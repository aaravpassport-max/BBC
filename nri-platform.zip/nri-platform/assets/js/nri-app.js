/* NRI Platform — nri-app.js v2.0 | All code inside single jQuery closure */
(function ($) {
    'use strict';

    /* ── Helpers ─────────────────────────────────────────────── */
    function esc(s) {
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
    }
    function nonce() { return NRI.admin_nonce || NRI.nonce; }
    function showMsg($el, type, text) {
        $el.removeClass('nri-alert-success nri-alert-error').addClass('nri-alert nri-alert-' + type).text(text).show();
    }
    function nriPost(action, data, cb, errCb) {
        data.action = action;
        data.nonce  = nonce();
        $.post(NRI.ajax_url, data)
            .done(function(r){ if (r.success) { if(cb) cb(r.data); } else { if(errCb) errCb(r.data&&r.data.message?r.data.message:'An error occurred.'); } })
            .fail(function(){ if(errCb) errCb('Connection error. Please check your internet and try again.'); });
    }

    /* ── Mobile-network-resilient upload helpers ─────────────────
       Root cause of "Connection error" on submit: large camera photos
       (often 4-10MB each) were sent unresized over a fixed 30s AJAX
       timeout, with no retry and no compression. On slow/unstable
       mobile data that upload routinely exceeds 30s or the connection
       drops mid-transfer, and the whole request fails outright.
    ═══════════════════════════════════════════════════════════ */

    // Downscale/compress an image file client-side before upload so a
    // 6-8MB phone-camera photo becomes ~200-500KB. PDFs and files that
    // are already small are sent as-is. Falls back to the original file
    // if compression fails or the browser can't do canvas/blob work.
    // TRACE: called per selected image, right before its background upload →
    //        decodes the photo via a blob: URL (NOT a FileReader data: URL — an
    //        8MB camera photo becomes an ~11MB base64 string in memory that
    //        low-RAM phones can choke on), draws it onto a canvas scaled to
    //        maxDim, flattens any transparency onto white (JPEG has no alpha, so
    //        a PNG screenshot would otherwise turn black), and re-encodes as
    //        JPEG → output: a File whose NAME ends in .jpg to match its JPEG
    //        content — the server's wp_check_filetype_and_ext() rejects a file
    //        named *.png whose bytes are JPEG, which is exactly what mobile
    //        screenshots (always PNG, usually >700KB) used to hit →
    //        edge cases: non-image/PDF or tiny files pass through untouched;
    //        any decode/canvas/toBlob failure resolves with the ORIGINAL file so
    //        compression can never block an upload; blob URL is always revoked.
    function nriCompressImage(file, maxDim, quality) {
        return new Promise(function (resolve) {
            if (!/^image\/(jpeg|jpg|png)$/i.test(file.type) || !(window.URL && URL.createObjectURL)) {
                resolve(file);
                return;
            }
            // Small files aren't worth the round-trip through canvas.
            if (file.size <= 700 * 1024) {
                resolve(file);
                return;
            }
            var url = URL.createObjectURL(file);
            var done = function (f) { try { URL.revokeObjectURL(url); } catch (e0) {} resolve(f); };
            var img = new Image();
            img.onerror = function () { done(file); };
            img.onload = function () {
                try {
                    var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
                    var scale = Math.min(1, maxDim / Math.max(w, h));
                    var cw = Math.max(1, Math.round(w * scale));
                    var ch = Math.max(1, Math.round(h * scale));
                    var canvas = document.createElement('canvas');
                    canvas.width = cw; canvas.height = ch;
                    var ctx = canvas.getContext('2d');
                    ctx.fillStyle = '#ffffff';
                    ctx.fillRect(0, 0, cw, ch);
                    ctx.drawImage(img, 0, 0, cw, ch);
                    canvas.toBlob(function (blob) {
                        if (!blob || blob.size >= file.size) { done(file); return; }
                        var newName = (file.name || 'document').replace(/\.[^.]+$/, '') + '.jpg';
                        var compressed;
                        try {
                            compressed = new File([blob], newName, { type: 'image/jpeg', lastModified: Date.now() });
                        } catch (e2) {
                            // Older mobile browsers may not support the File constructor fully.
                            blob.name = newName;
                            compressed = blob;
                        }
                        done(compressed);
                    }, 'image/jpeg', quality || 0.75);
                } catch (e3) {
                    done(file);
                }
            };
            img.src = url;
        });
    }

    function nriFormatMB(bytes) { return (bytes / (1024 * 1024)).toFixed(1) + 'MB'; }

    // TRACE: called when an AJAX call comes back 403 → asks the server for a
    //        fresh frontend nonce (action nri_fresh_nonce, nopriv) → on success
    //        stores it in NRI.nonce and calls cb(true); any failure calls
    //        cb(false) → edge case: never loops, callers retry at most once.
    function nriRefreshNonce(cb) {
        $.ajax({ url: NRI.ajax_url, type: 'POST', data: { action: 'nri_fresh_nonce' }, timeout: 15000 })
            .done(function (r) {
                if (r && r.success && r.data && r.data.nonce) { NRI.nonce = r.data.nonce; cb(true); }
                else { cb(false); }
            })
            .fail(function () { cb(false); });
    }

    // TRACE: turns a failed jQuery XHR into a short, TRUE, visitor-readable
    //        reason (previously every failure was labelled "Connection error",
    //        hiding whether it was a real network drop, a too-large file, a
    //        server error or an expired page) → uses the server's own JSON
    //        message when one came back → always returns a non-empty string.
    function nriDescribeAjaxError(xhr, status) {
        var serverMsg = (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ? xhr.responseJSON.data.message : '';
        if (serverMsg) return serverMsg;
        if (status === 'timeout') return 'The upload timed out — your connection looks slow. Please retry.';
        if (xhr && xhr.status === 0) {
            return (navigator.onLine === false)
                ? 'You appear to be offline. Reconnect and retry.'
                : 'Network connection was interrupted. Please retry (try Wi-Fi if on mobile data).';
        }
        if (xhr.status === 413) return 'File is too large for the server. Please choose a smaller file.';
        if (xhr.status === 403) return 'Your session expired. Please refresh the page and try again.';
        if (xhr.status >= 500) return 'Server error (' + xhr.status + '). Please retry in a moment.';
        return 'Upload failed (error ' + xhr.status + '). Please retry.';
    }

    // Uploads FormData with: a size-aware timeout (mobile networks can be
    // very slow — a fixed 30s budget is not enough for a few MB), a live
    // progress bar, and automatic retry on true network failures (a
    // dropped connection, DNS hiccup, etc.) — but never on a normal
    // server validation response, which arrives with a real HTTP status.
    function nriUploadWithRetry(opts) {
        var attempt = 0;
        var maxAttempts = opts.maxAttempts || 3;

        function bytesOf(fd) {
            var total = 0;
            if (fd && typeof fd.entries === 'function') {
                for (var pair of fd.entries()) {
                    var v = pair[1];
                    if (v && typeof v.size === 'number') total += v.size;
                }
            }
            return total;
        }

        var totalBytes = bytesOf(opts.formData);
        // Budget generously for slow/unstable mobile data: assume as
        // little as ~60KB/s of usable throughput, plus a large fixed
        // floor for latency, retries on the server, etc.
        var dynamicTimeout = Math.max(60000, Math.ceil(totalBytes / (60 * 1024)) * 1000 + 30000);

        function doAttempt() {
            attempt++;
            if (opts.onAttempt) opts.onAttempt(attempt, maxAttempts);

            $.ajax({
                url: NRI.ajax_url,
                type: 'POST',
                data: opts.formData,
                processData: false,
                contentType: false,
                timeout: opts.timeout || dynamicTimeout,
                xhr: function () {
                    var x = $.ajaxSettings.xhr();
                    if (x.upload) {
                        x.upload.addEventListener('progress', function (e) {
                            if (e.lengthComputable && opts.onProgress) {
                                opts.onProgress(Math.round((e.loaded / e.total) * 100));
                            }
                        });
                    }
                    return x;
                },
                success: function (r) {
                    if (opts.onSuccess) opts.onSuccess(r);
                },
                error: function (xhr, status) {
                    // status 0 / readyState 0 or the jQuery statuses
                    // 'timeout'/'error' with no real HTTP status code all
                    // mean the request never reached the server (or the
                    // response never got back) — i.e. a genuine network
                    // problem, not a validation rejection. Those are
                    // worth retrying on a flaky mobile connection. So are
                    // 502/503/504 (host/proxy blips under load).
                    var isNetworkFailure = (xhr.status === 0) || status === 'timeout' ||
                        xhr.status === 502 || xhr.status === 503 || xhr.status === 504;
                    // 403 = the page's embedded security token (nonce) is
                    // stale — typical when a mobile tab sat open for hours,
                    // was restored from the back/forward cache, or the page
                    // HTML itself was served from a page cache. Fetch a fresh
                    // token and retry ONCE, transparently, instead of
                    // telling the visitor "connection error".
                    if (xhr.status === 403 && !opts._nonceRefreshed) {
                        opts._nonceRefreshed = true;
                        nriRefreshNonce(function (ok) {
                            if (ok && opts.formData && typeof opts.formData.set === 'function') {
                                opts.formData.set('nonce', NRI.nonce);
                                attempt--; // the refresh retry doesn't use up a network-retry attempt
                                doAttempt();
                            } else if (opts.onError) {
                                opts.onError(xhr, status, attempt);
                            }
                        });
                        return;
                    }
                    if (isNetworkFailure && attempt < maxAttempts) {
                        if (opts.onRetry) opts.onRetry(attempt, maxAttempts);
                        setTimeout(doAttempt, 1500 * attempt); // brief backoff
                        return;
                    }
                    if (opts.onError) opts.onError(xhr, status, attempt);
                }
            });
        }

        doAttempt();
        return { totalBytes: totalBytes, timeout: dynamicTimeout };
    }

    /* ── Background document uploads for the new-request form ────
       Root cause of "shows an error even though the application was
       actually submitted": documents used to ride along with the
       final Submit click as one big multipart request, so a slow
       mobile upload could blow the client's wait budget (or just
       take a long time) AFTER the server had already finished
       successfully — the browser then showed a connection/timeout
       error for a request that had, in fact, succeeded.

       Fix: a document starts uploading the instant it's selected
       (see the #nri-file-input change handler below), independently
       of the rest of the form. By the time the student clicks
       Submit, most files are already done; Submit itself only ever
       sends small field data plus the IDs of whichever uploads have
       finished — never the files themselves — so it's fast and its
       own retry-after-timeout is safe (see submission_token below,
       matched server-side so a retried submit can never create a
       duplicate request). Anything still uploading when Submit is
       clicked keeps going in the background and gets linked to the
       new request as soon as it finishes — see nriWatchInFlightUploads. */
    var NRI_UPLOAD_TOKEN = (function () {
        try {
            var arr = new Uint8Array(16);
            (window.crypto || window.msCrypto).getRandomValues(arr);
            var t = '';
            for (var i = 0; i < arr.length; i++) t += ('0' + arr[i].toString(16)).slice(-2);
            return t;
        } catch (e) {
            return 'nt' + Date.now().toString(36) + Math.random().toString(36).slice(2);
        }
    })();

    var nriPendingUploads = {}; // clientId -> {file, name, size, status, attId, error}
    var _nriUploadSeq = 0;

    function nriRenderFilePreview() {
        var $list = $('#nri-file-preview-list');
        if (!$list.length) return;
        $list.empty();
        Object.keys(nriPendingUploads).forEach(function (cid) {
            var u = nriPendingUploads[cid], badge;
            if (u.status === 'uploading' || u.status === 'queued') {
                badge = '<span style="color:#2563eb;font-size:11px;">⏳ Uploading…</span>';
            } else if (u.status === 'done') {
                badge = '<span style="color:#16a34a;font-size:11px;">✅ Uploaded</span>';
            } else {
                badge = '<span style="color:#b45309;font-size:11px;">⚠️ ' + esc(u.error || 'Upload failed') + ' <a href="#" class="nri-fp-retry" data-cid="' + cid + '" style="color:#2563eb;">Retry</a></span>';
            }
            $list.append(
                '<div class="nri-fp-item" data-cid="' + cid + '" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">' +
                '<span>📎 ' + esc(u.name) + '</span>' +
                '<span style="color:#94a3b8;font-size:11px;">' + Math.round(u.size / 1024) + 'KB</span>' +
                badge +
                '</div>'
            );
        });
    }

    function nriStartBackgroundUpload(cid) {
        var u = nriPendingUploads[cid];
        if (!u) return;
        u.status = 'uploading'; u.error = null;
        nriRenderFilePreview();
        nriCompressImage(u.file, 1920, 0.75).then(function (processed) {
            var fd = new FormData();
            fd.append('action', 'nri_pending_upload');
            fd.append('nonce', NRI.nonce);
            fd.append('upload_token', NRI_UPLOAD_TOKEN);
            fd.append('file', processed, u.file.name);
            nriUploadWithRetry({
                formData: fd,
                maxAttempts: 3,
                onSuccess: function (r) {
                    if (r.success) {
                        u.status = 'done';
                        u.attId  = r.data.id;
                    } else {
                        u.status = 'error';
                        u.error  = (r.data && r.data.message) ? r.data.message : 'Upload failed.';
                    }
                    nriRenderFilePreview();
                },
                onError: function (xhr, status) {
                    u.status = 'error';
                    u.error  = nriDescribeAjaxError(xhr, status);
                    nriRenderFilePreview();
                }
            });
        }).catch(function () {
            u.status = 'error'; u.error = 'Could not prepare file.';
            nriRenderFilePreview();
        });
    }

    $(document).on('click', '.nri-fp-retry', function (e) {
        e.preventDefault();
        nriStartBackgroundUpload($(this).data('cid'));
    });

    // Once the request has been created, keep an eye on any uploads that
    // were still in flight at that moment; the instant each one finishes,
    // link it to the now-existing request. Polls the shared
    // nriPendingUploads status object (updated by nriStartBackgroundUpload's
    // own success/error handler above) rather than opening new requests of
    // its own, so this never competes with the uploads themselves.
    function nriWatchInFlightUploads(cids, postId) {
        if (!cids || !cids.length) return;
        var remaining = cids.slice();
        var timer = setInterval(function () {
            remaining = remaining.filter(function (cid) {
                var u = nriPendingUploads[cid];
                if (!u) return false;
                if (u.status === 'uploading' || u.status === 'queued') return true;
                if (u.status === 'done' && u.attId) {
                    $.post(NRI.ajax_url, {
                        action: 'nri_attach_pending_document',
                        nonce: NRI.nonce,
                        request_id: postId,
                        attachment_id: u.attId,
                        upload_token: NRI_UPLOAD_TOKEN
                    });
                }
                return false; // done or errored — stop watching this one
            });
            var $note = $('#nri-submit-bg-note');
            if (remaining.length) {
                $note.text('⏳ ' + remaining.length + ' document(s) still uploading in the background…');
            } else {
                clearInterval(timer);
                if ($note.length) $note.text('✅ All documents uploaded.');
            }
        }, 1000);
    }

    /* ── Persist in-progress request-form field values so a failed
       submission (network drop, closed tab, browser crash) never
       costs the client their typed-in answers. Files themselves
       can't be persisted this way, but re-selecting a file is far
       less painful than re-typing an entire multi-step form. ── */
    var NRI_DRAFT_KEY = 'nri_request_draft_v1';
    function nriSaveDraft($form) {
        try {
            var data = {};
            $form.find('input, select, textarea').not('[type=file]').each(function () {
                var $el = $(this), name = $el.attr('name');
                if (!name) return;
                if ($el.attr('type') === 'radio' || $el.attr('type') === 'checkbox') {
                    if ($el.is(':checked')) data[name] = $el.val();
                } else {
                    data[name] = $el.val();
                }
            });
            sessionStorage.setItem(NRI_DRAFT_KEY, JSON.stringify(data));
        } catch (e) { /* storage unavailable (private mode, quota) — ignore, non-critical */ }
    }
    function nriRestoreDraft($form) {
        try {
            var raw = sessionStorage.getItem(NRI_DRAFT_KEY);
            if (!raw) return;
            var data = JSON.parse(raw);
            Object.keys(data).forEach(function (name) {
                var $el = $form.find('[name="' + name.replace(/"/g, '\\"') + '"]');
                if (!$el.length) return;
                if ($el.attr('type') === 'radio' || $el.attr('type') === 'checkbox') {
                    $el.filter('[value="' + String(data[name]).replace(/"/g, '\\"') + '"]').prop('checked', true);
                } else {
                    $el.val(data[name]);
                }
            });
            nriRunConditionalLogicSafe();
        } catch (e) { /* ignore */ }
    }
    function nriClearDraft() {
        try { sessionStorage.removeItem(NRI_DRAFT_KEY); } catch (e) { /* ignore */ }
    }
    // nriRunConditionalLogic is defined later in this file; this thin
    // wrapper lets the draft-restore code above (defined earlier in
    // source order) call it safely once it exists.
    function nriRunConditionalLogicSafe() {
        if (typeof nriRunConditionalLogic === 'function') nriRunConditionalLogic();
    }

    /* ═══════════════════════════════════════════════════════════
       AUTH — Login tabs, login form, magic link, pw toggle
    ═══════════════════════════════════════════════════════════ */
    $(document).on('click', '.nri-lt', function () {
        var lt = $(this).data('lt');
        $(this).closest('.nri-login-card').find('.nri-lt').removeClass('active');
        $(this).closest('.nri-login-card').find('.nri-lt-pane').removeClass('active').hide();
        $(this).addClass('active');
        $('#nri-lt-' + lt).addClass('active').show();
    });
    $(document).on('click', '.nri-pw-toggle', function () {
        var $i = $(this).siblings('input');
        if ($i.attr('type') === 'password') { $i.attr('type','text'); $(this).text('Hide'); }
        else { $i.attr('type','password'); $(this).text('Show'); }
    });
    $(document).on('submit', '#nri-login-form', function (e) {
        e.preventDefault();
        var $f=$('#nri-login-form'), $btn=$f.find('[type=submit]'), $err=$('#nri-login-err');
        $btn.find('.nri-bt').hide(); $btn.find('.nri-bl').show(); $btn.prop('disabled',true); $err.hide();
        $.ajax({url:NRI.ajax_url,type:'POST',timeout:15000,data:{action:'nri_login',nonce:NRI.nonce,email:$f.find('[name=email]').val(),password:$f.find('[name=password]').val()},
            success:function(r){if(r.success){window.location.href=r.data.redirect;}else{$err.text(r.data&&r.data.message?r.data.message:'Login failed.').show();$btn.find('.nri-bt').show();$btn.find('.nri-bl').hide();$btn.prop('disabled',false);}},
            error:function(){$err.text('Connection error. Please try again.').show();$btn.find('.nri-bt').show();$btn.find('.nri-bl').hide();$btn.prop('disabled',false);}
        });
    });
    $(document).on('submit', '#nri-magic-form', function (e) {
        e.preventDefault();
        var $f=$(this),$btn=$f.find('[type=submit]'),$msg=$('#nri-magic-msg');
        $btn.text('Sending…').prop('disabled',true);
        $.post(NRI.ajax_url,{action:'nri_magic_link',nonce:NRI.nonce,email:$f.find('[name=email]').val()},function(){$msg.addClass('nri-alert nri-alert-success').text('Login link sent! Check your inbox.').show();$btn.text('Resend').prop('disabled',false);});
    });

    /* ═══════════════════════════════════════════════════════════
       MULTI-STEP REQUEST FORM WIZARD
    ═══════════════════════════════════════════════════════════ */
    var _step = 1, _totalSteps = 4;

    // scrollTop (default true): moving FORWARD to a new step still scrolls
    // to the top of it, same as before — that's normal, expected wizard
    // behavior, especially on mobile, so the new step's fields are visible
    // from the start rather than wherever the previous step happened to
    // leave the scroll position. Going BACK to a previous step passes
    // false — the page just stays where it was, matching the same
    // "never force a scroll jump" rule applied to the dashboards.
    function gotoStep(n, $form, scrollTop) {
        _step = n;
        var $root = ($form && $form.length) ? $form : $(document);
        $root.find('.nri-wizard-step').hide();
        $root.find('.nri-wizard-step[data-step="' + n + '"]').show();
        // Update step dots — look in parent container of the form
        var $dotsRoot = ($form && $form.length) ? $form.parent() : $(document);
        $dotsRoot.find('.nri-step').each(function(){
            var s = parseInt($(this).data('step'));
            $(this).removeClass('nri-step-active nri-step-done');
            if (s === n) $(this).addClass('nri-step-active');
            else if (s < n) $(this).addClass('nri-step-done');
        });
        $dotsRoot.find('.nri-step-line').each(function(i){ $(this).toggleClass('nri-step-line-done', i < n-1); });
        $dotsRoot.find('.nri-sl-step').each(function(){
            var s = parseInt($(this).data('step'));
            $(this).removeClass('nri-sl-step-active nri-sl-step-done');
            if (s === n) $(this).addClass('nri-sl-step-active');
            else if (s < n) $(this).addClass('nri-sl-step-done');
        });
        $dotsRoot.find('.nri-sl-step-line').each(function(i){ $(this).toggleClass('nri-sl-line-done', i < n-1); });
        // Animated progress bar: fraction = current step / total steps
        var _total = $root.find('.nri-wizard-step').length || 1;
        $dotsRoot.find('.nri-progress-fill').css('--p', Math.min(1, Math.max(0, n / _total)));
        $root.find('.nri-step-notice').remove();
        if (scrollTop !== false) {
            // Scroll to the top of the FORM itself, not the top of the
            // whole page — the page can have a header/hero above the form,
            // and jumping past that to y=0 hides the form's own heading
            // and step indicator. $dotsRoot is the form's wrapper (its
            // parent), which is what actually starts at the form's visual
            // top including the step dots — that's the right anchor.
            var $scrollTarget = ($dotsRoot && $dotsRoot.length) ? $dotsRoot : $form;
            var targetTop = ($scrollTarget && $scrollTarget.length) ? $scrollTarget.offset().top - 20 : 0;
            $('html,body').animate({scrollTop: Math.max(0, targetTop)}, 200);
        }
    }

    // ── Inline field validation helpers (class based, no alert()) ─────────────
    var NRI_EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    // TRACE: field/group wrapper + message (or null) -> toggles .nri-invalid on the .nri-field wrapper and
    //        writes/removes its .nri-field-err line -> postcondition: wrapper has class nri-invalid iff msg truthy
    function nriMarkField($wrap, msg) {
        if (!$wrap || !$wrap.length) return;
        var $err = $wrap.children('.nri-field-err');
        if (msg) {
            if (!$err.length) { $err = $('<p class="nri-field-err" role="alert"></p>').appendTo($wrap); }
            $err.text(msg);
            $wrap.addClass('nri-invalid').removeClass('nri-valid');
        } else {
            $err.remove();
            $wrap.removeClass('nri-invalid');
        }
    }
    // TRACE: blur of a required text/select/textarea/search input -> empty => "required" msg, bad email => format msg,
    //        else marks valid -> only acts on fields whose .nri-field has a .nri-req star and is not conditionally hidden
    $(document).on('focusout', '.nri-wizard-form .nri-field input:not([type=radio]):not([type=file]):not([type=hidden]), .nri-wizard-form .nri-field select, .nri-wizard-form .nri-field textarea', function () {
        var $f = $(this), $w = $f.closest('.nri-field');
        if ($f.hasClass('nri-phone-code')) return;
        if (!$w.find('.nri-req').length || $w.closest('.nri-cond-field').is(':hidden')) return;
        var v = $.trim($f.val());
        if (v === '') { nriMarkField($w, 'This field is required'); return; }
        if ($f.attr('type') === 'email' && !NRI_EMAIL_RE.test(v)) { nriMarkField($w, 'Enter a valid email address'); return; }
        nriMarkField($w, null); $w.addClass('nri-valid');
    });
    // Clear the error as soon as the user fixes the field
    $(document).on('input change', '.nri-wizard-form .nri-field.nri-invalid input, .nri-wizard-form .nri-field.nri-invalid select, .nri-wizard-form .nri-field.nri-invalid textarea', function () {
        var $f = $(this), $w = $f.closest('.nri-field');
        if ($.trim($f.val()) !== '' || $f.is(':radio:checked')) { nriMarkField($w, null); }
    });

    // ── NEXT button: validate only the current visible step's fields ──────────
    $(document).on('click', '.nri-wizard-next', function () {
        var $btn  = $(this);
        var step  = parseInt($btn.data('step'));
        var $form = $btn.closest('form');
        var $step = $form.length
            ? $form.find('.nri-wizard-step[data-step="' + step + '"]')
            : $('.nri-wizard-step[data-step="' + step + '"]').first();

        var ok = true;
        var DEBUG = false; // Set to true to see console logs

        // Helper: is a field marked required?
        function isReq($f) {
            var $fw = $f.closest('.nri-field');
            var hasStar = $fw.find('.nri-req').length > 0;
            if (DEBUG) console.log('isReq check:', {field: $f.attr('name'), wrapper: $fw[0], hasStar: hasStar});
            return hasStar;
        }
        // Helper: is a field inside a hidden conditional wrapper?
        function isCondHidden($f) {
            var $c = $f.closest('.nri-cond-field');
            return $c.length && $c.is(':hidden');
        }

        // 1) Text, email, number, tel, select, textarea
        $step.find('input, select, textarea').each(function(){
            var $f   = $(this);
            var type = ($f.attr('type') || 'text').toLowerCase();
            if (type === 'hidden' || type === 'radio' || type === 'file') return;
            var req = isReq($f);
            var condHide = isCondHidden($f);
            if (!req) return;
            if (condHide) return;
            var val = $.trim($f.val());
            if (DEBUG) console.log('Validating field:', {name: $f.attr('name'), type: type, required: req, hidden: condHide, value: val});
            if (val === '') {
                nriMarkField($f.closest('.nri-field'), 'This field is required');
                ok = false;
                if (DEBUG) console.log('Field FAILED validation:', $f.attr('name'));
            } else if (type === 'email' && !NRI_EMAIL_RE.test(val)) {
                nriMarkField($f.closest('.nri-field'), 'Enter a valid email address');
                ok = false;
            } else {
                nriMarkField($f.closest('.nri-field'), null);
            }
        });

        // 2) Searchable fields — validate the visible text input
        $step.find('.nri-search-field').each(function(){
            var $sf = $(this);
            if (isCondHidden($sf)) return;
            if (!isReq($sf)) return;
            var visVal = $.trim($sf.find('.nri-sf-input').val());
            if (visVal === '') {
                nriMarkField($sf.closest('.nri-field'), 'Please choose an option');
                ok = false;
            } else {
                nriMarkField($sf.closest('.nri-field'), null);
            }
        });

        // 3) Radio groups
        var seenGroups = {};
        $step.find('input[type=radio]').each(function(){
            var name = $(this).attr('name');
            if (seenGroups[name] !== undefined) return;
            var $group = $step.find('input[type=radio][name="' + name + '"]');
            if (isCondHidden($group.first())) { seenGroups[name] = true; return; }
            if (!isReq($group.first())) { seenGroups[name] = true; return; }
            var checked = $group.filter(':checked').length > 0;
            seenGroups[name] = checked;
            if (!checked) {
                nriMarkField($group.first().closest('.nri-field'), 'Please select one');
                ok = false;
            } else {
                nriMarkField($group.first().closest('.nri-field'), null);
            }
        });

        if (!ok) {
            // Inline notice (replaces the blocking alert()) + jump to the first problem
            $step.find('.nri-step-notice').remove();
            $('<div class="nri-step-notice" role="alert">Please complete the highlighted fields to continue.</div>').insertBefore($step.find('.nri-step-nav'));
            var $first = $step.find('.nri-invalid').first();
            if ($first.length) {
                var top = $first.offset().top - 90;
                $('html,body').animate({scrollTop: Math.max(0, top)}, 180);
                $first.find('input:visible,select:visible,textarea:visible').first().trigger('focus');
            }
            return;
        }
        gotoStep(step + 1, $form);
    });

    $(document).on('click', '.nri-wizard-prev', function () {
        var $f = $(this).closest('form');
        gotoStep(parseInt($(this).data('step')) - 1, $f, false);
    });

    // File select — upload starts immediately in the background (see
    // nriStartBackgroundUpload above), not when the form is submitted.
    $(document).on('change', '#nri-file-input', function () {
        var files = this.files;
        var maxBytes = (typeof MAX_FILE_BYTES !== 'undefined') ? MAX_FILE_BYTES : 10 * 1024 * 1024;
        for (var i = 0; i < files.length; i++) {
            var f = files[i];
            var cid = 'f' + (++_nriUploadSeq);
            if (f.size > maxBytes) {
                // Oversized — flagged here for free; the existing pre-submit
                // size check still blocks Submit outright, this just makes
                // the reason visible the moment the file is picked.
                nriPendingUploads[cid] = { file: f, name: f.name, size: f.size, status: 'error', attId: null, error: 'Exceeds 10MB limit' };
                continue;
            }
            nriPendingUploads[cid] = { file: f, name: f.name, size: f.size, status: 'queued', attId: null, error: null };
            nriStartBackgroundUpload(cid);
        }
        nriRenderFilePreview();
    });

    // Searchable dropdown in form
    var _sfTimers = {};
    $(document).on('input', '.nri-sf-input', function () {
        var $inp=$(this), key=$inp.data('field'), $wrap=$inp.closest('.nri-search-field'), $dd=$wrap.find('.nri-sf-dropdown'), $val=$wrap.find('.nri-sf-val'), q=$inp.val().trim();
        $val.val('');
        if (q.length<1){$dd.hide().empty();return;}
        clearTimeout(_sfTimers[key]);
        _sfTimers[key]=setTimeout(function(){
            $.post(NRI.ajax_url,{action:'nri_search_dropdown',field_key:key,search:q},function(r){
                if(!r.success||!r.data.length){$dd.html('<div class="nri-sf-item nri-sf-empty">No results</div>').show();return;}
                var h=''; $.each(r.data,function(i,v){h+='<div class="nri-sf-item" data-v="'+esc(v)+'">'+esc(v)+'</div>';});
                $dd.html(h).show();
            });
        },280);
    });
    $(document).on('click', '.nri-sf-item:not(.nri-sf-empty)', function () {
        var $wrap=$(this).closest('.nri-search-field');
        $wrap.find('.nri-sf-input').val($(this).data('v'));
        $wrap.find('.nri-sf-val').val($(this).data('v'));
        $wrap.find('.nri-sf-dropdown').hide().empty();
    });
    $(document).on('click', function(e){if(!$(e.target).closest('.nri-search-field').length)$('.nri-sf-dropdown').hide().empty();});

    /* ═══════════════════════════════════════════════════════════
       CONDITIONAL LOGIC ENGINE — Fluent Forms style
       Evaluates .nri-cond-field data-nri-cond attributes in real time
    ═══════════════════════════════════════════════════════════ */
    function nriGetFieldValue(fieldKey) {
        var $form = $('#nri-request-form');
        if (!$form.length) return '';
        var name = 'field_' + fieldKey;
        // Radio
        var $radio = $form.find('input[type=radio][name="'+name+'"]:checked');
        if ($radio.length) return $radio.val();
        // Hidden (searchable)
        var $hidden = $form.find('input[type=hidden][name="'+name+'"]');
        if ($hidden.length) return $hidden.val() || '';
        // Select / Input / Textarea
        var $el = $form.find('[name="'+name+'"]').not('[type=radio]').not('[type=hidden]');
        if ($el.length) return $el.val() || '';
        return '';
    }

    function nriEvalCondition(rule) {
        var val = String(nriGetFieldValue(rule.field) || '').toLowerCase().trim();
        var rv  = String(rule.value || '').toLowerCase().trim();
        switch (rule.operator) {
            case 'equals':         return val === rv;
            case 'not_equals':     return val !== rv;
            case 'contains':       return val.indexOf(rv) !== -1;
            case 'not_contains':   return val.indexOf(rv) === -1;
            case 'starts_with':    return val.indexOf(rv) === 0;
            case 'ends_with':      return val.slice(-rv.length) === rv;
            case 'is_empty':       return val === '';
            case 'is_not_empty':   return val !== '';
            case 'greater_than':   return parseFloat(val) > parseFloat(rv);
            case 'less_than':      return parseFloat(val) < parseFloat(rv);
        }
        return false;
    }

    function nriEvalConditions(condData) {
        if (!condData || !condData.rules || !condData.rules.length) return true;
        var action = condData.action || 'all';
        if (action === 'any') {
            for (var i=0; i<condData.rules.length; i++) {
                if (nriEvalCondition(condData.rules[i])) return true;
            }
            return false;
        } else {
            for (var j=0; j<condData.rules.length; j++) {
                if (!nriEvalCondition(condData.rules[j])) return false;
            }
            return true;
        }
    }

    function nriRunConditionalLogic() {
        $('.nri-cond-field[data-nri-cond]').each(function() {
            var $el = $(this);
            var condJson = $el.attr('data-nri-cond');
            if (!condJson) return;
            var condData;
            try { condData = JSON.parse(condJson); } catch(e) { return; }
            var show = nriEvalConditions(condData);
            if (show) {
                $el.slideDown(150);
                // Re-enable required on hidden inputs
                $el.find('input,select,textarea').each(function(){
                    if ($(this).data('nri-was-required')) $(this).prop('required', true);
                });
            } else {
                $el.slideUp(150);
                // Disable required so form can still submit
                $el.find('input[required],select[required],textarea[required]').each(function(){
                    $(this).data('nri-was-required', true).prop('required', false);
                });
            }
        });
    }

    // Run on any form input change
    $(document).on('change input', '#nri-request-form input, #nri-request-form select, #nri-request-form textarea', function() {
        nriRunConditionalLogic();
    });
    // Run on searchable field value change
    $(document).on('click', '.nri-sf-item:not(.nri-sf-empty)', function() {
        setTimeout(nriRunConditionalLogic, 50);
    });
    // Initial run
    $(document).ready(function() {
        if ($('#nri-request-form').length) {
            nriRestoreDraft($('#nri-request-form'));
            nriRunConditionalLogic();
        }
    });

    // Keep the draft up to date as the client fills the form in, so a
    // dropped connection at submit time (or an accidental tab close)
    // doesn't cost them everything they've typed so far.
    $(document).on('change input', '#nri-request-form', function () {
        nriSaveDraft($('#nri-request-form'));
    });

    var MAX_FILE_BYTES = 10 * 1024 * 1024;

    // Submit request form
    $(document).on('submit', '#nri-request-form', function (e) {
        e.preventDefault();
        var $f=$(this), $btn=$f.find('[type=submit]'), $err=$f.find('#nri-form-err, .nri-form-err').first();
        if (!$err.length) $err = $('#nri-form-err');
        var $prog = $('#nri-submit-progress'), $progFill = $('#nri-submit-progress-fill'), $progLabel = $('#nri-submit-progress-label');

        // Validate required file upload fields
        // Strategy: find every .nri-field that (a) has .nri-req star and (b) contains a .nri-dropzone
        // Skip only if the field has conditional logic (data-nri-cond attr) AND that condition hid it
        var fileOk = true;
        $f.find('.nri-field').each(function(){
            var $fw = $(this);

            // Does this field wrap a dropzone?
            var $dz = $fw.children('.nri-dropzone');
            if (!$dz.length) return; // not a file field

            // Is it marked required? (.nri-req star must be in the label)
            var isRequired = $fw.find('label .nri-req').length > 0;
            if (!isRequired) return;

            // Is it a CONDITIONAL field that is currently hidden by its condition?
            // Only skip if it explicitly has conditions AND those conditions are hiding it
            var hasCond  = typeof $fw.attr('data-nri-cond') !== 'undefined';
            var condHide = hasCond && $fw.css('display') === 'none';
            if (condHide) return;

            // Get the actual file input — it has id="nri-file-input" but use find() to be safe
            var fi = $dz.find('input[type="file"]')[0];
            var hasFiles = fi && fi.files && fi.files.length > 0;

            if (!hasFiles) {
                $dz.css({'border-color': '#ef4444', 'background': '#fff5f5'});
                fileOk = false;
            } else {
                $dz.css({'border-color': '', 'background': ''});
            }
        });

        if (!fileOk) {
            $err.text('Please upload all required documents before submitting.').show();
            gotoStep(4, $f);
            return;
        }

        // Client-side size check BEFORE we attempt any upload — catching an
        // oversized file here (instantly, for free) beats letting the client
        // burn minutes of their mobile data pushing it to the server only to
        // have it rejected (or the connection give out) at the end.
        var fileInput = document.getElementById('nri-file-input');
        var oversized = [];
        if (fileInput && fileInput.files) {
            for (var oi = 0; oi < fileInput.files.length; oi++) {
                if (fileInput.files[oi].size > MAX_FILE_BYTES) oversized.push(fileInput.files[oi].name);
            }
        }
        if (oversized.length) {
            $err.text('These files exceed the 10MB limit: ' + oversized.join(', ') + '. Please choose smaller files.').show();
            gotoStep(4, $f);
            return;
        }

        // Prevent duplicate submissions — a confused double-click (or a
        // retry that fires while the first attempt is still in flight)
        // must never send two create-request calls from the browser side.
        // (The server is also idempotent via submission_token below, which
        // covers the case where the FIRST call's response never made it
        // back at all — a true network timeout — and this handler gets to
        // run a second time.)
        if ($btn.data('nriSubmitting')) return;
        $btn.data('nriSubmitting', true);

        function resetBtn() {
            $btn.data('nriSubmitting', false);
            $btn.find('.nri-bt').show(); $btn.find('.nri-bl').hide(); $btn.prop('disabled', false);
            $prog.hide(); $progLabel.hide();
            nriRemoveProcessingCard($f);
        }

        $btn.find('.nri-bt').hide(); $btn.find('.nri-bl').show(); $btn.prop('disabled',true); $err.hide();
        // Old inline progress bar kept (hidden) for markup back-compat; the
        // actual "what's happening now" feedback is the staged checklist
        // takeover card below (nriRenderProcessingCard) — see spec sections
        // 1-2 ("Submitting Your Request..." + premium processing screen).
        $prog.hide(); $progLabel.hide();
        var $proc = nriRenderProcessingCard($f);
        nriSetProcessingStage($proc, 'account'); // request + documents are already known-good at this point

        // Documents already started uploading the moment they were
        // selected (see the #nri-file-input change handler above) — this
        // submission never sends the files themselves, only the IDs of
        // whichever background uploads have already finished. That's why
        // this call is small and fast regardless of how large or slow the
        // documents are.
        var fd = new FormData($f[0]);
        var fd2 = new FormData();
        for (var pair of fd.entries()) {
            if (pair[0] !== 'field_documents[]') fd2.append(pair[0], pair[1]);
        }
        fd2.append('action', 'nri_create_request');
        fd2.append('upload_token', NRI_UPLOAD_TOKEN);
        fd2.append('submission_token', NRI_UPLOAD_TOKEN);

        var doneIds = [], inFlightCids = [], erroredCount = 0;
        Object.keys(nriPendingUploads).forEach(function (cid) {
            var u = nriPendingUploads[cid];
            if (u.status === 'done' && u.attId) {
                doneIds.push(u.attId);
            } else if (u.status === 'uploading' || u.status === 'queued') {
                inFlightCids.push(cid);
            } else if (u.status === 'error') {
                erroredCount++;
            }
        });
        doneIds.forEach(function (id) { fd2.append('pending_upload_ids[]', id); });

        nriUploadWithRetry({
            formData: fd2,
            maxAttempts: 3,
            timeout: 30000, // field data only now — no need for the old size-scaled budget
            onProgress: function (pct) { $progFill.css('width', pct + '%'); },
            onRetry: function (attempt, max) {
                $progLabel.text('Connection interrupted — retrying (' + (attempt + 1) + '/' + max + ')…');
            },
            onSuccess: function (r) {
                if (r.success) {
                    nriClearDraft();
                    // Server round-trip is done: tick off the remaining two
                    // checklist stages in quick succession (a few hundred ms
                    // apart) so the client visibly sees "creating your
                    // account" then "preparing your dashboard" complete,
                    // rather than the checklist jumping straight from
                    // "active" to gone (spec section 2/5 — "Use a clean
                    // progress indicator or animated stepper").
                    nriSetProcessingStage($proc, 'account-done');
                    setTimeout(function () {
                        nriSetProcessingStage($proc, 'dashboard-done');
                        setTimeout(function () {
                            nriShowSubmitSuccess($f, $proc, r.data, inFlightCids.length, erroredCount);
                            if (inFlightCids.length) {
                                nriWatchInFlightUploads(inFlightCids, r.data.post_id);
                            }
                        }, 500);
                    }, 450);
                } else {
                    var msg = (r.data && r.data.message) ? r.data.message : 'Submission failed. Please try again.';
                    $err.text(msg).show();
                    resetBtn();
                }
            },
            onError: function (xhr, status) {
                var msg;
                if (status === 'timeout') {
                    msg = 'That took longer than expected. Please try again — if your application already went through, resubmitting is safe and won’t create a duplicate.';
                } else if (xhr.status === 0) {
                    msg = 'Connection lost while submitting. Your answers have been saved on this device — please check your internet connection and try again.';
                } else if (xhr.status >= 500) {
                    msg = 'The server had a problem processing your request. Please try again in a moment.';
                } else {
                    msg = nriDescribeAjaxError(xhr, status);
                }
                $err.text(msg).show();
                resetBtn();
            }
        });
    });

    // ── Premium submission processing card (spec section 2) ────────────────────
    // TRACE: called once, right when Submit is clicked (documents/request fields
    //        are already validated by this point) → hides the form and injects a
    //        4-line checklist takeover card in its place → mutates the DOM only
    //        (no network, no state) → precondition: $f is the request form jQuery
    //        object → postcondition: form is display:none, #nri-processing-card
    //        exists in the DOM with all four <li> stage rows present → edge case:
    //        calling it twice for the same $f is guarded by removing any existing
    //        card first, so a resubmission after an error never stacks two cards.
    function nriRenderProcessingCard($f) {
        nriRemoveProcessingCard($f);
        var html = '<div id="nri-processing-card" class="nri-proc-card" role="status" aria-live="polite">' +
            '<h3 class="nri-proc-title">Submitting Your Request</h3>' +
            '<ul class="nri-proc-steps">' +
            '<li class="nri-proc-step is-done" data-stage="details"><span class="nri-proc-mark">✓</span> Request details received</li>' +
            '<li class="nri-proc-step is-done" data-stage="documents"><span class="nri-proc-mark">✓</span> Documents uploaded successfully</li>' +
            '<li class="nri-proc-step is-active" data-stage="account"><span class="nri-proc-mark">●</span> Creating your client account</li>' +
            '<li class="nri-proc-step" data-stage="dashboard"><span class="nri-proc-mark">○</span> Preparing your request dashboard</li>' +
            '</ul>' +
            '<p class="nri-proc-note">Please wait — we\'re securely processing your request.</p>' +
            '</div>';
        $f.hide().after(html);
        var $card = $f.closest('.nri-sl-card, .nri-wizard-wrap');
        if ($card.length) $card[0].scrollIntoView({ behavior: 'smooth', block: 'start' });
        return $('#nri-processing-card');
    }

    function nriRemoveProcessingCard($f) {
        $('#nri-processing-card').remove();
        $('#nri-submit-success').remove();
    }

    // Advances the checklist's visual state. Stages, in order: 'account' (the
    // default render state — first two rows done, third active) ->
    // 'account-done' (third row ticked, fourth becomes active) ->
    // 'dashboard-done' (all four rows ticked). Never called with an earlier
    // stage than the card's current one, so this only ever moves forward.
    function nriSetProcessingStage($proc, stage) {
        if (!$proc || !$proc.length) return;
        function markDone($li) { $li.removeClass('is-active').addClass('is-done').find('.nri-proc-mark').text('✓'); }
        function markActive($li) { $li.addClass('is-active').find('.nri-proc-mark').text('●'); }
        if (stage === 'account') {
            markActive($proc.find('[data-stage="account"]'));
        } else if (stage === 'account-done') {
            markDone($proc.find('[data-stage="account"]'));
            markActive($proc.find('[data-stage="dashboard"]'));
        } else if (stage === 'dashboard-done') {
            markDone($proc.find('[data-stage="account"]'));
            markDone($proc.find('[data-stage="dashboard"]'));
        }
    }

    // ── Success confirmation (spec section 3) + auto-redirect (spec section 6) ─
    // TRACE: called once the processing checklist has fully ticked over →
    //        replaces the checklist card with the success confirmation (Request
    //        ID, account-creation explainer, primary/secondary CTAs) → when no
    //        document upload is still in flight, additionally counts down and
    //        navigates to the dashboard automatically; when one or more uploads
    //        are still running, autonav is skipped so navigating away can't
    //        cancel an in-flight upload (matches the pre-existing behaviour this
    //        replaces) → precondition: r.data (request_id, redirect, post_id,
    //        is_new) came back from a successful nri_create_request call →
    //        postcondition: #nri-submit-success is in the DOM; a countdown timer
    //        is running only in the "nothing pending" branch → edge cases
    //        handled: pendingCount>0 (no autonav, shows "still uploading" note),
    //        erroredCount>0 (shows skipped-file warning), user clicking "Go to
    //        My Account" cancels the pending countdown via clearInterval before
    //        navigating (avoids a double-navigation, harmless either way since
    //        both targets are the same URL, but avoids a stray console error
    //        from setting state after navigation started).
    function nriShowSubmitSuccess($f, $proc, data, pendingCount, erroredCount) {
        if ($proc && $proc.length) $proc.remove();
        $('#nri-submit-success').remove();

        var autoRedirect = !pendingCount;
        var secondsLeft = 5;

        var html = '<div id="nri-submit-success" class="nri-success-card" role="status" aria-live="polite">' +
            '<div class="nri-success-icon">✅</div>' +
            '<h3 class="nri-success-title">Request Submitted Successfully!</h3>' +
            '<p class="nri-success-sub">Your request has been received and your documents have been securely submitted.</p>' +
            '<div class="nri-success-refbox">Request ID: <strong>' + esc(data.request_id) + '</strong></div>' +
            (data.is_new ?
                '<p class="nri-success-account">We\'ve created your client account so you can track this request, view your documents, receive updates, and manage future requests from one place.</p>'
                : '<p class="nri-success-account">You can track this request any time from your account dashboard.</p>') +
            (pendingCount ? '<p id="nri-submit-bg-note" class="nri-success-note nri-note-pending">⏳ ' + pendingCount + ' document(s) still uploading in the background — you can leave this page, they will finish and attach automatically.</p>' : '') +
            (erroredCount ? '<p class="nri-success-note nri-note-error">⚠️ ' + erroredCount + ' document(s) could not be uploaded and were skipped. You can add them from your dashboard.</p>' : '') +
            '<div class="nri-success-actions">' +
            '<a href="' + esc(data.redirect) + '" class="nri-btn nri-btn-primary" id="nri-success-go-dashboard">Go to My Account</a> ' +
            // .nri-btn-outline (not .nri-btn-secondary — that class is a
            // SEPARATE dark-navy/white-text button used elsewhere on the
            // site; reusing its name here previously caused a CSS
            // specificity fight that left this button's text invisible).
            '<a href="' + esc(data.redirect) + '?request=' + esc(data.request_id) + '" class="nri-btn nri-btn-outline">View Request Details</a>' +
            '</div>' +
            (autoRedirect ? '<p class="nri-success-redirect" id="nri-success-countdown">Redirecting you to your account in ' + secondsLeft + '…</p>' : '') +
            '</div>';
        $f.after(html);
        var $card = $f.closest('.nri-sl-card, .nri-wizard-wrap');
        if ($card.length) $card[0].scrollIntoView({ behavior: 'smooth', block: 'start' });

        if (autoRedirect) {
            var timer = setInterval(function () {
                secondsLeft--;
                var $cd = $('#nri-success-countdown');
                if (!$cd.length) { clearInterval(timer); return; }
                if (secondsLeft <= 0) {
                    clearInterval(timer);
                    window.location.href = data.redirect;
                    return;
                }
                $cd.text('Redirecting you to your account in ' + secondsLeft + '…');
            }, 1000);
            $(document).on('click', '#nri-success-go-dashboard', function () { clearInterval(timer); });
        }
    }

    /* ═══════════════════════════════════════════════════════════
       CLIENT DASHBOARD — New Service Request Modal
    ═══════════════════════════════════════════════════════════ */
    function openSrModal() {
        $('#nri-sr-modal').css('display','flex');
        $('body').addClass('nri-no-scroll');
        $('#nri-sr-step1').show(); $('#nri-sr-step2').hide();
        var $cat = $('#nri-sr-cat');
        if ($cat.find('option').length <= 1) {
            $.post(NRI.ajax_url,{action:'nri_get_request_types',nonce:NRI.nonce},function(r){
                if(!r.success)return;
                var h='<option value="">-- Select Category --</option>';
                $.each(r.data,function(i,t){h+='<option value="'+t.id+'" data-name="'+esc(t.name)+'">'+esc(t.icon)+' '+esc(t.name)+'</option>';});
                $cat.html(h);
            });
        }
    }
    function closeSrModal() { $('#nri-sr-modal').css('display','none'); $('body').removeClass('nri-no-scroll'); }

    $(document).on('click', '#nri-new-sr-btn, #nri-new-sr-btn2', openSrModal);
    $(document).on('click', '#nri-sr-modal', function(e){if($(e.target).is('#nri-sr-modal'))closeSrModal();});
    // Close button handled inline in PHP (onclick="...")

    $(document).on('click', '#nri-sr-proceed', function(){
        var $cat=$('#nri-sr-cat'), catId=$cat.val(), catName=$cat.find('option:selected').data('name')||$cat.find('option:selected').text();
        if(!catId){alert('Please select a category.');return;}
        $('#nri-sr-cat-name').text(catName);
        $('#nri-sr-tid').val(catId);
        $('#nri-sr-tname').val(catName);
        $('#nri-sr-step1').hide(); $('#nri-sr-step2').show();
    });
    $(document).on('click', '#nri-sr-back', function(){ $('#nri-sr-step2').hide(); $('#nri-sr-step1').show(); });

    $(document).on('change', '#nri-sr-file', function(){
        var names=[]; for(var i=0;i<this.files.length;i++) names.push(this.files[i].name);
        $('#nri-sr-file-names').text(names.join(', '));
    });

    $(document).on('submit', '#nri-sr-form', function(e){
        e.preventDefault();
        var $f=$(this),$btn=$f.find('[type=submit]'),$err=$('#nri-sr-err');
        $btn.text('Submitting…').prop('disabled',true); $err.hide();
        var fd=new FormData($f[0]);
        fd.append('action','nri_submit_ticket'); fd.append('nonce',NRI.nonce);
        var files=document.getElementById('nri-sr-file');
        if(files&&files.files.length){for(var i=0;i<files.files.length;i++)fd.append('files[]',files.files[i]);}
        $.ajax({url:NRI.ajax_url,type:'POST',data:fd,processData:false,contentType:false,
            success:function(r){$btn.text('Submit').prop('disabled',false);if(r.success){closeSrModal();location.reload();}else{$err.text(r.data&&r.data.message?r.data.message:'Submission failed.').show();}},
            error:function(){$btn.text('Submit').prop('disabled',false);$err.text('Connection error.').show();}
        });
    });

    /* ═══════════════════════════════════════════════════════════
       REQUEST DETAIL — Tab switching
    ═══════════════════════════════════════════════════════════ */
    $(document).on('click', '.nri-ot', function(){
        var t=$(this).data('ot');
        $('.nri-ot').removeClass('active'); $(this).addClass('active');
        $('.nri-ot-pane').hide(); $('#nri-ot-'+t).show();
        if(t==='tickets') loadTicketTypes();
    });

    // Document section collapse
    $(document).on('click', '.nri-doc-section-btn', function(){
        var ds=$(this).data('ds'), $body=$('#nri-ds-'+ds);
        var open=$(this).hasClass('nri-ds-open');
        if(open){$body.hide();$(this).removeClass('nri-ds-open');$(this).find('.nri-ds-arrow').text('▾');}
        else{$body.show();$(this).addClass('nri-ds-open');$(this).find('.nri-ds-arrow').text('▴');}
    });

    /* ═══════════════════════════════════════════════════════════
       DOCUMENT UPLOAD
    ═══════════════════════════════════════════════════════════ */
    function nriShowUpload(type, rid) {
        $('#nri-upload-is-provider').val(type==='provider'?1:0);
        $('#nri-upload-rid').val(rid);
        var $area=$('#nri-upload-area');
        if($area.is(':visible')&&$area.data('type')===type){$area.hide();return;}
        $area.data('type',type).show();
        $('html,body').animate({scrollTop:$area.offset().top-20},200);
    }
    window.nriShowUpload = nriShowUpload; // expose for inline onclick

    $(document).on('dragover','#nri-upload-drop',function(e){e.preventDefault();$(this).css({borderColor:'#2563eb',background:'#eff6ff'});});
    $(document).on('dragleave','#nri-upload-drop',function(){$(this).css({borderColor:'',background:''});});
    $(document).on('drop','#nri-upload-drop',function(e){e.preventDefault();$(this).css({borderColor:'',background:''});var f=e.originalEvent.dataTransfer.files[0];if(f)doUpload(f);});
    $(document).on('change','#nri-doc-file',function(){if(this.files[0])doUpload(this.files[0]);});

    $(document).on('click','#nri-do-upload',function(){
        var f=document.getElementById('nri-doc-file').files[0];
        if(!f){alert('Please select a file.');return;}
        doUpload(f);
    });

    function doUpload(file){
        var rid=$('#nri-upload-rid').val(), isProv=$('#nri-upload-is-provider').val();
        if(file.size>10*1024*1024){alert('File exceeds 10MB.');return;}
        if(['application/pdf','image/jpeg','image/png'].indexOf(file.type)===-1){alert('Only PDF/JPG/PNG allowed.');return;}
        var fd=new FormData();
        fd.append('action','nri_upload_document'); fd.append('nonce',NRI.upload_nonce||NRI.nonce);
        fd.append('request_id',rid); fd.append('file',file);
        fd.append('doc_type',$('#nri-doc-type').val()||'Document'); fd.append('is_provider',isProv);
        $('#nri-upload-progress').show(); $('#nri-prog-fill').css('width','0%');
        $.ajax({url:NRI.ajax_url,type:'POST',data:fd,processData:false,contentType:false,
            xhr:function(){var x=new XMLHttpRequest();x.upload.addEventListener('progress',function(e){if(e.lengthComputable)$('#nri-prog-fill').css('width',Math.round(e.loaded/e.total*100)+'%');});return x;},
            success:function(r){$('#nri-upload-progress').hide();if(r.success){alert('Uploaded successfully!');location.reload();}else{alert(r.data&&r.data.message?r.data.message:'Upload failed.');}},
            error:function(){$('#nri-upload-progress').hide();alert('Upload error. Try again.');}
        });
    }

    $(document).on('click','.nri-del-doc',function(){
        if(!confirm('Delete this document?'))return;
        var rid=$(this).data('rid'), att=$(this).data('att');
        nriPost('nri_delete_document',{request_id:rid,attachment_id:att},function(){location.reload();},alert);
    });


    /* MESSAGING SYSTEM
       Send      = save to chat only (no email)
       Send via Email = save to chat + email other party
       Both parties see messages updated every 4 seconds.
       Full list refresh — no pointer/deduplication complexity.
    */
    var _pollRid   = 0;
    var _pollTimer = null;

    function _buildBubble(m) {
        var cls      = m.is_mine ? 'nri-msg-mine' : '';
        var labelCol = m.is_mine ? 'inherit' : '#475569';
        var badge    = m.is_email_sent ? ' <span class="nri-email-sent-badge">&#9993; Sent</span>' : '';
        var delBtn   = m.can_delete ? '<button class="nri-del-msg nri-btn-icon" data-id="'+m.id+'" title="Delete">&#128465;</button>' : '';
        return '<div class="nri-msg-item '+cls+'" id="nrimsg-'+m.id+'" data-mid="'+m.id+'">'
            +'<div class="nri-msg-meta-top">'
            +'<span style="font-weight:600;color:'+labelCol+';">'+esc(m.label)+'</span>'
            +'<span style="color:#94a3b8;font-size:11px;margin-left:6px;">'+esc(m.time)+'</span>'
            +badge+' '+delBtn
            +'</div>'
            +'<div class="nri-msg-bubble">'+esc(m.message).replace(/\n/g,'<br>')+'</div>'
            +'</div>';
    }

    function _refreshMsgList(rid, scrollToBottom) {
        $.post(NRI.ajax_url, {
            action:     'nri_get_messages_since',
            nonce:      NRI.nonce,
            request_id: rid,
            since_id:   0
        }, function(r) {
            var $list = $('#nri-msgs-list');
            if (!$list.length) return;
            if (!r || !r.success) {
                console.error('[NRI Messages] Refresh failed:', r);
                return;
            }
            var msgs = r.data.messages || [];
            if (msgs.length === 0) {
                if (!$list.find('.nri-msg-item').length) {
                    $list.html('<p class="nri-hint" style="text-align:center;padding:20px;color:#94a3b8;">No messages yet. Send a message below.</p>');
                }
                return;
            }
            var html = '';
            $.each(msgs, function(i, m) { html += _buildBubble(m); });
            $list.html(html);
            if (scrollToBottom !== false) {
                $list.scrollTop($list[0].scrollHeight);
            }
        }).fail(function(xhr) {
            console.error('[NRI Messages] AJAX error:', xhr.status, xhr.responseText);
        });
    }

    function _startPoll(rid) {
        if (_pollTimer) { clearInterval(_pollTimer); _pollTimer = null; }
        _pollRid = rid;
        if (!_pollRid) return;
        // Refresh every 4 seconds
        _pollTimer = setInterval(function() {
            _refreshMsgList(_pollRid, true);
        }, 4000);
    }

    $(document).ready(function(){
        var rid = parseInt($('#nri-msg-rid').val()) || 0;
        if (rid) {
            _startPoll(rid);
        }
        // Auto-scroll on load
        var $m = $('#nri-msgs-list');
        if ($m.length) { $m.scrollTop($m[0].scrollHeight); }
    });

    function sendMsg(sendEmail) {
        var msg = $('#nri-msg-text').val().trim();
        var rid = parseInt($('#nri-msg-rid').val()) || 0;
        if (!msg) { alert('Please type a message.'); return; }
        if (!rid)  { alert('Request ID missing.'); return; }
        var $btn     = sendEmail ? $('#nri-send-msg-email') : $('#nri-send-msg');
        var origText = $btn.text();
        $btn.prop('disabled', true).text('Sending...');
        $('#nri-send-msg,#nri-send-msg-email').prop('disabled', true);

        $.post(NRI.ajax_url, {
            action:     'nri_send_message',
            nonce:      NRI.nonce,
            request_id: rid,
            message:    msg,
            send_email: sendEmail ? 1 : 0
        }, function(r) {
            $('#nri-send-msg,#nri-send-msg-email').prop('disabled', false);
            $btn.text(origText);
            if (r.success) {
                $('#nri-msg-text').val('');
                // Immediately refresh the full list so both the sender's bubble
                // appears and any messages from the other party are visible
                _refreshMsgList(rid, true);
            } else {
                alert(r.data && r.data.message ? r.data.message : 'Send failed. Please try again.');
            }
        }).fail(function() {
            $('#nri-send-msg,#nri-send-msg-email').prop('disabled', false);
            $btn.text(origText);
            alert('Connection error. Please try again.');
        });
    }

    $(document).on('click','#nri-send-msg',       function(){ sendMsg(false); });
    $(document).on('click','#nri-send-msg-email',  function(){ sendMsg(true);  });

    // Manual refresh button
    $(document).on('click','#nri-refresh-msgs', function(){
        var rid = parseInt($(this).data('rid') || $('#nri-msg-rid').val()) || 0;
        if (!rid) return;
        $(this).text('Loading...');
        var $self = $(this);
        _refreshMsgList(rid, true);
        setTimeout(function(){ $self.html('&#8635; Refresh'); }, 1500);
    });


    $(document).on('click','.nri-del-msg',function(){
        if(!confirm('Delete this message?'))return;
        nriPost('nri_delete_message',{id:$(this).data('id')},function(){$(this).closest('.nri-msg-item').remove();}.bind(this),alert);
    });

    // Auto-scroll messages on load
    $(document).ready(function(){
        var $m=$('#nri-msgs-list');
        if($m.length) $m.scrollTop($m[0].scrollHeight);
    });

    /* ═══════════════════════════════════════════════════════════
       SERVICE REQUESTS (TICKETS) on request detail
    ═══════════════════════════════════════════════════════════ */
    function loadTicketTypes(){
        var $cat=$('#nri-ticket-cat');
        if($cat.find('option').length>1)return;
        $.post(NRI.ajax_url,{action:'nri_get_request_types',nonce:NRI.nonce},function(r){
            if(!r.success)return;
            var h='<option value="">-- Select Category --</option>';
            $.each(r.data,function(i,t){h+='<option value="'+t.id+'" data-name="'+esc(t.name)+'">'+esc(t.icon)+' '+esc(t.name)+'</option>';});
            $cat.html(h);
        });
    }

    $(document).on('click','#nri-new-ticket-btn',function(){
        loadTicketTypes();
        $('#nri-ticket-modal').css('display','flex'); $('body').addClass('nri-no-scroll');
    });
    $(document).on('click','#nri-ticket-modal-close',function(){$('#nri-ticket-modal').css('display','none');$('body').removeClass('nri-no-scroll');});
    $(document).on('click','#nri-ticket-modal',function(e){if($(e.target).is('#nri-ticket-modal')){$('#nri-ticket-modal').css('display','none');$('body').removeClass('nri-no-scroll');}});

    $(document).on('click','#nri-do-ticket',function(){
        var rid=$(this).data('rid');
        var $cat=$('#nri-ticket-cat'), tid=$cat.val(), tname=$cat.find('option:selected').data('name')||$cat.find('option:selected').text();
        var notes=$('#nri-ticket-notes').val();
        var email=$('#nri-ticket-email').val();
        if(!tid){alert('Please select a category.');return;}
        $(this).text('Submitting…').prop('disabled',true);
        var self=$(this);
        $.post(NRI.ajax_url,{action:'nri_submit_ticket',nonce:NRI.nonce,request_id:rid,type_id:tid,category:tname,notes:notes,email:email},
            function(r){self.text('Submit').prop('disabled',false);if(r.success){$('#nri-ticket-modal').css('display','none');$('body').removeClass('nri-no-scroll');location.reload();}else{$('#nri-ticket-err').text(r.data&&r.data.message?r.data.message:'Failed.').show();}},
            function(){self.text('Submit').prop('disabled',false);$('#nri-ticket-err').text('Connection error.').show();}
        );
    });

    // Ticket search filter
    $(document).on('input','#nri-ticket-search',function(){
        var q=$(this).val().toLowerCase();
        $('#nri-tickets-tbl tbody tr.nri-ticket-row').each(function(){$(this).toggle($(this).text().toLowerCase().indexOf(q)!==-1);});
    });

    $(document).on('change','.nri-ticket-status-sel',function(){
        nriPost('nri_update_ticket_status',{id:$(this).data('id'),status:$(this).val()},null,alert);
    });
    $(document).on('click','.nri-del-ticket',function(){
        if(!confirm('Delete this ticket?'))return;
        nriPost('nri_delete_ticket',{id:$(this).data('id')},function(){location.reload();},alert);
    });

    /* ═══════════════════════════════════════════════════════════
       STAFF CONTROLS on request detail
    ═══════════════════════════════════════════════════════════ */
    // Staff panel toggle
    $(document).on('click','#nri-staff-toggle',function(){
        $('#nri-staff-body').slideToggle(200);
    });

    // Timeline mode toggle
    $(document).on('click','.nri-tlt',function(){
        var mode=$(this).data('tl');
        $(this).closest('.nri-tl-toggle').find('.nri-tlt').removeClass('active');
        $(this).addClass('active');
        $('#nri-tl-days-wrap').toggle(mode==='days'); $('#nri-tl-date-wrap').toggle(mode==='date');
    });

    // Update status
    $(document).on('click','#nri-do-status',function(){
        var rid=$(this).data('rid'), $b=$(this);
        $b.text('Saving…').prop('disabled',true);
        nriPost('nri_update_status',{request_id:rid,status:$('#nri-status-sel').val(),note:$('#nri-status-note').val()},
            function(){$b.text('Update Status').prop('disabled',false);location.reload();},
            function(msg){$b.text('Update Status').prop('disabled',false);alert(msg);}
        );
    });

    // Set timeline
    $(document).on('click','#nri-do-timeline',function(){
        var rid=$(this).data('rid'), $b=$(this);
        var mode=$('.nri-tlt.active').data('tl')||'days';
        var payload={request_id:rid,mode:mode,note:$('#nri-tl-note').val()};
        if(mode==='days'){payload.days=$('#nri-tl-days').val();if(!payload.days||parseInt(payload.days)<1){alert('Enter number of days.');return;}}
        else{payload.date=$('#nri-tl-date').val();if(!payload.date){alert('Select a date.');return;}}
        $b.text('Saving…').prop('disabled',true);
        nriPost('nri_set_timeline',payload,function(){$b.text('Set Timeline').prop('disabled',false);location.reload();},function(msg){$b.text('Set Timeline').prop('disabled',false);alert(msg);});
    });

    // ── Save service charges (quote amount) — updates live total display ──────
    $(document).on('click','#nri-do-quote',function(){
        var $btn=$(this), rid=$btn.data('rid');
        var amt=parseFloat($('#nri-quote-amt').val())||0;
        $btn.text('Saving…').prop('disabled',true);
        nriPost('nri_set_quote',{request_id:rid,amount:amt,send_quote_email:0,include_terms:0},
            function(){
                $btn.text('Saved ✓').prop('disabled',false);
                setTimeout(function(){$btn.text('Save');},2000);
                nriRefreshQuoteTotal();
            },
            function(msg){$btn.text('Save').prop('disabled',false);alert('Error: '+msg);}
        );
    });

    // ── Save shipping charges — updates live total display ───────────────────
    $(document).on('click','#nri-do-shipping',function(){
        var $btn=$(this), rid=$btn.data('rid');
        var amount=parseFloat($('#nri-shipping-amt').val())||0;
        var type=$('#nri-shipping-type').val();
        $btn.text('Saving…').prop('disabled',true);
        $.post(NRI.ajax_url,{action:'nri_set_shipping',nonce:NRI.admin_nonce,request_id:rid,amount:amount,type:type},function(r){
            $btn.text('Saved ✓').prop('disabled',false);
            setTimeout(function(){$btn.text('Save');},2000);
            if(r.success){ nriRefreshQuoteTotal(); }
            else { alert('Error: '+(r.data&&r.data.message?r.data.message:'Unknown error')); }
        }).fail(function(){ $btn.text('Save').prop('disabled',false); alert('Network error'); });
    });

    // ── Live total refresh ────────────────────────────────────────────────────
    function nriRefreshQuoteTotal(){
        var svc  = parseFloat($('#nri-quote-amt').val())    || 0;
        var ship = parseFloat($('#nri-shipping-amt').val()) || 0;
        var total = svc + ship;
        var fmt  = function(n){ return n.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2}); };
        if(total > 0){
            $('#nri-quote-total-val').text('₹'+fmt(total));
            $('#nri-quote-total-breakdown').text('Service ₹'+fmt(svc)+' + Shipping ₹'+fmt(ship));
            $('#nri-quote-total-box').show();
        } else {
            $('#nri-quote-total-box').hide();
        }
    }

    // ── Dedicated "Send Quotation Email" button ───────────────────────────────
    $(document).on('click','#nri-send-quote-btn',function(){
        var $btn=$(this), rid=$btn.data('rid');
        var inclTerms=$('#nri-include-terms').is(':checked')?1:0;
        var svc  = parseFloat($('#nri-quote-amt').val())    || 0;
        var ship = parseFloat($('#nri-shipping-amt').val()) || 0;
        if(svc <= 0 && ship <= 0){
            alert('Please set at least one charge amount before sending the quotation email.');
            return;
        }
        if(!confirm('Send the quotation email to the client now?')) return;
        $btn.text('Sending…').prop('disabled',true);
        var $msg=$('#nri-quote-email-msg');
        // First save current amounts, then send email
        nriPost('nri_set_quote',{request_id:rid,amount:svc,send_quote_email:1,include_terms:inclTerms,notify_vendor:0},
            function(r){
                $btn.text('📧 Send Quotation Email to Client').prop('disabled',false);
                $msg.css({display:'block',color:'#16a34a',background:'#f0fdf4',padding:'6px 10px',borderRadius:'6px'})
                    .text('✓ Quotation email sent successfully!');
                nriRefreshQuoteTotal();
                setTimeout(function(){$msg.fadeOut(function(){$msg.hide().css('display','none');});},5000);
            },
            function(msg){
                $btn.text('📧 Send Quotation Email to Client').prop('disabled',false);
                $msg.css({display:'block',color:'#dc2626',background:'#fef2f2',padding:'6px 10px',borderRadius:'6px'})
                    .text('✗ '+msg);
            }
        );
    });

    // Set secondary status
    $(document).on('click','#nri-do-sec-status',function(){
        var rid=$(this).data('rid'), val=$('#nri-sec-status').val();
        nriPost('nri_set_secondary_status',{request_id:rid,value:val},function(){alert('Saved.');},alert);
    });

    // Assign manager — explicit Save button
    $(document).on('click','#nri-do-assign-mgr',function(){
        var rid=$(this).data('rid'), uid=$('#nri-assign-mgr').val(), $b=$(this);
        if(!uid){alert('Please select a manager.');return;}
        $b.text('Saving…').prop('disabled',true);
        nriPost('nri_assign_staff',{request_id:rid,type:'manager',user_id:uid},function(res){
            $b.text('Saved ✓').prop('disabled',false);
            if(res.data && res.data.name) $('#nri-mgr-current').html('Currently assigned: <strong>'+res.data.name+'</strong>');
            setTimeout(function(){$b.text('Save Manager');},2000);
        },function(){$b.text('Save Manager').prop('disabled',false);alert('Error saving manager.');});
    });

    // Assign vendor — explicit Save button, handles both vp_ (vendor table) and wp_ (WP user)
    $(document).on('click','#nri-do-assign-vendor',function(){
        var rid=$(this).data('rid'), raw=$('#nri-assign-vendor').val(), $b=$(this);
        var $msg=$('#nri-assign-msg');
        if(!raw){alert('Please select a vendor.');return;}
        var type='vendor', uid=raw;
        // Parse prefix: vp_ = vendor profile ID, wp_ = WP user ID
        var actual_uid=raw;
        if(raw.indexOf('vp_')===0) actual_uid=raw.substring(3);
        else if(raw.indexOf('wp_')===0) actual_uid=raw.substring(3);
        $b.text('Saving…').prop('disabled',true);
        $msg.hide();
        nriPost('nri_assign_staff',{request_id:rid,type:'vendor',user_id:actual_uid,id_type:raw.indexOf('vp_')===0?'vendor_profile':'wp_user'},function(res){
            $b.text('Save Vendor').prop('disabled',false);
            var name=res.data && res.data.name ? res.data.name : 'Vendor';
            $('#nri-vendor-current').html('Currently assigned: <strong>'+name+'</strong>');
            $msg.css({'background':'#d1fae5','color':'#065f46','display':'block'}).text('✅ Vendor saved! WhatsApp notification sent.');
            setTimeout(function(){$msg.hide();},4000);
        },function(){$b.text('Save Vendor').prop('disabled',false);$msg.css({'background':'#fee2e2','color':'#991b1b','display':'block'}).text('Error saving vendor.');});
    });

    // Save internal note
    $(document).on('click','#nri-do-save-note',function(){
        var rid=$(this).data('rid'), $b=$(this);
        $b.text('Saving…').prop('disabled',true);
        nriPost('nri_save_note',{request_id:rid,note:$('#nri-int-notes').val()},
            function(){$b.text('Saved ✓').prop('disabled',false);setTimeout(function(){$b.text('Save Note');},2000);},
            function(msg){$b.text('Save Note').prop('disabled',false);alert(msg);}
        );
    });

    /* ═══════════════════════════════════════════════════════════
       ADMIN: FORM FIELDS TAB
    ═══════════════════════════════════════════════════════════ */
    $(document).on('click','#nri-add-field-btn',function(){
        // Reset form
        $('#nf-id,#nf-key').val(''); $('#nf-label,#nf-placeholder,#nf-opts,#nf-description').val('');
        $('#nf-type').val('text'); $('#nf-step').val('1'); $('#nf-required').val('0');
        $('#nf-opts-wrap').hide(); $('#nri-field-msg').hide();
        // Reset conditional logic
        $('#nf-cond-enabled').prop('checked', false); $('#nf-cond-panel').hide();
        $('#nf-cond-action').val('all'); $('#nf-cond-rules').empty();
        $('#nri-add-field-panel').slideToggle(200);
    });
    $(document).on('click','#nri-cancel-field',function(){$('#nri-add-field-panel').slideUp(200);});

    $(document).on('change','#nf-type',function(){
        $('#nf-opts-wrap').toggle(['dropdown','radio','searchable'].indexOf($(this).val())!==-1);
    });
    // FIX 8: number field is handled like text in render, just needs correct HTML type
    $(document).on('input','#nf-label',function(){
        if(!$('#nf-id').val()) $('#nf-key').val($(this).val().toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,''));
    });

    // Toggle conditional logic panel - use click on the label too for safety
    $(document).on('change click','#nf-cond-enabled',function(e){
        if(e.type==='click' && $(this).is(':checkbox')) return; // let change handle it
        var checked = $(this).is(':checked');
        if(checked){
            $('#nf-cond-panel').slideDown(200);
            if(!$('#nf-cond-rules .nri-cond-row').length) nriAddCondRule();
        } else {
            $('#nf-cond-panel').slideUp(200);
        }
    });

    // Build one condition rule row
    function nriAllFieldOptions() {
        var opts = '<option value="">-- select field --</option>';
        var seen = {};

        // PRIMARY: Use the embedded JS map (always available when fields tab is open)
        var fieldMap = window.NRI_FIELD_MAP || {};
        Object.keys(fieldMap).forEach(function(key) {
            if (!seen[key]) {
                seen[key] = true;
                var label = fieldMap[key].label || key;
                opts += '<option value="' + key + '">' + label + ' [' + key + ']</option>';
            }
        });

        // FALLBACK: scan the rendered fields table rows
        if (Object.keys(seen).length === 0) {
            $('#nri-fields-tbody tr').each(function(){
                var $btn  = $(this).find('.nri-edit-field');
                var key   = $btn.data('key')   || $btn.attr('data-key');
                var label = $btn.data('label') || $btn.attr('data-label') || key;
                if (key && !seen[key]) {
                    seen[key] = true;
                    opts += '<option value="' + key + '">' + label + ' [' + key + ']</option>';
                }
            });
        }
        return opts;
    }

    function nriOperatorOptions() {
        return '<option value="equals">is equal to</option>'
             + '<option value="not_equals">is not equal to</option>'
             + '<option value="contains">contains</option>'
             + '<option value="not_contains">does not contain</option>'
             + '<option value="starts_with">starts with</option>'
             + '<option value="ends_with">ends with</option>'
             + '<option value="is_empty">is empty</option>'
             + '<option value="is_not_empty">is not empty</option>'
             + '<option value="greater_than">greater than</option>'
             + '<option value="less_than">less than</option>';
    }

    function nriAddCondRule(rule) {
        rule = rule || {};
        var row = '<div class="nri-cond-row" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:10px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;">'
            + '<select class="nri-cr-field" style="padding:6px 10px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;min-width:160px;">'+nriAllFieldOptions()+'</select>'
            + '<select class="nri-cr-op" style="padding:6px 10px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;">'+nriOperatorOptions()+'</select>'
            + '<span class="nri-cr-val-wrap" style="flex:1;min-width:120px;"><input class="nri-cr-val" type="text" placeholder="Enter value..." style="width:100%;padding:6px 10px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;"></span>'
            + '<button type="button" class="nri-btn nri-btn-danger nri-btn-sm nri-cr-del" style="flex-shrink:0;">&#10005;</button>'
            + '</div>';
        var $row = $(row);

        // Helper: update value input based on selected field
        function updateValueField(fieldKey, existingValue) {
            var $wrap = $row.find('.nri-cr-val-wrap');
            var $op   = $row.find('.nri-cr-op');
            if (!fieldKey) { return; }
            if (['is_empty','is_not_empty'].indexOf($op.val()) !== -1) { return; }

            // Use the embedded field map (no AJAX needed - always available)
            var fieldMap = window.NRI_FIELD_MAP || {};
            var fieldData = fieldMap[fieldKey];

            if (fieldData && fieldData.options && fieldData.options.length > 0) {
                // Field has predefined options - render a select dropdown
                var sel = '<select class="nri-cr-val" style="width:100%;padding:8px 10px;border:1px solid #bfdbfe;border-radius:6px;font-size:13px;background:#fff;">';
                sel += '<option value="">-- Select value --</option>';
                fieldData.options.forEach(function(opt) {
                    var selected = (existingValue && existingValue === opt) ? ' selected' : '';
                    sel += '<option value="' + opt + '"' + selected + '>' + opt + '</option>';
                });
                sel += '</select>';
                $wrap.html(sel);
            } else {
                // No predefined options - text input
                var current = $wrap.find('.nri-cr-val').val() || existingValue || '';
                $wrap.html('<input class="nri-cr-val" type="text" placeholder="Enter value..." style="width:100%;padding:8px 10px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;" value="' + current + '">');
            }
        }

        // Set initial values
        if (rule.field) { $row.find('.nri-cr-field').val(rule.field); }
        if (rule.operator) { $row.find('.nri-cr-op').val(rule.operator); }

        // Load options for the pre-selected field (when editing an existing rule)
        if (rule.field) {
            updateValueField(rule.field, rule.value || '');
        } else if (rule.value) {
            $row.find('.nri-cr-val').val(rule.value);
        }

        // When field selector changes → fetch options for newly chosen field
        $row.find('.nri-cr-field').on('change', function() {
            updateValueField($(this).val(), '');
        });

        // When operator changes → hide/show value field
        $row.find('.nri-cr-op').on('change', function() {
            var hide = ['is_empty','is_not_empty'].indexOf($(this).val()) !== -1;
            $row.find('.nri-cr-val-wrap').toggle(!hide);
        }).trigger('change');

        $('#nf-cond-rules').append($row);
    }

    $(document).on('click','#nf-cond-add-rule',function(){ nriAddCondRule(); });
    $(document).on('click','.nri-cr-del',function(){ $(this).closest('.nri-cond-row').remove(); });

    function nriGetConditions() {
        if(!$('#nf-cond-enabled').is(':checked')) return null;
        var rules = [];
        $('#nf-cond-rules .nri-cond-row').each(function(){
            var field = $(this).find('.nri-cr-field').val();
            var op    = $(this).find('.nri-cr-op').val();
            var val   = $(this).find('.nri-cr-val').val().trim();
            if(field) rules.push({field:field, operator:op, value:val});
        });
        if(!rules.length) return null;
        return {action: $('#nf-cond-action').val(), rules: rules};
    }

    $(document).on('click','.nri-edit-field',function(){
        var $b=$(this);
        $('#nf-id').val($b.data('id'));
        $('#nf-label').val($b.data('label'));
        $('#nf-key').val($b.data('key'));
        $('#nf-type').val($b.data('type'));
        $('#nf-step').val($b.data('step'));
        $('#nf-required').val($b.data('required'));
        $('#nf-placeholder').val($b.data('ph'));
        $('#nf-description').val($b.data('desc') || '');
        $('#nf-opts').val($b.data('opts'));
        $('#nf-opts-wrap').toggle(['dropdown','radio','searchable'].indexOf($b.data('type'))!==-1);
        $('#nri-field-msg').hide();
        // Load conditional logic
        $('#nf-cond-rules').empty();
        var condRaw = $b.data('conditions');
        var condData = null;
        if(condRaw) { try { condData = typeof condRaw === 'string' ? JSON.parse(condRaw) : condRaw; } catch(e){} }
        if(condData && condData.rules && condData.rules.length) {
            $('#nf-cond-enabled').prop('checked', true);
            $('#nf-cond-panel').show();
            $('#nf-cond-action').val(condData.action || 'all');
            $.each(condData.rules, function(i, rule){ nriAddCondRule(rule); });
        } else {
            $('#nf-cond-enabled').prop('checked', false);
            $('#nf-cond-panel').hide();
        }
        $('#nri-add-field-panel').slideDown(200);
        $('html,body').animate({scrollTop:$('#nri-add-field-panel').offset().top-20},200);
    });

    $(document).on('click','#nri-do-save-field',function(){
        var $msg=$('#nri-field-msg'), label=$('#nf-label').val().trim(), key=$('#nf-key').val().trim(), id=$('#nf-id').val();
        if(!label){showMsg($msg,'error','Label is required.');return;}
        if(!key&&!id){showMsg($msg,'error','Key is required.');return;}
        $msg.hide();
        var conditions = nriGetConditions();
        var data={label:label,key:key,type:$('#nf-type').val(),step:$('#nf-step').val(),required:$('#nf-required').val(),
                  options:$('#nf-opts').val(),placeholder:$('#nf-placeholder').val(),
                  description:$('#nf-description').val(),active:1,
                  conditions: conditions ? JSON.stringify(conditions) : ''};
        if(id)data.id=id;
        nriPost('nri_save_field',data,
            function(){showMsg($msg,'success','Saved! Reloading…');setTimeout(function(){location.reload();},1500);},
            function(msg){showMsg($msg,'error',msg);}
        );
    });

    $(document).on('click','.nri-del-field',function(){
        if(!confirm('Delete this field permanently?'))return;
        nriPost('nri_delete_field',{id:$(this).data('id')},function(){location.reload();},alert);
    });

    /* ═══════════════════════════════════════════════════════════
       ADMIN: DROPDOWN DATA TAB  (full CRUD with pagination)
    ═══════════════════════════════════════════════════════════ */
    var _ddKey='', _ddPage=1, _ddSearch='';

    $(document).on('change','#nri-dd-fkey',function(){
        _ddKey=$(this).val(); _ddPage=1; _ddSearch=''; $('#nri-dd-search').val('');
        if(!_ddKey){$('#nri-dd-table-wrap,#nri-dd-form,#nri-dd-empty').hide();$('#nri-dd-btns').css('display','none');return;}
        $('#nri-dd-btns').css('display','flex'); $('#nri-dd-form').hide();
        loadDdOptions();
    });
    $(document).on('input','#nri-dd-search',function(){
        _ddSearch=$(this).val(); _ddPage=1;
        clearTimeout(window._ddSt); window._ddSt=setTimeout(loadDdOptions,300);
    });

    function loadDdOptions(){
        $('#nri-dd-table-wrap').show(); $('#nri-dd-empty').hide();
        var $body=$('#nri-dd-tbody');
        $body.html('<tr><td colspan="4" class="nri-tbl-loading">Loading…</td></tr>');
        nriPost('nri_get_options_paged',{field_key:_ddKey,search:_ddSearch,page:_ddPage},function(d){
            if(!d.rows||!d.rows.length){
                $body.html('<tr><td colspan="4" class="nri-tbl-empty">No options found.</td></tr>');
                $('#nri-dd-pages').html(''); return;
            }
            var rows='';
            $.each(d.rows,function(i,o){
                rows+='<tr data-id="'+o.id+'">'
                    +'<td><input type="checkbox" class="nri-dd-cb" value="'+o.id+'"></td>'
                    +'<td style="color:#94a3b8;font-size:12px;">'+((_ddPage-1)*50+i+1)+'</td>'
                    +'<td>'+esc(o.option_value)+'</td>'
                    +'<td><button class="nri-btn nri-btn-sm nri-btn-outline nri-dd-edit" data-id="'+o.id+'" data-val="'+esc(o.option_value)+'">Edit</button> '
                    +'<button class="nri-btn nri-btn-sm nri-btn-danger nri-dd-del" data-id="'+o.id+'">Del</button></td>'
                    +'</tr>';
            });
            $body.html(rows);
            // Pagination
            var pg='<span style="font-size:13px;color:#64748b;margin-right:8px;">'+d.total+' total</span>';
            for(var p=1;p<=d.pages;p++) pg+='<button class="nri-btn nri-btn-sm '+(p===_ddPage?'nri-btn-primary':'nri-btn-ghost')+' nri-dd-go-pg" data-p="'+p+'">'+p+'</button> ';
            $('#nri-dd-pages').html(pg);
            updateDdBulkCount();
        },function(msg){$body.html('<tr><td colspan="4" class="nri-tbl-empty">Error: '+esc(msg)+'</td></tr>');});
    }

    $(document).on('click','.nri-dd-go-pg',function(){_ddPage=parseInt($(this).data('p'));loadDdOptions();});

    // Select all
    $(document).on('change','#nri-dd-all',function(){$('.nri-dd-cb').prop('checked',$(this).is(':checked'));updateDdBulkCount();});
    $(document).on('change','.nri-dd-cb',updateDdBulkCount);
    function updateDdBulkCount(){
        var n=$('.nri-dd-cb:checked').length;
        $('#nri-dd-sel-count').text(n>0?n+' selected':'');
        $('#nri-dd-bulk-del').toggle(n>0);
    }

    // Add button
    $(document).on('click','#nri-dd-add-btn',function(){
        $('#nri-dd-edit-id').val(''); $('#nri-dd-val').val('');
        $('#nri-dd-form-title').text('Add Option'); $('#nri-dd-form-msg').hide();
        $('#nri-dd-form').slideDown(200); $('#nri-dd-val').focus();
    });
    $(document).on('click','#nri-dd-cancel',function(){$('#nri-dd-form').slideUp(200);});

    // Save option
    $(document).on('click','#nri-dd-do-save',function(){
        var val=$('#nri-dd-val').val().trim(), editId=$('#nri-dd-edit-id').val(), $msg=$('#nri-dd-form-msg');
        if(!val){showMsg($msg,'error','Value required.');return;}
        $msg.hide();
        var data=editId?{id:editId,value:val}:{field_key:_ddKey,value:val};
        nriPost('nri_save_option',data,
            function(){showMsg($msg,'success',editId?'Updated.':'Added.');$('#nri-dd-val').val('');loadDdOptions();if(editId)setTimeout(function(){$('#nri-dd-form').slideUp(200);},1000);},
            function(msg){showMsg($msg,'error',msg);}
        );
    });

    // Edit button
    $(document).on('click','.nri-dd-edit',function(){
        $('#nri-dd-edit-id').val($(this).data('id'));
        $('#nri-dd-val').val($(this).data('val'));
        $('#nri-dd-form-title').text('Edit Option'); $('#nri-dd-form-msg').hide();
        $('#nri-dd-form').slideDown(200); $('#nri-dd-val').focus();
    });

    // Single delete
    $(document).on('click','.nri-dd-del',function(){
        if(!confirm('Delete this option?'))return;
        nriPost('nri_delete_option',{id:$(this).data('id')},loadDdOptions,alert);
    });

    // Bulk delete
    $(document).on('click','#nri-dd-bulk-del',function(){
        var ids=[]; $('.nri-dd-cb:checked').each(function(){ids.push($(this).val());});
        if(!ids.length)return;
        if(!confirm('Delete '+ids.length+' option(s)?'))return;
        nriPost('nri_bulk_delete_options',{ids:ids},function(){$('#nri-dd-all').prop('checked',false);loadDdOptions();},alert);
    });

    /* ═══════════════════════════════════════════════════════════
       ADMIN: BULK IMPORT TAB
    ═══════════════════════════════════════════════════════════ */
    // Method tabs
    $(document).on('click','.nri-bulk-tab',function(){
        var bt=$(this).data('bt');
        $('.nri-bulk-tab').removeClass('active'); $(this).addClass('active');
        $('.nri-bulk-pane').hide(); $('#nri-bt-'+bt).show();
        $('#nri-bulk-msg').hide();
    });

    // CSV file
    $(document).on('dragover','#nri-csv-drop',function(e){e.preventDefault();$(this).css({borderColor:'#2563eb',background:'#eff6ff'});});
    $(document).on('dragleave','#nri-csv-drop',function(){$(this).css({borderColor:'',background:''});});
    $(document).on('drop','#nri-csv-drop',function(e){e.preventDefault();$(this).css({borderColor:'',background:''});var f=e.originalEvent.dataTransfer.files[0];if(f)previewCsv(f);});
    $(document).on('change','#nri-csv-file',function(){if(this.files[0])previewCsv(this.files[0]);});

    function previewCsv(file){
        $('#nri-do-csv-import').prop('disabled',false);
        if(file.name.match(/\.(csv|txt)$/i)){
            var r=new FileReader(); r.onload=function(e){
                var lines=e.target.result.split(/\r\n|\r|\n/).map(function(l){return l.trim();}).filter(Boolean);
                var $list=$('#nri-csv-prev-list').empty();
                lines.slice(0,5).forEach(function(l){$list.append('<li style="margin-bottom:3px;">'+esc(l)+'</li>');});
                if(lines.length>5)$list.append('<li style="color:#94a3b8;">…and '+(lines.length-5)+' more</li>');
                $('#nri-csv-total').text('Total: '+lines.length+' values');
                $('#nri-csv-preview').show();
            }; r.readAsText(file);
        }
    }

    $(document).on('click','#nri-do-csv-import',function(){
        var key=$('#nri-bulk-fkey').val(), mode=$('#nri-bulk-mode').val(), file=document.getElementById('nri-csv-file').files[0];
        if(!key){alert('Select a target field.');return;} if(!file){alert('Select a CSV file.');return;}
        var $btn=$(this),$msg=$('#nri-bulk-msg'); $btn.text('Importing…').prop('disabled',true); $msg.hide();
        var fd=new FormData(); fd.append('action','nri_bulk_import'); fd.append('nonce',nonce()); fd.append('field_key',key); fd.append('mode',mode); fd.append('csv_file',file);
        $.ajax({url:NRI.ajax_url,type:'POST',data:fd,processData:false,contentType:false,
            success:function(r){$btn.text('Import File').prop('disabled',false);$msg.removeClass('nri-alert-error nri-alert-success').addClass('nri-alert').show();if(r.success)$msg.addClass('nri-alert-success').text('Imported '+r.data.imported+' values ('+r.data.mode+' mode).');else$msg.addClass('nri-alert-error').text(r.data&&r.data.message?r.data.message:'Import failed.');},
            error:function(){$btn.text('Import File').prop('disabled',false);$msg.addClass('nri-alert nri-alert-error').text('Connection error.').show();}
        });
    });

    // Paste format pills
    $(document).on('click','.nri-fp',function(){
        var fmt=$(this).data('fmt');
        $('.nri-fp').removeClass('active'); $(this).addClass('active');
        var ph={lines:'One value per line:\nUniversity of Delhi\nAnna University',comma:'Comma-separated: Value1, Value2, Value3',json:'JSON: ["Value1","Value2","Value3"]'};
        $('#nri-paste-data').attr('placeholder',ph[fmt]||'');
        $('#nri-paste-preview').hide(); $('#nri-do-paste-import').prop('disabled',true);
    });

    $(document).on('click','#nri-parse-paste',function(){
        var raw=$('#nri-paste-data').val().trim(), fmt=$('.nri-fp.active').data('fmt')||'lines', $err=$('#nri-paste-err');
        $err.hide();
        if(!raw){$err.text('Paste some data first.').show();return;}
        var vals=[];
        if(fmt==='json'){try{var a=JSON.parse(raw);if(!Array.isArray(a))throw 0;$.each(a,function(i,v){if(String(v).trim())vals.push(String(v).trim());});}catch(e){$err.text('Invalid JSON. Use format: ["val1","val2"]').show();return;}}
        else if(fmt==='comma'){vals=raw.split(',').map(function(v){return v.trim();}).filter(Boolean);}
        else{vals=raw.split(/\r\n|\r|\n/).map(function(v){return v.trim();}).filter(Boolean);}
        vals=vals.filter(function(v,i,a){return a.indexOf(v)===i;});
        if(!vals.length){$err.text('No valid values found.').show();return;}
        var $list=$('#nri-paste-prev-list').empty();
        vals.slice(0,5).forEach(function(v){$list.append('<div style="padding:2px 0;border-bottom:1px solid #f1f5f9;font-size:13px;">'+esc(v)+'</div>');});
        if(vals.length>5)$list.append('<div style="color:#94a3b8;font-size:12px;margin-top:4px;">…and '+(vals.length-5)+' more</div>');
        $('#nri-paste-count').text(vals.length+' unique values');
        $('#nri-paste-preview').show(); $('#nri-do-paste-import').prop('disabled',false);
    });

    $(document).on('click','#nri-do-paste-import',function(){
        var key=$('#nri-bulk-fkey').val(), mode=$('#nri-bulk-mode').val(), raw=$('#nri-paste-data').val().trim(), fmt=$('.nri-fp.active').data('fmt')||'lines';
        if(!key){alert('Select a target field.');return;} if(!raw){alert('Paste some data first.');return;}
        var $btn=$(this),$msg=$('#nri-bulk-msg'); $btn.text('Importing…').prop('disabled',true); $msg.hide();
        nriPost('nri_bulk_import',{field_key:key,mode:mode,raw_data:raw,format:fmt},
            function(d){$btn.text('Import').prop('disabled',false);showMsg($msg,'success','Imported '+d.imported+' values ('+d.mode+' mode).');},
            function(msg){$btn.text('Import').prop('disabled',false);showMsg($msg,'error',msg);}
        );
    });

    /* ═══════════════════════════════════════════════════════════
       ADMIN: REQUEST TYPES TAB
    ═══════════════════════════════════════════════════════════ */
    $(document).on('click','#nri-add-type-btn',function(){
        $('#nri-type-id').val(''); $('#nri-type-name,#nri-type-desc').val(''); $('#nri-type-icon').val('📄');
        $('#nri-type-form-title').text('Add Type'); $('#nri-type-msg').hide();
        $('#nri-type-form').slideToggle(200);
    });
    $(document).on('click','#nri-cancel-type',function(){$('#nri-type-form').slideUp(200);});

    $(document).on('click','.nri-edit-type',function(){
        var $b=$(this);
        $('#nri-type-id').val($b.data('id')); $('#nri-type-name').val($b.data('name'));
        $('#nri-type-icon').val($b.data('icon')); $('#nri-type-desc').val($b.data('desc'));
        $('#nri-type-form-title').text('Edit Type'); $('#nri-type-msg').hide();
        $('#nri-type-form').slideDown(200);
        $('html,body').animate({scrollTop:$('#nri-type-form').offset().top-20},200);
    });

    $(document).on('click','#nri-do-save-type',function(){
        var name=$('#nri-type-name').val().trim(), $msg=$('#nri-type-msg');
        if(!name){showMsg($msg,'error','Name required.');return;}
        $msg.hide();
        nriPost('nri_save_request_type',{id:$('#nri-type-id').val(),name:name,icon:$('#nri-type-icon').val(),description:$('#nri-type-desc').val()},
            function(){showMsg($msg,'success','Saved! Reloading…');setTimeout(function(){location.reload();},1500);},
            function(msg){showMsg($msg,'error',msg);}
        );
    });

    $(document).on('click','.nri-del-type',function(){
        if(!confirm('Delete this request type?'))return;
        nriPost('nri_delete_request_type',{id:$(this).data('id')},function(){location.reload();},alert);
    });

    // Services multiselect: select-all checkbox
    $(document).on('change','#nri-type-sel-all',function(){
        var checked=$(this).is(':checked');
        $('.nri-type-chk').prop('checked',checked);
        nriUpdateTypeToolbar();
    });
    // Services multiselect: individual checkbox
    $(document).on('change','.nri-type-chk',function(){
        nriUpdateTypeToolbar();
        var total=$('.nri-type-chk').length, checked=$('.nri-type-chk:checked').length;
        $('#nri-type-sel-all').prop('indeterminate', checked>0 && checked<total);
        $('#nri-type-sel-all').prop('checked', checked===total && total>0);
    });
    function nriUpdateTypeToolbar(){
        var n=$('.nri-type-chk:checked').length;
        var $bar=$('#nri-type-bulk-bar');
        if(n>0){
            $bar.css('display','flex');
            $('#nri-type-bulk-count').text(n+' service'+(n>1?'s':'')+' selected');
        } else {
            $bar.hide();
        }
    }
    // Bulk delete selected services
    $(document).on('click','#nri-type-bulk-del',function(){
        var ids=[]; $('.nri-type-chk:checked').each(function(){ids.push($(this).data('id'));});
        if(!ids.length){alert('No services selected.');return;}
        if(!confirm('Delete '+ids.length+' selected service type'+(ids.length>1?'s':'')+' permanently?'))return;
        var pending=ids.length, errors=0;
        ids.forEach(function(id){
            nriPost('nri_delete_request_type',{id:id},function(){
                pending--;
                if(pending===0){ if(errors===0) location.reload(); else alert(errors+' deletion(s) failed.'); }
            },function(){
                errors++; pending--;
                if(pending===0) alert(errors+' deletion(s) failed.');
            });
        });
    });
    // Clear selection
    $(document).on('click','#nri-type-bulk-clear',function(){
        $('.nri-type-chk, #nri-type-sel-all').prop('checked',false).prop('indeterminate',false);
        $('#nri-type-bulk-bar').hide();
    });

    /* ═══════════════════════════════════════════════════════════
       ADMIN: SETTINGS TAB
    ═══════════════════════════════════════════════════════════ */
    $(document).on('click','#nri-save-settings-btn',function(){
        var data={}, $btn=$(this), $msg=$('#nri-settings-msg');
        $('.nri-setting-inp').each(function(){data[$(this).data('key')]=$(this).val();});
        $btn.text('Saving…').prop('disabled',true); $msg.hide();
        nriPost('nri_save_settings',data,
            function(){showMsg($msg,'success','Settings saved!');$btn.text('Save Settings').prop('disabled',false);},
            function(msg){showMsg($msg,'error',msg);$btn.text('Save Settings').prop('disabled',false);}
        );
    });

})(jQuery);

/* ============================================================
   PROFILE FORM
   ============================================================ */
(function($){

$(document).on('submit','#nri-profile-form',function(e){
    e.preventDefault();
    var $f=$(this),$msg=$('#nri-profile-msg');
    $msg.hide().removeClass('nri-alert-success nri-alert-error');
    $.ajax({url:NRI.ajax_url,type:'POST',data:{
        action:'nri_update_profile',nonce:NRI.nonce,
        display_name:$f.find('[name=display_name]').val(),
        phone:$f.find('[name=phone]').val(),
        address:$f.find('[name=address]').val(),
        new_password:$f.find('[name=new_password]').val(),
        confirm_password:$f.find('[name=confirm_password]').val()
    },success:function(r){
        $msg.addClass('nri-alert '+(r.success?'nri-alert-success':'nri-alert-error'))
            .text(r.success?(r.data&&r.data.message?r.data.message:'Saved!'):(r.data&&r.data.message?r.data.message:'Error.')).show();
    }});
});

/* ============================================================
   SUPPORT MODAL (New Service Request on client dash)
   ============================================================ */
$(document).on('click','#nri-new-sr-btn,#nri-new-sr-btn2,#nri-nav-new-req,.nri-open-support-modal',function(){
    $('#nri-sr-modal').css('display','flex');
    $('body').addClass('nri-no-scroll');
});

$(document).on('submit','#nri-support-form',function(e){
    e.preventDefault();
    var $f=$(this),$btn=$f.find('[type=submit]'),$err=$('#nri-support-err');
    $btn.text('Submitting...').prop('disabled',true);$err.hide();
    var fd=new FormData($f[0]);
    fd.append('action','nri_submit_support');fd.append('nonce',NRI.nonce);
    $.ajax({url:NRI.ajax_url,type:'POST',data:fd,processData:false,contentType:false,timeout:20000,
        success:function(r){
            $btn.text('Submit Request').prop('disabled',false);
            if(r.success){
                $f[0].reset();
                $err.removeClass('nri-alert-error').addClass('nri-alert nri-alert-success')
                    .text('Your request has been submitted! Our team will respond shortly.').show();
                setTimeout(function(){
                    $('#nri-sr-modal').css('display','none');
                    $('body').removeClass('nri-no-scroll');
                    $err.hide().removeClass('nri-alert-success');
                }, 2500);
            }else{$err.addClass('nri-alert nri-alert-error').text(r.data&&r.data.message?r.data.message:'Submission failed. Please try again.').show();}
        },
        error:function(xhr,status){
            $btn.text('Submit Request').prop('disabled',false);
            var msg=status==='timeout'?'Request timed out. Please try again.':'Connection error. Please try again.';
            $err.addClass('nri-alert nri-alert-error').text(msg).show();
        }
    });
});

/* ============================================================
   COPY REQUEST DETAILS / COPY STUDENT REQUIREMENT DESCRIPTION
   ------------------------------------------------------------
   Two compact card/detail actions: "Copy Details" copies exactly what
   the card already shows (Applicant -> Mobile -> Document/Academic ->
   Location & Delivery -> Timeline -> Remarks), read straight from the
   rendered .nri-rc-fields block so it can never drift out of sync with
   what's on screen. "Copy Description" copies the internally-generated
   Student Requirement Description (see nri_generate_requirement_
   description() in helpers.php — a deterministic rule engine, not an
   external AI call). Both work via AJAX/DOM only: no page reload, no
   scroll change, and no interference with the card's own "View" click.
   ============================================================ */
function nriCopyText(text){
    if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text);
    }
    return new Promise(function(resolve, reject){
        try {
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.left = '-9999px';
            ta.style.top = '-9999px';
            document.body.appendChild(ta);
            ta.focus(); ta.select();
            var ok = document.execCommand('copy');
            document.body.removeChild(ta);
            if (ok) { resolve(); } else { reject(new Error('execCommand copy failed')); }
        } catch (err) { reject(err); }
    });
}
function nriFlashCopied($btn){
    var orig = $btn.data('nri-orig-html');
    if (orig === undefined) { orig = $btn.html(); $btn.data('nri-orig-html', orig); }
    clearTimeout($btn.data('nri-copy-timer'));
    $btn.html('Copied &#10003;').addClass('nri-copied-flash');
    var t = setTimeout(function(){ $btn.html(orig).removeClass('nri-copied-flash'); }, 1400);
    $btn.data('nri-copy-timer', t);
}
// Builds the plain-text "Copy Details" payload from a card's rendered
// .nri-rc-fields block — the same grouped Applicant/Document & Academic/
// Location & Delivery/Remarks HTML built server-side by
// nri_render_request_card_fields() (helpers.php). Reading it from the
// DOM (rather than re-fetching field data) guarantees the copied text
// always matches exactly what's currently displayed on the card.
function nriBuildCopyDetailsText($scope){
    var lines = [];
    $scope.find('.nri-rc-fields .nri-rc-pair').each(function(){
        var $p = $(this);
        var label = $p.find('.nri-rc-lbl').first().text().replace(/:\s*$/, '').trim();
        var val = $p.clone().find('.nri-rc-lbl').remove().end().text().replace(/\s+/g, ' ').trim();
        if (label && val) { lines.push(label + ': ' + val); }
    });
    $scope.find('.nri-rc-fields .nri-rc-remarks').each(function(){
        var $r = $(this);
        var label = $r.find('.nri-rc-lbl').first().text().replace(/:\s*$/, '').trim();
        var val = $r.find('.nri-rc-val').first().text().trim();
        if (label && val) { lines.push(label + ': ' + val); }
    });
    return lines.join('\n');
}
$(document).on('click', '.nri-copy-details-btn', function(e){
    e.preventDefault(); e.stopPropagation();
    var $btn = $(this);
    var $card = $btn.closest('.nri-req-card-admin, .nri-req-card, .nri-order-page');
    var text = nriBuildCopyDetailsText($card.length ? $card : $(document));
    if (!text) { return; }
    nriCopyText(text).then(function(){ nriFlashCopied($btn); }).catch(function(){});
});
$(document).on('click', '.nri-copy-desc-btn', function(e){
    e.preventDefault(); e.stopPropagation();
    var $btn = $(this);
    var rid = $btn.data('rid');
    var text = (window._nriDescCache && window._nriDescCache[rid]) || $btn.attr('data-desc-text') || '';
    if (!text) { return; }
    nriCopyText(text).then(function(){ nriFlashCopied($btn); }).catch(function(){});
});

// "Docs" — downloads every document on the request into ONE real,
// uncompressed folder named "[Student Complete Name] – [Request Number]"
// — never a ZIP, and never several separate per-file downloads. Uses
// window.nriSaveFilesAsFolder() (defined in the COMMUNICATION PANEL IIFE
// below, exposed on window specifically so this handler — a separate
// IIFE — can call it) — the File System Access API, Chrome/Edge only:
// the person picks a location once, a subfolder with the exact request
// name is created there, and every document is written straight into it.
// Browsers without that API (Firefox, Safari, or a non-HTTPS install)
// fall back to the previous one-file-at-a-time download via
// window.nriDownloadFilesSequential() — the most those browsers can do
// without going back to a server-generated ZIP. Reuses the same
// nri_bulk_download_docs endpoint the request detail page's "Download
// All" button uses. Card-scoped: no section filter, so it covers both
// client-uploaded and provider docs.
$(document).on('click', '.nri-download-docs-btn', function(e){
    e.preventDefault(); e.stopPropagation();
    var $btn = $(this);
    if ($btn.prop('disabled')) { return; }
    var rid = $btn.data('rid');
    var orig = $btn.html();
    $btn.prop('disabled', true).html('&#8595; ...');
    $.post(NRI.ajax_url, { action: 'nri_bulk_download_docs', nonce: NRI.admin_nonce, request_id: rid, section: 'all', att_ids: [] }, function(r){
        if (!r || !r.success) {
            $btn.prop('disabled', false).html(orig);
            alert((r && r.data && r.data.message) ? r.data.message : 'Could not download documents.');
            return;
        }
        var files = r.data.files || [];
        if (!files.length) { $btn.prop('disabled', false).html(orig); return; }
        if (window.nriSaveFilesAsFolder) {
            window.nriSaveFilesAsFolder(r.data.folder || ('Request-' + rid), files).then(function(result){
                $btn.prop('disabled', false).html(orig);
                if (result === 'unsupported' && window.nriDownloadFilesSequential) {
                    // This browser/context has no File System Access API —
                    // fall back to individual downloads rather than leaving
                    // the click with no result at all.
                    window.nriDownloadFilesSequential(files);
                }
                // 'cancelled': the person dismissed the folder picker — do
                // nothing further, that's a deliberate no-op, not an error.
            });
            return;
        }
        $btn.prop('disabled', false).html(orig);
        if (window.nriDownloadFilesSequential) {
            window.nriDownloadFilesSequential(files);
        }
    }).fail(function(){
        $btn.prop('disabled', false).html(orig);
        alert('Network error. Please try again.');
    });
});

/* ============================================================
   STUDENT REQUIREMENT DESCRIPTION — regenerate / edit / save
   (request detail page, Form Details tab — staff only)
   ============================================================ */
$(document).on('click', '.nri-regen-desc-btn', function(e){
    e.preventDefault();
    var $btn = $(this);
    var rid  = $btn.data('rid');
    var isManual = String($btn.data('manual')) === '1';
    if (isManual && !confirm('This description was manually edited. Regenerating will replace it with a freshly generated version. Continue?')) {
        return;
    }
    $btn.prop('disabled', true);
    $.post(NRI.ajax_url, { action: 'nri_regenerate_description', nonce: NRI.admin_nonce, request_id: rid, force: 1 }, function(r){
        $btn.prop('disabled', false);
        if (r && r.success) {
            var html = $('<div>').text(r.data.text).html().replace(/\n/g, '<br>');
            $('#nri-req-desc-text-' + rid).html(html);
            $('#nri-req-desc-edit-' + rid).val(r.data.text);
            $btn.data('manual', '0');
            var $panel = $btn.closest('.nri-req-desc-panel');
            $panel.find('.nri-req-desc-badge').first().removeClass('nri-req-desc-manual').addClass('nri-req-desc-auto').text('Auto-Generated');
            $panel.find('.nri-req-desc-stale').remove();
            $panel.find('.nri-copy-desc-btn').attr('data-desc-text', r.data.text);
            if (window._nriDescCache) { window._nriDescCache[rid] = r.data.text; }
        } else {
            alert((r && r.data && r.data.message) ? r.data.message : 'Could not regenerate the description.');
        }
    });
});
$(document).on('click', '.nri-edit-desc-btn', function(e){
    e.preventDefault();
    var $panel = $(this).closest('.nri-req-desc-panel');
    var rid = $panel.data('rid');
    $('#nri-req-desc-text-' + rid).hide();
    $('#nri-req-desc-edit-' + rid).show().focus();
    $panel.find('.nri-edit-desc-btn, .nri-regen-desc-btn').hide();
    $panel.find('.nri-save-desc-btn, .nri-cancel-desc-btn').show();
});
$(document).on('click', '.nri-cancel-desc-btn', function(e){
    e.preventDefault();
    var $panel = $(this).closest('.nri-req-desc-panel');
    var rid = $panel.data('rid');
    $('#nri-req-desc-edit-' + rid).hide();
    $('#nri-req-desc-text-' + rid).show();
    $panel.find('.nri-edit-desc-btn, .nri-regen-desc-btn').show();
    $panel.find('.nri-save-desc-btn, .nri-cancel-desc-btn').hide();
});
$(document).on('click', '.nri-save-desc-btn', function(e){
    e.preventDefault();
    var $btn   = $(this);
    var $panel = $btn.closest('.nri-req-desc-panel');
    var rid    = $panel.data('rid');
    var text   = $('#nri-req-desc-edit-' + rid).val();
    if (!text || !text.trim()) { alert('Description cannot be empty.'); return; }
    $btn.prop('disabled', true);
    $.post(NRI.ajax_url, { action: 'nri_save_description', nonce: NRI.admin_nonce, request_id: rid, text: text }, function(r){
        $btn.prop('disabled', false);
        if (r && r.success) {
            var html = $('<div>').text(r.data.text).html().replace(/\n/g, '<br>');
            $('#nri-req-desc-text-' + rid).html(html).show();
            $('#nri-req-desc-edit-' + rid).val(r.data.text).hide();
            $panel.find('.nri-edit-desc-btn, .nri-regen-desc-btn').show();
            $panel.find('.nri-regen-desc-btn').data('manual', '1');
            $panel.find('.nri-save-desc-btn, .nri-cancel-desc-btn').hide();
            $panel.find('.nri-copy-desc-btn').attr('data-desc-text', r.data.text);
            $panel.find('.nri-req-desc-badge').first().removeClass('nri-req-desc-auto').addClass('nri-req-desc-manual').text('Manually Edited');
            $panel.find('.nri-req-desc-stale').remove();
            if (window._nriDescCache) { window._nriDescCache[rid] = r.data.text; }
        } else {
            alert((r && r.data && r.data.message) ? r.data.message : 'Could not save the description.');
        }
    });
});

/* ============================================================
   DELETE REQUEST (Admin)
   ============================================================ */
$(document).on('click','.nri-delete-request',function(){
    var rid=$(this).data('rid');
    if(!confirm('Delete this request permanently? All messages and tickets will also be deleted.'))return;
    $.post(NRI.ajax_url,{action:'nri_delete_request',nonce:NRI.admin_nonce,request_id:rid,hard_delete:1},function(r){
        if(r.success){
            // Inside the admin dashboard SPA (embedded detail view): go
            // back to the requests list in place instead of a full page
            // redirect. Standalone /request/{id} page: fall back to the
            // old full-navigation behavior, since there's no SPA container
            // to return to.
            if ($('.nri-order-page-embedded').length && window.nriAdminLoadTab) {
                var s = (window.nriAdminStateGet ? window.nriAdminStateGet() : {});
                window.nriAdminLoadTab((s && s.currentTab) || 'requests');
            } else {
                window.location.href=NRI.home_url+'/admin-dashboard';
            }
        }
        else{alert('Delete failed.');}
    });
});

/* ============================================================
   FIELD REORDER — Drag-and-Drop (SortableJS)
   ============================================================ */
function nriInitFieldSortable() {
    var tbody = document.getElementById('nri-fields-tbody');
    if (!tbody || typeof Sortable === 'undefined') return;
    Sortable.create(tbody, {
        handle: '.nri-drag-handle',
        animation: 150,
        ghostClass: 'nri-drag-ghost',
        chosenClass: 'nri-drag-chosen',
        onEnd: function(evt) {
            var ids = [];
            tbody.querySelectorAll('tr[data-field-id]').forEach(function(tr) {
                ids.push(parseInt(tr.getAttribute('data-field-id'), 10));
            });
            $.post(NRI.ajax_url, {action: 'nri_reorder_fields', nonce: NRI.admin_nonce, ids: ids}, function(r) {
                if (!r.success) { alert('Could not save new order.'); }
            });
        }
    });
}
$(document).on('nri:fields_rendered', nriInitFieldSortable);

})(jQuery);

/* ============================================================
   v6.2.1: SHIPPING CHARGES HANDLER
   ============================================================ */
(function($){
    $(document).on('click', '#nri-do-shipping', function(){
        var rid = $(this).data('rid');
        var amount = $('#nri-shipping-amt').val();
        var type = $('#nri-shipping-type').val();
        
        if (!amount || amount < 0) {
            alert('Please enter a valid shipping amount');
            return;
        }
        
        $(this).text('Setting...').prop('disabled', true);
        
        $.post(NRI.ajax_url, {
            action: 'nri_set_shipping',
            nonce: NRI.nonce,
            request_id: rid,
            amount: amount,
            type: type
        }, function(r){
            $('#nri-do-shipping').text('Set').prop('disabled', false);
            if (r.success) {
                alert('Shipping charges updated!');
                location.reload();
            } else {
                alert('Error: ' + (r.data && r.data.message ? r.data.message : 'Failed to update'));
            }
        });
    });
})(jQuery);

// ── COMMUNICATION PANEL ─────────────────────────────────────────────────────
(function($){
    if (typeof NRI === 'undefined') return;

    // Load template into compose box
    $(document).on('click', '#nri-comm-load-template', function(){
        var ttype = $('#nri-comm-template-sel').val();
        if (!ttype) { alert('Please select a template first.'); return; }
        var rid = $('#nri-comm-rid').val();
        var $btn = $(this).text('Loading...').prop('disabled', true);
        $.post(NRI.ajax_url, {
            action: 'nri_get_comm_template',
            nonce: NRI.nonce,
            request_id: rid,
            template_type: ttype
        }, function(r){
            $btn.text('Load').prop('disabled', false);
            if (r.success) {
                if (r.data.subject) $('#nri-comm-subject').val(r.data.subject);
                if (r.data.body)    $('#nri-comm-body').val(r.data.body);
            } else {
                alert('Could not load template: ' + (r.data && r.data.message ? r.data.message : 'Unknown error'));
            }
        });
    });

    // Quick reply: insert into textarea
    $(document).on('click', '.nri-comm-quick-btn', function(){
        var content = $(this).data('content');
        var $ta = $('#nri-comm-body');
        var cur = $ta.val();
        $ta.val(cur ? cur + '\n\n' + content : content);
        $ta.focus();
        // Scroll textarea to bottom
        $ta[0].scrollTop = $ta[0].scrollHeight;
    });

    // Send email only
    $(document).on('click', '#nri-comm-send-email', function(){
        nriCommSend(false);
    });

    // Send email + log to message history
    $(document).on('click', '#nri-comm-send-and-log', function(){
        nriCommSend(true);
    });

    function nriCommSend(logMessage) {
        var rid     = $('#nri-comm-rid').val();
        var subject = $.trim($('#nri-comm-subject').val());
        var body    = $.trim($('#nri-comm-body').val());
        var $status = $('#nri-comm-status');

        if (!subject || !body) {
            nriCommStatus('Please fill in the subject and message.', 'error');
            return;
        }

        var $btn = logMessage ? $('#nri-comm-send-and-log') : $('#nri-comm-send-email');
        $btn.text('Sending...').prop('disabled', true);
        $('#nri-comm-send-email, #nri-comm-send-and-log').prop('disabled', true);

        $.post(NRI.ajax_url, {
            action: 'nri_send_comm_email',
            nonce: NRI.nonce,
            request_id: rid,
            subject: subject,
            body: body,
            log_message: logMessage ? 1 : 0
        }, function(r){
            $('#nri-comm-send-email, #nri-comm-send-and-log').prop('disabled', false).each(function(){
                $(this).text( $(this).attr('id') === 'nri-comm-send-email' ? '✉ Send Email' : '✉ Send & Log to History' );
            });
            if (r.success) {
                nriCommStatus('&#10003; ' + r.data.message, 'success');
                $('#nri-comm-body').val('');
                // If logged, append to communication log
                if (r.data.logged) {
                    var uid_new = 'nricl-new-' + Date.now();
                    var logHtml = '<div class="nri-comm-log-item" style="border:1px solid #e2e8f0;border-radius:8px;margin-bottom:12px;overflow:hidden;">'
                        + '<div class="nri-comm-log-hdr" style="display:flex;justify-content:space-between;align-items:flex-start;padding:12px 16px;background:#f8fafc;cursor:pointer;" onclick="nriToggleCommLog(\'' + uid_new + '\')" >'
                        + '<div style="flex:1;min-width:0;">'
                        + '<div style="display:flex;align-items:center;gap:8px;"><span style="font-size:16px;">&#9993;</span>'
                        + '<span style="font-size:13px;color:#64748b;">Sent by <strong style="color:#1e293b;">' + r.data.sender + '</strong> &mdash; ' + r.data.sent_time + '</span></div>'
                        + '<div style="margin-top:6px;padding-left:26px;font-size:13px;color:#374151;"><strong>Subject:</strong> ' + subject + '</div>'
                        + '</div>'
                        + '<span style="font-size:11px;color:#94a3b8;white-space:nowrap;padding-left:12px;" id="' + uid_new + '-arrow">&#9660; View</span>'
                        + '</div>'
                        + '<div id="' + uid_new + '" style="display:none;padding:16px;border-top:1px solid #e2e8f0;background:#fff;">'
                        + '<div style="margin-bottom:12px;padding:8px 12px;background:#eff6ff;border-radius:6px;font-size:13px;font-weight:600;color:#1e40af;">' + subject + '</div>'
                        + '<div style="font-size:14px;line-height:1.8;color:#374151;white-space:pre-wrap;border:1px solid #e2e8f0;border-radius:6px;padding:12px;background:#fafafa;">' + body + '</div>'
                        + '</div>'
                        + '</div>';
                    var $list = $('.nri-comm-history-list');
                    if ($list.find('.nri-hint').length) $list.empty();
                    $list.prepend(logHtml);
                    // Update count
                    var cur = parseInt($('.nri-comm-log-count').text()) || 0;
                    $('.nri-comm-log-count').text((cur + 1) + ' email(s) sent');
                }
            } else {
                nriCommStatus('&#10007; ' + (r.data && r.data.message ? r.data.message : 'Failed to send.'), 'error');
            }
        }).fail(function(){
            $('#nri-comm-send-email, #nri-comm-send-and-log').prop('disabled', false);
            nriCommStatus('&#10007; Network error. Please try again.', 'error');
        });
    }

    function nriCommStatus(msg, type) {
        var $s = $('#nri-comm-status');
        $s.removeClass('nri-comm-success nri-comm-error')
          .addClass(type === 'success' ? 'nri-comm-success' : 'nri-comm-error')
          .html(msg).show();
        if (type === 'success') {
            setTimeout(function(){ $s.fadeOut(); }, 5000);
        }
    }

})(jQuery);

// ── Communication log toggle (outside jQuery wrapper for inline onclick) ─────
function nriToggleCommLog(id) {
    var el = document.getElementById(id);
    var arrow = document.getElementById(id + '-arrow');
    if (!el) return;
    if (el.style.display === 'none') {
        el.style.display = 'block';
        if (arrow) arrow.innerHTML = '&#9650; Hide';
    } else {
        el.style.display = 'none';
        if (arrow) arrow.innerHTML = '&#9660; View';
    }
}

// ── Document bulk / multiselect download ─────────────────────────────────────
(function($){
    // Individual checkbox toggles the bulk toolbar for that section
    $(document).on('change', '.nri-doc-select-all', function(){
        var section = $(this).data('section');
        var checked = $(this).is(':checked');
        $('.nri-doc-chk[data-section="' + section + '"]').prop('checked', checked);
        nriUpdateDocBulkBar(section);
    });
    $(document).on('change', '.nri-doc-chk', function(){
        var section = $(this).data('section');
        nriUpdateDocBulkBar(section);
        var total   = $('.nri-doc-chk[data-section="' + section + '"]').length;
        var checked = $('.nri-doc-chk[data-section="' + section + '"]:checked').length;
        $('.nri-doc-select-all[data-section="' + section + '"]')
            .prop('indeterminate', checked > 0 && checked < total)
            .prop('checked', checked === total && total > 0);
    });
    function nriUpdateDocBulkBar(section) {
        var n = $('.nri-doc-chk[data-section="' + section + '"]:checked').length;
        var $btn = $('.nri-doc-bulk-dl[data-section="' + section + '"]');
        if (n > 0) { $btn.show().text('\u2193 Download Selected (' + n + ')'); }
        else        { $btn.hide(); }
    }

    // Download SELECTED documents — tries server-side ZIP first, falls back to sequential
    $(document).on('click', '.nri-doc-bulk-dl', function(){
        var $btn    = $(this);
        var section = $btn.data('section');
        var attIds  = [];
        var rid     = $('[data-nri-rid]').data('nri-rid') || $('#nri-msg-rid').val() || $('#nri-comm-rid').val() || 0;
        $('.nri-doc-chk[data-section="' + section + '"]:checked').each(function(){
            attIds.push($(this).closest('.nri-doc-entry').data('att-id'));
        });
        if (!attIds.length) { alert('No documents selected.'); return; }
        $btn.text('\u23f3 Preparing...').prop('disabled', true);
        nriBulkDownload(rid, section, attIds, $btn);
    });

    // Download ALL documents in a section
    $(document).on('click', '.nri-doc-dl-all', function(){
        var $btn    = $(this);
        var section = $btn.data('section');
        var rid     = $btn.data('rid') || $('#nri-msg-rid').val() || $('#nri-comm-rid').val() || 0;
        $btn.text('\u23f3 Preparing...').prop('disabled', true);
        nriBulkDownload(rid, section, [], $btn);
    });

    function nriBulkDownload(rid, section, attIds, $btn) {
        var label = attIds.length ? 'Download Selected' : 'Download All';
        $.post(NRI.ajax_url, {
            action:     'nri_bulk_download_docs',
            nonce:      NRI.nonce || NRI.admin_nonce,
            request_id: rid,
            section:    section,
            att_ids:    attIds
        }, function(r) {
            if (!r.success) {
                $btn.text('\u2193 ' + label).prop('disabled', false);
                alert('Download error: ' + (r.data && r.data.message ? r.data.message : 'Unknown error'));
                return;
            }
            var files = r.data.files || [];
            if (!files.length) { $btn.text('\u2193 ' + label).prop('disabled', false); return; }
            // Never a ZIP: one real folder ("[Student Name] \u2013 [Request Number]")
            // written straight to disk via the File System Access API where
            // the browser supports it (nriSaveFilesAsFolder(), defined
            // below), falling back to the previous one-file-at-a-time
            // download only where that API isn't available.
            if (typeof nriSaveFilesAsFolder === 'function') {
                nriSaveFilesAsFolder(r.data.folder || ('Request-' + rid), files).then(function(result){
                    $btn.text('\u2193 ' + label).prop('disabled', false);
                    if (result === 'unsupported') { nriDownloadFilesSequential(files); }
                });
                return;
            }
            $btn.text('\u2193 ' + label).prop('disabled', false);
            nriDownloadFilesSequential(files);
        }).fail(function(){
            $btn.text('\u2193 ' + label).prop('disabled', false);
            alert('Network error. Please try again.');
        });
    }

    // Sequential download: one file every 500ms so browser doesn't block them
    // all. Exposed on window so the "Docs" button handler (a separate IIFE,
    // above) can reuse this exact same download logic instead of duplicating
    // it — see the comment on window.nriDownloadFilesSequential's call site.
    function nriDownloadFilesSequential(files) {
        if (!files || !files.length) return;
        files.forEach(function(f, i){
            setTimeout(function(){
                var a = document.createElement('a');
                a.href     = f.url;
                a.download = f.filename || 'document';
                a.style.display = 'none';
                document.body.appendChild(a);
                a.click();
                setTimeout(function(){ document.body.removeChild(a); }, 1000);
            }, i * 500);
        });
    }
    window.nriDownloadFilesSequential = nriDownloadFilesSequential;

    // ── Remembered download location ────────────────────────────────────────
    // Browsers give a web page no way to "open" or navigate the OS file
    // explorer to a folder — that's not something any browser (Chrome,
    // Edge, Firefox, Safari) exposes to a website, for security reasons.
    // What we CAN do is stop asking every time: the very first time someone
    // picks a location for their documents, we remember that exact folder
    // (as a FileSystemDirectoryHandle, in IndexedDB) and reuse it silently
    // on every later download — so after the first pick, every request's
    // folder always lands inside the SAME parent folder the person already
    // knows and has open, with no picker and no re-navigating.
    var NRI_DIR_DB    = 'nri_docs_dir_db';
    var NRI_DIR_STORE = 'handles';
    var NRI_DIR_KEY   = 'download_folder';

    function nriOpenDirDB() {
        return new Promise(function(resolve, reject) {
            if (!window.indexedDB) { reject(new Error('no indexedDB')); return; }
            var req = window.indexedDB.open(NRI_DIR_DB, 1);
            req.onupgradeneeded = function(){ req.result.createObjectStore(NRI_DIR_STORE); };
            req.onsuccess = function(){ resolve(req.result); };
            req.onerror   = function(){ reject(req.error); };
        });
    }
    function nriGetStoredDirHandle() {
        return nriOpenDirDB().then(function(db){
            return new Promise(function(resolve){
                var tx  = db.transaction(NRI_DIR_STORE, 'readonly');
                var req = tx.objectStore(NRI_DIR_STORE).get(NRI_DIR_KEY);
                req.onsuccess = function(){ resolve(req.result || null); };
                req.onerror   = function(){ resolve(null); };
            });
        })['catch'](function(){ return null; });
    }
    function nriSetStoredDirHandle(handle) {
        return nriOpenDirDB().then(function(db){
            return new Promise(function(resolve){
                var tx = db.transaction(NRI_DIR_STORE, 'readwrite');
                tx.objectStore(NRI_DIR_STORE).put(handle, NRI_DIR_KEY);
                tx.oncomplete = function(){ resolve(); };
                tx.onerror    = function(){ resolve(); };
            });
        })['catch'](function(){});
    }
    function nriClearStoredDirHandle() {
        return nriOpenDirDB().then(function(db){
            return new Promise(function(resolve){
                var tx = db.transaction(NRI_DIR_STORE, 'readwrite');
                tx.objectStore(NRI_DIR_STORE)['delete'](NRI_DIR_KEY);
                tx.oncomplete = function(){ resolve(); };
                tx.onerror    = function(){ resolve(); };
            });
        })['catch'](function(){});
    }
    // Resolves the parent folder to save into: reuses the remembered one
    // (re-confirming permission, which the browser may re-prompt for) when
    // one exists and is still usable, otherwise asks once via the native
    // folder picker and remembers the choice for every future download.
    async function nriGetParentDirHandle() {
        var stored = await nriGetStoredDirHandle();
        if (stored) {
            try {
                var perm = await stored.queryPermission({ mode: 'readwrite' });
                if (perm !== 'granted') {
                    perm = await stored.requestPermission({ mode: 'readwrite' });
                }
                if (perm === 'granted') { return stored; }
            } catch (err) {
                // Stored handle is stale (folder was moved/deleted/revoked) —
                // fall through and ask again below.
            }
        }
        var opts = { mode: 'readwrite' };
        if (stored) { try { opts.startIn = stored; } catch (e) {} }
        var handle = await window.showDirectoryPicker(opts);
        await nriSetStoredDirHandle(handle);
        return handle;
    }

    // Small, non-blocking confirmation banner — used instead of alert() so
    // a normal successful download doesn't interrupt the person with a
    // dialog they have to dismiss every single time.
    function nriShowSaveToast(message, isError) {
        try {
            var $t = jQuery('<div/>').text(message).css({
                position: 'fixed', bottom: '24px', right: '24px', zIndex: 999999,
                background: isError ? '#b91c1c' : '#1f7a3d', color: '#fff',
                padding: '10px 16px', borderRadius: '6px', fontSize: '13px',
                maxWidth: '360px', boxShadow: '0 2px 10px rgba(0,0,0,.25)'
            }).appendTo('body');
            setTimeout(function(){ $t.fadeOut(400, function(){ $t.remove(); }); }, isError ? 6000 : 4000);
        } catch (e) { /* non-critical UI, ignore */ }
    }

    // Writes every file in `files` (each {url, filename}) into ONE real,
    // uncompressed folder named `folderName` — no ZIP, and no separate
    // per-file download prompts — using the File System Access API
    // (Chrome/Edge, secure-context only). Only the FIRST download ever asks
    // where to save; every download after that reuses the same remembered
    // parent folder automatically (see nriGetParentDirHandle() above), so
    // there is never anywhere to "navigate back to" — it's always the same
    // place. A subfolder named exactly `folderName` is created (or reused)
    // inside that parent, and every document is fetched and written
    // straight into it.
    //
    // Returns a Promise resolving to:
    //   'done'      — files were written into the folder
    //   'cancelled' — the person dismissed the folder picker (not an error)
    //   'unsupported' — this browser/context has no File System Access API
    //                   (Firefox, Safari, or the page isn't served over
    //                   HTTPS) — caller should fall back to
    //                   nriDownloadFilesSequential() instead, which is the
    //                   most any of those can do without going back to a
    //                   server-generated ZIP.
    // A thrown error means the picker itself failed for a reason other
    // than the person cancelling (e.g. permission denied); caller should
    // treat that the same as 'unsupported' and fall back.
    async function nriSaveFilesAsFolder(folderName, files) {
        if (!window.showDirectoryPicker) { return 'unsupported'; }
        if (!files || !files.length) { return 'done'; }

        var parentHandle;
        try {
            parentHandle = await nriGetParentDirHandle();
        } catch (err) {
            if (err && err.name === 'AbortError') { return 'cancelled'; }
            return 'unsupported';
        }

        var subDir;
        try {
            subDir = await parentHandle.getDirectoryHandle(folderName, { create: true });
        } catch (err) {
            return 'unsupported';
        }

        var failed = [];
        for (var i = 0; i < files.length; i++) {
            var f = files[i];
            try {
                var resp = await fetch(f.url, { credentials: 'same-origin' });
                if (!resp.ok) { failed.push(f.filename || ('file ' + (i + 1))); continue; }
                // The real filename (with its correct, server-decided
                // extension — PDF/JPG/PNG, after any WebP/AVIF conversion)
                // comes from Content-Disposition, not from `f.filename`
                // (which is only a pre-fetch hint with no extension yet).
                var cd = resp.headers.get('Content-Disposition') || '';
                var m  = /filename\*?=(?:UTF-8''|")?([^";]+)"?/i.exec(cd);
                var saveName = m ? decodeURIComponent(m[1]) : ((f.filename || 'document') + '.pdf');
                var blob = await resp.blob();
                var fileHandle = await subDir.getFileHandle(saveName, { create: true });
                var writable = await fileHandle.createWritable();
                await writable.write(blob);
                await writable.close();
            } catch (err) {
                failed.push(f.filename || ('file ' + (i + 1)));
            }
        }
        var whereText = (parentHandle.name || 'chosen folder') + ' / ' + folderName;
        if (failed.length) {
            nriShowSaveToast('Saved to "' + whereText + '", but ' + failed.length + ' file(s) could not be downloaded: ' + failed.join(', '), true);
        } else {
            nriShowSaveToast('Saved to "' + whereText + '" — same folder every time, no need to look elsewhere.', false);
        }
        return 'done';
    }
    window.nriSaveFilesAsFolder = nriSaveFilesAsFolder;

    // Lets the person explicitly point future downloads at a different
    // folder — otherwise the first-ever pick is remembered and reused
    // silently forever (see nriGetParentDirHandle() above), and there was
    // previously no way back to the picker short of clearing site data.
    // Wired to every ".nri-change-save-folder" button (Requests toolbar,
    // request-detail documents panel, Form Details documents panel).
    window.nriChangeDownloadFolder = async function () {
        await nriClearStoredDirHandle();
        if (!window.showDirectoryPicker) {
            nriShowSaveToast('This browser can\'t remember a save folder — documents download individually instead.', true);
            return;
        }
        try {
            var handle = await window.showDirectoryPicker({ mode: 'readwrite' });
            await nriSetStoredDirHandle(handle);
            nriShowSaveToast('Save folder changed to "' + handle.name + '". Future downloads will use this folder.', false);
        } catch (err) {
            if (err && err.name === 'AbortError') { return; } // cancelled — leave unset, next download will ask
            nriShowSaveToast('Could not set a new save folder.', true);
        }
    };
    $(document).on('click', '.nri-change-save-folder', function (e) {
        e.preventDefault();
        window.nriChangeDownloadFolder();
    });
})(jQuery);
// ── END COMMUNICATION PANEL ─────────────────────────────────────────────────

// ── Quick Email Buttons (Staff Panel) ───────────────────────────────────────
(function($){
    if (typeof NRI === 'undefined') return;

    function nriShowEmailResult($btn, originalText, success, msg) {
        $btn.prop('disabled', false);
        var $row = $btn.closest('.nri-staff-section');
        var $notice = $row.find('.nri-email-result-notice');
        if (!$notice.length) {
            $notice = $('<div class="nri-email-result-notice" style="margin-top:8px;padding:8px 12px;border-radius:6px;font-size:12px;font-weight:600;"></div>');
            $btn.after($notice);
        }
        if (success) {
            $btn.text('✓ Sent!');
            $notice.css({background:'#f0fdf4',color:'#16a34a',border:'1px solid #bbf7d0'}).text('✓ ' + msg).show();
            setTimeout(function(){ $btn.text(originalText); $notice.fadeOut(); }, 5000);
        } else {
            $btn.text(originalText);
            $notice.css({background:'#fef2f2',color:'#dc2626',border:'1px solid #fecaca'}).text('✗ ' + msg + ' — Check SMTP settings in WordPress.').show();
        }
    }

    $(document).on('click','#nri-send-doc-reminder',function(){
        var $btn=$(this), rid=$btn.data('rid'), originalText=$btn.text();
        var note=prompt('Optional: Add a note to the reminder email (leave blank to send standard reminder):','');
        if (note === null) return; // user cancelled prompt
        $btn.text('Sending…').prop('disabled',true);
        $.post(NRI.ajax_url,{action:'nri_send_doc_reminder',nonce:NRI.admin_nonce,request_id:rid,note:note||''},
            function(r){ nriShowEmailResult($btn, originalText, r.success, r.success?(r.data&&r.data.message?r.data.message:'Sent'):(r.data&&r.data.message?r.data.message:'Failed to send')); }
        ).fail(function(){ nriShowEmailResult($btn, originalText, false, 'Network error — request did not reach server'); });
    });

    $(document).on('click','#nri-send-status-email',function(){
        var $btn=$(this), rid=$btn.data('rid'), originalText=$btn.text();
        if (!confirm('Send current status update email to the client?')) return;
        $btn.text('Sending…').prop('disabled',true);
        $.post(NRI.ajax_url,{action:'nri_send_status_email',nonce:NRI.admin_nonce,request_id:rid},
            function(r){ nriShowEmailResult($btn, originalText, r.success, r.success?(r.data&&r.data.message?r.data.message:'Sent'):(r.data&&r.data.message?r.data.message:'Failed to send')); }
        ).fail(function(){ nriShowEmailResult($btn, originalText, false, 'Network error'); });
    });

})(jQuery);
// ── END Quick Email Buttons ─────────────────────────────────────────────────

// ── Form Details Tab: document multiselect + bulk download ───────────────────
(function($){
    if (typeof NRI === 'undefined') return;

    // Select-all checkbox
    $(document).on('change', '#nri-fd-sel-all', function(){
        var checked = $(this).is(':checked');
        $('.nri-fd-doc-chk').prop('checked', checked);
        nriFdUpdateBulkBar();
    });
    // Per-file checkbox
    $(document).on('change', '.nri-fd-doc-chk', function(){
        nriFdUpdateBulkBar();
        var total   = $('.nri-fd-doc-chk').length;
        var checked = $('.nri-fd-doc-chk:checked').length;
        $('#nri-fd-sel-all').prop('indeterminate', checked > 0 && checked < total).prop('checked', checked === total && total > 0);
    });
    function nriFdUpdateBulkBar(){
        var n = $('.nri-fd-doc-chk:checked').length;
        if (n > 0) {
            $('#nri-fd-dl-selected').show().text('↓ Download Selected (' + n + ')');
            $('#nri-fd-del-selected').show().text('🗑 Delete Selected (' + n + ')');
        } else {
            $('#nri-fd-dl-selected').hide();
            $('#nri-fd-del-selected').hide();
        }
    }

    // Removes a document row from the DOM and updates the "Uploaded
    // Documents (N)" heading count — done locally rather than re-fetching
    // the whole request detail, so a delete stays fast and doesn't disturb
    // anything else the staff member has open on this screen.
    function nriFdRemoveDocRows(attIds){
        attIds.forEach(function(id){
            $('.nri-fd-doc-row[data-att-id="' + id + '"]').remove();
        });
        var remaining = $('.nri-fd-doc-row').length;
        var $heading = $('.nri-ot-pane h4:contains("Uploaded Documents")').first();
        if ($heading.length) {
            $heading.html($heading.html().replace(/\(\d+\)/, '(' + remaining + ')'));
        }
        nriFdUpdateBulkBar();
        var $selAll = $('#nri-fd-sel-all');
        if ($selAll.length) { $selAll.prop('checked', false).prop('indeterminate', false); }
    }

    // Delete selected (bulk)
    $(document).on('click', '#nri-fd-del-selected', function(){
        var $btn = $(this), rid = $btn.data('rid');
        var attIds = [];
        $('.nri-fd-doc-chk:checked').each(function(){ attIds.push($(this).data('att-id')); });
        if (!attIds.length) { alert('No documents selected.'); return; }
        if (!confirm('Delete the selected ' + attIds.length + ' file' + (attIds.length > 1 ? 's' : '') + '? This cannot be undone.')) return;
        var origText = $btn.text();
        $btn.text('Deleting…').prop('disabled', true);
        $.post(NRI.ajax_url, {
            action: 'nri_delete_documents',
            nonce: NRI.admin_nonce || NRI.nonce,
            request_id: rid,
            att_ids: attIds
        }, function(r){
            $btn.text(origText).prop('disabled', false);
            if (r.success) { nriFdRemoveDocRows(attIds); }
            else { alert('Delete failed: ' + (r.data && r.data.message ? r.data.message : 'Unknown error')); }
        }).fail(function(){ $btn.text(origText).prop('disabled', false); alert('Network error.'); });
    });

    // Delete one file (per-row button)
    $(document).on('click', '.nri-fd-doc-del', function(){
        var $btn = $(this), rid = $btn.data('rid'), attId = $btn.data('att-id');
        if (!confirm('Delete this file? This cannot be undone.')) return;
        $btn.prop('disabled', true);
        $.post(NRI.ajax_url, {
            action: 'nri_delete_documents',
            nonce: NRI.admin_nonce || NRI.nonce,
            request_id: rid,
            att_ids: [attId]
        }, function(r){
            if (r.success) { nriFdRemoveDocRows([attId]); }
            else { $btn.prop('disabled', false); alert('Delete failed: ' + (r.data && r.data.message ? r.data.message : 'Unknown error')); }
        }).fail(function(){ $btn.prop('disabled', false); alert('Network error.'); });
    });

    // Download selected
    $(document).on('click', '#nri-fd-dl-selected', function(){
        var $btn = $(this), rid = $btn.data('rid');
        var attIds = [];
        $('.nri-fd-doc-chk:checked').each(function(){ attIds.push($(this).data('att-id')); });
        if (!attIds.length) { alert('No documents selected.'); return; }
        $btn.text('⏳ Preparing…').prop('disabled', true);
        nriFdBulkDownload(rid, attIds, $btn, 'Download Selected');
    });

    // Download all
    $(document).on('click', '#nri-fd-dl-all', function(){
        var $btn = $(this), rid = $btn.data('rid');
        $btn.text('⏳ Preparing…').prop('disabled', true);
        nriFdBulkDownload(rid, [], $btn, 'Download All');
    });

    function nriFdBulkDownload(rid, attIds, $btn, label){
        $.post(NRI.ajax_url, {
            action:     'nri_bulk_download_docs',
            nonce:      NRI.admin_nonce || NRI.nonce,
            request_id: rid,
            section:    'all',
            att_ids:    attIds
        }, function(r){
            if (!r.success) {
                $btn.text('↓ ' + label).prop('disabled', false);
                alert('Download error: ' + (r.data && r.data.message ? r.data.message : 'Unknown'));
                return;
            }
            var files = r.data.files || [];
            if (!files.length) { $btn.text('↓ ' + label).prop('disabled', false); return; }
            // Same one-real-folder behavior as the Docs button and
            // Download All/Selected elsewhere (nriSaveFilesAsFolder(),
            // defined in the COMMUNICATION PANEL IIFE below) — this entry
            // point used to fall back to per-file/ZIP downloads even after
            // that was fixed everywhere else; it now goes through the same
            // path so "Download All"/"Download Selected" here behaves
            // identically to every other download button in the plugin.
            if (typeof window.nriSaveFilesAsFolder === 'function') {
                window.nriSaveFilesAsFolder(r.data.folder || ('Request-' + rid), files).then(function(result){
                    $btn.text('↓ ' + label).prop('disabled', false);
                    if (result === 'unsupported' && window.nriDownloadFilesSequential) {
                        window.nriDownloadFilesSequential(files);
                    }
                });
                return;
            }
            $btn.text('↓ ' + label).prop('disabled', false);
            if (window.nriDownloadFilesSequential) {
                window.nriDownloadFilesSequential(files);
            }
        }).fail(function(){ $btn.text('↓ '+label).prop('disabled',false); alert('Network error.'); });
    }

})(jQuery);
// ── END Form Details multiselect ─────────────────────────────────────────────

// ── Bulk Select & Export (Admin Requests Table) ─────────────────────────────
(function($){
    if (typeof NRI === 'undefined') return;

    var selectedRids = [];

    function updateBulkUI(){
        var n = selectedRids.length;
        if(n > 0){
            $('#nri-bulk-toolbar').css('display','flex');
            $('#nri-bulk-count').text(n + ' request' + (n>1?'s':'') + ' selected');
        } else {
            $('#nri-bulk-toolbar').hide();
        }
    }

    // Row checkbox: delegate since tbody is dynamically built
    $(document).on('change','#nri-admin-tbody .nri-bulk-chk', function(){
        var rid = parseInt($(this).val());
        if($(this).is(':checked')){
            if(selectedRids.indexOf(rid) < 0) selectedRids.push(rid);
        } else {
            selectedRids = selectedRids.filter(function(r){ return r !== rid; });
            $('#nri-select-all-reqs').prop('checked', false);
        }
        updateBulkUI();
    });

    // Select all
    $(document).on('change','#nri-select-all-reqs',function(){
        var checked = $(this).is(':checked');
        $('#nri-admin-tbody .nri-bulk-chk').prop('checked', checked);
        selectedRids = [];
        if(checked){
            $('#nri-admin-tbody .nri-bulk-chk').each(function(){
                selectedRids.push(parseInt($(this).val()));
            });
        }
        updateBulkUI();
    });

    // Clear selection
    $(document).on('click','#nri-bulk-deselect',function(){
        selectedRids = [];
        $('#nri-admin-tbody .nri-bulk-chk, #nri-select-all-reqs').prop('checked', false);
        updateBulkUI();
    });

    // Called by nriLoadAdminRequests() (shortcodes.php) after every re-render
    // of the table — a fresh page/filter/search means the previous
    // selection no longer corresponds to what's on screen, so it's cleared
    // rather than silently going stale.
    window.nriResetBulkSelection = function(){
        selectedRids = [];
        updateBulkUI();
    };

    // Bulk delete requests (also used for the Requests tab's own rows —
    // Form Submissions has its own bulk-delete button/handler in
    // form-submissions.php, hitting the same nri_bulk_delete_requests
    // endpoint since a "submission" and a "request" are the same post).
    $(document).on('click','#nri-bulk-delete-requests',function(){
        if(selectedRids.length === 0){ alert('No requests selected.'); return; }
        var n = selectedRids.length;
        if(!confirm('Delete the selected ' + n + ' request' + (n>1?'s':'') + '? This also deletes their messages, tickets and uploaded documents. This cannot be undone.')) return;
        var $btn = $(this).text('Deleting…').prop('disabled', true);
        $.post(NRI.ajax_url,{
            action: 'nri_bulk_delete_requests',
            nonce: NRI.admin_nonce || NRI.nonce,
            request_ids: selectedRids
        }, function(r){
            $btn.text('🗑 Delete Selected').prop('disabled', false);
            if(r.success){
                selectedRids = [];
                if (window.nriLoadAdminRequests) window.nriLoadAdminRequests();
            } else {
                alert('Bulk delete failed: ' + (r.data && r.data.message ? r.data.message : 'Unknown error'));
            }
        }).fail(function(){ $btn.text('🗑 Delete Selected').prop('disabled', false); alert('Network error.'); });
    });

    // Bulk Excel export
    $(document).on('click','#nri-bulk-export-excel',function(){
        if(selectedRids.length === 0){ alert('No requests selected.'); return; }
        var $btn = $(this).text('Exporting...').prop('disabled', true);
        $.post(NRI.ajax_url,{
            action: 'nri_bulk_export_excel',
            nonce: NRI.nonce,
            request_ids: selectedRids
        }, function(r){
            $btn.text('📊 Export Selected (Excel)').prop('disabled', false);
            if(r.success && r.data && r.data.url){
                var a = document.createElement('a');
                a.href = r.data.url;
                a.download = r.data.filename || 'bulk-export.xlsx';
                document.body.appendChild(a); a.click(); document.body.removeChild(a);
            } else {
                alert('Export failed: ' + (r.data && r.data.message ? r.data.message : 'Unknown error'));
            }
        }).fail(function(){ $btn.text('📊 Export Selected (Excel)').prop('disabled', false); alert('Network error.'); });
    });

    // (Row checkboxes are written directly into each row's HTML by
    // nriLoadAdminRequests() in shortcodes.php, not patched on afterwards —
    // that's what actually makes the checkboxes appear on every render.)

})(jQuery);
// ── END Bulk Select ─────────────────────────────────────────────────────────

// ── Bulk Select & Delete (Admin Support Tickets Table) ──────────────────────
(function($){
    if (typeof NRI === 'undefined') return;

    var selectedTids = [];

    function updateTicketBulkUI(){
        var n = selectedTids.length;
        if(n > 0){
            $('#nri-ticket-bulk-toolbar').css('display','flex');
            $('#nri-ticket-bulk-count').text(n + ' ticket' + (n>1?'s':'') + ' selected');
        } else {
            $('#nri-ticket-bulk-toolbar').hide();
        }
    }

    $(document).on('change','#nri-support-tbody .nri-ticket-bulk-chk', function(){
        var tid = parseInt($(this).val());
        if($(this).is(':checked')){
            if(selectedTids.indexOf(tid) < 0) selectedTids.push(tid);
        } else {
            selectedTids = selectedTids.filter(function(t){ return t !== tid; });
            $('#nri-select-all-tickets').prop('checked', false);
        }
        updateTicketBulkUI();
    });

    $(document).on('change','#nri-select-all-tickets',function(){
        var checked = $(this).is(':checked');
        $('#nri-support-tbody .nri-ticket-bulk-chk').prop('checked', checked);
        selectedTids = [];
        if(checked){
            $('#nri-support-tbody .nri-ticket-bulk-chk').each(function(){
                selectedTids.push(parseInt($(this).val()));
            });
        }
        updateTicketBulkUI();
    });

    $(document).on('click','#nri-ticket-bulk-deselect',function(){
        selectedTids = [];
        $('#nri-support-tbody .nri-ticket-bulk-chk, #nri-select-all-tickets').prop('checked', false);
        updateTicketBulkUI();
    });

    // Called by nriLoadSupportTickets() (shortcodes.php) after every reload.
    window.nriResetTicketBulkSelection = function(){
        selectedTids = [];
        updateTicketBulkUI();
    };

    $(document).on('click','#nri-bulk-delete-tickets',function(){
        if(selectedTids.length === 0){ alert('No tickets selected.'); return; }
        var n = selectedTids.length;
        if(!confirm('Delete the selected ' + n + ' ticket' + (n>1?'s':'') + '? This cannot be undone.')) return;
        var $btn = $(this).text('Deleting…').prop('disabled', true);
        $.post(NRI.ajax_url,{
            action: 'nri_bulk_delete_tickets',
            nonce: NRI.admin_nonce || NRI.nonce,
            ticket_ids: selectedTids
        }, function(r){
            $btn.text('🗑 Delete Selected').prop('disabled', false);
            if(r.success){
                selectedTids = [];
                if (window.nriLoadSupportTickets) window.nriLoadSupportTickets();
            } else {
                alert('Bulk delete failed: ' + (r.data && r.data.message ? r.data.message : 'Unknown error'));
            }
        }).fail(function(){ $btn.text('🗑 Delete Selected').prop('disabled', false); alert('Network error.'); });
    });

})(jQuery);
// ── END Ticket Bulk Select ───────────────────────────────────────────────────

// ── Admin Dashboard SPA Controller ───────────────────────────────────────────
// Fixes the "every click reloads the whole page" problem across the admin
// dashboard: switching tabs (Requests/Submissions/Support/Fields/…) and
// opening a request's "View" detail now swap content inside
// #nri-admin-tab-container via AJAX instead of a full WordPress page
// navigation, while still keeping real, bookmarkable/shareable URLs in sync
// via the History API — so refresh, browser Back/Forward, and opening a
// link in a new tab all keep working exactly as before.
(function($){
    if (typeof NRI === 'undefined') return;

    var STATE_KEY = 'nri_admin_state_v1';

    // This controller now drives BOTH the admin dashboard and the client
    // dashboard — they're structurally the same problem (tab-container +
    // AJAX tab/detail loading instead of full page reloads), just with
    // different containers, endpoints, and default tabs. Exactly one of
    // these containers is ever on the page at once, so detecting it once
    // up front and branching on it here is simpler and less error-prone
    // than maintaining two near-identical copies of this controller.
    function detectSurface(){
        var $a = $('#nri-admin-tab-container');
        if ($a.length) {
            return { $el: $a, tabAction: 'nri_admin_load_tab', detailAction: 'nri_admin_load_request_detail', base: '/admin-dashboard', defaultTab: 'requests' };
        }
        var $c = $('#nri-client-tab-container');
        if ($c.length) {
            return { $el: $c, tabAction: 'nri_client_load_tab', detailAction: 'nri_client_load_request_detail', base: '/client-dashboard', defaultTab: 'dashboard' };
        }
        return null;
    }
    var SURFACE = detectSurface();

    // The browser's own scroll restoration fights with our AJAX content
    // swaps — it tries to restore scroll on popstate before our new
    // content (a different height than the old page) has even been
    // rendered, so the page visibly jumps once our own render finishes
    // and the layout shifts under it. Taking manual control and doing the
    // scroll restoration ourselves, AFTER the new content is in the DOM,
    // is what actually fixes the jump.
    if ('scrollRestoration' in history) { history.scrollRestoration = 'manual'; }

    // Pushes a new history entry, but first stamps the CURRENT scroll
    // position onto the entry being left — so if the user comes back to
    // it (Back button, or the "← All Requests" link, which now just
    // calls history.back()), we know exactly where to put them instead of
    // always snapping to the top.
    function pushHistoryState(state, url){
        var cur = history.state;
        if (cur) {
            var withScroll = {};
            for (var k in cur) { withScroll[k] = cur[k]; }
            withScroll.scrollY = window.scrollY;
            history.replaceState(withScroll, '', location.href);
        }
        history.pushState(state, '', url);
    }

    function stateGet(){
        try { return JSON.parse(sessionStorage.getItem(STATE_KEY)) || {}; }
        catch(e){ return {}; }
    }
    function stateSet(s){
        try { sessionStorage.setItem(STATE_KEY, JSON.stringify(s)); }
        catch(e){ /* private mode / quota — non-critical, just skip persistence */ }
    }
    window.nriAdminStateGet = stateGet;

    // Per-tab filter/search/page cache, read by nriLoadAdminRequests() (see
    // nri_admin_js() in shortcodes.php) so leaving and returning to a tab —
    // whether via the nav, a "back to list" click, or the browser's own
    // Back button — restores the same filtered/paginated view rather than
    // silently resetting it.
    window.nriSaveAdminListState = function(tab, listState){
        var s = stateGet();
        s.listState = s.listState || {};
        s.listState[tab] = listState;
        stateSet(s);
    };
    window.nriRestoreAdminListState = function(tab){
        var s = stateGet();
        return (s.listState && s.listState[tab]) || null;
    };

    // ── Background prefetch cache ────────────────────────────────────────
    // Goal: by the time the user actually clicks a tab or a "View" link,
    // the HTML is already sitting in memory, so the switch is instant with
    // no visible fetch/loading state. Tabs are prefetched in the
    // background right after the page settles; request-detail views are
    // prefetched on hover/touch (the ~150-300ms before a click lands is
    // enough time for the request to come back on a normal connection).
    var TAB_CACHE_TTL = 20000; // ms — after this, a cached tab is served
                                 // instantly but silently re-fetched in the
                                 // background so it doesn't go stale.
    var tabCache = {};          // { tabKey: { html, ts, loading:false } }
    var detailCache = {};       // { rid: { html, ts } }
    var detailCacheOrder = [];  // simple LRU eviction order
    var DETAIL_CACHE_MAX = 25;

    // If a background prefetch for this tab is already in flight when the
    // user actually clicks it, we must NOT start a second request — but we
    // also must NOT drop the click's callback, or the click just sits
    // there indefinitely waiting on a response that will never reach it.
    // So every caller's callback is queued against the one in-flight
    // request and all of them fire together when it resolves.
    function fetchTabInto(cacheObj, tab, cb){
        var entry = cacheObj[tab] = cacheObj[tab] || {};
        if (entry.loading) {
            if (cb) { entry.pending = entry.pending || []; entry.pending.push(cb); }
            return;
        }
        entry.loading = true;
        entry.pending = cb ? [cb] : [];
        $.post(NRI.ajax_url, {
            action: SURFACE ? SURFACE.tabAction : 'nri_admin_load_tab',
            nonce: NRI.admin_nonce || NRI.nonce,
            tab: tab
        }, function(r){
            entry.loading = false;
            var waiting = entry.pending || []; entry.pending = [];
            if (r && r.success) {
                entry.html = r.data.html;
                entry.tab = r.data.tab;
                entry.ts = Date.now();
                waiting.forEach(function(fn){ fn(r.data); });
            }
        }).fail(function(){
            entry.loading = false;
            var waiting = entry.pending || []; entry.pending = [];
            // Still flush pending callbacks (with no data) on failure, so a
            // click waiting on an in-flight prefetch — or the background
            // prefetch chain waiting to move to the next tab — doesn't
            // stall forever; each caller already handles "no data" safely
            // (nriAdminLoadTab falls back to its own error timeout, and
            // the background chain just moves on to the next tab).
            waiting.forEach(function(fn){ fn(null); });
        });
    }

    function prefetchTab(tab){
        var entry = tabCache[tab];
        var isFresh = entry && entry.html && (Date.now() - entry.ts) < TAB_CACHE_TTL;
        if (isFresh || (entry && entry.loading)) return;
        fetchTabInto(tabCache, tab);
    }
    window.nriPrefetchTab = prefetchTab;

    function prefetchRequestDetail(rid){
        if (!rid) return;
        var entry = detailCache[rid];
        var isFresh = entry && entry.html && (Date.now() - entry.ts) < TAB_CACHE_TTL;
        if (isFresh || (entry && entry.loading)) return;
        detailCache[rid] = detailCache[rid] || {};
        detailCache[rid].loading = true;
        $.post(NRI.ajax_url, {
            action: SURFACE ? SURFACE.detailAction : 'nri_admin_load_request_detail',
            nonce: NRI.admin_nonce || NRI.nonce,
            request_id: rid
        }, function(r){
            detailCache[rid].loading = false;
            if (r && r.success) {
                detailCache[rid].html = r.data.html;
                detailCache[rid].ts = Date.now();
                var idx = detailCacheOrder.indexOf(rid);
                if (idx !== -1) detailCacheOrder.splice(idx, 1);
                detailCacheOrder.push(rid);
                while (detailCacheOrder.length > DETAIL_CACHE_MAX) {
                    delete detailCache[detailCacheOrder.shift()];
                }
            }
        }).fail(function(){ detailCache[rid].loading = false; });
    }

    // Invalidate cached tab HTML after any action that changes what a tab
    // would show (delete/bulk-delete/create/status change/etc.), so the
    // instant-from-cache path never serves stale data for long. Individual
    // handlers call this; a blanket invalidation on any AJAX POST whose
    // action name suggests a mutation is the low-maintenance fallback.
    function invalidateTabCache(tab){
        if (tab) { delete tabCache[tab]; }
        else { tabCache = {}; }
    }
    window.nriInvalidateAdminTabCache = invalidateTabCache;

    $(document).ajaxSuccess(function(event, xhr, settings){
        if (!settings || !settings.data || typeof settings.data !== 'string') return;
        if (!/nri_(bulk_delete|delete_request|delete_documents|delete_ticket|update_status|create|submit)/.test(settings.data)) return;
        invalidateTabCache(); // simplest correct behavior: drop the whole
                               // cache so the next switch is a real fetch.
    });

    function setActiveNav(tab){
        // .nri-nav-item is the admin dashboard's nav class; the client
        // dashboard's links carry both .nri-nav-link (their existing
        // style) AND .nri-nav-item (added purely so this one selector
        // works for both — see nri_client_nav() in shortcodes.php).
        $('.nri-nav-item').removeClass('active');
        if (tab) { $('.nri-nav-item[data-tab="' + tab + '"]').addClass('active'); }
    }

    function loadingHtml(label){
        return '<div style="padding:60px 20px;text-align:center;color:#94a3b8;">' + (label || 'Loading…') + '</div>';
    }
    function errorHtml(msg){
        return '<div style="padding:60px 20px;text-align:center;color:#ef4444;">' + (msg || 'Something went wrong. Please try again.') + '</div>';
    }

    // Loads one admin-dashboard tab's content via AJAX (reusing the exact
    // same server-side render function a full page load would use — see
    // nri_ajax_admin_load_tab in ajax.php) and swaps it into the tab
    // container without touching the header/nav around it.
    function renderTab(data, $container, opts){
        $container.attr('data-current-tab', data.tab).html(data.html);
        setActiveNav(data.tab);
        var s = stateGet(); s.currentTab = data.tab; stateSet(s);
        if (!opts.noPush) {
            var url = NRI.home_url + SURFACE.base + (data.tab !== SURFACE.defaultTab ? '?tab=' + data.tab : '');
            pushHistoryState({ nriAdmin: true, tab: data.tab }, url);
        }
        // Tab clicks never move the scroll position on their own — the
        // page just stays exactly where it was (that's the "same state"
        // an app-like tab switch should feel like). The only time we DO
        // move it is coming BACK to a tab via popstate/"← All Requests",
        // where opts.scrollY restores exactly where the user had
        // scrolled to on that tab before leaving it.
        if (typeof opts.scrollY === 'number') { window.scrollTo(0, opts.scrollY); }
        // The Requests and Support tabs' list-loading script
        // (nri_admin_js() in shortcodes.php) is emitted only ONCE,
        // outside #nri-admin-tab-container, so it never re-executes on
        // an AJAX tab-swap the way each other tab's own inline <script>
        // does. Without this, returning to either tab would show an
        // empty table forever ("Loading…" with nothing to populate it).
        if (data.tab === 'requests' && window.nriLoadAdminRequests) {
            window.nriLoadAdminRequests();
        } else if (data.tab === 'support' && window.nriLoadSupportTickets) {
            window.nriLoadSupportTickets();
        }
    }

    // Switches to a tab. If it's already sitting in the prefetch cache
    // (fresh, or even slightly stale), it renders IMMEDIATELY — no spinner,
    // no visible fetch — and, if stale, quietly re-fetches in the
    // background to refresh the cache for the next switch. Only a genuine
    // cold cache (first visit to a tab this session) falls back to a
    // real-time fetch, and even that skips the "Loading…" placeholder
    // unless the response takes long enough to actually need one.
    function nriAdminLoadTab(tab, opts){
        opts = opts || {};
        if (!SURFACE) return false; // not on a SPA dashboard — nothing to do
        var $container = SURFACE.$el;

        var cached = tabCache[tab];
        if (cached && cached.html) {
            renderTab(cached, $container, opts);
            if ((Date.now() - cached.ts) >= TAB_CACHE_TTL) {
                fetchTabInto(tabCache, tab); // stale — refresh silently for next time
            }
            return true;
        }

        // Cold cache: fetch now, but only show a loading placeholder if it
        // turns out to be slow, so a quick connection never sees one.
        var showedLoading = false;
        var loadingTimer = setTimeout(function(){
            showedLoading = true;
            $container.html(loadingHtml());
        }, 200);
        fetchTabInto(tabCache, tab, function(data){
            clearTimeout(loadingTimer);
            if (data) {
                renderTab(data, $container, opts);
            } else {
                // fetch genuinely failed (data is null — see fetchTabInto's
                // .fail() handler) — show the error immediately instead of
                // waiting on the 15s fallback below.
                $container.html(errorHtml('Connection error loading this tab. Please try again.'));
            }
        });
        // Fallback in case something unexpected leaves the callback above
        // never firing at all (e.g. a genuinely hung request).
        setTimeout(function(){
            var entry = tabCache[tab];
            if (entry && !entry.loading && !entry.html && showedLoading) {
                $container.html(errorHtml('Connection error loading this tab. Please try again.'));
            }
        }, 15000);
        return true;
    }
    window.nriAdminLoadTab = nriAdminLoadTab;

    // Loads a single request's detail view via AJAX (same render function
    // the standalone /request/{id} page uses — see
    // nri_ajax_admin_load_request_detail in ajax.php) into the tab
    // container, so "View" never has to leave the dashboard.
    function renderDetail(html, rid, $container, opts){
        setActiveNav(null); // no tab is "current" while viewing a single request
        $container.html(html);
        if (!opts.noPush) {
            pushHistoryState({ nriAdmin: true, rid: rid }, NRI.home_url + '/request/' + rid);
        }
        // Same rule as tab clicks: opening a request never forces a scroll
        // jump on its own. Coming BACK from it restores the exact
        // position via opts.scrollY (see pushHistoryState/popstate).
        if (typeof opts.scrollY === 'number') { window.scrollTo(0, opts.scrollY); }
    }

    // Same instant-from-cache approach as nriAdminLoadTab: if this request
    // was already prefetched (typically because the user hovered/touched
    // the "View" link just before clicking it — see the hover-prefetch
    // binding below), it renders with zero visible fetch time.
    function nriAdminOpenRequestDetail(rid, opts){
        opts = opts || {};
        if (!SURFACE) return false; // not embedded — let the real <a href> navigate normally
        var $container = SURFACE.$el;

        var cached = detailCache[rid];
        if (cached && cached.html) {
            renderDetail(cached.html, rid, $container, opts);
            return true;
        }

        var showedLoading = false;
        var loadingTimer = setTimeout(function(){
            showedLoading = true;
            $container.html(loadingHtml('Loading request…'));
        }, 200);
        prefetchRequestDetail(rid);
        var poll = setInterval(function(){
            var entry = detailCache[rid];
            if (entry && entry.html) {
                clearInterval(poll);
                clearTimeout(loadingTimer);
                renderDetail(entry.html, rid, $container, opts);
            } else if (entry && !entry.loading) {
                clearInterval(poll);
                clearTimeout(loadingTimer);
                if (showedLoading) { $container.html(errorHtml('Connection error. Please try again.')); }
            }
        }, 100);
        return true;
    }
    window.nriAdminOpenRequestDetail = nriAdminOpenRequestDetail;

    // Hover/touch prefetch — start fetching a tab or a request's detail
    // view the moment the pointer signals intent (mouseenter, or
    // touchstart on mobile), so by the time the click actually lands the
    // content is usually already cached and the switch is instant.
    $(document).on('mouseenter touchstart', '.nri-nav-item[data-tab]', function(){
        prefetchTab($(this).data('tab'));
    });
    $(document).on('mouseenter touchstart', '.nri-view-request-link', function(){
        prefetchRequestDetail($(this).data('rid'));
    });

    // Tab nav clicks — progressive enhancement: the <a href> stays real
    // (works with no JS, middle-click, "open in new tab"); a plain left
    // click is intercepted so the tab swaps in place instead.
    $(document).on('click', '.nri-nav-item[data-tab]', function(e){
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.which === 2) return; // let modified clicks behave normally
        var handled = nriAdminLoadTab($(this).data('tab'));
        if (handled) { e.preventDefault(); }
    });

    // "View" request links — same progressive-enhancement approach.
    $(document).on('click', '.nri-view-request-link', function(e){
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.which === 2) return;
        var handled = nriAdminOpenRequestDetail($(this).data('rid'));
        if (handled) { e.preventDefault(); }
    });

    // "← All Requests" back link inside an embedded detail view — this is
    // conceptually a Back action, so it now IS one: history.back() reuses
    // the exact same popstate handling real Back/Forward use below,
    // including restoring the list's scroll position (see
    // pushHistoryState()) instead of duplicating that logic here and
    // risking it drifting out of sync.
    $(document).on('click', '.nri-back-to-admin-list', function(e){
        if (!SURFACE) return; // standalone page — let it navigate normally
        e.preventDefault();
        if (history.state && history.state.nriAdmin) {
            history.back();
        } else {
            // No SPA history to go back to (e.g. the detail view was the
            // very first page loaded, opened via a direct link) — fall
            // back to loading the list tab fresh.
            var s = stateGet();
            nriAdminLoadTab(s.currentTab || SURFACE.defaultTab);
        }
    });

    // Browser Back/Forward — mirrors whatever nriAdminLoadTab /
    // nriAdminOpenRequestDetail last pushed, so the dashboard's own history
    // entries behave like a normal multi-page site would, without actually
    // reloading the page each time.
    window.addEventListener('popstate', function(e){
        if (!SURFACE) return;
        var st = e.state;
        // st.scrollY (stamped by pushHistoryState onto the entry being
        // left, right before navigating forward) is where THIS entry's
        // page was scrolled to when the user was last on it — restoring
        // it here is what stops the visible jump when coming back.
        var scrollOpts = (st && typeof st.scrollY === 'number') ? { scrollY: st.scrollY } : {};
        if (st && st.rid) {
            nriAdminOpenRequestDetail(st.rid, $.extend({ noPush: true }, scrollOpts));
            return;
        }
        if (st && st.tab) {
            nriAdminLoadTab(st.tab, $.extend({ noPush: true }, scrollOpts));
            return;
        }
        // No captured state (e.g. the very first history entry, from the
        // original full page load) — fall back to reading the URL itself.
        var m = window.location.pathname.match(/\/request\/(\d+)/);
        if (m) { nriAdminOpenRequestDetail(parseInt(m[1], 10), { noPush: true }); return; }
        var params = new URLSearchParams(window.location.search);
        nriAdminLoadTab(params.get('tab') || SURFACE.defaultTab, { noPush: true });
    });

    // Stamp the initial page-load history entry with the same state shape
    // the SPA controller pushes for later entries, so the first Back press
    // after a tab switch resolves via e.state rather than the URL fallback.
    $(document).ready(function(){
        if (!SURFACE) return;
        var $container = SURFACE.$el;
        var initialTab = $container.attr('data-current-tab') || SURFACE.defaultTab;
        setActiveNav(initialTab);
        var s = stateGet(); s.currentTab = initialTab; stateSet(s);
        history.replaceState({ nriAdmin: true, tab: initialTab }, '', window.location.href);

        // NOTE: there is deliberately no automatic "warm every other tab in
        // the background" step here (an earlier version of this file had
        // one). On a typical shared-hosting PHP-FPM setup with only a
        // couple of worker processes, ANY extra background request —
        // sequenced or not — can still land at the exact moment the user
        // clicks something for real and make that real click wait behind
        // it. The only prefetching left is hover/touch-triggered (see the
        // mouseenter/touchstart bindings below), which only ever fires
        // immediately before an actual click and costs nothing when the
        // user doesn't follow through.
    });

})(jQuery);
// ── END Admin Dashboard SPA Controller ───────────────────────────────────────
