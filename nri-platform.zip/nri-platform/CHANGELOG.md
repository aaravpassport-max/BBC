# NRI Platform – Changelog

---

## v6.27.0 — Documents Upload in the Background; Submission No Longer Shows a False Error
**Release Date:** September 25, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Root cause: submission and document upload were one request

On both the Standalone Form (`[nri_standalone_form]`) and the Regular Request Form (`[nri_request_form]`) — they share the same markup and the same `nri_ajax_create_request()` handler, so both had this bug — clicking Submit sent the field data **and every selected document** to the server in a single multipart request, then waited for the whole thing (including per-file thumbnail generation) to finish before showing anything.

On a slow or unstable connection, the file bytes could take long enough that the browser's own request timed out — but the server, still processing, very often finished successfully anyway a few seconds later and created the request. The browser had already shown a "connection error" / "submission failed" message and given the student a **Submit** button that still worked, so a confused retry could create a **second, duplicate request** for the same application — the exact failure mode reported.

### ✅ Fix: upload starts on file select, not on Submit

- **New behavior**: the moment a document is selected, it starts uploading in the background (`nri_pending_upload`, a new nopriv AJAX endpoint — students often don't have an account yet at this point). Thumbnail generation and AVIF/WebP sanitizing happen then, not at submit time. The dropzone shows a live per-file status (Uploading… / Uploaded / a Retry link on failure).
- **Submit is now field-data only.** It never sends file bytes — only the IDs of whichever background uploads have already finished (`pending_upload_ids[]`). This is why it's fast regardless of document size, and why a slow document can no longer cause a false "submission failed" for an application that actually went through.
- **Still uploading when Submit is clicked?** The request is created immediately from the field data; the browser does **not** navigate away (which would cancel the in-flight upload) — it shows an in-page success confirmation with the request ID, keeps the upload running, and automatically links it to the new request the moment it finishes (`nri_attach_pending_document`), polling client-side once a second. Once nothing is left in flight, or the student clicks "Continue to Dashboard," they proceed normally. If a document fails outright, that's now shown as a separate, non-blocking note ("N document(s) could not be uploaded — add them from your dashboard"), never as an application-submission error.
- **True duplicate-submission fix, server-side:** the browser now sends a per-page-load `submission_token` with every create-request call. The server caches the response against that token for 10 minutes; if the exact same submission is retried (a client-side timeout, or a confused double-click), the server replays the **original** success response instead of creating a second request. This is what actually eliminates "shows an error even though the application was created" — even in the rare case a resubmission does happen, it can no longer duplicate the request.
- Required-document validation is unchanged client-side (still checks a file was selected) and extended server-side to also recognize `pending_upload_ids[]`, so background-uploaded documents still satisfy a required-file field.
- Housekeeping: an upload that's never claimed (a student picks a file, then abandons the form) is now swept up automatically after 48 hours by a new daily cron job, instead of sitting in the media library forever.

### Verified

- `php -l` clean across the whole plugin; `node --check` clean on `assets/js/nri-app.js`, both from the working tree and re-checked from inside the shipped zip.
- Built a Playwright test harness that loads the real, unmodified `nri-app.js` against markup transcribed from the actual form output, with a mock AJAX layer standing in for the new WordPress endpoints (this sandbox has no live WordPress/MySQL to test against). 10 assertions, all passing, zero browser console/JS errors:
  - a selected file starts uploading immediately, not on Submit;
  - Submit sends the attachment ID, never raw file bytes;
  - a fast-finishing upload redirects immediately, exactly like before;
  - a still-uploading file at submit time does **not** block or wait — the request is created immediately, submit sends no unfinished IDs;
  - the in-page success panel appears with the request ID and a background-upload note, without forcing navigation;
  - the late-finishing upload is automatically attached to the created request once it completes;
  - the background note updates to "All documents uploaded" once done;
  - required-file validation still blocks submission client-side when no file is selected;
  - a double-click on Submit fires exactly one create-request call.
- Manually re-read the full modified `nri_ajax_create_request()` end to end (idempotency short-circuit → required-file check → user/account creation → post creation → background-upload token stamp → pending-ID claiming with ownership check → legacy raw-file fallback → response caching) to confirm the control flow is correct.
- **Not verified in this pass** (no live WordPress/MySQL/PHP-FPM environment available here): an actual browser hitting a real WordPress install, real database row verification, the cron cleanup job actually firing on schedule, and mobile-device testing. These need to be checked on the live site — the request/network/DB behavior to look for is exactly what's described above.

---

## v6.26.0 — Fixed Critical Error on Settings → General
**Release Date:** September 23, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: "There has been a critical error on this website" on Settings → General Settings

`includes/smtp.php` (the built-in SMTP configuration module — sender identity, SMTP host/port/credentials, the "Send Test Email" button, and the `phpmailer_init` hook that actually routes outgoing mail through the configured SMTP server) defines `nri_get_smtp_settings()`, which the General Settings tab calls to render the form. The file was never added to the plugin's loader list (`nri_load_all()` in `nri-platform.php`), so `nri_get_smtp_settings()` didn't exist at runtime — a fatal "call to undefined function" the moment that tab rendered, which WordPress shows as a critical error page. Every other Settings tab (Email Templates, Quick Replies, Holidays, Internal Statuses) was unaffected since none of them touch SMTP.

Added `'smtp'` to the include list in `nri_load_all()`. This also fixes a second, previously invisible problem: because the file was never loaded, the `phpmailer_init` hook that makes WordPress actually use your configured SMTP settings was never registered either — so even a fully filled-in SMTP configuration was silently being ignored in favor of WordPress's default mail sending. Both are now active.

---

## v6.25.0 — Student Form Submission No Longer Waits on Admin Email/WhatsApp Notifications
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🚀 Fixed: Slow "Submitting..." on the student request form

Students reported the new-request form taking a long time to submit. Root cause: `nri_ajax_create_request()` (the AJAX handler behind form submit) was making the admin-notification email (`nri_notify_new_request()`) and, more significantly, the WhatsApp notification (`nri_wa_on_new_submission()`) *synchronously*, before sending its response back to the browser. The WhatsApp call in particular goes through the third-party CallMeBot API with a 15-second timeout **per recipient** — one blocking call for the admin number, plus one more sequential blocking call for every number configured in `nri_wa_staff_numbers`. With 2–3 staff numbers configured, or a slow/unresponsive CallMeBot API, this alone could add many extra seconds (or up to 15s × N in the worst case) to what the student experienced as "submitting" before the success screen appeared.

Both notifications are now deferred to run *after* the JSON response has already been handed back to the student's browser, via a new `nri_defer_after_response()` helper in `includes/ajax.php`: it registers a shutdown callback that flushes/closes the HTTP response immediately (`fastcgi_finish_request()` where available, with a manual output-buffer-flush fallback on hosts without PHP-FPM) and only then runs the email + WhatsApp calls. The notifications still fire exactly as before — same content, same recipients — just a moment later, in the background, instead of holding up the student's submit button.

No other behavior changes: request creation, file uploads, and the requirement-description generation are unaffected and still happen before the response is sent.

---

## v6.24.0 — Action Buttons Moved to a Single Row Under the Left Column; Sober Button Colors
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🎨 Changed: Copy/Desc/Docs/Delete/View now sit in one row at the bottom of the LEFT column

They previously lived in the right-hand status panel as a 2-up button grid. They now sit as a single row (`Copy | Desc | Docs | Delete | View Full Request`) directly under the Applicant/Academic/Location/Remarks details in the left column instead — these buttons act on the request's own data (its details, its description, its documents, itself), not on its handling state, so they read as that column's toolbar. The right column now holds only Status, Internal Status, the progress bar, and the Quote/Delivery/Manager/Vendor meta — purely "how this request is being handled."

### 🎨 Changed: "View Full Request" and "Delete" use sober, muted colors instead of solid ones

Added `.nri-btn-primary-soft` (light indigo tint, `#eef2ff` background with `#3949ab` text) and `.nri-btn-danger-soft` (light red tint, `#fef2f2` background with `#b91c1c` text) as calmer alternatives to the usual solid `.nri-btn-primary`/`.nri-btn-danger`, used only on this action row — the rest of the app's buttons (e.g. the support-ticket table's Delete) are unchanged. They read as clearly "the primary one" / "the delete one" next to the existing outline Copy/Desc/Docs buttons without the visual weight of a fully saturated button.

Verified by rendering the actual, unmodified card-rendering code in a headless browser before shipping — all five actions sit on one row, right column is unaffected, and the softened colors render as intended.

---

## v6.23.0 — Wider Status Panel with Labels, Narrower Left Column
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🎨 Changed: right-hand status panel is wider, with "Status"/"Internal" labels back

The card's side column (status selects, progress bar, operational meta, actions) grows from `minmax(210px,240px)` to `minmax(260px,320px)`. With the extra room, the Client Status and Internal Status selects are back to their own labeled row each — a small fixed-width "STATUS"/"INTERNAL" caption in front of the select — instead of sharing one unlabeled row, so which select is which no longer relies only on color/tooltip. Verified by rendering the actual card code that the caption fits without clipping into the select box.

### 🎨 Changed: left column's field values truncate narrower

`.nri-rc-val`'s max-width dropped from 260px/320px (≥1400px) to 200px/250px, so the submitted-form values in the left column read as a tighter, less sprawled block rather than stretching to fill whatever width remains once the wider side column is subtracted.

---

## v6.22.2 — Reduced Dashboard Max-Width to Cut Down Dead Space Below Cards
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🎨 Changed: dashboard shell narrowed from 1920px to 1560px

On an actual wide monitor, the 1920px ceiling (v6.21.0) let each request card's left column stretch much wider than a short field list needs — confirmed by rendering it — which left a large empty rectangle below the data on cards with fewer fields, instead of the extra width doing anything useful. `.nri-admin-wrap` and `.nri-dash-wrap` now cap at 1560px: still fills an ordinary monitor edge to edge rather than being boxed into the old 1200px column, but no longer stretches request cards' content column so wide on very large monitors that short requests read as mostly empty space.

---

## v6.22.1 — Fix: Two-Column Card Was Leaving Huge Dead Whitespace
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: v6.22.0's two-column card looked stretched and empty, not compact

Screenshots from the live dashboard showed the two-column card redesign (v6.22.0) producing very tall cards with large blank gaps — the opposite of the "compact, easy to scan" goal. Root cause, confirmed by actually rendering the card in a headless browser rather than just reading the CSS: the card grid defaulted to `align-items:stretch`, and the right-hand status panel had a roughly fixed height (its own row for Status, its own row for Internal Status, plus a bottom-pinned `margin-top:auto` action block) regardless of how much form data a given request had. That fixed-height side panel then force-stretched the left column to match it — so a request with only 2 fields ended up the same tall card height as one with 9 fields, with the difference showing up as dead space.

Fixed with three changes, verified visually (not just by reading CSS) using a real Chromium render of the actual, unmodified card-rendering code:
- The grid now uses `align-items:start` — each column is only as tall as its own content, instead of being force-stretched to match its sibling.
- Client Status and Internal Status are back to one compact row side by side (in the side column, not the old shared top row) instead of two stacked rows — removing a whole row of fixed height from every single card.
- Quote/Delivery/Manager/Vendor now sit in a compact 2×2 grid instead of four stacked rows, and the action buttons sit in normal document flow instead of being pinned to a forced bottom edge.

The side panel is now genuinely compact and content-sized, and card height reflects what's actually in a given request rather than a one-size-fits-all minimum imposed by the status panel.

---

## v6.22.0 — Two-Column Request Cards: Main Details Left, Status/Actions Right
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🎨 Redesigned: each request card is now a two-column layout, not a wider single column

v6.21.0 widened the dashboard shell itself; this pass restructures the *content* rather than just stretching it further. Each card on the "Requests" admin tab now splits into:
- **Left (`.nri-rc-main`)** — the request's own identity and submitted form data: title/ID, client/email/service, and the grouped Applicant / Document & Academic / Location & Delivery / Remarks fields. This column absorbs the dashboard's extra width, since it's where variable-length data actually benefits from more room.
- **Right (`.nri-rc-side`)** — a fixed-width (230–272px) panel for everything about the request's *current handling*: the date, the client-facing and internal status selects (now stacked with "Status"/"Internal" captions instead of squeezed side by side), a new compact pipeline-progress bar, the admin-operational Quote/Delivery/Manager/Vendor line as stacked key:value rows, and the action buttons in a 2-up grid with "View Full Request" spanning both columns as the standout primary action, pinned to the column's bottom edge.

Below ~780px there isn't room for two real columns, so the side panel drops beneath the main content instead of squeezing into an unreadable sliver.

### ✨ Added: at-a-glance pipeline-progress bar

Each card's status panel now includes a slim, colored progress fill showing how far the request has moved through the 7-stage pipeline (Received → Under Review → Ready for Processing → Approved → Processing → Dispatched → Completed) — the same stage order the request-detail page's own pipeline view uses, so it reads consistently in both places. `rejected` and `service_not_available` render a full bar in their own status color instead of a stage fraction, since they're terminal off-ramps rather than further points on the pipeline.

---

## v6.21.0 — Full-Width, Proportionally-Scaled Dashboard Layout
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🎨 Changed: both dashboards (staff admin + client portal) now use the full available screen width

`.nri-admin-wrap` (the staff "Admin Dashboard" — Requests tab, stat cards, filters, request cards, tables) and `.nri-dash-wrap` (the client-facing "My Requests" portal) were both capped at a fixed `max-width:1200px`, leaving wide monitors with large empty margins on either side. Both now stretch to fill the browser width up to a generous ceiling (1920px, so line lengths and card rows stay readable rather than sprawling on ultra-wide screens), with side padding driven by `clamp()` instead of a fixed value — the gutter grows smoothly with the viewport so content never sits flush against the edge at any width, without a jarring jump at a breakpoint.

### 🎨 Changed: every child component scales proportionally instead of just stretching

Rather than leaving the extra width as dead space around unchanged components, sizing throughout the dashboard now scales with the viewport via `clamp()`:
- Header title/subtitle, tab content padding, stat-card padding and stat numbers, table cell padding, request-card padding, and the request card's field-group spacing all grow gently on wider screens.
- The toolbar's search input now grows to fill spare space (`flex:1 1 260px`, capped at 440px) instead of sitting at its old cramped width next to the filter selects.
- On screens ≥1400px, the request card's value fields get more room before truncating (280px → 380px) and the client "My Requests" card grid steps its minimum card width up (300px → 340px) so a full-width screen resolves to a few comfortably-sized cards per row instead of auto-fill packing in many narrow ones.

The result is a layout that feels like a proper full-screen dashboard application at any screen size — not a version of the old 1200px layout with the browser chrome pushed further out.

---

## v6.20.1 — Fix: Client Status Dropdown Missing Statuses (Card, Filter, and a Pre-Existing Save Bug)
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: card's inline client-status dropdown was missing 2 of 9 real statuses

The client-facing status `<select>` on each Request List card (added in v6.19.0) was built from a hardcoded list in `nri_admin_js()` that had drifted to only 7 statuses — it was missing `ready_for_processing` ("Ready for Processing") and `service_not_available` ("Service Not Available"), even though both are real, already-live statuses used elsewhere in the plugin (the request-detail page's own "Update Status" panel, the client-facing pipeline view, and their own notification email templates). The card dropdown now offers the full, correct 9-status set: Received, Under Review, Ready for Processing, Approved, Processing, Dispatched, Completed, Service Not Available, Cancelled.

The "All Statuses" filter dropdown and the stat-cards row on the Requests admin tab used the same incomplete list and are fixed for the same reason.

### 🐛 Fixed: "Ready for Processing" had no label/color, so it silently degraded

`nri_status_label()` and `nri_status_color()` (the plugin's single source of truth for how a status is displayed) had no entry for `ready_for_processing`, so anywhere it was shown it fell back to a generic auto-capitalized label and flat gray color instead of "Ready for Processing" in its proper blue. This is also why the missing dropdown entry went unnoticed rather than throwing an obvious error — the fallback made it look intentional. Both functions now have a proper entry for it.

### 🐛 Fixed (pre-existing, unrelated to the card feature): "Ready for Processing" could never actually be saved

While checking this deeply, a more serious and fully independent bug was found in the server-side handler behind the "Update Status" button — the one on the request-detail page's staff panel, which has offered "Ready for Processing" as a dropdown choice for a long time already. Its validation whitelist (`$valid` in `nri_ajax_update_status_v2()`) was also missing `ready_for_processing`, so choosing it and clicking "Update Status" would silently fail with "Invalid status." — regardless of the card feature, and predating it. This is now fixed, so the status can actually be saved from both the staff panel and the card.

---

## v6.20.0 — Card Layout Refinement: Statuses Side by Side, Student Details Flow Horizontally
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🎨 Changed: Internal Status moved next to Client Status

Internal Status used to be its own line below the client info. It's now in the card's top row, right next to the client-facing status select, separated by a small vertical divider — both are still independently editable inline exactly as before, just visually paired instead of stacked.

### 🎨 Changed: student details now flow left-to-right instead of stacking

The Applicant / Document & Academic / Location & Delivery groups (each request's submitted form data) used to each get their own full-width row. Now that cards are full-width (v6.19.0), they flow side by side across the row instead, with a light divider between groups, wrapping to a new row only when they run out of space — a noticeably more compact, scan-friendly use of the extra width. Remarks (often longer free text) is deliberately kept on its own full-width row rather than folded into that flow, where it would either truncate awkwardly or push everything else around it.

---

## v6.19.0 — Client Status Editable From the Card + One Full-Width Card Per Row
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### ✨ Added: change the client-facing status directly from the Request List card

Each request card's status used to be a read-only chip — changing it required opening the request detail page first. It's now a colored `<select>` right in the card's title row: pick a new value and it saves immediately via the same status-update logic the detail page has always used (history log entry, the client notification email, everything unchanged) — just without leaving the list.

### 🎨 Changed: one full-width card per row instead of a multi-column grid

The Requests list used to lay cards out in a responsive grid (as many side-by-side columns as would fit). Each request now gets its own full-width row instead, so the list reads top-to-bottom like a scan-friendly list rather than a wall of tiles — and since a card is no longer squeezed into a fixed column width, its content (Applicant/Academic/Location & Delivery lines, the quote/manager/vendor line) has more room to lay out without truncating or wrapping as aggressively.

---

## v6.18.0 — Internal Status (CRM Pipeline) System
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** Yes (new table, auto-runs, safe)

### ✨ Added: a full staff-only internal workflow-status layer, separate from the client-facing status

A new **Internal Status** system gives staff a proper CRM-style pipeline on top of the existing client-facing request status, without touching or replacing it. **This is strictly internal** — it is never sent to, or rendered for, a client: not on their dashboard, their request page, in any email, or in any notification. Every place it's used (the Requests-tab filter bar, the request card's status selector, the new admin settings section) lives entirely inside the staff-only admin dashboard, which is gated by `nri_require_staff()`/`nri_require_admin()` on every request.

**The 21-stage pipeline**, seeded in this exact order (Inquiry → ... → Service Not Required Any More): Inquiry, Need to Work on Query, High Quality Prospect, Follow Up, Under Review – For Feasibility Check, Feasibility Check Required, Awaiting Client Decision – Pending, Quotation to be Sent, Quotation Sent, Waiting for Docs, Documents Received, Payment Received, PMT RECVD – Work Not Started, Assigned and In Progress, Work Completed, Delivered, No Response, High Charges – Lost, Late Response – Lost, Not Able to Serve, Service Not Required Any More.

**Filter bar:** compact pill buttons at the top of the Requests list, one per status plus "All", each showing a live count. The active filter is visually highlighted; on narrow screens the bar scrolls horizontally instead of wrapping and breaking the page layout. The chosen filter is preserved the same way the existing status/search/date filters already are (survives switching tabs and coming back).

**Change status inline:** every request card now shows an "Internal:" selector, colored to match its current stage. Changing it fires immediately via AJAX — no page reload, and no need to open the request detail page first.

**Manage the pipeline (Settings → 🏷️ Internal Statuses, administrator-only):** add a new status, rename/recolor an existing one, reorder the whole list with ▲▼ arrows, activate/deactivate, or delete. Deactivating removes a status from the choices offered for *new* assignments while every request already on it keeps that exact label — nothing about existing requests changes. Delete is only offered when zero requests currently use that status; otherwise it explains why and suggests deactivating instead.

**How it works under the hood:** a new `wp_nri_internal_statuses` table (slug, label, color, sort order, active flag) — completely separate from the existing client-facing `status` postmeta and its small fixed enum (`nri_status_label()`/`nri_status_color()` in `includes/helpers.php`, untouched). A request's assigned stage is its own `internal_status` postmeta key, defaulting to "Inquiry" for any request that's never had one explicitly set (matching how the client-facing status already defaults to "Received"/`submitted`). The migration that creates this table for existing installs runs automatically on the next admin page load — no reactivation needed.

---

## v6.17.0 — "Change Save Folder" Control + Form Details Download Fixed to Match
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### ✨ Added: a way to change the remembered download folder

v6.16.0 made every Docs / Download All / Download Selected download reuse
the same remembered folder after the first pick — which fixed "having to
navigate to find it," but left no way to point future downloads somewhere
else short of clearing browser site data. Added a **"📁 Change Save
Folder"** button in three places: the Requests table toolbar (next to
Search/Filter/Reset), the request-detail Documents panel, and the Form
Details Documents panel. Clicking it forgets the current folder and opens
the picker immediately so a new one can be chosen; cancelling leaves
nothing changed. It's one shared setting for the whole browser (not
per-request), so any one of the three buttons updates it everywhere.

### 🔧 Fixed: Form Details panel's Download All/Selected still used the old per-file/ZIP path

While wiring up the new button, found that `nriFdBulkDownload()` (the
Download All/Selected buttons on the **Form Details** documents panel)
had never been switched over to the single-folder download added in
v6.15.0 — it was still downloading each file individually (or as a ZIP,
depending on server response). It now goes through the same
`nriSaveFilesAsFolder()` path as every other download button in the
plugin, with the same automatic fallback to individual downloads on
browsers without the File System Access API.

---

## v6.16.0 — Docs Download Remembers Where You Save, So You're Never "Taken Away"
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🔧 Fixed: no more manually navigating/searching for the downloaded folder

After v6.15.0, Docs correctly created one real folder with all documents
inside it — but the browser gives a web page no way to open the OS file
explorer at that folder afterward (no browser — Chrome, Edge, Firefox,
or Safari — exposes that ability to any website; this is a hard, universal
browser security restriction, not something this plugin can route around).
So after the first save, the person still had to remember and manually
browse to wherever they'd picked.

Fixed the actual pain, since we can't "open Explorer" for you: **the
location is now only ever asked once.** The very first time you click
Docs, the folder picker opens as before and you choose a location. From
then on, every future Docs / Download All / Download Selected click reuses
that exact same remembered folder automatically — no picker, no
re-navigating — so every request's subfolder always lands in the one place
you already have open. (The browser's native folder picker itself also
already defaults to your last-used folder if it ever needs to ask again,
e.g. if permission is revoked.)

A small on-screen confirmation ("Saved to '<folder> / <request folder>' —
same folder every time, no need to look elsewhere.") replaces the old
alert() popup, so a successful save no longer interrupts you with a dialog
to dismiss — it just confirms where things went, in the corner, for a few
seconds.

**How it works:** the chosen parent folder is remembered as a
`FileSystemDirectoryHandle` in IndexedDB (`nriGetParentDirHandle()` in
`assets/js/nri-app.js`). Each Docs click first tries the stored handle
(re-confirming write permission, which the browser may occasionally
re-prompt for on its own) before ever falling back to asking again.

*Still true from v6.15.0:* this uses the File System Access API, which
only exists in Chrome/Edge over HTTPS; Firefox, Safari and non-HTTPS
installs fall back to individual downloads (there is no ZIP-free
alternative on those).

---

## v6.15.0 — "Docs" Now Downloads One Real Folder (Not Per-File Downloads)
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🔧 Fixed: v6.14.0's per-file downloads replaced with a genuine single folder

v6.14.0 removed the ZIP but still downloaded every document as a **separate
download event**, relying on a `/` inside the `Content-Disposition` filename
to make Chrome/Edge *auto-group* them into a folder under Downloads. That is
not the same thing as "one folder downloads" — it's still N individual
downloads happening one after another, which is exactly what was reported as
wrong.

This version changes the mechanism entirely. Clicking **Docs** (or
"Download All" / "Download Selected") now:

1. Asks the browser once, via the **File System Access API**
   (`window.showDirectoryPicker()`), where to put the request's folder.
2. Creates **one real folder** there, named
   `[Student Complete Name] – [Request Number]` (e.g.
   `Rahul Kumar – NRI-2026-0554`, same `NRI-YYYY-NNNN` format as before).
3. Fetches every document from the existing secure download proxy and
   writes each one **directly into that folder** — as a single user action,
   with no ZIP and no separate per-file download prompts.

**What changed under the hood:**
- `nri_get_download_url()` (`includes/document-download.php`) no longer
  takes a `$folder` argument — it only ever hands back a clean, flat
  filename hint. Building the actual folder is no longer the server's job.
- `nri_ajax_download_document()` no longer puts a folder name into
  `Content-Disposition` — every file is served with a plain filename.
- `nri_ajax_bulk_download_docs()` (`includes/ajax.php`) still returns the
  computed folder name (`Rahul Kumar – NRI-2026-0554`) in its JSON response,
  but now the **client** uses it to create the real folder, rather than the
  server smuggling it into a response header.
- New `nriSaveFilesAsFolder(folderName, files)` in `assets/js/nri-app.js`
  does the actual folder-creation + file-writing via
  `showDirectoryPicker()` → `getDirectoryHandle(name, {create:true})` →
  `getFileHandle(name, {create:true})` → `createWritable()`. Wired into
  both the **Docs** button and **Download All / Download Selected**.

**Browser support / fallback:** the File System Access API used to create
a real folder in one action only exists in **Chromium browsers (Chrome,
Edge) over HTTPS**. Firefox, Safari, and any non-HTTPS installs have no
equivalent capability — there is no ZIP-free way to hand a browser "one
folder" outside Chromium today. On those browsers (or if the person cancels
the folder picker without choosing a location), this falls back automatically
to the previous one-file-at-a-time sequential download (each file lands in
the browser's normal Downloads location individually — this is a graceful
degradation, not a bug, given the platform limitation).

---

## v6.14.0 — "Docs" Now Downloads Individual Files Into a Named Folder, Not a ZIP
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### ✨ Changed: no more ZIP — documents download as individual files, auto-grouped into one folder

Clicking **Docs** (or "Download All" / "Download Selected" on the request
detail page) used to package every document for a request into a single
`.zip` that had to be manually extracted before the files were usable.
It now downloads each document as its own individual file — no
extraction step — and the browser groups them together under one folder,
named:

```
[Student Complete Name] – [Request Number]
```

e.g. **Rahul Kumar – NRI-2026-0554** — the request number is exactly the
existing `NRI-YYYY-NNNN` format `nri_generate_request_id()` already
produces, unchanged.

**How it works:** each document's existing secure download-proxy URL
(`nri_get_download_url()`) now carries the folder name and a document-
type-based filename (e.g. "Passport", "Marksheet" — de-duplicated when
two documents share a type) as query hints. The proxy
(`nri_ajax_download_document()`) sets its `Content-Disposition` filename
to `"[Student Name] – [Request Number]/[document name].[ext]"` — a `/`
inside that header is what makes Chrome/Edge create (and reuse) a
subfolder under the browser's downloads location instead of dropping
every file into one flat list, which is the actual mechanism behind "no
ZIP, already organized into a folder." Clicking Docs downloads every
document for that request in sequence (one every 500ms so the browser
doesn't block a burst of downloads); each one lands directly in the
named folder.

*Browser note:* this uses the standard `Content-Disposition`
subfolder-creation behavior, which Chrome and Edge honor. Firefox and
Safari currently flatten or sanitize the `/` out of the download name on
their end — there's no cross-browser API for a true "download as a
folder," and building one server-side would mean going back to packaging
files (a ZIP), which is exactly what this change removes. All files still
download correctly and individually in every browser; the automatic
folder grouping is a Chrome/Edge enhancement on top of that.

**Where it applies:** the "Docs" button on every request card (Requests
tab), and the request detail page's "Download All" / "Download Selected"
buttons — all three share the same `nri_bulk_download_docs` endpoint and
the same client-side sequential-download helper, so behavior is
identical everywhere documents can be bulk-downloaded.

**Removed:** the ZipArchive-based packaging path in
`nri_ajax_bulk_download_docs()` (including the temp `.zip` file + its
5-minute scheduled cleanup) is gone entirely — every download now goes
through the individual-file path described above.

### ✅ Verification performed
- `php -l` on `includes/ajax.php` and `includes/document-download.php`.
- `node --check` on `assets/js/nri-app.js` (a real JS file, not PHP-
  generated, so this is a direct check).
- Standalone PHP test harness (13 checks) reproducing the exact
  folder-name, per-document base-name/de-duplication, and download-
  endpoint filename-assembly expressions copy-verified against the real
  source — covering: normal name+request-ID formatting, duplicate
  document types getting suffixed, missing document type falling back to
  the original filename, illegal path characters (`/`, `\`, `:`, `"`)
  being stripped rather than blocking the download, the server's
  authoritative file extension always overriding whatever extension the
  client-supplied name carried, and — the security-relevant cases — that
  neither an embedded `/`/`\` nor CR/LF/quote characters in the
  folder/filename can smuggle extra path segments or inject extra
  `Content-Disposition` header content. All 13 passed.
- Confirmed the harness's re-implemented expressions match the real
  `includes/document-download.php` source line-for-line (grepped both).

---

## v6.13.0 — Pagination Moved Into the Search/Filter/Reset Toolbar Row
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### ✨ Changed: pagination now sits top-right, in the same row as Search/Filter/Reset

Requested with a screenshot: the "49 total · Prev 1 2 3 Next" pagination
bar used to render in its own strip below the table/card list. It's now
inline in the same toolbar row as the search box, status filter, date
filter, and Search/Filter/Reset buttons — pushed to the right edge of
that row — on both the **Requests** tab and the **Form Submissions** tab.

- The pagination `<div>` (`#nri-admin-pages` / `#nri-sub-pages`) simply
  moved to a new position in the toolbar markup; its id, and the
  `nriBuildPager()` call that fills it after every list load, are
  unchanged — pagination behavior itself (bounded Prev/1/…/current/…/
  last/Next buttons, capped regardless of total row count — see v6.11.1)
  is identical, only its position moved.
- New `.nri-pagination-inline` CSS class strips the standalone bar's own
  `padding`/`border-top` (which would otherwise draw a stray divider line
  inside the toolbar row) and pushes itself to the row's right edge via
  `margin-left:auto`.
- Both toolbar rows already wrap on narrow widths (`flex-wrap:wrap`), so
  on a narrow admin panel or mobile view the pagination controls drop to
  their own line below the search/filter controls instead of overflowing
  or being clipped.

### ✅ Verification performed
- `php -l` on `includes/shortcodes.php` and `includes/form-submissions.php`.
- Re-extracted the actual generated inline JS for both the Requests tab
  (`nri_admin_js()`) and Form Submissions tab
  (`nri_admin_tab_submissions()`) via the standalone PHP harness and ran
  `node --check` on each — confirms the markup move didn't break the JS
  string-building around it.
- Grepped both changed files (and `nri-app.js`) for every reference to
  `#nri-admin-pages`/`#nri-sub-pages` to confirm every usage is a plain
  `getElementById` lookup (not a sibling/position-dependent DOM query
  that the markup move could have silently broken).
- Grepped the stylesheet for any selector combining `.nri-tbl-wrap` and
  `.nri-pagination` positionally — none existed, so nothing else assumed
  the pagination bar's old location.

---

## v6.12.2 — Filter Dropdowns Still Misrendering After v6.12.1 (Padding, Not Just Color)
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: v6.12.1's contrast fix was incomplete — padding/line-height were still theme-controlled

Reported again after v6.12.1: the status and date filter dropdowns were
still rendering wrong. The v6.12.1 fix only made `color`/`background`
`!important` on `.nri-filter-sel`/`.nri-search-input` and left every
other property (`padding`, `border`, `font-size`, `line-height`) at plain
specificity. That's a half-fix: the active WP theme's own global
`select{...}`/`input{...}` reset apparently uses a selector scoped to a
parent wrapper class, which is MORE SPECIFIC than our single class
selector — so on every property we didn't mark `!important`, the theme
kept winning regardless of source order. The result was readable text
(color fixed) sitting in a box whose real padding/line-height/height the
theme was still dictating — which is what looked like a padding/box
problem, because it was one.

**Fix:** every box-model property on `.nri-filter-sel`, `.nri-search-input`,
and the date-filter `input[type="date"]` fields (padding, border,
border-radius, font-size, line-height, height, box-sizing,
vertical-align) is now `!important`, not just color/background. This
takes the theme's selector out of the contest entirely rather than
relying on out-specificity-ing it. `appearance` is deliberately left
alone (not forced to a native "menulist" look, which v6.12.1 briefly
did) — overriding it can fight a theme's own custom dropdown-arrow
background-image and its own padding-right reserved for that arrow,
which is its own way to reintroduce the same kind of layout bug from a
different property.

### ✅ Verification performed
- Re-read the full resulting CSS block for the toolbar controls to confirm
  every box-model property (not just color) is now `!important` and there
  are no duplicate/conflicting rules left over from the v6.12.1 patch
  (there was one stray duplicate `input[type="date"]` rule from that
  patch, found and removed here).
- `php -l` on every PHP file in the package (this is a CSS-only change,
  but re-verified nothing else regressed) — re-checked inside the actual
  packaged zip, not just the working copy.

---

## v6.12.1 — Fixed Low-Contrast Status/Date Filter Dropdowns
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: status and date filter dropdowns rendered as faint, hard-to-read gray text

Reported with a screenshot right after v6.12.0: the "All Statuses" select
and the new "Last Week" date-filter select on the Requests tab (and the
same status select on Form Submissions) were rendering in washed-out,
placeholder-like gray text — not actually broken, but hard to read against
the white toolbar. Root cause: `.nri-filter-sel` and `.nri-search-input`
never declared their own `color`/`background`, so they fell through to
whatever the active WP theme's global `select{...}`/`input{...}` reset
says — and this theme's reset uses a light gray. Fixed by giving both
classes (plus the new date-filter `<input type="date">` fields and the
`<option>` text inside the selects) an explicit, `!important` `color` and
`background`, so they render with normal readable contrast regardless of
what the active theme declares.

### ✅ Verification performed
- Read the actual rendered CSS cascade path (`.nri-filter-sel` /
  `.nri-search-input` had no own `color`/`background` before this fix —
  confirmed by grep across `nri-style.css`) — this is what let a theme
  reset silently win.
- `php -l` unaffected (CSS-only change); re-ran it anyway on every file in
  the package to confirm nothing else regressed.

---

## v6.12.0 — Comprehensive Date Filtering for Requests & Form Submissions
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### ✨ Added: Today / Yesterday / This Week / Last Week / This Month / Last Month / Specific Date / Custom Range / All Dates

Both the **Requests** tab and the **Form Submissions** tab now have a date
filter dropdown next to Search, filtering by each request's actual
submission date/time (`post_date`):

- **Today, Yesterday** — the matching calendar day, 00:00:00–23:59:59.
- **This Week, Last Week** — Monday-start weeks. "This Week" runs through
  the current moment (not through the coming Sunday), so it never implies
  requests that haven't happened yet.
- **This Month, Last Month** — calendar-month boundaries, correctly
  rolling the year back when "last month" is December of the prior year.
- **Specific Date** — pick one date; the dropdown reveals a single date
  picker.
- **Custom Range** — pick a start and end date independently; the
  dropdown reveals two date pickers. Either end can be left open (e.g. "from
  X onward" or "up to Y").
- **All Dates** — clears the date filter (the default).

Selecting Today/Yesterday/This Week/Last Week/This Month/Last Month
applies immediately, no extra click needed. Specific Date / Custom Range
apply as soon as a date is picked. **Reset** clears the date filter along
with status/search, exactly like the existing filters. All of it runs
through the existing AJAX list-loading, so the list updates in place with
no page reload — and the date filter combines correctly with status and
search (e.g. "processing" + "this week" + a search term all narrow the
same list together), matching the same combining behavior status and
search already had.

**Where it applies:** the Requests tab and the Form Submissions tab — the
two admin request-list views with existing filter/search infrastructure.
Both share one PHP renderer (`nri_render_date_filter_controls()`) for the
control markup and one pair of JS helpers
(`nriInitDateFilterToggle()`/`nriReadDateFilter()`, defined once in
`nri_admin_js()`) for showing/hiding the Specific Date / Custom Range
inputs and reading the current selection, so both tabs behave identically
and any future fix only needs to be made once.

**Server side:** `nri_compute_request_date_range($filter, $from, $to)`
(new, `includes/helpers.php`) turns a filter name + optional date(s) into
`[$after, $before]` bounds using WordPress's configured timezone (not the
server's), and `nri_request_date_query($after, $before)` turns those
bounds into a `WP_Query` `date_query` clause against `post_date`. Both the
no-search fast path (`nri_ajax_get_requests()`) and the comprehensive
multi-field search path (`nri_search_matching_request_ids()`, shared with
Form Submissions) now accept and apply these bounds — including in the
search results transient cache key, so a date-filtered search and an
unfiltered search of the same term are cached separately and never bleed
into each other's results.

### 🐛 Fixed while building this: date_query was silently a no-op

`nri_request_date_query()` originally returned its single clause wrapped
in one array level too many (`array( array( $dq ) )` instead of
`array( $dq )`). `WP_Query`'s `date_query` expects a flat array of clause
arrays at the top level — the extra wrapping would have made every date
filter match nothing recognizable and silently return the *unfiltered*
list instead of erroring, which is the kind of bug that's invisible until
someone notices the date filter "doesn't actually filter." Caught by a
standalone test harness before delivery (see Verification below), not by
inspection — fixed before this ever reached the AJAX handlers.

### ✅ Verification performed
- `php -l` on every changed file (`helpers.php`, `ajax.php`,
  `form-submissions.php`, `shortcodes.php`, `nri-platform.php`).
- Extracted the actual generated inline JS from both `nri_admin_js()`
  (Requests tab) and `nri_admin_tab_submissions()` (Form Submissions tab)
  via a standalone PHP harness and ran `node --check` on each — catches JS
  syntax errors that `php -l` can't see, since this JS is built as PHP
  string concatenation.
- Standalone PHP test harness (17 checks) for
  `nri_compute_request_date_range()` and `nri_request_date_query()`,
  covering: Today/Yesterday, This Week/Last Week at both a Sunday-as-
  "today" edge case and a mid-week case, This Month/Last Month including
  a December-rollback year boundary, Specific Date, Custom Range (both
  ends, from-only, to-only), All Dates / unrecognized filter, and the
  `date_query` clause shape itself — all 17 passed after the wrapping fix
  above.

---

## v6.11.1 — Pagination Buttons Now Bounded Instead of One-Per-Page
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: pagination bar rendered one `<button>` per page, unbounded

Spotted from a screenshot at 535 total requests: the pagination bar was
rendering all 27 page-number buttons in a row (`for(var i=1;i<=pages;i++)`
in both the Requests tab and Form Submissions tab loaders). That's
already excessive at 27; at real scale — a few thousand requests — the
exact same loop renders hundreds of `<button>` elements into the DOM on
every single list load, filter change, or search, growing linearly and
unboundedly with total row count instead of staying flat. Not a
database-query cost (the v6.11.0 fix already made the query itself
bounded), but a real, needless render/layout/paint cost and a genuinely
unusable pager once the count gets large.

### ⚡ Optimized: shared, bounded pager component

Added `nriBuildPager(total, pages, current, gotoFnName)` (`includes/
shortcodes.php`, defined once in `nri_admin_js()` — the same script
block loaded once on every admin page — as `window.nriBuildPager`, so
one implementation serves both the Requests tab and the Form Submissions
tab loader in `includes/form-submissions.php`). It renders a fixed,
small set of controls regardless of how many pages exist: Prev / page 1
/ up to 2 pages around the current one / "…" gaps / last page / Next —
5 to 7 buttons whether there are 2 pages or 2,500. Prev/Next disable at
the first/last page.

### Verified

- `php -l` on `includes/shortcodes.php` and `includes/form-submissions.php`: clean.
- `node --check` on the JS extracted from the updated `nri_admin_js()`.
- Extracted `nriBuildPager()` standalone and ran it in Node across
  several total/page/current combinations (535/27, 50,000/2,500, 40/2)
  — button count stayed at 4-7 in every case, confirmed flat regardless
  of total pages.

---

## v6.11.0 — Pagination/Search Performance: Fixed a Full-Table-Scan Regression
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: every Requests/Form Submissions list load was fetching ALL matching rows, not just one page

**Root cause:** the v6.9.0 comprehensive-search fix (needed because
WP_Query's `'s'` parameter can't see postmeta) changed
`nri_ajax_get_requests()` and `nri_ajax_list_submissions()` to always
call `get_posts()` with `posts_per_page => -1` — fetching **every**
status-matching request ID on **every** list load, search or not — then
slicing 20/25 out of that full set in PHP. Before that fix, a plain
page load used a real SQL `LIMIT 20 OFFSET …` and only ever touched one
page's worth of rows. The regression meant a site with, say, 5,000
requests was pulling all 5,000 IDs (plus priming their postmeta cache)
on every single Requests-tab load, filter click, or page change — not
just when actually searching.

### ⚡ Optimized: split into a real fast path and a bounded, cached search path

- **No search term (the common case)** — restored true SQL-level
  pagination: a single `WP_Query` with `posts_per_page`/`paged`, exactly
  as before v6.9.0. Touches only the rows being displayed, full stop.
- **With a search term** — this still has to scan (there is no indexed
  column across the admin-configurable submitted fields to query
  directly), but it's now bounded and shared: the scan itself is one
  lightweight ID query (`fields => 'ids'`) plus WP's own single batched
  meta-cache-priming query — not one query per row — and the resulting
  matched-ID list is cached in a **45-second transient**, keyed by
  status+search, in a new shared helper
  `nri_search_matching_request_ids()` (`includes/ajax.php`). Paginating
  through search results, or re-running the same search shortly after,
  now costs nothing extra instead of re-scanning every time.
- **Cache freshness:** a brand-new or deleted request calls the new
  `nri_flush_request_search_cache()` immediately (in
  `nri_ajax_create_request()` and `nri_delete_request_by_id()`), so
  create/delete are reflected in search instantly. An in-place edit to
  an existing request (status change, quote, reassignment, a form
  field) is not flushed proactively — it's left to the 45s TTL — since
  flushing on every single admin edit across the whole app would be a
  much wider blast radius for a niche case (a value changing in a way
  that flips whether it currently matches someone's exact search term
  right now). The no-search fast path is unaffected by this and is
  always fully live.

### Verified

- `php -l` on `includes/ajax.php` and `includes/form-submissions.php`:
  clean.
- Standalone PHP harness (extracted `nri_request_search_haystack()` +
  `nri_search_matching_request_ids()` against fake `get_posts()`/
  `get_userdata()`/transient stubs): confirmed multi-term AND search,
  status+search combined, a second identical call served from cache
  (mutated underlying data not yet reflected), and a cleared cache
  picking the mutation back up — all behaved as designed.

---

## v6.10.0 — Client Dashboard Redesigned Into a Proper Application Portal
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🎨 Redesigned: the client-facing dashboard, profile tab and request-detail page

The logged-in client experience (`[nri_client_dashboard]` and the
standalone `/request/{id}` page) read too much like a plain website
page — flat cards, minimal contrast, no sense of being "inside" an
account. Gave it a full **visual** redesign so it reads as a
professional, modern application portal:

- **Portal shell** — a distinct off-site background tint, a sticky
  "portal" top nav with a brand mark and gradient CTA button, and a
  hero-style welcome header with avatar, eyebrow label and stat tiles
  (Total / Active / Completed) that lift on hover.
- **Request cards** — clearer status dots, an icon on the request
  number, a "View details →" hint that appears on hover, and a
  consistent elevation/hover-lift treatment shared with the profile
  panel and request-detail cards.
- **Request-detail page** (client view only) — info cards (Customer /
  Shipping / Manager) now read as real cards with depth and hover
  lift; the summary bar is explicitly labelled "Payments & Timeline"
  and the stage tracker is labelled "Current Stage" with a subtle
  pulse on the active step; tabs, document rows and the messages panel
  got matching portal styling (gradient header, gradient bubble for
  the client's own messages).
- **Buttons** — added explicit hover/active/focus-visible/disabled
  states across the portal (gradient fill + lift on hover, dim on
  active, visible focus ring, muted + no-lift when disabled).
- **Empty state, profile card** — restyled to match the same card
  system (rounded corners, soft border, dashed accent for the empty
  state).
- **Mobile** — the portal nav, hero header and stat row adapt at
  ≤600px (edge-to-edge nav, horizontally scrollable stat tiles) so the
  dashboard still feels like an app on a phone rather than a shrunk
  desktop page; info cards drop to 1 column below 400px.

This is a **CSS and light markup change only** — new/extended
`.nri-portal-*` classes wrap existing elements. No ids, JS-bound
classes, form field names, PHP data flow, shortcode behaviour, or the
staff/admin dashboard were changed; the admin's embedded request-detail
view (rendered by the same `nri_render_request_view()` function) is
untouched because the new styling is scoped to the standalone client
page wrapper, not the embedded admin one.

### Verified

- `php -l` on `includes/shortcodes.php` and `nri-platform.php`: clean.
- Grepped `assets/js/nri-app.js` for every id/class/data attribute the
  touched templates reference (`.nri-view-request-link`, `data-rid`,
  `data-tab`, `#nri-new-sr-btn`, `#nri-profile-form`, etc.) — all
  present and unchanged.
- Checked `.nri-status-chip` (shared with the admin requests table) —
  only additive/scoped rules were added, admin's inline-styled usage
  is unaffected.
- Reviewed new CSS against ~360px, ~768px and desktop widths.

---

## v6.9.2 — Removed Blank-Line Gaps From the Generated Description
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: unnecessary line gaps in the Student Requirement Description

`nri_generate_requirement_description()` (`includes/helpers.php`) joined
its paragraphs with a blank line (`"\n\n"`). That produced a visible
double gap in two places: on the request detail page, `nl2br()` keeps
the original `\n` characters *and* adds a `<br>` before each one, so
`"\n\n"` rendered as `<br><br>` — a full blank line between paragraphs;
and in the plain text copied by "Copy Description", pasting into
WhatsApp/email left an actual blank line between paragraphs too.
Changed the join to a single `"\n"` — each paragraph still starts on
its own line, just without the extra gap.

### Verified

- `php -l` on `includes/helpers.php`: clean.
- Re-ran the standalone description-generation test harness (8
  scenarios) — output now separates paragraphs with a single line
  break, no blank line, in every case.

---

## v6.9.1 — Fixed Filter/Search Being Silently Clobbered On Every Click; Added Search Button
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: Filter/Search on the Requests tab had no visible effect (real root cause)

**Root cause:** `nriLoadAdminRequests()` (`includes/shortcodes.php`)
unconditionally re-read the *last saved* filter/search/page state from
`nriRestoreAdminListState()` at the very top of every call — including
calls made right after the Filter button, Search, Reset, a stat-card
quick-filter, or a pagination click had just explicitly set
`_status`/`_search`/`_page` to the value the user chose. That restore
silently overwrote the brand-new values with the old cached ones
*before the AJAX request even went out*, so the list kept showing
results for whatever filter was applied previously — filtering and
searching looked completely broken, no matter what was typed or
selected. (This bug pre-dates and is separate from the search-scope
fix in v6.9.0 — it would have blocked that fix from ever being visibly
usable through the UI.)

**Fix:** `nriLoadAdminRequests()` now takes a `restoreState` argument
(defaults to `true`). Restoring cached state is only correct for a
*tab-entry* — the very first page load, or returning to the Requests
tab after being on another one — so only those two call sites (the
self-invoking call in `nri_admin_js()`, and `renderTab()`'s call to
`window.nriLoadAdminRequests()` in `nri-app.js`) use the default.
Every explicit user action — Filter, the new Search button, Reset, a
stat-card click, a pagination click — now passes `restoreState=false`,
so the value it just set is what actually gets sent.

### ✨ Added: dedicated "Search" button on the Requests tab

The search box previously had no button of its own — only Enter, or
the unrelated "Filter" button, triggered it, which read as a missing
feature. Added a primary "🔍 Search" button next to "Filter" (both run
the same combined search + status query — see
`nri_admin_tab_requests()`); Enter in the search box now clicks Search
instead of Filter, but the effect is identical either way.

### Verified

- `php -l` on `includes/shortcodes.php`: clean.
- `node --check` on the JS extracted from the updated `nri_admin_js()`.
- Extracted output inspected directly: confirmed exactly 4 call sites
  now pass `nriLoadAdminRequests(false)` (Filter/Search, Reset,
  `nriAdminFilter()`, `nriGoPage()`) and exactly 2 call sites keep the
  restoring default (the tab-entry self-invoke, and the implicit
  no-arg call `renderTab()` makes in `nri-app.js`).

---

## v6.9.0 — Fixed Requests Tab Stuck Loading, Comprehensive Search, Filters
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: Requests tab stuck on "Loading..." on the very first page load

**Root cause:** `nri_admin_js()` (`includes/shortcodes.php`) prints an
inline `<script>` block directly into the page body that calls `jQuery`
immediately, including a self-invoking `nriLoadAdminRequests();` at the
end. But `jquery`/`sortablejs`/`nri-app.js` are enqueued with
`in_footer => true` (`includes/enqueue.php`), so on the very first full
page load this inline script executes **before jQuery has loaded** —
`jQuery` doesn't exist yet, so the first `jQuery(...)` call throws a
`ReferenceError` and aborts the rest of the script, including the
self-invoking load call. The list stays on its static "Loading..."
placeholder forever. Switching tabs "fixed" it only because the AJAX
tab-swap is driven by `nri-app.js`, which by then has loaded and calls
`window.nriLoadAdminRequests()` itself.

**Fix:** the script's jQuery-dependent bindings and its first data load
are now wrapped in an init function gated by
`document.readyState === 'loading' ? addEventListener('DOMContentLoaded', …) : call immediately`
— the same pattern `nri_admin_tab_submissions()`'s own inline script
already used safely. This guarantees jQuery and `nri-app.js` (both
plain, non-deferred `<script>` tags) have already executed by the time
this runs, on every load path, first visit included.

### 🐛 Fixed: Search on the Requests tab and Form Submissions tab

**Root cause:** both `nri_ajax_get_requests()` and
`nri_ajax_list_submissions()` passed the search box's value straight
into `WP_Query`'s `'s'` parameter. WordPress's default search only
matches `post_title` / `post_content` — it never looks at postmeta,
where every submitted form field actually lives (applicant name,
university, enrollment number, phone, remarks, etc.), and never looks
at the client's `wp_users` name/email either. In practice this meant
search only ever coincidentally matched on the auto-generated post
title (service type + email + date).

**Fix:** added `nri_request_search_haystack()` (`includes/ajax.php`),
shared by both endpoints, which builds a flattened, lower-cased string
per request from request ID, client name/email, status, quote,
assigned manager/vendor, and **every value inside the submitted
`field_data` array** — regardless of which field keys this install's
form is configured with. The search box is now split on whitespace
into terms, and a request matches when **every** term appears
somewhere in that haystack (not a single exact-match string) — so e.g.
"sharma delhi" now finds a request whose applicant is "Rahul Sharma"
*and* whose university is "University Of Delhi" even though neither
single field contains both words on its own.

### 🐛 Fixed: Requests tab status filter not combining correctly with search

Filtering by status now happens first (as a DB-level `meta_query`, same
as before), and the new comprehensive search is applied on top of that
already-filtered set — so status + search now combine correctly (AND),
pagination totals reflect the actual filtered count, and Reset (which
clears both `_status` and `_search` before reloading) returns the
complete, unfiltered list exactly as it did before.

### Verified

- `php -l` on `includes/ajax.php`, `includes/shortcodes.php`,
  `includes/form-submissions.php`: clean.
- `node --check` on the JS extracted from the updated
  `nri_admin_js()`: clean.
- Standalone PHP harness for `nri_request_search_haystack()` +
  multi-term matching: single-field terms, cross-field AND terms
  ("sharma delhi"), enrollment number, email, and a non-matching term
  — all behave as expected.

---

## v6.8.0 — Requirement Description Restructured Into Short Paragraphs
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### ✨ Changed: `nri_generate_requirement_description()` now reads as 3–4 short paragraphs, not one dense block

Based on a reference example, restructured the engine's output
(`includes/helpers.php`) into clearly separated paragraphs (joined with
a blank line — renders as proper paragraph breaks via the existing
`nl2br()` on the detail page, and as plain blank lines when copied to
WhatsApp/email via "Copy Description"):

1. **What's needed** — document + "for the first time" when the
   Application Type is Fresh (previously phrased as "a fresh
   transcript"; e.g. *"needs a Medium of Instruction (MOI) letter for
   the first time for his/her ... course from ..."*), course, and
   institution.
2. **Academic timeline** — "He/she started the course in {admission
   year} and completed it in {passing year} through the {mode} mode."
   (or "completed the course in ..." / "started ... and is currently
   pursuing it" when only one year is given), plus a separate "His/Her
   Enrollment Number is {enrollment}." sentence — enrollment and the
   admission/passing years moved out of paragraph 1 so it doesn't read
   as one overloaded sentence.
3. **Location, purpose & delivery** — "He/she is currently based in
   {current location}, and needs the {document} for {purpose}. The
   completed document needs to be sent to {delivery location}, within
   about {timeline}." Urgency (detected in Remarks) folds into this
   paragraph rather than a separate sentence.
4. **Anything else in Remarks** — only when there's more to it than
   the urgency keyword already folded into paragraph 3.

Any field that's missing is still simply omitted from its paragraph
(or the whole paragraph is dropped) rather than leaving an awkward gap
— unchanged from prior versions.

### ✅ Verification
- Re-ran the reported reference example (Debolina Banerjee / MOI
  Letter / Fresh / Master of Journalism and Mass Communication /
  University of Calcutta, Presidency College / 2005–2007 / Regular
  mode / Enrollment 022282 / Immigration / Swansea, United Kingdom →
  Swansea, United Kingdom) — output now matches the requested
  paragraph structure and phrasing pattern closely.
- Re-ran all 7 prior standalone engine scenarios — all still produce
  correct, natural output in the new paragraph structure (course/
  institution, ongoing-vs-completed, service-type documents, sparse/
  empty data, unmatched Application Type, "None" remarks placeholder).
- Re-ran the full get/manual-save/stale-drift lifecycle test — an auto
  description is still always live and never stale; a manual edit is
  still fully preserved and unaffected by the wording change.
- Re-ran the `nri_render_form_details_pane()` end-to-end render check
  — panel markup and balanced `<div>` tags confirmed with the new
  multi-paragraph text.
- Full `php -l` sweep across every `.php` file in the plugin: clean.
- `node --check` on `assets/js/nri-app.js`: clean (unchanged this
  version — only `includes/helpers.php` was touched).

---

## v6.7.0 — Compact Card Action Buttons + "Docs" Download Button
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### ✨ Built: smaller card action buttons, plus a one-click "Docs" download

**Compact buttons:** the admin request card's action row (Copy, Desc,
Docs, View, Delete) now uses a new `.nri-btn-xs` CSS class
(`assets/css/nri-style.css`) — smaller padding/font-size than the
existing `.nri-btn-sm` — instead of full-size buttons that were
crowding the card. Labels were also shortened ("Copy Details" → "Copy",
"Copy Description" → "Desc") with the full wording kept in each
button's `title` tooltip, so nothing is lost, just smaller.

**New "Docs" button (`.nri-download-docs-btn`):** downloads every
document attached to that request (both client-uploaded and any
service-provider documents) as a single ZIP, reusing the existing
`nri_bulk_download_docs` AJAX endpoint the request detail page's
"Download All" already uses — no new server-side download logic. Falls
back to sequential one-by-one downloads on a host without PHP's
ZipArchive extension (same fallback the detail page already has). The
button is greyed out and disabled up front for a request with no
documents at all (`nri_ajax_get_requests()` now sends a `has_docs` flag
per request), instead of letting the admin click it and get an error.
Works via AJAX only — no reload, no scroll change, and
`e.stopPropagation()` so it can't trigger the card's "View" click.

### ✅ Verification
- `nri_ajax_get_requests()`'s new `has_docs` field traced to
  `nri_get_documents()` (existing helper, just a non-empty check).
- Extracted and `node --check`'d the JS `nri_admin_js()` generates —
  confirmed the new "Docs" button's conditional `disabled` attribute
  and title tooltip render correctly for both the has-docs and
  no-docs cases.
- Full `php -l` sweep across every `.php` file in the plugin: clean.
- `node --check` on `assets/js/nri-app.js`: clean.
- CSS brace-balance check on `nri-style.css`: clean.

---

## v6.6.2 — Requirement Description: Auto Descriptions Are Now Always Live + "None" Remarks Dropped
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: v6.6.1's pronoun fix wasn't showing up on already-generated requests

Root cause: `nri_get_requirement_description()` (`includes/helpers.php`)
was designed to read whatever text had already been saved to
`requirement_description` postmeta and only regenerate if that meta was
completely empty. That's correct behavior for an admin's own manually-
written description (never touch it), but it was ALSO applied to
auto-generated ones — so a request created before v6.6.1's "he/she"
fix kept showing its old "they/their" text forever, and would have kept
showing it after every future engine improvement too, unless an admin
manually clicked "Regenerate" on every single request.

**Fix:** an auto-generated description (`requirement_description_manual`
not set) is now always recomputed live from the request's current
fields on every read, instead of trusting a possibly-outdated saved
copy — so an engine fix or improvement is visible immediately on every
existing request, with nothing for an admin to click. A **manually
edited** description is completely unaffected by this — it's still
read from what the admin wrote, still never silently regenerated, and
still flags "Source data changed" only if the underlying fields drift
since it was saved. (The live-recompute path also no longer writes to
postmeta on every card/list load, avoiding an unnecessary DB write per
request per page view.)

### 🐛 Fixed: a literal remark of "None" (or similar) was quoted back as if it were real content

Reported example: *"...for a university admission. They also noted:
None."* A client leaving Remarks as a placeholder value — `None`,
`N/A`, `Nil`, `-`, `No remarks`, etc. — is effectively leaving it blank,
so the engine now treats those (case-insensitive, trimmed) the same as
an empty remark and omits the sentence entirely, instead of surfacing
the placeholder text as if it were a real note.

### ✅ Verification
- Re-ran the exact scenario from the report (Ayushh Shharma / Duplicate
  Degree Certificate / B.A / University Of Delhi, Shyam Lal College /
  Enrollment 444556 / completed 2022, Regular mode / Delhi India →
  Mumbai India / university admission / Remarks: "None") — confirmed
  output now reads "his/her" throughout and the Remarks sentence is
  correctly omitted.
- Re-ran all 6 prior standalone engine scenarios — unchanged, all still
  correct.
- Re-ran the full get/manual-save/stale-drift lifecycle test — confirmed
  an auto description is never marked stale (it's always fresh by
  definition) and a manual one is unaffected by this change.
- Full `php -l` sweep across every `.php` file in the plugin: clean.
- `node --check` on `assets/js/nri-app.js`: clean (unchanged this
  version — only `includes/helpers.php` was touched).

---

## v6.6.1 — Requirement Description: He/She Pronouns + No Dropped Fields
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: two gaps in v6.6.0's Student Requirement Description engine

**1. Pronouns — "he/she" instead of "they":** the form has no gender
field, so `nri_generate_requirement_description()` (`includes/helpers.php`)
now writes "he/she" / "his/her" throughout (course clause, completion
clause, location clause, remarks clause, and the purpose-phrase library
in `nri_req_purpose_phrase()`), instead of the gender-neutral "they" it
used before.

**2. Fields silently dropped — now all fields between Applicant and
Remarks are reflected (contact info still intentionally excluded):**
- **Year of Admission** was dropped whenever Year of Passing was also
  present (only the passing year showed). Now both show together:
  *"...having been admitted in 2020 and completed in 2023 through
  Regular mode."*
- **Application Type** was silently dropped whenever it didn't match
  "fresh" / "duplicate" / "revalidation" (e.g. "Renewal", "Correction").
  It now always surfaces, either folded into the document phrase (when
  it matches a known modifier) or as a parenthetical — *"needs a
  marksheet (Renewal application) from XYZ University"* — and a
  redundant parenthetical is avoided when the document type already
  implies it (e.g. "duplicate degree certificate" + Application Type
  "Duplicate" doesn't repeat "(Duplicate application)").
- Mobile Number remains intentionally excluded from the description, per
  instruction to keep contact info out of it.

### ✅ Verification
- Re-ran the standalone engine test harness (all 5 v6.6.0 scenarios +
  1 new one for an unmatched Application Type) — confirmed: both
  admission and passing years appear together when both are submitted,
  an unmatched Application Type surfaces as a parenthetical without
  duplicating information already in the document noun, and every
  sentence now reads with "he/she" / "his/her" rather than "they" /
  "their".
- Full `php -l` sweep across every `.php` file in the plugin: clean.
- `node --check` on `assets/js/nri-app.js`: clean (unchanged this
  version — only `includes/helpers.php` was touched).

---

## v6.6.0 — Copy Buttons + Internal "Student Requirement Description" Engine
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None (new postmeta keys only — no schema/table changes)

### ✨ Built: Two copy actions on the admin request card, and a new internal (no external AI) requirement-description engine

**1. Copy Details button (`.nri-copy-details-btn`, admin request card):**
Reads the card's own rendered `.nri-rc-fields` block (the grouped
Applicant/Document & Academic/Location & Delivery/Remarks HTML from
`nri_render_request_card_fields()`) straight out of the DOM and copies it
as clean `Label: Value` lines via the Clipboard API (`execCommand`
fallback for older browsers/non-HTTPS). Reading from the DOM — rather
than a second server-side template — guarantees the copied text always
matches exactly what the card displays. Works via AJAX/DOM only: no
reload, no scroll change, doesn't trigger the card's "View" click
(`e.stopPropagation()`), and flashes "Copied ✓" on the button for ~1.4s.

**2. Copy Description button (`.nri-copy-desc-btn`, card + request detail page):**
Copies the new Student Requirement Description (below) the same way —
instant on the card via an in-memory `window._nriDescCache` populated
from the list AJAX response, or via the button's own `data-desc-text`
attribute on the request detail page.

**3. New: Student Requirement Description — internal rule-based engine
(`includes/helpers.php`), NOT an external AI API call:**
- `nri_req_doc_library()` — filterable (`nri_req_doc_library`) knowledge
  table mapping raw Document Type text (Transcript, Consolidated/Final
  Semester/Final Year Marksheet, Degree/Duplicate Degree Certificate,
  Duplicate Marksheet, Migration Certificate, MOI Letter, Letter of
  Recommendation, Syllabus Copy, Verification, Attestation, Apostille,
  ...) to how it should be phrased — extensible without touching this
  file.
- `nri_req_purpose_phrase()` — maps Purpose (Higher Studies, Immigration,
  Employment, Visa, Admission, Scholarship, Residency, ...) to a natural
  phrase.
- `nri_generate_requirement_description( $rid, $meta )` — the engine.
  Interprets the RELATIONSHIP between fields (document type + course +
  institution + completion year vs. still-pursuing + mode; current vs.
  delivery location; timeline; purpose; urgency detected in Remarks) and
  composes a short 2–3 sentence narrative — e.g. *"Rahul Sharma needs a
  fresh transcript for their B.Com studies from ABC University, which
  they completed in 2023 through Regular mode. Currently based in
  Dubai, the transcript needs to reach UAE, within about 15 working
  days for a higher-studies application abroad, so the requirement is
  urgent."* Never a field-by-field concatenation; any missing field is
  simply omitted rather than producing an awkward gap.
- Storage is 4 new postmeta keys (no table/schema changes):
  `requirement_description`, `requirement_description_manual` (1/empty —
  distinguishes an admin's own wording from an engine-generated one),
  `requirement_description_hash` (detects when source fields have
  drifted since the saved text, WITHOUT ever auto-overwriting it), and
  `requirement_description_updated`.
- **Generated on creation** (`nri_ajax_create_request` in `ajax.php`)
  and **lazily backfilled** on first read for any pre-existing request
  (`nri_get_requirement_description()`), so no separate migration
  script is needed.
- **Regenerate action** (`nri_ajax_regenerate_description`): if the
  saved description was manually edited, the client shows a `confirm()`
  dialog and the server independently refuses to overwrite it unless
  `force=1` is sent — a manually-written description is never silently
  replaced.
- **Manual edit** (`nri_ajax_save_description`, request detail page →
  Form Details tab → Edit/Save/Cancel): saves the admin's own wording
  and marks it "Manually Edited" (vs. "Auto-Generated") with a visible
  badge; a "Source data changed" badge appears if the request's fields
  have changed since the saved text was last generated/edited.

### ⚠️ Note
`course_name`, `mode_of_education` and `number_of_semesters` still use
the same best-guess field-key fallback as the v6.5.3 card redesign
(they aren't part of the plugin's default field schema) — if your
actual custom field keys differ, tell me the exact keys and I'll add
them.

### ✅ Verification
- `nri_generate_requirement_description()` tested standalone across 5
  scenarios (full data, duplicate-degree/immigration, sparse
  service-type-only, completely empty, ongoing-course-with-semesters +
  non-urgent remark) — confirmed natural, contextual sentences with
  correct omission of missing fields in every case.
- `nri_get_requirement_description()` / `nri_save_requirement_description()`
  tested through the full lifecycle: first read (auto-generate +
  persist, not stale), manual save (marked manual, not stale), and
  source-field drift (marked stale, manually-saved text left untouched).
- `nri_render_form_details_pane()` rendered end-to-end in a stub
  harness — confirmed the new panel's markup is present and its `<div>`
  tags balance.
- Full `php -l` sweep across every `.php` file in the plugin: clean.
- `node --check` on both `assets/js/nri-app.js` directly and the JS
  extracted from `nri_admin_js()`: clean.

---

## v6.5.3 — Admin Requests Tab: Compact Grouped Cards Instead of a Table
**Release Date:** September 15, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### ✨ Built: Admin "Requests" list redesigned from a wide `<table>` into compact, information-dense cards

The admin Requests tab previously showed one `<table class="nri-tbl">` row
per request, which either truncated submitted form data or forced
horizontal scrolling to see it. Replaced with a responsive card grid
where each request's submitted form data is grouped into scannable
sections instead of raw label/value dumps.

**New (`includes/helpers.php`):**
- `nri_fd_first( $fd, $keys )` — returns the first non-empty value from
  a request's `field_data` among a list of candidate field-key
  spellings, since form fields are admin-configurable and a logical
  field (e.g. "University Name") may be stored under different keys on
  different installs.
- `nri_render_request_card_fields( $rid, $meta )` — builds the full
  compact card body as ready-to-insert, pre-escaped HTML, grouped as:
  1. **Applicant** — `first_name` + `last_name` combined into a full
     name, plus `phone`/`mobile`/`mobile_number` with `phone_code`.
  2. **Document/Academic** — `document_type` + `application_type`;
     `university_name`/`university` + `college_name`/`college`;
     `course_name`/`course` + `mode_of_education`/`mode`; `year_admission`
     + `year_passing` + `number_of_semesters`; `enrollment_number` +
     `purpose`.
  3. **Location & Delivery** — `current_location` → `delivery_location`
     with an arrow, plus `timeline_working_days` (the admin-set
     timeline, not a submitted field) as "N Working Days".
  4. **Remarks** — `remarks`/`additional_remarks`/`notes`, only
     rendered when actually provided.
  Any field that is empty is omitted entirely (not shown blank), and a
  whole line is omitted if every field on it is empty.

**Changed (`includes/ajax.php`):** `nri_ajax_get_requests()` now
includes `'card_fields' => nri_render_request_card_fields(...)` in each
request's JSON payload.

**Changed (`includes/shortcodes.php`):**
- `nri_admin_tab_requests()` markup swapped from `<table class="nri-tbl">`
  to a `.nri-rc-list` card-grid container with a "Select All" bar.
- `nriLoadAdminRequests()` (inside `nri_admin_js()`) now builds
  `.nri-req-card-admin` divs per request — checkbox, title, status
  chip, date, client/email/service line, the grouped `card_fields` HTML,
  a separate muted line for Quote/Delivery/Manager/Vendor, and the
  existing View/Delete actions — instead of `<tr><td>` rows.

**New (`assets/css/nri-style.css`):** `.nri-rc-list` is a CSS grid
(`repeat(auto-fit, minmax(420px, 1fr))`) that collapses to a single
column under 900px, with truncation + hover-tooltip (`title` attribute)
on long values (University, College, Remarks, etc.) via
`text-overflow: ellipsis`.

**⚠️ Note:** `course_name`, `mode_of_education` and `number_of_semesters`
are not part of this plugin's default field schema (`includes/schema.php`)
— they're matched via the best-guess key fallbacks above. If your actual
custom field keys differ, those three specific values may show blank on
the card; let me know the exact keys and I'll add them to the fallback
list.

### ✅ Verification
- `nri_render_request_card_fields()` tested standalone with full,
  sparse, and empty `field_data` — confirmed correct grouping, correct
  omission of empty fields/lines, and the exact requested format for
  Location & Delivery: `Current: Delhi NCR → Delivery: USA | Timeline:
  18 Working Days`.
- Full `php -l` sweep across every `.php` file in the plugin: clean.
- `node --check` on the JS extracted from `nri_admin_js()`: clean.

---

## v6.5.2 — Wizard "Next" Scrolls to the Form, Not the Top of the Whole Page
**Release Date:** September 14, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: Clicking "Next" scrolled past the form to the very top of the page

v6.5.1 kept the forward-scroll behavior on Next, but it was still
scrolling to `scrollTop: 0` — the absolute top of the page, above
whatever header/hero content sits above the form itself. That hides the
form's own heading and step indicator behind the page header instead of
showing the new step from its own top.

**Fix (`assets/js/nri-app.js`, `gotoStep()`):** now scrolls to the top
of the form's own wrapper (`$dotsRoot` — the element that contains the
step dots and the step content, i.e. the form's actual visual top),
minus a small 20px offset, instead of the page's `y = 0`. Clicking Next
now shows the new step starting right at the form, not the top of the
whole page.

### ✅ Verification
- `node --check assets/js/nri-app.js` passes clean.
- Traced: `gotoStep()` computes `$dotsRoot.offset().top - 20` (with a
  `Math.max(0, …)` floor so it can't animate to a negative scroll
  position) and animates `html,body` scrollTop to that value instead of
  a hardcoded `0`.

---

## v6.5.1 — Request-Submission Wizard: No Forced Scroll on "Back"
**Release Date:** September 14, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: The "Submit a New Request" wizard also force-scrolled to the top, including on Back

Audited the request-submission wizard (`nri_sc_request_form` /
`nri_sc_standalone_form`) as the last remaining place with this same
class of forced-scroll behavior. `gotoStep()` — the function both the
Next and Back buttons use to switch steps — unconditionally animated
`scrollTop` to 0 on every step change, in both directions.

**Fix (`assets/js/nri-app.js`):** `gotoStep()` now takes an explicit
`scrollTop` flag.
- **Next** (and the two "jump to the final review step" call sites)
  keep the existing scroll-to-top — that's normal, expected wizard
  behavior: moving forward, you want to see the new step's fields from
  the start, especially on mobile where a step can be long.
- **Back** now passes `false` — going back to a previous step leaves the
  page exactly where it was, the same "never force a scroll jump" rule
  already applied to the admin and client dashboards.

This was a judgment call (unlike the dashboard bugs, forced scroll on
a wizard's forward step is a defensible design choice), so it was
confirmed before implementing rather than guessed.

### ✅ Verification
- `node --check assets/js/nri-app.js` passes clean.
- Traced both call sites: `.nri-wizard-next` → `gotoStep(step+1, $form)`
  → `scrollTop` param omitted → defaults to scrolling (unchanged).
  `.nri-wizard-prev` → `gotoStep(step-1, $form, false)` → the
  `if (scrollTop !== false)` guard skips the animate call entirely.

---

## v6.5.0 — Client Dashboard Gets the Same SPA Treatment; "View Request" No Longer Jumps
**Release Date:** September 14, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: "View" on a specific request still forced a scroll jump

`renderDetail()` (used when opening a request's detail view) still had
its own unconditional `window.scrollTo(0, 0)` — the same class of bug
fixed for tab clicks in v6.4.5, just in the other function. Removed it,
for the same reason: opening a request is a forward action and should
leave the page's scroll position untouched; only coming BACK from it
restores where you were (already correct since v6.4.4).

### 🚀 Added: The client dashboard now has the same no-reload, no-jump navigation as the admin dashboard

The original request asked this be checked "across the platform,
even for the client" — the client dashboard (`/client-dashboard`, the
`[nri_client_dashboard]` shortcode) had the exact same full-page-reload
problem the admin dashboard had before this whole round of work:
switching between "Dashboard" and "Profile," and clicking into any
individual request from the requests grid, all did a full WordPress
page navigation.

**Fix — the admin dashboard's SPA controller (`assets/js/nri-app.js`)
now drives both dashboards** instead of being duplicated:
- It detects which container is present on the page —
  `#nri-admin-tab-container` (staff) or the new
  `#nri-client-tab-container` (clients) — and adjusts its AJAX endpoint,
  default tab, and URL base accordingly. Everything else (instant
  render, hover-prefetch, no-reload tab switching, scroll-position
  preservation on Back) is shared, unduplicated code.
- `includes/ajax.php`: added `nri_ajax_client_load_tab` and
  `nri_ajax_client_load_request_detail` — the client-facing equivalents
  of the admin endpoints, requiring only login (not staff). Access to a
  specific request is still enforced by `nri_render_request_view()`'s
  own `nri_is_own_request()` check, exactly as the standalone
  `/request/{id}` page already relied on.
- `includes/shortcodes.php`: extracted the client dashboard's tab
  content into `nri_render_client_tab($tab)` (used by both the normal
  page load and the new AJAX endpoint — one source of truth, same
  pattern as the admin tabs), wrapped it in `#nri-client-tab-container`,
  and added `nri-view-request-link`/`data-rid` to each request card so
  clicking into a request no longer leaves the dashboard. `nri_client_nav()`'s
  Dashboard/Profile links (not "New Request" or "Logout" — those are
  genuinely separate destinations, not tabs) now carry `nri-nav-item` +
  `data-tab` so they're picked up by the same tab-click handling the
  admin nav uses.
- `assets/css/nri-style.css`: added a one-line rule so the client nav's
  active-tab highlight also responds to the `active` class the JS
  controller toggles (it previously only had its server-rendered
  `nri-nav-active` class styled).

### ✅ Verification
- `node --check assets/js/nri-app.js` passes clean.
- `php -l` passes clean on every changed PHP file.
- Traced both surfaces through `detectSurface()`: on `/admin-dashboard`
  it resolves to the admin container/endpoints exactly as before (no
  behavior change for staff); on `/client-dashboard` it resolves to the
  new client container/endpoints.
- Traced the client request-detail permission path: a client opening
  their own request gets the rendered view; a request ID that isn't
  theirs gets the existing "Access denied." fragment from
  `nri_render_request_view()` — unchanged from the standalone page's
  existing behavior, just reached via AJAX now.

---

## v6.4.5 — Admin Dashboard: Tab Clicks No Longer Move Scroll Position At All
**Release Date:** September 14, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: Clicking a nav tab still jumped the page (to the top)

v6.4.4 fixed the jump when coming BACK to a tab. But a plain forward tab
click (Requests → Support Tickets, say) was still deliberately scrolling
to the top on the reasoning that it's "new content" — which is a
reasonable design choice in general, but not what was asked for here:
switching tabs should feel like the page just stays exactly where it
is, full stop.

**Fix (`assets/js/nri-app.js`, `renderTab()`):** removed the
forward-navigation `scrollTo(0, 0)` entirely. A tab click now never
moves the scroll position on its own — whatever the page's scroll
position was before the click, it's still that after. The only case
that still moves the scroll position is coming BACK to a tab (browser
Back, or "← All Requests"), which restores the exact position that tab
was at before you left it (from v6.4.4) — that's restoring state, not
introducing a new jump.

### ✅ Verification
- `node --check assets/js/nri-app.js` passes clean.
- Traced `renderTab()`: the only remaining `window.scrollTo()` call is
  gated on `opts.scrollY` being a number, which is only ever set by the
  popstate/back-link path — a plain tab-nav click passes no such option,
  so no scroll call happens at all for that path.

---

## v6.4.4 — Admin Dashboard: Fixed Page Jump When Going Back From a Request
**Release Date:** September 14, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: Page visibly jumped when returning from a request's detail view to the list

**Root cause:** every tab/detail swap forced `window.scrollTo(0, 0)`
unconditionally, including when going BACK to a list the user had
scrolled down in. On top of that, the browser's own native scroll
restoration (its default behavior on Back/Forward) was trying to restore
the old scroll position on `popstate` at the same time our code was
forcing it to 0 right after — two different scroll positions applied a
moment apart is exactly what shows up as a visible jump.

**Fix (`assets/js/nri-app.js`):**
- Set `history.scrollRestoration = 'manual'`, taking control away from
  the browser's own (badly-timed, pre-render) restoration attempt.
- Added `pushHistoryState()` — before pushing a new history entry (tab
  switch or "View"), it first stamps the CURRENT scroll position onto
  the entry being left. So the list's scroll position is saved at the
  exact moment you leave it, not guessed at afterward.
- `renderTab()`/`renderDetail()` now accept an explicit `scrollY` and
  restore to it (after the new content is already in the DOM, avoiding
  the pre-render jump) instead of always snapping to the top — forward
  navigation (clicking a nav tab or "View") still starts at the top,
  since that's genuinely new content; only coming BACK restores the
  previous position.
- The "← All Requests" link now simply calls `history.back()` instead of
  re-implementing "go to the previous list" itself — it reuses the exact
  same `popstate` handling (and scroll restoration) that the browser's
  own Back button uses, instead of two slightly different code paths
  that could drift out of sync.

### ✅ Verification
- `node --check assets/js/nri-app.js` passes clean.
- Traced: open a request from partway down a scrolled list → scroll
  position for that list entry is stamped via `pushHistoryState` →
  click "← All Requests" (or the browser Back button) → `popstate` fires
  with the stamped `scrollY` → list content renders first → scroll is
  set to the stamped value only after that render, matching where the
  user actually was.

---

## v6.4.3 — Admin Dashboard: Removed Automatic Background Prefetch
**Release Date:** September 14, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: Tabs were still slower than expected after v6.4.2

v6.4.2 fixed a real callback-queueing bug, but the reported slowness
persisted. The remaining, more likely cause: even sequenced one-at-a-time,
the automatic "warm every other tab in the background" step introduced in
v6.4.1 still issues several extra PHP requests within the first few
seconds after page load. On shared hosting with a small number of
PHP-FPM worker processes (very common for this kind of deployment), any
one of those background requests can still be occupying the only
available worker at the exact moment the user clicks something for
real — no amount of client-side sequencing prevents that, only not
sending the background requests in the first place does.

**Fix:** removed the automatic background tab-warming step entirely.
The only prefetching left is hover/touch-triggered — it fires
immediately when the pointer/finger lands on a nav item or "View" link
(a strong signal of actual intent), costs nothing if the user doesn't
follow through, and there's only ever at most one such request in
flight at a time.

**If tabs are still slower than expected after installing this version**,
the cause is very likely no longer in this prefetch layer at all — the
next place to look is the actual data-fetch endpoints themselves
(`nri_get_requests` / `nri_get_support_tickets` / `nri_list_submissions`
/ `nri_admin_load_tab`) for slow queries, missing indexes, or a
resource-constrained hosting plan. Worth confirming: which specific tab
is slow, how it compares (to before ANY of this SPA work, i.e. v6.3.2,
vs. just to v6.4.0), and whether it's every switch or only some.

### ✅ Verification
- `node --check assets/js/nri-app.js` passes clean.
- `php -l` passes clean on every changed PHP file.
- Confirmed no code path issues a tab-content AJAX request without a
  direct user action (hover/touch/click) triggering it.

---

## v6.4.2 — Admin Dashboard: Prefetch Regression Fix (Some Tabs Were Slower Than v6.4.0)
**Release Date:** September 14, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: Some tabs took longer to open than before the v6.4.1 prefetch change

**Root cause #1 (the main one) — `assets/js/nri-app.js`, `fetchTabInto()`:**
the background prefetch and a real click both call `fetchTabInto()`. If a
background prefetch for a tab was still in flight when the user clicked
that exact tab, the click's `fetchTabInto()` call hit the
"already loading, do nothing" guard and returned immediately — **without
ever registering the click's own callback**. The click then had nothing
telling it when the (already in-progress) request finished, so
`nriAdminLoadTab()` sat on its "Loading…" placeholder with no way to
resolve until the 15-second failure-fallback timer eventually kicked in.
This is what actually manifested as "some tabs take longer than before."

**Fix:** `fetchTabInto()` now queues the click's callback against the
in-flight request instead of discarding it — every caller waiting on a
given tab (background prefetch, an earlier hover, and the actual click)
is notified together the moment that one request resolves, success or
failure.

**Root cause #2 (a contributing factor) — background prefetch fired every
other tab in parallel** right after page load. On typical shared hosting
with a small number of PHP-FPM worker processes, 5+ simultaneous
background AJAX requests could occupy every available worker, forcing
the tab the user actually clicked to wait in queue behind them.

**Fix:**
- Background prefetch is now strictly **sequential** — one tab is
  fetched, and only once that finishes does the next one start (with a
  short gap between each) — instead of firing them all at roughly the
  same time.
- It now starts later (after the current tab's own data has had time to
  load) rather than racing it.
- It **skips Requests, Form Submissions, and Support Tickets** — those
  three tabs always re-fetch their live data table on render regardless
  of whether the surrounding shell HTML was cached (see
  `nriLoadAdminRequests`/`nriLoadSupportTickets`/`nriLoadSubmissions`),
  so prefetching their shell saved little while still costing a worker
  slot. Hovering/touching those tabs' nav links still prefetches them on
  demand, which is the case that actually matters (user is about to
  click).

### ✅ Verification
- `node --check assets/js/nri-app.js` passes clean.
- Traced the fixed race: background prefetch starts for tab X → user
  clicks tab X before it resolves → click's `fetchTabInto()` now queues
  its callback on the existing in-flight entry → request resolves →
  both the background caller and the click's `renderTab()` fire
  correctly, with the click rendering as soon as the (single, shared)
  request completes rather than waiting on any fallback timer.
- Traced the failure path: a prefetch that fails now flushes its queued
  callbacks with `null` instead of leaving them pending forever, so a
  click that had queued onto it shows the actual error state
  immediately instead of only after 15 seconds.
- Confirmed the background prefetch queue now issues at most one tab
  request at a time, and excludes the three self-fetching tabs.

---

## v6.4.1 — Admin Dashboard: Background Prefetching (Unnoticeable Tab-Switch Time)
**Release Date:** September 14, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### ⚡ Fixed: Fetching was still visible/felt slow when switching tabs or opening a request

v6.4.0 removed the full-page reload, but each switch still did its AJAX
fetch *at click time*, so a "Loading…" state was still visible on a
slower connection, and the Requests/Support Tickets tabs re-blanked
their table to "Loading…" on every single filter/page/tab-re-entry,
even when the previous data was still on screen.

**Fix — the work now happens ahead of the click, not during it:**
- `assets/js/nri-app.js`: added an in-memory prefetch cache
  (`tabCache`/`detailCache`) for the admin dashboard SPA controller.
  - Right after the page loads, every other nav tab (Requests, Form
    Submissions, Support Tickets, Settings, etc.) is silently fetched
    in the background, staggered so it never competes with the page's
    own load.
  - Hovering (or touching, on mobile) a nav tab or a "View" link now
    starts prefetching that tab/request immediately — by the time the
    actual click lands, the content is usually already cached, so
    `nriAdminLoadTab()` / `nriAdminOpenRequestDetail()` render it with
    zero visible fetch time.
  - A "Loading…" placeholder still exists as a fallback, but only
    appears if a genuinely cold, un-prefetched tab takes over 200ms to
    respond — so a fast connection or an already-warm cache never
    shows one.
  - Cached tab HTML is invalidated automatically after any delete/
    bulk-delete/status-change/create action (detected via a shared
    `$(document).ajaxSuccess` hook matching those AJAX action names),
    so the instant-from-cache path never serves stale data for more
    than one switch.
- `includes/shortcodes.php` (`nriLoadAdminRequests`, `nriLoadSupportTickets`)
  and `includes/form-submissions.php` (`nriLoadSubmissions`): these
  three table loaders were blanking the table to a "Loading…" row
  *before* every fetch, even when returning to a tab that already had
  rows on screen. Changed so the existing rows stay visible while the
  fetch is in flight (the loader now replaces them once fresh data
  arrives) and the "Loading…" row only appears — after a 200ms delay —
  on a genuinely empty table waiting on a slow first load.

### ✅ Verification
- `php -l` passes clean on every changed PHP file.
- `node --check assets/js/nri-app.js` passes clean.
- Traced the prefetch cache through both consumers (`nriAdminLoadTab`,
  `nriAdminOpenRequestDetail`): cache hit → instant render, no network
  call on the click path; cache miss → falls back to the same
  request as before, with the loading indicator now delayed and
  conditional instead of immediate.
- Traced the invalidation hook: a bulk-delete/delete/status-change AJAX
  call clears `tabCache`, so the next tab switch after a mutating
  action performs a real (not stale-cached) fetch.

---

## v6.4.0 — Admin Dashboard: SPA Navigation, Bulk Select & Bulk Delete
**Release Date:** September 14, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🚀 Fixed: Full-page reloads on Requests / Form Submissions / Support Tickets / Form Files

**Root cause:** every tab click and every "View" link in the admin
dashboard (`[nri_admin_dashboard]`) was a plain `<a href>` to a fresh
URL, so WordPress re-rendered the entire page (header, nav, stat
cards, everything) for each click, including going back to a list
after viewing one record — with no memory of the previous filters,
search term, or page number.

**Fix:**
- `includes/ajax.php`: added two new AJAX endpoints —
  `nri_admin_load_tab` (renders any admin tab's inner HTML server-side
  and returns it as JSON) and `nri_admin_load_request_detail` (renders
  a single request's detail view the same way, via a new shared
  `nri_render_request_view($rid, $embedded=true)` helper).
- `includes/shortcodes.php`: wrapped the tab content in
  `#nri-admin-tab-container`, tagged nav links with `data-tab`, and
  added an embedded (chromeless) rendering mode for the request detail
  view so it can be dropped into the dashboard without its own header.
- `assets/js/nri-app.js`: added an "Admin Dashboard SPA Controller" —
  intercepts nav and View-link clicks, swaps in the new HTML via AJAX,
  and uses `history.pushState`/`popstate` so the browser back/forward
  buttons keep working normally, all without a real page load.
- Current tab/filters/search/page are cached in `sessionStorage`
  (`nri_admin_state_v1`) and restored automatically when a list tab is
  reloaded — so returning from a detail view (or switching tabs and
  back) lands you exactly where you left off.
- Fixed a bug introduced mid-implementation where returning to the
  Requests or Support Tickets tab via the SPA controller left the
  table stuck on "Loading…" — their list-loader scripts only run once
  on the very first real page load, so `nriAdminLoadTab()` now
  explicitly re-invokes `nriLoadAdminRequests()` /
  `nriLoadSupportTickets()` after swapping in that tab's HTML.
- `includes/admin-settings-integrated.php`: the Settings tab's inline
  `<script>` re-executes on every AJAX tab load; its five
  `document.addEventListener(...)` registrations were not idempotent
  and would have silently multiplied (double/triple-firing SMTP
  handlers) — guarded behind a one-time `window.__nriSettingsJsInit`
  flag.

### ☑️ Added: Bulk select & bulk delete (Requests, Form Submissions, Support Tickets, Form Files)

**Root cause:** there was no multi-select in any list, and — during
this work — it was found that the Requests tab's per-row checkboxes
were *supposed* to exist already but never actually appeared, because
they depended on a `nri:rows_rendered` event that nothing in the
codebase ever fired (the toolbar showed "0 selected" but no checkbox
ever rendered on a row).

**Fix:**
- `includes/ajax.php`: added `nri_ajax_bulk_delete_requests` (also
  used for Form Submissions, since a submission is a `nri_request`
  post), `nri_ajax_bulk_delete_tickets`, and `nri_ajax_delete_documents`
  (single or bulk document removal). Refactored single-request delete
  into a shared `nri_delete_request_by_id()` helper used by both the
  single and bulk paths, which explicitly calls `wp_delete_attachment()`
  on every uploaded document before removing the request post/postmeta
  — so bulk deletion does not leave orphaned media files, ticket rows,
  or message rows behind.
- `includes/shortcodes.php` / `includes/form-submissions.php`: each
  list table (Requests, Form Submissions, Support Tickets) gained a
  checkbox column, a "Select All" header checkbox, and a bulk toolbar
  showing a live "N selected" count with Clear Selection and Bulk
  Delete buttons. The Requests table's checkboxes are now baked
  directly into the row template (fixing the dead-event bug above)
  instead of depending on a patch-after-render step.
- `includes/shortcodes.php` (`nri_render_form_details_pane`): added a
  "Form Files" document list with per-row delete buttons and a
  staff-only bulk "Delete Selected" action for uploaded documents.
- `assets/js/nri-app.js`: added matching Bulk Select & Delete
  controllers for the Support Tickets table and for Form Files
  (documents), parallel to the existing Requests one, each showing a
  confirmation dialog that names the exact item count before deleting
  (e.g. "Are you sure you want to delete the selected 12 items?").

### ✅ Verification
- `php -l` passes clean on every changed PHP file.
- Every PHP function that generates a `<script>` block was extracted
  with a brace-depth-aware Python harness (stubbing WordPress
  functions) and run through `node --check` to catch JS syntax errors
  invisible to `php -l` — all pass.
- Traced each new endpoint from its AJAX call site through its PHP
  handler to its JSON response and back to the DOM update it triggers.
- Confirmed the new UI reuses existing CSS classes already defined in
  `assets/css/nri-style.css` (`.nri-btn-danger`, `.nri-nav-item.active`,
  etc.) — no new stylesheet changes required.

---

## v6.3.2 — Mobile Submission Reliability Fix
**Release Date:** September 14, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

### 🐛 Fixed: "Connection Error. Please try again." on Request Submission (mobile)

**Root cause (confirmed by code trace, `assets/js/nri-app.js` submit handler for
`#nri-request-form`):**
1. The document-upload submission used a **hard-coded 30-second AJAX
   timeout** (`timeout: 30000`) with no retry. Marksheets/certificates
   photographed on a phone are routinely 4–10MB each, and several are
   often required at once — on real-world Indian mobile data (3G/4G,
   or an unstable connection) that upload regularly takes longer than
   30 seconds, or the connection drops mid-transfer. Either case
   surfaced as `error: function(xhr, status){...'Connection error...'}`.
2. There was **no client-side image compression or resizing** — full
   camera-resolution photos were uploaded as-is, multiplying the
   problem above.
3. On failure, the **form fields were not persisted anywhere durable**
   (no draft), so if the tab was reloaded after a failure the client's
   entered data was gone.
4. Server-side, `wp_generate_attachment_metadata()` runs per uploaded
   file (thumbnail generation) with no execution-time headroom
   reserved for multiple slow uploads, risking a PHP-level timeout
   that presents identically to a network error.

**Fix:**
- `assets/js/nri-app.js`: replaced the fixed 30s single-shot request
  with `nriUploadWithRetry()` — a size-aware timeout (scales with the
  actual upload size, floor 60s), automatic retry with backoff on
  genuine network failures only (never on a real server validation
  response), and a live upload progress bar.
- Added `nriCompressImage()` — client-side canvas-based downscale/
  recompress of any JPG/PNG over ~700KB (max dimension 1920px, ~75%
  quality) before upload, cutting typical phone-camera photos from
  several MB to a few hundred KB. PDFs are untouched.
- Added client-side 10MB-per-file validation *before* attempting
  upload, so an oversized file is rejected instantly instead of after
  a wasted, slow upload attempt.
- Added `nriSaveDraft()` / `nriRestoreDraft()` — all non-file field
  values are mirrored to `sessionStorage` as the client types, and
  restored automatically if the page reloads after a failed
  submission, so a dropped connection never costs the client their
  typed-in answers.
- Added a visible upload progress bar + status text
  (`includes/shortcodes.php`) so the client sees the submission is
  in progress on slow connections instead of assuming it's frozen.
- `includes/ajax.php` (`nri_ajax_create_request`): raised the PHP
  execution-time budget to 180s for this handler (`set_time_limit` /
  `ini_set('max_execution_time', ...)`, best-effort) so multi-file
  thumbnail generation on a slow upload doesn't itself trigger a
  server-side timeout.
- Error messages are now specific to the actual failure (slow
  connection / dropped connection / server error) and explicitly
  state that entered answers were saved, rather than a single generic
  "Connection error."

**Verification performed:**
- `php -l` clean on every `.php` file in the plugin (all pass).
- `node --check` clean on `assets/js/nri-app.js`.
- Traced the full submit path line-by-line: file validation → size
  check → compression → FormData assembly → `nriUploadWithRetry` →
  success/error branches → draft save/restore/clear — each step's
  output matches what the next step expects, and every exit path
  (success, validation error, timeout, network error, server error)
  re-enables the submit button and hides the progress bar.
- Confirmed the previously-hardcoded `timeout: 30000` no longer
  exists anywhere in the submit path (`grep -n "timeout: 30000"
  assets/js/nri-app.js` → no match in the request-form handler).
- Confirmed no duplicate `nonce` field is introduced (the form's
  existing hidden `nonce` input is left as the sole source, avoiding
  a PHP duplicate-POST-key footgun).

**What this does NOT fix (out of scope of this plugin, needs hosting
config if still encountered after this update):** server-level
`post_max_size` / `upload_max_filesize` / `client_max_body_size`
limits set by the hosting provider or reverse proxy. If a host has
these set very low (e.g. `post_max_size` under ~15MB while 3–4
required documents are attached), a large multi-file submission can
still be rejected at the web-server layer before PHP ever runs. This
plugin cannot change those from application code; recommend
`post_max_size ≥ 32M`, `upload_max_filesize ≥ 16M` on the host.

---

## v6.3.0 — Bug Fixes & Feature Enhancements
**Release Date:** April 30, 2026  |  **Status:** Production Ready ✅
**Breaking Changes:** None  |  **Backward Compatible:** Yes  |  **DB Migrations:** None

---

### 🐛 Bug Fixes (7 bugs fixed)

#### Fix 1 · Set Timeline → "Invalid Date"
**Cause:** `nri_calculate_delivery_date()` returns `$result['delivery_date']` but
the handler read `$result['date']` (non-existent key) → null → failed validity check.
**File:** `includes/ajax.php` — `nri_ajax_set_timeline()`

#### Fix 2 · "Service Not Available" Status → "Invalid status" Error
**Cause:** Both `nri_ajax_update_status` handlers had a hardcoded whitelist that
did not include `service_not_available`. Also `nri_status_label()` / `nri_status_color()`
had no mapping for it, so it rendered as a raw slug.
**Files:** `includes/ajax.php` (both status handlers), `includes/helpers.php`

#### Fix 3 · Save Email Template → Error
**Cause 1:** `wp_ajax_nri_save_email_template` was never registered — no PHP handler existed.
**Cause 2:** JS sent `NRI.nonce` (frontend) instead of `NRI.admin_nonce`, failing the security check.
**Files:** `includes/ajax.php` (added handler), `includes/admin-settings-integrated.php` (JS fix)

#### Fix 4 · Add / Edit Quick Reply → Error
**Cause 1:** Handlers used `check_ajax_referer()` instead of plugin-standard `nri_check_nonce()`.
**Cause 2:** Edit form sends hidden field `reply_id` but handler read `$_POST['id']`.
**Cause 3:** JS used wrong nonce key.
**File:** `includes/quick-replies.php`

#### Fix 5 · Add Holiday → Error on Save
**Cause 1:** Form sends `holiday_date`, `holiday_name`, `holiday_type`; handler expected `date`, `name`, `type`.
**Cause 2:** Inconsistent nonce handling and wrong nonce key in JS.
**File:** `includes/delivery-calculator.php`

#### Fix 6 · Calculate Delivery Date Button → Error
**Cause:** JS fires a **GET** request; PHP handler only read `$_POST` and used `check_ajax_referer()` which also only checks `$_POST`. Handler also only accepted `working_days` param, not `days`.
**File:** `includes/delivery-calculator.php` — now reads `$_REQUEST`, accepts `days` or `working_days`

#### Fix 7 · Shipping Charges Blank in Quotation Emails
**Cause:** `nri_get_meta()` never returned `shipping_charges` or `shipping_type`.
**File:** `includes/helpers.php`

---

### ✨ New Features (5 additions)

#### Feature 1 · Terms & Conditions Email Template
New built-in template type `terms_conditions` ("📋 Terms & Conditions") added with
a full HTML template pre-filled with 5 standard clauses. Fully editable.

#### Feature 2 · {DOCUMENT_TYPE} Variable in All Templates
All templates (Settings + Communication panel) now support `{DOCUMENT_TYPE}` which
resolves to the request's `field_document_type` value (falls back to `field_service_type`).
Variable hint text in the editor updated.

#### Feature 3 · Create New Custom Templates
"➕ New Template" button in the Settings → Email Templates tab creates a blank
template from scratch. Custom templates appear as tabs alongside built-ins and can
be edited, tested, duplicated, and deleted.

#### Feature 4 · Duplicate Any Template
"📋 Duplicate" button on every template. Prompts for a name, copies the current
template, and navigates to the new copy immediately.

#### Feature 5 · Rich HTML Preview Toggle
The template editor now has an "👁️ Rich Preview" / "🖥️ HTML Source" toggle.
Preview renders the HTML in a sandboxed iframe so you see the final email layout
without leaving the Settings page.

---

### 📁 Files Changed

| File | Type |
|---|---|
| `nri-platform.php` | Version bump → 6.3.0 |
| `includes/ajax.php` | Fix 1, 2, 3 (new handlers), variable expansion |
| `includes/helpers.php` | Fix 2, 7 |
| `includes/delivery-calculator.php` | Fix 5, 6 |
| `includes/quick-replies.php` | Fix 4 |
| `includes/email-templates.php` | Feature 1, 2, 3, 4 |
| `includes/admin-settings-integrated.php` | Fix 3, Feature 3, 4, 5 |
| `includes/notifications.php` | Feature 2 |

---

### 🚀 Deployment Steps

1. Back up database + plugin files
2. Upload the 8 files above to `/wp-content/plugins/nri-platform/`
3. No deactivate/reactivate needed (no DB migrations)
4. Hard-refresh admin: Ctrl+Shift+R
5. Test checklist:
   - Settings → Email Templates → Save → ✅ success message
   - Settings → Quick Replies → Add → ✅ saves correctly
   - Settings → Holidays → Add → ✅ saves correctly
   - Settings → Holidays → Calculate Date → ✅ shows result
   - View Request → Set Timeline (by days) → ✅ sets date
   - View Request → Status → Service Not Available → ✅ saves
   - Email Templates → New Template / Duplicate → ✅ creates copy
   - Email Templates → Rich Preview → ✅ renders HTML
