<?php
/**
 * Plugin Name: NRI Platform
 * Plugin URI:  https://visasure.in
 * Description: NRI Document Retrieval Platform
 * Version:     6.27.6
 * Author:      NRI Platform
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! defined( 'NRI_VER' ) ) { define( 'NRI_VER', '6.27.6' ); }
if ( ! defined( 'NRI_DIR' ) ) { define( 'NRI_DIR', plugin_dir_path( __FILE__ ) ); }
if ( ! defined( 'NRI_URL' ) ) { define( 'NRI_URL', plugin_dir_url( __FILE__ ) ); }

/* ----------------------------------------------------------
 * Debug: write errors to a log file in the plugin folder
 * Check wp-content/plugins/nri-platform/nri-debug.log
 * -------------------------------------------------------- */
function nri_log( $msg ) {
    $log = NRI_DIR . 'nri-debug.log';
    // Keep the log from growing without limit (it is written on every request): once it
    // passes ~2MB, move it aside so there is always room to record NEW errors.
    if ( @filesize( $log ) > 2 * 1024 * 1024 ) { @rename( $log, $log . '.old' ); }
    @file_put_contents( $log, date('[Y-m-d H:i:s] ') . $msg . "\n", FILE_APPEND );
}

function nri_error_handler( $errno, $errstr, $errfile, $errline ) {
    if ( strpos( $errfile, 'nri-platform' ) !== false ) {
        nri_log( 'PHP Error ' . $errno . ': ' . $errstr . ' in ' . $errfile . ' on line ' . $errline );
    }
    return false;
}
set_error_handler( 'nri_error_handler' );

function nri_safe_include( $name ) {
    $path = NRI_DIR . 'includes/' . $name . '.php';
    if ( ! file_exists( $path ) ) {
        nri_log( "MISSING FILE: $path" );
        return;
    }
    nri_log( "Loading: $name" );
    include_once $path;
    nri_log( "Loaded OK: $name" );
}

add_action( 'plugins_loaded', 'nri_load_all', 1 );
function nri_load_all() {
    nri_log( '=== plugins_loaded START ===' );
    foreach ( array(
        'helpers','document-download','schema','roles','capabilities','auth',
        'notifications','smtp','post-types','ajax','shortcodes',
        'enqueue','admin-menu','vendors','whatsapp','form-submissions',
        'migrations','email-templates','quick-replies','delivery-calculator',
        'admin-settings-integrated',
    ) as $f ) {
        nri_safe_include( $f );
    }
    nri_log( '=== plugins_loaded END ===' );
    // Runtime DB migration (runs once per version bump)
    $migrated = get_option( 'nri_db_version', '0' );
    if ( version_compare( $migrated, '4.3.1', '<' ) ) {
        global $wpdb;
        $col = $wpdb->get_results( "SHOW COLUMNS FROM {$wpdb->prefix}nri_tickets LIKE 'updated_at'" );
        if ( empty( $col ) ) {
            $wpdb->query( "ALTER TABLE {$wpdb->prefix}nri_tickets ADD COLUMN updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at" );
        }
        update_option( 'nri_db_version', '4.3.1' );
    }
    // v5.1 migration: add conditions column to fields table
    if ( version_compare( get_option( 'nri_db_version', '0' ), '5.1', '<' ) ) {
        global $wpdb;
        $cols = $wpdb->get_col( "SHOW COLUMNS FROM {$wpdb->prefix}nri_fields" );
        if ( ! in_array( 'conditions', $cols ) ) {
            $wpdb->query( "ALTER TABLE {$wpdb->prefix}nri_fields ADD COLUMN conditions longtext DEFAULT NULL" );
            nri_log( 'Migration 5.1: Added conditions column to nri_fields' );
        }
        update_option( 'nri_db_version', '5.1' );
    }
    if ( version_compare( get_option( 'nri_db_version', '0' ), '5.2', '<' ) ) {
        global $wpdb;
        $cols = $wpdb->get_col( "SHOW COLUMNS FROM {$wpdb->prefix}nri_fields" );
        if ( ! in_array( 'description', $cols ) ) {
            $wpdb->query( "ALTER TABLE {$wpdb->prefix}nri_fields ADD COLUMN description text DEFAULT NULL" );
            nri_log( 'Migration 5.2: Added description column to nri_fields' );
        }
        update_option( 'nri_db_version', '5.2' );
    }
}

register_activation_hook( __FILE__, 'nri_on_activate' );
function nri_on_activate() {
    nri_safe_include( 'helpers' );
    nri_safe_include( 'schema' );
    nri_safe_include( 'roles' );
    nri_safe_include( 'admin-menu' );
    if ( function_exists( 'nri_register_roles' ) ) { nri_register_roles(); }
    if ( function_exists( 'nri_create_tables' )  ) { nri_create_tables();  }
    if ( function_exists( 'nri_create_vendor_table' ) ) { nri_create_vendor_table(); }
    if ( function_exists( 'nri_create_pages' )   ) { nri_create_pages();   }
    // DB migration: add updated_at to tickets table if missing
    global $wpdb;
    $col = $wpdb->get_results("SHOW COLUMNS FROM {$wpdb->prefix}nri_tickets LIKE 'updated_at'");
    if ( empty( $col ) ) {
        $wpdb->query("ALTER TABLE {$wpdb->prefix}nri_tickets ADD COLUMN updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at");
    }
    update_option( 'nri_flush_needed', 1 );
    flush_rewrite_rules();
    if ( ! wp_next_scheduled( 'nri_daily_cron' ) ) {
        wp_schedule_event( time(), 'daily', 'nri_daily_cron' );
    }
    nri_log( 'Activation complete v4.3.1' );
}

register_deactivation_hook( __FILE__, 'nri_on_deactivate' );
function nri_on_deactivate() {
    flush_rewrite_rules();
    wp_clear_scheduled_hook( 'nri_daily_cron' );
}

add_action( 'nri_daily_cron', 'nri_cron_tick' );
function nri_cron_tick() { /* reserved */ }
