# NRI Platform v6.2.1 - DEPLOYMENT INSTRUCTIONS

## 🎯 WHAT'S INCLUDED

This deployment package includes all Phase 1 & 2 improvements:

### ✅ Implemented Features:
1. **CSS Improvements** - Button alignment and status flow styling
2. **Email Templates System** - Professional HTML email templates
3. **Quick Replies** - Predefined response templates
4. **Delivery Calculator** - Smart working days calculation with holidays
5. **Database Migrations** - Safe, reversible database updates

### 📦 Files in This Package:
- `nri-platform.php` - Updated main plugin file (v6.2.1)
- `nri-style.css` - Enhanced CSS with new improvements
- `email-templates.php` - NEW email template system
- `quick-replies.php` - NEW quick reply functionality
- `delivery-calculator.php` - NEW smart delivery calculator
- `migrations.php` - NEW database migration system

---

## ⚠️ PRE-DEPLOYMENT CHECKLIST

**CRITICAL: Complete ALL steps before deployment**

- [ ] **Backup database** - Use phpMyAdmin or your hosting panel
- [ ] **Backup current plugin folder** - `/wp-content/plugins/nri-platform/`
- [ ] **Test on staging first** - If you have a staging environment
- [ ] **Verify WordPress version** - 5.8 or higher
- [ ] **Verify PHP version** - 7.4 or higher
- [ ] **Check disk space** - At least 10MB free
- [ ] **Inform users** - If any downtime expected

---

## 🚀 DEPLOYMENT STEPS

### Step 1: Backup Current System

```bash
# SSH into your server
cd /path/to/wordpress/wp-content/plugins/

# Create backup
cp -r nri-platform nri-platform-backup-$(date +%Y%m%d)

# Backup database
mysqldump -u username -p database_name > nri_backup_$(date +%Y%m%d).sql
```

### Step 2: Deploy Files

**Option A: Via FTP/SFTP**
1. Connect to your server via FTP/SFTP
2. Navigate to `/wp-content/plugins/nri-platform/`
3. Upload files:
   - Upload `nri-platform.php` to root
   - Upload `nri-style.css` to `/assets/css/`
   - Upload `*.php` files to `/includes/`

**Option B: Via SSH**
```bash
# Upload deployment package to server
scp -r nri-platform-v6.2.1-deployment/ user@yourserver:/tmp/

# SSH into server
ssh user@yourserver

# Navigate to plugin directory
cd /path/to/wordpress/wp-content/plugins/nri-platform/

# Copy files
cp /tmp/nri-platform-v6.2.1-deployment/nri-platform.php ./
cp /tmp/nri-platform-v6.2.1-deployment/nri-style.css ./assets/css/
cp /tmp/nri-platform-v6.2.1-deployment/*.php ./includes/
```

### Step 3: Verify File Permissions

```bash
# Set correct permissions
chmod 644 nri-platform.php
chmod 644 assets/css/nri-style.css
chmod 644 includes/*.php
```

### Step 4: Activate Changes

**IMPORTANT: Deactivate and reactivate the plugin to run migrations**

1. Go to WordPress Admin → Plugins
2. **Deactivate** NRI Platform
3. **Activate** NRI Platform again
4. Check for error messages

### Step 5: Verify Deployment

✅ **Check these items:**

1. **Plugin Version**
   - Go to Plugins page
   - Verify version shows "6.2.1"

2. **Database Migrations**
   - Check debug log: `/wp-content/plugins/nri-platform/nri-debug.log`
   - Look for: "Migration status_enum: SUCCESS"
   - Look for: "Migration shipping_charges: SUCCESS"
   - Look for: "Migration holidays_table: SUCCESS"

3. **New Tables**
   ```sql
   -- Run this in phpMyAdmin
   SHOW TABLES LIKE 'wp_nri_holidays';
   -- Should return the table
   ```

4. **New Columns**
   ```sql
   -- Check new columns exist
   SHOW COLUMNS FROM wp_nri_tickets LIKE 'shipping%';
   -- Should show shipping_charges and shipping_type
   ```

5. **CSS Changes**
   - Visit admin dashboard
   - Check if buttons are aligned horizontally
   - Test on mobile (should stack vertically)

6. **Email Templates**
   - Check `/includes/email-templates.php` exists
   - No error messages in debug log

7. **Quick Replies**
   - Check default quick replies initialized
   - Check admin options saved

---

## 🔍 POST-DEPLOYMENT TESTING

### Test 1: Button Alignment
1. Go to Admin Dashboard → Requests
2. Verify Delete/View buttons are side-by-side
3. Test on mobile (should stack vertically)

### Test 2: Email Templates
```php
// Test email template (run in WordPress)
$template = nri_get_email_template('quotation', array(
    'CUSTOMER_NAME' => 'Test User',
    'UNIVERSITY_NAME' => 'Delhi University'
));

var_dump($template); // Should return template array
```

### Test 3: Quick Replies
```php
// Check quick replies loaded
$replies = nri_get_quick_replies();
var_dump(count($replies)); // Should show 3 default replies
```

### Test 4: Delivery Calculator
```php
// Test calculation
$result = nri_calculate_delivery_date(30);
var_dump($result); // Should return array with delivery_date
```

### Test 5: Database Integrity
```sql
-- Verify status ENUM updated
SELECT COLUMN_TYPE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'wp_nri_tickets' 
AND COLUMN_NAME = 'status';

-- Should include: ready_for_processing, service_not_available
```

---

## ⚠️ TROUBLESHOOTING

### Problem: Migrations Not Running

**Symptom:** Debug log shows "Migration X: FAILED"

**Solution:**
1. Check database permissions
2. Verify table exists
3. Run migrations manually via phpMyAdmin
4. Check error log for specific SQL error

### Problem: White Screen of Death

**Symptom:** Site shows blank white page

**Solution:**
1. Enable WordPress debug mode
2. Check error log
3. Restore from backup if critical
4. Check for syntax errors in uploaded files

### Problem: CSS Not Loading

**Symptom:** Buttons still vertical

**Solution:**
1. Clear WordPress cache
2. Clear browser cache
3. Verify `nri-style.css` uploaded correctly
4. Check file permissions (should be 644)
5. Hard refresh browser (Ctrl+Shift+R)

### Problem: Email Templates Not Working

**Symptom:** Emails not sending or showing errors

**Solution:**
1. Check `/includes/email-templates.php` exists
2. Verify file loaded in debug log
3. Test email sending separately
4. Check WordPress mail settings

---

## 🔄 ROLLBACK PROCEDURE

If anything goes wrong, follow these steps:

### Quick Rollback (Restore Backup)

```bash
# Stop and restore from backup
cd /path/to/wordpress/wp-content/plugins/

# Remove current version
rm -rf nri-platform

# Restore backup
cp -r nri-platform-backup-YYYYMMDD nri-platform

# Restore database
mysql -u username -p database_name < nri_backup_YYYYMMDD.sql
```

### Partial Rollback (Keep Data, Revert Code)

```bash
# Only restore plugin files (keeps database changes)
cd /path/to/wordpress/wp-content/plugins/
cp -r nri-platform-backup-YYYYMMDD/nri-platform.php nri-platform/
cp -r nri-platform-backup-YYYYMMDD/assets nri-platform/
cp -r nri-platform-backup-YYYYMMDD/includes nri-platform/
```

### Database-Only Rollback

```php
// Run in WordPress or phpMyAdmin
// This runs the rollback function from migrations.php
nri_rollback_v6_2_1();
```

**WARNING:** Database rollback will remove:
- shipping_charges and shipping_type columns
- nri_holidays table
- New status values (ready_for_processing, service_not_available)

---

## 📊 SUCCESS CRITERIA

✅ **Deployment is successful when:**

- [ ] Plugin shows version 6.2.1
- [ ] No PHP errors in logs
- [ ] Buttons align horizontally on desktop
- [ ] Buttons stack vertically on mobile
- [ ] Database migrations completed successfully
- [ ] New columns exist in wp_nri_tickets
- [ ] New table wp_nri_holidays exists
- [ ] Email templates module loads without errors
- [ ] Quick replies initialized with defaults
- [ ] Delivery calculator functions work
- [ ] All existing features still work
- [ ] No user-reported issues

---

## 📝 POST-DEPLOYMENT CHECKLIST

After successful deployment:

- [ ] Test all existing features (create request, update status, etc.)
- [ ] Test new features (email templates, quick replies)
- [ ] Monitor error logs for 24 hours
- [ ] Inform team of new features
- [ ] Update internal documentation
- [ ] Plan Phase 3 deployment (Export & Bulk features)

---

## 📞 SUPPORT

### If Issues Occur:

1. **Check Debug Log**
   - Location: `/wp-content/plugins/nri-platform/nri-debug.log`
   - Look for errors marked "FAILED" or "ERROR"

2. **Check Error Log**
   - Location: `/wp-content/debug.log` (if WP_DEBUG enabled)
   - Look for PHP errors or warnings

3. **Rollback if Critical**
   - Follow Rollback Procedure above
   - Restore from backup

4. **Contact Support**
   - Provide debug log excerpt
   - Provide error log excerpt
   - Describe what was happening when error occurred

---

## 🎉 NEXT STEPS

After successful deployment of v6.2.1:

1. **Monitor for 48 hours** - Watch for any issues
2. **Gather feedback** - From admin users
3. **Plan Phase 3** - Export & Bulk Operations features
4. **Plan Phase 4** - Advanced automation features

---

## 📅 VERSION HISTORY

### v6.2.1 (Current)
- ✅ Button alignment improvements
- ✅ Email template system
- ✅ Quick reply system
- ✅ Delivery date calculator
- ✅ Database migrations for new features
- ✅ Status flow enhancements

### v6.2.0 (Previous)
- Original version

---

## ✅ DEPLOYMENT COMPLETE

Once all checks pass, deployment is complete!

**Remember to:**
- Remove deployment package from server
- Document any customizations made
- Update team on new features
- Schedule next phase implementation

---

**Deployment Package Version:** 6.2.1  
**Created:** April 30, 2026  
**Status:** Ready for Production

