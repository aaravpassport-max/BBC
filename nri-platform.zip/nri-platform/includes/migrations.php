<?php
/**
 * Database Migrations for v6.2.1
 * All migrations are SAFE and REVERSIBLE
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Run all v6.2.1 migrations
 */
function nri_migrate_v6_2_1() {
    $current_version = get_option( 'nri_db_version', '0' );
    
    if ( version_compare( $current_version, '6.2.1', '>=' ) ) {
        nri_log( 'Database already at v6.2.1 or higher' );
        return true;
    }
    
    nri_log( '=== Starting v6.2.1 Migration ===' );
    
    $success = true;
    
    // Migration 1: Add shipping charges columns
    if ( ! nri_migrate_shipping_charges() ) {
        $success = false;
    }
    
    // Migration 2: Update status ENUM
    if ( ! nri_migrate_status_enum() ) {
        $success = false;
    }
    
    // Migration 3: Create holidays table
    if ( ! nri_migrate_holidays_table() ) {
        $success = false;
    }
    
    if ( $success ) {
        update_option( 'nri_db_version', '6.2.1' );
        nri_log( '=== v6.2.1 Migration Complete ===' );
    } else {
        nri_log( '=== v6.2.1 Migration FAILED - Review errors above ===' );
    }
    
    return $success;
}

/**
 * Migration 1: Add shipping charges to tickets table
 * SAFE: Columns are optional with default values
 */
function nri_migrate_shipping_charges() {
    global $wpdb;
    
    $table = $wpdb->prefix . 'nri_tickets';
    
    // Safety check: ensure table exists
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
        nri_log( 'Migration shipping_charges: Table not found' );
        return false;
    }
    
    // Check if columns already exist
    $columns = $wpdb->get_col( "SHOW COLUMNS FROM $table" );
    
    $migrations_needed = array();
    
    if ( ! in_array( 'shipping_charges', $columns ) ) {
        $migrations_needed[] = "ADD COLUMN shipping_charges DECIMAL(10,2) DEFAULT 0 AFTER quote_amount";
    }
    
    if ( ! in_array( 'shipping_type', $columns ) ) {
        $migrations_needed[] = "ADD COLUMN shipping_type VARCHAR(50) DEFAULT 'domestic' AFTER shipping_charges";
    }
    
    if ( empty( $migrations_needed ) ) {
        nri_log( 'Migration shipping_charges: Already complete' );
        return true;
    }
    
    // Apply migrations
    $query = "ALTER TABLE $table " . implode( ', ', $migrations_needed );
    
    if ( $wpdb->query( $query ) === false ) {
        nri_log( 'Migration shipping_charges: FAILED - ' . $wpdb->last_error );
        return false;
    }
    
    nri_log( 'Migration shipping_charges: SUCCESS' );
    return true;
}

/**
 * Migration 2: Update status ENUM to include new statuses
 * SAFE: ENUM extension preserves old values
 */
function nri_migrate_status_enum() {
    global $wpdb;
    
    $table = $wpdb->prefix . 'nri_tickets';
    
    // Safety check: ensure table exists
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
        nri_log( 'Migration status_enum: Table not found' );
        return false;
    }
    
    // Check current status column definition
    $result = $wpdb->get_results( "SHOW COLUMNS FROM $table WHERE Field = 'status'" );
    if ( empty( $result ) ) {
        nri_log( 'Migration status_enum: Status column not found' );
        return false;
    }
    
    $current_type = $result[0]->Type;
    
    // Check if new values already exist
    if ( strpos( $current_type, 'ready_for_processing' ) !== false && 
         strpos( $current_type, 'service_not_available' ) !== false ) {
        nri_log( 'Migration status_enum: Already complete' );
        return true;
    }
    
    // Apply the ENUM update (backward compatible)
    $query = "ALTER TABLE $table 
              MODIFY COLUMN status ENUM(
                  'received',
                  'under_review',
                  'ready_for_processing',
                  'processing',
                  'dispatched',
                  'service_not_available',
                  'completed'
              ) DEFAULT 'received'";
    
    if ( $wpdb->query( $query ) === false ) {
        nri_log( 'Migration status_enum: FAILED - ' . $wpdb->last_error );
        return false;
    }
    
    nri_log( 'Migration status_enum: SUCCESS' );
    return true;
}

/**
 * Migration 3: Create holidays table for delivery date calculation
 * SAFE: New table only, no impact on existing data
 */
function nri_migrate_holidays_table() {
    global $wpdb;
    
    $table = $wpdb->prefix . 'nri_holidays';
    $charset_collate = $wpdb->get_charset_collate();
    
    // Check if table already exists
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) === $table ) {
        nri_log( 'Migration holidays_table: Already exists' );
        return true;
    }
    
    $sql = "CREATE TABLE $table (
        id INT AUTO_INCREMENT PRIMARY KEY,
        date DATE NOT NULL,
        holiday_name VARCHAR(255),
        holiday_type ENUM('national', 'state', 'university') DEFAULT 'national',
        state_code VARCHAR(10),
        university_id INT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_holiday (date, university_id),
        KEY idx_date (date),
        KEY idx_type (holiday_type),
        KEY idx_university (university_id)
    ) $charset_collate;";
    
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
    
    // Verify table was created
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
        nri_log( 'Migration holidays_table: FAILED to create' );
        return false;
    }
    
    nri_log( 'Migration holidays_table: SUCCESS' );
    
    // Add some default Indian national holidays for 2026
    nri_seed_default_holidays();
    
    return true;
}

/**
 * Seed default holidays for India (2026)
 */
function nri_seed_default_holidays() {
    global $wpdb;
    
    $table = $wpdb->prefix . 'nri_holidays';
    
    $holidays = array(
        array( '2026-01-26', 'Republic Day', 'national' ),
        array( '2026-03-08', 'Holi', 'national' ),
        array( '2026-04-02', 'Mahavir Jayanti', 'national' ),
        array( '2026-04-06', 'Ram Navami', 'national' ),
        array( '2026-08-15', 'Independence Day', 'national' ),
        array( '2026-10-02', 'Gandhi Jayanti', 'national' ),
        array( '2026-10-24', 'Dussehra', 'national' ),
        array( '2026-11-12', 'Diwali', 'national' ),
        array( '2026-11-13', 'Diwali (Second Day)', 'national' ),
        array( '2026-12-25', 'Christmas', 'national' ),
    );
    
    foreach ( $holidays as $holiday ) {
        $wpdb->insert(
            $table,
            array(
                'date' => $holiday[0],
                'holiday_name' => $holiday[1],
                'holiday_type' => $holiday[2]
            ),
            array( '%s', '%s', '%s' )
        );
    }
    
    nri_log( 'Default holidays seeded for 2026' );
}

/**
 * Rollback function (for testing/emergency)
 * WARNING: Only use if absolutely necessary
 */
function nri_rollback_v6_2_1() {
    if ( ! current_user_can( 'manage_options' ) ) {
        nri_log( 'Rollback denied: insufficient permissions' );
        return false;
    }
    
    global $wpdb;
    
    nri_log( '=== Starting v6.2.1 Rollback ===' );
    
    // Rollback 1: Remove shipping columns
    $table = $wpdb->prefix . 'nri_tickets';
    $wpdb->query( "ALTER TABLE $table DROP COLUMN IF EXISTS shipping_charges, DROP COLUMN IF EXISTS shipping_type" );
    
    // Rollback 2: Drop holidays table
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}nri_holidays" );
    
    // Rollback 3: Restore old status ENUM
    $wpdb->query( "ALTER TABLE $table 
                   MODIFY COLUMN status ENUM('received','under_review','processing','dispatched','completed') 
                   DEFAULT 'received'" );
    
    update_option( 'nri_db_version', '6.2.0' );
    
    nri_log( '=== v6.2.1 Rollback Complete ===' );
    
    return true;
}

/**
 * v6.18.0: Internal Status (CRM pipeline) table for installs that are
 * upgrading rather than freshly activating — nri_create_tables() (schema.php)
 * only ever runs on activation, so an already-installed site would
 * otherwise never get this table just from dropping in a new plugin
 * version. SAFE: new table only, no impact on any existing data; requests
 * with no internal_status meta yet simply read as "Inquiry" (see
 * nri_get_meta() in helpers.php) until staff explicitly change one.
 */
function nri_migrate_v6_18_0() {
    if ( version_compare( get_option( 'nri_db_version', '0' ), '6.18.0', '>=' ) ) {
        return true;
    }
    global $wpdb;
    $table = $wpdb->prefix . 'nri_internal_statuses';
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table (
            id INT AUTO_INCREMENT PRIMARY KEY,
            slug VARCHAR(100) NOT NULL,
            label VARCHAR(200) NOT NULL,
            color VARCHAR(20) DEFAULT '#6b7280',
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_slug (slug)
        ) $charset_collate;";
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
            nri_log( 'Migration v6.18.0: FAILED to create nri_internal_statuses' );
            return false;
        }
        nri_log( 'Migration v6.18.0: nri_internal_statuses created' );
    }
    if ( ! $wpdb->get_var( "SELECT COUNT(*) FROM $table" ) && function_exists( 'nri_seed_internal_statuses' ) ) {
        nri_seed_internal_statuses();
        nri_log( 'Migration v6.18.0: default internal statuses seeded' );
    }
    update_option( 'nri_db_version', '6.18.0' );
    nri_log( 'Migration v6.18.0: complete' );
    return true;
}

// Auto-run migrations on plugins_loaded
add_action( 'plugins_loaded', 'nri_migrate_v6_2_1', 20 );
add_action( 'plugins_loaded', 'nri_migrate_v6_18_0', 21 );

nri_log( 'Migration module loaded' );
