<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nri_generate_request_id() {
    global $wpdb;
    $wpdb->query( "INSERT INTO {$wpdb->options}(option_name,option_value,autoload) VALUES('nri_counter',1,'no') ON DUPLICATE KEY UPDATE option_value=option_value+1" );
    $n = (int) $wpdb->get_var( "SELECT option_value FROM {$wpdb->options} WHERE option_name='nri_counter'" );
    return 'NRI-' . date('Y') . '-' . str_pad( $n, 4, '0', STR_PAD_LEFT );
}

// -----------------------------------------------------------
// REQUEST DATE FILTER — shared by the Requests tab and Form Submissions
// tab (nri_ajax_get_requests()/nri_ajax_list_submissions() in ajax.php /
// form-submissions.php) so both filter identically against the request's
// actual submission date/time (its post_date — when it was received, not
// any other date field on the request).
// -----------------------------------------------------------

/**
 * Turns a date-filter key (+ optional date value(s) for the two
 * user-supplied cases) into a concrete [start, end] datetime range in the
 * site's configured timezone, as 'Y-m-d H:i:s' strings ready for
 * WP_Query's date_query 'after'/'before'. Either end can be null, meaning
 * "no lower/upper bound" — the caller only adds the keys it actually got
 * a value for. Returns array(null, null) for an empty/unknown/'all' filter,
 * meaning "no date filter at all".
 *
 * $from/$to are 'Y-m-d' strings from the date inputs — for 'specific_date'
 * only $from is used (the single date picker), for 'custom_range' both
 * are optional and independent (a from-only range is "on or after", a
 * to-only range is "on or before").
 */
function nri_compute_request_date_range( $filter, $from = '', $to = '' ) {
    $filter = sanitize_key( $filter );
    $tz     = wp_timezone();
    $now    = new DateTime( 'now', $tz );
    $start  = null;
    $end    = null;

    switch ( $filter ) {
        case 'today':
            $start = ( clone $now )->setTime( 0, 0, 0 );
            $end   = ( clone $now )->setTime( 23, 59, 59 );
            break;
        case 'yesterday':
            $y     = ( clone $now )->modify( '-1 day' );
            $start = ( clone $y )->setTime( 0, 0, 0 );
            $end   = ( clone $y )->setTime( 23, 59, 59 );
            break;
        case 'this_week':
            // Monday-start week, through right now (not through Sunday —
            // "this week" shouldn't show requests that haven't happened
            // yet if today is, say, Wednesday).
            $start = ( clone $now )->modify( 'monday this week' )->setTime( 0, 0, 0 );
            $end   = ( clone $now )->setTime( 23, 59, 59 );
            break;
        case 'last_week':
            $this_monday = ( clone $now )->modify( 'monday this week' )->setTime( 0, 0, 0 );
            $start       = ( clone $this_monday )->modify( '-7 days' );
            $end         = ( clone $start )->modify( '+6 days' )->setTime( 23, 59, 59 );
            break;
        case 'this_month':
            $start = ( clone $now )->modify( 'first day of this month' )->setTime( 0, 0, 0 );
            $end   = ( clone $now )->setTime( 23, 59, 59 );
            break;
        case 'last_month':
            $start = ( clone $now )->modify( 'first day of last month' )->setTime( 0, 0, 0 );
            $end   = ( clone $now )->modify( 'last day of last month' )->setTime( 23, 59, 59 );
            break;
        case 'specific_date':
            if ( $from && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) {
                $d = DateTime::createFromFormat( 'Y-m-d', $from, $tz );
                if ( $d ) {
                    $start = ( clone $d )->setTime( 0, 0, 0 );
                    $end   = ( clone $d )->setTime( 23, 59, 59 );
                }
            }
            break;
        case 'custom_range':
            if ( $from && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) {
                $d1 = DateTime::createFromFormat( 'Y-m-d', $from, $tz );
                if ( $d1 ) { $start = ( clone $d1 )->setTime( 0, 0, 0 ); }
            }
            if ( $to && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) ) {
                $d2 = DateTime::createFromFormat( 'Y-m-d', $to, $tz );
                if ( $d2 ) { $end = ( clone $d2 )->setTime( 23, 59, 59 ); }
            }
            break;
        default:
            // '' (All Dates) or anything unrecognized — no filter.
            return array( null, null );
    }

    return array(
        $start ? $start->format( 'Y-m-d H:i:s' ) : null,
        $end   ? $end->format( 'Y-m-d H:i:s' )   : null,
    );
}

/**
 * Given already-computed [after, before] bounds (from
 * nri_compute_request_date_range()), returns the 'date_query' array to
 * merge into a WP_Query args array — or an empty array if both bounds are
 * null (no filter to apply). Always against post_date (submission time).
 */
function nri_request_date_query( $after, $before ) {
    if ( ! $after && ! $before ) { return array(); }
    $dq = array( 'column' => 'post_date', 'inclusive' => true );
    if ( $after )  { $dq['after']  = $after; }
    if ( $before ) { $dq['before'] = $before; }
    // WP_Query's 'date_query' expects a flat array of clause arrays at the
    // top level (e.g. array( array('column'=>...,'after'=>...) )) — NOT an
    // extra nesting level around that. Wrapping $dq in array() ONE MORE time
    // than that here would make WP_Query treat the single clause as an
    // unkeyed sub-array with no 'column'/'after'/'before' of its own,
    // silently matching against nothing recognizable and making every date
    // filter a no-op (still returns unfiltered results, no error/warning).
    return array( $dq );
}

/**
 * Renders the date-filter <select> plus its two conditional date input
 * groups (Specific Date / Custom Range — hidden until chosen, via CSS in
 * nri-style.css keyed off the shared .nri-datef-group class + data-show
 * attribute, toggled by nriInitDateFilterToggle() in nri_admin_js()).
 * $id_prefix lets the Requests tab and Form Submissions tab each get
 * their own element ids (e.g. "nri-admin-date" -> #nri-admin-date-f,
 * #nri-admin-date-specific, #nri-admin-date-from, #nri-admin-date-to)
 * while sharing one markup/behavior implementation.
 */
function nri_render_date_filter_controls( $id_prefix ) {
    $options = array(
        ''             => 'All Dates',
        'today'        => 'Today',
        'yesterday'    => 'Yesterday',
        'this_week'    => 'This Week',
        'last_week'    => 'Last Week',
        'this_month'   => 'This Month',
        'last_month'   => 'Last Month',
        'specific_date'=> 'Specific Date…',
        'custom_range' => 'Custom Range…',
    );
    $o  = '<select id="' . esc_attr( $id_prefix ) . '-f" class="nri-filter-sel" title="Filter by submission date">';
    foreach ( $options as $val => $label ) {
        $o .= '<option value="' . esc_attr( $val ) . '">' . esc_html( $label ) . '</option>';
    }
    $o .= '</select>';
    // Hidden by default (nri-style.css); shown by nriInitDateFilterToggle()
    // only when the select above is set to the matching value.
    $o .= '<span id="' . esc_attr( $id_prefix ) . '-specific-wrap" class="nri-datef-group" style="display:none;">';
    $o .= '<input type="date" id="' . esc_attr( $id_prefix ) . '-specific" class="nri-filter-sel">';
    $o .= '</span>';
    $o .= '<span id="' . esc_attr( $id_prefix ) . '-range-wrap" class="nri-datef-group" style="display:none;">';
    $o .= '<input type="date" id="' . esc_attr( $id_prefix ) . '-from" class="nri-filter-sel" title="From">';
    $o .= '<span class="nri-datef-sep">&ndash;</span>';
    $o .= '<input type="date" id="' . esc_attr( $id_prefix ) . '-to" class="nri-filter-sel" title="To">';
    $o .= '</span>';
    return $o;
}

function nri_get_meta( $rid ) {
    $status  = get_post_meta( $rid, 'status', true );
    $payst   = get_post_meta( $rid, 'payment_status', true );
    $fd      = get_post_meta( $rid, 'field_data', true );
    return array(
        'request_id'         => (string) get_post_meta( $rid, 'request_id', true ),
        'status'             => $status  ? (string) $status  : 'submitted',
        'payment_status'     => $payst   ? (string) $payst   : 'pending',
        'quote_amount'       => get_post_meta( $rid, 'quote_amount', true ),
        'estimated_delivery' => (string) get_post_meta( $rid, 'estimated_delivery', true ),
        'secondary_status'   => (string) get_post_meta( $rid, 'secondary_status', true ),
        'assigned_manager'   => get_post_meta( $rid, 'assigned_manager', true ),
        'assigned_vendor'    => get_post_meta( $rid, 'assigned_vendor', true ),
        'internal_notes'     => (string) get_post_meta( $rid, 'internal_notes', true ),
        // Staff-only CRM pipeline stage — see nri_get_internal_statuses()
        // below. Defaults to the first stage ("inquiry") when never set,
        // same pattern as 'status' defaulting to 'submitted' above. This
        // is intentionally separate from 'status' (the client-facing
        // request status) and must NEVER be exposed on any client-facing
        // page, email, or notification.
        'internal_status'    => ( $is_val = get_post_meta( $rid, 'internal_status', true ) ) ? (string) $is_val : 'inquiry',
        'field_data'         => is_array( get_post_meta( $rid, 'field_data', true ) ) ? get_post_meta( $rid, 'field_data', true ) : array(),
        'shipping_charges'   => get_post_meta( $rid, 'shipping_charges', true ),
        'shipping_type'      => (string) get_post_meta( $rid, 'shipping_type', true ),
    );
}

function nri_add_history( $rid, $event, $note = '' ) {
    $h   = (array) get_post_meta( $rid, 'history', true );
    $h[] = array( 'event' => sanitize_text_field($event), 'note' => sanitize_textarea_field($note), 'time' => current_time('Y-m-d H:i:s') );
    update_post_meta( $rid, 'history', $h );
}

// TRACE: reads a request's activity log → get_post_meta() returns '' (an empty
//        STRING) when the 'history' meta row doesn't exist yet — true for
//        every brand-new request until its first nri_add_history() write has
//        landed — and (array) '' casts that to [0 => ''], an array whose
//        single element is itself a string, not a history row. Any caller
//        that then does $entry['time'] on that element (every caller does)
//        hits PHP 8's "Cannot access offset of type string on string"
//        TypeError — this is exactly what surfaced as the client-dashboard
//        crash right after a fresh submission. → precondition: none, $rid
//        may be any post ID, with or without a history row → postcondition:
//        ALWAYS an array of arrays, safe for every existing caller to index
//        by ['event']/['note']/['time'] → edge case handled: legacy/corrupt
//        data with a stray non-array entry is filtered out rather than
//        crashing the caller.
function nri_get_history( $rid ) {
    $h = get_post_meta( $rid, 'history', true );
    if ( ! is_array( $h ) ) { return array(); }
    return array_values( array_filter( $h, 'is_array' ) );
}

/**
 * Returns the first non-empty value from $fd (a request's submitted
 * field_data) among a list of candidate field keys, WITHOUT the
 * 'field_' prefix (added here). Form fields are admin-configurable (see
 * the "Fields" tab / wp_nri_fields table), so a logical field like
 * "University Name" might be stored as field_university_name on one
 * install and field_university on another — trying several plausible
 * spellings makes the compact card summary work without hardcoding one
 * exact key per site.
 */
function nri_fd_first( $fd, $keys ) {
    if ( ! is_array( $fd ) ) { return ''; }
    foreach ( $keys as $k ) {
        if ( ! empty( $fd[ 'field_' . $k ] ) && is_scalar( $fd[ 'field_' . $k ] ) ) {
            return (string) $fd[ 'field_' . $k ];
        }
    }
    return '';
}

/**
 * Builds the compact, grouped "at a glance" summary of a request's
 * submitted form data for the admin Requests list — see the
 * "Document/Academic", "Location & Delivery", "Applicant" and
 * "Remarks" groups requested for the admin dashboard's request cards.
 * Returns ready-to-insert, already-escaped HTML (or '' if a group has
 * nothing to show), so the caller (nri_ajax_get_requests, consumed by
 * nriLoadAdminRequests() in shortcodes.php) can drop it straight into
 * a card without re-implementing the field-key guessing or escaping.
 *
 * Only lines with at least one non-empty value are rendered; empty
 * individual fields inside a still-populated line are simply omitted
 * from that line rather than shown as blank.
 */
function nri_render_request_card_fields( $rid, $meta = null ) {
    $meta = $meta ? $meta : nri_get_meta( $rid );
    $fd   = $meta['field_data'];

    // pair(): builds one "Label: value" segment, or '' if the value is
    // empty — callers join non-empty segments with a " | " separator.
    $pair = function( $label, $value ) {
        $value = trim( (string) $value );
        if ( $value === '' ) { return ''; }
        return '<span class="nri-rc-pair"><span class="nri-rc-lbl">' . esc_html( $label ) . ':</span> <span class="nri-rc-val" title="' . esc_attr( $value ) . '">' . esc_html( $value ) . '</span></span>';
    };
    $line = function( $parts ) {
        $parts = array_filter( $parts, function( $p ) { return $p !== ''; } );
        if ( empty( $parts ) ) { return ''; }
        return '<div class="nri-rc-line">' . implode( '<span class="nri-rc-sep">|</span>', $parts ) . '</div>';
    };

    $o = '';

    // 1. Applicant (submitted name/mobile — may differ from the WP
    // account name shown elsewhere, if someone submits on another
    // client's behalf).
    $first = nri_fd_first( $fd, array( 'first_name' ) );
    $last  = nri_fd_first( $fd, array( 'last_name' ) );
    $full_name = trim( $first . ' ' . $last );
    $phone = nri_fd_first( $fd, array( 'phone', 'mobile', 'mobile_number' ) );
    $phone_code = nri_fd_first( $fd, array( 'phone_code' ) );
    $o .= $line( array(
        $pair( 'Applicant', $full_name ),
        $pair( 'Mobile', $phone ? trim( $phone_code . ' ' . $phone ) : '' ),
    ) );

    // 2. Document / Academic details — several lines, grouped the way
    // an admin scans a form: what/how, then where, then when/how-long,
    // then reference numbers and why.
    $doc_type = nri_fd_first( $fd, array( 'document_type' ) );
    $app_type = nri_fd_first( $fd, array( 'application_type' ) );
    $o .= $line( array( $pair( 'Document', $doc_type ), $pair( 'Application', $app_type ) ) );

    $university = nri_fd_first( $fd, array( 'university_name', 'university' ) );
    $college    = nri_fd_first( $fd, array( 'college_name', 'college' ) );
    $o .= $line( array( $pair( 'University', $university ), $pair( 'College', $college ) ) );

    $course = nri_fd_first( $fd, array( 'course_name', 'course' ) );
    $mode   = nri_fd_first( $fd, array( 'mode_of_education', 'mode', 'education_mode' ) );
    $o .= $line( array( $pair( 'Course', $course ), $pair( 'Mode', $mode ) ) );

    $adm_year  = nri_fd_first( $fd, array( 'year_admission', 'year_of_admission', 'admission_year' ) );
    $pass_year = nri_fd_first( $fd, array( 'year_passing', 'year_of_passing', 'passing_year' ) );
    $semesters = nri_fd_first( $fd, array( 'number_of_semesters', 'semesters', 'no_of_semesters' ) );
    $o .= $line( array( $pair( 'Admission', $adm_year ), $pair( 'Passing', $pass_year ), $pair( 'Semesters', $semesters ) ) );

    $enrollment = nri_fd_first( $fd, array( 'enrollment_number', 'enrollment' ) );
    $purpose    = nri_fd_first( $fd, array( 'purpose' ) );
    $o .= $line( array( $pair( 'Enrollment', $enrollment ), $pair( 'Purpose', $purpose ) ) );

    // 3. Location & Delivery — timeline is the admin-SET working-days
    // value (timeline_working_days), not a submitted form field; it's
    // whatever staff configured via the "Set Timeline" action.
    $cur_loc  = nri_fd_first( $fd, array( 'current_location' ) );
    $del_loc  = nri_fd_first( $fd, array( 'delivery_location' ) );
    $wd       = $meta['estimated_delivery'] ? get_post_meta( $rid, 'timeline_working_days', true ) : '';
    $timeline = $wd ? intval( $wd ) . ' Working Days' : '';
    $loc_parts = array();
    if ( $cur_loc !== '' || $del_loc !== '' ) {
        $loc_parts[] = '<span class="nri-rc-pair"><span class="nri-rc-lbl">Current:</span> <span class="nri-rc-val" title="' . esc_attr( $cur_loc ) . '">' . esc_html( $cur_loc ?: '—' ) . '</span> <span class="nri-rc-arrow">&rarr;</span> <span class="nri-rc-lbl">Delivery:</span> <span class="nri-rc-val" title="' . esc_attr( $del_loc ) . '">' . esc_html( $del_loc ?: '—' ) . '</span></span>';
    }
    $loc_parts[] = $pair( 'Timeline', $timeline );
    $o .= $line( $loc_parts );

    // 4. Remarks — only rendered at all when actually provided, per
    // spec; no reserved empty space otherwise.
    $remarks = nri_fd_first( $fd, array( 'remarks', 'additional_remarks', 'notes' ) );
    if ( $remarks !== '' ) {
        $o .= '<div class="nri-rc-line nri-rc-remarks"><span class="nri-rc-lbl">Remarks:</span> <span class="nri-rc-val nri-rc-remarks-val" title="' . esc_attr( $remarks ) . '">' . esc_html( $remarks ) . '</span></div>';
    }

    return $o;
}

/* ============================================================
   STUDENT REQUIREMENT DESCRIPTION — INTERNAL INTELLIGENCE ENGINE
   ------------------------------------------------------------
   Deterministic, server-side, rule-based text generator — no
   external AI API. Turns a request's submitted fields into a
   short (2-4 sentence) natural-language explanation of what the
   student actually needs, the way a human who read the form
   would summarise it to a colleague — not a field-by-field
   concatenation. See nri_generate_requirement_description().
   ============================================================ */

/**
 * Requirement-type knowledge library: maps recognizable phrases inside
 * a request's raw "Document Type" value to how that document should be
 * talked about in a generated description. This is an ordered array —
 * the first (most specific) match wins, so e.g. "duplicate degree" is
 * listed ahead of the plainer "degree" it also contains. Filterable so
 * new document/service types can be added later without editing this
 * file (`add_filter('nri_req_doc_library', ...)`).
 */
function nri_req_doc_library() {
    $lib = array(
        'duplicate degree'         => array( 'noun' => 'duplicate degree certificate' ),
        'duplicate marksheet'      => array( 'noun' => 'duplicate marksheet' ),
        'consolidated marksheet'   => array( 'noun' => 'consolidated marksheet' ),
        'final semester marksheet' => array( 'noun' => 'final semester marksheet' ),
        'final year marksheet'     => array( 'noun' => 'final year marksheet' ),
        'marksheet'                => array( 'noun' => 'marksheet' ),
        'transcript'               => array( 'noun' => 'transcript' ),
        'degree certificate'       => array( 'noun' => 'degree certificate' ),
        'degree'                   => array( 'noun' => 'degree certificate' ),
        'migration certificate'    => array( 'noun' => 'migration certificate' ),
        'migration'                => array( 'noun' => 'migration certificate' ),
        'medium of instruction'    => array( 'noun' => 'Medium of Instruction (MOI) letter' ),
        'moi'                      => array( 'noun' => 'Medium of Instruction (MOI) letter' ),
        'letter of recommendation' => array( 'noun' => 'letter of recommendation' ),
        'recommendation'           => array( 'noun' => 'letter of recommendation' ),
        'syllabus'                 => array( 'noun' => 'syllabus copy' ),
        'duplicate'                => array( 'noun' => 'duplicate copy of his/her document' ),
        'verification'             => array( 'noun' => 'document verification', 'verb' => 'needs help getting his/her documents verified' ),
        'attestation'              => array( 'noun' => 'document attestation',  'verb' => 'needs his/her documents attested' ),
        'apostille'                => array( 'noun' => 'apostille',             'verb' => 'needs an apostille done on his/her documents' ),
    );
    return apply_filters( 'nri_req_doc_library', $lib );
}

/**
 * Matches a raw submitted "Document Type" value against the library
 * above. Falls back to using the raw value itself as the noun so an
 * unrecognised/custom document type still produces a sensible sentence
 * instead of being silently dropped.
 */
function nri_req_match_doc( $doc_type ) {
    $doc_type_l = strtolower( trim( (string) $doc_type ) );
    if ( $doc_type_l === '' ) { return null; }
    foreach ( nri_req_doc_library() as $needle => $rule ) {
        if ( strpos( $doc_type_l, $needle ) !== false ) { return $rule; }
    }
    return array( 'noun' => $doc_type_l );
}

/**
 * Turns a raw submitted "Purpose" value into a natural phrase for use
 * after "for" ("...for {phrase}"). Falls back to the raw value so an
 * unrecognised purpose still reads naturally instead of vanishing.
 */
function nri_req_purpose_phrase( $purpose ) {
    $p = strtolower( trim( (string) $purpose ) );
    if ( $p === '' ) { return ''; }
    $map = array(
        'higher stud' => 'a higher-studies application abroad',
        'further stud' => 'a higher-studies application',
        'immigrat'    => 'his/her immigration process',
        'employ'      => 'an employment requirement',
        'job'         => 'a job application',
        'visa'        => 'his/her visa processing',
        'admission'   => 'a university admission',
        'scholarship' => 'a scholarship application',
        'residen'     => 'his/her residency application',
        'pr application' => 'his/her PR application',
    );
    foreach ( $map as $needle => $phrase ) {
        if ( strpos( $p, $needle ) !== false ) {
            return apply_filters( 'nri_req_purpose_phrase', $phrase, $purpose );
        }
    }
    return apply_filters( 'nri_req_purpose_phrase', trim( (string) $purpose ), $purpose );
}

/**
 * The engine itself. Reads a request's submitted fields (via
 * nri_fd_first(), so admin-configurable field-key spellings are
 * handled the same way the compact card summary handles them),
 * interprets the RELATIONSHIP between them (document type + course +
 * institution + completion year + mode; current vs delivery location;
 * timeline; purpose; urgency signalled in remarks) and composes a
 * short 2-4 sentence narrative — never a field-by-field list. Any
 * field that is missing is simply omitted from the sentence rather
 * than producing an awkward gap ("... passed in [Year] ...").
 *
 * Returns plain text (no HTML) — callers that display it decide how
 * to escape/format it.
 */
function nri_generate_requirement_description( $rid, $meta = null ) {
    $meta = $meta ? $meta : nri_get_meta( $rid );
    $fd   = $meta['field_data'];

    $first = nri_fd_first( $fd, array( 'first_name' ) );
    $last  = nri_fd_first( $fd, array( 'last_name' ) );
    $name  = trim( $first . ' ' . $last );
    if ( $name === '' ) { $name = 'The applicant'; }

    $doc_type_raw = nri_fd_first( $fd, array( 'document_type' ) );
    $app_type     = nri_fd_first( $fd, array( 'application_type' ) );
    $university   = nri_fd_first( $fd, array( 'university_name', 'university' ) );
    $college      = nri_fd_first( $fd, array( 'college_name', 'college' ) );
    $course       = nri_fd_first( $fd, array( 'course_name', 'course' ) );
    $mode         = nri_fd_first( $fd, array( 'mode_of_education', 'mode', 'education_mode' ) );
    $adm_year     = nri_fd_first( $fd, array( 'year_admission', 'year_of_admission', 'admission_year' ) );
    $pass_year    = nri_fd_first( $fd, array( 'year_passing', 'year_of_passing', 'passing_year' ) );
    $semesters    = nri_fd_first( $fd, array( 'number_of_semesters', 'semesters', 'no_of_semesters' ) );
    $enrollment   = nri_fd_first( $fd, array( 'enrollment_number', 'enrollment' ) );
    $purpose_raw  = nri_fd_first( $fd, array( 'purpose' ) );
    $cur_loc      = nri_fd_first( $fd, array( 'current_location' ) );
    $del_loc      = nri_fd_first( $fd, array( 'delivery_location' ) );
    $remarks      = nri_fd_first( $fd, array( 'remarks', 'additional_remarks', 'notes' ) );
    $wd           = get_post_meta( $rid, 'timeline_working_days', true );
    $timeline     = $wd ? intval( $wd ) . ' working days' : '';

    // Institution: mention both university and college when both are
    // given and differ; otherwise whichever one is actually present.
    $institution = '';
    if ( $university !== '' && $college !== '' && strcasecmp( $university, $college ) !== 0 ) {
        $institution = $university . ', ' . $college;
    } elseif ( $university !== '' ) {
        $institution = $university;
    } else {
        $institution = $college;
    }

    $doc_rule   = nri_req_match_doc( $doc_type_raw );
    $need_noun  = $doc_rule ? $doc_rule['noun'] : 'document';
    $has_verb   = $doc_rule && isset( $doc_rule['verb'] );

    // A placeholder remark value ("None", "N/A", "-", ...) means the
    // client left this blank in effect — treat it the same as an empty
    // remark rather than quoting it back as if it were real content.
    $remarks_placeholder = array( 'none', 'na', 'n/a', 'nil', 'nothing', 'no', '-', '--', 'no remarks', 'no remark' );
    if ( $remarks !== '' && in_array( strtolower( trim( $remarks, " \t\n\r\0\x0B." ) ), $remarks_placeholder, true ) ) {
        $remarks = '';
    }
    $remarks_l = strtolower( $remarks );
    $is_urgent = ( $remarks !== '' && ( strpos( $remarks_l, 'urgent' ) !== false || strpos( $remarks_l, 'asap' ) !== false || strpos( $remarks_l, 'immediately' ) !== false ) );

    // The description reads as short PARAGRAPHS (joined with a blank
    // line), not one dense block — one paragraph for what's needed, one
    // for the academic timeline/enrollment, one for location/delivery/
    // purpose, and an optional one for anything else in the remarks.
    // No gender field exists on the form, so pronouns are written as
    // "he/she" / "his/her" throughout rather than guessed at.

    // ---- Paragraph 1: what is needed, for what course, from where ----
    if ( $has_verb ) {
        // Service-style requests (verification / attestation / apostille)
        // read more naturally as "needs X done" than "needs a X".
        $p1 = $name . ' ' . $doc_rule['verb'];
    } else {
        $article = preg_match( '/^[aeiou]/i', $need_noun ) ? 'an' : 'a';
        $modifier    = '';
        $tail        = ''; // appended right after the document phrase
        $app_type_l  = strtolower( $app_type );
        $app_matched = false;
        if ( $app_type !== '' ) {
            // If the document noun already implies what the Application
            // Type says (e.g. noun "duplicate degree certificate" + type
            // "Duplicate"), it's already covered — don't also append a
            // redundant "(Duplicate application)" parenthetical below.
            foreach ( array( 'duplicate', 'fresh', 'revalidat' ) as $core ) {
                if ( strpos( $app_type_l, $core ) !== false && stripos( $need_noun, $core ) !== false ) {
                    $app_matched = true;
                    break;
                }
            }
            if ( ! $app_matched && stripos( $need_noun, 'duplicate' ) === false ) {
                if ( strpos( $app_type_l, 'duplicate' ) !== false )     { $modifier = 'a duplicate'; $app_matched = true; }
                elseif ( strpos( $app_type_l, 'fresh' ) !== false )      { $tail = ' for the first time'; $app_matched = true; }
                elseif ( strpos( $app_type_l, 'revalidat' ) !== false )  { $modifier = 'a revalidation of his/her'; $app_matched = true; }
            }
        }
        $need_phrase = trim( ( $modifier !== '' ? $modifier : $article ) . ' ' . $need_noun ) . $tail;
        // Application Type is a submitted field in its own right — if it
        // didn't match one of the known modifiers above (fresh/duplicate/
        // revalidation), still surface it rather than silently dropping
        // it, e.g. "a marksheet (Renewal application)".
        if ( $app_type !== '' && ! $app_matched ) {
            $need_phrase .= ' (' . $app_type . ' application)';
        }
        $p1 = $name . ' needs ' . $need_phrase;
    }
    if ( $course !== '' ) {
        $p1 .= ' for his/her ' . $course . ' course';
    }
    if ( $institution !== '' ) {
        $p1 .= ' from ' . $institution;
    }
    $p1 = rtrim( $p1 ) . '.';

    // ---- Paragraph 2: academic timeline (admission/passing/mode/
    // semesters) and enrollment number — kept separate from paragraph 1
    // so neither reads as one overloaded sentence. ----
    $p2 = '';
    $progress = '';
    if ( $adm_year !== '' && $pass_year !== '' ) {
        $progress = 'He/she started the course in ' . $adm_year . ' and completed it in ' . $pass_year;
    } elseif ( $pass_year !== '' ) {
        $progress = 'He/she completed the course in ' . $pass_year;
    } elseif ( $adm_year !== '' ) {
        $progress = 'He/she started the course in ' . $adm_year . ' and is currently pursuing it';
    } elseif ( $mode !== '' ) {
        $progress = 'He/she pursued the course';
    }
    if ( $progress !== '' && $mode !== '' ) {
        $progress .= ' through the ' . $mode . ' mode';
    }
    if ( $progress !== '' && $semesters !== '' ) {
        $progress .= ', covering ' . $semesters . ' semester' . ( intval( $semesters ) === 1 ? '' : 's' );
    }
    if ( $progress !== '' ) { $p2 .= rtrim( $progress ) . '.'; }
    if ( $enrollment !== '' ) {
        $p2 .= ( $p2 !== '' ? ' ' : '' ) . 'His/Her Enrollment Number is ' . $enrollment . '.';
    }

    // ---- Paragraph 3: current location, purpose, and where the
    // finished document needs to go — with timeline/urgency folded in. ----
    $purpose_phrase = nri_req_purpose_phrase( $purpose_raw );
    $p3a = '';
    if ( $cur_loc !== '' && $purpose_phrase !== '' ) {
        $p3a = 'He/she is currently based in ' . $cur_loc . ', and needs the ' . ( $has_verb ? 'work done' : $need_noun ) . ' for ' . $purpose_phrase;
    } elseif ( $cur_loc !== '' ) {
        $p3a = 'He/she is currently based in ' . $cur_loc;
    } elseif ( $purpose_phrase !== '' ) {
        $p3a = 'He/she needs the ' . ( $has_verb ? 'work done' : $need_noun ) . ' for ' . $purpose_phrase;
    }
    if ( $p3a !== '' ) { $p3a = rtrim( $p3a ) . '.'; }

    $p3b = '';
    if ( $del_loc !== '' ) {
        $p3b = 'The completed document needs to be sent to ' . $del_loc;
        if ( $timeline !== '' ) { $p3b .= ', within about ' . $timeline; }
        $p3b = rtrim( $p3b ) . '.';
    } elseif ( $timeline !== '' ) {
        $p3b = 'It is needed within about ' . $timeline . '.';
    }

    if ( $is_urgent ) {
        if ( $p3b !== '' )      { $p3b = rtrim( $p3b, '.' ) . ', so the requirement is urgent.'; }
        elseif ( $p3a !== '' )  { $p3a = rtrim( $p3a, '.' ) . ', so the requirement is urgent.'; }
        else                    { $p3a = 'The requirement is urgent.'; }
    }
    $p3 = trim( $p3a . ( $p3a !== '' && $p3b !== '' ? ' ' : '' ) . $p3b );

    // ---- Paragraph 4: anything else noted, when it isn't just the
    // urgency flag already folded into paragraph 3 above. ----
    $p4 = '';
    if ( $remarks !== '' && ! ( $is_urgent && trim( preg_replace( '/\burgent(ly)?\b|\basap\b|\bimmediately\b/i', '', $remarks ) ) === '' ) ) {
        $trimmed = $remarks;
        $len     = function_exists( 'mb_strlen' ) ? mb_strlen( $trimmed ) : strlen( $trimmed );
        if ( $len > 160 ) {
            $trimmed = function_exists( 'mb_substr' ) ? mb_substr( $trimmed, 0, 157 ) . '...' : substr( $trimmed, 0, 157 ) . '...';
        }
        $p4 = 'He/she also noted: ' . rtrim( $trimmed, '.' ) . '.';
    }

    $sentences = array_values( array_filter( array( $p1, $p2, $p3, $p4 ), function( $s ) { return trim( (string) $s ) !== ''; } ) );

    if ( empty( $sentences ) ) {
        // Practically empty submission — never return a blank description.
        return trim( $name . ' has submitted a request' . ( $doc_type_raw !== '' ? ' for ' . $doc_type_raw . '.' : '.' ) );
    }

    // Single newline between paragraphs, not a blank line — a blank line
    // (the previous "\n\n" join) rendered as a double <br><br> gap on the
    // detail page (nl2br() keeps the original \n as well as adding <br>
    // before it) and as a genuinely blank line when the plain text was
    // pasted via Copy Description into WhatsApp/email. A single "\n" still
    // starts each paragraph on its own line either way, just without the
    // extra gap.
    return apply_filters( 'nri_requirement_description', implode( "\n", $sentences ), $rid, $fd );
}

/**
 * Hash of exactly the fields the engine above reads. Lets the UI tell
 * whether a request's underlying data has drifted since its
 * description (generated or hand-written) was last saved, WITHOUT ever
 * silently regenerating/overwriting anything on its own — see
 * nri_get_requirement_description()'s 'stale' flag.
 */
function nri_requirement_fields_hash( $rid, $meta = null ) {
    $meta = $meta ? $meta : nri_get_meta( $rid );
    $fd   = $meta['field_data'];
    $keys = array(
        'first_name', 'last_name', 'phone', 'mobile', 'mobile_number', 'phone_code',
        'document_type', 'application_type', 'university_name', 'university',
        'college_name', 'college', 'course_name', 'course', 'mode_of_education', 'mode',
        'education_mode', 'year_admission', 'year_of_admission', 'admission_year',
        'year_passing', 'year_of_passing', 'passing_year', 'number_of_semesters',
        'semesters', 'no_of_semesters', 'enrollment_number', 'enrollment', 'purpose',
        'current_location', 'delivery_location', 'remarks', 'additional_remarks', 'notes',
    );
    $snapshot = array();
    foreach ( $keys as $k ) {
        $snapshot[ $k ] = isset( $fd[ 'field_' . $k ] ) ? $fd[ 'field_' . $k ] : '';
    }
    $snapshot['timeline_working_days'] = get_post_meta( $rid, 'timeline_working_days', true );
    return md5( maybe_serialize( $snapshot ) );
}

/**
 * Persists a Student Requirement Description — used both by the
 * "generate on creation" step and by the admin regenerate/save actions.
 * $is_manual distinguishes an admin's own wording from an
 * engine-generated one (surfaced in the UI as a badge).
 */
function nri_save_requirement_description( $rid, $text, $is_manual = false ) {
    update_post_meta( $rid, 'requirement_description', sanitize_textarea_field( $text ) );
    update_post_meta( $rid, 'requirement_description_manual', $is_manual ? '1' : '' );
    update_post_meta( $rid, 'requirement_description_hash', nri_requirement_fields_hash( $rid ) );
    update_post_meta( $rid, 'requirement_description_updated', current_time( 'mysql' ) );
}

/**
 * Reads the Student Requirement Description.
 *
 * An admin's own manually-written wording is always honoured as-is —
 * only the 'stale' flag below tells the UI its source fields have since
 * changed; it is never regenerated or overwritten on its own.
 *
 * An AUTO-GENERATED description, however, is always recomputed live
 * from the request's current fields on every read (and the stored copy
 * quietly kept in sync) rather than trusting whatever text happened to
 * be saved earlier. This matters in practice: it's how an engine fix or
 * improvement (wording, pronouns, a previously-dropped field) shows up
 * immediately on existing requests without an admin having to click
 * "Regenerate" on each one — there is nothing an admin authored here to
 * protect, so there's nothing to go stale.
 *
 * Returns ['text'=>..., 'is_manual'=>bool, 'stale'=>bool] — 'stale' is
 * only ever true for a manual description whose source fields have
 * drifted since it was written (surfaced as a hint only; never
 * auto-applied).
 */
function nri_get_requirement_description( $rid, $meta = null ) {
    $meta      = $meta ? $meta : nri_get_meta( $rid );
    $is_manual = get_post_meta( $rid, 'requirement_description_manual', true ) === '1';

    if ( $is_manual ) {
        $text = get_post_meta( $rid, 'requirement_description', true );
        if ( $text === '' || $text === false ) {
            // Shouldn't normally happen (a manual flag with no text),
            // but never show a blank description.
            $text = nri_generate_requirement_description( $rid, $meta );
            nri_save_requirement_description( $rid, $text, false );
            $is_manual = false;
        }
    } else {
        // Computed live on every read — see the doc comment above for
        // why this deliberately does NOT persist on every call (that
        // would mean a DB write on every list/card load); the version
        // saved at creation time (nri_ajax_create_request) and by
        // nri_ajax_regenerate_description is only ever a point-in-time
        // record, not the source of truth for an auto description.
        $text = nri_generate_requirement_description( $rid, $meta );
    }

    // 'stale' only has meaning for a manual description (does the
    // admin's own wording still match the current fields?) — an auto
    // description is always freshly computed above, so it can never be
    // stale relative to itself.
    $stale = false;
    if ( $is_manual ) {
        $saved_hash   = get_post_meta( $rid, 'requirement_description_hash', true );
        $current_hash = nri_requirement_fields_hash( $rid, $meta );
        $stale        = ( $saved_hash !== '' && $saved_hash !== $current_hash );
    }
    return array(
        'text'      => $text,
        'is_manual' => $is_manual,
        'stale'     => $stale,
    );
}

function nri_get_documents( $rid ) {
    $d = get_post_meta( $rid, 'documents', true );
    return is_array( $d ) ? $d : array();
}

function nri_status_label( $s ) {
    // 'ready_for_processing' was missing here even though it's a real,
    // already-live client-facing status: it's offered in the staff
    // "Update Status" panel (nri_render_staff_panel() in shortcodes.php)
    // and has its own client notification email template
    // (notifications.php) — this function just fell back to a generic
    // ucwords() for it instead of a proper label, which is how it went
    // unnoticed rather than one card dropdown simply omitting it.
    $m = array( 'submitted'=>'Received','under_review'=>'Under Review','ready_for_processing'=>'Ready for Processing','approved'=>'Approved','processing'=>'Processing','dispatched'=>'Dispatched','completed'=>'Completed','rejected'=>'Cancelled','service_not_available'=>'Service Not Available' );
    return isset($m[$s]) ? $m[$s] : ucwords( str_replace('_',' ',$s) );
}

function nri_status_color( $s ) {
    $m = array( 'submitted'=>'#00b4d8','under_review'=>'#f59e0b','ready_for_processing'=>'#0ea5e9','approved'=>'#3b82f6','processing'=>'#8b5cf6','dispatched'=>'#f97316','completed'=>'#10b981','rejected'=>'#ef4444','service_not_available'=>'#6b7280' );
    return isset($m[$s]) ? $m[$s] : '#6b7280';
}

// ─────────────────────────────────────────────────────────────────────────
// INTERNAL STATUS (CRM pipeline) — staff-only, never client-facing.
//
// Lives in its own table (wp_nri_internal_statuses), fully separate from
// the client-facing 'status' meta/nri_status_label()/nri_status_color()
// above: that pair is the small fixed enum clients see on their dashboard;
// this pipeline is an admin-configurable, reorderable, activate/
// deactivate-able list of internal workflow stages that a client must
// never see. Nothing in this section is ever called from a client-facing
// template, email, or notification — grep for "internal_status" before
// adding a new call site to make sure that stays true.
// ─────────────────────────────────────────────────────────────────────────

// Deterministic slug from a label: lower-cased, underscored, ASCII-only
// (matches the snake_case style every other meta/option key in this
// plugin already uses, e.g. 'service_not_available'). sanitize_title()
// handles the transliteration/strip-punctuation work; the '-' → '_' swap
// is just house style.
function nri_generate_internal_status_slug( $label ) {
    $slug = str_replace( '-', '_', sanitize_title( $label ) );
    return $slug !== '' ? $slug : 'status_' . substr( md5( $label . microtime() ), 0, 8 );
}

// Every internal status row, ordered for display. Cached for the
// lifetime of the request (a single page load can ask for this many
// times — once for the filter bar, once per card badge, etc.) — a
// process-level static, not a persistent cache, so it can never go stale
// across requests. Any create/edit/reorder/activate/delete call in
// ajax.php calls nri_clear_internal_status_cache() immediately after
// writing, so a subsequent call within the SAME request (e.g. the
// management screen re-rendering its own list right after a save) also
// sees the fresh data instead of this request's first, now-stale read.
function nri_get_internal_statuses( $active_only = false, $force_refresh = false ) {
    static $all = null;
    if ( $all === null || $force_refresh ) {
        global $wpdb;
        $all = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}nri_internal_statuses ORDER BY sort_order ASC, id ASC" );
        if ( ! is_array( $all ) ) { $all = array(); }
    }
    if ( ! $active_only ) { return $all; }
    return array_values( array_filter( $all, function( $r ) { return (int) $r->is_active === 1; } ) );
}

function nri_clear_internal_status_cache() {
    nri_get_internal_statuses( false, true );
}

// slug => row map, for O(1) label/color lookups.
function nri_get_internal_status_map( $active_only = false ) {
    $map = array();
    foreach ( nri_get_internal_statuses( $active_only ) as $r ) { $map[ $r->slug ] = $r; }
    return $map;
}

function nri_internal_status_label( $slug ) {
    $map = nri_get_internal_status_map( false );
    if ( isset( $map[ $slug ] ) ) { return $map[ $slug ]->label; }
    return $slug ? ucwords( str_replace( '_', ' ', $slug ) ) : 'Inquiry';
}

function nri_internal_status_color( $slug ) {
    $map = nri_get_internal_status_map( false );
    if ( isset( $map[ $slug ] ) ) { return $map[ $slug ]->color ? $map[ $slug ]->color : '#6b7280'; }
    return '#6b7280';
}

// Builds the meta_query clause(s) for filtering WP_Query/get_posts by
// internal status. Needs special handling for the pipeline's first stage
// ("inquiry"): a request that has NEVER had an internal status set has no
// 'internal_status' postmeta row at all yet (see nri_get_meta()'s
// default-to-'inquiry' above), so filtering by "Inquiry" must match BOTH
// requests explicitly set to it AND requests where the meta key is simply
// missing or empty — otherwise every never-touched request would be
// invisible under its own correct filter.
function nri_internal_status_meta_query( $slug ) {
    $slug = sanitize_key( $slug );
    if ( $slug === '' ) { return null; }
    if ( $slug === 'inquiry' ) {
        return array(
            'relation' => 'OR',
            array( 'key' => 'internal_status', 'value' => 'inquiry', 'compare' => '=' ),
            array( 'key' => 'internal_status', 'value' => '',        'compare' => '=' ),
            array( 'key' => 'internal_status', 'compare' => 'NOT EXISTS' ),
        );
    }
    return array( array( 'key' => 'internal_status', 'value' => $slug, 'compare' => '=' ) );
}

// Grouped counts (slug => count of requests currently in that stage),
// respecting the same client-status + date filters already applied to
// the list itself, so the pill numbers always match what filtering by
// them would actually show. Deliberately does NOT factor in the free-text
// search box — re-scanning every request's full submitted-field haystack
// (see nri_request_search_haystack()) on every keystroke just to update
// pill counts would be real, avoidable per-keystroke DB work for a number
// that's mostly a rough orientation aid; the filter itself still works
// correctly together with a search term (see nri_ajax_get_requests()),
// only the displayed COUNT stays scoped to status+date.
function nri_get_internal_status_counts( $client_status = '', $date_after = null, $date_before = null ) {
    global $wpdb;
    $where  = array( "p.post_type = 'nri_request'", "p.post_status = 'publish'" );
    $params = array();
    if ( $client_status ) {
        $where[]  = "EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm2 WHERE pm2.post_id = p.ID AND pm2.meta_key = 'status' AND pm2.meta_value = %s)";
        $params[] = $client_status;
    }
    if ( $date_after )  { $where[] = 'p.post_date >= %s'; $params[] = $date_after; }
    if ( $date_before ) { $where[] = 'p.post_date <= %s'; $params[] = $date_before; }
    $sql = "SELECT COALESCE(NULLIF(pm.meta_value, ''), 'inquiry') AS ist, COUNT(*) AS cnt
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = 'internal_status'
            WHERE " . implode( ' AND ', $where ) . '
            GROUP BY ist';
    $sql  = $params ? $wpdb->prepare( $sql, $params ) : $sql;
    $rows = $wpdb->get_results( $sql );
    $out  = array();
    foreach ( (array) $rows as $r ) { $out[ $r->ist ] = (int) $r->cnt; }
    return $out;
}
