<?php
/**
 * Smart Delivery Date Calculation
 * Considers working days, weekends, and holidays
 * Version: 6.2.1
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Calculate delivery date from working days
 * 
 * @param int $working_days Number of working days
 * @param string $start_date Start date (optional, defaults to today)
 * @param int $university_id University ID for custom holidays (optional)
 * @return array|WP_Error Array with date info or error
 */
function nri_calculate_delivery_date( $working_days, $start_date = null, $university_id = null ) {
    // Validate input
    if ( ! is_numeric( $working_days ) || $working_days < 1 ) {
        return new WP_Error( 'invalid_days', 'Working days must be >= 1' );
    }
    
    // Convert start_date to DateTime
    if ( $start_date === null ) {
        $date = new DateTime( 'now', new DateTimeZone( 'Asia/Kolkata' ) );
    } else {
        try {
            $date = new DateTime( $start_date, new DateTimeZone( 'Asia/Kolkata' ) );
        } catch ( Exception $e ) {
            return new WP_Error( 'invalid_date', 'Invalid start date format' );
        }
    }
    
    // Start counting from next day
    $date->add( new DateInterval( 'P1D' ) );
    
    $counted_days = 0;
    $max_iterations = 365 * 2; // Safety limit (2 years)
    $iterations = 0;
    $skipped_weekends = 0;
    $skipped_holidays = 0;
    
    while ( $counted_days < $working_days && $iterations < $max_iterations ) {
        $iterations++;
        
        // Check if weekend (Saturday = 6, Sunday = 0)
        $day_of_week = (int) $date->format( 'w' );
        if ( $day_of_week === 0 || $day_of_week === 6 ) {
            $date->add( new DateInterval( 'P1D' ) );
            $skipped_weekends++;
            continue;
        }
        
        // Check if holiday
        if ( nri_is_holiday( $date, $university_id ) ) {
            $date->add( new DateInterval( 'P1D' ) );
            $skipped_holidays++;
            continue;
        }
        
        // This is a working day
        $counted_days++;
        
        if ( $counted_days < $working_days ) {
            $date->add( new DateInterval( 'P1D' ) );
        }
    }
    
    if ( $iterations >= $max_iterations ) {
        return new WP_Error( 'calculation_error', 'Unable to calculate delivery date (too many iterations)' );
    }
    
    return array(
        'delivery_date' => $date->format( 'Y-m-d' ),
        'delivery_date_formatted' => $date->format( 'F j, Y' ),
        'working_days' => $working_days,
        'total_calendar_days' => $iterations,
        'weekends_excluded' => $skipped_weekends,
        'holidays_excluded' => $skipped_holidays,
        'day_of_week' => $date->format( 'l' )
    );
}

/**
 * Check if a date is a holiday
 * 
 * @param DateTime $date The date to check
 * @param int $university_id University ID (optional)
 * @return bool True if holiday, false otherwise
 */
function nri_is_holiday( $date, $university_id = null ) {
    global $wpdb;
    
    $date_str = $date->format( 'Y-m-d' );
    $table = $wpdb->prefix . 'nri_holidays';
    
    // Check if holidays table exists
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
        return false;
    }
    
    // Check national and state holidays
    $result = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM $table 
             WHERE date = %s 
             AND (holiday_type = 'national' OR holiday_type = 'state')
             LIMIT 1",
            $date_str
        )
    );
    
    if ( $result ) {
        return true;
    }
    
    // Check university-specific holidays if provided
    if ( $university_id ) {
        $result = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM $table 
                 WHERE date = %s 
                 AND university_id = %d
                 LIMIT 1",
                $date_str,
                $university_id
            )
        );
        
        if ( $result ) {
            return true;
        }
    }
    
    return false;
}

/**
 * Add holiday to database
 * 
 * @param string $date Date in Y-m-d format
 * @param string $name Holiday name
 * @param string $type Holiday type (national, state, university)
 * @param int $university_id University ID (for university-specific holidays)
 * @param string $state_code State code (for state holidays)
 * @return bool|WP_Error True on success, error on failure
 */
function nri_add_holiday( $date, $name, $type = 'national', $university_id = null, $state_code = null ) {
    // Permission check
    if ( ! current_user_can( 'manage_options' ) ) {
        return new WP_Error( 'permission', 'Permission denied' );
    }
    
    // Validate date
    $date_obj = DateTime::createFromFormat( 'Y-m-d', $date );
    if ( ! $date_obj || $date_obj->format( 'Y-m-d' ) !== $date ) {
        return new WP_Error( 'invalid_date', 'Invalid date format. Use Y-m-d (e.g., 2026-01-26)' );
    }
    
    // Validate type
    $valid_types = array( 'national', 'state', 'university' );
    if ( ! in_array( $type, $valid_types ) ) {
        return new WP_Error( 'invalid_type', 'Invalid holiday type. Use: national, state, or university' );
    }
    
    global $wpdb;
    $table = $wpdb->prefix . 'nri_holidays';
    
    $result = $wpdb->insert(
        $table,
        array(
            'date' => $date,
            'holiday_name' => sanitize_text_field( $name ),
            'holiday_type' => $type,
            'university_id' => $university_id ? intval( $university_id ) : null,
            'state_code' => $state_code ? sanitize_text_field( $state_code ) : null
        ),
        array( '%s', '%s', '%s', '%d', '%s' )
    );
    
    if ( ! $result ) {
        return new WP_Error( 'db_error', 'Failed to save holiday: ' . $wpdb->last_error );
    }
    
    nri_log( "Holiday added: $name on $date" );
    return true;
}

/**
 * Delete holiday from database
 */
function nri_delete_holiday( $id ) {
    if ( ! current_user_can( 'manage_options' ) ) {
        return new WP_Error( 'permission', 'Permission denied' );
    }
    
    global $wpdb;
    $table = $wpdb->prefix . 'nri_holidays';
    
    $result = $wpdb->delete(
        $table,
        array( 'id' => intval( $id ) ),
        array( '%d' )
    );
    
    if ( $result === false ) {
        return new WP_Error( 'db_error', 'Failed to delete holiday' );
    }
    
    nri_log( "Holiday deleted: ID $id" );
    return true;
}

/**
 * Get all holidays for a date range
 */
function nri_get_holidays( $start_date = null, $end_date = null, $type = null ) {
    global $wpdb;
    $table = $wpdb->prefix . 'nri_holidays';
    
    $where = array( '1=1' );
    $values = array();
    
    if ( $start_date ) {
        $where[] = 'date >= %s';
        $values[] = $start_date;
    }
    
    if ( $end_date ) {
        $where[] = 'date <= %s';
        $values[] = $end_date;
    }
    
    if ( $type ) {
        $where[] = 'holiday_type = %s';
        $values[] = $type;
    }
    
    $query = "SELECT * FROM $table WHERE " . implode( ' AND ', $where ) . " ORDER BY date ASC";
    
    if ( ! empty( $values ) ) {
        $query = $wpdb->prepare( $query, $values );
    }
    
    return $wpdb->get_results( $query );
}

/**
 * Format delivery date message for display
 */
function nri_format_delivery_message( $calculation ) {
    if ( is_wp_error( $calculation ) ) {
        return 'Unable to calculate delivery date: ' . $calculation->get_error_message();
    }
    
    $message = sprintf(
        '<strong>%s Working Days</strong><br>',
        $calculation['working_days']
    );
    
    $message .= sprintf(
        '<span style="color: #666; font-size: 13px;">Expected Delivery: <strong>%s</strong></span><br>',
        $calculation['delivery_date_formatted']
    );
    
    $message .= '<span style="color: #999; font-size: 12px;">';
    $message .= 'Calculated based on working days; excludes weekends ';
    
    if ( $calculation['holidays_excluded'] > 0 ) {
        $message .= sprintf( 'and %d holiday(s)', $calculation['holidays_excluded'] );
    }
    
    $message .= '</span>';
    
    return $message;
}

// AJAX endpoint to calculate delivery date
add_action( 'wp_ajax_nri_calculate_delivery', 'nri_ajax_calculate_delivery' );
function nri_ajax_calculate_delivery() {
    // Support both GET (test calculator button) and POST
    $nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( $_REQUEST['nonce'] ) : '';
    if ( ! wp_verify_nonce( $nonce, 'nri_admin_nonce' ) && ! wp_verify_nonce( $nonce, 'nri_frontend_nonce' ) ) {
        wp_send_json_error( 'Security check failed.' );
    }

    if ( ! current_user_can( 'manage_options' ) && ! nri_is_staff() ) {
        wp_send_json_error( 'Permission denied' );
    }

    // Accept 'days' (from test calculator UI) or 'working_days' (from API calls)
    $working_days  = isset( $_REQUEST['days'] )         ? intval( $_REQUEST['days'] )         : 0;
    if ( ! $working_days ) {
        $working_days = isset( $_REQUEST['working_days'] ) ? intval( $_REQUEST['working_days'] ) : 0;
    }
    $start_date    = isset( $_REQUEST['start_date'] )   ? sanitize_text_field( $_REQUEST['start_date'] ) : null;
    $university_id = isset( $_REQUEST['university_id'] ) ? intval( $_REQUEST['university_id'] ) : null;

    if ( ! $working_days ) {
        wp_send_json_error( 'Working days required' );
    }

    $result = nri_calculate_delivery_date( $working_days, $start_date, $university_id );

    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }

    wp_send_json_success( $result );
}

// AJAX endpoint to add holiday
add_action( 'wp_ajax_nri_add_holiday', 'nri_ajax_add_holiday' );
function nri_ajax_add_holiday() {
    nri_check_nonce();
    nri_require_staff();
    
    $date = isset( $_POST['holiday_date'] ) ? sanitize_text_field( $_POST['holiday_date'] )
          : ( isset( $_POST['date'] ) ? sanitize_text_field( $_POST['date'] ) : '' );
    $name = isset( $_POST['holiday_name'] ) ? sanitize_text_field( $_POST['holiday_name'] )
          : ( isset( $_POST['name'] ) ? sanitize_text_field( $_POST['name'] ) : '' );
    $type = isset( $_POST['holiday_type'] ) ? sanitize_text_field( $_POST['holiday_type'] )
          : ( isset( $_POST['type'] ) ? sanitize_text_field( $_POST['type'] ) : 'national' );
    $university_id = isset( $_POST['university_id'] ) ? intval( $_POST['university_id'] ) : null;
    $state_code = isset( $_POST['state_code'] ) ? sanitize_text_field( $_POST['state_code'] ) : null;
    
    $result = nri_add_holiday( $date, $name, $type, $university_id, $state_code );
    
    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }
    
    wp_send_json_success( 'Holiday added successfully' );
}

// AJAX endpoint to delete holiday
add_action( 'wp_ajax_nri_delete_holiday', 'nri_ajax_delete_holiday' );
function nri_ajax_delete_holiday() {
    nri_check_nonce();
    nri_require_staff();
    
    $id = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;
    
    $result = nri_delete_holiday( $id );
    
    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }
    
    wp_send_json_success( 'Holiday deleted successfully' );
}

// AJAX endpoint to get holidays
add_action( 'wp_ajax_nri_get_holidays', 'nri_ajax_get_holidays' );
function nri_ajax_get_holidays() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permission denied' );
    }
    
    $start_date = isset( $_GET['start_date'] ) ? sanitize_text_field( $_GET['start_date'] ) : null;
    $end_date = isset( $_GET['end_date'] ) ? sanitize_text_field( $_GET['end_date'] ) : null;
    $type = isset( $_GET['type'] ) ? sanitize_text_field( $_GET['type'] ) : null;
    
    $holidays = nri_get_holidays( $start_date, $end_date, $type );
    
    wp_send_json_success( $holidays );
}

nri_log( 'Delivery calculator module loaded' );
