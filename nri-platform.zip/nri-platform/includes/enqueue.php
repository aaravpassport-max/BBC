<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action('wp_enqueue_scripts','nri_enqueue');
add_action('admin_enqueue_scripts','nri_enqueue');
function nri_enqueue() {
    // Use filemtime as version for hard cache busting on every file edit
    $css_ver = file_exists( NRI_DIR . 'assets/css/nri-style.css' ) ? filemtime( NRI_DIR . 'assets/css/nri-style.css' ) : NRI_VER;
    $js_ver  = file_exists( NRI_DIR . 'assets/js/nri-app.js' )   ? filemtime( NRI_DIR . 'assets/js/nri-app.js' )   : NRI_VER;
    wp_enqueue_style('nri-style',NRI_URL.'assets/css/nri-style.css',array(),$css_ver);
    wp_enqueue_script('sortablejs','https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js',array(),null,true);
    wp_enqueue_script('nri-app',NRI_URL.'assets/js/nri-app.js',array('jquery','sortablejs'),$js_ver,true);
    wp_localize_script('nri-app','NRI',array(
        'ajax_url'     =>admin_url('admin-ajax.php'),
        'nonce'        =>wp_create_nonce('nri_frontend_nonce'),
        'admin_nonce'  =>wp_create_nonce('nri_admin_nonce'),
        'upload_nonce' =>wp_create_nonce('nri_upload_nonce'),
        'home_url'     =>home_url(),
        'is_logged_in' =>is_user_logged_in()?1:0,
        'is_staff'     =>nri_is_staff()?1:0,
        'user_id'      =>get_current_user_id(),
    ));
}
