<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nri_send_welcome_email($email,$password) {
    wp_mail($email,'Your NRI Platform Account',"Hello,\n\nAccount created.\nEmail: $email\nPassword: $password\n\nLogin: ".home_url('/nri-login')."\n\n-- NRI Platform");
}
function nri_send_magic_link($user_id,$email) {
    $token=wp_generate_password(32,false);
    set_transient('nri_magic_'.$token,$user_id,30*MINUTE_IN_SECONDS);
    wp_mail($email,'NRI Platform Login Link',"Login link (expires 30 min):\n".home_url('/nri-login?token='.$token));
}
add_action('template_redirect','nri_handle_magic_link');
function nri_handle_magic_link() {
    if (empty($_GET['token'])) return;
    $token=sanitize_text_field($_GET['token']);
    $uid=get_transient('nri_magic_'.$token);
    if (!$uid) wp_die('Login link expired. <a href="'.esc_url(home_url('/nri-login')).'">Get new link</a>');
    delete_transient('nri_magic_'.$token);
    wp_set_auth_cookie($uid,true);
    $user=get_userdata($uid); $roles=$user?(array)$user->roles:array();
    wp_redirect(in_array('nri_client',$roles)&&!in_array('administrator',$roles)?home_url('/client-dashboard'):home_url('/admin-dashboard'));
    exit;
}
