<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

// ── Core mailer (HTML) ──────────────────────────────────────────────────────
// wp_mail() only returns false on failure — the REASON (SMTP auth refused, sender
// rejected, connection timed out, ...) arrives on this action. Keep it so it can be
// logged, stored on the request, and shown to staff instead of vanishing.
add_action( 'wp_mail_failed', 'nri_capture_mail_error' );
function nri_capture_mail_error( $err ) {
    $msg = is_wp_error( $err ) ? $err->get_error_message() : 'Unknown mail error';
    $pw_problem = get_transient( 'nri_smtp_pw_problem' );
    if ( $pw_problem ) { $msg .= ' — LIKELY CAUSE: ' . $pw_problem; }
    $GLOBALS['nri_last_mail_error'] = $msg;
    update_option( 'nri_last_mail_error', array( 'time' => time(), 'message' => $msg ), false );
    nri_log( 'wp_mail_failed: ' . $msg );
}

function nri_mail( $to, $subject, $body_html ) {
    $GLOBALS['nri_last_mail_error'] = '';
    if ( ! $to || ! is_email( $to ) ) {
        nri_log( 'nri_mail: invalid recipient: ' . $to );
        return false;
    }

    // Always send HTML
    $headers = array( 'Content-Type: text/html; charset=UTF-8' );

    // Only add a custom From header when a valid address is explicitly configured.
    // If nri_email_from is empty or invalid, omit the header entirely so WordPress
    // uses its own default — the same behaviour as any working WordPress email.
    $from_email = get_option( 'nri_email_from', '' );
    $from_name  = get_option( 'nri_email_name', get_option( 'nri_platform_name', get_bloginfo( 'name' ) ) );
    if ( $from_email && is_email( $from_email ) ) {
        $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
    }
    // If no valid From is set, wp_mail uses WordPress's own default (admin_email) —
    // exactly the same address that working WP emails already use.

    $result = wp_mail( $to, $subject, $body_html, $headers );
    if ( ! $result ) {
        nri_log( 'nri_mail: wp_mail returned false. To=' . $to . ' Subject=' . $subject );
    }
    return $result;
}

// ── HTML email wrapper ───────────────────────────────────────────────────────
function nri_html_email( $greeting, $body_paragraphs, $rid_label = '', $cta_url = '', $cta_text = '' ) {
    $platform = get_option( 'nri_platform_name', get_bloginfo( 'name' ) );
    $color    = '#4f46e5';
    $body_content = '';
    foreach ( (array) $body_paragraphs as $p ) {
        $body_content .= '<p style="margin:0 0 14px;color:#334155;font-size:15px;line-height:1.7;">' . $p . '</p>';
    }
    $cta_block = '';
    if ( $cta_url && $cta_text ) {
        $cta_block = '<div style="text-align:center;margin:28px 0;">
            <a href="' . esc_url( $cta_url ) . '" style="background:' . $color . ';color:#fff;text-decoration:none;padding:12px 32px;border-radius:8px;font-size:15px;font-weight:600;display:inline-block;">' . esc_html( $cta_text ) . '</a></div>';
    }
    $order_badge = $rid_label ? '<div style="display:inline-block;background:#e0e7ff;color:#3730a3;padding:4px 14px;border-radius:20px;font-size:13px;font-weight:600;margin-bottom:20px;">Order #' . esc_html( $rid_label ) . '</div>' : '';
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:Arial,Helvetica,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:40px 0;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
  <tr><td style="background:' . $color . ';border-radius:12px 12px 0 0;padding:28px 40px;">
    <h1 style="margin:0;color:#fff;font-size:22px;font-weight:700;">' . esc_html( $platform ) . '</h1>
  </td></tr>
  <tr><td style="background:#fff;padding:36px 40px;">
    ' . $order_badge . '
    <p style="margin:0 0 20px;color:#1e293b;font-size:17px;font-weight:600;">' . esc_html( $greeting ) . '</p>
    ' . $body_content . $cta_block . '
  </td></tr>
  <tr><td style="background:#f8fafc;border-radius:0 0 12px 12px;padding:20px 40px;border-top:1px solid #e2e8f0;">
    <p style="margin:0;color:#94a3b8;font-size:13px;">This email was sent by <strong>' . esc_html( $platform ) . '</strong>. Please do not reply directly to this email.</p>
  </td></tr>
</table>
</td></tr></table></body></html>';
}

function nri_client_email( $rid ) {
    $p = get_post( $rid );
    return $p ? get_the_author_meta( 'user_email', $p->post_author ) : '';
}
function nri_admin_notification_email() {
    $list = nri_admin_notification_recipients();
    return $list ? $list[0] : '';
}

// Every address that should hear about a new request, best first. The configured
// manager email wins if it is a VALID address; a typo/blank there used to mean
// "send to nobody" (nri_mail() just logs and drops it) — now it falls back to the
// site admin email, and finally to every administrator account.
function nri_admin_notification_recipients() {
    $out = array();
    $mgr = trim( (string) get_option( 'nri_manager_email', '' ) );
    if ( $mgr !== '' && is_email( $mgr ) ) { $out[] = $mgr; }
    $site = trim( (string) get_option( 'admin_email', '' ) );
    if ( empty( $out ) && $site !== '' && is_email( $site ) ) { $out[] = $site; }
    if ( empty( $out ) ) {
        foreach ( get_users( array( 'role' => 'administrator', 'fields' => array( 'user_email' ) ) ) as $u ) {
            if ( is_email( $u->user_email ) ) { $out[] = $u->user_email; }
        }
    }
    return array_values( array_unique( $out ) );
}

// ── Message email ────────────────────────────────────────────────────────────
function nri_send_message_email( $rid, $message, $sender_name, $sender_is_staff = false ) {
    $platform  = get_option( 'nri_platform_name', get_bloginfo( 'name' ) );
    $rid_label = get_post_meta( $rid, 'request_id', true );
    $post      = get_post( $rid );
    $client    = $post ? get_userdata( $post->post_author ) : null;
    $client_name  = $client ? $client->display_name : 'Client';
    $client_email = $client ? $client->user_email   : '';
    $req_url   = home_url( '/request/' . $rid );

    if ( $sender_is_staff ) {
        if ( ! $client_email ) return;
        $subject = 'Update on Your Request — Order #' . $rid_label;
        $html    = nri_html_email(
            'Dear ' . $client_name . ',',
            array(
                esc_html( $sender_name ) . ' has sent you a message regarding your request:',
                '<div style="background:#f8fafc;border-left:4px solid #4f46e5;padding:14px 18px;border-radius:0 8px 8px 0;color:#334155;font-size:14px;line-height:1.7;">' . nl2br( esc_html( $message ) ) . '</div>',
                'You can view your full request and respond using the button below.',
            ),
            $rid_label, $req_url, 'View Your Request'
        );
        nri_mail( $client_email, $subject, $html );
    } else {
        $admin_email = nri_admin_notification_email();
        $subject     = 'New Message from ' . $client_name . ' — Order #' . $rid_label;
        $html        = nri_html_email(
            'New client message received',
            array(
                'Client: <strong>' . esc_html( $client_name ) . '</strong> &lt;' . esc_html( $client_email ) . '&gt;',
                '<div style="background:#f8fafc;border-left:4px solid #4f46e5;padding:14px 18px;border-radius:0 8px 8px 0;color:#334155;font-size:14px;line-height:1.7;">' . nl2br( esc_html( $message ) ) . '</div>',
            ),
            $rid_label, $req_url, 'View Request in Admin'
        );
        nri_mail( $admin_email, $subject, $html );
    }
}

// ── New request (admin notification) ────────────────────────────────────────
function nri_notify_new_request( $rid ) {
    $rid_label = get_post_meta( $rid, 'request_id', true );
    $post      = get_post( $rid );
    $client    = $post ? get_userdata( $post->post_author ) : null;
    $name      = $client ? $client->display_name : 'A new client';
    $email     = $client ? $client->user_email   : '';
    $req_url   = home_url( '/request/' . $rid );
    $to        = nri_admin_notification_email();
    $subject   = 'New Request Received — Order #' . $rid_label;
    $html      = nri_html_email(
        'New service request submitted',
        array(
            'A new application has been submitted and requires your attention.',
            '<table style="width:100%;border-collapse:collapse;font-size:14px;">
              <tr><td style="padding:8px 0;color:#64748b;width:140px;">Client</td><td style="padding:8px 0;color:#1e293b;font-weight:600;">' . esc_html( $name ) . '</td></tr>
              <tr><td style="padding:8px 0;color:#64748b;">Email</td><td style="padding:8px 0;color:#1e293b;">' . esc_html( $email ) . '</td></tr>
              <tr><td style="padding:8px 0;color:#64748b;">Submitted</td><td style="padding:8px 0;color:#1e293b;">' . current_time( 'd M Y H:i' ) . '</td></tr>
            </table>',
        ),
        $rid_label, $req_url, 'View Request'
    );
    // Returns true only if wp_mail() accepted it for EVERY recipient, so the caller
    // (nri_run_admin_notification) can record success/failure and retry.
    $ok = true;
    foreach ( nri_admin_notification_recipients() as $to_addr ) {
        if ( ! nri_mail( $to_addr, $subject, $html ) ) { $ok = false; }
    }
    if ( ! nri_admin_notification_recipients() ) {
        nri_log( 'nri_notify_new_request: NO valid staff recipient (nri_manager_email / admin_email) for request ' . $rid );
        return false;
    }
    return $ok;
}

// ── Staff notification delivery tracking + retry ────────────────────────────
// A request is flagged "notification pending" the instant it is saved; the flag is
// removed only when the email was accepted. Anything still flagged is retried by
// WP-Cron every 10 minutes AND whenever staff open the admin dashboard, so a mail
// server that was down/misconfigured for a moment never means a request goes
// unannounced. Meta used:
//   _nri_admin_notify_pending = 1        (present while undelivered)
//   _nri_admin_notify = array(state, attempts, last, error)
function nri_mark_admin_notification_pending( $rid, $client_is_new = false ) {
    $blank = array( 'state' => 'pending', 'attempts' => 0, 'last' => 0, 'error' => '' );
    update_post_meta( $rid, '_nri_admin_notify_pending', 1 );
    update_post_meta( $rid, '_nri_admin_notify', $blank );
    // Same tracking for the CLIENT "your request was submitted" email.
    update_post_meta( $rid, '_nri_client_notify_pending', 1 );
    update_post_meta( $rid, '_nri_client_notify', $blank );
    update_post_meta( $rid, '_nri_client_notify_is_new', $client_is_new ? 1 : 0 );
}

// TRACE: called right after a request is saved (synchronously, BEFORE the HTTP response)
//        and by the retry sweep → $kind is 'admin' (staff email) or 'client' (client
//        confirmation) → sends at most once at a time per request+kind (60s lock) → records
//        state 'sent'/'failed', attempts, timestamp and the REAL mail error on the request →
//        pre: $rid is an nri_request → post: the pending flag is cleared iff the mail server
//        accepted the message → edge: Throwable inside the send is caught and recorded.
function nri_run_notification( $rid, $kind ) {
    $rid = (int) $rid;
    if ( ! $rid || get_post_type( $rid ) !== 'nri_request' ) { return false; }
    $flag = '_nri_' . $kind . '_notify_pending';
    $meta = '_nri_' . $kind . '_notify';
    if ( ! get_post_meta( $rid, $flag, true ) ) { return true; } // already delivered
    $lock = 'nri_notify_lock_' . $kind . '_' . $rid;
    if ( get_transient( $lock ) ) { return false; }
    set_transient( $lock, 1, 60 );

    $st = get_post_meta( $rid, $meta, true );
    if ( ! is_array( $st ) ) { $st = array( 'state' => 'pending', 'attempts' => 0, 'last' => 0, 'error' => '' ); }
    $st['attempts'] = (int) $st['attempts'] + 1;
    $st['last']     = time();

    $GLOBALS['nri_last_mail_error'] = '';
    $ok = false;
    try {
        if ( $kind === 'admin' ) {
            $ok = (bool) nri_notify_new_request( $rid );
        } else {
            $ok = (bool) nri_notify_client_request_submitted( $rid, (bool) get_post_meta( $rid, '_nri_client_notify_is_new', true ) );
        }
    } catch ( \Throwable $e ) {
        $GLOBALS['nri_last_mail_error'] = $e->getMessage();
        nri_log( 'nri_run_notification(' . $kind . ') threw for request ' . $rid . ' — ' . $e->getMessage() );
    }
    if ( $ok ) {
        $st['state'] = 'sent'; $st['error'] = '';
        delete_post_meta( $rid, $flag );
        nri_log( 'Notification (' . $kind . ') delivered to mail server for request ' . $rid );
    } else {
        $st['state'] = 'failed';
        $st['error'] = ! empty( $GLOBALS['nri_last_mail_error'] ) ? $GLOBALS['nri_last_mail_error'] : 'wp_mail() returned false (no detail from the mail server)';
        nri_log( 'Notification (' . $kind . ') FAILED for request ' . $rid . ' (attempt ' . $st['attempts'] . ') — ' . $st['error'] );
    }
    update_post_meta( $rid, $meta, $st );
    delete_transient( $lock );
    return $ok;
}
function nri_run_admin_notification( $rid ) { return nri_run_notification( $rid, 'admin' ); }

// Retries every still-pending notification (max 6 attempts each, >=2 minutes apart,
// only for requests from the last 7 days). Cheap when nothing is pending: one indexed
// meta lookup. Rate-limited to once per minute per site.
function nri_retry_pending_admin_notifications() {
    if ( get_transient( 'nri_notify_sweep' ) ) { return 0; }
    set_transient( 'nri_notify_sweep', 1, 60 );
    $n = 0;
    foreach ( array( 'admin', 'client' ) as $kind ) {
        $ids = get_posts( array(
            'post_type' => 'nri_request', 'post_status' => 'publish', 'posts_per_page' => 10, 'fields' => 'ids',
            'meta_key' => '_nri_' . $kind . '_notify_pending', 'meta_value' => 1,
            'date_query' => array( array( 'after' => '7 days ago' ) ),
        ) );
        foreach ( $ids as $rid ) {
            $st = get_post_meta( $rid, '_nri_' . $kind . '_notify', true );
            $attempts = is_array( $st ) ? (int) $st['attempts'] : 0;
            $last     = is_array( $st ) ? (int) $st['last'] : 0;
            if ( $attempts >= 6 || ( time() - $last ) < 120 ) { continue; }
            if ( nri_run_notification( $rid, $kind ) ) { $n++; }
        }
    }
    return $n;
}
add_action( 'nri_retry_notifications_event', 'nri_retry_pending_admin_notifications' );
add_filter( 'cron_schedules', function( $s ) {
    if ( ! isset( $s['nri_ten_minutes'] ) ) { $s['nri_ten_minutes'] = array( 'interval' => 600, 'display' => 'Every 10 minutes' ); }
    return $s;
} );
add_action( 'init', function() {
    if ( ! wp_next_scheduled( 'nri_retry_notifications_event' ) ) { wp_schedule_event( time() + 300, 'nri_ten_minutes', 'nri_retry_notifications_event' ); }
    // The daily follow-up/escalation job (WhatsApp reminders) was only ever scheduled by the
    // plugin's ACTIVATION hook, which does not run when the plugin files are replaced by an
    // upload — make sure it exists either way.
    if ( ! wp_next_scheduled( 'nri_daily_cron' ) ) { wp_schedule_event( time() + 600, 'daily', 'nri_daily_cron' ); }
} );

// Requests whose staff notification is still undelivered — for the dashboard warning.
function nri_count_undelivered_admin_notifications() {
    $a = get_posts( array( 'post_type' => 'nri_request', 'post_status' => 'publish', 'posts_per_page' => 50, 'fields' => 'ids',
        'meta_key' => '_nri_admin_notify_pending', 'meta_value' => 1 ) );
    $c = get_posts( array( 'post_type' => 'nri_request', 'post_status' => 'publish', 'posts_per_page' => 50, 'fields' => 'ids',
        'meta_key' => '_nri_client_notify_pending', 'meta_value' => 1 ) );
    return array_values( array_unique( array_merge( $a, $c ) ) );
}

// TRACE: called from nri_ajax_create_request()'s nri_defer_after_response() block, right
//        after nri_notify_new_request() — one background job per newly-submitted request
//        → builds and sends the CLIENT-facing "your request has been submitted" email
//          (request ID, service, submission date, document names, current status, and a
//          link back to the request) → mutates nothing, only sends mail
//        → preconditions: $rid is a published nri_request post with 'request_id' meta
//          already set and post_author pointing at a real (possibly brand-new) user
//        → postconditions: one HTML email attempted to the request's owner; failures are
//          logged by nri_mail()/wp_mail and never thrown, so a mail failure cannot turn a
//          successful submission into a fatal error in the deferred shutdown job
//        → edge cases handled: missing/invalid client email (nri_mail() checks is_email()
//          and no-ops); zero documents (list line is simply omitted); $is_new toggles
//          whether the login-credentials paragraph is included, since an existing client
//          reusing their account should not be told "your password is included below" —
//          those credentials were already sent separately by nri_send_welcome_email().
function nri_notify_client_request_submitted( $rid, $is_new = false ) {
    $rid_label = get_post_meta( $rid, 'request_id', true );
    $post      = get_post( $rid );
    if ( ! $post ) return true; // nothing to send to; do not keep retrying
    $client    = get_userdata( $post->post_author );
    if ( ! $client || ! is_email( $client->user_email ) ) { nri_log( 'client confirmation skipped for request ' . $rid . ': no valid client email' ); return true; }

    $status      = get_post_meta( $rid, 'status', true );
    $status_lbl  = function_exists( 'nri_status_label' ) ? nri_status_label( $status ) : ucfirst( $status );
    $field_data  = get_post_meta( $rid, 'field_data', true );
    $service     = is_array( $field_data ) && ! empty( $field_data['field_service_type'] )
                 ? $field_data['field_service_type']
                 : ( is_array( $field_data ) && ! empty( $field_data['field_document_type'] ) ? $field_data['field_document_type'] : 'Document Request' );
    $documents   = get_post_meta( $rid, 'documents', true );
    $doc_names   = array();
    if ( is_array( $documents ) ) {
        foreach ( $documents as $doc ) {
            if ( empty( $doc['file'] ) ) continue;
            $doc_names[] = get_the_title( $doc['file'] ) ?: 'Document';
        }
    }

    $req_url = home_url( '/request/' . $rid );
    $subject = 'Your request has been successfully submitted — Order #' . $rid_label;

    $paragraphs = array(
        '<strong>Your request has been successfully submitted.</strong> Our team will review the details and get back to you.',
    );

    $summary_rows = '<tr><td style="padding:8px 0;color:#64748b;width:150px;">Service</td><td style="padding:8px 0;color:#1e293b;font-weight:600;">' . esc_html( $service ) . '</td></tr>'
        . '<tr><td style="padding:8px 0;color:#64748b;">Submitted</td><td style="padding:8px 0;color:#1e293b;">' . current_time( 'd M Y' ) . '</td></tr>'
        . '<tr><td style="padding:8px 0;color:#64748b;">Current Status</td><td style="padding:8px 0;"><span style="background:#e0e7ff;color:#3730a3;padding:3px 12px;border-radius:20px;font-size:13px;font-weight:600;">' . esc_html( $status_lbl ) . '</span></td></tr>';
    $paragraphs[] = '<table style="width:100%;border-collapse:collapse;font-size:14px;">' . $summary_rows . '</table>';

    if ( ! empty( $doc_names ) ) {
        $doc_list = '<ul style="margin:0;padding-left:18px;color:#1e293b;font-size:14px;line-height:1.9;">';
        foreach ( $doc_names as $dn ) { $doc_list .= '<li>' . esc_html( $dn ) . '</li>'; }
        $doc_list .= '</ul>';
        $paragraphs[] = '<strong>Documents received:</strong>' . $doc_list;
    }

    if ( $is_new ) {
        $paragraphs[] = 'We\'ve created an account for you so you can track this request, view your documents, and receive updates — your login details were sent in a separate email.';
    } else {
        $paragraphs[] = 'You can track this request any time from your account dashboard.';
    }

    $paragraphs[] = 'If you have any questions, please do not hesitate to reach out to our support team.';

    $html = nri_html_email(
        'Dear ' . $client->display_name . ',',
        $paragraphs,
        $rid_label, $req_url, 'View My Request'
    );
    return nri_mail( $client->user_email, $subject, $html );
}

// ── Account created (client welcome) ────────────────────────────────────────
function nri_notify_account_created( $user_id ) {
    $user     = get_userdata( $user_id );
    if ( ! $user ) return;
    $platform = get_option( 'nri_platform_name', get_bloginfo( 'name' ) );
    $subject  = 'Welcome to ' . $platform . ' — Your Account is Ready';
    $html     = nri_html_email(
        'Dear ' . $user->display_name . ',',
        array(
            'Greetings for the day!',
            'Your account has been successfully created on <strong>' . esc_html( $platform ) . '</strong>. You can now log in and start submitting your service requests.',
            '<table style="width:100%;border-collapse:collapse;font-size:14px;">
              <tr><td style="padding:8px 0;color:#64748b;width:120px;">Name</td><td style="padding:8px 0;color:#1e293b;font-weight:600;">' . esc_html( $user->display_name ) . '</td></tr>
              <tr><td style="padding:8px 0;color:#64748b;">Email</td><td style="padding:8px 0;color:#1e293b;">' . esc_html( $user->user_email ) . '</td></tr>
            </table>',
            'If you have any questions, feel free to contact our support team.',
        ),
        '', home_url( '/client-dashboard' ), 'Go to Dashboard'
    );
    nri_mail( $user->user_email, $subject, $html );
}
add_action( 'user_register', 'nri_notify_account_created' );

// ── Status change (client notification) ─────────────────────────────────────
function nri_notify_status_change( $rid, $new_status ) {
    $rid_label    = get_post_meta( $rid, 'request_id', true );
    $post         = get_post( $rid );
    $client       = $post ? get_userdata( $post->post_author ) : null;
    if ( ! $client ) return false;
    $status_label = nri_status_label( $new_status );
    $req_url      = home_url( '/request/' . $rid );
    $meta         = nri_get_meta( $rid );
    $delivery     = $meta['estimated_delivery'] ? date( 'd M Y', strtotime( $meta['estimated_delivery'] ) ) : 'To be updated';
    $subject = 'Status Update: ' . $status_label . ' — Order #' . $rid_label;

    $status_messages = array(
        'under_review'         => 'Your application is currently under review by our team. We will keep you updated.',
        'ready_for_processing' => 'Great news! Your application is ready for processing. Our team will begin work shortly.',
        'approved'             => 'Your application has been approved! We are now proceeding with the next steps.',
        'processing'           => 'Your request is now being actively processed by our team.',
        'dispatched'           => 'Your documents have been dispatched. Please check your shipping details.',
        'completed'            => 'Your request has been successfully completed. Thank you for choosing us!',
        'service_not_available'=> 'We regret to inform you that the requested service is currently not available for your case. Our team will contact you with further details.',
        'rejected'             => 'Unfortunately, we were unable to process your request. Our team will contact you with further information.',
    );
    $msg = isset( $status_messages[ $new_status ] ) ? $status_messages[ $new_status ] : 'Your request status has been updated.';

    $html = nri_html_email(
        'Dear ' . $client->display_name . ',',
        array(
            'Greetings for the day!',
            $msg,
            '<table style="width:100%;border-collapse:collapse;font-size:14px;background:#f8fafc;border-radius:8px;padding:4px;">
              <tr><td style="padding:10px 14px;color:#64748b;width:160px;">Order ID</td><td style="padding:10px 14px;color:#1e293b;font-weight:600;">' . esc_html( $rid_label ) . '</td></tr>
              <tr><td style="padding:10px 14px;color:#64748b;">Current Status</td><td style="padding:10px 14px;"><span style="background:#e0e7ff;color:#3730a3;padding:3px 12px;border-radius:20px;font-size:13px;font-weight:600;">' . esc_html( $status_label ) . '</span></td></tr>
              <tr><td style="padding:10px 14px;color:#64748b;">Est. Delivery</td><td style="padding:10px 14px;color:#1e293b;">' . esc_html( $delivery ) . ' <small style="color:#94a3b8;">(working days only)</small></td></tr>
            </table>',
            'Click the button below to view your complete request details and updates.',
        ),
        $rid_label, $req_url, 'View Request'
    );
    // Return the real delivery result: the manual "Send status email" button reports
    // success/failure from this, and used to ALWAYS say "failed" because nothing was returned.
    return nri_mail( $client->user_email, $subject, $html );
}

// ── Quotation email ──────────────────────────────────────────────────────────
function nri_notify_quotation( $rid, $include_terms = false ) {
    $rid_label = get_post_meta( $rid, 'request_id', true );
    $post      = get_post( $rid );
    $client    = $post ? get_userdata( $post->post_author ) : null;
    if ( ! $client ) return false;
    $meta      = nri_get_meta( $rid );
    $fd        = $meta['field_data'];
    $platform  = get_option( 'nri_platform_name', get_bloginfo( 'name' ) );
    $req_url   = home_url( '/request/' . $rid );

    $service_amount  = $meta['quote_amount'] ? floatval( $meta['quote_amount'] ) : 0;
    $shipping        = isset( $meta['shipping_charges'] ) ? floatval( $meta['shipping_charges'] ) : 0;
    $shipping_type   = isset( $meta['shipping_type'] ) ? $meta['shipping_type'] : 'domestic';
    $total           = $service_amount + $shipping;
    $delivery        = $meta['estimated_delivery'] ? date( 'd M Y', strtotime( $meta['estimated_delivery'] ) ) : 'To be confirmed';
    $working_days    = get_post_meta( $rid, 'timeline_working_days', true );
    $timeline_str    = $working_days ? $working_days . ' Working Days' : 'To be confirmed';

    $svc = '';
    if ( ! empty( $fd['field_service_type'] ) )      $svc = $fd['field_service_type'];
    elseif ( ! empty( $fd['field_document_type'] ) ) $svc = $fd['field_document_type'];
    else                                              $svc = 'Document Service';

    // Also expose document type label cleanly
    $doc_type = ! empty( $fd['field_document_type'] ) ? $fd['field_document_type']
              : ( ! empty( $fd['field_service_type'] ) ? $fd['field_service_type'] : 'Document Service' );

    $terms_block = '';
    if ( $include_terms ) {
        $terms_block = '<div style="margin-top:24px;padding:20px;background:#fafafa;border:1px solid #e2e8f0;border-radius:8px;">
            <p style="margin:0 0 12px;font-size:15px;font-weight:700;color:#1e293b;">Terms &amp; Conditions</p>
            <p style="margin:0 0 10px;font-size:13px;color:#334155;line-height:1.7;"><strong>1. Non-Refundable Clause:</strong> If the university is unable to trace the student\'s record, or if submitted documents are incorrect or incomplete, university fees are non-refundable. Accordingly, ' . esc_html($platform) . ' will also not be able to process any refund.</p>
            <p style="margin:0 0 10px;font-size:13px;color:#334155;line-height:1.7;"><strong>2. Processing Time:</strong> The estimated timeline (' . esc_html($timeline_str) . ') is indicative and may vary depending on university workload, holidays, or internal delays.</p>
            <p style="margin:0 0 10px;font-size:13px;color:#334155;line-height:1.7;"><strong>3. Transcript Format:</strong> The format of transcripts is entirely determined by the university. We do not control the format and cannot accommodate requests for specific layouts.</p>
            <p style="margin:0 0 10px;font-size:13px;color:#334155;line-height:1.7;"><strong>4. Service Disclaimer:</strong> ' . esc_html($platform) . ' is an independent service provider and is not affiliated with any university or institution.</p>
            <p style="margin:0;font-size:13px;color:#334155;line-height:1.7;"><strong>5. Validity:</strong> This quotation is valid for <strong>7 days</strong> from the date of issue. There is no obligation to proceed.</p>
        </div>';
    }

    $subject = 'Quotation for Your Request — Order #' . $rid_label;
    $html    = nri_html_email(
        'Dear ' . $client->display_name . ',',
        array(
            'Greetings for the day!',
            'Thank you for reaching out to us. We are pleased to share the official quotation for your service request.',
            '<table style="width:100%;border-collapse:collapse;font-size:14px;background:#f8fafc;border-radius:8px;">
              <tr><td style="padding:10px 14px;color:#64748b;width:180px;">Order ID</td><td style="padding:10px 14px;color:#1e293b;font-weight:600;">' . esc_html($rid_label) . '</td></tr>
              <tr><td style="padding:10px 14px;color:#64748b;">Service</td><td style="padding:10px 14px;color:#1e293b;">' . esc_html($svc) . '</td></tr>
              <tr><td style="padding:10px 14px;color:#64748b;">Service Charges</td><td style="padding:10px 14px;color:#1e293b;font-weight:600;">INR ' . number_format($service_amount,2) . '</td></tr>
              <tr><td style="padding:10px 14px;color:#64748b;">Shipping (' . esc_html(ucfirst($shipping_type)) . ')</td><td style="padding:10px 14px;color:#1e293b;">INR ' . number_format($shipping,2) . '</td></tr>
              <tr style="background:#e0e7ff;"><td style="padding:12px 14px;color:#3730a3;font-weight:700;">Total Amount</td><td style="padding:12px 14px;color:#3730a3;font-weight:700;font-size:16px;">INR ' . number_format($total,2) . '</td></tr>
              <tr><td style="padding:10px 14px;color:#64748b;">Timeline</td><td style="padding:10px 14px;color:#1e293b;">' . esc_html($timeline_str) . '<br><small style="color:#94a3b8;">Excludes Sat, Sun &amp; Govt Holidays</small></td></tr>
              <tr><td style="padding:10px 14px;color:#64748b;">Expected by</td><td style="padding:10px 14px;color:#1e293b;font-weight:600;">' . esc_html($delivery) . '</td></tr>
            </table>',
            'Kindly review the quotation and confirm your acceptance to begin processing. You can view complete details using the button below.' . $terms_block,
        ),
        $rid_label, $req_url, 'View &amp; Accept Quotation'
    );
    return nri_mail( $client->user_email, $subject, $html );
}

// ── Document reminder email ──────────────────────────────────────────────────
function nri_notify_document_reminder( $rid, $extra_note = '' ) {
    $rid_label = get_post_meta( $rid, 'request_id', true );
    $post      = get_post( $rid );
    $client    = $post ? get_userdata( $post->post_author ) : null;
    if ( ! $client ) return false;
    $req_url   = home_url( '/request/' . $rid );
    $subject   = 'Documents Required — Order #' . $rid_label;
    $extra     = $extra_note ? '<p style="margin:12px 0 0;font-size:14px;color:#334155;line-height:1.7;"><strong>Note from our team:</strong> ' . esc_html($extra_note) . '</p>' : '';
    $html      = nri_html_email(
        'Dear ' . $client->display_name . ',',
        array(
            'Greetings for the day!',
            'We hope this message finds you well. This is a reminder that we are still awaiting some documents for your request.',
            '<div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:8px;padding:16px 20px;">
              <p style="margin:0 0 10px;font-size:14px;font-weight:700;color:#9a3412;">Documents Required:</p>
              <ul style="margin:0;padding-left:18px;color:#7c3a21;font-size:14px;line-height:1.9;">
                <li>All Semester Marksheets (Properly Scanned)</li>
                <li>Degree Certificate (Properly Scanned)</li>
                <li>Any other documents as instructed by our team</li>
              </ul>' . $extra . '
            </div>',
            '<div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:14px 18px;font-size:14px;color:#991b1b;font-weight:600;">&#9888; Your request cannot be processed without properly scanned documents. Please use a printer scanner — mobile photos may not be accepted.</div>',
            'Please upload your documents at the earliest to avoid delays.',
        ),
        $rid_label, $req_url, 'Upload Documents Now'
    );
    return nri_mail( $client->user_email, $subject, $html );
}
