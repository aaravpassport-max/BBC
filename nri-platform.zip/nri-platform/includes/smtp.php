<?php
/**
 * NRI Platform — Built-in SMTP Configuration
 * Hooks into WordPress's PHPMailer instance so all wp_mail() calls
 * (including WooCommerce, contact forms, and the NRI plugin itself)
 * route through the configured SMTP server.
 *
 * Settings are stored in wp_options under nri_smtp_* keys.
 * The password is stored AES-256-CBC encrypted using AUTH_KEY as the key.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// ── Encrypt / decrypt helpers ────────────────────────────────────────────────

function nri_smtp_encrypt( $plain ) {
    if ( ! $plain ) { return ''; }
    if ( ! function_exists( 'openssl_encrypt' ) ) { return ''; }
    $key    = substr( hash( 'sha256', defined( 'AUTH_KEY' ) ? AUTH_KEY : 'nri_fallback_key_change_me', true ), 0, 32 );
    $iv     = random_bytes( 16 );
    $cipher = openssl_encrypt( $plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
    return $cipher !== false ? base64_encode( $iv . $cipher ) : '';
}

function nri_smtp_decrypt( $stored ) {
    if ( ! $stored ) { return ''; }
    if ( ! function_exists( 'openssl_decrypt' ) ) { return ''; }
    $key  = substr( hash( 'sha256', defined( 'AUTH_KEY' ) ? AUTH_KEY : 'nri_fallback_key_change_me', true ), 0, 32 );
    $raw  = base64_decode( $stored );
    if ( strlen( $raw ) < 17 ) { return ''; }
    $iv   = substr( $raw, 0, 16 );
    $dec  = openssl_decrypt( substr( $raw, 16 ), 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
    return $dec !== false ? $dec : '';
}

// ── Get all SMTP settings ────────────────────────────────────────────────────

function nri_get_smtp_settings() {
    return array(
        'enabled'    => (bool) get_option( 'nri_smtp_enabled', 0 ),
        'host'       => get_option( 'nri_smtp_host',       '' ),
        'port'       => (int)  get_option( 'nri_smtp_port',       587 ),
        'encryption' => get_option( 'nri_smtp_encryption', 'tls' ),   // tls | ssl | none
        'auth'       => (bool) get_option( 'nri_smtp_auth',       1 ),
        'username'   => get_option( 'nri_smtp_username',   '' ),
        'password'   => nri_smtp_decrypt( get_option( 'nri_smtp_password_enc', '' ) ),
        'from_email' => get_option( 'nri_email_from',      get_option( 'admin_email' ) ),
        'from_name'  => get_option( 'nri_email_name',      get_bloginfo( 'name' ) ),
        // Only what the owner explicitly saved. We NEVER impersonate the site admin_email
        // (often a gmail.com address): SPF/DMARC then fails and hosts/inboxes drop the mail.
        'from_set'   => (string) get_option( 'nri_email_from', '' ),
    );
}

// ── Hook into PHPMailer before every wp_mail() call ─────────────────────────

add_action( 'phpmailer_init', 'nri_configure_phpmailer' );
function nri_configure_phpmailer( $phpmailer ) {
    $s = nri_get_smtp_settings();

    if ( ! $s['enabled'] || ! $s['host'] ) {
        // SMTP not configured — leave WordPress default (PHP mail()).
        // Force From ONLY if the owner explicitly saved one; otherwise keep WordPress's
        // own wordpress@{site-domain}, which matches the server and passes SPF.
        if ( $s['from_set'] && is_email( $s['from_set'] ) ) {
            $phpmailer->From     = $s['from_set'];
            $phpmailer->FromName = $s['from_name'];
        } elseif ( $phpmailer->FromName === 'WordPress' ) {
            $phpmailer->FromName = $s['from_name'];   // brand name only; address untouched
        }
        return;
    }

    // PHPMailer's default socket timeout is 300 SECONDS — far longer than PHP's own
    // execution limit (often 30s). A slow/unreachable mail server therefore used to hang
    // until PHP killed the script, which left NO error, NO log line and no email (and, when
    // that happened in a background job, nobody ever noticed). Fail fast and visibly instead.
    // Two separate limits exist: PHPMailer::$Timeout (connect + socket) AND the SMTP object's
    // own $Timelimit (how long to wait for the server's reply to each command) — the second
    // also defaults to 300s and is what a server that accepts the connection but then never
    // answers would hang on. Bound both.
    $phpmailer->Timeout       = 10;
    $phpmailer->SMTPKeepAlive = false;
    if ( method_exists( $phpmailer, 'getSMTPInstance' ) ) {
        $smtp_obj = $phpmailer->getSMTPInstance();
        if ( is_object( $smtp_obj ) ) { $smtp_obj->Timelimit = 10; $smtp_obj->Timeout = 10; }
    }

    // The stored SMTP password is encrypted with this site's AUTH_KEY. If the site was
    // migrated/cloned or its security keys were regenerated, the stored value can no longer
    // be decrypted and silently becomes '' — every login to the mail server then fails.
    // Surface that exact cause instead of an anonymous "authentication failed".
    if ( $s['auth'] && $s['username'] !== '' && $s['password'] === '' ) {
        $why = get_option( 'nri_smtp_password_enc', '' ) ? 'The saved SMTP password could not be decrypted (the site security keys changed, e.g. after a migration). Open Settings → Email/SMTP and enter the SMTP password again.' : 'No SMTP password is saved. Open Settings → Email/SMTP and enter it.';
        set_transient( 'nri_smtp_pw_problem', $why, 300 ); // appended to the real failure by nri_capture_mail_error()
        nri_log( 'nri_configure_phpmailer: ' . $why );
    } else {
        delete_transient( 'nri_smtp_pw_problem' );
    }

    $phpmailer->isSMTP();
    $phpmailer->Host       = $s['host'];
    $phpmailer->Port       = $s['port'];
    $phpmailer->SMTPAuth   = $s['auth'];
    $phpmailer->Username   = $s['username'];
    $phpmailer->Password   = $s['password'];

    switch ( $s['encryption'] ) {
        case 'ssl':
            $phpmailer->SMTPSecure = 'ssl';
            break;
        case 'tls':
            $phpmailer->SMTPSecure = 'tls';
            break;
        default:
            $phpmailer->SMTPSecure = '';
            $phpmailer->SMTPAutoTLS = false;
            break;
    }

    // Sender: explicit setting, else the authenticated SMTP account (most providers
    // reject or rewrite any other From). Never fall back to admin_email.
    $from = ( $s['from_set'] && is_email( $s['from_set'] ) ) ? $s['from_set']
          : ( is_email( $s['username'] ) ? $s['username'] : '' );
    if ( $from ) {
        $phpmailer->From     = $from;
        $phpmailer->FromName = $s['from_name'];
    } elseif ( $phpmailer->FromName === 'WordPress' ) {
        $phpmailer->FromName = $s['from_name'];
    }

    // Debug: write SMTP conversation to nri-debug.log in verbose mode
    if ( get_option( 'nri_smtp_debug', 0 ) ) {
        $phpmailer->SMTPDebug  = 2;
        $phpmailer->Debugoutput = function( $msg, $level ) {
            nri_log( '[SMTP DEBUG L' . $level . '] ' . trim( $msg ) );
        };
    }

    nri_log( 'nri_configure_phpmailer: SMTP configured. Host=' . $s['host'] . ' Port=' . $s['port'] . ' Enc=' . $s['encryption'] . ' User=' . $s['username'] );
}

// ── Also hook wp_mail_from and wp_mail_from_name filters ─────────────────────
// These ensure the correct sender appears even if something else overrides the header.

add_filter( 'wp_mail_from', function( $email ) {
    $from = get_option( 'nri_email_from', '' );
    return ( $from && is_email( $from ) ) ? $from : $email;
}, 20 );

add_filter( 'wp_mail_from_name', function( $name ) {
    $from_name = get_option( 'nri_email_name', '' );
    return $from_name ? $from_name : $name;
}, 20 );

// ── AJAX: Save SMTP settings ─────────────────────────────────────────────────

add_action( 'wp_ajax_nri_save_smtp_settings', 'nri_ajax_save_smtp_settings' );
function nri_ajax_save_smtp_settings() {
    nri_check_nonce();
    nri_require_staff();

    $enabled    = ! empty( $_POST['nri_smtp_enabled'] ) ? 1 : 0;
    $host       = sanitize_text_field( $_POST['nri_smtp_host']       ?? '' );
    $port       = intval( $_POST['nri_smtp_port']       ?? 587 );
    $encryption = sanitize_text_field( $_POST['nri_smtp_encryption'] ?? 'tls' );
    $auth       = ! empty( $_POST['nri_smtp_auth'] ) ? 1 : 0;
    $username   = sanitize_text_field( $_POST['nri_smtp_username']   ?? '' );
    $password   = $_POST['nri_smtp_password'] ?? '';          // raw — will be encrypted
    $from_email = sanitize_email( $_POST['nri_email_from']           ?? '' );
    $from_name  = sanitize_text_field( $_POST['nri_email_name']      ?? '' );
    $debug      = ! empty( $_POST['nri_smtp_debug'] ) ? 1 : 0;

    if ( ! in_array( $encryption, array( 'tls', 'ssl', 'none' ), true ) ) {
        $encryption = 'tls';
    }
    if ( $port < 1 || $port > 65535 ) { $port = 587; }

    update_option( 'nri_smtp_enabled',    $enabled );
    update_option( 'nri_smtp_host',       $host );
    update_option( 'nri_smtp_port',       $port );
    update_option( 'nri_smtp_encryption', $encryption );
    update_option( 'nri_smtp_auth',       $auth );
    update_option( 'nri_smtp_username',   $username );
    update_option( 'nri_smtp_debug',      $debug );
    if ( $from_email ) { update_option( 'nri_email_from', $from_email ); }
    if ( $from_name )  { update_option( 'nri_email_name', $from_name );  }

    // Only update password if a new one was submitted (empty = keep existing)
    if ( $password !== '' ) {
        update_option( 'nri_smtp_password_enc', nri_smtp_encrypt( $password ) );
    }

    nri_log( 'SMTP settings saved by ' . wp_get_current_user()->user_login . '. Host=' . $host . ' Port=' . $port . ' Enabled=' . $enabled );
    wp_send_json_success( array( 'message' => 'SMTP settings saved.' ) );
}

// ── AJAX: Send test email ────────────────────────────────────────────────────

add_action( 'wp_ajax_nri_smtp_test', 'nri_ajax_smtp_test' );
function nri_ajax_smtp_test() {
    nri_check_nonce();
    nri_require_staff();

    $to = sanitize_email( $_POST['test_email'] ?? '' );
    if ( ! $to || ! is_email( $to ) ) {
        wp_send_json_error( array( 'message' => 'Please enter a valid email address to send the test to.' ) );
    }

    $platform = get_option( 'nri_platform_name', get_bloginfo( 'name' ) );
    $s        = nri_get_smtp_settings();

    $subject = '[Test] SMTP working — ' . $platform;
    $body    = '<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;padding:30px;color:#1e293b;">'
             . '<h2 style="color:#4f46e5;">✅ SMTP is working!</h2>'
             . '<p>This is a test email from <strong>' . esc_html( $platform ) . '</strong>.</p>'
             . '<table style="border-collapse:collapse;font-size:14px;margin-top:20px;">'
             . '<tr><td style="padding:6px 14px 6px 0;color:#64748b;">Sent via</td><td style="padding:6px 0;font-weight:600;">' . esc_html( $s['enabled'] && $s['host'] ? $s['host'] . ':' . $s['port'] : 'PHP mail() (no SMTP configured)' ) . '</td></tr>'
             . '<tr><td style="padding:6px 14px 6px 0;color:#64748b;">From</td><td style="padding:6px 0;">' . esc_html( $s['from_name'] . ' <' . $s['from_email'] . '>' ) . '</td></tr>'
             . '<tr><td style="padding:6px 14px 6px 0;color:#64748b;">To</td><td style="padding:6px 0;">' . esc_html( $to ) . '</td></tr>'
             . '<tr><td style="padding:6px 14px 6px 0;color:#64748b;">Time</td><td style="padding:6px 0;">' . current_time( 'd M Y, g:i a' ) . '</td></tr>'
             . '</table>'
             . '<p style="margin-top:24px;color:#64748b;font-size:13px;">If you received this email, your SMTP configuration is correct.</p>'
             . '</body></html>';

    // Enable SMTP debug for this test send
    $prev_debug = get_option( 'nri_smtp_debug', 0 );
    update_option( 'nri_smtp_debug', 1 );

    $sent = nri_mail( $to, $subject, $body );

    update_option( 'nri_smtp_debug', $prev_debug ); // restore

    if ( $sent ) {
        nri_log( 'SMTP test email sent successfully to ' . $to );
        wp_send_json_success( array(
            'message' => 'Test email sent to ' . $to . '. Check your inbox (and spam folder). If received, SMTP is working correctly.',
        ) );
    } else {
        // Try to get PHPMailer error
        global $phpmailer;
        $err = ( isset( $phpmailer ) && is_object( $phpmailer ) && ! empty( $phpmailer->ErrorInfo ) )
             ? $phpmailer->ErrorInfo
             : 'wp_mail() returned false — check nri-debug.log in the plugin folder for SMTP conversation details.';
        nri_log( 'SMTP test FAILED to ' . $to . '. Error: ' . $err );
        wp_send_json_error( array( 'message' => 'Failed: ' . $err ) );
    }
}

// ── Email diagnostics ────────────────────────────────────────────────────────
// TRACE: staff clicks "Run email diagnostics" → collects live-server facts (settings, hooks that
//        can alter mail, PHP mail() availability, DNS, socket reach), sends ONE real test mail while
//        capturing PHPMailer's SMTP transcript (credentials masked) → returns {report, findings}.
//        preconditions: staff + valid nonce → postconditions: no option changed, one mail attempted
//        → edge cases: dns/ fsockopen/ Reflection unavailable (skipped), send throws (caught).
function nri_diag_callbacks( $hook ) {
    global $wp_filter;
    $out = array();
    if ( empty( $wp_filter[ $hook ] ) ) { return $out; }
    foreach ( $wp_filter[ $hook ]->callbacks as $prio => $cbs ) {
        foreach ( $cbs as $cb ) {
            $f = $cb['function']; $where = '?';
            try {
                if ( is_string( $f ) && function_exists( $f ) ) { $r = new ReflectionFunction( $f ); $where = $f . ' @ ' . basename( (string) $r->getFileName() ); }
                elseif ( $f instanceof Closure ) { $r = new ReflectionFunction( $f ); $where = 'closure @ ' . str_replace( WP_PLUGIN_DIR . '/', '', (string) $r->getFileName() ) . ':' . $r->getStartLine(); }
                elseif ( is_array( $f ) ) { $c = is_object( $f[0] ) ? get_class( $f[0] ) : $f[0]; $r = new ReflectionMethod( $c, $f[1] ); $where = $c . '::' . $f[1] . ' @ ' . str_replace( WP_PLUGIN_DIR . '/', '', (string) $r->getFileName() ); }
            } catch ( Throwable $e ) { $where = 'unknown'; }
            $out[] = '[' . $prio . '] ' . $where;
        }
    }
    return $out;
}

add_action( 'wp_ajax_nri_email_diagnostics', 'nri_ajax_email_diagnostics' );
function nri_ajax_email_diagnostics() {
    nri_check_nonce();
    nri_require_staff();
    $to = sanitize_email( $_POST['test_email'] ?? '' );
    if ( ! $to || ! is_email( $to ) ) { $to = wp_get_current_user()->user_email; }

    $L = array(); $F = array();
    $s = nri_get_smtp_settings();
    $site_host = preg_replace( '/^www\./', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) );

    $L[] = '== SETTINGS ==';
    $L[] = 'SMTP enabled: ' . ( $s['enabled'] ? 'yes' : 'NO (using PHP mail())' ) . ' | host: ' . ( $s['host'] ?: '-' ) . ':' . $s['port'] . ' ' . $s['encryption'] . ' | user: ' . ( $s['username'] ?: '-' );
    $L[] = 'Saved From (nri_email_from): ' . ( $s['from_set'] ?: '(not set → WordPress default)' );
    $L[] = 'Site admin_email: ' . get_option( 'admin_email' ) . ' | Manager email: ' . ( get_option( 'nri_manager_email', '' ) ?: '-' );
    $L[] = 'Admin alerts go to: ' . implode( ', ', nri_admin_notification_recipients() );
    $lme = get_option( 'nri_last_mail_error', '' );
    $L[] = 'Last recorded mail error: ' . ( $lme ? ( is_scalar( $lme ) ? (string) $lme : wp_json_encode( $lme ) ) : 'none' );
    $L[] = 'Requests with undelivered notifications: ' . count( nri_count_undelivered_admin_notifications() );

    $effective_from = $s['from_set'] ?: ( $s['enabled'] && is_email( $s['username'] ) ? $s['username'] : 'wordpress@' . $site_host );
    $fd = strtolower( substr( strrchr( $effective_from, '@' ), 1 ) );
    if ( $fd && $fd !== $site_host && ! ( $s['enabled'] && $s['host'] ) ) {
        $F[] = 'From address "' . $effective_from . '" is on ' . $fd . ' but this site/server is ' . $site_host . ' and no SMTP is configured. Hosts and inboxes usually reject or silently drop this (SPF/DMARC). Clear the From field or enable SMTP with a mailbox on your own domain.';
    }
    if ( $s['enabled'] && $s['host'] && $s['username'] && $s['from_set'] && strcasecmp( $s['from_set'], $s['username'] ) !== 0 && preg_match( '/gmail|outlook|office365|yahoo|hotmail/i', $s['host'] ) ) {
        $F[] = 'SMTP host ' . $s['host'] . ' requires From = the login mailbox (' . $s['username'] . '), but From is ' . $s['from_set'] . '. The provider rewrites or rejects it.';
    }
    if ( get_transient( 'nri_smtp_pw_problem' ) ) { $F[] = 'SMTP password could not be decrypted (site keys changed after a migration). Re-enter the SMTP password and Save.'; }

    $L[] = ''; $L[] = '== PHP / SERVER ==';
    $df = (string) ini_get( 'disable_functions' );
    $L[] = 'PHP ' . PHP_VERSION . ' | mail(): ' . ( function_exists( 'mail' ) ? 'available' : 'MISSING' ) . ' | sendmail_path: ' . ( ini_get( 'sendmail_path' ) ?: '-' ) . ' | disable_functions: ' . ( $df ?: '-' );
    if ( ! function_exists( 'mail' ) || preg_match( '/(^|,)\s*mail\s*(,|$)/', $df ) ) {
        if ( ! ( $s['enabled'] && $s['host'] ) ) { $F[] = 'PHP mail() is disabled on this server and SMTP is not enabled — NO email can leave. Enable SMTP.'; }
    }
    try { $rf = new ReflectionFunction( 'wp_mail' ); $wf = (string) $rf->getFileName(); $L[] = 'wp_mail() defined in: ' . str_replace( ABSPATH, '', $wf );
        if ( strpos( $wf, 'wp-includes/pluggable.php' ) === false ) { $F[] = 'wp_mail() is REPLACED by ' . str_replace( ABSPATH, '', $wf ) . ' — that code decides delivery, not WordPress/this plugin.'; } } catch ( Throwable $e ) {}
    if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) { $L[] = 'DISABLE_WP_CRON: true (retry sweep runs only when an admin opens the dashboard)'; }

    $L[] = ''; $L[] = '== HOOKS THAT CAN ALTER OR BLOCK MAIL ==';
    foreach ( array( 'pre_wp_mail', 'wp_mail', 'phpmailer_init', 'wp_mail_from', 'wp_mail_from_name', 'wp_mail_content_type', 'wp_mail_failed' ) as $h ) {
        $cbs = nri_diag_callbacks( $h );
        $L[] = $h . ': ' . ( $cbs ? '' : 'none' );
        foreach ( $cbs as $c ) { $L[] = '   ' . $c; }
        if ( $h === 'pre_wp_mail' && $cbs ) { $F[] = 'Something hooks pre_wp_mail — it can short-circuit every email before sending: ' . implode( '; ', $cbs ); }
    }

    $L[] = ''; $L[] = '== DNS for ' . ( $fd ?: '-' ) . ' ==';
    if ( $fd && function_exists( 'dns_get_record' ) ) {
        $spf = '-'; $dmarc = '-';
        foreach ( (array) @dns_get_record( $fd, DNS_TXT ) as $r ) { if ( isset( $r['txt'] ) && stripos( $r['txt'], 'v=spf1' ) === 0 ) { $spf = $r['txt']; } }
        foreach ( (array) @dns_get_record( '_dmarc.' . $fd, DNS_TXT ) as $r ) { if ( isset( $r['txt'] ) && stripos( $r['txt'], 'v=DMARC1' ) === 0 ) { $dmarc = $r['txt']; } }
        $L[] = 'SPF: ' . $spf; $L[] = 'DMARC: ' . $dmarc;
        if ( $spf === '-' && $fd === $site_host ) { $F[] = 'Your domain ' . $fd . ' has no SPF record. Gmail/Outlook often spam or reject mail without it. Add an SPF TXT record (your host or SMTP provider gives the value).'; }
    } else { $L[] = 'DNS lookup unavailable on this server.'; }

    if ( $s['enabled'] && $s['host'] && function_exists( 'fsockopen' ) ) {
        $L[] = ''; $L[] = '== SMTP CONNECTION ==';
        $t = microtime( true ); $en = 0; $es = '';
        $h = ( $s['encryption'] === 'ssl' ? 'ssl://' : '' ) . $s['host'];
        $fp = @fsockopen( $h, $s['port'], $en, $es, 6 );
        if ( $fp ) { $L[] = 'Connected to ' . $s['host'] . ':' . $s['port'] . ' in ' . round( ( microtime( true ) - $t ) * 1000 ) . ' ms'; fclose( $fp ); }
        else { $L[] = 'CANNOT connect to ' . $s['host'] . ':' . $s['port'] . ' — ' . $es . ' (' . $en . ')'; $F[] = 'This server cannot reach ' . $s['host'] . ':' . $s['port'] . ' (' . $es . '). The host firewall blocks outgoing SMTP. Ask the host to open it, or use port 465/2525 or an API-based mail service.'; }
    }

    // One real test send with captured transcript.
    $L[] = ''; $L[] = '== LIVE TEST SEND to ' . $to . ' ==';
    $log = array();
    $cap = function( $pm ) use ( &$log ) {
        $pm->SMTPDebug = 2;
        $pm->Debugoutput = function( $m ) use ( &$log ) { $log[] = trim( (string) $m ); };
    };
    add_action( 'phpmailer_init', $cap, 9999 );
    $sent = false; $t = microtime( true );
    try { $sent = nri_mail( $to, '[Diagnostics] ' . get_bloginfo( 'name' ), '<p>Email diagnostics test sent ' . esc_html( current_time( 'mysql' ) ) . '.</p>' ); }
    catch ( Throwable $e ) { $L[] = 'Exception: ' . $e->getMessage(); }
    remove_action( 'phpmailer_init', $cap, 9999 );
    global $phpmailer;
    $L[] = 'wp_mail() returned: ' . ( $sent ? 'TRUE (accepted for delivery)' : 'FALSE' ) . ' in ' . round( microtime( true ) - $t, 2 ) . 's';
    if ( is_object( $phpmailer ) ) { $L[] = 'Mailer: ' . $phpmailer->Mailer . ' | From used: ' . $phpmailer->From . ' | Sender (envelope): ' . ( $phpmailer->Sender ?: '-' ); }
    if ( ! $sent ) {
        $err = isset( $GLOBALS['nri_last_mail_error'] ) ? $GLOBALS['nri_last_mail_error'] : ( is_object( $phpmailer ) ? $phpmailer->ErrorInfo : '' );
        $L[] = 'ERROR: ' . $err;
        $F[] = 'Test send FAILED: ' . $err;
    } else {
        $F[] = 'wp_mail accepted the test message. If it still does not arrive in ' . $to . ' (check spam), the server handed it over but it is dropped after that — fix the From/SPF items above or use SMTP.';
    }
    foreach ( array_slice( $log, -40 ) as $line ) {
        $line = preg_replace( '/^(\S*\s*CLIENT -> SERVER:\s*)[A-Za-z0-9+\/=]{12,}$/', '$1[masked]', $line );
        $L[] = '  ' . $line;
    }

    nri_log( 'Email diagnostics run. Findings: ' . count( $F ) );
    wp_send_json_success( array( 'report' => implode( "\n", $L ), 'findings' => $F ) );
}

nri_log( 'SMTP module loaded' );
