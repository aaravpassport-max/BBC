<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nri_register_roles() {
    if (!get_role('nri_client'))  add_role('nri_client',  'NRI Client',  array('read'=>true));
    if (!get_role('nri_manager')) add_role('nri_manager', 'NRI Manager', array('read'=>true));
    if (!get_role('nri_vendor'))  add_role('nri_vendor',  'NRI Vendor',  array('read'=>true));
    if (!get_role('nri_admin'))   add_role('nri_admin',   'NRI Admin',   array('read'=>true));
    $all = array('read','nri_view_all','nri_edit_all','nri_manage_settings','nri_view_own','nri_submit','nri_message','nri_upload');
    foreach (array('administrator','nri_admin') as $rn) { $r=get_role($rn); if ($r) foreach($all as $c) $r->add_cap($c); }
    $r=get_role('nri_manager'); if($r) foreach(array('read','nri_view_all','nri_edit_all','nri_message','nri_upload') as $c) $r->add_cap($c);
    $r=get_role('nri_client');  if($r) foreach(array('read','nri_view_own','nri_submit','nri_message','nri_upload') as $c) $r->add_cap($c);
}
add_action('init','nri_register_roles');

/* ══════════════════════════════════════════════════════════════════════
   CLIENT wp-admin LOCKOUT
   Clients must never see or reach any WordPress backend screen, the black
   admin toolbar, or wp-login.php's own UI. Everything below is gated
   through nri_user_is_locked_out_client() — DEFAULT-DENY: only a small,
   explicit allowlist of trusted capabilities exempts an account; every
   other logged-in user is locked out, whatever role they hold.
   ══════════════════════════════════════════════════════════════════════ */

// TRACE: called by every gate below (admin_init redirect, show_admin_bar
//        filter, wp-login.php guard) → decides whether THIS request's
//        current user should be locked out of wp-admin → DEFAULT-DENY:
//        only manage_options (administrators), nri_view_all/nri_edit_all
//        (nri_admin, nri_manager — see nri_register_roles() above), or
//        nri_manage_settings exempts an account; every other logged-in
//        user is locked out, regardless of which WordPress role they hold
//        → precondition: none, safe to call whether or not anyone is
//        logged in → postcondition: pure read, no state changed → edge
//        case handled: an EARLIER version of this function checked only
//        "does this account hold the nri_client capability" — an
//        allowlist that missed any client account that was, for whatever
//        reason, never actually assigned the nri_client role (e.g.
//        created directly in wp-admin with the built-in "Editor" role,
//        which is exactly what a live report showed: a client account
//        with no nri_client capability at all, still seeing the black
//        toolbar with "Edit Page"/"Edit with Elementor" links, because
//        that allowlist simply never matched it). Flipping to
//        default-deny closes that gap for good: it no longer matters
//        what role an account carries — only an explicit trusted
//        capability opts it out of the lockout, so a client can never
//        slip through by having the "wrong" (or no) role at all.
function nri_user_is_locked_out_client() {
    if ( ! is_user_logged_in() ) { return false; }
    $trusted_caps = array( 'manage_options', 'nri_view_all', 'nri_edit_all', 'nri_manage_settings' );
    foreach ( $trusted_caps as $cap ) {
        if ( current_user_can( $cap ) ) { return false; }
    }
    return true;
}

// Every /wp-admin/*.php request (including admin-ajax.php and
// admin-post.php) fires 'admin_init' — so this is the single choke point
// that blocks the dashboard, plugins, themes, users, settings, update
// notices, profile.php, everything. wp_doing_ajax() is exempted because
// the client dashboard's OWN SPA (nri-app.js) submits every action through
// admin-ajax.php — without this exemption, clients would lose their whole
// dashboard, not just wp-admin. wp_doing_cron() is exempted for the same
// class of reason (scheduled jobs run as whatever user context triggered
// them, never a real client action) — belt-and-braces, cron requests
// aren't normally authenticated as a specific user anyway.
add_action( 'admin_init', 'nri_client_redirect' );
function nri_client_redirect() {
    if ( wp_doing_ajax() || ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) ) { return; }
    if ( nri_user_is_locked_out_client() ) {
        wp_safe_redirect( home_url( '/client-dashboard' ) );
        exit;
    }
}

// Hides the black admin toolbar on every FRONTEND page for client
// accounts. (wp-admin itself is unreachable for them anyway — see above —
// so this only ever matters on the frontend.) Deliberately overrides
// whatever the user's own "Show Toolbar" profile setting says, since a
// client should never be offered that choice in the first place.
add_filter( 'show_admin_bar', 'nri_hide_admin_bar_for_clients' );
function nri_hide_admin_bar_for_clients( $show ) {
    return nri_user_is_locked_out_client() ? false : $show;
}

// A client who is ALREADY logged in and manually opens wp-login.php would
// otherwise see WordPress's own "You are already logged in as X. <a>Log
// Out</a>" screen, which links straight back into wp-admin — one of the
// loopholes called out explicitly. Send them to their own dashboard
// instead, but never touch an actual logout request (action=logout must
// keep working) or the handful of auth actions WordPress itself needs to
// complete (postpass, rp/resetpass, etc. — none of these apply to a
// client who is already logged in, but excluding them here is cheap
// insurance against ever interrupting a real WordPress auth flow).
add_action( 'login_init', 'nri_block_wp_login_for_clients' );
function nri_block_wp_login_for_clients() {
    $action = isset( $_REQUEST['action'] ) ? sanitize_text_field( $_REQUEST['action'] ) : 'login';
    if ( in_array( $action, array( 'logout', 'postpass', 'rp', 'resetpass', 'confirmaction' ), true ) ) { return; }
    if ( nri_user_is_locked_out_client() ) {
        wp_safe_redirect( home_url( '/client-dashboard' ) );
        exit;
    }
}

add_filter('login_redirect','nri_login_redirect',10,3);
function nri_login_redirect($to,$req,$user) {
    if (is_wp_error($user)) return $to;
    $r=(array)$user->roles;
    if (in_array('nri_client',$r)&&!in_array('administrator',$r)) return home_url('/client-dashboard');
    if (array_intersect(array('nri_admin','nri_manager','administrator'),$r)) return home_url('/admin-dashboard');
    return $to;
}
