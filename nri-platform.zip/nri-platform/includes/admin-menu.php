<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action('admin_menu','nri_admin_menu');
function nri_admin_menu() {
    add_menu_page('NRI Platform','NRI Platform','read','nri-platform','nri_admin_overview_page','dashicons-groups',30);
}
function nri_admin_overview_page() {
    echo '<div class="wrap"><h1>NRI Platform</h1><p><a href="'.esc_url(home_url('/admin-dashboard')).'" target="_blank">Open Frontend Dashboard</a></p></div>';
}
function nri_create_pages() {
    foreach (array(
        array('NRI Login','nri-login','[nri_login_form]'),
        array('Request Submit','request-submit','[nri_request_form]'),
        array('Client Dashboard','client-dashboard','[nri_client_dashboard]'),
        array('Request','request','[nri_request_view]'),
        array('Admin Dashboard','admin-dashboard','[nri_admin_dashboard]'),
        array('Services','services','[nri_services]'),
    ) as $p) {
        if (!get_page_by_path($p[1])) {
            wp_insert_post(array('post_title'=>$p[0],'post_name'=>$p[1],'post_content'=>$p[2],'post_status'=>'publish','post_type'=>'page','post_author'=>1));
        }
    }
}
add_action('init','nri_rewrite_rules');
function nri_rewrite_rules() {
    $pg=get_page_by_path('request');
    if ($pg) add_rewrite_rule('^request/([0-9]+)/?$','index.php?page_id='.$pg->ID.'&nri_request_id=$matches[1]','top');
    if (get_option('nri_flush_needed')) { flush_rewrite_rules(); delete_option('nri_flush_needed'); }
}
add_filter('query_vars','nri_query_vars');
function nri_query_vars($v) { $v[]='nri_request_id'; return $v; }
