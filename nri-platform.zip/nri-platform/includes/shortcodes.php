<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   HELPERS
   ============================================================ */

function nri_auth_gate() {
    if ( ! is_user_logged_in() ) {
        return '<div style="padding:40px;text-align:center;"><p>Please <a href="' . esc_url( home_url( '/nri-login' ) ) . '">log in</a> to continue.</p></div>';
    }
    return '';
}

function nri_get_dashboard_url() {
    if ( ! is_user_logged_in() ) { return home_url( '/nri-login' ); }
    $roles = (array) wp_get_current_user()->roles;
    return ( in_array( 'nri_client', $roles ) && ! in_array( 'administrator', $roles ) )
        ? home_url( '/client-dashboard' )
        : home_url( '/admin-dashboard' );
}

/* Returns a sticky nav bar for client pages */
function nri_get_platform_name() {
    return get_option( 'nri_platform_name', get_bloginfo( 'name' ) );
}

function nri_client_nav( $active = '' ) {
    $platform = nri_get_platform_name();
    $links = array(
        'dashboard' => array( home_url( '/client-dashboard' ), '&#128203; Dashboard' ),
        'new'       => array( home_url( '/request-submit' ),   '&#43; New Request' ),
        'profile'   => array( home_url( '/client-dashboard?tab=profile' ), '&#128100; Profile' ),
        'logout'    => array( wp_logout_url( home_url() ), '&#8594; Logout' ),
    );
    /* Inline nav - sits above the dashboard content, not fixed to viewport */
    $o  = '<nav class="nri-inline-nav nri-portal-nav">';
    $o .= '<div class="nri-inline-nav-brand nri-portal-brand"><a href="' . esc_url( home_url( '/client-dashboard' ) ) . '"><span class="nri-portal-brand-mark" aria-hidden="true">&#9673;</span>' . esc_html( $platform ) . '</a></div>';
    $o .= '<div class="nri-inline-nav-links">';
    foreach ( $links as $key => $l ) {
        $ac = ( $active === $key ) ? 'nri-nav-active active' : '';
        if ( $key === 'new' || $key === 'logout' ) {
            // Real navigation, not a tab — "New Request" goes to a
            // separate multi-step submission flow and "Logout" is a
            // nonce-bearing WP link, neither should be AJAX-intercepted.
            $o .= '<a class="nri-nav-link' . ( $key === 'new' ? ' nri-nav-link-cta' : '' ) . ' ' . $ac . '" href="' . esc_url( $l[0] ) . '">' . $l[1] . '</a>';
        } else {
            // Dashboard / Profile — real tabs. nri-nav-item + data-tab let
            // the shared SPA controller (see detectSurface() in
            // nri-app.js) intercept the click and swap content in place.
            $o .= '<a class="nri-nav-link nri-nav-item ' . $ac . '" data-tab="' . esc_attr( $key ) . '" href="' . esc_url( $l[0] ) . '">' . $l[1] . '</a>';
        }
    }
    $o .= '</div></nav>';
    return $o;
}

/* ============================================================
   SHORTCODE: LOGIN BUTTON
   ============================================================ */

add_shortcode( 'nri_login_button', 'nri_sc_login_button' );
function nri_sc_login_button( $atts ) {
    $a = shortcode_atts( array( 'label' => 'Client Login', 'class' => '' ), $atts );
    if ( is_user_logged_in() ) {
        $u = wp_get_current_user();
        return '<a href="' . esc_url( nri_get_dashboard_url() ) . '" class="nri-btn nri-btn-primary">' . esc_html( $u->display_name ) . ' &rarr;</a>';
    }
    return '<a href="' . esc_url( home_url( '/nri-login' ) ) . '" class="nri-btn nri-btn-primary ' . esc_attr( $a['class'] ) . '">' . esc_html( $a['label'] ) . '</a>';
}

add_shortcode( 'nri_admin_login_button', 'nri_sc_admin_login_button' );
function nri_sc_admin_login_button( $atts ) {
    $a   = shortcode_atts( array( 'label' => 'Staff Login' ), $atts );
    $url = is_user_logged_in() ? home_url( '/admin-dashboard' ) : home_url( '/nri-login' );
    return '<a href="' . esc_url( $url ) . '" class="nri-btn nri-btn-secondary">' . esc_html( $a['label'] ) . '</a>';
}

/* ============================================================
   SHORTCODE: LOGIN FORM
   ============================================================ */

add_shortcode( 'nri_login_form', 'nri_sc_login_form' );
function nri_sc_login_form( $atts ) {
    $a = shortcode_atts( array( 'title' => 'Client Login' ), $atts );
    if ( is_user_logged_in() ) {
        $u  = wp_get_current_user();
        $o  = '<div class="nri-login-wrap"><div class="nri-login-card nri-text-center">';
        $o .= '<p>Logged in as <strong>' . esc_html( $u->display_name ) . '</strong></p>';
        $o .= '<a href="' . esc_url( nri_get_dashboard_url() ) . '" class="nri-btn nri-btn-primary">Go to Dashboard</a>';
        $o .= ' <a href="' . esc_url( wp_logout_url( home_url() ) ) . '" class="nri-btn nri-btn-ghost">Logout</a>';
        $o .= '</div></div>';
        return $o;
    }
    $n  = wp_create_nonce( 'nri_login_nonce' );
    $mn = wp_create_nonce( 'nri_frontend_nonce' );
    $o  = '<div class="nri-login-wrap"><div class="nri-login-card">';
    $o .= '<div class="nri-login-logo"><div class="nri-login-brand">' . esc_html( $a['title'] ) . '</div></div>';
    $o .= '<div class="nri-login-tabs"><button class="nri-lt active" data-lt="pw">Password Login</button><button class="nri-lt" data-lt="magic">Magic Link</button></div>';
    $o .= '<div id="nri-lt-pw" class="nri-lt-pane active"><form id="nri-login-form">';
    $o .= '<input type="hidden" name="nonce" value="' . esc_attr( $n ) . '">';
    $o .= '<div class="nri-field"><label>Email</label><input type="email" name="email" placeholder="you@example.com" required autocomplete="email"></div>';
    $o .= '<div class="nri-field"><label>Password</label><div class="nri-pw-wrap"><input type="password" name="password" placeholder="Password" required autocomplete="current-password"><button type="button" class="nri-pw-toggle">Show</button></div></div>';
    $o .= '<div id="nri-login-err" class="nri-alert nri-alert-error" style="display:none;"></div>';
    $o .= '<button type="submit" class="nri-btn nri-btn-primary nri-w100"><span class="nri-bt">Login</span><span class="nri-bl" style="display:none;">Logging in...</span></button>';
    $o .= '</form></div>';
    $o .= '<div id="nri-lt-magic" class="nri-lt-pane"><p class="nri-hint">Enter your email - we will send a login link.</p>';
    $o .= '<form id="nri-magic-form"><input type="hidden" name="nonce" value="' . esc_attr( $mn ) . '">';
    $o .= '<div class="nri-field"><label>Email</label><input type="email" name="email" placeholder="you@example.com" required></div>';
    $o .= '<div id="nri-magic-msg" class="nri-alert" style="display:none;"></div>';
    $o .= '<button type="submit" class="nri-btn nri-btn-primary nri-w100">Send Login Link</button>';
    $o .= '</form></div>';
    $o .= '<div class="nri-login-footer"><a href="' . esc_url( home_url( '/request-submit' ) ) . '">New client? Start a request &rarr;</a></div>';
    $o .= '</div></div>';
    return $o;
}

/* ============================================================
   SHORTCODE: MULTI-STEP REQUEST FORM
   ============================================================ */

add_shortcode( 'nri_request_form', 'nri_sc_request_form' );
function nri_sc_request_form( $atts ) {
    $fields = nri_get_fields();
    $steps  = array( 1 => 'Service Details', 2 => 'Academic Info', 3 => 'Your Details', 4 => 'Documents' );
    $step_sub = array( 1 => 'Tell us which service you need.', 2 => 'A few academic details so we can match your request.', 3 => 'How we can reach you.', 4 => 'Upload your documents and submit.' );
    $nonce  = wp_create_nonce( 'nri_frontend_nonce' );

    $o  = nri_client_nav( 'new' );
    $o .= '<div class="nri-page-wrap">';
    $o .= '<div class="nri-form-page"><div class="nri-form-hero"><span class="nri-hero-eyebrow"><i class="nri-hero-dot"></i>New request</span><h1>Submit a <em>New Request</em></h1><p>Complete all steps below. We will review and respond within 24 hours.</p>';
    $o .= '<ul class="nri-trust-row"><li><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>Reply within 24 hours</li><li><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>Secure &amp; private</li><li><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12l4 4L19 7"/></svg>' . count( $steps ) . ' quick steps</li></ul></div>';
    $o .= '<div class="nri-wizard-wrap"><div class="nri-progress-track" aria-hidden="true"><span class="nri-progress-fill"></span></div><div class="nri-steps-bar">';
    foreach ( $steps as $sn => $sl ) {
        $o .= '<div class="nri-step ' . ( $sn === 1 ? 'nri-step-active' : '' ) . '" data-step="' . intval( $sn ) . '">';
        $o .= '<div class="nri-step-dot"><span>' . intval( $sn ) . '</span></div>';
        $o .= '<div class="nri-step-label">' . esc_html( $sl ) . '</div></div>';
        if ( $sn < count( $steps ) ) { $o .= '<div class="nri-step-line"></div>'; }
    }
    $o .= '</div>';
    $o .= '<form id="nri-request-form" class="nri-wizard-form" novalidate>';
    $o .= '<input type="hidden" name="nonce" value="' . esc_attr( $nonce ) . '">';
    foreach ( $steps as $step_n => $step_label ) {
        $display = ( $step_n !== 1 ) ? 'style="display:none;"' : '';
        $o .= '<div class="nri-wizard-step" data-step="' . intval( $step_n ) . '" ' . $display . '>';
        $o .= '<div class="nri-step-head"><span class="nri-step-kicker">Step ' . intval( $step_n ) . ' of ' . count( $steps ) . '</span><h3 class="nri-step-title">' . esc_html( $step_label ) . '</h3>';
        if ( isset( $step_sub[ $step_n ] ) ) { $o .= '<p class="nri-step-sub">' . esc_html( $step_sub[ $step_n ] ) . '</p>'; }
        $o .= '</div><div class="nri-step-fields">';
        foreach ( $fields as $field ) {
            if ( (int) $field->step_number !== $step_n ) { continue; }
            $o .= nri_render_form_field( $field );
        }
        if ( $step_n === 3 ) {
            $o .= '<div class="nri-field nri-field-full nri-ft-email"><label>Email Address <span class="nri-req">*</span></label>';
            $o .= '<input type="email" name="client_email" placeholder="your@email.com" autocomplete="email" inputmode="email">';
            $o .= '<p class="nri-hint-sm">Used to create or find your account.</p></div>';
        }
        $o .= '</div><div class="nri-step-nav">';
        if ( $step_n > 1 ) { $o .= '<button type="button" class="nri-btn nri-btn-ghost nri-wizard-prev" data-step="' . intval( $step_n ) . '">&larr; Back</button>'; }
        if ( $step_n < count( $steps ) ) {
            $o .= '<button type="button" class="nri-btn nri-btn-primary nri-wizard-next" data-step="' . intval( $step_n ) . '">Next &rarr;</button>';
        } else {
            $o .= '<button type="submit" class="nri-btn nri-btn-primary nri-cta"><span class="nri-bt">Submit Request <svg class="nri-cta-ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span><span class="nri-bl" style="display:none;">Submitting...</span></button>';
        }
        $o .= '</div></div>';
    }
    $o .= '<div id="nri-form-err" class="nri-alert nri-alert-error" style="display:none;margin-top:12px;"></div>';
    $o .= '</form></div><p class="nri-form-foot"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>Secure submission &middot; You will get a confirmation email</p></div></div>';
    return $o;
}

function nri_render_form_field( $field ) {
    $opts     = $field->field_options ? array_filter( array_map( 'trim', explode( ',', $field->field_options ) ) ) : array();
    $db_opts  = ( $field->field_type === 'dropdown' || $field->field_type === 'searchable' ) ? nri_get_dropdown_options( $field->field_key ) : array();
    $all_opts = array_unique( array_merge( $opts, $db_opts ) );
    $req      = ''; // Validation done via JS using .nri-req star — no HTML required attr
    $rstar    = $field->is_required ? '<span class="nri-req" title="Required">*</span>' : '<span class="nri-opt">Optional</span>';
    $ph       = esc_attr( $field->placeholder ? $field->placeholder : $field->field_label );
    $fname    = 'field_' . esc_attr( $field->field_key );
    $label    = esc_html( $field->field_label );
    $o        = '';

    // Conditional logic wrapper attributes
    $cond_attr = '';
    $cond_style = '';
    $cond_data = isset($field->conditions) && $field->conditions ? json_decode($field->conditions, true) : null;
    $has_cond = !empty($cond_data) && !empty($cond_data['rules']);
    if ($has_cond) {
        $cond_attr = ' data-nri-cond="' . esc_attr(wp_json_encode($cond_data)) . '" data-nri-field-key="' . esc_attr($field->field_key) . '"';
        $cond_style = ' style="display:none;"'; // hidden by default when conditions set; JS will show if matched
    }

    if ( $field->field_type === 'radio' ) {
        $o .= '<div class="nri-field nri-field-full nri-cond-field"' . $cond_attr . $cond_style . '><label>' . $label . ' ' . $rstar . '</label><div class="nri-radio-group">';
        foreach ( $opts as $opt ) {
            $o .= '<label class="nri-radio-opt"><input type="radio" name="' . $fname . '" value="' . esc_attr( $opt ) . '" ' . $req . '><span>' . esc_html( $opt ) . '</span></label>';
        }
        $o .= '</div></div>';
    } elseif ( $field->field_type === 'dropdown' ) {
        $o .= '<div class="nri-field nri-cond-field"' . $cond_attr . $cond_style . '><label>' . $label . ' ' . $rstar . '</label><select name="' . $fname . '" ' . $req . '><option value="">- Select -</option>';
        foreach ( $all_opts as $opt ) { $o .= '<option value="' . esc_attr( $opt ) . '">' . esc_html( $opt ) . '</option>'; }
        $o .= '</select></div>';
    } elseif ( $field->field_type === 'searchable' ) {
        $o .= '<div class="nri-field nri-cond-field"' . $cond_attr . $cond_style . '><label>' . $label . ' ' . $rstar . '</label>';
        $o .= '<div class="nri-search-field" data-key="' . esc_attr( $field->field_key ) . '">';
        $o .= '<input type="text" class="nri-sf-input" placeholder="' . $ph . '" autocomplete="off" data-field="' . esc_attr( $field->field_key ) . '">';
        $o .= '<input type="hidden" name="' . $fname . '" class="nri-sf-val" ' . $req . '>';
        $o .= '<div class="nri-sf-dropdown" style="display:none;"></div></div></div>';
    } elseif ( $field->field_type === 'textarea' ) {
        $o .= '<div class="nri-field nri-field-full nri-cond-field"' . $cond_attr . $cond_style . '><label>' . $label . ' ' . $rstar . '</label><textarea name="' . $fname . '" placeholder="' . $ph . '" rows="4" ' . $req . '></textarea></div>';
    } elseif ( $field->field_type === 'phone' ) {
        $o .= '<div class="nri-field nri-field-full nri-cond-field"' . $cond_attr . $cond_style . '><label>' . $label . ' ' . $rstar . '</label>';
        $o .= '<div class="nri-phone-wrap" style="display:flex;gap:8px;width:100%;">';
        $o .= '<select name="field_phone_code" class="nri-phone-code" style="flex:0 0 auto;width:110px;">';
        $codes = array( '+91' => 'IN +91', '+1' => 'US +1', '+44' => 'UK +44', '+61' => 'AU +61', '+971' => 'UAE +971', '+65' => 'SG +65', '+60' => 'MY +60', '+49' => 'DE +49' );
        foreach ( $codes as $code => $text ) { $o .= '<option value="' . esc_attr( $code ) . '">' . esc_html( $text ) . '</option>'; }
        $o .= '</select>';
        $o .= '<input type="tel" name="' . $fname . '" placeholder="Mobile number" ' . $req . ' pattern="[0-9]{6,15}" style="flex:1;min-width:0;width:100%;">';
        $o .= '</div></div>';
    } elseif ( $field->field_type === 'file' ) {
        $o .= '<div class="nri-field nri-field-full nri-cond-field"' . $cond_attr . $cond_style . '><label>' . $label . ' ' . $rstar . '</label>';
        $o .= '<div class="nri-dropzone" id="nri-file-drop">';
        $o .= '<input type="file" name="' . $fname . '[]" multiple accept=".pdf,.jpg,.jpeg,.png" id="nri-file-input" style="display:none">';
        $o .= '<div class="nri-dz-inner"><div class="nri-dz-icon">&#128206;</div>';
        $o .= '<p>Drop files here or <button type="button" class="nri-link" onclick="document.getElementById(\'nri-file-input\').click()">browse</button></p>';
        $o .= '<p class="nri-hint-sm">PDF, JPG, PNG - max 10MB each</p></div>';
        $o .= '<div id="nri-file-preview-list" class="nri-file-preview"></div></div>';
        $o .= '<div id="nri-submit-progress" class="nri-prog-bar" style="display:none;margin-top:8px;"><div class="nri-prog-fill" id="nri-submit-progress-fill"></div></div>';
        $o .= '<p id="nri-submit-progress-label" class="nri-hint-sm" style="display:none;"></p>';
        $o .= '</div>';
    } elseif ( $field->field_type === 'number' ) {
        $o .= '<div class="nri-field nri-cond-field"' . $cond_attr . $cond_style . '><label>' . $label . ' ' . $rstar . '</label><input type="number" name="' . $fname . '" placeholder="' . $ph . '" ' . $req . ' style="-moz-appearance:number-input;"></div>';
    } else {
        $type = ( $field->field_type === 'email' ) ? 'email' : 'text';
        $o .= '<div class="nri-field nri-cond-field"' . $cond_attr . $cond_style . '><label>' . $label . ' ' . $rstar . '</label><input type="' . $type . '" name="' . $fname . '" placeholder="' . $ph . '" ' . $req . '></div>';
    }
    // Visual hook: tag the wrapper with the field type so CSS can add the right icon/treatment
    $ft = preg_replace( '/[^a-z0-9_-]/', '', strtolower( (string) $field->field_type ) );
    if ( $ft !== '' ) { $o = preg_replace( '/class="nri-field /', 'class="nri-field nri-ft-' . $ft . ' ', $o, 1 ); }
    // FIX 3: Append help text/description if set
    if ( !empty($field->description) ) {
        // Inject description inside the outermost nri-field div, before closing
        $desc_html = '<p class="nri-field-desc" style="margin:4px 0 0;font-size:12px;color:#64748b;line-height:1.5;">' . esc_html($field->description) . '</p>';
        // Insert before last </div>
        $last_div = strrpos($o, '</div>');
        if ($last_div !== false) {
            $o = substr($o, 0, $last_div) . $desc_html . substr($o, $last_div);
        }
    }
    return $o;
}


/* ============================================================
   SHORTCODE: STANDALONE REQUEST FORM  [nri_standalone_form]
   Displays the multi-step form independently, with an attractive
   hero section, without any nav/dashboard wrapper.
   Use: [nri_standalone_form] on any page.
   ============================================================ */

add_shortcode( 'nri_standalone_form', 'nri_sc_standalone_form' );
function nri_sc_standalone_form( $atts ) {
    $fields = nri_get_fields();
    $steps  = array( 1 => 'Service Details', 2 => 'Academic Info', 3 => 'Your Details', 4 => 'Documents' );
    $step_sub = array( 1 => 'Tell us which service you need.', 2 => 'A few academic details so we can match your request.', 3 => 'How we can reach you.', 4 => 'Upload your documents and submit.' );
    $nonce  = wp_create_nonce( 'nri_frontend_nonce' );

    $o  = '<div class="nri-sl-outer">';
    $o .= '<div class="nri-sl-card">';

    // Card heading
    $o .= '<div class="nri-sl-card-hdr">';
    $o .= '<h3 class="nri-sl-card-title">Get Estimated Quote Instantly</h3>';
    $o .= '</div>';

    // Step progress dots
    $o .= '<div class="nri-progress-track" aria-hidden="true"><span class="nri-progress-fill"></span></div>';
    $o .= '<div class="nri-sl-steps">';
    foreach ( $steps as $sn => $sl ) {
        $active = $sn === 1 ? 'nri-sl-step-active' : '';
        $o .= '<div class="nri-sl-step ' . $active . '" data-step="' . intval($sn) . '">';
        $o .= '<div class="nri-sl-step-dot"><span>' . intval($sn) . '</span></div>';
        $o .= '<div class="nri-sl-step-lbl">' . esc_html($sl) . '</div>';
        $o .= '</div>';
        if ( $sn < count($steps) ) { $o .= '<div class="nri-sl-step-line"></div>'; }
    }
    $o .= '</div>';

    // Form
    $o .= '<form id="nri-request-form" class="nri-wizard-form nri-sl-form" novalidate>';
    $o .= '<input type="hidden" name="nonce" value="' . esc_attr($nonce) . '">';

    foreach ( $steps as $step_n => $step_label ) {
        $display = ( $step_n !== 1 ) ? 'style="display:none;"' : '';
        $o .= '<div class="nri-wizard-step nri-sl-wizard-step" data-step="' . intval($step_n) . '" ' . $display . '>';
        $o .= '<p class="nri-sl-step-heading"><strong>Step ' . intval($step_n) . ':</strong> ' . esc_html($step_label) . '</p>';
        $o .= '<div class="nri-step-fields nri-sl-fields">';
        foreach ( $fields as $field ) {
            if ( (int) $field->step_number !== $step_n ) { continue; }
            $o .= nri_render_form_field( $field );
        }
        if ( $step_n === 3 ) {
            $o .= '<div class="nri-field nri-field-full nri-ft-email"><label>Email Address <span class="nri-req">*</span></label>';
            $o .= '<input type="email" name="client_email" placeholder="your@email.com" autocomplete="email" inputmode="email">';
            $o .= '<p class="nri-field-desc">Used to create or locate your account.</p></div>';
        }
        $o .= '</div>';
        $o .= '<div class="nri-step-nav nri-sl-nav">';
        if ( $step_n > 1 ) {
            $o .= '<button type="button" class="nri-sl-btn-back nri-wizard-prev" data-step="' . intval($step_n) . '">&larr; Back</button>';
        }
        if ( $step_n < count($steps) ) {
            $o .= '<button type="button" class="nri-sl-btn-next nri-wizard-next" data-step="' . intval($step_n) . '">Next &rarr;</button>';
        } else {
            $o .= '<button type="submit" class="nri-sl-btn-submit"><span class="nri-bt">&#9889; Calculate My Quote</span><span class="nri-bl" style="display:none;">Submitting…</span></button>';
        }
        $o .= '</div>';
        $o .= '</div>';
    }
    $o .= '<div id="nri-form-err" class="nri-alert nri-alert-error" style="display:none;margin-top:10px;font-size:13px;"></div>';
    $o .= '</form>';

    $o .= '<p class="nri-sl-card-footer">&#128274; SSL Secured &nbsp;|&nbsp; &#128203; Instant Confirmation</p>';
    $o .= '</div>'; // end card
    $o .= '</div>'; // end outer

    return $o;
}

/* ============================================================
   SHORTCODE: CLIENT DASHBOARD (with profile tab)
   ============================================================ */

// TRACE: called once per request by nri_sc_client_dashboard() (not by the AJAX
//        tab-switch path — the header/sidebar shell around #nri-client-tab-container
//        is only ever rendered on the real page load, never re-sent on a tab click)
//        → counts real, ownership-checked activity: (a) every one of the client's
//        own nri_request posts (for the "Total Requests" style badge elsewhere) and
//        (b) every nri_add_history() entry logged against one of those requests in
//        the last 14 days (nri_get_history() per request, filtered by 'time')
//        → returns an int, never negative, never fabricated when there is no
//        activity (returns 0) → precondition: $uid is a real, logged-in client's ID
//        → postcondition: no DB writes, read-only → edge case handled: a request
//        with no history array (get_post_meta returns '' before nri_add_history()
//        is ever called on it) is skipped via the (array) cast in nri_get_history().
function nri_client_notification_count( $uid ) {
    $requests = get_posts( array( 'post_type' => 'nri_request', 'post_status' => 'publish', 'posts_per_page' => -1, 'author' => $uid, 'fields' => 'ids' ) );
    if ( empty( $requests ) ) { return 0; }
    $cutoff = strtotime( '-14 days' );
    $count  = 0;
    foreach ( $requests as $rid ) {
        foreach ( nri_get_history( $rid ) as $h ) {
            if ( ! empty( $h['time'] ) && strtotime( $h['time'] ) >= $cutoff ) { $count++; }
        }
    }
    return $count;
}

// Small flat-style inline illustration for the welcome banner (spec: "an
// educational/document-related illustration on the right"). Kept as a
// self-contained inline SVG — no external image asset to package/host —
// and purely decorative (aria-hidden), so it never depends on data.
function nri_client_hero_illustration() {
    return '<svg class="nri-portal-hero-illus" viewBox="0 0 220 160" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
        <circle cx="110" cy="80" r="76" fill="#eef2ff"/>
        <rect x="118" y="26" width="70" height="94" rx="10" fill="#ffffff" stroke="#c7d2fe" stroke-width="2"/>
        <rect x="130" y="42" width="46" height="6" rx="3" fill="#c7d2fe"/>
        <rect x="130" y="56" width="46" height="6" rx="3" fill="#e0e7ff"/>
        <rect x="130" y="70" width="30" height="6" rx="3" fill="#e0e7ff"/>
        <path d="M148 30 l10 -12 10 12z" fill="#4f46e5"/>
        <rect x="20" y="70" width="70" height="56" rx="8" fill="#4f46e5"/>
        <rect x="28" y="78" width="54" height="34" rx="3" fill="#eef2ff"/>
        <circle cx="55" cy="60" r="16" fill="#fbbf5b"/>
        <path d="M39 108c0-10 8-18 16-18s16 8 16 18" fill="#1e293b"/>
        <path d="M20 140c6-14 20-22 35-22s29 8 35 22" fill="#c7d2fe"/>
        </svg>';
}

// TRACE: called once by nri_sc_client_dashboard() → renders the top portal header
//        (brand mark, activity/notification bell with a live count, avatar initial,
//        display name, email, a profile-dropdown affordance) → reads only, no writes
//        → precondition: $user is the logged-in WP_User → postcondition: static
//        markup string; the dropdown's open/close is pure CSS (:focus-within), so no
//        JS wiring is required or broken by adding this → edge case handled: a blank
//        display_name falls back to the email's local part so the initial/name never
//        render empty.
function nri_client_portal_header( $user, $notif_count ) {
    $platform = nri_get_platform_name();
    $name     = $user->display_name ? $user->display_name : strstr( $user->user_email, '@', true );
    $initial  = strtoupper( substr( $name, 0, 1 ) );
    $o  = '<header class="nri-portal-topbar">';
    $o .= '<div class="nri-portal-topbar-brand"><a href="' . esc_url( home_url( '/client-dashboard' ) ) . '"><span class="nri-portal-brand-mark" aria-hidden="true">&#127891;</span>' . esc_html( $platform ) . '</a></div>';
    $o .= '<div class="nri-portal-topbar-right">';
    $o .= '<a href="' . esc_url( home_url( '/client-dashboard#nri-updates-section' ) ) . '" class="nri-portal-bell" aria-label="Recent updates">&#128276;';
    if ( $notif_count > 0 ) { $o .= '<span class="nri-portal-bell-badge">' . intval( $notif_count ) . '</span>'; }
    $o .= '</a>';
    $o .= '<div class="nri-portal-userbox">';
    $o .= '<div class="nri-portal-userbox-avatar">' . esc_html( $initial ) . '</div>';
    $o .= '<div class="nri-portal-userbox-text"><span class="nri-portal-userbox-name">' . esc_html( $name ) . '</span><span class="nri-portal-userbox-email">' . esc_html( $user->user_email ) . '</span></div>';
    $o .= '<div class="nri-portal-userbox-caret">&#9662;</div>';
    $o .= '<div class="nri-portal-userbox-menu">';
    $o .= '<a href="' . esc_url( home_url( '/client-dashboard?tab=profile' ) ) . '" class="nri-nav-item" data-tab="profile">&#128100; My Profile</a>';
    $o .= '<a href="' . esc_url( wp_logout_url( home_url() ) ) . '">&#8594; Logout</a>';
    $o .= '</div></div></div></header>';
    return $o;
}

// TRACE: called once by nri_sc_client_dashboard() → renders the left sidebar
//        (bottom nav on mobile via CSS, not JS) → "Dashboard" and "My Profile" are
//        real SPA tabs (.nri-nav-item + data-tab, same delegation the admin
//        dashboard already uses — see detectSurface()/setActiveNav() in
//        nri-app.js); "New Application" is a real link to the existing
//        /request-submit wizard; "Other Services" reuses id="nri-nav-new-req",
//        the SAME id nri-app.js already binds the "Other Service Request" modal
//        opener to (search that file for '#nri-new-sr-btn,#nri-new-sr-btn2,
//        #nri-nav-new-req') — so this item opens the existing modal with zero
//        new JS; "My Requests", "My Documents", "Payments" and "Help & Support"
//        are plain in-page anchors to sections rendered further down the same
//        dashboard tab (see nri_render_client_tab()) → precondition: $active is
//        either 'dashboard' or 'profile' → postcondition: exactly one <a> carries
//        the "active" class, matching $active → edge case: anchors are plain
//        hrefs with no data-tab, so the SPA click-delegate (which only binds to
//        [data-tab]) never intercepts them — a normal in-page jump, no AJAX call.
function nri_client_portal_sidebar( $active ) {
    $dash_url = home_url( '/client-dashboard' );
    $items = array(
        array( 'dashboard', $dash_url, '&#127968;', 'Dashboard', true ),
        array( '',          $dash_url . '#nri-requests-section', '&#128203;', 'My Requests', false ),
        array( '',          home_url( '/request-submit' ), '&#10133;', 'New Application', false ),
        array( '',          '#', '&#128295;', 'Other Services', false ),
        array( '',          $dash_url . '#nri-documents-section', '&#128196;', 'My Documents', false ),
        array( '',          $dash_url . '#nri-payments-section', '&#128179;', 'Payments', false ),
        array( 'profile',   home_url( '/client-dashboard?tab=profile' ), '&#128100;', 'Profile', true ),
        array( '',          $dash_url . '#nri-help-section', '&#10067;', 'Help & Support', false ),
    );
    $o = '<nav class="nri-portal-sidebar" aria-label="Client portal navigation"><ul class="nri-portal-sidenav">';
    foreach ( $items as $it ) {
        list( $tab, $url, $icon, $label, $is_tab ) = $it;
        $classes = 'nri-portal-sidenav-link';
        $attrs   = '';
        if ( $is_tab ) {
            $classes .= ' nri-nav-item';
            $attrs   .= ' data-tab="' . esc_attr( $tab ) . '"';
            if ( $active === $tab ) { $classes .= ' active'; }
        } elseif ( $label === 'Other Services' ) {
            $attrs .= ' id="nri-nav-new-req"';
        }
        $o .= '<li><a href="' . esc_url( $url ) . '" class="' . esc_attr( $classes ) . '"' . $attrs . '><span class="nri-portal-sidenav-icon" aria-hidden="true">' . $icon . '</span><span class="nri-portal-sidenav-label">' . esc_html( $label ) . '</span></a></li>';
    }
    $o .= '</ul></nav>';
    return $o;
}

// TRACE: registered shortcode callback for [nri_client_dashboard], which is what
//        the /client-dashboard page (the redirect target right after a successful
//        request submission — see 'redirect' in nri_ajax_create_request()) actually
//        renders → auth-gates, then builds header + sidebar + the swappable tab
//        container → mutates nothing, pure render → precondition: none (handles
//        both logged-in and logged-out) → postcondition: always returns a STRING,
//        never throws past this function — see the try/catch below → edge case
//        handled: any exception/fatal (Throwable) anywhere in the header, sidebar,
//        or tab body is caught here so a single bad render can never take down the
//        whole page with WordPress's "critical error" screen; the real error is
//        written to nri-debug.log (see nri_log() in nri-platform.php) and the
//        client instead sees a minimal-but-working dashboard shell with a working
//        link back to their request list.
add_shortcode( 'nri_client_dashboard', 'nri_sc_client_dashboard' );
function nri_sc_client_dashboard( $atts ) {
    $gate = nri_auth_gate();
    if ( $gate ) { return $gate; }

    try {
        $tab  = sanitize_text_field( isset( $_GET['tab'] ) ? $_GET['tab'] : 'dashboard' );
        if ( $tab !== 'profile' ) { $tab = 'dashboard'; }
        $user = wp_get_current_user();
        if ( ! $user || ! $user->exists() ) {
            // Auth cookie from the just-completed submission didn't stick
            // (e.g. a race right after wp_set_auth_cookie(), or a host that
            // strips Set-Cookie on the AJAX response) — nri_auth_gate()
            // above only checks is_user_logged_in(), so this is the one
            // case it can miss. Send them to a real login rather than
            // rendering a dashboard for "nobody" (which would otherwise
            // query get_posts() with an empty author and risk showing
          // no one's — or, worse, everyone's — requests).
            return '<div style="padding:40px;text-align:center;"><p>Your session could not be verified. Please <a href="' . esc_url( home_url( '/nri-login' ) ) . '">log in</a> again — your request was already saved and is safe.</p></div>';
        }

        $o  = nri_client_portal_header( $user, nri_client_notification_count( $user->ID ) );
        $o .= '<div class="nri-portal-body nri-portal-shell">';
        $o .= nri_client_portal_sidebar( $tab === 'profile' ? 'profile' : 'dashboard' );
        // #nri-client-tab-container is what the client-side SPA controller
        // (the "Admin Dashboard SPA Controller" block in nri-app.js — it now
        // drives both dashboards, see detectSurface() there) swaps content
        // into via AJAX instead of a full page reload, exactly like
        // #nri-admin-tab-container does for staff.
        $o .= '<main id="nri-client-tab-container" class="nri-portal-main" data-current-tab="' . esc_attr( $tab ) . '">';
        $o .= nri_render_client_tab( $tab );
        $o .= '</main>';
        $o .= '</div>'; // .nri-portal-body
        return $o;
    } catch ( \Throwable $e ) {
        if ( function_exists( 'nri_log' ) ) {
            nri_log( 'nri_sc_client_dashboard fatal-guard caught: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
        }
        return '<div style="padding:40px;text-align:center;"><p>Your dashboard is temporarily unavailable. Your request has been saved — please <a href="' . esc_url( home_url( '/client-dashboard' ) ) . '">refresh this page</a>, or contact support if this keeps happening.</p></div>'
            . nri_debug_error_box( $e );
    }
}

// TEMPORARY diagnostic aid — NOT part of the normal error UX. Prints the
// caught Throwable's real message/file/line directly on the page (instead of
// only in nri-debug.log) so the exact cause can be identified in one round
// trip instead of needing server file access. Safe to remove once the
// underlying dashboard bug is confirmed fixed; it never appears unless a
// Throwable was actually caught, and it never blocks the safe fallback
// message above it from rendering.
function nri_debug_error_box( $e ) {
    return '<div style="max-width:700px;margin:20px auto 0;padding:14px 16px;background:#fff7ed;border:1px solid #fed7aa;border-radius:8px;text-align:left;font-family:monospace;font-size:12.5px;color:#7c2d12;white-space:pre-wrap;">'
        . '<strong>Debug (remove once fixed):</strong> ' . esc_html( get_class( $e ) . ': ' . $e->getMessage() ) . "\n"
        . esc_html( $e->getFile() . ':' . $e->getLine() )
        . '</div>';
}

/**
 * Renders just the INSIDE of a client-dashboard tab (no header/nav) —
 * used both by the normal page load above and by the AJAX endpoint
 * (nri_ajax_client_load_tab in ajax.php) that the SPA controller calls
 * on a tab switch, so there is one source of truth for each tab's markup.
 *
 * TRACE: thin wrapper around nri_render_client_tab_inner() → catches any
 *        Throwable from the real renderer so neither the page load above NOR
 *        the AJAX tab-switch endpoint (nri_ajax_client_load_tab in ajax.php,
 *        which calls this directly) can ever surface a fatal — the AJAX path
 *        in particular would otherwise come back as a broken/empty response
 *        that the SPA controller has no good way to recover from mid-click.
 *        → postcondition: always returns a string.
 */
function nri_render_client_tab( $tab ) {
    try {
        return nri_render_client_tab_inner( $tab );
    } catch ( \Throwable $e ) {
        if ( function_exists( 'nri_log' ) ) {
            nri_log( 'nri_render_client_tab fatal-guard caught (tab=' . $tab . '): ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
        }
        return '<div style="padding:40px;text-align:center;"><p>This section could not be loaded right now. Please <a href="' . esc_url( home_url( '/client-dashboard' ) ) . '">reload the dashboard</a>, or contact support if this keeps happening.</p></div>'
            . nri_debug_error_box( $e );
    }
}

function nri_render_client_tab_inner( $tab ) {
    $uid  = get_current_user_id();
    $user = wp_get_current_user();

    if ( $tab === 'profile' ) {
        return nri_render_profile_tab( $uid, $user );
    } else {
        $requests = get_posts( array( 'post_type' => 'nri_request', 'post_status' => 'publish', 'posts_per_page' => -1, 'author' => $uid, 'orderby' => 'date', 'order' => 'DESC' ) );
        $total = count( $requests ); $active = 0; $done = 0; $doc_count = 0;
        $all_docs = array(); // [ ['req' => WP_Post, 'meta' => [...], 'doc' => [...]], ... ] — for the Documents section below
        foreach ( $requests as $r ) {
            $s = get_post_meta( $r->ID, 'status', true );
            if ( $s === 'completed' ) { $done++; } elseif ( $s !== 'rejected' ) { $active++; }
            $docs = nri_get_documents( $r->ID );
            $doc_count += count( $docs );
            foreach ( $docs as $d ) { $all_docs[] = array( 'req' => $r, 'doc' => $d ); }
        }

        $o = '';

        /* ── Welcome hero banner ─────────────────────────────────────── */
        $o .= '<div class="nri-portal-hero nri-portal-hero-banner">';
        $o .= '<div class="nri-portal-hero-text">';
        $o .= '<h2 class="nri-portal-hero-title">Welcome back, ' . esc_html( $user->display_name ) . ' &#128075;</h2>';
        $o .= '<p class="nri-portal-hero-sub">Manage your transcript and educational document requests, check status, upload documents and stay updated.</p>';
        $o .= '<div class="nri-portal-hero-actions">';
        $o .= '<a href="' . esc_url( home_url( '/request-submit' ) ) . '" class="nri-btn nri-btn-primary">&#43; New Application Request</a>';
        $o .= '<button id="nri-new-sr-btn" class="nri-btn nri-btn-outline nri-btn-primary-outline">&#9675; Other Service Request</button>';
        $o .= '</div></div>';
        $o .= '<div class="nri-portal-hero-illus-wrap">' . nri_client_hero_illustration() . '</div>';
        $o .= '</div>';

        /* ── Stat cards (4) — every number below is computed above from the
           client's own posts/meta on THIS page load, never hardcoded ── */
        $o .= '<div class="nri-portal-stats4">';
        $o .= '<div class="nri-portal-stat4"><span class="nri-portal-stat4-icon nri-stat4-blue" aria-hidden="true">&#128203;</span><div><span class="nri-portal-stat4-label">Total Requests</span><span class="nri-portal-stat4-val">' . intval( $total ) . '</span></div></div>';
        $o .= '<div class="nri-portal-stat4"><span class="nri-portal-stat4-icon nri-stat4-amber" aria-hidden="true">&#8987;</span><div><span class="nri-portal-stat4-label">Active Requests</span><span class="nri-portal-stat4-val">' . intval( $active ) . '</span></div></div>';
        $o .= '<div class="nri-portal-stat4"><span class="nri-portal-stat4-icon nri-stat4-green" aria-hidden="true">&#9989;</span><div><span class="nri-portal-stat4-label">Completed Requests</span><span class="nri-portal-stat4-val">' . intval( $done ) . '</span></div></div>';
        $o .= '<div class="nri-portal-stat4"><span class="nri-portal-stat4-icon nri-stat4-purple" aria-hidden="true">&#128196;</span><div><span class="nri-portal-stat4-label">Documents Uploaded</span><span class="nri-portal-stat4-val">' . intval( $doc_count ) . '</span></div></div>';
        $o .= '</div>';

        /* ── Two-column: Recent Requests (left) + Quick Actions/Help (right) ── */
        $o .= '<div class="nri-portal-2col" id="nri-requests-section">';
        $o .= '<div class="nri-portal-col-main">';

        if ( empty( $requests ) ) {
            $o .= '<div class="nri-empty-state nri-portal-empty"><div class="nri-empty-icon">&#128203;</div>';
            $o .= '<h3>No requests yet</h3><p>Submit your first document retrieval request.</p>';
            $o .= '<button id="nri-new-sr-btn2" class="nri-btn nri-btn-primary nri-btn-lg">&#43; Other Service Request</button></div>';
        } else {
            $o .= '<div class="nri-portal-section-hdr"><h3 class="nri-portal-section-title">&#128203; My Recent Requests</h3><a href="#nri-requests-section" class="nri-portal-section-sub nri-portal-viewall">View all requests &#8594;</a></div>';
            $o .= '<div class="nri-portal-req-list">';
            $recent = array_slice( $requests, 0, 5 );
            foreach ( $recent as $req ) {
                $meta   = nri_get_meta( $req->ID );
                $status = $meta['status'];
                $fd     = $meta['field_data'];
                $svc    = '';
                if ( ! empty( $fd['field_service_type'] ) )  { $svc = $fd['field_service_type']; }
                elseif ( ! empty( $fd['field_document_type'] ) ) { $svc = $fd['field_document_type']; }
                else { $svc = 'Document Request'; }
                $hist = nri_get_history( $req->ID );
                $last = ! empty( $hist ) ? end( $hist ) : null;
                $day  = get_the_date( 'd', $req->ID ); $mon = get_the_date( 'M', $req->ID ); $yr = get_the_date( 'Y', $req->ID );
                // nri-view-request-link + data-rid let the SPA controller
                // (shared with the admin dashboard — see detectSurface() in
                // nri-app.js) intercept this click and open the request
                // in-place instead of a full page navigation.
                $o .= '<a href="' . esc_url( home_url( '/request/' . $req->ID ) ) . '" class="nri-req-row-link nri-view-request-link" data-rid="' . intval( $req->ID ) . '">';
                $o .= '<div class="nri-portal-req-row">';
                $o .= '<div class="nri-req-row-date"><span class="nri-req-row-day">' . esc_html( $day ) . '</span><span class="nri-req-row-mon">' . esc_html( $mon ) . '<br>' . esc_html( $yr ) . '</span></div>';
                $o .= '<div class="nri-req-row-body">';
                $o .= '<div class="nri-req-row-top"><span class="nri-req-row-num">' . esc_html( $meta['request_id'] ? $meta['request_id'] : '#' . $req->ID ) . '</span><span class="nri-status-chip nri-portal-status-dot" style="background:' . nri_status_color( $status ) . '22;color:' . nri_status_color( $status ) . ';">' . esc_html( nri_status_label( $status ) ) . '</span></div>';
                $o .= '<div class="nri-req-row-title">' . esc_html( wp_trim_words( $svc, 8, '' ) ) . '</div>';
                $o .= '<div class="nri-req-row-meta">';
                $o .= '<span>&#128196; ' . esc_html( wp_trim_words( $svc, 4, '' ) ) . '</span>';
                $o .= '<span>&#128197; Submitted On ' . esc_html( get_the_date( 'd M Y', $req->ID ) ) . '</span>';
                if ( $last ) { $o .= '<span>&#128337; Last Updated ' . esc_html( date( 'd M Y', strtotime( $last['time'] ) ) ) . '</span>'; }
                $o .= '</div></div>';
                $o .= '<div class="nri-req-row-cta"><span class="nri-btn nri-btn-outline nri-btn-sm">View Details &#8594;</span></div>';
                $o .= '</div></a>';
            }
            $o .= '</div>';
        }

        /* ── Our Services ── */
        $o .= '<div class="nri-portal-section-hdr" style="margin-top:26px;"><h3 class="nri-portal-section-title">&#128737; Our Services</h3><a href="' . esc_url( home_url( '/request-submit' ) ) . '" class="nri-portal-section-sub nri-portal-viewall">Explore All Services &#8594;</a></div>';
        $o .= '<div class="nri-portal-services-grid">';
        $services = array(
            array( '&#127891;', 'University Transcripts', 'nri-svc-blue' ),
            array( '&#128196;', 'Degree & Mark Sheets', 'nri-svc-blue' ),
            array( '&#127991;', 'Apostille & Attestation', 'nri-svc-green' ),
            array( '&#9999;',  'Name Change (Gazette)', 'nri-svc-purple' ),
            array( '&#127760;', 'Translation & Verification', 'nri-svc-purple' ),
        );
        foreach ( $services as $svc_item ) {
            $o .= '<a href="' . esc_url( home_url( '/request-submit' ) ) . '" class="nri-portal-svc-card"><span class="nri-portal-svc-icon ' . esc_attr( $svc_item[2] ) . '" aria-hidden="true">' . $svc_item[0] . '</span><span>' . esc_html( $svc_item[1] ) . '</span></a>';
        }
        $o .= '</div>';

        $o .= '</div>'; // .nri-portal-col-main

        /* ── Right column: Quick Actions + Need Help ── */
        $o .= '<div class="nri-portal-col-side">';
        $o .= '<div class="nri-portal-panel nri-portal-quick-actions">';
        $o .= '<h4 class="nri-portal-panel-title">&#9889; Quick Actions</h4>';
        $o .= '<a href="' . esc_url( home_url( '/request-submit' ) ) . '" class="nri-portal-qa-btn nri-portal-qa-primary"><span>New Application Request</span><small>Start a new transcript/document request</small><span class="nri-portal-qa-arrow" aria-hidden="true">&#8594;</span></a>';
        $o .= '<button class="nri-portal-qa-btn nri-open-support-modal"><span>Other Service Request</span><small>Attestation, verification and more</small><span class="nri-portal-qa-arrow" aria-hidden="true">&#8594;</span></button>';
        $o .= '</div>';

        $o .= '<div class="nri-portal-panel nri-portal-help-card" id="nri-help-section">';
        $o .= '<h4 class="nri-portal-panel-title">&#127911; Need Help?</h4>';
        $o .= '<p>Our support team is ready to assist you with your application, documents and any queries.</p>';
        $o .= '<button class="nri-btn nri-btn-outline nri-btn-sm nri-open-support-modal">Contact Support &#8594;</button>';
        $o .= '</div>';

        $o .= '<div class="nri-portal-panel nri-portal-track-card">';
        $o .= '<h4 class="nri-portal-panel-title">&#127919; Track Your Request Easily</h4>';
        $o .= '<p>Stay updated at every stage, from verification to final delivery.</p>';
        $o .= '<a href="#nri-requests-section" class="nri-portal-track-link">View my requests &#8594;</a>';
        $o .= '</div>';
        $o .= '</div>'; // .nri-portal-col-side

        $o .= '</div>'; // .nri-portal-2col

        /* ── My Documents (sidebar anchor target) ── */
        $o .= '<div class="nri-portal-section-hdr" id="nri-documents-section" style="margin-top:8px;"><h3 class="nri-portal-section-title">&#128196; My Documents</h3><span class="nri-portal-section-sub">' . intval( $doc_count ) . ' uploaded</span></div>';
        if ( empty( $all_docs ) ) {
            $o .= '<p class="nri-hint-sm" style="margin:0 0 20px;">No documents uploaded yet.</p>';
        } else {
            $o .= '<div class="nri-portal-doc-list">';
            foreach ( array_slice( $all_docs, 0, 8 ) as $row ) {
                $rid_label = get_post_meta( $row['req']->ID, 'request_id', true );
                $fname = get_the_title( $row['doc']['file'] );
                $o .= '<a href="' . esc_url( home_url( '/request/' . $row['req']->ID ) ) . '" class="nri-portal-doc-row nri-view-request-link" data-rid="' . intval( $row['req']->ID ) . '">';
                $o .= '<span class="nri-portal-doc-icon" aria-hidden="true">&#128196;</span><span class="nri-portal-doc-name">' . esc_html( $fname ? $fname : 'Document' ) . '</span><span class="nri-portal-doc-req">' . esc_html( $rid_label ? $rid_label : '#' . $row['req']->ID ) . '</span>';
                $o .= '</a>';
            }
            $o .= '</div>';
        }

        /* ── Payments (sidebar anchor target) ── */
        $o .= '<div class="nri-portal-section-hdr" id="nri-payments-section" style="margin-top:8px;"><h3 class="nri-portal-section-title">&#128179; Payments</h3></div>';
        $with_quote = array_filter( $requests, function( $r ) { return (bool) get_post_meta( $r->ID, 'quote_amount', true ); } );
        if ( empty( $with_quote ) ) {
            $o .= '<p class="nri-hint-sm" style="margin:0 0 20px;">No payments or quotations yet.</p>';
        } else {
            $o .= '<div class="nri-portal-doc-list">';
            foreach ( $with_quote as $req ) {
                $meta = nri_get_meta( $req->ID );
                $pay_label = $meta['payment_status'] === 'paid' ? 'Paid' : ucfirst( $meta['payment_status'] );
                $pay_color = $meta['payment_status'] === 'paid' ? '#10b981' : '#f59e0b';
                $o .= '<a href="' . esc_url( home_url( '/request/' . $req->ID ) ) . '" class="nri-portal-doc-row nri-view-request-link" data-rid="' . intval( $req->ID ) . '">';
                $o .= '<span class="nri-portal-doc-icon" aria-hidden="true">&#128179;</span><span class="nri-portal-doc-name">' . esc_html( $meta['request_id'] ? $meta['request_id'] : '#' . $req->ID ) . ' &mdash; &#8377;' . esc_html( number_format_i18n( (float) $meta['quote_amount'] ) ) . '</span>';
                $o .= '<span class="nri-status-chip" style="background:' . $pay_color . '22;color:' . $pay_color . ';">' . esc_html( $pay_label ) . '</span>';
                $o .= '</a>';
            }
            $o .= '</div>';
        }

        /* ── Recent activity (bell icon target) ── */
        $o .= '<div class="nri-portal-section-hdr" id="nri-updates-section" style="margin-top:8px;"><h3 class="nri-portal-section-title">&#128276; Recent Updates</h3></div>';
        $recent_events = array();
        foreach ( $requests as $r ) {
            foreach ( nri_get_history( $r->ID ) as $h ) { $h['req'] = $r; $recent_events[] = $h; }
        }
        // Plain > / < comparison rather than the <=> spaceship operator —
        // functionally identical here, kept portable in case this runs on
        // an older PHP build where <=> isn't available.
        usort( $recent_events, function( $a, $b ) {
            $ta = ! empty( $a['time'] ) ? strtotime( $a['time'] ) : 0;
            $tb = ! empty( $b['time'] ) ? strtotime( $b['time'] ) : 0;
            if ( $ta === $tb ) { return 0; }
            return ( $ta < $tb ) ? 1 : -1;
        } );
        if ( empty( $recent_events ) ) {
            $o .= '<p class="nri-hint-sm" style="margin:0 0 20px;">No recent activity.</p>';
        } else {
            $o .= '<div class="nri-portal-doc-list">';
            foreach ( array_slice( $recent_events, 0, 6 ) as $ev ) {
                $rid_label = get_post_meta( $ev['req']->ID, 'request_id', true );
                $o .= '<a href="' . esc_url( home_url( '/request/' . $ev['req']->ID ) ) . '" class="nri-portal-doc-row nri-view-request-link" data-rid="' . intval( $ev['req']->ID ) . '">';
                $o .= '<span class="nri-portal-doc-icon" aria-hidden="true">&#8226;</span><span class="nri-portal-doc-name">' . esc_html( $ev['event'] ) . '</span><span class="nri-portal-doc-req">' . esc_html( date( 'd M Y', strtotime( $ev['time'] ) ) ) . '</span>';
                $o .= '</a>';
            }
            $o .= '</div>';
        }

        $o .= nri_render_support_modal();
        return $o;
    }
}

function nri_render_profile_tab( $uid, $user ) {
    $phone   = get_user_meta( $uid, 'nri_phone',   true );
    $address = get_user_meta( $uid, 'nri_address', true );
    $o  = '<div class="nri-profile-wrap nri-portal-profile">';
    // nri-nav-item + data-tab reuse the same tab-click delegation as the
    // main nav links (see detectSurface()/setActiveNav() in nri-app.js) —
    // this is a plain forward tab switch (Profile → Dashboard), not a
    // "back" in the history sense, so it gets the same no-scroll-jump
    // in-place swap as any other tab click.
    $o .= '<div class="nri-page-breadcrumb"><a href="' . esc_url( home_url( '/client-dashboard' ) ) . '" class="nri-nav-item" data-tab="dashboard">&larr; Back to Dashboard</a></div>';
    $o .= '<h2 class="nri-portal-page-title"><span class="nri-portal-icon" aria-hidden="true">&#128100;</span> My Profile</h2>';
    $o .= '<div class="nri-panel-card nri-portal-panel" style="max-width:600px;">';
    $o .= '<form id="nri-profile-form">';
    $o .= '<div class="nri-field"><label>Display Name</label><input type="text" name="display_name" value="' . esc_attr( $user->display_name ) . '" placeholder="Your name"></div>';
    $o .= '<div class="nri-field"><label>Email Address</label><input type="email" value="' . esc_attr( $user->user_email ) . '" disabled style="background:#f8fafc;color:#94a3b8;"><p class="nri-hint-sm">Contact admin to change email.</p></div>';
    $o .= '<div class="nri-field"><label>Phone Number</label>';
    $o .= '<div class="nri-phone-wrap"><select name="phone_code" class="nri-phone-code">';
    foreach ( array( '+91' => 'IN +91', '+1' => 'US +1', '+44' => 'UK +44', '+61' => 'AU +61', '+971' => 'UAE +971' ) as $code => $text ) {
        $o .= '<option value="' . esc_attr( $code ) . '">' . esc_html( $text ) . '</option>';
    }
    $o .= '</select><input type="tel" name="phone" value="' . esc_attr( $phone ) . '" placeholder="Mobile number" pattern="[0-9]{6,15}"></div></div>';
    $o .= '<div class="nri-field"><label>Address</label><input type="text" name="address" value="' . esc_attr( $address ) . '" placeholder="Your address"></div>';
    $o .= '<hr style="border:none;border-top:1px solid #e2e8f0;margin:20px 0;">';
    $o .= '<h4 style="margin:0 0 12px;font-size:15px;">Change Password <span style="font-size:12px;font-weight:400;color:#94a3b8;">(leave blank to keep current)</span></h4>';
    $o .= '<div class="nri-field"><label>New Password</label><div class="nri-pw-wrap"><input type="password" name="new_password" placeholder="Min 8 characters" id="nri-new-pw"><button type="button" class="nri-pw-toggle">Show</button></div></div>';
    $o .= '<div class="nri-field"><label>Confirm Password</label><input type="password" name="confirm_password" placeholder="Repeat password"></div>';
    $o .= '<div id="nri-profile-msg" class="nri-alert" style="display:none;margin-bottom:12px;"></div>';
    $o .= '<button type="submit" class="nri-btn nri-btn-primary">Save Profile</button>';
    $o .= '</form></div></div>';
    return $o;
}

function nri_render_support_modal() {
    $cats = array( 'Refund', 'Shipping', 'Order Status', 'Payment Issue', 'Login / Sign Up', 'Other' );
    $o  = '<div id="nri-sr-modal" style="display:none;position:fixed;inset:0;z-index:99999;align-items:center;justify-content:center;background:rgba(0,0,0,.5);">';
    $o .= '<div class="nri-modal-box"><div class="nri-modal-hdr"><h3>Other Service Request</h3>';
    $o .= '<button class="nri-modal-x" onclick="document.getElementById(\'nri-sr-modal\').style.display=\'none\'">&#10005;</button></div>';
    $o .= '<div class="nri-modal-body">';
    $o .= '<form id="nri-support-form">';
    $o .= '<div class="nri-field"><label>Category <span class="nri-req">*</span></label>';
    $o .= '<select name="category" id="nri-support-cat" required class="nri-modal-select"><option value="">-- Select Category --</option>';
    foreach ( $cats as $cat ) { $o .= '<option value="' . esc_attr( $cat ) . '">' . esc_html( $cat ) . '</option>'; }
    $o .= '</select></div>';
    if ( ! is_user_logged_in() ) {
        $o .= '<div class="nri-field"><label>Your Email <span class="nri-req">*</span></label><input type="email" name="email" placeholder="your@email.com" required></div>';
    }
    $o .= '<div class="nri-field"><label>Description <span class="nri-req">*</span></label><textarea name="description" rows="4" placeholder="Describe your issue in detail..." required></textarea></div>';
    $o .= '<div class="nri-field"><label>Attachment <span class="nri-hint-sm">(optional)</span></label>';
    $o .= '<input type="file" name="support_file" accept=".pdf,.jpg,.jpeg,.png" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:8px;font-size:13px;"></div>';
    $o .= '<div id="nri-support-err" class="nri-alert nri-alert-error" style="display:none;margin-bottom:12px;"></div>';
    $o .= '<button type="submit" class="nri-btn nri-btn-primary nri-w100">Submit Request</button>';
    $o .= '</form></div><p class="nri-form-foot"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>Secure submission &middot; You will get a confirmation email</p></div></div>';
    return $o;
}

/* ============================================================
   SHORTCODE: REQUEST DETAIL VIEW
   ============================================================ */

add_shortcode( 'nri_request_view', 'nri_sc_request_view' );
function nri_sc_request_view( $atts ) {
    return nri_render_request_view( 0, false );
}

/**
 * Renders the full request-detail screen. Used two ways:
 *  - $embedded = false (default): the standalone /request/{id} page —
 *    includes the site nav/breadcrumb header, exactly as before.
 *  - $embedded = true: returned as an AJAX fragment for the admin
 *    dashboard SPA (nri_ajax_admin_load_request_detail) — the header
 *    nav/breadcrumb is swapped for a lightweight "back to list" button
 *    that the dashboard's own JS wires up, since the dashboard already
 *    has its own header/nav on screen.
 * $rid_override lets the AJAX path pass the request ID directly instead
 * of relying on the query var / URL parsing (which only make sense for
 * a real page load).
 */
function nri_render_request_view( $rid_override = 0, $embedded = false ) {
    $rid = $rid_override ? intval( $rid_override ) : intval( get_query_var( 'nri_request_id' ) );
    if ( ! $rid ) {
        $parts = explode( '/', trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' ) );
        $idx   = array_search( 'request', $parts );
        if ( $idx !== false && isset( $parts[ $idx + 1 ] ) ) { $rid = intval( $parts[ $idx + 1 ] ); }
    }
    if ( ! $rid )                       { return '<div class="nri-msg-card"><p>Request not found.</p></div>'; }
    if ( ! is_user_logged_in() )        { return '<div class="nri-msg-card"><p>Please <a href="' . esc_url( home_url( '/nri-login' ) ) . '">log in</a>.</p></div>'; }
    if ( ! nri_is_own_request( $rid ) ) { return '<div class="nri-msg-card"><p>Access denied.</p></div>'; }

    $meta       = nri_get_meta( $rid );
    $status     = $meta['status'];
    $fd         = $meta['field_data'];
    $docs       = nri_get_documents( $rid );
    $messages   = nri_get_messages( $rid );
    $tickets    = nri_get_tickets( $rid );
    $history    = nri_get_history( $rid );
    $is_staff   = nri_is_staff();
    $delivery   = $meta['estimated_delivery'];
    $quote      = $meta['quote_amount'];
    $sec        = $meta['secondary_status'] ? $meta['secondary_status'] : 'To be Updated';
    $req_post   = get_post( $rid );
    $author     = $req_post ? get_userdata( $req_post->post_author ) : null;
    $mgr_uid    = $meta['assigned_manager'];
    $mgr        = $mgr_uid ? get_userdata( $mgr_uid ) : null;
    $vnd_uid    = $meta['assigned_vendor'];
    $vnd        = $vnd_uid ? get_userdata( $vnd_uid ) : null;
    $svc        = '';
    if ( ! empty( $fd['field_service_type'] ) )      { $svc = $fd['field_service_type']; }
    elseif ( ! empty( $fd['field_document_type'] ) ) { $svc = $fd['field_document_type']; }
    else                                              { $svc = 'Document Request'; }
    $mgr_name   = $mgr ? $mgr->display_name  : get_option( 'nri_manager_name', 'NRI Support' );
    $mgr_email  = $mgr ? $mgr->user_email    : get_option( 'nri_manager_email', '' );
    $mgr_phone  = $mgr_uid ? get_user_meta( $mgr_uid, 'phone', true ) : get_option( 'nri_manager_phone', '' );

    $stages     = array( 'submitted' => 'Received', 'under_review' => 'Under Review', 'ready_for_processing' => 'Ready for Processing', 'approved' => 'Approved', 'processing' => 'Processing', 'dispatched' => 'Dispatched', 'completed' => 'Completed', 'service_not_available' => 'Service Not Available' );
    $stage_keys = array_keys( $stages );
    $cur_idx    = array_search( $status, $stage_keys );
    if ( $cur_idx === false ) { $cur_idx = 0; }

    $user_docs  = array(); $prov_docs = array();
    foreach ( $docs as $d ) {
        if ( ! empty( $d['is_provider'] ) ) { $prov_docs[] = $d; } else { $user_docs[] = $d; }
    }

    $cur_uid     = get_current_user_id();
    $all_mgrs    = array_merge( get_users( array( 'role' => 'nri_manager' ) ), get_users( array( 'role' => 'nri_admin' ) ), get_users( array( 'role' => 'administrator' ) ) );
    $all_vendors = get_users( array( 'role' => 'nri_vendor' ) );

    // --- Determine correct back URL ---
    $back_url = $is_staff ? home_url( '/admin-dashboard' ) : home_url( '/client-dashboard' );
    $back_lbl = $is_staff ? '&larr; All Requests' : '&larr; Dashboard';

    if ( $embedded ) {
        // Inside the admin dashboard SPA: no second nav bar, and the
        // "back" link is a JS hook (nri-back-to-admin-list) instead of
        // a real navigation — nri-app.js restores the requests list
        // exactly where the admin left it (same filters/search/page)
        // rather than reloading a fresh one.
        $o  = '<div class="nri-order-page nri-order-page-embedded" data-nri-rid="' . intval( $rid ) . '">';
        $o .= '<div class="nri-page-breadcrumb"><a href="' . esc_url( $back_url ) . '" class="nri-back-to-admin-list">' . $back_lbl . '</a></div>';
    } else {
        $o  = nri_client_nav( 'dashboard' );
        $o .= '<div class="nri-order-page nri-portal-order-page" data-nri-rid="' . intval( $rid ) . '">';
        $o .= '<div class="nri-page-breadcrumb"><a href="' . esc_url( $back_url ) . '">' . $back_lbl . '</a></div>';
    }

    // Order header
    $o .= '<div class="nri-order-hdr">';
    $o .= '<h1 class="nri-order-num">Order #' . esc_html( $meta['request_id'] ? $meta['request_id'] : $rid ) . '</h1>';
    $o .= '<div style="display:flex;align-items:center;gap:10px;">';
    $o .= '<span class="nri-status-chip nri-status-lg" style="background:' . nri_status_color( $status ) . '22;color:' . nri_status_color( $status ) . ';">' . esc_html( nri_status_label( $status ) ) . '</span>';
    if ( $is_staff ) {
        $o .= '<button class="nri-btn nri-btn-danger nri-btn-sm nri-delete-request" data-rid="' . intval( $rid ) . '">&#128465; Delete</button>';
    }
    $o .= '</div></div>';

    // Info row
    $o .= '<div class="nri-info-row">';
    $o .= '<div class="nri-info-card nri-info-card-svc"><div class="nri-svc-thumb">&#128218;</div><div class="nri-svc-name">' . esc_html( wp_trim_words( $svc, 6, '' ) ) . '</div></div>';
    $o .= '<div class="nri-info-card"><div class="nri-info-label">Customer Details</div>';
    if ( $author ) {
        $o .= '<div class="nri-info-name">' . esc_html( strtoupper( $author->display_name ) ) . '</div>';
        if ( ! empty( $fd['field_phone'] ) ) {
            $code = isset( $fd['field_phone_code'] ) ? $fd['field_phone_code'] : '+91';
            $o .= '<div class="nri-info-line">' . esc_html( $code . ' ' . $fd['field_phone'] ) . '</div>';
        }
        $o .= '<div class="nri-info-line">' . esc_html( $author->user_email ) . '</div>';
    }
    $o .= '</div>';
    $delivery_loc = isset( $fd['field_delivery_location'] ) ? $fd['field_delivery_location'] : 'NA';
    $o .= '<div class="nri-info-card"><div class="nri-info-label">Shipping Address</div><div class="nri-info-val">' . esc_html( $delivery_loc ) . '</div></div>';
    $o .= '<div class="nri-info-card nri-info-card-mgr"><div class="nri-info-label">Contact Order Manager</div>';
    $o .= '<div class="nri-info-name">' . esc_html( $mgr_name ) . '</div>';
    if ( $mgr_phone ) { $o .= '<div class="nri-info-line">Phone: ' . esc_html( $mgr_phone ) . '</div>'; }
    if ( $mgr_email ) { $o .= '<div class="nri-info-line">Email: ' . esc_html( $mgr_email ) . '</div>'; }
    if ( $vnd )       { $o .= '<div class="nri-info-line nri-info-vendor">Vendor: ' . esc_html( $vnd->display_name ) . '</div>'; }
    $o .= '</div></div>';

    // Summary bar
    $o .= '<div class="nri-summary-bar">';
    
    // v6.2.1: Show service charges and shipping charges separately
    $shipping_charges = isset($meta['shipping_charges']) ? floatval($meta['shipping_charges']) : 0;
    $service_amount = $quote ? floatval($quote) : 0;
    $total_amount = $service_amount + $shipping_charges;
    
    if ($service_amount > 0 || $shipping_charges > 0) {
        $o .= '<div class="nri-summary-item"><span class="nri-summary-label">Service Charges :</span><span class="nri-summary-val">INR ' . number_format($service_amount, 2) . '</span></div>';
        $o .= '<div class="nri-summary-sep"></div>';
        $o .= '<div class="nri-summary-item"><span class="nri-summary-label">Shipping Charges :</span><span class="nri-summary-val">INR ' . number_format($shipping_charges, 2) . '</span></div>';
        $o .= '<div class="nri-summary-sep"></div>';
        $o .= '<div class="nri-summary-item"><span class="nri-summary-label">Total Amount :</span><span class="nri-summary-val" style="font-weight:700;">INR ' . number_format($total_amount, 2) . '</span></div>';
    } else {
        $o .= '<div class="nri-summary-item"><span class="nri-summary-label">Total Amount :</span><span class="nri-summary-val">' . ( $quote ? 'INR ' . number_format( (float) $quote, 2 ) : 'To be Updated' ) . '</span></div>';
    }
    
    $o .= '<div class="nri-summary-sep"></div>';
    $working_days_disp = get_post_meta( $rid, 'timeline_working_days', true );
    $delivery_val = $delivery
        ? esc_html( date( 'd M Y', strtotime( $delivery ) ) ) . ( $working_days_disp ? '<br><small style="color:#94a3b8;font-size:11px;">(' . intval($working_days_disp) . ' working days &mdash; excl. Sat, Sun &amp; Govt Holidays)</small>' : '' )
        : 'To be Updated';
    $o .= '<div class="nri-summary-item"><span class="nri-summary-label">Timeline :</span><span class="nri-summary-val">' . $delivery_val . '</span></div>';
    $o .= '<div class="nri-summary-sep"></div>';
    $o .= '<div class="nri-summary-item"><span class="nri-summary-label">Secondary Status :</span><span class="nri-summary-val">' . esc_html( $sec ) . '</span></div>';
    $o .= '</div>';

    // Pipeline
    $o .= '<div class="nri-pipeline-wrap">';
    $is_service_unavailable = ($status === 'service_not_available');
    foreach ( $stage_keys as $i => $key ) {
        // Skip showing "service_not_available" in normal flow
        if ($key === 'service_not_available') continue;
        
        $is_done = ( $i <= $cur_idx ); 
        $is_cur = ( $i === $cur_idx );
        
        // If service not available, fade everything after "Under Review"
        $is_faded = false;
        if ($is_service_unavailable && $key !== 'submitted' && $key !== 'under_review') {
            $is_faded = true;
            $is_done = false;
            $is_cur = false;
        }
        
        $cls = ( $is_done ? ' nri-done' : '' ) . ( $is_cur ? ' nri-current' : '' ) . ( $is_faded ? ' nri-faded' : '' );
        $o .= '<div class="nri-pipeline-node' . $cls . '"><div class="nri-pipeline-circle">' . ( ( $is_done && ! $is_cur ) ? '&#10003;' : '' ) . '</div>';
        $o .= '<div class="nri-pipeline-lbl">' . esc_html( $stages[ $key ] ) . '</div></div>';
        if ( $i < count( $stage_keys ) - 1 ) {
            $bar_done = ($i < $cur_idx && !$is_service_unavailable);
            $o .= '<div class="nri-pipeline-bar' . ( $bar_done ? ' nri-done' : '' ) . '"></div>';
        }
    }
    
    // If service not available, show it as a special node
    if ($is_service_unavailable) {
        $o .= '<div class="nri-pipeline-node nri-current nri-service-unavailable"><div class="nri-pipeline-circle">✗</div>';
        $o .= '<div class="nri-pipeline-lbl">Service Not Available</div></div>';
    }
    
    $o .= '</div>';

    // Tabs — Communication tab is admin-only
    $o .= '<div class="nri-order-tabs-wrap"><div class="nri-order-tabs">';
    $o .= '<button class="nri-ot active" data-ot="docs">Documents &amp; Order History</button>';
    $o .= '<button class="nri-ot" data-ot="formdetails">Form Details &amp; Export</button>';
    $o .= '<button class="nri-ot" data-ot="tickets">Service Request</button>';
    if ( $is_staff ) {
        $o .= '<button class="nri-ot nri-ot-comm" data-ot="communication">&#9993; Communication</button>';
    }
    $o .= '</div>';

    // Documents & History tab
    $o .= '<div id="nri-ot-docs" class="nri-ot-pane active"><div class="nri-docs-layout"><div class="nri-docs-left">';

    foreach ( array( array( 'user', $user_docs, 'User Documents', false ), array( 'provider', $prov_docs, 'Service Provider Documents', true ) ) as $ds ) {
        list( $key, $items, $title, $is_prov ) = $ds;
        $o .= '<div class="nri-doc-section">';
        $o .= '<button class="nri-doc-section-btn ' . ( $is_prov ? '' : 'nri-ds-open' ) . '" data-ds="' . $key . '">' . esc_html( $title ) . ' <span class="nri-ds-arrow">' . ( $is_prov ? '&#9660;' : '&#9650;' ) . '</span></button>';
        $o .= '<div class="nri-doc-section-body" id="nri-ds-' . $key . '" style="' . ( $is_prov ? 'display:none;' : '' ) . '">';
        if ( empty( $items ) ) {
            $o .= '<p class="nri-hint" style="padding:12px 16px;">No documents yet.</p>';
        } else {
            // Bulk download toolbar
            $o .= '<div class="nri-doc-bulk-bar" id="nri-doc-bulk-bar-' . $key . '" style="display:flex;align-items:center;gap:8px;padding:8px 16px;background:#f1f5f9;border-bottom:1px solid #e2e8f0;">';
            $o .= '<label style="display:flex;align-items:center;gap:6px;font-size:13px;color:#475569;cursor:pointer;">';
            $o .= '<input type="checkbox" class="nri-doc-select-all" data-section="' . $key . '" style="width:15px;height:15px;"> Select All';
            $o .= '</label>';
            $o .= '<button class="nri-btn nri-btn-sm nri-btn-outline nri-doc-bulk-dl" data-section="' . $key . '" style="display:none;">&#8595; Download Selected</button>';
            $o .= '<button class="nri-btn nri-btn-sm nri-btn-ghost nri-doc-dl-all" data-rid="' . intval( $rid ) . '" data-section="' . $key . '">&#8595; Download All</button>';
            $o .= '<button type="button" class="nri-btn nri-btn-ghost nri-btn-sm nri-change-save-folder" title="Documents currently save into a remembered folder. Click to choose a different one for future downloads.">&#128193; Change Folder</button>';
            $o .= '</div>';
            foreach ( $items as $doc ) {
                $att_id  = intval( $doc['file'] );
                $dl_url  = nri_get_download_url( $att_id );
                $fn      = basename( get_attached_file( $att_id ) );
                // If file is AVIF/WebP, show .png since proxy converts it on download
                $fn_ext_chk = strtolower( pathinfo( $fn, PATHINFO_EXTENSION ) );
                if ( in_array( $fn_ext_chk, array( 'avif', 'webp' ), true ) ) {
                    $fn = pathinfo( $fn, PATHINFO_FILENAME ) . '.png';
                }
                $dname   = isset( $doc['doc_type'] ) ? $doc['doc_type'] : $fn;
                $o .= '<div class="nri-doc-entry" data-att-id="' . $att_id . '" data-url="' . esc_attr( $dl_url ) . '" data-filename="' . esc_attr( $fn ) . '">';
                $o .= '<label style="display:flex;align-items:center;gap:8px;flex:1;cursor:pointer;min-width:0;">';
                $o .= '<input type="checkbox" class="nri-doc-chk" data-section="' . $key . '" data-url="' . esc_attr( $dl_url ) . '" data-filename="' . esc_attr( $fn ) . '" style="width:15px;height:15px;flex-shrink:0;">';
                $o .= '<div style="min-width:0;"><div class="nri-doc-entry-name" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' . esc_html( $dname ) . '</div>';
                $o .= '<div class="nri-doc-entry-by">By ' . ( $is_prov ? 'System' : 'Client' ) . '</div></div>';
                $o .= '</label>';
                $o .= '<a href="' . esc_url( $dl_url ) . '" class="nri-dl-btn" title="Download">&#8595;</a>';
                if ( $is_staff ) { $o .= '<button class="nri-del-doc nri-btn-icon" data-rid="' . intval( $rid ) . '" data-att="' . $att_id . '" title="Delete">&#128465;</button>'; }
                $o .= '</div>';
            }
        }
        if ( ! $is_prov || $is_staff ) {
            $o .= '<div class="nri-doc-upload-row"><button class="nri-btn nri-btn-sm nri-btn-outline" onclick="nriShowUpload(\'' . $key . '\',' . intval( $rid ) . ')">+ Upload</button></div>';
        }
        $o .= '</div></div>';
    }

    // Upload area
    $o .= '<div id="nri-upload-area" style="display:none;padding:16px;"><div class="nri-field"><label>Document Name</label><input type="text" id="nri-doc-type" placeholder="e.g. Transcript"></div>';
    $o .= '<div class="nri-dropzone-sm" id="nri-upload-drop"><input type="file" id="nri-doc-file" accept=".pdf,.jpg,.jpeg,.png" style="display:none">';
    $o .= '<p style="font-size:13px;padding:12px;text-align:center;">Drop here or <button type="button" class="nri-link" onclick="document.getElementById(\'nri-doc-file\').click()">browse</button></p></div>';
    $o .= '<div id="nri-upload-progress" style="display:none;margin-top:8px;"><div class="nri-prog-bar"><div class="nri-prog-fill" id="nri-prog-fill"></div></div></div>';
    $o .= '<input type="hidden" id="nri-upload-rid" value="' . intval( $rid ) . '"><input type="hidden" id="nri-upload-is-provider" value="0">';
    $o .= '<div style="display:flex;gap:8px;margin-top:10px;"><button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-do-upload">Upload</button>';
    $o .= '<button class="nri-btn nri-btn-ghost nri-btn-sm" onclick="document.getElementById(\'nri-upload-area\').style.display=\'none\'">Cancel</button></div></div>';

    $o .= '</div>';

    // History / Messages
    // Filter out comm-panel email logs ([Email] prefix) — those belong in Communication Log only
    $display_messages = array_filter( $messages, function( $m ) {
        return strpos( $m->message, '[Email] ' ) !== 0;
    });

    $o .= '<div class="nri-docs-right">';
    $o .= '<div class="nri-order-history-hdr" style="display:flex;justify-content:space-between;align-items:center;">&#128172; Messages<button type="button" id="nri-refresh-msgs" data-rid="' . intval( $rid ) . '" style="font-size:11px;padding:3px 10px;background:none;border:1px solid #e2e8f0;border-radius:4px;cursor:pointer;color:#64748b;">&#8635; Refresh</button></div>';
    $o .= '<div class="nri-messages-list" id="nri-msgs-list">';
    if ( empty( $display_messages ) ) {
        $o .= '<p class="nri-hint" style="text-align:center;padding:20px;color:#94a3b8;">No messages yet. Send a message below.</p>';
    } else {
        foreach ( $display_messages as $m ) {
            $is_mine     = ( (int) $m->sender_id === $cur_uid );
            $sender_is_staff_msg = ( ! empty( $m->user_email ) )
                ? user_can( (int) $m->sender_id, 'administrator' )
                  || user_can( (int) $m->sender_id, 'nri_admin' )
                  || user_can( (int) $m->sender_id, 'nri_manager' )
                : false;

            // Label: "You" for own messages, "Support Team" for admin messages on client view,
            // client name for admin viewing client messages
            if ( $is_mine ) {
                $label = 'You';
            } elseif ( $sender_is_staff_msg ) {
                $label = $is_staff ? esc_html( $m->display_name ) . ' (Admin)' : 'Support Team';
            } else {
                $label = $is_staff ? esc_html( $m->display_name ) . ' (Client)' : esc_html( $m->display_name );
            }

            $time_fmt = wp_date( 'd M, g:i a', strtotime( $m->created_at ) );
            $o .= '<div class="nri-msg-item ' . ( $is_mine ? 'nri-msg-mine' : '' ) . '" id="nrimsg-' . intval( $m->id ) . '" data-mid="' . intval( $m->id ) . '">';
            $o .= '<div class="nri-msg-meta-top">';
            $o .= '<span style="font-weight:600;color:' . ( $is_mine ? 'inherit' : '#475569' ) . ';">' . $label . '</span>';
            $o .= '<span style="color:#94a3b8;font-size:11px;margin-left:6px;">' . esc_html( $time_fmt ) . '</span>';
            if ( $m->is_email_sent ) {
                $o .= ' <span class="nri-email-sent-badge" title="Email notification sent">&#9993; Sent</span>';
            }
            if ( $is_staff ) {
                $o .= ' <button class="nri-del-msg nri-btn-icon" data-id="' . intval( $m->id ) . '" title="Delete message">&#128465;</button>';
            }
            $o .= '</div>';
            $o .= '<div class="nri-msg-bubble">' . nl2br( esc_html( $m->message ) ) . '</div>';
            $o .= '</div>';
        }
    }
    $o .= '</div>';

    // Compose area
    $o .= '<div class="nri-msg-input-area">';
    $o .= '<textarea id="nri-msg-text" placeholder="Type your message here..." rows="3"></textarea>';
    $o .= '<input type="hidden" id="nri-msg-rid" value="' . intval( $rid ) . '">';
    $o .= '<div class="nri-msg-actions">';
    $o .= '<button id="nri-send-msg" class="nri-btn nri-btn-primary nri-btn-sm">Send</button>';
    $o .= '<button id="nri-send-msg-email" class="nri-btn nri-btn-outline nri-btn-sm">&#9993; Send via Email</button>';
    $o .= '</div>';
    $o .= '<p class="nri-hint-sm" style="color:#94a3b8;margin-top:4px;">Send = saved to this chat. Send via Email = saved here + also sends an email notification.</p>';
    $o .= '</div>';
    $o .= '</div></div></div>';

    // Form Details & Export tab
    $o .= nri_render_form_details_pane( $rid, $fd, $docs, $is_staff, $meta );

    // Tickets tab
    $o .= '<div id="nri-ot-tickets" class="nri-ot-pane" style="display:none;">';
    $o .= '<div class="nri-tickets-toolbar"><input type="text" id="nri-ticket-search" placeholder="Search..." class="nri-search-input">';
    $o .= '<button id="nri-new-ticket-btn" class="nri-btn nri-btn-primary nri-btn-sm" data-rid="' . intval( $rid ) . '">&#8853; Other Service Request</button></div>';
    $o .= '<table class="nri-tbl" id="nri-tickets-tbl"><thead><tr><th>Ticket ID</th><th>Category</th><th>Status</th><th>Date Created</th><th>Last Updated</th>';
    if ( $is_staff ) { $o .= '<th>Action</th>'; }
    $o .= '</tr></thead><tbody>';
    if ( empty( $tickets ) ) {
        $o .= '<tr><td colspan="' . ( $is_staff ? 6 : 5 ) . '" class="nri-tbl-empty">No service requests yet.</td></tr>';
    } else {
        foreach ( $tickets as $tk ) {
            $o .= '<tr class="nri-ticket-row" data-ticket-id="' . intval( $tk->id ) . '">';
            $o .= '<td><strong>#T-' . str_pad( $tk->id, 4, '0', STR_PAD_LEFT ) . '</strong></td>';
            $o .= '<td>' . esc_html( $tk->category ) . '</td>';
            $o .= '<td><span class="nri-ticket-status-chip nri-ts-' . esc_attr( $tk->status ) . '">' . esc_html( ucfirst( $tk->status ) ) . '</span></td>';
            $o .= '<td>' . esc_html( wp_date( 'd M Y', strtotime( $tk->created_at ) ) ) . '</td>';
            $o .= '<td>' . esc_html( wp_date( 'd M Y', strtotime( $tk->updated_at ) ) ) . '</td>';
            if ( $is_staff ) {
                $o .= '<td><select class="nri-ticket-status-sel" data-id="' . intval( $tk->id ) . '" style="font-size:12px;padding:4px;">';
                foreach ( array( 'open', 'in_progress', 'resolved', 'closed' ) as $ts ) {
                    $o .= '<option value="' . $ts . '" ' . ( $tk->status === $ts ? 'selected' : '' ) . '>' . esc_html( ucfirst( str_replace( '_', ' ', $ts ) ) ) . '</option>';
                }
                $o .= '</select><button class="nri-btn nri-btn-sm nri-btn-danger nri-del-ticket" data-id="' . intval( $tk->id ) . '" style="margin-left:6px;">Del</button></td>';
            }
            $o .= '</tr>';
        }
    }
    $o .= '</tbody></table></div></div>';

    // Communication panel — admin-only (compose + quick replies + history)
    if ( $is_staff ) {
        $comm_recipient_name  = $author ? $author->display_name : 'Client';
        $comm_recipient_email = $author ? $author->user_email   : '';
        $comm_quick_replies   = nri_get_quick_replies();
        // Load all available email templates (built-in + any custom ones)
        $comm_all_templates = function_exists( 'nri_get_all_template_types' )
            ? nri_get_all_template_types()
            : array(
                'quotation'            => 'Quotation Email',
                'application_received' => 'Application Received',
                'status_update'        => 'Status Update',
                'document_reminder'    => 'Document Reminder',
                'completion'           => 'Completion',
                'dispatch'             => 'Dispatch',
                'terms_conditions'     => 'Terms & Conditions',
                'general'              => 'General Message',
            );

        $o .= '<div id="nri-ot-communication" class="nri-ot-pane" style="display:none;">';
        $o .= '<div class="nri-comm-panel">';

        // Recipient card
        $o .= '<div class="nri-comm-recipient-card">';
        $o .= '<div class="nri-comm-recipient-icon">&#128100;</div>';
        $o .= '<div class="nri-comm-recipient-info">';
        $o .= '<div class="nri-comm-recipient-label">Sending to</div>';
        $o .= '<div class="nri-comm-recipient-name">' . esc_html( strtoupper( $comm_recipient_name ) ) . '</div>';
        $o .= '<div class="nri-comm-recipient-email">&#9993; ' . esc_html( $comm_recipient_email ) . '</div>';
        if ( ! empty( $fd['field_phone'] ) ) {
            $code = isset( $fd['field_phone_code'] ) ? $fd['field_phone_code'] : '+91';
            $o .= '<div class="nri-comm-recipient-phone">&#128222; ' . esc_html( $code . ' ' . $fd['field_phone'] ) . '</div>';
        }
        $o .= '</div>';
        $o .= '<div class="nri-comm-req-badge">Order #' . esc_html( $meta['request_id'] ? $meta['request_id'] : $rid ) . '</div>';
        $o .= '</div>';

        // Compose section
        $o .= '<div class="nri-comm-compose">';
        $o .= '<div class="nri-comm-compose-hdr"><span class="nri-comm-compose-title">&#9993; Compose Email</span></div>';
        $o .= '<div class="nri-comm-toolbar">';

        // All templates dropdown
        $o .= '<div class="nri-comm-toolbar-group">';
        $o .= '<label class="nri-comm-toolbar-label">Email Template</label>';
        $o .= '<div style="display:flex;gap:8px;align-items:center;">';
        $o .= '<select id="nri-comm-template-sel" class="nri-comm-select">';
        $o .= '<option value="">-- Select Template --</option>';
        foreach ( $comm_all_templates as $tkey => $tlabel ) {
            $clean = trim( preg_replace( '/[\x{1F300}-\x{1F9FF}\x{2600}-\x{26FF}]/u', '', $tlabel ) );
            $o .= '<option value="' . esc_attr( $tkey ) . '">' . esc_html( $clean ) . '</option>';
        }
        $o .= '</select>';
        $o .= '<button class="nri-btn nri-btn-outline nri-btn-sm" id="nri-comm-load-template">Load</button>';
        $o .= '</div></div>';

        // Quick Replies
        if ( ! empty( $comm_quick_replies ) ) {
            $o .= '<div class="nri-comm-toolbar-group nri-comm-qr-group">';
            $o .= '<label class="nri-comm-toolbar-label">Quick Replies</label>';
            $o .= '<div class="nri-comm-quick-btns">';
            foreach ( $comm_quick_replies as $qr ) {
                $o .= '<button class="nri-comm-quick-btn" data-content="' . esc_attr( $qr['content'] ) . '" title="' . esc_attr( $qr['title'] ) . '">' . esc_html( $qr['title'] ) . '</button>';
            }
            $o .= '</div></div>';
        } else {
            $qr_url = esc_url( home_url( '/admin-dashboard?tab=settings&section=quick_replies' ) );
            $o .= '<div class="nri-comm-toolbar-group" style="font-size:12px;color:#94a3b8;padding:4px 0;">';
            $o .= 'No quick replies yet. <a href="' . $qr_url . '" target="_blank" style="color:#3b82f6;">Add in Settings &#8599;</a>';
            $o .= '</div>';
        }
        $o .= '</div>'; // end toolbar

        $o .= '<div class="nri-comm-field"><label class="nri-comm-field-label">Subject</label>';
        $o .= '<input type="text" id="nri-comm-subject" class="nri-comm-input" placeholder="Email subject..." value="Update on Your Request - Order #' . esc_attr( $meta['request_id'] ? $meta['request_id'] : $rid ) . '"></div>';

        $o .= '<div class="nri-comm-field"><label class="nri-comm-field-label">Message</label>';
        $o .= '<textarea id="nri-comm-body" class="nri-comm-textarea" rows="10" placeholder="Type your email message here..."></textarea></div>';

        $o .= '<div class="nri-comm-actions">';
        $o .= '<input type="hidden" id="nri-comm-rid" value="' . intval( $rid ) . '">';
        $o .= '<input type="hidden" id="nri-comm-to-email" value="' . esc_attr( $comm_recipient_email ) . '">';
        $o .= '<input type="hidden" id="nri-comm-to-name" value="' . esc_attr( $comm_recipient_name ) . '">';
        $o .= '<button class="nri-btn nri-btn-primary" id="nri-comm-send-email">&#9993; Send Email</button>';
        $o .= '<button class="nri-btn nri-btn-outline" id="nri-comm-send-and-log">&#9993; Send &amp; Log to History</button>';
        $o .= '</div>';
        $o .= '<div id="nri-comm-status" class="nri-comm-status-msg" style="display:none;"></div>';
        $o .= '</div>'; // end compose

        // Communication history — full subject + body, collapsible
        $emailed_msgs = array_filter( $messages, function($m) { return $m->is_email_sent; } );
        $o .= '<div class="nri-comm-history">';
        $o .= '<div class="nri-comm-history-hdr">&#128203; Communication Log <span class="nri-comm-log-count">' . count( $emailed_msgs ) . ' email(s) sent</span></div>';
        $o .= '<div class="nri-comm-history-list">';
        if ( empty( $emailed_msgs ) ) {
            $o .= '<p class="nri-hint" style="text-align:center;padding:20px 0;">No emails sent yet for this request.</p>';
        } else {
            foreach ( array_reverse( array_values( $emailed_msgs ) ) as $m ) {
                // Messages are stored as "[Email] Subject\n\nBody" — parse back out
                $raw   = $m->message;
                $email_subject = '';
                $email_body    = $raw;
                if ( strpos( $raw, '[Email] ' ) === 0 ) {
                    $without_prefix = substr( $raw, 8 );
                    $sep_pos        = strpos( $without_prefix, "\n\n" );
                    if ( $sep_pos !== false ) {
                        $email_subject = trim( substr( $without_prefix, 0, $sep_pos ) );
                        $email_body    = trim( substr( $without_prefix, $sep_pos + 2 ) );
                    } else {
                        $email_subject = trim( $without_prefix );
                        $email_body    = '';
                    }
                }
                $uid_log = 'nricl-' . intval( $m->id );
                $o .= '<div class="nri-comm-log-item" style="border:1px solid #e2e8f0;border-radius:8px;margin-bottom:12px;overflow:hidden;">';
                // Header row — always visible, click to expand
                $o .= '<div class="nri-comm-log-hdr" style="display:flex;justify-content:space-between;align-items:flex-start;padding:12px 16px;background:#f8fafc;cursor:pointer;" onclick="nriToggleCommLog(\'' . $uid_log . '\')">';
                $o .= '<div style="flex:1;min-width:0;">';
                $o .= '<div style="display:flex;align-items:center;gap:8px;">';
                $o .= '<span style="font-size:16px;">&#9993;</span>';
                $o .= '<span style="font-size:13px;color:#64748b;">Sent by <strong style="color:#1e293b;">' . esc_html( $m->display_name ) . '</strong> &mdash; ' . esc_html( wp_date( 'd M Y, g:i a', strtotime( $m->created_at ) ) ) . '</span>';
                $o .= '</div>';
                if ( $email_subject ) {
                    $o .= '<div style="margin-top:6px;padding-left:26px;font-size:13px;color:#374151;"><strong>Subject:</strong> ' . esc_html( $email_subject ) . '</div>';
                }
                $o .= '</div>';
                $o .= '<span style="font-size:11px;color:#94a3b8;white-space:nowrap;padding-left:12px;" id="' . $uid_log . '-arrow">&#9660; View</span>';
                $o .= '</div>';
                // Body — collapsible
                $o .= '<div id="' . $uid_log . '" class="nri-comm-log-body-wrap" style="display:none;padding:16px;border-top:1px solid #e2e8f0;background:#fff;">';
                if ( $email_subject ) {
                    $o .= '<div style="margin-bottom:12px;padding:8px 12px;background:#eff6ff;border-radius:6px;font-size:13px;font-weight:600;color:#1e40af;">' . esc_html( $email_subject ) . '</div>';
                }
                if ( $email_body ) {
                    $o .= '<div style="font-size:14px;line-height:1.8;color:#374151;white-space:pre-wrap;border:1px solid #e2e8f0;border-radius:6px;padding:12px;background:#fafafa;">' . esc_html( $email_body ) . '</div>';
                } else {
                    $o .= '<p style="font-size:13px;color:#94a3b8;margin:0;">No body content stored for this email.</p>';
                }
                $o .= '</div>';
                $o .= '</div>'; // end log item
            }
        }
        $o .= '</div></div>'; // end history-list + history
        $o .= '</div></div>'; // end comm-panel + ot-pane

    } // end if ( $is_staff ) for comm panel
    // ── END COMMUNICATION PANEL ─────────────────────────────────────────────


    if ( $is_staff ) { $o .= nri_render_staff_panel( $rid, $meta, $status, $all_mgrs, $all_vendors, $mgr_uid, $vnd_uid ); }

    // Ticket modal
    $o .= '<div id="nri-ticket-modal" style="display:none;position:fixed;inset:0;z-index:99999;align-items:center;justify-content:center;background:rgba(0,0,0,.5);">';
    $o .= '<div class="nri-modal-box"><div class="nri-modal-hdr"><h3>Other Service Request</h3><button class="nri-modal-x" id="nri-ticket-modal-close">&#10005;</button></div>';
    $o .= '<div class="nri-modal-body"><div class="nri-field"><label>Category Name</label>';
    $o .= '<select id="nri-ticket-cat" class="nri-modal-select"><option value="">-- Select --</option></select></div>';
    if ( ! is_user_logged_in() ) { $o .= '<div class="nri-field"><label>Email <span class="nri-req">*</span></label><input type="email" id="nri-ticket-email" placeholder="your@email.com" required></div>'; }
    $o .= '<div class="nri-field"><label>Notes</label><textarea id="nri-ticket-notes" rows="3" placeholder="Describe your request..."></textarea></div>';
    $o .= '<div id="nri-ticket-err" class="nri-alert nri-alert-error" style="display:none;"></div>';
    $o .= '<button id="nri-do-ticket" class="nri-btn nri-btn-primary nri-w100" data-rid="' . intval( $rid ) . '">Submit</button></div></div></div>';

    $o .= '</div>';
    return $o;
}

function nri_render_staff_panel( $rid, $meta, $status, $all_mgrs, $all_vendors, $mgr_uid, $vnd_uid ) {
    $statuses = array( 'submitted' => 'Received', 'under_review' => 'Under Review', 'ready_for_processing' => 'Ready for Processing', 'approved' => 'Approved', 'processing' => 'Processing', 'dispatched' => 'Dispatched', 'completed' => 'Completed', 'service_not_available' => 'Service Not Available', 'rejected' => 'Cancelled' );
    $o  = '<div class="nri-staff-panel-wrap"><div class="nri-staff-panel-hdr" id="nri-staff-toggle">&#9881; Staff Controls <span>&#9660;</span></div>';
    $o .= '<div class="nri-staff-panel-body" id="nri-staff-body"><div class="nri-staff-grid">';
    $o .= '<div class="nri-staff-section"><div class="nri-staff-label">Update Status</div>';
    $o .= '<select id="nri-status-sel" style="width:100%;margin-bottom:8px;padding:8px;border:1px solid #e2e8f0;border-radius:6px;">';
    foreach ( $statuses as $sv => $sl ) { $o .= '<option value="' . $sv . '" ' . ( $status === $sv ? 'selected' : '' ) . '>' . esc_html( $sl ) . '</option>'; }
    $o .= '</select><input type="text" id="nri-status-note" placeholder="Note (optional)" style="width:100%;margin-bottom:8px;padding:8px;border:1px solid #e2e8f0;border-radius:6px;box-sizing:border-box;">';
    $o .= '<button class="nri-btn nri-btn-outline nri-btn-sm nri-w100" id="nri-do-status" data-rid="' . intval( $rid ) . '">Update Status</button></div>';
    $o .= '<div class="nri-staff-section"><div class="nri-staff-label">Set Delivery Date</div>';
    $o .= '<div class="nri-tl-toggle"><button class="nri-tlt active" data-tl="days">By Days</button><button class="nri-tlt" data-tl="date">Fixed Date</button></div>';
    $o .= '<div id="nri-tl-days-wrap" style="display:flex;gap:8px;align-items:center;margin:8px 0;"><input type="number" id="nri-tl-days" placeholder="30" min="1" style="width:80px;padding:8px;border:1px solid #e2e8f0;border-radius:6px;"><span style="font-size:13px;color:#64748b;"><strong>Working Days</strong><br><small style="color:#94a3b8;">(Excludes Sat, Sun, and Govt Holidays)</small></span></div>';
    $o .= '<div id="nri-tl-date-wrap" style="display:none;margin:8px 0;"><input type="date" id="nri-tl-date" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;box-sizing:border-box;"></div>';
    $o .= '<input type="text" id="nri-tl-note" placeholder="Note (optional)" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;box-sizing:border-box;margin-bottom:8px;">';
    $o .= '<button class="nri-btn nri-btn-primary nri-btn-sm nri-w100" id="nri-do-timeline" data-rid="' . intval( $rid ) . '">Set Timeline</button></div>';
    // ── Quote & Shipping section ─────────────────────────────────────────────
    $shipping_charges = isset($meta['shipping_charges']) ? floatval($meta['shipping_charges']) : 0;
    $shipping_type    = isset($meta['shipping_type'])    ? $meta['shipping_type'] : 'domestic';
    $service_amount   = floatval($meta['quote_amount']);
    $total_amount     = $service_amount + $shipping_charges;

    $o .= '<div class="nri-staff-section">';
    $o .= '<div class="nri-staff-label">💰 Quotation</div>';

    // Service charge row
    $o .= '<div style="margin-bottom:8px;">';
    $o .= '<label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Service Charges (INR)</label>';
    $o .= '<div style="display:flex;gap:6px;">';
    $o .= '<input type="number" id="nri-quote-amt" placeholder="0.00" min="0" step="0.01" value="' . esc_attr( $service_amount ?: '' ) . '" style="flex:1;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">';
    $o .= '<button class="nri-btn nri-btn-outline nri-btn-sm" id="nri-do-quote" data-rid="' . intval( $rid ) . '" style="white-space:nowrap;">Save</button>';
    $o .= '</div></div>';

    // Shipping charge row
    $o .= '<div style="margin-bottom:12px;">';
    $o .= '<label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Shipping Charges (INR)</label>';
    $o .= '<div style="display:flex;gap:6px;">';
    $o .= '<input type="number" id="nri-shipping-amt" placeholder="0.00" min="0" step="0.01" value="' . esc_attr( $shipping_charges ?: '' ) . '" style="flex:1;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">';
    $o .= '<select id="nri-shipping-type" style="padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;">';
    $o .= '<option value="domestic"      ' . ($shipping_type === 'domestic'      ? 'selected' : '') . '>Domestic</option>';
    $o .= '<option value="international" ' . ($shipping_type === 'international' ? 'selected' : '') . '>International</option>';
    $o .= '</select>';
    $o .= '<button class="nri-btn nri-btn-outline nri-btn-sm" id="nri-do-shipping" data-rid="' . intval( $rid ) . '" style="white-space:nowrap;">Save</button>';
    $o .= '</div></div>';

    // Live total display
    $o .= '<div id="nri-quote-total-box" style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:10px 14px;margin-bottom:14px;' . ($total_amount <= 0 ? 'display:none;' : '') . '">';
    $o .= '<div style="font-size:11px;color:#16a34a;font-weight:600;text-transform:uppercase;letter-spacing:.05em;margin-bottom:2px;">Total Amount</div>';
    $o .= '<div id="nri-quote-total-val" style="font-size:20px;font-weight:700;color:#15803d;">₹' . number_format( $total_amount, 2 ) . '</div>';
    $o .= '<div id="nri-quote-total-breakdown" style="font-size:11px;color:#4ade80;margin-top:2px;">Service ₹' . number_format($service_amount,2) . ' + Shipping ₹' . number_format($shipping_charges,2) . '</div>';
    $o .= '</div>';

    // Send quote email section
    $o .= '<div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:12px 14px;margin-bottom:6px;">';
    $o .= '<div style="font-size:12px;font-weight:600;color:#1e40af;margin-bottom:8px;">📧 Send Quotation Email</div>';
    $o .= '<label style="display:flex;align-items:center;gap:8px;font-size:13px;color:#374151;cursor:pointer;margin-bottom:6px;">';
    $o .= '<input type="checkbox" id="nri-include-terms" style="width:14px;height:14px;"> Include Terms &amp; Conditions</label>';
    $o .= '<button class="nri-btn nri-btn-primary nri-btn-sm nri-w100" id="nri-send-quote-btn" data-rid="' . intval($rid) . '">📧 Send Quotation Email to Client</button>';
    $o .= '<div id="nri-quote-email-msg" style="margin-top:8px;font-size:12px;display:none;"></div>';
    $o .= '</div>';
    $o .= '<div class="nri-staff-label">Secondary Status</div><div style="display:flex;gap:8px;"><input type="text" id="nri-sec-status" placeholder="e.g. Documents pending" value="' . esc_attr( $meta['secondary_status'] ) . '" style="flex:1;padding:8px;border:1px solid #e2e8f0;border-radius:6px;"><button class="nri-btn nri-btn-outline nri-btn-sm" id="nri-do-sec-status" data-rid="' . intval( $rid ) . '">Set</button></div></div>';
    $o .= '<div class="nri-staff-section"><div class="nri-staff-label">Quick Email Actions</div><div style="display:flex;flex-direction:column;gap:8px;"><button class="nri-btn nri-btn-outline nri-btn-sm nri-w100" id="nri-send-doc-reminder" data-rid="' . intval( $rid ) . '">&#128229; Send Document Reminder Email</button><button class="nri-btn nri-btn-outline nri-btn-sm nri-w100" id="nri-send-status-email" data-rid="' . intval( $rid ) . '">&#9993; Send Status Update Email</button></div></div>';
    $o .= '<div class="nri-staff-section"><div class="nri-staff-label">Assign Manager</div>';
    $o .= '<div style="display:flex;gap:8px;margin-bottom:12px;"><select id="nri-assign-mgr" data-rid="' . intval( $rid ) . '" style="flex:1;padding:8px;border:1px solid #e2e8f0;border-radius:6px;"><option value="">- Select Manager -</option>';
    foreach ( $all_mgrs as $m ) { $o .= '<option value="' . intval( $m->ID ) . '" ' . ( (int) $mgr_uid === $m->ID ? 'selected' : '' ) . '>' . esc_html( $m->display_name ) . '</option>'; }
    $o .= '</select><button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-do-assign-mgr" data-rid="' . intval( $rid ) . '">Save Manager</button></div>';
    $current_mgr_name = $mgr ? $mgr->display_name : '-';
    $o .= '<div id="nri-mgr-current" style="font-size:12px;color:#64748b;margin-bottom:8px;">Currently assigned: <strong>' . esc_html($current_mgr_name) . '</strong></div>';

    // Vendor dropdown from nri_vendors table (preferred) + WP users fallback
    $o .= '<div class="nri-staff-label">Assign Vendor</div>';
    // Get current vendor info for display
    global $wpdb;
    $vendor_profiles = $wpdb->get_results("SELECT id, name, phone, whatsapp FROM {$wpdb->prefix}nri_vendors WHERE status='active' ORDER BY name ASC");
    $current_vendor_id   = $meta['assigned_vendor'];
    $current_vendor_name = '-';
    if ($current_vendor_id) {
        $cv = $wpdb->get_row($wpdb->prepare("SELECT name FROM {$wpdb->prefix}nri_vendors WHERE id=%d", $current_vendor_id));
        if ($cv) $current_vendor_name = $cv->name;
        elseif ($vnd) $current_vendor_name = $vnd->display_name;
    }
    $o .= '<div style="display:flex;gap:8px;margin-bottom:6px;">';
    $o .= '<select id="nri-assign-vendor" data-rid="' . intval( $rid ) . '" style="flex:1;padding:8px;border:1px solid #e2e8f0;border-radius:6px;">';
    $o .= '<option value="">- Select Vendor -</option>';
    if (!empty($vendor_profiles)) {
        foreach ($vendor_profiles as $vp) {
            $sel = ((string)$current_vendor_id === (string)$vp->id) ? 'selected' : '';
            $o .= '<option value="vp_' . intval($vp->id) . '" ' . $sel . '>' . esc_html($vp->name) . ($vp->phone ? ' - '.$vp->phone : '') . '</option>';
        }
    }
    // Also show WP users with vendor role as fallback
    foreach ( $all_vendors as $v ) {
        $sel = ((int)$current_vendor_id === $v->ID && !preg_match('/^vp_/', (string)$current_vendor_id)) ? 'selected' : '';
        $o .= '<option value="wp_' . intval( $v->ID ) . '" ' . $sel . '>' . esc_html( $v->display_name ) . ' (WP)</option>';
    }
    $o .= '</select>';
    $o .= '<button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-do-assign-vendor" data-rid="' . intval( $rid ) . '">Save Vendor</button></div>';
    $o .= '<div id="nri-vendor-current" style="font-size:12px;color:#64748b;margin-bottom:4px;">Currently assigned: <strong>' . esc_html($current_vendor_name) . '</strong></div>';
    // Show WA number if available
    if ($current_vendor_id) {
        $cv_full = $wpdb->get_row($wpdb->prepare("SELECT whatsapp, phone FROM {$wpdb->prefix}nri_vendors WHERE id=%d", $current_vendor_id));
        if ($cv_full && $cv_full->whatsapp) {
            $o .= '<div style="font-size:11px;color:#25d366;margin-bottom:8px;"> WA: ' . esc_html($cv_full->whatsapp) . '</div>';
        }
    }
    $o .= '<div id="nri-assign-msg" style="font-size:12px;padding:4px 8px;border-radius:4px;display:none;margin-top:4px;"></div></div>';
    $o .= '<div class="nri-staff-section nri-staff-section-wide"><div class="nri-staff-label">Internal Notes (not visible to client)</div>';
    $o .= '<textarea id="nri-int-notes" rows="3" data-rid="' . intval( $rid ) . '" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;box-sizing:border-box;">' . esc_textarea( $meta['internal_notes'] ) . '</textarea>';
    $o .= '<button class="nri-btn nri-btn-ghost nri-btn-sm" id="nri-do-save-note" data-rid="' . intval( $rid ) . '" style="margin-top:6px;">Save Note</button></div>';
    $o .= '</div></div></div>';
    return $o;
}

/* ============================================================
   SHORTCODE: ADMIN DASHBOARD
   ============================================================ */

add_shortcode( 'nri_admin_dashboard', 'nri_sc_admin_dashboard' );
function nri_sc_admin_dashboard( $atts ) {
    if ( ! nri_is_staff() ) { return '<div class="nri-msg-card nri-text-center"><p>Access denied. <a href="' . esc_url( home_url( '/nri-login' ) ) . '">Log in</a> as staff.</p></div>'; }
    $user = wp_get_current_user();
    $tab  = sanitize_text_field( isset( $_GET['tab'] ) ? $_GET['tab'] : 'requests' );
    $tabs = array( 'requests' => 'Requests', 'submissions' => 'Form Submissions', 'support' => 'Support Tickets', 'fields' => 'Form Fields', 'dropdowns' => 'Dropdown Data', 'bulk' => 'Bulk Import', 'types' => 'Request Types', 'settings' => 'Settings' );
    $o    = '<div class="nri-admin-wrap"><div class="nri-admin-hdr"><div><h2>Admin Dashboard</h2><p>Welcome, ' . esc_html( $user->display_name ) . '</p></div>';
    $o   .= '<div><a href="' . esc_url( wp_logout_url( home_url() ) ) . '" class="nri-btn nri-btn-ghost nri-btn-sm">Logout</a></div></div>';
    $o   .= '<div class="nri-admin-nav">';
    foreach ( $tabs as $key => $label ) {
        $href = home_url( '/admin-dashboard' . ( $key !== 'requests' ? '?tab=' . $key : '' ) );
        // Real href kept as a fallback (no-JS, open-in-new-tab, bookmarking);
        // nri-app.js intercepts the click to swap tabs via AJAX instead of a
        // full page reload, using data-tab as the lookup key.
        $o   .= '<a class="nri-nav-item ' . ( $tab === $key ? 'active' : '' ) . '" href="' . esc_url( $href ) . '" data-tab="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</a>';
    }
    $o .= '</div>';
    // Email-delivery warning: shown only while at least one saved request still has an
    // undelivered staff notification, with the real mail-server error so it can be fixed.
    if ( function_exists( 'nri_count_undelivered_admin_notifications' ) ) {
        $undelivered = nri_count_undelivered_admin_notifications();
        if ( $undelivered ) {
            $last = get_option( 'nri_last_mail_error', array() );
            $why  = ( is_array( $last ) && ! empty( $last['message'] ) ) ? $last['message'] : 'The mail server did not accept the message.';
            $o .= '<div class="nri-alert nri-alert-error" role="alert" style="margin:0 0 14px;"><strong>' . intval( count( $undelivered ) ) . ' new request' . ( count( $undelivered ) === 1 ? '' : 's' ) . ' saved, but the staff email could not be delivered.</strong> '
                . 'Requests are safe and listed below; the system keeps retrying automatically. Please check Settings &rarr; Email/SMTP (sender address, host, password). Last mail error: <code>' . esc_html( wp_strip_all_tags( $why ) ) . '</code></div>';
        }
    }
    $o .= '<div id="nri-admin-tab-container" data-current-tab="' . esc_attr( $tab ) . '">';
    if      ( $tab === 'requests' )    { $o .= nri_admin_tab_requests(); }
    elseif  ( $tab === 'submissions' ) { $o .= nri_admin_tab_submissions(); }
    elseif  ( $tab === 'support' )     { $o .= nri_admin_tab_support(); }
    elseif  ( $tab === 'fields' )      { $o .= nri_admin_tab_fields(); }
    elseif  ( $tab === 'dropdowns' )   { $o .= nri_admin_tab_dropdowns(); }
    elseif  ( $tab === 'bulk' )        { $o .= nri_admin_tab_bulk(); }
    elseif  ( $tab === 'types' )       { $o .= nri_admin_tab_types(); }
    elseif  ( $tab === 'settings' )    { $o .= nri_admin_tab_settings(); }
    $o .= '</div>';
    $o .= nri_admin_js();
    $o .= '</div>';
    return $o;
}

function nri_admin_tab_requests() {
    // Full 9-status set, matching the canonical list already used by the
    // staff "Update Status" panel on the request detail page
    // (nri_render_staff_panel() below) and the client-facing pipeline
    // display (nri_sc_request_view()) — 'ready_for_processing' and
    // 'service_not_available' were previously missing from this
    // particular array (stat cards + "All Statuses" filter dropdown +,
    // until this fix, the card's inline status selector), even though
    // both are real, already-in-use statuses elsewhere in the plugin.
    $statuses = array( 'submitted', 'under_review', 'ready_for_processing', 'approved', 'processing', 'dispatched', 'completed', 'service_not_available', 'rejected' );
    $o  = '<div class="nri-tab-content"><div class="nri-stats-strip">';
    foreach ( $statuses as $s ) {
        $q = new WP_Query( array( 'post_type' => 'nri_request', 'post_status' => 'publish', 'posts_per_page' => -1, 'meta_query' => array( array( 'key' => 'status', 'value' => $s ) ) ) );
        $c = $q->found_posts; wp_reset_postdata();
        $o .= '<div class="nri-stat-card" onclick="nriAdminFilter(\'' . esc_js( $s ) . '\')" style="border-left:4px solid ' . nri_status_color( $s ) . ';"><div class="nri-stat-num" style="color:' . nri_status_color( $s ) . '">' . intval( $c ) . '</div><div class="nri-stat-lbl">' . esc_html( nri_status_label( $s ) ) . '</div></div>';
    }
    $o .= '</div><div class="nri-tbl-toolbar"><input type="text" id="nri-admin-search" placeholder="Search by name, email, university, enrollment no., phone, remarks…" class="nri-search-input"><select id="nri-admin-status-f" class="nri-filter-sel"><option value="">All Statuses</option>';
    foreach ( $statuses as $s ) { $o .= '<option value="' . $s . '">' . esc_html( nri_status_label( $s ) ) . '</option>'; }
    $o .= '</select>';
    // Date filter — filters by the request's actual submission date/time
    // (post_date, i.e. when it was received), not any other date field.
    // "Specific Date" and "Custom Range" reveal their own date input(s);
    // everything else is applied the moment it's chosen. nri_admin_js()
    // computes nothing client-side — the filter key + any date value(s)
    // are sent to the server, and nri_compute_request_date_range()
    // (helpers.php) is the single place the actual date-range math lives,
    // shared with the Form Submissions tab so both filter identically.
    $o .= nri_render_date_filter_controls( 'nri-admin-date' );
    // Explicit "Search" button alongside "Filter" — before this, the search
    // box had no button of its own (Enter, or the unrelated "Filter" button,
    // were the only ways to trigger it), which read as broken/missing.
    // Both buttons run the exact same combined search+status+date query;
    // Search is just the more discoverable, correctly-labelled entry point
    // when what the user typed is a search term rather than a filter choice.
    $o .= '<button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-admin-search-btn">&#128269; Search</button><button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-admin-filter-btn">Filter</button><button class="nri-btn nri-btn-ghost nri-btn-sm" id="nri-admin-reset-btn">Reset</button>';
    // Pagination ("49 total · Prev 1 2 3 Next") lives in this same toolbar
    // row now, pushed to the far right via .nri-pagination-inline
    // (margin-left:auto in a flex row) instead of its own bar below the
    // list — the id (#nri-admin-pages) and the nriBuildPager() render call
    // that fills it (see nri_admin_js()) are unchanged, only where the
    // empty container sits in the markup has moved.
    // Lets the person pick a different folder for future Docs / Download
    // All / Download Selected saves — the folder chosen the first time is
    // otherwise remembered and reused silently forever (see
    // nriGetParentDirHandle() in nri-app.js), so this is the only way to
    // point it somewhere else. One shared setting for the whole browser,
    // not per-request, so one control here covers every Docs button below.
    $o .= '<button type="button" class="nri-btn nri-btn-ghost nri-btn-sm nri-change-save-folder" title="Documents currently save into a remembered folder. Click to choose a different one for future downloads.">&#128193; Change Save Folder</button>';
    $o .= '<div id="nri-admin-pages" class="nri-pagination nri-pagination-inline"></div>';
    $o .= '</div>';
    // Internal Status filter bar — a separate row of compact pill buttons
    // (one per staff-only CRM pipeline stage, plus "All"), populated by
    // JS from the same nri_get_requests response that already loads the
    // list (see nri_admin_js() below), so no extra round trip is needed
    // just to show it. Deliberately its OWN row, not squeezed into the
    // Search/Filter/Reset toolbar above: up to 21 statuses need to wrap
    // or horizontally scroll on their own without fighting the search box
    // for space, especially on a phone-width screen (see
    // .nri-istatus-bar in nri-style.css).
    //
    // Internal statuses are staff-only by construction: this entire tab
    // (nri_admin_tab_requests()) only renders inside the admin dashboard,
    // which is itself gated by nri_require_staff() on every AJAX call
    // that feeds it — nothing here is ever reachable from, or sent to,
    // any client-facing page, email, or notification.
    $o .= '<div id="nri-istatus-bar" class="nri-istatus-bar" aria-label="Filter by internal status"></div>';
    $o .= '<div class="nri-bulk-toolbar" id="nri-bulk-toolbar" style="display:none;margin-bottom:10px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:10px 14px;display:flex;gap:10px;align-items:center;">';
    $o .= '<span id="nri-bulk-count" style="font-size:13px;font-weight:600;color:#1e40af;">0 selected</span>';
    $o .= '<button class="nri-btn nri-btn-outline nri-btn-sm" id="nri-bulk-export-excel">&#128202; Export Selected (Excel)</button>';
    $o .= '<button class="nri-btn nri-btn-danger nri-btn-sm" id="nri-bulk-delete-requests">&#128465; Delete Selected</button>';
    $o .= '<button class="nri-btn nri-btn-ghost nri-btn-sm" id="nri-bulk-deselect">Clear Selection</button>';
    $o .= '</div>';
    // Card-based list (not a <table>) — each request is a compact,
    // scannable card grouping its submitted form data (Applicant /
    // Document & Academic / Location & Delivery / Remarks) instead of
    // a wall of table columns. "Select All" lives in a small header bar
    // above the card list since there's no header row to put it in.
    $o .= '<div class="nri-tbl-wrap"><div class="nri-rc-listhdr"><label class="nri-rc-selall"><input type="checkbox" id="nri-select-all-reqs" title="Select All"> Select All</label></div>';
    $o .= '<div id="nri-admin-tbody" class="nri-rc-list"><div class="nri-tbl-loading">Loading...</div></div>';
    $o .= '</div></div>';
    return $o;
}

function nri_admin_tab_support() {
    $o  = '<div class="nri-tab-content"><div class="nri-tab-hdr"><h3>Support Requests</h3><div>';
    $o .= '<select id="nri-support-status-filter" style="padding:8px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:13px;margin-right:8px;"><option value="">All Statuses</option><option value="open">Open</option><option value="in_progress">In Progress</option><option value="resolved">Resolved</option><option value="closed">Closed</option></select>';
    $o .= '<button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-load-support-btn">Load</button></div></div>';
    $o .= '<div class="nri-bulk-toolbar" id="nri-ticket-bulk-toolbar" style="display:none;margin-bottom:10px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:10px 14px;display:flex;gap:10px;align-items:center;">';
    $o .= '<span id="nri-ticket-bulk-count" style="font-size:13px;font-weight:600;color:#1e40af;">0 selected</span>';
    $o .= '<button class="nri-btn nri-btn-danger nri-btn-sm" id="nri-bulk-delete-tickets">&#128465; Delete Selected</button>';
    $o .= '<button class="nri-btn nri-btn-ghost nri-btn-sm" id="nri-ticket-bulk-deselect">Clear Selection</button>';
    $o .= '</div>';
    $o .= '<div class="nri-tbl-wrap"><table class="nri-tbl"><thead><tr><th style="width:36px;"><input type="checkbox" id="nri-select-all-tickets" title="Select All"></th><th>ID</th><th>Client</th><th>Category</th><th>Description</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>';
    $o .= '<tbody id="nri-support-tbody"><tr><td colspan="8" class="nri-tbl-loading">Click Load to show tickets</td></tr></tbody></table></div></div>';
    return $o;
}

function nri_admin_tab_fields() {
    $fields = nri_get_fields( false );
    $o  = '<div class="nri-tab-content"><div class="nri-tab-hdr"><h3>Form Fields</h3><button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-add-field-btn">+ Add Field</button></div>';
    $o .= '<p class="nri-hint" style="margin-bottom:12px;"><span style="font-size:16px;">&#9776;</span> Drag the handle on the left to reorder fields.</p>';
    $o .= '<div id="nri-add-field-panel" class="nri-panel-card" style="display:none;margin-bottom:16px;"><h4 style="margin:0 0 14px;">Add / Edit Field</h4><input type="hidden" id="nf-id" value=""><div class="nri-form-grid">';
    $o .= '<div class="nri-field"><label>Label *</label><input type="text" id="nf-label" placeholder="e.g. University Name"></div>';
    $o .= '<div class="nri-field"><label>Key (unique)</label><input type="text" id="nf-key" placeholder="e.g. university_name"></div>';
    $o .= '<div class="nri-field"><label>Type</label><select id="nf-type"><option value="text">Text</option><option value="number">Number</option><option value="textarea">Textarea</option><option value="dropdown">Dropdown</option><option value="searchable">Searchable</option><option value="radio">Radio</option><option value="file">File</option><option value="phone">Phone</option><option value="email">Email</option></select></div>';
    $o .= '<div class="nri-field"><label>Step (1-4)</label><input type="number" id="nf-step" value="1" min="1" max="4"></div>';
    $o .= '<div class="nri-field"><label>Placeholder</label><input type="text" id="nf-placeholder" placeholder="Hint text"></div>';
    $o .= '<div class="nri-field"><label>Required?</label><select id="nf-required"><option value="0">Optional</option><option value="1">Required</option></select></div>';
    $o .= '</div><div class="nri-field nri-field-full" style="margin-top:10px;"><label>Help Text / Description <span style="font-weight:400;color:#94a3b8;font-size:12px;">(shown below the field on the form)</span></label><textarea id="nf-description" rows="2" placeholder="e.g. Please upload a clear scanned copy of your document." style="width:100%;padding:8px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:13px;resize:vertical;"></textarea></div>';
    $o .= '<div class="nri-field" id="nf-opts-wrap" style="display:none;"><label>Options (comma-separated)</label><input type="text" id="nf-opts" placeholder="Option A, Option B"></div>';

    // --- Conditional Logic Section ---
    $o .= '<div style="margin-top:18px;border-top:1px solid #e2e8f0;padding-top:16px;">';
    $o .= '<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">';
    $o .= '<h5 style="margin:0;font-size:14px;font-weight:600;color:#1e293b;">&#127380; Conditional Logic</h5>';
    $o .= '<div style="display:flex;align-items:center;gap:8px;">';
    $o .= '<input type="checkbox" id="nf-cond-enabled" style="width:16px;height:16px;cursor:pointer;accent-color:#4f46e5;flex-shrink:0;">';
    $o .= '<label for="nf-cond-enabled" style="font-size:13px;color:#64748b;cursor:pointer;margin:0;">Enable conditional logic for this field</label>';
    $o .= '</div></div>';
    $o .= '<div id="nf-cond-panel" style="display:none;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:16px;">';
    $o .= '<div style="display:flex;gap:10px;align-items:center;margin-bottom:14px;flex-wrap:wrap;">';
    $o .= '<span style="font-size:13px;font-weight:600;color:#475569;">Show this field if</span>';
    $o .= '<select id="nf-cond-action" style="padding:6px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;background:#fff;">';
    $o .= '<option value="all">ALL of the following match</option><option value="any">ANY of the following match</option></select></div>';
    $o .= '<div id="nf-cond-rules" style="display:flex;flex-direction:column;gap:10px;"></div>';
    $o .= '<button type="button" id="nf-cond-add-rule" class="nri-btn nri-btn-ghost nri-btn-sm" style="margin-top:12px;">+ Add Condition</button>';
    $o .= '<p style="font-size:12px;color:#94a3b8;margin:8px 0 0;">Leave empty to always show this field. Conditions check field values in real time.</p>';
    $o .= '</div></div>';
    // --- End Conditional Logic Section ---

    $o .= '<div style="display:flex;gap:10px;margin-top:12px;"><button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-do-save-field">Save Field</button><button class="nri-btn nri-btn-ghost nri-btn-sm" id="nri-cancel-field">Cancel</button></div>';
    $o .= '<div id="nri-field-msg" class="nri-alert" style="display:none;margin-top:10px;"></div></div>';
    $o .= '<div class="nri-tbl-wrap"><table class="nri-tbl"><thead><tr><th style="width:36px;"></th><th>#</th><th>Label</th><th>Key</th><th>Type</th><th>Step</th><th>Req.</th><th>Help Text</th><th>Active</th><th>Conditions</th><th>Actions</th></tr></thead>';
    $o .= '<tbody id="nri-fields-tbody">';
    $i = 1;
    foreach ( $fields as $f ) {
        $cond_data = $f->conditions ? json_decode($f->conditions, true) : null;
        $has_cond  = !empty($cond_data) && !empty($cond_data['rules']);
        $cond_icon = $has_cond ? '<span style="color:#4f46e5;font-weight:600;font-size:12px;" title="Has conditional logic">&#127380; Yes</span>' : '<span style="color:#94a3b8;font-size:12px;">-</span>';
        $o .= '<tr data-field-id="' . intval( $f->id ) . '">';
        $o .= '<td><span class="nri-drag-handle" title="Drag to reorder">&#9776;</span></td>';
        $o .= '<td style="color:#94a3b8;">' . intval( $i++ ) . '</td>';
        $o .= '<td>' . esc_html( $f->field_label ) . '</td>';
        $o .= '<td><code>' . esc_html( $f->field_key ) . '</code></td>';
        $o .= '<td>' . esc_html( $f->field_type ) . '</td>';
        $o .= '<td>' . intval( $f->step_number ) . '</td>';
        $o .= '<td>' . ( $f->is_required ? '<span style="color:#10b981;font-weight:600;">Yes</span>' : 'No' ) . '</td>';
        $o .= '<td>' . ( $f->is_active ? '<span style="color:#10b981;font-weight:600;">On</span>' : '<span style="color:#ef4444;">Off</span>' ) . '</td>';
        $o .= '<td style="max-width:160px;color:#64748b;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="' . esc_attr( isset($f->description) ? $f->description : '' ) . '">' . ( !empty($f->description) ? esc_html( mb_strimwidth($f->description, 0, 40, '…') ) : '<span style="color:#cbd5e1;">—</span>' ) . '</td>';
        $o .= '<td>' . $cond_icon . '</td>';
        $o .= '<td style="display:flex;gap:6px;">';
        $cond_json = ( $cond_data ) ? esc_attr( wp_json_encode( $cond_data ) ) : '';
        $o .= '<button class="nri-btn nri-btn-sm nri-btn-outline nri-edit-field" data-id="' . intval( $f->id ) . '" data-label="' . esc_attr( $f->field_label ) . '" data-key="' . esc_attr( $f->field_key ) . '" data-type="' . esc_attr( $f->field_type ) . '" data-step="' . intval( $f->step_number ) . '" data-required="' . intval( $f->is_required ) . '" data-opts="' . esc_attr( $f->field_options ) . '" data-ph="' . esc_attr( $f->placeholder ) . '" data-desc="' . esc_attr( isset($f->description) ? $f->description : '' ) . '" data-conditions="' . $cond_json . '">Edit</button>';
        $o .= '<button class="nri-btn nri-btn-sm nri-btn-danger nri-del-field" data-id="' . intval( $f->id ) . '">Del</button>';
        $o .= '</td></tr>';
    }
    $o .= '</tbody></table></div>';
    // Build a JS map of all fields and their options - embedded directly in page
    // This is used by conditional logic to populate the value dropdown
    $field_opts_map = array();
    $all_fields     = nri_get_fields( false );
    foreach ( $all_fields as $ff ) {
        $opts = array();
        if ( in_array( $ff->field_type, array( 'dropdown', 'searchable', 'radio' ), true ) ) {
            $db_opts = nri_get_dropdown_options( $ff->field_key );
            if ( $db_opts ) {
                $opts = $db_opts;
            } elseif ( $ff->field_options ) {
                $opts = array_values( array_filter( array_map( 'trim', explode( ',', $ff->field_options ) ) ) );
            }
        }
        $field_opts_map[ $ff->field_key ] = array(
            'label'   => $ff->field_label,
            'type'    => $ff->field_type,
            'options' => $opts,
        );
    }
    $field_map_json = wp_json_encode( $field_opts_map );
    $o .= '<script>';
    $o .= 'window.NRI_FIELD_MAP = ' . $field_map_json . ';';
    $o .= 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",function(){jQuery(document).trigger("nri:fields_rendered");});}else{jQuery(document).trigger("nri:fields_rendered");}';
    $o .= '</script>';
    $o .= '</div>';
    return $o;
}

function nri_admin_tab_dropdowns() {
    global $wpdb;
    $fkeys = $wpdb->get_results( "SELECT field_key, field_label FROM {$wpdb->prefix}nri_fields WHERE field_type IN ('dropdown','searchable') AND is_active=1" );
    $o  = '<div class="nri-tab-content"><div class="nri-tab-hdr"><h3>Dropdown Data Manager</h3></div>';
    $o .= '<div class="nri-dd-controls"><select id="nri-dd-fkey" style="padding:9px 14px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;"><option value="">- Select Field -</option>';
    foreach ( $fkeys as $fk ) { $o .= '<option value="' . esc_attr( $fk->field_key ) . '">' . esc_html( $fk->field_label ) . '</option>'; }
    $o .= '</select><input type="text" id="nri-dd-search" placeholder="Search options..." style="padding:9px 14px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;flex:1;max-width:260px;">';
    $o .= '<div id="nri-dd-btns" style="display:none;gap:8px;"><button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-dd-add-btn">+ Add Option</button>';
    $o .= '<button class="nri-btn nri-btn-danger nri-btn-sm" id="nri-dd-bulk-del" style="display:none;">Delete Selected</button>';
    $o .= '<span id="nri-dd-sel-count" style="font-size:13px;color:#64748b;align-self:center;"></span></div></div>';
    $o .= '<div id="nri-dd-form" class="nri-panel-card" style="display:none;margin:12px 0;"><h4 id="nri-dd-form-title" style="margin:0 0 12px;">Add Option</h4>';
    $o .= '<div style="display:flex;gap:10px;"><input type="hidden" id="nri-dd-edit-id" value=""><input type="text" id="nri-dd-val" placeholder="Option value" style="flex:1;padding:9px 14px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;">';
    $o .= '<button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-dd-do-save">Save</button><button class="nri-btn nri-btn-ghost nri-btn-sm" id="nri-dd-cancel">Cancel</button></div>';
    $o .= '<div id="nri-dd-form-msg" class="nri-alert" style="display:none;margin-top:10px;"></div></div>';
    $o .= '<div id="nri-dd-table-wrap" class="nri-tbl-wrap" style="display:none;"><table class="nri-tbl"><thead><tr><th style="width:40px;"><input type="checkbox" id="nri-dd-all"></th><th>#</th><th>Option Value</th><th style="width:160px;">Actions</th></tr></thead>';
    $o .= '<tbody id="nri-dd-tbody"><tr><td colspan="4" class="nri-tbl-loading">Select a field above</td></tr></tbody></table>';
    $o .= '<div id="nri-dd-pages" class="nri-pagination"></div></div></div>';
    return $o;
}

function nri_admin_tab_bulk() {
    global $wpdb;
    $fkeys = $wpdb->get_results( "SELECT field_key, field_label FROM {$wpdb->prefix}nri_fields WHERE field_type IN ('dropdown','searchable') AND is_active=1" );
    $o  = '<div class="nri-tab-content"><div class="nri-tab-hdr"><h3>Bulk Import</h3></div>';
    $o .= '<div class="nri-panel-card" style="margin-bottom:16px;"><div class="nri-form-grid">';
    $o .= '<div class="nri-field"><label>Target Field *</label><select id="nri-bulk-fkey" style="width:100%;padding:9px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;"><option value="">- Select -</option>';
    foreach ( $fkeys as $fk ) { $o .= '<option value="' . esc_attr( $fk->field_key ) . '">' . esc_html( $fk->field_label ) . '</option>'; }
    $o .= '</select></div><div class="nri-field"><label>Import Mode</label><select id="nri-bulk-mode" style="width:100%;padding:9px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;"><option value="append">Append to existing</option><option value="replace">Replace all existing</option></select></div>';
    $o .= '</div></div>';
    $o .= '<div class="nri-bulk-tabs"><button class="nri-bulk-tab active" data-bt="file">Upload CSV</button><button class="nri-bulk-tab" data-bt="paste">Paste Data</button></div>';
    $o .= '<div id="nri-bt-file" class="nri-bulk-pane nri-panel-card"><p style="color:#64748b;margin:0 0 16px;">Upload a CSV file - one value per row.</p>';
    $o .= '<div class="nri-dropzone" id="nri-csv-drop" style="cursor:pointer;" onclick="document.getElementById(\'nri-csv-file\').click()"><input type="file" id="nri-csv-file" accept=".csv,.txt" style="display:none">';
    $o .= '<div class="nri-dz-inner"><div class="nri-dz-icon">&#128202;</div><p>Drop CSV here or click to browse</p><p class="nri-hint-sm">One value per row, no header</p></div></div>';
    $o .= '<div id="nri-csv-preview" style="display:none;margin-top:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px;">';
    $o .= '<strong style="font-size:13px;">Preview</strong><span id="nri-csv-total" style="font-size:12px;color:#94a3b8;margin-left:12px;"></span>';
    $o .= '<ul id="nri-csv-prev-list" style="margin:8px 0;padding-left:20px;font-size:13px;color:#475569;"></ul></div>';
    $o .= '<div style="margin-top:16px;display:flex;gap:10px;"><button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-do-csv-import" disabled>Import File</button>';
    $o .= '<a href="data:text/csv;charset=utf-8,University+of+Delhi%0AUniversity+of+Mumbai%0AAnna+University" download="sample.csv" class="nri-btn nri-btn-ghost nri-btn-sm">Sample CSV</a></div></div>';
    $o .= '<div id="nri-bt-paste" class="nri-bulk-pane nri-panel-card" style="display:none;">';
    $o .= '<div class="nri-format-pills"><button class="nri-fp active" data-fmt="lines">One per line</button><button class="nri-fp" data-fmt="comma">Comma-separated</button><button class="nri-fp" data-fmt="json">JSON array</button></div>';
    $o .= '<div class="nri-field" style="margin-top:12px;"><label>Paste data here:</label><textarea id="nri-paste-data" rows="8" placeholder="University of Delhi&#10;University of Mumbai"></textarea></div>';
    $o .= '<div id="nri-paste-preview" style="display:none;margin-bottom:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px;">';
    $o .= '<strong style="font-size:13px;">Parsed Preview</strong><span id="nri-paste-count" style="font-size:12px;color:#64748b;margin-left:8px;font-weight:600;"></span>';
    $o .= '<div id="nri-paste-prev-list" style="font-size:13px;color:#475569;max-height:100px;overflow-y:auto;margin-top:8px;"></div>';
    $o .= '<div id="nri-paste-err" class="nri-alert nri-alert-error" style="display:none;margin-top:8px;"></div></div>';
    $o .= '<div style="display:flex;gap:10px;"><button class="nri-btn nri-btn-outline nri-btn-sm" id="nri-parse-paste">Parse &amp; Preview</button><button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-do-paste-import" disabled>Import</button></div></div>';
    $o .= '<div id="nri-bulk-msg" class="nri-alert" style="display:none;margin-top:12px;"></div></div>';
    return $o;
}

function nri_admin_tab_types() {
    $types = nri_get_request_types( false );
    $o  = '<div class="nri-tab-content">';
    $o .= '<div class="nri-tab-hdr"><h3>Service / Request Types</h3><button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-add-type-btn">+ Add Type</button></div>';
    $o .= '<p style="color:#64748b;font-size:13px;margin-bottom:16px;">These categories appear in the service request modal.</p>';

    // Add/Edit form
    $o .= '<div id="nri-type-form" class="nri-panel-card" style="display:none;margin-bottom:16px;">';
    $o .= '<h4 id="nri-type-form-title" style="margin:0 0 14px;">Add Type</h4>';
    $o .= '<input type="hidden" id="nri-type-id" value="">';
    $o .= '<div class="nri-form-grid">';
    $o .= '<div class="nri-field"><label>Name *</label><input type="text" id="nri-type-name" placeholder="e.g. Transcript Request"></div>';
    $o .= '<div class="nri-field"><label>Description</label><input type="text" id="nri-type-desc" placeholder="Brief description"></div>';
    $o .= '</div>';
    $o .= '<div style="display:flex;gap:10px;margin-top:12px;">';
    $o .= '<button class="nri-btn nri-btn-primary nri-btn-sm" id="nri-do-save-type">Save</button>';
    $o .= '<button class="nri-btn nri-btn-ghost nri-btn-sm" id="nri-cancel-type">Cancel</button>';
    $o .= '</div>';
    $o .= '<div id="nri-type-msg" class="nri-alert" style="display:none;margin-top:10px;"></div>';
    $o .= '</div>';

    // Bulk toolbar — shown when 1+ checked
    $o .= '<div id="nri-type-bulk-bar" style="display:none;align-items:center;gap:10px;padding:10px 14px;background:#fff7ed;border:1px solid #fed7aa;border-radius:8px;margin-bottom:12px;">';
    $o .= '<span id="nri-type-bulk-count" style="font-size:13px;color:#92400e;font-weight:600;"></span>';
    $o .= '<button class="nri-btn nri-btn-danger nri-btn-sm" id="nri-type-bulk-del">&#128465; Delete Selected</button>';
    $o .= '<button class="nri-btn nri-btn-ghost nri-btn-sm" id="nri-type-bulk-clear">Clear</button>';
    $o .= '</div>';

    $o .= '<div class="nri-tbl-wrap"><table class="nri-tbl"><thead><tr>';
    $o .= '<th style="width:38px;"><input type="checkbox" id="nri-type-sel-all" title="Select all" style="width:15px;height:15px;"></th>';
    $o .= '<th>Name</th><th>Description</th><th>Active</th><th>Actions</th>';
    $o .= '</tr></thead><tbody>';
    if ( empty( $types ) ) {
        $o .= '<tr><td colspan="5" class="nri-tbl-empty">No types found. Add one above.</td></tr>';
    } else {
        foreach ( $types as $t ) {
            $o .= '<tr class="nri-type-row">';
            $o .= '<td><input type="checkbox" class="nri-type-chk" data-id="' . intval( $t->id ) . '" style="width:15px;height:15px;"></td>';
            $o .= '<td><strong>' . esc_html( $t->name ) . '</strong></td>';
            $o .= '<td style="color:#64748b;font-size:13px;">' . esc_html( $t->description ) . '</td>';
            $o .= '<td>' . ( $t->is_active ? '<span style="color:#10b981;font-weight:600;">Active</span>' : '<span style="color:#ef4444;">Off</span>' ) . '</td>';
            $o .= '<td style="display:flex;gap:6px;">';
            $o .= '<button class="nri-btn nri-btn-sm nri-btn-outline nri-edit-type" data-id="' . intval( $t->id ) . '" data-name="' . esc_attr( $t->name ) . '" data-desc="' . esc_attr( $t->description ) . '">Edit</button>';
            $o .= '<button class="nri-btn nri-btn-sm nri-btn-danger nri-del-type" data-id="' . intval( $t->id ) . '">Delete</button>';
            $o .= '</td></tr>';
        }
    }
    $o .= '</tbody></table></div></div>';
    return $o;
}


function nri_admin_js() {
    $o  = '<script>';
    // These vars/functions are declared once, outside #nri-admin-tab-container,
    // so an AJAX tab-swap never destroys them — nri-app.js's SPA controller
    // calls window.nriLoadAdminRequests() again each time the Requests tab
    // is (re)shown instead of relying on this script re-executing.
    $o .= 'var _page=1,_status="",_search="",_dateFilter="",_dateFrom="",_dateTo="",_internalStatus="";';
    // Client-facing status list for the card's inline status <select> —
    // same 7 statuses already offered by the "All Statuses" filter
    // dropdown above (nri_admin_tab_requests()), built once here from
    // nri_status_label()/nri_status_color() (helpers.php) so the card
    // selector can never drift out of sync with what those return.
    // Same 9-status canonical list as $statuses in nri_admin_tab_requests()
    // above — this was the actual bug: this array (the card's inline
    // status <select>) had silently drifted to a 7-status subset, missing
    // 'ready_for_processing' and 'service_not_available', both of which
    // are real statuses already used by the staff "Update Status" panel,
    // the client-facing pipeline display, and their own notification
    // email templates.
    $client_statuses = array( 'submitted', 'under_review', 'ready_for_processing', 'approved', 'processing', 'dispatched', 'completed', 'service_not_available', 'rejected' );
    $cs_js = array();
    foreach ( $client_statuses as $cs ) { $cs_js[] = array( 'value' => $cs, 'label' => nri_status_label( $cs ), 'color' => nri_status_color( $cs ) ); }
    $o .= 'var _nriClientStatuses=' . wp_json_encode( $cs_js ) . ';';
    // Renders the compact Internal Status pill bar from the same response
    // that loaded the list (istatuses = full definition list including
    // inactive ones still in use; counts = slug -> count, see
    // nri_get_internal_status_counts() in helpers.php). "All" always
    // appears first and clears the filter. Deactivated statuses only
    // render as a pill when a request in the CURRENT result set actually
    // carries them (so old data stays reachable/filterable) or when
    // they\'re the currently-active filter — otherwise they\'d clutter the
    // bar with stages staff can no longer pick anyway. Horizontal
    // scrolling on narrow screens is pure CSS (.nri-istatus-bar in
    // nri-style.css) — this just renders one <button> per status in a
    // row, in exactly the sort_order the admin configured.
    $o .= 'function nriRenderIStatusBar(istatuses,counts){';
    $o .= 'var bar=document.getElementById("nri-istatus-bar");if(!bar)return;';
    $o .= 'var total=0;Object.keys(counts||{}).forEach(function(k){total+=counts[k]||0;});';
    $o .= 'var html="";';
    $o .= 'html+="<button type=button class=\'nri-istatus-pill"+(_internalStatus===""?" active":"")+"\' onclick=\'nriFilterInternalStatus(\\"\\")\'>All <span class=nri-istatus-count>"+total+"</span></button>";';
    $o .= '(istatuses||[]).forEach(function(s){';
    $o .= 'var c=counts&&counts[s.slug]?counts[s.slug]:0;';
    $o .= 'if(!s.is_active&&c===0&&s.slug!==_internalStatus)return;';
    $o .= 'var active=(_internalStatus===s.slug);';
    $o .= 'html+="<button type=button class=\'nri-istatus-pill"+(active?" active":"")+(s.is_active?"":" nri-istatus-inactive")+"\' style="+(active?"background:"+s.color+";border-color:"+s.color+";color:#fff;":"border-color:"+s.color+"55;color:"+s.color+";")+" onclick=\'nriFilterInternalStatus(\\""+s.slug+"\\")\'  title=\'"+s.label.replace(/\'/g,"")+(s.is_active?"":" (deactivated)")+"\'>"+s.label+" <span class=nri-istatus-count>"+c+"</span></button>";';
    $o .= '});';
    $o .= 'bar.innerHTML=html;';
    $o .= '}';
    $o .= 'window.nriRenderIStatusBar=nriRenderIStatusBar;';
    $o .= 'function nriFilterInternalStatus(slug){_internalStatus=slug;_page=1;nriLoadAdminRequests(false);}';
    $o .= 'window.nriFilterInternalStatus=nriFilterInternalStatus;';
    // Inline "change internal status" from the card itself — no page
    // reload, no navigating to the request detail page. optimistic UI:
    // the badge/select updates immediately; on failure it\'s reverted and
    // the error shown, so a rejected change (e.g. a since-deactivated
    // slug) never leaves the card silently wrong.
    $o .= 'function nriChangeInternalStatus(rid,slug,selEl){';
    $o .= 'var prevIdx=selEl?selEl.getAttribute("data-prev"):null;';
    $o .= 'jQuery.post(NRI.ajax_url,{action:"nri_set_internal_status",nonce:NRI.admin_nonce,request_id:rid,internal_status:slug},function(r){';
    $o .= 'if(!r||!r.success){alert((r&&r.data&&r.data.message)?r.data.message:"Could not update internal status.");if(selEl&&prevIdx!==null)selEl.value=prevIdx;return;}';
    $o .= 'if(selEl){selEl.setAttribute("data-prev",slug);selEl.style.borderColor=r.data.internal_status_color;selEl.style.color=r.data.internal_status_color;}';
    $o .= '});';
    $o .= '}';
    $o .= 'window.nriChangeInternalStatus=nriChangeInternalStatus;';
    // Builds the <option> list for one card\'s inline internal-status
    // <select>: every active status (in configured order) plus, if the
    // request\'s CURRENT status has since been deactivated, that one too
    // (marked "(inactive)") so the select always has a selected option
    // that actually matches the request\'s real status instead of
    // silently falling back to the first option in the list.
    $o .= 'function nriIStatusOptionsHtml(currentSlug){';
    $o .= 'var defs=window._nriIStatusDefs||[];var html="";var seenCurrent=false;';
    $o .= 'defs.forEach(function(s){';
    $o .= 'if(!s.is_active&&s.slug!==currentSlug)return;';
    $o .= 'if(s.slug===currentSlug)seenCurrent=true;';
    $o .= 'html+="<option value=\'"+s.slug+"\'"+(s.slug===currentSlug?" selected":"")+">"+s.label+(s.is_active?"":" (inactive)")+"</option>";';
    $o .= '});';
    $o .= 'if(!seenCurrent&&currentSlug){html="<option value=\'"+currentSlug+"\' selected>"+currentSlug+"</option>"+html;}';
    $o .= 'return html;';
    $o .= '}';
    $o .= 'window.nriIStatusOptionsHtml=nriIStatusOptionsHtml;';
    // Client-facing status: options builder + inline change handler,
    // mirroring the Internal Status pair above but posting to the
    // existing "nri_update_status" endpoint (nri_ajax_update_status_v2()
    // in ajax.php) — the SAME endpoint the request detail page already
    // uses, so a card-side change gets identical behavior: history log
    // entry, the nri_after_status_changed hook, and the client
    // notification email, with nothing duplicated or re-implemented here.
    $o .= 'function nriClientStatusOptionsHtml(currentVal){';
    $o .= 'var html="";var seen=false;';
    $o .= '_nriClientStatuses.forEach(function(s){if(s.value===currentVal)seen=true;html+="<option value=\'"+s.value+"\'"+(s.value===currentVal?" selected":"")+">"+s.label+"</option>";});';
    $o .= 'if(!seen&&currentVal){html="<option value=\'"+currentVal+"\' selected>"+currentVal+"</option>"+html;}';
    $o .= 'return html;';
    $o .= '}';
    $o .= 'window.nriClientStatusOptionsHtml=nriClientStatusOptionsHtml;';
    // Compact progress fill for the card's sidebar — reuses the same
    // 7-stage linear pipeline order as the request-detail page's own
    // $stages array (nri_sc_request_view() in this file), so "how far
    // along" reads consistently in both places. 'rejected' and
    // 'service_not_available' aren't points on that pipeline (they're
    // terminal off-ramps, not a further stage of it), so both render a
    // full bar in the status's own color instead of a stage fraction —
    // that reads as "this request stopped here", not "further along
    // than Completed".
    $o .= 'var NRI_PIPELINE=["submitted","under_review","ready_for_processing","approved","processing","dispatched","completed"];';
    $o .= 'function nriRcProgressPct(status){var idx=NRI_PIPELINE.indexOf(status);if(idx===-1)return 100;return Math.round(((idx+1)/NRI_PIPELINE.length)*100);}';
    $o .= 'window.nriRcProgressPct=nriRcProgressPct;';
    $o .= 'function nriChangeClientStatus(rid,slug,selEl){';
    $o .= 'var prev=selEl?selEl.getAttribute("data-prev"):null;';
    $o .= 'jQuery.post(NRI.ajax_url,{action:"nri_update_status",nonce:NRI.admin_nonce,request_id:rid,status:slug},function(r){';
    $o .= 'if(!r||!r.success){alert((r&&r.data&&r.data.message)?r.data.message:"Could not update status.");if(selEl&&prev!==null)selEl.value=prev;return;}';
    $o .= 'if(selEl){var col=_nriClientStatuses.filter(function(s){return s.value===slug;})[0];col=col?col.color:"#6b7280";selEl.setAttribute("data-prev",slug);selEl.style.borderColor=col;selEl.style.color=col;}';
    $o .= '});';
    $o .= '}';
    $o .= 'window.nriChangeClientStatus=nriChangeClientStatus;';
    $o .= 'function nriUpdateTicketStatus(id,status){jQuery.post(NRI.ajax_url,{action:"nri_update_ticket_status",nonce:NRI.admin_nonce,id:id,status:status});}';
    // Shows/hides the Specific Date / Custom Range input group that
    // matches whatever the date-filter <select> is currently set to (both
    // start hidden — see nri_render_date_filter_controls() in
    // helpers.php). $prefix (e.g. "nri-admin-date") is the same id prefix
    // passed to that PHP function, so this one JS function serves both the
    // Requests tab and the Form Submissions tab date filter.
    $o .= 'function nriInitDateFilterToggle(prefix){';
    $o .= 'var sel=document.getElementById(prefix+"-f");if(!sel)return;';
    $o .= 'var specWrap=document.getElementById(prefix+"-specific-wrap");';
    $o .= 'var rangeWrap=document.getElementById(prefix+"-range-wrap");';
    $o .= 'function sync(){';
    $o .= 'var v=sel.value;';
    $o .= 'if(specWrap)specWrap.style.display=(v==="specific_date")?"inline-flex":"none";';
    $o .= 'if(rangeWrap)rangeWrap.style.display=(v==="custom_range")?"inline-flex":"none";';
    $o .= '}';
    $o .= 'sel.addEventListener("change",sync);';
    $o .= 'sync();';
    $o .= '}';
    $o .= 'window.nriInitDateFilterToggle=nriInitDateFilterToggle;';
    // Reads the date-filter select + whichever conditional input is
    // relevant into {filter, from, to} — "specific_date" maps its single
    // date input to "from" (with "to" left empty), matching what
    // nri_compute_request_date_range() (helpers.php) expects server-side.
    // Shared by the Requests tab and Form Submissions tab.
    $o .= 'function nriReadDateFilter(prefix){';
    $o .= 'var sel=document.getElementById(prefix+"-f");var v=sel?sel.value:"";';
    $o .= 'var from="",to="";';
    $o .= 'if(v==="specific_date"){var sp=document.getElementById(prefix+"-specific");from=sp?sp.value:"";}';
    $o .= 'else if(v==="custom_range"){var fr=document.getElementById(prefix+"-from");var t=document.getElementById(prefix+"-to");from=fr?fr.value:"";to=t?t.value:"";}';
    $o .= 'return {filter:v,from:from,to:to};';
    $o .= '}';
    $o .= 'window.nriReadDateFilter=nriReadDateFilter;';
    // The "false" argument on every call below means "don\'t restore cached
    // filter state" — see the comment on nriLoadAdminRequests() itself for
    // why this matters: every one of these already just set _status/_search/
    // _page to the value the user explicitly chose, and restoring would
    // silently throw that away again.
    $o .= 'function nriAdminFilter(s){var el=document.getElementById("nri-admin-status-f");if(el)el.value=s;_status=s;_page=1;nriLoadAdminRequests(false);}';
    $o .= 'function nriGoPage(p){_page=p;nriLoadAdminRequests(false);}';
    $o .= 'function nriDeleteRequest(rid){if(!confirm("Delete this request? All messages and tickets on it will also be deleted."))return;';
    $o .= 'jQuery.post(NRI.ajax_url,{action:"nri_delete_request",nonce:NRI.admin_nonce,request_id:rid,hard_delete:1},function(r){if(r.success){nriLoadAdminRequests();}else{alert("Delete failed.");}});}';
    $o .= 'window.nriDeleteRequest=nriDeleteRequest;';
    $o .= 'function nriDeleteTicket(id){if(!confirm("Delete this ticket?"))return;';
    $o .= 'jQuery.post(NRI.ajax_url,{action:"nri_delete_ticket",nonce:NRI.admin_nonce,id:id},function(r){if(r.success){nriLoadSupportTickets();}else{alert("Delete failed.");}});}';
    $o .= 'window.nriDeleteTicket=nriDeleteTicket;';
    // Shared compact pager: renders a Prev button, a bounded page-number
    // window around the current page (with 1/last always shown + "…"
    // gaps), and a Next button — capped at a handful of buttons no matter
    // how many total pages exist. Previously every list (Requests, Form
    // Submissions) rendered ONE <button> per page with no cap, so a
    // dataset with 535 rows already produced 27 buttons, and a larger
    // install (thousands of rows) would render hundreds of DOM nodes into
    // the pagination bar on every single load/filter/search — real,
    // unbounded work that grows with total row count instead of staying
    // flat. `fn` is the goto-page function\'s name as a string (e.g.
    // "nriGoPage" or "nriSubGoPage") so this one builder serves both the
    // Requests and Form Submissions tabs.
    $o .= 'function nriBuildPager(total,pages,current,fn){';
    $o .= 'var pg="<span style=font-size:13px;color:#64748b;margin-right:8px>"+total+" total</span>";';
    $o .= 'if(pages<=1)return pg;';
    $o .= 'function btn(p,label){return "<button onclick="+fn+"("+p+") class=\'nri-btn nri-btn-sm "+(p===current?"nri-btn-primary":"nri-btn-ghost")+"\'"+(p===current?" disabled":"")+">"+(label!=null?label:p)+"</button> ";}';
    $o .= 'function ellip(){return "<span style=padding:0 6px;color:#94a3b8;font-size:13px>&#8230;</span>";}';
    $o .= 'pg+="<button onclick="+fn+"("+Math.max(1,current-1)+") class=\'nri-btn nri-btn-sm nri-btn-ghost\'"+(current<=1?" disabled":"")+">&#8249; Prev</button> ";';
    $o .= 'var win=1,nums=[1];';
    $o .= 'for(var i=current-win;i<=current+win;i++){if(i>1&&i<pages)nums.push(i);}';
    $o .= 'if(pages>1)nums.push(pages);';
    $o .= 'nums=nums.filter(function(v,i,a){return a.indexOf(v)===i;}).sort(function(a,b){return a-b;});';
    $o .= 'var prev=0;nums.forEach(function(p){if(p-prev>1)pg+=ellip();pg+=btn(p);prev=p;});';
    $o .= 'pg+=" <button onclick="+fn+"("+Math.min(pages,current+1)+") class=\'nri-btn nri-btn-sm nri-btn-ghost\'"+(current>=pages?" disabled":"")+">Next &#8250;</button>";';
    $o .= 'return pg;';
    $o .= '}';
    $o .= 'window.nriBuildPager=nriBuildPager;';
    // restoreState defaults to true — the ONLY callers that want that
    // default are a fresh tab-entry (the self-invoking call at the bottom
    // of this script, and nri-app.js's renderTab() calling
    // window.nriLoadAdminRequests() again after an AJAX tab-swap). Every
    // other caller — Filter, Search, Reset, a stat-card quick-filter, or a
    // pagination click — just explicitly set _status/_search/_page to what
    // the user chose right before calling this, and passes false so that
    // choice survives. Previously this restored the LAST SAVED state
    // unconditionally on every single call, including those — so clicking
    // Filter/Search would immediately get its own new _status/_search
    // silently overwritten by the old cached values before the request
    // even went out, making filtering look broken/stuck.
    $o .= 'function nriLoadAdminRequests(restoreState){';
    $o .= 'var tbody=document.getElementById("nri-admin-tbody");if(!tbody)return;';
    // Re-apply cached filter/search/page state (if any) before loading, so
    // switching away and back to this tab shows the same filtered view —
    // not a reset one. See nriRestoreAdminListState() in nri-app.js.
    $o .= 'if(restoreState!==false&&window.nriRestoreAdminListState){var st=window.nriRestoreAdminListState("requests");if(st){_status=st.status||"";_search=st.search||"";_dateFilter=st.dateFilter||"";_dateFrom=st.dateFrom||"";_dateTo=st.dateTo||"";_internalStatus=st.internalStatus||"";_page=st.page||1;';
    $o .= 'var sf=document.getElementById("nri-admin-status-f");if(sf)sf.value=_status;var se=document.getElementById("nri-admin-search");if(se)se.value=_search;';
    $o .= 'var df=document.getElementById("nri-admin-date-f");if(df)df.value=_dateFilter;var dsp=document.getElementById("nri-admin-date-specific");if(dsp)dsp.value=(_dateFilter==="specific_date")?_dateFrom:"";var dfr=document.getElementById("nri-admin-date-from");if(dfr)dfr.value=(_dateFilter==="custom_range")?_dateFrom:"";var dto=document.getElementById("nri-admin-date-to");if(dto)dto.value=_dateTo;';
    $o .= 'if(window.nriInitDateFilterToggle)window.nriInitDateFilterToggle("nri-admin-date");';
    $o .= '}}';
    // Only flash a "Loading..." row when the table is genuinely empty AND
    // the fetch is slow — a fast response (the common case) replaces the
    // existing rows directly, so switching filters/pages/tabs never shows
    // a visible blank-then-fill flicker.
    $o .= 'var _reqHadRows=tbody.children.length>0;';
    $o .= 'var _reqLoadTimer=_reqHadRows?null:setTimeout(function(){tbody.innerHTML="<div class=nri-tbl-loading>Loading...</div>";},200);';
    $o .= 'jQuery.ajax({url:NRI.ajax_url,type:"POST",timeout:20000,data:{action:"nri_get_requests",nonce:NRI.admin_nonce,status:_status,search:_search,date_filter:_dateFilter,date_from:_dateFrom,date_to:_dateTo,internal_status:_internalStatus,paged:_page},';
    $o .= 'error:function(xhr,st,err){if(_reqLoadTimer)clearTimeout(_reqLoadTimer);tbody.innerHTML="<div class=nri-tbl-empty style=color:#ef4444;>AJAX error: "+(err||st)+"</div>";},';
    $o .= 'success:function(r){';
    $o .= 'if(_reqLoadTimer)clearTimeout(_reqLoadTimer);';
    $o .= 'if(!r||!r.success){tbody.innerHTML="<div class=nri-tbl-empty style=color:#ef4444;>Error: "+(r&&r.data&&r.data.message?r.data.message:"Unknown error")+"</div>";return;}';
    $o .= 'if(window.nriSaveAdminListState)window.nriSaveAdminListState("requests",{status:_status,search:_search,dateFilter:_dateFilter,dateFrom:_dateFrom,dateTo:_dateTo,internalStatus:_internalStatus,page:_page});';
    $o .= 'window._nriIStatusDefs=r.data.internal_statuses||[];';
    $o .= 'nriRenderIStatusBar(r.data.internal_statuses,r.data.internal_status_counts);';
    $o .= 'var rows="";';
    // Description cache: rid -> plain-text Student Requirement
    // Description, so the card's "Copy Description" button can copy it
    // instantly without a round trip (see nri-copy-desc-btn handler in
    // nri-app.js).
    $o .= 'window._nriDescCache=window._nriDescCache||{};';
    $o .= 'r.data.requests.forEach(function(req){';
    // Compact card, not a table row. The checkbox is baked directly into
    // the card markup (not patched on afterwards) so bulk-select always
    // works on every render — first load, filter, page change, or tab
    // re-entry alike. req.card_fields is pre-rendered, already-escaped
    // HTML from nri_render_request_card_fields() (helpers.php) — the
    // grouped Applicant / Document & Academic / Location & Delivery /
    // Remarks lines, with empty fields and empty lines already omitted.
    // Two-column card: .nri-rc-main (left) carries the request\'s own
    // identity and submitted-form data — what the request IS. .nri-rc-side
    // (right) carries everything ABOUT its current handling — both status
    // selects, a compact pipeline-progress fill, and the admin-operational
    // quote/delivery/manager/vendor line — so "what is this" and "how is
    // it being handled" read as two clearly separated concerns instead of
    // one long stacked column. The action buttons (Copy/Desc/Docs/Delete/
    // View) sit in their own row at the bottom of the LEFT column instead
    // — they act on the request\'s own data, not its handling state, so
    // they read as that column\'s toolbar rather than crowding the status
    // panel. Below ~780px (.nri-req-card-admin media query in
    // nri-style.css) the two columns stack, side below main, so this
    // still reads fine on a narrow browser window.
    $o .= 'rows+="<div class=nri-req-card-admin data-rid="+req.id+">";';
    $o .= 'rows+="<div class=nri-rc-main>";';
    $o .= 'rows+="<div class=nri-rc-top><input type=checkbox class=nri-bulk-chk value="+req.id+"><strong class=nri-rc-title>"+req.request_id+"</strong></div>";';
    $o .= 'rows+="<div class=nri-rc-client>"+req.client+" <small>"+req.email+"</small> <span class=nri-rc-svc>&#8226; "+req.service+"</span></div>";';
    // Wrapped in .nri-rc-fields so the "Copy Details" button can scope
    // its DOM read to exactly this block (Applicant/Academic/Location &
    // Delivery/Remarks) and nothing else on the card.
    $o .= 'rows+="<div class=nri-rc-fields>"+req.card_fields+"</div>";';
    // Copy/Desc/Docs/Delete/View — one row at the bottom of the LEFT
    // column now (not the side panel): they act on the request\'s own
    // data (Applicant/Academic/Location/Remarks, the description, its
    // documents, the request itself), so they read as this column\'s
    // toolbar rather than crowding the status/handling panel on the
    // right. Plain buttons (not nri-view-request-link) for Copy/Desc/
    // Docs so they never trip the delegated "open request detail" click
    // handler; each has its own delegated handler in nri-app.js that
    // stops propagation.
    $o .= 'rows+="<div class=nri-rc-actions>";';
    $o .= 'rows+="<button type=button class=\'nri-btn nri-btn-xs nri-btn-outline nri-copy-details-btn\' data-rid="+req.id+" title=\'Copy Applicant, Academic, Location and Remarks details\'>&#128203; Copy</button>";';
    $o .= 'rows+="<button type=button class=\'nri-btn nri-btn-xs nri-btn-outline nri-copy-desc-btn\' data-rid="+req.id+" title=\'Copy the Student Requirement Description\'>&#10022; Desc</button>";';
    $o .= 'rows+="<button type=button class=\'nri-btn nri-btn-xs nri-btn-outline nri-download-docs-btn\' data-rid="+req.id+" title=\'Download all documents for this request\'"+(req.has_docs?"":" disabled")+">&#8595; Docs</button>";';
    $o .= 'rows+="<button onclick=nriDeleteRequest("+req.id+") class=\'nri-btn nri-btn-xs nri-btn-danger-soft\'>Delete</button>";';
    // "View" is a real link (works with no JS, middle-click, open-in-new-tab)
    // but carries nri-view-request-link + data-rid so nri-app.js can
    // intercept the click and open the request in-place instead of
    // navigating the whole browser tab away from the dashboard.
    // nri-btn-primary-soft (nri-style.css) is a muted/lighter take on
    // the usual solid primary button, per the request for "sober colors
    // instead of dark ones" on this row.
    $o .= 'rows+="<a href="+NRI.home_url+"/request/"+req.id+" class=\'nri-btn nri-btn-xs nri-btn-primary-soft nri-view-request-link\' data-rid="+req.id+">View Full Request</a>";';
    $o .= 'rows+="</div>";'; // end .nri-rc-actions
    $o .= 'rows+="</div>";'; // end .nri-rc-main
    $o .= 'window._nriDescCache[req.id]=req.description||"";';
    $o .= 'rows+="<div class=nri-rc-side>";';
    $o .= 'rows+="<div class=nri-rc-side-top><span class=nri-rc-date>"+req.date+"</span></div>";';
    // Client-facing status AND Internal status, each on its own labeled
    // row ("Status"/"Internal" captions — .nri-rc-scap) now that the
    // side column is wide enough to afford the extra row without the
    // dead-space problem an earlier pass hit at the old, narrower side
    // width (confirmed by rendering both versions). Both are still
    // inline <select>s, each posting its own change immediately via
    // nriChangeClientStatus()/nriChangeInternalStatus() (defined
    // above), so staff never have to open the request detail page just
    // to move either one along. event.stopPropagation() on
    // click/mousedown keeps a click into either dropdown from also
    // triggering the card\'s own "open request detail" delegated
    // handler. Internal Status is still staff-only, shown ONLY here
    // (the admin request card) and on the management screen, never in
    // any client-facing template, email, or notification (see the
    // "INTERNAL STATUS" section of helpers.php).
    $o .= 'rows+="<div class=nri-rc-status-group>";';
    $o .= 'rows+="<div class=nri-rc-status-row><span class=nri-rc-scap>Status</span><select class=nri-status-select data-prev=\'"+req.status+"\' style=border-color:"+req.status_color+";color:"+req.status_color+"; onchange=\'nriChangeClientStatus("+req.id+",this.value,this)\' onclick=\'event.stopPropagation()\' onmousedown=\'event.stopPropagation()\'>"+nriClientStatusOptionsHtml(req.status)+"</select></div>";';
    $o .= 'rows+="<div class=nri-rc-status-row><span class=nri-rc-scap>Internal</span><select class=\'nri-istatus-select nri-istatus-select-top\' data-prev=\'"+req.internal_status+"\' title=\'Internal status (staff only)\' style=border-color:"+req.internal_status_color+";color:"+req.internal_status_color+"; onchange=\'nriChangeInternalStatus("+req.id+",this.value,this)\' onclick=\'event.stopPropagation()\' onmousedown=\'event.stopPropagation()\'>"+nriIStatusOptionsHtml(req.internal_status)+"</select></div>";';
    $o .= 'rows+="</div>";'; // end .nri-rc-status-group
    // Compact pipeline-progress fill — a quick "how far along is this"
    // glance without opening the request, colored to match the current
    // client status (nriRcProgressPct() defined above).
    $o .= 'rows+="<div class=nri-rc-progress title=\'Pipeline progress\'><div class=nri-rc-progress-fill style=\'width:"+nriRcProgressPct(req.status)+"%;background:"+req.status_color+";\'></div></div>";';
    // Admin-operational meta (quote/manager/vendor/delivery) — not part
    // of the client\'s submitted form, so it lives in the side column with
    // the rest of the "handling" info rather than among the form-data
    // groups on the left. Stacked key:value lines (no "|" separators
    // needed now that each has its own row).
    $o .= 'rows+="<div class=nri-rc-meta>";';
    $o .= 'rows+="<span class=nri-rc-pair><span class=nri-rc-lbl>Quote</span><span class=nri-rc-val>"+req.quote+"</span></span>";';
    $o .= 'rows+="<span class=nri-rc-pair><span class=nri-rc-lbl>Delivery</span><span class=nri-rc-val>"+req.delivery+"</span></span>";';
    $o .= 'rows+="<span class=nri-rc-pair><span class=nri-rc-lbl>Manager</span><span class=nri-rc-val>"+(req.manager&&req.manager!="Unassigned"?req.manager:"—")+"</span></span>";';
    $o .= 'rows+="<span class=nri-rc-pair><span class=nri-rc-lbl>Vendor</span><span class=nri-rc-val>"+(req.vendor&&req.vendor!="Unassigned"?req.vendor:"—")+"</span></span>";';
    $o .= 'rows+="</div>";'; // end .nri-rc-meta
    $o .= 'rows+="</div>";'; // end .nri-rc-side
    $o .= 'rows+="</div>";'; // end .nri-req-card-admin
    $o .= '});';
    $o .= 'tbody.innerHTML=rows||"<div class=nri-tbl-empty>No requests found.</div>";';
    $o .= 'if(window.nriResetBulkSelection)window.nriResetBulkSelection();';
    $o .= 'document.getElementById("nri-admin-pages").innerHTML=nriBuildPager(r.data.total,r.data.pages,_page,"nriGoPage");';
    $o .= '}';
    $o .= '});';
    $o .= '}';
    $o .= 'window.nriLoadAdminRequests=nriLoadAdminRequests;';

    // Support tab loader — kept as its own function too, so the SPA
    // controller can call it directly if it wants to (e.g. re-apply a
    // cached status filter) without depending on the button existing yet.
    $o .= 'function nriLoadSupportTickets(){';
    $o .= 'var stbody=document.getElementById("nri-support-tbody");if(!stbody)return;';
    $o .= 'var stf=document.getElementById("nri-support-status-filter");var st=stf?stf.value:"";';
    $o .= 'var _stHadRows=stbody.children.length>0;';
    $o .= 'var _stLoadTimer=_stHadRows?null:setTimeout(function(){stbody.innerHTML="<tr><td colspan=8 class=nri-tbl-loading>Loading...</td></tr>";},200);';
    $o .= 'jQuery.post(NRI.ajax_url,{action:"nri_get_support_tickets",nonce:NRI.admin_nonce,status:st},function(r){';
    $o .= 'if(_stLoadTimer)clearTimeout(_stLoadTimer);';
    $o .= 'if(!r||!r.success){stbody.innerHTML="<tr><td colspan=8 class=nri-tbl-empty style=color:#ef4444;>Could not load tickets.</td></tr>";return;}';
    $o .= 'var srows="";';
    $o .= 'r.data.forEach(function(t){';
    $o .= 'srows+="<tr data-tid="+t.id+"><td style=text-align:center><input type=checkbox class=nri-ticket-bulk-chk value="+t.id+"></td><td><strong>#"+t.id+"</strong></td><td>"+(t.display_name||"Guest")+"</td><td>"+t.category+"</td><td>"+t.notes.substring(0,60)+"...</td>";';
    $o .= 'srows+="<td><span class=nri-status-chip>"+t.status+"</span></td><td>"+t.created_at.substring(0,10)+"</td>";';
    $o .= 'srows+="<td><select onchange=nriUpdateTicketStatus("+t.id+",this.value) style=font-size:12px;padding:4px;><option value=open "+(t.status=="open"?"selected":"")+">Open</option><option value=in_progress "+(t.status=="in_progress"?"selected":"")+">In Progress</option><option value=resolved "+(t.status=="resolved"?"selected":"")+">Resolved</option><option value=closed "+(t.status=="closed"?"selected":"")+">Closed</option></select> <button onclick=nriDeleteTicket("+t.id+") class=nri-btn nri-btn-sm nri-btn-danger style=margin-left:6px;>Del</button></td></tr>";';
    $o .= '});';
    $o .= 'stbody.innerHTML=srows||"<tr><td colspan=8 class=nri-tbl-empty>No support tickets.</td></tr>";';
    $o .= 'if(window.nriResetTicketBulkSelection)window.nriResetTicketBulkSelection();';
    $o .= '});';
    $o .= '}';
    $o .= 'window.nriLoadSupportTickets=nriLoadSupportTickets;';

    // Delegated (not direct) bindings: survive the Requests/Support tab
    // content being destroyed and re-created by an AJAX tab-swap, because
    // delegation is registered on document once and matches by selector at
    // click-time rather than by a reference to a specific (possibly now-
    // removed) DOM node.
    //
    // All of this — the delegated bindings AND the very first data load —
    // is wrapped in a readiness-checked init function rather than run
    // immediately. Why: this whole <script> tag is printed inline, in the
    // page body, the FIRST time the admin page loads — but jquery/sortablejs
    // and nri-app.js are enqueued with in_footer=true (see enqueue.php), so
    // on that very first load they haven't executed yet when this script
    // runs and `jQuery` doesn't exist. Calling jQuery(...) here immediately
    // used to throw a ReferenceError that killed the rest of this script
    // block — including the self-invoking nriLoadAdminRequests() call below
    // — leaving the Requests tab stuck on "Loading..." until something else
    // (an AJAX tab-swap, which runs after nri-app.js has loaded) called
    // window.nriLoadAdminRequests() again. Deferring to DOMContentLoaded
    // guarantees jQuery/nri-app.js (synchronous, non-deferred <script>
    // tags) have already run by the time this fires — mirroring the same
    // readyState-check pattern nri_admin_tab_submissions() already uses.
    $o .= 'function nriInitAdminRequestsTab(){';
    // Filter and Search both apply the current status + search box
    // together (they are not two separate query modes — status alone,
    // search alone, and both combined all go through the same call), each
    // passing restoreState=false so the values just read from the DOM are
    // not immediately clobbered by nriLoadAdminRequests()\'s own cached-state
    // restore (see the comment on that function above).
    $o .= 'jQuery(document).on("click","#nri-admin-filter-btn,#nri-admin-search-btn",function(){_status=document.getElementById("nri-admin-status-f").value;_search=document.getElementById("nri-admin-search").value;var d=nriReadDateFilter("nri-admin-date");_dateFilter=d.filter;_dateFrom=d.from;_dateTo=d.to;_page=1;nriLoadAdminRequests(false);});';
    $o .= 'jQuery(document).on("click","#nri-admin-reset-btn",function(){document.getElementById("nri-admin-status-f").value="";document.getElementById("nri-admin-search").value="";var df=document.getElementById("nri-admin-date-f");if(df)df.value="";var dsp=document.getElementById("nri-admin-date-specific");if(dsp)dsp.value="";var dfr=document.getElementById("nri-admin-date-from");if(dfr)dfr.value="";var dto=document.getElementById("nri-admin-date-to");if(dto)dto.value="";if(window.nriInitDateFilterToggle)window.nriInitDateFilterToggle("nri-admin-date");_status="";_search="";_dateFilter="";_dateFrom="";_dateTo="";_internalStatus="";_page=1;nriLoadAdminRequests(false);});';
    $o .= 'jQuery(document).on("keypress","#nri-admin-search",function(e){if(e.which===13){jQuery("#nri-admin-search-btn").click();}});';
    // Any date-filter choice applies immediately (no separate "apply"
    // click needed for the date filter specifically, matching how the
    // stat-card quick-filters behave) — Specific Date / Custom Range are
    // the exception: those need an actual date typed/picked first, so
    // picking them only reveals the input(s) (nriInitDateFilterToggle
    // above already handles that on its own "change" listener) and
    // doesn\'t fire a request until Filter/Search is clicked or the date
    // input itself changes.
    $o .= 'jQuery(document).on("change","#nri-admin-date-f",function(){var v=this.value;if(v==="specific_date"||v==="custom_range")return;var d=nriReadDateFilter("nri-admin-date");_dateFilter=d.filter;_dateFrom=d.from;_dateTo=d.to;_page=1;nriLoadAdminRequests(false);});';
    $o .= 'jQuery(document).on("change","#nri-admin-date-specific,#nri-admin-date-from,#nri-admin-date-to",function(){var d=nriReadDateFilter("nri-admin-date");if(!d.from&&!d.to)return;_dateFilter=d.filter;_dateFrom=d.from;_dateTo=d.to;_page=1;nriLoadAdminRequests(false);});';
    $o .= 'jQuery(document).on("click","#nri-load-support-btn",function(){nriLoadSupportTickets();});';
    $o .= 'nriInitDateFilterToggle("nri-admin-date");';
    // nriLoadAdminRequests() itself is a no-op if #nri-admin-tbody isn\'t on
    // the page (i.e. a different tab loaded first), so this is safe to call
    // unconditionally. Subsequent tab entries are additionally driven by
    // nri-app.js's SPA controller calling window.nriLoadAdminRequests()
    // directly (see renderTab() in nri-app.js) — this call only covers the
    // very first full page load, and DOES want to restore cached state
    // (the default), since it\'s a tab-entry, not an explicit user action.
    $o .= 'nriLoadAdminRequests();';
    $o .= '}';
    $o .= 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",nriInitAdminRequestsTab);}else{nriInitAdminRequestsTab();}';
    $o .= '</script>';

    return $o;
}

/* ============================================================
   HELPER: Form Details pane (used inside nri_sc_request_view)
   ============================================================ */
function nri_render_form_details_pane( $rid, $fd, $docs, $is_staff, $meta ) {
    global $wpdb;
    $fields_rows = $wpdb->get_results( "SELECT field_key, field_label, field_type FROM {$wpdb->prefix}nri_fields ORDER BY sort_order ASC" );
    $label_map   = array();
    $type_map    = array();
    foreach ( $fields_rows as $fr ) {
        $label_map[ 'field_' . $fr->field_key ] = $fr->field_label;
        $type_map[  'field_' . $fr->field_key ] = $fr->field_type;
    }

    $req_label = $meta['request_id'] ? $meta['request_id'] : '#' . $rid;

    $o  = '<div id="nri-ot-formdetails" class="nri-ot-pane" style="display:none;">';
    $o .= '<div class="nri-panel-card" style="margin:0;">';

    // Download bar — uses modern nri_export_submission handler (same as Submissions section)
    $export_base_args = array(
        'nonce'      => wp_create_nonce( 'nri_admin_nonce' ),
        'request_id' => $rid,
    );
    $exp_pdf   = esc_url( add_query_arg( array_merge( $export_base_args, array( 'action' => 'nri_export_submission', 'format' => 'pdf'  ) ), admin_url( 'admin-ajax.php' ) ) );
    $exp_png   = esc_url( add_query_arg( array_merge( $export_base_args, array( 'action' => 'nri_export_submission', 'format' => 'png'  ) ), admin_url( 'admin-ajax.php' ) ) );
    $exp_docx  = esc_url( add_query_arg( array_merge( $export_base_args, array( 'action' => 'nri_export_submission', 'format' => 'docx' ) ), admin_url( 'admin-ajax.php' ) ) );
    $exp_xlsx  = esc_url( add_query_arg( array_merge( $export_base_args, array( 'action' => 'nri_export_submission', 'format' => 'xlsx' ) ), admin_url( 'admin-ajax.php' ) ) );

    $o .= '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;padding:14px 16px;background:#f8fafc;border-radius:10px;border:1px solid #e2e8f0;align-items:center;">';
    $o .= '<span style="font-size:13px;font-weight:600;color:#475569;margin-right:4px;">&#8595; Download As:</span>';
    $o .= '<a href="' . $exp_pdf  . '" target="_blank" class="nri-btn nri-btn-primary nri-btn-sm">&#128196; PDF</a>';
    $o .= '<a href="' . $exp_png  . '" target="_blank" class="nri-btn nri-btn-outline nri-btn-sm">&#128247; PNG / Image</a>';
    if ( $is_staff ) {
        $o .= '<a href="' . $exp_docx . '" class="nri-btn nri-btn-outline nri-btn-sm">&#128221; Word (.docx)</a>';
        $o .= '<a href="' . $exp_xlsx . '" class="nri-btn nri-btn-outline nri-btn-sm">&#128202; Excel (.xlsx)</a>';
    }
    $o .= '</div>';

    // Student Requirement Description — the internal, deterministic
    // rule-based summary engine (nri_generate_requirement_description()
    // in helpers.php); never an external AI call. Shown for both staff
    // and the client, but editing/regenerating is staff-only.
    $req_desc = nri_get_requirement_description( $rid, $meta );
    $o .= '<div class="nri-req-desc-panel" data-rid="' . intval( $rid ) . '">';
    $o .= '<div class="nri-req-desc-hdr"><h4>&#10022; Student Requirement Description</h4>';
    $o .= '<span class="nri-req-desc-badge ' . ( $req_desc['is_manual'] ? 'nri-req-desc-manual' : 'nri-req-desc-auto' ) . '">' . ( $req_desc['is_manual'] ? 'Manually Edited' : 'Auto-Generated' ) . '</span>';
    if ( $req_desc['stale'] ) {
        $o .= '<span class="nri-req-desc-badge nri-req-desc-stale" title="The request\'s form data has changed since this description was last generated/saved.">Source data changed</span>';
    }
    $o .= '</div>';
    $o .= '<div class="nri-req-desc-text" id="nri-req-desc-text-' . intval( $rid ) . '">' . nl2br( esc_html( $req_desc['text'] ) ) . '</div>';
    if ( $is_staff ) {
        $o .= '<textarea class="nri-req-desc-edit" id="nri-req-desc-edit-' . intval( $rid ) . '" style="display:none;">' . esc_textarea( $req_desc['text'] ) . '</textarea>';
    }
    $o .= '<div class="nri-req-desc-actions">';
    $o .= '<button type="button" class="nri-btn nri-btn-sm nri-btn-outline nri-copy-desc-btn" data-rid="' . intval( $rid ) . '" data-desc-text="' . esc_attr( $req_desc['text'] ) . '">&#10022; Copy Description</button>';
    if ( $is_staff ) {
        $o .= '<button type="button" class="nri-btn nri-btn-sm nri-btn-ghost nri-regen-desc-btn" data-rid="' . intval( $rid ) . '" data-manual="' . ( $req_desc['is_manual'] ? '1' : '0' ) . '">&#8635; Regenerate</button>';
        $o .= '<button type="button" class="nri-btn nri-btn-sm nri-btn-ghost nri-edit-desc-btn" data-rid="' . intval( $rid ) . '">&#9998; Edit</button>';
        $o .= '<button type="button" class="nri-btn nri-btn-sm nri-btn-primary nri-save-desc-btn" data-rid="' . intval( $rid ) . '" style="display:none;">Save</button>';
        $o .= '<button type="button" class="nri-btn nri-btn-sm nri-btn-ghost nri-cancel-desc-btn" data-rid="' . intval( $rid ) . '" style="display:none;">Cancel</button>';
    }
    $o .= '</div></div>';

    // The printable content wrapper
    $o .= '<div id="nri-formdetail-printable-' . intval( $rid ) . '">';

    // Form fields
    $o .= '<h4 style="font-size:15px;font-weight:700;color:#1e293b;margin:0 0 14px;border-bottom:2px solid #e2e8f0;padding-bottom:8px;">&#128203; Submitted Form Data</h4>';
    $o .= '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;margin-bottom:24px;">';
    foreach ( $fd as $key => $val ) {
        if ( $key === 'field_documents' ) { continue; }
        $label   = isset( $label_map[ $key ] ) ? $label_map[ $key ] : ucwords( str_replace( array( 'field_', '_' ), array( '', ' ' ), $key ) );
        $display = is_array( $val ) ? implode( ', ', $val ) : (string) $val;
        if ( $display === '' ) { continue; }
        $o .= '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 12px;">';
        $o .= '<div style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:3px;">' . esc_html( $label ) . '</div>';
        $o .= '<div style="font-size:14px;color:#1e293b;font-weight:500;">' . esc_html( $display ) . '</div>';
        $o .= '</div>';
    }
    $o .= '</div>';

    // Documents — with multiselect + bulk download
    if ( ! empty( $docs ) ) {
        $o .= '<h4 style="font-size:15px;font-weight:700;color:#1e293b;margin:0 0 10px;border-bottom:2px solid #e2e8f0;padding-bottom:8px;">&#128196; Uploaded Documents (' . count( $docs ) . ')</h4>';
        // Bulk toolbar
        $o .= '<div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:#f1f5f9;border-radius:8px;margin-bottom:10px;flex-wrap:wrap;">';
        $o .= '<label style="display:flex;align-items:center;gap:6px;font-size:13px;color:#475569;cursor:pointer;">';
        $o .= '<input type="checkbox" id="nri-fd-sel-all" style="width:15px;height:15px;"> Select All</label>';
        $o .= '<button class="nri-btn nri-btn-sm nri-btn-outline" id="nri-fd-dl-selected" data-rid="' . intval($rid) . '" style="display:none;">&#8595; Download Selected</button>';
        $o .= '<button class="nri-btn nri-btn-sm nri-btn-ghost" id="nri-fd-dl-all" data-rid="' . intval($rid) . '">&#8595; Download All</button>';
        $o .= '<button type="button" class="nri-btn nri-btn-ghost nri-btn-sm nri-change-save-folder" title="Documents currently save into a remembered folder. Click to choose a different one for future downloads.">&#128193; Change Folder</button>';
        if ( $is_staff ) {
            $o .= '<button class="nri-btn nri-btn-sm nri-btn-danger" id="nri-fd-del-selected" data-rid="' . intval($rid) . '" style="display:none;margin-left:auto;">&#128465; Delete Selected</button>';
        }
        $o .= '</div>';
        $o .= '<div style="display:flex;flex-direction:column;gap:8px;" id="nri-fd-docs-list">';
        foreach ( $docs as $d ) {
            $att_id  = isset( $d['file'] )     ? intval( $d['file'] ) : 0;
            $dl_url  = $att_id ? nri_get_download_url( $att_id ) : '';
            $raw_url = $att_id ? wp_get_attachment_url( $att_id ) : '';
            $fn      = $att_id ? basename( get_attached_file( $att_id ) ) : '';
            // If file is AVIF/WebP, show .png as the display name since proxy converts it
            if ( $att_id ) {
                $fn_ext = strtolower( pathinfo( $fn, PATHINFO_EXTENSION ) );
                if ( in_array( $fn_ext, array( 'avif', 'webp' ), true ) ) {
                    $fn = pathinfo( $fn, PATHINFO_FILENAME ) . '.png';
                }
            }
            $dtype   = isset( $d['doc_type'] ) ? $d['doc_type'] : 'Document';
            $is_prov = ! empty( $d['is_provider'] );
            $mime    = $att_id ? get_post_mime_type( $att_id ) : '';
            $icon    = ( strpos( $mime, 'image' ) !== false ) ? '&#128247;' : '&#128196;';
            $badge_bg = $is_prov ? '#dbeafe' : '#dcfce7';
            $badge_c  = $is_prov ? '#1d4ed8' : '#166534';
            $badge = '<span style="font-size:10px;background:' . $badge_bg . ';color:' . $badge_c . ';padding:2px 8px;border-radius:10px;font-weight:600;">' . ( $is_prov ? 'Provider' : 'Client' ) . '</span>';
            $o .= '<div class="nri-fd-doc-row" style="display:flex;align-items:center;gap:10px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 14px;" data-att-id="' . $att_id . '" data-url="' . esc_attr($dl_url) . '" data-filename="' . esc_attr($fn) . '">';
            $o .= '<input type="checkbox" class="nri-fd-doc-chk" data-att-id="' . $att_id . '" data-url="' . esc_attr($dl_url) . '" data-filename="' . esc_attr($fn) . '" style="width:15px;height:15px;flex-shrink:0;">';
            $o .= '<span style="font-size:20px;flex-shrink:0;">' . $icon . '</span>';
            $o .= '<div style="flex:1;min-width:0;"><div style="font-weight:600;font-size:13px;color:#1e293b;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' . esc_html($dtype) . '</div>';
            $o .= '<div style="font-size:12px;color:#64748b;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' . esc_html($fn) . '</div></div>';
            $o .= $badge;
            if ( $dl_url ) {
                $o .= '<a href="' . esc_url($dl_url) . '" class="nri-btn nri-btn-sm nri-btn-outline" style="flex-shrink:0;" title="Download">&#8595; Download</a>';
                $o .= '<a href="' . esc_url($raw_url) . '" target="_blank" class="nri-btn nri-btn-sm nri-btn-ghost" style="flex-shrink:0;" title="View in browser">&#128065;</a>';
            }
            if ( $is_staff && $att_id ) {
                $o .= '<button class="nri-btn nri-btn-sm nri-btn-danger nri-fd-doc-del" data-rid="' . intval($rid) . '" data-att-id="' . intval($att_id) . '" style="flex-shrink:0;" title="Delete this file">&#128465;</button>';
            }
            $o .= '</div>';
        }
        $o .= '</div>';
    } else {
        $o .= '<p class="nri-hint">No documents uploaded yet.</p>';
    }

    $o .= '</div>'; // end printable
    $o .= '</div>'; // end panel-card

    // Export buttons now use direct links to nri_export_submission (see download bar above)

    $o .= '</div>'; // end pane
    return $o;
}

/* ============================================================
   SHORTCODE: SERVICES
   ============================================================ */

add_shortcode( 'nri_services', 'nri_sc_services' );
function nri_sc_services( $atts ) {
    $types = nri_get_request_types();
    $o     = '<div class="nri-services-wrap">';
    foreach ( $types as $t ) {
        $o .= '<div class="nri-svc-card"><div class="nri-svc-icon">&#128196;</div>';
        $o .= '<h3 class="nri-svc-name">' . esc_html( $t->name ) . '</h3>';
        $o .= '<p class="nri-svc-desc">' . esc_html( $t->description ) . '</p>';
        $o .= '<a href="' . esc_url( home_url( '/request-submit' ) ) . '" class="nri-btn nri-btn-primary">Get Started</a>';
        $o .= '</div>';
    }
    $o .= '</div>';
    return $o;
}
