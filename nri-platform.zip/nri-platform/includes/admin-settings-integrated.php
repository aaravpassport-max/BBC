<?php
/**
 * Integrated Admin Settings Panel - v6.2.1
 * ALL features in one clean dashboard interface
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// Replace the settings tab with comprehensive interface
function nri_admin_tab_settings() {
    $section = isset($_GET['section']) ? sanitize_text_field($_GET['section']) : 'email_templates';
    
    $o = '<div class="nri-tab-content">';
    
    // Settings Navigation
    $o .= '<div class="nri-settings-nav" style="background: white; padding: 15px 20px; margin-bottom: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<div style="display: flex; gap: 10px; flex-wrap: wrap;">';
    
    $sections = array(
        'email_templates' => '📧 Email Templates',
        'quick_replies' => '⚡ Quick Replies',
        'holidays' => '📅 Holidays',
        'internal_statuses' => '🏷️ Internal Statuses',
        'general' => '⚙️ General Settings'
    );

    foreach ($sections as $key => $label) {
        $active = ($section === $key) ? 'nri-btn-primary' : 'nri-btn-outline';
        $o .= '<a href="?tab=settings&section=' . $key . '" class="nri-btn ' . $active . ' nri-btn-sm">' . esc_html($label) . '</a>';
    }

    $o .= '</div></div>';

    // Content based on section
    if ($section === 'email_templates') {
        $o .= nri_settings_email_templates();
    } elseif ($section === 'quick_replies') {
        $o .= nri_settings_quick_replies();
    } elseif ($section === 'holidays') {
        $o .= nri_settings_holidays();
    } elseif ($section === 'internal_statuses') {
        $o .= nri_settings_internal_statuses();
    } else {
        $o .= nri_settings_general();
    }
    
    $o .= '</div>';
    
    // Add inline JavaScript for this section
    $o .= nri_settings_js();
    
    return $o;
}

// EMAIL TEMPLATES SECTION
function nri_settings_email_templates() {
    $template_type = isset($_GET['tpl']) ? sanitize_text_field($_GET['tpl']) : 'quotation';
    $template      = nri_get_email_template($template_type);

    // Use unified list (built-in + any custom ones admin created)
    $templates = function_exists('nri_get_all_template_types') ? nri_get_all_template_types() : array(
        'quotation'            => '💰 Quotation',
        'application_received' => '✅ Application Received',
        'status_update'        => '🔄 Status Update',
        'document_reminder'    => '📄 Document Reminder',
        'completion'           => '🎉 Completion',
        'dispatch'             => '📦 Dispatch',
        'terms_conditions'     => '📋 Terms & Conditions',
    );

    // Built-in types (cannot be deleted)
    $builtin_types = array('quotation','application_received','status_update','document_reminder','completion','dispatch','terms_conditions');

    $o = '<div class="nri-settings-section">';
    $o .= '<h3 style="margin: 0 0 20px;">📧 Professional Email Templates</h3>';

    // Template selector tabs
    $o .= '<div style="display: flex; gap: 8px; margin-bottom: 20px; flex-wrap: wrap; align-items: center;">';
    foreach ($templates as $type => $label) {
        $active = ($type === $template_type) ? 'nri-btn-primary' : 'nri-btn-ghost';
        $o .= '<button class="nri-btn ' . $active . ' nri-btn-sm" onclick="location.href=\'?tab=settings&section=email_templates&tpl=' . $type . '\'">' . esc_html($label) . '</button>';
    }
    // New template button
    $o .= '<button class="nri-btn nri-btn-outline nri-btn-sm" onclick="nriCreateNewTemplate()" style="margin-left:auto;">➕ New Template</button>';
    $o .= '</div>';

    // Template editor
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<form id="nri-email-template-form" method="post">';
    $o .= '<input type="hidden" name="action" value="nri_save_email_template">';
    $o .= '<input type="hidden" name="template_type" value="' . esc_attr($template_type) . '">';
    $o .= wp_nonce_field('nri_email_template', '_nonce', true, false);

    // Subject
    $o .= '<div class="nri-field">';
    $o .= '<label><strong>Email Subject</strong></label>';
    $o .= '<input type="text" name="subject" value="' . esc_attr($template['subject']) . '" class="nri-input-lg" required style="width: 100%; padding: 10px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $o .= '<p class="nri-hint" style="font-size:12px;color:#6b7280;margin:6px 0 0;">Variables: <code>{CUSTOMER_NAME}</code> <code>{REQUEST_ID}</code> <code>{DOCUMENT_TYPE}</code> <code>{UNIVERSITY_NAME}</code> <code>{QUOTATION_AMOUNT}</code> <code>{SHIPPING_CHARGES}</code> <code>{TOTAL_AMOUNT}</code> <code>{TIMELINE}</code> <code>{DELIVERY_DATE}</code> <code>{STATUS}</code> <code>{PLATFORM}</code></p>';
    $o .= '</div>';

    // Body — with rich text / HTML toggle
    $o .= '<div class="nri-field" style="margin-top: 20px;">';
    $o .= '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">';
    $o .= '<label><strong>Email Body</strong></label>';
    $o .= '<div style="display:flex;gap:6px;">';
    $o .= '<button type="button" class="nri-btn nri-btn-sm nri-btn-outline nri-view-btn active" data-view="html" onclick="nriSwitchView(\'html\')">🖥️ HTML Source</button>';
    $o .= '<button type="button" class="nri-btn nri-btn-sm nri-btn-ghost nri-view-btn" data-view="preview" onclick="nriSwitchView(\'preview\')">👁️ Rich Preview</button>';
    $o .= '</div></div>';

    // HTML textarea (default visible)
    $o .= '<div id="nri-html-view">';
    $o .= '<textarea name="body" id="email-body" rows="18" style="width: 100%; padding: 10px; border: 1px solid #e5e7eb; border-radius: 6px; font-family: monospace; font-size: 13px; box-sizing:border-box;">' . esc_textarea($template['body']) . '</textarea>';
    $o .= '<p class="nri-hint" style="font-size:12px;color:#6b7280;margin:4px 0 0;">HTML formatting supported. Variables are replaced automatically when sending.</p>';
    $o .= '</div>';

    // Rich preview pane (hidden by default)
    $o .= '<div id="nri-preview-view" style="display:none;">';
    $o .= '<div style="border:1px solid #e5e7eb;border-radius:6px;padding:10px;background:#f9fafb;margin-bottom:6px;">';
    $o .= '<p style="margin:0 0 8px;font-size:12px;color:#6b7280;">⚠️ Rich preview shows rendered HTML. Edit in HTML Source mode. Variables shown as placeholders.</p>';
    $o .= '<iframe id="nri-preview-frame" style="width:100%;min-height:400px;border:none;border-radius:4px;background:white;" srcdoc=""></iframe>';
    $o .= '</div>';
    $o .= '</div>';
    $o .= '</div>';

    // Actions row
    $o .= '<div style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap; align-items:center;">';
    $o .= '<button type="button" class="nri-btn nri-btn-primary" onclick="nriSaveEmailTemplate()">💾 Save Template</button>';
    $o .= '<button type="button" class="nri-btn nri-btn-outline" onclick="nriResetEmailTemplate(\'' . $template_type . '\')">🔄 Reset to Default</button>';
    $o .= '<button type="button" class="nri-btn nri-btn-ghost" onclick="nriTestEmail(\'' . $template_type . '\')">📧 Send Test Email</button>';
    $o .= '<button type="button" class="nri-btn nri-btn-ghost" onclick="nriDuplicateTemplate(\'' . $template_type . '\')" style="margin-left:auto;">📋 Duplicate</button>';
    // Only show delete for custom (non-built-in) types
    if (!in_array($template_type, $builtin_types)) {
        $o .= '<button type="button" class="nri-btn nri-btn-danger nri-btn-sm" onclick="nriDeleteCustomTemplate(\'' . $template_type . '\')">🗑️ Delete</button>';
    }
    $o .= '</div>';

    $o .= '<div id="email-template-message" style="margin-top: 15px;"></div>';
    $o .= '</form>';
    $o .= '</div>';

    // Help box
    $o .= '<div style="background: #eff6ff; padding: 15px; border: 1px solid #3b82f6; border-radius: 6px; margin-top: 20px;">';
    $o .= '<h4 style="margin: 0 0 10px;">💡 Template Variables Guide</h4>';
    $o .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;font-size:13px;">';
    $vars = array(
        '{CUSTOMER_NAME}'    => 'Client\'s full name',
        '{REQUEST_ID}'       => 'Order / Request ID',
        '{DOCUMENT_TYPE}'    => 'Type of document requested (e.g. Transcript)',
        '{UNIVERSITY_NAME}'  => 'University name from form',
        '{QUOTATION_AMOUNT}' => 'Service charge amount',
        '{SHIPPING_CHARGES}' => 'Shipping charges',
        '{TOTAL_AMOUNT}'     => 'Total (service + shipping)',
        '{TIMELINE}'         => 'Working days estimate',
        '{DELIVERY_DATE}'    => 'Expected delivery date',
        '{STATUS}'           => 'Current request status',
        '{PLATFORM}'         => 'Your platform/business name',
    );
    foreach ($vars as $var => $desc) {
        $o .= '<div style="padding:3px 0;"><code style="background:#dbeafe;padding:1px 5px;border-radius:3px;font-size:12px;">' . $var . '</code> — ' . $desc . '</div>';
    }
    $o .= '</div>';
    $o .= '</div>';

    $o .= '</div>';
    return $o;
}

// QUICK REPLIES SECTION
function nri_settings_quick_replies() {
    $replies = nri_get_quick_replies();
    $editing = isset($_GET['edit']) ? sanitize_text_field($_GET['edit']) : null;
    $edit_reply = null;
    
    if ($editing) {
        foreach ($replies as $r) {
            if ($r['id'] === $editing) {
                $edit_reply = $r;
                break;
            }
        }
    }
    
    $o = '<div class="nri-settings-section">';
    $o .= '<h3 style="margin: 0 0 20px;">⚡ Quick Replies (WhatsApp Style)</h3>';
    
    $o .= '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">';
    
    // Add/Edit Form
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<h4 style="margin: 0 0 15px;">' . ($edit_reply ? '✏️ Edit Reply' : '➕ Add New Reply') . '</h4>';
    
    $o .= '<form id="nri-quick-reply-form">';
    if ($edit_reply) {
        $o .= '<input type="hidden" name="reply_id" value="' . esc_attr($edit_reply['id']) . '">';
    }
    
    $o .= '<div class="nri-field">';
    $o .= '<label>Title *</label>';
    $o .= '<input type="text" name="title" value="' . ($edit_reply ? esc_attr($edit_reply['title']) : '') . '" required style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $o .= '</div>';
    
    $o .= '<div class="nri-field">';
    $o .= '<label>Category</label>';
    $o .= '<select name="category" style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $categories = array('Documents', 'Status', 'General', 'Follow-up');
    foreach ($categories as $cat) {
        $selected = ($edit_reply && $edit_reply['category'] === $cat) ? 'selected' : '';
        $o .= '<option value="' . $cat . '" ' . $selected . '>' . $cat . '</option>';
    }
    $o .= '</select>';
    $o .= '</div>';
    
    $o .= '<div class="nri-field">';
    $o .= '<label>Reply Content *</label>';
    $o .= '<textarea name="content" rows="8" required style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">' . ($edit_reply ? esc_textarea($edit_reply['content']) : '') . '</textarea>';
    $o .= '<p class="nri-hint-sm">Use: {CUSTOMER_NAME}, {REQUEST_ID}, {TIMELINE}, {UNIVERSITY_NAME}</p>';
    $o .= '</div>';
    
    $o .= '<div style="display: flex; gap: 10px;">';
    if ($edit_reply) {
        $o .= '<button type="button" class="nri-btn nri-btn-primary nri-btn-sm" onclick="nriUpdateQuickReply()">💾 Update</button>';
        $o .= '<a href="?tab=settings&section=quick_replies" class="nri-btn nri-btn-ghost nri-btn-sm">Cancel</a>';
    } else {
        $o .= '<button type="button" class="nri-btn nri-btn-primary nri-btn-sm" onclick="nriAddQuickReply()">➕ Add Reply</button>';
    }
    $o .= '</div>';
    
    $o .= '<div id="quick-reply-message" style="margin-top: 10px;"></div>';
    $o .= '</form>';
    $o .= '</div>';
    
    // Replies List
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<h4 style="margin: 0 0 15px;">📋 All Quick Replies (' . count($replies) . ')</h4>';
    
    if (empty($replies)) {
        $o .= '<p style="color: #999; text-align: center; padding: 20px;">No quick replies yet. Add your first one!</p>';
    } else {
        // Group by category
        $by_category = array();
        foreach ($replies as $reply) {
            $cat = $reply['category'] ? $reply['category'] : 'General';
            if (!isset($by_category[$cat])) {
                $by_category[$cat] = array();
            }
            $by_category[$cat][] = $reply;
        }
        
        foreach ($by_category as $category => $category_replies) {
            $o .= '<div style="margin-bottom: 15px;">';
            $o .= '<strong style="color: #2563eb;">📁 ' . esc_html($category) . '</strong>';
            
            foreach ($category_replies as $reply) {
                $o .= '<div style="border: 1px solid #e5e7eb; padding: 10px; margin-top: 5px; border-radius: 4px; background: #f9fafb;">';
                $o .= '<div style="display: flex; justify-content: space-between; align-items: start;">';
                $o .= '<div><strong style="font-size: 14px;">' . esc_html($reply['title']) . '</strong>';
                $o .= '<div style="font-size: 12px; color: #666; margin-top: 5px;">' . esc_html(wp_trim_words($reply['content'], 15)) . '</div></div>';
                $o .= '<div style="display: flex; gap: 5px;">';
                $o .= '<a href="?tab=settings&section=quick_replies&edit=' . esc_attr($reply['id']) . '" class="nri-btn nri-btn-sm" style="padding: 4px 8px; font-size: 12px;">✏️</a>';
                $o .= '<button onclick="nriDeleteQuickReply(\'' . esc_js($reply['id']) . '\')" class="nri-btn nri-btn-danger nri-btn-sm" style="padding: 4px 8px; font-size: 12px;">🗑️</button>';
                $o .= '</div></div></div>';
            }
            
            $o .= '</div>';
        }
    }
    
    $o .= '</div>';
    
    $o .= '</div>'; // End grid
    $o .= '</div>';
    return $o;
}

// HOLIDAYS SECTION
function nri_settings_holidays() {
    $year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');
    $holidays = nri_get_holidays($year . '-01-01', $year . '-12-31');
    
    $o = '<div class="nri-settings-section">';
    $o .= '<h3 style="margin: 0 0 20px;">📅 Holiday Management & Delivery Calculator</h3>';
    
    $o .= '<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px;">';
    
    // Add Holiday Form
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<h4 style="margin: 0 0 15px;">➕ Add Holiday</h4>';
    
    $o .= '<form id="nri-holiday-form">';
    $o .= '<div class="nri-field">';
    $o .= '<label>Date *</label>';
    $o .= '<input type="date" name="holiday_date" required style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $o .= '</div>';
    
    $o .= '<div class="nri-field">';
    $o .= '<label>Holiday Name *</label>';
    $o .= '<input type="text" name="holiday_name" placeholder="e.g., Republic Day" required style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $o .= '</div>';
    
    $o .= '<div class="nri-field">';
    $o .= '<label>Type</label>';
    $o .= '<select name="holiday_type" style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $o .= '<option value="national">National Holiday</option>';
    $o .= '<option value="state">State Holiday</option>';
    $o .= '<option value="university">University Holiday</option>';
    $o .= '</select>';
    $o .= '</div>';
    
    $o .= '<button type="button" class="nri-btn nri-btn-primary nri-btn-sm nri-w100" onclick="nriAddHoliday()">➕ Add Holiday</button>';
    $o .= '<div id="holiday-message" style="margin-top: 10px;"></div>';
    $o .= '</form>';
    
    // Test Calculator
    $o .= '<hr style="margin: 20px 0;">';
    $o .= '<h4 style="margin: 0 0 10px;">🧮 Test Calculator</h4>';
    $o .= '<div class="nri-field">';
    $o .= '<label>Working Days</label>';
    $o .= '<input type="number" id="test-days" value="30" min="1" style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $o .= '</div>';
    $o .= '<button type="button" class="nri-btn nri-btn-outline nri-btn-sm nri-w100" onclick="nriTestCalculator()">🧮 Calculate Delivery Date</button>';
    $o .= '<div id="calculator-result" style="margin-top: 10px;"></div>';
    
    $o .= '</div>';
    
    // Holidays List
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    
    // Year navigation
    $o .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">';
    $o .= '<h4 style="margin: 0;">Holidays for ' . $year . ' (' . count($holidays) . ')</h4>';
    $o .= '<div style="display: flex; gap: 5px;">';
    $o .= '<a href="?tab=settings&section=holidays&year=' . ($year - 1) . '" class="nri-btn nri-btn-sm">◀ ' . ($year - 1) . '</a>';
    $o .= '<a href="?tab=settings&section=holidays&year=' . date('Y') . '" class="nri-btn nri-btn-primary nri-btn-sm">Today</a>';
    $o .= '<a href="?tab=settings&section=holidays&year=' . ($year + 1) . '" class="nri-btn nri-btn-sm">' . ($year + 1) . ' ▶</a>';
    $o .= '</div></div>';
    
    if (empty($holidays)) {
        $o .= '<p style="color: #999; text-align: center; padding: 40px;">No holidays for ' . $year . '</p>';
    } else {
        $o .= '<div style="max-height: 500px; overflow-y: auto;">';
        $o .= '<table class="nri-tbl" style="width: 100%;">';
        $o .= '<thead><tr><th>Date</th><th>Holiday</th><th>Type</th><th>Day</th><th>Action</th></tr></thead><tbody>';
        
        foreach ($holidays as $holiday) {
            $type_color = $holiday->holiday_type === 'national' ? '#10b981' : ($holiday->holiday_type === 'state' ? '#3b82f6' : '#f59e0b');
            $o .= '<tr>';
            $o .= '<td><strong>' . date('M j', strtotime($holiday->date)) . '</strong></td>';
            $o .= '<td>' . esc_html($holiday->holiday_name) . '</td>';
            $o .= '<td><span style="padding: 2px 8px; border-radius: 3px; font-size: 11px; background: ' . $type_color . '22; color: ' . $type_color . ';">' . esc_html(ucfirst($holiday->holiday_type)) . '</span></td>';
            $o .= '<td style="font-size: 12px; color: #666;">' . date('l', strtotime($holiday->date)) . '</td>';
            $o .= '<td><button onclick="nriDeleteHoliday(' . intval($holiday->id) . ')" class="nri-btn nri-btn-danger nri-btn-sm" style="padding: 4px 8px; font-size: 12px;">🗑️</button></td>';
            $o .= '</tr>';
        }
        
        $o .= '</tbody></table></div>';
    }
    
    $o .= '</div>';
    
    $o .= '</div>'; // End grid
    
    // Info box
    $o .= '<div style="background: #e0f2fe; padding: 15px; border: 1px solid #0ea5e9; border-radius: 6px; margin-top: 20px;">';
    $o .= '<h4 style="margin: 0 0 10px;">ℹ️ How Working Days Calculation Works</h4>';
    $o .= '<ul style="margin: 0; padding-left: 20px; font-size: 14px;">';
    $o .= '<li>When you set a timeline (e.g., 30 working days), the system automatically excludes weekends (Sat/Sun) and all holidays listed here</li>';
    $o .= '<li>National holidays apply to all requests</li>';
    $o .= '<li>2026 Indian holidays are already pre-loaded</li>';
    $o .= '<li>Example: 30 working days starting Jan 1, 2026 = actual delivery ~40 calendar days (excluding weekends + holidays)</li>';
    $o .= '</ul>';
    $o .= '</div>';
    
    $o .= '</div>';
    return $o;
}

// INTERNAL STATUS (CRM pipeline) MANAGEMENT — admin-only. Assigning an
// existing status to a request is a staff action (the card select in the
// Requests tab); defining/reordering/retiring the status list itself is
// gated to administrators only, matching the feature spec's "authorized
// administrators" wording and nri_require_admin() in capabilities.php.
function nri_settings_internal_statuses() {
    if ( ! nri_is_admin_user() ) {
        return '<div class="nri-settings-section"><div style="background:#fef2f2;border:1px solid #fecaca;color:#991b1b;padding:16px 20px;border-radius:8px;">Administrator access is required to manage internal statuses.</div></div>';
    }
    $rows = nri_get_internal_statuses( false );

    $o  = '<div class="nri-settings-section">';
    $o .= '<h3 style="margin: 0 0 6px;">🏷️ Internal Status Pipeline</h3>';
    $o .= '<p style="margin:0 0 20px;color:#64748b;font-size:13px;max-width:640px;">Staff-only CRM workflow stages for the Requests list. These are never shown to clients anywhere — not on their dashboard, their request page, in emails, or in notifications.</p>';

    $o .= '<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px;">';

    // Add form
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<h4 style="margin: 0 0 15px;">➕ Add Internal Status</h4>';
    $o .= '<div class="nri-field"><label>Status Name *</label><input type="text" id="nri-istatus-new-label" placeholder="e.g., Awaiting Bank Details" style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;"></div>';
    $o .= '<div class="nri-field"><label>Color</label><input type="color" id="nri-istatus-new-color" value="#6b7280" style="width: 100%; height: 38px; padding: 2px; border: 1px solid #e5e7eb; border-radius: 6px;"></div>';
    $o .= '<button type="button" class="nri-btn nri-btn-primary nri-btn-sm nri-w100" onclick="nriAddInternalStatus()">➕ Add Status</button>';
    $o .= '<div id="istatus-message" style="margin-top: 10px;"></div>';
    $o .= '<hr style="margin:20px 0;"><p style="font-size:12px;color:#94a3b8;margin:0;">Reorder with the ▲▼ arrows on each row. Deactivate a status to remove it from new selections while every request already on it keeps its label. Delete is only offered when a status is used by zero requests.</p>';
    $o .= '</div>';

    // List
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<h4 style="margin: 0 0 15px;">Pipeline Order (' . count( $rows ) . ')</h4>';
    $o .= '<div id="nri-istatus-mgmt-list" style="max-height:600px;overflow-y:auto;">';
    $o .= nri_render_internal_status_mgmt_rows( $rows );
    $o .= '</div>';
    $o .= '</div>';

    $o .= '</div></div>';
    return $o;
}

// Shared row-renderer: used both for the settings page's first render and
// for the JS-side refresh after any add/rename/reorder/toggle so the two
// never have separate markup to keep in sync.
function nri_render_internal_status_mgmt_rows( $rows ) {
    if ( empty( $rows ) ) { return '<p style="color:#999;text-align:center;padding:40px;">No internal statuses defined yet.</p>'; }
    global $wpdb;
    $o  = '<table class="nri-tbl" style="width:100%;" id="nri-istatus-mgmt-table">';
    $o .= '<thead><tr><th style="width:70px;">Order</th><th>Status</th><th style="width:70px;">In Use</th><th style="width:90px;">Active</th><th style="width:110px;">Action</th></tr></thead><tbody>';
    $n = count( $rows );
    foreach ( $rows as $i => $r ) {
        $in_use = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID=pm.post_id WHERE pm.meta_key='internal_status' AND pm.meta_value=%s AND p.post_type='nri_request' AND p.post_status='publish'",
            $r->slug
        ) );
        if ( $r->slug === 'inquiry' ) { $in_use += nri_count_requests_defaulting_to_inquiry(); }
        $o .= '<tr data-id="' . intval( $r->id ) . '">';
        $o .= '<td><button type="button" class="nri-btn nri-btn-xs nri-btn-ghost" ' . ( $i === 0 ? 'disabled' : '' ) . ' onclick="nriMoveInternalStatus(' . intval( $r->id ) . ',-1)" title="Move up">&#9650;</button> ';
        $o .= '<button type="button" class="nri-btn nri-btn-xs nri-btn-ghost" ' . ( $i === $n - 1 ? 'disabled' : '' ) . ' onclick="nriMoveInternalStatus(' . intval( $r->id ) . ',1)" title="Move down">&#9660;</button></td>';
        $o .= '<td><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:' . esc_attr( $r->color ) . ';margin-right:6px;"></span>' . esc_html( $r->label ) . '<div style="font-size:11px;color:#94a3b8;">' . esc_html( $r->slug ) . '</div></td>';
        $o .= '<td>' . intval( $in_use ) . '</td>';
        $o .= '<td><label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;"><input type="checkbox" ' . ( (int) $r->is_active === 1 ? 'checked' : '' ) . ' onchange="nriToggleInternalStatus(' . intval( $r->id ) . ',this.checked)"> ' . ( (int) $r->is_active === 1 ? 'Yes' : 'No' ) . '</label></td>';
        $o .= '<td>';
        $o .= '<button type="button" class="nri-btn nri-btn-xs nri-btn-outline" onclick="nriRenameInternalStatus(' . intval( $r->id ) . ',\'' . esc_js( $r->label ) . '\',\'' . esc_js( $r->color ) . '\')" title="Rename / recolor" style="padding:4px 6px;">&#9998;</button> ';
        $o .= '<button type="button" class="nri-btn nri-btn-xs nri-btn-danger" onclick="nriDeleteInternalStatus(' . intval( $r->id ) . ',' . intval( $in_use ) . ')" title="Delete" style="padding:4px 6px;">&#128465;</button>';
        $o .= '</td></tr>';
    }
    $o .= '</tbody></table>';
    return $o;
}

// GENERAL SETTINGS — includes full SMTP configuration
function nri_settings_general() {
    $smtp = nri_get_smtp_settings();

    // Mask stored password for display
    $pw_placeholder = get_option( 'nri_smtp_password_enc', '' ) ? '●●●●●●●●' : '';

    $o  = '<div class="nri-settings-section">';
    $o .= '<h3 style="margin:0 0 20px;">⚙️ General Settings</h3>';

    // ── Sender Identity ───────────────────────────────────────────────────────
    $o .= '<div style="background:white;border:1px solid #e5e7eb;border-radius:8px;padding:20px;margin-bottom:20px;">';
    $o .= '<h4 style="margin:0 0 16px;font-size:15px;color:#1e293b;">📧 Sender Identity</h4>';
    $o .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">From Name</label>';
    $o .= '<input type="text" name="nri_email_name" id="nri-smtp-from-name" value="' . esc_attr( $smtp['from_name'] ) . '" placeholder="Your Business Name" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">From Email</label>';
    $o .= '<input type="email" name="nri_email_from" id="nri-smtp-from-email" value="' . esc_attr( $smtp['from_set'] ) . '" placeholder="noreply@yourdomain.com (leave empty = automatic)" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '</div>';
    $o .= '<p style="margin:0;font-size:12px;color:#94a3b8;">These appear as the sender on all platform emails. The From Email <strong>must match your SMTP account</strong> or emails will be rejected/spam-filtered.</p>';
    $o .= '</div>';

    // ── SMTP Configuration ────────────────────────────────────────────────────
    $o .= '<div style="background:white;border:1px solid #e5e7eb;border-radius:8px;padding:20px;margin-bottom:20px;">';
    $o .= '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">';
    $o .= '<h4 style="margin:0;font-size:15px;color:#1e293b;">🔌 SMTP Configuration</h4>';
    $o .= '<label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer;">';
    $o .= '<input type="checkbox" id="nri-smtp-enabled" ' . ( $smtp['enabled'] ? 'checked' : '' ) . ' style="width:16px;height:16px;"> Enable SMTP (recommended)';
    $o .= '</label></div>';

    $o .= '<div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:6px;padding:12px 14px;margin-bottom:16px;font-size:13px;color:#78350f;">';
    $o .= '⚠️ <strong>Without SMTP, emails are sent via PHP mail() which is blocked or spam-filtered on most hosts.</strong> ';
    $o .= 'Configure SMTP to ensure emails reach recipients. Use Gmail, Outlook, or any transactional email service (SendGrid, Mailgun, Brevo/Sendinblue).';
    $o .= '</div>';

    $o .= '<div id="nri-smtp-fields" style="' . ( $smtp['enabled'] ? '' : 'opacity:0.5;pointer-events:none;' ) . '">';

    // Popular presets
    $o .= '<div style="margin-bottom:14px;">';
    $o .= '<label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:6px;text-transform:uppercase;letter-spacing:.05em;">Quick Presets</label>';
    $o .= '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
    $presets = array(
        'gmail'     => array( '📧 Gmail',    'smtp.gmail.com',        587, 'tls' ),
        'outlook'   => array( '📧 Outlook',  'smtp.office365.com',    587, 'tls' ),
        'yahoo'     => array( '📧 Yahoo',    'smtp.mail.yahoo.com',   587, 'tls' ),
        'brevo'     => array( '📧 Brevo',    'smtp-relay.brevo.com',  587, 'tls' ),
        'mailgun'   => array( '📧 Mailgun',  'smtp.mailgun.org',      587, 'tls' ),
        'sendgrid'  => array( '📧 SendGrid', 'smtp.sendgrid.net',     587, 'tls' ),
        'custom'    => array( '⚙️ Custom',   '',                        587, 'tls' ),
    );
    foreach ( $presets as $pk => $pv ) {
        $o .= '<button type="button" class="nri-btn nri-btn-ghost nri-btn-sm nri-smtp-preset"'
            . ' data-host="' . esc_attr($pv[1]) . '"'
            . ' data-port="' . intval($pv[2]) . '"'
            . ' data-enc="'  . esc_attr($pv[3]) . '">'
            . esc_html($pv[0]) . '</button>';
    }
    $o .= '</div></div>';

    // Host + Port + Encryption
    $o .= '<div style="display:grid;grid-template-columns:2fr 1fr 1fr;gap:12px;margin-bottom:12px;">';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">SMTP Host *</label>';
    $o .= '<input type="text" id="nri-smtp-host" value="' . esc_attr($smtp['host']) . '" placeholder="smtp.gmail.com" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">Port *</label>';
    $o .= '<input type="number" id="nri-smtp-port" value="' . intval($smtp['port']) . '" placeholder="587" min="1" max="65535" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">Encryption</label>';
    $o .= '<select id="nri-smtp-encryption" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;">';
    foreach ( array( 'tls' => 'TLS (587)', 'ssl' => 'SSL (465)', 'none' => 'None' ) as $ev => $el ) {
        $o .= '<option value="' . $ev . '" ' . ( $smtp['encryption'] === $ev ? 'selected' : '' ) . '>' . $el . '</option>';
    }
    $o .= '</select></div></div>';

    // Username + Password
    $o .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">SMTP Username</label>';
    $o .= '<input type="text" id="nri-smtp-username" value="' . esc_attr($smtp['username']) . '" placeholder="your@email.com" autocomplete="username" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">SMTP Password / App Password</label>';
    $o .= '<div style="position:relative;">';
    $o .= '<input type="password" id="nri-smtp-password" placeholder="' . esc_attr($pw_placeholder ?: 'Enter password') . '" autocomplete="new-password" style="width:100%;padding:9px 36px 9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;">';
    $o .= '<button type="button" id="nri-smtp-pw-toggle" style="position:absolute;right:8px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:16px;color:#94a3b8;" title="Show/hide">👁</button>';
    $o .= '</div>';
    if ( $pw_placeholder ) {
        $o .= '<p style="margin:4px 0 0;font-size:11px;color:#94a3b8;">Password stored. Leave blank to keep existing.</p>';
    }
    $o .= '</div></div>';

    // Gmail notice
    $o .= '<div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;padding:10px 14px;margin-bottom:12px;font-size:12px;color:#1e40af;">';
    $o .= '💡 <strong>Gmail users:</strong> Use an <a href="https://myaccount.google.com/apppasswords" target="_blank" style="color:#1d4ed8;">App Password</a> (not your regular Gmail password). ';
    $o .= 'Go to Google Account → Security → 2-Step Verification → App Passwords. Set host to smtp.gmail.com, port 587, TLS.';
    $o .= '</div>';

    $o .= '<label style="display:flex;align-items:center;gap:8px;font-size:13px;color:#64748b;cursor:pointer;margin-bottom:14px;">';
    $o .= '<input type="checkbox" id="nri-smtp-debug" ' . ( get_option('nri_smtp_debug',0) ? 'checked' : '' ) . ' style="width:14px;height:14px;">';
    $o .= 'Enable verbose SMTP debug logging (writes SMTP conversation to nri-debug.log — disable after testing)';
    $o .= '</label>';

    $o .= '</div>'; // end nri-smtp-fields

    // Actions row
    $o .= '<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">';
    $o .= '<button type="button" class="nri-btn nri-btn-primary" id="nri-save-smtp-btn">💾 Save SMTP Settings</button>';
    $o .= '<button type="button" class="nri-btn nri-btn-outline" id="nri-smtp-test-btn">📧 Send Test Email</button>';
    $o .= '<button type="button" class="nri-btn nri-btn-outline" id="nri-email-diag-btn">🩺 Run Email Diagnostics</button>';
    $o .= '<pre id="nri-email-diag-out" style="display:none;margin-top:14px;padding:14px;background:#0f172a;color:#e2e8f0;border-radius:8px;font-size:12px;line-height:1.5;white-space:pre-wrap;word-break:break-word;max-height:480px;overflow:auto;"></pre>';
    $o .= '</div>';
    $o .= '<div id="nri-smtp-msg" style="margin-top:14px;"></div>';
    $o .= '</div>'; // end smtp card

    // ── Reference table ───────────────────────────────────────────────────────
    $o .= '<div style="background:white;border:1px solid #e5e7eb;border-radius:8px;padding:20px;">';
    $o .= '<h4 style="margin:0 0 12px;font-size:14px;color:#1e293b;">📋 Common SMTP Settings Reference</h4>';
    $o .= '<table style="width:100%;border-collapse:collapse;font-size:13px;">';
    $o .= '<thead><tr style="background:#f8fafc;">';
    foreach ( array('Provider','Host','Port','Encryption','Username','Password') as $h ) {
        $o .= '<th style="padding:8px 10px;text-align:left;border:1px solid #e2e8f0;color:#475569;font-size:11px;text-transform:uppercase;letter-spacing:.05em;">' . $h . '</th>';
    }
    $o .= '</tr></thead><tbody>';
    $refs = array(
        array('Gmail',           'smtp.gmail.com',            587, 'TLS', 'your@gmail.com',    'App Password (16 chars)'),
        array('Outlook / 365',   'smtp.office365.com',        587, 'TLS', 'your@outlook.com',  'Your password'),
        array('Yahoo Mail',      'smtp.mail.yahoo.com',       587, 'TLS', 'your@yahoo.com',    'App Password'),
        array('Brevo (Sendinblue)','smtp-relay.brevo.com',    587, 'TLS', 'Your login email',  'Brevo SMTP key'),
        array('Mailgun',         'smtp.mailgun.org',          587, 'TLS', 'postmaster@domain', 'Mailgun SMTP password'),
        array('SendGrid',        'smtp.sendgrid.net',         587, 'TLS', 'apikey',            'Your API Key'),
        array('Amazon SES',      'email-smtp.us-east-1.amazonaws.com', 587, 'TLS', 'SMTP Access Key ID', 'SMTP Secret Access Key'),
    );
    foreach ( $refs as $i => $row ) {
        $bg = $i % 2 === 0 ? '#fff' : '#f8fafc';
        $o .= '<tr style="background:' . $bg . ';">';
        foreach ( $row as $j => $cell ) {
            $o .= '<td style="padding:7px 10px;border:1px solid #e2e8f0;' . ($j===0?'font-weight:600;':'') . '">' . esc_html($cell) . '</td>';
        }
        $o .= '</tr>';
    }
    $o .= '</tbody></table>';
    $o .= '</div>';

    $o .= '</div>'; // end section

    // ── Fix Existing Documents card (count loaded via AJAX to avoid page crash) ──
    $o .= '<div style="background:white;border:1px solid #fbbf24;border-radius:8px;padding:20px;margin-top:20px;">';
    $o .= '<h4 style="margin:0 0 8px;font-size:15px;color:#92400e;">🔧 Fix Existing Documents (AVIF/WebP → PNG)</h4>';
    $o .= '<p style="margin:0 0 14px;font-size:13px;color:#64748b;">If students uploaded documents that were converted to AVIF or WebP by an image optimizer, they cannot be opened when downloaded. Click Scan to check, then Convert to fix them permanently.</p>';
    $o .= '<div id="nri-fix-docs-status" style="background:#f1f5f9;border:1px solid #e2e8f0;border-radius:6px;padding:10px 14px;font-size:13px;color:#475569;margin-bottom:14px;">⏳ Click Scan to check your documents…</div>';
    $o .= '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">';
    $o .= '<button type="button" id="nri-recount-docs-btn" class="nri-btn nri-btn-outline">🔍 Scan</button>';
    $o .= '<button type="button" id="nri-fix-docs-btn" class="nri-btn nri-btn-primary" disabled>🔧 Convert to PNG</button>';
    $o .= '</div>';
    $o .= '<div id="nri-fix-docs-progress" style="display:none;margin-top:12px;">';
    $o .= '<div style="background:#e2e8f0;border-radius:4px;height:8px;overflow:hidden;margin-bottom:8px;">';
    $o .= '<div id="nri-fix-docs-bar" style="height:100%;background:linear-gradient(90deg,#f59e0b,#d97706);width:0%;transition:width .4s;border-radius:4px;"></div>';
    $o .= '</div>';
    $o .= '<div id="nri-fix-docs-msg" style="font-size:13px;color:#475569;"></div>';
    $o .= '</div>';
    $o .= '</div>';

    return $o;
}

// JavaScript for settings
function nri_settings_js() {
    ob_start();
    ?>
    <script>
    // ── View toggle: HTML Source ↔ Rich Preview ──────────────────────────────
    function nriSwitchView(view) {
        const htmlView    = document.getElementById('nri-html-view');
        const previewView = document.getElementById('nri-preview-view');
        document.querySelectorAll('.nri-view-btn').forEach(b => {
            b.classList.toggle('nri-btn-outline', b.dataset.view === view);
            b.classList.toggle('nri-btn-ghost',   b.dataset.view !== view);
            b.classList.toggle('active',           b.dataset.view === view);
        });
        if (view === 'preview') {
            htmlView.style.display    = 'none';
            previewView.style.display = 'block';
            // Render body HTML into iframe
            const body  = document.getElementById('email-body').value;
            const frame = document.getElementById('nri-preview-frame');
            frame.srcdoc = '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{margin:0;padding:0;background:#f1f5f9;font-family:Arial,sans-serif;}</style></head><body>' + body + '</body></html>';
        } else {
            htmlView.style.display    = 'block';
            previewView.style.display = 'none';
        }
    }

    // ── Save email template ──────────────────────────────────────────────────
    function nriSaveEmailTemplate() {
        const form = document.getElementById('nri-email-template-form');
        const formData = new FormData(form);
        formData.set('action', 'nri_save_email_template');
        formData.set('nonce', NRI.admin_nonce);

        const msg = document.getElementById('email-template-message');
        msg.innerHTML = '<div class="nri-alert" style="color:#555;background:#f1f5f9;padding:10px;border-radius:6px;">⏳ Saving…</div>';

        fetch(NRI.ajax_url, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    msg.innerHTML = '<div class="nri-alert nri-alert-success" style="background:#d1fae5;color:#065f46;padding:10px;border-radius:6px;">✅ Template saved successfully!</div>';
                } else {
                    const err = (data.data && data.data.message) ? data.data.message : (data.data || 'Failed to save');
                    msg.innerHTML = '<div class="nri-alert nri-alert-error" style="background:#fee2e2;color:#991b1b;padding:10px;border-radius:6px;">❌ Error: ' + err + '</div>';
                }
            })
            .catch(e => {
                msg.innerHTML = '<div class="nri-alert nri-alert-error" style="background:#fee2e2;color:#991b1b;padding:10px;border-radius:6px;">❌ Network error: ' + e.message + '</div>';
            });
    }

    // ── Reset to default ─────────────────────────────────────────────────────
    function nriResetEmailTemplate(type) {
        if (!confirm('Reset to default template? Your custom changes will be lost.')) return;
        fetch(NRI.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nri_reset_email_template&template_type=' + encodeURIComponent(type) + '&nonce=' + NRI.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('Reset failed: ' + (data.data || 'Unknown error'));
        });
    }

    // ── Send test email ──────────────────────────────────────────────────────
    function nriTestEmail(type) {
        const email = prompt('Send test email to:', '<?php echo esc_js(wp_get_current_user()->user_email); ?>');
        if (!email) return;
        fetch(NRI.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nri_test_email&template_type=' + encodeURIComponent(type) + '&test_email=' + encodeURIComponent(email) + '&nonce=' + NRI.admin_nonce
        }).then(r => r.json()).then(data => {
            alert(data.success ? '✅ Test email sent to ' + email : '❌ Failed: ' + (data.data && data.data.message ? data.data.message : data.data || 'Unknown error'));
        });
    }

    // ── Duplicate template ───────────────────────────────────────────────────
    function nriDuplicateTemplate(type) {
        const label = prompt('Name for the duplicated template:', 'Copy of template');
        if (!label || !label.trim()) return;
        fetch(NRI.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nri_duplicate_email_template&template_type=' + encodeURIComponent(type) + '&new_label=' + encodeURIComponent(label.trim()) + '&nonce=' + NRI.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) {
                alert('✅ ' + data.data.message);
                location.href = '?tab=settings&section=email_templates&tpl=' + data.data.new_type;
            } else {
                alert('❌ ' + (data.data && data.data.message ? data.data.message : 'Error'));
            }
        });
    }

    // ── Create new blank template ────────────────────────────────────────────
    function nriCreateNewTemplate() {
        const label = prompt('Name for the new template (e.g. "Payment Reminder"):');
        if (!label || !label.trim()) return;
        fetch(NRI.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nri_create_email_template&new_label=' + encodeURIComponent(label.trim()) + '&nonce=' + NRI.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) {
                alert('✅ ' + data.data.message);
                location.href = '?tab=settings&section=email_templates&tpl=' + data.data.new_type;
            } else {
                alert('❌ ' + (data.data && data.data.message ? data.data.message : 'Error'));
            }
        });
    }

    // ── Delete custom template ───────────────────────────────────────────────
    function nriDeleteCustomTemplate(type) {
        if (!confirm('Permanently delete this custom template? This cannot be undone.')) return;
        fetch(NRI.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nri_delete_custom_template&template_type=' + encodeURIComponent(type) + '&nonce=' + NRI.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) {
                location.href = '?tab=settings&section=email_templates&tpl=quotation';
            } else {
                alert('❌ ' + (data.data && data.data.message ? data.data.message : 'Error'));
            }
        });
    }

    // ── Quick Reply Functions ────────────────────────────────────────────────
    function nriAddQuickReply() {
        const form = document.getElementById('nri-quick-reply-form');
        const formData = new FormData(form);
        formData.append('action', 'nri_add_quick_reply');
        formData.set('nonce', NRI.admin_nonce);

        fetch(NRI.ajax_url, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                const msg = document.getElementById('quick-reply-message');
                if (data.success) {
                    msg.innerHTML = '<div class="nri-alert nri-alert-success" style="background:#d1fae5;color:#065f46;padding:8px 12px;border-radius:6px;">✅ Quick reply added!</div>';
                    setTimeout(() => location.reload(), 900);
                } else {
                    msg.innerHTML = '<div class="nri-alert nri-alert-error" style="background:#fee2e2;color:#991b1b;padding:8px 12px;border-radius:6px;">❌ ' + (data.data || 'Error') + '</div>';
                }
            });
    }

    function nriUpdateQuickReply() {
        const form = document.getElementById('nri-quick-reply-form');
        const formData = new FormData(form);
        formData.append('action', 'nri_update_quick_reply');
        formData.set('nonce', NRI.admin_nonce);

        fetch(NRI.ajax_url, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    location.href = '?tab=settings&section=quick_replies';
                } else {
                    alert('❌ ' + (data.data || 'Update failed'));
                }
            });
    }

    function nriDeleteQuickReply(id) {
        if (!confirm('Delete this quick reply?')) return;
        fetch(NRI.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nri_delete_quick_reply&id=' + encodeURIComponent(id) + '&nonce=' + NRI.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('❌ ' + (data.data || 'Delete failed'));
        });
    }

    // ── Holiday Functions ────────────────────────────────────────────────────
    function nriAddHoliday() {
        const form = document.getElementById('nri-holiday-form');
        const formData = new FormData(form);
        formData.append('action', 'nri_add_holiday');
        formData.set('nonce', NRI.admin_nonce);

        fetch(NRI.ajax_url, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                const msg = document.getElementById('holiday-message');
                if (data.success) {
                    msg.innerHTML = '<div class="nri-alert nri-alert-success" style="background:#d1fae5;color:#065f46;padding:8px 12px;border-radius:6px;">✅ Holiday added!</div>';
                    setTimeout(() => location.reload(), 900);
                } else {
                    const err = data.data && data.data.message ? data.data.message : (data.data || 'Error');
                    msg.innerHTML = '<div class="nri-alert nri-alert-error" style="background:#fee2e2;color:#991b1b;padding:8px 12px;border-radius:6px;">❌ ' + err + '</div>';
                }
            });
    }

    function nriDeleteHoliday(id) {
        if (!confirm('Delete this holiday?')) return;
        fetch(NRI.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nri_delete_holiday&id=' + id + '&nonce=' + NRI.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('❌ ' + (data.data || 'Delete failed'));
        });
    }

    // ── Internal Status (CRM pipeline) management ────────────────────────────
    // Every action here reloads the page on success — same convention as
    // the Holidays section just above — rather than re-rendering the
    // table in place, since the row markup (order arrows enabled/
    // disabled at the ends, per-row "in use" counts) is built server-side
    // in nri_render_internal_status_mgmt_rows() and duplicating that
    // logic in JS would be one more place for the two to drift apart.
    // This is a settings/admin-configuration screen, not the fast-moving
    // Requests list itself — the "no unnecessary reloads" requirement in
    // the spec is specifically about assigning a status to a request
    // (nriChangeInternalStatus() in shortcodes.php), which never reloads.
    function nriAddInternalStatus() {
        const label = document.getElementById('nri-istatus-new-label').value.trim();
        const color = document.getElementById('nri-istatus-new-color').value;
        const msg = document.getElementById('istatus-message');
        if (!label) { msg.innerHTML = '<div class="nri-alert nri-alert-error" style="background:#fee2e2;color:#991b1b;padding:8px 12px;border-radius:6px;">❌ Enter a status name.</div>'; return; }
        fetch(NRI.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nri_admin_save_internal_status&label=' + encodeURIComponent(label) + '&color=' + encodeURIComponent(color) + '&nonce=' + NRI.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) { msg.innerHTML = '<div class="nri-alert nri-alert-success" style="background:#d1fae5;color:#065f46;padding:8px 12px;border-radius:6px;">✅ Status added!</div>'; setTimeout(() => location.reload(), 700); }
            else { msg.innerHTML = '<div class="nri-alert nri-alert-error" style="background:#fee2e2;color:#991b1b;padding:8px 12px;border-radius:6px;">❌ ' + (data.data && data.data.message ? data.data.message : 'Error') + '</div>'; }
        });
    }
    function nriRenameInternalStatus(id, currentLabel, currentColor) {
        const label = prompt('Status name:', currentLabel);
        if (label === null) return;
        const trimmed = label.trim();
        if (!trimmed) { alert('Status name cannot be empty.'); return; }
        fetch(NRI.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nri_admin_save_internal_status&id=' + id + '&label=' + encodeURIComponent(trimmed) + '&color=' + encodeURIComponent(currentColor || '#6b7280') + '&nonce=' + NRI.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('❌ ' + (data.data && data.data.message ? data.data.message : 'Rename failed'));
        });
    }
    function nriMoveInternalStatus(id, dir) {
        const rows = Array.from(document.querySelectorAll('#nri-istatus-mgmt-table tbody tr'));
        const ids = rows.map(r => parseInt(r.getAttribute('data-id'), 10));
        const idx = ids.indexOf(id);
        const swapWith = idx + dir;
        if (idx < 0 || swapWith < 0 || swapWith >= ids.length) return;
        const tmp = ids[idx]; ids[idx] = ids[swapWith]; ids[swapWith] = tmp;
        fetch(NRI.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nri_admin_reorder_internal_statuses&order=' + ids.join(',') + '&nonce=' + NRI.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('❌ Reorder failed');
        });
    }
    function nriToggleInternalStatus(id, active) {
        fetch(NRI.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nri_admin_toggle_internal_status&id=' + id + '&active=' + (active ? '1' : '0') + '&nonce=' + NRI.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('❌ Update failed');
        });
    }
    function nriDeleteInternalStatus(id, inUse) {
        if (inUse > 0) { alert(inUse + ' request(s) currently use this status. Deactivate it instead, or reassign those requests first.'); return; }
        if (!confirm('Delete this internal status? This cannot be undone.')) return;
        fetch(NRI.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nri_admin_delete_internal_status&id=' + id + '&nonce=' + NRI.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('❌ ' + (data.data && data.data.message ? data.data.message : 'Delete failed'));
        });
    }

    // ── Test delivery calculator ─────────────────────────────────────────────
    function nriTestCalculator() {
        const days = document.getElementById('test-days').value;
        if (!days || parseInt(days) < 1) { alert('Enter a valid number of working days.'); return; }

        const result = document.getElementById('calculator-result');
        result.innerHTML = '<div style="color:#555;font-size:13px;">⏳ Calculating…</div>';

        fetch(NRI.ajax_url + '?action=nri_calculate_delivery&days=' + encodeURIComponent(days) + '&nonce=' + NRI.admin_nonce)
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    const d = data.data;
                    result.innerHTML = '<div style="background:#d1fae5;color:#065f46;padding:12px;border-radius:6px;font-size:13px;">' +
                        '<strong>📅 Delivery Date: ' + d.delivery_date_formatted + '</strong><br><br>' +
                        '• Working Days: <strong>' + d.working_days + '</strong><br>' +
                        '• Total Calendar Days: ' + d.total_calendar_days + '<br>' +
                        '• Weekends Skipped: ' + d.weekends_excluded + '<br>' +
                        '• Holidays Skipped: ' + d.holidays_excluded +
                        '</div>';
                } else {
                    const err = data.data && data.data.message ? data.data.message : (data.data || 'Calculation failed');
                    result.innerHTML = '<div style="background:#fee2e2;color:#991b1b;padding:10px;border-radius:6px;">❌ ' + err + '</div>';
                }
            })
            .catch(e => {
                result.innerHTML = '<div style="background:#fee2e2;color:#991b1b;padding:10px;border-radius:6px;">❌ Network error: ' + e.message + '</div>';
            });
    }

    // ── SMTP Settings ────────────────────────────────────────────────────────
    // Everything below this point only needs to run ONCE per page session:
    // the functions above are safe to redefine (identical code every time),
    // but the document.addEventListener(...) calls below are NOT idempotent
    // — the Settings tab can now be (re)loaded via the admin dashboard's
    // AJAX tab switcher instead of always via a full page load, and without
    // this guard, visiting Settings twice would register every one of these
    // click/change handlers twice (so each click would fire its action
    // twice, three times on a third visit, and so on).
    if (!window.__nriSettingsJsInit) {
    window.__nriSettingsJsInit = true;

    // Toggle fields enabled/disabled when checkbox changes
    document.addEventListener('change', function(e) {
        if (e.target && e.target.id === 'nri-smtp-enabled') {
            var fields = document.getElementById('nri-smtp-fields');
            if (fields) {
                fields.style.opacity       = e.target.checked ? '1'  : '0.5';
                fields.style.pointerEvents = e.target.checked ? ''   : 'none';
            }
        }
    });

    // Password show/hide toggle
    document.addEventListener('click', function(e) {
        if (e.target && e.target.id === 'nri-smtp-pw-toggle') {
            var inp = document.getElementById('nri-smtp-password');
            if (inp) {
                inp.type = (inp.type === 'password') ? 'text' : 'password';
                e.target.textContent = (inp.type === 'password') ? '👁' : '🙈';
            }
        }
    });

    // Quick preset buttons
    document.addEventListener('click', function(e) {
        var btn = e.target.closest ? e.target.closest('.nri-smtp-preset') : null;
        if (!btn) return;
        var host = btn.dataset.host, port = btn.dataset.port, enc = btn.dataset.enc;
        var hEl = document.getElementById('nri-smtp-host');
        var pEl = document.getElementById('nri-smtp-port');
        var eEl = document.getElementById('nri-smtp-encryption');
        if (hEl && host !== undefined) hEl.value = host;
        if (pEl && port)              pEl.value = port;
        if (eEl && enc)               eEl.value = enc;
        document.querySelectorAll('.nri-smtp-preset').forEach(function(b){ b.classList.remove('nri-btn-primary'); b.classList.add('nri-btn-ghost'); });
        btn.classList.remove('nri-btn-ghost'); btn.classList.add('nri-btn-primary');
    });

    // Save SMTP settings
    document.addEventListener('click', function(e) {
        if (!e.target || e.target.id !== 'nri-save-smtp-btn') return;
        var $msg = document.getElementById('nri-smtp-msg');
        var btn  = e.target;
        btn.textContent = '⏳ Saving…'; btn.disabled = true;

        var data = new URLSearchParams();
        data.append('action',              'nri_save_smtp_settings');
        data.append('nonce',               NRI.admin_nonce);
        data.append('nri_smtp_enabled',    document.getElementById('nri-smtp-enabled')    && document.getElementById('nri-smtp-enabled').checked    ? '1' : '0');
        data.append('nri_smtp_host',       document.getElementById('nri-smtp-host')       ? document.getElementById('nri-smtp-host').value       : '');
        data.append('nri_smtp_port',       document.getElementById('nri-smtp-port')       ? document.getElementById('nri-smtp-port').value       : '587');
        data.append('nri_smtp_encryption', document.getElementById('nri-smtp-encryption') ? document.getElementById('nri-smtp-encryption').value : 'tls');
        data.append('nri_smtp_auth',       '1');
        data.append('nri_smtp_username',   document.getElementById('nri-smtp-username')   ? document.getElementById('nri-smtp-username').value   : '');
        data.append('nri_smtp_password',   document.getElementById('nri-smtp-password')   ? document.getElementById('nri-smtp-password').value   : '');
        data.append('nri_email_from',      document.getElementById('nri-smtp-from-email') ? document.getElementById('nri-smtp-from-email').value : '');
        data.append('nri_email_name',      document.getElementById('nri-smtp-from-name')  ? document.getElementById('nri-smtp-from-name').value  : '');
        data.append('nri_smtp_debug',      document.getElementById('nri-smtp-debug')      && document.getElementById('nri-smtp-debug').checked    ? '1' : '0');

        fetch(NRI.ajax_url, { method: 'POST', body: data })
            .then(function(r){ return r.json(); })
            .then(function(d) {
                btn.textContent = '💾 Save SMTP Settings'; btn.disabled = false;
                if ($msg) {
                    $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;font-weight:600;margin-top:14px;';
                    if (d.success) {
                        $msg.style.background = '#f0fdf4'; $msg.style.color = '#16a34a'; $msg.style.border = '1px solid #bbf7d0';
                        $msg.textContent = '✅ SMTP settings saved. Use "Send Test Email" to verify delivery.';
                    } else {
                        var err = d.data && d.data.message ? d.data.message : 'Save failed';
                        $msg.style.background = '#fef2f2'; $msg.style.color = '#dc2626'; $msg.style.border = '1px solid #fecaca';
                        $msg.textContent = '❌ ' + err;
                    }
                }
            })
            .catch(function(err) {
                btn.textContent = '💾 Save SMTP Settings'; btn.disabled = false;
                if ($msg) { $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;color:#dc2626;background:#fef2f2;border:1px solid #fecaca;'; $msg.textContent = '❌ Network error: ' + err.message; }
            });
    });

    // Send test email
    document.addEventListener('click', function(e) {
        if (!e.target || e.target.id !== 'nri-smtp-test-btn') return;
        var $msg = document.getElementById('nri-smtp-msg');
        var to   = prompt('Send test email to:', '<?php echo esc_js( wp_get_current_user()->user_email ); ?>');
        if (!to || !to.trim()) return;
        var btn  = e.target;
        btn.textContent = '⏳ Sending…'; btn.disabled = true;
        if ($msg) { $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;background:#f1f5f9;color:#475569;margin-top:14px;'; $msg.textContent = 'Sending test email to ' + to + ' …'; }

        var data = new URLSearchParams();
        data.append('action',     'nri_smtp_test');
        data.append('nonce',      NRI.admin_nonce);
        data.append('test_email', to.trim());

        fetch(NRI.ajax_url, { method: 'POST', body: data })
            .then(function(r){ return r.json(); })
            .then(function(d) {
                btn.textContent = '📧 Send Test Email'; btn.disabled = false;
                if ($msg) {
                    $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;font-weight:600;margin-top:14px;';
                    if (d.success) {
                        $msg.style.background = '#f0fdf4'; $msg.style.color = '#16a34a'; $msg.style.border = '1px solid #bbf7d0';
                        $msg.textContent = '✅ ' + (d.data && d.data.message ? d.data.message : 'Test sent!');
                    } else {
                        var err = d.data && d.data.message ? d.data.message : 'Test failed';
                        $msg.style.background = '#fef2f2'; $msg.style.color = '#dc2626'; $msg.style.border = '1px solid #fecaca';
                        $msg.innerHTML = '❌ ' + err + '<br><small style="font-weight:400;color:#7f1d1d;">Check nri-debug.log in the plugin folder for full SMTP details.</small>';
                    }
                }
            })
            .catch(function(err) {
                btn.textContent = '📧 Send Test Email'; btn.disabled = false;
                if ($msg) { $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;color:#dc2626;background:#fef2f2;border:1px solid #fecaca;'; $msg.textContent = '❌ Network error: ' + err.message; }
            });
    });


    // Email diagnostics
    document.addEventListener('click', function(e) {
        if (!e.target || e.target.id !== 'nri-email-diag-btn') return;
        var btn = e.target, out = document.getElementById('nri-email-diag-out');
        var to = prompt('Send diagnostics test email to:', '<?php echo esc_js( wp_get_current_user()->user_email ); ?>');
        if (!to || !to.trim()) return;
        btn.disabled = true; btn.textContent = '⏳ Running…';
        out.style.display = 'block'; out.textContent = 'Running diagnostics (up to ~30 seconds)…';
        var data = new URLSearchParams();
        data.append('action', 'nri_email_diagnostics'); data.append('nonce', NRI.admin_nonce); data.append('test_email', to.trim());
        fetch(NRI.ajax_url, { method: 'POST', body: data })
            .then(function(r){ return r.json(); })
            .then(function(d) {
                btn.disabled = false; btn.textContent = '🩺 Run Email Diagnostics';
                if (!d.success) { out.textContent = 'Diagnostics failed: ' + (d.data && d.data.message ? d.data.message : 'unknown'); return; }
                var f = d.data.findings || [];
                out.textContent = 'FINDINGS\n' + (f.length ? f.map(function(x,i){ return (i+1)+'. '+x; }).join('\n') : 'none') + '\n\n' + d.data.report;
            })
            .catch(function(err){ btn.disabled = false; btn.textContent = '🩺 Run Email Diagnostics'; out.textContent = 'Network error: ' + err.message; });
    });

    // ── Fix Existing Documents ───────────────────────────────────────────────
    (function() {
        var fixBtn     = document.getElementById('nri-fix-docs-btn');
        var scanBtn    = document.getElementById('nri-recount-docs-btn');
        var statusBox  = document.getElementById('nri-fix-docs-status');
        var fixProg    = document.getElementById('nri-fix-docs-progress');
        var fixBar     = document.getElementById('nri-fix-docs-bar');
        var fixMsg     = document.getElementById('nri-fix-docs-msg');
        var totalBroken = 0;

        if (!fixBtn || !scanBtn) return; // not on general settings tab

        function nriDocPost(action, data, onOk, onErr) {
            var body = new URLSearchParams({ action: action, nonce: NRI.admin_nonce || NRI.nonce || '' });
            Object.keys(data).forEach(function(k){ body.append(k, data[k]); });
            fetch(NRI.ajax_url, { method: 'POST', body: body, headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function(r){ return r.json(); })
                .then(function(r){
                    if (r && r.success) { onOk(r.data || {}); }
                    else { onErr((r && r.data && r.data.message) ? r.data.message : 'Server error'); }
                })
                .catch(function(e){ onErr('Network error: ' + e.message); });
        }

        // Scan button
        scanBtn.addEventListener('click', function() {
            scanBtn.disabled = true;
            scanBtn.textContent = '⏳ Scanning…';
            if (statusBox) statusBox.textContent = '⏳ Scanning all documents…';
            nriDocPost('nri_count_avif_docs', {}, function(d) {
                scanBtn.disabled = false;
                scanBtn.textContent = '🔍 Scan Again';
                totalBroken = parseInt(d.count) || 0;
                if (statusBox) {
                    if (totalBroken === 0) {
                        statusBox.style.cssText = 'background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;padding:10px 14px;font-size:13px;color:#166534;margin-bottom:14px;';
                        statusBox.textContent = '✅ All documents are in PDF/JPG/PNG format. Nothing to fix.';
                    } else {
                        statusBox.style.cssText = 'background:#fef9c3;border:1px solid #fde68a;border-radius:6px;padding:10px 14px;font-size:13px;color:#78350f;margin-bottom:14px;';
                        statusBox.textContent = '⚠️ ' + totalBroken + ' document(s) found in AVIF or WebP format.';
                    }
                }
                fixBtn.disabled = (totalBroken === 0);
                fixBtn.textContent = totalBroken > 0 ? '🔧 Convert ' + totalBroken + ' Document(s) to PNG' : '🔧 Convert to PNG';
            }, function(err) {
                scanBtn.disabled = false;
                scanBtn.textContent = '🔍 Scan';
                if (statusBox) { statusBox.style.cssText = 'background:#fef2f2;border:1px solid #fecaca;border-radius:6px;padding:10px 14px;font-size:13px;color:#991b1b;margin-bottom:14px;'; statusBox.textContent = '❌ Scan failed: ' + err; }
            });
        });

        // Convert button
        fixBtn.addEventListener('click', function() {
            fixBtn.disabled = true;
            fixBtn.textContent = '⏳ Converting…';
            fixProg.style.display = 'block';
            fixBar.style.width = '2%';
            fixMsg.textContent = 'Starting conversion…';
            runBatch(0, totalBroken);
        });

        function runBatch(done, total) {
            nriDocPost('nri_fix_avif_docs', { batch: 10 }, function(d) {
                done += parseInt(d.converted) || 0;
                var remaining = parseInt(d.remaining) || 0;
                var pct = total > 0 ? Math.min(98, Math.round((done / total) * 100)) : 50;
                fixBar.style.width = pct + '%';
                fixMsg.textContent = '✓ ' + done + ' converted'
                    + (d.failed ? ', ✗ ' + d.failed + ' failed' : '')
                    + (remaining > 0 ? ' — ' + remaining + ' remaining…' : '');

                if (remaining > 0) {
                    setTimeout(function(){ runBatch(done, total); }, 400);
                } else {
                    fixBar.style.width = '100%';
                    fixBar.style.background = '#10b981';
                    fixBtn.disabled = true;
                    fixBtn.textContent = '✅ All Done';
                    fixMsg.textContent = '🎉 ' + done + ' document(s) successfully converted to PNG.';
                    if (statusBox) { statusBox.style.cssText = 'background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;padding:10px 14px;font-size:13px;color:#166534;margin-bottom:14px;'; statusBox.textContent = '✅ All documents are now in PDF/JPG/PNG format.'; }
                    scanBtn.textContent = '🔍 Scan Again';
                }
            }, function(err) {
                fixBtn.disabled = false;
                fixBtn.textContent = '🔧 Retry';
                fixMsg.textContent = '❌ Error: ' + err;
            });
        }
    })();
    } // end if (!window.__nriSettingsJsInit)
    </script>
    <?php
    return ob_get_clean();
}
