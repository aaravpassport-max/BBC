<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action('init','nri_register_cpt');
function nri_register_cpt() {
    register_post_type('nri_request',array('label'=>'NRI Requests','public'=>false,'show_ui'=>true,'supports'=>array('title')));
}
