<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nri_is_staff() {
    return is_user_logged_in() && (current_user_can('administrator')||current_user_can('nri_admin')||current_user_can('nri_manager'));
}
function nri_check_nonce() {
    $n = sanitize_text_field(isset($_POST['nonce'])?$_POST['nonce']:'');
    if (wp_verify_nonce($n,'nri_admin_nonce'))    return true;
    if (wp_verify_nonce($n,'nri_frontend_nonce')) return true;
    if (wp_verify_nonce($n,'nri_upload_nonce'))   return true;
    if (wp_verify_nonce($n,'nri_login_nonce'))    return true;
    wp_send_json_error(array('message'=>'Security check failed. Please refresh and try again.'),403);
    exit;
}
function nri_require_staff() {
    if (!nri_is_staff()) { wp_send_json_error(array('message'=>'Permission denied.'),403); exit; }
}
// Stricter gate for Internal Status *management* (add/edit/reorder/
// activate/delete a status definition) — separate from just assigning an
// existing status to a request, which any staff member (nri_is_staff())
// can do. Matches the "authorized administrators" wording in the feature
// spec and the manage_options gate already used for the migration
// rollback in migrations.php.
function nri_is_admin_user() {
    return is_user_logged_in() && current_user_can( 'manage_options' );
}
function nri_require_admin() {
    if ( ! nri_is_admin_user() ) { wp_send_json_error( array( 'message' => 'Administrator access required.' ), 403 ); exit; }
}
function nri_is_own_request($rid) {
    if (!is_user_logged_in()) return false;
    if (nri_is_staff()) return true;
    $p=get_post($rid);
    return $p && $p->post_type==='nri_request' && (int)$p->post_author===get_current_user_id();
}
