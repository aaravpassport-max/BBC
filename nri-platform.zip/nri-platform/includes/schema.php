<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nri_create_tables() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nri_fields (id int NOT NULL AUTO_INCREMENT,field_key varchar(100) NOT NULL,field_label varchar(200) NOT NULL,field_type varchar(50) NOT NULL DEFAULT 'text',field_options text,placeholder varchar(300) DEFAULT '',description text DEFAULT NULL,is_required tinyint(1) DEFAULT 0,sort_order int DEFAULT 0,is_active tinyint(1) DEFAULT 1,step_number int DEFAULT 1,conditions longtext DEFAULT NULL,PRIMARY KEY(id),UNIQUE KEY uq_fk(field_key)) $c");
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nri_dropdown_options (id int NOT NULL AUTO_INCREMENT,field_key varchar(100) NOT NULL,option_value varchar(500) NOT NULL,sort_order int DEFAULT 0,PRIMARY KEY(id),KEY idx_fk(field_key)) $c");
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nri_request_types (id int NOT NULL AUTO_INCREMENT,name varchar(200) NOT NULL,description text,icon varchar(20) DEFAULT '',sort_order int DEFAULT 0,is_active tinyint(1) DEFAULT 1,PRIMARY KEY(id)) $c");
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nri_tickets (id int NOT NULL AUTO_INCREMENT,request_id bigint unsigned DEFAULT 0,user_id bigint unsigned DEFAULT 0,type_id int DEFAULT 0,category varchar(200) DEFAULT '',status varchar(50) DEFAULT 'open',notes text,created_at datetime DEFAULT CURRENT_TIMESTAMP,updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_req(request_id)) $c");
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nri_messages (id int NOT NULL AUTO_INCREMENT,request_id bigint unsigned DEFAULT 0,sender_id bigint unsigned DEFAULT 0,message text NOT NULL,is_email_sent tinyint(1) DEFAULT 0,created_at datetime DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_req(request_id)) $c");
    // Migration: add conditions column if missing
    $cols = $wpdb->get_col("SHOW COLUMNS FROM {$wpdb->prefix}nri_fields");
    if (!in_array('conditions', $cols)) {
        $wpdb->query("ALTER TABLE {$wpdb->prefix}nri_fields ADD COLUMN conditions longtext DEFAULT NULL");
    }
    if (!in_array('description', $cols)) {
        $wpdb->query("ALTER TABLE {$wpdb->prefix}nri_fields ADD COLUMN description text DEFAULT NULL");
    }
    // Internal Status pipeline (CRM-style staff-only workflow stages —
    // never shown to clients; see nri_internal_status_default_rows() and
    // nri_migrate_internal_statuses_table() in includes/migrations.php,
    // which creates this same table for installs that are upgrading
    // rather than activating fresh).
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nri_internal_statuses (id int NOT NULL AUTO_INCREMENT,slug varchar(100) NOT NULL,label varchar(200) NOT NULL,color varchar(20) DEFAULT '#6b7280',sort_order int DEFAULT 0,is_active tinyint(1) DEFAULT 1,created_at datetime DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_slug(slug)) $c");
    if ( ! $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}nri_fields") ) { nri_seed_fields(); }
    if ( ! $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}nri_request_types") ) { nri_seed_rtypes(); }
    if ( ! $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}nri_internal_statuses") ) { nri_seed_internal_statuses(); }
}

// Default 21-stage internal pipeline, in recommended end-to-end workflow
// order (Inquiry → ... → Service Not Required Any More). Shared by both
// the fresh-activation path above and the upgrade-path migration in
// includes/migrations.php, so the two never drift apart.
function nri_internal_status_default_rows() {
    return array(
        array( 'Inquiry',                                    '#64748b' ),
        array( 'Need to Work on Query',                       '#0ea5e9' ),
        array( 'High Quality Prospect',                       '#2563eb' ),
        array( 'Follow Up',                                   '#7c3aed' ),
        array( 'Under Review – For Feasibility Check',        '#8b5cf6' ),
        array( 'Feasibility Check Required',                  '#a855f7' ),
        array( 'Awaiting Client Decision – Pending',           '#d946ef' ),
        array( 'Quotation to be Sent',                         '#f59e0b' ),
        array( 'Quotation Sent',                               '#f97316' ),
        array( 'Waiting for Docs',                             '#eab308' ),
        array( 'Documents Received',                           '#84cc16' ),
        array( 'Payment Received',                             '#22c55e' ),
        array( 'PMT RECVD – Work Not Started',                 '#14b8a6' ),
        array( 'Assigned and In Progress',                     '#06b6d4' ),
        array( 'Work Completed',                               '#10b981' ),
        array( 'Delivered',                                    '#059669' ),
        array( 'No Response',                                  '#94a3b8' ),
        array( 'High Charges – Lost',                          '#ef4444' ),
        array( 'Late Response – Lost',                         '#dc2626' ),
        array( 'Not Able to Serve',                            '#b91c1c' ),
        array( 'Service Not Required Any More',                '#78716c' ),
    );
}

function nri_seed_internal_statuses() {
    global $wpdb; $t = $wpdb->prefix . 'nri_internal_statuses';
    foreach ( nri_internal_status_default_rows() as $i => $row ) {
        list( $label, $color ) = $row;
        $slug = nri_generate_internal_status_slug( $label );
        $wpdb->insert( $t, array(
            'slug'       => $slug,
            'label'      => $label,
            'color'      => $color,
            'sort_order' => ( $i + 1 ) * 10,
            'is_active'  => 1,
        ) );
    }
}

function nri_seed_fields() {
    global $wpdb; $t=$wpdb->prefix.'nri_fields';
    $rows=array(array('service_type','Service Type','dropdown','','Select service type',1,1,1),array('document_type','Document Type','dropdown','','Select document type',1,2,1),array('application_type','Application Type','radio','Reissue/Duplicate,First Time','',1,3,1),array('university_name','University Name','searchable','','Type to search',1,4,1),array('college_name','College Name','text','','Enter college name',0,5,1),array('year_admission','Year of Admission','text','','e.g. 2018',0,7,2),array('year_passing','Year of Passing','text','','e.g. 2022',0,8,2),array('enrollment_number','Enrollment Number','text','','Your enrollment number',0,9,2),array('purpose','Purpose','dropdown','','Select purpose',0,10,2),array('current_location','Current Location','text','','e.g. Dubai, UAE',0,11,2),array('delivery_location','Delivery Location','text','','City, Country',0,12,2),array('first_name','First Name','text','','Your first name',1,13,3),array('last_name','Last Name','text','','Your last name',1,14,3),array('phone','Mobile Number','phone','','Your mobile number',1,15,3),array('remarks','Additional Remarks','textarea','','Any special instructions',0,16,3),array('documents','Upload Documents','file','','',0,17,4));
    foreach($rows as $r) { $wpdb->insert($t,array('field_key'=>$r[0],'field_label'=>$r[1],'field_type'=>$r[2],'field_options'=>$r[3],'placeholder'=>$r[4],'is_required'=>$r[5],'sort_order'=>$r[6],'is_active'=>1,'step_number'=>$r[7])); }
    foreach(array('service_type'=>array('Educational Document Retrieval','Legal Document Retrieval','Government Record Retrieval','Property Document Retrieval'),'document_type'=>array('Transcript','Degree Certificate','Mark Sheet','Migration Certificate','Character Certificate','Bonafide Certificate','Provisional Certificate'),'purpose'=>array('Higher Education Abroad','Employment Verification','Immigration','Personal Records','Legal Requirement','Other'),'university_name'=>array('University of Delhi','University of Mumbai','Anna University','Amity University','Punjab University','Osmania University')) as $key=>$opts) { $t2=$wpdb->prefix.'nri_dropdown_options'; foreach($opts as $i=>$v){$wpdb->insert($t2,array('field_key'=>$key,'option_value'=>$v,'sort_order'=>$i+1));} }
}

function nri_seed_rtypes() {
    global $wpdb; $t=$wpdb->prefix.'nri_request_types';
    foreach(array('Transcript Request','Degree Certificate','Mark Sheet Retrieval','Migration Certificate','Character Certificate','Bonafide Certificate','Other Service Request') as $i=>$n) { $wpdb->insert($t,array('name'=>$n,'icon'=>'','sort_order'=>$i+1,'is_active'=>1)); }
}

function nri_get_fields($active=true) { global $wpdb; $w=$active?'WHERE is_active=1':''; return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}nri_fields $w ORDER BY sort_order ASC"); }

function nri_get_dropdown_options($key,$search='') {
    global $wpdb; $key=sanitize_key($key);
    if($search) return $wpdb->get_col($wpdb->prepare("SELECT option_value FROM {$wpdb->prefix}nri_dropdown_options WHERE field_key=%s AND option_value LIKE %s ORDER BY sort_order ASC LIMIT 300",$key,'%'.$wpdb->esc_like($search).'%'));
    return $wpdb->get_col($wpdb->prepare("SELECT option_value FROM {$wpdb->prefix}nri_dropdown_options WHERE field_key=%s ORDER BY sort_order ASC LIMIT 300",$key));
}

function nri_get_request_types($active=true) { global $wpdb; $w=$active?'WHERE is_active=1':''; return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}nri_request_types $w ORDER BY sort_order ASC"); }
function nri_get_tickets($rid) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}nri_tickets WHERE request_id=%d ORDER BY created_at DESC",intval($rid))); }
function nri_get_messages($rid) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT m.*,u.display_name,u.user_email FROM {$wpdb->prefix}nri_messages m LEFT JOIN {$wpdb->prefix}users u ON m.sender_id=u.ID WHERE m.request_id=%d ORDER BY m.created_at ASC",intval($rid))); }
