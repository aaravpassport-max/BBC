<?php
if (!defined('ABSPATH')) exit;

// ── NRI Document Sanitiser ─────────────────────────────────────────────────
// Called after every document upload to ensure the stored file is always
// PDF, JPG, or PNG. If another plugin (image optimizer) converted the file
// to AVIF or WebP, this function converts it back to PNG and updates the
// WordPress attachment record so downloads always work correctly.
function nri_sanitise_attachment( int $att_id ): void {
    if ( ! $att_id ) return;

    $file_path = get_attached_file( $att_id );
    if ( ! $file_path || ! file_exists( $file_path ) ) return;

    $finfo     = new finfo( FILEINFO_MIME_TYPE );
    $mime_real = $finfo->file( $file_path );

    // Already a safe format — nothing to do
    if ( in_array( $mime_real, [ 'application/pdf', 'image/jpeg', 'image/png' ], true ) ) return;

    // Not AVIF or WebP — not our concern
    if ( ! in_array( $mime_real, [ 'image/avif', 'image/webp' ], true ) ) return;

    nri_log( 'nri_sanitise_attachment: ' . $mime_real . ' detected for att ' . $att_id . ' — converting to PNG' );

    // Build path for PNG replacement (same dir, same base name, .png extension)
    $dir      = dirname( $file_path );
    $basename = preg_replace( '/\.[^.]+$/', '', basename( $file_path ) );
    // Also strip compound extensions like "doc.jpg" → "doc" from "doc.jpg.avif"
    $basename = preg_replace( '/\.(jpg|jpeg|png|webp|avif)$/i', '', $basename );
    $png_path = $dir . DIRECTORY_SEPARATOR . $basename . '.png';

    $converted = false;

    // Try Imagick
    if ( extension_loaded( 'imagick' ) ) {
        try {
            $im = new Imagick( $file_path );
            // Flatten transparency onto white background
            if ( $im->getImageAlphaChannel() ) {
                $bg = new Imagick();
                $bg->newImage( $im->getImageWidth(), $im->getImageHeight(), new ImagickPixel( 'white' ) );
                $bg->compositeImage( $im, Imagick::COMPOSITE_OVER, 0, 0 );
                $im = $bg;
            }
            $im->setImageFormat( 'png' );
            $im->setImageCompressionQuality( 95 );
            $im->writeImage( $png_path );
            $im->clear(); $im->destroy();
            if ( file_exists( $png_path ) && filesize( $png_path ) > 0 ) {
                $converted = true;
            }
        } catch ( Throwable $e ) {
            nri_log( 'nri_sanitise_attachment Imagick failed: ' . $e->getMessage() );
        }
    }

    // Try GD if Imagick failed
    if ( ! $converted ) {
        $img = null;
        if ( $mime_real === 'image/webp' && function_exists( 'imagecreatefromwebp' ) ) {
            $img = @imagecreatefromwebp( $file_path );
        } elseif ( $mime_real === 'image/avif' && function_exists( 'imagecreatefromavif' ) ) {
            $img = @imagecreatefromavif( $file_path );
        }
        if ( $img ) {
            $w   = imagesx( $img ); $h = imagesy( $img );
            $out = imagecreatetruecolor( $w, $h );
            imagefill( $out, 0, 0, imagecolorallocate( $out, 255, 255, 255 ) );
            imagecopy( $out, $img, 0, 0, 0, 0, $w, $h );
            if ( imagepng( $out, $png_path, 6 ) && file_exists( $png_path ) && filesize( $png_path ) > 0 ) {
                $converted = true;
            }
            imagedestroy( $img ); imagedestroy( $out );
        }
    }

    if ( ! $converted ) {
        nri_log( 'nri_sanitise_attachment: conversion failed for att ' . $att_id );
        return;
    }

    // Delete the AVIF/WebP file
    @unlink( $file_path );

    // Update WordPress attachment to point to the PNG
    update_attached_file( $att_id, $png_path );
    wp_update_post( [ 'ID' => $att_id, 'post_mime_type' => 'image/png' ] );

    // Regenerate metadata so WP knows about the new file
    $metadata = wp_generate_attachment_metadata( $att_id, $png_path );
    wp_update_attachment_metadata( $att_id, $metadata );

    nri_log( 'nri_sanitise_attachment: converted to PNG — ' . basename( $png_path ) );
}


// -----------------------------------------------------------
// AUTH
// -----------------------------------------------------------
add_action('wp_ajax_nopriv_nri_login', 'nri_ajax_login');
add_action('wp_ajax_nri_login',        'nri_ajax_login');
function nri_ajax_login() {
    $nonce    = sanitize_text_field(isset($_POST['nonce']) ? $_POST['nonce'] : '');
    $email    = sanitize_email(isset($_POST['email']) ? $_POST['email'] : '');
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    if (!is_email($email)) wp_send_json_error(array('message' => 'Enter a valid email.'));
    if (!$password)        wp_send_json_error(array('message' => 'Enter your password.'));
    $user = get_user_by('email', $email);
    if (!$user) wp_send_json_error(array('message' => 'No account found with that email.'));
    $result = wp_authenticate($user->user_login, $password);
    if (is_wp_error($result)) wp_send_json_error(array('message' => 'Incorrect password.'));
    wp_set_auth_cookie($result->ID, true);
    wp_set_current_user($result->ID);
    $roles    = (array) $result->roles;
    $redirect = (in_array('nri_client', $roles) && !in_array('administrator', $roles))
                ? home_url('/client-dashboard') : home_url('/admin-dashboard');
    wp_send_json_success(array('redirect' => $redirect));
}

add_action('wp_ajax_nopriv_nri_magic_link', 'nri_ajax_magic_link');
function nri_ajax_magic_link() {
    $email = sanitize_email(isset($_POST['email']) ? $_POST['email'] : '');
    $user  = get_user_by('email', $email);
    if ($user) nri_send_magic_link($user->ID, $email);
    wp_send_json_success(array('message' => 'If an account exists, a link has been sent.'));
}

// -----------------------------------------------------------
// SEARCHABLE DROPDOWN
// -----------------------------------------------------------
add_action('wp_ajax_nopriv_nri_search_dropdown', 'nri_ajax_search_dropdown');
add_action('wp_ajax_nri_search_dropdown',        'nri_ajax_search_dropdown');
function nri_ajax_search_dropdown() {
    $key    = sanitize_key(isset($_POST['field_key']) ? $_POST['field_key'] : '');
    $search = sanitize_text_field(isset($_POST['search']) ? $_POST['search'] : '');
    wp_send_json_success(array_values(nri_get_dropdown_options($key, $search)));
}

// TRACE: called for every client/staff document upload (pending upload, staff add-document) →
//        moves the already-validated $_FILES[$key] into the uploads folder and creates the
//        attachment record → DELIBERATELY skips wp_generate_attachment_metadata(): that call
//        makes WordPress write a thumbnail for EVERY registered image size (a theme/Elementor
//        site easily has 10-20) and fires every image-optimizer/WebP/CDN plugin hooked on it —
//        several seconds, sometimes tens of seconds, even for a 50KB image. These are ID/
//        marksheet documents that are only ever downloaded whole; no thumbnail is used anywhere
//        in the plugin → pre: file already type/size checked by the caller → post: returns the
//        new attachment ID, or WP_Error with the reason → edge cases: wp_handle_upload error,
//        wp_insert_attachment failure (WP_Error), missing $_FILES entry.
function nri_store_document_upload( $key, $parent = 0 ) {
    if ( empty( $_FILES[ $key ] ) || ! is_array( $_FILES[ $key ] ) ) {
        return new WP_Error( 'nri_no_file', 'No file received.' );
    }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    $file   = $_FILES[ $key ];
    $upload = wp_handle_upload( $file, array( 'test_form' => false ) );
    if ( ! is_array( $upload ) || isset( $upload['error'] ) || empty( $upload['file'] ) ) {
        return new WP_Error( 'nri_upload_failed', isset( $upload['error'] ) ? $upload['error'] : 'The file could not be stored.' );
    }
    $att_id = wp_insert_attachment( array(
        'post_mime_type' => $upload['type'],
        'post_title'     => sanitize_text_field( pathinfo( $file['name'], PATHINFO_FILENAME ) ),
        'post_content'   => '',
        'post_status'    => 'inherit',
    ), $upload['file'], (int) $parent, true );
    if ( is_wp_error( $att_id ) || ! $att_id ) {
        return is_wp_error( $att_id ) ? $att_id : new WP_Error( 'nri_attach_failed', 'The file was stored but could not be registered.' );
    }
    return (int) $att_id;
}

// -----------------------------------------------------------
// CREATE REQUEST (guest + logged-in)
// -----------------------------------------------------------
add_action('wp_ajax_nopriv_nri_create_request', 'nri_ajax_create_request');
add_action('wp_ajax_nri_create_request',        'nri_ajax_create_request');
function nri_ajax_create_request() {
    // Nonce check - allows both frontend and admin nonces
    nri_check_nonce();

    // Multiple document uploads + per-file thumbnail generation
    // (wp_generate_attachment_metadata) can legitimately take longer than
    // a shared host's default 30s execution budget, especially when
    // several files arrive back-to-back on a slow mobile upload. A PHP
    // timeout here looks identical to a "connection error" on the client
    // (the connection is simply cut), so give this request more room.
    // Best-effort only — disabled on hosts that block runtime overrides.
    if ( function_exists( 'set_time_limit' ) ) {
        @set_time_limit( 180 );
    }
    if ( function_exists( 'ini_set' ) ) {
        @ini_set( 'max_execution_time', 180 );
    }

    $email = sanitize_email(isset($_POST['client_email']) ? $_POST['client_email'] : '');
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'A valid email address is required. Please go back to Step 3 and enter your email.'));
    }

    // ── Background-uploaded documents ────────────────────────────────────────
    // Documents no longer have to ride along with this request: the browser
    // starts uploading each file the moment it's selected (nri_pending_upload
    // below), well before Submit is clicked, and hands us back the resulting
    // attachment IDs here. $upload_token ties those attachments to THIS
    // browser's upload session (checked against the same token stamped on
    // each attachment by nri_ajax_pending_upload) so one client can't claim
    // another's uploaded file by guessing an attachment ID.
    $upload_token   = sanitize_text_field( isset( $_POST['upload_token'] ) ? $_POST['upload_token'] : '' );
    $pending_ids    = array();
    if ( isset( $_POST['pending_upload_ids'] ) ) {
        foreach ( (array) $_POST['pending_upload_ids'] as $pid ) {
            $pid = (int) $pid;
            if ( $pid > 0 ) { $pending_ids[] = $pid; }
        }
    }

    // ── Idempotency ───────────────────────────────────────────────────────────
    // $submission_token is a random value the browser generates once per
    // page load (the same value doubles as $upload_token above). If this
    // exact submission already went through — a retried request after a
    // client-side timeout, or the student double-clicking Submit — replay
    // the SAME success response instead of creating a second request. This
    // is what stops "shows an error but the application was actually
    // created": a retry now returns the original success payload rather
    // than failing or duplicating.
    $submission_token = sanitize_text_field( isset( $_POST['submission_token'] ) ? $_POST['submission_token'] : '' );
    if ( $submission_token !== '' ) {
        $cached = get_transient( 'nri_submit_' . md5( $submission_token ) );
        if ( $cached !== false ) {
            // Only replay "success" if the request it points at STILL exists. If it was
            // deleted (staff cleaning up a test, a failed restore, a rolled-back DB) a
            // replay would tell the client "submitted" while nothing exists — so drop the
            // stale marker and fall through to create the request properly.
            $cached_post = ( is_array( $cached ) && ! empty( $cached['post_id'] ) ) ? get_post( (int) $cached['post_id'] ) : null;
            if ( $cached_post && $cached_post->post_type === 'nri_request' && $cached_post->post_status === 'publish' ) {
                wp_send_json_success( $cached );
            }
            delete_transient( 'nri_submit_' . md5( $submission_token ) );
        }
    }

    // Server-side: enforce required file uploads
    global $wpdb;
    $required_file_fields = $wpdb->get_results(
        "SELECT field_key, field_label FROM {$wpdb->prefix}nri_fields WHERE field_type='file' AND is_required=1 AND is_active=1"
    );
    if ( ! empty( $required_file_fields ) ) {
        // Files from the form are sent as field_documents[] (appended via JS FormData)
        // OR as field_{key}[] if sent natively by the file input name attribute
        // OR — the normal path now — already uploaded in the background and
        // referenced here via pending_upload_ids[].
        $files_received = ! empty( $pending_ids );

        // Check field_documents[] — legacy/fallback path (JS disabled, or a
        // background upload never got queued for some reason)
        if ( ! $files_received && ! empty( $_FILES['field_documents']['name'] ) ) {
            $names = (array) $_FILES['field_documents']['name'];
            foreach ( $names as $n ) {
                if ( ! empty( $n ) ) { $files_received = true; break; }
            }
        }

        // Also check any field_{key}[] keys sent natively from the file input name attr
        if ( ! $files_received ) {
            foreach ( $required_file_fields as $rff ) {
                $file_key = 'field_' . $rff->field_key;
                if ( ! empty( $_FILES[ $file_key ]['name'][0] ) || ! empty( $_FILES[ $file_key ]['name'] ) ) {
                    $files_received = true;
                    break;
                }
            }
        }

        if ( ! $files_received ) {
            wp_send_json_error( array( 'message' => 'Please upload all required documents before submitting.' ) );
        }
    }

    // Server-side validation: enforce ALL required fields
    $all_required_fields = $wpdb->get_results(
        "SELECT field_key, field_label, field_type FROM {$wpdb->prefix}nri_fields WHERE is_required=1 AND is_active=1"
    );
    foreach ( $all_required_fields as $rf ) {
        $field_name = 'field_' . $rf->field_key;
        $value = isset( $_POST[ $field_name ] ) ? $_POST[ $field_name ] : '';

        // Special handling per type
        if ( $rf->field_type === 'file' ) {
            continue; // Already validated above
        }

        // For all other types (text, select, textarea, radio, etc) — check not empty
        if ( empty( $value ) || ( is_string( $value ) && trim( $value ) === '' ) ) {
            wp_send_json_error( array(
                'message' => esc_html( $rf->field_label ) . ' is required. Please complete all required fields before submitting.'
            ) );
        }

        // Additional check for select fields — ensure not default "- Select -" option
        if ( $rf->field_type === 'dropdown' || $rf->field_type === 'searchable' ) {
            if ( $value === '' || $value === '- Select -' ) {
                wp_send_json_error( array(
                    'message' => 'Please select a value for ' . esc_html( $rf->field_label ) . '.'
                ) );
            }
        }
    }

    $user   = get_user_by('email', $email);
    $is_new = false;
    $welcome_pw = '';
    if (!$user) {
        $pw  = wp_generate_password(12, false);
        // The 'user_register' hook sends the welcome email synchronously from inside
        // wp_create_user(). That put a live SMTP/mail round-trip BEFORE the request is
        // saved, so a slow or failing mail server could time the whole submission out
        // with nothing stored. Suspend it here; the same email is sent after the request
        // is safely saved (see the deferred job below).
        $had_acct_hook = has_action( 'user_register', 'nri_notify_account_created' );
        if ( $had_acct_hook !== false ) { remove_action( 'user_register', 'nri_notify_account_created' ); }
        $uid = wp_create_user($email, $pw, $email);
        if ( $had_acct_hook !== false ) { add_action( 'user_register', 'nri_notify_account_created' ); }
        // NOTE (open issue — see delivery notes): this fails BEFORE the request post is
        // created, so nothing is saved yet and the client is asked to try again. A full
        // fix (save the request first, reconcile the account afterwards) is a larger
        // backend change than this pass covers — flagged rather than silently left as-is.
        if (is_wp_error($uid)) wp_send_json_error(array('message' => 'We could not set up your account just now, so your request was not saved. Please try submitting again — you will not be charged or double-billed, and no duplicate will be created.'));
        $disp = sanitize_text_field(isset($_POST['field_first_name']) ? $_POST['field_first_name'] : $email);
        wp_update_user(array('ID' => $uid, 'display_name' => $disp));
        wp_update_user(array('ID' => $uid, 'role' => 'nri_client'));
        $welcome_pw = $pw; // held in memory only, for the post-save credentials email
        $is_new = true;
    } else {
        $uid = $user->ID;
    }
    wp_set_auth_cookie($uid, true);
    wp_set_current_user($uid);

    $fd = array();
    foreach ($_POST as $k => $v) {
        if (strpos($k, 'field_') === 0) {
            $fd[sanitize_key($k)] = is_array($v) ? array_map('sanitize_text_field', $v) : sanitize_text_field($v);
        }
    }
    $service = !empty($fd['field_service_type']) ? $fd['field_service_type']
             : (!empty($fd['field_document_type']) ? $fd['field_document_type'] : 'Document Request');

    // wp_insert_post() returns 0 (NOT a WP_Error) on a database failure unless $wp_error
    // is requested — the old is_wp_error() check let that through, and the client was then
    // told "submitted" while nothing had been stored. Ask for the WP_Error and treat both a
    // WP_Error and 0 as a hard failure the visitor can see.
    $post_id = wp_insert_post(array(
        'post_type'   => 'nri_request',
        'post_status' => 'publish',
        'post_title'  => wp_trim_words($service, 8, '') . ' - ' . $email . ' - ' . date('Y-m-d'),
        'post_author' => $uid,
    ), true);
    if ( is_wp_error( $post_id ) || ! $post_id ) {
        nri_log( 'nri_create_request: wp_insert_post FAILED for ' . $email . ' — ' . ( is_wp_error( $post_id ) ? $post_id->get_error_message() : 'returned 0' ) );
        wp_send_json_error(array('message' => 'We could not save your request just now. Nothing was submitted — please try again in a moment.'));
    }

    $rid = nri_generate_request_id();
    update_post_meta($post_id, 'request_id',     $rid);
    update_post_meta($post_id, 'status',         'submitted');
    update_post_meta($post_id, 'payment_status', 'pending');
    update_post_meta($post_id, 'field_data',     $fd);
    // A brand-new request should be findable immediately, not after the
    // search cache's TTL expires — see nri_search_matching_request_ids().
    nri_flush_request_search_cache();
    // Delivery tracking for the staff notification email (see nri_run_admin_notification()
    // in notifications.php): flagged pending now, cleared only once the email is accepted
    // for delivery, so a lost/failed send is retried instead of silently forgotten.
    nri_mark_admin_notification_pending( $post_id, $is_new );
    nri_log( 'nri_create_request: saved post ' . $post_id . ' as ' . $rid . ' for ' . $email );

    // Stamp the upload token on the request itself so a document that's
    // STILL uploading in the background when this response goes out can be
    // linked to this request afterwards (nri_ajax_attach_pending_document),
    // once it finishes, without needing the student to still be logged in
    // at that exact moment — the token is the proof of ownership either way.
    if ( $upload_token !== '' ) {
        update_post_meta( $post_id, '_nri_upload_token', $upload_token );
    }

    $documents = array();

    // Find the file field's label for doc_type naming (used by both the
    // background-upload path below and the legacy/fallback path further down)
    $file_field = $wpdb->get_row(
        "SELECT field_label FROM {$wpdb->prefix}nri_fields WHERE field_type='file' AND is_required=1 LIMIT 1"
    );
    $doc_type_default = $file_field ? $file_field->field_label : 'Uploaded Document';

    // ── Claim documents already uploaded in the background ─────────────────────
    // These finished uploading (and had their thumbnails generated) BEFORE
    // this request was ever submitted — see nri_ajax_pending_upload(). All
    // that's left to do here is re-parent each attachment onto this request
    // and record it, which is cheap (no file I/O, no thumbnail generation).
    if ( ! empty( $pending_ids ) && $upload_token !== '' ) {
        foreach ( $pending_ids as $pending_id ) {
            $att = get_post( $pending_id );
            if ( ! $att || $att->post_type !== 'attachment' ) { continue; }
            $owner_token = get_post_meta( $pending_id, '_nri_pending_token', true );
            // Ownership check: only THIS browser's own background upload
            // (matching upload_token) can be claimed — prevents one
            // submission from grabbing another student's in-flight upload
            // by guessing an attachment ID.
            if ( $owner_token === '' || $owner_token !== $upload_token ) { continue; }

            wp_update_post( array( 'ID' => $pending_id, 'post_parent' => $post_id ) );
            delete_post_meta( $pending_id, '_nri_pending_token' );
            delete_post_meta( $pending_id, '_nri_pending_at' );

            $documents[] = array(
                'file'        => $pending_id,
                'doc_type'    => $doc_type_default,
                'is_provider' => 0,
                'expiry'      => '',
                'uploaded_at' => current_time( 'mysql' ),
            );
        }
    }

    // ── Legacy/fallback path: files posted synchronously with this request ─────
    // Normally empty now (the browser uploads documents in the background —
    // see above), but kept as a fallback for JavaScript-disabled submissions
    // or a background upload that never got queued.
    if ( ! empty( $_FILES['field_documents']['name'] ) ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $files = $_FILES['field_documents'];
        $count = is_array( $files['name'] ) ? count( $files['name'] ) : 0;

        for ( $i = 0; $i < $count; $i++ ) {
            if ( empty( $files['name'][ $i ] ) ) { continue; }
            // Re-shape into single-file array for media_handle_sideload-style processing
            $single = array(
                'name'     => $files['name'][ $i ],
                'type'     => $files['type'][ $i ],
                'tmp_name' => $files['tmp_name'][ $i ],
                'error'    => $files['error'][ $i ],
                'size'     => $files['size'][ $i ],
            );

            // Skip files with upload errors
            if ( $single['error'] !== UPLOAD_ERR_OK ) {
                nri_log( 'File upload error code ' . $single['error'] . ' for ' . $single['name'] );
                continue;
            }

            // Validate size & type
            if ( $single['size'] > 10 * 1024 * 1024 ) {
                nri_log( 'File too large: ' . $single['name'] );
                continue;
            }
            $allowed_mimes = array( 'application/pdf', 'image/jpeg', 'image/png', 'image/jpg' );
            $finfo = new finfo( FILEINFO_MIME_TYPE );
            $mime  = $finfo->file( $single['tmp_name'] );
            if ( ! in_array( $mime, $allowed_mimes ) ) {
                nri_log( 'File type not allowed: ' . $mime . ' for ' . $single['name'] );
                continue;
            }

            // Move into uploads dir via wp_handle_upload
            $upload = wp_handle_upload( $single, array( 'test_form' => false ) );
            if ( isset( $upload['error'] ) || ! isset( $upload['file'] ) ) {
                nri_log( 'wp_handle_upload failed: ' . ( isset( $upload['error'] ) ? $upload['error'] : 'unknown' ) );
                continue;
            }

            // Create attachment post
            $attachment = array(
                'post_mime_type' => $upload['type'],
                'post_title'     => sanitize_file_name( pathinfo( $single['name'], PATHINFO_FILENAME ) ),
                'post_content'   => '',
                'post_status'    => 'inherit',
            );
            $att_id = wp_insert_attachment( $attachment, $upload['file'], $post_id );
            if ( is_wp_error( $att_id ) || ! $att_id ) { continue; }

            // (no thumbnail generation — see nri_store_document_upload())

            // Ensure document is stored as PDF/JPG/PNG, not AVIF/WebP
            nri_sanitise_attachment( $att_id );

            $documents[] = array(
                'file'        => $att_id,
                'doc_type'    => $doc_type_default,
                'is_provider' => 0,
                'expiry'      => '',
                'uploaded_at' => current_time( 'mysql' ),
            );
        }
    }

    if ( ! empty( $documents ) ) {
        update_post_meta( $post_id, 'documents', $documents );
        nri_add_history( $post_id, 'Documents uploaded', count( $documents ) . ' file(s) attached.' );
    }

    // Generate the initial Student Requirement Description from the
    // submitted fields (nri_generate_requirement_description() in
    // helpers.php) — staff can edit or regenerate it later from the
    // request detail page (nri_ajax_save_description /
    // nri_ajax_regenerate_description below).
    $req_meta_for_desc = nri_get_meta( $post_id );
    nri_save_requirement_description( $post_id, nri_generate_requirement_description( $post_id, $req_meta_for_desc ), false );

    nri_add_history($post_id, 'Request submitted', $is_new ? 'New account created.' : '');

    // Admin email + WhatsApp (CallMeBot) notifications are pure side effects —
    // the student's browser doesn't need to wait for them. CallMeBot in
    // particular is a third-party HTTP call with a 15s timeout, made once per
    // configured staff number (sequentially), so with a few staff numbers
    // configured this alone could add many extra seconds to what the student
    // sees as "submitting...". Defer both to run AFTER the JSON response has
    // already been sent to the browser (nri_defer_after_response() below), so
    // submission feels instant while the notifications still fire normally,
    // just a moment later, in the background.
    $response = array(
        'redirect'   => home_url('/client-dashboard'),
        'request_id' => $rid,
        'post_id'    => (int) $post_id,
        'is_new'     => $is_new,
    );

    // Cache this exact response under the submission token for a few
    // minutes — see the idempotency check near the top of this function. If
    // the browser's request timed out on this end even though we finished
    // successfully (slow mobile network, server briefly slow) and the
    // client retries, that retry gets this SAME response back instead of
    // creating a second request. (Stored BEFORE the emails below so a retry
    // caused by a slow mail server can never create a duplicate request.)
    if ( $submission_token !== '' ) {
        set_transient( 'nri_submit_' . md5( $submission_token ), $response, 10 * MINUTE_IN_SECONDS );
    }

    // ── The two emails that matter run NOW, inside this request ──────────────
    // The staff "new request" email and the client "request submitted" email used to be
    // pushed to a PHP shutdown callback that runs after the response. That is the one place
    // hosts differ most (output buffering, LiteSpeed/LSAPI vs PHP-FPM, process recyclers
    // that stop a worker the moment the response is out) and when it fails nothing is
    // logged — which is how emails could vanish while the "Send test email" button (which
    // runs inside a normal request) kept working. Sent here they behave exactly like that
    // test email. Each send is bounded (SMTP timeout 10s, see smtp.php), isolated, recorded
    // on the request, and retried automatically if the mail server refuses it.
    $notify_t0 = microtime( true );
    foreach ( array( 'admin', 'client' ) as $notify_kind ) {
        // If the FIRST send already burned several seconds failing (mail host down/hung),
        // don't make the visitor wait through a second doomed attempt — the retry sweep
        // (notifications.php) delivers the remaining email as soon as the host answers.
        if ( $notify_kind === 'client' && ( microtime( true ) - $notify_t0 ) > 5 && get_post_meta( $post_id, '_nri_admin_notify_pending', true ) ) { break; }
        try { nri_run_notification( $post_id, $notify_kind ); }
        catch ( \Throwable $e ) { nri_log( 'nri_create_request ' . $notify_kind . ' notification failed — ' . $e->getMessage() ); }
    }

    // Everything non-critical (account welcome emails, WhatsApp/CallMeBot — a 15s third-party
    // call per number) stays deferred until after the response.
    nri_defer_after_response( function() use ( $post_id, $is_new, $uid, $email, $welcome_pw ) {
        $steps = array(
            function() use ( $is_new, $uid ) { if ( $is_new && function_exists( 'nri_notify_account_created' ) ) { nri_notify_account_created( $uid ); } },
            function() use ( $is_new, $email, $welcome_pw ) { if ( $is_new && $welcome_pw !== '' ) { nri_send_welcome_email( $email, $welcome_pw ); } },
            function() use ( $post_id ) { if ( function_exists( 'nri_wa_on_new_submission' ) ) { nri_wa_on_new_submission( $post_id ); } },
        );
        foreach ( $steps as $step ) {
            try { $step(); } catch ( \Throwable $e ) { nri_log( 'nri_create_request deferred step failed — ' . $e->getMessage() ); }
        }
    } );

    wp_send_json_success( $response );
}

// TRACE: called from nri_ajax_create_request() right before wp_send_json_success()
//        → registers a shutdown callback that (1) tries to flush/close the HTTP
//        connection back to the browser immediately (fastcgi_finish_request()
//        on PHP-FPM, else a manual ob_end_flush()+flush() best effort), then
//        (2) runs the given slow/non-critical work (email + WhatsApp calls)
//        → preconditions: must be called before any wp_die()/exit() in the
//        current request (wp_send_json_success() itself calls wp_die(), which
//        still triggers PHP's normal shutdown sequence, so registering here is
//        safe) → postconditions: the student's response is not delayed by
//        $work; $work still runs in the same request lifecycle, just after the
//        response bytes are handed off → edge cases handled: fastcgi_finish_request
//        missing (shared hosting without PHP-FPM) falls back to manual buffer
//        flushing; ignore_user_abort(true) so the student closing the tab
//        right after submit doesn't kill $work mid-flight; any throwable inside
//        $work is caught and logged so a notification failure can never surface
//        as a fatal error after the response has already gone out.
if ( ! function_exists( 'nri_defer_after_response' ) ) {
    function nri_defer_after_response( callable $work ) {
        register_shutdown_function( function() use ( $work ) {
            // Don't let the browser disconnecting (tab closed right after
            // submit) abort the background notification work.
            if ( function_exists( 'ignore_user_abort' ) ) {
                @ignore_user_abort( true );
            }

            // Best effort: hand the response back to the client now, before
            // doing any of the slow notification work, so the student's
            // "Submitting..." spinner clears as soon as WordPress has built
            // the response — not after CallMeBot/email round-trips.
            if ( function_exists( 'fastcgi_finish_request' ) ) {
                fastcgi_finish_request();
            } else {
                // Non-FPM fallback: flush whatever output buffers are open so
                // the already-written response is pushed to the client instead
                // of sitting in a PHP buffer until script end.
                if ( function_exists( 'session_write_close' ) && session_id() ) {
                    session_write_close();
                }
                while ( ob_get_level() > 0 ) {
                    @ob_end_flush();
                }
                @flush();
            }

            try {
                $work();
            } catch ( \Throwable $e ) {
                if ( function_exists( 'nri_log' ) ) {
                    nri_log( 'nri_defer_after_response: deferred work failed — ' . $e->getMessage() );
                }
            }
        } );
    }
}

// -----------------------------------------------------------
// REQUEST TYPES
// -----------------------------------------------------------
add_action('wp_ajax_nopriv_nri_get_request_types', 'nri_ajax_get_request_types');
add_action('wp_ajax_nri_get_request_types',        'nri_ajax_get_request_types');
function nri_ajax_get_request_types() {
    $types = nri_get_request_types();
    $out   = array();
    foreach ($types as $t) {
        $out[] = array('id' => $t->id, 'name' => $t->name, 'icon' => $t->icon, 'description' => $t->description);
    }
    wp_send_json_success($out);
}

add_action('wp_ajax_nri_save_request_type', 'nri_ajax_save_request_type');
function nri_ajax_save_request_type() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $tbl  = $wpdb->prefix . 'nri_request_types';
    $name = sanitize_text_field(isset($_POST['name']) ? $_POST['name'] : '');
    $desc = sanitize_textarea_field(isset($_POST['description']) ? $_POST['description'] : '');
    $icon = sanitize_text_field(isset($_POST['icon']) ? $_POST['icon'] : '');
    $id   = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    if (!$name) wp_send_json_error(array('message' => 'Name required.'));
    if ($id) {
        $wpdb->update($tbl, array('name' => $name, 'description' => $desc, 'icon' => $icon), array('id' => $id));
    } else {
        $max = (int) $wpdb->get_var("SELECT MAX(sort_order) FROM $tbl") + 1;
        $wpdb->insert($tbl, array('name' => $name, 'description' => $desc, 'icon' => $icon, 'sort_order' => $max, 'is_active' => 1));
    }
    wp_send_json_success();
}

add_action('wp_ajax_nri_delete_request_type', 'nri_ajax_delete_request_type');
function nri_ajax_delete_request_type() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $wpdb->delete($wpdb->prefix . 'nri_request_types', array('id' => intval(isset($_POST['id']) ? $_POST['id'] : 0)));
    wp_send_json_success();
}

// -----------------------------------------------------------
// TICKETS
// -----------------------------------------------------------
add_action('wp_ajax_nopriv_nri_submit_ticket', 'nri_ajax_submit_ticket');
add_action('wp_ajax_nri_submit_ticket',        'nri_ajax_submit_ticket');
function nri_ajax_submit_ticket() {
    $rid    = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $cat_id = intval(isset($_POST['type_id'])    ? $_POST['type_id']    : 0);
    $cat    = sanitize_text_field(isset($_POST['category']) ? $_POST['category'] : '');
    $notes  = sanitize_textarea_field(isset($_POST['notes']) ? $_POST['notes'] : '');
    $email  = sanitize_email(isset($_POST['email']) ? $_POST['email'] : '');

    if (!is_user_logged_in() && is_email($email)) {
        $user = get_user_by('email', $email);
        if (!$user) {
            $pw  = wp_generate_password(12, false);
            $uid = wp_create_user($email, $pw, $email);
            if (!is_wp_error($uid)) {
                wp_update_user(array('ID' => $uid, 'role' => 'nri_client'));
                nri_send_welcome_email($email, $pw);
            }
        } else {
            $uid = $user->ID;
        }
        if (isset($uid) && !is_wp_error($uid)) {
            wp_set_auth_cookie($uid, true);
            wp_set_current_user($uid);
        }
    }

    global $wpdb;
    $wpdb->insert($wpdb->prefix . 'nri_tickets', array(
        'request_id' => $rid,
        'user_id'    => get_current_user_id(),
        'type_id'    => $cat_id,
        'category'   => $cat,
        'status'     => 'open',
        'notes'      => $notes,
    ));
    if ($rid) nri_add_history($rid, 'Service request created: ' . $cat);
    wp_send_json_success(array('id' => $wpdb->insert_id, 'category' => $cat));
}

add_action('wp_ajax_nri_delete_ticket', 'nri_ajax_delete_ticket');
function nri_ajax_delete_ticket() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $wpdb->delete($wpdb->prefix . 'nri_tickets', array('id' => intval(isset($_POST['id']) ? $_POST['id'] : 0)));
    wp_send_json_success();
}

add_action('wp_ajax_nri_update_ticket_status', 'nri_ajax_update_ticket_status');
function nri_ajax_update_ticket_status() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $wpdb->update(
        $wpdb->prefix . 'nri_tickets',
        array('status' => sanitize_text_field(isset($_POST['status']) ? $_POST['status'] : 'open')),
        array('id'     => intval(isset($_POST['id']) ? $_POST['id'] : 0))
    );
    wp_send_json_success();
}

// -----------------------------------------------------------
// MESSAGES
// -----------------------------------------------------------
add_action('wp_ajax_nri_send_message', 'nri_ajax_send_message');
function nri_ajax_send_message() {
    nri_check_nonce();
    if (!is_user_logged_in()) wp_send_json_error(array('message' => 'Login required.'), 401);
    $rid        = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $msg        = sanitize_textarea_field(isset($_POST['message']) ? $_POST['message'] : '');
    $send_email = !empty($_POST['send_email']);
    if (!$msg) wp_send_json_error(array('message' => 'Message cannot be empty.'));
    if (!nri_is_own_request($rid)) wp_send_json_error(array('message' => 'Access denied.'), 403);

    $sender   = wp_get_current_user();
    $is_staff = nri_is_staff();

    global $wpdb;
    $wpdb->insert($wpdb->prefix . 'nri_messages', array(
        'request_id'   => $rid,
        'sender_id'    => get_current_user_id(),
        'message'      => $msg,
        'is_email_sent'=> 0,
    ));
    $mid = $wpdb->insert_id;

    // Send email only when explicitly requested ("Send via Email" button)
    if ($send_email) {
        nri_send_message_email($rid, $msg, $sender->display_name, $is_staff);
        $wpdb->update($wpdb->prefix . 'nri_messages', array('is_email_sent' => 1), array('id' => $mid));
    }

    nri_add_history($rid, 'Message sent by ' . $sender->display_name);
    wp_send_json_success(array(
        'id'           => $mid,
        'message'      => $msg,
        'time'         => current_time( 'd M Y, g:i a' ),
        'is_email_sent'=> $send_email ? 1 : 0,
        'sender_name'  => $sender->display_name,
        'sender_id'    => $sender->ID,
        'is_staff'     => $is_staff ? 1 : 0,
    ));
}

add_action('wp_ajax_nri_delete_message', 'nri_ajax_delete_message');
function nri_ajax_delete_message() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $wpdb->delete($wpdb->prefix . 'nri_messages', array('id' => intval(isset($_POST['id']) ? $_POST['id'] : 0)));
    wp_send_json_success();
}

// -----------------------------------------------------------
// DOCUMENT UPLOAD
// -----------------------------------------------------------
add_action('wp_ajax_nri_upload_document', 'nri_ajax_upload_doc');
function nri_ajax_upload_doc() {
    nri_check_nonce();
    $rid = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    if (!nri_is_own_request($rid)) wp_send_json_error(array('message' => 'Access denied.'), 403);
    if (empty($_FILES['file'])) wp_send_json_error(array('message' => 'No file received.'));
    $file = $_FILES['file'];
    if ($file['size'] > 10 * 1024 * 1024) wp_send_json_error(array('message' => 'File exceeds 10MB.'));
    $allowed = array('application/pdf', 'image/jpeg', 'image/png');
    $finfo   = new finfo(FILEINFO_MIME_TYPE);
    $mime    = $finfo->file($file['tmp_name']);
    if (!in_array($mime, $allowed)) wp_send_json_error(array('message' => 'Only PDF/JPG/PNG allowed.'));
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $att = nri_store_document_upload('file', $rid);
    if (is_wp_error($att)) wp_send_json_error(array('message' => 'Upload failed: ' . $att->get_error_message()));

    // Ensure document is stored as PDF/JPG/PNG, not AVIF/WebP
    nri_sanitise_attachment( intval($att) );

    $doc_type    = sanitize_text_field(isset($_POST['doc_type']) ? $_POST['doc_type'] : 'Document');
    $is_provider = !empty($_POST['is_provider']) ? 1 : 0;
    $docs        = get_post_meta($rid, 'documents', true);
    if (!is_array($docs)) $docs = array();
    $docs[] = array('file' => $att, 'doc_type' => $doc_type, 'is_provider' => $is_provider, 'expiry' => '');
    update_post_meta($rid, 'documents', $docs);
    nri_add_history($rid, 'Document uploaded: ' . $doc_type);
    $att_id  = intval($att);
    wp_send_json_success(array(
        'id'          => $att_id,
        'url'         => function_exists('nri_get_download_url') ? nri_get_download_url($att_id) : wp_get_attachment_url($att_id),
        'view_url'    => wp_get_attachment_url($att_id),
        'filename'    => basename(get_attached_file($att_id)),
        'doc_type'    => $doc_type,
        'is_provider' => $is_provider,
    ));
}

// -----------------------------------------------------------
// BACKGROUND (PRE-SUBMISSION) DOCUMENT UPLOAD
// -----------------------------------------------------------
// Uploads a single document the moment it's selected on the new-request
// form — BEFORE the request exists and often before the student is even
// logged in (a brand-new student has no account yet at this point; one is
// created when the request is finally submitted). The file is stored as an
// unattached (post_parent = 0) media attachment, stamped with the calling
// browser's upload_token, and claimed by nri_ajax_create_request() once the
// student actually hits Submit — see the "background-uploaded documents"
// block there. nopriv because the student is very often not logged in yet.
// Hands the browser a fresh frontend nonce. The nonce printed into the page
// (wp_localize_script in enqueue.php) goes stale if a mobile tab sits open for
// hours, is restored from the back/forward cache, or the page HTML is served
// from a page cache — every AJAX call then fails 403. The JS calls this once,
// swaps the token in and retries. Safe to expose: it only returns a nonce for
// the CURRENT visitor (nonces are tied to the session/user), no data.
add_action('wp_ajax_nri_fresh_nonce',        'nri_ajax_fresh_nonce');
add_action('wp_ajax_nopriv_nri_fresh_nonce', 'nri_ajax_fresh_nonce');
function nri_ajax_fresh_nonce() {
    nocache_headers();
    wp_send_json_success( array( 'nonce' => wp_create_nonce( 'nri_frontend_nonce' ) ) );
}

add_action('wp_ajax_nri_pending_upload', 'nri_ajax_pending_upload');
add_action('wp_ajax_nopriv_nri_pending_upload', 'nri_ajax_pending_upload');
function nri_ajax_pending_upload() {
    // PHP silently DISCARDS the whole POST body (both $_POST and $_FILES come
    // through empty) when a request exceeds post_max_size — which would then
    // fail nri_check_nonce() below with a misleading "security check failed"
    // 403. Detect that case first and say what actually happened. Typical
    // trigger: a big phone-camera photo (or a PDF scan) on a host with a low
    // post_max_size/upload_max_filesize.
    if ( ! empty( $_SERVER['CONTENT_LENGTH'] ) && empty( $_POST ) && empty( $_FILES ) ) {
        $limit = ini_get( 'post_max_size' );
        nri_log( 'nri_pending_upload: body exceeded post_max_size (' . $limit . '), CONTENT_LENGTH=' . (int) $_SERVER['CONTENT_LENGTH'] );
        wp_send_json_error( array( 'message' => 'This file is too large for the server (limit ' . $limit . '). Please choose a smaller file.' ), 413 );
    }
    nri_check_nonce();

    // Thumbnail generation for a large photo can exceed the default memory
    // limit (a fatal that surfaces to the visitor as a generic network
    // error). Ask WordPress for its image-processing headroom and a bit of
    // extra time; best-effort, ignored on hosts that forbid it.
    if ( function_exists( 'wp_raise_memory_limit' ) ) { wp_raise_memory_limit( 'image' ); }
    if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 120 ); }

    $token = sanitize_text_field( isset( $_POST['upload_token'] ) ? $_POST['upload_token'] : '' );
    if ( ! preg_match( '/^[A-Za-z0-9_-]{8,64}$/', $token ) ) {
        wp_send_json_error( array( 'message' => 'Invalid upload session. Please refresh the page and try again.' ) );
    }
    if ( empty( $_FILES['file'] ) ) {
        wp_send_json_error( array( 'message' => 'No file received.' ) );
    }
    $file = $_FILES['file'];
    if ( $file['error'] !== UPLOAD_ERR_OK ) {
        nri_log( 'nri_pending_upload: PHP upload error code ' . $file['error'] . ' size=' . ( isset( $file['size'] ) ? $file['size'] : '?' ) );
        $msgs = array(
            UPLOAD_ERR_INI_SIZE  => 'This file is larger than the server allows. Please choose a smaller file.',
            UPLOAD_ERR_FORM_SIZE => 'This file is too large. Please choose a smaller file.',
            UPLOAD_ERR_PARTIAL   => 'The upload was interrupted. Please retry.',
            UPLOAD_ERR_NO_FILE   => 'No file received. Please select the file again.',
        );
        wp_send_json_error( array( 'message' => isset( $msgs[ $file['error'] ] ) ? $msgs[ $file['error'] ] : 'The server could not store this file. Please try again.' ) );
    }
    if ( $file['size'] > 10 * 1024 * 1024 ) {
        wp_send_json_error( array( 'message' => 'File exceeds 10MB.' ) );
    }
    $allowed = array( 'application/pdf', 'image/jpeg', 'image/png' );
    $finfo   = new finfo( FILEINFO_MIME_TYPE );
    $mime    = $finfo->file( $file['tmp_name'] );
    if ( ! in_array( $mime, $allowed, true ) ) {
        wp_send_json_error( array( 'message' => 'Only PDF/JPG/PNG allowed.' ) );
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    // post_id 0 = unattached; nri_ajax_create_request() (or
    // nri_ajax_attach_pending_document() below) re-parents this onto the
    // actual request once one exists.
    $att_id = nri_store_document_upload( 'file', 0 );
    if ( is_wp_error( $att_id ) ) {
        nri_log( 'nri_pending_upload: upload failed — ' . $att_id->get_error_message() . ' (name=' . $file['name'] . ', mime=' . $mime . ', size=' . $file['size'] . ')' );
        wp_send_json_error( array( 'message' => 'Upload failed: ' . $att_id->get_error_message() ) );
    }
    $att_id = intval( $att_id );

    // Ensure document is stored as PDF/JPG/PNG, not AVIF/WebP (thumbnail
    // generation already happened inside media_handle_upload() — this is
    // the expensive work now finished BEFORE the request is submitted,
    // instead of blocking it).
    nri_sanitise_attachment( $att_id );

    update_post_meta( $att_id, '_nri_pending_token', $token );
    update_post_meta( $att_id, '_nri_pending_at', time() );

    wp_send_json_success( array(
        'id'       => $att_id,
        'filename' => basename( get_attached_file( $att_id ) ),
    ) );
}

// Attaches a document to a request that ALREADY EXISTS — used only when a
// background upload (above) was still in flight at the moment the student
// clicked Submit, so nri_ajax_create_request() couldn't claim it yet. The
// browser keeps that upload running after showing the success screen, and
// calls this the moment it finishes. nopriv for the same reason as above:
// the auth cookie nri_ajax_create_request() just set may not have round-
// tripped to the browser yet, so ownership is proven by the shared token,
// not by session state.
add_action('wp_ajax_nri_attach_pending_document', 'nri_ajax_attach_pending_document');
add_action('wp_ajax_nopriv_nri_attach_pending_document', 'nri_ajax_attach_pending_document');
function nri_ajax_attach_pending_document() {
    nri_check_nonce();

    $rid    = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    $att_id = intval( isset( $_POST['attachment_id'] ) ? $_POST['attachment_id'] : 0 );
    $token  = sanitize_text_field( isset( $_POST['upload_token'] ) ? $_POST['upload_token'] : '' );
    if ( ! $rid || ! $att_id || $token === '' ) {
        wp_send_json_error( array( 'message' => 'Missing data.' ) );
    }

    $post = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nri_request' ) {
        wp_send_json_error( array( 'message' => 'Request not found.' ), 404 );
    }
    $req_token = get_post_meta( $rid, '_nri_upload_token', true );
    if ( $req_token === '' || $req_token !== $token ) {
        wp_send_json_error( array( 'message' => 'Access denied.' ), 403 );
    }

    $att = get_post( $att_id );
    if ( ! $att || $att->post_type !== 'attachment' ) {
        wp_send_json_error( array( 'message' => 'File not found.' ), 404 );
    }
    $att_token = get_post_meta( $att_id, '_nri_pending_token', true );
    if ( $att_token === '' || $att_token !== $token ) {
        wp_send_json_error( array( 'message' => 'Access denied.' ), 403 );
    }

    wp_update_post( array( 'ID' => $att_id, 'post_parent' => $rid ) );
    delete_post_meta( $att_id, '_nri_pending_token' );
    delete_post_meta( $att_id, '_nri_pending_at' );

    $docs = get_post_meta( $rid, 'documents', true );
    if ( ! is_array( $docs ) ) { $docs = array(); }
    $already = false;
    foreach ( $docs as $d ) {
        if ( isset( $d['file'] ) && (int) $d['file'] === $att_id ) { $already = true; break; }
    }
    if ( ! $already ) {
        $docs[] = array(
            'file'        => $att_id,
            'doc_type'    => 'Uploaded Document',
            'is_provider' => 0,
            'expiry'      => '',
            'uploaded_at' => current_time( 'mysql' ),
        );
        update_post_meta( $rid, 'documents', $docs );
        nri_add_history( $rid, 'Document uploaded', basename( get_attached_file( $att_id ) ) . ' (finished uploading in the background)' );
    }

    wp_send_json_success( array( 'id' => $att_id ) );
}

// Housekeeping: a background upload that's never claimed (student picked a
// file, then abandoned the form entirely) would otherwise sit in the media
// library forever as an unattached attachment. Sweep anything still
// unclaimed after 48h once a day.
add_action( 'nri_cleanup_pending_uploads_event', 'nri_cleanup_pending_uploads' );
function nri_cleanup_pending_uploads() {
    global $wpdb;
    $cutoff = time() - 2 * DAY_IN_SECONDS;
    $ids = $wpdb->get_col( $wpdb->prepare(
        "SELECT pm.post_id FROM {$wpdb->postmeta} pm
         INNER JOIN {$wpdb->postmeta} pm2 ON pm2.post_id = pm.post_id AND pm2.meta_key = '_nri_pending_at'
         WHERE pm.meta_key = '_nri_pending_token' AND CAST(pm2.meta_value AS UNSIGNED) < %d",
        $cutoff
    ) );
    foreach ( (array) $ids as $id ) {
        wp_delete_attachment( (int) $id, true );
    }
}
if ( ! wp_next_scheduled( 'nri_cleanup_pending_uploads_event' ) ) {
    wp_schedule_event( time() + 300, 'daily', 'nri_cleanup_pending_uploads_event' );
}

add_action('wp_ajax_nri_delete_document', 'nri_ajax_delete_doc');
function nri_ajax_delete_doc() {
    nri_check_nonce(); nri_require_staff();
    $rid    = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $att_id = intval(isset($_POST['attachment_id']) ? $_POST['attachment_id'] : 0);
    $docs   = get_post_meta($rid, 'documents', true);
    if (!is_array($docs)) $docs = array();
    $new = array();
    foreach ($docs as $d) {
        if ((int) $d['file'] !== $att_id) $new[] = $d;
    }
    update_post_meta($rid, 'documents', $new);
    wp_send_json_success();
}

// -----------------------------------------------------------
// REQUEST MANAGEMENT (admin)
// -----------------------------------------------------------
add_action('wp_ajax_nri_get_requests', 'nri_ajax_get_requests');
function nri_ajax_get_requests() {
    nri_check_nonce(); nri_require_staff();
    // Staff just opened/refreshed the list: also retry any new-request email that has not
    // been delivered yet (cheap + rate-limited; never allowed to break the list itself).
    if ( function_exists( 'nri_retry_pending_admin_notifications' ) ) {
        try { nri_retry_pending_admin_notifications(); } catch ( \Throwable $e ) { nri_log( 'notification retry sweep failed — ' . $e->getMessage() ); }
    }
    $status          = sanitize_text_field(isset($_POST['status']) ? $_POST['status'] : '');
    $internal_status = sanitize_key(isset($_POST['internal_status']) ? $_POST['internal_status'] : '');
    $search          = sanitize_text_field(isset($_POST['search']) ? $_POST['search'] : '');
    $paged    = max(1, intval(isset($_POST['paged']) ? $_POST['paged'] : 1));
    $per_page = 20;

    $date_filter = sanitize_key(isset($_POST['date_filter']) ? $_POST['date_filter'] : '');
    $date_from   = sanitize_text_field(isset($_POST['date_from']) ? $_POST['date_from'] : '');
    $date_to     = sanitize_text_field(isset($_POST['date_to'])   ? $_POST['date_to']   : '');
    list($date_after, $date_before) = nri_compute_request_date_range($date_filter, $date_from, $date_to);

    if ($search === '') {
        // FAST PATH — no search term: real SQL-level pagination (LIMIT/
        // OFFSET via WP_Query's own posts_per_page/paged), exactly like
        // before the comprehensive-search feature was added. This is the
        // common case (most tab loads/page changes/status-only filters
        // carry no search term) and it must never touch more rows than the
        // one page it's about to show.
        $args = array(
            'post_type'      => 'nri_request',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $paged,
            'orderby'        => 'date',
            'order'          => 'DESC',
        );
        $meta_query = array();
        if ($status) { $meta_query[] = array('key' => 'status', 'value' => $status); }
        if ($internal_status) {
            $ist_mq = nri_internal_status_meta_query($internal_status);
            if ($ist_mq) { $meta_query[] = $ist_mq; }
        }
        if ($meta_query) {
            if (count($meta_query) > 1) { $meta_query['relation'] = 'AND'; }
            $args['meta_query'] = $meta_query;
        }
        $date_query = nri_request_date_query($date_after, $date_before);
        if ($date_query) { $args['date_query'] = $date_query; }
        $q        = new WP_Query($args);
        $page_ids = wp_list_pluck($q->posts, 'ID');
        $total    = $q->found_posts;
        $pages    = $q->max_num_pages ? $q->max_num_pages : 1;
    } else {
        // SEARCH PATH — WP_Query's built-in 's' parameter only matches
        // post_title/post_content, but a request's actual submitted data
        // (applicant name, university, phone, enrollment number, etc.)
        // lives in the field_data postmeta array, and client name/email
        // live on the wp_users row — neither reachable via 's'. There is
        // no indexed column to search across the admin-configurable set of
        // submitted fields, so this path necessarily scans every
        // status-matching request's meta once per search and can't use a
        // single-query SQL LIMIT/OFFSET. Two things keep it cheap even on
        // a large table:
        //  1. 'fields' => 'ids' + WP_Query's own meta-cache priming means
        //     this is one lightweight ID query plus one batched postmeta
        //     query for the whole set — not one query per row.
        //  2. The matched-ID list for a given status+search combination is
        //     cached in a short-lived transient (45s), so paginating
        //     through search results, or the same term being searched
        //     again shortly after, don't re-scan the table — a deliberate,
        //     bounded staleness window (new/changed requests can take up
        //     to 45s to appear in *search* results specifically; the
        //     no-search fast path above is always fully live).
        list($matched_ids, $total) = nri_search_matching_request_ids($status, $search, $date_after, $date_before, $internal_status);
        $pages    = max(1, (int) ceil($total / $per_page));
        $page_ids = array_slice($matched_ids, ($paged - 1) * $per_page, $per_page);
    }

    $out = array();
    foreach ($page_ids as $pid) {
        $p      = get_post($pid);
        $meta   = nri_get_meta($pid);
        $author = get_userdata($p->post_author);
        $mgr    = $meta['assigned_manager'] ? get_userdata($meta['assigned_manager']) : null;
        $vendor = $meta['assigned_vendor']  ? get_userdata($meta['assigned_vendor'])  : null;
        $fd     = $meta['field_data'];
        $svc    = !empty($fd['field_service_type']) ? $fd['field_service_type']
                : (!empty($fd['field_document_type']) ? $fd['field_document_type'] : 'Request');
        $out[]  = array(
            'id'           => $p->ID,
            'request_id'   => $meta['request_id'] ? $meta['request_id'] : '#' . $p->ID,
            'client'       => $author ? $author->display_name : '?',
            'email'        => $author ? $author->user_email : '',
            'service'      => wp_trim_words($svc, 6, ''),
            'status'       => $meta['status'],
            'status_label' => nri_status_label($meta['status']),
            'status_color' => nri_status_color($meta['status']),
            // Staff-only CRM pipeline stage — see the "INTERNAL STATUS"
            // section in helpers.php. Deliberately kept in the same
            // response as everything above (this whole endpoint is
            // nri_require_staff()-gated, so nothing here ever reaches a
            // client), never returned from any client-facing endpoint.
            'internal_status'       => $meta['internal_status'],
            'internal_status_label' => nri_internal_status_label($meta['internal_status']),
            'internal_status_color' => nri_internal_status_color($meta['internal_status']),
            'quote'        => $meta['quote_amount'] ? 'INR ' . number_format((float) $meta['quote_amount'], 2) : '-',
            'delivery'     => $meta['estimated_delivery'] ? date('d M Y', strtotime($meta['estimated_delivery'])) : '-',
            'manager'      => $mgr    ? $mgr->display_name    : 'Unassigned',
            'vendor'       => $vendor ? $vendor->display_name : 'Unassigned',
            'date'         => get_the_date('d M Y', $p->ID),
            // Whether the card's "Docs" button has anything to download —
            // avoids a click-then-error round trip when there are none.
            'has_docs'     => ! empty( nri_get_documents( $p->ID ) ),
            // Pre-rendered, already-escaped compact summary of the
            // submitted form data (grouped Applicant/Academic/
            // Location-Delivery/Remarks lines) — see
            // nri_render_request_card_fields() in helpers.php. Built
            // server-side so escaping and field-key fallback logic live
            // in one place instead of being duplicated in JS strings.
            'card_fields'  => nri_render_request_card_fields( $p->ID, $meta ),
            // Plain-text Student Requirement Description for the card's
            // "Copy Description" button — see nri_get_requirement_description()
            // in helpers.php. Lazily generated + persisted on first access
            // for any request that predates this feature.
            'description'  => nri_get_requirement_description( $p->ID, $meta )['text'],
        );
    }
    // Internal-status filter bar data: every defined status (including
    // inactive ones already in use, so an old assignment stays labeled
    // instead of falling back to a raw slug) plus a count per slug,
    // scoped the same way as nri_get_internal_status_counts()'s own
    // docblock explains (client status + date, not the free-text search
    // term). Sent on every list load so the pill bar can render/refresh
    // without a second round trip.
    $istatus_rows = array();
    foreach ( nri_get_internal_statuses( false ) as $r ) {
        $istatus_rows[] = array(
            'slug'      => $r->slug,
            'label'     => $r->label,
            'color'     => $r->color ? $r->color : '#6b7280',
            'is_active' => (int) $r->is_active === 1,
        );
    }
    wp_send_json_success(array(
        'requests'               => $out,
        'total'                  => $total,
        'pages'                  => $pages,
        'internal_statuses'      => $istatus_rows,
        'internal_status_counts' => nri_get_internal_status_counts( $status, $date_after, $date_before ),
    ));
}

// Builds a single lower-cased, whitespace-joined string containing every
// value that makes sense to search a request by: request ID, applicant
// name/email, service/document type, status label, quote, manager/vendor
// names, and — critically — every value inside the submitted field_data
// array (university, course, enrollment number, phone, remarks, etc., no
// matter what field keys this install's form is configured with). Shared
// by both the Requests tab and Form Submissions tab search so the two stay
// consistent.
function nri_request_search_haystack($pid, $meta, $author) {
    $parts = array();
    $parts[] = isset($meta['request_id']) ? $meta['request_id'] : '';
    $parts[] = '#' . $pid;
    $parts[] = $author ? $author->display_name : '';
    $parts[] = $author ? $author->user_email : '';
    $parts[] = isset($meta['status']) ? nri_status_label($meta['status']) : '';
    $parts[] = isset($meta['quote_amount']) ? $meta['quote_amount'] : '';
    if (!empty($meta['assigned_manager'])) { $m = get_userdata($meta['assigned_manager']); if ($m) $parts[] = $m->display_name; }
    if (!empty($meta['assigned_vendor']))  { $v = get_userdata($meta['assigned_vendor']);  if ($v) $parts[] = $v->display_name; }
    if (!empty($meta['field_data']) && is_array($meta['field_data'])) {
        foreach ($meta['field_data'] as $val) {
            if (is_array($val)) {
                foreach ($val as $vv) { if (!is_array($vv)) { $parts[] = (string) $vv; } }
            } elseif (!is_array($val)) {
                $parts[] = (string) $val;
            }
        }
    }
    $parts = array_filter($parts, function($x){ return $x !== null && $x !== ''; });
    return strtolower(implode(' | ', $parts));
}

// Runs the comprehensive multi-term meta+author search for a given
// status+search combination and returns array($matched_ids, $total),
// newest-first (matching the default 'date DESC' ordering used
// everywhere else in the admin lists). Shared by the Requests tab and
// Form Submissions tab so both get the same caching behavior.
//
// Result is cached in a 45-second transient keyed by status+search: the
// underlying scan (one ID query + one batched meta-cache-priming query,
// via 'fields' => 'ids' + WP_Query's own update_post_meta_cache) is cheap
// per call, but a user paginating through several pages of the same
// search, or re-running the same search moments later, would otherwise
// repeat it — the transient makes every page after the first free, and
// caps how often a given search re-scans the table. The tradeoff is a
// bounded staleness window (up to 45s) on SEARCH results specifically; a
// no-search list load is always fully live (see the fast path in
// nri_ajax_get_requests()) because it never goes through this function.
function nri_search_matching_request_ids($status, $search, $date_after = null, $date_before = null, $internal_status = '') {
    $cache_key = 'nri_srch_' . md5($status . '|' . $search . '|' . $date_after . '|' . $date_before . '|' . $internal_status);
    $cached    = get_transient($cache_key);
    if (is_array($cached)) { return array($cached, count($cached)); }

    $id_args = array(
        'post_type'      => 'nri_request',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'fields'         => 'ids',
    );
    $meta_query = array();
    if ($status) { $meta_query[] = array('key' => 'status', 'value' => $status); }
    if ($internal_status) {
        $ist_mq = nri_internal_status_meta_query($internal_status);
        if ($ist_mq) { $meta_query[] = $ist_mq; }
    }
    if ($meta_query) {
        if (count($meta_query) > 1) { $meta_query['relation'] = 'AND'; }
        $id_args['meta_query'] = $meta_query;
    }
    $date_query = nri_request_date_query($date_after, $date_before);
    if ($date_query) { $id_args['date_query'] = $date_query; }
    $all_ids = get_posts($id_args);

    $search_terms = array_filter(preg_split('/\s+/', strtolower(trim($search))));
    $matched_ids  = array();
    foreach ($all_ids as $pid) {
        $meta   = nri_get_meta($pid);
        $author = get_userdata(get_post_field('post_author', $pid));
        $hay    = nri_request_search_haystack($pid, $meta, $author);
        $ok = true;
        foreach ($search_terms as $term) {
            if (strpos($hay, $term) === false) { $ok = false; break; }
        }
        if ($ok) { $matched_ids[] = $pid; }
    }

    set_transient($cache_key, $matched_ids, 45);
    return array($matched_ids, count($matched_ids));
}

// Clears every cached search result so the next search (any status/term
// combination) re-scans instead of serving up-to-45s-stale results — see
// nri_search_matching_request_ids(). Called after a request is created or
// deleted (the two changes that add/remove a row from every possible
// result set); an in-place edit to an existing request's fields only
// affects that one request's presence in a *few* specific searches, so
// those are left to expire on their own via the 45s TTL rather than
// flushing the whole cache on every field/status/quote/assignment change
// across the admin UI.
function nri_flush_request_search_cache() {
    global $wpdb;
    $wpdb->query(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_nri\_srch\_%' OR option_name LIKE '\_transient\_timeout\_nri\_srch\_%'"
    );
}

// -----------------------------------------------------------
// INTERNAL STATUS (CRM pipeline) — staff-only, never client-facing.
// See the "INTERNAL STATUS" section in helpers.php for the shared
// label/color/meta_query helpers this block builds on.
// -----------------------------------------------------------

// Assigns an internal status to one request — any staff member
// (nri_is_staff(), not just an administrator) can do this; it's the
// day-to-day pipeline action, distinct from *defining* the status list
// below, which is admin-only. Refuses an inactive/unknown slug UNLESS
// it's the slug the request already carries (so a request already
// sitting on a status that got deactivated afterward is never silently
// blocked from having ITS status re-saved as part of some other edit —
// though the UI itself won't offer a deactivated slug as a new choice).
add_action( 'wp_ajax_nri_set_internal_status', 'nri_ajax_set_internal_status' );
function nri_ajax_set_internal_status() {
    nri_check_nonce(); nri_require_staff();
    $rid  = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    $slug = sanitize_key( isset( $_POST['internal_status'] ) ? $_POST['internal_status'] : '' );
    if ( ! $rid || get_post_type( $rid ) !== 'nri_request' ) {
        wp_send_json_error( array( 'message' => 'Request not found.' ) );
    }
    if ( $slug === '' ) {
        wp_send_json_error( array( 'message' => 'Missing internal status.' ) );
    }
    $current = nri_get_meta( $rid )['internal_status'];
    $map     = nri_get_internal_status_map( false );
    if ( ! isset( $map[ $slug ] ) ) {
        wp_send_json_error( array( 'message' => 'Unknown internal status.' ) );
    }
    if ( (int) $map[ $slug ]->is_active !== 1 && $slug !== $current ) {
        wp_send_json_error( array( 'message' => 'That status is deactivated and can no longer be newly assigned.' ) );
    }
    update_post_meta( $rid, 'internal_status', $slug );
    if ( $slug !== $current ) {
        nri_add_history( $rid, 'internal_status_changed', nri_internal_status_label( $current ) . ' → ' . nri_internal_status_label( $slug ) );
    }
    wp_send_json_success( array(
        'internal_status'       => $slug,
        'internal_status_label' => nri_internal_status_label( $slug ),
        'internal_status_color' => nri_internal_status_color( $slug ),
    ) );
}

// Full status-definition list for the management screen (includes
// inactive rows — the admin needs to see and re-activate/delete those
// too, unlike the request-card dropdown which only offers active ones).
add_action( 'wp_ajax_nri_admin_list_internal_statuses', 'nri_ajax_admin_list_internal_statuses' );
function nri_ajax_admin_list_internal_statuses() {
    nri_check_nonce(); nri_require_admin();
    global $wpdb;
    $rows  = nri_get_internal_statuses( false, true );
    $out   = array();
    foreach ( $rows as $r ) {
        $out[] = array(
            'id'         => (int) $r->id,
            'slug'       => $r->slug,
            'label'      => $r->label,
            'color'      => $r->color ? $r->color : '#6b7280',
            'sort_order' => (int) $r->sort_order,
            'is_active'  => (int) $r->is_active === 1,
            // How many requests currently carry this exact slug — lets
            // the management UI warn before a delete instead of the
            // delete endpoint being the first place that's discovered.
            'in_use'     => (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = 'internal_status' AND pm.meta_value = %s AND p.post_type = 'nri_request' AND p.post_status = 'publish'",
                $r->slug
            ) ) + ( $r->slug === 'inquiry' ? nri_count_requests_defaulting_to_inquiry() : 0 ),
        );
    }
    wp_send_json_success( $out );
}

// Requests with NO internal_status meta row at all also count as
// "Inquiry" for display (see nri_get_meta()'s default) — this adds those
// in for the Inquiry row's in_use count specifically, so "safe to
// delete?" reflects reality for that one stage instead of undercounting
// every request that has simply never been touched.
function nri_count_requests_defaulting_to_inquiry() {
    global $wpdb;
    return (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->posts} p
         WHERE p.post_type = 'nri_request' AND p.post_status = 'publish'
         AND NOT EXISTS (
             SELECT 1 FROM {$wpdb->postmeta} pm WHERE pm.post_id = p.ID AND pm.meta_key = 'internal_status' AND pm.meta_value <> ''
         )"
    );
}

// Create (no id) or rename (id present) a status definition. Reordering,
// activating/deactivating, and deleting each have their own endpoint
// below — this one only ever touches label/color.
add_action( 'wp_ajax_nri_admin_save_internal_status', 'nri_ajax_admin_save_internal_status' );
function nri_ajax_admin_save_internal_status() {
    nri_check_nonce(); nri_require_admin();
    global $wpdb;
    $id    = intval( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
    $label = sanitize_text_field( isset( $_POST['label'] ) ? $_POST['label'] : '' );
    $color = sanitize_hex_color( isset( $_POST['color'] ) ? $_POST['color'] : '' );
    if ( $color === null || $color === '' ) { $color = '#6b7280'; }
    if ( $label === '' ) { wp_send_json_error( array( 'message' => 'Status name is required.' ) ); }
    $table = $wpdb->prefix . 'nri_internal_statuses';

    if ( $id ) {
        // Rename an existing status — the slug (and therefore every
        // request currently pointing at it via postmeta) is left
        // untouched on purpose: changing only the display label/color
        // means every existing assignment stays correctly labeled with
        // zero postmeta rewriting, no matter how many requests use it.
        $existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", $id ) );
        if ( ! $existing ) { wp_send_json_error( array( 'message' => 'Status not found.' ) ); }
        $wpdb->update( $table, array( 'label' => $label, 'color' => $color ), array( 'id' => $id ) );
        nri_clear_internal_status_cache();
        wp_send_json_success( array( 'id' => $id, 'slug' => $existing->slug, 'label' => $label, 'color' => $color ) );
    }

    // Create — auto-slug from the label, de-duplicated if it collides
    // with an existing slug (append -2, -3, … the same way WordPress
    // itself de-dupes post slugs).
    $base_slug = nri_generate_internal_status_slug( $label );
    $slug      = $base_slug;
    $n         = 2;
    while ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE slug=%s", $slug ) ) ) {
        $slug = $base_slug . '_' . $n;
        $n++;
    }
    $max_order = (int) $wpdb->get_var( "SELECT MAX(sort_order) FROM $table" );
    $wpdb->insert( $table, array(
        'slug'       => $slug,
        'label'      => $label,
        'color'      => $color,
        'sort_order' => $max_order + 10,
        'is_active'  => 1,
    ) );
    nri_clear_internal_status_cache();
    wp_send_json_success( array( 'id' => (int) $wpdb->insert_id, 'slug' => $slug, 'label' => $label, 'color' => $color ) );
}

// Persists a new top-to-bottom order for the whole list in one call —
// $_POST['order'] is a comma-separated list of status IDs in the new
// order (matches how the management UI's up/down controls submit it).
add_action( 'wp_ajax_nri_admin_reorder_internal_statuses', 'nri_ajax_admin_reorder_internal_statuses' );
function nri_ajax_admin_reorder_internal_statuses() {
    nri_check_nonce(); nri_require_admin();
    global $wpdb;
    $order_raw = isset( $_POST['order'] ) ? sanitize_text_field( wp_unslash( $_POST['order'] ) ) : '';
    $ids       = array_filter( array_map( 'intval', explode( ',', $order_raw ) ) );
    if ( empty( $ids ) ) { wp_send_json_error( array( 'message' => 'Nothing to reorder.' ) ); }
    $table = $wpdb->prefix . 'nri_internal_statuses';
    $pos   = 10;
    foreach ( $ids as $id ) {
        $wpdb->update( $table, array( 'sort_order' => $pos ), array( 'id' => $id ) );
        $pos += 10;
    }
    nri_clear_internal_status_cache();
    wp_send_json_success();
}

// Activate/deactivate — a deactivated status stops appearing as a
// choice for NEW assignments (nri_get_internal_statuses(true) /
// nri_ajax_set_internal_status()'s is_active check above), but every
// request already carrying it keeps that exact label/color untouched;
// nothing about existing requests changes.
add_action( 'wp_ajax_nri_admin_toggle_internal_status', 'nri_ajax_admin_toggle_internal_status' );
function nri_ajax_admin_toggle_internal_status() {
    nri_check_nonce(); nri_require_admin();
    global $wpdb;
    $id     = intval( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
    $active = ! empty( $_POST['active'] ) ? 1 : 0;
    if ( ! $id ) { wp_send_json_error( array( 'message' => 'Missing status id.' ) ); }
    $table = $wpdb->prefix . 'nri_internal_statuses';
    $wpdb->update( $table, array( 'is_active' => $active ), array( 'id' => $id ) );
    nri_clear_internal_status_cache();
    wp_send_json_success( array( 'id' => $id, 'is_active' => (bool) $active ) );
}

// Delete — only when SAFE, i.e. zero requests currently carry this
// slug (including the implicit "Inquiry" default for untouched
// requests — see nri_count_requests_defaulting_to_inquiry() above).
// Otherwise refuses with a clear message instead of leaving requests
// pointing at a now-nonexistent status row; deactivating is always the
// safe alternative for a status still in use.
add_action( 'wp_ajax_nri_admin_delete_internal_status', 'nri_ajax_admin_delete_internal_status' );
function nri_ajax_admin_delete_internal_status() {
    nri_check_nonce(); nri_require_admin();
    global $wpdb;
    $id = intval( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
    if ( ! $id ) { wp_send_json_error( array( 'message' => 'Missing status id.' ) ); }
    $table = $wpdb->prefix . 'nri_internal_statuses';
    $row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", $id ) );
    if ( ! $row ) { wp_send_json_error( array( 'message' => 'Status not found.' ) ); }

    $in_use = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = 'internal_status' AND pm.meta_value = %s AND p.post_type = 'nri_request' AND p.post_status = 'publish'",
        $row->slug
    ) );
    if ( $row->slug === 'inquiry' ) { $in_use += nri_count_requests_defaulting_to_inquiry(); }

    if ( $in_use > 0 ) {
        wp_send_json_error( array(
            'message' => sprintf( '%d request(s) currently use this status — deactivate it instead, or reassign those requests first.', $in_use ),
            'in_use'  => $in_use,
        ) );
    }
    $wpdb->delete( $table, array( 'id' => $id ) );
    nri_clear_internal_status_cache();
    wp_send_json_success();
}

// -----------------------------------------------------------
// STUDENT REQUIREMENT DESCRIPTION
// -----------------------------------------------------------

// Read-only fetch (used by the request-detail page for either a staff
// member or the request's own client — both are allowed to see it,
// only staff can edit/regenerate it).
add_action( 'wp_ajax_nri_get_requirement_description', 'nri_ajax_get_requirement_description' );
function nri_ajax_get_requirement_description() {
    nri_check_nonce();
    $rid = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    if ( ! $rid || ! nri_is_own_request( $rid ) ) {
        wp_send_json_error( array( 'message' => 'Access denied.' ) );
    }
    wp_send_json_success( nri_get_requirement_description( $rid ) );
}

// Regenerates the description from the request's CURRENT fields. If the
// stored description was manually edited, this refuses unless the
// caller explicitly confirms with force=1 — the client-side confirm()
// dialog is the primary gate, this is the server-side backstop, so a
// manually-edited description is never silently overwritten.
add_action( 'wp_ajax_nri_regenerate_description', 'nri_ajax_regenerate_description' );
function nri_ajax_regenerate_description() {
    nri_check_nonce(); nri_require_staff();
    $rid   = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    $force = ! empty( $_POST['force'] );
    if ( ! $rid ) { wp_send_json_error( array( 'message' => 'Invalid request.' ) ); }
    $is_manual = get_post_meta( $rid, 'requirement_description_manual', true ) === '1';
    if ( $is_manual && ! $force ) {
        wp_send_json_error( array( 'message' => 'This description was manually edited. Confirm to overwrite it.', 'needs_confirm' => true ) );
    }
    $meta = nri_get_meta( $rid );
    $text = nri_generate_requirement_description( $rid, $meta );
    nri_save_requirement_description( $rid, $text, false );
    nri_add_history( $rid, 'Requirement description regenerated' );
    wp_send_json_success( array( 'text' => $text, 'is_manual' => false, 'stale' => false ) );
}

// Saves an admin's own wording, marking it manually-edited so a later
// regenerate always asks for confirmation before replacing it.
add_action( 'wp_ajax_nri_save_description', 'nri_ajax_save_description' );
function nri_ajax_save_description() {
    nri_check_nonce(); nri_require_staff();
    $rid  = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    $text = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['text'] ) ) : '';
    if ( ! $rid )      { wp_send_json_error( array( 'message' => 'Invalid request.' ) ); }
    if ( $text === '' ) { wp_send_json_error( array( 'message' => 'Description cannot be empty.' ) ); }
    nri_save_requirement_description( $rid, $text, true );
    nri_add_history( $rid, 'Requirement description edited manually' );
    wp_send_json_success( array( 'text' => $text, 'is_manual' => true, 'stale' => false ) );
}

add_action('wp_ajax_nri_update_status', 'nri_ajax_update_status');
function nri_ajax_update_status() {
    nri_check_nonce(); nri_require_staff();
    $rid    = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $status = sanitize_text_field(isset($_POST['status']) ? $_POST['status'] : '');
    $note   = sanitize_textarea_field(isset($_POST['note']) ? $_POST['note'] : '');
    $valid  = array('submitted','under_review','ready_for_processing','approved','processing','dispatched','completed','rejected','service_not_available');
    if (!in_array($status, $valid)) wp_send_json_error(array('message' => 'Invalid status.'));
    update_post_meta($rid, 'status', $status);
    nri_add_history($rid, 'Status updated: ' . nri_status_label($status), $note);
    wp_send_json_success(array('status' => $status, 'label' => nri_status_label($status)));
}

add_action('wp_ajax_nri_set_timeline', 'nri_ajax_set_timeline');
function nri_ajax_set_timeline() {
    nri_check_nonce(); nri_require_staff();
    $rid  = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $mode = sanitize_text_field(isset($_POST['mode']) ? $_POST['mode'] : 'days');
    $note = sanitize_text_field(isset($_POST['note']) ? $_POST['note'] : '');
    if ($mode === 'days') {
        $days = intval(isset($_POST['days']) ? $_POST['days'] : 0);
        if ($days <= 0) wp_send_json_error(array('message' => 'Invalid number of days.'));
        // Use smart delivery calculator (excludes weekends + holidays)
        if (function_exists('nri_calculate_delivery_date')) {
            $result = nri_calculate_delivery_date($days);
            if (is_wp_error($result)) wp_send_json_error(array('message' => $result->get_error_message()));
            $date   = $result['delivery_date'];
        } else {
            $date = date('Y-m-d', strtotime('+' . $days . ' days'));
        }
    } else {
        $date = sanitize_text_field(isset($_POST['date']) ? $_POST['date'] : '');
    }
    if (!$date) wp_send_json_error(array('message' => 'Invalid date.'));
    update_post_meta($rid, 'estimated_delivery', $date);
    update_post_meta($rid, 'timeline_working_days', isset($_POST['days']) ? intval($_POST['days']) : 0);
    nri_add_history($rid, 'Delivery date set: ' . date('d M Y', strtotime($date)) . ' (' . (isset($_POST['days']) ? intval($_POST['days']) . ' working days' : 'fixed date') . ')', $note);
    wp_send_json_success(array('formatted' => date('d M Y', strtotime($date)), 'working_days' => isset($_POST['days']) ? intval($_POST['days']) : 0));
}

add_action('wp_ajax_nri_set_quote', 'nri_ajax_set_quote');
function nri_ajax_set_quote() {
    nri_check_nonce(); nri_require_staff();
    $rid    = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $amount = floatval(isset($_POST['amount']) ? $_POST['amount'] : 0);
    update_post_meta($rid, 'quote_amount', $amount);
    nri_add_history($rid, 'Quote set: INR ' . number_format($amount, 2));
    wp_send_json_success();
}

add_action('wp_ajax_nri_assign_staff', 'nri_ajax_assign_staff');
function nri_ajax_assign_staff() {
    nri_check_nonce(); nri_require_staff();
    $rid  = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $type = sanitize_text_field(isset($_POST['type']) ? $_POST['type'] : 'manager');
    $uid  = intval(isset($_POST['user_id']) ? $_POST['user_id'] : 0);
    $key  = ($type === 'vendor') ? 'assigned_vendor' : 'assigned_manager';
    update_post_meta($rid, $key, $uid);
    $u = get_userdata($uid);
    nri_add_history($rid, ucfirst($type) . ' assigned: ' . ($u ? $u->display_name : ''));
    wp_send_json_success();
}

add_action('wp_ajax_nri_save_note', 'nri_ajax_save_note');
function nri_ajax_save_note() {
    nri_check_nonce(); nri_require_staff();
    $rid  = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $note = sanitize_textarea_field(isset($_POST['note']) ? $_POST['note'] : '');
    update_post_meta($rid, 'internal_notes', $note);
    wp_send_json_success();
}

add_action('wp_ajax_nri_set_secondary_status', 'nri_ajax_set_secondary_status');
function nri_ajax_set_secondary_status() {
    nri_check_nonce(); nri_require_staff();
    $rid = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $val = sanitize_text_field(isset($_POST['value']) ? $_POST['value'] : '');
    update_post_meta($rid, 'secondary_status', $val);
    wp_send_json_success();
}

// -----------------------------------------------------------
// FIELD MANAGEMENT
// -----------------------------------------------------------
add_action('wp_ajax_nri_save_field', 'nri_ajax_save_field');
function nri_ajax_save_field() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $tbl  = $wpdb->prefix . 'nri_fields';
    $id   = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    // Conditions: JSON string of conditional logic rules
    $conditions_raw = isset($_POST['conditions']) ? wp_unslash($_POST['conditions']) : '';
    $conditions_json = null;
    if ($conditions_raw) {
        $decoded = json_decode($conditions_raw, true);
        $conditions_json = (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) ? wp_json_encode($decoded) : null;
    }
    $data = array(
        'field_label'   => sanitize_text_field(isset($_POST['label'])       ? $_POST['label']       : ''),
        'field_type'    => sanitize_text_field(isset($_POST['type'])        ? $_POST['type']        : 'text'),
        'field_options' => sanitize_text_field(isset($_POST['options'])     ? $_POST['options']     : ''),
        'placeholder'   => sanitize_text_field(isset($_POST['placeholder']) ? $_POST['placeholder'] : ''),
        'description'   => sanitize_textarea_field(isset($_POST['description']) ? $_POST['description'] : ''),
        'is_required'   => intval(isset($_POST['required']) ? $_POST['required'] : 0),
        'step_number'   => intval(isset($_POST['step'])     ? $_POST['step']     : 1),
        'is_active'     => intval(isset($_POST['active'])   ? $_POST['active']   : 1),
        'conditions'    => $conditions_json,
    );
    if (!$data['field_label']) wp_send_json_error(array('message' => 'Label required.'));
    if ($id) {
        $wpdb->update($tbl, $data, array('id' => $id));
    } else {
        $key = sanitize_key(isset($_POST['key']) ? $_POST['key'] : '');
        if (!$key) wp_send_json_error(array('message' => 'Key required.'));
        $max              = (int) $wpdb->get_var("SELECT MAX(sort_order) FROM $tbl") + 1;
        $data['field_key']= $key;
        $data['sort_order']= $max;
        $result = $wpdb->insert($tbl, $data);
        if (!$result) wp_send_json_error(array('message' => 'Could not save field. Key may already exist.'));
        $id = $wpdb->insert_id;
    }
    wp_send_json_success(array('id' => $id));
}

add_action('wp_ajax_nri_delete_field', 'nri_ajax_delete_field');
function nri_ajax_delete_field() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $wpdb->delete($wpdb->prefix . 'nri_fields', array('id' => intval(isset($_POST['id']) ? $_POST['id'] : 0)));
    wp_send_json_success();
}

// -----------------------------------------------------------
// DROPDOWN OPTIONS CRUD
// -----------------------------------------------------------
add_action('wp_ajax_nri_get_options_paged', 'nri_ajax_get_options_paged');
function nri_ajax_get_options_paged() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $key    = sanitize_key(isset($_POST['field_key']) ? $_POST['field_key'] : '');
    $search = sanitize_text_field(isset($_POST['search']) ? $_POST['search'] : '');
    $page   = max(1, intval(isset($_POST['page']) ? $_POST['page'] : 1));
    $per    = 50;
    $offset = ($page - 1) * $per;
    $tbl    = $wpdb->prefix . 'nri_dropdown_options';
    if ($search) {
        $total = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $tbl WHERE field_key=%s AND option_value LIKE %s", $key, '%' . $wpdb->esc_like($search) . '%'
        ));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id,option_value FROM $tbl WHERE field_key=%s AND option_value LIKE %s ORDER BY sort_order ASC,id ASC LIMIT %d OFFSET %d",
            $key, '%' . $wpdb->esc_like($search) . '%', $per, $offset
        ));
    } else {
        $total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tbl WHERE field_key=%s", $key));
        $rows  = $wpdb->get_results($wpdb->prepare(
            "SELECT id,option_value FROM $tbl WHERE field_key=%s ORDER BY sort_order ASC,id ASC LIMIT %d OFFSET %d",
            $key, $per, $offset
        ));
    }
    wp_send_json_success(array(
        'rows'  => $rows,
        'total' => $total,
        'pages' => (int) ceil($total / $per),
        'page'  => $page,
    ));
}

add_action('wp_ajax_nri_save_option', 'nri_ajax_save_option');
function nri_ajax_save_option() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $tbl = $wpdb->prefix . 'nri_dropdown_options';
    $id  = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    $val = sanitize_text_field(isset($_POST['value']) ? $_POST['value'] : '');
    if (!$val) wp_send_json_error(array('message' => 'Value required.'));
    if ($id) {
        $wpdb->update($tbl, array('option_value' => $val), array('id' => $id));
    } else {
        $key = sanitize_key(isset($_POST['field_key']) ? $_POST['field_key'] : '');
        $max = (int) $wpdb->get_var($wpdb->prepare("SELECT MAX(sort_order) FROM $tbl WHERE field_key=%s", $key)) + 1;
        $wpdb->insert($tbl, array('field_key' => $key, 'option_value' => $val, 'sort_order' => $max));
        $id = $wpdb->insert_id;
    }
    wp_send_json_success(array('id' => $id, 'value' => $val));
}

add_action('wp_ajax_nri_delete_option', 'nri_ajax_delete_option');
function nri_ajax_delete_option() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $wpdb->delete($wpdb->prefix . 'nri_dropdown_options', array('id' => intval(isset($_POST['id']) ? $_POST['id'] : 0)));
    wp_send_json_success();
}

add_action('wp_ajax_nri_bulk_delete_options', 'nri_ajax_bulk_delete_options');
function nri_ajax_bulk_delete_options() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $raw_ids = isset($_POST['ids']) ? (array) $_POST['ids'] : array();
    $ids     = array();
    foreach ($raw_ids as $i) {
        $i = intval($i);
        if ($i > 0) $ids[] = $i;
    }
    if (empty($ids)) wp_send_json_error(array('message' => 'No IDs provided.'));
    // Build placeholders safely without spread operator
    $placeholders = implode(',', array_fill(0, count($ids), '%d'));
    $sql  = "DELETE FROM {$wpdb->prefix}nri_dropdown_options WHERE id IN ($placeholders)";
    $args = array_merge(array($sql), $ids);
    $wpdb->query(call_user_func_array(array($wpdb, 'prepare'), $args));
    wp_send_json_success(array('deleted' => count($ids)));
}

add_action('wp_ajax_nri_bulk_import', 'nri_ajax_bulk_import');
function nri_ajax_bulk_import() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $key    = sanitize_key(isset($_POST['field_key']) ? $_POST['field_key'] : '');
    $mode   = sanitize_text_field(isset($_POST['mode'])   ? $_POST['mode']   : 'append');
    $format = sanitize_text_field(isset($_POST['format']) ? $_POST['format'] : 'lines');
    $raw    = isset($_POST['raw_data']) ? wp_unslash($_POST['raw_data']) : '';
    $values = array();

    if (!empty($_FILES['csv_file']['tmp_name'])) {
        $handle = fopen($_FILES['csv_file']['tmp_name'], 'r');
        if ($handle) {
            while (($row = fgetcsv($handle)) !== false) {
                $v = isset($row[0]) ? trim($row[0]) : '';
                if ($v) $values[] = $v;
            }
            fclose($handle);
        }
    } elseif ($raw) {
        if ($format === 'json') {
            $arr = json_decode($raw, true);
            if (is_array($arr)) {
                foreach ($arr as $v) {
                    $v = trim(strval($v));
                    if ($v) $values[] = $v;
                }
            }
        } elseif ($format === 'comma') {
            foreach (explode(',', $raw) as $v) {
                $v = trim($v);
                if ($v) $values[] = $v;
            }
        } else {
            foreach (preg_split('/\r\n|\r|\n/', $raw) as $v) {
                $v = trim($v);
                if ($v) $values[] = $v;
            }
        }
    }

    $values = array_unique($values);
    if (empty($values)) wp_send_json_error(array('message' => 'No values found.'));

    $tbl = $wpdb->prefix . 'nri_dropdown_options';
    if ($mode === 'replace') $wpdb->delete($tbl, array('field_key' => $key));
    $max = (int) $wpdb->get_var($wpdb->prepare("SELECT MAX(sort_order) FROM $tbl WHERE field_key=%s", $key));
    foreach ($values as $v) {
        $wpdb->insert($tbl, array('field_key' => $key, 'option_value' => sanitize_text_field($v), 'sort_order' => ++$max));
    }
    wp_send_json_success(array('imported' => count($values), 'mode' => $mode));
}

// -----------------------------------------------------------
// SETTINGS
// -----------------------------------------------------------
add_action('wp_ajax_nri_save_settings', 'nri_ajax_save_settings');
function nri_ajax_save_settings() {
    nri_check_nonce(); nri_require_staff();
    $keys = array(
        'nri_bank_name','nri_bank_account_name','nri_bank_account_number',
        'nri_bank_ifsc','nri_bank_swift','nri_bank_instructions',
        'nri_platform_name','nri_email_from','nri_email_name','nri_manager_name','nri_manager_phone','nri_manager_email',
    );
    foreach ($keys as $k) {
        if (isset($_POST[$k])) update_option($k, sanitize_text_field($_POST[$k]));
    }
    wp_send_json_success();
}

/* ============================================================
   FIELD REORDERING - Drag-and-Drop (SortableJS)
   ============================================================ */
add_action( 'wp_ajax_nri_move_field', 'nri_ajax_move_field' ); // kept for back-compat
function nri_ajax_move_field() {
    nri_check_nonce(); nri_require_staff();
    wp_send_json_success(); // no-op; replaced by nri_reorder_fields
}

add_action( 'wp_ajax_nri_reorder_fields', 'nri_ajax_reorder_fields' );
function nri_ajax_reorder_fields() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $ids = isset( $_POST['ids'] ) ? array_map( 'intval', (array) $_POST['ids'] ) : array();
    if ( empty( $ids ) ) { wp_send_json_error( array( 'message' => 'No IDs provided.' ) ); }
    $tbl = $wpdb->prefix . 'nri_fields';
    foreach ( $ids as $order => $id ) {
        $wpdb->update( $tbl, array( 'sort_order' => $order + 1 ), array( 'id' => $id ) );
    }
    wp_send_json_success( array( 'message' => 'Order saved.' ) );
}

/* ============================================================
   DELETE REQUEST (Admin only)
   ============================================================ */
add_action( 'wp_ajax_nri_delete_request', 'nri_ajax_delete_request' );
function nri_ajax_delete_request() {
    nri_check_nonce(); nri_require_staff();
    $rid  = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    $hard = ! empty( $_POST['hard_delete'] );
    if ( ! $rid || ! nri_delete_request_by_id( $rid, $hard ) ) {
        wp_send_json_error( array( 'message' => 'Could not delete this request.' ) );
    }
    wp_send_json_success();
}

/**
 * Shared delete logic for a single request (used by both the single-delete
 * and bulk-delete AJAX handlers so behavior — including cleanup of the
 * request's own tickets/messages/uploaded documents — never drifts between
 * the two entry points).
 */
function nri_delete_request_by_id( $rid, $hard = true ) {
    global $wpdb;
    $post = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nri_request' ) { return false; }

    if ( $hard ) {
        // Remove uploaded documents (media attachments) before the post
        // itself, so nothing is left behind in the media library.
        $docs = nri_get_documents( $rid );
        foreach ( $docs as $d ) {
            $att_id = isset( $d['file'] ) ? intval( $d['file'] ) : 0;
            if ( $att_id ) { wp_delete_attachment( $att_id, true ); }
        }
        wp_delete_post( $rid, true );
        $wpdb->delete( $wpdb->prefix . 'nri_tickets',  array( 'request_id' => $rid ) );
        $wpdb->delete( $wpdb->prefix . 'nri_messages', array( 'request_id' => $rid ) );
        nri_flush_request_search_cache();
    } else {
        wp_trash_post( $rid );
        nri_flush_request_search_cache();
    }
    return true;
}

/**
 * Bulk delete — shared by the Requests tab and the Form Submissions tab,
 * since "submissions" are the same nri_request posts viewed differently.
 * Deletes what it can and reports back exactly which ids (if any) failed,
 * rather than silently succeeding or aborting the whole batch on one bad id.
 */
add_action( 'wp_ajax_nri_bulk_delete_requests', 'nri_ajax_bulk_delete_requests' );
function nri_ajax_bulk_delete_requests() {
    nri_check_nonce(); nri_require_staff();
    $ids = isset( $_POST['request_ids'] ) ? (array) $_POST['request_ids'] : array();
    $ids = array_filter( array_map( 'intval', $ids ) );
    if ( empty( $ids ) ) { wp_send_json_error( array( 'message' => 'No requests selected.' ) ); }

    $deleted = array();
    $failed  = array();
    foreach ( $ids as $rid ) {
        if ( nri_delete_request_by_id( $rid, true ) ) { $deleted[] = $rid; }
        else { $failed[] = $rid; }
    }
    wp_send_json_success( array(
        'deleted_count' => count( $deleted ),
        'failed_ids'    => $failed,
        'message'       => count( $deleted ) . ' request' . ( count( $deleted ) === 1 ? '' : 's' ) . ' deleted.' . ( $failed ? ' ' . count( $failed ) . ' could not be deleted.' : '' ),
    ) );
}

/**
 * Bulk delete support tickets. Single-ticket delete (nri_ajax_delete_ticket,
 * above) already exists; this reuses the exact same underlying $wpdb->delete
 * call, looped, so behavior stays identical between single and bulk.
 */
add_action( 'wp_ajax_nri_bulk_delete_tickets', 'nri_ajax_bulk_delete_tickets' );
function nri_ajax_bulk_delete_tickets() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $ids = isset( $_POST['ticket_ids'] ) ? (array) $_POST['ticket_ids'] : array();
    $ids = array_filter( array_map( 'intval', $ids ) );
    if ( empty( $ids ) ) { wp_send_json_error( array( 'message' => 'No tickets selected.' ) ); }

    $deleted = 0;
    foreach ( $ids as $tid ) {
        $deleted += (int) $wpdb->delete( $wpdb->prefix . 'nri_tickets', array( 'id' => $tid ) );
    }
    wp_send_json_success( array(
        'deleted_count' => $deleted,
        'message'       => $deleted . ' ticket' . ( $deleted === 1 ? '' : 's' ) . ' deleted.',
    ) );
}

/**
 * Delete one or more uploaded documents ("Form Files") from a request:
 * removes them from the media library (so nothing is orphaned on disk)
 * AND from the request's `documents` postmeta so they stop appearing in
 * both the admin request-detail view and the Form Submissions modal.
 */
add_action( 'wp_ajax_nri_delete_documents', 'nri_ajax_delete_documents' );
function nri_ajax_delete_documents() {
    nri_check_nonce(); nri_require_staff();
    $rid = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    $att_ids = isset( $_POST['att_ids'] ) ? (array) $_POST['att_ids'] : array();
    $att_ids = array_filter( array_map( 'intval', $att_ids ) );
    if ( ! $rid || empty( $att_ids ) ) { wp_send_json_error( array( 'message' => 'Nothing selected to delete.' ) ); }

    $post = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nri_request' ) { wp_send_json_error( array( 'message' => 'Request not found.' ) ); }

    $docs = nri_get_documents( $rid );
    $kept = array();
    $removed = 0;
    foreach ( $docs as $d ) {
        $att_id = isset( $d['file'] ) ? intval( $d['file'] ) : 0;
        if ( $att_id && in_array( $att_id, $att_ids, true ) ) {
            wp_delete_attachment( $att_id, true );
            $removed++;
        } else {
            $kept[] = $d;
        }
    }
    update_post_meta( $rid, 'documents', $kept );
    if ( $removed ) { nri_add_history( $rid, $removed . ' document(s) deleted by staff' ); }

    wp_send_json_success( array(
        'removed_count'   => $removed,
        'remaining_count' => count( $kept ),
        'message'         => $removed . ' file' . ( $removed === 1 ? '' : 's' ) . ' deleted.',
    ) );
}

/* ============================================================
   ADMIN DASHBOARD — SPA-STYLE TAB / DETAIL LOADING
   Lets the admin dashboard switch tabs and open a request's detail
   view without a full WordPress page reload: these handlers return
   exactly the same markup the equivalent full-page render would
   produce (by calling the very same PHP render functions), so there
   is only one source of truth for each screen's HTML.
   ============================================================ */
add_action( 'wp_ajax_nri_admin_load_tab', 'nri_ajax_admin_load_tab' );
function nri_ajax_admin_load_tab() {
    nri_check_nonce(); nri_require_staff();
    $valid_tabs = array( 'requests', 'submissions', 'support', 'fields', 'dropdowns', 'bulk', 'types', 'settings' );
    $tab = sanitize_text_field( isset( $_POST['tab'] ) ? $_POST['tab'] : 'requests' );
    if ( ! in_array( $tab, $valid_tabs, true ) ) { $tab = 'requests'; }

    switch ( $tab ) {
        case 'requests':    $html = nri_admin_tab_requests();    break;
        case 'submissions': $html = nri_admin_tab_submissions(); break;
        case 'support':     $html = nri_admin_tab_support();     break;
        case 'fields':      $html = nri_admin_tab_fields();      break;
        case 'dropdowns':   $html = nri_admin_tab_dropdowns();   break;
        case 'bulk':        $html = nri_admin_tab_bulk();        break;
        case 'types':       $html = nri_admin_tab_types();       break;
        case 'settings':    $html = nri_admin_tab_settings();    break;
        default:            $html = nri_admin_tab_requests();
    }
    // The Requests tab relies on nri_admin_js() (loaded once on first
    // page load) for its list-loading logic, so it doesn't need its
    // script re-sent; other tabs carry their own inline <script> as
    // part of their render function already.
    wp_send_json_success( array( 'tab' => $tab, 'html' => $html ) );
}

add_action( 'wp_ajax_nri_admin_load_request_detail', 'nri_ajax_admin_load_request_detail' );
function nri_ajax_admin_load_request_detail() {
    nri_check_nonce(); nri_require_staff();
    $rid = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    if ( ! $rid ) { wp_send_json_error( array( 'message' => 'Invalid request.' ) ); }
    $post = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nri_request' ) { wp_send_json_error( array( 'message' => 'Request not found.' ) ); }
    wp_send_json_success( array( 'html' => nri_render_request_view( $rid, true ) ) );
}

/* ============================================================
   CLIENT DASHBOARD — SPA-STYLE TAB / DETAIL LOADING
   Same idea as the admin endpoints above (see the block comment there),
   applied to the client dashboard's own two tabs (Dashboard/Profile) and
   its request-detail view — clients get the same no-full-reload, no
   forced-scroll-jump navigation admins do. Only login is required (not
   staff); nri_render_request_view()'s own nri_is_own_request() check is
   still the real access-control gate for the detail view, same as it
   already was for the standalone /request/{id} page.
   ============================================================ */
add_action( 'wp_ajax_nri_client_load_tab', 'nri_ajax_client_load_tab' );
function nri_ajax_client_load_tab() {
    nri_check_nonce();
    if ( ! is_user_logged_in() ) { wp_send_json_error( array( 'message' => 'Please log in.' ), 401 ); }
    $valid_tabs = array( 'dashboard', 'profile' );
    $tab = sanitize_text_field( isset( $_POST['tab'] ) ? $_POST['tab'] : 'dashboard' );
    if ( ! in_array( $tab, $valid_tabs, true ) ) { $tab = 'dashboard'; }
    wp_send_json_success( array( 'tab' => $tab, 'html' => nri_render_client_tab( $tab ) ) );
}

add_action( 'wp_ajax_nri_client_load_request_detail', 'nri_ajax_client_load_request_detail' );
function nri_ajax_client_load_request_detail() {
    nri_check_nonce();
    if ( ! is_user_logged_in() ) { wp_send_json_error( array( 'message' => 'Please log in.' ), 401 ); }
    $rid = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    if ( ! $rid ) { wp_send_json_error( array( 'message' => 'Invalid request.' ) ); }
    $post = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nri_request' ) { wp_send_json_error( array( 'message' => 'Request not found.' ) ); }
    // nri_render_request_view() itself returns an "Access denied." fragment
    // (not a JSON error) for a request that isn't this user's own — same
    // behavior the standalone page always had, just reused here.
    wp_send_json_success( array( 'html' => nri_render_request_view( $rid, true ) ) );
}

/* ============================================================
   CLIENT PROFILE UPDATE
   ============================================================ */
add_action( 'wp_ajax_nri_update_profile', 'nri_ajax_update_profile' );
function nri_ajax_update_profile() {
    nri_check_nonce();
    if ( ! is_user_logged_in() ) { wp_send_json_error( array( 'message' => 'Not logged in.' ), 401 ); }

    $uid          = get_current_user_id();
    $display_name = sanitize_text_field( isset( $_POST['display_name'] ) ? $_POST['display_name'] : '' );
    $phone        = sanitize_text_field( isset( $_POST['phone'] )        ? $_POST['phone']        : '' );
    $address      = sanitize_text_field( isset( $_POST['address'] )      ? $_POST['address']      : '' );
    $new_pass     = isset( $_POST['new_password'] )    ? $_POST['new_password']    : '';
    $confirm_pass = isset( $_POST['confirm_password'] ) ? $_POST['confirm_password'] : '';

    $data = array( 'ID' => $uid );
    if ( $display_name ) { $data['display_name'] = $display_name; }

    if ( $new_pass ) {
        if ( $new_pass !== $confirm_pass ) { wp_send_json_error( array( 'message' => 'Passwords do not match.' ) ); }
        if ( strlen( $new_pass ) < 8 )    { wp_send_json_error( array( 'message' => 'Password must be at least 8 characters.' ) ); }
        $data['user_pass'] = $new_pass;
    }

    $result = wp_update_user( $data );
    if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ) ); }

    if ( $phone )   { update_user_meta( $uid, 'nri_phone',   $phone ); }
    if ( $address ) { update_user_meta( $uid, 'nri_address', $address ); }

    wp_send_json_success( array( 'message' => 'Profile updated successfully.' ) );
}

/* ============================================================
   SUPPORT TICKET SUBMIT (separate from service requests)
   ============================================================ */
add_action( 'wp_ajax_nri_submit_support',        'nri_ajax_submit_support' );
add_action( 'wp_ajax_nopriv_nri_submit_support', 'nri_ajax_submit_support' );
function nri_ajax_submit_support() {
    nri_check_nonce();
    global $wpdb;
    $cat   = sanitize_text_field( isset( $_POST['category'] )    ? $_POST['category']    : '' );
    $desc  = sanitize_textarea_field( isset( $_POST['description'] ) ? $_POST['description'] : '' );
    $email = sanitize_email( isset( $_POST['email'] )            ? $_POST['email']        : '' );
    $uid   = get_current_user_id();

    if ( ! $cat )  { wp_send_json_error( array( 'message' => 'Please select a category.' ) ); }
    if ( ! $desc ) { wp_send_json_error( array( 'message' => 'Please describe your issue.' ) ); }

    if ( ! $uid && $email ) {
        $u = get_user_by( 'email', $email );
        if ( $u ) { $uid = $u->ID; }
    }

    $wpdb->insert( $wpdb->prefix . 'nri_tickets', array(
        'request_id' => 0,
        'user_id'    => $uid,
        'type_id'    => 0,
        'category'   => $cat,
        'status'     => 'open',
        'notes'      => $desc,
    ) );
    $tid = $wpdb->insert_id;

    // Handle file attachment
    if ( ! empty( $_FILES['support_file']['tmp_name'] ) && $uid ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        media_handle_upload( 'support_file', 0 );
    }

    wp_send_json_success( array( 'ticket_id' => $tid, 'message' => 'Support request submitted successfully.' ) );
}

/* ============================================================
   GET SUPPORT TICKETS (Admin)
   ============================================================ */
add_action( 'wp_ajax_nri_get_support_tickets', 'nri_ajax_get_support_tickets' );
function nri_ajax_get_support_tickets() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $status = sanitize_text_field( isset( $_POST['status'] ) ? $_POST['status'] : '' );
    $where  = $status ? $wpdb->prepare( 'WHERE status=%s AND request_id=0', $status ) : 'WHERE request_id=0';
    $rows   = $wpdb->get_results( "SELECT t.*, u.display_name, u.user_email FROM {$wpdb->prefix}nri_tickets t LEFT JOIN {$wpdb->prefix}users u ON t.user_id=u.ID $where ORDER BY t.created_at DESC" );
    wp_send_json_success( $rows );
}

/* ============================================================
   ASSIGN VENDOR / MANAGER - Save button + WA trigger
   ============================================================ */

// Override the existing nri_assign_staff to also fire WA hooks
remove_action('wp_ajax_nri_assign_staff', 'nri_ajax_assign_staff');
add_action('wp_ajax_nri_assign_staff', 'nri_ajax_assign_staff_v2');
function nri_ajax_assign_staff_v2() {
    nri_check_nonce(); nri_require_staff();
    $rid  = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $type = sanitize_text_field(isset($_POST['type']) ? $_POST['type'] : 'manager');
    $uid  = intval(isset($_POST['user_id']) ? $_POST['user_id'] : 0);
    $key  = ($type === 'vendor') ? 'assigned_vendor' : 'assigned_manager';
    $old  = get_post_meta($rid, $key, true);
    update_post_meta($rid, $key, $uid);
    $u    = get_userdata($uid);
    $name = $u ? $u->display_name : 'Unknown';
    nri_add_history($rid, ucfirst($type) . ' assigned: ' . $name);

    // Fire WhatsApp hook when vendor is assigned/changed
    if ($type === 'vendor' && $uid && $uid != $old) {
        do_action('nri_after_vendor_assigned', $rid, $uid);
    }

    wp_send_json_success(['message' => ucfirst($type) . ' assigned: ' . $name, 'name' => $name]);
}

// Trigger WA on status change
remove_action('wp_ajax_nri_update_status', 'nri_ajax_update_status');
add_action('wp_ajax_nri_update_status', 'nri_ajax_update_status_v2');
function nri_ajax_update_status_v2() {
    nri_check_nonce(); nri_require_staff();
    $rid    = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $status = sanitize_text_field(isset($_POST['status']) ? $_POST['status'] : '');
    $note   = sanitize_textarea_field(isset($_POST['note']) ? $_POST['note'] : '');
    $valid  = array('submitted','under_review','ready_for_processing','approved','processing','dispatched','completed','rejected','service_not_available');
    if (!in_array($status, $valid)) wp_send_json_error(array('message' => 'Invalid status.'));
    update_post_meta($rid, 'status', $status);
    nri_add_history($rid, 'Status updated: ' . nri_status_label($status), $note);
    do_action('nri_after_status_changed', $rid, $status);
    // Automated email: notify client of status change
    if (function_exists('nri_notify_status_change')) {
        nri_notify_status_change($rid, $status);
    }
    wp_send_json_success(array('status' => $status, 'label' => nri_status_label($status)));
}

// Trigger WA on payment set
remove_action('wp_ajax_nri_set_quote', 'nri_ajax_set_quote');
add_action('wp_ajax_nri_set_quote', 'nri_ajax_set_quote_v2');
function nri_ajax_set_quote_v2() {
    nri_check_nonce(); nri_require_staff();
    $rid    = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $amount = floatval(isset($_POST['amount']) ? $_POST['amount'] : 0);
    $notify = !empty($_POST['notify_vendor']);
    update_post_meta($rid, 'quote_amount', $amount);
    nri_add_history($rid, 'Quote set: INR ' . number_format($amount, 2));
    if ($notify) do_action('nri_after_payment_set', $rid);
    // Auto-send quotation email with T&C if checkbox ticked
    $send_quote_email = !empty($_POST['send_quote_email']);
    $include_terms    = !empty($_POST['include_terms']);
    if ($send_quote_email && function_exists('nri_notify_quotation')) {
        nri_notify_quotation($rid, $include_terms);
        nri_add_history($rid, 'Quotation email sent to client');
    }
    wp_send_json_success();
}

// v6.2.1: Set Shipping Charges
add_action('wp_ajax_nri_set_shipping', 'nri_ajax_set_shipping');
function nri_ajax_set_shipping() {
    nri_check_nonce(); nri_require_staff();
    $rid = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $amount = floatval(isset($_POST['amount']) ? $_POST['amount'] : 0);
    $type = sanitize_text_field(isset($_POST['type']) ? $_POST['type'] : 'domestic');
    
    if (!$rid) {
        wp_send_json_error('Invalid request ID');
    }
    
    update_post_meta($rid, 'shipping_charges', $amount);
    update_post_meta($rid, 'shipping_type', $type);
    nri_add_history($rid, 'Shipping charges set: ₹' . number_format($amount, 2) . ' (' . ucfirst($type) . ')');
    
    wp_send_json_success(array(
        'amount' => $amount,
        'type' => $type,
        'message' => 'Shipping charges updated'
    ));
}

/* ============================================================
   VENDOR PROFILE LISTING FOR ADMIN (dropdown in request view)
   ============================================================ */

add_action('wp_ajax_nri_get_vendors_list', 'nri_ajax_get_vendors_list');
function nri_ajax_get_vendors_list() {
    nri_check_nonce(); nri_require_staff();
    global $wpdb;
    $vendors = $wpdb->get_results("SELECT id, name, phone, whatsapp, work_types, status FROM {$wpdb->prefix}nri_vendors WHERE status='active' ORDER BY name ASC");
    $out = [];
    foreach ($vendors as $v) {
        $out[] = [
            'id'         => $v->id,
            'name'       => $v->name,
            'phone'      => $v->phone,
            'whatsapp'   => $v->whatsapp,
            'work_types' => $v->work_types,
        ];
    }
    wp_send_json_success($out);
}

// -----------------------------------------------------------
// GET FIELD OPTIONS  used by conditional logic value selector
// -----------------------------------------------------------
add_action('wp_ajax_nri_get_field_options',        'nri_ajax_get_field_options');
add_action('wp_ajax_nopriv_nri_get_field_options', 'nri_ajax_get_field_options');
function nri_ajax_get_field_options() {
    nri_check_nonce();
    $key   = sanitize_key(isset($_POST['field_key']) ? $_POST['field_key'] : '');
    if (!$key) { wp_send_json_error(array('message' => 'No field key.')); return; }
    global $wpdb;
    $field = $wpdb->get_row($wpdb->prepare(
        "SELECT field_type, field_options FROM {$wpdb->prefix}nri_fields WHERE field_key=%s LIMIT 1", $key
    ));
    $options = array();
    if ($field) {
        if (in_array($field->field_type, array('dropdown','searchable','radio'), true)) {
            // First get options from dropdown_options table
            $db_opts = nri_get_dropdown_options($key);
            if ($db_opts) {
                $options = $db_opts;
            } elseif ($field->field_options) {
                // Fallback: comma-separated field_options column
                $options = array_values(array_filter(array_map('trim', explode(',', $field->field_options))));
            }
        }
    }
    wp_send_json_success(array(
        'options'    => $options,
        'field_type' => $field ? $field->field_type : '',
        'has_options'=> !empty($options),
    ));
}

// ── COMMUNICATION PANEL: Send Email ────────────────────────────────────────
add_action( 'wp_ajax_nri_send_comm_email', 'nri_ajax_send_comm_email' );
function nri_ajax_send_comm_email() {
    nri_check_nonce();
    nri_require_staff();

    $rid         = intval( $_POST['request_id'] ?? 0 );
    $subject     = sanitize_text_field( $_POST['subject'] ?? '' );
    $body        = sanitize_textarea_field( $_POST['body'] ?? '' );
    $log_message = ! empty( $_POST['log_message'] );

    if ( ! $rid || ! $subject || ! $body ) {
        wp_send_json_error( array( 'message' => 'Subject and message are required.' ) );
    }
    if ( ! nri_is_own_request( $rid ) ) {
        wp_send_json_error( array( 'message' => 'Access denied.' ), 403 );
    }

    $post   = get_post( $rid );
    $client = $post ? get_userdata( $post->post_author ) : null;
    if ( ! $client || ! $client->user_email ) {
        wp_send_json_error( array( 'message' => 'No recipient email found for this request.' ) );
    }

    $sender = wp_get_current_user();
    $rid_label = get_post_meta( $rid, 'request_id', true ) ?: '#' . $rid;

    // Build headers — only add custom From when a valid address is configured
    $headers = array( 'Content-Type: text/html; charset=UTF-8' );
    $from_name  = get_option( 'nri_email_name', get_bloginfo( 'name' ) );
    $from_email = get_option( 'nri_email_from', '' );
    if ( $from_email && is_email( $from_email ) ) {
        $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
    }

    // Wrap body using the same branded HTML template used by all platform emails
    $req_url = home_url( '/request/' . $rid );

    // Split on blank lines into paragraphs; preserve single line breaks within each
    $raw_paragraphs = preg_split( '/\n{2,}/', trim( $body ) );
    $paragraphs = array();
    foreach ( $raw_paragraphs as $para ) {
        $para = trim( $para );
        if ( $para !== '' ) {
            $paragraphs[] = nl2br( esc_html( $para ) );
        }
    }
    if ( empty( $paragraphs ) ) {
        $paragraphs[] = nl2br( esc_html( trim( $body ) ) );
    }

    $html_body = nri_html_email(
        'Dear ' . $client->display_name . ',',
        $paragraphs,
        $rid_label,
        $req_url,
        'View Your Request'
    );

    $sent = wp_mail( $client->user_email, $subject, $html_body, $headers );

    if ( ! $sent ) {
        // Capture last WordPress mail error for a more useful message
        global $phpmailer;
        $smtp_err = '';
        if ( isset( $phpmailer ) && is_object( $phpmailer ) && ! empty( $phpmailer->ErrorInfo ) ) {
            $smtp_err = ' SMTP error: ' . $phpmailer->ErrorInfo;
        }
        nri_log( 'nri_send_comm_email: wp_mail failed. To=' . $client->user_email . ' Subject=' . $subject . $smtp_err );
        wp_send_json_error( array(
            'message' => 'Failed to send email.' . ( $smtp_err ? $smtp_err : ' Check WordPress SMTP/mail settings.' ),
        ) );
    }

    // Optionally log message to history
    global $wpdb;
    $mid = null;
    if ( $log_message ) {
        $wpdb->insert( $wpdb->prefix . 'nri_messages', array(
            'request_id'    => $rid,
            'sender_id'     => $sender->ID,
            'message'       => '[Email] ' . $subject . "\n\n" . $body,
            'is_email_sent' => 1,
        ) );
        $mid = $wpdb->insert_id;
    }

    nri_add_history( $rid, 'Email sent by ' . $sender->display_name . ' to ' . $client->user_email );
    nri_log( 'Communication email sent from ' . $sender->display_name . ' to ' . $client->user_email . ' for request ' . $rid );

    wp_send_json_success( array(
        'message'   => 'Email sent successfully to ' . $client->user_email,
        'logged'    => $log_message,
        'msg_id'    => $mid,
        'sent_time' => current_time( 'd M Y, g:i a' ),
        'sender'    => $sender->display_name,
    ) );
}

// ── COMMUNICATION PANEL: Get Email Template Body ────────────────────────────
add_action( 'wp_ajax_nri_get_comm_template', 'nri_ajax_get_comm_template' );
function nri_ajax_get_comm_template() {
    nri_check_nonce();
    nri_require_staff();

    $rid           = intval( $_POST['request_id'] ?? 0 );
    $template_type = sanitize_key( $_POST['template_type'] ?? '' );

    if ( ! $rid || ! $template_type ) {
        wp_send_json_error( array( 'message' => 'Invalid parameters.' ) );
    }

    $post   = get_post( $rid );
    $client = $post ? get_userdata( $post->post_author ) : null;
    $meta   = nri_get_meta( $rid );
    $fd     = $meta['field_data'];

    $client_name  = $client ? $client->display_name : 'Client';
    $rid_label    = get_post_meta( $rid, 'request_id', true ) ?: '#' . $rid;
    $platform     = get_option( 'nri_platform_name', get_bloginfo( 'name' ) );

    $templates = array(
        'quotation' => array(
            'subject' => 'Quotation for Your Request - Order #' . $rid_label,
            'body'    => "Dear {CLIENT_NAME},\n\nGreetings for the day!\n\nThank you for reaching out to us. We are pleased to share the quotation for your request.\n\nOrder ID: {REQUEST_ID}\nService Charges: INR {QUOTE_AMOUNT}\nShipping Charges: INR {SHIPPING}\nTimeline: {TIMELINE} Working Days\n(Excludes Sat, Sun, and Govt Holidays)\n\nKindly review the details and confirm your acceptance to proceed.\n\nFor any queries, feel free to contact us.\n\nWarm Regards,\n{PLATFORM}",
        ),
        'status_update' => array(
            'subject' => 'Status Update on Order #' . $rid_label,
            'body'    => "Dear {CLIENT_NAME},\n\nGreetings for the day!\n\nWe would like to inform you about the current status of your request.\n\nOrder ID: {REQUEST_ID}\nCurrent Status: {STATUS}\n\nWe will keep you updated on further progress. If you have any questions, please do not hesitate to reach out.\n\nWarm Regards,\n{PLATFORM}",
        ),
        'document_reminder' => array(
            'subject' => 'Document Required - Order #' . $rid_label,
            'body'    => "Dear {CLIENT_NAME},\n\nGreetings for the day!\n\nWe hope this message finds you well. This is a gentle reminder that we are awaiting the following documents for your request:\n\nOrder ID: {REQUEST_ID}\n\nRequired Documents:\n- All Semester Marksheets (Properly Scanned)\n- Degree Certificate (Properly Scanned)\n\nIMPORTANT: Please ensure all documents are properly scanned using a printer scanner. Mobile photos may not be accepted.\n\nNote: Your request cannot be processed without properly scanned documents.\n\nKindly upload the required documents at the earliest to avoid delays in processing.\n\nWarm Regards,\n{PLATFORM}",
        ),
        'general' => array(
            'subject' => 'Update Regarding Order #' . $rid_label,
            'body'    => "Dear {CLIENT_NAME},\n\nGreetings for the day!\n\nWe are writing to you regarding your request (Order ID: {REQUEST_ID}).\n\n[Your message here]\n\nIf you have any questions or need further assistance, please feel free to contact us.\n\nWarm Regards,\n{PLATFORM}",
        ),
    );

    if ( ! isset( $templates[ $template_type ] ) ) {
        // Try to get from email-templates.php system
        $tpl = nri_get_email_template( $template_type, array(
            'CUSTOMER_NAME'  => $client_name,
            'REQUEST_ID'     => $rid_label,
        ) );
        if ( $tpl ) {
            wp_send_json_success( $tpl );
        }
        wp_send_json_error( array( 'message' => 'Template not found.' ) );
    }

    $tpl = $templates[ $template_type ];

    // Replace variables
    $quote    = $meta['quote_amount'] ?: 'To be updated';
    $shipping = isset( $meta['shipping_charges'] ) ? $meta['shipping_charges'] : '0';
    $timeline = '';
    if ( ! empty( $meta['estimated_delivery'] ) ) {
        $timeline = date( 'd M Y', strtotime( $meta['estimated_delivery'] ) );
    }
    $status_label = nri_status_label( $meta['status'] );

    $replacements = array(
        '{CLIENT_NAME}'     => $client_name,
        '{REQUEST_ID}'      => $rid_label,
        '{QUOTE_AMOUNT}'    => $quote,
        '{SHIPPING}'        => $shipping,
        '{TIMELINE}'        => $timeline ?: 'To be updated',
        '{STATUS}'          => $status_label,
        '{PLATFORM}'        => $platform,
        '{DOCUMENT_TYPE}'   => ! empty( $fd['field_document_type'] ) ? $fd['field_document_type']
                             : ( ! empty( $fd['field_service_type'] ) ? $fd['field_service_type'] : 'Document Service' ),
        '{UNIVERSITY_NAME}' => ! empty( $fd['field_university_name'] ) ? $fd['field_university_name'] : '',
        '{CUSTOMER_NAME}'   => $client_name,
        '{DELIVERY_DATE}'   => $timeline ?: 'To be updated',
    );

    $tpl['subject'] = str_replace( array_keys( $replacements ), array_values( $replacements ), $tpl['subject'] );
    $tpl['body']    = str_replace( array_keys( $replacements ), array_values( $replacements ), $tpl['body'] );

    wp_send_json_success( $tpl );
}

// ── Quick email actions from staff panel ────────────────────────────────────
add_action('wp_ajax_nri_send_doc_reminder', 'nri_ajax_send_doc_reminder');
function nri_ajax_send_doc_reminder() {
    nri_check_nonce(); nri_require_staff();
    $rid  = intval($_POST['request_id'] ?? 0);
    $note = sanitize_textarea_field($_POST['note'] ?? '');
    if (!$rid) wp_send_json_error(array('message' => 'Invalid request.'));
    $sent = nri_notify_document_reminder($rid, $note);
    if ($sent) {
        nri_add_history($rid, 'Document reminder email sent to client');
        wp_send_json_success(array('message' => 'Document reminder sent successfully.'));
    } else {
        $post   = get_post($rid);
        $client = $post ? get_userdata($post->post_author) : null;
        $to_email = $client ? $client->user_email : 'unknown';
        nri_log('nri_send_doc_reminder: failed. rid=' . $rid . ' recipient=' . $to_email);
        wp_send_json_error(array('message' => 'Failed to send email to ' . $to_email . '. Check WordPress SMTP / mail plugin settings.'));
    }
}

add_action('wp_ajax_nri_send_status_email', 'nri_ajax_send_status_email');
function nri_ajax_send_status_email() {
    nri_check_nonce(); nri_require_staff();
    $rid = intval($_POST['request_id'] ?? 0);
    if (!$rid) wp_send_json_error(array('message' => 'Invalid request.'));
    $meta = nri_get_meta($rid);
    $post   = get_post($rid);
    $client = $post ? get_userdata($post->post_author) : null;
    $to_email = $client ? $client->user_email : 'unknown';
    $sent = nri_notify_status_change($rid, $meta['status']);
    if ($sent) {
        nri_add_history($rid, 'Status update email manually sent to client');
        wp_send_json_success(array('message' => 'Status update email sent successfully to ' . $to_email . '.'));
    } else {
        nri_log('nri_send_status_email: failed. rid=' . $rid . ' recipient=' . $to_email);
        wp_send_json_error(array('message' => 'Failed to send email to ' . $to_email . '. Check WordPress SMTP / mail plugin settings.'));
    }
}

// ── Bulk Excel Export ────────────────────────────────────────────────────────
add_action('wp_ajax_nri_bulk_export_excel', 'nri_ajax_bulk_export_excel');
function nri_ajax_bulk_export_excel() {
    nri_check_nonce();
    nri_require_staff();

    $request_ids = array_map('intval', (array)($_POST['request_ids'] ?? []));
    if (empty($request_ids)) {
        wp_send_json_error(array('message' => 'No requests selected.'));
    }
    $request_ids = array_filter($request_ids);

    global $wpdb;
    $fields_rows = $wpdb->get_results("SELECT field_key, field_label FROM {$wpdb->prefix}nri_fields ORDER BY sort_order ASC");
    $label_map   = array();
    foreach ($fields_rows as $fr) { $label_map['field_' . $fr->field_key] = $fr->field_label; }

    // Build header row
    $all_rows   = array();
    $header_done = false;

    foreach ($request_ids as $rid) {
        $post = get_post($rid);
        if (!$post || $post->post_type !== 'nri_request') continue;
        $meta   = nri_get_meta($rid);
        $author = get_userdata($post->post_author);
        $fd     = $meta['field_data'];
        $req_id = $meta['request_id'] ? $meta['request_id'] : '#' . $rid;

        if (!$header_done) {
            $header = array('Order ID', 'Client Name', 'Client Email', 'Status', 'Quote', 'Shipping', 'Est. Delivery', 'Submitted');
            foreach ($fd as $k => $v) {
                $header[] = isset($label_map[$k]) ? $label_map[$k] : ucwords(str_replace(array('field_','_'),array('',' '),$k));
            }
            $all_rows[]  = $header;
            $header_done = true;
        }

        $row = array(
            $req_id,
            $author ? $author->display_name : '',
            $author ? $author->user_email   : '',
            nri_status_label($meta['status']),
            $meta['quote_amount'] ? 'INR ' . number_format(floatval($meta['quote_amount']), 2) : '',
            isset($meta['shipping_charges']) ? 'INR ' . number_format(floatval($meta['shipping_charges']), 2) : '',
            $meta['estimated_delivery'] ? date('d M Y', strtotime($meta['estimated_delivery'])) : '',
            $post->post_date,
        );
        foreach ($fd as $k => $v) {
            $row[] = is_array($v) ? implode(', ', $v) : (string)$v;
        }
        $all_rows[] = $row;
    }

    if (count($all_rows) <= 1) {
        wp_send_json_error(array('message' => 'No valid requests found.'));
    }

    $xlsx     = nri_build_xlsx_simple($all_rows, 'Bulk Export');
    $filename = 'bulk-export-' . date('Y-m-d') . '.xlsx';
    $uploads  = wp_upload_dir();
    $filepath = trailingslashit($uploads['basedir']) . $filename;
    file_put_contents($filepath, $xlsx);
    $url = trailingslashit($uploads['baseurl']) . $filename;

    // Schedule cleanup after 5 min
    wp_schedule_single_event(time() + 300, 'nri_cleanup_temp_file', array($filepath));

    wp_send_json_success(array('url' => $url, 'filename' => $filename));
}
add_action('nri_cleanup_temp_file', function($path){ if (file_exists($path)) unlink($path); });

// -----------------------------------------------------------
// EMAIL TEMPLATE SAVE / RESET / TEST (Settings panel)
// -----------------------------------------------------------
add_action('wp_ajax_nri_save_email_template', 'nri_ajax_save_email_template');
function nri_ajax_save_email_template() {
    nri_check_nonce(); nri_require_staff();
    $type    = sanitize_key(isset($_POST['template_type']) ? $_POST['template_type'] : '');
    $subject = sanitize_text_field(isset($_POST['subject']) ? $_POST['subject'] : '');
    $body    = isset($_POST['body']) ? wp_kses_post(wp_unslash($_POST['body'])) : '';
    if (!$type || !$subject) wp_send_json_error(array('message' => 'Template type and subject are required.'));
    if (function_exists('nri_save_custom_template')) {
        $result = nri_save_custom_template($type, $subject, $body);
    } else {
        $result = update_option('nri_email_template_' . $type, array('subject' => $subject, 'body' => $body, 'updated_at' => current_time('mysql')));
    }
    if ($result) {
        nri_log('Email template saved: ' . $type);
        wp_send_json_success(array('message' => 'Template saved successfully.'));
    } else {
        wp_send_json_error(array('message' => 'Failed to save template.'));
    }
}

add_action('wp_ajax_nri_reset_email_template', 'nri_ajax_reset_email_template');
function nri_ajax_reset_email_template() {
    nri_check_nonce(); nri_require_staff();
    $type = sanitize_key(isset($_POST['template_type']) ? $_POST['template_type'] : '');
    if (!$type) wp_send_json_error(array('message' => 'Template type required.'));
    delete_option('nri_email_template_' . $type);
    wp_send_json_success(array('message' => 'Template reset to default.'));
}

add_action('wp_ajax_nri_test_email', 'nri_ajax_test_email');
function nri_ajax_test_email() {
    nri_check_nonce(); nri_require_staff();
    $type  = sanitize_key(isset($_POST['template_type']) ? $_POST['template_type'] : '');
    $email = sanitize_email(isset($_POST['test_email']) ? $_POST['test_email'] : '');
    if (!$email || !is_email($email)) wp_send_json_error(array('message' => 'Valid email address required.'));
    $template = function_exists('nri_get_email_template') ? nri_get_email_template($type, array()) : false;
    if (!$template) wp_send_json_error(array('message' => 'Template not found.'));
    $from_name  = get_option('nri_email_name',  get_bloginfo('name'));
    $from_email = get_option('nri_email_from',  '');
    $headers = array('Content-Type: text/html; charset=UTF-8');
    if ( $from_email && is_email( $from_email ) ) {
        $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
    }
    $sent = wp_mail($email, '[TEST] ' . $template['subject'], $template['body'], $headers);
    if ($sent) {
        wp_send_json_success(array('message' => 'Test email sent to ' . $email));
    } else {
        wp_send_json_error(array('message' => 'Failed to send test email. Check SMTP settings.'));
    }
}

// -----------------------------------------------------------
// COUNT broken documents (AVIF/WebP) — used by Settings > General
// -----------------------------------------------------------
function nri_count_broken_docs(): int {
    global $wpdb;
    $posts = $wpdb->get_col(
        "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'nri_request' AND post_status = 'publish'"
    );
    $count = 0;
    $finfo = new finfo( FILEINFO_MIME_TYPE );
    foreach ( $posts as $pid ) {
        $docs = get_post_meta( intval($pid), 'documents', true );
        if ( ! is_array( $docs ) ) continue;
        foreach ( $docs as $doc ) {
            $att_id = intval( $doc['file'] ?? 0 );
            if ( ! $att_id ) continue;
            $path = get_attached_file( $att_id );
            if ( ! $path || ! file_exists( $path ) ) continue;
            $mime = $finfo->file( $path );
            if ( in_array( $mime, [ 'image/avif', 'image/webp' ], true ) ) {
                $count++;
            }
        }
    }
    return $count;
}

add_action( 'wp_ajax_nri_count_avif_docs', 'nri_ajax_count_avif_docs' );
function nri_ajax_count_avif_docs(): void {
    nri_check_nonce();
    nri_require_staff();
    wp_send_json_success( [ 'count' => nri_count_broken_docs() ] );
}

// -----------------------------------------------------------
// BATCH FIX: convert all AVIF/WebP documents → PNG
// -----------------------------------------------------------
add_action( 'wp_ajax_nri_fix_avif_docs', 'nri_ajax_fix_avif_docs' );
function nri_ajax_fix_avif_docs(): void {
    nri_check_nonce();
    nri_require_staff();

    // wp_generate_attachment_metadata (called inside nri_sanitise_attachment) needs these
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $batch = max( 1, min( 20, intval( $_POST['batch'] ?? 10 ) ) );
    $finfo = new finfo( FILEINFO_MIME_TYPE );

    global $wpdb;
    $posts = $wpdb->get_col(
        "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'nri_request' AND post_status = 'publish'"
    );

    // Collect all broken attachment IDs
    $queue = [];
    foreach ( $posts as $pid ) {
        $docs = get_post_meta( intval($pid), 'documents', true );
        if ( ! is_array( $docs ) ) continue;
        foreach ( $docs as $doc ) {
            $att_id = intval( $doc['file'] ?? 0 );
            if ( ! $att_id ) continue;
            $path = get_attached_file( $att_id );
            if ( ! $path || ! file_exists( $path ) ) continue;
            $mime = $finfo->file( $path );
            if ( in_array( $mime, [ 'image/avif', 'image/webp' ], true ) ) {
                $queue[] = $att_id;
            }
        }
    }

    $remaining = max( 0, count( $queue ) - $batch );
    $to_fix    = array_slice( $queue, 0, $batch );
    $converted = 0;
    $failed    = 0;

    foreach ( $to_fix as $att_id ) {
        nri_sanitise_attachment( $att_id );
        $path = get_attached_file( $att_id );
        if ( $path && file_exists( $path ) ) {
            $mime = $finfo->file( $path );
            if ( in_array( $mime, [ 'application/pdf', 'image/jpeg', 'image/png' ], true ) ) {
                $converted++;
            } else {
                $failed++;
                nri_log( 'nri_fix_avif_docs: still not converted, att=' . $att_id );
            }
        } else {
            $failed++;
        }
    }

    wp_send_json_success( [
        'converted' => $converted,
        'failed'    => $failed,
        'remaining' => $remaining,
    ] );
}

// -----------------------------------------------------------
// BULK DOCUMENT DOWNLOAD — returns every document's proxied URL + a clean
// display name, plus a single "folder" name: "[Student Complete Name] –
// [Request Number]". Never packaged into a ZIP. The client
// (nriSaveFilesAsFolder() in nri-app.js, via the File System Access API)
// creates that one real folder and writes every file straight into it as
// a single download action, so the person gets one uncompressed folder
// with individual files inside — not a ZIP, and not several separate
// per-file downloads landing loose in their downloads folder. Browsers
// without File System Access support (Firefox, Safari, or any non-HTTPS
// context) fall back to the previous one-file-at-a-time download, which
// is the most those browsers can do without a server-side archive.
// Accessible by both staff and the request owner.
// -----------------------------------------------------------
add_action('wp_ajax_nri_bulk_download_docs', 'nri_ajax_bulk_download_docs');
function nri_ajax_bulk_download_docs() {
    nri_check_nonce();
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Login required.'), 401);
    }

    $rid     = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $att_ids = isset($_POST['att_ids']) ? array_map('intval', (array)$_POST['att_ids']) : array();
    $section = sanitize_text_field(isset($_POST['section']) ? $_POST['section'] : 'all'); // 'user', 'provider', 'all'

    if (!$rid) {
        wp_send_json_error(array('message' => 'Invalid request ID.'));
    }
    if (!nri_is_own_request($rid)) {
        wp_send_json_error(array('message' => 'Access denied.'), 403);
    }

    // Collect documents
    $docs = nri_get_documents($rid);
    if (empty($docs)) {
        wp_send_json_error(array('message' => 'No documents found for this request.'));
    }

    // Filter by section if needed
    if ($section === 'user') {
        $docs = array_filter($docs, function($d){ return empty($d['is_provider']); });
    } elseif ($section === 'provider') {
        $docs = array_filter($docs, function($d){ return !empty($d['is_provider']); });
    }

    // Further filter by specific attachment IDs if provided
    if (!empty($att_ids)) {
        $docs = array_filter($docs, function($d) use ($att_ids) {
            return in_array(intval($d['file']), $att_ids);
        });
    }

    $docs = array_values($docs);
    if (empty($docs)) {
        wp_send_json_error(array('message' => 'No matching documents to download.'));
    }

    // "[Student Complete Name] – [Request Number]" — the request number
    // keeps its existing format exactly as generated by
    // nri_generate_request_id() (e.g. NRI-2026-0554); the fallback only
    // applies to the handful of legacy requests created before that field
    // existed. The en dash (–) matches the format given in the request.
    $author       = get_userdata(get_post_field('post_author', $rid));
    $student_name = $author && $author->display_name ? $author->display_name : 'Client';
    $rid_label    = get_post_meta($rid, 'request_id', true) ?: ('REQ-' . $rid);
    $folder       = trim($student_name) . ' – ' . $rid_label;

    $urls       = array();
    $used_names = array();
    foreach ($docs as $doc) {
        $att_id = intval($doc['file']);
        if (!$att_id) { continue; }

        $doc_type = isset($doc['doc_type']) && $doc['doc_type'] ? $doc['doc_type'] : '';
        if ($doc_type) {
            $base = sanitize_file_name($doc_type);
        } else {
            $fn   = basename((string) get_attached_file($att_id));
            $base = sanitize_file_name(preg_replace('/\.(jpg|jpeg|png|webp|avif|pdf)$/i', '', $fn));
        }
        if ($base === '') { $base = 'document'; }
        // Avoid two documents in the same folder colliding on name (e.g.
        // two "Passport" entries) — the download endpoint appends the
        // correct extension itself, so only the base name needs to be
        // unique here.
        if (in_array($base, $used_names, true)) {
            $base .= '-' . (count($used_names) + 1);
        }
        $used_names[] = $base;

        $dl_url = function_exists('nri_get_download_url')
            ? nri_get_download_url($att_id, $base)
            : wp_get_attachment_url($att_id);
        if (!$dl_url) { continue; }

        // filename here is a clean, flat base name (no folder prefix) — the
        // real extension comes from the proxied URL's Content-Disposition
        // header (nri_ajax_download_document() decides PDF/JPG/PNG, converting
        // WebP/AVIF, so it isn't known until the response arrives). Grouping
        // every one of these into one actual folder is the client's job now
        // (nriSaveFilesAsFolder() in nri-app.js, via the File System Access
        // API), using the 'folder' name returned below — not this endpoint.
        $urls[] = array('url' => $dl_url, 'filename' => $base);
    }

    if (empty($urls)) {
        wp_send_json_error(array('message' => 'No matching documents to download.'));
    }

    nri_log('Bulk document download: ' . count($urls) . ' files, request ' . $rid . ', folder "' . $folder . '"');
    wp_send_json_success(array(
        'mode'   => 'sequential',
        'files'  => $urls,
        'folder' => $folder,
        'count'  => count($urls),
    ));
}

// -----------------------------------------------------------
// GET NEW MESSAGES SINCE A GIVEN MESSAGE ID (for live polling)
// -----------------------------------------------------------
add_action('wp_ajax_nri_get_messages_since',        'nri_ajax_get_messages_since');
add_action('wp_ajax_nopriv_nri_get_messages_since', 'nri_ajax_get_messages_since');
function nri_ajax_get_messages_since() {
    nri_check_nonce();
    if (!is_user_logged_in()) wp_send_json_error(array('message' => 'Login required.'), 401);

    $rid      = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $since_id = intval(isset($_POST['since_id'])   ? $_POST['since_id']   : 0);

    if (!$rid || !nri_is_own_request($rid)) {
        wp_send_json_error(array('message' => 'Access denied.'), 403);
    }

    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT m.id, m.sender_id, m.message, m.is_email_sent, m.created_at,
                u.display_name, u.user_email
         FROM {$wpdb->prefix}nri_messages m
         LEFT JOIN {$wpdb->prefix}users u ON m.sender_id = u.ID
         WHERE m.request_id = %d
           AND m.id > %d
           AND m.message NOT LIKE '[Email] %%'
         ORDER BY m.id ASC",
        $rid, $since_id
    ));

    $is_staff   = nri_is_staff();
    $cur_uid    = get_current_user_id();
    $out        = array();

    foreach ($rows as $m) {
        $is_mine         = ( (int) $m->sender_id === $cur_uid );
        $sender_is_staff = ( $m->user_email &&
            ( user_can( (int) $m->sender_id, 'administrator' ) ||
              user_can( (int) $m->sender_id, 'nri_admin' )    ||
              user_can( (int) $m->sender_id, 'nri_manager' ) ) );

        if      ( $is_mine )         { $label = 'You'; }
        elseif  ( $sender_is_staff ) { $label = $is_staff ? $m->display_name . ' (Admin)' : 'Support Team'; }
        else                         { $label = $is_staff ? $m->display_name . ' (Client)' : $m->display_name; }

        $out[] = array(
            'id'           => (int) $m->id,
            'message'      => $m->message,
            'time'         => wp_date( 'd M, g:i a', strtotime( $m->created_at ) ),
            'is_email_sent'=> (int) $m->is_email_sent,
            'sender_id'    => (int) $m->sender_id,
            'is_mine'      => $is_mine,
            'is_staff'     => $sender_is_staff,
            'label'        => $label,
            'can_delete'   => $is_staff,
        );
    }

    wp_send_json_success(array('messages' => $out));
}
