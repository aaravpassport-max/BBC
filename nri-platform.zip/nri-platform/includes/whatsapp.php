<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   CALLME BOT - Core send function
   ============================================================ */

function nri_wa_send( $phone, $message, $force = false ) {
    if ( ! $force && get_option('nri_wa_enabled','1') !== '1' ) return false;
    $api_key = get_option('nri_callme_api_key','');
    $api_url = get_option('nri_callme_api_url','https://api.callmebot.com/whatsapp.php');
    if ( ! $api_key || ! $phone ) return false;

    $phone   = preg_replace('/[^+0-9]/', '', $phone);
    $url     = add_query_arg([
        'phone'  => urlencode($phone),
        'text'   => urlencode($message),
        'apikey' => $api_key,
    ], $api_url);

    $response = wp_remote_get($url, ['timeout'=>15,'sslverify'=>false]);
    $ok       = !is_wp_error($response) && wp_remote_retrieve_response_code($response) == 200;
    nri_log( 'WA send to ' . $phone . ' - ' . ($ok ? 'OK' : 'FAIL') . ' - ' . substr($message, 0, 80) );
    return $ok;
}

/* ============================================================
   SEND TO STAFF / ADMIN
   ============================================================ */

function nri_wa_notify_admin( $message ) {
    $no = get_option('nri_wa_admin_number','');
    if ($no) nri_wa_send($no, $message);
}

function nri_wa_notify_staff( $message ) {
    $lines = preg_split('/\r\n|\r|\n/', get_option('nri_wa_staff_numbers',''));
    foreach ($lines as $line) {
        $no = trim($line);
        if ($no) nri_wa_send($no, $message);
    }
}

/* ============================================================
   TEMPLATE RENDERER
   ============================================================ */

function nri_wa_render( $template_option, $vars = [] ) {
    $tpl = get_option($template_option, '');
    if (!$tpl) return '';
    foreach ($vars as $k => $v) {
        $tpl = str_replace('{' . $k . '}', $v, $tpl);
    }
    return $tpl;
}

/* ============================================================
   NOTIFICATION HELPERS - build vars from request
   ============================================================ */

function nri_wa_vars( $rid ) {
    $meta     = nri_get_meta($rid);
    $post     = get_post($rid);
    $client   = $post ? get_userdata($post->post_author) : null;
    $fd       = $meta['field_data'];
    $service  = !empty($fd['field_service_type']) ? $fd['field_service_type']
              : (!empty($fd['field_document_type']) ? $fd['field_document_type'] : 'Document Request');
    $phone    = !empty($fd['field_phone']) ? $fd['field_phone'] : '';
    $vid      = $meta['assigned_vendor'];
    $vendor   = null;
    if ($vid) {
        // Try vendor table first, fallback to WP user
        global $wpdb;
        $vendor = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}nri_vendors WHERE id=%d", $vid));
        if (!$vendor) {
            $u = get_userdata($vid);
            if ($u) {
                $vendor = (object)[
                    'name'     => $u->display_name,
                    'whatsapp' => get_user_meta($vid,'nri_whatsapp',true),
                    'phone'    => $u->user_email,
                ];
            }
        }
    }

    $assigned_at = get_post_meta($rid, 'vendor_assigned_at', true);
    $days        = $assigned_at ? floor((time() - strtotime($assigned_at)) / DAY_IN_SECONDS) : 0;

    return [
        'client_name'  => $client ? $client->display_name : 'Client',
        'client_phone' => $phone,
        'work_type'    => $service,
        'request_id'   => $meta['request_id'] ?: '#'.$rid,
        'vendor_name'  => $vendor ? $vendor->name : 'Vendor',
        'vendor_phone' => $vendor ? ($vendor->whatsapp ?: $vendor->phone) : '',
        'days'         => $days,
        'amount'       => get_post_meta($rid,'quote_amount',true) ? 'Rs.'.number_format((float)get_post_meta($rid,'quote_amount',true),2) : '-',
        'request_url'  => home_url('/request/'.$rid),
        'status'       => nri_status_label($meta['status']),
        '_vendor_obj'  => $vendor,
    ];
}

/* ============================================================
   TRIGGER: NEW APPLICATION SUBMITTED (admin / owner alert)
   ============================================================ */

function nri_wa_on_new_submission( $rid ) {
    if ( get_option( 'nri_wa_enabled', '1' ) !== '1' ) return;

    $vars = nri_wa_vars( $rid );

    // Use custom template if configured, otherwise fall back to a built-in message
    $msg = nri_wa_render( 'nri_wa_new_submission_tpl', $vars );
    if ( ! $msg ) {
        $msg = "\u{2705} *New Application Received*\n"
             . "Client : {$vars['client_name']}\n"
             . "Phone  : {$vars['client_phone']}\n"
             . "Service: {$vars['work_type']}\n"
             . "Ref    : {$vars['request_id']}\n"
             . "Time   : " . current_time( 'd M Y H:i' ) . "\n"
             . "Link   : {$vars['request_url']}";
    }

    nri_wa_notify_admin( $msg );
    nri_wa_notify_staff( $msg );
}

/* ============================================================
   TRIGGER: VENDOR ASSIGNED
   ============================================================ */

function nri_wa_on_vendor_assigned( $rid, $vendor_id ) {
    if (get_option('nri_wa_enabled','1') !== '1') return;

    global $wpdb;
    $vendor = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}nri_vendors WHERE id=%d", $vendor_id));
    if (!$vendor && is_numeric($vendor_id)) {
        $u = get_userdata($vendor_id);
        if ($u) $vendor = (object)['name'=>$u->display_name,'whatsapp'=>get_user_meta($vendor_id,'nri_whatsapp',true)];
    }

    $vars = nri_wa_vars($rid);

    // Notify vendor
    if ($vendor && !empty($vendor->whatsapp)) {
        $msg = nri_wa_render('nri_wa_assign_tpl', $vars);
        if ($msg) nri_wa_send($vendor->whatsapp, $msg);
    }

    // Notify admin
    $admin_msg = " *Vendor Assigned*\nLead: {$vars['client_name']}\nWork: {$vars['work_type']}\nVendor: {$vars['vendor_name']}\nRequest: {$vars['request_id']}";
    nri_wa_notify_admin($admin_msg);

    // Record assignment time for escalation tracking
    update_post_meta($rid, 'vendor_assigned_at', current_time('mysql'));
    update_post_meta($rid, 'vendor_escalation_level', 0);
}

/* ============================================================
   TRIGGER: STATUS UPDATED
   ============================================================ */

function nri_wa_on_status_change( $rid, $new_status ) {
    if (get_option('nri_wa_enabled','1') !== '1') return;
    $vars = nri_wa_vars($rid);

    if ($new_status === 'completed') {
        $msg = nri_wa_render('nri_wa_complete_tpl', $vars);
        if ($msg) {
            nri_wa_notify_admin($msg);
            nri_wa_notify_staff($msg);
        }
    }
}

/* ============================================================
   TRIGGER: PAYMENT RELEASED (when quote/payment updated by admin)
   ============================================================ */

function nri_wa_on_payment( $rid ) {
    if (get_option('nri_wa_enabled','1') !== '1') return;
    $vars = nri_wa_vars($rid);
    $vid  = get_post_meta($rid,'assigned_vendor',true);
    global $wpdb;
    $vendor = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}nri_vendors WHERE id=%d", $vid));
    if ($vendor && !empty($vendor->whatsapp)) {
        $msg = nri_wa_render('nri_wa_payment_tpl', $vars);
        if ($msg) nri_wa_send($vendor->whatsapp, $msg);
    }
}

/* ============================================================
   CRON: DAILY - follow-up reminders + escalations
   ============================================================ */

add_action('nri_daily_cron', 'nri_wa_daily_checks');
function nri_wa_daily_checks() {
    if (get_option('nri_wa_enabled','1') !== '1') return;
    nri_wa_check_followups();
    nri_wa_check_escalations();
}

function nri_wa_check_followups() {
    $today = date('Y-m-d');
    $args  = [
        'post_type'   => 'nri_request',
        'post_status' => 'publish',
        'meta_query'  => [
            ['key'=>'next_action_date','value'=>$today,'compare'=>'='],
        ],
        'posts_per_page' => -1,
    ];
    $q = new WP_Query($args);
    foreach ($q->posts as $p) {
        $vars = nri_wa_vars($p->ID);
        $msg  = nri_wa_render('nri_wa_followup_tpl', $vars);
        if ($msg) {
            nri_wa_notify_admin($msg);
            nri_wa_notify_staff($msg);
        }
    }
}

function nri_wa_check_escalations() {
    global $wpdb;
    // Get all active requests with vendors assigned
    $posts = $wpdb->get_results("
        SELECT p.ID, pm1.meta_value AS assigned_vendor, pm2.meta_value AS assigned_at, pm3.meta_value AS esc_level
        FROM {$wpdb->prefix}posts p
        LEFT JOIN {$wpdb->prefix}postmeta pm1 ON pm1.post_id=p.ID AND pm1.meta_key='assigned_vendor'
        LEFT JOIN {$wpdb->prefix}postmeta pm2 ON pm2.post_id=p.ID AND pm2.meta_key='vendor_assigned_at'
        LEFT JOIN {$wpdb->prefix}postmeta pm3 ON pm3.post_id=p.ID AND pm3.meta_key='vendor_escalation_level'
        WHERE p.post_type='nri_request' AND p.post_status='publish'
        AND pm1.meta_value IS NOT NULL AND pm1.meta_value != ''
        AND pm2.meta_value IS NOT NULL
    ");

    foreach ($posts as $row) {
        $rid          = $row->ID;
        $vendor_id    = $row->assigned_vendor;
        $assigned_at  = $row->assigned_at;
        $esc_level    = (int)((isset($row->esc_level) ? $row->esc_level : 0));
        if (!$assigned_at || !$vendor_id) continue;

        $hours_elapsed = (time() - strtotime($assigned_at)) / HOUR_IN_SECONDS;
        $days_elapsed  = $hours_elapsed / 24;

        // Get vendor-specific thresholds
        $vendor = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}nri_vendors WHERE id=%d", $vendor_id));
        $esc_hours = $vendor ? intval($vendor->escalation_hours) : 24;
        $esc_days  = $vendor ? intval($vendor->escalation_days)  : 3;

        $vars  = nri_wa_vars($rid);
        $status = get_post_meta($rid,'status',true);
        if (in_array($status,['completed','rejected'])) continue;

        // Level 1: reminder after X hours
        if ($esc_level < 1 && $hours_elapsed >= $esc_hours) {
            $msg = nri_wa_render('nri_wa_followup_tpl', $vars);
            if ($msg && $vendor && !empty($vendor->whatsapp)) nri_wa_send($vendor->whatsapp, $msg);
            update_post_meta($rid,'vendor_escalation_level',1);
            nri_add_history($rid, 'WA Reminder sent to vendor (level 1)');
        }

        // Level 2: escalate to admin after X days
        if ($esc_level < 2 && $days_elapsed >= $esc_days) {
            // Mark vendor as delayed
            update_post_meta($rid,'vendor_status','delayed');
            // Send escalation WA to admin
            $msg = nri_wa_render('nri_wa_escalation_tpl', $vars);
            if ($msg) nri_wa_notify_admin($msg);
            // Second reminder to vendor
            if ($vendor && !empty($vendor->whatsapp)) {
                $r2 = " *Urgent Reminder*\nDear {$vars['vendor_name']}, please respond immediately for {$vars['client_name']}.\nRequest: {$vars['request_id']}\nOverdue by {$vars['days']} days!";
                nri_wa_send($vendor->whatsapp, $r2);
            }
            update_post_meta($rid,'vendor_escalation_level',2);
            nri_add_history($rid, 'Vendor escalated to admin (level 2) - overdue '.$vars['days'].' days');
        }
    }
}

/* ============================================================
   HOOK INTO EXISTING AJAX - assign vendor  trigger WA
   ============================================================ */

add_action('nri_after_vendor_assigned', 'nri_wa_on_vendor_assigned', 10, 2);
add_action('nri_after_status_changed',  'nri_wa_on_status_change',   10, 2);
add_action('nri_after_payment_set',     'nri_wa_on_payment',         10, 1);
