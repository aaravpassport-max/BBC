<?php
namespace GoodService\Module;

use GoodService\Core\Config;
use GoodService\Core\Cache;

/**
 * ModuleManager — Feature flag system.
 *
 * Each feature module can be independently enabled/disabled from the admin panel.
 * Stored in gs_settings. Runtime switching — no code changes required.
 *
 * Usage:
 *   ModuleManager::is_enabled('booking')   → true/false
 *   ModuleManager::enable('booking')
 *   ModuleManager::disable('messaging')
 *   ModuleManager::all()                   → array of all modules with their status
 */
final class ModuleManager {

    /** Master list of all available modules. */
    public const MODULES = [
        'listings'     => [ 'label' => 'Listings',         'description' => 'Core listing directory',          'core' => true  ],
        'vendors'      => [ 'label' => 'Vendors',          'description' => 'Vendor profiles & management',    'core' => true  ],
        'leads'        => [ 'label' => 'Leads',            'description' => 'Lead capture & management',       'core' => true  ],
        'reviews'      => [ 'label' => 'Reviews',          'description' => 'Customer reviews & ratings',      'core' => false ],
        'billing'      => [ 'label' => 'Billing',          'description' => 'Subscriptions, invoices, plans',  'core' => false ],
        'analytics'    => [ 'label' => 'Analytics',        'description' => 'Views, leads, conversion data',   'core' => false ],
        'messaging'    => [ 'label' => 'Messaging',        'description' => 'Vendor-customer chat threads',    'core' => false ],
        'booking'      => [ 'label' => 'Booking',          'description' => 'Appointment / slot booking',      'core' => false ],
        'requirements' => [ 'label' => 'Reverse Leads',    'description' => 'Post requirements, get quotes',   'core' => false ],
        'complaints'   => [ 'label' => 'Complaints',       'description' => 'Dispute & complaint management',  'core' => false ],
        'verification' => [ 'label' => 'Verification',     'description' => 'Document-based vendor trust',     'core' => false ],
        'seo'          => [ 'label' => 'SEO Tools',        'description' => 'Per-listing SEO overrides',       'core' => false ],
        'api'          => [ 'label' => 'REST API',         'description' => 'External API access for vendors', 'core' => false ],
    ];

    private static array $cache = [];

    /** Boot the module system — called once during Plugin::boot(). */
    public static function boot(): void {
        // Seed default module states on first run
        foreach ( self::MODULES as $slug => $meta ) {
            $key = "module_{$slug}_enabled";
            if ( Config::get( $key ) === null ) {
                // Core modules default ON; optional modules default OFF except reviews/analytics
                $default = $meta['core'] || in_array( $slug, [ 'reviews', 'analytics', 'billing', 'requirements', 'complaints' ], true );
                Config::set( $key, $default ? '1' : '0', 'modules' );
            }
        }
    }

    /** Check whether a module is currently enabled. */
    public static function is_enabled( string $module ): bool {
        if ( isset( self::$cache[ $module ] ) ) {
            return self::$cache[ $module ];
        }
        // Core modules are always enabled
        if ( ( self::MODULES[ $module ]['core'] ?? false ) ) {
            self::$cache[ $module ] = true;
            return true;
        }
        $value = Config::get( "module_{$module}_enabled", '0' );
        self::$cache[ $module ] = $value === '1' || $value === true;
        return self::$cache[ $module ];
    }

    public static function enable( string $module ): void {
        Config::set( "module_{$module}_enabled", '1', 'modules' );
        self::$cache[ $module ] = true;
    }

    public static function disable( string $module ): void {
        if ( self::MODULES[ $module ]['core'] ?? false ) {
            throw new \LogicException( "Core module '{$module}' cannot be disabled." );
        }
        Config::set( "module_{$module}_enabled", '0', 'modules' );
        self::$cache[ $module ] = false;
    }

    /** Return all modules with their enabled status. */
    public static function all(): array {
        $result = [];
        foreach ( self::MODULES as $slug => $meta ) {
            $result[ $slug ] = array_merge( $meta, [ 'slug' => $slug, 'enabled' => self::is_enabled( $slug ) ] );
        }
        return $result;
    }

    /** Toggle a module on/off. Returns new state. */
    public static function toggle( string $module ): bool {
        $new = ! self::is_enabled( $module );
        $new ? self::enable( $module ) : self::disable( $module );
        return $new;
    }
}
