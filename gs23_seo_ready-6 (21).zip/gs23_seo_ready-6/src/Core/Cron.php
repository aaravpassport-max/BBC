<?php
namespace GoodService\Core;

final class Cron {

    public static function register(): void {
        add_filter( 'cron_schedules', [ self::class, 'add_schedules' ] );
        add_action( 'gs_hourly',   [ self::class, 'hourly'  ] );
        add_action( 'gs_daily',    [ self::class, 'daily'   ] );
        add_action( 'gs_weekly',   [ self::class, 'weekly'  ] );
        // FIXED — root-cause audit finding: Cron::monthly() (compute_demand_signals(),
        // ProfitIntelligenceService::compute_monthly_benchmarks(),
        // generate_seo_location_pages(), VendorScorecardService::send_monthly_scorecards())
        // was a fully-built, correct method that was never hooked to any WP cron
        // event anywhere in the codebase — confirmed via an exhaustive grep across
        // src/ for both 'gs_monthly' and every function monthly() calls: the only
        // call sites for all four were inside monthly() itself. This is not a
        // "let it run and see" gap — since the plugin was first installed, the
        // Hyperlocal Demand Map, the monthly Profit Intelligence benchmarks, SEO
        // location-page generation, and vendor monthly scorecard emails have
        // never executed on any install, ever, on schedule or otherwise.
        add_action( 'gs_monthly',  [ self::class, 'monthly' ] );

        if ( ! wp_next_scheduled( 'gs_hourly' ) ) {
            wp_schedule_event( time(), 'hourly', 'gs_hourly' );
        }
        if ( ! wp_next_scheduled( 'gs_daily' ) ) {
            wp_schedule_event( time(), 'daily', 'gs_daily' );
        }
        if ( ! wp_next_scheduled( 'gs_weekly' ) ) {
            wp_schedule_event( time(), 'weekly', 'gs_weekly' );
        }
        if ( ! wp_next_scheduled( 'gs_monthly' ) ) {
            wp_schedule_event( time(), 'gs_monthly', 'gs_monthly' );
        }
    }

    public static function add_schedules( array $s ): array {
        $s['gs_five_minutes'] = [ 'interval' => 300,    'display' => 'Every 5 Minutes' ];
        $s['weekly']          = [ 'interval' => 604800,  'display' => 'Once Weekly' ];
        // 30 days, not a calendar-month — WP core has no native monthly interval
        // and cron intervals must be a fixed number of seconds. Close enough for
        // benchmark/SEO/scorecard jobs, which are not calendar-sensitive; each
        // run recomputes from current live data rather than depending on having
        // fired on any particular date.
        $s['gs_monthly']       = [ 'interval' => 30 * DAY_IN_SECONDS, 'display' => 'Once Monthly (GoodService)' ];
        return $s;
    }

    // =========================================================================
    // Hourly tasks
    // =========================================================================

    public static function hourly(): void {
        // Concurrency lock — prevent two PHP processes running hourly() simultaneously.
        // set_transient returns false if the key already exists (atomic on most object caches).
        // TTL of 10 minutes: if a run crashes mid-way, the lock clears and the next cron fires.
        $lock_key = 'gs_cron_hourly_lock';
        if ( ! set_transient( $lock_key, 1, 10 * MINUTE_IN_SECONDS ) ) {
            gs_write_log( 'Cron: hourly() skipped — another process is already running it', 'INFO' );
            return;
        }

        $tasks = [
            'expire_subscriptions'   => fn() => JobQueue::push( 'expire_subscriptions', [] ),
            'check_missed_inquiries' => fn() => self::check_missed_inquiries(),
            // ENTERPRISE-AUDIT FIX (Critical, confirmed): "no auto-assignment
            // to a vendor rep, no round-robin" — see auto_assign_leads() below.
            'auto_assign_leads'      => fn() => self::auto_assign_leads(),
            'booking_reminder'       => fn() => self::booking_reminder_cascade(),
            'booking_auto_expire'    => fn() => self::booking_auto_expire(),
            'booking_noshow'         => fn() => self::booking_noshow_detection(),
            'booking_stuck_sweep'    => fn() => self::booking_stuck_job_sweep(),
            'booking_post_completion'=> fn() => self::booking_post_completion(),
            'booking_waitlist'       => fn() => self::booking_waitlist_notify(),
            // Safe auto search-engine ping (IndexNow) — drains the queue
            // filled by IndexNowService::submit_for_listing() on listing
            // save/approve. See IndexNowService.php for the full design
            // rationale and the safety checks this replaces.
            'indexnow_process_queue' => fn() => \GoodService\Service\IndexNowService::process_queue(),
            // ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "No SLA/
            // escalation tracking on complaints or disputes — status/
            // priority fields only, no due-date, auto-escalation, or
            // assignee"). See escalate_overdue_complaints() below.
            'escalate_overdue_complaints' => fn() => self::escalate_overdue_complaints(),
        ];

        foreach ( $tasks as $name => $fn ) {
            try {
                $fn();
            } catch ( \Throwable $e ) {
                gs_write_log( "Cron hourly task [{$name}] failed: " . $e->getMessage()
                    . ' in ' . str_replace( ABSPATH, '', $e->getFile() ) . ':' . $e->getLine(), 'ERROR' );
                // Continue to next task — one failure must not abort the rest
            }
        }

        // NOTE: SubscriptionService::expire_batch() is intentionally NOT called
        // directly here. The job queue handler calls it when processing the
        // 'expire_subscriptions' job above. Calling it twice per cron tick was
        // doubling DB load and cache-invalidation work (CRITICAL BUG FIX #6).

        // Expire open requirements
        global $wpdb;
        $wpdb->query(
            "UPDATE {$wpdb->prefix}gs_requirements
             SET status='expired'
             WHERE status='open' AND expires_at IS NOT NULL AND expires_at < NOW()"
        );

        // Purge old completed/failed jobs (keep 7 days of history)
        JobQueue::purge( 7 );

        // Release concurrency lock
        delete_transient( $lock_key );
        update_option( 'gs_last_cron_run', time(), false );
    }

    // =========================================================================
    // Daily tasks
    // =========================================================================

    public static function daily(): void {
        // Concurrency lock — prevent two WP-Cron fires from running daily() simultaneously.
        // Without this, on high-traffic installs where WP-Cron fires via page load,
        // two concurrent requests can trigger this at the same time, causing duplicate
        // subscription expiry emails and double-processing of all daily tasks.
        $lock_key = 'gs_cron_daily_lock';
        if ( ! set_transient( $lock_key, 1, 20 * MINUTE_IN_SECONDS ) ) {
            return; // Another instance is already running — skip
        }
        $daily_tasks = [
            'update_trust_scores'           => fn() => self::update_trust_scores(),
            'trigger_subscription_inquiries'=> fn() => self::trigger_subscription_inquiries(),
            'check_trial_endings'           => fn() => self::check_trial_endings(),
            // ENTERPRISE-AUDIT FIX (Part 2, High): "No automatic dunning/retry
            // cascade for failed recurring payments." See
            // SubscriptionService::start_or_touch_dunning() (started from the
            // Razorpay/Stripe payment.failed webhook handlers) and
            // payment_dunning_cascade() below for the escalating reminders and
            // eventual auto-downgrade once the grace period expires unresolved.
            'payment_dunning_cascade'       => fn() => self::payment_dunning_cascade(),
            'home_os_due_reminders'         => fn() => \GoodService\Service\HomeOsService::send_due_reminders(),
            // Manual Subscription & Offline Payment system (Section 4 & 5 of spec:
            // Renewal Reminder / Plan Expiry Reminder notifications, and scheduled-future
            // plan activation for admin assignments made with "Schedule future activation").
            'activate_scheduled_manual_plans' => fn() => self::activate_scheduled_manual_plans(),
            'manual_plan_renewal_reminders'   => fn() => self::manual_plan_renewal_reminders(),
            // FIX (enterprise hardening pass): rate-limited, cache-backed resolver for the
            // Hyperlocal Demand Map's city coordinates — see GeoCodingService for the full
            // root-cause writeup. Runs a small batch per day so demand-map coverage grows
            // over time for ANY city with real inquiry volume, not just a fixed hardcoded
            // list, without making any dashboard page load depend on a live external call.
            'geocode_demand_map_cities'       => fn() => self::geocode_demand_map_cities(),
            // FIXED — Known Limitations audit: the "Missing DB Columns" warning on
            // Admin Tools was purely reactive — it only appeared AFTER a vendor's
            // save had already silently dropped a field, meaning at least one real
            // vendor was already affected before any admin could know. This daily
            // check proactively compares the live gs_listings table's actual
            // columns against the same authoritative column list
            // Schema::upgrade_columns() itself installs, and raises the identical
            // gs_missing_cols_warning option — with id=0 signaling "found by
            // proactive check, not triggered by any specific listing save" — so
            // schema drift (e.g. a failed migration on a staging clone) is caught
            // before a vendor is ever affected by it.
            'check_missing_listing_columns'   => fn() => self::check_missing_listing_columns(),
            // ENTERPRISE-AUDIT FIX (Part 1, High: "Enterprise admin tools
            // require a recoverable trash bin (30-day retention)"). See
            // AjaxController::adminDeleteListing()/adminRestoreListing() for
            // the soft-delete itself — this is the retention-window half of
            // that fix, permanently removing anything that's sat in Trash
            // (status='deleted') for 30+ days, same as any standard trash bin.
            'purge_old_trashed_listings'      => fn() => self::purge_old_trashed_listings(),
        ];
        foreach ( $daily_tasks as $name => $fn ) {
            try { $fn(); }
            catch ( \Throwable $e ) {
                gs_write_log( "Cron daily task [{$name}] failed: " . $e->getMessage()
                    . ' in ' . str_replace( ABSPATH, '', $e->getFile() ) . ':' . $e->getLine(), 'ERROR' );
            }
        }
        global $wpdb;

        // ── 1. Purge old analytics rows ────────────────────────────────────────
        $days = (int) Config::get( 'analytics_retention_days', 365 );
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}gs_analytics
             WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ) );

        // ── 2. Update category listing counts ─────────────────────────────────
        ( new \GoodService\Repository\CategoryRepository() )->update_counts();

        // ── 3. Trust-score batch — process vendors in rotating offsets so all
        //       vendors are covered over time without hogging a single cron run.
        //       Processes 100 vendors per run; offset stored in options.
        //
        //       MAJOR FIX #11: Replaced the N+1 pattern (cache read + listing count
        //       query + UPDATE per vendor = 300 queries for 100 vendors) with a
        //       single computed approach: fetch all data needed for scoring in one
        //       JOIN query, compute scores in PHP, then batch-UPDATE in one statement.
        $offset = (int) get_option( 'gs_trust_score_offset', 0 );
        $total  = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gs_vendor_profiles WHERE is_active = 1"
        );

        // Fetch profile fields + active listing count in one JOIN query
        $vendors = $wpdb->get_results( $wpdb->prepare(
            "SELECT vp.id, vp.user_id,
                    vp.business_name, vp.phone, vp.email, vp.bio, vp.logo_url,
                    vp.address, vp.website, vp.verification_status,
                    COUNT(l.id) AS active_listings
             FROM {$wpdb->prefix}gs_vendor_profiles vp
             LEFT JOIN {$wpdb->prefix}gs_listings l
               ON l.vendor_id = vp.id AND l.status = 'active'
             WHERE vp.is_active = 1
             GROUP BY vp.id
             ORDER BY vp.id ASC
             LIMIT 100 OFFSET %d",
            $offset
        ) );

        if ( ! empty( $vendors ) ) {
            // Compute all scores in PHP, then build a single batch CASE UPDATE
            $case_parts = [];
            $ids        = [];

            foreach ( $vendors as $v ) {
                $score = 0;
                if ( $v->business_name )                          $score += 10;
                if ( $v->phone )                                   $score += 10;
                if ( $v->email )                                   $score += 5;
                if ( $v->bio )                                     $score += 10;
                if ( $v->logo_url )                               $score += 10;
                if ( $v->address )                                $score += 5;
                if ( $v->website )                                $score += 5;
                if ( $v->verification_status === 'verified' )     $score += 30;
                $score += min( 15, (int) $v->active_listings * 5 );
                $score  = min( 100, $score );

                $case_parts[] = "WHEN id = " . (int) $v->id . " THEN " . (int) $score;
                $ids[]        = (int) $v->id;
            }

            // Single UPDATE touches all 100 vendors in one round-trip
            $ids_list = implode( ',', $ids );
            $wpdb->query(
                "UPDATE {$wpdb->prefix}gs_vendor_profiles
                 SET trust_score = CASE " . implode( ' ', $case_parts ) . " ELSE trust_score END
                 WHERE id IN ({$ids_list})"
            );

            // Real fix — this batch UPDATE bypassed VendorRepository's cache
            // entirely, so vendor:id:{id} / vendor:user:{uid} (cached 600s/60s
            // respectively) kept serving the pre-update trust_score for up to
            // 10 minutes after every cron run. "vendor" is the shared group
            // prefix for both key shapes (Cache::group() reads everything
            // before the first ':'), so one flush_group() call here — not per
            // vendor — invalidates both in a single wp_options write.
            \GoodService\Core\Cache::flush_group( 'vendor' );
        }

        // Advance (or reset) the rotating offset
        $processed   = count( $vendors );
        $next_offset = ( $processed < 100 || ( $offset + $processed >= $total ) ) ? 0 : $offset + $processed;
        update_option( 'gs_trust_score_offset', $next_offset );

        // ── 4. Clean up stale GoodService transients left by the old Cache.php ─
        //       (one-time migration — runs until the migration flag is set)
        if ( ! get_option( 'gs_old_transients_purged' ) ) {
            self::purge_legacy_transients();
        }

        // Release concurrency lock
        delete_transient( $lock_key );
    }

    // =========================================================================
    // Weekly tasks
    // =========================================================================

    public static function weekly(): void {
        $lock_key = 'gs_cron_weekly_lock';
        if ( ! set_transient( $lock_key, 1, 30 * MINUTE_IN_SECONDS ) ) {
            return;
        }
        global $wpdb;

        // ── OPTIMIZE analytics table ───────────────────────────────────────────
        // The analytics table grows fast (one row per event) and benefits from
        // periodic OPTIMIZE to reclaim space after the daily DELETE purge.
        // OPTIMIZE on InnoDB is equivalent to ALTER TABLE … ENGINE=InnoDB;
        // it rebuilds the clustered index and reclaims fragmented pages.
        //
        // We suppress errors because OPTIMIZE requires no active transactions
        // and could fail on very large tables if the server is under load —
        // in that case it simply doesn't run this week and tries again next week.
        $wpdb->suppress_errors( true );
        $wpdb->query( "OPTIMIZE TABLE {$wpdb->prefix}gs_analytics" );
        $wpdb->suppress_errors( false );

        // ── Prune error_log rows older than 30 days ───────────────────────────
        $wpdb->query(
            "DELETE FROM {$wpdb->prefix}gs_error_log
             WHERE is_resolved = 1
               AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)"
        );

        // ── Purge old activity_log rows (keep 90 days) ────────────────────────
        $wpdb->query(
            "DELETE FROM {$wpdb->prefix}gs_activity_log
             WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)"
        );

        delete_transient( $lock_key );
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    /**
     * One-time cleanup: remove old-format GoodService transients from wp_options.
     * These were written by Cache.php v20/v21 using the pattern '_transient_gs_c_*'.
     * New Cache.php uses '_transient_gsc*' — so old rows are dead weight.
     *
     * Runs once (guarded by an option flag) to keep wp_options lean.
     * Uses batched deletes to avoid long-running queries.
     */
    private static function purge_legacy_transients(): void {
        global $wpdb;

        $batch = 200;
        $total = 0;

        do {
            // Fetch a batch of old key names first (avoids LIKE + DELETE in one step)
            $keys = $wpdb->get_col( $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options}
                 WHERE option_name LIKE %s
                    OR option_name LIKE %s
                 LIMIT %d",
                '_transient_gs_c_%',
                '_transient_timeout_gs_c_%',
                $batch
            ) );

            if ( empty( $keys ) ) { break; }

            $placeholders = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
            $wpdb->query( $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name IN ({$placeholders})",
                ...$keys
            ) );

            $total += count( $keys );
        } while ( count( $keys ) === $batch ); // keep going if there's more

        if ( function_exists( 'gs_write_log' ) ) {
            gs_write_log( "purge_legacy_transients: removed {$total} old transient rows.", 'INFO' );
        }

        update_option( 'gs_old_transients_purged', time() );
    }

    // =========================================================================
    // Missed Inquiry Alert System (Part 1.3 / Part 5.2)
    // =========================================================================

    /**
     * Alert vendors about unanswered inquiries (2h and 6h escalation).
     * Also queues client backup-vendor suggestions when vendor hasn't replied in 2h.
     */
    // =========================================================================
    // Phase 3 — Booking Lifecycle Automation
    // =========================================================================

    // ── Phase 3 — Booking Lifecycle Automation
    // =========================================================================

    /**
     * booking_waitlist_notify()
     * When a confirmed booking transitions to 'cancelled', notify the next
     * person on the waitlist for that listing+date so they can claim the slot.
     * Gives a 2-hour claim window before moving to the next in line.
     * Runs hourly — also called directly from booking cancellation paths.
     */
    public static function booking_waitlist_notify(): void {
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';

        // Find listing+date combos where a slot just opened (recently cancelled)
        // and there are still-waiting waitlist entries.
        $combos = $wpdb->get_results(
            "SELECT DISTINCT w.listing_id, w.preferred_date
             FROM {$p}booking_waitlist w
             WHERE w.status = 'waiting'
               AND EXISTS (
                 SELECT 1 FROM {$p}bookings b
                 WHERE b.listing_id = w.listing_id
                   AND b.booking_date = w.preferred_date
                   AND b.status = 'cancelled'
                   AND b.updated_at >= DATE_SUB(NOW(), INTERVAL 2 HOUR)
               )
             LIMIT 20"
        ) ?: [];

        foreach ( $combos as $combo ) {
            // Expire stale notified entries whose claim window has passed
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$p}booking_waitlist SET status='expired'
                 WHERE listing_id=%d AND preferred_date=%s
                   AND status='notified' AND claim_expires < NOW()",
                $combo->listing_id, $combo->preferred_date
            ) );

            // Already someone notified and within claim window — skip
            $active_notified = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$p}booking_waitlist
                 WHERE listing_id=%d AND preferred_date=%s AND status='notified' AND claim_expires >= NOW()",
                $combo->listing_id, $combo->preferred_date
            ) );
            if ( $active_notified ) { continue; }

            // Get next in line
            $next = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$p}booking_waitlist
                 WHERE listing_id=%d AND preferred_date=%s AND status='waiting'
                 ORDER BY created_at ASC LIMIT 1",
                $combo->listing_id, $combo->preferred_date
            ) );
            if ( ! $next ) { continue; }

            $listing = $wpdb->get_row( $wpdb->prepare(
                "SELECT id, title, slug FROM {$p}listings WHERE id=%d", (int) $combo->listing_id
            ) );
            if ( ! $listing ) { continue; } // listing deleted — skip
            $claim_expires = date( 'Y-m-d H:i:s', strtotime( '+2 hours' ) );
            $book_url      = home_url( '/' . ( $listing->slug ?? '' ) . '/' );

            // Mark notified
            $wpdb->update( "{$p}booking_waitlist", [
                'status'       => 'notified',
                'notified_at'  => current_time( 'mysql' ),
                'claim_expires'=> $claim_expires,
            ], [ 'id' => (int) $next->id ] );

            $platform = \GoodService\Core\Config::get( 'platform_name', 'GoodService' );
            $date_str = date( 'D, d M Y', strtotime( $combo->preferred_date ) );
            $msg      = "Great news! A slot opened up for {$listing->title} on {$date_str}. "
                      . "Book now — this slot is held for you for 2 hours: {$book_url}";

            // In-app notification
            $uid = (int) ( $next->user_id ?? 0 );
            if ( $uid ) {
                \GoodService\Service\NotificationService::create(
                    $uid, 'booking.waitlist_slot',
                    '🎉 Slot available!',
                    "A slot opened for {$listing->title} on {$date_str}. Book in the next 2 hours!",
                    $book_url, 'calendar', '#059669'
                );
                \GoodService\Service\NotificationService::maybe_push(
                    $uid, 'booking.waitlist_slot',
                    '🎉 Slot available!',
                    "A slot opened for {$listing->title} on {$date_str}.",
                    $book_url, 'booking.waitlist_slot'
                );
            }

            // Email
            if ( $next->customer_email ) {
                wp_mail(
                    $next->customer_email,
                    "🎉 Slot available — {$platform}",
                    "Hi {$next->customer_name},\n\n{$msg}\n\n— {$platform} Team",
                    [ 'Content-Type: text/plain; charset=UTF-8' ]
                );
            }

            // WhatsApp
            if ( $next->customer_phone ) {
                \GoodService\Service\WhatsAppService::send_text( $next->customer_phone,
                    "🎉 *{$platform}* — A slot just opened!\n\n{$msg}" );
            }

            gs_write_log( "Waitlist: notified {$next->customer_email} for listing {$combo->listing_id} on {$combo->preferred_date}", 'INFO' );
        }
    }

    /**
     * booking_reminder_cascade()
     * Fires 24h and 2h before a confirmed booking slot.
     * Sends reminder via in-app, push, and email to both vendor and customer.
     * Uses reminder_24h_sent / reminder_2h_sent flags to ensure each fires once.
     */
    private static function booking_reminder_cascade(): void {
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';

        // 24-hour reminder window: booking slot is between 23h and 25h from now.
        $rows_24h = $wpdb->get_results(
            "SELECT b.*, vp.business_name AS vendor_business_name
             FROM {$p}bookings b
             LEFT JOIN {$wpdb->prefix}gs_vendor_profiles vp ON vp.id = b.vendor_id
             WHERE b.status = 'confirmed'
               AND b.reminder_24h_sent = 0
               AND TIMESTAMP(b.booking_date, b.booking_time) BETWEEN DATE_ADD(NOW(), INTERVAL 23 HOUR)
                                                                   AND DATE_ADD(NOW(), INTERVAL 25 HOUR)"
        ) ?: [];

        foreach ( $rows_24h as $bk ) {
            self::dispatch_booking_reminder( $bk, '24h' );
            $wpdb->update( "{$p}bookings", [ 'reminder_24h_sent' => 1 ], [ 'id' => (int) $bk->id ] );
        }

        // 2-hour reminder window: booking slot is between 1h 45m and 2h 15m from now.
        $rows_2h = $wpdb->get_results(
            "SELECT b.*, vp.business_name AS vendor_business_name
             FROM {$p}bookings b
             LEFT JOIN {$wpdb->prefix}gs_vendor_profiles vp ON vp.id = b.vendor_id
             WHERE b.status = 'confirmed'
               AND b.reminder_2h_sent = 0
               AND TIMESTAMP(b.booking_date, b.booking_time) BETWEEN DATE_ADD(NOW(), INTERVAL 105 MINUTE)
                                                                  AND DATE_ADD(NOW(), INTERVAL 135 MINUTE)"
        ) ?: [];

        foreach ( $rows_2h as $bk ) {
            self::dispatch_booking_reminder( $bk, '2h' );
            $wpdb->update( "{$p}bookings", [ 'reminder_2h_sent' => 1 ], [ 'id' => (int) $bk->id ] );
        }
    }

    /** Send in-app + push + email reminder to vendor and customer for a booking. */
    private static function dispatch_booking_reminder( object $bk, string $window ): void {
        $label      = $window === '24h' ? 'tomorrow' : 'in 2 hours';
        $slot       = date( 'D, d M', strtotime( $bk->booking_date ) ) . ' at ' . date( 'g:i A', strtotime( $bk->booking_time ) );
        $title_v    = "📅 Reminder: booking {$label}";
        $body_v     = "You have a booking with {$bk->customer_name} on {$slot}. Get ready!";
        $title_c    = "📅 Your appointment is {$label}";
        $body_c     = ( $bk->vendor_business_name ?? $bk->listing_title ?? 'Your professional' ) . " will be with you on {$slot}.";
        $track_url  = home_url( '/track-job/' . $bk->tracking_token . '/' );
        $vendor_url = home_url( '/vendor/dashboard/?section=bookings' );

        $vid = (int) ( $bk->vendor_user_id ?? 0 );
        $cid = (int) ( $bk->customer_user_id ?? 0 );

        if ( $vid ) {
            \GoodService\Service\NotificationService::create(
                $vid, 'booking.reminder', $title_v, $body_v, $vendor_url, 'calendar', '#2563EB'
            );
            \GoodService\Service\NotificationService::maybe_push(
                $vid, 'booking.reminder', $title_v, $body_v, $vendor_url, 'booking.reminder'
            );
            \GoodService\Service\NotificationService::maybe_email(
                $vid, 'booking.reminder', $bk->vendor_email ?? '', 'booking_reminder_vendor',
                (array) $bk + [ 'window' => $window, 'slot' => $slot ]
            );
        }
        if ( $cid ) {
            \GoodService\Service\NotificationService::create(
                $cid, 'booking.reminder', $title_c, $body_c, $track_url, 'calendar', '#2563EB'
            );
            \GoodService\Service\NotificationService::maybe_push(
                $cid, 'booking.reminder', $title_c, $body_c, $track_url, 'booking.reminder'
            );
            \GoodService\Service\NotificationService::maybe_email(
                $cid, 'booking.reminder', $bk->customer_email ?? '', 'booking_reminder_client',
                (array) $bk + [ 'window' => $window, 'slot' => $slot ]
            );
        } elseif ( ! empty( $bk->customer_email ) ) {
            // Guest booking — no user_id, fall back to raw email
            \GoodService\Service\NotificationService::maybe_email(
                0, 'booking.reminder', $bk->customer_email, 'booking_reminder_client',
                (array) $bk + [ 'window' => $window, 'slot' => $slot ]
            );
        }

        EventBus::emit( 'booking.reminder', [
            'booking_id'  => (int) $bk->id,
            'window'      => $window,
            'vendor_id'   => (int) $bk->vendor_id,
            'customer_id' => $cid,
        ] );
        // WhatsApp reminder (fires only if BSP API configured)
        \GoodService\Service\WhatsAppService::send_booking_reminder( $bk, $window );
    }

    /**
     * booking_auto_expire()
     * Cancels bookings that are still 'pending' (vendor hasn't confirmed) and
     * have passed their auto_expire_at timestamp. Notifies the customer so they
     * know the booking didn't go through and can try a different vendor/slot.
     */
    private static function booking_auto_expire(): void {
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';

        $expired = $wpdb->get_results(
            "SELECT * FROM {$p}bookings
             WHERE status = 'pending'
               AND auto_expire_at IS NOT NULL
               AND auto_expire_at < NOW()"
        ) ?: [];

        foreach ( $expired as $bk ) {
            // Mark cancelled
            $wpdb->update( "{$p}bookings",
                [ 'status' => 'cancelled', 'updated_at' => current_time( 'mysql' ) ],
                [ 'id' => (int) $bk->id ]
            );

            // Notify customer
            $cid = (int) ( $bk->customer_user_id ?? 0 );
            $title_c = '⚠️ Booking not confirmed';
            $body_c  = 'Your booking request for ' . ( $bk->listing_title ?: 'a service' )
                     . ' on ' . date( 'D d M', strtotime( $bk->booking_date ) )
                     . ' was not confirmed by the vendor in time and has been cancelled.';
            if ( $cid ) {
                \GoodService\Service\NotificationService::create(
                    $cid, 'booking.expired', $title_c, $body_c,
                    home_url( '/my-account/?section=track' ), 'x', '#DC2626'
                );
                \GoodService\Service\NotificationService::maybe_push(
                    $cid, 'booking.expired', $title_c, $body_c,
                    home_url( '/my-account/?section=track' ), 'booking.expired'
                );
            }
            if ( ! empty( $bk->customer_email ) ) {
                \GoodService\Service\NotificationService::maybe_email(
                    $cid, 'booking.expired', $bk->customer_email, 'booking_expired_client', (array) $bk
                );
            }

            // Notify vendor (so they know a slot opened back up)
            $vid = (int) ( $bk->vendor_user_id ?? 0 );
            if ( $vid ) {
                \GoodService\Service\NotificationService::create(
                    $vid, 'booking.expired',
                    '⚠️ Booking request expired',
                    'A booking request from ' . $bk->customer_name . ' was auto-cancelled because it wasn\'t confirmed in time.',
                    home_url( '/vendor/dashboard/?section=bookings' ), 'clock', '#D97706'
                );
            }

            EventBus::emit( 'booking.expired', [ 'booking_id' => (int) $bk->id, 'vendor_id' => (int) $bk->vendor_id ] );

            if ( function_exists( 'gs_write_log' ) ) {
                gs_write_log( "Cron: auto-expired booking #{$bk->id} (vendor {$bk->vendor_id})", 'INFO' );
            }
        }
    }

    /**
     * booking_noshow_detection()
     * Detects confirmed bookings whose slot has passed (+ 90-min grace period)
     * but whose job_status never advanced beyond 'confirmed'. Marks as no_show,
     * notifies admin for manual review.
     */
    private static function booking_noshow_detection(): void {
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';

        $noshows = $wpdb->get_results(
            "SELECT * FROM {$p}bookings
             WHERE status = 'confirmed'
               AND job_status = 'confirmed'
               AND TIMESTAMP(booking_date, booking_time) < DATE_SUB(NOW(), INTERVAL 90 MINUTE)"
        ) ?: [];

        foreach ( $noshows as $bk ) {
            $wpdb->update( "{$p}bookings",
                [ 'status' => 'no_show', 'updated_at' => current_time( 'mysql' ) ],
                [ 'id' => (int) $bk->id ]
            );

            // Alert admin
            \GoodService\Service\NotificationService::notify_admins(
                'booking.noshow',
                '⚠️ Possible no-show: booking #' . $bk->id,
                'Booking #' . $bk->id . ' for ' . $bk->listing_title
                . ' (' . $bk->customer_name . ') on '
                . date( 'D d M', strtotime( $bk->booking_date ) )
                . ' was never started. Marked as no-show.',
                home_url( '/wp-admin/admin.php?page=goodservice&section=bookings&q=' . $bk->id )
            );

            EventBus::emit( 'booking.noshow', [ 'booking_id' => (int) $bk->id, 'vendor_id' => (int) $bk->vendor_id ] );
        }
    }

    /**
     * booking_stuck_job_sweep()
     * Detects bookings stuck in travelling/arrived/in_progress for > 4 hours.
     * Does NOT auto-cancel (vendor may be on a long job) — just alerts admin
     * with a force-complete / force-cancel action link.
     */
    private static function booking_stuck_job_sweep(): void {
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';

        $stuck_threshold_hours = (int) \GoodService\Core\Config::get( 'booking_stuck_hours', 4 );

        $stuck = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$p}bookings
             WHERE status = 'confirmed'
               AND job_status IN ('travelling','arrived','in_progress')
               AND updated_at < DATE_SUB(NOW(), INTERVAL %d HOUR)",
            $stuck_threshold_hours
        ) ) ?: [];

        foreach ( $stuck as $bk ) {
            \GoodService\Service\NotificationService::notify_admins(
                'booking.stuck',
                '🔧 Stuck job: booking #' . $bk->id,
                'Booking #' . $bk->id . ' (' . $bk->listing_title . ' for ' . $bk->customer_name
                . ') has been in status "' . $bk->job_status . '" for over ' . $stuck_threshold_hours . ' hours.',
                home_url( '/wp-admin/admin.php?page=goodservice&section=bookings&q=' . $bk->id )
            );
            // Don't emit BookingStuck event repeatedly — only once per booking.
            // Use a meta-option to track which booking IDs have been alerted.
            $alerted_key = 'gs_stuck_alerted_' . $bk->id;
            if ( ! get_option( $alerted_key ) ) {
                update_option( $alerted_key, 1, false );
                EventBus::emit( 'booking.stuck', [ 'booking_id' => (int) $bk->id ] );
            }
        }
    }

    /**
     * booking_post_completion()
     * After job_status = 'done', fire a review request to the customer.
     * Uses review_request_sent flag to ensure it fires exactly once per booking.
     * Runs on a 15-minute offset (waits for the cron that fires after 'done' is set).
     */
    private static function booking_post_completion(): void {
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';

        $completed = $wpdb->get_results(
            "SELECT * FROM {$p}bookings
             WHERE job_status = 'done'
               AND review_request_sent = 0
               AND completed_at IS NOT NULL
               AND completed_at < DATE_SUB(NOW(), INTERVAL 15 MINUTE)"
        ) ?: [];

        foreach ( $completed as $bk ) {
            $cid       = (int) ( $bk->customer_user_id ?? 0 );
            $track_url = home_url( '/track-job/' . $bk->tracking_token . '/?review=1' );
            $title     = '⭐ How was your experience?';
            $body      = 'Your job with ' . ( $bk->listing_title ?: 'your professional' ) . ' is complete. Leave a review — it helps others!';

            if ( $cid ) {
                \GoodService\Service\NotificationService::create(
                    $cid, 'booking.review_request', $title, $body, $track_url, 'star', '#D97706'
                );
                \GoodService\Service\NotificationService::maybe_push(
                    $cid, 'booking.review_request', $title, $body, $track_url, 'booking.review_request'
                );
            }
            if ( ! empty( $bk->customer_email ) ) {
                \GoodService\Service\NotificationService::maybe_email(
                    $cid, 'booking.review_request', $bk->customer_email, 'booking_review_request', (array) $bk
                );
            }

            $wpdb->update( "{$p}bookings", [ 'review_request_sent' => 1 ], [ 'id' => (int) $bk->id ] );
            EventBus::emit( 'booking.review_request', [ 'booking_id' => (int) $bk->id, 'customer_id' => $cid ] );
            // WhatsApp review request (fires only if BSP API configured)
            \GoodService\Service\WhatsAppService::send_job_completed( $bk );
        }
    }

    private static function check_missed_inquiries(): void {
        global $wpdb;
        $pfx = $wpdb->prefix;

        // ── 2-hour alert to vendor ─────────────────────────────────────────────
        $overdue = $wpdb->get_results(
            "SELECT l.id, l.vendor_id, l.name AS client_name, l.created_at,
                    vp.user_id AS vendor_user_id, vp.business_name,
                    li.title AS listing_title
             FROM {$pfx}gs_leads l
             JOIN {$pfx}gs_vendor_profiles vp ON vp.id = l.vendor_id
             JOIN {$pfx}gs_listings li ON li.id = l.listing_id
             WHERE l.status = 'new'
               AND l.created_at < DATE_SUB(NOW(), INTERVAL 2 HOUR)
               AND (l.missed_alert_sent IS NULL OR l.missed_alert_sent = 0)
             LIMIT 100"
        ) ?: [];

        foreach ( $overdue as $lead ) {
            \GoodService\Service\NotificationService::create(
                (int) $lead->vendor_user_id,
                'lead.overdue',
                '⏰ Inquiry needs your reply',
                "Inquiry from {$lead->client_name} for {$lead->listing_title} has been waiting over 2 hours.",
                home_url( '/vendor/dashboard/?section=leads' ),
                'clock', '#D97706'
            );

            JobQueue::push( 'send_email', [
                'to'       => get_userdata( $lead->vendor_user_id )->user_email ?? '',
                'template' => 'missed_inquiry_alert',
                'vars'     => [
                    'vendor_name'    => $lead->business_name,
                    'client_name'    => $lead->client_name,
                    'listing_title'  => $lead->listing_title,
                    'dashboard_url'  => home_url( '/vendor/dashboard/?section=leads' ),
                ],
            ] );

            $wpdb->update(
                "{$pfx}gs_leads",
                [ 'missed_alert_sent' => 1, 'missed_alert_at' => current_time( 'mysql' ) ],
                [ 'id' => $lead->id ]
            );
        }

        // ── 6-hour escalation to vendor ────────────────────────────────────────
        $escalated = $wpdb->get_results(
            "SELECT l.id, l.vendor_id, l.name AS client_name,
                    vp.user_id AS vendor_user_id, li.title AS listing_title
             FROM {$pfx}gs_leads l
             JOIN {$pfx}gs_vendor_profiles vp ON vp.id = l.vendor_id
             JOIN {$pfx}gs_listings li ON li.id = l.listing_id
             WHERE l.status = 'new'
               AND l.created_at < DATE_SUB(NOW(), INTERVAL 6 HOUR)
               AND l.missed_alert_sent = 1
               AND (l.missed_escalation_sent IS NULL OR l.missed_escalation_sent = 0)
             LIMIT 50"
        ) ?: [];

        foreach ( $escalated as $lead ) {
            \GoodService\Service\NotificationService::create(
                (int) $lead->vendor_user_id,
                'lead.escalated',
                '🚨 Urgent: Inquiry still unanswered (6h)',
                "Client may contact another provider. Reply now to keep this lead.",
                home_url( '/vendor/dashboard/?section=leads' ),
                'alert-triangle', '#DC2626'
            );
            $wpdb->update(
                "{$pfx}gs_leads",
                [ 'missed_escalation_sent' => 1 ],
                [ 'id' => $lead->id ]
            );

            // Part 5.2 — Suggest backup vendors to client if lead has client email
            self::suggest_backup_vendors( (int) $lead->id, (int) $lead->vendor_id );
        }
    }

    /**
     * ENTERPRISE-AUDIT FIX (Part 1, Critical, confirmed): "No lead
     * assignment/routing... there is no auto-assignment to a vendor rep,
     * no round-robin." A vendor CAN manually assign a lead to one of
     * their own team members (AjaxController::assignStaff(), used from
     * the vendor dashboard's inquiry inbox), but nothing did this
     * automatically — a vendor with a team of reps had every new lead
     * simply sit unassigned until someone happened to notice and hand it
     * off by hand, no different from having no team feature at all.
     *
     * Runs hourly. Load-balanced (not blind round-robin): for every
     * vendor who has at least one active, non-viewer team member, any of
     * that vendor's still-unassigned new leads are handed to whichever
     * of their staff currently holds the fewest open (new/seen/contacted)
     * assigned leads — this self-corrects if one rep has been on leave
     * and fallen behind, rather than mechanically cycling through a fixed
     * order regardless of actual workload. Vendors with no team are
     * completely unaffected — this only ever touches vendors who opted
     * into having staff at all.
     */
    private static function auto_assign_leads(): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        // Vendors with at least one active team member who can actually
        // work a lead (viewer is read-only — matches enforce_viewer_role_
        // restriction()'s own definition of who can act on anything).
        $vendors_with_staff = $wpdb->get_col(
            "SELECT DISTINCT vendor_id FROM {$pfx}vendor_staff
             WHERE is_active = 1 AND role IN ('staff','manager')"
        ) ?: [];
        if ( ! $vendors_with_staff ) { return; }

        foreach ( $vendors_with_staff as $vendor_id ) {
            $vendor_id = (int) $vendor_id;

            // This vendor's unassigned, still-fresh new leads. Bounded to
            // the last 72h so a long-idle backlog (e.g. a team member
            // deactivated weeks ago, leaving old leads stuck) doesn't get
            // silently mass-reassigned the moment staff are added back —
            // an admin/vendor working an actual backlog should do that
            // deliberately, not have this job do it for them retroactively.
            $unassigned = $wpdb->get_col( $wpdb->prepare(
                "SELECT id FROM {$pfx}leads
                 WHERE vendor_id = %d AND status = 'new'
                   AND assigned_staff_id IS NULL
                   AND created_at > DATE_SUB(NOW(), INTERVAL 72 HOUR)
                 ORDER BY created_at ASC
                 LIMIT 50",
                $vendor_id
            ) ) ?: [];
            if ( ! $unassigned ) { continue; }

            $staff = $wpdb->get_results( $wpdb->prepare(
                "SELECT s.id, s.user_id, u.display_name,
                        (SELECT COUNT(*) FROM {$pfx}leads l WHERE l.assigned_staff_id = s.id AND l.status IN ('new','seen','contacted')) AS open_count
                 FROM {$pfx}vendor_staff s
                 LEFT JOIN {$wpdb->users} u ON u.ID = s.user_id
                 WHERE s.vendor_id = %d AND s.is_active = 1 AND s.role IN ('staff','manager')",
                $vendor_id
            ) ) ?: [];
            if ( ! $staff ) { continue; }

            foreach ( $unassigned as $lead_id ) {
                // Re-sort by current open_count on every iteration — each
                // assignment made in this loop must count toward the next
                // one's load, or a burst of leads for the same vendor
                // would all land on whichever rep happened to be least
                // loaded at the START of this run instead of being spread
                // out, defeating the entire point of load-balancing.
                usort( $staff, fn( $a, $b ) => $a->open_count <=> $b->open_count );
                $pick = $staff[0];

                $updated = $wpdb->update( "{$pfx}leads",
                    [ 'assigned_staff_id' => (int) $pick->id ],
                    [ 'id' => (int) $lead_id, 'assigned_staff_id' => null ] // guard against a race with a manual assignment made after we read this list
                );
                if ( ! $updated ) { continue; }
                $pick->open_count++;

                if ( $pick->user_id ) {
                    \GoodService\Service\NotificationService::create(
                        (int) $pick->user_id, 'lead.assigned', '📋 New inquiry auto-assigned to you',
                        'A new inquiry was automatically assigned to you based on current team workload.',
                        home_url( '/vendor/dashboard/?section=leads' ), 'clipboard', '#2563EB'
                    );
                }
            }
        }
    }

    /** Part 5.2: Find alternative vendors for the same service and notify the client. */
    private static function suggest_backup_vendors( int $lead_id, int $original_vendor_id ): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $lead = $wpdb->get_row( $wpdb->prepare(
            "SELECT l.*,li.category_id,li.title AS listing_title FROM {$pfx}gs_leads l
             LEFT JOIN {$pfx}gs_listings li ON li.id=l.listing_id
             WHERE l.id=%d",
            $lead_id
        ) );
        if ( ! $lead || empty( $lead->email ) ) { return; }

        // Already sent backup suggestion
        if ( $lead->client_backup_sent ) { return; }

        $alternatives = $wpdb->get_results( $wpdb->prepare(
            "SELECT vp.business_name, li.slug, li.avg_rating, vp.response_rate, vp.city
             FROM {$pfx}gs_vendor_profiles vp
             JOIN {$pfx}gs_listings li ON li.vendor_id=vp.id
             WHERE li.status='active' AND li.category_id=%d
               AND vp.id != %d AND vp.is_active=1
             ORDER BY vp.trust_score DESC LIMIT 3",
            (int) $lead->category_id, $original_vendor_id
        ) ) ?: [];

        if ( empty( $alternatives ) ) { return; }

        $links_html = '';
        foreach ( $alternatives as $alt ) {
            $links_html .= '<li style="margin-bottom:8px"><strong>'
                .esc_html($alt->business_name).'</strong>'
                .($alt->avg_rating>0?' ★'.number_format((float)$alt->avg_rating,1):'')
                .' — <a href="'.home_url('\/'.$alt->slug.'').'" style="color:#2563EB">View profile</a></li>';
        }

        \GoodService\Service\EmailService::send( $lead->email, 'inquiry_confirmed_client', [
            'client_name'  => $lead->name,
            'vendor_name'  => 'other verified vendors',
            'service'      => $lead->listing_title ?? $lead->inquiry_module,
            'reply_time'   => 'soon',
            'dashboard_url'=> home_url( '/customer/dashboard/' ),
            'inquiry_ref'  => 'INQ-'.str_pad($lead_id, 5, '0', STR_PAD_LEFT),
        ] );

        $wpdb->update(
            "{$pfx}gs_leads",
            [ 'client_backup_sent' => 1 ],
            [ 'id' => $lead_id ]
        );
    }


    // =========================================================================
    // Part 12.1 — Daily Trust Score Computation
    // =========================================================================
    private static function update_trust_scores(): void {
        global $wpdb;
        $pfx     = $wpdb->prefix . 'gs_';
        $vendors = $wpdb->get_col( "SELECT id FROM {$pfx}vendor_profiles WHERE is_active=1" ) ?: [];

        foreach ( $vendors as $vid ) {
            $vid = (int) $vid;
            $stats = $wpdb->get_row( $wpdb->prepare(
                "SELECT COUNT(*) AS total,
                        SUM(replied_at IS NOT NULL) AS replied,
                        AVG(CASE WHEN replied_at IS NOT NULL
                            THEN TIMESTAMPDIFF(MINUTE, created_at, replied_at) END) AS avg_min,
                        SUM(status='converted') AS converted
                 FROM {$pfx}leads
                 WHERE vendor_id=%d AND created_at > DATE_SUB(NOW(), INTERVAL 90 DAY)
                   AND status != 'junk'",
                $vid
            ) );

            $response_rate = $stats && $stats->total > 0
                ? round( ( $stats->replied / $stats->total ) * 100, 1 ) : 0;
            $avg_min       = (int) ( $stats->avg_min ?? 999 );
            $jobs_done     = (int) ( $stats->converted ?? 0 );

            $review_avg = (float) $wpdb->get_var( $wpdb->prepare(
                "SELECT AVG(rating) FROM {$pfx}reviews WHERE vendor_id=%d AND status='approved'", $vid
            ) );

            // Formula: 40% response rate + 30% reply speed + 20% review score + 10% jobs done
            // Real feature — verification bonus added: up to 2 extra
            // points for a fully-verified vendor, reconciling this
            // formula with VerificationService's own verification_levels
            // count rather than that service writing a second,
            // conflicting value to this same column.
            $speed_score = max( 0, min( 10, 10 - ( $avg_min / 60 ) ) );
            $verification_levels = (int) ( $wpdb->get_var( $wpdb->prepare(
                "SELECT verification_levels FROM {$pfx}vendor_profiles WHERE id = %d", $vid
            ) ) ?? 0 );
            $verification_bonus = min( 2, $verification_levels / 4 ); // 8 levels max → up to 2 bonus points
            $trust       = ( $response_rate / 100 * 40 )
                         + ( $speed_score * 3 )
                         + ( $review_avg * 4 )
                         + min( 10, $jobs_done / 5 )
                         + $verification_bonus;

            $wpdb->update( $wpdb->prefix . 'gs_vendor_profiles', [
                'response_rate'      => $response_rate,
                'avg_reply_minutes'  => $avg_min === 999 ? 0 : $avg_min,
                'total_jobs_done'    => $jobs_done,
                'trust_score'        => round( $trust, 2 ),
                'trust_score_updated'=> current_time( 'mysql' ),
            ], [ 'id' => $vid ] );

            // Real feature — SLA enforcement, the actual confirmed gap:
            // response rate and reply speed were already tracked and fed
            // into search ranking (a soft, continuous consequence), but
            // nothing ever fired an explicit consequence when a vendor's
            // metrics fell below an acceptable threshold. Reuses the
            // existing risk_events queue (built for fraud detection)
            // rather than creating a second, parallel "things an admin
            // should look at" system — an SLA breach and a fraud signal
            // are both, at the infrastructure level, the same kind of
            // thing: a reviewable flag on a vendor.
            if ( $stats && $stats->total >= 5 ) { // real validation rule: don't flag a vendor on a tiny sample size
                $sla_response_threshold = (int) \GoodService\Core\Config::get( 'sla_min_response_rate', 50 );
                $sla_reply_threshold    = (int) \GoodService\Core\Config::get( 'sla_max_reply_minutes', 240 );

                if ( $response_rate < $sla_response_threshold ) {
                    self::maybe_flag_sla_breach( $vid, 'sla_low_response_rate', 'medium',
                        "Response rate {$response_rate}% is below the {$sla_response_threshold}% threshold (last 90 days, {$stats->total} leads)." );
                }
                if ( $avg_min !== 999 && $avg_min > $sla_reply_threshold ) {
                    self::maybe_flag_sla_breach( $vid, 'sla_slow_replies', 'medium',
                        "Average reply time of {$avg_min} minutes exceeds the {$sla_reply_threshold}-minute threshold." );
                }
            }
        }

        // Real fix — this loop writes response_rate/avg_reply_minutes/
        // total_jobs_done/trust_score directly via $wpdb->update() for every
        // active vendor, bypassing VendorRepository's cache entirely. Before
        // this fix, vendor:id:{id} (600s TTL) and vendor:user:{uid} (60s TTL)
        // kept serving yesterday's scorecard numbers to vendors' own
        // dashboards and anywhere else a cached profile is read, for up to
        // 10 minutes after every daily run. One flush after the loop (not
        // per vendor) bumps the whole "vendor" group in a single write.
        if ( ! empty( $vendors ) ) {
            \GoodService\Core\Cache::flush_group( 'vendor' );
        }

        // Part 12.2: Neighbourhood count (weekly via daily cron)
        if ( (int) date('N' ) === 1 ) { // Monday only
            self::update_neighbourhood_counts();
        }
    }

    /**
     * Real feature — SLA breach flagging with duplicate prevention. This
     * cron runs daily; without checking for an existing unreviewed
     * breach of the SAME signal for the SAME vendor first, an ongoing
     * SLA issue would flood the admin risk queue with a fresh row every
     * single day instead of surfacing once per genuine occurrence.
     */
    private static function maybe_flag_sla_breach( int $vendor_id, string $signal, string $severity, string $details ): void {
        global $wpdb;
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_risk_events
             WHERE subject_type = 'vendor' AND subject_id = %d AND signal = %s AND reviewed = 0",
            $vendor_id, $signal
        ) );
        if ( $existing ) { return; } // already flagged and awaiting admin review — don't duplicate

        \GoodService\Service\FraudDetectionService::record( 'vendor', $vendor_id, $signal, $severity, $details, '' );

        // Real feature — notify the vendor directly, giving them a
        // chance to improve before any escalating consequence, rather
        // than only surfacing this in an admin queue they can't see.
        $vendor_user_id = $wpdb->get_var( $wpdb->prepare( "SELECT user_id FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $vendor_id ) );
        if ( $vendor_user_id ) {
            \GoodService\Service\NotificationService::create(
                (int) $vendor_user_id, 'sla.breach', '⚠️ Response Performance Alert',
                $details . ' This affects your visibility in search results — faster responses help you rank higher.',
                home_url( '/vendor/dashboard/?section=leads' ), 'alert-triangle', '#D97706'
            );
        }
    }

    /**
     * FIXED — Known Limitations audit: proactive counterpart to
     * ListingRepository::save()'s reactive missing-column detection. Reuses
     * the exact same {$p}listings column list Schema::upgrade_columns()
     * itself installs (kept as a small local copy here rather than a shared
     * dependency, since Schema::upgrade_columns() runs its ALTER TABLE calls
     * inline rather than returning its column list as data) so drift is
     * caught on a schedule, not only after a vendor's edit has already been
     * silently dropped.
     */
    private static function check_missing_listing_columns(): void {
        global $wpdb;
        $pfx   = $wpdb->prefix . 'gs_';
        $table = $pfx . 'listings';
        $expected = [
            'seo_title', 'seo_desc', 'seo_keywords', 'seo_focus_keyword', 'og_image',
            'seo_robots', 'map_embed', 'address', 'location_id', 'country',
            'location_name', 'ranking_score', 'listing_uid', 'swiper_enabled', 'swiper_settings',
        ];
        $actual_cols = $wpdb->get_col( "SHOW COLUMNS FROM `{$table}`", 0 ) ?: [];
        $missing = array_values( array_diff( $expected, $actual_cols ) );
        if ( $missing ) {
            gs_write_log( '[cron:check_missing_listing_columns] Proactively detected missing columns on '
                . $table . ': ' . implode( ', ', $missing ) . ' — run Admin › Tools › DB Upgrade', 'ERROR' );
            // id=0 distinguishes "found by the proactive daily scan" from a
            // specific vendor's save (which always records a real listing id),
            // so the Admin Tools banner's "Listing ID: 0" reads unambiguously
            // as "no single listing triggered this — a scan found it."
            update_option( 'gs_missing_cols_warning', [
                'cols' => $missing, 'id' => 0, 'time' => current_time( 'mysql' ),
            ] );
        }
    }

    /**
     * ENTERPRISE-AUDIT FIX (Part 1, High — trash/restore, 30-day retention).
     * Permanently removes any listing that has sat in Trash (status=
     * 'deleted') for 30+ days, along with its reviews/leads/saved-listing
     * rows — identical cleanup to AjaxController::adminPurgeListing()'s
     * manual "Delete Forever" action, just triggered by age instead of an
     * admin click. Runs in small batches so a large trash backlog (e.g.
     * right after this feature first ships, if bulk-deletes had
     * accumulated) can't turn one daily cron run into a long-running query.
     */
    private static function purge_old_trashed_listings(): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        $ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT id FROM {$pfx}listings
             WHERE status = 'deleted' AND deleted_at IS NOT NULL AND deleted_at < DATE_SUB(NOW(), INTERVAL 30 DAY)
             LIMIT 200"
        ) );
        if ( ! $ids ) { return; }
        foreach ( $ids as $id ) {
            $id = (int) $id;
            $wpdb->delete( $pfx . 'reviews',        [ 'listing_id' => $id ] );
            $wpdb->delete( $pfx . 'leads',          [ 'listing_id' => $id ] );
            $wpdb->delete( $pfx . 'saved_listings', [ 'listing_id' => $id ] );
            $wpdb->delete( $pfx . 'listings',       [ 'id' => $id ] );
            \GoodService\Core\Cache::delete( "listing:id:{$id}" );
        }
        \GoodService\Core\Cache::flush_group( 'listings' );
        gs_write_log( 'Cron: purge_old_trashed_listings permanently removed ' . count( $ids ) . ' listing(s) past the 30-day trash retention window.' );
    }

    /**
     * ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "No SLA/escalation
     * tracking on complaints or disputes — status/priority fields only, no
     * due-date, auto-escalation, or assignee"). Assignee already existed
     * (assigned_to, wired into the admin detail view by an earlier session);
     * this is the missing due-date + auto-escalation half.
     *
     * Runs hourly. Finds still-open complaints whose sla_due_at has passed
     * and that have never been auto-escalated before (escalated_at IS NULL —
     * a one-shot bump, not a repeated nag every hour the breach continues),
     * bumps priority one tier via the same shared map used at submission
     * time (Helpers::complaint_escalated_priority()), sets escalated_at, and
     * gives the complaint a fresh due date at the new (shorter) SLA window
     * so a 'critical' escalation is followed up on quickly rather than
     * silently sitting overdue forever. Notifies admins once per complaint
     * via the new complaint.escalated event (respects the per-event
     * in-app/email toggles built for the admin-alerting screen).
     */
    private static function escalate_overdue_complaints(): void {
        global $wpdb;
        $pfx  = $wpdb->prefix . 'gs_';
        $rows = $wpdb->get_results(
            "SELECT id, complaint_number, priority, subject FROM {$pfx}complaints
             WHERE status IN ('open','in_review')
               AND sla_due_at IS NOT NULL AND sla_due_at < NOW()
               AND escalated_at IS NULL
             LIMIT 200"
        );
        if ( ! $rows ) { return; }
        foreach ( $rows as $c ) {
            $new_priority = \GoodService\Core\Helpers::complaint_escalated_priority( $c->priority );
            $new_due_at   = date( 'Y-m-d H:i:s', time() + ( \GoodService\Core\Helpers::complaint_sla_hours( $new_priority ) * HOUR_IN_SECONDS ) );
            $wpdb->update( $pfx . 'complaints', [
                'priority'     => $new_priority,
                'sla_due_at'   => $new_due_at,
                'escalated_at' => current_time( 'mysql' ),
                'updated_at'   => current_time( 'mysql' ),
            ], [ 'id' => (int) $c->id ] );
            \GoodService\Core\Helpers::notify_admins(
                'complaint.escalated',
                '⏰ Complaint SLA breached: ' . $c->complaint_number,
                'Complaint ' . $c->complaint_number . ' ("' . $c->subject . '") missed its response window and was auto-escalated from ' . ucfirst( $c->priority ) . ' to ' . ucfirst( $new_priority ) . '.',
                home_url( '/admin-panel/?section=complaints&view=' . (int) $c->id )
            );
        }
        gs_write_log( 'Cron: escalate_overdue_complaints auto-escalated ' . count( $rows ) . ' overdue complaint(s).' );
    }

    private static function update_neighbourhood_counts(): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        $vendors = $wpdb->get_col( "SELECT id FROM {$pfx}vendor_profiles WHERE is_active=1" ) ?: [];
        foreach ( $vendors as $vid ) {
            $vid = (int) $vid;
            $area = $wpdb->get_row( $wpdb->prepare(
                "SELECT city, COUNT(DISTINCT phone) AS cnt
                 FROM {$pfx}leads WHERE vendor_id=%d AND status='converted' AND city != ''
                 GROUP BY city ORDER BY cnt DESC LIMIT 1",
                $vid
            ) );
            if ( $area ) {
                $wpdb->update( $wpdb->prefix . 'gs_vendor_profiles', [
                    'neighbourhood_count' => (int) $area->cnt,
                    'neighbourhood_area'  => sanitize_text_field( $area->city ),
                ], [ 'id' => $vid ] );
            }
        }
    }


    // =========================================================================
    // Part 22.3 — Demand Signals
    // =========================================================================
    private static function compute_demand_signals(): void {
        global $wpdb;
        $pfx   = $wpdb->prefix . 'gs_';
        $month = (int) date( 'n' );
        $year  = (int) date( 'Y' );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT inquiry_module AS cat, city, COUNT(*) AS cnt
             FROM {$pfx}leads
             WHERE YEAR(created_at)=%d AND MONTH(created_at)=%d AND inquiry_module!='' AND city!=''
             GROUP BY inquiry_module, city",
            $year, $month
        ) ) ?: [];

        foreach ( $rows as $row ) {
            // YoY change
            $last_year = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$pfx}leads
                 WHERE inquiry_module=%s AND city=%s
                   AND YEAR(created_at)=%d AND MONTH(created_at)=%d",
                $row->cat, $row->city, $year - 1, $month
            ) );
            $yoy = $last_year > 0 ? round( ( $row->cnt - $last_year ) / $last_year * 100, 2 ) : 0;

            $wpdb->replace( $wpdb->prefix . 'gs_demand_signals', [
                'category'      => $row->cat,
                'city'          => $row->city,
                'month_num'     => $month,
                'year_num'      => $year,
                'inquiry_count' => (int) $row->cnt,
                'yoy_change'    => $yoy,
                'created_at'    => current_time( 'mysql' ),
            ] );
        }
    }

    // =========================================================================
    // Part 26.1 — SEO Location Pages Generator
    // =========================================================================
    private static function generate_seo_location_pages(): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $combos = $wpdb->get_results(
            "SELECT c.slug AS cat_slug, l.city, COUNT(l.id) AS vendor_count
             FROM {$pfx}listings l
             JOIN {$pfx}categories c ON c.id=l.category_id
             WHERE l.status='active' AND l.city!=''
             GROUP BY c.slug, l.city HAVING vendor_count>=3
             ORDER BY vendor_count DESC LIMIT 500"
        ) ?: [];

        foreach ( $combos as $combo ) {
            $cat_label = ucwords( str_replace( ['_','-'], ' ', $combo->cat_slug ) );
            $city      = $combo->city;
            $page_url  = '/service/' . $combo->cat_slug . '/' . sanitize_title( $city ) . '/';

            $wpdb->replace( $wpdb->prefix . 'gs_seo_location_pages', [
                'category_slug' => $combo->cat_slug,
                'city'          => $city,
                'page_url'      => $page_url,
                'vendor_count'  => (int) $combo->vendor_count,
                'h1_text'       => "Best {$cat_label} in {$city} — Verified & Trusted",
                'meta_desc'     => "Find the best {$cat_label} in {$city}. Compare " . $combo->vendor_count . "+ verified professionals, read reviews, and get free quotes.",
                'last_updated'  => current_time( 'mysql' ),
            ] );
        }
        gs_write_log( '[Cron] SEO pages regenerated: ' . count( $combos ) . ' combinations', 'INFO' );
    }


    // =========================================================================
    // Monthly Cron Jobs
    // =========================================================================

    public static function monthly(): void {
        $lock_key = 'gs_cron_monthly_lock';
        if ( ! set_transient( $lock_key, 1, 60 * MINUTE_IN_SECONDS ) ) {
            return;
        }
        self::compute_demand_signals();
        \GoodService\Service\ProfitIntelligenceService::compute_monthly_benchmarks();
        self::generate_seo_location_pages();
        \GoodService\Service\VendorScorecardService::send_monthly_scorecards();
        delete_transient( $lock_key );
    }


    // ── Part 16.3 — Auto-generate leads for subscription service dates ────────
    private static function trigger_subscription_inquiries(): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$pfx}service_subscriptions'" ) ) { return; }
        $subs = $wpdb->get_results(
            "SELECT ss.*, sp.category_slug, sp.name AS plan_name, sp.vendor_id, sp.listing_id,
                    vp.user_id AS vendor_user_id,
                    u.display_name AS client_name, u.user_email AS client_email,
                    um.meta_value AS client_phone
             FROM {$pfx}service_subscriptions ss
             JOIN {$pfx}service_plans sp ON sp.id = ss.plan_id
             LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = sp.vendor_id
             JOIN {$wpdb->prefix}users u ON u.ID = ss.client_user_id
             LEFT JOIN {$wpdb->prefix}usermeta um ON um.user_id = u.ID AND um.meta_key = 'gs_phone'
             WHERE ss.status = 'active' AND ss.next_service_date = CURDATE()"
        ) ?: [];
        foreach ( $subs as $sub ) {
            // Real gap fix: customer_user_id was never set on this auto-generated
            // lead — the exact same bug found and fixed in submitInquiry() earlier.
            // ss.client_user_id is already available from the query's own JOIN
            // (used to fetch client_name/client_email) but was never written here,
            // meaning every recurring-service inquiry was permanently invisible in
            // the customer's own /my-account/?section=inquiries dashboard, and
            // would always show "Verification Pending" regardless of whether the
            // customer had actually verified their account.
            $sub_email_verified = (int) get_user_meta( (int) $sub->client_user_id, 'gs_account_email_verified', true );
            $sub_phone_verified = (int) get_user_meta( (int) $sub->client_user_id, 'gs_account_phone_verified', true );
            $wpdb->insert( "{$pfx}leads", [
                'vendor_id'        => $sub->vendor_id,
                'listing_id'       => $sub->listing_id,
                'customer_user_id' => (int) $sub->client_user_id,
                'name'             => $sub->client_name,
                'email'            => $sub->client_email,
                'phone'            => $sub->client_phone ?? '',
                'email_verified'   => $sub_email_verified,
                'phone_verified'   => $sub_phone_verified,
                'message'          => "Recurring service due: {$sub->plan_name}",
                'inquiry_module'   => $sub->category_slug,
                'source'           => 'subscription',
                // Real fix — confirmed gap: ties this auto-generated lead back
                // to the plan that produced it, so the Service Plans screen can
                // show a real per-plan "auto-generated inquiries" count and a
                // working filtered link, instead of no correlation at all.
                'service_plan_id'  => (int) $sub->plan_id,
                'status'           => 'new',
                'created_at'       => current_time( 'mysql' ),
            ] );
            // Real gap fix: no notification at all after this auto-generated lead —
            // same missing-signal pattern found and fixed elsewhere this session
            // (verification docs, complaints). A vendor with an active recurring
            // service subscription would only discover the new lead by manually
            // checking their inbox, with zero proactive signal.
            if ( $sub->vendor_user_id ) {
                \GoodService\Service\NotificationService::create(
                    (int) $sub->vendor_user_id, 'lead.recurring_service', '🔄 Recurring Service Due',
                    'A recurring service inquiry was created: ' . $sub->plan_name . ' for ' . $sub->client_name,
                    home_url( '/vendor/dashboard/?section=leads' ), 'refresh-cw', '#2563EB'
                );
            }
            $dt = new \DateTime( $sub->next_service_date );
            match( $sub->frequency ?? 'monthly' ) {
                'weekly'    => $dt->modify( '+1 week' ),
                'quarterly' => $dt->modify( '+3 months' ),
                'biannual'  => $dt->modify( '+6 months' ),
                'annual'    => $dt->modify( '+1 year' ),
                default     => $dt->modify( '+1 month' ),
            };
            $wpdb->update( "{$pfx}service_subscriptions",
                [ 'next_service_date' => $dt->format( 'Y-m-d' ) ],
                [ 'id' => $sub->id ]
            );
        }
    }

    /**
     * ENTERPRISE-AUDIT FIX (Part 2, High): "No automatic dunning/retry cascade
     * for failed recurring payments — the payment.failed webhook handler
     * sends one notification only, with no retry schedule, grace period, or
     * card-update dunning sequence." SubscriptionService::start_or_touch_
     * dunning() (called from the payment.failed webhook handlers) starts the
     * grace period; this runs daily and does the actual cascade:
     *
     *   dunning_stage 1 → past the halfway point of the grace period with no
     *                     resolution: send reminder #1, advance to stage 2.
     *   dunning_stage 2 → past 80% of the grace period: send reminder #2
     *                     ("final notice"), advance to stage 3.
     *   grace_until has fully passed, still unresolved: cancel the row and
     *   auto-downgrade to Free — the exact same shared downgrade_to_free()
     *   path check_trial_endings() below uses, so a vendor who never resolves
     *   a failed payment ends up in the identical, correctly-notified state
     *   as one whose trial or paid term simply ran out.
     *
     * A subscription's dunning fields are only ever set while it stays
     * status='active' (see start_or_touch_dunning()); the moment a real
     * successful payment arrives, activate_subscription() cancels this row
     * and inserts a fresh one with dunning_stage=0 by default — so a
     * resolved payment silently exits the cascade with no extra code needed
     * here to "clear" it.
     */
    private static function payment_dunning_cascade(): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        $in_dunning = $wpdb->get_results(
            "SELECT s.id, s.vendor_id, s.plan_name, s.dunning_stage, s.dunning_started_at, s.dunning_grace_until,
                    vp.user_id AS vendor_user_id, vp.business_name
             FROM {$pfx}subscriptions s
             JOIN {$pfx}vendor_profiles vp ON vp.id = s.vendor_id
             WHERE s.status = 'active' AND s.dunning_stage > 0"
        ) ?: [];
        if ( ! $in_dunning ) { return; }

        foreach ( $in_dunning as $sub ) {
            $grace_started = strtotime( (string) $sub->dunning_started_at );
            $grace_ends    = strtotime( (string) $sub->dunning_grace_until );
            if ( ! $grace_started || ! $grace_ends || $grace_ends <= $grace_started ) { continue; }
            $total_span = $grace_ends - $grace_started;
            $remaining  = $grace_ends - time();

            if ( $remaining <= 0 ) {
                // Grace period fully expired, still unresolved — cancel this
                // row and downgrade, mirroring check_trial_endings()'s own
                // "mark the row terminal, THEN route through the shared
                // downgrade path" sequence exactly.
                $wpdb->update( "{$pfx}subscriptions",
                    [ 'status' => 'cancelled', 'cancel_reason' => 'payment_dunning_expired', 'cancelled_at' => current_time( 'mysql' ), 'updated_at' => current_time( 'mysql' ) ],
                    [ 'id' => (int) $sub->id ]
                );
                \GoodService\Service\SubscriptionService::downgrade_to_free( (int) $sub->vendor_id, (int) $sub->vendor_user_id, 'payment_dunning_expired' );
                EventBus::emit( 'subscription.expired', [ 'vendor_id' => (int) $sub->vendor_id, 'user_id' => (int) $sub->vendor_user_id ] );
                $vars = [
                    'vendor_name' => $sub->business_name ?: 'there',
                    'plan_name'   => $sub->plan_name ?: 'your',
                    'failed_since'=> date( 'd M Y', $grace_started ),
                ];
                \GoodService\Service\NotificationService::create(
                    (int) $sub->vendor_user_id, 'subscription.downgraded_dunning',
                    '⚠️ Plan Cancelled — Payment Not Resolved',
                    'Your ' . ( $sub->plan_name ?: '' ) . ' plan was cancelled because payment could not be collected. You are now on the free plan.',
                    home_url( '/vendor/dashboard/?section=plans' ), 'alert-triangle', '#DC2626'
                );
                $notify_email = gs_vendor_site_email( (int) $sub->vendor_id );
                if ( $notify_email ) {
                    \GoodService\Service\EmailService::send( $notify_email, 'subscription_downgraded_dunning', $vars );
                }
                \GoodService\Service\NotificationService::notify_admins(
                    'subscription.downgraded_dunning', '⚠️ Vendor Auto-Downgraded (Payment Dunning Expired)',
                    ( $sub->business_name ?: 'A vendor' ) . "'s {$sub->plan_name} plan was cancelled — payment failing since " . date( 'd M Y', $grace_started ) . ", could not be collected despite reminders.",
                    home_url( '/admin-panel/?section=transactions' )
                );
                continue;
            }

            $elapsed_fraction = 1 - ( $remaining / $total_span );
            $days_left        = max( 1, (int) ceil( $remaining / DAY_IN_SECONDS ) );
            $next_stage       = null;
            if ( (int) $sub->dunning_stage === 1 && $elapsed_fraction >= 0.5 ) {
                $next_stage = 2;
            } elseif ( (int) $sub->dunning_stage === 2 && $elapsed_fraction >= 0.8 ) {
                $next_stage = 3;
            }
            if ( $next_stage === null ) { continue; } // not yet at the next checkpoint

            $wpdb->update( "{$pfx}subscriptions", [ 'dunning_stage' => $next_stage ], [ 'id' => (int) $sub->id ] );
            \GoodService\Service\NotificationService::create(
                (int) $sub->vendor_user_id, 'payment.dunning_reminder',
                '⏰ Payment Still Failing', "We still can't process your subscription payment — {$days_left} day(s) left before your plan is downgraded.",
                home_url( '/vendor/dashboard/?section=subscription' ), 'alert-triangle', '#D97706'
            );
            $notify_email = gs_vendor_site_email( (int) $sub->vendor_id );
            if ( $notify_email ) {
                \GoodService\Service\EmailService::send( $notify_email, 'payment_dunning_reminder', [
                    'vendor_name'  => $sub->business_name ?: 'there',
                    'plan_name'    => $sub->plan_name ?: 'your',
                    'failed_since' => date( 'd M Y', $grace_started ),
                    'days_left'    => $days_left,
                ] );
            }
        }
    }

    // ── Part 24.3 — Notify vendors 4 days before trial end ───────────────────
    private static function check_trial_endings(): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        $trials = $wpdb->get_results(
            "SELECT s.vendor_id, vp.user_id AS vendor_user_id, vp.business_name, u.user_email
             FROM {$pfx}subscriptions s
             JOIN {$pfx}vendor_profiles vp ON vp.id = s.vendor_id
             JOIN {$wpdb->prefix}users u ON u.ID = vp.user_id
             WHERE s.status = 'trialing'
               AND DATE(s.trial_ends_at) = DATE_ADD(CURDATE(), INTERVAL 4 DAY)"
        ) ?: [];
        foreach ( $trials as $trial ) {
            if ( get_user_meta( (int) $trial->vendor_user_id, 'gs_trial_ending_notified', true ) ) { continue; }
            \GoodService\Service\NotificationService::on_trial_ending( [
                'vendor_user_id' => (int) $trial->vendor_user_id,
                'vendor_name'    => $trial->business_name,
                'vendor_email'   => $trial->user_email,
                'days_left'      => 4,
                'dashboard_url'  => home_url( '/vendor/dashboard/' ),
            ] );
            update_user_meta( (int) $trial->vendor_user_id, 'gs_trial_ending_notified', 1 );
        }
        // Expire finished trials.
        //
        // Root-cause fix — confirmed gap from full subscription-lifecycle audit:
        // this raw UPDATE previously only flipped the row's status column, with
        // NO downstream side effects — unlike SubscriptionService::expire_batch()'s
        // equivalent expires_at-based hourly path, which downgrades the vendor to
        // the Free plan (SubscriptionService::downgrade_to_free()) and emits
        // 'subscription.expired' so both the vendor and admin are notified.
        // That asymmetry meant: a trial that expired via trial_ends_at here (rather
        // than via expires_at in the hourly job) would show status='expired' in the
        // DB while the vendor's actual plan access, dashboard state, and feature
        // gates never updated, and nobody was ever notified of the lapse.
        //
        // Fixed by selecting the affected rows first and routing every one of them
        // through the exact same shared downgrade_to_free()/EventBus::emit() path
        // expire_batch() uses — guaranteeing identical behavior regardless of which
        // of the two expiry mechanisms actually catches a given trial. This also
        // makes the fix independent of AjaxController::markOnboardingDone()'s
        // separate expires_at fix above: even if some future trial-creation path
        // reintroduces the same expires_at gap, this path now has full parity.
        $ending = $wpdb->get_results(
            "SELECT s.id, s.vendor_id, vp.user_id
             FROM {$pfx}subscriptions s
             JOIN {$pfx}vendor_profiles vp ON vp.id = s.vendor_id
             WHERE s.status = 'trialing' AND s.trial_ends_at < NOW()"
        ) ?: [];
        if ( $ending ) {
            $ids = array_map( fn( $r ) => (int) $r->id, $ending );
            $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$pfx}subscriptions SET status='expired', updated_at=NOW() WHERE id IN ({$placeholders})",
                ...$ids
            ) );
            foreach ( $ending as $row ) {
                \GoodService\Service\SubscriptionService::downgrade_to_free( (int) $row->vendor_id, (int) $row->user_id, 'trial_ended' );
                EventBus::emit( 'subscription.expired', [ 'vendor_id' => (int) $row->vendor_id, 'user_id' => (int) $row->user_id ] );
            }
        }
    }

    // =========================================================================
    // Manual Subscription & Offline Payment system — scheduled activation & reminders
    // =========================================================================

    /**
     * activate_scheduled_manual_plans()
     * Picks up admin-assigned plan requests created with "schedule future activation"
     * (status='on_hold', has an activation_date) whose activation_date has arrived,
     * and activates them. Mirrors ManualPlanService::activate() exactly — calling the
     * service method (not duplicating its SQL) so there is one single activation path.
     */
    private static function activate_scheduled_manual_plans(): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$pfx}plan_requests'" ) ) { return; }

        $due = $wpdb->get_col(
            "SELECT id FROM {$pfx}plan_requests
             WHERE status = 'on_hold' AND source = 'admin_assigned'
               AND activation_date IS NOT NULL AND activation_date <= NOW()
             LIMIT 100"
        ) ?: [];

        foreach ( $due as $request_id ) {
            $request_id = (int) $request_id;
            // approved_by was set to the original assigning admin at creation time —
            // reuse it here since this is an automated continuation of that admin's action,
            // not a new approval decision by a different actor.
            $assigned_by = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT assigned_by FROM {$pfx}plan_requests WHERE id = %d", $request_id
            ) );
            // Move to 'approved' first (activate() doesn't itself transition on_hold→approved;
            // it only links the subscription and sets 'completed' on success).
            $wpdb->update( "{$pfx}plan_requests", [ 'status' => 'approved', 'updated_at' => current_time( 'mysql' ) ], [ 'id' => $request_id ] );
            $sub_id = \GoodService\Service\ManualPlanService::activate( $request_id, $assigned_by ?: 0 );
            if ( $sub_id === false ) {
                gs_write_log( "Cron: scheduled manual plan activation failed for request #{$request_id}: " . \GoodService\Service\ManualPlanService::$last_error, 'ERROR' );
                // Revert to on_hold so it's retried tomorrow rather than stuck silently as 'approved'.
                $wpdb->update( "{$pfx}plan_requests", [ 'status' => 'on_hold' ], [ 'id' => $request_id ] );
                \GoodService\Service\NotificationService::notify_admins(
                    'plan_request.scheduled_activation_failed',
                    '⚠️ Scheduled plan activation failed',
                    'Request #' . $request_id . ' was due to activate today but activation failed. It will retry tomorrow — check it manually if this repeats.',
                    home_url( '/admin-panel/?section=plan-requests' )
                );
            }
        }
    }

    /**
     * manual_plan_renewal_reminders()
     * Sends a "your plan expires soon" reminder for subscriptions that were activated
     * via the manual/offline path (gateway='manual_offline'), at 7 and 1 day(s) before
     * expiry. Uses user meta flags (same pattern as gs_trial_ending_notified) so each
     * reminder fires exactly once per subscription per window.
     */
    private static function manual_plan_renewal_reminders(): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$pfx}subscriptions'" ) ) { return; }

        foreach ( [ 7, 1 ] as $days_left ) {
            $expiring = $wpdb->get_results( $wpdb->prepare(
                "SELECT s.id, s.vendor_id, s.plan_name, s.expires_at, vp.user_id AS vendor_user_id, u.user_email
                 FROM {$pfx}subscriptions s
                 JOIN {$pfx}vendor_profiles vp ON vp.id = s.vendor_id
                 JOIN {$wpdb->prefix}users u ON u.ID = vp.user_id
                 WHERE s.status = 'active' AND s.gateway = 'manual_offline'
                   AND s.expires_at IS NOT NULL
                   AND DATE(s.expires_at) = DATE_ADD(CURDATE(), INTERVAL %d DAY)",
                $days_left
            ) ) ?: [];

            foreach ( $expiring as $sub ) {
                $meta_key = 'gs_manual_renewal_notified_' . $sub->id . '_' . $days_left;
                if ( get_user_meta( (int) $sub->vendor_user_id, $meta_key, true ) ) { continue; }

                \GoodService\Service\NotificationService::create(
                    (int) $sub->vendor_user_id, 'plan_request.renewal_reminder',
                    '⏰ Plan Expires in ' . $days_left . ' Day' . ( $days_left > 1 ? 's' : '' ),
                    'Your "' . $sub->plan_name . '" plan expires on ' . date( 'd M Y', strtotime( $sub->expires_at ) ) . '. Submit a renewal request to keep your features.',
                    home_url( '/vendor/dashboard/?section=subscription' ), 'clock', '#D97706'
                );
                if ( ! empty( $sub->user_email ) ) {
                    \GoodService\Service\EmailService::send( $sub->user_email, 'plan_request_renewal_reminder', [
                        'plan_name'  => $sub->plan_name,
                        'expires_at' => date( 'd M Y', strtotime( $sub->expires_at ) ),
                    ] );
                }
                update_user_meta( (int) $sub->vendor_user_id, $meta_key, 1 );
            }
        }
    }

    // FIX (enterprise hardening pass): closes the Demand Map's hardcoded-city-list
    // limitation at the root — see GeoCodingService for the full design writeup.
    // Pulls the same recent-lead city list the demand_map screen itself queries,
    // and hands any not-yet-cached cities to the rate-limited batch resolver.
    private static function geocode_demand_map_cities(): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$pfx}leads'" ) ) { return; }
        $cities = $wpdb->get_col(
            "SELECT DISTINCT city FROM {$pfx}leads
             WHERE created_at > DATE_SUB(NOW(), INTERVAL 30 DAY) AND city != ''
             LIMIT 200"
        ) ?: [];
        if ( $cities ) {
            \GoodService\Service\GeoCodingService::resolve_missing_batch( $cities );
        }
    }
}
