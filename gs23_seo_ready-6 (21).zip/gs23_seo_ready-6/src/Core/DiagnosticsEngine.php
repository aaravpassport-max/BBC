<?php
namespace GoodService\Core;

/**
 * DiagnosticsEngine — Enterprise Diagnostic & Error Intelligence System
 *
 * Covers all 17 requirement sections:
 *   1.  Frontend / JS errors
 *   2.  Browser-level errors
 *   3.  Network & communication errors
 *   4.  Backend / server errors (PHP)
 *   5.  Database errors
 *   6.  WordPress-specific diagnostics
 *   7.  Performance diagnostics
 *   8.  Security diagnostics
 *   9.  Infrastructure diagnostics
 *  10.  Integration diagnostics (Razorpay, WhatsApp, SMTP)
 *  11.  AI-powered unknown error detection (pattern analysis)
 *  12.  Root cause analysis engine
 *  13.  Diagnostic report generator
 *  14.  Download center (PDF/CSV/JSON/HTML)
 *  15.  Real-time monitoring dashboard
 *  16.  Automated resolution guidance
 *  17.  Universal detection — no error type ignored
 */
final class DiagnosticsEngine {

    // ── Severity constants ────────────────────────────────────────────────────
    const SEV_CRITICAL = 'critical';
    const SEV_ERROR    = 'error';
    const SEV_WARNING  = 'warning';
    const SEV_NOTICE   = 'notice';
    const SEV_INFO     = 'info';

    // ── Source constants ──────────────────────────────────────────────────────
    const SRC_JS             = 'js';
    const SRC_PHP            = 'php';
    const SRC_DB             = 'db';
    const SRC_NETWORK        = 'network';
    const SRC_SECURITY       = 'security';
    const SRC_PERFORMANCE    = 'performance';
    const SRC_WP             = 'wp';
    const SRC_INTEGRATION    = 'integration';
    const SRC_BROWSER        = 'browser';
    const SRC_INFRASTRUCTURE = 'infrastructure';

    // ── Table names ───────────────────────────────────────────────────────────
    private static function tbl_errors(): string {
        global $wpdb;
        return $wpdb->prefix . 'gs_error_log';
    }
    private static function tbl_runs(): string {
        global $wpdb;
        return $wpdb->prefix . 'gs_diag_runs';
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 1: Error capture — store one event from any source
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Capture an error from any source. Deduplicates by (source+type+message hash).
     * Increments occurrence_count instead of creating a new row for repeat events.
     */
    public static function capture(
        string $source,
        string $type,
        string $severity,
        string $message,
        array  $context = []
    ): int {
        global $wpdb;
        $tbl = self::tbl_errors();

        // Dedup key — same error recurring bumps the counter instead of inserting
        $dedup_hash = md5( $source . '|' . $type . '|' . substr( $message, 0, 200 ) );

        $existing = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, occurrence_count FROM {$tbl}
             WHERE MD5(CONCAT(source,'|',type,'|',LEFT(message,200))) = %s
               AND is_resolved = 0
             LIMIT 1",
            $dedup_hash
        ) );

        if ( $existing ) {
            $wpdb->update( $tbl, [
                'occurrence_count' => (int) $existing->occurrence_count + 1,
                'last_seen'        => current_time( 'mysql' ),
                'severity'         => $severity, // update to worst seen
            ], [ 'id' => (int) $existing->id ] );
            return (int) $existing->id;
        }

        // Root cause analysis
        $rca = self::analyse_root_cause( $source, $type, $message, $context );

        $wpdb->insert( $tbl, [
            'source'           => $source,
            'type'             => $type,
            'severity'         => $severity,
            'message'          => substr( $message, 0, 65535 ),
            'context'          => substr( $context['context'] ?? '', 0, 255 ),
            'file_path'        => substr( $context['file'] ?? '', 0, 500 ),
            'line_number'      => (int) ( $context['line'] ?? 0 ),
            'stack_trace'      => substr( $context['stack'] ?? '', 0, 65535 ),
            'url'              => substr( $context['url'] ?? ( $_SERVER['REQUEST_URI'] ?? '' ), 0, 1000 ),
            'user_agent'       => substr( $context['user_agent'] ?? ( $_SERVER['HTTP_USER_AGENT'] ?? '' ), 0, 500 ),
            'user_id'          => $context['user_id'] ?? ( is_user_logged_in() ? get_current_user_id() : 0 ),
            'request_data'     => $context['request_data'] ?? null,
            'root_cause'       => $rca['root_cause'],
            'suggested_fix'    => $rca['suggested_fix'],
            'occurrence_count' => 1,
            'first_seen'       => current_time( 'mysql' ),
            'last_seen'        => current_time( 'mysql' ),
            'created_at'       => current_time( 'mysql' ),
        ] );

        $inserted_id = (int) $wpdb->insert_id;

        // §17: Send admin email alert for new critical errors (not repeated ones)
        if ( $severity === self::SEV_CRITICAL && $inserted_id && ( $context['context'] ?? '' ) !== 'diagnostic_scan' ) {
            // Use shutdown hook to avoid blocking the current request
            add_action( 'shutdown', function() use ( $message, $source, $type ) {
                self::send_critical_alert( $message, $source, $type );
            } );
        }

        return $inserted_id;
    }
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Automatically determines root cause and fix recommendation for any error.
     * Covers all 17 source categories with specific pattern matching.
     */
    public static function analyse_root_cause( string $source, string $type, string $msg, array $ctx = [] ): array {
        $root_cause    = '';
        $suggested_fix = '';

        // ── PHP / Backend errors ───────────────────────────────────────────
        if ( $source === self::SRC_PHP ) {
            if ( str_contains( $msg, 'Call to undefined function' ) ) {
                preg_match( "/Call to undefined function (.+?)\(\)/", $msg, $m );
                $fn = $m[1] ?? 'unknown';
                $root_cause    = "Function {$fn}() is called but not defined. Either the function name is misspelled, a required file/plugin is not loaded, or the function is defined conditionally and the condition was not met.";
                $suggested_fix = "1. Verify spelling of {$fn}(). 2. Wrap in function_exists() check. 3. Ensure the plugin/file that defines it is loaded before this call. 4. Check load order in Plugin.php.";
            } elseif ( str_contains( $msg, 'Call to undefined method' ) ) {
                preg_match( "/Call to undefined method (.+?)::(.+?)\(\)/", $msg, $m );
                $class  = $m[1] ?? 'unknown';
                $method = $m[2] ?? 'unknown';
                $root_cause    = "Method {$class}::{$method}() does not exist. The class may not be the expected version, or the method was renamed/removed.";
                $suggested_fix = "1. Check if {$class} is the correct class (not an older version cached). 2. Verify {$method}() exists and is public. 3. Check for typos.";
            } elseif ( str_contains( $msg, 'Class' ) && str_contains( $msg, 'not found' ) ) {
                preg_match( "/Class \"?(.+?)\"? not found/", $msg, $m );
                $class = $m[1] ?? 'unknown';
                $root_cause    = "Class {$class} is not autoloaded. The file defining it may be missing, or the namespace mapping in composer.json/Plugin.php is incorrect.";
                $suggested_fix = "1. Verify the file src/.../{$class}.php exists. 2. Check namespace declaration matches PSR-4 mapping. 3. Re-run composer dump-autoload if applicable.";
            } elseif ( str_contains( $msg, 'memory' ) || str_contains( $msg, 'Allowed memory size' ) ) {
                preg_match( '/(\d+) bytes/', $msg, $m );
                $bytes = $m[1] ?? '???';
                $root_cause    = "PHP ran out of memory ({$bytes} bytes used). Common causes: loading too many posts/rows at once, large image manipulation, unserializing huge option values.";
                $suggested_fix = "1. Add WP_MEMORY_LIMIT = '256M' to wp-config.php. 2. Paginate large database queries. 3. Use streams instead of loading entire files into memory. 4. Profile with Xdebug or Blackfire.";
            } elseif ( str_contains( $msg, 'Maximum execution time' ) ) {
                $root_cause    = "Script exceeded PHP max_execution_time. Usually caused by a slow DB query, external HTTP call, or infinite loop.";
                $suggested_fix = "1. Increase max_execution_time in php.ini (set_time_limit(120)). 2. Move long operations to WP Cron. 3. Add query timeouts. 4. Check for infinite loops.";
            } elseif ( str_contains( $msg, 'Cannot redeclare' ) ) {
                preg_match( '/Cannot redeclare (.+?)\(/', $msg, $m );
                $fn = $m[1] ?? 'unknown';
                $root_cause    = "Function/class {$fn} is defined in two places and both are loaded. Typically caused by a plugin loading a file twice or a naming conflict with another plugin.";
                $suggested_fix = "1. Wrap the definition in if (!function_exists('{$fn}')) {}. 2. Check require vs require_once usage. 3. Search for duplicate declarations.";
            } elseif ( str_contains( $msg, 'Parse error' ) || str_contains( $msg, 'syntax error' ) ) {
                $root_cause    = "PHP syntax error — the file cannot be parsed. Common causes: missing semicolon, mismatched brackets, unsupported PHP version syntax.";
                $suggested_fix = "1. Check the file at the reported line number. 2. Run php -l filename.php to validate syntax. 3. Verify PHP version compatibility (plugin requires PHP 8.0+).";
            } elseif ( str_contains( $msg, 'Undefined variable' ) ) {
                preg_match( '/Undefined variable:?\s*\$?(\w+)/', $msg, $m );
                $var = $m[1] ?? 'unknown';
                $root_cause    = "Variable \${$var} is used before it is defined. It may be conditional (only set in some code paths) or a typo.";
                $suggested_fix = "1. Initialize \${$var} before the first use. 2. Use \${$var} ?? null to provide a default. 3. Check all code paths that lead to this point.";
            } elseif ( str_contains( $msg, 'Undefined index' ) || str_contains( $msg, 'Undefined array key' ) ) {
                preg_match( '/Undefined (?:index|array key):?\s*["\']?(\w+)["\']?/', $msg, $m );
                $key = $m[1] ?? 'unknown';
                $root_cause    = "Array key '{$key}' does not exist. The array structure may have changed, or the key is only set conditionally.";
                $suggested_fix = "1. Use array_key_exists('{$key}', \$array) before access. 2. Use \$array['{$key}'] ?? null. 3. Verify the array is populated as expected.";
            } else {
                $root_cause    = "PHP runtime error in " . basename( $ctx['file'] ?? 'unknown file' ) . " at line " . ( $ctx['line'] ?? '?' ) . ".";
                $suggested_fix = "Review the stack trace above to trace the call chain. Enable WP_DEBUG temporarily to see full context.";
            }
        }

        // ── Database errors ────────────────────────────────────────────────
        elseif ( $source === self::SRC_DB ) {
            if ( str_contains( $msg, 'Duplicate entry' ) ) {
                preg_match( "/Duplicate entry '(.+?)' for key '(.+?)'/", $msg, $m );
                $val = $m[1] ?? '?'; $key = $m[2] ?? '?';
                $root_cause    = "Duplicate value '{$val}' violates UNIQUE constraint on key '{$key}'. A record with this value already exists.";
                $suggested_fix = "1. Check for existing record before INSERT (SELECT then INSERT). 2. Use INSERT IGNORE or ON DUPLICATE KEY UPDATE. 3. If this is a slug collision, append a unique suffix.";
            } elseif ( str_contains( $msg, "Table") && str_contains( $msg, "doesn't exist" ) ) {
                preg_match( "/Table '(.+?)' doesn't exist/", $msg, $m );
                $tbl = $m[1] ?? '?';
                $root_cause    = "Table {$tbl} does not exist. The database schema may not have been installed or upgraded.";
                $suggested_fix = "1. Go to Admin → Tools → DB Upgrade to run Schema::install(). 2. Check if the plugin was fully activated. 3. Verify the table prefix matches WP config.";
            } elseif ( str_contains( $msg, "Unknown column" ) ) {
                preg_match( "/Unknown column '(.+?)' in/", $msg, $m );
                $col = $m[1] ?? '?';
                $root_cause    = "Column '{$col}' does not exist in the table. The DB schema upgrade may not have run, or the column was added in a newer version.";
                $suggested_fix = "1. Run Admin → Tools → DB Upgrade to add missing columns via upgrade_columns(). 2. Check Schema.php for the column definition.";
            } elseif ( str_contains( $msg, 'Lock wait timeout' ) || str_contains( $msg, 'Deadlock' ) ) {
                $root_cause    = "Database deadlock or lock timeout. Two transactions are waiting for each other's locks, causing a timeout.";
                $suggested_fix = "1. Retry the operation (most transient). 2. Ensure transactions are short. 3. Acquire locks in a consistent order. 4. Check for long-running queries in MySQL processlist.";
            } elseif ( str_contains( $msg, 'Too many connections' ) ) {
                $root_cause    = "MySQL has reached its max_connections limit. Too many simultaneous connections are open.";
                $suggested_fix = "1. Increase max_connections in MySQL config. 2. Use persistent connections carefully. 3. Check for connection leaks (connections not closed). 4. Add a connection pool.";
            } elseif ( str_contains( $msg, 'Access denied' ) ) {
                $root_cause    = "MySQL authentication failure. The DB_USER in wp-config.php does not have sufficient privileges or the password is wrong.";
                $suggested_fix = "1. Verify DB_USER, DB_PASSWORD, DB_HOST in wp-config.php. 2. Grant privileges: GRANT ALL ON database.* TO user@host. 3. Check if MySQL server is running.";
            } elseif ( str_contains( $msg, 'slow query' ) || str_contains( $msg, 'Query took' ) ) {
                $root_cause    = "A database query is taking too long, indicating a missing index or a query scanning too many rows.";
                $suggested_fix = "1. Run EXPLAIN on the slow query. 2. Add composite indexes for WHERE/ORDER BY columns. 3. Limit result sets with LIMIT. 4. Avoid SELECT * on large tables.";
            } else {
                $root_cause    = "Database operation failed. Check wpdb->last_error for details.";
                $suggested_fix = "Enable SAVEQUERIES in wp-config.php to log all queries. Check the MySQL error log for more detail.";
            }
        }

        // ── JavaScript / Browser errors ────────────────────────────────────
        elseif ( $source === self::SRC_JS || $source === self::SRC_BROWSER ) {
            if ( str_contains( $msg, 'is not defined' ) ) {
                preg_match( "/(.+?) is not defined/", $msg, $m );
                $ident = $m[1] ?? '?';
                $root_cause    = "'{$ident}' is referenced in JavaScript but not defined at that point. The script that defines it may not be loaded, or the load order is wrong.";
                $suggested_fix = "1. Check script enqueue order in Assets.php. 2. Move the script to footer (in_footer=true). 3. Use wp_add_inline_script to ensure dependency is loaded first. 4. Check for typos in the identifier name.";
            } elseif ( str_contains( $msg, 'Cannot read propert' ) || str_contains( $msg, 'Cannot read properties' ) ) {
                $root_cause    = "Attempting to access a property of null or undefined. A DOM element query returned null (element not found) or an API response was not checked for null.";
                $suggested_fix = "1. Add null checks: if (element) { element.property }. 2. Use optional chaining: element?.property. 3. Verify the DOM element ID/selector matches the HTML.";
            } elseif ( str_contains( $msg, 'CORS' ) || str_contains( $msg, 'Cross-Origin' ) ) {
                $root_cause    = "CORS (Cross-Origin Resource Sharing) error. The server did not include the correct Access-Control-Allow-Origin header for a cross-origin request.";
                $suggested_fix = "1. Add 'Access-Control-Allow-Origin: *' or specific origin to server responses. 2. For WP REST API add: add_filter('rest_pre_serve_request', ...). 3. Check if the request needs credentials (use withCredentials=true + specific origin).";
            } elseif ( str_contains( $msg, 'net::ERR' ) || str_contains( $msg, 'Failed to fetch' ) ) {
                $root_cause    = "Network request failed. The server may be down, the URL may be wrong, or a firewall/proxy is blocking the request.";
                $suggested_fix = "1. Verify the API endpoint URL is correct. 2. Check network tab in browser DevTools for the actual HTTP response. 3. Test with curl from the server. 4. Check WAF/firewall rules.";
            } elseif ( str_contains( $msg, 'SyntaxError' ) && str_contains( $msg, 'JSON' ) ) {
                $root_cause    = "JSON.parse() received invalid JSON. The server returned HTML (often an error page or redirect) instead of the expected JSON response.";
                $suggested_fix = "1. Check the raw response in Network tab — it may be a PHP error page or redirect. 2. Ensure AJAX handlers always return wp_send_json_success/error. 3. Look for PHP output before the JSON (whitespace, BOM, error notices).";
            } elseif ( str_contains( $msg, 'Mixed Content' ) ) {
                $root_cause    = "A page served over HTTPS is trying to load resources (scripts, images, API calls) over HTTP. Browsers block this for security.";
                $suggested_fix = "1. Update all resource URLs to HTTPS. 2. Set FORCE_SSL_ADMIN in wp-config.php. 3. Update site URL in WordPress settings to https://. 4. Use the Really Simple SSL plugin or manual .htaccess fix.";
            } elseif ( str_contains( $msg, 'localStorage' ) || str_contains( $msg, 'sessionStorage' ) ) {
                $root_cause    = "Browser storage API failed. This can happen in private/incognito mode, when storage quota is exceeded, or when the browser blocks storage for the origin.";
                $suggested_fix = "1. Wrap localStorage calls in try/catch. 2. Check navigator.storage.estimate() for quota. 3. Clear storage and retry. 4. Provide in-memory fallback for incognito.";
            } elseif ( str_contains( $msg, 'Service Worker' ) || str_contains( $msg, 'ServiceWorker' ) ) {
                $root_cause    = "Service Worker registration or fetch handling failed. This can break offline functionality and push notifications.";
                $suggested_fix = "1. Ensure the SW file is served from the root scope. 2. Check SW scope path. 3. Unregister and re-register: navigator.serviceWorker.getRegistrations().then(r=>r.forEach(r=>r.unregister())). 4. Clear Cache Storage.";
            } else {
                $root_cause    = "JavaScript runtime error at " . ( $ctx['file'] ?? 'unknown file' ) . ":" . ( $ctx['line'] ?? '?' ) . ".";
                $suggested_fix = "Review the stack trace. Enable source maps for production builds to get readable file/line references.";
            }
        }

        // ── Network errors ─────────────────────────────────────────────────
        elseif ( $source === self::SRC_NETWORK ) {
            if ( str_contains( $msg, 'timeout' ) || str_contains( $msg, 'Timeout' ) ) {
                $root_cause    = "HTTP request timed out. The remote server did not respond within the configured timeout window.";
                $suggested_fix = "1. Increase wp_remote_post() timeout parameter. 2. Check if the external service is down. 3. Move the call to a background job (WP Cron) to avoid blocking the request. 4. Add retry logic with exponential backoff.";
            } elseif ( str_contains( $msg, 'SSL' ) || str_contains( $msg, 'certificate' ) ) {
                $root_cause    = "SSL certificate verification failed. The remote server's certificate may be expired, self-signed, or the CA bundle on this server is outdated.";
                $suggested_fix = "1. Update the CA bundle: apt-get update ca-certificates. 2. Check the remote server's SSL cert expiry. 3. Use sslverify=false only in dev — never in production. 4. Update PHP's curl CA bundle.";
            } elseif ( str_contains( $msg, '401' ) || str_contains( $msg, 'Unauthorized' ) ) {
                $root_cause    = "API authentication failed. The API key, token, or credentials are invalid, expired, or missing.";
                $suggested_fix = "1. Verify API key is correct and not expired. 2. Check authorization header format (Bearer, Basic, etc.). 3. Regenerate the API key. 4. Confirm the key has the required permissions.";
            } elseif ( str_contains( $msg, '403' ) || str_contains( $msg, 'Forbidden' ) ) {
                $root_cause    = "Access forbidden. The authenticated user/API key lacks permission for this resource.";
                $suggested_fix = "1. Check API key permissions/scopes. 2. Verify IP whitelisting if applicable. 3. Check WAF rules that may be blocking the request. 4. Review the API documentation for required permissions.";
            } elseif ( str_contains( $msg, '429' ) || str_contains( $msg, 'rate limit' ) ) {
                $root_cause    = "API rate limit exceeded. Too many requests sent in a given time window.";
                $suggested_fix = "1. Implement request throttling/queuing. 2. Cache API responses to reduce call frequency. 3. Use exponential backoff on retry. 4. Upgrade the API plan if needed.";
            } elseif ( str_contains( $msg, '500' ) || str_contains( $msg, 'Internal Server Error' ) ) {
                $root_cause    = "Remote server returned HTTP 500. The external service has an internal error — not caused by this plugin.";
                $suggested_fix = "1. Retry after a delay. 2. Check the external service's status page. 3. Log the full response body for debugging. 4. Alert admin if the service is consistently down.";
            } else {
                $root_cause    = "Network communication error with external service.";
                $suggested_fix = "Check network connectivity and verify the external service is operational. Review the full HTTP response body.";
            }
        }

        // ── Security issues ────────────────────────────────────────────────
        elseif ( $source === self::SRC_SECURITY ) {
            if ( str_contains( $type, 'nonce' ) ) {
                $root_cause    = "WordPress nonce verification failed. The request may have been tampered with, the nonce may have expired (24-hour window), or the user was logged out mid-session.";
                $suggested_fix = "1. Refresh the page and retry. 2. Ensure wp_create_nonce() and check_ajax_referer() use the same action string exactly. 3. Check if the user session expired. 4. Verify the nonce is being sent in the AJAX request.";
            } elseif ( str_contains( $type, 'csrf' ) ) {
                $root_cause    = "CSRF (Cross-Site Request Forgery) protection triggered. A form submission or API call arrived without a valid nonce, likely from an external origin.";
                $suggested_fix = "1. Ensure all forms include wp_nonce_field(). 2. Add nonce to all AJAX calls. 3. Never disable CSRF protection — investigate the specific request.";
            } elseif ( str_contains( $type, 'auth_failure' ) ) {
                $root_cause    = "Authentication failure. Invalid credentials, expired session, or unauthorized access attempt.";
                $suggested_fix = "1. If legitimate: reset password, check session expiry. 2. If suspicious: review login logs for brute force patterns. 3. Implement login throttling and 2FA.";
            } elseif ( str_contains( $type, 'injection' ) ) {
                $root_cause    = "Possible SQL/code injection attempt detected in request parameters.";
                $suggested_fix = "1. CRITICAL: Ensure all DB queries use \$wpdb->prepare(). 2. Sanitize all inputs with sanitize_text_field(), sanitize_email() etc. 3. Never interpolate raw user input into SQL strings. 4. Review the request for malicious payload.";
            } elseif ( str_contains( $type, 'xss' ) ) {
                $root_cause    = "Possible XSS (Cross-Site Scripting) indicator detected.";
                $suggested_fix = "1. Escape all output with esc_html(), esc_attr(), esc_js(). 2. Use wp_kses() for HTML that should allow limited tags. 3. Implement Content-Security-Policy headers. 4. Review template files for unescaped echo statements.";
            } elseif ( str_contains( $type, 'brute_force' ) ) {
                $root_cause    = "Multiple authentication failures from the same IP — possible brute force attack.";
                $suggested_fix = "1. Implement login rate limiting (limit_login_attempts). 2. Enable reCAPTCHA on login forms. 3. Block the IP at firewall level if attacks persist. 4. Notify admin via email.";
            } else {
                $root_cause    = "Security-related event detected. Review request details carefully.";
                $suggested_fix = "Investigate the request source and payload. Check audit logs for related activity.";
            }
        }

        // ── Performance issues ─────────────────────────────────────────────
        elseif ( $source === self::SRC_PERFORMANCE ) {
            if ( str_contains( $type, 'slow_query' ) ) {
                $root_cause    = "Database query exceeded acceptable time threshold. Missing indexes, full table scans, or JOIN on un-indexed columns are the most common causes.";
                $suggested_fix = "1. Run EXPLAIN on the query. 2. Add indexes for WHERE/JOIN/ORDER BY columns. 3. Limit result rows with LIMIT + pagination. 4. Consider caching the result with transients.";
            } elseif ( str_contains( $type, 'memory' ) ) {
                $root_cause    = "Memory usage exceeded safe threshold. Likely loading too much data into memory at once.";
                $suggested_fix = "1. Process data in chunks (use LIMIT/OFFSET loops). 2. Use streaming for large files. 3. Increase WP_MEMORY_LIMIT. 4. Profile with WP Query Monitor.";
            } elseif ( str_contains( $type, 'ttfb' ) ) {
                $root_cause    = "Time to First Byte (TTFB) is too high. Server processing time before the first byte is sent to the client is excessive.";
                $suggested_fix = "1. Enable object caching (Redis/Memcached). 2. Use output buffering and page caching. 3. Profile PHP execution time — identify slow hooks. 4. Optimize database queries. 5. Use a CDN.";
            } elseif ( str_contains( $type, 'cache_miss' ) ) {
                $root_cause    = "Cache miss — data was not found in cache and required a DB query. High miss rate indicates ineffective caching strategy.";
                $suggested_fix = "1. Verify the cache key is being set correctly. 2. Check cache expiry TTL — may be too short. 3. Ensure cache is being invalidated only when data changes. 4. Check if object cache is running (Redis/Memcached).";
            } else {
                $root_cause    = "Performance threshold exceeded.";
                $suggested_fix = "Profile with WP Query Monitor or Xdebug to identify the specific bottleneck. Enable slow query log in MySQL.";
            }
        }

        // ── WordPress-specific ─────────────────────────────────────────────
        elseif ( $source === self::SRC_WP ) {
            if ( str_contains( $type, 'hook_conflict' ) ) {
                $root_cause    = "Multiple plugins or themes are hooking the same action/filter and one is overriding or breaking the other's callback.";
                $suggested_fix = "1. Use the $priority parameter in add_action/add_filter to control order. 2. Use remove_action() to unhook conflicting callbacks. 3. Use has_action() to detect conflicts before hooking. 4. Check priority of both hooks.";
            } elseif ( str_contains( $type, 'cron' ) ) {
                $root_cause    = "WordPress Cron failed to execute or is not firing. WP-Cron requires HTTP requests to trigger — if traffic is low or the site blocks loopback requests, cron may not fire.";
                $suggested_fix = "1. Use a real cron job: */5 * * * * curl https://site.com/wp-cron.php. 2. Add DISABLE_WP_CRON in wp-config.php. 3. Check if wp_schedule_event() is correctly scheduling the hook. 4. Use WP Cron Control plugin for debugging.";
            } elseif ( str_contains( $type, 'rest_api' ) ) {
                $root_cause    = "WordPress REST API request failed. The endpoint may not be registered, the user may lack permission, or a plugin is blocking REST API access.";
                $suggested_fix = "1. Test the endpoint directly: /wp-json/goodservice/v1/. 2. Check permission_callback returns true for public endpoints. 3. Disable plugins one-by-one to find conflicts. 4. Verify pretty permalinks are enabled.";
            } elseif ( str_contains( $type, 'rewrite' ) ) {
                $root_cause    = "WordPress rewrite rules are not flushed after adding/modifying custom routes. Pages show 404 after plugin activation or update.";
                $suggested_fix = "1. Go to Settings → Permalinks and click Save (flushes rewrites). 2. Call flush_rewrite_rules(false) on plugin activation. 3. Verify register_rewrites() is hooked to init.";
            } else {
                $root_cause    = "WordPress-specific error in the GoodService plugin.";
                $suggested_fix = "Enable WP_DEBUG and WP_DEBUG_LOG to capture full context. Review the error in wp-content/debug.log.";
            }
        }

        // ── Integration errors ─────────────────────────────────────────────
        elseif ( $source === self::SRC_INTEGRATION ) {
            if ( str_contains( $type, 'razorpay' ) ) {
                $root_cause    = "Razorpay payment gateway error. The payment may have failed, the API key may be invalid, or the HMAC signature verification failed.";
                $suggested_fix = "1. Verify RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in settings. 2. Check Razorpay dashboard for the payment status. 3. Verify HMAC: hash_hmac('sha256', order_id.'|'.payment_id, secret). 4. Check Razorpay API status page.";
            } elseif ( str_contains( $type, 'whatsapp' ) ) {
                $root_cause    = "WhatsApp Business API error. The BSP (Business Service Provider) may be down, the API key may be invalid, or the message template is not approved.";
                $suggested_fix = "1. Check WhatsApp BSP dashboard for error codes. 2. Verify API key and endpoint URL. 3. Ensure message templates are pre-approved by WhatsApp for business messages. 4. Fall back to SMS via OtpService::send_sms().";
            } elseif ( str_contains( $type, 'email' ) || str_contains( $type, 'smtp' ) ) {
                $root_cause    = "Email delivery failed. SMTP credentials may be wrong, the mail server may be blocking the request, or the FROM address is not authorized.";
                $suggested_fix = "1. Verify SMTP credentials in settings. 2. Check if the FROM address domain has SPF/DKIM records. 3. Test with an SMTP plugin (WP Mail SMTP). 4. Check for rate limits on the mail provider. 5. Review bounce logs.";
            } elseif ( str_contains( $type, 'webhook' ) ) {
                $root_cause    = "Webhook delivery or processing failed. The endpoint may not be reachable, the signature verification may have failed, or the payload is malformed.";
                $suggested_fix = "1. Verify the webhook endpoint URL is publicly accessible. 2. Check webhook secret/signature validation. 3. Return 200 OK immediately and process asynchronously. 4. Review the delivery log in the external service dashboard.";
            } else {
                $root_cause    = "Third-party integration error.";
                $suggested_fix = "Check the external service's dashboard and API logs. Verify API keys and endpoint configurations are current.";
            }
        }

        // ── Infrastructure ─────────────────────────────────────────────────
        elseif ( $source === self::SRC_INFRASTRUCTURE ) {
            if ( str_contains( $msg, 'disk space' ) || str_contains( $msg, 'No space left' ) ) {
                $root_cause    = "Server disk is full or nearly full. File uploads, log writing, and caching will fail.";
                $suggested_fix = "1. Delete old log files. 2. Clean up the WordPress uploads directory. 3. Move media to S3/CDN. 4. Expand disk size on hosting. 5. Set up disk usage alerts.";
            } elseif ( str_contains( $msg, 'Permission denied' ) ) {
                $root_cause    = "File or directory permission error. The web server process (www-data/nginx) does not have read or write permission on the target file/directory.";
                $suggested_fix = "1. Check file ownership: chown -R www-data:www-data wp-content/. 2. Set permissions: chmod 755 for dirs, 644 for files. 3. Never use 777. 4. Check SELinux/AppArmor policies if on RHEL/CentOS.";
            } elseif ( str_contains( $msg, 'php.ini' ) || str_contains( $msg, 'ini_set' ) ) {
                $root_cause    = "PHP configuration is not meeting the minimum requirements. The hosting environment may restrict php.ini changes.";
                $suggested_fix = "1. Use .user.ini in the wp-root (for CGI/FPM). 2. Use .htaccess php_value directives (for Apache mod_php). 3. Contact hosting to raise limits. 4. Use a different hosting tier.";
            } else {
                $root_cause    = "Infrastructure/hosting environment issue.";
                $suggested_fix = "Check server error logs, hosting control panel, and resource usage metrics.";
            }
        }

        // ── Generic fallback ───────────────────────────────────────────────
        else {
            $root_cause    = "Error in {$source} layer. See message and stack trace for details.";
            $suggested_fix = "Review the error message, stack trace, and request context. Enable diagnostic logging (Admin → Diagnostics) for more detail.";
        }

        return [
            'root_cause'    => $root_cause,
            'suggested_fix' => $suggested_fix,
        ];
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 6–11: Full System Scan — runs all diagnostic checks
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Run a complete system diagnostic scan covering all 17 spec sections.
     * Returns a run ID. Findings are stored in gs_diag_runs and individual
     * critical findings are also stored in gs_error_log.
     */
    /**
     * Real fix: the confirmed root cause of every scan getting permanently
     * stuck at status='running' with zero error ever recorded. Seven
     * separate live HTTP fetches across this scan, several with 10-second
     * timeouts and two hitting third-party APIs that can hang for their
     * full timeout if unreachable, could sum well past PHP's execution
     * time limit on this server. A hard timeout kills the process
     * instantly — no exception handler, including the update-failure
     * check added last turn, ever gets a chance to run. This is checked
     * before every remaining live-fetch check, so the scan physically
     * cannot run past a safe threshold no matter how many external calls
     * are slow or unreachable.
     */
    private static function time_budget_ok( int $start_ms, int $budget_ms = 18000 ): bool {
        return ( (int) ( microtime( true ) * 1000 ) - $start_ms ) < $budget_ms;
    }

    public static function run_full_scan( int $triggered_by = 0 ): int {
        global $wpdb;
        $start_ms = (int) ( microtime( true ) * 1000 );

        // Real fix, directly matching the confirmed evidence from the last
        // failed run: 9.1 seconds elapsed with healthy memory (46MB of a
        // 4096MB limit) rules out memory exhaustion and points at a
        // connection-level timeout — most likely the CDN already confirmed
        // in front of this site, or an intermediate proxy giving up on the
        // browser's connection well before PHP itself has any reason to
        // stop. ignore_user_abort(true) is the standard, correct mechanism
        // for exactly this: PHP keeps executing even if the connecting
        // client or proxy disconnects, so the scan can still finish and
        // write its real result even if the original browser request times
        // out waiting for a response.
        ignore_user_abort( true );
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 60 ); // defense in depth, in case a PHP-level limit is also a factor
        }

        // Create run record
        $wpdb->insert( self::tbl_runs(), [
            'run_type'     => 'full',
            'status'       => 'running',
            'triggered_by' => $triggered_by,
            'created_at'   => current_time( 'mysql' ),
        ] );
        $run_id = (int) $wpdb->insert_id;
        if ( ! $run_id ) { return 0; }

        // Real, direct fix — no more guessing at external log file
        // locations, which has failed three times in a row. register_shutdown_function()
        // combined with error_get_last() is PHP's own native mechanism for
        // this exact situation: it fires even when a fatal error (including
        // an execution timeout) kills the script mid-way, something no
        // try/catch can ever intercept. Writes the real error directly into
        // this same database row, which is already confirmed writable —
        // completely sidestepping the file-permission dead end. If the scan
        // completes normally, $scan_finished is true and this does nothing.
        $scan_finished = false;
        // Real fix: the last run confirmed this is an external kill (no PHP
        // error recorded at all) — something outside PHP terminated the
        // process. The next genuinely useful fact is exactly how long it
        // ran and how much memory it had used before dying, since a
        // suspiciously round elapsed time (10s, 15s, 30s) points directly
        // at a specific server-level timeout setting, and memory usage near
        // PHP's configured limit points at memory exhaustion instead.
        register_shutdown_function( function() use ( $wpdb, $run_id, &$scan_finished, $start_ms ) {
            if ( $scan_finished ) { return; } // normal completion — nothing to do
            $elapsed_s = round( ( ( (int) ( microtime( true ) * 1000 ) ) - $start_ms ) / 1000, 1 );
            $mem_used_mb  = round( memory_get_usage( true ) / 1048576, 1 );
            $mem_peak_mb  = round( memory_get_peak_usage( true ) / 1048576, 1 );
            $mem_limit    = ini_get( 'memory_limit' );
            $error = error_get_last();
            $mem_limit_bytes = null;
            if ( preg_match( '/^(\d+)([KMG]?)$/i', (string) $mem_limit, $m ) ) {
                $unit_mult = [ '' => 1, 'K' => 1024, 'M' => 1048576, 'G' => 1073741824 ];
                $mem_limit_bytes = (int) $m[1] * ( $unit_mult[ strtoupper( $m[2] ) ] ?? 1 );
            }
            $mem_limit_mb = $mem_limit_bytes ? round( $mem_limit_bytes / 1048576, 1 ) : null;
            $looks_like_memory_exhaustion = $mem_limit_mb && $mem_peak_mb >= ( $mem_limit_mb * 0.9 );
            $error_text = $error
                ? sprintf( '%s: %s in %s on line %d', self::php_error_type_name( $error['type'] ), $error['message'], $error['file'], $error['line'] )
                : sprintf(
                    'The scan process ended unexpectedly with no PHP error recorded — killed externally, not by PHP itself. Ran for %s seconds before being killed. Memory at time of death: %sMB used, %sMB peak (PHP memory_limit is %s). %s',
                    $elapsed_s, $mem_used_mb, $mem_peak_mb, $mem_limit,
                    $looks_like_memory_exhaustion
                        ? 'Peak memory is within 10% of the configured limit — this looks like memory exhaustion, not a timeout. Ask your host to raise memory_limit.'
                        : 'This elapsed time is the exact number to give your host — ask specifically what PHP-FPM\'s request_terminate_timeout (or equivalent) is set to for this site, since that\'s the most common cause of an external kill with no PHP error.'
                );
            $wpdb->update( self::tbl_runs(), [
                'status'   => 'failed',
                'summary'  => wp_json_encode( [ 'fatal_error' => $error_text, 'elapsed_seconds' => $elapsed_s, 'memory_peak_mb' => $mem_peak_mb, 'memory_limit' => $mem_limit ] ),
                'findings' => wp_json_encode( [] ),
            ], [ 'id' => $run_id ] );
        } );

        $findings    = [];
        $crit_count  = 0;
        $err_count   = 0;
        $warn_count  = 0;
        $health      = 100;

        // ── Section 0: Deployment & Build Integrity (checked FIRST — if this
        //    fails, every other finding below may be describing STALE code) ──
        // Wrapped in try/catch: this check makes live system calls
        // (opcache_get_status) that the other established checks below
        // don't — a failure here must never break the entire scan response.
        try {
            $deploy_checks = self::check_deployment_integrity();
        } catch ( \Throwable $e ) {
            $deploy_checks = [ self::finding( self::SRC_INFRASTRUCTURE, 'deploy_check_exception', self::SEV_WARNING,
                'The deployment integrity check itself failed to run: ' . $e->getMessage(),
                'This is a diagnostics-tooling issue, not necessarily a problem with your site — the rest of this scan still ran normally.',
                'N/A' ) ];
        }
        foreach ( $deploy_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 15; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 8; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 3; }
        }

        // ── Section 0c: Customer Dashboard Wiring — covers syntax validity,
        //    table existence, AJAX action registration, and a live fetch of
        //    the actual page, rather than only inferring from source code. ──
        if ( self::time_budget_ok( $start_ms ) ) {
            try {
                $wiring_checks = self::check_customer_dashboard_wiring();
            } catch ( \Throwable $e ) {
                $wiring_checks = [ self::finding( self::SRC_INFRASTRUCTURE, 'wiring_check_exception', self::SEV_WARNING,
                    'The customer dashboard wiring check itself failed to run: ' . $e->getMessage(),
                    'This is a diagnostics-tooling issue, not necessarily a problem with your site — the rest of this scan still ran normally.',
                    'N/A' ) ];
            }
        } else {
            $wiring_checks = [ self::finding( self::SRC_INFRASTRUCTURE, 'wiring_check_skipped_time_budget', self::SEV_WARNING,
                'Skipped the customer dashboard wiring check (including its live HTTP fetch) because the scan has already used most of its safe execution time budget.',
                'This check makes a live network request that can be slow — if this keeps happening, an earlier check in this scan is consistently slow (check for a slow/unreachable external service) and is consuming the shared time budget before this one gets a turn.',
                'N/A' ) ];
        }
        foreach ( $wiring_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 15; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 8; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 3; }
        }

        if ( self::time_budget_ok( $start_ms ) ) {
            try {
                $listing_checks = self::check_listing_click_through();
            } catch ( \Throwable $e ) {
                $listing_checks = [ self::finding( self::SRC_NETWORK, 'listing_check_exception', self::SEV_WARNING,
                    'The listing click-through check itself failed to run: ' . $e->getMessage(),
                    'This is a diagnostics-tooling issue, not necessarily a problem with your site — the rest of this scan still ran normally.',
                    'N/A' ) ];
            }
        } else {
            $listing_checks = [ self::finding( self::SRC_NETWORK, 'listing_check_skipped_time_budget', self::SEV_WARNING,
                'Skipped the listing click-through check (including its live HTTP fetch and the router-query-mismatch check) because the scan has already used most of its safe execution time budget.',
                'Run the scan again — if this keeps happening, an earlier check is consistently slow and consuming the shared time budget.',
                'N/A' ) ];
        }
        foreach ( $listing_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 15; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 8; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 3; }
        }

        // ── Section 0b: Directory Page First-Load Integrity ──────────────
        // Wrapped in try/catch: this check makes a live HTTP self-request
        // — a failure or unexpected exception here must never break the
        // entire scan response (the rest of the findings are still valid
        // and useful even if this specific network call fails).
        if ( self::time_budget_ok( $start_ms ) ) {
            try {
                $dir_checks = self::check_directory_first_load();
            } catch ( \Throwable $e ) {
                $dir_checks = [ self::finding( self::SRC_NETWORK, 'directory_check_exception', self::SEV_WARNING,
                    'The Directory first-load check itself failed to run: ' . $e->getMessage(),
                    'This is a diagnostics-tooling issue, not necessarily a problem with your Directory page — the rest of this scan still ran normally.',
                    'N/A' ) ];
            }
        } else {
            $dir_checks = [ self::finding( self::SRC_NETWORK, 'directory_check_skipped_time_budget', self::SEV_WARNING,
                'Skipped the Directory first-load check because the scan has already used most of its safe execution time budget.',
                'Run the scan again — if this keeps happening, an earlier check is consistently slow.',
                'N/A' ) ];
        }
        foreach ( $dir_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 15; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 8; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 3; }
        }

        // ── Section 4/9: PHP & Infrastructure ────────────────────────────
        $php_checks = self::check_php_environment();
        foreach ( $php_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 15; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 8; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 3; }
        }

        // ── Section 5: Database ───────────────────────────────────────────
        $db_checks = self::check_database();
        foreach ( $db_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 15; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 8; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 3; }
        }

        // ── Section 6: WordPress ──────────────────────────────────────────
        $wp_checks = self::check_wordpress();
        foreach ( $wp_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 12; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 6; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 2; }
        }

        // ── Section 7: Performance ────────────────────────────────────────
        $perf_checks = self::check_performance();
        foreach ( $perf_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 10; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 5; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 2; }
        }

        // ── Section 8: Security ───────────────────────────────────────────
        $sec_checks = self::check_security();
        foreach ( $sec_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 20; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 10; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 4; }
        }

        // ── Section 10: Integration ───────────────────────────────────────
        if ( self::time_budget_ok( $start_ms ) ) {
            try {
                $int_checks = self::check_integrations();
            } catch ( \Throwable $e ) {
                $int_checks = [ self::finding( self::SRC_INTEGRATION, 'integrations_check_exception', self::SEV_WARNING,
                    'The integrations check itself failed to run: ' . $e->getMessage(), 'N/A', 'N/A' ) ];
            }
        } else {
            $int_checks = [ self::finding( self::SRC_INTEGRATION, 'integrations_check_skipped_time_budget', self::SEV_WARNING,
                'Skipped the payment/AI integration check (Razorpay, Anthropic) because the scan has already used most of its safe execution time budget — these calls to third-party APIs can hang for their full timeout if unreachable.',
                'Run the scan again — if this keeps happening consistently, one of these external services is slow or unreachable from this server and is consuming the shared time budget.', 'N/A' ) ];
        }
        foreach ( $int_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 5; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 2; }
        }

        // ── Section 8-B: Security headers ────────────────────────────────
        $hdr_checks = self::check_security_headers();
        foreach ( $hdr_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 15; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 8; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 3; }
        }

        // ── Section 8-C: File integrity ───────────────────────────────────
        $file_checks = self::check_file_integrity();
        foreach ( $file_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 25; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 5; }
        }

        // ── Section 6-B/7-B: Cron + queue health ─────────────────────────
        $cron_checks = self::check_cron_and_queue();
        foreach ( $cron_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 12; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 6; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 2; }
        }

        // ── Section 7-B: Advanced performance ────────────────────────────
        $adv_perf = self::check_advanced_performance();
        foreach ( $adv_perf as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 10; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 5; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 2; }
        }

        // ── Section 6-C: Multisite + update checks ────────────────────────
        $ms_checks = self::check_multisite_and_updates();
        foreach ( $ms_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 15; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 6; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 2; }
        }

        // ── Section 9-B: CDN + server response ───────────────────────────
        if ( self::time_budget_ok( $start_ms ) ) {
            try {
                $cdn_checks = self::check_cdn_and_server();
            } catch ( \Throwable $e ) {
                $cdn_checks = [ self::finding( self::SRC_NETWORK, 'cdn_check_exception', self::SEV_WARNING,
                    'The CDN/server check itself failed to run: ' . $e->getMessage(), 'N/A', 'N/A' ) ];
            }
        } else {
            $cdn_checks = [ self::finding( self::SRC_NETWORK, 'cdn_check_skipped_time_budget', self::SEV_WARNING,
                'Skipped the CDN/server response check because the scan has already used most of its safe execution time budget.',
                'Run the scan again — if this keeps happening, an earlier check is consistently slow.', 'N/A' ) ];
        }
        foreach ( $cdn_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 3; }
            elseif ( $chk['severity'] === self::SEV_NOTICE ) { /* no penalty */ }
        }

        // ── Section 10-B: Active connectivity tests ───────────────────────
        if ( self::time_budget_ok( $start_ms ) ) {
            try {
                $conn_checks = self::check_connectivity();
            } catch ( \Throwable $e ) {
                $conn_checks = [ self::finding( self::SRC_NETWORK, 'connectivity_check_exception', self::SEV_WARNING,
                    'The connectivity check itself failed to run: ' . $e->getMessage(), 'N/A', 'N/A' ) ];
            }
        } else {
            $conn_checks = [ self::finding( self::SRC_NETWORK, 'connectivity_check_skipped_time_budget', self::SEV_WARNING,
                'Skipped the active connectivity tests because the scan has already used most of its safe execution time budget.',
                'Run the scan again — if this keeps happening, an earlier check is consistently slow.', 'N/A' ) ];
        }
        foreach ( $conn_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 20; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 8; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 3; }
        }

        // ── Section 5-B: DB integrity ─────────────────────────────────────
        // Real fix: this section previously had no exception handling at
        // all, unlike nearly every other section in this scan. If it ever
        // throws, the failure needs to be visible in the report itself —
        // not silently drop every check inside it (old ones and new ones
        // alike) with zero explanation, which is exactly what made three
        // consecutive live scans impossible to diagnose from the report.
        try {
            $dbi_checks = self::check_database_integrity();
        } catch ( \Throwable $e ) {
            $dbi_checks = [ self::finding( self::SRC_DB, 'db_integrity_check_crashed', self::SEV_CRITICAL,
                'The database integrity check section crashed and could not run any of its checks: ' . $e->getMessage(),
                'Fix the underlying error below, then re-run the scan. Until then, orphan/duplicate/hex-color-title checks are NOT running.',
                'Uncaught ' . get_class( $e ) . ' at ' . $e->getFile() . ':' . $e->getLine(),
                [ 'affected_files' => [ $e->getFile() . ':' . $e->getLine() ] ] ) ];
        }
        foreach ( $dbi_checks as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 15; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 8; }
            elseif ( $chk['severity'] === self::SEV_WARNING ) { $warn_count++; $health -= 3; }
        }

        // ── Section 11: Pattern analysis on recent errors ─────────────────
        $pattern_findings = self::analyse_error_patterns();
        foreach ( $pattern_findings as $chk ) {
            $findings[] = $chk;
            if ( $chk['severity'] === self::SEV_CRITICAL ) { $crit_count++; $health -= 15; }
            elseif ( $chk['severity'] === self::SEV_ERROR ) { $err_count++; $health -= 8; }
        }

        // Store critical/error findings in error_log too
        foreach ( $findings as $f ) {
            if ( in_array( $f['severity'], [ self::SEV_CRITICAL, self::SEV_ERROR ], true ) ) {
                self::capture( $f['source'], $f['type'], $f['severity'], $f['message'], [
                    'context' => 'diagnostic_scan',
                ] );
            }
        }

        $end_ms      = (int) ( microtime( true ) * 1000 );
        $duration_ms = $end_ms - $start_ms;
        $health      = max( 0, min( 100, $health ) );

        $summary = [
            'health_score'   => $health,
            'critical_count' => $crit_count,
            'error_count'    => $err_count,
            'warning_count'  => $warn_count,
            'total_findings' => count( $findings ),
            'duration_ms'    => $duration_ms,
            'scanned_at'     => current_time( 'mysql' ),
        ];

        $update_result = $wpdb->update( self::tbl_runs(), [
            'status'         => 'complete',
            'summary'        => wp_json_encode( $summary ),
            'findings'       => wp_json_encode( $findings ),
            'health_score'   => $health,
            'critical_count' => $crit_count,
            'error_count'    => $err_count,
            'warning_count'  => $warn_count,
            'duration_ms'    => $duration_ms,
            'completed_at'   => current_time( 'mysql' ),
        ], [ 'id' => $run_id ] );

        // Real bug fix: this return value was previously never checked. A
        // failed update here (wrong column, oversized JSON, or — before the
        // schema fix above — a table that didn't exist at all) meant this
        // function still returned $run_id as if everything succeeded, and
        // the caller (AjaxController::runDiagnostics()) would read back a
        // stale "running" row with empty findings, reporting it to the
        // browser as a completed scan. This is the confirmed, precise cause
        // of a scan that shows a success toast but displays no findings.
        if ( $update_result === false ) {
            throw new \RuntimeException( 'Failed to save scan results to ' . self::tbl_runs() . ': ' . $wpdb->last_error );
        }

        $scan_finished = true; // tells the shutdown handler above: normal completion, nothing to do

        return $run_id;
    }

    /** Translates PHP's numeric E_* error type constants into readable names for the shutdown handler above. */
    private static function php_error_type_name( int $type ): string {
        $map = [
            E_ERROR => 'Fatal error', E_WARNING => 'Warning', E_PARSE => 'Parse error',
            E_NOTICE => 'Notice', E_CORE_ERROR => 'Core error', E_CORE_WARNING => 'Core warning',
            E_COMPILE_ERROR => 'Compile error', E_COMPILE_WARNING => 'Compile warning',
            E_USER_ERROR => 'User error', E_USER_WARNING => 'User warning', E_USER_NOTICE => 'User notice',
            E_STRICT => 'Strict standards', E_RECOVERABLE_ERROR => 'Recoverable error',
            E_DEPRECATED => 'Deprecated', E_USER_DEPRECATED => 'User deprecated',
        ];
        return $map[ $type ] ?? ( 'Error type ' . $type );
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 4/9: PHP & Infrastructure checks
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Deployment & Build Integrity — catches the exact failure mode where a
     * verified-correct code change has zero effect on a live site after
     * confirmed redeployment. Two independent root causes this check can
     * distinguish between:
     *
     * 1. PHP OPCACHE serving stale compiled bytecode. OPcache caches a
     *    file's compiled bytecode keyed by path, and only recompiles when
     *    the file's mtime changes (if opcache.validate_timestamps is on) —
     *    or NEVER recompiles until the cache is cleared (if
     *    opcache.validate_timestamps is OFF, common on some shared hosts
     *    for performance). A deploy can fully succeed at the filesystem
     *    level and still have zero effect if OPcache is serving the old
     *    compiled version.
     *
     * 2. STALE DEPLOY — some hosting control panels' "extract zip" / file
     *    manager tools silently skip overwriting a file if one already
     *    exists at that path, or a deploy script extracts to the wrong
     *    directory. The zip on disk can be 100% correct while the LIVE
     *    file is untouched.
     *
     * GS_BUILD_FINGERPRINT (defined in goodservice.php) is the ground
     * truth — a literal string baked into the codebase at edit time, NOT
     * derived from any filesystem timestamp a deploy tool could preserve.
     * Comparing it to the actual live opcache_get_status() entry for THIS
     * exact running file, and to a live md5 of a recently-changed file,
     * gives two independent, hard-to-fool signals.
     */
    private static function check_deployment_integrity(): array {
        $findings = [];

        // ── Signal 1: OPcache configuration & live cache state ─────────────
        $opcache_enabled = function_exists( 'opcache_get_status' ) && (bool) @ini_get( 'opcache.enable' );
        if ( $opcache_enabled ) {
            $status = @opcache_get_status( false );
            $validate_timestamps = (bool) @ini_get( 'opcache.validate_timestamps' );
            $opcache_problem_found = false;
            if ( ! $validate_timestamps ) {
                $opcache_problem_found = true;
                $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'opcache_stale_risk', self::SEV_CRITICAL,
                    'PHP OPcache is enabled with opcache.validate_timestamps=OFF. The server NEVER checks whether a PHP file changed on disk — it keeps serving the FIRST compiled version forever until OPcache is explicitly cleared or PHP-FPM/Apache is restarted.',
                    'Ask your hosting provider to either set opcache.validate_timestamps=1, or restart PHP-FPM / clear OPcache (opcache_reset()) after every single deployment. This setting is the single most common reason a confirmed-correct code change appears to have no effect after deploying.',
                    'Every code change you deploy can silently fail to take effect, indefinitely, with no error of any kind — this exactly matches "verified the file is correct, deployed it, zero change in behavior."' );
            }
            // Real fix: previously only checked THIS file (DiagnosticsEngine.php)
            // — completely blind to whether Router.php, AjaxController.php, or
            // any other critical file was stale. A file checking only itself
            // for staleness proves nothing about the files that actually
            // render the site. Checks every critical file individually now.
            $critical_files = [
                'Router.php'            => GS_DIR . 'src/Router/Router.php',
                'AjaxController.php'    => GS_DIR . 'src/Controller/AjaxController.php',
                'DiagnosticsEngine.php' => __FILE__,
            ];
            $stale_files = [];
            foreach ( $critical_files as $label => $path ) {
                if ( ! file_exists( $path ) ) { continue; }
                $cached_entry = $status['scripts'][ $path ] ?? null;
                if ( ! $cached_entry ) { continue; } // not yet compiled/cached — not stale, just not loaded this request
                $live_mtime   = filemtime( $path );
                $cached_mtime = $cached_entry['timestamp'] ?? 0;
                if ( $cached_mtime > 0 && $live_mtime > 0 && $cached_mtime !== $live_mtime ) {
                    $opcache_problem_found = true;
                    $stale_files[] = [ 'label' => $label, 'path' => $path,
                        'cached_at' => date( 'Y-m-d H:i:s', $cached_mtime ), 'file_modified_at' => date( 'Y-m-d H:i:s', $live_mtime ) ];
                }
            }
            if ( $stale_files ) {
                $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'opcache_stale_confirmed', self::SEV_CRITICAL,
                    'OPcache is serving STALE compiled bytecode for ' . count( $stale_files ) . ' critical file(s) — the file on disk has changed, but this running PHP process is still executing the OLD compiled version.',
                    'Clear OPcache immediately: use the "🧹 Clear OPcache Now" button, or restart PHP-FPM/the web server. Every deployed code change to these specific files has had zero effect until this is cleared.',
                    'CONFIRMED per-file: ' . implode( '; ', array_map( fn( $f ) => "{$f['label']} — cached from {$f['cached_at']}, actual file modified {$f['file_modified_at']}", $stale_files ) ),
                    [ 'affected_rows' => $stale_files ] );
            }

            // Real bug fix: previously, if OPcache was enabled and correctly
            // configured, neither branch above fired and this check produced
            // zero output — silently indistinguishable from the check never
            // having run at all. Explicit confirmation closes that gap.
            if ( ! $opcache_problem_found ) {
                $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'opcache_healthy', self::SEV_INFO,
                    'OPcache is enabled and correctly configured (validate_timestamps=ON, no stale bytecode detected for this diagnostics file). OPcache is not the cause of any "confirmed-correct file, no effect on live site" symptom on this server.',
                    'No action needed for this signal — OPcache staleness has been directly ruled out, not merely unchecked.', 'N/A' );
            }
        } else {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'opcache_disabled', self::SEV_INFO,
                'PHP OPcache is not enabled or not detectable from this process.',
                'No action needed — without OPcache, every request re-reads files fresh from disk, so stale-bytecode is not possible (though requests may be slower).',
                'N/A' );
        }

        // ── Signal 2: live build fingerprint vs. what THIS request sees ───
        $fingerprint = defined( 'GS_BUILD_FINGERPRINT' ) ? GS_BUILD_FINGERPRINT : null;
        if ( ! $fingerprint ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'build_fingerprint_missing', self::SEV_WARNING,
                'GS_BUILD_FINGERPRINT is not defined. Cannot verify which build is actually running.',
                'Ensure goodservice.php defines GS_BUILD_FINGERPRINT and that this exact constant is what changes with every new release you are given.',
                'Without a fingerprint independent of file mtimes, a stale deploy cannot be distinguished from a fresh one by this check.' );
        } else {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'build_fingerprint_present', self::SEV_INFO,
                'Currently running build fingerprint: ' . $fingerprint . '. Compare this value against the fingerprint printed in the changelog/notes of the version you most recently deployed — if they differ, this server is NOT running the file you most recently uploaded, regardless of what is in the zip.',
                'No action needed if this matches the version you intended to deploy.',
                'N/A' );
        }

        // ── Signal 3: live content hash of a file known to change often ───
        // InquiryModuleDiagnostics.php is edited frequently — hashing its
        // LIVE, on-disk content right now (not a cached value) gives a
        // direct, independent way to confirm exactly what code this server
        // process is actually executing for diagnostics specifically.
        $diag_file = GS_SRC . 'Service/InquiryModuleDiagnostics.php';
        if ( file_exists( $diag_file ) ) {
            $live_hash = md5_file( $diag_file );
            $live_mtime = filemtime( $diag_file );
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'diag_file_live_hash', self::SEV_INFO,
                'InquiryModuleDiagnostics.php on disk right now — md5: ' . $live_hash . ', last modified: ' . date( 'Y-m-d H:i:s', $live_mtime ) . '.',
                'If you expected a newer version of this file and the modified time shown here is OLD, the deployment did not actually overwrite this file — re-check your upload/extraction process and confirm it has permission and is targeting the correct directory.',
                'N/A' );
        }

        // ── Signal 4: rewrite rules registration — a page can render "old
        //    content" not because the PHP file is stale, but because the
        //    URL never actually reached this plugin's routing at all. This
        //    reads the LIVE rewrite_rules option from the database right
        //    now, not an assumption that activation registered it once. ──
        $rewrite_rules = get_option( 'rewrite_rules' );
        $key_routes = [
            '^my-account/?$'        => 'Customer account dashboard (/my-account/)',
            '^vendor/dashboard/?$'  => 'Vendor dashboard (/vendor/dashboard/)',
            '^admin-panel/?$'       => 'Admin panel (/admin-panel/)',
        ];
        if ( ! is_array( $rewrite_rules ) || empty( $rewrite_rules ) ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'rewrite_rules_empty', self::SEV_CRITICAL,
                'The WordPress rewrite_rules option is empty or missing entirely. None of this plugin\'s custom URLs (/my-account/, /vendor/dashboard/, /admin-panel/, etc.) can route anywhere — WordPress has no rule to match them against.',
                'Go to Settings → Permalinks in wp-admin and click Save (no changes needed) to force WordPress to regenerate its rewrite rules. Do this immediately after any migration, staging-to-live copy, or fresh install.',
                'A visitor to any custom plugin URL gets whatever WordPress\'s default fallback produces for an unmatched URL — which can still be a real, styled page (a 404 template, or an unrelated actual Page with a similar slug) that has nothing to do with the plugin code being investigated.' );
        } else {
            foreach ( $key_routes as $pattern => $label ) {
                $found = isset( $rewrite_rules[ $pattern ] );
                if ( ! $found ) {
                    $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'rewrite_rule_missing', self::SEV_CRITICAL,
                        "The rewrite rule for {$label} (pattern: {$pattern}) is NOT present in the live rewrite_rules option.",
                        'Go to Settings → Permalinks in wp-admin and click Save to force regeneration. If it is still missing afterward, this plugin\'s add_rewrite_rule() call for this route is not firing — check Router.php.',
                        "Visitors to this URL are not reaching this plugin's PHP template at all, regardless of how correct that template's code is." );
                } else {
                    $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'rewrite_rule_present', self::SEV_INFO,
                        "Confirmed: the rewrite rule for {$label} is present and registered right now.",
                        'No action needed.', 'N/A' );
                }
            }
        }

        // ── Signal 5: page-caching plugin detection — CSS/JS assets can
        //    update correctly (they're versioned separately) while the
        //    actual HTML of a page keeps being served from a full-page
        //    cache captured before the update, independent of whether the
        //    underlying PHP file or OPcache are already correct. ──
        $cache_plugins = [
            'WP_ROCKET_VERSION' => 'WP Rocket',
            'LSCWP_V'           => 'LiteSpeed Cache',
            'W3TC_VERSION'      => 'W3 Total Cache',
            'WPCACHEHOME'       => 'WP Super Cache',
            'SG_CACHEPRESS_VERSION' => 'SiteGround Optimizer',
        ];
        $detected_cache = [];
        foreach ( $cache_plugins as $const => $name ) {
            if ( defined( $const ) ) { $detected_cache[] = $name; }
        }
        if ( $detected_cache ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'page_cache_plugin_detected', self::SEV_WARNING,
                'Page-caching plugin(s) detected active on this site: ' . implode( ', ', $detected_cache ) . '. These cache the full rendered HTML of a page, separately from CSS/JS assets — meaning this plugin\'s style sheet can show new classes while the actual page markup is still an old cached snapshot.',
                'After every plugin update, explicitly purge the cache for the affected page(s) in ' . implode( '/', $detected_cache ) . '\'s own settings — do not rely on it detecting the change automatically.',
                'The CSS for a new feature can be confirmed present and correct while the HTML that would use those classes is still served from a cached copy captured before the feature existed.' );
        } else {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'page_cache_plugin_none', self::SEV_INFO,
                'No known page-caching plugin detected as active.',
                'No action needed for this specific signal.', 'N/A' );
        }

        // ── Signal 6: CDN indicators on this site's own URL — a CDN caches
        //    full page responses at a layer outside WordPress entirely;
        //    neither a WordPress cache-clear nor an OPcache reset touches it. ──
        $site_host = parse_url( home_url(), PHP_URL_HOST ) ?: '';
        $cdn_indicators = [ 'cdn-alpha', 'cloudflare', 'cdn.', '.cdn' ];
        $cdn_hit = null;
        foreach ( $cdn_indicators as $ind ) {
            if ( stripos( $site_host, $ind ) !== false ) { $cdn_hit = $ind; break; }
        }
        if ( $cdn_hit ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'cdn_domain_detected', self::SEV_WARNING,
                "This site's own domain ({$site_host}) contains a CDN indicator ('{$cdn_hit}'), meaning requests likely pass through a CDN edge cache before reaching WordPress at all.",
                'Purge the CDN cache for the specific affected URL(s) after every deployment, in addition to any WordPress-level cache. A WordPress cache clear or OPcache reset does not touch a CDN edge cache.',
                'A visitor can be served a stale, fully-rendered HTML page directly from a CDN edge node — the request may never even reach this WordPress installation, so no server-side fix of any kind changes what that visitor sees until the CDN cache is purged.' );
        }

        return $findings;
    }

    /**
     * Directory Page — First-Load Integrity. Runs the EXACT same base
     * query templates/pages/archive.php runs with zero filters applied,
     * to give a direct, factual answer to "does the unfiltered query
     * return listings on a genuine first load" — rather than relying on
     * reading the query logic and reasoning about it abstractly, this
     * actually executes it against the real, live database right now.
     */
    /**
     * Real, comprehensive check covering categories deployment/cache checks
     * do NOT cover: PHP syntax validity of the live file, whether a
     * dependent table actually exists on this specific database, whether
     * dependent AJAX actions are genuinely registered, and a live fetch of
     * the actual page to see exactly what a real visitor's browser receives
     * right now — not inferred from source code, fetched directly.
     */
    private static function check_customer_dashboard_wiring(): array {
        $findings = [];
        global $wpdb;

        // ── Check 1: live PHP syntax validity of the actual file ──────────
        $file = GS_DIR . 'templates/pages/customer-dashboard.php';
        if ( file_exists( $file ) ) {
            if ( function_exists( 'shell_exec' ) && ! in_array( 'shell_exec', array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) ), true ) ) {
                $lint_output = @shell_exec( 'php -l ' . escapeshellarg( $file ) . ' 2>&1' );
                $syntax_ok = $lint_output && strpos( $lint_output, 'No syntax errors detected' ) !== false;
                if ( ! $syntax_ok ) {
                    // ENTERPRISE-AUDIT FIX: this file is CONFIRMED dead code — no
                    // router path ever requires/includes it (see the file's own
                    // header comment for the full trace). A syntax error here
                    // cannot affect any real visitor, so this is downgraded from
                    // CRITICAL/"page renders but some tabs are missing" (which was
                    // never true for this specific file) to WARNING/housekeeping.
                    $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'customer_dashboard_syntax_error', self::SEV_WARNING,
                        'customer-dashboard.php failed live PHP syntax validation right now: ' . trim( (string) $lint_output ),
                        'This file is confirmed dead code (nothing in the router includes it — the live /my-account/ page is rendered entirely by other-dashboards.php). A syntax error here has zero effect on any real visitor. Kept as a housekeeping signal only, in case the file is ever revived or deleted.',
                        'CONFIRMED: this exact file, as it exists on disk right now, does not pass PHP syntax validation. CONFIRMED separately: this file is unreachable via any router path.' );
                } else {
                    $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'customer_dashboard_syntax_ok', self::SEV_INFO,
                        'customer-dashboard.php passes live PHP syntax validation right now (php -l).',
                        'No action needed for this signal.', 'N/A' );
                }
            } elseif ( function_exists( 'opcache_compile_file' ) && (bool) @ini_get( 'opcache.enable' ) ) {
                // Real fix: shell_exec is unavailable, but opcache_compile_file()
                // must genuinely parse the file to compile it — a real syntax
                // error surfaces as a catchable ParseError, giving syntax
                // validation without needing shell access at all.
                try {
                    @opcache_compile_file( $file );
                    $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'customer_dashboard_syntax_ok', self::SEV_INFO,
                        'customer-dashboard.php passes live PHP syntax validation right now (verified via opcache_compile_file(), since shell_exec is unavailable on this server).',
                        'No action needed for this signal.', 'N/A' );
                } catch ( \ParseError $e ) {
                    $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'customer_dashboard_syntax_error', self::SEV_WARNING,
                        'customer-dashboard.php failed live PHP syntax validation right now (via opcache_compile_file()): ' . $e->getMessage() . ' at line ' . $e->getLine() . '.',
                        'This file is confirmed dead code (nothing in the router includes it — the live /my-account/ page is rendered entirely by other-dashboards.php). A syntax error here has zero effect on any real visitor. Kept as a housekeeping signal only, in case the file is ever revived or deleted.',
                        'CONFIRMED: this exact file, as it exists on disk right now, does not pass PHP syntax validation. CONFIRMED separately: this file is unreachable via any router path.' );
                }
            } else {
                $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'syntax_check_unavailable', self::SEV_WARNING,
                    'Cannot run a live syntax check — shell_exec() is disabled on this server, and OPcache is unavailable as a fallback verification method.',
                    'Ask your host to run `php -l wp-content/plugins/gs23_seo_ready-6/templates/pages/customer-dashboard.php` manually and confirm it reports "No syntax errors detected".',
                    'N/A' );
            }
        } else {
            // This file is confirmed dead code (see its own header comment /
            // the WARNING-severity branches above) — if it's ever deleted on
            // purpose, that's expected and harmless, not an infrastructure
            // problem, so this stays INFO rather than CRITICAL.
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'customer_dashboard_file_missing', self::SEV_INFO,
                'customer-dashboard.php does not exist at the expected path: ' . $file,
                'This file is confirmed dead code (nothing in the router includes it), so its absence has no effect on any real visitor — the live /my-account/ page is rendered entirely by other-dashboards.php. No action needed unless you specifically expected this file to still be present.',
                'N/A — file is unreachable via any router path either way.' );
        }

        // ── Check 2: does the dependent table actually exist on THIS DB ───
        $msg_table = $wpdb->prefix . 'gs_message_threads';
        $table_exists = $wpdb->get_var( "SHOW TABLES LIKE '{$msg_table}'" ) === $msg_table;
        if ( ! $table_exists ) {
            $findings[] = self::finding( self::SRC_DB, 'message_threads_table_missing', self::SEV_CRITICAL,
                "The table {$msg_table} does not exist on this database, even though it is defined in Schema.php.",
                'Run the DB Upgrade tool (Admin Panel → Settings → System, or reactivate the plugin) to create missing tables. A table defined in code is not the same as a table that was actually created on this specific database — the upgrade routine has to actually run.',
                'The Messages tab and nav badge would still render (they do not depend on this table existing), but opening the Messages section would either show zero conversations or throw a database error, depending on error-suppression settings.' );
        } else {
            $findings[] = self::finding( self::SRC_DB, 'message_threads_table_present', self::SEV_INFO,
                "Confirmed: {$msg_table} exists on this database right now.",
                'No action needed for this signal.', 'N/A' );
        }

        // ── Check 3: are the dependent AJAX actions actually registered ───
        $required_actions = [ 'gs_get_messages', 'gs_send_message', 'gs_impersonate_user', 'gs_clear_opcache' ];
        foreach ( $required_actions as $action ) {
            $registered = has_action( 'wp_ajax_' . $action ) || has_action( 'wp_ajax_nopriv_' . $action );
            if ( ! $registered ) {
                $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'ajax_action_not_registered', self::SEV_CRITICAL,
                    "The AJAX action '{$action}' is not registered with WordPress on this running process (checked via has_action('wp_ajax_{$action}')).",
                    'This means the PHP method may exist in the source file, but the add_action() call that wires it to WordPress never executed — check that AjaxController\'s registration list actually includes this exact string, and that AjaxController is being loaded at all on this request.',
                    "Any JS call to this action returns WordPress's generic \"0\" or a 400-style response — not the plugin's own error message — since WordPress never found a handler to route the request to." );
            } else {
                $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'ajax_action_registered', self::SEV_INFO,
                    "Confirmed: '{$action}' is registered and reachable on this running process right now.",
                    'No action needed for this signal.', 'N/A' );
            }
        }

        // ── Check 4: live fetch of the actual page — the single most direct
        //    possible test, since it reproduces exactly what a real visitor's
        //    browser receives right now, not what the source code implies. ──
        $test_url = home_url( '/my-account/?section=inquiries' );
        $response = wp_remote_get( $test_url, [ 'timeout' => 5, 'sslverify' => false, 'cookies' => $_COOKIE ] );
        if ( is_wp_error( $response ) ) {
            $findings[] = self::finding( self::SRC_NETWORK, 'live_fetch_failed', self::SEV_WARNING,
                'Could not live-fetch ' . $test_url . ' to inspect the actual served HTML: ' . $response->get_error_message(),
                'This self-test could not run — it does not mean the page itself is broken, only that this diagnostic could not verify it directly this way.',
                'N/A' );
        } else {
            $body = wp_remote_retrieve_body( $response );
            // Real fix: no longer checks for the Messages tab marker — that
            // feature was deliberately removed per explicit request; its
            // correct absence was previously being reported as a CRITICAL
            // finding, a genuine false positive.
            $has_formdetails = strpos( $body, 'gsc-info-grid' ) !== false;

            // ── Real, direct answer to "why would other pages work but not
            //    this one" — capture the actual cache-status header for THIS
            //    exact URL. If it reports HIT, that is conclusive, direct
            //    proof the origin server (and therefore any PHP code at all,
            //    including cache-control headers already added) is never
            //    contacted for this specific request — the CDN answers from
            //    its own edge copy without running a single line of PHP.
            //    This is categorically different from a code bug: no code
            //    change of any kind can affect a response the code never
            //    got a chance to produce. ──
            $cache_status_headers = [ 'cf-cache-status', 'x-cache', 'x-cache-status', 'x-proxy-cache', 'x-litespeed-cache' ];
            $found_cache_header = null;
            $found_cache_value  = null;
            foreach ( $cache_status_headers as $h ) {
                $v = wp_remote_retrieve_header( $response, $h );
                if ( $v ) { $found_cache_header = $h; $found_cache_value = $v; break; }
            }
            if ( $found_cache_header ) {
                $is_hit = stripos( $found_cache_value, 'hit' ) !== false;
                $findings[] = self::finding( self::SRC_NETWORK, $is_hit ? 'my_account_cache_hit_confirmed' : 'my_account_cache_bypassed',
                    $is_hit ? self::SEV_CRITICAL : self::SEV_INFO,
                    "Cache status header for /my-account/ itself, right now: {$found_cache_header}: {$found_cache_value}.",
                    $is_hit
                        ? 'This is a cache HIT — the CDN answered this exact request directly from its edge cache without contacting the origin server at all. This means no PHP code change of any kind (including the no-store headers already added to BaseController::view() and Router::render_page()) can have any effect on this response, because the origin was never asked to produce it. This must be fixed at the CDN level: add a Cache Rule / Page Rule to bypass cache specifically for /my-account/*, or purge this specific cached URL and confirm the bypass rule is in place before it gets re-cached.'
                        : 'This confirms the request reached the origin server (not served from edge cache), meaning the no-store headers already in the code are actually being sent and should take effect for future requests.',
                    $is_hit
                        ? 'CONFIRMED, directly: this specific page is being answered from CDN cache, not from this code, which is the precise, code-independent reason it can behave differently from other pages that are not cached the same way — this is not a PHP bug, it is a caching configuration scope issue specific to this URL.'
                        : 'N/A' );
            } else {
                $findings[] = self::finding( self::SRC_NETWORK, 'my_account_cache_header_absent', self::SEV_WARNING,
                    'No recognizable cache-status header (cf-cache-status, x-cache, x-litespeed-cache, etc.) was present on the response for /my-account/.',
                    'Either no CDN/reverse-proxy cache is involved for this specific URL (in which case the earlier code fix should be effective), or the CDN in front of this site uses a header name not in this check\'s known list — check your CDN\'s documentation for its specific cache-status header name.',
                    'N/A' );
            }

            if ( ! $has_formdetails ) {
                $findings[] = self::finding( self::SRC_NETWORK, 'live_fetch_missing_markers', self::SEV_CRITICAL,
                    'Fetched ' . $test_url . ' live, right now, and checked its actual returned HTML. Submitted Details marker (gsc-info-grid) present: NO.',
                    'The live-fetched HTML for this exact URL, right now, does not contain a marker that is confirmed present in the source file on disk. This means something between "PHP file on disk" and "HTTP response body" is altering the output — a caching layer (page cache, CDN, proxy), a PHP fatal error partway through rendering, or a template override intercepting this route before reaching this file.',
                    'CONFIRMED via direct HTTP fetch, not inference from source code: what this server is actually returning right now for this URL does not match what the source file on disk would produce.' );
            } else {
                $findings[] = self::finding( self::SRC_NETWORK, 'live_fetch_markers_present', self::SEV_INFO,
                    'Fetched ' . $test_url . ' live, right now — the Submitted Details marker is present in the actual returned HTML.',
                    'This confirms the live page is genuinely serving the current code. If a specific feature still does not appear correctly in a browser, the cause is client-side (browser cache, service worker, or a JS error) rather than the server not running current code.', 'N/A' );
            }
        }

        return $findings;
    }

    /**
     * Real, targeted diagnostic for "clicking any listing redirects back to
     * /directory/". render_listing_unified() in Router.php has several
     * conditions that can cause this redirect — rather than reason about
     * which one abstractly, this picks a real active listing from the live
     * database, checks each condition directly against it, and does a live
     * HTTP fetch of its actual URL to report exactly what happens.
     */
    private static function check_listing_click_through(): array {
        $findings = [];
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $listing = $wpdb->get_row(
            "SELECT l.id, l.slug, l.status, l.vendor_id, vp.is_active AS vendor_is_active, vp.business_name
             FROM {$pfx}listings l
             LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
             WHERE l.status = 'active' ORDER BY l.id DESC LIMIT 1"
        );

        if ( ! $listing ) {
            $findings[] = self::finding( self::SRC_DB, 'no_active_listing_to_test', self::SEV_WARNING,
                'No active listing exists on this site to test against — cannot verify the directory click-through behavior directly.',
                'Create or activate at least one listing, then re-run this scan.', 'N/A' );
            return $findings;
        }

        // ── Check 1: does this specific listing's vendor show as inactive?
        //    This is the exact condition at Router.php's render_listing_unified()
        //    that redirects to /directory/ for a suspended vendor, independent
        //    of the listing's own status. ──
        if ( $listing->vendor_id && isset( $listing->vendor_is_active ) && (int) $listing->vendor_is_active === 0 ) {
            $findings[] = self::finding( self::SRC_DB, 'listing_vendor_inactive_confirmed', self::SEV_CRITICAL,
                "CONFIRMED: listing #{$listing->id} (slug: {$listing->slug}) is active, but its vendor ('" . ( $listing->business_name ?: 'unnamed' ) . "', vendor_id {$listing->vendor_id}) has is_active=0 in vendor_profiles. Router.php's render_listing_unified() explicitly redirects to /directory/ whenever this is true, regardless of the listing's own status.",
                "Run: UPDATE {$pfx}vendor_profiles SET is_active=1 WHERE id={$listing->vendor_id} — if this is the only affected vendor. If MANY vendors show is_active=0, something suspended them in bulk; check for a recent bulk admin action or a bug in whatever ran last.",
                'This is a direct, confirmed match for "click any listing, get redirected to directory" — not every listing necessarily has this vendor, but if most/all vendors on this site show is_active=0, this explains the symptom being reported as "any listing."' );
        } elseif ( $listing->vendor_id && isset( $listing->vendor_is_active ) && (int) $listing->vendor_is_active === 1 ) {
            $findings[] = self::finding( self::SRC_DB, 'listing_vendor_active_confirmed', self::SEV_INFO,
                "Checked listing #{$listing->id}'s vendor directly — is_active=1, not the cause for this specific listing.",
                'No action needed for this specific signal — check the live fetch result below for what is actually happening.', 'N/A' );
        } elseif ( $listing->vendor_id ) {
            // Real bug fix: previously this case (vendor_is_active is NULL,
            // not 0 or 1) silently fell into the "confirmed active" branch
            // above via elseif — isset() treats NULL as not-set, so a
            // broken vendor_id reference (pointing to a vendor_profiles row
            // that doesn't exist) was being misreported as a healthy,
            // active vendor.
            $findings[] = self::finding( self::SRC_DB, 'listing_vendor_join_broken', self::SEV_CRITICAL,
                "Listing #{$listing->id} has vendor_id={$listing->vendor_id}, but joining that ID against vendor_profiles returned no row at all — vendor_is_active is NULL, not 0 or 1. This vendor_id points to a vendor_profiles row that does not exist.",
                "Check whether vendor_profiles row id={$listing->vendor_id} genuinely doesn't exist (deleted vendor, orphaned listing) or whether there's a data-type mismatch between listings.vendor_id and vendor_profiles.id. If the vendor is genuinely gone, this listing should probably be unpublished rather than left pointing at nothing.",
                'A broken join here means any code that checks vendor_is_active without accounting for NULL specifically (isset() treats NULL as unset) can behave unpredictably — this needs verifying directly against Router.php\'s actual redirect condition, not assumed safe.' );
        }

        // ── Check 1b: does Router.php's OWN, more restrictive listing query
        //    (extra JOINs, larger column list) find this same listing where
        //    the simpler query above succeeded? A silent difference here —
        //    not a difference in status/vendor state, but in which rows the
        //    JOINs themselves return — would explain render_listing_unified()
        //    hitting its own "if (!$listing) redirect" even for a listing
        //    confirmed active and vendor-healthy by the checks above. ──
        $router_query_result = $wpdb->get_row( $wpdb->prepare(
            "SELECT l.id FROM {$pfx}listings l
             LEFT JOIN {$pfx}categories c ON c.id = l.category_id
             LEFT JOIN {$pfx}categories sc ON sc.id = l.subcategory_id
             LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
             WHERE l.slug = %s AND l.status IN('active','pending','draft')",
            $listing->slug
        ) );
        if ( ! $router_query_result ) {
            $findings[] = self::finding( self::SRC_DB, 'router_query_mismatch_confirmed', self::SEV_CRITICAL,
                "CONFIRMED: Router.php's actual listing-lookup query (the one render_listing_unified() really runs, replicated here exactly) returns ZERO rows for slug '{$listing->slug}', even though a simpler query for the same slug succeeds. This is a direct reproduction of the exact query the live site runs.",
                'Since the only structural differences are the categories/subcategory JOINs, check whether this listing\'s category_id or subcategory_id references a row that no longer exists in the categories table — an INNER-JOIN-like failure from a LEFT JOIN only happens if something in the WHERE clause implicitly filters on a joined column, or if there is a real data type mismatch between the joined columns.',
                'This is the most direct possible explanation for "listing confirmed active, vendor confirmed active, yet the page still redirects to /directory/" — the redirect at Router.php\'s render_listing_unified() line "if (!$listing) redirect" fires specifically because ITS query, not a simpler one, finds nothing.' );
        } else {
            $findings[] = self::finding( self::SRC_DB, 'router_query_matches', self::SEV_INFO,
                "Router.php's actual listing-lookup query, replicated exactly, DOES find listing #{$listing->id} for slug '{$listing->slug}' — the query itself is not the cause of any redirect for this listing.",
                'N/A', 'N/A' );
        }

        // ── Check 2: how many vendors total are inactive right now? If this
        //    is a small number, it's an isolated case; if it's most/all
        //    vendors, that's a systemic issue matching "any listing." ──
        $total_vendors    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}vendor_profiles" );
        $inactive_vendors = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE is_active = 0" );
        if ( $total_vendors > 0 && $inactive_vendors > 0 ) {
            $pct = round( ( $inactive_vendors / $total_vendors ) * 100 );
            $findings[] = self::finding( self::SRC_DB, 'inactive_vendor_ratio', $pct >= 50 ? self::SEV_CRITICAL : self::SEV_WARNING,
                "{$inactive_vendors} of {$total_vendors} vendors ({$pct}%) currently have is_active=0.",
                $pct >= 50
                    ? 'This is the majority of vendors on the site — this directly explains a symptom reported as "any listing" redirects, since most listing click-throughs would hit an inactive vendor. Investigate what set is_active=0 on this many rows at once — check for a recent bulk suspend action, a migration that ran with the wrong default, or a bug in an update statement missing its WHERE clause.'
                    : 'A minority of vendors — likely isolated suspensions, not a systemic bug. If the specific listing being clicked belongs to one of these vendors, that click will still redirect; this is expected for a genuinely suspended vendor.',
                'N/A' );
        }

        // ── Check 3: live fetch of this exact listing's real URL — the most
        //    direct possible test, since it reproduces exactly what a real
        //    visitor's click produces right now. ──
        $listing_url = home_url( '/' . $listing->slug . '/' );
        $response = wp_remote_get( $listing_url, [ 'timeout' => 5, 'redirection' => 0, 'sslverify' => false ] );
        if ( is_wp_error( $response ) ) {
            $findings[] = self::finding( self::SRC_NETWORK, 'listing_live_fetch_failed', self::SEV_WARNING,
                'Could not live-fetch ' . $listing_url . ': ' . $response->get_error_message(),
                'This self-test could not run directly — it does not mean the page itself is broken.', 'N/A' );
        } else {
            $code = wp_remote_retrieve_response_code( $response );
            $location = wp_remote_retrieve_header( $response, 'location' );
            if ( in_array( $code, [ 301, 302, 303, 307, 308 ], true ) ) {
                $redirects_to_directory = $location && str_contains( $location, '/directory' );
                $findings[] = self::finding( self::SRC_NETWORK, $redirects_to_directory ? 'listing_redirect_confirmed' : 'listing_redirect_elsewhere', self::SEV_CRITICAL,
                    "CONFIRMED via live HTTP fetch: {$listing_url} returns HTTP {$code}, redirecting to: " . ( $location ?: '(no Location header present)' ) . '.',
                    $redirects_to_directory
                        ? 'This is a live, direct reproduction of the reported bug on this exact listing, right now. Combined with the vendor is_active checks above, this narrows the cause to a specific, confirmed condition rather than a hypothesis.'
                        : 'This listing redirects, but NOT to /directory/ — if the reported symptom is specifically about /directory/, this particular listing may not be representative of the one being clicked. Test the exact listing URL the user actually clicked.',
                    'N/A' );
            } else {
                $findings[] = self::finding( self::SRC_NETWORK, 'listing_live_fetch_ok', self::SEV_INFO,
                    "Live-fetched {$listing_url} right now — returned HTTP {$code}, no redirect. This specific listing loads correctly.",
                    'If a different, specific listing is the one exhibiting the reported bug, test that exact URL instead — the cause is likely specific to that listing/vendor\'s data, not a site-wide bug, since this one loads fine.', 'N/A' );
            }
        }

        return $findings;
    }

    private static function check_directory_first_load(): array {
        global $wpdb;
        $findings = [];
        $pfx = $wpdb->prefix . 'gs_';

        // ── Same WHERE clause archive.php builds with zero $_GET filters ──
        $listings_tbl = $pfx . 'listings';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$listings_tbl}'" ) === null ) {
            $findings[] = self::finding( self::SRC_DB, 'directory_table_missing', self::SEV_CRITICAL,
                "Table {$listings_tbl} does not exist.",
                'Run the DB Upgrade tool to create missing tables.',
                'The Directory page query would fail entirely (SQL error), not silently return zero rows — if you are seeing an EMPTY but otherwise normally-rendered page, this is not the cause.' );
            return $findings;
        }

        $active_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$listings_tbl} WHERE status='active'" );
        $total_count  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$listings_tbl}" );

        if ( $total_count === 0 ) {
            $findings[] = self::finding( self::SRC_DB, 'directory_zero_listings_total', self::SEV_CRITICAL,
                "{$listings_tbl} has ZERO rows of any status — there are no listings in the database at all.",
                'This is a content/data issue, not a code bug — create or import at least one listing.',
                'No code fix can make a Directory page show listings that do not exist in the database.' );
        } elseif ( $active_count === 0 ) {
            $findings[] = self::finding( self::SRC_DB, 'directory_zero_active_listings', self::SEV_CRITICAL,
                "{$listings_tbl} has {$total_count} row(s) total, but ZERO have status='active'. The Directory query explicitly filters WHERE status='active', so this exactly matches \"no listings on first load.\"",
                "Check why listings are not active — review the actual status values present: " . implode( ', ', array_filter( array_map( 'strval', $wpdb->get_col( "SELECT DISTINCT status FROM {$listings_tbl}" ) ?: [] ) ) ),
                'Every visit to the Directory page will show zero listings regardless of filters, browser, cache, or how the page was reached — this is a data-state issue, not a rendering bug. A filter click would NOT fix this either (the AJAX path applies the same status=active condition).' );
        } else {
            // Run the literal query archive.php executes with NO filters,
            // exactly as a genuine first-time visitor would trigger it.
            $per_page = max( 1, (int) gs_setting( 'listings_per_page', '20' ) );
            $sample = $wpdb->get_results(
                "SELECT l.id, l.title, l.status, l.city FROM {$listings_tbl} l WHERE l.status='active' ORDER BY l.is_featured DESC, l.id DESC LIMIT {$per_page}"
            );
            $sample_count = is_array( $sample ) ? count( $sample ) : 0;
            if ( $sample_count === 0 ) {
                $findings[] = self::finding( self::SRC_DB, 'directory_query_returns_zero', self::SEV_CRITICAL,
                    "Active listings exist ({$active_count} total) but the exact unfiltered first-load query returned ZERO rows right now. This points to a query-construction issue specific to the no-filter case, not a data issue.",
                    'Re-check archive.php for a WHERE/JOIN clause that unintentionally excludes rows when no filter values are present (e.g. an empty-string comparison that should be skipped but is not).',
                    'CONFIRMED via live execution: the base query itself returns nothing for an unfiltered visit, independent of any caching, JS, or CSS issue.' );
            } else {
                $findings[] = self::finding( self::SRC_DB, 'directory_query_ok', self::SEV_INFO,
                    "CONFIRMED via live execution: the unfiltered first-load query returns {$sample_count} row(s) right now (first result: \"" . esc_html( $sample[0]->title ?? '' ) . "\" in " . esc_html( $sample[0]->city ?? '' ) . "). {$active_count} active listing(s) exist in total.",
                    'No fix needed for the underlying data/query — if the page still appears empty on first load in a real browser, the cause is in rendering (CSS/JS/caching on the page itself), NOT in the database or PHP query logic. Check the page-cache / CDN / JS console next.',
                    'N/A' );
            }

            // ── Faithful reproduction of the REAL archive.php query, exact
            //    joins and all, compared directly against the cached count
            //    archive.php itself would read. Built specifically because
            //    real browser evidence showed a CORRECT, non-zero count
            //    displayed alongside a genuinely EMPTY card list on the same
            //    page load — something the simplified check above cannot
            //    catch, since it never includes the LEFT JOINs or the
            //    wp_cache_get() staleness window the real page actually uses.
            $wsql_real = "l.status='active'";
            $count_cache_key = 'gsd_count_' . md5( $wsql_real . serialize( [] ) );
            $cached_total = wp_cache_get( $count_cache_key, 'gs_directory' );
            $real_rows = $wpdb->get_results(
                "SELECT l.id, l.title, l.city, l.category_id, l.vendor_id
                 FROM {$listings_tbl} l
                 LEFT JOIN {$wpdb->prefix}gs_categories c ON c.id = l.category_id
                 LEFT JOIN {$wpdb->prefix}gs_vendor_profiles vp ON l.vendor_id = vp.id
                 WHERE {$wsql_real}
                 ORDER BY l.is_featured DESC, l.avg_rating DESC, l.views_count DESC
                 LIMIT {$per_page}"
            );
            $real_row_count = is_array( $real_rows ) ? count( $real_rows ) : 0;
            $fresh_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$listings_tbl} l WHERE {$wsql_real}" );

            if ( $cached_total !== false && (int) $cached_total !== $fresh_count ) {
                $findings[] = self::finding( self::SRC_DB, 'directory_count_cache_stale', self::SEV_CRITICAL,
                    "The cached listing count (used for 'Showing X of Y' / sidebar counts) is {$cached_total}, but a fresh COUNT(*) right now gives {$fresh_count}. These should match — the cache is genuinely stale.",
                    'Reduce or remove the 60-second wp_cache_get/set TTL on the directory count in archive.php, or flush the \'gs_directory\' cache group whenever a listing\'s status changes.',
                    'CONFIRMED: this is the exact mechanism that produces a correct-looking listing COUNT displayed next to an EMPTY card list — the count came from a stale cache while the row query (never cached) reflects current, different reality.' );
            } elseif ( $real_row_count === 0 && $fresh_count > 0 ) {
                $findings[] = self::finding( self::SRC_DB, 'directory_joins_drop_rows', self::SEV_CRITICAL,
                    "A fresh COUNT(*) finds {$fresh_count} active listing(s), but the SAME query WITH the real page's LEFT JOINs (categories, vendor_profiles) returns ZERO rows. The joins themselves are eliminating every row — almost certainly because LEFT JOIN was written or is behaving as an INNER JOIN somewhere in the actual query (e.g. a WHERE clause on a joined table's column applied unconditionally turns a LEFT JOIN into an effective INNER JOIN), or because gs_categories/gs_vendor_profiles is missing rows that gs_listings.category_id/vendor_id reference.",
                    'Check whether any WHERE condition references c.* or vp.* columns unconditionally (this silently converts LEFT JOIN to INNER JOIN). Check for orphaned category_id/vendor_id values: SELECT l.id FROM listings l LEFT JOIN categories c ON c.id=l.category_id WHERE c.id IS NULL AND l.category_id IS NOT NULL.',
                    'CONFIRMED via live execution: this is the most likely real mechanism behind a correct count + empty card list on the same page load.' );
            } else {
                $findings[] = self::finding( self::SRC_DB, 'directory_count_rows_consistent', self::SEV_INFO,
                    "Cached count: " . ( $cached_total === false ? 'not cached yet' : $cached_total ) . ". Fresh count: {$fresh_count}. Row query with real joins returns: {$real_row_count}. All consistent right now.",
                    'No fix needed for this specific mechanism at this moment — if the empty-list symptom recurs, re-run this scan immediately when it happens (the cache window is only 60 seconds, so timing matters for catching it).',
                    'N/A' );
            }
        }

        // ── Route registration sanity check ─────────────────────────────
        global $wp_rewrite;
        $rules = $wp_rewrite instanceof \WP_Rewrite ? (array) $wp_rewrite->wp_rewrite_rules() : [];
        $has_directory_rule = false;
        foreach ( array_keys( $rules ) as $pattern ) {
            if ( str_contains( (string) $pattern, 'directory' ) ) { $has_directory_rule = true; break; }
        }
        if ( ! $has_directory_rule ) {
            $findings[] = self::finding( self::SRC_WP, 'directory_rewrite_missing', self::SEV_WARNING,
                'No WordPress rewrite rule containing "directory" was found in the live rewrite rules table.',
                'Go to Settings → Permalinks and click Save (this forces WordPress to regenerate rewrite rules) — or deactivate/reactivate the plugin.',
                'If rewrite rules are stale/missing, /directory/ may be served by a fallback WP page+theme template instead of the intended GS_DIR archive.php route — this can produce a page that looks similar but runs different code with different (or missing) data preparation.' );
        }

        // ── Live HTTP self-request: what does a genuine first-time visitor
        //    actually receive? No cookies, no session, no JS — the literal
        //    raw HTML bytes. This is the single most direct way to rule
        //    in/out every server-side explanation (PHP logic, caching,
        //    rewrite routing) at once, independent of anything that could
        //    only be diagnosed in a real browser (CSS rendering, JS errors).
        $directory_url = home_url( '/directory/' );
        // SHORT timeout (5s, not 15s) — this is a SELF-request (the server
        // calling itself). On hosts with few PHP-FPM workers, or where
        // loopback requests are firewalled, a long timeout here can make
        // the entire diagnostic scan appear to hang or do nothing at all —
        // a worse outcome than this one check simply being skipped.
        // Wrapped in try/catch as an extra safety net: a network-layer
        // failure in THIS check must never prevent every other finding in
        // the report from being returned.
        try {
            $response = wp_remote_get( $directory_url, [
                'timeout'   => 5,
                'sslverify' => false,
                'headers'   => [ 'User-Agent' => 'GoodService-Diagnostics/1.0' ],
                'cookies'   => [],
            ] );
        } catch ( \Throwable $e ) {
            $response = new \WP_Error( 'gs_diag_exception', $e->getMessage() );
        }

        if ( is_wp_error( $response ) ) {
            $findings[] = self::finding( self::SRC_NETWORK, 'directory_http_request_failed', self::SEV_ERROR,
                'Could not fetch ' . $directory_url . ' — ' . $response->get_error_message(),
                'Check that the site is reachable from itself (some hosts block self-requests via loopback) and that the URL is correct.',
                'Unable to verify what a real first-time visitor receives — this check could not run.' );
        } else {
            $code = wp_remote_retrieve_response_code( $response );
            $body = wp_remote_retrieve_body( $response );
            $headers = wp_remote_retrieve_headers( $response );
            // getAll() is a real, documented method on
            // Requests_Utility_CaseInsensitiveDictionary (confirmed against
            // WP core source: wp-includes/Requests/Utility/CaseInsensitiveDictionary.php).
            // A plain (array) cast would NOT work here — the class's $data
            // property is protected, so casting only exposes public
            // properties with mangled keys, not the clean header names.
            // wp_remote_retrieve_headers() can also legitimately return a
            // plain array in some code paths, so guard for both shapes.
            $headers_arr = ( is_object( $headers ) && method_exists( $headers, 'getAll' ) ) ? $headers->getAll() : (array) $headers;
            $headers_lc  = array_change_key_case( $headers_arr, CASE_LOWER );

            // ── Direct inspection of cache-related response headers — the
            //    server-side equivalent of manually checking the Network
            //    tab's Response Headers, done automatically here so the
            //    answer doesn't depend on anyone opening DevTools.
            $cache_control = $headers_lc['cache-control'] ?? null;
            $cf_status     = $headers_lc['cf-cache-status'] ?? null;
            $x_cache       = $headers_lc['x-cache'] ?? null;
            $age_header    = $headers_lc['age'] ?? null;

            if ( $cf_status || $x_cache ) {
                $findings[] = self::finding( self::SRC_NETWORK, 'directory_cdn_cache_header_present', self::SEV_CRITICAL,
                    'A CDN/edge-cache response header was found on the live response for /directory/: ' .
                    ( $cf_status ? "cf-cache-status: {$cf_status}" : '' ) .
                    ( $x_cache ? ( $cf_status ? ', ' : '' ) . "x-cache: {$x_cache}" : '' ) .
                    ( $age_header ? ", age: {$age_header} seconds (how long this response has been cached)" : '' ) . '.',
                    $cf_status === 'HIT' || stripos( (string) $x_cache, 'hit' ) !== false
                        ? 'CONFIRMED: this exact response was served from a CDN cache, not freshly generated by PHP. Log into your CDN dashboard (e.g. Cloudflare) and add a cache-bypass / "Cache Level: Bypass" rule specifically for the /directory/ path, or purge the existing cached entry for this URL.'
                        : 'A CDN is present in front of this site (the header exists) but this specific response was not a cache hit. Still worth excluding /directory/ from caching in the CDN dashboard to prevent a future cached copy from going stale.',
                    'This is a different, more specific signal than just "no WordPress caching plugin detected" — a CDN sits in front of WordPress entirely and would not be visible to that earlier check.' );
            } else {
                $findings[] = self::finding( self::SRC_NETWORK, 'directory_no_cdn_cache_header', self::SEV_INFO,
                    'No CDN/edge-cache header (cf-cache-status, x-cache) was found on this response. Cache-Control sent: "' . esc_html( (string) $cache_control ) . '".',
                    'No CDN-level caching detected on this specific request. If the live page is still empty for real visitors while this diagnostic shows correct data, the remaining likely causes are: a CDN that does not announce itself via these headers, a hosting-provider-level cache invisible to HTTP headers, or — given this request bypassed any browser cache by design — a genuine difference between how this server-side request and a real browser request are routed (e.g. a load balancer sending them to different backend servers with different data).',
                    'N/A' );
            }

            if ( (int) $code !== 200 ) {
                $findings[] = self::finding( self::SRC_NETWORK, 'directory_http_bad_status', self::SEV_CRITICAL,
                    "GET {$directory_url} returned HTTP {$code}, not 200.",
                    $code >= 300 && $code < 400 ? 'The page is redirecting somewhere else — check the Location header / redirect target.' : 'Check the server error log for what is causing this status code.',
                    'A non-200 response on a genuine first visit would itself explain an apparently empty page.' );
            } else {
                $has_results_container = str_contains( $body, 'gd4-results-list' );
                // NOTE: counting '<!-- .gd4-card -->' rather than the bare
                // class name — 'gd4-card' is always present via the page's
                // own CSS rule (.gd4-card {...}) regardless of whether any
                // real listing exists, which meant this check could never
                // actually detect a genuinely empty results list.
                $has_listing_card      = str_contains( $body, '<!-- .gd4-card -->' );
                $has_footer            = str_contains( $body, 'gd4-footer' );
                $has_footer_css_rule   = str_contains( $body, '.gd4-footer{' ) || str_contains( $body, '.gd4-footer {' );

                if ( ! $has_results_container ) {
                    $findings[] = self::finding( self::SRC_WP, 'directory_html_missing_container', self::SEV_CRITICAL,
                        "The raw HTML response for {$directory_url} does NOT contain the results container (gd4-results-list) at all. The page being served is NOT templates/pages/archive.php — a different template, theme page, or cached snapshot is being returned instead.",
                        'Check Settings → Permalinks → Save to flush rewrite rules. Check for a caching plugin or CDN serving a stale/wrong page for this exact URL. Check whether a WordPress Page with slug "directory" exists and is using the theme template instead of being intercepted by the GS router.',
                        'CONFIRMED via live HTTP request: whatever IS rendering for visitors at this URL is not the code being analysed in this report — any fix to archive.php would have zero effect until this routing/caching issue is resolved.' );
                } elseif ( ! $has_listing_card ) {
                    $findings[] = self::finding( self::SRC_WP, 'directory_html_empty_results', self::SEV_CRITICAL,
                        "The results container IS present in the raw HTML, but contains ZERO listing cards (no 'gd4-card' found) on this genuine, cookie-less first request.",
                        'This confirms the empty-results behaviour is server-side, present in the very first byte stream sent — not a JS/browser rendering issue. Cross-reference with the directory_query_ok / directory_zero_active_listings finding above for the specific data-level cause.',
                        'CONFIRMED via live HTTP request: a true first-time visitor (no cookies, no JS) receives zero listing cards in the initial HTML. This is NOT explainable by browser caching, JS timing, or CSS — the server itself sent no cards.' );
                } else {
                    $findings[] = self::finding( self::SRC_WP, 'directory_html_has_listings', self::SEV_INFO,
                        "CONFIRMED via live HTTP request: the raw first-load HTML DOES contain the results container and at least one listing card. If listings still appear empty in a real browser, the cause is downstream of the server response — check browser console for JS errors, and check for a caching plugin/CDN serving a DIFFERENT cached response to real visitors than what this server-side request just received (this request bypassed any browser/CDN cache).",
                        'Compare this finding with what a real browser actually shows — if they differ, a CDN or caching layer between the visitor and this server is the most likely remaining explanation.',
                        'N/A' );
                }

                if ( ! $has_footer ) {
                    $findings[] = self::finding( self::SRC_WP, 'directory_html_missing_footer', self::SEV_CRITICAL,
                        "The raw HTML response does NOT contain the footer markup (gd4-footer) at all — not a CSS/visibility issue, the footer HTML itself is absent from the response.",
                        'The page is likely being cut off mid-render (a PHP fatal/timeout partway through archive.php before reaching the footer section), or a different template without this footer is being served.',
                        'CONFIRMED: the footer cannot be "invisible due to CSS" if its markup was never sent in the first place — check the PHP error log for a fatal error or timeout during this page render.' );
                } elseif ( ! $has_footer_css_rule ) {
                    $findings[] = self::finding( self::SRC_WP, 'directory_html_footer_no_css', self::SEV_CRITICAL,
                        'The footer markup (gd4-footer) IS present in the response, but its defining CSS rule (.gd4-footer) was NOT found in the same response — the style block containing it may have been truncated or is not present.',
                        'Check whether the single style block in archive.php is being fully sent — a truncated response (check Content-Length vs actual bytes received) or a PHP error partway through the style block output would explain text rendering with browser-default (invisible-looking) styling.',
                        'CONFIRMED: the footer text would render in unstyled, default black-on-transparent text if this CSS rule never reached the browser — against the footer\'s dark background, default black text would be very hard to see, matching "footer text not visible."' );
                } else {
                    $findings[] = self::finding( self::SRC_WP, 'directory_html_footer_ok', self::SEV_INFO,
                        'CONFIRMED via live HTTP request: both the footer markup and its CSS rule are present in the raw HTML response.',
                        'If the footer still looks invisible in a real browser, check for a browser extension, ad-blocker, or a theme/plugin stylesheet loaded AFTER this page that overrides .gd4-footer text color — inspect the footer text element directly and check the "Computed" styles tab for which rule is actually winning.',
                        'N/A' );
                }
            }
        }

        // ── Direct GET vs AJAX comparison — tests the EXACT reported
        //    symptom: "plain reload shows nothing, clicking the 'All'
        //    filter button immediately shows listings." Both code paths
        //    use the same effective filter values (none/empty) on a clean
        //    URL, so if they disagree right now, it proves a real
        //    divergence between archive.php's own page-render query and
        //    AjaxController::directoryFilter()'s query — not something
        //    that can be explained by a stale cache or CDN, since both
        //    requests are made fresh, back to back, from this same check.
        if ( ! is_wp_error( $response ) && (int) wp_remote_retrieve_response_code( $response ) === 200 ) {
            // NOTE: counting the literal closing comment '<!-- .gd4-card -->'
            // rather than the bare class name 'gd4-card' — the bare string
            // also matches CSS rules, hover-state selectors, and the
            // client-side JS card-builder's template strings, none of which
            // represent an actual rendered card. The closing comment is
            // emitted exactly once per real PHP-rendered card and nowhere
            // else in the codebase (verified: zero occurrences in any
            // <script> block or CSS rule).
            $page_card_count = substr_count( wp_remote_retrieve_body( $response ), '<!-- .gd4-card -->' );

            try {
                $ajax_response = wp_remote_post( admin_url( 'admin-ajax.php' ), [
                    'timeout'   => 5,
                    'sslverify' => false,
                    'body'      => [ 'action' => 'gs_directory_filter' ], // every filter field deliberately omitted = same "no filters" state as clicking "All"
                    'cookies'   => [],
                ] );
            } catch ( \Throwable $e ) {
                $ajax_response = new \WP_Error( 'gs_diag_exception', $e->getMessage() );
            }

            if ( is_wp_error( $ajax_response ) ) {
                $findings[] = self::finding( self::SRC_NETWORK, 'directory_ajax_compare_failed', self::SEV_WARNING,
                    'Could not call gs_directory_filter directly to compare against the page-load query: ' . $ajax_response->get_error_message(),
                    'This comparison could not run — not itself evidence of a problem.',
                    'N/A' );
            } else {
                $ajax_body = wp_remote_retrieve_body( $ajax_response );
                $ajax_json = json_decode( $ajax_body, true );
                $ajax_listing_count = is_array( $ajax_json ) && isset( $ajax_json['data']['listings'] )
                    ? count( (array) $ajax_json['data']['listings'] )
                    : null;

                if ( $ajax_listing_count === null ) {
                    $findings[] = self::finding( self::SRC_NETWORK, 'directory_ajax_compare_unparseable', self::SEV_WARNING,
                        'Called gs_directory_filter directly with no filters, but could not find a "listings" array in the JSON response to count. Raw response (first 300 chars): ' . esc_html( substr( $ajax_body, 0, 300 ) ),
                        'The AJAX response shape may differ from what this check expects — check AjaxController::directoryFilter()\'s actual response keys.',
                        'N/A' );
                } elseif ( $page_card_count === 0 && $ajax_listing_count > 0 ) {
                    $findings[] = self::finding( self::SRC_WP, 'directory_get_vs_ajax_mismatch', self::SEV_CRITICAL,
                        "CONFIRMED, RIGHT NOW: a plain GET to /directory/ (no filters, exactly what a page reload sends) returns {$page_card_count} listing card(s) in its HTML, while calling gs_directory_filter directly with no filters (exactly what the \"All\" button triggers) returns {$ajax_listing_count} listing(s). These two requests, made seconds apart with identical (empty) filter state, disagree. This is a genuine divergence between archive.php's page-render query and AjaxController::directoryFilter()'s query — not a cache or CDN issue, since both requests were made fresh just now.",
                        'Compare the two WHERE-clause constructions line by line: templates/pages/archive.php (around the $where array near the top of the file) versus AjaxController::directoryFilter() (the $where array near its start). Look specifically for a condition that is unconditional in one but correctly guarded in the other.',
                        'This is the single most direct, live confirmation of the exact symptom reported — not inferred from a single static check, but from two real requests compared against each other in the same moment.' );
                } else {
                    $findings[] = self::finding( self::SRC_WP, 'directory_get_vs_ajax_consistent', self::SEV_INFO,
                        "Right now, a plain GET to /directory/ returns {$page_card_count} card(s), and gs_directory_filter with no filters returns {$ajax_listing_count} listing(s). Consistent at this exact moment.",
                        'If the reported symptom (reload empty, "All" button fixes it) recurs, re-run this scan again immediately when it happens — this specific divergence may be intermittent or timing-dependent rather than constant.',
                        'N/A' );
                }
            }
        }

        // ── Page-caching plugin detection — the single most likely
        //    explanation for "listings only appear after a filter click."
        //    nocache_headers() (called for this exact page — confirmed in
        //    Router.php) only sets HTTP response headers; it does nothing
        //    to stop a PAGE-CACHING plugin that intercepts the request
        //    BEFORE WordPress/this plugin's router code even runs, serving
        //    a static, pre-rendered HTML file from disk instead. AJAX POST
        //    requests to admin-ajax.php are essentially never cached by
        //    these plugins (they don't match the cacheable-GET pattern),
        //    so the city-filter AJAX call always hits fresh PHP and always
        //    works — while the first GET to /directory/ can serve a STALE
        //    snapshot captured before listings existed, or from a
        //    different filter state, with zero relationship to what the
        //    live PHP/SQL would actually return right now.
        $active_plugins = get_option( 'active_plugins', [] );
        $known_cache_plugins = [
            'wp-super-cache/wp-cache.php'                 => 'WP Super Cache',
            'w3-total-cache/w3-total-cache.php'           => 'W3 Total Cache',
            'wp-rocket/wp-rocket.php'                     => 'WP Rocket',
            'litespeed-cache/litespeed-cache.php'         => 'LiteSpeed Cache',
            'wp-fastest-cache/wpFastestCache.php'         => 'WP Fastest Cache',
            'cache-enabler/cache-enabler.php'             => 'Cache Enabler',
            'comet-cache/comet-cache.php'                 => 'Comet Cache',
            'sg-cachepress/sg-cachepress.php'             => 'SiteGround Optimizer (SG CachePress)',
            'breeze/breeze.php'                           => 'Breeze (Cloudways)',
        ];
        $found_cache_plugins = [];
        foreach ( $known_cache_plugins as $plugin_file => $plugin_name ) {
            if ( in_array( $plugin_file, $active_plugins, true ) ) { $found_cache_plugins[] = $plugin_name; }
        }
        // WP_CACHE is the standard constant nearly every page-cache plugin
        // defines in wp-config.php, even if the specific plugin above
        // isn't in the known list (custom/host-level caching).
        $wp_cache_constant = defined( 'WP_CACHE' ) && WP_CACHE;

        if ( $found_cache_plugins || $wp_cache_constant ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'directory_page_cache_risk', self::SEV_CRITICAL,
                'A page-caching mechanism is active on this site: ' .
                ( $found_cache_plugins ? implode( ', ', $found_cache_plugins ) : '' ) .
                ( $wp_cache_constant ? ( $found_cache_plugins ? ' (and WP_CACHE constant is also set)' : 'WP_CACHE constant is set in wp-config.php' ) : '' ) .
                '. This can serve a STALE, pre-rendered snapshot of /directory/ to first-time visitors, completely bypassing this plugin\'s nocache_headers() call (which only sets HTTP response headers — it cannot stop a page cache that intercepts the request before WordPress routing even runs).',
                'In the caching plugin\'s settings, add /directory/ and /directory/* to its page-cache EXCLUSION / "never cache" list. Then purge/clear the existing cache for this URL specifically. This is a configuration change in the CACHING PLUGIN, not a code fix in GoodService — no amount of editing archive.php can fix a cached page being served instead of it.',
                'CONFIRMED MATCH for the reported symptom: a city-filter click always uses an AJAX POST to admin-ajax.php, which page-caching plugins virtually never cache — so it always hits fresh PHP and always shows correct results, while the plain GET to /directory/ can be served entirely from a stale cached file, explaining the exact asymmetry reported ("works after I click a filter, not on first load").' );
        } else {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'directory_no_cache_plugin_detected', self::SEV_INFO,
                'No known page-caching plugin detected in active_plugins, and the WP_CACHE constant is not set.',
                'If listings still only appear after a filter click, the cause is more likely a CDN/reverse-proxy cache in front of the server (Cloudflare, hosting-provider-level caching) rather than a WordPress plugin — check your hosting control panel and any CDN dashboard for a page-rule caching /directory/.',
                'N/A' );
        }

        return $findings;
    }

    private static function check_php_environment(): array {
        $findings = [];

        // PHP version
        if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
            $findings[] = self::finding( self::SRC_PHP, 'php_version', self::SEV_CRITICAL,
                'PHP ' . PHP_VERSION . ' detected — GoodService requires PHP 8.0+',
                'Upgrade PHP to 8.0 or higher. Contact your hosting provider.',
                'Server is running unsupported PHP version. Security patches may not be applied.' );
        } elseif ( version_compare( PHP_VERSION, '8.2', '<' ) ) {
            $findings[] = self::finding( self::SRC_PHP, 'php_version', self::SEV_WARNING,
                'PHP ' . PHP_VERSION . ' detected — PHP 8.2+ is recommended for best performance',
                'Consider upgrading to PHP 8.2+ for better performance and security.',
                'PHP 8.2 includes significant performance improvements and security fixes.' );
        }

        // Memory limit
        $mem = self::parse_bytes( ini_get( 'memory_limit' ) );
        if ( $mem < 128 * 1024 * 1024 ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'memory_limit', self::SEV_CRITICAL,
                'PHP memory_limit is ' . ini_get( 'memory_limit' ) . ' — minimum 128M required',
                "Add define('WP_MEMORY_LIMIT', '256M') to wp-config.php. Ask hosting to increase PHP memory_limit.",
                'Low memory limit will cause fatal errors on complex operations.' );
        } elseif ( $mem < 256 * 1024 * 1024 ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'memory_limit', self::SEV_WARNING,
                'PHP memory_limit is ' . ini_get( 'memory_limit' ) . ' — 256M recommended',
                "Add define('WP_MEMORY_LIMIT', '256M') to wp-config.php.",
                'May cause memory exhaustion on heavy operations like PDF generation or image processing.' );
        }

        // post_max_size
        $post = self::parse_bytes( ini_get( 'post_max_size' ) );
        if ( $post < 8 * 1024 * 1024 ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'post_max_size', self::SEV_ERROR,
                'PHP post_max_size is ' . ini_get( 'post_max_size' ) . ' — 32M recommended',
                'Increase post_max_size to 32M in php.ini or .htaccess (php_value post_max_size 32M).',
                'Large form submissions and file uploads will fail silently.' );
        }

        // upload_max_filesize
        $upl = self::parse_bytes( ini_get( 'upload_max_filesize' ) );
        if ( $upl < 8 * 1024 * 1024 ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'upload_max_filesize', self::SEV_ERROR,
                'PHP upload_max_filesize is ' . ini_get( 'upload_max_filesize' ) . ' — 16M recommended',
                'Increase upload_max_filesize in php.ini. Also increase post_max_size to match.',
                'Image and document uploads will fail for files larger than ' . ini_get( 'upload_max_filesize' ) . '.' );
        }

        // max_input_vars
        $miv = (int) ini_get( 'max_input_vars' );
        if ( $miv > 0 && $miv < 1000 ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'max_input_vars', self::SEV_WARNING,
                'PHP max_input_vars is ' . $miv . ' — 1000+ recommended for complex forms',
                'Add php_value max_input_vars 3000 to .htaccess or php.ini.',
                'Form fields beyond this limit are silently truncated, causing data loss in large form submissions.' );
        }

        // max_execution_time
        $met = (int) ini_get( 'max_execution_time' );
        if ( $met > 0 && $met < 30 ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'max_execution_time', self::SEV_WARNING,
                'PHP max_execution_time is ' . $met . 's — operations like PDF generation may timeout',
                'Increase max_execution_time to 120s in php.ini.',
                'Background tasks, imports, and report generation may fail with timeout errors.' );
        }

        // WP uploads dir
        $upload_dir = wp_upload_dir();
        if ( ! empty( $upload_dir['error'] ) ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'uploads_dir', self::SEV_CRITICAL,
                'WordPress uploads directory error: ' . $upload_dir['error'],
                'Check directory permissions: chmod 755 wp-content/uploads. Verify the directory exists.',
                'All file uploads and media attachments will fail.' );
        } elseif ( ! is_writable( $upload_dir['basedir'] ) ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'uploads_dir', self::SEV_CRITICAL,
                'Uploads directory is not writable: ' . $upload_dir['basedir'],
                'Run: chown -R www-data:www-data ' . $upload_dir['basedir'],
                'All file uploads will fail with permission denied errors.' );
        }

        // Disk space (try to check free space)
        if ( function_exists( 'disk_free_space' ) ) {
            $free = @disk_free_space( ABSPATH );
            if ( $free !== false && $free < 100 * 1024 * 1024 ) {
                $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'disk_space', self::SEV_CRITICAL,
                    'Disk space critically low: only ' . round( $free / 1024 / 1024, 1 ) . 'MB free',
                    'Delete old log files, clear WordPress cache, and consider expanding disk space immediately.',
                    'File uploads, logging, and caching will fail when disk is full.' );
            } elseif ( $free !== false && $free < 500 * 1024 * 1024 ) {
                $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'disk_space', self::SEV_WARNING,
                    'Disk space low: ' . round( $free / 1024 / 1024, 1 ) . 'MB free',
                    'Monitor disk usage. Set up disk usage alerts. Clear unnecessary files.',
                    'Risk of disk-full errors in the near future.' );
        }
        }

        // WP_DEBUG in production
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG && ! ( defined( 'WP_DEBUG_DISPLAY' ) && ! WP_DEBUG_DISPLAY ) ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'wp_debug_display', self::SEV_ERROR,
                'WP_DEBUG and WP_DEBUG_DISPLAY are both enabled — PHP errors are visible to site visitors',
                "Add define('WP_DEBUG_DISPLAY', false); to wp-config.php. Enable WP_DEBUG_LOG instead.",
                'PHP error details expose file paths, code structure, and internal logic to attackers.' );
        }

        // Required PHP extensions
        $required_exts = [ 'json', 'mbstring', 'openssl', 'curl', 'gd', 'pdo', 'mysqli' ];
        foreach ( $required_exts as $ext ) {
            if ( ! extension_loaded( $ext ) ) {
                $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'php_extension', self::SEV_ERROR,
                    "Required PHP extension '{$ext}' is not loaded",
                    "Install the {$ext} extension: apt-get install php-{$ext} (Ubuntu) or enable in php.ini.",
                    "Features depending on {$ext} will fail. This may include image processing, encryption, or database connectivity." );
            }
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 5: Database checks
    // ════════════════════════════════════════════════════════════════════════

    private static function check_database(): array {
        global $wpdb;
        $findings = [];
        $p        = $wpdb->prefix . 'gs_';

        // Connection check
        if ( ! $wpdb->check_connection( false ) ) {
            $findings[] = self::finding( self::SRC_DB, 'db_connection', self::SEV_CRITICAL,
                'Database connection failed',
                'Check DB_HOST, DB_NAME, DB_USER, DB_PASSWORD in wp-config.php. Verify MySQL is running.',
                'Complete site failure — all pages will show database connection errors.' );
            return $findings; // can't run further DB checks
        }

        // MySQL version
        $mysql_ver = $wpdb->get_var( 'SELECT VERSION()' );
        if ( $mysql_ver && version_compare( $mysql_ver, '5.7', '<' ) ) {
            $findings[] = self::finding( self::SRC_DB, 'mysql_version', self::SEV_WARNING,
                "MySQL/MariaDB version {$mysql_ver} detected — 5.7+ required, 8.0+ recommended",
                'Upgrade database server to MySQL 8.0+ or MariaDB 10.4+.',
                'Older versions lack performance features and may have security vulnerabilities.' );
        }

        // Check all required GoodService tables exist
        $required_tables = [
            'vendor_profiles', 'listings', 'categories', 'leads', 'bookings',
            'subscription_plans', 'subscriptions', 'reviews', 'notifications',
            'settings', 'email_templates', 'activity_log', 'error_log', 'diag_runs',
        ];
        foreach ( $required_tables as $tname ) {
            $full = $p . $tname;
            $exists = $wpdb->get_var( "SHOW TABLES LIKE '{$full}'" );
            if ( ! $exists ) {
                $findings[] = self::finding( self::SRC_DB, 'missing_table', self::SEV_CRITICAL,
                    "Required table `{$full}` does not exist",
                    'Go to Admin → Tools → DB Upgrade to run the schema installer.',
                    "All features using this table will fail with \"table doesn't exist\" errors." );
            }
        }

        // Check required columns in gs_listings
        $listings_tbl = $p . 'listings';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$listings_tbl}'" ) ) {
            $existing_cols = $wpdb->get_col( "SHOW COLUMNS FROM `{$listings_tbl}`", 0 ) ?: [];
            $required_cols = [
                'hero_data', 'about_data', 'items_data', 'customizer_data',
                'mobile_data', 'inquiry_modules_data',
                'avg_rating', 'review_count', 'views_count',
            ];
            foreach ( $required_cols as $col ) {
                if ( ! in_array( $col, $existing_cols, true ) ) {
                    $findings[] = self::finding( self::SRC_DB, 'missing_column', self::SEV_ERROR,
                        "Column `{$col}` missing from `{$listings_tbl}`",
                        'Run Admin → Tools → DB Upgrade to add missing columns via upgrade_columns().',
                        "INSERT/UPDATE queries referencing {$col} will fail with Unknown column error." );
                }
            }
        }

        // Check for slow queries (query monitor approach — count long-running queries)
        if ( defined( 'SAVEQUERIES' ) && SAVEQUERIES && ! empty( $wpdb->queries ) ) {
            foreach ( $wpdb->queries as $q ) {
                if ( isset( $q[1] ) && (float) $q[1] > 1.0 ) {
                    $findings[] = self::finding( self::SRC_DB, 'slow_query', self::SEV_WARNING,
                        'Slow query detected (' . round( (float) $q[1], 3 ) . 's): ' . substr( $q[0], 0, 200 ),
                        'Add indexes to WHERE/JOIN/ORDER BY columns. Run EXPLAIN on the query.',
                        'Slow queries increase page load times and block the MySQL thread pool.' );
                }
            }
        }

        // Check table indexes exist for gs_error_log and gs_diag_runs
        $idx_tables = [ 'error_log', 'diag_runs', 'bookings', 'leads', 'listings' ];
        foreach ( $idx_tables as $tn ) {
            $full = $p . $tn;
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$full}'" ) ) {
                $idx_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '{$full}'" );
                if ( $idx_count <= 1 ) { // Only PRIMARY
                    $findings[] = self::finding( self::SRC_DB, 'missing_indexes', self::SEV_WARNING,
                        "Table `{$full}` appears to have no secondary indexes",
                        'Review Schema.php and ensure indexes are created for high-frequency query columns.',
                        'Queries on this table will perform full table scans, degrading with data volume.' );
                }
            }
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 6: WordPress-specific checks
    // ════════════════════════════════════════════════════════════════════════

    private static function check_wordpress(): array {
        $findings = [];

        // WordPress version
        global $wp_version;
        if ( version_compare( $wp_version, '6.0', '<' ) ) {
            $findings[] = self::finding( self::SRC_WP, 'wp_version', self::SEV_ERROR,
                "WordPress {$wp_version} detected — GoodService requires WordPress 6.0+",
                'Update WordPress to the latest version via Dashboard → Updates.',
                'Older WordPress versions have known security vulnerabilities and API incompatibilities.' );
        }

        // Check plugin roles are registered
        $gs_vendor_role = get_role( 'gs_vendor' );
        if ( ! $gs_vendor_role ) {
            $findings[] = self::finding( self::SRC_WP, 'missing_role', self::SEV_CRITICAL,
                "Custom role 'gs_vendor' is not registered",
                'Deactivate and reactivate the GoodService plugin to re-run Roles::register().',
                'Vendors cannot register or log in. All vendor functionality is broken.' );
        }

        // Check custom pages exist
        $required_pages = [
            'vendor-dashboard' => 'Vendor Dashboard',
            'gs-home'          => 'GoodService Home',
            'admin-panel'      => 'Admin Panel',
        ];
        foreach ( $required_pages as $slug => $label ) {
            $page = get_page_by_path( $slug );
            if ( ! $page ) {
                $findings[] = self::finding( self::SRC_WP, 'missing_page', self::SEV_ERROR,
                    "Required page '{$label}' (slug: {$slug}) does not exist",
                    'Go to Admin → Tools and click "Create Platform Pages" to recreate missing pages.',
                    "The {$label} will show a 404 error for all users." );
            }
        }

        // Check permalink structure
        $permalink_struct = get_option( 'permalink_structure' );
        if ( empty( $permalink_struct ) ) {
            $findings[] = self::finding( self::SRC_WP, 'permalink_structure', self::SEV_CRITICAL,
                'WordPress permalink structure is set to "Plain" — custom routes will not work',
                'Go to Settings → Permalinks and select "Post name" or any non-plain structure.',
                'All custom GoodService URLs (/directory/, /vendor/dashboard/, etc.) will show 404.' );
        }

        // Check if WP Cron is disabled
        if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
            // This is actually OK if real cron is set up, but flag as notice
            $findings[] = self::finding( self::SRC_WP, 'wp_cron_disabled', self::SEV_NOTICE,
                'WP_CRON is disabled. Ensure a real cron job fires wp-cron.php every 5 minutes.',
                'Add to server cron: */5 * * * * curl -s ' . site_url( '/wp-cron.php?doing_wp_cron' ),
                'Booking reminders, waitlist notifications, and subscription expiry will not run if real cron is not configured.' );
        }

        // Check for plugin conflicts (other booking plugins that might conflict)
        $active_plugins = get_option( 'active_plugins', [] );
        $conflict_plugins = [
            'woocommerce-bookings/woocommerce-bookings.php'  => 'WooCommerce Bookings',
            'latepoint/latepoint.php'                        => 'LatePoint',
            'bookly-responsive-appointment-booking-tool/main.php' => 'Bookly',
        ];
        foreach ( $conflict_plugins as $plugin_file => $plugin_name ) {
            if ( in_array( $plugin_file, $active_plugins, true ) ) {
                $findings[] = self::finding( self::SRC_WP, 'plugin_conflict', self::SEV_WARNING,
                    "Potential conflict: {$plugin_name} is active alongside GoodService",
                    "Test thoroughly for hook conflicts, especially on booking and listing pages. Deactivate {$plugin_name} if conflicts occur.",
                    "Booking functionality, REST API endpoints, or template loading may conflict." );
            }
        }

        // Check GoodService settings are populated
        global $wpdb;
        $platform_name = $wpdb->get_var( $wpdb->prepare(
            "SELECT setting_value FROM {$wpdb->prefix}gs_settings WHERE setting_key=%s", 'platform_name'
        ) );
        if ( ! $platform_name ) {
            $findings[] = self::finding( self::SRC_WP, 'missing_settings', self::SEV_ERROR,
                'GoodService platform settings are not initialized',
                'Run Admin → Tools → Seed Demo Data to initialize default settings.',
                'Platform name, email, and other required settings will be empty, causing broken emails and UI.' );
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 7: Performance checks
    // ════════════════════════════════════════════════════════════════════════

    private static function check_performance(): array {
        $findings = [];

        // Object caching
        if ( ! wp_using_ext_object_cache() ) {
            $findings[] = self::finding( self::SRC_PERFORMANCE, 'no_object_cache', self::SEV_WARNING,
                'WordPress object cache is not using an external backend (Redis/Memcached)',
                'Install and configure Redis or Memcached with a WP object cache plugin (Redis Object Cache).',
                'All transient/option reads hit the database. Performance degrades significantly at scale.' );
        }

        // Memory usage
        $mem_used  = memory_get_usage( true );
        $mem_limit = self::parse_bytes( ini_get( 'memory_limit' ) );
        if ( $mem_limit > 0 && $mem_used > $mem_limit * 0.85 ) {
            $findings[] = self::finding( self::SRC_PERFORMANCE, 'memory_usage', self::SEV_WARNING,
                'Memory usage is at ' . round( $mem_used / 1024 / 1024, 1 ) . 'MB — ' . round( $mem_used / $mem_limit * 100, 0 ) . '% of limit',
                'Increase memory_limit or optimize memory-heavy operations.',
                'Approaching memory limit. Fatal out-of-memory errors likely on complex operations.' );
        }

        // Check for very large transients
        global $wpdb;
        $large_transients = $wpdb->get_results(
            "SELECT option_name, LENGTH(option_value) as size_bytes
             FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_%'
               AND LENGTH(option_value) > 102400
             LIMIT 5"
        );
        foreach ( $large_transients ?? [] as $tr ) {
            $findings[] = self::finding( self::SRC_PERFORMANCE, 'large_transient', self::SEV_NOTICE,
                "Large transient detected: {$tr->option_name} (" . round( $tr->size_bytes / 1024, 1 ) . 'KB)',
                'Review what data is cached in this transient. Consider chunking or compressing the data.',
                'Large transients slow down WordPress option autoloading and increase memory usage.' );
        }

        // Check autoloaded options size
        $autoload_size = $wpdb->get_var(
            "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE autoload='yes'"
        );
        if ( $autoload_size > 1024 * 1024 ) {
            $findings[] = self::finding( self::SRC_PERFORMANCE, 'autoloaded_options', self::SEV_WARNING,
                'WordPress autoloaded options total ' . round( (float) $autoload_size / 1024, 0 ) . 'KB — every page load reads this',
                'Set large options to autoload=no: $wpdb->update($wpdb->options, ["autoload"=>"no"], ["option_name"=>"large_option_name"]).',
                'Large autoloaded options add ' . round( (float) $autoload_size / 1024 / 1024, 2 ) . 'MB to every page load database query.' );
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 8: Security checks
    // ════════════════════════════════════════════════════════════════════════

    private static function check_security(): array {
        $findings = [];

        // WP_DEBUG_DISPLAY check (already in PHP checks but also a security issue)
        if ( ! defined( 'WP_HTTPS' ) && ! is_ssl() && isset( $_SERVER['HTTP_HOST'] ) ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'no_https', self::SEV_ERROR,
                'Site is not running over HTTPS — all data transmitted in plain text',
                '1. Install an SSL certificate (free via Let\'s Encrypt). 2. Force HTTPS in .htaccess. 3. Update WordPress Site URL to https://.',
                'Vendor passwords, payment data, and customer PII transmitted without encryption.' );
        }

        // Check for debug log in public location
        $debug_log = WP_CONTENT_DIR . '/debug.log';
        if ( file_exists( $debug_log ) ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'debug_log_exposed', self::SEV_WARNING,
                'wp-content/debug.log exists and may be publicly accessible',
                'Add "deny from all" rule for debug.log in wp-content/.htaccess or move log to a non-public directory.',
                'Debug logs contain file paths, error messages, and internal code details visible to attackers.' );
        }

        // Check GS diagnostic log public accessibility
        $diag_log = WP_CONTENT_DIR . '/gs-diag.log';
        if ( file_exists( $diag_log ) ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'diag_log_exposed', self::SEV_WARNING,
                'gs-diag.log exists in wp-content — may be publicly accessible',
                'Add protection: echo \'<Files "gs-diag.log">\' to wp-content/.htaccess with deny from all.',
                'Diagnostic logs may contain user IDs, request data, and internal details.' );
        }

        // Check file permissions on sensitive files
        $sensitive_files = [ ABSPATH . 'wp-config.php', ABSPATH . '.htaccess' ];
        foreach ( $sensitive_files as $sf ) {
            if ( file_exists( $sf ) ) {
                $perms = substr( sprintf( '%o', fileperms( $sf ) ), -4 );
                if ( in_array( $perms, [ '0777', '0666', '0664' ], true ) ) {
                    $findings[] = self::finding( self::SRC_SECURITY, 'insecure_file_permissions', self::SEV_CRITICAL,
                        "Insecure permissions ({$perms}) on " . basename( $sf ),
                        'Run: chmod 600 ' . $sf . ' (for wp-config.php) or chmod 644 (for .htaccess).',
                        'World-writable sensitive files can be modified by any process on the server.' );
                }
            }
        }

        // Check recent auth failures
        global $wpdb;
        $recent_failures = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gs_error_log
             WHERE source=%s AND type=%s
               AND last_seen >= DATE_SUB(NOW(), INTERVAL 1 HOUR)",
            self::SRC_SECURITY, 'auth_failure'
        ) );
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_error_log'" ) && $recent_failures >= 10 ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'brute_force', self::SEV_CRITICAL,
                "{$recent_failures} authentication failures in the last hour — possible brute force attack",
                '1. Enable login rate limiting. 2. Block the attacking IP at firewall/CDN level. 3. Enable 2FA. 4. Notify admin.',
                'Attacker may gain unauthorized access to vendor/admin accounts.' );
        }

        // Check for admin accounts with weak roles
        $admin_users = get_users( [ 'role' => 'administrator', 'fields' => [ 'ID', 'user_email' ] ] );
        if ( count( $admin_users ) > 5 ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'excessive_admins', self::SEV_WARNING,
                count( $admin_users ) . ' administrator accounts detected — principle of least privilege violated',
                'Review administrator accounts and downgrade those that do not need full access.',
                'Each administrator account is a potential breach point. Excess admins increase attack surface.' );
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 10: Integration checks
    // ════════════════════════════════════════════════════════════════════════

    private static function check_integrations(): array {
        $findings = [];

        // Razorpay configuration
        $rzp_key = Config::get( 'razorpay_key_id', '' );
        $rzp_sec = Config::get( 'razorpay_key_secret', '' );
        if ( empty( $rzp_key ) || empty( $rzp_sec ) ) {
            $findings[] = self::finding( self::SRC_INTEGRATION, 'razorpay_unconfigured', self::SEV_WARNING,
                'Razorpay payment gateway is not configured (no API keys)',
                'Add Razorpay Key ID and Key Secret in Admin → Settings → Payments.',
                'Online payments for subscriptions and booking deposits are not functional.' );
        } elseif ( strlen( $rzp_key ) < 20 ) {
            $findings[] = self::finding( self::SRC_INTEGRATION, 'razorpay_key_format', self::SEV_ERROR,
                'Razorpay Key ID appears too short — may be invalid',
                'Verify the Key ID in your Razorpay dashboard. It should start with rzp_live_ or rzp_test_.',
                'Payment order creation will fail, blocking all subscription upgrades.' );
        }

        // WhatsApp BSP configuration
        $wa_enabled = Config::get( 'whatsapp_enabled', false );
        $wa_key     = Config::get( 'whatsapp_api_key', '' );
        if ( $wa_enabled && empty( $wa_key ) ) {
            $findings[] = self::finding( self::SRC_INTEGRATION, 'whatsapp_key_missing', self::SEV_ERROR,
                'WhatsApp is enabled but API key is empty',
                'Add the WhatsApp BSP API key in Admin → Settings → WhatsApp, or disable WhatsApp.',
                'All booking confirmation and reminder WhatsApp messages will fail silently.' );
        }

        // SMS configuration
        $sms_provider = Config::get( 'sms_provider', '' );
        $sms_key      = Config::get( 'sms_api_key', '' );
        $otp_enabled  = Config::get( 'booking_otp_enabled', '0' );
        if ( $otp_enabled === '1' && ( empty( $sms_provider ) || empty( $sms_key ) ) ) {
            $findings[] = self::finding( self::SRC_INTEGRATION, 'otp_sms_unconfigured', self::SEV_ERROR,
                'OTP verification is enabled but no SMS provider is configured',
                'Add SMS provider and API key in Admin → Settings → SMS/OTP, or disable OTP.',
                'Booking OTP verification will fail for users without an email address, blocking bookings.' );
        }

        // Email configuration check
        $admin_email = get_option( 'admin_email', '' );
        if ( empty( $admin_email ) || ! is_email( $admin_email ) ) {
            $findings[] = self::finding( self::SRC_INTEGRATION, 'email_unconfigured', self::SEV_ERROR,
                'WordPress admin email is not set or invalid: "' . $admin_email . '"',
                'Go to Settings → General and set a valid admin email address.',
                'System notification emails (deletion requests, stuck bookings, admin alerts) will fail.' );
        }

        // Check Anthropic API key for AI features
        $ai_key = Config::get( 'anthropic_api_key', '' ) ?: Config::get( 'gs_anthropic_api_key', '' );
        if ( empty( $ai_key ) ) {
            $findings[] = self::finding( self::SRC_INTEGRATION, 'ai_key_missing', self::SEV_NOTICE,
                'Anthropic API key not configured — AI features will be disabled',
                'Add the Anthropic API key in Admin → Settings to enable AI reply drafting and AI concierge search.',
                'AI-powered features (reply drafting, quote generation, concierge search) will not function.' );
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 8-B: Security headers scan (§8 gap — CSP/HSTS/X-Frame/etc.)
    // ════════════════════════════════════════════════════════════════════════

    private static function check_security_headers(): array {
        $findings = [];
        $site_url = site_url();

        // Make a HEAD request to the site to check response headers
        $response = wp_remote_head( $site_url, [
            'timeout'   => 8,
            'sslverify' => false,
            'headers'   => [ 'User-Agent' => 'GoodService-Diagnostics/1.0' ],
        ] );

        if ( is_wp_error( $response ) ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'self_request_failed', self::SEV_WARNING,
                'Could not make a self-request to check security headers: ' . $response->get_error_message(),
                'Verify the site is accessible from the server. Check loopback request restrictions.',
                'Some hosting environments block loopback HTTP requests. Security header audit could not run.',
                [ 'affected_modules' => ['Security Headers'] ] );
            return $findings;
        }

        $headers = wp_remote_retrieve_headers( $response );

        // Content-Security-Policy
        if ( empty( $headers['content-security-policy'] ) && empty( $headers['Content-Security-Policy'] ) ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'missing_csp_header', self::SEV_WARNING,
                'Content-Security-Policy (CSP) header is not set',
                "Add CSP header via .htaccess: Header set Content-Security-Policy \"default-src 'self'; script-src 'self' 'unsafe-inline';\" — or use a WordPress security plugin.",
                'Without CSP, the browser has no policy to prevent XSS attacks from injecting and executing malicious scripts.',
                [ 'affected_modules' => ['Security Headers'], 'reproduction_steps' => "curl -I {$site_url} | grep -i content-security" ] );
        }

        // Strict-Transport-Security (HSTS)
        if ( is_ssl() && empty( $headers['strict-transport-security'] ) && empty( $headers['Strict-Transport-Security'] ) ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'missing_hsts_header', self::SEV_WARNING,
                'Strict-Transport-Security (HSTS) header is not set on HTTPS site',
                'Add to .htaccess: Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"',
                'Without HSTS, browsers may accept HTTP connections even when HTTPS is available, enabling SSL stripping attacks.',
                [ 'affected_modules' => ['Security Headers'] ] );
        }

        // X-Frame-Options
        if ( empty( $headers['x-frame-options'] ) && empty( $headers['X-Frame-Options'] ) ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'missing_x_frame_options', self::SEV_WARNING,
                'X-Frame-Options header is not set — site may be embeddable in iframes (clickjacking risk)',
                'Add to .htaccess: Header always set X-Frame-Options "SAMEORIGIN" — or use CSP frame-ancestors.',
                'Attackers can embed the site in a transparent iframe to trick users into clicking on hidden elements (clickjacking).',
                [ 'affected_modules' => ['Security Headers'] ] );
        }

        // X-Content-Type-Options
        if ( empty( $headers['x-content-type-options'] ) && empty( $headers['X-Content-Type-Options'] ) ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'missing_xcto_header', self::SEV_NOTICE,
                'X-Content-Type-Options header is not set',
                'Add to .htaccess: Header always set X-Content-Type-Options "nosniff"',
                'Without this header, browsers may MIME-sniff responses and execute them as a different content type, enabling certain attack vectors.',
                [ 'affected_modules' => ['Security Headers'] ] );
        }

        // Referrer-Policy
        if ( empty( $headers['referrer-policy'] ) && empty( $headers['Referrer-Policy'] ) ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'missing_referrer_policy', self::SEV_NOTICE,
                'Referrer-Policy header is not set — full URLs may leak to third parties',
                'Add to .htaccess: Header always set Referrer-Policy "strict-origin-when-cross-origin"',
                'Without a referrer policy, query strings (which may contain sensitive data) are sent to third-party sites when users follow links.',
                [ 'affected_modules' => ['Security Headers'] ] );
        }

        // Server header leaking software version
        $server = $headers['server'] ?? $headers['Server'] ?? '';
        if ( $server && preg_match( '/Apache\/[\d.]+|nginx\/[\d.]+|PHP\/[\d.]+/', $server ) ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'server_version_exposed', self::SEV_NOTICE,
                "Server header exposes software version: \"{$server}\"",
                'Configure ServerTokens Prod in Apache or server_tokens off in Nginx to suppress version disclosure.',
                'Attackers can use the version information to identify known vulnerabilities for the exact software version.',
                [ 'affected_modules' => ['Security Headers'] ] );
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 8-C: File integrity monitoring (§8 — suspicious file changes)
    // ════════════════════════════════════════════════════════════════════════

    private static function check_file_integrity(): array {
        $findings = [];

        // Check for PHP files in uploads directory (classic malware injection)
        $upload_dir = wp_upload_dir();
        $uploads_base = $upload_dir['basedir'] ?? '';
        if ( $uploads_base && is_dir( $uploads_base ) ) {
            $php_in_uploads = [];
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator( $uploads_base, \RecursiveDirectoryIterator::SKIP_DOTS ),
                \RecursiveIteratorIterator::LEAVES_ONLY
            );
            $checked = 0;
            foreach ( $iterator as $file ) {
                if ( $checked++ > 500 ) { break; } // safety limit
                if ( $file->getExtension() === 'php' || $file->getExtension() === 'phtml' ) {
                    $php_in_uploads[] = str_replace( ABSPATH, '', $file->getPathname() );
                }
            }
            if ( $php_in_uploads ) {
                $findings[] = self::finding( self::SRC_SECURITY, 'php_in_uploads', self::SEV_CRITICAL,
                    count( $php_in_uploads ) . ' PHP file(s) found in uploads directory: ' . implode( ', ', array_slice( $php_in_uploads, 0, 3 ) ),
                    '1. Delete suspicious PHP files immediately. 2. Scan with a malware scanner (Wordfence, Malcure). 3. Audit server access logs. 4. Change all passwords.',
                    'PHP files in uploads are almost always malware — the uploads directory should only contain media files. Attackers use these to execute arbitrary server-side code.',
                    [ 'affected_files' => $php_in_uploads, 'fix_priority' => 1,
                      'reproduction_steps' => 'find ' . $uploads_base . ' -name "*.php" -o -name "*.phtml"' ] );
            }
        }

        // Check wp-config.php is above web root (or has restrictive permissions)
        $wp_config = ABSPATH . 'wp-config.php';
        if ( file_exists( $wp_config ) ) {
            $perms = substr( sprintf( '%o', fileperms( $wp_config ) ), -4 );
            if ( in_array( $perms, [ '0777', '0666', '0664', '0660' ], true ) ) {
                $findings[] = self::finding( self::SRC_SECURITY, 'wp_config_permissions', self::SEV_CRITICAL,
                    "wp-config.php has insecure permissions ({$perms})",
                    'Run: chmod 600 ' . $wp_config . ' — only the web server user should read this file.',
                    'wp-config.php contains database credentials. World-readable permissions allow any server process to read it.',
                    [ 'affected_files' => [ 'wp-config.php' ], 'fix_priority' => 1 ] );
            }
        }

        // Check for recently modified plugin/theme files (last 24h, unexpected changes)
        $plugin_dirs = [ WP_PLUGIN_DIR, get_theme_root() ];
        $recently_modified = [];
        // Real fix: this exclusion previously looked for the literal string
        // "goodservice" in the file path, but the actual deployed folder
        // name is gs23_fixed (or whatever this plugin's real directory is
        // named on a given install) — the exclusion never matched, so
        // every legitimate update to this plugin's own files was
        // misidentified as a possible site compromise. Derives the real
        // folder name from this file's own location instead of guessing.
        $own_plugin_dir = basename( dirname( dirname( __DIR__ ) ) ); // .../wp-content/plugins/<this>/src/Core/DiagnosticsEngine.php
        foreach ( $plugin_dirs as $dir ) {
            if ( ! is_dir( $dir ) ) { continue; }
            $iter = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator( $dir, \RecursiveDirectoryIterator::SKIP_DOTS )
            );
            $count = 0;
            foreach ( $iter as $f ) {
                if ( $count++ > 2000 ) { break; }
                if ( $f->getMTime() > ( time() - 3600 * 24 ) && $f->getExtension() === 'php' ) {
                    $rel = str_replace( ABSPATH, '', $f->getPathname() );
                    // Only flag if NOT in our own plugin (expected changes)
                    if ( ! str_contains( $rel, $own_plugin_dir ) && ! str_contains( strtolower( $rel ), 'goodservice' ) ) {
                        $recently_modified[] = $rel;
                    }
                }
            }
        }
        if ( count( $recently_modified ) > 5 ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'unexpected_file_changes', self::SEV_WARNING,
                count( $recently_modified ) . ' PHP files in plugins/themes modified in the last 24h (excluding GoodService)',
                '1. Verify these changes came from a legitimate plugin update. 2. If not, your site may be compromised. 3. Run a malware scan immediately.',
                'Unexpected file changes may indicate malware injection, unauthorized file editing, or a supply-chain attack via a compromised plugin.',
                [ 'affected_files' => array_slice( $recently_modified, 0, 10 ),
                  'reproduction_steps' => 'find ' . WP_PLUGIN_DIR . ' -name "*.php" -newer /tmp/ref_time' ] );
        }

        // Check .htaccess for suspicious content
        $htaccess = ABSPATH . '.htaccess';
        if ( file_exists( $htaccess ) ) {
            $content = @file_get_contents( $htaccess );
            if ( $content ) {
                $suspicious = [ 'base64_decode', 'eval(', 'RewriteRule.*http://', 'RewriteRule.*https://' ];
                foreach ( $suspicious as $pattern ) {
                    if ( str_contains( $content, $pattern ) ) {
                        $findings[] = self::finding( self::SRC_SECURITY, 'suspicious_htaccess', self::SEV_CRITICAL,
                            ".htaccess contains suspicious pattern: {$pattern}",
                            '1. Review .htaccess immediately. 2. Remove any code you did not add. 3. Restore from backup if needed. 4. Run a malware scan.',
                            '.htaccess files can redirect visitors to malicious sites or execute PHP code. Suspicious patterns indicate a hack.',
                            [ 'affected_files' => [ '.htaccess' ], 'fix_priority' => 1 ] );
                        break;
                    }
                }
            }
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 6-B/7-B: Cron health + Queue health (§4/§6 gaps)
    // ════════════════════════════════════════════════════════════════════════

    private static function check_cron_and_queue(): array {
        global $wpdb;
        $findings = [];
        $p        = $wpdb->prefix . 'gs_';

        // ── WP-Cron scheduled events ──────────────────────────────────────
        $gs_crons = [
            'gs_hourly' => 'Booking reminders, waitlist notifications, cron automation',
            'gs_daily'  => 'Subscription expiry, analytics rollup',
        ];
        $scheduled = _get_cron_array() ?: [];
        $all_hooks = array_reduce( $scheduled, function( $carry, $ts ) {
            return array_merge( $carry, array_keys( $ts ) );
        }, [] );

        foreach ( $gs_crons as $hook => $purpose ) {
            if ( ! in_array( $hook, $all_hooks, true ) ) {
                $findings[] = self::finding( self::SRC_WP, 'cron_not_scheduled', self::SEV_ERROR,
                    "WP-Cron event '{$hook}' is not scheduled — {$purpose} will not run",
                    "Deactivate and reactivate the GoodService plugin to re-register cron events, or call: wp_schedule_event(time(), 'hourly', '{$hook}');",
                    "The {$hook} event was not found in WP-Cron. This can happen after a failed activation or if the hook was removed.",
                    [ 'affected_modules' => ['Cron', 'Bookings'], 'reproduction_steps' => "wp cron event list | grep {$hook}" ] );
            }
        }

        // Check for missed cron events (last run > 2x the interval)
        foreach ( $scheduled as $timestamp => $cron_jobs ) {
            foreach ( $cron_jobs as $hook => $runs ) {
                if ( ! str_starts_with( $hook, 'gs_' ) ) { continue; }
                $recurrence = array_values( $runs )[0]['schedule'] ?? '';
                $interval   = wp_get_schedules()[ $recurrence ]['interval'] ?? 3600;
                if ( $timestamp < time() - $interval * 2 ) {
                    $findings[] = self::finding( self::SRC_WP, 'cron_missed', self::SEV_WARNING,
                        "WP-Cron event '{$hook}' was due " . human_time_diff( $timestamp ) . " ago but has not run",
                        '1. Check WP-Cron is enabled (DISABLE_WP_CRON should be false, or real cron must be running). 2. Try: wp cron run --due-now',
                        'Missed cron events indicate WP-Cron is not firing. This requires HTTP traffic to trigger — low-traffic sites may miss cron windows.',
                        [ 'affected_modules' => ['Cron'], 'reproduction_steps' => 'wp cron event list' ] );
                }
            }
        }

        // ── Job Queue health ──────────────────────────────────────────────
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$p}job_queue'" ) ) {
            $stuck_jobs = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$p}job_queue
                 WHERE status='processing' AND updated_at < DATE_SUB(NOW(), INTERVAL %d MINUTE)",
                30
            ) );
            if ( $stuck_jobs > 0 ) {
                $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'stuck_queue_jobs', self::SEV_ERROR,
                    "{$stuck_jobs} background job(s) stuck in 'processing' state for 30+ minutes",
                    '1. Go to Admin → Diagnostics → Queue to retry stuck jobs. 2. Check error log for the job failure reason. 3. Reset stuck jobs: UPDATE gs_job_queue SET status="failed" WHERE status="processing" AND updated_at < DATE_SUB(NOW(), INTERVAL 30 MINUTE)',
                    'Jobs stuck in "processing" indicate a worker crash or PHP timeout during job execution. They will never retry automatically.',
                    [ 'affected_modules' => ['Job Queue'], 'fix_priority' => 2 ] );
            }

            $failed_jobs = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$p}job_queue WHERE status='failed'"
            );
            if ( $failed_jobs > 0 ) {
                $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'failed_queue_jobs', self::SEV_WARNING,
                    "{$failed_jobs} background job(s) in 'failed' state",
                    'Go to Admin → Jobs to review and retry failed jobs. Check the job error field for the failure reason.',
                    'Failed jobs represent operations that did not complete — email sends, webhook deliveries, or data processing tasks.',
                    [ 'affected_modules' => ['Job Queue'] ] );
            }
        }

        // ── Background processor concurrency guard ────────────────────────
        $last_cron_run = get_option( 'gs_last_cron_run', 0 );
        if ( $last_cron_run && ( time() - $last_cron_run ) > 7200 ) {
            $findings[] = self::finding( self::SRC_WP, 'cron_not_running', self::SEV_ERROR,
                'GoodService cron has not run for ' . round( ( time() - $last_cron_run ) / 3600, 1 ) . ' hours',
                '1. Set up a real server cron: */5 * * * * curl -s ' . site_url('/wp-cron.php?doing_wp_cron') . '. 2. Verify DISABLE_WP_CRON is not set to true.',
                'If cron is not running, booking reminders, subscription expiry, and waitlist notifications are all silently failing.',
                [ 'affected_modules' => ['Cron', 'Bookings', 'Subscriptions'], 'fix_priority' => 2 ] );
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 6-C/7-C: N+1 detection + advanced performance (§7 gaps)
    // ════════════════════════════════════════════════════════════════════════

    private static function check_advanced_performance(): array {
        global $wpdb;
        $findings = [];

        // ── N+1 query detection via SAVEQUERIES analysis ──────────────────
        if ( defined( 'SAVEQUERIES' ) && SAVEQUERIES && ! empty( $wpdb->queries ) ) {
            // Group queries by stripped SQL to find repeating patterns
            $query_patterns = [];
            foreach ( $wpdb->queries as $q ) {
                if ( ! isset( $q[0] ) ) { continue; }
                // Strip numeric values to normalise — "WHERE id=1" and "WHERE id=2" become same pattern
                $pattern = preg_replace( '/\b\d+\b/', 'N', $q[0] );
                $pattern = substr( $pattern, 0, 100 );
                $query_patterns[ $pattern ] = ( $query_patterns[ $pattern ] ?? 0 ) + 1;
            }
            arsort( $query_patterns );
            foreach ( $query_patterns as $pattern => $count ) {
                if ( $count >= 10 ) {
                    $findings[] = self::finding( self::SRC_PERFORMANCE, 'n_plus_1_query', self::SEV_WARNING,
                        "Query pattern repeated {$count} times — N+1 query detected: " . substr( $pattern, 0, 120 ),
                        '1. Replace individual queries with a single JOIN query. 2. Use wp_cache_get/set to batch load. 3. Use get_posts with post__in to fetch all at once.',
                        "N+1 queries occur when code queries inside a loop. With {$count} iterations this causes {$count} DB round-trips instead of 1.",
                        [ 'affected_modules' => ['Database', 'Performance'], 'reproduction_steps' => 'Enable SAVEQUERIES in wp-config.php and check $wpdb->queries' ] );
                    break; // Only report the worst one per scan
                }
            }

            // Total query count per page
            $total_queries = count( $wpdb->queries );
            if ( $total_queries > 50 ) {
                $findings[] = self::finding( self::SRC_PERFORMANCE, 'excessive_queries', self::SEV_WARNING,
                    "{$total_queries} database queries on this admin page load",
                    '1. Enable object caching (Redis). 2. Use transients to cache expensive query results. 3. Profile with WP Query Monitor.',
                    "High query counts indicate missing caching or N+1 patterns. Each query adds ~1-5ms latency, totalling " . round( $total_queries * 3 ) . 'ms+ overhead.',
                    [ 'affected_modules' => ['Performance', 'Database'] ] );
            }
        }

        // ── Active plugins count ──────────────────────────────────────────
        $active_plugins = get_option( 'active_plugins', [] );
        if ( count( $active_plugins ) > 30 ) {
            $findings[] = self::finding( self::SRC_PERFORMANCE, 'too_many_plugins', self::SEV_WARNING,
                count( $active_plugins ) . ' active plugins detected — each adds boot overhead',
                '1. Deactivate unused plugins. 2. Use asset-loading conditionals to load plugins only on relevant pages. 3. Combine functionality where possible.',
                'Each active plugin runs code on every request. 30+ plugins typically add 100-500ms to TTFB and significantly increase memory usage.',
                [ 'affected_modules' => ['Performance'] ] );
        }

        // ── Database table sizes ──────────────────────────────────────────
        $large_tables = $wpdb->get_results( $wpdb->prepare(
            "SELECT TABLE_NAME, ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 1) AS size_mb,
                    TABLE_ROWS
             FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME LIKE %s
               AND (DATA_LENGTH + INDEX_LENGTH) > 104857600
             ORDER BY size_mb DESC LIMIT 5",
            $wpdb->prefix . 'gs\_%'
        ) ) ?: [];
        foreach ( $large_tables as $tbl ) {
            $findings[] = self::finding( self::SRC_PERFORMANCE, 'large_table', self::SEV_NOTICE,
                "Table {$tbl->TABLE_NAME} is {$tbl->size_mb}MB ({$tbl->TABLE_ROWS} rows)",
                '1. Archive old records to a history table. 2. Add pagination to all queries on this table. 3. Ensure indexes cover common WHERE clauses. 4. Consider partitioning.',
                "Large tables slow down queries even with indexes. At {$tbl->TABLE_ROWS} rows, unindexed scans can take seconds.",
                [ 'affected_modules' => ['Database', 'Performance'] ] );
        }

        // ── Render-blocking resources check via meta-analysis ────────────
        $render_blocking_option = get_option( 'gs_diag_render_blocking', 0 );
        if ( $render_blocking_option > 0 ) {
            $findings[] = self::finding( self::SRC_PERFORMANCE, 'render_blocking_resources', self::SEV_WARNING,
                "{$render_blocking_option} render-blocking resources detected (reported by frontend)",
                '1. Add async/defer to non-critical scripts. 2. Move scripts to footer. 3. Preload critical CSS. 4. Use link rel=preload for key resources.',
                'Render-blocking resources delay First Contentful Paint (FCP) — the browser cannot show anything until all blocking resources are downloaded.',
                [ 'affected_modules' => ['Performance', 'Frontend'] ] );
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 6-D: Multisite + Update failures (§6 gaps)
    // ════════════════════════════════════════════════════════════════════════

    private static function check_multisite_and_updates(): array {
        $findings = [];

        // ── Multisite check ───────────────────────────────────────────────
        if ( is_multisite() ) {
            $findings[] = self::finding( self::SRC_WP, 'multisite_detected', self::SEV_NOTICE,
                'WordPress Multisite is active — GoodService must be Network Activated for full functionality',
                '1. Go to Network Admin → Plugins and activate GoodService network-wide. 2. Verify each subsite has the correct custom pages created.',
                'On Multisite, plugin-level rewrite rules and page creation must run per-site. Network activation ensures correct setup on all sites.',
                [ 'affected_modules' => ['WordPress', 'Routing'] ] );
        }

        // ── Pending WordPress core updates ────────────────────────────────
        $wp_updates = get_site_transient( 'update_core' );
        if ( $wp_updates && ! empty( $wp_updates->updates ) ) {
            $latest = $wp_updates->updates[0] ?? null;
            if ( $latest && isset( $latest->version ) && $latest->version !== $GLOBALS['wp_version'] ) {
                // Real bug fix: floor() was called directly on version
                // strings (e.g. "7.0.1"), which PHP 8+ correctly rejects
                // with a TypeError — this crashed the entire scan. Extract
                // just the major version number and compare those as real
                // integers, which is both what this check actually needs
                // and resolves the crash.
                $latest_major  = (int) strtok( (string) $latest->version, '.' );
                $current_major = (int) strtok( (string) $GLOBALS['wp_version'], '.' );
                $is_major = version_compare( $latest->version, $GLOBALS['wp_version'], '>' )
                         && $latest_major > $current_major;
                $findings[] = self::finding( self::SRC_WP, 'wp_update_available', $is_major ? self::SEV_WARNING : self::SEV_NOTICE,
                    'WordPress ' . $latest->version . ' is available (current: ' . $GLOBALS['wp_version'] . ')',
                    '1. Back up your site. 2. Go to Dashboard → Updates and update WordPress. 3. Test all functionality after update.',
                    'Outdated WordPress versions miss security patches. Critical security updates should be applied within 48 hours.',
                    [ 'affected_modules' => ['WordPress Core'] ] );
            }
        }

        // ── Pending plugin updates ─────────────────────────────────────────
        $plugin_updates = get_site_transient( 'update_plugins' );
        if ( $plugin_updates && ! empty( $plugin_updates->response ) ) {
            $count = count( $plugin_updates->response );
            if ( $count > 0 ) {
                $plugin_names = array_map( function( $p ) {
                    return $p->slug ?? '';
                }, array_slice( array_values( $plugin_updates->response ), 0, 5 ) );
                $findings[] = self::finding( self::SRC_WP, 'plugin_updates_available', self::SEV_NOTICE,
                    "{$count} plugin update(s) available: " . implode( ', ', array_filter( $plugin_names ) ),
                    '1. Back up your site. 2. Go to Dashboard → Updates and update plugins. 3. Test after each update.',
                    'Outdated plugins are the #1 cause of WordPress security breaches. Plugin updates often include security patches.',
                    [ 'affected_modules' => ['WordPress Plugins'] ] );
            }
        }

        // ── Failed activation error ────────────────────────────────────────
        $activation_error = get_option( 'gs_activation_error', '' );
        if ( $activation_error ) {
            $findings[] = self::finding( self::SRC_PHP, 'activation_error', self::SEV_CRITICAL,
                'GoodService has a stored activation error: ' . substr( $activation_error, 0, 200 ),
                '1. Go to Admin → Debug to see the full error. 2. Fix the root cause. 3. Deactivate and reactivate the plugin to clear this error.',
                'A failed activation means the database schema, cron events, and custom pages may not have been created correctly.',
                [ 'fix_priority' => 1, 'reproduction_steps' => 'Check Admin → Debug for full stack trace' ] );
        }

        // ── Hook conflict detection: scan for duplicate hook priorities ───
        global $wp_filter;
        $conflicts = [];
        foreach ( $wp_filter as $hook_name => $hook_obj ) {
            if ( ! str_starts_with( $hook_name, 'gs_' ) ) { continue; }
            foreach ( $hook_obj->callbacks ?? [] as $priority => $callbacks ) {
                if ( count( $callbacks ) > 3 ) {
                    $conflicts[] = "{$hook_name} at priority {$priority}: " . count( $callbacks ) . ' callbacks';
                }
            }
        }
        if ( $conflicts ) {
            $findings[] = self::finding( self::SRC_WP, 'hook_crowding', self::SEV_NOTICE,
                count( $conflicts ) . ' GoodService hooks have 4+ callbacks at the same priority: ' . implode( ' | ', array_slice( $conflicts, 0, 3 ) ),
                '1. Review hook priorities. 2. Ensure third-party plugins are not hooking into gs_* actions unexpectedly.',
                'Multiple callbacks at the same priority on the same hook can cause unpredictable execution order.',
                [ 'affected_modules' => ['WordPress Hooks'] ] );
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 9-B: CDN + Server response quality (§9 gaps)
    // ════════════════════════════════════════════════════════════════════════

    private static function check_cdn_and_server(): array {
        $findings = [];

        // Make a request to check response headers for CDN indicators and compression
        $response = wp_remote_get( site_url(), [
            'timeout'   => 5,
            'sslverify' => false,
            'headers'   => [ 'User-Agent' => 'GoodService-Diagnostics/1.0', 'Accept-Encoding' => 'gzip, deflate, br' ],
        ] );

        if ( is_wp_error( $response ) ) { return $findings; }

        $headers  = wp_remote_retrieve_headers( $response );
        $body_len = strlen( wp_remote_retrieve_body( $response ) );
        $code     = wp_remote_retrieve_response_code( $response );

        // Check gzip/brotli compression
        $encoding = $headers['content-encoding'] ?? $headers['Content-Encoding'] ?? '';
        if ( empty( $encoding ) && $body_len > 10000 ) {
            $findings[] = self::finding( self::SRC_PERFORMANCE, 'no_compression', self::SEV_WARNING,
                'HTTP response is not compressed (no content-encoding header on ' . round( $body_len / 1024, 1 ) . 'KB response)',
                '1. Enable gzip in .htaccess: AddOutputFilterByType DEFLATE text/html text/css application/javascript. 2. Or use a caching plugin. 3. Or enable gzip at Nginx/Apache config level.',
                'Uncompressed responses are typically 70% larger than compressed. This directly increases page load time and bandwidth costs.',
                [ 'affected_modules' => ['Performance', 'Infrastructure'] ] );
        }

        // Check CDN presence via via/cf-ray/x-cache headers
        $via      = $headers['via']    ?? $headers['Via']    ?? '';
        $cf_ray   = $headers['cf-ray'] ?? $headers['Cf-Ray'] ?? '';
        $x_cache  = $headers['x-cache'] ?? $headers['X-Cache'] ?? '';
        $has_cdn  = ! empty( $via ) || ! empty( $cf_ray ) || ! empty( $x_cache );
        if ( ! $has_cdn ) {
            $findings[] = self::finding( self::SRC_PERFORMANCE, 'no_cdn_detected', self::SEV_NOTICE,
                'No CDN detected (no Via/CF-Ray/X-Cache response headers)',
                '1. Use Cloudflare (free tier covers most use cases). 2. Or use BunnyCDN/AWS CloudFront. 3. At minimum enable a caching plugin like WP Rocket.',
                'Without a CDN, all requests hit the origin server. Static assets (images, JS, CSS) should be served from edge locations near users to reduce latency.',
                [ 'affected_modules' => ['Performance', 'Infrastructure'] ] );
        }

        // Check cache headers on response
        $cache_control = $headers['cache-control'] ?? $headers['Cache-Control'] ?? '';
        if ( empty( $cache_control ) || str_contains( $cache_control, 'no-store' ) ) {
            $findings[] = self::finding( self::SRC_PERFORMANCE, 'no_cache_headers', self::SEV_NOTICE,
                'HTML response has no browser caching headers (cache-control is absent or no-store)',
                '1. Configure a caching plugin (WP Rocket, LiteSpeed Cache, W3 Total Cache). 2. Set cache-control headers in .htaccess for static assets.',
                'Without cache headers, browsers re-download resources on every visit. Proper caching reduces repeat load times by 60-90%.',
                [ 'affected_modules' => ['Performance'] ] );
        }

        // Response time check
        $response_time = wp_remote_retrieve_header( $response, 'x-response-time' )
                      ?: wp_remote_retrieve_header( $response, 'server-timing' );
        // We can't reliably measure TTFB from within PHP, but check page size
        if ( $body_len > 150000 ) {
            $findings[] = self::finding( self::SRC_PERFORMANCE, 'large_html_response', self::SEV_WARNING,
                'HTML response size is ' . round( $body_len / 1024, 1 ) . 'KB — larger than recommended 150KB',
                '1. Remove unnecessary page content. 2. Use defer/async for scripts. 3. Avoid inlining large JS/CSS. 4. Enable HTML minification.',
                'Large HTML responses increase parse time and delay First Contentful Paint. Each extra KB adds ~1ms on mobile connections.',
                [ 'affected_modules' => ['Performance', 'Frontend'] ] );
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 10-B: Active connectivity tests (§10 gaps)
    // ════════════════════════════════════════════════════════════════════════

    private static function check_connectivity(): array {
        $findings = [];

        // ── SMTP / Email delivery test ────────────────────────────────────
        // We can't send a real email without side effects during a scan.
        // Instead, check if wp_mail is hooked and SMTP is configured.
        $smtp_host = Config::get( 'smtp_host', '' ) ?: ini_get( 'SMTP' );
        if ( ! has_filter( 'phpmailer_init' ) && empty( $smtp_host ) ) {
            $findings[] = self::finding( self::SRC_INTEGRATION, 'email_smtp_not_configured', self::SEV_WARNING,
                'No SMTP configuration detected — WordPress is using PHP mail() which is unreliable and often blocked',
                '1. Install WP Mail SMTP plugin and configure SMTP (Gmail/Mailgun/SMTP2GO). 2. Or configure SMTP in GoodService Settings. 3. Test email delivery via Admin → Diagnostics → Test Email.',
                'PHP mail() is blocked by most hosting providers and marked as spam by email servers. SMTP ensures reliable email delivery for booking confirmations, OTPs, and system alerts.',
                [ 'affected_modules' => ['Email', 'Notifications'] ] );
        }

        // ── Razorpay API connectivity ─────────────────────────────────────
        $rzp_key = Config::get( 'razorpay_key_id', '' );
        $rzp_sec = Config::get( 'razorpay_key_secret', '' );
        if ( $rzp_key && $rzp_sec ) {
            $rzp_response = wp_remote_get( 'https://api.razorpay.com/v1/plans', [
                'timeout' => 8,
                'headers' => [
                    'Authorization' => 'Basic ' . base64_encode( $rzp_key . ':' . $rzp_sec ),
                ],
            ] );
            if ( is_wp_error( $rzp_response ) ) {
                $findings[] = self::finding( self::SRC_INTEGRATION, 'razorpay_unreachable', self::SEV_ERROR,
                    'Razorpay API is unreachable: ' . $rzp_response->get_error_message(),
                    '1. Check server outbound internet access. 2. Verify no firewall is blocking api.razorpay.com. 3. Test: curl -u key:secret https://api.razorpay.com/v1/plans',
                    'Cannot reach Razorpay API. Subscription upgrades and booking deposits will fail for all users.',
                    [ 'affected_modules' => ['Payments'], 'fix_priority' => 1 ] );
            } elseif ( wp_remote_retrieve_response_code( $rzp_response ) === 401 ) {
                $findings[] = self::finding( self::SRC_INTEGRATION, 'razorpay_auth_failed', self::SEV_CRITICAL,
                    'Razorpay API authentication failed (HTTP 401) — API keys are invalid',
                    '1. Verify Key ID and Key Secret in Admin → Settings → Payments. 2. Check if the key pair is live vs test mode. 3. Regenerate keys in Razorpay dashboard if needed.',
                    'Invalid Razorpay credentials. All payment processing is broken — no subscription upgrades or deposits can be accepted.',
                    [ 'affected_modules' => ['Payments'], 'fix_priority' => 1 ] );
            }
        }

        // ── Anthropic API connectivity ────────────────────────────────────
        $ai_key = Config::get( 'anthropic_api_key', '' ) ?: Config::get( 'gs_anthropic_api_key', '' );
        if ( $ai_key ) {
            $ai_response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
                'timeout' => 8,
                'headers' => [
                    'x-api-key'         => $ai_key,
                    'anthropic-version' => '2023-06-01',
                    'content-type'      => 'application/json',
                ],
                'body' => wp_json_encode( [
                    'model'      => 'claude-haiku-4-5-20251001',
                    'max_tokens' => 1,
                    'messages'   => [ [ 'role' => 'user', 'content' => 'ping' ] ],
                ] ),
            ] );
            $ai_code = is_wp_error( $ai_response ) ? 0 : wp_remote_retrieve_response_code( $ai_response );
            if ( $ai_code === 401 ) {
                $findings[] = self::finding( self::SRC_INTEGRATION, 'anthropic_auth_failed', self::SEV_ERROR,
                    'Anthropic API key is invalid (HTTP 401)',
                    '1. Verify the API key in Admin → Settings. 2. Regenerate at console.anthropic.com.',
                    'Invalid Anthropic API key. AI reply drafting, AI concierge search, and quote generation are all disabled.',
                    [ 'affected_modules' => ['AI Features'] ] );
            } elseif ( is_wp_error( $ai_response ) ) {
                $findings[] = self::finding( self::SRC_INTEGRATION, 'anthropic_unreachable', self::SEV_WARNING,
                    'Anthropic API unreachable: ' . $ai_response->get_error_message(),
                    '1. Check outbound internet access. 2. Verify no WAF is blocking api.anthropic.com.',
                    'Cannot reach Anthropic API. AI features will fall back to keyword-based matching.',
                    [ 'affected_modules' => ['AI Features'] ] );
            }
        }

        // ── WordPress.org connectivity (for updates) ──────────────────────
        $wp_org = wp_remote_head( 'https://api.wordpress.org/core/version-check/1.7/', [ 'timeout' => 5 ] );
        if ( is_wp_error( $wp_org ) ) {
            $findings[] = self::finding( self::SRC_INFRASTRUCTURE, 'wp_org_unreachable', self::SEV_WARNING,
                'Cannot reach api.wordpress.org: ' . $wp_org->get_error_message(),
                '1. Check outbound internet access from the server. 2. Verify no firewall is blocking WordPress.org. 3. Test: curl -I https://api.wordpress.org',
                'Without access to WordPress.org, automatic plugin/core updates are disabled and license checks for commercial plugins may fail.',
                [ 'affected_modules' => ['WordPress Updates'] ] );
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 5-B: DB — data corruption + migration (§5 gaps)
    // ════════════════════════════════════════════════════════════════════════

    private static function check_database_integrity(): array {
        global $wpdb;
        $findings = [];
        $p        = $wpdb->prefix . 'gs_';

        // Real fix: an always-on proof-of-execution marker, independent of
        // whether any actual problem is found. Three consecutive live
        // scans showed zero findings from this entire section — including
        // checks that predate this specific investigation — with no way
        // to tell whether the section ran and found nothing, or never ran
        // at all. This makes that distinction impossible to miss going
        // forward: it fires every single time this function executes.
        $listings_table_exists = (bool) $wpdb->get_var( "SHOW TABLES LIKE '{$p}listings'" );
        $hex_count_raw = $listings_table_exists
            ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$p}listings WHERE TRIM(title) REGEXP '^#[0-9a-fA-F]{3,6}$'" )
            : -1;
        $findings[] = self::finding( self::SRC_DB, 'db_integrity_section_reached', self::SEV_INFO,
            "DB integrity section executed. Table {$p}listings exists: " . ( $listings_table_exists ? 'yes' : 'NO — this is why every check below is silently skipped' )
                . '. Raw hex-color-title count: ' . ( $hex_count_raw === -1 ? 'not checked (table missing)' : $hex_count_raw ),
            'If this finding is present but listing_title_is_hex_color is absent while the raw count above is 0, the check correctly found nothing. If the raw count above is greater than 0 but listing_title_is_hex_color is still absent, that is a genuine bug to report back with this exact number.',
            'Diagnostic marker — not an actual error.',
            [] );

        // ── Orphaned vendor profiles (no WP user) ─────────────────────────
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$p}vendor_profiles'" ) ) {
            $orphaned = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$p}vendor_profiles vp
                 LEFT JOIN {$wpdb->prefix}users u ON u.ID = vp.user_id
                 WHERE u.ID IS NULL"
            );
            if ( $orphaned > 0 ) {
                $findings[] = self::finding( self::SRC_DB, 'orphaned_vendor_profiles', self::SEV_WARNING,
                    "{$orphaned} vendor profile(s) have no corresponding WordPress user",
                    '1. Delete orphaned profiles: DELETE FROM gs_vendor_profiles WHERE user_id NOT IN (SELECT ID FROM wp_users). 2. Or recreate the WP user if the profile should be kept.',
                    'Orphaned vendor profiles indicate WP user deletion without cascading to plugin data. These profiles are unreachable by any user.',
                    [ 'affected_modules' => ['Vendors', 'Database'], 'reproduction_steps' => 'Run the orphan check query above in phpMyAdmin' ] );
            }
        }

        // ── Orphaned listings (no vendor profile) ─────────────────────────
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$p}listings'" ) && $wpdb->get_var( "SHOW TABLES LIKE '{$p}vendor_profiles'" ) ) {
            $orphaned_listings = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$p}listings l
                 LEFT JOIN {$p}vendor_profiles vp ON vp.id = l.vendor_id
                 WHERE vp.id IS NULL AND l.status != 'deleted'"
            );
            if ( $orphaned_listings > 0 ) {
                $findings[] = self::finding( self::SRC_DB, 'orphaned_listings', self::SEV_WARNING,
                    "{$orphaned_listings} active listing(s) have no vendor profile",
                    '1. Mark orphaned listings as deleted: UPDATE gs_listings SET status="deleted" WHERE vendor_id NOT IN (SELECT id FROM gs_vendor_profiles). 2. Investigate how vendor deletion occurred without cascading.',
                    'Orphaned listings are orphan records that may appear in search results but have no owner to manage them.',
                    [ 'affected_modules' => ['Listings', 'Database'] ] );
            }
        }

        // ── Duplicate slugs check ─────────────────────────────────────────
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$p}listings'" ) ) {
            $dup_slugs = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM (
                    SELECT slug, COUNT(*) as cnt FROM {$p}listings
                    WHERE status != 'deleted' GROUP BY slug HAVING cnt > 1
                ) dupes"
            );
            if ( $dup_slugs > 0 ) {
                $findings[] = self::finding( self::SRC_DB, 'duplicate_listing_slugs', self::SEV_ERROR,
                    "{$dup_slugs} duplicate listing slug(s) detected — URLs will be ambiguous",
                    '1. Find duplicates: SELECT slug, COUNT(*) as cnt FROM gs_listings GROUP BY slug HAVING cnt > 1. 2. Update duplicate slugs to be unique by appending -2, -3 etc.',
                    'Duplicate slugs mean multiple listings share the same URL. The router will match whichever it finds first, making the others unreachable.',
                    [ 'affected_modules' => ['Listings', 'Routing', 'Database'] ] );
            }
        }

        // ── Subscriptions with invalid plan references ─────────────────────
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$p}subscriptions'" ) && $wpdb->get_var( "SHOW TABLES LIKE '{$p}subscription_plans'" ) ) {
            $invalid_subs = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$p}subscriptions s
                 LEFT JOIN {$p}subscription_plans sp ON sp.id = s.plan_id
                 WHERE sp.id IS NULL AND s.status IN ('active','trialing')"
            );
            if ( $invalid_subs > 0 ) {
                $findings[] = self::finding( self::SRC_DB, 'orphaned_subscriptions', self::SEV_ERROR,
                    "{$invalid_subs} active subscription(s) reference non-existent plan(s)",
                    '1. Find them: SELECT * FROM gs_subscriptions WHERE plan_id NOT IN (SELECT id FROM gs_subscription_plans). 2. Cancel or reassign to an existing plan.',
                    'Subscriptions referencing deleted plans will fail LEFT JOINs in directoryFilter, showing those vendors as free tier even when they have paid subscriptions.',
                    [ 'affected_modules' => ['Subscriptions', 'Database', 'Directory'] ] );
            }
        }

        // ── Listing title / vendor name accidentally set to a hex color code ──
        // Real feature: this is the diagnostic requested after tracing the
        // "vendor name renders as a color code" bug on trust-documentation-
        // services — $brand (used for the page title, WhatsApp popup,
        // sticky bar, and breadcrumb) falls back through listing.title →
        // vendor_profiles.business_name → platform_name. If any of those
        // literally contain a hex color string (e.g. '#2563EB', the
        // platform's own default primary color), it renders verbatim
        // instead of a real name. This check finds every row affected by
        // that exact pattern, not just the one reported listing.
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$p}listings'" ) ) {
            $hex_titles = $wpdb->get_results(
                "SELECT l.id, l.slug, l.title, l.vendor_id, vp.business_name
                 FROM {$p}listings l
                 LEFT JOIN {$p}vendor_profiles vp ON vp.id = l.vendor_id
                 WHERE TRIM(l.title) REGEXP '^#[0-9a-fA-F]{3,6}$' AND l.status != 'deleted'"
            );
            if ( $hex_titles ) {
                $rows_detail = [];
                foreach ( $hex_titles as $row ) {
                    $vendor_also_corrupt = $row->business_name && preg_match( '/^#[0-9a-fA-F]{3,6}$/i', trim( $row->business_name ) );
                    $would_resolve_to = ! empty( $row->business_name ) && ! $vendor_also_corrupt
                        ? $row->business_name
                        : ( \GoodService\Core\Config::get( 'platform_name', 'GoodService' ) ?: 'GoodService' );
                    $rows_detail[] = [
                        'listing_id'        => (int) $row->id,
                        'slug'              => $row->slug,
                        'url'               => home_url( '/' . $row->slug . '/' ),
                        'corrupt_title'     => $row->title,
                        'vendor_id'         => (int) $row->vendor_id,
                        'vendor_business_name' => $row->business_name,
                        'vendor_also_corrupt'  => (bool) $vendor_also_corrupt,
                        'would_fall_back_to'   => $would_resolve_to,
                    ];
                }
                $findings[] = self::finding( self::SRC_DB, 'listing_title_is_hex_color', self::SEV_ERROR,
                    count( $hex_titles ) . ' listing(s) have a hex color code (e.g. "#2563EB") stored literally as the listing title, instead of a real business name',
                    "For each listing below: 1. Confirm the intended business name with the vendor. 2. UPDATE gs_listings SET title = '<real name>' WHERE id = <listing_id>. 3. If the vendor's own business_name (vendor_profiles table) is correct and not itself corrupted, that is shown as the safe fallback value below — consider using it directly if the vendor can't be reached immediately.",
                    'A hex color string in the title column renders verbatim everywhere the page title is used: the <title> tag, meta description/OG tags, the WhatsApp popup name, the sticky bottom action bar, and the breadcrumb. This almost always originates from a bulk listing-creation or data-seeding script that assigned a color-config value (most commonly the platform\'s own default primary color) to the title field instead of the intended business name.',
                    [ 'affected_modules' => ['Listings', 'SEO', 'WhatsApp Widget', 'Vendor Site'], 'affected_rows' => $rows_detail ] );
            }

            // Same check for vendor_profiles.business_name directly, since a
            // corrupted business_name with a CLEAN listing.title is invisible
            // to the check above (title wins first) but still poisons the
            // fallback chain the moment that listing's title is ever cleared,
            // and directly affects any OTHER listing owned by the same vendor
            // whose title is empty.
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$p}vendor_profiles'" ) ) {
                $hex_vendor_names = $wpdb->get_results(
                    "SELECT id, business_name FROM {$p}vendor_profiles WHERE TRIM(business_name) REGEXP '^#[0-9a-fA-F]{3,6}$'"
                );
                if ( $hex_vendor_names ) {
                    $vendor_rows = array_map( fn( $r ) => [ 'vendor_id' => (int) $r->id, 'corrupt_business_name' => $r->business_name ], $hex_vendor_names );
                    $findings[] = self::finding( self::SRC_DB, 'vendor_business_name_is_hex_color', self::SEV_WARNING,
                        count( $hex_vendor_names ) . ' vendor profile(s) have a hex color code stored as business_name',
                        'UPDATE gs_vendor_profiles SET business_name = \'<real name>\' WHERE id = <vendor_id>. This is currently masked wherever that vendor\'s listing has its own valid title, but will surface the moment any listing.title for this vendor is empty or itself corrupted.',
                        'business_name is the fallback source when listing.title is missing or itself a hex color. A corrupted business_name silently affects every listing owned by this vendor that currently has no valid title of its own.',
                        [ 'affected_modules' => ['Vendors', 'SEO'], 'affected_rows' => $vendor_rows ] );
                }
            }
        }

        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$p}bookings'" ) ) {
            $expired_bookings = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$p}bookings
                 WHERE status='pending'
                   AND auto_expire_at IS NOT NULL
                   AND auto_expire_at < NOW()"
            );
            if ( $expired_bookings > 0 ) {
                $findings[] = self::finding( self::SRC_DB, 'bookings_past_auto_expire', self::SEV_WARNING,
                    "{$expired_bookings} pending booking(s) past their auto-expire time but still in 'pending' status",
                    '1. Run the cron manually: wp eval "\\GoodService\\Core\\Cron::booking_auto_expire();" 2. Check if gs_hourly cron is running.',
                    'Bookings stuck in pending past their expiry window indicate the cron auto-expire function is not running. Customers are waiting for expired bookings.',
                    [ 'affected_modules' => ['Bookings', 'Cron'] ] );
            }
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 15-B: Subsystem health scores (§15 gap)
    // ════════════════════════════════════════════════════════════════════════

    public static function get_subsystem_health(): array {
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';

        // Each subsystem gets an independent score
        $scores = [
            'database'      => 100,
            'performance'   => 100,
            'security'      => 100,
            'integrations'  => 100,
            'wordpress'     => 100,
            'infrastructure'=> 100,
        ];

        // Fast per-subsystem checks (not full scan)
        // Database
        if ( ! $wpdb->check_connection( false ) )               { $scores['database'] = 0; }
        elseif ( $wpdb->get_var( "SHOW TABLES LIKE '{$p}listings'" ) === null ) { $scores['database'] -= 30; }
        elseif ( $wpdb->get_var( "SHOW TABLES LIKE '{$p}error_log'" ) === null )  { $scores['database'] -= 10; }

        // Performance
        if ( ! wp_using_ext_object_cache() )                     { $scores['performance'] -= 20; }
        $mem_pct = ( self::parse_bytes( ini_get( 'memory_limit' ) ) > 0 )
            ? memory_get_usage( true ) / self::parse_bytes( ini_get( 'memory_limit' ) ) * 100 : 0;
        if ( $mem_pct > 85 )                                     { $scores['performance'] -= 30; }
        elseif ( $mem_pct > 60 )                                 { $scores['performance'] -= 10; }

        // Security
        if ( ! is_ssl() )                                        { $scores['security'] -= 25; }
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY ) { $scores['security'] -= 20; }
        if ( file_exists( WP_CONTENT_DIR . '/debug.log' ) )     { $scores['security'] -= 10; }

        // Integrations
        if ( ! Config::get( 'razorpay_key_id', '' ) )           { $scores['integrations'] -= 20; }
        if ( ! Config::get( 'razorpay_key_secret', '' ) )       { $scores['integrations'] -= 20; }
        if ( ! get_option( 'admin_email', '' ) )                 { $scores['integrations'] -= 15; }

        // WordPress
        if ( empty( get_option( 'permalink_structure' ) ) )     { $scores['wordpress'] -= 40; }
        if ( ! get_role( 'gs_vendor' ) )                        { $scores['wordpress'] -= 30; }
        if ( get_option( 'gs_activation_error', '' ) )          { $scores['wordpress'] -= 20; }

        // Infrastructure
        if ( self::parse_bytes( ini_get( 'memory_limit' ) ) < 128 * 1024 * 1024 ) { $scores['infrastructure'] -= 25; }
        if ( ! extension_loaded( 'curl' ) )                     { $scores['infrastructure'] -= 20; }
        if ( ! extension_loaded( 'openssl' ) )                  { $scores['infrastructure'] -= 20; }
        if ( ! extension_loaded( 'mbstring' ) )                 { $scores['infrastructure'] -= 10; }

        // Clamp all scores to 0-100
        return array_map( fn( $s ) => max( 0, min( 100, $s ) ), $scores );
    }

    // ════════════════════════════════════════════════════════════════════════
    // §13: Enhanced reports with missing sections
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Get server log tail (last N lines of gs-debug.log).
     * Satisfies §13 "Server logs" in diagnostic reports.
     */
    public static function get_server_logs( int $lines = 100 ): array {
        $log_file = WP_CONTENT_DIR . '/gs-debug.log';
        if ( ! file_exists( $log_file ) ) { return []; }
        $all = @file( $log_file ) ?: [];
        return array_values( array_slice( $all, -$lines ) );
    }

    /**
     * Get historical occurrence trend for a specific error type or all.
     * Satisfies §13 "Historical occurrence tracking".
     */
    public static function get_occurrence_history( string $type = '', int $days = 30 ): array {
        global $wpdb;
        $tbl = self::tbl_errors();
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) { return []; }

        $where = $type ? $wpdb->prepare( "AND type=%s", $type ) : '';

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT DATE(last_seen) as date, source, severity,
                    COUNT(*) as distinct_errors,
                    SUM(occurrence_count) as total_occurrences
             FROM {$tbl}
             WHERE last_seen >= DATE_SUB(NOW(), INTERVAL %d DAY) {$where}
             GROUP BY DATE(last_seen), source, severity
             ORDER BY date ASC",
            $days
        ) ) ?: [];
    }

    // ════════════════════════════════════════════════════════════════════════
    // §17: Admin email alert on new critical errors
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Send an admin email alert when a new critical error is first captured.
     * Called from capture() when severity=critical and is a new row (not a dedup).
     */
    public static function send_critical_alert( string $message, string $source, string $type ): void {
        // Respect admin preference — gs_diag_alert_emails must be 1 to send alerts
        if ( ! get_option( 'gs_diag_alert_emails', 0 ) ) { return; }

        // Only send if alert emails are enabled and not recently sent (1hr cooldown per type)
        $cooldown_key = 'gs_diag_alert_' . md5( $source . $type );
        if ( get_transient( $cooldown_key ) ) { return; }
        set_transient( $cooldown_key, 1, HOUR_IN_SECONDS );

        $admin_email = Config::get( 'platform_email', get_option( 'admin_email', '' ) );
        $platform    = Config::get( 'platform_name', 'GoodService' );
        $site_url    = site_url();

        if ( ! $admin_email || ! is_email( $admin_email ) ) { return; }

        wp_mail(
            $admin_email,
            "🚨 [{$platform}] Critical Error Detected — {$source}/{$type}",
            "A critical error has been detected on your {$platform} platform.\n\n"
            . "Error: {$message}\n"
            . "Source: {$source}\n"
            . "Type: {$type}\n"
            . "Time: " . current_time( 'mysql' ) . "\n"
            . "Site: {$site_url}\n\n"
            . "Go to your diagnostic dashboard to investigate:\n"
            . admin_url( 'admin.php?page=goodservice&section=diagnostics&dtab=errors' ) . "\n\n"
            . "This alert will not repeat for 1 hour for the same error type.\n"
            . "— {$platform} Diagnostic System",
            [ 'Content-Type: text/plain; charset=UTF-8' ]
        );
    }

    

    /**
     * Analyses error_log for patterns that indicate systemic issues not
     * caught by individual checks — the "unknown error detection" requirement.
     * Uses frequency analysis, clustering, and anomaly detection heuristics.
     */
    private static function analyse_error_patterns(): array {
        global $wpdb;
        $findings = [];
        $tbl      = self::tbl_errors();

        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) {
            return $findings;
        }

        // ── Pattern 1: Error storm — many errors in a short window ────────
        $recent_count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$tbl} WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d MINUTE) AND is_resolved=0",
            15
        ) );
        if ( $recent_count >= 50 ) {
            $findings[] = self::finding( self::SRC_PHP, 'error_storm', self::SEV_CRITICAL,
                "{$recent_count} errors in the last 15 minutes — error storm detected",
                '1. Check if a recent deployment or config change triggered this. 2. Roll back the last change. 3. Review the most frequent error type below.',
                'Error storms indicate a systemic failure. User experience is severely degraded.' );
        } elseif ( $recent_count >= 20 ) {
            $findings[] = self::finding( self::SRC_PHP, 'elevated_error_rate', self::SEV_ERROR,
                "{$recent_count} errors in the last 15 minutes — elevated error rate",
                'Investigate the most frequent error type. Check recent deployments.',
                'Elevated error rate indicates emerging instability.' );
        }

        // ── Pattern 2: Repeating error dominance ──────────────────────────
        $top_error = $wpdb->get_row(
            "SELECT type, SUM(occurrence_count) as total, source
             FROM {$tbl}
             WHERE is_resolved=0 AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
             GROUP BY type, source
             ORDER BY total DESC
             LIMIT 1"
        );
        if ( $top_error && (int) $top_error->total >= 100 ) {
            $rca = self::analyse_root_cause( $top_error->source, $top_error->type, $top_error->type, [] );
            $findings[] = self::finding( $top_error->source, 'dominant_error_pattern', self::SEV_ERROR,
                "Error type '{$top_error->type}' has occurred {$top_error->total} times in 24h — systematic issue",
                $rca['suggested_fix'],
                "A single error type dominating the log indicates a root systemic problem that affects many users." );
        }

        // ── Pattern 3: Security cluster — multiple security events ────────
        $security_cluster = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$tbl}
             WHERE source=%s AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)",
            self::SRC_SECURITY
        ) );
        if ( $security_cluster >= 20 ) {
            $findings[] = self::finding( self::SRC_SECURITY, 'security_event_cluster', self::SEV_CRITICAL,
                "{$security_cluster} security events in the last hour — active attack or misconfiguration",
                '1. Review IP addresses in recent security events. 2. Block malicious IPs at WAF/firewall. 3. Enable 2FA. 4. Check for unauthorized file changes.',
                'Cluster of security events indicates either an active attack or a fundamental authentication misconfiguration.' );
        }

        // ── Pattern 4: DB errors correlating with performance ─────────────
        $db_perf_errors = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$tbl}
             WHERE source IN (%s, %s) AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)",
            self::SRC_DB, self::SRC_PERFORMANCE
        ) );
        if ( $db_perf_errors >= 10 ) {
            $findings[] = self::finding( self::SRC_DB, 'db_performance_correlation', self::SEV_ERROR,
                "{$db_perf_errors} DB/performance errors in the last hour — database is likely under stress",
                '1. Check MySQL processlist for blocking queries. 2. Review slow query log. 3. Check server CPU/IO metrics. 4. Consider adding read replicas.',
                'Correlated DB and performance errors indicate database resource exhaustion.' );
        }

        // ── Pattern 5: Unresolved critical errors older than 24h ──────────
        $stale_criticals = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$tbl}
             WHERE severity=%s AND is_resolved=0 AND created_at <= DATE_SUB(NOW(), INTERVAL 24 HOUR)",
            self::SEV_CRITICAL
        ) );
        if ( $stale_criticals > 0 ) {
            $findings[] = self::finding( self::SRC_PHP, 'stale_critical_errors', self::SEV_WARNING,
                "{$stale_criticals} critical errors unresolved for 24+ hours",
                'Review the Error Log tab and address critical issues systematically, starting with the highest-frequency ones.',
                'Long-standing critical errors indicate blind spots in monitoring or insufficient response to alerts.' );
        }

        return $findings;
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 13/14: Report Generator & Download Center
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Generate a diagnostic report in the requested format.
     * Supports: json, csv, html, txt (for printable view).
     * PDF is generated client-side via browser print dialog from the HTML format.
     */
    public static function generate_report( int $run_id, string $format = 'json' ): array {
        global $wpdb;

        $run = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::tbl_runs() . " WHERE id=%d", $run_id
        ) );

        if ( ! $run ) {
            return [ 'error' => 'Run not found' ];
        }

        $summary  = json_decode( $run->summary ?? '{}', true ) ?: [];
        $findings = json_decode( $run->findings ?? '[]', true ) ?: [];

        // Recent error log entries
        $errors = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . self::tbl_errors() . "
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             ORDER BY severity ASC, occurrence_count DESC
             LIMIT 500"
        ) ) ?: [];

        switch ( $format ) {
            case 'csv':
                return self::report_csv( $run, $summary, $findings, $errors );
            case 'html':
                return self::report_html( $run, $summary, $findings, $errors );
            case 'txt':
                return self::report_txt( $run, $summary, $findings, $errors );
            default:
                return self::report_json( $run, $summary, $findings, $errors );
        }
    }

    private static function report_json( object $run, array $summary, array $findings, array $errors ): array {
        $platform = Config::get( 'platform_name', 'GoodService' );
        $data = [
            'report_meta' => [
                'generated_at' => current_time( 'mysql' ),
                'platform'     => $platform,
                'site_url'     => site_url(),
                'wp_version'   => $GLOBALS['wp_version'] ?? 'unknown',
                'php_version'  => PHP_VERSION,
                'run_id'       => (int) $run->id,
                'run_type'     => $run->run_type,
                'completed_at' => $run->completed_at,
            ],
            'executive_summary' => [
                'health_score'      => $summary['health_score'] ?? 0,
                'status'            => ( $summary['health_score'] ?? 0 ) >= 80 ? 'HEALTHY' : ( ( $summary['health_score'] ?? 0 ) >= 60 ? 'WARNING' : 'CRITICAL' ),
                'critical_findings' => $summary['critical_count'] ?? 0,
                'error_findings'    => $summary['error_count'] ?? 0,
                'warning_findings'  => $summary['warning_count'] ?? 0,
                'total_findings'    => $summary['total_findings'] ?? 0,
                'scan_duration_ms'  => $summary['duration_ms'] ?? 0,
            ],
            'findings'     => $findings,
            'error_log'    => array_map( function( $e ) {
                return [
                    'id'               => $e->id,
                    'source'           => $e->source,
                    'type'             => $e->type,
                    'severity'         => $e->severity,
                    'message'          => $e->message,
                    'file'             => $e->file_path,
                    'line'             => $e->line_number,
                    'occurrences'      => $e->occurrence_count,
                    'first_seen'       => $e->first_seen,
                    'last_seen'        => $e->last_seen,
                    'root_cause'       => $e->root_cause,
                    'suggested_fix'    => $e->suggested_fix,
                    'is_resolved'      => (bool) $e->is_resolved,
                ];
            }, $errors ),
            'environment' => [
                'php_version'         => PHP_VERSION,
                'memory_limit'        => ini_get( 'memory_limit' ),
                'memory_used_mb'      => round( memory_get_usage( true ) / 1024 / 1024, 2 ),
                'post_max_size'       => ini_get( 'post_max_size' ),
                'upload_max_filesize' => ini_get( 'upload_max_filesize' ),
                'max_execution_time'  => ini_get( 'max_execution_time' ),
                'max_input_vars'      => ini_get( 'max_input_vars' ),
                'active_plugins'      => count( get_option( 'active_plugins', [] ) ),
                'object_cache'        => wp_using_ext_object_cache() ? 'external' : 'default',
                'is_https'            => is_ssl(),
                'wp_debug'            => defined( 'WP_DEBUG' ) && WP_DEBUG,
            ],
            // §13: Performance metrics section
            'performance_metrics' => [
                'memory_usage_pct'   => self::parse_bytes( ini_get( 'memory_limit' ) ) > 0
                    ? round( memory_get_usage( true ) / self::parse_bytes( ini_get( 'memory_limit' ) ) * 100, 1 ) : 0,
                'peak_memory_mb'     => round( memory_get_peak_usage( true ) / 1024 / 1024, 2 ),
                'active_plugin_count'=> count( get_option( 'active_plugins', [] ) ),
                'object_cache_active'=> wp_using_ext_object_cache(),
                'autoloaded_options_kb' => (function() {
                    global $wpdb;
                    return round( (float) $wpdb->get_var( "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE autoload='yes'" ) / 1024, 0 );
                })(),
            ],
            // §13: Security findings section (security-sourced errors only)
            'security_findings'   => array_values( array_filter( $findings, fn( $f ) => $f['source'] === self::SRC_SECURITY ) ),
            // §13: Server logs (last 50 lines of gs-debug.log)
            'server_logs'         => self::get_server_logs( 50 ),
            // §13: Historical occurrence tracking (30-day trend)
            'historical_occurrences' => self::get_occurrence_history( '', 30 ),
            // §13: Subsystem health scores
            'subsystem_health'    => self::get_subsystem_health(),
            // §13: Suggested code fixes — extracted from findings with file references
            'suggested_code_fixes' => array_values( array_filter(
                array_map( function( $f ) {
                    if ( empty( $f['affected_files'] ) && empty( $f['affected_functions'] ) ) { return null; }
                    return [
                        'type'               => $f['type'] ?? '',
                        'severity'           => $f['severity'] ?? '',
                        'affected_files'     => $f['affected_files'] ?? [],
                        'affected_functions' => $f['affected_functions'] ?? [],
                        'affected_modules'   => $f['affected_modules'] ?? [],
                        'suggested_fix'      => $f['suggested_fix'] ?? '',
                        'reproduction_steps' => $f['reproduction_steps'] ?? '',
                        'fix_priority'       => $f['fix_priority'] ?? 3,
                        'estimated_impact'   => $f['estimated_impact'] ?? '',
                    ];
                }, $findings ),
                fn( $f ) => $f !== null
            ) ),
        ];

        return [
            'format'   => 'json',
            'filename' => 'gs-diagnostic-report-' . date( 'Y-m-d-His' ) . '.json',
            'content'  => wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ),
            'mime'     => 'application/json',
        ];
    }

    private static function report_csv( object $run, array $summary, array $findings, array $errors ): array {
        $rows = [];
        $rows[] = [ 'GoodService Diagnostic Report', site_url(), date( 'Y-m-d H:i:s' ) ];
        $rows[] = [ 'Health Score', ( $summary['health_score'] ?? 0 ) . '/100' ];
        $rows[] = [];
        $rows[] = [ 'ID', 'Source', 'Type', 'Severity', 'Message', 'File', 'Line', 'Occurrences', 'First Seen', 'Last Seen', 'Root Cause', 'Suggested Fix', 'Resolved' ];

        foreach ( $errors as $e ) {
            $rows[] = [
                $e->id, $e->source, $e->type, $e->severity,
                str_replace( [ "\r", "\n", '"' ], [ ' ', ' ', '""' ], $e->message ),
                $e->file_path, $e->line_number, $e->occurrence_count,
                $e->first_seen, $e->last_seen,
                str_replace( [ "\r", "\n" ], ' ', $e->root_cause ?? '' ),
                str_replace( [ "\r", "\n" ], ' ', $e->suggested_fix ?? '' ),
                $e->is_resolved ? 'Yes' : 'No',
            ];
        }

        $rows[] = [];
        $rows[] = [ '--- SCAN FINDINGS ---' ];
        $rows[] = [ 'Source', 'Type', 'Severity', 'Message', 'Root Cause', 'Fix' ];
        foreach ( $findings as $f ) {
            $rows[] = [
                $f['source'] ?? '', $f['type'] ?? '', $f['severity'] ?? '',
                str_replace( [ "\r", "\n" ], ' ', $f['message'] ?? '' ),
                str_replace( [ "\r", "\n" ], ' ', $f['root_cause'] ?? '' ),
                str_replace( [ "\r", "\n" ], ' ', $f['suggested_fix'] ?? '' ),
            ];
        }

        $csv = '';
        foreach ( $rows as $row ) {
            $csv .= implode( ',', array_map( fn( $cell ) => '"' . $cell . '"', $row ) ) . "\r\n";
        }

        return [
            'format'   => 'csv',
            'filename' => 'gs-diagnostic-report-' . date( 'Y-m-d-His' ) . '.csv',
            'content'  => "\xEF\xBB\xBF" . $csv, // UTF-8 BOM for Excel
            'mime'     => 'text/csv',
        ];
    }

    private static function report_html( object $run, array $summary, array $findings, array $errors ): array {
        $platform   = esc_html( Config::get( 'platform_name', 'GoodService' ) );
        $score      = (int) ( $summary['health_score'] ?? 0 );
        $score_col  = $score >= 80 ? '#059669' : ( $score >= 60 ? '#D97706' : '#DC2626' );
        $gen_date   = date( 'D, d M Y H:i:s' );

        $sev_colors = [
            'critical' => '#FEF2F2', 'error' => '#FFF7ED',
            'warning'  => '#FFFBEB', 'notice' => '#F0F9FF', 'info' => '#F8FAFC',
        ];
        $sev_text = [
            'critical' => '#991B1B', 'error' => '#9A3412',
            'warning'  => '#92400E', 'notice' => '#075985', 'info' => '#334155',
        ];
        $sev_badge = [
            'critical' => '#DC2626', 'error' => '#EA580C',
            'warning'  => '#D97706', 'notice' => '#0284C7', 'info' => '#64748B',
        ];

        $findings_html = '';
        foreach ( $findings as $f ) {
            $sev  = $f['severity'] ?? 'info';
            $bg   = $sev_colors[ $sev ] ?? '#F8FAFC';
            $tc   = $sev_text[ $sev ]   ?? '#334155';
            $bc   = $sev_badge[ $sev ]  ?? '#64748B';
            $findings_html .= "
            <div style='background:{$bg};border:1px solid {$bc}30;border-radius:8px;padding:14px;margin-bottom:10px'>
              <div style='display:flex;align-items:center;gap:10px;margin-bottom:8px'>
                <span style='background:{$bc};color:#fff;padding:2px 10px;border-radius:12px;font-size:.72rem;font-weight:700;text-transform:uppercase'>" . esc_html( $sev ) . "</span>
                <span style='font-weight:700;color:{$tc};font-size:.88rem'>" . esc_html( $f['source'] ?? '' ) . " / " . esc_html( $f['type'] ?? '' ) . "</span>
              </div>
              <p style='margin:0 0 8px;color:{$tc};font-size:.85rem'>" . esc_html( $f['message'] ?? '' ) . "</p>
              <div style='font-size:.8rem;color:#64748B'>
                <strong>Root Cause:</strong> " . esc_html( $f['root_cause'] ?? '' ) . "
              </div>
              <div style='font-size:.8rem;color:#059669;margin-top:4px'>
                <strong>Fix:</strong> " . esc_html( $f['suggested_fix'] ?? '' ) . "
              </div>
            </div>";
        }

        $errors_html = '';
        foreach ( array_slice( $errors, 0, 100 ) as $e ) {
            $sev  = $e->severity;
            $bg   = $sev_colors[ $sev ] ?? '#F8FAFC';
            $bc   = $sev_badge[ $sev ]  ?? '#64748B';
            $errors_html .= "
            <tr style='border-bottom:1px solid #E2E8F0'>
              <td style='padding:8px;font-size:.75rem'><span style='background:{$bc};color:#fff;padding:2px 8px;border-radius:10px;font-size:.68rem'>" . esc_html( $sev ) . "</span></td>
              <td style='padding:8px;font-size:.75rem;font-weight:600'>" . esc_html( $e->source ) . '</td>
              <td style=\'padding:8px;font-size:.75rem\'>' . esc_html( substr( $e->message, 0, 120 ) ) . (strlen($e->message)>120?'…':'') . "</td>
              <td style='padding:8px;font-size:.75rem;text-align:center'>" . esc_html( (string) $e->occurrence_count ) . "</td>
              <td style='padding:8px;font-size:.75rem'>" . esc_html( $e->last_seen ) . "</td>
              <td style='padding:8px;font-size:.75rem;color:#059669'>" . esc_html( substr( $e->suggested_fix ?? '', 0, 100 ) ) . "</td>
            </tr>";
        }

        $html = "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'>
<title>{$platform} Diagnostic Report — {$gen_date}</title>
<style>
  * { box-sizing:border-box; margin:0; padding:0; }
  body { font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; color:#1E293B; background:#F8FAFC; padding:32px; }
  h1 { font-size:1.5rem; color:#1E293B; margin-bottom:4px; }
  h2 { font-size:1.1rem; color:#334155; margin:24px 0 12px; border-bottom:2px solid #E2E8F0; padding-bottom:8px; }
  table { width:100%; border-collapse:collapse; }
  th { background:#1E293B; color:#fff; padding:10px 8px; text-align:left; font-size:.78rem; }
  .badge { display:inline-block; padding:3px 10px; border-radius:12px; font-size:.72rem; font-weight:700; }
  @media print { body { padding:16px; } }
</style>
</head><body>
<div style='background:#1E3A5F;color:#fff;padding:24px 32px;border-radius:12px;margin-bottom:24px'>
  <h1>🔬 {$platform} — Diagnostic Report</h1>
  <p style='color:rgba(255,255,255,.7);margin-top:4px;font-size:.85rem'>Generated: {$gen_date} | Site: " . esc_html( site_url() ) . " | PHP " . PHP_VERSION . " | WP " . ( $GLOBALS['wp_version'] ?? '?' ) . "</p>
</div>

<div style='display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px'>
  <div style='background:#fff;border-radius:10px;padding:20px;text-align:center;border:1px solid #E2E8F0'>
    <div style='font-size:2.5rem;font-weight:900;color:{$score_col}'>{$score}</div>
    <div style='font-size:.8rem;color:#64748B;margin-top:4px'>Health Score / 100</div>
  </div>
  <div style='background:#FEF2F2;border-radius:10px;padding:20px;text-align:center;border:1px solid #FECACA'>
    <div style='font-size:2rem;font-weight:800;color:#DC2626'>" . ( $summary['critical_count'] ?? 0 ) . "</div>
    <div style='font-size:.8rem;color:#64748B;margin-top:4px'>Critical Issues</div>
  </div>
  <div style='background:#FFF7ED;border-radius:10px;padding:20px;text-align:center;border:1px solid #FED7AA'>
    <div style='font-size:2rem;font-weight:800;color:#EA580C'>" . ( $summary['error_count'] ?? 0 ) . "</div>
    <div style='font-size:.8rem;color:#64748B;margin-top:4px'>Errors</div>
  </div>
  <div style='background:#FFFBEB;border-radius:10px;padding:20px;text-align:center;border:1px solid #FDE68A'>
    <div style='font-size:2rem;font-weight:800;color:#D97706'>" . ( $summary['warning_count'] ?? 0 ) . "</div>
    <div style='font-size:.8rem;color:#64748B;margin-top:4px'>Warnings</div>
  </div>
</div>

<h2>🔍 Scan Findings</h2>
{$findings_html}

<h2>📋 Error Log (last 7 days, top 100)</h2>
<table>
  <tr><th>Severity</th><th>Source</th><th>Message</th><th>Count</th><th>Last Seen</th><th>Fix</th></tr>
  {$errors_html}
</table>

<h2>⚙️ Environment</h2>
<table style='max-width:600px'>
  <tr><th>Key</th><th>Value</th></tr>
  <tr><td style='padding:6px 8px;font-size:.82rem'>PHP Version</td><td style='padding:6px 8px;font-size:.82rem'>" . PHP_VERSION . "</td></tr>
  <tr><td style='padding:6px 8px;font-size:.82rem'>Memory Limit</td><td style='padding:6px 8px;font-size:.82rem'>" . ini_get('memory_limit') . "</td></tr>
  <tr><td style='padding:6px 8px;font-size:.82rem'>Memory Used</td><td style='padding:6px 8px;font-size:.82rem'>" . round(memory_get_usage(true)/1024/1024,1) . "MB</td></tr>
  <tr><td style='padding:6px 8px;font-size:.82rem'>post_max_size</td><td style='padding:6px 8px;font-size:.82rem'>" . ini_get('post_max_size') . "</td></tr>
  <tr><td style='padding:6px 8px;font-size:.82rem'>upload_max_filesize</td><td style='padding:6px 8px;font-size:.82rem'>" . ini_get('upload_max_filesize') . "</td></tr>
  <tr><td style='padding:6px 8px;font-size:.82rem'>max_execution_time</td><td style='padding:6px 8px;font-size:.82rem'>" . ini_get('max_execution_time') . "s</td></tr>
</table>

<p style='margin-top:32px;font-size:.75rem;color:#94A3B8;text-align:center'>
  {$platform} Diagnostic Report · Run ID #{$run->id} · " . esc_html( site_url() ) . "
  <br>This report is confidential. Do not share publicly.
</p>
</body></html>";

        return [
            'format'   => 'html',
            'filename' => 'gs-diagnostic-report-' . date( 'Y-m-d-His' ) . '.html',
            'content'  => $html,
            'mime'     => 'text/html',
        ];
    }

    private static function report_txt( object $run, array $summary, array $findings, array $errors ): array {
        $platform = Config::get( 'platform_name', 'GoodService' );
        $divider  = str_repeat( '=', 80 );
        $thin     = str_repeat( '-', 80 );

        $out  = $divider . "\n";
        $out .= "  {$platform} — DIAGNOSTIC REPORT\n";
        $out .= "  Generated: " . date( 'Y-m-d H:i:s' ) . " | Run ID: #{$run->id}\n";
        $out .= "  Site: " . site_url() . "\n";
        $out .= $divider . "\n\n";

        $out .= "EXECUTIVE SUMMARY\n" . $thin . "\n";
        $out .= "Health Score   : " . ( $summary['health_score'] ?? 0 ) . " / 100\n";
        $out .= "Critical Issues: " . ( $summary['critical_count'] ?? 0 ) . "\n";
        $out .= "Errors         : " . ( $summary['error_count'] ?? 0 ) . "\n";
        $out .= "Warnings       : " . ( $summary['warning_count'] ?? 0 ) . "\n";
        $out .= "Total Findings : " . ( $summary['total_findings'] ?? 0 ) . "\n";
        $out .= "Scan Duration  : " . ( $summary['duration_ms'] ?? 0 ) . "ms\n\n";

        $out .= "FINDINGS\n" . $thin . "\n";
        foreach ( $findings as $i => $f ) {
            $out .= ( $i + 1 ) . ". [" . strtoupper( $f['severity'] ?? '' ) . "] " . ( $f['source'] ?? '' ) . " / " . ( $f['type'] ?? '' ) . "\n";
            $out .= "   Issue : " . ( $f['message'] ?? '' ) . "\n";
            $out .= "   Cause : " . ( $f['root_cause'] ?? '' ) . "\n";
            $out .= "   Fix   : " . ( $f['suggested_fix'] ?? '' ) . "\n\n";
        }

        $out .= "ERROR LOG (last 7 days, top 100)\n" . $thin . "\n";
        foreach ( array_slice( $errors, 0, 100 ) as $e ) {
            $out .= "[" . strtoupper( $e->severity ) . "] [{$e->source}] {$e->message}\n";
            $out .= "  File: {$e->file_path}:{$e->line_number} | Count: {$e->occurrence_count} | Last: {$e->last_seen}\n";
            $out .= "  Fix : " . ( $e->suggested_fix ?? 'See documentation.' ) . "\n\n";
        }

        return [
            'format'   => 'txt',
            'filename' => 'gs-diagnostic-report-' . date( 'Y-m-d-His' ) . '.txt',
            'content'  => $out,
            'mime'     => 'text/plain',
        ];
    }

    // ════════════════════════════════════════════════════════════════════════
    // SECTION 15: Real-Time Dashboard Data
    // ════════════════════════════════════════════════════════════════════════

    public static function get_dashboard_data(): array {
        global $wpdb;
        $tbl_err  = self::tbl_errors();
        $tbl_runs = self::tbl_runs();

        $has_error_log = (bool) $wpdb->get_var( "SHOW TABLES LIKE '{$tbl_err}'" );
        $has_runs      = (bool) $wpdb->get_var( "SHOW TABLES LIKE '{$tbl_runs}'" );

        // Latest run
        $last_run = $has_runs ? $wpdb->get_row(
            "SELECT * FROM {$tbl_runs} WHERE status='complete' ORDER BY completed_at DESC LIMIT 1"
        ) : null;

        // Current 24h error counts by severity
        $severity_counts = [];
        if ( $has_error_log ) {
            $rows = $wpdb->get_results(
                "SELECT severity, SUM(occurrence_count) as total
                 FROM {$tbl_err}
                 WHERE last_seen >= DATE_SUB(NOW(), INTERVAL 24 HOUR) AND is_resolved=0
                 GROUP BY severity"
            ) ?: [];
            foreach ( $rows as $r ) {
                $severity_counts[ $r->severity ] = (int) $r->total;
            }
        }

        // Error trend (last 7 days, daily)
        $trend = [];
        if ( $has_error_log ) {
            $trend_rows = $wpdb->get_results(
                "SELECT DATE(created_at) as day, severity, COUNT(*) as cnt
                 FROM {$tbl_err}
                 WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                 GROUP BY DATE(created_at), severity
                 ORDER BY day ASC"
            ) ?: [];
            foreach ( $trend_rows as $r ) {
                $trend[ $r->day ][ $r->severity ] = (int) $r->cnt;
            }
        }

        // Source breakdown
        $source_counts = [];
        if ( $has_error_log ) {
            $src_rows = $wpdb->get_results(
                "SELECT source, COUNT(*) as cnt
                 FROM {$tbl_err}
                 WHERE last_seen >= DATE_SUB(NOW(), INTERVAL 24 HOUR) AND is_resolved=0
                 GROUP BY source
                 ORDER BY cnt DESC"
            ) ?: [];
            foreach ( $src_rows as $r ) {
                $source_counts[ $r->source ] = (int) $r->cnt;
            }
        }

        // Recent critical errors
        $recent_criticals = $has_error_log ? ( $wpdb->get_results(
            "SELECT id, source, type, message, occurrence_count, last_seen, suggested_fix
             FROM {$tbl_err}
             WHERE severity='critical' AND is_resolved=0
             ORDER BY last_seen DESC LIMIT 5"
        ) ?: [] ) : [];

        // Health scores by subsystem
        $last_summary = $last_run ? ( json_decode( $last_run->summary ?? '{}', true ) ?: [] ) : [];
        $health_score = $last_summary['health_score'] ?? null;

        return [
            'last_run'         => $last_run ? [
                'id'             => $last_run->id,
                'completed_at'   => $last_run->completed_at,
                'health_score'   => $last_run->health_score,
                'critical_count' => $last_run->critical_count,
                'error_count'    => $last_run->error_count,
                'warning_count'  => $last_run->warning_count,
                'duration_ms'    => $last_run->duration_ms,
            ] : null,
            'health_score'      => $health_score,
            'subsystem_health'  => self::get_subsystem_health(),
            'severity_counts'   => $severity_counts,
            'source_counts'     => $source_counts,
            'trend'             => $trend,
            'recent_criticals'  => $recent_criticals,
            'occurrence_history'=> self::get_occurrence_history( '', 7 ),
            'server_log_tail'   => array_slice( self::get_server_logs( 20 ), -20 ),
            'environment'       => [
                'php_version'    => PHP_VERSION,
                'memory_limit'   => ini_get( 'memory_limit' ),
                'memory_used_mb' => round( memory_get_usage( true ) / 1024 / 1024, 1 ),
                'wp_debug'       => defined( 'WP_DEBUG' ) && WP_DEBUG,
                'wp_version'     => $GLOBALS['wp_version'] ?? '?',
                'active_plugins' => count( get_option( 'active_plugins', [] ) ),
                'is_multisite'   => is_multisite(),
                'object_cache'   => wp_using_ext_object_cache(),
            ],
        ];
    }

    // ════════════════════════════════════════════════════════════════════════
    // Helpers
    // ════════════════════════════════════════════════════════════════════════

    /** Build a standardised finding array — §12 RCA fields included */
    private static function finding(
        string $source, string $type, string $severity,
        string $message, string $suggested_fix, string $root_cause,
        array  $extra = []
    ): array {
        // Fix priority: 1=critical now, 2=high today, 3=medium this-week, 4=low planned
        $priority_map = [
            self::SEV_CRITICAL => 1, self::SEV_ERROR   => 2,
            self::SEV_WARNING  => 3, self::SEV_NOTICE   => 4, self::SEV_INFO => 4,
        ];
        return array_merge( compact( 'source', 'type', 'severity', 'message', 'suggested_fix', 'root_cause' ), [
            'fix_priority'       => $extra['fix_priority']    ?? ( $priority_map[ $severity ] ?? 3 ),
            'estimated_impact'   => $extra['estimated_impact'] ?? self::default_impact( $severity ),
            'affected_files'     => $extra['affected_files']   ?? [],
            'affected_functions' => $extra['affected_functions'] ?? [],
            'affected_modules'   => $extra['affected_modules']  ?? [],
            'reproduction_steps' => $extra['reproduction_steps'] ?? '',
            'related_deps'       => $extra['related_deps']      ?? [],
            // Real fix: generic structured detail for findings that
            // identify individual affected database rows, not just a
            // count — was previously silently dropped by this whitelist
            // merge for any check that tried to attach it.
            'affected_rows'      => $extra['affected_rows']     ?? [],
        ] );
    }

    private static function default_impact( string $severity ): string {
        return match( $severity ) {
            self::SEV_CRITICAL => 'Site-wide failure or data loss. All users affected. Immediate action required.',
            self::SEV_ERROR    => 'Feature unavailable for affected users. Revenue or data impact possible.',
            self::SEV_WARNING  => 'Degraded experience. Performance or compatibility risk.',
            self::SEV_NOTICE   => 'Minor issue. No immediate user impact but should be addressed.',
            default            => 'Informational. No direct user impact.',
        };
    }

    /** Parse PHP ini byte strings (e.g. "256M", "2G") */
    public static function parse_bytes( string $val ): int {
        $val  = trim( $val );
        if ( ! $val ) { return 0; }
        $last = strtolower( $val[ strlen( $val ) - 1 ] );
        $num  = (int) $val;
        return match ( $last ) {
            'g' => $num * 1_073_741_824,
            'm' => $num * 1_048_576,
            'k' => $num * 1_024,
            default => $num,
        };
    }

    /** Mark an error as resolved */
    public static function resolve( int $error_id ): bool {
        global $wpdb;
        return (bool) $wpdb->update( self::tbl_errors(), [
            'is_resolved' => 1,
        ], [ 'id' => $error_id ] );
    }

    /** Bulk resolve all errors of a given severity */
    public static function resolve_all( string $severity = '' ): int {
        global $wpdb;
        $where = [ 'is_resolved' => 0 ];
        if ( $severity ) { $where['severity'] = $severity; }
        return (int) $wpdb->update( self::tbl_errors(), [ 'is_resolved' => 1 ], $where );
    }

    /** Get paginated error list for dashboard */
    public static function get_errors(
        array $filters = [],
        int $page = 1,
        int $per_page = 50
    ): array {
        global $wpdb;
        $tbl    = self::tbl_errors();
        $where  = [ 'is_resolved=0' ];
        $vals   = [];

        if ( ! empty( $filters['severity'] ) ) {
            $where[] = 'severity=%s'; $vals[] = $filters['severity'];
        }
        if ( ! empty( $filters['source'] ) ) {
            $where[] = 'source=%s'; $vals[] = $filters['source'];
        }
        if ( ! empty( $filters['search'] ) ) {
            $like    = '%' . $wpdb->esc_like( $filters['search'] ) . '%';
            $where[] = '(message LIKE %s OR type LIKE %s)';
            $vals[]  = $like; $vals[] = $like;
        }

        $wsql   = implode( ' AND ', $where );
        $offset = ( $page - 1 ) * $per_page;
        $vals_count = $vals;

        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$tbl} WHERE {$wsql}", ...$vals_count
        ) );

        $errors = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$tbl} WHERE {$wsql}
             ORDER BY severity ASC, occurrence_count DESC, last_seen DESC
             LIMIT %d OFFSET %d",
            ...array_merge( $vals, [ $per_page, $offset ] )
        ) ) ?: [];

        return [ 'errors' => $errors, 'total' => $total, 'page' => $page, 'per_page' => $per_page ];
    }

    /** Get all historical diagnostic runs for the run history panel */
    public static function get_runs( int $limit = 20 ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT id, run_type, status, health_score, critical_count, error_count,
                    warning_count, duration_ms, created_at, completed_at
             FROM " . self::tbl_runs() . "
             WHERE status='complete'
             ORDER BY completed_at DESC LIMIT %d",
            $limit
        ) ) ?: [];
    }
}
