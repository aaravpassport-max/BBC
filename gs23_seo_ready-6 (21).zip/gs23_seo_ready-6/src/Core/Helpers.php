<?php
namespace GoodService\Core;

final class Helpers {

    public static function format_price( float $amount, bool $with_symbol = true ): string {
        $sym = $with_symbol ? Config::get( 'currency_symbol', '₹' ) : '';
        if ( $amount >= 10_000_000 ) { return $sym . number_format( $amount / 10_000_000, 2 ) . 'Cr'; }
        if ( $amount >= 100_000   ) { return $sym . number_format( $amount / 100_000,    2 ) . 'L';  }
        if ( $amount >= 1_000     ) { return $sym . number_format( $amount / 1_000,      1 ) . 'K'; }
        return $sym . number_format( $amount, 0 );
    }

    public static function stars( float $rating, int $max = 5 ): string {
        $full = (int) floor( $rating );
        $half = ( $rating - $full ) >= 0.5;
        $out  = str_repeat( '★', $full );
        if ( $half ) { $out .= '½'; }
        $out .= str_repeat( '☆', max( 0, $max - $full - (int) $half ) );
        return '<span class="gs-stars" style="color:#F59E0B">' . $out . '</span>';
    }

    public static function time_ago( ?string $datetime ): string {
        if ( ! $datetime ) { return '—'; }
        $s = max( 0, time() - (int) strtotime( $datetime ) );
        return match ( true ) {
            $s < 60        => 'just now',
            $s < 3600      => (int) ( $s / 60 ) . 'm ago',
            $s < 86400     => (int) ( $s / 3600 ) . 'h ago',
            $s < 2592000   => (int) ( $s / 86400 ) . 'd ago',
            $s < 31536000  => (int) ( $s / 2592000 ) . 'mo ago',
            default        => (int) ( $s / 31536000 ) . 'yr ago',
        };
    }

    /**
     * Structural fix for the max_input_vars data-loss class of bug (see
     * AjaxController::saveListing()'s guard and create-listing.php's
     * clSave()): rather than relying on every host's PHP config being
     * generous enough for an ever-growing form, the client now sends its
     * entire field set as ONE JSON string in $_POST['payload'] (plus a
     * handful of untouched top-level fields like action/nonce/listing_id).
     * That is exactly one $_POST entry from PHP's max_input_vars point of
     * view, no matter how much content it carries — the only remaining
     * ceiling is post_max_size (megabytes, not "a few hundred fields"),
     * which every real WordPress host already sets high enough for normal
     * uploads. This makes the fix permanent and host-config-independent,
     * instead of depending on an admin raising max_input_vars correctly
     * (or ever knowing they need to).
     *
     * Fully backward compatible: if no 'payload' field is present (an
     * older cached JS bundle, a different caller, a direct API test),
     * $_POST is left exactly as PHP parsed it and every existing
     * $_POST-reading code path behaves exactly as before.
     *
     * MUST be called before wp_unslash($_POST) is taken anywhere in the
     * calling method, and before any max_input_vars truncation check —
     * the truncation check needs the RAW, pre-merge $_POST count (this
     * method's un-merged return value) since after merging, $_POST will
     * legitimately contain many more keys than PHP ever parsed off the
     * wire.
     *
     * @return int The raw $_POST field count exactly as PHP parsed it,
     *             before any merging — the true truncation signal.
     */
    public static function consume_json_payload(): int {
        $raw_post_count = count( $_POST );

        if ( ! isset( $_POST['payload'] ) || ! is_string( $_POST['payload'] ) || $_POST['payload'] === '' ) {
            return $raw_post_count;
        }

        // wp_magic_quotes() has already addslashes()'d this string like
        // every other superglobal value — reverse it before json_decode(),
        // exactly like every other JSON blob field on this platform.
        $decoded = json_decode( wp_unslash( $_POST['payload'] ), true );
        unset( $_POST['payload'] );

        if ( ! is_array( $decoded ) ) {
            // Corrupted/truncated payload string (e.g. the request body
            // itself was cut short by post_max_size) — leave $_POST as-is
            // (now missing 'payload') so the caller's normal "required
            // field missing" validation reports a clear error, rather than
            // silently proceeding with an empty save.
            return $raw_post_count;
        }

        foreach ( $decoded as $key => $value ) {
            if ( ! is_string( $key ) || $key === '' ) { continue; }
            // Re-apply the same addslashes() layer every other native
            // $_POST value already carries at this point in the request
            // lifecycle, so the one shared `wp_unslash( $_POST )` call
            // every existing method already does continues to produce
            // exactly the same result for these fields as for any
            // natively-submitted field — no double-(un)slashing, no
            // special-casing needed anywhere downstream.
            $_slashed_value = is_string( $value ) ? wp_slash( $value ) : $value;

            // Root-cause fix — bracket-notation nesting. create-listing.php's
            // generic field collector (clCollectData()) builds this payload
            // with `data[el.name] = el.value`, using each input's raw HTML
            // `name` attribute STRING as the JS object key verbatim — so a
            // field named e.g. "property_listings[0][title]" arrives here as
            // one flat key containing literal bracket characters, exactly as
            // written above. A real browser form submission (or PHP's own
            // parse_str()) would instead turn that same name attribute into
            // real nested structure: $_POST['property_listings'][0]['title'].
            // Before this fix, the flat-merge loop below stored the literal
            // bracket-string as a top-level key and never performed that
            // reconstruction, so every save handler that reads a nested key
            // (e.g. AjaxController::saveListing()'s
            // `array_key_exists('property_listings', $post) && is_array(...)`
            // repeater blocks) always found nothing there and silently wrote
            // an empty array — wiping real vendor-entered data on every save.
            // This affects every "own dedicated save path" repeater section
            // that relies on raw bracket-name POST parsing rather than a
            // client-side JSON-array collector (confirmed via a full audit of
            // AjaxController.php's `__present` save blocks): property_listings,
            // room_types, hotel_event_spaces, hotel_events_showcase,
            // hotel_dining, hotel_amenities, featured_projects,
            // featured_services, beauty_services, beauty_gallery,
            // beauty_experts, home_services_catalogue, home_services_packages,
            // home_services_technicians, home_services_guarantee,
            // home_services_before_after, doctors, wedding_portfolio,
            // wedding_stories, wedding_services, wedding_packages,
            // wedding_team, wedding_locations. Reconstructing the nesting
            // here — once, centrally, exactly where the flattening was
            // introduced — fixes all of them uniformly instead of requiring
            // 23+ individual JS collector rewrites, and is a strict no-op for
            // every plain (non-bracket) key, which is the overwhelming
            // majority of this payload and covers every already-working
            // field on this form.
            if ( strpos( $key, '[' ) !== false ) {
                $_path = self::parse_bracket_key( $key );
                if ( count( $_path ) > 1 ) {
                    self::assign_nested( $_POST, $_path, $_slashed_value );
                    continue;
                }
            }

            $_POST[ $key ] = $_slashed_value;
        }

        return $raw_post_count;
    }

    /**
     * Parses an HTML form field name like "foo[0][bar]" into its path
     * segments ['foo', '0', 'bar'], mirroring how PHP natively parses
     * bracket-notation field names out of a real form submission (see
     * consume_json_payload()'s docblock for why this is needed here).
     * "foo[]" (empty brackets — append) yields a null segment. A key with
     * no brackets at all (or malformed bracket syntax) is returned as a
     * single-segment path, i.e. left completely untouched by the caller.
     *
     * @return array<int, string|null>
     */
    private static function parse_bracket_key( string $key ): array {
        if ( ! preg_match( '/^([^\[\]]+)((?:\[[^\[\]]*\])*)$/', $key, $m ) || $m[2] === '' ) {
            return [ $key ];
        }
        $path = [ $m[1] ];
        preg_match_all( '/\[([^\[\]]*)\]/', $m[2], $segments );
        foreach ( $segments[1] as $seg ) {
            $path[] = ( $seg === '' ) ? null : $seg;
        }
        return $path;
    }

    /**
     * Writes $value into $target at the nested location described by
     * $path (as produced by parse_bracket_key()), creating intermediate
     * arrays as needed — the same structure PHP's native superglobal
     * parser would have produced for the equivalent form field name.
     *
     * @param array<int, string|null> $path
     */
    private static function assign_nested( array &$target, array $path, $value ): void {
        $ref  = &$target;
        $last = count( $path ) - 1;
        foreach ( $path as $i => $seg ) {
            if ( $i === $last ) {
                if ( $seg === null ) {
                    $ref[] = $value;
                } else {
                    $ref[ $seg ] = $value;
                }
                return;
            }
            if ( $seg === null ) {
                $ref[] = [];
                $keys  = array_keys( $ref );
                $ref   = &$ref[ end( $keys ) ];
            } else {
                if ( ! isset( $ref[ $seg ] ) || ! is_array( $ref[ $seg ] ) ) {
                    $ref[ $seg ] = [];
                }
                $ref = &$ref[ $seg ];
            }
        }
    }

    public static function unique_slug( string $base, string $table, string $col = 'slug' ): string {
        global $wpdb;
        $slug = sanitize_title( $base );
        $i    = 1;
        while ( (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}{$table} WHERE {$col} = %s", $slug
        ) ) ) {
            $slug = sanitize_title( $base ) . '-' . $i++;
        }
        return $slug;
    }

    /**
     * Builds a natural, search-intent phrase from a listing's category and
     * city — e.g. "Best Electronics Shop in Laxmi Nagar" — the kind of
     * phrase real searchers actually type, rather than a business's own
     * name, which most searchers never type at all.
     *
     * IMPORTANT — confirmed via research before this was wired into any
     * page: Google's own spam policies explicitly call out "blocks of
     * text that list cities and regions a page is trying to rank for" and
     * "repeating the same words/phrases so often it sounds unnatural" as
     * spam patterns, and separately warn that automation replacing real
     * editorial judgment — at the scale of thousands of near-identical
     * generated pages — can make an entire site section look low-value
     * even if no single page is individually flagged.
     *
     * Given that, this phrase is intentionally used ONLY in short,
     * single-instance, structurally-expected locations — the <title> tag
     * and the H1 — which Google's own SEO starter guide explicitly
     * endorses ("place [the words people search for] in prominent
     * locations... such as the title and main heading of a page"). It is
     * NOT used to generate repeated body paragraphs or keyword-stuffed
     * blocks; any body content built from this needs a genuine,
     * listing-specific fact alongside it (see
     * build_visible_intent_sentence() below) so the page differs in real
     * substance from every other listing in the same category/city, not
     * only in which city name was swapped in.
     *
     * Single source of truth used by title/H1/slug, so all three stay
     * consistent with each other rather than drifting out of sync from
     * separate string-building attempts.
     *
     * Gracefully degrades when data is missing: no city → "Near You"
     * framing instead of a location; no category at all → returns null,
     * letting the caller fall back to the bare business name.
     */
    public static function intent_phrase( string $category, string $city = '', bool $with_best = true ): ?string {
        $category = trim( $category );
        if ( $category === '' ) { return null; }
        $superlative = $with_best ? 'Best ' : '';
        return $city !== ''
            ? "{$superlative}{$category} in {$city}"
            : "{$superlative}{$category} Near You";
    }

    /**
     * Builds ONE genuine, differentiated sentence for visible body
     * content, combining the intent phrase with a real, listing-specific
     * fact (rating+review count, years established, or a certification —
     * whichever is actually present on this listing). This is the
     * deliberate safeguard against the exact spam pattern confirmed in
     * research: the same category+city phrase alone, repeated across
     * every listing in that category/city with nothing else changed,
     * would be exactly the "low-value pattern at scale" Google's
     * guidance warns about. Pairing it with a real fact means two
     * listings in the same category and city still read as genuinely
     * different sentences, because they ARE genuinely different
     * businesses with different real facts.
     *
     * Returns null (caller should omit the sentence entirely) when NO
     * real differentiating fact is available — a phrase with nothing
     * genuine attached is worse than no phrase at all.
     */
    public static function build_visible_intent_sentence(
        string $category, string $city, string $brand,
        float $rating = 0, int $review_count = 0,
        int $established_year = 0
    ): ?string {
        $phrase = self::intent_phrase( $category, $city, false ); // no "Best" claim in body copy — that's a title/H1-only convention, asserting it as a body fact reads as an unsupported claim
        if ( ! $phrase ) { return null; }

        if ( $rating > 0 && $review_count > 0 ) {
            return "{$brand} is a {$phrase}, rated {$rating} out of 5 from {$review_count} " . ( $review_count === 1 ? 'review' : 'reviews' ) . '.';
        }
        $years = $established_year > 0 ? ( (int) gmdate( 'Y' ) - $established_year ) : 0;
        if ( $years > 0 ) {
            return "{$brand} has been serving as a {$phrase} for {$years} " . ( $years === 1 ? 'year' : 'years' ) . '.';
        }
        return null; // no real fact available — omit rather than assert an unsupported claim
    }

    public static function update_search_index( int $listing_id ): void {
        global $wpdb;
        $l = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_listings WHERE id = %d", $listing_id
        ) );
        if ( ! $l ) { return; }
        $content = implode( ' ', array_filter( [
            $l->title, $l->tagline, $l->short_desc, $l->tags, $l->city, $l->state,
        ] ) );
        $wpdb->replace( $wpdb->prefix . 'gs_search_index', [
            'listing_id'  => $listing_id,
            'content'     => $content,
            'city'        => $l->city,
            'category_id' => (int) $l->category_id,
            'status'      => $l->status,
            'updated_at'  => current_time( 'mysql' ),
        ] );
    }

    public static function generate_invoice_number(): string {
        global $wpdb;
        $prefix = Config::get( 'invoice_prefix', 'INV' );
        $year   = date( 'Y' );
        $month  = date( 'm' );
        $count  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}gs_invoices WHERE YEAR(created_at) = {$year}" );
        return $prefix . '-' . $year . $month . '-' . str_pad( $count + 1, 4, '0', STR_PAD_LEFT );
    }

    public static function excerpt( string $text, int $words = 20 ): string {
        $parts = explode( ' ', wp_strip_all_tags( $text ) );
        return count( $parts ) <= $words
            ? $text
            : implode( ' ', array_slice( $parts, 0, $words ) ) . '…';
    }

    /**
     * Checks a listing's phone number against every OTHER active listing
     * on the platform and flags it for admin review if a real duplicate
     * is found. Confirmed real gap: no uniqueness check existed anywhere
     * for phone numbers, despite this directly matching the
     * duplicate/inconsistent-detail problem that research confirmed
     * actively hurts how Google trusts a listing.
     *
     * Deliberately excludes the SAME VENDOR'S other listings — a vendor
     * legitimately running two different services from one shop, sharing
     * one phone number, is real and common, not a duplicate to flag.
     * Only flags when a DIFFERENT vendor has the exact same phone number,
     * which is a genuine, real signal something is wrong (one business
     * listed twice under different names, or a vendor copying a
     * competitor's real contact details).
     *
     * Sets the existing, already-built moderation_flag/moderation_reason
     * columns and notifies admins via the existing notify_admins()
     * mechanism, rather than blocking the save outright — this is
     * detection for human review, not an automatic rejection, since a
     * flagged match might still turn out to be legitimate (e.g. a
     * shared landline at a small shared office).
     */
    public static function check_phone_duplicate( int $listing_id, string $phone, string $title ): void {
        $phone = trim( $phone );
        if ( $phone === '' ) { return; } // nothing to check

        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $own_vendor_id = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT vendor_id FROM {$pfx}listings WHERE id = %d", $listing_id
        ) );

        $match = $wpdb->get_row( $wpdb->prepare(
            "SELECT l.id, l.title, vp.business_name
             FROM {$pfx}listings l
             LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
             WHERE l.phone = %s AND l.id != %d AND l.vendor_id != %d AND l.status IN ('active','pending')
             LIMIT 1",
            $phone, $listing_id, $own_vendor_id
        ) );

        if ( ! $match ) { return; } // no duplicate found — nothing to do

        $reason = "Phone number {$phone} also used by listing #{$match->id} (\"{$match->title}\" — {$match->business_name})";
        $wpdb->update(
            "{$pfx}listings",
            [ 'moderation_flag' => 1, 'moderation_reason' => $reason, 'moderation_flagged_at' => current_time( 'mysql' ) ],
            [ 'id' => $listing_id ]
        );

        self::notify_admins(
            'listing.duplicate_phone',
            '🚩 Possible duplicate listing',
            "\"{$title}\" was flagged: " . $reason,
            home_url( '/admin-panel/?section=flagged_listings' )
        );
    }

    /**
     * Real fix — this used to only create in-app notifications, never
     * email, despite being the version used at every existing admin-alert
     * call site in this codebase. Confirmed during a full audit of admin
     * notification coverage: NotificationService::notify_admins() is the
     * only implementation that actually sends email. Delegating here
     * means every existing caller (listing pending, and others) starts
     * sending email with zero changes needed to them, and eliminates
     * having two inconsistent admin-notify implementations.
     *
     * FIXED (bug report follow-up — "Vendor Listing form Save button, 4-5
     * second delay"): NotificationService::notify_admins() calls wp_mail()
     * synchronously (NotificationService.php ~line 526), and this wrapper
     * used to call it inline. Every call site is on the vendor-facing save
     * path: AjaxController::saveListing() calls this unconditionally for
     * every brand-new listing AND for every edit of an already-active
     * listing by its vendor (AjaxController.php, the `listing.pending` /
     * `listing.edited` calls right after the save commits) — i.e. most
     * real "click Save" traffic. A real SMTP handshake commonly costs
     * exactly this much time per call, and the request can't respond
     * ($this->ok()) until wp_mail() returns. Routed through the same
     * JobQueue::push() pattern already used a few lines earlier in
     * saveListing() for 'update_search_index', so the admin alert still
     * goes out (next gs_process_jobs cron tick) without the vendor's
     * save request waiting on an SMTP round-trip.
     * NOTE: NotificationService::notify_admins() itself is left
     * synchronous — AjaxController::diagnoseAdminEmail() (the "Send Real
     * Test Email" diagnostic tool) calls it directly (not through this
     * wrapper) specifically because it needs to inspect
     * gs_recent_mail_failures in the SAME request to report a real
     * pass/fail result; queuing that one would make it always report
     * "sent" immediately regardless of actual delivery.
     */
    public static function notify_admins( string $type, string $title, string $message, string $url = '' ): void {
        \GoodService\Core\JobQueue::push( 'notify_admins', [
            'type'    => $type,
            'title'   => $title,
            'message' => $message,
            'url'     => $url,
        ] );
    }

    /**
     * ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "No SLA/escalation
     * tracking on complaints or disputes"). Single source of truth for the
     * priority -> response-window mapping, shared by AjaxController
     * (submitComplaint/updateComplaint, to set/recompute sla_due_at) and
     * Cron::escalate_overdue_complaints() (to compute the new due date
     * after an auto-escalation) — kept in one place so the two can never
     * silently drift onto different SLA numbers.
     */
    public static function complaint_sla_hours( string $priority ): int {
        $map = [ 'critical' => 4, 'high' => 24, 'medium' => 72, 'low' => 168 ];
        return $map[ $priority ] ?? $map['medium'];
    }

    /**
     * ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: SLA due-date display).
     * time_ago() above clamps negative diffs to 0 via max(0, ...) — it was
     * built only for past timestamps (created_at, updated_at, etc.), so
     * feeding it a still-in-the-future sla_due_at would misleadingly render
     * "just now" for something due in 3 days. This is the future-facing
     * counterpart used specifically for complaint due-date badges: returns
     * "Xh"/"Xd" for a future date, or delegates to time_ago() unchanged for
     * a past (i.e. already-overdue) one so existing overdue-styling logic
     * keeps working exactly as before.
     */
    public static function due_in_or_overdue( ?string $datetime ): string {
        if ( ! $datetime ) { return '—'; }
        $diff = abs( (int) strtotime( $datetime ) - time() );
        return match ( true ) {
            $diff < 60     => 'less than a minute',
            $diff < 3600   => (int) ( $diff / 60 ) . 'm',
            $diff < 86400  => (int) ( $diff / 3600 ) . 'h',
            default        => (int) ( $diff / 86400 ) . 'd',
        };
    }

    /** Next tier up from the given complaint priority; 'critical' has none. */
    public static function complaint_escalated_priority( string $priority ): string {
        $order = [ 'low', 'medium', 'high', 'critical' ];
        $i = array_search( $priority, $order, true );
        if ( $i === false ) { $i = 1; } // unknown priority treated as 'medium'
        return $order[ min( $i + 1, count( $order ) - 1 ) ];
    }

    // ENTERPRISE-AUDIT FIX (Part 1, Enterprise-level, Medium: "No vendor
    // performance / risk scoring beyond Trust Score... nothing rolls up
    // complaint count, review rating trend, lead-response time, or
    // cancellation rate into a composite risk indicator admins could use to
    // proactively flag declining vendors before a complaint escalates").
    //
    // Deliberately separate from trust_score (which measures identity/
    // business VERIFICATION — static checkboxes an admin ticks once) — this
    // measures ongoing OPERATIONAL behavior over the trailing 90 days, so a
    // fully-verified vendor can still show as high-risk if service quality
    // is currently declining, and vice versa.
    //
    // Each of the 4 signals is included only when there is enough recent
    // data for it to mean anything (a vendor with 1 lead this quarter isn't
    // meaningfully "50% missed"); components with too little data are simply
    // left out of the weighted average rather than assumed to be 0 (good) —
    // that would hide risk for exactly the low-activity vendors most likely
    // to be quietly failing. Complaint count is the one signal always
    // included, since zero complaints is itself real, always-meaningful data.
    //
    // Returns null only when there is no signal at all (complaints, by
    // definition, always contributes — so null in practice never happens
    // for a real vendor row, but the contract is kept honest rather than
    // hardcoding "always returns an array").
    public static function vendor_risk_score( int $vendor_id ): ?array {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $complaints_90d = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$pfx}complaints WHERE vendor_id=%d AND status != 'dismissed' AND created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)",
            $vendor_id
        ) );

        $recent = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS c, AVG(rating) AS avg_r FROM {$pfx}reviews WHERE vendor_id=%d AND status='approved' AND created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)",
            $vendor_id
        ) );
        $prior = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS c, AVG(rating) AS avg_r FROM {$pfx}reviews WHERE vendor_id=%d AND status='approved' AND created_at >= DATE_SUB(NOW(), INTERVAL 180 DAY) AND created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)",
            $vendor_id
        ) );

        $leads = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS total, SUM(CASE WHEN missed_alert_sent=1 THEN 1 ELSE 0 END) AS missed FROM {$pfx}leads WHERE vendor_id=%d AND created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)",
            $vendor_id
        ) );

        $bookings = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS total, SUM(CASE WHEN status IN ('cancelled','no_show') THEN 1 ELSE 0 END) AS cancelled FROM {$pfx}bookings WHERE vendor_id=%d AND created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)",
            $vendor_id
        ) );

        $components = []; // key => [score(0-100, higher=riskier), weight, label]

        // 0 complaints -> 0, 7+ complaints in 90 days -> 100 (maxed out).
        $components['complaints'] = [ min( 100, $complaints_90d * 100 / 7 ), 0.35, "{$complaints_90d} complaint(s) in 90 days" ];

        if ( (int) $recent->c >= 3 && (int) $prior->c >= 3 ) {
            $drop = (float) $prior->avg_r - (float) $recent->avg_r; // positive = getting worse
            $components['rating_trend'] = [
                max( 0, min( 100, $drop * 50 ) ), 0.15,
                sprintf( '%.1f★ (prior 90d) → %.1f★ (last 90d)', (float) $prior->avg_r, (float) $recent->avg_r ),
            ];
        }

        if ( (int) $leads->total >= 3 ) {
            $missed_pct = (int) $leads->missed * 100 / (int) $leads->total;
            $components['response'] = [ min( 100, $missed_pct ), 0.25, sprintf( '%d of %d inquiries missed 2h response window', (int) $leads->missed, (int) $leads->total ) ];
        }

        if ( (int) $bookings->total >= 3 ) {
            $cancel_pct = (int) $bookings->cancelled * 100 / (int) $bookings->total;
            $components['cancellation'] = [ min( 100, $cancel_pct ), 0.25, sprintf( '%d of %d bookings cancelled/no-show', (int) $bookings->cancelled, (int) $bookings->total ) ];
        }

        if ( ! $components ) { return null; }

        $weight_sum = array_sum( array_column( $components, 1 ) );
        $score_sum  = array_sum( array_map( fn( $c ) => $c[0] * $c[1], $components ) );
        $score = round( $score_sum / $weight_sum, 1 );

        return [
            'score'      => $score,
            'level'      => $score >= 60 ? 'high' : ( $score >= 30 ? 'medium' : 'low' ),
            'confidence' => count( $components ) . '/4 signals',
            'components' => array_map( fn( $c ) => [ 'score' => round( $c[0], 1 ), 'weight' => $c[1], 'detail' => $c[2] ], $components ),
        ];
    }
}
