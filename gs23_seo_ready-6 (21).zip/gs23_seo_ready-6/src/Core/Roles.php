<?php
namespace GoodService\Core;

final class Roles {

    public static function register(): void {
        if ( ! get_role( 'gs_regional_manager' ) ) {
            add_role( 'gs_regional_manager', 'GS Regional Account Manager', [
                'read'                    => true,
                'gs_manage_own_listings'  => true, // deliberately narrow — only covers listings assigned to THIS specific manager, enforced at the data layer, not just this capability flag
            ] );
        }
        if ( ! get_role( 'gs_vendor' ) ) {
            add_role( 'gs_vendor', 'GS Vendor', [ 'read' => true ] );
        }
        if ( ! get_role( 'gs_manager' ) ) {
            add_role( 'gs_manager', 'GS Manager', [
                'read'                  => true,
                'gs_approve_listings'   => true,
                'gs_manage_reviews'     => true,
                'gs_manage_complaints'  => true,
                'gs_verify_vendors'     => true,
                'gs_view_leads'         => true,
                'gs_manage_vendors'     => true,
            ] );
        }
        if ( ! get_role( 'gs_moderator' ) ) {
            add_role( 'gs_moderator', 'GS Moderator', [
                'read'                  => true,
                'gs_approve_listings'   => true,
                'gs_manage_reviews'     => true,
                'gs_manage_complaints'  => true,
                'gs_verify_vendors'     => true,
                'gs_view_leads'         => true,
            ] );
        } else {
            // Ensure existing gs_moderator roles get the capabilities (migration fix)
            $mod_role = get_role( 'gs_moderator' );
            foreach ( [ 'gs_approve_listings', 'gs_manage_reviews', 'gs_manage_complaints', 'gs_verify_vendors', 'gs_view_leads' ] as $cap ) {
                if ( ! isset( $mod_role->capabilities[ $cap ] ) ) {
                    $mod_role->add_cap( $cap );
                }
            }
        }
        if ( ! get_role( 'gs_staff' ) ) {
            add_role( 'gs_staff', 'GS Staff', [
                'read'                  => true,
                'gs_approve_listings'   => true,
                'gs_manage_reviews'     => true,
                'gs_manage_complaints'  => true,
            ] );
        }
        if ( ! get_role( 'gs_customer' ) ) {
            add_role( 'gs_customer', 'GS Customer', [
                'read' => true,
            ] );
        }
    }

    public static function is_vendor( int $uid = 0 ): bool {
        $u = $uid ? get_user_by( 'id', $uid ) : wp_get_current_user();
        if ( ! $u?->ID ) { return false; }
        // MAJOR FIX #7: is_vendor() now ONLY returns true for users with the
        // gs_vendor role. Previously it returned true for administrators, managers,
        // moderators, and staff, causing those roles to hit the vendor dashboard
        // (which requires a vendor profile) and generate PHP errors.
        //
        // Use can_create_listings() when you need "vendor OR admin can do this".
        return in_array( 'gs_vendor', (array) $u->roles, true );
    }

    /**
     * Returns true if the user can create and manage listings.
     * This is the correct check to use when the operation is valid for BOTH
     * vendors (gs_vendor role) AND admin-level users (administrator, gs_manager, etc.).
     */
    public static function can_create_listings( int $uid = 0 ): bool {
        return self::is_vendor( $uid ) || self::is_admin_level( $uid ) || self::is_regional_manager( $uid );
    }

    public static function is_admin_level( int $uid = 0 ): bool {
        $u = $uid ? get_user_by( 'id', $uid ) : wp_get_current_user();
        if ( ! $u?->ID ) { return false; }
        // H7 FIX: is_admin_level() now only covers true admin-tier roles.
        // gs_moderator and gs_staff are NOT admin-level — they are operations staff
        // who should have access to content moderation but NOT to:
        //   saveSettings(), managePlans(), exportData(), manageUsers(), etc.
        // Use is_operations_level() for moderator/staff permission checks.
        // Use is_moderator() for moderation-specific access (approve listings, reviews).
        if ( ! empty( array_intersect( (array) $u->roles, [ 'administrator', 'gs_manager' ] ) ) ) {
            return true;
        }
        return user_can( $u, 'manage_options' );
    }

    public static function is_regional_manager( int $uid = 0 ): bool {
        $u = $uid ? get_user_by( 'id', $uid ) : wp_get_current_user();
        if ( ! $u?->ID ) { return false; }
        return in_array( 'gs_regional_manager', (array) $u->roles, true );
    }

    /**
     * The actual RBAC enforcement point: is THIS SPECIFIC listing assigned
     * to THIS SPECIFIC regional manager right now? Admins always pass.
     * Every listing edit/view path a regional manager can reach must call
     * this — the WordPress capability alone only says "this role can manage
     * listings in general," not "this listing, right now."
     */
    public static function can_edit_listing( int $listing_id, int $uid = 0 ): bool {
        if ( self::is_admin_level( $uid ) ) { return true; }
        if ( ! self::is_regional_manager( $uid ) ) { return false; }
        global $wpdb;
        $uid = $uid ?: get_current_user_id();
        $pfx = $wpdb->prefix . 'gs_';
        $assigned = $wpdb->get_var( $wpdb->prepare(
            "SELECT 1 FROM {$pfx}listing_manager_assignments WHERE listing_id=%d AND manager_id=%d LIMIT 1",
            $listing_id, $uid
        ) );
        return (bool) $assigned;
    }

    /** Cities this regional manager is allowed to create new listings in. */
    public static function manager_cities( int $uid = 0 ): array {
        global $wpdb;
        $uid = $uid ?: get_current_user_id();
        $pfx = $wpdb->prefix . 'gs_';
        $rows = $wpdb->get_col( $wpdb->prepare(
            "SELECT city FROM {$pfx}manager_cities WHERE manager_id=%d", $uid
        ) );
        return $rows ?: [];
    }

    /**
     * Returns true for admin + operations staff (manager, moderator, staff).
     * Use this when the operation is valid for all platform staff but NOT vendors.
     * Typical use: read-only admin views, moderation queues, vendor management.
     */
    public static function is_operations_level( int $uid = 0 ): bool {
        $u = $uid ? get_user_by( 'id', $uid ) : wp_get_current_user();
        if ( ! $u?->ID ) { return false; }
        if ( ! empty( array_intersect( (array) $u->roles, [ 'administrator', 'gs_manager', 'gs_moderator', 'gs_staff' ] ) ) ) {
            return true;
        }
        return user_can( $u, 'manage_options' );
    }

    public static function is_manager( int $uid = 0 ): bool {
        $u = $uid ? get_user_by( 'id', $uid ) : wp_get_current_user();
        if ( ! $u?->ID ) { return false; }
        return ! empty( array_intersect( (array) $u->roles, [ 'administrator', 'gs_manager' ] ) );
    }

    public static function is_moderator( int $uid = 0 ): bool {
        $u = $uid ? get_user_by( 'id', $uid ) : wp_get_current_user();
        if ( ! $u?->ID ) { return false; }
        return ! empty( array_intersect( (array) $u->roles, [ 'administrator', 'gs_manager', 'gs_moderator', 'gs_staff' ] ) );
    }

    public static function is_staff( int $uid = 0 ): bool {
        $u = $uid ? get_user_by( 'id', $uid ) : wp_get_current_user();
        if ( ! $u?->ID ) { return false; }
        return ! empty( array_intersect( (array) $u->roles, [ 'gs_staff', 'gs_moderator' ] ) );
    }

    /**
     * ENTERPRISE-AUDIT FIX (Critical finding, root-caused): register() above
     * defines real, distinct per-role capabilities (gs_verify_vendors,
     * gs_manage_vendors, gs_view_leads, etc.) — gs_staff was deliberately
     * given a NARROWER set than gs_manager/gs_moderator (no vendor-verify or
     * vendor-manage). But every enforcement point in the codebase checked
     * only the coarse role tier (is_operations_level(), is_manager(), etc.),
     * never these specific capabilities — so the narrower gs_staff role
     * granted identical access to gs_manager/gs_moderator in practice, on
     * every vendor-suspend/verify action. This is the actual capability
     * check that was missing: administrators and gs_manager (already
     * covered by is_admin_level()) always pass; everyone else must actually
     * hold the named WordPress capability on their role, exactly as
     * register() defines it above.
     */
    public static function can( string $capability, int $uid = 0 ): bool {
        if ( self::is_admin_level( $uid ) ) { return true; }
        $u = $uid ? get_user_by( 'id', $uid ) : wp_get_current_user();
        if ( ! $u?->ID ) { return false; }
        return user_can( $u, $capability );
    }

    /**
     * ENTERPRISE-AUDIT FIX (Part 1, Critical: "No staff/regional-manager
     * permission granularity"). Root cause: gs_manager/gs_moderator/gs_staff
     * are WP roles, but every operations-level AJAX handler only checked the
     * coarse role tier (require_operations()/is_operations_level()) — there
     * was no way to restrict ONE specific staff account to, say, Reviews-only.
     * This is the real per-user enforcement point, backed by the new
     * {$wpdb->prefix}gs_staff_permissions table (see Schema::get_table_definitions()).
     *
     * Deliberately "empty = unrestricted": a staff/moderator user with ZERO
     * rows in that table keeps their full existing access (every currently
     * active internal staff account is unaffected until an admin explicitly
     * restricts them here) — restriction is opt-in per user, never a silent
     * lockout regression across the existing staff base.
     *
     * $section is one of the 3 sections the staff dashboard actually exposes
     * (see other-dashboards.php's GS_MGR_TRUSTED_INCLUDE whitelist): 'listings',
     * 'reviews', 'complaints'.
     */
    public static function can_access_section( string $section, int $uid = 0 ): bool {
        if ( self::is_admin_level( $uid ) ) { return true; } // administrator / gs_manager — always full access
        $uid = $uid ?: get_current_user_id();
        if ( ! $uid ) { return false; }
        if ( ! self::is_moderator( $uid ) ) { return false; } // not operations staff at all — unrelated to this gate
        global $wpdb;
        $pfx     = $wpdb->prefix . 'gs_';
        $has_any = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$pfx}staff_permissions WHERE user_id = %d", $uid
        ) );
        if ( ! $has_any ) { return true; } // no restriction rows for this user — unrestricted (back-compat default)
        $granted = $wpdb->get_var( $wpdb->prepare(
            "SELECT 1 FROM {$pfx}staff_permissions WHERE user_id = %d AND section = %s LIMIT 1",
            $uid, $section
        ) );
        return (bool) $granted;
    }

    /** Valid admin tiers. 'full_admin' is the implicit default for every
     * admin-level user with no row in {$prefix}gs_admin_tiers — see
     * admin_tier()'s docblock. */
    public const ADMIN_TIERS = [ 'full_admin', 'billing_admin', 'support_agent', 'read_only_auditor' ];

    /**
     * ENTERPRISE-AUDIT FIX (Part 2, Critical: "No admin RBAC / granular
     * roles"). Root cause: is_admin_level() was a single binary gate — any
     * administrator or gs_manager account could grant free subscriptions,
     * refund payments, and read/edit every settings group (AI keys, SMTP
     * credentials, payment gateway secrets) with no secondary tier at all.
     *
     * Returns this user's admin tier. 'full_admin' (today's exact existing
     * behavior, unrestricted) unless an admin has explicitly assigned them a
     * narrower tier via gs_admin_set_tier — the same "empty row = fully
     * unrestricted" back-compat convention already used by
     * can_access_section() above, so every currently active admin/manager
     * account is completely unaffected until someone deliberately restricts
     * a specific account.
     */
    public static function admin_tier( int $uid = 0 ): string {
        $uid = $uid ?: get_current_user_id();
        if ( ! $uid || ! self::is_admin_level( $uid ) ) { return 'full_admin'; } // meaningless for non-admin-level users; never used to grant access
        global $wpdb;
        $pfx  = $wpdb->prefix . 'gs_';
        $tier = $wpdb->get_var( $wpdb->prepare( "SELECT tier FROM {$pfx}admin_tiers WHERE user_id = %d", $uid ) );
        return ( $tier && in_array( $tier, self::ADMIN_TIERS, true ) ) ? $tier : 'full_admin';
    }

    public static function is_full_admin( int $uid = 0 ): bool {
        return self::is_admin_level( $uid ) && self::admin_tier( $uid ) === 'full_admin';
    }

    /**
     * Per-settings-group save permission. full_admin always passes. An
     * UNKNOWN group (SettingsGroups::group_of() returned null — e.g. a
     * dynamically-added field not yet catalogued) is deliberately treated
     * as permitted for every tier except read_only_auditor: the safe
     * failure mode for an uncategorized key is "don't silently break an
     * existing save that used to work", not "block anything we don't
     * recognize" — the four explicitly-named risk groups (AI, SMTP, both
     * payment gateways, and everything else) are all fully catalogued in
     * SettingsGroups::GROUPS, so this fallback only ever applies to genuine
     * edge cases, never to the groups this finding was actually about.
     */
    public static function can_save_settings_group( ?string $group, int $uid = 0 ): bool {
        $tier = self::admin_tier( $uid );
        if ( $tier === 'full_admin' ) { return true; }
        if ( $tier === 'read_only_auditor' ) { return false; } // read-only, full stop — no settings group is writable
        if ( $tier === 'billing_admin' ) {
            return $group === null || in_array( $group, \GoodService\Core\SettingsGroups::BILLING_ADMIN_GROUPS, true );
        }
        // support_agent: settings page is out of scope entirely.
        return false;
    }

    /**
     * Gate for the other three explicitly-named Critical-finding risk
     * actions: granting/assigning a free or comped subscription plan, and
     * refunding a payment/dispute. full_admin and billing_admin both pass
     * (billing management is exactly what a billing_admin exists to do);
     * support_agent and read_only_auditor are blocked — these are real
     * financial-impact actions, not something a support/read-only account
     * should ever be able to trigger.
     */
    public static function can_manage_billing_actions( int $uid = 0 ): bool {
        $tier = self::admin_tier( $uid );
        return $tier === 'full_admin' || $tier === 'billing_admin';
    }
}
