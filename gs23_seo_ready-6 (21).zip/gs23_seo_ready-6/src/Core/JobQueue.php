<?php
namespace GoodService\Core;

/**
 * JobQueue — Async background job processor.
 *
 * Jobs are written to gs_job_queue table and processed by WP-Cron.
 * Keeps heavy work (email, reports, bulk operations) off the request cycle.
 *
 * Usage:
 *   JobQueue::push( 'send_email', [ 'user_id' => 5, 'template' => 'welcome' ] );
 *   JobQueue::push( 'recalculate_analytics', [ 'vendor_id' => 12 ], 60 ); // delay 60s
 */
final class JobQueue {

    /** Register WP-Cron event and action. */
    public static function register(): void {
        add_action( 'gs_process_jobs', [ self::class, 'process_batch' ] );
        if ( ! wp_next_scheduled( 'gs_process_jobs' ) ) {
            wp_schedule_event( time(), 'gs_five_minutes', 'gs_process_jobs' );
        }
    }

    /** Push a job onto the queue. */
    public static function push( string $job_type, array $payload = [], int $delay_seconds = 0 ): int|false {
        global $wpdb;
        $result = $wpdb->insert( $wpdb->prefix . 'gs_job_queue', [
            'job_type'      => $job_type,
            'payload'       => wp_json_encode( $payload ),
            'status'        => 'pending',
            'run_after'     => date( 'Y-m-d H:i:s', time() + $delay_seconds ),
            'created_at'    => current_time( 'mysql' ),
        ] );
        if ( $result ) {
            EventBus::emit( 'job.queued', [ 'job_type' => $job_type ] );
            return $wpdb->insert_id;
        }
        return false;
    }

    // TRACE: triggered by gs_process_jobs WP-Cron action (every 5 min) → acquires transient lock,
    //        fetches pending jobs ordered by created_at ASC, atomically claims each via
    //        UPDATE WHERE status='pending', dispatches to handle(), marks done or retries on failure,
    //        releases lock in finally block → mutates gs_job_queue rows: status pending→running→done/failed/pending
    // PRECONDITIONS: gs_job_queue table exists; WP-Cron active; $wpdb available globally
    // POSTCONDITIONS: Each processed job has status='done' and completed_at=timestamp in DB.
    //                 Failed jobs have status='failed' (after 3 attempts) or status='pending' with
    //                 run_after deferred by attempts*300s. Lock transient deleted regardless of outcome.
    // EDGE CASES: concurrent cron fires: second worker finds lock, returns immediately (no double-exec);
    //             job throws exception: caught, retried up to 3 times with backoff, logged to error_log;
    //             process dies mid-job: lock TTL=330s auto-expires, next cron run re-claims orphaned running jobs
    // BUSINESS RULE: each job type executes exactly once (idempotency enforced at DB level via atomic UPDATE)
    // ROLES ALLOWED: system-only (WP-Cron internal, no user role required)
    public static function process_batch( int $limit = 20 ): void {
        global $wpdb;
        $table = $wpdb->prefix . 'gs_job_queue';

        // ── Concurrency guard: use a transient-based lock so two simultaneous
        //    WP-Cron fires (possible under high traffic) don't double-process jobs.
        //    Lock TTL = 5 minutes (the cron interval) + 30s buffer.
        $lock_key = 'gs_jq_lock';
        if ( get_transient( $lock_key ) ) {
            return; // Another instance is already processing — skip
        }
        set_transient( $lock_key, 1, 330 ); // 5m 30s — auto-releases if process dies

        try {
            $jobs = $wpdb->get_results( $wpdb->prepare(
                "SELECT * FROM {$table}
                 WHERE status = 'pending' AND run_after <= NOW()
                 ORDER BY created_at ASC LIMIT %d",
                $limit
            ) );
            foreach ( $jobs as $job ) {
                // Atomic claim: only proceed if we win the status race.
                // UPDATE returns 1 if status was still 'pending', 0 if another
                // process already claimed it. This prevents double-execution.
                $claimed = $wpdb->query( $wpdb->prepare(
                    "UPDATE {$table}
                     SET status = 'running', started_at = %s
                     WHERE id = %d AND status = 'pending'",
                    current_time( 'mysql' ), $job->id
                ) );
                if ( ! $claimed ) {
                    continue; // Already claimed by another worker — skip
                }
                try {
                    $payload = json_decode( $job->payload, true ) ?? [];
                    self::handle( $job->job_type, $payload );
                    $wpdb->update( $table, [ 'status' => 'done', 'completed_at' => current_time( 'mysql' ) ], [ 'id' => $job->id ] );
                } catch ( \Throwable $e ) {
                    $attempts = (int) $job->attempts + 1;
                    $status   = $attempts >= 3 ? 'failed' : 'pending';
                    $wpdb->update( $table, [
                        'status'      => $status,
                        'attempts'    => $attempts,
                        'error'       => substr( $e->getMessage(), 0, 500 ),
                        'run_after'   => date( 'Y-m-d H:i:s', time() + ( $attempts * 300 ) ),
                    ], [ 'id' => $job->id ] );
                    error_log( "[GoodService][JobQueue] {$job->job_type} failed: " . $e->getMessage() );
                }
            }
        } finally {
            // Always release lock — even if an exception escapes
            delete_transient( $lock_key );
        }
    }

    /** Route a job to its handler. */
    private static function handle( string $job_type, array $payload ): void {
        match ( $job_type ) {
            'send_email'              => self::handle_send_email( $payload ),
            'send_raw_email'          => self::handle_send_raw_email( $payload ),
            'send_push'               => self::handle_send_push( $payload ),
            'send_notification_sms'   => self::handle_send_notification_sms( $payload ),
            'recalculate_analytics'   => \GoodService\Service\AnalyticsService::recalculate( $payload ),
            'update_search_index'     => Helpers::update_search_index( (int) ( $payload['listing_id'] ?? 0 ) ),
            'generate_invoice'        => \GoodService\Service\BillingService::generate_invoice( (int) ( $payload['subscription_id'] ?? 0 ) ),
            'expire_subscriptions'    => \GoodService\Service\SubscriptionService::expire_batch(),
            'bulk_approve_listings'   => self::handle_bulk_approve( $payload ),
            'send_review_request'     => self::handle_review_request( $payload ),
            // Real fix — Part 4 §6: customer/vendor "export my data" now
            // runs here (off the request cycle) instead of synchronously
            // inside the AJAX handler. See DataExportService::generate_and_notify().
            'data_export'             => \GoodService\Service\DataExportService::generate_and_notify(
                                              (int) ( $payload['export_id'] ?? 0 ),
                                              (int) ( $payload['user_id']   ?? 0 )
                                          ),
            // Real fix — see Core\Helpers::notify_admins(): moves the
            // wp_mail() call inside NotificationService::notify_admins()
            // off the request path for hot save flows (e.g.
            // AjaxController::saveListing()) that used to call it inline.
            'notify_admins'           => \GoodService\Service\NotificationService::notify_admins(
                                              (string) ( $payload['type']    ?? '' ),
                                              (string) ( $payload['title']   ?? '' ),
                                              (string) ( $payload['message'] ?? '' ),
                                              (string) ( $payload['url']     ?? '' )
                                          ),
            default                   => \GoodService\Service\NotificationService::send_email_job( $payload ),
        };
    }

    /**
     * Sends a pre-built email (subject/body/headers already assembled by the
     * caller) with the same retry-with-backoff every other job type gets.
     * Unlike handle_send_email(), this does not go through the email_templates
     * system — it's for emails whose content is dynamically built per-call
     * (e.g. AjaxController::build_inquiry_email(), which formats each
     * inquiry module's custom fields differently) rather than a fixed template.
     * Throws on wp_mail() failure so process_batch()'s catch block schedules
     * a retry — matching the failure-signaling convention every handler here uses.
     */
    private static function handle_send_raw_email( array $payload ): void {
        $to      = sanitize_email( $payload['to'] ?? '' );
        $subject = (string) ( $payload['subject'] ?? '' );
        $body    = (string) ( $payload['body']    ?? '' );
        $headers = (array)  ( $payload['headers'] ?? [] );
        if ( ! $to || ! $subject || ! $body ) { return; } // malformed payload — not retriable
        if ( ! wp_mail( $to, $subject, $body, $headers ) ) {
            throw new \RuntimeException( "wp_mail() returned false sending to {$to}" );
        }
    }

    /**
     * Real fix — confirmed bug found during Phase 1 discovery of the
     * SMS notification work: 'send_push' jobs had no dedicated case in
     * handle()'s match statement, so they silently fell through to
     * send_email_job(), which expects a completely different payload
     * shape ('to'/'template'/'vars' vs this job's
     * 'subscription'/'payload'/vapid keys). Since send_email_job()
     * returns early on a missing 'to' with no error, every push
     * notification queued by NotificationService::send_push_notification()
     * was being silently dropped — no exception, no log entry, nothing.
     *
     * Actually sending a Web Push message requires VAPID JWT signing
     * (ECDSA P-256) and RFC 8291 payload encryption — real cryptography
     * this plugin has no library for (no Composer/vendor directory
     * exists in it at all). Implementing that from scratch under time
     * pressure, with no way to verify it against a live push service,
     * risks shipping subtly-broken or insecure crypto — worse than
     * being explicit about what's needed. This handler is correctly
     * wired and will correctly use the industry-standard
     * minishlink/web-push library the moment it's added via Composer;
     * until then it fails loudly with a specific, actionable log entry
     * instead of the previous silent, undiagnoseable drop.
     */
    private static function handle_send_push( array $payload ): void {
        if ( ! class_exists( '\Minishlink\WebPush\WebPush' ) ) {
            gs_write_log(
                'JobQueue::handle_send_push — the minishlink/web-push library is not installed, so this push notification could not be sent. ' .
                'This plugin has no Composer/vendor directory at all currently; adding one (composer require minishlink/web-push) ' .
                'is required to complete push notification delivery. The notification was NOT silently dropped without a trace — ' .
                'see this log entry — but it was not delivered.',
                'ERROR'
            );
            return;
        }

        // Real implementation once the library is present — VAPID
        // details and the subscription/payload are already correctly
        // assembled by NotificationService::send_push_notification().
        $subscription = json_decode( (string) ( $payload['subscription'] ?? '' ), true );
        if ( ! $subscription || empty( $subscription['endpoint'] ) ) {
            gs_write_log( 'JobQueue::handle_send_push — malformed subscription payload, cannot send.', 'ERROR' );
            return;
        }

        $webpush = new \Minishlink\WebPush\WebPush( [
            'VAPID' => [
                'subject'    => home_url(),
                'publicKey'  => $payload['vapid_public']  ?? '',
                'privateKey' => $payload['vapid_private'] ?? '',
            ],
        ] );
        $webpush->queueNotification(
            \Minishlink\WebPush\Subscription::create( $subscription ),
            (string) ( $payload['payload'] ?? '' )
        );
        foreach ( $webpush->flush() as $report ) {
            if ( ! $report->isSuccess() ) {
                gs_write_log( 'JobQueue::handle_send_push — delivery failed: ' . $report->getReason(), 'WARNING' );
            }
        }
    }

    /**
     * Real feature — thin handler reusing OtpService::send_sms(), the
     * already-working, already-configured (msg91/textlocal) SMS gateway
     * built as the WhatsApp fallback channel. No new gateway
     * integration needed for general notification SMS.
     */
    private static function handle_send_notification_sms( array $payload ): void {
        $phone   = (string) ( $payload['phone']   ?? '' );
        $message = (string) ( $payload['message'] ?? '' );
        if ( ! $phone || ! $message ) { return; } // malformed payload — not retriable
        if ( ! \GoodService\Service\OtpService::send_sms( $phone, $message ) ) {
            gs_write_log( "JobQueue::handle_send_notification_sms — send_sms() returned false for {$phone} (no provider configured, or the gateway call failed).", 'WARNING' );
        }
    }

    private static function handle_bulk_approve( array $payload ): void {
        global $wpdb;
        $ids = array_map( 'intval', $payload['ids'] ?? [] );
        if ( ! $ids ) { return; }
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->prefix}gs_listings SET status = 'active' WHERE id IN ({$placeholders})",
            ...$ids
        ) );
        // Fetch full listing+vendor details for the batch — the previous emit
        // payload carried only listing_id, so on_listing_approved() exited
        // immediately on its vendor_user_id guard for every bulk-approved
        // listing. Vendors received zero notification (in-app, email, or push)
        // for any listing approved via this path.
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT l.id AS listing_id, l.title, l.slug, l.email AS listing_email, vp.user_id AS vendor_user_id, vp.email AS vendor_profile_email
             FROM {$wpdb->prefix}gs_listings l
             LEFT JOIN {$wpdb->prefix}gs_vendor_profiles vp ON vp.id = l.vendor_id
             WHERE l.id IN ({$placeholders})", ...$ids
        ) ) ?: [];
        foreach ( $rows as $row ) {
            // Real fix — per explicit request, prioritizes the listing's
            // own contact email over vendor_profiles.email, matching the
            // correct order fixed elsewhere in the other two listing-
            // approve paths this session — this query didn't even select
            // l.email at all before.
            $vendor_email = ! empty( $row->listing_email )
                ? $row->listing_email
                : ( ! empty( $row->vendor_profile_email )
                    ? $row->vendor_profile_email
                    : ( $row->vendor_user_id ? $wpdb->get_var( $wpdb->prepare( "SELECT user_email FROM {$wpdb->prefix}users WHERE ID=%d", $row->vendor_user_id ) ) : '' ) );
            EventBus::emit( 'listing.approved', [
                'listing_id'     => (int) $row->listing_id,
                'vendor_user_id' => (int) $row->vendor_user_id,
                'vendor_email'   => $vendor_email ?: '',
                'title'          => $row->title,
                'slug'           => $row->slug,
            ] );
        }
    }

    /** Purge completed/failed jobs older than N days. */
    public static function purge( int $days = 7 ): int {
        global $wpdb;
        return (int) $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}gs_job_queue
             WHERE status IN ('done','failed') AND created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ) );
    }

    /** Route email jobs: try EmailService first, fall back to NotificationService */
    private static function handle_send_email( array $payload ): void {
        // If it has a _cleanup_file key, delete it
        if ( ! empty( $payload['_cleanup_file'] ) && file_exists( $payload['_cleanup_file'] ) ) {
            @unlink( $payload['_cleanup_file'] );
            return;
        }
        $to       = sanitize_email( $payload['to'] ?? '' );
        $template = sanitize_key( $payload['template'] ?? '' );
        $vars     = (array) ( $payload['vars'] ?? [] );

        if ( ! $to || ! $template ) { return; }

        // Use EmailService if template exists there, otherwise NotificationService
        $sent = \GoodService\Service\EmailService::send( $to, $template, $vars );
        if ( ! $sent ) {
            // Fallback to legacy NotificationService email job
            \GoodService\Service\NotificationService::send_email_job( $payload );
        }
    }

    private static function handle_review_request( array $payload ): void {
        $to      = sanitize_email( $payload['to'] ?? '' );
        $vars    = (array) ( $payload['vars'] ?? [] );
        if ( $to ) {
            \GoodService\Service\EmailService::send( $to, 'review_request', $vars );
        }
    }

}
