<?php
namespace GoodService\Core;

/**
 * RateLimiter — Transient-based per-user/per-IP rate limiting.
 * Applied to AI generation, inquiry submission, and quote sending.
 */
final class RateLimiter {

    /**
     * Check and increment a rate limit counter.
     * Returns true if the action is allowed, false if limit exceeded.
     *
     * @param string $action   Identifier for the action being limited.
     * @param int    $limit    Max calls allowed in the window.
     * @param int    $window   Time window in seconds.
     * @param string $identity Per-user key (user ID for logged-in, hashed IP for guests).
     */
    public static function allow( string $action, int $limit, int $window, string $identity ): bool {
        $key   = 'gsrl_' . substr( md5( $action . '_' . $identity ), 0, 32 );
        $count = (int) get_transient( $key );

        if ( $count >= $limit ) {
            return false;
        }

        if ( $count === 0 ) {
            set_transient( $key, 1, $window );
        } else {
            set_transient( $key, $count + 1, $window );
        }

        return true;
    }

    /**
     * Get a stable identity string for rate limiting.
     * Uses user ID for logged-in users, hashed IP for guests.
     *
     * H9 FIX: HTTP_X_FORWARDED_FOR is user-supplied and forgeable. An attacker can
     * send a different X-Forwarded-For header on every request to appear as a new IP
     * and bypass all rate limits. We now only trust XFF when REMOTE_ADDR is a private
     * or loopback address (i.e. a real internal reverse proxy). When REMOTE_ADDR is a
     * public IP it IS the client — XFF cannot be trusted.
     *
     * Observable output: guest rate limits can no longer be bypassed by header spoofing.
     */
    public static function get_identity(): string {
        if ( is_user_logged_in() ) {
            return 'u_' . get_current_user_id();
        }
        $remote = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $ip     = self::resolve_real_ip( $remote );
        return 'ip_' . substr( md5( $ip . ( defined( 'AUTH_SALT' ) ? AUTH_SALT : 'gs' ) ), 0, 16 );
    }

    /**
     * Resolve the real client IP.
     * Only trusts X-Forwarded-For when the direct TCP connection comes from a
     * private/loopback address (a real internal load balancer or reverse proxy).
     * When REMOTE_ADDR is a public IP, it IS the client — XFF is untrusted.
     */
    public static function resolve_real_ip( string $remote_addr ): string {
        if ( self::is_private_ip( $remote_addr ) && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
            $xff    = sanitize_text_field( $_SERVER['HTTP_X_FORWARDED_FOR'] );
            $client = trim( explode( ',', $xff )[0] );
            if ( filter_var( $client, FILTER_VALIDATE_IP ) ) {
                return $client;
            }
        }
        return $remote_addr;
    }

    /**
     * Returns true when $ip is a loopback or RFC-1918 private address
     * (i.e. could only come from an internal reverse proxy, never a real client).
     */
    private static function is_private_ip( string $ip ): bool {
        if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
            return false;
        }
        // FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE returns false for
        // private/reserved addresses — so a false result here means the IP IS private.
        return filter_var( $ip, FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        ) === false;
    }
}
