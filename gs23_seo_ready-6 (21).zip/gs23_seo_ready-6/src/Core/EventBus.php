<?php
namespace GoodService\Core;

/**
 * EventBus — Internal event dispatcher.
 * Decouples modules from each other. Modules subscribe to events;
 * any part of the system can fire them.
 *
 * Usage:
 *   EventBus::on( 'lead.created', fn($data) => ... );
 *   EventBus::emit( 'lead.created', $data );
 */
final class EventBus {

    private static array $listeners = [];

    /** Register built-in platform event listeners. Called once by Plugin::boot(). */
    public static function init(): void {
        // Lead created → notify vendor, update analytics
        self::on( 'lead.created', static function ( array $d ): void {
            \GoodService\Service\NotificationService::on_lead_created( $d );
        } );

        // Listing approved → notify vendor
        self::on( 'listing.approved', static function ( array $d ): void {
            \GoodService\Service\NotificationService::on_listing_approved( $d );
        } );

        // Listing rejected → notify vendor
        self::on( 'listing.rejected', static function ( array $d ): void {
            \GoodService\Service\NotificationService::on_listing_rejected( $d );
        } );

        // Review approved → recalculate listing rating
        self::on( 'review.approved', static function ( array $d ): void {
            ( new \GoodService\Repository\ReviewRepository() )->recalculate_listing( (int) $d['listing_id'] );
            \GoodService\Core\Cache::delete( 'vendor_page_html:' . (int) $d['listing_id'] );
        } );

        // Real fix — major gap: on_review_created() was fully built
        // (in-app + email, using the 'new_review' template) but never
        // actually registered against any event, meaning a vendor has
        // never once been notified about a new review through this path
        // despite the notification logic itself being correct and complete.
        self::on( 'review.new', static function ( array $d ): void {
            \GoodService\Service\NotificationService::on_review_created( $d );
        } );

        // Real feature — Part 22, Public Q&A. Same registration pattern
        // as review.new directly above.
        self::on( 'question.new', static function ( array $d ): void {
            \GoodService\Service\NotificationService::on_question_created( $d );
        } );

        // Real gap fix: rejectReview() previously emitted no event at all — a
        // review that was approved (and counted in the listing's average rating),
        // then later rejected by a moderator (e.g. after a complaint), never had
        // that rating contribution removed. recalculate_listing() correctly
        // filters WHERE status='approved', so triggering it on rejection is the
        // actual fix — this mirrors review.approved's listener exactly.
        self::on( 'review.rejected', static function ( array $d ): void {
            ( new \GoodService\Repository\ReviewRepository() )->recalculate_listing( (int) $d['listing_id'] );
            \GoodService\Core\Cache::delete( 'vendor_page_html:' . (int) $d['listing_id'] );
        } );

        // Vendor verified → notify vendor
        self::on( 'vendor.verified', static function ( array $d ): void {
            \GoodService\Service\NotificationService::on_vendor_verified( $d );
        } );

        // Subscription created → generate invoice
        self::on( 'subscription.created', static function ( array $d ): void {
            \GoodService\Service\BillingService::generate_invoice( (int) $d['subscription_id'] );
        } );

        // Subscription activated (payment received) → notify vendor with payment receipt
        self::on( 'subscription.activated', static function ( array $d ): void {
            $vendor_id = (int) ( $d['vendor_id'] ?? 0 );
            if ( ! $vendor_id ) { return; }
            // Load vendor user_id and email for notification
            global $wpdb;
            $vp = $wpdb->get_row( $wpdb->prepare(
                "SELECT user_id, email, business_name FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d",
                $vendor_id
            ) );
            if ( ! $vp ) { return; }
            // In-app notification
            \GoodService\Service\NotificationService::create(
                (int) $vp->user_id, 'subscription.activated',
                '🎉 Payment Confirmed!',
                'Your ' . ( $d['plan_name'] ?? 'plan' ) . ' subscription is now active (Razorpay ID: ' . ( $d['payment_id'] ?? '' ) . ').',
                home_url( '/vendor/dashboard/?section=subscription' ),
                'check-circle', '#059669'
            );
            // Email receipt
            \GoodService\Service\EmailService::send(
                $vp->email ?: '',
                'subscription_payment_confirmed',
                [
                    'vendor_name' => $vp->business_name,
                    'plan_name'   => $d['plan_name'] ?? '',
                    'payment_id'  => $d['payment_id'] ?? '',
                    'cycle'       => $d['cycle'] ?? '',
                    'expires_at'  => $d['expires_at'] ?? '',
                ]
            );
        } );

        // Job queued → schedule processor if not already running
        self::on( 'job.queued', static function (): void {
            if ( ! wp_next_scheduled( 'gs_process_jobs' ) ) {
                wp_schedule_single_event( time() + 5, 'gs_process_jobs' );
            }
        } );

        // Manual Subscription & Offline Payment system — plan request approved & subscription
        // activated via the offline/manual path. The in-app notification is sent inline by
        // ManualPlanService::activate() at the point of activation; this listener only sends
        // the email receipt, following the same EventBus-driven side-effect pattern as
        // 'subscription.created' → invoice generation above.
        self::on( 'plan_request.activated', static function ( array $d ): void {
            $vendor_id = (int) ( $d['vendor_id'] ?? 0 );
            if ( ! $vendor_id ) { return; }
            global $wpdb;
            $vp = $wpdb->get_row( $wpdb->prepare(
                "SELECT user_id, email, business_name FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d",
                $vendor_id
            ) );
            if ( ! $vp || ! $vp->email ) { return; }
            $expires_at = $d['expires_at'] ?? '';
            $is_lifetime = $expires_at >= '2099-01-01';
            \GoodService\Service\EmailService::send(
                $vp->email,
                'plan_request_activated',
                [
                    'vendor_name'   => $vp->business_name,
                    'plan_name'     => $d['plan_name'] ?? '',
                    'expiry_clause' => $is_lifetime || ! $expires_at
                        ? ''
                        : ' until ' . date( 'd M Y', strtotime( $expires_at ) ),
                ]
            );
        } );

        // Inquiry/booking email verification hard gate (Section 1 of the
        // inquiry/booking audit) — fired by EmailVerificationService once a
        // customer clicks the verification link. Activates the lead: vendor
        // notification, leads_count, analytics — everything that was held
        // back since the inquiry was submitted with an (unverified) email.
        self::on( 'lead.email_verified', static function ( array $d ): void {
            $lead_id = (int) ( $d['lead_id'] ?? 0 );
            if ( ! $lead_id ) { return; }
            \GoodService\Controller\AjaxController::on_lead_email_verified( $lead_id );
        } );

        // Booking confirmed (Phase 1 — Bookable Inquiry Modules) → notify vendor + customer
        self::on( 'booking.confirmed', static function ( array $d ): void {
            \GoodService\Service\NotificationService::on_booking_confirmed( $d );
        } );

        // Real fix — Audit Section D/E: booking cancelled never notified
        // the customer at all. Fired from AjaxController::updateBooking().
        self::on( 'booking.cancelled', static function ( array $d ): void {
            \GoodService\Service\NotificationService::on_booking_cancelled( $d );
        } );

        // Real fix — Audit Section E: no notification fired when a
        // vendor's subscription payment succeeded. Fired from
        // AjaxController::razorpayVerifyPayment().
        self::on( 'payment.received', static function ( array $d ): void {
            \GoodService\Service\NotificationService::on_payment_received( $d );
        } );

        // Real fix — Audit Section E ("Lead acceptance/rejection"): status
        // 'won'/'lost' already existed as valid lead statuses but never
        // notified the customer. Fired from AjaxController::updateInquiryStatus().
        self::on( 'lead.status_decided', static function ( array $d ): void {
            \GoodService\Service\NotificationService::on_lead_status_decided( $d );
        } );

        // ── Previously dead events (C4+C5 fix) — added listeners ─────────────

        // Vendor registered → send welcome email + in-app notification
        self::on( 'vendor.registered', static function ( array $d ): void {
            $user_id = (int) ( $d['user_id'] ?? 0 );
            if ( ! $user_id ) { return; }
            $user = get_userdata( $user_id );
            if ( ! $user ) { return; }
            // In-app welcome notification
            \GoodService\Service\NotificationService::create(
                $user_id, 'vendor.registered',
                '👋 Welcome to ' . \GoodService\Core\Config::get( 'platform_name', 'GoodService' ) . '!',
                'Your vendor account is ready. Complete your listing to start receiving inquiries.',
                home_url( '/vendor/create/' ),
                'user', '#2563EB'
            );
            // Welcome email
            // Real fix — confirmed bug: was sending with slug
            // 'vendor_welcome' (no such template exists — only 'welcome'
            // does) and variable key 'vendor_name' when the template
            // expects '{{name}}'. Both mismatches meant this has silently
            // failed every time, caught via the email-templates diagnostic.
            \GoodService\Service\EmailService::send( $user->user_email, 'welcome', [
                'name' => $user->display_name ?? $user->user_email,
            ] );

            // Real fix — confirmed gap: email verification was entirely
            // absent (gs_account_email_verified was read in one place but
            // never set anywhere, no send flow, no token, no link).
            \GoodService\Api\RestApiController::send_verification_email(
                $user->ID, $user->user_email, $user->display_name ?: $user->user_email
            );

            // Real fix — confirmed gap from full admin-notification audit:
            // new vendor registration never notified admin at all, despite
            // being explicitly the first example on the audit's own list.
            \GoodService\Service\NotificationService::notify_admins(
                'vendor.registered', '👋 New Vendor Registered',
                ( $user->display_name ?: $user->user_email ) . ' just registered as a vendor.',
                home_url( '/admin-panel/?section=vendors' )
            );
        } );

        // Booking deposit paid → notify vendor of payment confirmation
        self::on( 'booking.deposit_paid', static function ( array $d ): void {
            $vendor_user_id = (int) ( $d['vendor_user_id'] ?? 0 );
            if ( ! $vendor_user_id ) { return; }
            \GoodService\Service\NotificationService::create(
                $vendor_user_id, 'booking.deposit_paid',
                '💰 Booking Deposit Received',
                'A deposit of ₹' . number_format( (float) ( $d['amount'] ?? 0 ), 2 ) . ' has been paid for booking #' . ( $d['booking_id'] ?? '' ) . '.',
                home_url( '/vendor/dashboard/?section=bookings' ),
                'check-circle', '#059669'
            );
        } );

        // Booking reminder → remind vendor of upcoming booking
        self::on( 'booking.reminder', static function ( array $d ): void {
            $vendor_user_id = (int) ( $d['vendor_user_id'] ?? 0 );
            if ( ! $vendor_user_id ) { return; }
            \GoodService\Service\NotificationService::create(
                $vendor_user_id, 'booking.reminder',
                '⏰ Upcoming Booking Reminder',
                'You have a booking scheduled for ' . ( $d['scheduled_at'] ?? 'soon' ) . '. Customer: ' . ( $d['customer_name'] ?? 'N/A' ) . '.',
                home_url( '/vendor/dashboard/?section=bookings' ),
                'clock', '#D97706'
            );
        } );

        // Booking expired → notify vendor that unconfirmed booking has expired
        self::on( 'booking.expired', static function ( array $d ): void {
            $vendor_user_id = (int) ( $d['vendor_user_id'] ?? 0 );
            if ( ! $vendor_user_id ) { return; }
            \GoodService\Service\NotificationService::create(
                $vendor_user_id, 'booking.expired',
                '⌛ Booking Expired',
                'Booking #' . ( $d['booking_id'] ?? '' ) . ' expired without confirmation.',
                home_url( '/vendor/dashboard/?section=bookings' ),
                'x-circle', '#DC2626'
            );
        } );

        // Booking no-show → notify vendor for tracking
        self::on( 'booking.noshow', static function ( array $d ): void {
            $vendor_user_id = (int) ( $d['vendor_user_id'] ?? 0 );
            if ( ! $vendor_user_id ) { return; }
            \GoodService\Service\NotificationService::create(
                $vendor_user_id, 'booking.noshow',
                '🚫 Customer No-Show',
                'Customer did not show for booking #' . ( $d['booking_id'] ?? '' ) . '. The booking has been marked as no-show.',
                home_url( '/vendor/dashboard/?section=bookings' ),
                'user-x', '#DC2626'
            );
        } );

        // Booking rescheduled → notify both vendor and customer
        self::on( 'booking.rescheduled', static function ( array $d ): void {
            $vendor_user_id = (int) ( $d['vendor_user_id'] ?? 0 );
            if ( $vendor_user_id ) {
                \GoodService\Service\NotificationService::create(
                    $vendor_user_id, 'booking.rescheduled',
                    '📅 Booking Rescheduled',
                    'Booking #' . ( $d['booking_id'] ?? '' ) . ' has been rescheduled to ' . ( $d['new_time'] ?? 'a new time' ) . '.',
                    home_url( '/vendor/dashboard/?section=bookings' ),
                    'calendar', '#2563EB'
                );
            }
        } );

        // Booking review request → prompt customer to leave review after job
        self::on( 'booking.review_request', static function ( array $d ): void {
            $customer_email = $d['customer_email'] ?? '';
            $listing_slug   = $d['listing_slug']   ?? '';
            if ( $customer_email && $listing_slug ) {
                \GoodService\Service\EmailService::send( $customer_email, 'review_request', [
                    'customer_name' => $d['customer_name'] ?? 'Customer',
                    'vendor_name'   => $d['vendor_name']   ?? 'the service provider',
                    'review_url'    => home_url( '/' . $listing_slug . '/#reviews' ),
                ] );
            }
        } );

        // Booking stuck → alert admin so they can intervene
        self::on( 'booking.stuck', static function ( array $d ): void {
            $admin_email = get_option( 'admin_email' );
            if ( $admin_email ) {
                \GoodService\Service\EmailService::send( $admin_email, 'admin_booking_stuck_alert', [
                    'booking_id'  => $d['booking_id'] ?? 'unknown',
                    'stuck_since' => $d['stuck_since'] ?? 'unknown',
                    'admin_url'   => home_url( '/admin-panel/?section=bookings&id=' . ( $d['booking_id'] ?? '' ) ),
                ] );
            }
        } );

        // Real feature — closes a gap discovered while auditing the
        // notification system: DisputeService (built earlier this
        // engagement) already emitted these events, but nothing was
        // listening, so nobody was ever actually notified of a dispute
        // being opened or resolved despite the full notification
        // infrastructure (in-app, email, push) already existing.
        self::on( 'dispute.opened', static function ( array $d ): void {
            \GoodService\Service\NotificationService::on_dispute_opened( $d );
        } );
        self::on( 'dispute.resolved', static function ( array $d ): void {
            \GoodService\Service\NotificationService::on_dispute_resolved( $d );
        } );

        // Real feature — closes a confirmed gap: subscription_plans.is_featured
        // existed purely as marketing data (a "this plan includes featured
        // placement" bullet point) with zero code anywhere that actually
        // granted featured status when a vendor was on such a plan.
        // Registered on all three activation paths (gateway payment,
        // gateway subscription creation, and manual/offline activation)
        // since they were confirmed to use different event names — the
        // shared handler looks up the vendor's current plan directly
        // from gs_subscriptions rather than trusting each event's
        // payload shape, which was confirmed to differ between them.
        $sync_featured = static function ( array $d ): void {
            \GoodService\Service\SubscriptionService::sync_featured_status( (int) ( $d['vendor_id'] ?? 0 ) );
        };
        self::on( 'subscription.activated', $sync_featured );
        self::on( 'subscription.created', $sync_featured );
        self::on( 'plan_request.activated', $sync_featured );

        // Real fix — confirmed gap from full admin-notification audit:
        // this event was already being emitted (SubscriptionService::cancel())
        // but had no registered listener at all — cancellation currently
        // does nothing, not even notifying the vendor it happened, let
        // alone the admin about a revenue-loss event.
        self::on( 'subscription.cancelled', static function ( array $d ): void {
            $vendor_id = (int) ( $d['vendor_id'] ?? 0 );
            $user_id   = (int) ( $d['user_id'] ?? 0 );
            if ( ! $vendor_id ) { return; }
            global $wpdb;
            $vp = $wpdb->get_row( $wpdb->prepare(
                "SELECT business_name, email FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $vendor_id
            ) );
            if ( $user_id ) {
                \GoodService\Service\NotificationService::create(
                    $user_id, 'subscription.cancelled', '📋 Subscription Cancelled',
                    'Your subscription has been cancelled. You are now on the free plan.',
                    home_url( '/vendor/dashboard/?section=plans' ), 'alert-triangle', '#D97706'
                );
            }
            // Real fix — confirmed gap: this was in-app only, never email.
            // Uses gs_vendor_site_email() (the listing's own contact
            // email) rather than vendor_profiles.email directly, per
            // explicit request — a vendor's account/login email can
            // genuinely differ from the address on their public listing.
            $notify_email = gs_vendor_site_email( $vendor_id );
            if ( $notify_email ) {
                \GoodService\Service\EmailService::send( $notify_email, 'subscription_cancelled_vendor', [
                    'vendor_name' => $vp->business_name ?: 'there',
                ] );
            }
            \GoodService\Service\NotificationService::notify_admins(
                'subscription.cancelled', '📉 Vendor Subscription Cancelled',
                ( $vp->business_name ?? 'A vendor' ) . ' cancelled their paid subscription and reverted to the free plan.',
                home_url( '/admin-panel/?section=vendors' )
            );
        } );

        self::on( 'subscription.expired', static function ( array $d ): void {
            $vendor_id = (int) ( $d['vendor_id'] ?? 0 );
            $user_id   = (int) ( $d['user_id'] ?? 0 );
            if ( ! $vendor_id ) { return; }
            global $wpdb;
            $vp = $wpdb->get_row( $wpdb->prepare(
                "SELECT business_name, email FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $vendor_id
            ) );
            if ( $user_id ) {
                \GoodService\Service\NotificationService::create(
                    $user_id, 'subscription.expired', '⏰ Subscription Expired',
                    'Your subscription has expired and you are now on the free plan. Renew anytime to restore your paid features.',
                    home_url( '/vendor/dashboard/?section=plans' ), 'alert-triangle', '#D97706'
                );
            }
            // Real fix — confirmed gap: this was in-app only, never email
            // (and the query didn't even select the email column at all).
            // Uses gs_vendor_site_email() per explicit request — the
            // listing's own contact email, not the account/login email.
            $notify_email = gs_vendor_site_email( $vendor_id );
            if ( $notify_email ) {
                \GoodService\Service\EmailService::send( $notify_email, 'subscription_expired_vendor', [
                    'vendor_name' => $vp->business_name ?: 'there',
                ] );
            }
            \GoodService\Service\NotificationService::notify_admins(
                'subscription.expired', '⏰ Vendor Subscription Expired',
                ( $vp->business_name ?? 'A vendor' ) . "'s subscription lapsed without renewal and reverted to the free plan — a possible follow-up opportunity.",
                home_url( '/admin-panel/?section=vendors' )
            );
        } );
    }

    /** Subscribe to an event. Multiple listeners per event are supported. */
    public static function on( string $event, callable $listener ): void {
        self::$listeners[ $event ][] = $listener;
    }

    /** Fire an event. All registered listeners are called synchronously. */
    public static function emit( string $event, array $data = [] ): void {
        foreach ( self::$listeners[ $event ] ?? [] as $listener ) {
            try {
                $listener( $data );
            } catch ( \Throwable $e ) {
                error_log( "[GoodService] EventBus error on '{$event}': " . $e->getMessage() );
            }
        }
        // Also fire a WP action so external code can hook in
        do_action( 'gs_event_' . str_replace( '.', '_', $event ), $data );
    }

    /** Check if any listeners are registered for an event. */
    public static function has( string $event ): bool {
        return ! empty( self::$listeners[ $event ] );
    }
}
