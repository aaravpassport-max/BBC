<?php
namespace GoodService\Core;

final class Assets {

    public static function enqueue(): void {
        wp_enqueue_style(
            'goodservice',
            GS_URL . 'assets/css/goodservice.css',
            [],
            GS_VERSION
        );
        wp_enqueue_script(
            'goodservice',
            GS_URL . 'assets/js/goodservice.js',
            [ 'jquery' ],
            GS_VERSION,
            true
        );
        wp_localize_script( 'goodservice', 'GS', self::config() );

        // FIXED — Known Limitations audit: enables the vendor Leads screen's
        // Heartbeat-based near-real-time new-inquiry notification (see
        // Plugin::gs_heartbeat_settings()/AjaxController::inject_inquiry_heartbeat()).
        // WordPress core's own 'heartbeat' script — not bundled, always
        // available, safe to enqueue unconditionally since it's a no-op
        // unless a page actually listens for 'heartbeat-tick'.
        wp_enqueue_script( 'heartbeat' );
    }

    /** Alias used by Router — keeps backward compatibility */
    public static function js_config(): array {
        return self::config();
    }

    public static function config(): array {
        $user = wp_get_current_user();
        try {
            $vp  = \GoodService\Repository\VendorRepository::get_by_user( $user->ID );
            $sub = \GoodService\Service\SubscriptionService::get_active( $user->ID );
        } catch ( \Throwable ) {
            $vp  = null;
            $sub = null;
        }
        return [
            'ajax_url'      => admin_url( 'admin-ajax.php' ),
            'rest_url'      => rest_url( 'goodservice/v1/' ),
            'nonce'         => wp_create_nonce( 'gs_ajax' ),
            'rest_nonce'    => wp_create_nonce( 'wp_rest' ),
            'home_url'      => home_url( '/' ),
            'plugin_url'    => GS_URL,
            'assets_url'    => GS_URL . 'assets/',
            'version'       => GS_VERSION,
            'sw_urls'       => [
                'client' => self::pwa_service_worker_urls( 'client' ),
                'vendor' => self::pwa_service_worker_urls( 'vendor' ),
            ],
            'root_sw_synced' => get_option( 'gs_root_sw_synced_version', '' ) === GS_VERSION,
            'manifest_url'   => gs_pwa_manifest_url( 'client' ),
            // Real bug fix: push subscription (gsRequestPushPermission /
            // gsRequestClientPushPermission in goodservice.js) reads
            // window.GS.vapid_public_key — this was never localized here at
            // all, meaning pushManager.subscribe() could never succeed for
            // any visitor, vendor or client, regardless of browser support
            // or permission grants. Same option already used server-side in
            // NotificationService.php for signing outbound push payloads.
            'vapid_public_key' => get_option( 'gs_vapid_public_key' ),
            'user_id'       => $user->ID,
            'user_name'     => $user->display_name ?? '',
            'user_email'    => $user->user_email   ?? '',
            'is_logged_in'  => is_user_logged_in() ? 1 : 0,
            'is_vendor'     => Roles::is_vendor()      ? 1 : 0,
            'is_admin'      => Roles::is_admin_level() ? 1 : 0,
            'vendor_id'     => $vp  ? (int) $vp->id   : 0,
            'currency_sym'  => Config::get( 'currency_symbol', '₹' ),
            'platform_name' => Config::get( 'platform_name',   'GoodService' ),
            'vendor_url'    => home_url( '/vendor/dashboard/' ),
            'admin_url_gs'  => home_url( '/admin-panel/' ),
            'login_url'     => home_url( '/vendor/login/' ),
            'register_url'  => home_url( '/vendor/register/' ),
            'plan_name'     => $sub ? ( $sub->plan_name ?? 'Free' ) : 'Free',
            'modules'       => [
                'booking'      => \GoodService\Module\ModuleManager::is_enabled( 'booking'      ) ? 1 : 0,
                'messaging'    => \GoodService\Module\ModuleManager::is_enabled( 'messaging'    ) ? 1 : 0,
                'requirements' => \GoodService\Module\ModuleManager::is_enabled( 'requirements' ) ? 1 : 0,
                'analytics'    => \GoodService\Module\ModuleManager::is_enabled( 'analytics'    ) ? 1 : 0,
                'reviews'      => \GoodService\Module\ModuleManager::is_enabled( 'reviews'      ) ? 1 : 0,
            ],
            'i18n' => [
                'error'     => 'Something went wrong. Please try again.',
                'login_req' => 'Please login to continue.',
                'saving'    => 'Saving…',
                'saved'     => 'Saved!',
                'confirm'   => 'Are you sure?',
            ],
        ];
    }

    /** Ordered fallback URLs for service worker registration (ajax first — bypasses Anubis on static paths). */
    private static function pwa_service_worker_urls( string $type ): array {
        $file = $type === 'vendor' ? 'gs-vendor-sw.js' : 'gs-client-sw.js';
        $v    = rawurlencode( GS_VERSION );
        $urls = [
            admin_url( 'admin-ajax.php?action=gs_serve_sw&type=' . $type . '&v=' . $v ),
        ];
        if ( file_exists( ABSPATH . $file ) ) {
            $urls[] = home_url( $file . '?v=' . $v );
        }
        $urls[] = rest_url( 'goodservice/v1/sw?type=' . $type . '&v=' . $v );
        if ( file_exists( GS_DIR . 'assets/js/' . $file ) ) {
            $urls[] = GS_URL . 'assets/js/' . $file . '?v=' . $v;
        }

        return $urls;
    }
}
