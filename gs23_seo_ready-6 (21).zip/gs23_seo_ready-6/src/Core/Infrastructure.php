<?php
namespace GoodService\Core;

/**
 * Infrastructure — Toggle-based runtime layer for Redis, external MySQL, and Meilisearch.
 *
 * How it works:
 *   Admin sets connection details in Settings → Infrastructure.
 *   Each service has a "mode" toggle: 'off' | 'active'.
 *   When 'active', the connection is tested on every wp_loaded hook.
 *   If the test passes, the service is used. If it fails, the platform
 *   transparently falls back to the current (Nestify) setup — zero downtime.
 *
 * Migration path (zero-downtime):
 *   1. Fill in connection details for the new service.
 *   2. Set mode to 'test' — platform tests the connection and reports status.
 *   3. Set mode to 'active' — platform uses the new service with silent fallback.
 *   4. Monitor for 48 hours. If stable, the migration is complete.
 *
 * Nothing in this class touches any existing code paths unless a service
 * is explicitly set to 'active' by the admin.
 */
final class Infrastructure {

    /** Singleton boot guard */
    private static bool $booted = false;

    /** Live connection test results (populated on boot) */
    public static array $status = [
        'redis'       => [ 'mode' => 'off', 'ok' => false, 'msg' => 'Not configured' ],
        'mysql'       => [ 'mode' => 'off', 'ok' => false, 'msg' => 'Not configured' ],
        'meilisearch' => [ 'mode' => 'off', 'ok' => false, 'msg' => 'Not configured' ],
    ];

    /** External MySQL connection (set when active + healthy) */
    public static ?\mysqli $ext_mysql = null;

    // =========================================================================
    // Boot — called once from goodservice.php after Config::load()
    // =========================================================================

    public static function boot(): void {
        if ( self::$booted ) { return; }
        self::$booted = true;

        self::maybe_boot_redis();
        self::maybe_boot_mysql();
        self::maybe_boot_meilisearch();
    }

    // =========================================================================
    // REDIS
    // =========================================================================

    /**
     * Redis setup — zero-code path.
     *
     * Nestify (and most managed WordPress hosts) support Redis via the
     * "Redis Object Cache" or "W3 Total Cache" plugin. When that plugin is
     * installed and configured, WordPress's wp_cache_* functions automatically
     * use Redis. This class does NOT need to do anything for that path.
     *
     * This method handles the MANUAL path: when the admin has provided Redis
     * connection details and we need to configure the object cache ourselves.
     * This is only needed when NOT using a Redis plugin.
     */
    private static function maybe_boot_redis(): void {
        $mode = Config::get( 'infra_redis_mode', 'off' );
        self::$status['redis']['mode'] = $mode;

        // Check if a WordPress Redis plugin is already handling it
        if ( defined( 'WP_REDIS_VERSION' ) || defined( 'REDIS_OBJECT_CACHE' ) ) {
            // Redis plugin is active — it manages the connection. Report its status.
            $ok  = function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache();
            self::$status['redis'] = [
                'mode' => 'plugin',
                'ok'   => $ok,
                'msg'  => $ok
                    ? 'Redis active via WordPress plugin (automatic)'
                    : 'Redis plugin installed but object cache not connected',
            ];
            return;
        }

        if ( $mode !== 'active' && $mode !== 'test' ) {
            self::$status['redis']['msg'] = 'Redis not configured. See Settings → Infrastructure.';
            return;
        }

        $host   = Config::get( 'infra_redis_host', '127.0.0.1' );
        $port   = (int) Config::get( 'infra_redis_port', 6379 );
        $pass   = Config::get( 'infra_redis_password', '' );
        $db     = (int) Config::get( 'infra_redis_db', 0 );

        if ( ! $host ) {
            self::$status['redis'] = [ 'mode' => $mode, 'ok' => false, 'msg' => 'Redis host not set.' ];
            return;
        }

        // Test connection
        $result = self::test_redis_connection( $host, $port, $pass, $db );
        self::$status['redis'] = array_merge( [ 'mode' => $mode ], $result );

        if ( $result['ok'] && $mode === 'active' ) {
            // Define constants for the Redis Object Cache plugin to auto-connect
            // These constants are read on the next request after wp-config.php loads
            // For the current request, we inject the constants now if not already set
            if ( ! defined( 'WP_REDIS_HOST' ) ) {
                define( 'WP_REDIS_HOST', $host );
                define( 'WP_REDIS_PORT', $port );
                if ( $pass ) { define( 'WP_REDIS_PASSWORD', $pass ); }
                define( 'WP_REDIS_DATABASE', $db );
                define( 'WP_CACHE', true );
            }

            // Write to wp-config.php addendum if we have write access
            self::write_redis_config( $host, $port, $pass, $db );
        }
    }

    public static function test_redis_connection( string $host, int $port, string $pass, int $db ): array {
        if ( ! extension_loaded( 'redis' ) && ! class_exists( 'Redis' ) ) {
            // Try socket connection as a basic connectivity test
            $sock = @fsockopen( $host, $port, $errno, $errstr, 2 );
            if ( $sock ) {
                fclose( $sock );
                return [ 'ok' => true, 'msg' => "Redis port {$port} reachable on {$host}. Install PHP Redis extension for full support." ];
            }
            return [ 'ok' => false, 'msg' => "Cannot reach Redis at {$host}:{$port}. Error: {$errstr}" ];
        }

        try {
            $redis = new \Redis();
            $connected = $redis->connect( $host, $port, 2.0 ); // 2s timeout
            if ( ! $connected ) {
                return [ 'ok' => false, 'msg' => "Redis connection refused at {$host}:{$port}" ];
            }
            if ( $pass && ! $redis->auth( $pass ) ) {
                return [ 'ok' => false, 'msg' => 'Redis authentication failed. Check password.' ];
            }
            if ( $db ) { $redis->select( $db ); }
            $pong = $redis->ping( 'gs_test' );
            $redis->close();
            if ( $pong === 'gs_test' || $pong === true ) {
                return [ 'ok' => true, 'msg' => "Redis connected and responding at {$host}:{$port}" ];
            }
            return [ 'ok' => false, 'msg' => 'Redis PING failed — unexpected response.' ];
        } catch ( \Throwable $e ) {
            return [ 'ok' => false, 'msg' => 'Redis error: ' . $e->getMessage() ];
        }
    }

    /**
     * Write Redis constants to a drop-in config file that gets included
     * by wp-config.php (if the admin has added the include line), or
     * store as wp_options for display/documentation purposes.
     */
    private static function write_redis_config( string $host, int $port, string $pass, int $db ): void {
        $lines = [
            "<?php",
            "// GoodService Infrastructure — Redis configuration",
            "// Auto-generated by Infrastructure::boot(). Do not edit manually.",
            "// Generated: " . date( 'Y-m-d H:i:s' ),
            "if ( ! defined( 'WP_REDIS_HOST' ) ) {",
            "    define( 'WP_REDIS_HOST',     '" . esc_attr( $host ) . "' );",
            "    define( 'WP_REDIS_PORT',     " . $port . " );",
            $pass ? "    define( 'WP_REDIS_PASSWORD', '" . esc_attr( $pass ) . "' );" : "    // No Redis password set",
            "    define( 'WP_REDIS_DATABASE', " . $db . " );",
            "    define( 'WP_CACHE',          true );",
            "}",
        ];
        $file = WP_CONTENT_DIR . '/gs-redis-config.php';
        @file_put_contents( $file, implode( "\n", $lines ) . "\n" );

        // Store the snippet admin needs to add to wp-config.php
        $snippet = "require_once WP_CONTENT_DIR . '/gs-redis-config.php';";
        update_option( 'gs_infra_redis_snippet', $snippet );
    }

    // =========================================================================
    // EXTERNAL MYSQL
    // =========================================================================

    /**
     * External MySQL — connect to a separate database server.
     *
     * When mode = 'active', we connect to the external MySQL server and
     * replace WordPress's $wpdb connection for GoodService tables only.
     * All other WordPress tables continue to use the original Nestify connection.
     *
     * Implementation: We do NOT replace $wpdb globally (that would break WordPress).
     * Instead, we establish a parallel mysqli connection and expose it via
     * Infrastructure::$ext_mysql. The GoodService query helper gs_db() uses this
     * when available, falling back to $wpdb transparently.
     *
     * Migration path:
     *   1. Set up external MySQL (DigitalOcean Managed DB, AWS RDS, etc.)
     *   2. Export your GoodService tables from Nestify and import to new server
     *   3. Fill in connection details and set mode to 'test'
     *   4. Verify connection test passes
     *   5. Set mode to 'active' — GoodService tables now hit the external server
     */
    private static function maybe_boot_mysql(): void {
        $mode = Config::get( 'infra_mysql_mode', 'off' );
        self::$status['mysql']['mode'] = $mode;

        if ( $mode !== 'active' && $mode !== 'test' ) {
            self::$status['mysql']['msg'] = 'External MySQL not configured. Using Nestify database (current setup).';
            return;
        }

        $host   = Config::get( 'infra_mysql_host', '' );
        $port   = (int) Config::get( 'infra_mysql_port', 3306 );
        $user   = Config::get( 'infra_mysql_user', '' );
        $pass   = Config::get( 'infra_mysql_password', '' );
        $dbname = Config::get( 'infra_mysql_dbname', '' );
        $ssl    = Config::get( 'infra_mysql_ssl', '1' ) === '1';

        if ( ! $host || ! $user || ! $dbname ) {
            self::$status['mysql'] = [
                'mode' => $mode,
                'ok'   => false,
                'msg'  => 'External MySQL: host, user, and database name are required.',
            ];
            return;
        }

        $result = self::test_mysql_connection( $host, $port, $user, $pass, $dbname, $ssl );
        self::$status['mysql'] = array_merge( [ 'mode' => $mode ], $result );

        if ( $result['ok'] && $mode === 'active' ) {
            // Store the live connection for use by gs_db()
            self::$ext_mysql = $result['conn'] ?? null;
            unset( self::$status['mysql']['conn'] ); // don't expose conn object in status array
        }
    }

    public static function test_mysql_connection(
        string $host, int $port, string $user, string $pass, string $dbname, bool $ssl
    ): array {
        if ( ! extension_loaded( 'mysqli' ) ) {
            return [ 'ok' => false, 'msg' => 'PHP mysqli extension not loaded on this server.' ];
        }

        try {
            $mysqli = new \mysqli();
            $mysqli->init();

            if ( $ssl ) {
                // DigitalOcean Managed MySQL requires SSL
                $mysqli->ssl_set( null, null, null, null, null );
                $mysqli->options( MYSQLI_OPT_SSL_VERIFY_SERVER_CERT, false );
            }

            $connected = @$mysqli->real_connect( $host, $user, $pass, $dbname, $port );

            if ( ! $connected || $mysqli->connect_errno ) {
                return [ 'ok' => false, 'msg' => 'MySQL connection failed: ' . $mysqli->connect_error ];
            }

            // Quick sanity check — confirm GoodService tables exist
            $test = $mysqli->query( "SHOW TABLES LIKE '" . $mysqli->real_escape_string( DB_PREFIX ?? 'wp_' ) . "gs_listings'" );
            $has_tables = $test && $test->num_rows > 0;

            if ( ! $has_tables ) {
                $mysqli->close();
                return [
                    'ok'  => false,
                    'msg' => "Connected to {$host} but GoodService tables not found in '{$dbname}'. Have you imported the data?",
                ];
            }

            return [
                'ok'   => true,
                'msg'  => "External MySQL connected: {$host}:{$port} / {$dbname}",
                'conn' => $mysqli,
            ];

        } catch ( \Throwable $e ) {
            return [ 'ok' => false, 'msg' => 'MySQL error: ' . $e->getMessage() ];
        }
    }

    // =========================================================================
    // MEILISEARCH
    // =========================================================================

    /**
     * Meilisearch — fast full-text search engine.
     * When active, keyword search queries go to Meilisearch instead of MySQL FULLTEXT.
     * All writes (listing save/update/delete) sync to Meilisearch automatically.
     *
     * Not needed until you have 20+ lakh listings. Configure in advance,
     * populate the index, then flip the mode toggle when ready.
     */
    private static function maybe_boot_meilisearch(): void {
        $mode = Config::get( 'infra_meili_mode', 'off' );
        self::$status['meilisearch']['mode'] = $mode;

        if ( $mode !== 'active' && $mode !== 'test' ) {
            self::$status['meilisearch']['msg'] = 'Meilisearch not configured. Not needed until 20+ lakh listings.';
            return;
        }

        $host   = Config::get( 'infra_meili_host', '' );
        $key    = Config::get( 'infra_meili_api_key', '' );
        $index  = Config::get( 'infra_meili_index', 'gs_listings' );

        if ( ! $host ) {
            self::$status['meilisearch'] = [
                'mode' => $mode,
                'ok'   => false,
                'msg'  => 'Meilisearch host URL not set.',
            ];
            return;
        }

        $result = self::test_meilisearch_connection( $host, $key );
        self::$status['meilisearch'] = array_merge( [ 'mode' => $mode, 'index' => $index ], $result );
    }

    public static function test_meilisearch_connection( string $host, string $key ): array {
        $host = rtrim( $host, '/' );
        $args = [
            'timeout' => 5,
            'headers' => array_filter( [
                'Authorization' => $key ? "Bearer {$key}" : '',
                'Content-Type'  => 'application/json',
            ] ),
        ];

        $response = wp_remote_get( "{$host}/health", $args );

        if ( is_wp_error( $response ) ) {
            return [ 'ok' => false, 'msg' => 'Cannot reach Meilisearch: ' . $response->get_error_message() ];
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 ) {
            return [ 'ok' => false, 'msg' => "Meilisearch returned HTTP {$code}. Check host URL and API key." ];
        }

        $status = $body['status'] ?? '';
        if ( $status === 'available' ) {
            return [ 'ok' => true, 'msg' => "Meilisearch healthy at {$host}" ];
        }

        return [ 'ok' => false, 'msg' => "Meilisearch responded but status is '{$status}' (expected 'available')" ];
    }

    // =========================================================================
    // Meilisearch search — called from keyword search when mode=active
    // =========================================================================

    /**
     * Execute a keyword search against Meilisearch.
     * Returns an array of listing IDs in relevance order,
     * or null if Meilisearch is not active / unavailable.
     *
     * Callers: archive.php, AjaxController::directoryFilter()
     * Usage:
     *   $ids = Infrastructure::meili_search($keyword, ['city'=>$city, 'category_id'=>$cat]);
     *   if ($ids !== null) { use IDs in WHERE l.id IN(...) }
     *   else               { use FULLTEXT / LIKE fallback }
     */
    public static function meili_search( string $keyword, array $filters = [], int $limit = 100 ): ?array {
        $s = self::$status['meilisearch'];
        if ( ( $s['mode'] ?? 'off' ) !== 'active' || ! ( $s['ok'] ?? false ) ) {
            return null; // Not active or connection failed — caller uses fallback
        }

        $host  = rtrim( Config::get( 'infra_meili_host', '' ), '/' );
        $key   = Config::get( 'infra_meili_api_key', '' );
        $index = Config::get( 'infra_meili_index', 'gs_listings' );

        if ( ! $host ) { return null; }

        // Build Meilisearch filter string
        $meili_filters = [ "status = 'active'" ];
        if ( ! empty( $filters['category_id'] ) ) {
            $meili_filters[] = 'category_id = ' . (int) $filters['category_id'];
        }
        if ( ! empty( $filters['city'] ) ) {
            // city_list is an array field we index that contains primary + service cities
            $meili_filters[] = 'city_list = "' . addslashes( $filters['city'] ) . '"';
        }
        if ( ! empty( $filters['min_rating'] ) ) {
            $meili_filters[] = 'avg_rating >= ' . (float) $filters['min_rating'];
        }
        if ( ! empty( $filters['is_verified'] ) ) {
            $meili_filters[] = 'is_verified = true';
        }

        $payload = [
            'q'      => $keyword,
            'limit'  => $limit,
            'attributesToRetrieve' => [ 'id' ],
        ];
        if ( ! empty( $meili_filters ) ) {
            $payload['filter'] = implode( ' AND ', $meili_filters );
        }

        $response = wp_remote_post( "{$host}/indexes/{$index}/search", [
            'timeout' => 3,
            'headers' => array_filter( [
                'Authorization' => $key ? "Bearer {$key}" : '',
                'Content-Type'  => 'application/json',
            ] ),
            'body' => wp_json_encode( $payload ),
        ] );

        if ( is_wp_error( $response ) ) { return null; }
        if ( wp_remote_retrieve_response_code( $response ) !== 200 ) { return null; }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        $hits = $body['hits'] ?? [];

        return array_map( fn( $h ) => (int) $h['id'], $hits );
    }

    /**
     * Sync a single listing to Meilisearch.
     * Called from ListingRepository::save() when mode = 'active'.
     * Silently skips if Meilisearch is not configured.
     *
     * @param array $data  The listing data being saved (same array as the DB write)
     * @param int   $id    The listing ID
     */
    public static function meili_sync_listing( int $id, array $data ): void {
        $s = self::$status['meilisearch'];
        if ( ( $s['mode'] ?? 'off' ) !== 'active' || ! ( $s['ok'] ?? false ) ) { return; }

        $host  = rtrim( Config::get( 'infra_meili_host', '' ), '/' );
        $key   = Config::get( 'infra_meili_api_key', '' );
        $index = Config::get( 'infra_meili_index', 'gs_listings' );

        if ( ! $host ) { return; }

        // Build the document — only searchable and filterable fields
        $svc_cities = [];
        if ( ! empty( $data['service_cities'] ) ) {
            $decoded = is_string( $data['service_cities'] )
                ? json_decode( $data['service_cities'], true )
                : $data['service_cities'];
            if ( is_array( $decoded ) ) { $svc_cities = $decoded; }
        }

        $city_list = array_unique( array_filter( array_merge(
            [ trim( $data['city'] ?? '' ) ],
            $svc_cities
        ) ) );

        $doc = [
            'id'          => $id,
            'title'       => $data['title']      ?? '',
            'tagline'     => $data['tagline']     ?? '',
            'short_desc'  => $data['short_desc']  ?? '',
            'tags'        => $data['tags']        ?? '',
            'city'        => $data['city']        ?? '',
            'city_list'   => array_values( $city_list ),
            'category_id' => (int) ( $data['category_id'] ?? 0 ),
            'avg_rating'  => (float) ( $data['avg_rating'] ?? 0 ),
            'is_featured' => (bool) ( $data['is_featured'] ?? false ),
            'is_verified' => (bool) ( $data['is_verified'] ?? false ),
            'status'      => $data['status'] ?? 'active',
        ];

        // Fire and forget — do not wait for response (background sync)
        wp_remote_post( "{$host}/indexes/{$index}/documents", [
            'timeout'  => 2,
            'blocking' => false, // non-blocking: doesn't slow down listing save
            'headers'  => array_filter( [
                'Authorization' => $key ? "Bearer {$key}" : '',
                'Content-Type'  => 'application/json',
            ] ),
            'body' => wp_json_encode( [ $doc ] ),
        ] );
    }

    /**
     * Delete a listing from Meilisearch index (on soft-delete or hard-delete).
     */
    public static function meili_delete_listing( int $id ): void {
        $s = self::$status['meilisearch'];
        if ( ( $s['mode'] ?? 'off' ) !== 'active' || ! ( $s['ok'] ?? false ) ) { return; }

        $host  = rtrim( Config::get( 'infra_meili_host', '' ), '/' );
        $key   = Config::get( 'infra_meili_api_key', '' );
        $index = Config::get( 'infra_meili_index', 'gs_listings' );

        if ( ! $host ) { return; }

        wp_remote_request( "{$host}/indexes/{$index}/documents/{$id}", [
            'method'   => 'DELETE',
            'timeout'  => 2,
            'blocking' => false,
            'headers'  => array_filter( [ 'Authorization' => $key ? "Bearer {$key}" : '' ] ),
        ] );
    }

    // =========================================================================
    // Status API — called by admin dashboard
    // =========================================================================

    /** Return all service statuses for the admin panel */
    public static function get_status(): array {
        return self::$status;
    }

    /** Run fresh connection tests and return results (for "Test Connection" button) */
    public static function run_tests(): array {
        $results = [];

        // Redis
        $host = Config::get( 'infra_redis_host', '127.0.0.1' );
        $port = (int) Config::get( 'infra_redis_port', 6379 );
        $pass = Config::get( 'infra_redis_password', '' );
        $db   = (int) Config::get( 'infra_redis_db', 0 );
        if ( $host ) {
            $results['redis'] = self::test_redis_connection( $host, $port, $pass, $db );
        } else {
            $results['redis'] = [ 'ok' => false, 'msg' => 'Redis host not configured' ];
        }

        // MySQL
        $h  = Config::get( 'infra_mysql_host', '' );
        $p  = (int) Config::get( 'infra_mysql_port', 3306 );
        $u  = Config::get( 'infra_mysql_user', '' );
        $pw = Config::get( 'infra_mysql_password', '' );
        $db = Config::get( 'infra_mysql_dbname', '' );
        $ssl = Config::get( 'infra_mysql_ssl', '1' ) === '1';
        if ( $h && $u && $db ) {
            $r = self::test_mysql_connection( $h, $p, $u, $pw, $db, $ssl );
            if ( isset( $r['conn'] ) ) { $r['conn']->close(); unset( $r['conn'] ); }
            $results['mysql'] = $r;
        } else {
            $results['mysql'] = [ 'ok' => false, 'msg' => 'MySQL host/user/database not configured' ];
        }

        // Meilisearch
        $mh  = Config::get( 'infra_meili_host', '' );
        $mk  = Config::get( 'infra_meili_api_key', '' );
        if ( $mh ) {
            $results['meilisearch'] = self::test_meilisearch_connection( $mh, $mk );
        } else {
            $results['meilisearch'] = [ 'ok' => false, 'msg' => 'Meilisearch host not configured' ];
        }

        return $results;
    }

    /**
     * Export a shell script to help migrate GoodService tables to external MySQL.
     * Admin downloads this and runs it on their local machine / Nestify SSH.
     */
    public static function export_migration_script(): string {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $tables = $wpdb->get_col(
            "SELECT table_name FROM information_schema.tables
             WHERE table_schema = DATABASE() AND table_name LIKE '{$pfx}%'"
        );

        $ext_host   = Config::get( 'infra_mysql_host', 'YOUR_NEW_HOST' );
        $ext_port   = Config::get( 'infra_mysql_port', '3306' );
        $ext_user   = Config::get( 'infra_mysql_user', 'YOUR_USER' );
        $ext_db     = Config::get( 'infra_mysql_dbname', 'YOUR_DATABASE' );
        $table_list = implode( ' ', $tables );

        $lines = [
            "#!/bin/bash",
            "# GoodService database migration script — generated " . date( 'Y-m-d H:i:s' ),
            "# SSH into your Nestify server and run this script.",
            "",
            "# Step 1: Export GoodService tables from current Nestify database",
            "mysqldump -h " . escapeshellarg($wpdb->dbhost) . " \\",
            "  -u " . escapeshellarg($wpdb->dbuser) . " \\",
            "  -p" . $wpdb->dbpassword . " \\",
            "  " . $wpdb->dbname . " \\",
            "  " . $table_list . " \\",
            "  --single-transaction --quick > gs_export.sql",
            "",
            "echo Export complete.",
            "",
            "# Step 2: Import into external MySQL",
            "mysql -h " . $ext_host . " -P " . $ext_port . " \\",
            "  -u " . $ext_user . " -p " . $ext_db . " < gs_export.sql",
            "",
            "echo Import complete.",
            "echo Next: Set MySQL mode to active in GoodService Admin > Settings > Infrastructure",
        ];
        return implode( "\n", $lines );
    }
}
