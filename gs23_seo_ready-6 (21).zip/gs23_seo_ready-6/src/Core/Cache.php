<?php
namespace GoodService\Core;

/**
 * Cache — Three-tier cache with automatic Redis/Memcached support.
 *
 * L1 : in-memory PHP static array (zero cost, per-request).
 * L2 : WordPress Object Cache (wp_cache_*) — automatically uses Redis or
 *       Memcached when a persistent object-cache plugin is installed,
 *       otherwise falls back to WP's built-in per-request cache.
 * L2b: WordPress transients — used only when NO persistent object cache is
 *       active, so results survive across PHP requests without Redis.
 *
 * Group flush strategy (the critical fix vs v20/v21):
 *   Old code ran:  DELETE FROM wp_options WHERE option_name LIKE '_transient_gs_c_%'
 *   → Full table scan on wp_options.  Catastrophic at 50 K listings + real traffic.
 *
 *   New code runs: update_option( 'gs_cv_{group}', version + 1 )
 *   → Single primary-key write.  Zero table scan.  Old transients expire by TTL.
 *
 *   Every cache key embeds the current group version counter.  Bumping the counter
 *   makes ALL old entries for that group unreachable instantly — no DELETE needed.
 *
 * Redis setup (recommended for 50 K listings):
 *   1. Install "Redis Object Cache" plugin.
 *   2. Add to wp-config.php:
 *        define( 'WP_REDIS_HOST', '127.0.0.1' );
 *        define( 'WP_CACHE', true );
 *   This class detects Redis automatically via wp_using_ext_object_cache().
 */
final class Cache {

    // ── L1: per-request in-memory store ──────────────────────────────────────
    private static array $l1 = [];

    // ── Group version counters (loaded lazily from wp_options) ───────────────
    private static array $gv = [];

    // ── Cached result of wp_using_ext_object_cache() ─────────────────────────
    private static ?bool $has_obj_cache = null;

    /**
     * FUNC FIX #6: Sentinel value used when caching NULL.
     * Cache::get() and Cache::remember() return null BOTH on cache miss AND when
     * the cached value is null. This sentinel distinguishes the two cases:
     *   - L2 returns false  → cache miss  → run callback
     *   - L2 returns SENTINEL → cached null → return null without re-running callback
     * The sentinel is a string that cannot be a legitimate cached value.
     */
    private const NULL_SENTINEL = '__GS_CACHED_NULL__';


    // =========================================================================
    // Public API  (identical signatures to v20/v21 — fully backward compatible)
    // =========================================================================

    /**
     * Return a cached value, or compute it via $callback and cache the result.
     *
     * @param string   $key      Cache key.  Use "group:subkey" format so group
     *                           flush works (e.g. "listings:featured:8").
     * @param callable $callback Executed only on a cache miss.
     * @param int      $ttl      Seconds. 0 = L1 only (no cross-request persist).
     */
    public static function remember( string $key, callable $callback, int $ttl = 300 ): mixed {
        if ( array_key_exists( $key, self::$l1 ) ) {
            return self::$l1[ $key ];             // L1 hit — zero cost
        }
        $v = self::l2_get( $key );
        if ( $v !== false ) {
            // FUNC FIX #6: Convert sentinel back to null before returning
            $result = ( $v === self::NULL_SENTINEL ) ? null : $v;
            self::$l1[ $key ] = $result;
            return $result;                        // L2 hit
        }
        // Cache miss — compute, store everywhere
        $v = $callback();
        self::$l1[ $key ] = $v;
        if ( $ttl > 0 ) {
            // FUNC FIX #6: Store sentinel instead of null so future hits are
            // distinguishable from misses (l2_get returns false on miss, not null)
            self::l2_set( $key, ( $v === null ) ? self::NULL_SENTINEL : $v, $ttl );
        }
        return $v;
    }

    /** Read from cache.  Returns null on miss (allows caching boolean false). */
    public static function get( string $key ): mixed {
        if ( array_key_exists( $key, self::$l1 ) ) {
            return self::$l1[ $key ];
        }
        $v = self::l2_get( $key );
        if ( $v !== false ) {
            // FUNC FIX #6: Convert sentinel back to null
            $result = ( $v === self::NULL_SENTINEL ) ? null : $v;
            self::$l1[ $key ] = $result;
            return $result;
        }
        return null;
    }

    /** Write to both cache levels. */
    public static function set( string $key, mixed $value, int $ttl = 300 ): void {
        self::$l1[ $key ] = $value;
        if ( $ttl > 0 ) {
            // FUNC FIX #6: Store sentinel for null values
            self::l2_set( $key, ( $value === null ) ? self::NULL_SENTINEL : $value, $ttl );
        }
    }

    /** Delete a single key from all cache levels. */
    public static function delete( string $key ): void {
        unset( self::$l1[ $key ] );
        self::l2_del( $key );
    }

    /**
     * Flush all cache entries whose key starts with $prefix.
     * Pass an empty string to flush ALL GoodService cache entries.
     *
     * Performance: this is now a single update_option() call regardless of
     * how many cached entries exist.  No DELETE, no LIKE, no table scan.
     */
    public static function flush_group( string $prefix = '' ): void {
        $g = $prefix ?: 'gs';
        // The paired singular group (see the real-fix comment below) needs
        // its own L1 keys cleared too, in the same call — otherwise a
        // read-after-flush within the SAME request (e.g. an admin preview
        // rendered right after a save) would still hit the stale L1 entry
        // even though the underlying L2 version was correctly bumped.
        $l1_prefixes = $g === 'listings' ? [ $prefix, 'listing' ] : [ $prefix ];
        foreach ( array_keys( self::$l1 ) as $k ) {
            foreach ( $l1_prefixes as $l1p ) {
                if ( ! $l1p || str_starts_with( $k, $l1p ) ) {
                    unset( self::$l1[ $k ] );
                    break;
                }
            }
        }

        self::bump_group_version( $g );

        // Real fix, found while tracing an "Image Fit setting doesn't
        // change on the live page" report: group() extracts everything
        // BEFORE THE FIRST COLON as the group name — "listing:slug:foo"
        // belongs to group "listing" (singular), while
        // "listings:featured:8" belongs to group "listings" (plural).
        // Every call site across this plugin calls
        // flush_group('listings') (plural) after a listing save,
        // several with a comment explicitly claiming "this is what
        // actually invalidates listing:slug:*" — but plural "listings"
        // and singular "listing" are two entirely separate group
        // version counters, so that call never touched the single
        // listing's own detail-page cache at all. It happened to cause
        // no visible bug because every save handler ALSO calls the
        // exact-key Cache::delete("listing:slug:{$slug}") directly —
        // but any future save path that relies on flush_group('listings')
        // alone, without that direct delete, would silently serve a
        // stale single-listing page for up to the cache's TTL. Fixed at
        // the one shared source rather than at each of the dozens of
        // call sites: flushing the plural collection group now also
        // flushes the singular detail group, matching what every one of
        // those call sites' own comments already say it does.
        if ( $g === 'listings' ) {
            self::bump_group_version( 'listing' );
        }
    }

    /** Shared by flush_group() for both the requested group and, where
     * applicable, its paired singular/plural group — see flush_group(). */
    private static function bump_group_version( string $g ): void {
        $new_ver        = self::group_version( $g ) + 1;
        self::$gv[ $g ] = $new_ver;
        update_option( 'gs_cv_' . $g, $new_ver, false ); // false = not autoloaded

        // If Redis/Memcached is active and the drop-in supports group flush,
        // also evict from the external store to free memory immediately.
        if ( self::using_obj_cache() && function_exists( 'wp_cache_flush_group' ) ) {
            wp_cache_flush_group( 'gs_' . $g );
        }
    }


    // =========================================================================
    // Internal helpers
    // =========================================================================

    /** Returns true when a persistent object cache (Redis / Memcached) is wired up. */
    private static function using_obj_cache(): bool {
        if ( self::$has_obj_cache === null ) {
            self::$has_obj_cache = function_exists( 'wp_using_ext_object_cache' )
                                    && wp_using_ext_object_cache();
        }
        return self::$has_obj_cache;
    }

    /**
     * Extract the group name from a cache key.
     * "listings:featured:8" → "listings"
     * "listing:slug:foo"    → "listing"
     * "plain-key"           → "gs"
     */
    private static function group( string $key ): string {
        $pos = strpos( $key, ':' );
        return $pos !== false ? substr( $key, 0, $pos ) : 'gs';
    }

    /**
     * Get the current version integer for a group.
     * Loaded from wp_options once per request via WP's own option cache (free).
     */
    private static function group_version( string $g ): int {
        if ( ! isset( self::$gv[ $g ] ) ) {
            self::$gv[ $g ] = (int) get_option( 'gs_cv_' . $g, 1 );
        }
        return self::$gv[ $g ];
    }

    /**
     * Build the versioned L2 storage key.
     * Format: "v{version}:{md5(original_key)}"
     * Changing the version makes previously stored entries unreachable.
     */
    private static function l2_key( string $key ): string {
        return 'v' . self::group_version( self::group( $key ) ) . ':' . md5( $key );
    }

    /** Read from L2 (object cache or transient). Returns false on miss. */
    private static function l2_get( string $key ): mixed {
        $l2k   = self::l2_key( $key );
        $group = 'gs_' . self::group( $key );

        if ( self::using_obj_cache() ) {
            $found = false;
            $v     = wp_cache_get( $l2k, $group, false, $found );
            return $found ? $v : false;
        }

        // Transient fallback — prefix "gsc" keeps keys under 172-char WP limit
        return get_transient( 'gsc' . $l2k );
    }

    /** Write to L2. */
    private static function l2_set( string $key, mixed $value, int $ttl ): void {
        $l2k   = self::l2_key( $key );
        $group = 'gs_' . self::group( $key );

        if ( self::using_obj_cache() ) {
            wp_cache_set( $l2k, $value, $group, $ttl );
        } else {
            set_transient( 'gsc' . $l2k, $value, $ttl );
        }
    }

    /** Delete from L2. */
    private static function l2_del( string $key ): void {
        $l2k   = self::l2_key( $key );
        $group = 'gs_' . self::group( $key );

        if ( self::using_obj_cache() ) {
            wp_cache_delete( $l2k, $group );
        } else {
            delete_transient( 'gsc' . $l2k );
        }
    }
}
