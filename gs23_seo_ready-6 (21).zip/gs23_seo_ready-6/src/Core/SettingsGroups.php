<?php
namespace GoodService\Core;

/**
 * ENTERPRISE-AUDIT FIX (Part 2, Critical + High: "No admin RBAC / granular
 * roles" and "Settings page is one 15-group monolith with only a client-side
 * diff, not true per-group save/permissioning").
 *
 * Before this fix, the group→field-keys mapping used to RENDER the Settings
 * page (admin-dashboard.php's local $setting_groups array) had no
 * server-side counterpart at all — the actual save handler
 * (AjaxController::adminSavePlatformSettings()) accepted any key→value map
 * and wrote every field through one single hardcoded group ('platform'),
 * with zero awareness of which visual group a key belonged to. That made
 * true per-group permissioning structurally impossible: there was nothing
 * on the server to check a submitted key AGAINST.
 *
 * This class is now the ONE canonical definition of "which settings group
 * does this key belong to" — the template reads GROUPS to render the page
 * (identical content to before, just no longer a second hand-maintained
 * copy), and the AJAX save handler reads group_of()/can_save_group() to
 * actually enforce per-tier save permission before writing anything.
 */
final class SettingsGroups {

    /**
     * Canonical group → field-keys map. MUST stay content-identical to what
     * was previously hardcoded in templates/pages/admin-dashboard.php's
     * `case 'settings':` block — copied verbatim, not re-derived, so the
     * rendered page is byte-for-byte unchanged.
     */
    public const GROUPS = [
        'Homepage Hero' => [
            'homepage_hero_bg_color','homepage_hero_bg_image','homepage_hero_bg_video',
            'homepage_hero_overlay_opacity','homepage_hero_overlay_color',
            'homepage_hero_heading','homepage_hero_subheading',
            'homepage_hero_layout',
            'homepage_hero_text_align',
            'homepage_hero_min_height',
            'homepage_hero_padding_top','homepage_hero_padding_bottom',
            'homepage_hero_cta1_text','homepage_hero_cta1_link','homepage_hero_cta1_bg','homepage_hero_cta1_color',
            'homepage_hero_cta2_text','homepage_hero_cta2_link','homepage_hero_cta2_bg','homepage_hero_cta2_color',
            'homepage_hero_show_trust_bar','homepage_hero_trust_bar_text','homepage_hero_trust_bar_speed',
            'homepage_hero_show_search','homepage_hero_heading_size','homepage_hero_heading_color',
            'homepage_hero_sub_color','homepage_hero_sub_size',
        ],
        'General' => ['platform_name','platform_tagline','platform_email','platform_phone','platform_address','logo_url','platform_favicon_url','platform_facebook','platform_instagram','platform_linkedin','platform_twitter'],
        'Appearance' => ['platform_color_primary','platform_color_secondary','platform_color_accent','slider_height_desktop','slider_height_mobile'],
        'Listings' => ['listings_per_page','auto_approve_listings','require_login_to_lead','lead_rate_limit','featured_on_home','show_sponsored_on_home','sponsored_count','sponsored_columns','sponsored_rows','sponsored_padding_y','sponsored_full_width','sponsored_card_min_width','sponsored_mobile_columns'],
        'Features' => ['booking_enabled','reverse_req_enabled','complaints_enabled','messaging_enabled','ai_assist_enabled','trust_score_enabled','booking_otp_enabled'],
        'Payment — Razorpay' => ['razorpay_enabled','razorpay_key_id','razorpay_key_secret','razorpay_webhook_secret'],
        'Payment — Stripe' => ['stripe_enabled','stripe_public_key','stripe_secret_key','stripe_webhook_secret'],
        'Invoice & Billing Settings' => ['company_name','invoice_logo_url','company_address','platform_gstin','platform_pan','company_cin','company_phone','company_email','company_website','invoice_prefix','tax_label','gst_rate','currency','currency_symbol','invoice_terms','invoice_payment_notes','invoice_footer_note'],
        'AI — Anthropic' => ['gs_anthropic_api_key','ai_assist_enabled'],
        'WhatsApp Business API (optional)' => ['whatsapp_api_key','whatsapp_bsp','whatsapp_meta_phone_number_id','whatsapp_enabled','whatsapp_verify_enabled','whatsapp_webhook_verify_token','client_dashboard_whatsapp_verify_enabled'],
        'WhatsApp Business' => ['whatsapp_business_token'],
        'SMS / OTP (India)' => ['sms_provider','sms_api_key','sms_sender','msg91_template_id','otp_resend_cooldown_seconds'],
        'Email / SMTP' => ['smtp_host','smtp_port','smtp_username','smtp_password','smtp_from_name','smtp_from_email'],
        'Google' => ['google_maps_api'],
        'Homepage Popup' => ['promo_popup_enabled','promo_popup_image','promo_popup_frequency'],
        'Inquiry Form — Global Design Defaults' => [
            'inq_global_heading_color','inq_global_body_color',
            'inq_global_input_bg','inq_global_input_border','inq_global_input_text',
            'inq_global_btn_bg','inq_global_btn_text','inq_global_label_color',
            'inq_global_form_shadow','inq_global_form_radius','inq_global_btn_radius',
            'inq_global_sec_pt','inq_global_sec_pb',
            'inq_global_font_family',
            'inq_global_input_font_size','inq_global_input_font_weight',
            'inq_global_btn_font_size','inq_global_btn_font_weight',
            'inq_global_help_font_size','inq_global_help_color','inq_global_help_font_weight',
            'inq_global_desc_color','inq_global_desc_font_size','inq_global_desc_font_weight',
            'inq_global_placeholder_color','inq_global_placeholder_font_size','inq_global_placeholder_font_weight',
        ],
    ];

    /**
     * Which groups a 'billing_admin' tier may save. Deliberately narrow to
     * the groups that are actually billing/payment-related — a billing-only
     * admin should never be able to touch AI keys, SMTP credentials, or any
     * other unrelated group, which is the exact scenario the audit finding
     * called out by name. full_admin (the default/unrestricted tier) always
     * passes regardless of this list — see Roles::can_save_settings_group().
     */
    public const BILLING_ADMIN_GROUPS = [
        'Payment — Razorpay',
        'Payment — Stripe',
        'Invoice & Billing Settings',
    ];

    /** Reverse lookup cache: field key => group name. */
    private static ?array $key_to_group = null;

    /**
     * Returns the settings-group name a given field key belongs to, or null
     * if the key isn't part of any known group (e.g. a dynamically-added
     * field not yet catalogued here — treated permissively as ungrouped,
     * see Roles::can_save_settings_group()'s docblock for why that's the
     * safe direction for an unknown key rather than blocking it outright).
     */
    public static function group_of( string $key ): ?string {
        if ( self::$key_to_group === null ) {
            self::$key_to_group = [];
            foreach ( self::GROUPS as $group => $keys ) {
                foreach ( $keys as $k ) {
                    self::$key_to_group[ $k ] = $group;
                }
            }
        }
        return self::$key_to_group[ $key ] ?? null;
    }
}
