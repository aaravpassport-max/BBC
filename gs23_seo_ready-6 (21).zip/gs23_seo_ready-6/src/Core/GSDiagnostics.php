<?php
namespace GoodService\Core;

/**
 * GSDiagnostics — Deep diagnostic and trace logger for GoodService Platform.
 *
 * INSTALLATION: This file is auto-loaded by the plugin's PSR-4 autoloader.
 * All diagnostic data is written to wp-content/gs-diag.log (separate from gs-debug.log).
 *
 * HOW TO USE:
 *   - Open wp-content/gs-diag.log to see every save/upload trace.
 *   - Visit /admin-panel/?section=diagnostics to see a live dashboard.
 *   - Add define('GS_DIAG', true); to wp-config.php to enable always.
 *   - Or use the toggle in Admin → Tools → Diagnostics.
 *
 * DISABLE IN PRODUCTION: set define('GS_DIAG', false); in wp-config.php
 */
final class GSDiagnostics {

    const LOG_FILE    = WP_CONTENT_DIR . '/gs-diag.log';
    const OPTION_KEY  = 'gs_diag_enabled';
    const MAX_BYTES   = 2 * 1024 * 1024; // 2 MB — rotate after this

    /** Is diagnostic mode on? */
    public static function enabled(): bool {
        if ( defined( 'GS_DIAG' ) ) return (bool) GS_DIAG;
        return (bool) get_option( self::OPTION_KEY, false );
    }

    /** Write a trace line */
    public static function log( string $context, string $msg, array $data = [], string $level = 'TRACE' ): void {
        if ( ! self::enabled() ) return;
        self::rotate_if_needed();
        $uid   = is_user_logged_in() ? get_current_user_id() : 0;
        $roles = $uid ? implode( ',', (array)( wp_get_current_user()->roles ?? [] ) ) : 'guest';
        $line  = sprintf(
            "[%s][%s][%s][uid:%d|%s] %s%s\n",
            date( 'Y-m-d H:i:s' ),
            $level,
            $context,
            $uid,
            $roles,
            $msg,
            $data ? ' | ' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) : ''
        );
        @file_put_contents( self::LOG_FILE, $line, FILE_APPEND | LOCK_EX );
    }

    public static function error( string $context, string $msg, array $data = [] ): void {
        self::log( $context, $msg, $data, 'ERROR' );
    }

    public static function warn( string $context, string $msg, array $data = [] ): void {
        self::log( $context, $msg, $data, 'WARN' );
    }

    public static function info( string $context, string $msg, array $data = [] ): void {
        self::log( $context, $msg, $data, 'INFO' );
    }

    /** Rotate log if it exceeds MAX_BYTES */
    private static function rotate_if_needed(): void {
        if ( file_exists( self::LOG_FILE ) && filesize( self::LOG_FILE ) > self::MAX_BYTES ) {
            @rename( self::LOG_FILE, self::LOG_FILE . '.old' );
        }
    }

    /** Read last N lines of log */
    public static function tail( int $lines = 200 ): string {
        if ( ! file_exists( self::LOG_FILE ) ) return '';
        $all = file( self::LOG_FILE );
        if ( ! $all ) return '';
        return implode( '', array_slice( $all, -$lines ) );
    }

    /** Clear log */
    public static function clear(): void {
        @file_put_contents( self::LOG_FILE, '' );
    }

    /**
     * Validate that all required columns exist in a table.
     * Returns an array of MISSING column names (empty = all good).
     */
    public static function check_columns( string $table, array $required_cols ): array {
        global $wpdb;
        $existing = $wpdb->get_col( "SHOW COLUMNS FROM `{$table}`", 0 );
        if ( ! $existing ) return $required_cols; // table missing — all "missing"
        return array_values( array_diff( $required_cols, $existing ) );
    }

    /**
     * Full pre-save diagnostic check.
     * Returns an array of problems (empty = all OK).
     */
    public static function pre_save_listing_check( array $data ): array {
        global $wpdb;
        $table    = $wpdb->prefix . 'gs_listings';
        $problems = [];

        // 1. Check table exists
        $exists = $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" );
        if ( ! $exists ) {
            $problems[] = "Table `{$table}` does not exist. Run DB install from Admin → Tools.";
            return $problems; // can't check columns on missing table
        }

        // 2. Check for missing columns that the code tries to write
        $required = [
            'hero_data', 'about_data', 'items_data', 'feedback_data', 'footer_data',
            'customizer_data', 'mobile_data', 'opening_hours',
            'trust_bar_text', 'gallery_title',
            'services_section_title', 'services_section_desc', 'process_section_title',
            'brand_color', 'brand_color2', 'accent_color', 'section_bg',
            'text_color', 'muted_color', 'logo_border_c', 'logo_bg',
            'banner_overlay', 'logo_radius', 'logo_shadow', 'logo_border_w',
            'logo_padding', 'banner_height', 'banner_radius', 'banner_opacity',
            'seo_title', 'seo_desc', 'map_embed', 'address',
        ];
        $missing = self::check_columns( $table, $required );
        if ( $missing ) {
            $problems[] = 'MISSING DB COLUMNS (run Admin → Tools → DB Upgrade): ' . implode( ', ', $missing );
        }

        // 3. Check PHP limits
        $post_max   = self::parse_bytes( ini_get( 'post_max_size' ) );
        $upload_max = self::parse_bytes( ini_get( 'upload_max_filesize' ) );
        if ( $post_max < 5 * 1024 * 1024 ) {
            $problems[] = "PHP post_max_size is only " . ini_get( 'post_max_size' ) . " — form data may be truncated. Set to at least 32M.";
        }
        if ( $upload_max < 5 * 1024 * 1024 ) {
            $problems[] = "PHP upload_max_filesize is only " . ini_get( 'upload_max_filesize' ) . " — file uploads will fail. Set to at least 10M.";
        }

        $input_vars = (int) ini_get( 'max_input_vars' );
        if ( $input_vars && $input_vars < 500 ) {
            $problems[] = "PHP max_input_vars is only {$input_vars} — form fields may be silently truncated. Set to at least 1000.";
        }

        // 4. Check WP uploads dir is writable
        $upload_dir = wp_upload_dir();
        if ( ! empty( $upload_dir['error'] ) ) {
            $problems[] = 'WordPress uploads directory error: ' . $upload_dir['error'];
        }

        // 5. Check JSON fields are valid JSON — and log actual (truncated) value for diagnosis
        $json_keys = [ 'gallery', 'services_data', 'items_data', 'faq_data', 'why_choose_data',
                       'process_data', 'stats_data', 'hero_data', 'customizer_data', 'mobile_data',
                       'about_data', 'items_data', 'feedback_data', 'footer_data', 'opening_hours' ];
        foreach ( $json_keys as $key ) {
            if ( ! isset( $data[ $key ] ) || $data[ $key ] === '' || $data[ $key ] === null ) {
                continue; // empty is fine — will be saved as empty/null
            }
            if ( ! is_string( $data[ $key ] ) ) {
                $problems[] = "Field `{$key}` is " . gettype( $data[$key] ) . " (expected string/JSON). Will be auto-encoded.";
                continue;
            }
            json_decode( $data[ $key ] );
            if ( json_last_error() !== JSON_ERROR_NONE ) {
                // Log the ACTUAL value (first 300 chars) so the corruption is visible
                $raw_preview = substr( $data[ $key ], 0, 300 );
                // Check if it looks like WordPress magic-quotes corrupted it
                $unslashed = wp_unslash( $data[ $key ] );
                json_decode( $unslashed );
                $fixable = ( json_last_error() === JSON_ERROR_NONE );
                $hint = $fixable
                    ? ' ⚑ CAUSE: WordPress magic_quotes/addslashes corrupted this JSON. Fix: add wp_unslash() when reading $_POST.'
                    : ' Raw value (first 300 chars): ' . $raw_preview;
                $problems[] = "Invalid JSON in field `{$key}`: " . json_last_error_msg() . '.' . $hint;
            }
        }

        return $problems;
    }

    /** Parse PHP ini size strings like "32M", "1G" */
    private static function parse_bytes( string $val ): int {
        $val  = trim( $val );
        $last = strtolower( $val[ strlen( $val ) - 1 ] );
        $num  = (int) $val;
        return match ( $last ) {
            'g' => $num * 1073741824,
            'm' => $num * 1048576,
            'k' => $num * 1024,
            default => $num,
        };
    }

    /**
     * Render diagnostics HTML panel (called from admin dashboard).
     */
    public static function render_panel(): void {
        global $wpdb;
        $table    = $wpdb->prefix . 'gs_listings';
        $problems = self::pre_save_listing_check( [] );
        $log_tail = self::tail( 300 );
        $enabled  = self::enabled();
        $nonce    = wp_create_nonce( 'gs_diag_toggle' );
        ?>
        <div style="font-family:monospace;padding:24px;max-width:1100px">
            <h2 style="font-family:sans-serif;margin:0 0 16px">🔬 GoodService Diagnostics</h2>

            <!-- Toggle -->
            <div style="background:#F1F5F9;border:1px solid #CBD5E1;border-radius:8px;padding:14px;margin-bottom:20px;display:flex;align-items:center;gap:16px">
                <span style="font-family:sans-serif;font-weight:600">Diagnostic Logging:</span>
                <span style="background:<?php echo $enabled ? '#DCFCE7' : '#FEE2E2'; ?>;color:<?php echo $enabled ? '#166534' : '#991B1B'; ?>;padding:4px 12px;border-radius:20px;font-size:.82rem;font-weight:700">
                    <?php echo $enabled ? '🟢 ENABLED' : '🔴 DISABLED'; ?>
                </span>
                <form method="post" style="margin:0">
                    <?php wp_nonce_field( 'gs_diag_toggle', 'gs_diag_nonce' ); ?>
                    <input type="hidden" name="gs_diag_action" value="<?php echo $enabled ? 'disable' : 'enable'; ?>">
                    <button type="submit" style="background:<?php echo $enabled ? '#DC2626' : '#2563EB'; ?>;color:#fff;border:none;padding:6px 14px;border-radius:6px;cursor:pointer;font-size:.82rem">
                        <?php echo $enabled ? 'Disable Logging' : 'Enable Logging'; ?>
                    </button>
                </form>
                <?php if ( $enabled ): ?>
                <form method="post" style="margin:0">
                    <?php wp_nonce_field( 'gs_diag_toggle', 'gs_diag_nonce' ); ?>
                    <input type="hidden" name="gs_diag_action" value="clear">
                    <button type="submit" style="background:#64748B;color:#fff;border:none;padding:6px 14px;border-radius:6px;cursor:pointer;font-size:.82rem">🗑 Clear Log</button>
                </form>
                <?php endif; ?>
            </div>

            <!-- System checks -->
            <h3 style="font-family:sans-serif;margin:0 0 10px">⚙️ System Check</h3>
            <?php if ( empty( $problems ) ): ?>
                <div style="background:#DCFCE7;border:1px solid #86EFAC;border-radius:8px;padding:12px;margin-bottom:20px;color:#166534;font-family:sans-serif">
                    ✅ All system checks passed — DB columns, PHP limits, and upload directory look good.
                </div>
            <?php else: ?>
                <div style="background:#FEF2F2;border:1px solid #FECACA;border-radius:8px;padding:14px;margin-bottom:20px">
                    <?php foreach ( $problems as $p ): ?>
                        <div style="color:#991B1B;font-size:.85rem;margin-bottom:6px">🚨 <?php echo esc_html( $p ); ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <!-- PHP info -->
            <h3 style="font-family:sans-serif;margin:0 0 10px">🐘 PHP Environment</h3>
            <table style="width:100%;border-collapse:collapse;margin-bottom:20px;font-size:.84rem">
                <?php
                $checks = [
                    'PHP Version'             => PHP_VERSION,
                    'post_max_size'           => ini_get( 'post_max_size' ),
                    'upload_max_filesize'     => ini_get( 'upload_max_filesize' ),
                    'max_input_vars'          => ini_get( 'max_input_vars' ),
                    'memory_limit'            => ini_get( 'memory_limit' ),
                    'max_execution_time'      => ini_get( 'max_execution_time' ) . 's',
                    'WP Upload Dir'           => wp_upload_dir()['basedir'],
                    'WP Upload Writable'      => is_writable( wp_upload_dir()['basedir'] ) ? '✅ Yes' : '❌ No',
                    'WP Debug'                => defined('WP_DEBUG') && WP_DEBUG ? '🟡 Enabled' : '✅ Disabled',
                    'GS_DIAG constant'        => defined('GS_DIAG') ? ( GS_DIAG ? 'true (forced on)' : 'false (forced off)' ) : 'not set (uses DB option)',
                    'Listings table'          => $wpdb->get_var("SHOW TABLES LIKE '{$table}'") ? '✅ Exists' : '❌ MISSING',
                ];
                foreach ( $checks as $k => $v ):
                ?>
                <tr style="border-bottom:1px solid #E2E8F0">
                    <td style="padding:6px 10px;font-weight:600;width:220px"><?php echo esc_html( $k ); ?></td>
                    <td style="padding:6px 10px;color:#334155"><?php echo esc_html( $v ); ?></td>
                </tr>
                <?php endforeach; ?>
            </table>

            <!-- DB Columns Check -->
            <h3 style="font-family:sans-serif;margin:0 0 10px">🗄️ DB Column Audit — gs_listings</h3>
            <?php
            $all_cols = $wpdb->get_col( "SHOW COLUMNS FROM `{$table}`", 0 ) ?: [];
            $expected = [
                // Base columns
                'id','vendor_id','listing_type','title','slug','tagline','short_desc','full_desc',
                'category_id','subcategory_id','tags','price_min','price_max','price_unit',
                'city','state','pincode','service_cities','phone','whatsapp','email','website',
                'banner_url','logo_url','gallery','video_url','services_data','products_data',
                'process_data','faq_data','why_choose_data','stats_data','highlights',
                'certifications','awards','established_year','team_size','opening_hours',
                'layout_id','form_data','status','is_featured','views_count','leads_count',
                'avg_rating','review_count','created_at','updated_at',
                // Migration columns
                'hero_data','about_data','items_data','feedback_data','footer_data',
                'customizer_data','mobile_data','trust_bar_text','gallery_title',
                'services_section_title','services_section_desc','process_section_title',
                'brand_color','brand_color2','accent_color','section_bg','text_color',
                'muted_color','logo_border_c','logo_bg','banner_overlay','logo_radius',
                'logo_shadow','logo_border_w','logo_padding','logo_padding',
                'banner_height','banner_radius','banner_opacity','seo_title','seo_desc',
                'map_embed','address',
            ];
            ?>
            <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:20px">
                <?php foreach ( array_unique($expected) as $col ):
                    $present = in_array( $col, $all_cols );
                ?>
                <span style="font-size:.72rem;padding:3px 8px;border-radius:4px;background:<?php echo $present ? '#DCFCE7' : '#FEE2E2'; ?>;color:<?php echo $present ? '#166534' : '#991B1B'; ?>">
                    <?php echo $present ? '✅' : '❌'; ?> <?php echo esc_html( $col ); ?>
                </span>
                <?php endforeach; ?>
            </div>

            <!-- Log viewer -->
            <h3 style="font-family:sans-serif;margin:0 0 10px">📋 Diagnostic Log (last 300 lines)</h3>
            <?php if ( $log_tail ): ?>
            <pre style="background:#0F172A;color:#E2E8F0;padding:16px;border-radius:8px;font-size:.72rem;line-height:1.6;overflow:auto;max-height:600px;white-space:pre-wrap;word-break:break-all"><?php
                // Colour-code log lines
                foreach ( array_slice( file( self::LOG_FILE ) ?: [], -300 ) as $line ) {
                    $esc = esc_html( rtrim( $line ) );
                    if ( str_contains( $line, '][ERROR]' ) ) {
                        echo '<span style="color:#F87171">' . $esc . '</span>' . "\n";
                    } elseif ( str_contains( $line, '][WARN]' ) ) {
                        echo '<span style="color:#FBBF24">' . $esc . '</span>' . "\n";
                    } elseif ( str_contains( $line, '][INFO]' ) ) {
                        echo '<span style="color:#60A5FA">' . $esc . '</span>' . "\n";
                    } else {
                        echo $esc . "\n";
                    }
                }
            ?></pre>
            <?php else: ?>
                <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:24px;text-align:center;color:#64748B;font-family:sans-serif">
                    <?php echo $enabled ? 'Log is empty — trigger some actions to see traces.' : 'Enable diagnostic logging first, then reproduce the issue.'; ?>
                </div>
            <?php endif; ?>

            <p style="font-family:sans-serif;color:#94A3B8;font-size:.8rem;margin-top:16px">
                Log file: <code><?php echo esc_html( str_replace( ABSPATH, '', self::LOG_FILE ) ); ?></code>
                &nbsp;<span style="opacity:.6">(relative to WordPress root)</span>
            </p>
        </div>
        <?php
    }

    /** Handle POST actions from the panel */
    public static function handle_panel_post(): void {
        if ( ! isset( $_POST['gs_diag_action'] ) ) return;
        if ( ! wp_verify_nonce( sanitize_text_field( $_POST['gs_diag_nonce'] ?? '' ), 'gs_diag_toggle' ) ) return;
        if ( ! current_user_can( 'manage_options' ) ) return;

        $action = sanitize_text_field( $_POST['gs_diag_action'] );
        if ( $action === 'enable'  ) update_option( self::OPTION_KEY, 1 );
        if ( $action === 'disable' ) update_option( self::OPTION_KEY, 0 );
        if ( $action === 'clear'   ) self::clear();
    }
}
