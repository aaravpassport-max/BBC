<?php
namespace GoodService\Core;

/**
 * Config — Central configuration manager.
 * Single DB read per request; all settings in memory thereafter.
 * Supports group-based bulk retrieval and environment overrides.
 *
 * H12 FIX: Sensitive API keys (Razorpay, WhatsApp, Anthropic, SMS) are
 * encrypted at rest using AES-256-CBC with WordPress AUTH_KEY as the secret.
 * Encryption is transparent — set() encrypts, get() decrypts automatically.
 * If AUTH_KEY changes, encrypted values must be re-saved from the admin settings UI.
 */
final class Config {

    private static array $store  = [];
    private static bool  $booted = false;

    /**
     * Keys that contain sensitive credentials — stored encrypted in DB.
     *
     * ENTERPRISE-AUDIT FIX (root cause of a Critical finding): this list had
     * drifted out of sync with the keys the Settings UI (admin-dashboard.php
     * $sensitive_keys) actually masks/stores — several live payment and
     * webhook secrets (Stripe, Razorpay webhook, WhatsApp) were being saved
     * in PLAINTEXT despite the docblock above claiming encryption-at-rest.
     * This is now the single canonical list; the Settings UI reads it via
     * Config::is_sensitive_key() instead of keeping its own copy, so the two
     * can never drift apart again.
     */
    private const SENSITIVE_KEYS = [
        'razorpay_key_id',   'razorpay_key_secret',   'razorpay_webhook_secret',
        'stripe_secret_key', 'stripe_webhook_secret',
        'whatsapp_api_key',  'whatsapp_access_token', 'whatsapp_webhook_verify_token',
        'whatsapp_business_token',
        'anthropic_api_key', 'anthropic_key',         'gs_anthropic_api_key',
        'openai_api_key',
        'sms_api_key',       'sms_api_secret',
        'smtp_password',     'platform_api_key',
    ];

    /** True if $key must be encrypted at rest / masked in the admin UI. Single source of truth — see SENSITIVE_KEYS docblock. */
    public static function is_sensitive_key( string $key ): bool {
        return in_array( $key, self::SENSITIVE_KEYS, true );
    }

    /** Full sensitive-key list, for UI code that needs an array (e.g. in_array() over a rendered field list) rather than a per-key check. Same single source of truth as is_sensitive_key(). */
    public static function get_sensitive_keys(): array {
        return self::SENSITIVE_KEYS;
    }

    /**
     * Re-encrypts any SENSITIVE_KEYS row currently stored in plaintext.
     * Safe to call repeatedly (idempotent) — rows already encrypted (gsenc: prefix)
     * are left untouched. Run once on upgrade via check_db_version() so any
     * key that was previously saved before this fix (or before a key was added
     * to SENSITIVE_KEYS) gets encrypted without the admin having to re-type it.
     */
    public static function reencrypt_plaintext_sensitive_values(): int {
        global $wpdb;
        $table = $wpdb->prefix . 'gs_settings';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) ) {
            return 0;
        }
        $fixed = 0;
        foreach ( self::SENSITIVE_KEYS as $key ) {
            $row = $wpdb->get_row( $wpdb->prepare( "SELECT id, setting_value FROM {$table} WHERE setting_key=%s LIMIT 1", $key ) );
            if ( ! $row || $row->setting_value === '' || $row->setting_value === null ) {
                continue;
            }
            if ( strpos( (string) $row->setting_value, self::ENC_PREFIX ) === 0 ) {
                continue; // already encrypted
            }
            $encrypted = self::encrypt( (string) $row->setting_value );
            $wpdb->update( $table, [ 'setting_value' => $encrypted ], [ 'id' => $row->id ] );
            $fixed++;
        }
        if ( $fixed > 0 ) {
            \GoodService\Core\Cache::flush_group( 'config' );
        }
        return $fixed;
    }

    /** Prefix used to identify encrypted values in DB */
    private const ENC_PREFIX = 'gsenc:';

    /** Called once by Plugin::boot(). Loads all settings into memory. */
    public static function load(): void {
        if ( self::$booted ) { return; }
        global $wpdb;
        $table = $wpdb->prefix . 'gs_settings';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) ) {
            self::$booted = true;
            return;
        }

        // L13 FIX: Use WordPress object cache (L2) so Redis/Memcached installs
        // avoid a full DB table scan on every PHP request.
        // Cache stores encrypted blobs for sensitive keys — never plaintext.
        $cache_key   = 'gs_config_all_v1';
        $cache_group = 'gs_config';
        $cached      = wp_cache_get( $cache_key, $cache_group );

        if ( $cached && is_array( $cached ) ) {
            // Decrypt sensitive values from cache on the way in
            foreach ( $cached as $k => $v ) {
                self::$store[ $k ] = in_array( $k, self::SENSITIVE_KEYS, true )
                    ? self::decrypt( (string) $v )
                    : $v;
            }
            self::$booted = true;
            return;
        }

        $rows       = $wpdb->get_results( "SELECT setting_key, setting_value FROM {$table}" );
        $to_cache   = [];
        foreach ( $rows as $row ) {
            // Memory store always holds plaintext; cache stores the raw (encrypted) DB value
            $raw_val = $row->setting_value;
            $to_cache[ $row->setting_key ] = $raw_val; // store encrypted blob in object cache
            self::$store[ $row->setting_key ] = in_array( $row->setting_key, self::SENSITIVE_KEYS, true )
                ? self::decrypt( $raw_val )
                : $raw_val;
        }

        // Cache for 5 minutes — short enough to pick up setting changes promptly
        wp_cache_set( $cache_key, $to_cache, $cache_group, 5 * MINUTE_IN_SECONDS );
        self::$booted = true;
    }

    public static function get( string $key, mixed $default = null ): mixed {
        return self::$store[ $key ] ?? $default;
    }

    public static function get_group( string $group ): array {
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT setting_key, setting_value FROM {$wpdb->prefix}gs_settings WHERE setting_group = %s", $group
        ) );
        $result = [];
        foreach ( (array) $rows as $row ) {
            $val = $row->setting_value;
            if ( in_array( $row->setting_key, self::SENSITIVE_KEYS, true ) ) {
                $val = self::decrypt( $val );
            }
            $result[ $row->setting_key ] = $val;
        }
        return $result;
    }

    public static function set( string $key, mixed $value, string $group = 'general' ): void {
        global $wpdb;
        $store_value = (string) $value;
        // Encrypt sensitive keys before writing to DB
        if ( in_array( $key, self::SENSITIVE_KEYS, true ) && $value !== '' ) {
            $store_value = self::encrypt( (string) $value );
        }
        $wpdb->replace( $wpdb->prefix . 'gs_settings', [
            'setting_key'   => $key,
            'setting_value' => $store_value,
            'setting_group' => $group,
        ] );
        self::$store[ $key ] = (string) $value; // memory store always holds plaintext
        // Invalidate the L2 object cache so the next request reads fresh from DB
        wp_cache_delete( 'gs_config_all_v1', 'gs_config' );
    }

    public static function set_bulk( array $data, string $group = 'general' ): void {
        foreach ( $data as $key => $value ) {
            self::set( sanitize_key( $key ), $value, $group );
        }
        \GoodService\Core\Cache::flush_group( 'config' );
    }

    public static function reset(): void {
        self::$store  = [];
        self::$booted = false;
    }

    /** Encrypt a value using AUTH_KEY + AES-256-CBC */
    private static function encrypt( string $plaintext ): string {
        if ( ! function_exists( 'openssl_encrypt' ) ) { return $plaintext; }
        $key    = substr( hash( 'sha256', defined( 'AUTH_KEY' ) ? AUTH_KEY : 'gs_fallback' ), 0, 32 );
        $iv     = random_bytes( 16 );
        $cipher = openssl_encrypt( $plaintext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
        if ( $cipher === false ) { return $plaintext; }
        return self::ENC_PREFIX . base64_encode( $iv . $cipher );
    }

    /** Decrypt a value — returns plaintext, or the original if not encrypted */
    private static function decrypt( string $value ): string {
        if ( ! str_starts_with( $value, self::ENC_PREFIX ) ) { return $value; } // not encrypted
        if ( ! function_exists( 'openssl_decrypt' ) ) { return $value; }
        $encoded = base64_decode( substr( $value, strlen( self::ENC_PREFIX ) ) );
        if ( strlen( $encoded ) < 17 ) { return $value; }
        $key    = substr( hash( 'sha256', defined( 'AUTH_KEY' ) ? AUTH_KEY : 'gs_fallback' ), 0, 32 );
        $iv     = substr( $encoded, 0, 16 );
        $cipher = substr( $encoded, 16 );
        $plain  = openssl_decrypt( $cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
        return $plain !== false ? $plain : $value;
    }
}
