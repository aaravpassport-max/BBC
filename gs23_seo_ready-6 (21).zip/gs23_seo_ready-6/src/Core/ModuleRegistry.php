<?php
namespace GoodService\Core;

/**
 * ⚠️ CRITICAL DEVELOPMENT NOTICE — MANDATORY SECTION ARCHITECTURE ⚠️
 * ════════════════════════════════════════════════════════════════════
 * THIS RULE IS PERMANENT. IT APPLIES TO EVERY SECTION EVER ADDED TO
 * THIS PLUGIN FROM THIS POINT FORWARD — no exceptions, no shortcuts,
 * no "just this once," regardless of who is making the change (a
 * human developer, a different AI, a future version of this same AI
 * with no memory of this conversation, anyone).
 *
 * MANDATORY RULE: a section must NEVER become part of a vendor's
 * listing simply because it exists in this plugin. A brand-new
 * category-specific module that is not one of the small set of
 * regular/common sections (see below) must ALWAYS require the vendor
 * to explicitly select and save it before it appears anywhere in
 * their sidebar, their form, or their public listing page. If it has
 * not been selected and saved, it must remain completely hidden,
 * inactive, and detached — never shown empty, never partially loaded.
 *
 * The required lifecycle for every new category-specific section:
 *   Category Selected → Its Available Sections Shown as Checkboxes →
 *   Vendor Ticks the Ones They Want → Vendor Saves →
 *   ONLY Ticked Sections Become Active → They Appear in the Sidebar/Form
 *
 * There are exactly two kinds of section in this system, and every
 * new one MUST be one of these — never a third, alternative kind:
 *
 *   1. REGULAR / COMMON sections — registered with
 *      'categories' => 'all' and 'default_enabled' => true. These
 *      remain available to every vendor by default, exactly as they
 *      always have. This is the ONLY case where a section may render
 *      without an explicit per-listing opt-in.
 *
 *   2. CATEGORY-SPECIFIC / OPTIONAL sections — registered with a real
 *      categories array (e.g. ['hotels']) and, critically,
 *      'default_enabled' => false. Getting this second value wrong
 *      is the single most likely way to accidentally violate this
 *      whole architecture — it happened once already, in this exact
 *      codebase, and was caught and corrected. register() below now
 *      actively refuses to register a module with a real categories
 *      array and default_enabled=true, specifically so this mistake
 *      cannot happen silently again.
 *
 * Before writing a single line of a new section, verify:
 *   - Is this genuinely regular/common (every category can use it),
 *     or genuinely category-specific (only relevant to some)? Decide
 *     this deliberately — do not default to "regular" for convenience.
 *   - If category-specific: is `default_enabled` set to false? Is a
 *     real `categories` array (not 'all') provided?
 *   - Does the render path check BOTH category eligibility AND real,
 *     per-listing assignment via ModuleRegistry::is_assigned() with
 *     get_assigned_module_keys()? (Every section that reads $_sec_show()
 *     in vendor-site.php already gets this for free — do not bypass
 *     $_sec_show() with a separate, hand-rolled visibility check.)
 *   - Does the admin editor (create-listing.php) require the vendor to
 *     tick a checkbox — surfaced only after they've picked a matching
 *     category — before this section's tab/panel appears at all?
 *   - Is the actual per-listing choice persisted via
 *     ModuleRegistry::set_assignment() against gs_listing_modules, not
 *     some new, separate table or flag invented for this one section?
 *
 * DO NOT build a second, alternative, legacy, or shortcut system for
 * "just this one section." There is one architecture. Every future
 * category-specific section reuses it exactly, via ModuleRegistry.
 *
 * Full narrative and the original real-world bug this corrected are
 * documented in MODULE_ARCHITECTURE_ROADMAP.md, Section 6.16.
 * ════════════════════════════════════════════════════════════════════
 *
 * ModuleRegistry — Phase 0 of the modular listing architecture roadmap.
 *
 * Single source of truth for every section/module in the system — old
 * (once migrated in later phases) and new alike. A module registers
 * itself here exactly once; every other part of the system (the
 * rendering engine, Section Container Widths, Layout & Element Manager,
 * the category-assignment workflow) reads FROM this registry rather
 * than maintaining its own separate, hand-edited list.
 *
 * This directly fixes the audited root cause: today, Layout & Element
 * Manager and Section Container Widths each hold their own hardcoded
 * PHP array of sections, requiring a manual edit to BOTH whenever a
 * section is added. A module registered here once is automatically
 * visible to both — see get_all() / get_for_category(), which is what
 * those two admin tools will be changed to read from once they're
 * migrated onto this registry (a later roadmap step, not done yet).
 *
 * Two supported module shapes (per roadmap Section 3.4):
 *   - 'schema'  — a plain field list, rendered by a generic engine.
 *                 Use when a module is just "a repeater of simple
 *                 fields" (e.g. a hotel's Room Types).
 *   - 'custom'  — bespoke render/admin code the module owns itself
 *                 (e.g. the hand-designed Facilities/Awards/Highlights
 *                 sections built earlier). Registered here for
 *                 visibility/assignment purposes, but rendering stays
 *                 in the module's own callback — never auto-generated.
 *
 * Nothing in this file touches the database, the rendering pipeline,
 * or any existing section. It is pure in-memory registration data for
 * the current request, matching the read pattern the rest of the
 * roadmap will build against.
 */
class ModuleRegistry {

    /** @var array<string, array> module_key => module definition */
    private static array $modules = [];

    /** True once apply_admin_overrides() has run for this request — a
     * guard so a second call (e.g. from an admin AJAX handler that also
     * needs the registry) doesn't re-query and re-merge unnecessarily. */
    private static bool $overrides_applied = false;

    /**
     * Register a module. Safe to call multiple times for the same
     * plugin lifecycle (e.g. once per relevant file load) — a second
     * registration with the same key simply overwrites the first,
     * matching how WordPress hooks are typically idempotent across
     * repeated requests.
     *
     * @param string $module_key   Unique, stable identifier. Becomes
     *                             the value stored in gs_listing_modules
     *                             and gs_listing_module_data — must
     *                             never change once vendors have data
     *                             under it.
     * @param array  $config {
     *     @type string   $label        Human-readable name, e.g. 'Room Types'.
     *                                   Feeds Section Container Widths and
     *                                   Layout & Element Manager directly —
     *                                   no separate label list to maintain.
     *     @type string   $icon         Emoji/icon shown in those same admin
     *                                   tools, e.g. '🛏️'.
     *     @type string   $type         'schema' or 'custom'. See class docblock.
     *     @type array|string $categories  Array of category slugs this module
     *                                   is eligible for, or the literal string
     *                                   'all' for shared/standard modules that
     *                                   ship with every listing regardless of
     *                                   category (Packages, Services, contact
     *                                   info, etc. once migrated).
     *     @type array    $fields       Only for type='schema': the field
     *                                   definitions this module's generic
     *                                   renderer needs (key, label, input
     *                                   type, etc.). Ignored for type='custom'.
     *     @type callable|null $render_callback   Only for type='custom':
     *                                   the module's own render function.
     *                                   Required for 'custom', ignored for
     *                                   'schema'.
     *     @type callable|null $admin_fields_callback  Only for type='custom':
     *                                   the module's own admin-form field
     *                                   renderer. Required for 'custom',
     *                                   ignored for 'schema'.
     *     @type bool     $default_enabled  Whether this module is
     *                                   pre-assigned to every new listing
     *                                   (true for standard/shared modules)
     *                                   or opt-in via the category
     *                                   checklist (false for everything
     *                                   else). Defaults to false.
     * }
     * @return bool True if registered, false if $config failed
     *              validation (missing a required key for its type) —
     *              a mistake here must never fatal the whole site, so
     *              this fails soft and logs, matching this codebase's
     *              existing error_log conventions elsewhere.
     */
    public static function register( string $module_key, array $config ): bool {
        if ( $module_key === '' ) {
            error_log( 'ModuleRegistry::register() called with an empty module_key — ignored.' );
            return false;
        }

        $type = $config['type'] ?? 'schema';
        if ( ! in_array( $type, [ 'schema', 'custom' ], true ) ) {
            error_log( "ModuleRegistry::register('{$module_key}') — invalid type '{$type}', must be 'schema' or 'custom'. Ignored." );
            return false;
        }

        if ( $type === 'custom' && ( empty( $config['render_callback'] ) || ! is_callable( $config['render_callback'] ) ) ) {
            error_log( "ModuleRegistry::register('{$module_key}') — type 'custom' requires a callable render_callback. Ignored." );
            return false;
        }

        if ( $type === 'schema' && empty( $config['fields'] ) ) {
            error_log( "ModuleRegistry::register('{$module_key}') — type 'schema' requires a non-empty fields array. Ignored." );
            return false;
        }

        // MANDATORY ARCHITECTURE GUARD — see the notice at the top of this
        // file and MODULE_ARCHITECTURE_ROADMAP.md Section 6.16. A module
        // restricted to specific categories (not 'all') must ALWAYS
        // require explicit, per-listing vendor opt-in — it must never be
        // pre-enabled for every matching listing just because it exists.
        // This is exactly the mistake made once already in this codebase
        // (Room Types was first registered with categories=['hotels'] AND
        // default_enabled=true, which silently defeated the whole
        // opt-in requirement). Refusing this combination outright — not
        // just documenting it — is what makes it structurally impossible
        // for that specific mistake to happen silently again, by anyone,
        // including a future AI with no memory of this conversation.
        $_categories = $config['categories'] ?? 'all';
        $_default_enabled = (bool) ( $config['default_enabled'] ?? false );
        if ( $_categories !== 'all' && $_default_enabled === true ) {
            error_log(
                "ModuleRegistry::register('{$module_key}') — REFUSED. A category-specific module " .
                "(categories = " . json_encode( $_categories ) . ") cannot have default_enabled = true. " .
                "Category-specific sections must always require explicit, per-listing vendor opt-in via " .
                "the assignment checklist — see the mandatory architecture notice at the top of this file. " .
                "Set default_enabled to false, or set categories to 'all' if this is genuinely meant to be " .
                "a regular/common section available to every listing."
            );
            return false;
        }
        // Real fix — the symmetric, opposite case: a module registered
        // with no category restrictions (categories='all') but
        // default_enabled=false would be permanently unreachable — see
        // the matching correction in apply_admin_overrides() for the
        // full reasoning. Auto-corrected silently here rather than
        // refused: unlike the case above, this combination isn't
        // architecture-violating, just a dead end, and a developer
        // registering a new module shouldn't need to know this nuance
        // for their module to actually work correctly.
        if ( $_categories === 'all' && $_default_enabled === false ) {
            $_default_enabled = true;
        }

        self::$modules[ $module_key ] = array_merge( [
            'label'                  => $config['label'] ?? $module_key,
            'icon'                   => $config['icon'] ?? '🧩',
            'type'                   => $type,
            'categories'             => $_categories,
            'fields'                 => $config['fields'] ?? [],
            'render_callback'        => $config['render_callback'] ?? null,
            'admin_fields_callback'  => $config['admin_fields_callback'] ?? null,
            'default_enabled'        => $_default_enabled,
        ], [ 'module_key' => $module_key ] );

        return true;
    }

    /**
     * Fetches every module_key assigned AND enabled for a given listing,
     * in a single query — not one query per registered module. This is
     * the mechanism that makes "zero overhead for unassigned modules"
     * real: the rendering engine calls this ONCE per page load, then
     * checks membership in the returned array (an in-memory operation)
     * for every registered module, rather than querying the database
     * once per module to ask "is this one assigned."
     *
     * Uses the exact UNIQUE KEY (listing_id, module_key) created in
     * Phase 0's gs_listing_modules table — an indexed lookup, not a
     * table scan, regardless of how many modules exist platform-wide.
     *
     * @param object $wpdb WordPress database object (not strictly typed, matching this codebase's convention)
     * @param string $table_prefix WordPress table prefix + plugin prefix,
     *               e.g. "wp_gs_" — matches the {$p} convention used
     *               throughout Schema.php.
     * @param int    $listing_id
     * @return string[] Array of assigned module_keys. Empty array if the
     *                   listing has no module assignments at all (e.g. a
     *                   pre-migration listing, or one that only uses
     *                   default-enabled modules not yet written as rows —
     *                   see get_default_enabled() for that fallback case).
     */
    public static function get_assigned_module_keys( $wpdb, string $table_prefix, int $listing_id ): array {
        if ( $listing_id <= 0 ) { return []; }
        $sql = $wpdb->prepare(
            "SELECT module_key FROM {$table_prefix}listing_modules WHERE listing_id = %d AND is_enabled = 1",
            $listing_id
        );
        $keys = $wpdb->get_col( $sql );
        return is_array( $keys ) ? $keys : [];
    }

    /**
     * The actual "should this module render for this listing" check the
     * rendering engine will call once per registered module. Combines
     * get_assigned_module_keys()'s real assignment data with
     * get_default_enabled()'s fallback — a module marked default_enabled
     * counts as assigned even if no explicit row exists yet (covers
     * every currently-live listing prior to any assignment migration,
     * so shared/standard modules like Packages continue working
     * unchanged for vendors who existed before this system did).
     *
     * @param string[] $assigned_keys The result of get_assigned_module_keys(),
     *                 computed once per page load and passed in — never
     *                 recomputed per module, to avoid the N-queries
     *                 problem this whole method exists to prevent.
     */
    public static function is_assigned( string $module_key, array $assigned_keys ): bool {
        if ( in_array( $module_key, $assigned_keys, true ) ) { return true; }
        $module = self::get( $module_key );
        return $module !== null && $module['default_enabled'] === true;
    }

    /**
     * Fetches a single module's migrated data for one listing, from the
     * new gs_listing_module_data table (Phase 0). Returns an empty array
     * if no row exists — the correct, expected state for every module
     * before its own migration step runs, and the signal that causes
     * render callbacks (see HighlightsModule::render()) to correctly
     * fall back to reading from the legacy $primary row instead.
     *
     * This is the real implementation for ModuleRenderer::render_all()'s
     * $fetch_module_data_callback parameter — only ever called for
     * modules that already passed is_assigned(), matching the same
     * "no query for an unassigned module" guarantee proven for
     * get_assigned_module_keys().
     *
     * @param object $wpdb
     * @param string $table_prefix
     * @param string $module_key
     * @param int    $listing_id
     * @return array Decoded data_json, or [] if no row / invalid JSON.
     */
    public static function fetch_module_data( $wpdb, string $table_prefix, string $module_key, int $listing_id ): array {
        if ( $listing_id <= 0 || $module_key === '' ) { return []; }
        $sql = $wpdb->prepare(
            "SELECT data_json FROM {$table_prefix}listing_module_data WHERE listing_id = %d AND module_key = %s",
            $listing_id, $module_key
        );
        $raw = $wpdb->get_var( $sql );
        if ( $raw === null || $raw === false ) { return []; }
        $decoded = json_decode( (string) $raw, true );
        return is_array( $decoded ) ? $decoded : [];
    }

    /**
     * Writes (or clears) one listing's assignment row for one module in
     * gs_listing_modules — the actual "has this vendor explicitly opted
     * into this category-specific module for this listing" record.
     * Uses INSERT ... ON DUPLICATE KEY UPDATE against the table's own
     * UNIQUE KEY (listing_id, module_key), matching save_module_data()'s
     * pattern exactly. Setting $enabled=false does NOT delete the row —
     * matches this table's own documented "soft-disable, recoverable"
     * design (see Schema.php's own comment on this table): a vendor who
     * unticks a box and re-ticks it later gets their prior data back
     * without anything needing to be re-entered.
     *
     * @param object $wpdb
     * @param string $table_prefix
     * @param string $module_key
     * @param int    $listing_id
     * @param bool   $enabled
     * @return bool True on success.
     */
    public static function set_assignment( $wpdb, string $table_prefix, string $module_key, int $listing_id, bool $enabled ): bool {
        if ( $listing_id <= 0 || $module_key === '' ) { return false; }
        $table = "{$table_prefix}listing_modules";
        $is_enabled = $enabled ? 1 : 0;
        $result = $wpdb->query( $wpdb->prepare(
            "INSERT INTO {$table} (listing_id, module_key, is_enabled, created_at, updated_at)
             VALUES (%d, %s, %d, NOW(), NOW())
             ON DUPLICATE KEY UPDATE is_enabled = %d, updated_at = NOW()",
            $listing_id, $module_key, $is_enabled, $is_enabled
        ) );
        return $result !== false;
    }

    /** Get a single module's definition, or null if not registered. */
    public static function get( string $module_key ): ?array {
        return self::$modules[ $module_key ] ?? null;
    }

    /**
     * Writes a single module's data for one listing to
     * gs_listing_module_data — the write counterpart to
     * fetch_module_data() above. Uses INSERT ... ON DUPLICATE KEY UPDATE
     * against the table's own UNIQUE KEY (listing_id, module_key), so
     * this is safe to call repeatedly (every save) without needing a
     * separate "does a row already exist" check first.
     *
     * @param object $wpdb
     * @param string $table_prefix
     * @param string $module_key
     * @param int    $listing_id
     * @param array  $data The data to store — will be JSON-encoded.
     * @return bool True on success, false if the write failed.
     */
    public static function save_module_data( $wpdb, string $table_prefix, string $module_key, int $listing_id, array $data ): bool {
        if ( $listing_id <= 0 || $module_key === '' ) { return false; }
        $json = wp_json_encode( $data );
        $table = "{$table_prefix}listing_module_data";
        $result = $wpdb->query( $wpdb->prepare(
            "INSERT INTO {$table} (listing_id, module_key, data_json, created_at, updated_at)
             VALUES (%d, %s, %s, NOW(), NOW())
             ON DUPLICATE KEY UPDATE data_json = %s, updated_at = NOW()",
            $listing_id, $module_key, $json, $json
        ) );
        return $result !== false;
    }

    /** Get every registered module, keyed by module_key. */
    public static function get_all(): array {
        return self::$modules;
    }

    /**
     * Loads gs_module_config (the persistent, admin-editable layer) and
     * merges it over whatever register() calls already put in memory —
     * label, icon, categories, default_enabled, active state, sort
     * order can all be changed here by an admin with no code touched.
     * A module_key present in gs_module_config but NEVER registered by
     * any PHP class at all (source='admin', a pure no-code section
     * built entirely from the Section Builder screen) gets a real,
     * complete in-memory entry created here for the first time — its
     * render_callback is SchemaModuleRenderer::render(), the generic
     * renderer that reads gs_module_config_fields and this module's
     * saved gs_listing_module_data to produce output, with no
     * hand-written PHP module class required at all.
     *
     * Must run AFTER ModulesBootstrap::register_all() (so there is
     * something in self::$modules to merge onto) and is idempotent —
     * safe to call more than once per request; only the first call
     * actually queries the database.
     *
     * A module with is_active=0 here is filtered OUT of self::$modules
     * entirely — not just marked inactive. This is deliberate: an
     * inactive module must be completely invisible to every part of
     * the system that reads the registry (rendering, both admin
     * tools, category-assignment UI), not merely flagged and still
     * present for something to accidentally still act on.
     */
    /** True once ensure_tables_exist() has confirmed the tables this
     * request, guarding against a redundant SHOW TABLES query on every
     * single call within the same request. */
    private static bool $tables_checked = false;

    /**
     * Real, direct fix — reported by the user: after delivering the
     * GS_VERSION bump intended to trigger the plugin's own existing
     * automatic upgrade mechanism (Plugin::check_db_version(), hooked
     * on every request), the user reported no change at all. That
     * mechanism's own logic was re-verified and is correct — but it is
     * an INDIRECT dependency (a separate class, hooked at a specific
     * priority, relying on an option value and a version comparison)
     * that cannot be directly confirmed without access to the user's
     * actual server, and something about their specific environment
     * (opcode caching with timestamp validation disabled, a hosting
     * quirk, or something else entirely) may be preventing it from
     * taking effect. Rather than continue depending solely on that
     * indirect path, or guess further at why it might not be firing,
     * this is a direct, self-contained, always-effective alternative:
     * a real `SHOW TABLES LIKE` check followed by the exact same
     * `CREATE TABLE IF NOT EXISTS` statements Schema.php already
     * defines for these two tables, called directly from within this
     * feature's own code path (apply_admin_overrides() below, and the
     * Section Manager AJAX handlers), so this feature does not depend
     * on any other mechanism working correctly at all — it guarantees
     * its own prerequisites every time it runs.
     */
    public static function ensure_tables_exist( $wpdb, string $table_prefix ): void {
        if ( self::$tables_checked ) { return; }
        self::$tables_checked = true;

        $exists = $wpdb->get_var(
            "SHOW TABLES LIKE '{$table_prefix}module_config'"
        );
        if ( $exists ) { return; } // already present — the normal, expected case after the first check per request

        $c = method_exists( $wpdb, 'get_charset_collate' ) ? $wpdb->get_charset_collate() : '';
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS {$table_prefix}module_config (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                module_key      VARCHAR(64)     NOT NULL,
                label           VARCHAR(191)    DEFAULT NULL,
                icon            VARCHAR(16)     DEFAULT NULL,
                type            VARCHAR(16)     NOT NULL DEFAULT 'schema',
                categories_json TEXT            DEFAULT NULL,
                default_enabled TINYINT(1)      NOT NULL DEFAULT 0,
                is_active       TINYINT(1)      NOT NULL DEFAULT 1,
                sort_order      INT UNSIGNED    DEFAULT 0,
                source          VARCHAR(16)     NOT NULL DEFAULT 'admin',
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_module_key (module_key),
                KEY idx_active (is_active)
            ) {$c}"
        );
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS {$table_prefix}module_config_fields (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                module_key      VARCHAR(64)     NOT NULL,
                field_key       VARCHAR(64)     NOT NULL,
                field_label     VARCHAR(191)    NOT NULL,
                field_type      VARCHAR(24)     NOT NULL DEFAULT 'text',
                is_repeater_item TINYINT(1)     NOT NULL DEFAULT 0,
                options_json    TEXT            DEFAULT NULL,
                sort_order      INT UNSIGNED    DEFAULT 0,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_module_field (module_key, field_key),
                KEY idx_module (module_key)
            ) {$c}"
        );
        // gs_listing_modules (the assignment table used by
        // set_assignment()/get_assigned_module_keys(), built earlier
        // this project) is also directly guaranteed here for the same
        // reason — every table this whole feature depends on, not just
        // the two newest ones, so a partially-migrated database can
        // never be the cause of a silent failure in this feature again.
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS {$table_prefix}listing_modules (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id      BIGINT UNSIGNED NOT NULL,
                module_key      VARCHAR(64)     NOT NULL,
                is_enabled      TINYINT(1)      NOT NULL DEFAULT 1,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_listing_module (listing_id, module_key),
                KEY idx_listing (listing_id)
            ) {$c}"
        );
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS {$table_prefix}listing_module_data (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id      BIGINT UNSIGNED NOT NULL,
                module_key      VARCHAR(64)     NOT NULL,
                data_json       LONGTEXT        DEFAULT NULL,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_listing_module_data (listing_id, module_key),
                KEY idx_listing_data (listing_id)
            ) {$c}"
        );
    }

    public static function apply_admin_overrides( $wpdb, string $table_prefix ): void {
        self::ensure_tables_exist( $wpdb, $table_prefix );
        if ( self::$overrides_applied ) { return; }
        self::$overrides_applied = true;

        $table = "{$table_prefix}module_config";
        $rows = $wpdb->get_results( "SELECT * FROM {$table}" );
        if ( ! is_array( $rows ) ) { return; }

        foreach ( $rows as $row ) {
            $key = $row->module_key;
            $categories = $row->categories_json ? ( json_decode( $row->categories_json, true ) ?: 'all' ) : 'all';
            $default_enabled = (bool) $row->default_enabled;

            // Same mandatory architecture guard as register() — see the
            // notice at the top of this file. An admin editing a
            // module's config through the Section Manager screen is a
            // second path that bypasses register()'s own validation
            // entirely, so the exact same real mistake (a category-
            // specific module marked default_enabled=true) could
            // otherwise slip in here even with that guard already in
            // place. Refuse the same way: log it, fall back to
            // default_enabled=false rather than silently accepting an
            // architecture-violating configuration.
            if ( $categories !== 'all' && $default_enabled === true ) {
                error_log(
                    "ModuleRegistry::apply_admin_overrides('{$key}') — a category-specific module " .
                    "cannot have default_enabled = true. Falling back to false. See the mandatory " .
                    "architecture notice at the top of this file."
                );
                $default_enabled = false;
            }
            // Real fix — the symmetric, opposite case, reported directly:
            // a module with NO category restrictions (categories='all')
            // but default_enabled=false is not a reachable state at all
            // — the vendor-facing opt-in checklist (create-listing.php)
            // deliberately excludes every 'all'-category module, so
            // there is no UI anywhere that could ever satisfy this
            // module's own opt-in requirement. It would stay
            // permanently invisible for every listing, appearing under
            // no category/subcategory combination whatsoever, exactly
            // as reported. Corrected here on every read (not just at
            // the point of save) so any row already saved with this
            // combination — from before this fix, or from any other
            // path that might produce it in the future — self-heals
            // automatically rather than needing to be found and
            // re-saved by hand.
            if ( $categories === 'all' && $default_enabled === false ) {
                $default_enabled = true;
            }

            if ( isset( self::$modules[ $key ] ) ) {
                // A code-registered module — merge admin-editable fields
                // over its defaults. render_callback and fields (the
                // actual rendering logic) are NEVER overridden here —
                // an admin can change how a hand-built module is
                // configured, never what it renders.
                if ( $row->label !== null ) { self::$modules[ $key ]['label'] = $row->label; }
                if ( $row->icon !== null ) { self::$modules[ $key ]['icon'] = $row->icon; }
                self::$modules[ $key ]['categories'] = $categories;
                self::$modules[ $key ]['default_enabled'] = $default_enabled;
                self::$modules[ $key ]['sort_order'] = (int) $row->sort_order;
                if ( ! (bool) $row->is_active ) { unset( self::$modules[ $key ] ); }
            } elseif ( (bool) $row->is_active ) {
                // A pure no-code module — never registered by any PHP
                // class, exists ONLY because an admin built it. Create
                // its in-memory entry now, pointing at the generic
                // schema renderer.
                self::$modules[ $key ] = [
                    'module_key'             => $key,
                    'label'                  => $row->label ?? $key,
                    'icon'                   => $row->icon ?? '🧩',
                    'type'                   => 'schema',
                    'categories'             => $categories,
                    'fields'                 => [], // loaded on demand by SchemaModuleRenderer, not cached here
                    'render_callback'        => [ \GoodService\Modules\SchemaModuleRenderer::class, 'render' ],
                    'admin_fields_callback'  => null,
                    'default_enabled'        => $default_enabled,
                    'sort_order'             => (int) $row->sort_order,
                ];
            }
        }

        uasort( self::$modules, fn( $a, $b ) => ( $a['sort_order'] ?? 0 ) <=> ( $b['sort_order'] ?? 0 ) );
    }

    /** @var array<string, array> module_key => field rows, memoized per-request */
    private static array $field_cache = [];

    /**
     * Reads a schema module's field definitions from
     * gs_module_config_fields, ordered by sort_order — the actual
     * structure a no-code section's admin form and public render are
     * both built from. Memoized: called once per module per request
     * regardless of how many listings/contexts need it in that
     * request (the field DEFINITIONS are the same for every listing —
     * only the per-listing DATA differs, which is fetched separately
     * via fetch_module_data()).
     */
    public static function get_module_fields( $wpdb_or_key, string $table_prefix = '', string $module_key = '' ): array {
        // Supports being called either as get_module_fields($wpdb, $prefix, $key)
        // or, when the caller only has the module_key (e.g.
        // SchemaModuleRenderer), get_module_fields($key), using the
        // wpdb global directly.
        if ( func_num_args() === 1 ) {
            global $wpdb;
            $module_key = $wpdb_or_key;
            $table_prefix = $wpdb->prefix . 'gs_';
        } else {
            $wpdb = $wpdb_or_key;
        }
        if ( isset( self::$field_cache[ $module_key ] ) ) { return self::$field_cache[ $module_key ]; }
        $table = "{$table_prefix}module_config_fields";
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE module_key = %s ORDER BY sort_order ASC", $module_key
        ) );
        self::$field_cache[ $module_key ] = is_array( $rows ) ? $rows : [];
        return self::$field_cache[ $module_key ];
    }

    /**
     * Get every module eligible for a given category — either because
     * it's explicitly listed for that category, or because it's marked
     * 'all' (a shared/standard module every category can use).
     */
    /**
     * Real feature — category-assignment redesign. Replaces the old,
     * simple flat-slug matching with support for the new structured
     * format: an array of groups, each `{"main_id": int, "subs":
     * "all"|[int, int, ...]}`, produced by the redesigned Section
     * Manager UI (main-category dropdown → subcategory dropdown → ALL
     * or specific selections → repeatable for multiple main
     * categories).
     *
     * Backward compatible by design, not by a one-time migration that
     * could silently lose data: a plain string entry (the OLD format,
     * e.g. RoomTypesModule's code-registered `['hotels']`) is matched
     * EXACTLY as it always was — the listing's own resolved category
     * slug must match directly, with no hierarchy consideration at
     * all, since that is what the original implementation actually
     * did (confirmed by reading it, not assumed). This means existing
     * data and existing code-registered modules keep working forever
     * without requiring every one of them to be rewritten — the new
     * structured format is available for anything actually configured
     * through the new UI, without forcing a disruptive migration on
     * everything else.
     *
     * @param mixed        $module_categories 'all', an array of legacy
     *                     slug strings, or an array of structured
     *                     group objects/arrays.
     * @param object|null  $listing_category  The listing's own resolved
     *                     category row (id, parent_id, slug) — e.g.
     *                     from CategoryRepository::get_by_id(). Null if
     *                     the listing has no category set at all.
     */
    public static function category_matches( $module_categories, ?object $listing_category ): bool {
        if ( $module_categories === 'all' ) { return true; }
        if ( $listing_category === null ) { return false; }
        if ( ! is_array( $module_categories ) || empty( $module_categories ) ) { return false; }

        $listing_id        = (int) $listing_category->id;
        $listing_parent_id = (int) ( $listing_category->parent_id ?? 0 );
        $listing_slug       = (string) ( $listing_category->slug ?? '' );

        foreach ( $module_categories as $entry ) {
            if ( is_string( $entry ) ) {
                if ( $entry === $listing_slug ) { return true; }
                continue;
            }
            $entry = (array) $entry; // tolerate stdClass from a JSON-decode with assoc=false anywhere upstream
            if ( array_key_exists( 'main_id', $entry ) ) {
                $main_id = (int) $entry['main_id'];
                if ( $listing_id === $main_id ) { return true; }
                if ( $listing_parent_id === $main_id ) {
                    $subs = $entry['subs'] ?? 'all';
                    if ( $subs === 'all' ) { return true; }
                    if ( is_array( $subs ) && in_array( $listing_id, array_map( 'intval', $subs ), true ) ) { return true; }
                }
            }
        }
        return false;
    }

    public static function get_for_category( string $category ): array {
        return array_filter( self::$modules, function ( $module ) use ( $category ) {
            if ( $module['categories'] === 'all' ) { return true; }
            return is_array( $module['categories'] ) && in_array( $category, $module['categories'], true );
        } );
    }

    /** Every module marked default_enabled — pre-assigned to new listings. */
    public static function get_default_enabled(): array {
        return array_filter( self::$modules, fn( $module ) => $module['default_enabled'] === true );
    }

    /** True if a module is registered at all. */
    public static function exists( string $module_key ): bool {
        return isset( self::$modules[ $module_key ] );
    }

    /**
     * Produces [module_key => [icon, label]] — the exact shape Section
     * Container Widths' $width_sections and Layout & Element Manager's
     * $sec_labels currently hold as two SEPARATE hardcoded arrays (the
     * audited root cause: a new section today needs a manual edit to
     * both). Once those two tools are migrated (a later phase — not
     * done yet, per the roadmap's explicit "nothing existing touched"
     * scope for Phase 0), both will read from this single method
     * instead, so registering a module once makes it appear in both
     * automatically.
     */
    public static function get_admin_tool_entries(): array {
        $entries = [];
        foreach ( self::$modules as $key => $module ) {
            $entries[ $key ] = [ $module['icon'], $module['label'] ];
        }
        return $entries;
    }

    /** Test-only: clears all registrations. Never called from production
     * code paths — exists so registry-behavior tests can start from a
     * known-empty state without needing a full request lifecycle reset.
     */
    public static function _reset_for_testing(): void {
        self::$modules = [];
    }
}
