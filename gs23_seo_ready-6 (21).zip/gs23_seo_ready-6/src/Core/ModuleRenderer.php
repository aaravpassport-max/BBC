<?php
namespace GoodService\Core;

/**
 * ModuleRenderer — the actual engine loop for the modular listing
 * architecture roadmap (Phase 1).
 *
 * Separate from ModuleRegistry deliberately: the registry answers "what
 * modules exist and what are they eligible for," this class answers
 * "given a specific listing, which of those modules actually render,
 * and how." Keeping them separate means the registry stays a pure data
 * store, testable and reasoned about independently of any rendering
 * concern.
 *
 * The core guarantee this class exists to make real, not just designed:
 * for a module NOT assigned to a listing, this class never fetches its
 * module_data, never calls its render_callback, and returns nothing for
 * it — checked via ModuleRegistry::is_assigned() using an already-
 * fetched assignment list (one query per page load, computed by the
 * caller via ModuleRegistry::get_assigned_module_keys()), never a
 * per-module lookup.
 */
class ModuleRenderer {

    /**
     * Renders every module assigned to a listing, in registration order.
     * (Ordering by the roadmap's later `sort_order` column is a Phase 3
     * concern — this method deliberately doesn't attempt it yet, so it
     * isn't guessing at a requirement not yet built.)
     *
     * @param array $assigned_keys Pre-fetched via
     *              ModuleRegistry::get_assigned_module_keys() — computed
     *              ONCE per page load by the caller, not by this method,
     *              so calling render_all() doesn't itself trigger the
     *              assignment query.
     * @param array $base_context  Shared context every module receives:
     *              ['listing_id' => int, 'primary' => object, 'cd' => array].
     *              module_data is added per-module by this method, not
     *              the caller — see fetch_module_data_callback below.
     * @param callable|null $fetch_module_data_callback  Optional callback
     *              with signature (string $module_key, int $listing_id): array,
     *              called ONLY for modules that pass is_assigned() — this
     *              is what makes "no query for an unassigned module's
     *              data" real rather than assumed. If null (the default,
     *              matching today's pre-migration reality where no
     *              module has real data in the new table yet), every
     *              module receives an empty module_data array and
     *              falls back to reading from $context['primary'],
     *              exactly like HighlightsModule does today.
     * @return array<string, string> module_key => rendered HTML, for
     *              every module that was actually assigned. Unassigned
     *              modules are simply absent from this array — not
     *              present with an empty string, absent entirely,
     *              matching "behave as if it does not exist."
     */
    public static function render_all( array $assigned_keys, array $base_context, ?callable $fetch_module_data_callback = null ): array {
        $output = [];
        foreach ( ModuleRegistry::get_all() as $module_key => $module ) {
            if ( ! ModuleRegistry::is_assigned( $module_key, $assigned_keys ) ) {
                continue; // Unassigned: zero further work for this module. No data fetch, no render call.
            }
            if ( $module['render_callback'] === null ) {
                continue; // Schema-driven modules render generically — not built yet (later phase); nothing to call.
            }
            $module_data = $fetch_module_data_callback !== null
                ? $fetch_module_data_callback( $module_key, (int) ( $base_context['listing_id'] ?? 0 ) )
                : [];
            $context = array_merge( $base_context, [ 'module_data' => $module_data ] );
            $output[ $module_key ] = call_user_func( $module['render_callback'], $context );
        }
        return $output;
    }
}
