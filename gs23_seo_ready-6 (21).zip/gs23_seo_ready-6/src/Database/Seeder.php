<?php
namespace GoodService\Database;

final class Seeder {

    public static function run(): void {
        global $wpdb;
        // Seed diagnosis templates if table exists (Moat 1)
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_diagnosis_templates'" ) ) {
            self::seed_diagnosis_templates();
        }
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';

        // Only seed if tables are empty
        if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$p}subscription_plans" ) > 0 ) {
            return;
        }

        self::seed_plans( $p );
        self::seed_categories( $p );
        self::seed_settings( $p );
        self::seed_email_templates( $p );
        self::seed_whatsapp_templates( $p );
        self::seed_section_templates( $p );
        self::seed_reply_templates( $p );
    }

    private static function seed_plans( string $p ): void {
        global $wpdb;
        $plans = [
            [
                'name'                  => 'Free',
                'slug'                  => 'free',
                'description'           => 'Get started for free. Perfect for new businesses.',
                'price_monthly'         => 0.00,
                'price_yearly'          => 0.00,
                'max_listings'          => 1,
                'max_photos'            => 3,
                'max_services'          => 5,
                'show_phone'            => 1,
                'show_whatsapp'         => 1,
                'show_email'            => 0,
                'show_analytics'        => 0,
                'featured_badge'        => 0,
                'priority_listing'      => 0,
                'allow_inquiry_module'  => 0,
                'allow_booking_module'  => 0,
                'features_list'         => "1 listing\n3 photos\nBasic profile\nLead notifications",
                'sort_order'            => 1,
                'is_active'             => 1,
                'is_popular'            => 0,
                'color'                 => '#64748B',
            ],
            [
                'name'                  => 'Starter',
                'slug'                  => 'starter',
                'description'           => 'For growing businesses that need more visibility.',
                'price_monthly'         => 999.00,
                'price_yearly'          => 9999.00,
                'max_listings'          => 3,
                'max_photos'            => 10,
                'max_services'          => 20,
                'show_phone'            => 1,
                'show_whatsapp'         => 1,
                'show_email'            => 1,
                'show_analytics'        => 1,
                'featured_badge'        => 0,
                'priority_listing'      => 0,
                'allow_inquiry_module'  => 1,
                'allow_booking_module'  => 1,
                // Starter gets booking access (Section 7 of the inquiry/booking
                // audit) but capped at one category at a time — Professional
                // (below) remains unlimited via max_booking_modules=0.
                'max_booking_modules'   => 1,
                'features_list'         => "3 listings\n10 photos\nAnalytics dashboard\nEmail display\nInquiry forms\nDirect booking (1 service)\nPriority support",
                'sort_order'            => 2,
                'is_active'             => 1,
                'is_popular'            => 0,
                'color'                 => '#2563EB',
            ],
            [
                'name'                  => 'Professional',
                'slug'                  => 'professional',
                'description'           => 'Full-featured plan for serious businesses.',
                'price_monthly'         => 2499.00,
                'price_yearly'          => 24999.00,
                'max_listings'          => 10,
                'max_photos'            => 30,
                'max_services'          => 50,
                'show_phone'            => 1,
                'show_whatsapp'         => 1,
                'show_email'            => 1,
                'show_analytics'        => 1,
                'show_seo_tools'        => 1,
                'featured_badge'        => 1,
                'priority_listing'      => 1,
                'allow_inquiry_module'  => 1,
                'allow_booking_module'  => 1,
                'max_booking_modules'   => 0, // 0 = unlimited
                'features_list'         => "10 listings\n30 photos\nFeatured badge\nPriority placement\nSEO tools\nAnalytics\nInquiry & Booking modules",
                'sort_order'            => 3,
                'is_active'             => 1,
                'is_popular'            => 1,
                'color'                 => '#7C3AED',
            ],
        ];
        foreach ( $plans as $plan ) {
            $wpdb->insert( $p . 'subscription_plans', $plan );
        }
    }

    /**
     * The full, current category list. Kept as a single source of truth
     * so both seed_categories() (fresh installs) and
     * sync_missing_categories() (existing live installs — see that
     * method's own docblock for the real bug this fixes) insert
     * identical rows and can never drift apart from each other.
     */
    private static function category_definitions(): array {
        return [
            [ 'name' => 'Home Services',      'slug' => 'home-services',      'icon_emoji' => '🏠', 'color' => '#2563EB', 'sort_order' => 1 ],
            [ 'name' => 'Business Services',  'slug' => 'business-services',  'icon_emoji' => '💼', 'color' => '#7C3AED', 'sort_order' => 2 ],
            [ 'name' => 'Health & Wellness',  'slug' => 'health-wellness',    'icon_emoji' => '❤️', 'color' => '#DC2626', 'sort_order' => 3 ],
            [ 'name' => 'Education',          'slug' => 'education',          'icon_emoji' => '📚', 'color' => '#059669', 'sort_order' => 4 ],
            [ 'name' => 'IT & Technology',    'slug' => 'it-technology',      'icon_emoji' => '💻', 'color' => '#0891B2', 'sort_order' => 5 ],
            [ 'name' => 'Events & Wedding',   'slug' => 'events-wedding',     'icon_emoji' => '🎉', 'color' => '#D97706', 'sort_order' => 6 ],
            [ 'name' => 'Beauty & Salon',     'slug' => 'beauty-salon',       'icon_emoji' => '💄', 'color' => '#DB2777', 'sort_order' => 7 ],
            [ 'name' => 'Legal & Finance',    'slug' => 'legal-finance',      'icon_emoji' => '⚖️', 'color' => '#334155', 'sort_order' => 8 ],
            // ── The 3 categories below were referenced by ModuleRegistry
            // (RoomTypesModule/PropertyListingsModule/InteriorDesignArchitects*
            // Module and every sibling module in each of their categories)
            // but were NEVER added here — confirmed root cause of a
            // reported bug: with no matching row in wp_gs_categories, a
            // vendor could never select these categories in the admin
            // category dropdown at all, so category_matches() could
            // never return true for any real listing, so every single
            // Hotels/Real-Estate/Interior-Designers module — the entire
            // Hospitality series included — silently never appeared in
            // the Sections tab for ANY vendor, on ANY listing. Added here
            // for fresh installs; see sync_missing_categories() below for
            // the matching fix on already-installed sites.
            [ 'name' => 'Hotels & Hospitality',        'slug' => 'hotels',                          'icon_emoji' => '🏨', 'color' => '#B45309', 'sort_order' => 9 ],
            [ 'name' => 'Real Estate',                 'slug' => 'real-estate',                     'icon_emoji' => '🏢', 'color' => '#0D9488', 'sort_order' => 10 ],
            [ 'name' => 'Interior Designers & Architects', 'slug' => 'interior-designers-architects', 'icon_emoji' => '🎨', 'color' => '#6366F1', 'sort_order' => 11 ],
        ];
    }

    private static function seed_categories( string $p ): void {
        global $wpdb;
        foreach ( self::category_definitions() as $cat ) {
            $wpdb->insert( $p . 'categories', array_merge( $cat, [
                'is_active'    => 1,
                'listing_type' => 'both',
                'created_at'   => current_time( 'mysql' ),
            ] ) );
        }
    }

    /**
     * Idempotent per-slug category sync — inserts only whatever category
     * rows are missing from wp_gs_categories, never touching or
     * duplicating one that already exists. Safe to call on every version
     * bump even though Seeder::run() itself only seeds once (gated by
     * "subscription_plans table empty?"), exactly the same pattern
     * already established for seed_email_templates() being called
     * directly from Plugin::check_db_version() to reach existing, live
     * sites — see that call site's own comment for the precedent this
     * follows.
     */
    public static function sync_missing_categories( string $p ): void {
        global $wpdb;
        $table = $p . 'categories';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) ) { return; }
        foreach ( self::category_definitions() as $cat ) {
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$table} WHERE slug = %s LIMIT 1", $cat['slug']
            ) );
            if ( $exists ) { continue; }
            $wpdb->insert( $table, array_merge( $cat, [
                'is_active'    => 1,
                'listing_type' => 'both',
                'created_at'   => current_time( 'mysql' ),
            ] ) );
        }
    }

    private static function seed_settings( string $p ): void {
        global $wpdb;
        $settings = [
            'platform_name'           => 'GoodService',
            'platform_tagline'        => 'Find Trusted Local Businesses',
            'platform_email'          => get_option( 'admin_email' ),
            'platform_color_primary'  => '#2563EB',
            'currency'                => 'INR',
            'currency_symbol'         => '₹',
            'listings_per_page'       => '20',
            'auto_approve_listings'   => '0',
            'require_login_to_lead'   => '0',
            'lead_rate_limit'         => '300',
            'booking_enabled'         => '0',
            'reverse_req_enabled'     => '1',
            'complaints_enabled'      => '1',
            'messaging_enabled'       => '1',
            'trust_score_enabled'     => '1',
            'invoice_prefix'          => 'INV',
            'gst_rate'                => '18',
        ];
        foreach ( $settings as $key => $value ) {
            $existing = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$p}settings WHERE setting_key = %s", $key
            ) );
            if ( ! $existing ) {
                $wpdb->insert( $p . 'settings', [
                    'setting_key'   => $key,
                    'setting_value' => $value,
                    'setting_group' => 'general',
                ] );
            }
        }
    }

    public static function seed_email_templates( string $p ): void {
        global $wpdb;
        $site = get_bloginfo('name') ?: 'GoodService';
        $base_style = '<div style="font-family:Arial,sans-serif;max-width:580px;margin:0 auto;padding:0 0 40px">'
            . '<div style="background:#2563EB;padding:20px 28px"><span style="color:#fff;font-weight:800;font-size:1.1rem">{{platform_name}}</span></div>'
            . '<div style="background:#fff;padding:28px 28px 20px;border:1px solid #E2E8F0;border-top:none">';
        $base_footer = '</div><div style="padding:18px 28px;font-size:.74rem;color:#94A3B8;text-align:center">'
            . '© {{year}} {{platform_name}} · <a href="{{platform_url}}" style="color:#2563EB">Visit site</a></div></div>';

        $templates = [
            ['slug'=>'new_lead','name'=>'New Inquiry Received','subject'=>'📞 New inquiry from {{name}} — {{listing_title}}',
             'body'=>$base_style.'<h2 style="color:#1E293B;margin:0 0 12px">New Inquiry Received</h2><p>Hi {{vendor_name}},</p><p><strong>{{name}}</strong> has sent you an inquiry for <strong>{{listing_title}}</strong>.</p><p>Phone: <strong>{{phone}}</strong></p><p>Message: {{message}}</p><p style="margin-top:20px"><a href="{{dashboard_url}}" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View & Reply →</a></p>'.$base_footer],
            ['slug'=>'inquiry_confirmed_client','name'=>'Inquiry Confirmation (Client)','subject'=>'✅ Your inquiry was sent — Reference #INQ-{{lead_id}}',
             'body'=>$base_style.'<h2 style="color:#1E293B;margin:0 0 12px">Inquiry Sent!</h2><p>Hi {{name}},</p><p>Your inquiry has been sent to <strong>{{vendor_name}}</strong>. Reference: <strong>#INQ-{{lead_id}}</strong>.</p><p>They typically reply within <strong>{{avg_reply_time}}</strong>. You\'ll receive an email the moment they respond.</p><p style="margin:14px 0 4px;font-size:13px;color:#64748B">Want a faster reply? Message them directly:</p><p style="margin-bottom:18px"><a href="https://wa.me/{{vendor_whatsapp}}?text=Hi%2C+I+submitted+an+inquiry+on+{{platform_name}}+(Ref+%23INQ-{{lead_id}}).+Can+you+help%3F" style="background:#25D366;color:#fff;padding:9px 18px;border-radius:7px;text-decoration:none;font-weight:700;font-size:13px">&#x1F4AC; WhatsApp {{vendor_name}}</a></p><p style="margin-top:16px"><a href="{{platform_url}}my-account/?section=inquiries" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Track Your Inquiry &#x2192;</a></p>'.$base_footer],
            ['slug'=>'vendor_replied','name'=>'Vendor Replied to Your Inquiry','subject'=>'💬 {{vendor_name}} replied to your inquiry',
             'body'=>$base_style.'<h2 style="color:#1E293B;margin:0 0 12px">You have a reply!</h2><p>Hi {{name}},</p><p><strong>{{vendor_name}}</strong> replied to your inquiry.</p><blockquote style="border-left:3px solid #2563EB;padding:10px 16px;background:#F8FAFC;margin:16px 0">{{reply_text}}</blockquote><p style="margin-top:20px"><a href="{{platform_url}}my-account/?section=inquiries" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Full Reply →</a></p>'.$base_footer],
            ['slug'=>'missed_inquiry_alert','name'=>'Missed Inquiry Alert (Vendor)','subject'=>'⏰ Inquiry from {{client_name}} still needs your reply',
             'body'=>$base_style.'<h2 style="color:#D97706;margin:0 0 12px">Inquiry Waiting 2+ Hours</h2><p>Hi {{vendor_name}},</p><p><strong>{{client_name}}</strong> sent an inquiry to <strong>{{listing_title}}</strong> over 2 hours ago and is still waiting for a reply.</p><p style="background:#FFFBEB;border:1px solid #FDE68A;padding:12px;border-radius:8px">Fast replies win more business. Vendors who reply within 1 hour get 3× more conversions.</p><p style="margin-top:20px"><a href="{{dashboard_url}}" style="background:#D97706;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Reply Now →</a></p>'.$base_footer],
            ['slug'=>'quote_sent','name'=>'Quotation Received (Client)','subject'=>'📋 {{vendor_name}} sent you a quote — ₹{{total}}',
             'body'=>$base_style.'<h2 style="color:#1E293B;margin:0 0 12px">You Received a Quote</h2><p>Hi {{client_name}},</p><p><strong>{{vendor_name}}</strong> sent you a quotation of <strong>₹{{total}}</strong> for your inquiry.</p><p>Quote valid until: {{valid_until}}</p><p>{{cover_note}}</p><div style="margin:20px 0;display:flex;gap:10px"><a href="{{accept_url}}" style="background:#059669;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Accept Quote</a>&nbsp;&nbsp;<a href="{{platform_url}}my-account/?section=inquiries" style="background:#F1F5F9;color:#1E293B;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Details</a></div>'.$base_footer],
            ['slug'=>'quote_accepted','name'=>'Quote Accepted (Vendor)','subject'=>'🎉 {{client_name}} accepted your quote — ₹{{total}}',
             'body'=>$base_style.'<h2 style="color:#059669;margin:0 0 12px">Quote Accepted!</h2><p>Hi {{vendor_name}},</p><p><strong>{{client_name}}</strong> has accepted your quote of <strong>₹{{total}}</strong>. A booking has been created.</p><p style="margin-top:20px"><a href="{{dashboard_url}}" style="background:#059669;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Booking →</a></p>'.$base_footer],
            ['slug'=>'booking_confirmed_vendor','name'=>'Booking Confirmed (Vendor)','subject'=>'📅 Booking confirmed with {{customer_name}} on {{booking_date}}',
             'body'=>$base_style.'<h2 style="color:#1E293B;margin:0 0 12px">Booking Confirmed</h2><p>Hi {{vendor_name}},</p><p>Your booking with <strong>{{customer_name}}</strong> is confirmed for <strong>{{booking_date}}</strong>.</p><p>Address: {{address}}</p><p style="margin-top:20px"><a href="{{dashboard_url}}" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Booking →</a></p>'.$base_footer],
            ['slug'=>'booking_confirmed_client','name'=>'Booking Confirmed (Client)','subject'=>'✅ Booking confirmed with {{vendor_name}} on {{booking_date}}',
             'body'=>$base_style.'<h2 style="color:#059669;margin:0 0 12px">Booking Confirmed!</h2><p>Hi {{customer_name}},</p><p>Your booking with <strong>{{vendor_name}}</strong> is confirmed for <strong>{{booking_date}}</strong>.</p><p>You can track the job status in real time.</p><p style="margin-top:20px"><a href="{{platform_url}}my-account/?section=track" style="background:#059669;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Track Your Booking →</a></p>'.$base_footer],
            ['slug'=>'job_completed_client','name'=>'Job Completed — Leave a Review','subject'=>'🎉 Job completed by {{vendor_name}} — Share your experience',
             'body'=>$base_style.'<h2 style="color:#059669;margin:0 0 12px">Job Completed!</h2><p>Hi {{customer_name}},</p><p><strong>{{vendor_name}}</strong> has marked your job as complete. How did it go?</p><p style="margin-top:20px"><a href="{{review_url}}" style="background:#D97706;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Leave a Review →</a></p>'.$base_footer],
            ['slug'=>'new_review','name'=>'New Review Received (Vendor)','subject'=>'⭐ {{reviewer_name}} left you a {{rating}}-star review',
             'body'=>$base_style.'<h2 style="color:#1E293B;margin:0 0 12px">New Review</h2><p>Hi {{vendor_name}},</p><p><strong>{{reviewer_name}}</strong> left a <strong>{{rating}}-star review</strong> on your listing.</p><blockquote style="border-left:3px solid #D97706;padding:10px 16px;background:#FFFBEB;margin:16px 0">{{review_text}}</blockquote><p style="margin-top:20px"><a href="{{dashboard_url}}" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View & Respond →</a></p>'.$base_footer],
            ['slug'=>'listing_approved','name'=>'Listing Approved','subject'=>'✅ Your listing is now live — {{listing_title}}',
             'body'=>$base_style.'<h2 style="color:#059669;margin:0 0 12px">Listing Approved!</h2><p>Hi {{vendor_name}},</p><p><strong>{{listing_title}}</strong> is now live and visible to customers.</p><p style="margin-top:20px"><a href="{{listing_url}}" style="background:#059669;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Live Listing →</a></p>'.$base_footer],
            ['slug'=>'listing_rejected','name'=>'Listing Requires Changes','subject'=>'⚠️ Your listing needs changes — {{listing_title}}',
             'body'=>$base_style.'<h2 style="color:#DC2626;margin:0 0 12px">Listing Needs Changes</h2><p>Hi {{vendor_name}},</p><p><strong>{{listing_title}}</strong> was not approved. Reason: <strong>{{reason}}</strong></p><p style="margin-top:20px"><a href="{{dashboard_url}}" style="background:#DC2626;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Edit Listing →</a></p>'.$base_footer],
            ['slug'=>'subscription_trial_ending','name'=>'Trial Ending Soon','subject'=>'⏰ Your Pro trial ends in {{days_left}} days',
             'body'=>$base_style.'<h2 style="color:#D97706;margin:0 0 12px">Your Trial is Ending</h2><p>Hi {{vendor_name}},</p><p>Your Pro trial ends in <strong>{{days_left}} days</strong>. Upgrade now to keep access to AI Reply, Analytics, Templates, and more.</p><p style="margin-top:20px"><a href="{{dashboard_url}}?section=subscription" style="background:#D97706;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Upgrade to Pro →</a></p>'.$base_footer],
            ['slug'=>'booking_cancelled_client','name'=>'Booking Cancelled (Client)','subject'=>'❌ Your booking with {{vendor_name}} was cancelled',
             'body'=>$base_style.'<h2 style="color:#DC2626;margin:0 0 12px">Booking Cancelled</h2><p>Hi {{customer_name}},</p><p>Your booking with <strong>{{vendor_name}}</strong> has been cancelled.</p><p>If this wasn\'t expected, feel free to reach out to them directly, or browse other professionals on the platform.</p><p style="margin-top:20px"><a href="{{platform_url}}directory/" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Browse Directory →</a></p>'.$base_footer],
            ['slug'=>'payment_received_vendor','name'=>'Payment Received (Vendor)','subject'=>'💳 Payment received — {{plan_name}} plan activated',
             'body'=>$base_style.'<h2 style="color:#059669;margin:0 0 12px">Payment Successful</h2><p>Hi {{vendor_name}},</p><p>Your payment of <strong>₹{{amount}}</strong> for the <strong>{{plan_name}}</strong> plan was successful. Your plan is now active.</p><p style="color:#64748B;font-size:.9rem">Invoice: <strong>{{invoice_no}}</strong></p><p style="margin-top:20px"><a href="{{dashboard_url}}?section=invoices" style="background:#059669;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Invoice &amp; Receipt →</a></p>'.$base_footer],
            ['slug'=>'payment_failed_vendor','name'=>'Payment Failed (Vendor)','subject'=>'❌ Your subscription payment failed',
             'body'=>$base_style.'<h2 style="color:#DC2626;margin:0 0 12px">Payment Failed</h2><p>Hi {{vendor_name}},</p><p>We were unable to process your subscription payment. Your plan features may be affected until this is resolved.</p><p style="margin-top:20px"><a href="{{dashboard_url}}?section=subscription" style="background:#DC2626;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Update Payment Details →</a></p>'.$base_footer],
            // ENTERPRISE-AUDIT FIX (Part 2, High — dunning cascade): escalating
            // reminder sent by Cron::payment_dunning_cascade() at each stage of
            // the grace period, and the final notice sent when the grace period
            // expires unresolved and the vendor is auto-downgraded to Free. See
            // SubscriptionService::start_or_touch_dunning() and Cron.php.
            ['slug'=>'payment_dunning_reminder','name'=>'Payment Still Failing — Reminder','subject'=>'⏰ Action needed: your payment is still failing ({{days_left}} days left)',
             'body'=>$base_style.'<h2 style="color:#D97706;margin:0 0 12px">Your Payment Is Still Failing</h2><p>Hi {{vendor_name}},</p><p>We\'ve been unable to charge your subscription since <strong>{{failed_since}}</strong>. Please update your payment details within <strong>{{days_left}} day(s)</strong> to avoid losing your <strong>{{plan_name}}</strong> plan features.</p><p style="margin-top:20px"><a href="{{dashboard_url}}?section=subscription" style="background:#D97706;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Update Payment Details →</a></p>'.$base_footer],
            ['slug'=>'subscription_downgraded_dunning','name'=>'Subscription Downgraded — Payment Grace Period Ended','subject'=>'⚠️ Your {{plan_name}} plan was cancelled — payment could not be collected',
             'body'=>$base_style.'<h2 style="color:#DC2626;margin:0 0 12px">Plan Cancelled — Payment Not Resolved</h2><p>Hi {{vendor_name}},</p><p>We were unable to collect payment for your <strong>{{plan_name}}</strong> plan despite several reminders since <strong>{{failed_since}}</strong>, so your account has been moved to the free plan. Your listings remain live, but paid-plan features are no longer active.</p><p style="margin-top:20px"><a href="{{dashboard_url}}?section=plans" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Resubscribe →</a></p>'.$base_footer],
            ['slug'=>'vendor_suspended','name'=>'Vendor Account Suspended','subject'=>'⛔ Your vendor account has been suspended',
             'body'=>$base_style.'<h2 style="color:#DC2626;margin:0 0 12px">Account Suspended</h2><p>Hi {{vendor_name}},</p><p>Your vendor account on {{platform_name}} has been suspended. Your listings are no longer visible to customers.</p><p>If you believe this is an error or would like more information, please contact our support team.</p>'.$base_footer],
            ['slug'=>'vendor_reactivated','name'=>'Vendor Account Reactivated','subject'=>'✅ Your vendor account has been reactivated',
             'body'=>$base_style.'<h2 style="color:#059669;margin:0 0 12px">Welcome Back!</h2><p>Hi {{vendor_name}},</p><p>Good news — your vendor account on {{platform_name}} has been reactivated. Your listings are visible again and you have full access to your dashboard.</p><p style="margin-top:20px"><a href="{{dashboard_url}}" style="background:#059669;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Go to Dashboard →</a></p>'.$base_footer],
            ['slug'=>'subscription_cancelled_vendor','name'=>'Subscription Cancelled (Vendor)','subject'=>'📋 Your subscription has been cancelled',
             'body'=>$base_style.'<h2 style="color:#D97706;margin:0 0 12px">Subscription Cancelled</h2><p>Hi {{vendor_name}},</p><p>Your subscription has been cancelled as requested. You are now on the free plan — your listings remain live, but paid-plan features (like featured placement) are no longer active.</p><p style="margin-top:20px"><a href="{{dashboard_url}}?section=plans" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Plans →</a></p>'.$base_footer],
            ['slug'=>'subscription_expired_vendor','name'=>'Subscription Expired (Vendor)','subject'=>'⏰ Your subscription has expired',
             'body'=>$base_style.'<h2 style="color:#DC2626;margin:0 0 12px">Subscription Expired</h2><p>Hi {{vendor_name}},</p><p>Your subscription has expired and you have been moved to the free plan. Renew anytime to restore your paid features, including featured placement and priority ranking.</p><p style="margin-top:20px"><a href="{{dashboard_url}}?section=plans" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Renew Now →</a></p>'.$base_footer],
            ['slug'=>'password_changed_alert','name'=>'Password Changed Security Alert','subject'=>'🔒 Your password was just changed',
             'body'=>$base_style.'<h2 style="color:#1E293B;margin:0 0 12px">Password Changed</h2><p>Hi {{name}},</p><p>This confirms your password on {{platform_name}} was changed on {{changed_at}}.</p><p style="background:#FFFBEB;border:1px solid #FDE68A;padding:12px;border-radius:8px;font-size:.88rem">If you did not make this change, your account may be compromised — please contact support immediately and reset your password again.</p>'.$base_footer],
            ['slug'=>'vendor_verified_alert','name'=>'Vendor Account Verified','subject'=>'✅ Your business is now verified',
             'body'=>$base_style.'<h2 style="color:#7C3AED;margin:0 0 12px">You\'re Verified!</h2><p>Hi {{vendor_name}},</p><p>Great news — your business has been verified on {{platform_name}}. A verified badge now appears on your listings, helping build trust with customers.</p><p style="margin-top:20px"><a href="{{dashboard_url}}?section=profile" style="background:#7C3AED;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Your Profile →</a></p>'.$base_footer],
            ['slug'=>'verify_email_address','name'=>'Verify Your Email Address','subject'=>'📧 Please verify your email address',
             'body'=>$base_style.'<h2 style="color:#1E293B;margin:0 0 12px">Verify Your Email</h2><p>Hi {{name}},</p><p>Please confirm this is your email address to complete your account setup on {{platform_name}}.</p><p style="margin-top:20px"><a href="{{verify_url}}" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Verify Email Address →</a></p><p style="color:#94A3B8;font-size:.82rem;margin-top:16px">This link expires in 24 hours.</p>'.$base_footer],
            ['slug'=>'listing_suspended_vendor','name'=>'Listing Suspended (Vendor)','subject'=>'⛔ Your listing has been suspended',
             'body'=>$base_style.'<h2 style="color:#DC2626;margin:0 0 12px">Listing Suspended</h2><p>Hi {{vendor_name}},</p><p>Your listing <strong>"{{listing_title}}"</strong> has been suspended and is no longer visible to customers.</p><p>If you believe this is an error or would like more information, please contact our support team.</p>'.$base_footer],
            ['slug'=>'listing_restored_vendor','name'=>'Listing Restored (Vendor)','subject'=>'✅ Your listing is live again',
             'body'=>$base_style.'<h2 style="color:#059669;margin:0 0 12px">Listing Restored</h2><p>Hi {{vendor_name}},</p><p>Good news — your listing <strong>"{{listing_title}}"</strong> has been restored and is visible to customers again.</p><p style="margin-top:20px"><a href="{{dashboard_url}}?section=listings" style="background:#059669;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Listing →</a></p>'.$base_footer],
            ['slug'=>'lead_won_client','name'=>'Inquiry Accepted (Client)','subject'=>'✅ {{vendor_name}} accepted your inquiry',
             'body'=>$base_style.'<h2 style="color:#059669;margin:0 0 12px">Good News!</h2><p>Hi {{customer_name}},</p><p><strong>{{vendor_name}}</strong> has accepted your inquiry and will be in touch shortly.</p><p style="margin-top:20px"><a href="{{platform_url}}my-account/?section=inquiries" style="background:#059669;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Inquiry →</a></p>'.$base_footer],
            ['slug'=>'lead_lost_client','name'=>'Inquiry Update (Client)','subject'=>'Update on your inquiry to {{vendor_name}}',
             'body'=>$base_style.'<h2 style="color:#64748B;margin:0 0 12px">Inquiry Update</h2><p>Hi {{customer_name}},</p><p><strong>{{vendor_name}}</strong> is unable to take on your inquiry at this time.</p><p>Don\'t worry — there are other qualified professionals ready to help.</p><p style="margin-top:20px"><a href="{{platform_url}}directory/" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Browse Other Professionals →</a></p>'.$base_footer],
            ['slug'=>'welcome','name'=>'Welcome Email','subject'=>'Welcome to {{platform_name}}!',
             'body'=>$base_style.'<h2 style="color:#2563EB;margin:0 0 12px">Welcome to {{platform_name}}!</h2><p>Hi {{name}},</p><p>Your account is ready. Start exploring trusted local professionals near you.</p><p style="margin-top:20px"><a href="{{platform_url}}" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Get Started →</a></p>'.$base_footer],
            ['slug'=>'vendor_monthly_scorecard','name'=>'Vendor Monthly Performance Scorecard','subject'=>'📊 Your {{business_name}} performance scorecard',
             'body'=>$base_style.'<h2 style="color:#1E293B;margin:0 0 12px">Your Monthly Scorecard</h2><p>Hi there,</p><p>Here\'s how <strong>{{business_name}}</strong> performed over the last 30 days:</p><table style="width:100%;border-collapse:collapse;margin:16px 0"><tr><td style="padding:8px 0;color:#64748B">Trust Score</td><td style="padding:8px 0;text-align:right;font-weight:700">{{trust_score}}</td></tr><tr style="border-top:1px solid #F1F5F9"><td style="padding:8px 0;color:#64748B">Response Rate</td><td style="padding:8px 0;text-align:right;font-weight:700">{{response_rate}}%</td></tr><tr style="border-top:1px solid #F1F5F9"><td style="padding:8px 0;color:#64748B">Avg. Reply Time</td><td style="padding:8px 0;text-align:right;font-weight:700">{{avg_reply_minutes}} min</td></tr><tr style="border-top:1px solid #F1F5F9"><td style="padding:8px 0;color:#64748B">Jobs Completed</td><td style="padding:8px 0;text-align:right;font-weight:700">{{total_jobs_done}}</td></tr><tr style="border-top:1px solid #F1F5F9"><td style="padding:8px 0;color:#64748B">Average Rating</td><td style="padding:8px 0;text-align:right;font-weight:700">{{avg_rating}} ★</td></tr></table><p style="margin-top:20px"><a href="{{platform_url}}vendor/dashboard/?section=scorecard" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Full Scorecard →</a></p>'.$base_footer],
            // ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "No bulk-
            // invite/CSV import of RWA residents — one-at-a-time self-
            // service via access code only"). Sent by
            // RwaService::bulk_invite_residents() (see gs_rwa_bulk_invite_
            // residents in AjaxController.php) — includes the same access
            // code residents already use to self-register, so no new join
            // flow was needed, just a way for the RWA admin to reach many
            // residents at once instead of relying on them finding the
            // code some other way.
            ['slug'=>'rwa_resident_invite','name'=>'RWA Resident Invite','subject'=>'🏢 You\'re invited to join {{society_name}} on {{platform_name}}',
             'body'=>$base_style.'<h2 style="color:#1E3A5F;margin:0 0 12px">You\'re Invited!</h2><p>Hi {{resident_name}},</p><p><strong>{{society_name}}</strong> has invited you to join their resident portal on {{platform_name}}, where you can see RWA-approved vendors and community updates for <strong>Flat {{flat_number}}</strong>.</p><p style="background:#F8FAFC;border:1px solid #E2E8F0;padding:14px;border-radius:8px;text-align:center;margin:18px 0"><span style="font-size:.78rem;color:#64748B">Society Access Code</span><br><strong style="font-size:1.3rem;letter-spacing:.15em;color:#1E3A5F">{{access_code}}</strong></p><p style="margin-top:20px"><a href="{{join_url}}" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Join {{society_name}} →</a></p><p style="color:#94A3B8;font-size:.82rem;margin-top:16px">Sign in (or create a free account), then enter this code on the Join a Society page.</p>'.$base_footer],
        ];
        foreach ( $templates as $tpl ) {
            $existing = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$p}email_templates WHERE slug = %s", $tpl['slug']
            ) );
            if ( ! $existing ) {
                $wpdb->insert( $p . 'email_templates', array_merge( $tpl, [
                    'is_active'  => 1,
                    'created_at' => current_time( 'mysql' ),
                    'updated_at' => current_time( 'mysql' ),
                ] ) );
            }
        }
    }

    /**
     * Seeds gs_whatsapp_category_templates from WhatsAppService::CATEGORY_TEMPLATES
     * so the new "WhatsApp Templates" admin page shows the templates
     * already in active use, pre-populated, rather than an empty list —
     * exact same content, so nothing about actual message behavior
     * changes until an admin explicitly edits one. Idempotent like
     * seed_email_templates() — only inserts rows that don't already exist,
     * safe to call on every plugin activation/upgrade. Seeded as
     * vendor_id=0 (platform default), language='en', status='approved' —
     * live and in use immediately, exactly matching current behavior.
     */
    /**
     * Seeds gs_section_templates with the default library of "View More"
     * popup section types — every type from the original request, given a
     * sensible content_type so the future builder UI knows what editor to
     * show for each. Idempotent — only inserts slugs that don't already
     * exist, so an admin's own edits/additions/deletions here are never
     * overwritten by a later plugin update re-running this seeder.
     */
    public static function seed_section_templates( string $p ): void {
        global $wpdb;
        $defaults = [
            [ 'overview',            'Overview',                    '📋', 'richtext',     'A short, high-level summary of the service or product.' ],
            [ 'about',               'About the Service/Product',   'ℹ️', 'richtext',     'A fuller description than the short listing description.' ],
            [ 'key_features',        'Key Features',                '✨', 'list',         'A bullet list of standout features.' ],
            [ 'benefits',            'Benefits',                    '👍', 'list',         'What the customer gains from choosing this.' ],
            [ 'whats_included',      "What's Included",             '✅', 'list',         'Everything bundled into the price.' ],
            [ 'whats_not_included',  "What's Not Included",         '❌', 'list',         'Exclusions the customer should know about upfront.' ],
            [ 'process',             'Process / How It Works',      '🔄', 'numbered_list','Step-by-step walkthrough of the process.' ],
            [ 'packages',            'Packages',                    '📦', 'cards',        'Tiered package options as comparison cards.' ],
            [ 'pricing_info',        'Pricing Information',         '💰', 'table',        'Detailed pricing breakdown as a table.' ],
            [ 'timeline',            'Timeline',                    '⏱️', 'richtext',     'Expected turnaround or delivery timeline.' ],
            [ 'service_areas',       'Service Areas',                '📍', 'list',         'Cities/regions this is available in.' ],
            [ 'requirements',        'Requirements',                '📝', 'list',         'What the customer needs to provide or arrange.' ],
            [ 'documents_required',  'Documents Required',          '📄', 'list',         'Required documents, listed clearly.' ],
            [ 'eligibility',         'Eligibility',                 '🎯', 'list',         'Who qualifies for this service/product.' ],
            [ 'faqs',                'FAQs',                        '❓', 'faq',          'Frequently asked questions, as an accordion.' ],
            [ 'terms_conditions',    'Terms & Conditions',          '📜', 'richtext',     'Legal/usage terms specific to this offering.' ],
            [ 'warranty_guarantee',  'Warranty / Guarantee',        '🛡️', 'richtext',     'Warranty or guarantee details.' ],
            [ 'return_cancellation', 'Return / Cancellation Policy','↩️', 'richtext',     'Return, refund, or cancellation policy.' ],
            [ 'delivery_info',       'Delivery Information',        '🚚', 'richtext',     'Delivery method, timing, and charges.' ],
            [ 'additional_notes',    'Additional Notes',            '📌', 'richtext',     'Anything else worth mentioning.' ],
            [ 'important_instructions','Important Instructions',    '⚠️', 'highlight',    'Critical instructions, shown in a highlight box.' ],
            // Real feature — explicitly requested: a proper repeatable
            // name/value specifications table (Minimum Order Quantity,
            // Payment Terms, Delivery Time, etc.), distinct from the
            // existing 'table' content_type above (pricing_info) which is
            // a freeform, arbitrary-column table — this one is always
            // exactly two columns (Specification, Value) with its own
            // dedicated add/remove-row editor and its own styled render,
            // matching the two-column spec layout vendors expect. Available
            // wherever this same Manage Details/View More popup is used
            // (Services, Products, Packages, Room Types, Featured
            // Projects, Featured Services, Beauty Services, Home Services
            // Catalogue) since all of them share this one template table.
            [ 'specifications',     'Specifications / Features',   '📐', 'specs',        'A two-column table of specification name → value pairs (e.g. Minimum Order Quantity, Payment Terms, Delivery Time).' ],
        ];
        foreach ( $defaults as $i => [ $slug, $name, $icon, $content_type, $desc ] ) {
            $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$p}section_templates WHERE slug = %s", $slug ) );
            if ( ! $existing ) {
                $wpdb->insert( $p . 'section_templates', [
                    'slug'         => $slug,
                    'name'         => $name,
                    'icon'         => $icon,
                    'content_type' => $content_type,
                    'description'  => $desc,
                    'is_active'    => 1,
                    'sort_order'   => $i * 10,
                    'created_at'   => current_time( 'mysql' ),
                    'updated_at'   => current_time( 'mysql' ),
                ] );
            }
        }
    }

    private static function seed_whatsapp_templates( string $p ): void {
        global $wpdb;
        $labels = [
            'plumber'        => 'Plumber',
            'electrician'    => 'Electrician',
            'ca'             => 'Chartered Accountant',
            'packers-movers' => 'Packers & Movers',
            'pest-control'   => 'Pest Control',
            'ac-repair'      => 'AC Repair',
            'default'        => 'Default (fallback for any category without its own template)',
        ];
        foreach ( \GoodService\Service\WhatsAppService::CATEGORY_TEMPLATES as $slug => $body ) {
            $existing = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$p}whatsapp_category_templates WHERE category_slug = %s AND vendor_id = 0 AND language = 'en'", $slug
            ) );
            if ( ! $existing ) {
                $wpdb->insert( $p . 'whatsapp_category_templates', [
                    'name'          => $labels[ $slug ] ?? ucwords( str_replace( '-', ' ', $slug ) ),
                    'category_slug' => $slug,
                    'body'          => $body,
                    'variables'     => '{{client_name}}, {{vendor_name}}',
                    'is_active'     => 1,
                    'vendor_id'     => 0,
                    'language'      => 'en',
                    'status'        => 'approved',
                    'created_at'    => current_time( 'mysql' ),
                    'updated_at'    => current_time( 'mysql' ),
                ] );
            }
        }
    }

    /**
     * Seed demo vendors, vendor profiles, and one listing each.
     * Called from Admin → Tools → "Seed Demo Vendors" button.
     *
     * Returns array with created/skipped/errors counts and a log of per-vendor status.
     * Safe to call multiple times — skips existing emails.
     * Ensures plans and categories exist first so category lookup never returns 0.
     */
    public static function seed_demo(): array {
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';

        $result = [ 'created' => 0, 'skipped' => 0, 'errors' => 0, 'log' => [] ];

        // 1. Ensure foundation data exists before inserting vendors
        if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$p}subscription_plans" ) === 0 ) {
            self::seed_plans( $p );
            $result['log'][] = '✅ Seeded subscription plans.';
        }
        if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$p}categories" ) === 0 ) {
            self::seed_categories( $p );
            $result['log'][] = '✅ Seeded categories.';
        }
        if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$p}settings" ) === 0 ) {
            self::seed_settings( $p );
        }

        // 2. Demo vendor definitions
        $demo_vendors = [
            [
                'name'     => 'Sharma Plumbing Works',
                'email'    => 'sharma.plumbing@demo.gs',
                'phone'    => '9876511001',
                'bio'      => 'Expert plumbing services for homes and offices. 15+ years experience. Emergency repairs 24/7.',
                'city'     => 'Mumbai',
                'state'    => 'Maharashtra',
                'category' => 'home-services',
                'price_min'=> 299,
                'price_max'=> 2999,
                'tags'     => 'plumber,plumbing,pipe repair,tap,geyser,bathroom',
                'rating'   => 4.6,
                'reviews'  => 38,
            ],
            [
                'name'     => 'TechSolve IT Solutions',
                'email'    => 'techsolve@demo.gs',
                'phone'    => '9876511002',
                'bio'      => 'Full-stack web development, IT support, and cloud services. Serving startups and enterprises since 2015.',
                'city'     => 'Bangalore',
                'state'    => 'Karnataka',
                'category' => 'it-technology',
                'price_min'=> 4999,
                'price_max'=> 49999,
                'tags'     => 'web development,IT support,cloud,React,WordPress,mobile app',
                'rating'   => 4.8,
                'reviews'  => 22,
            ],
            [
                'name'     => 'Glow Beauty Studio',
                'email'    => 'glow.beauty@demo.gs',
                'phone'    => '9876511003',
                'bio'      => 'Premium beauty treatments, bridal makeup, and salon services. Award-winning stylists, 10+ years experience.',
                'city'     => 'Delhi',
                'state'    => 'Delhi',
                'category' => 'beauty-salon',
                'price_min'=> 499,
                'price_max'=> 9999,
                'tags'     => 'beauty,salon,bridal makeup,hair,skincare,facial',
                'rating'   => 4.7,
                'reviews'  => 61,
            ],
            [
                'name'     => 'Mehta & Associates CA',
                'email'    => 'mehta.ca@demo.gs',
                'phone'    => '9876511004',
                'bio'      => 'Chartered accountants specialising in GST, ITR, company registration, and tax planning.',
                'city'     => 'Mumbai',
                'state'    => 'Maharashtra',
                'category' => 'legal-finance',
                'price_min'=> 999,
                'price_max'=> 29999,
                'tags'     => 'CA,chartered accountant,GST,ITR,tax,company registration',
                'rating'   => 4.9,
                'reviews'  => 84,
            ],
            [
                'name'     => 'CleanPro Home Services',
                'email'    => 'cleanpro@demo.gs',
                'phone'    => '9876511005',
                'bio'      => 'Professional home cleaning, deep cleaning, sofa shampooing, and pest control. Trained, background-checked staff.',
                'city'     => 'Hyderabad',
                'state'    => 'Telangana',
                'category' => 'home-services',
                'price_min'=> 599,
                'price_max'=> 4999,
                'tags'     => 'cleaning,deep cleaning,sofa cleaning,pest control,home services',
                'rating'   => 4.5,
                'reviews'  => 127,
            ],
        ];

        // 3. Create each demo vendor
        foreach ( $demo_vendors as $i => $vdata ) {

            // Check if vendor profile already exists for this email
            $existing_uid = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->prefix}users WHERE user_email = %s", $vdata['email']
            ) );
            if ( $existing_uid ) {
                $existing_profile = $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM {$p}vendor_profiles WHERE user_id = %d", $existing_uid
                ) );
                if ( $existing_profile ) {
                    $result['skipped']++;
                    $result['log'][] = "⏭ Skipped: {$vdata['name']} (profile already exists)";
                    continue;
                }
            }

            // Create WP user (or reuse existing one without a profile)
            $username = 'demo_vendor_' . ( $i + 1 );
            if ( username_exists( $username ) ) {
                $username .= '_' . substr( md5( $vdata['email'] ), 0, 4 );
            }

            $user_id = $existing_uid ?: wp_insert_user( [
                'user_login'   => $username,
                'user_pass'    => wp_generate_password( 16 ),
                'user_email'   => $vdata['email'],
                'display_name' => $vdata['name'],
                'role'         => 'gs_vendor',
            ] );

            if ( is_wp_error( $user_id ) ) {
                $result['errors']++;
                $result['log'][] = "❌ User create failed for {$vdata['name']}: " . $user_id->get_error_message();
                continue;
            }

            // Ensure gs_vendor role is assigned
            $u = new \WP_User( (int) $user_id );
            if ( ! in_array( 'gs_vendor', (array) $u->roles, true ) ) {
                $u->set_role( 'gs_vendor' );
            }

            // Resolve category — fallback to first active category if slug not found
            $cat_id = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$p}categories WHERE slug = %s AND is_active=1 LIMIT 1", $vdata['category']
            ) );
            if ( ! $cat_id ) {
                $cat_id = (int) $wpdb->get_var(
                    "SELECT id FROM {$p}categories WHERE is_active=1 ORDER BY sort_order ASC LIMIT 1"
                );
            }

            // Deterministic slugs based on email hash — safe on re-run
            $hash         = substr( md5( $vdata['email'] ), 0, 6 );
            $profile_slug = sanitize_title( $vdata['name'] ) . '-' . $hash;
            $listing_slug = sanitize_title( $vdata['name'] ) . '-services-' . $hash;

            // Insert vendor profile
            $profile_ok = $wpdb->insert( $p . 'vendor_profiles', [
                'user_id'             => (int) $user_id,
                'business_name'       => $vdata['name'],
                'slug'                => $profile_slug,
                'phone'               => $vdata['phone'],
                'email'               => $vdata['email'],
                'bio'                 => $vdata['bio'],
                'city'                => $vdata['city'],
                'state'               => $vdata['state'],
                'is_active'           => 1,
                'verification_status' => 'verified',
                'avg_rating'          => $vdata['rating'],
                'response_rate'       => 85,
                'trust_score'         => 80,
                'created_at'          => current_time( 'mysql' ),
            ] );

            if ( ! $profile_ok ) {
                $result['errors']++;
                $result['log'][] = "❌ vendor_profiles insert failed for {$vdata['name']}: " . $wpdb->last_error;
                continue;
            }

            $profile_id = (int) $wpdb->insert_id;

            // Insert demo listing
            $listing_ok = $wpdb->insert( $p . 'listings', [
                'vendor_id'    => $profile_id,
                'title'        => $vdata['name'] . ' — ' . $vdata['city'],
                'slug'         => $listing_slug,
                'short_desc'   => $vdata['bio'],
                'full_desc'    => '<p>' . esc_html( $vdata['bio'] ) . '</p>',
                'category_id'  => $cat_id,
                'city'         => $vdata['city'],
                'state'        => $vdata['state'],
                'phone'        => $vdata['phone'],
                'email'        => $vdata['email'],
                'tags'         => $vdata['tags'],
                'price_min'    => $vdata['price_min'],
                'price_max'    => $vdata['price_max'],
                'avg_rating'   => $vdata['rating'],
                'review_count' => $vdata['reviews'],
                'status'       => 'active',
                'is_featured'  => ( $i < 2 ) ? 1 : 0,
                'created_at'   => current_time( 'mysql' ),
                'updated_at'   => current_time( 'mysql' ),
            ] );

            if ( ! $listing_ok ) {
                $result['errors']++;
                $result['log'][] = "⚠️ Profile created but listing failed for {$vdata['name']}: " . $wpdb->last_error;
                $result['created']++;
                continue;
            }

            $result['created']++;
            $result['log'][] = "✅ Created: {$vdata['name']} ({$vdata['city']})";
        }

        return $result;
    }



    /** Seed AI diagnosis templates for key categories (Moat 1). */
    public static function seed_diagnosis_templates(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'gs_diagnosis_templates';

        $templates = [
            [ 'plumber', 'Where exactly is the plumbing issue — kitchen, bathroom, or somewhere else?', 4,
              'You are a plumbing diagnosis assistant. Ask 2-4 short questions about: location (kitchen/bathroom/toilet/pipeline), symptoms (dripping/no water/overflow/burst), duration, urgency. After gathering context output ONLY valid JSON: {"summary":"...","location":"...","symptoms":["..."],"urgency":"emergency|urgent|normal|flexible","estimated_work":"...","price_range":"₹X-Y","diy_possible":false,"vendor_instruction":"..."}' ],
            [ 'electrician', 'What is the electrical problem — no power, short circuit, new fitting, or something else?', 4,
              'You are an electrical diagnosis assistant. SAFETY FIRST: sparks/burning smell/exposed wires = emergency. Ask about location, nature of problem, when it started. Output JSON: {"summary":"...","location":"...","symptoms":["..."],"urgency":"emergency|urgent|normal|flexible","estimated_work":"...","price_range":"₹X-Y","diy_possible":false,"vendor_instruction":"...","safety_warning":null}' ],
            [ 'ac-repair', 'What is your AC doing — not cooling, making noise, leaking water, or not switching on?', 4,
              'You are an AC diagnosis assistant. Ask about AC brand/age, type (split/window), specific symptom, last service date. Output JSON: {"summary":"...","ac_type":"split|window|cassette","symptoms":["..."],"urgency":"normal|urgent","likely_cause":"...","estimated_work":"...","price_range":"₹X-Y","diy_possible":false,"vendor_instruction":"..."}' ],
            [ 'pest-control', 'Which pest are you dealing with — cockroaches, termites, rats, bed bugs, mosquitoes, or other?', 3,
              'You are a pest control diagnosis assistant. Ask about: pest type, severity, how long, affected area size. Output JSON: {"summary":"...","pest_type":"...","severity":"mild|moderate|severe","area_sqft":"...","urgency":"normal|urgent","treatment_type":"spray|gel|fumigation|heat","price_range":"₹X-Y","diy_possible":false,"vendor_instruction":"..."}' ],
            [ 'carpenter', 'What carpentry work do you need — repair, new furniture, door/window, or something else?', 3,
              'You are a carpentry diagnosis assistant. Ask about work type, materials needed, approximate size/dimensions. Output JSON: {"summary":"...","work_type":"repair|new|installation","materials":"wood_type","estimated_work":"...","price_range":"₹X-Y","diy_possible":false,"vendor_instruction":"..."}' ],
        ];

        foreach ( $templates as [ $cat, $opening, $max_turns, $prompt ] ) {
            $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE category_slug=%s", $cat ) );
            if ( ! $exists ) {
                $wpdb->insert( $table, [
                    'category_slug'    => $cat,
                    'opening_question' => $opening,
                    'max_turns'        => $max_turns,
                    'system_prompt'    => $prompt,
                    'is_active'        => 1,
                    'created_at'       => current_time( 'mysql' ),
                ] );
            }
        }
    }

    private static function seed_reply_templates( string $p ): void {
        global $wpdb;
        $tbl = $p . 'reply_templates';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) { return; }
        if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tbl} WHERE vendor_id=0" ) > 0 ) { return; }

        $templates = [
            // General
            [ 'name' => 'Professional greeting',          'body' => 'Thank you for reaching out, {{client_name}}! I have received your inquiry for {{service}} and will get back to you with more details shortly. Could you please share your preferred date and time?', 'category_slug' => '' ],
            [ 'name' => 'Request more details',           'body' => 'Hi {{client_name}}, thank you for your inquiry. To give you an accurate quote for {{service}}, could you please share: 1) Your address/area 2) Preferred date 3) Any specific requirements?', 'category_slug' => '' ],
            [ 'name' => 'Quote follow-up',                'body' => 'Hi {{client_name}}, just following up on the quote I sent for {{service}}. Please let me know if you have any questions or need any adjustments. Looking forward to serving you!', 'category_slug' => '' ],
            [ 'name' => 'Confirm appointment',            'body' => 'Hi {{client_name}}, confirmed! I will be at your location on the scheduled date for {{service}}. Please ensure someone is available. If you need to reschedule, let me know 24 hours in advance.', 'category_slug' => '' ],
            [ 'name' => 'Visit charge notice',            'body' => 'Hi {{client_name}}, thank you for your interest. Please note there is a visiting charge of {{visiting_charge}} for the initial inspection/assessment, which will be adjusted against the final bill if you proceed. When would you like me to visit?', 'category_slug' => '' ],
            // Plumbing
            [ 'name' => 'Plumbing availability',          'body' => 'Hi {{client_name}}, I can help with your plumbing issue. I am available today after 2 PM and tomorrow morning. Could you tell me the exact problem — is it a leak, blockage, or installation? This helps me bring the right tools.', 'category_slug' => 'plumber' ],
            // Electrical
            [ 'name' => 'Electrical enquiry response',    'body' => 'Hi {{client_name}}, thank you for contacting me for electrical work. I need to inspect the site before giving a final quote. However, based on what you have described, it should take about 2-3 hours. When can I visit?', 'category_slug' => 'electrician' ],
            // CA / Tax
            [ 'name' => 'CA services response',           'body' => 'Hi {{client_name}}, I can certainly help with {{service}}. Could you please share: 1) Type of entity (individual/business) 2) Financial year 3) Any specific concerns? This will help me quote accurately. Happy to schedule a call.', 'category_slug' => 'ca' ],
            // Cleaning
            [ 'name' => 'Cleaning enquiry',               'body' => 'Hi {{client_name}}, thank you for your cleaning enquiry. Please share: 1) Area size (sq ft) 2) Type of cleaning needed 3) Any specific areas of concern. I will send you a transparent quote within the hour!', 'category_slug' => 'cleaning' ],
            // Pest control
            [ 'name' => 'Pest control quote',             'body' => 'Hi {{client_name}}, I can solve your pest problem. My treatment is 100% safe for family and pets. For a home under 1000 sq ft, the cost is approx ₹1,200-1,800 depending on the pest type. Shall I confirm a slot?', 'category_slug' => 'pest-control' ],
        ];

        foreach ( $templates as $t ) {
            $wpdb->insert( $tbl, [
                'vendor_id'     => 0,
                'name'          => $t['name'],
                'body'          => $t['body'],
                'category_slug' => $t['category_slug'],
                'use_count'     => 0,
                'created_at'    => current_time('mysql'),
                'updated_at'    => current_time('mysql'),
            ] );
        }
    }

}
