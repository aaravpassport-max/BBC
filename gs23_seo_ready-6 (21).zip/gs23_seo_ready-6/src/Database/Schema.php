<?php
namespace GoodService\Database;

/**
 * Schema — Installs all 36 custom GoodService tables.
 * Zero dependency on wp_posts / wp_postmeta.
 * All tables are indexed for performance.
 */
final class Schema {

    /** Stores result of last upgrade_columns() call for reporting */
    public static array $last_upgrade_result = ['added'=>[],'failed'=>[],'skipped'=>0];


    public static function install( bool $skip_delta = false ): void {
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';

        if ( ! $skip_delta ) {
            // Full install — run dbDelta to create/update table structure
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            $c = $wpdb->get_charset_collate();
            $tables = self::get_table_definitions( $p, $c );
            foreach ( $tables as $sql ) {
                $sql = str_replace( 'CREATE TABLE IF NOT EXISTS', 'CREATE TABLE', $sql );
                $sql = preg_replace( '/,\s*FULLTEXT KEY \w+ \([^)]+\)/', '', $sql );
                dbDelta( $sql );
            }
            self::create_2fa_tables( $p, $c );
            self::create_dispute_tables( $p, $c );
            self::create_fraud_tables( $p, $c );
            self::create_wallet_tables( $p, $c );
            self::create_seo_microsite_entry_table( $p, $c );
            self::add_fulltext_indexes( $p );
        }

        // Always ensure performance indexes exist (safe — checks before adding)
        self::add_performance_indexes( $p );

        // Always run upgrade_columns — fast SHOW COLUMNS approach
        self::upgrade_columns( $p );

        // Migrate ENUM columns that gained new values in upgrades
        // Safe: ALTER TABLE MODIFY only changes the ENUM definition; data preserved
        self::migrate_enum_columns( $p );

        // Backfill gs_listing_cities from existing service_cities JSON + primary city.
        // INSERT IGNORE makes this idempotent — safe to run on every DB Upgrade.
        self::backfill_listing_cities( $p );
    }

    /**
     * Backfill gs_listing_cities for ALL existing listings.
     *
     * Why needed: vendors already have service_cities data in the LONGTEXT column.
     * This reads that JSON, plus the primary city column, and populates the new
     * indexed join table so city filtering works instantly without LIKE scans.
     *
     * Processes in batches of 500 to avoid PHP memory exhaustion on large datasets.
     * INSERT IGNORE skips already-inserted rows — safe to run multiple times.
     */
    public static function backfill_listing_cities( string $p ): void {
        global $wpdb;

        $tbl_cities   = $p . 'listing_cities';
        $tbl_listings = $p . 'listings';

        // Table may not exist yet on first run before dbDelta has created it
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl_cities}'" ) ) { return; }

        $batch  = 500;
        $offset = 0;

        do {
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT id, city, service_cities
                 FROM {$tbl_listings}
                 WHERE status IN ('active','pending','suspended','inactive')
                 ORDER BY id ASC
                 LIMIT %d OFFSET %d",
                $batch, $offset
            ) );

            if ( empty( $rows ) ) { break; }

            $values = [];
            foreach ( $rows as $row ) {
                $lid     = (int) $row->id;
                $primary = trim( (string) ( $row->city ?? '' ) );

                // Always insert the primary city
                if ( $primary !== '' ) {
                    $values[] = $wpdb->prepare( '(%d, %s)', $lid, $primary );
                }

                // Service cities from JSON array e.g. ["Mumbai","Thane","Pune"]
                if ( ! empty( $row->service_cities ) ) {
                    $cities = json_decode( $row->service_cities, true );
                    if ( is_array( $cities ) ) {
                        foreach ( $cities as $svc_city ) {
                            $svc_city = trim( (string) $svc_city );
                            // Skip empty and duplicates of primary (UNIQUE KEY handles it too)
                            if ( $svc_city !== '' && $svc_city !== $primary ) {
                                $values[] = $wpdb->prepare( '(%d, %s)', $lid, $svc_city );
                            }
                        }
                    }
                }
            }

            if ( ! empty( $values ) ) {
                // INSERT IGNORE: silently skips rows that violate UNIQUE KEY uq_listing_city
                $wpdb->query(
                    "INSERT IGNORE INTO {$tbl_cities} (listing_id, city) VALUES "
                    . implode( ', ', $values )
                );
            }

            $offset += $batch;

        } while ( count( $rows ) === $batch );
    }

    /** Fast upgrade — only adds missing columns, skips slow dbDelta table rebuild */
    public static function upgrade_only(): void {
        global $wpdb;
        self::install( true );
    }

    /** Safely add new columns to existing tables for upgrades */
    public static function upgrade_columns( string $p ): void {
        global $wpdb;
        $cols = [
            // Real fix — confirmed limitation: auto-generated recurring-service
            // leads (Cron::trigger_subscription_inquiries()) had no reliable way
            // to be traced back to the service plan that generated them except
            // fragile text-matching against the lead's message string. This
            // column lets the Service Plans screen show a real, exact count and
            // link straight to the matching leads (see 'service-plans' case,
            // vendor-dashboard.php).
            [ "{$p}leads", 'service_plan_id', "BIGINT UNSIGNED DEFAULT NULL" ],
            [ "{$p}leads", 'product_name',   "VARCHAR(255) DEFAULT ''" ],
            [ "{$p}leads", 'product_price',  "VARCHAR(50) DEFAULT ''" ],
            [ "{$p}leads", 'quantity',        "VARCHAR(50) DEFAULT ''" ],
            [ "{$p}leads", 'purchase_date',   "DATE DEFAULT NULL" ],
            [ "{$p}leads", 'callback_date',   "DATETIME DEFAULT NULL" ],
            [ "{$p}leads", 'vendor_notes',    "TEXT" ],
            // ── Inquiry management system (Fluent Forms integration) ──────────
            [ "{$p}leads", 'fluent_entry_id', "INT DEFAULT 0" ],
            [ "{$p}leads", 'company_name',    "VARCHAR(255) DEFAULT ''" ],
            [ "{$p}leads", 'extra_fields',    "LONGTEXT" ],
            [ "{$p}leads", 'priority',        "VARCHAR(10) DEFAULT 'normal'" ],
            [ "{$p}leads", 'is_starred',      "TINYINT(1) DEFAULT 0" ],
            [ "{$p}leads", 'replied_at',      "DATETIME DEFAULT NULL" ],
            [ "{$p}leads", 'replied_by',      "BIGINT UNSIGNED DEFAULT 0" ],
            // ── Customer portal ───────────────────────────────────────────────
            [ "{$p}leads", 'customer_user_id', "BIGINT UNSIGNED DEFAULT 0" ],
            // Real fix — Regional Account Managers' "Awaiting Updates" metric had
            // no way to distinguish "genuinely stale" from "an RAM checked this
            // recently and it's still fine" — a listing that needs no content
            // change kept re-appearing on the stale list every day forever.
            // This column lets a manager mark a listing reviewed without
            // forcing an artificial content edit; the staleness query (see
            // 'regional-managers' case, admin-dashboard.php) now compares
            // against whichever of updated_at/reviewed_at is more recent.
            [ "{$p}listings", 'reviewed_at', "DATETIME NULL DEFAULT NULL" ],
            // Real fix — confirmed limitation: dispute resolutions that trigger a
            // real, immediate refund/wallet-credit had no second-admin approval
            // step at any amount, so a mis-clicked resolution type issued real
            // money with no cooldown. These columns hold an intended resolution
            // above a configurable threshold pending a DIFFERENT admin's
            // confirmation (see 'disputes' case, admin-dashboard.php, and
            // AjaxController::resolveDispute()/confirmDisputeRefund()) — added
            // as new columns rather than widening the existing status ENUM, to
            // avoid an ALTER...MODIFY on a column already in production use.
            [ "{$p}disputes", 'pending_refund_by',         "BIGINT UNSIGNED DEFAULT NULL" ],
            [ "{$p}disputes", 'pending_refund_resolution', "VARCHAR(30) DEFAULT NULL" ],
            [ "{$p}disputes", 'pending_refund_note',       "TEXT" ],
            [ "{$p}disputes", 'pending_refund_amount',     "DECIMAL(10,2) DEFAULT NULL" ],
            [ "{$p}disputes", 'pending_refund_requested_at', "DATETIME DEFAULT NULL" ],
            [ "{$p}listings", 'seo_title',         "VARCHAR(255) DEFAULT ''" ],
            [ "{$p}listings", 'seo_desc',          "TEXT" ],
            [ "{$p}listings", 'seo_keywords',      "TEXT" ],
            [ "{$p}listings", 'seo_focus_keyword', "VARCHAR(200) DEFAULT ''" ],
            [ "{$p}listings", 'og_image',          "VARCHAR(500) DEFAULT ''" ],
            [ "{$p}listings", 'seo_robots',        "VARCHAR(50) DEFAULT 'index,follow'" ],
            [ "{$p}listings", 'map_embed',    "VARCHAR(500) DEFAULT ''" ],
            [ "{$p}listings", 'address',      "TEXT" ],
            [ "{$p}listings", 'location_id',  "INT UNSIGNED DEFAULT 0" ],
            [ "{$p}listings", 'country',      "VARCHAR(100) DEFAULT ''" ],
            [ "{$p}listings", 'location_name',"VARCHAR(255) DEFAULT ''" ],
            [ "{$p}listings", 'ranking_score',  "DECIMAL(8,4) DEFAULT 0.0000" ],
            [ "{$p}listings", 'listing_uid',    "VARCHAR(20) DEFAULT ''" ],
            [ "{$p}listings", 'swiper_enabled', "TINYINT(1) DEFAULT 0" ],
            [ "{$p}listings", 'swiper_settings', "TEXT DEFAULT NULL" ],
            [ "{$p}swiper_slides", 'image_mobile', "VARCHAR(500) DEFAULT ''" ],
            [ "{$p}swiper_slides", 'device', "ENUM('all','desktop','mobile') DEFAULT 'all'" ],
            [ "{$p}swiper_slides", 'img_fit_desktop', "VARCHAR(20) DEFAULT 'cover'" ],
            [ "{$p}swiper_slides", 'img_fit_mobile', "VARCHAR(20) DEFAULT 'cover'" ],
            [ "{$p}swiper_slides", 'img_position_desktop', "VARCHAR(20) DEFAULT 'center'" ],
            [ "{$p}swiper_slides", 'img_position_mobile', "VARCHAR(20) DEFAULT 'center'" ],
            [ "{$p}swiper_slides", 'img_zoom_desktop', "INT UNSIGNED DEFAULT 100" ],
            [ "{$p}swiper_slides", 'img_zoom_mobile', "INT UNSIGNED DEFAULT 100" ],
            [ "{$p}swiper_slides", 'height_override_desktop', "INT UNSIGNED DEFAULT 0" ],
            [ "{$p}swiper_slides", 'height_override_mobile', "INT UNSIGNED DEFAULT 0" ],
            [ "{$p}media", 'tags', "VARCHAR(500) DEFAULT ''" ],
            [ "{$p}categories",'parent_id',   "INT UNSIGNED DEFAULT 0" ],
            [ "{$p}subscription_plans",'max_images',   "INT DEFAULT 10" ],
            [ "{$p}subscription_plans",'show_video',   "TINYINT(1) DEFAULT 0" ],
            [ "{$p}subscription_plans",'can_products', "TINYINT(1) DEFAULT 0" ],
            // Feature gating: inquiry and booking modules are premium features.
            // Free plan (price_monthly=0) has both off by default; paid plans have them on.
            [ "{$p}subscription_plans",'allow_inquiry_module', "TINYINT(1) DEFAULT 0" ],
            [ "{$p}subscription_plans",'allow_booking_module', "TINYINT(1) DEFAULT 0" ],
            // How many inquiry-module categories a vendor on this plan may turn
            // accepts_booking=true for, at the same time. 0 = unlimited (kept as
            // the safe default for existing installs — an admin must explicitly
            // set a number for it to actually restrict anything; see Section 6/7
            // of the inquiry/booking audit for the worked example: Starter=1,
            // Professional=unlimited(0)).
            [ "{$p}subscription_plans",'max_booking_modules', "TINYINT UNSIGNED DEFAULT 0" ],
            [ "{$p}subscription_plans",'badge_text',   "VARCHAR(50) DEFAULT ''" ],
            [ "{$p}subscription_plans",'is_featured',  "TINYINT(1) DEFAULT 0" ],
            [ "{$p}subscription_plans",'priority_support',   "TINYINT(1) DEFAULT 0" ],
            [ "{$p}subscription_plans",'price_quarterly',    "DECIMAL(10,2) DEFAULT 0.00" ],  // MAJOR FIX #14
            // ── Listing Page Builder fields (v7) ─────────────────────────────
            [ "{$p}listings", 'brand_color',            "VARCHAR(20) DEFAULT ''" ],
            [ "{$p}listings", 'brand_color2',           "VARCHAR(20) DEFAULT ''" ],
            [ "{$p}listings", 'accent_color',           "VARCHAR(20) DEFAULT ''" ],
            [ "{$p}listings", 'section_bg',             "VARCHAR(20) DEFAULT ''" ],
            [ "{$p}listings", 'text_color',             "VARCHAR(20) DEFAULT ''" ],
            [ "{$p}listings", 'muted_color',            "VARCHAR(20) DEFAULT ''" ],
            [ "{$p}listings", 'logo_radius',            "TINYINT DEFAULT 10" ],
            [ "{$p}listings", 'logo_shadow',            "VARCHAR(10) DEFAULT 'none'" ],
            [ "{$p}listings", 'logo_border_w',          "TINYINT DEFAULT 0" ],
            [ "{$p}listings", 'logo_border_c',          "VARCHAR(20) DEFAULT '#E2E8F0'" ],
            [ "{$p}listings", 'logo_padding',           "TINYINT DEFAULT 0" ],
            [ "{$p}listings", 'logo_bg',                "VARCHAR(20) DEFAULT ''" ],
            [ "{$p}listings", 'banner_height',          "SMALLINT DEFAULT 400" ],
            [ "{$p}listings", 'banner_radius',          "TINYINT DEFAULT 0" ],
            [ "{$p}listings", 'banner_overlay',         "VARCHAR(20) DEFAULT '#000000'" ],
            [ "{$p}listings", 'banner_opacity',         "TINYINT DEFAULT 0" ],
            [ "{$p}listings", 'hero_data',               'LONGTEXT' ],
            [ "{$p}listings", 'trust_bar_text',          "VARCHAR(500) DEFAULT ''" ],
            [ "{$p}listings", 'gallery_title',            "VARCHAR(255) DEFAULT ''" ],
            [ "{$p}listings", 'about_data',              'LONGTEXT' ],
            [ "{$p}listings", 'items_data',              'LONGTEXT' ],
            [ "{$p}listings", 'feedback_data',           'LONGTEXT' ],
            [ "{$p}listings", 'footer_data',             'LONGTEXT' ],
            [ "{$p}listings", 'services_section_title',  "VARCHAR(255) DEFAULT ''" ],
            [ "{$p}listings", 'services_section_desc',   "TEXT" ],
            [ "{$p}listings", 'process_section_title',   "VARCHAR(255) DEFAULT ''" ],
            // ── Customizer & mobile settings (v7) ─────────────────────────────
            [ "{$p}listings", 'customizer_data',         'LONGTEXT' ],
            [ "{$p}listings", 'mobile_data',             'LONGTEXT' ],
            [ "{$p}listings", 'opening_hours',           'LONGTEXT' ],
            // ── Section ordering & visibility (v8) ───────────────────────────
            [ "{$p}listings", 'sections_config',          'LONGTEXT' ],
            // ── Vendor-defined category management, real feature — Services
            //    and Products each get their own independent category list
            //    (a vendor's "Popular Services" category shouldn't clutter
            //    their Products category dropdown, and vice versa). Each is
            //    a JSON array of {id, name} — same storage pattern already
            //    proven for gallery/opening_hours: a single hidden field the
            //    vendor form's JS maintains directly, not a per-row repeater
            //    field. Category assignment on each service/product item
            //    itself needs no schema change — it's a new key nested
            //    inside the existing services_data/products_data JSON,
            //    exactly like view_more_sections was. ──────────────────────
            [ "{$p}listings", 'service_categories',       'LONGTEXT' ],
            [ "{$p}listings", 'product_categories',       'LONGTEXT' ],
            // Real feature — SMS as a general notification channel,
            // alongside the existing email/push preference columns.
            // pref() already reads whatever column name is passed
            // dynamically, so this column is the only schema change SMS
            // needs to become a full preference-gated channel.
            [ "{$p}notification_preferences", 'sms', "TINYINT(1) DEFAULT 0" ],
            // Real feature — extends the existing, already-generic
            // coupon system (BillingService::apply_coupon() was
            // confirmed during discovery to have zero plan-specific
            // logic despite the plan_ids column — coupons already work
            // for any amount, just needed a booking-side integration
            // point) to booking deposits.
            [ "{$p}bookings", 'coupon_id',    "INT UNSIGNED DEFAULT NULL" ],
            [ "{$p}bookings", 'coupon_code',  "VARCHAR(30) DEFAULT ''" ],
            [ "{$p}bookings", 'discount_amount', "DECIMAL(10,2) DEFAULT 0.00" ],
            // ── Plan request feature ──────────────────────────────────────────
            [ "{$p}subscription_plans", 'allow_request', "TINYINT(1) DEFAULT 1" ],
            // Fluent Forms integration (v9)
            [ "{$p}listings", 'fluent_form_id', "INT DEFAULT 0" ],
            // Custom CSS per listing (v10)
            [ "{$p}listings", 'custom_css', 'LONGTEXT' ],
            // ── Premium vendor site sections (v11) ───────────────────────────
            [ "{$p}listings", 'team_data',         'LONGTEXT' ],
            [ "{$p}listings", 'clients_data',      'LONGTEXT' ],
            [ "{$p}listings", 'pricing_data',      'LONGTEXT' ],
            [ "{$p}listings", 'portfolio_data',    'LONGTEXT' ],
            [ "{$p}listings", 'testimonials_data', 'LONGTEXT' ],
            // ── Inquiry Modules System (v12) ──────────────────────────────────
            // Stores vendor's active category inquiry module configs as JSON.
            // Format: { "hotel-booking": { enabled: true, cta: "Book Room", intro: "", sort: 0 }, ... }
            [ "{$p}listings", 'inquiry_modules_data', 'LONGTEXT' ],
            // Stores module slug on inquiry submissions for categorised CRM view
            [ "{$p}leads",    'inquiry_module',    "VARCHAR(100) DEFAULT ''" ],
            // ── Vendor category system (v13) ─────────────────────────────
            [ "{$p}vendor_profiles", 'inq_cat_limit', "TINYINT DEFAULT 3" ],
            [ "{$p}vendor_profiles", 'inq_cat_locked', "TINYINT(1) DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'min_visit_charge', "DECIMAL(10,2) DEFAULT 0.00" ],
            // ── Section visibility per listing (v13) ──────────────────────
            [ "{$p}listings", 'sections_visible_data', 'LONGTEXT' ],
            // ── Inquiry booking support (v13) ─────────────────────────────
            [ "{$p}leads", 'inquiry_type',    "VARCHAR(20) DEFAULT 'inquiry'" ],
            [ "{$p}leads", 'step_data',       'LONGTEXT' ],
            [ "{$p}leads", 'booking_date',    "DATE DEFAULT NULL" ],
            [ "{$p}leads", 'booking_time',    "VARCHAR(20) DEFAULT ''" ],
            // ── New Vendor Listing Form sections (v14) ────────────────────
            // Each stores a JSON array of repeatable items (or a single
            // object for the two non-repeating sections), matching the
            // exact same storage pattern as team_data/clients_data/etc.
            [ "{$p}listings", 'highlights_data',     'LONGTEXT' ], // Key Highlights: [{icon,title,description}]
            [ "{$p}listings", 'amenities_data',      'LONGTEXT' ], // Features & Amenities: [{icon,title,description}]
            [ "{$p}listings", 'facilities_data',     'LONGTEXT' ], // Facilities: [{icon,title,description,image}]
            [ "{$p}listings", 'awards_data',         'LONGTEXT' ], // Awards & Recognition: [{title,issuer,year,description,image}]
            [ "{$p}listings", 'languages_data',      'LONGTEXT' ], // Languages Spoken: [{name,proficiency}]
            [ "{$p}listings", 'packages_data',       'LONGTEXT' ], // Packages & Pricing: [{name,price,duration,features[],image,featured}]
            [ "{$p}listings", 'memberships_data',    'LONGTEXT' ], // Membership Plans: [{name,price,billing_cycle,benefits[],featured}]
            [ "{$p}listings", 'certifications_data', 'LONGTEXT' ], // Licences & Certifications: [{title,issuer,year,credential_id,image,verify_url}]
            [ "{$p}listings", 'warranty_data',       'LONGTEXT' ], // Warranty/Guarantee: single object {title,duration,description,icon}
            [ "{$p}listings", 'terms_data',          'LONGTEXT' ], // Terms & Conditions: single object {content}
            // ── New columns from master document v1.0 ────────────────────────
            // gs_leads additions
            [ "{$p}leads", 'quality_score',          "TINYINT UNSIGNED DEFAULT 0" ],
            [ "{$p}leads", 'missed_alert_sent',      "TINYINT(1) DEFAULT 0" ],
            [ "{$p}leads", 'missed_alert_at',        "DATETIME DEFAULT NULL" ],
            [ "{$p}leads", 'missed_escalation_sent', "TINYINT(1) DEFAULT 0" ],
            [ "{$p}leads", 'is_multi_quote',         "TINYINT(1) DEFAULT 0" ],
            [ "{$p}leads", 'quote_group_id',         "CHAR(36) DEFAULT NULL" ],
            [ "{$p}leads", 'is_archived',            "TINYINT(1) DEFAULT 0" ],
            [ "{$p}leads", 'client_backup_sent',     "TINYINT(1) DEFAULT 0" ],
            [ "{$p}leads", 'phone_revealed',         "TINYINT(1) DEFAULT 0" ],
            [ "{$p}leads", 'source_url',             "VARCHAR(500) DEFAULT ''" ],
            [ "{$p}leads", 'diagnosis_session',      "CHAR(36) DEFAULT NULL" ],
            [ "{$p}leads", 'urgency_level',          "VARCHAR(20) DEFAULT 'normal'" ],
            [ "{$p}leads", 'consent_given_at',       "DATETIME DEFAULT NULL" ],
            [ "{$p}leads", 'consent_ip_hash',        "CHAR(32) DEFAULT ''" ],
            [ "{$p}leads", 'converted_at',           "DATETIME DEFAULT NULL" ],
            [ "{$p}leads", 'viewed_at',              "DATETIME DEFAULT NULL" ],
            // gs_vendor_profiles additions
            [ "{$p}vendor_profiles", 'avg_reply_minutes',     "INT DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'total_jobs_done',       "INT UNSIGNED DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'trust_score_pct',       "DECIMAL(4,2) DEFAULT 0.00" ],
            [ "{$p}vendor_profiles", 'trust_score_updated',   "DATETIME DEFAULT NULL" ],
            [ "{$p}vendor_profiles", 'neighbourhood_count',   "INT UNSIGNED DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'neighbourhood_area',    "VARCHAR(255) DEFAULT ''" ],
            [ "{$p}vendor_profiles", 'video_intro_url',       "VARCHAR(500) DEFAULT ''" ],
            [ "{$p}vendor_profiles", 'citation_checklist',    "TEXT DEFAULT NULL" ],
            // gs_bookings additions
            [ "{$p}bookings", 'job_status',          "VARCHAR(20) DEFAULT 'confirmed'" ],
            [ "{$p}bookings", 'travelling_at',       "DATETIME DEFAULT NULL" ],
            [ "{$p}bookings", 'arrived_at',          "DATETIME DEFAULT NULL" ],
            [ "{$p}bookings", 'started_at',          "DATETIME DEFAULT NULL" ],
            [ "{$p}bookings", 'completed_at',        "DATETIME DEFAULT NULL" ],
            [ "{$p}bookings", 'vendor_eta_minutes',  "INT DEFAULT NULL" ],
            [ "{$p}bookings", 'tracking_token',      "VARCHAR(64) DEFAULT NULL" ],
            [ "{$p}bookings", 'agreed_amount',       "DECIMAL(10,2) DEFAULT NULL" ],
            [ "{$p}bookings", 'review_requested_at', "DATETIME DEFAULT NULL" ],
            // FIX (enterprise hardening pass): bookings had no way to record which staff
            // member actually did the job, so per-staff performance metrics (reviews,
            // ratings) were architecturally impossible to compute correctly — the old
            // Staff Performance query papered over this with a vendor-wide LEFT JOIN that
            // fanned out and inflated every count. This column is the real fix: it lets a
            // vendor assign a staff member to a booking/job, and every downstream metric
            // (reviews.assigned_staff_id below, staff_performance query) is now traceable
            // back to this single source of truth instead of being guessed or averaged.
            [ "{$p}bookings", 'assigned_staff_id',  "INT UNSIGNED DEFAULT NULL" ],
            // gs_reviews additions
            // FIX (enterprise hardening pass): backfilled from bookings.assigned_staff_id
            // at review-submission time (via reviews.booking_id) so a review's rating can
            // be correctly attributed to the staff member who performed that job.
            [ "{$p}reviews", 'assigned_staff_id',   "INT UNSIGNED DEFAULT NULL" ],
            [ "{$p}reviews", 'punctuality_rating',  "TINYINT DEFAULT NULL" ],
            [ "{$p}reviews", 'quality_rating',      "TINYINT DEFAULT NULL" ],
            [ "{$p}reviews", 'cleanliness_rating',  "TINYINT DEFAULT NULL" ],
            [ "{$p}reviews", 'price_rating',        "TINYINT DEFAULT NULL" ],
            [ "{$p}reviews", 'would_recommend',     "TINYINT(1) DEFAULT NULL" ],
            [ "{$p}reviews", 'review_photos',       "LONGTEXT DEFAULT NULL" ],
            [ "{$p}reviews", 'booking_id',          "BIGINT UNSIGNED DEFAULT NULL" ],
            [ "{$p}reviews", 'is_flagged',          "TINYINT(1) DEFAULT 0" ],
            [ "{$p}reviews", 'vendor_reply_at',     "DATETIME DEFAULT NULL" ],
            [ "{$p}reviews", 'updated_at',          "DATETIME DEFAULT NULL" ],
            [ "{$p}reviews", 'approved_at',         "DATETIME DEFAULT NULL" ],
            [ "{$p}reviews", 'approved_by',         "BIGINT UNSIGNED DEFAULT NULL" ],
            [ "{$p}reviews", 'admin_reply',         "TEXT DEFAULT NULL" ],
            [ "{$p}reviews", 'admin_reply_at',      "DATETIME DEFAULT NULL" ],
            [ "{$p}reviews", 'is_spam',             "TINYINT(1) DEFAULT 0" ],
            // gs_staff additions (Part 17.1)
            [ "{$p}staff", 'vendor_id',            "INT UNSIGNED DEFAULT 0" ],
            [ "{$p}staff", 'can_view_all_leads',   "TINYINT(1) DEFAULT 0" ],
            [ "{$p}staff", 'assigned_categories',  "LONGTEXT DEFAULT NULL" ],
            // gs_leads additions (Part 17.3)
            [ "{$p}leads", 'assigned_staff_id',    "INT UNSIGNED DEFAULT NULL" ],
            // gs_verification_docs additions (Part 12.3)
            [ "{$p}verification_docs", 'badge_type', "VARCHAR(30) DEFAULT ''" ],
            // gs_lead_replies additions
            [ "{$p}lead_replies", 'quotation_id',   "BIGINT UNSIGNED DEFAULT NULL" ],
            [ "{$p}lead_replies", 'reply_type',     "VARCHAR(30) DEFAULT 'message'" ],
            // gs_listings additions
            [ "{$p}listings", 'reply_text', "TEXT DEFAULT NULL" ],

            // ── New columns — GoodService Complete Implementation (Phase 1+) ──
            [ "{$p}subscriptions", 'razorpay_sub_id', "VARCHAR(100) DEFAULT ''" ],
            [ "{$p}subscriptions", 'trial_ends_at',   "DATETIME DEFAULT NULL" ],
            [ "{$p}subscriptions", 'updated_at',      "DATETIME DEFAULT NULL" ],
            // gs_bookings job tracking columns (Part 15.1 / 28.2)
            [ "{$p}bookings", 'job_status',          "ENUM('confirmed','travelling','arrived','in_progress','done','cancelled') DEFAULT 'confirmed'" ],
            [ "{$p}bookings", 'travelling_at',        "DATETIME DEFAULT NULL" ],
            [ "{$p}bookings", 'arrived_at',           "DATETIME DEFAULT NULL" ],
            [ "{$p}bookings", 'started_at',           "DATETIME DEFAULT NULL" ],
            [ "{$p}bookings", 'completed_at',         "DATETIME DEFAULT NULL" ],
            [ "{$p}bookings", 'vendor_eta_minutes',   "INT DEFAULT NULL" ],
            // gs_vendor_profiles columns (Part 28.2)
            [ "{$p}vendor_profiles", 'neighbourhood_count', "INT UNSIGNED DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'neighbourhood_area',  "VARCHAR(255) DEFAULT ''" ],
            // gs_reviews columns (Part 12.4 / 28.2)
            [ "{$p}reviews", 'photos',                "LONGTEXT DEFAULT NULL" ],
            [ "{$p}reviews", 'booking_id',            "BIGINT UNSIGNED DEFAULT NULL" ],
            // gs_leads columns (Part 5.2 / 28.2)
            [ "{$p}leads", 'client_backup_sent',      "TINYINT(1) DEFAULT 0" ],
            [ "{$p}leads", 'source_url',              "VARCHAR(500) DEFAULT ''" ],
            [ "{$p}leads", 'utm_source',               "VARCHAR(100) DEFAULT ''" ],
            [ "{$p}leads", 'utm_campaign',             "VARCHAR(100) DEFAULT ''" ],
            [ "{$p}vendor_profiles", 'video_intro_url', "VARCHAR(500) DEFAULT ''" ],
            [ "{$p}reviews", 'vendor_reply',            "TEXT DEFAULT NULL" ],
            [ "{$p}reviews", 'vendor_replied_at',       "DATETIME DEFAULT NULL" ],
            [ "{$p}reviews", 'is_flagged',              "TINYINT(1) DEFAULT 0" ],
            // ── Listing-level availability/booking restructure ─────────────────
            // gs_availability and gs_blocked_dates were originally vendor-scoped
            // (one schedule per vendor). Restructured to listing-scoped: each
            // listing (a vendor may have several — e.g. "AC Repair" and
            // "Plumbing" — each its own category/booking config) now has its
            // own independent weekly schedule and blocked-date calendar.
            // vendor_id is retained for convenience/back-compat queries but
            // listing_id is now the primary scoping key for all booking logic.
            [ "{$p}availability",  'listing_id', "INT UNSIGNED NOT NULL DEFAULT 0" ],
            [ "{$p}blocked_dates", 'listing_id', "INT UNSIGNED NOT NULL DEFAULT 0" ],

            // ── Phase 3 booking automation columns ──────────────────────────
            // reminder_24h_sent / reminder_2h_sent — set to 1 after the cron
            // fires the corresponding reminder so it never fires twice.
            [ "{$p}bookings", 'reminder_24h_sent',   "TINYINT(1) DEFAULT 0" ],
            [ "{$p}bookings", 'reminder_2h_sent',    "TINYINT(1) DEFAULT 0" ],
            // review_request_sent — set to 1 after post-completion review
            // request is dispatched so it doesn't fire on every cron run.
            [ "{$p}bookings", 'review_request_sent', "TINYINT(1) DEFAULT 0" ],
            // auto_expire_at — datetime after which a pending/unconfirmed booking
            // is auto-cancelled if the vendor hasn't responded. Set at booking
            // creation time (NOW() + configurable window, default 30 minutes).
            [ "{$p}bookings", 'auto_expire_at',      "DATETIME DEFAULT NULL" ],
            // vendor_user_id — WP user ID of the listing's vendor. Stored at
            // booking creation time so cron notification queries avoid a JOIN
            // to gs_vendor_profiles on every row processed.
            [ "{$p}bookings", 'vendor_user_id',      "BIGINT UNSIGNED DEFAULT 0" ],
            // customer_user_id — WP user ID of the customer (0 for guests).
            // Already in leads but needed here independently for cron queries.
            [ "{$p}bookings", 'customer_user_id',    "BIGINT UNSIGNED DEFAULT 0" ],
            // listing_title — denormalised for notification copy without JOIN.
            [ "{$p}bookings", 'listing_title',       "VARCHAR(255) DEFAULT ''" ],
            // Phase 5 — booking deposit invoice linkage
            [ "{$p}invoices", 'booking_id',          "BIGINT UNSIGNED DEFAULT NULL" ],
            // Phase 4 — reschedule tracking
            [ "{$p}bookings", 'reschedule_count',     "TINYINT UNSIGNED DEFAULT 0" ],
            [ "{$p}bookings", 'original_date',        "DATE DEFAULT NULL" ],
            [ "{$p}bookings", 'original_time',        "TIME DEFAULT NULL" ],
            [ "{$p}bookings", 'rescheduled_at',       "DATETIME DEFAULT NULL" ],

            // ── GS Enhancements v1.0 — blueprint gap fixes ────────────────────
            // gs_leads: AI intent classification + lost-lead attribution
            [ "{$p}leads", 'intent_class',   "VARCHAR(10) DEFAULT 'unknown'" ],  // hot|warm|cold|unknown
            [ "{$p}leads", 'intent_score',   "TINYINT UNSIGNED DEFAULT 0" ],     // 0-100 scored by AI
            [ "{$p}leads", 'lost_reason',    "VARCHAR(50) DEFAULT ''" ],         // price|slow|chose_other|not_relevant|other
            [ "{$p}leads", 'lost_to',        "VARCHAR(255) DEFAULT ''" ],        // free-text competitor note
            // gs_reviews: single-use token gate (enforces booking-verified reviews)
            [ "{$p}reviews", 'review_token',  "CHAR(64) DEFAULT NULL" ],
            // gs_vendor_profiles: reliability score + new-provider boost expiry
            [ "{$p}vendor_profiles", 'reliability_score',  "TINYINT UNSIGNED DEFAULT 100" ], // 0-100
            [ "{$p}vendor_profiles", 'cancel_count',       "SMALLINT UNSIGNED DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'noshow_count',       "SMALLINT UNSIGNED DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'completed_count',    "SMALLINT UNSIGNED DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'boost_until',        "DATETIME DEFAULT NULL" ],         // new-provider boost expiry
            // gs_subscription_plans: lead distribution cap per day
            [ "{$p}subscription_plans", 'lead_cap_per_day', "TINYINT UNSIGNED DEFAULT 0" ],  // 0 = unlimited

            // ── GS Enhancements v1.1 — Multi-level verification (Blueprint #6) ─────
            // 8 independent verification booleans replacing single verification_status.
            // verification_status ENUM is preserved for backwards compat.
            [ "{$p}vendor_profiles", 'mobile_verified',        "TINYINT(1) DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'email_verified',         "TINYINT(1) DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'identity_verified',      "TINYINT(1) DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'address_verified',       "TINYINT(1) DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'qualification_verified', "TINYINT(1) DEFAULT 0" ],
            // WhatsApp verification override (Section 2 of inquiry/booking audit):
            // 'inherit' = use the global setting, 'on'/'off' = explicit per-vendor
            // override. Resolution order in WhatsAppVerificationService::is_enabled():
            // per-module setting → this vendor override → global setting → off.
            [ "{$p}vendor_profiles", 'whatsapp_verify_mode',   "VARCHAR(10) DEFAULT 'inherit'" ],
            [ "{$p}vendor_profiles", 'license_verified',       "TINYINT(1) DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'business_verified',      "TINYINT(1) DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'experience_verified',    "TINYINT(1) DEFAULT 0" ],
            [ "{$p}vendor_profiles", 'verification_levels',    "TINYINT UNSIGNED DEFAULT 0" ], // count of verified levels 0-8

            // ── GS Enhancements v1.1 — Moderation flag (Blueprint #35) ──────────────
            [ "{$p}listings", 'moderation_flag',    "TINYINT(1) DEFAULT 0" ],         // 1 = flagged for review
            [ "{$p}listings", 'moderation_reason',  "VARCHAR(255) DEFAULT ''" ],       // inactive|low_quality|flagged_reviews|duplicate_phone (descriptive text)
            [ "{$p}listings", 'moderation_flagged_at', "DATETIME DEFAULT NULL" ],

            // ── GS Enhancements v1.2 — Safety records (Blueprint #5) ────────────────
            [ "{$p}vendor_profiles", 'safety_verified',   "TINYINT(1) DEFAULT 0" ],  // 1 = has approved safety doc
            [ "{$p}vendor_profiles", 'safety_doc_type',   "VARCHAR(50) DEFAULT ''" ], // police_clearance|background_check|id_proof|address_proof
            // Real fix — closes a confirmed gap: only the document TYPE
            // was ever stored, with no column to reference an actually
            // uploaded file. Reuses the existing Media Library upload
            // pipeline (gs_upload_media, built earlier this engagement)
            // for storage — this just tracks the reference and review
            // state, matching the same "don't duplicate an existing,
            // working system" principle applied throughout this audit.
            [ "{$p}vendor_profiles", 'safety_doc_url',    "VARCHAR(500) DEFAULT ''" ],
            [ "{$p}vendor_profiles", 'safety_doc_status', "ENUM('none','pending','approved','rejected') DEFAULT 'none'" ],
            [ "{$p}vendor_profiles", 'safety_doc_note',   "VARCHAR(255) DEFAULT ''" ], // admin's reason if rejected
            [ "{$p}vendor_profiles", 'safety_doc_reviewed_at', "DATETIME DEFAULT NULL" ],
            [ "{$p}vendor_profiles", 'safety_verified_at',"DATETIME DEFAULT NULL" ],  // when safety doc was approved

            // ── GS Enhancements v1.2 — Portfolio verification (Blueprint #8) ─────────
            [ "{$p}listings", 'portfolio_verified',       "TINYINT(1) DEFAULT 0" ],  // 1 = at least one item customer-verified
            [ "{$p}listings", 'portfolio_verified_count', "SMALLINT UNSIGNED DEFAULT 0" ], // count of customer-verified items

            // ── GS Enhancements v1.2 — Response badge (Blueprint #19) ───────────────
            [ "{$p}vendor_profiles", 'response_badge', "VARCHAR(60) DEFAULT ''" ],  // e.g. "Usually responds in 2 hrs"

            // ── GS Enhancements v1.2 — OTP lead gate phone_verified (Blueprint #11) ─
            [ "{$p}leads", 'phone_verified', "TINYINT(1) DEFAULT 0" ],              // 1 if customer verified phone via OTP

            // ── Inquiry/Booking email verification (replaces the phantom mobile-OTP
            //    gate — see EmailVerificationService). email_verified=1 once the
            //    customer clicks the link in their confirmation email. Vendor
            //    notification is NOT gated on this — see EmailVerificationService
            //    docblock for the reasoning (phone-only leads have nothing to verify
            //    and must keep working exactly as before). ──────────────────────────
            [ "{$p}leads", 'email_verified',       "TINYINT(1) DEFAULT 0" ],
            [ "{$p}leads", 'email_verify_sent_at',  "DATETIME DEFAULT NULL" ],

            // ── GS Enhancements v1.2 — Structured intake data (Blueprint #26/#27) ──
            [ "{$p}leads", 'intake_data', "LONGTEXT DEFAULT NULL" ],                // JSON blob for doctor/legal structured intake

            // ── Manual Subscription & Offline Payment system — gs_plan_requests additions ──
            // (status ENUM widened separately in migrate_enum_columns(); these are new columns
            //  for installs where gs_plan_requests already existed before this version.)
            [ "{$p}plan_requests", 'source',            "VARCHAR(20) DEFAULT 'vendor_request'" ],
            [ "{$p}plan_requests", 'billing_cycle',      "VARCHAR(20) DEFAULT 'monthly'" ],
            [ "{$p}plan_requests", 'custom_months',      "SMALLINT UNSIGNED DEFAULT 0" ],
            [ "{$p}plan_requests", 'activation_date',    "DATETIME DEFAULT NULL" ],
            [ "{$p}plan_requests", 'expiry_date',        "DATETIME DEFAULT NULL" ],
            [ "{$p}plan_requests", 'renewal_date',       "DATETIME DEFAULT NULL" ],
            [ "{$p}plan_requests", 'grace_period_days',  "SMALLINT UNSIGNED DEFAULT 0" ],
            [ "{$p}plan_requests", 'auto_expiry',        "TINYINT(1) DEFAULT 1" ],
            [ "{$p}plan_requests", 'list_price',         "DECIMAL(10,2) DEFAULT 0.00" ],
            [ "{$p}plan_requests", 'override_price',     "DECIMAL(10,2) DEFAULT NULL" ],
            [ "{$p}plan_requests", 'discount_type',      "VARCHAR(20) DEFAULT 'none'" ],
            [ "{$p}plan_requests", 'discount_value',     "DECIMAL(10,2) DEFAULT 0.00" ],
            [ "{$p}plan_requests", 'discount_reason',    "VARCHAR(255) DEFAULT ''" ],
            [ "{$p}plan_requests", 'final_amount',       "DECIMAL(10,2) DEFAULT 0.00" ],
            [ "{$p}plan_requests", 'amount_paid',        "DECIMAL(10,2) DEFAULT 0.00" ],
            [ "{$p}plan_requests", 'balance_due',        "DECIMAL(10,2) DEFAULT 0.00" ],
            [ "{$p}plan_requests", 'currency',           "CHAR(3) DEFAULT 'INR'" ],
            [ "{$p}plan_requests", 'payment_mode',       "VARCHAR(30) DEFAULT ''" ],
            [ "{$p}plan_requests", 'transaction_id',     "VARCHAR(120) DEFAULT ''" ],
            [ "{$p}plan_requests", 'utr_number',         "VARCHAR(60) DEFAULT ''" ],
            [ "{$p}plan_requests", 'cheque_number',      "VARCHAR(40) DEFAULT ''" ],
            [ "{$p}plan_requests", 'bank_name',          "VARCHAR(120) DEFAULT ''" ],
            [ "{$p}plan_requests", 'bank_branch',        "VARCHAR(120) DEFAULT ''" ],
            [ "{$p}plan_requests", 'payment_date',       "DATE DEFAULT NULL" ],
            [ "{$p}plan_requests", 'reference_number',   "VARCHAR(100) DEFAULT ''" ],
            [ "{$p}plan_requests", 'payment_proof_ids',  "TEXT" ],
            [ "{$p}plan_requests", 'internal_notes',     "TEXT" ],
            [ "{$p}plan_requests", 'assigned_by',        "BIGINT UNSIGNED DEFAULT 0" ],
            [ "{$p}plan_requests", 'verified_by',        "BIGINT UNSIGNED DEFAULT 0" ],
            [ "{$p}plan_requests", 'verified_at',        "DATETIME DEFAULT NULL" ],
            [ "{$p}plan_requests", 'approved_by',        "BIGINT UNSIGNED DEFAULT 0" ],
            [ "{$p}plan_requests", 'approved_at',        "DATETIME DEFAULT NULL" ],
            [ "{$p}plan_requests", 'cancelled_at',       "DATETIME DEFAULT NULL" ],
            [ "{$p}plan_requests", 'subscription_id',    "BIGINT UNSIGNED DEFAULT 0" ],
            [ "{$p}plan_requests", 'resulting_action',   "VARCHAR(20) DEFAULT ''" ],
            [ "{$p}plan_requests", 'is_deleted',         "TINYINT(1) DEFAULT 0" ],
            // ── Conditional logic operators (Fluent-Forms-style condition editor) ──
            // gs_form_fields.cond_field_key/cond_value already existed; cond_op is
            // new. Listed here (not just in the CREATE TABLE) because this table
            // has already shipped on real installs without this column — without
            // this entry, every site that migrated categories before this change
            // would have a gs_form_fields table missing cond_op entirely, and the
            // new operator-aware evaluator would silently fail to read it.
            [ "{$p}form_fields", 'cond_op', "VARCHAR(20) DEFAULT 'equals'" ],
            [ "{$p}form_fields", 'show_label', "TINYINT(1) DEFAULT 1" ],
            [ "{$p}form_fields", 'step_group', "VARCHAR(60) DEFAULT ''" ],
            // Real fix, confirmed root cause: universal fields (name,
            // phone, email) carry a 'group' value in their hardcoded
            // source data (e.g. 'contact') identifying which form
            // section they belong in — but this was never persisted
            // when migrate_universal_fields() wrote them to the
            // database, so every site where that migration has already
            // run permanently loses this on read-back, causing these
            // fields to silently default to the wrong group.
            [ "{$p}form_fields", 'universal_group', "VARCHAR(60) DEFAULT ''" ],
            // FIXED, real root-cause bug found during the tooltip audit: the
            // Layout Templates admin screen (templates/pages/admin-dashboard.php,
            // 'layouts' case) reads $l->is_default and $l->schema_json directly
            // off {$p}layout_templates rows, but the original CREATE TABLE for
            // layout_templates never defined either column — meaning every read
            // of those properties silently returned null. Worse, saveLayout(),
            // deleteLayout() and setDefaultLayout() in AjaxController.php were
            // all writing to a DIFFERENT, unrelated table ({$p}layout_templates
            // vs the {$p}layouts table those methods actually targeted), so
            // "New Layout"/"Set Default" never affected what the screen showed
            // at all. Both problems are fixed together: these columns make the
            // schema match what the screen already reads, and the AJAX methods
            // below are repointed at this table to match.
            [ "{$p}layout_templates", 'is_default', "TINYINT(1) DEFAULT 0" ],
            [ "{$p}layout_templates", 'schema_json', "LONGTEXT" ],
            // FIXED, Known Limitations audit: the complaint filing form's own
            // placeholder invited attaching a screenshot, but no upload field
            // (or column to store it) ever existed — see submitComplaint() and
            // the vendor 'complaints' case in vendor-dashboard.php.
            [ "{$p}complaints", 'attachment_url', "VARCHAR(500) DEFAULT ''" ],
            // FIXED — Plans & Subscriptions audit: gs_subscriptions had no way to
            // record HOW a subscription came to exist (self-service purchase vs.
            // admin-granted vs. a brand-new vendor's automatic default plan vs. a
            // promotional/complimentary grant), nor WHO granted it when an admin
            // was involved. This made it impossible to distinguish a legitimate
            // free assignment from the createSubscription() payment-bypass bug.
            // See SubscriptionService::create(), ManualPlanService::admin_assign().
            [ "{$p}subscriptions", 'source',            "VARCHAR(30) DEFAULT 'purchased'" ],
            [ "{$p}subscriptions", 'assigned_by',        "BIGINT UNSIGNED DEFAULT NULL" ],
            // FIXED — Plans & Subscriptions audit: cancelling a subscription never
            // recorded what actually happened to the money that was paid for it
            // (refunded / intentionally not refunded / payment never received /
            // test transaction / cancelled before it ever activated), so Admin
            // Dashboard revenue kept counting cancelled-but-never-refunded
            // invoices forever. See AjaxController::adminCancelSubscription().
            [ "{$p}subscriptions", 'payment_treatment',  "VARCHAR(40) DEFAULT NULL" ],
            // FIXED — "which plan is the Free/default plan" was pure slug=='free'
            // convention with no explicit flag; a renamed or duplicated slug broke
            // SubscriptionService::downgrade_to_free() silently. See also the
            // is_default guard added to AjaxController::deletePlan()/togglePlan().
            [ "{$p}subscription_plans", 'is_default', "TINYINT(1) DEFAULT 0" ],

            // ENTERPRISE-AUDIT FIX (Part 2, High): "No automatic dunning/retry
            // cascade for failed recurring payments — the payment.failed webhook
            // handler sends one notification only, with no retry schedule, grace
            // period, or card-update dunning sequence." New columns rather than
            // widening the existing status ENUM — same rationale already used
            // for gs_disputes' pending_refund_* columns above: avoids an
            // ALTER...MODIFY on a column already in production use. See
            // SubscriptionService::start_or_touch_dunning()/clear_dunning() and
            // Cron::payment_dunning_cascade().
            [ "{$p}subscriptions", 'dunning_stage',        "TINYINT UNSIGNED DEFAULT 0" ],        // 0 = not in dunning; increments as each reminder stage fires
            [ "{$p}subscriptions", 'dunning_started_at',   "DATETIME DEFAULT NULL" ],
            [ "{$p}subscriptions", 'dunning_grace_until',  "DATETIME DEFAULT NULL" ],              // auto-downgrade to Free once this passes unresolved
            [ "{$p}subscriptions", 'last_payment_failed_at', "DATETIME DEFAULT NULL" ],

            // ENTERPRISE-AUDIT FIX (Part 2, High: "No plan versioning/
            // grandfathering — editing a plan retroactively affects every
            // active subscriber's displayed data with no 'existing
            // subscribers keep old price' mechanism"). Root cause:
            // SubscriptionService::get_active() always JOINs the LIVE
            // gs_subscription_plans row for every entitlement/display field
            // (max_listings, show_analytics, featured_badge, etc.) — plan_name
            // and amount were already snapshotted onto the subscription row,
            // but every OTHER plan attribute was not, so editing a plan's
            // limits/features instantly changed what every existing
            // subscriber saw and was entitled to, with no way to grandfather
            // anyone. A JSON snapshot of the plan's entitlement columns taken
            // at the moment a subscription is created/activated — see
            // SubscriptionService::build_plan_snapshot()/get_active()'s
            // "prefer snapshot, fall back to live" logic, and
            // AjaxController::adminPushPlanChanges() for the explicit,
            // admin-triggered opt-in to push a plan edit to existing
            // subscribers rather than it happening automatically/silently.
            [ "{$p}subscriptions", 'plan_snapshot', "LONGTEXT" ],
            // ENTERPRISE-AUDIT FIX (Part 1, High: "Delete is hard/irreversible
            // with no trash/restore... Enterprise admin tools require a
            // recoverable trash bin (30-day retention)"). The 'deleted' status
            // ENUM value already existed on gs_listings and was already
            // excluded from every real query across the codebase (vendor
            // dashboard, diagnostics, public listing lookups) — it was simply
            // never actually USED; adminDeleteListing() hard-deleted the row
            // instead. These columns make that existing status value a real,
            // restorable soft-delete: pre_delete_status remembers what to
            // restore back to (active/pending/draft/etc — restoring must not
            // just guess 'active'), deleted_at drives the 30-day retention
            // purge (see Cron::purge_old_trashed_listings()), deleted_by is
            // the audit trail.
            [ "{$p}listings", 'pre_delete_status', "VARCHAR(20) DEFAULT NULL" ],
            [ "{$p}listings", 'deleted_at',        "DATETIME DEFAULT NULL" ],
            [ "{$p}listings", 'deleted_by',        "BIGINT UNSIGNED DEFAULT 0" ],

            // ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "No SLA/
            // escalation tracking on complaints or disputes — status/priority
            // fields only, no due-date, auto-escalation, or assignee").
            // Assignee already existed (assigned_to, wired to a UI at
            // v7.417.0-era work). sla_due_at is set at submission time from
            // the priority-based SLA window and recomputed whenever an admin
            // manually changes priority; escalated_at records the one-time
            // auto-escalation so the hourly sweep never re-escalates the
            // same breach repeatedly. See Cron::escalate_overdue_complaints().
            [ "{$p}complaints", 'sla_due_at',   "DATETIME DEFAULT NULL" ],
            [ "{$p}complaints", 'escalated_at', "DATETIME DEFAULT NULL" ],
            // ENTERPRISE-AUDIT FIX (Part 3, Medium-High: "No calendar sync
            // (iCal/Google Calendar) for bookings"). A per-vendor secret token
            // used to authenticate the public, unauthenticated .ics feed URL
            // (calendar apps poll it periodically with no WP login/cookie) —
            // generated on first request, regenerable if a vendor suspects it
            // leaked. Separate from any nonce/session mechanism on purpose.
            [ "{$p}vendor_profiles", 'ical_token', "VARCHAR(64) DEFAULT ''" ],
            // ENTERPRISE-AUDIT FIX (Part 3, large, deliberately-deferred: "no
            // saved payment methods"). One gateway-customer id per vendor per
            // gateway — created lazily on first use (StripeService/
            // RazorpayService::get_or_create_customer()), reused for every
            // subsequent saved card so a vendor never ends up with duplicate
            // gateway-side customer records.
            [ "{$p}vendor_profiles", 'stripe_customer_id',   "VARCHAR(64) DEFAULT ''" ],
            [ "{$p}vendor_profiles", 'razorpay_customer_id', "VARCHAR(64) DEFAULT ''" ],

            // ENTERPRISE-AUDIT FIX (Part 3, Low-Medium: "Quick Replies/
            // Templates are reasonably complete but have no per-template
            // conversion analytics and no per-staff visibility control").
            // Root cause found to be deeper than the finding's wording: the
            // feature's gs_get_quick_replies endpoint was never called from
            // any frontend code at all — Quick Replies existed only as a
            // standalone CRUD screen with no connection to the actual
            // vendor-to-lead messaging compose flow, so there was nothing
            // to have usage analytics ON. used_count/last_used_at are
            // incremented only when a reply is actually inserted into an
            // outgoing message (AjaxController::useQuickReply()), giving
            // an honest usage-frequency count rather than a fabricated
            // "conversion rate" the platform has no way to attribute.
            // visible_to_staff implements the requested per-staff
            // visibility control: 1 = shown to team members (staff/manager
            // role, per gs_vendor_staff — see enforce_viewer_role_restriction()
            // just above for the existing owner-vs-staff lookup pattern this
            // reuses), 0 = owner-only. Defaults to 1 (visible) so existing
            // templates don't silently disappear from staff on upgrade.
            [ "{$p}quick_replies", 'used_count',      "INT UNSIGNED DEFAULT 0" ],
            [ "{$p}quick_replies", 'last_used_at',    "DATETIME DEFAULT NULL" ],
            [ "{$p}quick_replies", 'visible_to_staff',"TINYINT(1) DEFAULT 1" ],
            // Real fix — audit finding: customers can save/bookmark a listing
            // (AjaxController::saveListingBookmark()) but the Saved Listings
            // screen (other-dashboards.php, case 'saved') has no way to
            // organize saves into folders or attach a personal note ("get
            // quote before Diwali", "cheaper than X"), despite the finding
            // explicitly asking for both. Added directly to gs_saved_listings
            // rather than a new table — one row per save already exists and
            // a 1:1 attribute fits there with no join needed on read.
            [ "{$p}saved_listings", 'folder', "VARCHAR(100) DEFAULT ''" ],
            [ "{$p}saved_listings", 'note',   "TEXT" ],
        ];

        // ── Category audit log table ────────────────────────────────────────
        $wpdb->query( "
            CREATE TABLE IF NOT EXISTS {$p}inq_category_audit (
                id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                admin_id    BIGINT UNSIGNED DEFAULT 0,
                vendor_id   BIGINT UNSIGNED NOT NULL,
                action      VARCHAR(50) NOT NULL,
                prev_value  TEXT,
                new_value   TEXT,
                created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_vendor (vendor_id)
            ) {$wpdb->get_charset_collate()}
        " );

        // ── GS Enhancements v1.1 — Review token gate table (Blueprint #9) ─────────
        // Single-use tokens generated by vendor after completed booking.
        // Customer uses token URL to submit a verified review.
        // Separate table avoids polluting gs_reviews.status ENUM.
        $wpdb->query( "
            CREATE TABLE IF NOT EXISTS {$p}review_tokens (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                token       CHAR(64)        NOT NULL,
                listing_id  BIGINT UNSIGNED NOT NULL,
                vendor_id   BIGINT UNSIGNED NOT NULL,
                booking_id  BIGINT UNSIGNED NOT NULL,
                used        TINYINT(1)      DEFAULT 0,
                used_at     DATETIME        DEFAULT NULL,
                expires_at  DATETIME        NOT NULL,
                created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_token (token),
                KEY idx_listing (listing_id),
                KEY idx_vendor  (vendor_id)
            ) {$wpdb->get_charset_collate()}
        " );
        $added  = [];
        $failed = [];
        $skipped = 0;

        // Build a column map per table using SHOW COLUMNS — one query per table, much faster
        $table_cols = [];
        $unique_tables = array_unique( array_column( $cols, 0 ) );
        foreach ( $unique_tables as $tbl ) {
            $rows = $wpdb->get_results( "SHOW COLUMNS FROM `{$tbl}`", ARRAY_A );
            if ( $rows ) {
                $table_cols[ $tbl ] = array_column( $rows, 'Field' );
            }
            // If SHOW COLUMNS returned nothing, table may not exist — mark as empty array
            if ( ! isset( $table_cols[ $tbl ] ) ) {
                $table_cols[ $tbl ] = null; // null = table missing
            }
        }

        // One-time migration: reset logo_bg='#ffffff' (old default) → '' (transparent).
        // Listings created before this fix show white CSS background behind transparent logos.
        // Resetting to '' causes vendor-site.php to output background:transparent instead.
        $wpdb->query(
            "UPDATE `{$wpdb->prefix}gs_listings` SET `logo_bg`='' WHERE `logo_bg`='#ffffff'"
        );

        foreach ( $cols as [ $table, $col, $def ] ) {
            if ( $table_cols[ $table ] === null ) {
                // Table does not exist — skip silently (will be created by dbDelta above)
                $skipped++;
                continue;
            }
            if ( in_array( $col, $table_cols[ $table ], true ) ) {
                $skipped++;
                continue;
            }
            $result = $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN `{$col}` {$def}" );
            if ( $result === false ) {
                $failed[] = "`{$col}` on `{$table}`: " . $wpdb->last_error;
            } else {
                $added[] = $col;
                $table_cols[ $table ][] = $col; // keep map updated
            }
        }

        // Real bug fix: gs_leads.status ENUM never included 'replied', but
        // AjaxController::replyToInquiry() (the vendor's core, already-live
        // reply action) sets status='replied' on every reply. On strict-SQL
        // MySQL/MariaDB this throws a real error on every vendor reply; on
        // non-strict servers the status silently fails to update. Guarded by
        // checking the current column definition first, so this only runs once.
        $leads_tbl = $p . 'leads';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$leads_tbl}'" ) ) {
            $col_def = $wpdb->get_row( "SHOW COLUMNS FROM `{$leads_tbl}` LIKE 'status'", ARRAY_A );
            if ( $col_def && strpos( $col_def['Type'], "'replied'" ) === false ) {
                $enum_result = $wpdb->query(
                    "ALTER TABLE `{$leads_tbl}` MODIFY COLUMN `status`
                     ENUM('new','seen','contacted','qualified','replied','converted','junk')
                     DEFAULT 'new'"
                );
                if ( $enum_result === false ) {
                    $failed[] = "status ENUM extension on `{$leads_tbl}`: " . $wpdb->last_error;
                } else {
                    $added[] = 'leads.status:replied';
                }
            }
        }

        // ENTERPRISE-AUDIT FIX (root-cause bug, confirmed): admin-dashboard.php's
        // entire Leads screen (status filter tabs, badge colors, the
        // lead-detail status dropdown, and the list's inline status
        // dropdown) has always offered 'lost' and 'spam' as selectable
        // statuses — neither existed in this ENUM, so selecting either one
        // and clicking Update failed on strict MySQL/MariaDB (or silently
        // corrupted the column to '' on non-strict servers). Same guarded,
        // idempotent, run-once pattern as the 'replied' migration directly
        // above — checks the live column definition first so this is a
        // no-op after it has run once.
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$leads_tbl}'" ) ) {
            $col_def = $wpdb->get_row( "SHOW COLUMNS FROM `{$leads_tbl}` LIKE 'status'", ARRAY_A );
            if ( $col_def && strpos( $col_def['Type'], "'lost'" ) === false ) {
                $enum_result2 = $wpdb->query(
                    "ALTER TABLE `{$leads_tbl}` MODIFY COLUMN `status`
                     ENUM('new','seen','contacted','qualified','replied','converted','junk','lost','spam')
                     DEFAULT 'new'"
                );
                if ( $enum_result2 === false ) {
                    $failed[] = "status ENUM extension (lost/spam) on `{$leads_tbl}`: " . $wpdb->last_error;
                } else {
                    $added[] = 'leads.status:lost,spam';
                }
            }
        }

        // Store result for reporting
        self::$last_upgrade_result = [
            'added'   => $added,
            'failed'  => $failed,
            'skipped' => $skipped,
        ];

        // ── Bust ListingRepository SHOW COLUMNS cache when new columns were added ──
        // ListingRepository::save() caches SHOW COLUMNS for 24h keyed by GS_VERSION.
        // If columns were just added, the cache must be cleared immediately so the
        // next save() call picks up the new columns and does NOT strip them from UPDATE.
        // Without this, fields like items_data, mobile_data, team_data etc. would be
        // silently dropped from every listing save for up to 24 hours after upgrade,
        // causing vendor data to appear to "flush out" after saving.
        if ( ! empty( $added ) ) {
            // Delete every variant of the schema cache key (covers version changes)
            $gs_version = defined( 'GS_VERSION' ) ? GS_VERSION : '0';
            \GoodService\Core\Cache::delete( 'schema:cols:listings:' . $gs_version );
            \GoodService\Core\Cache::delete( 'schema:cols:listings:0' );
            if ( function_exists( 'gs_write_log' ) ) {
                gs_write_log( 'upgrade_columns: busted SHOW COLUMNS cache after adding ' . implode( ', ', $added ), 'INFO' );
            }
        }

        // Log failures
        if ( ! empty( $failed ) && function_exists( 'gs_write_log' ) ) {
            foreach ( $failed as $f ) {
                gs_write_log( 'upgrade_columns: ' . $f );
            }
        }

        // ── One-time column charset fixes ─────────────────────────────────────
        // icon_emoji: must be utf8mb4 so emoji survive on servers where the DB
        // was created with the default utf8 (3-byte) charset. MODIFY is idempotent.
        $cat_tbl = $p . 'categories';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$cat_tbl}'" ) ) {
            // Force utf8mb4 on the connection before ALTER so the query itself
            // travels over a 4-byte-capable pipe.
            $wpdb->query( "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci" );

            // Widen the column charset.
            $wpdb->query(
                "ALTER TABLE `{$cat_tbl}`
                 MODIFY COLUMN `icon_emoji`
                 VARCHAR(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''"
            );

            // Repair corrupted emoji: any category whose icon_emoji is exactly '?'
            // (U+003F — what MySQL stores when a 4-byte emoji is written over a
            // utf8/3-byte connection) gets restored from a broad name/slug map.
            // This covers both the default seeded categories AND common custom names.
            $emoji_map = [
                // ── by slug (highest priority) ───────────────────────────
                'home-services'        => '🏠',
                'business-services'    => '💼',
                'health-wellness'      => '❤️',
                'education'            => '📚',
                'it-technology'        => '💻',
                'events-wedding'       => '🎉',
                'beauty-salon'         => '💄',
                'legal-finance'        => '⚖️',
                // common admin-added slugs
                'beauty-wellness'      => '💆',
                'food-catering'        => '🍽️',
                'fashion-apparel'      => '👗',
                'travel-tourism'       => '✈️',
                'automotive'           => '🚗',
                'real-estate'          => '🏠',
                'construction'         => '🔨',
                'cleaning'             => '🧹',
                'plumbing'             => '🔧',
                'electrical'           => '⚡',
                'carpentry'            => '🪚',
                'painting'             => '🎨',
                'gardening'            => '🌱',
                'pest-control'         => '🐛',
                'security'             => '🔒',
                'photography'          => '📷',
                'fitness'              => '💪',
                'spa-massage'          => '💆',
                'tutoring'             => '📖',
                'catering'             => '🍽️',
                'accounting'           => '📊',
                'consulting'           => '💼',
                'marketing'            => '📢',
                'web-design'           => '🌐',
                'logistics'            => '🚚',
                'medical'              => '🏥',
                'dental'               => '🦷',
                'veterinary'           => '🐾',
                'interior-design'      => '🛋️',
                'architecture'         => '🏗️',
                'music-lessons'        => '🎵',
                'dance-classes'        => '💃',
                'yoga'                 => '🧘',
                'astrology'            => '🔮',
                'packers-movers'       => '📦',
                'appliance-repair'     => '🔧',
                'ac-repair'            => '❄️',
                'laundry'              => '👕',
                'drivers'              => '🚗',
                'cooking-classes'      => '👩‍🍳',
                'tailoring'            => '🧵',
                'salon'                => '💇',
                'mehndi'               => '🌺',
                'makeup'               => '💋',
                'nails'                => '💅',
            ];

            // Fetch all categories whose icon is corrupted
            $broken = $wpdb->get_results(
                "SELECT id, slug, name FROM `{$cat_tbl}`
                 WHERE icon_emoji = '?' OR icon_emoji = '' OR LENGTH(icon_emoji) = 1"
            ) ?: [];

            foreach ( $broken as $row ) {
                $fix = $emoji_map[ $row->slug ] ?? null;

                // Also try matching by normalised name if slug didn't match
                if ( ! $fix ) {
                    $name_slug = sanitize_title( $row->name );
                    $fix = $emoji_map[ $name_slug ] ?? null;
                }

                // Generic fallback so at least something shows instead of '?'
                if ( ! $fix ) { $fix = '📂'; }

                $wpdb->query( $wpdb->prepare(
                    "UPDATE `{$cat_tbl}` SET icon_emoji = %s WHERE id = %d",
                    $fix, (int) $row->id
                ) );
            }

            // Flush category cache so repaired data is served immediately
            if ( class_exists( '\GoodService\Core\Cache' ) ) {
                \GoodService\Core\Cache::flush_group( 'categories' );
            }
        }

        // ── Widen moderation_reason on installs that already have it ───────
        // Confirmed real issue: the column loop above only ADDS columns
        // that don't exist yet — it silently SKIPS any column that
        // already exists, regardless of its current width. This column
        // existed (as VARCHAR(50)) before this fix was written, so simply
        // changing its definition in the $cols array above would never
        // actually reach a site that already ran a prior version's
        // upgrade. MODIFY COLUMN is idempotent — safe to run on every
        // page load, since re-widening an already-wide column is a
        // harmless no-op.
        $listings_tbl = $p . 'listings';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$listings_tbl}'" ) ) {
            $current_def = $wpdb->get_row( "SHOW COLUMNS FROM `{$listings_tbl}` LIKE 'moderation_reason'" );
            if ( $current_def && stripos( $current_def->Type, 'varchar(50)' ) !== false ) {
                $wpdb->query( "ALTER TABLE `{$listings_tbl}` MODIFY COLUMN `moderation_reason` VARCHAR(255) DEFAULT ''" );
            }
        }

        // ── Add missing UNIQUE KEY to seo_location_pages on installs that
        //    already have this table ──────────────────────────────────────
        // Confirmed real issue via research: dbDelta cannot add a missing
        // unique index to an already-existing table — it only adds
        // genuinely new COLUMNS to an existing table, never new KEYS.
        // This table's original definition had no unique key at all,
        // meaning $wpdb->replace() in Cron::generate_seo_location_pages()
        // inserted a fresh duplicate row every month instead of updating
        // the existing one — so any already-running install likely has
        // real duplicate (category_slug, city) rows by now. Those must be
        // de-duplicated FIRST (kept: most recent by last_updated) or
        // adding the unique key below would fail outright with a
        // duplicate-entry error.
        $seo_loc_tbl = $p . 'seo_location_pages';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$seo_loc_tbl}'" ) ) {
            $has_unique_key = $wpdb->get_row( "SHOW INDEX FROM `{$seo_loc_tbl}` WHERE Key_name = 'uniq_category_city'" );
            if ( ! $has_unique_key ) {
                // De-duplicate: keep the highest id per (category_slug,
                // city) pair. This is genuinely equivalent to "keep the
                // most recently updated row" specifically BECAUSE of how
                // this bug behaved — with no unique key, every monthly
                // cron run was a fresh INSERT, never an UPDATE, so higher
                // id always means more recently written, with no
                // exceptions possible under this specific failure mode.
                $wpdb->query(
                    "DELETE t1 FROM `{$seo_loc_tbl}` t1
                     INNER JOIN `{$seo_loc_tbl}` t2
                       ON t1.category_slug = t2.category_slug
                      AND t1.city = t2.city
                      AND t1.id < t2.id"
                );
                $wpdb->query( "ALTER TABLE `{$seo_loc_tbl}` ADD UNIQUE KEY `uniq_category_city` (`category_slug`, `city`)" );
            }
        }

        // ── Same fix for demand_signals — confirmed real, second instance
        //    of the identical bug class, found only by re-checking
        //    thoroughly rather than assuming the seo_location_pages fix
        //    above covered everything ──────────────────────────────────
        $demand_tbl = $p . 'demand_signals';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$demand_tbl}'" ) ) {
            // Widen yoy_change first — dbDelta only ADDS new columns to an
            // existing table, it never widens an already-existing one.
            $yoy_def = $wpdb->get_row( "SHOW COLUMNS FROM `{$demand_tbl}` LIKE 'yoy_change'" );
            if ( $yoy_def && stripos( $yoy_def->Type, 'decimal(5,2)' ) !== false ) {
                $wpdb->query( "ALTER TABLE `{$demand_tbl}` MODIFY COLUMN `yoy_change` DECIMAL(9,2) DEFAULT 0" );
            }
            $has_demand_key = $wpdb->get_row( "SHOW INDEX FROM `{$demand_tbl}` WHERE Key_name = 'uniq_signal'" );
            if ( ! $has_demand_key ) {
                // Same reasoning as seo_location_pages above: with no
                // unique key, every monthly cron run was a fresh INSERT,
                // so higher id reliably means more recently written.
                $wpdb->query(
                    "DELETE t1 FROM `{$demand_tbl}` t1
                     INNER JOIN `{$demand_tbl}` t2
                       ON t1.category = t2.category
                      AND t1.city = t2.city
                      AND t1.month_num = t2.month_num
                      AND t1.year_num = t2.year_num
                      AND t1.id < t2.id"
                );
                $wpdb->query( "ALTER TABLE `{$demand_tbl}` ADD UNIQUE KEY `uniq_signal` (`category`, `city`, `month_num`, `year_num`)" );
            }
        }

        // ── One-time backfill: ranking_score for existing listings ─────────
        // Confirmed real gap: every EXISTING listing gets the column's
        // default of 0.0000 the moment it's added — they all tie at zero
        // until each one happens to get a new review or be edited, which
        // could take a long time for some vendors, making the default
        // sort effectively arbitrary (by id) for everyone in the
        // meantime. Computed as a single SQL UPDATE (not a PHP loop —
        // safe at real scale, no risk of timing out on a large table)
        // using the EXACT same formula as
        // ReviewRepository::recalculate_ranking_score() — C=10, m=3.5,
        // 270-day half-life, +0.15 featured / +0.10 verified boost. Keep
        // these two in sync deliberately if the formula ever changes.
        // Gated on "any row still at the literal default" so this never
        // re-runs once real scores exist — re-running it would be
        // harmless (idempotent) but wasteful at scale.
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$listings_tbl}'" ) ) {
            $reviews_tbl = $p . 'reviews';
            $needs_backfill = $wpdb->get_var(
                "SELECT 1 FROM `{$listings_tbl}` WHERE ranking_score = 0.0000 LIMIT 1"
            );
            if ( $needs_backfill && $wpdb->get_var( "SHOW TABLES LIKE '{$reviews_tbl}'" ) ) {
                $wpdb->query(
                    "UPDATE `{$listings_tbl}` l SET l.ranking_score = ROUND(
                        ( (10 * 3.5 + l.review_count * l.avg_rating) / (10 + l.review_count) )
                        * POW(0.5, GREATEST(0, DATEDIFF(NOW(), COALESCE(
                            (SELECT MAX(r.created_at) FROM `{$reviews_tbl}` r WHERE r.listing_id = l.id AND r.status = 'approved'),
                            l.created_at
                        ))) / 270)
                        * (1 + (l.is_featured * 0.15) + (l.is_verified * 0.10))
                    , 4)"
                );
            }
        }

        // ── One-time backfill: listing_uid for existing listings ───────────
        // Same pattern as the ranking_score backfill above: gated on "any
        // row still at the empty default" so this never re-runs once real
        // IDs exist. Single SQL UPDATE using LPAD, safe at real scale.
        // Format GS-100001, derived directly from the existing,
        // already-unique auto-increment id — guarantees no duplicates are
        // possible without any separate uniqueness-checking logic at all.
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$listings_tbl}'" ) ) {
            $needs_uid_backfill = $wpdb->get_var(
                "SELECT 1 FROM `{$listings_tbl}` WHERE listing_uid = '' OR listing_uid IS NULL LIMIT 1"
            );
            if ( $needs_uid_backfill ) {
                $wpdb->query(
                    "UPDATE `{$listings_tbl}` SET listing_uid = CONCAT('GS-', LPAD(id, 6, '0')) WHERE listing_uid = '' OR listing_uid IS NULL"
                );
            }
        }

        // ── One-time seed: default content for the nine static platform
        //    pages (About, Contact, Privacy, Terms, Cookies, Refund,
        //    Disclaimer, Blog index, Sitemap) ─────────────────────────────
        // Confirmed real gap found during the footer-link audit: these
        // pages had no real route, and the gs_pages table — though fully
        // built with a working admin editor — had never been seeded with
        // any real content for them. Seeder.php's own run() only fires on
        // a genuinely fresh install (gated on subscription_plans being
        // empty), so it would never reach an already-running site; this
        // uses the same version-gated pattern as every other fix added
        // today instead. Checked per-slug rather than with one blanket
        // gate, so an admin who has already manually created any of these
        // nine pages keeps their own real content — this never overwrites
        // an existing row, only fills in ones that are genuinely missing.
        $pages_tbl = $p . 'pages';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$pages_tbl}'" ) ) {
            $platform_name  = \GoodService\Core\Config::get( 'platform_name', get_bloginfo( 'name' ) ?: 'GoodService' );
            $platform_email = \GoodService\Core\Config::get( 'platform_email', '' );
            $platform_phone = \GoodService\Core\Config::get( 'platform_phone', '' );
            $platform_addr  = \GoodService\Core\Config::get( 'platform_address', '' );
            $today          = gmdate( 'F j, Y' );

            $contact_line = $platform_email
                ? "<p>Email us at <a href=\"mailto:{$platform_email}\">{$platform_email}</a>" . ( $platform_phone ? " or call {$platform_phone}" : '' ) . '.</p>'
                : '<p>Use the contact form below and our team will respond within 1–2 business days.</p>';

            $default_pages = [
                'about-us' => [
                    'title'   => 'About Us',
                    'content' => "<h2>Connecting you with trusted local professionals</h2>
<p>{$platform_name} is a verified directory of local service providers, built to make finding the right professional — for the right job, at the right price — simple and trustworthy.</p>
<h3>What we do</h3>
<p>Every business listed on {$platform_name} goes through a verification process before going live. We surface providers based on genuine customer reviews, response speed, and how complete and current their profile is — not just who pays the most.</p>
<h3>Why it matters</h3>
<p>Finding a reliable plumber, electrician, or service provider shouldn't mean guessing from a pile of identical, unverified listings. We built {$platform_name} so customers can compare real, verified options — and so good businesses get found for the right reasons.</p>",
                ],
                'contact-us' => [
                    'title'   => 'Contact Us',
                    'content' => "<h2>We're here to help</h2>
{$contact_line}
<h3>For customers</h3>
<p>Questions about a listing, a booking, or how {$platform_name} works — reach out and we'll point you in the right direction.</p>
<h3>For businesses</h3>
<p>Want to list your business, or have a question about your existing listing? Visit your <a href=\"" . home_url( '/vendor/dashboard/' ) . "\">vendor dashboard</a> or contact us directly.</p>" . ( $platform_addr ? "<p><strong>Address:</strong> " . esc_html( $platform_addr ) . '</p>' : '' ),
                ],
                'blog' => [
                    'title'   => 'Blog',
                    'content' => "<h2>{$platform_name} Blog</h2>
<p>Guidance for finding and working with local service professionals, and tips for businesses looking to grow through {$platform_name}.</p>
<p><em>New articles are on the way — check back soon, or follow our social channels for updates.</em></p>",
                ],
                'privacy-policy' => [
                    'title'   => 'Privacy Policy',
                    'content' => "<p><em>Last updated: {$today}</em></p>
<h2>1. Information we collect</h2>
<p>When you use {$platform_name}, we collect information you provide directly — such as your name, contact details, and inquiry content when you contact a listed business — along with basic usage data (pages visited, search terms) to help us improve the platform.</p>
<h2>2. How we use your information</h2>
<p>We use your information to connect you with service providers, respond to inquiries, improve our directory, and — where you've agreed — send you relevant updates. We do not sell your personal information to third parties.</p>
<h2>3. Information sharing</h2>
<p>When you submit an inquiry to a listed business, the details you provide are shared with that business so they can respond to you. We may also share data with service providers who help us operate the platform (e.g. hosting, analytics), under confidentiality obligations.</p>
<h2>4. Data security</h2>
<p>We use reasonable technical and organizational measures to protect your information. No method of transmission over the internet is 100% secure, and we cannot guarantee absolute security.</p>
<h2>5. Your rights</h2>
<p>You may request access to, correction of, or deletion of your personal data by contacting us" . ( $platform_email ? " at <a href=\"mailto:{$platform_email}\">{$platform_email}</a>" : '' ) . ".</p>
<h2>6. Changes to this policy</h2>
<p>We may update this policy from time to time. Material changes will be reflected by updating the date above.</p>",
                ],
                'terms-of-service' => [
                    'title'   => 'Terms of Service',
                    'content' => "<p><em>Last updated: {$today}</em></p>
<h2>1. Acceptance of terms</h2>
<p>By accessing or using {$platform_name}, you agree to these Terms of Service. If you do not agree, please do not use the platform.</p>
<h2>2. The service we provide</h2>
<p>{$platform_name} is a directory connecting customers with independent local service providers. We do not employ, supervise, or guarantee the work of any listed business — each provider is solely responsible for the services they perform.</p>
<h2>3. Listings and verification</h2>
<p>We make reasonable efforts to verify businesses before they're listed, but verification does not constitute an endorsement or guarantee of quality. Customers should use their own judgment, including checking reviews, before engaging any provider.</p>
<h2>4. User conduct</h2>
<p>You agree not to misuse the platform, submit false information, or use it for any unlawful purpose. We reserve the right to suspend or remove access for users or listings that violate these terms.</p>
<h2>5. Limitation of liability</h2>
<p>{$platform_name} is not liable for any dispute, loss, or damage arising from your interaction with a listed business. Any agreement for services is solely between you and the provider.</p>
<h2>6. Changes to these terms</h2>
<p>We may revise these terms from time to time. Continued use of the platform after changes constitutes acceptance of the revised terms.</p>",
                ],
                'cookie-policy' => [
                    'title'   => 'Cookie Policy',
                    'content' => "<p><em>Last updated: {$today}</em></p>
<h2>What are cookies</h2>
<p>Cookies are small text files stored on your device that help websites function correctly and remember your preferences.</p>
<h2>How we use cookies</h2>
<p>{$platform_name} uses cookies to keep you logged in, remember your search filters, and understand how the platform is used so we can improve it. We do not use cookies to sell your data.</p>
<h2>Managing cookies</h2>
<p>Most browsers let you control or delete cookies through their settings. Disabling cookies may affect some features, such as staying logged in.</p>",
                ],
                'refund-policy' => [
                    'title'   => 'Refund Policy',
                    'content' => "<p><em>Last updated: {$today}</em></p>
<h2>Directory listings</h2>
<p>{$platform_name} is a directory connecting customers with independent service providers. Payments for actual services (labor, materials, bookings) are made directly to the provider and are governed by that provider's own refund terms, not by {$platform_name}.</p>
<h2>Platform subscriptions</h2>
<p>If you are a vendor with a paid subscription on {$platform_name}, refund eligibility for that subscription is described in your plan terms at the time of purchase. Contact us if you have a billing concern.</p>
<h2>Questions</h2>
<p>If you believe you were charged in error for a platform subscription, please contact us" . ( $platform_email ? " at <a href=\"mailto:{$platform_email}\">{$platform_email}</a>" : '' ) . " and we'll review it promptly.</p>",
                ],
                'disclaimer' => [
                    'title'   => 'Disclaimer',
                    'content' => "<h2>General information only</h2>
<p>Content on {$platform_name}, including business descriptions, reviews, and pricing estimates, is provided for general informational purposes. We make reasonable efforts to keep listings accurate but do not guarantee completeness or accuracy at all times.</p>
<h2>No professional advice</h2>
<p>Nothing on this platform constitutes professional, legal, or financial advice. Decisions to engage any listed service provider are made at your own discretion.</p>
<h2>Third-party listings</h2>
<p>Listed businesses are independent third parties, not employees or agents of {$platform_name}. We are not responsible for the actions, quality of work, or representations of any listed business.</p>",
                ],
                'sitemap' => [
                    'title'   => 'Sitemap',
                    'content' => "<h2>Find your way around {$platform_name}</h2>
<ul>
<li><a href=\"" . home_url( '/' ) . "\">Home</a></li>
<li><a href=\"" . home_url( '/directory/' ) . "\">Browse Directory</a></li>
<li><a href=\"" . home_url( '/vendor/register/' ) . "\">List Your Business</a></li>
<li><a href=\"" . home_url( '/vendor/login/' ) . "\">Vendor Login</a></li>
<li><a href=\"" . home_url( '/about-us/' ) . "\">About Us</a></li>
<li><a href=\"" . home_url( '/contact-us/' ) . "\">Contact Us</a></li>
<li><a href=\"" . home_url( '/blog/' ) . "\">Blog</a></li>
<li><a href=\"" . home_url( '/privacy-policy/' ) . "\">Privacy Policy</a></li>
<li><a href=\"" . home_url( '/terms-of-service/' ) . "\">Terms of Service</a></li>
<li><a href=\"" . home_url( '/cookie-policy/' ) . "\">Cookie Policy</a></li>
<li><a href=\"" . home_url( '/refund-policy/' ) . "\">Refund Policy</a></li>
<li><a href=\"" . home_url( '/disclaimer/' ) . "\">Disclaimer</a></li>
</ul>
<p>Looking for the machine-readable sitemap for search engines? <a href=\"" . home_url( '/gs-sitemap.xml' ) . "\">View XML sitemap →</a></p>",
                ],
            ];

            foreach ( $default_pages as $slug => $page_data ) {
                $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM `{$pages_tbl}` WHERE slug = %s", $slug ) );
                if ( $exists ) { continue; } // admin already has real content here — never overwrite it
                $wpdb->insert( $pages_tbl, [
                    'slug'       => $slug,
                    'title'      => $page_data['title'],
                    'content'    => $page_data['content'],
                    'meta_title' => $page_data['title'] . ' — ' . $platform_name,
                    'meta_desc'  => '',
                    'is_active'  => 1,
                    'created_at' => current_time( 'mysql' ),
                    'updated_at' => current_time( 'mysql' ),
                ] );
            }
        }

        // Real feature: seeds the default step-category registry — only
        // when the table is empty, so a site that already has its own
        // configured step categories (including any custom ones an admin
        // has added) is never touched by this on a future update.
        $step_cat_tbl = $p . 'form_step_categories';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$step_cat_tbl}'" ) ) {
            $existing_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$step_cat_tbl}" );
            if ( $existing_count === 0 ) {
                $wpdb->insert( $step_cat_tbl, [ 'step_key' => 'scheduling', 'label' => 'Scheduling', 'sort_order' => 10, 'is_active' => 1 ] );
                $wpdb->insert( $step_cat_tbl, [ 'step_key' => 'contact',    'label' => 'Contact',    'sort_order' => 20, 'is_active' => 1 ] );
            }
        }
    }

    private static function add_fulltext_indexes( string $p ): void {
        global $wpdb;
        $indexes = [
            [ 'table' => "{$p}listings",     'name' => 'ft_search',  'cols' => 'title, tagline, short_desc, tags, city' ],
            [ 'table' => "{$p}search_index", 'name' => 'ft_content', 'cols' => 'content' ],
        ];
        foreach ( $indexes as $idx ) {
            $tbl = $wpdb->get_var( "SHOW TABLES LIKE '{$idx['table']}'" );
            if ( ! $tbl ) { continue; }
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM information_schema.STATISTICS
                 WHERE table_schema = DATABASE() AND table_name = %s AND index_name = %s",
                $idx['table'], $idx['name']
            ) );
            if ( ! $exists ) {
                $wpdb->query( "ALTER TABLE `{$idx['table']}` ADD FULLTEXT KEY `{$idx['name']}` ({$idx['cols']})" );
            }
        }
    }

    /**
     * Two-Factor Authentication tables — real feature, Critical priority
     * gap from the enterprise audit. Deliberately reuses the existing,
     * proven OtpService (SMS + email fallback, rate limiting,
     * hash_equals timing-safe compare, single-use enforcement) rather
     * than building a separate TOTP/authenticator-app system from
     * scratch — discovered during Phase 1 discovery to be the
     * architecturally superior choice: less new surface area, reuses
     * tested infrastructure, matches what this platform's other
     * verification flows already use.
     *
     * Deliberately a standalone method using heredoc syntax rather than
     * added to get_table_definitions()'s array — that array's existing
     * escaped-quote convention proved fragile to hand-edit safely.
     */
    private static function create_2fa_tables( string $p, string $c ): void {
        global $wpdb;

        $settings_sql = <<<SQL
CREATE TABLE IF NOT EXISTS {$p}2fa_settings (
    user_id     BIGINT UNSIGNED NOT NULL,
    enabled     TINYINT(1)               DEFAULT 0,
    phone       VARCHAR(20)              DEFAULT '',
    enabled_at  DATETIME                 DEFAULT NULL,
    updated_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id)
) $c
SQL;

        // Bridges the gap between password verification succeeding and
        // OTP verification succeeding. Deliberately NOT a session or a
        // capability grant of any kind — it only proves "this specific
        // password check already passed", nothing more. Single-use,
        // short TTL matching OtpService's own 5-minute OTP window for
        // consistency (a longer-lived pending token than the OTP itself
        // would be validated against makes no sense).
        $pending_sql = <<<SQL
CREATE TABLE IF NOT EXISTS {$p}2fa_pending (
    token       CHAR(64)        NOT NULL,
    user_id     BIGINT UNSIGNED NOT NULL,
    created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
    expires_at  DATETIME        NOT NULL,
    PRIMARY KEY (token),
    KEY idx_user (user_id),
    KEY idx_expires (expires_at)
) $c
SQL;

        dbDelta( $settings_sql );
        dbDelta( $pending_sql );
    }

    /**
     * Dispute Resolution tables — real feature, Critical priority gap
     * from the enterprise audit. References booking_id specifically
     * (not a generic "order" concept) since Phase 1 discovery confirmed
     * that's the entity actually linked to a real gateway payment —
     * via {$p}invoices.booking_id → payment_id/gateway, the exact chain
     * DisputeService needs to issue a real refund through
     * RazorpayService::refund() / StripeService::refund().
     *
     * evidence is a JSON array of {url, note, uploaded_by, uploaded_at}
     * — reuses the existing vendor media library upload pipeline for
     * the actual file storage (gs_upload_media), this table only
     * records references to what was uploaded, matching the same
     * "don't duplicate an existing, working system" principle applied
     * throughout this audit.
     */
    private static function create_dispute_tables( string $p, string $c ): void {
        $disputes_sql = <<<SQL
CREATE TABLE IF NOT EXISTS {$p}disputes (
    id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    booking_id        BIGINT UNSIGNED NOT NULL,
    listing_id        BIGINT UNSIGNED NOT NULL,
    vendor_id         BIGINT UNSIGNED NOT NULL,
    opened_by_user_id BIGINT UNSIGNED NOT NULL,
    opened_by_role    ENUM('customer','vendor') NOT NULL,
    reason            VARCHAR(100)    NOT NULL,
    description       TEXT,
    evidence          LONGTEXT,
    status            ENUM('open','awaiting_response','under_review','resolved','closed') DEFAULT 'open',
    resolution        ENUM('full_refund','partial_refund','no_refund','mediation','wallet_credit') DEFAULT NULL,
    resolution_note   TEXT,
    refund_amount     DECIMAL(10,2)   DEFAULT NULL,
    refund_id         VARCHAR(255)    DEFAULT '',
    resolved_by       BIGINT UNSIGNED DEFAULT NULL,
    resolved_at       DATETIME        DEFAULT NULL,
    sla_deadline      DATETIME        DEFAULT NULL,
    created_at        DATETIME                 DEFAULT CURRENT_TIMESTAMP,
    updated_at        DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_booking (booking_id),
    KEY idx_vendor  (vendor_id),
    KEY idx_status  (status),
    KEY idx_opened_by (opened_by_user_id)
) $c
SQL;

        // One row per message in the back-and-forth between the parties
        // and admin — kept separate from the dispute row itself so the
        // conversation thread can grow without bloating/rewriting the
        // parent row on every message.
        $messages_sql = <<<SQL
CREATE TABLE IF NOT EXISTS {$p}dispute_messages (
    id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    dispute_id   BIGINT UNSIGNED NOT NULL,
    user_id      BIGINT UNSIGNED NOT NULL,
    user_role    ENUM('customer','vendor','admin') NOT NULL,
    message      TEXT            NOT NULL,
    attachment_url VARCHAR(500)  DEFAULT '',
    created_at   DATETIME                 DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_dispute (dispute_id)
) $c
SQL;

        dbDelta( $disputes_sql );
        dbDelta( $messages_sql );
    }

    /**
     * Fraud detection signal log — real feature, Critical priority gap
     * from the enterprise audit. Deliberately rule-based and fully
     * auditable (every fired signal is a row here with its own reason),
     * not a black-box ML score — matches the audit's own explicit
     * recommendation to start explainable before any ML investment, and
     * means an admin reviewing a flagged account can see exactly why.
     */
    private static function create_fraud_tables( string $p, string $c ): void {
        $sql = <<<SQL
CREATE TABLE IF NOT EXISTS {$p}risk_events (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    subject_type ENUM('vendor','user','listing','review') NOT NULL,
    subject_id  BIGINT UNSIGNED NOT NULL,
    signal      VARCHAR(100)    NOT NULL,
    severity    ENUM('low','medium','high') DEFAULT 'medium',
    details     TEXT,
    ip_hash     VARCHAR(64)     DEFAULT '',
    reviewed    TINYINT(1)      DEFAULT 0,
    reviewed_by BIGINT UNSIGNED DEFAULT NULL,
    reviewed_at DATETIME        DEFAULT NULL,
    created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_subject (subject_type, subject_id),
    KEY idx_signal (signal),
    KEY idx_reviewed (reviewed)
) $c
SQL;
        dbDelta( $sql );
    }

    /**
     * Wallet/credits ledger — real feature, confirmed genuinely missing
     * during Phase 1 discovery (unlike coupons, which turned out to
     * already exist fully-built for vendor subscription purchases —
     * this is a real gap, not a re-verification correction). Ledger
     * design (every transaction is its own row with the resulting
     * balance recorded alongside it) rather than a single mutable
     * balance column — wallet balances are real financial liability and
     * need the same auditability as any other money-movement record in
     * this system, matching how gs_invoices already treats payments.
     */
    /**
     * SEO Search Entry URLs — lightweight per-microsite keyword→URL
     * mapping table backing the /{microsite-slug}/{seo-keyword-slug}/
     * dynamic entry-point feature. Deliberately NOT a duplicate of the
     * listing row: it only stores the keyword metadata + rendering
     * context (title/H1/meta/intro/canonical) needed to layer an SEO
     * entry point on top of the existing, single source-of-truth
     * listing (gs_listings). See GoodService\SEO\SeoEntryService.
     */
    private static function create_seo_microsite_entry_table( string $p, string $c ): void {
        $sql = <<<SQL
CREATE TABLE IF NOT EXISTS {$p}seo_microsite_entries (
    id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    listing_id          BIGINT UNSIGNED NOT NULL,
    keyword             VARCHAR(190)    NOT NULL,
    normalized_keyword  VARCHAR(190)    NOT NULL,
    keyword_slug        VARCHAR(190)    NOT NULL,
    intent_signature    VARCHAR(64)     NOT NULL DEFAULT '',
    search_intent       VARCHAR(190)    DEFAULT '',
    matched_service     VARCHAR(190)    DEFAULT '',
    matched_location     VARCHAR(190)    DEFAULT '',
    status              VARCHAR(20)     NOT NULL DEFAULT 'draft',
    indexable           TINYINT(1)      NOT NULL DEFAULT 0,
    sitemap_enabled     TINYINT(1)      NOT NULL DEFAULT 0,
    quality_score       TINYINT UNSIGNED NOT NULL DEFAULT 0,
    quality_label       VARCHAR(10)     DEFAULT '',
    rejection_reason    VARCHAR(255)    DEFAULT '',
    consolidated_into   BIGINT UNSIGNED DEFAULT NULL,
    title               VARCHAR(255)    DEFAULT '',
    meta_description    VARCHAR(320)    DEFAULT '',
    h1                  VARCHAR(255)    DEFAULT '',
    intro_content       TEXT,
    canonical_url       VARCHAR(500)    DEFAULT '',
    created_at          DATETIME        DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME        DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_listing_slug (listing_id, keyword_slug),
    KEY idx_listing (listing_id),
    KEY idx_status (status),
    KEY idx_indexable (indexable, sitemap_enabled),
    KEY idx_intent (listing_id, intent_signature)
) $c
SQL;
        dbDelta( $sql );
    }

    private static function create_wallet_tables( string $p, string $c ): void {
        $sql = <<<SQL
CREATE TABLE IF NOT EXISTS {$p}wallet_transactions (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         BIGINT UNSIGNED NOT NULL,
    type            ENUM('credit','debit') NOT NULL,
    amount          DECIMAL(10,2)   NOT NULL,
    balance_after   DECIMAL(10,2)   NOT NULL,
    source          VARCHAR(50)     NOT NULL,
    reference_type  VARCHAR(50)     DEFAULT '',
    reference_id    BIGINT UNSIGNED DEFAULT NULL,
    note            VARCHAR(255)    DEFAULT '',
    created_by      BIGINT UNSIGNED DEFAULT NULL,
    created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_user (user_id),
    KEY idx_source (source),
    KEY idx_reference (reference_type, reference_id)
) $c
SQL;
        dbDelta( $sql );
    }

    private static function get_table_definitions( string $p, string $c ): array {
        return [

            // ── 1. Vendor Profiles ───────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}vendor_profiles (
                id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id             BIGINT UNSIGNED NOT NULL,
                business_name       VARCHAR(255)    NOT NULL DEFAULT '',
                slug                VARCHAR(255)    NOT NULL DEFAULT '',
                phone               VARCHAR(30)     NOT NULL DEFAULT '',
                whatsapp            VARCHAR(30)              DEFAULT '',
                email               VARCHAR(255)             DEFAULT '',
                website             VARCHAR(500)             DEFAULT '',
                gst_number          VARCHAR(25)              DEFAULT '',
                pan_number          VARCHAR(15)              DEFAULT '',
                logo_url            VARCHAR(500)             DEFAULT '',
                cover_url           VARCHAR(500)             DEFAULT '',
                bio                 TEXT,
                address             TEXT,
                city                VARCHAR(100)             DEFAULT '',
                state               VARCHAR(100)             DEFAULT '',
                pincode             VARCHAR(10)              DEFAULT '',
                lat                 DECIMAL(10,8)            DEFAULT NULL,
                lng                 DECIMAL(11,8)            DEFAULT NULL,
                social_links        LONGTEXT,
                verification_status ENUM('unverified','pending','verified') DEFAULT 'unverified',
                verification_docs   LONGTEXT,
                profile_data        LONGTEXT,
                total_listings      INT UNSIGNED             DEFAULT 0,
                total_leads         INT UNSIGNED             DEFAULT 0,
                avg_rating          DECIMAL(3,2)             DEFAULT 0.00,
                response_rate       TINYINT UNSIGNED         DEFAULT 0,
                response_time       VARCHAR(50)              DEFAULT '',
                trust_score         TINYINT UNSIGNED         DEFAULT 0,
                is_active           TINYINT(1)               DEFAULT 1,
                created_at          DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at          DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_user   (user_id),
                UNIQUE KEY uq_slug   (slug),
                KEY idx_city         (city),
                KEY idx_state        (state),
                KEY idx_verification (verification_status),
                KEY idx_active       (is_active),
                KEY idx_trust        (trust_score)
            ) $c",

            // ── 2. Vendor Staff ──────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}vendor_staff (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id   BIGINT UNSIGNED NOT NULL,
                user_id     BIGINT UNSIGNED NOT NULL,
                role        ENUM('manager','staff','viewer') DEFAULT 'staff',
                permissions LONGTEXT,
                is_active   TINYINT(1) DEFAULT 1,
                created_at  DATETIME   DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_vendor (vendor_id),
                KEY idx_user   (user_id)
            ) $c",

            // ── 2b. Staff Permissions (ENTERPRISE-AUDIT FIX — Part 1 Critical:
            // per-user section-level RBAC for gs_staff/gs_moderator accounts.
            // One row per explicitly-GRANTED section for a RESTRICTED staff
            // member; zero rows for a user = fully unrestricted (see
            // Roles::can_access_section() for the enforcement logic and the
            // "empty = unrestricted" back-compat rationale). ─────────────────
            "CREATE TABLE IF NOT EXISTS {$p}staff_permissions (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id     BIGINT UNSIGNED NOT NULL,
                section     VARCHAR(30)     NOT NULL,
                created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_user_section (user_id, section),
                KEY idx_user (user_id)
            ) $c",

            // ── 2c. Admin Tiers (ENTERPRISE-AUDIT FIX — Part 2 Critical: "No
            // admin RBAC / granular roles" — is_admin_level() was previously a
            // single binary gate covering administrator/gs_manager, meaning
            // every admin-level account could grant free subscriptions, refund
            // payments, and edit every settings group including AI keys/SMTP.
            // One row per user who has been explicitly restricted to a
            // narrower tier (billing_admin/support_agent/read_only_auditor);
            // zero rows for a user = 'full_admin' (identical to today's
            // unrestricted behavior for every currently active admin/manager
            // account — see Roles::admin_tier() for the enforcement logic and
            // the same "empty = unrestricted" back-compat rationale already
            // used by staff_permissions above). ───────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}admin_tiers (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id     BIGINT UNSIGNED NOT NULL,
                tier        VARCHAR(30)     NOT NULL DEFAULT 'full_admin',
                set_by      BIGINT UNSIGNED NOT NULL DEFAULT 0,
                created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
                updated_at  DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_user (user_id)
            ) $c",

            // ── 2b. Admin alert preferences ─────────────────────────────────────
            // ENTERPRISE-AUDIT FIX (Part 2, High: "No notification-center/admin
            // alerting configuration screen — alerting is hardcoded per-event
            // inside services rather than admin-configurable"). One row per
            // event that has been explicitly reconfigured by an admin; an
            // event with no row here defaults to in_app_enabled=1,
            // email_enabled=1 — identical to every hardcoded notify_admins()
            // call site's current behavior today (see
            // NotificationService::admin_alert_channel_enabled() for the
            // enforcement, which is checked once inside notify_admins()
            // itself rather than at each of the ~20 call sites).
            "CREATE TABLE IF NOT EXISTS {$p}admin_alert_prefs (
                event_key      VARCHAR(80)  NOT NULL,
                in_app_enabled TINYINT(1)   NOT NULL DEFAULT 1,
                email_enabled  TINYINT(1)   NOT NULL DEFAULT 1,
                updated_by     BIGINT UNSIGNED NOT NULL DEFAULT 0,
                updated_at     DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (event_key)
            ) $c",

            // ── 3. Categories ────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}categories (
                id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
                parent_id       INT UNSIGNED             DEFAULT 0,
                name            VARCHAR(255)    NOT NULL,
                slug            VARCHAR(255)    NOT NULL,
                description     TEXT,
                icon_url        VARCHAR(500)             DEFAULT '',
                icon_svg        TEXT,
                icon_emoji      VARCHAR(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
                color           VARCHAR(7)               DEFAULT '#2563EB',
                listing_count   INT UNSIGNED             DEFAULT 0,
                listing_type    ENUM('service','product','both') DEFAULT 'both',
                seo_title       VARCHAR(255)             DEFAULT '',
                seo_desc        VARCHAR(500)             DEFAULT '',
                sort_order      INT                      DEFAULT 0,
                is_active       TINYINT(1)               DEFAULT 1,
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_slug (slug),
                KEY idx_parent    (parent_id),
                KEY idx_active    (is_active),
                KEY idx_sort      (sort_order)
            ) $c",

            // ── 3b. Locations (SaaS)
            "CREATE TABLE IF NOT EXISTS {$p}locations (
                id          INT UNSIGNED     NOT NULL AUTO_INCREMENT,
                parent_id   INT UNSIGNED     DEFAULT 0,
                type        ENUM('country','state','city','area') NOT NULL DEFAULT 'city',
                name        VARCHAR(255)     NOT NULL,
                slug        VARCHAR(255)     NOT NULL DEFAULT '',
                code        VARCHAR(10)      DEFAULT '',
                sort_order  INT              DEFAULT 0,
                is_active   TINYINT(1)       DEFAULT 1,
                listing_count INT UNSIGNED   DEFAULT 0,
                created_at  DATETIME         DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_parent (parent_id),
                KEY idx_type   (type),
                KEY idx_slug   (slug(100))
            ) $c",

            // ── 4. Listings ──────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}listings (
                id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_uid      VARCHAR(20)     NOT NULL DEFAULT '',
                vendor_id        BIGINT UNSIGNED NOT NULL,
                listing_type     ENUM('service','product','both') DEFAULT 'service',
                title            VARCHAR(255)    NOT NULL DEFAULT '',
                slug             VARCHAR(255)    NOT NULL DEFAULT '',
                tagline          VARCHAR(500)             DEFAULT '',
                short_desc       TEXT,
                full_desc        LONGTEXT,
                category_id      INT UNSIGNED             DEFAULT 0,
                subcategory_id   INT UNSIGNED             DEFAULT 0,
                tags             TEXT,
                price_min        DECIMAL(12,2)            DEFAULT NULL,
                price_max        DECIMAL(12,2)            DEFAULT NULL,
                price_unit       VARCHAR(50)              DEFAULT '',
                city             VARCHAR(100)             DEFAULT '',
                state            VARCHAR(100)             DEFAULT '',
                pincode          VARCHAR(10)              DEFAULT '',
                service_cities   LONGTEXT,
                lat              DECIMAL(10,8)            DEFAULT NULL,
                lng              DECIMAL(11,8)            DEFAULT NULL,
                phone            VARCHAR(30)              DEFAULT '',
                whatsapp         VARCHAR(30)              DEFAULT '',
                email            VARCHAR(255)             DEFAULT '',
                website          VARCHAR(500)             DEFAULT '',
                banner_url       VARCHAR(500)             DEFAULT '',
                logo_url         VARCHAR(500)             DEFAULT '',
                gallery          LONGTEXT,
                video_url        VARCHAR(500)             DEFAULT '',
                services_data    LONGTEXT,
                products_data    LONGTEXT,
                service_categories LONGTEXT,
                product_categories LONGTEXT,
                process_data     LONGTEXT,
                faq_data         LONGTEXT,
                why_choose_data  LONGTEXT,
                stats_data       LONGTEXT,
                highlights       LONGTEXT,
                certifications   TEXT,
                awards           TEXT,
                established_year YEAR                     DEFAULT NULL,
                team_size        VARCHAR(50)              DEFAULT '',
                opening_hours    LONGTEXT,
                layout_id        INT UNSIGNED             DEFAULT 1,
                form_data        LONGTEXT,
                -- Extended content columns (added via upgrade_columns for existing installs)
                hero_data           LONGTEXT,
                about_data          LONGTEXT,
                items_data          LONGTEXT,
                feedback_data       LONGTEXT,
                footer_data         LONGTEXT,
                customizer_data     LONGTEXT,
                mobile_data         LONGTEXT,
                team_data           LONGTEXT,
                clients_data        LONGTEXT,
                pricing_data        LONGTEXT,
                portfolio_data      LONGTEXT,
                testimonials_data   LONGTEXT,
                inquiry_modules_data LONGTEXT,
                sections_visible_data LONGTEXT,
                status           ENUM('draft','pending','active','suspended','expired','rejected','deleted') DEFAULT 'draft',
                rejection_reason TEXT,
                is_featured      TINYINT(1)               DEFAULT 0,
                is_verified      TINYINT(1)               DEFAULT 0,
                is_claimed       TINYINT(1)               DEFAULT 1,
                views_count      INT UNSIGNED             DEFAULT 0,
                leads_count      INT UNSIGNED             DEFAULT 0,
                avg_rating       DECIMAL(3,2)             DEFAULT 0.00,
                review_count     INT UNSIGNED             DEFAULT 0,
                expires_at       DATETIME                 DEFAULT NULL,
                custom_css       LONGTEXT,
                created_at       DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at       DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_slug   (slug),
                UNIQUE KEY uq_listing_uid (listing_uid),
                KEY idx_vendor       (vendor_id),
                KEY idx_category     (category_id),
                KEY idx_subcategory  (subcategory_id),
                KEY idx_status       (status),
                KEY idx_city         (city),
                KEY idx_featured     (is_featured),
                KEY idx_verified     (is_verified),
                KEY idx_type         (listing_type),
                KEY idx_expires      (expires_at),
                KEY idx_rating       (avg_rating),
                KEY idx_views        (views_count)
            ) $c",

            // ── 5. Listing SEO (reserved — not currently used) ───────────────────
            // SEO fields are stored inline on gs_listings (seo_title, seo_desc,
            // seo_keywords, og_image, seo_robots via upgrade_columns).
            // This table is kept for schema compatibility but is not read or
            // written by any current code path. Do not build new features on it
            // without first migrating the inline columns here.
            "CREATE TABLE IF NOT EXISTS {$p}listing_seo (
                id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id          BIGINT UNSIGNED NOT NULL,
                meta_title          VARCHAR(70)              DEFAULT '',
                meta_description    VARCHAR(165)             DEFAULT '',
                focus_keyword       VARCHAR(255)             DEFAULT '',
                og_title            VARCHAR(255)             DEFAULT '',
                og_description      TEXT,
                og_image_url        VARCHAR(500)             DEFAULT '',
                twitter_title       VARCHAR(255)             DEFAULT '',
                twitter_description TEXT,
                schema_json         LONGTEXT,
                canonical_url       VARCHAR(500)             DEFAULT '',
                robots              VARCHAR(50)              DEFAULT 'index,follow',
                sitemap_priority    DECIMAL(2,1)             DEFAULT 0.80,
                custom_title        TINYINT(1)               DEFAULT 0,
                custom_desc         TINYINT(1)               DEFAULT 0,
                last_generated_at   DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_listing (listing_id)
            ) $c",

            // ── 6. Subscription Plans ────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}subscription_plans (
                id                  INT UNSIGNED    NOT NULL AUTO_INCREMENT,
                name                VARCHAR(100)    NOT NULL,
                slug                VARCHAR(50)     NOT NULL,
                description         TEXT,
                price_monthly       DECIMAL(10,2)            DEFAULT 0.00,
                price_yearly        DECIMAL(10,2)            DEFAULT 0.00,
                price_quarterly     DECIMAL(10,2)            DEFAULT 0.00,
                currency            CHAR(3)                  DEFAULT 'INR',
                max_listings        INT                      DEFAULT 1,
                max_photos          INT                      DEFAULT 5,
                max_services        INT                      DEFAULT 10,
                max_products        INT                      DEFAULT 0,
                max_staff           INT                      DEFAULT 0,
                show_phone          TINYINT(1)               DEFAULT 1,
                show_whatsapp       TINYINT(1)               DEFAULT 1,
                show_email          TINYINT(1)               DEFAULT 0,
                show_website        TINYINT(1)               DEFAULT 0,
                show_analytics      TINYINT(1)               DEFAULT 0,
                show_seo_tools      TINYINT(1)               DEFAULT 0,
                priority_listing    TINYINT(1)               DEFAULT 0,
                featured_badge      TINYINT(1)               DEFAULT 0,
                custom_domain       TINYINT(1)               DEFAULT 0,
                lead_notifications  TINYINT(1)               DEFAULT 1,
                api_access          TINYINT(1)               DEFAULT 0,
                features_list       LONGTEXT,
                sort_order          INT                      DEFAULT 0,
                is_active           TINYINT(1)               DEFAULT 1,
                is_popular          TINYINT(1)               DEFAULT 0,
                color               VARCHAR(7)               DEFAULT '#2563EB',
                created_at          DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_slug (slug),
                KEY idx_active     (is_active),
                KEY idx_sort       (sort_order)
            ) $c",

            // ── 7. Subscriptions ─────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}subscriptions (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id       BIGINT UNSIGNED NOT NULL,
                plan_id         INT UNSIGNED             NOT NULL,
                plan_name       VARCHAR(100)             DEFAULT '',
                billing_cycle   ENUM('monthly','quarterly','yearly','lifetime') DEFAULT 'monthly',
                amount          DECIMAL(10,2)            DEFAULT 0.00,
                currency        CHAR(3)                  DEFAULT 'INR',
                status          ENUM('active','expired','cancelled','pending','trialing') DEFAULT 'pending',
                payment_method  VARCHAR(50)              DEFAULT '',
                payment_id      VARCHAR(255)             DEFAULT '',
                gateway         VARCHAR(50)              DEFAULT '',
                gateway_data    LONGTEXT,
                starts_at       DATETIME                 DEFAULT NULL,
                expires_at      DATETIME                 DEFAULT NULL,
                cancelled_at    DATETIME                 DEFAULT NULL,
                cancel_reason   TEXT,
                auto_renew      TINYINT(1)               DEFAULT 1,
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_vendor  (vendor_id),
                KEY idx_plan    (plan_id),
                KEY idx_status  (status),
                KEY idx_expires (expires_at)
            ) $c",

            // ── 8. Invoices ──────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}invoices (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                invoice_no      VARCHAR(30)     NOT NULL,
                vendor_id       BIGINT UNSIGNED NOT NULL,
                subscription_id BIGINT UNSIGNED          DEFAULT NULL,
                amount          DECIMAL(10,2)            DEFAULT 0.00,
                tax             DECIMAL(10,2)            DEFAULT 0.00,
                total           DECIMAL(10,2)            DEFAULT 0.00,
                currency        CHAR(3)                  DEFAULT 'INR',
                status          ENUM('draft','pending','paid','failed','refunded') DEFAULT 'pending',
                payment_id      VARCHAR(255)             DEFAULT '',
                gateway         VARCHAR(50)              DEFAULT '',
                items           LONGTEXT,
                notes           TEXT,
                paid_at         DATETIME                 DEFAULT NULL,
                due_date        DATETIME                 DEFAULT NULL,
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_invoice_no (invoice_no),
                KEY idx_vendor  (vendor_id),
                KEY idx_status  (status)
            ) $c",

            // ── 9. Leads ─────────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}leads (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id      BIGINT UNSIGNED NOT NULL,
                vendor_id       BIGINT UNSIGNED NOT NULL,
                name            VARCHAR(255)             DEFAULT '',
                phone           VARCHAR(30)              DEFAULT '',
                email           VARCHAR(255)             DEFAULT '',
                message         TEXT,
                city            VARCHAR(100)             DEFAULT '',
                source          VARCHAR(50)              DEFAULT 'organic',
                utm_source      VARCHAR(100)             DEFAULT '',
                utm_medium      VARCHAR(100)             DEFAULT '',
                utm_campaign    VARCHAR(100)             DEFAULT '',
                status          ENUM('new','seen','contacted','qualified','converted','junk') DEFAULT 'new',
                quality_score   TINYINT UNSIGNED         DEFAULT 0,
                product_name    VARCHAR(255)             DEFAULT '',
                product_price   VARCHAR(50)              DEFAULT '',
                quantity        VARCHAR(50)              DEFAULT '',
                purchase_date   DATE                     DEFAULT NULL,
                callback_date   DATETIME                 DEFAULT NULL,
                vendor_notes    TEXT,
                notes           TEXT,
                custom_fields   LONGTEXT,
                ip_address      VARCHAR(45)              DEFAULT '',
                user_agent      VARCHAR(500)             DEFAULT '',
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_listing (listing_id),
                KEY idx_vendor  (vendor_id),
                KEY idx_status  (status),
                KEY idx_created (created_at)
            ) $c",

            // ── 10. Lead Notes ───────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}lead_notes (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                lead_id     BIGINT UNSIGNED NOT NULL,
                user_id     BIGINT UNSIGNED NOT NULL,
                note        TEXT            NOT NULL,
                created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_lead (lead_id)
            ) $c",

            // ── 10a. WhatsApp Message Log — real fix: WhatsAppService::log()
            // and AjaxController's direct insert into this exact table name
            // both assumed it already existed and silently did nothing when
            // it didn't (log() explicitly checks SHOW TABLES and returns
            // early rather than erroring) — this table was never part of
            // the tracked schema anywhere, so on every install it never
            // existed, and every WhatsApp send (vendor lead alerts, booking
            // confirmations/reminders, verification OTPs) has been logging
            // nothing at all. provider_message_id + delivered_at/read_at
            // are new columns needed for the webhook-based delivery-status
            // tracking added alongside this fix — without a message ID to
            // correlate against, an incoming delivery receipt has no way to
            // find which outbound row it belongs to. ───────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}whatsapp_logs (
                id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                lead_id             BIGINT UNSIGNED NOT NULL DEFAULT 0,
                vendor_id           BIGINT UNSIGNED NOT NULL DEFAULT 0,
                direction           ENUM('outbound','inbound') DEFAULT 'outbound',
                phone               VARCHAR(30)              DEFAULT '',
                body                TEXT,
                status              ENUM('pending','sent','delivered','read','failed') DEFAULT 'pending',
                provider_message_id VARCHAR(128)             DEFAULT '',
                error_message       VARCHAR(500)             DEFAULT '',
                sent_at             DATETIME                 DEFAULT NULL,
                delivered_at        DATETIME                 DEFAULT NULL,
                read_at             DATETIME                 DEFAULT NULL,
                created_at          DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_lead (lead_id),
                KEY idx_vendor (vendor_id),
                KEY idx_provider_msg (provider_message_id),
                KEY idx_status (status)
            ) $c",

            // ── 10b. Diagnostic Scan Runs — real fix: this table was read
            // and written by DiagnosticsEngine::run_full_scan() and
            // AjaxController::runDiagnostics(), but was never part of the
            // tracked schema at all, meaning nothing guaranteed it existed
            // with the right columns on any given install. findings is
            // LONGTEXT specifically so a scan with many findings can never
            // be silently truncated by an undersized column. ───────────────
            "CREATE TABLE IF NOT EXISTS {$p}diag_runs (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                run_type        VARCHAR(20)     DEFAULT 'full',
                status          VARCHAR(20)     DEFAULT 'running',
                triggered_by    BIGINT UNSIGNED DEFAULT 0,
                summary         LONGTEXT,
                findings        LONGTEXT,
                health_score    TINYINT UNSIGNED DEFAULT 0,
                critical_count  INT UNSIGNED    DEFAULT 0,
                error_count     INT UNSIGNED    DEFAULT 0,
                warning_count   INT UNSIGNED    DEFAULT 0,
                duration_ms     INT UNSIGNED    DEFAULT 0,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                completed_at    DATETIME        DEFAULT NULL,
                PRIMARY KEY (id),
                KEY idx_status  (status),
                KEY idx_created (created_at)
            ) $c",

            // ── 11. Reviews ──────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}reviews (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id      BIGINT UNSIGNED NOT NULL,
                vendor_id       BIGINT UNSIGNED NOT NULL,
                user_id         BIGINT UNSIGNED          DEFAULT 0,
                reviewer_name   VARCHAR(255)             DEFAULT '',
                reviewer_email  VARCHAR(255)             DEFAULT '',
                reviewer_phone  VARCHAR(30)              DEFAULT '',
                rating          TINYINT UNSIGNED         DEFAULT 5,
                review_text     TEXT,
                vendor_reply    TEXT,
                vendor_reply_at DATETIME                 DEFAULT NULL,
                status          ENUM('pending','approved','rejected') DEFAULT 'pending',
                verified        TINYINT(1)               DEFAULT 0,
                would_recommend TINYINT(1)               DEFAULT NULL,
                helpful_count   INT UNSIGNED             DEFAULT 0,
                ip_address      VARCHAR(45)              DEFAULT '',
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_listing (listing_id),
                KEY idx_vendor  (vendor_id),
                KEY idx_status  (status),
                KEY idx_rating  (rating),
                KEY idx_email_listing (reviewer_email, listing_id)
            ) $c",

            // ── Listing Questions (Part 22 — Public Q&A) ──────────────────
            // Real feature — modeled directly on the reviews table above:
            // same asker/vendor-reply/status shape, since a public
            // question-and-answer is architecturally the same kind of
            // thing as a review with a vendor reply, just asked before
            // a purchase instead of after one.
            "CREATE TABLE IF NOT EXISTS {$p}listing_questions (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id      BIGINT UNSIGNED NOT NULL,
                vendor_id       BIGINT UNSIGNED NOT NULL,
                user_id         BIGINT UNSIGNED          DEFAULT 0,
                asker_name      VARCHAR(255)             DEFAULT '',
                asker_email     VARCHAR(255)             DEFAULT '',
                question_text   TEXT                     NOT NULL,
                vendor_answer   TEXT,
                vendor_answer_at DATETIME                DEFAULT NULL,
                status          ENUM('pending','answered','hidden') DEFAULT 'pending',
                helpful_count   INT UNSIGNED             DEFAULT 0,
                ip_address      VARCHAR(45)              DEFAULT '',
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_listing (listing_id),
                KEY idx_vendor  (vendor_id),
                KEY idx_status  (status)
            ) $c",

            // ── 11b. Review Audit Log ───────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}review_audit_log (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                review_id       BIGINT UNSIGNED NOT NULL,
                action          VARCHAR(40)              NOT NULL,
                admin_user_id   BIGINT UNSIGNED          DEFAULT NULL,
                admin_name      VARCHAR(255)             DEFAULT '',
                details         TEXT,
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_review  (review_id),
                KEY idx_action  (action),
                KEY idx_created (created_at)
            ) $c",

            // ── 12. Messages ─────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}message_threads (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                participant_a   BIGINT UNSIGNED NOT NULL,
                participant_b   BIGINT UNSIGNED NOT NULL,
                listing_id      BIGINT UNSIGNED          DEFAULT NULL,
                subject         VARCHAR(255)             DEFAULT '',
                last_message    TEXT,
                last_message_at DATETIME                 DEFAULT NULL,
                unread_a        INT UNSIGNED             DEFAULT 0,
                unread_b        INT UNSIGNED             DEFAULT 0,
                is_archived_a   TINYINT(1)               DEFAULT 0,
                is_archived_b   TINYINT(1)               DEFAULT 0,
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_pa (participant_a),
                KEY idx_pb (participant_b)
            ) $c",

            "CREATE TABLE IF NOT EXISTS {$p}messages (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                thread_id   BIGINT UNSIGNED NOT NULL,
                sender_id   BIGINT UNSIGNED NOT NULL,
                body        TEXT            NOT NULL,
                attachments LONGTEXT,
                is_read     TINYINT(1)      DEFAULT 0,
                created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_thread (thread_id),
                KEY idx_sender (sender_id)
            ) $c",

            // ENTERPRISE-AUDIT FIX (Part 2, Security/reliability, High:
            // "Dispute refund dual-control is a genuine strength... but it's
            // the only place with this control — Grant Plan (bypasses
            // payment entirely) and Fix Payment Status (reclassifies
            // revenue) have no equivalent second-approval, despite directly
            // affecting revenue reporting"). Generic pending-approval queue
            // (not one more copy of gs_disputes' pending_refund_* columns
            // bolted onto two more tables) so a future third action can
            // reuse the same mechanism instead of a fourth bespoke copy.
            // action_type + payload (JSON of the original validated request)
            // let confirmPendingAdminAction() re-execute the exact same
            // underlying logic the direct (under-threshold) path already
            // uses, rather than duplicating it.
            "CREATE TABLE IF NOT EXISTS {$p}pending_admin_actions (
                id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                action_type    VARCHAR(50)     NOT NULL,
                payload        LONGTEXT        NOT NULL,
                amount         DECIMAL(10,2)   DEFAULT 0.00,
                summary        VARCHAR(500)    DEFAULT '',
                reason         TEXT,
                status         ENUM('pending','confirmed','rejected') DEFAULT 'pending',
                requested_by   BIGINT UNSIGNED NOT NULL,
                requested_at   DATETIME        DEFAULT CURRENT_TIMESTAMP,
                confirmed_by   BIGINT UNSIGNED DEFAULT NULL,
                confirmed_at   DATETIME        DEFAULT NULL,
                PRIMARY KEY (id),
                KEY idx_status (status),
                KEY idx_type   (action_type)
            ) $c",

            // ── 13. Complaints ───────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}complaints (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                complainant_id  BIGINT UNSIGNED          DEFAULT 0,
                vendor_id       BIGINT UNSIGNED          DEFAULT 0,
                listing_id      BIGINT UNSIGNED          DEFAULT 0,
                assigned_to     BIGINT UNSIGNED          DEFAULT NULL,
                type            VARCHAR(50)              DEFAULT '',
                subject         VARCHAR(255)             DEFAULT '',
                description     TEXT,
                evidence        LONGTEXT,
                status          ENUM('open','in_review','resolved','closed','dismissed') DEFAULT 'open',
                priority        ENUM('low','medium','high','critical') DEFAULT 'medium',
                resolution      TEXT,
                resolved_at     DATETIME                 DEFAULT NULL,
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_complainant (complainant_id),
                KEY idx_vendor      (vendor_id),
                KEY idx_status      (status),
                KEY idx_priority    (priority)
            ) $c",

            "CREATE TABLE IF NOT EXISTS {$p}complaint_responses (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                complaint_id BIGINT UNSIGNED NOT NULL,
                user_id      BIGINT UNSIGNED NOT NULL,
                message      TEXT            NOT NULL,
                attachments  LONGTEXT,
                is_internal  TINYINT(1)      DEFAULT 0,
                created_at   DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_complaint (complaint_id)
            ) $c",

            // ── 14. Notifications ────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}notifications (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id     BIGINT UNSIGNED NOT NULL,
                type        VARCHAR(50)              DEFAULT '',
                title       VARCHAR(255)             DEFAULT '',
                message     TEXT,
                action_url  VARCHAR(500)             DEFAULT '',
                icon        VARCHAR(50)              DEFAULT 'bell',
                color       VARCHAR(7)               DEFAULT '#2563EB',
                data        LONGTEXT,
                is_read     TINYINT(1)               DEFAULT 0,
                email_sent  TINYINT(1)               DEFAULT 0,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_user   (user_id),
                KEY idx_read   (is_read),
                KEY idx_type   (type),
                KEY idx_created(created_at)
            ) $c",

            // ── 15. Activity Log ─────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}activity_log (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id     BIGINT UNSIGNED          DEFAULT 0,
                action      VARCHAR(100)             DEFAULT '',
                object_type VARCHAR(50)              DEFAULT '',
                object_id   BIGINT UNSIGNED          DEFAULT 0,
                description TEXT,
                old_value   LONGTEXT,
                new_value   LONGTEXT,
                ip_address  VARCHAR(45)              DEFAULT '',
                user_agent  VARCHAR(500)             DEFAULT '',
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_user    (user_id),
                KEY idx_action  (action),
                KEY idx_object  (object_type, object_id),
                KEY idx_created (created_at)
            ) $c",

            // ── 16. Analytics ────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}analytics (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id  BIGINT UNSIGNED NOT NULL,
                vendor_id   BIGINT UNSIGNED NOT NULL,
                event_type  ENUM('view','lead','call','whatsapp','email','website','map','share','save','review') DEFAULT 'view',
                source      VARCHAR(100)             DEFAULT '',
                city        VARCHAR(100)             DEFAULT '',
                device      VARCHAR(20)              DEFAULT '',
                ip_address  VARCHAR(45)              DEFAULT '',
                user_agent  VARCHAR(500)             DEFAULT '',
                referrer    VARCHAR(500)             DEFAULT '',
                session_id  VARCHAR(64)              DEFAULT '',
                user_id     BIGINT UNSIGNED          DEFAULT NULL,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_listing (listing_id),
                KEY idx_vendor  (vendor_id),
                KEY idx_event   (event_type),
                KEY idx_created (created_at),
                KEY idx_city    (city)
            ) $c",

            // ── 17. Saved Listings ───────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}saved_listings (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id     BIGINT UNSIGNED NOT NULL,
                listing_id  BIGINT UNSIGNED NOT NULL,
                created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_user_listing (user_id, listing_id),
                KEY idx_user    (user_id),
                KEY idx_listing (listing_id)
            ) $c",

            // ── 18. Bookings ─────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}bookings (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id      BIGINT UNSIGNED NOT NULL,
                vendor_id       BIGINT UNSIGNED NOT NULL,
                user_id         BIGINT UNSIGNED          DEFAULT 0,
                customer_name   VARCHAR(255)             DEFAULT '',
                customer_phone  VARCHAR(30)              DEFAULT '',
                customer_email  VARCHAR(255)             DEFAULT '',
                service_name    VARCHAR(255)             DEFAULT '',
                booking_date    DATE                     DEFAULT NULL,
                booking_time    TIME                     DEFAULT NULL,
                duration_mins   INT UNSIGNED             DEFAULT 60,
                amount          DECIMAL(10,2)            DEFAULT 0.00,
                status          ENUM('pending','confirmed','completed','cancelled','no_show') DEFAULT 'pending',
                notes           TEXT,
                custom_fields   LONGTEXT,
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_listing (listing_id),
                KEY idx_vendor  (vendor_id),
                KEY idx_date    (booking_date),
                KEY idx_status  (status)
            ) $c",

            // ── Phase 12: Enterprise Diagnostics — Error Log ─────────────────
            // Stores every captured error from every source: JS, PHP, DB,
            // network, security, performance. Keyed by source + type for
            // fast dashboard aggregation.
            "CREATE TABLE IF NOT EXISTS {$p}error_log (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                source          ENUM('js','php','db','network','security','performance','wp','integration','browser','infrastructure') DEFAULT 'php',
                type            VARCHAR(100)    NOT NULL DEFAULT 'generic',
                severity        ENUM('critical','error','warning','notice','info') DEFAULT 'error',
                message         TEXT            NOT NULL,
                context         VARCHAR(255)    DEFAULT '',
                file_path       VARCHAR(500)    DEFAULT '',
                line_number     INT UNSIGNED    DEFAULT 0,
                stack_trace     LONGTEXT,
                url             VARCHAR(1000)   DEFAULT '',
                user_agent      VARCHAR(500)    DEFAULT '',
                user_id         BIGINT UNSIGNED DEFAULT 0,
                request_data    LONGTEXT,
                root_cause      TEXT,
                suggested_fix   TEXT,
                is_resolved     TINYINT(1)      DEFAULT 0,
                occurrence_count INT UNSIGNED   DEFAULT 1,
                first_seen      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                last_seen       DATETIME        DEFAULT CURRENT_TIMESTAMP,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_source_severity (source, severity),
                KEY idx_type (type),
                KEY idx_last_seen (last_seen),
                KEY idx_resolved (is_resolved),
                KEY idx_user (user_id)
            ) $c",

            // ── Diagnostic Runs — see the {$p}diag_runs definition earlier
            // in this file. A redundant, near-identical duplicate of this
            // same table used to be here — removed rather than left to
            // silently merge column definitions with the real one via
            // dbDelta. ───────────────────────────────────────────────────

            // Customers who want a slot that is fully booked. When a booking
            // is cancelled, a cron job notifies the next person in line.
            "CREATE TABLE IF NOT EXISTS {$p}booking_waitlist (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id      BIGINT UNSIGNED NOT NULL,
                user_id         BIGINT UNSIGNED DEFAULT 0,
                customer_name   VARCHAR(255)    DEFAULT '',
                customer_phone  VARCHAR(30)     DEFAULT '',
                customer_email  VARCHAR(255)    DEFAULT '',
                preferred_date  DATE            NOT NULL,
                preferred_time  TIME            DEFAULT NULL,
                status          ENUM('waiting','notified','booked','expired') DEFAULT 'waiting',
                notified_at     DATETIME        DEFAULT NULL,
                claim_expires   DATETIME        DEFAULT NULL,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_wl_listing_date (listing_id, preferred_date, status),
                KEY idx_wl_user (user_id)
            ) $c",

            // ── 19. Requirements ─────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}requirements (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                poster_name     VARCHAR(255)             DEFAULT '',
                poster_email    VARCHAR(255)             DEFAULT '',
                poster_phone    VARCHAR(30)              DEFAULT '',
                poster_city     VARCHAR(100)             DEFAULT '',
                category_id     INT UNSIGNED             DEFAULT 0,
                title           VARCHAR(255)             DEFAULT '',
                description     TEXT,
                budget_min      DECIMAL(12,2)            DEFAULT NULL,
                budget_max      DECIMAL(12,2)            DEFAULT NULL,
                deadline        DATE                     DEFAULT NULL,
                status          ENUM('open','fulfilled','expired','closed') DEFAULT 'open',
                responses_count INT UNSIGNED             DEFAULT 0,
                expires_at      DATETIME                 DEFAULT NULL,
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_category (category_id),
                KEY idx_status   (status),
                KEY idx_city     (poster_city)
            ) $c",

            "CREATE TABLE IF NOT EXISTS {$p}requirement_bids (
                id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                requirement_id BIGINT UNSIGNED NOT NULL,
                vendor_id      BIGINT UNSIGNED NOT NULL,
                bid_amount     DECIMAL(12,2)            DEFAULT NULL,
                timeline       VARCHAR(100)             DEFAULT '',
                message        TEXT,
                status         ENUM('pending','shortlisted','accepted','rejected') DEFAULT 'pending',
                created_at     DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_req    (requirement_id),
                KEY idx_vendor (vendor_id)
            ) $c",

            // ── 20. Products & Services ──────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}products (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id   BIGINT UNSIGNED NOT NULL,
                listing_id  BIGINT UNSIGNED          DEFAULT NULL,
                name        VARCHAR(255)             DEFAULT '',
                description TEXT,
                price       DECIMAL(12,2)            DEFAULT NULL,
                price_type  ENUM('fixed','starting','negotiable','free') DEFAULT 'fixed',
                sku         VARCHAR(100)             DEFAULT '',
                image_url   VARCHAR(500)             DEFAULT '',
                gallery     LONGTEXT,
                icon        VARCHAR(50)              DEFAULT '',
                stock       INT                      DEFAULT -1,
                is_active   TINYINT(1)               DEFAULT 1,
                sort_order  INT UNSIGNED             DEFAULT 0,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_vendor  (vendor_id),
                KEY idx_listing (listing_id),
                KEY idx_active  (is_active)
            ) $c",

            "CREATE TABLE IF NOT EXISTS {$p}services (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id   BIGINT UNSIGNED NOT NULL,
                listing_id  BIGINT UNSIGNED          DEFAULT NULL,
                name        VARCHAR(255)             DEFAULT '',
                description TEXT,
                price       DECIMAL(12,2)            DEFAULT NULL,
                price_type  ENUM('fixed','starting','hourly','daily','negotiable','free') DEFAULT 'starting',
                icon        VARCHAR(50)              DEFAULT '',
                image_url   VARCHAR(500)             DEFAULT '',
                duration    VARCHAR(100)             DEFAULT '',
                is_active   TINYINT(1)               DEFAULT 1,
                sort_order  INT UNSIGNED             DEFAULT 0,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_vendor  (vendor_id),
                KEY idx_listing (listing_id),
                KEY idx_active  (is_active)
            ) $c",

            // ── 21. Verification Docs ────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}verification_docs (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id   BIGINT UNSIGNED NOT NULL,
                doc_type    VARCHAR(50)              DEFAULT '',
                doc_url     VARCHAR(500)             DEFAULT '',
                doc_name    VARCHAR(255)             DEFAULT '',
                status      ENUM('pending','approved','rejected') DEFAULT 'pending',
                reviewer_id BIGINT UNSIGNED          DEFAULT NULL,
                notes       TEXT,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                reviewed_at DATETIME                 DEFAULT NULL,
                PRIMARY KEY (id),
                KEY idx_vendor (vendor_id),
                KEY idx_status (status)
            ) $c",

            // ── 22. Quick Replies ────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}quick_replies (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id   BIGINT UNSIGNED NOT NULL,
                title       VARCHAR(255)             DEFAULT '',
                body        TEXT,
                sort_order  INT UNSIGNED             DEFAULT 0,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_vendor (vendor_id)
            ) $c",

            // ── 23. Promotions ───────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}promotions (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id  BIGINT UNSIGNED NOT NULL,
                vendor_id   BIGINT UNSIGNED NOT NULL,
                type        ENUM('featured','top','spotlight','banner') DEFAULT 'featured',
                position    INT UNSIGNED             DEFAULT 0,
                amount      DECIMAL(10,2)            DEFAULT 0.00,
                status      ENUM('active','expired','cancelled') DEFAULT 'active',
                starts_at   DATETIME                 DEFAULT NULL,
                expires_at  DATETIME                 DEFAULT NULL,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_listing (listing_id),
                KEY idx_vendor  (vendor_id),
                KEY idx_status  (status),
                KEY idx_type    (type)
            ) $c",

            // ── 24. Coupons ──────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}coupons (
                id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
                code            VARCHAR(30)     NOT NULL,
                name            VARCHAR(100)             DEFAULT '',
                type            ENUM('percentage','fixed') DEFAULT 'percentage',
                value           DECIMAL(10,2)            DEFAULT 0.00,
                min_amount      DECIMAL(10,2)            DEFAULT 0.00,
                max_uses        INT UNSIGNED             DEFAULT NULL,
                uses_count      INT UNSIGNED             DEFAULT 0,
                plan_ids        TEXT,
                expires_at      DATETIME                 DEFAULT NULL,
                is_active       TINYINT(1)               DEFAULT 1,
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_code (code),
                KEY idx_active (is_active)
            ) $c",

            // ── 25. Layout Templates ─────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}layout_templates (
                id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
                name        VARCHAR(100)    NOT NULL,
                description TEXT,
                config      LONGTEXT,
                thumbnail   VARCHAR(500)             DEFAULT '',
                is_active   TINYINT(1)               DEFAULT 1,
                sort_order  INT                      DEFAULT 0,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_active (is_active)
            ) $c",

            // ── 26. Form Definitions ─────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}form_definitions (
                id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
                name        VARCHAR(100)    NOT NULL,
                slug        VARCHAR(100)    NOT NULL,
                fields      LONGTEXT,
                settings    LONGTEXT,
                is_active   TINYINT(1)               DEFAULT 1,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_slug (slug)
            ) $c",

            // ── 27. Settings ─────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}settings (
                id            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
                setting_key   VARCHAR(100)    NOT NULL,
                setting_value LONGTEXT,
                setting_group VARCHAR(50)              DEFAULT 'general',
                created_at    DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at    DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_key (setting_key),
                KEY idx_group (setting_group)
            ) $c",

            // ── 28. Email Templates ──────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}email_templates (
                id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
                name        VARCHAR(100)    NOT NULL,
                slug        VARCHAR(100)    NOT NULL,
                subject     VARCHAR(255)             DEFAULT '',
                body        LONGTEXT,
                variables   TEXT,
                is_active   TINYINT(1)               DEFAULT 1,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_slug (slug)
            ) $c",

            // ── WhatsApp Category Templates — real fix, Audit Section F:
            // WhatsAppService::CATEGORY_TEMPLATES was a hardcoded PHP
            // constant with no admin UI, no database backing, and no way
            // to edit a template without a code deployment — unlike email
            // templates, which already had all of that. Named
            // whatsapp_CATEGORY_templates specifically (not
            // whatsapp_templates) because that name is already taken —
            // gs_whatsapp_templates already exists elsewhere in this same
            // schema for a completely different, unrelated feature
            // (vendor_id-scoped personal canned reply snippets a vendor
            // manually picks from while replying to an inquiry — see
            // AjaxController::createWaTemplate()). This table is the
            // opposite: platform-wide, category-keyed templates that
            // auto-fill the "Message Vendor" WhatsApp deep-link on
            // listing pages. Mirrors gs_email_templates' shape
            // (slug/body/variables/is_active) so the admin UI and save
            // handler can reuse the same pattern. category_slug is
            // nullable+unique-when-set rather than a strict UNIQUE KEY,
            // since 'default' is the fallback template and every other
            // row is keyed to one category slug — a plain UNIQUE KEY on a
            // column that's sometimes reused isn't right here, so
            // uniqueness is enforced at the application layer instead. ──
            // ── Listing Detail Section Templates — real feature, Vendor Listing
            // Form "View More" popup redesign: the admin-manageable library of
            // section TYPES a vendor can add to a service/product's structured
            // detail popup (Overview, Key Features, FAQs, Pricing, etc.) — per
            // explicit request that admin can create/edit/delete these without
            // any code change. This table is the type library only; the actual
            // per-listing CONTENT for each section a vendor fills in lives
            // nested inside services_data/items_data/products_data's existing
            // JSON blobs (confirmed by tracing saveListing()'s $pf() handler:
            // those blobs pass through whole, un-stripped, already size-capped
            // at 2MB — a new nested key needs no backend change to persist). ──
            "CREATE TABLE IF NOT EXISTS {$p}section_templates (
                id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
                slug            VARCHAR(100)    NOT NULL,
                name            VARCHAR(100)    NOT NULL,
                icon            VARCHAR(10)     DEFAULT '',
                content_type    ENUM('richtext','list','numbered_list','faq','table','gallery','cards','accordion','highlight','specs') DEFAULT 'richtext',
                description     VARCHAR(255)    DEFAULT '',
                is_active       TINYINT(1)      DEFAULT 1,
                sort_order      INT             DEFAULT 0,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_slug (slug)
            ) $c",

            "CREATE TABLE IF NOT EXISTS {$p}whatsapp_category_templates (
                id              INT UNSIGNED    NOT NULL AUTO_INCREMENT,
                name            VARCHAR(100)    NOT NULL,
                category_slug   VARCHAR(100)    NOT NULL,
                body            TEXT            NOT NULL,
                variables       TEXT,
                is_active       TINYINT(1)               DEFAULT 1,
                vendor_id       BIGINT UNSIGNED          DEFAULT 0,
                language        VARCHAR(10)              DEFAULT 'en',
                status          ENUM('draft','pending_review','approved') DEFAULT 'approved',
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_category (category_slug),
                KEY idx_vendor (vendor_id),
                KEY idx_status (status)
            ) $c",

            // ── WhatsApp Category Template Versions — real fix, Audit
            // Section F ("Template versioning"): every save to a row in
            // whatsapp_category_templates snapshots the PREVIOUS body here
            // first, so a change can be reviewed or reverted rather than
            // silently overwriting whatever was there before with no
            // record of it. ─────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}whatsapp_category_template_versions (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                template_id     INT UNSIGNED    NOT NULL,
                body            TEXT            NOT NULL,
                edited_by       BIGINT UNSIGNED          DEFAULT 0,
                edited_by_name  VARCHAR(255)             DEFAULT '',
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_template (template_id)
            ) $c",

            // ── 30. Platform Staff ────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}staff (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id     BIGINT UNSIGNED NOT NULL,
                role        VARCHAR(50)              DEFAULT 'staff',
                department  VARCHAR(50)              DEFAULT '',
                permissions LONGTEXT,
                is_active   TINYINT(1)               DEFAULT 1,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_user (user_id)
            ) $c",

            // ── 31. Testimonials ─────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}testimonials (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name            VARCHAR(255)             DEFAULT '',
                designation     VARCHAR(255)             DEFAULT '',
                company         VARCHAR(255)             DEFAULT '',
                avatar_url      VARCHAR(500)             DEFAULT '',
                testimonial     TEXT,
                rating          TINYINT UNSIGNED         DEFAULT 5,
                is_featured     TINYINT(1)               DEFAULT 0,
                is_active       TINYINT(1)               DEFAULT 1,
                sort_order      INT                      DEFAULT 0,
                created_at      DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_featured (is_featured),
                KEY idx_active   (is_active)
            ) $c",

            // ── 32. Pages (Custom CMS pages) ──────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}pages (
                id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
                slug        VARCHAR(100)    NOT NULL,
                title       VARCHAR(255)             DEFAULT '',
                content     LONGTEXT,
                meta_title  VARCHAR(255)             DEFAULT '',
                meta_desc   VARCHAR(500)             DEFAULT '',
                is_active   TINYINT(1)               DEFAULT 1,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_slug (slug)
            ) $c",

            // ── 33. Media Registry ───────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}media (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id   BIGINT UNSIGNED          DEFAULT 0,
                wp_media_id BIGINT UNSIGNED          DEFAULT 0,
                url         VARCHAR(1000)            DEFAULT '',
                thumbnail   VARCHAR(1000)            DEFAULT '',
                file_name   VARCHAR(255)             DEFAULT '',
                file_type   VARCHAR(50)              DEFAULT '',
                file_size   INT UNSIGNED             DEFAULT 0,
                context     VARCHAR(50)              DEFAULT '',
                tags        VARCHAR(500)             DEFAULT '',
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_vendor (vendor_id),
                KEY idx_wp     (wp_media_id)
            ) $c",

            // ── 34. SEO Sitemap Cache ─────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}sitemap_entries (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                url          VARCHAR(500)    NOT NULL,
                lastmod      DATETIME                 DEFAULT NULL,
                changefreq   VARCHAR(20)              DEFAULT 'weekly',
                priority     DECIMAL(2,1)             DEFAULT 0.50,
                type         VARCHAR(30)              DEFAULT 'listing',
                ref_id       BIGINT UNSIGNED          DEFAULT 0,
                created_at   DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_type (type),
                KEY idx_ref  (ref_id)
            ) $c",

            // ── 35. Search Index (materialized view helper) ───────────────────
            "CREATE TABLE IF NOT EXISTS {$p}search_index (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id  BIGINT UNSIGNED NOT NULL,
                content     LONGTEXT        NOT NULL,
                city        VARCHAR(100)             DEFAULT '',
                category_id INT UNSIGNED             DEFAULT 0,
                status      VARCHAR(20)              DEFAULT 'active',
                updated_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_listing (listing_id),
                KEY idx_city     (city),
                KEY idx_category (category_id)
            ) $c",

            // ── 36. API Keys ──────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}api_keys (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id   BIGINT UNSIGNED NOT NULL,
                name        VARCHAR(100)             DEFAULT '',
                api_key     VARCHAR(64)     NOT NULL,
                secret      VARCHAR(64)     NOT NULL,
                permissions LONGTEXT,
                last_used   DATETIME                 DEFAULT NULL,
                is_active   TINYINT(1)               DEFAULT 1,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_key (api_key),
                KEY idx_vendor (vendor_id)
            ) $c",

            // ── 38. Plan Requests (manual / offline-payment plan assignment & approval) ──
            // Extended (Manual Subscription & Offline Payment system) to capture full
            // offline payment detail, richer lifecycle status, and admin-assignment metadata.
            // billing_cycle/duration values: trial, monthly, quarterly, half_yearly, annual,
            // lifetime, custom (custom uses custom_months / activation_date+expiry_date).
            "CREATE TABLE IF NOT EXISTS {$p}plan_requests (
                id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id           BIGINT UNSIGNED NOT NULL,
                plan_id             INT UNSIGNED    NOT NULL,
                plan_name           VARCHAR(100)    DEFAULT '',
                source              ENUM('vendor_request','admin_assigned') DEFAULT 'vendor_request',
                status              ENUM(
                                        'draft','pending','under_review','payment_verification_pending',
                                        'info_required','on_hold','approved','rejected','expired',
                                        'cancelled','completed'
                                    ) DEFAULT 'pending',
                billing_cycle       VARCHAR(20)     DEFAULT 'monthly',
                custom_months       SMALLINT UNSIGNED DEFAULT 0,
                activation_date     DATETIME        DEFAULT NULL,
                expiry_date         DATETIME        DEFAULT NULL,
                renewal_date        DATETIME        DEFAULT NULL,
                grace_period_days   SMALLINT UNSIGNED DEFAULT 0,
                auto_expiry         TINYINT(1)      DEFAULT 1,
                list_price          DECIMAL(10,2)   DEFAULT 0.00,
                override_price      DECIMAL(10,2)   DEFAULT NULL,
                discount_type       ENUM('none','percentage','fixed','complimentary','staff','coupon_equivalent','credit_adjustment') DEFAULT 'none',
                discount_value      DECIMAL(10,2)   DEFAULT 0.00,
                discount_reason     VARCHAR(255)    DEFAULT '',
                final_amount        DECIMAL(10,2)   DEFAULT 0.00,
                amount_paid         DECIMAL(10,2)   DEFAULT 0.00,
                balance_due         DECIMAL(10,2)   DEFAULT 0.00,
                currency            CHAR(3)         DEFAULT 'INR',
                payment_mode        VARCHAR(30)     DEFAULT '',
                transaction_id      VARCHAR(120)    DEFAULT '',
                utr_number          VARCHAR(60)     DEFAULT '',
                cheque_number       VARCHAR(40)     DEFAULT '',
                bank_name           VARCHAR(120)    DEFAULT '',
                bank_branch         VARCHAR(120)    DEFAULT '',
                payment_date        DATE            DEFAULT NULL,
                reference_number    VARCHAR(100)    DEFAULT '',
                payment_proof_ids   TEXT,
                internal_notes      TEXT,
                note                TEXT,
                admin_note          TEXT,
                assigned_by         BIGINT UNSIGNED DEFAULT 0,
                verified_by         BIGINT UNSIGNED DEFAULT 0,
                verified_at         DATETIME        DEFAULT NULL,
                approved_by         BIGINT UNSIGNED DEFAULT 0,
                approved_at         DATETIME        DEFAULT NULL,
                cancelled_at        DATETIME        DEFAULT NULL,
                subscription_id     BIGINT UNSIGNED DEFAULT 0,
                resulting_action    VARCHAR(20)     DEFAULT '',
                is_deleted          TINYINT(1)      DEFAULT 0,
                created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at          DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_vendor      (vendor_id),
                KEY idx_status      (status),
                KEY idx_source      (source),
                KEY idx_expiry      (expiry_date),
                KEY idx_deleted     (is_deleted)
            ) $c",

            // ── 38b. Plan Request Payments (supports multiple/partial installments) ──
            "CREATE TABLE IF NOT EXISTS {$p}plan_request_payments (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                request_id      BIGINT UNSIGNED NOT NULL,
                vendor_id       BIGINT UNSIGNED NOT NULL,
                amount          DECIMAL(10,2)   DEFAULT 0.00,
                currency        CHAR(3)         DEFAULT 'INR',
                payment_mode    VARCHAR(30)     DEFAULT '',
                transaction_id  VARCHAR(120)    DEFAULT '',
                utr_number      VARCHAR(60)     DEFAULT '',
                cheque_number   VARCHAR(40)     DEFAULT '',
                bank_name       VARCHAR(120)    DEFAULT '',
                bank_branch     VARCHAR(120)    DEFAULT '',
                payment_date    DATE            DEFAULT NULL,
                proof_ids       TEXT,
                status          ENUM('pending','partial','verified','rejected') DEFAULT 'pending',
                recorded_by     BIGINT UNSIGNED DEFAULT 0,
                verified_by     BIGINT UNSIGNED DEFAULT 0,
                verified_at     DATETIME        DEFAULT NULL,
                notes           TEXT,
                created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_request (request_id),
                KEY idx_vendor   (vendor_id),
                KEY idx_status   (status)
            ) $c",

            // ── 37. Job Queue ──────────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}job_queue (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                job_type     VARCHAR(100)    NOT NULL,
                payload      LONGTEXT,
                status       ENUM('pending','running','done','failed') DEFAULT 'pending',
                attempts     TINYINT UNSIGNED DEFAULT 0,
                error        TEXT,
                run_after    DATETIME         DEFAULT CURRENT_TIMESTAMP,
                started_at   DATETIME         DEFAULT NULL,
                completed_at DATETIME         DEFAULT NULL,
                created_at   DATETIME         DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_status    (status),
                KEY idx_run_after (run_after),
                KEY idx_type      (job_type)
            ) $c",

            // ── 38b. Data export requests ──────────────────────────────────────
            // ENTERPRISE-AUDIT FIX (Part 4 §6, Medium: "customer data export
            // running synchronous/blocking rather than queued"). Investigation
            // found the gap was deeper than "blocking": AjaxController's
            // existing exportMyData() (gs_export_my_data) had NO live caller
            // at all — its only reference is in customer-dashboard.php, which
            // was confirmed dead/unreachable in an earlier session (kept in
            // place per DiagnosticsEngine's deliberate monitoring of it, not
            // deleted). Real fix wires a genuinely queued flow (via the
            // existing JobQueue — see 'data_export' case in JobQueue::handle())
            // into the LIVE customer dashboard (other-dashboards.php, Profile
            // screen) instead. One row per request; token is the only thing
            // needed to download (single-use-safe via status, time-bounded via
            // expires_at) so the download link works from an emailed link
            // without requiring an active login session.
            "CREATE TABLE IF NOT EXISTS {$p}data_exports (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id      BIGINT UNSIGNED NOT NULL,
                status       ENUM('pending','processing','done','failed') DEFAULT 'pending',
                token        VARCHAR(64)      DEFAULT '',
                file_path    VARCHAR(500)     DEFAULT '',
                error        TEXT,
                expires_at   DATETIME         DEFAULT NULL,
                created_at   DATETIME         DEFAULT CURRENT_TIMESTAMP,
                completed_at DATETIME         DEFAULT NULL,
                PRIMARY KEY (id),
                KEY idx_user   (user_id),
                KEY idx_token  (token),
                KEY idx_status (status)
            ) $c",

            // ── 38c. Saved payment methods ──────────────────────────────────────
            // ENTERPRISE-AUDIT FIX (Part 3, large, deliberately deferred across
            // multiple prior windows: "no saved payment methods"). One row per
            // saved card, per gateway. gateway_ref is the gateway's own id for
            // the reusable-charge object: a Stripe PaymentMethod id (pm_...) or
            // a Razorpay card token id (token_...) — never the raw card number,
            // which this platform never sees or stores (both gateways tokenize
            // client-side/gateway-side; only their reference ids ever reach us).
            "CREATE TABLE IF NOT EXISTS {$p}saved_payment_methods (
                id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id     BIGINT UNSIGNED NOT NULL,
                gateway       VARCHAR(20)      NOT NULL,
                gateway_ref   VARCHAR(100)     NOT NULL,
                card_brand    VARCHAR(30)      DEFAULT '',
                card_last4    VARCHAR(4)       DEFAULT '',
                is_default    TINYINT(1)       DEFAULT 0,
                created_at    DATETIME         DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_gateway_ref (gateway, gateway_ref),
                KEY idx_vendor (vendor_id)
            ) $c",

            // ── 39. Forms (custom lead capture forms) ─────────────────────────
            // NOTE: AjaxController uses {prefix}gs_forms for saveForm/deleteForm.
            // This table was missing from the schema (CRITICAL BUG FIX #2).
            "CREATE TABLE IF NOT EXISTS {$p}forms (
                id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
                name        VARCHAR(100)    NOT NULL DEFAULT '',
                slug        VARCHAR(100)    NOT NULL DEFAULT '',
                fields      LONGTEXT,
                settings    LONGTEXT,
                is_active   TINYINT(1)               DEFAULT 1,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_active (is_active)
            ) $c",

            // ── 40. Layouts ───────────────────────────────────────────────────
            // NOTE: AjaxController uses {prefix}gs_layouts for saveLayout/deleteLayout/setDefaultLayout.
            // This table was missing from the schema (CRITICAL BUG FIX #2).
            "CREATE TABLE IF NOT EXISTS {$p}layouts (
                id          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
                name        VARCHAR(100)    NOT NULL DEFAULT '',
                description TEXT,
                config      LONGTEXT,
                thumbnail   VARCHAR(500)             DEFAULT '',
                is_default  TINYINT(1)               DEFAULT 0,
                is_active   TINYINT(1)               DEFAULT 1,
                sort_order  INT                      DEFAULT 0,
                created_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP,
                updated_at  DATETIME                 DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_active  (is_active),
                KEY idx_default (is_default)
            ) $c",

            // ── 37. Lead Replies (conversation history per inquiry) ───────────
            "CREATE TABLE IF NOT EXISTS {$p}lead_replies (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                lead_id     BIGINT UNSIGNED NOT NULL,
                sender_type VARCHAR(20)     NOT NULL DEFAULT 'vendor',
                sender_id   BIGINT UNSIGNED          DEFAULT 0,
                sender_name VARCHAR(255)             DEFAULT '',
                message     TEXT            NOT NULL,
                is_internal TINYINT(1)               DEFAULT 0,
                sent_via    VARCHAR(20)              DEFAULT 'email',
                sent_at     DATETIME                 DEFAULT NULL,
                created_at  DATETIME        NOT NULL,
                PRIMARY KEY (id),
                KEY idx_lead_id (lead_id),
                KEY idx_sender  (lead_id, sender_type)
            ) $c",

            // ── Push Subscriptions (PWA) ──────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}push_subscriptions (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id      BIGINT UNSIGNED NOT NULL,
                subscription LONGTEXT NOT NULL,
                device_type  VARCHAR(20) DEFAULT 'desktop',
                created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_user (user_id)
            ) $c",

            // ── Quotations ────────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}quotations (
                id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                lead_id             BIGINT UNSIGNED NOT NULL,
                vendor_id           INT UNSIGNED NOT NULL,
                quote_number        VARCHAR(30) NOT NULL DEFAULT '',
                status              VARCHAR(20) DEFAULT 'draft',
                line_items          LONGTEXT,
                subtotal            DECIMAL(10,2) DEFAULT 0,
                gst_rate            DECIMAL(5,2) DEFAULT 0.00,
                gst_amount          DECIMAL(10,2) DEFAULT 0,
                total               DECIMAL(10,2) DEFAULT 0,
                validity_days       INT DEFAULT 7,
                valid_until         DATE DEFAULT NULL,
                payment_terms       TEXT,
                notes               TEXT,
                cover_note          TEXT,
                quote_accept_token  VARCHAR(64) DEFAULT NULL,
                token_used          TINYINT(1) DEFAULT 0,
                accepted_at         DATETIME DEFAULT NULL,
                rejected_at         DATETIME DEFAULT NULL,
                created_at          DATETIME DEFAULT NULL,
                updated_at          DATETIME DEFAULT NULL,
                PRIMARY KEY (id),
                KEY idx_lead (lead_id),
                KEY idx_vendor_status (vendor_id, status),
                UNIQUE KEY uniq_token (quote_accept_token)
            ) $c",

            // ── Quote Groups (Multi-vendor comparison) ────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}quote_groups (
                id               CHAR(36) NOT NULL,
                client_user_id   BIGINT UNSIGNED NOT NULL,
                service_category VARCHAR(100) NOT NULL DEFAULT '',
                location_id      INT UNSIGNED DEFAULT NULL,
                original_message TEXT NOT NULL,
                status           VARCHAR(20) DEFAULT 'open',
                expires_at       DATETIME DEFAULT NULL,
                created_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_client (client_user_id),
                KEY idx_status (status)
            ) $c",

            // ── Reply Templates ───────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}reply_templates (
                id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id     INT UNSIGNED NOT NULL,
                name          VARCHAR(255) NOT NULL DEFAULT '',
                body          TEXT NOT NULL,
                category_slug VARCHAR(100) DEFAULT '',
                use_count     INT UNSIGNED DEFAULT 0,
                created_at    DATETIME DEFAULT NULL,
                updated_at    DATETIME DEFAULT NULL,
                PRIMARY KEY (id),
                KEY idx_vendor_cat (vendor_id, category_slug)
            ) $c",

            // ── WhatsApp Templates (vendor-authored) ────────────────────────────
            // Real gap fix: this table was referenced by vendor-dashboard.php's
            // WhatsApp Templates section (SELECT/create/update/delete) but never
            // defined anywhere — the UI's own "Run database upgrade... to enable
            // WhatsApp templates" fallback message was the tell. Structured
            // identically to gs_reply_templates above, which serves the same
            // purpose (vendor-authored reusable message text) for a different channel.
            "CREATE TABLE IF NOT EXISTS {$p}whatsapp_templates (
                id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id     INT UNSIGNED NOT NULL,
                name          VARCHAR(255) NOT NULL DEFAULT '',
                body          TEXT NOT NULL,
                category_slug VARCHAR(100) DEFAULT '',
                use_count     INT UNSIGNED DEFAULT 0,
                created_at    DATETIME DEFAULT NULL,
                updated_at    DATETIME DEFAULT NULL,
                PRIMARY KEY (id),
                KEY idx_vendor_cat (vendor_id, category_slug)
            ) $c",

            // ── Availability Schedule ─────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}availability (
                id                    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id             INT UNSIGNED NOT NULL,
                day_of_week           TINYINT NOT NULL COMMENT '0=Sun,1=Mon,...6=Sat',
                start_time            TIME NOT NULL DEFAULT '09:00:00',
                end_time              TIME NOT NULL DEFAULT '18:00:00',
                slot_duration_minutes INT DEFAULT 60,
                buffer_minutes        INT DEFAULT 0,
                is_active             TINYINT(1) DEFAULT 1,
                PRIMARY KEY (id),
                KEY idx_vendor (vendor_id)
            ) $c",

            // ── Blocked Dates ─────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}blocked_dates (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id    INT UNSIGNED NOT NULL,
                blocked_date DATE NOT NULL,
                reason       VARCHAR(255) DEFAULT '',
                PRIMARY KEY (id),
                KEY idx_vendor_date (vendor_id, blocked_date)
            ) $c",

            // ── WhatsApp Logs — see the fuller gs_whatsapp_logs definition
            // earlier in this file (with provider_message_id/delivered_at/
            // read_at for real delivery tracking). A second, simpler,
            // never-actually-used duplicate of this same table used to be
            // here (wa_message_id column, referenced nowhere else in the
            // codebase) — removed rather than left to silently merge
            // columns with the real definition via dbDelta. ─────────────

            // ── Notification Preferences ──────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}notification_preferences (
                user_id    BIGINT UNSIGNED NOT NULL,
                event_type VARCHAR(100) NOT NULL,
                email      TINYINT(1) DEFAULT 1,
                push       TINYINT(1) DEFAULT 1,
                in_app     TINYINT(1) DEFAULT 1,
                PRIMARY KEY (user_id, event_type)
            ) $c",

            // ── AI Usage Tracking ─────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}ai_usage (
                id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id     INT UNSIGNED NOT NULL,
                month         CHAR(7) NOT NULL COMMENT 'YYYY-MM',
                input_tokens  INT UNSIGNED DEFAULT 0,
                output_tokens INT UNSIGNED DEFAULT 0,
                call_count    INT UNSIGNED DEFAULT 0,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_vendor_month (vendor_id, month),
                KEY idx_month (month)
            ) $c",

            // ── SEO Location Pages ────────────────────────────────────────────
            // Confirmed real bug: this definition was missing h1_text and
            // meta_desc — both genuinely written by Cron::
            // generate_seo_location_pages() — and had no UNIQUE KEY at
            // all, meaning $wpdb->replace() would insert a fresh
            // duplicate row every month instead of updating the existing
            // one for a given category+city pair.
            "CREATE TABLE IF NOT EXISTS {$p}seo_location_pages (
                id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                category_slug  VARCHAR(100) NOT NULL,
                city           VARCHAR(100) NOT NULL,
                page_url       VARCHAR(500) NOT NULL,
                vendor_count   SMALLINT DEFAULT 0,
                h1_text        VARCHAR(255) DEFAULT '',
                meta_desc      TEXT,
                last_updated   DATETIME DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_category_city (category_slug, city),
                KEY idx_cat_city (category_slug, city)
            ) $c",



            // ── Diagnosis Sessions (Moat 1) ───────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}diagnosis_sessions (
                id              CHAR(36) NOT NULL,
                user_id         BIGINT UNSIGNED DEFAULT NULL,
                listing_id      BIGINT UNSIGNED DEFAULT NULL,
                category_slug   VARCHAR(100) NOT NULL DEFAULT '',
                initial_message TEXT NOT NULL DEFAULT '',
                messages        LONGTEXT NOT NULL DEFAULT '[]',
                diagnosis       LONGTEXT DEFAULT NULL,
                urgency_level   VARCHAR(20) DEFAULT 'normal',
                diy_suggestion  TEXT DEFAULT NULL,
                converted_to_lead TINYINT(1) DEFAULT 0,
                lead_id         BIGINT UNSIGNED DEFAULT NULL,
                started_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
                completed_at    DATETIME DEFAULT NULL,
                PRIMARY KEY (id),
                KEY idx_user (user_id),
                KEY idx_category (category_slug)
            ) $c",

            // ── Diagnosis Templates (Moat 1) ──────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}diagnosis_templates (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                category_slug   VARCHAR(100) NOT NULL,
                system_prompt   LONGTEXT NOT NULL DEFAULT '',
                opening_question TEXT NOT NULL DEFAULT '',
                max_turns       TINYINT DEFAULT 4,
                is_active       TINYINT(1) DEFAULT 1,
                created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_slug (category_slug)
            ) $c",

            // ── Group Deals (Moat 2) ──────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}group_deals (
                id              CHAR(36) NOT NULL,
                vendor_id       INT UNSIGNED NOT NULL,
                listing_id      BIGINT UNSIGNED NOT NULL,
                title           VARCHAR(255) NOT NULL DEFAULT '',
                description     TEXT DEFAULT '',
                location_id     INT UNSIGNED NOT NULL DEFAULT 0,
                colony_name     VARCHAR(255) DEFAULT '',
                service_date    DATE DEFAULT NULL,
                original_price  DECIMAL(10,2) NOT NULL DEFAULT 0,
                deal_price      DECIMAL(10,2) NOT NULL DEFAULT 0,
                min_bookings    SMALLINT DEFAULT 3,
                max_bookings    SMALLINT DEFAULT 20,
                current_count   SMALLINT DEFAULT 0,
                status          VARCHAR(20) DEFAULT 'forming',
                expires_at      DATETIME NOT NULL,
                activated_at    DATETIME DEFAULT NULL,
                created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_vendor (vendor_id),
                KEY idx_status (status)
            ) $c",

            // ── Group Deal Members (Moat 2) ───────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}group_deal_members (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                deal_id     CHAR(36) NOT NULL,
                user_id     BIGINT UNSIGNED DEFAULT NULL,
                name        VARCHAR(255) NOT NULL DEFAULT '',
                phone       VARCHAR(20) NOT NULL DEFAULT '',
                flat_number VARCHAR(50) DEFAULT '',
                status      VARCHAR(20) DEFAULT 'interested',
                joined_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_deal (deal_id)
            ) $c",

            // ── Flash Slots (Moat 2) ──────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}flash_slots (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id       INT UNSIGNED NOT NULL,
                listing_id      BIGINT UNSIGNED NOT NULL,
                slot_date       DATE NOT NULL,
                slot_time       TIME NOT NULL,
                original_price  DECIMAL(10,2) NOT NULL DEFAULT 0,
                flash_price     DECIMAL(10,2) NOT NULL DEFAULT 0,
                discount_pct    TINYINT DEFAULT 0,
                radius_km       SMALLINT DEFAULT 5,
                location_id     INT UNSIGNED NOT NULL DEFAULT 0,
                status          VARCHAR(20) DEFAULT 'active',
                booked_by_user  BIGINT UNSIGNED DEFAULT NULL,
                booked_at       DATETIME DEFAULT NULL,
                expires_at      DATETIME NOT NULL,
                created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_vendor (vendor_id),
                KEY idx_status (status)
            ) $c",

            // ── Societies (Moat 3) ────────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}societies (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name            VARCHAR(255) NOT NULL DEFAULT '',
                type            VARCHAR(30) DEFAULT 'apartment',
                location_id     INT UNSIGNED NOT NULL DEFAULT 0,
                address         TEXT DEFAULT '',
                total_units     SMALLINT DEFAULT 0,
                pincode         VARCHAR(10) DEFAULT '',
                admin_user_id   BIGINT UNSIGNED NOT NULL,
                access_code     VARCHAR(16) NOT NULL,
                is_verified     TINYINT(1) DEFAULT 0,
                created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_code (access_code)
            ) $c",

            // ── Society Members (Moat 3) ──────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}society_members (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                society_id  BIGINT UNSIGNED NOT NULL,
                user_id     BIGINT UNSIGNED NOT NULL,
                flat_number VARCHAR(50) DEFAULT '',
                role        VARCHAR(20) DEFAULT 'resident',
                joined_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_society_user (society_id, user_id)
            ) $c",

            // ── Society Vendors (Moat 3) ──────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}society_vendors (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                society_id      BIGINT UNSIGNED NOT NULL,
                vendor_id       INT UNSIGNED NOT NULL,
                listing_id      BIGINT UNSIGNED NOT NULL,
                approved_by     BIGINT UNSIGNED NOT NULL,
                tier            VARCHAR(20) DEFAULT 'approved',
                notes           TEXT DEFAULT '',
                negotiated_rate DECIMAL(10,2) DEFAULT NULL,
                approved_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_society_vendor (society_id, listing_id)
            ) $c",

            // ── Society Resident Invites (Part 4, Enterprise-level audit fix) ──────────
            // "No bulk-invite/CSV import of RWA residents — one-at-a-time
            // self-service via access code only." Residents still join the
            // same way they always did (self-service via access code on
            // /rwa/dashboard/ — RwaService::join_society()); this table is
            // purely the RWA admin's outbound-invite + tracking layer on top
            // of that, so a secretary can invite a whole building at once by
            // CSV and see who has actually joined vs is still pending,
            // rather than needing every resident to somehow already know the
            // code exists. status flips from 'pending' to 'joined'
            // automatically the moment the invited email actually joins
            // (matched in join_society() by email, not by any new account-
            // linking mechanism).
            "CREATE TABLE IF NOT EXISTS {$p}society_invites (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                society_id   BIGINT UNSIGNED NOT NULL,
                name         VARCHAR(150) DEFAULT '',
                email        VARCHAR(190) NOT NULL DEFAULT '',
                phone        VARCHAR(20)  DEFAULT '',
                flat_number  VARCHAR(50)  DEFAULT '',
                status       ENUM('pending','joined') DEFAULT 'pending',
                invited_by   BIGINT UNSIGNED NOT NULL,
                invited_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
                joined_at    DATETIME DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_society_email (society_id, email),
                KEY idx_society_status (society_id, status)
            ) $c",

            // ── Webhook Log / Dead-Letter Queue ─────────────────────────────────────
            // FIXED — audit gap "webhook dead-letter queue": every inbound webhook
            // (Razorpay, Stripe, WhatsApp, partner booking-status) was only ever
            // recorded via gs_write_log() to a plain text file — a rejected
            // signature, a processing exception, or a partial DB failure left no
            // queryable, admin-visible record and no way to retry a failed event
            // short of the sender's own webhook retry policy (which most
            // providers eventually give up on). This table is the persisted,
            // queryable record every other write-path in this codebase already
            // gets via gs_activity_log — see RestApiController's webhook methods
            // and the new "Webhooks" admin screen (AjaxController::retryWebhook()).
            "CREATE TABLE IF NOT EXISTS {$p}webhook_log (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                source          VARCHAR(30)     NOT NULL DEFAULT '',
                event_type      VARCHAR(80)     NOT NULL DEFAULT '',
                payload         LONGTEXT,
                status          ENUM('processed','failed','rejected') NOT NULL DEFAULT 'processed',
                error_message   TEXT,
                http_status     SMALLINT UNSIGNED DEFAULT 200,
                attempts        TINYINT UNSIGNED NOT NULL DEFAULT 1,
                created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
                processed_at    DATETIME DEFAULT NULL,
                PRIMARY KEY (id),
                KEY idx_source_status (source, status),
                KEY idx_created (created_at)
            ) $c",

            // ── Home Profiles (Moat 5) ────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}home_profiles (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id         BIGINT UNSIGNED NOT NULL,
                property_name   VARCHAR(255) DEFAULT 'My Home',
                address         TEXT DEFAULT '',
                city            VARCHAR(100) DEFAULT '',
                pincode         VARCHAR(10) DEFAULT '',
                is_primary      TINYINT(1) DEFAULT 0,
                created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_user (user_id)
            ) $c",

            // ── Service Records (Moat 5) ──────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}service_records (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                property_id     BIGINT UNSIGNED NOT NULL,
                booking_id      BIGINT UNSIGNED DEFAULT NULL,
                service_title   VARCHAR(255) NOT NULL DEFAULT '',
                category_slug   VARCHAR(100) DEFAULT '',
                vendor_name     VARCHAR(255) DEFAULT '',
                vendor_phone    VARCHAR(20) DEFAULT '',
                amount_paid     DECIMAL(10,2) DEFAULT 0,
                service_date    DATE NOT NULL,
                warranty_months TINYINT DEFAULT 0,
                warranty_expiry DATE DEFAULT NULL,
                next_service_due DATE DEFAULT NULL,
                notes           TEXT DEFAULT '',
                created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_property (property_id),
                KEY idx_warranty (warranty_expiry)
            ) $c",

            // ── Service Reminders (Moat 5) ────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}service_reminders (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                record_id       BIGINT UNSIGNED NOT NULL,
                property_id     BIGINT UNSIGNED NOT NULL,
                user_id         BIGINT UNSIGNED NOT NULL,
                category        VARCHAR(100) DEFAULT '',
                service_title   VARCHAR(255) DEFAULT '',
                remind_date     DATE NOT NULL,
                reminded        TINYINT(1) DEFAULT 0,
                snoozed_until   DATE DEFAULT NULL,
                created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_user (user_id),
                KEY idx_remind_date (remind_date)
            ) $c",
            // ── Demand Signals (Part 22.3) ────────────────────────────────────────
            // Confirmed real bug found during re-audit: this definition had
            // no UNIQUE KEY at all, meaning $wpdb->replace() in
            // Cron::compute_demand_signals() would insert a fresh
            // duplicate row every month instead of updating the existing
            // one for that category+city+month+year. yoy_change widened
            // from DECIMAL(5,2) — confirmed too small for a realistic
            // worst-case percentage swing (a category growing from 1 to
            // 1000+ leads year over year would overflow it).
            "CREATE TABLE IF NOT EXISTS {$p}demand_signals (
                id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                category      VARCHAR(100) NOT NULL,
                city          VARCHAR(100) NOT NULL,
                month_num     TINYINT NOT NULL,
                year_num      SMALLINT NOT NULL,
                inquiry_count INT UNSIGNED DEFAULT 0,
                yoy_change    DECIMAL(9,2) DEFAULT 0,
                created_at    DATETIME DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_signal (category, city, month_num, year_num),
                KEY idx_cat_city (category, city, month_num)
            ) $c",

            // ── Courses (Moat 6) ──────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}courses (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                title           VARCHAR(255) NOT NULL,
                slug            VARCHAR(100) NOT NULL,
                category_slug   VARCHAR(100) DEFAULT '',
                description     TEXT DEFAULT '',
                thumbnail_url   VARCHAR(500) DEFAULT '',
                modules         LONGTEXT NOT NULL DEFAULT '[]',
                passing_score   TINYINT DEFAULT 70,
                certificate_text TEXT DEFAULT '',
                is_mandatory    TINYINT(1) DEFAULT 0,
                is_active       TINYINT(1) DEFAULT 1,
                created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_slug (slug),
                KEY idx_category (category_slug)
            ) $c",

            // ── Vendor Course Progress (Moat 6) ───────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}vendor_course_progress (
                id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id           INT UNSIGNED NOT NULL,
                course_id           BIGINT UNSIGNED NOT NULL,
                modules_completed   LONGTEXT DEFAULT '[]',
                quiz_attempts       LONGTEXT DEFAULT '[]',
                status              VARCHAR(20) DEFAULT 'not_started',
                final_score         TINYINT DEFAULT NULL,
                started_at          DATETIME DEFAULT NULL,
                completed_at        DATETIME DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_vendor_course (vendor_id, course_id),
                KEY idx_vendor (vendor_id)
            ) $c",

            // ── Vendor Certifications (Moat 6) ────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}vendor_certifications (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id       INT UNSIGNED NOT NULL,
                course_id       BIGINT UNSIGNED NOT NULL,
                category_slug   VARCHAR(100) DEFAULT '',
                cert_level      VARCHAR(20) DEFAULT 'basic',
                issued_at       DATE NOT NULL,
                expires_at      DATE DEFAULT NULL,
                cert_number     VARCHAR(50) NOT NULL,
                is_active       TINYINT(1) DEFAULT 1,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_cert_num (cert_number),
                KEY idx_vendor (vendor_id),
                KEY idx_category (category_slug)
            ) $c",

            // ── Market Benchmarks (Moat 7) ────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}market_benchmarks (
                id                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                category_slug           VARCHAR(100) NOT NULL,
                city                    VARCHAR(100) NOT NULL DEFAULT '',
                month                   CHAR(7) NOT NULL,
                avg_response_time_min   SMALLINT DEFAULT NULL,
                avg_quote_amount        DECIMAL(10,2) DEFAULT NULL,
                avg_conversion_rate     DECIMAL(5,2) DEFAULT NULL,
                top_quartile_leads      SMALLINT DEFAULT NULL,
                demand_index            TINYINT DEFAULT 50,
                computed_at             DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uniq_cat_city_month (category_slug, city, month)
            ) $c",

            // ── Vendor Ranking History (Moat 7) ───────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}vendor_ranking_history (
                id                    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id             INT UNSIGNED NOT NULL,
                category_slug         VARCHAR(100) NOT NULL,
                city                  VARCHAR(100) NOT NULL DEFAULT '',
                month                 CHAR(7) NOT NULL,
                rank_position         SMALLINT DEFAULT NULL,
                total_in_category     SMALLINT DEFAULT NULL,
                leads_received        SMALLINT DEFAULT 0,
                leads_won             SMALLINT DEFAULT 0,
                avg_response_time_min SMALLINT DEFAULT NULL,
                PRIMARY KEY (id),
                KEY idx_vendor_month (vendor_id, month)
            ) $c",
            // ── Content Flags (moderation) ────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}content_flags (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                content_type VARCHAR(30) NOT NULL,
                content_id   BIGINT UNSIGNED NOT NULL,
                flagged_by   BIGINT UNSIGNED NOT NULL,
                reason       VARCHAR(255) DEFAULT '',
                status       VARCHAR(20) DEFAULT 'pending',
                created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_status (status)
            ) $c",

            // ── gs_service_plans ─────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}service_plans (
                id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                vendor_id        INT UNSIGNED NOT NULL,
                listing_id       BIGINT UNSIGNED NOT NULL DEFAULT 0,
                name             VARCHAR(255) NOT NULL DEFAULT '',
                description      TEXT,
                category_slug    VARCHAR(100) NOT NULL DEFAULT '',
                frequency        ENUM('weekly','monthly','quarterly','biannual','annual') NOT NULL DEFAULT 'monthly',
                price            DECIMAL(10,2) NOT NULL DEFAULT 0,
                visits_included  INT DEFAULT 1,
                is_active        TINYINT(1) DEFAULT 1,
                created_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_vendor (vendor_id),
                KEY idx_listing (listing_id)
            ) $c",

            // ── gs_service_subscriptions ─────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}service_subscriptions (
                id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                plan_id          BIGINT UNSIGNED NOT NULL,
                client_user_id   BIGINT UNSIGNED NOT NULL,
                vendor_id        INT UNSIGNED NOT NULL,
                status           ENUM('active','paused','cancelled','expired') DEFAULT 'active',
                next_service_date DATE NOT NULL,
                started_at       DATETIME DEFAULT NULL,
                cancelled_at     DATETIME DEFAULT NULL,
                PRIMARY KEY (id),
                KEY idx_client (client_user_id),
                KEY idx_next_date (next_service_date, status),
                KEY idx_plan (plan_id)
            ) $c",

            // gs_listing_cities — normalised city table for fast city filtering.
            // Replaces LIKE '%city%' on service_cities LONGTEXT with an indexed JOIN.
            // Populated on listing save via sync_listing_cities(). Backfilled on upgrade.
            "CREATE TABLE IF NOT EXISTS {$p}listing_cities (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id  BIGINT UNSIGNED NOT NULL,
                city        VARCHAR(120)    NOT NULL DEFAULT '',
                PRIMARY KEY (id),
                UNIQUE KEY uq_listing_city (listing_id, city),
                KEY idx_city (city)
            ) $c",

            // ── Regional Account Manager system ──────────────────────────────
            // manager_cities — which cities each regional manager may create
            // new listings in. A manager can have multiple cities.
            "CREATE TABLE IF NOT EXISTS {$p}manager_cities (
                id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                manager_id  BIGINT UNSIGNED NOT NULL,
                city        VARCHAR(120)    NOT NULL DEFAULT '',
                PRIMARY KEY (id),
                UNIQUE KEY uq_manager_city (manager_id, city),
                KEY idx_manager (manager_id),
                KEY idx_city (city)
            ) $c",

            // listing_manager_assignments — the actual, enforced assignment
            // Roles::can_edit_listing() checks against. One listing has at
            // most one manager at a time (UNIQUE on listing_id) — matches
            // the stated assignment rule exactly. Reassigning simply
            // replaces the row; the previous manager loses access
            // immediately since the query no longer matches them.
            "CREATE TABLE IF NOT EXISTS {$p}listing_manager_assignments (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id   BIGINT UNSIGNED NOT NULL,
                manager_id   BIGINT UNSIGNED NOT NULL,
                assigned_by  BIGINT UNSIGNED NOT NULL DEFAULT 0,
                assigned_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_listing (listing_id),
                KEY idx_manager (manager_id)
            ) $c",

            // manager_activity_log — the audit trail the admin dashboard
            // requires: every create/edit a regional manager makes, with
            // who, what, and when, independent of the general system log.
            "CREATE TABLE IF NOT EXISTS {$p}manager_activity_log (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                manager_id   BIGINT UNSIGNED NOT NULL,
                listing_id   BIGINT UNSIGNED NOT NULL DEFAULT 0,
                action       VARCHAR(60)     NOT NULL DEFAULT '',
                details      TEXT,
                created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_manager (manager_id),
                KEY idx_listing (listing_id),
                KEY idx_created (created_at)
            ) $c",

            // manager_notifications — real admin-to-manager notifications, a
            // distinct inbox from the audit trail above, matching the
            // "Notifications from Admin" dashboard requirement explicitly.
            "CREATE TABLE IF NOT EXISTS {$p}manager_notifications (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                manager_id   BIGINT UNSIGNED NOT NULL,
                message      TEXT            NOT NULL,
                sent_by      BIGINT UNSIGNED NOT NULL DEFAULT 0,
                is_read      TINYINT(1)      NOT NULL DEFAULT 0,
                created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_manager (manager_id, is_read)
            ) $c",
            // gs_redirects — the audit-flagged "custom redirect management"
            // gap: a real, admin-manageable redirect map from old/arbitrary
            // source paths to destination URLs, independent of the
            // automatic slug-change 301s already handled elsewhere.
            "CREATE TABLE IF NOT EXISTS {$p}redirects (
                id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                source_path   VARCHAR(500)    NOT NULL DEFAULT '',
                dest_url      VARCHAR(500)    NOT NULL DEFAULT '',
                status_code   SMALLINT UNSIGNED NOT NULL DEFAULT 301,
                is_active     TINYINT(1)      NOT NULL DEFAULT 1,
                hit_count     INT UNSIGNED    NOT NULL DEFAULT 0,
                created_by    BIGINT UNSIGNED NOT NULL DEFAULT 0,
                created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
                last_hit_at   DATETIME        DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_source (source_path),
                KEY idx_active (is_active)
            ) $c",
            // hardcoded InquiryCategoryData::_registry() array) ──────────────
            // One row per category (was one array entry, e.g. 'hotel-booking').
            // InquiryFormService reads from this table; if a category has no
            // row here, InquiryCategoryData's hardcoded definition is used as
            // the fallback — this is the backward-compatibility seam that lets
            // every existing form keep working unmodified while categories are
            // migrated into the database one at a time (see migrate_legacy_data()).
            "CREATE TABLE IF NOT EXISTS {$p}form_categories (
                id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                slug         VARCHAR(60)     NOT NULL,
                category_group VARCHAR(80)   DEFAULT '',
                name         VARCHAR(150)    DEFAULT '',
                icon         VARCHAR(20)     DEFAULT '',
                ctas         TEXT,
                is_active    TINYINT(1)      DEFAULT 1,
                is_legacy    TINYINT(1)      DEFAULT 0,
                sort_order   INT             DEFAULT 0,
                created_by   BIGINT UNSIGNED DEFAULT 0,
                created_at   DATETIME        DEFAULT CURRENT_TIMESTAMP,
                updated_at   DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_slug (slug),
                KEY idx_group (category_group)
            ) $c",

            // ── 42. Inquiry Form Fields ────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS {$p}form_fields (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                category_id     BIGINT UNSIGNED NOT NULL,
                field_key       VARCHAR(80)     NOT NULL,
                label           VARCHAR(255)    DEFAULT '',
                field_type      VARCHAR(20)     DEFAULT 'text',
                is_required     TINYINT(1)      DEFAULT 0,
                step            TINYINT UNSIGNED DEFAULT 1,
                placeholder     VARCHAR(255)    DEFAULT '',
                help_text       VARCHAR(255)    DEFAULT '',
                options_json    TEXT,
                min_value       INT             DEFAULT NULL,
                max_value       INT             DEFAULT NULL,
                show_others     TINYINT(1)      DEFAULT 0,
                cond_field_key  VARCHAR(80)     DEFAULT '',
                cond_op         VARCHAR(20)     DEFAULT 'equals',
                cond_value      VARCHAR(500)    DEFAULT '',
                sort_order      INT             DEFAULT 0,
                is_active       TINYINT(1)      DEFAULT 1,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_category (category_id),
                KEY idx_sort (category_id, step, sort_order)
            ) $c",

            // ── 42b. Per-Category Universal Field Overrides ────────────────────
            // Absence of a row for (category_id, field_key) = enabled, label
            // shown — identical to today's hardcoded global behavior. A row
            // only needs to exist when a form diverges from that default,
            // which is what makes this backward-compatible by construction
            // rather than by migration: every existing form has zero rows
            // here today and therefore behaves exactly as it does now.
            "CREATE TABLE IF NOT EXISTS {$p}form_universal_overrides (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                category_id     BIGINT UNSIGNED NOT NULL,
                field_key       VARCHAR(80)     NOT NULL,
                is_enabled      TINYINT(1)      DEFAULT 1,
                show_label      TINYINT(1)      DEFAULT 1,
                label_override  VARCHAR(255)    DEFAULT '',
                sort_order      INT             DEFAULT NULL,
                updated_at      DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_cat_field (category_id, field_key)
            ) $c",

            // ── 42c. Default Step Categories Registry ───────────────────────────
            // The actual source of truth for "which default steps exist" —
            // Scheduling and Contact are rows here, not hardcoded strings in
            // the renderer. A future default step (e.g. "Payment") is added
            // by inserting a row, not by editing inquiry-modules.php. Every
            // universal field's 'group' value must match a step_key here.
            "CREATE TABLE IF NOT EXISTS {$p}form_step_categories (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                step_key        VARCHAR(60)     NOT NULL,
                label           VARCHAR(100)    NOT NULL,
                sort_order      INT             DEFAULT 0,
                is_active       TINYINT(1)      DEFAULT 1,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_step_key (step_key)
            ) $c",

            // ── 43. Inquiry Form Field Versions (history + rollback) ───────────
            // One row per save of a category's field set — NOT one row per
            // field. A "version" is the complete field-set state at that
            // point, stored as JSON; rolling back replaces the current
            // gs_form_fields rows for that category with the snapshot's rows
            // in one atomic operation, rather than trying to undo individual
            // field-level diffs (which gets ambiguous fast — e.g. if a field
            // was added AND another was deleted in the same save).
            "CREATE TABLE IF NOT EXISTS {$p}form_field_versions (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                category_id     BIGINT UNSIGNED NOT NULL,
                snapshot_json   LONGTEXT        NOT NULL,
                field_count     SMALLINT UNSIGNED DEFAULT 0,
                change_summary  VARCHAR(255)    DEFAULT '',
                created_by      BIGINT UNSIGNED DEFAULT 0,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_category (category_id, created_at)
            ) $c",

            // ── Swiper / Image Slider — Slides ──────────────────────────────────
            // Real, dedicated, independent table for the new Swiper section's
            // slides — confirmed deliberately separate from any hero-related
            // table or column, exactly matching the explicit requirement that
            // this section be completely independent. Each slide stores its
            // own desktop and mobile image separately (real, distinct
            // requirement), optional title/subtitle/description text, and an
            // optional button (text + URL) — all genuinely optional per slide,
            // supporting the "image only" requirement when every text field is
            // left blank. sort_order is the real, dedicated column enabling
            // reordering via a simple UPDATE, the same proven pattern already
            // used elsewhere in this schema for ordered, per-listing content.
            "CREATE TABLE IF NOT EXISTS {$p}swiper_slides (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id      BIGINT UNSIGNED NOT NULL,
                image_desktop   VARCHAR(500)    NOT NULL,
                image_mobile    VARCHAR(500)    DEFAULT '',
                device          ENUM('all','desktop','mobile') DEFAULT 'all',
                img_fit_desktop VARCHAR(20)     DEFAULT 'cover',
                img_fit_mobile  VARCHAR(20)     DEFAULT 'cover',
                img_position_desktop VARCHAR(20) DEFAULT 'center',
                img_position_mobile  VARCHAR(20) DEFAULT 'center',
                img_zoom_desktop INT UNSIGNED   DEFAULT 100,
                img_zoom_mobile  INT UNSIGNED   DEFAULT 100,
                height_override_desktop INT UNSIGNED DEFAULT 0,
                height_override_mobile  INT UNSIGNED DEFAULT 0,
                title           VARCHAR(255)    DEFAULT '',
                subtitle        VARCHAR(255)    DEFAULT '',
                description     TEXT            DEFAULT NULL,
                button_text     VARCHAR(100)    DEFAULT '',
                button_url      VARCHAR(500)    DEFAULT '',
                sort_order      INT UNSIGNED    DEFAULT 0,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_listing_sort (listing_id, sort_order)
            ) $c",

            // ── Module Architecture: Phase 0 (Roadmap) ──────────────────────
            // gs_listing_modules — the assignment record: does this listing
            // use this module at all. An unassigned module has NO ROW here,
            // not a disabled flag — this is what makes "zero query cost for
            // unassigned modules" literally true, not just small. is_enabled
            // exists separately from row-presence to support the roadmap's
            // "soft-disable on uncheck" decision (Section 6 of the roadmap
            // doc): a vendor unchecking a module preserves its data row and
            // just flips is_enabled=0, rather than deleting the assignment
            // outright — recoverable if they re-check it later.
            "CREATE TABLE IF NOT EXISTS {$p}listing_modules (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id      BIGINT UNSIGNED NOT NULL,
                module_key      VARCHAR(64)     NOT NULL,
                is_enabled      TINYINT(1)      NOT NULL DEFAULT 1,
                sort_order      INT UNSIGNED    DEFAULT 0,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_listing_module (listing_id, module_key),
                KEY idx_listing (listing_id),
                KEY idx_module (module_key)
            ) $c",

            // gs_module_config — the persistent, admin-editable layer over
            // ModuleRegistry's code-registered defaults. A module (whether
            // hand-built 'custom' PHP or a no-code 'schema' section built
            // entirely from the admin) gets ONE row here the first time an
            // admin touches its settings. Everything an admin can change
            // without code — display label, icon, which categories it's
            // available for, active/inactive, sort order — lives here, not
            // in a PHP array a developer has to edit. ModuleRegistry reads
            // this table on boot and merges it OVER whatever a module's own
            // register() call provided, so a code-registered module's
            // hardcoded defaults become just that — defaults, not the only
            // way to configure it. A 'schema' module (defined entirely
            // through the admin builder, never touched by a developer) has
            // its base config here too; there is no separate, second
            // config mechanism for schema-type modules.
            "CREATE TABLE IF NOT EXISTS {$p}module_config (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                module_key      VARCHAR(64)     NOT NULL,
                label           VARCHAR(191)    DEFAULT NULL,
                icon            VARCHAR(16)     DEFAULT NULL,
                type            VARCHAR(16)     NOT NULL DEFAULT 'schema',
                categories_json TEXT            DEFAULT NULL,
                default_enabled TINYINT(1)      NOT NULL DEFAULT 0,
                is_active       TINYINT(1)      NOT NULL DEFAULT 1,
                sort_order      INT UNSIGNED    DEFAULT 0,
                source          VARCHAR(16)     NOT NULL DEFAULT 'admin',
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_module_key (module_key),
                KEY idx_active (is_active)
            ) $c",

            // gs_module_config_fields — the field DEFINITIONS for a
            // 'schema'-type module built through the no-code admin
            // builder: one row per field (text, textarea, repeater,
            // number, image, checkbox, select...). A 'custom'-type module
            // (the 25 hand-built sections that already existed before this
            // table was introduced) has no rows here at all — its fields
            // are whatever its own PHP render/admin code already defines,
            // which stays exactly as-is; this table only governs sections
            // an admin actually builds from the section builder screen.
            "CREATE TABLE IF NOT EXISTS {$p}module_config_fields (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                module_key      VARCHAR(64)     NOT NULL,
                field_key       VARCHAR(64)     NOT NULL,
                field_label     VARCHAR(191)    NOT NULL,
                field_type      VARCHAR(24)     NOT NULL DEFAULT 'text',
                is_repeater_item TINYINT(1)     NOT NULL DEFAULT 0,
                options_json    TEXT            DEFAULT NULL,
                sort_order      INT UNSIGNED    DEFAULT 0,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_module_field (module_key, field_key),
                KEY idx_module (module_key)
            ) $c",

            // gs_listing_module_data — per-module data, one row per
            // (listing, module) pair that has actually been filled in.
            // Deliberately separate from the assignment table above:
            // assignment answers "is this module active," this table
            // answers "what did the vendor type into it" — keeping them
            // separate means re-enabling a soft-disabled module restores
            // its data with zero extra work, since the data row was never
            // touched by the disable action.
            "CREATE TABLE IF NOT EXISTS {$p}listing_module_data (
                id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                listing_id      BIGINT UNSIGNED NOT NULL,
                module_key      VARCHAR(64)     NOT NULL,
                data_json       LONGTEXT,
                created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_listing_module (listing_id, module_key),
                KEY idx_listing (listing_id)
            ) $c",

        ];
    }

    /**
     * Add composite indexes optimised for 50 K+ listings.
     * Every index is checked for existence before attempting ALTER TABLE,
     * so this method is safe to run repeatedly with zero side-effects.
     *
     * Why composite indexes matter at scale:
     *  • "status, is_featured, avg_rating" covers the default browse sort
     *    (WHERE status='active' ORDER BY is_featured DESC, avg_rating DESC)
     *    without a filesort.
     *  • "vendor_id, created_at" on analytics makes vendor dashboard queries
     *    10-50× faster than scanning the full analytics table.
     *  • "status, category_id" and "status, city" let MySQL use index range
     *    scans for category/city browse without touching the fulltext index.
     */
    /**
     * Migrate ENUM columns that gained new values in version upgrades.
     * Safely ALTER TABLE MODIFY — MySQL preserves all existing data when adding
     * new ENUM values to the end. Runs a SHOW COLUMNS check first to avoid
     * redundant ALTER operations on each page load.
     */
    private static function migrate_enum_columns( string $p ): void {
        global $wpdb;

        // [ table, column, full new ENUM definition ]
        $enums = [
            [
                "{$p}listings",
                'status',
                "ENUM('draft','pending','active','suspended','expired','rejected','deleted') NOT NULL DEFAULT 'draft'",
            ],
            // GS Enhancements v1.0 — CRM stage alignment: add quotation_sent, follow_up, won, lost
            [
                "{$p}leads",
                'status',
                "ENUM('new','seen','contacted','qualified','converted','junk','quotation_sent','follow_up','won','lost') DEFAULT 'new'",
            ],
            // GS Enhancements v1.0 — Review token gate: add token_pending status
            [
                "{$p}reviews",
                'status',
                "ENUM('pending','approved','rejected','token_pending') DEFAULT 'pending'",
            ],
            // Manual Subscription & Offline Payment system — widen plan_requests.status
            // from the original ('pending','approved','rejected') to the full lifecycle.
            [
                "{$p}plan_requests",
                'status',
                "ENUM('draft','pending','under_review','payment_verification_pending','info_required','on_hold','approved','rejected','expired','cancelled','completed') DEFAULT 'pending'",
            ],
            // Real feature — wallet credit as a dispute resolution option,
            // widening the resolution ENUM created earlier this same
            // engagement. dbDelta doesn't alter existing ENUM columns on
            // repeat runs, so this migration entry is what actually
            // applies the change for any install where the disputes
            // table was already created before this addition.
            [
                "{$p}disputes",
                'resolution',
                "ENUM('full_refund','partial_refund','no_refund','mediation','wallet_credit') DEFAULT NULL",
            ],
            // Real feature — Specifications/Features repeater section type,
            // widening the content_type ENUM created earlier. Existing
            // installs already have this table (created before this
            // addition), so the base CREATE TABLE IF NOT EXISTS definition
            // alone would never reach them — this migration entry is what
            // actually applies the change there, same as every entry above.
            [
                "{$p}section_templates",
                'content_type',
                "ENUM('richtext','list','numbered_list','faq','table','gallery','cards','accordion','highlight','specs') DEFAULT 'richtext'",
            ],
        ];

        foreach ( $enums as [ $table, $column, $definition ] ) {
            if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) ) { continue; }

            // Read current ENUM definition
            $col_info = $wpdb->get_row( $wpdb->prepare(
                "SELECT COLUMN_TYPE FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s",
                $table, $column
            ) );

            // Idempotency: skip if the LAST value we're adding is already present.
            // Each ENUM definition ends with the newest value — if it's present the migration ran.
            // Listings check: 'deleted'. Leads check: 'lost'. Reviews check: 'token_pending'.
            preg_match( "/ENUM\\((.+?)\\)/i", $definition, $dm );
            $enum_values  = $dm[1] ?? '';
            // Extract last quoted value from the ENUM definition as the sentinel
            preg_match_all( "/'([^']+)'/", $enum_values, $vm );
            $sentinel = end( $vm[1] ) ?: 'deleted';
            if ( $col_info && str_contains( strtolower( $col_info->COLUMN_TYPE ), "'{$sentinel}'" ) ) {
                continue;
            }

            // Suppress errors — non-fatal; dbDelta will handle next upgrade
            $prev = $wpdb->suppress_errors( true );
            $wpdb->query( "ALTER TABLE `{$table}` MODIFY `{$column}` {$definition}" ); // phpcs:ignore
            $wpdb->suppress_errors( $prev );

            if ( function_exists( 'gs_write_log' ) ) {
                gs_write_log( "migrate_enum_columns: updated {$table}.{$column} ENUM to include '{$sentinel}'", 'INFO' );
            }
        }
    }

    private static function add_performance_indexes( string $p ): void {
        global $wpdb;

        // [ table, index_name, columns ]
        $indexes = [
            // Listings — main browse + search sort combinations
            // RENAMED (not just edited) from idx_perf_status_featured_rating
            // to idx_perf_status_featured_rating_views — the upgrade loop
            // below only checks whether an index with this EXACT NAME
            // already exists; it has no way to detect that an existing
            // index's column list changed. A live install that already ran
            // this upgrade once would have the old 3-column index already
            // present under the old name, and editing the column list here
            // alone would never actually apply — the loop would see the old
            // name already exists and skip forever. The old, now-redundant
            // 3-column index is left in place (harmless, just no longer
            // the one actually used by the optimizer for this query) rather
            // than risk a DROP INDEX on a column set something else might
            // still depend on.
            [ "{$p}listings",      'idx_perf_status_featured_rating_views', 'status, is_featured, avg_rating, views_count' ],
            [ "{$p}listings",      'idx_perf_status_ranking_score',    'status, ranking_score' ],
            [ "{$p}listings",      'idx_perf_status_category',         'status, category_id' ],
            [ "{$p}listings",      'idx_perf_status_subcategory',      'status, subcategory_id' ],
            [ "{$p}listings",      'idx_perf_status_city',             'status, city' ],
            // FIX 4: Covering indexes for category+sort and city+sort — avoids filesort at 50L+ rows.
            // category browse: WHERE status='active' AND category_id=X ORDER BY is_featured DESC, avg_rating DESC
            [ "{$p}listings",      'idx_perf_cat_featured_rating',     'status, category_id, is_featured, avg_rating' ],
            // city browse: WHERE status='active' AND city=X ORDER BY is_featured DESC, avg_rating DESC
            [ "{$p}listings",      'idx_perf_city_featured_rating',    'status, city, is_featured, avg_rating' ],
            [ "{$p}listings",      'idx_perf_status_created',          'status, created_at' ],
            [ "{$p}listings",      'idx_perf_status_views',            'status, views_count' ],
            [ "{$p}listings",      'idx_perf_vendor_status',           'vendor_id, status' ],
            // Analytics — vendor dashboard & platform stats queries
            [ "{$p}analytics",     'idx_perf_vendor_event_created',    'vendor_id, event_type, created_at' ],
            [ "{$p}analytics",     'idx_perf_listing_event_created',   'listing_id, event_type, created_at' ],
            // Leads — vendor lead management with date range filters
            [ "{$p}leads",         'idx_perf_vendor_status_created',   'vendor_id, status, created_at' ],
            // Reviews — listing review page + moderation queue
            [ "{$p}reviews",       'idx_perf_listing_status_created',  'listing_id, status, created_at' ],
            // Notifications — vendor notification panel (unread first, then date)
            [ "{$p}notifications", 'idx_perf_user_read_created',       'user_id, is_read, created_at' ],
            // Job queue — processor query (pending jobs ordered by run_after)
            [ "{$p}job_queue",     'idx_perf_status_run_after',        'status, run_after' ],
            // Subscriptions — expiry check + vendor lookup
            [ "{$p}subscriptions", 'idx_perf_status_expires',          'status, expires_at' ],
            [ "{$p}subscriptions", 'idx_perf_vendor_status',           'vendor_id, status' ],
            // Availability/blocked dates — now listing-scoped (see upgrade_columns)
            [ "{$p}availability",  'idx_perf_listing_dow',             'listing_id, day_of_week' ],
            [ "{$p}blocked_dates", 'idx_perf_listing_date',            'listing_id, blocked_date' ],
            // Phase 3 cron index — covers reminder sweep + auto-expire sweep
            [ "{$p}bookings",      'idx_perf_booking_cron',            'status, booking_date, reminder_24h_sent' ],
            // FIX (enterprise hardening pass): staff-attribution lookups — Staff
            // Performance dashboard now scopes bookings/reviews by assigned_staff_id
            // via correlated subqueries instead of a fan-out JOIN; these indexes keep
            // that scoped per-staff aggregation fast as booking/review volume grows.
            [ "{$p}bookings",      'idx_perf_staff_assigned',          'assigned_staff_id, status' ],
            [ "{$p}reviews",       'idx_perf_staff_assigned',          'assigned_staff_id, status' ],
        ];

        foreach ( $indexes as [ $table, $name, $cols ] ) {
            // Skip if table does not exist yet
            if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) ) {
                continue;
            }
            // Skip if index already exists
            $exists = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*)
                 FROM information_schema.STATISTICS
                 WHERE table_schema = DATABASE()
                   AND table_name   = %s
                   AND index_name   = %s",
                $table, $name
            ) );
            if ( $exists ) {
                continue;
            }
            // Suppress errors — a rare failure (e.g. index on TEXT column without
            // prefix length) must not abort the whole install.
            $prev = $wpdb->suppress_errors( true );
            $wpdb->query( "ALTER TABLE `{$table}` ADD INDEX `{$name}` ({$cols})" );
            $wpdb->suppress_errors( $prev );
        }
    }

}
