<?php
namespace GoodService\Controller;

class VisitorController extends BaseController {

    public function dashboard(): void {
        if ( ! is_user_logged_in() ) {
            $this->redirect( home_url( '/vendor/login/' ) );
        }
        $this->view( 'other-dashboards', [ 'dash_type' => 'visitor' ] );
    }
}
