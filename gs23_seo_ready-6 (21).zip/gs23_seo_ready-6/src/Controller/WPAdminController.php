<?php
namespace GoodService\Controller;

use GoodService\Core\Config;

class WPAdminController {

    public static function register(): void {
        add_action( 'admin_menu', [ self::class, 'register_menu' ] );
        add_action( 'admin_bar_menu', [ self::class, 'admin_bar_links' ], 100 );
    }

    public static function register_menu(): void {
        add_menu_page(
            'GoodService Platform',
            'GoodService',
            'manage_options',
            'goodservice',
            [ self::class, 'render_dashboard_link' ],
            'dashicons-store',
            3
        );
        add_submenu_page( 'goodservice', 'Dashboard',    'Dashboard',    'manage_options', 'goodservice',            [ self::class, 'render_dashboard_link' ] );
        add_submenu_page( 'goodservice', 'Add Vendor',   'Add Vendor',   'manage_options', 'goodservice-add-vendor', [ self::class, 'render_add_vendor' ] );
        add_submenu_page( 'goodservice', 'Add Listing',  'Add Listing',  'manage_options', 'goodservice-add-listing',[ self::class, 'render_add_listing' ] );
        add_submenu_page( 'goodservice', 'View Directory','Directory',   'manage_options', 'goodservice-directory',  [ self::class, 'render_directory' ] );
        add_submenu_page( 'goodservice', 'Settings',     'Settings',     'manage_options', 'goodservice-settings',   [ self::class, 'render_settings' ] );
        add_submenu_page( 'goodservice', 'Flush Rewrites','Flush Routes',  'manage_options', 'goodservice-flush',      [ self::class, 'flush_rewrites'    ] );
        add_submenu_page( 'goodservice', 'DB Upgrade',   'DB Upgrade',   'manage_options', 'goodservice-db-upgrade', [ self::class, 'force_db_upgrade' ] );
    }
    // NOTE: the Typography/Footer-Link-Color diagnostic lives in the
    // platform's own custom admin panel (templates/pages/admin-dashboard.php,
    // case 'typo_diag' — nav: System → 🎨 Typography Diag), matching every
    // other diagnostic tool on this platform (e.g. Inquiry Diag), not here.
    // A wp-admin submenu was tried first and reverted: this platform's
    // actual admin UI is the custom-routed dashboard at /admin-panel/, not
    // wp-admin — nobody using this platform day-to-day ever opens wp-admin.

    public static function admin_bar_links( \WP_Admin_Bar $bar ): void {
        $bar->add_menu( [
            'id'    => 'gs-platform',
            'title' => '🏪 GoodService',
            'href'  => home_url( '/admin-panel/' ),
        ] );
        $bar->add_menu( [
            'id'     => 'gs-admin',
            'parent' => 'gs-platform',
            'title'  => '📊 Admin Dashboard',
            'href'   => home_url( '/admin-panel/' ),
            'meta'   => [ 'target' => '_blank' ],
        ] );
        $bar->add_menu( [
            'id'     => 'gs-add-vendor',
            'parent' => 'gs-platform',
            'title'  => '➕ Add Vendor',
            'href'   => home_url( '/admin-panel/?section=vendors&add=1' ),
            'meta'   => [ 'target' => '_blank' ],
        ] );
        $bar->add_menu( [
            'id'     => 'gs-add-listing',
            'parent' => 'gs-platform',
            'title'  => '➕ Add Listing',
            'href'   => home_url( '/admin-panel/?section=listings&add=1' ),
            'meta'   => [ 'target' => '_blank' ],
        ] );
        $bar->add_menu( [
            'id'     => 'gs-directory',
            'parent' => 'gs-platform',
            'title'  => '🔍 Directory',
            'href'   => home_url( '/directory/' ),
            'meta'   => [ 'target' => '_blank' ],
        ] );
    }

    public static function render_dashboard_link(): void {
        $admin_url    = home_url( '/admin-panel/' );
        $vendor_url   = home_url( '/admin-panel/?section=vendors&add=1' );
        $listing_url  = home_url( '/admin-panel/?section=listings&add=1' );
        $dir_url      = home_url( '/directory/' );
        $flush_url    = admin_url( 'admin.php?page=goodservice-flush' );

        // Check if the rewrite rules are registered (admin-panel route exists)
        $rules = get_option( 'rewrite_rules', [] );
        $has_route = false;
        foreach ( (array) $rules as $pattern => $target ) {
            if ( str_contains( $target, 'gs_page' ) ) { $has_route = true; break; }
        }

        echo '<div class="wrap">';
        echo '<h1 style="display:flex;align-items:center;gap:10px">🏪 GoodService Platform <span style="font-size:.7rem;background:#EFF6FF;color:#2563EB;padding:3px 10px;border-radius:20px;font-weight:600">v' . esc_html( GS_VERSION ) . '</span></h1>';

        if ( ! $has_route ) {
            echo '<div class="notice notice-warning inline" style="margin:12px 0"><p>⚠️ <strong>Rewrite rules not active.</strong> ';
            echo 'Click <a href="' . esc_url( $flush_url ) . '" class="button button-small">Flush Routes</a> to activate all URLs. ';
            echo 'Then the dashboard link below will work.</p></div>';
        }

        echo '<div style="display:flex;flex-wrap:wrap;gap:10px;margin:16px 0">';
        echo '<a href="' . esc_url( $admin_url ) . '" class="button button-primary button-large" target="_blank" style="font-size:15px;height:auto;padding:10px 20px">🚀 Open Admin Dashboard</a>';
        echo '<a href="' . esc_url( $vendor_url ) . '" class="button button-large" target="_blank">➕ Add Vendor</a>';
        echo '<a href="' . esc_url( $listing_url ) . '" class="button button-large" target="_blank">📋 Add Listing</a>';
        echo '<a href="' . esc_url( $dir_url ) . '" class="button button-large" target="_blank">🔍 Directory</a>';
        echo '<a href="' . esc_url( $flush_url ) . '" class="button">🔄 Flush Routes</a>';
        echo '</div>';

        echo '<table class="widefat" style="max-width:640px"><thead><tr><th>Page</th><th>URL</th><th></th></tr></thead><tbody>';
        $links = [
            [ '🏪 Admin Dashboard',   $admin_url ],
            [ '👤 Add Vendor',         $vendor_url ],
            [ '📋 Add Listing',        $listing_url ],
            [ '🔍 Directory',          $dir_url ],
            [ '🔑 Vendor Login',       home_url('/vendor/login/') ],
            [ '📝 Vendor Register',    home_url('/vendor/register/') ],
            [ '📋 Manager Login',      home_url('/manager/login/') ],
            [ '🛡️ Staff Login',        home_url('/staff/login/') ],
            [ '🔒 Forgot Password',    home_url('/forgot-password/') ],
            [ '🏢 Manager Panel',      home_url('/manager-panel/') ],
            [ '🛡️ Moderation',         home_url('/moderation/') ],
        ];
        foreach ( $links as [$label, $url] ) {
            echo '<tr><td>' . esc_html($label) . '</td>';
            echo '<td><code style="font-size:.8rem">' . esc_html($url) . '</code></td>';
            echo '<td><a href="' . esc_url($url) . '" target="_blank" class="button button-small">Open →</a></td></tr>';
        }
        echo '</tbody></table>';
        echo '</div>';
    }

    public static function render_add_vendor(): void {
        echo '<script>window.open("' . esc_url( home_url( '/admin-panel/?section=vendors&add=1' ) ) . '","_blank");window.history.back();</script>';
        echo '<div class="wrap"><p><a href="' . esc_url( home_url( '/admin-panel/?section=vendors&add=1' ) ) . '" target="_blank" class="button button-primary">Open Add Vendor →</a></p></div>';
    }

    public static function render_add_listing(): void {
        echo '<script>window.open("' . esc_url( home_url( '/admin-panel/?section=listings&add=1' ) ) . '","_blank");window.history.back();</script>';
        echo '<div class="wrap"><p><a href="' . esc_url( home_url( '/admin-panel/?section=listings&add=1' ) ) . '" target="_blank" class="button button-primary">Open Add Listing →</a></p></div>';
    }

    public static function render_directory(): void {
        echo '<script>window.open("' . esc_url( home_url( '/directory/' ) ) . '","_blank");window.history.back();</script>';
        echo '<div class="wrap"><p><a href="' . esc_url( home_url( '/directory/' ) ) . '" target="_blank" class="button button-primary">Open Directory →</a></p></div>';
    }

    public static function render_settings(): void {
        // ── Detect optimizer capabilities ──────────────────────────────────
        $has_gd       = extension_loaded( 'gd' );
        $has_imagick  = extension_loaded( 'imagick' );
        $gd_webp      = $has_gd && function_exists( 'imagewebp' );
        $imagick_webp = $has_imagick && in_array( 'WEBP', \Imagick::queryFormats(), true );
        $imagick_avif = $has_imagick && in_array( 'AVIF', \Imagick::queryFormats(), true );
        $optimizer_ok = $gd_webp || $imagick_webp;

        $status = fn( bool $ok, string $yes, string $no ) =>
            $ok ? '<span style="color:#059669;font-weight:700">✅ ' . $yes . '</span>'
                : '<span style="color:#DC2626;font-weight:700">❌ ' . $no . '</span>';
        ?>
        <div class="wrap">
            <h1>GoodService v<?php echo esc_html( GS_VERSION ); ?></h1>
            <p>All platform settings are in the <a href="<?php echo esc_url( home_url( '/admin-panel/?section=settings' ) ); ?>" target="_blank">Platform Admin Dashboard</a>.</p>
            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px">
                <a href="<?php echo esc_url( home_url( '/admin-panel/' ) ); ?>" class="button button-primary" target="_blank">Open Admin Dashboard →</a>
                <a href="<?php echo esc_url( home_url( '/admin-panel/?section=vendors&add=1' ) ); ?>" class="button" target="_blank">➕ Add Vendor</a>
                <a href="<?php echo esc_url( home_url( '/admin-panel/?section=listings&add=1' ) ); ?>" class="button" target="_blank">➕ Add Listing</a>
                <a href="<?php echo esc_url( home_url( '/directory/' ) ); ?>" class="button" target="_blank">🔍 View Directory</a>
                <a href="<?php echo esc_url( home_url( '/vendor/login/' ) ); ?>" class="button" target="_blank">Vendor Login</a>
            </div>

            <hr style="margin:24px 0">

            <!-- ── Image Optimizer Status ────────────────────────────────── -->
            <h2>🖼 Image Optimizer Status</h2>
            <p style="color:#64748B;margin-bottom:16px">
                GoodService automatically converts uploaded images to WebP (near-lossless, quality <?php echo GS_IMG_WEBP_QUALITY; ?>)
                to reduce file size while preserving visual quality. Original files are kept with an <code>_orig</code> suffix.
            </p>
            <table class="widefat" style="max-width:640px;margin-bottom:20px">
                <thead><tr><th>Component</th><th>Status</th><th>Notes</th></tr></thead>
                <tbody>
                    <tr>
                        <td><strong>GD Extension</strong></td>
                        <td><?php echo $status( $has_gd, 'Available', 'Not installed' ); ?></td>
                        <td style="font-size:.85rem;color:#64748B">PHP GD library</td>
                    </tr>
                    <tr>
                        <td><strong>GD WebP encode</strong></td>
                        <td><?php echo $status( $gd_webp, 'Supported', 'Not compiled in' ); ?></td>
                        <td style="font-size:.85rem;color:#64748B">Required for GD-based conversion</td>
                    </tr>
                    <tr>
                        <td><strong>Imagick Extension</strong></td>
                        <td><?php echo $status( $has_imagick, 'Available', 'Not installed' ); ?></td>
                        <td style="font-size:.85rem;color:#64748B">Preferred — better quality &amp; metadata preservation</td>
                    </tr>
                    <tr>
                        <td><strong>Imagick WebP</strong></td>
                        <td><?php echo $status( $imagick_webp, 'Supported', 'Not compiled in' ); ?></td>
                        <td style="font-size:.85rem;color:#64748B">Imagick WebP encode</td>
                    </tr>
                    <tr>
                        <td><strong>Imagick AVIF</strong></td>
                        <td><?php echo $status( $imagick_avif, 'Supported', 'Not available' ); ?></td>
                        <td style="font-size:.85rem;color:#64748B">Optional — next-gen format for even smaller files</td>
                    </tr>
                    <tr style="background:<?php echo $optimizer_ok ? '#F0FDF4' : '#FFF7ED'; ?>">
                        <td><strong>Optimizer Overall</strong></td>
                        <td><?php echo $status( $optimizer_ok, 'Active — uploads will be converted to WebP', 'Disabled — no compatible image library' ); ?></td>
                        <td style="font-size:.85rem;color:#64748B">
                            <?php if ( ! $optimizer_ok ): ?>
                                Install GD with WebP support or Imagick to enable optimisation.
                            <?php else: ?>
                                Using <?php echo $imagick_webp ? 'Imagick (preferred)' : 'GD fallback'; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>

            <h3>Current Settings</h3>
            <table class="widefat" style="max-width:640px;margin-bottom:20px">
                <thead><tr><th>Setting</th><th>Value</th><th>How to change</th></tr></thead>
                <tbody>
                    <tr><td>WebP quality</td><td><strong><?php echo GS_IMG_WEBP_QUALITY; ?>/100</strong></td><td><code>define('GS_IMG_WEBP_QUALITY', 88)</code> in wp-config.php</td></tr>
                    <tr><td>AVIF quality</td><td><strong><?php echo GS_IMG_AVIF_QUALITY; ?>/100</strong></td><td><code>define('GS_IMG_AVIF_QUALITY', 80)</code></td></tr>
                    <tr><td>JPEG fallback quality</td><td><strong><?php echo GS_IMG_JPEG_QUALITY; ?>/100</strong></td><td><code>define('GS_IMG_JPEG_QUALITY', 88)</code></td></tr>
                    <tr><td>Strip EXIF/metadata</td><td><strong><?php echo GS_IMG_STRIP_META ? 'Yes (enabled)' : 'No (metadata preserved)'; ?></strong></td><td><code>define('GS_IMG_STRIP_META', true)</code></td></tr>
                    <tr><td>Max dimension cap</td><td><strong><?php echo GS_IMG_MAX_DIMENSION > 0 ? GS_IMG_MAX_DIMENSION . 'px' : 'No cap (original resolution)'; ?></strong></td><td><code>define('GS_IMG_MAX_DIMENSION', 2400)</code></td></tr>
                </tbody>
            </table>

            <div style="background:#EFF6FF;border-left:4px solid #3B82F6;padding:14px 18px;border-radius:0 8px 8px 0;max-width:640px;font-size:.87rem;line-height:1.7">
                <strong>How it works:</strong> When a vendor uploads a JPEG, PNG, or GIF, GoodService converts it to WebP
                at quality <?php echo GS_IMG_WEBP_QUALITY; ?> (near-lossless — visually indistinguishable from the original).
                PNG images with transparency are converted using <em>lossless</em> WebP (quality 100) so no alpha information is lost.
                The original file is preserved with an <code>_orig</code> suffix. PDF and document uploads are never altered.
                All sub-sizes (thumbnail, medium, large) are also converted.
            </div>

            <hr style="margin:24px 0">
            <h2>Quick Links</h2>
            <table class="widefat" style="max-width:600px">
                <tr><th>Page</th><th>URL</th></tr>
                <?php $pages = [
                    ['Admin Dashboard', '/admin-panel/'],
                    ['Add Vendor',      '/admin-panel/?section=vendors&add=1'],
                    ['Add Listing',     '/admin-panel/?section=listings&add=1'],
                    ['Directory',       '/directory/'],
                    ['Vendor Login',    '/vendor/login/'],
                    ['Vendor Register', '/vendor/register/'],
                    ['Manager Login',   '/manager/login/'],
                    ['Manager Panel',   '/manager-panel/'],
                    ['Staff Login',     '/staff/login/'],
                    ['Moderation',      '/moderation/'],
                    ['Forgot Password', '/forgot-password/'],
                    ['Create Listing (Vendor)', '/vendor/create/'],
                ];
                foreach($pages as [$name, $path]): $url = home_url($path); ?>
                <tr><td><?php echo esc_html($name); ?></td><td><a href="<?php echo esc_url($url); ?>" target="_blank"><?php echo esc_html($url); ?></a></td></tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php
    }

    public static function force_db_upgrade(): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Access denied.' ); }
        // No nonce required — protected by WP admin login + manage_options capability

        \GoodService\Database\Schema::upgrade_only(); // Fast: skips dbDelta, only adds missing columns
        $result  = \GoodService\Database\Schema::$last_upgrade_result;
        $added   = $result['added']   ?? [];
        $failed  = $result['failed']  ?? [];
        $skipped = $result['skipped'] ?? 0;
        update_option( 'gs_db_version', GS_VERSION );
        ?>
        <div class="wrap">
          <h1>🗄️ GoodService — DB Upgrade</h1>
          <?php if ( ! empty( $failed ) ): ?>
          <div class="notice notice-error inline" style="margin:12px 0">
            <p>⚠️ <strong><?php echo count($failed); ?> error(s):</strong></p>
            <ul><?php foreach($failed as $f): ?><li><?php echo esc_html($f); ?></li><?php endforeach; ?></ul>
          </div>
          <?php endif; ?>
          <?php if ( ! empty( $added ) ): ?>
          <div class="notice notice-success inline" style="margin:12px 0">
            <p>✅ <strong><?php echo count($added); ?> column(s) added:</strong> <?php echo esc_html(implode(', ', $added)); ?></p>
          </div>
          <?php else: ?>
          <div class="notice notice-success inline" style="margin:12px 0">
            <p>✅ <strong>Database already up to date.</strong> <?php echo $skipped; ?> column(s) already present — no changes needed.</p>
          </div>
          <?php endif; ?>
          <div style="display:flex;gap:10px;margin-top:16px">
            <a href="<?php echo esc_url(home_url('/admin-panel/?section=tools')); ?>" class="button button-primary">← Back to Tools</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=goodservice-flush')); ?>" class="button">Flush Routes →</a>
          </div>
        </div>
        <?php
    }

    public static function flush_rewrites(): void {
        \GoodService\Router\Router::register_rewrites();
        flush_rewrite_rules( true );
        // Also ensure pages exist
        \GoodService\Core\Plugin::create_pages();
        ?>
        <div class="wrap">
          <h1>🔄 GoodService — Routes Flushed</h1>
          <div class="notice notice-success inline" style="margin:12px 0">
            <p>✅ <strong>Rewrite rules flushed successfully!</strong> All platform URLs are now active.</p>
          </div>
          <div style="display:flex;gap:10px;flex-wrap:wrap;margin:16px 0">
            <a href="<?php echo esc_url(home_url('/admin-panel/')); ?>" class="button button-primary button-large" target="_blank">🚀 Open Admin Dashboard</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=goodservice')); ?>" class="button">← Back to GoodService</a>
          </div>
          <table class="widefat" style="max-width:640px"><thead><tr><th>Page</th><th>URL</th><th></th></tr></thead><tbody>
          <?php foreach ([
            ['Admin Dashboard',  home_url('/admin-panel/')],
            ['Directory',        home_url('/directory/')],
            ['Vendor Dashboard', home_url('/vendor/dashboard/')],
            ['Vendor Login',     home_url('/vendor/login/')],
            ['Manager Login',    home_url('/manager/login/')],
            ['Staff Login',      home_url('/staff/login/')],
            ['Manager Panel',    home_url('/manager-panel/')],
            ['Moderation',       home_url('/moderation/')],
            ['Forgot Password',  home_url('/forgot-password/')],
            ['Vendor Site (eg)', home_url('/demo-vendor/')],
          ] as [$name, $url]): ?>
          <tr>
            <td><?php echo esc_html($name); ?></td>
            <td><code style="font-size:.8rem"><?php echo esc_html($url); ?></code></td>
            <td><a href="<?php echo esc_url($url); ?>" target="_blank" class="button button-small">Open →</a></td>
          </tr>
          <?php endforeach; ?>
          </tbody></table>
        </div>
        <?php
    }
}
