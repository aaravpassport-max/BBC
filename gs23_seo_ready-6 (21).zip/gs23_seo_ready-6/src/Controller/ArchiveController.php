<?php
namespace GoodService\Controller;

use GoodService\Repository\ListingRepository;
use GoodService\Repository\CategoryRepository;
use GoodService\Core\Config;

class ArchiveController extends BaseController {

    public function index(): void {
        $repo     = new ListingRepository();
        $cat_repo = new CategoryRepository();

        $args = [
            'keyword'  => sanitize_text_field( $_GET['keyword'] ?? '' ),
            'city'     => sanitize_text_field( $_GET['city']    ?? '' ),
            'category' => (int) ( $_GET['category'] ?? 0 ),
            'sort'     => sanitize_text_field( $_GET['sort']    ?? 'featured' ),
            'type'     => sanitize_text_field( $_GET['type']    ?? '' ),
            'page'     => max( 1, (int) ( $_GET['page'] ?? 1 ) ),
            'per_page' => 12,
        ];

        // Handle category slug URL
        //
        // Real fix: this called CategoryRepository::find_by('slug', $cat_slug),
        // a method that has never existed on CategoryRepository or its base
        // class (only find(int $id), get_by_slug(string $slug), get_by_id(),
        // get_all_active(), get_with_subcategories() exist). Calling an
        // undefined method throws \Error in PHP 8, which is a \Throwable —
        // caught by render_page()'s generic catch block and shown to every
        // non-admin visitor as "Something went wrong. Please try again or
        // contact support." This fired on EVERY /directory/{category-slug}/
        // URL (the rewrite rule that sets gs_category), not just the one
        // reported — any direct category-slug URL across the whole
        // directory was broken the same way. Swapped for the real,
        // already-existing get_by_slug() method.
        $cat_slug = get_query_var( 'gs_category' );
        if ( $cat_slug ) {
            $cat = $cat_repo->get_by_slug( $cat_slug );
            if ( $cat ) $args['category'] = (int) $cat->id;
        }

        $result     = $repo->search( $args );
        $categories = $cat_repo->get_with_subcategories();
        $cities     = $repo->get_cities();
        $current_cat= $args['category'] ? $cat_repo->find( $args['category'] ) : null;

        $this->view( 'archive', compact( 'result', 'categories', 'cities', 'args', 'current_cat' ) );
    }
}
