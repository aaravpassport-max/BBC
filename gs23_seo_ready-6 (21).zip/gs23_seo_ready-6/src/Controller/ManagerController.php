<?php
namespace GoodService\Controller;

use GoodService\Core\Roles;

class ManagerController extends BaseController {

    public function dashboard(): void {
        if ( ! Roles::is_manager() && ! Roles::is_admin_level() ) {
            $this->redirect( home_url( '/vendor/login/' ) );
        }
        // Manager dashboard has its own standalone template
        $path = GS_DIR . 'templates/pages/manager-dashboard.php';
        if ( file_exists( $path ) ) {
            require $path;
        } else {
            echo '<div style="padding:40px;text-align:center;color:#DC2626">Manager dashboard template missing.</div>';
        }
    }
}
