<?php
namespace GoodService\Controller;

use GoodService\Core\Roles;

class AuthController extends BaseController {

    // ── Shared: determine correct dashboard URL for current user ──────────────
    private static function dashboard_url(): string {
        if ( function_exists( 'gs_login_redirect' ) ) {
            return gs_login_redirect();
        }
        $roles = (array) wp_get_current_user()->roles;
        if ( in_array( 'administrator', $roles, true ) || current_user_can( 'manage_options' ) ) {
            return home_url( '/admin-panel/' );
        }
        if ( in_array( 'gs_manager', $roles, true ) ) {
            return home_url( '/manager-panel/' );
        }
        if ( in_array( 'gs_moderator', $roles, true ) || in_array( 'gs_staff', $roles, true ) ) {
            return home_url( '/moderation/' );
        }
        // Same fix as gs_login_redirect() — this fallback never checked for
        // gs_customer, which would send customers into the exact same
        // infinite redirect loop if this path were ever reached.
        if ( in_array( 'gs_vendor', $roles, true ) ) {
            return home_url( '/vendor/dashboard/' );
        }
        if ( in_array( 'gs_regional_manager', $roles, true ) ) {
            return home_url( '/admin-panel/?section=regional_manager' );
        }
        if ( in_array( 'gs_customer', $roles, true ) ) {
            return home_url( '/my-account/' );
        }
        return home_url( '/vendor/dashboard/' );
    }

    // ── Universal vendor/all-role login page (/vendor/login/) ────────────────
    public function login(): void {
        if ( is_user_logged_in() ) {
            $this->redirect( self::dashboard_url() );
        }
        $this->view( 'auth-login' );
    }

    // ── Register page (/vendor/register/) ────────────────────────────────────
    public function register(): void {
        if ( is_user_logged_in() ) {
            $this->redirect( self::dashboard_url() );
        }
        $this->view( 'auth-register' );
    }

    // ── Admin login entry point (/admin/login/) ────────────────────────────
    // Real fix — confirmed gap: no admin-specific frontend login URL existed
    // at all, despite the platform's own role-based redirect logic already
    // correctly handling administrator authentication. Redirects into the
    // same, already-proven universal login flow rather than building a
    // fourth independent copy of the login form and its redirect logic.
    public function admin_login(): void {
        if ( is_user_logged_in() && ( Roles::is_admin_level() ) ) {
            $this->redirect( home_url( '/admin-panel/' ) );
        }
        $this->redirect( home_url( '/login/?role=admin' ) );
    }

    // ── Manager-specific login page (/manager/login/) ─────────────────────────
    public function manager_login(): void {
        if ( is_user_logged_in() ) {
            $this->redirect( Roles::is_manager() ? home_url( '/manager-panel/' ) : self::dashboard_url() );
        }
        $this->view( 'auth-manager-login' );
    }

    // ── Staff/Moderator login page (/staff/login/) ────────────────────────────
    public function staff_login(): void {
        if ( is_user_logged_in() ) {
            $this->redirect( Roles::is_moderator() ? home_url( '/moderation/' ) : self::dashboard_url() );
        }
        $this->view( 'auth-staff-login' );
    }

    // ── Staff dashboard (moderation wrapper) (/staff/dashboard/) ─────────────
    public function staff_dashboard(): void {
        if ( ! is_user_logged_in() ) {
            $this->redirect( home_url( '/staff/login/' ) );
        }
        if ( ! Roles::is_moderator() ) {
            $this->redirect( home_url( '/staff/login/' ) );
        }
        // Reuse the full moderation dashboard template
        $path = GS_DIR . 'templates/pages/other-dashboards.php';
        // Force the gs_page query var so other-dashboards.php renders moderation_dashboard
        set_query_var( 'gs_page', 'moderation_dashboard' );
        if ( file_exists( $path ) ) {
            require $path;
        } else {
            echo '<div style="padding:40px;text-align:center;color:#DC2626">Staff dashboard template missing.</div>';
        }
    }

    // ── Forgot password page (/forgot-password/) ──────────────────────────────
    public function forgot_password(): void {
        if ( is_user_logged_in() ) {
            $this->redirect( self::dashboard_url() );
        }
        $this->view( 'auth-forgot-password' );
    }

    // ── Vendor-acquisition landing page (/advertise/) ───────────────────────
    // Real feature — deliberately no redirect for logged-in users, unlike
    // forgot_password above: an already-logged-in vendor should still be
    // able to view plans/pricing here, not get bounced to their dashboard.
    public function advertise_with_us(): void {
        $this->view( 'advertise-with-us' );
    }

    // ── Customer-facing process explainer (/how-it-works/) ──────────────────
    // Real feature — same reasoning as advertise_with_us() above: no
    // redirect for logged-in users, since this page is equally relevant
    // to a first-time visitor and an already-registered customer trying
    // to understand what happens after they book.
    public function how_it_works(): void {
        $this->view( 'how-it-works' );
    }

    // ── Trust & Safety explainer (/trust-safety/) ────────────────────────────
    // Real feature — same reasoning as how_it_works() above.
    public function trust_safety(): void {
        $this->view( 'trust-safety' );
    }

    // ── About Us page (/about-us/) ───────────────────────────────────────────
    public function about_us(): void {
        $this->view( 'about-us' );
    }

    // ── Contact Us page (/contact-us/) ───────────────────────────────────────
    public function contact_us(): void {
        $this->view( 'contact-us' );
    }

    // ── Reset password page (/reset-password/) ────────────────────────────────
    public function reset_password(): void {
        if ( is_user_logged_in() ) {
            $this->redirect( self::dashboard_url() );
        }
        // key and login are passed as URL params from the WP reset email
        $key   = sanitize_text_field( $_GET['key']   ?? '' );
        $login = sanitize_text_field( $_GET['login'] ?? '' );
        if ( ! $key || ! $login ) {
            // Invalid link — redirect to forgot password with message
            $this->redirect( home_url( '/forgot-password/?error=invalid_link' ) );
        }
        $this->view( 'auth-reset-password', compact( 'key', 'login' ) );
    }

    // ── Vendor staff portal (/vendor/staff/) ─────────────────────────────────
    public function vendor_staff_dashboard(): void {
        if ( ! is_user_logged_in() ) {
            $this->redirect( home_url( '/vendor/login/' ) );
        }
        global $wpdb;
        $staff_row = $wpdb->get_row( $wpdb->prepare(
            "SELECT vs.* FROM {$wpdb->prefix}gs_vendor_staff vs WHERE vs.user_id = %d",
            get_current_user_id()
        ) );
        if ( ! $staff_row && ! Roles::is_vendor() ) {
            $this->redirect( home_url( '/vendor/login/' ) );
        }
        // Render vendor_staff_dashboard section of other-dashboards.php
        set_query_var( 'gs_page', 'vendor_staff_dashboard' );
        $path = GS_DIR . 'templates/pages/other-dashboards.php';
        if ( file_exists( $path ) ) {
            require $path;
        }
    }
}
