<?php
namespace GoodService\Controller;

use GoodService\Core\Roles;
use GoodService\Repository\VendorRepository;

class VendorController extends BaseController {

    public function dashboard(): void {
        if ( ! is_user_logged_in() ) {
            $this->redirect( home_url( '/vendor/login/' ) );
        }
        if ( ! Roles::is_vendor() ) {
            $this->redirect( home_url( '/vendor/login/' ) );
        }
        // Admins/managers without a vendor profile → send to admin panel
        if ( Roles::is_admin_level() ) {
            $vp = VendorRepository::get_by_user( get_current_user_id() );
            if ( ! $vp ) {
                $this->redirect( home_url( '/admin-panel/' ) );
            }
        }
        // Real fix: same as AdminController::dashboard() — this custom
        // front-end route isn't WordPress's native /wp-admin/, so it can
        // be served stale by a page cache without this explicit call.
        nocache_headers();
        $this->view( 'vendor-dashboard' );
    }

    public function public_profile(): void {
        $slug   = sanitize_text_field( get_query_var( 'gs_vendor_slug', '' ) );
        $vendor = VendorRepository::get_by_slug( $slug );
        // FUNC FIX #4: Handle missing vendor gracefully instead of passing null
        // to the template where $vendor->property access causes PHP 8.x TypeError.
        if ( ! $vendor ) {
            $this->redirect( home_url( '/directory/' ) );
        }
        $this->view( 'vendor-profile', compact( 'vendor', 'slug' ) );
    }
}
