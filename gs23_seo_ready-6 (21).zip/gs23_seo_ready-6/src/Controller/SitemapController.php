<?php
namespace GoodService\Controller;

class SitemapController {

    // 10,000 rather than Google's full 50,000-per-file allowance — research
    // (cited when this was built) found that cramming sitemaps to the legal
    // maximum has been observed to reduce overall indexing completeness;
    // smaller, more numerous files tend to index more thoroughly in
    // practice. Still comfortably under the 50MB uncompressed file-size
    // limit at this URL count.
    const LISTINGS_PER_SITEMAP = 10000;

    /**
     * Sitemap INDEX — the entry point search engines actually request
     * (/gs-sitemap.xml). Lists every individual sitemap file rather than
     * listing pages directly, so the total listing count is no longer
     * capped by a single file's URL limit. This is the standard,
     * documented structure for any site with more URLs than fit in one
     * sitemap file (Google's hard limit: 50,000 URLs per file).
     */
    public static function render(): void {
        header( 'Content-Type: application/xml; charset=UTF-8' );
        global $wpdb;

        // Real fix — reuses the platform's own established indexability
        // rule (see SEO\Modules\IndexabilityModule.php): a listing that
        // is active but explicitly marked noindex should never appear
        // in the sitemap. Including a noindex page in a sitemap sends
        // search engines a contradictory signal, which Google's own
        // guidance explicitly advises against — this count must match
        // the same filter the actual listings query below uses, or
        // pagination here and the real page contents would disagree.
        $total_listings = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gs_listings WHERE status = 'active' AND ( seo_robots IS NULL OR seo_robots NOT LIKE '%noindex%' )"
        );
        $listing_pages = max( 1, (int) ceil( $total_listings / self::LISTINGS_PER_SITEMAP ) );

        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        // Static/core pages — kept in the index itself as a tiny dedicated
        // sitemap, generated inline rather than as a separate route since
        // there are only ever two URLs here.
        echo '<sitemap><loc>' . esc_url( home_url( '/gs-sitemap-core.xml' ) ) . '</loc></sitemap>' . "\n";

        for ( $page = 1; $page <= $listing_pages; $page++ ) {
            echo '<sitemap><loc>' . esc_url( home_url( "/gs-sitemap-listings-{$page}.xml" ) ) . '</loc></sitemap>' . "\n";
        }

        // SEO Search Entry URLs — only approved/indexable/sitemap_enabled
        // entries whose parent listing is still active are ever counted
        // here (Part 23, 41 — a disabled/deleted entry disappears from the
        // sitemap on its own, no separate cleanup job required).
        $seo_pfx = $wpdb->prefix . 'gs_';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$seo_pfx}seo_microsite_entries'" ) ) {
            $total_seo_entries = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$seo_pfx}seo_microsite_entries e
                 INNER JOIN {$seo_pfx}listings l ON l.id = e.listing_id
                 WHERE e.indexable = 1 AND e.sitemap_enabled = 1 AND e.status IN ('approved','indexable')
                   AND l.status = 'active'"
            );
            $seo_pages = $total_seo_entries > 0 ? (int) ceil( $total_seo_entries / self::LISTINGS_PER_SITEMAP ) : 0;
            for ( $page = 1; $page <= $seo_pages; $page++ ) {
                echo '<sitemap><loc>' . esc_url( home_url( "/gs-sitemap-seo-entries-{$page}.xml" ) ) . '</loc></sitemap>' . "\n";
            }
        }

        echo '</sitemapindex>';
        exit;
    }

    /**
     * One real chunk of listing URLs — /gs-sitemap-listings-{page}.xml.
     * Ordered by id (a stable, indexed column) rather than updated_at, so
     * pagination is deterministic and consistent between requests — using
     * updated_at for paging would risk a listing jumping between pages (or
     * being skipped entirely) if it gets edited between two crawl
     * requests, since its sort position would change mid-pagination.
     */
    public static function render_listings_page( int $page ): void {
        header( 'Content-Type: application/xml; charset=UTF-8' );
        global $wpdb;
        $page = max( 1, $page );
        $offset = ( $page - 1 ) * self::LISTINGS_PER_SITEMAP;

        // Real feature, item 6 from the audit: image sitemap extension —
        // now also selects the real image fields already confirmed to
        // exist on this table, used below to emit <image:image> nodes.
        $listings = $wpdb->get_results( $wpdb->prepare(
            "SELECT slug, updated_at, created_at, title, logo_url, banner_url, gallery FROM {$wpdb->prefix}gs_listings WHERE status = 'active' AND ( seo_robots IS NULL OR seo_robots NOT LIKE '%noindex%' ) ORDER BY id ASC LIMIT %d OFFSET %d",
            self::LISTINGS_PER_SITEMAP, $offset
        ) );

        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        // Real feature: declares the standard image sitemap namespace
        // alongside the base sitemap namespace — Google's documented way
        // to combine image data into the regular sitemap rather than
        // requiring a wholly separate image sitemap file.
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";
        foreach ( $listings as $l ) {
            // Guard against null updated_at — fall back to created_at, then today.
            $ts = ! empty( $l->updated_at ) ? strtotime( $l->updated_at )
                : ( ! empty( $l->created_at ) ? strtotime( $l->created_at ) : time() );
            if ( ! $ts || $ts < 0 ) { $ts = time(); }
            echo '<url><loc>' . esc_url( home_url( '/' . $l->slug . '/' ) ) . '</loc>';
            echo '<lastmod>' . date( 'Y-m-d', $ts ) . '</lastmod>';
            echo '<changefreq>weekly</changefreq><priority>0.7</priority>';

            // Real feature, item 6: real images for this listing — logo,
            // banner, and up to 5 gallery photos (a sane cap; Google
            // supports up to 1,000 images per URL, but the real, practical
            // value here is the primary/hero images, not an unbounded set).
            $image_urls = [];
            if ( ! empty( $l->logo_url ) )   { $image_urls[] = $l->logo_url; }
            if ( ! empty( $l->banner_url ) ) { $image_urls[] = $l->banner_url; }
            if ( ! empty( $l->gallery ) ) {
                $gallery_decoded = json_decode( $l->gallery, true );
                if ( is_array( $gallery_decoded ) ) {
                    foreach ( array_slice( $gallery_decoded, 0, 5 ) as $g ) {
                        $g_url = is_array( $g ) ? ( $g['url'] ?? '' ) : $g;
                        if ( $g_url ) { $image_urls[] = $g_url; }
                    }
                }
            }
            $image_urls = array_unique( array_filter( $image_urls ) );
            foreach ( $image_urls as $img_url ) {
                echo '<image:image><image:loc>' . esc_url( $img_url ) . '</image:loc>';
                if ( ! empty( $l->title ) ) {
                    echo '<image:title>' . esc_html( $l->title ) . '</image:title>';
                }
                echo '</image:image>';
            }

            echo '</url>' . "\n";
        }
        echo '</urlset>';
        exit;
    }

    /**
     * SEO Search Entry URLs — /{microsite-slug}/{seo-keyword-slug}/.
     * Only rows that are indexable=1, sitemap_enabled=1, status IN
     * ('approved','indexable'), AND whose parent listing is active are
     * ever emitted — the same gate the router itself enforces before
     * serving one of these URLs at all (Part 23, 24).
     */
    public static function render_seo_entries_page( int $page ): void {
        header( 'Content-Type: application/xml; charset=UTF-8' );
        global $wpdb;
        $page = max( 1, $page );
        $offset = ( $page - 1 ) * self::LISTINGS_PER_SITEMAP;
        $pfx = $wpdb->prefix . 'gs_';

        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$pfx}seo_microsite_entries'" ) ) {
            $entries = $wpdb->get_results( $wpdb->prepare(
                "SELECT e.canonical_url, e.updated_at, e.created_at
                 FROM {$pfx}seo_microsite_entries e
                 INNER JOIN {$pfx}listings l ON l.id = e.listing_id
                 WHERE e.indexable = 1 AND e.sitemap_enabled = 1 AND e.status IN ('approved','indexable')
                   AND l.status = 'active'
                 ORDER BY e.id ASC LIMIT %d OFFSET %d",
                self::LISTINGS_PER_SITEMAP, $offset
            ) );
            foreach ( $entries as $e ) {
                if ( empty( $e->canonical_url ) ) { continue; }
                $ts = ! empty( $e->updated_at ) ? strtotime( $e->updated_at )
                    : ( ! empty( $e->created_at ) ? strtotime( $e->created_at ) : time() );
                if ( ! $ts || $ts < 0 ) { $ts = time(); }
                echo '<url><loc>' . esc_url( $e->canonical_url ) . '</loc>';
                echo '<lastmod>' . date( 'Y-m-d', $ts ) . '</lastmod>';
                // Lower priority/changefreq than the primary microsite URL —
                // this is a secondary entry point, not the canonical page.
                echo '<changefreq>monthly</changefreq><priority>0.5</priority></url>' . "\n";
            }
        }
        echo '</urlset>';
        exit;
    }

    /**
     * The small, fixed set of non-listing pages — home, directory browse,
     * programmatic SEO location pages, and category browse pages. Split
     * out from the listings sitemap so the listings file is purely
     * listings (cleaner for diagnosing indexing issues per content type,
     * per the documented best practice of separating sitemaps by content
     * type rather than mixing everything into one file).
     */
    public static function render_core(): void {
        header( 'Content-Type: application/xml; charset=UTF-8' );
        global $wpdb;

        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        echo '<url><loc>' . esc_url( home_url( '/' ) ) . '</loc><changefreq>daily</changefreq><priority>1.0</priority></url>' . "\n";
        echo '<url><loc>' . esc_url( home_url( '/directory/' ) ) . '</loc><changefreq>daily</changefreq><priority>0.9</priority></url>' . "\n";

        // Real fix — these are real, live, publicly-routed pages (see
        // Router.php's own static-page registration) that had never
        // been included in the sitemap at all, despite being exactly
        // the kind of canonical, indexable content a sitemap exists
        // to surface.
        foreach ( [ 'about-us', 'contact-us', 'blog', 'privacy-policy', 'terms-of-service', 'cookie-policy', 'refund-policy', 'disclaimer' ] as $static_slug ) {
            echo '<url><loc>' . esc_url( home_url( '/' . $static_slug . '/' ) ) . '</loc><changefreq>monthly</changefreq><priority>0.5</priority></url>' . "\n";
        }

        // Programmatic SEO location pages
        $tbl_loc = $wpdb->prefix . 'gs_seo_location_pages';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$tbl_loc}'" ) ) {
            $location_pages = $wpdb->get_results(
                "SELECT page_url, last_updated FROM {$tbl_loc} WHERE vendor_count >= 3 ORDER BY vendor_count DESC LIMIT 2000"
            ) ?: [];
            foreach ( $location_pages as $page ) {
                $lts = ! empty( $page->last_updated ) ? strtotime( $page->last_updated ) : time();
                if ( ! $lts || $lts < 0 ) { $lts = time(); }
                echo '<url><loc>' . esc_url( home_url( $page->page_url ) ) . '</loc>';
                echo '<lastmod>' . date( 'Y-m-d', $lts ) . '</lastmod>';
                echo '<changefreq>weekly</changefreq><priority>0.8</priority></url>' . "\n";
            }
        }

        // Category browse pages
        $cats = $wpdb->get_results(
            "SELECT slug FROM {$wpdb->prefix}gs_categories WHERE is_active=1 ORDER BY sort_order ASC LIMIT 200"
        ) ?: [];
        foreach ( $cats as $cat ) {
            echo '<url><loc>' . esc_url( home_url( '/directory/' . $cat->slug . '/' ) ) . '</loc>';
            echo '<changefreq>daily</changefreq><priority>0.8</priority></url>' . "\n";
        }

        echo '</urlset>';
        exit;
    }

    /**
     * /llms.txt — confirmed real, missing item from the SEO Ceiling Plan.
     * Follows the official llmstxt.org specification exactly: H1 site
     * name (the only required section), a blockquote summary, then
     * H2-grouped sections of links with a short description after each.
     * Plain text/markdown, served at the genuine site root.
     *
     * Uses real, live database content (actual platform name/description,
     * actual top categories with real active listing counts) rather than
     * static text, since a stale llms.txt has been documented to actively
     * misinform AI models rather than simply being unhelpful — keeping
     * this dynamic means it never goes stale on its own.
     */
    public static function render_llms_txt(): void {
        header( 'Content-Type: text/plain; charset=UTF-8' );
        global $wpdb;

        $platform    = \GoodService\Core\Config::get( 'platform_name', get_bloginfo( 'name' ) );
        $description = \GoodService\Core\Config::get(
            'platform_description',
            "Find verified local service providers across India."
        );

        echo "# {$platform}\n\n";
        echo "> {$description}\n\n";

        echo "## Directory\n";
        echo "- [Browse all service providers](" . home_url( '/directory/' ) . "): Full directory of verified local businesses, filterable by category, city, and rating.\n\n";

        // Top real categories by actual active listing count — curated,
        // not exhaustive, per the documented best practice of treating
        // this as an editorial briefing rather than a dump of every URL.
        $top_categories = $wpdb->get_results(
            "SELECT c.name, c.slug, COUNT(l.id) AS listing_count
             FROM {$wpdb->prefix}gs_categories c
             INNER JOIN {$wpdb->prefix}gs_listings l ON l.category_id = c.id AND l.status = 'active'
             WHERE c.is_active = 1 AND c.parent_id = 0
             GROUP BY c.id
             HAVING listing_count > 0
             ORDER BY listing_count DESC
             LIMIT 12"
        ) ?: [];

        if ( $top_categories ) {
            echo "## Service Categories\n";
            foreach ( $top_categories as $cat ) {
                $cat_url = home_url( '/directory/' . $cat->slug . '/' );
                $count   = (int) $cat->listing_count;
                $noun    = $count === 1 ? 'provider' : 'providers';
                echo "- [{$cat->name}]({$cat_url}): {$count} verified {$noun} in this category.\n";
            }
            echo "\n";
        }

        echo "## About\n";
        echo "- [List your business](" . home_url( '/vendor/create/' ) . "): How a service provider creates a free listing on {$platform}.\n";

        exit;
    }

    /**
     * /{listing-slug}/llms.txt — real fix, confirmed via PageSpeed's
     * "Agent Accessibility" / llms.txt audit: it checks for a file scoped
     * to the CURRENT page's own path, not only the site root, so every
     * vendor listing page was 404ing this check even though the root
     * /llms.txt is itself correct. Falls back to the same site-wide
     * content whenever the slug doesn't resolve to a real, active
     * listing, so this endpoint never 404s for any path it's asked about.
     *
     * Every link emitted here is verified real: the listing's own page
     * URL always exists, and the #vs-sec-services in-page anchor is only
     * added when services_data is genuinely non-empty — the exact same
     * condition vendor-site.php itself uses to decide whether that
     * section renders at all, so this can never link to an anchor that
     * isn't actually on the page.
     */
    public static function render_llms_txt_for_listing( string $slug ): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT l.title, l.short_desc, l.seo_desc, l.city, l.slug, l.services_data,
                    c.name AS cat_name
             FROM {$pfx}listings l
             LEFT JOIN {$pfx}categories c ON c.id = l.category_id
             WHERE l.slug = %s AND l.status = 'active' LIMIT 1",
            strtolower( $slug )
        ) );

        if ( ! $row || empty( $row->title ) ) {
            // Not a real, active listing — fall back to the site-wide
            // file rather than 404, since the audit expects *some* valid
            // llms.txt at any path it checks.
            self::render_llms_txt();
            return;
        }

        header( 'Content-Type: text/plain; charset=UTF-8' );
        $platform    = \GoodService\Core\Config::get( 'platform_name', get_bloginfo( 'name' ) );
        $listing_url = home_url( '/' . $row->slug . '/' );
        $name        = wp_strip_all_tags( $row->title );

        $summary = wp_strip_all_tags( $row->short_desc ?: $row->seo_desc ?: '' );
        if ( $summary === '' ) {
            // No description on file — build one from real, already-known
            // fields rather than fabricating claims about the business.
            $bits = array_filter( [ $row->cat_name ? "a {$row->cat_name} provider" : '', $row->city ? "in {$row->city}" : '' ] );
            $summary = $bits ? ( "{$name} — " . implode( ' ', $bits ) . " on {$platform}." ) : "{$name} on {$platform}.";
        }

        echo "# {$name}\n\n";
        echo "> {$summary}\n\n";

        echo "## Listing\n";
        echo "- [Full profile & contact details]({$listing_url}): Verified listing for {$name} on {$platform}, including services, reviews, and how to get in touch.\n";

        $_services = $row->services_data;
        if ( is_string( $_services ) ) { $_services = json_decode( $_services, true ) ?: []; }
        if ( is_array( $_services ) && ! empty( array_filter( $_services, fn( $s ) => is_array( $s ) && trim( (string) ( $s['name'] ?? '' ) ) !== '' ) ) ) {
            echo "- [Services offered]({$listing_url}#vs-sec-services): The full list of services {$name} offers, with descriptions and pricing where provided.\n";
        }
        echo "\n";

        echo "## Directory\n";
        echo "- [Browse the full directory](" . home_url( '/directory/' ) . "): Every verified local business on {$platform}, filterable by category and city.\n";

        exit;
    }
}
