<?php
namespace GoodService\Controller;
use GoodService\Core\Roles;

abstract class BaseController {
    protected function nonce( string $action = '' ): void {
        // SEC FIX #4: Nonce must come from POST body or X-GS-Nonce header only.
        // Previously also accepted $_GET['nonce'], which exposes nonce tokens in
        // server logs, referrer headers, and browser history.
        // wp_unslash: WP's magic quotes add slashes to $_POST globally; nonces
        // are alphanumeric so unslashing doesn't change them, but is correct practice.
        $n = wp_unslash( $_POST['nonce'] ?? $_SERVER['HTTP_X_GS_NONCE'] ?? '' );
        if ( ! wp_verify_nonce( $n, 'gs_ajax' ) && ! wp_verify_nonce( $n, 'gs_admin' ) ) {
            $this->error( 'Security check failed.', 403 );
        }
    }

    /**
     * Real fix, audit sweep: several GET-triggered CSV/file download links
     * (a plain <a href="admin-ajax.php?...&nonce=...">, not an AJAX POST)
     * were calling the strict nonce() above, which only reads POST/header —
     * so every one of those download links unconditionally 403'd with
     * "Security check failed." This is the same GET-source exception
     * require_export_admin() already carves out for one export action,
     * generalized so any read-only download endpoint can opt in explicitly
     * rather than reinventing (or forgetting) the same fix per-method.
     * Only use this for endpoints that are pure downloads with no side
     * effects — it deliberately trades the referrer/log leak risk nonce()
     * was hardened against for the ability to work as a plain link at all.
     */
    protected function nonce_allow_get(): void {
        $n = wp_unslash( $_GET['nonce'] ?? $_POST['nonce'] ?? $_SERVER['HTTP_X_GS_NONCE'] ?? '' );
        if ( ! wp_verify_nonce( $n, 'gs_ajax' ) && ! wp_verify_nonce( $n, 'gs_admin' ) ) {
            $this->error( 'Security check failed.', 403 );
        }
    }
    protected function auth(): void { if(!is_user_logged_in()) $this->error('Login required.',401); }
    protected function require_vendor(): void {
        $this->auth();
        // MAJOR FIX #7: Use can_create_listings() which covers both gs_vendor role
        // AND admin-level users. is_vendor() now strictly means "has gs_vendor role".
        if ( ! Roles::can_create_listings() ) {
            $this->error( 'Vendor access required.', 403 );
        }
        // Real gap fix: suspendVendor() sets is_active=0 on gs_vendor_profiles, but
        // this was never checked here — a suspended vendor retained full dashboard
        // and API access with zero restriction, making the admin "suspend" action
        // have no observable effect on the vendor's own ability to operate.
        // Only blocks when a vendor profile genuinely exists and is explicitly
        // inactive — an admin-level user with no vendor profile row at all still
        // passes through unaffected (preserves the "also covers admin" behavior
        // documented above).
        $vp = \GoodService\Repository\VendorRepository::get_by_user( get_current_user_id() );
        if ( $vp && (int) ( $vp->is_active ?? 1 ) === 0 ) {
            $this->error( 'Your vendor account has been suspended. Please contact support.', 403 );
        }
    }
    protected function require_admin(): void  { $this->auth(); if(!Roles::is_admin_level()) $this->error('Admin access required.',403); }
    protected function require_operations(): void { $this->auth(); if(!Roles::is_operations_level()) $this->error('Operations access required.',403); }
    protected function ok(array $data=[], string $msg='OK'): never { wp_send_json_success(array_merge(['message'=>$msg],$data)); }
    protected function error(string $msg, int $code=400): never { wp_send_json_error(['message'=>$msg],$code); }
    protected function redirect(string $url): never { wp_safe_redirect($url); exit; }
    protected function view(string $tpl, array $vars=[]): void {
        $path = GS_DIR.'templates/pages/'.$tpl.'.php';
        if(!file_exists($path)){ echo '<p style="color:red">Template missing: '.esc_html($tpl).'.php</p>'; return; }
        // Real fix for confirmed CDN-caching bug: this render path serves
        // personalized, logged-in-only content (e.g. the customer dashboard
        // via VisitorController::dashboard()), but never sent any
        // cache-control headers at all — leaving the caching decision
        // entirely up to whatever default a CDN or browser applies, which is
        // exactly how a page personalized to one user gets served, cached,
        // and then shown identically-stale to every subsequent visitor.
        // Explicit no-store headers instruct any standards-respecting
        // downstream cache (including Cloudflare's default, non-page-rule
        // behavior) not to cache this response at all.
        if ( is_user_logged_in() && ! headers_sent() ) {
            nocache_headers();
            header( 'Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0' );
            header( 'CDN-Cache-Control: no-store' ); // Cloudflare-specific — takes precedence over generic Cache-Control on CF's edge.
            header( 'Pragma: no-cache' );
        }
        if($vars) extract($vars,EXTR_SKIP);
        require $path;
    }
    protected function post(string $key, string $type='text', mixed $default=''): mixed {
        $raw = $_POST[$key] ?? $default;
        return match($type){
            'int'=>(int)$raw,'float'=>(float)$raw,'email'=>sanitize_email($raw),
            'url'=>esc_url_raw($raw),'textarea'=>sanitize_textarea_field($raw),
            'html'=>wp_kses_post($raw),'raw'=>$raw,
            default=>sanitize_text_field($raw),
        };
    }
}
