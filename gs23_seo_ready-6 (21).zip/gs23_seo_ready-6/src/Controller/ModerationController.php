<?php
namespace GoodService\Controller;

use GoodService\Core\Roles;

class ModerationController extends BaseController {

    public function dashboard(): void {
        if ( ! is_user_logged_in() ) {
            $this->redirect( home_url( '/staff/login/' ) );
        }
        if ( ! Roles::is_moderator() ) {
            $this->redirect( home_url( '/staff/login/' ) );
        }
        $this->view( 'other-dashboards', [ 'dash_type' => 'moderation' ] );
    }
}
