<?php
namespace GoodService\Controller;

use GoodService\Core\Roles;

class AdminController extends BaseController {

    public function dashboard(): void {
        if ( ! Roles::is_operations_level() && ! Roles::is_regional_manager() ) {
            $this->redirect( home_url( '/vendor/login/' ) );
        }
        // Real fix: this custom front-end admin panel is not WordPress's
        // native /wp-admin/, which most caching plugins/servers exclude
        // automatically. Without an explicit nocache_headers() call here,
        // this page can be served stale from cache — an admin could see a
        // snapshot from before a fresh review submission, making a
        // successful submission look like it never appeared.
        nocache_headers();
        // Plugin::check_db_version() is normally hooked to admin_notices, which only
        // fires inside real /wp-admin/ page loads. This custom front-end admin panel
        // is how administrators actually use the plugin day-to-day, so without this
        // call, anyone who upgrades the plugin files but never separately visits
        // /wp-admin/ will keep running against stale table columns indefinitely —
        // every new feature that needed a schema change (this one included) breaks
        // with confusing "could not save" errors instead of upgrading silently.
        // check_db_version() is already idempotent (version_compare + static guard),
        // safe to call here unconditionally.
        \GoodService\Core\Plugin::check_db_version();
        $this->view( 'admin-dashboard' );
    }
}
