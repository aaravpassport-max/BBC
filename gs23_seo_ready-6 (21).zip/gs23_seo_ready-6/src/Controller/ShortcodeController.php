<?php
namespace GoodService\Controller;

use GoodService\Repository\CategoryRepository;
use GoodService\Repository\ListingRepository;
use GoodService\Core\Cache;

class ShortcodeController {

    public static function register(): void {
        add_shortcode( 'gs_home',              [ self::class, 'sc_home'        ] );
        add_shortcode( 'gs_directory',         [ self::class, 'sc_directory'   ] );
        add_shortcode( 'gs_login',             [ self::class, 'sc_login'       ] );
        add_shortcode( 'gs_register',          [ self::class, 'sc_register'    ] );
        add_shortcode( 'gs_vendor_dashboard',  [ self::class, 'sc_vendor_dash' ] );
        add_shortcode( 'gs_search_bar',        [ self::class, 'sc_search_bar'  ] );
        add_shortcode( 'gs_categories_grid',   [ self::class, 'sc_categories'  ] );
        add_shortcode( 'gs_featured_listings', [ self::class, 'sc_featured'    ] );
        add_shortcode( 'gs_lead_form',         [ self::class, 'sc_lead_form'   ] );
    }

    public static function sc_home(): string {
        ob_start();
        require GS_DIR . 'templates/pages/home.php';
        return ob_get_clean();
    }

    public static function sc_directory(): string {
        ob_start();
        require GS_DIR . 'templates/pages/archive.php';
        return ob_get_clean();
    }

    public static function sc_login(): string {
        ob_start();
        require GS_DIR . 'templates/pages/auth-login.php';
        return ob_get_clean();
    }

    public static function sc_register(): string {
        ob_start();
        require GS_DIR . 'templates/pages/auth-register.php';
        return ob_get_clean();
    }

    public static function sc_vendor_dash(): string {
        ob_start();
        require GS_DIR . 'templates/pages/vendor-dashboard.php';
        return ob_get_clean();
    }

    public static function sc_search_bar(): string {
        ob_start();
        $cats = ( new CategoryRepository() )->get_all_active();
        require GS_DIR . 'templates/partials/search-bar.php';
        return ob_get_clean();
    }

    public static function sc_categories(): string {
        ob_start();
        $cats = ( new CategoryRepository() )->get_all_active();
        require GS_DIR . 'templates/partials/categories-grid.php';
        return ob_get_clean();
    }

    public static function sc_featured(): string {
        ob_start();
        $listings = ( new ListingRepository() )->get_featured( 8 );
        require GS_DIR . 'templates/partials/featured-listings.php';
        return ob_get_clean();
    }

    public static function sc_lead_form(): string {
        ob_start();
        require GS_DIR . 'templates/partials/lead-form.php';
        return ob_get_clean();
    }
}
