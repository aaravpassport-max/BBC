<?php
namespace GoodService\Controller;

use GoodService\Core\Roles;
use GoodService\Repository\ListingRepository;

class ListingController extends BaseController {

    public function show(): void {
        $slug    = sanitize_text_field( get_query_var( 'gs_slug', '' ) );
        $repo    = new ListingRepository();
        $listing = $repo->get_by_slug( $slug );
        $this->view( 'listing-detail', compact( 'listing', 'repo' ) );
    }

    public function create(): void {
        if ( ! is_user_logged_in() ) {
            $this->redirect( home_url( '/vendor/login/?redirect=' . urlencode( $_SERVER['REQUEST_URI'] ?? '' ) ) );
        }
        if ( ! Roles::can_create_listings() ) {
            $this->redirect( home_url( '/vendor/register/' ) );
        }
        $listing_id = (int) get_query_var( 'gs_listing_id', 0 );
        $listing    = $listing_id ? ( new ListingRepository() )->find( $listing_id ) : null;
        $this->view( 'create-listing', compact( 'listing', 'listing_id' ) );
    }
}