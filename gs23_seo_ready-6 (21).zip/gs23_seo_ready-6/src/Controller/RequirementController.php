<?php
namespace GoodService\Controller;

class RequirementController extends BaseController {

    public function show(): void {
        global $wpdb;
        $req_id = (int) get_query_var( 'gs_requirement_id', 0 );
        $req    = $req_id ? $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_requirements WHERE id = %d", $req_id
        ) ) : null;
        $this->view( 'requirement-detail', compact( 'req', 'req_id' ) );
    }
}
