<?php
namespace GoodService\Repository;

use GoodService\Core\Cache;

class VendorRepository extends BaseRepository {

    protected function table_name(): string { return 'vendor_profiles'; }

    public static function get_by_user( int $user_id ): ?\stdClass {
        if ( ! $user_id ) { return null; }
        try {
            global $wpdb;
            return Cache::remember( "vendor:user:{$user_id}", function() use ( $wpdb, $user_id ) {
                if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_vendor_profiles'" ) ) {
                    return null;
                }
                return $wpdb->get_row( $wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}gs_vendor_profiles WHERE user_id = %d", $user_id
                ) ) ?: null;
            }, 60 );
        } catch ( \Throwable $e ) {
            return null;
        }
    }

    /**
     * ENTERPRISE-AUDIT FIX (Part 3, Low-Medium: Quick Replies per-staff
     * visibility control) — a staff-aware variant of get_by_user(), added
     * as a NEW opt-in method rather than changing get_by_user() itself.
     * get_by_user() is called directly, unaudited, from ~15+ ownership-
     * verification call sites in AjaxController (e.g. "reject unless
     * $vp->user_id === get_current_user_id()" on account-deletion/business-
     * profile actions) where silently returning the OWNER's row for a
     * STAFF caller would be a real, wrong-actor security regression, not a
     * fix. Callers that genuinely want "the vendor context this user acts
     * within, whether owner or team member" (Quick Replies' visibility
     * filtering is exactly that) should call this instead of get_by_user().
     * Falls back to the vendor's own row if the caller IS the owner (same
     * as get_by_user()); otherwise resolves via an active gs_vendor_staff
     * membership. Returns null for neither.
     */
    public static function get_by_user_or_staff( int $user_id ): ?\stdClass {
        $vp = self::get_by_user( $user_id );
        if ( $vp ) { return $vp; }
        if ( ! $user_id ) { return null; }
        global $wpdb;
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_vendor_staff'" ) ) { return null; }
        $staff_vendor_id = $wpdb->get_var( $wpdb->prepare(
            "SELECT vendor_id FROM {$wpdb->prefix}gs_vendor_staff WHERE user_id = %d AND is_active = 1 LIMIT 1",
            $user_id
        ) );
        return $staff_vendor_id ? self::get_by_id( (int) $staff_vendor_id ) : null;
    }

    /**
     * Companion to get_by_user_or_staff(): returns the calling user's
     * gs_vendor_staff.role ('manager'|'staff'|'viewer') when they reach a
     * vendor context via team membership, or null when they ARE the owner
     * (an owner has no role restriction) or aren't vendor staff at all.
     * Mirrors the exact lookup AjaxController::enforce_viewer_role_restriction()/
     * enforce_manager_only_restriction() already use, so "is this caller
     * staff, and what can they see/do" stays answered the same way
     * everywhere it's asked.
     */
    public static function staff_role_for_user( int $user_id ): ?string {
        if ( ! $user_id || self::get_by_user( $user_id ) ) { return null; } // owner: no restriction
        global $wpdb;
        $role = $wpdb->get_var( $wpdb->prepare(
            "SELECT role FROM {$wpdb->prefix}gs_vendor_staff WHERE user_id=%d AND is_active=1 ORDER BY FIELD(role,'manager','staff','viewer') ASC LIMIT 1",
            $user_id
        ) );
        return $role ?: null;
    }

    public static function get_by_id( int $vendor_id ): ?\stdClass {
        global $wpdb;
        return Cache::remember( "vendor:id:{$vendor_id}", function() use ( $wpdb, $vendor_id ) {
            return $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $vendor_id
            ) ) ?: null;
        }, 600 );
    }

    public static function get_by_slug( string $slug ): ?\stdClass {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT vp.*, u.display_name, u.user_email
             FROM {$wpdb->prefix}gs_vendor_profiles vp
             JOIN {$wpdb->prefix}users u ON u.ID = vp.user_id
             WHERE vp.slug = %s", $slug
        ) ) ?: null;
    }

    public static function save( array $data, int $user_id ): int|false {
        global $wpdb;
        $table    = $wpdb->prefix . 'gs_vendor_profiles';
        $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE user_id = %d", $user_id ) );

        // M8 whitelist — built by cross-checking every real caller of this method
        // (saveVendorProfile() and registerVendor() in AjaxController) so no
        // legitimate field silently drops. Two columns are deliberately excluded:
        //   verification_status — must ONLY change via the admin verifyVendor()
        //     endpoint (operations-level, gated); a vendor self-verifying their own
        //     account through this method would defeat that control entirely.
        //   user_id / created_at / id — ownership and audit fields; this is the
        //     actual vulnerability this whitelist exists to close (a caller
        //     forwarding raw $_POST could otherwise overwrite account ownership).
        $allowed_columns = [
            'business_name','slug','tagline','short_bio','bio','logo_url','banner_url','cover_url',
            'phone','whatsapp','email','website','city','state','pincode','address',
            'gst_number','pan_number','lat','lng',
            'service_area','response_rate','response_time','avg_reply_minutes','total_jobs_done',
            'total_listings','total_leads',
            'neighbourhood_count','neighbourhood_area','avg_rating','trust_score',
            'social_links','verification_docs','profile_data',
            'neighbourhood_lat','neighbourhood_lng','is_online','is_active',
            'updated_at','notes',
        ];
        $data = array_intersect_key( $data, array_flip( $allowed_columns ) );

        $json_fields = [ 'social_links', 'verification_docs', 'profile_data' ];
        foreach ( $json_fields as $f ) {
            if ( isset( $data[$f] ) && is_array( $data[$f] ) ) $data[$f] = wp_json_encode( $data[$f] );
        }
        if ( $existing ) {
            $data['updated_at'] = current_time( 'mysql' );
            $wpdb->update( $table, $data, [ 'user_id' => $user_id ] );
            Cache::delete( "vendor:user:{$user_id}" );
            Cache::delete( "vendor:id:{$existing}" );
            return (int) $existing;
        }
        $data['user_id']    = $user_id;
        $data['created_at'] = current_time( 'mysql' );
        $wpdb->insert( $table, $data );
        Cache::delete( "vendor:user:{$user_id}" );
        return $wpdb->insert_id ?: false;
    }

    /** Admin vendor list with subscription info */
    public static function admin_list( array $args = [] ): array {
        global $wpdb;
        $search   = sanitize_text_field( $args['search']   ?? '' );
        $status   = sanitize_text_field( $args['status']   ?? '' );
        $verify   = sanitize_text_field( $args['verify']   ?? '' );
        $page     = max( 1, (int) ( $args['page'] ?? 1 ) );
        $per_page = (int) ( $args['per_page'] ?? 20 );
        $offset   = ( $page - 1 ) * $per_page;

        $where = [ '1=1' ];
        $params = [];
        if ( $search ) {
            $like = '%' . $wpdb->esc_like( $search ) . '%';
            $where[] = '(vp.business_name LIKE %s OR vp.email LIKE %s OR vp.phone LIKE %s)';
            array_push( $params, $like, $like, $like );
        }
        if ( $status !== '' ) { $where[] = 'vp.is_active = %d'; $params[] = (int)$status; }
        if ( $verify ) { $where[] = 'vp.verification_status = %s'; $params[] = $verify; }

        $w = implode( ' AND ', $where );
        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gs_vendor_profiles vp WHERE {$w}", ...$params
        ) );
        // FIXED (same root cause found and proven via live-DB reproduction in
        // ManualPlanService::search_vendors() — see the comment there): this
        // INNER JOIN to {$wpdb->prefix}users silently drops any vendor whose
        // profile row's user_id no longer resolves to a real WP user (an
        // "orphaned" profile — a condition this codebase's own
        // DiagnosticsEngine.php already documents as real and occurring, with
        // its own cleanup query). That vendor would be invisible not just to
        // Manual Plan search but to this whole admin Vendors list and its
        // total count. Changed to LEFT JOIN + COALESCE so an orphaned vendor
        // still shows up (with its own vp.email as fallback) instead of
        // silently vanishing — an admin needs to see it in order to fix it.
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT vp.*, u.display_name, COALESCE(u.user_email, vp.email) AS user_email, u.user_registered,
                    (SELECT COUNT(*) FROM {$wpdb->prefix}gs_listings l WHERE l.vendor_id = vp.id AND l.status='active') AS active_listings,
                    sub.plan_name, sub.status AS sub_status, sub.expires_at AS sub_expires
             FROM {$wpdb->prefix}gs_vendor_profiles vp
             LEFT JOIN {$wpdb->prefix}users u ON u.ID = vp.user_id
             LEFT JOIN {$wpdb->prefix}gs_subscriptions sub ON sub.id = (
                    SELECT id FROM {$wpdb->prefix}gs_subscriptions
                    WHERE vendor_id = vp.id AND status IN ('active','trialing')
                    ORDER BY created_at DESC LIMIT 1
                )
             WHERE {$w} ORDER BY vp.created_at DESC LIMIT %d OFFSET %d",
            ...array_merge( $params, [ $per_page, $offset ] )
        ) );
        return [ 'vendors' => $rows ?: [], 'total' => $total, 'page' => $page, 'last_page' => (int) ceil( $total / $per_page ) ];
    }

    public static function calculate_trust_score( int $user_id ): int {
        global $wpdb;
        $vp = self::get_by_user( $user_id );
        if ( ! $vp ) return 0;
        $score = 0;
        if ( $vp->business_name ) $score += 10;
        if ( $vp->phone )         $score += 10;
        if ( $vp->email )         $score += 5;
        if ( $vp->bio )           $score += 10;
        if ( $vp->logo_url )      $score += 10;
        if ( $vp->address )       $score += 5;
        if ( $vp->website )       $score += 5;
        if ( $vp->verification_status === 'verified' ) $score += 30;
        $listing_count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gs_listings WHERE vendor_id = %d AND status = 'active'", $vp->id
        ) );
        $score += min( 15, $listing_count * 5 );
        return min( 100, $score );
    }
}
