<?php
namespace GoodService\Repository;

abstract class BaseRepository {

    protected string $table;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'gs_' . $this->table_name();
    }

    abstract protected function table_name(): string;

    public function find( int $id ): ?\stdClass {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d", $id )
        ) ?: null;
    }

    public function delete( int $id ): bool {
        global $wpdb;
        return (bool) $wpdb->delete( $this->table, [ 'id' => $id ] );
    }

    public function count( string $where = '1=1', array $params = [] ): int {
        global $wpdb;
        if ( $params ) {
            return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->table} WHERE {$where}", ...$params ) );
        }
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table} WHERE {$where}" );
    }
}
