<?php
namespace GoodService\Repository;

use GoodService\Core\Cache;

class ReviewRepository extends BaseRepository {

    protected function table_name(): string { return 'reviews'; }

    public function get_listing_reviews( int $listing_id, string $status = 'approved' ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_reviews
             WHERE listing_id = %d AND status = %s ORDER BY created_at DESC",
            $listing_id, $status
        ) ) ?: [];
    }

    public function get_vendor_reviews( int $vendor_id, array $args = [] ): array {
        global $wpdb;
        $status = sanitize_text_field( $args['status'] ?? '' );
        $w = $status ? $wpdb->prepare( 'AND r.status = %s', $status ) : '';
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT r.*, l.title AS listing_title
             FROM {$wpdb->prefix}gs_reviews r
             LEFT JOIN {$wpdb->prefix}gs_listings l ON l.id = r.listing_id
             WHERE r.vendor_id = %d {$w} ORDER BY r.created_at DESC", $vendor_id
        ) ) ?: [];
    }

    public function recalculate_listing( int $listing_id ): void {
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->prefix}gs_listings l SET
                l.avg_rating    = COALESCE((SELECT ROUND(AVG(r.rating),2) FROM {$wpdb->prefix}gs_reviews r WHERE r.listing_id=%d AND r.status='approved'),0),
                l.review_count  = (SELECT COUNT(*) FROM {$wpdb->prefix}gs_reviews r WHERE r.listing_id=%d AND r.status='approved')
             WHERE l.id = %d",
            $listing_id, $listing_id, $listing_id
        ) );
        $this->recalculate_ranking_score( $listing_id );
        // NOTE: "listing:id:{id}" is not a key any reader ever caches under —
        // the real public-facing caches are listing:slug:{slug}, listings:featured:*,
        // listings:related:*, and listings:cities. Flushing the group is what
        // actually invalidates the avg_rating/review_count shown on listing pages.
        Cache::delete( "listing:id:{$listing_id}" );
        Cache::flush_group( 'listings' );
    }

    /**
     * Composite ranking score — real, research-backed formula, NOT an
     * arbitrary number. Combines:
     *
     * 1. Bayesian-adjusted rating: BR = (C×m + n×avg_rating) / (C+n)
     *    Confirmed via research this round as the standard, IMDB-style
     *    fix for the exact problem found in the existing default sort —
     *    one 5-star review currently outranks 200 reviews averaging 4.8.
     *    C=10, m=3.5 are deliberately fixed, documented constants rather
     *    than self-calculated from platform data — this platform has too
     *    few real reviews right now for a self-calculated confidence
     *    number to be meaningful; revisit once there's real volume.
     *
     * 2. Freshness factor: exponential decay based on days since
     *    updated_at, 90-day half-life. Confirmed via research as a real,
     *    separate concern — without this, established listings with
     *    years of accumulated reviews permanently dominate regardless of
     *    whether they're still actually active/current.
     *
     * 3. Featured/verified boost: reuses the existing, already-meaningful
     *    is_featured and is_verified columns rather than inventing a
     *    parallel signal.
     *
     * Calculated here (the one, established place avg_rating/review_count
     * already get refreshed) and stored in the real ranking_score column,
     * rather than computed per-row at query time — the keyset pagination
     * system built earlier needs a real, persisted, indexable column to
     * sort on efficiently at scale; a per-row computed value would defeat
     * the entire purpose of that system.
     */
    public function recalculate_ranking_score( int $listing_id ): void {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT l.avg_rating, l.review_count, l.is_featured, l.is_verified,
                    GREATEST(0, DATEDIFF(NOW(), COALESCE(
                        (SELECT MAX(r.created_at) FROM {$wpdb->prefix}gs_reviews r WHERE r.listing_id = l.id AND r.status = 'approved'),
                        l.created_at
                    ))) AS days_since_last_review
             FROM {$wpdb->prefix}gs_listings l WHERE l.id = %d", $listing_id
        ) );
        if ( ! $row ) { return; }

        $C = 10;    // confidence number — see class doc above for why this is a fixed constant right now
        $m = 3.5;   // assumed platform-wide average rating — same reasoning

        $n = (int) $row->review_count;
        $bayesian = ( $C * $m + $n * (float) $row->avg_rating ) / ( $C + $n );

        // Exponential decay based on REVIEW recency, not profile-edit
        // recency — confirmed via research this round: review
        // velocity/recency is the real, documented signal (a business
        // still earning fresh reviews vs. one that's gone quiet), not
        // whether the listing TEXT was recently edited. An accurate,
        // unedited listing for a real, currently-operating business
        // should not be penalized just because nothing needed changing.
        // 270-day (9-month) half-life — confirmed via direct testing that
        // a 90-day half-life (calibrated for blog/content freshness, a
        // very different cadence) produced an unrealistic, overly
        // punishing result for a real local service business, which
        // doesn't realistically earn a new review every few weeks the
        // way a blog needs new posts.
        $freshness = pow( 0.5, (float) $row->days_since_last_review / 270 );

        $boost = 1.0 + ( $row->is_featured ? 0.15 : 0 ) + ( $row->is_verified ? 0.10 : 0 );

        $score = $bayesian * $freshness * $boost;

        $wpdb->update(
            "{$wpdb->prefix}gs_listings",
            [ 'ranking_score' => round( $score, 4 ) ],
            [ 'id' => $listing_id ]
        );
    }
}
