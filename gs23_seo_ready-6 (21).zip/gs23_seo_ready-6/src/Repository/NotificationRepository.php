<?php
namespace GoodService\Repository;

class NotificationRepository extends BaseRepository {

    protected function table_name(): string { return 'notifications'; }

    public function get_for_user( int $user_id, int $limit = 20 ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_notifications
             WHERE user_id = %d ORDER BY created_at DESC LIMIT %d",
            $user_id, $limit
        ) ) ?: [];
    }

    public function unread_count( int $user_id ): int {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gs_notifications
             WHERE user_id = %d AND is_read = 0", $user_id
        ) );
    }

    public function mark_read( int $id, int $user_id ): void {
        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'gs_notifications',
            [ 'is_read' => 1 ],
            [ 'id' => $id, 'user_id' => $user_id ]
        );
    }

    public function mark_all_read( int $user_id ): void {
        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'gs_notifications',
            [ 'is_read' => 1 ],
            [ 'user_id' => $user_id ]
        );
    }
}
