<?php
namespace GoodService\Repository;

use GoodService\Core\Cache;

/**
 * ListingRepository — All listing data access.
 * Replaces WP_Query + post meta with optimized custom SQL.
 *
 * Performance improvements (v22):
 *  • search()         — results cached with short TTL (120 s / 60 s)
 *  • get_by_vendor()  — cached (120 s, invalidated on listing save)
 *  • get_related()    — cached (600 s)
 *  • increment_views()— writes deferred to shutdown hook; no DB hit on the
 *                       critical render path; accumulated per request and
 *                       flushed as a single UPDATE per listing at the end.
 */
class ListingRepository extends BaseRepository {

    protected function table_name(): string { return 'listings'; }

    // ── Deferred view-count buffers ───────────────────────────────────────────
    private static array $pending_views              = [];
    private static bool  $views_shutdown_registered  = false;


    // =========================================================================
    // Search / Browse
    // =========================================================================

    /** Full-text + filtered search — the main directory query */
    public function search( array $args = [] ): array {
        global $wpdb;

        $keyword  = sanitize_text_field( $args['keyword']  ?? '' );
        $city     = sanitize_text_field( $args['city']     ?? '' );
        $category = (int) ( $args['category'] ?? 0 );
        $type     = sanitize_text_field( $args['type']     ?? '' );
        $sort     = sanitize_text_field( $args['sort']     ?? 'featured' );
        $page     = max( 1, (int) ( $args['page']     ?? 1 ) );
        $per_page = min( 60, max( 1, (int) ( $args['per_page'] ?? 12 ) ) );
        $offset   = ( $page - 1 ) * $per_page;
        $status   = $args['status'] ?? 'active';

        // ── Cache layer: cache search results to avoid repeated COUNT + SELECT ─
        // TTL is shorter with a keyword (results more specific, invalidation less
        // critical) and longer for pure browse queries (category/city filters).
        // Any listing save calls Cache::flush_group('listings') which bumps the
        // version counter and makes all 'listings:search:*' keys unreachable.
        $cache_args = compact( 'keyword', 'city', 'category', 'type', 'sort',
                                'page', 'per_page', 'status' );
        ksort( $cache_args );
        $cache_key = 'listings:search:' . md5( serialize( $cache_args ) );
        $cache_ttl = $keyword ? 60 : 120; // seconds

        $cached = Cache::get( $cache_key );
        if ( $cached !== null ) {
            return $cached;
        }

        // ── Build query ────────────────────────────────────────────────────────
        $where     = [ 'l.status = %s' ];
        $params    = [ $status ];
        $join      = '';
        $select    = 'l.*, c.name AS category_name, c.icon_emoji AS category_icon, c.color AS category_color';
        $relevance = '';

        if ( $keyword ) {
            $like      = '%' . $wpdb->esc_like( $keyword ) . '%';
            $relevance = ", MATCH(l.title, l.tagline, l.short_desc, l.tags, l.city) AGAINST (%s IN BOOLEAN MODE) AS relevance_score";
            $params[]  = $keyword . '*';
            $where[]   = "(MATCH(l.title,l.tagline,l.short_desc,l.tags,l.city) AGAINST (%s IN BOOLEAN MODE)
                          OR l.title LIKE %s OR l.tags LIKE %s OR l.city LIKE %s)";
            $params[]  = $keyword . '*';
            $params[]  = $like;
            $params[]  = $like;
            $params[]  = $like;
        }

        if ( $city ) {
            // City filter: l.city direct match always included (uses idx_city).
            // Join table gives service-city coverage on top when available and populated.
            $lc_tbl = $wpdb->prefix . 'gs_listing_cities';
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$lc_tbl}'" ) ) {
                $where[]  = "(l.city = %s OR EXISTS (SELECT 1 FROM {$lc_tbl} lc WHERE lc.listing_id = l.id AND lc.city = %s))";
                $params[] = $city;
                $params[] = $city;
            } else {
                $where[]  = '(l.city = %s OR l.service_cities LIKE %s)';
                $params[] = $city;
                $params[] = '%' . $wpdb->esc_like( $city ) . '%';
            }
        }

        if ( $category ) {
            // Real fix — same root cause found and fixed in archive.php's
            // initial render and in AjaxController::directoryFilter(): a
            // listing's category_id is set to the SUBCATEGORY the vendor
            // picked, never to the parent's own id, whenever that parent
            // category actually has subcategories (create-listing.php's
            // cl-category-sub select). The OR l.subcategory_id = %d half of
            // this clause never helped with that — subcategory_id is a
            // schema column that exists but is never actually populated by
            // the real save path (dead column) — so a caller passing a
            // parent category id here (this shared method backs BOTH the
            // gs_search_listings and gs_enh_search_listings AJAX actions)
            // matched zero rows for any parent with children. Rolls the
            // filter up to the parent OR any of its direct children — a
            // no-op for an already-precise subcategory id, which has no
            // children of its own.
            $category_ids = [ $category ];
            $pfx_cat      = $wpdb->prefix . 'gs_';
            $cur_cat_row  = $wpdb->get_row( $wpdb->prepare( "SELECT parent_id FROM {$pfx_cat}categories WHERE id=%d", $category ) );
            if ( $cur_cat_row && (int) ( $cur_cat_row->parent_id ?? 0 ) === 0 ) {
                $sub_ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$pfx_cat}categories WHERE parent_id=%d", $category ) );
                if ( $sub_ids ) { $category_ids = array_merge( $category_ids, array_map( 'intval', $sub_ids ) ); }
            }
            $where[]  = '(l.category_id IN (' . implode( ',', array_fill( 0, count( $category_ids ), '%d' ) ) . ') OR l.subcategory_id = %d)';
            array_push( $params, ...$category_ids );
            $params[] = $category;
        }

        if ( $type && in_array( $type, [ 'service', 'product', 'both' ], true ) ) {
            $where[]  = 'l.listing_type = %s';
            $params[] = $type;
        }

        $join      .= " LEFT JOIN {$wpdb->prefix}gs_categories c ON c.id = l.category_id";
        $where_sql  = implode( ' AND ', $where );

        $order = match ( $sort ) {
            'rating'   => 'l.avg_rating DESC, l.review_count DESC',
            'newest'   => 'l.created_at DESC',
            'views'    => 'l.views_count DESC',
            'leads'    => 'l.leads_count DESC',
            'price_lo' => 'l.price_min ASC',
            'price_hi' => 'l.price_min DESC',
            default    => ( $keyword ? 'relevance_score DESC, ' : '' )
                          . 'l.is_featured DESC, l.avg_rating DESC, l.views_count DESC',
        };

        $total = (int) $wpdb->get_var(
            $wpdb->prepare( "SELECT COUNT(*) FROM {$this->table} l{$join} WHERE {$where_sql}", ...$params )
        );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT {$select}{$relevance} FROM {$this->table} l{$join} WHERE {$where_sql}
                 ORDER BY {$order} LIMIT %d OFFSET %d",
                ...array_merge( $params, [ $per_page, $offset ] )
            )
        );

        $result = [
            'listings'  => $rows ?: [],
            'total'     => $total,
            'page'      => $page,
            'per_page'  => $per_page,
            'last_page' => (int) ceil( $total / $per_page ),
            'keyword'   => $keyword,
            'city'      => $city,
            'category'  => $category,
            'sort'      => $sort,
        ];

        Cache::set( $cache_key, $result, $cache_ttl );
        return $result;
    }

    /** Get single listing by slug with full joins */
    public function get_by_slug( string $slug ): ?\stdClass {
        global $wpdb;
        return Cache::remember( "listing:slug:{$slug}", function () use ( $wpdb, $slug ) {
            return $wpdb->get_row( $wpdb->prepare(
                "SELECT l.*, c.name AS category_name, c.icon_emoji AS category_icon, c.color AS category_color,
                        vp.business_name, vp.slug AS vendor_slug, vp.user_id AS vendor_user_id,
                        vp.logo_url AS vendor_logo, vp.verification_status, vp.trust_score,
                        vp.avg_rating AS vendor_rating, vp.total_leads AS vendor_leads,
                        vp.phone AS vendor_phone, vp.whatsapp AS vendor_wa,
                        vp.bio AS vendor_bio, vp.city AS vendor_city, vp.state AS vendor_state
                 FROM {$wpdb->prefix}gs_listings l
                 LEFT JOIN {$wpdb->prefix}gs_categories c  ON c.id  = l.category_id
                 LEFT JOIN {$wpdb->prefix}gs_vendor_profiles vp ON vp.id = l.vendor_id
                 WHERE l.slug = %s AND l.status IN('active','pending')", $slug
            ) ) ?: null;
        }, 300 );
    }

    /** Get listings by vendor — cached, invalidated on listing save */
    public function get_by_vendor( int $vendor_id, string $status = '' ): array {
        global $wpdb;
        $cache_key = "listings:vendor:{$vendor_id}:" . ( $status ?: 'all' );
        return Cache::remember( $cache_key, function () use ( $wpdb, $vendor_id, $status ) {
            $status_sql = $status ? $wpdb->prepare( 'AND status = %s', $status ) : '';
            return $wpdb->get_results( $wpdb->prepare(
                "SELECT l.*, c.name AS category_name
                 FROM {$wpdb->prefix}gs_listings l
                 LEFT JOIN {$wpdb->prefix}gs_categories c ON c.id = l.category_id
                 WHERE l.vendor_id = %d {$status_sql} ORDER BY l.created_at DESC",
                $vendor_id
            ) ) ?: [];
        }, 120 );
    }

    /**
     * Increment the view counter for a listing.
     *
     * PERFORMANCE CHANGE (v22):
     * Instead of issuing an UPDATE on every page view (high-frequency DB write
     * on the critical render path), we accumulate counts in a static array and
     * flush them to the database at WordPress shutdown — after the response has
     * already been sent in many server configurations (FastCGI / PHP-FPM).
     *
     * If a single request somehow views the same listing N times, the count is
     * still correct (we track per-listing accumulations, not just flags).
     */
    public function increment_views( int $listing_id ): void {
        // Accumulate count in memory
        if ( ! isset( self::$pending_views[ $listing_id ] ) ) {
            self::$pending_views[ $listing_id ] = 0;
        }
        self::$pending_views[ $listing_id ]++;

        // Register the shutdown flush exactly once
        if ( ! self::$views_shutdown_registered ) {
            self::$views_shutdown_registered = true;
            add_action( 'shutdown', [ self::class, '_flush_pending_views' ], 99 );
        }

        // NOTE: no cache group flush here on purpose. "listing:id:{id}" is not
        // a key any reader caches under (real caches are listing:slug:{slug},
        // listings:featured:*, listings:related:*) — flushing the whole
        // 'listings' group on every single page view, high-frequency by
        // definition, would cause a cache stampede and defeat the entire
        // point of the shutdown-batched write above. Displayed view counts
        // may lag by up to the cache TTL until another mutation (edit,
        // review, status change) naturally flushes the group; this is an
        // accepted, deliberate trade-off, not a bug.
    }

    /**
     * @internal Called by WordPress 'shutdown' action. Do not call directly.
     * Flushes all accumulated view-count increments to the database in one pass.
     */
    public static function _flush_pending_views(): void {
        if ( empty( self::$pending_views ) ) { return; }
        global $wpdb;
        foreach ( self::$pending_views as $lid => $count ) {
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->prefix}gs_listings
                 SET views_count = views_count + %d WHERE id = %d",
                $count, (int) $lid
            ) );
        }
        self::$pending_views = [];
    }

    /** Featured listings for homepage */
    public function get_featured( int $limit = 8, string $city = '' ): array {
        global $wpdb;
        $city_sql = $city ? $wpdb->prepare( 'AND l.city = %s', $city ) : '';
        return Cache::remember( "listings:featured:{$limit}:{$city}", function () use ( $wpdb, $limit, $city_sql ) {
            return $wpdb->get_results( $wpdb->prepare(
                "SELECT l.*, c.name AS category_name, c.icon_emoji AS category_icon
                 FROM {$wpdb->prefix}gs_listings l
                 LEFT JOIN {$wpdb->prefix}gs_categories c ON c.id = l.category_id
                 WHERE l.status = 'active' AND l.is_featured = 1 {$city_sql}
                 ORDER BY l.avg_rating DESC, l.views_count DESC LIMIT %d",
                $limit
            ) ) ?: [];
        }, 600 );
    }

    /** Get related listings (same category) — cached per listing */
    public function get_related( int $listing_id, int $category_id, int $limit = 4 ): array {
        global $wpdb;
        return Cache::remember( "listings:related:{$listing_id}:{$category_id}:{$limit}", function () use ( $wpdb, $listing_id, $category_id, $limit ) {
            return $wpdb->get_results( $wpdb->prepare(
                "SELECT l.*, c.name AS category_name
                 FROM {$wpdb->prefix}gs_listings l
                 LEFT JOIN {$wpdb->prefix}gs_categories c ON c.id = l.category_id
                 WHERE l.category_id = %d AND l.id != %d AND l.status = 'active'
                 ORDER BY l.avg_rating DESC LIMIT %d",
                $category_id, $listing_id, $limit
            ) ) ?: [];
        }, 600 );
    }

    /** Admin listing list with vendor info */
    public function admin_list( array $args = [] ): array {
        global $wpdb;
        $status   = sanitize_text_field( $args['status']   ?? '' );
        $search   = sanitize_text_field( $args['search']   ?? '' );
        $page     = max( 1, (int) ( $args['page']     ?? 1 ) );
        $per_page = (int) ( $args['per_page'] ?? 20 );
        $offset   = ( $page - 1 ) * $per_page;

        $where  = [ '1=1' ];
        $params = [];

        if ( $status ) { $where[] = 'l.status = %s'; $params[] = $status; }
        if ( $search ) {
            $like    = '%' . $wpdb->esc_like( $search ) . '%';
            $where[] = '(l.title LIKE %s OR l.city LIKE %s OR vp.business_name LIKE %s)';
            array_push( $params, $like, $like, $like );
        }

        $where_sql = implode( ' AND ', $where );
        $total     = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gs_listings l
             LEFT JOIN {$wpdb->prefix}gs_vendor_profiles vp ON vp.id = l.vendor_id
             WHERE {$where_sql}", ...$params
        ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT l.*, vp.business_name, vp.verification_status, c.name AS category_name
             FROM {$wpdb->prefix}gs_listings l
             LEFT JOIN {$wpdb->prefix}gs_vendor_profiles vp ON vp.id = l.vendor_id
             LEFT JOIN {$wpdb->prefix}gs_categories c ON c.id = l.category_id
             WHERE {$where_sql} ORDER BY l.created_at DESC LIMIT %d OFFSET %d",
            ...array_merge( $params, [ $per_page, $offset ] )
        ) );

        return [
            'listings'  => $rows ?: [],
            'total'     => $total,
            'page'      => $page,
            'last_page' => (int) ceil( $total / $per_page ),
        ];
    }

    /** Save or update a listing — FIXED v7.1 */
    public function save( array $data, int $id = 0 ): int|false {
        global $wpdb;
        $table = $wpdb->prefix . 'gs_listings';
        $diag  = class_exists( '\\GoodService\\Core\\GSDiagnostics' )
                    && \GoodService\Core\GSDiagnostics::enabled();

        // ── JSON-encode any array values ──────────────────────────────────────
        $json_fields = [
            'gallery', 'services_data', 'products_data', 'process_data', 'faq_data',
            'why_choose_data', 'stats_data', 'highlights', 'service_cities', 'opening_hours',
            'form_data', 'hero_data', 'about_data', 'items_data', 'feedback_data', 'footer_data',
            'customizer_data', 'mobile_data',
        ];
        foreach ( $json_fields as $f ) {
            if ( isset( $data[ $f ] ) && is_array( $data[ $f ] ) ) {
                $data[ $f ] = wp_json_encode( $data[ $f ] );
            }
        }

        // ── Strip columns that don't exist yet in the DB ──────────────────────
        // PERF FIX #2: SHOW COLUMNS is now cached for 24 hours keyed by GS_VERSION.
        // Previously this issued an uncached SHOW COLUMNS query on every single
        // listing save, which is a heavyweight schema-introspection operation.
        // Real hardening: TTL reduced from 24 hours to 10 minutes — the only
        // thing that invalidates this cache is a GS_VERSION change, and a
        // schema column added without a version bump could otherwise be
        // silently stripped from every save for up to a full day.
        $cache_key = 'schema:cols:listings:' . ( defined( 'GS_VERSION' ) ? GS_VERSION : '0' );
        $db_cols   = Cache::get( $cache_key );
        // Real fix — a transient DB hiccup (lock timeout, a mid-migration
        // ALTER TABLE, a permissions blip) can make SHOW COLUMNS return an
        // empty or suspiciously small result. Previously that got cached
        // for 10 minutes and used as-is: every save in that window would
        // then see almost every real column as "not in the DB" and silently
        // strip it from $data before the UPDATE/INSERT ever ran — on a
        // brand-new listing (INSERT path, no existing row to fall back on)
        // that is a genuine, silent, whole-listing data-loss window, not
        // just a "missed one new column" inconvenience. A real
        // gs_listings table always has dozens of columns (id, vendor_id,
        // title, slug, status, ... — every field this repository writes),
        // so fewer than 20 columns coming back is never a legitimate
        // schema, only a failed introspection query — treat that as a
        // hard failure instead of trusting and caching it.
        if ( $db_cols === null || ( is_array( $db_cols ) && count( $db_cols ) < 20 ) ) {
            $fresh = $wpdb->get_col( "SHOW COLUMNS FROM `{$table}`", 0 ) ?: [];
            if ( count( $fresh ) < 20 ) {
                // Introspection itself looks broken right now — never cache
                // this, and never strip a single column based on it. Saving
                // with every submitted column intact (and letting the real
                // $wpdb->update()/insert() fail loudly with a DB error if a
                // column genuinely doesn't exist) is safer than silently
                // discarding real vendor data.
                if ( function_exists( 'gs_write_log' ) ) {
                    gs_write_log( '[save_listing] SHOW COLUMNS returned only ' . count( $fresh )
                        . ' columns for `' . $table . '` — treating as a failed schema check, not stripping any fields this save.' );
                }
                $db_cols = null;
            } else {
                $db_cols = $fresh;
                Cache::set( $cache_key, $db_cols, 600 ); // cache 10 minutes, not 24 hours
            }
        }
        $stripped = [];
        if ( $db_cols !== null ) {
            foreach ( array_keys( $data ) as $col ) {
                if ( $col !== 'id' && ! in_array( $col, $db_cols, true ) ) {
                    $stripped[] = $col;
                    unset( $data[ $col ] );
                }
            }
        }
        if ( $stripped ) {
            if ( function_exists( 'gs_write_log' ) ) {
                gs_write_log( '[save_listing] Stripped missing columns: ' . implode( ', ', $stripped )
                    . ' — run Admin › Tools › DB Upgrade' );
            }
            if ( $diag ) {
                \GoodService\Core\GSDiagnostics::warn(
                    'ListingRepository::save',
                    'Stripped ' . count( $stripped ) . ' missing DB columns — run DB Upgrade',
                    [ 'missing' => $stripped, 'id' => $id ]
                );
            }
            update_option( 'gs_missing_cols_warning', [
                'cols' => $stripped, 'id' => $id, 'time' => current_time( 'mysql' ),
            ] );
        }

        if ( $id ) {
            $data['updated_at'] = current_time( 'mysql' );

            $current = $wpdb->get_row( $wpdb->prepare(
                "SELECT slug FROM {$table} WHERE id = %d", $id
            ) );

            if ( $diag ) {
                \GoodService\Core\GSDiagnostics::log(
                    'ListingRepo::save',
                    "UPDATE id={$id} title=" . ( $data['title'] ?? '?' ),
                    [ 'keys' => array_keys( $data ) ]
                );
            }

            $result = $wpdb->update( $table, $data, [ 'id' => $id ] );
            if ( $result === false ) {
                $err = $wpdb->last_error;
                if ( function_exists( 'gs_write_log' ) ) {
                    gs_write_log( "[save_listing] UPDATE FAILED id={$id} — {$err}" );
                }
                if ( $diag ) {
                    \GoodService\Core\GSDiagnostics::error(
                        'ListingRepo::save',
                        "UPDATE FAILED id={$id}",
                        [ 'db_error' => $err ]
                    );
                }
                return false;
            }

            if ( $diag ) {
                \GoodService\Core\GSDiagnostics::info(
                    'ListingRepo::save', "UPDATE OK id={$id} rows_affected={$result}"
                );
            }

            // ── Cache invalidation ────────────────────────────────────────────
            Cache::delete( "listing:id:{$id}" );
            if ( $current && $current->slug ) {
                Cache::delete( "listing:slug:{$current->slug}" );
            }
            if ( ! empty( $data['slug'] ) && ( ! $current || $data['slug'] !== $current->slug ) ) {
                Cache::delete( "listing:slug:{$data['slug']}" );
            }
            // Flush vendor-specific listing cache
            if ( ! empty( $data['vendor_id'] ) ) {
                Cache::delete( "listings:vendor:{$data['vendor_id']}:all" );
                Cache::delete( "listings:vendor:{$data['vendor_id']}:" . ( $data['status'] ?? 'active' ) );
            }
            // Flush all search + featured caches (version bump — zero table scan)
            Cache::flush_group( 'listings' );

            // Sync gs_listing_cities — keeps city join table consistent after update
            self::sync_listing_cities(
                $id,
                $data['city']           ?? '',
                $data['service_cities'] ?? ''
            );

            // Sync to Meilisearch if active (non-blocking, 2s timeout)
            \GoodService\Core\Infrastructure::meili_sync_listing( $id, array_merge( $data, [ 'id' => $id ] ) );

            return $id;
        }

        // ── INSERT ────────────────────────────────────────────────────────────
        $data['updated_at'] = current_time( 'mysql' );

        if ( $diag ) {
            \GoodService\Core\GSDiagnostics::log(
                'ListingRepo::save', 'INSERT new listing title=' . ( $data['title'] ?? '?' ),
                [ 'keys' => array_keys( $data ) ]
            );
        }

        $result = $wpdb->insert( $table, $data );
        if ( $result === false ) {
            $err = $wpdb->last_error;
            if ( function_exists( 'gs_write_log' ) ) {
                gs_write_log( "[save_listing] INSERT FAILED — {$err}" );
            }
            if ( $diag ) {
                \GoodService\Core\GSDiagnostics::error(
                    'ListingRepo::save', 'INSERT FAILED', [ 'db_error' => $err ]
                );
            }
            return false;
        }

        $new_id = $wpdb->insert_id ?: false;
        // Real root-cause fix, issue 1: my earlier Listing ID generation
        // fix was mistakenly only ever added to the separate, admin-only
        // adminCreateListing() function — which inserts directly, bypassing
        // this repository entirely. Every other listing creation path,
        // including the main vendor-facing saveListing() flow, goes
        // through here, which is why vendor-created listings never
        // received a Listing ID. This is the true, single point of
        // creation — fixing it here covers every real creation path.
        if ( $new_id ) {
            $wpdb->update( $table,
                [ 'listing_uid' => 'GS-' . str_pad( (string) $new_id, 6, '0', STR_PAD_LEFT ) ],
                [ 'id' => $new_id ]
            );
        }
        if ( $diag ) {
            \GoodService\Core\GSDiagnostics::info(
                'ListingRepo::save', "INSERT OK new id={$new_id}"
            );
        }
        if ( $new_id && ! empty( $data['slug'] ) ) {
            Cache::delete( "listing:slug:{$data['slug']}" );
        }
        Cache::flush_group( 'listings' );

        // Sync gs_listing_cities for the new listing
        if ( $new_id ) {
            self::sync_listing_cities(
                $new_id,
                $data['city']           ?? '',
                $data['service_cities'] ?? ''
            );
            // Sync to Meilisearch if active (non-blocking, 2s timeout)
            \GoodService\Core\Infrastructure::meili_sync_listing( $new_id, array_merge( $data, [ 'id' => $new_id ] ) );
        }

        return $new_id;
    }

    /**
     * Sync gs_listing_cities for a single listing.
     *
     * Called after every INSERT or UPDATE to keep the join table consistent.
     * Steps:
     *   1. Delete all existing rows for this listing_id
     *   2. Re-insert the primary city + all service_cities
     *
     * This is safe and simple — the table is small (one row per city per listing)
     * and the delete+reinsert is atomic enough for this use case.
     *
     * @param int    $listing_id  The listing being saved
     * @param string $city        Primary city (plain string)
     * @param mixed  $svc_cities  service_cities — JSON string or PHP array
     */
    public static function sync_listing_cities( int $listing_id, string $city, mixed $svc_cities ): void {
        global $wpdb;
        $tbl = $wpdb->prefix . 'gs_listing_cities';

        // Guard: table must exist (created by Schema::install on DB Upgrade)
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) { return; }
        if ( ! $listing_id ) { return; }

        // Collect all cities for this listing
        $all_cities = [];

        $primary = trim( $city );
        if ( $primary !== '' ) {
            $all_cities[] = $primary;
        }

        // service_cities may arrive as JSON string or already-decoded array
        if ( is_string( $svc_cities ) && $svc_cities !== '' ) {
            $decoded = json_decode( $svc_cities, true );
            if ( is_array( $decoded ) ) { $svc_cities = $decoded; }
        }
        if ( is_array( $svc_cities ) ) {
            foreach ( $svc_cities as $c ) {
                $c = trim( (string) $c );
                if ( $c !== '' && ! in_array( $c, $all_cities, true ) ) {
                    $all_cities[] = $c;
                }
            }
        }

        // Delete existing rows for this listing then re-insert
        $wpdb->delete( $tbl, [ 'listing_id' => $listing_id ], [ '%d' ] );

        if ( empty( $all_cities ) ) { return; }

        $values = [];
        foreach ( $all_cities as $c ) {
            $values[] = $wpdb->prepare( '(%d, %s)', $listing_id, $c );
        }

        $wpdb->query(
            "INSERT IGNORE INTO {$tbl} (listing_id, city) VALUES "
            . implode( ', ', $values )
        );
    }

    /** Get distinct cities for search filters */
    public function get_cities(): array {
        global $wpdb;
        return Cache::remember( 'listings:cities', function () use ( $wpdb ) {
            return $wpdb->get_col(
                "SELECT DISTINCT city FROM {$wpdb->prefix}gs_listings
                 WHERE city != '' AND status = 'active' ORDER BY city ASC"
            ) ?: [];
        }, 3600 );
    }
}
