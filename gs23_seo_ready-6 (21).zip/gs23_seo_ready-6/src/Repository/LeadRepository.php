<?php
namespace GoodService\Repository;

use GoodService\Core\Cache;

class LeadRepository extends BaseRepository {

    protected function table_name(): string { return 'leads'; }

    public function get_vendor_leads( int $vendor_id, array $args = [] ): array {
        global $wpdb;
        $status    = sanitize_text_field( $args['status']    ?? '' );
        $priority  = sanitize_text_field( $args['priority']  ?? '' );
        $module    = sanitize_text_field( $args['module']    ?? '' );
        $search    = sanitize_text_field( $args['search']    ?? '' );
        $starred   = (int) ( $args['starred']   ?? 0 );
        $date_from = sanitize_text_field( $args['date_from'] ?? '' );
        $date_to   = sanitize_text_field( $args['date_to']   ?? '' );
        $sort_by   = sanitize_text_field( $args['sort_by']   ?? 'newest' );
        $page      = max( 1, (int) ( $args['page']     ?? 1 ) );
        $per_page  = (int) ( $args['per_page'] ?? 20 );
        $offset    = ( $page - 1 ) * $per_page;

        $where  = [ 'l.vendor_id = %d', 'l.is_archived = 0' ];
        $params = [ $vendor_id ];

        // Architecture change: verification no longer gates inbox visibility.
        // Every lead reaches the vendor immediately at submission — see
        // AjaxController::submitInquiry()/submitBookingFromModule(). The old
        // hard filter here ("(l.email = '' OR l.email_verified = 1)") made an
        // unverified lead genuinely invisible; verification is now a trust
        // badge shown per-lead (email_verified + phone_verified columns are
        // still selected below for exactly that badge) rather than a gate.

        if ( $status )   { $where[] = 'l.status = %s';               $params[] = $status; }
        if ( $priority ) { $where[] = 'l.priority = %s';             $params[] = $priority; }
        if ( $module )   { $where[] = 'l.inquiry_module = %s';       $params[] = $module; }
        if ( $starred )  { $where[] = 'l.is_starred = 1'; }
        if ( $search )   {
            $where[] = '(l.name LIKE %s OR l.phone LIKE %s OR l.message LIKE %s)';
            $like    = '%' . $wpdb->esc_like( $search ) . '%';
            $params  = array_merge( $params, [ $like, $like, $like ] );
        }
        if ( $date_from && strtotime( $date_from ) ) {
            $where[] = 'DATE(l.created_at) >= %s';
            $params[] = $date_from;
        }
        if ( $date_to && strtotime( $date_to ) ) {
            $where[] = 'DATE(l.created_at) <= %s';
            $params[] = $date_to;
        }

        $order = match( $sort_by ) {
            'oldest'     => 'l.created_at ASC',
            'urgency'    => "FIELD(l.priority,'urgent','high','normal','low') ASC, l.created_at DESC",
            'unanswered' => "FIELD(l.status,'new','viewed','replied','converted','closed','junk') ASC, l.created_at DESC",
            default      => 'l.created_at DESC',
        };

        $w = implode( ' AND ', $where );

        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gs_leads l WHERE {$w}", ...$params
        ) );
        $rows  = $wpdb->get_results( $wpdb->prepare(
            "SELECT l.*, li.title AS listing_title, li.phone AS listing_phone,
                    li.whatsapp AS listing_whatsapp, li.email AS listing_email
             FROM {$wpdb->prefix}gs_leads l
             LEFT JOIN {$wpdb->prefix}gs_listings li ON li.id = l.listing_id
             WHERE {$w} ORDER BY {$order} LIMIT %d OFFSET %d",
            ...array_merge( $params, [ $per_page, $offset ] )
        ) );

        // Phase 2: attach booking_info (job_status, tracking_token, agreed_amount)
        // to any lead created via submitBookingFromModule. booking_id lives inside
        // the lead's custom_fields JSON (added at booking-creation time), not as a
        // real column, so it must be decoded in PHP rather than via SQL JSON_EXTRACT
        // (not reliably available on older MySQL/MariaDB used on shared hosting).
        $booking_ids = [];
        foreach ( $rows as $row ) {
            if ( ( $row->inquiry_type ?? '' ) !== 'booking' || empty( $row->custom_fields ) ) { continue; }
            $cf = json_decode( (string) $row->custom_fields, true );
            if ( ! empty( $cf['booking_id'] ) ) { $booking_ids[ (int) $row->id ] = (int) $cf['booking_id']; }
        }
        if ( $booking_ids ) {
            $unique_ids  = array_values( array_unique( $booking_ids ) );
            $placeholders = implode( ',', array_fill( 0, count( $unique_ids ), '%d' ) );
            $bk_rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT id, job_status, tracking_token, agreed_amount FROM {$wpdb->prefix}gs_bookings WHERE id IN ({$placeholders})",
                ...$unique_ids
            ) );
            $bk_by_id = [];
            foreach ( $bk_rows as $bk ) { $bk_by_id[ (int) $bk->id ] = $bk; }
            foreach ( $rows as $row ) {
                $bid = $booking_ids[ (int) $row->id ] ?? 0;
                if ( $bid && isset( $bk_by_id[ $bid ] ) ) {
                    $row->booking_info = $bk_by_id[ $bid ];
                }
            }
        }
        return [ 'leads' => $rows ?: [], 'total' => $total, 'page' => $page,
                 'last_page' => (int) ceil( $total / $per_page ) ];
    }

    public function get_vendor_stats( int $vendor_id ): array {
        global $wpdb;
        return Cache::remember( "leads:stats:{$vendor_id}", function() use ( $wpdb, $vendor_id ) {
            $row = $wpdb->get_row( $wpdb->prepare(
                "SELECT COUNT(*) AS total,
                    SUM(status='new') AS new_leads,
                    SUM(status='contacted') AS contacted,
                    SUM(status='converted') AS converted,
                    SUM(status='qualified') AS qualified
                 FROM {$wpdb->prefix}gs_leads WHERE vendor_id = %d", $vendor_id
            ) );
            return $row ? (array) $row : [ 'total' => 0, 'new_leads' => 0,
                'contacted' => 0, 'converted' => 0, 'qualified' => 0 ];
        }, 300 );
    }
}
