<?php
namespace GoodService\Repository;

use GoodService\Core\Cache;

class CategoryRepository extends BaseRepository {

    protected function table_name(): string { return 'categories'; }

    public function get_all_active( bool $with_count = true ): array {
        return Cache::remember( 'categories:all_active:' . (int) $with_count . ':' . GS_VERSION, function() {
            global $wpdb;
            return $wpdb->get_results(
                "SELECT * FROM {$wpdb->prefix}gs_categories
                 WHERE is_active = 1 AND parent_id = 0
                 ORDER BY sort_order ASC, listing_count DESC"
            ) ?: [];
        }, 1800 );
    }

    /**
     * Returns top-level categories with their subcategories pre-loaded.
     *
     * PERF FIX #4: Replaced N+1 query pattern (1 query per top-level category)
     * with a single query that fetches ALL categories at once and groups in PHP.
     * For 50 categories, this reduces 51 DB queries to 1.
     */
    public function get_with_subcategories(): array {
        return Cache::remember( 'categories:with_subs:' . GS_VERSION, function () {
            global $wpdb;
            $all = $wpdb->get_results(
                "SELECT * FROM {$wpdb->prefix}gs_categories
                 WHERE is_active = 1 ORDER BY sort_order ASC, listing_count DESC"
            ) ?: [];

            // Group by parent_id in PHP — zero additional DB queries
            $by_parent = [];
            foreach ( $all as $cat ) {
                $by_parent[ (int) ( $cat->parent_id ?? 0 ) ][] = $cat;
            }

            // Attach subcategories to their parent
            $top_level = $by_parent[0] ?? [];
            foreach ( $top_level as &$cat ) {
                $cat->subcategories = $by_parent[ (int) $cat->id ] ?? [];
            }
            unset( $cat );

            return $top_level;
        }, 1800 );
    }

    public function get_by_slug( string $slug ): ?\stdClass {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_categories WHERE slug = %s", $slug
        ) ) ?: null;
    }

    /**
     * Direct single-row lookup by id — deliberately NOT using
     * get_all_active() as a substitute (that method only returns
     * top-level categories, parent_id = 0; a listing's category_id can
     * point to a subcategory, which get_all_active() would silently
     * miss). Added for ModuleRegistry's category-gating: a listing's
     * $primary->category_id needs resolving to a slug before it can be
     * checked against a module's registered categories array.
     */
    public function get_by_id( int $id ): ?\stdClass {
        return Cache::remember( 'categories:by_id:' . $id . ':' . GS_VERSION, function() use ( $id ) {
            global $wpdb;
            return $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}gs_categories WHERE id = %d", $id
            ) ) ?: null;
        }, 1800 );
    }

    public function update_counts(): void {
        global $wpdb;
        $wpdb->query(
            "UPDATE {$wpdb->prefix}gs_categories c SET c.listing_count =
             (SELECT COUNT(*) FROM {$wpdb->prefix}gs_listings l
              WHERE l.category_id = c.id AND l.status = 'active')"
        );
        self::flush_cache();
    }

    /**
     * Flush ALL category cache entries.
     * Must be called after any create / update / delete on gs_categories.
     * The cache keys embed GS_VERSION so we use flush_group('categories')
     * which bumps the version counter — making all old entries unreachable
     * instantly without a slow DELETE scan.
     */
    public static function flush_cache(): void {
        Cache::flush_group( 'categories' );
    }
}
