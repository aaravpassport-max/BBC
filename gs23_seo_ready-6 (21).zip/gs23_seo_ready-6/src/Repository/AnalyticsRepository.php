<?php
namespace GoodService\Repository;

use GoodService\Core\Cache;

/**
 * AnalyticsRepository
 *
 * Performance improvement (v22) — Buffered writes:
 *   Old: track() fired one INSERT per event, synchronously on every page view.
 *   New: events are accumulated in a static array during the request and
 *        flushed as a single bulk INSERT at WordPress shutdown — after the
 *        response has been sent to the browser (in FPM/FastCGI setups).
 *
 *   This eliminates N sequential INSERT statements and replaces them with
 *   one multi-row INSERT, reducing DB round-trips from N to 1.
 */
class AnalyticsRepository extends BaseRepository {

    protected function table_name(): string { return 'analytics'; }

    // ── Write buffer ──────────────────────────────────────────────────────────
    private static array $pending_events             = [];
    private static bool  $events_shutdown_registered = false;

    /**
     * Record an analytics event.
     *
     * The event is buffered in memory and written to the DB at shutdown.
     * If this is the first event in a request, a shutdown handler is registered.
     */
    public function track( int $listing_id, int $vendor_id, string $event_type, array $data = [] ): void {
        self::$pending_events[] = [
            'listing_id' => $listing_id,
            'vendor_id'  => $vendor_id,
            'event_type' => $event_type,
            'ip_address' => (string) ( $data['ip']         ?? '' ),
            'device'     => (string) ( $data['device']     ?? 'desktop' ),
            'source'     => (string) ( $data['source']     ?? 'direct' ),
            'city'       => (string) ( $data['city']       ?? '' ),
            'session_id' => (string) ( $data['session_id'] ?? '' ),
            'user_id'    => get_current_user_id(),  // 0 for guests; avoids NULL handling
            'created_at' => current_time( 'mysql' ),
        ];

        if ( ! self::$events_shutdown_registered ) {
            self::$events_shutdown_registered = true;
            // Priority 98 — flush analytics before views (priority 99)
            add_action( 'shutdown', [ self::class, '_flush_pending_events' ], 98 );
        }
    }

    /**
     * @internal Called by WordPress 'shutdown' action.  Do not call directly.
     *
     * Flushes all buffered analytics events to the database as a single
     * multi-row INSERT instead of N individual INSERT statements.
     */
    public static function _flush_pending_events(): void {
        if ( empty( self::$pending_events ) ) { return; }
        global $wpdb;

        $table        = $wpdb->prefix . 'gs_analytics';
        $col_list     = '(listing_id, vendor_id, event_type, ip_address, device, source, city, session_id, user_id, created_at)';
        $placeholders = [];
        $values       = [];

        foreach ( self::$pending_events as $e ) {
            $placeholders[] = '(%d, %d, %s, %s, %s, %s, %s, %s, %d, %s)';
            array_push( $values,
                (int)    $e['listing_id'],
                (int)    $e['vendor_id'],
                (string) $e['event_type'],
                (string) $e['ip_address'],
                (string) $e['device'],
                (string) $e['source'],
                (string) $e['city'],
                (string) $e['session_id'],
                (int)    $e['user_id'],
                (string) $e['created_at']
            );
        }

        $sql = "INSERT INTO {$table} {$col_list} VALUES " . implode( ', ', $placeholders );
        $wpdb->query( $wpdb->prepare( $sql, ...$values ) );  // phpcs:ignore — dynamic placeholders

        self::$pending_events = [];
    }

    /** Vendor analytics summary — cached 10 minutes */
    public function vendor_summary( int $vendor_id, int $days = 30 ): array {
        global $wpdb;
        return Cache::remember( "analytics:vendor:{$vendor_id}:{$days}", function () use ( $wpdb, $vendor_id, $days ) {
            $row = $wpdb->get_row( $wpdb->prepare(
                "SELECT COUNT(*) AS total_events,
                    SUM(event_type='view')      AS views,
                    SUM(event_type='lead')      AS leads,
                    SUM(event_type='call')      AS calls,
                    SUM(event_type='whatsapp')  AS whatsapp_clicks,
                    SUM(event_type='email')     AS email_clicks,
                    SUM(event_type='website')   AS website_clicks
                 FROM {$wpdb->prefix}gs_analytics
                 WHERE vendor_id = %d
                   AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
                $vendor_id, $days
            ) );
            $trend = $wpdb->get_results( $wpdb->prepare(
                "SELECT DATE(created_at) AS dt, COUNT(*) AS cnt, event_type
                 FROM {$wpdb->prefix}gs_analytics
                 WHERE vendor_id = %d
                   AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
                 GROUP BY dt, event_type ORDER BY dt ASC",
                $vendor_id, $days
            ) );
            return [ 'summary' => $row ? (array) $row : [], 'trend' => $trend ?: [] ];
        }, 600 );
    }

    /** Platform-wide analytics summary — cached 15 minutes */
    public function platform_summary( int $days = 30 ): \stdClass {
        global $wpdb;
        return Cache::remember( "analytics:platform:{$days}", function () use ( $wpdb, $days ) {
            return $wpdb->get_row( $wpdb->prepare(
                "SELECT SUM(event_type='view')    AS total_views,
                    SUM(event_type='lead')         AS total_leads,
                    SUM(event_type='call')         AS total_calls,
                    COUNT(DISTINCT listing_id)     AS active_listings,
                    COUNT(DISTINCT vendor_id)      AS active_vendors
                 FROM {$wpdb->prefix}gs_analytics
                 WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
                $days
            ) ) ?: new \stdClass();
        }, 900 );
    }
}
