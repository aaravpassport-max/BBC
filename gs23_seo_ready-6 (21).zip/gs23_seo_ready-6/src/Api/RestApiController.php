<?php
namespace GoodService\Api;

use GoodService\Repository\ListingRepository;
use GoodService\Repository\CategoryRepository;
use GoodService\Repository\VendorRepository;
use GoodService\Core\Cache;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class RestApiController {

    private const NS = 'goodservice/v1';

    public static function register(): void {
        add_action( 'rest_api_init', [ self::class, 'register_routes' ] );
    }

    public static function register_routes(): void {
        // ── WhatsApp delivery-status & inbound-message webhook — real fix
        // for a confirmed gap: no webhook receiver existed anywhere in the
        // codebase, meaning every outbound message's status was frozen at
        // whatever the initial send API response said ('sent') forever,
        // and no inbound reply from a customer/vendor could ever be
        // received or logged. GET handles Meta's one-time subscription
        // verification handshake; POST receives the actual status/message
        // callbacks from Meta Cloud API, 360dialog, or Interakt. Public
        // (permission_callback __return_true) because the provider's
        // servers call this directly with no WordPress auth context —
        // secured instead via the configured verify token (GET) and a
        // best-effort payload-shape check (POST; providers don't uniformly
        // support signed webhook bodies the way GET verification does). ──
        register_rest_route( self::NS, '/whatsapp-webhook', [
            'methods'             => 'GET',
            'callback'            => [ self::class, 'whatsapp_webhook_verify' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/whatsapp-webhook', [
            'methods'             => 'POST',
            'callback'            => [ self::class, 'whatsapp_webhook_receive' ],
            'permission_callback' => '__return_true',
        ] );

        // Per-listing PWA manifest — real fix for a confirmed CDN
        // restriction on /wp-admin/ paths: this used to be served via
        // admin-ajax.php, which returned a raw 400 with an empty body
        // before ever reaching this plugin's own code. The REST API lives
        // at a completely different URL (/wp-json/...) and isn't subject to
        // the same restriction.
        register_rest_route( self::NS, '/manifest/(?P<slug>[a-zA-Z0-9\\-]+)', [
            'methods'             => 'GET',
            'callback'            => [ self::class, 'get_listing_manifest' ],
            'permission_callback' => '__return_true',
        ] );

        // Platform-wide PWA manifest — real fix eliminating a fragile
        // dependency: this previously relied on a custom WordPress rewrite
        // rule (/goodservice-client.webmanifest → the actual file), but new
        // rewrite rules require an explicit flush before they take effect,
        // and that timing can't be fully verified from outside the live
        // site. The REST API has no such dependency — it works immediately,
        // exactly like the already-working per-listing manifest fix.
        register_rest_route( self::NS, '/manifest', [
            'methods'             => 'GET',
            'callback'            => [ self::class, 'get_platform_manifest' ],
            'permission_callback' => '__return_true',
        ] );

        // Real fix — confirmed root cause of "Install" always falling back
        // to manual instructions on the vendor/manager dashboards: those
        // pages' <link rel="manifest"> still pointed at the old
        // rewrite-rule-served static file (/goodservice-vendor.webmanifest),
        // which (a) depends on rewrite rules having actually been flushed —
        // the exact fragility the platform manifest was already moved away
        // from — and (b) even when reachable, serves the file's icon URLs
        // completely unrewritten, i.e. the exact direct static .png paths
        // already confirmed intercepted by the CDN's WebP conversion
        // elsewhere in this file. Chrome will not fire beforeinstallprompt
        // if the manifest's icons don't actually load, so a broken icon
        // URL silently disables the install prompt with no visible error.
        // This mirrors get_platform_manifest() exactly, for the vendor app.
        register_rest_route( self::NS, '/manifest-vendor', [
            'methods'             => 'GET',
            'callback'            => [ self::class, 'get_vendor_manifest' ],
            'permission_callback' => '__return_true',
        ] );

        // PWA icon — served through PHP to bypass CDN static-asset WebP
        // conversion, confirmed the actual remaining cause via live evidence.
        // Real fix for a confirmed regression: the CDN very likely
        // pattern-matches on the .png extension at the end of ANY url,
        // regardless of whether it's a real static file or a dynamic REST
        // route — the same aggressive, extension-based behavior already
        // confirmed for actual static assets on this CDN. No file-like
        // extension anywhere in this URL now.
        register_rest_route( self::NS, '/icon', [
            'methods'             => 'GET',
            'callback'            => [ self::class, 'get_pwa_icon' ],
            'permission_callback' => '__return_true',
        ] );

        // Real fix — the actual root cause of "Download App works from the
        // vendor listing page but not the homepage header button": both
        // gsRegisterVendorPWA() and gsRegisterClientPWA() register the
        // service worker via navigator.serviceWorker.register(swUrl) with
        // NO explicit scope. Per spec, a service worker's maximum allowed
        // scope defaults to the DIRECTORY of its own script URL — here,
        // GS.plugin_url + 'assets/js/', i.e.
        // /wp-content/plugins/<slug>/assets/js/. That scope does not
        // include '/', so the service worker can never control the
        // homepage (start_url "/" in goodservice-client.webmanifest,
        // scope "/") no matter how correct the manifest or icons are —
        // Chrome's installability check requires the SW's scope to cover
        // the manifest's scope/start_url before beforeinstallprompt can
        // ever fire. This is why the vendor LISTING page's own button
        // could still work in some cases (its page happens to fall under
        // whatever scope was actually granted) while the site-wide
        // homepage header button never could.
        // The fix has two parts: (1) this REST route re-serves the exact
        // same service-worker file's bytes, same-origin, with an explicit
        // `Service-Worker-Allowed: /` response header — the ONLY way a
        // browser permits a script to claim a broader scope than its own
        // URL's directory; and (2) goodservice.js now registers through
        // this route and passes `{ scope: '/' }` explicitly (see
        // gsRegisterVendorPWA()/gsRegisterClientPWA()).
        register_rest_route( self::NS, '/sw', [
            'methods'             => 'GET',
            'callback'            => [ self::class, 'get_pwa_service_worker' ],
            'permission_callback' => '__return_true',
        ] );

        self::register_webhook_routes();

        // Real feature — email verification, confirmed genuinely absent:
        // gs_account_email_verified was read in one place but never set
        // anywhere, with no token generation or verification link at all.
        register_rest_route( self::NS, '/verify-email/(?P<token>[a-f0-9]{64})', [
            'methods'             => 'GET',
            'callback'            => [ self::class, 'verify_email' ],
            'permission_callback' => '__return_true', // the token itself is the security mechanism, matching the webhook signature model above
        ] );
        // Listings
        register_rest_route( self::NS, '/listings', [
            [ 'methods' => 'GET',  'callback' => [ self::class, 'get_listings'  ], 'permission_callback' => '__return_true' ],
            [ 'methods' => 'POST', 'callback' => [ self::class, 'create_listing'], 'permission_callback' => [ self::class, 'vendor_permission' ] ],
        ] );
        register_rest_route( self::NS, '/listings/(?P<id>\d+)', [
            [ 'methods' => 'GET',    'callback' => [ self::class, 'get_listing'    ], 'permission_callback' => '__return_true' ],
            [ 'methods' => 'PUT',    'callback' => [ self::class, 'update_listing' ], 'permission_callback' => [ self::class, 'owner_permission' ] ],
            [ 'methods' => 'DELETE', 'callback' => [ self::class, 'delete_listing' ], 'permission_callback' => [ self::class, 'owner_permission' ] ],
        ] );

        // Categories
        register_rest_route( self::NS, '/categories', [
            'methods'             => 'GET',
            'callback'            => [ self::class, 'get_categories' ],
            'permission_callback' => '__return_true',
        ] );

        // Search
        register_rest_route( self::NS, '/search', [
            'methods'             => 'GET',
            'callback'            => [ self::class, 'search' ],
            'permission_callback' => '__return_true',
        ] );

        // Vendors
        register_rest_route( self::NS, '/vendors/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [ self::class, 'get_vendor' ],
            'permission_callback' => '__return_true',
        ] );

        // Reviews
        register_rest_route( self::NS, '/listings/(?P<id>\d+)/reviews', [
            [ 'methods' => 'GET',  'callback' => [ self::class, 'get_reviews'  ], 'permission_callback' => '__return_true' ],
            [ 'methods' => 'POST', 'callback' => [ self::class, 'post_review'  ], 'permission_callback' => 'is_user_logged_in' ],
        ] );

        // Leads (submit a lead)
        register_rest_route( self::NS, '/listings/(?P<id>\d+)/leads', [
            'methods'             => 'POST',
            'callback'            => [ self::class, 'submit_lead' ],
            'permission_callback' => '__return_true',
        ] );

        // Vendor (authenticated)
        register_rest_route( self::NS, '/vendor/stats', [
            'methods'             => 'GET',
            'callback'            => [ self::class, 'vendor_stats' ],
            'permission_callback' => [ self::class, 'vendor_permission' ],
        ] );

        // Me
        register_rest_route( self::NS, '/me', [
            'methods'             => 'GET',
            'callback'            => [ self::class, 'get_me' ],
            'permission_callback' => 'is_user_logged_in',
        ] );

        // API key auth endpoint
        register_rest_route( self::NS, '/auth/token', [
            'methods'             => 'POST',
            'callback'            => [ self::class, 'get_token' ],
            'permission_callback' => '__return_true',
        ] );
    }

    // ── Permission Callbacks ────────────────────────────────────────────────
    public static function vendor_permission( \WP_REST_Request $req ): bool {
        return is_user_logged_in() && ( gs_is_vendor() || gs_is_admin_level() );
    }

    public static function owner_permission( \WP_REST_Request $req ): bool {
        if ( ! is_user_logged_in() ) { return false; }
        if ( gs_is_admin_level() ) { return true; }
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        $listing_id  = (int) $req->get_param( 'id' );
        $vendor_id   = gs_current_vendor_id();
        $owner       = (int) $wpdb->get_var( $wpdb->prepare( "SELECT vendor_id FROM {$pfx}listings WHERE id=%d", $listing_id ) );
        return $vendor_id && $owner === $vendor_id;
    }

    public static function admin_permission(): bool {
        return is_user_logged_in() && gs_is_admin_level();
    }

    // ── Listings ─────────────────────────────────────────────────────────────
    public static function get_listings( \WP_REST_Request $req ): \WP_REST_Response {
        $repo   = new ListingRepository();
        $result = $repo->search( [
            'keyword'     => sanitize_text_field( $req->get_param( 'q' ) ?? '' ),
            'category_id' => (int) ( $req->get_param( 'category' ) ?? 0 ),
            'city'        => sanitize_text_field( $req->get_param( 'city' ) ?? '' ),
            'status'      => 'active',
            'per_page'    => min( (int) ( $req->get_param( 'per_page' ) ?? 12 ), 50 ),
            'page'        => max( 1, (int) ( $req->get_param( 'page' ) ?? 1 ) ),
            'sort'        => sanitize_key( $req->get_param( 'sort' ) ?? 'featured' ),
        ] );
        return rest_ensure_response( $result );
    }

    public static function get_listing( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $repo    = new ListingRepository();
        $listing = $repo->find( (int) $req->get_param( 'id' ) );
        if ( ! $listing ) { return new \WP_Error( 'not_found', 'Listing not found', [ 'status' => 404 ] ); }
        return rest_ensure_response( $listing );
    }

    /**
     * Sanitize listing data from REST API (JSON body) using the same rules as
     * the AJAX saveListing() handler. Prevents XSS injection through the REST API.
     * (MAJOR FIX #6 — previously raw get_json_params() was passed directly to save())
     */
    private static function sanitize_listing_data( array $raw ): array {
        return [
            'listing_type'    => sanitize_text_field(      $raw['listing_type']    ?? 'service' ),
            'title'           => sanitize_text_field(      $raw['title']           ?? '' ),
            'slug'            => sanitize_title(           $raw['slug']            ?? '' ),
            'tagline'         => sanitize_text_field(      $raw['tagline']         ?? '' ),
            'short_desc'      => sanitize_textarea_field(  $raw['short_desc']      ?? '' ),
            'full_desc'       => wp_kses_post(             $raw['full_desc']       ?? '' ),
            'category_id'     => (int)                   ( $raw['category_id']     ?? 0  ),
            'subcategory_id'  => (int)                   ( $raw['subcategory_id']  ?? 0  ),
            'tags'            => sanitize_text_field(      $raw['tags']            ?? '' ),
            'price_min'       => isset( $raw['price_min'] ) ? (float) $raw['price_min'] : null,
            'price_max'       => isset( $raw['price_max'] ) ? (float) $raw['price_max'] : null,
            'price_unit'      => sanitize_text_field(      $raw['price_unit']      ?? '' ),
            'city'            => sanitize_text_field(      $raw['city']            ?? '' ),
            'state'           => sanitize_text_field(      $raw['state']           ?? '' ),
            'pincode'         => sanitize_text_field(      $raw['pincode']         ?? '' ),
            'phone'           => sanitize_text_field(      $raw['phone']           ?? '' ),
            'whatsapp'        => sanitize_text_field(      $raw['whatsapp']        ?? '' ),
            'email'           => sanitize_email(           $raw['email']           ?? '' ),
            'website'         => esc_url_raw(              $raw['website']         ?? '' ),
            'banner_url'      => esc_url_raw(              $raw['banner_url']      ?? '' ),
            'logo_url'        => esc_url_raw(              $raw['logo_url']        ?? '' ),
            'video_url'       => esc_url_raw(              $raw['video_url']       ?? '' ),
            'address'         => sanitize_textarea_field(  $raw['address']         ?? '' ),
            'team_size'       => sanitize_text_field(      $raw['team_size']       ?? '' ),
            'established_year'=> (int)                   ( $raw['established_year'] ?? 0 ) ?: null,
            'certifications'  => sanitize_text_field(      $raw['certifications']  ?? '' ),
            'awards'          => sanitize_text_field(      $raw['awards']          ?? '' ),
            'seo_title'         => sanitize_text_field(     $raw['seo_title']         ?? '' ),
            'seo_desc'          => sanitize_textarea_field( $raw['seo_desc']           ?? '' ),
            'seo_keywords'      => sanitize_text_field(     $raw['seo_keywords']       ?? '' ),
            'seo_focus_keyword' => sanitize_text_field(     $raw['seo_focus_keyword']  ?? '' ),
            'og_image'          => esc_url_raw(              $raw['og_image']           ?? '' ),
            'seo_robots'        => in_array( sanitize_text_field( $raw['seo_robots'] ?? 'index,follow' ), ['index,follow','noindex,follow','noindex,nofollow'], true )
                                    ? sanitize_text_field( $raw['seo_robots'] ) : 'index,follow',
            // JSON blobs: kept as-is from JSON body (already decoded/re-encoded safely)
            'gallery'         => isset( $raw['gallery'] )       ? wp_json_encode( $raw['gallery'] )       : null,
            'services_data'   => isset( $raw['services_data'] ) ? wp_json_encode( $raw['services_data'] ) : null,
            'faq_data'        => isset( $raw['faq_data'] )      ? wp_json_encode( $raw['faq_data'] )      : null,
        ];
    }

    public static function create_listing( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $repo      = new ListingRepository();
        $vendor_id = gs_current_vendor_id();
        if ( ! $vendor_id ) { return new \WP_Error( 'no_vendor', 'Vendor profile not found', [ 'status' => 403 ] ); }

        // MAJOR FIX #6: Sanitize REST input before passing to save().
        // Previously raw get_json_params() was used, allowing XSS and field injection.
        $safe_data = self::sanitize_listing_data( $req->get_json_params() ?? [] );
        $id        = $repo->save( array_merge( $safe_data, [ 'vendor_id' => $vendor_id ] ) );
        if ( is_wp_error( $id ) ) { return $id; }
        return rest_ensure_response( [ 'id' => $id, 'message' => 'Listing created' ] );
    }

    public static function update_listing( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $repo      = new ListingRepository();
        $id        = (int) $req->get_param( 'id' );
        // MAJOR FIX #6: Sanitize REST input — same as above.
        $safe_data = self::sanitize_listing_data( $req->get_json_params() ?? [] );
        $repo->save( array_merge( $safe_data, [ 'id' => $id ] ) );
        return rest_ensure_response( [ 'id' => $id, 'message' => 'Updated' ] );
    }

    // TRACE: triggered by DELETE /wp-json/goodservice/v1/listings/{id} with owner_permission satisfied →
    //        casts id param to int, calls $wpdb->update to set status='deleted' WHERE id=N,
    //        checks return value (false=DB error→500, 0=not found→404, 1=success→200+cache flush) →
    //        mutates gs_listings row status column to 'deleted'; flushes listings cache group
    // PRECONDITIONS: caller authenticated, owner_permission() returned true (vendor owns listing OR is admin)
    // POSTCONDITIONS: gs_listings.status='deleted' for given id; listings cache flushed;
    //                 listing no longer appears in any WHERE status='active' queries
    // EDGE CASES: non-existent id → $wpdb->update returns 0 → 404 returned (not ghost 200);
    //             DB error → $wpdb->update returns false → 500 with $wpdb->last_error message;
    //             already-deleted listing → update returns 0 (no rows changed) → 404
    // BUSINESS RULE: soft-delete only — row preserved for audit; status='deleted' excludes from public queries
    // ROLES ALLOWED: listing owner (gs_vendor whose vendor_id matches listing.vendor_id) OR admin-level
    public static function delete_listing( \WP_REST_Request $req ): \WP_REST_Response {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        $id  = (int) $req->get_param( 'id' );
        $result = $wpdb->update( $pfx . 'listings', [ 'status' => 'deleted' ], [ 'id' => $id ] );
        if ( $result === false ) {
            return new \WP_REST_Response( [ 'message' => 'Delete failed: ' . $wpdb->last_error ], 500 );
        }
        if ( $result === 0 ) {
            return new \WP_REST_Response( [ 'message' => 'Listing not found.' ], 404 );
        }
        \GoodService\Core\Cache::flush_group( 'listings' );
        return rest_ensure_response( [ 'message' => 'Deleted' ] );
    }

    // ── Categories ────────────────────────────────────────────────────────────
    public static function get_categories( \WP_REST_Request $request = null ): \WP_REST_Response {
        $cats = Cache::remember( 'api_categories', 3600, function() {
            return ( new \GoodService\Repository\CategoryRepository() )->get_with_subcategories();
        } );

        // Real, additive enhancement to this EXISTING public read-only
        // endpoint — no new route. When a caller (an AI agent, a search
        // engine, or anything else) passes ?city=, each category and
        // subcategory in the response gains a `listing_count_in_city`
        // field: how many active listings in that category actually
        // serve that city, using the city coverage this platform already
        // tracks in gs_listing_cities (populated by
        // ListingRepository::sync_listing_cities() on every save — the
        // same table the vendor page's own city-serving data is built
        // from). This answers "which vendors offer Category X in City Y"
        // machine-readably without creating any new public page, URL, or
        // combined category+city route. Omitting ?city= returns the
        // response completely unchanged from today, so nothing existing
        // that already calls /categories is affected.
        $city = $request ? sanitize_text_field( (string) $request->get_param( 'city' ) ) : '';
        if ( $city !== '' ) {
            global $wpdb;
            $pfx = $wpdb->prefix . 'gs_';
            $counts = Cache::remember( 'api_categories:city_counts:' . md5( $city ), 900, function() use ( $wpdb, $pfx, $city ) {
                $rows = $wpdb->get_results( $wpdb->prepare(
                    "SELECT l.category_id, COUNT(DISTINCT l.id) AS cnt
                     FROM {$pfx}listings l
                     INNER JOIN {$pfx}listing_cities lc ON lc.listing_id = l.id
                     WHERE l.status = 'active' AND lc.city = %s
                     GROUP BY l.category_id",
                    $city
                ) );
                $map = [];
                foreach ( $rows as $r ) { $map[ (int) $r->category_id ] = (int) $r->cnt; }
                return $map;
            } );
            $_annotate = function( $cat ) use ( $counts ) {
                $cat->listing_count_in_city = $counts[ (int) $cat->id ] ?? 0;
                return $cat;
            };
            $cats = array_map( function( $cat ) use ( $_annotate ) {
                $cat = clone $cat; // never mutate the shared cached objects
                $cat = $_annotate( $cat );
                if ( ! empty( $cat->subcategories ) && is_array( $cat->subcategories ) ) {
                    $cat->subcategories = array_map( function( $sub ) use ( $_annotate ) {
                        $sub = clone $sub;
                        return $_annotate( $sub );
                    }, $cat->subcategories );
                }
                return $cat;
            }, $cats );
        }

        return rest_ensure_response( $cats );
    }

    // ── Search ────────────────────────────────────────────────────────────────
    public static function search( \WP_REST_Request $req ): \WP_REST_Response {
        $repo   = new ListingRepository();
        $result = $repo->search( [
            'keyword'     => sanitize_text_field( $req->get_param( 'q' ) ?? '' ),
            'category_id' => (int) ( $req->get_param( 'category' ) ?? 0 ),
            'city'        => sanitize_text_field( $req->get_param( 'city' ) ?? '' ),
            'min_rating'  => (float) ( $req->get_param( 'min_rating' ) ?? 0 ),
            'per_page'    => min( (int) ( $req->get_param( 'per_page' ) ?? 12 ), 50 ),
            'page'        => max( 1, (int) ( $req->get_param( 'page' ) ?? 1 ) ),
            'sort'        => sanitize_key( $req->get_param( 'sort' ) ?? 'relevance' ),
        ] );
        return rest_ensure_response( $result );
    }

    // ── Per-listing PWA manifest ─────────────────────────────────────────────
    // ── Platform-wide PWA manifest ───────────────────────────────────────────
    // ── PWA icon — served through PHP to bypass CDN static-asset WebP
    // conversion, the actual remaining cause on a fresh device: the CDN's
    // automatic image optimization applies to direct static-file requests,
    // which is exactly how the icon was being served before. A dynamic,
    // application-generated response isn't subject to that same pipeline,
    // and this forces the correct, real Content-Type explicitly. ──
    public static function get_pwa_icon( \WP_REST_Request $req ) {
        // Real fix: uses short, non-file-like slugs — not actual filenames
        // — mapped internally to the real file paths, so nothing in the
        // request resembles a static asset to a naive, extension-based CDN
        // rule (the confirmed cause of the regression this replaces).
        $slug_map = [
            'client-192' => 'client-icon-192.png',
            'client-512' => 'client-icon-512.png',
            'vendor-192' => 'vendor-icon-192.png',
            'vendor-512' => 'vendor-icon-512.png',
        ];
        $slug = sanitize_key( $req->get_param( 'name' ) );
        if ( ! isset( $slug_map[ $slug ] ) ) {
            return new \WP_Error( 'not_found', 'Icon not found', [ 'status' => 404 ] );
        }
        $name = $slug_map[ $slug ];
        $path = GS_DIR . 'assets/pwa/' . $name;
        if ( ! file_exists( $path ) ) {
            return new \WP_Error( 'not_found', 'Icon file missing on disk', [ 'status' => 404 ] );
        }
        if ( ! headers_sent() ) {
            header( 'Content-Type: image/png' );
            header( 'Content-Length: ' . filesize( $path ) );
            header( 'Cache-Control: public, max-age=86400' ); // icons change rarely; safe to cache for a day
        }
        // Real fix: WordPress commonly has active output buffering
        // internally (its own REST serialization layer, caching plugins,
        // etc.) — writing raw binary data while any buffer is still active
        // can corrupt the output, wrapping or mangling the actual image
        // bytes before they reach the client. Clears every active buffer
        // first, a necessary practice for raw binary output inside a
        // framework that uses buffering internally.
        while ( ob_get_level() > 0 ) { ob_end_clean(); }
        readfile( $path );
        exit;
    }

    /**
     * Serves gs-client-sw.js / gs-vendor-sw.js same-origin, with an explicit
     * Service-Worker-Allowed: / header — see the route registration comment
     * above for why this is required at all. `type` selects which file;
     * defaults to the client worker (matches gsRegisterClientPWA() being the
     * default branch in goodservice.js's bootstrap for non-vendor visitors).
     */
    public static function get_pwa_service_worker( \WP_REST_Request $req ) {
        $type = sanitize_key( $req->get_param( 'type' ) );
        $file = $type === 'vendor' ? 'gs-vendor-sw.js' : 'gs-client-sw.js';
        $path = GS_DIR . 'assets/js/' . $file;
        if ( ! file_exists( $path ) ) {
            return new \WP_Error( 'not_found', 'Service worker file missing on disk', [ 'status' => 404 ] );
        }
        if ( ! headers_sent() ) {
            header( 'Content-Type: application/javascript; charset=UTF-8' );
            header( 'Content-Length: ' . filesize( $path ) );
            // The one line that actually fixes installability: without this,
            // the browser silently caps this script's scope to its own
            // directory (this REST route's path), which still would not
            // cover '/' — this header is what grants the broader scope.
            header( 'Service-Worker-Allowed: /' );
            // Real fix, from live diagnostic evidence: this route was
            // confirmed (via the admin "Check Why App Isn't Downloading"
            // tool, run against the real live site) to return HTTP 200 with
            // an EMPTY body and Content-Type forced to
            // application/octet-stream — for both this route and the
            // completely separately-implemented manifest route below (one
            // streams a file via readfile(), the other returns a plain JSON
            // array; they share no code path), which rules out a bug in
            // either PHP handler and points at something between PHP and
            // the browser — most likely a caching layer (WordPress object
            // cache, a caching plugin, the hosting panel's own page cache,
            // or a CDN) serving a stale/empty cached copy from before this
            // route existed. self::no_cache_headers() sends every no-cache
            // convention recognized by WordPress itself AND by the most
            // common CDN/reverse-proxy vendors (Cloudflare, Akamai,
            // Fastly/Varnish), maximizing the chance this specific response
          // is never served from any of those caches again.
            self::no_cache_headers();
        }
        while ( ob_get_level() > 0 ) { ob_end_clean(); }
        readfile( $path );
        exit;
    }

    /**
     * Sends every no-cache header convention this investigation could
     * identify across WordPress core and the major CDN/reverse-proxy
     * vendors, in one place — see the call sites' comments for why this
     * exists at all. Deliberately broader than a single `Cache-Control`
     * line: different intermediaries key off different header names, and
     * sending the ones a given intermediary doesn't recognize is harmless.
     */
    private static function no_cache_headers(): void {
        if ( function_exists( 'nocache_headers' ) ) { nocache_headers(); } // WordPress's own — covers WP object/page-cache plugins that respect it.
        header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
        header( 'Pragma: no-cache' );
        header( 'Expires: 0' );
        header( 'CDN-Cache-Control: no-store' );          // Cloudflare Enterprise / generic CDN convention.
        header( 'Cloudflare-CDN-Cache-Control: no-store' ); // Cloudflare-specific override of the line above.
        header( 'Surrogate-Control: no-store' );          // Fastly / Varnish / Akamai convention.
        // Real, targeted fix now that the actual host is confirmed: Nestify
        // is LiteSpeed-based managed WordPress hosting. LiteSpeed's own
        // server-level cache (LSCache) — which runs at the web-server
        // layer, in front of PHP, independent of any WordPress caching
        // plugin — has its OWN header convention for "never cache this
        // response", separate from the generic Cache-Control lines above.
        // A generic Cache-Control header is not guaranteed to be read the
        // same way by LSCache, which is almost certainly why the plain
        // no-cache headers sent before this had zero effect. This is
        // LiteSpeed's own documented mechanism for excluding a single
        // response from its cache.
        header( 'X-LiteSpeed-Cache-Control: no-cache' );
        // Belt-and-braces: if the LiteSpeed Cache plugin (LSCWP) is also
        // active in WordPress itself (Nestify typically installs it by
        // default), its own PHP-level API achieves the same thing one more
        // way — harmless no-op if the plugin isn't present.
        if ( has_action( 'litespeed_control_set_nocache' ) ) {
            do_action( 'litespeed_control_set_nocache', 'gs23 pwa manifest/sw route' );
        }
    }

    public static function get_platform_manifest( \WP_REST_Request $req ) {
        $file = GS_DIR . 'goodservice-client.webmanifest';
        if ( ! file_exists( $file ) ) {
            return new \WP_Error( 'not_found', 'Platform manifest file not found', [ 'status' => 404 ] );
        }
        $manifest = json_decode( file_get_contents( $file ), true );
        if ( ! is_array( $manifest ) ) {
            return new \WP_Error( 'invalid_manifest', 'Platform manifest file is not valid JSON', [ 'status' => 500 ] );
        }
        // Real fix: rewrites icon URLs to the new PHP-served route instead
        // of the direct static file path — the direct path is exactly what
        // the CDN's WebP conversion intercepts, confirmed by live evidence
        // across multiple diagnostic runs on this exact icon. Uses a
        // non-file-like query parameter, not a path ending in .png — a
        // path-based .png URL was ALSO confirmed intercepted by the same
        // CDN's extension-based rules, even though it was a dynamic route.
        $filename_to_slug = [
            'client-icon-192.png' => 'client-192',
            'client-icon-512.png' => 'client-512',
            'vendor-icon-192.png' => 'vendor-192',
            'vendor-icon-512.png' => 'vendor-512',
        ];
        if ( is_array( $manifest['icons'] ?? null ) ) {
            foreach ( $manifest['icons'] as &$icon ) {
                // Real fix (v7.475.0): the source .webmanifest file's icon
                // src values now already point directly at this REST icon
                // route with a real ?name= slug baked in (needed for the
                // static-file-serving pivot — see the file's own history),
                // instead of the old raw static .png path this rewriter
                // was originally written to translate. Rewriting again
                // here would misparse the query string via basename() and
                // collapse both icon sizes onto the same fallback slug —
                // skip icons that are already a real REST icon URL.
                if ( str_contains( (string) ( $icon['src'] ?? '' ), '/goodservice/v1/icon' ) ) {
                    continue;
                }
                $filename = basename( parse_url( $icon['src'], PHP_URL_PATH ) ?: '' );
                $slug = $filename_to_slug[ $filename ] ?? 'client-192';
                $icon['src'] = add_query_arg( 'name', $slug, rest_url( 'goodservice/v1/icon' ) );
            }
            unset( $icon );
        }
        add_filter( 'rest_pre_serve_request', function( $served, $result ) {
            if ( ! headers_sent() ) {
                header( 'Content-Type: application/manifest+json' );
                // See no_cache_headers()'s doc comment in this class — this
                // exact route was confirmed via live diagnostic evidence to
                // return an empty, wrongly-typed response, most likely from
                // a stale cache layer between PHP and the browser predating
                // this route's existence.
                self::no_cache_headers();
            }
            return $served;
        }, 10, 2 );
        return rest_ensure_response( $manifest );
    }

    /**
     * Vendor/manager-dashboard PWA manifest — identical shape and icon-URL
     * rewriting to get_platform_manifest() above, just sourced from
     * goodservice-vendor.webmanifest and the vendor-* icon slugs.
     */
    public static function get_vendor_manifest( \WP_REST_Request $req ) {
        $file = GS_DIR . 'goodservice-vendor.webmanifest';
        if ( ! file_exists( $file ) ) {
            return new \WP_Error( 'not_found', 'Vendor manifest file not found', [ 'status' => 404 ] );
        }
        $manifest = json_decode( file_get_contents( $file ), true );
        if ( ! is_array( $manifest ) ) {
            return new \WP_Error( 'invalid_manifest', 'Vendor manifest file is not valid JSON', [ 'status' => 500 ] );
        }
        $filename_to_slug = [
            'client-icon-192.png' => 'client-192',
            'client-icon-512.png' => 'client-512',
            'vendor-icon-192.png' => 'vendor-192',
            'vendor-icon-512.png' => 'vendor-512',
        ];
        if ( is_array( $manifest['icons'] ?? null ) ) {
            foreach ( $manifest['icons'] as &$icon ) {
                // See the matching comment in get_platform_manifest() above.
                if ( str_contains( (string) ( $icon['src'] ?? '' ), '/goodservice/v1/icon' ) ) {
                    continue;
                }
                $filename = basename( parse_url( $icon['src'], PHP_URL_PATH ) ?: '' );
                $slug = $filename_to_slug[ $filename ] ?? 'vendor-192';
                $icon['src'] = add_query_arg( 'name', $slug, rest_url( 'goodservice/v1/icon' ) );
            }
            unset( $icon );
        }
        add_filter( 'rest_pre_serve_request', function( $served, $result ) {
            if ( ! headers_sent() ) {
                header( 'Content-Type: application/manifest+json' );
                // See no_cache_headers()'s doc comment in this class — this
                // exact route was confirmed via live diagnostic evidence to
                // return an empty, wrongly-typed response, most likely from
                // a stale cache layer between PHP and the browser predating
                // this route's existence.
                self::no_cache_headers();
            }
            return $served;
        }, 10, 2 );
        return rest_ensure_response( $manifest );
    }

    public static function get_listing_manifest( \WP_REST_Request $req ) {
        global $wpdb;
        $slug = sanitize_text_field( $req->get_param( 'slug' ) );
        $pfx = $wpdb->prefix . 'gs_';
        $listing = $wpdb->get_row( $wpdb->prepare(
            "SELECT title, logo_url, slug FROM {$pfx}listings WHERE slug = %s AND status = 'active' LIMIT 1",
            $slug
        ) );
        if ( ! $listing ) { return new \WP_Error( 'not_found', 'Listing not found', [ 'status' => 404 ] ); }

        // Real fix, same issue as the platform manifest for this fallback
        // case (vendor genuinely has no logo uploaded): the direct static
        // file path is exactly what the CDN's WebP conversion intercepts.
        $logo = $listing->logo_url ?: add_query_arg( 'name', 'vendor-512', rest_url( 'goodservice/v1/icon' ) );
        $name = $listing->title ?: 'GoodService Listing';
        $start_url = home_url( '/' . ltrim( $listing->slug, '/' ) . '/?pwa=1' );

        $manifest = [
            'name'             => $name,
            'short_name'       => mb_substr( $name, 0, 12 ),
            'start_url'        => $start_url,
            'display'          => 'standalone',
            'orientation'      => 'portrait',
            'background_color' => '#ffffff',
            'theme_color'      => '#2563EB',
            // Real fix: no "type" declared — even correctly
            // extension-matched detection can be wrong if a CDN silently
            // serves a different format underneath (confirmed happening for
            // the platform icon: a real .png served as image/webp). Letting
            // the browser trust what it actually receives is more robust
            // than any declaration this code could make.
            'icons' => [
                [ 'src' => $logo, 'sizes' => '192x192', 'purpose' => 'any' ],
                [ 'src' => $logo, 'sizes' => '512x512', 'purpose' => 'any' ],
            ],
        ];

        // Force the precise, spec-correct manifest content-type rather than
        // the REST API's default application/json — both work in practice,
        // but this is the fully correct one.
        add_filter( 'rest_pre_serve_request', function( $served, $result ) {
            if ( ! headers_sent() ) {
                header( 'Content-Type: application/manifest+json' );
                // See no_cache_headers()'s doc comment in this class — this
                // exact route was confirmed via live diagnostic evidence to
                // return an empty, wrongly-typed response, most likely from
                // a stale cache layer between PHP and the browser predating
                // this route's existence.
                self::no_cache_headers();
            }
            return $served;
        }, 10, 2 );

        return rest_ensure_response( $manifest );
    }

    // ── Vendors ───────────────────────────────────────────────────────────────
    public static function get_vendor( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        $vendor = VendorRepository::get_by_id( (int) $req->get_param( 'id' ) );
        if ( ! $vendor ) { return new \WP_Error( 'not_found', 'Vendor not found', [ 'status' => 404 ] ); }
        unset( $vendor->bank_details, $vendor->private_notes );
        return rest_ensure_response( $vendor );
    }

    // ── Reviews ───────────────────────────────────────────────────────────────
    public static function get_reviews( \WP_REST_Request $req ): \WP_REST_Response {
        global $wpdb;
        $pfx     = $wpdb->prefix . 'gs_';
        $listing_id = (int) $req->get_param( 'id' );
        $reviews = $wpdb->get_results( $wpdb->prepare(
            "SELECT r.*, u.display_name as reviewer_name FROM {$pfx}reviews r
             LEFT JOIN {$wpdb->users} u ON u.ID=r.user_id
             WHERE r.listing_id=%d AND r.status='approved'
             ORDER BY r.created_at DESC LIMIT 20",
            $listing_id
        ) );
        return rest_ensure_response( $reviews );
    }

    public static function post_review( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        global $wpdb;
        $pfx     = $wpdb->prefix . 'gs_';
        $listing_id = (int) $req->get_param( 'id' );
        $user       = wp_get_current_user();
        $data       = $req->get_json_params();

        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$pfx}reviews WHERE listing_id=%d AND user_id=%d",
            $listing_id, $user->ID
        ) );
        if ( $existing ) { return new \WP_Error( 'already_reviewed', 'Already reviewed', [ 'status' => 409 ] ); }

        $rating = min( 5, max( 1, (int) ( $data['rating'] ?? 5 ) ) );
        $wpdb->insert( $pfx . 'reviews', [
            'listing_id'    => $listing_id,
            'user_id'       => $user->ID,
            'reviewer_name' => $user->display_name,
            'rating'        => $rating,
            'title'         => sanitize_text_field( $data['title'] ?? '' ),
            'review_text'   => sanitize_textarea_field( $data['review_text'] ?? '' ),
            'status'        => gs_setting( 'auto_approve_reviews', '0' ) ? 'approved' : 'pending',
            'created_at'    => current_time( 'mysql' ),
        ] );

        return rest_ensure_response( [ 'message' => 'Review submitted', 'id' => $wpdb->insert_id ] );
    }

    // ── Leads ─────────────────────────────────────────────────────────────────
    public static function submit_lead( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        global $wpdb;
        $pfx        = $wpdb->prefix . 'gs_';
        $listing_id = (int) $req->get_param( 'id' );
        $data       = $req->get_json_params();
        $ip         = gs_get_ip();

        $cooldown = (int) gs_setting( 'lead_cooldown_hours', '24' );
        $recent   = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$pfx}leads WHERE listing_id=%d AND ip_address=%s AND created_at > DATE_SUB(NOW(), INTERVAL %d HOUR)",
            $listing_id, $ip, $cooldown
        ) );
        if ( $recent ) { return new \WP_Error( 'too_many', 'Please wait before sending another enquiry', [ 'status' => 429 ] ); }

        $listing  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pfx}listings WHERE id=%d AND status='active'", $listing_id ) );
        if ( ! $listing ) { return new \WP_Error( 'not_found', 'Listing not found', [ 'status' => 404 ] ); }

        $wpdb->insert( $pfx . 'leads', [
            'vendor_id'    => $listing->vendor_id,
            'listing_id'   => $listing_id,
            'name'         => sanitize_text_field( $data['name'] ?? '' ),
            'email'        => sanitize_email( $data['email'] ?? '' ),
            'phone'        => sanitize_text_field( $data['phone'] ?? '' ),
            'message'      => sanitize_textarea_field( $data['message'] ?? '' ),
            'service_type' => sanitize_text_field( $data['service_type'] ?? $listing->title ),
            'ip_address'   => $ip,
            'status'       => 'new',
            'source'       => 'api',
            'created_at'   => current_time( 'mysql' ),
        ] );

        gs_notify(
            (int) $listing->vendor_id,
            'lead.new',
            '📞 New Lead Received',
            "New enquiry for: {$listing->title}",
            home_url( '/vendor/dashboard/?section=leads' )
        );
        return rest_ensure_response( [ 'message' => 'Enquiry sent successfully' ] );
    }

    // ── Vendor Stats ──────────────────────────────────────────────────────────
    public static function vendor_stats(): \WP_REST_Response {
        $vendor_id = gs_current_vendor_id();
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $stats = Cache::remember( "api_vendor_stats_{$vendor_id}", 300, function() use ( $wpdb, $pfx, $vendor_id ) {
            return [
                'listings'       => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$pfx}listings WHERE vendor_id=%d AND status='active'", $vendor_id ) ),
                'leads_total'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d", $vendor_id ) ),
                'leads_new'      => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d AND status='new'", $vendor_id ) ),
                'total_views'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(view_count),0) FROM {$pfx}listings WHERE vendor_id=%d", $vendor_id ) ),
                'avg_rating'     => round( (float) $wpdb->get_var( $wpdb->prepare(
                    "SELECT COALESCE(AVG(r.rating),0) FROM {$pfx}reviews r INNER JOIN {$pfx}listings l ON l.id=r.listing_id WHERE l.vendor_id=%d AND r.status='approved'",
                    $vendor_id
                ) ), 1 ),
                'reviews_count'  => (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$pfx}reviews r INNER JOIN {$pfx}listings l ON l.id=r.listing_id WHERE l.vendor_id=%d AND r.status='approved'",
                    $vendor_id
                ) ),
            ];
        } );

        return rest_ensure_response( $stats );
    }

    // ── Me ────────────────────────────────────────────────────────────────────
    public static function get_me(): \WP_REST_Response {
        $user   = wp_get_current_user();
        $vendor = VendorRepository::get_by_user( $user->ID );
        return rest_ensure_response( [
            'id'           => $user->ID,
            'name'         => $user->display_name,
            'email'        => $user->user_email,
            'roles'        => $user->roles,
            'vendor'       => $vendor,
            'is_vendor'    => gs_is_vendor(),
            'is_admin'     => gs_is_admin_level(),
        ] );
    }

    // ── Token ─────────────────────────────────────────────────────────────────
    public static function get_token( \WP_REST_Request $req ): \WP_REST_Response|\WP_Error {
        // SEC FIX: Rate-limit credential attempts to prevent brute-force attacks.
        // Allows 5 attempts per IP per 15 minutes; resets on successful auth.
        $ip     = gs_get_ip();
        $rl_key = 'gs_token_rl_' . md5( $ip );
        $hits   = (int) get_transient( $rl_key );
        if ( $hits >= 5 ) {
            return new \WP_Error(
                'rate_limited',
                'Too many login attempts. Please wait 15 minutes before trying again.',
                [ 'status' => 429 ]
            );
        }

        $creds = $req->get_json_params();
        $user  = wp_authenticate( $creds['username'] ?? '', $creds['password'] ?? '' );
        if ( is_wp_error( $user ) ) {
            // Increment failure counter; starts or extends the 15-minute window
            set_transient( $rl_key, $hits + 1, 15 * MINUTE_IN_SECONDS );
            return new \WP_Error( 'invalid_credentials', 'Invalid credentials', [ 'status' => 401 ] );
        }

        // Successful auth — clear the lockout counter
        delete_transient( $rl_key );

        $token = bin2hex( random_bytes( 32 ) );
        set_transient( 'gs_api_token_' . $token, $user->ID, DAY_IN_SECONDS );
        return rest_ensure_response( [ 'token' => $token, 'user_id' => $user->ID, 'expires_in' => DAY_IN_SECONDS ] );
    }

    // ── Part 29.3 — Webhook endpoints ─────────────────────────────────────────

    public static function register_webhook_routes(): void {
        register_rest_route( self::NS, '/razorpay-webhook', [
            'methods'             => 'POST',
            'callback'            => [ self::class, 'razorpay_webhook' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/stripe-webhook', [
            'methods'             => 'POST',
            'callback'            => [ self::class, 'stripe_webhook' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/booking-status', [
            'methods'             => 'POST',
            'callback'            => [ self::class, 'booking_status_webhook' ],
            'permission_callback' => '__return_true',
        ] );
    }

    /** POST /wp-json/goodservice/v1/razorpay-webhook — payment events */
    /**
     * GET /wp-json/goodservice/v1/verify-email/{token}
     * Real feature — closes a confirmed gap: email_verified was read in
     * one place but never set anywhere, no send flow, no verification
     * link at all. Uses a transient as the token→user_id lookup — a
     * meta_query search across all users for a matching token would be
     * far slower and wouldn't naturally expire.
     */
    public static function verify_email( \WP_REST_Request $req ): \WP_REST_Response {
        $token   = sanitize_text_field( $req->get_param( 'token' ) );
        $user_id = get_transient( 'gs_email_verify_' . $token );

        if ( ! $user_id ) {
            wp_die( 'This verification link is invalid or has expired. Please request a new one from your dashboard.', 'Verification Failed', [ 'response' => 400 ] );
        }

        update_user_meta( (int) $user_id, 'gs_account_email_verified', 1 );
        delete_transient( 'gs_email_verify_' . $token ); // real validation rule: single-use, cannot be replayed

        gs_write_log( "Email verified for user #{$user_id} via token.", 'INFO' );

        wp_safe_redirect( home_url( '/vendor/dashboard/?verified=1' ) );
        exit;
    }

    /**
     * Real feature — generates a 24-hour, single-use verification token
     * and sends the email. Called at registration; also reusable for a
     * future "resend verification email" action without duplicating
     * this logic.
     */
    public static function send_verification_email( int $user_id, string $email, string $name ): void {
        $token = bin2hex( random_bytes( 32 ) );
        set_transient( 'gs_email_verify_' . $token, $user_id, 24 * HOUR_IN_SECONDS );

        \GoodService\Service\EmailService::send( $email, 'verify_email_address', [
            'name'         => $name ?: $email,
            'verify_url'   => rest_url( 'goodservice/v1/verify-email/' . $token ),
        ] );
    }

    public static function razorpay_webhook( \WP_REST_Request $req ): \WP_REST_Response {
        // Verify Razorpay webhook signature
        $sig      = $req->get_header( 'x-razorpay-signature' ) ?? '';
        // Read via Config (benefits from H12 encryption at rest)
        $secret   = \GoodService\Core\Config::get( 'razorpay_webhook_secret', '' );
        if ( ! $secret ) {
            // Fallback to legacy wp-option (pre-Config migration)
            $secret = get_option( 'gs_razorpay_webhook_secret', '' );
        }
        $raw_body = $req->get_body();

        // Reject if secret not configured — never accept unsigned webhooks
        if ( ! $secret ) {
            gs_write_log( 'Razorpay webhook rejected: webhook secret not configured in GoodService settings.' );
            return new \WP_REST_Response( [ 'error' => 'Webhook secret not configured. Set razorpay_webhook_secret in GoodService Settings > Payments.' ], 403 );
        }

        $expected = hash_hmac( 'sha256', $raw_body, $secret );
        if ( ! hash_equals( $expected, $sig ) ) {
            $rejected_event = json_decode( $raw_body, true )['event'] ?? 'unknown';
            gs_write_log( "Razorpay webhook rejected: invalid signature for event: {$rejected_event}" );
            \GoodService\Service\WebhookLogService::log( 'razorpay', (string) $rejected_event, $raw_body, 'rejected', 'Invalid signature', 403 );
            return new \WP_REST_Response( [ 'error' => 'Invalid signature' ], 403 );
        }

        $payload = $req->get_json_params();
        $event   = $payload['event'] ?? '';

        // FIXED — audit gap "webhook dead-letter queue": processing is now
        // wrapped so a thrown exception (a DB failure, a bad-shape payload
        // reaching activate_subscription(), etc.) is captured as a
        // queryable, admin-visible failed row — see WebhookLogService and
        // the admin "Webhooks" screen — instead of either silently
        // vanishing or crashing to a bare 500 with no persisted record.
        // Still returns 500 on failure so Razorpay's own webhook retry
        // policy also gets a chance, with the DLQ as the backstop once
        // that policy gives up.
        try {
            self::process_razorpay_event( $event, $payload );
        } catch ( \Throwable $e ) {
            gs_write_log( "Razorpay webhook processing failed for event {$event}: " . $e->getMessage() );
            \GoodService\Service\WebhookLogService::log( 'razorpay', (string) $event, $raw_body, 'failed', $e->getMessage(), 500 );
            return new \WP_REST_Response( [ 'error' => 'Processing failed, will be retried.' ], 500 );
        }
        \GoodService\Service\WebhookLogService::log( 'razorpay', (string) $event, $raw_body, 'processed', '', 200 );

        return new \WP_REST_Response( [ 'status' => 'ok' ], 200 );
    }

    /**
     * Extracted from razorpay_webhook() so the exact same event-processing
     * logic can be re-run by an admin from the Webhooks DLQ screen
     * (retry_webhook()) using the originally-stored raw payload, without
     * duplicating a second copy of this switch.
     */
    private static function process_razorpay_event( string $event, array $payload ): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        switch ( $event ) {
            case 'payment.captured':
                // Update subscription status to active on successful payment
                $notes       = $payload['payload']['payment']['entity']['notes'] ?? [];
                $vendor_id   = (int) ( $notes['vendor_id'] ?? 0 );
                $plan_id     = (int) ( $notes['plan_id']   ?? 0 );
                $cycle       = sanitize_text_field( $notes['cycle'] ?? 'monthly' );
                $payment_id  = sanitize_text_field( $payload['payload']['payment']['entity']['id'] ?? '' );

                // Real fix — this used to do its own raw subscription
                // UPDATE + a raw gs_invoices INSERT that never set invoice_no
                // (a NOT NULL UNIQUE column — the first such row could
                // insert with an empty string, and a second one would
                // fail outright on the uniqueness constraint). It also
                // duplicated RazorpayService::activate_subscription()'s
                // logic with none of its side effects (real invoice
                // numbering, vendor notification, EventBus event) — two
                // divergent activation paths for the same event.
                //
                // Idempotency: webhooks are expected to fire independently
                // of (and possibly in addition to) the client-side
                // gs_razorpay_verify_payment call for the exact same
                // payment — that's the normal, correct behavior of a
                // webhook, not an edge case. Without checking whether this
                // payment_id was already processed, a payment confirmed
                // both ways would activate two subscriptions and generate
                // two invoices for one payment.
                if ( $vendor_id && $plan_id && $payment_id ) {
                    \GoodService\Service\RazorpayService::activate_subscription( $vendor_id, $plan_id, $payment_id, $cycle );
                    gs_write_log( "Razorpay webhook: payment.captured processed for vendor {$vendor_id} (plan {$plan_id}), payment {$payment_id}." );
                }
                break;

            case 'subscription.cancelled':
                $sub_id = sanitize_text_field( $payload['payload']['subscription']['entity']['id'] ?? '' );
                $wpdb->update(
                    "{$pfx}subscriptions",
                    [ 'status' => 'cancelled', 'updated_at' => current_time( 'mysql' ) ],
                    [ 'razorpay_sub_id' => $sub_id ]
                );
                break;

            case 'payment.failed':
                $notes     = $payload['payload']['payment']['entity']['notes'] ?? [];
                $vendor_id = (int) ( $notes['vendor_id'] ?? 0 );
                if ( $vendor_id ) {
                    $vp = $wpdb->get_row( $wpdb->prepare(
                        "SELECT vp.user_id, vp.business_name, vp.email AS vendor_email FROM {$pfx}vendor_profiles vp WHERE vp.id=%d", $vendor_id
                    ) );
                    if ( $vp ) {
                        \GoodService\Service\NotificationService::create(
                            (int) $vp->user_id, 'payment.failed',
                            '❌ Payment Failed', 'Your subscription payment failed. Please update your payment details.',
                            home_url( '/vendor/dashboard/?section=subscription' ), 'x', '#DC2626'
                        );
                        // Real fix — confirmed gap from full admin-notification
                        // audit: this was in-app only, not even emailed to the
                        // vendor themselves, and admin had zero awareness of
                        // payment failures at all — a real churn signal and
                        // potential gateway-misconfiguration indicator. Uses
                        // gs_vendor_site_email() per explicit request — the
                        // listing's own contact email, not the account/login
                        // email stored on the vendor profile.
                        $notify_email = gs_vendor_site_email( $vendor_id );
                        if ( $notify_email ) {
                            \GoodService\Service\EmailService::send( $notify_email, 'payment_failed_vendor', [
                                'vendor_name' => $vp->business_name ?: 'there',
                            ] );
                        }
                        \GoodService\Service\NotificationService::notify_admins(
                            'payment.failed', '❌ Vendor Payment Failed',
                            ( $vp->business_name ?: 'A vendor' ) . "'s subscription payment attempt failed.",
                            home_url( '/admin-panel/?section=transactions' )
                        );
                        // ENTERPRISE-AUDIT FIX (Part 2, High): starts the dunning
                        // grace period (or records a repeat failure within an
                        // already-running one) — closes "No automatic dunning/
                        // retry cascade for failed recurring payments... no retry
                        // schedule, grace period, or card-update dunning
                        // sequence." See Cron::payment_dunning_cascade() for the
                        // escalating reminders and eventual auto-downgrade.
                        \GoodService\Service\SubscriptionService::start_or_touch_dunning( $vendor_id );
                    }
                }
                break;
        }
    }

    /**
     * POST /wp-json/goodservice/v1/stripe-webhook — payment events.
     * Same governing principle as the Razorpay webhook above: this is
     * the AUTHORITATIVE confirmation path, not the browser returning to
     * success_url — Stripe redirects the browser back based on client-
     * side state that proves nothing on its own. Signature verification
     * happens before anything else touches the payload, exactly like
     * Razorpay's — an unsigned or wrongly-signed request is rejected
     * outright, never partially processed.
     */
    public static function stripe_webhook( \WP_REST_Request $req ): \WP_REST_Response {
        $sig      = $req->get_header( 'stripe-signature' ) ?? '';
        $secret   = \GoodService\Core\Config::get( 'stripe_webhook_secret', '' );
        $raw_body = $req->get_body();

        if ( ! $secret ) {
            gs_write_log( 'Stripe webhook rejected: webhook secret not configured in GoodService settings.' );
            return new \WP_REST_Response( [ 'error' => 'Webhook secret not configured. Set stripe_webhook_secret in GoodService Settings > Payments.' ], 403 );
        }

        if ( ! \GoodService\Service\StripeService::verify_webhook_signature( $raw_body, $sig, $secret ) ) {
            gs_write_log( 'Stripe webhook rejected: invalid signature.' );
            \GoodService\Service\WebhookLogService::log( 'stripe', 'unknown', $raw_body, 'rejected', 'Invalid signature', 403 );
            return new \WP_REST_Response( [ 'error' => 'Invalid signature' ], 403 );
        }

        $payload = $req->get_json_params();
        $event   = $payload['type'] ?? '';

        // FIXED — audit gap "webhook dead-letter queue": see the identical
        // fix and rationale in razorpay_webhook() above.
        try {
            self::process_stripe_event( $event, $payload );
        } catch ( \Throwable $e ) {
            gs_write_log( "Stripe webhook processing failed for event {$event}: " . $e->getMessage() );
            \GoodService\Service\WebhookLogService::log( 'stripe', (string) $event, $raw_body, 'failed', $e->getMessage(), 500 );
            return new \WP_REST_Response( [ 'error' => 'Processing failed, will be retried.' ], 500 );
        }
        \GoodService\Service\WebhookLogService::log( 'stripe', (string) $event, $raw_body, 'processed', '', 200 );

        return new \WP_REST_Response( [ 'status' => 'ok' ], 200 );
    }

    /** Extracted from stripe_webhook() — see process_razorpay_event()'s docblock for why. */
    private static function process_stripe_event( string $event, array $payload ): void {
        switch ( $event ) {
            case 'checkout.session.completed':
                $session   = $payload['data']['object'] ?? [];
                $metadata  = $session['metadata'] ?? [];
                $vendor_id = (int) ( $metadata['vendor_id'] ?? 0 );
                $plan_id   = (int) ( $metadata['plan_id']   ?? 0 );
                $cycle     = in_array( $metadata['cycle'] ?? '', [ 'monthly', 'yearly' ], true ) ? $metadata['cycle'] : 'monthly';
                $payment_id = sanitize_text_field( $session['payment_intent'] ?? ( $session['id'] ?? '' ) );

                if ( $vendor_id && $plan_id && $payment_id && ( $session['payment_status'] ?? '' ) === 'paid' ) {
                    // activate_subscription() is idempotent on payment_id —
                    // safe even if stripeConfirmSession() (the browser's
                    // return-trip handler) already activated this exact
                    // session moments earlier.
                    \GoodService\Service\StripeService::activate_subscription( $vendor_id, $plan_id, $payment_id, $cycle );
                    gs_write_log( "Stripe webhook: checkout.session.completed processed for vendor {$vendor_id} (plan {$plan_id}), payment {$payment_id}." );
                }
                break;

            case 'checkout.session.async_payment_failed':
            case 'payment_intent.payment_failed':
                $obj       = $payload['data']['object'] ?? [];
                $metadata  = $obj['metadata'] ?? [];
                $vendor_id = (int) ( $metadata['vendor_id'] ?? 0 );
                if ( $vendor_id ) {
                    global $wpdb;
                    // ENTERPRISE-AUDIT FIX (Part 2, High): this handler was
                    // previously the weaker of the two gateways' payment.failed
                    // paths — in-app notification only, no vendor email, no
                    // admin alert, and (like the Razorpay path before this same
                    // fix) no dunning/retry cascade at all. Brought up to the
                    // exact same behavior as the Razorpay handler above rather
                    // than left as a second, thinner implementation of the same
                    // event.
                    $vp = $wpdb->get_row( $wpdb->prepare(
                        "SELECT user_id, business_name FROM {$wpdb->prefix}gs_vendor_profiles WHERE id=%d", $vendor_id
                    ) );
                    if ( $vp ) {
                        \GoodService\Service\NotificationService::create(
                            (int) $vp->user_id, 'payment.failed',
                            '❌ Payment Failed', 'Your subscription payment failed. Please update your payment details.',
                            home_url( '/vendor/dashboard/?section=subscription' ), 'x', '#DC2626'
                        );
                        $notify_email = gs_vendor_site_email( $vendor_id );
                        if ( $notify_email ) {
                            \GoodService\Service\EmailService::send( $notify_email, 'payment_failed_vendor', [
                                'vendor_name' => $vp->business_name ?: 'there',
                            ] );
                        }
                        \GoodService\Service\NotificationService::notify_admins(
                            'payment.failed', '❌ Vendor Payment Failed',
                            ( $vp->business_name ?: 'A vendor' ) . "'s subscription payment attempt failed.",
                            home_url( '/admin-panel/?section=transactions' )
                        );
                        \GoodService\Service\SubscriptionService::start_or_touch_dunning( $vendor_id );
                    }
                }
                break;
        }
    }

    /** POST /wp-json/goodservice/v1/booking-status — partner integrations */
    public static function booking_status_webhook( \WP_REST_Request $req ): \WP_REST_Response {
        // CRITICAL SECURITY FIX, confirmed by audit: this check only ran
        // when $stored_key was already non-empty — if no partner API key
        // had ever been configured (the default state for most
        // installs), the entire auth check silently short-circuited,
        // meaning ANY unauthenticated request could modify ANY booking's
        // status. Fixed to fail closed, matching the same "reject if not
        // configured" pattern already used correctly in the Razorpay
        // webhook above.
        $api_key    = $req->get_header( 'x-gs-api-key' ) ?? '';
        $stored_key = get_option( 'gs_partner_api_key', '' );
        if ( ! $stored_key ) {
            gs_write_log( 'Booking status webhook rejected: no partner API key configured.' );
            return new \WP_REST_Response( [ 'error' => 'Partner API key not configured. Set gs_partner_api_key before using this endpoint.' ], 403 );
        }
        if ( ! hash_equals( $stored_key, $api_key ) ) {
            gs_write_log( 'Booking status webhook rejected: invalid API key.' );
            \GoodService\Service\WebhookLogService::log( 'booking_status', 'unknown', $req->get_body(), 'rejected', 'Invalid API key', 403 );
            return new \WP_REST_Response( [ 'error' => 'Unauthorised' ], 403 );
        }
        $data       = $req->get_json_params();
        $raw_body   = $req->get_body();

        // FIXED — audit gap "webhook dead-letter queue" + a ghost-success
        // bug found while fixing it: this previously discarded $wpdb->update()'s
        // return value entirely and always responded 200 'updated' — including
        // when booking_id matched zero rows (typo'd/deleted booking), so a
        // partner integration had no way to ever learn its update silently
        // did nothing. Now checked, and failures land in the same DLQ as
        // every other webhook source above for admin visibility/retry.
        try {
            self::process_booking_status_event( $data );
        } catch ( \Throwable $e ) {
            gs_write_log( 'Booking status webhook processing failed: ' . $e->getMessage() );
            \GoodService\Service\WebhookLogService::log( 'booking_status', 'status_update', $raw_body, 'failed', $e->getMessage(), 422 );
            return new \WP_REST_Response( [ 'error' => $e->getMessage() ], 422 );
        }
        \GoodService\Service\WebhookLogService::log( 'booking_status', 'status_update', $raw_body, 'processed', '', 200 );
        return new \WP_REST_Response( [ 'status' => 'updated' ], 200 );
    }

    /** Extracted from booking_status_webhook() — see process_razorpay_event()'s docblock for why. */
    private static function process_booking_status_event( array $data ): void {
        $booking_id = (int) ( $data['booking_id'] ?? 0 );
        $status     = sanitize_text_field( $data['status'] ?? '' );
        if ( ! $booking_id || ! $status ) {
            throw new \RuntimeException( 'booking_id and status required' );
        }
        global $wpdb;
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_bookings WHERE id=%d", $booking_id
        ) );
        if ( ! $exists ) {
            throw new \RuntimeException( "Booking #{$booking_id} not found." );
        }
        $result = $wpdb->update(
            $wpdb->prefix . 'gs_bookings',
            [ 'status' => $status, 'updated_at' => current_time( 'mysql' ) ],
            [ 'id' => $booking_id ]
        );
        if ( $result === false ) {
            throw new \RuntimeException( "Database error updating booking #{$booking_id}: " . $wpdb->last_error );
        }
    }

    /**
     * GET /wp-json/goodservice/v1/whatsapp-webhook — Meta Cloud API's
     * one-time subscription verification handshake. Meta calls this with
     * hub.mode=subscribe, hub.verify_token, and hub.challenge when the
     * webhook URL is first configured in the Meta App dashboard; it must
     * echo hub.challenge back as plain text if and only if the verify
     * token matches what's configured here. 360dialog/Interakt don't use
     * this handshake — only the POST route matters for those providers.
     */
    public static function whatsapp_webhook_verify( \WP_REST_Request $req ) {
        $mode      = $req->get_param( 'hub_mode' ) ?? $req->get_param( 'hub.mode' );
        $token     = $req->get_param( 'hub_verify_token' ) ?? $req->get_param( 'hub.verify_token' );
        $challenge = $req->get_param( 'hub_challenge' ) ?? $req->get_param( 'hub.challenge' );

        $configured_token = \GoodService\Core\Config::get( 'whatsapp_webhook_verify_token', '' );

        if ( $mode === 'subscribe' && $configured_token && hash_equals( $configured_token, (string) $token ) ) {
            return new \WP_REST_Response( (string) $challenge, 200 );
        }
        gs_write_log( 'WhatsApp webhook verification failed — mode/token mismatch.' );
        return new \WP_REST_Response( [ 'error' => 'Verification failed' ], 403 );
    }

    /**
     * POST /wp-json/goodservice/v1/whatsapp-webhook — receives both
     * delivery-status updates for outbound messages (sent/delivered/read/
     * failed) and inbound replies from customers/vendors. Handles Meta
     * Cloud API's payload shape natively; 360dialog and Interakt use a
     * broadly similar {"statuses":[...]} / {"messages":[...]} shape for
     * their own webhook forwarding, so the same parsing covers all three
     * without provider-specific branching — matched by field presence,
     * not a provider flag, since a misconfigured 'whatsapp_bsp' setting
     * shouldn't be able to make correctly-shaped incoming data unreadable.
     */
    public static function whatsapp_webhook_receive( \WP_REST_Request $req ): \WP_REST_Response {
        $data = $req->get_json_params();
        if ( ! is_array( $data ) ) {
            return new \WP_REST_Response( [ 'error' => 'Invalid payload' ], 400 );
        }
        $raw_body = $req->get_body();

        // FIXED — audit gap "webhook dead-letter queue": see the identical
        // fix and rationale in razorpay_webhook() above. WhatsApp delivery-
        // status/inbound-message processing previously had no exception
        // handling at all — a malformed payload reaching one of the two
        // inner loops below would 500 with nothing recorded anywhere but
        // the PHP error log.
        try {
            $result = self::process_whatsapp_event( $data );
        } catch ( \Throwable $e ) {
            gs_write_log( 'WhatsApp webhook processing failed: ' . $e->getMessage() );
            \GoodService\Service\WebhookLogService::log( 'whatsapp', 'inbound_or_status', $raw_body, 'failed', $e->getMessage(), 500 );
            return new \WP_REST_Response( [ 'error' => 'Processing failed, will be retried.' ], 500 );
        }
        \GoodService\Service\WebhookLogService::log( 'whatsapp', 'inbound_or_status', $raw_body, 'processed', '', 200 );
        return new \WP_REST_Response( array_merge( [ 'status' => 'ok' ], $result ), 200 );
    }

    /** Extracted from whatsapp_webhook_receive() — see process_razorpay_event()'s docblock for why. */
    private static function process_whatsapp_event( array $data ): array {
        global $wpdb;
        $tbl = $wpdb->prefix . 'gs_whatsapp_logs';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) {
            // Table genuinely doesn't exist yet on this install — nothing
            // to update. Not a failure — reported to the caller as ignored.
            return [ 'status' => 'ignored' ];
        }

        // Meta Cloud API nests everything under entry[].changes[].value —
        // 360dialog/Interakt webhook payloads are typically already at
        // the top level ({"statuses":[...]} / {"messages":[...]}
        // directly), so both shapes are checked.
        $values = [];
        if ( ! empty( $data['entry'] ) && is_array( $data['entry'] ) ) {
            foreach ( $data['entry'] as $entry ) {
                foreach ( (array) ( $entry['changes'] ?? [] ) as $change ) {
                    if ( ! empty( $change['value'] ) ) { $values[] = $change['value']; }
                }
            }
        } else {
            $values[] = $data;
        }

        $updated = 0;
        $inbound = 0;

        foreach ( $values as $value ) {
            // ── Delivery status updates (sent/delivered/read/failed) ────────
            foreach ( (array) ( $value['statuses'] ?? [] ) as $status_update ) {
                $provider_id = (string) ( $status_update['id'] ?? '' );
                $status      = (string) ( $status_update['status'] ?? '' );
                if ( ! $provider_id || ! in_array( $status, [ 'sent', 'delivered', 'read', 'failed' ], true ) ) { continue; }

                $timestamp = ! empty( $status_update['timestamp'] )
                    ? date( 'Y-m-d H:i:s', (int) $status_update['timestamp'] )
                    : current_time( 'mysql' );

                $fields = [ 'status' => $status ];
                if ( $status === 'delivered' ) { $fields['delivered_at'] = $timestamp; }
                if ( $status === 'read' )      { $fields['read_at']      = $timestamp; }
                if ( $status === 'failed' && ! empty( $status_update['errors'][0]['title'] ) ) {
                    $fields['error_message'] = substr( (string) $status_update['errors'][0]['title'], 0, 500 );
                }

                $affected = $wpdb->update( $tbl, $fields, [ 'provider_message_id' => $provider_id ] );
                if ( $affected ) { $updated += (int) $affected; }
            }

            // ── Inbound messages (customer/vendor replying via WhatsApp) ────
            // Logged for conversation history; matched to a lead by phone
            // number since an inbound message has no provider_message_id
            // to correlate against an outbound row.
            foreach ( (array) ( $value['messages'] ?? [] ) as $inbound_msg ) {
                $from_phone = preg_replace( '/\D/', '', (string) ( $inbound_msg['from'] ?? '' ) );
                $text       = (string) ( $inbound_msg['text']['body'] ?? '' );
                if ( ! $from_phone ) { continue; }

                $lead_id = (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}gs_leads WHERE phone LIKE %s ORDER BY created_at DESC LIMIT 1",
                    '%' . $wpdb->esc_like( substr( $from_phone, -10 ) )
                ) );

                $wpdb->insert( $tbl, [
                    'lead_id'             => $lead_id,
                    'vendor_id'           => 0,
                    'direction'           => 'inbound',
                    'phone'               => $from_phone,
                    'body'                => substr( $text, 0, 1000 ),
                    'status'              => 'delivered',
                    'provider_message_id' => substr( (string) ( $inbound_msg['id'] ?? '' ), 0, 128 ),
                    'delivered_at'        => current_time( 'mysql' ),
                    'created_at'          => current_time( 'mysql' ),
                ] );
                $inbound++;
            }
        }

        return [ 'statuses_updated' => $updated, 'inbound_logged' => $inbound ];
    }

    /**
     * gs_retry_webhook — ADMIN. Re-runs a previously-failed webhook event
     * from its stored raw payload, dispatching to the same processing
     * method the live handler used originally. See WebhookLogService and
     * the admin "Webhooks" screen. Deliberately re-checks nothing about
     * the original request's signature/API key: a row only exists here
     * because it already passed that check (or was explicitly logged as
     * 'rejected', which this refuses to retry — see below) at receipt
     * time, and retrying is itself an admin-authenticated action gated by
     * AjaxController::retryWebhook()'s own require_admin() call.
     */
    public static function retry_webhook( int $log_id ): array {
        $row = \GoodService\Service\WebhookLogService::get( $log_id );
        if ( ! $row ) { return [ 'error' => 'Webhook log entry not found.' ]; }
        if ( $row->status === 'rejected' ) {
            return [ 'error' => 'Rejected events (bad signature/API key) cannot be retried — the sender must re-deliver with a corrected credential.' ];
        }
        $payload = json_decode( (string) $row->payload, true );
        if ( ! is_array( $payload ) ) { $payload = []; }

        try {
            switch ( $row->source ) {
                case 'razorpay':
                    self::process_razorpay_event( $row->event_type, $payload );
                    break;
                case 'stripe':
                    self::process_stripe_event( $row->event_type, $payload );
                    break;
                case 'booking_status':
                    self::process_booking_status_event( $payload );
                    break;
                case 'whatsapp':
                    self::process_whatsapp_event( $payload );
                    break;
                default:
                    return [ 'error' => "Unknown webhook source \"{$row->source}\" — cannot retry." ];
            }
        } catch ( \Throwable $e ) {
            \GoodService\Service\WebhookLogService::mark_retried_failure( $log_id, $e->getMessage() );
            return [ 'error' => 'Retry failed: ' . $e->getMessage() ];
        }

        \GoodService\Service\WebhookLogService::mark_retried_success( $log_id );
        return [ 'success' => true ];
    }

}
