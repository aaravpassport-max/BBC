<?php
namespace GoodService\SEO;

/**
 * Real feature — closes a confirmed gap: the "Description popup" content
 * for Products and Services (products_data[]/services_data[], including
 * their richer view_more_sections detail content) was completely absent
 * from every SEO module in this codebase, verified by grepping the
 * entire src/SEO tree before writing this. Shared here because both
 * SeoSectionAuditor (completion scoring) and ContentAnalysisModule
 * (keyword/readability analysis) need the same extraction logic, and it
 * must mirror the real renderer exactly: vendor-site.php's own
 * vsRenderDetailSection() JS function, which is the actual, live
 * definition of what content each content_type holds. Field names
 * (name/description/view_more_sections) verified directly against the
 * real create-listing.php form output, not assumed.
 */
final class SeoContentExtractor {

    /**
     * Decodes a listing's products_data or services_data JSON column
     * into a normalized array, filtering out empty/unnamed entries the
     * same way the rest of this codebase already does elsewhere
     * (SeoSectionAuditor::items(), vendor-site.php's own item loops).
     */
    public static function decode_items( ?string $json ): array {
        $raw = json_decode( (string) ( $json ?? '[]' ), true );
        if ( ! is_array( $raw ) ) { return []; }
        return array_values( array_filter( $raw, fn( $i ) => is_array( $i ) && trim( (string) ( $i['name'] ?? '' ) ) !== '' ) );
    }

    /**
     * Extracts all human-readable text from a single item's
     * view_more_sections popup content — the actual "Description
     * popup" the user is referring to. Mirrors vsRenderDetailSection()'s
     * switch on content_type exactly, field for field, so this measures
     * the same content a customer actually sees in the popup, not a
     * guess at its shape.
     */
    public static function extract_view_more_text( $view_more_sections ): string {
        $sections = is_string( $view_more_sections )
            ? ( json_decode( $view_more_sections, true ) ?: [] )
            : ( is_array( $view_more_sections ) ? $view_more_sections : [] );
        if ( ! is_array( $sections ) ) { return ''; }

        $parts = [];
        foreach ( $sections as $sec ) {
            if ( ! is_array( $sec ) ) { continue; }
            if ( ! empty( $sec['title'] ) ) { $parts[] = (string) $sec['title']; }
            switch ( $sec['content_type'] ?? 'richtext' ) {
                case 'faq':
                case 'accordion':
                    foreach ( (array) ( $sec['faq_items'] ?? [] ) as $item ) {
                        if ( ! is_array( $item ) ) { continue; }
                        $parts[] = (string) ( $item['q'] ?? '' );
                        $parts[] = (string) ( $item['a'] ?? '' );
                    }
                    break;
                case 'list':
                case 'numbered_list':
                    foreach ( (array) ( $sec['list_items'] ?? [] ) as $li ) { $parts[] = (string) $li; }
                    break;
                case 'table':
                    foreach ( (array) ( $sec['list_items'] ?? [] ) as $row ) {
                        $parts[] = str_replace( '|', ' ', (string) $row );
                    }
                    break;
                case 'cards':
                    foreach ( (array) ( $sec['list_items'] ?? [] ) as $item ) {
                        // Format is "icon||title||text" — same split vendor-site.php's own renderer uses.
                        $bits = explode( '||', (string) $item );
                        $parts[] = $bits[1] ?? '';
                        $parts[] = $bits[2] ?? '';
                    }
                    break;
                case 'gallery':
                    // Images only — genuinely no text content in this section type.
                    break;
                case 'highlight':
                    $parts[] = (string) ( $sec['body'] ?? '' );
                    break;
                case 'specs':
                    // Real feature — Specifications/Features repeater.
                    // name/value pairs are genuine content (e.g. "Minimum
                    // Order Quantity: 1 Piece") that should count toward
                    // this listing's content completeness the same way
                    // FAQ text already does.
                    foreach ( (array) ( $sec['spec_items'] ?? [] ) as $item ) {
                        if ( ! is_array( $item ) ) { continue; }
                        $parts[] = (string) ( $item['name'] ?? '' );
                        $parts[] = (string) ( $item['value'] ?? '' );
                    }
                    break;
                default: // richtext — TinyMCE HTML, already sanitized on save
                    $parts[] = (string) ( $sec['body'] ?? '' );
            }
        }
        // strip_tags handles the richtext/highlight HTML case; plain
        // strings from other content_types pass through unaffected.
        return trim( strip_tags( implode( ' ', array_filter( $parts, fn( $p ) => trim( (string) $p ) !== '' ) ) ) );
    }

    /**
     * The full text for one product/service item: its short description
     * plus everything inside its view_more_sections popup — this is the
     * complete "Description popup" content the user is referring to,
     * combined into one string for keyword/readability analysis.
     */
    /**
     * Extracts real <h2>/<h3> heading text specifically from richtext/
     * highlight Manage Details sections — separate from
     * extract_view_more_text() deliberately, since that method strips
     * all HTML (including real headings) before word-count/keyword
     * analysis and the crawlable sr-only rendering, both of which
     * correctly want plain text. This exists so heading structure
     * within popup content can be checked on its own terms, closing a
     * gap where a vendor's real <h2>/<h3> tags in a richtext section
     * were invisible to every heading-related check in this codebase.
     */
    public static function extract_view_more_headings( $view_more_sections ): array {
        $sections = is_string( $view_more_sections )
            ? ( json_decode( $view_more_sections, true ) ?: [] )
            : ( is_array( $view_more_sections ) ? $view_more_sections : [] );
        if ( ! is_array( $sections ) ) { return []; }

        $headings = [];
        foreach ( $sections as $sec ) {
            if ( ! is_array( $sec ) ) { continue; }
            $type = $sec['content_type'] ?? 'richtext';
            if ( ! in_array( $type, [ 'richtext', 'highlight' ], true ) ) { continue; }
            $body = (string) ( $sec['body'] ?? '' );
            preg_match_all( '/<h[23][^>]*>(.*?)<\/h[23]>/is', $body, $matches );
            foreach ( $matches[1] ?? [] as $h ) {
                $text = trim( strip_tags( $h ) );
                if ( $text !== '' ) { $headings[] = $text; }
            }
        }
        return $headings;
    }

    /**
     * All real <h2>/<h3> heading text across every item's Manage
     * Details content for a listing — used to check whether popup
     * content includes the focus keyword in a heading, the same
     * standard already applied to the main description elsewhere.
     */
    public static function all_items_headings( object $listing ): array {
        $items = array_merge(
            self::decode_items( $listing->products_data ?? null ),
            self::decode_items( $listing->services_data ?? null )
        );
        $all = [];
        foreach ( $items as $item ) {
            $all = array_merge( $all, self::extract_view_more_headings( $item['view_more_sections'] ?? [] ) );
        }
        return $all;
    }

    /**
     * All text content from FAQ, process steps, why-choose points, team
     * bios, and portfolio project descriptions, combined into one block
     * — real feature, closing a confirmed gap: none of this content
     * contributed to any scored SEO check anywhere in this codebase
     * (verified by grepping every SEO module before writing this), the
     * same pattern already found and fixed for products/services,
     * replicated across five more content sections. Field names
     * verified directly against the real vendor-site.php rendering
     * loops, not guessed.
     */
    public static function all_other_sections_text( object $listing ): string {
        $parts = [];

        $faqs = json_decode( (string) ( $listing->faq_data ?? '[]' ), true ) ?: [];
        foreach ( $faqs as $f ) {
            if ( ! empty( $f['question'] ?? null ) ) { $parts[] = (string) $f['question']; }
            if ( ! empty( $f['answer'] ?? null ) ) { $parts[] = trim( strip_tags( (string) $f['answer'] ) ); }
        }

        $process = json_decode( (string) ( $listing->process_data ?? '[]' ), true ) ?: [];
        foreach ( $process as $p ) {
            if ( ! empty( $p['title'] ?? null ) ) { $parts[] = (string) $p['title']; }
            if ( ! empty( $p['description'] ?? null ) ) { $parts[] = (string) $p['description']; }
        }

        $why = json_decode( (string) ( $listing->why_choose_data ?? '[]' ), true ) ?: [];
        foreach ( $why as $w ) {
            if ( ! is_array( $w ) ) { continue; } // real validation rule: skips the non-item 'section_title' key mixed into this array
            if ( ! empty( $w['title'] ?? null ) ) { $parts[] = (string) $w['title']; }
            if ( ! empty( $w['description'] ?? null ) ) { $parts[] = (string) $w['description']; }
        }

        $team = json_decode( (string) ( $listing->team_data ?? '[]' ), true ) ?: [];
        foreach ( $team as $t ) {
            if ( ! empty( $t['role'] ?? null ) ) { $parts[] = (string) $t['role']; }
            if ( ! empty( $t['bio'] ?? null ) ) { $parts[] = (string) $t['bio']; }
        }

        $portfolio = json_decode( (string) ( $listing->portfolio_data ?? '[]' ), true ) ?: [];
        foreach ( $portfolio as $p ) {
            if ( ! empty( $p['title'] ?? null ) ) { $parts[] = (string) $p['title']; }
            if ( ! empty( $p['description'] ?? null ) ) { $parts[] = (string) $p['description']; }
        }

        return trim( implode( ' ', array_filter( $parts, fn( $p ) => trim( $p ) !== '' ) ) );
    }

    public static function item_full_text( array $item ): string {
        $short = trim( (string) ( $item['description'] ?? '' ) );
        $popup = self::extract_view_more_text( $item['view_more_sections'] ?? [] );
        return trim( $short . ' ' . $popup );
    }

    /**
     * All products_data + services_data content for a listing, combined
     * into one block of text — used by ContentAnalysisModule to fold
     * this content into the same keyword/readability checks every other
     * piece of listing content already goes through.
     */
    public static function all_items_text( object $listing ): string {
        $items = array_merge(
            self::decode_items( $listing->products_data ?? null ),
            self::decode_items( $listing->services_data ?? null )
        );
        $texts = array_map( fn( $i ) => self::item_full_text( $i ), $items );
        return trim( implode( ' ', array_filter( $texts ) ) );
    }
}
