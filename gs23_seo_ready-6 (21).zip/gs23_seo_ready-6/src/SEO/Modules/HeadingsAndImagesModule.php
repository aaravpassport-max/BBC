<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;
use GoodService\SEO\FocusKeywordResolver;

/**
 * Heading hierarchy and image alt-text coverage — both long-documented
 * public factors: a single, descriptive H1 per page has been standard
 * HTML/SEO guidance since the H1 tag existed, and alt text is required
 * by WCAG accessibility standards as well as being how search engines
 * understand image content (they can't "see" pixels).
 */
final class HeadingsAndImagesModule implements SeoModuleInterface {

    public function key(): string { return 'headings_images'; }
    public function label(): string { return 'Headings & Images'; }

    public function evaluate( object $listing ): array {
        $checks = [];
        $title = trim( (string) ( $listing->seo_title ?: $listing->title ?? '' ) );

        // ── Single, descriptive H1 ─────────────────────────────────
        // Your render already emits exactly one <h1> per listing page
        // (confirmed in vendor-site.php) — this check verifies its
        // CONTENT quality, not just presence.
        $h1_source = trim( (string) ( $listing->title ?? '' ) );
        if ( $h1_source === '' ) {
            $checks[] = SeoCheckResult::fail( 'h1_content', 'H1 heading has content', 15, 'critical',
                'Your page heading would fall back to a generic phrase since no business name is set.',
                'Set your business name — it drives the main heading visitors and Google see first.' );
        } elseif ( mb_strlen( $h1_source ) < 3 ) {
            $checks[] = SeoCheckResult::partial( 'h1_content', 'H1 heading has content', 5, 15, 'medium',
                'Your business name is very short for a main heading.', 'Consider a more descriptive business name if possible.' );
        } else {
            $checks[] = SeoCheckResult::pass( 'h1_content', 'H1 heading has content', 15,
                'Your main heading is set and descriptive.' );
        }

        // ── Alt text coverage across the gallery ────────────────────
        // Alt text is scored per-image because a gallery with 1 of 8
        // images described is meaningfully different from one with 8 of
        // 8 — a single pass/fail for "has alt text" would hide that.
        // Real fix: gallery is stored as a JSON array directly on the
        // listings row (confirmed via Router.php's query and its JSON
        // field list), not a separate table as originally assumed here.
        // ASSUMPTION FLAGGED: each gallery item's alt-text field is
        // assumed to be keyed 'alt' — verify this against your actual
        // JSON structure and adjust if the real key name differs.
        $gallery_raw = json_decode( (string) ( $listing->gallery ?? '[]' ), true );
        $images = is_array( $gallery_raw ) ? $gallery_raw : [];
        $total = count( $images );
        $with_alt = count( array_filter( $images, fn( $img ) => is_array( $img ) && trim( (string) ( $img['alt'] ?? '' ) ) !== '' ) );

        if ( $total === 0 ) {
            // No penalty here — the Gallery section (SeoSectionAuditor)
            // already covers "no photos at all" as its own critical issue.
            $checks[] = SeoCheckResult::pass( 'alt_coverage', 'Image alt text', 20,
                'No gallery images yet — nothing to check here until photos are added.' );
        } elseif ( $with_alt === $total ) {
            $checks[] = SeoCheckResult::pass( 'alt_coverage', 'Image alt text', 20,
                "All {$total} gallery images have descriptive alt text." );
        } else {
            $missing = $total - $with_alt;
            $pct = (int) round( ( $with_alt / $total ) * 100 );
            $checks[] = SeoCheckResult::partial( 'alt_coverage', 'Image alt text', (int) round( 20 * ( $with_alt / $total ) ), 20,
                $missing > $total / 2 ? 'high' : 'medium',
                "{$missing} of {$total} gallery images are missing alt text ({$pct}% covered).",
                'Add a short description to each photo (e.g. "Kitchen renovation completed in Mumbai") — this helps both accessibility and image search visibility.' );
        }

        // ── Focus keyword relevance in alt text ────────────────────────
        // Beyond just existing, alt text that actually describes the
        // service/location is what search engines can use to understand
        // image relevance — "IMG_4021.jpg"-style or generic alt text
        // technically "exists" but provides no real signal.
        $category = trim( (string) ( $listing->subcat_name ?? $listing->cat_name ?? '' ) );
        $city = trim( (string) ( $listing->city ?? '' ) );
        $focus_keyword = FocusKeywordResolver::resolve( $listing );
        $explicit = FocusKeywordResolver::is_explicit( $listing );
        if ( $with_alt > 0 && $focus_keyword ) {
            $relevant = 0;
            foreach ( $images as $img ) {
                $alt = strtolower( trim( (string) ( $img['alt'] ?? '' ) ) );
                if ( $alt === '' ) { continue; }
                $match = $explicit
                    ? str_contains( $alt, strtolower( $focus_keyword ) )
                    : ( str_contains( $alt, strtolower( $category ) ) || ( $city && str_contains( $alt, strtolower( $city ) ) ) );
                if ( $match ) { $relevant++; }
            }
            $checks[] = $relevant > 0
                ? SeoCheckResult::pass( 'alt_relevance', 'Alt text mentions focus keyword', 10,
                    "{$relevant} of {$with_alt} image(s) with alt text mention your focus keyword." )
                : SeoCheckResult::fail( 'alt_relevance', 'Alt text mentions focus keyword', 10, 'low',
                    'Your image alt text exists but doesn\'t mention your focus keyword in any of it.',
                    "Rewrite at least a couple of alt texts to include \"{$focus_keyword}\" naturally." );
        }

        return $checks;
    }
}
