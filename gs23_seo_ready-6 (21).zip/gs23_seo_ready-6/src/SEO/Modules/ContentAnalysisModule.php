<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;
use GoodService\SEO\FocusKeywordResolver;

/**
 * The broader on-page content checklist — every one of these is
 * independently, publicly documented across the SEO industry (Google's
 * own Search Central guidance, and cross-verified by Moz/Ahrefs/Backlinko
 * writeups on ranking factors). None of it is read from or modeled on
 * any specific competitor's implementation.
 */
final class ContentAnalysisModule implements SeoModuleInterface {

    public function key(): string { return 'content_analysis'; }
    public function label(): string { return 'Content Quality'; }

    public function evaluate( object $listing ): array {
        $checks = [];
        $body = trim( (string) ( $listing->full_desc ?: $listing->short_desc ?? '' ) );
        // Real fix — confirmed gap: Products/Services description popup
        // content (products_data[]/services_data[], including their
        // richer view_more_sections detail content) was never part of
        // this analysis at all. Folded into the same body every other
        // check below already runs against — keyword density,
        // readability, subheadings, link balance, paragraph length —
        // so this content genuinely contributes to every metric, not
        // just an isolated "did you fill it in" completion check.
        $items_text = \GoodService\SEO\SeoContentExtractor::all_items_text( $listing );
        if ( $items_text !== '' ) {
            $body = trim( $body . ' ' . $items_text );
        }
        // Real fix — confirmed gap: FAQ, process steps, why-choose
        // points, team bios, and portfolio descriptions contributed to
        // zero scored SEO check anywhere in this codebase (verified by
        // grepping every module before writing this), the same pattern
        // already found and fixed for products/services.
        $other_sections_text = \GoodService\SEO\SeoContentExtractor::all_other_sections_text( $listing );
        if ( $other_sections_text !== '' ) {
            $body = trim( $body . ' ' . $other_sections_text );
        }
        $title = trim( (string) ( $listing->seo_title ?: $listing->title ?? '' ) );
        $category = trim( (string) ( $listing->subcat_name ?? $listing->cat_name ?? '' ) );
        $city = trim( (string) ( $listing->city ?? '' ) );
        // Real fix: this line was hardcoded to the inferred guess despite
        // its own variable name claiming to be the focus keyword — now
        // genuinely resolves the real field, falling back to the guess
        // only when no explicit keyword has been set.
        $focus_keyword = FocusKeywordResolver::resolve( $listing );

        // ── Focus keyword in the first 10% of content ────────────────
        // Long-established practice: search engines historically weight
        // early-appearing terms more heavily as a relevance signal.
        if ( $focus_keyword && $body ) {
            $first_chunk = mb_substr( $body, 0, (int) max( 50, mb_strlen( $body ) * 0.1 ) );
            $in_opening = FocusKeywordResolver::is_explicit( $listing )
                ? stripos( $first_chunk, $focus_keyword ) !== false
                : ( stripos( $first_chunk, $category ) !== false || stripos( $first_chunk, $city ) !== false );
            $checks[] = $in_opening
                ? SeoCheckResult::pass( 'keyword_opening', 'Focus keyword in opening', 10,
                    'Your service/city appears early in your description — this reinforces relevance.' )
                : SeoCheckResult::fail( 'keyword_opening', 'Focus keyword in opening', 10, 'medium',
                    'Your service category or city doesn\'t appear in the first part of your description.',
                    "Mention \"{$focus_keyword}\" naturally in your opening sentence." );
        }

        // ── Keyword density (not too sparse, not stuffed) ────────────
        // A well-known balance: near-zero mentions signals weak topical
        // relevance; excessive repetition reads as keyword stuffing and
        // has been explicitly discouraged by Google's own guidance for
        // over a decade.
        if ( $focus_keyword && $body ) {
            $measured_term = FocusKeywordResolver::is_explicit( $listing ) ? $focus_keyword : $category;
            if ( $measured_term ) {
                $word_count = max( 1, str_word_count( $body ) );
                $mentions = substr_count( strtolower( $body ), strtolower( $measured_term ) );
                $density = ( $mentions / $word_count ) * 100;
                if ( $mentions === 0 ) {
                    $checks[] = SeoCheckResult::fail( 'keyword_density', 'Keyword usage', 10, 'high',
                        "Your focus keyword (\"{$measured_term}\") isn't mentioned anywhere in your description.",
                        "Mention \"{$measured_term}\" 2-3 times naturally throughout your description." );
                } elseif ( $density > 3 ) {
                    $checks[] = SeoCheckResult::partial( 'keyword_density', 'Keyword usage', 5, 10, 'low',
                        'Your focus keyword is repeated quite often — this can look like keyword stuffing to Google.',
                        'Reduce repetition and use natural variations instead (synonyms, related phrases).' );
                } else {
                    $checks[] = SeoCheckResult::pass( 'keyword_density', 'Keyword usage', 10,
                        'Your focus keyword is mentioned naturally throughout your description.' );
                }
            }
        }

        // ── Readability (sentence length) ─────────────────────────────
        // Shorter average sentence length is a widely-used readability
        // heuristic (the same underlying idea behind Flesch Reading
        // Ease, published and public since 1948) — easier content
        // generally keeps visitors on the page longer.
        if ( $body ) {
            $sentences = max( 1, preg_match_all( '/[.!?]+/', $body ) );
            $words = str_word_count( $body );
            $avg_sentence_len = $words / $sentences;
            if ( $avg_sentence_len > 25 ) {
                $checks[] = SeoCheckResult::partial( 'readability', 'Readability', 5, 10, 'low',
                    'Your sentences average ' . round( $avg_sentence_len ) . ' words — quite long, which can be harder to read.',
                    'Break long sentences into shorter ones. Aim for under 20 words per sentence on average.' );
            } else {
                $checks[] = SeoCheckResult::pass( 'readability', 'Readability', 10,
                    'Your sentences are an easy-to-read length.' );
            }
        }

        // Real internal-link suggestions (naming actual related listings)
        // now live in InternalLinkingModule — removed the generic
        // duplicate flag that used to be here.

        // ── Focus keyword in subheadings ────────────────────────────
        // Descriptions go through wp_kses_post(), so real <h2>/<h3> tags
        // are genuinely possible if a vendor uses rich formatting — this
        // parses the actual HTML rather than assuming headings exist.
        preg_match_all( '/<h[23][^>]*>(.*?)<\/h[23]>/is', $body, $heading_matches );
        $headings = array_map( fn( $h ) => trim( strip_tags( $h ) ), $heading_matches[1] ?? [] );
        if ( ! empty( $headings ) && $focus_keyword ) {
            $explicit = FocusKeywordResolver::is_explicit( $listing );
            $kw_in_heading = false;
            foreach ( $headings as $h ) {
                $match = $explicit
                    ? stripos( $h, $focus_keyword ) !== false
                    : ( stripos( $h, $category ) !== false || ( $city && stripos( $h, $city ) !== false ) );
                if ( $match ) { $kw_in_heading = true; break; }
            }
            $checks[] = $kw_in_heading
                ? SeoCheckResult::pass( 'keyword_subheadings', 'Focus keyword in subheadings', 8,
                    'At least one subheading includes your focus keyword.' )
                : SeoCheckResult::fail( 'keyword_subheadings', 'Focus keyword in subheadings', 8, 'low',
                    'None of your subheadings mention your focus keyword.',
                    "If you use subheadings in your description, include \"{$focus_keyword}\" in at least one." );
        }
        // No penalty when there are no subheadings at all — a short
        // business description with no headings isn't inherently wrong,
        // this check only applies when headings already exist.

        // ── External links, and internal/external balance ────────────
        // A page that links out ONLY (or ONLY inward, exclusively) both
        // read as less natural than a healthy mix — pure "internal only"
        // can look walled-off, pure "external only" sends all authority
        // away. This checks real <a href> tags in the actual content.
        preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\']/i', $body, $link_matches );
        $links = $link_matches[1] ?? [];
        $home_host = wp_parse_url( home_url(), PHP_URL_HOST );
        $internal = 0; $external = 0;
        foreach ( $links as $href ) {
            $host = wp_parse_url( $href, PHP_URL_HOST );
            if ( $host === null || $host === $home_host ) { $internal++; } else { $external++; }
        }
        if ( $external === 0 ) {
            $checks[] = SeoCheckResult::fail( 'external_links', 'External links', 6, 'low',
                'Your description has no external links.',
                'Consider linking to one credible external source if relevant — e.g. an industry certification body or association you belong to.' );
        } else {
            $checks[] = SeoCheckResult::pass( 'external_links', 'External links', 6,
                "Your description links to {$external} external source(s)." );
        }
        if ( $internal > 0 && $external > 0 ) {
            $checks[] = SeoCheckResult::pass( 'link_balance', 'Internal/external link balance', 4,
                "Good mix: {$internal} internal, {$external} external link(s)." );
        } elseif ( $internal > 0 || $external > 0 ) {
            $checks[] = SeoCheckResult::partial( 'link_balance', 'Internal/external link balance', 2, 4, 'low',
                $internal > 0 ? 'All your links are internal — none point outward.' : 'All your links are external — none point to other pages on this platform.',
                'Aim for a mix of both internal (related listings) and external (credible sources) links.' );
        }

        // ── Paragraph length ───────────────────────────────────────────
        // Long, unbroken paragraphs are a well-documented readability
        // deterrent — the same underlying idea behind Flesch scoring
        // applied at paragraph rather than sentence level.
        $paragraphs = preg_split( '/<\/p>|\n{2,}/i', strip_tags( $body, '<p>' ) );
        $paragraphs = array_filter( array_map( 'trim', $paragraphs ) );
        if ( ! empty( $paragraphs ) ) {
            $long_paragraphs = array_filter( $paragraphs, fn( $p ) => str_word_count( $p ) > 150 );
            $checks[] = empty( $long_paragraphs )
                ? SeoCheckResult::pass( 'short_paragraphs', 'Short, scannable paragraphs', 6,
                    'Your paragraphs are a reasonable, scannable length.' )
                : SeoCheckResult::partial( 'short_paragraphs', 'Short, scannable paragraphs', 3, 6, 'low',
                    count( $long_paragraphs ) . ' paragraph(s) are quite long (150+ words).',
                    'Break long paragraphs into shorter ones — 2-4 sentences each is easier to scan on mobile.' );
        }

        return $checks;
    }
}
