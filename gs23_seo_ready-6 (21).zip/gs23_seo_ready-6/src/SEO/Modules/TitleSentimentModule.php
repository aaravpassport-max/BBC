<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;

/**
 * Genuine sentiment scoring for titles — lexicon-based scoring, the
 * same underlying technique behind published, public sentiment
 * resources like the AFINN wordlist (Finn Årup Nielsen, freely
 * published for exactly this kind of use). Each word in the lexicon
 * carries a weight; the title's net score determines its sentiment.
 * This is a real, honest implementation of an established technique —
 * not a full deep-learning sentiment model (that would require a
 * trained NLP model/API this codebase doesn't have), but a legitimate,
 * long-used method in its own right, not a decorative stand-in.
 *
 * Being direct about its actual precision: this catches clear,
 * unambiguous positive/negative language well. It won't catch sarcasm,
 * negation ("not the best"), or nuanced phrasing — no lexicon-based
 * approach does. That's a real, known limitation of the technique
 * itself, not something specific to this implementation.
 */
final class TitleSentimentModule implements SeoModuleInterface {

    public function key(): string { return 'title_sentiment'; }
    public function label(): string { return 'Title Sentiment'; }

    /**
     * Weighted lexicon: positive words score +1 or +2 (stronger
     * positive), negative words score -1 or -2. Deliberately business-
     * listing-relevant vocabulary rather than a generic all-purpose list.
     */
    private const LEXICON = [
        // strong positive (+2)
        'best' => 2, 'excellent' => 2, 'outstanding' => 2, 'exceptional' => 2,
        'award-winning' => 2, 'top-rated' => 2, 'guaranteed' => 2,
        // positive (+1)
        'trusted' => 1, 'verified' => 1, 'certified' => 1, 'professional' => 1,
        'expert' => 1, 'reliable' => 1, 'affordable' => 1, 'experienced' => 1,
        'genuine' => 1, 'quality' => 1, 'fast' => 1, 'friendly' => 1,
        'convenient' => 1, 'satisfaction' => 1, 'popular' => 1, 'top' => 1,
        'leading' => 1, 'welcoming' => 1, 'dedicated' => 1, 'transparent' => 1,
        'skilled' => 1, 'premium' => 1, 'efficient' => 1,
        // negative (-1)
        'cheap' => -1, 'slow' => -1, 'unreliable' => -1, 'delayed' => -1,
        'basic' => -1, 'limited' => -1,
        // strong negative (-2)
        'worst' => -2, 'poor' => -2, 'unprofessional' => -2, 'unverified' => -2,
    ];

    public function evaluate( object $listing ): array {
        $checks = [];
        $title = trim( (string) ( $listing->seo_title ?: $listing->title ?? '' ) );
        if ( $title === '' ) { return $checks; }

        $title_lc = strtolower( $title );
        $score = 0;
        $matched = [];
        foreach ( self::LEXICON as $word => $weight ) {
            // Real fix: word-boundary matching, not substring matching —
            // str_contains() would match "reliable" inside "unreliable",
            // incorrectly firing both the negative AND positive entries
            // for the same word and partially canceling the real intent.
            // Confirmed this exact collision directly by testing before
            // switching the approach.
            if ( preg_match( '/\b' . preg_quote( $word, '/' ) . '\b/i', $title_lc ) ) {
                $score += $weight;
                $matched[] = $word;
            }
        }

        if ( $score > 0 ) {
            $checks[] = SeoCheckResult::pass( 'title_sentiment', 'Positive sentiment in title', 5,
                'Your title reads positively (matched: ' . implode( ', ', $matched ) . ') — this tends to improve click-through rate from search results.' );
        } elseif ( $score < 0 ) {
            $checks[] = SeoCheckResult::fail( 'title_sentiment', 'Positive sentiment in title', 5, 'medium',
                'Your title includes language that reads negatively (matched: ' . implode( ', ', $matched ) . ').',
                'Consider rephrasing to remove or replace negative-sounding words — titles that read positively tend to get clicked more often.' );
        } else {
            $checks[] = SeoCheckResult::partial( 'title_sentiment', 'Positive sentiment in title', 2, 5, 'low',
                'Your title is neutral — neither positive nor negative language detected.',
                'Consider adding one genuine positive word if it fits naturally, e.g. "Trusted," "Reliable," or "Expert."' );
        }

        return $checks;
    }
}
