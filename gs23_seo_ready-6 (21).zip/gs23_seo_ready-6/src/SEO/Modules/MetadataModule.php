<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;
use GoodService\SEO\FocusKeywordResolver;

/**
 * Scores the title, meta description, URL slug, and H1 for one listing.
 *
 * Every threshold below is public, documented SEO knowledge — Google's
 * own guidance on SERP snippet truncation, and long-established on-page
 * factors independently described by Search Console docs, Moz, and
 * Ahrefs. None of it is read from, or reproduces, any third-party
 * plugin's implementation.
 */
final class MetadataModule implements SeoModuleInterface {

    public function key(): string { return 'metadata'; }
    public function label(): string { return 'Title & Description'; }

    public function evaluate( object $listing ): array {
        global $wpdb;
        $checks = [];

        $title = trim( (string) ( $listing->seo_title ?: $listing->title ?? '' ) );
        $desc  = trim( (string) ( $listing->seo_desc ?? '' ) );
        $slug  = trim( (string) ( $listing->slug ?? '' ) );
        $category = trim( (string) ( $listing->subcat_name ?? $listing->cat_name ?? '' ) );
        $city  = trim( (string) ( $listing->city ?? '' ) );

        // ── Explicit focus keyword set ──────────────────────────────
        // Real gap closed this round: this platform has a genuine
        // seo_focus_keyword field that every module was ignoring in
        // favor of an inferred category+city guess. An inferred guess
        // is a reasonable default, but a vendor deliberately choosing
        // their own target phrase is more precise and more in their
        // control.
        $checks[] = FocusKeywordResolver::is_explicit( $listing )
            ? SeoCheckResult::pass( 'focus_keyword_set', 'Focus keyword set', 5,
                'You\'ve set a specific focus keyword — your other checks are scored against exactly what you want to rank for.' )
            : SeoCheckResult::partial( 'focus_keyword_set', 'Focus keyword set', 2, 5, 'low',
                'No focus keyword explicitly set — currently using your category and city as a reasonable default.',
                'Set a specific focus keyword in your listing SEO settings for more precise scoring, e.g. "emergency plumber in Mumbai" instead of just your category.' );

        // ── Title length ─────────────────────────────────────────────
        // Google truncates SERP titles around ~580-600px, which maps to
        // roughly 50-60 characters for most Latin-script fonts. This is
        // Google's own documented rendering behavior, not any plugin's rule.
        $len = mb_strlen( $title );
        if ( $len === 0 ) {
            $checks[] = SeoCheckResult::fail( 'title_length', 'Title length', 15, 'critical',
                'This listing has no title at all — the most important on-page SEO signal is missing.',
                'Add a title that includes your service category and city, e.g. "Plumbing Services in Mumbai — YourBusinessName".' );
        } elseif ( $len < 30 ) {
            $checks[] = SeoCheckResult::partial( 'title_length', 'Title length', 5, 15, 'high',
                "Your title is only {$len} characters — too short to include your service and location together.",
                'Aim for 50-60 characters. Include what you do and where, e.g. "Best Home Cleaning Services in Pune — Sparkle Co."' );
        } elseif ( $len > 60 ) {
            $checks[] = SeoCheckResult::partial( 'title_length', 'Title length', 8, 15, 'medium',
                "Your title is {$len} characters. Google typically cuts titles off around 60 characters in search results.",
                'Shorten to under 60 characters so the full title shows in search results instead of being cut off with "...".' );
        } else {
            $checks[] = SeoCheckResult::pass( 'title_length', 'Title length', 15,
                "Title is {$len} characters — within the range Google typically displays in full." );
        }

        // ── Title contains focus keyword ────────────────────────────
        // Local intent matching (service + location in the title) is a
        // well-established local-SEO factor since it mirrors how people
        // actually search ("plumber near me in <city>"). Checks the
        // REAL focus keyword when a vendor has set one explicitly —
        // this was the specific gap found and fixed this round: the
        // resolver existed but wasn't actually wired into this check.
        if ( FocusKeywordResolver::is_explicit( $listing ) ) {
            $keyword = FocusKeywordResolver::resolve( $listing );
            $has_keyword = stripos( $title, $keyword ) !== false;
            $checks[] = $has_keyword
                ? SeoCheckResult::pass( 'title_relevance', 'Title includes focus keyword', 15,
                    "Your title includes your focus keyword (\"{$keyword}\")." )
                : SeoCheckResult::fail( 'title_relevance', 'Title includes focus keyword', 15, 'critical',
                    "Your title doesn't include your focus keyword (\"{$keyword}\").",
                    "Rework your title to naturally include \"{$keyword}\"." );
        } else {
            $has_category = $category && stripos( $title, $category ) !== false;
            $has_city     = $city && stripos( $title, $city ) !== false;
            if ( $has_category && $has_city ) {
                $checks[] = SeoCheckResult::pass( 'title_relevance', 'Title includes service + city', 15,
                    'Your title includes both your service category and city — this matches how customers actually search.' );
            } elseif ( $has_category || $has_city ) {
                $checks[] = SeoCheckResult::partial( 'title_relevance', 'Title includes service + city', 8, 15, 'high',
                    $has_category ? 'Your title mentions your service but not your city.' : 'Your title mentions your city but not your service.',
                    "Include both, e.g. \"{$category} in {$city}\" — people search by service AND location together." );
            } else {
                $checks[] = SeoCheckResult::fail( 'title_relevance', 'Title includes service + city', 15, 'critical',
                    'Your title doesn\'t mention your service category or your city.',
                    "Rewrite it to include both, e.g. \"{$category} in {$city} — YourBusinessName\"." );
            }
        }

        // ── Title uniqueness across the platform ─────────────────────
        // Genuinely platform-specific: on a marketplace, many vendors in
        // the same category/city can end up with near-identical
        // auto-generated titles, which creates internal duplicate-title
        // competition — vendors ranking against each other instead of
        // against outside competitors.
        if ( $title !== '' ) {
            $dupes = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}gs_listings WHERE (seo_title = %s OR (seo_title = '' AND title = %s)) AND id != %d AND status = 'active'",
                $title, $title, $listing->id ?? 0
            ) );
            if ( $dupes > 0 ) {
                $checks[] = SeoCheckResult::fail( 'title_uniqueness', 'Title is unique on the platform', 10, 'high',
                    "{$dupes} other active listing(s) on this platform have the exact same title — you're competing with your own marketplace, not just outside sites.",
                    'Add something that makes your listing distinct: your business name, a specialty, or years of experience.' );
            } else {
                $checks[] = SeoCheckResult::pass( 'title_uniqueness', 'Title is unique on the platform', 10,
                    'No other listing on this platform shares this exact title.' );
            }
        }

        // ── Meta description length ──────────────────────────────────
        // Google's snippet display is commonly ~120-158 characters on
        // desktop before truncation — again Google's own rendering
        // behavior, independently documented across the industry.
        $dlen = mb_strlen( $desc );
        if ( $dlen === 0 ) {
            $checks[] = SeoCheckResult::fail( 'desc_length', 'Meta description', 15, 'critical',
                'No meta description is set — Google will auto-generate one from your page content, which is usually worse at convincing people to click.',
                'Write a 1-2 sentence summary of what you offer and why to choose you, 120-158 characters long.' );
        } elseif ( $dlen < 70 ) {
            $checks[] = SeoCheckResult::partial( 'desc_length', 'Meta description', 6, 15, 'medium',
                "Your description is only {$dlen} characters — you're leaving room in the search snippet unused.",
                'Expand to 120-158 characters. Mention your service, location, and one reason to choose you.' );
        } elseif ( $dlen > 160 ) {
            $checks[] = SeoCheckResult::partial( 'desc_length', 'Meta description', 10, 15, 'low',
                "Your description is {$dlen} characters — Google will likely cut it off in search results.",
                'Trim to under 160 characters so the full description shows without truncation.' );
        } else {
            $checks[] = SeoCheckResult::pass( 'desc_length', 'Meta description', 15,
                "Description is {$dlen} characters — a good length for search result snippets." );
        }

        // ── URL slug quality ──────────────────────────────────────────
        // Short, readable, hyphen-separated URLs are an established best
        // practice — both for users scanning a URL and for how search
        // engines have historically weighted URL relevance signals.
        $slug_words = $slug ? substr_count( $slug, '-' ) + 1 : 0;
        if ( $slug === '' ) {
            $checks[] = SeoCheckResult::fail( 'url_slug', 'URL is clean and readable', 5, 'medium',
                'This listing has no URL slug set.', 'Set a short, descriptive slug based on your business name.' );
        } elseif ( $slug_words > 8 || mb_strlen( $slug ) > 75 ) {
            $checks[] = SeoCheckResult::partial( 'url_slug', 'URL is clean and readable', 2, 5, 'low',
                'Your URL is quite long, which can look untrustworthy in search results and is harder to share.',
                'Shorten the URL to just your business name and category — drop filler words.' );
        } else {
            $checks[] = SeoCheckResult::pass( 'url_slug', 'URL is clean and readable', 5,
                'Your URL is short and readable.' );
        }

        // ── Focus keyword in meta description ─────────────────────────
        // Checking presence, not just length — a description can be
        // perfectly-sized and still never mention what the page is for.
        // Checks the real focus keyword when explicitly set — this was
        // part of the same gap found and fixed this round.
        if ( $desc !== '' ) {
            if ( FocusKeywordResolver::is_explicit( $listing ) ) {
                $keyword = FocusKeywordResolver::resolve( $listing );
                $kw_in_desc = stripos( $desc, $keyword ) !== false;
                $checks[] = $kw_in_desc
                    ? SeoCheckResult::pass( 'keyword_in_desc', 'Focus keyword in description', 10,
                        "Your meta description includes your focus keyword (\"{$keyword}\")." )
                    : SeoCheckResult::fail( 'keyword_in_desc', 'Focus keyword in description', 10, 'medium',
                        "Your meta description doesn't include your focus keyword (\"{$keyword}\").",
                        "Rework your description to naturally include \"{$keyword}\"." );
            } elseif ( $category ) {
                $kw_in_desc = stripos( $desc, $category ) !== false || ( $city && stripos( $desc, $city ) !== false );
                $checks[] = $kw_in_desc
                    ? SeoCheckResult::pass( 'keyword_in_desc', 'Focus keyword in description', 10,
                        'Your meta description mentions your service or city.' )
                    : SeoCheckResult::fail( 'keyword_in_desc', 'Focus keyword in description', 10, 'medium',
                        'Your meta description doesn\'t mention your service category or city.',
                        "Rework your description to naturally include \"{$category}\" or \"{$city}\"." );
            }
        }

        // ── Focus keyword in permalink ────────────────────────────────
        // Checked word-by-word, not as one phrase — a slug uses hyphens
        // ("emergency-plumber-mumbai"), so a strict phrase match against
        // a space-separated keyword would incorrectly fail even when
        // every word is genuinely present.
        if ( $slug !== '' ) {
            $slug_lc = strtolower( str_replace( '-', ' ', $slug ) );
            if ( FocusKeywordResolver::is_explicit( $listing ) ) {
                $keyword = FocusKeywordResolver::resolve( $listing );
                $kw_words = array_filter( explode( ' ', strtolower( $keyword ) ) );
                $matched_words = array_filter( $kw_words, fn( $w ) => str_contains( $slug_lc, $w ) );
                $kw_in_slug = count( $kw_words ) > 0 && count( $matched_words ) >= ceil( count( $kw_words ) / 2 );
                $checks[] = $kw_in_slug
                    ? SeoCheckResult::pass( 'keyword_in_url', 'Focus keyword in URL', 10,
                        "Your URL includes words from your focus keyword (\"{$keyword}\")." )
                    : SeoCheckResult::fail( 'keyword_in_url', 'Focus keyword in URL', 10, 'low',
                        "Your URL doesn't reflect your focus keyword (\"{$keyword}\").",
                        "If possible, include the key words from \"{$keyword}\" in the URL slug." );
            } elseif ( $category ) {
                $kw_in_slug = stripos( $slug_lc, strtolower( $category ) ) !== false || ( $city && stripos( $slug_lc, strtolower( $city ) ) !== false );
                $checks[] = $kw_in_slug
                    ? SeoCheckResult::pass( 'keyword_in_url', 'Focus keyword in URL', 10,
                        'Your URL includes your service or city — reinforces relevance to both users and search engines.' )
                    : SeoCheckResult::fail( 'keyword_in_url', 'Focus keyword in URL', 10, 'low',
                        'Your URL doesn\'t include your service category or city.',
                        'If possible, include your business name and category/city in the URL slug.' );
            }
        }

        return $checks;
    }
}
