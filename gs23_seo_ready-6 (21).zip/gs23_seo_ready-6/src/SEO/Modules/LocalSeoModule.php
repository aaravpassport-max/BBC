<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;

/**
 * Local SEO — the single biggest gap for a service-vendor marketplace
 * specifically, since every listing here IS inherently a local page.
 * NAP (Name, Address, Phone) consistency and complete location data are
 * publicly well-documented local-ranking factors, independently
 * confirmed across Google's own Business Profile guidance and every
 * major local-SEO resource — not specific to any one tool.
 */
final class LocalSeoModule implements SeoModuleInterface {

    public function key(): string { return 'local_seo'; }
    public function label(): string { return 'Local SEO'; }

    public function evaluate( object $listing ): array {
        global $wpdb;
        $checks = [];
        $p = $wpdb->prefix . 'gs_';

        // ── NAP completeness ──────────────────────────────────────────
        // Name, Address, Phone together (not scattered/partial) is the
        // foundational local-SEO signal — consistently listed across
        // Google's own local ranking guidance as a baseline requirement.
        $name_ok = trim( (string) ( $listing->title ?? '' ) ) !== '';
        $addr_ok = trim( (string) ( $listing->address ?? '' ) ) !== '';
        $phone_ok = trim( (string) ( $listing->phone ?? '' ) ) !== '';
        $nap_complete = $name_ok && $addr_ok && $phone_ok;
        $checks[] = $nap_complete
            ? SeoCheckResult::pass( 'nap_complete', 'NAP (Name, Address, Phone) complete', 25,
                'Your business name, address, and phone are all set — the foundation of local search visibility.' )
            : SeoCheckResult::fail( 'nap_complete', 'NAP (Name, Address, Phone) complete', 25, 'critical',
                'Your NAP (Name, Address, Phone) is incomplete — this is the single most important local SEO factor.',
                'Fill in whichever is missing: ' . implode( ', ', array_filter( [ $name_ok ? null : 'business name', $addr_ok ? null : 'address', $phone_ok ? null : 'phone' ] ) ) . '.' );

        // ── NAP consistency across listing vs vendor profile ──────────
        // A mismatch between the listing's own phone/address and the
        // parent vendor profile's is a real, checkable inconsistency
        // that can confuse both customers and search engines about
        // which is authoritative.
        $vp = $wpdb->get_row( $wpdb->prepare(
            "SELECT phone, address FROM {$p}vendor_profiles WHERE id = %d", $listing->vendor_id ?? 0
        ) );
        if ( $vp && trim( (string) $vp->phone ) !== '' && trim( (string) ( $listing->phone ?? '' ) ) !== '' ) {
            $phones_match = preg_replace( '/\D/', '', $vp->phone ) === preg_replace( '/\D/', '', $listing->phone );
            $checks[] = $phones_match
                ? SeoCheckResult::pass( 'nap_consistency', 'Phone matches vendor profile', 15,
                    'This listing\'s phone number matches the vendor profile — consistent contact info.' )
                : SeoCheckResult::fail( 'nap_consistency', 'Phone matches vendor profile', 15, 'medium',
                    'This listing\'s phone number differs from the main vendor profile\'s phone number.',
                    'Inconsistent contact info across your own pages can confuse customers and weaken local trust signals. Make sure both match, or update whichever is outdated.' );
        }

        // ── City-specific relevance ────────────────────────────────────
        // Beyond just having a city field set, the city should actually
        // appear in customer-facing content — a listing that never
        // mentions its own city in its description is a weaker local
        // signal than the field alone provides.
        $city = trim( (string) ( $listing->city ?? '' ) );
        $desc = trim( (string) ( $listing->full_desc ?: $listing->short_desc ?? '' ) );
        if ( $city !== '' && $desc !== '' ) {
            $mentions = substr_count( strtolower( $desc ), strtolower( $city ) );
            $checks[] = $mentions > 0
                ? SeoCheckResult::pass( 'city_in_content', 'City mentioned in description', 15,
                    "\"{$city}\" is mentioned in your description — reinforces local relevance." )
                : SeoCheckResult::fail( 'city_in_content', 'City mentioned in description', 15, 'medium',
                    "Your city (\"{$city}\") is set as a field but never mentioned in your actual description.",
                    "Mention \"{$city}\" naturally 1-2 times in your description — e.g. \"serving {$city} for over 5 years.\"" );
        }

        // ── Service area beyond a single city ─────────────────────────
        // Corrected from an earlier mistake: I'd removed this check
        // claiming no such field existed — I was searching for
        // "service_areas" when the real column is "service_cities"
        // (confirmed this time, including a migration comment
        // explicitly referencing it). Whether a vendor serves
        // surrounding areas is directly relevant local-intent
        // information for nearby-location searches.
        $service_cities_raw = json_decode( (string) ( $listing->service_cities ?? '[]' ), true );
        $service_cities = is_array( $service_cities_raw ) ? array_filter( $service_cities_raw ) : [];
        $checks[] = ! empty( $service_cities )
            ? SeoCheckResult::pass( 'service_area', 'Service area defined', 15,
                'You\'ve specified ' . count( $service_cities ) . ' additional area(s) you serve beyond your primary city.' )
            : SeoCheckResult::fail( 'service_area', 'Service area defined', 15, 'low',
                'No additional service areas specified beyond your primary city.',
                'If you serve nearby towns or neighborhoods, list them — this helps you show up in searches from those areas too.' );

        // ── Local listing count on platform (density signal) ──────────
        // Genuinely platform-specific: how many other active listings
        // exist in the same city gives a rough read on local search
        // competitiveness — useful context a vendor wouldn't otherwise see.
        $local_count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$p}listings WHERE city = %s AND status = 'active' AND id != %d",
            $city, $listing->id ?? 0
        ) );
        $checks[] = SeoCheckResult::pass( 'local_density', 'Local competition context', 5,
            $local_count === 0
                ? "You're currently the only active listing in {$city} on this platform."
                : "There are {$local_count} other active listing(s) in {$city} — a complete, detailed profile matters more with local competition present." );

        return $checks;
    }
}
