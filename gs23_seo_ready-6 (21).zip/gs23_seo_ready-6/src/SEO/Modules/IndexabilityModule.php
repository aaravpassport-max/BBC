<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;

/**
 * The foundational check that has to pass before anything else matters:
 * can this page actually be indexed and crawled at all? Robots
 * directives and canonical tags are both open web standards (defined by
 * the robots exclusion protocol and W3C/Google's canonical spec), not
 * proprietary to any SEO tool.
 */
final class IndexabilityModule implements SeoModuleInterface {

    public function key(): string { return 'indexability'; }
    public function label(): string { return 'Indexability'; }

    public function evaluate( object $listing ): array {
        $checks = [];

        // A listing accidentally marked noindex is a critical, silent
        // failure — everything else could be perfect and the page still
        // wouldn't appear in search at all.
        $is_noindex = ! empty( $listing->seo_robots ) && str_contains( (string) $listing->seo_robots, 'noindex' );
        $checks[] = $is_noindex
            ? SeoCheckResult::fail( 'noindex_check', 'Page is indexable', 40, 'critical',
                'This listing is set to "noindex" — Google will NOT show it in search results at all, regardless of anything else being correct.',
                'Remove the noindex setting from this listing immediately unless it was intentional.' )
            : SeoCheckResult::pass( 'noindex_check', 'Page is indexable', 40,
                'This page is indexable — no robots directive is blocking it.' );

        // Listing status directly determines whether the page is even
        // publicly reachable — a draft/pending listing has nothing to
        // rank regardless of its content quality.
        $status = (string) ( $listing->status ?? '' );
        $checks[] = $status === 'active'
            ? SeoCheckResult::pass( 'status_active', 'Listing is live', 30,
                'This listing is active and publicly visible.' )
            : SeoCheckResult::fail( 'status_active', 'Listing is live', 30, 'critical',
                "This listing's status is \"{$status}\" — it isn't publicly visible, so none of its SEO matters until it's published.",
                'Publish this listing to make it visible to search engines and customers.' );

        // A canonical URL prevents duplicate-content confusion if the
        // same listing is ever reachable via more than one URL pattern.
        $checks[] = SeoCheckResult::pass( 'canonical_auto', 'Canonical URL set', 10,
            'This platform automatically sets a canonical URL for every listing page.' );

        return $checks;
    }
}
