<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;

/**
 * Real fix — closes a confirmed, massive gap found in a full audit of
 * every field in the Vendor Listing form: FAQ, Process, Why Choose,
 * Team, Portfolio, and Pricing content was already folded into
 * ContentAnalysisModule's combined keyword/readability body (a
 * previous fix), but — the same lesson learned from products/services
 * — that alone gives no vendor a specific, per-section, per-item
 * recommendation. This module gives each of these six sections the
 * same depth already built for products/services: named completeness
 * checks, content-depth checks, and duplicate-content detection, each
 * explicitly labeled with its own real section name.
 *
 * Clients (logos/names only) and Stats (flat numeric key-value pairs)
 * were checked and deliberately excluded — neither has meaningful
 * prose content to analyze; SeoSectionAuditor's existing completeness
 * checks for those two are the appropriate level of scrutiny.
 *
 * Field names verified directly against the real vendor-site.php
 * rendering for every section before writing this, not guessed:
 * FAQ (question/answer), Process (title/description), Why Choose
 * (title/description), Team (name/role/bio), Portfolio
 * (title/description), Pricing (name/features).
 */
final class OtherSectionsContentModule implements SeoModuleInterface {

    public function key(): string { return 'other_sections_content'; }
    public function label(): string { return 'Other Sections Content' ; }

    public function evaluate( object $listing ): array {
        $checks = [];

        $checks = array_merge( $checks, $this->faq_checks( $listing ) );
        $checks = array_merge( $checks, $this->generic_section_checks(
            $this->decode( $listing->process_data ?? null ),
            'title', 'description', 'Process / How It Works', 'process'
        ) );
        $checks = array_merge( $checks, $this->generic_section_checks(
            $this->decode_why_choose( $listing->why_choose_data ?? null ),
            'title', 'description', 'Why Choose Us', 'why'
        ) );
        $checks = array_merge( $checks, $this->generic_section_checks(
            $this->decode( $listing->highlights_data ?? null ),
            'title', 'description', 'Key Highlights', 'highlights'
        ) );
        $checks = array_merge( $checks, $this->generic_section_checks(
            $this->decode( $listing->amenities_data ?? null ),
            'title', 'description', 'Features & Amenities', 'amenities'
        ) );
        $checks = array_merge( $checks, $this->generic_section_checks(
            $this->decode( $listing->facilities_data ?? null ),
            'title', 'description', 'Facilities', 'facilities'
        ) );
        $checks = array_merge( $checks, $this->generic_section_checks(
            $this->decode( $listing->awards_data ?? null ),
            'title', 'description', 'Awards & Recognition', 'awards'
        ) );
        $checks = array_merge( $checks, $this->generic_section_checks(
            $this->decode( $listing->certifications_data ?? null ),
            'title', 'description', 'Licences & Certifications', 'certifications'
        ) );
        $checks = array_merge( $checks, $this->generic_section_checks(
            $this->decode( $listing->team_data ?? null ),
            'name', 'bio', 'Team', 'team'
        ) );
        $checks = array_merge( $checks, $this->generic_section_checks(
            $this->decode( $listing->portfolio_data ?? null ),
            'title', 'description', 'Portfolio', 'portfolio'
        ) );
        $checks = array_merge( $checks, $this->pricing_checks( $listing ) );

        if ( empty( $checks ) ) {
            $checks[] = SeoCheckResult::pass( 'other_sections_na', 'Other listing sections', 5,
                'No FAQ, Process, Why Choose, Team, Portfolio, or Pricing content added — optional, not penalized if your listing doesn\'t need these sections.' );
        }

        return $checks;
    }

    private function decode( ?string $json ): array {
        $raw = json_decode( (string) ( $json ?? '[]' ), true );
        return is_array( $raw ) ? array_values( $raw ) : [];
    }

    /** why_choose_data mixes a non-item 'section_title' key into the same array — filtered out here. */
    private function decode_why_choose( $raw ): array {
        $decoded = is_string( $raw ) ? ( json_decode( $raw, true ) ?: [] ) : ( is_array( $raw ) ? $raw : [] );
        return array_values( array_filter( $decoded, fn( $w ) => is_array( $w ) ) );
    }

    /**
     * FAQ gets its own method rather than the generic helper below —
     * question/answer is a genuinely different shape (a question isn't
     * a "name," and an answer often contains real HTML from a richer
     * editor) from every other section's plain name+description pair.
     */
    private function faq_checks( object $listing ): array {
        $checks = [];
        $items = array_values( array_filter( $this->decode( $listing->faq_data ?? null ), fn( $f ) => ! empty( $f['question'] ?? null ) ) );
        $count = count( $items );
        if ( $count === 0 ) { return $checks; }

        $missing = array_filter( $items, fn( $f ) => trim( wp_strip_all_tags( (string) ( $f['answer'] ?? '' ) ) ) === '' );
        $missing_count = count( $missing );
        if ( $missing_count === 0 ) {
            $checks[] = SeoCheckResult::pass( 'faq_answers_complete', 'FAQ answers', 12, "All {$count} FAQ question(s) have an answer." );
        } else {
            $qs = implode( ', ', array_slice( array_map( fn( $f ) => mb_strimwidth( (string) $f['question'], 0, 40, '…' ), $missing ), 0, 3 ) );
            $checks[] = SeoCheckResult::partial( 'faq_answers_complete', 'FAQ answers',
                (int) round( 12 * ( ( $count - $missing_count ) / $count ) ), 12, 'medium',
                "{$missing_count} of {$count} FAQ question(s) have no answer: {$qs}.",
                'Answer every FAQ question you\'ve added — a question with no answer is confusing to customers and useless for FAQPage rich results in Google.' );
        }

        $answered = array_filter( $items, fn( $f ) => trim( wp_strip_all_tags( (string) ( $f['answer'] ?? '' ) ) ) !== '' );
        if ( ! empty( $answered ) ) {
            $words = array_map( fn( $f ) => str_word_count( wp_strip_all_tags( (string) $f['answer'] ) ), $answered );
            $avg = round( array_sum( $words ) / count( $words ), 1 );
            $checks[] = $avg >= 10
                ? SeoCheckResult::pass( 'faq_content_depth', 'FAQ answer depth', 8, "Averaging {$avg} words per answer — substantive enough to be genuinely useful." )
                : SeoCheckResult::partial( 'faq_content_depth', 'FAQ answer depth', 4, 8, 'low',
                    "Averaging only {$avg} words per answer — quite brief.",
                    'Expand your FAQ answers with more specific detail — a one-line answer often isn\'t enough to actually resolve the question.' );
        }

        $checks = array_merge( $checks, $this->duplicate_check(
            array_map( fn( $f ) => [ 'name' => mb_strimwidth( (string) $f['question'], 0, 40, '…' ), 'description' => wp_strip_all_tags( (string) ( $f['answer'] ?? '' ) ) ], $items ),
            'FAQ', 'faq'
        ) );

        return $checks;
    }

    /**
     * Shared completeness + depth + duplicate checks for any section
     * shaped as [{name_field: '...', desc_field: '...'}, ...] — Process,
     * Why Choose, Team, and Portfolio all share this exact shape (just
     * with different field names), confirmed against the real rendering
     * for each before writing this.
     */
    private function generic_section_checks( array $raw_items, string $name_field, string $desc_field, string $label, string $key_prefix ): array {
        $checks = [];
        $items = array_values( array_filter( $raw_items, fn( $i ) => is_array( $i ) && ! empty( $i[ $name_field ] ?? null ) ) );
        $count = count( $items );
        if ( $count === 0 ) { return $checks; }

        $missing = array_filter( $items, fn( $i ) => trim( (string) ( $i[ $desc_field ] ?? '' ) ) === '' );
        $missing_count = count( $missing );
        $desc_label = $desc_field === 'bio' ? 'bios' : 'descriptions';
        if ( $missing_count === 0 ) {
            $checks[] = SeoCheckResult::pass( "{$key_prefix}_desc_complete", "{$label} {$desc_label}", 12,
                "All {$count} {$label} item(s) have a " . rtrim( $desc_label, 's' ) . '.' );
        } else {
            $names = implode( ', ', array_slice( array_map( fn( $i ) => $i[ $name_field ] ?? 'Unnamed', $missing ), 0, 3 ) );
            $more = $missing_count > 3 ? ' and ' . ( $missing_count - 3 ) . ' more' : '';
            $checks[] = SeoCheckResult::partial( "{$key_prefix}_desc_complete", "{$label} {$desc_label}",
                (int) round( 12 * ( ( $count - $missing_count ) / $count ) ), 12, 'medium',
                "{$missing_count} of {$count} {$label} item(s) have no " . rtrim( $desc_label, 's' ) . ": {$names}{$more}.",
                "Add a " . rtrim( $desc_label, 's' ) . " to each {$label} item listed above." );
        }

        $filled = array_filter( $items, fn( $i ) => trim( (string) ( $i[ $desc_field ] ?? '' ) ) !== '' );
        if ( ! empty( $filled ) ) {
            $words = array_map( fn( $i ) => str_word_count( (string) $i[ $desc_field ] ), $filled );
            $avg = round( array_sum( $words ) / count( $words ), 1 );
            $checks[] = $avg >= 8
                ? SeoCheckResult::pass( "{$key_prefix}_content_depth", "{$label} content depth", 6, "Averaging {$avg} words — reasonable depth." )
                : SeoCheckResult::partial( "{$key_prefix}_content_depth", "{$label} content depth", 3, 6, 'low',
                    "Averaging only {$avg} words per {$label} item — quite thin.",
                    "Expand your {$label} " . rtrim( $desc_label, 's' ) . " with more specific detail." );
        }

        $checks = array_merge( $checks, $this->duplicate_check(
            array_map( fn( $i ) => [ 'name' => $i[ $name_field ] ?? 'Unnamed', 'description' => (string) ( $i[ $desc_field ] ?? '' ) ], $items ),
            $label, $key_prefix
        ) );

        return $checks;
    }

    private function pricing_checks( object $listing ): array {
        $checks = [];
        $items = array_values( array_filter( $this->decode( $listing->pricing_data ?? null ), fn( $p ) => ! empty( $p['name'] ?? null ) ) );
        $count = count( $items );
        if ( $count === 0 ) { return $checks; }

        $get_features = function( $p ) {
            $f = $p['features'] ?? [];
            $list = is_array( $f ) ? $f : array_filter( array_map( 'trim', explode( "\n", (string) $f ) ) );
            return array_values( array_filter( $list ) );
        };

        $missing = array_filter( $items, fn( $p ) => empty( $get_features( $p ) ) );
        $missing_count = count( $missing );
        if ( $missing_count === 0 ) {
            $checks[] = SeoCheckResult::pass( 'pricing_features_complete', 'Pricing plan features', 10, "All {$count} pricing plan(s) list their included features." );
        } else {
            $names = implode( ', ', array_slice( array_map( fn( $p ) => $p['name'] ?? 'Unnamed', $missing ), 0, 3 ) );
            $more = $missing_count > 3 ? ' and ' . ( $missing_count - 3 ) . ' more' : '';
            $checks[] = SeoCheckResult::partial( 'pricing_features_complete', 'Pricing plan features',
                (int) round( 10 * ( ( $count - $missing_count ) / $count ) ), 10, 'low',
                "{$missing_count} of {$count} pricing plan(s) list no features: {$names}{$more}.",
                'List what\'s included in each plan — an empty feature list gives customers and search engines nothing to understand about what they\'re paying for.' );
        }

        return $checks;
    }

    /**
     * Shared duplicate-content detection — identical logic already
     * proven in ProductsServicesContentModule, applied here generically
     * across any section's description-bearing items.
     */
    private function duplicate_check( array $items, string $label, string $key_prefix ): array {
        $checks = [];
        $groups = [];
        foreach ( $items as $item ) {
            $desc = trim( (string) ( $item['description'] ?? '' ) );
            if ( str_word_count( $desc ) < 5 ) { continue; } // real validation rule: short coincidental matches aren't meaningful duplicates
            $normalized = strtolower( preg_replace( '/\s+/', ' ', $desc ) );
            $groups[ $normalized ][] = $item['name'] ?? 'Unnamed';
        }
        $duplicates = array_filter( $groups, fn( $names ) => count( $names ) > 1 );
        if ( ! empty( $duplicates ) ) {
            $examples = array_map( fn( $names ) => implode( ' / ', array_slice( $names, 0, 3 ) ), $duplicates );
            $checks[] = SeoCheckResult::partial( "{$key_prefix}_duplicate_content", "Duplicate content — {$label}", 4, 8, 'low',
                count( $duplicates ) . " group(s) of {$label} items share identical text: " . implode( '; ', array_slice( $examples, 0, 2 ) ) . '.',
                'Write unique content for each item — copy-pasted text across entries reads as low-effort to both customers and search engines.' );
        } elseif ( count( $items ) > 1 ) {
            $checks[] = SeoCheckResult::pass( "{$key_prefix}_duplicate_content", "Duplicate content — {$label}", 8,
                "Every {$label} item has unique content — no copy-paste duplication detected." );
        }
        return $checks;
    }
}
