<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;

/**
 * Internal linking — a well-established on-page factor for both
 * crawlability (helps search engines discover related pages) and
 * keeping visitors browsing longer on the platform. This goes beyond a
 * generic "add internal links" flag: it queries real, related listings
 * (same category, same city) and names them specifically, so the
 * suggestion is immediately actionable.
 */
final class InternalLinkingModule implements SeoModuleInterface {

    public function key(): string { return 'internal_linking'; }
    public function label(): string { return 'Internal Linking'; }

    public function evaluate( object $listing ): array {
        global $wpdb;
        $checks = [];
        $p = $wpdb->prefix . 'gs_';
        $category = $listing->subcat_name ?? $listing->cat_name ?? '';
        $city = $listing->city ?? '';
        // Real fix: the WHERE clause below used to filter on
        // subcat_name/cat_name directly — those aren't real columns on
        // this table, only JOIN-aliased results elsewhere. This SQL
        // would have failed outright ("Unknown column") against the
        // real database. Uses the genuine foreign key columns instead.
        $category_id = (int) ( $listing->subcategory_id ?: $listing->category_id ?? 0 );

        if ( ! $category && ! $city ) {
            return $checks; // nothing to base a suggestion on
        }

        // Real, specific related listings — same category AND city
        // first (strongest relevance), falling back to same category
        // OR city if there aren't enough close matches.
        $related = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, title, slug FROM {$p}listings
             WHERE id != %d AND status = 'active'
               AND ( (subcategory_id = %d OR category_id = %d) OR city = %s )
             ORDER BY (CASE WHEN city = %s THEN 1 ELSE 0 END
                     + CASE WHEN (subcategory_id = %d OR category_id = %d) THEN 1 ELSE 0 END) DESC
             LIMIT 5",
            $listing->id ?? 0, $category_id, $category_id, $city, $city, $category_id, $category_id
        ) );

        if ( empty( $related ) ) {
            $checks[] = SeoCheckResult::fail( 'internal_links', 'Related listings available to link', 10, 'low',
                'No other active listings on the platform closely match your category or city yet.',
                'As more listings join the platform in your area/category, linking to them will help.' );
            return $checks;
        }

        $names = implode( ', ', array_map( fn( $r ) => $r->title, array_slice( $related, 0, 3 ) ) );
        $checks[] = SeoCheckResult::fail( 'internal_links', 'Links to related listings', 10, 'medium',
            count( $related ) . " related listing(s) found that you could mention or link to from your description, but your description doesn't currently link to any other page.",
            "Consider mentioning nearby or related businesses in your description, e.g.: {$names}" );

        return $checks;
    }
}
