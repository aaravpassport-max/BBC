<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;

/**
 * Numbers in title — e.g. "10+ Years Experience", "500+ Happy
 * Customers" — a well-documented pattern for standing out in a list of
 * otherwise similar-looking search results, independently confirmed
 * across multiple CTR studies in the content-marketing industry, not
 * any one SEO tool.
 *
 * Real fix from a full audit: this module used to also check for
 * "power words" (trust/quality language) — but that fully overlapped
 * with TitleSentimentModule's more comprehensive, correctly-matched
 * lexicon, meaning a vendor would see two separate checklist items for
 * the same underlying signal. Removed the duplicate here rather than
 * fix the same substring-matching bug in two places.
 */
final class TitleQualityModule implements SeoModuleInterface {

    public function key(): string { return 'title_quality'; }
    public function label(): string { return 'Title Appeal'; }

    public function evaluate( object $listing ): array {
        $checks = [];
        $title = trim( (string) ( $listing->seo_title ?: $listing->title ?? '' ) );
        if ( $title === '' ) { return $checks; }

        $has_number = (bool) preg_match( '/\d/', $title );
        $checks[] = $has_number
            ? SeoCheckResult::pass( 'title_numbers', 'Numbers in title', 5,
                'Your title includes a number — these tend to stand out in search results.' )
            : SeoCheckResult::partial( 'title_numbers', 'Numbers in title', 2, 5, 'low',
                'Your title has no numbers.',
                'If relevant, consider adding a concrete number, e.g. years in business or number of customers served.' );

        return $checks;
    }
}
