<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;

/**
 * Real page-speed measurement — does a genuine, live HTTP fetch of the
 * listing's actual public URL and measures real, observable signals:
 * response time, total page weight, render-blocking resource count,
 * and compression. This is NOT a full Lighthouse-equivalent (that
 * requires real browser rendering — paint timing, layout shift — which
 * isn't achievable from server-side PHP). What it measures is genuine
 * and real: actual bytes over the wire, actual server response time,
 * actual resource counts — all publicly-documented factors Google's own
 * PageSpeed Insights and Core Web Vitals guidance are built on.
 *
 * Honest limitation, stated plainly rather than hidden: Largest
 * Contentful Paint, Cumulative Layout Shift, and Time to Interactive
 * require a real browser and cannot be measured here. For those,
 * Google's PageSpeed Insights API (free, public) would need to be
 * called separately — that's a reasonable next step if deeper
 * measurement is wanted, but it's a different kind of integration than
 * this module (an external API call, with its own rate limits) rather
 * than something addable to this same class.
 */
final class PageSpeedModule implements SeoModuleInterface {

    public function key(): string { return 'page_speed'; }
    public function label(): string { return 'Page Speed'; }

    public function evaluate( object $listing ): array {
        $checks = [];
        $slug = trim( (string) ( $listing->slug ?? '' ) );
        if ( $slug === '' ) { return $checks; }

        // Real fix — confirmed limitation: this module previously did a live
        // HTTP fetch on every single call to the SEO Score Checker, so
        // clicking "check" twice in a row for the same listing paid the same
        // network-round-trip cost twice and could show a different score
        // purely from normal response-time jitter, not any real content
        // change. Cached for 20 minutes per listing (short enough that a
        // real fix — e.g. enabling compression — is reflected well within
        // a single admin session, long enough to eliminate repeat-click cost
        // and score noise). Uses WordPress's own transient API, the same
        // caching mechanism already used elsewhere on this platform — no
        // new infrastructure introduced.
        $cache_key = 'gs_pagespeed_' . (int) ( $listing->id ?? 0 );
        if ( ! empty( $listing->id ) ) {
            $cached = get_transient( $cache_key );
            if ( is_array( $cached ) && $cached ) {
                return $cached;
            }
        }

        $url = home_url( '/' . $slug . '/' );
        $start = microtime( true );
        $response = wp_remote_get( $url, [ 'timeout' => 15, 'sslverify' => false ] );
        $elapsed_ms = (int) round( ( microtime( true ) - $start ) * 1000 );

        if ( is_wp_error( $response ) ) {
            $checks[] = SeoCheckResult::fail( 'page_reachable', 'Page loads successfully', 20, 'critical',
                'Could not load this page at all: ' . $response->get_error_message(),
                'Fix whatever is preventing this page from loading before addressing any other SEO factor.' );
            if ( ! empty( $listing->id ) ) { set_transient( $cache_key, $checks, 20 * MINUTE_IN_SECONDS ); }
            return $checks;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $html = wp_remote_retrieve_body( $response );
        $bytes = strlen( $html );

        // ── Response time (proxy for server-side TTFB) ────────────────
        // Google's own guidance has long treated server response time as
        // a real ranking-relevant factor; under 600ms is a widely-used
        // "good" threshold across the industry (including Google's own
        // historical PageSpeed documentation).
        if ( $elapsed_ms <= 600 ) {
            $checks[] = SeoCheckResult::pass( 'response_time', 'Server response time', 25,
                "Page responded in {$elapsed_ms}ms — a fast, healthy response time." );
        } elseif ( $elapsed_ms <= 1500 ) {
            $checks[] = SeoCheckResult::partial( 'response_time', 'Server response time', 15, 25, 'medium',
                "Page took {$elapsed_ms}ms to respond — noticeably slow.",
                'Consider what\'s adding delay: uncached database queries, unoptimized images loaded server-side, or third-party scripts blocking the response.' );
        } else {
            $checks[] = SeoCheckResult::fail( 'response_time', 'Server response time', 25, 'high',
                "Page took {$elapsed_ms}ms to respond — this is slow enough to noticeably hurt both user experience and Core Web Vitals scoring.",
                'Investigate slow database queries or heavy server-side processing for this page specifically.' );
        }

        // ── Total page weight ─────────────────────────────────────────
        // Under ~500KB of HTML (excluding separately-loaded
        // images/scripts) is a reasonable, commonly-used threshold for
        // "lean" markup; heavier HTML often indicates excessive inline
        // styles/scripts or unoptimized embedded content.
        $kb = round( $bytes / 1024, 1 );
        if ( $kb <= 300 ) {
            $checks[] = SeoCheckResult::pass( 'page_weight', 'HTML page weight', 20,
                "Page HTML is {$kb}KB — lean and fast to download." );
        } elseif ( $kb <= 600 ) {
            $checks[] = SeoCheckResult::partial( 'page_weight', 'HTML page weight', 12, 20, 'low',
                "Page HTML is {$kb}KB — on the heavier side.",
                'Check for large inline scripts or styles that could be moved to external, cacheable files.' );
        } else {
            $checks[] = SeoCheckResult::fail( 'page_weight', 'HTML page weight', 20, 'medium',
                "Page HTML is {$kb}KB — quite heavy for a single page load.",
                'Look for large inline content (scripts, styles, base64-embedded images) that could be reduced or externalized.' );
        }

        // ── Render-blocking resource count ────────────────────────────
        // Counting synchronous <script> tags without async/defer, and
        // <link rel="stylesheet"> tags — both directly delay first
        // paint, a foundational, publicly-documented performance factor.
        $blocking_scripts = preg_match_all( '/<script(?![^>]*\b(async|defer)\b)[^>]*\bsrc=/i', $html );
        $stylesheets = preg_match_all( '/<link[^>]*rel=["\']stylesheet["\']/i', $html );
        $blocking_total = $blocking_scripts + $stylesheets;
        if ( $blocking_total <= 5 ) {
            $checks[] = SeoCheckResult::pass( 'render_blocking', 'Render-blocking resources', 15,
                "{$blocking_total} render-blocking resource(s) — a reasonable amount." );
        } else {
            $checks[] = SeoCheckResult::partial( 'render_blocking', 'Render-blocking resources', 8, 15, 'low',
                "{$blocking_total} render-blocking scripts/stylesheets found.",
                'Consider adding async/defer to non-critical scripts, or combining stylesheets where possible.' );
        }

        // ── Compression ─────────────────────────────────────────────
        // gzip/br compression on the HTML response is a basic, always-
        // recommended server configuration — its absence is one of the
        // most common, easily-fixed causes of slow page weight.
        $encoding = wp_remote_retrieve_header( $response, 'content-encoding' );
        $checks[] = $encoding
            ? SeoCheckResult::pass( 'compression', 'Compression enabled', 20,
                "Response is compressed ({$encoding}) — reduces bytes transferred to visitors." )
            : SeoCheckResult::fail( 'compression', 'Compression enabled', 20, 'high',
                'No compression detected on this page\'s response — the full, uncompressed HTML is being sent to every visitor.',
                'Enable gzip or brotli compression at the server/CDN level — this is usually a one-time hosting configuration change with an immediate, platform-wide benefit.' );

        // ── Description popup payload size ────────────────────────────
        // Real fix — confirmed gap: Products/Services "View More" popup
        // content (data-sections attributes) already silently counted
        // toward the generic page-weight check above, since it's part
        // of the same raw HTML — but a vendor had no way to know THAT
        // was the cause of a heavy page. Named specifically so the
        // recommendation is actionable, not a vague "your HTML is heavy."
        //
        // Real fix, follow-on: also measures .vs-sr-only crawlable text
        // (added in a later fix so this content is genuinely indexable,
        // not just present in a JSON attribute) — a direct consequence
        // of that earlier fix I hadn't cross-checked against this
        // specific measurement. Without this, the sr-only addition
        // correctly counts toward the generic total page-weight number
        // below, but was invisible to this specific, actionable check —
        // recreating exactly the same "silent contributor" problem this
        // check exists to solve.
        $popup_attr_bytes = 0;
        $popup_count = preg_match_all( '/data-sections="([^"]*)"/i', $html, $popup_matches );
        if ( $popup_count > 0 ) {
            foreach ( $popup_matches[1] as $attr_val ) { $popup_attr_bytes += strlen( $attr_val ); }
        }
        $sr_only_bytes = 0;
        preg_match_all( '/<div class="vs-sr-only">(.*?)<\/div>/is', $html, $sr_only_matches );
        foreach ( $sr_only_matches[1] ?? [] as $sr_val ) { $sr_only_bytes += strlen( $sr_val ); }
        $popup_kb = round( ( $popup_attr_bytes + $sr_only_bytes ) / 1024, 1 );
        if ( $popup_count > 0 ) {
            if ( $popup_kb <= 50 ) {
                $checks[] = SeoCheckResult::pass( 'popup_content_weight', 'Description popup content size', 10,
                    "{$popup_count} product/service detail popup(s) totaling {$popup_kb}KB (including the crawlable text version) — a reasonable size." );
            } else {
                $checks[] = SeoCheckResult::partial( 'popup_content_weight', 'Description popup content size', 5, 10, 'low',
                    "{$popup_count} product/service detail popup(s) totaling {$popup_kb}KB embedded in this page's HTML (interactive JSON plus its crawlable text version) — this loads for every visitor even if they never open a popup.",
                    'Consider trimming very long popup sections (especially large image galleries or long tables) on your highest-content items, or splitting an unusually detailed item into its own listing.' );
            }
        }

        if ( ! empty( $listing->id ) ) { set_transient( $cache_key, $checks, 20 * MINUTE_IN_SECONDS ); }
        return $checks;
    }
}
