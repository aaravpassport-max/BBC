<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;
use GoodService\SEO\SeoContentExtractor;
use GoodService\SEO\FocusKeywordResolver;

/**
 * Real fix — closes a confirmed gap found on direct verification: the
 * Products/Services "Description popup" content was folded into
 * ContentAnalysisModule's keyword/readability body text, and checked
 * for completeness in SeoSectionAuditor — but SeoSectionAuditor is a
 * SEPARATE system (content-completeness per section) that never
 * contributes to SeoScorer's overall_score or checklist at all,
 * confirmed by reading SeoScorer::score() directly: it sums points
 * exclusively from registered SeoModuleInterface implementations.
 *
 * Real fix, follow-on (confirmed directly from live diagnostic
 * evidence): description-completeness checks were correctly split by
 * section ("Products & Services section" vs "Services Category
 * section"), but every OTHER check — Manage Details usage, content
 * depth, duplicate content, popup keyword/readability/heading — was
 * still computed as one combined figure across both sections, with no
 * section attribution in the label or message at all. A vendor with
 * only Services Category items (confirmed live: products_count=0,
 * services_count=5) saw "Manage Details (View More popup) usage" with
 * no indication that check was actually about their Services Category
 * items specifically — indistinguishable from a generic, unattributed
 * check. Restructured so every check in this module runs once per
 * real section and says so explicitly in its own label.
 */
final class ProductsServicesContentModule implements SeoModuleInterface {

    public function key(): string { return 'products_services_content'; }
    public function label(): string { return 'Products & Services Content'; }

    public function evaluate( object $listing ): array {
        $checks = [];
        $all_products_section = SeoContentExtractor::decode_items( $listing->products_data ?? null );
        $focus_keyword = FocusKeywordResolver::resolve( $listing );

        // Real fix, confirmed root cause: items in products_data (the
        // "Products & Services" section, full image cards) are each
        // individually typed as Product or Service via item_type — a
        // real, per-item toggle confirmed against the actual form field
        // (products[n][item_type]). The RENDERING default (vendor-
        // site.php) is 'service' when unset — confirmed directly against
        // the live page, not the form's own, different default — so
        // that's the default used here too, matching what's actually
        // displayed to a customer/crawler.
        $products = array_values( array_filter( $all_products_section, fn( $i ) => ( $i['item_type'] ?? 'service' ) !== 'service' ) );
        $products_section_services = array_values( array_filter( $all_products_section, fn( $i ) => ( $i['item_type'] ?? 'service' ) === 'service' ) );
        // services_data is the SEPARATE "Services Category" section
        // (icon tiles) — a genuinely different section from the one
        // above, confirmed by this platform's own on-page note: "Two
        // distinct sections: the Services Category section... This
        // Products & Services section..."
        $services = SeoContentExtractor::decode_items( $listing->services_data ?? null );

        if ( empty( $all_products_section ) && empty( $services ) ) {
            // Real validation rule: no products/services added at all is
            // not penalized here — many listing types (a single
            // consulting service, for example) legitimately have
            // nothing to add in this section, and the Services &
            // Category section already covers the core category choice.
            $checks[] = SeoCheckResult::pass( 'items_content_na', 'Products/Services content', 5,
                'No individual products or services added — optional, not penalized if your listing doesn\'t need this section.' );
            return $checks;
        }

        // ── Description completeness — Products & Services section: Product-typed items ──
        if ( ! empty( $products ) ) {
            $missing = array_filter( $products, fn( $p ) => trim( (string) ( $p['description'] ?? '' ) ) === '' );
            $count = count( $products );
            $missing_count = count( $missing );
            if ( $missing_count === 0 ) {
                $checks[] = SeoCheckResult::pass( 'product_desc_complete', 'Product descriptions (Products & Services section)', 15,
                    "All {$count} product(s) have descriptions." );
            } else {
                $names = implode( ', ', array_slice( array_map( fn( $p ) => $p['name'] ?? 'Unnamed', $missing ), 0, 3 ) );
                $more = $missing_count > 3 ? " and " . ( $missing_count - 3 ) . " more" : '';
                $checks[] = SeoCheckResult::partial( 'product_desc_complete', 'Product descriptions (Products & Services section)',
                    (int) round( 15 * ( ( $count - $missing_count ) / $count ) ), 15, 'medium',
                    "{$missing_count} of {$count} product(s) have no description: {$names}{$more}.",
                    'Add a description to each product listed above — search engines and customers both read this content, and it\'s currently blank.' );
            }
        }

        // ── Description completeness — Products & Services section: Service-typed items ──
        if ( ! empty( $products_section_services ) ) {
            $missing = array_filter( $products_section_services, fn( $s ) => trim( (string) ( $s['description'] ?? '' ) ) === '' );
            $count = count( $products_section_services );
            $missing_count = count( $missing );
            if ( $missing_count === 0 ) {
                $checks[] = SeoCheckResult::pass( 'products_section_service_desc_complete', 'Service descriptions (Products & Services section)', 15,
                    "All {$count} service-typed item(s) in your Products & Services section have descriptions." );
            } else {
                $names = implode( ', ', array_slice( array_map( fn( $s ) => $s['name'] ?? 'Unnamed', $missing ), 0, 3 ) );
                $more = $missing_count > 3 ? " and " . ( $missing_count - 3 ) . " more" : '';
                $checks[] = SeoCheckResult::partial( 'products_section_service_desc_complete', 'Service descriptions (Products & Services section)',
                    (int) round( 15 * ( ( $count - $missing_count ) / $count ) ), 15, 'medium',
                    "{$missing_count} of {$count} service-typed item(s) in your Products & Services section have no description: {$names}{$more}.",
                    'Add a description to each of these — they\'re marked as services in your Products & Services section, and currently blank.' );
            }
        }

        // ── Description completeness — Services Category section ──────
        if ( ! empty( $services ) ) {
            $missing = array_filter( $services, fn( $s ) => trim( (string) ( $s['description'] ?? '' ) ) === '' );
            $count = count( $services );
            $missing_count = count( $missing );
            if ( $missing_count === 0 ) {
                $checks[] = SeoCheckResult::pass( 'service_desc_complete', 'Service descriptions (Services Category section)', 15,
                    "All {$count} service(s) have descriptions." );
            } else {
                $names = implode( ', ', array_slice( array_map( fn( $s ) => $s['name'] ?? 'Unnamed', $missing ), 0, 3 ) );
                $more = $missing_count > 3 ? " and " . ( $missing_count - 3 ) . " more" : '';
                $checks[] = SeoCheckResult::partial( 'service_desc_complete', 'Service descriptions (Services Category section)',
                    (int) round( 15 * ( ( $count - $missing_count ) / $count ) ), 15, 'medium',
                    "{$missing_count} of {$count} service(s) have no description: {$names}{$more}.",
                    'Add a description to each service listed above — search engines and customers both read this content, and it\'s currently blank.' );
            }
        }

        // Real fix — every remaining check (content depth, Manage
        // Details usage, keyword/readability/heading within Manage
        // Details, duplicate content) now runs ONCE PER REAL SECTION
        // instead of once combined — confirmed via live diagnostic
        // evidence that a vendor with only Services Category items saw
        // no section attribution at all on these checks. Products &
        // Services section's product- and service-typed items are
        // grouped together here (they're visually the same section on
        // the page), Services Category is entirely separate.
        $checks = array_merge( $checks,
            $this->section_content_quality_checks( $all_products_section, 'Products & Services section', 'ps', $focus_keyword )
        );
        $checks = array_merge( $checks,
            $this->section_content_quality_checks( $services, 'Services Category section', 'svccat', $focus_keyword )
        );

        return $checks;
    }

    /**
     * Runs the full content-quality checklist — content depth, Manage
     * Details usage, Manage Details keyword/readability/heading, and
     * duplicate content — against ONE real section's items. Called once
     * per section from evaluate() so every check explicitly names which
     * section it's about, rather than blending two genuinely different
     * parts of the form into one unattributed figure.
     *
     * @param array  $items      Decoded items belonging to this one section.
     * @param string $section_label Human label appended to every check in this group, e.g. "Products & Services section".
     * @param string $key_prefix Short, unique prefix for this group's check keys, so Products & Services and Services Category never collide on the same key.
     */
    private function section_content_quality_checks( array $items, string $section_label, string $key_prefix, string $focus_keyword ): array {
        $checks = [];
        $item_count = count( $items );
        if ( $item_count === 0 ) { return $checks; }

        // ── Content depth ──────────────────────────────────────────────
        $texts = array_map( fn( $i ) => SeoContentExtractor::item_full_text( $i ), $items );
        $word_count = array_sum( array_map( 'str_word_count', $texts ) );
        $avg_words = round( $word_count / $item_count, 1 );
        if ( $avg_words >= 15 ) {
            $checks[] = SeoCheckResult::pass( "{$key_prefix}_content_depth", "Content depth ({$section_label})", 10,
                "Averaging {$avg_words} words per item across descriptions and detail content — good depth." );
        } elseif ( $avg_words >= 5 ) {
            $checks[] = SeoCheckResult::partial( "{$key_prefix}_content_depth", "Content depth ({$section_label})", 6, 10, 'low',
                "Averaging only {$avg_words} words per item in your {$section_label} — quite thin.",
                'Expand these descriptions with more specific detail — what\'s included, how it works, who it\'s for.' );
        } else {
            $checks[] = SeoCheckResult::fail( "{$key_prefix}_content_depth", "Content depth ({$section_label})", 10, 'medium',
                "Averaging only {$avg_words} words per item in your {$section_label} — this reads as placeholder content to both customers and search engines.",
                'Write real, specific descriptions for each item — a few words each isn\'t enough to be useful or to rank.' );
        }

        // ── Manage Details (View More popup) usage ─────────────────────
        $with_popup = array_filter( $items, fn( $i ) => SeoContentExtractor::extract_view_more_text( $i['view_more_sections'] ?? [] ) !== '' );
        $with_popup_count = count( $with_popup );
        if ( $with_popup_count === 0 ) {
            // Real validation rule: still not a hard failure — Manage
            // Details is genuinely optional richer content, the same
            // way FAQ/process sections are optional elsewhere in this
            // codebase.
            $checks[] = SeoCheckResult::partial( "{$key_prefix}_popup_usage", "Manage Details (View More popup) usage — {$section_label}", 5, 10, 'low',
                "None of your {$item_count} item(s) in {$section_label} have any content in their Manage Details (View More popup).",
                "Click \"📝 Manage Details (View More popup)\" on your best-performing items in {$section_label} and add FAQs, specs, or a longer explanation — this is real content search engines and customers can both read, currently sitting empty." );
        } elseif ( $with_popup_count < $item_count ) {
            $checks[] = SeoCheckResult::partial( "{$key_prefix}_popup_usage", "Manage Details (View More popup) usage — {$section_label}",
                (int) round( 10 * ( $with_popup_count / $item_count ) ), 10, 'low',
                "{$with_popup_count} of {$item_count} item(s) in {$section_label} have Manage Details content — the rest have none.",
                "Add Manage Details content to your remaining items in {$section_label} too, for consistent depth." );
        } else {
            $checks[] = SeoCheckResult::pass( "{$key_prefix}_popup_usage", "Manage Details (View More popup) usage — {$section_label}", 10,
                "All {$item_count} item(s) in {$section_label} have Manage Details (View More popup) content." );
        }

        // ── Manage Details content quality — keyword usage & readability ──
        if ( $with_popup_count > 0 ) {
            $popup_text = trim( implode( ' ', array_map(
                fn( $i ) => SeoContentExtractor::extract_view_more_text( $i['view_more_sections'] ?? [] ), $with_popup
            ) ) );
            if ( $focus_keyword && $popup_text ) {
                $mentions = substr_count( strtolower( $popup_text ), strtolower( $focus_keyword ) );
                $checks[] = $mentions > 0
                    ? SeoCheckResult::pass( "{$key_prefix}_popup_keyword", "Manage Details mentions focus keyword — {$section_label}", 8,
                        "Your Manage Details content in {$section_label} mentions \"{$focus_keyword}\" — reinforces relevance beyond just your main description." )
                    : SeoCheckResult::partial( "{$key_prefix}_popup_keyword", "Manage Details mentions focus keyword — {$section_label}", 4, 8, 'low',
                        "Your Manage Details content in {$section_label} doesn't mention \"{$focus_keyword}\" anywhere.",
                        "Consider mentioning \"{$focus_keyword}\" naturally somewhere in your Manage Details content — FAQs and detail sections are extra opportunities to reinforce it." );
            }
            $popup_words = str_word_count( $popup_text );
            $popup_sentences = max( 1, preg_match_all( '/[.!?]+/', $popup_text ) );
            $avg_sentence = $popup_words / $popup_sentences;
            if ( $avg_sentence > 25 ) {
                $checks[] = SeoCheckResult::partial( "{$key_prefix}_popup_readability", "Manage Details readability — {$section_label}", 4, 8, 'low',
                    "Sentences in your Manage Details content in {$section_label} average " . round( $avg_sentence ) . ' words — quite long.',
                    'Break up long sentences in your FAQs/detail sections — shorter is easier to scan, especially on mobile.' );
            } else {
                $checks[] = SeoCheckResult::pass( "{$key_prefix}_popup_readability", "Manage Details readability — {$section_label}", 8,
                    "Your Manage Details content in {$section_label} is an easy-to-read length." );
            }

            // ── Heading structure within Manage Details content ────────
            $popup_headings = [];
            foreach ( $with_popup as $i ) {
                $popup_headings = array_merge( $popup_headings, SeoContentExtractor::extract_view_more_headings( $i['view_more_sections'] ?? [] ) );
            }
            if ( ! empty( $popup_headings ) && $focus_keyword ) {
                $kw_in_heading = false;
                foreach ( $popup_headings as $h ) {
                    if ( stripos( $h, $focus_keyword ) !== false ) { $kw_in_heading = true; break; }
                }
                $checks[] = $kw_in_heading
                    ? SeoCheckResult::pass( "{$key_prefix}_popup_heading_keyword", "Manage Details heading structure — {$section_label}", 5,
                        "At least one heading in your Manage Details content in {$section_label} includes your focus keyword." )
                    : SeoCheckResult::partial( "{$key_prefix}_popup_heading_keyword", "Manage Details heading structure — {$section_label}", 2, 5, 'low',
                        count( $popup_headings ) . " heading(s) found in your Manage Details content in {$section_label}, but none mention \"{$focus_keyword}\".",
                        "Consider including \"{$focus_keyword}\" in at least one heading within your Manage Details sections." );
            }
        }

        // ── Duplicate content across items in this section ─────────────
        $desc_groups = [];
        foreach ( $items as $item ) {
            $desc = trim( (string) ( $item['description'] ?? '' ) );
            // Real validation rule: only compares real content — a
            // handful of words is common enough to coincidentally match
            // without being a meaningful duplicate; this threshold
            // avoids false positives.
            if ( str_word_count( $desc ) < 5 ) { continue; }
            $normalized = strtolower( preg_replace( '/\s+/', ' ', $desc ) );
            $desc_groups[ $normalized ][] = $item['name'] ?? 'Unnamed';
        }
        $duplicate_groups = array_filter( $desc_groups, fn( $names ) => count( $names ) > 1 );
        if ( ! empty( $duplicate_groups ) ) {
            $examples = [];
            foreach ( $duplicate_groups as $names ) {
                $examples[] = implode( ' / ', array_slice( $names, 0, 3 ) ) . ( count( $names ) > 3 ? ' and ' . ( count( $names ) - 3 ) . ' more' : '' );
            }
            $checks[] = SeoCheckResult::partial( "{$key_prefix}_duplicate_content", "Duplicate content across items — {$section_label}",
                6, 10, 'medium',
                count( $duplicate_groups ) . " group(s) of items in {$section_label} share identical descriptions: " . implode( '; ', array_slice( $examples, 0, 2 ) ) . ( count( $examples ) > 2 ? '; and more' : '' ) . '.',
                'Write a unique description for each item — even similar services usually differ in some specific way worth mentioning (turnaround time, what\'s included, who it\'s for).' );
        } elseif ( $item_count > 1 ) {
            $checks[] = SeoCheckResult::pass( "{$key_prefix}_duplicate_content", "Duplicate content across items — {$section_label}", 10,
                "Every item in {$section_label} has a unique description — no copy-paste duplication detected." );
        }

        return $checks;
    }
}
