<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;

/**
 * Checks whether this listing has everything needed to generate valid
 * LocalBusiness + Review schema — schema.org's LocalBusiness type and
 * Google's structured data guidelines are both public specifications,
 * independently implementable by anyone; this checks against those
 * published requirements, not any plugin's generator code.
 *
 * This module does not generate the schema itself — it answers "is
 * this listing schema-ready," which is what a vendor actually needs to
 * know before schema generation happens elsewhere in the platform.
 */
final class SchemaReadinessModule implements SeoModuleInterface {

    public function key(): string { return 'schema_readiness'; }
    public function label(): string { return 'Structured Data (Schema)'; }

    public function evaluate( object $listing ): array {
        global $wpdb;
        $checks = [];

        // ── Required LocalBusiness fields ────────────────────────────
        // schema.org/LocalBusiness marks name, address, and telephone as
        // its core recommended properties — without these, Google's Rich
        // Results Test flags LocalBusiness markup as incomplete.
        $required = [
            'title'   => [ 'Business name', 'name' ],
            'address' => [ 'Street address', 'address' ],
            'city'    => [ 'City', 'address.addressLocality' ],
            'phone'   => [ 'Phone number', 'telephone' ],
        ];
        $missing_required = [];
        foreach ( $required as $field => [ $label, $schema_prop ] ) {
            if ( trim( (string) ( $listing->$field ?? '' ) ) === '' ) {
                $missing_required[] = $label;
            }
        }
        if ( empty( $missing_required ) ) {
            $checks[] = SeoCheckResult::pass( 'schema_required', 'Required schema fields present', 30,
                'All required LocalBusiness fields are set — valid schema can be generated.' );
        } else {
            $list = implode( ', ', $missing_required );
            $checks[] = SeoCheckResult::fail( 'schema_required', 'Required schema fields present', 30, 'critical',
                "Missing: {$list}. Without these, valid LocalBusiness structured data can't be generated for this listing.",
                "Fill in: {$list}. These are required for Google to show rich results for your listing." );
        }

        // ── Geo-coordinates for map-based rich results ───────────────
        // Corrected from an earlier mistake: lat/lng genuinely exist,
        // but on vendor_profiles, not listings directly — confirmed by
        // reading the full table definition this time, not a single-line
        // grep that missed the multi-line column declarations.
        $vp_geo = $wpdb->get_row( $wpdb->prepare(
            "SELECT lat, lng FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $listing->vendor_id ?? 0
        ) );
        $has_geo = $vp_geo && $vp_geo->lat !== null && $vp_geo->lng !== null;
        $checks[] = $has_geo
            ? SeoCheckResult::pass( 'schema_geo', 'Location coordinates set', 15,
                'Your vendor profile has map coordinates — eligible for location-based rich results.' )
            : SeoCheckResult::fail( 'schema_geo', 'Location coordinates set', 15, 'medium',
                'No map coordinates set on your vendor profile.',
                'Set your exact location on the map in your vendor profile settings — this enables map-based search features.' );

        // ── Business hours for openingHours schema ────────────────────
        $has_hours = ! empty( $listing->opening_hours );
        $checks[] = $has_hours
            ? SeoCheckResult::pass( 'schema_hours', 'Business hours set', 10,
                'Business hours are set — eligible for "open now" display in search results.' )
            : SeoCheckResult::fail( 'schema_hours', 'Business hours set', 10, 'low',
                'No business hours set.', 'Add your opening hours — Google can show "Open now" directly in search results.' );

        // ── Image for schema.org "image" property ─────────────────────
        // Google's structured data guidelines explicitly recommend an
        // image for LocalBusiness/Service rich results.
        $checks[] = $listing->logo_url || $listing->banner_url
            ? SeoCheckResult::pass( 'schema_image', 'Schema image available', 10,
                'A logo or cover image is available for schema markup.' )
            : SeoCheckResult::fail( 'schema_image', 'Schema image available', 10, 'medium',
                'No logo or cover image available for structured data.',
                'Upload a logo or cover image — Google\'s guidelines recommend an image for rich results eligibility.' );

        return $checks;
    }
}
