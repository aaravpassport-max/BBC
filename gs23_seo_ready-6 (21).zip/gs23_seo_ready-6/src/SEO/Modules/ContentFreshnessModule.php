<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;

/**
 * Content freshness — Google has publicly discussed (via its own
 * Search Central blog and spokespeople) that meaningfully updated
 * content can be treated as a freshness signal, particularly for
 * queries where recency matters. This checks how long it's been since
 * a listing's content last changed, using the real updated_at column.
 */
final class ContentFreshnessModule implements SeoModuleInterface {

    public function key(): string { return 'content_freshness'; }
    public function label(): string { return 'Content Freshness'; }

    public function evaluate( object $listing ): array {
        $checks = [];
        $updated = trim( (string) ( $listing->updated_at ?? '' ) );

        if ( $updated === '' ) {
            $checks[] = SeoCheckResult::fail( 'freshness', 'Recently updated', 10, 'low',
                'No update history available for this listing.',
                'Make a small update to your listing (even a minor description tweak) to refresh it.' );
            return $checks;
        }

        $days_old = (int) floor( ( time() - strtotime( $updated ) ) / DAY_IN_SECONDS );

        if ( $days_old <= 90 ) {
            $checks[] = SeoCheckResult::pass( 'freshness', 'Recently updated', 10,
                "Last updated {$days_old} day(s) ago — this listing is current." );
        } elseif ( $days_old <= 180 ) {
            $checks[] = SeoCheckResult::partial( 'freshness', 'Recently updated', 6, 10, 'low',
                "Last updated {$days_old} days ago.",
                'Consider refreshing your description, photos, or services soon to keep the listing feeling current.' );
        } else {
            $checks[] = SeoCheckResult::fail( 'freshness', 'Recently updated', 10, 'medium',
                "This listing hasn't been updated in {$days_old} days — over 6 months.",
                'Update your description, add new photos, or refresh your services. Stale listings can lose ground to more actively maintained competitors.' );
        }

        return $checks;
    }
}
