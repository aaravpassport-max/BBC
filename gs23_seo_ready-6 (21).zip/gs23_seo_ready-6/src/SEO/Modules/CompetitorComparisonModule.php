<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;

/**
 * Genuinely platform-specific advantage over a generic SEO plugin: a
 * standalone WordPress blog has no visibility into "competitors" at
 * all — but on a marketplace, every other vendor in the same
 * category/city IS a real, queryable competitor, and their completeness
 * is directly comparable using the same data this system already scores.
 */
final class CompetitorComparisonModule implements SeoModuleInterface {

    public function key(): string { return 'competitor_comparison'; }
    public function label(): string { return 'Competitor Comparison'; }

    public function evaluate( object $listing ): array {
        global $wpdb;
        $checks = [];
        $p = $wpdb->prefix . 'gs_';
        $category = $listing->subcat_name ?? $listing->cat_name ?? '';
        $city = $listing->city ?? '';
        // Real fix: the WHERE clause below used to filter on
        // subcat_name/cat_name directly — those aren't real columns on
        // this table, only JOIN-aliased results elsewhere. Uses the
        // genuine foreign key columns instead.
        $category_id = (int) ( $listing->subcategory_id ?: $listing->category_id ?? 0 );

        if ( ! $category || ! $city || ! $category_id ) { return $checks; }

        // Real competitors: same category AND city, active, excluding self.
        $competitors = $wpdb->get_results( $wpdb->prepare(
            "SELECT title, full_desc, short_desc, gallery, phone, whatsapp, products_data, services_data,
                    faq_data, process_data, why_choose_data, team_data, portfolio_data
             FROM {$p}listings
             WHERE id != %d AND status = 'active' AND (subcategory_id = %d OR category_id = %d) AND city = %s
             LIMIT 20",
            $listing->id ?? 0, $category_id, $category_id, $city
        ) );

        if ( empty( $competitors ) ) {
            $checks[] = SeoCheckResult::pass( 'competitor_gallery', 'Gallery vs local competitors', 10,
                "No other active competitors found in {$category} in {$city} yet — nothing to compare against." );
            return $checks;
        }

        // ── Description length vs local competitors ────────────────────
        // Real fix — confirmed gap: word counts here used to measure
        // only full_desc/short_desc, completely excluding Products/
        // Services description popup content on both sides of the
        // comparison — now consistent with what ContentAnalysisModule
        // measures elsewhere, and fair to both sides of this comparison.
        $my_words = str_word_count( trim( (string) ( $listing->full_desc ?: $listing->short_desc ?? '' ) . ' ' . \GoodService\SEO\SeoContentExtractor::all_items_text( $listing ) . ' ' . \GoodService\SEO\SeoContentExtractor::all_other_sections_text( $listing ) ) );
        $competitor_word_counts = array_map( fn( $c ) => str_word_count( trim( (string) ( $c->full_desc ?: $c->short_desc ?? '' ) . ' ' . \GoodService\SEO\SeoContentExtractor::all_items_text( $c ) . ' ' . \GoodService\SEO\SeoContentExtractor::all_other_sections_text( $c ) ) ), $competitors );
        $avg_competitor_words = $competitor_word_counts ? array_sum( $competitor_word_counts ) / count( $competitor_word_counts ) : 0;

        if ( $avg_competitor_words > 0 && $my_words < $avg_competitor_words * 0.7 ) {
            $checks[] = SeoCheckResult::fail( 'competitor_content', 'Description length vs local competitors', 15, 'medium',
                "Your description is {$my_words} words. Other " . count( $competitors ) . " listing(s) in {$category} in {$city} average " . round( $avg_competitor_words ) . " words.",
                'Expand your description — competitors in your exact category and city currently have noticeably more content than you do.' );
        } else {
            $checks[] = SeoCheckResult::pass( 'competitor_content', 'Description length vs local competitors', 15,
                "Your description ({$my_words} words) is competitive with other listings in your category/city (avg " . round( $avg_competitor_words ) . " words)." );
        }

        // ── Gallery size vs local competitors ───────────────────────────
        $my_gallery = json_decode( (string) ( $listing->gallery ?? '[]' ), true );
        $my_gallery_count = is_array( $my_gallery ) ? count( $my_gallery ) : 0;
        $competitor_gallery_counts = array_map( function ( $c ) {
            $g = json_decode( (string) ( $c->gallery ?? '[]' ), true );
            return is_array( $g ) ? count( $g ) : 0;
        }, $competitors );
        $avg_competitor_gallery = $competitor_gallery_counts ? array_sum( $competitor_gallery_counts ) / count( $competitor_gallery_counts ) : 0;

        if ( $avg_competitor_gallery > 0 && $my_gallery_count < $avg_competitor_gallery * 0.7 ) {
            $checks[] = SeoCheckResult::fail( 'competitor_gallery', 'Gallery size vs local competitors', 10, 'medium',
                "You have {$my_gallery_count} photo(s). Local competitors in your category average " . round( $avg_competitor_gallery ) . '.',
                'Add more photos — you\'re noticeably behind other listings in your exact category and city.' );
        } else {
            $checks[] = SeoCheckResult::pass( 'competitor_gallery', 'Gallery size vs local competitors', 10,
                "Your gallery ({$my_gallery_count} photos) is competitive with local listings in your category." );
        }

        // ── Contact channel coverage vs local competitors ──────────────
        $my_channels = ( trim( (string) ( $listing->phone ?? '' ) ) !== '' ? 1 : 0 ) + ( trim( (string) ( $listing->whatsapp ?? '' ) ) !== '' ? 1 : 0 );
        $with_both = count( array_filter( $competitors, fn( $c ) => trim( (string) $c->phone ) !== '' && trim( (string) $c->whatsapp ) !== '' ) );
        if ( $my_channels < 2 && $with_both > count( $competitors ) / 2 ) {
            $checks[] = SeoCheckResult::fail( 'competitor_contact', 'Contact channels vs local competitors', 5, 'low',
                'Most competing listings in your area offer both phone and WhatsApp contact — you offer fewer contact options.',
                'Add a WhatsApp number if you have one — most of your local competitors already offer it.' );
        } else {
            $checks[] = SeoCheckResult::pass( 'competitor_contact', 'Contact channels vs local competitors', 5,
                'Your contact options are competitive with other local listings.' );
        }

        return $checks;
    }
}
