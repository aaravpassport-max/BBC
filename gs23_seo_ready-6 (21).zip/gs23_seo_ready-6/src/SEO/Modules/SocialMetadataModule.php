<?php
namespace GoodService\SEO\Modules;

use GoodService\SEO\Contracts\SeoModuleInterface;
use GoodService\SEO\Contracts\SeoCheckResult;

/**
 * Open Graph and Twitter Card completeness — both are open, public
 * specifications (ogp.me and Twitter's own developer docs), not
 * anything proprietary to a plugin. This checks whether a shared link
 * to this listing would render properly on WhatsApp, Facebook, LinkedIn,
 * and X — a genuinely high-value check for a marketplace where vendors
 * actively share their own listing links.
 */
final class SocialMetadataModule implements SeoModuleInterface {

    public function key(): string { return 'social_metadata'; }
    public function label(): string { return 'Social Sharing'; }

    public function evaluate( object $listing ): array {
        $checks = [];
        $title = trim( (string) ( $listing->seo_title ?: $listing->title ?? '' ) );
        $desc  = trim( (string) ( $listing->seo_desc ?? '' ) );
        $image = trim( (string) ( $listing->og_image ?: $listing->banner_url ?: $listing->logo_url ?? '' ) );

        // og:title / og:description existing is required for a link
        // preview to show anything other than a bare, generic URL.
        $checks[] = ( $title !== '' && $desc !== '' )
            ? SeoCheckResult::pass( 'og_text', 'Share preview text ready', 15,
                'Title and description are set — links to this page will show a proper preview when shared.' )
            : SeoCheckResult::fail( 'og_text', 'Share preview text ready', 15, 'high',
                'Missing title or description — when this link is shared on WhatsApp or Facebook, the preview will look broken or empty.',
                'Complete both your title and meta description — these also power social share previews.' );

        // og:image is the single biggest factor in whether a shared link
        // gets clicked — a specific, well-known finding across social
        // platforms' own published engagement data.
        // NOTE: an image-dimension check (recommending 1200x630px+) was
        // left out here — I could not confirm og_image_width/height
        // columns genuinely exist in this schema. Flagged rather than
        // guessed; add this back once dimension storage is confirmed.
        $checks[] = ( $image !== '' )
            ? SeoCheckResult::pass( 'og_image', 'Share preview image set', 25,
                'A share preview image is available.' )
            : SeoCheckResult::fail( 'og_image', 'Share preview image set', 25, 'critical',
                'No image available for social sharing — shared links will show as plain text with no visual, which gets far fewer clicks.',
                'Upload a logo or cover image — this becomes the image people see when your listing link is shared.' );

        return $checks;
    }
}
