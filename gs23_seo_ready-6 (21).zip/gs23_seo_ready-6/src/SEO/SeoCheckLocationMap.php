<?php
namespace GoodService\SEO;

/**
 * Maps every check key to the real, navigable section of the listing
 * form (create-listing.php) — so a vendor's checklist can say exactly
 * where to go, not just what's wrong.
 *
 * Every section ID here was verified directly against real
 * clSectionNav() calls in create-listing.php, not assumed. Checks that
 * genuinely don't correspond to any editable form field (server
 * response time, page weight, indexability, etc.) are honestly labeled
 * as such rather than forced into an incorrect section.
 */
final class SeoCheckLocationMap {

    /** @var array<string, array{section: ?string, label: string}> */
    private const MAP = [
        // ── Metadata (SEO section of the form) ──────────────────────
        'title_length'         => [ 'section' => 'seo', 'label' => 'SEO' ],
        'title_relevance'      => [ 'section' => 'seo', 'label' => 'SEO' ],
        'title_uniqueness'     => [ 'section' => 'seo', 'label' => 'SEO' ],
        'focus_keyword_set'    => [ 'section' => 'seo', 'label' => 'SEO' ],
        'keyword_in_desc'      => [ 'section' => 'seo', 'label' => 'SEO' ],
        'keyword_in_url'       => [ 'section' => 'seo', 'label' => 'SEO' ],
        'desc_length'          => [ 'section' => 'seo', 'label' => 'SEO' ],
        'url_slug'             => [ 'section' => 'seo', 'label' => 'SEO' ],
        'title_numbers'        => [ 'section' => 'seo', 'label' => 'SEO' ],
        'title_sentiment'      => [ 'section' => 'seo', 'label' => 'SEO' ],
        'og_text'              => [ 'section' => 'seo', 'label' => 'SEO' ],
        'og_image'             => [ 'section' => 'seo', 'label' => 'SEO' ],

        // ── Content (About section — full_desc/short_desc live there) ──
        'keyword_opening'      => [ 'section' => 'about', 'label' => 'About' ],
        'keyword_density'      => [ 'section' => 'about', 'label' => 'About' ],
        'keyword_subheadings'  => [ 'section' => 'about', 'label' => 'About' ],
        'readability'          => [ 'section' => 'about', 'label' => 'About' ],
        'short_paragraphs'     => [ 'section' => 'about', 'label' => 'About' ],
        'external_links'       => [ 'section' => 'about', 'label' => 'About' ],
        'link_balance'         => [ 'section' => 'about', 'label' => 'About' ],
        'internal_links'       => [ 'section' => 'about', 'label' => 'About' ],
        'city_in_content'      => [ 'section' => 'about', 'label' => 'About' ],

        // ── Headings & Images (Gallery — alt text lives on gallery images) ──
        'h1_content'           => [ 'section' => 'hero', 'label' => 'Hero' ],
        'alt_coverage'         => [ 'section' => 'gallery', 'label' => 'Gallery' ],
        'alt_relevance'        => [ 'section' => 'gallery', 'label' => 'Gallery' ],

        // ── Local SEO ────────────────────────────────────────────────
        'nap_complete'         => [ 'section' => 'contact', 'label' => 'Contact' ],
        'nap_consistency'      => [ 'section' => 'contact', 'label' => 'Contact' ],
        'service_area'         => [ 'section' => 'contact', 'label' => 'Contact' ],
        'local_density'        => [ 'section' => null, 'label' => 'Informational only — no fix needed here' ],

        // ── Schema readiness — lives on the vendor profile, not this form ──
        'schema_required'      => [ 'section' => null, 'label' => 'Vendor Profile settings (not this form)' ],
        'schema_geo'           => [ 'section' => null, 'label' => 'Vendor Profile settings — set your map location there' ],
        'schema_hours'         => [ 'section' => 'contact', 'label' => 'Contact' ],
        'schema_image'         => [ 'section' => 'hero', 'label' => 'Hero' ],

        // ── Indexability & technical — not editable form fields at all ──
        'noindex_check'        => [ 'section' => null, 'label' => 'Technical — set via listing status/robots, not a form field' ],
        'status_active'        => [ 'section' => null, 'label' => 'Publish this listing to make it live' ],
        'canonical_auto'       => [ 'section' => null, 'label' => 'Automatic — no action needed' ],

        // ── Page speed — server/hosting-level, not a form field ─────────
        'page_reachable'       => [ 'section' => null, 'label' => 'Technical — contact your host/developer' ],
        'response_time'        => [ 'section' => null, 'label' => 'Technical (server performance) — not a form field' ],
        'page_weight'          => [ 'section' => null, 'label' => 'Technical (server performance) — not a form field' ],
        'render_blocking'      => [ 'section' => null, 'label' => 'Technical (server performance) — not a form field' ],
        'compression'          => [ 'section' => null, 'label' => 'Technical (hosting configuration) — not a form field' ],

        // ── Competitor comparison — informational, no single fix location ──
        'competitor_content'   => [ 'section' => 'about', 'label' => 'About' ],
        'competitor_gallery'   => [ 'section' => 'gallery', 'label' => 'Gallery' ],
        'competitor_contact'   => [ 'section' => 'contact', 'label' => 'Contact' ],

        // ── Products/Services description popup content — real fix,
        // confirmed gap: these check keys didn't exist in this map at
        // all until the products_data/services_data content itself was
        // wired into SEO scoring — section IDs verified against real
        // clSectionNav('services',...) / clSectionNav('products',...)
        // calls in create-listing.php, not assumed. ──────────────────
        'svc_desc'             => [ 'section' => 'services', 'label' => 'Services' ],
        'svc_popup_content'    => [ 'section' => 'services', 'label' => 'Services' ],
        'products_desc'        => [ 'section' => 'products', 'label' => 'Products' ],
        'popup_content_weight' => [ 'section' => null, 'label' => 'Technical (page weight) — trim popup content on your Services/Products items' ],

        // ── Products/Services content module — real fix, confirmed gap:
        // these checks genuinely flow through the vendor-visible
        // checklist (unlike the SeoSectionAuditor-only checks above),
        // so without real mappings they'd fall back to "General" instead
        // of pointing at the actual form section. Combined-scope checks
        // (covering both products and services together) point to
        // 'products' as the primary location with a label naming both,
        // since the map only supports one section per key. ──────────
        'product_desc_complete' => [ 'section' => 'products', 'label' => 'Products' ],
        'products_section_service_desc_complete' => [ 'section' => 'products', 'label' => 'Products & Services (item marked as Service)' ],
        'service_desc_complete' => [ 'section' => 'services', 'label' => 'Services' ],
        'ps_content_depth'      => [ 'section' => 'products', 'label' => 'Products & Services section' ],
        'ps_popup_usage'        => [ 'section' => 'products', 'label' => 'Products & Services section' ],
        'ps_popup_keyword'      => [ 'section' => 'products', 'label' => 'Products & Services section — Manage Details' ],
        'ps_popup_readability'  => [ 'section' => 'products', 'label' => 'Products & Services section — Manage Details' ],
        'ps_popup_heading_keyword' => [ 'section' => 'products', 'label' => 'Products & Services section — Manage Details' ],
        'ps_duplicate_content'  => [ 'section' => 'products', 'label' => 'Products & Services section — check for copy-pasted descriptions' ],
        'svccat_content_depth'      => [ 'section' => 'services', 'label' => 'Services Category section' ],
        'svccat_popup_usage'        => [ 'section' => 'services', 'label' => 'Services Category section' ],
        'svccat_popup_keyword'      => [ 'section' => 'services', 'label' => 'Services Category section — Manage Details' ],
        'svccat_popup_readability'  => [ 'section' => 'services', 'label' => 'Services Category section — Manage Details' ],
        'svccat_popup_heading_keyword' => [ 'section' => 'services', 'label' => 'Services Category section — Manage Details' ],
        'svccat_duplicate_content'  => [ 'section' => 'services', 'label' => 'Services Category section — check for copy-pasted descriptions' ],
        'items_content_na'      => [ 'section' => null, 'label' => 'Informational only — no fix needed here' ],

        // ── Other Sections Content module — real fix, closing a
        // confirmed gap across FAQ, Process, Why Choose, Team,
        // Portfolio, and Pricing. Section IDs verified against real
        // clSectionNav() calls in create-listing.php. ─────────────────
        'faq_answers_complete'      => [ 'section' => 'faq', 'label' => 'FAQ' ],
        'faq_content_depth'         => [ 'section' => 'faq', 'label' => 'FAQ' ],
        'faq_duplicate_content'     => [ 'section' => 'faq', 'label' => 'FAQ' ],
        'process_desc_complete'     => [ 'section' => 'process', 'label' => 'Process / How It Works' ],
        'process_content_depth'     => [ 'section' => 'process', 'label' => 'Process / How It Works' ],
        'process_duplicate_content' => [ 'section' => 'process', 'label' => 'Process / How It Works' ],
        'why_desc_complete'         => [ 'section' => 'why', 'label' => 'Why Choose Us' ],
        'why_content_depth'         => [ 'section' => 'why', 'label' => 'Why Choose Us' ],
        'why_duplicate_content'     => [ 'section' => 'why', 'label' => 'Why Choose Us' ],
        'team_desc_complete'        => [ 'section' => 'team', 'label' => 'Team' ],
        'team_content_depth'        => [ 'section' => 'team', 'label' => 'Team' ],
        'team_duplicate_content'    => [ 'section' => 'team', 'label' => 'Team' ],
        'portfolio_desc_complete'   => [ 'section' => 'portfolio', 'label' => 'Portfolio' ],
        'portfolio_content_depth'   => [ 'section' => 'portfolio', 'label' => 'Portfolio' ],
        'portfolio_duplicate_content' => [ 'section' => 'portfolio', 'label' => 'Portfolio' ],
        'pricing_features_complete' => [ 'section' => 'pricing', 'label' => 'Pricing Plans' ],
        'other_sections_na'         => [ 'section' => null, 'label' => 'Informational only — no fix needed here' ],

        // ── Freshness — informational, fixed by editing anything ────────
        'freshness'            => [ 'section' => null, 'label' => 'Update any section to refresh this' ],
    ];

    /** @return array{section: ?string, label: string} */
    public static function locate( string $check_key ): array {
        return self::MAP[ $check_key ] ?? [ 'section' => null, 'label' => 'General' ];
    }
}
