<?php
namespace GoodService\SEO;

use GoodService\SEO\Modules\MetadataModule;
use GoodService\SEO\Modules\ContentAnalysisModule;
use GoodService\SEO\Modules\ProductsServicesContentModule;
use GoodService\SEO\Modules\OtherSectionsContentModule;
use GoodService\SEO\Modules\HeadingsAndImagesModule;
use GoodService\SEO\Modules\SchemaReadinessModule;
use GoodService\SEO\Modules\SocialMetadataModule;
use GoodService\SEO\Modules\IndexabilityModule;
use GoodService\SEO\Modules\ContentFreshnessModule;
use GoodService\SEO\Modules\InternalLinkingModule;
use GoodService\SEO\Modules\PageSpeedModule;
use GoodService\SEO\Modules\LocalSeoModule;
use GoodService\SEO\Modules\TitleQualityModule;
use GoodService\SEO\Modules\CompetitorComparisonModule;
use GoodService\SEO\Modules\TitleSentimentModule;

/**
 * Single place that wires every module into the scorer. Adding a new
 * module later means adding one line here — nothing else changes.
 */
final class SeoBootstrap {

    public static function scorer(): SeoScorer {
        static $scorer = null;
        if ( $scorer === null ) {
            $scorer = new SeoScorer();
            $scorer->register( new IndexabilityModule() );      // checked first — nothing else matters if this fails
            $scorer->register( new MetadataModule() );
            $scorer->register( new ContentAnalysisModule() );
            $scorer->register( new ProductsServicesContentModule() );
            $scorer->register( new OtherSectionsContentModule() );
            $scorer->register( new HeadingsAndImagesModule() );
            $scorer->register( new SchemaReadinessModule() );
            $scorer->register( new SocialMetadataModule() );
            $scorer->register( new ContentFreshnessModule() );
            $scorer->register( new InternalLinkingModule() );
            $scorer->register( new PageSpeedModule() );      // placed last — does a live HTTP fetch, slower than the rest
            $scorer->register( new LocalSeoModule() );
            $scorer->register( new TitleQualityModule() );
            $scorer->register( new CompetitorComparisonModule() );
            $scorer->register( new TitleSentimentModule() );
        }
        return $scorer;
    }

    public static function section_auditor(): SeoSectionAuditor {
        static $auditor = null;
        if ( $auditor === null ) {
            $auditor = new SeoSectionAuditor();
        }
        return $auditor;
    }
}
