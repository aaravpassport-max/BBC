<?php
namespace GoodService\SEO;

use GoodService\SEO\Contracts\SeoModuleInterface;

/**
 * Runs every registered module against a listing and produces the
 * single thing a vendor actually needs: an overall score, and a
 * checklist sorted so the highest-impact fix is always first.
 */
final class SeoScorer {

    /** @var SeoModuleInterface[] */
    private array $modules = [];

    public function register( SeoModuleInterface $module ): void {
        $this->modules[ $module->key() ] = $module;
    }

    public function score( object $listing ): array {
        $all_checks = [];
        foreach ( $this->modules as $module ) {
            foreach ( $module->evaluate( $listing ) as $check ) {
                $all_checks[] = [ 'module' => $module->key(), 'module_label' => $module->label(), 'check' => $check ];
            }
        }

        $earned = array_sum( array_map( fn( $c ) => $c['check']->points, $all_checks ) );
        $max    = array_sum( array_map( fn( $c ) => $c['check']->max_points, $all_checks ) );
        $overall = $max > 0 ? (int) round( ( $earned / $max ) * 100 ) : 0;

        // Priority order a vendor should actually work through, highest
        // real-world impact first — not alphabetical, not by module.
        $priority_rank = [ 'critical' => 0, 'high' => 1, 'medium' => 2, 'low' => 3 ];
        $failing = array_values( array_filter( $all_checks, fn( $c ) => ! $c['check']->passed ) );
        usort( $failing, fn( $a, $b ) => $priority_rank[ $a['check']->priority ] <=> $priority_rank[ $b['check']->priority ] );

        return [
            'overall_score'   => $overall,
            'points_earned'   => $earned,
            'points_possible' => $max,
            'checklist'       => $failing,       // what to fix, in priority order
            'all_checks'      => $all_checks,     // full detail, including passes
        ];
    }
}
