<?php
namespace GoodService\SEO;

/**
 * Single source of truth for "what is this listing's focus keyword."
 * Every module was independently inferring this as category+city —
 * this platform actually has a real, dedicated seo_focus_keyword field
 * that was never being checked. Uses it when a vendor/admin has set it
 * explicitly; falls back to the inferred category+city only when it's
 * empty, so nothing breaks for listings that haven't set one yet.
 */
final class FocusKeywordResolver {

    public static function resolve( object $listing ): string {
        $explicit = trim( (string) ( $listing->seo_focus_keyword ?? '' ) );
        if ( $explicit !== '' ) {
            return $explicit;
        }
        $category = trim( (string) ( $listing->subcat_name ?? $listing->cat_name ?? '' ) );
        $city = trim( (string) ( $listing->city ?? '' ) );
        return trim( $category . ' ' . $city );
    }

    /** True if this listing has a real, vendor/admin-set focus keyword — vs. an inferred one. */
    public static function is_explicit( object $listing ): bool {
        return trim( (string) ( $listing->seo_focus_keyword ?? '' ) ) !== '';
    }
}
