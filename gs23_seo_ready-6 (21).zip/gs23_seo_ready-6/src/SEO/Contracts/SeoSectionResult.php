<?php
namespace GoodService\SEO\Contracts;

/**
 * One editable section of the vendor page (Hero, About, Gallery, ...)
 * scored for completeness. This is what lets the dashboard say
 * "Gallery: 40% complete — missing 3 things" instead of one flat
 * overall number.
 */
final class SeoSectionResult {

    /** @var SeoCheckResult[] */
    public readonly array $checks;
    public readonly int $completion_percent;

    public function __construct(
        public readonly string $key,     // 'hero', 'about', 'gallery'
        public readonly string $label,   // 'Hero Section'
        array $checks
    ) {
        $this->checks = $checks;
        $earned = array_sum( array_map( fn( $c ) => $c->points, $checks ) );
        $max    = array_sum( array_map( fn( $c ) => $c->max_points, $checks ) );
        $this->completion_percent = $max > 0 ? (int) round( ( $earned / $max ) * 100 ) : 100;
    }

    /** @return SeoCheckResult[] only what's still missing, worst first */
    public function missing(): array {
        $priority_rank = [ 'critical' => 0, 'high' => 1, 'medium' => 2, 'low' => 3 ];
        $missing = array_values( array_filter( $this->checks, fn( $c ) => ! $c->passed ) );
        usort( $missing, fn( $a, $b ) => $priority_rank[ $a->priority ] <=> $priority_rank[ $b->priority ] );
        return $missing;
    }
}
