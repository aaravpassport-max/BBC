<?php
namespace GoodService\SEO\Contracts;

/**
 * One single check's outcome — e.g. "title length", "keyword in title".
 * A module returns an array of these. The dashboard renders each one as
 * a row: pass/fail, plain-English fix, priority, points.
 */
final class SeoCheckResult {

    public function __construct(
        public readonly string $key,          // 'title_length'
        public readonly string $label,        // 'Title length'
        public readonly bool   $passed,
        public readonly int    $points,       // points earned
        public readonly int    $max_points,   // points possible
        public readonly string $priority,     // 'critical' | 'high' | 'medium' | 'low'
        public readonly string $message,      // plain-English explanation, always present
        public readonly ?string $fix = null,  // plain-English fix, only when failed
    ) {}

    public static function pass( string $key, string $label, int $points, string $message ): self {
        return new self( $key, $label, true, $points, $points, 'low', $message );
    }

    public static function fail( string $key, string $label, int $max_points, string $priority, string $message, string $fix ): self {
        return new self( $key, $label, false, 0, $max_points, $priority, $message, $fix );
    }

    public static function partial( string $key, string $label, int $points, int $max_points, string $priority, string $message, string $fix ): self {
        return new self( $key, $label, $points === $max_points, $points, $max_points, $priority, $message, $points === $max_points ? null : $fix );
    }
}
