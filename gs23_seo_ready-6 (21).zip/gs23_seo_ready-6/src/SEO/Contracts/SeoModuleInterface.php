<?php
namespace GoodService\SEO\Contracts;

/**
 * Every SEO module (Metadata, Schema, LocalSEO, ...) implements this.
 * The Vendor SEO Intelligence dashboard just aggregates whatever modules
 * are registered — adding a new check means adding a new module, not
 * touching the aggregator.
 */
interface SeoModuleInterface {

    /** Machine key, e.g. 'metadata', 'schema', 'local_seo' */
    public function key(): string;

    /** Human label shown in the dashboard, e.g. 'Title & Description' */
    public function label(): string;

    /**
     * Run every check for this module against one listing.
     * Returns a SeoCheckResult[] — one per individual check, never one
     * lump score. The vendor needs to see WHICH thing is wrong, not just
     * a number.
     */
    public function evaluate( object $listing ): array;
}
