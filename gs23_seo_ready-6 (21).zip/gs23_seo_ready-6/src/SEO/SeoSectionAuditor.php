<?php
namespace GoodService\SEO;

use GoodService\SEO\Contracts\SeoCheckResult;
use GoodService\SEO\Contracts\SeoSectionResult;

/**
 * Answers the actual question: "what do I need to add to make THIS
 * section 100%?" — one SeoSectionResult per editable area of the
 * vendor page, each with its own completion percentage and missing-item
 * list. This is separate from SeoScorer (which scores metadata/schema
 * quality); this scores CONTENT COMPLETENESS per section.
 */
final class SeoSectionAuditor {

    /**
     * Real fix, closing a gap identified directly: checks whether a
     * section is genuinely toggled visible on the live page, using the
     * exact same mechanism vendor-site.php itself uses for this —
     * customizer_data['element_config'][$element_id]['visible'],
     * defaulting to true unless explicitly set false. Hidden sections
     * have zero SEO impact (nothing not rendered can be crawled), so
     * scoring them as "incomplete" would be actively wrong advice.
     */
    private function is_element_visible( object $listing, string $element_id ): bool {
        $cd = json_decode( (string) ( $listing->customizer_data ?? '{}' ), true );
        $elcfg = is_array( $cd ) ? ( $cd['element_config'] ?? [] ) : [];
        $user = is_array( $elcfg ) ? ( $elcfg[ $element_id ] ?? [] ) : [];
        return (bool) ( $user['visible'] ?? true );
    }

    /** A single, honest "hidden — not scored" result for a toggled-off section. */
    private function hidden_result( string $key, string $label ): SeoSectionResult {
        return new SeoSectionResult( $key, $label, [
            SeoCheckResult::pass( $key . '_hidden', 'Section visibility', 1,
                'This section is currently hidden on your live page (toggled off in your page customizer), so it isn\'t scored — hidden content has no SEO effect either way. Turn it back on if you want it to count.' ),
        ] );
    }

    /** @return SeoSectionResult[] keyed by section key */
    public function audit( object $listing, array $context = [] ): array {
        $gallery_count = (int) ( $context['gallery_count'] ?? 0 );
        $review_count  = (int) ( $context['review_count'] ?? 0 );
        $review_avg    = (float) ( $context['review_avg'] ?? 0 );
        $faq_count     = (int) ( $context['faq_count'] ?? 0 );
        $badge_count   = (int) ( $context['badge_count'] ?? 0 );

        return [
            'hero'     => $this->hero( $listing ),
            'about'    => $this->about( $listing ),
            'gallery'  => $this->gallery( $listing, $gallery_count ),
            'contact'  => $this->contact( $listing ),
            'trust'    => $this->trust( $listing, $review_count, $review_avg, $badge_count ),
            'services' => $this->services( $listing ),
            'faq'      => $this->faq( $faq_count ),
            'process'      => $this->is_element_visible( $listing, 'process_steps' )    ? $this->process( $listing )      : $this->hidden_result( 'process', 'Process / How It Works' ),
            'items'        => $this->is_element_visible( $listing, 'items_grid' )       ? $this->items( $listing )        : $this->hidden_result( 'items', 'Products / Services Items' ),
            'stats'        => $this->is_element_visible( $listing, 'stats_grid' )       ? $this->stats( $listing )        : $this->hidden_result( 'stats', 'Trust Stats' ),
            'why'          => $this->is_element_visible( $listing, 'why_grid' )         ? $this->why_choose( $listing )   : $this->hidden_result( 'why_choose', 'Why Choose Us' ),
            'team'         => $this->is_element_visible( $listing, 'team_grid' )        ? $this->team( $listing )         : $this->hidden_result( 'team', 'Team' ),
            'clients'      => $this->is_element_visible( $listing, 'clients_logos' )    ? $this->clients( $listing )      : $this->hidden_result( 'clients', 'Client Logos' ),
            'pricing'      => $this->is_element_visible( $listing, 'pricing_grid' )     ? $this->pricing( $listing )      : $this->hidden_result( 'pricing', 'Pricing Plans' ),
            'portfolio'    => $this->is_element_visible( $listing, 'portfolio_grid' )   ? $this->portfolio( $listing )    : $this->hidden_result( 'portfolio', 'Portfolio' ),
            'testimonials' => $this->is_element_visible( $listing, 'testimonials_grid' ) ? $this->testimonials( $listing ) : $this->hidden_result( 'testimonials', 'Curated Testimonials' ),
            'languages'    => $this->is_element_visible( $listing, 'languages_list' )    ? $this->languages( $listing )    : $this->hidden_result( 'languages', 'Languages Spoken' ),
            'packages'     => $this->is_element_visible( $listing, 'packages_grid' )     ? $this->packages( $listing )     : $this->hidden_result( 'packages', 'Packages & Pricing' ),
            'memberships'  => $this->is_element_visible( $listing, 'memberships_grid' )  ? $this->memberships( $listing )  : $this->hidden_result( 'memberships', 'Membership Plans' ),
            'warranty'     => $this->is_element_visible( $listing, 'warranty_block' )     ? $this->warranty( $listing )     : $this->hidden_result( 'warranty', 'Warranty / Guarantee' ),
            'terms'        => $this->is_element_visible( $listing, 'terms_block' )        ? $this->terms( $listing )        : $this->hidden_result( 'terms', 'Terms & Conditions' ),
        ];
    }

    private function hero( object $l ): SeoSectionResult {
        $c = [];
        $c[] = $l->logo_url
            ? SeoCheckResult::pass( 'logo', 'Logo uploaded', 20, 'A logo builds instant trust and shows in search/social previews.' )
            : SeoCheckResult::fail( 'logo', 'Logo uploaded', 20, 'critical', 'No logo uploaded — your listing shows a generic placeholder.', 'Upload a square logo (at least 512x512px) in your listing settings.' );

        $c[] = $l->banner_url
            ? SeoCheckResult::pass( 'cover', 'Cover image set', 20, 'A cover image makes the hero section feel complete and professional.' )
            : SeoCheckResult::fail( 'cover', 'Cover image set', 20, 'high', 'No cover/hero image set.', 'Upload a wide banner image (1600x600px recommended) representing your business.' );

        $tagline = trim( (string) ( $l->tagline ?? '' ) );
        $c[] = $tagline !== ''
            ? SeoCheckResult::pass( 'tagline', 'Tagline set', 15, 'A short tagline gives visitors an instant sense of what you do.' )
            : SeoCheckResult::fail( 'tagline', 'Tagline set', 15, 'medium', 'No tagline set under your business name.', 'Add a one-line tagline, e.g. "Trusted plumbing since 2015."' );

        $c[] = ( trim( (string) ( $l->phone ?? '' ) ) !== '' )
            ? SeoCheckResult::pass( 'hero_cta', 'Contact button works', 15, 'Your phone number is set, so the hero call-to-action button will work.' )
            : SeoCheckResult::fail( 'hero_cta', 'Contact button works', 15, 'critical', 'No phone number set — your main "Call Now" button has nothing to call.', 'Add a phone number in your listing settings.' );

        // ── Highlights (sub-element) ──────────────────────────────────
        // Real field confirmed: a newline-separated text field, shown in
        // both the Hero and About sections from the exact same data —
        // one check here covers both, since they're not independent.
        $highlights = array_filter( array_map( 'trim', explode( "\n", (string) ( $l->highlights ?? '' ) ) ) );
        $c[] = ! empty( $highlights )
            ? SeoCheckResult::pass( 'highlights', 'Highlights list', 10, count( $highlights ) . ' highlight(s) set — shown in both your Hero and About sections.' )
            : SeoCheckResult::fail( 'highlights', 'Highlights list', 10, 'low',
                'No highlights added (e.g. "Licensed & Insured", "24/7 Support").',
                'Add 3-4 short highlights — these show as quick trust bullets in both your Hero and About sections.' );

        return new SeoSectionResult( 'hero', 'Hero Section', $c );
    }

    private function about( object $l ): SeoSectionResult {
        $c = [];
        $desc = trim( (string) ( $l->full_desc ?: $l->short_desc ?? '' ) );
        $words = $desc === '' ? 0 : str_word_count( $desc );
        // 300+ words is a widely-used threshold for "substantial" page
        // content across SEO tooling and Google's own thin-content
        // guidance discussions — not any one plugin's specific rule.
        if ( $words === 0 ) {
            $c[] = SeoCheckResult::fail( 'about_length', 'About description', 30, 'critical',
                'No business description at all — this is one of the biggest gaps for both SEO and customer trust.',
                'Write at least 150 words about your business: what you do, your experience, and what makes you different.' );
        } elseif ( $words < 100 ) {
            $c[] = SeoCheckResult::partial( 'about_length', 'About description', 12, 30, 'high',
                "Your description is only {$words} words — too thin for Google to understand what you offer in depth.",
                'Expand to at least 150 words. Mention your services, experience, and service area.' );
        } elseif ( $words < 150 ) {
            $c[] = SeoCheckResult::partial( 'about_length', 'About description', 22, 30, 'medium',
                "Your description is {$words} words — close, but a bit short.",
                'Add another 1-2 sentences about your experience or specialties to reach 150+ words.' );
        } else {
            $c[] = SeoCheckResult::pass( 'about_length', 'About description', 30, "Your description is {$words} words — a healthy amount of content." );
        }

        // ── Stats row (sub-element) ────────────────────────────────────
        // Real fields confirmed: established_year, team_size, price_min/
        // price_max all live directly on the listing row.
        $stats_filled = array_filter( [
            trim( (string) ( $l->established_year ?? '' ) ),
            trim( (string) ( $l->team_size ?? '' ) ),
            trim( (string) ( $l->price_min ?? '' ) ) . trim( (string) ( $l->price_max ?? '' ) ),
        ] );
        $c[] = ! empty( $stats_filled )
            ? SeoCheckResult::pass( 'about_stats', 'Founded/team/price stats', 10, count( $stats_filled ) . ' of 3 quick-stat field(s) filled in.' )
            : SeoCheckResult::fail( 'about_stats', 'Founded/team/price stats', 10, 'low',
                'None of your founding year, team size, or price range are set.',
                'Fill in at least one — these show as quick, scannable trust stats right under your description.' );

        // ── CTA button (sub-element) ─────────────────────────────────
        $about_raw = json_decode( (string) ( $l->about_data ?? '{}' ), true );
        $about_cta = is_array( $about_raw ) ? trim( (string) ( $about_raw['about_cta_text'] ?? '' ) ) : '';
        $c[] = $about_cta !== ''
            ? SeoCheckResult::pass( 'about_cta', 'About section CTA button', 5, 'A call-to-action button is set under your About description.' )
            : SeoCheckResult::pass( 'about_cta', 'About section CTA button', 5, 'No custom CTA button set — optional, the section still works without one.' );

        // ── Video (sub-element) ───────────────────────────────────────
        $video_url = trim( (string) ( $l->video_url ?? '' ) );
        $c[] = $video_url !== ''
            ? SeoCheckResult::pass( 'about_video', 'Intro video', 5, 'A video is set — video content tends to increase time-on-page.' )
            : SeoCheckResult::pass( 'about_video', 'Intro video', 5, 'No video set — optional, but a short intro video can meaningfully boost engagement if you have one.' );

        return new SeoSectionResult( 'about', 'About Us', $c );
    }

    private function gallery( object $l, int $count ): SeoSectionResult {
        $c = [];
        // 6+ images is a common recommendation across local-listing best
        // practices (Google Business Profile itself nudges toward this
        // range) as the point where a gallery starts feeling "complete"
        // rather than sparse.
        if ( $count === 0 ) {
            $c[] = SeoCheckResult::fail( 'gallery_count', 'Gallery has photos', 25, 'critical',
                'No gallery photos uploaded — listings with photos get significantly more engagement.',
                'Upload at least 6 photos of your work, premises, or team.' );
        } elseif ( $count < 3 ) {
            $c[] = SeoCheckResult::partial( 'gallery_count', 'Gallery has photos', 8, 25, 'high',
                "Only {$count} photo(s) uploaded.", 'Add more photos — aim for at least 6 to give visitors a full picture.' );
        } elseif ( $count < 6 ) {
            $c[] = SeoCheckResult::partial( 'gallery_count', 'Gallery has photos', 18, 25, 'medium',
                "{$count} photos uploaded — a good start.", 'Add a few more to reach 6+ for a fuller gallery.' );
        } else {
            $c[] = SeoCheckResult::pass( 'gallery_count', 'Gallery has photos', 25, "{$count} photos uploaded — a well-stocked gallery." );
        }
        return new SeoSectionResult( 'gallery', 'Photo Gallery', $c );
    }

    private function contact( object $l ): SeoSectionResult {
        $c = [];
        $fields = [
            'phone'   => [ 'Phone number', 20, 'critical' ],
            'whatsapp'=> [ 'WhatsApp number', 15, 'high' ],
            'email'   => [ 'Email address', 15, 'medium' ],
            'address' => [ 'Full address', 25, 'critical' ],
            'city'    => [ 'City set', 25, 'critical' ],
        ];
        foreach ( $fields as $field => [ $label, $points, $priority ] ) {
            $val = trim( (string) ( $l->$field ?? '' ) );
            $c[] = $val !== ''
                ? SeoCheckResult::pass( $field, $label, $points, "{$label} is set — customers and Google can find this." )
                : SeoCheckResult::fail( $field, $label, $points, $priority, "{$label} is missing.", "Add your {$label} in listing settings — this is required for local search visibility." );
        }

        // ── Website (sub-element) ────────────────────────────────────
        $website = trim( (string) ( $l->website ?? '' ) );
        $c[] = $website !== ''
            ? SeoCheckResult::pass( 'website', 'Website link', 5, 'A website link is set.' )
            : SeoCheckResult::pass( 'website', 'Website link', 5, 'No website set — optional if you don\'t have one outside this platform.' );

        // ── Opening hours (sub-element) ───────────────────────────────
        $oh_raw = json_decode( (string) ( $l->opening_hours ?? '[]' ), true );
        $has_hours = is_array( $oh_raw ) && count( array_filter( $oh_raw ) ) > 0;
        $c[] = $has_hours
            ? SeoCheckResult::pass( 'opening_hours', 'Opening hours set', 10, 'Your opening hours are set — enables "Open now" display and helps local search relevance.' )
            : SeoCheckResult::fail( 'opening_hours', 'Opening hours set', 10, 'low',
                'No opening hours set.', 'Add your opening hours — this is a genuine, checkable local SEO signal, not just a display convenience.' );

        // ── Map embed (sub-element) ────────────────────────────────────
        $map = trim( (string) ( $l->map_embed ?? '' ) );
        $c[] = $map !== ''
            ? SeoCheckResult::pass( 'contact_map', 'Map embedded', 10, 'A map is embedded — helps visitors confirm your location instantly.' )
            : SeoCheckResult::fail( 'contact_map', 'Map embedded', 10, 'low',
                'No map embedded on your contact section.', 'Add a Google Maps embed — this is a quick, high-trust addition for a local business.' );

        // ── Awards & certifications (sub-elements) ─────────────────────
        $awards = trim( (string) ( $l->awards ?? '' ) );
        $certs = trim( (string) ( $l->certifications ?? '' ) );
        $c[] = ( $awards !== '' || $certs !== '' )
            ? SeoCheckResult::pass( 'awards_certs', 'Awards/certifications listed', 10,
                'You\'ve listed ' . implode( ' and ', array_filter( [ $awards !== '' ? 'awards' : null, $certs !== '' ? 'certifications' : null ] ) ) . '.' )
            : SeoCheckResult::pass( 'awards_certs', 'Awards/certifications listed', 10,
                'No awards or certifications listed — optional, but a real, relevant credential is a strong trust signal if you have one.' );

        // ── Tags (sub-element) ──────────────────────────────────────────
        $tags = array_filter( array_map( 'trim', explode( ',', (string) ( $l->tags ?? '' ) ) ) );
        $c[] = ! empty( $tags )
            ? SeoCheckResult::pass( 'contact_tags', 'Tags/keywords set', 5, count( $tags ) . ' tag(s) set — helps with search filtering and topical relevance.' )
            : SeoCheckResult::fail( 'contact_tags', 'Tags/keywords set', 5, 'low',
                'No tags set on this listing.', 'Add a few relevant tags — these help with search filtering on the platform itself.' );

        return new SeoSectionResult( 'contact', 'Contact Information', $c );
    }

    private function trust( object $l, int $reviews, float $avg, int $badges ): SeoSectionResult {
        $c = [];
        if ( $reviews === 0 ) {
            $c[] = SeoCheckResult::fail( 'reviews', 'Customer reviews', 40, 'critical',
                'No reviews yet — review count and rating are strong trust signals for both visitors and Google\'s rich results.',
                'Ask recent customers to leave a review. Even 3-5 genuine reviews make a real difference.' );
        } elseif ( $reviews < 5 ) {
            $c[] = SeoCheckResult::partial( 'reviews', 'Customer reviews', 20, 40, 'high',
                "{$reviews} review(s) so far.", 'Keep asking customers for reviews — 5+ gives visitors real confidence.' );
        } else {
            $c[] = SeoCheckResult::pass( 'reviews', 'Customer reviews', 40, "{$reviews} reviews with a {$avg}-star average — a strong trust signal." );
        }

        $c[] = $badges > 0
            ? SeoCheckResult::pass( 'badges', 'Certifications/badges', 20, "{$badges} badge(s) displayed." )
            : SeoCheckResult::fail( 'badges', 'Certifications/badges', 20, 'low', 'No certification or trust badges uploaded.', 'If you have any certifications, licenses, or awards, upload them as badges.' );

        return new SeoSectionResult( 'trust', 'Trust Signals', $c );
    }

    private function services( object $l ): SeoSectionResult {
        $c = [];
        $has_cat = trim( (string) ( $l->subcat_name ?? $l->cat_name ?? '' ) ) !== '';
        $c[] = $has_cat
            ? SeoCheckResult::pass( 'category', 'Service category set', 30, 'A specific category helps you show up in the right searches and filters.' )
            : SeoCheckResult::fail( 'category', 'Service category set', 30, 'critical', 'No service category selected.', 'Choose the most specific category available for what you do.' );

        // Real fix — confirmed gap: services_data (the actual Services
        // entries vendors add, each with its own Description popup) was
        // never checked here at all, only the category dropdown.
        $svc_items = \GoodService\SEO\SeoContentExtractor::decode_items( $l->services_data ?? null );
        $svc_count = count( $svc_items );
        if ( $svc_count > 0 ) {
            $missing_desc = count( array_filter( $svc_items, fn( $i ) => trim( (string) ( $i['description'] ?? '' ) ) === '' ) );
            $c[] = $missing_desc === 0
                ? SeoCheckResult::pass( 'svc_desc', 'Services have descriptions', 15, "Every service ({$svc_count}) has a description." )
                : SeoCheckResult::partial( 'svc_desc', 'Services have descriptions', (int) round( 15 * ( ( $svc_count - $missing_desc ) / $svc_count ) ), 15, 'medium',
                    "{$missing_desc} of {$svc_count} service(s) have no description.",
                    'Add a clear description to each service — this is content customers and search engines both read.' );

            $with_popup = count( array_filter( $svc_items, fn( $i ) => \GoodService\SEO\SeoContentExtractor::extract_view_more_text( $i['view_more_sections'] ?? [] ) !== '' ) );
            $c[] = $with_popup > 0
                ? SeoCheckResult::pass( 'svc_popup_content', 'Service detail popups have content', 10, "{$with_popup} of {$svc_count} service(s) have expanded \"View More\" detail content." )
                : SeoCheckResult::pass( 'svc_popup_content', 'Service detail popups have content', 10,
                    'No expanded detail content added yet — optional, but a good place for FAQs, process steps, or a longer explanation of each service.' );
        }
        return new SeoSectionResult( 'services', 'Services & Category', $c );
    }

    private function faq( int $count ): SeoSectionResult {
        $c = [];
        // FAQ content is directly eligible for Google's FAQ rich result
        // schema — a well-documented, publicly available schema.org type.
        if ( $count === 0 ) {
            $c[] = SeoCheckResult::fail( 'faq_count', 'FAQ section', 100, 'medium',
                'No FAQs added — this is a missed opportunity for both customer questions and potential rich results in Google search.',
                'Add 3-5 common questions customers ask, with clear answers.' );
        } elseif ( $count < 3 ) {
            $c[] = SeoCheckResult::partial( 'faq_count', 'FAQ section', 50, 100, 'low',
                "{$count} FAQ(s) added.", 'Add a couple more common questions to round this out.' );
        } else {
            $c[] = SeoCheckResult::pass( 'faq_count', 'FAQ section', 100, "{$count} FAQs added." );
        }
        return new SeoSectionResult( 'faq', 'FAQ', $c );
    }

    private function process( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->process_data ?? '[]' ), true );
        $steps = is_array( $raw ) ? array_filter( $raw, fn( $s ) => ! empty( $s['title'] ?? null ) ) : [];
        $count = count( $steps );
        // Optional section — many listing types don't need a "how it
        // works" process explanation, so absence isn't penalized hard.
        if ( $count === 0 ) {
            $c[] = SeoCheckResult::pass( 'process_steps', 'Process/how-it-works steps', 10,
                'No process steps added — optional, but useful if your service has a clear multi-step workflow customers should understand.' );
        } elseif ( $count < 3 ) {
            $c[] = SeoCheckResult::partial( 'process_steps', 'Process/how-it-works steps', 6, 10, 'low',
                "{$count} step(s) added.", 'Most "how it works" sections read best with 3-4 clear steps.' );
        } else {
            $c[] = SeoCheckResult::pass( 'process_steps', 'Process/how-it-works steps', 10, "{$count} process steps added." );
        }
        $missing_desc = count( array_filter( $steps, fn( $s ) => empty( $s['description'] ?? null ) ) );
        if ( $count > 0 && $missing_desc > 0 ) {
            $c[] = SeoCheckResult::partial( 'process_step_desc', 'Process steps have descriptions', 5, 10, 'low',
                "{$missing_desc} of {$count} step(s) have a title but no description.",
                'Add a short description to each step — a title alone doesn\'t explain what actually happens.' );
        } elseif ( $count > 0 ) {
            $c[] = SeoCheckResult::pass( 'process_step_desc', 'Process steps have descriptions', 10, 'Every step has both a title and a description.' );
        }
        return new SeoSectionResult( 'process', 'Process / How It Works', $c );
    }

    private function items( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->items_data ?? '[]' ), true );
        $items = is_array( $raw ) ? array_filter( $raw, fn( $i ) => ! empty( $i['item_title'] ?? $i['name'] ?? null ) ) : [];
        $count = count( $items );
        if ( $count === 0 ) {
            $c[] = SeoCheckResult::pass( 'items_count', 'Products/services items', 10,
                'No individual items added — optional if your Services & Category section already covers what you offer.' );
        } else {
            $c[] = SeoCheckResult::pass( 'items_count', 'Products/services items', 10, "{$count} item(s) listed." );
            $missing_img = count( array_filter( $items, fn( $i ) => empty( $i['item_image'] ?? null ) ) );
            $missing_desc = count( array_filter( $items, fn( $i ) => empty( $i['item_description'] ?? null ) ) );
            $c[] = $missing_img === 0
                ? SeoCheckResult::pass( 'items_images', 'Items have images', 10, 'Every item has an image.' )
                : SeoCheckResult::partial( 'items_images', 'Items have images', (int) round( 10 * ( ( $count - $missing_img ) / $count ) ), 10, 'low',
                    "{$missing_img} of {$count} item(s) have no image.", 'Add a photo to each item — listings with images get more engagement.' );
            $c[] = $missing_desc === 0
                ? SeoCheckResult::pass( 'items_desc', 'Items have descriptions', 10, 'Every item has a description.' )
                : SeoCheckResult::partial( 'items_desc', 'Items have descriptions', (int) round( 10 * ( ( $count - $missing_desc ) / $count ) ), 10, 'low',
                    "{$missing_desc} of {$count} item(s) have no description.", 'Add a short description to each item.' );
        }

        // Real fix — confirmed gap: products_data (the actual Products
        // entries vendors add via create-listing.php, each with its own
        // Description popup) was never checked anywhere in this codebase
        // — items_data above is a separate, legacy field. Verified field
        // names (name/description/view_more_sections) directly against
        // the real create-listing.php form output before writing this.
        //
        // Real fix, follow-on: items here can each be individually typed
        // Product or Service (products[n][item_type], a real per-item
        // toggle confirmed against the actual form field) — split here
        // too, matching the same fix already applied in
        // ProductsServicesContentModule, so this Section Completeness
        // view never disagrees with the scored checklist about which
        // items are products vs services.
        $all_prod_items = \GoodService\SEO\SeoContentExtractor::decode_items( $l->products_data ?? null );
        $prod_items = array_values( array_filter( $all_prod_items, fn( $i ) => ( $i['item_type'] ?? 'service' ) !== 'service' ) );
        $svc_typed_items = array_values( array_filter( $all_prod_items, fn( $i ) => ( $i['item_type'] ?? 'service' ) === 'service' ) );
        $prod_count = count( $prod_items );
        if ( $prod_count > 0 ) {
            $missing_pdesc = count( array_filter( $prod_items, fn( $i ) => trim( (string) ( $i['description'] ?? '' ) ) === '' ) );
            $c[] = $missing_pdesc === 0
                ? SeoCheckResult::pass( 'products_desc', 'Products have descriptions', 15, "Every product ({$prod_count}) has a description." )
                : SeoCheckResult::partial( 'products_desc', 'Products have descriptions', (int) round( 15 * ( ( $prod_count - $missing_pdesc ) / $prod_count ) ), 15, 'medium',
                    "{$missing_pdesc} of {$prod_count} product(s) have no description.",
                    'Add a clear description to each product — this is content customers and search engines both read.' );
        }
        $svc_typed_count = count( $svc_typed_items );
        if ( $svc_typed_count > 0 ) {
            $missing_sdesc = count( array_filter( $svc_typed_items, fn( $i ) => trim( (string) ( $i['description'] ?? '' ) ) === '' ) );
            $c[] = $missing_sdesc === 0
                ? SeoCheckResult::pass( 'products_section_services_desc', 'Service-typed items have descriptions', 15, "Every service-typed item ({$svc_typed_count}) has a description." )
                : SeoCheckResult::partial( 'products_section_services_desc', 'Service-typed items have descriptions', (int) round( 15 * ( ( $svc_typed_count - $missing_sdesc ) / $svc_typed_count ) ), 15, 'medium',
                    "{$missing_sdesc} of {$svc_typed_count} service-typed item(s) have no description.",
                    'Add a clear description to each — these are marked as services in your Products & Services section.' );
        }
        return new SeoSectionResult( 'items', 'Products / Services Items', $c );
    }

    private function stats( object $l ): SeoSectionResult {
        $c = [];
        // Real fix: stats_data is structurally different from every
        // other section here — confirmed by reading the real code — a
        // flat {key: value} object (e.g. {happy_clients: '200'}), not an
        // array of items. Treated accordingly, not forced into the same
        // "array of objects" pattern as the rest.
        $raw = json_decode( (string) ( $l->stats_data ?? '{}' ), true );
        $filled = is_array( $raw ) ? count( array_filter( $raw, fn( $v ) => trim( (string) $v ) !== '' ) ) : 0;
        if ( $filled === 0 ) {
            $c[] = SeoCheckResult::pass( 'stats_filled', 'Trust stats (clients served, years, etc.)', 10,
                'No stats filled in — optional, but real numbers (years in business, clients served) build quick trust.' );
        } elseif ( $filled < 3 ) {
            $c[] = SeoCheckResult::partial( 'stats_filled', 'Trust stats (clients served, years, etc.)', 6, 10, 'low',
                "{$filled} stat(s) filled in.", 'Fill in a couple more if you have the numbers — 3+ stats read as more credible than 1.' );
        } else {
            $c[] = SeoCheckResult::pass( 'stats_filled', 'Trust stats (clients served, years, etc.)', 10, "{$filled} stats filled in." );
        }
        return new SeoSectionResult( 'stats', 'Trust Stats', $c );
    }

    private function why_choose( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->why_choose_data ?? '[]' ), true );
        if ( is_array( $raw ) ) { unset( $raw['section_title'] ); } // real structure quirk confirmed in the template
        $reasons = is_array( $raw ) ? array_filter( $raw, fn( $r ) => ! empty( $r['title'] ?? null ) ) : [];
        $count = count( $reasons );
        if ( $count === 0 ) {
            $c[] = SeoCheckResult::fail( 'why_choose', '"Why choose us" reasons', 15, 'low',
                'No "why choose us" reasons added — this is a direct opportunity to state your advantages that\'s currently empty.',
                'Add 3-4 genuine reasons customers should pick you over competitors.' );
        } elseif ( $count < 3 ) {
            $c[] = SeoCheckResult::partial( 'why_choose', '"Why choose us" reasons', 8, 15, 'low',
                "{$count} reason(s) added.", 'Add a couple more — 3-4 reasons is a common, effective amount.' );
        } else {
            $c[] = SeoCheckResult::pass( 'why_choose', '"Why choose us" reasons', 15, "{$count} reasons added." );
        }
        return new SeoSectionResult( 'why_choose', 'Why Choose Us', $c );
    }

    private function team( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->team_data ?? '[]' ), true );
        $members = is_array( $raw ) ? array_filter( $raw, fn( $m ) => ! empty( $m['name'] ?? null ) ) : [];
        $count = count( $members );
        if ( $count === 0 ) {
            $c[] = SeoCheckResult::pass( 'team_count', 'Team section', 10,
                'No team members added — optional, but showing real people behind the business builds trust (E-E-A-T signal).' );
        } else {
            $missing_photo = count( array_filter( $members, fn( $m ) => empty( $m['photo'] ?? null ) ) );
            $c[] = SeoCheckResult::pass( 'team_count', 'Team section', 10, "{$count} team member(s) added." );
            $c[] = $missing_photo === 0
                ? SeoCheckResult::pass( 'team_photos', 'Team members have photos', 10, 'Every team member has a photo.' )
                : SeoCheckResult::partial( 'team_photos', 'Team members have photos', (int) round( 10 * ( ( $count - $missing_photo ) / $count ) ), 10, 'low',
                    "{$missing_photo} of {$count} team member(s) have no photo.", 'Add a real photo for each team member — placeholders read as less trustworthy.' );
        }
        return new SeoSectionResult( 'team', 'Team', $c );
    }

    private function clients( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->clients_data ?? '[]' ), true );
        $clients = is_array( $raw ) ? array_filter( $raw, fn( $cl ) => ! empty( $cl['name'] ?? null ) || ! empty( $cl['logo'] ?? null ) ) : [];
        $count = count( $clients );
        $c[] = $count === 0
            ? SeoCheckResult::pass( 'clients_count', 'Client logos', 10,
                'No client logos added — optional, but recognizable client names/logos are a strong trust signal if you have permission to display them.' )
            : SeoCheckResult::pass( 'clients_count', 'Client logos', 10, "{$count} client(s) shown." );
        return new SeoSectionResult( 'clients', 'Client Logos', $c );
    }

    /**
     * Languages Spoken — a name + proficiency level, no prose to assess
     * for depth or duplication, so this deliberately uses a simple
     * presence check rather than OtherSectionsContentModule's content-
     * depth/duplicate-detection checks, matching this file's own
     * existing treatment of Clients and Stats (see clients() above and
     * OtherSectionsContentModule's docblock, which explicitly excludes
     * sections with "no meaningful prose content" from that module).
     */
    private function languages( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->languages_data ?? '[]' ), true );
        $languages = is_array( $raw ) ? array_filter( $raw, fn( $lg ) => ! empty( $lg['name'] ?? null ) ) : [];
        $count = count( $languages );
        $c[] = $count === 0
            ? SeoCheckResult::pass( 'languages_count', 'Languages spoken', 10,
                'No languages listed — optional, but useful for tourism, healthcare, legal, or any customer-facing business serving a multilingual audience.' )
            : SeoCheckResult::pass( 'languages_count', 'Languages spoken', 10, "{$count} language(s) listed." );
        return new SeoSectionResult( 'languages', 'Languages Spoken', $c );
    }

    private function pricing( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->pricing_data ?? '[]' ), true );
        $plans = is_array( $raw ) ? array_filter( $raw, fn( $p ) => ! empty( $p['name'] ?? null ) ) : [];
        $count = count( $plans );
        if ( $count === 0 ) {
            $c[] = SeoCheckResult::pass( 'pricing_count', 'Pricing plans', 10,
                'No pricing plans added — optional; many service listings handle pricing via quote requests instead.' );
        } else {
            $missing_features = count( array_filter( $plans, fn( $p ) => empty( $p['features'] ?? null ) ) );
            $c[] = SeoCheckResult::pass( 'pricing_count', 'Pricing plans', 10, "{$count} pricing plan(s) added." );
            $c[] = $missing_features === 0
                ? SeoCheckResult::pass( 'pricing_features', 'Plans list what\'s included', 10, 'Every plan lists its included features.' )
                : SeoCheckResult::partial( 'pricing_features', 'Plans list what\'s included', (int) round( 10 * ( ( $count - $missing_features ) / $count ) ), 10, 'low',
                    "{$missing_features} of {$count} plan(s) don't list included features.", 'List what\'s included in each plan — a bare price with no detail is a weak sell.' );
        }
        return new SeoSectionResult( 'pricing', 'Pricing Plans', $c );
    }

    /**
     * Packages & Pricing — structurally identical to pricing() (a set
     * of priced tiers with a features list), so scored the same way,
     * as its own distinct section from the general Pricing Table.
     */
    private function packages( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->packages_data ?? '[]' ), true );
        $items = is_array( $raw ) ? array_filter( $raw, fn( $p ) => ! empty( $p['name'] ?? null ) ) : [];
        $count = count( $items );
        if ( $count === 0 ) {
            $c[] = SeoCheckResult::pass( 'packages_count', 'Packages', 10,
                'No packages added — optional; useful for bundled offerings like spa packages, tour packages, or event packages.' );
        } else {
            $missing_features = count( array_filter( $items, fn( $p ) => empty( $p['features'] ?? null ) ) );
            $c[] = SeoCheckResult::pass( 'packages_count', 'Packages', 10, "{$count} package(s) added." );
            $c[] = $missing_features === 0
                ? SeoCheckResult::pass( 'packages_features', 'Packages list what\'s included', 10, 'Every package lists its included features.' )
                : SeoCheckResult::partial( 'packages_features', 'Packages list what\'s included', (int) round( 10 * ( ( $count - $missing_features ) / $count ) ), 10, 'low',
                    "{$missing_features} of {$count} package(s) don't list included features.", 'List what\'s included in each package — a bare price with no detail is a weak sell.' );
        }
        return new SeoSectionResult( 'packages', 'Packages & Pricing', $c );
    }

    /**
     * Membership Plans — same pricing-tier shape as packages(), for
     * recurring memberships (benefits field instead of features).
     */
    private function memberships( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->memberships_data ?? '[]' ), true );
        $items = is_array( $raw ) ? array_filter( $raw, fn( $m ) => ! empty( $m['name'] ?? null ) ) : [];
        $count = count( $items );
        if ( $count === 0 ) {
            $c[] = SeoCheckResult::pass( 'memberships_count', 'Membership plans', 10,
                'No membership plans added — optional; useful for gyms, clubs, or subscription-based businesses.' );
        } else {
            $missing_benefits = count( array_filter( $items, fn( $m ) => empty( $m['benefits'] ?? null ) ) );
            $c[] = SeoCheckResult::pass( 'memberships_count', 'Membership plans', 10, "{$count} membership plan(s) added." );
            $c[] = $missing_benefits === 0
                ? SeoCheckResult::pass( 'memberships_benefits', 'Plans list member benefits', 10, 'Every plan lists its member benefits.' )
                : SeoCheckResult::partial( 'memberships_benefits', 'Plans list member benefits', (int) round( 10 * ( ( $count - $missing_benefits ) / $count ) ), 10, 'low',
                    "{$missing_benefits} of {$count} plan(s) don't list member benefits.", 'List what members get with each plan — a bare price with no detail is a weak sell.' );
        }
        return new SeoSectionResult( 'memberships', 'Membership Plans', $c );
    }

    /**
     * Warranty / Guarantee — a single highlighted block, not a repeater,
     * so scored as simple presence + a minimum description length
     * rather than the list-based checks used for repeater sections.
     */
    private function warranty( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->warranty_data ?? '{}' ), true );
        $w = is_array( $raw ) ? $raw : [];
        if ( empty( $w['title'] ?? null ) ) {
            $c[] = SeoCheckResult::pass( 'warranty_present', 'Warranty / guarantee', 10,
                'No warranty or guarantee added — optional, but a clear guarantee can meaningfully reduce buyer hesitation.' );
            return new SeoSectionResult( 'warranty', 'Warranty / Guarantee', $c );
        }
        $c[] = SeoCheckResult::pass( 'warranty_present', 'Warranty / guarantee', 10, 'Warranty/guarantee added: "' . $w['title'] . '".' );
        $desc_len = str_word_count( wp_strip_all_tags( (string) ( $w['description'] ?? '' ) ) );
        $c[] = $desc_len >= 8
            ? SeoCheckResult::pass( 'warranty_detail', 'Warranty has real detail', 8, 'The warranty description gives visitors enough detail to understand the coverage.' )
            : SeoCheckResult::partial( 'warranty_detail', 'Warranty has real detail', 3, 8, 'low',
                'The warranty has a title but little or no description.', 'Explain what\'s covered, for how long, and how to make a claim — a bare title alone leaves visitors unsure what they\'re actually getting.' );
        return new SeoSectionResult( 'warranty', 'Warranty / Guarantee', $c );
    }

    /**
     * Terms & Conditions — a single free-text block, not a repeater.
     * Scored as simple presence only; there's no meaningful "depth" or
     * "duplicate content" check that applies to a legal/policy block.
     */
    private function terms( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->terms_data ?? '{}' ), true );
        $t = is_array( $raw ) ? $raw : [];
        $c[] = empty( $t['content'] ?? null )
            ? SeoCheckResult::pass( 'terms_present', 'Terms & conditions', 5,
                'No terms & conditions added — optional; useful for cancellation policies, booking conditions, or service terms specific to this listing.' )
            : SeoCheckResult::pass( 'terms_present', 'Terms & conditions', 5, 'Terms & conditions added.' );
        return new SeoSectionResult( 'terms', 'Terms & Conditions', $c );
    }

    private function portfolio( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->portfolio_data ?? '[]' ), true );
        $projects = is_array( $raw ) ? array_filter( $raw, fn( $p ) => ! empty( $p['title'] ?? null ) ) : [];
        $count = count( $projects );
        if ( $count === 0 ) {
            $c[] = SeoCheckResult::pass( 'portfolio_count', 'Portfolio / past work', 10,
                'No portfolio projects added — optional, but showing completed work is one of the strongest trust signals available.' );
        } else {
            $missing_img = count( array_filter( $projects, fn( $p ) => empty( $p['image'] ?? null ) ) );
            $c[] = SeoCheckResult::pass( 'portfolio_count', 'Portfolio / past work', 10, "{$count} project(s) shown." );
            $c[] = $missing_img === 0
                ? SeoCheckResult::pass( 'portfolio_images', 'Portfolio items have images', 10, 'Every portfolio project has an image.' )
                : SeoCheckResult::partial( 'portfolio_images', 'Portfolio items have images', (int) round( 10 * ( ( $count - $missing_img ) / $count ) ), 10, 'low',
                    "{$missing_img} of {$count} project(s) have no image.", 'A portfolio without images is much less convincing — add photos of completed work.' );
        }
        return new SeoSectionResult( 'portfolio', 'Portfolio', $c );
    }

    private function testimonials( object $l ): SeoSectionResult {
        $c = [];
        $raw = json_decode( (string) ( $l->testimonials_data ?? '[]' ), true );
        $items = is_array( $raw ) ? array_filter( $raw, fn( $t ) => ! empty( $t['name'] ?? null ) || ! empty( $t['text'] ?? null ) ) : [];
        $count = count( $items );
        // Distinct from the platform's own star-rating Reviews (already
        // covered by the Trust section) — this is vendor-curated
        // testimonial quotes/videos, a separate, genuinely different
        // section in the template.
        $c[] = $count === 0
            ? SeoCheckResult::pass( 'testimonials_count', 'Curated testimonials', 10,
                'No curated testimonials added — optional, separate from your platform star ratings, useful for featuring specific customer quotes.' )
            : SeoCheckResult::pass( 'testimonials_count', 'Curated testimonials', 10, "{$count} testimonial(s) added." );
        return new SeoSectionResult( 'testimonials', 'Curated Testimonials', $c );
    }
}
