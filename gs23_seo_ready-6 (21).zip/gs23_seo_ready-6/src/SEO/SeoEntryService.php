<?php
namespace GoodService\SEO;

use GoodService\Core\Config;

/**
 * SeoEntryService — the engine behind /{microsite-slug}/{seo-keyword-slug}/
 *
 * Turns the vendor's comma-separated "SEO Tags / Keywords" field into a set
 * of validated, deduplicated, intent-clustered SEO Search Entry URLs, each
 * backed by a row in {$wpdb->prefix}gs_seo_microsite_entries.
 *
 * Deliberate design constraints (see requirement doc):
 *  - One row per keyword-slug, NOT one page/content record per keyword.
 *    The listing (gs_listings) remains the single source of truth for all
 *    vendor/business/service/location data; this table stores only the
 *    thin per-keyword metadata needed to render a keyword-specific
 *    head/H1/intro on top of the existing microsite template.
 *  - Only keywords that pass relevance + intent validation ever become
 *    `indexable` — most keywords are expected to remain metadata-only.
 *  - Near-duplicate keywords (same underlying search intent) are
 *    consolidated onto ONE indexable URL rather than each getting its own,
 *    to avoid doorway-page-style proliferation.
 *  - Every keyword is re-validated on every save; a keyword an admin has
 *    manually disabled or rejected is left alone unless the vendor removes
 *    and re-adds it (its slug then simply gets a fresh row after the old
 *    one is pruned).
 */
final class SeoEntryService {

    /** Claim words that must never appear in an auto-indexed keyword unless verified. */
    private const BANNED_CLAIMS = [
        'guaranteed', 'guarantee', '100% approval', '100% guaranteed',
        'cheapest', 'lowest price', 'best', 'no. 1', 'no.1', 'no 1', '#1',
        'number 1', 'number one', 'official government', 'government approved',
        'govt approved', 'certified by government',
    ];

    /** Generic filler tokens stripped before computing an intent signature,
     *  so "birth certificate retrieval" and "birth certificate retrieval
     *  service" cluster onto the same search intent. */
    private const FILLER_TOKENS = [
        'service', 'services', 'provider', 'providers', 'near', 'me', 'online',
        'the', 'a', 'an', 'in', 'at', 'for', 'and', 'of', 'to', 'best',
    ];

    private const VALID_STATUSES = [
        'draft', 'processing', 'validated', 'approved', 'indexable',
        'consolidated', 'rejected', 'disabled',
    ];

    /**
     * Recognized Indian city/state names — used ONLY to detect when a
     * keyword names a specific place at all (Part 26). Not exhaustive by
     * design: an unrecognized word is simply never treated as a location
     * claim (fails closed toward "probably part of the service phrase"),
     * so this list only needs to cover realistic vendor input, not every
     * place name in India. Multi-word entries are listed so "new delhi"
     * matches as one place, not as "new" + "delhi" separately. Sorted
     * longest-first at use time so a longer, more specific name (e.g.
     * "navi mumbai") is matched before a shorter one it contains ("mumbai").
     */
    private const KNOWN_LOCATIONS = [
        'new delhi', 'delhi', 'gurgaon', 'gurugram', 'noida', 'greater noida',
        'faridabad', 'ghaziabad', 'navi mumbai', 'mumbai', 'thane', 'pune',
        'bangalore', 'bengaluru', 'chennai', 'hyderabad', 'secunderabad',
        'kolkata', 'ahmedabad', 'surat', 'vadodara', 'rajkot', 'jaipur',
        'jodhpur', 'udaipur', 'lucknow', 'kanpur', 'agra', 'varanasi',
        'allahabad', 'prayagraj', 'chandigarh', 'mohali', 'panchkula',
        'ludhiana', 'amritsar', 'jalandhar', 'bhopal', 'indore', 'gwalior',
        'nagpur', 'nashik', 'aurangabad', 'patna', 'ranchi', 'raipur',
        'bhubaneswar', 'cuttack', 'guwahati', 'shillong', 'imphal', 'kochi',
        'cochin', 'thiruvananthapuram', 'kozhikode', 'coimbatore', 'madurai',
        'tiruchirappalli', 'trichy', 'salem', 'visakhapatnam', 'vizag',
        'vijayawada', 'guntur', 'tirupati', 'mysore', 'mysuru', 'mangalore',
        'hubli', 'belgaum', 'dehradun', 'haridwar', 'rishikesh', 'shimla',
        'srinagar', 'jammu', 'goa', 'panaji', 'vasco', 'siliguri', 'durgapur',
        'asansol', 'jamshedpur', 'dhanbad', 'bokaro', 'noida extension',
        'meerut', 'aligarh', 'bareilly', 'moradabad', 'saharanpur',
        'gorakhpur', 'jhansi', 'muzaffarpur', 'gaya', 'bhagalpur',
        'noida sector', 'greater kailash', 'dwarka', 'rohini', 'saket',
        'andheri', 'bandra', 'borivali', 'malad', 'powai', 'worli',
        'vashi', 'kharghar', 'panvel', 'kalyan', 'dombivli', 'virar',
        'whitefield', 'electronic city', 'indiranagar', 'koramangala',
        'anna nagar', 'velachery', 'gachibowli', 'hitech city', 'kukatpally',
        'uttar pradesh', 'madhya pradesh', 'andhra pradesh', 'himachal pradesh',
        'arunachal pradesh', 'tamil nadu', 'west bengal', 'maharashtra',
        'karnataka', 'telangana', 'kerala', 'punjab', 'haryana', 'rajasthan',
        'gujarat', 'bihar', 'jharkhand', 'odisha', 'assam', 'chhattisgarh',
        'uttarakhand', 'sikkim', 'tripura', 'meghalaya', 'manipur',
        'mizoram', 'nagaland',
    ];

    // ── Public entry point — called after a listing is saved ────────────────

    /**
     * Reprocesses the full keyword set for one listing. Idempotent: safe to
     * call on every save. Never touches rows the admin has explicitly set
     * to 'disabled' (a deliberate manual override) unless the keyword text
     * itself changed (a changed keyword is treated as a new candidate).
     */
    public static function process_for_listing( int $listing_id, string $raw_seo_keywords ): void {
        if ( $listing_id <= 0 ) { return; }
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$pfx}seo_microsite_entries'" ) ) {
            return; // table not migrated yet — fail closed, never fatal
        }

        $listing = $wpdb->get_row( $wpdb->prepare(
            "SELECT l.id, l.slug, l.title, l.city, l.state, l.service_cities, l.tags,
                    l.category_id, l.subcategory_id, l.services_data,
                    l.avg_rating, l.review_count, l.established_year, l.team_size,
                    l.price_min, l.price_max, l.price_unit, l.highlights,
                    c.name AS cat_name, sc.name AS subcat_name
             FROM {$pfx}listings l
             LEFT JOIN {$pfx}categories c  ON c.id = l.category_id
             LEFT JOIN {$pfx}categories sc ON sc.id = l.subcategory_id
             WHERE l.id = %d LIMIT 1",
            $listing_id
        ) );
        if ( ! $listing ) { return; }

        // ── 1. Split, trim, normalize, dedupe the raw comma list ────────────
        $keywords = array_filter( array_map( 'trim', explode( ',', (string) $raw_seo_keywords ) ) );
        $seen_slugs = [];
        $candidates = [];
        foreach ( $keywords as $kw ) {
            $kw = wp_strip_all_tags( $kw );
            if ( $kw === '' || mb_strlen( $kw ) > 190 ) { continue; }
            $normalized = self::normalize( $kw );
            if ( $normalized === '' ) { continue; }
            $slug = sanitize_title( $normalized );
            if ( $slug === '' || isset( $seen_slugs[ $slug ] ) ) { continue; } // duplicate-URL protection (Part 27)
            $seen_slugs[ $slug ] = true;
            $candidates[] = [ 'keyword' => $kw, 'normalized' => $normalized, 'slug' => $slug ];
        }

        // Safety guard: some save paths in this plugin update the listings
        // table without going through the full listing editor (e.g. a
        // quick "SEO title/description" panel), and a bug in one such path
        // was found to submit an empty seo_keywords value that this method
        // would otherwise interpret as "the vendor deleted every keyword"
        // and prune every existing entry URL — a real, confirmed data-loss
        // incident. An accidental/partial submission is far more likely
        // than a vendor genuinely wanting to remove every keyword at once,
        // so when nothing valid was submitted AND live entries already
        // exist, do nothing rather than destroy them. A vendor who
        // genuinely wants to clear all keywords can still do so by
        // removing them individually via the SEO Search Entry URLs admin
        // table (apply_action 'disable'/'delete'), which is an explicit,
        // one-at-a-time action rather than an implicit side effect of an
        // unrelated save.
        if ( ! $candidates ) {
            $has_existing = (bool) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$pfx}seo_microsite_entries WHERE listing_id = %d", $listing_id
            ) );
            if ( $has_existing ) {
                error_log( "[GoodService] SeoEntryService::process_for_listing — ignored empty seo_keywords submission for listing {$listing_id} to avoid deleting existing entries; verify the calling save path actually intends to clear all SEO keywords." );
                return;
            }
        }

        // ── 2. Validate each candidate against the listing ──────────────────
        $vendor_locations = self::vendor_locations( $listing );
        $vendor_services  = self::vendor_service_tokens( $listing );

        $validated = [];
        foreach ( $candidates as $c ) {
            $validated[] = array_merge( $c, self::validate( $c['normalized'], $vendor_locations, $vendor_services ) );
        }

        // ── 3. Search-intent clustering — one indexable URL per intent ──────
        // Group by intent signature; only the highest-quality candidate in
        // each cluster is eligible to be the indexable representative, the
        // rest are marked 'consolidated' and point at it.
        $clusters = [];
        foreach ( $validated as $i => $v ) {
            $clusters[ $v['intent_signature'] ][] = $i;
        }

        $final = [];
        foreach ( $clusters as $signature => $idxs ) {
            usort( $idxs, fn( $a, $b ) => $validated[ $b ]['quality_score'] <=> $validated[ $a ]['quality_score'] );
            $rep_idx = $idxs[0];
            foreach ( $idxs as $pos => $idx ) {
                $v = $validated[ $idx ];
                $is_rep = ( $pos === 0 );
                if ( ! $v['valid'] ) {
                    $v['status'] = 'rejected';
                    $v['indexable'] = false;
                } elseif ( ! $is_rep ) {
                    $v['status'] = 'consolidated';
                    $v['indexable'] = false;
                } elseif ( $v['quality_label'] === 'REJECT' ) {
                    $v['status'] = 'rejected';
                    $v['indexable'] = false;
                } elseif ( $v['quality_label'] === 'REVIEW' ) {
                    $v['status'] = 'validated'; // needs human approval before going live
                    $v['indexable'] = false;
                } else {
                    $v['status'] = 'indexable';
                    $v['indexable'] = true;
                }
                $v['representative_idx'] = $rep_idx;
                $final[ $idx ] = $v;
            }
        }

        // ── 4. Upsert into DB, respecting manual admin overrides ────────────
        $existing_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, keyword_slug, status FROM {$pfx}seo_microsite_entries WHERE listing_id = %d",
            $listing_id
        ), OBJECT_K );
        $existing_by_slug = [];
        foreach ( (array) $existing_rows as $row ) { $existing_by_slug[ $row->keyword_slug ] = $row; }

        $slug_to_id = [];
        foreach ( $final as $v ) {
            $existing = $existing_by_slug[ $v['slug'] ] ?? null;
            // Respect a manual admin override: once an admin has explicitly
            // disabled or rejected a keyword, re-saving the same listing
            // (without removing/re-adding that exact keyword) must not
            // silently resurrect it.
            if ( $existing && in_array( $existing->status, [ 'disabled' ], true ) ) {
                $slug_to_id[ $v['slug'] ] = (int) $existing->id;
                continue;
            }

            $listing_slug = $listing->slug;
            $canonical    = home_url( '/' . trim( $listing_slug, '/' ) . '/' . $v['slug'] . '/' );
            [ $title, $meta, $h1, $intro ] = self::generate_content( $listing, $v );

            $row_data = [
                'listing_id'         => $listing_id,
                'keyword'            => $v['keyword'],
                'normalized_keyword' => $v['normalized'],
                'keyword_slug'       => $v['slug'],
                'intent_signature'   => $v['intent_signature'],
                'search_intent'      => $v['search_intent'],
                'matched_service'    => $v['matched_service'],
                'matched_location'   => $v['matched_location'],
                'status'             => $v['status'],
                'indexable'          => $v['indexable'] ? 1 : 0,
                'sitemap_enabled'    => $v['indexable'] ? 1 : 0,
                'quality_score'      => $v['quality_score'],
                'quality_label'      => $v['quality_label'],
                'rejection_reason'   => $v['reason'],
                'title'              => $title,
                'meta_description'   => $meta,
                'h1'                 => $h1,
                'intro_content'      => $intro,
                'canonical_url'      => $canonical,
                'updated_at'         => current_time( 'mysql' ),
            ];

            if ( $existing ) {
                $wpdb->update( "{$pfx}seo_microsite_entries", $row_data, [ 'id' => $existing->id ] );
                $slug_to_id[ $v['slug'] ] = (int) $existing->id;
            } else {
                $row_data['created_at'] = current_time( 'mysql' );
                $wpdb->insert( "{$pfx}seo_microsite_entries", $row_data );
                $slug_to_id[ $v['slug'] ] = (int) $wpdb->insert_id;
            }
        }

        // Point consolidated rows at their representative's real DB id.
        foreach ( $final as $v ) {
            if ( $v['status'] !== 'consolidated' ) { continue; }
            $rep = $final[ $v['representative_idx'] ] ?? null;
            if ( ! $rep || ! isset( $slug_to_id[ $rep['slug'] ], $slug_to_id[ $v['slug'] ] ) ) { continue; }
            $wpdb->update(
                "{$pfx}seo_microsite_entries",
                [ 'consolidated_into' => $slug_to_id[ $rep['slug'] ] ],
                [ 'id' => $slug_to_id[ $v['slug'] ] ]
            );
        }

        // Prune rows for keywords the vendor removed entirely (never touch
        // admin-disabled/rejected rows — leave an audit trail instead).
        $current_slugs = array_map( fn( $v ) => $v['slug'], $final );
        foreach ( $existing_by_slug as $slug => $row ) {
            if ( in_array( $slug, $current_slugs, true ) ) { continue; }
            if ( in_array( $row->status, [ 'disabled' ], true ) ) { continue; }
            $wpdb->delete( "{$pfx}seo_microsite_entries", [ 'id' => $row->id ] );
        }
    }

    // ── Normalization (Part 10, 27) ──────────────────────────────────────────

    public static function normalize( string $kw ): string {
        $kw = strtolower( trim( $kw ) );
        $kw = str_replace( [ '_', '-' ], ' ', $kw );
        $kw = preg_replace( '/[^a-z0-9\s]/u', ' ', $kw ) ?? $kw;
        $kw = preg_replace( '/\s+/', ' ', $kw ) ?? $kw;
        return trim( $kw );
    }

    /** Sorted, filler-stripped token signature used for intent clustering (Part 12). */
    private static function intent_signature( string $normalized ): string {
        $tokens = array_filter( explode( ' ', $normalized ), function ( $t ) {
            return $t !== '' && ! in_array( $t, self::FILLER_TOKENS, true );
        } );
        sort( $tokens );
        $sig = implode( ' ', $tokens );
        return $sig !== '' ? md5( $sig ) : md5( $normalized );
    }

    // ── Validation (Part 11, 25, 26) ─────────────────────────────────────────

    /**
     * Finds every recognized place name mentioned in a normalized keyword
     * (e.g. "birth certificate agent in noida" -> ['noida']). Matches
     * longest entries in KNOWN_LOCATIONS first so a multi-word place like
     * "new delhi" is captured as one claim, not as "delhi" a second time
     * once "new delhi" already matched; each matched span is blanked out
     * of the working copy so it can't also register a shorter substring
     * match (e.g. "noida" inside "greater noida").
     */
    private static function detect_claimed_locations( string $normalized ): array {
        $remaining = ' ' . $normalized . ' ';
        $locations = self::KNOWN_LOCATIONS;
        usort( $locations, fn( $a, $b ) => mb_strlen( $b ) <=> mb_strlen( $a ) );
        $found = [];
        foreach ( $locations as $loc ) {
            $needle = ' ' . $loc . ' ';
            if ( str_contains( $remaining, $needle ) ) {
                $found[] = $loc;
                $remaining = str_replace( $needle, ' ', $remaining );
            }
        }
        return array_values( array_unique( $found ) );
    }

    /**
     * Very light, deliberately crude suffix stripper — NOT a real
     * linguistic stemmer, just enough to stop plain substring matching
     * from treating "manufactures"/"manufacturer" or "packing"/"packaging"
     * as unrelated words when checking keyword-to-service relevance.
     * Strips at most one common English suffix, longest first, and only
     * when the remaining stem is still long enough to be meaningful
     * (avoids over-stripping short words into meaningless fragments).
     */
    private static function stem( string $w ): string {
        $w = strtolower( $w );
        foreach ( [ 'ing', 'ers', 'er', 'ies', 'es', 's' ] as $suffix ) {
            $len = mb_strlen( $suffix );
            if ( mb_strlen( $w ) > $len + 3 && str_ends_with( $w, $suffix ) ) {
                return mb_substr( $w, 0, -$len );
            }
        }
        return $w;
    }

    private static function vendor_locations( object $listing ): array {
        $locs = [];
        if ( ! empty( $listing->city ) )  { $locs[] = strtolower( trim( $listing->city ) ); }
        if ( ! empty( $listing->state ) ) { $locs[] = strtolower( trim( $listing->state ) ); }
        $service_cities = json_decode( (string) ( $listing->service_cities ?? '' ), true );
        if ( is_array( $service_cities ) ) {
            foreach ( $service_cities as $sc ) {
                $name = is_array( $sc ) ? ( $sc['name'] ?? $sc['city'] ?? '' ) : (string) $sc;
                if ( $name ) { $locs[] = strtolower( trim( $name ) ); }
            }
        }
        return array_values( array_unique( array_filter( $locs ) ) );
    }

    private static function vendor_service_tokens( object $listing ): array {
        $tokens = [];
        foreach ( [ $listing->cat_name ?? '', $listing->subcat_name ?? '', $listing->tags ?? '' ] as $field ) {
            foreach ( preg_split( '/[,\s]+/', strtolower( (string) $field ) ) as $t ) {
                if ( mb_strlen( $t ) >= 4 ) { $tokens[] = $t; }
            }
        }
        $services_data = json_decode( (string) ( $listing->services_data ?? '' ), true );
        if ( is_array( $services_data ) ) {
            foreach ( $services_data as $svc ) {
                $name = is_array( $svc ) ? ( $svc['name'] ?? $svc['title'] ?? '' ) : (string) $svc;
                foreach ( preg_split( '/[,\s]+/', strtolower( (string) $name ) ) as $t ) {
                    if ( mb_strlen( $t ) >= 4 ) { $tokens[] = $t; }
                }
            }
        }
        return array_values( array_unique( array_filter( $tokens ) ) );
    }

    /**
     * Returns:
     *  valid            bool   — passes minimum bar to exist as a keyword at all
     *  reason           string — human-readable reason when invalid/flagged
     *  quality_score    int 0-100
     *  quality_label    GOOD|REVIEW|REJECT
     *  search_intent    string — human phrase describing the intent
     *  matched_service  string
     *  matched_location string
     *  intent_signature string
     */
    private static function validate( string $normalized, array $vendor_locations, array $vendor_service_tokens ): array {
        $tokens = array_filter( explode( ' ', $normalized ) );
        $signature = self::intent_signature( $normalized );

        // Minimum meaningful length — single-word keywords rarely represent
        // a distinct, useful search intent worth its own entry URL.
        if ( count( $tokens ) < 2 ) {
            return [
                'valid' => false, 'reason' => 'Too short to represent a distinct search intent',
                'quality_score' => 0, 'quality_label' => 'REJECT', 'search_intent' => $normalized,
                'matched_service' => '', 'matched_location' => '', 'intent_signature' => $signature,
            ];
        }

        // Unsupported / manipulative claims (Part 11, 44)
        foreach ( self::BANNED_CLAIMS as $claim ) {
            if ( str_contains( $normalized, $claim ) ) {
                return [
                    'valid' => false, 'reason' => "Contains an unverified claim (\"{$claim}\")",
                    'quality_score' => 0, 'quality_label' => 'REJECT', 'search_intent' => $normalized,
                    'matched_service' => '', 'matched_location' => '', 'intent_signature' => $signature,
                ];
            }
        }

        // Location relevance (Part 11, 26) — strict: a keyword that names a
        // real, recognizable place the vendor has NOT configured (via City,
        // State, or the Service Cities list in the listing's Contact
        // section) is rejected outright rather than merely un-rewarded.
        // A word that ISN'T a recognized place name at all (i.e. not in
        // KNOWN_LOCATIONS) is never treated as a location claim — it's
        // simply part of the service phrase, exactly as before.
        $claimed_locations = self::detect_claimed_locations( $normalized );
        $matched_location = '';
        $unsupported_location = '';
        foreach ( $claimed_locations as $claimed ) {
            $is_served = false;
            foreach ( $vendor_locations as $loc ) {
                if ( str_contains( $loc, $claimed ) || str_contains( $claimed, $loc ) ) {
                    $is_served = true;
                    if ( ! $matched_location ) { $matched_location = $claimed; }
                    break;
                }
            }
            if ( ! $is_served ) { $unsupported_location = $claimed; break; }
        }
        if ( $unsupported_location !== '' ) {
            return [
                'valid' => false,
                'reason' => 'Names "' . ucwords( $unsupported_location ) . '", which is not in this vendor\'s configured City/State/Service Cities',
                'quality_score' => 5, 'quality_label' => 'REJECT', 'search_intent' => $normalized,
                'matched_service' => '', 'matched_location' => '', 'intent_signature' => $signature,
            ];
        }

        // Service relevance (Part 11, 25) — require genuine token overlap
        // with something the vendor actually offers (category/subcategory/
        // tags/services_data), matching the spirit of "car repair" never
        // becoming valid for a birth-certificate vendor. Compares both the
        // raw word AND a lightly-stemmed form (suffix-stripped) on both
        // sides — real-world category/tag naming ("Packaging Machinery",
        // "Manufacturer") otherwise fails a plain substring check against
        // a legitimately-related keyword ("packing machine manufactures")
        // purely due to -ing/-er/-es word-form differences, which is a
        // false rejection, not a real relevance problem.
        $overlap = 0;
        $matched_service = '';
        foreach ( $tokens as $t ) {
            if ( mb_strlen( $t ) < 4 ) { continue; }
            $t_stem = self::stem( $t );
            foreach ( $vendor_service_tokens as $st ) {
                $st_stem = self::stem( $st );
                if ( $t === $st || str_contains( $st, $t ) || str_contains( $t, $st )
                    || $t_stem === $st_stem || str_contains( $st_stem, $t_stem ) || str_contains( $t_stem, $st_stem ) ) {
                    $overlap++;
                    if ( ! $matched_service ) { $matched_service = $st; }
                }
            }
        }
        // Vendors run real, specific businesses that this plugin's own
        // category/tag list can't always name exactly the way the vendor
        // (or a real searcher) would phrase it — "supplier" vs
        // "manufacturer", a niche machine type not in the taxonomy, etc.
        // Repeatedly rejecting genuinely relevant keywords on a plain
        // token-overlap technicality caused more harm (blocked legitimate
        // SEO entries) than it prevented (a determined bad actor typing an
        // unrelated keyword). Per an explicit decision to prioritize vendor
        // flexibility, a missing service/category match no longer blocks
        // the keyword outright — it just doesn't earn the relevance score
        // bonus below. The two checks that actually protect against real
        // Google spam-policy risk — unverified superlative/claim words,
        // and claiming to serve a place the vendor hasn't configured — are
        // unaffected and still reject outright, above.

        // ── Score ──────────────────────────────────────────────────────────
        $score = 50;
        $score += min( 20, $overlap * 10 );          // real service relevance
        $score += $matched_location ? 15 : 0;         // confirmed, in-scope location
        $score += count( $tokens ) >= 3 ? 10 : 0;     // multi-word = clearer intent
        $score = max( 0, min( 100, $score ) );

        $label = $score >= 70 ? 'GOOD' : ( $score >= 45 ? 'REVIEW' : 'REJECT' );

        $search_intent = self::smart_title_case( $normalized );

        return [
            'valid' => true, 'reason' => '', 'quality_score' => $score, 'quality_label' => $label,
            'search_intent' => $search_intent, 'matched_service' => $matched_service,
            'matched_location' => $matched_location, 'intent_signature' => $signature,
        ];
    }

    /**
     * Title-case a phrase the way a human editor would — capitalize every
     * word except short connector words ("in", "of", "for", ...), and never
     * lowercase the first word. Fixes the raw ucwords() behaviour that
     * produced awkward output like "Packing Machine Manufactures In Kanpur"
     * (capital "In" mid-sentence).
     */
    private static function smart_title_case( string $s ): string {
        $minor = [ 'a', 'an', 'and', 'as', 'at', 'but', 'by', 'for', 'in', 'nor',
                   'of', 'on', 'or', 'per', 'the', 'to', 'vs', 'via' ];
        $words = preg_split( '/\s+/', trim( $s ) );
        if ( ! $words ) { return $s; }
        $last = count( $words ) - 1;
        foreach ( $words as $i => $w ) {
            if ( $w === '' ) { continue; }
            $lower = mb_strtolower( $w );
            $words[ $i ] = ( $i !== 0 && $i !== $last && in_array( $lower, $minor, true ) )
                ? $lower
                : mb_convert_case( $w, MB_CASE_TITLE, 'UTF-8' );
        }
        return implode( ' ', $words );
    }

    /**
     * Vendors frequently store their business name in ALL CAPS (e.g.
     * "NAMRTA ENGINEERING WORKS"). Reading that name twice in one short
     * paragraph is jarring, so display copy uses a Title Case version of
     * an all-caps name while leaving normally-cased names untouched.
     */
    private static function display_brand( string $brand ): string {
        $letters = preg_replace( '/[^A-Za-z]/', '', $brand );
        if ( $letters !== '' && $brand === mb_strtoupper( $brand ) ) {
            return self::smart_title_case( mb_strtolower( $brand ) );
        }
        return $brand;
    }

    /**
     * Looks for a real, vendor-entered service description that matches the
     * keyword, so the intro can carry one extra fact-based sentence instead
     * of staying purely templated. Never invents anything — returns '' when
     * nothing in the vendor's own services_data matches closely enough.
     */
    /**
     * BUG FIX — root cause of the reported content mismatch (e.g. a
     * "Police Clearance Certificate" keyword pulling in the vendor's
     * "Late Birth Certificate" service description).
     *
     * The old logic matched on `$hits > 0` — ANY single shared token was
     * enough to attach a service's description to a keyword. Two phrases
     * that both merely contain one common, generic word from the same
     * business niche ("certificate", "documentation", "registration",
     * "service", "consultant"...) are NOT evidence they're about the same
     * specific service. For a vendor who offers several similarly-worded
     * services (very common for documentation/certificate agents,
     * consultancies, agencies), the old rule guaranteed cross-contamination
     * the moment two service names shared even one generic word — which is
     * exactly the reported failure mode, and would recur for any vendor
     * with overlapping service names, not just this one example.
     *
     * Fix: require the shared tokens to cover the MAJORITY of the
     * significant words on BOTH sides (the keyword and the candidate
     * service name), not just a nonzero intersection. "police clearance
     * certificate" now needs at least 2 of its 3 tokens to match a
     * service's name, AND those matched tokens must cover at least half of
     * that service name's own tokens — so a broad/short match like plain
     * "certificate" can no longer stand in for a specific 3-word intent.
     * When nothing meets that bar, the intro correctly falls back to the
     * generic, still-accurate "provides this service" phrasing instead of
     * borrowing another service's specifics.
     */
    private static function find_service_detail( object $listing, string $normalized ): string {
        $services_data = json_decode( (string) ( $listing->services_data ?? '' ), true );
        if ( ! is_array( $services_data ) ) { return ''; }

        $kw_tokens = array_values( array_filter( preg_split( '/\s+/', $normalized ), fn( $t ) => mb_strlen( $t ) >= 4 ) );
        if ( ! $kw_tokens ) { return ''; }
        $kw_stems = array_values( array_unique( array_map( [ self::class, 'stem' ], $kw_tokens ) ) );
        $kw_count = count( $kw_stems );
        if ( $kw_count === 0 ) { return ''; }

        $best = ''; $best_ratio = 0.0; $best_hits = 0;
        foreach ( $services_data as $svc ) {
            if ( ! is_array( $svc ) || empty( $svc['name'] ) || empty( $svc['description'] ) ) { continue; }
            $svc_tokens = array_values( array_filter( preg_split( '/[,\s]+/', mb_strtolower( (string) $svc['name'] ) ), fn( $t ) => mb_strlen( $t ) >= 4 ) );
            if ( ! $svc_tokens ) { continue; }
            $svc_stems = array_values( array_unique( array_map( [ self::class, 'stem' ], $svc_tokens ) ) );
            $hits = count( array_intersect( $kw_stems, $svc_stems ) );
            if ( $hits === 0 ) { continue; }

            // Majority-overlap requirement on BOTH sides — see doc-block above.
            $kw_ratio  = $hits / $kw_count;
            $svc_ratio = $hits / count( $svc_stems );
            if ( $kw_ratio < 0.6 || $svc_ratio < 0.5 ) { continue; }

            $ratio = min( $kw_ratio, $svc_ratio );
            if ( $ratio > $best_ratio || ( $ratio === $best_ratio && $hits > $best_hits ) ) {
                $best_ratio = $ratio;
                $best_hits  = $hits;
                $best = trim( wp_strip_all_tags( (string) $svc['description'] ) );
            }
        }
        if ( $best === '' ) { return ''; }
        // Keep it a short supporting fact, not a wall of text.
        $best = preg_replace( '/\s+/', ' ', $best );
        return mb_substr( $best, 0, 160 );
    }

    // ── Content generation (Part 16-19) ──────────────────────────────────────

    /** @return array{0:string,1:string,2:string,3:string} [title, meta, h1, intro] */
    private static function generate_content( object $listing, array $v ): array {
        $brand         = trim( (string) $listing->title ) ?: (string) Config::get( 'platform_name', 'GoodService' );
        $brand_display = self::display_brand( $brand );
        $intent        = $v['search_intent'];
        $intent_lc     = mb_strtolower( $intent );

        // Bug fix: the keyword itself often already names the location
        // (e.g. vendor typed "Birth Certificate Consultant in Delhi"), in
        // which case $intent ALREADY contains it — appending " in Delhi"
        // again produced "...In Delhi in Delhi". Only append the location
        // suffix when the keyword text doesn't already mention it.
        $location_already_in_intent = $v['matched_location'] !== ''
            && str_contains( strtolower( $intent ), strtolower( $v['matched_location'] ) );
        $location_suffix    = ( $v['matched_location'] && ! $location_already_in_intent )
            ? ' in ' . ucwords( $v['matched_location'] ) : '';
        $location_suffix_lc = mb_strtolower( $location_suffix );

        $h1    = "{$intent}{$location_suffix} – {$brand_display}";
        $title = function_exists( 'gs_enh_trim_to_pixel_width' ) ? gs_enh_trim_to_pixel_width( $h1, 580 ) : mb_substr( $h1, 0, 65 );

        $meta = "Get {$intent_lc}{$location_suffix_lc} from {$brand_display}. View services, pricing, contact details, and reviews on their GoodService page.";
        $meta = mb_substr( $meta, 0, 300 );
        $meta = mb_strtoupper( mb_substr( $meta, 0, 1 ) ) . mb_substr( $meta, 1 );

        // A single bare token (e.g. "manufacturers", "consultant") reads
        // ungrammatically when dropped straight into a sentence ("offers
        // Manufacturers"), and re-stating the whole intent phrase back
        // reads as a stutter ("provides packing machine manufactures in
        // kanpur"). Only use matched_service as a distinct noun phrase
        // when it is a genuine multi-word phrase that adds information
        // beyond the intent itself; otherwise fall back to a neutral,
        // still-truthful phrase.
        $service_raw   = trim( (string) $v['matched_service'] );
        $service_words = $service_raw === '' ? [] : preg_split( '/\s+/', $service_raw );
        $has_distinct_service = count( $service_words ) >= 2
            && mb_strtolower( $service_raw ) !== $intent_lc;

        // Pull one real, vendor-written fact (their own service description)
        // when one closely matches this keyword — gives Google and readers
        // genuine additional content instead of a purely templated line.
        $service_detail = self::find_service_detail( $listing, (string) ( $v['normalized'] ?? $intent_lc ) );

        if ( $has_distinct_service ) {
            $service_phrase = mb_strtolower( $service_raw );
            $lead = "Looking for {$intent_lc}{$location_suffix_lc}? {$brand_display} offers {$service_phrase}"
                  . ( $service_detail !== '' ? ": " . rtrim( $service_detail, '.' ) . '.' : '.' );
        } else {
            $lead = "Looking for {$intent_lc}{$location_suffix_lc}? {$brand_display} provides this service"
                  . ( $service_detail !== '' ? ": " . rtrim( $service_detail, '.' ) . '.' : '.' );
        }

        // Real feature: the intro used to be a bare 2-sentence stub (lead +
        // closing CTA), which reads as very thin body copy under a full
        // H1 — a real reported complaint, and also weak for SEO (Google's
        // guidance favours genuinely informative content over a token
        // paragraph). Every extra sentence below is built ONLY from data
        // this specific listing has actually filled in (rating, years in
        // business, team size, price range, service areas, highlights) —
        // never invented — so a data-rich listing gets a genuinely
        // informative paragraph, and a bare-bones listing still gets
        // honest, non-fabricated supporting sentences rather than nothing.
        $facts = self::collect_supporting_facts( $listing, $v, $brand_display );

        $sentences   = [ $lead ];
        $sentences[] = "This page brings together everything you need to know about {$intent_lc}{$location_suffix_lc} from {$brand_display} in one place.";
        // Cap how many real-fact sentences get pulled in — a listing with
        // rating + years + team + price + areas + highlights all filled in
        // would otherwise stack every single one, growing the paragraph
        // unboundedly as the vendor fills in more of their profile over
        // time. 4 is enough to make the page genuinely informative without
        // turning it into a wall of text.
        foreach ( array_slice( $facts, 0, 4 ) as $fact ) { $sentences[] = $fact; }
        $sentences[] = "Whether you're comparing a few options or ready to reach out directly, {$brand_display} aims to make the process simple, transparent, and hassle-free.";
        $sentences[] = "See full service details, pricing, and contact options below, or view the complete profile for more information.";

        $intro = implode( ' ', $sentences );
        $intro = mb_strtoupper( mb_substr( $intro, 0, 1 ) ) . mb_substr( $intro, 1 );

        return [ $title, $meta, $h1, $intro ];
    }

    /**
     * Builds truthful, listing-specific supporting sentences for the SEO
     * entry intro — every fact used here already exists on the listing
     * (rating/reviews, years in business, team size, price range, extra
     * service areas beyond the one matched in the H1, and the vendor's own
     * "Key Highlights"). A fact is included only when the underlying field
     * is actually populated, so this never fabricates a rating, a price,
     * or an area the vendor never entered — it only surfaces what's real.
     */
    private static function collect_supporting_facts( object $listing, array $v, string $brand_display ): array {
        $facts = [];

        // Rating / reviews — same non-fabrication rule as SchemaGenerator's
        // aggregateRating: never mentioned with zero reviews.
        $review_count = (int) ( $listing->review_count ?? 0 );
        $avg_rating   = (float) ( $listing->avg_rating ?? 0 );
        if ( $review_count > 0 && $avg_rating > 0 ) {
            $facts[] = sprintf(
                'They are rated %.1f out of 5 based on %d verified customer review%s.',
                $avg_rating, $review_count, $review_count === 1 ? '' : 's'
            );
        }

        // Experience / team size — only when at least one is actually set.
        $established = (int) ( $listing->established_year ?? 0 );
        $team_size   = trim( (string) ( $listing->team_size ?? '' ) );
        $years       = $established > 1900 ? ( (int) gmdate( 'Y' ) - $established ) : 0;
        if ( $years > 0 && $team_size !== '' ) {
            $facts[] = "With {$years}+ years in business and a team of {$team_size}, {$brand_display} has the experience to handle this reliably.";
        } elseif ( $years > 0 ) {
            $facts[] = "{$brand_display} has been operating for {$years}+ years in this line of business.";
        } elseif ( $team_size !== '' ) {
            $facts[] = "{$brand_display} works with a team of {$team_size} to handle customer requests.";
        }

        // Price range — only when the vendor has actually set a floor.
        if ( ! empty( $listing->price_min ) ) {
            $currency_symbol = \GoodService\Core\Config::get( 'currency_symbol', '₹' );
            $has_max = ! empty( $listing->price_max ) && (float) $listing->price_max > (float) $listing->price_min;
            $price_str = $has_max
                ? $currency_symbol . number_format( (float) $listing->price_min, 0 ) . ' – ' . $currency_symbol . number_format( (float) $listing->price_max, 0 )
                : 'from ' . $currency_symbol . number_format( (float) $listing->price_min, 0 );
            $unit = trim( (string) ( $listing->price_unit ?? '' ) );
            $facts[] = "Typical pricing for this kind of service is {$price_str}" . ( $unit !== '' ? " per {$unit}" : '' ) . ', though the exact cost depends on your specific requirement.';
        }

        // Additional service areas beyond the one already named in the H1 —
        // real data from the vendor's own Service Cities list, capped at 4
        // so this stays a supporting sentence, not a location-stuffing list.
        $extra_locations = [];
        $service_cities = json_decode( (string) ( $listing->service_cities ?? '' ), true );
        if ( is_array( $service_cities ) ) {
            foreach ( $service_cities as $sc ) {
                $name = is_array( $sc ) ? ( $sc['name'] ?? $sc['city'] ?? '' ) : (string) $sc;
                $name = trim( (string) $name );
                if ( $name !== '' && strcasecmp( $name, (string) $v['matched_location'] ) !== 0 ) {
                    $extra_locations[] = $name;
                }
            }
        }
        $extra_locations = array_slice( array_values( array_unique( $extra_locations ) ), 0, 4 );
        if ( $extra_locations ) {
            $facts[] = "{$brand_display} also serves customers in " . implode( ', ', $extra_locations ) . '.';
        }

        // Key Highlights — the vendor's own free-text bullet list (already
        // shown elsewhere on the page); reuse up to 3 of the real entries
        // rather than inventing generic praise.
        $highlights_raw = (string) ( $listing->highlights ?? '' );
        $highlights = array_values( array_filter( array_map( 'trim', explode( "\n", $highlights_raw ) ) ) );
        $highlights = array_slice( $highlights, 0, 3 );
        if ( $highlights ) {
            $facts[] = 'Key highlights include ' . implode( ', ', array_map( 'lcfirst', $highlights ) ) . '.';
        }

        return $facts;
    }

    // ── Lookup used by the router ─────────────────────────────────────────────

    public static function get_indexable_entry( int $listing_id, string $keyword_slug ): ?object {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$pfx}seo_microsite_entries'" ) ) { return null; }
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$pfx}seo_microsite_entries
             WHERE listing_id = %d AND keyword_slug = %s AND status IN ('approved','indexable') AND indexable = 1
             LIMIT 1",
            $listing_id, $keyword_slug
        ) );
        return $row ?: null;
    }

    /**
     * Other indexable entry URLs for the same listing, excluding the one
     * currently being viewed. Used to build an internal "related searches"
     * link block on entry-URL pages — internal links are a materially
     * stronger discovery/relevance signal to Google than sitemap presence
     * alone, and this only touches entry-URL views, never the primary
     * canonical microsite page.
     */
    /**
     * BUG FIX: this previously hard-capped the list at 8 (function default)
     * / 6 (the only real caller, in vendor-site.php) for no functional
     * reason — every 'indexable' row for a listing is, by definition,
     * already a keyword that passed validation, intent-clustering, and
     * (where required) manual approval, so there is no quality reason to
     * hide any of them from the "Related searches" block. That arbitrary
     * cap was the actual cause of "only a few of the generated Related
     * Searches are currently being displayed" — nothing was filtering them
     * out at the query/status level, they were simply never selected past
     * position 6/8 in the ORDER BY. $limit is now 0 = unlimited by default;
     * pass a positive number only if a caller genuinely needs to cap the
     * list (none currently do).
     */
    public static function indexable_siblings( int $listing_id, string $exclude_slug, int $limit = 0 ): array {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$pfx}seo_microsite_entries'" ) ) { return []; }
        $sql = "SELECT keyword, keyword_slug, canonical_url FROM {$pfx}seo_microsite_entries
             WHERE listing_id = %d AND keyword_slug != %s AND status = 'indexable' AND indexable = 1
             ORDER BY quality_score DESC, keyword ASC";
        $params = [ $listing_id, $exclude_slug ];
        if ( $limit > 0 ) {
            $sql .= ' LIMIT %d';
            $params[] = $limit;
        }
        return $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) ?: [];
    }

    public static function list_for_listing( int $listing_id ): array {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$pfx}seo_microsite_entries'" ) ) { return []; }
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$pfx}seo_microsite_entries WHERE listing_id = %d ORDER BY quality_score DESC, keyword ASC",
            $listing_id
        ) ) ?: [];
    }

    /**
     * One-time repair for rows generated BEFORE the find_service_detail()
     * fix above — those rows have the wrong, cross-contaminated
     * intro_content/title/h1/meta_description already baked into the
     * database, and simply fixing the generator code does nothing for
     * them until the vendor happens to re-save their listing. Recomputes
     * title/meta/h1/intro_content for every existing entry from its
     * already-stored keyword + the listing's current data — never touches
     * status/indexable/quality_score/consolidation, so this cannot change
     * which entries are live, only correct their displayed text. Called
     * automatically, once, from Plugin::check_db_version() on this version
     * bump — no admin action needed, and safe to call again (idempotent:
     * re-running it just regenerates the same correct content).
     */
    public static function repair_all_content( int $batch = 500 ): int {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$pfx}seo_microsite_entries'" ) ) { return 0; }

        $fixed = 0;
        $offset = 0;
        do {
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT id, listing_id, keyword, normalized_keyword, matched_service, matched_location
                 FROM {$pfx}seo_microsite_entries ORDER BY id ASC LIMIT %d OFFSET %d",
                $batch, $offset
            ) );
            if ( ! $rows ) { break; }

            foreach ( $rows as $row ) {
                $listing = $wpdb->get_row( $wpdb->prepare(
                    "SELECT id, slug, title, services_data, avg_rating, review_count,
                            established_year, team_size, price_min, price_max, price_unit, highlights
                     FROM {$pfx}listings WHERE id = %d LIMIT 1",
                    (int) $row->listing_id
                ) );
                if ( ! $listing ) { continue; }

                $v = [
                    // Cast every field: these are nullable DB columns, and
                    // generate_content()/find_service_detail() both do
                    // strict '' comparisons and string operations on them
                    // (e.g. `$v['matched_location'] !== ''`), which breaks
                    // on a raw NULL (`null !== ''` is true in PHP, so a
                    // NULL location would wrongly be treated as "a real,
                    // matched location value" and get appended to the H1).
                    'normalized'       => (string) $row->normalized_keyword,
                    'search_intent'    => self::smart_title_case( (string) $row->normalized_keyword ),
                    'matched_service'  => (string) ( $row->matched_service ?? '' ),
                    'matched_location' => (string) ( $row->matched_location ?? '' ),
                ];
                [ $title, $meta, $h1, $intro ] = self::generate_content( $listing, $v );
                $wpdb->update(
                    "{$pfx}seo_microsite_entries",
                    [ 'title' => $title, 'meta_description' => $meta, 'h1' => $h1, 'intro_content' => $intro ],
                    [ 'id' => $row->id ]
                );
                $fixed++;
            }
            $offset += $batch;
        } while ( count( $rows ) === $batch );

        return $fixed;
    }

    /** Admin/vendor action: approve | disable | delete | reindex a single entry. Ownership-checked by caller. */
    public static function apply_action( int $entry_id, string $action ): bool {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        switch ( $action ) {
            case 'approve':
                return (bool) $wpdb->update( "{$pfx}seo_microsite_entries",
                    [ 'status' => 'indexable', 'indexable' => 1, 'sitemap_enabled' => 1, 'updated_at' => current_time( 'mysql' ) ],
                    [ 'id' => $entry_id ] );
            case 'disable':
                return (bool) $wpdb->update( "{$pfx}seo_microsite_entries",
                    [ 'status' => 'disabled', 'indexable' => 0, 'sitemap_enabled' => 0, 'updated_at' => current_time( 'mysql' ) ],
                    [ 'id' => $entry_id ] );
            case 'delete':
                return (bool) $wpdb->delete( "{$pfx}seo_microsite_entries", [ 'id' => $entry_id ] );
            default:
                return false;
        }
    }
}
