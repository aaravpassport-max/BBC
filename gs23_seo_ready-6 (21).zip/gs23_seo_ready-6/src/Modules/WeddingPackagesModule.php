<?php
namespace GoodService\Modules;

/**
 * WeddingPackagesModule — Events & Wedding, Section 04: "Packages &
 * Collections". Vendor pricing packages, but unlike BeautyPackagesModule
 * (Beauty & Salon's fixed-price-only discount cards), Events & Wedding
 * pricing is not always a single fixed number — a photographer may only
 * be willing to quote "Starting from ₹X", and a planner or decorator may
 * want "Price on Request" with no number shown at all. Each item's price
 * display is driven by a real vendor-selected `price_mode` field
 * (fixed | starting_from | on_request) — never inferred from which price
 * fields happen to be filled in.
 *
 * "No fake urgency": exactly like BeautyPackagesModule, there is no
 * countdown timer, no "X people booked this" claim, and no invented
 * scarcity copy anywhere in this file. The only price signals ever shown
 * are the vendor's own real numbers: a genuine strikethrough discount
 * (original vs. offer, reusing BeautyPackagesModule's exact
 * show-strike-only-when-both-real-and-offer-is-lower discipline) or a
 * plain "Starting from" prefix on a real minimum price.
 *
 * Safe fallback: if a vendor picks `fixed` or `starting_from` but never
 * actually typed a price, the card is treated as `on_request` — never
 * rendered as "Starting from ₹0" or with a blank price. This fallback is
 * applied at render time (defense in depth) in addition to being
 * enforced at save time in AjaxController.
 *
 * CTA mechanism: every package card's button calls the same shared
 * `vsOpenInquiry()` JS function every other section's "Enquire" button
 * already calls on the vendor-site template (see e.g.
 * BeautyPackagesModule::render_grid()'s `gs-beauty-pkg-cta` button, and
 * the `vs-pkg-add-btn` / `vs-dp-cta-btn` buttons elsewhere in
 * vendor-site.php) — no parallel inquiry/form system is introduced here.
 * A dedicated "Request a Quote" section (Section 11) has not been built
 * yet at this stage, so `on_request` cards reuse this exact same
 * existing mechanism with different label copy ("Request a Quote")
 * rather than inventing a new one.
 */
class WeddingPackagesModule {

    public const PRICE_MODES = [ 'fixed', 'starting_from', 'on_request' ];

    /**
     * Layout variants — same proven mechanism as
     * FeaturedProjectsModule::LAYOUTS / DoctorsModule::LAYOUTS: a
     * public const on the module class, looped by a single admin
     * <select>, validated with in_array() at render time, keyed off a
     * layout-modifier class on the grid element. `grid` (the existing
     * flat equal grid) stays the default so upgrading never silently
     * changes an already-configured vendor page.
     *
     * `featured` marks ONE vendor-chosen package larger/prominent,
     * directly reusing FeaturedProjectsModule's own `is_primary`
     * per-repeater-item checkbox + "first one marked wins" mechanism
     * (FeaturedProjectsModule::select_projects()) rather than
     * DoctorsModule's featured layout, which has no vendor marking
     * control at all (it always just treats index 0 as featured) —
     * this section needs the vendor to be able to choose *which*
     * package is "recommended", so the is_primary precedent is the
     * correct one to copy. If layout=featured but no package is
     * marked is_primary, render_grid() gracefully falls back to plain
     * grid rather than leaving the section broken or blank.
     */
    public const LAYOUTS = [
        'grid'     => 'Equal Grid',
        'featured' => 'Featured Package',
    ];

    public static function render_title( string $heading, string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-wedding-sec-head">
        <div class="gs-wedding-eyebrow">Our Work</div>
        <h2 class="vs-sec-title gs-wedding-title"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-wedding-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Resolves one item's real, safe price-display state. Never trusts
     * price_mode blindly — a mode of fixed/starting_from with no real
     * numeric price falls back to on_request so a blank price or a
     * "Starting from ₹0" can never render.
     *
     * @return array{mode:string, price:?float, original:?float, show_strike:bool, savings:?float}
     */
    private static function resolve_price( array $item ): array {
        $mode = (string) ( $item['price_mode'] ?? 'on_request' );
        if ( ! in_array( $mode, self::PRICE_MODES, true ) ) { $mode = 'on_request'; }

        $price_raw = trim( (string) ( $item['price'] ?? '' ) );
        $price     = ( $price_raw !== '' && is_numeric( $price_raw ) ) ? (float) $price_raw : null;

        if ( $mode !== 'on_request' && $price === null ) {
            // Safe fallback — never show "Starting from ₹0" or a blank price.
            $mode = 'on_request';
        }

        $orig_raw = trim( (string) ( $item['original_price'] ?? '' ) );
        $orig     = ( $orig_raw !== '' && is_numeric( $orig_raw ) ) ? (float) $orig_raw : null;

        // Genuine strikethrough discount only meaningful for fixed price,
        // only when both numbers are real, and only when it's an actual
        // discount — same discipline as BeautyPackagesModule::render_grid().
        $show_strike = ( $mode === 'fixed' && $orig !== null && $price !== null && $price < $orig );
        $savings     = $show_strike ? ( $orig - $price ) : null;

        return [
            'mode'        => $mode,
            'price'       => $price,
            'original'    => $show_strike ? $orig : null,
            'show_strike' => $show_strike,
            'savings'     => $savings,
        ];
    }

    public static function render_grid( array $items, string $currency = '₹', string $layout = 'grid' ): string {
        $items = array_values( array_filter( $items, fn( $i ) => is_array( $i ) && trim( (string) ( $i['title'] ?? '' ) ) !== '' ) );
        if ( empty( $items ) ) { return ''; }
        $layout = in_array( $layout, array_keys( self::LAYOUTS ), true ) ? $layout : 'grid';

        // "featured" needs a vendor-marked primary package to mean
        // anything; with none, gracefully fall back to plain grid
        // rather than rendering a broken/blank "featured" section —
        // same safe-fallback discipline as resolve_price() above.
        if ( $layout === 'featured' ) {
            $has_primary = false;
            foreach ( $items as $_i ) { if ( ! empty( $_i['is_primary'] ) ) { $has_primary = true; break; } }
            if ( ! $has_primary ) { $layout = 'grid'; }
        }

        // Defense in depth against malicious duplicate is_primary=1
        // POST data: only the first matching item ever gets the
        // featured slot, exactly like
        // FeaturedProjectsModule::select_projects()'s own
        // `$primary === null` guard.
        $_pkg_featured_used = false;

        ob_start();
        ?>
    <div class="gs-wedding-pkg-grid gs-wedding-pkg-layout-<?php echo esc_attr( $layout ); ?>">
        <?php foreach ( $items as $_pi => $item ):
            $title   = trim( (string) ( $item['title'] ?? '' ) );
            $desc    = trim( (string) ( $item['description'] ?? '' ) );
            $tag     = trim( (string) ( $item['tag'] ?? '' ) );
            $incl    = array_values( array_filter( array_map( 'trim', (array) ( $item['includes'] ?? [] ) ), fn( $s ) => is_string( $s ) && $s !== '' ) );
            $p       = self::resolve_price( $item );
            $is_featured = ( $layout === 'featured' && ! $_pkg_featured_used && ! empty( $item['is_primary'] ) );
            if ( $is_featured ) { $_pkg_featured_used = true; }
        ?>
        <div class="gs-wedding-pkg-card<?php echo $is_featured ? ' gs-wedding-pkg-featured' : ''; ?>">
            <?php if ( $tag !== '' ): ?><span class="gs-wedding-pkg-tag"><?php echo esc_html( $tag ); ?></span><?php endif; ?>
            <div class="gs-wedding-pkg-title"><?php echo esc_html( $title ); ?></div>
            <?php if ( $desc !== '' ): ?><p class="gs-wedding-pkg-desc"><?php echo esc_html( $desc ); ?></p><?php endif; ?>

            <?php if ( $p['show_strike'] ): ?>
            <div class="gs-wedding-pkg-price-row">
                <span class="gs-wedding-pkg-price-orig"><?php echo esc_html( $currency . number_format( $p['original'], 0 ) ); ?></span>
                <span class="gs-wedding-pkg-price-main"><?php echo esc_html( $currency . number_format( $p['price'], 0 ) ); ?></span>
            </div>
            <div class="gs-wedding-pkg-save">You save <?php echo esc_html( $currency . number_format( $p['savings'], 0 ) ); ?></div>
            <?php elseif ( $p['mode'] === 'fixed' && $p['price'] !== null ): ?>
            <div class="gs-wedding-pkg-price-row"><span class="gs-wedding-pkg-price-main"><?php echo esc_html( $currency . number_format( $p['price'], 0 ) ); ?></span></div>
            <?php elseif ( $p['mode'] === 'starting_from' && $p['price'] !== null ): ?>
            <div class="gs-wedding-pkg-price-row">
                <span class="gs-wedding-pkg-price-prefix">Starting from</span>
                <span class="gs-wedding-pkg-price-main"><?php echo esc_html( $currency . number_format( $p['price'], 0 ) ); ?></span>
            </div>
            <?php else: ?>
            <div class="gs-wedding-pkg-price-row gs-wedding-pkg-price-quote">Price on Request</div>
            <?php endif; ?>

            <?php if ( ! empty( $incl ) ): ?>
            <ul class="gs-wedding-pkg-includes">
                <?php foreach ( $incl as $line ): ?><li><?php echo esc_html( $line ); ?></li><?php endforeach; ?>
            </ul>
            <?php endif; ?>

            <?php
            $cta_label = ( $p['mode'] === 'on_request' ) ? 'Request a Quote' : 'Enquire';
            $cta_price = ( $p['mode'] === 'on_request' ) ? '' : ( $currency . number_format( $p['price'], 0 ) );
            ?>
            <button type="button" class="gs-wedding-pkg-cta<?php echo $p['mode'] === 'on_request' ? ' gs-wedding-pkg-cta-quote' : ''; ?>" onclick="vsOpenInquiry({name:'<?php echo esc_js( $title ); ?>',type:'service',price:'<?php echo esc_js( $cta_price ); ?>'})"><?php echo esc_html( $cta_label ); ?></button>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $items          each with title/description/tag/price_mode/price/original_price/includes
     *     @type array  $vendor_types
     *     @type string $section_title  vendor override; falls back to the adaptive heading when blank.
     *     @type string $section_description
     *     @type string $currency
     *     @type string $layout
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid( (array) ( $context['items'] ?? [] ), (string) ( $context['currency'] ?? '₹' ), (string) ( $context['layout'] ?? 'grid' ) );
        if ( $html === '' ) { return ''; }
        $heading = trim( (string) ( $context['section_title'] ?? '' ) );
        if ( $heading === '' ) {
            $heading = \GoodService\Modules\WeddingEventsModule::packages_heading( (array) ( $context['vendor_types'] ?? [] ) );
        }
        return self::render_title( $heading, (string) ( $context['section_description'] ?? '' ) ) . $html;
    }
}
