<?php
namespace GoodService\Modules;

/**
 * WeddingStoriesModule — Events & Wedding, Section 02: "Real Weddings /
 * Real Events". Distinct from Section 01's flat portfolio grid: this
 * section groups multiple photos into named "story" cards — one real
 * wedding or one real event, with a title, an optional short
 * description, an optional date/location, and its own set of photos —
 * rendered as a grid of story cards that open into a story-scoped
 * gallery, not a flat photo grid.
 *
 * Each story gets its own lightbox grid id (vs-wedding-story-{index}-
 * grid) so window.vsLightbox(url, caption, gridId) can navigate each
 * story's photos independently of every other story's — same reason
 * Section 01 gives its own grid its own id.
 */
class WeddingStoriesModule {

    public static function render_title( string $heading, string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-wedding-sec-head">
        <div class="gs-wedding-eyebrow">Our Work</div>
        <h2 class="vs-sec-title gs-wedding-title"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-wedding-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render_grid( array $stories, array $img_display = [] ): string {
        // A story with zero real photos never renders — same filter the
        // data layer already applies, kept here too since render_grid()
        // can be called directly with unfiltered data.
        $stories = array_values( array_filter( $stories, function ( $s ) {
            if ( ! is_array( $s ) || trim( (string) ( $s['title'] ?? '' ) ) === '' ) { return false; }
            $photos = array_values( array_filter( (array) ( $s['photos'] ?? [] ), fn( $p ) => is_string( $p ) && trim( $p ) !== '' ) );
            return ! empty( $photos );
        } ) );
        if ( empty( $stories ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];

        ob_start();
        ?>
    <div class="gs-wedding-stories-grid">
        <?php foreach ( $stories as $_idx => $story ):
            $photos    = array_values( array_filter( (array) ( $story['photos'] ?? [] ), fn( $p ) => is_string( $p ) && trim( $p ) !== '' ) );
            $cover     = $photos[0];
            $title     = trim( (string) ( $story['title'] ?? '' ) );
            $desc      = trim( (string) ( $story['description'] ?? '' ) );
            $date      = trim( (string) ( $story['event_date'] ?? '' ) );
            $location  = trim( (string) ( $story['location'] ?? '' ) );
            $cat_key   = (string) ( $story['category'] ?? '' );
            $cat_label = isset( \GoodService\Modules\WeddingEventsModule::PORTFOLIO_CATEGORIES[ $cat_key ] ) ? \GoodService\Modules\WeddingEventsModule::PORTFOLIO_CATEGORIES[ $cat_key ] : '';
            $grid_id   = 'vs-wedding-story-' . $_idx . '-grid';
            $meta_bits = array_values( array_filter( [ $date, $location ] ) );
        ?>
        <div class="gs-wedding-story-card">
            <button type="button" class="gs-wedding-story-cover" onclick="vsLightbox('<?php echo esc_js( $cover ); ?>','<?php echo esc_js( $title ); ?>','<?php echo esc_js( $grid_id ); ?>')">
                <img src="<?php echo esc_url( $cover ); ?>" alt="<?php echo esc_attr( $title ); ?>" class="gs-wedding-story-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php if ( $cat_label !== '' ): ?><span class="gs-wedding-story-badge"><?php echo esc_html( $cat_label ); ?></span><?php endif; ?>
                <span class="gs-wedding-story-count">View Gallery — <?php echo count( $photos ); ?> photo<?php echo count( $photos ) === 1 ? '' : 's'; ?></span>
            </button>
            <div class="gs-wedding-story-body">
                <div class="gs-wedding-story-title"><?php echo esc_html( $title ); ?></div>
                <?php if ( ! empty( $meta_bits ) ): ?><div class="gs-wedding-story-meta"><?php echo esc_html( implode( ' · ', $meta_bits ) ); ?></div><?php endif; ?>
                <?php if ( $desc !== '' ): ?><p class="gs-wedding-story-desc"><?php echo esc_html( $desc ); ?></p><?php endif; ?>
            </div>
            <div class="gs-wedding-story-hidden-photos" id="<?php echo esc_attr( $grid_id ); ?>" hidden>
                <?php foreach ( $photos as $_p ): ?>
                <img src="<?php echo esc_url( $_p ); ?>" alt="<?php echo esc_attr( $title ); ?>">
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $items          the story array (each with title/description/event_date/location/category/photos)
     *     @type array  $vendor_types
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid(
            (array) ( $context['items'] ?? [] ),
            (array) ( $context['img_display'] ?? [] )
        );
        if ( $html === '' ) { return ''; }
        $heading = trim( (string) ( $context['section_title'] ?? '' ) );
        if ( $heading === '' ) {
            $heading = \GoodService\Modules\WeddingEventsModule::stories_heading( (array) ( $context['vendor_types'] ?? [] ) );
        }
        return self::render_title( $heading, (string) ( $context['section_description'] ?? '' ) ) . $html;
    }
}
