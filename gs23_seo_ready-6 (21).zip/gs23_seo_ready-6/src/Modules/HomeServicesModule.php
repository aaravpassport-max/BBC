<?php
namespace GoodService\Modules;

/**
 * HomeServicesModule — the foundational data-access layer for the
 * Home Repair & Services category build, matching the established
 * pattern of BeautySalonModule / HealthWellnessModule before it: one
 * small, shared class per category holding the real category slug,
 * shared constants, and the plain data-fetch helpers every module in
 * the category needs, rather than each module re-declaring its own
 * copy.
 *
 * CONFIRMED, not guessed, per the master build prompt's Section 0.2:
 * "Home Services" is a real, pre-seeded category — see
 * src/Database/Seeder.php::seed_categories() (name 'Home Services',
 * slug 'home-services'). This was read directly from the seeder, not
 * assumed from the custom build spec's own working title "Home Repair
 * & Services".
 *
 * Module 1 of this category's build — Service Catalogue & Problem
 * Solver — deliberately combines what the custom build spec describes
 * as two separate sections (Section 01 "Service Discovery & Problem
 * Solver" and Section 02 "Service Menu / Catalogue") into one module,
 * per the spec's own explicit "Data-Density Requirement" (its Section
 * 32): "the Service Discovery section can combine: Service Categories
 * + Common Problems + Popular Services + Quick Actions." Splitting
 * these into two separate always-empty-until-filled sections would
 * produce two thin sections instead of one genuinely useful one.
 */
class HomeServicesModule {

    /** Service groups (Section 03/04 of the custom build spec — "primary
     * service groups"). Only a subset the vendor actually has services
     * in is ever shown — see get_active_groups(). Keys are stored on
     * each service's own `group` field; values are the tab label. */
    public const SERVICE_GROUPS = [
        'ac_cooling'         => 'AC & Cooling',
        'electrical'         => 'Electrical',
        'plumbing'           => 'Plumbing',
        'appliance_repair'   => 'Appliance Repair',
        'cleaning'           => 'Cleaning',
        'pest_control'       => 'Pest Control',
        'carpentry'          => 'Carpentry',
        'painting'           => 'Painting',
        'waterproofing'      => 'Waterproofing',
        'ro_water_purifier'  => 'RO & Water Purifier',
        'cctv_security'      => 'CCTV & Security',
        'solar_power'        => 'Solar & Power',
        'general_maintenance'=> 'General Maintenance',
    ];

    /** Optional per-service flags a vendor can tick — never inferred,
     * only ever shown when the vendor explicitly set them (custom
     * build spec's repeated "only show genuine configured X" rule). */
    public const SERVICE_FLAGS = [
        'is_popular' => 'Popular',
        'is_new'     => 'New',
        'emergency'  => 'Emergency Service',
    ];

    public static function get_services( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'home_services_catalogue', $listing_id );
        return array_values( array_filter( (array) ( $data['services'] ?? [] ), fn( $s ) => is_array( $s ) && ! empty( $s['name'] ) ) );
    }

    /** Only the groups that at least one real, named service actually
     * uses — the spec's explicit "Only show groups supported by the
     * vendor" rule (its Section 03). An "All" tab is added by the
     * render layer, not here, since whether the count warrants an
     * "All" tab is a display decision, not a data one. */
    public static function get_active_groups( array $services ): array {
        $used = [];
        foreach ( $services as $s ) {
            $g = $s['group'] ?? '';
            if ( $g !== '' && isset( self::SERVICE_GROUPS[ $g ] ) && ! isset( $used[ $g ] ) ) {
                $used[ $g ] = self::SERVICE_GROUPS[ $g ];
            }
        }
        return $used;
    }

    /**
     * The problem-first discovery layer (custom build spec's Section 03:
     * "Problem-first discovery" — "AC not cooling", "Water leaking",
     * etc., each mapping back to a recommended service). Built entirely
     * from each service's own vendor-entered `problems` list — never a
     * hardcoded, generic problem list unrelated to what this specific
     * vendor actually offers, and never phrased as a guaranteed
     * diagnosis (the spec explicitly requires "Possible service", never
     * "Your problem is definitely X" — enforced by the render layer's
     * copy, not here).
     *
     * @return array<string,array<int,string>> problem text => list of
     *         service names that address it (a problem can legitimately
     *         map to more than one service, e.g. a multi-service vendor
     *         who lists "AC not cooling" against both an AC service and
     *         a general maintenance visit).
     */
    public static function get_problem_map( array $services ): array {
        $map = [];
        foreach ( $services as $s ) {
            $name = trim( (string) ( $s['name'] ?? '' ) );
            if ( $name === '' ) { continue; }
            foreach ( (array) ( $s['problems'] ?? [] ) as $p ) {
                $p = trim( (string) $p );
                if ( $p === '' ) { continue; }
                if ( ! isset( $map[ $p ] ) ) { $map[ $p ] = []; }
                if ( ! in_array( $name, $map[ $p ], true ) ) { $map[ $p ][] = $name; }
            }
        }
        return $map;
    }
}
