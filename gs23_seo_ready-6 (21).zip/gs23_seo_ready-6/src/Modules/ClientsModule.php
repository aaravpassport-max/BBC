<?php
namespace GoodService\Modules;

/**
 * ClientsModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of the existing Clients rendering logic from
 * vendor-site.php's $_el_capture calls for 'clients_title' and
 * 'clients_logos'.
 *
 * Same clients_data sourcing pattern as TeamModule (excluded from the
 * main query, fetched via $_fetch_premium_section() only when a cheap
 * length-check confirms it's worth it) — see TeamModule's docblock for
 * the full rationale, not repeated here.
 *
 * Genuinely new complexity not seen in any module migrated so far:
 * this callback computes each logo's natural aspect ratio via
 * getimagesize() (a real, potentially slow network call for a remote
 * URL) and caches the result in a 30-day transient, keyed by the
 * logo's own URL — avoiding a repeated network call for the same logo
 * on every single page load. This module preserves that exact caching
 * behavior rather than simplifying it away.
 */
class ClientsModule {

    /** Faithful copy of the 'clients_title' $_el_capture callback — no
     * parameters, matching the original's empty use() clause. */
    public static function render_title(): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Our Clients</div>
        <h2 class="vs-sec-title">Trusted by Leading Brands</h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /** Faithful copy of the 'clients_logos' $_el_capture callback. */
    /** @param string $img_fit Image Fit — site-wide image-fit audit: previously hardcoded to a computed-natural-aspect width with no vendor choice at all; now a real setting layered on top of that same distortion-free width computation. */
    public static function render_logos( array $clients_data, int $logo_height, string $img_fit = 'contain' ): string {
        if ( empty( $clients_data ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( [ 'fit' => $img_fit ] )['img'];
        ob_start();
        ?>
    <div class="vs-clients-grid">
        <?php foreach ( $clients_data as $cl ):
            if ( empty( $cl['name'] ) && empty( $cl['logo'] ) ) continue;
            // Real fix, PageSpeed audit: height is fixed platform-wide via
            // CSS, but each logo's natural width varies — computes the
            // real width at that fixed height from the actual image's
            // aspect ratio, same cached getimagesize() pattern already
            // proven correct for the hero/about images.
            $_cl_dim_w = 0;
            if ( ! empty( $cl['logo'] ) ) {
                $_cl_dim_cache_key = 'gs_cllogo_dim_' . md5( $cl['logo'] );
                $_cl_dim = get_transient( $_cl_dim_cache_key );
                if ( $_cl_dim === false ) {
                    $_cl_dim = @getimagesize( $cl['logo'] ) ?: [ 0, 0 ];
                    set_transient( $_cl_dim_cache_key, $_cl_dim, 30 * DAY_IN_SECONDS );
                }
                if ( ! empty( $_cl_dim[0] ) && ! empty( $_cl_dim[1] ) ) {
                    $_cl_dim_w = (int) round( ( $_cl_dim[0] / $_cl_dim[1] ) * $logo_height );
                }
            }
        ?>
        <?php if ( ! empty( $cl['logo'] ) ): ?>
            <?php $wrap_tag = ! empty( $cl['url'] ) ? 'a' : 'span'; ?>
            <<?php echo $wrap_tag; ?><?php if($wrap_tag==='a'): ?> href="<?php echo esc_url($cl['url']); ?>" target="_blank" rel="noopener nofollow"<?php endif; ?>>
                <img src="<?php echo esc_url( $cl['logo'] ); ?>"
                     alt="<?php echo esc_attr( $cl['name'] ?? '' ); ?>"
                     class="vs-client-logo" loading="lazy"
                     height="<?php echo (int) $logo_height; ?>"<?php if($_cl_dim_w>0): ?> width="<?php echo (int) $_cl_dim_w; ?>"<?php endif; ?>
                     style="<?php echo esc_attr( $_img_style ); ?>"
                     title="<?php echo esc_attr( $cl['name'] ?? '' ); ?>">
            </<?php echo $wrap_tag; ?>>
        <?php elseif ( ! empty( $cl['name'] ) ): ?>
            <span class="vs-clients-text-item"><?php echo esc_html( $cl['name'] ); ?></span>
        <?php endif; ?>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array $clients_data  The already-fetched clients array.
     *     @type int   $logo_height   $cv_client_logo_height from the
     *                  caller — a platform-wide fixed CSS height, not
     *                  per-listing customizer data, so it's passed as
     *                  its own explicit key rather than bundled into 'cd'.
     * }
     */
    public static function render( array $context ): string {
        $clients_data = $context['clients_data'] ?? [];
        $logo_height = (int) ( $context['logo_height'] ?? 44 );
        return self::render_title() . self::render_logos( $clients_data, $logo_height, (string) ( $context['img_fit'] ?? 'contain' ) );
    }
}
