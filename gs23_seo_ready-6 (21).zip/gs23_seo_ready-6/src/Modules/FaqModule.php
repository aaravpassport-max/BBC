<?php
namespace GoodService\Modules;

/**
 * FaqModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of the existing FAQ rendering logic from
 * vendor-site.php's $_el_capture calls for 'faq_title' and 'faq_items'.
 *
 * [CORRECTION — found and fixed in a later session, documented here per
 * this project's own standard of recording mistakes explicitly, not
 * silently]: this class's docblock previously claimed a "real bug" —
 * that the original 'faq_items' callback's `foreach ($primary->faq_data
 * as ...)` treats faq_data as already-decoded when it's actually a raw
 * JSON string, causing zero iterations for every vendor. That claim was
 * WRONG, and the error was a testing-methodology mistake: the isolated
 * test that "proved" it fed a raw JSON string directly into the
 * extracted callback, which is NOT how the real live page ever calls
 * it. vendor-site.php has a pre-existing global JSON-decode loop
 * (search for "Decode all JSON blobs", ~line 391) that runs on EVERY
 * page load, decodes `$primary->faq_data` (and why_choose_data,
 * process_data, and 16 other fields) into a real array, and does so
 * long before any $_el_capture callback executes. Verified directly:
 * extracting that real decode loop verbatim and running it ahead of
 * the real faq_items callback, with a realistic raw-JSON-string input,
 * produces correctly rendered FAQ items — no bug. FAQ items DO render
 * correctly for vendors today; they always have.
 *
 * The good news: this class's actual CODE was never wrong — decoding
 * defensively (`is_string(...) ? json_decode(...) : $data`) is correct
 * regardless of whether the input arrives already-decoded (the real
 * case) or as a string (never actually happens, but handling it is
 * harmless). Enabling GS_USE_MODULE_ENGINE_FAQ therefore changes
 * NOTHING observable in production — flag-on and flag-off produce
 * identical output today, because the real input is always already an
 * array by the time either path runs. The only thing wrong was the
 * "why this fix matters" narrative, now corrected.
 */
class FaqModule {

    /** Faithful copy of the 'faq_title' $_el_capture callback. */
    public static function render_title( array $hd ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Got Questions?</div>
        <h2 class="vs-sec-title"><?php echo esc_html($hd['faq_section_title'] ?? 'Frequently Asked Questions'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Corrected copy of the 'faq_items' $_el_capture callback — see
     * class docblock for the real bug this fixes (JSON decoding).
     */
    public static function render_items( $faq_data_raw ): string {
        if ( empty( $faq_data_raw ) ) { return ''; }
        $items = is_string( $faq_data_raw ) ? ( json_decode( $faq_data_raw, true ) ?: [] ) : $faq_data_raw;
        if ( empty( $items ) ) { return ''; }
        ob_start();
        ?>
    <div class="vs-faq-list">
        <?php foreach ($items as $i => $faq): if (empty($faq['question'])) continue; ?>
        <div class="vs-faq-item" onclick="this.classList.toggle('on')">
            <div class="vs-faq-q">
                <span><?php echo esc_html($faq['question']); ?></span>
                <span class="vs-faq-arrow">▾</span>
            </div>
            <div class="vs-faq-a"><?php echo wp_kses_post($faq['answer'] ?? ''); ?></div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $hd = $context['hd'] ?? [];
        $faq_data_raw = $context['module_data']['faq_data']
            ?? ( $context['primary']->faq_data ?? null );
        return self::render_title( $hd ) . self::render_items( $faq_data_raw );
    }
}
