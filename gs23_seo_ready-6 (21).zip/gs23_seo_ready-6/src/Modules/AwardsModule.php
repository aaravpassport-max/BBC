<?php
namespace GoodService\Modules;

/**
 * AwardsModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of the existing Awards rendering logic (title
 * block + badge-ring card grid) from vendor-site.php's $_el_capture
 * calls for 'awards_title' and 'awards_grid'.
 *
 * Note: Certifications (migrated separately as CertificationsModule)
 * shares the same vs-awd-* CSS classes and a very similar card
 * structure, but has genuinely distinct fields (credential_id,
 * verify_url) and a different badge-ring style override. Built as two
 * fully independent modules rather than one shared base class — per
 * the roadmap's principle that modules stay independent so a future
 * change to one never risks silently affecting the other.
 */
class AwardsModule {

    private static function has_real_content( $raw, string $required_key ): bool {
        if ( empty( $raw ) ) { return false; }
        $decoded = json_decode( (string) $raw, true );
        if ( ! is_array( $decoded ) ) { return false; }
        if ( array_key_exists( $required_key, $decoded ) ) {
            return ! empty( $decoded[ $required_key ] );
        }
        foreach ( $decoded as $item ) {
            if ( is_array( $item ) && ! empty( $item[ $required_key ] ?? null ) ) { return true; }
        }
        return false;
    }

    /** Faithful copy of the 'awards_title' $_el_capture callback. */
    public static function render_title( array $cd ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['awards_section_title'] ?? 'Awards & Recognition'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /** Faithful copy of the 'awards_grid' $_el_capture callback. */
    public static function render_grid( $awards_data_raw, array $cd ): string {
        if ( ! self::has_real_content( $awards_data_raw, 'title' ) ) { return ''; }
        $items = is_string( $awards_data_raw ) ? ( json_decode( $awards_data_raw, true ) ?: [] ) : $awards_data_raw;
        $_awd_img_settings = is_array( $cd['awards_img_display'] ?? null ) ? $cd['awards_img_display'] : [];
        $_awd_style = gs_vs_img_display_style( $_awd_img_settings );
        $_awd_ring_style = ! empty( $_awd_img_settings['badge_size'] ) ? 'width:' . (int) $_awd_img_settings['badge_size'] . 'px;height:' . (int) $_awd_img_settings['badge_size'] . 'px;' : '';
        ob_start();
        ?>
    <div class="vs-awd-grid">
        <?php foreach ($items as $a): if (empty($a['title'])) continue; ?>
        <div class="vs-awd-card">
            <div class="vs-awd-badge-ring" style="<?php echo esc_attr($_awd_ring_style); ?>">
                <div class="vs-awd-badge">
                    <?php if (!empty($a['image'])): ?>
                        <img src="<?php echo esc_url($a['image']); ?>" alt="<?php echo esc_attr($a['title']); ?>" loading="lazy" width="100" height="100" style="<?php echo esc_attr($_awd_style['img']); ?>">
                    <?php else: ?>
                        <span class="vs-awd-badge-emoji">🏆</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="vs-awd-title"><?php echo esc_html($a['title']); ?></div>
            <?php if (!empty($a['issuer']) || !empty($a['year'])): ?>
            <div class="vs-awd-meta"><?php echo esc_html(trim(($a['issuer'] ?? '') . (!empty($a['issuer']) && !empty($a['year']) ? ' · ' : '') . ($a['year'] ?? ''))); ?></div>
            <?php endif; ?>
            <?php if (!empty($a['description'])): ?>
            <div class="vs-awd-desc"><?php echo esc_html($a['description']); ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $cd = $context['cd'] ?? [];
        $awards_data_raw = $context['module_data']['awards_data']
            ?? ( $context['primary']->awards_data ?? null );
        return self::render_title( $cd ) . self::render_grid( $awards_data_raw, $cd );
    }
}
