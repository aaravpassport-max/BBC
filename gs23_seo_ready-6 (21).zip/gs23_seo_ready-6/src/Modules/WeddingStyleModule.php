<?php
namespace GoodService\Modules;

/**
 * WeddingStyleModule — Events & Wedding, Section 05: "Experience &
 * Style". A deliberately light section: a heading plus a row of fixed
 * creative-style chips (Candid, Traditional, Editorial, …) the vendor
 * selects from WeddingEventsModule::STYLE_TAGS. No images, no pricing,
 * no per-item extra fields — this is a pure customizer_data multi-
 * select setting (like wedding_vendor_types), not module-registry
 * repeater content, so unlike Sections 01-04 there is no items array
 * and no ModuleRegistry::fetch_module_data() call anywhere in this
 * class's own render path — the caller (vendor-site.php) reads the
 * selected tags directly via WeddingEventsModule::get_style_tags($cd)
 * and hands them into render() as plain context, exactly like
 * vendor_types is threaded through every other section.
 */
class WeddingStyleModule {

    public static function render_title( string $heading, string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-wedding-sec-head">
        <div class="gs-wedding-eyebrow">Our Work</div>
        <h2 class="vs-sec-title gs-wedding-title"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-wedding-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $style_tags     selected keys, already validated against STYLE_TAGS by the caller.
     *     @type array  $vendor_types
     *     @type string $section_title  vendor override; falls back to the adaptive heading when blank.
     *     @type string $section_description
     * }
     */
    public static function render( array $context ): string {
        $tags = array_values( array_intersect( (array) ( $context['style_tags'] ?? [] ), array_keys( WeddingEventsModule::STYLE_TAGS ) ) );
        if ( empty( $tags ) ) { return ''; }

        $heading = trim( (string) ( $context['section_title'] ?? '' ) );
        if ( $heading === '' ) {
            $heading = WeddingEventsModule::styles_heading( (array) ( $context['vendor_types'] ?? [] ) );
        }

        ob_start();
        ?>
    <div class="gs-wedding-style-grid">
        <?php foreach ( $tags as $tag ): $info = WeddingEventsModule::style_tag_info( $tag ); if ( $info['label'] === '' ) { continue; } ?>
        <div class="gs-wedding-style-card">
            <div class="gs-wedding-style-card-label"><?php echo esc_html( $info['label'] ); ?></div>
            <?php if ( $info['desc'] !== '' ): ?><p class="gs-wedding-style-card-desc"><?php echo esc_html( $info['desc'] ); ?></p><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        $grid = ob_get_clean();

        return self::render_title( $heading, (string) ( $context['section_description'] ?? '' ) ) . $grid;
    }
}
