<?php
namespace GoodService\Modules;

/**
 * HotelEventSpacesModule — Hotels / Banquets / Hospitality category,
 * Module 1: "Banquet & Event Spaces" (custom build spec's Sections 03,
 * 08 and 09: Event Space types, the Event Venue card, and the Event
 * Capacity Matrix).
 *
 * CATEGORY SLUG ASSUMPTION, noted explicitly per this project's own
 * established convention (see RoomTypesModule's own docblock, which
 * made and documented the exact same assumption first): the category
 * slug used for gating is 'hotels' — the same slug RoomTypesModule
 * already registers against. Categories on this platform are created
 * by real admins, not fully seeded (src/Database/Seeder.php's static
 * list only covers 8 general categories and does not include a
 * hotels/hospitality one), so 'hotels' is not independently
 * "confirmed" here either — but reusing the exact same slug an
 * existing, already-shipped, already-wired module uses is far safer
 * than guessing a second, different slug ('hospitality',
 * 'banquets') that would silently split this category's listings
 * across two unrelated category rows. If the real slug differs, both
 * this module's and RoomTypesModule's single 'categories' => [...]
 * line need the same one-line fix together.
 *
 * INVESTIGATION PERFORMED FIRST, per the master build prompt's Section
 * 0.1: RoomTypesModule (module_key 'room_types') already fully covers
 * the spec's Section 02/05/06 (Rooms & Accommodation, Room Gallery via
 * its own additional_images popup slider, and the Room Detail
 * Experience via the shared vsOpenDetailPopup component) — not
 * rebuilt here. The spec's Sections 11 (Packages), 19 (Team), 20
 * (Reviews), 21 (FAQ) are already served by the universal `packages`,
 * `team`, `testimonials` and `faq` modules (category 'all',
 * default_enabled true) — a vendor in the 'hotels' category already
 * has all four active by default; not duplicated here either. What
 * remains genuinely uncovered is the venue/event-space side of the
 * business (banquet halls, ballrooms, conference rooms) with its own
 * capacity-by-arrangement matrix — a structured, actionable piece of
 * information no existing module can express — which is what this
 * module adds.
 *
 * Reuses established platform mechanisms exactly like every other
 * module in this codebase: vsOpenDetailPopup() for "View Venue" and
 * vsOpenInquiry() for "Check Date" (seeded with the venue's own name
 * and price, matching RoomTypesModule's and HomeServicesCatalogueModule's
 * own exact call pattern) — no new popup or enquiry mechanism built.
 */
class HotelEventSpacesModule {

    public static function get_venues( $wpdb, string $table_prefix, int $listing_id ): array {
        $stored = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'hotel_event_spaces', $listing_id );
        return array_values( array_filter( (array) ( $stored['venues'] ?? [] ), fn( $v ) => is_array( $v ) ) );
    }

    public const SPACE_TYPES = [
        'banquet_hall'    => 'Banquet Hall',
        'ballroom'        => 'Ballroom',
        'lawn'            => 'Lawn',
        'rooftop'         => 'Rooftop',
        'terrace'         => 'Terrace',
        'poolside'        => 'Poolside',
        'conference_room' => 'Conference Room',
        'boardroom'       => 'Boardroom',
        'meeting_room'    => 'Meeting Room',
        'outdoor_venue'   => 'Outdoor Venue',
        'pre_function'    => 'Pre-Function Area',
    ];

    /** Capacity matrix columns (custom build spec's Section 09). Keys
     * match the admin panel's field names exactly. Only a column with
     * at least one real, vendor-entered value across all venues is
     * ever rendered — an all-empty column is never shown as a blank
     * "0" or dash (spec's Zero-Data Handling). */
    public const CAPACITY_ARRANGEMENTS = [
        'theatre'     => 'Theatre',
        'round_table' => 'Round Table',
        'u_shape'     => 'U-Shape',
        'classroom'   => 'Classroom',
        'boardroom'   => 'Boardroom',
        'cocktail'    => 'Cocktail',
        'standing'    => 'Standing',
    ];

    public static function render_title( string $title = 'Celebrate Your Moments Here', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-hev-sec-head">
        <div class="gs-hev-eyebrow">Event Spaces</div>
        <h2 class="vs-sec-title gs-hev-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-hev-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /** Custom build spec's exact price-state contract (its own Section
     * 08: "Starting Price / Custom Quote") — matches
     * HomeServicesCatalogueModule's own price_display() rule exactly:
     * never a fabricated or ₹0 price standing in for a real one. */
    private static function price_display( array $venue ): string {
        $currency = \gs_setting( 'currency_symbol', '₹' );
        $exact = trim( (string) ( $venue['price'] ?? '' ) );
        if ( $exact !== '' && is_numeric( $exact ) && (float) $exact > 0 ) {
            return $currency . $exact;
        }
        return 'Custom Quote';
    }

    /**
     * Renders the capacity matrix table, one row per venue that has at
     * least one real capacity figure, one column per arrangement that
     * at least one venue actually specified. A venue/arrangement cell
     * with no value renders as an em-dash, never a fabricated "0" or
     * blank implying zero capacity.
     */
    private static function render_capacity_matrix( array $venues ): string {
        $used_cols = [];
        foreach ( $venues as $v ) {
            foreach ( array_keys( self::CAPACITY_ARRANGEMENTS ) as $col ) {
                if ( isset( $v['capacity'][ $col ] ) && is_numeric( $v['capacity'][ $col ] ) && (int) $v['capacity'][ $col ] > 0 ) {
                    $used_cols[ $col ] = true;
                }
            }
        }
        if ( empty( $used_cols ) ) { return ''; }
        $rows = array_values( array_filter( $venues, fn( $v ) => ! empty( array_intersect_key( (array) ( $v['capacity'] ?? [] ), $used_cols ) ) ) );
        if ( empty( $rows ) ) { return ''; }

        ob_start();
        ?>
    <div class="gs-hev-matrix-wrap">
        <div class="gs-hev-matrix-title">Capacity by Arrangement</div>
        <div class="gs-hev-matrix-scroll">
        <table class="gs-hev-matrix">
            <thead><tr><th>Venue</th>
                <?php foreach ( array_keys( $used_cols ) as $col ): ?><th><?php echo esc_html( self::CAPACITY_ARRANGEMENTS[ $col ] ); ?></th><?php endforeach; ?>
            </tr></thead>
            <tbody>
            <?php foreach ( $rows as $v ): ?>
            <tr><td class="gs-hev-matrix-venue"><?php echo esc_html( $v['name'] ); ?></td>
                <?php foreach ( array_keys( $used_cols ) as $col ):
                    $val = $v['capacity'][ $col ] ?? null;
                ?>
                <td><?php echo ( is_numeric( $val ) && (int) $val > 0 ) ? (int) $val : '—'; ?></td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $img_display  fit/position/zoom — shared,
     *              gs_vs_img_display_style() helper.
     */
    public static function render_grid( array $venues, array $img_display = [] ): string {
        $venues = array_values( array_filter( $venues, fn( $v ) => ! empty( $v['name'] ) ) );
        if ( empty( $venues ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];

        ob_start();
        ?>
    <div class="gs-hev-grid">
        <?php foreach ( $venues as $venue ):
            $event_types = array_values( array_filter( array_map( 'trim', explode( ',', (string) ( $venue['event_types'] ?? '' ) ) ) ) );
            $price_display = self::price_display( $venue );
        ?>
        <div class="gs-hev-card">
            <?php if ( ! empty( $venue['image'] ) ): ?>
            <div class="gs-hev-card-media">
                <img src="<?php echo esc_url( $venue['image'] ); ?>" alt="<?php echo esc_attr( $venue['name'] ); ?>" class="gs-hev-card-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php if ( ! empty( $venue['type'] ) && isset( self::SPACE_TYPES[ $venue['type'] ] ) ): ?>
                <span class="gs-hev-card-type-badge"><?php echo esc_html( self::SPACE_TYPES[ $venue['type'] ] ); ?></span>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <div class="gs-hev-card-body">
                <div class="gs-hev-card-name"><?php echo esc_html( $venue['name'] ); ?></div>
                <div class="gs-hev-card-meta">
                    <?php if ( ! empty( $venue['capacity']['max_guests'] ) ): ?><span class="gs-hev-meta-item">👥 Up to <?php echo (int) $venue['capacity']['max_guests']; ?> Guests</span><?php endif; ?>
                    <?php if ( ! empty( $venue['indoor_outdoor'] ) ): ?><span class="gs-hev-meta-item"><?php echo $venue['indoor_outdoor'] === 'outdoor' ? '🌤 Outdoor' : '🏢 Indoor'; ?></span><?php endif; ?>
                    <?php if ( ! empty( $venue['area'] ) ): ?><span class="gs-hev-meta-item">📐 <?php echo esc_html( $venue['area'] ); ?></span><?php endif; ?>
                </div>
                <?php if ( ! empty( $event_types ) ): ?>
                <div class="gs-hev-card-events">Ideal for: <?php echo esc_html( implode( ' • ', $event_types ) ); ?></div>
                <?php endif; ?>
                <?php if ( ! empty( $venue['description'] ) ): ?><p class="gs-hev-card-desc"><?php echo esc_html( $venue['description'] ); ?></p><?php endif; ?>
                <div class="gs-hev-card-footer">
                    <span class="gs-hev-card-price"><?php echo esc_html( $price_display ); ?></span>
                    <div class="gs-hev-card-ctas">
                        <a href="#" class="gs-hev-cta-secondary"
                           data-title="<?php echo esc_attr( $venue['name'] ); ?>"
                           data-image="<?php echo esc_attr( $venue['image'] ?? '' ); ?>"
                           data-price="<?php echo esc_attr( $price_display ); ?>"
                           data-sections="<?php echo esc_attr( wp_json_encode( array_values( array_filter( [
                               ! empty( $venue['description'] ) ? [ 'content_type' => 'richtext', 'title' => 'About This Venue', 'icon' => '📝', 'body' => esc_html( $venue['description'] ) ] : null,
                               ! empty( $event_types ) ? [ 'content_type' => 'list', 'title' => 'Ideal For', 'icon' => '🎉', 'list_items' => $event_types ] : null,
                           ] ) ) ) ); ?>"
                           onclick="event.preventDefault();vsOpenDetailPopup(event,this)">Explore Venue</a>
                        <a href="#" class="gs-hev-cta-primary" onclick="event.preventDefault();vsOpenInquiry({name:'<?php echo esc_js( $venue['name'] ); ?>',type:'service',price:'<?php echo esc_js( $price_display ); ?>'})">Check Date</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php echo self::render_capacity_matrix( $venues ); ?>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $venues
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid(
            $context['venues'] ?? [],
            (array) ( $context['img_display'] ?? [] )
        );
        if ( $html === '' ) { return ''; } // Mandatory empty-state — custom build spec's Section 48 (Zero-Data Behaviour).
        return self::render_title( $context['section_title'] ?? 'Celebrate Your Moments Here', $context['section_description'] ?? '' ) . $html;
    }
}
