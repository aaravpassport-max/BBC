<?php
namespace GoodService\Modules;

/**
 * TestimonialsModule — Phase 2 of the modular listing architecture
 * roadmap.
 *
 * Same premium-section fetch mechanism as Pricing and Portfolio:
 * `$_fetch_premium_section('testimonials_data')` (~line 833 of
 * vendor-site.php). `$primary->testimonials_data` is never the real
 * data — Router.php deliberately leaves it empty for performance.
 *
 * Checked explicitly for the closure-capture bug class found in
 * Products/Items and Gallery (Section 6.10) — clean here.
 * 'testimonials_grid' only references its own `use()` variable
 * ($_testi_data) and loop-local values ($t, $rating, $initials,
 * $is_video, $video_embed, $vm) — nothing missing.
 *
 * Faithful extraction of 'testimonials_title' and 'testimonials_grid'.
 * No logic changes, including one harmless piece of genuinely dead
 * code preserved exactly rather than "cleaned up": `$star_hints` (a
 * label map for star ratings) is assigned but never actually
 * referenced anywhere in the original callback — confirmed via a
 * direct search of the callback body. It has zero effect on output;
 * removing it would be a real behavior-preserving no-op, but this is a
 * pure migration, not a cleanup pass, so it's kept exactly as-is.
 */
class TestimonialsModule {

    public static function render_title(): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Social Proof</div>
        <h2 class="vs-sec-title">What Our Clients Say</h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /** @param string $img_fit Image Fit — site-wide image-fit audit: previously hardcoded, now a real vendor-facing setting (applies to the reviewer avatar). */
    public static function render_grid( array $testi_data, string $img_fit = 'cover' ): string {
        if ( empty( $testi_data ) ) { return ''; }
        $star_hints = [ 1=>'Poor', 2=>'Fair', 3=>'Good', 4=>'Very Good', 5=>'Excellent' ];
        $_img_style = \gs_vs_img_display_style( [ 'fit' => $img_fit ] )['img'];
        ob_start();
        ?>
    <div class="vs-testi-grid">
        <?php foreach ( $testi_data as $t ):
            if ( empty( $t['name'] ) && empty( $t['text'] ) && empty( $t['video_url'] ) ) continue;
            $rating    = max( 0, min( 5, (int)( $t['rating'] ?? 5 ) ) );
            $initials  = strtoupper( substr( trim( $t['name'] ?? 'C' ), 0, 1 ) );
            $is_video  = ! empty( $t['video_url'] );
            $video_embed = '';
            if ( $is_video ) {
                if ( preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([A-Za-z0-9_-]+)/', $t['video_url'], $vm ) ) {
                    $video_embed = 'https://www.youtube.com/embed/' . $vm[1] . '?autoplay=1&rel=0';
                } elseif ( preg_match('/vimeo\.com\/(\d+)/', $t['video_url'], $vm ) ) {
                    $video_embed = 'https://player.vimeo.com/video/' . $vm[1] . '?autoplay=1';
                }
            }
        ?>
        <div class="vs-testi-card">
            <div class="vs-testi-quote">"</div>

            <?php if ( $is_video ): ?>
            <?php if ( $video_embed ): ?>
            <!-- Video testimonial with play-in-place -->
            <div class="vs-testi-video-wrap"
                 onclick="this.innerHTML='<iframe src=\'<?php echo esc_js($video_embed); ?>\' width=\'100%\' height=\'160\' frameborder=\'0\' allow=\'autoplay;encrypted-media\' allowfullscreen style=\'display:block;border-radius:10px\'></iframe>'"
                 title="Play testimonial video">
                <?php if ( ! empty( $t['video_thumb'] ) ): ?>
                    <img src="<?php echo esc_url( $t['video_thumb'] ); ?>" alt="Video testimonial" class="vs-testi-video-thumb" loading="lazy" width="400" height="160">
                <?php else: ?>
                    <div class="vs-testi-video-thumb" style="background:#1E293B;display:flex;align-items:center;justify-content:center;font-size:2rem">🎥</div>
                <?php endif; ?>
                <div class="vs-testi-video-play">
                    <div class="vs-testi-video-play-btn">▶</div>
                </div>
            </div>
            <?php else: ?>
            <a href="<?php echo esc_url( $t['video_url'] ); ?>" target="_blank" rel="noopener" class="vs-btn vs-btn-ghost" style="margin-bottom:12px;font-size:.8rem">▶ Watch Testimonial</a>
            <?php endif; ?>
            <?php endif; ?>

            <?php if ( $rating > 0 ): ?>
            <div class="vs-testi-stars"><?php echo str_repeat( '★', $rating ) . str_repeat( '☆', 5 - $rating ); ?></div>
            <?php endif; ?>

            <?php if ( ! empty( $t['text'] ) ): ?>
            <p class="vs-testi-text"><?php echo nl2br( esc_html( $t['text'] ) ); ?></p>
            <?php endif; ?>

            <div class="vs-testi-footer">
                <?php if ( ! empty( $t['photo'] ) ): ?>
                    <?php /* Real audit finding, item 4: deliberately left as alt="" — the customer's
                             name is already shown as visible text right below this avatar (see $t['name']
                             a few lines down), so an empty alt is the WCAG-correct choice here, avoiding a
                             redundant screen-reader announcement, unlike the genuine gaps fixed elsewhere
                             in this file where no equivalent visible text existed nearby. */ ?>
                    <img src="<?php echo esc_url( $t['photo'] ); ?>" alt="" class="vs-testi-avatar" loading="lazy" width="42" height="42" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php else: ?>
                    <div class="vs-testi-avatar"><?php echo esc_html( $initials ); ?></div>
                <?php endif; ?>
                <div>
                    <div class="vs-testi-name"><?php echo esc_html( $t['name'] ?? '' ); ?></div>
                    <?php if ( ! empty( $t['company'] ) || ! empty( $t['role'] ) ): ?>
                        <div class="vs-testi-company"><?php echo esc_html( implode( ', ', array_filter( [ $t['role'] ?? '', $t['company'] ?? '' ] ) ) ); ?></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array $testimonials_data  The already-fetched
     *                  testimonials array (via
     *                  $_fetch_premium_section) — see class docblock
     *                  for why this can't be derived from
     *                  $context['primary'] directly.
     * }
     */
    public static function render( array $context ): string {
        $testi_data = $context['testimonials_data'] ?? [];
        return self::render_title() . self::render_grid( $testi_data, (string) ( $context['img_fit'] ?? 'cover' ) );
    }
}
