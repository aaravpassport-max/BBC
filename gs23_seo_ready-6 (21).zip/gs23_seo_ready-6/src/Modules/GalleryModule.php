<?php
namespace GoodService\Modules;

/**
 * GalleryModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of 'gallery_title', 'gallery_filters', and
 * 'gallery_grid'. `gallery` IS in the global decode loop's
 * `$json_fields` list — checked before writing anything, per Section
 * 6.9 — so `$primary->gallery` always arrives as a real array.
 *
 * A REAL, MINOR bug found and fixed here — same class as the severe
 * Products/Items one (Section 6.10) but with much smaller impact: the
 * original 'gallery_grid' closure's own `use(...)` list never captures
 * `$cv_gallery_aspect`, yet the closure body reads it directly (not
 * even via a nested closure this time) at
 * `explode('/', $cv_gallery_aspect)`. Verified directly: this does NOT
 * crash (no strict type hint is involved, unlike the Items case) —
 * `explode('/', null)` returns `['']`, `array_map('intval', [''])`
 * returns `[0]`, and `count(...) === 2` is false, so the code silently
 * falls through to the `300` default height on every single render,
 * regardless of what aspect ratio the vendor actually configured via
 * `gallery_aspect`. Net effect: the "Gallery Aspect Ratio" customizer
 * setting has never actually done anything — every vendor's gallery
 * images render at a fixed fallback height no matter what they choose.
 * This module fixes it by receiving the real value as an explicit
 * parameter, matching the same fix pattern as Products/Items.
 */
class GalleryModule {

    public static function render_title( string $gallery_sec_title ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:20px">
        <div class="vs-sec-eyebrow">Visual Showcase</div>
        <h2 class="vs-sec-title"><?php echo esc_html($gallery_sec_title); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render_filters( $gallery ): string {
        if ( empty( $gallery ) ) { return ''; }
        $tags = [];
        foreach ( $gallery as $g ) { if ( ! empty( $g['tag'] ) ) $tags[ $g['tag'] ] = true; }
        if ( empty( $tags ) ) { return ''; }
        ob_start();
        ?>
    <div class="vs-gal-filters" id="vs-gal-filters">
        <button class="vs-gal-filter on" data-tag="all">All</button>
        <?php foreach (array_keys($tags) as $t): ?><button class="vs-gal-filter" data-tag="<?php echo esc_attr($t); ?>"><?php echo esc_html($t); ?></button><?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render_grid(
        $primary, $gallery, int $cv_gallery_img_h, int $cv_gallery_img_w, string $cv_gallery_img_fit,
        bool $cv_gallery_lightbox, bool $cv_gallery_captions, string $cv_gallery_aspect
    ): string {
        if ( empty( $gallery ) ) { return ''; }
        $images = array_filter( array_map( fn( $g ) => is_array( $g ) ? ( $g['url'] ?? $g ) : $g, $gallery ) );
        if ( empty( $images ) ) { return ''; }
        ob_start();
        ?>
    <div class="vs-gallery-grid" id="vs-gallery-grid">
        <?php foreach ($images as $i => $img_url): $_gal_caption = ( $primary->title ?? 'Gallery' ) . ' — photo ' . ( (int) $i + 1 ); ?>
        <div class="vs-gallery-item"<?php echo $cv_gallery_lightbox ? ' onclick="vsLightbox(\''.esc_js($img_url).'\',\''.esc_js($_gal_caption).'\')"' : ''; ?>>
            <div class="vs-img-clip">
                <?php
                $_gal_ar_parts = array_map('intval', explode('/', $cv_gallery_aspect));
                $_gal_w = 400;
                $_gal_h = ( count($_gal_ar_parts) === 2 && $_gal_ar_parts[0] > 0 ) ? (int) round( 400 * $_gal_ar_parts[1] / $_gal_ar_parts[0] ) : 300;
                ?>
                <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($_gal_caption); ?>" loading="lazy" width="<?php echo $_gal_w; ?>" height="<?php echo $_gal_h; ?>">
                <?php if ($cv_gallery_captions): ?><div class="vs-gallery-caption"><?php echo esc_html($_gal_caption); ?></div><?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $primary = $context['primary'] ?? null;
        $gallery = $primary->gallery ?? [];
        $cd = $context['cd'] ?? [];
        $gallery_sec_title = ! empty( $primary->gallery_title ?? null ) ? $primary->gallery_title : 'Photo Gallery';

        $_px = fn( $v, $def ) => $v !== null ? (int) $v : $def;
        $_wpx = fn( $v, $def ) => $v !== null ? (int) $v : $def;
        $_fit_v = fn( $v, $def ) => in_array( $v, ['cover','contain','fill'], true ) ? $v : $def;

        $out = self::render_title( $gallery_sec_title );
        $out .= self::render_filters( $gallery );
        $out .= self::render_grid(
            $primary, $gallery,
            $_px( $cd['gallery_img_height'] ?? null, 240 ),
            $_wpx( $cd['gallery_img_width'] ?? null, 0 ),
            $_fit_v( $cd['gallery_img_fit'] ?? null, 'cover' ),
            ( $cd['gallery_lightbox'] ?? 1 ) ? true : false,
            ( $cd['gallery_captions'] ?? 0 ) ? true : false,
            $cd['gallery_aspect'] ?? '4/3'
        );
        return $out;
    }
}
