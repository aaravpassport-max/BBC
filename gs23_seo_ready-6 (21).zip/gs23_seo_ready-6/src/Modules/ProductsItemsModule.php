<?php
namespace GoodService\Modules;

/**
 * ProductsItemsModule — Phase 2 of the modular listing architecture
 * roadmap.
 *
 * Faithful extraction of 'items_title' and 'items_grid'. No logic
 * changes. `items_data` and `products_data` are both in the global
 * decode loop's `$json_fields` list — checked before writing anything,
 * per Section 6.9 — so `$all_items` (computed once, early in
 * vendor-site.php, from whichever of those two fields has content) is
 * always a real array by the time it reaches this module.
 *
 * `$all_items` itself is NOT recomputed here — it's a precomputed
 * value passed in exactly as the original captures it via `use
 * ($all_items, ...)`. Reproducing its derivation (item_type/legacy
 * products_data fallback logic) is out of scope for this migration;
 * this module receives the final, ready-to-render list, matching how
 * every other precomputed value ($primary, $cd, $hd) is already
 * handled by every prior module.
 *
 * The original callback's own comment notes a "Services closure-scope
 * bug" was found and fixed in an earlier pass by carefully auditing
 * exactly which outer variables the card-renderer closure needs
 * (`$items_qbtn_inline, $cd, $primary` only) — the same discipline is
 * applied here: every parameter below was individually traced back to
 * an actual reference inside render_card(), not assumed by pattern-
 * matching against ServicesModule's parameter list.
 */
class ProductsItemsModule {

    public static function render_title( string $items_title_raw, array $hd ): string {
        $title = $hd['items_section_title'] ?? $items_title_raw;
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($title); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render_card( array $item, string $items_qbtn_inline, array $cd, $primary ): string {
        $iname  = $item['item_title'] ?? $item['name'] ?? ''; if (!$iname) return '';
        $iimg   = $item['item_image']    ?? $item['image']       ?? '';
        $iprice = $item['item_price']    ?? $item['price']       ?? '';
        $idesc  = $item['item_description'] ?? $item['description'] ?? '';
        $itype  = $item['item_type']     ?? 'service';
        $iquote = (bool)($item['show_quote_button'] ?? false);
        $icat   = $item['item_category'] ?? $item['category'] ?? '';
        $desc_is_list = false;
        $desc_lines   = [];
        if ($idesc) {
            $lines = array_filter(array_map('trim', explode("\n", $idesc)));
            $list_lines = array_filter($lines, fn($l) => preg_match('/^[-*•]\s+/', $l));
            if (count($list_lines) >= 2 && count($list_lines) >= count($lines) * 0.6) {
                $desc_is_list = true;
                $desc_lines   = array_map(fn($l) => preg_replace('/^[-*•]\s+/', '', $l), $lines);
            }
        }
        $_item_structured_sections = [];
        $_item_key_features = is_array( $item['key_features'] ?? null ) ? $item['key_features'] : array_filter( array_map( 'trim', explode( "\n", $item['key_features'] ?? '' ) ) );
        if ( ! empty( $_item_key_features ) ) {
            $_item_structured_sections[] = [ '_field' => 'key_features', 'content_type' => 'list', 'title' => \gs_vs_field_label( $cd, 'products', 'step1_features_label', 'Key Features' ), 'icon' => '✨', 'list_items' => array_values( $_item_key_features ) ];
        }
        if ( ! empty( $item['full_description'] ) ) {
            $_item_structured_sections[] = [ '_field' => 'full_description', 'content_type' => 'richtext', 'title' => \gs_vs_field_label( $cd, 'products', 'field_full_description_label', 'About this item' ), 'icon' => '📝', 'body' => esc_html( $item['full_description'] ) ];
        }
        $_item_has_vms = !empty($item['view_more_sections']);
        $_item_show_reviews = ( $cd['items_show_reviews'] ?? 1 ) ? true : false;
        $_item_custom_sections = $_item_has_vms
            ? ( is_string( $item['view_more_sections'] ) ? ( json_decode( $item['view_more_sections'], true ) ?: [] ) : $item['view_more_sections'] )
            : [];
        $_item_sections = array_merge( $_item_structured_sections, $_item_custom_sections );
        if ( ! empty( $_item_structured_sections ) ) { $_item_has_vms = true; }
        if ( $_item_show_reviews && ! empty( $primary->id ) ) {
            $_item_sections[] = [ 'content_type' => 'reviews', 'title' => 'Client Reviews', 'icon' => '⭐', 'listing_id' => (int) $primary->id ];
            $_item_has_vms = true;
        }
        ob_start();
        ?>
        <div class="vs-item-card"<?php if ($_item_has_vms): ?> style="cursor:pointer" onclick="vsOpenDetailPopup(event,this)"
              data-title="<?php echo esc_attr($iname); ?>" data-availability="<?php echo esc_attr($item['availability']??''); ?>" data-delivery="<?php echo esc_attr($item['delivery_info']??''); ?>"
              data-image="<?php echo esc_attr($iimg ?: ''); ?>"
              data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $item['additional_images'] ?? null ) ? $item['additional_images'] : [] ) ) ) ); ?>"
              data-img-fit="<?php echo esc_attr( in_array( $cd['items_popup_img_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $cd['items_popup_img_fit'] ?? 'cover' ) : 'cover' ); ?>"
                       data-slider-interval="<?php echo esc_attr( (int) ( ( (float) ( $cd['items_slider_interval'] ?? 0 ) ) * 1000 ) ); ?>"
              data-price="<?php echo esc_attr($iprice ?: ''); ?>"
              data-item-type="<?php echo esc_attr($itype); ?>"
              data-sections="<?php echo esc_attr( wp_json_encode( $_item_sections ) ); ?>"<?php endif; ?>>
            <!-- Image section with padding -->
            <div class="vs-item-img-wrap">
                <span class="vs-item-badge"><?php echo esc_html(ucfirst($itype)); ?></span>
                <?php if ($iimg): ?>
                <div class="vs-img-clip">
                  <img src="<?php echo esc_url($iimg); ?>" alt="<?php echo esc_attr($iname); ?>" loading="lazy" width="400" height="300">
                </div>
                <?php else: ?>
                <div class="vs-item-img-placeholder">
                    <?php echo $itype === 'product' ? '📦' : '🛠️'; ?>
                </div>
                <?php endif; ?>
            </div>
            <!-- Card body -->
            <div class="vs-item-body">
                <?php if ($icat): ?><div style="font-size:.7rem;font-weight:700;color:var(--vs-primary,#2563EB);text-transform:uppercase;letter-spacing:.08em;margin-bottom:2px"><?php echo esc_html($icat); ?></div><?php endif; ?>
                <div class="vs-item-title"><?php echo esc_html($iname); ?></div>
                <?php if ($idesc): ?>
                    <?php if ($desc_is_list && !empty($desc_lines)): ?>
                    <ul class="vs-item-desc-list">
                        <?php foreach (array_slice($desc_lines, 0, 5) as $dl): ?>
                        <li><?php echo esc_html($dl); ?></li>
                        <?php endforeach; ?>
                        <?php if (count($desc_lines) > 5): ?><li style="color:#647388">+<?php echo count($desc_lines)-5; ?> more…</li><?php endif; ?>
                    </ul>
                    <?php else: ?>
                    <p class="vs-item-desc"><?php echo esc_html(mb_strimwidth($idesc, 0, 120, '…')); ?></p>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if ($_item_has_vms): ?>
                    <a href="#" class="vs-view-more-link" onclick="event.stopPropagation();vsOpenDetailPopup(event,this)"
                       data-title="<?php echo esc_attr($iname); ?>" data-availability="<?php echo esc_attr($item['availability']??''); ?>" data-delivery="<?php echo esc_attr($item['delivery_info']??''); ?>"
                       data-image="<?php echo esc_attr($iimg ?: ''); ?>"
                       data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $item['additional_images'] ?? null ) ? $item['additional_images'] : [] ) ) ) ); ?>"
                       data-img-fit="<?php echo esc_attr( in_array( $cd['items_popup_img_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $cd['items_popup_img_fit'] ?? 'cover' ) : 'cover' ); ?>"
                       data-slider-interval="<?php echo esc_attr( (int) ( ( (float) ( $cd['items_slider_interval'] ?? 0 ) ) * 1000 ) ); ?>"
                       data-price="<?php echo esc_attr($iprice ?: ''); ?>"
                       data-item-type="<?php echo esc_attr($itype); ?>"
                       data-sections="<?php echo esc_attr( wp_json_encode( $_item_sections ) ); ?>">View More →</a>
                <?php endif; ?>
                <!-- Footer: price + CTA -->
                <?php if ($iprice || $itype === 'product' || $iquote || !empty($item['item_price'])): ?>
                <div class="vs-item-footer">
                    <?php if ($iprice): ?>
                    <div class="vs-item-price"><?php echo esc_html($iprice); ?></div>
                    <?php else: ?><div></div><?php endif; ?>
                    <?php if ($itype === 'product' || $iquote || !empty($item['item_price'])): ?>
                    <button onclick="event.stopPropagation();<?php
                        $_item_extra_product = wp_json_encode( ['full_description'=>$item['full_description']??'','availability'=>$item['availability']??'','delivery_info'=>$item['delivery_info']??'','key_features'=>array_values(is_array($item['key_features']??null)?$item['key_features']:array_filter(array_map('trim',explode(chr(10),$item['key_features']??''))))] );
                        $_item_extra_service = wp_json_encode( ['full_description'=>$item['full_description']??'','duration'=>$item['delivery_info']??'','highlights'=>array_values(is_array($item['key_features']??null)?$item['key_features']:array_filter(array_map('trim',explode(chr(10),$item['key_features']??''))))] );
                        echo $itype === 'product'
                            ? "vsOpenQuote('" . esc_js($iname) . "','" . esc_js($iprice) . "','" . esc_js($_item_extra_product) . "')"
                            : "vsOpenSvcEnquiry('" . esc_js($iname) . "','" . esc_js($iprice) . "','" . esc_js($_item_extra_service) . "')";
                    ?>"
                            class="vs-item-quote-btn" style="<?php echo esc_attr($items_qbtn_inline); ?>">
                        ✉ Send Inquiry
                    </button>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <?php
            if ( ! empty( $item['view_more_sections'] ) ) {
                $_item_popup_text = \GoodService\SEO\SeoContentExtractor::extract_view_more_text( $item['view_more_sections'] );
                if ( $_item_popup_text !== '' ) {
                    echo '<div class="vs-sr-only">' . esc_html( $_item_popup_text ) . '</div>';
                }
            }
            ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function render_grid(
        array $all_items, $primary, array $cd, string $items_qbtn_inline,
        int $cv_items_grid_cols, int $cv_items_max_rows
    ): string {
        if ( empty( $all_items ) ) { return ''; }

        $_items_render_list = $all_items;
        if ( $cv_items_max_rows > 0 ) {
            $_items_render_list = array_slice( $_items_render_list, 0, $cv_items_grid_cols * $cv_items_max_rows );
        }

        $_item_cats = is_array( $primary->product_categories ?? null ) ? $primary->product_categories : [];
        $_item_cat_ids_used = [];
        foreach ( $_items_render_list as $_it ) {
            if ( ! empty( $_it['category_id'] ) ) { $_item_cat_ids_used[ $_it['category_id'] ] = true; }
        }
        $_item_cats_active = array_values( array_filter( $_item_cats, fn( $c ) => isset( $_item_cat_ids_used[ $c['id'] ?? null ] ) ) );
        $_item_is_categorized = ! empty( $_item_cats_active );

        $render_card = fn( $item ) => self::render_card( $item, $items_qbtn_inline, $cd, $primary );

        ob_start();

        if ( ! $_item_is_categorized ) {
        ?>
        <div class="vs-items-grid">
            <?php foreach ($_items_render_list as $item) { echo $render_card($item); } ?>
        </div>
        <?php
        } else {
            foreach ( $_item_cats_active as $_cat ) {
                $_cat_items = array_filter( $_items_render_list, fn( $it ) => ( $it['category_id'] ?? '' ) === $_cat['id'] );
                if ( empty( $_cat_items ) ) continue;
            ?>
            <div class="vs-svc-cat-heading"><?php echo esc_html( $_cat['name'] ); ?></div>
            <div class="vs-items-grid" style="margin-bottom:28px">
                <?php foreach ( $_cat_items as $item ) { echo $render_card($item); } ?>
            </div>
            <?php
            }
            $_item_uncat = array_filter( $_items_render_list, function( $it ) use ( $_item_cats ) {
                $cid = $it['category_id'] ?? '';
                if ( $cid === '' ) return true;
                return ! in_array( $cid, array_column( $_item_cats, 'id' ), true );
            } );
            if ( ! empty( $_item_uncat ) ) {
            ?>
            <div class="vs-items-grid">
                <?php foreach ( $_item_uncat as $item ) { echo $render_card($item); } ?>
            </div>
            <?php
            }
        }
    ?>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $primary = $context['primary'] ?? null;
        $hd = $context['hd'] ?? [];
        $cd = $context['cd'] ?? [];
        $all_items = $context['all_items'] ?? [];
        $items_qbtn_inline = $context['items_qbtn_inline'] ?? '';
        $out = self::render_title( $context['items_title_raw'] ?? '', $hd );
        $out .= self::render_grid(
            $all_items, $primary, $cd, $items_qbtn_inline,
            max( 1, min( 6, (int) ( $cd['items_grid_cols'] ?? 3 ) ) ),
            max( 0, min( 10, (int) ( $cd['items_max_rows'] ?? 0 ) ) )
        );
        return $out;
    }
}
