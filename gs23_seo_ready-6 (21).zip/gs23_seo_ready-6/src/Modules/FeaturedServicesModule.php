<?php
namespace GoodService\Modules;

/**
 * FeaturedServicesModule — Health & Wellness, module 1 of 5. The
 * primary healthcare service discovery system, owning the real
 * service/treatment data every other module in this category reads
 * from (Departments' own service counts, a service's related doctor).
 *
 * Reuses three established platform mechanisms rather than building
 * new ones: the shared detail popup (vsOpenDetailPopup) for the
 * service detail view, the existing simple inquiry flow
 * (vsOpenInquiry) for "Book Appointment"/"Request Consultation", and
 * the platform's own existing tel:/wa.me CTA pattern for "Call
 * Clinic"/"WhatsApp Clinic" — using the vendor's own already-saved
 * phone/WhatsApp number, never asking for it again per service.
 *
 * Medical safety, by construction not by filtering: every text field
 * a service can carry (description, patient information, aftercare)
 * is rendered exactly as the vendor typed it — there is no synthesis,
 * paraphrasing, or auto-generated claim anywhere in this class.
 */
class FeaturedServicesModule {

    public const LAYOUTS = [
        'featured'    => 'Featured Treatment',
        'directory'   => 'Service Directory',
        'image_led'   => 'Image-Led Services',
        'departments' => 'Department-Based',
    ];

    public static function render_title( string $title = 'Our Services & Treatments', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-hw-sec-head">
        <div class="vs-hw-eyebrow">Care We Provide</div>
        <h2 class="vs-sec-title vs-hw-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-hw-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Builds the service detail popup's content — reuses the
     * platform's own established, shared vsOpenDetailPopup component
     * (already used by Packages, Room Types, and every Real Estate and
     * Interior Designers module) rather than a new detail system.
     */
    private static function build_detail_sections( array $service, array $doctors ): array {
        $sections = [];
        if ( ! empty( $service['detailed_description'] ) ) {
            $sections[] = [ 'content_type' => 'richtext', 'title' => 'About This Service', 'icon' => '📋', 'body' => esc_html( $service['detailed_description'] ) ];
        }
        $patient_info = [];
        if ( ! empty( $service['who_its_for'] ) ) { $patient_info[] = 'Who it\'s for: ' . $service['who_its_for']; }
        if ( ! empty( $service['common_reasons'] ) ) { $patient_info[] = 'Common reasons for consultation: ' . $service['common_reasons']; }
        if ( ! empty( $service['what_it_involves'] ) ) { $patient_info[] = 'What it involves: ' . $service['what_it_involves']; }
        if ( ! empty( $service['appointment_duration'] ) ) { $patient_info[] = 'Typical duration: ' . $service['appointment_duration']; }
        if ( ! empty( $patient_info ) ) {
            $sections[] = [ 'content_type' => 'list', 'title' => 'What to Expect', 'icon' => 'ℹ️', 'list_items' => $patient_info ];
        }
        if ( ! empty( $service['preparation'] ) ) {
            $sections[] = [ 'content_type' => 'richtext', 'title' => 'Preparation', 'icon' => '📝', 'body' => esc_html( $service['preparation'] ) ];
        }
        if ( ! empty( $service['aftercare'] ) ) {
            $sections[] = [ 'content_type' => 'richtext', 'title' => 'Aftercare', 'icon' => '🩹', 'body' => esc_html( $service['aftercare'] ) ];
        }
        $matched_doctors = HealthWellnessModule::get_doctors_for_service( $doctors, $service );
        if ( ! empty( $matched_doctors ) ) {
            $doctor_names = array_column( $matched_doctors, 'name' );
            $sections[] = [ 'content_type' => 'list', 'title' => 'Available With', 'icon' => '🩺', 'list_items' => $doctor_names ];
        }
        // Real feature — "Related FAQs" from the request, built via
        // the same Manage Details popup builder every other section
        // uses for optional, add-as-needed per-item content, rather
        // than a separate FAQ system duplicating the platform's
        // existing site-wide FaqModule.
        $custom_vms = is_string( $service['view_more_sections'] ?? null )
            ? ( json_decode( $service['view_more_sections'], true ) ?: [] )
            : ( $service['view_more_sections'] ?? [] );
        if ( is_array( $custom_vms ) ) {
            foreach ( $custom_vms as $_vms ) { if ( is_array( $_vms ) ) { $sections[] = $_vms; } }
        }
        return $sections;
    }

    /**
     * @param array $img_display  fit/position/zoom — shared, global
     *              gs_vs_img_display_style() helper.
     * @param string $phone       Vendor's own saved phone number.
     * @param string $wa_clean    Vendor's own saved WhatsApp number,
     *              digits only.
     */
    public static function render_grid( array $services, string $layout = 'directory', array $doctors = [], array $img_display = [], string $phone = '', string $wa_clean = '' ): string {
        $services = array_values( array_filter( $services, fn( $s ) => ! empty( $s['name'] ) ) );
        if ( empty( $services ) ) { return ''; }
        $layout = in_array( $layout, array_keys( self::LAYOUTS ), true ) ? $layout : 'directory';
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        $currency = \gs_setting( 'currency_symbol', '₹' );

        // Department-Based layout groups services by department first.
        $grouped = [ '' => $services ];
        if ( $layout === 'departments' ) {
            $grouped = [];
            foreach ( $services as $s ) {
                $dept = ! empty( $s['department'] ) ? $s['department'] : 'Other Services';
                $grouped[ $dept ][] = $s;
            }
        }

        ob_start();
        ?>
    <div class="vs-hw-services vs-hw-layout-<?php echo esc_attr( $layout ); ?>">
        <?php foreach ( $grouped as $_dept_name => $_dept_services ): ?>
        <?php if ( $layout === 'departments' && $_dept_name !== '' ): ?><div class="vs-hw-dept-group-label"><?php echo esc_html( $_dept_name ); ?></div><?php endif; ?>
        <div class="vs-hw-services-inner">
        <?php foreach ( $_dept_services as $_si => $service ):
            $is_featured = ( $_si === 0 && $layout === 'featured' ) || ! empty( $service['is_featured'] );
            $detail_sections = self::build_detail_sections( $service, $doctors );
            $price_display = '';
            if ( ! empty( $service['price_label'] ) ) { $price_display = $service['price_label']; }
            elseif ( ! empty( $service['starting_price'] ) ) { $price_display = 'From ' . $currency . $service['starting_price']; }
            elseif ( ! empty( $service['consultation_fee'] ) ) { $price_display = $currency . $service['consultation_fee'] . ' consultation'; }
        ?>
        <div class="vs-hw-service-card<?php echo $is_featured ? ' vs-hw-service-featured' : ''; ?>">
            <?php if ( $layout !== 'directory' && ! empty( $service['image'] ) ): ?>
            <div class="vs-hw-service-media">
                <img src="<?php echo esc_url( $service['image'] ); ?>" alt="<?php echo esc_attr( $service['name'] ); ?>" class="vs-hw-service-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
            </div>
            <?php endif; ?>
            <div class="vs-hw-service-body">
                <?php if ( ! empty( $service['icon'] ) ): ?><div class="vs-hw-service-icon"><?php echo esc_html( $service['icon'] ); ?></div><?php endif; ?>
                <div class="vs-hw-service-name"><?php echo esc_html( $service['name'] ); ?></div>
                <?php if ( $layout !== 'image_led' && ! empty( $service['short_description'] ) ): ?><p class="vs-hw-service-desc"><?php echo esc_html( $service['short_description'] ); ?></p><?php endif; ?>
                <div class="vs-hw-service-meta">
                    <?php if ( $layout !== 'departments' && ! empty( $service['department'] ) ): ?><span class="vs-hw-service-dept"><?php echo esc_html( $service['department'] ); ?></span><?php endif; ?>
                    <?php if ( $price_display !== '' ): ?><span class="vs-hw-service-price"><?php echo esc_html( $price_display ); ?></span><?php endif; ?>
                </div>
                <?php if ( ! empty( $service['online_consultation'] ) || ! empty( $service['in_clinic_consultation'] ) ): ?>
                <div class="vs-hw-service-modes">
                    <?php if ( ! empty( $service['in_clinic_consultation'] ) ): ?><span>🏥 In-Clinic</span><?php endif; ?>
                    <?php if ( ! empty( $service['online_consultation'] ) ): ?><span>💻 Online</span><?php endif; ?>
                </div>
                <?php endif; ?>
                <div class="vs-hw-service-ctas">
                    <a href="#" class="vs-hw-cta-primary"
                       data-title="<?php echo esc_attr( $service['name'] ); ?>"
                       data-image="<?php echo esc_attr( $service['image'] ?? '' ); ?>"
                       data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $service['additional_images'] ?? null ) ? $service['additional_images'] : [] ) ) ) ); ?>"
                       data-img-fit="<?php echo esc_attr( in_array( $img_display['popup_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $img_display['popup_fit'] ?? 'cover' ) : 'cover' ); ?>"
                   data-slider-interval="<?php echo esc_attr( (int) ( $img_display['interval'] ?? 0 ) ); ?>"
                       data-price="<?php echo esc_attr( $price_display ); ?>"
                       data-sections="<?php echo esc_attr( wp_json_encode( $detail_sections ) ); ?>"
                       onclick="event.preventDefault();vsOpenDetailPopup(event,this)"><?php echo esc_html( ! empty( $service['booking_cta'] ) ? $service['booking_cta'] : 'View Details' ); ?></a>
                    <?php if ( ! empty( $service['appointment_available'] ) ): ?>
                    <a href="#" class="vs-hw-cta-secondary" onclick="event.preventDefault();vsOpenInquiry({name:'<?php echo esc_js( $service['name'] ); ?>',type:'service',price:'<?php echo esc_js( $price_display ); ?>'})"><?php echo esc_html( ! empty( $service['enquiry_cta'] ) ? $service['enquiry_cta'] : 'Request Consultation' ); ?></a>
                    <?php endif; ?>
                    <?php if ( $phone !== '' ): ?><a href="tel:<?php echo esc_attr( $phone ); ?>" class="vs-hw-cta-icon" title="Call Clinic" aria-label="Call Clinic about <?php echo esc_attr( $service['name'] ); ?>">📞</a><?php endif; ?>
                    <?php if ( $wa_clean !== '' ): ?><a href="https://wa.me/<?php echo esc_attr( $wa_clean ); ?>?text=<?php echo esc_attr( rawurlencode( 'Hi, I\'d like to know more about ' . $service['name'] ) ); ?>" target="_blank" rel="noopener" class="vs-hw-cta-icon" title="WhatsApp Clinic" aria-label="WhatsApp Clinic about <?php echo esc_attr( $service['name'] ); ?>">💬</a><?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $services
     *     @type array  $doctors
     *     @type string $layout
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     *     @type string $phone
     *     @type string $wa_clean
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid(
            $context['services'] ?? [],
            $context['layout'] ?? 'directory',
            $context['doctors'] ?? [],
            (array) ( $context['img_display'] ?? [] ),
            (string) ( $context['phone'] ?? '' ),
            (string) ( $context['wa_clean'] ?? '' )
        );
        if ( $html === '' ) { return ''; } // Real feature — empty-state requirement.
        return self::render_title( $context['section_title'] ?? 'Our Services & Treatments', $context['section_description'] ?? '' ) . $html;
    }
}
