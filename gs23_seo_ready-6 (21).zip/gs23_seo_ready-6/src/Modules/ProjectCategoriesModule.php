<?php
namespace GoodService\Modules;

/**
 * ProjectCategoriesModule — Interior Designers & Architects, module 2
 * of 5. Answers "what kind of projects do you handle?", distinct from
 * Featured Projects' "show me your best work."
 *
 * Unlike PropertyTypesModule (which used a fixed, code-defined
 * taxonomy), the request explicitly requires vendor-defined,
 * addable/removable/reorderable categories — a real repeater of
 * category definitions (name, description, cover image, icon, CTA
 * text), not an enum. Each category's real project count is computed
 * fresh from ProjectsModule::get_category_counts() — matching that
 * category definition's own 'name' against each project's own
 * free-text 'category' field — never manually entered, per the
 * request's own explicit "the vendor should not have to manually
 * enter project counts" requirement.
 *
 * Independent of Featured Projects' own activation, same pattern as
 * every cross-referencing module this session: reads project data
 * directly via ProjectsModule::get_projects(), never checks
 * $_sec_show('featured_projects') or that module's assignment state.
 */
class ProjectCategoriesModule {

    /**
     * @param array $category_defs  Vendor-managed repeater: each entry
     *              {name, description, cover_image, icon, cta_text}.
     * @param array $projects       Already resolved via ProjectsModule::get_projects().
     * @return array  Each category_def entry enriched with a real 'count'.
     */
    public static function with_counts( array $category_defs, array $projects ): array {
        $counts = ProjectsModule::get_category_counts( $projects );
        $by_name = [];
        foreach ( $projects as $p ) { if ( ! empty( $p['name'] ) ) { $by_name[ $p['name'] ] = $p; } }
        $enriched = [];
        foreach ( $category_defs as $def ) {
            if ( empty( $def['name'] ) ) { continue; }
            $def['count'] = $counts[ $def['name'] ] ?? 0;
            // Real feature — fixes a confirmed gap: "Featured Project"
            // per category is resolved here into the actual project's
            // data (not left as an unused name string), so it can
            // provide a real cover-image fallback and be shown as a
            // genuine reference on the category tile.
            $def['featured_project_data'] = ( ! empty( $def['featured_project'] ) && isset( $by_name[ $def['featured_project'] ] ) )
                ? $by_name[ $def['featured_project'] ]
                : null;
            $enriched[] = $def;
        }
        return $enriched;
    }

    public static function render_title( string $title = 'Project Categories', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-ida-sec-head">
        <div class="vs-ida-eyebrow">Specialization</div>
        <h2 class="vs-sec-title vs-ida-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-ida-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $categories  Already enriched via with_counts().
     * @param bool  $hide_empty  When true (the sensible default), a
     *              category with zero matching projects is not shown
     *              at all — a vendor-defined category the vendor
     *              hasn't yet assigned any project to should not
     *              appear as a dead link.
     */
    public static function render_grid( array $categories, array $img_display = [], int $grid_cols = 3, bool $hide_empty = true ): string {
        if ( $hide_empty ) {
            $categories = array_values( array_filter( $categories, fn( $c ) => ( $c['count'] ?? 0 ) > 0 ) );
        }
        if ( empty( $categories ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        ob_start();
        ?>
    <div class="vs-ida-cat-grid" style="--vs-ida-cat-cols:<?php echo (int) $grid_cols; ?>">
        <?php foreach ( $categories as $cat ):
            $count = (int) ( $cat['count'] ?? 0 );
            $cta = ! empty( $cat['cta_text'] ) ? $cat['cta_text'] : 'View Projects';
            // Real feature — fixes a confirmed gap: falls back to the
            // Featured Project's own cover image when the category
            // itself has none set, rather than leaving
            // featured_project as an unused, disconnected field.
            $_display_img = $cat['cover_image'] ?? '';
            if ( $_display_img === '' && ! empty( $cat['featured_project_data']['cover_image'] ) ) {
                $_display_img = $cat['featured_project_data']['cover_image'];
            }
        ?>
        <div class="vs-ida-cat-tile" onclick="vsIdaFilterProjectsByCategory('<?php echo esc_js( $cat['name'] ); ?>')">
            <?php if ( $_display_img !== '' ): ?>
                <img src="<?php echo esc_url( $_display_img ); ?>" alt="<?php echo esc_attr( $cat['name'] ); ?>" class="vs-ida-cat-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
            <?php else: ?>
                <div class="vs-ida-cat-img-placeholder"><?php echo esc_html( $cat['icon'] ?? '🏛️' ); ?></div>
            <?php endif; ?>
            <div class="vs-ida-cat-overlay">
                <div class="vs-ida-cat-name"><?php echo esc_html( $cat['name'] ); ?></div>
                <div class="vs-ida-cat-count"><?php echo $count; ?> Project<?php echo $count === 1 ? '' : 's'; ?></div>
                <?php if ( ! empty( $cat['description'] ) ): ?><div class="vs-ida-cat-desc"><?php echo esc_html( $cat['description'] ); ?></div><?php endif; ?>
                <?php if ( ! empty( $cat['featured_project_data']['name'] ) ): ?><div class="vs-ida-cat-featured">★ Featured: <?php echo esc_html( $cat['featured_project_data']['name'] ); ?></div><?php endif; ?>
                <div class="vs-ida-cat-cta"><?php echo esc_html( $cta ); ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $category_defs  Vendor-managed repeater, raw (unenriched).
     *     @type array  $projects       ALL projects, unfiltered.
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     *     @type int    $grid_cols
     * }
     */
    public static function render( array $context ): string {
        $enriched = self::with_counts( $context['category_defs'] ?? [], $context['projects'] ?? [] );
        $grid = self::render_grid( $enriched, (array) ( $context['img_display'] ?? [] ), (int) ( $context['grid_cols'] ?? 3 ) );
        if ( $grid === '' ) { return ''; } // Real feature — empty-state requirement.
        return self::render_title( $context['section_title'] ?? 'Project Categories', $context['section_description'] ?? '' ) . $grid;
    }
}
