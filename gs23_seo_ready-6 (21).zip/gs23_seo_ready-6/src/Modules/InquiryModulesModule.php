<?php
namespace GoodService\Modules;

/**
 * InquiryModulesModule — Phase 2 of the modular listing architecture
 * roadmap.
 *
 * GENUINELY DIFFERENT APPROACH FROM EVERY OTHER MODULE, and deliberately
 * so — documented here rather than silently deviating from the
 * established pattern without explanation.
 *
 * This section is not `$_el_capture`-based (like Trust Bar), and unlike
 * every other section, its entire render logic — HTML, its own
 * self-contained `<style>` block, and 5 `<script>` blocks powering a
 * 4-step booking wizard — lives in a separate 1495-line partial file
 * (`templates/pages/partials/inquiry-modules.php`), not inline in
 * vendor-site.php. It includes vendor lookup queries, a global-vs-
 * per-listing customizer resolution cascade, and dynamic field
 * rendering via a second shared partial
 * (`inquiry-field-renderer.php`).
 *
 * Manually re-transcribing 1495 lines of this complexity by hand (the
 * approach used for every other module) would carry meaningfully
 * higher risk of introducing a subtle transcription bug — a single
 * mistyped variable in a booking-wizard step or a vendor-profile query
 * — than every other module built this session, for very little
 * benefit: unlike ServicesModule or ProductsItemsModule, there's no
 * closure-scope bug to fix here and no reason to touch the internal
 * logic at all.
 *
 * Instead, this module wraps the SAME, unmodified partial file via a
 * plain PHP `include` inside render() — the exact same file, executing
 * exactly the same code, with zero transcription risk, while still
 * satisfying the `render(array $context): string` contract every other
 * module implements (for ModuleRegistry/Phase 3b consistency). Every
 * variable the partial reads from its calling scope was identified by
 * a full read-vs-assigned scan of the file, not assumed:
 * `$_inq_modules_data`, `$cd`, `$primary`, `$brand_color`, `$lid`.
 *
 * One real, minor, pre-existing bug NOTED (not fixed, since this
 * wrapper deliberately does not touch the partial's internal logic —
 * fixing it would require editing the 1495-line file itself, a
 * separate, larger task): `$_cat` is read once, at the "no CTA button
 * label configured" fallback (`!empty($_cat['ctas'][0]) ? ... :
 * 'Get a Free Callback'`), but is never assigned anywhere in the
 * entire file — confirmed via a full read-vs-assigned variable scan.
 * The fallback text always shows; a category-specific CTA was
 * evidently intended here but never wired up. Because this module
 * includes the real, unmodified file, this bug is automatically and
 * exactly preserved — there was nothing to "accidentally fix" by
 * transcribing it, which is one more argument for this approach.
 */
class InquiryModulesModule {

    /**
     * @param array $context {
     *     @type array    $inq_modules_data  Resolved inquiry module
     *                     configs (from $_inq_modules_data).
     *     @type array    $cd                Customizer data.
     *     @type mixed    $primary           The listing object.
     *     @type string   $brand_color       Brand color, defaults to
     *                     '#2563EB' exactly as the original does.
     *     @type int      $lid               Listing ID.
     * }
     */
    public static function render( array $context ): string {
        $_inq_modules_data = $context['inq_modules_data'] ?? [];
        if ( empty( $_inq_modules_data ) ) { return ''; }

        $cd = $context['cd'] ?? [];
        $primary = $context['primary'] ?? null;
        $brand_color = $context['brand_color'] ?? '#2563EB';
        $lid = $context['lid'] ?? 0;

        ob_start();
        include GS_DIR . 'templates/pages/partials/inquiry-modules.php';
        return ob_get_clean();
    }
}
