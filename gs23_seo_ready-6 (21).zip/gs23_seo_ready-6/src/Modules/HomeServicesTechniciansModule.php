<?php
namespace GoodService\Modules;

/**
 * HomeServicesTechniciansModule — Home Services, Module 3:
 * "Technicians & Experts" (custom build spec Section 04). Structurally
 * mirrors BeautyExpertsModule's established pattern exactly (same
 * card shape, same zero-data discipline: experience, rating,
 * languages and the verification badge are only ever shown when the
 * vendor actually entered them — never computed, inferred, or
 * defaulted to a plausible-looking value).
 *
 * One deliberate, spec-driven addition beyond BeautyExpertsModule:
 * `background_verified` — a distinct trust signal from the generic
 * "Verified" badge, because a home-services technician is someone the
 * customer lets into their home (the custom build spec's Section 05
 * "Trust & Why Choose Us" calls out background/ID verification by
 * name as a category-specific trust signal, unlike a salon expert).
 * Still vendor-entered only, still never inferred, still per-
 * technician rather than a vague vendor-wide claim.
 *
 * "Book With {Technician}" reuses the real, existing Service Booking
 * Wizard (window.vsOpenServiceWizard) with its `specialist` field,
 * exactly as BeautyExpertsModule does — no parallel booking system.
 */
class HomeServicesTechniciansModule {

    public static function get_technicians( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'home_services_technicians', $listing_id );
        return array_values( array_filter( (array) ( $data['technicians'] ?? [] ), fn( $t ) => is_array( $t ) && ! empty( $t['name'] ) ) );
    }

    public static function render_title( string $title = 'Meet Our Technicians', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-htech-sec-head">
        <div class="gs-htech-eyebrow">Trained &amp; Trusted</div>
        <h2 class="vs-sec-title gs-htech-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-htech-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    private static function first_name( string $full_name ): string {
        $parts = explode( ' ', trim( $full_name ) );
        return $parts[0] ?? $full_name;
    }

    public static function render_grid( array $technicians, array $img_display = [] ): string {
        $technicians = array_values( array_filter( $technicians, fn( $t ) => ! empty( $t['name'] ) ) );
        if ( empty( $technicians ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];

        ob_start();
        ?>
    <div class="gs-htech-grid">
        <?php foreach ( $technicians as $t ):
            $specialities = array_values( array_filter( array_map( 'trim', explode( ',', (string) ( $t['specialities'] ?? '' ) ) ) ) );
            $languages    = array_values( array_filter( array_map( 'trim', explode( ',', (string) ( $t['languages'] ?? '' ) ) ) ) );
            $rating       = trim( (string) ( $t['rating'] ?? '' ) );
            $has_rating   = $rating !== '' && is_numeric( $rating ) && (float) $rating > 0 && (float) $rating <= 5;
            $payload = [
                'name' => $t['name'], 'specialist_id' => $t['id'] ?? '', 'specialist_name' => $t['name'],
            ];
        ?>
        <div class="gs-htech-card">
            <?php if ( ! empty( $t['photo'] ) ): ?>
            <div class="gs-htech-media">
                <img src="<?php echo esc_url( $t['photo'] ); ?>" alt="<?php echo esc_attr( $t['name'] ); ?>" class="gs-htech-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php if ( ! empty( $t['verified'] ) ): ?><span class="gs-htech-verified" title="Verified">✓ Verified</span><?php endif; ?>
            </div>
            <?php endif; ?>
            <div class="gs-htech-body">
                <div class="gs-htech-name"><?php echo esc_html( $t['name'] ); ?></div>
                <?php if ( ! empty( $t['designation'] ) ): ?><div class="gs-htech-role"><?php echo esc_html( $t['designation'] ); ?></div><?php endif; ?>
                <?php if ( $has_rating ): ?><div class="gs-htech-rating">★ <?php echo esc_html( number_format( (float) $rating, 1 ) ); ?></div><?php endif; ?>
                <?php if ( ! empty( $t['background_verified'] ) ): ?><div class="gs-htech-bg-badge">🛡️ Background Verified</div><?php endif; ?>
                <?php if ( ! empty( $specialities ) ): ?>
                <div class="gs-htech-tags">
                    <?php foreach ( $specialities as $sp ): ?><span class="gs-htech-tag"><?php echo esc_html( $sp ); ?></span><?php endforeach; ?>
                </div>
                <?php endif; ?>
                <?php if ( ! empty( $t['bio'] ) ): ?><p class="gs-htech-bio"><?php echo esc_html( $t['bio'] ); ?></p><?php endif; ?>
                <div class="gs-htech-meta">
                    <?php if ( ! empty( $t['experience'] ) ): ?><span>💼 <?php echo esc_html( $t['experience'] ); ?></span><?php endif; ?>
                    <?php if ( ! empty( $languages ) ): ?><span>🗣️ <?php echo esc_html( implode( ', ', $languages ) ); ?></span><?php endif; ?>
                </div>
                <?php if ( ! empty( $t['bookable'] ) ): ?>
                <button type="button" class="gs-htech-book-btn" onclick='vsOpenServiceWizard({name:<?php echo wp_json_encode( "Service with " . $t['name'] ); ?>,listing_id:window.LID||0,specialist:<?php echo wp_json_encode( $payload ); ?>})'>Book with <?php echo esc_html( self::first_name( $t['name'] ) ); ?></button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $technicians
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid( $context['technicians'] ?? [], (array) ( $context['img_display'] ?? [] ) );
        if ( $html === '' ) { return ''; } // Mandatory empty-state.
        return self::render_title( $context['section_title'] ?? 'Meet Our Technicians', $context['section_description'] ?? '' ) . $html;
    }
}
