<?php
namespace GoodService\Modules;

/**
 * WarrantyModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of the existing Warranty rendering logic from
 * vendor-site.php's single $_el_capture call for 'warranty_block'.
 *
 * Genuinely different shape from every module built earlier in this
 * phase: there is no separate title/grid split, and no $cd usage at
 * all — the original callback's use() clause only references
 * ($primary, $_json_has_real_content). The "title" here is
 * $w['title'], part of the single-block data itself, not a separate
 * $cd['xxx_section_title'] customizable heading like every other
 * migrated section has. render() therefore has no title method to
 * call — this reflects a real structural difference, not an omission.
 */
class WarrantyModule {

    private static function has_real_content( $raw, string $required_key ): bool {
        if ( empty( $raw ) ) { return false; }
        $decoded = json_decode( (string) $raw, true );
        if ( ! is_array( $decoded ) ) { return false; }
        if ( array_key_exists( $required_key, $decoded ) ) {
            return ! empty( $decoded[ $required_key ] );
        }
        foreach ( $decoded as $item ) {
            if ( is_array( $item ) && ! empty( $item[ $required_key ] ?? null ) ) { return true; }
        }
        return false;
    }

    /** Faithful copy of the 'warranty_block' $_el_capture callback. */
    public static function render_block( $warranty_data_raw ): string {
        if ( ! self::has_real_content( $warranty_data_raw, 'title' ) ) { return ''; }
        $w = is_string( $warranty_data_raw ) ? ( json_decode( $warranty_data_raw, true ) ?: [] ) : $warranty_data_raw;
        if ( empty( $w['title'] ) ) { return ''; }
        $desc_lines = ! empty( $w['description'] ) ? array_values( array_filter( array_map( 'trim', explode( "\n", $w['description'] ) ) ) ) : [];
        ob_start();
        ?>
    <div class="vs-war-banner">
        <div class="vs-war-seal"><?php echo esc_html($w['icon'] ?? '🛡️'); ?></div>
        <div>
            <div class="vs-war-title"><?php echo esc_html($w['title']); ?></div>
            <?php if (!empty($w['duration'])): ?>
            <div class="vs-war-duration"><?php echo esc_html($w['duration']); ?></div>
            <?php endif; ?>
            <?php if (count($desc_lines) > 1): ?>
            <ul class="vs-war-checklist">
                <?php foreach ($desc_lines as $line): ?>
                <li><?php echo esc_html(ltrim($line, '-✓• ')); ?></li>
                <?php endforeach; ?>
            </ul>
            <?php elseif (!empty($w['description'])): ?>
            <div class="vs-war-desc-plain"><?php echo nl2br(esc_html($w['description'])); ?></div>
            <?php endif; ?>
        </div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * The module's full render output. No title-block concatenation —
     * unlike every prior module in this phase, there is only one piece
     * to render, matching the original's single $_el_capture call.
     */
    public static function render( array $context ): string {
        $warranty_data_raw = $context['module_data']['warranty_data']
            ?? ( $context['primary']->warranty_data ?? null );
        return self::render_block( $warranty_data_raw );
    }
}
