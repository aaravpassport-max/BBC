<?php
namespace GoodService\Modules;

/**
 * LanguagesModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of the existing Languages rendering logic from
 * vendor-site.php's $_el_capture calls for 'languages_title' and
 * 'languages_list'. Genuinely simpler than the modules migrated so far
 * in this phase — no image-display settings, no icon customization,
 * just a name, a fixed proficiency-level bar, and a constant globe
 * emoji. render_grid() deliberately doesn't accept $cd at all, matching
 * the original callback's exact use() clause (which never referenced it
 * either) — not an oversight.
 */
class LanguagesModule {

    private static function has_real_content( $raw, string $required_key ): bool {
        if ( empty( $raw ) ) { return false; }
        $decoded = json_decode( (string) $raw, true );
        if ( ! is_array( $decoded ) ) { return false; }
        if ( array_key_exists( $required_key, $decoded ) ) {
            return ! empty( $decoded[ $required_key ] );
        }
        foreach ( $decoded as $item ) {
            if ( is_array( $item ) && ! empty( $item[ $required_key ] ?? null ) ) { return true; }
        }
        return false;
    }

    /** Faithful copy of the 'languages_title' $_el_capture callback. */
    public static function render_title( array $cd ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['languages_section_title'] ?? 'Languages Spoken'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Faithful copy of the 'languages_list' $_el_capture callback.
     * Note the required_key is 'name' here, not 'title' — matching the
     * original exactly (languages entries use a different field name).
     */
    public static function render_grid( $languages_data_raw ): string {
        if ( ! self::has_real_content( $languages_data_raw, 'name' ) ) { return ''; }
        $items = is_string( $languages_data_raw ) ? ( json_decode( $languages_data_raw, true ) ?: [] ) : $languages_data_raw;
        $proficiency_levels = [ 'Native' => 4, 'Fluent' => 3, 'Conversational' => 2, 'Basic' => 1 ];
        ob_start();
        ?>
    <div class="vs-lang-grid">
        <?php foreach ($items as $l): if (empty($l['name'])) continue;
            $level = $l['proficiency'] ?? 'Fluent';
            $filled = $proficiency_levels[$level] ?? 3;
        ?>
        <div class="vs-lang-card">
            <div class="vs-lang-globe">🌐</div>
            <div class="vs-lang-name"><?php echo esc_html($l['name']); ?></div>
            <div class="vs-lang-bar">
                <?php for ($i = 1; $i <= 4; $i++): ?>
                <div class="vs-lang-seg<?php echo $i <= $filled ? ' filled' : ''; ?>"></div>
                <?php endfor; ?>
            </div>
            <div class="vs-lang-level"><?php echo esc_html($level); ?></div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $cd = $context['cd'] ?? [];
        $languages_data_raw = $context['module_data']['languages_data']
            ?? ( $context['primary']->languages_data ?? null );
        return self::render_title( $cd ) . self::render_grid( $languages_data_raw );
    }
}
