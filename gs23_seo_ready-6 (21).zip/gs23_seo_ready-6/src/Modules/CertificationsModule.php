<?php
namespace GoodService\Modules;

/**
 * CertificationsModule — Phase 2 of the modular listing architecture
 * roadmap.
 *
 * Faithful extraction of the existing Certifications rendering logic
 * from vendor-site.php's $_el_capture calls for 'certifications_title'
 * and 'certifications_grid'. Shares CSS classes and card structure with
 * AwardsModule but has genuinely distinct fields (credential_id,
 * verify_url) and its own badge-ring color/radius override — built as
 * a fully independent module rather than sharing a base class, per the
 * roadmap's principle that modules stay independent.
 */
class CertificationsModule {

    private static function has_real_content( $raw, string $required_key ): bool {
        if ( empty( $raw ) ) { return false; }
        $decoded = json_decode( (string) $raw, true );
        if ( ! is_array( $decoded ) ) { return false; }
        if ( array_key_exists( $required_key, $decoded ) ) {
            return ! empty( $decoded[ $required_key ] );
        }
        foreach ( $decoded as $item ) {
            if ( is_array( $item ) && ! empty( $item[ $required_key ] ?? null ) ) { return true; }
        }
        return false;
    }

    /** Faithful copy of the 'certifications_title' $_el_capture callback. */
    public static function render_title( array $cd ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['certifications_section_title'] ?? 'Licences & Certifications'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /** Faithful copy of the 'certifications_grid' $_el_capture callback. */
    public static function render_grid( $certifications_data_raw, array $cd ): string {
        if ( ! self::has_real_content( $certifications_data_raw, 'title' ) ) { return ''; }
        $items = is_string( $certifications_data_raw ) ? ( json_decode( $certifications_data_raw, true ) ?: [] ) : $certifications_data_raw;
        $_cert_img_settings = is_array( $cd['certifications_img_display'] ?? null ) ? $cd['certifications_img_display'] : [];
        $_cert_style = gs_vs_img_display_style( $_cert_img_settings );
        $_cert_size_style = ! empty( $_cert_img_settings['badge_size'] ) ? 'width:' . (int) $_cert_img_settings['badge_size'] . 'px;height:' . (int) $_cert_img_settings['badge_size'] . 'px;' : '';
        ob_start();
        ?>
    <div class="vs-awd-grid">
        <?php foreach ($items as $c): if (empty($c['title'])) continue; ?>
        <div class="vs-awd-card">
            <div class="vs-awd-badge-ring" style="border-radius:20px;background:conic-gradient(from 180deg,#DBEAFE,#BFDBFE,#DBEAFE);<?php echo esc_attr($_cert_size_style); ?>">
                <div class="vs-awd-badge" style="border-radius:16px">
                    <?php if (!empty($c['image'])): ?>
                        <img src="<?php echo esc_url($c['image']); ?>" alt="<?php echo esc_attr($c['title']); ?>" loading="lazy" width="100" height="100" style="<?php echo esc_attr($_cert_style['img']); ?>">
                    <?php else: ?>
                        <span class="vs-awd-badge-emoji">📜</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="vs-awd-title"><?php echo esc_html($c['title']); ?></div>
            <?php if (!empty($c['issuer']) || !empty($c['year'])): ?>
            <div class="vs-awd-meta"><?php echo esc_html(trim(($c['issuer'] ?? '') . (!empty($c['issuer']) && !empty($c['year']) ? ' · ' : '') . ($c['year'] ?? ''))); ?></div>
            <?php endif; ?>
            <?php if (!empty($c['description'])): ?>
            <div class="vs-awd-desc"><?php echo esc_html($c['description']); ?></div>
            <?php endif; ?>
            <?php if (!empty($c['credential_id'])): ?>
            <div class="vs-awd-credential">ID: <?php echo esc_html($c['credential_id']); ?></div>
            <?php endif; ?>
            <?php if (!empty($c['verify_url'])): ?>
            <br><a href="<?php echo esc_url($c['verify_url']); ?>" target="_blank" rel="noopener noreferrer" class="vs-awd-verify">✓ Verify Credential →</a>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $cd = $context['cd'] ?? [];
        $certifications_data_raw = $context['module_data']['certifications_data']
            ?? ( $context['primary']->certifications_data ?? null );
        return self::render_title( $cd ) . self::render_grid( $certifications_data_raw, $cd );
    }
}
