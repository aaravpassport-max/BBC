<?php
namespace GoodService\Modules;

/**
 * WeddingAvailabilityModule — Events & Wedding, Section 10 of 10:
 * "Check Availability". Investigation before building (per the same
 * discipline as Section 09/Testimonials): a real, listing-scoped
 * booking/availability schema DOES exist on this platform —
 * wp_gs_availability (weekly day-of-week hours) and wp_gs_blocked_dates
 * (specific blocked calendar dates), both wired into archive.php's
 * search-by-date filter and the vendor dashboard's own booking-manager
 * UI (see src/Database/Schema.php ~2808-2831, src/Controller/
 * AjaxController.php gs_get_availability / gs_get_blocked_dates /
 * PART 9).
 *
 * That system was deliberately NOT reused to drive a real-time
 * "is this date free" display here, for one concrete, honesty-driven
 * reason: adoption of gs_availability/gs_blocked_dates is optional and
 * built for recurring-appointment verticals (salons, clinics, repair
 * techs). A wedding vendor who has simply never opened that booking
 * manager has zero rows in either table — querying it for such a
 * vendor would report every single date as "available" not because it
 * genuinely is, but because the feature was never configured. That is
 * exactly the fabricated-state failure mode this build is required to
 * avoid: it would look like a real calendar check while actually
 * encoding "no data" as "yes, free." There is no reliable way from the
 * public vendor-site render to distinguish "verified free" from
 * "never configured" for this vertical, so no real per-date open/
 * blocked signal can be honestly shown here.
 *
 * So Section 10 is the honest fallback described in the build spec:
 * a date picker plus a "Request Availability" CTA that opens the
 * platform's real, existing lead-capture popup (window.vsOpenInquiry,
 * the same mechanism wedding_packages' "Request a Quote" CTA already
 * uses — see vendor-site.php ~6550, ~10288) with the picked date
 * folded into the enquiry's own Requirements/Message field. No
 * calendar grid, no invented open/booked day states — the vendor sets
 * nothing calendar-specific for this section at all.
 */
class WeddingAvailabilityModule {

    /**
     * @param array $context {
     *     @type array  $vendor_types
     *     @type string $section_title        vendor override; falls back to the adaptive heading when blank.
     *     @type string $section_description   vendor override; falls back to the default copy when blank.
     * }
     */
    public static function render( array $context ): string {
        $heading = trim( (string) ( $context['section_title'] ?? '' ) );
        if ( $heading === '' ) {
            $heading = \GoodService\Modules\WeddingEventsModule::availability_heading( (array) ( $context['vendor_types'] ?? [] ) );
        }
        $desc = trim( (string) ( $context['section_description'] ?? '' ) );
        if ( $desc === '' ) {
            $desc = "Tell us your event date and we'll get back to you with availability.";
        }

        // Honest, real-flow "how it works" steps — deliberately matched
        // to what vsWeddingCheckAvailability()/vsOpenInquiry() actually
        // do (see vendor-site.php): pick a date, that date + your details
        // fold into the platform's one real enquiry popup, the vendor
        // replies. No fabricated steps (e.g. "choose event type" — the
        // popup collects no such field) and no fake calendar/availability
        // data — 3 honest steps, not padded to a round number.
        $steps = [
            [ 'n' => '01', 'title' => 'Pick your event date', 'body' => 'Use the date field to tell us when your event is.' ],
            [ 'n' => '02', 'title' => 'Send a quick enquiry', 'body' => 'Your date is added to a short enquiry with your name and message.' ],
            [ 'n' => '03', 'title' => 'Get a personal response', 'body' => "We'll get back to you directly to confirm availability." ],
        ];

        ob_start();
        ?>
    <div class="gs-wedding-sec-head">
        <div class="gs-wedding-eyebrow">Availability</div>
        <h2 class="vs-sec-title gs-wedding-title gs-wedding-availability-heading"><?php echo esc_html( $heading ); ?></h2>
    </div>
    <div class="gs-wedding-availability-steps">
        <?php foreach ( $steps as $step ): ?>
        <div class="gs-wedding-availability-step">
            <div class="gs-wedding-availability-step-num"><?php echo esc_html( $step['n'] ); ?></div>
            <div class="gs-wedding-availability-step-title"><?php echo esc_html( $step['title'] ); ?></div>
            <p class="gs-wedding-availability-step-body"><?php echo esc_html( $step['body'] ); ?></p>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="gs-wedding-availability-card">
        <div class="gs-wedding-availability-copy">
            <p class="gs-wedding-availability-desc"><?php echo esc_html( $desc ); ?></p>
            <p class="gs-wedding-availability-trust">Popular dates fill quickly — reach out as soon as you have a date in mind.</p>
        </div>
        <div class="gs-wedding-availability-action">
            <label class="gs-wedding-availability-lbl" for="gs-wedding-avail-date">Your event date</label>
            <input type="date" id="gs-wedding-avail-date" class="gs-wedding-availability-input">
            <button type="button" class="gs-wedding-availability-btn" onclick="vsWeddingCheckAvailability()">Request Availability for This Date</button>
        </div>
    </div>
<?php
        return ob_get_clean();
    }
}
