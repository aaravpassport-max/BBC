<?php
namespace GoodService\Modules;

/**
 * WeddingServicesModule — Events & Wedding, Section 03: "Services &
 * Experience". A vendor-type-adaptive list of the concrete
 * services/packages of work a vendor offers — what a photographer
 * shoots, what a planner plans, what a caterer serves — distinct from
 * Section 02's project story galleries (this is not photos) and from
 * a future dedicated packages/pricing section (this is not prices).
 * Deliberately text-forward: an icon/tag + title + description card
 * grid, no lightbox, no images at all.
 *
 * Tag design decision: each item's optional third field is a plain
 * free-text tag (e.g. "Photography", "Decor", "Bridal"), not a fixed
 * SERVICE_ICONS-style const. Sections 01/02 both reuse the single
 * shared PORTFOLIO_CATEGORIES enum because they describe the same
 * underlying photo/story content categorized the same way; a
 * vendor's *services* are a much more open-ended, business-specific
 * set ("Candid Photography" vs "Full Event Decor" vs "Bridal Mehndi")
 * that doesn't map cleanly onto any one fixed list without either
 * omitting real services or forcing an awkward "Other" bucket — so
 * this stays a plain optional text tag, sanitized like every other
 * free-text field, rather than a constrained enum.
 */
class WeddingServicesModule {

    public static function render_title( string $heading, string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-wedding-sec-head">
        <div class="gs-wedding-eyebrow">Our Work</div>
        <h2 class="vs-sec-title gs-wedding-title"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-wedding-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $items         each with title/description/tag, plus the
     *                             new optional icon_image/duration fields.
     * @param bool  $can_lead_popup whether the "Enquire Now" CTA should render —
     *                              same gate every other section's enquiry
     *                              button already respects (see ServicesModule).
     */
    /** @param string $img_fit Image Fit — site-wide image-fit audit: previously hardcoded, now a real vendor-facing setting. */
    public static function render_grid( array $items, bool $can_lead_popup = true, string $img_fit = 'cover' ): string {
        $items = array_values( array_filter( $items, fn( $i ) => is_array( $i ) && trim( (string) ( $i['title'] ?? '' ) ) !== '' ) );
        if ( empty( $items ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( [ 'fit' => $img_fit ] )['img'];

        ob_start();
        ?>
    <div class="gs-wedding-services-grid">
        <?php foreach ( $items as $item ):
            $title    = trim( (string) ( $item['title'] ?? '' ) );
            $desc     = trim( (string) ( $item['description'] ?? '' ) );
            $tag      = trim( (string) ( $item['tag'] ?? '' ) );
            // New, optional, backward-compatible fields — a pre-existing
            // saved item simply has none of these and renders exactly as
            // before (icon-less/image-less card, never broken).
            $icon_img = trim( (string) ( $item['icon_image'] ?? '' ) );
            $duration = trim( (string) ( $item['duration'] ?? '' ) );
        ?>
        <div class="gs-wedding-service-card<?php echo $icon_img !== '' ? ' gs-wedding-service-card-has-img' : ''; ?>">
            <?php if ( $icon_img !== '' ): ?>
            <div class="gs-wedding-service-img-wrap">
                <img class="gs-wedding-service-img" src="<?php echo esc_url( $icon_img ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="lazy" width="320" height="200" style="<?php echo esc_attr( $_img_style ); ?>">
            </div>
            <?php endif; ?>
            <div class="gs-wedding-service-card-body">
                <?php if ( $tag !== '' ): ?><span class="gs-wedding-service-tag"><?php echo esc_html( $tag ); ?></span><?php endif; ?>
                <div class="gs-wedding-service-title"><?php echo esc_html( $title ); ?></div>
                <?php if ( $desc !== '' ): ?><p class="gs-wedding-service-desc"><?php echo esc_html( $desc ); ?></p><?php endif; ?>
                <?php if ( $duration !== '' ): ?><div class="gs-wedding-service-duration">🕐 <?php echo esc_html( $duration ); ?></div><?php endif; ?>
                <?php if ( $can_lead_popup ): ?>
                <button type="button" class="gs-wedding-service-enquire-btn" onclick="vsOpenSvcEnquiry('<?php echo esc_js( $title ); ?>','','<?php echo esc_js( wp_json_encode( [ 'full_description' => $desc, 'duration' => $duration ] ) ); ?>')">📋 Enquire Now</button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $items          each with title/description/tag/icon_image/duration
     *     @type array  $vendor_types
     *     @type bool   $can_lead_popup
     *     @type string $section_title  vendor override; falls back to the adaptive heading when blank.
     *     @type string $section_description
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid( (array) ( $context['items'] ?? [] ), (bool) ( $context['can_lead_popup'] ?? true ), (string) ( $context['img_fit'] ?? 'cover' ) );
        if ( $html === '' ) { return ''; }
        $heading = trim( (string) ( $context['section_title'] ?? '' ) );
        if ( $heading === '' ) {
            $heading = \GoodService\Modules\WeddingEventsModule::services_heading( (array) ( $context['vendor_types'] ?? [] ) );
        }
        return self::render_title( $heading, (string) ( $context['section_description'] ?? '' ) ) . $html;
    }
}
