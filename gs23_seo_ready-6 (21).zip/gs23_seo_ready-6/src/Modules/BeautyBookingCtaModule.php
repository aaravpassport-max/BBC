<?php
namespace GoodService\Modules;

/**
 * BeautyBookingCtaModule — Beauty & Salon, Section 06 of 6:
 * "Appointment/Booking Conversion". The closing section of the
 * microsite, driving into the platform's one real booking flow
 * (window.vsOpenServiceWizard — the same shared wizard extended in
 * Section 03 for specialist selection) rather than any parallel
 * booking system, per the confirmed approach for this build.
 *
 * "Adaptive steps": the little numbered flow shown here is not a
 * fixed, hand-written list — it is built at render time from what the
 * vendor has actually configured elsewhere in this same category
 * build (Section 01's services, Section 03's experts). A vendor who
 * has not added any named experts never sees a "Choose Your
 * Specialist" step promised to them, because that step would be a lie
 * about what their real booking flow does.
 */
class BeautyBookingCtaModule {

    /**
     * @param array $context {
     *     @type bool   $has_services   whether BeautySalonModule::get_services() returned anything real.
     *     @type bool   $has_experts    whether BeautySalonModule::get_experts() returned anything real.
     *     @type string $section_title
     *     @type string $section_description
     *     @type string $cta_text
     *     @type string $image
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $title       = (string) ( $context['section_title'] ?? 'Ready to Book Your Appointment?' );
        $description = (string) ( $context['section_description'] ?? '' );
        $cta_text    = trim( (string) ( $context['cta_text'] ?? '' ) );
        if ( $cta_text === '' ) { $cta_text = 'Book Your Appointment'; }
        $image       = (string) ( $context['image'] ?? '' );
        $has_services = ! empty( $context['has_services'] );
        $has_experts  = ! empty( $context['has_experts'] );

        // Built only from real, currently-true states — never a fixed
        // hard-coded 4-step list.
        $steps = [];
        if ( $has_services ) { $steps[] = [ 'icon' => '💇', 'label' => 'Browse Services' ]; }
        if ( $has_experts )  { $steps[] = [ 'icon' => '💁', 'label' => 'Choose Your Specialist' ]; }
        $steps[] = [ 'icon' => '📅', 'label' => 'Pick Date & Time' ];
        $steps[] = [ 'icon' => '✅', 'label' => 'Confirm Your Booking' ];

        $_img_style = \gs_vs_img_display_style( (array) ( $context['img_display'] ?? [] ) )['img'];

        ob_start();
        ?>
    <div class="gs-beauty-cta<?php echo $image === '' ? ' gs-beauty-cta-no-img' : ''; ?>">
        <?php if ( $image !== '' ): ?>
        <div class="gs-beauty-cta-media">
            <img src="<?php echo esc_url( $image ); ?>" alt="" class="gs-beauty-cta-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
        </div>
        <?php endif; ?>
        <div class="gs-beauty-cta-content">
            <div class="gs-beauty-eyebrow">Book Now</div>
            <h2 class="vs-sec-title gs-beauty-title gs-beauty-cta-title"><?php echo esc_html( $title ); ?></h2>
            <?php if ( $description !== '' ): ?><p class="gs-beauty-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>

            <ol class="gs-beauty-cta-steps">
                <?php foreach ( $steps as $i => $s ): ?>
                <li class="gs-beauty-cta-step"><span class="gs-beauty-cta-step-num"><?php echo esc_html( (string) ( $i + 1 ) ); ?></span><span class="gs-beauty-cta-step-icon"><?php echo esc_html( $s['icon'] ); ?></span><span class="gs-beauty-cta-step-label"><?php echo esc_html( $s['label'] ); ?></span></li>
                <?php endforeach; ?>
            </ol>

            <button type="button" class="gs-beauty-cta-btn" onclick="vsOpenServiceWizard()"><?php echo esc_html( $cta_text ); ?></button>
        </div>
    </div>
<?php
        return ob_get_clean();
    }
}
