<?php
namespace GoodService\Modules;

/**
 * RoomTypesModule — Phase 3d/3e: the first genuinely NEW module built
 * on this project's own infrastructure, not a migration of pre-existing
 * render logic. Category-restricted to 'hotels' (see registration in
 * ModulesBootstrap) — invisible for every listing outside that
 * category, verified directly against the real $_sec_show() code.
 *
 * ASSUMPTION, noted per this session's working instructions: the
 * category slug used for gating is 'hotels' — no category with that
 * exact slug was found already seeded in this codebase (categories
 * here appear to be created by real admins, not seeded), so this is a
 * reasonable, common-sense default rather than a confirmed existing
 * value. If the actual category slug in use differs (e.g. 'hotel',
 * 'accommodation'), update the single 'categories' => [...] array in
 * ModulesBootstrap::register_all() to match — a one-line fix, nothing
 * else in this module depends on the exact string.
 *
 * Data storage: unlike every other module this session (all of which
 * read pre-existing legacy columns/JSON blobs), this module has no
 * legacy data to fall back to — it is genuinely new. Data lives in
 * gs_listing_module_data (module_key = 'room_types'), read via
 * ModuleRegistry::fetch_module_data() and written via the new
 * ModuleRegistry::save_module_data() (added alongside this module,
 * since no module before this one needed the write side).
 *
 * No flag-gating: there is no pre-existing "original" behavior for
 * this section to preserve alongside a new one — it either renders or
 * it doesn't, gated only by category eligibility and the standard
 * visibility system every section already uses.
 */
class RoomTypesModule {

    /**
     * @param string $title Custom section title, matching Packages'
     *               own configurable "Section Title" field — falls
     *               back to the original hardcoded text if not set.
     */
    public static function render_title( string $title = 'Room Types' ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Accommodation</div>
        <h2 class="vs-sec-title"><?php echo esc_html( $title ); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $room_types
     * @param int   $listing_id    Needed to build a correct booking-wizard
     *              payload — every mode of the shared wizard requires
     *              this for its final submission (see vsOpenBookingWizard's
     *              own JS: `listing_id: _vsBW.pkg.listing_id` at
     *              submission time).
     * @param array $img_display   ['fit'=>..,'position'=>..,'zoom'=>..],
     *              matching Packages' own Photo Display Settings shape
     *              exactly — passed through to the shared, global
     *              gs_vs_img_display_style() helper every other section
     *              with configurable photo display already uses.
     * @param int   $grid_cols     2–6, matching Items' own Columns control.
     * @param int   $max_rows     0 = show all (matching Items' own "Show
     *              all" convention), otherwise limits the total number
     *              of rooms rendered to grid_cols * max_rows.
     */
    public static function render_grid( array $room_types, int $listing_id = 0, array $img_display = [], int $grid_cols = 3, int $max_rows = 0 ): string {
        if ( empty( $room_types ) ) { return ''; }
        // Real feature — Rows & Columns, matching Items' own exact
        // limiting behavior: max_rows=0 means unlimited (every room
        // shows); otherwise only the first grid_cols * max_rows rooms
        // render at all — the rest are not merely hidden by CSS, they
        // are never rendered in the first place, consistent with this
        // project's own "hidden must mean detached, not just visually
        // hidden" standard applied everywhere else this session.
        if ( $max_rows > 0 ) {
            $room_types = array_slice( $room_types, 0, $grid_cols * $max_rows );
        }
        $currency = \gs_setting( 'currency_symbol', '₹' );
        // Real feature — reuses the exact same shared, global photo
        // display helper Packages, Services, and Items already use for
        // their own configurable image fit/position/zoom, rather than
        // hardcoding style values as this module did before.
        $_room_img_style = \gs_vs_img_display_style( $img_display )['img'];
        ob_start();
        ?>
    <div class="vs-room-grid">
        <?php foreach ( $room_types as $room ):
            if ( empty( $room['name'] ) ) continue;
            $amenities = is_array( $room['amenities'] ?? null )
                ? $room['amenities']
                : array_filter( array_map( 'trim', explode( "\n", $room['amenities'] ?? '' ) ) );
            $amenities = array_values( array_filter( array_map( 'trim', (array) $amenities ) ) );
            $available = ! isset( $room['available'] ) || (bool) $room['available'];
            // Real fix — "Enquire Now" was a stub: the previous onclick
            // checked `this.getAttribute('href') === '#vs-inq-open'`, but
            // the href was always hardcoded to '#vs-sec-contact' a few
            // characters earlier on the very same line — that condition
            // could never be true, so the button did nothing but jump to
            // the Contact section. Fixed by reusing the platform's own
            // established, shared booking architecture (the same
            // vsOpenBookingWizard()/wizard_payload contract Packages
            // already uses, per the user's explicit requirement not to
            // build a separate mechanism for hotels) — an available room
            // opens the real booking wizard exactly like a package does;
            // a fully-booked room opens the simpler, existing enquiry
            // flow instead, matching how Packages itself falls back to
            // vsOpenInquiry() when its own booking wizard isn't the
            // right fit for a given item.
            $_room_wizard_payload = [
                'name'        => $room['name'],
                'price'       => (float) preg_replace( '/[^0-9.]/', '', (string) ( $room['price'] ?? 0 ) ),
                'period'      => 'night',
                'description' => $room['description'] ?? '',
                'image'       => $room['image'] ?? '',
                'features'    => $amenities,
                'addons'      => [],
                'gst_type'    => 'not_applicable',
                'gst_percent' => 0,
                'currency'    => $currency,
                'listing_id'  => $listing_id,
            ];
            // Real feature — reuses the exact same vsOpenDetailPopup /
            // vsRenderDetailSection component Packages, Services, and
            // Items already share (same popup markup, styling, scroll
            // behavior, open/close, animation — nothing new built), fed
            // with this room's own content so it stays independent: a
            // room's popup shows only that room's own detail sections,
            // built fresh from the room's own data every time, never
            // shared or cached across rooms or with Packages' own
            // sections in any way.
            $_room_dp_sections = [];
            $_room_details_list = [];
            if ( ! empty( $room['capacity'] ) ) { $_room_details_list[] = 'Sleeps up to ' . (int) $room['capacity'] . ' guests'; }
            if ( ! empty( $room['bed_type'] ) ) { $_room_details_list[] = $room['bed_type']; }
            if ( ! empty( $room['size'] ) ) { $_room_details_list[] = 'Room size: ' . $room['size']; }
            if ( ! empty( $_room_details_list ) ) {
                $_room_dp_sections[] = [ 'content_type' => 'list', 'title' => 'Room Details', 'icon' => '🛏️', 'list_items' => $_room_details_list ];
            }
            if ( ! empty( $amenities ) ) {
                $_room_dp_sections[] = [ 'content_type' => 'list', 'title' => 'Amenities', 'icon' => '✅', 'list_items' => $amenities ];
            }
            if ( ! empty( $room['description'] ) ) {
                $_room_dp_sections[] = [ 'content_type' => 'richtext', 'title' => 'About this room', 'icon' => '📝', 'body' => esc_html( $room['description'] ) ];
            }
            // Real feature — merges in the vendor's own custom "Manage
            // Details" sections (built via the same clOpenDetailBuilder
            // tool Packages, Services, and Products already have),
            // matching Packages' own exact merge pattern: appended
            // after the automatic sections above, so a room's popup
            // shows Room Details / Amenities / Description first, then
            // whatever custom content the vendor added.
            $_room_custom_vms = is_string( $room['view_more_sections'] ?? null )
                ? ( json_decode( $room['view_more_sections'], true ) ?: [] )
                : ( $room['view_more_sections'] ?? [] );
            if ( is_array( $_room_custom_vms ) ) {
                foreach ( $_room_custom_vms as $_vms_section ) {
                    if ( is_array( $_vms_section ) ) { $_room_dp_sections[] = $_vms_section; }
                }
            }
            $_room_price_display = ! empty( $room['price'] ) ? ( $currency . $room['price'] . ' / night' ) : '';
        ?>
        <div class="vs-room-card">
            <?php if ( ! empty( $room['image'] ) ): ?>
                <img src="<?php echo esc_url( $room['image'] ); ?>" alt="<?php echo esc_attr( $room['name'] ); ?>" class="vs-room-img" loading="lazy" width="400" height="220" style="<?php echo esc_attr( $_room_img_style ); ?>">
            <?php else: ?>
                <div class="vs-room-img-placeholder">🛏️</div>
            <?php endif; ?>
            <div class="vs-room-body">
                <div class="vs-room-top-row">
                    <div class="vs-room-name"><?php echo esc_html( $room['name'] ); ?></div>
                    <span class="vs-room-avail<?php echo $available ? '' : ' unavailable'; ?>"><?php echo $available ? 'Available' : 'Fully Booked'; ?></span>
                </div>
                <div class="vs-room-meta">
                    <?php if ( ! empty( $room['capacity'] ) ): ?><span class="vs-room-meta-item">👥 <?php echo (int) $room['capacity']; ?> guests</span><?php endif; ?>
                    <?php if ( ! empty( $room['bed_type'] ) ): ?><span class="vs-room-meta-item">🛏️ <?php echo esc_html( $room['bed_type'] ); ?></span><?php endif; ?>
                    <?php if ( ! empty( $room['size'] ) ): ?><span class="vs-room-meta-item">📐 <?php echo esc_html( $room['size'] ); ?></span><?php endif; ?>
                </div>
                <?php if ( ! empty( $room['description'] ) ): ?>
                    <div class="vs-room-desc"><?php echo esc_html( $room['description'] ); ?></div>
                <?php endif; ?>
                <?php if ( ! empty( $amenities ) ): ?>
                <ul class="vs-room-amenities">
                    <?php foreach ( array_slice( $amenities, 0, 6 ) as $a ): ?>
                    <li>✓ <?php echo esc_html( $a ); ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
                <a href="#" class="vs-view-more-link" data-title="<?php echo esc_attr( $room['name'] ); ?>"
                   data-image="<?php echo esc_attr( $room['image'] ?? '' ); ?>"
                   data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $room['additional_images'] ?? null ) ? $room['additional_images'] : [] ) ) ) ); ?>"
                   data-img-fit="<?php echo esc_attr( in_array( $img_display['popup_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $img_display['popup_fit'] ?? 'cover' ) : 'cover' ); ?>"
                   data-slider-interval="<?php echo esc_attr( (int) ( $img_display['interval'] ?? 0 ) ); ?>"
                   data-price="<?php echo esc_attr( $_room_price_display ); ?>"
                   data-sections="<?php echo esc_attr( wp_json_encode( $_room_dp_sections ) ); ?>"
                   <?php if ( $available ): ?>data-pkg="<?php echo esc_attr( wp_json_encode( $_room_wizard_payload ) ); ?>"<?php endif; ?>
                   onclick="event.preventDefault();vsOpenDetailPopup(event,this)">View more details</a>
                <div class="vs-room-footer">
                    <?php if ( ! empty( $room['price'] ) ): ?>
                        <div class="vs-room-price"><?php echo esc_html( $currency . $room['price'] ); ?><span>/night</span></div>
                    <?php endif; ?>
                    <?php if ( $available ): ?>
                    <button type="button" class="vs-btn vs-btn-primary vs-room-cta"
                            data-pkg="<?php echo esc_attr( wp_json_encode( $_room_wizard_payload ) ); ?>"
                            onclick="vsOpenBookingWizard(this)">Book Now</button>
                    <?php else: ?>
                    <button type="button" class="vs-btn vs-btn-primary vs-room-cta"
                            onclick="vsOpenInquiry({name:'<?php echo esc_js( $room['name'] ); ?>',type:'service',price:'<?php echo esc_js( $currency . ( $room['price'] ?? '' ) ); ?>'})">Enquire Now</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $room_types    The room types array, fetched via
     *                  ModuleRegistry::fetch_module_data() before this
     *                  is called — see how vendor-site.php wires this
     *                  in for the exact call site.
     *     @type int    $listing_id    Needed to build a correct booking
     *                  wizard payload for each room — see render_grid()'s
     *                  own docblock.
     *     @type string $section_title Custom section title text.
     *     @type array  $img_display   Photo display settings, passed
     *                  through to render_grid().
     *     @type int    $grid_cols     Columns (desktop), passed through.
     *     @type int    $max_rows      Max rows, passed through.
     * }
     */
    public static function render( array $context ): string {
        $room_types = $context['room_types'] ?? [];
        if ( empty( $room_types ) ) { return ''; }
        return self::render_title( $context['section_title'] ?? 'Room Types' )
            . self::render_grid(
                $room_types,
                (int) ( $context['listing_id'] ?? 0 ),
                (array) ( $context['img_display'] ?? [] ),
                (int) ( $context['grid_cols'] ?? 3 ),
                (int) ( $context['max_rows'] ?? 0 )
            );
    }
}
