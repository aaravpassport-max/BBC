<?php
namespace GoodService\Modules;

use GoodService\Core\ModuleRegistry;

/**
 * ⚠️ BEFORE ADDING A NEW ModuleRegistry::register() CALL BELOW ⚠️
 * ════════════════════════════════════════════════════════════════════
 * Read the mandatory architecture notice at the top of
 * src/Core/ModuleRegistry.php first. Short version: a category-specific
 * section (categories = a real array, not 'all') MUST be registered
 * with 'default_enabled' => false and MUST require the vendor to
 * explicitly tick and save it before it appears anywhere for that
 * listing. register() itself will now refuse (and log) any attempt to
 * combine a real categories array with default_enabled=true — but
 * refusing silently at runtime is a safety net, not a substitute for
 * getting it right here. See `room_types` below for the correct,
 * working example of a category-specific module's registration, and
 * MODULE_ARCHITECTURE_ROADMAP.md Section 6.16 for the full story.
 * ════════════════════════════════════════════════════════════════════
 *
 * ModulesBootstrap — registers every migrated module with ModuleRegistry.
 *
 * REAL GAP FOUND AND FIXED IN THIS SESSION: the roadmap document's
 * Section 6 status table claimed all 12 previously-migrated modules
 * were "registered in ModuleRegistry." A direct search of the entire
 * codebase (grep for ModuleRegistry::register across every .php file)
 * found ZERO calls anywhere — no bootstrap file existed, so none of
 * the 12 modules were actually registered outside of isolated tests.
 * This is exactly the kind of discrepancy Section 0's "verify, don't
 * trust this document" instruction exists to catch. Recorded here
 * per this project's own documentation standard (Section J) rather
 * than silently fixed with no note.
 *
 * All 12 prior modules + Contact (this session's addition) are
 * registered here with `default_enabled => true, categories => 'all'`,
 * matching their real status: every one of them is a migrated EXISTING
 * shared section available to every listing regardless of category —
 * none of them are new, opt-in, category-specific modules (those don't
 * exist yet — Phase 3e). Icons/labels are copied verbatim from
 * create-listing.php's existing $sec_labels array (the exact hardcoded
 * array this registry is meant to eventually replace — see
 * ModuleRegistry::get_admin_tool_entries()) so nothing visually changes
 * once Phase 3b wires the admin tools onto this registry.
 *
 * render_callback here is each module's own render(array $context)
 * method — the same contract every module already implements. It is
 * NOT currently invoked by the live page (Section 9, item 1: the real
 * engine cutover is a separate, later, higher-risk phase) — the live
 * file's flag-gated integration points call each module's specific
 * render_xxx() method directly, bypassing the registry/renderer
 * entirely, exactly as documented. Registering here makes every module
 * visible to ModuleRegistry::get_all()/get_admin_tool_entries() and
 * unblocks Phase 3b without requiring any changes to the modules
 * themselves.
 *
 * Called once from goodservice.php, immediately after functions.php is
 * required (autoloader is already active by that point) and before any
 * page-render code could ask the registry for module data.
 */
class ModulesBootstrap {

    private static bool $registered = false;

    public static function register_all(): void {
        if ( self::$registered ) { return; } // idempotent — safe if called more than once per request
        self::$registered = true;

        // ── Phase 1 ──
        ModuleRegistry::register( 'highlights', [
            'label' => 'Key Highlights', 'icon' => '✨', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ HighlightsModule::class, 'render' ],
        ] );

        // ── Phase 2: originally partially-CSS-gated sections ──
        ModuleRegistry::register( 'amenities', [
            'label' => 'Features & Amenities', 'icon' => '🏷️', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ AmenitiesModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'facilities', [
            'label' => 'Facilities', 'icon' => '🏢', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ FacilitiesModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'awards', [
            'label' => 'Awards & Recognition', 'icon' => '🏆', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ AwardsModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'certifications', [
            'label' => 'Licences & Certifications', 'icon' => '📜', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ CertificationsModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'languages', [
            'label' => 'Languages Spoken', 'icon' => '🗣️', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ LanguagesModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'memberships', [
            'label' => 'Membership Plans', 'icon' => '💳', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ MembershipsModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'warranty', [
            'label' => 'Warranty / Guarantee', 'icon' => '🛡️', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ WarrantyModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'terms', [
            'label' => 'Terms & Conditions', 'icon' => '📄', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ TermsModule::class, 'render' ],
        ] );

        // ── Phase 2: originally NOT CSS/JS gated at all ──
        ModuleRegistry::register( 'faq', [
            'label' => 'FAQ', 'icon' => '❓', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ FaqModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'team', [
            'label' => 'Team', 'icon' => '👥', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ TeamModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'clients', [
            'label' => 'Clients', 'icon' => '🤝', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ ClientsModule::class, 'render' ],
        ] );

        // ── This session ──
        ModuleRegistry::register( 'contact', [
            'label' => 'Contact', 'icon' => '📍', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ ContactModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'why', [
            'label' => 'Why Us', 'icon' => '💡', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ WhyModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'process', [
            'label' => 'Process', 'icon' => '📋', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ ProcessModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'trust_bar', [
            'label' => 'Trust Bar (scrolling)', 'icon' => '🔒', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ TrustBarModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'services', [
            'label' => 'Services', 'icon' => '🛠️', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ ServicesModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'packages', [
            'label' => 'Packages & Pricing', 'icon' => '📦', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ PackagesModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'items', [
            'label' => 'Products & Services Items', 'icon' => '🧰', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ ProductsItemsModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'gallery', [
            'label' => 'Photo Gallery', 'icon' => '🖼️', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ GalleryModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'pricing', [
            'label' => 'Pricing Table', 'icon' => '💰', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ PricingModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'portfolio', [
            'label' => 'Portfolio / Case Studies', 'icon' => '📁', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ PortfolioModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'testimonials', [
            'label' => 'Testimonials', 'icon' => '💬', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ TestimonialsModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'inquiry_modules', [
            'label' => 'Inquiry Modules', 'icon' => '📋', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ InquiryModulesModule::class, 'render' ],
        ] );
        ModuleRegistry::register( 'related_listings', [
            'label' => 'Similar Businesses Near You', 'icon' => '🔗', 'type' => 'custom',
            'categories' => 'all', 'default_enabled' => true,
            'render_callback' => [ RelatedListingsModule::class, 'render' ],
        ] );
        // Phase 3e — the first genuinely category-specific module. See
        // RoomTypesModule's own docblock for the 'hotels' slug assumption.
        // default_enabled is deliberately FALSE here (unlike every other
        // module, all of which are 'all'-category and default_enabled=true):
        // a category-specific module must require explicit, per-listing
        // vendor opt-in via the real gs_listing_modules assignment table —
        // it is not enough for the listing's category to merely match.
        // See is_assigned()'s own docblock, which already documents this
        // exact distinction: default_enabled=true counts as assigned with
        // no row needed (every regular/common section); default_enabled=
        // false requires a real, explicit assignment row.
        ModuleRegistry::register( 'room_types', [
            'label' => 'Room Types', 'icon' => '🛏️', 'type' => 'custom',
            'categories' => [ 'hotels' ], 'default_enabled' => false,
            'render_callback' => [ RoomTypesModule::class, 'render' ],
        ] );
        // Hotels / Banquets / Hospitality, module 1 — Banquet & Event
        // Spaces (with the Event Capacity Matrix). Same 'hotels' slug
        // as room_types — see HotelEventSpacesModule's own docblock for
        // the reasoning and for the universal modules (packages, team,
        // testimonials, faq) already investigated and NOT duplicated.
        ModuleRegistry::register( 'hotel_event_spaces', [
            'label' => 'Banquet & Event Spaces', 'icon' => '🎪', 'type' => 'custom',
            'categories' => [ 'hotels' ], 'default_enabled' => false,
            'render_callback' => [ HotelEventSpacesModule::class, 'render' ],
        ] );
        // Hotels / Banquets / Hospitality, module 2 — Events at the
        // Property (spec Sections 04+05 combined). See
        // HotelEventsShowcaseModule's own docblock for why it reuses
        // WeddingStoriesModule's proven story-card structure rather than
        // reusing that module directly (it is gated to a different
        // category).
        ModuleRegistry::register( 'hotel_events_showcase', [
            'label' => 'Events at the Property', 'icon' => '🎊', 'type' => 'custom',
            'categories' => [ 'hotels' ], 'default_enabled' => false,
            'render_callback' => [ HotelEventsShowcaseModule::class, 'render' ],
        ] );
        // Hotels / Banquets / Hospitality, module 3 — Dining & Culinary
        // Experience (spec Sections 06+07 combined). See
        // HotelDiningModule's own docblock — no existing module in any
        // category covers a food/beverage menu, so nothing was
        // duplicated; the category-tab filtering mechanism is reused
        // from HomeServicesCatalogueModule rather than reinvented.
        ModuleRegistry::register( 'hotel_dining', [
            'label' => 'Dining & Culinary Experience', 'icon' => '🍽️', 'type' => 'custom',
            'categories' => [ 'hotels' ], 'default_enabled' => false,
            'render_callback' => [ HotelDiningModule::class, 'render' ],
        ] );
        // Hotels / Banquets / Hospitality, module 4 — Amenities &
        // Facilities, grouped presentation. See HotelAmenitiesModule's
        // own docblock — the universal Amenities/Facilities modules
        // were investigated first and both only render a flat,
        // ungrouped grid; this module fills that real gap rather than
        // duplicating either one.
        ModuleRegistry::register( 'hotel_amenities', [
            'label' => 'Amenities & Facilities (Grouped)', 'icon' => '🛎️', 'type' => 'custom',
            'categories' => [ 'hotels' ], 'default_enabled' => false,
            'render_callback' => [ HotelAmenitiesModule::class, 'render' ],
        ] );
        // Hotels / Banquets / Hospitality, module 5 — Virtual Tour. See
        // HotelVirtualTourModule's own docblock — no existing module
        // embeds a video/360 tour, so nothing was duplicated; the
        // YouTube-embed regex and iframe sanitization are reused from
        // TestimonialsModule and ContactModule respectively.
        ModuleRegistry::register( 'hotel_virtual_tour', [
            'label' => 'Virtual Tour', 'icon' => '🎥', 'type' => 'custom',
            'categories' => [ 'hotels' ], 'default_enabled' => false,
            'render_callback' => [ HotelVirtualTourModule::class, 'render' ],
        ] );
        // Hotels / Banquets / Hospitality, module 6 — Final Conversion
        // CTA. Follows WeddingClosingBannerModule's exact precedent —
        // see HotelClosingBannerModule's own docblock.
        ModuleRegistry::register( 'hotel_closing_banner', [
            'label' => 'Final Conversion Banner', 'icon' => '📣', 'type' => 'custom',
            'categories' => [ 'hotels' ], 'default_enabled' => false,
            'render_callback' => [ HotelClosingBannerModule::class, 'render' ],
        ] );
        // Real estate module 1 of 4 — Property Listings. See
        // PropertyListingsModule's own docblock for the 'real-estate'
        // slug assumption and why this module owns the shared property
        // data the other three real-estate modules read from.
        ModuleRegistry::register( 'property_listings', [
            'label' => 'Property Listings', 'icon' => '🏠', 'type' => 'custom',
            'categories' => [ 'real-estate' ], 'default_enabled' => false,
            'render_callback' => [ PropertyListingsModule::class, 'render' ],
        ] );
        // Real estate module 2 of 4 — Featured Properties. Deliberately
        // a separate module key with its own independent activation —
        // reads the SAME underlying property data as property_listings
        // (via PropertyListingsModule::get_properties()) but does not
        // depend on that module being active at all, satisfying the
        // request's own explicit requirement that Featured can be ON
        // while Listings is OFF.
        ModuleRegistry::register( 'featured_properties', [
            'label' => 'Featured Properties', 'icon' => '⭐', 'type' => 'custom',
            'categories' => [ 'real-estate' ], 'default_enabled' => false,
            'render_callback' => [ FeaturedPropertiesModule::class, 'render' ],
        ] );
        // Real estate module 3 of 4 — Property Types/Categories. Same
        // independence pattern as Featured Properties: own module key,
        // own activation, reads the shared property data directly.
        ModuleRegistry::register( 'property_types', [
            'label' => 'Property Types', 'icon' => '🏘️', 'type' => 'custom',
            'categories' => [ 'real-estate' ], 'default_enabled' => false,
            'render_callback' => [ PropertyTypesModule::class, 'render' ],
        ] );
        // Real estate module 4 of 4 — Property Gallery. Deliberately
        // independent of the other three (see PropertyGalleryModule's
        // own docblock) — its own gallery of vendor-selected images
        // from the existing media library, not tied to individual
        // property records.
        ModuleRegistry::register( 'property_gallery', [
            'label' => 'Property Gallery', 'icon' => '🖼️', 'type' => 'custom',
            'categories' => [ 'real-estate' ], 'default_enabled' => false,
            'render_callback' => [ PropertyGalleryModule::class, 'render' ],
        ] );

        // ── Interior Designers & Architects (5 modules) ──
        // Category slug 'interior-designers-architects', confirmed
        // directly from the user's stated real category name, not
        // guessed — see ProjectsModule's own docblock for the full
        // reasoning. Module 1 of 5 — Featured Projects, the data-
        // owning, "Advanced" complexity module every other module in
        // this category reads from.
        ModuleRegistry::register( 'featured_projects', [
            'label' => 'Featured Projects', 'icon' => '🏛️', 'type' => 'custom',
            'categories' => [ 'interior-designers-architects' ], 'default_enabled' => false,
            'render_callback' => [ FeaturedProjectsModule::class, 'render' ],
        ] );
        // Module 2 of 5 — Project Categories. Reads Featured Projects'
        // shared data directly (see ProjectCategoriesModule's own
        // docblock) — independent activation, same pattern as every
        // other cross-referencing module this session.
        ModuleRegistry::register( 'project_categories', [
            'label' => 'Project Categories', 'icon' => '📁', 'type' => 'custom',
            'categories' => [ 'interior-designers-architects' ], 'default_enabled' => false,
            'render_callback' => [ ProjectCategoriesModule::class, 'render' ],
        ] );
        // Module 3 of 5 — 3D Designs & Before/After.
        ModuleRegistry::register( 'three_d_before_after', [
            'label' => '3D Designs & Before/After', 'icon' => '🎨', 'type' => 'custom',
            'categories' => [ 'interior-designers-architects' ], 'default_enabled' => false,
            'render_callback' => [ ThreeDBeforeAfterModule::class, 'render' ],
        ] );
        // Module 4 of 5 — Design Styles & Expertise.
        ModuleRegistry::register( 'design_styles', [
            'label' => 'Design Styles & Expertise', 'icon' => '🖌️', 'type' => 'custom',
            'categories' => [ 'interior-designers-architects' ], 'default_enabled' => false,
            'render_callback' => [ DesignStylesModule::class, 'render' ],
        ] );
        // Module 5 of 5 — Design Process. The final module in this
        // category build. Fully independent, no cross-referencing.
        ModuleRegistry::register( 'design_process', [
            'label' => 'Design Process', 'icon' => '🗺️', 'type' => 'custom',
            'categories' => [ 'interior-designers-architects' ], 'default_enabled' => false,
            'render_callback' => [ DesignProcessModule::class, 'render' ],
        ] );

        // ── Health & Wellness (5 modules) ──
        // Category slug 'health-wellness', confirmed directly from the
        // user's stated real category name — see HealthWellnessModule's
        // own docblock. Module 1 of 5 — Featured Services/Treatments,
        // the "Advanced" complexity data-owning module.
        ModuleRegistry::register( 'featured_services', [
            'label' => 'Featured Services & Treatments', 'icon' => '⚕️', 'type' => 'custom',
            'categories' => [ 'health-wellness' ], 'default_enabled' => false,
            'render_callback' => [ FeaturedServicesModule::class, 'render' ],
        ] );
        // Module 2 of 5 — Departments/Specialties. Reads both Services'
        // and Doctors' shared data directly, independent activation.
        ModuleRegistry::register( 'departments', [
            'label' => 'Departments & Specialties', 'icon' => '🏥', 'type' => 'custom',
            'categories' => [ 'health-wellness' ], 'default_enabled' => false,
            'render_callback' => [ DepartmentsModule::class, 'render' ],
        ] );
        // Module 3 of 5 — Doctors & Healthcare Professionals. Owns
        // doctor data both Departments and Featured Services read from.
        ModuleRegistry::register( 'doctors', [
            'label' => 'Doctors & Healthcare Professionals', 'icon' => '🩺', 'type' => 'custom',
            'categories' => [ 'health-wellness' ], 'default_enabled' => false,
            'render_callback' => [ DoctorsModule::class, 'render' ],
        ] );
        // Module 4 of 5 — Facilities & Patient Experience. Registered
        // under 'patient_facilities', a distinct key from the
        // existing, separate 'facilities' module (registered above,
        // 'categories' => 'all', a different class) — confirmed
        // directly before building this, see PatientFacilitiesModule's
        // own docblock for the full reasoning.
        ModuleRegistry::register( 'patient_facilities', [
            'label' => 'Facilities & Patient Experience', 'icon' => '🏨', 'type' => 'custom',
            'categories' => [ 'health-wellness' ], 'default_enabled' => false,
            'render_callback' => [ PatientFacilitiesModule::class, 'render' ],
        ] );
        // Module 5 of 5 — Patient Journey/Treatment Process. The
        // final module in this five-module category build. Fully
        // independent, no cross-referencing.
        ModuleRegistry::register( 'patient_journey', [
            'label' => 'Patient Journey', 'icon' => '🗺️', 'type' => 'custom',
            'categories' => [ 'health-wellness' ], 'default_enabled' => false,
            'render_callback' => [ PatientJourneyModule::class, 'render' ],
        ] );

        // ── Beauty & Salon — built one section at a time, per the master
        // build prompt. CONFIRMED, not guessed: 'beauty-salon' is the
        // real, pre-seeded category slug — see Seeder::seed_categories()
        // and BeautySalonModule's own docblock. Module 1 (of 6 total,
        // planned) — Beauty Service Discovery, the primary
        // service-discovery/data-owning module for this category.
        ModuleRegistry::register( 'beauty_services', [
            'label' => 'Beauty Services', 'icon' => '💇', 'type' => 'custom',
            'categories' => [ 'beauty-salon' ], 'default_enabled' => false,
            'render_callback' => [ BeautyServicesModule::class, 'render' ],
        ] );

        // Module 2 of 6 — Signature Looks & Transformations. Its own,
        // independently-gated gallery, deliberately not dependent on
        // beauty_services being enabled.
        ModuleRegistry::register( 'beauty_gallery', [
            'label' => 'Signature Looks & Transformations', 'icon' => '📸', 'type' => 'custom',
            'categories' => [ 'beauty-salon' ], 'default_enabled' => false,
            'render_callback' => [ BeautyGalleryModule::class, 'render' ],
        ] );

        // Module 3 of 6 — Beauty Experts/Stylists. Own, independently-
        // gated data, not dependent on beauty_services or beauty_gallery.
        ModuleRegistry::register( 'beauty_experts', [
            'label' => 'Beauty Experts / Stylists', 'icon' => '💁', 'type' => 'custom',
            'categories' => [ 'beauty-salon' ], 'default_enabled' => false,
            'render_callback' => [ BeautyExpertsModule::class, 'render' ],
        ] );

        // Module 4 of 6 — Salon Experience & Facilities. Own,
        // independently-gated data.
        ModuleRegistry::register( 'beauty_facilities', [
            'label' => 'Salon Experience & Facilities', 'icon' => '🏛️', 'type' => 'custom',
            'categories' => [ 'beauty-salon' ], 'default_enabled' => false,
            'render_callback' => [ BeautyFacilitiesModule::class, 'render' ],
        ] );

        // Module 5 of 6 — Beauty Packages & Offers. Own,
        // independently-gated data.
        ModuleRegistry::register( 'beauty_packages', [
            'label' => 'Beauty Packages & Offers', 'icon' => '🎁', 'type' => 'custom',
            'categories' => [ 'beauty-salon' ], 'default_enabled' => false,
            'render_callback' => [ BeautyPackagesModule::class, 'render' ],
        ] );

        // Module 6 of 6 — Appointment/Booking Conversion. No
        // ModuleRegistry-stored data of its own — every field is a
        // lightweight customizer_data setting (title/description/CTA
        // text/photo), the same pattern the generic PackagesModule's
        // own 'packages_title' section already uses.
        ModuleRegistry::register( 'beauty_booking_cta', [
            'label' => 'Appointment Booking CTA', 'icon' => '📅', 'type' => 'custom',
            'categories' => [ 'beauty-salon' ], 'default_enabled' => false,
            'render_callback' => [ BeautyBookingCtaModule::class, 'render' ],
        ] );

        // ═══ EVENTS & WEDDING (real seeded category slug: 'events-wedding',
        // confirmed directly from Seeder.php::seed_categories() — the
        // custom build spec's own working title "Wedding & Events" is
        // NOT the real slug) ═══
        // Module 1 — Signature Portfolio. Own, independently-gated data.
        ModuleRegistry::register( 'wedding_portfolio', [
            'label' => 'Signature Portfolio', 'icon' => '📷', 'type' => 'custom',
            'categories' => [ 'events-wedding' ], 'default_enabled' => false,
            'render_callback' => [ WeddingPortfolioModule::class, 'render' ],
        ] );

        // Module 2 — Real Weddings / Real Events. Own, independently-
        // gated data; grouped story cards, distinct from Module 1's
        // flat portfolio grid.
        ModuleRegistry::register( 'wedding_stories', [
            'label' => 'Real Weddings / Real Events', 'icon' => '💍', 'type' => 'custom',
            'categories' => [ 'events-wedding' ], 'default_enabled' => false,
            'render_callback' => [ WeddingStoriesModule::class, 'render' ],
        ] );

        // Module 3 — Services & Experience. Own, independently-gated
        // data; a text-forward list of what the vendor actually does,
        // distinct from Module 2's photo story cards and from a future
        // dedicated packages/pricing section.
        ModuleRegistry::register( 'wedding_services', [
            'label' => 'Services & Experience', 'icon' => '🛠️', 'type' => 'custom',
            'categories' => [ 'events-wedding' ], 'default_enabled' => false,
            'render_callback' => [ WeddingServicesModule::class, 'render' ],
        ] );

        // Module 4 — Packages & Collections. Own, independently-gated
        // data; vendor pricing packages with a real, vendor-selected
        // 3-state price display (fixed / starting_from / on_request) —
        // distinct from Module 3's plain service list, which never
        // carries a price at all.
        ModuleRegistry::register( 'wedding_packages', [
            'label' => 'Packages & Collections', 'icon' => '💼', 'type' => 'custom',
            'categories' => [ 'events-wedding' ], 'default_enabled' => false,
            'render_callback' => [ WeddingPackagesModule::class, 'render' ],
        ] );

        // Module 5 — Experience & Style. A pure customizer_data
        // multi-select setting (fixed style-tag chips), not repeater
        // content — no per-listing items array, so there is nothing for
        // this render_callback to ever be dispatched through generically;
        // like every other wedding_* section, vendor-site.php calls
        // WeddingStyleModule::render() directly. Registered anyway for
        // section-detachment auditing, admin card assignment, and the
        // shared visibility/nav plumbing every module key gets.
        ModuleRegistry::register( 'wedding_style', [
            'label' => 'Experience & Style', 'icon' => '✨', 'type' => 'custom',
            'categories' => [ 'events-wedding' ], 'default_enabled' => false,
            'render_callback' => [ WeddingStyleModule::class, 'render' ],
        ] );

        // Module 6 — Team / Creative Experts. Own, independently-gated
        // data; directly analogous to Beauty & Salon's beauty_experts
        // (photo, name, role, bio), with an optional single profile
        // link per member and a graceful initial-avatar fallback when
        // no photo is set.
        ModuleRegistry::register( 'wedding_team', [
            'label' => 'Team / Creative Experts', 'icon' => '👥', 'type' => 'custom',
            'categories' => [ 'events-wedding' ], 'default_enabled' => false,
            'render_callback' => [ WeddingTeamModule::class, 'render' ],
        ] );

        // Module 7 — Venue / Event Specialisation. OPTIONAL, only ever
        // meaningful for venue-adjacent vendor types (planners,
        // decorators, event companies) — never vendor-type-gated at the
        // admin level though, same as every sibling section above; a
        // vendor with nothing checked simply renders ''. Hybrid data
        // shape: a fixed enum selection (WeddingEventsModule::
        // VENUE_SPECIALIZATIONS) where each checked item can carry an
        // optional per-item free-text note, so — like wedding_team —
        // this is genuine per-listing repeater content, not a plain
        // customizer_data setting.
        ModuleRegistry::register( 'wedding_venue_specialization', [
            'label' => 'Venue / Event Specialisation', 'icon' => '🏰', 'type' => 'custom',
            'categories' => [ 'events-wedding' ], 'default_enabled' => false,
            'render_callback' => [ WeddingVenueSpecModule::class, 'render' ],
        ] );

        // Module 8 — Location & Destination Coverage. Own, independently-
        // gated data; a flat, open-ended repeater of city/region names
        // (each with an optional per-item note), plus one plain
        // customizer_data flag ('wedding_destination_available') for
        // "Available for Destination Weddings" — deliberately NOT a
        // fixed enum like Module 7, since real city/region names cannot
        // be exhaustively listed in advance.
        ModuleRegistry::register( 'wedding_locations', [
            'label' => 'Location & Destination Coverage', 'icon' => '📍', 'type' => 'custom',
            'categories' => [ 'events-wedding' ], 'default_enabled' => false,
            'render_callback' => [ WeddingLocationsModule::class, 'render' ],
        ] );

        // Module 10 — Check Availability. No repeater data — there is no
        // real per-date open/blocked signal on this platform for the
        // events-wedding vertical (see WeddingAvailabilityModule's own
        // header comment). Vendor-configurable parts are just an optional
        // section title/description override, same shape as plain
        // customizer_data string fields elsewhere.
        ModuleRegistry::register( 'wedding_availability', [
            'label' => 'Check Availability', 'icon' => '📅', 'type' => 'custom',
            'categories' => [ 'events-wedding' ], 'default_enabled' => false,
            'render_callback' => [ WeddingAvailabilityModule::class, 'render' ],
        ] );

        // Module 11 — Request a Quote. No repeater data — same shape as
        // Module 10: an optional section title/description override
        // plus this module's own real-mechanism CTA (see
        // WeddingQuoteModule's own header comment for why it reuses
        // window.vsOpenInquiry() rather than inventing a new submission
        // path).
        ModuleRegistry::register( 'wedding_quote', [
            'label' => 'Request a Quote', 'icon' => '💌', 'type' => 'custom',
            'categories' => [ 'events-wedding' ], 'default_enabled' => false,
            'render_callback' => [ WeddingQuoteModule::class, 'render' ],
        ] );

        // Module 12 (final) — Premium Conversion Banner. The closing
        // full-bleed CTA bookend to Module 11's form. No repeater data;
        // just an optional section title/description override, same
        // shape as Module 10/11. Its CTA calls window.vsOpenInquiry()
        // directly (see WeddingClosingBannerModule's own header comment
        // for why, vs. going through the wedding-specific wrapper).
        ModuleRegistry::register( 'wedding_closing_banner', [
            'label' => 'Premium Conversion Banner', 'icon' => '🎉', 'type' => 'custom',
            'categories' => [ 'events-wedding' ], 'default_enabled' => false,
            'render_callback' => [ WeddingClosingBannerModule::class, 'render' ],
        ] );

        // ═══ HOME SERVICES (real seeded category slug: 'home-services',
        // confirmed directly from Seeder.php::seed_categories() — the
        // custom build spec's own working title "Home Repair &
        // Services" is not the real category name). Module 1 (of a
        // planned multi-module build) — Service Catalogue & Problem
        // Solver, the primary service-discovery/data-owning module for
        // this category. Own data-owning module, independent of every
        // other Home Services section still to be built (each will be
        // gated by its own $_sec_show()).
        ModuleRegistry::register( 'home_services_catalogue', [
            'label' => 'Service Catalogue & Problem Solver', 'icon' => '🧰', 'type' => 'custom',
            'categories' => [ 'home-services' ], 'default_enabled' => false,
            'render_callback' => [ HomeServicesCatalogueModule::class, 'render' ],
        ] );

        // Home Services, Module 2 — Packages & Maintenance Plans (custom
        // build spec Section 03, combined with the recurring-AMC concept
        // per the spec's own Section 32 Data-Density Requirement). Own
        // module_key/data store, independent of home_services_catalogue.
        ModuleRegistry::register( 'home_services_packages', [
            'label' => 'Packages & Maintenance Plans', 'icon' => '🧾', 'type' => 'custom',
            'categories' => [ 'home-services' ], 'default_enabled' => false,
            'render_callback' => [ HomeServicesPackagesModule::class, 'render' ],
        ] );

        // Home Services, Module 3 — Technicians & Experts (custom build
        // spec Section 04). Own module_key/data store, independent of
        // both prior Home Services modules.
        ModuleRegistry::register( 'home_services_technicians', [
            'label' => 'Technicians & Experts', 'icon' => '👷', 'type' => 'custom',
            'categories' => [ 'home-services' ], 'default_enabled' => false,
            'render_callback' => [ HomeServicesTechniciansModule::class, 'render' ],
        ] );

        // Home Services, Module 4 — License, Insurance & Service
        // Guarantee. Deliberately NOT a duplicate of the universal
        // `why` / `trust_bar` modules — see HomeServicesGuaranteeModule's
        // own docblock for why those were investigated and ruled out
        // first. Own module_key/data store.
        ModuleRegistry::register( 'home_services_guarantee', [
            'label' => 'License, Insurance & Guarantee', 'icon' => '🛡️', 'type' => 'custom',
            'categories' => [ 'home-services' ], 'default_enabled' => false,
            'render_callback' => [ HomeServicesGuaranteeModule::class, 'render' ],
        ] );

        // Home Services, Module 5 — Before & After Work Gallery.
        // Investigated first: BeautyGalleryModule is the only existing
        // before/after gallery, category-gated to 'beauty-salon' only —
        // not a duplicate for Home Services. Reuses the same shared
        // window.vsIdaInitBeforeAfterSlider() engine and window.vsLightbox()
        // rather than building either mechanism again — see
        // HomeServicesBeforeAfterModule's own docblock.
        ModuleRegistry::register( 'home_services_before_after', [
            'label' => 'Before & After Work Gallery', 'icon' => '🖼️', 'type' => 'custom',
            'categories' => [ 'home-services' ], 'default_enabled' => false,
            'render_callback' => [ HomeServicesBeforeAfterModule::class, 'render' ],
        ] );
    }
}
