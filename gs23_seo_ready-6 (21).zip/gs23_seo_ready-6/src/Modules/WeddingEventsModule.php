<?php
namespace GoodService\Modules;

/**
 * WeddingEventsModule — the foundational data-access + vendor-type
 * adaptation layer for the Events & Wedding category build, matching
 * the established pattern of BeautySalonModule, HealthWellnessModule
 * and InteriorDesignersModule before it: one small, shared class per
 * category holding real category slug/group constants, the vendor-
 * type adaptation logic every section needs, and the plain data-fetch
 * helpers every module in the category needs.
 *
 * CONFIRMED, not guessed, per the master build prompt's Section 0.2:
 * this platform's real pre-seeded category is named "Events &
 * Wedding" with slug 'events-wedding' — read directly from
 * src/Database/Seeder.php::seed_categories(). The custom build
 * document this category is being built from calls it "Wedding &
 * Events", but that is the document's own working title, not the
 * real slug; every module in this category is gated to the real
 * 'events-wedding' slug.
 *
 * Vendor-type adaptation: rather than building a separate frontend
 * template per business type (photographer page vs. planner page vs.
 * decorator page), one vendor_type multi-select is stored once, in
 * customizer_data (a setting, not content — the vendor picks it once,
 * it never grows into a list the vendor manages entries in), and
 * every section's PHP reads it via get_vendor_types() and adapts its
 * own heading/labels/CTAs. A vendor can genuinely be more than one
 * type (e.g. a "Photography & Videography Studio"), so this is a
 * multi-select, not a single enum — every adaptation helper below is
 * written to pick a sensible single "primary" presentation from
 * whichever real types are actually selected, never assuming exactly
 * one.
 */
class WeddingEventsModule {

    /** The real, fixed set of vendor types this category's adaptation
     * engine supports — matches the spec's own vendor_type list
     * exactly. Never extended silently; a vendor_type value read back
     * that isn't a key here is dropped rather than trusted. */
    public const VENDOR_TYPES = [
        'photographer'   => 'Wedding Photographer',
        'videographer'   => 'Wedding Videographer',
        'planner'        => 'Wedding Planner',
        'decorator'      => 'Wedding Decorator',
        'makeup_artist'  => 'Makeup Artist',
        'mehndi'         => 'Mehndi Artist',
        'caterer'        => 'Caterer',
        'dj'             => 'DJ / Entertainment',
        'event_company'  => 'Event Planning Company',
    ];

    /** Portfolio categories (Section 01) — only ever shown as a tab
     * when a vendor has at least one real portfolio item tagged with
     * it; never a fixed, always-shown list. */
    public const PORTFOLIO_CATEGORIES = [
        'weddings'             => 'Weddings',
        'pre_weddings'         => 'Pre-Weddings',
        'engagements'          => 'Engagements',
        'mehndi'               => 'Mehndi',
        'sangeet'              => 'Sangeet',
        'reception'            => 'Reception',
        'bridal'               => 'Bridal',
        'groom'                => 'Groom',
        'destination_weddings' => 'Destination Weddings',
        'corporate_events'     => 'Corporate Events',
        'birthday_events'      => 'Birthday Events',
        'private_events'       => 'Private Events',
        'decor'                => 'Decor',
        'makeup'               => 'Makeup',
    ];

    /** Reads the vendor's own selected business type(s) — a plain
     * customizer_data setting, validated here against the real,
     * fixed VENDOR_TYPES list on every read, so a forged or stale key
     * can never reach any section's adaptation logic. */
    public static function get_vendor_types( array $cd ): array {
        $raw = is_array( $cd['wedding_vendor_types'] ?? null ) ? $cd['wedding_vendor_types'] : [];
        return array_values( array_intersect( $raw, array_keys( self::VENDOR_TYPES ) ) );
    }

    /**
     * Mobile sticky action bar (the generic `.vs-mobile-cta-bar` in
     * vendor-site.php) — real fix for the client's follow-up ask beyond
     * the generic "Get Quote" default: on an events-wedding listing with
     * at least one recognized vendor_type, swap in a genuinely
     * vendor-type-adaptive label. Same documented priority order as
     * portfolio_heading() above (photography-style first), extended with
     * the planner/makeup/decor-adjacent buckets the client specifically
     * asked for. Purely additive: only ever called for events-wedding,
     * and only overrides $default when a real type actually matched —
     * every other category, and a listing with no recognized type,
     * keeps using whatever $default already resolved to (the existing
     * $mv_float_cta_txt logic, untouched).
     */
    public static function mobile_cta_label( array $vendor_types, string $default ): string {
        if ( in_array( 'photographer', $vendor_types, true ) || in_array( 'videographer', $vendor_types, true ) ) { return 'Check Date'; }
        if ( in_array( 'planner', $vendor_types, true ) || in_array( 'event_company', $vendor_types, true ) ) { return 'Plan Your Wedding'; }
        if ( in_array( 'makeup_artist', $vendor_types, true ) || in_array( 'mehndi', $vendor_types, true ) ) { return 'Book Consultation'; }
        if ( in_array( 'decorator', $vendor_types, true ) || in_array( 'caterer', $vendor_types, true ) || in_array( 'dj', $vendor_types, true ) ) { return 'Get Quote'; }
        return $default;
    }

    /**
     * Section 01's adaptive heading — picks the most fitting real
     * heading for whichever vendor type(s) are actually selected. A
     * vendor with more than one type gets the heading for whichever
     * real type is checked first below (a deliberate, documented
     * priority order — photography-style headings first since a
     * "Photography & Videography Studio" is still fundamentally a
     * portfolio-first business), never a blended or invented phrase.
     */
    public static function portfolio_heading( array $vendor_types ): string {
        if ( in_array( 'photographer', $vendor_types, true ) || in_array( 'videographer', $vendor_types, true ) ) { return 'Signature Stories'; }
        if ( in_array( 'makeup_artist', $vendor_types, true ) || in_array( 'mehndi', $vendor_types, true ) ) { return 'Wedding Portfolio'; }
        if ( in_array( 'decorator', $vendor_types, true ) ) { return 'Celebrations We\'ve Captured'; }
        return 'Our Work';
    }

    /** Section 01 — Signature Portfolio. Its own, independently-gated
     * data owned under module key 'wedding_portfolio'. */
    public static function get_portfolio_items( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'wedding_portfolio', $listing_id );
        return array_values( array_filter( (array) ( $data['items'] ?? [] ), fn( $i ) => is_array( $i ) && ! empty( $i['image'] ) ) );
    }

    /** Only the categories that at least one real portfolio item
     * actually uses — same discipline as
     * BeautySalonModule::get_active_groups(). */
    public static function get_active_portfolio_categories( array $items ): array {
        $used = [];
        foreach ( $items as $i ) {
            $c = $i['category'] ?? '';
            if ( $c !== '' && isset( self::PORTFOLIO_CATEGORIES[ $c ] ) && ! isset( $used[ $c ] ) ) {
                $used[ $c ] = self::PORTFOLIO_CATEGORIES[ $c ];
            }
        }
        return $used;
    }

    public static function get_items_for_category( array $items, string $category ): array {
        if ( $category === '' || $category === 'all' ) { return $items; }
        return array_values( array_filter( $items, fn( $i ) => ( $i['category'] ?? '' ) === $category ) );
    }

    /**
     * Section 02 — Real Weddings / Real Events. Own, independently-
     * gated data owned under module key 'wedding_stories'. A story
     * only ever surfaces here if it has a real title AND at least one
     * real photo — same "never render an empty shell" discipline as
     * get_portfolio_items() above, just applied one level deeper since
     * each story item itself nests a photos array.
     */
    public static function get_stories( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'wedding_stories', $listing_id );
        $stories = (array) ( $data['items'] ?? [] );
        return array_values( array_filter( $stories, function ( $s ) {
            if ( ! is_array( $s ) || trim( (string) ( $s['title'] ?? '' ) ) === '' ) { return false; }
            $photos = array_values( array_filter( (array) ( $s['photos'] ?? [] ), fn( $p ) => is_string( $p ) && trim( $p ) !== '' ) );
            return ! empty( $photos );
        } ) );
    }

    /**
     * Section 02's adaptive heading — same priority-order discipline as
     * portfolio_heading() above.
     */
    public static function stories_heading( array $vendor_types ): string {
        if ( in_array( 'photographer', $vendor_types, true ) || in_array( 'videographer', $vendor_types, true ) ) { return 'Real Weddings We\'ve Captured'; }
        if ( in_array( 'planner', $vendor_types, true ) || in_array( 'event_company', $vendor_types, true ) ) { return 'Real Events We\'ve Planned'; }
        if ( in_array( 'decorator', $vendor_types, true ) ) { return 'Celebrations We\'ve Styled'; }
        if ( in_array( 'caterer', $vendor_types, true ) ) { return 'Events We\'ve Catered'; }
        return 'Real Weddings & Events';
    }

    /**
     * Section 03 — Services & Experience. Own, independently-gated
     * data owned under module key 'wedding_services'. An item only
     * ever surfaces here if it has a real, non-empty title — same
     * "never render an empty shell" discipline as get_portfolio_items()
     * and get_stories() above. No photos are involved (this section is
     * deliberately text-forward, distinct from Sections 01/02).
     */
    public static function get_services( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'wedding_services', $listing_id );
        $items = (array) ( $data['items'] ?? [] );
        return array_values( array_filter( $items, fn( $i ) => is_array( $i ) && trim( (string) ( $i['title'] ?? '' ) ) !== '' ) );
    }

    /**
     * Section 03's adaptive heading — same priority-order discipline as
     * portfolio_heading() and stories_heading() above.
     */
    public static function services_heading( array $vendor_types ): string {
        if ( in_array( 'photographer', $vendor_types, true ) || in_array( 'videographer', $vendor_types, true ) ) { return 'What We Offer'; }
        if ( in_array( 'planner', $vendor_types, true ) || in_array( 'event_company', $vendor_types, true ) ) { return 'Our Planning Services'; }
        if ( in_array( 'decorator', $vendor_types, true ) ) { return 'Décor & Styling Services'; }
        if ( in_array( 'caterer', $vendor_types, true ) ) { return 'Catering Services'; }
        if ( in_array( 'makeup_artist', $vendor_types, true ) || in_array( 'mehndi', $vendor_types, true ) ) { return 'Beauty Services'; }
        if ( in_array( 'dj', $vendor_types, true ) ) { return 'Entertainment Services'; }
        return 'Our Services';
    }

    /**
     * Microcopy noun for a single Section 03 item — used only in the
     * admin panel/empty-state copy, never in stored data. Kept
     * deliberately simple: "package" reads more naturally than
     * "service" for planners/event companies, whose offerings are
     * typically sold as bundled packages rather than à la carte
     * services; every other vendor type gets the plain "service" noun.
     */
    public static function service_item_noun( array $vendor_types ): string {
        if ( in_array( 'planner', $vendor_types, true ) || in_array( 'event_company', $vendor_types, true ) ) { return 'package'; }
        return 'service';
    }

    /**
     * Section 04 — Packages & Collections. Own, independently-gated
     * data owned under module key 'wedding_packages'. An item only
     * ever surfaces here if it has a real, non-empty title — same
     * "never render an empty shell" discipline as get_services() and
     * every prior section's data helper above.
     */
    public static function get_packages( $wpdb, string $table_prefix, int $listing_id ): array {
        $data  = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'wedding_packages', $listing_id );
        $items = (array) ( $data['items'] ?? [] );
        return array_values( array_filter( $items, fn( $i ) => is_array( $i ) && trim( (string) ( $i['title'] ?? '' ) ) !== '' ) );
    }

    /**
     * Section 04's adaptive heading — same priority-order discipline as
     * portfolio_heading()/stories_heading()/services_heading() above.
     */
    public static function packages_heading( array $vendor_types ): string {
        if ( in_array( 'photographer', $vendor_types, true ) || in_array( 'videographer', $vendor_types, true ) ) { return 'Photography Packages'; }
        if ( in_array( 'planner', $vendor_types, true ) || in_array( 'event_company', $vendor_types, true ) ) { return 'Planning Packages'; }
        if ( in_array( 'decorator', $vendor_types, true ) ) { return 'Décor Packages'; }
        if ( in_array( 'caterer', $vendor_types, true ) ) { return 'Catering Packages'; }
        if ( in_array( 'makeup_artist', $vendor_types, true ) || in_array( 'mehndi', $vendor_types, true ) ) { return 'Beauty Packages'; }
        if ( in_array( 'dj', $vendor_types, true ) ) { return 'Entertainment Packages'; }
        return 'Packages & Collections';
    }

    /** The real, fixed set of creative-style tags Section 05 supports —
     * a pure customizer_data multi-select setting (like VENDOR_TYPES),
     * never a per-listing repeater. A style_tags value read back that
     * isn't a key here is dropped rather than trusted. */
    /**
     * Shape upgraded from plain key=>label to key=>['label'=>...,'desc'=>...]
     * so each style chip can render as a small card (label + one-line
     * description) instead of a bare pill. BACKWARD COMPATIBLE: this
     * const is only ever consumed for its VALUES by the render layer
     * (WeddingStyleModule) via a lookup helper (style_tag_info() below) —
     * get_style_tags() itself still only ever returns validated KEYS (see
     * its own docblock), so nothing downstream that only ever consumed
     * flat keys is affected by this shape change.
     */
    public const STYLE_TAGS = [
        'candid'      => [ 'label' => 'Candid',      'desc' => 'Natural, unposed moments' ],
        'traditional' => [ 'label' => 'Traditional', 'desc' => 'Classic rituals, timeless framing' ],
        'editorial'   => [ 'label' => 'Editorial',   'desc' => 'Magazine-inspired composition' ],
        'luxury'      => [ 'label' => 'Luxury',      'desc' => 'Polished, high-end presentation' ],
        'cinematic'   => [ 'label' => 'Cinematic',   'desc' => 'Story-driven visual pacing' ],
        'documentary' => [ 'label' => 'Documentary', 'desc' => 'Candid storytelling, minimal direction' ],
        'vintage'     => [ 'label' => 'Vintage',     'desc' => 'Warm, nostalgic tones and film feel' ],
        'modern'      => [ 'label' => 'Modern',      'desc' => 'Clean lines, contemporary styling' ],
        'minimalist'  => [ 'label' => 'Minimalist',  'desc' => 'Simple, understated, uncluttered' ],
        'destination' => [ 'label' => 'Destination', 'desc' => 'Built for travel and scenic locales' ],
        'rustic'      => [ 'label' => 'Rustic',      'desc' => 'Earthy, outdoor, handcrafted charm' ],
        'glamorous'   => [ 'label' => 'Glamorous',   'desc' => 'Bold, dramatic, statement-making' ],
    ];

    /**
     * Section 05 — Experience & Style. A plain customizer_data setting
     * (not module-registry repeater content — no per-item extra fields,
     * just a fixed multi-select), validated here against the real,
     * fixed STYLE_TAGS list on every read, same discipline as
     * get_vendor_types() above.
     *
     * Contract preserved across the STYLE_TAGS shape change above: this
     * still returns a flat array of validated KEYS only — never the
     * label/desc shape. Callers that need the label/desc for rendering
     * look it up themselves via style_tag_info() below.
     */
    public static function get_style_tags( array $cd ): array {
        $raw = is_array( $cd['wedding_style_tags'] ?? null ) ? $cd['wedding_style_tags'] : [];
        return array_values( array_intersect( $raw, array_keys( self::STYLE_TAGS ) ) );
    }

    /**
     * Render-layer-only lookup for a validated style tag key's
     * label + one-line description. Never trusts an unvalidated key —
     * returns a safe empty shape for anything not in STYLE_TAGS, so a
     * forged/stale key can never surface real-looking copy.
     */
    public static function style_tag_info( string $key ): array {
        $info = self::STYLE_TAGS[ $key ] ?? null;
        if ( ! is_array( $info ) ) { return [ 'label' => '', 'desc' => '' ]; }
        return [ 'label' => (string) ( $info['label'] ?? '' ), 'desc' => (string) ( $info['desc'] ?? '' ) ];
    }

    /**
     * Section 05's adaptive heading — same priority-order discipline as
     * every prior section's heading helper above.
     */
    public static function styles_heading( array $vendor_types ): string {
        if ( in_array( 'photographer', $vendor_types, true ) || in_array( 'videographer', $vendor_types, true ) ) { return 'Our Style'; }
        if ( in_array( 'planner', $vendor_types, true ) || in_array( 'event_company', $vendor_types, true ) ) { return 'Our Aesthetic'; }
        if ( in_array( 'decorator', $vendor_types, true ) ) { return 'Our Design Style'; }
        return 'Experience & Style';
    }

    /**
     * Section 06 — Team / Creative Experts. Own, independently-gated
     * data owned under module key 'wedding_team'. A team member only
     * ever surfaces here if it has a real, non-empty name — same
     * "never render an empty shell" discipline as every prior section's
     * data helper above (get_services()/get_packages()/etc). Photo,
     * role, bio and link are all optional per member.
     */
    public static function get_team( $wpdb, string $table_prefix, int $listing_id ): array {
        $data  = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'wedding_team', $listing_id );
        $items = (array) ( $data['items'] ?? [] );
        return array_values( array_filter( $items, fn( $i ) => is_array( $i ) && trim( (string) ( $i['name'] ?? '' ) ) !== '' ) );
    }

    /**
     * Section 06's adaptive heading — same priority-order discipline as
     * every prior section's heading helper above.
     */
    public static function team_heading( array $vendor_types ): string {
        if ( in_array( 'photographer', $vendor_types, true ) || in_array( 'videographer', $vendor_types, true ) ) { return 'Meet the Team Behind the Lens'; }
        if ( in_array( 'planner', $vendor_types, true ) || in_array( 'event_company', $vendor_types, true ) ) { return 'Meet Our Planning Team'; }
        if ( in_array( 'decorator', $vendor_types, true ) ) { return 'Meet Our Design Team'; }
        return 'Meet the Team';
    }

    /** The real, fixed set of venue/event specializations Section 07
     * supports — a fixed enum, never extended silently; a stored 'key'
     * value read back that isn't a key here is dropped rather than
     * trusted (same discipline as VENDOR_TYPES/STYLE_TAGS above). Kept
     * deliberately non-overlapping and realistic — venue *types* and
     * event *formats* a planner/decorator/event company might genuinely
     * specialize in, not a generic style or portfolio tag (those already
     * exist as PORTFOLIO_CATEGORIES/STYLE_TAGS). */
    public const VENUE_SPECIALIZATIONS = [
        'banquet_halls'       => 'Banquet Halls',
        'outdoor_garden'      => 'Outdoor / Garden Weddings',
        'destination_weddings'=> 'Destination Weddings',
        'beach_weddings'      => 'Beach Weddings',
        'palace_heritage'     => 'Palace / Heritage Venues',
        'farmhouse'           => 'Farmhouse Weddings',
        'rooftop'             => 'Rooftop Events',
        'luxury_five_star'    => 'Luxury Five-Star Venues',
        'intimate_micro'      => 'Intimate / Micro Weddings',
        'corporate_events'    => 'Corporate Events',
    ];

    /**
     * A tasteful, sensible emoji motif per VENUE_SPECIALIZATIONS key —
     * used purely as a small visual icon on each specialization card
     * (real vendor photos don't exist for an abstract "specialization"
     * concept, so a representative icon is the honest substitute, never
     * a fabricated/generic photo). Every real key has an explicit,
     * deliberately-chosen icon; a forged/unknown key (never reachable
     * here since callers only ever iterate real VENUE_SPECIALIZATIONS
     * keys) falls back to a neutral marker rather than erroring.
     */
    public const VENUE_SPEC_ICONS = [
        'banquet_halls'        => '🎪',
        'outdoor_garden'       => '🌳',
        'destination_weddings' => '✈️',
        'beach_weddings'       => '🏖️',
        'palace_heritage'      => '🏛️',
        'farmhouse'            => '🌾',
        'rooftop'              => '🏙️',
        'luxury_five_star'     => '💎',
        'intimate_micro'       => '💍',
        'corporate_events'     => '🏢',
    ];

    /** Render-layer-only icon lookup, same safe-fallback discipline as
     * style_tag_info() above. */
    public static function venue_spec_icon( string $key ): string {
        return self::VENUE_SPEC_ICONS[ $key ] ?? '📌';
    }

    /**
     * Section 07 — Venue / Event Specialisation. Own, independently-
     * gated data owned under module key 'wedding_venue_specialization'.
     * Unlike Section 05's pure customizer_data style tags, each checked
     * specialization can carry an optional per-item free-text note (e.g.
     * "20+ destination weddings across Goa and Udaipur"), which is genuine
     * per-listing content, not a simple setting — so this is fetched the
     * same repeater way as get_team() above, stored as
     * ['items' => [ ['key'=>..., 'note'=>...], ... ]].
     *
     * Every stored 'key' is re-validated against the real, fixed
     * VENUE_SPECIALIZATIONS list on every read (a forged/stale key is
     * dropped, never trusted). Results are returned in
     * VENUE_SPECIALIZATIONS's own fixed key order — not save order — so
     * the frontend always renders a stable, predictable sequence
     * regardless of how the vendor happened to check boxes; the display
     * label is attached here so render code never needs the enum map
     * itself.
     */
    public static function get_venue_specializations( $wpdb, string $table_prefix, int $listing_id ): array {
        $data  = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'wedding_venue_specialization', $listing_id );
        $items = (array) ( $data['items'] ?? [] );
        $by_key = [];
        foreach ( $items as $it ) {
            if ( ! is_array( $it ) ) { continue; }
            $key = (string) ( $it['key'] ?? '' );
            if ( ! array_key_exists( $key, self::VENUE_SPECIALIZATIONS ) ) { continue; } // forged/stale key — never trusted.
            $by_key[ $key ] = trim( (string) ( $it['note'] ?? '' ) );
        }
        $ordered = [];
        foreach ( self::VENUE_SPECIALIZATIONS as $key => $label ) {
            if ( ! array_key_exists( $key, $by_key ) ) { continue; }
            $ordered[] = [ 'key' => $key, 'label' => $label, 'note' => $by_key[ $key ] ];
        }
        return $ordered;
    }

    /**
     * Section 07's adaptive heading — same priority-order discipline as
     * every prior section's heading helper above.
     */
    public static function venue_spec_heading( array $vendor_types ): string {
        if ( in_array( 'planner', $vendor_types, true ) || in_array( 'event_company', $vendor_types, true ) ) { return 'Venues & Events We Specialize In'; }
        if ( in_array( 'decorator', $vendor_types, true ) ) { return 'Venue Styles We Transform'; }
        return 'Our Specializations';
    }

    /**
     * Section 08 — Location & Destination Coverage. Own, independently-
     * gated data owned under module key 'wedding_locations'. Unlike
     * Section 07's fixed VENUE_SPECIALIZATIONS enum, a location/city/
     * region name is genuinely open-ended vendor-entered text (there is
     * no realistic fixed list of every city/region a wedding vendor
     * might cover), so this is a plain flat repeater — same shape and
     * "never render an empty shell" discipline as get_services()/
     * get_team() above: an item only ever surfaces here if it has a
     * real, non-empty location name; the optional per-item note (e.g.
     * "+₹15,000 travel charge") is genuine per-listing content, never
     * dropped or re-validated against any enum since there is none.
     */
    public static function get_locations( $wpdb, string $table_prefix, int $listing_id ): array {
        $data  = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'wedding_locations', $listing_id );
        $items = (array) ( $data['items'] ?? [] );
        return array_values( array_filter( $items, fn( $i ) => is_array( $i ) && trim( (string) ( $i['location'] ?? '' ) ) !== '' ) );
    }

    /**
     * Section 08's "Available for Destination Weddings" flag. Unlike
     * the location list above, this is a plain customizer_data setting
     * (a single vendor-wide yes/no + optional note), not per-listing
     * repeater content — same shape as get_style_tags()/get_vendor_types()
     * above. The boolean is read here with a real, explicit cast — never
     * a loose truthy check on whatever happened to be stored (a stray
     * string like "0" or "false" must never resolve to true) — and the
     * note is defensively sanitized again at read time (sanitize_text_field()
     * is idempotent, and this guards against any legacy/malformed value
     * that slipped in before this section existed).
     *
     * @return array{available: bool, note: string}
     */
    public static function get_destination_availability( array $cd ): array {
        $raw = $cd['wedding_destination_available'] ?? false;
        // Explicit, narrow truthy check: real boolean true, or exactly
        // the strings/ints that a checked checkbox is ever actually
        // sent as ('1', 1, true). Everything else — including "0",
        // "false", "no", 0, null, '', [] — resolves to false.
        $available = ( $raw === true || $raw === 1 || $raw === '1' );
        $note = function_exists( 'sanitize_text_field' )
            ? sanitize_text_field( (string) ( $cd['wedding_destination_note'] ?? '' ) )
            : trim( (string) ( $cd['wedding_destination_note'] ?? '' ) );
        return [ 'available' => $available, 'note' => $note ];
    }

    /**
     * Section 08's adaptive heading — same priority-order discipline as
     * every prior section's heading helper above.
     */
    public static function locations_heading( array $vendor_types ): string {
        if ( in_array( 'photographer', $vendor_types, true ) || in_array( 'videographer', $vendor_types, true ) ) { return 'Where We Work'; }
        if ( in_array( 'planner', $vendor_types, true ) || in_array( 'event_company', $vendor_types, true ) ) { return 'Where We Work'; }
        return 'Locations We Cover';
    }

    /**
     * Section 10's heading. Unlike every other section, this one does
     * not branch on vendor_types: the mechanism underneath (pick a
     * date, send an enquiry) is identical whether the vendor is a
     * photographer, venue, planner, or caterer — there is no honest
     * per-type variation to surface here (no real per-type calendar
     * data exists to describe differently). A single natural heading
     * keeps the section simple rather than inventing false nuance.
     */
    public static function availability_heading( array $vendor_types ): string {
        return 'Check Our Availability';
    }

    /**
     * Section 11's heading — "Request a Quote". Same discipline as
     * availability_heading() above: the underlying mechanism (a
     * prominent form that folds into the real vsOpenInquiry() enquiry
     * popup — see WeddingQuoteModule's own header comment) is identical
     * across every vendor type, so a single natural heading is used
     * rather than inventing per-type phrasing with no real behavioural
     * difference behind it.
     */
    public static function quote_heading( array $vendor_types ): string {
        return 'Request a Free Quote';
    }

    /**
     * Section 11's ONE adaptive extra field — deliberately at most one,
     * per the build spec's "modest, not an explosion" instruction. Picked
     * per vendor_type from a small, realistic set; every type not
     * explicitly listed falls back to the universally-sensible "Estimated
     * Guest Count" (event vendors overwhelmingly care about headcount
     * regardless of specialty). Shape matches a plain HTML form field:
     * key (used as the DOM id / value carrier only — this does NOT feed
     * gs_submit_inquiry's gs_f_ custom-fields path, see WeddingQuoteModule
     * for why), label, and either 'text' or 'select' with options.
     */
    public static function extra_quote_field( array $vendor_types ): array {
        if ( in_array( 'decorator', $vendor_types, true ) ) {
            return [
                'key' => 'venue_type', 'label' => 'Venue Type', 'type' => 'select',
                'options' => [ 'Banquet Hall', 'Outdoor / Lawn', 'Hotel', 'Farmhouse', 'Home', 'Other' ],
            ];
        }
        if ( in_array( 'caterer', $vendor_types, true ) ) {
            return [ 'key' => 'guest_count', 'label' => 'Number of Guests', 'type' => 'text', 'ph' => 'e.g. 200' ];
        }
        if ( in_array( 'photographer', $vendor_types, true ) || in_array( 'videographer', $vendor_types, true ) ) {
            return [
                'key' => 'event_type', 'label' => 'Event Type', 'type' => 'select',
                'options' => [ 'Wedding', 'Pre-Wedding Shoot', 'Engagement', 'Reception', 'Other' ],
            ];
        }
        if ( in_array( 'planner', $vendor_types, true ) || in_array( 'event_company', $vendor_types, true ) ) {
            return [
                'key' => 'event_type', 'label' => 'Event Type', 'type' => 'select',
                'options' => [ 'Full Wedding', 'Single Function', 'Reception', 'Destination Wedding', 'Other' ],
            ];
        }
        return [ 'key' => 'guest_count', 'label' => 'Estimated Guest Count', 'type' => 'text', 'ph' => 'e.g. 150' ];
    }

    /**
     * Section 12's heading — "Premium Conversion Banner", the closing
     * full-bleed CTA bookend to Section 11's quote form. Adaptive by
     * vendor type, same pattern as every other *_heading() above.
     */
    public static function closing_banner_heading( array $vendor_types ): string {
        if ( in_array( 'photographer', $vendor_types, true ) || in_array( 'videographer', $vendor_types, true ) ) {
            return "Let's Bring Your Wedding Vision to Life";
        }
        if ( in_array( 'planner', $vendor_types, true ) || in_array( 'event_company', $vendor_types, true ) ) {
            return "Let's Plan Your Perfect Day";
        }
        if ( in_array( 'decorator', $vendor_types, true ) ) {
            return "Let's Style Your Celebration";
        }
        if ( in_array( 'caterer', $vendor_types, true ) ) {
            return "Let's Cater Your Perfect Event";
        }
        if ( in_array( 'makeup_artist', $vendor_types, true ) || in_array( 'mehndi', $vendor_types, true ) ) {
            return "Let's Make You Look Stunning";
        }
        if ( in_array( 'dj', $vendor_types, true ) ) {
            return "Let's Set the Mood for Your Event";
        }
        return "Let's Make Your Event Unforgettable";
    }
}
