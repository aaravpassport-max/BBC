<?php
namespace GoodService\Modules;

/**
 * TermsModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of the existing Terms & Conditions rendering
 * logic from vendor-site.php's single $_el_capture call for
 * 'terms_block'. Same genuinely single-block structure as
 * WarrantyModule — no separate title method, no $cd usage; the title
 * lives inside the data itself ($t['title']).
 */
class TermsModule {

    private static function has_real_content( $raw, string $required_key ): bool {
        if ( empty( $raw ) ) { return false; }
        $decoded = json_decode( (string) $raw, true );
        if ( ! is_array( $decoded ) ) { return false; }
        if ( array_key_exists( $required_key, $decoded ) ) {
            return ! empty( $decoded[ $required_key ] );
        }
        foreach ( $decoded as $item ) {
            if ( is_array( $item ) && ! empty( $item[ $required_key ] ?? null ) ) { return true; }
        }
        return false;
    }

    /** Faithful copy of the 'terms_block' $_el_capture callback. */
    public static function render_block( $terms_data_raw ): string {
        if ( ! self::has_real_content( $terms_data_raw, 'content' ) ) { return ''; }
        $t = is_string( $terms_data_raw ) ? ( json_decode( $terms_data_raw, true ) ?: [] ) : $terms_data_raw;
        if ( empty( $t['content'] ) ) { return ''; }
        $clauses = array_values( array_filter( array_map( 'trim', explode( "\n", $t['content'] ) ) ) );
        ob_start();
        ?>
    <details class="vs-terms-clause" style="max-width:820px;margin:0 auto">
        <summary>
            <span style="flex:1"><?php echo esc_html($t['title'] ?? 'Terms & Conditions'); ?></span>
            <span class="vs-terms-clause-arrow">▾</span>
        </summary>
        <div class="vs-terms-clause-body" style="padding-left:20px">
            <?php if (count($clauses) > 1): ?>
            <div class="vs-terms-wrap">
                <?php foreach ($clauses as $i => $clause): ?>
                <div style="display:flex;gap:12px;align-items:flex-start">
                    <span class="vs-terms-num" style="margin-top:2px"><?php echo $i + 1; ?></span>
                    <span><?php echo esc_html(ltrim($clause, '-•0123456789. ')); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <span style="white-space:pre-line"><?php echo esc_html($t['content']); ?></span>
            <?php endif; ?>
        </div>
    </details>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $terms_data_raw = $context['module_data']['terms_data']
            ?? ( $context['primary']->terms_data ?? null );
        return self::render_block( $terms_data_raw );
    }
}
