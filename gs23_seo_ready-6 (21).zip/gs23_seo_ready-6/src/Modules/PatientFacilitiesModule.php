<?php
namespace GoodService\Modules;

/**
 * PatientFacilitiesModule — Health & Wellness, module 4 of 5.
 * Deliberately named distinctly from the platform's own existing,
 * separate `FacilitiesModule` — confirmed directly before writing
 * this class that a generic "Facilities" section already exists,
 * registered under the key `facilities` for every vendor category
 * (`'categories' => 'all'`). That module is a simple title/description/
 * image/icon grid with no category grouping and no dedicated gallery —
 * it does not satisfy this request's much more specific requirements
 * (the request's own four category groups, a dedicated photo gallery,
 * a "Related Branch" field), so a distinct module was genuinely
 * needed here, registered under its own key (`patient_facilities`) to
 * avoid colliding with the existing one rather than replacing or
 * duplicating it under the same name.
 *
 * Answers "what can I expect when I visit this clinic?" — the request
 * is explicit this should communicate real facilities and patient
 * experience, not marketing claims, and explicitly warns against a
 * generic "10 feature icons" layout.
 *
 * Two independent parts, matching the request's own structure: Part
 * A, real facility entries grouped by the request's own four
 * categories (Clinic Environment, Equipment, Patient Convenience,
 * Comfort); Part B, a dedicated photo gallery reusing the exact same
 * media-library and multi-image rendering pattern already proven for
 * Property Gallery, rather than building a second gallery mechanism.
 *
 * "Only display facilities that the clinic actually provides" — this
 * class never assumes or defaults any facility as present; every
 * entry is something the vendor explicitly added.
 */
class PatientFacilitiesModule {

    public const CATEGORY_GROUPS = [
        'Clinic Environment' => [ 'reception', 'waiting_area', 'consultation_rooms', 'treatment_rooms', 'procedure_rooms', 'recovery_area' ],
        'Equipment' => [ 'diagnostic_equipment', 'treatment_equipment', 'imaging_equipment', 'laboratory' ],
        'Patient Convenience' => [ 'wheelchair_access', 'parking', 'lift', 'pharmacy', 'online_appointment', 'digital_reports', 'home_visit', 'online_consultation', 'insurance_support' ],
        'Comfort' => [ 'private_consultation', 'family_waiting', 'child_friendly', 'multilingual' ],
    ];

    public const LAYOUTS = [ 'tabs' => 'Facility Category Tabs', 'split' => 'Editorial Split', 'grid' => 'Feature Grid' ];

    public static function render_title( string $title = 'Facilities & Patient Experience', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-hw-sec-head">
        <div class="vs-hw-eyebrow">What to Expect</div>
        <h2 class="vs-sec-title vs-hw-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-hw-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    private static function group_for_category( string $category_key ): string {
        foreach ( self::CATEGORY_GROUPS as $group => $keys ) {
            if ( in_array( $category_key, $keys, true ) ) { return $group; }
        }
        return 'Other';
    }

    /** Part A — the facility list, grouped by category group when the
     * tabs layout is active. */
    public static function render_facilities( array $facilities, string $layout = 'tabs', array $img_display = [] ): string {
        $facilities = array_values( array_filter( $facilities, fn( $f ) => ! empty( $f['name'] ) ) );
        if ( empty( $facilities ) ) { return ''; }
        $layout = in_array( $layout, array_keys( self::LAYOUTS ), true ) ? $layout : 'tabs';
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];

        $grouped = [ '' => $facilities ];
        if ( $layout === 'tabs' ) {
            $grouped = [];
            foreach ( $facilities as $f ) {
                $group = self::group_for_category( $f['category'] ?? '' );
                $grouped[ $group ][] = $f;
            }
        }

        ob_start();
        ?>
    <div class="vs-hw-facilities vs-hw-facilities-layout-<?php echo esc_attr( $layout ); ?>">
        <?php foreach ( $grouped as $_group_name => $_group_facilities ): ?>
        <?php if ( $layout === 'tabs' && $_group_name !== '' ): ?><div class="vs-hw-fac-group-label"><?php echo esc_html( $_group_name ); ?></div><?php endif; ?>
        <div class="vs-hw-facilities-inner">
        <?php foreach ( $_group_facilities as $f ): ?>
        <div class="vs-hw-fac-card">
            <?php if ( $layout !== 'grid' && ! empty( $f['image'] ) ): ?>
            <div class="vs-hw-fac-media"><img src="<?php echo esc_url( $f['image'] ); ?>" alt="<?php echo esc_attr( $f['name'] ); ?>" class="vs-hw-fac-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>"></div>
            <?php endif; ?>
            <div class="vs-hw-fac-body">
                <?php if ( ! empty( $f['icon'] ) ): ?><div class="vs-hw-fac-icon"><?php echo esc_html( $f['icon'] ); ?></div><?php endif; ?>
                <div class="vs-hw-fac-name"><?php echo esc_html( $f['name'] ); ?></div>
                <?php if ( $layout !== 'grid' && ! empty( $f['description'] ) ): ?><p class="vs-hw-fac-desc"><?php echo esc_html( $f['description'] ); ?></p><?php endif; ?>
                <?php if ( ! empty( $f['branch'] ) ): ?><div class="vs-hw-fac-branch"><?php echo esc_html( $f['branch'] ); ?></div><?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /** Part B — photo gallery, reusing the exact same multi-image
     * rendering pattern already proven for Property Gallery (grid
     * layout, lightbox support), not a new gallery mechanism. */
    public static function render_gallery( array $images, array $img_display = [] ): string {
        $images = array_values( array_filter( $images, fn( $i ) => is_array( $i ) && ! empty( $i['url'] ) ) );
        if ( empty( $images ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        ob_start();
        ?>
    <div class="vs-hw-fac-gallery" id="vs-hw-facilities-gallery-grid">
        <?php foreach ( $images as $img ):
            $caption = $img['caption'] ?? '';
        ?>
        <div class="vs-hw-fac-gallery-item" onclick="vsLightbox('<?php echo esc_js( $img['url'] ); ?>','<?php echo esc_js( $caption ); ?>','vs-hw-facilities-gallery-grid')">
            <img src="<?php echo esc_url( $img['url'] ); ?>" alt="<?php echo esc_attr( $caption ); ?>" class="vs-hw-fac-gallery-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
            <?php if ( $caption !== '' ): ?><div class="vs-hw-fac-gallery-caption"><?php echo esc_html( $caption ); ?></div><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $facilities
     *     @type array  $gallery_images
     *     @type string $layout
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $facilities_html = self::render_facilities( $context['facilities'] ?? [], $context['layout'] ?? 'tabs', (array) ( $context['img_display'] ?? [] ) );
        $gallery_html = self::render_gallery( $context['gallery_images'] ?? [], (array) ( $context['img_display'] ?? [] ) );
        if ( $facilities_html === '' && $gallery_html === '' ) { return ''; } // Real feature — empty-state requirement.
        $body = '';
        if ( $facilities_html !== '' ) { $body .= $facilities_html; }
        if ( $gallery_html !== '' ) { $body .= '<div class="vs-hw-gallery-subhead">Take a Look Around</div>' . $gallery_html; }
        return self::render_title( $context['section_title'] ?? 'Facilities & Patient Experience', $context['section_description'] ?? '' ) . $body;
    }
}
