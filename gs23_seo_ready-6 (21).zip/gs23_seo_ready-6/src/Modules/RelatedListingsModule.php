<?php
namespace GoodService\Modules;

/**
 * RelatedListingsModule — Phase 2 of the modular listing architecture
 * roadmap, and the FINAL section.
 *
 * Genuinely different from every other module in one specific way: this
 * section previously had NO visibility toggle at all — confirmed by
 * checking `$_default_sec_order` (it wasn't in the list) and the render
 * condition (`if ( ! empty( $related_listings ) )`, no `$_sec_show()`
 * call anywhere). It rendered unconditionally whenever the Router found
 * related listings, with no way for a vendor to hide it even if they
 * wanted to — the roadmap's own note that this section "requires adding
 * a real feature, then wrapping it," confirmed accurate on investigation
 * rather than assumed.
 *
 * The real feature added (in vendor-site.php and create-listing.php,
 * alongside this module — see the roadmap's Section 6, item 25 for the
 * full account): 'related_listings' added to both copies of the default
 * section-order array (vendor-site.php's `$_default_sec_order` and
 * create-listing.php's `$default_sec_order`), plus a labeled entry in
 * create-listing.php's `$sec_labels` array so the existing Section Order
 * admin UI — already fully built and working for every other section —
 * shows a real, working "Similar Businesses Near You" toggle row without
 * needing any new UI to be built from scratch. The generic
 * `$_sec_show()` visibility-check infrastructure already existed and
 * already defaults to `true` for any key with no explicit saved
 * setting, so adding the check here is safe: it changes nothing for any
 * vendor who has never touched this new toggle (still always shown,
 * exactly as before), and only takes effect once a vendor explicitly
 * decides to hide it.
 *
 * NOT changed: this section's position in the page (hardcoded, right
 * before the footer, not currently part of the `$_sec_order` render
 * loop that determines position for reorderable sections) — adding
 * drag-and-drop repositioning was not asked for and is a distinct,
 * larger feature from "let a vendor hide this section," which is what
 * was actually requested.
 *
 * `$related_listings` is a genuine outer-scope variable computed once
 * in Router.php (a cached DB query via WordPress transients, ~line
 * 1450) — not derived from `$primary`, not JSON, no decode-loop
 * question applies here at all.
 *
 * No closure-capture bugs possible — this section was never wrapped in
 * any closure in the original code, plain top-level PHP.
 *
 * Faithful extraction of the existing render logic. No logic changes
 * to the actual card rendering.
 */
class RelatedListingsModule {

    public static function render_grid( array $related_listings ): string {
        if ( empty( $related_listings ) ) { return ''; }
        ob_start();
        ?>
<section class="vs-related" style="max-width:1100px;margin:0 auto;padding:40px 20px">
  <h2 style="font-size:1.3rem;font-weight:800;margin-bottom:18px">Similar Businesses Near You</h2>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px">
    <?php foreach ( $related_listings as $rl ): ?>
      <a href="<?php echo esc_url( home_url( '/' . $rl->slug . '/' ) ); ?>" style="display:block;text-decoration:none;color:inherit;border:1px solid #E5E7EB;border-radius:12px;padding:14px;transition:box-shadow .15s" onmouseover="this.style.boxShadow='0 4px 14px rgba(0,0,0,.08)'" onmouseout="this.style.boxShadow='none'">
        <?php if ( $rl->logo_url ): ?>
          <?php /* Real fix (follow-up, per explicit request): switched from
                 contain to fill — the image stretches to exactly fill the
                 card with no cropping and no letterbox gaps around a
                 non-square image (the wrapper's background is kept as a
                 harmless fallback for the instant before the image loads,
                 though fill leaves no visible gap once it has). */ ?>
          <div style="width:100%;height:100px;border-radius:8px;margin-bottom:10px;background:#F1F5F9;overflow:hidden">
            <img src="<?php echo esc_url( $rl->logo_url ); ?>" alt="<?php echo esc_attr( $rl->title ); ?>" loading="lazy" width="220" height="100" style="width:100%;height:100%;object-fit:fill">
          </div>
        <?php endif; ?>
        <div style="font-weight:700;font-size:.92rem;margin-bottom:4px"><?php echo esc_html( $rl->title ); ?></div>
        <div style="font-size:.78rem;color:#6B7280"><?php echo esc_html( $rl->city ?: '' ); ?><?php if ( $rl->review_count > 0 ): ?> · ★ <?php echo number_format( (float) $rl->avg_rating, 1 ); ?> (<?php echo (int) $rl->review_count; ?>)<?php endif; ?></div>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $related_listings = $context['related_listings'] ?? [];
        return self::render_grid( $related_listings );
    }
}
