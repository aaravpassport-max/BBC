<?php
namespace GoodService\Modules;

/**
 * DesignStylesModule — Interior Designers & Architects, module 4 of
 * 5. Answers "what is this designer actually good at?" Two vendor-
 * managed repeaters, matching the request's own "Default Design
 * Styles" + "Expertise Subcategories" split, both enriched with real,
 * computed-not-entered project counts — same real "intelligent
 * relationship" pattern already proven for Project Categories, reused
 * directly rather than reimplemented.
 *
 * Independent of Featured Projects' own activation, same pattern as
 * every cross-referencing module in this category.
 */
class DesignStylesModule {

    /** Suggested defaults shown as pre-fill hints in the admin panel
     * — the request's own list — never enforced as an enum, since
     * styles here are vendor-managed free text like Project Categories. */
    public const SUGGESTED_STYLES = [
        'Modern', 'Contemporary', 'Minimalist', 'Luxury', 'Scandinavian', 'Japandi', 'Industrial',
        'Traditional', 'Transitional', 'Art Deco', 'Modern Indian', 'Rustic', 'Mediterranean',
        'Sustainable', 'Biophilic',
    ];

    public const SUGGESTED_EXPERTISE = [
        'Space Planning', 'Luxury Interiors', 'Turnkey Interiors', 'Renovation', 'Sustainable Design',
        'Smart Homes', 'Lighting Design', 'Modular Kitchens', 'Custom Furniture', 'Architectural Planning',
        'Commercial Design', 'Hospitality Design',
    ];

    /** @param array $style_defs Vendor repeater: {name, description, image, color_palette, key_materials}. */
    public static function with_style_counts( array $style_defs, array $projects ): array {
        $counts = ProjectsModule::get_style_counts( $projects );
        $enriched = [];
        foreach ( $style_defs as $def ) {
            if ( empty( $def['name'] ) ) { continue; }
            $def['count'] = $counts[ $def['name'] ] ?? 0;
            $enriched[] = $def;
        }
        return $enriched;
    }

    /** @param array $expertise_defs Vendor repeater: {name, description}. */
    public static function with_expertise_counts( array $expertise_defs, array $projects ): array {
        $counts = ProjectsModule::get_expertise_counts( $projects );
        $enriched = [];
        foreach ( $expertise_defs as $def ) {
            if ( empty( $def['name'] ) ) { continue; }
            $def['count'] = $counts[ $def['name'] ] ?? 0;
            $enriched[] = $def;
        }
        return $enriched;
    }

    public static function render_title( string $title = 'Design Styles & Expertise', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-ida-sec-head">
        <div class="vs-ida-eyebrow">Design Language</div>
        <h2 class="vs-sec-title vs-ida-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-ida-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /** @param array $styles Already enriched via with_style_counts(). */
    public static function render_styles( array $styles, array $img_display = [], bool $hide_empty = true ): string {
        if ( $hide_empty ) {
            $styles = array_values( array_filter( $styles, fn( $s ) => ( $s['count'] ?? 0 ) > 0 ) );
        }
        if ( empty( $styles ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        ob_start();
        ?>
    <div class="vs-ida-style-row">
        <?php foreach ( $styles as $s ):
            $count = (int) ( $s['count'] ?? 0 );
        ?>
        <div class="vs-ida-style-tile" onclick="vsIdaFilterProjectsByStyle('<?php echo esc_js( $s['name'] ); ?>')">
            <?php if ( ! empty( $s['image'] ) ): ?>
                <img src="<?php echo esc_url( $s['image'] ); ?>" alt="<?php echo esc_attr( $s['name'] ); ?>" class="vs-ida-style-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
            <?php else: ?>
                <div class="vs-ida-style-img-placeholder">🎨</div>
            <?php endif; ?>
            <div class="vs-ida-style-body">
                <div class="vs-ida-style-name"><?php echo esc_html( $s['name'] ); ?></div>
                <div class="vs-ida-style-count"><?php echo $count; ?> Project<?php echo $count === 1 ? '' : 's'; ?></div>
                <?php if ( ! empty( $s['description'] ) ): ?><p class="vs-ida-style-desc"><?php echo esc_html( $s['description'] ); ?></p><?php endif; ?>
                <?php if ( ! empty( $s['color_palette'] ) ):
                    $_colors = array_filter( array_map( 'trim', explode( ',', (string) $s['color_palette'] ) ) );
                    if ( ! empty( $_colors ) ):
                ?>
                <div class="vs-ida-style-palette">
                    <?php foreach ( $_colors as $_color ): ?>
                    <span class="vs-ida-style-swatch" style="background:<?php echo esc_attr( $_color ); ?>" title="<?php echo esc_attr( $_color ); ?>"></span>
                    <?php endforeach; ?>
                </div>
                <?php endif; endif; ?>
                <?php if ( ! empty( $s['key_materials'] ) ): ?><div class="vs-ida-style-materials"><?php echo esc_html( $s['key_materials'] ); ?></div><?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /** @param array $expertise Already enriched via with_expertise_counts(). */
    public static function render_expertise( array $expertise, bool $hide_empty = false ): string {
        // Real feature — expertise tags default to always showing
        // (hide_empty=false), unlike styles: a vendor advertising
        // "Smart Homes" as a specialization before completing their
        // first smart-home project is a legitimate, common case this
        // section should still support, matching the request's own
        // framing of expertise as things the designer is "good at,"
        // not strictly things already delivered.
        if ( $hide_empty ) {
            $expertise = array_values( array_filter( $expertise, fn( $e ) => ( $e['count'] ?? 0 ) > 0 ) );
        }
        if ( empty( $expertise ) ) { return ''; }
        ob_start();
        ?>
    <div class="vs-ida-expertise-row">
        <?php foreach ( $expertise as $e ):
            $count = (int) ( $e['count'] ?? 0 );
        ?>
        <div class="vs-ida-expertise-tag"<?php echo $count > 0 ? ' onclick="vsIdaFilterProjectsByExpertise(\'' . esc_js( $e['name'] ) . '\')"' : ''; ?>>
            <span class="vs-ida-expertise-name"><?php echo esc_html( $e['name'] ); ?></span>
            <?php if ( $count > 0 ): ?><span class="vs-ida-expertise-count"><?php echo $count; ?></span><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $style_defs
     *     @type array  $expertise_defs
     *     @type array  $projects
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $projects = $context['projects'] ?? [];
        $styles_html = self::render_styles( self::with_style_counts( $context['style_defs'] ?? [], $projects ), (array) ( $context['img_display'] ?? [] ) );
        $expertise_html = self::render_expertise( self::with_expertise_counts( $context['expertise_defs'] ?? [], $projects ) );
        if ( $styles_html === '' && $expertise_html === '' ) { return ''; } // Real feature — empty-state requirement.
        $body = '';
        if ( $styles_html !== '' ) { $body .= $styles_html; }
        if ( $expertise_html !== '' ) { $body .= '<div class="vs-ida-expertise-subhead">Areas of Expertise</div>' . $expertise_html; }
        return self::render_title( $context['section_title'] ?? 'Design Styles & Expertise', $context['section_description'] ?? '' ) . $body;
    }
}
