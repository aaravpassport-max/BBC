<?php
namespace GoodService\Modules;

/**
 * PricingModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Genuinely different data-source pattern from every module built
 * earlier this session: `pricing_data` is one of the five "premium"
 * fields (team_data, clients_data, pricing_data, portfolio_data,
 * testimonials_data) that Router.php DELIBERATELY leaves empty on
 * `$primary` for performance — a cheap LENGTH() check determines
 * whether it's worth fetching at all, and the real content is only
 * fetched, decoded, and cached on demand via the
 * `$_fetch_premium_section('pricing_data')` closure (~line 833 of
 * vendor-site.php). `$primary->pricing_data` itself is NEVER the real
 * data — reading it directly would always be empty/wrong, regardless
 * of what's actually saved. This is NOT the same mechanism as the
 * global decode loop (Section 6.9) — checked this specifically before
 * writing anything, per the roadmap's guidance that Pricing/Portfolio/
 * Testimonials need this different check.
 *
 * Confirmed this is already handled correctly in the already-migrated
 * TeamModule/ClientsModule (both fetch via the same premium mechanism
 * and accept the pre-fetched array as an explicit context value,
 * documented in their own docblocks) — this module follows the exact
 * same, already-proven pattern rather than inventing a new one.
 *
 * Faithful extraction of 'pricing_title' and 'pricing_grid'. No logic
 * changes. No closure-capture bugs found here (checked explicitly per
 * the discipline established after finding two real instances in
 * Products/Items and Gallery) — this callback references only its own
 * declared use() variables ($_pricing_data, $lid), both present.
 */
class PricingModule {

    public static function render_title(): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:40px">
        <div class="vs-sec-eyebrow">Transparent Pricing</div>
        <h2 class="vs-sec-title">Choose the Right Plan</h2>
        <p class="vs-sec-sub" style="margin:8px auto 0">No hidden charges. Cancel anytime.</p>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render_grid( array $pricing_data ): string {
        if ( empty( $pricing_data ) ) { return ''; }
        $currency = \gs_setting( 'currency_symbol', '₹' );
        ob_start();
        ?>
    <div class="vs-pricing-grid">
        <?php foreach ( $pricing_data as $plan ):
            if ( empty( $plan['name'] ) ) continue;
            $featured     = ! empty( $plan['featured'] );
            $badge_text   = $plan['badge']    ?? ( $featured ? 'Most Popular' : '' );
            $features     = is_array( $plan['features'] ?? null ) ? $plan['features'] : array_filter( array_map( 'trim', explode( "\n", $plan['features'] ?? '' ) ) );
            $cta_text     = $plan['cta_text'] ?? 'Get Started';
            $cta_link     = $plan['cta_link'] ?? '#vs-sec-contact';
        ?>
        <div class="vs-pricing-card<?php echo $featured ? ' featured' : ''; ?>">
            <?php if ( $badge_text ): ?>
                <div class="vs-pricing-badge"><?php echo esc_html( $badge_text ); ?></div>
            <?php endif; ?>
            <div class="vs-pricing-name"><?php echo esc_html( $plan['name'] ); ?></div>
            <div class="vs-pricing-price">
                <?php if ( ! empty( $plan['price'] ) ): ?>
                    <?php echo esc_html( $currency . $plan['price'] ); ?><span><?php echo ! empty( $plan['period'] ) ? '/' . esc_html( $plan['period'] ) : ''; ?></span>
                <?php else: ?>
                    <span style="font-size:.95rem;font-weight:700;color:#647388">Custom</span>
                <?php endif; ?>
            </div>
            <?php if ( ! empty( $plan['description'] ) ): ?>
                <div class="vs-pricing-desc"><?php echo esc_html( $plan['description'] ); ?></div>
            <?php endif; ?>
            <?php if ( ! empty( $features ) ): ?>
            <ul class="vs-pricing-features" style="list-style:none">
                <?php foreach ( $features as $feat ):
                    $included = ! ( str_starts_with( $feat, '-' ) || str_starts_with( $feat, '✕' ) );
                    $feat_txt = ltrim( $feat, '-✕+✓ ' );
                    if ( ! $feat_txt ) continue;
                ?>
                <li class="vs-pricing-feat<?php echo $included ? '' : ' no-feat'; ?>">
                    <span class="vs-pricing-feat-ico <?php echo $included ? 'yes' : 'no'; ?>"><?php echo $included ? '✓' : '–'; ?></span>
                    <?php echo esc_html( $feat_txt ); ?>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
            <a href="<?php echo esc_url( $cta_link ); ?>" class="vs-pricing-cta"
               onclick="if(this.getAttribute('href')==='#vs-inq-open'){event.preventDefault();vsOpenInquiry({name:'<?php echo esc_js($plan['name']); ?> Plan',type:'service'});}">
                <?php echo esc_html( $cta_text ); ?>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array $pricing_data  The already-fetched pricing plans
     *                  array (via $_fetch_premium_section) — see class
     *                  docblock for why this can't be derived from
     *                  $context['primary'] directly.
     * }
     */
    public static function render( array $context ): string {
        $pricing_data = $context['pricing_data'] ?? [];
        return self::render_title() . self::render_grid( $pricing_data );
    }
}
