<?php
namespace GoodService\Modules;

/**
 * HomeServicesBeforeAfterModule — Home Services, Module 5: "Before &
 * After Work Gallery".
 *
 * Investigation performed before building (master build prompt's
 * Section 0.1): the only existing before/after gallery on the
 * platform is BeautyGalleryModule (Beauty & Salon, category-gated to
 * 'beauty-salon' only) — not a duplicate risk for Home Services, a
 * different category entirely. That module's own docblock records
 * that the draggable compare slider is itself a shared, generic
 * platform engine — window.vsIdaInitBeforeAfterSlider(sliderId),
 * originally built for Interior Designers & Architects (module 3 of
 * 5) and already reused a second time by Beauty. This module reuses
 * it a third time rather than building a parallel slider, following
 * BeautyGalleryModule's own established integration contract exactly:
 * the fixed .vs-ida-ba-* structural hook classes, with every other
 * visual element kept in this module's own gs-hba-* namespace. The
 * plain-image (no before/after pair) fallback card and its lightbox
 * reuse the platform's own generic window.vsLightbox(url, caption,
 * gridId), also matching BeautyGalleryModule's precedent exactly.
 *
 * Adds one thing Beauty's version does not need: an optional short
 * work description per item ("Kitchen sink leak repaired, new trap
 * fitted") — real, vendor-entered content describing the actual job,
 * never a fabricated claim (custom build spec's Section 33, Zero-Data
 * Handling).
 */
class HomeServicesBeforeAfterModule {

    public static function get_items( $wpdb, string $table_prefix, int $listing_id ): array {
        $stored = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'home_services_before_after', $listing_id );
        return array_values( array_filter( (array) ( $stored['items'] ?? [] ), fn( $i ) => is_array( $i ) ) );
    }

    public static function render_title( string $title = 'Before & After — See Our Work', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-hba-sec-head">
        <div class="gs-hba-eyebrow">Real Jobs, Real Results</div>
        <h2 class="vs-sec-title gs-hba-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-hba-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $img_display  fit/position/zoom — shared,
     *              gs_vs_img_display_style() helper.
     */
    public static function render_grid( array $items, array $img_display = [] ): string {
        // Same real, deliberate rule as BeautyGalleryModule: an item
        // needs EITHER a single image OR a genuine before+after pair —
        // an item with neither is not a real gallery entry and must
        // never render as an empty placeholder tile.
        $items = array_values( array_filter( $items, fn( $g ) =>
            ! empty( $g['image'] ) || ( ! empty( $g['before_image'] ) && ! empty( $g['after_image'] ) )
        ) );
        if ( empty( $items ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        $grid_id = 'gs-hba-grid';

        ob_start();
        ?>
    <div class="gs-hba-grid" id="<?php echo esc_attr( $grid_id ); ?>">
        <?php foreach ( $items as $_gi => $g ):
            $is_before_after = ! empty( $g['before_image'] ) && ! empty( $g['after_image'] );
            $title = trim( (string) ( $g['title'] ?? '' ) );
            $desc  = trim( (string) ( $g['description'] ?? '' ) );
        ?>
        <?php if ( $is_before_after ):
            $uid = 'gs-hba-ba-' . $_gi . '-' . substr( md5( $title . $g['before_image'] ), 0, 6 );
        ?>
        <div class="gs-hba-item gs-hba-item-ba">
            <div class="gs-hba-ba-slider vs-ida-ba-slider" id="<?php echo esc_attr( $uid ); ?>">
                <img src="<?php echo esc_url( $g['after_image'] ); ?>" alt="<?php echo esc_attr( $title !== '' ? $title . ' — after' : 'After' ); ?>" class="gs-hba-ba-img vs-ida-ba-after" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <div class="vs-ida-ba-before-wrap">
                    <img src="<?php echo esc_url( $g['before_image'] ); ?>" alt="<?php echo esc_attr( $title !== '' ? $title . ' — before' : 'Before' ); ?>" class="gs-hba-ba-img vs-ida-ba-before" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                </div>
                <div class="vs-ida-ba-handle gs-hba-ba-handle" style="left:50%">
                    <div class="vs-ida-ba-handle-grip gs-hba-ba-handle-grip">&#8596;</div>
                </div>
                <span class="gs-hba-ba-tag gs-hba-ba-tag-before">Before</span>
                <span class="gs-hba-ba-tag gs-hba-ba-tag-after">After</span>
            </div>
            <script>if(window.vsIdaInitBeforeAfterSlider){vsIdaInitBeforeAfterSlider('<?php echo esc_js( $uid ); ?>');}else{document.addEventListener('DOMContentLoaded',function(){vsIdaInitBeforeAfterSlider('<?php echo esc_js( $uid ); ?>');});}</script>
            <?php if ( $title !== '' || $desc !== '' ): ?>
            <div class="gs-hba-caption">
                <?php if ( $title !== '' ): ?><div class="gs-hba-caption-title"><?php echo esc_html( $title ); ?></div><?php endif; ?>
                <?php if ( $desc !== '' ): ?><div class="gs-hba-caption-desc"><?php echo esc_html( $desc ); ?></div><?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php else: ?>
        <div class="gs-hba-item">
            <a href="#" class="gs-hba-link" onclick="event.preventDefault();vsLightbox('<?php echo esc_js( $g['image'] ); ?>','<?php echo esc_js( $title ); ?>','<?php echo esc_js( $grid_id ); ?>')">
                <img src="<?php echo esc_url( $g['image'] ); ?>" alt="<?php echo esc_attr( $title !== '' ? $title : 'Completed work photo' ); ?>" class="gs-hba-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
            </a>
            <?php if ( $title !== '' || $desc !== '' ): ?>
            <div class="gs-hba-caption">
                <?php if ( $title !== '' ): ?><div class="gs-hba-caption-title"><?php echo esc_html( $title ); ?></div><?php endif; ?>
                <?php if ( $desc !== '' ): ?><div class="gs-hba-caption-desc"><?php echo esc_html( $desc ); ?></div><?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $items
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid(
            $context['items'] ?? [],
            (array) ( $context['img_display'] ?? [] )
        );
        if ( $html === '' ) { return ''; } // Mandatory empty-state — custom build spec's Section 33.
        return self::render_title( $context['section_title'] ?? 'Before & After — See Our Work', $context['section_description'] ?? '' ) . $html;
    }
}
