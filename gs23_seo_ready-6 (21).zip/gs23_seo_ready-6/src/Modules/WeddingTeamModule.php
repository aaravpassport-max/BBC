<?php
namespace GoodService\Modules;

/**
 * WeddingTeamModule — Events & Wedding, Section 06 of 6: "Team /
 * Creative Experts". Directly analogous to Beauty & Salon's
 * BeautyExpertsModule (Section 03) — same data shape (photo, name,
 * role/title, short bio) and the same "never render an empty shell"
 * discipline: a member only ever surfaces here if it has a real,
 * non-empty name (enforced in WeddingEventsModule::get_team() and
 * defensively again in render_grid() below).
 *
 * Unlike BeautyExpertsModule, a photo is optional but recommended —
 * photographers/planners/decorators often want to show a full crew
 * even before every headshot is collected — so a member with no
 * photo renders with a graceful initial-avatar fallback (first letter
 * of their name on a soft accent tile) rather than being dropped or
 * leaving a broken image. No rating/booking/verified-badge fields
 * here (those are Beauty & Salon-specific); instead each member may
 * carry one optional, simple link (a profile/Instagram URL) rendered
 * as a small icon button — kept deliberately single-purpose per the
 * build prompt's "don't over-engineer" instruction, rather than a
 * full social-links block.
 */
class WeddingTeamModule {

    /**
     * Layout variants — same proven mechanism as
     * FeaturedProjectsModule::LAYOUTS / DoctorsModule::LAYOUTS: a
     * public const on the module class, looped by a single admin
     * <select>, validated with in_array() at render time, keyed off a
     * layout-modifier class on the grid element. `grid` (the existing
     * equal grid) stays the default so upgrading never silently
     * changes an already-configured vendor page.
     *
     * `featured` directly copies DoctorsModule::LAYOUTS's own
     * `featured` layout mechanism verbatim — almost the identical
     * data shape (name/role/bio/photo) — the first member in stored
     * order renders larger/prominent (`grid-column: span 2`, same as
     * DoctorsModule's `.vs-hw-doctor-featured`), the rest render in
     * the smaller supporting grid. No new per-item vendor control is
     * added, matching DoctorsModule's own actual behavior — the
     * vendor expresses "who's first" simply by ordering the repeater
     * (the existing move-up/move-down controls every repeater already
     * has), the same way DoctorsModule's featured layout works today.
     */
    public const LAYOUTS = [
        'grid'     => 'Equal Grid',
        'featured' => 'Featured Lead',
    ];

    public static function render_title( string $heading, string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-wedding-sec-head">
        <div class="gs-wedding-eyebrow">Our Team</div>
        <h2 class="vs-sec-title gs-wedding-title"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-wedding-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /** @param string $img_fit Image Fit — site-wide image-fit audit: previously hardcoded, now a real vendor-facing setting. */
    public static function render_grid( array $items, string $layout = 'grid', string $img_fit = 'cover' ): string {
        $items = array_values( array_filter( $items, fn( $i ) => is_array( $i ) && trim( (string) ( $i['name'] ?? '' ) ) !== '' ) );
        if ( empty( $items ) ) { return ''; }
        $layout = in_array( $layout, array_keys( self::LAYOUTS ), true ) ? $layout : 'grid';
        $_img_style = \gs_vs_img_display_style( [ 'fit' => $img_fit ] )['img'];

        ob_start();
        ?>
    <div class="gs-wedding-team-grid gs-wedding-team-layout-<?php echo esc_attr( $layout ); ?>">
        <?php foreach ( $items as $_ti => $m ):
            $name  = trim( (string) ( $m['name'] ?? '' ) );
            $role  = trim( (string) ( $m['role'] ?? '' ) );
            $bio   = trim( (string) ( $m['bio'] ?? '' ) );
            $photo = trim( (string) ( $m['photo'] ?? '' ) );
            $link  = trim( (string) ( $m['link'] ?? '' ) );
            $is_featured = ( $_ti === 0 && $layout === 'featured' );
            $initial = function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( $name, 0, 1 ) ) : strtoupper( substr( $name, 0, 1 ) );
        ?>
        <div class="gs-wedding-team-card<?php echo $is_featured ? ' gs-wedding-team-featured' : ''; ?>">
            <?php if ( $photo !== '' ): ?>
            <img src="<?php echo esc_url( $photo ); ?>" alt="<?php echo esc_attr( $name ); ?>" class="gs-wedding-team-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
            <?php else: ?>
            <div class="gs-wedding-team-img gs-wedding-team-img-fallback" aria-hidden="true"><?php echo esc_html( $initial ); ?></div>
            <?php endif; ?>
            <div class="gs-wedding-team-body">
                <div class="gs-wedding-team-name"><?php echo esc_html( $name ); ?></div>
                <?php if ( $role !== '' ): ?><div class="gs-wedding-team-role"><?php echo esc_html( $role ); ?></div><?php endif; ?>
                <?php if ( $bio !== '' ): ?><p class="gs-wedding-team-bio"><?php echo esc_html( $bio ); ?></p><?php endif; ?>
                <?php if ( $link !== '' ): ?>
                <a href="<?php echo esc_url( $link ); ?>" class="gs-wedding-team-link" target="_blank" rel="noopener noreferrer" title="View profile" aria-label="View <?php echo esc_attr( $name ); ?>'s profile">🔗</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $items          each with name/role/bio/photo/link
     *     @type array  $vendor_types
     *     @type string $section_title  vendor override; falls back to the adaptive heading when blank.
     *     @type string $section_description
     *     @type string $layout
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid( (array) ( $context['items'] ?? [] ), (string) ( $context['layout'] ?? 'grid' ), (string) ( $context['img_fit'] ?? 'cover' ) );
        if ( $html === '' ) { return ''; } // Mandatory empty-state.
        $heading = trim( (string) ( $context['section_title'] ?? '' ) );
        if ( $heading === '' ) {
            $heading = \GoodService\Modules\WeddingEventsModule::team_heading( (array) ( $context['vendor_types'] ?? [] ) );
        }
        return self::render_title( $heading, (string) ( $context['section_description'] ?? '' ) ) . $html;
    }
}
