<?php
namespace GoodService\Modules;

/**
 * TrustBarModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Genuinely different shape from every module built so far: Trust Bar
 * is NOT rendered via $_el_capture. Confirmed directly (comment at the
 * original render site): "trust_bar [is] rendered directly in the hero
 * HTML below (not via el_capture) because [it has] fixed position[s]"
 * — it's an element belonging to the 'hero' section group (registered
 * as `['hero', 80, 'Trust Bar (scrolling)']`), not a top-level section
 * with its own $_sec_show() key. Its only visibility control is the
 * element-level `$_elget('trust_bar')['vis']` flag, checked inline at
 * the render call site alongside a content check (`&& $trust_bar`).
 *
 * Per Section 5's guidance for sections with no $_el_capture wrapper:
 * the flag-gated integration point still works the same way — wrap the
 * inline block in the same if(defined(...)) check — it just isn't
 * inside an $_el_capture callback to begin with. Because there's no
 * existing external gate calling this, render() takes the visibility
 * flag as an explicit parameter, replicating the original's exact
 * `if ($_tb_cfg['vis'] && $trust_bar)` condition internally rather
 * than assuming a caller already checked it.
 *
 * No JSON-decode concern here — $trust_bar is a plain text field
 * (`$primary->trust_bar_text`), never JSON.
 */
class TrustBarModule {

    /**
     * The detailed render logic, taking every input explicitly —
     * mirrors the original inline block's exact parameters.
     */
    public static function render_bar(
        bool $visible,
        ?string $trust_bar_text,
        ?string $cv_tb_bg,
        int $cv_tb_padding,
        int $cv_tb_radius,
        bool $cv_tb_pause_hover,
        int $cv_marquee_speed,
        string $cv_tb_direction,
        int $cv_tb_gap,
        string $cv_tb_align
    ): string {
        if ( ! $visible || ! $trust_bar_text ) { return ''; }

        $tb_items = array_filter( array_map( 'trim', explode( '•', $trust_bar_text ) ) );
        if ( empty( $tb_items ) ) { $tb_items = array_filter( array_map( 'trim', explode( ',', $trust_bar_text ) ) ); }
        if ( empty( $tb_items ) ) { $tb_items = [ $trust_bar_text ]; }
        $tb_html = '';
        foreach ( $tb_items as $tbi ) { $tb_html .= '<span>' . esc_html( $tbi ) . '</span>'; }

        ob_start();
        ?>
<div class="vs-trust-bar" style="<?php
    if ($cv_tb_bg) echo 'background:'.esc_attr($cv_tb_bg).';';
    echo 'padding:'.$cv_tb_padding.'px 0;';
    if ($cv_tb_radius) echo 'border-radius:'.$cv_tb_radius.'px;';
  ?>"><div style="overflow:hidden;<?php echo $cv_tb_pause_hover ? '' : ''; ?>" class="<?php echo $cv_tb_pause_hover ? 'vs-tb-pause-hover' : ''; ?>"><div class="vs-trust-marquee" style="animation-duration:<?php echo $cv_marquee_speed; ?>s;animation-direction:<?php echo $cv_tb_direction === 'right' ? 'reverse' : 'normal'; ?>;gap:<?php echo $cv_tb_gap; ?>px;justify-content:<?php echo $cv_tb_align === 'center' ? 'center' : ( $cv_tb_align === 'right' ? 'flex-end' : 'flex-start' ); ?>"><?php echo $tb_html.$tb_html; ?></div></div></div>
<?php
        return ob_get_clean();
    }

    /**
     * Standard render(array $context): string contract, matching every
     * other module. Extracts trust-bar-specific values out of the
     * shared $context array (as built once per page load) and delegates
     * to render_bar(). Not currently invoked by the live page (Section
     * 9, item 1 — the registry isn't wired into real rendering yet);
     * exists so this module is consistent with the same contract every
     * other registered module already implements, for when Phase 3b
     * needs it.
     */
    public static function render( array $context ): string {
        $cd = $context['cd'] ?? [];
        return self::render_bar(
            (bool) ( $context['visible'] ?? true ),
            $context['trust_bar_text'] ?? null,
            $cd['trust_bar_bg'] ?? '',
            max( 0, min( 60, (int) ( $cd['trust_bar_padding'] ?? 12 ) ) ),
            max( 0, min( 40, (int) ( $cd['trust_bar_radius'] ?? 0 ) ) ),
            ( $cd['trust_bar_pause_hover'] ?? 1 ) ? true : false,
            max( 5, min( 120, (int) ( $cd['trust_bar_speed'] ?? 28 ) ) ),
            in_array( $cd['trust_bar_direction'] ?? '', ['left','right'], true ) ? $cd['trust_bar_direction'] : 'left',
            max( 0, min( 200, (int) ( $cd['trust_bar_gap'] ?? 48 ) ) ),
            in_array( $cd['trust_bar_align'] ?? '', ['left','center','right'], true ) ? $cd['trust_bar_align'] : 'left'
        );
    }
}
