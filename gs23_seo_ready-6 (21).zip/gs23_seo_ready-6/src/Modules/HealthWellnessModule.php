<?php
namespace GoodService\Modules;

/**
 * HealthWellnessModule — the foundational data-access layer for the
 * Health & Wellness category build (5 sections total).
 *
 * ASSUMPTION, per this session's master prompt (Section 0.2): the
 * category slug is 'health-wellness', confirmed directly from the
 * user's stated real category name ("Health & Wellness") run through
 * this platform's own real slug-generation function — not guessed.
 *
 * Architecturally different from the Interior Designers & Architects
 * foundation: there, one module (Featured Projects) owned all the
 * data every other module read from. Here, the request's own "Cross-
 * Section Intelligence" hierarchy (Department → Doctors → Services →
 * Facilities → Patient Journey) means Departments connects to TWO
 * separate, independently-owned data sources — Services (owned by
 * FeaturedServicesModule) and Doctors (owned by DoctorsModule) — so
 * this shared layer reads from both rather than a single owner,
 * matching the real relationship the request describes rather than
 * forcing IDA's simpler shape onto a genuinely different structure.
 */
class HealthWellnessModule {

    public const SERVICE_CATEGORIES = [
        'general_consultation' => 'General Consultation', 'diagnostics' => 'Diagnostics',
        'preventive_care' => 'Preventive Care', 'dental_care' => 'Dental Care',
        'physiotherapy' => 'Physiotherapy', 'dermatology' => 'Dermatology',
        'cardiology' => 'Cardiology', 'orthopaedics' => 'Orthopaedics',
        'womens_health' => "Women's Health", 'child_healthcare' => 'Child Healthcare',
        'eye_care' => 'Eye Care', 'ent' => 'ENT', 'mental_wellness' => 'Mental Wellness',
        'nutrition' => 'Nutrition', 'rehabilitation' => 'Rehabilitation', 'other' => 'Other',
    ];

    public const FACILITY_CATEGORIES = [
        'reception' => 'Reception', 'waiting_area' => 'Waiting Area', 'consultation_rooms' => 'Consultation Rooms',
        'treatment_rooms' => 'Treatment Rooms', 'procedure_rooms' => 'Procedure Rooms', 'recovery_area' => 'Recovery Area',
        'diagnostic_equipment' => 'Diagnostic Equipment', 'treatment_equipment' => 'Treatment Equipment',
        'imaging_equipment' => 'Imaging Equipment', 'laboratory' => 'Laboratory Facilities',
        'wheelchair_access' => 'Wheelchair Accessibility', 'parking' => 'Parking', 'lift' => 'Lift / Elevator',
        'pharmacy' => 'Pharmacy', 'online_appointment' => 'Online Appointment', 'digital_reports' => 'Digital Reports',
        'home_visit' => 'Home Visit', 'online_consultation' => 'Online Consultation', 'insurance_support' => 'Insurance / TPA Support',
        'private_consultation' => 'Private Consultation', 'family_waiting' => 'Family Waiting Area',
        'child_friendly' => 'Child-Friendly Area', 'multilingual' => 'Multilingual Support',
    ];

    /** Real feature — never fabricated: this platform never generates
     * or displays medical claims, cure guarantees, or credentials on
     * its own. Every field these modules render is vendor-entered
     * text, verbatim, with no synthesized language anywhere in this
     * codebase — the request's own explicit safety requirement is
     * satisfied by construction (there is no generation path to
     * misuse), not by a runtime filter trying to catch bad output. */

    public static function get_services( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'featured_services', $listing_id );
        return array_values( array_filter( (array) ( $data['services'] ?? [] ), fn( $s ) => is_array( $s ) && ! empty( $s['name'] ) ) );
    }

    public static function get_doctors( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'doctors', $listing_id );
        return array_values( array_filter( (array) ( $data['doctors'] ?? [] ), fn( $d ) => is_array( $d ) && ! empty( $d['name'] ) ) );
    }

    /** Real feature — "the number of services should preferably be
     * calculated automatically rather than manually entered," matching
     * the request's own explicit example ("Dermatology — 8 Services"). */
    public static function get_department_service_counts( array $services ): array {
        $counts = [];
        foreach ( $services as $s ) {
            $dept = trim( (string) ( $s['department'] ?? '' ) );
            if ( $dept === '' ) { continue; }
            $counts[ $dept ] = ( $counts[ $dept ] ?? 0 ) + 1;
        }
        return $counts;
    }

    /** A department's related doctors — matched by each doctor's own
     * department field, same real cross-referencing principle as
     * every other "intelligent relationship" built this session. */
    public static function get_doctors_for_department( array $doctors, string $department_name ): array {
        return array_values( array_filter( $doctors, fn( $d ) => ( $d['department'] ?? '' ) === $department_name ) );
    }

    /** A department's related services — same matching principle. */
    public static function get_services_for_department( array $services, string $department_name ): array {
        return array_values( array_filter( $services, fn( $s ) => ( $s['department'] ?? '' ) === $department_name ) );
    }

    /** A service's related doctor(s) — matched by department, since a
     * service names its department, not a specific doctor directly
     * (a service can have several doctors who perform it). A service
     * can also optionally name one specific doctor directly via its
     * own 'related_doctor' field, which takes precedence when set. */
    public static function get_doctors_for_service( array $doctors, array $service ): array {
        if ( ! empty( $service['related_doctor'] ) ) {
            $direct = array_values( array_filter( $doctors, fn( $d ) => $d['name'] === $service['related_doctor'] ) );
            if ( ! empty( $direct ) ) { return $direct; }
        }
        if ( ! empty( $service['department'] ) ) {
            return self::get_doctors_for_department( $doctors, $service['department'] );
        }
        return [];
    }

    /** A doctor's own matched services — the reverse of
     * get_doctors_for_service(). A service matches this doctor either
     * because it names them directly (related_doctor) or shares their
     * department, same real relationship, read from the other
     * direction for the Doctors module's own "Available Services"
     * requirement. */
    public static function get_services_for_doctor( array $services, array $doctor ): array {
        return array_values( array_filter( $services, function ( $s ) use ( $doctor ) {
            if ( ! empty( $s['related_doctor'] ) && $s['related_doctor'] === $doctor['name'] ) { return true; }
            if ( ! empty( $doctor['department'] ) && ( $s['department'] ?? '' ) === $doctor['department'] ) { return true; }
            return false;
        } ) );
    }
}
