<?php
namespace GoodService\Modules;

/**
 * DesignProcessModule — Interior Designers & Architects, module 5 of
 * 5, the final module in this category build. Answers "what happens
 * after I contact this designer?" Deliberately the lightest module in
 * this category, matching the request's own explicit complexity
 * ranking — a single repeater of process steps, no cross-referencing
 * to Projects at all, fully independent by construction rather than
 * by an explicit gate check.
 *
 * A default 7-step process (matching the request's own suggested
 * structure) is provided as pre-fill in the admin panel, not enforced
 * in this class — the request is explicit that every part of it
 * (add/remove/reorder/rename/edit) must be vendor-editable, so this
 * class makes no assumption about how many steps exist or what they
 * are called.
 */
class DesignProcessModule {

    public const LAYOUTS = [
        'timeline'  => 'Timeline',
        'vertical'  => 'Vertical Process',
        'horizontal' => 'Horizontal Process',
        'editorial' => 'Editorial Process',
    ];

    /** Suggested default steps shown as admin panel pre-fill — the
     * request's own 7-step structure — never enforced here. */
    public const SUGGESTED_STEPS = [
        [ 'name' => 'Discovery', 'description' => "Understand the client's requirements, lifestyle, goals and expectations." ],
        [ 'name' => 'Site & Requirement Assessment', 'description' => 'Understand the space, dimensions, constraints and functional requirements.' ],
        [ 'name' => 'Concept Development', 'description' => 'Develop the design direction, mood, layout and overall concept.' ],
        [ 'name' => '3D Visualization', 'description' => 'Present realistic visualizations so the client can understand the proposed space.' ],
        [ 'name' => 'Materials & Design Finalization', 'description' => 'Finalize finishes, materials, furniture, lighting and other design elements.' ],
        [ 'name' => 'Execution', 'description' => 'Coordinate execution, installation and implementation according to the selected service scope.' ],
        [ 'name' => 'Final Handover', 'description' => 'Complete the project and hand over the finished space.' ],
    ];

    public static function render_title( string $title = 'Our Design Process', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-ida-sec-head">
        <div class="vs-ida-eyebrow">How We Work</div>
        <h2 class="vs-sec-title vs-ida-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-ida-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $steps  Each entry {name, description, image,
     *              duration, deliverable}. Step numbers are derived
     *              from array position (1-indexed) at render time —
     *              never stored — so reordering in the admin panel is
     *              reflected automatically without a separate
     *              renumbering step.
     */
    public static function render_steps( array $steps, string $layout = 'timeline', array $img_display = [] ): string {
        $steps = array_values( array_filter( $steps, fn( $s ) => ! empty( $s['name'] ) ) );
        if ( empty( $steps ) ) { return ''; }
        $layout = in_array( $layout, array_keys( self::LAYOUTS ), true ) ? $layout : 'timeline';
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        ob_start();
        ?>
    <div class="vs-ida-process vs-ida-process-<?php echo esc_attr( $layout ); ?>">
        <?php foreach ( $steps as $i => $step ):
            $num = $i + 1;
        ?>
        <div class="vs-ida-process-step">
            <div class="vs-ida-process-num"><?php echo str_pad( (string) $num, 2, '0', STR_PAD_LEFT ); ?></div>
            <?php if ( $layout === 'editorial' && ! empty( $step['image'] ) ): ?>
                <div class="vs-ida-process-img-wrap"><img src="<?php echo esc_url( $step['image'] ); ?>" alt="<?php echo esc_attr( $step['name'] ); ?>" class="vs-ida-process-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>"></div>
            <?php endif; ?>
            <div class="vs-ida-process-body">
                <div class="vs-ida-process-name"><?php echo esc_html( $step['name'] ); ?></div>
                <?php if ( ! empty( $step['description'] ) ): ?><p class="vs-ida-process-desc"><?php echo esc_html( $step['description'] ); ?></p><?php endif; ?>
                <?php if ( ! empty( $step['duration'] ) || ! empty( $step['deliverable'] ) ): ?>
                <div class="vs-ida-process-meta">
                    <?php if ( ! empty( $step['duration'] ) ): ?><span class="vs-ida-process-duration">⏱ <?php echo esc_html( $step['duration'] ); ?></span><?php endif; ?>
                    <?php if ( ! empty( $step['deliverable'] ) ): ?><span class="vs-ida-process-deliverable">📄 <?php echo esc_html( $step['deliverable'] ); ?></span><?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <?php if ( $num < count( $steps ) ): ?><div class="vs-ida-process-connector" aria-hidden="true"></div><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $steps
     *     @type string $layout
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_steps( $context['steps'] ?? [], $context['layout'] ?? 'timeline', (array) ( $context['img_display'] ?? [] ) );
        if ( $html === '' ) { return ''; } // Real feature — empty-state requirement.
        return self::render_title( $context['section_title'] ?? 'Our Design Process', $context['section_description'] ?? '' ) . $html;
    }
}
