<?php
namespace GoodService\Modules;

/**
 * TeamModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of the existing Team rendering logic from
 * vendor-site.php's $_el_capture calls for 'team_title' and
 * 'team_grid'.
 *
 * Two genuine structural differences from every module migrated so
 * far, both confirmed by tracing the real code before writing anything:
 *
 * 1. The title is hardcoded ("Meet Our Team") — the original callback's
 *    use() clause is empty, meaning it references no $cd/$hd data at
 *    all. render_title() correctly takes no parameters.
 *
 * 2. team_data is NOT part of $primary. It's deliberately excluded
 *    from the main listing query (see $_fetch_premium_section() in
 *    vendor-site.php, which explicitly documents this as a performance
 *    optimization — a cheap LENGTH() check determines whether the
 *    real content is even worth a separate query, avoiding that query
 *    entirely for any vendor who's never touched this section). This
 *    module therefore receives the already-fetched team data directly
 *    via $context['team_data'], never attempting to read it from
 *    $context['primary'], which never has this column.
 */
class TeamModule {

    /** Faithful copy of the 'team_title' $_el_capture callback — no
     * parameters, matching the original's genuinely empty use() clause. */
    public static function render_title(): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">The People Behind The Work</div>
        <h2 class="vs-sec-title">Meet Our Team</h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /** Faithful copy of the 'team_grid' $_el_capture callback. */
    /** @param string $img_fit Image Fit — site-wide image-fit audit: previously hardcoded, now a real vendor-facing setting. */
    public static function render_grid( array $team_data, string $img_fit = 'cover' ): string {
        if ( empty( $team_data ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( [ 'fit' => $img_fit ] )['img'];
        ob_start();
        ?>
    <div class="vs-team-grid">
        <?php foreach ( $team_data as $tm ):
            if ( empty( $tm['name'] ) ) continue;
            $initials = strtoupper( implode( '', array_map( fn($w) => $w[0], array_slice( explode( ' ', trim( $tm['name'] ) ), 0, 2 ) ) ) );
        ?>
        <div class="vs-team-card">
            <?php if ( ! empty( $tm['photo'] ) ): ?>
                <img src="<?php echo esc_url( $tm['photo'] ); ?>" alt="<?php echo esc_attr( $tm['name'] ); ?>" class="vs-team-photo" loading="lazy" width="400" height="400" style="<?php echo esc_attr( $_img_style ); ?>">
            <?php else: ?>
                <div class="vs-team-photo-placeholder"><?php echo esc_html( $initials ); ?></div>
            <?php endif; ?>
            <div class="vs-team-body">
                <div class="vs-team-name"><?php echo esc_html( $tm['name'] ); ?></div>
                <?php if ( ! empty( $tm['role'] ) ): ?>
                    <div class="vs-team-role"><?php echo esc_html( $tm['role'] ); ?></div>
                <?php endif; ?>
                <?php if ( ! empty( $tm['bio'] ) ): ?>
                    <div class="vs-team-bio"><?php echo esc_html( $tm['bio'] ); ?></div>
                <?php endif; ?>
                <?php
                $socials = [
                    'linkedin'  => [ $tm['linkedin']  ?? '', 'in',  'LinkedIn'  ],
                    'twitter'   => [ $tm['twitter']   ?? '', 'X',   'X/Twitter' ],
                    'instagram' => [ $tm['instagram'] ?? '', '📷',  'Instagram' ],
                    'email'     => [ $tm['email']     ?? '', '✉',   'Email'     ],
                ];
                $has_social = array_filter( array_column( $socials, 0 ) );
                if ( $has_social ): ?>
                <div class="vs-team-socials">
                    <?php foreach ( $socials as [$url, $icon, $label] ):
                        if ( ! $url ) continue;
                        $href = ( $label === 'Email' ) ? 'mailto:' . $url : $url;
                    ?>
                    <a href="<?php echo esc_url( $href ); ?>" class="vs-team-social-link" target="<?php echo $label==='Email'?'_self':'_blank'; ?>" rel="noopener" title="<?php echo esc_attr( $label ); ?>"><?php echo $icon; ?></a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array $team_data  The already-fetched team array — see
     *                  class docblock for why this can't be derived
     *                  from $context['primary'].
     * }
     */
    public static function render( array $context ): string {
        $team_data = $context['team_data'] ?? [];
        return self::render_title() . self::render_grid( $team_data, (string) ( $context['img_fit'] ?? 'cover' ) );
    }
}
