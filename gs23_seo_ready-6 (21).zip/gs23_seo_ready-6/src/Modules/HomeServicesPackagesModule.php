<?php
namespace GoodService\Modules;

/**
 * HomeServicesPackagesModule — Home Services, Module 2: "Packages &
 * Maintenance Plans." Combines the custom build spec's Section 03
 * ("Service Packages / Bundles") and its recurring-maintenance/AMC
 * concept into one module, per the spec's own Section 32 Data-Density
 * Requirement — a one-time discounted bundle and a recurring annual
 * maintenance plan are the same underlying idea (a fixed price for a
 * defined scope of work) and do not warrant two separate thin
 * sections.
 *
 * Follows BeautyPackagesModule's established, explicit "no fake
 * urgency" discipline: no countdown timer, no invented "X people
 * booked this" claim, no "Hurry" copy. The only time/price signals are
 * ones the vendor actually typed — an optional real "valid until"
 * date (checked against today; an expired one-time offer is not
 * rendered), a savings amount computed by plain arithmetic, and a
 * plan's own vendor-entered "billed every" cadence label — never an
 * inferred or fabricated one.
 */
class HomeServicesPackagesModule {

    /** A plan's billing cadence — vendor-selected, never inferred.
     * 'one_time' covers a single discounted service bundle; the three
     * AMC options cover a recurring maintenance contract. */
    public const PLAN_TYPES = [
        'one_time'     => 'One-Time Package',
        'amc_monthly'  => 'Monthly Maintenance Plan',
        'amc_quarterly'=> 'Quarterly Maintenance Plan',
        'amc_yearly'   => 'Annual Maintenance Contract (AMC)',
    ];

    public static function get_plans( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'home_services_packages', $listing_id );
        return array_values( array_filter( (array) ( $data['plans'] ?? [] ), fn( $p ) => is_array( $p ) && ! empty( $p['name'] ) ) );
    }

    public static function render_title( string $title = 'Packages & Maintenance Plans', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-hpkg-eyebrow">Save With a Plan</div>
    <h2 class="vs-sec-title gs-hpkg-title"><?php echo esc_html( $title ); ?></h2>
    <?php if ( $description !== '' ): ?><p class="gs-hpkg-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
<?php
        return ob_get_clean();
    }

    /** Same real-expiry discipline as BeautyPackagesModule: a plan
     * with no vendor-set expiry is always still valid; an unparseable
     * date is never treated as expired (never silently discard real
     * vendor data on a format guess); a real past date IS expired and
     * is dropped from the grid entirely — reflecting the vendor's own
     * data, not fabricating new urgency copy about it. AMC plans
     * (recurring) almost never carry a valid_until at all in practice,
     * but the same rule applies uniformly rather than special-casing
     * plan_type here. */
    private static function is_still_valid( array $p ): bool {
        $valid_until = trim( (string) ( $p['valid_until'] ?? '' ) );
        if ( $valid_until === '' ) { return true; }
        $ts = strtotime( $valid_until );
        if ( $ts === false ) { return true; }
        return $ts >= strtotime( 'today' );
    }

    private static function cadence_suffix( string $plan_type ): string {
        return match ( $plan_type ) {
            'amc_monthly'   => '/month',
            'amc_quarterly' => '/quarter',
            'amc_yearly'    => '/year',
            default         => '',
        };
    }

    public static function render_grid( array $plans, array $img_display = [], string $currency = '₹' ): string {
        $active = array_values( array_filter( $plans, [ self::class, 'is_still_valid' ] ) );
        if ( empty( $active ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];

        ob_start();
        ?>
    <div class="gs-hpkg-grid">
        <?php foreach ( $active as $p ):
            $name         = (string) $p['name'];
            $description  = (string) ( $p['description'] ?? '' );
            $plan_type    = (string) ( $p['plan_type'] ?? 'one_time' );
            $plan_type    = isset( self::PLAN_TYPES[ $plan_type ] ) ? $plan_type : 'one_time';
            $badge        = (string) ( $p['badge'] ?? '' );
            $image        = (string) ( $p['image'] ?? '' );
            $valid_until  = trim( (string) ( $p['valid_until'] ?? '' ) );
            $visits       = trim( (string) ( $p['visits_included'] ?? '' ) );
            $is_recommended = ! empty( $p['is_recommended'] );
            $features     = array_values( array_filter( array_map( 'trim', (array) ( $p['features'] ?? [] ) ), fn( $f ) => $f !== '' ) );

            $orig_raw  = trim( (string) ( $p['original_price'] ?? '' ) );
            $offer_raw = trim( (string) ( $p['offer_price'] ?? '' ) );
            $orig  = is_numeric( $orig_raw ) ? (float) $orig_raw : null;
            $offer = is_numeric( $offer_raw ) ? (float) $offer_raw : null;

            $show_strike = ( $orig !== null && $offer !== null && $offer < $orig );
            $savings     = $show_strike ? ( $orig - $offer ) : null;
            $single_price = null;
            if ( ! $show_strike ) {
                if ( $offer !== null ) { $single_price = $offer; }
                elseif ( $orig !== null ) { $single_price = $orig; }
            }
            $suffix = self::cadence_suffix( $plan_type );
            $price_label_override = trim( (string) ( $p['price_label'] ?? '' ) );
        ?>
        <div class="gs-hpkg-card<?php echo $is_recommended ? ' gs-hpkg-recommended' : ''; ?>">
            <?php if ( $is_recommended ): ?><div class="gs-hpkg-rec-ribbon">Most Popular</div><?php endif; ?>
            <?php if ( $image !== '' ): ?>
            <div class="gs-hpkg-media">
                <img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $name ); ?>" class="gs-hpkg-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php if ( $badge !== '' ): ?><span class="gs-hpkg-badge"><?php echo esc_html( $badge ); ?></span><?php endif; ?>
            </div>
            <?php elseif ( $badge !== '' ): ?>
            <span class="gs-hpkg-badge gs-hpkg-badge-noimg"><?php echo esc_html( $badge ); ?></span>
            <?php endif; ?>
            <div class="gs-hpkg-body">
                <div class="gs-hpkg-type"><?php echo esc_html( self::PLAN_TYPES[ $plan_type ] ); ?></div>
                <div class="gs-hpkg-name"><?php echo esc_html( $name ); ?></div>
                <?php if ( $description !== '' ): ?><p class="gs-hpkg-card-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>

                <?php if ( $show_strike ): ?>
                <div class="gs-hpkg-price-row">
                    <span class="gs-hpkg-price-orig"><?php echo esc_html( $currency . number_format( $orig, 0 ) ); ?></span>
                    <span class="gs-hpkg-price-offer"><?php echo esc_html( $currency . number_format( $offer, 0 ) . $suffix ); ?></span>
                </div>
                <div class="gs-hpkg-save">You save <?php echo esc_html( $currency . number_format( $savings, 0 ) ); ?></div>
                <?php elseif ( $single_price !== null ): ?>
                <div class="gs-hpkg-price-row"><span class="gs-hpkg-price-offer"><?php echo esc_html( $currency . number_format( $single_price, 0 ) . $suffix ); ?></span></div>
                <?php elseif ( $price_label_override !== '' ): ?>
                <div class="gs-hpkg-price-row"><span class="gs-hpkg-price-offer"><?php echo esc_html( $price_label_override ); ?></span></div>
                <?php endif; ?>

                <?php if ( $visits !== '' ): ?><div class="gs-hpkg-visits">🗓️ <?php echo esc_html( $visits ); ?></div><?php endif; ?>

                <?php if ( ! empty( $features ) ): ?>
                <ul class="gs-hpkg-features">
                    <?php foreach ( $features as $f ): ?><li><?php echo esc_html( $f ); ?></li><?php endforeach; ?>
                </ul>
                <?php endif; ?>

                <?php if ( $valid_until !== '' && strtotime( $valid_until ) !== false ): ?>
                <div class="gs-hpkg-valid">Valid until <?php echo esc_html( date_i18n( 'j M Y', strtotime( $valid_until ) ) ); ?></div>
                <?php endif; ?>

                <button type="button" class="gs-hpkg-cta" onclick="vsOpenInquiry({name:'<?php echo esc_js( $name ); ?>',type:'service',price:'<?php echo esc_js( $single_price !== null ? ( $currency . number_format( $single_price, 0 ) . $suffix ) : ( $show_strike ? ( $currency . number_format( $offer, 0 ) . $suffix ) : '' ) ); ?>'})">Enquire About This Plan</button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $plans
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     *     @type string $currency
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid(
            (array) ( $context['plans'] ?? [] ),
            (array) ( $context['img_display'] ?? [] ),
            (string) ( $context['currency'] ?? '₹' )
        );
        if ( $html === '' ) { return ''; }
        return '<div class="gs-hpkg-sec-head">' . self::render_title( $context['section_title'] ?? 'Packages & Maintenance Plans', $context['section_description'] ?? '' ) . '</div>' . $html;
    }
}
