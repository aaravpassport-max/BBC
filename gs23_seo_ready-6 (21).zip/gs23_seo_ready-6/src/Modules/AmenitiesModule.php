<?php
namespace GoodService\Modules;

/**
 * AmenitiesModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of the existing Amenities rendering logic (title
 * block + tile grid) from vendor-site.php's $_el_capture calls for
 * 'amenities_title' and 'amenities_grid'. Structurally identical to
 * HighlightsModule (Phase 1) — same title/grid split, same icon-or-image
 * handling — confirming the pattern generalizes rather than being a
 * one-off fit for Highlights specifically.
 *
 * Deliberately NOT yet wired into any live rendering path. Per the
 * roadmap's explicit safety requirement, this must first be proven
 * byte-for-byte identical to the original inline code via direct
 * execution comparison before any integration point is added.
 */
class AmenitiesModule {

    /** Exact copy of $_json_has_real_content() — see HighlightsModule
     * for the rationale on why this is duplicated rather than shared. */
    private static function has_real_content( $raw, string $required_key ): bool {
        if ( empty( $raw ) ) { return false; }
        $decoded = json_decode( (string) $raw, true );
        if ( ! is_array( $decoded ) ) { return false; }
        if ( array_key_exists( $required_key, $decoded ) ) {
            return ! empty( $decoded[ $required_key ] );
        }
        foreach ( $decoded as $item ) {
            if ( is_array( $item ) && ! empty( $item[ $required_key ] ?? null ) ) { return true; }
        }
        return false;
    }

    /** Faithful copy of the 'amenities_title' $_el_capture callback. */
    public static function render_title( array $cd ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['amenities_section_title'] ?? 'Features & Amenities'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /** Faithful copy of the 'amenities_grid' $_el_capture callback. */
    public static function render_grid( $amenities_data_raw, array $cd ): string {
        if ( ! self::has_real_content( $amenities_data_raw, 'title' ) ) { return ''; }
        $items = is_string( $amenities_data_raw ) ? ( json_decode( $amenities_data_raw, true ) ?: [] ) : $amenities_data_raw;
        $_am_img_settings = is_array( $cd['amenities_img_display'] ?? null ) ? $cd['amenities_img_display'] : [];
        $_am_icon_size_style = ! empty( $_am_img_settings['icon_size'] ) ? 'width:' . (int) $_am_img_settings['icon_size'] . 'px;height:' . (int) $_am_img_settings['icon_size'] . 'px;' : '';
        $_am_icon_fit = ( $_am_img_settings['fit'] ?? 'cover' ) === 'contain' ? 'contain' : 'cover';
        ob_start();
        ?>
    <div class="vs-am-grid">
        <?php foreach ($items as $a): if (empty($a['title'])) continue;
            $aicon = !empty($a['icon_image']) ? $a['icon_image'] : ($a['icon'] ?? '✅'); ?>
        <div class="vs-am-tile">
            <div class="vs-am-check" style="<?php echo esc_attr($_am_icon_size_style); ?>"><?php
                if (filter_var($aicon, FILTER_VALIDATE_URL)) {
                    echo '<img src="' . esc_url($aicon) . '" alt="' . esc_attr($a['title']) . '" loading="lazy" width="' . (!empty($_am_img_settings['icon_size']) ? (int)$_am_img_settings['icon_size'] : 32) . '" height="' . (!empty($_am_img_settings['icon_size']) ? (int)$_am_img_settings['icon_size'] : 32) . '" style="object-fit:' . $_am_icon_fit . ($_am_icon_fit === 'contain' ? ';padding:4px;box-sizing:border-box' : '') . '">';
                } else {
                    echo esc_html($aicon);
                }
            ?></div>
            <div class="vs-am-body">
                <div class="vs-am-title"><?php echo esc_html($a['title']); ?></div>
                <?php if (!empty($a['description'])): ?>
                <div class="vs-am-desc"><?php echo esc_html($a['description']); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * The module's full render output, following the same context-array
     * calling convention established in Phase 1 for HighlightsModule —
     * one shared shape every module's render_callback receives.
     */
    public static function render( array $context ): string {
        $cd = $context['cd'] ?? [];
        $amenities_data_raw = $context['module_data']['amenities_data']
            ?? ( $context['primary']->amenities_data ?? null );
        return self::render_title( $cd ) . self::render_grid( $amenities_data_raw, $cd );
    }
}
