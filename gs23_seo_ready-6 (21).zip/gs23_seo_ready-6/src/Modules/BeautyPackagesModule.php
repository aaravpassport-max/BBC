<?php
namespace GoodService\Modules;

/**
 * BeautyPackagesModule — Beauty & Salon, Section 05 of 6: "Beauty
 * Packages & Offers". Offer cards built only from real, vendor-typed
 * package data — the master build prompt's explicit instruction for
 * this section is "no fake urgency messaging": there is no countdown
 * timer, no "X people booked this" social-proof claim, and no
 * "Hurry, offer ending soon" copy anywhere in this file. The only two
 * time/price signals ever shown are ones the vendor actually typed:
 * an optional real "valid until" date, and a savings amount that is
 * plain arithmetic (original minus offer price) rather than an
 * invented percentage claim. A package whose real "valid until" date
 * has already passed is not rendered at all — reflecting the vendor's
 * own real data (an offer that has actually expired), not fabricating
 * new urgency copy.
 */
class BeautyPackagesModule {

    public static function render_title( string $title = 'Packages & Offers', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-beauty-eyebrow">Special Offers</div>
    <h2 class="vs-sec-title gs-beauty-title gs-beauty-pkg-title"><?php echo esc_html( $title ); ?></h2>
    <?php if ( $description !== '' ): ?><p class="gs-beauty-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
<?php
        return ob_get_clean();
    }

    /**
     * A package is only ever considered "still on" if it has no
     * vendor-set expiry date at all, or that date has not yet passed —
     * both are real states, never inferred or assumed.
     */
    private static function is_still_valid( array $p ): bool {
        $valid_until = trim( (string) ( $p['valid_until'] ?? '' ) );
        if ( $valid_until === '' ) { return true; }
        $ts = strtotime( $valid_until );
        if ( $ts === false ) { return true; } // Unparseable vendor input — never silently discard real data on a format guess.
        return $ts >= strtotime( 'today' );
    }

    public static function render_grid( array $packages, array $img_display, string $currency = '₹' ): string {
        $active = array_values( array_filter( $packages, [ self::class, 'is_still_valid' ] ) );
        if ( empty( $active ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];

        ob_start();
        ?>
    <div class="gs-beauty-pkg-grid">
        <?php foreach ( $active as $p ):
            $name        = (string) $p['name'];
            $description = (string) ( $p['description'] ?? '' );
            $badge       = (string) ( $p['badge'] ?? '' );
            $image       = (string) ( $p['image'] ?? '' );
            $valid_until = trim( (string) ( $p['valid_until'] ?? '' ) );

            $orig_raw  = trim( (string) ( $p['original_price'] ?? '' ) );
            $offer_raw = trim( (string) ( $p['offer_price'] ?? '' ) );
            $orig  = is_numeric( $orig_raw ) ? (float) $orig_raw : null;
            $offer = is_numeric( $offer_raw ) ? (float) $offer_raw : null;

            // Every price-state branch below reflects only what the
            // vendor actually filled in — never a fabricated default.
            $show_strike = ( $orig !== null && $offer !== null && $offer < $orig );
            $savings     = $show_strike ? ( $orig - $offer ) : null;
            $single_price = null;
            if ( ! $show_strike ) {
                if ( $offer !== null ) { $single_price = $offer; }
                elseif ( $orig !== null ) { $single_price = $orig; }
            }
        ?>
        <div class="gs-beauty-pkg-card">
            <?php if ( $image !== '' ): ?>
            <div class="gs-beauty-pkg-media">
                <img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $name ); ?>" class="gs-beauty-pkg-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php if ( $badge !== '' ): ?><span class="gs-beauty-pkg-badge"><?php echo esc_html( $badge ); ?></span><?php endif; ?>
            </div>
            <?php elseif ( $badge !== '' ): ?>
            <span class="gs-beauty-pkg-badge gs-beauty-pkg-badge-noimg"><?php echo esc_html( $badge ); ?></span>
            <?php endif; ?>
            <div class="gs-beauty-pkg-body">
                <div class="gs-beauty-pkg-name"><?php echo esc_html( $name ); ?></div>
                <?php if ( $description !== '' ): ?><p class="gs-beauty-pkg-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>

                <?php if ( $show_strike ): ?>
                <div class="gs-beauty-pkg-price-row">
                    <span class="gs-beauty-pkg-price-orig"><?php echo esc_html( $currency . number_format( $orig, 0 ) ); ?></span>
                    <span class="gs-beauty-pkg-price-offer"><?php echo esc_html( $currency . number_format( $offer, 0 ) ); ?></span>
                </div>
                <div class="gs-beauty-pkg-save">You save <?php echo esc_html( $currency . number_format( $savings, 0 ) ); ?></div>
                <?php elseif ( $single_price !== null ): ?>
                <div class="gs-beauty-pkg-price-row"><span class="gs-beauty-pkg-price-offer"><?php echo esc_html( $currency . number_format( $single_price, 0 ) ); ?></span></div>
                <?php endif; ?>

                <?php if ( $valid_until !== '' && strtotime( $valid_until ) !== false ): ?>
                <div class="gs-beauty-pkg-valid">Valid until <?php echo esc_html( date_i18n( 'j M Y', strtotime( $valid_until ) ) ); ?></div>
                <?php endif; ?>

                <button type="button" class="gs-beauty-pkg-cta" onclick="vsOpenInquiry({name:'<?php echo esc_js( $name ); ?>',type:'service',price:'<?php echo esc_js( $single_price !== null ? ( $currency . number_format( $single_price, 0 ) ) : ( $show_strike ? ( $currency . number_format( $offer, 0 ) ) : '' ) ); ?>'})">Enquire About This Offer</button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $packages
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     *     @type string $currency
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid(
            (array) ( $context['packages'] ?? [] ),
            (array) ( $context['img_display'] ?? [] ),
            (string) ( $context['currency'] ?? '₹' )
        );
        if ( $html === '' ) { return ''; }
        return '<div class="gs-beauty-sec-head">' . self::render_title( $context['section_title'] ?? 'Packages & Offers', $context['section_description'] ?? '' ) . '</div>' . $html;
    }
}
