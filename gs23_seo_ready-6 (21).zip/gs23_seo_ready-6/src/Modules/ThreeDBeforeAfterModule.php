<?php
namespace GoodService\Modules;

/**
 * ThreeDBeforeAfterModule — Interior Designers & Architects, module 3
 * of 5. Combines the request's own two distinct but related parts —
 * 3D Designs (concept → result) and Before/After (interactive
 * transformation) — into one section with two independent repeaters,
 * matching the request's own "Part A" / "Part B" structure exactly
 * rather than forcing them into one generic gallery.
 *
 * The before/after drag-slider has no existing equivalent anywhere on
 * this platform (confirmed directly — only a standard multi-image
 * carousel exists, a different interaction entirely) — built fresh
 * here as native HTML/CSS/JS, no external library, matching the
 * request's own "smooth and touch-friendly" requirement.
 *
 * Independent of Featured Projects' own activation, same pattern as
 * every cross-referencing module in this category — "Related Project"
 * is an optional link by project name, read directly via
 * ProjectsModule::get_projects(), never a dependency on that other
 * module being active.
 */
class ThreeDBeforeAfterModule {

    public const DESIGN_TYPES = [
        'living_room' => 'Living Room', 'bedroom' => 'Bedroom', 'kitchen' => 'Kitchen',
        'bathroom' => 'Bathroom', 'office' => 'Office', 'exterior' => 'Exterior', 'villa' => 'Villa',
        'commercial' => 'Commercial Space', 'restaurant' => 'Restaurant', 'retail' => 'Retail',
        'landscape' => 'Landscape', 'custom' => 'Custom',
    ];

    public const BA_LAYOUTS = [ 'slider' => 'Slider (drag to compare)', 'side_by_side' => 'Side by Side' ];

    public static function render_title( string $title = '3D Designs & Before/After', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-ida-sec-head">
        <div class="vs-ida-eyebrow">Visualization</div>
        <h2 class="vs-sec-title vs-ida-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-ida-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Part A — 3D Designs. The recommended presentation from the
     * request: "Concept / 3D Render → Final Result" where both exist,
     * demonstrating capability rather than just displaying images.
     */
    public static function render_3d_designs( array $designs, array $img_display = [] ): string {
        $designs = array_values( array_filter( $designs, fn( $d ) => ! empty( $d['project_name'] ) && ! empty( $d['render_3d'] ) ) );
        if ( empty( $designs ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        ob_start();
        ?>
    <div class="vs-ida-3d-grid">
        <?php foreach ( $designs as $d ):
            $has_original = ! empty( $d['original_photo'] );
            $has_final = ! empty( $d['final_photo'] );
            $_pane_count = 1 + ( $has_original ? 1 : 0 ) + ( $has_final ? 1 : 0 );
        ?>
        <div class="vs-ida-3d-card">
            <div class="vs-ida-3d-images vs-ida-3d-panes-<?php echo $_pane_count; ?>">
                <?php if ( $has_original ): ?>
                <div class="vs-ida-3d-pane">
                    <span class="vs-ida-3d-label">Original Space</span>
                    <img src="<?php echo esc_url( $d['original_photo'] ); ?>" alt="<?php echo esc_attr( $d['project_name'] ); ?> — original" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                </div>
                <?php endif; ?>
                <div class="vs-ida-3d-pane">
                    <span class="vs-ida-3d-label">3D Concept</span>
                    <img src="<?php echo esc_url( $d['render_3d'] ); ?>" alt="<?php echo esc_attr( $d['project_name'] ); ?> — 3D concept" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                </div>
                <?php if ( $has_final ): ?>
                <div class="vs-ida-3d-pane">
                    <span class="vs-ida-3d-label">Completed Space</span>
                    <img src="<?php echo esc_url( $d['final_photo'] ); ?>" alt="<?php echo esc_attr( $d['project_name'] ); ?> — completed" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                </div>
                <?php endif; ?>
            </div>
            <div class="vs-ida-3d-body">
                <div class="vs-ida-3d-name"><?php echo esc_html( $d['project_name'] ); ?></div>
                <?php if ( ! empty( $d['room_space'] ) ): ?><div class="vs-ida-3d-meta"><?php echo esc_html( $d['room_space'] ); ?></div><?php endif; ?>
                <?php if ( ! empty( $d['description'] ) ): ?><p class="vs-ida-3d-desc"><?php echo esc_html( $d['description'] ); ?></p><?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Part B — Before/After. Real feature: a native drag-to-compare
     * slider (no external library), touch-friendly via pointer events
     * (covers both mouse and touch in one handler), plus a
     * side-by-side layout alternative. Stacked mobile presentation
     * happens automatically via responsive CSS, not a separate toggle.
     */
    public static function render_before_after( array $items, string $layout = 'slider', array $img_display = [] ): string {
        $items = array_values( array_filter( $items, fn( $ba ) => ! empty( $ba['project_name'] ) && ! empty( $ba['before_image'] ) && ! empty( $ba['after_image'] ) ) );
        if ( empty( $items ) ) { return ''; }
        $layout = in_array( $layout, array_keys( self::BA_LAYOUTS ), true ) ? $layout : 'slider';
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        ob_start();
        ?>
    <div class="vs-ida-ba-grid vs-ida-ba-layout-<?php echo esc_attr( $layout ); ?>">
        <?php foreach ( $items as $_bi => $ba ):
            $uid = 'vs-ba-' . $_bi . '-' . substr( md5( $ba['project_name'] ), 0, 6 );
        ?>
        <div class="vs-ida-ba-card">
            <?php if ( $layout === 'slider' ): ?>
            <div class="vs-ida-ba-slider" id="<?php echo esc_attr( $uid ); ?>">
                <img src="<?php echo esc_url( $ba['after_image'] ); ?>" alt="<?php echo esc_attr( $ba['project_name'] ); ?> — after" class="vs-ida-ba-img vs-ida-ba-after" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <div class="vs-ida-ba-before-wrap">
                    <img src="<?php echo esc_url( $ba['before_image'] ); ?>" alt="<?php echo esc_attr( $ba['project_name'] ); ?> — before" class="vs-ida-ba-img vs-ida-ba-before" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                </div>
                <div class="vs-ida-ba-handle" style="left:50%">
                    <div class="vs-ida-ba-handle-grip">&#8596;</div>
                </div>
                <span class="vs-ida-ba-tag vs-ida-ba-tag-before">Before</span>
                <span class="vs-ida-ba-tag vs-ida-ba-tag-after">After</span>
            </div>
            <script>if(window.vsIdaInitBeforeAfterSlider){vsIdaInitBeforeAfterSlider('<?php echo esc_js( $uid ); ?>');}else{document.addEventListener('DOMContentLoaded',function(){vsIdaInitBeforeAfterSlider('<?php echo esc_js( $uid ); ?>');});}</script>
            <?php else: ?>
            <div class="vs-ida-ba-sidebyside">
                <div><span class="vs-ida-ba-tag-static">Before</span><img src="<?php echo esc_url( $ba['before_image'] ); ?>" alt="<?php echo esc_attr( $ba['project_name'] ); ?> — before" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>"></div>
                <div><span class="vs-ida-ba-tag-static">After</span><img src="<?php echo esc_url( $ba['after_image'] ); ?>" alt="<?php echo esc_attr( $ba['project_name'] ); ?> — after" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>"></div>
            </div>
            <?php endif; ?>
            <div class="vs-ida-ba-body">
                <div class="vs-ida-ba-name"><?php echo esc_html( $ba['project_name'] ); ?></div>
                <?php if ( ! empty( $ba['space_type'] ) ): ?><div class="vs-ida-ba-meta"><?php echo esc_html( $ba['space_type'] ); ?></div><?php endif; ?>
                <?php if ( ! empty( $ba['description'] ) ): ?><p class="vs-ida-ba-desc"><?php echo esc_html( $ba['description'] ); ?></p><?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $designs        3D Designs repeater data.
     *     @type array  $before_afters  Before/After repeater data.
     *     @type string $ba_layout
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $designs_html = self::render_3d_designs( $context['designs'] ?? [], (array) ( $context['img_display'] ?? [] ) );
        $ba_html = self::render_before_after( $context['before_afters'] ?? [], $context['ba_layout'] ?? 'slider', (array) ( $context['img_display'] ?? [] ) );
        if ( $designs_html === '' && $ba_html === '' ) { return ''; } // Real feature — empty-state requirement.
        $body = '';
        if ( $designs_html !== '' ) { $body .= '<div class="vs-ida-3d-subsection"><h3 class="vs-ida-subhead">3D Designs</h3>' . $designs_html . '</div>'; }
        if ( $ba_html !== '' ) { $body .= '<div class="vs-ida-ba-subsection"><h3 class="vs-ida-subhead">Before / After</h3>' . $ba_html . '</div>'; }
        return self::render_title( $context['section_title'] ?? '3D Designs & Before/After', $context['section_description'] ?? '' ) . $body;
    }
}
