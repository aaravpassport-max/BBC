<?php
namespace GoodService\Modules;

/**
 * WhyModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of the existing "Why Choose Us" rendering logic
 * from vendor-site.php's $_el_capture calls for 'why_title' and
 * 'why_grid'.
 *
 * [SELF-CORRECTION — a mistake made and caught within this same
 * session, documented explicitly rather than silently fixed]: this
 * class originally claimed a "real bug" copied from the same pattern
 * already (incorrectly) documented in FaqModule.php — that
 * why_choose_data arrives as a raw JSON string and foreach() on it
 * silently produces zero items. That claim is WRONG. The mistake: I
 * copied FaqModule's "found a bug" narrative onto Why without first
 * re-checking vendor-site.php's pre-existing global JSON-decode loop
 * (search for "Decode all JSON blobs", ~line 391), which runs on every
 * page load and decodes `$primary->why_choose_data` into a real array
 * long before any $_el_capture callback executes — the same loop that
 * makes FaqModule's original claim wrong too. Verified directly:
 * extracting that real decode loop verbatim and running it ahead of
 * the real why_grid callback, with a realistic raw-JSON-string input,
 * produces correctly rendered Why cards — no bug. "Why Choose Us" DOES
 * render correctly for vendors today; it always has.
 *
 * This class's actual CODE was never wrong — decoding defensively
 * (`is_string(...) ? json_decode(...) : $data`) is correct regardless
 * of input shape. Enabling GS_USE_MODULE_ENGINE_WHY therefore changes
 * NOTHING observable in production — flag-on and flag-off produce
 * identical output today, because the real input is always already an
 * array by the time either path runs. The only thing wrong was the
 * "why this fix matters" narrative, now corrected.
 */
class WhyModule {

    /** Faithful copy of the 'why_title' $_el_capture callback. */
    public static function render_title( array $hd ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Our Promise</div>
        <h2 class="vs-sec-title"><?php echo esc_html($hd['why_section_title'] ?? 'Why Choose Us'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Corrected copy of the 'why_grid' $_el_capture callback — see
     * class docblock for the real bug this fixes (JSON decoding).
     */
    /** @param string $img_fit Image Fit — site-wide image-fit audit: previously hardcoded, now a real vendor-facing setting. */
    public static function render_grid( $why_choose_data_raw, string $img_fit = 'contain' ): string {
        if ( empty( $why_choose_data_raw ) ) { return ''; }
        $items = is_string( $why_choose_data_raw ) ? ( json_decode( $why_choose_data_raw, true ) ?: [] ) : $why_choose_data_raw;
        if ( empty( $items ) ) { return ''; }
        if ( isset( $items['section_title'] ) ) { unset( $items['section_title'] ); }
        $_img_style = \gs_vs_img_display_style( [ 'fit' => $img_fit ] )['img'];
        ob_start();
        ?>
    <div class="vs-why-grid">
        <?php foreach ($items as $w): if (empty($w['title'])) continue;
            $wicon = !empty($w['icon_image']) ? $w['icon_image'] : ($w['icon'] ?? '✅'); ?>
        <div class="vs-why-card">
            <div class="vs-why-icon-wrap"><?php
                if (filter_var($wicon, FILTER_VALIDATE_URL)) {
                    echo '<img src="' . esc_url($wicon) . '" alt="' . esc_attr($w['title']) . '" loading="lazy" width="88" height="88" style="' . esc_attr( $_img_style ) . '">';
                } else {
                    echo '<span style="font-size:2rem;line-height:1">' . esc_html($wicon) . '</span>';
                }
            ?></div>
            <div class="vs-why-title"><?php echo esc_html($w['title']); ?></div>
            <?php if (!empty($w['description'])): ?>
            <div class="vs-why-desc"><?php echo esc_html($w['description']); ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $hd = $context['hd'] ?? [];
        $why_choose_data_raw = $context['module_data']['why_choose_data']
            ?? ( $context['primary']->why_choose_data ?? null );
        return self::render_title( $hd ) . self::render_grid( $why_choose_data_raw, (string) ( $context['img_fit'] ?? 'contain' ) );
    }
}
