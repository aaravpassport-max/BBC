<?php
namespace GoodService\Modules;

/**
 * HomeServicesCatalogueModule — Home Services, Module 1 (of a planned
 * multi-module category build): "Service Catalogue & Problem Solver".
 * Follows the exact same shape as the reference pattern
 * (BeautyServicesModule, Beauty & Salon) per the master build prompt's
 * Section 0.1: read the most similar existing module first, reuse its
 * structure rather than inventing a new one.
 *
 * Combines the custom build spec's Section 01 ("Service Discovery &
 * Problem Solver") and Section 02 ("Service Menu / Service Catalogue")
 * into one module, per the spec's own Section 32 ("Data-Density
 * Requirement") — a problem-first picker above a real service
 * catalogue, not two separate thin sections.
 *
 * Reuses established platform mechanisms, never a parallel system:
 * vsOpenDetailPopup() for the service detail view, vsOpenInquiry() for
 * "Book"/"Enquire" (preserving the selected service's name/price into
 * the existing simple-inquiry flow), and the platform's own tel:/wa.me
 * CTA pattern using the vendor's own already-saved phone/WhatsApp
 * number. The problem-picker and category tabs are rendered
 * server-side but filtered client-side with plain data-attribute
 * matching — no page reload, no second AJAX round trip — matching the
 * exact mechanism already used by BeautyServicesModule's category
 * tabs.
 */
class HomeServicesCatalogueModule {

    public static function render_title( string $title = 'Home Services You Can Rely On', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-hsvc-sec-head">
        <div class="gs-hsvc-eyebrow">What Do You Need Help With?</div>
        <h2 class="vs-sec-title gs-hsvc-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-hsvc-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Custom build spec's exact price-state contract (its Section 02):
     * an exact price, a "Starting from" price, or "Request Quote" —
     * never a fabricated or zero/blank value standing in for a real
     * price (spec's Section 33, "Zero-Data Handling": never show ₹0,
     * N/A, or blank).
     */
    private static function price_display( array $service ): string {
        $currency = \gs_setting( 'currency_symbol', '₹' );
        $exact    = trim( (string) ( $service['price'] ?? '' ) );
        $from     = trim( (string) ( $service['starting_price'] ?? '' ) );
        if ( $exact !== '' && is_numeric( $exact ) && (float) $exact > 0 ) {
            return $currency . $exact;
        }
        if ( $from !== '' && is_numeric( $from ) && (float) $from > 0 ) {
            return 'Starting from ' . $currency . $from;
        }
        return 'Request Quote';
    }

    /** Vendor-entered free text (30 min / 1-2 hrs / Varies), never
     * computed or guessed when absent — same contract as duration
     * everywhere else in the platform. */
    private static function duration_display( array $service ): string {
        return trim( (string) ( $service['duration'] ?? '' ) );
    }

    private static function build_detail_sections( array $service ): array {
        $sections = [];
        if ( ! empty( $service['detailed_description'] ) ) {
            $sections[] = [ 'content_type' => 'richtext', 'title' => 'About This Service', 'icon' => '🧰', 'body' => esc_html( $service['detailed_description'] ) ];
        }
        $included = array_values( array_filter( array_map( 'trim', (array) ( $service['included'] ?? [] ) ) ) );
        if ( ! empty( $included ) ) {
            $sections[] = [ 'content_type' => 'list', 'title' => 'What Is Included', 'icon' => '✅', 'list_items' => $included ];
        }
        $meta = [];
        if ( ! empty( $service['duration'] ) ) { $meta[] = 'Estimated Duration: ' . $service['duration']; }
        if ( ! empty( $service['warranty'] ) ) { $meta[] = 'Service Warranty: ' . $service['warranty']; }
        if ( ! empty( $service['group'] ) && isset( HomeServicesModule::SERVICE_GROUPS[ $service['group'] ] ) ) {
            $meta[] = 'Category: ' . HomeServicesModule::SERVICE_GROUPS[ $service['group'] ];
        }
        if ( ! empty( $meta ) ) {
            $sections[] = [ 'content_type' => 'list', 'title' => 'Service Details', 'icon' => 'ℹ️', 'list_items' => $meta ];
        }
        // Real, established pattern — the shared "Manage Details" popup
        // builder's own output, appended after the automatic sections,
        // exactly like every other card-based module (master build
        // prompt's Section 8).
        $custom_vms = is_string( $service['view_more_sections'] ?? null )
            ? ( json_decode( $service['view_more_sections'], true ) ?: [] )
            : ( $service['view_more_sections'] ?? [] );
        if ( is_array( $custom_vms ) ) {
            foreach ( $custom_vms as $_vms ) { if ( is_array( $_vms ) ) { $sections[] = $_vms; } }
        }
        return $sections;
    }

    /**
     * Custom build spec's Section 03 "Problem-first discovery" strip —
     * built entirely from HomeServicesModule::get_problem_map(), so it
     * only ever shows problems this specific vendor actually configured
     * against a real service. Clicking a chip filters the grid below to
     * the service(s) that address it — never a claimed diagnosis
     * (spec's explicit "Possible service", never "Your problem is
     * definitely X" — enforced here by never using diagnostic wording).
     */
    private static function render_problem_strip( array $problem_map ): string {
        if ( empty( $problem_map ) ) { return ''; }
        ob_start();
        ?>
    <div class="gs-hsvc-problems" role="group" aria-label="What's the problem? Pick one to see the matching service.">
        <div class="gs-hsvc-problems-label">Not sure what to book? Tell us the problem —</div>
        <div class="gs-hsvc-problem-chips">
            <?php foreach ( array_keys( $problem_map ) as $_problem ): ?>
            <button type="button" class="gs-hsvc-problem-chip" data-problem="<?php echo esc_attr( $_problem ); ?>"><?php echo esc_html( $_problem ); ?></button>
            <?php endforeach; ?>
        </div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $img_display  fit/position/zoom — shared, global
     *              gs_vs_img_display_style() helper.
     */
    public static function render_grid( array $services, array $img_display = [], string $phone = '', string $wa_clean = '' ): string {
        $services = array_values( array_filter( $services, fn( $s ) => ! empty( $s['name'] ) ) );
        if ( empty( $services ) ) { return ''; }
        $_img_style    = \gs_vs_img_display_style( $img_display )['img'];
        $active_groups = HomeServicesModule::get_active_groups( $services );
        $problem_map   = HomeServicesModule::get_problem_map( $services );

        ob_start();
        ?>
    <div class="gs-hsvc-catalogue">
        <?php echo self::render_problem_strip( $problem_map ); ?>
        <?php if ( count( $active_groups ) > 1 ): ?>
        <div class="gs-hsvc-tabs" role="tablist" aria-label="Filter services by category">
            <button type="button" class="gs-hsvc-tab is-active" data-group="all" role="tab" aria-selected="true">All Services</button>
            <?php foreach ( $active_groups as $_gkey => $_glabel ): ?>
            <button type="button" class="gs-hsvc-tab" data-group="<?php echo esc_attr( $_gkey ); ?>" role="tab" aria-selected="false"><?php echo esc_html( $_glabel ); ?></button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="gs-hsvc-grid">
        <?php foreach ( $services as $service ):
            $detail_sections = self::build_detail_sections( $service );
            $price_display   = self::price_display( $service );
            $duration        = self::duration_display( $service );
            $problems_attr   = implode( '|', array_map( 'trim', (array) ( $service['problems'] ?? [] ) ) );
            $flags = [];
            foreach ( HomeServicesModule::SERVICE_FLAGS as $_fkey => $_flabel ) {
                if ( ! empty( $service[ $_fkey ] ) ) { $flags[] = $_flabel; }
            }
            $included = array_values( array_filter( array_map( 'trim', (array) ( $service['included'] ?? [] ) ) ) );
        ?>
        <div class="gs-hsvc-card" data-group="<?php echo esc_attr( $service['group'] ?? '' ); ?>" data-problems="<?php echo esc_attr( $problems_attr ); ?>">
            <?php if ( ! empty( $service['image'] ) ): ?>
            <div class="gs-hsvc-card-media">
                <img src="<?php echo esc_url( $service['image'] ); ?>" alt="<?php echo esc_attr( $service['name'] ); ?>" class="gs-hsvc-card-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php if ( ! empty( $flags ) ): ?>
                <div class="gs-hsvc-card-flags">
                    <?php foreach ( $flags as $_flag ): ?><span class="gs-hsvc-flag"><?php echo esc_html( $_flag ); ?></span><?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <div class="gs-hsvc-card-body">
                <?php if ( ! empty( $service['group'] ) && isset( HomeServicesModule::SERVICE_GROUPS[ $service['group'] ] ) ): ?>
                <div class="gs-hsvc-card-cat"><?php echo esc_html( HomeServicesModule::SERVICE_GROUPS[ $service['group'] ] ); ?></div>
                <?php endif; ?>
                <div class="gs-hsvc-card-name"><?php echo esc_html( $service['name'] ); ?></div>
                <?php if ( ! empty( $service['short_description'] ) ): ?><p class="gs-hsvc-card-desc"><?php echo esc_html( $service['short_description'] ); ?></p><?php endif; ?>
                <?php if ( ! empty( $included ) ): ?>
                <ul class="gs-hsvc-card-includes">
                    <?php foreach ( array_slice( $included, 0, 4 ) as $_inc ): ?><li><?php echo esc_html( $_inc ); ?></li><?php endforeach; ?>
                </ul>
                <?php endif; ?>
                <div class="gs-hsvc-card-meta">
                    <?php if ( $duration !== '' ): ?><span class="gs-hsvc-card-duration">⏱ <?php echo esc_html( $duration ); ?></span><?php endif; ?>
                    <span class="gs-hsvc-card-price"><?php echo esc_html( $price_display ); ?></span>
                </div>
                <div class="gs-hsvc-card-ctas">
                    <a href="#" class="gs-hsvc-cta-primary"
                       data-title="<?php echo esc_attr( $service['name'] ); ?>"
                       data-image="<?php echo esc_attr( $service['image'] ?? '' ); ?>"
                       data-img-fit="<?php echo esc_attr( in_array( $img_display['popup_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $img_display['popup_fit'] ?? 'cover' ) : 'cover' ); ?>"
                       data-price="<?php echo esc_attr( $price_display ); ?>"
                       data-sections="<?php echo esc_attr( wp_json_encode( $detail_sections ) ); ?>"
                       onclick="event.preventDefault();vsOpenDetailPopup(event,this)">View Details</a>
                    <?php if ( ! empty( $service['bookable'] ) ): ?>
                    <a href="#" class="gs-hsvc-cta-secondary" onclick="event.preventDefault();vsOpenInquiry({name:'<?php echo esc_js( $service['name'] ); ?>',type:'service',price:'<?php echo esc_js( $price_display ); ?>'})">Book Service</a>
                    <?php endif; ?>
                    <?php if ( $wa_clean !== '' ): ?><a href="https://wa.me/<?php echo esc_attr( $wa_clean ); ?>?text=<?php echo esc_attr( rawurlencode( 'Hi, I\'d like to know more about ' . $service['name'] ) ); ?>" target="_blank" rel="noopener" class="gs-hsvc-cta-icon" title="WhatsApp" aria-label="WhatsApp about <?php echo esc_attr( $service['name'] ); ?>">💬</a><?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $services
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     *     @type string $phone
     *     @type string $wa_clean
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid(
            $context['services'] ?? [],
            (array) ( $context['img_display'] ?? [] ),
            (string) ( $context['phone'] ?? '' ),
            (string) ( $context['wa_clean'] ?? '' )
        );
        if ( $html === '' ) { return ''; } // Mandatory empty-state — custom build spec's Section 33.
        return self::render_title( $context['section_title'] ?? 'Home Services You Can Rely On', $context['section_description'] ?? '' ) . $html;
    }
}
