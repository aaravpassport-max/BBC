<?php
namespace GoodService\Modules;

/**
 * FacilitiesModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of the existing Facilities rendering logic (title
 * block + photo-first card grid, with fallback icon handling when no
 * photo is set) from vendor-site.php's $_el_capture calls for
 * 'facilities_title' and 'facilities_grid'.
 *
 * Note on gs_vs_img_display_style(): this module calls that shared
 * global helper rather than duplicating its logic locally (unlike the
 * small has_real_content() check, which IS duplicated — see
 * HighlightsModule for that rationale). gs_vs_img_display_style() is
 * genuinely shared across multiple sections being migrated in this same
 * phase (Facilities, Awards, Certifications); duplicating a non-trivial
 * function three times risks the copies silently drifting apart later.
 * This does mean FacilitiesModule currently depends on vendor-site.php
 * having already defined that function — true for the live integration
 * point (called from within that same file, after the function is
 * defined), but worth revisiting if this module is ever needed fully
 * independently of vendor-site.php.
 */
class FacilitiesModule {

    private static function has_real_content( $raw, string $required_key ): bool {
        if ( empty( $raw ) ) { return false; }
        $decoded = json_decode( (string) $raw, true );
        if ( ! is_array( $decoded ) ) { return false; }
        if ( array_key_exists( $required_key, $decoded ) ) {
            return ! empty( $decoded[ $required_key ] );
        }
        foreach ( $decoded as $item ) {
            if ( is_array( $item ) && ! empty( $item[ $required_key ] ?? null ) ) { return true; }
        }
        return false;
    }

    /** Faithful copy of the 'facilities_title' $_el_capture callback. */
    public static function render_title( array $cd ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['facilities_section_title'] ?? 'Our Facilities'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /** Faithful copy of the 'facilities_grid' $_el_capture callback. */
    public static function render_grid( $facilities_data_raw, array $cd ): string {
        if ( ! self::has_real_content( $facilities_data_raw, 'title' ) ) { return ''; }
        $items = is_string( $facilities_data_raw ) ? ( json_decode( $facilities_data_raw, true ) ?: [] ) : $facilities_data_raw;
        $_fac_img_settings = is_array( $cd['facilities_img_display'] ?? null ) ? $cd['facilities_img_display'] : [];
        $_fac_style_desk = gs_vs_img_display_style( $_fac_img_settings, false );
        $_fac_style_mob  = gs_vs_img_display_style( $_fac_img_settings, true );
        ob_start();
        ?>
    <div class="vs-fac-grid">
        <?php foreach ($items as $f): if (empty($f['title'])) continue;
            $ficon = !empty($f['icon_image']) ? $f['icon_image'] : ($f['icon'] ?? '🏢');
            $has_photo = !empty($f['image']);
        ?>
        <div class="vs-fac-card">
            <div class="vs-fac-photo vs-fac-photo-custom" style="<?php echo esc_attr($_fac_style_desk['container']); ?>">
                <?php if ($has_photo): ?>
                    <img src="<?php echo esc_url($f['image']); ?>" alt="<?php echo esc_attr($f['title']); ?>" loading="lazy" width="400" height="320" style="<?php echo esc_attr($_fac_style_desk['img']); ?>">
                <?php else: ?>
                    <div class="vs-fac-photo-fallback"><?php
                        if (filter_var($ficon, FILTER_VALIDATE_URL)) {
                            echo '<img src="' . esc_url($ficon) . '" alt="" loading="lazy" width="400" height="320" style="width:100%;height:100%;object-fit:cover">';
                        } else {
                            echo esc_html($ficon);
                        }
                    ?></div>
                <?php endif; ?>
                <?php if ($has_photo && !filter_var($ficon, FILTER_VALIDATE_URL)): ?>
                <div class="vs-fac-icon-badge"><?php echo esc_html($ficon); ?></div>
                <?php endif; ?>
            </div>
            <div class="vs-fac-body">
                <div class="vs-fac-title"><?php echo esc_html($f['title']); ?></div>
                <?php if (!empty($f['description'])): ?>
                <div class="vs-fac-desc"><?php echo esc_html($f['description']); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php if ( ! empty( $_fac_img_settings['height_mobile'] ) ): ?>
    <style>
    @media(max-width:640px){
      .vs-fac-photo-custom{ height:<?php echo (int) $_fac_img_settings['height_mobile']; ?>px !important; }
    }
    </style>
    <?php endif; ?>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $cd = $context['cd'] ?? [];
        $facilities_data_raw = $context['module_data']['facilities_data']
            ?? ( $context['primary']->facilities_data ?? null );
        return self::render_title( $cd ) . self::render_grid( $facilities_data_raw, $cd );
    }
}
