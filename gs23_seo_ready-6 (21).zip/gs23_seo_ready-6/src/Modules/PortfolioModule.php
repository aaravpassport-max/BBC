<?php
namespace GoodService\Modules;

/**
 * PortfolioModule — Phase 2 of the modular listing architecture
 * roadmap.
 *
 * Same premium-section fetch mechanism as Pricing:
 * `$_fetch_premium_section('portfolio_data')` (~line 833 of
 * vendor-site.php). `$primary->portfolio_data` is never the real data
 * — Router.php deliberately leaves it empty for performance.
 *
 * A stale comment found and NOT acted on, per Section 5's non-goal of
 * scope creep during a pure migration (worth recording since verifying
 * comments' factual claims caught a real issue in Pricing this same
 * session): the original 'portfolio_grid' callback has a comment
 * claiming "computes the real width at that fixed height from the
 * actual image's aspect ratio, same cached getimagesize() pattern used
 * elsewhere" — but the code directly below it just hardcodes
 * `width="400" height="200"` with no getimagesize() call anywhere in
 * this callback (confirmed via a direct search — getimagesize() IS
 * used elsewhere in this file, for the nav logo, hero image, and
 * client logos, just not here). The comment describes something that
 * was either never actually implemented in this specific callback or
 * was removed without updating the comment. This module faithfully
 * reproduces the ACTUAL behavior (hardcoded dimensions), not what the
 * stale comment claims it does — fixing the discrepancy between
 * comment and code is a separate, real cleanup task, not something to
 * silently fold into a migration meant to be behavior-preserving.
 *
 * No closure-capture bugs found (checked explicitly): 'portfolio_grid'
 * only references $_portfolio_data (its own use() variable) and loop-
 * local variables ($proj, $results, $r) — nothing missing.
 *
 * Faithful extraction of 'portfolio_title' and 'portfolio_grid'. No
 * logic changes.
 */
class PortfolioModule {

    public static function render_title(): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Our Work</div>
        <h2 class="vs-sec-title">Projects & Case Studies</h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /** @param string $img_fit Image Fit — site-wide image-fit audit: previously hardcoded, now a real vendor-facing setting. */
    public static function render_grid( array $portfolio_data, string $img_fit = 'cover' ): string {
        if ( empty( $portfolio_data ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( [ 'fit' => $img_fit ] )['img'];
        ob_start();
        ?>
    <div class="vs-portfolio-grid">
        <?php foreach ( $portfolio_data as $proj ):
            if ( empty( $proj['title'] ) ) continue;
            $results = is_array( $proj['results'] ?? null )
                ? $proj['results']
                : array_filter( array_map( 'trim', explode( "\n", $proj['results'] ?? '' ) ) );
        ?>
        <div class="vs-portfolio-card">
            <?php if ( ! empty( $proj['image'] ) ): ?>
                <img src="<?php echo esc_url( $proj['image'] ); ?>" alt="<?php echo esc_attr( $proj['title'] ); ?>" class="vs-portfolio-img" loading="lazy" width="400" height="200" style="<?php echo esc_attr( $_img_style ); ?>">
            <?php else: ?>
                <div class="vs-portfolio-img-placeholder">📁</div>
            <?php endif; ?>
            <div class="vs-portfolio-body">
                <?php if ( ! empty( $proj['category'] ) ): ?>
                    <div class="vs-portfolio-cat"><?php echo esc_html( $proj['category'] ); ?></div>
                <?php endif; ?>
                <div class="vs-portfolio-title"><?php echo esc_html( $proj['title'] ); ?></div>
                <?php if ( ! empty( $proj['description'] ) ): ?>
                    <div class="vs-portfolio-desc"><?php echo esc_html( $proj['description'] ); ?></div>
                <?php endif; ?>
                <?php if ( ! empty( $results ) ): ?>
                    <div class="vs-portfolio-stats">
                        <?php foreach ( array_slice( (array)$results, 0, 3 ) as $r ):
                            if ( ! trim( $r ) ) continue;
                        ?>
                        <span class="vs-portfolio-stat">✅ <?php echo esc_html( trim( $r ) ); ?></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <?php if ( ! empty( $proj['link'] ) ): ?>
                    <a href="<?php echo esc_url( $proj['link'] ); ?>" target="_blank" rel="noopener" class="vs-portfolio-link">View Case Study →</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array $portfolio_data  The already-fetched portfolio
     *                  array (via $_fetch_premium_section) — see class
     *                  docblock for why this can't be derived from
     *                  $context['primary'] directly.
     * }
     */
    public static function render( array $context ): string {
        $portfolio_data = $context['portfolio_data'] ?? [];
        return self::render_title() . self::render_grid( $portfolio_data, (string) ( $context['img_fit'] ?? 'cover' ) );
    }
}
