<?php
namespace GoodService\Modules;

/**
 * FeaturedPropertiesModule — real estate module 2 of 4.
 *
 * Deliberately does NOT store its own copy of property data. It reads
 * from PropertyListingsModule::get_properties() — the single, shared
 * source every real-estate module reads from — and applies its own
 * selection logic on top. This is what makes the request's own
 * explicit, critical requirement true by construction rather than by
 * convention: get_properties() is a pure data-access call against
 * gs_listing_module_data, with no dependency whatsoever on whether the
 * 'property_listings' module/section is itself active, assigned, or
 * visible. A vendor can have Featured Properties ON while Property
 * Listings is OFF, and this module still has real data to show,
 * because it never asked whether that other section was enabled in
 * the first place — it only asked for the data.
 *
 * Category-gated to 'real-estate', same assumption and same reasoning
 * as PropertyListingsModule's own docblock.
 */
class FeaturedPropertiesModule {

    public const SELECTION_MODES = [
        'manual'          => 'Manually Selected (via the ⭐ Featured flag on each property)',
        'recently_added'  => 'Recently Added',
        'by_type'         => 'Selected Property Type',
        'by_purpose'      => 'Selected Listing Purpose',
    ];

    /**
     * Applies the selection mode on top of the shared property data —
     * the actual "separate selection mechanism" the request requires,
     * distinct from Property Listings' own plain "show everything"
     * behavior.
     *
     * @param array  $properties  Already resolved via
     *               PropertyListingsModule::get_properties().
     * @param string $mode
     * @param array  $filter      For 'by_type'/'by_purpose': the
     *               specific value to filter by.
     * @param int    $limit       0 = no limit.
     */
    public static function select( array $properties, string $mode = 'manual', array $filter = [], int $limit = 0 ): array {
        switch ( $mode ) {
            case 'by_type':
                $properties = array_values( array_filter( $properties, fn( $p ) => ( $p['property_type'] ?? '' ) === ( $filter['property_type'] ?? '' ) ) );
                break;
            case 'by_purpose':
                $properties = array_values( array_filter( $properties, fn( $p ) => ( $p['listing_purpose'] ?? '' ) === ( $filter['listing_purpose'] ?? '' ) ) );
                break;
            case 'recently_added':
                // Properties are stored in save-order, most-recently-added
                // last — matches how every other repeater-based module in
                // this project already orders its own data.
                $properties = array_reverse( $properties );
                break;
            case 'manual':
            default:
                $properties = array_values( array_filter( $properties, fn( $p ) => ! empty( $p['featured'] ) ) );
                break;
        }
        if ( $limit > 0 ) {
            $properties = array_slice( $properties, 0, $limit );
        }
        return $properties;
    }

    public static function render_title( string $title = 'Featured Properties', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Real Estate</div>
        <h2 class="vs-sec-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-sec-desc" style="max-width:640px;margin:12px auto 0;color:#64748B"><?php echo esc_html( $description ); ?></p><?php endif; ?>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * A visually stronger card than PropertyListingsModule's own, per
     * the request's explicit "must have a stronger visual presentation"
     * requirement — larger image, larger price, always-shown featured
     * ribbon (this section exists specifically to feature something,
     * so the badge is not optional the way it is on the plain listing
     * card).
     */
    public static function render_grid( array $properties, array $display = [], int $grid_cols = 2, array $img_display = [] ): string {
        if ( empty( $properties ) ) { return ''; }
        $show = array_merge( [
            'price' => true, 'location' => true, 'type' => true, 'area' => true,
            'bedrooms' => true, 'bathrooms' => true, 'cta' => true,
        ], $display );
        $currency = \gs_setting( 'currency_symbol', '₹' );
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        ob_start();
        ?>
    <div class="vs-feat-prop-grid">
        <?php foreach ( $properties as $p ):
            if ( empty( $p['title'] ) ) continue;
        ?>
        <div class="vs-feat-prop-card">
            <div class="vs-feat-prop-img-wrap">
                <?php if ( ! empty( $p['image'] ) ): ?>
                    <img src="<?php echo esc_url( $p['image'] ); ?>" alt="<?php echo esc_attr( $p['title'] ); ?>" class="vs-feat-prop-img" loading="lazy" width="600" height="380" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php else: ?>
                    <div class="vs-feat-prop-img-placeholder">🏠</div>
                <?php endif; ?>
                <div class="vs-feat-prop-ribbon">⭐ Featured Property</div>
            </div>
            <div class="vs-feat-prop-body">
                <div class="vs-feat-prop-title"><?php echo esc_html( $p['title'] ); ?></div>
                <?php if ( $show['type'] && ! empty( $p['property_type'] ) && isset( \GoodService\Modules\PropertyListingsModule::PROPERTY_TYPES[ $p['property_type'] ] ) ): ?>
                    <div class="vs-feat-prop-type"><?php echo esc_html( \GoodService\Modules\PropertyListingsModule::PROPERTY_TYPES[ $p['property_type'] ] ); ?></div>
                <?php endif; ?>
                <?php if ( $show['location'] && ! empty( $p['location'] ) ): ?>
                    <div class="vs-feat-prop-location">📍 <?php echo esc_html( $p['location'] ); ?></div>
                <?php endif; ?>
                <?php if ( $show['price'] && ! empty( $p['price'] ) ): ?>
                    <div class="vs-feat-prop-price"><?php echo esc_html( $currency . $p['price'] ); ?></div>
                <?php endif; ?>
                <div class="vs-feat-prop-specs">
                    <?php if ( $show['bedrooms'] && ! empty( $p['bedrooms'] ) ): ?><span><?php echo (int) $p['bedrooms']; ?> Beds</span><?php endif; ?>
                    <?php if ( $show['bathrooms'] && ! empty( $p['bathrooms'] ) ): ?><span><?php echo (int) $p['bathrooms']; ?> Baths</span><?php endif; ?>
                    <?php if ( $show['area'] && ! empty( $p['area'] ) ): ?><span><?php echo esc_html( $p['area'] ); ?></span><?php endif; ?>
                </div>
                <?php if ( $show['cta'] ): ?>
                <button type="button" class="vs-btn vs-btn-primary vs-feat-prop-cta"
                        onclick="vsOpenInquiry({name:'<?php echo esc_js( $p['title'] ); ?>',type:'service',price:'<?php echo esc_js( ! empty( $p['price'] ) ? ( $currency . $p['price'] ) : '' ); ?>'})">View Property</button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $properties     ALL properties (unfiltered) —
     *                  selection is applied inside render(), not by
     *                  the caller, so this module's own selection
     *                  logic stays testable and correct in one place.
     *     @type string $selection_mode
     *     @type array  $selection_filter
     *     @type int    $limit
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $display
     *     @type int    $grid_cols
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $properties = $context['properties'] ?? [];
        $selected = self::select(
            $properties,
            $context['selection_mode'] ?? 'manual',
            (array) ( $context['selection_filter'] ?? [] ),
            (int) ( $context['limit'] ?? 0 )
        );
        if ( empty( $selected ) ) { return ''; } // Real feature — empty-state requirement: no properties selected/matching means the section does not render at all.
        return self::render_title( $context['section_title'] ?? 'Featured Properties', $context['section_description'] ?? '' )
            . self::render_grid(
                $selected,
                (array) ( $context['display'] ?? [] ),
                (int) ( $context['grid_cols'] ?? 2 ),
                (array) ( $context['img_display'] ?? [] )
            );
    }
}
