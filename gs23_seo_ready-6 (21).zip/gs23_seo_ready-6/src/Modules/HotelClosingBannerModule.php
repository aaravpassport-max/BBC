<?php
namespace GoodService\Modules;

/**
 * HotelClosingBannerModule — Hotels / Banquets / Hospitality category,
 * Module 6: "Final Conversion CTA" (custom build spec's Section 22).
 *
 * INVESTIGATION PERFORMED FIRST, per the master build prompt's Section
 * 0.1: WeddingClosingBannerModule (Events & Wedding, its own Section
 * 12) is the exact precedent for this kind of section — a bold,
 * full-width closing bookend near the bottom of the page with one
 * final CTA, no input fields of its own, calling window.vsOpenInquiry()
 * directly rather than inventing a second form. This module follows
 * that module's exact shape and reasoning rather than a new one.
 *
 * Scope note on the spec's Section 32 ("Hospitality Vendor-Type
 * Engine — a single engine driving adaptive copy/IA across every
 * section, not per-hotel/resort/banquet special-casing"): building
 * that full, cross-section engine is a large, standalone piece of
 * work spanning every module already shipped in this category, not
 * something to bolt on as a side effect of one closing-banner module.
 * This module instead reuses WeddingClosingBannerModule's own narrower
 * pattern — an adaptive heading keyed off a simple business-type
 * selection local to this section only (mirroring
 * WeddingEventsModule::closing_banner_heading()'s vendor_types
 * lookup) — which gives the same real per-vendor-type value at this
 * one section without prematurely inventing the platform-wide engine
 * the spec describes. If/when that engine is built, this module's
 * business_type field is the natural place to wire it in.
 */
class HotelClosingBannerModule {

    public const BUSINESS_TYPES = [
        'hotel'         => 'Hotel / Resort',
        'banquet_hall'  => 'Banquet Hall',
        'wedding_venue' => 'Wedding Venue',
        'guest_house'   => 'Guest House / Serviced Apartment',
    ];

    public static function heading_for( string $business_type ): string {
        return match ( $business_type ) {
            'banquet_hall'  => "Let's Host Your Perfect Event",
            'wedding_venue' => "Let's Make Your Big Day Unforgettable",
            'guest_house'   => "Let's Make Your Stay Memorable",
            default         => "Let's Make Your Stay Exceptional",
        };
    }

    /**
     * @param array $context {
     *     @type string $business_type
     *     @type string $section_title       vendor override; falls back to the adaptive heading when blank.
     *     @type string $section_description  vendor override; falls back to the default copy when blank.
     * }
     */
    public static function render( array $context ): string {
        $business_type = (string) ( $context['business_type'] ?? '' );

        $heading = trim( (string) ( $context['section_title'] ?? '' ) );
        if ( $heading === '' ) {
            $heading = self::heading_for( $business_type );
        }
        $desc = trim( (string) ( $context['section_description'] ?? '' ) );
        if ( $desc === '' ) {
            $desc = "Get in touch and we'll help you plan every detail.";
        }

        ob_start();
        ?>
    <div class="gs-hcb-inner">
        <h2 class="vs-sec-title gs-hcb-heading"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $desc !== '' ): ?><p class="gs-hcb-desc"><?php echo esc_html( $desc ); ?></p><?php endif; ?>
        <button type="button" class="gs-hcb-btn" onclick="vsOpenInquiry()">Get In Touch</button>
    </div>
<?php
        return ob_get_clean();
    }
}
