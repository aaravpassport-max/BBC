<?php
namespace GoodService\Modules;

/**
 * HomeServicesGuaranteeModule — Home Services, Module 4: "License,
 * Insurance & Service Guarantee."
 *
 * INVESTIGATION NOTE (master build prompt Section 0.2 — read the most
 * similar existing thing before building): the custom build spec's
 * Section 05 "Trust & Why Choose Us" was NOT built as its own module.
 * Two universal, already-registered, default-enabled modules already
 * cover exactly that ground for every category including Home
 * Services: `why` (WhyModule — an icon+title+description trust-badge
 * grid, 'categories' => 'all') and `trust_bar` (TrustBarModule — a
 * scrolling trust-strip). A Home-Services-specific "Trust & Why Us"
 * module would duplicate both, which the custom build spec's own
 * Section 32 Data-Density Requirement explicitly warns against.
 *
 * What genuinely is NOT covered by either generic module: structured,
 * home-services-particular trust CREDENTIALS with real fields — a
 * licence number and type, an actual insurance coverage figure, a
 * real years-in-business number, the vendor's own worded guarantee,
 * and a real response-time commitment. These are exactly the
 * category-specific signals the spec's Section 05 calls out by name
 * that a generic icon grid renders poorly (a license number typed
 * into a generic "title" field has no structure). This module exists
 * only for that structured content — never as a second copy of the
 * generic Why grid.
 *
 * Same zero-data discipline as every other module in this build:
 * every credential is vendor-entered and shown only when actually
 * filled in. No item defaults to a generic "Licensed & Insured"
 * claim the vendor never typed, and there is no invented "X years"
 * or fabricated coverage figure.
 */
class HomeServicesGuaranteeModule {

    public static function get_data( $wpdb, string $table_prefix, int $listing_id ): array {
        return \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'home_services_guarantee', $listing_id );
    }

    public static function render_title( string $title = 'Licensed, Insured & Guaranteed', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-hgty-eyebrow">Our Assurance</div>
    <h2 class="vs-sec-title gs-hgty-title"><?php echo esc_html( $title ); ?></h2>
    <?php if ( $description !== '' ): ?><p class="gs-hgty-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $data {
     *     @type string $license_number
     *     @type string $license_type
     *     @type bool   $insured
     *     @type string $insurance_amount
     *     @type string $years_in_business
     *     @type string $response_time
     *     @type bool   $background_checked_staff
     *     @type string $guarantee_text
     * }
     */
    public static function render_credentials( array $data ): string {
        $license_number    = trim( (string) ( $data['license_number'] ?? '' ) );
        $license_type      = trim( (string) ( $data['license_type'] ?? '' ) );
        $insured           = ! empty( $data['insured'] );
        $insurance_amount  = trim( (string) ( $data['insurance_amount'] ?? '' ) );
        $years_in_business = trim( (string) ( $data['years_in_business'] ?? '' ) );
        $response_time     = trim( (string) ( $data['response_time'] ?? '' ) );
        $bg_checked        = ! empty( $data['background_checked_staff'] );
        $guarantee_text    = trim( (string) ( $data['guarantee_text'] ?? '' ) );

        $tiles = [];
        if ( $license_number !== '' || $license_type !== '' ) {
            $label = $license_type !== '' ? $license_type : 'Licensed';
            $tiles[] = [ 'icon' => '📜', 'label' => $label, 'value' => $license_number !== '' ? ( 'Licence No. ' . $license_number ) : '' ];
        }
        if ( $insured ) {
            $tiles[] = [ 'icon' => '🛡️', 'label' => 'Fully Insured', 'value' => $insurance_amount !== '' ? $insurance_amount : '' ];
        }
        if ( $years_in_business !== '' && is_numeric( $years_in_business ) && (int) $years_in_business > 0 ) {
            $tiles[] = [ 'icon' => '📅', 'label' => ( (int) $years_in_business ) . '+ Years in Business', 'value' => '' ];
        }
        if ( $response_time !== '' ) {
            $tiles[] = [ 'icon' => '⏱️', 'label' => 'Response Time', 'value' => $response_time ];
        }
        if ( $bg_checked ) {
            $tiles[] = [ 'icon' => '✅', 'label' => 'Background-Checked Staff', 'value' => '' ];
        }

        if ( empty( $tiles ) && $guarantee_text === '' ) { return ''; }

        ob_start();
        ?>
    <?php if ( ! empty( $tiles ) ): ?>
    <div class="gs-hgty-grid">
        <?php foreach ( $tiles as $tile ): ?>
        <div class="gs-hgty-tile">
            <div class="gs-hgty-icon"><?php echo esc_html( $tile['icon'] ); ?></div>
            <div class="gs-hgty-label"><?php echo esc_html( $tile['label'] ); ?></div>
            <?php if ( $tile['value'] !== '' ): ?><div class="gs-hgty-value"><?php echo esc_html( $tile['value'] ); ?></div><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?php if ( $guarantee_text !== '' ): ?>
    <div class="gs-hgty-guarantee">
        <div class="gs-hgty-guarantee-icon">🤝</div>
        <p class="gs-hgty-guarantee-text"><?php echo esc_html( $guarantee_text ); ?></p>
    </div>
    <?php endif; ?>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $data
     *     @type string $section_title
     *     @type string $section_description
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_credentials( (array) ( $context['data'] ?? [] ) );
        if ( $html === '' ) { return ''; } // Mandatory empty-state.
        return self::render_title( $context['section_title'] ?? 'Licensed, Insured & Guaranteed', $context['section_description'] ?? '' ) . $html;
    }
}
