<?php
namespace GoodService\Modules;

/**
 * BeautyExpertsModule — Beauty & Salon, Section 03 of 6: "Beauty
 * Experts/Stylists". Every field here is vendor-entered exactly as
 * saved — experience, rating, languages, and the "verified" badge are
 * never computed, inferred, or defaulted to a plausible-looking value;
 * a field left blank simply does not render (Section 19's mandatory
 * zero-data rule), rather than showing a fabricated "4.8★" or
 * "Verified" that the vendor never actually set.
 *
 * "Book With {Specialist}" reuses the real, existing Service Booking
 * Wizard (window.vsOpenServiceWizard) rather than a parallel booking
 * system, per this build's confirmed approach — extended with a new,
 * optional `specialist` field on its own shared state object so every
 * other category's use of the same wizard is completely unaffected
 * when that field is simply never set.
 */
class BeautyExpertsModule {

    public static function render_title( string $title = 'Meet Our Beauty Experts', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-beauty-sec-head">
        <div class="gs-beauty-eyebrow">Our Team</div>
        <h2 class="vs-sec-title gs-beauty-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-beauty-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $img_display  fit/position/zoom — shared,
     *              gs_vs_img_display_style() helper.
     */
    public static function render_grid( array $experts, array $img_display = [] ): string {
        $experts = array_values( array_filter( $experts, fn( $e ) => ! empty( $e['name'] ) ) );
        if ( empty( $experts ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];

        ob_start();
        ?>
    <div class="gs-beauty-experts-grid">
        <?php foreach ( $experts as $e ):
            $specialities = array_values( array_filter( array_map( 'trim', explode( ',', (string) ( $e['specialities'] ?? '' ) ) ) ) );
            $languages    = array_values( array_filter( array_map( 'trim', explode( ',', (string) ( $e['languages'] ?? '' ) ) ) ) );
            $rating       = trim( (string) ( $e['rating'] ?? '' ) );
            $has_rating   = $rating !== '' && is_numeric( $rating ) && (float) $rating > 0 && (float) $rating <= 5;
            $payload = [
                'name' => $e['name'], 'specialist_id' => $e['id'] ?? '', 'specialist_name' => $e['name'],
            ];
        ?>
        <div class="gs-beauty-expert-card">
            <?php if ( ! empty( $e['photo'] ) ): ?>
            <div class="gs-beauty-expert-media">
                <img src="<?php echo esc_url( $e['photo'] ); ?>" alt="<?php echo esc_attr( $e['name'] ); ?>" class="gs-beauty-expert-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php if ( ! empty( $e['verified'] ) ): ?><span class="gs-beauty-expert-verified" title="Verified">✓ Verified</span><?php endif; ?>
            </div>
            <?php endif; ?>
            <div class="gs-beauty-expert-body">
                <div class="gs-beauty-expert-name"><?php echo esc_html( $e['name'] ); ?></div>
                <?php if ( ! empty( $e['designation'] ) ): ?><div class="gs-beauty-expert-role"><?php echo esc_html( $e['designation'] ); ?></div><?php endif; ?>
                <?php if ( $has_rating ): ?><div class="gs-beauty-expert-rating">★ <?php echo esc_html( number_format( (float) $rating, 1 ) ); ?></div><?php endif; ?>
                <?php if ( ! empty( $specialities ) ): ?>
                <div class="gs-beauty-expert-tags">
                    <?php foreach ( $specialities as $sp ): ?><span class="gs-beauty-expert-tag"><?php echo esc_html( $sp ); ?></span><?php endforeach; ?>
                </div>
                <?php endif; ?>
                <?php if ( ! empty( $e['bio'] ) ): ?><p class="gs-beauty-expert-bio"><?php echo esc_html( $e['bio'] ); ?></p><?php endif; ?>
                <div class="gs-beauty-expert-meta">
                    <?php if ( ! empty( $e['experience'] ) ): ?><span>💼 <?php echo esc_html( $e['experience'] ); ?></span><?php endif; ?>
                    <?php if ( ! empty( $languages ) ): ?><span>🗣️ <?php echo esc_html( implode( ', ', $languages ) ); ?></span><?php endif; ?>
                </div>
                <?php if ( ! empty( $e['bookable'] ) ): ?>
                <button type="button" class="gs-beauty-expert-book-btn" onclick='vsOpenServiceWizard({name:<?php echo wp_json_encode( "Appointment with " . $e['name'] ); ?>,listing_id:window.LID||0,specialist:<?php echo wp_json_encode( $payload ); ?>})'>Book with <?php echo esc_html( self::first_name( $e['name'] ) ); ?></button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    private static function first_name( string $full_name ): string {
        $parts = explode( ' ', trim( $full_name ) );
        return $parts[0] ?? $full_name;
    }

    /**
     * @param array $context {
     *     @type array  $experts
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid( $context['experts'] ?? [], (array) ( $context['img_display'] ?? [] ) );
        if ( $html === '' ) { return ''; } // Mandatory empty-state.
        return self::render_title( $context['section_title'] ?? 'Meet Our Beauty Experts', $context['section_description'] ?? '' ) . $html;
    }
}
