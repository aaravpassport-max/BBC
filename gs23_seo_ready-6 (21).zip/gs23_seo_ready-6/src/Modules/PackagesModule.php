<?php
namespace GoodService\Modules;

/**
 * PackagesModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of 'packages_title' and 'packages_grid'. No
 * logic changes.
 *
 * IMPORTANT, checked per the corrected methodology in Section 6.9
 * BEFORE writing anything: `packages_data` is NOT in vendor-site.php's
 * global decode loop's `$json_fields` list — unlike faq_data,
 * why_choose_data, and process_data (which ARE in that list and always
 * arrive pre-decoded), `packages_data` genuinely does arrive as a raw
 * JSON string. The original code's defensive decode
 * (`is_string($primary->packages_data) ? json_decode(...) : ...`) is
 * therefore genuinely necessary and correct as-is — preserved exactly,
 * not "fixed" (there is nothing to fix here, unlike the FAQ/Why case).
 *
 * Uses the existing global helpers gs_setting() and
 * gs_vs_img_display_style() (both declared in src/functions.php,
 * always-available) and the existing $_json_has_real_content closure's
 * equivalent logic reimplemented here as a static method, since the
 * original is a closure captured by `use()` rather than a named global
 * function — not something callable directly from outside
 * vendor-site.php's scope.
 */
class PackagesModule {

    public static function render_title( array $cd ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['packages_section_title'] ?? 'Our Packages'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Faithful reimplementation of the $_json_has_real_content closure
     * (defined in vendor-site.php ~line 625) — same logic, exposed as
     * a static method since the original closure isn't callable from
     * outside that file's local scope.
     */
    public static function json_has_real_content( $raw, string $required_key ): bool {
        if ( empty( $raw ) ) { return false; }
        $decoded = json_decode( (string) $raw, true );
        if ( ! is_array( $decoded ) ) { return false; }
        if ( array_key_exists( $required_key, $decoded ) ) {
            return ! empty( $decoded[ $required_key ] );
        }
        foreach ( $decoded as $item ) {
            if ( is_array( $item ) && ! empty( $item[ $required_key ] ?? null ) ) { return true; }
        }
        return false;
    }

    public static function render_grid( $primary, array $cd ): string {
        if ( ! self::json_has_real_content( $primary->packages_data ?? null, 'name' ) ) { return ''; }
        $items = is_string($primary->packages_data) ? (json_decode($primary->packages_data, true) ?: []) : $primary->packages_data;
        $currency = \gs_setting('currency_symbol', '₹');
        ob_start();
        ?>
    <div class="vs-pkg-grid">
        <?php
        $show_reviews = ( $cd['packages_show_reviews'] ?? 1 ) ? true : false;
        foreach ($items as $p): if (empty($p['name'])) continue;
            $features_full = is_array($p['features'] ?? null) ? $p['features'] : array_filter(array_map('trim', explode("\n", $p['features'] ?? '')));
            $features_full = array_values(array_filter(array_map(function($f){ return ltrim(trim((string)$f), '-✕+✓ '); }, $features_full)));
            $features_preview = array_slice($features_full, 0, 2);
            $cta_text   = $p['cta_text'] ?? 'Book Now';

            $dp_sections = [];
            if ( ! empty( $features_full ) ) {
                $dp_sections[] = [ 'content_type' => 'list', 'title' => "What's Included", 'icon' => '✅', 'list_items' => $features_full ];
            }
            if ( ! empty( $p['description'] ) ) {
                $dp_sections[] = [ 'content_type' => 'richtext', 'title' => 'About this package', 'icon' => '📝', 'body' => esc_html( $p['description'] ) ];
            }
            $custom_vms = is_string( $p['view_more_sections'] ?? null ) ? ( json_decode( $p['view_more_sections'], true ) ?: [] ) : ( $p['view_more_sections'] ?? [] );
            if ( is_array( $custom_vms ) ) {
                foreach ( $custom_vms as $vms_section ) {
                    if ( is_array( $vms_section ) ) { $dp_sections[] = $vms_section; }
                }
            }
            if ( $show_reviews && ! empty( $primary->id ) ) {
                $dp_sections[] = [ 'content_type' => 'reviews', 'title' => 'Client Reviews', 'icon' => '⭐', 'listing_id' => (int) $primary->id ];
            }
            $price_display = ! empty( $p['price'] ) ? ( $currency . $p['price'] . ( ! empty( $p['period'] ) ? ' · ' . $p['period'] : '' ) ) : 'Custom';

            $addons_raw = is_array( $p['addons'] ?? null ) ? $p['addons'] : array_filter( array_map( 'trim', explode( "\n", $p['addons'] ?? '' ) ) );
            $addons_parsed = [];
            foreach ( $addons_raw as $addon_line ) {
                $parts = array_map( 'trim', explode( '|', $addon_line, 2 ) );
                if ( empty( $parts[0] ) ) { continue; }
                $addons_parsed[] = [ 'name' => $parts[0], 'price' => isset( $parts[1] ) ? (float) preg_replace( '/[^0-9.]/', '', $parts[1] ) : 0 ];
            }
            $wizard_payload = [
                'name'        => $p['name'],
                'price'       => (float) preg_replace( '/[^0-9.]/', '', (string) ( $p['price'] ?? 0 ) ),
                'period'      => $p['period'] ?? '',
                'description' => $p['description'] ?? '',
                'image'       => $p['image'] ?? '',
                'features'    => $features_full,
                'addons'      => $addons_parsed,
                'gst_type'    => $p['gst_type'] ?? 'not_applicable',
                'gst_percent' => (float) ( $p['gst_percent'] ?? 0 ),
                'currency'    => $currency,
                'listing_id'  => (int) ( $primary->id ?? 0 ),
            ];
            $use_wizard = ( $cd['packages_booking_wizard'] ?? 1 ) ? true : false;
        ?>
        <div class="vs-pkg-card">
            <div class="vs-pkg-img">
                <?php if (!empty($p['image'])): ?>
                    <img src="<?php echo esc_url($p['image']); ?>" alt="<?php echo esc_attr($p['name']); ?>" loading="lazy" width="400" height="300" style="<?php echo esc_attr( \gs_vs_img_display_style( is_array( $cd['packages_img_display'] ?? null ) ? $cd['packages_img_display'] : [] )['img'] ); ?>">
                <?php else: ?>
                    <div class="vs-pkg-img-fallback">📦</div>
                <?php endif; ?>
            </div>
            <div class="vs-pkg-main">
                <?php if (!empty($p['badge'])): ?><div class="vs-pkg-badge"><?php echo esc_html($p['badge']); ?></div><?php endif; ?>
                <div class="vs-pkg-name"><?php echo esc_html($p['name']); ?></div>
                <?php if (!empty($primary->avg_rating) && !empty($primary->review_count)): ?>
                <div class="vs-pkg-meta">
                    <span class="vs-pkg-rating"><span class="vs-pkg-rating-star">★</span> <?php echo esc_html(number_format((float)$primary->avg_rating, 2)); ?></span>
                    <span>(<?php echo esc_html((int)$primary->review_count); ?> reviews)</span>
                </div>
                <?php endif; ?>
                <?php if (!empty($p['short_description'])): ?>
                <div class="vs-pkg-short-desc"><?php echo esc_html($p['short_description']); ?></div>
                <?php endif; ?>
                <div class="vs-pkg-price-row">
                    <span class="vs-pkg-price"><?php echo esc_html($price_display); ?></span>
                </div>
                <?php if (!empty($features_preview)): ?>
                <ul class="vs-pkg-features">
                    <?php foreach ($features_preview as $feat): ?>
                    <li><?php echo esc_html($feat); ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
                <button type="button" class="vs-pkg-view-details"
                        data-title="<?php echo esc_attr($p['name']); ?>"
                        data-price="<?php echo esc_attr($price_display); ?>"
                        data-image="<?php echo esc_attr($p['image'] ?? ''); ?>"
                        data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $p['additional_images'] ?? null ) ? $p['additional_images'] : [] ) ) ) ); ?>"
                        data-img-fit="<?php echo esc_attr( in_array( $cd['pkg_popup_img_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $cd['pkg_popup_img_fit'] ?? 'cover' ) : 'cover' ); ?>"
                       data-slider-interval="<?php echo esc_attr( (int) ( ( (float) ( $cd['pkg_slider_interval'] ?? 0 ) ) * 1000 ) ); ?>"
                        data-sections="<?php echo esc_attr(wp_json_encode($dp_sections)); ?>"
                        data-pkg="<?php echo $use_wizard ? esc_attr(wp_json_encode($wizard_payload)) : ''; ?>"
                        onclick="vsOpenDetailPopup(event, this)">View details</button>
                <?php if ($use_wizard): ?>
                <button type="button" class="vs-pkg-add-btn" data-pkg="<?php echo esc_attr(wp_json_encode($wizard_payload)); ?>" onclick="vsOpenBookingWizard(this)"><?php echo esc_html($cta_text); ?></button>
                <?php else: ?>
                <button type="button" class="vs-pkg-add-btn" onclick="vsOpenInquiry({name:'<?php echo esc_js($p['name']); ?>',type:'service',price:'<?php echo esc_js($price_display); ?>'})"><?php echo esc_html($cta_text); ?></button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $primary = $context['primary'] ?? null;
        $cd = $context['cd'] ?? [];
        return self::render_title( $cd ) . self::render_grid( $primary, $cd );
    }
}
