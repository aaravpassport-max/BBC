<?php
namespace GoodService\Modules;

/**
 * HotelVirtualTourModule — Hotels / Banquets / Hospitality category,
 * Module 5: "Virtual Tour" (custom build spec's Section 17).
 *
 * INVESTIGATION PERFORMED FIRST, per the master build prompt's Section
 * 0.1: no existing module in this codebase embeds a video/360 tour as
 * its own section. Two existing, proven pieces of logic are reused
 * rather than reinvented: TestimonialsModule's own YouTube URL → embed
 * URL regex (for a plain video walkthrough) and ContactModule's own
 * wp_kses() iframe-attribute allowlist (for a Matterport/360-tour
 * embed code) — see those two modules for the original patterns this
 * one is built from.
 *
 * Deliberately a single-item section — a hotel has one virtual tour,
 * not a repeater of many — so there is no admin repeater UI to
 * duplicate from elsewhere; this is the simplest possible correct
 * shape for the content it holds.
 */
class HotelVirtualTourModule {

    /** Same regex TestimonialsModule already uses for a plain YouTube
     * walkthrough video — not reinvented. Vimeo added for parity since
     * hotel/venue tour videos are commonly hosted there too. */
    private static function to_embed_url( string $url ): string {
        if ( preg_match( '/(?:youtube\.com\/watch\?v=|youtu\.be\/)([A-Za-z0-9_-]+)/', $url, $m ) ) {
            return 'https://www.youtube.com/embed/' . $m[1];
        }
        if ( preg_match( '/vimeo\.com\/(\d+)/', $url, $m ) ) {
            return 'https://player.vimeo.com/video/' . $m[1];
        }
        return '';
    }

    public static function render_title( string $heading = 'Take a Virtual Tour', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-hvt-sec-head">
        <h2 class="vs-sec-title gs-hvt-title"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-hvt-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param string $video_url    A YouTube/Vimeo watch URL (converted
     *                             to an embeddable URL here).
     * @param string $embed_code   A raw <iframe> embed code (e.g. from
     *                             Matterport/a 360° tour provider) —
     *                             sanitized through the same iframe
     *                             attribute allowlist ContactModule's
     *                             map embed already uses, never
     *                             trusted as raw HTML.
     */
    public static function render_embed( string $video_url, string $embed_code ): string {
        $video_url  = trim( $video_url );
        $embed_code = trim( $embed_code );
        $embed_src  = $video_url !== '' ? self::to_embed_url( $video_url ) : '';

        if ( $embed_src === '' && $embed_code === '' ) { return ''; }

        ob_start();
        ?>
    <div class="gs-hvt-wrap">
        <div class="gs-hvt-frame">
            <?php if ( $embed_src !== '' ): ?>
            <iframe src="<?php echo esc_url( $embed_src ); ?>" title="Virtual Tour" loading="lazy" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            <?php elseif ( $embed_code !== '' ): ?>
            <?php echo wp_kses( $embed_code, [ 'iframe' => [ 'src' => true, 'width' => true, 'height' => true, 'frameborder' => true, 'allowfullscreen' => true, 'loading' => true, 'referrerpolicy' => true, 'style' => true, 'allow' => true, 'title' => true ] ] ); ?>
            <?php endif; ?>
        </div>
    </div>
<?php
        return ob_get_clean();
    }

    public static function get_data( $wpdb, string $table_prefix, int $listing_id ): array {
        $stored = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'hotel_virtual_tour', $listing_id );
        return [
            'video_url'  => trim( (string) ( $stored['video_url'] ?? '' ) ),
            'embed_code' => trim( (string) ( $stored['embed_code'] ?? '' ) ),
        ];
    }

    /**
     * @param array $context {
     *     @type string $video_url
     *     @type string $embed_code
     *     @type string $section_title
     *     @type string $section_description
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_embed(
            (string) ( $context['video_url'] ?? '' ),
            (string) ( $context['embed_code'] ?? '' )
        );
        if ( $html === '' ) { return ''; } // Mandatory empty-state — custom build spec's Section 48.
        return self::render_title( $context['section_title'] ?? 'Take a Virtual Tour', $context['section_description'] ?? '' ) . $html;
    }
}
