<?php
namespace GoodService\Modules;

/**
 * ProcessModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of the existing "How Process Works" rendering
 * logic from vendor-site.php's $_el_capture calls for 'process_title'
 * and 'process_steps'. No logic changes.
 *
 * Checked (per the corrected methodology in this project's roadmap
 * Section 6.9, added after two prior sections wrongly claimed a
 * JSON-decode bug): `process_data` IS in vendor-site.php's global
 * decode loop's `$json_fields` list (~line 391, "Decode all JSON
 * blobs"), so `$primary->process_data` always arrives as a real,
 * already-decoded array by the time this callback runs — no defensive
 * string-decoding needed here, and none added, to avoid repeating the
 * same mistake of inventing a "fix" for something that isn't broken.
 *
 * Note: `process_title` reads `$primary->process_section_title`
 * directly (NOT `$hd['process_section_title']` the way FAQ/Why read
 * their titles from `$hd`) — traced and confirmed this is a genuine,
 * deliberate difference in this section's data source, not a typo to
 * "correct" during migration.
 */
class ProcessModule {

    /** Faithful copy of the 'process_title' $_el_capture callback. */
    public static function render_title( $process_section_title ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($process_section_title ?? 'How Process Works'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0;background:var(--vs-yellow)"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /** Faithful copy of the 'process_steps' $_el_capture callback. */
    /**
     * @param string $img_fit Image Fit — site-wide image-fit audit: this
     *                        section previously hardcoded the uploaded
     *                        step icon to its natural aspect with no fit
     *                        control at all. Now a real, vendor-facing
     *                        setting (cover/contain/fill/auto/scale-down).
     */
    public static function render_steps( $process_data, string $img_fit = 'contain' ): string {
        if ( empty( $process_data ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( [ 'fit' => $img_fit ] )['img'];
        ob_start();
        ?>
    <div class="vs-proc-grid">
        <?php foreach ($process_data as $i => $step): if (empty($step['title'])) continue; ?>
        <div class="vs-proc-step">
            <div class="vs-proc-num">
                <?php if (!empty($step['icon_image'])): ?>
                    <img src="<?php echo esc_url($step['icon_image']); ?>" alt="<?php echo esc_attr($step['title']); ?>" loading="lazy" width="108" height="108" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php else: ?>
                    <?php echo !empty($step['icon'])?esc_html($step['icon']):($i+1); ?>
                <?php endif; ?>
            </div>
            <div class="vs-proc-title"><?php echo esc_html($step['title']); ?></div>
            <?php if (!empty($step['description'])): ?><div class="vs-proc-desc"><?php echo esc_html($step['description']); ?></div><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $primary = $context['primary'] ?? null;
        $title = $primary->process_section_title ?? null;
        $process_data = $context['module_data']['process_data']
            ?? ( $primary->process_data ?? null );
        return self::render_title( $title ) . self::render_steps( $process_data, (string) ( $context['img_fit'] ?? 'contain' ) );
    }
}
