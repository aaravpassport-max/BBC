<?php
namespace GoodService\Modules;

/**
 * HotelEventsShowcaseModule — Hotels / Banquets / Hospitality category,
 * Module 2: "Events at the Property" (custom build spec's Sections 04
 * and 05 combined: Weddings & Celebrations, and Real Events / Event
 * Gallery — the spec's own explicit instruction was "do not create
 * just another image gallery", and the "Weddings" section and the
 * "Real Events" section describe the exact same underlying content —
 * named event case studies with photos — so they are combined into one
 * module here rather than shipped as two thin, overlapping sections,
 * matching this codebase's own established Data-Density principle
 * (see HomeServicesCatalogueModule's docblock for the same reasoning
 * applied to a different category).
 *
 * INVESTIGATION PERFORMED FIRST, per the master build prompt's Section
 * 0.1: WeddingStoriesModule (Events & Wedding category) already
 * implements almost exactly this concept — named "story" cards with a
 * title, description, date, location, category and a per-story photo
 * set that opens its own independently-scoped window.vsLightbox()
 * gallery. That module is category-gated to 'events-wedding' and is
 * NOT reused directly (a banquet-hall vendor in the 'hotels' category
 * cannot activate a module gated to a different category), so this
 * module follows its exact same proven structure and reuses the same
 * platform mechanism (window.vsLightbox(url, caption, gridId)) rather
 * than inventing a new gallery engine — while adding the two fields
 * the spec explicitly calls for that WeddingStoriesModule has no
 * equivalent of: guest_count and venue_used ("Ballroom + Lawn", "350
 * Guests" in the spec's own worked example).
 *
 * Master build prompt Section 8 (Manage/View Details) — REAL GAP FOUND
 * AND FIXED: this module's cards have title/description/meta/type, real
 * per-item content beyond what fits comfortably in the card, and had NO
 * View Details trigger at all. Fixed by wiring the same auto-generated
 * vsOpenDetailPopup() pattern HotelEventSpacesModule's "Explore Venue"
 * button already uses (description as a richtext section, the meta
 * bits as a list section) — not the full clOpenDetailBuilder custom-
 * content admin builder, since (matching Event Spaces' own precedent)
 * there is no additional freeform content a vendor would need to enter
 * beyond what this module already collects.
 *
 * Master build prompt Section 3 (Rows & Columns / Sorting / Show-Hide
 * Fields) — deliberately NOT built, per Section 0.1's own instruction to
 * follow the actual most-similar existing module: this module's own
 * cited structural precedent, WeddingStoriesModule, has none of these
 * controls either (confirmed directly — grepped for
 * wedding_stories_columns/_max_rows/_sort/_show_ in create-listing.php,
 * zero matches), so building them here would make this module MORE
 * complex than its own precedent, not consistent with it. If a future
 * pass adds these controls to WeddingStoriesModule, they should be added
 * here at the same time for the same reason.
 */
class HotelEventsShowcaseModule {

    /** Own, independent constant — not borrowed from
     * WeddingEventsModule::PORTFOLIO_CATEGORIES, per this codebase's
     * "modules stay independent" principle (see CertificationsModule's
     * own docblock for the same reasoning). Covers the spec's own
     * Section 04 event-type list plus a hotel-specific 'conference'. */
    public const EVENT_TYPES = [
        'wedding'        => 'Wedding',
        'reception'      => 'Reception',
        'engagement'     => 'Engagement',
        'mehndi'         => 'Mehndi',
        'haldi'          => 'Haldi',
        'sangeet'        => 'Sangeet',
        'cocktail'       => 'Cocktail',
        'anniversary'    => 'Anniversary',
        'birthday'       => 'Birthday',
        'private_event'  => 'Private Event',
        'conference'     => 'Conference',
        'other'          => 'Other',
    ];

    public static function render_title( string $heading = 'Events at the Property', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-hevs-sec-head">
        <div class="gs-hevs-eyebrow">Real Celebrations, Real Events</div>
        <h2 class="vs-sec-title gs-hevs-title"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-hevs-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render_grid( array $events, array $img_display = [] ): string {
        // Same real, deliberate rule as WeddingStoriesModule: an event
        // with zero real photos never renders as an empty card.
        $events = array_values( array_filter( $events, function ( $e ) {
            if ( ! is_array( $e ) || trim( (string) ( $e['title'] ?? '' ) ) === '' ) { return false; }
            $photos = array_values( array_filter( (array) ( $e['photos'] ?? [] ), fn( $p ) => is_string( $p ) && trim( $p ) !== '' ) );
            return ! empty( $photos );
        } ) );
        if ( empty( $events ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];

        ob_start();
        ?>
    <div class="gs-hevs-grid">
        <?php foreach ( $events as $_idx => $event ):
            $photos    = array_values( array_filter( (array) ( $event['photos'] ?? [] ), fn( $p ) => is_string( $p ) && trim( $p ) !== '' ) );
            $cover     = $photos[0];
            $title     = trim( (string) ( $event['title'] ?? '' ) );
            $desc      = trim( (string) ( $event['description'] ?? '' ) );
            $location  = trim( (string) ( $event['location'] ?? '' ) );
            $venue     = trim( (string) ( $event['venue_used'] ?? '' ) );
            $guests    = isset( $event['guest_count'] ) && is_numeric( $event['guest_count'] ) && (int) $event['guest_count'] > 0 ? (int) $event['guest_count'] : null;
            $type_key  = (string) ( $event['event_type'] ?? '' );
            $type_label = self::EVENT_TYPES[ $type_key ] ?? '';
            $grid_id   = 'gs-hevs-event-' . $_idx . '-grid';
            $meta_bits = array_values( array_filter( [ $location, $venue, $guests !== null ? $guests . ' Guests' : '' ] ) );
            // Manage/View Details (master build prompt Section 8) — same
            // pattern as HotelEventSpacesModule's own "Explore Venue"
            // trigger: auto-generated data-sections built from this
            // event's own real fields (no separate custom-content builder
            // needed here, same judgment call already made for Event
            // Spaces — there is nothing this card collects that isn't
            // already surfaced by an auto-generated section).
            $_vmp_sections = array_values( array_filter( [
                $desc !== '' ? [ 'content_type' => 'richtext', 'title' => 'About This Event', 'icon' => '📝', 'body' => esc_html( $desc ) ] : null,
                ! empty( $meta_bits ) ? [ 'content_type' => 'list', 'title' => 'Event Details', 'icon' => 'ℹ️', 'list_items' => $meta_bits ] : null,
            ] ) );
        ?>
        <div class="gs-hevs-card">
            <button type="button" class="gs-hevs-cover" onclick="vsLightbox('<?php echo esc_js( $cover ); ?>','<?php echo esc_js( $title ); ?>','<?php echo esc_js( $grid_id ); ?>')">
                <img src="<?php echo esc_url( $cover ); ?>" alt="<?php echo esc_attr( $title ); ?>" class="gs-hevs-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php if ( $type_label !== '' ): ?><span class="gs-hevs-badge"><?php echo esc_html( $type_label ); ?></span><?php endif; ?>
                <span class="gs-hevs-count">View Gallery — <?php echo count( $photos ); ?> photo<?php echo count( $photos ) === 1 ? '' : 's'; ?></span>
            </button>
            <div class="gs-hevs-body">
                <div class="gs-hevs-card-title"><?php echo esc_html( $title ); ?></div>
                <?php if ( ! empty( $meta_bits ) ): ?><div class="gs-hevs-meta"><?php echo esc_html( implode( ' · ', $meta_bits ) ); ?></div><?php endif; ?>
                <?php if ( $desc !== '' ): ?><p class="gs-hevs-card-desc"><?php echo esc_html( $desc ); ?></p><?php endif; ?>
                <?php if ( ! empty( $_vmp_sections ) ): ?>
                <a href="#" class="gs-hevs-details-link"
                   data-title="<?php echo esc_attr( $title ); ?>"
                   data-image="<?php echo esc_attr( $cover ); ?>"
                   data-sections="<?php echo esc_attr( wp_json_encode( $_vmp_sections ) ); ?>"
                   onclick="event.preventDefault();vsOpenDetailPopup(event,this)">View Full Details</a>
                <?php endif; ?>
            </div>
            <div class="gs-hevs-hidden-photos" id="<?php echo esc_attr( $grid_id ); ?>" hidden>
                <?php foreach ( $photos as $_p ): ?>
                <img src="<?php echo esc_url( $_p ); ?>" alt="<?php echo esc_attr( $title ); ?>">
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function get_events( $wpdb, string $table_prefix, int $listing_id ): array {
        $stored = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'hotel_events_showcase', $listing_id );
        return array_values( array_filter( (array) ( $stored['items'] ?? [] ), fn( $e ) => is_array( $e ) ) );
    }

    /**
     * @param array $context {
     *     @type array  $items
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid(
            (array) ( $context['items'] ?? [] ),
            (array) ( $context['img_display'] ?? [] )
        );
        if ( $html === '' ) { return ''; } // Mandatory empty-state — custom build spec's Section 48.
        return self::render_title( $context['section_title'] ?? 'Events at the Property', $context['section_description'] ?? '' ) . $html;
    }
}
