<?php
namespace GoodService\Modules;

/**
 * PropertyTypesModule — real estate module 3 of 4.
 *
 * Same independence pattern as FeaturedPropertiesModule: reads the
 * shared property data via PropertyListingsModule::get_properties(),
 * never checks whether 'property_listings' (or any other real-estate
 * module) is itself active. Counts are computed fresh from that data
 * on each render — a single already-fetched in-memory array grouped
 * once, not a repeated database query per category, so this stays
 * cheap without needing a dedicated caching layer of its own.
 *
 * Deliberately reuses PropertyListingsModule::PROPERTY_TYPES as the
 * category taxonomy rather than inventing a second, separate list —
 * the request itself asks for categories to come from "the platform's
 * structured Real Estate property taxonomy rather than being
 * hard-coded", and the one taxonomy that actually determines what a
 * property IS in this system is that same constant every property is
 * already tagged against. A second, independently-hardcoded category
 * list (e.g. one including "Penthouse" or "Showroom", named in the
 * request's own illustrative example) would risk listing categories
 * no property could ever actually belong to, or missing one a
 * property IS tagged with — this module's counts would silently be
 * wrong in either direction. Using the one real source of truth makes
 * that class of bug structurally impossible.
 *
 * Category-gated to 'real-estate', same assumption as the other two
 * real-estate modules already built this session.
 */
class PropertyTypesModule {

    /** A representative icon per property type, used when the vendor
     * hasn't set a custom category image. */
    public const TYPE_ICONS = [
        'apartment' => '🏢', 'villa' => '🏡', 'independent_house' => '🏠',
        'builder_floor' => '🏘️', 'plot' => '📐', 'commercial' => '🏬',
        'office' => '🏢', 'shop' => '🏪', 'warehouse' => '🏭',
        'industrial' => '🏗️', 'other' => '🏗️',
    ];

    /**
     * Groups the shared property data by type and counts each —
     * the actual, accurate count the request requires ("must remain
     * accurate when properties are added, removed, unpublished or
     * changed"), computed fresh from the same live data every other
     * real-estate module reads, not a separately-maintained number
     * that could drift out of sync.
     *
     * @param array $properties  Already resolved via
     *              PropertyListingsModule::get_properties().
     * @return array [ property_type => count ], only for types that
     *              have at least one property — a type with zero
     *              properties is never returned at all, matching the
     *              request's own "do not force every possible
     *              category to display" for types the vendor hasn't
     *              enabled AND for types that are empty regardless.
     */
    public static function get_counts( array $properties ): array {
        $counts = [];
        foreach ( $properties as $p ) {
            $type = $p['property_type'] ?? 'other';
            if ( ! isset( PropertyListingsModule::PROPERTY_TYPES[ $type ] ) ) { $type = 'other'; }
            $counts[ $type ] = ( $counts[ $type ] ?? 0 ) + 1;
        }
        return $counts;
    }

    public static function render_title( string $title = 'Browse by Property Type', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Real Estate</div>
        <h2 class="vs-sec-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-sec-desc" style="max-width:640px;margin:12px auto 0;color:#64748B"><?php echo esc_html( $description ); ?></p><?php endif; ?>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $counts         [ property_type => count ], from get_counts().
     * @param array $enabled_types  Which types the vendor has chosen to
     *              show — matches the request's own explicit example
     *              (Residential ✓, Commercial ✓, Industrial ✕). Empty
     *              array means "show every type that has properties",
     *              the sensible default for a vendor who hasn't
     *              curated this yet.
     * @param array $images         [ property_type => image_url ], vendor-set
     *              per-category images, matching the request's own
     *              "Category image" field.
     */
    /** @param string $img_fit Image Fit — site-wide image-fit audit: previously hardcoded, now a real vendor-facing setting. */
    public static function render_grid( array $counts, array $enabled_types = [], array $images = [], int $grid_cols = 3, string $img_fit = 'cover' ): string {
        if ( empty( $counts ) ) { return ''; }
        if ( ! empty( $enabled_types ) ) {
            $counts = array_intersect_key( $counts, array_flip( $enabled_types ) );
        }
        if ( empty( $counts ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( [ 'fit' => $img_fit ] )['img'];
        ob_start();
        ?>
    <div class="vs-prop-type-grid">
        <?php foreach ( $counts as $type => $count ):
            $label = PropertyListingsModule::PROPERTY_TYPES[ $type ] ?? ucfirst( $type );
            $icon = self::TYPE_ICONS[ $type ] ?? '🏗️';
            $image = $images[ $type ] ?? '';
        ?>
        <div class="vs-prop-type-card" onclick="vsFilterPropertiesByType('<?php echo esc_js( $type ); ?>')">
            <?php if ( $image !== '' ): ?>
                <img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $label ); ?>" class="vs-prop-type-img" loading="lazy" width="320" height="180" style="<?php echo esc_attr( $_img_style ); ?>">
            <?php else: ?>
                <div class="vs-prop-type-icon"><?php echo $icon; ?></div>
            <?php endif; ?>
            <div class="vs-prop-type-body">
                <div class="vs-prop-type-name"><?php echo esc_html( $label ); ?></div>
                <div class="vs-prop-type-count"><?php echo (int) $count; ?> Propert<?php echo $count === 1 ? 'y' : 'ies'; ?></div>
                <div class="vs-prop-type-cta">View Properties</div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $properties     ALL properties (unfiltered) —
     *                  counts are computed inside render(), matching
     *                  FeaturedPropertiesModule's own pattern of
     *                  keeping the derivation logic in one place.
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $enabled_types
     *     @type array  $images
     *     @type int    $grid_cols
     * }
     */
    public static function render( array $context ): string {
        $properties = $context['properties'] ?? [];
        $counts = self::get_counts( $properties );
        $grid = self::render_grid(
            $counts,
            (array) ( $context['enabled_types'] ?? [] ),
            (array) ( $context['images'] ?? [] ),
            (int) ( $context['grid_cols'] ?? 3 ),
            (string) ( $context['img_fit'] ?? 'cover' )
        );
        if ( $grid === '' ) { return ''; } // Real feature — empty-state requirement: no applicable categories means the section does not render at all.
        return self::render_title( $context['section_title'] ?? 'Browse by Property Type', $context['section_description'] ?? '' ) . $grid;
    }
}
