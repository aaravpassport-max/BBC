<?php
namespace GoodService\Modules;

/**
 * ServicesModule — Phase 2 of the modular listing architecture roadmap.
 *
 * By far the largest and most feature-rich section migrated so far:
 * category grouping (with the "never show an empty category heading"
 * safety net), a shared dual-mode (image/icon) card renderer used by
 * both the flat and grouped paths, server-rendered crawlable text for
 * the view-more popup content (via SeoContentExtractor, same instance
 * powering SEO scoring — deliberately not a separate extraction so the
 * two can never drift apart), lead-enquiry popups, and a genuinely
 * tricky "pricing at a glance" gate (explicit customizer override takes
 * priority; the 3+-priced-items count only applies as the DEFAULT when
 * the vendor has never touched the toggle — not stacked on top of it).
 *
 * `services_data` IS in vendor-site.php's global decode loop's
 * `$json_fields` list (~line 393), so it always arrives pre-decoded —
 * checked per the corrected methodology in Section 6.9 before writing
 * anything; no false "bug" claim repeated here.
 *
 * Faithful extraction of 'services_title' and 'services_grid'. No
 * logic changes. Calls the existing global helpers
 * gs_vs_normalize_view_more_sections() and gs_vs_field_label() (both
 * declared with function_exists() guards elsewhere in vendor-site.php)
 * rather than reimplementing them — confirmed both are always-available
 * global functions, not reinvented here.
 */
class ServicesModule {

    public static function render_title( $primary, array $hd ): string {
        $sec_title = $primary->services_section_title ?? 'Our Services';
        $sec_desc  = $primary->services_section_desc  ?? '';
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow"><?php echo esc_html($hd['services_section_subtitle']??'What We Offer'); ?></div>
        <h2 class="vs-sec-title"><?php echo esc_html($sec_title); ?></h2>
        <?php if($sec_desc): ?><div class="vs-sec-sub"><?php echo esc_html($sec_desc); ?></div><?php endif; ?>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render_card(
        array $svc, bool $can_lead_popup, array $cd, $primary,
        int $cv_svc_icon_img_width, int $cv_svc_icon_img_size, int $cv_svc_icon_img_radius,
        float $cv_svc_icon_img_bg_opacity, int $cv_svc_icon_img_border_w, int $cv_svc_icon_img_padding,
        string $cv_svc_icon_img_shadow, int $cv_svc_icon_img_rotation, string $cv_svc_icon_img_fit,
        float $cv_svc_icon_img_opacity, array $shadow_map
    ): string {
        $_svc_has_vms = !empty($svc['view_more_sections']);
        $_svc_structured_sections = [];
        $_svc_highlights = is_array( $svc['highlights'] ?? null ) ? $svc['highlights'] : array_filter( array_map( 'trim', explode( "\n", $svc['highlights'] ?? '' ) ) );
        if ( ! empty( $_svc_highlights ) ) {
            $_svc_structured_sections[] = [ '_field' => 'highlights', 'content_type' => 'list', 'title' => \gs_vs_field_label( $cd, 'services', 'step1_highlights_label', 'Highlights' ), 'icon' => '✨', 'list_items' => array_values( $_svc_highlights ) ];
        }
        if ( ! empty( $svc['full_description'] ) ) {
            $_svc_structured_sections[] = [ '_field' => 'full_description', 'content_type' => 'richtext', 'title' => \gs_vs_field_label( $cd, 'services', 'field_full_description_label', 'About this service' ), 'icon' => '📝', 'body' => esc_html( $svc['full_description'] ) ];
        }
        $_svc_custom_sections = $_svc_has_vms
            ? ( is_string( $svc['view_more_sections'] ) ? ( json_decode( $svc['view_more_sections'], true ) ?: [] ) : $svc['view_more_sections'] )
            : [];
        $_svc_sections = array_merge( $_svc_structured_sections, $_svc_custom_sections );
        if ( ! empty( $_svc_structured_sections ) ) { $_svc_has_vms = true; }
        $_svc_show_reviews = ( $cd['services_show_reviews'] ?? 1 ) ? true : false;
        if ( $_svc_show_reviews && ! empty( $primary->id ) ) {
            $_svc_sections[] = [ 'content_type' => 'reviews', 'title' => 'Client Reviews', 'icon' => '⭐', 'listing_id' => (int) $primary->id ];
            $_svc_has_vms = true;
        }
        $_can_lead_popup = $can_lead_popup;
        ob_start();
        ?>
        <div class="vs-svc-card"<?php if ($_svc_has_vms): ?> style="cursor:pointer" onclick="vsOpenDetailPopup(event,this)"
              data-title="<?php echo esc_attr($svc['name']); ?>" data-duration="<?php echo esc_attr($svc['duration']??''); ?>"
              data-image="<?php echo esc_attr($svc['image'] ?? ($svc['icon_image'] ?? '')); ?>"
              data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $svc['additional_images'] ?? null ) ? $svc['additional_images'] : [] ) ) ) ); ?>"
              data-img-fit="<?php echo esc_attr( in_array( $cd['svc_popup_img_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $cd['svc_popup_img_fit'] ?? 'cover' ) : 'cover' ); ?>"
                       data-slider-interval="<?php echo esc_attr( (int) ( ( (float) ( $cd['svc_slider_interval'] ?? 0 ) ) * 1000 ) ); ?>"
              data-price="<?php echo esc_attr($svc['price'] ?? ''); ?>"
              data-sections="<?php echo esc_attr( wp_json_encode( $_svc_sections ) ); ?>"<?php endif; ?>>
            <?php if (!empty($svc['image'])): ?>
              <!-- Image mode: cover photo at top -->
              <div class="vs-svc-img">
                <div class="vs-img-clip">
                  <img src="<?php echo esc_url($svc['image']); ?>" alt="<?php echo esc_attr($svc['name']); ?>" loading="lazy" width="400" height="300">
                </div>
              </div>
              <div class="vs-svc-card-body">
                <div class="vs-svc-name"><?php echo esc_html($svc['name']); ?></div>
                <?php if (!empty($svc['description'])): ?>
                  <div class="vs-svc-desc" style="margin-top:6px;flex:1"><?php echo esc_html($svc['description']); ?></div>
                <?php endif; ?>
                <?php if ($_svc_has_vms): ?>
                  <a href="#" class="vs-view-more-link" onclick="event.stopPropagation();vsOpenDetailPopup(event,this)"
                     data-title="<?php echo esc_attr($svc['name']); ?>" data-duration="<?php echo esc_attr($svc['duration']??''); ?>"
                     data-image="<?php echo esc_attr($svc['image'] ?? ''); ?>"
                     data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $svc['additional_images'] ?? null ) ? $svc['additional_images'] : [] ) ) ) ); ?>"
                     data-img-fit="<?php echo esc_attr( in_array( $cd['svc_popup_img_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $cd['svc_popup_img_fit'] ?? 'cover' ) : 'cover' ); ?>"
                       data-slider-interval="<?php echo esc_attr( (int) ( ( (float) ( $cd['svc_slider_interval'] ?? 0 ) ) * 1000 ) ); ?>"
                     data-price="<?php echo esc_attr($svc['price'] ?? ''); ?>"
                     data-sections="<?php echo esc_attr( wp_json_encode( $_svc_sections ) ); ?>">View More →</a>
                <?php endif; ?>
              </div>
              <?php if (!empty($svc['price']) || !empty($svc['link']) || $_can_lead_popup): ?>
              <div class="vs-svc-card-footer">
                <?php if (!empty($svc['price'])): ?><div class="vs-svc-price"><?php echo esc_html($svc['price']); ?></div><?php endif; ?>
                <?php if (!empty($svc['link'])): ?><a href="<?php echo esc_url($svc['link']); ?>" onclick="event.stopPropagation()" class="vs-btn vs-btn-ghost" style="font-size:.8rem">Learn More →</a><?php endif; ?>
                <?php if ( $_can_lead_popup ): ?><button onclick="event.stopPropagation();vsOpenSvcEnquiry('<?php echo esc_js($svc['name']); ?>','<?php echo esc_js($svc['price']??''); ?>','<?php echo esc_js( wp_json_encode( ['full_description'=>$svc['full_description']??'','duration'=>$svc['duration']??'','highlights'=>array_values(is_array($svc['highlights']??null)?$svc['highlights']:array_filter(array_map('trim',explode(chr(10),$svc['highlights']??''))))] ) ); ?>')" class="vs-svc-enquire-btn">📋 Enquire Now</button><?php endif; ?>
              </div>
              <?php endif; ?>
            <?php else: ?>
              <!-- Icon/emoji mode: centred layout -->
              <div class="vs-svc-card-body">
                <div class="vs-svc-icon" <?php if (!empty($svc['icon_image'])): ?>style="
                  width:<?php echo $cv_svc_icon_img_width > 0 ? $cv_svc_icon_img_width.'px' : $cv_svc_icon_img_size.'px'; ?>;
                  height:<?php echo $cv_svc_icon_img_size; ?>px;
                  border-radius:<?php echo $cv_svc_icon_img_radius; ?>px;
                  opacity:<?php echo $cv_svc_icon_img_bg_opacity; ?>;
                  border-width:<?php echo $cv_svc_icon_img_border_w; ?>px;border-style:solid;
                  padding:<?php echo $cv_svc_icon_img_padding; ?>px;
                  box-shadow:<?php echo $shadow_map[$cv_svc_icon_img_shadow] ?? 'none'; ?>;
                  transform:rotate(<?php echo $cv_svc_icon_img_rotation; ?>deg);
                "<?php endif; ?>>
                  <?php if (!empty($svc['icon_image'])): ?>
                    <img src="<?php echo esc_url($svc['icon_image']); ?>" alt="<?php echo esc_attr($svc['name']); ?>" loading="lazy" width="56" height="56" style="object-fit:<?php echo esc_attr($cv_svc_icon_img_fit); ?>;opacity:<?php echo $cv_svc_icon_img_opacity; ?>">
                  <?php else: ?>
                    <span style="font-size:1.6rem"><?php echo !empty($svc['icon']) ? esc_html($svc['icon']) : '🛠️'; ?></span>
                  <?php endif; ?>
                </div>
                <div class="vs-svc-name"><?php echo esc_html($svc['name']); ?></div>
                <?php if (!empty($svc['description'])): ?>
                  <div class="vs-svc-desc" style="margin-top:6px;flex:1"><?php echo esc_html($svc['description']); ?></div>
                <?php endif; ?>
                <?php if ($_svc_has_vms): ?>
                  <a href="#" class="vs-view-more-link" onclick="event.stopPropagation();vsOpenDetailPopup(event,this)"
                     data-title="<?php echo esc_attr($svc['name']); ?>" data-duration="<?php echo esc_attr($svc['duration']??''); ?>"
                     data-image="<?php echo esc_attr($svc['icon_image'] ?? ''); ?>"
                     data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $svc['additional_images'] ?? null ) ? $svc['additional_images'] : [] ) ) ) ); ?>"
                     data-img-fit="<?php echo esc_attr( in_array( $cd['svc_popup_img_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $cd['svc_popup_img_fit'] ?? 'cover' ) : 'cover' ); ?>"
                       data-slider-interval="<?php echo esc_attr( (int) ( ( (float) ( $cd['svc_slider_interval'] ?? 0 ) ) * 1000 ) ); ?>"
                     data-price="<?php echo esc_attr($svc['price'] ?? ''); ?>"
                     data-sections="<?php echo esc_attr( wp_json_encode( $_svc_sections ) ); ?>">View More →</a>
                <?php endif; ?>
              </div>
              <?php if (!empty($svc['price']) || !empty($svc['link']) || $_can_lead_popup): ?>
              <div class="vs-svc-card-footer">
                <?php if (!empty($svc['price'])): ?><div class="vs-svc-price"><?php echo esc_html($svc['price']); ?></div><?php endif; ?>
                <?php if (!empty($svc['link'])): ?><a href="<?php echo esc_url($svc['link']); ?>" onclick="event.stopPropagation()" class="vs-btn vs-btn-ghost" style="font-size:.8rem">Learn More →</a><?php endif; ?>
                <?php if ( $_can_lead_popup ): ?><button onclick="event.stopPropagation();vsOpenSvcEnquiry('<?php echo esc_js($svc['name']); ?>','<?php echo esc_js($svc['price']??''); ?>','<?php echo esc_js( wp_json_encode( ['full_description'=>$svc['full_description']??'','duration'=>$svc['duration']??'','highlights'=>array_values(is_array($svc['highlights']??null)?$svc['highlights']:array_filter(array_map('trim',explode(chr(10),$svc['highlights']??''))))] ) ); ?>')" class="vs-svc-enquire-btn">📋 Enquire Now</button><?php endif; ?>
              </div>
              <?php endif; ?>
            <?php endif; ?>
            <?php
            if ( $_svc_has_vms ) {
                $_svc_popup_text = \GoodService\SEO\SeoContentExtractor::extract_view_more_text( $svc['view_more_sections'] );
                if ( $_svc_popup_text !== '' ) {
                    echo '<div class="vs-sr-only">' . esc_html( $_svc_popup_text ) . '</div>';
                }
            }
            ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function render_grid(
        $primary, array $cd, int $cv_svc_grid_cols, int $cv_svc_max_rows, bool $can_lead_popup,
        int $cv_svc_icon_img_width, int $cv_svc_icon_img_size, int $cv_svc_icon_img_radius,
        float $cv_svc_icon_img_bg_opacity, int $cv_svc_icon_img_border_w, int $cv_svc_icon_img_padding,
        string $cv_svc_icon_img_shadow, int $cv_svc_icon_img_rotation, string $cv_svc_icon_img_fit,
        float $cv_svc_icon_img_opacity, array $shadow_map
    ): string {
        if ( empty( $primary->services_data ) ) { return ''; }

        $_svc_render_list = \gs_vs_normalize_view_more_sections( $primary->services_data );
        if ( $cv_svc_max_rows > 0 ) {
            $_svc_render_list = array_slice( $_svc_render_list, 0, $cv_svc_grid_cols * $cv_svc_max_rows );
        }

        $_svc_cats = is_array( $primary->service_categories ?? null ) ? $primary->service_categories : [];
        $_svc_cat_ids_used = [];
        foreach ( $_svc_render_list as $_s ) {
            if ( ! empty( $_s['category_id'] ) ) { $_svc_cat_ids_used[ $_s['category_id'] ] = true; }
        }
        $_svc_cats_active = array_values( array_filter( $_svc_cats, fn( $c ) => isset( $_svc_cat_ids_used[ $c['id'] ?? null ] ) ) );
        $_svc_is_categorized = ! empty( $_svc_cats_active );

        $render_card = fn( $svc ) => self::render_card(
            $svc, $can_lead_popup, $cd, $primary,
            $cv_svc_icon_img_width, $cv_svc_icon_img_size, $cv_svc_icon_img_radius,
            $cv_svc_icon_img_bg_opacity, $cv_svc_icon_img_border_w, $cv_svc_icon_img_padding,
            $cv_svc_icon_img_shadow, $cv_svc_icon_img_rotation, $cv_svc_icon_img_fit,
            $cv_svc_icon_img_opacity, $shadow_map
        );

        ob_start();

        if ( ! $_svc_is_categorized ) {
        ?>
        <div class="vs-svc-grid">
            <?php foreach ($_svc_render_list as $svc): if (empty($svc['name'])) continue; echo $render_card($svc); endforeach; ?>
        </div>
        <?php
        } else {
            foreach ( $_svc_cats_active as $_cat ) {
                $_cat_items = array_filter( $_svc_render_list, fn( $s ) => ! empty( $s['name'] ) && ( $s['category_id'] ?? '' ) === $_cat['id'] );
                if ( empty( $_cat_items ) ) continue;
            ?>
            <div class="vs-svc-cat-heading"><?php echo esc_html( $_cat['name'] ); ?></div>
            <div class="vs-svc-grid" style="margin-bottom:28px">
                <?php foreach ( $_cat_items as $svc ) { echo $render_card($svc); } ?>
            </div>
            <?php
            }
            $_svc_uncat = array_filter( $_svc_render_list, function( $s ) use ( $_svc_cats ) {
                if ( empty( $s['name'] ) ) return false;
                $cid = $s['category_id'] ?? '';
                if ( $cid === '' ) return true;
                return ! in_array( $cid, array_column( $_svc_cats, 'id' ), true );
            } );
            if ( ! empty( $_svc_uncat ) ) {
            ?>
            <div class="vs-svc-grid">
                <?php foreach ( $_svc_uncat as $svc ) { echo $render_card($svc); } ?>
            </div>
            <?php
            }
        }
    ?>
    <!-- Part 21.2 — Compact pricing table for quick scanning -->
    <?php
        $priced_svcs = array_filter($primary->services_data ?? [], fn($s) => !empty($s['price']) && !empty($s['name']));
        $_pricing_glance_explicit = array_key_exists( 'show_pricing_glance', (array) $cd );
        $_show_pricing_glance = ! empty( $priced_svcs ) && ( $_pricing_glance_explicit
            ? ( (bool) $cd['show_pricing_glance'] )
            : ( count( $priced_svcs ) >= 3 ) );
        if ($_show_pricing_glance):
        ?>
    <div style="margin-top:20px;background:#F8FAFC;border-radius:12px;overflow:hidden;border:1px solid #E2E8F0">
      <div style="padding:12px 18px;font-weight:700;font-size:.85rem;color:#475569;background:#F1F5F9;border-bottom:1px solid #E2E8F0">💰 Pricing at a glance</div>
      <table style="width:100%;border-collapse:collapse">
        <?php foreach(array_slice($priced_svcs, 0, 8) as $psvc): ?>
        <tr style="border-bottom:1px solid #F1F5F9">
          <td style="padding:10px 18px;font-size:.85rem;color:#334155"><?php echo esc_html($psvc['name']); ?></td>
          <td style="padding:10px 18px;font-size:.85rem;font-weight:700;color:#2563EB;text-align:right;white-space:nowrap"><?php echo esc_html($psvc['price']); ?></td>
          <td style="padding:10px 14px;text-align:right">
            <?php if ( $can_lead_popup ): ?><button onclick="vsOpenSvcEnquiry('<?php echo esc_js($psvc['name']); ?>','<?php echo esc_js($psvc['price']); ?>','<?php echo esc_js( wp_json_encode( ['full_description'=>$psvc['full_description']??'','duration'=>$psvc['duration']??'','highlights'=>array_values(is_array($psvc['highlights']??null)?$psvc['highlights']:array_filter(array_map('trim',explode(chr(10),$psvc['highlights']??''))))] ) ); ?>')"
                    style="background:none;border:1.5px solid #2563EB;color:#2563EB;border-radius:7px;padding:4px 10px;font-size:.72rem;font-weight:700;cursor:pointer">
              Get Quote
            </button><?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </table>
      <div style="padding:10px 18px;font-size:.74rem;color:#647388;border-top:1px solid #F1F5F9">Prices are indicative. Final quote after site visit.</div>
    </div>
    <?php endif; ?>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $primary = $context['primary'] ?? null;
        $hd = $context['hd'] ?? [];
        $cd = $context['cd'] ?? [];
        $shadow_map = $context['shadow_map'] ?? ['none'=>'none','sm'=>'0 2px 8px rgba(0,0,0,.06)','md'=>'0 4px 16px rgba(0,0,0,.1)','lg'=>'0 8px 32px rgba(0,0,0,.15)'];
        $out = self::render_title( $primary, $hd );
        $out .= self::render_grid(
            $primary, $cd,
            max( 1, min( 6, (int) ( $cd['svc_grid_cols'] ?? 4 ) )),
            max( 0, min( 10, (int) ( $cd['svc_max_rows'] ?? 0 ) ) ),
            (bool) ( $context['can_lead_popup'] ?? true ),
            max( 0, min( 250, (int) ( $cd['svc_icon_img_width'] ?? 0 ) ) ),
            max( 20, min( 250, (int) ( $cd['svc_icon_img_size'] ?? 56 ) ) ),
            max( 0, min( 999, (int) ( $cd['svc_icon_img_radius'] ?? 14 ) ) ),
            max( 0, min( 100, (int) ( $cd['svc_icon_img_bg_opacity'] ?? 100 ) ) ) / 100,
            max( 0, min( 20, (int) ( $cd['svc_icon_img_border_width'] ?? 0 ) ) ),
            max( 0, min( 60, (int) ( $cd['svc_icon_img_padding'] ?? 0 ) ) ),
            in_array( $cd['svc_icon_img_shadow'] ?? '', ['none','sm','md','lg'], true ) ? $cd['svc_icon_img_shadow'] : 'none',
            max( -180, min( 180, (int) ( $cd['svc_icon_img_rotation'] ?? 0 ) ) ),
            $context['cv_svc_icon_img_fit'] ?? 'contain',
            max( 0, min( 100, (int) ( $cd['svc_icon_img_opacity'] ?? 100 ) ) ) / 100,
            $shadow_map
        );
        return $out;
    }
}
