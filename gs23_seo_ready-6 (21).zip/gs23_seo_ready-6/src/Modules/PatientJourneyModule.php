<?php
namespace GoodService\Modules;

/**
 * PatientJourneyModule — Health & Wellness, module 5 of 5, the final
 * module in this category build. Answers "what happens when I book an
 * appointment here?" Deliberately the lightest module in this
 * category, matching the request's own complexity ranking — a single
 * repeater of journey steps, no cross-referencing to any other module,
 * fully independent by construction, the same real architecture
 * already proven for Interior Designers & Architects' own Design
 * Process module.
 *
 * A default patient journey is provided as pre-fill in the admin
 * panel, not enforced in this class — every part of it must remain
 * vendor-editable (add/remove/reorder/rename/edit), matching the same
 * real requirement Design Process was built against. Suggested step
 * text is deliberately neutral, matching this category's own medical-
 * safety requirement applied consistently across every module this
 * category build has needed it for: no outcome claims, no guarantees,
 * nothing beyond describing what the process itself involves.
 */
class PatientJourneyModule {

    public const LAYOUTS = [
        'timeline'   => 'Timeline',
        'vertical'   => 'Vertical Process',
        'horizontal' => 'Horizontal Process',
    ];

    /** Suggested default steps shown as admin panel pre-fill — never
     * enforced here, and deliberately written in neutral, descriptive
     * language rather than any outcome-implying phrasing. */
    public const SUGGESTED_STEPS = [
        [ 'name' => 'Book Appointment', 'description' => 'Schedule a visit online, by phone, or by walking in.' ],
        [ 'name' => 'Initial Consultation', 'description' => 'Discuss your concerns and medical history with the doctor.' ],
        [ 'name' => 'Assessment', 'description' => 'Relevant examinations or diagnostic tests, if needed.' ],
        [ 'name' => 'Discussion of Options', 'description' => 'Review available options and next steps together.' ],
        [ 'name' => 'Treatment / Procedure', 'description' => 'Carried out according to the agreed plan.' ],
        [ 'name' => 'Follow-Up', 'description' => 'A follow-up visit or check-in as advised.' ],
    ];

    public static function render_title( string $title = 'Your Patient Journey', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-hw-sec-head">
        <div class="vs-hw-eyebrow">What Happens Next</div>
        <h2 class="vs-sec-title vs-hw-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-hw-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $steps  Each entry {name, description, duration}.
     *              Step numbers are derived from array position
     *              (1-indexed) at render time — never stored — so
     *              reordering in the admin panel is reflected
     *              automatically.
     */
    public static function render_steps( array $steps, string $layout = 'timeline' ): string {
        $steps = array_values( array_filter( $steps, fn( $s ) => ! empty( $s['name'] ) ) );
        if ( empty( $steps ) ) { return ''; }
        $layout = in_array( $layout, array_keys( self::LAYOUTS ), true ) ? $layout : 'timeline';
        ob_start();
        ?>
    <div class="vs-hw-journey vs-hw-journey-<?php echo esc_attr( $layout ); ?>">
        <?php foreach ( $steps as $i => $step ):
            $num = $i + 1;
        ?>
        <div class="vs-hw-journey-step">
            <div class="vs-hw-journey-num"><?php echo str_pad( (string) $num, 2, '0', STR_PAD_LEFT ); ?></div>
            <div class="vs-hw-journey-body">
                <div class="vs-hw-journey-name"><?php echo esc_html( $step['name'] ); ?></div>
                <?php if ( ! empty( $step['description'] ) ): ?><p class="vs-hw-journey-desc"><?php echo esc_html( $step['description'] ); ?></p><?php endif; ?>
                <?php if ( ! empty( $step['duration'] ) ): ?><div class="vs-hw-journey-duration">⏱ <?php echo esc_html( $step['duration'] ); ?></div><?php endif; ?>
            </div>
            <?php if ( $num < count( $steps ) ): ?><div class="vs-hw-journey-connector" aria-hidden="true"></div><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $steps
     *     @type string $layout
     *     @type string $section_title
     *     @type string $section_description
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_steps( $context['steps'] ?? [], $context['layout'] ?? 'timeline' );
        if ( $html === '' ) { return ''; } // Real feature — empty-state requirement.
        return self::render_title( $context['section_title'] ?? 'Your Patient Journey', $context['section_description'] ?? '' ) . $html;
    }
}
