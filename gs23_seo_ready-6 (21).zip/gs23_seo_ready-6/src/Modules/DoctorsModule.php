<?php
namespace GoodService\Modules;

/**
 * DoctorsModule — Health & Wellness, module 3 of 5. "For most clinics,
 * the doctor is one of the strongest trust factors" — the request's
 * own framing, and this is built as one of the two "Advanced"
 * complexity modules in this category as a direct result.
 *
 * Owns the real doctor data both Departments and Featured Services
 * read from directly. Cross-references back to Services for a
 * doctor's own "Available Services" (the reverse of Featured
 * Services' own doctor-matching), via
 * HealthWellnessModule::get_services_for_doctor().
 *
 * Medical safety, by construction not by filtering, exactly matching
 * the same principle already established for Featured Services:
 * "Do not automatically create medical qualifications or credentials.
 * Everything must be vendor-entered." There is no synthesis path
 * anywhere in this class — every qualification, certification, and
 * biography line a visitor sees is exactly what the vendor typed.
 */
class DoctorsModule {

    public const LAYOUTS = [
        'grid'      => 'Professional Profile Grid',
        'featured'  => 'Featured Doctor',
        'editorial' => 'Editorial Team Layout',
    ];

    public static function render_title( string $title = 'Our Doctors', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-hw-sec-head">
        <div class="vs-hw-eyebrow">Meet Our Team</div>
        <h2 class="vs-sec-title vs-hw-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-hw-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Builds the doctor's full professional profile popup — reuses
     * the platform's own established shared detail popup rather than
     * a new profile system, matching the request's own "Doctor Profile
     * Experience" field list exactly.
     */
    private static function build_detail_sections( array $doctor, array $services ): array {
        $sections = [];
        $professional = [];
        if ( ! empty( $doctor['qualifications'] ) ) { $professional[] = 'Qualifications: ' . $doctor['qualifications']; }
        if ( ! empty( $doctor['certifications'] ) ) { $professional[] = 'Certifications: ' . $doctor['certifications']; }
        if ( ! empty( $doctor['years_experience'] ) ) { $professional[] = 'Experience: ' . $doctor['years_experience']; }
        if ( ! empty( $doctor['languages'] ) ) { $professional[] = 'Languages: ' . $doctor['languages']; }
        if ( ! empty( $doctor['areas_of_expertise'] ) ) { $professional[] = 'Areas of Expertise: ' . $doctor['areas_of_expertise']; }
        if ( ! empty( $doctor['memberships'] ) ) { $professional[] = 'Professional Memberships: ' . $doctor['memberships']; }
        if ( ! empty( $professional ) ) {
            $sections[] = [ 'content_type' => 'list', 'title' => 'Professional Background', 'icon' => '🎓', 'list_items' => $professional ];
        }
        if ( ! empty( $doctor['detailed_bio'] ) ) {
            $sections[] = [ 'content_type' => 'richtext', 'title' => 'About Dr. ' . self::last_name_or_full( $doctor['name'] ), 'icon' => '📋', 'body' => esc_html( $doctor['detailed_bio'] ) ];
        }
        if ( ! empty( $doctor['professional_approach'] ) ) {
            $sections[] = [ 'content_type' => 'richtext', 'title' => 'Approach to Care', 'icon' => '💬', 'body' => esc_html( $doctor['professional_approach'] ) ];
        }
        $practice = [];
        if ( ! empty( $doctor['available_days'] ) ) { $practice[] = 'Available Days: ' . $doctor['available_days']; }
        if ( ! empty( $doctor['available_time_slots'] ) ) { $practice[] = 'Time Slots: ' . $doctor['available_time_slots']; }
        if ( ! empty( $doctor['location'] ) ) { $practice[] = 'Location: ' . $doctor['location']; }
        if ( ! empty( $practice ) ) {
            $sections[] = [ 'content_type' => 'list', 'title' => 'Consultation Availability', 'icon' => '🗓️', 'list_items' => $practice ];
        }
        if ( ! empty( $doctor['publications'] ) ) {
            $sections[] = [ 'content_type' => 'richtext', 'title' => 'Publications & Research', 'icon' => '📚', 'body' => esc_html( $doctor['publications'] ) ];
        }
        if ( ! empty( $doctor['awards'] ) ) {
            $sections[] = [ 'content_type' => 'richtext', 'title' => 'Awards & Recognition', 'icon' => '🏆', 'body' => esc_html( $doctor['awards'] ) ];
        }
        $matched_services = HealthWellnessModule::get_services_for_doctor( $services, $doctor );
        if ( ! empty( $matched_services ) ) {
            $sections[] = [ 'content_type' => 'list', 'title' => 'Available Services', 'icon' => '⚕️', 'list_items' => array_column( $matched_services, 'name' ) ];
        }
        return $sections;
    }

    private static function last_name_or_full( string $name ): string {
        $parts = explode( ' ', trim( $name ) );
        return end( $parts ) ?: $name;
    }

    /**
     * @param array $img_display  fit/position/zoom — shared, global helper.
     * @param string $phone       Vendor's own saved phone number, for Appointment CTA.
     */
    public static function render_grid( array $doctors, string $layout = 'grid', array $services = [], array $img_display = [], string $phone = '' ): string {
        $doctors = array_values( array_filter( $doctors, fn( $d ) => ! empty( $d['name'] ) ) );
        if ( empty( $doctors ) ) { return ''; }
        $layout = in_array( $layout, array_keys( self::LAYOUTS ), true ) ? $layout : 'grid';
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        $currency = \gs_setting( 'currency_symbol', '₹' );

        ob_start();
        ?>
    <div class="vs-hw-doctors vs-hw-doctors-layout-<?php echo esc_attr( $layout ); ?>">
        <?php foreach ( $doctors as $_di => $doctor ):
            $is_featured = ( $_di === 0 && $layout === 'featured' );
            $detail_sections = self::build_detail_sections( $doctor, $services );
        ?>
        <div class="vs-hw-doctor-card<?php echo $is_featured ? ' vs-hw-doctor-featured' : ''; ?>">
            <div class="vs-hw-doctor-media">
                <?php if ( ! empty( $doctor['photo'] ) ): ?>
                    <img src="<?php echo esc_url( $doctor['photo'] ); ?>" alt="<?php echo esc_attr( $doctor['name'] ); ?>" class="vs-hw-doctor-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php else: ?>
                    <div class="vs-hw-doctor-img-placeholder">🩺</div>
                <?php endif; ?>
            </div>
            <div class="vs-hw-doctor-body">
                <div class="vs-hw-doctor-name"><?php echo esc_html( $doctor['name'] ); ?></div>
                <?php if ( ! empty( $doctor['title'] ) ): ?><div class="vs-hw-doctor-title"><?php echo esc_html( $doctor['title'] ); ?></div><?php endif; ?>
                <?php if ( ! empty( $doctor['department'] ) ): ?><div class="vs-hw-doctor-dept"><?php echo esc_html( $doctor['department'] ); ?><?php if ( ! empty( $doctor['subspecialty'] ) ): ?> · <?php echo esc_html( $doctor['subspecialty'] ); ?><?php endif; ?></div><?php endif; ?>
                <?php if ( $layout === 'editorial' && ! empty( $doctor['short_bio'] ) ): ?><p class="vs-hw-doctor-bio"><?php echo esc_html( $doctor['short_bio'] ); ?></p><?php endif; ?>
                <?php if ( ! empty( $doctor['years_experience'] ) ): ?><div class="vs-hw-doctor-exp"><?php echo esc_html( $doctor['years_experience'] ); ?> Experience</div><?php endif; ?>
                <?php if ( ! empty( $doctor['in_clinic_consultation'] ) || ! empty( $doctor['online_consultation'] ) ): ?>
                <div class="vs-hw-doctor-modes">
                    <?php if ( ! empty( $doctor['in_clinic_consultation'] ) ): ?><span>🏥 In-Clinic</span><?php endif; ?>
                    <?php if ( ! empty( $doctor['online_consultation'] ) ): ?><span>💻 Online</span><?php endif; ?>
                </div>
                <?php endif; ?>
                <div class="vs-hw-doctor-ctas">
                    <a href="#" class="vs-hw-cta-primary"
                       data-title="<?php echo esc_attr( $doctor['name'] ); ?>"
                       data-image="<?php echo esc_attr( $doctor['photo'] ?? '' ); ?>"
                       data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $doctor['additional_images'] ?? null ) ? $doctor['additional_images'] : [] ) ) ) ); ?>"
                       data-img-fit="<?php echo esc_attr( in_array( $img_display['popup_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $img_display['popup_fit'] ?? 'cover' ) : 'cover' ); ?>"
                   data-slider-interval="<?php echo esc_attr( (int) ( $img_display['interval'] ?? 0 ) ); ?>"
                       data-price="<?php echo ! empty( $doctor['consultation_fee'] ) ? esc_attr( $currency . $doctor['consultation_fee'] . ' consultation' ) : ''; ?>"
                       data-sections="<?php echo esc_attr( wp_json_encode( $detail_sections ) ); ?>"
                       onclick="event.preventDefault();vsOpenDetailPopup(event,this)">View Profile</a>
                    <?php if ( $phone !== '' ): ?><a href="tel:<?php echo esc_attr( $phone ); ?>" class="vs-hw-cta-secondary"><?php echo esc_html( ! empty( $doctor['appointment_cta'] ) ? $doctor['appointment_cta'] : 'Book Appointment' ); ?></a><?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $doctors
     *     @type array  $services
     *     @type string $layout
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     *     @type string $phone
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid(
            $context['doctors'] ?? [],
            $context['layout'] ?? 'grid',
            $context['services'] ?? [],
            (array) ( $context['img_display'] ?? [] ),
            (string) ( $context['phone'] ?? '' )
        );
        if ( $html === '' ) { return ''; } // Real feature — empty-state requirement.
        return self::render_title( $context['section_title'] ?? 'Our Doctors', $context['section_description'] ?? '' ) . $html;
    }
}
