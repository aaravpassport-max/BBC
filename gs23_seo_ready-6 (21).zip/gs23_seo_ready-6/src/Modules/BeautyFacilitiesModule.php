<?php
namespace GoodService\Modules;

/**
 * BeautyFacilitiesModule — Beauty & Salon, Section 04 of 6: "Salon
 * Experience & Facilities". An editorial, split-layout trust section
 * built only from real vendor-ticked facility attributes (Section
 * 0.1's own explicit instruction: never a generic icon-box "Why Choose
 * Us" grid) — a facility appears if and only if the vendor actually
 * ticked it or typed it as a custom facility; nothing here is ever
 * inferred, defaulted to "on", or presented as a platform-wide claim.
 */
class BeautyFacilitiesModule {

    /** The fixed, known set of real facility attributes a vendor can
     * tick — every value here is a genuine physical/operational trait,
     * never a marketing claim ("Best Service", "Award Winning") that
     * would violate the platform's real-data-only rule. */
    public const FACILITIES = [
        'ac'               => 'Air Conditioned',
        'private_rooms'    => 'Private Rooms',
        'parking'          => 'Parking Available',
        'wifi'             => 'Free Wi-Fi',
        'card_payment'     => 'Card Payment Accepted',
        'upi_payment'      => 'UPI Payment Accepted',
        'wheelchair'       => 'Wheelchair Accessible',
        'sanitized_tools'  => 'Sanitized Tools & Equipment',
        'music'            => 'Music / Ambience',
        'refreshments'     => 'Complimentary Refreshments',
        'kids_friendly'    => 'Kids Friendly',
        'home_service'     => 'Home Service Available',
    ];

    public static function render_title( string $title = 'The Salon Experience', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-beauty-eyebrow">Facilities</div>
    <h2 class="vs-sec-title gs-beauty-title gs-beauty-fac-title"><?php echo esc_html( $title ); ?></h2>
    <?php if ( $description !== '' ): ?><p class="gs-beauty-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $facilities        {key: bool} — only the fixed set above.
     * @param string $custom_facilities comma-separated vendor-typed extras.
     */
    public static function render_split( string $image, array $facilities, string $custom_facilities, array $img_display = [] ): string {
        $active = [];
        foreach ( self::FACILITIES as $key => $label ) {
            if ( ! empty( $facilities[ $key ] ) ) { $active[] = $label; }
        }
        $custom = array_values( array_filter( array_map( 'trim', explode( ',', $custom_facilities ) ) ) );
        $all = array_merge( $active, $custom );
        if ( empty( $all ) ) { return ''; } // Mandatory empty-state — no real facility data at all.
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];

        ob_start();
        ?>
    <div class="gs-beauty-facilities-split<?php echo $image === '' ? ' gs-beauty-facilities-no-img' : ''; ?>">
        <?php if ( $image !== '' ): ?>
        <div class="gs-beauty-facilities-media">
            <img src="<?php echo esc_url( $image ); ?>" alt="Inside the salon" class="gs-beauty-facilities-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
        </div>
        <?php endif; ?>
        <div class="gs-beauty-facilities-content">
            <ul class="gs-beauty-facilities-list">
                <?php foreach ( $all as $label ): ?>
                <li class="gs-beauty-facilities-item"><span class="gs-beauty-facilities-check">✓</span><?php echo esc_html( $label ); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type string $image
     *     @type array  $facilities
     *     @type string $custom_facilities
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_split(
            (string) ( $context['image'] ?? '' ),
            (array) ( $context['facilities'] ?? [] ),
            (string) ( $context['custom_facilities'] ?? '' ),
            (array) ( $context['img_display'] ?? [] )
        );
        if ( $html === '' ) { return ''; }
        return '<div class="gs-beauty-sec-head">' . self::render_title( $context['section_title'] ?? 'The Salon Experience', $context['section_description'] ?? '' ) . '</div>' . $html;
    }
}
