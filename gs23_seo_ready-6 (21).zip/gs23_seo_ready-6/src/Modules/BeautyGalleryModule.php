<?php
namespace GoodService\Modules;

/**
 * BeautyGalleryModule — Beauty & Salon, Section 02 of 6: "Signature
 * Looks & Transformations". Reuses established platform mechanisms
 * rather than building parallel ones, per the master build prompt's
 * Section 0.1:
 *  - the fullscreen lightbox with swipe/keyboard navigation is the
 *    platform's own generic window.vsLightbox(url, caption, gridId) —
 *    already grid-agnostic (built that way specifically so new
 *    sections like this one could plug straight into it), so this
 *    module supplies its own grid id and nothing else.
 *  - the before/after draggable slider is the platform's own generic
 *    window.vsIdaInitBeforeAfterSlider(sliderId) engine (Interior
 *    Designers & Architects, module 3 of 5) — its DOM contract is a
 *    fixed set of class hooks (.vs-ida-ba-before-wrap /
 *    .vs-ida-ba-handle), so this module's before/after cards use
 *    those same structural hook classes to plug into the existing
 *    drag engine, while every other visual element in this section
 *    still uses its own gs-beauty-* namespace, per this build's CSS
 *    isolation requirement.
 */
class BeautyGalleryModule {

    public static function render_title( string $title = 'Signature Looks & Transformations', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-beauty-sec-head">
        <div class="gs-beauty-eyebrow">Our Work</div>
        <h2 class="vs-sec-title gs-beauty-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-beauty-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $img_display  fit/position/zoom — shared,
     *              gs_vs_img_display_style() helper.
     */
    public static function render_grid( array $items, array $img_display = [] ): string {
        // Real, deliberate rule: an item needs EITHER a single image
        // (plain gallery card) OR a genuine before+after pair (slider
        // card) — an item with neither is not a real gallery entry and
        // must never render as an empty placeholder tile.
        $items = array_values( array_filter( $items, fn( $g ) =>
            ! empty( $g['image'] ) || ( ! empty( $g['before_image'] ) && ! empty( $g['after_image'] ) )
        ) );
        if ( empty( $items ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        $grid_id = 'gs-beauty-gallery-grid';

        ob_start();
        ?>
    <div class="gs-beauty-gallery-grid" id="<?php echo esc_attr( $grid_id ); ?>">
        <?php foreach ( $items as $_gi => $g ):
            $is_before_after = ! empty( $g['before_image'] ) && ! empty( $g['after_image'] );
            $title = trim( (string) ( $g['title'] ?? '' ) );
        ?>
        <?php if ( $is_before_after ):
            $uid = 'gs-beauty-ba-' . $_gi . '-' . substr( md5( $title . $g['before_image'] ), 0, 6 );
        ?>
        <div class="gs-beauty-gallery-item gs-beauty-gallery-item-ba">
            <div class="gs-beauty-ba-slider vs-ida-ba-slider" id="<?php echo esc_attr( $uid ); ?>">
                <img src="<?php echo esc_url( $g['after_image'] ); ?>" alt="<?php echo esc_attr( $title !== '' ? $title . ' — after' : 'After' ); ?>" class="gs-beauty-ba-img vs-ida-ba-after" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <div class="vs-ida-ba-before-wrap">
                    <img src="<?php echo esc_url( $g['before_image'] ); ?>" alt="<?php echo esc_attr( $title !== '' ? $title . ' — before' : 'Before' ); ?>" class="gs-beauty-ba-img vs-ida-ba-before" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                </div>
                <div class="vs-ida-ba-handle gs-beauty-ba-handle" style="left:50%">
                    <div class="vs-ida-ba-handle-grip gs-beauty-ba-handle-grip">&#8596;</div>
                </div>
                <span class="gs-beauty-ba-tag gs-beauty-ba-tag-before">Before</span>
                <span class="gs-beauty-ba-tag gs-beauty-ba-tag-after">After</span>
            </div>
            <script>if(window.vsIdaInitBeforeAfterSlider){vsIdaInitBeforeAfterSlider('<?php echo esc_js( $uid ); ?>');}else{document.addEventListener('DOMContentLoaded',function(){vsIdaInitBeforeAfterSlider('<?php echo esc_js( $uid ); ?>');});}</script>
            <?php if ( $title !== '' ): ?><div class="gs-beauty-gallery-caption"><?php echo esc_html( $title ); ?></div><?php endif; ?>
        </div>
        <?php else: ?>
        <?php
            // Whole-card-click-opens-lightbox: same established platform
            // pattern used elsewhere (duplicate the same action onto the
            // card wrapper, inner interactive element stops propagation)
            // — real fix for "only the image itself opened the lightbox,
            // the caption below it did nothing." Both call the exact
            // same vsLightbox(...) with identical arguments, so there is
            // never a second, divergent code path to drift out of sync.
        ?>
        <div class="gs-beauty-gallery-item" style="cursor:pointer" onclick="vsLightbox('<?php echo esc_js( $g['image'] ); ?>','<?php echo esc_js( $title ); ?>','<?php echo esc_js( $grid_id ); ?>')">
            <a href="#" class="gs-beauty-gallery-link" onclick="event.preventDefault();event.stopPropagation();vsLightbox('<?php echo esc_js( $g['image'] ); ?>','<?php echo esc_js( $title ); ?>','<?php echo esc_js( $grid_id ); ?>')">
                <img src="<?php echo esc_url( $g['image'] ); ?>" alt="<?php echo esc_attr( $title !== '' ? $title : 'Gallery image' ); ?>" class="gs-beauty-gallery-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
            </a>
            <?php if ( $title !== '' ): ?><div class="gs-beauty-gallery-caption"><?php echo esc_html( $title ); ?></div><?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $items
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid( $context['items'] ?? [], (array) ( $context['img_display'] ?? [] ) );
        if ( $html === '' ) { return ''; } // Mandatory empty-state.
        return self::render_title( $context['section_title'] ?? 'Signature Looks & Transformations', $context['section_description'] ?? '' ) . $html;
    }
}
