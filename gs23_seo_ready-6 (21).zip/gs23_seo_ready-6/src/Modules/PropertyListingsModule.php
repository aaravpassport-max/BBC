<?php
namespace GoodService\Modules;

/**
 * PropertyListingsModule — the first of four independent Real Estate
 * modules, built following the exact same architecture as
 * RoomTypesModule: category-gated to 'real-estate' (assumption noted
 * below, matching the same reasoning RoomTypesModule's own docblock
 * already documents for 'hotels'), default_enabled=false (requires
 * explicit per-listing vendor opt-in via the Section Manager's
 * category-assignment flow), data stored via
 * ModuleRegistry::fetch_module_data()/save_module_data() against
 * gs_listing_module_data — the same real, working mechanism, not a
 * new one.
 *
 * ASSUMPTION, noted per this session's working instructions: the
 * category slug used for gating is 'real-estate' — this exact slug
 * was found already anticipated elsewhere in this codebase (an icon
 * mapping keyed by category slug already includes 'real-estate' =>
 * a house emoji), so this is a confirmed, not guessed, assumption. If
 * the real slug in use differs, the fix is the one-line change
 * ModulesBootstrap::register_all() already documents for this exact
 * situation.
 *
 * This module OWNS the actual property records — FeaturedProperties
 * Module and PropertyTypesModule (Sections 2 and 3 of this same
 * request) read from this SAME stored data rather than each keeping
 * their own duplicate copy, exactly as the request requires ("must
 * not force vendors to manually duplicate property information",
 * "use the same underlying property data"). PropertyGalleryModule
 * (Section 4) is independent of this one, since its content is
 * general property photography, not individual property records.
 */
class PropertyListingsModule {

    /** Every valid property_type value, matching the request's own list. */
    public const PROPERTY_TYPES = [
        'apartment' => 'Apartment', 'villa' => 'Villa', 'independent_house' => 'Independent House',
        'builder_floor' => 'Builder Floor', 'plot' => 'Plot', 'commercial' => 'Commercial Property',
        'office' => 'Office', 'shop' => 'Shop', 'warehouse' => 'Warehouse',
        'industrial' => 'Industrial Property', 'other' => 'Other',
    ];

    /** Every valid listing_purpose value, matching the request's own list. */
    public const LISTING_PURPOSES = [
        'sale' => 'For Sale', 'rent' => 'For Rent', 'lease' => 'For Lease',
        'new_project' => 'New Project', 'resale' => 'Resale',
    ];

    public const FURNISHING_STATUSES = [
        'unfurnished' => 'Unfurnished', 'semi_furnished' => 'Semi-Furnished', 'furnished' => 'Fully Furnished',
    ];

    public const POSSESSION_STATUSES = [
        'ready_to_move' => 'Ready to Move', 'under_construction' => 'Under Construction',
    ];

    /**
     * Reads every property stored for this listing, in the shape both
     * this module and FeaturedPropertiesModule/PropertyTypesModule
     * expect — the single, shared source every one of those three
     * modules reads from, so an edit here is automatically reflected
     * everywhere else without any of them needing to be told.
     *
     * @return array Each entry matches one property's full field set.
     */
    public static function get_properties( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'property_listings', $listing_id );
        $properties = array_values( array_filter( (array) ( $data['properties'] ?? [] ), fn( $p ) => is_array( $p ) && ! empty( $p['title'] ) ) );
        return $properties;
    }

    public static function render_title( string $title = 'Available Properties', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Real Estate</div>
        <h2 class="vs-sec-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-sec-desc" style="max-width:640px;margin:12px auto 0;color:#64748B"><?php echo esc_html( $description ); ?></p><?php endif; ?>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $properties  Already-resolved via get_properties().
     * @param array $display     Which fields to show — every key defaults
     *              to true, matching the request's "show/hide" settings
     *              list exactly (price, location, type, area, bedrooms,
     *              bathrooms, badges, cta).
     * @param int   $grid_cols   Matches Items'/Room Types' own established
     *              rows & columns pattern.
     * @param int   $max_rows    0 = show all, matching the same established
     *              convention.
     * @param array $img_display fit/position/zoom, matching the same
     *              shared, global gs_vs_img_display_style() helper every
     *              other configurable-photo section already uses.
     */
    public const SORT_MODES = [
        'default' => 'As Entered', 'newest' => 'Newest First', 'title_asc' => 'Title (A–Z)',
        'price_low' => 'Price: Low to High', 'price_high' => 'Price: High to Low',
    ];

    /**
     * Best-effort numeric extraction from a free-text price field
     * (e.g. "1.85 Cr", "50 Lakh", "85L", "₹45,000") — necessary because
     * price is stored as vendor-entered text, not a plain number, so a
     * naive string sort would incorrectly order "50 Lakh" before
     * "9 Cr". Returns 0 for anything unparseable, which sorts those
     * entries to the low end rather than throwing or crashing.
     */
    public static function parse_price_value( string $price ): float {
        $price = trim( $price );
        if ( $price === '' ) { return 0.0; }
        if ( ! preg_match( '/([\d,]+\.?\d*)/', $price, $m ) ) { return 0.0; }
        $number = (float) str_replace( ',', '', $m[1] );
        $lower = strtolower( $price );
        // Real fix — the original word-boundary regex (\bl\b) could
        // never match a bare "L" directly touching the digits, as in
        // the common shorthand "85L" — a word boundary only occurs
        // between a word character and a non-word character, and a
        // digit followed immediately by a letter has no such boundary
        // between them at all. Matches "lakh"/"cr"/"k" whether or not
        // they're separated from the number by a space, so both "50
        // Lakh" and "50L" (or "1.85Cr") parse identically.
        if ( preg_match( '/\d\s*(?:cr\b|crore)/', $lower ) ) { return $number * 10000000; }
        if ( preg_match( '/\d\s*(?:l\b|lakh)/', $lower ) ) { return $number * 100000; }
        if ( preg_match( '/\d\s*(?:k\b|thousand)/', $lower ) ) { return $number * 1000; }
        return $number;
    }

    /**
     * @param string $mode One of self::SORT_MODES' keys. Anything else
     *              falls back to 'default' (as entered/stored order) —
     *              never crashes or silently drops properties.
     */
    public static function sort_properties( array $properties, string $mode = 'default' ): array {
        switch ( $mode ) {
            case 'newest':
                return array_reverse( $properties );
            case 'title_asc':
                usort( $properties, fn( $a, $b ) => strcasecmp( $a['title'] ?? '', $b['title'] ?? '' ) );
                return $properties;
            case 'price_low':
                usort( $properties, fn( $a, $b ) => self::parse_price_value( $a['price'] ?? '' ) <=> self::parse_price_value( $b['price'] ?? '' ) );
                return $properties;
            case 'price_high':
                usort( $properties, fn( $a, $b ) => self::parse_price_value( $b['price'] ?? '' ) <=> self::parse_price_value( $a['price'] ?? '' ) );
                return $properties;
            default:
                return $properties;
        }
    }

    /**
     * Completes the previously-missing "Property selection/filter"
     * section setting — listed separately from "Number of properties"
     * in the original request, so this is a real content filter, not
     * just a count limit. Defaults to showing everything (empty/'all'
     * filter), since Property Listings is the main showcase and
     * should not silently hide properties unless an admin explicitly
     * narrows it down.
     */
    public static function filter_by_purpose( array $properties, string $purpose = 'all' ): array {
        if ( $purpose === '' || $purpose === 'all' || ! isset( self::LISTING_PURPOSES[ $purpose ] ) ) {
            return $properties;
        }
        return array_values( array_filter( $properties, fn( $p ) => ( $p['listing_purpose'] ?? '' ) === $purpose ) );
    }

    public static function render_grid( array $properties, array $display = [], int $grid_cols = 3, int $max_rows = 0, array $img_display = [], string $sort = 'default', string $filter_purpose = 'all' ): string {
        $properties = self::filter_by_purpose( $properties, $filter_purpose );
        $properties = self::sort_properties( $properties, $sort );
        if ( empty( $properties ) ) { return ''; }
        $show = array_merge( [
            'price' => true, 'location' => true, 'type' => true, 'area' => true,
            'bedrooms' => true, 'bathrooms' => true, 'badges' => true, 'cta' => true,
        ], $display );
        if ( $max_rows > 0 ) {
            $properties = array_slice( $properties, 0, $grid_cols * $max_rows );
        }
        $currency = \gs_setting( 'currency_symbol', '₹' );
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        ob_start();
        ?>
    <div class="vs-prop-grid">
        <?php foreach ( $properties as $p ):
            if ( empty( $p['title'] ) ) continue;
            $status_available = ( $p['property_status'] ?? 'available' ) === 'available';
        ?>
        <div class="vs-prop-card" data-property-type="<?php echo esc_attr( $p['property_type'] ?? 'other' ); ?>">
            <div class="vs-prop-img-wrap">
                <?php if ( ! empty( $p['image'] ) ): ?>
                    <img src="<?php echo esc_url( $p['image'] ); ?>" alt="<?php echo esc_attr( $p['title'] ); ?>" class="vs-prop-img" loading="lazy" width="400" height="260" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php else: ?>
                    <div class="vs-prop-img-placeholder">🏠</div>
                <?php endif; ?>
                <?php if ( $show['badges'] ): ?>
                <div class="vs-prop-badges">
                    <?php if ( ! empty( $p['listing_purpose'] ) && isset( self::LISTING_PURPOSES[ $p['listing_purpose'] ] ) ): ?>
                        <span class="vs-prop-badge vs-prop-badge-purpose"><?php echo esc_html( self::LISTING_PURPOSES[ $p['listing_purpose'] ] ); ?></span>
                    <?php endif; ?>
                    <?php if ( ! empty( $p['featured'] ) ): ?><span class="vs-prop-badge vs-prop-badge-featured">⭐ Featured</span><?php endif; ?>
                    <?php if ( ! empty( $p['verified'] ) ): ?><span class="vs-prop-badge vs-prop-badge-verified">✓ Verified</span><?php endif; ?>
                    <?php if ( ! $status_available ): ?><span class="vs-prop-badge vs-prop-badge-unavailable"><?php echo esc_html( ucfirst( $p['property_status'] ?? '' ) ); ?></span><?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="vs-prop-body">
                <div class="vs-prop-title"><?php echo esc_html( $p['title'] ); ?></div>
                <?php if ( $show['type'] && ! empty( $p['property_type'] ) && isset( self::PROPERTY_TYPES[ $p['property_type'] ] ) ): ?>
                    <div class="vs-prop-type"><?php echo esc_html( self::PROPERTY_TYPES[ $p['property_type'] ] ); ?></div>
                <?php endif; ?>
                <?php if ( $show['location'] && ! empty( $p['location'] ) ): ?>
                    <div class="vs-prop-location">📍 <?php echo esc_html( $p['location'] ); ?></div>
                <?php endif; ?>
                <?php if ( $show['price'] && ! empty( $p['price'] ) ): ?>
                    <div class="vs-prop-price"><?php echo esc_html( $currency . $p['price'] ); ?></div>
                <?php endif; ?>
                <div class="vs-prop-specs">
                    <?php if ( $show['area'] && ! empty( $p['area'] ) ): ?><span><?php echo esc_html( $p['area'] ); ?></span><?php endif; ?>
                    <?php if ( $show['bedrooms'] && ! empty( $p['bedrooms'] ) ): ?><span><?php echo (int) $p['bedrooms']; ?> Beds</span><?php endif; ?>
                    <?php if ( $show['bathrooms'] && ! empty( $p['bathrooms'] ) ): ?><span><?php echo (int) $p['bathrooms']; ?> Baths</span><?php endif; ?>
                    <?php if ( ! empty( $p['floor'] ) ): ?><span><?php echo esc_html( $p['floor'] ); ?></span><?php endif; ?>
                </div>
                <?php if ( $show['cta'] ): ?>
                <button type="button" class="vs-btn vs-btn-primary vs-prop-cta"
                        onclick="vsOpenInquiry({name:'<?php echo esc_js( $p['title'] ); ?>',type:'service',price:'<?php echo esc_js( ! empty( $p['price'] ) ? ( $currency . $p['price'] ) : '' ); ?>'})">View Property</button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $properties     Already-resolved via get_properties().
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $display        show/hide field settings.
     *     @type int    $grid_cols
     *     @type int    $max_rows
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $properties = $context['properties'] ?? [];
        if ( empty( $properties ) ) { return ''; } // Real feature — empty-state requirement: never render an empty grid.
        return self::render_title( $context['section_title'] ?? 'Available Properties', $context['section_description'] ?? '' )
            . self::render_grid(
                $properties,
                (array) ( $context['display'] ?? [] ),
                (int) ( $context['grid_cols'] ?? 3 ),
                (int) ( $context['max_rows'] ?? 0 ),
                (array) ( $context['img_display'] ?? [] ),
                (string) ( $context['sort'] ?? 'default' ),
                (string) ( $context['filter_purpose'] ?? 'all' )
            );
    }
}
