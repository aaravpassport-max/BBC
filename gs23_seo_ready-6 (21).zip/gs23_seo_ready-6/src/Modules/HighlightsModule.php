<?php
namespace GoodService\Modules;

/**
 * HighlightsModule — Phase 1 proof-of-concept for the modular listing
 * architecture roadmap.
 *
 * This is a faithful extraction of the existing Highlights rendering
 * logic (title block + card grid) from vendor-site.php's $_el_capture
 * calls for 'highlights_title' and 'highlights_grid'. It is deliberately
 * NOT yet wired into any live rendering path — its sole purpose right
 * now is to be proven, via direct execution comparison against the
 * original inline code, to produce byte-for-byte identical output.
 *
 * Per the roadmap's explicit Phase 1 safety requirement: "any visual or
 * functional difference is a blocking failure, not a footnote." This
 * class exists to make that comparison possible in isolation, without
 * risking the live, currently-working rendering for any real vendor.
 *
 * The data-source question (reading from the legacy highlights_data
 * column on gs_listings vs. the new gs_listing_module_data table) is
 * deliberately deferred — this function accepts the same raw inputs the
 * original code uses today, so it works correctly regardless of where
 * those inputs end up coming from once that separate decision is made.
 */
class HighlightsModule {

    /**
     * Replicates $_json_has_real_content() exactly — copied rather than
     * referenced, since this class must be usable standalone (e.g. in
     * a test harness) without requiring vendor-site.php's closures to
     * be in scope.
     */
    private static function has_real_content( $raw, string $required_key ): bool {
        if ( empty( $raw ) ) { return false; }
        $decoded = json_decode( (string) $raw, true );
        if ( ! is_array( $decoded ) ) { return false; }
        if ( array_key_exists( $required_key, $decoded ) ) {
            return ! empty( $decoded[ $required_key ] );
        }
        foreach ( $decoded as $item ) {
            if ( is_array( $item ) && ! empty( $item[ $required_key ] ?? null ) ) { return true; }
        }
        return false;
    }

    /**
     * Renders the title block. Faithful copy of the 'highlights_title'
     * $_el_capture callback.
     *
     * @param array $cd customizer_data array.
     */
    public static function render_title( array $cd ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['highlights_section_title'] ?? 'Key Highlights'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Renders the card grid. Faithful copy of the 'highlights_grid'
     * $_el_capture callback.
     *
     * @param string|array|null $highlights_data_raw Raw highlights_data
     *                          value (JSON string, as it currently comes
     *                          from $primary->highlights_data — kept as
     *                          the same raw shape deliberately, so the
     *                          eventual data-source decision doesn't
     *                          require any change to this method).
     * @param array $cd customizer_data array.
     */
    public static function render_grid( $highlights_data_raw, array $cd ): string {
        if ( ! self::has_real_content( $highlights_data_raw, 'title' ) ) { return ''; }
        $items = is_string( $highlights_data_raw ) ? ( json_decode( $highlights_data_raw, true ) ?: [] ) : $highlights_data_raw;
        $_hl_img_settings = is_array( $cd['highlights_img_display'] ?? null ) ? $cd['highlights_img_display'] : [];
        $_hl_icon_size_style = ! empty( $_hl_img_settings['icon_size'] ) ? 'width:' . (int) $_hl_img_settings['icon_size'] . 'px;height:' . (int) $_hl_img_settings['icon_size'] . 'px;' : '';
        $_hl_icon_fit = ( $_hl_img_settings['fit'] ?? 'cover' ) === 'contain' ? 'contain' : 'cover';
        ob_start();
        ?>
    <div class="vs-hl-grid">
        <?php foreach ($items as $h): if (empty($h['title'])) continue;
            $hicon = !empty($h['icon_image']) ? $h['icon_image'] : ($h['icon'] ?? '✨'); ?>
        <div class="vs-hl-card">
            <div class="vs-hl-icon" style="<?php echo esc_attr($_hl_icon_size_style); ?>"><?php
                if (filter_var($hicon, FILTER_VALIDATE_URL)) {
                    echo '<img src="' . esc_url($hicon) . '" alt="' . esc_attr($h['title']) . '" loading="lazy" width="' . (!empty($_hl_img_settings['icon_size']) ? (int)$_hl_img_settings['icon_size'] : 60) . '" height="' . (!empty($_hl_img_settings['icon_size']) ? (int)$_hl_img_settings['icon_size'] : 60) . '" style="object-fit:' . $_hl_icon_fit . ($_hl_icon_fit === 'contain' ? ';padding:8px;box-sizing:border-box' : '') . '">';
                } else {
                    echo esc_html($hicon);
                }
            ?></div>
            <div class="vs-hl-body">
                <div class="vs-hl-title"><?php echo esc_html($h['title']); ?></div>
                <?php if (!empty($h['description'])): ?>
                <div class="vs-hl-desc"><?php echo esc_html($h['description']); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * The module's full render output, in the same order the existing
     * $_sec_el_render('highlights') call produces (title, then grid).
     *
     * This is the module's registered render_callback — called uniformly
     * by the rendering engine with a single $context array, the same
     * shape every other module's render_callback receives regardless of
     * what data it internally needs. Positional arguments (the previous
     * shape of this method) don't scale to an engine that must call
     * arbitrarily different modules the same way; a single context
     * object does.
     *
     * @param array $context {
     *     @type int      $listing_id   The listing being rendered.
     *     @type object   $primary      The legacy $primary row object —
     *                     still the source of highlights_data until/
     *                     unless a later, separate step migrates it to
     *                     $context['module_data'].
     *     @type array    $cd           customizer_data array.
     *     @type array    $module_data  Data already migrated to
     *                     gs_listing_module_data for this module, if
     *                     any. Empty for Highlights today — checked
     *                     first so a future migration requires zero
     *                     change to this method's calling convention.
     * }
     */
    public static function render( array $context ): string {
        $cd = $context['cd'] ?? [];
        // Prefer migrated module_data if present (future-proofing for
        // the eventual data-source cutover); fall back to the legacy
        // column on $primary, which is where every current vendor's
        // data actually lives today.
        $highlights_data_raw = $context['module_data']['highlights_data']
            ?? ( $context['primary']->highlights_data ?? null );
        return self::render_title( $cd ) . self::render_grid( $highlights_data_raw, $cd );
    }
}
