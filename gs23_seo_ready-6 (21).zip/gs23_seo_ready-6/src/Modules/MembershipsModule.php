<?php
namespace GoodService\Modules;

/**
 * MembershipsModule — Phase 2 of the modular listing architecture
 * roadmap.
 *
 * Faithful extraction of the existing Memberships rendering logic from
 * vendor-site.php's $_el_capture calls for 'memberships_title' and
 * 'memberships_grid'. Calls the shared gs_setting() global helper
 * rather than duplicating it — unlike gs_vs_img_display_style()
 * (defined inside vendor-site.php itself, noted as a real dependency
 * in FacilitiesModule), gs_setting() lives in src/functions.php, a
 * genuinely always-loaded platform utility file, so this carries no
 * equivalent load-order caveat.
 */
class MembershipsModule {

    private static function has_real_content( $raw, string $required_key ): bool {
        if ( empty( $raw ) ) { return false; }
        $decoded = json_decode( (string) $raw, true );
        if ( ! is_array( $decoded ) ) { return false; }
        if ( array_key_exists( $required_key, $decoded ) ) {
            return ! empty( $decoded[ $required_key ] );
        }
        foreach ( $decoded as $item ) {
            if ( is_array( $item ) && ! empty( $item[ $required_key ] ?? null ) ) { return true; }
        }
        return false;
    }

    /** Faithful copy of the 'memberships_title' $_el_capture callback. */
    public static function render_title( array $cd ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['memberships_section_title'] ?? 'Membership Plans'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /** Faithful copy of the 'memberships_grid' $_el_capture callback. */
    public static function render_grid( $memberships_data_raw ): string {
        if ( ! self::has_real_content( $memberships_data_raw, 'name' ) ) { return ''; }
        $items = is_string( $memberships_data_raw ) ? ( json_decode( $memberships_data_raw, true ) ?: [] ) : $memberships_data_raw;
        $currency = gs_setting('currency_symbol', '₹');
        $cycle_labels = ['month'=>'month','year'=>'year','quarter'=>'quarter','week'=>'week','one-time'=>''];
        $tier_icons = ['🥉','🥈','🥇','💎'];
        ob_start();
        ?>
    <div class="vs-mem-grid">
        <?php foreach ($items as $mi => $m): if (empty($m['name'])) continue;
            $featured   = !empty($m['featured']);
            $badge_text = $m['badge'] ?? ($featured ? 'Most Popular' : '');
            $benefits   = is_array($m['benefits'] ?? null) ? $m['benefits'] : array_filter(array_map('trim', explode("\n", $m['benefits'] ?? '')));
            $cta_text   = $m['cta_text'] ?? 'Join Now';
            $cta_link   = $m['cta_link'] ?? '#vs-inq-open';
            $cycle      = $cycle_labels[$m['billing_cycle'] ?? 'month'] ?? ($m['billing_cycle'] ?? '');
            $tier_n     = min($mi + 1, 4);
        ?>
        <div class="vs-mem-card<?php echo $featured ? ' featured' : ''; ?>">
            <?php if ($badge_text): ?><div class="vs-mem-badge"><?php echo esc_html($badge_text); ?></div><?php endif; ?>
            <div class="vs-mem-tier-badge vs-mem-tier-<?php echo $tier_n; ?>"><?php echo $tier_icons[$tier_n-1]; ?></div>
            <div class="vs-mem-name"><?php echo esc_html($m['name']); ?></div>
            <div class="vs-mem-price">
                <?php if (!empty($m['price'])): ?>
                    <?php echo esc_html($currency . $m['price']); ?><span><?php echo $cycle ? '/' . esc_html($cycle) : ''; ?></span>
                <?php else: ?>
                    <span style="font-size:1.1rem">Custom</span>
                <?php endif; ?>
            </div>
            <?php if (!empty($m['description'])): ?><div class="vs-mem-desc"><?php echo esc_html($m['description']); ?></div><?php endif; ?>
            <?php if (!empty($benefits)): ?>
            <ul class="vs-mem-benefits">
                <?php foreach ($benefits as $b):
                    $included = !(str_starts_with($b, '-') || str_starts_with($b, '✕'));
                    $b_txt = ltrim($b, '-✕+✓ ');
                    if (!$b_txt) continue;
                ?>
                <li class="<?php echo $included ? '' : 'no-benefit'; ?>">
                    <span class="vs-mem-benefit-ico <?php echo $included ? 'yes' : 'no'; ?>"><?php echo $included ? '✓' : '–'; ?></span>
                    <?php echo esc_html($b_txt); ?>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
            <a href="<?php echo esc_url($cta_link); ?>" class="vs-mem-cta"
               onclick="if(this.getAttribute('href')==='#vs-inq-open'){event.preventDefault();vsOpenInquiry({name:'<?php echo esc_js($m['name']); ?>',type:'service'});}">
                <?php echo esc_html($cta_text); ?>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render( array $context ): string {
        $cd = $context['cd'] ?? [];
        $memberships_data_raw = $context['module_data']['memberships_data']
            ?? ( $context['primary']->memberships_data ?? null );
        return self::render_title( $cd ) . self::render_grid( $memberships_data_raw );
    }
}
