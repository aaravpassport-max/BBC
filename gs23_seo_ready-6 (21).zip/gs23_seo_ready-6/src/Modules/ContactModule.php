<?php
namespace GoodService\Modules;

/**
 * ContactModule — Phase 2 of the modular listing architecture roadmap.
 *
 * Faithful extraction of the existing Contact rendering logic from
 * vendor-site.php's 10 $_el_capture calls for the 'contact' section
 * (contact_phone, contact_whatsapp, contact_email, contact_website,
 * contact_address, contact_certs, contact_awards, contact_hours,
 * contact_map, contact_cities). No logic changes — this is a pure
 * migration, byte-for-byte verified against the real live file.
 *
 * NOTE: 'contact_tags' and 'contact_inquiry' are deliberately NOT
 * included here. contact_tags renders general listing tags that are
 * not contact-specific content (confirmed via the live file's own
 * comment structure — it sits alongside, not inside, the contact detail
 * rows) and contact_inquiry is the Fluent Form panel rendered separately
 * in vendor-site.php's right-column markup, not through $_el_capture at
 * all (confirmed via the live file's own comment: "contact_inquiry is
 * rendered in the right column of the contact section"). Migrating a
 * form-embed integration point is out of scope for this module and
 * would need its own dedicated investigation — not silently folded in
 * here as if it were the same kind of change.
 */
class ContactModule {

    public static function render_phone( ?string $phone, ?string $phone_masked, $primary_id ): string {
        if ( ! $phone ) { return ''; }
        ob_start();
        ?>
    <div class="vs-cd-row"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 11.5a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.62 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 9.91a16 16 0 0 0 6.29 6.29l.91-.91a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg></div><div><div class="vs-cd-lbl">Phone</div>
<a href="#" id="vs-cd-phone-link" onclick="vsRevealPhone(this,'<?php echo esc_js($primary_id ?? 0); ?>');return false;" class="vs-cd-val">
  <?php echo esc_html($phone_masked); ?> <span style="font-size:.72rem;color:#2563EB">(tap to reveal)</span>
</a></div></div>
<?php
        return ob_get_clean();
    }

    public static function render_whatsapp( ?string $wa, ?string $wa_clean ): string {
        if ( ! $wa_clean ) { return ''; }
        ob_start();
        ?>
    <div class="vs-cd-row"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div><div><div class="vs-cd-lbl">WhatsApp</div><a href="https://wa.me/<?php echo esc_attr($wa_clean); ?>" target="_blank" class="vs-cd-val"><?php echo esc_html($wa); ?></a></div></div>
<?php
        return ob_get_clean();
    }

    public static function render_email( ?string $email ): string {
        if ( ! $email ) { return ''; }
        ob_start();
        ?>
    <div class="vs-cd-row"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div><div><div class="vs-cd-lbl">Email</div><a href="mailto:<?php echo esc_attr($email); ?>" class="vs-cd-val"><?php echo esc_html($email); ?></a></div></div>
<?php
        return ob_get_clean();
    }

    public static function render_website( ?string $website ): string {
        if ( ! $website ) { return ''; }
        ob_start();
        ?>
    <div class="vs-cd-row"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></div><div><div class="vs-cd-lbl">Website</div><a href="<?php echo esc_url($website); ?>" target="_blank" class="vs-cd-val"><?php echo esc_html(preg_replace('#^https?://#','',$website)); ?></a></div></div>
<?php
        return ob_get_clean();
    }

    public static function render_address( ?string $address, ?string $city ): string {
        if ( ! $address && ! $city ) { return ''; }
        ob_start();
        ?>
    <div class="vs-cd-row vs-cd-row-top"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div><div><div class="vs-cd-lbl">Address</div><div class="vs-cd-val"><?php echo nl2br(esc_html($address ?: $city)); ?></div></div></div>
<?php
        return ob_get_clean();
    }

    public static function render_certs( ?string $certs ): string {
        if ( ! $certs ) { return ''; }
        ob_start();
        ?>
    <div class="vs-cd-row"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg></div><div><div class="vs-cd-lbl">Certifications</div><div class="vs-cd-val"><?php echo esc_html($certs); ?></div></div></div>
<?php
        return ob_get_clean();
    }

    public static function render_awards( ?string $awards ): string {
        if ( ! $awards ) { return ''; }
        ob_start();
        ?>
    <div class="vs-cd-row"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg></div><div><div class="vs-cd-lbl">Awards</div><div class="vs-cd-val"><?php echo esc_html($awards); ?></div></div></div>
<?php
        return ob_get_clean();
    }

    /**
     * Faithful copy, including the original's real key-shape comment:
     * create-listing.php stores {"monday":{"open":"09:00","close":"18:00","closed":false}},
     * vendor-dashboard.php stores {"monday":"09:00 - 18:00"} — both handled below,
     * exactly as the original callback does.
     */
    public static function render_hours( $opening_hours_raw ): string {
        $oh = is_array( $opening_hours_raw ?? null ) ? $opening_hours_raw : ( json_decode( $opening_hours_raw ?? '[]', true ) ?: [] );
        if ( empty( $oh ) ) { return ''; }
        $days = ['monday'=>'Monday','tuesday'=>'Tuesday','wednesday'=>'Wednesday','thursday'=>'Thursday','friday'=>'Friday','saturday'=>'Saturday','sunday'=>'Sunday'];
        $today_key = strtolower(date('l'));
        $today = $oh[$today_key] ?? null;
        $is_open_today = false; $status_str = '';
        if ($today) {
            if (is_array($today)) {
                if (!empty($today['closed'])) { $status_str = 'Closed Today'; }
                elseif (!empty($today['open']) && !empty($today['close'])) {
                    $now = date('H:i');
                    $is_open_today = $now >= $today['open'] && $now <= $today['close'];
                    $fmt = fn($t) => date('g:i A', strtotime($t));
                    $status_str = $is_open_today
                        ? 'Open Now · Closes ' . $fmt($today['close'])
                        : 'Closed · Opens ' . $fmt($today['open']);
                }
            } else {
                $status_str = $today;
            }
        }
        ob_start();
        ?>
    <div class="vs-contact-hours">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
            <div style="font-weight:700;font-size:.85rem;color:#334155">🕐 Opening Hours</div>
            <?php if ($status_str): ?>
            <span style="font-size:.75rem;font-weight:700;padding:3px 10px;border-radius:20px;background:<?php echo $is_open_today?'#DCFCE7':'#FEF2F2'; ?>;color:<?php echo $is_open_today?'#166534':'#DC2626'; ?>"><?php echo esc_html($status_str); ?></span>
            <?php endif; ?>
        </div>
        <?php foreach ($days as $k => $label):
            $d = $oh[$k] ?? null; if(!$d) continue;
            $is_today = ($k === $today_key);
            if (is_array($d)) {
                if (!empty($d['closed'])) $display = 'Closed';
                else $display = (!empty($d['open'])&&!empty($d['close']))
                    ? date('g:i A',strtotime($d['open'])) . ' – ' . date('g:i A',strtotime($d['close']))
                    : '—';
            } else { $display = $d; }
        ?>
        <div style="display:flex;justify-content:space-between;font-size:.82rem;padding:5px 0;border-bottom:1px solid #F8FAFC;<?php echo $is_today?'font-weight:700':''; ?>">
            <span style="color:<?php echo $is_today?'var(--vs-primary)':'#64748B'; ?>"><?php echo $is_today?'→ ':'' ?><?php echo $label; ?></span>
            <span style="font-weight:<?php echo $is_today?'800':'600'; ?>"><?php echo esc_html($display); ?></span>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render_map( ?string $map_embed ): string {
        if ( ! $map_embed ) { return ''; }
        ob_start();
        ?>
    <div class="vs-map-wrap"><div style="border-radius:14px;overflow:hidden"><?php echo wp_kses($map_embed, ['iframe'=>['src'=>true,'width'=>true,'height'=>true,'frameborder'=>true,'allowfullscreen'=>true,'loading'=>true,'referrerpolicy'=>true,'style'=>true]]); ?></div></div>
<?php
        return ob_get_clean();
    }

    public static function render_cities( $service_cities_raw ): string {
        $cities = is_array( $service_cities_raw ?? null ) ? $service_cities_raw : ( json_decode( $service_cities_raw ?? '[]', true ) ?: [] );
        if ( empty( $cities ) ) { return ''; }
        ob_start();
        ?>
    <div style="margin-top:20px"><div style="font-size:.75rem;font-weight:700;color:#647388;text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px">🗺 Service Areas</div><div style="display:flex;flex-wrap:wrap;gap:6px"><?php foreach ($cities as $sc): if(!$sc)continue; ?><span style="background:#EFF6FF;color:#2563EB;border-radius:20px;padding:4px 12px;font-size:.78rem;font-weight:600"><?php echo esc_html($sc); ?></span><?php endforeach; ?></div></div>
<?php
        return ob_get_clean();
    }

    /**
     * render(): aggregates every element into the exact same order the
     * live file's markup relies on (details-panel rows, then hours,
     * then map, then service-cities) — this ordering is NOT arbitrary,
     * it matches the physical layout of the left-column contact panel
     * in vendor-site.php and must be preserved.
     */
    public static function render( array $context ): string {
        $primary = $context['primary'] ?? null;
        $out  = self::render_phone( $context['phone'] ?? null, $context['phone_masked'] ?? null, $primary->id ?? 0 );
        $out .= self::render_whatsapp( $context['wa'] ?? null, $context['wa_clean'] ?? null );
        $out .= self::render_email( $context['email'] ?? null );
        $out .= self::render_website( $context['website'] ?? null );
        $out .= self::render_address( $context['address'] ?? null, $context['city'] ?? null );
        $out .= self::render_certs( $context['certs'] ?? null );
        $out .= self::render_awards( $context['awards'] ?? null );
        $out .= self::render_hours( $primary->opening_hours ?? null );
        $out .= self::render_map( $primary->map_embed ?? null );
        $out .= self::render_cities( $primary->service_cities ?? null );
        return $out;
    }
}
