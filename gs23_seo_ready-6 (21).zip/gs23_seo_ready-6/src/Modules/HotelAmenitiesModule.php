<?php
namespace GoodService\Modules;

/**
 * HotelAmenitiesModule — Hotels / Banquets / Hospitality category,
 * Module 4: "Amenities & Facilities" (custom build spec's Section 08).
 * The spec is explicit that this must NOT be "a wall of tiny icons" —
 * it calls for a grouped presentation (e.g. Business & Connectivity,
 * Wellness & Recreation, Family & Kids, Dining & General).
 *
 * INVESTIGATION PERFORMED FIRST, per the master build prompt's Section
 * 0.1: the universal AmenitiesModule and FacilitiesModule both already
 * exist and are available to every category, including 'hotels'. Both
 * were read in full. Both render a single FLAT tile/card grid with no
 * grouping whatsoever (AmenitiesModule::render_grid() — one
 * undifferentiated .vs-am-grid of icon tiles; FacilitiesModule::
 * render_grid() — one undifferentiated .vs-fac-grid of photo cards).
 * Neither has any concept of a category/group. A 20+ item hotel
 * amenity list rendered through either one is exactly the generic
 * "wall of icons" directory look the spec's own Section 51 ("Final
 * Development Standard") explicitly warns against — so this is a real
 * gap, not a duplicate: this module is NOT a copy of Amenities/
 * Facilities, it is the grouped presentation neither of them offers.
 * A hotel vendor can still use the universal Amenities/Facilities
 * modules for a short, ungrouped list if they prefer — this module is
 * additive, not a replacement, and is category-gated to 'hotels' only
 * so it never appears as a confusing duplicate control in any other
 * category's admin panel.
 *
 * Master build prompt Section 8 (Manage/View Details) — explicitly
 * considered, not applicable: each item here is a title plus an
 * optional one-line description (2 fields), the same shape as the
 * universal AmenitiesModule/FacilitiesModule tiles this module sits
 * alongside, neither of which has a View Details popup either. There is
 * no per-item content dense enough to warrant one.
 *
 * Master build prompt Section 3 (Rows & Columns / Sorting / Show-Hide
 * Fields) — not applicable for the same reason as Manage/View Details:
 * this module's own cited precedents (AmenitiesModule/FacilitiesModule)
 * have neither a max-rows/column-count control nor a sort control for
 * their tile grids, and grouping (by GROUPS' own fixed display order)
 * already IS this module's organizing/filtering mechanism.
 */
class HotelAmenitiesModule {

    public const GROUPS = [
        'business'  => 'Business & Connectivity',
        'wellness'  => 'Wellness & Recreation',
        'family'    => 'Family & Kids',
        'dining'    => 'Food & Dining',
        'general'   => 'General Facilities',
    ];

    public static function render_title( string $heading = 'Amenities & Facilities', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-hamn-sec-head">
        <h2 class="vs-sec-title gs-hamn-title"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-hamn-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render_groups( array $items ): string {
        $items = array_values( array_filter( $items, fn( $i ) => is_array( $i ) && trim( (string) ( $i['title'] ?? '' ) ) !== '' ) );
        if ( empty( $items ) ) { return ''; }

        // Only groups the vendor actually used ever appear — same
        // "never show an empty configuration" rule as every other
        // module in this build.
        $grouped = [];
        foreach ( $items as $it ) {
            $g = (string) ( $it['group'] ?? '' );
            if ( ! isset( self::GROUPS[ $g ] ) ) { $g = 'general'; }
            $grouped[ $g ][] = $it;
        }
        // Preserve GROUPS' own display order, not insertion order.
        $ordered = [];
        foreach ( self::GROUPS as $gk => $gl ) {
            if ( ! empty( $grouped[ $gk ] ) ) { $ordered[ $gk ] = $grouped[ $gk ]; }
        }

        ob_start();
        ?>
    <div class="gs-hamn-wrap">
        <?php foreach ( $ordered as $_gk => $_gitems ): ?>
        <div class="gs-hamn-group">
            <h3 class="gs-hamn-group-title"><?php echo esc_html( self::GROUPS[ $_gk ] ); ?></h3>
            <div class="gs-hamn-group-list">
                <?php foreach ( $_gitems as $it ):
                    $icon = trim( (string) ( $it['icon'] ?? '' ) );
                    if ( $icon === '' ) { $icon = '✓'; }
                    $desc = trim( (string) ( $it['description'] ?? '' ) );
                ?>
                <div class="gs-hamn-item">
                    <span class="gs-hamn-icon"><?php
                        if ( filter_var( $icon, FILTER_VALIDATE_URL ) ) {
                            echo '<img src="' . esc_url( $icon ) . '" alt="" loading="lazy" width="22" height="22" style="width:22px;height:22px;object-fit:contain">';
                        } else {
                            echo esc_html( $icon );
                        }
                    ?></span>
                    <span class="gs-hamn-item-body">
                        <span class="gs-hamn-item-title"><?php echo esc_html( $it['title'] ); ?></span>
                        <?php if ( $desc !== '' ): ?><span class="gs-hamn-item-desc"><?php echo esc_html( $desc ); ?></span><?php endif; ?>
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function get_items( $wpdb, string $table_prefix, int $listing_id ): array {
        $stored = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'hotel_amenities', $listing_id );
        return array_values( array_filter( (array) ( $stored['items'] ?? [] ), fn( $i ) => is_array( $i ) ) );
    }

    /**
     * @param array $context {
     *     @type array  $items
     *     @type string $section_title
     *     @type string $section_description
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_groups( (array) ( $context['items'] ?? [] ) );
        if ( $html === '' ) { return ''; } // Mandatory empty-state — custom build spec's Section 48.
        return self::render_title( $context['section_title'] ?? 'Amenities & Facilities', $context['section_description'] ?? '' ) . $html;
    }
}
