<?php
namespace GoodService\Modules;

/**
 * WeddingLocationsModule — Events & Wedding, Section 08 of 8: "Location
 * & Destination Coverage". Own, independently-gated data owned under
 * module key 'wedding_locations', plus one plain customizer_data
 * setting ('wedding_destination_available' + its optional note) — a
 * deliberate hybrid, same overall shape as Section 07's fixed enum +
 * per-item note, except the location list itself is open-ended
 * vendor-entered text (there is no realistic fixed enum of every city
 * or region a wedding vendor might cover), so each location is a plain
 * flat repeater item, not a checked enum key.
 *
 * Render rule (same visual family as Section 07 for consistency): a
 * location WITH a non-empty note renders as a small card (name + note
 * line); a location with no note renders as a plain chip — the two mix
 * freely in the same grid. Distinct from Section 07: this section also
 * carries its own prominent "✈ Available for Destination Weddings"
 * badge/banner, shown above the location grid when the vendor has
 * flagged it, with its own optional note beneath.
 *
 * Empty-state rule is deliberately an OR, not an AND at the item level:
 * unlike every prior section (empty items array -> ''), this section
 * renders something if EITHER the vendor has at least one real location
 * OR the destination-availability flag is on — a vendor who only
 * travels for destination weddings and lists no fixed home cities still
 * has real, meaningful content to show. It returns '' only when BOTH
 * are empty/false.
 */
class WeddingLocationsModule {

    public static function render_title( string $heading, string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-wedding-sec-head">
        <div class="gs-wedding-eyebrow">Coverage</div>
        <h2 class="vs-sec-title gs-wedding-title"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-wedding-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render_destination_badge( bool $available, string $note ): string {
        if ( ! $available ) { return ''; }
        ob_start();
        ?>
    <div class="gs-wedding-location-badge">
        <span class="gs-wedding-location-badge-icon">✈</span>
        <div class="gs-wedding-location-badge-text">
            <div class="gs-wedding-location-badge-title">Available for Destination Weddings</div>
            <?php if ( $note !== '' ): ?><p class="gs-wedding-location-badge-note"><?php echo esc_html( $note ); ?></p><?php endif; ?>
        </div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Real-content-driven layout: 5+ real locations get a richer,
     * responsive multi-column card-grid treatment (a genuine "coverage
     * map" feel at scale); fewer than 5 keep the original lighter
     * flex-wrap chip/mini-card row. This is a pure count-based automatic
     * behaviour in render — no new admin toggle, no vendor setting.
     */
    public static function render_grid( array $items ): string {
        $items = array_values( array_filter( $items, fn( $i ) => is_array( $i ) && trim( (string) ( $i['location'] ?? '' ) ) !== '' ) );
        if ( empty( $items ) ) { return ''; }

        // Defensive, same discipline as the save layer: only the FIRST
        // item flagged home_base is ever honoured, even if malformed/
        // duplicate data somehow reached here with more than one.
        $home_base_used = false;
        $is_dense = count( $items ) >= 5;
        $wrap_class = $is_dense ? 'gs-wedding-location-grid gs-wedding-location-grid-dense' : 'gs-wedding-location-grid';

        ob_start();
        ?>
    <div class="<?php echo esc_attr( $wrap_class ); ?>">
        <?php foreach ( $items as $it ):
            $name = trim( (string) ( $it['location'] ?? '' ) );
            $note = trim( (string) ( $it['note'] ?? '' ) );
            $is_home = ! $home_base_used && ! empty( $it['home_base'] );
            if ( $is_home ) { $home_base_used = true; }
            $card_class = 'gs-wedding-location-card' . ( $is_home ? ' gs-wedding-location-card-home' : '' );
        ?>
        <?php if ( $note !== '' || $is_home || $is_dense ): ?>
        <div class="<?php echo esc_attr( $card_class ); ?>">
            <?php if ( $is_home ): ?><span class="gs-wedding-location-home-badge">📍 Home Base</span><?php endif; ?>
            <div class="gs-wedding-location-card-name"><?php echo esc_html( $name ); ?></div>
            <?php if ( $note !== '' ): ?><p class="gs-wedding-location-card-note"><?php echo esc_html( $note ); ?></p><?php endif; ?>
        </div>
        <?php else: ?>
        <div class="gs-wedding-location-chip"><?php echo esc_html( $name ); ?></div>
        <?php endif; ?>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $items                each with location/note
     *     @type bool   $destination_available
     *     @type string $destination_note
     *     @type array  $vendor_types
     *     @type string $section_title  vendor override; falls back to the adaptive heading when blank.
     *     @type string $section_description
     * }
     */
    public static function render( array $context ): string {
        $grid_html  = self::render_grid( (array) ( $context['items'] ?? [] ) );
        $available  = (bool) ( $context['destination_available'] ?? false );
        $dest_note  = trim( (string) ( $context['destination_note'] ?? '' ) );
        $badge_html = self::render_destination_badge( $available, $dest_note );

        // Mandatory empty-state, but OR'd rather than AND'd — either
        // real content is enough to justify rendering the section.
        if ( $grid_html === '' && $badge_html === '' ) { return ''; }

        $heading = trim( (string) ( $context['section_title'] ?? '' ) );
        if ( $heading === '' ) {
            $heading = \GoodService\Modules\WeddingEventsModule::locations_heading( (array) ( $context['vendor_types'] ?? [] ) );
        }
        return self::render_title( $heading, (string) ( $context['section_description'] ?? '' ) ) . $badge_html . $grid_html;
    }
}
