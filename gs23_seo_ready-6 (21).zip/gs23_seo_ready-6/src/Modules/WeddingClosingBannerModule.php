<?php
namespace GoodService\Modules;

/**
 * WeddingClosingBannerModule — Events & Wedding, Section 12 of 12:
 * "Premium Conversion Banner". The final section of the spec: a bold,
 * full-width closing bookend near the bottom of the page (after every
 * other wedding_* section, right before the footer) restating the
 * core value proposition with one strong final CTA.
 *
 * This is deliberately NOT a second form — Section 11 (wedding_quote)
 * already is the form. This section carries no input fields at all,
 * so there is nothing here to fold into a popup field the way Section
 * 10/11 fold a picked date or typed extras into vsOpenInquiry()'s own
 * remarks field. The CTA therefore calls the platform's real popup
 * directly — window.vsOpenInquiry() — the exact same mechanism every
 * other wedding_* CTA ultimately opens (wedding_quote's button calls
 * the wedding-specific wrapper vsWeddingRequestQuote(), which itself
 * just prefills and calls vsOpenInquiry(); with no fields to prefill
 * here, calling vsOpenInquiry() directly is the correct minimal reuse
 * rather than inventing a reason to go through the wrapper).
 *
 * Visual boldness (full-bleed background, large centered heading,
 * prominent button) is a CSS concern handled in vendor-site.php's
 * .gs-wedding-closing-banner-* rules; this render stays simple.
 */
class WeddingClosingBannerModule {

    /**
     * @param array $context {
     *     @type array  $vendor_types
     *     @type string $section_title        vendor override; falls back to the adaptive heading when blank.
     *     @type string $section_description   vendor override; falls back to the default copy when blank.
     * }
     */
    public static function render( array $context ): string {
        $vendor_types = (array) ( $context['vendor_types'] ?? [] );

        $heading = trim( (string) ( $context['section_title'] ?? '' ) );
        if ( $heading === '' ) {
            $heading = \GoodService\Modules\WeddingEventsModule::closing_banner_heading( $vendor_types );
        }
        $desc = trim( (string) ( $context['section_description'] ?? '' ) );
        if ( $desc === '' ) {
            $desc = "Let's talk about your big day — reach out and we'll take it from there.";
        }

        ob_start();
        ?>
    <div class="gs-wedding-closing-banner-inner">
        <h2 class="vs-sec-title gs-wedding-title gs-wedding-closing-banner-heading"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $desc !== '' ) : ?>
        <p class="gs-wedding-closing-banner-desc"><?php echo esc_html( $desc ); ?></p>
        <?php endif; ?>
        <button type="button" class="gs-wedding-closing-banner-btn" onclick="vsOpenInquiry()">Get In Touch</button>
    </div>
<?php
        return ob_get_clean();
    }
}
