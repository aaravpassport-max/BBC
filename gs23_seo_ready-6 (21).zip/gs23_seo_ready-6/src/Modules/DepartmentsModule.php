<?php
namespace GoodService\Modules;

/**
 * DepartmentsModule — Health & Wellness, module 2 of 5. Answers "what
 * type of healthcare does this clinic specialize in?", distinct from
 * Featured Services' "what services do you actually provide."
 *
 * A vendor-managed repeater (like Project Categories in the Interior
 * Designers build) — the request explicitly requires vendor-defined,
 * addable/removable department names, not a fixed enum — enriched
 * with real, computed-not-entered data from both Services and Doctors.
 * Unlike Project Categories (a single count), the request's own
 * example ("Cardiology can display: Cardiologists, Cardiology
 * Services, Related Treatments, Related FAQs") calls for the actual
 * related lists, not just a number — the detail popup surfaces the
 * real names, not a count alone.
 *
 * Independent of Featured Services' and Doctors' own activation, same
 * pattern as every cross-referencing module this session: reads their
 * data directly via HealthWellnessModule, never checks $_sec_show()
 * or assignment state for either.
 */
class DepartmentsModule {

    public const SUGGESTED_SPECIALTIES = [
        'General Medicine', 'Cardiology', 'Dermatology', 'Orthopaedics', 'Paediatrics',
        'Gynaecology', 'Dentistry', 'Ophthalmology', 'ENT', 'Physiotherapy', 'Neurology',
        'Gastroenterology', 'Pulmonology', 'Urology', 'Psychiatry', 'Nutrition',
        'Rehabilitation', 'Diagnostics',
    ];

    /**
     * @param array $dept_defs  Vendor repeater: {name, description,
     *              image, icon, lead_doctor, cta_text}.
     * @return array  Each entry enriched with real 'count' (services),
     *              'related_doctors', and 'related_services'.
     */
    public static function with_relationships( array $dept_defs, array $services, array $doctors ): array {
        $counts = HealthWellnessModule::get_department_service_counts( $services );
        $enriched = [];
        foreach ( $dept_defs as $def ) {
            if ( empty( $def['name'] ) ) { continue; }
            $def['count'] = $counts[ $def['name'] ] ?? 0;
            $def['related_doctors'] = HealthWellnessModule::get_doctors_for_department( $doctors, $def['name'] );
            $def['related_services'] = HealthWellnessModule::get_services_for_department( $services, $def['name'] );
            $enriched[] = $def;
        }
        return $enriched;
    }

    public static function render_title( string $title = 'Departments & Specialties', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-hw-sec-head">
        <div class="vs-hw-eyebrow">Our Expertise</div>
        <h2 class="vs-sec-title vs-hw-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-hw-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    private static function build_detail_sections( array $dept ): array {
        $sections = [];
        if ( ! empty( $dept['description'] ) ) {
            $sections[] = [ 'content_type' => 'richtext', 'title' => 'About This Department', 'icon' => '📋', 'body' => esc_html( $dept['description'] ) ];
        }
        if ( ! empty( $dept['lead_doctor'] ) ) {
            $sections[] = [ 'content_type' => 'list', 'title' => 'Lead Doctor', 'icon' => '🩺', 'list_items' => [ $dept['lead_doctor'] ] ];
        }
        if ( ! empty( $dept['related_doctors'] ) ) {
            $sections[] = [ 'content_type' => 'list', 'title' => 'Doctors in This Department', 'icon' => '👥', 'list_items' => array_column( $dept['related_doctors'], 'name' ) ];
        }
        if ( ! empty( $dept['related_services'] ) ) {
            $sections[] = [ 'content_type' => 'list', 'title' => 'Services & Treatments', 'icon' => '⚕️', 'list_items' => array_column( $dept['related_services'], 'name' ) ];
        }
        return $sections;
    }

    /**
     * @param array $departments  Already enriched via with_relationships().
     * @param bool  $hide_empty   Same real requirement as Project
     *              Categories: a department with zero matching
     *              services should not appear as a dead link.
     */
    public static function render_grid( array $departments, array $img_display = [], int $grid_cols = 3, bool $hide_empty = true ): string {
        if ( $hide_empty ) {
            $departments = array_values( array_filter( $departments, fn( $d ) => ( $d['count'] ?? 0 ) > 0 ) );
        }
        if ( empty( $departments ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        ob_start();
        ?>
    <div class="vs-hw-dept-grid" style="--vs-hw-dept-cols:<?php echo (int) $grid_cols; ?>">
        <?php foreach ( $departments as $dept ):
            $count = (int) ( $dept['count'] ?? 0 );
            $cta = ! empty( $dept['cta_text'] ) ? $dept['cta_text'] : 'View Department';
            $detail_sections = self::build_detail_sections( $dept );
        ?>
        <div class="vs-hw-dept-tile">
            <?php if ( ! empty( $dept['image'] ) ): ?>
                <img src="<?php echo esc_url( $dept['image'] ); ?>" alt="<?php echo esc_attr( $dept['name'] ); ?>" class="vs-hw-dept-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
            <?php else: ?>
                <div class="vs-hw-dept-img-placeholder"><?php echo esc_html( $dept['icon'] ?? '🏥' ); ?></div>
            <?php endif; ?>
            <div class="vs-hw-dept-body">
                <div class="vs-hw-dept-name"><?php echo esc_html( $dept['name'] ); ?></div>
                <?php if ( ! empty( $dept['description'] ) ): ?><p class="vs-hw-dept-desc"><?php echo esc_html( $dept['description'] ); ?></p><?php endif; ?>
                <div class="vs-hw-dept-count"><?php echo $count; ?> Service<?php echo $count === 1 ? '' : 's'; ?></div>
                <a href="#" class="vs-hw-dept-cta"
                   data-title="<?php echo esc_attr( $dept['name'] ); ?>"
                   data-image="<?php echo esc_attr( $dept['image'] ?? '' ); ?>"
                   data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $dept['additional_images'] ?? null ) ? $dept['additional_images'] : [] ) ) ) ); ?>"
                   data-img-fit="<?php echo esc_attr( in_array( $img_display['popup_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $img_display['popup_fit'] ?? 'cover' ) : 'cover' ); ?>"
                   data-slider-interval="<?php echo esc_attr( (int) ( $img_display['interval'] ?? 0 ) ); ?>"
                   data-price=""
                   data-sections="<?php echo esc_attr( wp_json_encode( $detail_sections ) ); ?>"
                   onclick="event.preventDefault();vsOpenDetailPopup(event,this)"><?php echo esc_html( $cta ); ?></a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $dept_defs
     *     @type array  $services
     *     @type array  $doctors
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     *     @type int    $grid_cols
     * }
     */
    public static function render( array $context ): string {
        $enriched = self::with_relationships( $context['dept_defs'] ?? [], $context['services'] ?? [], $context['doctors'] ?? [] );
        $grid = self::render_grid( $enriched, (array) ( $context['img_display'] ?? [] ), (int) ( $context['grid_cols'] ?? 3 ) );
        if ( $grid === '' ) { return ''; } // Real feature — empty-state requirement.
        return self::render_title( $context['section_title'] ?? 'Departments & Specialties', $context['section_description'] ?? '' ) . $grid;
    }
}
