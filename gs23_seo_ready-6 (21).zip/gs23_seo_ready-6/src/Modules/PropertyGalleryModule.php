<?php
namespace GoodService\Modules;

/**
 * PropertyGalleryModule — real estate module 4 of 4.
 *
 * Unlike the other three real-estate modules, this one is deliberately
 * NOT built on top of PropertyListingsModule's shared property data —
 * per the request's own framing, this is a general visual showcase
 * (exteriors, interiors, amenities, construction progress) rather than
 * a display of individual structured property records, and the
 * request explicitly separates "Property Data" (Section 4 of its own
 * spec) from "Gallery Source", which explicitly requires reusing the
 * vendor's EXISTING media library rather than building a second one.
 *
 * Confirmed directly, not assumed, before building this: the
 * platform's real image-quota mechanism is a vendor-wide PHOTO COUNT
 * limit (SubscriptionService::get_vendor_photo_usage(), e.g. 30 photos
 * on a paid plan, 10 without one) — not a "5MB total size" quota as
 * such. This module respects that real mechanism by construction: it
 * only ever lets a vendor SELECT existing images already in their
 * media library (via the same clOpenMediaLibrary() picker every other
 * image field already uses, with multi:true) rather than uploading
 * new ones through a separate path — selecting an existing image adds
 * nothing to that count at all, since the file was already uploaded
 * and already counted through the one real upload path
 * (AjaxController::uploadMedia()) that actually enforces the limit.
 *
 * Category-gated to 'real-estate', same assumption as the other three
 * real-estate modules.
 */
class PropertyGalleryModule {

    public const LAYOUTS = [ 'grid' => 'Grid', 'masonry' => 'Masonry', 'carousel' => 'Carousel' ];

    /**
     * @return array Each entry stored gallery image: {url, caption}.
     */
    public static function get_images( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'property_gallery', $listing_id );
        return array_values( array_filter( (array) ( $data['images'] ?? [] ), fn( $i ) => is_array( $i ) && ! empty( $i['url'] ) ) );
    }

    public static function render_title( string $title = 'Property Gallery', string $description = '' ): string {
        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Real Estate</div>
        <h2 class="vs-sec-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="vs-sec-desc" style="max-width:640px;margin:12px auto 0;color:#64748B"><?php echo esc_html( $description ); ?></p><?php endif; ?>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $images        Already resolved via get_images().
     * @param string $layout       'grid' | 'masonry' | 'carousel'.
     * @param int   $grid_cols
     * @param bool  $lightbox_enabled
     * @param bool  $captions_enabled
     * @param int   $max_images    0 = show all.
     * @param string $aspect_ratio CSS aspect-ratio value, e.g. '4/3', '1/1', '16/9'.
     * @param string $border_radius CSS value, e.g. '12px'.
     * @param int   $gap           Gap in px.
     * @param array $img_display   fit/position/zoom — matches the
     *              shared, global gs_vs_img_display_style() helper
     *              every other configurable-photo module here uses.
     */
    public static function render_grid(
        array $images, string $layout = 'grid', int $grid_cols = 4, bool $lightbox_enabled = true,
        bool $captions_enabled = true, int $max_images = 0, string $aspect_ratio = '4/3',
        string $border_radius = '12px', int $gap = 16, array $img_display = []
    ): string {
        if ( empty( $images ) ) { return ''; }
        if ( $max_images > 0 ) {
            $images = array_slice( $images, 0, $max_images );
        }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];
        $layout_class = in_array( $layout, array_keys( self::LAYOUTS ), true ) ? $layout : 'grid';
        ob_start();
        ?>
    <?php if ( $layout_class === 'carousel' ): ?>
    <div class="vs-prop-gallery-carousel-wrap">
    <?php endif; ?>
    <div class="vs-prop-gallery-<?php echo esc_attr( $layout_class ); ?>" id="vs-property-gallery-grid"
         style="--vs-prop-gallery-cols:<?php echo (int) $grid_cols; ?>;--vs-prop-gallery-gap:<?php echo (int) $gap; ?>px;--vs-prop-gallery-radius:<?php echo esc_attr( $border_radius ); ?>;--vs-prop-gallery-aspect:<?php echo esc_attr( $aspect_ratio ); ?>">
        <?php foreach ( $images as $img ):
            if ( empty( $img['url'] ) ) continue;
            $caption = $img['caption'] ?? '';
        ?>
        <div class="vs-prop-gallery-item"<?php echo $lightbox_enabled ? ' onclick="vsLightbox(\'' . esc_js( $img['url'] ) . '\',\'' . esc_js( $caption ) . '\',\'vs-property-gallery-grid\')"' : ''; ?>>
            <img src="<?php echo esc_url( $img['url'] ); ?>" alt="<?php echo esc_attr( $caption ); ?>" class="vs-prop-gallery-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
            <?php if ( $captions_enabled && $caption !== '' ): ?><div class="vs-prop-gallery-caption"><?php echo esc_html( $caption ); ?></div><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <?php if ( $layout_class === 'carousel' ): ?>
    <button type="button" class="vs-prop-gallery-nav vs-prop-gallery-nav-prev" onclick="vsPropGalleryScroll(-1)" aria-label="Previous photo">&#8249;</button>
    <button type="button" class="vs-prop-gallery-nav vs-prop-gallery-nav-next" onclick="vsPropGalleryScroll(1)" aria-label="Next photo">&#8250;</button>
    </div>
    <?php endif; ?>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array   $images
     *     @type string  $section_title
     *     @type string  $section_description
     *     @type string  $layout
     *     @type int     $grid_cols
     *     @type bool    $lightbox_enabled
     *     @type bool    $captions_enabled
     *     @type int     $max_images
     *     @type string  $aspect_ratio
     *     @type string  $border_radius
     *     @type int     $gap
     *     @type array   $img_display
     * }
     */
    public static function render( array $context ): string {
        $images = $context['images'] ?? [];
        if ( empty( $images ) ) { return ''; } // Real feature — empty-state requirement: no images selected means the section does not render at all.
        return self::render_title( $context['section_title'] ?? 'Property Gallery', $context['section_description'] ?? '' )
            . self::render_grid(
                $images,
                $context['layout'] ?? 'grid',
                (int) ( $context['grid_cols'] ?? 4 ),
                (bool) ( $context['lightbox_enabled'] ?? true ),
                (bool) ( $context['captions_enabled'] ?? true ),
                (int) ( $context['max_images'] ?? 0 ),
                $context['aspect_ratio'] ?? '4/3',
                $context['border_radius'] ?? '12px',
                (int) ( $context['gap'] ?? 16 ),
                (array) ( $context['img_display'] ?? [] )
            );
    }
}
