<?php
namespace GoodService\Modules;

/**
 * ProjectsModule — the foundational data owner for the Interior
 * Designers & Architects category build (5 sections total). This is
 * the "Featured Projects" module's real identity: it owns every
 * project record a vendor creates. Project Categories, Design Styles/
 * Expertise, and (partially) 3D Designs & Before/After all read from
 * THIS SAME data via get_projects()/get_category_counts()/
 * get_style_counts() — never a second, duplicated copy — matching the
 * request's own explicit "cross-section intelligence" requirement and
 * this platform's already-proven Property Listings → Featured
 * Properties / Property Types pattern from the Real Estate build.
 *
 * ASSUMPTION, per this session's master prompt (Section 0.2): the
 * category slug is 'interior-designers-architects', confirmed directly
 * from the user's stated real category name ("Interior Designers &
 * Architects") run through this platform's own real slug-generation
 * function — not guessed from an unrelated icon-map coincidence, the
 * mistake made twice earlier this session.
 *
 * The section registered under the module key 'featured_projects'
 * (matching the request's own section name) is the one that owns and
 * renders this data — this class exists separately so the other four
 * sections can depend on it without depending on the rendering module
 * itself, exactly like PropertyListingsModule vs FeaturedPropertiesModule.
 */
class ProjectsModule {

    public const PROJECT_TYPES = [
        'residential' => 'Residential', 'commercial' => 'Commercial', 'hospitality' => 'Hospitality',
        'office' => 'Office', 'retail' => 'Retail', 'restaurant' => 'Restaurant', 'villa' => 'Villa',
        'apartment' => 'Apartment', 'penthouse' => 'Penthouse', 'farmhouse' => 'Farmhouse',
        'renovation' => 'Renovation', 'architectural' => 'Architectural Project', 'custom' => 'Custom',
    ];

    public const PROJECT_STATUSES = [
        'completed' => 'Completed', 'in_progress' => 'In Progress', 'concept' => 'Concept',
    ];

    /**
     * Reads every project stored for this listing — the single,
     * shared source Project Categories and Design Styles/Expertise
     * both read from for their own count computations, matching the
     * same pure-data-access, no-activation-dependency pattern
     * PropertyListingsModule::get_properties() already established.
     */
    public static function get_projects( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'featured_projects', $listing_id );
        return array_values( array_filter( (array) ( $data['projects'] ?? [] ), fn( $p ) => is_array( $p ) && ! empty( $p['name'] ) ) );
    }

    /**
     * Real feature — "cross-section intelligence": Project Categories
     * must never require the vendor to manually enter a count. Grouped
     * fresh from the same in-memory project list on every render — one
     * already-fetched dataset, not a repeated query per category.
     * Grouped by the project's own free-text 'category' field (matching
     * whatever vendor-defined category names the Project Categories
     * section itself manages — see ProjectCategoriesModule), not a
     * fixed enum, since the request explicitly requires vendor-defined,
     * addable/removable categories rather than a hardcoded list.
     */
    public static function get_category_counts( array $projects ): array {
        $counts = [];
        foreach ( $projects as $p ) {
            $cat = trim( (string) ( $p['category'] ?? '' ) );
            if ( $cat === '' ) { continue; }
            $counts[ $cat ] = ( $counts[ $cat ] ?? 0 ) + 1;
        }
        return $counts;
    }

    /** Same real, computed-not-entered pattern as get_category_counts(),
     * for the Design Styles/Expertise section's own "Modern — 12
     * Projects" requirement. */
    public static function get_style_counts( array $projects ): array {
        $counts = [];
        foreach ( $projects as $p ) {
            $style = trim( (string) ( $p['design_style'] ?? '' ) );
            if ( $style === '' ) { continue; }
            $counts[ $style ] = ( $counts[ $style ] ?? 0 ) + 1;
        }
        return $counts;
    }

    /**
     * Real feature — Design Styles/Expertise's own "connect meaningfully
     * to projects/services" requirement. Unlike category/style (single
     * value per project), a project can list several services in its
     * own 'services_provided' array — this counts every project that
     * includes a given expertise tag anywhere in that array, matching
     * the request's own example ("Luxury Interiors → related
     * projects") without a separate, duplicated expertise field on
     * every project.
     */
    public static function get_expertise_counts( array $projects ): array {
        $counts = [];
        foreach ( $projects as $p ) {
            $services = $p['services_provided'] ?? [];
            if ( ! is_array( $services ) ) { continue; }
            foreach ( $services as $service ) {
                $service = trim( (string) $service );
                if ( $service === '' ) { continue; }
                $counts[ $service ] = ( $counts[ $service ] ?? 0 ) + 1;
            }
        }
        return $counts;
    }

    /**
     * Real feature — "Project → Category → Design Style → Services →
     * Related Projects" without duplicating data: finds every other
     * project sharing this one's category or design style, for the
     * project detail view's own "related projects" requirement.
     */
    public static function get_related_projects( array $projects, array $current_project, int $limit = 3 ): array {
        $current_id = $current_project['id'] ?? null;
        $related = array_values( array_filter( $projects, function ( $p ) use ( $current_project, $current_id ) {
            if ( ( $p['id'] ?? null ) === $current_id ) { return false; }
            $same_category = ! empty( $current_project['category'] ) && ( $p['category'] ?? '' ) === $current_project['category'];
            $same_style = ! empty( $current_project['design_style'] ) && ( $p['design_style'] ?? '' ) === $current_project['design_style'];
            return $same_category || $same_style;
        } ) );
        return array_slice( $related, 0, $limit );
    }
}
