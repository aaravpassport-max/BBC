<?php
namespace GoodService\Modules;

use GoodService\Core\ModuleRegistry;

/**
 * SchemaModuleRenderer — the generic render engine for 'schema'-type
 * modules: sections built entirely through the admin Section Builder
 * screen, with no PHP class written for them at all (unlike every
 * 'custom'-type module built earlier in this project, each of which
 * has its own hand-written Module class).
 *
 * A schema module's structure comes from gs_module_config_fields (one
 * row per field: text, textarea, number, image, checkbox, select, or a
 * repeater item), read via ModuleRegistry::get_module_fields(). Its
 * actual per-listing data comes from gs_listing_module_data, exactly
 * the same table every other module (including the hand-built
 * RoomTypesModule) already reads and writes through
 * ModuleRegistry::fetch_module_data() / save_module_data() — there is
 * no separate storage mechanism for no-code sections.
 *
 * Two shapes, decided per-field by is_repeater_item, matching real
 * needs seen across this project's own hand-built modules: a section
 * either has one repeating group (like Room Types' rooms, Packages'
 * plans, Testimonials' entries) OR a flat set of section-level fields
 * (like a single About paragraph). A schema module is one or the
 * other, not both, decided by whether ANY of its fields are marked as
 * repeater items.
 */
class SchemaModuleRenderer {

    private const FIELD_TYPES = [ 'text', 'textarea', 'number', 'image', 'checkbox', 'select', 'url' ];

    /**
     * @param array $context {
     *     @type string $module_key  Required.
     *     @type array  $data        This listing's saved data for this
     *                  module (from fetch_module_data()) — shape
     *                  depends on whether the module is a repeater:
     *                  ['items' => [...]] for a repeater, or a flat
     *                  ['field_key' => value, ...] otherwise.
     * }
     */
    public static function render( array $context ): string {
        $module_key = $context['module_key'] ?? '';
        if ( $module_key === '' ) { return ''; }
        $module = ModuleRegistry::get( $module_key );
        if ( $module === null ) { return ''; }

        $fields = ModuleRegistry::get_module_fields( $module_key );
        if ( empty( $fields ) ) { return ''; }

        $data = $context['data'] ?? [];
        $is_repeater = array_reduce( $fields, fn( $carry, $f ) => $carry || ! empty( $f->is_repeater_item ), false );

        ob_start();
        ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html( $module['label'] ); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php
        if ( $is_repeater ) {
            $items = array_filter( (array) ( $data['items'] ?? [] ), 'is_array' );
            if ( empty( $items ) ) { ob_end_clean(); return ''; }
            ?>
    <div class="vs-schema-grid">
        <?php foreach ( $items as $item ): ?>
        <div class="vs-schema-card">
            <?php foreach ( $fields as $f ): echo self::render_field( $f, $item[ $f->field_key ] ?? null ); endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php
        } else {
            $has_any_value = false;
            foreach ( $fields as $f ) { if ( ! empty( $data[ $f->field_key ] ) ) { $has_any_value = true; break; } }
            if ( ! $has_any_value ) { ob_end_clean(); return ''; }
            ?>
    <div class="vs-schema-flat">
        <?php foreach ( $fields as $f ): echo self::render_field( $f, $data[ $f->field_key ] ?? null ); endforeach; ?>
    </div>
<?php
        }
        return ob_get_clean();
    }

    /** Renders a single field's value according to its declared type. Unknown/unsupported types fall back to plain escaped text, never raw/unescaped output. */
    private static function render_field( object $field, $value ): string {
        if ( $value === null || $value === '' ) { return ''; }
        $type = in_array( $field->field_type, self::FIELD_TYPES, true ) ? $field->field_type : 'text';
        ob_start();
        switch ( $type ) {
            case 'image':
                ?><img src="<?php echo esc_url( (string) $value ); ?>" alt="<?php echo esc_attr( $field->field_label ); ?>" loading="lazy" class="vs-schema-field-image" width="320" height="200"><?php
                break;
            case 'url':
                ?><a href="<?php echo esc_url( (string) $value ); ?>" target="_blank" rel="noopener" class="vs-schema-field-link"><?php echo esc_html( (string) $value ); ?></a><?php
                break;
            case 'checkbox':
                if ( $value ) { ?><span class="vs-schema-field-badge">✓ <?php echo esc_html( $field->field_label ); ?></span><?php }
                break;
            case 'number':
                ?><div class="vs-schema-field vs-schema-field-number"><?php echo esc_html( (string) (float) $value ); ?></div><?php
                break;
            case 'textarea':
                ?><div class="vs-schema-field vs-schema-field-text"><?php echo nl2br( esc_html( (string) $value ) ); ?></div><?php
                break;
            default: // text, select
                ?><div class="vs-schema-field vs-schema-field-text"><?php echo esc_html( (string) $value ); ?></div><?php
        }
        return ob_get_clean();
    }
}
