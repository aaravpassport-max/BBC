<?php
namespace GoodService\Modules;

/**
 * WeddingPortfolioModule — Events & Wedding, Section 01: "Signature
 * Portfolio". The hero section beneath the existing Hero Slider, per
 * the spec's own framing — an editorial mosaic gallery, not a generic
 * equal-grid, with category tabs shown only for categories that
 * actually contain real vendor work.
 *
 * Reuses the platform's existing fullscreen lightbox
 * (window.vsLightbox(url, caption, gridId)) rather than building a
 * new fullscreen viewer — its own grid-id parameter exists precisely
 * so a second gallery-style grid on the same page (this one) can have
 * its own independently-navigable lightbox, per the master build
 * prompt's Section 7 guidance.
 */
class WeddingPortfolioModule {

    /**
     * Layout variants — the same proven mechanism already established
     * by FeaturedProjectsModule::LAYOUTS / DoctorsModule::LAYOUTS: a
     * public const on the module class, looped by a single admin
     * <select>, validated with in_array() at render time, and keyed
     * off a layout-modifier class on the grid element.
     *
     * `editorial` is the pre-existing every-3rd-item mosaic rhythm and
     * stays the default so upgrading never silently changes an
     * already-configured vendor page. `masonry` reuses the platform's
     * own closest masonry precedent — GalleryModule's `gallery_layout`
     * option on `.vs-gallery-grid`/`.vs-gallery-item` in
     * vendor-site.php — verbatim: a JS-free CSS grid trick (fine
     * `grid-auto-rows` plus a fixed `grid-row-end: span` per item,
     * image `aspect-ratio: auto`), not CSS columns, because that is
     * the actual mechanism that precedent uses.
     */
    public const LAYOUTS = [
        'editorial' => 'Editorial Mosaic',
        'masonry'   => 'Masonry',
    ];

    public static function render_title( string $heading, string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-wedding-sec-head">
        <div class="gs-wedding-eyebrow">Our Work</div>
        <h2 class="vs-sec-title gs-wedding-title"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-wedding-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Editorial mosaic (default, unchanged): every third item
     * (0-indexed positions 0, 3, 6…) renders large — the
     * featured-image treatment the spec's own layout diagram calls
     * for — the two items either side render at the smaller size,
     * repeating down the grid as more items load. A pure count-based
     * rule rather than a vendor-set "featured" flag, since the spec's
     * own diagram describes a *repeating* editorial rhythm, not a
     * single one-off hero image.
     *
     * Masonry (new): the every-3rd-item mosaic rhythm doesn't apply —
     * Pinterest-style masonry is about natural varying-height columns,
     * not a repeating hero pattern — so `is-featured` is never applied
     * in this layout; height variance comes purely from the CSS
     * mechanism described on LAYOUTS above.
     */
    public static function render_grid( array $items, array $img_display = [], string $layout = 'editorial' ): string {
        $items = array_values( array_filter( $items, fn( $i ) => ! empty( $i['image'] ) ) );
        if ( empty( $items ) ) { return ''; }
        $layout = in_array( $layout, array_keys( self::LAYOUTS ), true ) ? $layout : 'editorial';
        $_img_style   = \gs_vs_img_display_style( $img_display )['img'];
        $active_cats  = \GoodService\Modules\WeddingEventsModule::get_active_portfolio_categories( $items );
        $grid_id      = 'vs-wedding-portfolio-grid';

        ob_start();
        ?>
    <div class="gs-wedding-portfolio">
        <?php if ( count( $active_cats ) > 1 ): ?>
        <div class="gs-wedding-tabs" role="tablist" aria-label="Filter portfolio by category">
            <button type="button" class="gs-wedding-tab is-active" data-category="all" role="tab" aria-selected="true">All</button>
            <?php foreach ( $active_cats as $_ckey => $_clabel ): ?>
            <button type="button" class="gs-wedding-tab" data-category="<?php echo esc_attr( $_ckey ); ?>" role="tab" aria-selected="false"><?php echo esc_html( $_clabel ); ?></button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="gs-wedding-portfolio-grid gs-wedding-portfolio-layout-<?php echo esc_attr( $layout ); ?>" id="<?php echo esc_attr( $grid_id ); ?>">
        <?php foreach ( $items as $_idx => $item ):
            $is_featured = ( $layout === 'editorial' && $_idx % 3 === 0 );
            $caption     = trim( (string) ( $item['caption'] ?? '' ) );
            $cat_label   = isset( $item['category'], \GoodService\Modules\WeddingEventsModule::PORTFOLIO_CATEGORIES[ $item['category'] ] ) ? \GoodService\Modules\WeddingEventsModule::PORTFOLIO_CATEGORIES[ $item['category'] ] : '';
        ?>
            <button type="button" class="gs-wedding-portfolio-item<?php echo $is_featured ? ' is-featured' : ''; ?>" data-category="<?php echo esc_attr( $item['category'] ?? '' ); ?>" onclick="vsLightbox(this.querySelector('img').src, this.querySelector('img').alt, '<?php echo esc_js( $grid_id ); ?>')">
                <img src="<?php echo esc_url( $item['image'] ); ?>" alt="<?php echo esc_attr( $caption !== '' ? $caption : ( $cat_label !== '' ? $cat_label : 'Portfolio image' ) ); ?>" class="gs-wedding-portfolio-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <div class="gs-wedding-portfolio-overlay">
                    <?php if ( $cat_label !== '' ): ?><span class="gs-wedding-portfolio-cat"><?php echo esc_html( $cat_label ); ?></span><?php endif; ?>
                    <?php if ( $caption !== '' ): ?><span class="gs-wedding-portfolio-caption"><?php echo esc_html( $caption ); ?></span><?php endif; ?>
                </div>
            </button>
        <?php endforeach; ?>
        </div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $items
     *     @type array  $vendor_types
     *     @type string $section_title  vendor override; falls back to the adaptive heading when blank.
     *     @type string $section_description
     *     @type array  $img_display
     *     @type string $layout
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid(
            (array) ( $context['items'] ?? [] ),
            (array) ( $context['img_display'] ?? [] ),
            (string) ( $context['layout'] ?? 'editorial' )
        );
        if ( $html === '' ) { return ''; }
        $heading = trim( (string) ( $context['section_title'] ?? '' ) );
        if ( $heading === '' ) {
            $heading = \GoodService\Modules\WeddingEventsModule::portfolio_heading( (array) ( $context['vendor_types'] ?? [] ) );
        }
        return self::render_title( $heading, (string) ( $context['section_description'] ?? '' ) ) . $html;
    }
}
