<?php
namespace GoodService\Modules;

/**
 * WeddingQuoteModule — Events & Wedding, Section 11 of 11:
 * "Request a Quote". Investigation before building, per this build's
 * standing discipline:
 *
 * 1. Is window.vsOpenInquiry() a real multi-field CUSTOM form that
 *    could carry arbitrary extra fields (Event Type, Guest Count,
 *    Venue Type, ...)? No. Grepped its full implementation in
 *    vendor-site.php (~10334-10412) and its submit handler
 *    vsSubmitInquiry() (~10415-10478): it is a FIXED-shape popup —
 *    name/phone/email/city/qty/purchase-date/callback-date/remarks
 *    plus item name/type/price — posting straight to action
 *    'gs_submit_lead'. There is no mechanism to add a new named field
 *    to it; every field it POSTs is read by id in vsSubmitInquiry(),
 *    so an extra input placed outside those ids would simply never be
 *    read and its data would be silently discarded.
 *
 * 2. Does a real, separate, genuinely free-form inquiry endpoint
 *    exist? Yes — action 'gs_submit_inquiry' (AjaxController::
 *    submitInquiry(), ~17928), driven by the pre-existing
 *    InquiryCategoryData.php / InquiryFormService registry and
 *    rendered as the page's own "inquiry_modules" section (the
 *    .vs-contact-form-card / cxSubmit() flow, ~7790-7832 /
 *    ~10500-10520). Its custom gs_f_-prefixed fields DO reach
 *    custom_fields JSON. But it is NOT a fit for this section: it
 *    requires `inquiry_module` to be a slug already present in
 *    InquiryFormService's registry (submitInquiry() hard-rejects any
 *    unknown slug — see the "Invalid inquiry module type" check right
 *    after module_slug is read), so a new 'wedding_quote' slug could
 *    not be added without also registering a whole new inquiry
 *    category — a much bigger, differently-owned system. Worse, that
 *    whole endpoint is server-side gated behind the vendor's
 *    subscription plan (`allow_inquiry_module` — see the "plan_allows_
 *    inquiry" check): wiring this always-available, default section
 *    into a paid-plan-gated endpoint would make it silently error out
 *    ("This listing is not currently accepting inquiries") for any
 *    vendor without that specific plan feature, which is a strictly
 *    worse and more confusing failure mode than what this file does
 *    instead.
 *
 * DECISION: same honest fallback as Section 10 (Check Availability) —
 * this section is a real, prominent `<form>`-shaped UI (base fields:
 * Name/Phone/Email collected by the popup itself, plus this section's
 * own Event Date + one vendor-type-adaptive extra field + Message),
 * but its submit button does not invent a new submission path. It
 * calls the platform's real, existing, working window.vsOpenInquiry()
 * popup — the exact same mechanism wedding_packages' "Request a
 * Quote" CTA and wedding_availability's CTA already use — and folds
 * every value the visitor typed here into that popup's own real
 * fields (purchase-date + remarks) before it opens, via
 * window.vsWeddingRequestQuote() in vendor-site.php. Nothing typed
 * here is ever silently discarded; nothing fake is submitted either.
 * What makes this section "Section 11" rather than a copy of Section
 * 10 is presentation: a full-width, prominent banner-style CTA
 * distinct from Section 10's plain two-column card, plus the one
 * vendor-type-adaptive extra field neither Section 04's nor Section
 * 10's CTAs carry.
 */
class WeddingQuoteModule {

    /**
     * @param array $context {
     *     @type array  $vendor_types
     *     @type string $section_title        vendor override; falls back to the adaptive heading when blank.
     *     @type string $section_description   vendor override; falls back to the default copy when blank.
     * }
     */
    public static function render( array $context ): string {
        $vendor_types = (array) ( $context['vendor_types'] ?? [] );

        $heading = trim( (string) ( $context['section_title'] ?? '' ) );
        if ( $heading === '' ) {
            $heading = \GoodService\Modules\WeddingEventsModule::quote_heading( $vendor_types );
        }
        $desc = trim( (string) ( $context['section_description'] ?? '' ) );
        if ( $desc === '' ) {
            $desc = "Share a few details about your event and we'll send you a personalised quote — no obligation.";
        }

        $extra = \GoodService\Modules\WeddingEventsModule::extra_quote_field( $vendor_types );

        ob_start();
        ?>
    <div class="gs-wedding-quote-banner">
        <div class="gs-wedding-quote-copy">
            <div class="gs-wedding-eyebrow gs-wedding-quote-eyebrow">Get Started</div>
            <h2 class="vs-sec-title gs-wedding-title gs-wedding-quote-heading"><?php echo esc_html( $heading ); ?></h2>
            <p class="gs-wedding-quote-desc"><?php echo esc_html( $desc ); ?></p>
        </div>
        <div class="gs-wedding-quote-form">
            <div class="gs-wedding-quote-row">
                <label class="gs-wedding-quote-lbl" for="gs-wq-name">Your Name</label>
                <input type="text" id="gs-wq-name" class="gs-wedding-quote-input" placeholder="Full name">
            </div>
            <div class="gs-wedding-quote-row">
                <label class="gs-wedding-quote-lbl" for="gs-wq-date">Event Date</label>
                <input type="date" id="gs-wq-date" class="gs-wedding-quote-input">
            </div>
            <div class="gs-wedding-quote-row">
                <label class="gs-wedding-quote-lbl" for="gs-wq-extra"><?php echo esc_html( $extra['label'] ); ?></label>
                <?php if ( $extra['type'] === 'select' ) : ?>
                <select id="gs-wq-extra" class="gs-wedding-quote-input">
                    <option value="">Select…</option>
                    <?php foreach ( (array) $extra['options'] as $opt ) : ?>
                    <option value="<?php echo esc_attr( $opt ); ?>"><?php echo esc_html( $opt ); ?></option>
                    <?php endforeach; ?>
                </select>
                <?php else : ?>
                <input type="text" id="gs-wq-extra" class="gs-wedding-quote-input" placeholder="<?php echo esc_attr( $extra['ph'] ?? '' ); ?>">
                <?php endif; ?>
            </div>
            <div class="gs-wedding-quote-row">
                <label class="gs-wedding-quote-lbl" for="gs-wq-message">Tell Us More</label>
                <textarea id="gs-wq-message" class="gs-wedding-quote-input gs-wedding-quote-textarea" rows="2" placeholder="Anything else that will help us quote accurately"></textarea>
            </div>
            <button type="button" class="gs-wedding-quote-btn" data-extra-label="<?php echo esc_attr( $extra['label'] ); ?>" onclick="vsWeddingRequestQuote(this)">Get My Free Quote</button>
        </div>
    </div>
<?php
        return ob_get_clean();
    }
}
