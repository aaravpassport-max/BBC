<?php
namespace GoodService\Modules;

/**
 * WeddingVenueSpecModule — Events & Wedding, Section 07 of 7: "Venue /
 * Event Specialisation". OPTIONAL section, only meaningful for vendor
 * types that actually specialize by venue/event format (planners,
 * decorators, event companies) — not for e.g. a pure makeup_artist or
 * mehndi artist. Deliberately NOT vendor-type-gated at the admin level:
 * consistent with every other wedding_* section, the admin card is
 * always available and this section naturally renders '' publicly for
 * any vendor who genuinely has nothing checked (the standard
 * "never render an empty shell" discipline already used everywhere in
 * this category, rather than inventing new vendor-type-based admin
 * hiding logic that no sibling section has).
 *
 * Hybrid data shape: a fixed enum selection (like wedding_style_tags)
 * where each checked item can optionally carry a short free-text note
 * (unlike wedding_style, which has no per-item fields at all). Render
 * rule: an item WITH a non-empty note renders as a small card (label +
 * note line); an item with no note renders as a plain chip — the two
 * can mix freely in the same grid. This keeps the common "just tick a
 * few boxes" case visually light while still giving vendors who want to
 * add real proof ("20+ destination weddings across Goa and Udaipur")
 * room to show it, without forcing every chip into a heavier card.
 */
class WeddingVenueSpecModule {

    public static function render_title( string $heading, string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-wedding-sec-head">
        <div class="gs-wedding-eyebrow">Specialization</div>
        <h2 class="vs-sec-title gs-wedding-title"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-wedding-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    public static function render_grid( array $items ): string {
        $items = array_values( array_filter( $items, fn( $i ) => is_array( $i ) && trim( (string) ( $i['label'] ?? '' ) ) !== '' ) );
        if ( empty( $items ) ) { return ''; }

        ob_start();
        ?>
    <div class="gs-wedding-venuespec-grid">
        <?php foreach ( $items as $it ):
            $label = trim( (string) ( $it['label'] ?? '' ) );
            $note  = trim( (string) ( $it['note'] ?? '' ) );
            $icon  = \GoodService\Modules\WeddingEventsModule::venue_spec_icon( (string) ( $it['key'] ?? '' ) );
        ?>
        <?php if ( $note !== '' ): ?>
        <div class="gs-wedding-venuespec-card">
            <div class="gs-wedding-venuespec-card-icon" aria-hidden="true"><?php echo esc_html( $icon ); ?></div>
            <div class="gs-wedding-venuespec-card-label"><?php echo esc_html( $label ); ?></div>
            <p class="gs-wedding-venuespec-card-note"><?php echo esc_html( $note ); ?></p>
        </div>
        <?php else: ?>
        <div class="gs-wedding-venuespec-chip"><span class="gs-wedding-venuespec-chip-icon" aria-hidden="true"><?php echo esc_html( $icon ); ?></span> <?php echo esc_html( $label ); ?></div>
        <?php endif; ?>
        <?php endforeach; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $items          each with key/label/note
     *     @type array  $vendor_types
     *     @type string $section_title  vendor override; falls back to the adaptive heading when blank.
     *     @type string $section_description
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid( (array) ( $context['items'] ?? [] ) );
        if ( $html === '' ) { return ''; } // Mandatory empty-state.
        $heading = trim( (string) ( $context['section_title'] ?? '' ) );
        if ( $heading === '' ) {
            $heading = \GoodService\Modules\WeddingEventsModule::venue_spec_heading( (array) ( $context['vendor_types'] ?? [] ) );
        }
        return self::render_title( $heading, (string) ( $context['section_description'] ?? '' ) ) . $html;
    }
}
