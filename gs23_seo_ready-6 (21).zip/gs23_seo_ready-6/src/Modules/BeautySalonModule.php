<?php
namespace GoodService\Modules;

/**
 * BeautySalonModule — the foundational data-access layer for the
 * Beauty & Salon category build (built one section at a time; this
 * file is the shared foundation every Beauty & Salon module reads
 * from, matching the established pattern of HealthWellnessModule
 * and InteriorDesignersModule before it — one small, shared class per
 * category holding real category slug/group constants and the plain
 * data-fetch helpers every module in the category needs, rather than
 * each module re-declaring its own copy).
 *
 * CONFIRMED, not guessed, per the master build prompt's Section 0.2:
 * "Beauty & Salon" is a real, pre-seeded category — see
 * src/Database/Seeder.php::seed_categories() — with slug
 * 'beauty-salon'. This was read directly from the seeder, not assumed
 * from the category's display name.
 */
class BeautySalonModule {

    /** Service discovery groups (Section 01). Only a subset that a
     * vendor actually has services in is ever shown — see
     * BeautyServicesModule::get_active_groups(). Keys are stored on
     * each service's own `group` field; values are the tab label. */
    public const SERVICE_GROUPS = [
        'hair'     => 'Hair',
        'skin'     => 'Skin',
        'facial'   => 'Facial',
        'makeup'   => 'Makeup',
        'nails'    => 'Nails',
        'grooming' => 'Grooming',
        'spa'      => 'Spa',
        'bridal'   => 'Bridal',
        'packages' => 'Packages',
    ];

    /** Optional per-service flags a vendor can tick — never inferred,
     * only ever shown when the vendor explicitly set them (Section 01,
     * "Only display actual configured flags"). */
    public const SERVICE_FLAGS = [
        'is_popular'    => 'Popular',
        'is_new'        => 'New',
        'is_best_seller'=> 'Best Seller',
        'is_bridal'     => 'Bridal',
        'is_premium'    => 'Premium',
    ];

    public static function get_services( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'beauty_services', $listing_id );
        return array_values( array_filter( (array) ( $data['services'] ?? [] ), fn( $s ) => is_array( $s ) && ! empty( $s['name'] ) ) );
    }

    /** Only the groups that at least one real, named service actually
     * uses — Section 01's explicit requirement: "Only display
     * categories for which services actually exist." An "All" tab is
     * added by the render layer, not here, since whether the count
     * warrants showing an "All" tab at all is a display decision. */
    public static function get_active_groups( array $services ): array {
        $used = [];
        foreach ( $services as $s ) {
            $g = $s['group'] ?? '';
            if ( $g !== '' && isset( self::SERVICE_GROUPS[ $g ] ) && ! isset( $used[ $g ] ) ) {
                $used[ $g ] = self::SERVICE_GROUPS[ $g ];
            }
        }
        return $used;
    }

    public static function get_services_for_group( array $services, string $group ): array {
        if ( $group === '' || $group === 'all' ) { return $services; }
        return array_values( array_filter( $services, fn( $s ) => ( $s['group'] ?? '' ) === $group ) );
    }

    /** Section 02 — Signature Looks & Transformations. Its own,
     * independently-gated data owned under module key 'beauty_gallery'. */
    public static function get_gallery_items( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'beauty_gallery', $listing_id );
        return array_values( array_filter( (array) ( $data['items'] ?? [] ), fn( $g ) =>
            is_array( $g ) && ( ! empty( $g['image'] ) || ( ! empty( $g['before_image'] ) && ! empty( $g['after_image'] ) ) )
        ) );
    }

    /** Section 03 — Beauty Experts/Stylists. Its own, independently-
     * gated data owned under module key 'beauty_experts'. */
    public static function get_experts( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'beauty_experts', $listing_id );
        return array_values( array_filter( (array) ( $data['experts'] ?? [] ), fn( $e ) => is_array( $e ) && ! empty( $e['name'] ) ) );
    }

    /** Section 04 — Salon Experience & Facilities. Its own,
     * independently-gated data owned under module key 'beauty_facilities'. */
    public static function get_facilities_data( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'beauty_facilities', $listing_id );
        return [
            'image'             => (string) ( $data['image'] ?? '' ),
            'facilities'        => is_array( $data['facilities'] ?? null ) ? $data['facilities'] : [],
            'custom_facilities' => (string) ( $data['custom_facilities'] ?? '' ),
        ];
    }

    /** Section 05 — Beauty Packages & Offers. Its own, independently-
     * gated data owned under module key 'beauty_packages'. Only items
     * with a real, vendor-typed name are ever returned — matching the
     * same "never fabricate" discipline as every prior section. */
    public static function get_packages( $wpdb, string $table_prefix, int $listing_id ): array {
        $data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'beauty_packages', $listing_id );
        return array_values( array_filter( (array) ( $data['packages'] ?? [] ), fn( $p ) => is_array( $p ) && ! empty( $p['name'] ) ) );
    }
}
