<?php
namespace GoodService\Modules;

/**
 * HotelDiningModule — Hotels / Banquets / Hospitality category, Module
 * 3: "Dining & Culinary Experience" (custom build spec's Sections 06
 * and 07 combined: Dining & Culinary Experience overview, and Menu
 * Experience). Combined into one module for the same Data-Density
 * reasoning already documented on HotelEventsShowcaseModule and
 * HomeServicesCatalogueModule — an overview strip with no real menu
 * items behind it is exactly the kind of thin, overlapping section the
 * master build prompt's Section 32 warns against; a real, filterable
 * menu already IS the dining experience section.
 *
 * INVESTIGATION PERFORMED FIRST, per the master build prompt's Section
 * 0.1: no existing module in this codebase covers a food/beverage menu
 * in any category, so there is nothing to reuse the data model from.
 * Structurally, though, this is the same shape as
 * HomeServicesCatalogueModule (a category-tabbed grid of items with a
 * price contract and flags) — that module's tab-filtering pattern
 * (plain data-attribute matching, filtered client-side, no reload) is
 * reused here rather than inventing a second tab mechanism.
 *
 * No booking wizard, no detail popup — a restaurant menu is browsed,
 * not booked per-item — so this module intentionally does NOT reuse
 * vsOpenBookingWizard()/vsOpenDetailPopup(); it is a pure, real display
 * of what the vendor has actually entered.
 *
 * Master build prompt Section 3 (Rows & Columns / Sorting / Show-Hide
 * Fields) — Selection/Filter IS built (the category tabs above); Rows &
 * Columns and Sorting are not: this module's cited structural precedent,
 * HomeServicesCatalogueModule, has neither a max-rows/column-count
 * control nor a sort control on its own tabbed item grid either
 * (confirmed directly — grepped create-listing.php for
 * home_services_catalogue_columns/_max_rows/_sort, zero matches), so
 * this module stays consistent with the actual precedent it followed
 * rather than adding controls that precedent doesn't have.
 */
class HotelDiningModule {

    public const MENU_CATEGORIES = [
        'breakfast'    => 'Breakfast',
        'starters'     => 'Starters',
        'soups'        => 'Soups',
        'main_course'  => 'Main Course',
        'breads_rice'  => 'Breads & Rice',
        'desserts'     => 'Desserts',
        'beverages'    => 'Beverages',
        'buffet'       => 'Buffet / Set Menu',
    ];

    /** Indian dining convention — a single dietary classification per
     * item (not multiple flags), matching how Indian restaurant menus
     * are actually marked (a green/red/brown dot). */
    public const DIETARY_TYPES = [
        'veg'      => 'Veg',
        'non_veg'  => 'Non-Veg',
        'egg'      => 'Contains Egg',
        'vegan'    => 'Vegan',
        'jain'     => 'Jain',
    ];

    public static function render_title( string $heading = 'Dining & Culinary Experience', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-hdin-sec-head">
        <div class="gs-hdin-eyebrow">Food &amp; Beverage</div>
        <h2 class="vs-sec-title gs-hdin-title"><?php echo esc_html( $heading ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-hdin-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /** Same real, deliberate contract as everywhere else in this
     * codebase (spec's Section 33, "Zero-Data Handling"): a real,
     * positive numeric price shows; a blank/zero/non-numeric one is
     * simply omitted from the card rather than shown as ₹0 or a
     * fabricated "Ask Staff" guess. */
    private static function price_display( array $item ): string {
        $currency = \gs_setting( 'currency_symbol', '₹' );
        $price    = trim( (string) ( $item['price'] ?? '' ) );
        if ( $price !== '' && is_numeric( $price ) && (float) $price > 0 ) {
            return $currency . $price;
        }
        return '';
    }

    private static function dot_class( string $type ): string {
        return match ( $type ) {
            'veg', 'vegan', 'jain' => 'gs-hdin-dot-veg',
            'non_veg' => 'gs-hdin-dot-nonveg',
            'egg' => 'gs-hdin-dot-egg',
            default => '',
        };
    }

    public static function render_grid( array $items, array $img_display = [] ): string {
        $items = array_values( array_filter( $items, fn( $i ) => is_array( $i ) && trim( (string) ( $i['name'] ?? '' ) ) !== '' ) );
        if ( empty( $items ) ) { return ''; }
        $_img_style = \gs_vs_img_display_style( $img_display )['img'];

        // Same "only show tabs the vendor actually used" rule as
        // HomeServicesCatalogueModule's active-groups logic — never a
        // full fixed tab bar with empty tabs behind it.
        $active_cats = [];
        foreach ( $items as $it ) {
            $cat = (string) ( $it['category'] ?? '' );
            if ( isset( self::MENU_CATEGORIES[ $cat ] ) && ! isset( $active_cats[ $cat ] ) ) {
                $active_cats[ $cat ] = self::MENU_CATEGORIES[ $cat ];
            }
        }

        ob_start();
        ?>
    <div class="gs-hdin-menu">
        <?php if ( count( $active_cats ) > 1 ): ?>
        <div class="gs-hdin-tabs" role="tablist" aria-label="Filter menu by category">
            <button type="button" class="gs-hdin-tab is-active" data-cat="all" role="tab" aria-selected="true">All</button>
            <?php foreach ( $active_cats as $_ck => $_cl ): ?>
            <button type="button" class="gs-hdin-tab" data-cat="<?php echo esc_attr( $_ck ); ?>" role="tab" aria-selected="false"><?php echo esc_html( $_cl ); ?></button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="gs-hdin-grid">
        <?php foreach ( $items as $item ):
            $price     = self::price_display( $item );
            $diet_key  = (string) ( $item['dietary'] ?? '' );
            $diet_lbl  = self::DIETARY_TYPES[ $diet_key ] ?? '';
            $dot_class = self::dot_class( $diet_key );
            $chef      = ! empty( $item['chef_special'] );
            $cuisine   = trim( (string) ( $item['cuisine'] ?? '' ) );
            $desc      = trim( (string) ( $item['description'] ?? '' ) );
            $image     = trim( (string) ( $item['image'] ?? '' ) );
        ?>
        <div class="gs-hdin-card" data-cat="<?php echo esc_attr( $item['category'] ?? '' ); ?>">
            <?php if ( $image !== '' ): ?>
            <div class="gs-hdin-media">
                <img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>" class="gs-hdin-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php if ( $chef ): ?><span class="gs-hdin-chef-badge">★ Chef's Special</span><?php endif; ?>
            </div>
            <?php endif; ?>
            <div class="gs-hdin-body">
                <div class="gs-hdin-top-row">
                    <div class="gs-hdin-name-row">
                        <?php if ( $dot_class !== '' ): ?><span class="gs-hdin-dot <?php echo esc_attr( $dot_class ); ?>" title="<?php echo esc_attr( $diet_lbl ); ?>" aria-label="<?php echo esc_attr( $diet_lbl ); ?>"></span><?php endif; ?>
                        <span class="gs-hdin-name"><?php echo esc_html( $item['name'] ); ?></span>
                    </div>
                    <?php if ( $price !== '' ): ?><span class="gs-hdin-price"><?php echo esc_html( $price ); ?></span><?php endif; ?>
                </div>
                <?php if ( $image === '' && $chef ): ?><span class="gs-hdin-chef-badge gs-hdin-chef-badge-inline">★ Chef's Special</span><?php endif; ?>
                <?php if ( $cuisine !== '' ): ?><div class="gs-hdin-cuisine"><?php echo esc_html( $cuisine ); ?></div><?php endif; ?>
                <?php if ( $desc !== '' ): ?><p class="gs-hdin-desc-line"><?php echo esc_html( $desc ); ?></p><?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
    </div>
<?php
        return ob_get_clean();
    }

    public static function get_items( $wpdb, string $table_prefix, int $listing_id ): array {
        $stored = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $table_prefix, 'hotel_dining', $listing_id );
        return array_values( array_filter( (array) ( $stored['items'] ?? [] ), fn( $i ) => is_array( $i ) ) );
    }

    /**
     * @param array $context {
     *     @type array  $items
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid(
            (array) ( $context['items'] ?? [] ),
            (array) ( $context['img_display'] ?? [] )
        );
        if ( $html === '' ) { return ''; } // Mandatory empty-state — custom build spec's Section 48.
        return self::render_title( $context['section_title'] ?? 'Dining & Culinary Experience', $context['section_description'] ?? '' ) . $html;
    }
}
