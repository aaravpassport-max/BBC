<?php
namespace GoodService\Modules;

/**
 * BeautyServicesModule — Beauty & Salon, Section 01 of 6: "Beauty
 * Service Discovery". The primary service-discovery system for the
 * category, following the exact same shape as the reference pattern
 * (FeaturedServicesModule, Health & Wellness) per the master build
 * prompt's Section 0.1: read the most similar existing module first,
 * reuse its structure rather than inventing a new one.
 *
 * Reuses established platform mechanisms, never a parallel system:
 * vsOpenDetailPopup() for the service detail view, vsOpenInquiry() for
 * "Book"/"Enquire" (preserving the selected service's name/price into
 * the existing simple-inquiry flow — the master spec's Section 3
 * requirement: "preserve selected service when proceeding to
 * booking"), and the platform's own tel:/wa.me CTA pattern using the
 * vendor's own already-saved phone/WhatsApp number.
 *
 * Category tabs (All / Hair / Skin / ...) are rendered server-side but
 * filtered client-side with plain data-attribute matching — no page
 * reload, no second AJAX round trip for what is, at most, a few dozen
 * already-rendered cards.
 */
class BeautyServicesModule {

    public static function render_title( string $title = 'Beauty & Salon Services', string $description = '' ): string {
        ob_start();
        ?>
    <div class="gs-beauty-sec-head">
        <div class="gs-beauty-eyebrow">What We Offer</div>
        <h2 class="vs-sec-title gs-beauty-title"><?php echo esc_html( $title ); ?></h2>
        <?php if ( $description !== '' ): ?><p class="gs-beauty-desc"><?php echo esc_html( $description ); ?></p><?php endif; ?>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * Section 3's exact price-state contract: an exact price, a
     * "From"/"Starting at" price, or "Price on enquiry" — never a
     * fabricated or zero/blank value standing in for a real price.
     */
    private static function price_display( array $service ): string {
        $currency = \gs_setting( 'currency_symbol', '₹' );
        $exact    = trim( (string) ( $service['price'] ?? '' ) );
        $from     = trim( (string) ( $service['starting_price'] ?? '' ) );
        if ( $exact !== '' && is_numeric( $exact ) && (float) $exact > 0 ) {
            return $currency . $exact;
        }
        if ( $from !== '' && is_numeric( $from ) && (float) $from > 0 ) {
            return 'From ' . $currency . $from;
        }
        return 'Price on enquiry';
    }

    /** Section 3's exact duration-state contract — vendor-entered free
     * text (45 min / 60 min / 1 hr 30 min / Varies), never computed or
     * guessed when absent. */
    private static function duration_display( array $service ): string {
        return trim( (string) ( $service['duration'] ?? '' ) );
    }

    private static function build_detail_sections( array $service ): array {
        $sections = [];
        if ( ! empty( $service['detailed_description'] ) ) {
            $sections[] = [ 'content_type' => 'richtext', 'title' => 'About This Service', 'icon' => '💇', 'body' => esc_html( $service['detailed_description'] ) ];
        }
        $meta = [];
        if ( ! empty( $service['duration'] ) )       { $meta[] = 'Duration: ' . $service['duration']; }
        if ( ! empty( $service['group'] ) && isset( \GoodService\Modules\BeautySalonModule::SERVICE_GROUPS[ $service['group'] ] ) ) {
            $meta[] = 'Category: ' . \GoodService\Modules\BeautySalonModule::SERVICE_GROUPS[ $service['group'] ];
        }
        if ( ! empty( $meta ) ) {
            $sections[] = [ 'content_type' => 'list', 'title' => 'Service Details', 'icon' => 'ℹ️', 'list_items' => $meta ];
        }
        // Real, established pattern — the shared "Manage Details" popup
        // builder's own output, appended after the automatic sections,
        // exactly like every other card-based module (Section 8 of the
        // master build prompt).
        $custom_vms = is_string( $service['view_more_sections'] ?? null )
            ? ( json_decode( $service['view_more_sections'], true ) ?: [] )
            : ( $service['view_more_sections'] ?? [] );
        if ( is_array( $custom_vms ) ) {
            foreach ( $custom_vms as $_vms ) { if ( is_array( $_vms ) ) { $sections[] = $_vms; } }
        }
        return $sections;
    }

    /**
     * @param array $img_display  fit/position/zoom — shared, global
     *              gs_vs_img_display_style() helper.
     */
    public static function render_grid( array $services, array $img_display = [], string $phone = '', string $wa_clean = '' ): string {
        $services = array_values( array_filter( $services, fn( $s ) => ! empty( $s['name'] ) ) );
        if ( empty( $services ) ) { return ''; }
        $_img_style   = \gs_vs_img_display_style( $img_display )['img'];
        $active_groups = \GoodService\Modules\BeautySalonModule::get_active_groups( $services );

        ob_start();
        ?>
    <div class="gs-beauty-services">
        <?php if ( count( $active_groups ) > 1 ): ?>
        <div class="gs-beauty-tabs" role="tablist" aria-label="Filter services by category">
            <button type="button" class="gs-beauty-tab is-active" data-group="all" role="tab" aria-selected="true">All</button>
            <?php foreach ( $active_groups as $_gkey => $_glabel ): ?>
            <button type="button" class="gs-beauty-tab" data-group="<?php echo esc_attr( $_gkey ); ?>" role="tab" aria-selected="false"><?php echo esc_html( $_glabel ); ?></button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="gs-beauty-grid">
        <?php foreach ( $services as $service ):
            $detail_sections = self::build_detail_sections( $service );
            $price_display   = self::price_display( $service );
            $duration        = self::duration_display( $service );
            $flags = [];
            foreach ( \GoodService\Modules\BeautySalonModule::SERVICE_FLAGS as $_fkey => $_flabel ) {
                if ( ! empty( $service[ $_fkey ] ) ) { $flags[] = $_flabel; }
            }
        ?>
        <?php
            // Whole-card-click-opens-popup: same established platform
            // pattern already used by .vs-svc-card/.vs-item-card (see
            // vendor-site.php ~6670) — duplicate the exact same data-*
            // attributes onto the card wrapper itself and give it the
            // SAME onclick call, so the card and the "View Details" link
            // are guaranteed to open the identical popup with identical
            // content (they call the exact same function with the exact
            // same data — there is no second, divergent code path to
            // drift out of sync). Every other clickable element inside
            // the card (View Details itself, Book, WhatsApp) stops the
            // click from bubbling up to the card's own handler, so
            // clicking them does exactly what they already did — never a
            // double-open, never the wrong action.
            $_svc_popup_fit = in_array( $img_display['popup_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $img_display['popup_fit'] ?? 'cover' ) : 'cover';
        ?>
        <div class="gs-beauty-card" data-group="<?php echo esc_attr( $service['group'] ?? '' ); ?>"
             style="cursor:pointer" onclick="vsOpenDetailPopup(event,this)"
             data-title="<?php echo esc_attr( $service['name'] ); ?>"
             data-image="<?php echo esc_attr( $service['image'] ?? '' ); ?>"
             data-img-fit="<?php echo esc_attr( $_svc_popup_fit ); ?>"
             data-price="<?php echo esc_attr( $price_display ); ?>"
             data-sections="<?php echo esc_attr( wp_json_encode( $detail_sections ) ); ?>">
            <?php if ( ! empty( $service['image'] ) ): ?>
            <div class="gs-beauty-card-media">
                <img src="<?php echo esc_url( $service['image'] ); ?>" alt="<?php echo esc_attr( $service['name'] ); ?>" class="gs-beauty-card-img" loading="lazy" style="<?php echo esc_attr( $_img_style ); ?>">
                <?php if ( ! empty( $flags ) ): ?>
                <div class="gs-beauty-card-flags">
                    <?php foreach ( $flags as $_flag ): ?><span class="gs-beauty-flag"><?php echo esc_html( $_flag ); ?></span><?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <div class="gs-beauty-card-body">
                <div class="gs-beauty-card-name"><?php echo esc_html( $service['name'] ); ?></div>
                <?php if ( ! empty( $service['short_description'] ) ): ?><p class="gs-beauty-card-desc"><?php echo esc_html( $service['short_description'] ); ?></p><?php endif; ?>
                <div class="gs-beauty-card-meta">
                    <?php if ( $duration !== '' ): ?><span class="gs-beauty-card-duration">⏱ <?php echo esc_html( $duration ); ?></span><?php endif; ?>
                    <span class="gs-beauty-card-price"><?php echo esc_html( $price_display ); ?></span>
                </div>
                <div class="gs-beauty-card-ctas">
                    <a href="#" class="gs-beauty-cta-primary"
                       data-title="<?php echo esc_attr( $service['name'] ); ?>"
                       data-image="<?php echo esc_attr( $service['image'] ?? '' ); ?>"
                       data-img-fit="<?php echo esc_attr( $_svc_popup_fit ); ?>"
                       data-price="<?php echo esc_attr( $price_display ); ?>"
                       data-sections="<?php echo esc_attr( wp_json_encode( $detail_sections ) ); ?>"
                       onclick="event.preventDefault();event.stopPropagation();vsOpenDetailPopup(event,this)">View Details</a>
                    <?php if ( ! empty( $service['bookable'] ) ): ?>
                    <a href="#" class="gs-beauty-cta-secondary" onclick="event.preventDefault();event.stopPropagation();vsOpenInquiry({name:'<?php echo esc_js( $service['name'] ); ?>',type:'service',price:'<?php echo esc_js( $price_display ); ?>'})">Book</a>
                    <?php endif; ?>
                    <?php if ( $wa_clean !== '' ): ?><a href="https://wa.me/<?php echo esc_attr( $wa_clean ); ?>?text=<?php echo esc_attr( rawurlencode( 'Hi, I\'d like to know more about ' . $service['name'] ) ); ?>" target="_blank" rel="noopener" class="gs-beauty-cta-icon" title="WhatsApp" aria-label="WhatsApp about <?php echo esc_attr( $service['name'] ); ?>" onclick="event.stopPropagation()">💬</a><?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        </div>
    </div>
<?php
        return ob_get_clean();
    }

    /**
     * @param array $context {
     *     @type array  $services
     *     @type string $section_title
     *     @type string $section_description
     *     @type array  $img_display
     *     @type string $phone
     *     @type string $wa_clean
     * }
     */
    public static function render( array $context ): string {
        $html = self::render_grid(
            $context['services'] ?? [],
            (array) ( $context['img_display'] ?? [] ),
            (string) ( $context['phone'] ?? '' ),
            (string) ( $context['wa_clean'] ?? '' )
        );
        if ( $html === '' ) { return ''; } // Mandatory empty-state — Section 19 of the master build prompt.
        return self::render_title( $context['section_title'] ?? 'Beauty & Salon Services', $context['section_description'] ?? '' ) . $html;
    }
}
