<?php
namespace GoodService\Service;

use GoodService\Core\Cache;
use GoodService\Core\Config;
use GoodService\Core\EventBus;

final class SubscriptionService {

    /** The plan attributes a subscription snapshots at activation time — see
     * build_plan_snapshot() and get_active()'s "prefer snapshot" logic. Kept
     * as one list so both stay in sync with exactly the columns
     * get_active()'s live JOIN already selects. */
    public const SNAPSHOT_FIELDS = [
        'max_listings', 'max_photos', 'max_services',
        'show_phone', 'show_whatsapp', 'show_email', 'show_website',
        'show_analytics', 'show_seo_tools', 'priority_listing',
        'featured_badge', 'api_access', 'lead_notifications',
    ];

    /**
     * ENTERPRISE-AUDIT FIX (Part 2, High: plan versioning/grandfathering).
     * Reads the CURRENT (live) values of a plan's entitlement columns and
     * returns them as a JSON string, to be stored on the subscription row at
     * the moment it's created/activated/renewed. See every
     * $wpdb->insert(...'gs_subscriptions'...) call site across this class,
     * ManualPlanService, and AjaxController::adminGrantPlan() — each now
     * populates 'plan_snapshot' with this.
     */
    public static function build_plan_snapshot( int $plan_id ): string {
        global $wpdb;
        $cols = implode( ', ', self::SNAPSHOT_FIELDS );
        $plan = $wpdb->get_row( $wpdb->prepare(
            "SELECT {$cols} FROM {$wpdb->prefix}gs_subscription_plans WHERE id = %d", $plan_id
        ), ARRAY_A );
        return $plan ? wp_json_encode( $plan ) : '';
    }

    /** Get active subscription for a WP user ID. Returns null if none. */
    public static function get_active( int $user_id ): ?\stdClass {
        if ( ! $user_id ) { return null; }
        try {
        global $wpdb;
        return Cache::remember( "sub:active:{$user_id}", function() use ( $wpdb, $user_id ) {
            // Table existence check — prevents exceptions on fresh installs
            if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_vendor_profiles'" ) ) { return null; }
            // Find vendor profile id for this user
            $vendor_id = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}gs_vendor_profiles WHERE user_id = %d", $user_id
            ) );
            if ( ! $vendor_id ) { return null; }
            // Join subscription with plan to get plan feature columns.
            // status IN ('active','trialing') — NOT status='active' only. A
            // manually-assigned trial plan (ManualPlanService::activate() sets
            // status='trialing' for billing_cycle='trial') was previously
            // invisible here entirely: this method would return null, and every
            // feature gate / dashboard display built on top of it (gs_vendor_can(),
            // the subscription banner, etc.) would treat a vendor on an active
            // trial exactly the same as a vendor with no plan at all.
            $row = $wpdb->get_row( $wpdb->prepare(
                "SELECT s.*, p.max_listings, p.max_photos, p.max_services,
                        p.show_phone, p.show_whatsapp, p.show_email, p.show_website,
                        p.show_analytics, p.show_seo_tools, p.priority_listing,
                        p.featured_badge, p.api_access, p.lead_notifications
                 FROM {$wpdb->prefix}gs_subscriptions s
                 JOIN {$wpdb->prefix}gs_subscription_plans p ON p.id = s.plan_id
                 WHERE s.vendor_id = %d
                   AND s.status IN ('active','trialing')
                   AND ( s.expires_at IS NULL OR s.expires_at > NOW() )
                 ORDER BY s.created_at DESC LIMIT 1",
                $vendor_id
            ) ) ?: null;
            // ENTERPRISE-AUDIT FIX (Part 2, High: plan versioning/
            // grandfathering) — the query above always joins the LIVE plan
            // row (needed as the fallback for subscriptions created before
            // this fix, which have no snapshot yet). When a snapshot DOES
            // exist, it overrides those live-joined columns with the values
            // captured at the moment this specific subscription was
            // activated, so editing a plan afterward no longer silently
            // changes what an existing subscriber is entitled to or sees —
            // only a subscriber whose subscription is renewed/re-activated
            // (which re-snapshots — see build_plan_snapshot() call sites) or
            // whose plan an admin explicitly pushes changes to (see
            // AjaxController::adminPushPlanChanges()) picks up the new terms.
            if ( $row && ! empty( $row->plan_snapshot ) ) {
                $snap = json_decode( (string) $row->plan_snapshot, true );
                if ( is_array( $snap ) ) {
                    foreach ( $snap as $k => $v ) {
                        if ( property_exists( $row, $k ) ) { $row->$k = $v; }
                    }
                }
            }
            return $row;
        }, 60 );
        } catch ( \Throwable $e ) { return null; }
    }

    /**
     * Real policy change, explicit instruction: the plan limit is
     * enforced against the vendor's TOTAL stored/uploaded images across
     * their entire media library — not a scan of one listing's content
     * fields (the previous design). Simpler and matches what a vendor
     * actually sees when they open their Media Library: "45 images in
     * your library" and "X / limit used" must be the same number now,
     * not two different ones that happened to sit next to each other.
     *
     * Counts only actual images (file_type starting with "image/") —
     * documents (verification docs, View More Section PDFs/attachments)
     * were never part of the "photo" limit and still aren't.
     *
     * Renamed from get_listing_photo_usage() — that name was accurate
     * for the old per-listing design but would be actively misleading
     * now that this is vendor-wide; kept the old name here would be the
     * exact same class of bug as "Heading Colour" turning out to mean
     * something else entirely.
     *
     * @return array{used:int, limit:int, is_unlimited:bool, remaining:int}
     */
    public static function get_vendor_photo_usage( int $vendor_id ): array {
        global $wpdb;
        $sub = self::get_active( self::get_user_id_for_vendor( $vendor_id ) );
        $limit = $sub ? (int) ( $sub->max_photos ?? 30 ) : 10;
        // Real fix — matches the original enforcement's exact behavior:
        // treats any limit <= 0 as "not configured, don't enforce" (the
        // original code's `if ($max_photos > 0)` guard), not "zero
        // photos allowed." Only -1 was ever the explicit "unlimited"
        // sentinel elsewhere in this codebase, but 0 needs the same
        // practical treatment here to avoid a real behavior change.
        $is_unlimited = $limit <= 0;

        $used = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gs_media WHERE vendor_id = %d AND file_type LIKE %s",
            $vendor_id, 'image/%'
        ) );

        return [
            'used'         => $used,
            'limit'        => $limit,
            'is_unlimited' => $is_unlimited,
            'remaining'    => $is_unlimited ? -1 : max( 0, $limit - $used ),
        ];
    }

    /**
     * The one canonical list of upload contexts that DON'T consume a
     * vendor's photo quota. AjaxController::uploadMedia()'s enforcement
     * gate reads this exact list — nothing else in the codebase should
     * hardcode its own copy of "which upload types are exempt," or the
     * gate and the counter can drift apart again exactly like they did
     * before this fix. Now that the limit is the vendor's total stored
     * images, every image upload counts — 'document' is the one real
     * exception, since verification docs and View More Section
     * attachments were never "photos" and were never part of this limit.
     */
    public const QUOTA_EXEMPT_CONTEXTS = [ 'document' ];

    /**
     * Small helper — get_active() takes a WP user ID, but callers of
     * get_vendor_photo_usage() naturally have a vendor_id (the
     * gs_vendor_profiles row), matching every other function in this
     * codebase that works with listings. Resolves one to the other so
     * callers don't each need to know this distinction themselves.
     */
    private static function get_user_id_for_vendor( int $vendor_id ): int {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT user_id FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $vendor_id
        ) );
    }

    /** Get all active plans. */
    public static function get_plans(): array {
        global $wpdb;
        return Cache::remember( 'plans:all', function() use ( $wpdb ) {
            return $wpdb->get_results(
                "SELECT * FROM {$wpdb->prefix}gs_subscription_plans
                 WHERE is_active = 1 ORDER BY sort_order ASC, price_monthly ASC"
            ) ?: [];
        }, 3600 );
    }

    /** Check whether vendor has not exceeded listing limit. */
    public static function check_listing_limit( int $vendor_id ): bool {
        $sub = null;
        // Get sub by vendor_id directly
        global $wpdb;
        $user_id = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT user_id FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $vendor_id
        ) );
        if ( $user_id ) { $sub = self::get_active( $user_id ); }
        $limit = $sub ? (int) $sub->max_listings : 1;
        // M14 FIX: Exclude drafts from the count. A draft has not been submitted and
        // should not consume the vendor's listing quota. Only non-draft, non-rejected
        // listings count against the limit.
        $count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gs_listings
             WHERE vendor_id = %d AND status NOT IN ('draft','rejected')",
            $vendor_id
        ) );
        return $count < $limit;
    }

    /**
     * Create a subscription record. Returns subscription ID.
     *
     * @param string $source Provenance recorded on the row — 'purchased' (default,
     *                       self-service), 'system_default' (vendor's very first
     *                       plan, free), 'promotional'/'complimentary' for
     *                       non-standard free grants. Callers that bypass payment
     *                       must only ever pass this for a genuinely $0 price —
     *                       this method does not itself verify payment; the caller
     *                       (AjaxController::createSubscription()) is responsible
     *                       for gating any non-zero-price activation on a verified
     *                       payment BEFORE calling here.
     */
    public static function create( int $vendor_id, int $plan_id, string $billing_cycle, array $payment_data = [], string $source = 'purchased' ): int|false {
        global $wpdb;
        $plan = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_subscription_plans WHERE id = %d", $plan_id
        ) );
        if ( ! $plan ) { return false; }

        $price = match ( $billing_cycle ) {
            'yearly'     => (float) $plan->price_yearly,
            'quarterly'  => (float) $plan->price_quarterly,
            default      => (float) $plan->price_monthly,
        };
        $months = match ( $billing_cycle ) {
            'yearly'     => 12,
            'quarterly'  => 3,
            'lifetime'   => 1200,
            default      => 1,
        };

        // Root-cause fix — confirmed gap from full subscription-lifecycle audit:
        // this only ever cancelled an existing status='active' row before
        // inserting the new one. A vendor still on a 'trialing' subscription
        // who self-activates a (different) free-tier plan through this path —
        // AjaxController::createSubscription()'s free branch, the only caller
        // of this method — was left with BOTH the trialing row and the new
        // active row simultaneously matching status IN ('active','trialing'),
        // the exact duplicate-subscription-state bug already found and fixed
        // in the three sibling methods this one was never updated to match:
        // RazorpayService::activate_subscription(), ManualPlanService::activate(),
        // and AjaxController::adminGrantPlan(). Now cancels both, same pattern.
        $wpdb->update( $wpdb->prefix . 'gs_subscriptions',
            [ 'status' => 'cancelled', 'cancelled_at' => current_time( 'mysql' ) ],
            [ 'vendor_id' => $vendor_id, 'status' => 'active' ]
        );
        $wpdb->update( $wpdb->prefix . 'gs_subscriptions',
            [ 'status' => 'cancelled', 'cancelled_at' => current_time( 'mysql' ) ],
            [ 'vendor_id' => $vendor_id, 'status' => 'trialing' ]
        );

        // Ghost-success fix: $wpdb->insert_id is not reset to 0 on a failed
        // insert (it retains the last successful insert's id from earlier in
        // this request), so checking insert_id alone could not reliably detect
        // this specific insert failing on the core subscription-creation path.
        // Checked directly against insert()'s own return value instead.
        $inserted = $wpdb->insert( $wpdb->prefix . 'gs_subscriptions', [
            'vendor_id'      => $vendor_id,
            'plan_id'        => $plan_id,
            'plan_name'      => $plan->name,
            'billing_cycle'  => $billing_cycle,
            'amount'         => $price,
            'currency'       => Config::get( 'currency', 'INR' ),
            'status'         => 'active',
            'payment_method' => sanitize_text_field( $payment_data['method']     ?? '' ),
            'payment_id'     => sanitize_text_field( $payment_data['payment_id'] ?? '' ),
            'gateway'        => sanitize_text_field( $payment_data['gateway']    ?? '' ),
            'source'         => $source,
            'starts_at'      => current_time( 'mysql' ),
            'expires_at'     => date( 'Y-m-d H:i:s', strtotime( "+{$months} months" ) ),
            'auto_renew'     => 1,
            // ENTERPRISE-AUDIT FIX (Part 2, High: plan versioning/grandfathering).
            'plan_snapshot'  => self::build_plan_snapshot( $plan_id ),
            'created_at'     => current_time( 'mysql' ),
            'updated_at'     => current_time( 'mysql' ),
        ] );
        if ( ! $inserted ) { return false; }
        $sub_id = (int) $wpdb->insert_id;
        if ( ! $sub_id ) { return false; }

        // Invalidate cache
        $user_id = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT user_id FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $vendor_id
        ) );
        if ( $user_id ) { Cache::delete( "sub:active:{$user_id}" ); }

        EventBus::emit( 'subscription.created', [
            'subscription_id' => $sub_id,
            'vendor_id'       => $vendor_id,
            'plan_name'       => $plan->name,
        ] );

        return $sub_id;
    }

    /** Expire subscriptions past their end date. Called by cron/job queue. */
    /**
     * Expires every subscription past its expiry date — INCLUDING trialing
     * ones, which the original version of this method never caught at all
     * (it only matched status='active'). A trial's trial_ends_at/expires_at
     * passing would previously just sit there forever: never marked expired,
     * never downgraded, the vendor silently kept every trial-plan feature
     * indefinitely past the trial's actual end date.
     *
     * On expiry, each affected vendor is given a real, new 'active'
     * subscription on the platform's Free plan (looked up by slug='free')
     * — not just marked 'expired' with nothing replacing it. This is what
     * actually fulfills "downgrade to Free/Basic, inquiry module hidden,
     * stays there until a new plan is assigned" — gs_vendor_can() and every
     * other feature gate read the vendor's CURRENT active subscription's
     * plan_id, so without a real replacement row, a vendor with no active
     * subscription at all would behave inconsistently (effectively "no
     * plan" rather than the defined Free plan) across different parts of
     * the platform, rather than predictably landing on Free everywhere.
     */
    public static function expire_batch(): void {
        global $wpdb;
        $expired = $wpdb->get_results(
            "SELECT id, vendor_id FROM {$wpdb->prefix}gs_subscriptions
             WHERE status IN ('active','trialing') AND expires_at IS NOT NULL AND expires_at < NOW()"
        );
        if ( ! $expired ) { return; }

        $ids = array_map( fn( $r ) => (int) $r->id, $expired );
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->prefix}gs_subscriptions SET status='expired' WHERE id IN ({$placeholders})",
            ...$ids
        ) );

        // Downgrade every affected vendor to the Free plan via the shared helper —
        // guarantees identical behavior whether a subscription ends by expiry (here)
        // or by explicit vendor cancellation (see cancel() below).
        $vendor_ids = array_unique( array_map( fn( $r ) => (int) $r->vendor_id, $expired ) );
        $affected = $vendor_ids ? $wpdb->get_results( $wpdb->prepare(
            "SELECT vp.id AS vendor_id, vp.user_id FROM {$wpdb->prefix}gs_vendor_profiles vp WHERE vp.id IN (" .
            implode( ',', array_fill( 0, count( $vendor_ids ), '%d' ) ) . ')',
            ...$vendor_ids
        ) ) : [];

        foreach ( $affected as $row ) {
            self::downgrade_to_free( (int) $row->vendor_id, (int) $row->user_id, 'trial_or_subscription_expired' );
            // Real fix — confirmed gap from full admin-notification audit:
            // expiry never emitted any event at all, meaning neither the
            // vendor nor admin was ever notified when a subscription
            // simply lapsed rather than being explicitly cancelled.
            EventBus::emit( 'subscription.expired', [ 'vendor_id' => (int) $row->vendor_id, 'user_id' => (int) $row->user_id ] );
        }
    }

    /**
     * Explicit vendor-initiated cancellation. Unlike the previous version, this
     * now downgrades to Free via the exact same shared path expire_batch() uses —
     * a cancelled vendor is never left with zero active subscription rows.
     *
     * Without this, two different feature gates disagreed on what a cancelled
     * vendor could do: gs_vendor_can() (functions.php) returns false for every
     * single feature when get_active() returns null, while the vendor-site.php
     * listing-page gate only hides phone/email when an active row explicitly
     * sets show_phone/show_email to 0 — a null subscription satisfies neither
     * condition, so a cancelled vendor's contact info stayed fully visible on
     * their public page while their own dashboard showed every feature blocked.
     *
     * @return bool true if an active/trialing subscription was found and cancelled
     */
    public static function cancel( int $vendor_id, int $user_id ): bool {
        global $wpdb;
        // FIXED (re-audit follow-up, Gap A): this used to only flip status
        // and downgrade to Free — it never touched gs_invoices, never
        // recorded a payment_treatment, and never wrote a gs_activity_log
        // entry. adminCancelSubscription() requires an admin to explicitly
        // pick a payment treatment before it will even cancel; this
        // vendor-initiated path had no equivalent at all, meaning a vendor
        // self-cancelling a paid, active plan left the linked invoice
        // status='paid' forever — permanently counted as dashboard revenue —
        // with zero record that a cancellation had even happened.
        //
        // A vendor cancelling their OWN subscription cannot be trusted to
        // decide the financial outcome (refunded vs. kept) — that's the
        // platform's money, not theirs to characterize. So this does NOT
        // guess an invoice status. Instead it flags the subscription with
        // payment_treatment='pending_admin_review' (a 6th value, deliberately
        // not offered in adminCancelSubscription()'s/adminReclassifyPayment()'s
        // own admin-facing radio list — it only ever appears here, as a
        // marker meaning "no admin decision has been made yet") and writes a
        // real gs_activity_log entry so the cancellation is actually visible
        // and actionable — an admin can then use the existing "Fix Payment
        // Status" tool to resolve it the same way as any other correction.
        $sub = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, amount FROM {$wpdb->prefix}gs_subscriptions WHERE vendor_id = %d AND status IN ('active','trialing') ORDER BY created_at DESC LIMIT 1",
            $vendor_id
        ) );
        if ( ! $sub ) { return false; }

        $wpdb->update(
            $wpdb->prefix . 'gs_subscriptions',
            [
                'status'            => 'cancelled',
                'cancelled_at'      => current_time( 'mysql' ),
                'cancel_reason'     => 'vendor_self_cancelled',
                'payment_treatment' => (float) $sub->amount > 0 ? 'pending_admin_review' : null,
                'updated_at'        => current_time( 'mysql' ),
            ],
            [ 'vendor_id' => $vendor_id, 'status' => 'active' ]
        );
        $wpdb->update(
            $wpdb->prefix . 'gs_subscriptions',
            [
                'status'            => 'cancelled',
                'cancelled_at'      => current_time( 'mysql' ),
                'cancel_reason'     => 'vendor_self_cancelled',
                'payment_treatment' => (float) $sub->amount > 0 ? 'pending_admin_review' : null,
                'updated_at'        => current_time( 'mysql' ),
            ],
            [ 'vendor_id' => $vendor_id, 'status' => 'trialing' ]
        );

        if ( (float) $sub->amount > 0 && function_exists( 'gs_log_activity' ) ) {
            gs_log_activity(
                'vendor_self_cancel_subscription', 'subscription', (int) $sub->id,
                sprintf(
                    'Vendor #%d cancelled their own subscription #%d (%s) — flagged payment_treatment=pending_admin_review since a vendor cannot decide their own refund outcome. Needs admin review via "Fix Payment Status".',
                    $vendor_id, (int) $sub->id, gs_format_price( (float) $sub->amount )
                )
            );
        }

        self::downgrade_to_free( $vendor_id, $user_id, 'vendor_cancelled' );

        EventBus::emit( 'subscription.cancelled', [ 'vendor_id' => $vendor_id, 'user_id' => $user_id ] );
        return true;
    }

    /**
     * ENTERPRISE-AUDIT FIX (Part 2, High — dunning cascade): starts (or, on a
     * repeat failure during an already-running grace period, just records)
     * dunning for a vendor's currently-active subscription. Called from both
     * gateway webhook handlers (RestApiController::razorpay_webhook()/
     * stripe_webhook(), case 'payment.failed') so Razorpay and Stripe share
     * one dunning implementation rather than each growing its own.
     *
     * Deliberately only ever touches the CURRENTLY ACTIVE subscription row —
     * never trialing (a failed trial-card charge is handled by the existing
     * trial-ending flow, not this one) — and only initializes the grace clock
     * once per dunning episode: a second, third, etc. failed retry within the
     * same grace period updates last_payment_failed_at (so admins/vendor see
     * the most recent failure) without resetting dunning_grace_until, which
     * would let a vendor whose card keeps failing indefinitely postpone
     * ever reaching a resolution.
     */
    public static function start_or_touch_dunning( int $vendor_id ): void {
        if ( ! $vendor_id ) { return; }
        global $wpdb;
        $sub = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, dunning_stage FROM {$wpdb->prefix}gs_subscriptions WHERE vendor_id = %d AND status = 'active' ORDER BY id DESC LIMIT 1",
            $vendor_id
        ) );
        if ( ! $sub ) { return; } // nothing active to dun (already free/trialing/cancelled)

        if ( (int) $sub->dunning_stage > 0 ) {
            // Already mid-grace-period — just record the repeat failure.
            $wpdb->update( $wpdb->prefix . 'gs_subscriptions',
                [ 'last_payment_failed_at' => current_time( 'mysql' ) ],
                [ 'id' => (int) $sub->id ]
            );
            return;
        }

        $grace_days = max( 1, (int) Config::get( 'dunning_grace_days', 7 ) );
        $wpdb->update( $wpdb->prefix . 'gs_subscriptions', [
            'dunning_stage'          => 1,
            'dunning_started_at'     => current_time( 'mysql' ),
            'dunning_grace_until'    => date( 'Y-m-d H:i:s', strtotime( "+{$grace_days} days" ) ),
            'last_payment_failed_at' => current_time( 'mysql' ),
        ], [ 'id' => (int) $sub->id ] );
    }

    /**
     * Shared Free-plan downgrade — the single source of truth for "this vendor
     * no longer has a paid subscription, give them a real Free-plan row instead
     * of leaving them with none." Called by both expire_batch() and cancel().
     */
    public static function downgrade_to_free( int $vendor_id, int $user_id, string $reason ): void {
        global $wpdb;
        if ( $user_id ) { Cache::delete( "sub:active:{$user_id}" ); }

        // FIXED — Issue 5: "which plan is Free" was pure slug=='free' convention;
        // now prefers the explicit is_default=1 flag (see Schema::upgrade_columns()
        // and AjaxController::deletePlan()/togglePlan(), which guard against
        // removing/hiding the is_default plan without a replacement). slug='free'
        // is kept as a backward-compatible fallback for sites where no plan has
        // been marked is_default yet.
        $free_plan = $wpdb->get_row(
            "SELECT id, name FROM {$wpdb->prefix}gs_subscription_plans WHERE is_default = 1 AND is_active = 1 LIMIT 1"
        );
        if ( ! $free_plan ) {
            $free_plan = $wpdb->get_row(
                "SELECT id, name FROM {$wpdb->prefix}gs_subscription_plans WHERE slug = 'free' AND is_active = 1 LIMIT 1"
            );
        }
        if ( ! $free_plan ) {
            gs_write_log( "SubscriptionService::downgrade_to_free: no is_default/slug=free plan found — vendor #{$vendor_id} left with NO active subscription row (reason={$reason}).", 'ERROR' );
            return;
        }

        // Guard against a double-insert if this vendor somehow already has a
        // live subscription (e.g. this running twice before a lock clears, or
        // cancel() and expire_batch() racing on the same vendor).
        $already_has_live_sub = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gs_subscriptions WHERE vendor_id = %d AND status IN ('active','trialing')",
            $vendor_id
        ) );
        if ( $already_has_live_sub ) { return; }

        $inserted = $wpdb->insert( $wpdb->prefix . 'gs_subscriptions', [
            'vendor_id'     => $vendor_id,
            'plan_id'       => $free_plan->id,
            'plan_name'     => $free_plan->name,
            'billing_cycle' => 'monthly',
            'amount'        => 0.00,
            'currency'      => Config::get( 'currency', 'INR' ),
            'status'        => 'active',
            'payment_method'=> 'auto_downgrade',
            'gateway'       => 'system',
            'source'        => 'system_default',
            'gateway_data'  => wp_json_encode( [ 'reason' => $reason, 'downgraded_at' => current_time( 'mysql' ) ] ),
            'starts_at'     => current_time( 'mysql' ),
            'expires_at'    => null, // Free plan doesn't expire on its own
            // ENTERPRISE-AUDIT FIX (Part 2, High: plan versioning/grandfathering).
            'plan_snapshot' => self::build_plan_snapshot( (int) $free_plan->id ),
            'created_at'    => current_time( 'mysql' ),
            'updated_at'    => current_time( 'mysql' ),
        ] );

        // Root-cause fix — confirmed ghost-success gap from full subscription-
        // lifecycle audit: this insert's return value was previously discarded.
        // downgrade_to_free() is the single shared path expire_batch(), cancel(),
        // and check_trial_endings() all rely on to guarantee a vendor never ends
        // up with NO active subscription row after their paid/trial plan ends.
        // If this specific insert silently failed (duplicate key race, DB
        // pressure, etc.), the caller had no way to know — the vendor would be
        // left exactly in the "no plan at all" state this method exists to
        // prevent, with sync_featured_status() below still running against
        // stale data as if the downgrade had succeeded.
        if ( ! $inserted ) {
            gs_write_log( "SubscriptionService::downgrade_to_free: INSERT of Free-plan subscription row failed for vendor #{$vendor_id} (reason={$reason}): " . $wpdb->last_error, 'ERROR' );
            return;
        }

        // Real fix: without this, a vendor who was featured because a
        // higher-tier plan included it would stay featured indefinitely
        // after downgrading to free — the exact "one-time subscription
        // grants permanent benefit" bug this sync exists to prevent.
        self::sync_featured_status( $vendor_id );
    }

    /**
     * Real feature — closes a confirmed gap: subscription_plans.is_featured
     * existed as pure marketing data with zero code ever reading it.
     * Looks up the vendor's current active plan directly from
     * gs_subscriptions (not trusted from any event payload, which was
     * confirmed to differ in shape between the gateway and manual
     * activation paths) and syncs their listings' featured status to
     * match — both granting AND revoking, so this is never a one-time,
     * permanent benefit from a plan the vendor no longer holds.
     * Known, deliberate trade-off: this does not distinguish "featured
     * because the current plan includes it" from "featured via an
     * admin's manual bulk-action override for an unrelated reason" —
     * there's no column tracking why a listing is featured. A vendor
     * manually featured by an admin, who then triggers a subscription
     * sync (e.g. a renewal on a plan without is_featured), would have
     * that manual feature revoked. This is a real, narrow edge case,
     * accepted deliberately rather than building a full featured-source
     * tracking system for a Medium-priority gap — the alternative
     * (doing nothing) leaves the strictly worse problem of permanent
     * stale featuring after any downgrade, for every vendor, always.
     */
    public static function sync_featured_status( int $vendor_id ): void {
        if ( ! $vendor_id ) { return; }
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $should_be_featured = (bool) $wpdb->get_var( $wpdb->prepare(
            "SELECT sp.is_featured FROM {$pfx}subscriptions s
             JOIN {$pfx}subscription_plans sp ON sp.id = s.plan_id
             WHERE s.vendor_id = %d AND s.status IN ('active','trialing')
             ORDER BY s.id DESC LIMIT 1",
            $vendor_id
        ) );

        $wpdb->update( $pfx . 'listings', [ 'is_featured' => $should_be_featured ? 1 : 0 ], [ 'vendor_id' => $vendor_id ] );

        gs_write_log( "SubscriptionService::sync_featured_status — vendor #{$vendor_id} featured status set to " . ( $should_be_featured ? '1' : '0' ) . ' based on current plan.', 'INFO' );
    }
}
