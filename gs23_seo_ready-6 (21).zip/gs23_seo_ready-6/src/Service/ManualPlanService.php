<?php
namespace GoodService\Service;

use GoodService\Core\Cache;
use GoodService\Core\Config;
use GoodService\Core\EventBus;
use GoodService\Core\Helpers;

/**
 * ManualPlanService — Manual Subscription Management & Offline Payment Approval.
 *
 * Composes with (does NOT replace) the existing SubscriptionService / BillingService:
 *   - Activation still goes through SubscriptionService::create() so caching,
 *     EventBus 'subscription.created' (→ invoice generation), and the
 *     gs_subscriptions table stay the single source of truth for "what plan
 *     is active right now".
 *   - gs_plan_requests / gs_plan_request_payments are the offline-payment
 *     paper trail: who asked for what, what they paid, who approved it.
 *
 * Status lifecycle (gs_plan_requests.status):
 *   draft → pending → under_review → payment_verification_pending → info_required
 *         → on_hold → approved → completed
 *                    → rejected
 *                    → expired
 *                    → cancelled
 * (info_required / on_hold / payment_verification_pending can loop back to pending/under_review)
 */
final class ManualPlanService {

    /** Set by any method that can fail; read by callers (AjaxController) to surface a message. */
    public static string $last_error = '';

    /** Set on success-with-a-caveat (e.g. saved but a follow-up step needs admin attention).
     *  Unlike $last_error, this is never paired with a `false` return value. */
    public static string $last_warning = '';

    /** Billing-cycle keyword → number of months. 'custom' is resolved by caller via custom_months. */
    public const CYCLE_MONTHS = [
        'trial'       => 0,   // handled specially — uses trial_days setting
        'trial_3m'    => 3,   // 3-Month Trial (₹0) — fixed duration, see is_trial_cycle()
        'trial_6m'    => 6,   // 6-Month Trial (₹0) — fixed duration, see is_trial_cycle()
        'monthly'     => 1,
        'quarterly'   => 3,
        'half_yearly' => 6,
        'annual'      => 12,
        'lifetime'    => 1200, // ~100 years, matches existing "lifetime" convention in SubscriptionService
        'custom'      => 0,   // resolved from custom_months
    ];

    /**
     * Identifies any billing cycle that should result in status='trialing'
     * (free trial period, with trial_ends_at populated) rather than a normal
     * paid status='active' subscription. Used at every point that previously
     * checked billing_cycle === 'trial' literally, so adding a future named
     * trial duration only ever requires one line changed here.
     */
    public static function is_trial_cycle( string $cycle ): bool {
        return $cycle === 'trial' || str_starts_with( $cycle, 'trial_' );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Vendor search (Admin Dashboard → Manual Plan Management)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Search vendors by name, business name, email, mobile, vendor ID, or GST number.
     * Reuses gs_vendor_profiles / wp users — no new table needed for search.
     */
    public static function search_vendors( string $term, int $limit = 20 ): array {
        global $wpdb;
        self::$last_error = '';
        $term = trim( $term );
        if ( $term === '' ) { return []; }

        $like = '%' . $wpdb->esc_like( $term ) . '%';
        $is_numeric_id = ctype_digit( $term );

        // FIXED (bug report follow-up): this only ever matched the vendor's
        // business_name/email/phone/gst_number — a listing's own title
        // (gs_listings.title) is a genuinely separate field a vendor sets per
        // listing and can differ from their registered business name.
        // Reported gap: "i searched by listing name ... nothing comes up" —
        // confirmed by reading the query, which had no reference to
        // gs_listings at all. Added as an EXISTS clause so a vendor with
        // ANY listing whose title matches is now found too.
        $where  = "(vp.business_name LIKE %s OR vp.email LIKE %s OR vp.phone LIKE %s
                     OR vp.gst_number LIKE %s OR u.user_email LIKE %s
                     OR EXISTS ( SELECT 1 FROM {$wpdb->prefix}gs_listings gl WHERE gl.vendor_id = vp.id AND gl.title LIKE %s ))";
        $params = [ $like, $like, $like, $like, $like, $like ];

        if ( $is_numeric_id ) {
            $where  = "(vp.id = %d OR {$where})";
            $params = array_merge( [ (int) $term ], $params );
        }

        // FIXED (root-caused live with a real MySQL reproduction, not a guess —
        // this codebase's own DiagnosticsEngine.php already documents "orphaned"
        // gs_vendor_profiles rows — vp.user_id pointing at a WP user that no
        // longer exists — as a real, occurring condition on this platform, with
        // a suggested cleanup query. The old `JOIN {$wpdb->prefix}users` (INNER
        // JOIN) silently drops every such vendor from this search entirely, for
        // EVERY search term, because the join itself never matches — proven with
        // a live test DB: an otherwise-matching vendor row with a dangling
        // user_id returned 0 rows under INNER JOIN and 1 row under LEFT JOIN
        // against the identical query and data. This exactly explains "I search
        // any terms/options to search the vendor, it gives no results" if the
        // live site's vendor accounts have drifted from wp_users (a stale
        // staging/live sync, a partial user import/cleanup, etc.) — every vendor
        // becomes permanently unsearchable, not just some. Changed to LEFT JOIN
        // so a vendor with no resolvable WP user account is still findable (an
        // admin needs exactly this case to be visible, in order to fix it), with
        // COALESCE(u.user_email, vp.email) so the result row still shows a
        // usable email instead of blank/null when there is no matched user.
        // VendorRepository::admin_list() (main Vendors screen) has the identical
        // INNER JOIN and was changed the same way for consistency — see there.
        $sql = $wpdb->prepare(
            "SELECT vp.id AS vendor_id, vp.business_name, vp.email, vp.phone, vp.gst_number,
                    vp.city, vp.state, vp.verification_status, vp.is_active,
                    u.ID AS user_id, COALESCE(u.user_email, vp.email) AS user_email, u.display_name,
                    sub.plan_name AS current_plan, sub.status AS sub_status, sub.expires_at AS sub_expires,
                    ( SELECT gl.title FROM {$wpdb->prefix}gs_listings gl WHERE gl.vendor_id = vp.id AND gl.title LIKE %s ORDER BY gl.id ASC LIMIT 1 ) AS matched_listing
             FROM {$wpdb->prefix}gs_vendor_profiles vp
             LEFT JOIN {$wpdb->prefix}users u ON u.ID = vp.user_id
             LEFT JOIN {$wpdb->prefix}gs_subscriptions sub
                    ON sub.id = (
                        SELECT id FROM {$wpdb->prefix}gs_subscriptions
                        WHERE vendor_id = vp.id AND status IN ('active','trialing')
                        ORDER BY created_at DESC LIMIT 1
                    )
             WHERE {$where}
             ORDER BY vp.business_name ASC
             LIMIT %d",
            // The matched_listing subquery's %s is the FIRST placeholder to
            // appear in the SQL string (it's in the SELECT list, before
            // WHERE), so its value must be prepended here — $wpdb->prepare()
            // binds positionally in string order, not by array key.
            ...array_merge( [ $like ], $params, [ $limit ] )
        );
        $result = $wpdb->get_results( $sql );
        // FIXED: previously `?: []` swallowed a genuine SQL error (bad column,
        // collation clash, a table not yet migrated) into the exact same shape
        // as "zero real matches" — an admin (and this developer, on the first
        // pass) cannot tell "no such vendor" from "the query itself is broken"
        // when both silently render "No vendors found." Surfacing $wpdb->last_error
        // via self::$last_error lets the AJAX handler return the real reason.
        if ( $result === null && $wpdb->last_error ) {
            self::$last_error = $wpdb->last_error;
        }
        $rows = $result ?: [];

        return $rows;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Pricing computation — shared by vendor request + admin assignment
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Resolve the (list_price, final_amount) pair for a plan + cycle + discount config.
     * Pure function — no DB writes. Used by both create_request() and admin_assign().
     */
    public static function compute_pricing( \stdClass $plan, string $cycle, int $custom_months, ?float $override_price, string $discount_type, float $discount_value ): array {
        if ( $override_price !== null ) {
            $list_price = $override_price;
        } else {
            $list_price = match ( $cycle ) {
                'annual'     => (float) ( $plan->price_yearly ?: $plan->price_monthly * 12 ),
                'quarterly'  => (float) ( $plan->price_quarterly ?: $plan->price_monthly * 3 ),
                'half_yearly'=> (float) ( $plan->price_monthly * 6 ),
                'trial', 'trial_3m', 'trial_6m' => 0.00,
                'lifetime'   => (float) ( $plan->price_yearly ?: $plan->price_monthly * 12 ) * 5,
                'custom'     => (float) $plan->price_monthly * max( 1, $custom_months ),
                default      => (float) $plan->price_monthly, // monthly
            };
        }

        $discount_amount = match ( $discount_type ) {
            'percentage'          => round( $list_price * min( 100, max( 0, $discount_value ) ) / 100, 2 ),
            'fixed', 'coupon_equivalent', 'credit_adjustment' => min( $list_price, max( 0, $discount_value ) ),
            'complimentary', 'staff' => $list_price, // 100% off
            default               => 0.00, // 'none'
        };

        $final_amount = max( 0, round( $list_price - $discount_amount, 2 ) );

        return [
            'list_price'      => round( $list_price, 2 ),
            'discount_amount' => $discount_amount,
            'final_amount'    => $final_amount,
        ];
    }

    /** Resolve activation_date + expiry_date for a cycle, honouring custom_months and grace_period_days. */
    public static function compute_dates( string $cycle, int $custom_months, ?string $activation_date = null ): array {
        $start = $activation_date ? strtotime( $activation_date ) : current_time( 'timestamp' );
        if ( $start === false ) { $start = current_time( 'timestamp' ); }

        if ( $cycle === 'trial' ) {
            $trial_days = (int) Config::get( 'manual_plan_trial_days', 14 );
            $expiry = strtotime( "+{$trial_days} days", $start );
        } elseif ( $cycle === 'custom' ) {
            $months = max( 1, $custom_months );
            $expiry = strtotime( "+{$months} months", $start );
        } else {
            $months = self::CYCLE_MONTHS[ $cycle ] ?? 1;
            $expiry = strtotime( "+{$months} months", $start );
        }

        return [
            'activation_date' => date( 'Y-m-d H:i:s', $start ),
            'expiry_date'     => date( 'Y-m-d H:i:s', $expiry ),
        ];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Vendor-side: create / save-draft a plan request with offline payment info
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Create (or update an existing draft) plan request from the vendor dashboard.
     * $data keys: plan_id, billing_cycle, custom_months, payment_mode, transaction_id,
     *             utr_number, cheque_number, bank_name, bank_branch, payment_date,
     *             reference_number, amount_paid, note, payment_proof_ids (array of media IDs),
     *             is_draft (bool), draft_id (int, optional — update an existing draft).
     * Returns the request_id on success, false on failure (false is always paired with
     * a caller-visible error set via self::$last_error before returning).
     */
    public static function create_request( int $vendor_id, array $data ): int|false {
        global $wpdb;
        self::$last_error = ''; self::$last_warning = '';

        $plan_id = (int) ( $data['plan_id'] ?? 0 );
        $plan = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_subscription_plans WHERE id = %d AND is_active = 1", $plan_id
        ) );
        if ( ! $plan ) { self::$last_error = 'Plan not found or no longer available.'; return false; }

        $cycle         = self::sanitize_cycle( $data['billing_cycle'] ?? 'monthly' );
        $custom_months = max( 0, (int) ( $data['custom_months'] ?? 0 ) );
        $is_draft      = ! empty( $data['is_draft'] );

        $pricing = self::compute_pricing( $plan, $cycle, $custom_months, null, 'none', 0.0 );

        $row = [
            'vendor_id'         => $vendor_id,
            'plan_id'           => $plan_id,
            'plan_name'         => $plan->name,
            'source'            => 'vendor_request',
            'status'            => $is_draft ? 'draft' : 'pending',
            'billing_cycle'     => $cycle,
            'custom_months'     => $custom_months,
            'list_price'        => $pricing['list_price'],
            'final_amount'      => $pricing['final_amount'],
            'amount_paid'       => max( 0.0, (float) ( $data['amount_paid'] ?? 0 ) ),
            'currency'          => Config::get( 'currency', 'INR' ),
            'payment_mode'      => self::clamp( sanitize_text_field( $data['payment_mode']      ?? '' ), 30 ),
            'transaction_id'    => self::clamp( sanitize_text_field( $data['transaction_id']    ?? '' ), 120 ),
            'utr_number'        => self::clamp( sanitize_text_field( $data['utr_number']        ?? '' ), 60 ),
            'cheque_number'     => self::clamp( sanitize_text_field( $data['cheque_number']     ?? '' ), 40 ),
            'bank_name'         => self::clamp( sanitize_text_field( $data['bank_name']         ?? '' ), 120 ),
            'bank_branch'       => self::clamp( sanitize_text_field( $data['bank_branch']       ?? '' ), 120 ),
            'payment_date'      => self::sanitize_date( $data['payment_date'] ?? '' ),
            'reference_number'  => self::clamp( sanitize_text_field( $data['reference_number']  ?? '' ), 100 ),
            'payment_proof_ids' => self::encode_ids( $data['payment_proof_ids'] ?? [] ),
            'note'              => sanitize_textarea_field( $data['note'] ?? '' ),
            'updated_at'        => current_time( 'mysql' ),
        ];
        $row['balance_due'] = max( 0, round( $row['final_amount'] - $row['amount_paid'], 2 ) );

        $draft_id = (int) ( $data['draft_id'] ?? 0 );

        if ( $draft_id ) {
            // Updating an existing draft (or resubmitting after info_required) — must belong to this vendor.
            $existing = $wpdb->get_row( $wpdb->prepare(
                "SELECT id, status FROM {$wpdb->prefix}gs_plan_requests WHERE id = %d AND vendor_id = %d AND is_deleted = 0",
                $draft_id, $vendor_id
            ) );
            if ( ! $existing ) { self::$last_error = 'Draft not found.'; return false; }
            if ( ! in_array( $existing->status, [ 'draft', 'info_required' ], true ) ) {
                self::$last_error = 'This request can no longer be edited.';
                return false;
            }
            $ok = $wpdb->update( $wpdb->prefix . 'gs_plan_requests', $row, [ 'id' => $draft_id ] );
            if ( $ok === false ) { self::$last_error = 'Could not update your request. Please try again.'; return false; }
            $request_id = $draft_id;
        } else {
            // Cancel any prior NON-TERMINAL request for this vendor (one active
            // request at a time). Originally only checked status='pending', which
            // missed under_review/payment_verification_pending/info_required/on_hold —
            // a vendor could click "Get Plan" on a card while an info_required
            // request from a previous attempt was still open, leaving it orphaned
            // forever instead of being superseded by the new submission.
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->prefix}gs_plan_requests
                 SET status = 'cancelled', cancelled_at = %s
                 WHERE vendor_id = %d AND is_deleted = 0
                   AND status IN ('pending','under_review','payment_verification_pending','info_required','on_hold')",
                current_time( 'mysql' ), $vendor_id
            ) );
            $row['created_at'] = current_time( 'mysql' );
            $ok = $wpdb->insert( $wpdb->prefix . 'gs_plan_requests', $row );
            if ( $ok === false ) { self::$last_error = 'Could not save your request. Please try again.'; return false; }
            $request_id = (int) $wpdb->insert_id;
        }

        if ( ! $is_draft ) {
            self::log( $request_id, $vendor_id, 'request.submitted', get_current_user_id(), null, $row );
            // NotificationService::notify_admins (not Helpers::notify_admins) — covers
            // gs_manager/gs_moderator too, not just 'administrator'. Those roles are the
            // ones who actually work the Manual Plans queue (is_admin_level() includes them).
            NotificationService::notify_admins(
                'plan_request.submitted',
                '📋 Plan Request — ' . $plan->name,
                'A vendor submitted an offline-payment request for the "' . $plan->name . '" plan.',
                home_url( '/admin-panel/?section=plan-requests' )
            );
        }

        return $request_id;
    }

    /** Vendor cancels their own pending/draft/info_required request. */
    public static function vendor_cancel( int $request_id, int $vendor_id ): bool {
        self::$last_error = ''; self::$last_warning = '';
        global $wpdb;
        $req = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_plan_requests WHERE id = %d AND vendor_id = %d AND is_deleted = 0",
            $request_id, $vendor_id
        ) );
        if ( ! $req ) { self::$last_error = 'Request not found.'; return false; }
        if ( ! in_array( $req->status, [ 'draft', 'pending', 'under_review', 'info_required', 'on_hold' ], true ) ) {
            self::$last_error = 'This request can no longer be cancelled.';
            return false;
        }
        $__gs_cancel = $wpdb->update( $wpdb->prefix . 'gs_plan_requests',
            [ 'status' => 'cancelled', 'cancelled_at' => current_time( 'mysql' ) ],
            [ 'id' => $request_id ]
        );
        if ( $__gs_cancel === false ) { self::$last_error = 'Could not cancel your request. Please try again.'; return false; }
        self::log( $request_id, $vendor_id, 'request.cancelled_by_vendor', get_current_user_id(), $req->status, 'cancelled' );
        return true;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Admin-side: direct assignment (no vendor request needed)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Admin assigns a plan directly to a vendor. Creates a plan_request row with
     * source='admin_assigned' and status='approved' in the same call (admin assignment
     * is its own approval), then immediately activates the subscription — unless
     * $data['schedule_future'] is set, in which case it stays 'approved' with a future
     * activation_date and the cron will activate it (see Cron::activate_scheduled_manual_plans).
     */
    public static function admin_assign( int $vendor_id, array $data, int $admin_id ): int|false {
        global $wpdb;
        self::$last_error = ''; self::$last_warning = '';

        $plan_id = (int) ( $data['plan_id'] ?? 0 );
        $plan = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_subscription_plans WHERE id = %d", $plan_id
        ) );
        if ( ! $plan ) { self::$last_error = 'Plan not found.'; return false; }

        $vendor = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, user_id, business_name FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $vendor_id
        ) );
        if ( ! $vendor ) { self::$last_error = 'Vendor not found.'; return false; }

        $cycle          = self::sanitize_cycle( $data['billing_cycle'] ?? 'monthly' );
        $custom_months  = max( 0, (int) ( $data['custom_months'] ?? 0 ) );
        $override_price = isset( $data['override_price'] ) && $data['override_price'] !== ''
            ? max( 0.0, (float) $data['override_price'] ) : null;
        $discount_type  = self::sanitize_discount_type( $data['discount_type'] ?? 'none' );
        $discount_value = (float) ( $data['discount_value'] ?? 0 );

        $pricing = self::compute_pricing( $plan, $cycle, $custom_months, $override_price, $discount_type, $discount_value );

        $schedule_future = ! empty( $data['schedule_future'] ) && ! empty( $data['activation_date'] );
        $dates = self::compute_dates( $cycle, $custom_months, $schedule_future ? $data['activation_date'] : null );

        $amount_paid = max( 0.0, (float) ( $data['amount_paid'] ?? $pricing['final_amount'] ) ); // default: fully paid
        $balance_due = max( 0, round( $pricing['final_amount'] - $amount_paid, 2 ) );

        $row = [
            'vendor_id'         => $vendor_id,
            'plan_id'           => $plan_id,
            'plan_name'         => $plan->name,
            'source'            => 'admin_assigned',
            'status'            => $schedule_future ? 'on_hold' : 'approved',
            'billing_cycle'     => $cycle,
            'custom_months'     => $custom_months,
            'activation_date'   => $dates['activation_date'],
            'expiry_date'       => $dates['expiry_date'],
            'grace_period_days' => max( 0, (int) ( $data['grace_period_days'] ?? 0 ) ),
            'auto_expiry'       => empty( $data['auto_expiry'] ) ? 0 : 1,
            'list_price'        => $pricing['list_price'],
            'override_price'    => $override_price,
            'discount_type'     => $discount_type,
            'discount_value'    => $discount_value,
            'discount_reason'   => self::clamp( sanitize_text_field( $data['discount_reason'] ?? '' ), 255 ),
            'final_amount'      => $pricing['final_amount'],
            'amount_paid'       => $amount_paid,
            'balance_due'       => $balance_due,
            'currency'          => Config::get( 'currency', 'INR' ),
            'payment_mode'      => self::clamp( sanitize_text_field( $data['payment_mode']     ?? '' ), 30 ),
            'transaction_id'    => self::clamp( sanitize_text_field( $data['transaction_id']   ?? '' ), 120 ),
            'utr_number'        => self::clamp( sanitize_text_field( $data['utr_number']       ?? '' ), 60 ),
            'cheque_number'     => self::clamp( sanitize_text_field( $data['cheque_number']    ?? '' ), 40 ),
            'bank_name'         => self::clamp( sanitize_text_field( $data['bank_name']        ?? '' ), 120 ),
            'bank_branch'       => self::clamp( sanitize_text_field( $data['bank_branch']      ?? '' ), 120 ),
            'payment_date'      => self::sanitize_date( $data['payment_date'] ?? '' ),
            'reference_number'  => self::clamp( sanitize_text_field( $data['reference_number'] ?? '' ), 100 ),
            'payment_proof_ids' => self::encode_ids( $data['payment_proof_ids'] ?? [] ),
            'internal_notes'    => sanitize_textarea_field( $data['internal_notes'] ?? '' ),
            'admin_note'        => sanitize_textarea_field( $data['admin_note'] ?? '' ),
            'assigned_by'       => $admin_id,
            'approved_by'       => $admin_id,
            'approved_at'       => current_time( 'mysql' ),
            'created_at'        => current_time( 'mysql' ),
            'updated_at'        => current_time( 'mysql' ),
        ];

        $ok = $wpdb->insert( $wpdb->prefix . 'gs_plan_requests', $row );
        if ( $ok === false ) { self::$last_error = 'Could not save the assignment record.'; return false; }
        $request_id = (int) $wpdb->insert_id;

        self::log( $request_id, $vendor_id, 'request.admin_assigned', $admin_id, null, $row );

        if ( $amount_paid > 0 ) {
            self::record_payment( $request_id, $vendor_id, [
                'amount'         => $amount_paid,
                'payment_mode'   => $row['payment_mode'],
                'transaction_id' => $row['transaction_id'],
                'utr_number'     => $row['utr_number'],
                'cheque_number'  => $row['cheque_number'],
                'bank_name'      => $row['bank_name'],
                'bank_branch'    => $row['bank_branch'],
                'payment_date'   => $row['payment_date'],
                'proof_ids'      => $data['payment_proof_ids'] ?? [],
                'status'         => 'verified', // admin-entered payment is self-verified
            ], $admin_id, true );
        }

        if ( $schedule_future ) {
            // Stays on_hold; Cron picks it up on/after activation_date.
            self::notify_vendor_scheduled( $vendor, $plan, $dates['activation_date'] );
            return $request_id;
        }

        $sub_id = self::activate( $request_id, $admin_id );
        if ( $sub_id === false ) {
            // Activation record failed but the request row exists — surface for admin follow-up.
            // This is a WARNING, not an error: the assignment itself succeeded (the row was
            // saved), so callers must NOT treat this as a `false` return — only $last_error
            // (left untouched here) signals failure.
            self::$last_warning = self::$last_error ?: 'Assignment saved but activation failed. Check the request and retry activation.';
            self::$last_error = '';
            return $request_id; // request exists; admin can retry activation from the queue
        }

        return $request_id;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Admin approval workflow actions
    // ─────────────────────────────────────────────────────────────────────────

    public static function set_status( int $request_id, string $new_status, int $admin_id, string $admin_note = '' ): bool {
        self::$last_error = ''; self::$last_warning = '';
        global $wpdb;
        $valid = [ 'under_review', 'payment_verification_pending', 'info_required', 'on_hold', 'rejected', 'cancelled' ];
        if ( ! in_array( $new_status, $valid, true ) ) { self::$last_error = 'Invalid status.'; return false; }

        $req = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}gs_plan_requests WHERE id = %d", $request_id ) );
        if ( ! $req ) { self::$last_error = 'Request not found.'; return false; }

        $update = [ 'status' => $new_status, 'updated_at' => current_time( 'mysql' ) ];
        if ( $admin_note !== '' ) { $update['admin_note'] = sanitize_textarea_field( $admin_note ); }
        if ( $new_status === 'cancelled' ) { $update['cancelled_at'] = current_time( 'mysql' ); }

        $__gs_status = $wpdb->update( $wpdb->prefix . 'gs_plan_requests', $update, [ 'id' => $request_id ] );
        if ( $__gs_status === false ) { self::$last_error = 'Could not update the request status. Please try again.'; return false; }
        self::log( $request_id, (int) $req->vendor_id, 'request.status_changed', $admin_id, $req->status, $new_status );

        self::notify_vendor_status_change( $req, $new_status, $admin_note );
        return true;
    }

    /** Record a (possibly partial) payment against a request. Recalculates amount_paid/balance_due. */
    public static function record_payment( int $request_id, int $vendor_id, array $payment, int $recorder_id, bool $skip_log = false ): int|false {
        self::$last_error = ''; self::$last_warning = '';
        global $wpdb;
        $req = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}gs_plan_requests WHERE id = %d", $request_id ) );
        if ( ! $req ) { self::$last_error = 'Request not found.'; return false; }

        $amount = (float) ( $payment['amount'] ?? 0 );
        if ( $amount <= 0 ) { self::$last_error = 'Payment amount must be greater than zero.'; return false; }

        $status = in_array( $payment['status'] ?? '', [ 'pending', 'partial', 'verified', 'rejected' ], true )
            ? $payment['status'] : 'pending';

        // Ghost-success fix: $wpdb->insert_id is not reset to 0 on a failed
        // insert (it retains the last successful insert's id from earlier in
        // this request), so checking insert_id alone could not reliably detect
        // this specific insert failing on a money-recording path. Checked
        // directly against insert()'s own return value instead.
        $inserted = $wpdb->insert( $wpdb->prefix . 'gs_plan_request_payments', [
            'request_id'     => $request_id,
            'vendor_id'       => $vendor_id,
            'amount'          => $amount,
            'currency'        => Config::get( 'currency', 'INR' ),
            'payment_mode'    => self::clamp( sanitize_text_field( $payment['payment_mode']   ?? '' ), 30 ),
            'transaction_id'  => self::clamp( sanitize_text_field( $payment['transaction_id'] ?? '' ), 120 ),
            'utr_number'      => self::clamp( sanitize_text_field( $payment['utr_number']     ?? '' ), 60 ),
            'cheque_number'   => self::clamp( sanitize_text_field( $payment['cheque_number']  ?? '' ), 40 ),
            'bank_name'       => self::clamp( sanitize_text_field( $payment['bank_name']      ?? '' ), 120 ),
            'bank_branch'     => self::clamp( sanitize_text_field( $payment['bank_branch']    ?? '' ), 120 ),
            'payment_date'    => self::sanitize_date( $payment['payment_date'] ?? '' ),
            'proof_ids'       => self::encode_ids( $payment['proof_ids'] ?? [] ),
            'status'          => $status,
            'recorded_by'     => $recorder_id,
            'verified_by'     => $status === 'verified' ? $recorder_id : 0,
            'verified_at'     => $status === 'verified' ? current_time( 'mysql' ) : null,
            'notes'           => sanitize_textarea_field( $payment['notes'] ?? '' ),
            'created_at'      => current_time( 'mysql' ),
        ] );
        if ( ! $inserted ) { self::$last_error = 'Could not record payment: ' . $wpdb->last_error; return false; }
        $payment_id = (int) $wpdb->insert_id;
        if ( ! $payment_id ) { self::$last_error = 'Could not record payment.'; return false; }

        // Recalculate totals from all verified+pending payments tied to this request.
        $total_paid = (float) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(amount),0) FROM {$wpdb->prefix}gs_plan_request_payments
             WHERE request_id = %d AND status IN ('verified','partial')",
            $request_id
        ) );
        $balance = max( 0, round( (float) $req->final_amount - $total_paid, 2 ) );

        // Status advancement: a payment being recorded always means "this needs a human look",
        // unless the request has already moved past the point where payment matters (approved,
        // completed, rejected, expired, cancelled — those are left untouched).
        $terminal = [ 'approved', 'completed', 'rejected', 'expired', 'cancelled' ];
        $new_request_status = $req->status;
        if ( ! in_array( $req->status, $terminal, true ) ) {
            // Balance still outstanding → flag for verification of what's been paid so far.
            // Balance fully cleared → ready for admin review (under_review), not "still pending".
            $new_request_status = $balance > 0 ? 'payment_verification_pending' : 'under_review';
        }

        $wpdb->update( $wpdb->prefix . 'gs_plan_requests', [
            'amount_paid' => $total_paid,
            'balance_due' => $balance,
            'status'      => $new_request_status,
            'updated_at'  => current_time( 'mysql' ),
        ], [ 'id' => $request_id ] );

        if ( ! $skip_log ) {
            self::log( $request_id, $vendor_id, 'payment.recorded', $recorder_id, null, [
                'amount' => $amount, 'status' => $status, 'total_paid' => $total_paid, 'balance' => $balance,
            ] );
            self::notify_vendor_payment_received( $req, $amount, $total_paid, $balance );
        }

        return $payment_id;
    }

    /**
     * Approve a request: optionally let the admin override the plan/cycle (matches the
     * original approve flow's "admin can override the plan" behaviour), finalise pricing
     * if not already set, then activate the subscription.
     */
    public static function approve( int $request_id, int $admin_id, array $overrides = [] ): int|false {
        self::$last_error = ''; self::$last_warning = '';
        global $wpdb;
        $req = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}gs_plan_requests WHERE id = %d", $request_id ) );
        if ( ! $req ) { self::$last_error = 'Request not found.'; return false; }
        if ( in_array( $req->status, [ 'approved', 'completed', 'cancelled', 'rejected', 'expired' ], true ) ) {
            self::$last_error = 'This request has already been finalised (' . $req->status . ').';
            return false;
        }

        $effective_plan_id = (int) ( $overrides['plan_id'] ?? $req->plan_id );
        $plan = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}gs_subscription_plans WHERE id = %d", $effective_plan_id ) );
        if ( ! $plan ) { self::$last_error = 'Plan no longer exists.'; return false; }

        $cycle         = self::sanitize_cycle( $overrides['billing_cycle'] ?? $req->billing_cycle ?? 'monthly' );
        $custom_months = max( 0, (int) ( $overrides['custom_months'] ?? $req->custom_months ?? 0 ) );
        $dates         = self::compute_dates( $cycle, $custom_months, $overrides['activation_date'] ?? null );

        $__gs_approve = $wpdb->update( $wpdb->prefix . 'gs_plan_requests', [
            'plan_id'         => $effective_plan_id,
            'plan_name'       => $plan->name,
            'billing_cycle'   => $cycle,
            'custom_months'   => $custom_months,
            'activation_date' => $dates['activation_date'],
            'expiry_date'     => $dates['expiry_date'],
            'status'          => 'approved',
            'approved_by'     => $admin_id,
            'approved_at'     => current_time( 'mysql' ),
            'admin_note'      => sanitize_textarea_field( $overrides['admin_note'] ?? $req->admin_note ?? '' ),
            'updated_at'      => current_time( 'mysql' ),
        ], [ 'id' => $request_id ] );
        // activate() below re-reads this row from the DB and requires
        // status='approved' — if this write silently failed, activate()
        // would read the stale pre-approval status and could reject
        // activation (or worse, activate against stale plan/date fields).
        if ( $__gs_approve === false ) { self::$last_error = 'Could not approve the request. Please try again.'; return false; }

        self::log( $request_id, (int) $req->vendor_id, 'request.approved', $admin_id, $req->status, 'approved' );

        return self::activate( $request_id, $admin_id );
    }

    public static function reject( int $request_id, int $admin_id, string $reason ): bool {
        self::$last_error = ''; self::$last_warning = '';
        return self::set_status( $request_id, 'rejected', $admin_id, $reason );
    }

    /**
     * Activate the subscription for an approved request. Idempotent: if the request
     * already has a subscription_id linked, returns that instead of creating a duplicate.
     */
    public static function activate( int $request_id, int $admin_id ): int|false {
        self::$last_error = ''; self::$last_warning = '';
        global $wpdb;
        $req = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}gs_plan_requests WHERE id = %d", $request_id ) );
        if ( ! $req ) { self::$last_error = 'Request not found.'; return false; }
        if ( (int) $req->subscription_id > 0 ) { return (int) $req->subscription_id; }

        $months = match ( $req->billing_cycle ) {
            'annual'      => 12,
            'quarterly'   => 3,
            'half_yearly' => 6,
            'lifetime'    => 1200,
            'trial'       => 0, // expires_at below is taken from request's own expiry_date for trial
            'custom'      => max( 1, (int) $req->custom_months ),
            default       => 1,
        };

        // Cancel any existing active OR trialing sub for this vendor (matches
        // SubscriptionService::create() behaviour). Previously only matched
        // status='active' — a vendor currently on a manual trial who then got
        // a new plan assigned would end up with two simultaneously-live
        // subscription rows (the old trialing one never cancelled).
        $wpdb->update( $wpdb->prefix . 'gs_subscriptions',
            [ 'status' => 'cancelled', 'cancelled_at' => current_time( 'mysql' ) ],
            [ 'vendor_id' => $req->vendor_id, 'status' => 'active' ]
        );
        $wpdb->update( $wpdb->prefix . 'gs_subscriptions',
            [ 'status' => 'cancelled', 'cancelled_at' => current_time( 'mysql' ) ],
            [ 'vendor_id' => $req->vendor_id, 'status' => 'trialing' ]
        );

        $expires_at = $req->expiry_date ?: date( 'Y-m-d H:i:s', strtotime( "+{$months} months" ) );

        // Ghost-success fix: $wpdb->insert_id is not reset to 0 on a failed
        // insert (it retains the last successful insert's id from earlier in
        // this request — the payment insert above, if one happened, or an
        // even earlier query), so checking insert_id alone below could not
        // reliably detect this specific insert failing on the subscription-
        // activation path. Checked directly against insert()'s own return
        // value instead.
        $inserted = $wpdb->insert( $wpdb->prefix . 'gs_subscriptions', [
            'vendor_id'      => $req->vendor_id,
            'plan_id'        => $req->plan_id,
            'plan_name'      => $req->plan_name,
            'billing_cycle'  => match ( $req->billing_cycle ) {
                'annual'                          => 'yearly',
                'quarterly', 'yearly', 'lifetime' => $req->billing_cycle,
                default                           => 'monthly', // monthly, half_yearly, trial, trial_3m, trial_6m, custom — all map to the closest valid ENUM value
            },
            'amount'         => (float) $req->final_amount,
            'currency'       => $req->currency ?: Config::get( 'currency', 'INR' ),
            'status'         => self::is_trial_cycle( $req->billing_cycle ) ? 'trialing' : 'active',
            // trial_ends_at: populated for trial subscriptions so the existing
            // Cron::check_trial_endings() reminder (which filters on this exact
            // column) can find and notify manually-assigned trials — without
            // this, that reminder silently never fired for any manual trial,
            // since it only ever populated expires_at, not trial_ends_at.
            'trial_ends_at'  => self::is_trial_cycle( $req->billing_cycle ) ? $expires_at : null,
            'payment_method' => $req->payment_mode ?: 'manual_offline',
            'payment_id'     => $req->transaction_id ?: $req->utr_number ?: ( 'MANUAL-' . $req->id ),
            'gateway'        => 'manual_offline',
            // ENTERPRISE-AUDIT FIX (Part 2, High: plan versioning/grandfathering).
            'plan_snapshot'  => SubscriptionService::build_plan_snapshot( (int) $req->plan_id ),
            'gateway_data'   => wp_json_encode( [
                'plan_request_id' => $req->id,
                'utr_number'      => $req->utr_number,
                'cheque_number'   => $req->cheque_number,
                'bank_name'       => $req->bank_name,
                'reference_number'=> $req->reference_number,
            ] ),
            'starts_at'      => $req->activation_date ?: current_time( 'mysql' ),
            'expires_at'     => $req->billing_cycle === 'lifetime' ? '2099-12-31 23:59:59' : $expires_at,
            'auto_renew'     => 0, // manual plans don't auto-renew via gateway; admin/cron handles renewal reminders
            'created_at'     => current_time( 'mysql' ),
            'updated_at'     => current_time( 'mysql' ),
        ] );
        if ( ! $inserted ) { self::$last_error = 'Failed to activate subscription: ' . $wpdb->last_error; return false; }
        $sub_id = (int) $wpdb->insert_id;
        if ( ! $sub_id ) { self::$last_error = 'Failed to activate subscription.'; return false; }

        $wpdb->update( $wpdb->prefix . 'gs_plan_requests', [
            'status'          => 'completed',
            'subscription_id' => $sub_id,
            'resulting_action'=> 'activated',
            'updated_at'      => current_time( 'mysql' ),
        ], [ 'id' => $request_id ] );

        // Invalidate vendor's cached active-subscription lookup
        $user_id = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT user_id FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $req->vendor_id
        ) );
        if ( $user_id ) { Cache::delete( "sub:active:{$user_id}" ); }
        Cache::flush_group( 'listings' );

        self::log( $request_id, (int) $req->vendor_id, 'request.activated', $admin_id, 'approved', 'completed' );

        // In-app notification (email receipt is sent by the 'plan_request.activated'
        // EventBus listener registered in EventBus::init() — kept separate so the
        // email-template dependency lives with the other EventBus-driven side effects).
        if ( $user_id ) {
            NotificationService::create(
                $user_id, 'plan_request.activated', '✅ Plan Activated!',
                'Your "' . $req->plan_name . '" plan is now active'
                    . ( $req->billing_cycle === 'lifetime' ? '.' : ( ' until ' . date( 'd M Y', strtotime( $expires_at ) ) . '.' ) ),
                home_url( '/vendor/dashboard/?section=subscription' ), 'check-circle', '#059669'
            );
        }

        EventBus::emit( 'subscription.created', [
            'subscription_id' => $sub_id,
            'vendor_id'       => $req->vendor_id,
            'plan_name'       => $req->plan_name,
        ] );
        EventBus::emit( 'plan_request.activated', [
            'request_id'      => $request_id,
            'vendor_id'       => (int) $req->vendor_id,
            'plan_name'       => $req->plan_name,
            'subscription_id' => $sub_id,
            'expires_at'      => $expires_at,
        ] );

        return $sub_id;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Lifecycle: renew / upgrade / downgrade / extend (Section 7 of spec)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Manual renewal/upgrade/downgrade/extension. Creates a NEW plan_request row
     * (source=admin_assigned) linked to the existing subscription's vendor, so full
     * history is preserved (spec requirement: "all changes must preserve historical
     * subscription records" — we never edit/delete a prior request row in place).
     */
    public static function renew_or_change( int $vendor_id, array $data, int $admin_id, string $action ): int|false {
        self::$last_error = ''; self::$last_warning = '';
        if ( ! in_array( $action, [ 'renew', 'upgrade', 'downgrade', 'extend', 'trial_conversion' ], true ) ) {
            self::$last_error = 'Invalid lifecycle action.';
            return false;
        }

        // Real fix — confirmed gap: this lifecycle label is genuinely stored
        // (resulting_action, below) and read back by the Subscription Revenue
        // report's upgrade/downgrade breakdown, so an admin picking the wrong
        // label for the actual price direction silently corrupts that report
        // with no warning. This cross-checks the vendor's current active plan
        // price against the newly-selected plan's price and, for the two
        // labels where direction actually matters (upgrade/downgrade),
        // auto-corrects the stored label to match reality and appends a
        // visible warning so the admin knows their selection was overridden.
        if ( in_array( $action, [ 'upgrade', 'downgrade' ], true ) && ! empty( $data['plan_id'] ) ) {
            global $wpdb;
            // FIXED — confirmed bug: gs_subscription_plans has NO column named
            // `price` (only price_monthly/price_yearly/price_quarterly) —
            // $wpdb->get_var() silently swallows the resulting SQL error and
            // returns null, which cast to (float) 0.0 always, so the
            // upgrade/downgrade auto-correction below could never actually
            // fire. Both prices are now read from the column matching each
            // side's own billing_cycle. 'lifetime' has no dedicated price
            // column — price_yearly is used as the safe fallback (a lifetime
            // plan's yearly price is the closest existing proxy for its tier,
            // and this only feeds a same-vendor upgrade/downgrade LABEL, not
            // any amount actually charged).
            $current_row = $wpdb->get_row( $wpdb->prepare(
                "SELECT sp.price_monthly, sp.price_quarterly, sp.price_yearly, s.billing_cycle
                 FROM {$wpdb->prefix}gs_subscriptions s
                 JOIN {$wpdb->prefix}gs_subscription_plans sp ON sp.id = s.plan_id
                 WHERE s.vendor_id = %d AND s.status IN ('active','trialing')
                 ORDER BY s.created_at DESC LIMIT 1",
                $vendor_id
            ) );
            $price_for_cycle = static function( ?\stdClass $row, string $cycle ): float {
                if ( ! $row ) { return 0.0; }
                return (float) match ( $cycle ) {
                    'yearly', 'lifetime' => $row->price_yearly,
                    'quarterly'          => $row->price_quarterly,
                    default              => $row->price_monthly,
                };
            };
            $current_price = $price_for_cycle( $current_row, $current_row->billing_cycle ?? 'monthly' );

            $new_cycle = self::sanitize_cycle( $data['billing_cycle'] ?? ( $current_row->billing_cycle ?? 'monthly' ) );
            $new_plan_row = $wpdb->get_row( $wpdb->prepare(
                "SELECT price_monthly, price_quarterly, price_yearly FROM {$wpdb->prefix}gs_subscription_plans WHERE id = %d", (int) $data['plan_id']
            ) );
            $new_price = $price_for_cycle( $new_plan_row, $new_cycle );
            if ( $current_price > 0.0 && $new_price > 0.0 && $current_price !== $new_price ) {
                $correct_action = $new_price > $current_price ? 'upgrade' : 'downgrade';
                if ( $correct_action !== $action ) {
                    self::$last_warning = "Label corrected: you selected \"{$action}\" but the new plan (₹{$new_price}) is actually a {$correct_action} from the current plan (₹{$current_price}). Recorded as \"{$correct_action}\" so reporting stays accurate.";
                    $action = $correct_action;
                }
            }
        }

        $data['admin_note'] = trim( ( $data['admin_note'] ?? '' ) . " [{$action}]" );
        $request_id = self::admin_assign( $vendor_id, $data, $admin_id );
        if ( $request_id === false ) { return false; }

        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'gs_plan_requests',
            [ 'resulting_action' => $action ],
            [ 'id' => $request_id ]
        );
        return $request_id;
    }

    /** Complimentary extension of an existing active subscription's expiry, no new payment. */
    public static function extend_validity( int $vendor_id, int $extra_days, string $reason, int $admin_id ): bool {
        self::$last_error = ''; self::$last_warning = '';
        global $wpdb;
        $sub = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_subscriptions WHERE vendor_id = %d AND status IN ('active','trialing') ORDER BY id DESC LIMIT 1",
            $vendor_id
        ) );
        if ( ! $sub ) { self::$last_error = 'No active subscription found for this vendor.'; return false; }

        $base = $sub->expires_at ? strtotime( $sub->expires_at ) : current_time( 'timestamp' );
        $new_expiry = date( 'Y-m-d H:i:s', strtotime( "+{$extra_days} days", $base ) );

        $__gs_extend = $wpdb->update( $wpdb->prefix . 'gs_subscriptions',
            [ 'expires_at' => $new_expiry, 'updated_at' => current_time( 'mysql' ) ],
            [ 'id' => $sub->id ]
        );
        if ( $__gs_extend === false ) { self::$last_error = 'Could not extend the subscription. Please try again.'; return false; }

        // Record as its own request row purely for audit/history — no new subscription created.
        $wpdb->insert( $wpdb->prefix . 'gs_plan_requests', [
            'vendor_id'        => $vendor_id,
            'plan_id'          => $sub->plan_id,
            'plan_name'        => $sub->plan_name,
            'source'           => 'admin_assigned',
            'status'           => 'completed',
            'billing_cycle'    => 'custom',
            'final_amount'     => 0,
            'amount_paid'      => 0,
            'discount_type'    => 'complimentary',
            'discount_reason'  => self::clamp( sanitize_text_field( $reason ), 255 ),
            'admin_note'       => 'Complimentary extension of ' . $extra_days . ' day(s). ' . sanitize_text_field( $reason ),
            'assigned_by'      => $admin_id,
            'approved_by'      => $admin_id,
            'approved_at'      => current_time( 'mysql' ),
            'subscription_id'  => $sub->id,
            'resulting_action' => 'extend',
            'expiry_date'      => $new_expiry,
            'created_at'       => current_time( 'mysql' ),
            'updated_at'       => current_time( 'mysql' ),
        ] );
        $request_id = (int) $wpdb->insert_id;

        self::log( $request_id, $vendor_id, 'subscription.extended', $admin_id, $sub->expires_at, $new_expiry );

        $user_id = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT user_id FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $vendor_id
        ) );
        if ( $user_id ) {
            Cache::delete( "sub:active:{$user_id}" );
            NotificationService::create(
                $user_id, 'subscription.extended', '🎁 Plan Extended',
                'Your "' . $sub->plan_name . '" plan validity has been extended to ' . date( 'd M Y', strtotime( $new_expiry ) ) . '.',
                home_url( '/vendor/dashboard/?section=subscription' ), 'gift', '#7C3AED'
            );
        }
        return true;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Email template seeding (idempotent — safe to call on every version bump)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Seeds the email templates this service's maybe_email() calls depend on.
     * Without this, NotificationService::maybe_email() silently no-ops (see
     * EmailService/NotificationService::send_email_job(): "if (!$tpl) return;")
     * — the in-app notification would still appear, but no email would ever send,
     * with no error anywhere. Called from Plugin::check_db_version() on every
     * version bump so existing sites get these templates without re-activating.
     */
    public static function seed_email_templates(): void {
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$p}email_templates'" ) ) { return; }

        $base_style = '<div style="font-family:Arial,sans-serif;max-width:580px;margin:0 auto;padding:0 0 40px">'
            . '<div style="background:#2563EB;padding:20px 28px"><span style="color:#fff;font-weight:800;font-size:1.1rem">{{platform_name}}</span></div>'
            . '<div style="background:#fff;padding:28px 28px 20px;border:1px solid #E2E8F0;border-top:none">';
        $base_footer = '</div><div style="padding:18px 28px;font-size:.74rem;color:#94A3B8;text-align:center">'
            . '© {{year}} {{platform_name}} · <a href="{{platform_url}}" style="color:#2563EB">Visit site</a></div></div>';

        $templates = [
            [ 'slug' => 'plan_request_status_changed', 'name' => 'Plan Request Status Changed',
              'subject' => '📋 Update on your "{{plan_name}}" plan request — {{status}}',
              'body' => $base_style
                  . '<h2 style="color:#1E293B;margin:0 0 12px">Plan Request Update</h2>'
                  . '<p>Your plan request for <strong>{{plan_name}}</strong> is now: <strong>{{status}}</strong>.</p>'
                  . '<p>{{note}}</p>'
                  . '<p style="margin-top:20px"><a href="{{platform_url}}vendor/dashboard/?section=subscription" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Request →</a></p>'
                  . $base_footer ],
            [ 'slug' => 'plan_request_payment_received', 'name' => 'Offline Payment Received',
              'subject' => '🧾 We received your payment for "{{plan_name}}"',
              'body' => $base_style
                  . '<h2 style="color:#059669;margin:0 0 12px">Payment Received</h2>'
                  . '<p>We\'ve recorded your payment of <strong>{{amount}}</strong> for the <strong>{{plan_name}}</strong> plan.</p>'
                  . '<p>Our team will verify the details and activate your plan shortly.</p>'
                  . '<p style="margin-top:20px"><a href="{{platform_url}}vendor/dashboard/?section=subscription" style="background:#059669;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Track Status →</a></p>'
                  . $base_footer ],
            [ 'slug' => 'plan_request_activated', 'name' => 'Manual Plan Activated',
              'subject' => '✅ Your "{{plan_name}}" plan is now active!',
              'body' => $base_style
                  . '<h2 style="color:#059669;margin:0 0 12px">Plan Activated</h2>'
                  . '<p>Your <strong>{{plan_name}}</strong> plan is now active{{expiry_clause}}.</p>'
                  . '<p style="margin-top:20px"><a href="{{platform_url}}vendor/dashboard/" style="background:#059669;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Go to Dashboard →</a></p>'
                  . $base_footer ],
            [ 'slug' => 'plan_request_renewal_reminder', 'name' => 'Manual Plan Renewal Reminder',
              'subject' => '⏰ Your "{{plan_name}}" plan expires on {{expires_at}}',
              'body' => $base_style
                  . '<h2 style="color:#D97706;margin:0 0 12px">Renewal Reminder</h2>'
                  . '<p>Your <strong>{{plan_name}}</strong> plan expires on <strong>{{expires_at}}</strong>.</p>'
                  . '<p>To renew via offline payment (bank transfer, UPI, cheque, etc.), submit a renewal request from your dashboard.</p>'
                  . '<p style="margin-top:20px"><a href="{{platform_url}}vendor/dashboard/?section=subscription" style="background:#D97706;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Renew Now →</a></p>'
                  . $base_footer ],
            // Inquiry/booking email verification (replaces the removed phantom
            // mobile-OTP gate — see EmailVerificationService).
            [ 'slug' => 'inquiry_email_verification', 'name' => 'Inquiry Email Verification',
              'subject' => 'Please verify your email — {{platform_name}}',
              'body' => $base_style
                  . '<h2 style="color:#1E293B;margin:0 0 12px">Verify Your Email</h2>'
                  . '<p>Hi {{customer_name}}, thanks for reaching out! Please confirm your email address so the business knows your inquiry is genuine.</p>'
                  . '<p style="margin-top:20px"><a href="{{verify_url}}" style="background:#2563EB;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">Verify My Email →</a></p>'
                  . '<p style="font-size:.78rem;color:#94A3B8;margin-top:18px">This link expires in 48 hours. If you didn\'t submit this inquiry, you can ignore this email.</p>'
                  . $base_footer ],
            // OTP-code counterpart to the above — used by
            // EmailVerificationService::send_otp(), the flow actually wired up
            // to inquiry/booking submissions. Customer types the code on the
            // confirmation screen instead of clicking a link.
            [ 'slug' => 'inquiry_email_otp', 'name' => 'Inquiry Email Verification (OTP)',
              'subject' => 'Your verification code — {{platform_name}}',
              'body' => $base_style
                  . '<h2 style="color:#1E293B;margin:0 0 12px">Verify Your Email</h2>'
                  . '<p>Hi {{customer_name}}, thanks for reaching out! Enter this code to confirm your inquiry is genuine:</p>'
                  . '<p style="margin:20px 0;text-align:center"><span style="display:inline-block;background:#F1F5F9;color:#1E293B;padding:14px 28px;border-radius:10px;font-size:1.6rem;font-weight:800;letter-spacing:.3em">{{otp_code}}</span></p>'
                  . '<p style="font-size:.78rem;color:#94A3B8;margin-top:18px">This code expires in 10 minutes. If you didn\'t submit this inquiry, you can ignore this email.</p>'
                  . $base_footer ],
            // Vendor listing approval/rejection — the EventBus payload for these
            // (AjaxController::approveListing()/rejectListing()) now correctly
            // supplies vendor_email, but that fix is inert without these templates
            // actually existing to be looked up. Without both pieces, this email
            // silently never sent for a single listing approval or rejection.
            [ 'slug' => 'listing_approved', 'name' => 'Listing Approved',
              'subject' => '✅ Your listing "{{title}}" is now live!',
              'body' => $base_style
                  . '<h2 style="color:#1E293B;margin:0 0 12px">Your listing is live!</h2>'
                  . '<p>Good news — <strong>{{title}}</strong> has been approved and is now visible to customers on {{platform_name}}.</p>'
                  . '<p style="margin-top:20px"><a href="{{platform_url}}{{slug}}/" style="background:#059669;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;font-weight:700">View Your Listing →</a></p>'
                  . $base_footer ],
            [ 'slug' => 'listing_rejected', 'name' => 'Listing Rejected',
              'subject' => 'Action needed on your listing "{{title}}"',
              'body' => $base_style
                  . '<h2 style="color:#1E293B;margin:0 0 12px">Your listing needs changes</h2>'
                  . '<p><strong>{{title}}</strong> could not be approved as submitted.</p>'
                  . '<p style="background:#FEF2F2;border-left:3px solid #DC2626;padding:12px 16px;margin:16px 0;color:#7F1D1D">{{reason}}</p>'
                  . '<p>Please make the needed changes and resubmit from your vendor dashboard.</p>'
                  . $base_footer ],
        ];

        foreach ( $templates as $tpl ) {
            $existing = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$p}email_templates WHERE slug = %s", $tpl['slug']
            ) );
            if ( ! $existing ) {
                $wpdb->insert( $p . 'email_templates', array_merge( $tpl, [
                    'is_active'  => 1,
                    'created_at' => current_time( 'mysql' ),
                    'updated_at' => current_time( 'mysql' ),
                ] ) );
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Internal helpers
    // ─────────────────────────────────────────────────────────────────────────

    private static function sanitize_cycle( string $cycle ): string {
        $cycle = strtolower( trim( $cycle ) );
        return array_key_exists( $cycle, self::CYCLE_MONTHS ) ? $cycle : 'monthly';
    }

    private static function sanitize_discount_type( string $type ): string {
        $allowed = [ 'none', 'percentage', 'fixed', 'complimentary', 'staff', 'coupon_equivalent', 'credit_adjustment' ];
        return in_array( $type, $allowed, true ) ? $type : 'none';
    }

    private static function sanitize_date( string $date ): ?string {
        if ( ! $date ) { return null; }
        $ts = strtotime( $date );
        return $ts ? date( 'Y-m-d', $ts ) : null;
    }

    /**
     * Clamp a sanitized string to a column's actual VARCHAR width before insert.
     * Without this, pasting an oversized value (e.g. a long bank-generated UTR
     * string) into a field like utr_number (VARCHAR(60)) can fail the entire
     * INSERT outright under MySQL strict mode — surfacing as a generic "could
     * not save your request" with no indication of which field or why. Silent
     * truncation here is the better failure mode: the data is still usable
     * (most reference numbers are front-loaded with the meaningful part) and
     * the request doesn't get lost entirely over a cosmetic length mismatch.
     */
    private static function clamp( string $value, int $max_length ): string {
        return mb_substr( $value, 0, $max_length );
    }

    /** @param array<int>|int[] $ids Media IDs returned by the existing uploadMedia AJAX action. */
    private static function encode_ids( mixed $ids ): string {
        if ( is_string( $ids ) ) {
            // Already a comma/JSON list — try to decode, else pass through as a single value.
            $decoded = json_decode( $ids, true );
            $ids = is_array( $decoded ) ? $decoded : array_filter( array_map( 'trim', explode( ',', $ids ) ) );
        }
        $ids = array_values( array_unique( array_filter( array_map( 'intval', (array) $ids ) ) ) );
        return wp_json_encode( $ids );
    }

    /** Writes to the existing, generic gs_activity_log table — single audit trail for the whole plugin. */
    private static function log( int $request_id, int $vendor_id, string $action, int $user_id, mixed $old_value, mixed $new_value ): void {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'gs_activity_log', [
            'user_id'     => $user_id,
            'action'      => $action,
            'object_type' => 'plan_request',
            'object_id'   => $request_id,
            'description' => $action . ' (vendor #' . $vendor_id . ')',
            'old_value'   => is_scalar( $old_value ) ? (string) $old_value : wp_json_encode( $old_value ),
            'new_value'   => is_scalar( $new_value ) ? (string) $new_value : wp_json_encode( $new_value ),
            'ip_address'  => self::client_ip(),
            'user_agent'  => substr( sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ?? '' ), 0, 490 ),
            'created_at'  => current_time( 'mysql' ),
        ] );
    }

    private static function client_ip(): string {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
        $ip = explode( ',', $ip )[0] ?? '';
        return substr( sanitize_text_field( trim( $ip ) ), 0, 45 );
    }

    private static function notify_vendor_scheduled( \stdClass $vendor, \stdClass $plan, string $activation_date ): void {
        NotificationService::create(
            (int) $vendor->user_id, 'plan_request.scheduled', '📅 Plan Scheduled',
            'Your "' . $plan->name . '" plan is scheduled to activate on ' . date( 'd M Y', strtotime( $activation_date ) ) . '.',
            home_url( '/vendor/dashboard/?section=subscription' ), 'calendar', '#2563EB'
        );
    }

    private static function notify_vendor_payment_received( \stdClass $req, float $amount_this_payment, float $total_paid, float $balance ): void {
        global $wpdb;
        $vp = $wpdb->get_row( $wpdb->prepare(
            "SELECT vp.user_id, u.user_email FROM {$wpdb->prefix}gs_vendor_profiles vp
             LEFT JOIN {$wpdb->prefix}users u ON u.ID = vp.user_id WHERE vp.id = %d",
            $req->vendor_id
        ) );
        if ( ! $vp || ! $vp->user_id ) { return; }

        $formatted = Helpers::format_price( $amount_this_payment );
        $tail = $balance > 0
            ? ' Remaining balance: ' . Helpers::format_price( $balance ) . '.'
            : ' Payment is now complete — awaiting admin verification.';

        NotificationService::create(
            (int) $vp->user_id, 'plan_request.payment_received', '🧾 Payment Recorded',
            'We recorded your payment of ' . $formatted . ' for "' . $req->plan_name . '".' . $tail,
            home_url( '/vendor/dashboard/?section=subscription' ), 'check', '#059669'
        );
        if ( ! empty( $vp->user_email ) ) {
            NotificationService::maybe_email(
                (int) $vp->user_id, 'plan_request.payment_received', $vp->user_email, 'plan_request_payment_received',
                [ 'plan_name' => $req->plan_name, 'amount' => $formatted ]
            );
        }
    }

    private static function notify_vendor_status_change( \stdClass $req, string $new_status, string $note ): void {
        global $wpdb;
        $vp = $wpdb->get_row( $wpdb->prepare(
            "SELECT vp.user_id, u.user_email FROM {$wpdb->prefix}gs_vendor_profiles vp
             LEFT JOIN {$wpdb->prefix}users u ON u.ID = vp.user_id WHERE vp.id = %d",
            $req->vendor_id
        ) );
        if ( ! $vp || ! $vp->user_id ) { return; }

        $copy = [
            'under_review'                 => [ '🔍 Request Under Review',        'Your "' . $req->plan_name . '" plan request is being reviewed.' ],
            'payment_verification_pending' => [ '🧾 Verifying Your Payment',       'We received your payment details for "' . $req->plan_name . '" and are verifying them.' ],
            'info_required'                => [ '⚠️ Additional Info Needed',       'We need more information about your "' . $req->plan_name . '" request' . ( $note ? ': ' . $note : '.' ) ],
            'on_hold'                      => [ '⏸️ Request On Hold',              'Your "' . $req->plan_name . '" request has been put on hold' . ( $note ? ': ' . $note : '.' ) ],
            'rejected'                     => [ '❌ Request Rejected',             'Your "' . $req->plan_name . '" plan request was rejected' . ( $note ? ': ' . $note : '.' ) ],
            'cancelled'                    => [ '✕ Request Cancelled',             'Your "' . $req->plan_name . '" plan request was cancelled.' ],
        ];
        if ( ! isset( $copy[ $new_status ] ) ) { return; }
        [ $title, $body ] = $copy[ $new_status ];

        NotificationService::create(
            (int) $vp->user_id, 'plan_request.' . $new_status, $title, $body,
            home_url( '/vendor/dashboard/?section=subscription' ), 'bell', '#2563EB'
        );
        if ( ! empty( $vp->user_email ) ) {
            NotificationService::maybe_email(
                (int) $vp->user_id, 'plan_request.' . $new_status, $vp->user_email, 'plan_request_status_changed',
                [ 'plan_name' => $req->plan_name, 'status' => $new_status, 'note' => $note ]
            );
        }
    }
}
