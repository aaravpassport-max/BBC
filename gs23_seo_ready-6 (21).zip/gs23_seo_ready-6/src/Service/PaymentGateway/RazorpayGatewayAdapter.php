<?php
namespace GoodService\Service\PaymentGateway;

use GoodService\Service\RazorpayService;

/**
 * Thin adapter — delegates every call straight to RazorpayService, which
 * remains the single source of truth for the actual Razorpay API
 * integration (this file adds zero new HTTP calls or business logic).
 * See PaymentGatewayInterface's docblock for why this exists.
 */
final class RazorpayGatewayAdapter implements PaymentGatewayInterface {

    public static function key(): string { return 'razorpay'; }
    public static function label(): string { return 'Razorpay'; }
    public static function is_configured(): bool { return RazorpayService::is_configured(); }
    public static function test_connection(): array { return RazorpayService::test_connection(); }

    public static function create_payment( array $params ): array {
        $amount_paise = (int) round( (float) ( $params['amount'] ?? 0 ) * 100 );
        $order = RazorpayService::create_order(
            $amount_paise,
            (string) ( $params['receipt'] ?? '' ),
            (array) ( $params['metadata'] ?? [] )
        );
        if ( $order === false || empty( $order['id'] ) ) {
            return [ 'success' => false, 'mode' => 'embedded', 'checkout' => [], 'error' => 'Could not create Razorpay order — see error log for details.' ];
        }
        return [
            'success' => true,
            'mode'    => 'embedded',
            'checkout' => [
                'order_id' => $order['id'],
                'key_id'   => RazorpayService::key_id(),
                'amount'   => $amount_paise,
                'currency' => $order['currency'] ?? ( $params['currency'] ?? 'INR' ),
            ],
            'error' => null,
        ];
    }

    public static function refund( string $payment_id, ?float $amount = null ): array {
        return RazorpayService::refund( $payment_id, $amount );
    }
}
