<?php
namespace GoodService\Service\PaymentGateway;

/**
 * Single lookup point for "which gateway classes exist" — see
 * PaymentGatewayInterface's docblock. A third gateway is added by
 * appending ONE line to default_gateways(); nothing else in the codebase
 * needs to change to make it selectable/usable everywhere this registry
 * is consulted.
 *
 * Also filterable via the 'gs_payment_gateways' WordPress filter, so a
 * site-specific mu-plugin or a future paid add-on could register an
 * additional gateway without editing this core file at all — the
 * standard WordPress extensibility pattern, used nowhere else for
 * gateways before this fix (both gateways were previously hardcoded
 * directly into call sites).
 */
final class PaymentGatewayRegistry {

    /** @var array<string,class-string<PaymentGatewayInterface>>|null */
    private static ?array $gateways = null;

    /** The two gateways that exist today. Add a third here (see
     * PaymentGatewayInterface's docblock for the steps). */
    private static function default_gateways(): array {
        return [
            'razorpay' => RazorpayGatewayAdapter::class,
            'stripe'   => StripeGatewayAdapter::class,
        ];
    }

    private static function load(): array {
        if ( self::$gateways === null ) {
            $gateways = self::default_gateways();
            if ( function_exists( 'apply_filters' ) ) {
                // Allows a third-party gateway class to be registered
                // without touching this file — see class docblock.
                $gateways = apply_filters( 'gs_payment_gateways', $gateways );
            }
            // Defensive: only keep entries that actually implement the
            // interface — a misconfigured filter callback must not be
            // able to make get()/create_payment() call an arbitrary class.
            self::$gateways = array_filter( $gateways, static function ( $class ) {
                return is_string( $class ) && class_exists( $class ) && in_array( PaymentGatewayInterface::class, class_implements( $class ) ?: [], true );
            } );
        }
        return self::$gateways;
    }

    /** @return class-string<PaymentGatewayInterface>|null */
    public static function get( string $key ): ?string {
        $gateways = self::load();
        return $gateways[ $key ] ?? null;
    }

    /** All registered gateway keys => class names. */
    public static function all(): array {
        return self::load();
    }

    /** Only the gateways that currently have valid API credentials —
     * what a "choose a payment method" UI should actually offer. */
    public static function configured(): array {
        $out = [];
        foreach ( self::load() as $key => $class ) {
            if ( $class::is_configured() ) { $out[ $key ] = $class; }
        }
        return $out;
    }
}
