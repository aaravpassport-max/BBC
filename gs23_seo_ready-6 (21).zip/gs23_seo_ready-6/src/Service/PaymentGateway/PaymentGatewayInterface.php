<?php
namespace GoodService\Service\PaymentGateway;

/**
 * ENTERPRISE-AUDIT FIX (Part 2, §12, High: "payment-gateway abstraction
 * layer for a 3rd gateway" — Razorpay and Stripe were each wired directly
 * into AjaxController/vendor-dashboard.php with no shared contract, so
 * adding a third gateway (Cashfree, PayU, PhonePe...) meant duplicating
 * every call site rather than implementing one interface).
 *
 * This does NOT touch RazorpayService/StripeService's own internals —
 * both are already working, tested, production code, and rewriting them
 * would be pure regression risk for no behavioral gain. Instead this
 * interface + the two Adapter classes in this same directory wrap the
 * existing services behind one shared contract, and PaymentGatewayRegistry
 * is the single place a third gateway gets registered. To add a real third
 * gateway: write its own GatewayNameService (API calls) exactly like
 * RazorpayService/StripeService already do, write a thin
 * GatewayNameGatewayAdapter implementing this interface (see
 * RazorpayGatewayAdapter for the embedded-checkout shape,
 * StripeGatewayAdapter for the redirect-checkout shape), and add one line
 * to PaymentGatewayRegistry::default_gateways() — no other file needs to
 * change.
 *
 * Razorpay and Stripe use genuinely different checkout UX (Razorpay:
 * client-side JS widget against a pre-created order; Stripe: redirect to a
 * hosted Checkout Session) — that difference is real, not an artifact of
 * inconsistent code, so create_payment() returns a normalized envelope
 * with a 'mode' field ('embedded' | 'redirect') rather than forcing both
 * into one identical checkout flow that would fit neither well.
 */
interface PaymentGatewayInterface {

    /** Stable machine key — 'razorpay', 'stripe', etc. Matches the
     * gs_subscriptions.gateway / gs_invoices.gateway column values already
     * written by the existing services, so no data migration is needed. */
    public static function key(): string;

    /** Human label for admin UI (Settings gateway picker, invoice display). */
    public static function label(): string;

    /** True when this gateway has valid API credentials configured. */
    public static function is_configured(): bool;

    /** Live credential/connectivity check — used by the Settings screen's
     * existing "Test Connection" buttons. Returns
     * ['success'=>bool,'message'=>string]. */
    public static function test_connection(): array;

    /**
     * Starts a payment. $params:
     *   'amount'      => float, amount in the major currency unit (rupees, not paise)
     *   'currency'    => string, e.g. 'INR'
     *   'description' => string
     *   'receipt'     => string, an internal reference (order/invoice id)
     *   'metadata'    => array, arbitrary key/value passed through to the gateway
     *   'success_url' => string, required by redirect-mode gateways, ignored by embedded-mode ones
     *   'cancel_url'  => string, required by redirect-mode gateways, ignored by embedded-mode ones
     *
     * Returns:
     *   ['success'=>bool, 'mode'=>'embedded'|'redirect', 'checkout'=>array, 'error'=>?string]
     *   For 'embedded': checkout carries whatever the frontend JS widget
     *     needs (e.g. Razorpay's order_id + key_id).
     *   For 'redirect': checkout carries at least ['url' => string] — the
     *     browser is sent there directly.
     */
    public static function create_payment( array $params ): array;

    /**
     * Issues a refund. Returns ['success'=>bool,'refund_id'=>?string,'error'=>?string]
     * — this shape was already identical between RazorpayService::refund()
     * and StripeService::refund() before this abstraction existed, so both
     * adapters below delegate straight through with zero translation.
     */
    public static function refund( string $payment_id, ?float $amount = null ): array;
}
