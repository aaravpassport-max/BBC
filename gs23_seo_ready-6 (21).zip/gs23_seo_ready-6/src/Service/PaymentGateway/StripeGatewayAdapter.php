<?php
namespace GoodService\Service\PaymentGateway;

use GoodService\Service\StripeService;

/**
 * Thin adapter — delegates every call straight to StripeService. See
 * PaymentGatewayInterface's docblock for why this exists.
 */
final class StripeGatewayAdapter implements PaymentGatewayInterface {

    public static function key(): string { return 'stripe'; }
    public static function label(): string { return 'Stripe'; }
    public static function is_configured(): bool { return StripeService::is_configured(); }
    public static function test_connection(): array { return StripeService::test_connection(); }

    public static function create_payment( array $params ): array {
        $currency = (string) ( $params['currency'] ?? 'INR' );
        $amount_minor = (int) round( (float) ( $params['amount'] ?? 0 ) * 100 );
        $session = StripeService::create_checkout_session(
            $amount_minor,
            $currency,
            (string) ( $params['description'] ?? '' ),
            (string) ( $params['success_url'] ?? '' ),
            (string) ( $params['cancel_url'] ?? '' ),
            (array) ( $params['metadata'] ?? [] )
        );
        if ( $session === false || empty( $session['url'] ) ) {
            return [ 'success' => false, 'mode' => 'redirect', 'checkout' => [], 'error' => 'Could not create Stripe checkout session — see error log for details.' ];
        }
        return [
            'success' => true,
            'mode'    => 'redirect',
            'checkout' => [
                'url'        => $session['url'],
                'session_id' => $session['id'] ?? '',
            ],
            'error' => null,
        ];
    }

    public static function refund( string $payment_id, ?float $amount = null ): array {
        return StripeService::refund( $payment_id, $amount );
    }
}
