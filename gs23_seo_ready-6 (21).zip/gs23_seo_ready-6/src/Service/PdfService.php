<?php
namespace GoodService\Service;

/**
 * ENTERPRISE-AUDIT FIX (Part 2, Critical): "No PDF generation for invoices
 * --- only browser print-to-PDF." (audit_report.md, BillingService.php
 * render_invoice_html). There is no server-generated PDF for emailing as an
 * attachment or for accounting-system ingestion.
 *
 * Root cause: no PDF library exists in this codebase, and this environment
 * cannot vendor one in (composer/packagist and GitHub are both unreachable
 * from here — see the delivery notes). Rather than ship a fake/partial fix,
 * this is a small, dependency-free, pure-PHP PDF *writer* — it emits the raw
 * PDF file format directly (objects, cross-reference table, trailer) per the
 * PDF 1.4 spec, using only the 14 standard (always-available, no embedding
 * needed) core fonts. No composer, no external binary, nothing to install on
 * the production server — it works anywhere PHP runs.
 *
 * Deliberate scope/trade-off, documented rather than hidden: the standard
 * core fonts use WinAnsiEncoding, which has no glyph for the Indian Rupee
 * sign (₹, U+20B9) or other non-Latin-1 characters. BillingService::
 * render_invoice_pdf() therefore renders amounts with "Rs." instead of "₹"
 * in the PDF specifically (the HTML/print-to-PDF path is untouched and still
 * shows "₹" via UTF-8). This is a real, intentional trade-off — not a bug —
 * and is called out again at the call site.
 *
 * This is a generic single-purpose PDF *builder* (pages, text runs, lines,
 * filled rectangles) — not a general HTML-to-PDF renderer. It is built to
 * exactly the layout needs of an invoice document (see
 * BillingService::render_invoice_pdf()), with simple automatic pagination
 * when line items overflow one page.
 */
final class PdfService {

    /** Page dimensions in points (A4 @ 72dpi = 595.28 x 841.89). */
    private const PAGE_W = 595.28;
    private const PAGE_H = 841.89;

    private const CORE_FONTS = [
        'F1' => 'Helvetica',
        'F2' => 'Helvetica-Bold',
    ];

    /** @var array<int,array{content:string}> */
    private array $pages = [];
    private string $buf = '';
    private float $y = 0;
    private float $margin_left = 50;
    private float $margin_right = 50;
    private float $margin_bottom = 60;

    public function __construct() {
        $this->add_page();
    }

    public function add_page(): void {
        if ( $this->buf !== '' ) {
            $this->pages[] = [ 'content' => $this->buf ];
        }
        $this->buf = '';
        $this->y   = self::PAGE_H - 50;
    }

    public function cursor_y(): float { return $this->y; }
    public function set_cursor_y( float $y ): void { $this->y = $y; }

    /** Starts a new page if fewer than $needed points remain above the bottom margin. */
    public function ensure_space( float $needed ): void {
        if ( $this->y - $needed < $this->margin_bottom ) {
            $this->add_page();
        }
    }

    private function esc( string $s ): string {
        // WinAnsiEncoding covers Latin-1; anything outside it (emoji, ₹, etc.)
        // is transliterated to '?' by iconv rather than corrupting the stream.
        $converted = @iconv( 'UTF-8', 'CP1252//TRANSLIT//IGNORE', $s );
        if ( $converted === false ) { $converted = preg_replace( '/[^\x20-\x7E]/', '', $s ); }
        $converted = str_replace( [ '\\', '(', ')' ], [ '\\\\', '\\(', '\\)' ], $converted );
        return $converted;
    }

    public function text( float $x, float $y, string $str, float $size = 10, bool $bold = false ): void {
        $font = $bold ? 'F2' : 'F1';
        $this->buf .= sprintf(
            "BT /%s %.1F Tf %.2F %.2F Td (%s) Tj ET\n",
            $font, $size, $x, $y, $this->esc( $str )
        );
    }

    /** Right-aligned text — width is approximated (core-font metrics are fixed-ratio enough for money/labels). */
    public function text_right( float $right_x, float $y, string $str, float $size = 10, bool $bold = false ): void {
        $avg_char_w = $size * ( $bold ? 0.60 : 0.55 );
        $w = strlen( $str ) * $avg_char_w;
        $this->text( $right_x - $w, $y, $str, $size, $bold );
    }

    public function line( float $x1, float $y1, float $x2, float $y2, float $width = 0.75, string $hex = '#E2E8F0' ): void {
        [ $r, $g, $b ] = $this->hex_rgb( $hex );
        $this->buf .= sprintf(
            "%.2F %.2F %.2F RG %.2F w %.2F %.2F m %.2F %.2F l S\n",
            $r, $g, $b, $width, $x1, $y1, $x2, $y2
        );
    }

    public function rect( float $x, float $y, float $w, float $h, string $hex ): void {
        [ $r, $g, $b ] = $this->hex_rgb( $hex );
        $this->buf .= sprintf(
            "%.2F %.2F %.2F rg %.2F %.2F %.2F %.2F re f\n",
            $r, $g, $b, $x, $y, $w, $h
        );
    }

    private function hex_rgb( string $hex ): array {
        $hex = ltrim( $hex, '#' );
        if ( strlen( $hex ) === 3 ) { $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2]; }
        $hex = str_pad( $hex, 6, '0' );
        return [
            hexdec( substr( $hex, 0, 2 ) ) / 255,
            hexdec( substr( $hex, 2, 2 ) ) / 255,
            hexdec( substr( $hex, 4, 2 ) ) / 255,
        ];
    }

    public function page_width(): float { return self::PAGE_W; }
    public function content_left(): float { return $this->margin_left; }
    public function content_right(): float { return self::PAGE_W - $this->margin_right; }

    /** Simple word-wrap for a text block; returns array of lines that each fit within $max_width at $size. */
    public function wrap( string $text, float $max_width, float $size = 10 ): array {
        $avg_char_w = $size * 0.5;
        $max_chars  = max( 4, (int) floor( $max_width / $avg_char_w ) );
        $lines = [];
        foreach ( explode( "\n", $text ) as $para ) {
            $lines = array_merge( $lines, $this->wordwrap_line( $para, $max_chars ) );
        }
        return $lines ?: [ '' ];
    }

    private function wordwrap_line( string $line, int $max_chars ): array {
        if ( $line === '' ) { return [ '' ]; }
        $wrapped = wordwrap( $line, $max_chars, "\n", true );
        return explode( "\n", $wrapped );
    }

    /** Serializes the accumulated pages into a complete, valid PDF 1.4 byte string. */
    public function output(): string {
        if ( $this->buf !== '' || empty( $this->pages ) ) {
            $this->pages[] = [ 'content' => $this->buf ];
        }
        $objects = [];
        // 1: Catalog, 2: Pages (kids filled below)
        $page_count   = count( $this->pages );
        $font_obj_ids = [];
        $first_free   = 3;

        // Font objects (F1, F2)
        $font_id_map = [];
        $next_id = $first_free;
        foreach ( self::CORE_FONTS as $key => $base ) {
            $font_id_map[ $key ] = $next_id;
            $objects[ $next_id ] = "<< /Type /Font /Subtype /Type1 /BaseFont /{$base} /Encoding /WinAnsiEncoding >>";
            $next_id++;
        }

        // Content + Page objects
        $page_ids    = [];
        $content_ids = [];
        foreach ( $this->pages as $i => $p ) {
            $content_ids[ $i ] = $next_id;
            $stream = $p['content'];
            $objects[ $next_id ] = "<< /Length " . strlen( $stream ) . " >>\nstream\n{$stream}endstream";
            $next_id++;
        }
        foreach ( $this->pages as $i => $p ) {
            $page_ids[ $i ] = $next_id;
            $font_res = '';
            foreach ( $font_id_map as $key => $fid ) { $font_res .= "/{$key} {$fid} 0 R "; }
            $objects[ $next_id ] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " . self::PAGE_W . ' ' . self::PAGE_H . "] "
                . "/Resources << /Font << {$font_res}>> >> /Contents {$content_ids[$i]} 0 R >>";
            $next_id++;
        }

        // Object 1: Catalog, Object 2: Pages
        $kids = implode( ' ', array_map( fn( $id ) => "{$id} 0 R", $page_ids ) );
        $objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
        $objects[2] = "<< /Type /Pages /Kids [{$kids}] /Count {$page_count} >>";

        ksort( $objects );

        $pdf = "%PDF-1.4\n";
        $offsets = [];
        foreach ( $objects as $id => $body ) {
            $offsets[ $id ] = strlen( $pdf );
            $pdf .= "{$id} 0 obj\n{$body}\nendobj\n";
        }
        $xref_offset = strlen( $pdf );
        $max_id = max( array_keys( $objects ) );
        $pdf .= "xref\n0 " . ( $max_id + 1 ) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ( $id = 1; $id <= $max_id; $id++ ) {
            if ( isset( $offsets[ $id ] ) ) {
                $pdf .= sprintf( "%010d 00000 n \n", $offsets[ $id ] );
            } else {
                $pdf .= "0000000000 00000 f \n";
            }
        }
        $pdf .= "trailer\n<< /Size " . ( $max_id + 1 ) . " /Root 1 0 R >>\nstartxref\n{$xref_offset}\n%%EOF";
        return $pdf;
    }
}
