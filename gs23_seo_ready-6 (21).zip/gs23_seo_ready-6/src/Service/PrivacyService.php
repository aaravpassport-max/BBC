<?php
namespace GoodService\Service;

/**
 * PrivacyService — WordPress core "Export/Erase Personal Data" integration.
 *
 * FIXED — audit gap: this plugin stores 100% of its data in its own custom
 * gs_* tables, entirely outside WordPress's native user/postmeta system.
 * WordPress's built-in Tools > Export Personal Data / Erase Personal Data
 * screens (Settings > Privacy) only know about core WP data (comments,
 * user meta, etc.) unless a plugin explicitly registers exporter/eraser
 * callbacks via the wp_privacy_personal_data_exporters /
 * wp_privacy_personal_data_erasers filters. Before this fix, NO
 * gs_* table was ever included — meaning every "export my data" or
 * "erase my data" request an admin processed for a user silently omitted
 * every review, booking, saved listing, home-service record, and inquiry
 * that user had on this platform, regardless of how many were fulfilled.
 *
 * SCOPE — this is a real, bounded first implementation covering every
 * table with a genuine user_id foreign key (reviews, bookings,
 * saved_listings, home_profiles + its child service_records/reminders),
 * plus gs_leads matched by email (leads have no user_id column — a
 * customer can submit an inquiry without ever creating an account).
 * Vendor-side business data (a vendor's own listings, subscription
 * billing records, etc.) is deliberately NOT included here: a vendor
 * account's data is the vendor's own business record, not "personal
 * data" in the sense this WP screen is for, and erasing a vendor's
 * listings/invoices via a customer-facing privacy request would itself
 * be a data-integrity bug, not a fix. Extending coverage to additional
 * customer-identifiable tables as they're added is a mechanical
 * follow-up against this same pattern, not a redesign.
 *
 * ERASURE POLICY — reviews and bookings are ANONYMIZED (name/email/phone
 * blanked, content kept) rather than hard-deleted: the review text and
 * the fact a booking occurred are the vendor's own business/transaction
 * record and other customers' trust signal, not solely the requester's
 * data — this mirrors how WooCommerce and most real GDPR
 * implementations handle order/review erasure. Saved listings and the
 * Home Service OS profile (pure personal preference/tracking data with
 * no counterparty) are hard-deleted.
 */
final class PrivacyService {

    public static function register(): void {
        add_filter( 'wp_privacy_personal_data_exporters', [ self::class, 'register_exporter' ] );
        add_filter( 'wp_privacy_personal_data_erasers',   [ self::class, 'register_eraser' ] );
    }

    public static function register_exporter( array $exporters ): array {
        $exporters['goodservice-platform'] = [
            'exporter_friendly_name' => 'GoodService Platform',
            'callback'                => [ self::class, 'export_data' ],
        ];
        return $exporters;
    }

    public static function register_eraser( array $erasers ): array {
        $erasers['goodservice-platform'] = [
            'eraser_friendly_name' => 'GoodService Platform',
            'callback'              => [ self::class, 'erase_data' ],
        ];
        return $erasers;
    }

    /**
     * TRACE: WP core (Tools > Export Personal Data) → export_data($email,$page)
     *        → resolve $email to a WP user id (reviews/bookings/saved_listings/
     *        home_profiles are keyed by user_id, not email) → one SELECT per
     *        table, each page-limited → mapped into WP's required
     *        {group_id,group_label,item_id,data:[{name,value}]} shape.
     *        Preconditions: $email is a string WP core already validated
     *        belongs to a real user's export/erase request.
     *        Postconditions: returns ['data'=>[...], 'done'=>bool] — 'done'
     *        is true once every table for this user has been fully paged.
     *        Edge cases handled: no matching WP user (email-only lead
     *        submissions still export via gs_leads); a table not yet
     *        created on an un-upgraded install (SHOW TABLES guard); a user
     *        with zero rows in a given table (empty result, not an error).
     */
    public static function export_data( string $email, int $page = 1 ): array {
        global $wpdb;
        $page  = max( 1, $page );
        $limit = 200;
        $offset = ( $page - 1 ) * $limit;
        $user   = get_user_by( 'email', $email );
        $uid    = $user ? (int) $user->ID : 0;
        $data   = [];

        $add_group = function ( string $group_id, string $group_label, array $rows, callable $mapper ) use ( &$data ) {
            foreach ( $rows as $row ) {
                $data[] = [
                    'group_id'    => $group_id,
                    'group_label' => $group_label,
                    'item_id'     => $group_id . '-' . ( $row->id ?? uniqid() ),
                    'data'        => $mapper( $row ),
                ];
            }
        };

        if ( $uid ) {
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_reviews'" ) ) {
                $rows = $wpdb->get_results( $wpdb->prepare(
                    "SELECT id, rating, review_text, reviewer_name, reviewer_email, reviewer_phone, created_at
                     FROM {$wpdb->prefix}gs_reviews WHERE user_id=%d ORDER BY id LIMIT %d OFFSET %d",
                    $uid, $limit, $offset
                ) ) ?: [];
                $add_group( 'gs-reviews', 'Reviews You Wrote', $rows, fn( $r ) => [
                    [ 'name' => 'Rating',   'value' => (string) $r->rating ],
                    [ 'name' => 'Review',   'value' => (string) $r->review_text ],
                    [ 'name' => 'Name used','value' => (string) $r->reviewer_name ],
                    [ 'name' => 'Email used','value' => (string) $r->reviewer_email ],
                    [ 'name' => 'Phone used','value' => (string) $r->reviewer_phone ],
                    [ 'name' => 'Date',     'value' => (string) $r->created_at ],
                ] );
            }

            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_bookings'" ) ) {
                $rows = $wpdb->get_results( $wpdb->prepare(
                    "SELECT id, service_name, customer_name, customer_phone, customer_email, booking_date, booking_time, status, created_at
                     FROM {$wpdb->prefix}gs_bookings WHERE user_id=%d ORDER BY id LIMIT %d OFFSET %d",
                    $uid, $limit, $offset
                ) ) ?: [];
                $add_group( 'gs-bookings', 'Your Bookings', $rows, fn( $r ) => [
                    [ 'name' => 'Service',  'value' => (string) $r->service_name ],
                    [ 'name' => 'Name used','value' => (string) $r->customer_name ],
                    [ 'name' => 'Phone used','value' => (string) $r->customer_phone ],
                    [ 'name' => 'Email used','value' => (string) $r->customer_email ],
                    [ 'name' => 'Date',     'value' => (string) $r->booking_date . ' ' . $r->booking_time ],
                    [ 'name' => 'Status',   'value' => (string) $r->status ],
                    [ 'name' => 'Created',  'value' => (string) $r->created_at ],
                ] );
            }

            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_saved_listings'" ) ) {
                $rows = $wpdb->get_results( $wpdb->prepare(
                    "SELECT sl.id, sl.created_at, l.title FROM {$wpdb->prefix}gs_saved_listings sl
                     LEFT JOIN {$wpdb->prefix}gs_listings l ON l.id = sl.listing_id
                     WHERE sl.user_id=%d ORDER BY sl.id LIMIT %d OFFSET %d",
                    $uid, $limit, $offset
                ) ) ?: [];
                $add_group( 'gs-saved-listings', 'Saved Listings', $rows, fn( $r ) => [
                    [ 'name' => 'Listing', 'value' => (string) ( $r->title ?? '(deleted listing)' ) ],
                    [ 'name' => 'Saved on','value' => (string) $r->created_at ],
                ] );
            }

            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_home_profiles'" ) ) {
                $profiles = $wpdb->get_results( $wpdb->prepare(
                    "SELECT id, property_name, address, city, pincode, created_at
                     FROM {$wpdb->prefix}gs_home_profiles WHERE user_id=%d ORDER BY id LIMIT %d OFFSET %d",
                    $uid, $limit, $offset
                ) ) ?: [];
                $add_group( 'gs-home-profiles', 'Home Service OS — Properties', $profiles, fn( $r ) => [
                    [ 'name' => 'Property', 'value' => (string) $r->property_name ],
                    [ 'name' => 'Address',  'value' => (string) $r->address ],
                    [ 'name' => 'City',     'value' => (string) $r->city ],
                    [ 'name' => 'Pincode',  'value' => (string) $r->pincode ],
                    [ 'name' => 'Created',  'value' => (string) $r->created_at ],
                ] );

                if ( $profiles && $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_service_records'" ) ) {
                    $pids = implode( ',', array_map( 'intval', wp_list_pluck( $profiles, 'id' ) ) );
                    $recs = $wpdb->get_results(
                        "SELECT id, service_title, vendor_name, amount_paid, service_date
                         FROM {$wpdb->prefix}gs_service_records WHERE property_id IN ({$pids}) ORDER BY id"
                    ) ?: [];
                    $add_group( 'gs-service-records', 'Home Service OS — Service History', $recs, fn( $r ) => [
                        [ 'name' => 'Service', 'value' => (string) $r->service_title ],
                        [ 'name' => 'Vendor',  'value' => (string) $r->vendor_name ],
                        [ 'name' => 'Amount',  'value' => (string) $r->amount_paid ],
                        [ 'name' => 'Date',    'value' => (string) $r->service_date ],
                    ] );
                }
            }
        }

        // Leads have no user_id column (an inquiry can be submitted without an
        // account), so this is matched by email regardless of $uid above.
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_leads'" ) ) {
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT id, name, phone, message, city, status, created_at
                 FROM {$wpdb->prefix}gs_leads WHERE email=%s ORDER BY id LIMIT %d OFFSET %d",
                $email, $limit, $offset
            ) ) ?: [];
            $add_group( 'gs-leads', 'Inquiries You Sent', $rows, fn( $r ) => [
                [ 'name' => 'Name used', 'value' => (string) $r->name ],
                [ 'name' => 'Phone used','value' => (string) $r->phone ],
                [ 'name' => 'Message',   'value' => (string) $r->message ],
                [ 'name' => 'City',      'value' => (string) $r->city ],
                [ 'name' => 'Status',    'value' => (string) $r->status ],
                [ 'name' => 'Date',      'value' => (string) $r->created_at ],
            ] );
        }

        // Exhaustion check: every group above is queried with the same
        // $page/$limit/$offset, so once a page comes back with zero rows
        // across every group, there is nothing left to page through.
        return [ 'data' => $data, 'done' => empty( $data ) ];
    }

    /**
     * TRACE: WP core (Tools > Erase Personal Data, after admin confirms) →
     *        erase_data($email,$page) → resolve email to WP user id →
     *        reviews/bookings: UPDATE to blank out name/email/phone columns
     *        only (content/rating/status kept intact) → saved_listings/
     *        home_profiles(+service_records+reminders): DELETE outright →
     *        leads: UPDATE to blank name/phone/message, matched by email.
     *        Preconditions: none beyond a valid $email — safe to call even
     *        for a user with zero rows in every table (each guarded by
     *        SHOW TABLES + affects 0 rows silently, which is correct, not
     *        an error).
     *        Postconditions: returns WP's required
     *        {items_removed,items_retained,messages,done} shape; items_removed
     *        is true if ANY row was touched across all groups this call.
     *        Edge cases handled: a table missing on an un-upgraded install;
     *        a user with no WP account (leads-by-email erasure still runs).
     */
    public static function erase_data( string $email, int $page = 1 ): array {
        global $wpdb;
        $user = get_user_by( 'email', $email );
        $uid  = $user ? (int) $user->ID : 0;
        $items_removed = false;
        $messages = [];

        if ( $uid ) {
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_reviews'" ) ) {
                $n = $wpdb->query( $wpdb->prepare(
                    "UPDATE {$wpdb->prefix}gs_reviews SET reviewer_name='Deleted User', reviewer_email='', reviewer_phone='' WHERE user_id=%d",
                    $uid
                ) );
                if ( $n ) { $items_removed = true; $messages[] = "Anonymized {$n} review(s) — the review content itself was kept as the vendor's business record."; }
            }
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_bookings'" ) ) {
                $n = $wpdb->query( $wpdb->prepare(
                    "UPDATE {$wpdb->prefix}gs_bookings SET customer_name='Deleted User', customer_phone='', customer_email='' WHERE user_id=%d",
                    $uid
                ) );
                if ( $n ) { $items_removed = true; $messages[] = "Anonymized {$n} booking(s) — the transaction record itself was kept as the vendor's business record."; }
            }
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_saved_listings'" ) ) {
                $n = $wpdb->delete( $wpdb->prefix . 'gs_saved_listings', [ 'user_id' => $uid ] );
                if ( $n ) { $items_removed = true; $messages[] = "Deleted {$n} saved listing(s)."; }
            }
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_home_profiles'" ) ) {
                $pids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}gs_home_profiles WHERE user_id=%d", $uid ) );
                if ( $pids ) {
                    $pid_list = implode( ',', array_map( 'intval', $pids ) );
                    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_service_reminders'" ) ) {
                        $wpdb->query( "DELETE FROM {$wpdb->prefix}gs_service_reminders WHERE property_id IN ({$pid_list})" );
                    }
                    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_service_records'" ) ) {
                        $wpdb->query( "DELETE FROM {$wpdb->prefix}gs_service_records WHERE property_id IN ({$pid_list})" );
                    }
                    $n = $wpdb->delete( $wpdb->prefix . 'gs_home_profiles', [ 'user_id' => $uid ] );
                    if ( $n ) { $items_removed = true; $messages[] = "Deleted {$n} Home Service OS propert(y/ies) and its full service history."; }
                }
            }
        }

        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_leads'" ) ) {
            $n = $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->prefix}gs_leads SET name='Deleted User', phone='', message='' WHERE email=%s",
                $email
            ) );
            if ( $n ) { $items_removed = true; $messages[] = "Anonymized {$n} inquir(y/ies) sent to vendors."; }
        }

        return [
            'items_removed'  => $items_removed,
            'items_retained' => false,
            'messages'       => $messages,
            'done'           => true, // single-pass eraser — no pagination needed for UPDATE/DELETE-by-user_id
        ];
    }
}
