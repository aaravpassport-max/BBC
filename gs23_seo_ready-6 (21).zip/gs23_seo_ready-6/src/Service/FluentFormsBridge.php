<?php
namespace GoodService\Service;

use GoodService\Core\Cache;
use GoodService\Core\Config;
use GoodService\Core\EventBus;

/**
 * FluentFormsBridge — Fluent Forms → GoodService Inquiry Integration.
 *
 * When a visitor submits any Fluent Forms form that is linked to a listing
 * (via the fluent_form_id column on gs_listings), this service:
 *   1. Fuzzy-maps submitted fields to the GS lead schema.
 *   2. Creates a gs_leads record.
 *   3. Saves the customer message as the first gs_lead_replies entry.
 *   4. Sends a professional email notification to the vendor (Reply-To = customer).
 *   5. Sends an admin copy.
 *   6. Creates an in-app notification for the vendor.
 *   7. Fires an internal EventBus event.
 *
 * Supports Fluent Forms v1–v5 (hook name and argument shape differ between versions).
 */
final class FluentFormsBridge {

    /** Register WordPress hooks. Called once from Plugin::boot(). */
    public static function register(): void {
        // Fluent Forms v1–v4: fires (entry_id, form_data, form_object)
        add_action( 'fluentform_submission_inserted', [ self::class, 'on_submission_v4' ], 10, 3 );
        // Fluent Forms v5+: fires (entry_object, form_data, form_object)
        add_action( 'fluentform/submission_inserted', [ self::class, 'on_submission_v5' ], 10, 3 );
    }

    // ── Hook adapters ─────────────────────────────────────────────────────────

    public static function on_submission_v4( $entry_id, array $form_data, object $form ): void {
        self::process( (int) $entry_id, $form_data, (int) $form->id );
    }

    public static function on_submission_v5( $entry, array $form_data, object $form ): void {
        $entry_id = is_object( $entry ) ? (int) ( $entry->id ?? 0 ) : (int) $entry;
        self::process( $entry_id, $form_data, (int) $form->id );
    }

    // ── Core processor ────────────────────────────────────────────────────────

    /**
     * Main processing pipeline: map → insert → notify.
     *
     * @param int   $entry_id    Fluent Forms entry ID (for cross-reference).
     * @param array $form_data   Raw submitted field data (key => value).
     * @param int   $ff_form_id  Fluent Forms form ID.
     */
    private static function process( int $entry_id, array $form_data, int $ff_form_id ): void {
        if ( ! $ff_form_id ) return;

        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        // ── 1. Resolve which active listing uses this form ────────────────────
        $listing = $wpdb->get_row( $wpdb->prepare(
            "SELECT l.*,
                    vp.id          AS vendor_profile_id,
                    vp.user_id     AS vendor_user_id,
                    vp.business_name,
                    vp.email       AS vendor_profile_email,
                    u.user_email   AS vendor_wp_email
             FROM {$pfx}listings l
             JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
             JOIN {$wpdb->prefix}users u ON u.ID = vp.user_id
             WHERE l.fluent_form_id = %d AND l.status = 'active'
             LIMIT 1",
            $ff_form_id
        ) );
        // Note: $listing->email, $listing->phone, $listing->whatsapp are the
        // Vendor SITE contact details (from gs_listings) and always take
        // precedence over the Vendor-level profile contact details.

        if ( ! $listing ) return; // No active GoodService listing linked to this form

        // ── 2. Fuzzy-map form fields to our lead schema ───────────────────────
        // Fetch Admin Field Labels from Fluent Forms DB so that unmatched fields
        // stored in extra_fields use the human-readable label from the form builder
        // (e.g. "How did you hear about us?") rather than the raw key ("dropdown_1").
        $field_labels = self::get_ff_field_labels( $ff_form_id );
        $mapped   = self::map_fields( $form_data, $field_labels );
        $name     = sanitize_text_field( $mapped['name']    ?: 'Anonymous' );
        $email    = sanitize_email(      $mapped['email']   ?: '' );
        $phone    = sanitize_text_field( $mapped['phone']   ?: '' );
        $city     = sanitize_text_field( $mapped['city']    ?: '' );
        $company  = sanitize_text_field( $mapped['company'] ?: '' );
        $product  = sanitize_text_field( $mapped['product'] ?: $listing->title );
        $qty      = sanitize_text_field( $mapped['quantity'] ?: '' );
        $price    = sanitize_text_field( $mapped['price']   ?: '' );
        $message  = sanitize_textarea_field( $mapped['message'] ?: '' );
        $extra    = $mapped['extra_fields'] ?? [];  // unmatched fields

        // ── 3. Insert the lead record ─────────────────────────────────────────
        $__gs_ok = $wpdb->insert( $pfx . 'leads', [
            'listing_id'      => (int) $listing->id,
            'vendor_id'       => (int) $listing->vendor_profile_id,
            'fluent_entry_id' => $entry_id,
            'name'            => $name,
            'company_name'    => $company,
            'phone'           => $phone,
            'email'           => $email,
            'city'            => $city,
            'product_name'    => $product,
            'quantity'        => $qty,
            'product_price'   => $price,
            'message'         => $message,
            'extra_fields'    => $extra ? wp_json_encode( $extra ) : null,
            'source'          => 'fluent_form',
            'status'          => 'new',
            'priority'        => 'normal',
            'is_starred'      => 0,
            'ip_address'      => gs_get_ip(),
            'user_agent'      => substr( $_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500 ),
            'created_at'      => current_time( 'mysql' ),
            'updated_at'      => current_time( 'mysql' ),
        ] );

        // Ghost-success fix: this insert's result was previously discarded
        // entirely — a DB failure would fall through with a stale/zero
        // insert_id and silently never record the Fluent Forms submission
        // as a lead, with no error surfaced anywhere.
        if ( ! $__gs_ok ) { gs_write_log( 'FluentFormsBridge: lead insert failed: ' . $wpdb->last_error, 'ERROR' ); return; }
        $lead_id = (int) $wpdb->insert_id;
        if ( ! $lead_id ) return;

        // ── 4. Save customer's opening message as first reply entry ──────────
        if ( $message ) {
            $wpdb->insert( $pfx . 'lead_replies', [
                'lead_id'     => $lead_id,
                'sender_type' => 'customer',
                'sender_id'   => 0,
                'sender_name' => $name,
                'message'     => $message,
                'is_internal' => 0,
                'sent_via'    => 'form',
                'sent_at'     => current_time( 'mysql' ),
                'created_at'  => current_time( 'mysql' ),
            ] );
        }

        // ── 5. Increment listing lead counter ─────────────────────────────────
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$pfx}listings SET leads_count = leads_count + 1 WHERE id = %d",
            (int) $listing->id
        ) );

        // ── 6. Auto-create / find customer account & auto-login ─────────────
        // If the customer provided an email we create (or locate) a WordPress
        // user for them, link this lead to their account, and silently log them
        // in so that after the Fluent Forms confirmation page they are already
        // authenticated and can visit /my-account/ to see all their inquiries.
        if ( $email ) {
            self::handle_customer_account( $lead_id, $name, $email, $phone, $city, $company );
        }

        // ── 7. Send vendor email notification ─────────────────────────────────
        // Priority: Vendor Site email (listing) → Vendor profile email → WP user email.
        // This ensures notifications go to the correct business location's inbox.
        $vendor_email = sanitize_email(
            $listing->email ?: $listing->vendor_profile_email ?: $listing->vendor_wp_email
        );
        if ( $vendor_email ) {
            self::send_vendor_email(
                $vendor_email, $listing, $lead_id,
                $name, $company, $phone, $email, $city, $product, $qty, $price, $message, $extra
            );
        }

        // ── 7. Send admin notification email ─────────────────────────────────
        $admin_email = sanitize_email( Config::get( 'admin_email', get_option( 'admin_email' ) ) );
        if ( $admin_email && $admin_email !== $vendor_email ) {
            self::send_admin_email(
                $admin_email, $listing, $lead_id,
                $name, $company, $phone, $email, $city, $product, $qty, $price, $message
            );
        }

        // ── 8. In-app notification (bell icon) ────────────────────────────────
        NotificationService::create(
            (int) $listing->vendor_user_id,
            'lead.new',
            '📬 New Inquiry Received',
            "New inquiry from {$name}" . ( $product ? " for {$product}" : '' ),
            home_url( '/vendor/dashboard/?section=leads&view=' . $lead_id )
        );

        // ── 9. Cache invalidation ─────────────────────────────────────────────
        Cache::flush_group( 'leads' );
        Cache::delete( "leads:stats:{$listing->vendor_profile_id}" );

        // ── 10. Internal platform event ───────────────────────────────────────
        EventBus::emit( 'lead.created', [
            'lead_id'        => $lead_id,
            'vendor_user_id' => (int) $listing->vendor_user_id,
            'vendor_email'   => $vendor_email,
            'listing_title'  => $listing->title,
            'name'           => $name,
            'phone'          => $phone,
            'product_name'   => $product,
        ] );

        // ── AUTO-LOGIN: create/find WP user by email ─────────────────────────
        if ( $email && ! is_user_logged_in() ) {
            $existing = get_user_by( 'email', $email );
            if ( $existing ) {
                $auto_uid = $existing->ID;
            } else {
                $uname    = sanitize_user( strtolower( preg_replace( '/[^a-zA-Z0-9]/', '', $name ) ?: 'user' ) . '_' . wp_generate_password( 5, false ) );
                $auto_uid = wp_create_user( $uname, wp_generate_password( 14, false ), $email );
                if ( ! is_wp_error( $auto_uid ) ) {
                    $u = new \WP_User( $auto_uid );
                    $u->set_role( 'gs_customer' );
                    wp_update_user( [ 'ID' => $auto_uid, 'display_name' => $name ] );
                }
            }
            if ( isset( $auto_uid ) && ! is_wp_error( $auto_uid ) ) {
                wp_set_current_user( $auto_uid );
                wp_set_auth_cookie( $auto_uid, true );
            }
        }
    }

    // ── Field mapping ─────────────────────────────────────────────────────────

    /**
     * Returns true if the submitted field key is an internal Fluent Forms or
     * WordPress system field that should never appear in the lead record or the
     * inquiry detail panel.
     *
     * Skipped patterns:
     *  - Anything starting with _  → _wp_http_referer, _fluentform_*, _token
     *  - Anything containing "nonce" → fluentformnonce, wp_nonce, _nonce
     *  - Fluent Forms numeric form-ID keys → fluentform3, fluentform_3
     *  - Hidden internal fields → __fluent_form_embded_post_id, submit
     *  - CAPTCHA response fields → recaptcha, g-recaptcha, cf-turnstile, h-captcha
     *  - Common honeypot / bot-trap fields
     */
    private static function is_internal_ff_field( string $raw_key ): bool {
        // Lowercase the key once for case-insensitive matching
        $k = strtolower( $raw_key );

        // Fields starting with _ are always WordPress/Fluent internals
        if ( str_starts_with( $k, '_' ) ) { return true; }

        // Any field with "nonce" in its name is a security token
        if ( str_contains( $k, 'nonce' ) ) { return true; }

        // Fluent Forms embeds a hidden field named "fluentform<id>" (numeric suffix)
        if ( preg_match( '/^fluentform\d/i', $k ) ) { return true; }

        // Double-underscore Fluent Forms internal fields
        if ( str_starts_with( $k, '__fluent' ) ) { return true; }

        // Submit button value (not user data)
        if ( $k === 'submit' || $k === 'fluentform_submit' ) { return true; }

        // CAPTCHA response tokens from any provider
        if ( preg_match( '/^(g-recaptcha|recaptcha|cf-turnstile|h-captcha|hcaptcha)/', $k ) ) { return true; }

        // Common honeypot / hidden spam-trap names
        if ( in_array( $k, [ 'website', 'url', 'hp', 'honeypot', 'bot-field' ], true ) &&
             strlen( $raw_key ) <= 8 ) {
            // Short, common honeypot names — only skip if the label lookup also returns nothing
            // (genuine "website" fields usually have an admin label). Handled downstream.
        }

        return false;
    }

    /**
     * Fetch Admin Field Labels from the Fluent Forms database for a given form.
     *
     * Returns an associative array of [ field_name => admin_label ] so that
     * unmatched fields stored in extra_fields use the label the form builder
     * set (e.g. "How did you hear about us?") instead of the raw field key
     * (e.g. "dropdown_1").
     *
     * Gracefully returns [] if Fluent Forms is not installed, the table does
     * not exist, or the form cannot be found.
     *
     * @param  int   $ff_form_id  Fluent Forms form ID.
     * @return array              Map of field_name → admin label string.
     */
    private static function get_ff_field_labels( int $ff_form_id ): array {
        if ( ! $ff_form_id ) { return []; }
        global $wpdb;

        // Standard Fluent Forms table (all versions since v1)
        $table = $wpdb->prefix . 'fluentform_forms';

        // Use prepare() with LIKE so the table name is safely quoted
        if ( ! $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) ) {
            return []; // Fluent Forms not installed or table renamed
        }

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT form_fields FROM `{$table}` WHERE id = %d",
            $ff_form_id
        ) );
        if ( ! $row || empty( $row->form_fields ) ) { return []; }

        $parsed = @json_decode( $row->form_fields, true );
        if ( ! is_array( $parsed ) ) { return []; }

        $labels = [];
        $fields = $parsed['fields'] ?? [];
        if ( is_array( $fields ) ) {
            self::extract_field_labels( $fields, $labels );
        }

        return $labels;
    }

    /**
     * Recursively walk Fluent Forms field definitions and collect
     * field_name → admin_label pairs.
     *
     * Handles:
     *  - Simple elements (input_text, select, textarea, etc.)
     *  - Compound elements (input_name with first_name/last_name sub-fields)
     *  - Column/row layout wrappers that nest child fields
     *
     * Priority: admin_field_label (set in form builder) → label (visible label).
     *
     * @param  array  $fields   Raw "fields" array from Fluent Forms JSON.
     * @param  array &$labels   Running map being populated (passed by reference).
     */
    private static function extract_field_labels( array $fields, array &$labels ): void {
        foreach ( $fields as $field ) {
            if ( ! is_array( $field ) ) { continue; }

            $name  = $field['attributes']['name'] ?? '';
            $label = trim( $field['settings']['admin_field_label'] ?? '' );
            if ( $label === '' ) {
                $label = trim( $field['settings']['label'] ?? '' );
            }

            if ( $name !== '' && $label !== '' ) {
                $labels[ $name ] = $label;
            }

            // Compound elements (e.g. Full Name → first_name, last_name sub-fields)
            if ( ! empty( $field['fields'] ) && is_array( $field['fields'] ) ) {
                self::extract_field_labels( array_values( $field['fields'] ), $labels );
            }

            // Column/row layout wrappers
            if ( ! empty( $field['columns'] ) && is_array( $field['columns'] ) ) {
                foreach ( $field['columns'] as $col ) {
                    if ( ! empty( $col['fields'] ) && is_array( $col['fields'] ) ) {
                        self::extract_field_labels( $col['fields'], $labels );
                    }
                }
            }
        }
    }

    /**
     * Map raw Fluent Forms field data to GS lead schema columns.
     *
     * Matching is done by testing each submitted field key against a set of
     * regex patterns for each known column. Fields that match no pattern are
     * collected in 'extra_fields' so no data is ever discarded.
     *
     * When $field_labels is supplied (from get_ff_field_labels), unmatched
     * fields use the Admin Field Label defined in the form builder as their
     * display key — e.g. "How did you hear about us?" instead of "dropdown_1".
     * If no label is found for a key, the existing key-transformation fallback
     * (ucwords / separator replacement) is used, preserving backward compatibility.
     *
     * @param  array  $form_data    Raw submitted data (field_name => value).
     * @param  array  $field_labels Optional map of field_name => admin label
     *                              (from get_ff_field_labels). Default [] = no lookup.
     * @return array                Known columns + 'extra_fields' array.
     */
    public static function map_fields( array $form_data, array $field_labels = [] ): array {
        $result = [
            'name'         => '',
            'email'        => '',
            'phone'        => '',
            'city'         => '',
            'company'      => '',
            'product'      => '',
            'quantity'     => '',
            'price'        => '',
            'message'      => '',
            'extra_fields' => [],
        ];

        // Patterns are applied case-insensitively to the normalized field key.
        // More specific patterns come first to prevent wrong matches.
        $patterns = [
            'name'     => [ 'full.?name', 'your.?name', 'contact.?name', 'requester', 'applicant', 'customer.?name', 'name' ],
            'email'    => [ 'e[\-\.]?mail', 'email.?address', 'your.?email', 'mail' ],
            'phone'    => [ 'mobile', 'cell', 'contact.?number', 'whatsapp', 'call.?back', 'telephone', 'phone' ],
            'city'     => [ 'your.?city', 'location', 'district', 'locality', 'city', 'place', 'area', 'from' ],
            'company'  => [ 'organisation', 'organization', 'business.?name', 'company.?name', 'firm', 'enterprise', 'establishment', 'company' ],
            'product'  => [ 'product.?name', 'service.?name', 'item.?name', 'i.?need', 'looking.?for', 'interested.?in', 'product', 'service', 'item', 'require', 'request', 'interest', 'catalogue' ],
            'quantity' => [ 'order.?size', 'quantity', 'how.?many', 'pieces', 'units', 'volume', 'qty' ],
            'price'    => [ 'expected.?price', 'price.?range', 'budget.?range', 'how.?much', 'budget', 'price', 'rate', 'cost', 'amount' ],
            'message'  => [ 'requirement', 'more.?info', 'additional', 'anything.?else', 'comment', 'remark', 'tell.?us', 'enquiry', 'inquiry', 'detail', 'description', 'note', 'message' ],
        ];

        foreach ( $form_data as $raw_key => $raw_value ) {
            // ── Drop Fluent Forms internal / system fields first ──────────────
            // These are never user data (nonces, referer, form ID placeholders,
            // CAPTCHA tokens) and must never appear in the inquiry detail panel.
            if ( self::is_internal_ff_field( $raw_key ) ) { continue; }

            // Flatten arrays (e.g. checkboxes, multi-select)
            if ( is_array( $raw_value ) ) {
                $raw_value = implode( ', ', array_filter( $raw_value, 'is_scalar' ) );
            }
            $value = trim( (string) $raw_value );
            if ( $value === '' ) continue;

            // Normalise the key: lowercase, replace separators with space
            $key_norm = strtolower( preg_replace( '/[\-_.]+/', ' ', $raw_key ) );
            $matched  = false;

            foreach ( $patterns as $field => $keywords ) {
                foreach ( $keywords as $kw ) {
                    if ( preg_match( '/\b' . $kw . '\b/i', $key_norm ) ) {
                        if ( ! $result[ $field ] ) {
                            $result[ $field ] = $value;
                        }
                        $matched = true;
                        break 2; // pattern matched — move to next form field
                    }
                }
            }

            if ( ! $matched ) {
                // Use the Fluent Forms Admin Field Label when available (passed in from
                // get_ff_field_labels). This shows "How did you hear about us?" instead of
                // "dropdown_1" in the inquiry detail panel. Falls back to the existing
                // key-transformation (ucwords + separator replacement) for any field whose
                // name has no entry in the label map.
                $display_key = ( ! empty( $field_labels[ $raw_key ] ) )
                    ? $field_labels[ $raw_key ]
                    : ucwords( str_replace( [ '_', '-', '.' ], ' ', $raw_key ) );
                $result['extra_fields'][ $display_key ] = $value;
            }
        }

        return $result;
    }

    // ── Customer account ──────────────────────────────────────────────────────

    /**
     * Find or create a WordPress user for the customer, link the lead, and
     * silently log them in so they are authenticated after the form submission.
     *
     * New customer: creates a WP user with gs_customer role, generates a
     * password-reset link pointing at the custom /reset-password/ page, and
     * sends a welcome email so they can set their own password.
     *
     * Returning customer: just links the new lead to their existing user and
     * sends a brief "your inquiry was received" notification email.
     *
     * Auto-login: calls wp_set_auth_cookie() which sets the auth cookie in
     * the response headers of the Fluent Forms AJAX submission — on the next
     * page load the customer is authenticated.
     */
    private static function handle_customer_account(
        int $lead_id, string $name, string $email,
        string $phone, string $city, string $company
    ): void {
        if ( ! $email ) { return; }

        global $wpdb;
        $is_new = false;

        // 1. Find existing WP user
        $user = get_user_by( 'email', $email );

        if ( ! $user ) {
            // 2. Build a unique username from the email local-part
            $base = sanitize_user( strtolower( strstr( $email, '@', true ) ), true );
            if ( ! $base ) { $base = 'customer'; }
            $username = $base;
            $suffix   = 2;
            while ( username_exists( $username ) ) {
                $username = $base . $suffix++;
            }

            // 3. Create the account
            $user_id = wp_create_user( $username, wp_generate_password( 16, true, true ), $email );
            if ( is_wp_error( $user_id ) ) { return; }

            // 4. Assign role and display name
            $user_obj = new \WP_User( $user_id );
            $user_obj->set_role( 'gs_customer' );
            wp_update_user( [
                'ID'           => $user_id,
                'display_name' => $name ?: $username,
                'first_name'   => $name,
            ] );

            // 5. Store extra profile meta
            if ( $phone   ) { update_user_meta( $user_id, 'gs_phone',   $phone   ); }
            if ( $city    ) { update_user_meta( $user_id, 'gs_city',    $city    ); }
            if ( $company ) { update_user_meta( $user_id, 'gs_company', $company ); }

            $user   = get_user_by( 'id', $user_id );
            $is_new = true;
        }

        if ( ! $user || ! $user->ID ) { return; }

        // 6. Link this lead to the customer
        $wpdb->update(
            $wpdb->prefix . 'gs_leads',
            [ 'customer_user_id' => $user->ID ],
            [ 'id'               => $lead_id ],
            [ '%d' ], [ '%d' ]
        );

        // 7. Back-fill any previous unlinked leads from this email
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->prefix}gs_leads
             SET customer_user_id = %d
             WHERE email = %s AND (customer_user_id = 0 OR customer_user_id IS NULL)",
            $user->ID, $email
        ) );

        // 8. Auto-login: set the auth cookie in the current AJAX response.
        //    Fluent Forms submits via AJAX; the Set-Cookie headers we add here
        //    are returned to the browser, which stores them. On the very next
        //    page load the customer is already authenticated.
        if ( ! is_user_logged_in() ) {
            wp_set_auth_cookie( $user->ID, true ); // true = "remember me" (2 weeks)
            wp_set_current_user( $user->ID );
        }

        // 9. Send appropriate email to the customer
        if ( $is_new ) {
            // New account: generate a password-reset link so they can set their password
            $reset_key = get_password_reset_key( $user );
            $reset_url = ! is_wp_error( $reset_key )
                ? add_query_arg(
                    [ 'key' => $reset_key, 'login' => rawurlencode( $user->user_login ) ],
                    home_url( '/reset-password/' )
                )
                : home_url( '/vendor-login/' );

            self::send_customer_welcome_email(
                $user->user_email, $user->display_name,
                $user->user_login, $reset_url, $lead_id
            );
        } else {
            self::send_customer_inquiry_notification(
                $user->user_email, $user->display_name, $lead_id
            );
        }
    }

    /**
     * Send a welcome email to a newly-created customer, including a secure
     * link to set their password and a direct link to their inquiry dashboard.
     */
    private static function send_customer_welcome_email(
        string $to, string $name, string $username,
        string $reset_url, int $lead_id
    ): void {
        $platform  = Config::get( 'platform_name', get_bloginfo( 'name' ) );
        $dash_url  = home_url( '/my-account/?section=inquiries' );
        $subject   = "Your account on {$platform} — Set your password";

        $body = "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'></head>
<body style='margin:0;padding:20px;background:#F1F5F9;font-family:-apple-system,BlinkMacSystemFont,\"Segoe UI\",Roboto,Arial,sans-serif'>
<div style='max-width:540px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.09)'>
  <div style='background:linear-gradient(135deg,#1E3A5F 0%,#2563EB 100%);padding:28px;color:#fff'>
    <div style='font-size:.72rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;opacity:.65;margin-bottom:7px'>" . esc_html( $platform ) . "</div>
    <div style='font-size:1.25rem;font-weight:800'>👋 Welcome, " . esc_html( $name ?: $username ) . "!</div>
    <div style='font-size:.82rem;opacity:.72;margin-top:5px'>Your inquiry has been submitted and your account is ready.</div>
  </div>
  <div style='padding:24px 28px;font-size:.88rem;color:#334155;line-height:1.75'>
    <p>We've created an account for you so you can track all your inquiries in one place.</p>
    <p style='margin-top:12px'><strong>Username:</strong> " . esc_html( $username ) . "</p>
    <div style='margin:20px 0;text-align:center'>
      <a href='" . esc_url( $reset_url ) . "' style='display:inline-block;background:#2563EB;color:#fff;padding:13px 28px;border-radius:8px;font-weight:700;font-size:.92rem;text-decoration:none'>Set Your Password →</a>
    </div>
    <p style='font-size:.82rem;color:#64748B'>After setting your password you can log in anytime to view all your inquiries, saved listings, and track responses from businesses.</p>
    <div style='margin-top:16px;text-align:center'>
      <a href='" . esc_url( $dash_url ) . "' style='font-size:.82rem;color:#2563EB;text-decoration:none'>Go to My Account →</a>
    </div>
  </div>
  <div style='padding:14px 28px;background:#F8FAFC;border-top:1px solid #E2E8F0;font-size:.72rem;color:#94A3B8;text-align:center'>
    " . esc_html( $platform ) . " · <a href='" . esc_url( home_url( '/' ) ) . "' style='color:#2563EB;text-decoration:none'>Visit website</a>
  </div>
</div>
</body></html>";

        wp_mail( $to, $subject, $body, [ 'Content-Type: text/html; charset=UTF-8' ] );
    }

    /**
     * Send a brief "inquiry received" notification to an existing customer.
     */
    private static function send_customer_inquiry_notification(
        string $to, string $name, int $lead_id
    ): void {
        $platform = Config::get( 'platform_name', get_bloginfo( 'name' ) );
        $dash_url = home_url( '/my-account/?section=inquiries' );
        $subject  = "Your inquiry has been received — {$platform}";

        $body = "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'></head>
<body style='margin:0;padding:20px;background:#F1F5F9;font-family:-apple-system,sans-serif'>
<div style='max-width:520px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 16px rgba(0,0,0,.07)'>
  <div style='background:#1E293B;padding:20px 24px;color:#fff'>
    <div style='font-size:1rem;font-weight:700'>✅ Inquiry Received</div>
    <div style='font-size:.82rem;opacity:.6;margin-top:4px'>" . esc_html( $platform ) . "</div>
  </div>
  <div style='padding:20px 24px;font-size:.88rem;color:#334155;line-height:1.75'>
    <p>Hi " . esc_html( $name ) . ",</p>
    <p style='margin-top:10px'>Your inquiry has been successfully submitted. The business will review it and get back to you shortly.</p>
    <div style='margin:20px 0;text-align:center'>
      <a href='" . esc_url( $dash_url ) . "' style='display:inline-block;background:#2563EB;color:#fff;padding:11px 24px;border-radius:8px;font-weight:700;font-size:.88rem;text-decoration:none'>Track Your Inquiry →</a>
    </div>
  </div>
</div>
</body></html>";

        wp_mail( $to, $subject, $body, [ 'Content-Type: text/html; charset=UTF-8' ] );
    }

    // ── Email templates ───────────────────────────────────────────────────────

    /**
     * Send a professional HTML inquiry notification to the vendor.
     *
     * Critical: Reply-To is set to the customer's email so that hitting
     * "Reply" in any email client sends a message directly to the customer —
     * without the vendor needing to log into the dashboard.
     */
    private static function send_vendor_email(
        string $to, object $listing, int $lead_id,
        string $name, string $company, string $phone, string $customer_email,
        string $city, string $product, string $qty, string $price,
        string $message, array $extra
    ): void {
        $platform  = Config::get( 'platform_name', get_bloginfo( 'name' ) );
        $inq_no    = 'INQ-' . str_pad( $lead_id, 5, '0', STR_PAD_LEFT );
        $dash_url  = home_url( '/vendor/dashboard/?section=leads&view=' . $lead_id );
        $subject   = "New Inquiry: {$product} from {$name} [{$inq_no}]";

        // Build the info-card rows
        $info_rows = '';
        $fields    = array_filter( [
            'Customer Name'     => $name,
            'Company / Org'     => $company,
            'Mobile Number'     => $phone,
            'Email Address'     => $customer_email,
            'City / Location'   => $city,
            'Product / Service' => $product,
            'Quantity Required' => $qty,
            'Expected Budget'   => $price,
        ] );
        foreach ( $fields as $lbl => $val ) {
            $info_rows .= "<tr>
              <td style='padding:9px 14px;background:#F8FAFC;font-weight:600;font-size:.83rem;color:#475569;width:38%;border-bottom:1px solid #E2E8F0'>" . esc_html( $lbl ) . "</td>
              <td style='padding:9px 14px;font-size:.83rem;color:#1E293B;border-bottom:1px solid #E2E8F0'>" . esc_html( $val ) . "</td>
            </tr>";
        }
        // Extra / unmatched fields
        foreach ( $extra as $k => $v ) {
            $info_rows .= "<tr>
              <td style='padding:9px 14px;background:#F8FAFC;font-weight:600;font-size:.83rem;color:#475569;width:38%;border-bottom:1px solid #E2E8F0'>" . esc_html( $k ) . "</td>
              <td style='padding:9px 14px;font-size:.83rem;color:#1E293B;border-bottom:1px solid #E2E8F0'>" . esc_html( $v ) . "</td>
            </tr>";
        }

        $msg_block = $message
            ? "<div style='margin-top:20px;background:#F8FAFC;border-left:4px solid #2563EB;padding:14px 16px;border-radius:0 7px 7px 0;font-size:.87rem;color:#334155;line-height:1.75'>
                 <div style='font-size:.68rem;font-weight:700;color:#94A3B8;letter-spacing:.06em;text-transform:uppercase;margin-bottom:7px'>Message / Requirement</div>
                 " . nl2br( esc_html( $message ) ) . "
               </div>"
            : '';

        $wa_phone = preg_replace( '/[^0-9]/', '', $phone );
        $wa_text  = rawurlencode( "Hi {$name}, we received your inquiry for {$product} on {$platform}. We will get back to you shortly." );

        $quick_links = '';
        if ( $customer_email ) $quick_links .= "<a href='mailto:" . esc_attr( $customer_email ) . "?subject=" . rawurlencode( "Re: Your inquiry for {$product}" ) . "' style='font-size:.78rem;color:#2563EB;text-decoration:none;font-weight:600'>✉ Email {$name}</a>&nbsp;&nbsp;";
        if ( $phone )          $quick_links .= "<a href='tel:{$phone}' style='font-size:.78rem;color:#16A34A;text-decoration:none;font-weight:600'>📞 Call {$phone}</a>&nbsp;&nbsp;";
        if ( $wa_phone )       $quick_links .= "<a href='https://wa.me/{$wa_phone}?text={$wa_text}' style='font-size:.78rem;color:#16A34A;text-decoration:none;font-weight:600'>💬 WhatsApp</a>";

        $body = "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'></head>
<body style='margin:0;padding:20px;background:#F1F5F9;font-family:-apple-system,BlinkMacSystemFont,\"Segoe UI\",Roboto,Arial,sans-serif'>
<div style='max-width:580px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,.09)'>

  <div style='background:linear-gradient(135deg,#1E3A5F 0%,#2563EB 100%);padding:28px 28px 22px;color:#fff'>
    <div style='font-size:.72rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;opacity:.65;margin-bottom:7px'>" . esc_html( $platform ) . " · Inquiry {$inq_no}</div>
    <div style='font-size:1.3rem;font-weight:800;margin-bottom:4px'>📬 " . esc_html( $name ) . " sent you an inquiry</div>
    <div style='font-size:.8rem;opacity:.72'>for <strong>" . esc_html( $product ) . "</strong> · " . esc_html( current_time( 'd M Y, g:i A' ) ) . "</div>
  </div>

  <div style='padding:24px 28px'>
    <table style='width:100%;border-collapse:collapse;border:1px solid #E2E8F0;border-radius:8px;overflow:hidden;font-family:inherit'>{$info_rows}</table>
    {$msg_block}

    <div style='margin-top:24px;text-align:center'>
      <a href='" . esc_url( $dash_url ) . "' style='display:inline-block;background:#2563EB;color:#fff;padding:13px 32px;border-radius:8px;font-weight:700;font-size:.92rem;text-decoration:none;letter-spacing:.01em'>View &amp; Respond in Dashboard &rarr;</a>
    </div>

    <div style='margin-top:18px;padding:13px 16px;background:#F8FAFC;border-radius:8px;font-family:inherit'>
      <div style='font-size:.73rem;color:#64748B;font-weight:700;margin-bottom:6px;text-transform:uppercase;letter-spacing:.05em'>Quick Actions</div>
      <div style='display:flex;flex-wrap:wrap;gap:10px;align-items:center'>{$quick_links}</div>
    </div>
  </div>

  <div style='padding:14px 28px;background:#F8FAFC;border-top:1px solid #E2E8F0;font-size:.72rem;color:#94A3B8;text-align:center;line-height:1.7'>
    Sent by <strong>" . esc_html( $platform ) . "</strong> &nbsp;·&nbsp;
    <a href='" . esc_url( home_url( '/vendor/dashboard/' ) ) . "' style='color:#2563EB;text-decoration:none'>Your Dashboard</a>
    &nbsp;·&nbsp; This inquiry is automatically saved in your dashboard.
  </div>

</div>
</body></html>";

        wp_mail(
            $to,
            $subject,
            $body,
            [
                'Content-Type: text/html; charset=UTF-8',
                // Reply-To is set to the customer's email.
                // When the vendor hits Reply in their email client, the reply goes
                // DIRECTLY to the customer — without needing to visit the dashboard.
                'Reply-To: ' . sanitize_email( $customer_email ?: $to ),
            ]
        );
    }

    /**
     * Send admin copy of the inquiry notification.
     */
    private static function send_admin_email(
        string $to, object $listing, int $lead_id,
        string $name, string $company, string $phone, string $customer_email,
        string $city, string $product, string $qty, string $price, string $message
    ): void {
        $platform   = Config::get( 'platform_name', get_bloginfo( 'name' ) );
        $inq_no     = 'INQ-' . str_pad( $lead_id, 5, '0', STR_PAD_LEFT );
        $admin_url  = home_url( '/admin-panel/?section=leads' );
        $listing_url = home_url( '/' . ( $listing->slug ?? '' ) . '/' );
        $subject    = "[Admin] New Inquiry {$inq_no}: {$name} → {$listing->title}";

        $body = "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'></head>
<body style='margin:0;padding:20px;background:#F1F5F9;font-family:-apple-system,sans-serif'>
<div style='max-width:560px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 16px rgba(0,0,0,.07)'>
  <div style='background:#1E293B;padding:20px 24px;color:#fff'>
    <div style='font-size:.72rem;opacity:.5;letter-spacing:.07em;text-transform:uppercase;margin-bottom:4px'>Admin Alert · {$inq_no}</div>
    <div style='font-size:1.1rem;font-weight:700'>New Inquiry on " . esc_html( $platform ) . "</div>
  </div>
  <div style='padding:20px 24px;font-size:.86rem;color:#334155;line-height:1.85'>
    <b>Customer:</b> " . esc_html( $name ) . ( $company ? " — " . esc_html( $company ) : '' ) . "<br>
    <b>Phone:</b> " . esc_html( $phone ?: '—' ) . " &nbsp;&nbsp; <b>Email:</b> " . esc_html( $customer_email ?: '—' ) . "<br>
    <b>City:</b> " . esc_html( $city ?: '—' ) . "<br>
    <b>Product / Service:</b> " . esc_html( $product ) . "<br>
    " . ( $qty   ? "<b>Quantity:</b> " . esc_html( $qty )   . "<br>" : '' ) . "
    " . ( $price ? "<b>Budget:</b> "   . esc_html( $price ) . "<br>" : '' ) . "
    <br>
    <b>Listing:</b> <a href='" . esc_url( $listing_url ) . "' style='color:#2563EB'>" . esc_html( $listing->title ) . "</a><br>
    <b>Vendor:</b> " . esc_html( $listing->business_name ?? '—' ) . "<br>
    " . ( $message
        ? "<br><b>Message:</b><br><div style='background:#F8FAFC;padding:12px;border-radius:6px;margin-top:6px;line-height:1.7'>" . nl2br( esc_html( $message ) ) . "</div>"
        : '' ) . "
  </div>
  <div style='padding:14px 24px;background:#F8FAFC;border-top:1px solid #E2E8F0;text-align:center'>
    <a href='" . esc_url( $admin_url ) . "' style='background:#1E293B;color:#fff;padding:10px 24px;border-radius:7px;font-size:.84rem;font-weight:700;text-decoration:none;display:inline-block'>View in Admin Dashboard</a>
  </div>
</div>
</body></html>";

        wp_mail( $to, $subject, $body, [ 'Content-Type: text/html; charset=UTF-8' ] );
    }
}
