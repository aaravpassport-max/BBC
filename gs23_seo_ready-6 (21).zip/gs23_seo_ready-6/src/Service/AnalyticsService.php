<?php
namespace GoodService\Service;

use GoodService\Core\Cache;

final class AnalyticsService {

    /** Recalculate and return analytics for a vendor (called from job queue). */
    public static function recalculate( array $payload ): void {
        $vendor_id = (int) ( $payload['vendor_id'] ?? 0 );
        if ( ! $vendor_id ) { return; }
        Cache::delete( "analytics:vendor:{$vendor_id}:30" );
        Cache::delete( "analytics:vendor:{$vendor_id}:7" );
        Cache::delete( "analytics:vendor:{$vendor_id}:90" );
        Cache::delete( 'analytics:platform:30' );
        // Trigger fresh computation
        ( new \GoodService\Repository\AnalyticsRepository() )->vendor_summary( $vendor_id, 30 );
    }
}
