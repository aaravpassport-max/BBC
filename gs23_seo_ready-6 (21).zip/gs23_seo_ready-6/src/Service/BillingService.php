<?php
namespace GoodService\Service;

use GoodService\Core\Config;
use GoodService\Core\Helpers;

final class BillingService {

    /** Generate an invoice for a subscription. */
    public static function generate_invoice( int $subscription_id ): int|false {
        global $wpdb;
        $sub = $wpdb->get_row( $wpdb->prepare(
            "SELECT s.*, p.name AS plan_name
             FROM {$wpdb->prefix}gs_subscriptions s
             JOIN {$wpdb->prefix}gs_subscription_plans p ON p.id = s.plan_id
             WHERE s.id = %d",
            $subscription_id
        ) );
        if ( ! $sub ) { return false; }

        // Check no active invoice already exists for this subscription.
        // gs_invoices.status ENUM: 'draft','pending','paid','failed','refunded'
        // Block new invoice creation if one exists in draft, pending, or paid state.
        // Allow creation if all existing invoices are failed or refunded (those need replacement).
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_invoices
             WHERE subscription_id = %d AND status IN ('draft','pending','paid')
             ORDER BY id DESC LIMIT 1",
            $subscription_id
        ) );
        if ( $existing ) { return (int) $existing; }

        $gst_rate = (float) Config::get( 'gst_rate', 18 );
        $amount   = (float) $sub->amount;
        $tax      = round( $amount * $gst_rate / 100, 2 );
        $total    = round( $amount + $tax, 2 );

        $items = wp_json_encode( [ [
            'description' => $sub->plan_name . ' Plan — ' . ucfirst( $sub->billing_cycle ),
            'amount'      => $amount,
            'tax_rate'    => $gst_rate,
            'tax_amount'  => $tax,
            'total'       => $total,
        ] ] );

        // Ghost-success/wrong-ID fix: $wpdb->insert_id is not reset to 0 on a
        // failed insert — it retains whatever the last successful insert in
        // this request set it to. Both callers of this method (Razorpay/Stripe
        // subscription activation) call it immediately after inserting the new
        // subscription row, so a failed invoice insert here would previously
        // return the SUBSCRIPTION's own id disguised as an invoice id — the
        // caller would log/notify "invoice generated" for an invoice that was
        // never actually created, using the wrong numeric id. Checked directly
        // against insert()'s own return value instead.
        $inserted = $wpdb->insert( $wpdb->prefix . 'gs_invoices', [
            'invoice_no'      => Helpers::generate_invoice_number(),
            'vendor_id'       => (int) $sub->vendor_id,
            'subscription_id' => $subscription_id,
            'amount'          => $amount,
            'tax'             => $tax,
            'total'           => $total,           // ← correct column name: total
            'currency'        => Config::get( 'currency', 'INR' ),
            'status'          => 'paid',
            'payment_id'      => $sub->payment_id ?? '',
            'gateway'         => $sub->gateway    ?? '',
            'items'           => $items,
            'paid_at'         => current_time( 'mysql' ),
            'created_at'      => current_time( 'mysql' ),
        ] );
        if ( ! $inserted ) {
            gs_write_log( "BillingService: invoice insert FAILED for subscription {$subscription_id}: " . $wpdb->last_error, 'ERROR' );
            return false;
        }
        return (int) $wpdb->insert_id ?: false;
    }

    /** Validate a coupon and return discount amount. */
    public static function apply_coupon( string $code, float $amount ): array {
        global $wpdb;
        $coupon = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_coupons
             WHERE code = %s AND is_active = 1
               AND ( expires_at IS NULL OR expires_at > NOW() )",
            strtoupper( $code )
        ) );
        if ( ! $coupon ) { return [ 'valid' => false, 'message' => 'Invalid or expired coupon.' ]; }
        if ( $coupon->max_uses && (int) $coupon->uses_count >= (int) $coupon->max_uses ) {
            return [ 'valid' => false, 'message' => 'Coupon usage limit reached.' ];
        }
        if ( (float) $coupon->min_amount > 0 && $amount < (float) $coupon->min_amount ) {
            return [ 'valid' => false, 'message' => 'Minimum order amount not met.' ];
        }
        $discount = $coupon->type === 'percentage'
            ? round( $amount * (float) $coupon->value / 100, 2 )
            : min( (float) $coupon->value, $amount );

        // Usage count is NOT incremented here. apply_coupon() is called from
        // validateCoupon() (a live preview endpoint — called as the vendor types/
        // checks a code, potentially many times, before they commit to paying
        // anything) and from order-creation (before any payment has happened).
        // Incrementing usage at either point meant a limited-use coupon could be
        // exhausted entirely by people previewing it, with zero real purchases
        // behind any of those uses. use_coupon() is called exactly once, at the
        // point payment genuinely succeeds — see RazorpayService::activate_subscription().

        return [
            'valid'     => true,
            'discount'  => $discount,
            'final'     => max( 0, $amount - $discount ),
            'coupon'    => $coupon,
            'message'   => 'Coupon applied!',
        ];
    }

    /** Increment coupon use count. */
    public static function use_coupon( int $coupon_id ): void {
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->prefix}gs_coupons SET uses_count = uses_count + 1 WHERE id = %d",
            $coupon_id
        ) );
    }

    /**
     * Renders a complete, standalone, print-optimized HTML invoice
     * document for one invoice — real fix for "professionally generated
     * invoice": no PDF library (TCPDF/mPDF/Dompdf) exists anywhere in
     * this environment, and this codebase deliberately avoids Composer
     * dependencies elsewhere (see RazorpayService's own docblock on this).
     * Rather than silently doing nothing (the previous "PDF download
     * isn't available yet" toast), this generates a real, complete
     * invoice document using every field configured in Invoice & Billing
     * Settings — company name/logo/address/GSTIN/PAN/CIN/contact/terms/
     * payment notes — styled for both on-screen viewing and clean
     * printing. A browser's native Print → Save as PDF turns this into a
     * real PDF file with no server-side dependency at all.
     *
     * @param int $invoice_id
     * @param int $requesting_user_id  0 = skip the ownership check (admin/system context)
     * @return string|false  Full HTML document, or false if not found / not authorized
     */
    public static function render_invoice_html( int $invoice_id, int $requesting_user_id = 0 ): string|false {
        global $wpdb;
        $inv = $wpdb->get_row( $wpdb->prepare(
            "SELECT i.*, s.plan_name, s.billing_cycle
             FROM {$wpdb->prefix}gs_invoices i
             LEFT JOIN {$wpdb->prefix}gs_subscriptions s ON s.id = i.subscription_id
             WHERE i.id = %d", $invoice_id
        ) );
        if ( ! $inv ) { return false; }

        $vendor = \GoodService\Repository\VendorRepository::get_by_id( (int) $inv->vendor_id );
        if ( ! $vendor ) { return false; }

        // Ownership check — a vendor may only ever view their own
        // invoice; 0 explicitly opts out for admin/system contexts
        // (the caller is responsible for its own admin-capability check
        // before passing 0).
        if ( $requesting_user_id && (int) $vendor->user_id !== $requesting_user_id ) {
            return false;
        }

        $items = json_decode( (string) $inv->items, true );
        if ( ! is_array( $items ) || empty( $items ) ) {
            // Fallback for invoices created before line-item detail was
            // stored (e.g. the webhook path, or very early records) —
            // a single line reconstructed from the invoice totals
            // themselves, so the document is still complete rather than
            // showing an empty items table.
            $items = [ [
                'description' => $inv->plan_name ? ( $inv->plan_name . ' Plan' . ( $inv->billing_cycle ? ' — ' . ucfirst( $inv->billing_cycle ) : '' ) ) : 'Payment',
                'amount'      => (float) $inv->amount,
                'tax_rate'    => (float) Config::get( 'gst_rate', 18 ),
                'tax_amount'  => (float) $inv->tax,
                'total'       => (float) $inv->total,
            ] ];
        }

        $company_name    = Config::get( 'company_name', Config::get( 'platform_name', get_bloginfo( 'name' ) ) );
        $company_logo    = Config::get( 'invoice_logo_url', Config::get( 'logo_url', '' ) );
        $company_address = Config::get( 'company_address', '' );
        $gstin           = Config::get( 'platform_gstin', '' );
        $pan             = Config::get( 'platform_pan', '' );
        $cin             = Config::get( 'company_cin', '' );
        $phone           = Config::get( 'company_phone', '' );
        $email           = Config::get( 'company_email', get_option( 'admin_email' ) );
        $website         = Config::get( 'company_website', home_url( '/' ) );
        $tax_label       = Config::get( 'tax_label', 'GST' ) ?: 'GST';
        $terms           = Config::get( 'invoice_terms', '' );
        $payment_notes   = Config::get( 'invoice_payment_notes', '' );
        $footer_note     = Config::get( 'invoice_footer_note', '' );
        $currency_symbol = Config::get( 'currency_symbol', '₹' );

        $status_colors = [ 'paid' => '#059669', 'pending' => '#D97706', 'failed' => '#DC2626', 'refunded' => '#64748B', 'draft' => '#94A3B8' ];
        $status_color  = $status_colors[ $inv->status ] ?? '#64748B';

        ob_start();
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Invoice <?php echo esc_html( $inv->invoice_no ); ?></title>
<style>
  * { box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; color: #1E293B; margin: 0; padding: 40px; background: #F1F5F9; }
  .inv-sheet { max-width: 800px; margin: 0 auto; background: #fff; padding: 48px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,.08); }
  .inv-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 36px; padding-bottom: 28px; border-bottom: 2px solid #E2E8F0; }
  .inv-logo img { max-height: 56px; max-width: 220px; object-fit: contain; }
  .inv-company-name { font-size: 1.3rem; font-weight: 800; color: #0F172A; margin-top: 8px; }
  .inv-company-meta { font-size: .78rem; color: #64748B; line-height: 1.6; margin-top: 6px; white-space: pre-line; }
  .inv-title-block { text-align: right; }
  .inv-title { font-size: 1.6rem; font-weight: 900; color: #2563EB; letter-spacing: 1px; }
  .inv-no { font-size: .85rem; color: #475569; margin-top: 4px; font-weight: 600; }
  .inv-status { display: inline-block; margin-top: 10px; padding: 4px 14px; border-radius: 20px; font-size: .72rem; font-weight: 700; color: #fff; text-transform: uppercase; background: <?php echo esc_attr( $status_color ); ?>; }
  .inv-meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 32px; }
  .inv-meta-label { font-size: .68rem; font-weight: 700; color: #94A3B8; text-transform: uppercase; letter-spacing: .5px; margin-bottom: 6px; }
  .inv-meta-value { font-size: .88rem; color: #1E293B; line-height: 1.7; }
  table.inv-items { width: 100%; border-collapse: collapse; margin-bottom: 28px; }
  table.inv-items th { text-align: left; font-size: .72rem; text-transform: uppercase; color: #64748B; font-weight: 700; padding: 10px 12px; background: #F8FAFC; border-bottom: 2px solid #E2E8F0; }
  table.inv-items td { padding: 12px; font-size: .86rem; border-bottom: 1px solid #F1F5F9; }
  table.inv-items th:last-child, table.inv-items td:last-child { text-align: right; }
  .inv-totals { margin-left: auto; width: 280px; }
  .inv-totals-row { display: flex; justify-content: space-between; padding: 6px 0; font-size: .86rem; color: #475569; }
  .inv-totals-row.grand { border-top: 2px solid #E2E8F0; margin-top: 8px; padding-top: 12px; font-size: 1.15rem; font-weight: 800; color: #0F172A; }
  .inv-section { margin-top: 32px; padding-top: 20px; border-top: 1px solid #F1F5F9; }
  .inv-section-title { font-size: .72rem; font-weight: 700; color: #94A3B8; text-transform: uppercase; letter-spacing: .5px; margin-bottom: 8px; }
  .inv-section-body { font-size: .8rem; color: #475569; line-height: 1.6; white-space: pre-line; }
  .inv-footer { text-align: center; font-size: .74rem; color: #94A3B8; margin-top: 36px; padding-top: 20px; border-top: 1px solid #F1F5F9; }
  .print-bar { max-width: 800px; margin: 0 auto 16px; text-align: right; }
  .print-btn { background: #2563EB; color: #fff; border: none; padding: 10px 22px; border-radius: 8px; font-weight: 700; font-size: .85rem; cursor: pointer; }
  @media print { body { background: #fff; padding: 0; } .inv-sheet { box-shadow: none; border-radius: 0; padding: 20px; } .print-bar { display: none; } }
</style>
</head>
<body>
  <div class="print-bar"><button class="print-btn" onclick="window.print()">🖨️ Print / Save as PDF</button></div>
  <div class="inv-sheet">
    <div class="inv-top">
      <div class="inv-logo">
        <?php if ( $company_logo ): ?><img src="<?php echo esc_url( $company_logo ); ?>" alt="<?php echo esc_attr( $company_name ); ?>"><?php endif; ?>
        <div class="inv-company-name"><?php echo esc_html( $company_name ); ?></div>
        <div class="inv-company-meta"><?php
            $meta_lines = array_filter( [
                $company_address,
                $gstin ? "GSTIN: {$gstin}" : '',
                $pan ? "PAN: {$pan}" : '',
                $cin ? "CIN: {$cin}" : '',
                $phone ? "Phone: {$phone}" : '',
                $email ? "Email: {$email}" : '',
                $website ? "Web: {$website}" : '',
            ] );
            echo esc_html( implode( "\n", $meta_lines ) );
        ?></div>
      </div>
      <div class="inv-title-block">
        <div class="inv-title">INVOICE</div>
        <div class="inv-no"><?php echo esc_html( $inv->invoice_no ); ?></div>
        <div class="inv-status"><?php echo esc_html( ucfirst( $inv->status ) ); ?></div>
      </div>
    </div>

    <div class="inv-meta-grid">
      <div>
        <div class="inv-meta-label">Billed To</div>
        <div class="inv-meta-value">
          <strong><?php echo esc_html( $vendor->business_name ?: 'Vendor #' . $vendor->id ); ?></strong><br>
          <?php echo esc_html( trim( implode( ', ', array_filter( [ $vendor->address ?? '', $vendor->city ?? '', $vendor->state ?? '', $vendor->pincode ?? '' ] ) ) ) ) ?: '—'; ?><br>
          <?php echo $vendor->phone ? esc_html( $vendor->phone ) . '<br>' : ''; ?>
          <?php echo $vendor->email ? esc_html( $vendor->email ) : ''; ?>
          <?php // ENTERPRISE-AUDIT FIX (Part 3, High: "no billing/GSTIN
                // address field visible on invoices") — same fix as the PDF
                // renderer below; the vendor's own gst_number (already
                // settable in Profile) was never shown on this HTML view
                // either, which is what "View / Print" actually shows. ?>
          <?php if ( ! empty( $vendor->gst_number ) ): ?><br><strong>GSTIN:</strong> <?php echo esc_html( $vendor->gst_number ); ?><?php endif; ?>
        </div>
      </div>
      <div>
        <div class="inv-meta-label">Invoice Details</div>
        <div class="inv-meta-value">
          Date: <?php echo esc_html( date( 'd M Y', strtotime( $inv->created_at ) ) ); ?><br>
          <?php if ( $inv->paid_at ): ?>Paid On: <?php echo esc_html( date( 'd M Y', strtotime( $inv->paid_at ) ) ); ?><br><?php endif; ?>
          <?php if ( $inv->payment_id ): ?>Payment ID: <?php echo esc_html( $inv->payment_id ); ?><br><?php endif; ?>
          <?php if ( $inv->gateway ): ?>Gateway: <?php echo esc_html( ucfirst( $inv->gateway ) ); ?><?php endif; ?>
        </div>
      </div>
    </div>

    <table class="inv-items">
      <thead><tr><th>Description</th><th>Amount</th><th><?php echo esc_html( $tax_label ); ?></th><th>Total</th></tr></thead>
      <tbody>
      <?php foreach ( $items as $item ): ?>
        <tr>
          <td><?php echo esc_html( $item['description'] ?? '' ); ?></td>
          <td><?php echo esc_html( $currency_symbol ) . number_format( (float) ( $item['amount'] ?? 0 ), 2 ); ?></td>
          <td><?php echo esc_html( $currency_symbol ) . number_format( (float) ( $item['tax_amount'] ?? 0 ), 2 ); ?> <span style="color:#94A3B8">(<?php echo esc_html( (string) ( $item['tax_rate'] ?? 0 ) ); ?>%)</span></td>
          <td><?php echo esc_html( $currency_symbol ) . number_format( (float) ( $item['total'] ?? 0 ), 2 ); ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>

    <div class="inv-totals">
      <div class="inv-totals-row"><span>Subtotal</span><span><?php echo esc_html( $currency_symbol ) . number_format( (float) $inv->amount, 2 ); ?></span></div>
      <div class="inv-totals-row"><span><?php echo esc_html( $tax_label ); ?></span><span><?php echo esc_html( $currency_symbol ) . number_format( (float) $inv->tax, 2 ); ?></span></div>
      <div class="inv-totals-row grand"><span>Total</span><span><?php echo esc_html( $currency_symbol ) . number_format( (float) $inv->total, 2 ); ?></span></div>
    </div>

    <?php if ( $payment_notes ): ?>
    <div class="inv-section"><div class="inv-section-title">Payment Notes</div><div class="inv-section-body"><?php echo esc_html( $payment_notes ); ?></div></div>
    <?php endif; ?>

    <?php if ( $terms ): ?>
    <div class="inv-section"><div class="inv-section-title">Terms &amp; Conditions</div><div class="inv-section-body"><?php echo esc_html( $terms ); ?></div></div>
    <?php endif; ?>

    <div class="inv-footer">
      <?php echo $footer_note ? esc_html( $footer_note ) . '<br>' : ''; ?>
      This is a system-generated invoice from <?php echo esc_html( $company_name ); ?>.
    </div>
  </div>
</body>
</html>
        <?php
        return ob_get_clean();
    }

    /**
     * ENTERPRISE-AUDIT FIX (Part 2, Critical): "No PDF generation for
     * invoices --- only browser print-to-PDF." Real server-generated PDF
     * bytes, suitable for emailing as an attachment or for accounting-
     * system ingestion (neither was possible before — window.print() only
     * produces a PDF in the requesting user's own browser, at that
     * moment, with no server-side copy ever existing).
     *
     * Mirrors render_invoice_html()'s data-fetch and ownership check
     * exactly (0 = admin/system context, caller already capability-
     * checked) so the two documents always agree on what an invoice
     * contains.
     *
     * See PdfService's class doc for why this uses a small dependency-
     * free PDF writer instead of a library: composer/packagist and GitHub
     * are both unreachable from this build environment, so nothing could
     * be vendored in. One deliberate, documented trade-off from that: the
     * PDF's core fonts have no ₹ glyph, so amounts render with "Rs."
     * instead of "₹" here specifically — the HTML/print-to-PDF path is
     * unaffected and still shows "₹".
     *
     * @return string|false  Raw PDF bytes, or false if not found / not authorized
     */
    public static function render_invoice_pdf( int $invoice_id, int $requesting_user_id = 0 ): string|false {
        global $wpdb;
        $inv = $wpdb->get_row( $wpdb->prepare(
            "SELECT i.*, s.plan_name, s.billing_cycle
             FROM {$wpdb->prefix}gs_invoices i
             LEFT JOIN {$wpdb->prefix}gs_subscriptions s ON s.id = i.subscription_id
             WHERE i.id = %d", $invoice_id
        ) );
        if ( ! $inv ) { return false; }

        $vendor = \GoodService\Repository\VendorRepository::get_by_id( (int) $inv->vendor_id );
        if ( ! $vendor ) { return false; }

        if ( $requesting_user_id && (int) $vendor->user_id !== $requesting_user_id ) {
            return false;
        }

        $items = json_decode( (string) $inv->items, true );
        if ( ! is_array( $items ) || empty( $items ) ) {
            $items = [ [
                'description' => $inv->plan_name ? ( $inv->plan_name . ' Plan' . ( $inv->billing_cycle ? ' — ' . ucfirst( $inv->billing_cycle ) : '' ) ) : 'Payment',
                'amount'      => (float) $inv->amount,
                'tax_rate'    => (float) Config::get( 'gst_rate', 18 ),
                'tax_amount'  => (float) $inv->tax,
                'total'       => (float) $inv->total,
            ] ];
        }

        $company_name    = Config::get( 'company_name', Config::get( 'platform_name', get_bloginfo( 'name' ) ) );
        $company_address = Config::get( 'company_address', '' );
        $gstin           = Config::get( 'platform_gstin', '' );
        $pan             = Config::get( 'platform_pan', '' );
        $cin             = Config::get( 'company_cin', '' );
        $phone           = Config::get( 'company_phone', '' );
        $email           = Config::get( 'company_email', get_option( 'admin_email' ) );
        $tax_label       = Config::get( 'tax_label', 'GST' ) ?: 'GST';
        $terms           = Config::get( 'invoice_terms', '' );
        $payment_notes   = Config::get( 'invoice_payment_notes', '' );
        $footer_note     = Config::get( 'invoice_footer_note', '' );
        // Deliberately "Rs." not the configured currency_symbol — see method
        // doc: the PDF core fonts have no glyph for ₹ (or most non-Latin-1
        // symbols) so a configured "₹" would render as a broken/blank glyph.
        $cur = 'Rs. ';

        $pdf = new \GoodService\Service\PdfService();
        $left  = $pdf->content_left();
        $right = $pdf->content_right();

        // ── Header: company block (left) + INVOICE title block (right) ──────
        $pdf->text( $left, 780, $company_name, 15, true );
        $meta_lines = array_filter( [
            $company_address,
            $gstin ? "GSTIN: {$gstin}" : '',
            $pan ? "PAN: {$pan}" : '',
            $cin ? "CIN: {$cin}" : '',
            $phone ? "Phone: {$phone}" : '',
            $email ? "Email: {$email}" : '',
        ] );
        $my = 764;
        foreach ( $meta_lines as $line ) {
            foreach ( $pdf->wrap( $line, 260, 8 ) as $wl ) {
                $pdf->text( $left, $my, $wl, 8 );
                $my -= 11;
            }
        }
        $pdf->text_right( $right, 786, 'INVOICE', 18, true );
        $pdf->text_right( $right, 768, (string) $inv->invoice_no, 9, true );
        $pdf->text_right( $right, 754, strtoupper( (string) $inv->status ), 8, true );

        $pdf->line( $left, 738, $right, 738, 1.2, '#94A3B8' );

        // ── Billed To / Invoice Details ──────────────────────────────────────
        $by = 715;
        $pdf->text( $left, $by, 'BILLED TO', 8, true );
        $by -= 13;
        $pdf->text( $left, $by, $vendor->business_name ?: ( 'Vendor #' . $vendor->id ), 9, true );
        $by -= 12;
        $addr = trim( implode( ', ', array_filter( [ $vendor->address ?? '', $vendor->city ?? '', $vendor->state ?? '', $vendor->pincode ?? '' ] ) ) );
        foreach ( $pdf->wrap( $addr ?: '—', 260, 9 ) as $wl ) { $pdf->text( $left, $by, $wl, 9 ); $by -= 12; }
        if ( ! empty( $vendor->phone ) ) { $pdf->text( $left, $by, (string) $vendor->phone, 9 ); $by -= 12; }
        if ( ! empty( $vendor->email ) ) { $pdf->text( $left, $by, (string) $vendor->email, 9 ); $by -= 12; }
        // ENTERPRISE-AUDIT FIX (Part 3, High: "no billing/GSTIN address
        // field visible on invoices"). Root cause: gs_vendor_profiles.
        // gst_number already exists and vendors can already set it in their
        // own Profile settings (vendor-dashboard.php:1351) — it was simply
        // never read into this PDF. A vendor needs their OWN GSTIN on the
        // "Billed To" side to claim input tax credit on the subscription
        // fee; the platform's GSTIN in the header above is a different,
        // already-shown field (the seller's, not the buyer's).
        if ( ! empty( $vendor->gst_number ) ) { $pdf->text( $left, $by, 'GSTIN: ' . (string) $vendor->gst_number, 9, true ); $by -= 12; }

        $dx = $left + 300;
        $dy = 715;
        $pdf->text( $dx, $dy, 'INVOICE DETAILS', 8, true ); $dy -= 13;
        $pdf->text( $dx, $dy, 'Date: ' . date( 'd M Y', strtotime( (string) $inv->created_at ) ), 9 ); $dy -= 12;
        if ( ! empty( $inv->paid_at ) ) { $pdf->text( $dx, $dy, 'Paid On: ' . date( 'd M Y', strtotime( (string) $inv->paid_at ) ), 9 ); $dy -= 12; }
        if ( ! empty( $inv->payment_id ) ) { $pdf->text( $dx, $dy, 'Payment ID: ' . $inv->payment_id, 9 ); $dy -= 12; }
        if ( ! empty( $inv->gateway ) ) { $pdf->text( $dx, $dy, 'Gateway: ' . ucfirst( (string) $inv->gateway ), 9 ); $dy -= 12; }

        $y = min( $by, $dy ) - 20;

        // ── Line items table ─────────────────────────────────────────────────
        $col_desc = $left; $col_amt = $left + 260; $col_tax = $left + 370; $col_tot = $right;
        $draw_header = function () use ( $pdf, $left, $right, $col_desc, $col_amt, $col_tax, $col_tot, $tax_label, &$y ) {
            $pdf->ensure_space( 30 );
            $y = $pdf->cursor_y();
            $pdf->rect( $left, $y - 4, $right - $left, 18, '#F1F5F9' );
            $pdf->text( $col_desc + 4, $y, 'Description', 8, true );
            $pdf->text( $col_amt, $y, 'Amount', 8, true );
            $pdf->text( $col_tax, $y, $tax_label, 8, true );
            $pdf->text_right( $col_tot, $y, 'Total', 8, true );
            $y -= 20;
            $pdf->set_cursor_y( $y );
        };
        $pdf->set_cursor_y( $y );
        $draw_header();
        foreach ( $items as $item ) {
            // Page-break detection: capture the y ensure_space() saw BEFORE it
            // runs — if it triggers a new page, cursor_y() afterwards will be
            // the fresh page's top constant instead of what we just set, which
            // is how a page break is detected (rather than comparing floats
            // across arithmetic, which risks precision drift).
            $y_before_check = $y;
            $pdf->ensure_space( 16 );
            if ( abs( $pdf->cursor_y() - $y_before_check ) > 0.01 ) { $draw_header(); }
            $y = $pdf->cursor_y();
            $desc = (string) ( $item['description'] ?? '' );
            $pdf->text( $col_desc + 4, $y, mb_strimwidth( $desc, 0, 42, '…' ), 8 );
            $pdf->text( $col_amt, $y, $cur . number_format( (float) ( $item['amount'] ?? 0 ), 2 ), 8 );
            $pdf->text( $col_tax, $y, $cur . number_format( (float) ( $item['tax_amount'] ?? 0 ), 2 ) . ' (' . (string) ( $item['tax_rate'] ?? 0 ) . '%)', 7 );
            $pdf->text_right( $col_tot, $y, $cur . number_format( (float) ( $item['total'] ?? 0 ), 2 ), 8, true );
            $y -= 16;
            $pdf->set_cursor_y( $y );
        }
        $pdf->line( $left, $y + 6, $right, $y + 6, 0.75, '#E2E8F0' );
        $y -= 8;

        // ── Totals ────────────────────────────────────────────────────────────
        $pdf->ensure_space( 60 ); $y = $pdf->cursor_y();
        $pdf->text( $left + 300, $y, 'Subtotal', 9 );
        $pdf->text_right( $right, $y, $cur . number_format( (float) $inv->amount, 2 ), 9 );
        $y -= 14;
        $pdf->text( $left + 300, $y, $tax_label, 9 );
        $pdf->text_right( $right, $y, $cur . number_format( (float) $inv->tax, 2 ), 9 );
        $y -= 6;
        $pdf->line( $left + 300, $y, $right, $y, 1, '#0F172A' );
        $y -= 16;
        $pdf->text( $left + 300, $y, 'TOTAL', 11, true );
        $pdf->text_right( $right, $y, $cur . number_format( (float) $inv->total, 2 ), 11, true );
        $y -= 30;
        $pdf->set_cursor_y( $y );

        // ── Notes / terms / footer ──────────────────────────────────────────
        if ( $payment_notes ) {
            $pdf->ensure_space( 30 ); $y = $pdf->cursor_y();
            $pdf->text( $left, $y, 'PAYMENT NOTES', 8, true ); $y -= 12;
            foreach ( $pdf->wrap( $payment_notes, $right - $left, 8 ) as $wl ) { $pdf->text( $left, $y, $wl, 8 ); $y -= 11; }
            $y -= 8; $pdf->set_cursor_y( $y );
        }
        if ( $terms ) {
            $pdf->ensure_space( 30 ); $y = $pdf->cursor_y();
            $pdf->text( $left, $y, 'TERMS & CONDITIONS', 8, true ); $y -= 12;
            foreach ( $pdf->wrap( $terms, $right - $left, 8 ) as $wl ) { $pdf->text( $left, $y, $wl, 8 ); $y -= 11; }
            $y -= 8; $pdf->set_cursor_y( $y );
        }
        $pdf->ensure_space( 24 ); $y = $pdf->cursor_y();
        $footer_text = ( $footer_note ? $footer_note . ' — ' : '' ) . 'This is a system-generated invoice from ' . $company_name . '.';
        foreach ( $pdf->wrap( $footer_text, $right - $left, 7 ) as $wl ) { $pdf->text( $left, $y, $wl, 7 ); $y -= 10; }

        return $pdf->output();
    }
}
