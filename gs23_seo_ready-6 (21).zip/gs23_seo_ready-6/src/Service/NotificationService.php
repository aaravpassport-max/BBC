<?php
namespace GoodService\Service;

use GoodService\Core\Config;
use GoodService\Core\JobQueue;

/**
 * NotificationService — Full event-driven notification hub.
 * Handles in-app notifications, email queuing, and push delivery
 * for every platform event defined in the master implementation doc (Part 27).
 */
final class NotificationService {

    /**
     * ENTERPRISE-AUDIT FIX (Part 2, High): the full inventory of every
     * distinct admin-alert event currently fired via notify_admins(),
     * across RestApiController, EmailService, this class, ManualPlanService,
     * AjaxController, Cron, and EventBus — enumerated by grepping every
     * notify_admins() call site in the codebase. This is the source of
     * truth the admin "Alerts" settings screen renders its toggle list
     * from; a new call site should add its event key here so it shows up
     * in the UI (it is still delivered, defaulting to on, even if a
     * developer forgets — admin_alert_channel_enabled() defaults open).
     * 'diagnostic.test' (the Diagnostics panel's manual test-send tool) is
     * deliberately excluded — it is an explicit, user-triggered one-off
     * action, not a recurring alert an admin would ever want to silence.
     */
    public const ADMIN_ALERT_EVENTS = [
        'vendor.registered'                        => 'New vendor registered',
        'listing.pending'                           => 'New listing submitted for review',
        'listing.edited'                             => 'Live (already-approved) listing edited',
        'listing.suspended'                          => 'Listing suspended',
        'listing.restored'                           => 'Listing restored',
        'vendor.suspended'                           => 'Vendor suspended',
        'vendor.safety_doc_submitted'                => 'Vendor safety document submitted for review',
        'verification.doc_submitted'                 => 'Vendor verification document submitted',
        'complaint.submitted'                        => 'New complaint filed',
        'complaint.escalated'                        => 'Complaint SLA breached / auto-escalated',
        'dispute.opened'                             => 'New booking dispute opened',
        'payment.received'                           => 'Payment received',
        'payment.failed'                             => 'Vendor subscription payment failed',
        'subscription.cancelled'                     => 'Vendor subscription cancelled',
        'subscription.expired'                       => 'Vendor subscription expired',
        'subscription.downgraded_dunning'            => 'Vendor auto-downgraded (payment dunning expired)',
        'plan_request.submitted'                     => 'Manual (offline-payment) plan request submitted',
        'plan_request.scheduled_activation_failed'   => 'Scheduled manual plan activation failed',
        'booking.noshow'                             => 'Possible no-show booking detected',
        'booking.stuck'                               => 'Booking stuck in progress',
        'email.delivery_failed'                       => 'Critical transactional email failed to deliver',
    ];

    /**
     * Whether a given delivery channel is enabled for an admin-alert event.
     * Missing row = both channels on (matches every call site's hardcoded
     * behavior before this fix — zero regression for existing installs).
     * 'diagnostic.test' always returns true regardless of any stored row —
     * it must never be silenceable since it exists purely to let an admin
     * verify delivery is working.
     */
    public static function admin_alert_channel_enabled( string $event, string $channel ): bool {
        if ( $event === 'diagnostic.test' ) { return true; }
        global $wpdb;
        $tbl = $wpdb->prefix . 'gs_admin_alert_prefs';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) { return true; }
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$tbl} WHERE event_key=%s", $event
        ) );
        if ( ! $row ) { return true; }
        $col = $channel === 'email' ? 'email_enabled' : 'in_app_enabled';
        return (bool) $row->$col;
    }

    /** Create an in-app notification. */
    public static function create(
        int    $user_id,
        string $type,
        string $title,
        string $message  = '',
        string $url      = '',
        string $icon     = 'bell',
        string $color    = '#2563EB',
        array  $data     = []
    ): void {
        if ( ! $user_id ) { return; }
        global $wpdb;
        $inserted = $wpdb->insert( $wpdb->prefix . 'gs_notifications', [
            'user_id'    => $user_id,
            'type'       => $type,
            'title'      => $title,
            'message'    => $message,
            'action_url' => $url,
            'icon'       => $icon,
            'color'      => $color,
            'data'       => $data ? wp_json_encode( $data ) : null,
            'is_read'    => 0,
            'email_sent' => 0,
            'created_at' => current_time( 'mysql' ),
        ] );
        if ( ! $inserted && function_exists( 'gs_write_log' ) ) {
            gs_write_log( "NotificationService::create failed for user_id={$user_id} type={$type}: " . $wpdb->last_error );
        }
    }

    /** Check user preferences before sending. Returns true if channel is enabled. */
    private static function pref( int $user_id, string $event_type, string $channel ): bool {
        global $wpdb;
        $tbl = $wpdb->prefix . 'gs_notification_preferences';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) { return true; }
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$tbl} WHERE user_id=%d AND event_type=%s", $user_id, $event_type
        ) );
        if ( ! $row ) { return true; } // default on
        return (bool) $row->$channel;
    }

    /**
     * Public wrapper for pref() — needed by other services (like
     * VendorScorecardService) that must check a preference before
     * calling create() directly, since create() itself is unconditional
     * and every existing internal caller in this class checks pref()
     * first.
     */
    public static function should_send( int $user_id, string $event_type, string $channel ): bool {
        return self::pref( $user_id, $event_type, $channel );
    }

    /** Queue email only if user preference allows it. */
    public static function maybe_email( int $user_id, string $event_type, string $to, string $template, array $vars ): void {
        if ( ! $to || ! self::pref( $user_id, $event_type, 'email' ) ) { return; }
        JobQueue::push( 'send_email', [ 'to' => $to, 'template' => $template, 'vars' => $vars ] );
    }

    /** Queue push notification if user preference allows it. */
    public static function maybe_push( int $user_id, string $event_type, string $title, string $body, string $url = '', string $tag = '' ): void {
        if ( ! self::pref( $user_id, $event_type, 'push' ) ) { return; }
        self::send_push_notification( $user_id, $title, $body, $url, $tag );
    }

    /**
     * Send SMS if the user has explicitly opted in. Real feature —
     * reuses OtpService::send_sms(), the general-purpose (non-OTP) SMS
     * function already built as the WhatsApp fallback channel, rather
     * than a new gateway integration. Deliberately defaults OFF (unlike
     * email/push) — SMS costs per-message, unlike push (free) or
     * WhatsApp Business API's more favourable session-based pricing, so
     * this must be an explicit opt-in, never a silent-by-default cost.
     */
    public static function maybe_sms( int $user_id, string $event_type, string $phone, string $message ): void {
        if ( ! $phone || ! self::pref( $user_id, $event_type, 'sms' ) ) { return; }
        JobQueue::push( 'send_notification_sms', [ 'phone' => $phone, 'message' => mb_strimwidth( $message, 0, 160, '…' ) ] );
    }

    /** Send web push to all user subscriptions. */
    public static function send_push_notification( int $user_id, string $title, string $body, string $url = '', string $tag = '' ): void {
        global $wpdb;
        $tbl = $wpdb->prefix . 'gs_push_subscriptions';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) { return; }
        $subs = $wpdb->get_col( $wpdb->prepare( "SELECT subscription FROM {$tbl} WHERE user_id=%d", $user_id ) );
        if ( empty( $subs ) ) { return; }
        $payload = wp_json_encode( [
            'title' => $title,
            'body'  => $body,
            'url'   => $url ?: home_url( '/vendor/dashboard/' ),
            'tag'   => $tag ?: 'gs-' . time(),
        ] );
        foreach ( $subs as $sub_json ) {
            JobQueue::push( 'send_push', [
                'subscription'  => $sub_json,
                'payload'       => $payload,
                'vapid_public'  => get_option( 'gs_vapid_public_key' ),
                'vapid_private' => get_option( 'gs_vapid_private_key' ),
            ] );
        }
    }

    // ── Event handlers ────────────────────────────────────────────────────────

    public static function on_lead_created( array $d ): void {
        $vid  = (int) ( $d['vendor_user_id'] ?? 0 );
        $cid  = (int) ( $d['customer_user_id'] ?? 0 );
        if ( ! $vid ) { return; }

        // Vendor: in-app + email + push
        if ( self::pref( $vid, 'lead.new', 'in_app' ) ) {
            self::create( $vid, 'lead.new', '📞 New Inquiry',
                'From ' . ( $d['name'] ?? '' ) . ' — ' . ( $d['listing_title'] ?? '' ),
                home_url( '/vendor/dashboard/?section=leads' ), 'phone', '#2563EB' );
        }
        self::maybe_email( $vid, 'lead.new', $d['vendor_email'] ?? '', 'new_lead', $d );
        self::maybe_push( $vid, 'lead.new', '📞 New Inquiry', ( $d['name'] ?? 'A client' ) . ' sent you an inquiry', home_url( '/vendor/dashboard/?section=leads' ), 'lead.new' );
        self::maybe_sms( $vid, 'lead.new', $d['vendor_phone'] ?? '', 'New inquiry from ' . ( $d['name'] ?? 'a client' ) . ' — check your GoodService dashboard.' );

        // Client: confirmation email + WhatsApp acknowledgement
        if ( $cid && ! empty( $d['customer_email'] ) ) {
            self::maybe_email( $cid, 'lead.confirmed', $d['customer_email'], 'inquiry_confirmed_client', $d );
        }
        WhatsAppService::send_inquiry_acknowledgement( $d );
    }

    public static function on_vendor_replied( array $d ): void {
        $cid = (int) ( $d['customer_user_id'] ?? 0 );
        if ( ! $cid ) { return; }
        if ( self::pref( $cid, 'lead.replied', 'in_app' ) ) {
            self::create( $cid, 'lead.replied', '💬 Vendor Replied',
                ( $d['vendor_name'] ?? 'Your vendor' ) . ' replied to your inquiry',
                home_url( '/my-account/?section=inquiries' ), 'message-circle', '#2563EB' );
        }
        self::maybe_email( $cid, 'lead.replied', $d['customer_email'] ?? '', 'vendor_replied', $d );
        self::maybe_push( $cid, 'lead.replied', '💬 ' . ( $d['vendor_name'] ?? 'Vendor' ) . ' replied!', 'Tap to view their message', home_url( '/my-account/?section=inquiries' ), 'lead.replied' );
    }

    public static function on_quote_sent( array $d ): void {
        $cid = (int) ( $d['customer_user_id'] ?? 0 );
        if ( ! $cid ) { return; }
        if ( self::pref( $cid, 'quote.received', 'in_app' ) ) {
            self::create( $cid, 'quote.received', '📋 Quote Received',
                ( $d['vendor_name'] ?? 'A vendor' ) . ' sent you a quote for ₹' . number_format( (float)( $d['total'] ?? 0 ) ),
                home_url( '/my-account/?section=inquiries' ), 'file-text', '#7C3AED' );
        }
        self::maybe_email( $cid, 'quote.received', $d['customer_email'] ?? '', 'quote_sent', $d );
        self::maybe_push( $cid, 'quote.received', '📋 New Quote Received', '₹' . number_format( (float)( $d['total'] ?? 0 ) ) . ' from ' . ( $d['vendor_name'] ?? 'vendor' ), home_url( '/my-account/?section=inquiries' ), 'quote' );
    }

    public static function on_quote_accepted( array $d ): void {
        $vid = (int) ( $d['vendor_user_id'] ?? 0 );
        if ( ! $vid ) { return; }
        if ( self::pref( $vid, 'quote.accepted', 'in_app' ) ) {
            self::create( $vid, 'quote.accepted', '🎉 Quote Accepted!',
                ( $d['client_name'] ?? 'Client' ) . ' accepted your quote for ₹' . number_format( (float)( $d['total'] ?? 0 ) ),
                home_url( '/vendor/dashboard/?section=leads' ), 'check-circle', '#059669' );
        }
        self::maybe_email( $vid, 'quote.accepted', $d['vendor_email'] ?? '', 'quote_accepted', $d );
        self::maybe_push( $vid, 'quote.accepted', '🎉 Quote Accepted!', ( $d['client_name'] ?? 'Client' ) . ' accepted your quote', home_url( '/vendor/dashboard/?section=leads' ), 'quote.accepted' );
    }

    /**
     * In-app dashboard notification for a new plain inquiry (not a booking --
     * see on_booking_confirmed() below, which already had this).
     * Previously the ONLY signal a vendor received for a new inquiry was a
     * single unretried wp_mail() call in AjaxController::activate_inquiry_lead() --
     * if that email failed to send for any reason (SMTP hiccup, spam filter,
     * misconfigured mail server), the vendor had zero indication a lead ever
     * existed. This gives every inquiry the same in-app dashboard signal
     * bookings already had, independent of whether the email succeeds.
     */
    public static function notify_new_lead( int $vendor_user_id, string $customer_name, string $category_name, int $lead_id ): void {
        if ( ! $vendor_user_id ) { return; }
        if ( self::pref( $vendor_user_id, 'lead.new', 'in_app' ) ) {
            self::create(
                $vendor_user_id, 'lead.new', '\xF0\x9F\x93\xA8 New Inquiry',
                'New inquiry from ' . ( $customer_name ?: 'a customer' ) . ' -- ' . ( $category_name ?: 'General Inquiry' ),
                home_url( '/vendor/dashboard/?section=leads' ), 'mail', '#2563EB',
                [ 'lead_id' => $lead_id ]
            );
        }
    }

    public static function on_booking_confirmed( array $d ): void {
        $vid = (int) ( $d['vendor_user_id'] ?? 0 );
        $cid = (int) ( $d['customer_user_id'] ?? 0 );

        if ( $vid && self::pref( $vid, 'booking.confirmed', 'in_app' ) ) {
            self::create( $vid, 'booking.confirmed', '📅 Booking Confirmed',
                'Booking with ' . ( $d['customer_name'] ?? 'client' ) . ' on ' . ( $d['booking_date'] ?? '' ),
                home_url( '/vendor/dashboard/?section=bookings' ), 'calendar', '#059669' );
        }
        if ( $vid ) {
            self::maybe_email( $vid, 'booking.confirmed', $d['vendor_email'] ?? '', 'booking_confirmed_vendor', $d );
            self::maybe_push( $vid, 'booking.confirmed', '📅 Booking Confirmed', 'With ' . ( $d['customer_name'] ?? 'client' ) . ' on ' . ( $d['booking_date'] ?? '' ), home_url( '/vendor/dashboard/?section=bookings' ), 'booking' );
        }
        if ( $cid && self::pref( $cid, 'booking.confirmed', 'in_app' ) ) {
            self::create( $cid, 'booking.confirmed', '✅ Booking Confirmed',
                'Your booking with ' . ( $d['vendor_name'] ?? 'vendor' ) . ' is confirmed for ' . ( $d['booking_date'] ?? '' ),
                home_url( '/my-account/?section=track' ), 'calendar-check', '#059669' );
        }
        if ( $cid ) {
            self::maybe_email( $cid, 'booking.confirmed', $d['customer_email'] ?? '', 'booking_confirmed_client', $d );
            self::maybe_push( $cid, 'booking.confirmed', '✅ Booking Confirmed!', 'Your booking with ' . ( $d['vendor_name'] ?? 'vendor' ) . ' is confirmed', home_url( '/my-account/?section=track' ), 'booking' );
        }
        // WhatsApp — Track B (fires only if BSP API configured; silent otherwise)
        WhatsAppService::send_booking_confirmed( $d );
    }

    public static function on_job_status_changed( array $d ): void {
        $cid    = (int) ( $d['customer_user_id'] ?? 0 );
        $status = $d['job_status'] ?? '';
        $msgs   = [
            'travelling'  => [ '🚗 On the way!',     ( $d['vendor_name'] ?? 'Your professional' ) . ' is heading to your location.' . ( isset( $d['eta'] ) ? ' ETA: ~' . $d['eta'] . ' mins' : '' ) ],
            'arrived'     => [ '📍 Arrived!',         ( $d['vendor_name'] ?? 'Your professional' ) . ' has arrived at your location.' ],
            'in_progress' => [ '🔧 Work in progress', 'Job started by ' . ( $d['vendor_name'] ?? 'your professional' ) . '.' ],
            'done'        => [ '🎉 Job Completed!',   'Great news — your job is done! Tap to leave a review.' ],
        ];
        if ( ! $cid || ! isset( $msgs[ $status ] ) ) { return; }
        [ $title, $body ] = $msgs[ $status ];
        $url = home_url( '/my-account/?section=track' );
        if ( self::pref( $cid, 'job.' . $status, 'in_app' ) ) {
            self::create( $cid, 'job.' . $status, $title, $body, $url, 'map-pin', '#2563EB' );
        }
        self::maybe_push( $cid, 'job.' . $status, $title, $body, $url, 'job.' . $status );
        if ( $status === 'done' ) {
            self::maybe_email( $cid, 'job.done', $d['customer_email'] ?? '', 'job_completed_client', $d );
        }
        // WhatsApp: send "on the way" message when vendor starts travelling
        if ( $status === 'travelling' ) {
            WhatsAppService::send_vendor_enroute( $d );
        }
    }

    public static function on_job_completed( array $d ): void {
        self::on_job_status_changed( array_merge( $d, [ 'job_status' => 'done' ] ) );
    }

    public static function on_review_created( array $d ): void {
        $vid = (int) ( $d['vendor_user_id'] ?? 0 );
        if ( ! $vid ) { return; }
        if ( self::pref( $vid, 'review.new', 'in_app' ) ) {
            self::create( $vid, 'review.new', '⭐ New Review',
                ( $d['reviewer_name'] ?? 'A client' ) . ' left a ' . ( $d['rating'] ?? 5 ) . '-star review',
                home_url( '/vendor/dashboard/?section=reviews' ), 'star', '#D97706' );
        }
        self::maybe_email( $vid, 'review.new', $d['vendor_email'] ?? '', 'new_review', $d );
    }

    // Real feature — Part 22, Public Q&A. Matches on_review_created()
    // above exactly: same preference check, same in-app + email shape.
    public static function on_question_created( array $d ): void {
        $vid = (int) ( $d['vendor_user_id'] ?? 0 );
        if ( ! $vid ) { return; }
        if ( self::pref( $vid, 'question.new', 'in_app' ) ) {
            self::create( $vid, 'question.new', '❓ New Question',
                'Someone asked: "' . mb_strimwidth( $d['question_text'] ?? '', 0, 60, '…' ) . '"',
                home_url( '/vendor/dashboard/?section=questions' ), 'help-circle', '#2563EB' );
        }
        self::maybe_email( $vid, 'question.new', $d['vendor_email'] ?? '', 'new_question', $d );
    }

    public static function on_listing_approved( array $d ): void {
        $vid = (int) ( $d['vendor_user_id'] ?? 0 );
        if ( ! $vid ) { return; }
        if ( self::pref( $vid, 'listing.approved', 'in_app' ) ) {
            self::create( $vid, 'listing.approved', '✅ Listing Approved!',
                '"' . ( $d['title'] ?? '' ) . '" is now live.',
                home_url( '/' . ltrim( $d['slug'] ?? '', '/' ) . '/' ), 'check', '#059669' );
        }
        self::maybe_email( $vid, 'listing.approved', $d['vendor_email'] ?? '', 'listing_approved', $d );
        self::maybe_push( $vid, 'listing.approved', '✅ Listing Live!', '"' . ( $d['title'] ?? '' ) . '" is now live on the directory', home_url( '/vendor/dashboard/' ), 'listing.approved' );
    }

    /**
     * Real feature — closes a gap found while auditing the notification
     * system: DisputeService already emitted this event, nothing was
     * listening. Notifies whichever party did NOT open the dispute
     * (the other party needs to know something was filed against/about
     * them) plus admin, via notify_admins() — a dispute is exactly the
     * kind of thing that existing helper was built for.
     */
    public static function on_dispute_opened( array $d ): void {
        $vendor_uid   = (int) ( $d['vendor_user_id'] ?? 0 );
        $customer_uid = (int) ( $d['customer_user_id'] ?? 0 );
        $notify_uid   = ( $d['opened_by'] ?? '' ) === 'customer' ? $vendor_uid : $customer_uid;
        $other_name   = ( $d['opened_by'] ?? '' ) === 'customer' ? ( $d['customer_name'] ?? 'The customer' ) : ( $d['vendor_name'] ?? 'The vendor' );

        if ( $notify_uid && self::pref( $notify_uid, 'dispute.opened', 'in_app' ) ) {
            self::create( $notify_uid, 'dispute.opened', '⚖️ A Dispute Was Opened',
                $other_name . ' opened a dispute regarding a booking. Reason: ' . ( $d['reason'] ?? 'not specified' ),
                home_url( '/vendor/dashboard/?section=bookings' ), 'alert-triangle', '#DC2626' );
        }
        self::maybe_push( $notify_uid, 'dispute.opened', '⚖️ A Dispute Was Opened',
            $other_name . ' opened a dispute regarding a booking.', home_url( '/vendor/dashboard/?section=bookings' ), 'dispute' );

        self::notify_admins( 'dispute.opened', '⚖️ New Dispute Opened',
            'A dispute (#' . ( $d['dispute_id'] ?? '' ) . ') was opened on booking #' . ( $d['booking_id'] ?? '' ) . '. Reason: ' . ( $d['reason'] ?? 'not specified' ),
            home_url( '/admin-panel/?section=disputes' ) );
    }

    public static function on_dispute_resolved( array $d ): void {
        $resolution_labels = [
            'full_refund'    => 'a full refund',
            'partial_refund' => 'a partial refund',
            'no_refund'      => 'no refund',
            'mediation'      => 'mediation',
            'wallet_credit'  => 'a wallet credit',
        ];
        $resolution_text = $resolution_labels[ $d['resolution'] ?? '' ] ?? ( $d['resolution'] ?? 'a decision' );

        foreach ( [ (int) ( $d['customer_user_id'] ?? 0 ), (int) ( $d['vendor_user_id'] ?? 0 ) ] as $uid ) {
            if ( ! $uid ) { continue; }
            if ( self::pref( $uid, 'dispute.resolved', 'in_app' ) ) {
                self::create( $uid, 'dispute.resolved', '✅ Dispute Resolved',
                    'Your dispute has been resolved with ' . $resolution_text . '.' . ( ! empty( $d['resolution_note'] ) ? ' Note: ' . $d['resolution_note'] : '' ),
                    home_url( '/vendor/dashboard/?section=bookings' ), 'check-circle', '#059669' );
            }
            self::maybe_push( $uid, 'dispute.resolved', '✅ Dispute Resolved',
                'Your dispute has been resolved with ' . $resolution_text . '.', home_url( '/vendor/dashboard/?section=bookings' ), 'dispute' );
        }
    }

    public static function on_listing_rejected( array $d ): void {
        $vid = (int) ( $d['vendor_user_id'] ?? 0 );
        if ( ! $vid ) { return; }
        if ( self::pref( $vid, 'listing.rejected', 'in_app' ) ) {
            self::create( $vid, 'listing.rejected', '❌ Listing Needs Changes',
                '"' . ( $d['title'] ?? '' ) . '" — Reason: ' . ( $d['reason'] ?? '' ),
                home_url( '/vendor/dashboard/?section=listings' ), 'x', '#DC2626' );
        }
        self::maybe_email( $vid, 'listing.rejected', $d['vendor_email'] ?? '', 'listing_rejected', $d );
    }

    public static function on_vendor_verified( array $d ): void {
        // Real fix — confirmed bug: this event has two emission sites
        // with inconsistent payload keys ('user_id' vs 'vendor_user_id').
        // Reading either means the bulk-action path (which only ever
        // sends 'vendor_user_id') was silently never notifying anyone at
        // all, since this used to read $d['user_id'] exclusively.
        $uid = (int) ( $d['user_id'] ?? $d['vendor_user_id'] ?? 0 );
        if ( ! $uid ) { return; }
        self::create( $uid, 'vendor.verified', '✅ Account Verified!',
            'Your business is now verified on ' . Config::get( 'platform_name', 'GoodService' ),
            home_url( '/vendor/dashboard/?section=profile' ), 'shield', '#7C3AED' );
        // Real fix — confirmed gap: this was in-app only, never email,
        // despite "account approval" being explicitly on the audit list.
        // Uses gs_vendor_site_email() per explicit request — the
        // listing's own contact email, not the account/login email.
        $user = get_userdata( $uid );
        $vp = gs_get_vendor_profile( $uid );
        $notify_email = $vp ? gs_vendor_site_email( (int) $vp->id ) : ( $user->user_email ?? '' );
        if ( $notify_email ) {
            \GoodService\Service\EmailService::send( $notify_email, 'vendor_verified_alert', [
                'vendor_name' => $user->display_name ?? ( $user->user_email ?? 'there' ),
            ] );
        }
    }

    public static function on_trial_ending( array $d ): void {
        $vid = (int) ( $d['vendor_user_id'] ?? 0 );
        if ( ! $vid ) { return; }
        if ( self::pref( $vid, 'subscription.trial_ending', 'in_app' ) ) {
            self::create( $vid, 'subscription.trial_ending', '⏰ Trial Ending Soon',
                'Your Pro trial ends in ' . ( $d['days_left'] ?? 4 ) . ' days. Upgrade to keep your features.',
                home_url( '/vendor/dashboard/?section=subscription' ), 'clock', '#D97706' );
        }
        self::maybe_email( $vid, 'subscription.trial_ending', $d['vendor_email'] ?? '', 'subscription_trial_ending', $d );
        self::maybe_push( $vid, 'subscription.trial_ending', '⏰ Trial Ending', 'Your Pro trial ends in ' . ( $d['days_left'] ?? 4 ) . ' days', home_url( '/vendor/dashboard/?section=subscription' ), 'trial' );
    }

    public static function on_staff_assigned( array $d ): void {
        $staff_uid = (int) ( $d['staff_user_id'] ?? 0 );
        if ( ! $staff_uid ) { return; }
        self::create( $staff_uid, 'staff.assigned', '📋 Inquiry Assigned to You',
            'You have been assigned an inquiry from ' . ( $d['client_name'] ?? 'a client' ),
            home_url( '/vendor/dashboard/?section=leads' ), 'user-check', '#2563EB' );
        self::maybe_push( $staff_uid, 'staff.assigned', '📋 New Assignment', 'Inquiry from ' . ( $d['client_name'] ?? 'client' ) . ' assigned to you', home_url( '/vendor/dashboard/?section=leads' ), 'staff.assigned' );
    }

    /**
     * Real fix — Audit Section D/E gap: booking cancellation never
     * notified the affected customer at all (only triggered a waitlist
     * check for OTHER people who might want the newly-freed slot). Fires
     * from AjaxController::updateBooking() when a vendor sets status to
     * 'cancelled'.
     */
    public static function on_booking_cancelled( array $d ): void {
        $cid = (int) ( $d['customer_user_id'] ?? 0 );
        if ( $cid && self::pref( $cid, 'booking.cancelled', 'in_app' ) ) {
            self::create( $cid, 'booking.cancelled', '❌ Booking Cancelled',
                'Your booking with ' . ( $d['vendor_name'] ?? 'the vendor' ) . ' has been cancelled.',
                home_url( '/my-account/?section=track' ), 'x-circle', '#DC2626' );
        }
        self::maybe_email( $cid, 'booking.cancelled', $d['customer_email'] ?? '', 'booking_cancelled_client', $d );
        self::maybe_push( $cid, 'booking.cancelled', '❌ Booking Cancelled', 'Your booking with ' . ( $d['vendor_name'] ?? 'vendor' ) . ' was cancelled', home_url( '/my-account/?section=track' ), 'booking' );
        WhatsAppService::send_booking_cancelled( $d );

        // Root-cause fix — confirmed gap from full enterprise audit
        // (Part 4, "Customer dashboard has no cancellation action for
        // bookings"): this listener only ever handled the vendor-initiated
        // path (AjaxController::updateBooking(), which never sets
        // 'cancelled_by' — defaults to 'vendor' below, so that existing
        // call's behavior is completely unchanged). Adding real customer-
        // initiated cancellation (AjaxController::customerCancelBooking())
        // exposed a symmetric gap this event was never built for: when the
        // CUSTOMER cancels, the vendor was never told at all — they'd only
        // discover an upcoming booking vanished by noticing it missing from
        // their own dashboard. Mirrors on_booking_confirmed()'s existing
        // dual vendor+customer notify pattern, gated so the vendor-
        // initiated path (where the vendor obviously already knows) is
        // never touched.
        if ( ( $d['cancelled_by'] ?? 'vendor' ) === 'customer' ) {
            $vid = (int) ( $d['vendor_user_id'] ?? 0 );
            if ( $vid && self::pref( $vid, 'booking.cancelled', 'in_app' ) ) {
                self::create( $vid, 'booking.cancelled', '❌ Booking Cancelled by Customer',
                    ( $d['customer_name'] ?? 'A customer' ) . ' cancelled their booking on ' . ( $d['booking_date'] ?? '' ),
                    home_url( '/vendor/dashboard/?section=bookings' ), 'x-circle', '#DC2626' );
            }
            if ( $vid ) {
                self::maybe_email( $vid, 'booking.cancelled', $d['vendor_email'] ?? '', 'booking_cancelled_vendor', $d );
                self::maybe_push( $vid, 'booking.cancelled', '❌ Booking Cancelled', ( $d['customer_name'] ?? 'A customer' ) . ' cancelled on ' . ( $d['booking_date'] ?? '' ), home_url( '/vendor/dashboard/?section=bookings' ), 'booking' );
            }
        }
    }

    /**
     * Real fix — Audit Section E gap: no notification of any kind fired
     * when a vendor's subscription payment succeeded (razorpayVerifyPayment(),
     * context='subscription') — a vendor had no way to know a payment went
     * through except by manually checking billing.
     */
    public static function on_payment_received( array $d ): void {
        $vid = (int) ( $d['vendor_user_id'] ?? 0 );
        if ( ! $vid ) { return; }
        $invoice_no = $d['invoice_no'] ?? '';
        $invoice_suffix = $invoice_no ? " (Invoice {$invoice_no})" : '';
        if ( self::pref( $vid, 'payment.received', 'in_app' ) ) {
            self::create( $vid, 'payment.received', '💳 Payment Received',
                'Your payment of ₹' . number_format( (float) ( $d['amount'] ?? 0 ) ) . ' for the ' . ( $d['plan_name'] ?? '' ) . " plan was successful.{$invoice_suffix}",
                home_url( '/vendor/dashboard/?section=invoices' ), 'credit-card', '#059669' );
        }
        self::maybe_email( $vid, 'payment.received', $d['vendor_email'] ?? '', 'payment_received_vendor', $d );
        self::maybe_push( $vid, 'payment.received', '💳 Payment Successful', '₹' . number_format( (float) ( $d['amount'] ?? 0 ) ) . ' — ' . ( $d['plan_name'] ?? 'plan' ) . ' activated', home_url( '/vendor/dashboard/?section=invoices' ), 'payment' );

        // Real fix — confirmed gap from full admin-notification audit:
        // payment received never notified admin at all, despite being
        // explicitly on the audit's own list as a revenue event requiring
        // admin awareness.
        self::notify_admins(
            'payment.received', '💰 Payment Received',
            '₹' . number_format( (float) ( $d['amount'] ?? 0 ) ) . ' received for the ' . ( $d['plan_name'] ?? 'a' ) . " plan{$invoice_suffix}.",
            home_url( '/admin-panel/?section=transactions' )
        );
    }

    /**
     * Real fix — Audit Section E gap ("Lead acceptance / Lead rejection"):
     * gs_leads.status already supports 'won' and 'lost' as valid values
     * (see updateInquiryStatus()'s $allowed list) but neither ever
     * notified the customer when a vendor set it. Fires from
     * updateInquiryStatus() specifically for those two values — every
     * other status change (seen/contacted/qualified/etc.) is an internal
     * vendor workflow state, not something a customer needs pinged about.
     */
    public static function on_lead_status_decided( array $d ): void {
        $cid = (int) ( $d['customer_user_id'] ?? 0 );
        if ( ! $cid ) { return; }
        $won = ( $d['status'] ?? '' ) === 'won';

        if ( self::pref( $cid, 'lead.decided', 'in_app' ) ) {
            self::create( $cid, 'lead.decided',
                $won ? '✅ Inquiry Accepted' : 'Inquiry Update',
                ( $d['vendor_name'] ?? 'The vendor' ) . ( $won ? ' has accepted your inquiry and will be in touch.' : ' is unable to take on your inquiry at this time.' ),
                home_url( '/my-account/?section=inquiries' ), $won ? 'check-circle' : 'info', $won ? '#059669' : '#64748B' );
        }
        self::maybe_email( $cid, 'lead.decided', $d['customer_email'] ?? '', $won ? 'lead_won_client' : 'lead_lost_client', $d );
        WhatsAppService::send_lead_status_decided( $d );
    }

    /** Process a queued email job. */
    public static function send_email_job( array $payload ): void {
        $to       = sanitize_email( $payload['to'] ?? '' );
        $template = $payload['template'] ?? '';
        $vars     = $payload['vars'] ?? [];
        if ( ! $to || ! $template ) { return; }

        global $wpdb;
        $tpl = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_email_templates WHERE slug = %s AND is_active = 1", $template
        ) );
        if ( ! $tpl ) { return; }

        $subject = self::parse_template( $tpl->subject, $vars );
        $body    = self::parse_template( $tpl->body,    $vars );

        wp_mail( $to, $subject, $body, [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . Config::get( 'platform_name', 'GoodService' ) . ' <' . Config::get( 'platform_email', get_option( 'admin_email' ) ) . '>',
        ] );
    }

    private static function parse_template( string $template, array $vars ): string {
        $vars = array_merge( [
            'platform_name' => Config::get( 'platform_name', 'GoodService' ),
            'platform_url'  => home_url( '/' ),
            'year'          => date( 'Y' ),
        ], $vars );
        foreach ( $vars as $key => $value ) {
            $template = str_replace( '{{' . $key . '}}', (string) $value, $template );
        }
        return $template;
    }

    /**
     * notify_admins()
     * Sends an in-app notification to all users with administrator, gs_manager,
     * or gs_moderator roles. Used by Phase 3 cron automation to alert operations
     * staff about no-shows, stuck jobs, and auto-expires without developer access.
     *
     * @param string $event  EventBus-style event name (e.g. 'booking.stuck')
     * @param string $title  Notification title
     * @param string $body   Notification body
     * @param string $url    Deep-link URL for the admin to take action
     */
    public static function notify_admins( string $event, string $title, string $body, string $url = '' ): void {
        if ( ! $url ) {
            $url = home_url( '/wp-admin/admin.php?page=goodservice' );
        }
        // ENTERPRISE-AUDIT FIX (Part 2, High): checked once, here, at the
        // single shared root every notify_admins() call (both this method
        // and Helpers::notify_admins()'s async wrapper, which routes back
        // to this same method via JobQueue) ultimately goes through —
        // rather than adding an enabled-check at each of the ~20 individual
        // call sites across the codebase. A disabled channel is skipped
        // entirely (no wasted DB insert / no wasted wp_mail() call), not
        // just hidden from the UI.
        $in_app_on = self::admin_alert_channel_enabled( $event, 'in_app' );
        $email_on  = self::admin_alert_channel_enabled( $event, 'email' );

        if ( $in_app_on ) {
            $admin_roles = [ 'administrator', 'gs_manager', 'gs_moderator' ];
            $admins      = get_users( [ 'role__in' => $admin_roles, 'fields' => 'ID', 'number' => 50 ] );
            foreach ( $admins as $uid ) {
                self::create( (int) $uid, $event, $title, $body, $url, 'alert-triangle', '#DC2626' );
            }
        }
        // Also email the platform admin address so it lands in a monitored inbox
        $admin_email = Config::get( 'platform_email', get_option( 'admin_email' ) );
        if ( $email_on && $admin_email ) {
            wp_mail(
                $admin_email,
                '[GoodService] ' . $title,
                $body . "\n\nAction link: " . $url,
                [
                    'Content-Type: text/plain; charset=UTF-8',
                    'From: GoodService Alerts <' . $admin_email . '>',
                ]
            );
        }
    }
}
