<?php
namespace GoodService\Service;

/**
 * TwoFactorService — real feature, Critical priority gap from the
 * enterprise audit.
 *
 * ARCHITECTURAL CONTEXT (Phase 1-4 discovery, documented so the next
 * engineer doesn't re-derive it):
 *
 * Deliberately reuses the existing, proven OtpService (SMS via
 * msg91/textlocal with email fallback, 5-minute TTL, rate limiting,
 * hash_equals timing-safe compare, single-use enforcement) as the
 * verification mechanism, rather than building a separate TOTP /
 * authenticator-app system from scratch. This was a genuine
 * architectural pivot discovered during Phase 1 discovery, not the
 * originally-planned approach — TOTP would have required a new library,
 * new secret storage, QR code generation, and a backup-code system, all
 * duplicating what OtpService already does correctly. Reusing it means
 * less new surface area, and 2FA delivery uses the exact same channel
 * infrastructure this platform's other verification flows already rely
 * on and have already proven reliable in production.
 *
 * SECURITY DESIGN — the password/2FA ordering matters:
 * wp_signon() creates a session internally on success, so 2FA MUST be
 * decided BEFORE any session-creating call runs, not after. The login
 * handler in AjaxController therefore verifies the password as a pure,
 * side-effect-free check first (wp_check_password — no session), asks
 * this service whether 2FA applies, and only then either proceeds
 * immediately (2FA off) or defers session creation until a pending
 * token + OTP are both verified (2FA on). This preserves the ENTIRE
 * existing login code path byte-for-byte for any account that hasn't
 * enabled 2FA — zero behaviour change, zero regression risk for the
 * common case.
 */
class TwoFactorService {

    private const PENDING_TTL_SECONDS = 300; // matches OtpService's own OTP TTL — a longer-lived pending token than the OTP it gates makes no sense

    /**
     * Whether this user must complete a 2FA challenge to log in.
     * Enforced (not optional) for admin and regional-manager roles
     * regardless of their own per-account toggle, per the audit's
     * explicit requirement that these highest-value accounts are
     * mandatory, not opt-in. Vendors and other roles are opt-in via
     * their own gs_2fa_settings.enabled flag.
     */
    public static function is_required( \WP_User $user ): bool {
        $roles = (array) $user->roles;
        if ( array_intersect( $roles, [ 'administrator', 'gs_manager' ] ) || user_can( $user, 'manage_options' ) ) {
            return true;
        }
        global $wpdb;
        $enabled = $wpdb->get_var( $wpdb->prepare(
            "SELECT enabled FROM {$wpdb->prefix}gs_2fa_settings WHERE user_id = %d",
            $user->ID
        ) );
        return (bool) $enabled;
    }

    /**
     * Starts a 2FA challenge: generates a single-use pending token,
     * sends the OTP via the existing OtpService to the user's
     * registered phone (falling back to their WP account email —
     * OtpService already supports this natively), and returns the
     * token the client must submit alongside the OTP code.
     *
     * Returns null if no delivery channel could be used at all (no
     * phone on file, no SMS provider configured, and email send
     * failed) — the caller must treat this as a hard failure, never as
     * "2FA passed", since an unsent challenge must not silently
     * degrade into unauthenticated access.
     */
    public static function start_challenge( \WP_User $user ): ?string {
        global $wpdb;

        $phone = $wpdb->get_var( $wpdb->prepare(
            "SELECT phone FROM {$wpdb->prefix}gs_2fa_settings WHERE user_id = %d",
            $user->ID
        ) );
        if ( ! $phone ) {
            // Fall back to the vendor profile's phone if the user has one —
            // avoids forcing a separate phone-entry step for vendors who
            // already have a verified number on their profile.
            $phone = $wpdb->get_var( $wpdb->prepare(
                "SELECT phone FROM {$wpdb->prefix}gs_vendor_profiles WHERE user_id = %d",
                $user->ID
            ) );
        }

        $result = OtpService::send( (string) $phone, '2fa', $user->user_email );
        if ( ! $result['sent'] ) {
            gs_write_log( "TwoFactorService: challenge send failed for user {$user->ID} — {$result['error']}", 'WARNING' );
            return null;
        }

        $token = bin2hex( random_bytes( 32 ) ); // 64 hex chars, matches the CHAR(64) column
        $wpdb->insert( $wpdb->prefix . 'gs_2fa_pending', [
            'token'      => $token,
            'user_id'    => $user->ID,
            'expires_at' => gmdate( 'Y-m-d H:i:s', time() + self::PENDING_TTL_SECONDS ),
        ] );

        return $token;
    }

    /**
     * Completes a 2FA challenge: validates the pending token is real,
     * unexpired, and matches the claimed user, then verifies the OTP
     * itself via the existing OtpService. The pending token is deleted
     * immediately on any outcome (success or failure) — single-use,
     * matching OtpService's own single-use OTP behaviour.
     *
     * Returns the WP_User on success, or a WP_Error describing exactly
     * why verification failed (never a bare boolean — the login handler
     * needs the specific reason to show the user).
     */
    public static function verify_challenge( string $token, string $otp_code ): \WP_User|\WP_Error {
        global $wpdb;

        $pending = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_2fa_pending WHERE token = %s",
            $token
        ) );

        if ( ! $pending ) {
            return new \WP_Error( '2fa_invalid_token', 'This login attempt has expired. Please log in again.' );
        }

        // Always delete on first use, regardless of outcome — a pending
        // token must never be usable twice, whether the OTP check that
        // follows succeeds or fails.
        $wpdb->delete( $wpdb->prefix . 'gs_2fa_pending', [ 'token' => $token ] );

        if ( strtotime( $pending->expires_at ) < time() ) {
            return new \WP_Error( '2fa_expired', 'This login attempt has expired. Please log in again.' );
        }

        $user = get_user_by( 'ID', $pending->user_id );
        if ( ! $user ) {
            return new \WP_Error( '2fa_user_missing', 'Account not found. Please log in again.' );
        }

        $phone = $wpdb->get_var( $wpdb->prepare(
            "SELECT phone FROM {$wpdb->prefix}gs_2fa_settings WHERE user_id = %d",
            $user->ID
        ) );
        if ( ! $phone ) {
            $phone = $wpdb->get_var( $wpdb->prepare(
                "SELECT phone FROM {$wpdb->prefix}gs_vendor_profiles WHERE user_id = %d",
                $user->ID
            ) );
        }

        $verify = OtpService::verify( (string) $phone, $otp_code );
        if ( ! $verify['valid'] ) {
            return new \WP_Error( '2fa_bad_code', $verify['error'] );
        }

        return $user;
    }

    /**
     * Enable 2FA for a user (vendor self-service opt-in). Requires a
     * phone number since OTP delivery needs a destination — email-only
     * 2FA would be weaker (a compromised email often means a compromised
     * account already) and isn't offered as the primary path.
     */
    public static function enable( int $user_id, string $phone ): bool {
        global $wpdb;
        $phone = preg_replace( '/[^0-9+]/', '', $phone );
        if ( strlen( $phone ) < 10 ) { return false; }

        return (bool) $wpdb->replace( $wpdb->prefix . 'gs_2fa_settings', [
            'user_id'    => $user_id,
            'enabled'    => 1,
            'phone'      => $phone,
            'enabled_at' => current_time( 'mysql' ),
        ] );
    }

    public static function disable( int $user_id ): bool {
        global $wpdb;
        return (bool) $wpdb->update( $wpdb->prefix . 'gs_2fa_settings', [ 'enabled' => 0 ], [ 'user_id' => $user_id ] );
    }
}
