<?php
namespace GoodService\Service;

/**
 * DataExportService — queued customer/vendor personal-data export.
 *
 * ENTERPRISE-AUDIT FIX (Part 4 §6, Medium: "customer data export running
 * synchronous/blocking rather than queued"). Real fix: the export is
 * generated off the request cycle by JobQueue (see JobQueue::handle()'s
 * 'data_export' case), written to a protected, non-web-accessible
 * directory (same .htaccess/index.php/web.config guard pattern as
 * BackupService), and the user is emailed a link once it's ready —
 * matching the standard enterprise "request export → email when ready"
 * pattern the finding asked for.
 */
final class DataExportService {

    private const DIR_NAME = 'gs23-data-exports';

    public static function export_dir(): string {
        $up = wp_upload_dir();
        return trailingslashit( $up['basedir'] ) . self::DIR_NAME;
    }

    private static function ensure_export_dir(): string {
        $dir = self::export_dir();
        if ( ! is_dir( $dir ) ) {
            wp_mkdir_p( $dir );
        }
        $htaccess = $dir . '/.htaccess';
        if ( ! file_exists( $htaccess ) ) {
            file_put_contents( $htaccess, "Require all denied\nDeny from all\n" );
        }
        $index = $dir . '/index.php';
        if ( ! file_exists( $index ) ) {
            file_put_contents( $index, "<?php\n// Silence is golden.\n" );
        }
        $webconfig = $dir . '/web.config';
        if ( ! file_exists( $webconfig ) ) {
            file_put_contents( $webconfig, '<?xml version="1.0" encoding="UTF-8"?><configuration><system.webServer><authorization><deny users="*" /></authorization></system.webServer></configuration>' );
        }
        return $dir;
    }

    /**
     * Queue a new export request for a user. Refuses to queue a second one
     * while an earlier request is still pending/processing (returns the
     * existing request instead) — prevents a double-click from queuing
     * duplicate jobs and duplicate emails.
     */
    public static function request( int $user_id ): array {
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';

        $existing = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$p}data_exports WHERE user_id=%d AND status IN ('pending','processing') ORDER BY created_at DESC LIMIT 1",
            $user_id
        ) );
        if ( $existing ) {
            return [ 'id' => (int) $existing->id, 'status' => $existing->status, 'already_queued' => true ];
        }

        $wpdb->insert( $p . 'data_exports', [
            'user_id'    => $user_id,
            'status'     => 'pending',
            'created_at' => current_time( 'mysql' ),
        ] );
        $id = (int) $wpdb->insert_id;
        \GoodService\Core\JobQueue::push( 'data_export', [ 'user_id' => $user_id, 'export_id' => $id ] );
        return [ 'id' => $id, 'status' => 'pending', 'already_queued' => false ];
    }

    /** Latest export request for a user (for the dashboard's status poll). */
    public static function latest_for_user( int $user_id ): ?\stdClass {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT id,status,token,expires_at,created_at,completed_at FROM {$wpdb->prefix}gs_data_exports
             WHERE user_id=%d ORDER BY created_at DESC LIMIT 1",
            $user_id
        ) );
    }

    /**
     * Runs in the background via JobQueue. Builds the same personal-data
     * snapshot AjaxController::exportMyData() used to build synchronously
     * (profile/leads/bookings/reviews/messages/subscriptions/invoices/saved
     * listings), writes it to the protected directory, and emails a
     * download link. Throws on failure so JobQueue's existing retry-with-
     * backoff applies (matches every other job handler's convention).
     */
    public static function generate_and_notify( int $export_id, int $user_id ): void {
        global $wpdb;
        $p = $wpdb->prefix . 'gs_';

        $wpdb->update( $p . 'data_exports', [ 'status' => 'processing' ], [ 'id' => $export_id ] );

        try {
            $u = get_userdata( $user_id );
            if ( ! $u ) { throw new \RuntimeException( 'User no longer exists.' ); }
            $vp = \GoodService\Repository\VendorRepository::get_by_user( $user_id );

            $export = [
                'exported_at'  => current_time( 'mysql' ),
                'platform'     => \GoodService\Core\Config::get( 'platform_name', 'GoodService' ),
                'user'         => [
                    'id'           => $user_id,
                    'email'        => $u->user_email ?? '',
                    'display_name' => $u->display_name ?? '',
                    'registered'   => $u->user_registered ?? '',
                ],
                'vendor_profile' => $vp ? [
                    'business_name'       => $vp->business_name,
                    'phone'               => $vp->phone,
                    'email'               => $vp->email,
                    'city'                => $vp->city,
                    'verification_status' => $vp->verification_status,
                    'created_at'          => $vp->created_at,
                ] : null,
                'leads'       => $wpdb->get_results( $wpdb->prepare(
                    "SELECT id,name,phone,email,message,status,created_at FROM {$p}leads WHERE customer_user_id=%d OR (vendor_id=(SELECT id FROM {$p}vendor_profiles WHERE user_id=%d LIMIT 1)) ORDER BY created_at DESC LIMIT 500",
                    $user_id, $user_id
                ) ) ?: [],
                'bookings'    => $wpdb->get_results( $wpdb->prepare(
                    "SELECT id,customer_name,customer_phone,customer_email,booking_date,booking_time,status,job_status,created_at FROM {$p}bookings WHERE user_id=%d OR customer_user_id=%d ORDER BY created_at DESC LIMIT 200",
                    $user_id, $user_id
                ) ) ?: [],
                'reviews'     => $wpdb->get_results( $wpdb->prepare(
                    "SELECT id,rating,comment,status,created_at FROM {$p}reviews WHERE user_id=%d ORDER BY created_at DESC LIMIT 200",
                    $user_id
                ) ) ?: [],
                'messages'    => $wpdb->get_results( $wpdb->prepare(
                    "SELECT id,body,created_at FROM {$p}messages WHERE sender_id=%d ORDER BY created_at DESC LIMIT 500",
                    $user_id
                ) ) ?: [],
                'subscriptions' => $vp ? $wpdb->get_results( $wpdb->prepare(
                    "SELECT id,plan_name,billing_cycle,amount,status,starts_at,expires_at FROM {$p}subscriptions WHERE vendor_id=%d ORDER BY created_at DESC LIMIT 50",
                    (int) $vp->id
                ) ) ?: [] : [],
                'invoices'    => $vp ? $wpdb->get_results( $wpdb->prepare(
                    "SELECT invoice_no,amount,tax,total,status,paid_at FROM {$p}invoices WHERE vendor_id=%d ORDER BY created_at DESC LIMIT 100",
                    (int) $vp->id
                ) ) ?: [] : [],
                'saved_listings' => $wpdb->get_results( $wpdb->prepare(
                    "SELECT listing_id,folder,note,created_at FROM {$p}saved_listings WHERE user_id=%d ORDER BY created_at DESC LIMIT 200",
                    $user_id
                ) ) ?: [],
            ];

            $dir      = self::ensure_export_dir();
            $token    = wp_generate_password( 40, false, false );
            $filename = 'export-' . $export_id . '-' . $token . '.json';
            $path     = $dir . '/' . $filename;
            $written  = file_put_contents( $path, wp_json_encode( $export, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) );
            if ( $written === false ) { throw new \RuntimeException( 'Could not write export file to disk.' ); }

            $expires_at = date( 'Y-m-d H:i:s', time() + ( 7 * DAY_IN_SECONDS ) );
            $wpdb->update( $p . 'data_exports', [
                'status'       => 'done',
                'token'        => $token,
                'file_path'    => $filename,
                'expires_at'   => $expires_at,
                'completed_at' => current_time( 'mysql' ),
            ], [ 'id' => $export_id ] );

            if ( $u->user_email ) {
                $download_url = add_query_arg( [
                    'action' => 'gs_download_data_export',
                    'id'     => $export_id,
                    'token'  => $token,
                ], admin_url( 'admin-ajax.php' ) );
                \GoodService\Core\JobQueue::push( 'send_raw_email', [
                    'to'      => $u->user_email,
                    'subject' => 'Your data export is ready',
                    'body'    => '<p>Hi ' . esc_html( $u->display_name ?: '' ) . ',</p>'
                        . '<p>Your requested data export is ready. This link expires in 7 days:</p>'
                        . '<p><a href="' . esc_url( $download_url ) . '">Download my data</a></p>'
                        . '<p>If you did not request this, you can safely ignore this email.</p>',
                ] );
            }
        } catch ( \Throwable $e ) {
            $wpdb->update( $p . 'data_exports', [ 'status' => 'failed', 'error' => substr( $e->getMessage(), 0, 500 ) ], [ 'id' => $export_id ] );
            throw $e; // let JobQueue's retry-with-backoff handle it
        }
    }
}
