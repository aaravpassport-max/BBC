<?php
namespace GoodService\Service;

/**
 * IndexNowService — "safe auto ping" search-engine notification.
 *
 * WHY THIS EXISTS / WHAT IT REPLACES:
 * The reference plugin supplied for this feature ("Auto Ping Booster 12hr")
 * blindly POSTs an XML-RPC "weblogUpdates.ping" to ~40 hardcoded ping
 * directories (Technorati, Feedster, blo.gs, Pingoat, etc.) on a timer,
 * for ANY published/updated post, with no regard for whether that content
 * is even meant to be indexed. As of 2026 almost every one of those ~40
 * services is dead (confirmed: Technorati, Feedster, blo.gs and most of
 * that list shut down years ago), and Google's own sitemap "ping" endpoint
 * was officially deprecated in June 2023
 * (https://developers.google.com/search/blog/2023/06/sitemaps-lastmod-ping).
 * So the reference plugin's approach is, today, mostly firing requests
 * into the void — not "unsafe" in a security sense, but functionally
 * close to a no-op dressed up as an SEO feature, and the "ping everyone
 * about everything" pattern is exactly the shape real search engines
 * treat as spam signal if a service on the list ever DID respond.
 *
 * WHAT THIS DOES INSTEAD — IndexNow (https://www.indexnow.org/):
 * IndexNow is the real, current (2026) protocol that search engines
 * actually consume for "a page changed, please recrawl it" — one
 * lightweight POST is shared instantly across every participating engine
 * (confirmed live: Bing and Yandex; Google does not participate in
 * IndexNow and has no direct-ping alternative — Search Console / sitemap
 * discovery is Google's own recommended path, which this platform already
 * has via SitemapController.php, left untouched by this feature).
 *
 * SAFETY — everything the reference plugin got wrong, fixed here:
 *  - Only ever submits a URL that is genuinely public: listing status
 *    must be 'active' AND its seo_robots must not contain 'noindex'.
 *    The reference plugin pinged on ANY post publish with no such check.
 *  - Never pings on every save — de-duplicated with a per-URL cooldown
 *    (self::COOLDOWN) so rapid repeated edits to the same listing don't
 *    generate repeated notifications.
 *  - Never blocks the save/approve request the user is waiting on: this
 *    only ENQUEUES (a fast DB/option write); the actual outbound HTTP
 *    call happens later, in the existing hourly cron batch job.
 *  - Batched + rate-limited: one HTTP call per cron tick, capped batch
 *    size, short timeout, and a queue size cap — this can never turn into
 *    an unbounded flood even under a bulk-import burst.
 *  - Every submission is logged (success/failure counts + timestamp) via
 *    gs_write_log and a small option, so it's fully auditable rather than
 *    a silent fire-and-forget background action.
 */
final class IndexNowService {

    private const OPT_ENABLED   = 'gs_indexnow_enabled';
    private const OPT_KEY       = 'gs_indexnow_key';
    private const OPT_QUEUE     = 'gs_indexnow_queue';
    private const OPT_LAST_RUN  = 'gs_indexnow_last_run';
    private const QUEUE_CAP     = 500;   // never let the queue itself grow unbounded
    private const BATCH_SIZE    = 100;   // IndexNow's own documented max per submission is 10,000; we stay far below it
    private const COOLDOWN      = HOUR_IN_SECONDS; // don't re-notify the same URL more than once per hour

    /** Feature is on by default — matches the reference plugin's own default-active behavior — but admin-toggleable via the option. */
    public static function is_enabled(): bool {
        return (bool) get_option( self::OPT_ENABLED, true );
    }

    public static function set_enabled( bool $on ): void {
        update_option( self::OPT_ENABLED, $on ? 1 : 0, false );
    }

    /** The site's IndexNow key — generated once, persisted, never rotated automatically (rotating it would invalidate the already-hosted key file for no benefit). */
    public static function get_key(): string {
        $key = get_option( self::OPT_KEY, '' );
        if ( ! $key || ! preg_match( '/^[a-f0-9]{32}$/', $key ) ) {
            $key = bin2hex( random_bytes( 16 ) ); // 32 lowercase-hex chars — IndexNow's required key format
            update_option( self::OPT_KEY, $key, false );
        }
        return $key;
    }

    /** The exact path IndexNow requires the key to be servable at: https://{host}/{key}.txt */
    public static function key_file_path(): string {
        return self::get_key() . '.txt';
    }

    /**
     * Called extremely early (init, priority 0) on every request. Cheap
     * (one substring compare on most requests) — only does real work on
     * the one exact request path IndexNow's own verifier will ever hit.
     */
    public static function maybe_serve_key_file(): void {
        $path = trim( (string) parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
        if ( $path === '' || $path !== self::key_file_path() ) { return; }
        header( 'Content-Type: text/plain; charset=utf-8' );
        header( 'X-Robots-Tag: noindex' ); // the key file itself has no reason to ever be indexed
        echo self::get_key();
        exit;
    }

    /**
     * Queue a listing's canonical URL for IndexNow submission. Safe to call
     * from any save/approve path — it only ever queues; it never makes an
     * outbound HTTP call itself (that happens in process_queue(), on the
     * existing hourly cron, never inline with a user-facing request).
     */
    public static function enqueue( string $url ): void {
        if ( ! self::is_enabled() || ! $url ) { return; }

        // Cooldown: skip if this exact URL was already queued/pinged recently.
        $cooldown_key = 'gs_indexnow_cd_' . md5( $url );
        if ( get_transient( $cooldown_key ) ) { return; }
        set_transient( $cooldown_key, 1, self::COOLDOWN );

        $queue = get_option( self::OPT_QUEUE, [] );
        if ( ! is_array( $queue ) ) { $queue = []; }
        if ( in_array( $url, $queue, true ) ) { return; } // already pending
        $queue[] = $url;
        // Cap: if a bulk import or import script ever floods this, drop the
        // OLDEST entries rather than growing without bound or refusing new
        // ones — newest content is the more useful thing to notify about.
        if ( count( $queue ) > self::QUEUE_CAP ) {
            $queue = array_slice( $queue, -1 * self::QUEUE_CAP );
        }
        update_option( self::OPT_QUEUE, $queue, false );
    }

    /**
     * Given a full listing row, decide whether it's genuinely safe/worth
     * notifying search engines about, and enqueue it if so. This is the
     * ONE gate every call path (save, approve) should go through — no
     * caller decides indexability itself, so the rule can never drift
     * between callers.
     */
    public static function submit_for_listing( object $listing ): void {
        if ( empty( $listing->slug ) ) { return; }
        // Real safety fix vs. the reference plugin: never notify search
        // engines about content that isn't actually meant to be public/
        // indexed. The reference plugin pinged on every single post save
        // with zero such check.
        $status = $listing->status ?? '';
        if ( ! in_array( $status, [ 'active', 'published', 'publish' ], true ) ) { return; }
        $robots = strtolower( (string) ( $listing->seo_robots ?? '' ) );
        if ( strpos( $robots, 'noindex' ) !== false ) { return; }

        $url = home_url( '/' . ltrim( $listing->slug, '/' ) . '/' );
        self::enqueue( $url );
    }

    /**
     * Cron-invoked (hourly, alongside every other GoodService background
     * task — see Cron::hourly()). Drains up to BATCH_SIZE queued URLs in
     * ONE IndexNow submission per run — never one HTTP call per URL,
     * which is both faster and exactly how the protocol is designed to
     * be used (it accepts a urlList array).
     */
    public static function process_queue(): void {
        if ( ! self::is_enabled() ) { return; }

        $queue = get_option( self::OPT_QUEUE, [] );
        if ( ! is_array( $queue ) || empty( $queue ) ) { return; }

        $batch     = array_slice( $queue, 0, self::BATCH_SIZE );
        $remaining = array_slice( $queue, self::BATCH_SIZE );
        // Remove the batch from the queue BEFORE the network call — if the
        // call fails we simply try those URLs again next time they're
        // re-saved/re-approved, rather than retry-storming a possibly-down
        // endpoint every single hour forever.
        update_option( self::OPT_QUEUE, $remaining, false );

        $host = parse_url( home_url(), PHP_URL_HOST );
        $key  = self::get_key();
        $body = wp_json_encode( [
            'host'        => $host,
            'key'         => $key,
            'keyLocation' => home_url( '/' . self::key_file_path() ),
            'urlList'     => array_values( $batch ),
        ] );

        $response = wp_remote_post( 'https://api.indexnow.org/indexnow', [
            'headers' => [ 'Content-Type' => 'application/json; charset=utf-8' ],
            'body'    => $body,
            'timeout' => 8, // short — this runs inside the shared hourly cron tick, must never hold it up
        ] );

        $ok   = ! is_wp_error( $response );
        $code = $ok ? (int) wp_remote_retrieve_response_code( $response ) : 0;
        // IndexNow's documented success responses are 200 (processed) and
        // 202 (accepted, key not yet validated but request is queued).
        $success = $ok && in_array( $code, [ 200, 202 ], true );

        update_option( self::OPT_LAST_RUN, [
            'time'    => current_time( 'mysql' ),
            'count'   => count( $batch ),
            'success' => $success,
            'code'    => $code,
            'error'   => $ok ? '' : $response->get_error_message(),
        ], false );

        if ( function_exists( 'gs_write_log' ) ) {
            gs_write_log(
                'IndexNowService: submitted ' . count( $batch ) . ' URL(s), '
                . ( $success ? 'accepted' : ( 'FAILED (' . ( $ok ? "HTTP {$code}" : $response->get_error_message() ) . ')' ) ),
                $success ? 'INFO' : 'ERROR'
            );
        }
    }

    /** For an admin "status" view — how many URLs are currently waiting, and how the last run went. */
    public static function status(): array {
        $queue = get_option( self::OPT_QUEUE, [] );
        return [
            'enabled'      => self::is_enabled(),
            'queue_count'  => is_array( $queue ) ? count( $queue ) : 0,
            'key'          => self::get_key(),
            'key_url'      => home_url( '/' . self::key_file_path() ),
            'last_run'     => get_option( self::OPT_LAST_RUN, null ),
        ];
    }
}
