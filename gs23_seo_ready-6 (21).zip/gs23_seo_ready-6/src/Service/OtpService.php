<?php
namespace GoodService\Service;

use GoodService\Core\Config;

/**
 * OtpService — Phone verification via OTP.
 *
 * Generates a 6-digit OTP, stores it in a WordPress transient (5-minute TTL),
 * and delivers it via SMS (Msg91 or TextLocal) with an email fallback if no
 * SMS gateway is configured.
 *
 * Transient key: gs_otp_{phone_hash} — hashed so the phone number itself is
 * never stored as a cache key visible in the options table.
 *
 * Rate limiting: max 3 OTP sends per phone per 10 minutes via a counter
 * transient, preventing SMS bombing.
 *
 * Settings (stored in gs_settings via Config):
 *   sms_provider  — 'msg91' | 'textlocal' | '' (empty = email fallback)
 *   sms_api_key   — API key for chosen provider
 *   sms_sender    — sender ID (e.g. 'GSVRFY' for Msg91 DLT)
 *   msg91_template_id — DLT template ID (required by Msg91 in India)
 */
final class OtpService {

    private const OTP_TTL       = 300;  // 5 minutes
    private const RATE_TTL      = 600;  // 10-minute rate-limit window
    private const RATE_MAX      = 3;    // max 3 sends per window
    private const OTP_LENGTH    = 6;

    // ── Public API ─────────────────────────────────────────────────────────────

    /**
     * Generate and send an OTP to the given phone number.
     *
     * @param string $phone   Raw phone number (digits only, with or without +91)
     * @param string $purpose Context string shown in the message ('booking' | 'profile')
     * @return array  [ 'sent' => bool, 'channel' => 'sms'|'email', 'error' => string|null ]
     */
    public static function send( string $phone, string $purpose = 'verification', string $email = '' ): array {
        $phone = self::normalise_phone( $phone );
        if ( ! $phone ) {
            return [ 'sent' => false, 'channel' => null, 'error' => 'Invalid phone number.' ];
        }

        // Rate limit check
        $rate_key = 'gs_otp_rate_' . md5( $phone );
        $attempts = (int) get_transient( $rate_key );
        if ( $attempts >= self::RATE_MAX ) {
            return [ 'sent' => false, 'channel' => null, 'error' => 'Too many OTP requests. Please wait a few minutes.' ];
        }

        $otp = self::generate();
        $msg = self::build_message( $otp, $purpose );

        // Store OTP (hashed key so phone is not exposed in options table)
        $store_key = 'gs_otp_' . md5( $phone );
        set_transient( $store_key, [
            'code'    => $otp,
            'phone'   => $phone,
            'purpose' => $purpose,
        ], self::OTP_TTL );

        // Increment rate counter
        set_transient( $rate_key, $attempts + 1, self::RATE_TTL );

        // Try SMS first; fall back to email
        $provider = Config::get( 'sms_provider', '' );
        if ( $provider && Config::get( 'sms_api_key', '' ) ) {
            $sent = match ( $provider ) {
                'msg91'     => self::send_msg91( $phone, $otp ),
                'textlocal' => self::send_textlocal( $phone, $msg ),
                default     => false,
            };
            if ( $sent ) {
                return [ 'sent' => true, 'channel' => 'sms', 'error' => null ];
            }
        }

        // Email fallback
        if ( $email && is_email( $email ) ) {
            $platform = Config::get( 'platform_name', 'GoodService' );
            $ok = wp_mail(
                $email,
                "Your {$platform} verification code",
                "Your OTP is: {$otp}\n\nValid for 5 minutes. Do not share this code.",
                [ 'Content-Type: text/plain; charset=UTF-8' ]
            );
            return [ 'sent' => $ok, 'channel' => 'email', 'error' => $ok ? null : 'Could not send OTP email.' ];
        }

        // No channel available — still stored so a manual lookup is possible
        gs_write_log( "OtpService: no delivery channel for phone {$phone} (SMS provider: '{$provider}', email: '{$email}')", 'WARNING' );
        return [ 'sent' => false, 'channel' => null, 'error' => 'No delivery channel configured. Please contact support.' ];
    }

    /**
     * Verify a submitted OTP against the stored value.
     *
     * @param string $phone  Same phone used when send() was called
     * @param string $code   The 6-digit code the user submitted
     * @return array [ 'valid' => bool, 'error' => string|null ]
     */
    public static function verify( string $phone, string $code ): array {
        $phone     = self::normalise_phone( $phone );
        $store_key = 'gs_otp_' . md5( $phone );
        $stored    = get_transient( $store_key );

        if ( ! $stored ) {
            return [ 'valid' => false, 'error' => 'OTP expired or not found. Please request a new one.' ];
        }

        // Rate-limit verify attempts — max 5 wrong guesses per OTP lifetime
        $attempt_key = 'gs_otp_attempts_' . md5( $phone );
        $attempts    = (int) get_transient( $attempt_key );
        if ( $attempts >= 5 ) {
            delete_transient( $store_key ); // invalidate OTP after too many attempts
            return [ 'valid' => false, 'error' => 'Too many incorrect attempts. Please request a new OTP.' ];
        }

        if ( ! hash_equals( (string) $stored['code'], trim( $code ) ) ) {
            set_transient( $attempt_key, $attempts + 1, self::OTP_TTL );
            return [ 'valid' => false, 'error' => 'Incorrect OTP. Please check and try again.' ];
        }

        // Single-use — delete immediately after successful verify
        delete_transient( $store_key );
        delete_transient( $attempt_key );

        return [ 'valid' => true, 'error' => null ];
    }

    /**
     * Send a plain SMS message (non-OTP) via the configured SMS provider.
     * Used as a fallback channel when WhatsApp BSP is not configured.
     * Returns true on success, false if no provider configured or send fails.
     *
     * @param string $phone  Phone number (digits, with or without +91)
     * @param string $body   Message text (keep under 160 chars for single SMS)
     */
    public static function send_sms( string $phone, string $body ): bool {
        $phone    = self::normalise_phone( $phone );
        $provider = Config::get( 'sms_provider', '' );
        if ( ! $phone || ! $provider || ! Config::get( 'sms_api_key', '' ) ) {
            return false;
        }
        return match ( $provider ) {
            'msg91'     => self::send_msg91_text( $phone, $body ),
            'textlocal' => self::send_textlocal( $phone, $body ),
            default     => false,
        };
    }

    /** Send plain text via Msg91 (uses the same API but without OTP template). */
    private static function send_msg91_text( string $phone, string $body ): bool {
        $api_key = Config::get( 'sms_api_key', '' );
        $sender  = Config::get( 'sms_sender', 'GSVRFY' );
        $response = wp_remote_post( 'https://api.msg91.com/api/v2/sendsms', [
            'timeout' => 10,
            'headers' => [ 'authkey' => $api_key, 'Content-Type' => 'application/json' ],
            'body'    => wp_json_encode( [
                'sender'   => $sender,
                'route'    => '4', // transactional route
                'country'  => '91',
                'sms'      => [ [ 'message' => substr( $body, 0, 320 ), 'to' => [ $phone ] ] ],
            ] ),
        ] );
        if ( is_wp_error( $response ) ) { return false; }
        $code = wp_remote_retrieve_response_code( $response );
        return $code >= 200 && $code < 300;
    }

    // ── Private helpers ────────────────────────────────────────────────────────

    private static function generate(): string {
        return str_pad( (string) random_int( 0, 999999 ), self::OTP_LENGTH, '0', STR_PAD_LEFT );
    }

    private static function build_message( string $otp, string $purpose ): string {
        $platform = Config::get( 'platform_name', 'GoodService' );
        return match ( $purpose ) {
            'booking' => "{$otp} is your {$platform} OTP to confirm your booking. Valid 5 mins. Do not share.",
            'profile' => "{$otp} is your {$platform} OTP to verify your phone number. Valid 5 mins.",
            default   => "{$otp} is your {$platform} verification code. Valid 5 mins.",
        };
    }

    private static function normalise_phone( string $phone ): string {
        $clean = preg_replace( '/\D/', '', $phone );
        // India: add 91 prefix if missing
        if ( strlen( $clean ) === 10 ) { $clean = '91' . $clean; }
        if ( strlen( $clean ) < 10 || strlen( $clean ) > 15 ) { return ''; }
        return $clean;
    }

    // ── SMS providers ──────────────────────────────────────────────────────────

    /** Send via Msg91 (India-focused, requires DLT template registration). */
    private static function send_msg91( string $phone, string $otp ): bool {
        $api_key     = Config::get( 'sms_api_key', '' );
        $sender      = Config::get( 'sms_sender', 'GSVRFY' );
        $template_id = Config::get( 'msg91_template_id', '' );

        // Msg91 OTP API (v5)
        $response = wp_remote_post( 'https://api.msg91.com/api/v5/otp', [
            'timeout' => 10,
            'headers' => [
                'authkey'      => $api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode( [
                'mobile'      => $phone,
                'otp'         => $otp,
                'sender'      => $sender,
                'template_id' => $template_id,
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            gs_write_log( 'OtpService Msg91 error: ' . $response->get_error_message(), 'ERROR' );
            return false;
        }
        $code = wp_remote_retrieve_response_code( $response );
        return $code >= 200 && $code < 300;
    }

    /** Send via TextLocal (India-focused, simple HTTP API). */
    private static function send_textlocal( string $phone, string $message ): bool {
        $api_key = Config::get( 'sms_api_key', '' );
        $sender  = Config::get( 'sms_sender', 'GSVRFY' );

        $response = wp_remote_post( 'https://api.textlocal.in/send/', [
            'timeout' => 10,
            'body'    => [
                'apikey'  => $api_key,
                'numbers' => $phone,
                'message' => $message,
                'sender'  => $sender,
            ],
        ] );

        if ( is_wp_error( $response ) ) {
            gs_write_log( 'OtpService TextLocal error: ' . $response->get_error_message(), 'ERROR' );
            return false;
        }
        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        return ( $body['status'] ?? '' ) === 'success';
    }
}
