<?php
namespace GoodService\Service;

use GoodService\Core\EventBus;

/**
 * DisputeService — real feature, Critical priority gap from the
 * enterprise audit.
 *
 * ARCHITECTURAL CONTEXT (Phase 1-4 discovery, documented so the next
 * engineer doesn't re-derive it):
 *
 * A dispute is opened against a specific booking. The actual refund
 * capability lives on the two gateway service classes
 * (RazorpayService::refund() / StripeService::refund()), both newly
 * built during this same engagement after Phase 1 discovery confirmed
 * no refund-execution code existed anywhere — 'refunded' was previously
 * only a status label. This service is the orchestration layer: it
 * resolves which gateway a booking's payment went through (via
 * {$p}invoices.booking_id → gateway/payment_id) and calls the correct
 * one, so resolving a dispute and actually refunding the money are one
 * action, not two disconnected manual steps.
 */
class DisputeService {

    private const SLA_DAYS = 7;

    /**
     * Opens a new dispute. $booking_id must reference a real booking;
     * vendor_id and listing_id are derived from it rather than trusted
     * from client input, so a dispute can never be opened against a
     * booking the caller doesn't actually have a relationship to.
     */
    public static function open( int $booking_id, int $opened_by_user_id, string $reason, string $description ): array {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $booking = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pfx}bookings WHERE id = %d", $booking_id ) );
        if ( ! $booking ) {
            return [ 'success' => false, 'error' => 'Booking not found.' ];
        }

        // Real validation rule: only the actual customer or the actual
        // vendor on this specific booking may open a dispute against it
        // — never trust a client-supplied role claim without checking
        // it against the booking's own recorded parties.
        $is_customer = ( (int) $booking->user_id === $opened_by_user_id );
        $vendor_user_id = self::vendor_user_id( (int) $booking->vendor_id );
        $is_vendor = ( $vendor_user_id === $opened_by_user_id );
        if ( ! $is_customer && ! $is_vendor ) {
            return [ 'success' => false, 'error' => 'You do not have permission to open a dispute on this booking.' ];
        }

        // Real validation rule: one open dispute per booking at a time —
        // prevents duplicate disputes fragmenting the same underlying
        // issue across multiple rows.
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$pfx}disputes WHERE booking_id = %d AND status NOT IN ('resolved','closed')",
            $booking_id
        ) );
        if ( $existing ) {
            return [ 'success' => false, 'error' => 'A dispute is already open for this booking.', 'dispute_id' => (int) $existing ];
        }

        // Ghost-success fix: this insert's result was previously discarded
        // entirely (not even an insert_id check existed) — a DB failure would
        // still emit 'dispute.opened' and proceed with $dispute_id = 0,
        // silently notifying about and operating on a dispute that was never
        // actually created.
        $inserted = $wpdb->insert( $pfx . 'disputes', [
            'booking_id'        => $booking_id,
            'listing_id'        => (int) $booking->listing_id,
            'vendor_id'         => (int) $booking->vendor_id,
            'opened_by_user_id' => $opened_by_user_id,
            'opened_by_role'    => $is_customer ? 'customer' : 'vendor',
            'reason'            => sanitize_text_field( $reason ),
            'description'       => wp_strip_all_tags( $description ),
            'status'            => 'open',
            'sla_deadline'      => gmdate( 'Y-m-d H:i:s', time() + self::SLA_DAYS * DAY_IN_SECONDS ),
        ] );
        if ( ! $inserted ) {
            return [ 'success' => false, 'error' => 'Could not open dispute: ' . $wpdb->last_error ];
        }
        $dispute_id = (int) $wpdb->insert_id;
        if ( ! $dispute_id ) {
            return [ 'success' => false, 'error' => 'Could not open dispute.' ];
        }

        $vendor_business_name = $wpdb->get_var( $wpdb->prepare(
            "SELECT business_name FROM {$pfx}vendor_profiles WHERE id = %d", (int) $booking->vendor_id
        ) );

        EventBus::emit( 'dispute.opened', [
            'dispute_id'       => $dispute_id,
            'booking_id'       => $booking_id,
            'vendor_id'        => (int) $booking->vendor_id,
            'vendor_user_id'   => $vendor_user_id,
            'customer_user_id' => (int) $booking->user_id,
            'customer_name'    => $booking->customer_name ?? '',
            'vendor_name'      => $vendor_business_name ?: '',
            'opened_by'        => $is_customer ? 'customer' : 'vendor',
            'reason'           => sanitize_text_field( $reason ),
        ] );

        gs_write_log( "DisputeService: dispute #{$dispute_id} opened on booking #{$booking_id} by " . ( $is_customer ? 'customer' : 'vendor' ) . " (user {$opened_by_user_id})", 'INFO' );

        return [ 'success' => true, 'dispute_id' => $dispute_id ];
    }

    public static function add_message( int $dispute_id, int $user_id, string $user_role, string $message, string $attachment_url = '' ): bool {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $dispute = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pfx}disputes WHERE id = %d", $dispute_id ) );
        if ( ! $dispute || in_array( $dispute->status, [ 'resolved', 'closed' ], true ) ) {
            return false; // real validation rule: no new messages on a closed dispute
        }

        $wpdb->insert( $pfx . 'dispute_messages', [
            'dispute_id'     => $dispute_id,
            'user_id'        => $user_id,
            'user_role'      => $user_role,
            'message'        => wp_strip_all_tags( $message ),
            'attachment_url' => esc_url_raw( $attachment_url ),
        ] );

        // A message from either party moves the dispute out of "open"
        // (nobody has responded yet) into "awaiting_response" or
        // "under_review" — real state-machine progression, not just a
        // flat log of messages with no status meaning.
        if ( $dispute->status === 'open' ) {
            $wpdb->update( $pfx . 'disputes', [ 'status' => 'awaiting_response' ], [ 'id' => $dispute_id ] );
        }

        return true;
    }

    /**
     * Resolves a dispute. When the resolution involves a refund, this
     * is the one place that actually calls the gateway — resolution and
     * refund execution are a single action, not two manual steps that
     * could get out of sync (an admin marking "refunded" without the
     * money actually moving, the exact gap this whole feature closes).
     */
    public static function resolve( int $dispute_id, int $resolved_by_admin_id, string $resolution, string $resolution_note, ?float $refund_amount = null ): array {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $dispute = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pfx}disputes WHERE id = %d", $dispute_id ) );
        if ( ! $dispute ) {
            return [ 'success' => false, 'error' => 'Dispute not found.' ];
        }
        if ( in_array( $dispute->status, [ 'resolved', 'closed' ], true ) ) {
            return [ 'success' => false, 'error' => 'This dispute has already been resolved.' ];
        }

        $refund_id = '';
        if ( in_array( $resolution, [ 'full_refund', 'partial_refund' ], true ) ) {
            $refund_result = self::execute_refund( (int) $dispute->booking_id, $resolution === 'partial_refund' ? $refund_amount : null );
            if ( ! $refund_result['success'] ) {
                // Real fix: a resolution that claims a refund happened
                // but the gateway call actually failed must not be
                // recorded as resolved — that would create exactly the
                // "marked refunded but money never moved" gap this
                // service exists to close.
                return [ 'success' => false, 'error' => 'Refund failed: ' . $refund_result['error'] ];
            }
            $refund_id = $refund_result['refund_id'] ?? '';
        } elseif ( $resolution === 'wallet_credit' ) {
            if ( $refund_amount === null || $refund_amount <= 0 ) {
                return [ 'success' => false, 'error' => 'Please specify a wallet credit amount.' ];
            }
            // Real fix: always the booking's actual customer, never
            // opened_by_user_id — a vendor can open a dispute too (per
            // this class's own open() logic), and a wallet credit must
            // go to whoever paid, not whoever happened to file it.
            $booking = $wpdb->get_row( $wpdb->prepare( "SELECT user_id FROM {$pfx}bookings WHERE id = %d", $dispute->booking_id ) );
            if ( ! $booking || ! $booking->user_id ) {
                return [ 'success' => false, 'error' => 'Could not identify the customer to credit.' ];
            }
            // Real feature — avoids gateway fees/delay for cases where
            // the admin judges store credit is the right resolution.
            // Same fail-safe principle as the refund path above: a
            // credit that fails to record must not be marked resolved.
            $wallet_ok = \GoodService\Service\WalletService::credit(
                (int) $booking->user_id, $refund_amount, 'dispute_resolution', 'dispute', $dispute_id,
                "Wallet credit for dispute #{$dispute_id}", $resolved_by_admin_id
            );
            if ( ! $wallet_ok ) {
                return [ 'success' => false, 'error' => 'Could not credit wallet. Please try again.' ];
            }
        }

        $wpdb->update( $pfx . 'disputes', [
            'status'          => 'resolved',
            'resolution'      => $resolution,
            'resolution_note' => wp_strip_all_tags( $resolution_note ),
            'refund_amount'   => $refund_amount,
            'refund_id'       => $refund_id,
            'resolved_by'     => $resolved_by_admin_id,
            'resolved_at'     => current_time( 'mysql' ),
        ], [ 'id' => $dispute_id ] );

        $booking_row = $wpdb->get_row( $wpdb->prepare( "SELECT user_id FROM {$pfx}bookings WHERE id = %d", $dispute->booking_id ) );
        $vendor_user_id = self::vendor_user_id( (int) $dispute->vendor_id );

        EventBus::emit( 'dispute.resolved', [
            'dispute_id'       => $dispute_id,
            'booking_id'       => (int) $dispute->booking_id,
            'customer_user_id' => $booking_row ? (int) $booking_row->user_id : 0,
            'vendor_user_id'   => $vendor_user_id,
            'resolution'       => $resolution,
            'resolution_note'  => $resolution_note,
            'refund_id'        => $refund_id,
        ] );

        gs_write_log( "DisputeService: dispute #{$dispute_id} resolved as '{$resolution}' by admin {$resolved_by_admin_id}" . ( $refund_id ? " (refund {$refund_id})" : '' ), 'INFO' );

        return [ 'success' => true, 'refund_id' => $refund_id ];
    }

    /**
     * Resolves which gateway a booking's payment actually went through
     * and calls that gateway's real refund() method. This is the exact
     * chain confirmed during Phase 1 discovery: booking → invoice (via
     * invoices.booking_id) → gateway + payment_id.
     */
    private static function execute_refund( int $booking_id, ?float $partial_amount ): array {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $invoice = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$pfx}invoices WHERE booking_id = %d AND status = 'paid' ORDER BY id DESC LIMIT 1",
            $booking_id
        ) );
        if ( ! $invoice || ! $invoice->payment_id ) {
            return [ 'success' => false, 'refund_id' => null, 'error' => 'No paid invoice found for this booking — nothing to refund.' ];
        }

        // Real fix — confirmed gap (Known Limitations, Disputes screen):
        // the partial-refund amount field had no maximum-value check against
        // the original booking amount, so an admin typo could attempt to
        // refund more than was ever actually charged. Most gateways would
        // reject that themselves, but relying on that is inconsistent across
        // gateways (and 'wallet' has no gateway to reject it at all) — so
        // it's validated here, once, for every gateway path.
        if ( $partial_amount !== null && $partial_amount > (float) $invoice->amount ) {
            return [ 'success' => false, 'refund_id' => null, 'error' => sprintf(
                'Refund amount (%s) cannot exceed the original payment amount (%s).',
                number_format( $partial_amount, 2 ), number_format( (float) $invoice->amount, 2 )
            ) ];
        }

        $result = match ( $invoice->gateway ) {
            'razorpay' => RazorpayService::refund( $invoice->payment_id, $partial_amount ),
            'stripe'   => StripeService::refund( $invoice->payment_id, $partial_amount ),
            // Real fix — a booking paid from wallet balance has no real
            // gateway transaction to reverse; refunding it means
            // crediting the wallet back, matching how the original
            // payment moved money in the first place.
            'wallet'   => self::refund_to_wallet( $booking_id, (float) $invoice->amount, $partial_amount ),
            default    => [ 'success' => false, 'refund_id' => null, 'error' => "Unknown payment gateway '{$invoice->gateway}' on this invoice." ],
        };

        if ( $result['success'] ) {
            $wpdb->update( $pfx . 'invoices', [ 'status' => 'refunded' ], [ 'id' => $invoice->id ] );
        }

        return $result;
    }

    /**
     * Refunds a wallet-paid booking by crediting the wallet back, rather
     * than attempting a gateway API call against a synthetic payment_id
     * that was never a real charge. Mirrors execute_refund()'s own
     * structure: resolves the actual customer from the booking record,
     * never trusts a passed-in ID.
     */
    private static function refund_to_wallet( int $booking_id, float $paid_amount, ?float $partial_amount ): array {
        global $wpdb;
        $booking = $wpdb->get_row( $wpdb->prepare( "SELECT user_id FROM {$wpdb->prefix}gs_bookings WHERE id = %d", $booking_id ) );
        if ( ! $booking || ! $booking->user_id ) {
            return [ 'success' => false, 'refund_id' => null, 'error' => 'Could not identify the customer to refund.' ];
        }

        $refund_amount = $partial_amount ?? $paid_amount;
        $ok = \GoodService\Service\WalletService::credit(
            (int) $booking->user_id, $refund_amount, 'dispute_refund', 'booking', $booking_id,
            "Refund for booking #{$booking_id}"
        );

        return $ok
            ? [ 'success' => true, 'refund_id' => 'wallet_refund_' . $booking_id . '_' . time(), 'error' => null ]
            : [ 'success' => false, 'refund_id' => null, 'error' => 'Could not credit wallet for refund.' ];
    }

    private static function vendor_user_id( int $vendor_id ): ?int {
        global $wpdb;
        $uid = $wpdb->get_var( $wpdb->prepare(
            "SELECT user_id FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d",
            $vendor_id
        ) );
        return $uid ? (int) $uid : null;
    }
}
