<?php
namespace GoodService\Service;

use GoodService\Core\Cache;

/**
 * ProfitIntelligenceService — Vendor profit insights and market benchmarks (Moat 7)
 * Analyses vendor's pricing, response, win/loss vs market.
 * Results cached 6 hours.
 */
final class ProfitIntelligenceService {

    public static function get_report( int $vendor_id ): array {
        $cache_key = "gs_intel_{$vendor_id}_" . date( 'YmdH' );
        $cached    = Cache::get( $cache_key );
        if ( $cached !== null ) { return $cached; }

        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $vendor  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pfx}vendor_profiles WHERE id=%d", $vendor_id ) );
        $listing = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$pfx}listings WHERE vendor_id=%d AND status='active' ORDER BY is_featured DESC LIMIT 1", $vendor_id
        ) );
        if ( ! $listing ) { return [ 'error' => 'No active listing found.' ]; }

        $report = [
            'pricing'     => self::get_pricing_insights( $vendor_id, $listing, $wpdb ),
            'response'    => self::get_response_insights( $vendor_id, $wpdb ),
            'win_loss'    => self::get_win_loss_analysis( $vendor_id, $wpdb ),
            'demand'      => self::get_demand_forecast( $listing->category_slug ?? '', $listing->city ?? '', $wpdb ),
            'revenue_opt' => self::get_revenue_opportunities( $vendor_id, $listing, $wpdb ),
        ];

        Cache::set( $cache_key, $report, 6 * HOUR_IN_SECONDS );
        return $report;
    }

    private static function get_pricing_insights( int $vendor_id, object $listing, $wpdb ): array {
        $my_price    = (float) ( $listing->starting_price ?? 0 );
        $competitors = $wpdb->get_col( $wpdb->prepare(
            "SELECT li.starting_price FROM {$wpdb->prefix}gs_listings li
             WHERE li.category_id=%d AND li.city=%s AND li.status='active' AND li.vendor_id!=%d AND li.starting_price>0
             ORDER BY RAND() LIMIT 20",
            (int) ( $listing->category_id ?? 0 ), (string) ( $listing->city ?? '' ), $vendor_id
        ) ) ?: [];

        if ( empty( $competitors ) ) {
            return [ 'available' => false, 'reason' => 'Not enough market data in your area yet.' ];
        }

        sort( $competitors );
        $n        = count( $competitors );
        $avg      = array_sum( $competitors ) / $n;
        $p25      = (float) $competitors[ (int) floor( $n * 0.25 ) ];
        $p75      = (float) $competitors[ (int) floor( $n * 0.75 ) ];
        $position = $my_price > 0 ? ( $my_price < $p25 ? 'low' : ( $my_price > $p75 ? 'high' : 'competitive' ) ) : 'unknown';

        if ( $position === 'low' ) {
            $insight = "You are priced below 75% of competitors. Consider raising by \u20b9" . round( ( $avg_price - $my_price ) * 0.5, -1 ) . ".";
        } elseif ( $position === 'high' ) {
            $insight = "You are priced above 75% of competitors. This is fine if your conversion rate is strong.";
        } else {
            $insight = "Your pricing is competitive with the local market.";
        }

        return [
            'available'   => true,
            'my_price'    => $my_price,
            'market_avg'  => round( $avg, 2 ),
            'market_p25'  => round( $p25, 2 ),
            'market_p75'  => round( $p75, 2 ),
            'position'    => $position,
            'insight'     => $insight,
        ];
    }

    private static function get_response_insights( int $vendor_id, $wpdb ): array {
        $stats = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS total,
                    SUM(replied_at IS NOT NULL) AS replied,
                    AVG(CASE WHEN replied_at IS NOT NULL THEN TIMESTAMPDIFF(MINUTE,created_at,replied_at) END) AS avg_min
             FROM {$wpdb->prefix}gs_leads WHERE vendor_id=%d AND created_at>DATE_SUB(NOW(),INTERVAL 90 DAY)",
            $vendor_id
        ) );
        $rate   = $stats && $stats->total > 0 ? round( $stats->replied / $stats->total * 100, 1 ) : 0;
        $avg_m  = (int) ( $stats->avg_min ?? 0 );

        // Platform benchmark
        $bench_rate = (float) ( $wpdb->get_var( "SELECT AVG(CASE WHEN replied_at IS NOT NULL THEN 1 ELSE 0 END)*100 FROM {$wpdb->prefix}gs_leads WHERE created_at>DATE_SUB(NOW(),INTERVAL 90 DAY)" ) ?? 60 );
        $bench_time = (int) ( $wpdb->get_var( "SELECT AVG(CASE WHEN replied_at IS NOT NULL THEN TIMESTAMPDIFF(MINUTE,created_at,replied_at) END) FROM {$wpdb->prefix}gs_leads WHERE created_at>DATE_SUB(NOW(),INTERVAL 90 DAY)" ) ?? 180 );

        return [
            'your_rate'       => $rate,
            'your_avg_min'    => $avg_m,
            'benchmark_rate'  => round( $bench_rate, 1 ),
            'benchmark_min'   => $bench_time,
            'above_benchmark' => $rate > $bench_rate,
            'insight'         => $rate >= $bench_rate
                ? "Your response rate ({$rate}%) is above the platform average ({$bench_rate}%). Keep it up!"
                : "Your response rate ({$rate}%) is below the platform average ({$bench_rate}%). Faster replies win more jobs.",
        ];
    }

    private static function get_win_loss_analysis( int $vendor_id, $wpdb ): array {
        $data = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS total,
                    SUM(status='converted') AS won,
                    SUM(status='new' OR status='viewed') AS pending
             FROM {$wpdb->prefix}gs_leads WHERE vendor_id=%d AND created_at>DATE_SUB(NOW(),INTERVAL 90 DAY)",
            $vendor_id
        ) );
        $win_rate = $data && $data->total > 0 ? round( $data->won / $data->total * 100, 1 ) : 0;
        return [
            'total'    => (int) ( $data->total   ?? 0 ),
            'won'      => (int) ( $data->won      ?? 0 ),
            'pending'  => (int) ( $data->pending  ?? 0 ),
            'win_rate' => $win_rate,
            'insight'  => $win_rate > 20
                ? "You convert {$win_rate}% of inquiries to paid work — strong performance."
                : "Your conversion rate is {$win_rate}%. Try following up unanswered inquiries within 30 minutes.",
        ];
    }

    private static function get_demand_forecast( string $category, string $city, $wpdb ): array {
        if ( ! $category ) { return [ 'available' => false ]; }
        $monthly = $wpdb->get_results( $wpdb->prepare(
            "SELECT DATE_FORMAT(created_at,'%%Y-%%m') AS mon, COUNT(*) AS cnt
             FROM {$wpdb->prefix}gs_leads WHERE inquiry_module=%s AND created_at>DATE_SUB(NOW(),INTERVAL 12 MONTH)
             GROUP BY mon ORDER BY mon ASC",
            $category
        ) ) ?: [];
        if ( count( $monthly ) < 3 ) { return [ 'available' => false, 'reason' => 'Not enough historical data yet.' ]; }

        $months = array_column( $monthly, 'cnt' );
        $peak_idx  = array_search( max( $months ), $months );
        $peak_month = $monthly[ $peak_idx ]->mon ?? '';
        $peak_name  = $peak_month ? date( 'F', mktime( 0, 0, 0, (int) substr( $peak_month, 5, 2 ), 1 ) ) : '';

        $last   = end( $months );
        $prev   = count( $months ) >= 2 ? $months[ count( $months ) - 2 ] : $last;
        $trend  = $prev > 0 ? round( ( $last - $prev ) / $prev * 100, 1 ) : 0;

        return [
            'available'   => true,
            'monthly'     => $monthly,
            'peak_month'  => $peak_name,
            'trend'       => $trend,
            'insight'     => $peak_name
                ? "Demand for {$category} peaks in {$peak_name}. Consider promoting your listing before then."
                : "Demand is stable.",
        ];
    }

    private static function get_revenue_opportunities( int $vendor_id, object $listing, $wpdb ): array {
        $ops = [];

        // Check response rate
        $rr = (float) ( $wpdb->get_var( $wpdb->prepare(
            "SELECT response_rate FROM {$wpdb->prefix}gs_vendor_profiles WHERE id=%d", $vendor_id
        ) ) ?? 0 );
        if ( $rr < 80 ) {
            $ops[] = [ 'type' => 'response', 'impact' => 'high',
                'title'   => 'Improve response rate',
                'detail'  => "You reply to {$rr}% of inquiries. Vendors at 90%+ earn 2× more bookings. Enable notifications to catch leads faster." ];
        }

        // Check profile completeness
        $missing = [];
        if ( empty( $listing->cover_photo ) ) { $missing[] = 'cover photo'; }
        if ( empty( $listing->description ) || strlen( $listing->description ) < 150 ) { $missing[] = 'detailed description'; }
        $vp = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}gs_vendor_profiles WHERE id=%d", $vendor_id ) );
        if ( empty( $vp->video_intro_url ?? '' ) ) { $missing[] = 'video intro'; }
        if ( ! empty( $missing ) ) {
            $ops[] = [ 'type' => 'profile', 'impact' => 'medium',
                'title'   => 'Complete your profile',
                'detail'  => "Missing: " . implode( ', ', $missing ) . ". Complete profiles get 3× more views." ];
        }

        // Check if listing is in top 3 positions
        $rank = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*)+1 FROM {$wpdb->prefix}gs_listings WHERE category_id=%d AND city=%s AND status='active' AND trust_score>(SELECT trust_score FROM {$wpdb->prefix}gs_vendor_profiles WHERE id=%d)",
            (int) ( $listing->category_id ?? 0 ), (string) ( $listing->city ?? '' ), $vendor_id
        ) );
        if ( $rank && (int) $rank > 5 ) {
            $ops[] = [ 'type' => 'ranking', 'impact' => 'high',
                'title'   => "You are ranked #{$rank} in your area",
                'detail'  => "Top 5 vendors get 80% of inquiries. Reply faster and collect reviews to improve your ranking." ];
        }

        return $ops;
    }

    /** Monthly cron: compute market benchmarks. */
    public static function compute_monthly_benchmarks(): void {
        global $wpdb;
        $pfx   = $wpdb->prefix . 'gs_';
        $month = date( 'Y-m' );

        $categories = $wpdb->get_col( "SELECT DISTINCT inquiry_module FROM {$pfx}leads WHERE inquiry_module!='' AND created_at>DATE_SUB(NOW(),INTERVAL 30 DAY)" ) ?: [];
        foreach ( $categories as $cat ) {
            $cities = $wpdb->get_col( $wpdb->prepare(
                "SELECT DISTINCT l.city FROM {$pfx}leads l WHERE l.inquiry_module=%s AND l.city!='' AND l.created_at>DATE_SUB(NOW(),INTERVAL 30 DAY) LIMIT 20",
                $cat
            ) ) ?: [];

            foreach ( $cities as $city ) {
                $stats = $wpdb->get_row( $wpdb->prepare(
                    "SELECT COUNT(*) AS cnt,
                            AVG(CASE WHEN replied_at IS NOT NULL THEN TIMESTAMPDIFF(MINUTE,created_at,replied_at) END) AS avg_rt,
                            SUM(status='converted') AS won
                     FROM {$pfx}leads WHERE inquiry_module=%s AND city=%s AND created_at>DATE_SUB(NOW(),INTERVAL 30 DAY)",
                    $cat, $city
                ) );

                if ( ! $stats || $stats->cnt < 3 ) { continue; }

                $conv_rate = round( $stats->won / $stats->cnt * 100, 2 );
                $demand_i  = min( 100, (int) ( $stats->cnt * 5 ) );

                $wpdb->replace( $wpdb->prefix . 'gs_market_benchmarks', [
                    'category_slug'         => $cat,
                    'city'                  => $city,
                    'month'                 => $month,
                    'avg_response_time_min' => (int) ( $stats->avg_rt ?? 0 ),
                    'avg_conversion_rate'   => $conv_rate,
                    'top_quartile_leads'    => (int) ceil( $stats->cnt / 4 ),
                    'demand_index'          => $demand_i,
                    'computed_at'           => current_time( 'mysql' ),
                ] );
            }
        }
    }
}
