<?php
namespace GoodService\Service;

use GoodService\Core\Cache;

/**
 * CertificationService — Vendor Training & Certification Platform (Moat 6)
 * Tracks course progress, awards certifications, verifies cert numbers.
 * Note: PDF certificate generation requires dompdf (Composer) — badge display works without it.
 */
final class CertificationService {

    /** Record a completed course module and check if vendor passed. */
    public static function complete_module( int $vendor_id, int $course_id, int $module_index ): array {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $progress = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$pfx}vendor_course_progress WHERE vendor_id=%d AND course_id=%d",
            $vendor_id, $course_id
        ) );

        if ( ! $progress ) {
            $wpdb->insert( $wpdb->prefix . 'gs_vendor_course_progress', [
                'vendor_id'          => $vendor_id,
                'course_id'          => $course_id,
                'modules_completed'  => wp_json_encode( [ $module_index ] ),
                'status'             => 'in_progress',
                'started_at'         => current_time( 'mysql' ),
            ] );
        } else {
            $completed = json_decode( $progress->modules_completed, true ) ?: [];
            if ( ! in_array( $module_index, $completed, true ) ) {
                $completed[] = $module_index;
            }
            $course = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pfx}courses WHERE id=%d", $course_id ) );
            $modules_total = $course ? count( json_decode( $course->modules ?? '[]', true ) ?: [] ) : 1;
            $is_complete   = count( $completed ) >= $modules_total;

            $wpdb->update( $wpdb->prefix . 'gs_vendor_course_progress', [
                'modules_completed' => wp_json_encode( $completed ),
                'status'            => $is_complete ? 'passed' : 'in_progress',
                'completed_at'      => $is_complete ? current_time( 'mysql' ) : null,
                'final_score'       => $is_complete ? 100 : null,
            ], [ 'vendor_id' => $vendor_id, 'course_id' => $course_id ] );

            if ( $is_complete && $course ) {
                self::award_certification( $vendor_id, $course, 100 );
                return [ 'completed' => true, 'course_title' => $course->title ];
            }
        }
        return [ 'completed' => false, 'module_index' => $module_index ];
    }

    /** Submit quiz answers and compute score. */
    public static function submit_quiz( int $vendor_id, int $course_id, array $answers ): array {
        global $wpdb;
        $pfx    = $wpdb->prefix . 'gs_';
        $course = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pfx}courses WHERE id=%d", $course_id ) );
        if ( ! $course ) { return [ 'success' => false, 'message' => 'Course not found.' ]; }

        $modules = json_decode( $course->modules ?? '[]', true ) ?: [];
        $total = 0; $correct = 0;

        foreach ( $modules as $module ) {
            foreach ( $module['quiz'] ?? [] as $q_idx => $q ) {
                $total++;
                $submitted = $answers[ $q_idx ] ?? null;
                if ( $submitted !== null && (int) $submitted === (int) ( $q['correct'] ?? -1 ) ) {
                    $correct++;
                }
            }
        }

        $score   = $total > 0 ? round( $correct / $total * 100 ) : 0;
        $passing = (int) ( $course->passing_score ?? 70 );
        $passed  = $score >= $passing;

        // Record attempt
        $progress = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$pfx}vendor_course_progress WHERE vendor_id=%d AND course_id=%d",
            $vendor_id, $course_id
        ) );
        $attempts = $progress ? ( json_decode( $progress->quiz_attempts ?? '[]', true ) ?: [] ) : [];
        $attempts[] = [ 'score' => $score, 'passed' => $passed, 'date' => current_time( 'mysql' ) ];

        if ( $progress ) {
            $wpdb->update( $wpdb->prefix . 'gs_vendor_course_progress', [
                'quiz_attempts' => wp_json_encode( $attempts ),
                'status'        => $passed ? 'passed' : ( count( $attempts ) > 2 ? 'failed' : 'in_progress' ),
                'final_score'   => $passed ? $score : ( $progress->final_score ?? null ),
                'completed_at'  => $passed ? current_time( 'mysql' ) : null,
            ], [ 'vendor_id' => $vendor_id, 'course_id' => $course_id ] );
        } else {
            $wpdb->insert( $wpdb->prefix . 'gs_vendor_course_progress', [
                'vendor_id'      => $vendor_id,
                'course_id'      => $course_id,
                'quiz_attempts'  => wp_json_encode( $attempts ),
                'status'         => $passed ? 'passed' : 'in_progress',
                'final_score'    => $passed ? $score : null,
                'started_at'     => current_time( 'mysql' ),
                'completed_at'   => $passed ? current_time( 'mysql' ) : null,
            ] );
        }

        if ( $passed ) {
            self::award_certification( $vendor_id, $course, $score );
        }

        return [
            'success'        => true,
            'score'          => $score,
            'passed'         => $passed,
            'passing_score'  => $passing,
            'attempts'       => count( $attempts ),
            'message'        => $passed ? "Congratulations! You passed with {$score}%." : "You scored {$score}%. Passing score is {$passing}%.",
        ];
    }

    /** Award a certification to a vendor. */
    public static function award_certification( int $vendor_id, object $course, int $score ): void {
        global $wpdb;

        // Check if already has active cert for this course
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_vendor_certifications WHERE vendor_id=%d AND course_id=%d AND is_active=1",
            $vendor_id, $course->id
        ) );
        if ( $existing ) { return; }

        $cert_level = $score >= 90 ? 'advanced' : ( $score >= 75 ? 'intermediate' : 'basic' );
        $cert_num   = 'GS-' . strtoupper( substr( $course->category_slug ?? 'GEN', 0, 4 ) )
                    . '-' . date( 'Y' ) . '-' . str_pad( $vendor_id, 5, '0', STR_PAD_LEFT );

        $wpdb->insert( $wpdb->prefix . 'gs_vendor_certifications', [
            'vendor_id'     => $vendor_id,
            'course_id'     => (int) $course->id,
            'category_slug' => $course->category_slug ?? '',
            'cert_level'    => $cert_level,
            'issued_at'     => date( 'Y-m-d' ),
            'expires_at'    => date( 'Y-m-d', strtotime( '+2 years' ) ),
            'cert_number'   => $cert_num,
            'is_active'     => 1,
        ] );

        // Notify vendor
        $vp = $wpdb->get_row( $wpdb->prepare(
            "SELECT user_id FROM {$wpdb->prefix}gs_vendor_profiles WHERE id=%d", $vendor_id
        ) );
        if ( $vp ) {
            NotificationService::create(
                (int) $vp->user_id, 'cert.earned', '🏅 Certification earned!',
                "You are now GoodService Certified in {$course->title}.",
                home_url( '/vendor/dashboard/?section=certifications' ),
                'award', '#D97706'
            );
        }
    }

    /** Verify a certification number (public). */
    public static function verify( string $cert_number ): ?array {
        global $wpdb;
        $cert = $wpdb->get_row( $wpdb->prepare(
            "SELECT vc.*, c.title AS course_title, vp.business_name
             FROM {$wpdb->prefix}gs_vendor_certifications vc
             JOIN {$wpdb->prefix}gs_courses c ON c.id=vc.course_id
             JOIN {$wpdb->prefix}gs_vendor_profiles vp ON vp.id=vc.vendor_id
             WHERE vc.cert_number=%s AND vc.is_active=1",
            sanitize_text_field( $cert_number )
        ) );
        return $cert ? (array) $cert : null;
    }
}
