<?php
namespace GoodService\Service;

use GoodService\Core\Config;

/**
 * WhatsAppVerificationService — optional WhatsApp verification (Section 2 of the
 * inquiry/booking audit). NOT mandatory — email verification (EmailVerificationService)
 * remains the default for every inquiry/booking. This is an additional, opt-in channel
 * an admin can turn on globally, a vendor can override per-listing, and which can be
 * further overridden per inquiry-module/category.
 *
 * Resolution order (most specific wins): module setting → vendor setting → global
 * setting → off. A module/vendor set to 'inherit' falls through to the next level;
 * only an explicit 'on' or 'off' stops the resolution early.
 *
 * Built on the existing, already-working WhatsAppService::send_text() (real BSP API
 * integration — 360dialog/Interakt) rather than introducing a second WhatsApp
 * transport. If no WhatsApp API key is configured, WhatsAppService::send_text()
 * already returns false safely — this service surfaces that as a normal
 * "could not send" result, not a crash, so turning the toggle on without a BSP key
 * configured degrades gracefully rather than breaking the inquiry form.
 */
final class WhatsAppVerificationService {

    private const OTP_TTL_MINUTES = 10;
    private const OTP_LENGTH      = 6;

    public static function ensure_table(): void {
        global $wpdb;
        $tbl = $wpdb->prefix . 'gs_whatsapp_verify_tokens';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) { return; }
        $wpdb->query( "
            CREATE TABLE IF NOT EXISTS {$tbl} (
                id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                phone      VARCHAR(30)     NOT NULL,
                otp_hash   VARCHAR(128)    NOT NULL,
                attempts   TINYINT UNSIGNED DEFAULT 0,
                verified   TINYINT(1)      DEFAULT 0,
                token      CHAR(64)        DEFAULT NULL,
                expires_at DATETIME        NOT NULL,
                created_at DATETIME        DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY idx_phone (phone)
            ) " . $wpdb->get_charset_collate()
        );
    }

    /**
     * Resolve whether WhatsApp verification is active for a given listing + module.
     * @param object|null $listing  gs_listings row (needs vendor_id + inquiry_modules_data), or null to check global only.
     * @param string      $module_slug
     */
    public static function is_enabled( ?object $listing, string $module_slug = '' ): bool {
        // 1. Admin's global setting is checked FIRST and is a hard ceiling —
        // real fix (Section 5 of the verification spec: "Admin settings
        // should take priority over vendor settings where applicable").
        // Previously this same Config::get() call was the LAST check, after
        // module/vendor overrides — meaning a vendor (or a module config
        // nested inside a vendor's own listing) could set 'on' and enable
        // WhatsApp verification even when the admin had it globally off.
        // That's backwards: an admin turning this off platform-wide must
        // mean off, full stop, not "off unless a vendor disagrees."
        $global_enabled = (bool) Config::get( 'whatsapp_verify_enabled', false );
        if ( ! $global_enabled ) { return false; }

        // Admin allows the feature — vendors/modules may still fine-tune
        // (e.g. turn it off for their own listing even though the platform
        // allows it), same resolution order as before for that narrower
        // decision: module-level override (most specific) first, then
        // vendor-level, only ever able to restrict further, never to
        // re-enable something the admin has switched off above.
        if ( $listing && $module_slug && ! empty( $listing->inquiry_modules_data ) ) {
            $modules_cfg = json_decode( (string) $listing->inquiry_modules_data, true ) ?: [];
            $mode = $modules_cfg[ $module_slug ]['whatsapp_verify_mode'] ?? 'inherit';
            if ( $mode === 'on' )  { return true; }
            if ( $mode === 'off' ) { return false; }
        }

        if ( $listing && ! empty( $listing->vendor_id ) ) {
            global $wpdb;
            $vendor_mode = $wpdb->get_var( $wpdb->prepare(
                "SELECT whatsapp_verify_mode FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d",
                (int) $listing->vendor_id
            ) );
            if ( $vendor_mode === 'on' )  { return true; }
            if ( $vendor_mode === 'off' ) { return false; }
        }

        // No more specific override — admin's global "on" is the answer.
        return true;
    }

    /**
     * Send a WhatsApp OTP to the given phone. Returns a result array — never throws.
     * Caller (AJAX handler) decides how to surface 'sent'=>false to the user.
     */
    public static function send_otp( string $phone ): array {
        $phone_clean = preg_replace( '/\D/', '', $phone );
        if ( strlen( $phone_clean ) < 10 ) {
            return [ 'sent' => false, 'error' => 'Please enter a valid phone number.' ];
        }

        if ( ! WhatsAppService::is_api_enabled() ) {
            return [ 'sent' => false, 'error' => 'WhatsApp verification is not currently available. Please use email verification instead.' ];
        }

        global $wpdb;
        self::ensure_table();
        $tbl = $wpdb->prefix . 'gs_whatsapp_verify_tokens';

        // Rate limit: max 3 sends per phone per 10 minutes (mirrors OtpService's convention).
        $recent = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$tbl} WHERE phone = %s AND created_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE)",
            $phone_clean
        ) );
        if ( $recent >= 3 ) {
            return [ 'sent' => false, 'error' => 'Too many requests. Please wait a few minutes and try again.' ];
        }

        $otp = str_pad( (string) random_int( 0, 999999 ), self::OTP_LENGTH, '0', STR_PAD_LEFT );
        $wpdb->insert( $tbl, [
            'phone'      => $phone_clean,
            'otp_hash'   => wp_hash_password( $otp ),
            'expires_at' => date( 'Y-m-d H:i:s', strtotime( '+' . self::OTP_TTL_MINUTES . ' minutes' ) ),
            'created_at' => current_time( 'mysql' ),
        ] );

        $platform = Config::get( 'platform_name', 'GoodService' );
        $message  = "Your {$platform} verification code is: {$otp}\n\nValid for " . self::OTP_TTL_MINUTES . " minutes. Do not share this code.";

        $sent = WhatsAppService::send_text( $phone_clean, $message );
        if ( ! $sent ) {
            return [ 'sent' => false, 'error' => 'Could not send WhatsApp message. Please try email verification instead.' ];
        }
        return [ 'sent' => true, 'error' => null ];
    }

    /**
     * Verify a submitted OTP. On success, returns a short-lived signed token the
     * caller can attach to the inquiry submission (mirrors the old, removed
     * phone_otp_token pattern — but this one is OPTIONAL and only consulted when
     * is_enabled() is true, never a hard requirement on every submission).
     */
    public static function verify_otp( string $phone, string $otp ): array {
        global $wpdb;
        self::ensure_table();
        $tbl = $wpdb->prefix . 'gs_whatsapp_verify_tokens';
        $phone_clean = preg_replace( '/\D/', '', $phone );

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$tbl} WHERE phone = %s AND verified = 0 AND expires_at > NOW() ORDER BY id DESC LIMIT 1",
            $phone_clean
        ) );
        if ( ! $row ) {
            return [ 'valid' => false, 'error' => 'Code expired or not found. Please request a new one.' ];
        }
        if ( (int) $row->attempts >= 5 ) {
            $wpdb->delete( $tbl, [ 'id' => $row->id ] );
            return [ 'valid' => false, 'error' => 'Too many incorrect attempts. Please request a new code.' ];
        }
        if ( ! wp_check_password( $otp, $row->otp_hash ) ) {
            $wpdb->update( $tbl, [ 'attempts' => (int) $row->attempts + 1 ], [ 'id' => $row->id ] );
            return [ 'valid' => false, 'error' => 'Incorrect code. Please check and try again.' ];
        }

        $token = bin2hex( random_bytes( 32 ) );
        $wpdb->update( $tbl, [ 'verified' => 1, 'token' => $token ], [ 'id' => $row->id ] );

        return [ 'valid' => true, 'token' => $token, 'error' => null ];
    }

    /** Mark a lead as WhatsApp-verified once the inquiry that used a verified token is created. */
    public static function mark_lead_verified( int $lead_id, string $phone ): void {
        global $wpdb;
        $phone_clean = preg_replace( '/\D/', '', $phone );
        $verified = (bool) $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_whatsapp_verify_tokens
             WHERE phone = %s AND verified = 1 AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)
             ORDER BY id DESC LIMIT 1",
            $phone_clean
        ) );
        if ( $verified ) {
            $wpdb->update( $wpdb->prefix . 'gs_leads', [ 'phone_verified' => 1 ], [ 'id' => $lead_id ] );
        }
    }
}
