<?php
namespace GoodService\Service;

use GoodService\Core\RateLimiter;

/**
 * FraudDetectionService — real feature, Critical priority gap from the
 * enterprise audit.
 *
 * ARCHITECTURAL CONTEXT: deliberately rule-based and fully explainable
 * rather than a black-box ML score, matching the audit's own explicit
 * recommendation — every fired signal is a row in gs_risk_events with
 * its own human-readable reason, so an admin reviewing a flagged
 * account sees exactly why, not just a number. Reuses
 * RateLimiter::resolve_real_ip() (widened from private to public for
 * this reuse) rather than re-implementing IP resolution — that method
 * already correctly guards against X-Forwarded-For spoofing, a subtlety
 * worth not re-deriving.
 *
 * This flags, it never blocks. An automated system that auto-rejects on
 * a rule match will have false positives that lock out legitimate
 * vendors with no recourse — the audit itself calls this out as a real
 * risk. Every signal here creates a reviewable risk_event; nothing here
 * prevents an account from being created or a review from posting.
 */
class FraudDetectionService {

    /**
     * Evaluates a new vendor registration for risk signals. Called
     * AFTER the account is created (never blocks registration itself),
     * so every signal fired is purely informational for the admin risk
     * queue.
     */
    public static function evaluate_signup( int $vendor_id, string $email, string $phone ): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        $ip = RateLimiter::resolve_real_ip( $_SERVER['REMOTE_ADDR'] ?? '' );
        $ip_hash = substr( md5( $ip . ( defined( 'AUTH_SALT' ) ? AUTH_SALT : 'gs' ) ), 0, 16 );

        // Signal 1: velocity — multiple vendor registrations from the
        // same IP in a short window. A legitimate business registers
        // once; several registrations from one connection in one day is
        // the classic pattern for fake-listing farms.
        $recent_from_ip = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$pfx}risk_events
             WHERE signal = 'registration_velocity_marker' AND ip_hash = %s AND created_at > %s",
            $ip_hash, gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS )
        ) );
        // Always record this registration's own IP marker, regardless of
        // whether it trips the threshold — needed so the NEXT
        // registration from this IP can see this one in its own count.
        self::record( 'vendor', $vendor_id, 'registration_velocity_marker', 'low', "Registration from IP hash {$ip_hash}", $ip_hash );
        if ( $recent_from_ip >= 2 ) {
            self::record( 'vendor', $vendor_id, 'registration_velocity', 'high',
                "{$recent_from_ip} other vendor registrations from the same IP in the last 24 hours.", $ip_hash );
        }

        // Signal 2: duplicate phone/email pattern — the same phone or
        // email (or a trivially modified variant, e.g. email+1@,
        // email+2@) already exists on another vendor profile.
        $dupe_phone = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE phone = %s AND id != %d", $phone, $vendor_id
        ) );
        if ( $dupe_phone > 0 ) {
            self::record( 'vendor', $vendor_id, 'duplicate_phone', 'medium',
                "Phone number already used by {$dupe_phone} other vendor profile(s).", $ip_hash );
        }
    }

    /**
     * Evaluates a submitted review for risk signals. Called after the
     * review is saved (matches submitReview()'s existing moderation
     * queue — this adds risk context to that queue, doesn't replace it).
     */
    public static function evaluate_review( int $review_id, int $listing_id, int $rating, string $ip ): void {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        $ip_hash = substr( md5( $ip . ( defined( 'AUTH_SALT' ) ? AUTH_SALT : 'gs' ) ), 0, 16 );

        // Signal: review burst — an unusually high number of 5-star
        // reviews for the same listing in a short window is the classic
        // signature of a purchased-review campaign, not organic
        // customer feedback (which arrives spread out, tied to actual
        // completed bookings over time).
        if ( $rating >= 4 ) {
            $recent_high_reviews = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$pfx}reviews WHERE listing_id = %d AND rating >= 4 AND created_at > %s",
                $listing_id, gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS )
            ) );
            if ( $recent_high_reviews >= 5 ) {
                self::record( 'listing', $listing_id, 'review_burst', 'high',
                    "{$recent_high_reviews} four/five-star reviews for this listing in the last 24 hours.", $ip_hash );
            }
        }

        // Signal: same IP reviewing the same listing more than once —
        // reviews are meant to be one genuine customer's experience;
        // repeat submissions from one connection point at the same
        // person (or the vendor themselves) inflating their own rating.
        $same_ip_count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$pfx}risk_events
             WHERE signal = 'review_ip_marker' AND subject_id = %d AND ip_hash = %s",
            $listing_id, $ip_hash
        ) );
        self::record( 'review', $review_id, 'review_ip_marker', 'low', "Review from IP hash {$ip_hash}", $ip_hash, $listing_id );
        if ( $same_ip_count >= 1 ) {
            self::record( 'listing', $listing_id, 'repeat_reviewer_ip', 'medium',
                "This connection has submitted a review for this listing before.", $ip_hash );
        }
    }

    public static function record( string $subject_type, int $subject_id, string $signal, string $severity, string $details, string $ip_hash = '', ?int $override_subject_id = null ): void {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'gs_risk_events', [
            'subject_type' => $subject_type,
            'subject_id'   => $override_subject_id ?? $subject_id,
            'signal'       => $signal,
            'severity'     => $severity,
            'details'      => $details,
            'ip_hash'      => $ip_hash,
        ] );
    }

    public static function unreviewed_count(): int {
        global $wpdb;
        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}gs_risk_events WHERE reviewed = 0 AND severity != 'low'"
        );
    }

    public static function mark_reviewed( int $event_id, int $admin_id ): void {
        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'gs_risk_events', [
            'reviewed'    => 1,
            'reviewed_by' => $admin_id,
            'reviewed_at' => current_time( 'mysql' ),
        ], [ 'id' => $event_id ] );
    }
}
