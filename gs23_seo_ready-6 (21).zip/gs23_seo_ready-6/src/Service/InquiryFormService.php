<?php
namespace GoodService\Service;

use GoodService\Database\InquiryCategoryData;

/**
 * InquiryFormService — makes the 29 categories in InquiryCategoryData.php
 * (a 1,375-line hardcoded PHP array) editable through the database instead
 * of requiring a code change + deployment for every field tweak.
 *
 * Design: this is NOT a parallel system. get() and get_all() below are drop-in
 * replacements for InquiryCategoryData::get()/get_all() — same return shape
 * (group/name/icon/ctas/fields, each field key/label/type/required/step/
 * options/ph/help/cond/others/min/max), so every existing caller
 * (submitInquiry(), submitBookingFromModule(), inquiry-modules.php's renderer,
 * saveInquiryModules()'s slug validation) can switch to this service with
 * zero changes to their own logic.
 *
 * Backward compatibility (explicit, not assumed): a category is read from
 * gs_form_categories/gs_form_fields ONLY if a row exists for that slug. Any
 * slug with no row falls through to InquiryCategoryData's hardcoded
 * definition, unchanged. Nothing breaks for an un-migrated category — it
 * behaves exactly as it did before this service existed. migrate_all()
 * (below) copies every category into the database; after that runs, every
 * category becomes admin-editable, but the fallback path stays in place
 * forever as a safety net (e.g. if a row is later deleted by mistake).
 */
final class InquiryFormService {

    /** @var array<string,array>|null In-process cache for a single request. */
    private static ?array $cache = null;

    // ─────────────────────────────────────────────────────────────────────────
    // Drop-in replacements for InquiryCategoryData::get() / get_all()
    // ─────────────────────────────────────────────────────────────────────────

    public static function get( string $slug ): ?array {
        return self::get_all()[ $slug ] ?? null;
    }

    public static function get_all(): array {
        if ( self::$cache !== null ) { return self::$cache; }

        global $wpdb;
        $db_categories = [];
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_form_categories'" ) ) {
            $rows = $wpdb->get_results(
                "SELECT * FROM {$wpdb->prefix}gs_form_categories WHERE is_active = 1 ORDER BY sort_order ASC"
            ) ?: [];
            foreach ( $rows as $row ) {
                $db_categories[ $row->slug ] = self::row_to_category( $row );
            }
        }

        // Fallback: every hardcoded category NOT already present from the DB.
        // This is the actual backward-compatibility mechanism — not a comment
        // promising it, a real merge that prefers DB rows and only fills gaps
        // from the hardcoded registry.
        $legacy = InquiryCategoryData::get_all();
        self::$cache = $db_categories + $legacy; // '+' keeps left-hand (DB) entries on key collision

        return self::$cache;
    }

    public static function get_grouped(): array {
        $g = [];
        foreach ( self::get_all() as $slug => $cat ) {
            $g[ $cat['group'] ][] = array_merge( [ 'slug' => $slug ], $cat );
        }
        return $g;
    }

    /**
     * Real fix: same as get_all(), but excludes the '_universal'
     * pseudo-category — for any context showing a human a list of
     * modules to choose from. '_universal' is an internal system row,
     * never meant to be vendor-selectable.
     */
    public static function get_selectable(): array {
        $all = self::get_all();
        unset( $all['_universal'] );
        return $all;
    }

    /** Real fix: same as get_grouped(), but excludes '_universal' — see get_selectable(). */
    public static function get_grouped_selectable(): array {
        $g = [];
        foreach ( self::get_selectable() as $slug => $cat ) {
            $g[ $cat['group'] ][] = array_merge( [ 'slug' => $slug ], $cat );
        }
        return $g;
    }

    /**
     * Drop-in replacement for InquiryCategoryData::universal_fields(). Reads
     * the '_universal' pseudo-category created by migrate_universal_fields()
     * if it exists; falls back to the hardcoded universal_fields() otherwise —
     * same backward-compatibility pattern as get()/get_all() above.
     */
    public static function universal_fields(): array {
        $cat = self::get( '_universal' );
        return $cat['fields'] ?? InquiryCategoryData::universal_fields();
    }

    /**
     * Real feature: per-category override lookup for universal fields.
     * Returns [] when a category has never customized anything — the
     * exact case for every existing form today — so callers that find no
     * override simply treat the field as enabled with its default label,
     * identical to current behavior.
     */
    public static function get_universal_overrides( int $category_id ): array {
        global $wpdb;
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_form_universal_overrides'" ) ) {
            return [];
        }
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_form_universal_overrides WHERE category_id = %d", $category_id
        ) );
        $out = [];
        foreach ( $rows as $r ) { $out[ $r->field_key ] = $r; }
        return $out;
    }

    /**
     * Real feature: the actual foundation of the dynamic-groups
     * architecture — reads the genuinely configurable list of default
     * step categories (Scheduling, Contact, and any future ones an admin
     * adds) from the database, ordered for display. This is what makes
     * "add a new default step category" a data change, not a code
     * change: nothing downstream of this function assumes there are
     * exactly two, or that they're named 'scheduling'/'contact' — those
     * are just the two rows this table happens to be seeded with.
     */
    public static function get_step_categories(): array {
        global $wpdb;
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_form_step_categories'" ) ) {
            return [ [ 'step_key' => 'scheduling', 'label' => 'Scheduling' ], [ 'step_key' => 'contact', 'label' => 'Contact' ] ];
        }
        $rows = $wpdb->get_results(
            "SELECT step_key, label FROM {$wpdb->prefix}gs_form_step_categories WHERE is_active = 1 ORDER BY sort_order ASC, id ASC",
            ARRAY_A
        );
        if ( ! $rows ) {
            return [ [ 'step_key' => 'scheduling', 'label' => 'Scheduling' ], [ 'step_key' => 'contact', 'label' => 'Contact' ] ];
        }
        return $rows;
    }

    /**
     * Real feature: single source of truth for "what fields does this form
     * actually have, and how are they configured" — replaces the two
     * duplicated, step-1-only inline merges in inquiry-modules.php and
     * vendor-site.php. Fields are grouped by ROLE (own_step_1, own_step_2,
     * plus one key per active row in get_step_categories() — today that's
     * scheduling/contact, but a future third default step category shows
     * up here automatically, with zero changes to this function). A
     * category's own fields at any step (not just step 1) are genuinely
     * used, and a category-owned field sharing a universal field's key
     * replaces it outright. Universal fields disabled for this category
     * via the override table are omitted entirely — which also means
     * their whole group can end up with zero fields, and it's the
     * CALLER's job (not this function's) to skip rendering an empty
     * group's step, since doing that here would hardcode a rendering
     * assumption into the data layer.
     *
     * @return array own_step_1, own_step_2, plus one key per active step category
     */
    public static function resolve_fields_for_category( string $slug ): array {
        $step_categories = self::get_step_categories();
        $result = [ 'own_step_1' => [], 'own_step_2' => [] ];
        foreach ( $step_categories as $sc ) { $result[ $sc['step_key'] ] = []; }

        $cat = self::get( $slug );
        if ( ! $cat ) { return $result; }

        $cat_fields   = $cat['fields'] ?? [];
        $cat_by_key   = [];
        foreach ( $cat_fields as $f ) { $cat_by_key[ $f['key'] ] = $f; }

        $category_id  = (int) ( $cat['id'] ?? 0 );
        $overrides    = $category_id ? self::get_universal_overrides( $category_id ) : [];

        // Category-owned fields, EXCEPT ones that share a key with a
        // universal field (handled below so the override table's
        // enable/disable + label settings apply uniformly whether the
        // field is "pure universal" or "category-customized universal").
        // A category's own step is a purely internal split within its
        // OWN content (step 1 vs "more details"), never a default step
        // category — those are identified by the 'group' tag below, not
        // a step number.
        $universal_keys = array_column( self::universal_fields(), 'key' );
        foreach ( $cat_fields as $f ) {
            if ( in_array( $f['key'], $universal_keys, true ) ) { continue; }
            $f['show_label'] = $f['show_label'] ?? true;
            // Real fix: a field explicitly assigned to a real step
            // category (via step_group) goes there directly — this is
            // what lets a genuinely NEW field (not a customized copy of
            // an existing universal one) be added to Scheduling, Contact,
            // or any future step category. Falls back to the numeric
            // own_step_1/own_step_2 split when step_group is empty —
            // today's exact behavior, unaffected for every existing field.
            $explicit_group = $f['step_group'] ?? '';
            if ( $explicit_group !== '' && isset( $result[ $explicit_group ] ) ) {
                $result[ $explicit_group ][] = $f;
                continue;
            }
            $own_step = (int) ( $f['step'] ?? 1 );
            $bucket = $own_step >= 2 ? 'own_step_2' : 'own_step_1';
            $result[ $bucket ][] = $f;
        }

        // Universal fields: category-owned version wins if present
        // (rename/retype/reconfigure), then per-category enable/disable
        // and label overrides apply on top. Grouped by 'group' (a
        // step_key from the registry), never by step number — this is
        // what makes every default step category genuinely relocatable
        // to any visual position depending on how many "own" steps a
        // given form has, and lets a genuinely new group (not just
        // scheduling/contact) hold fields correctly.
        $default_group = $step_categories[0]['step_key'] ?? 'scheduling';
        foreach ( self::universal_fields() as $uf ) {
            $key = $uf['key'];
            $override = $overrides[ $key ] ?? null;
            if ( $override && ! (int) $override->is_enabled ) { continue; }

            $field = $cat_by_key[ $key ] ?? $uf;
            $field['show_label'] = $override ? (bool) $override->show_label : true;
            if ( $override && $override->label_override !== '' ) {
                $field['label'] = $override->label_override;
            }
            $group = $uf['group'] ?? $default_group;
            if ( ! isset( $result[ $group ] ) ) { $group = $default_group; }
            $result[ $group ][] = $field;
        }

        foreach ( $result as $group => $fields ) {
            usort( $fields, fn( $a, $b ) => ( $a['sort_order'] ?? 0 ) <=> ( $b['sort_order'] ?? 0 ) );
            $result[ $group ] = $fields;
        }
        return $result;
    }

    /** Builds the get()/get_all() return shape for one category from its DB rows. */
    private static function row_to_category( object $row ): array {
        global $wpdb;
        $fields = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_form_fields WHERE category_id = %d AND is_active = 1 ORDER BY step ASC, sort_order ASC",
            $row->id
        ) ) ?: [];

        return [
            'id'    => (int) $row->id,
            'group' => $row->category_group,
            'name'  => $row->name,
            'icon'  => $row->icon,
            'ctas'  => json_decode( (string) $row->ctas, true ) ?: [],
            'fields'=> array_map( [ self::class, 'row_to_field' ], $fields ),
        ];
    }

    /** Builds one field array (key/label/type/required/step/... ) from a gs_form_fields row. */
    private static function row_to_field( object $f ): array {
        $field = [
            'key'        => $f->field_key,
            'label'      => $f->label,
            'type'       => $f->field_type,
            'required'   => (bool) $f->is_required,
            'step'       => (int) $f->step,
            'show_label' => isset( $f->show_label ) ? (bool) $f->show_label : true,
        ];
        if ( ! empty( $f->step_group ) ) { $field['step_group'] = $f->step_group; }
        if ( ! empty( $f->universal_group ) ) { $field['group'] = $f->universal_group; }
        if ( $f->placeholder !== '' )       { $field['ph']     = $f->placeholder; }
        if ( $f->help_text !== '' )         { $field['help']   = $f->help_text; }
        if ( $f->options_json )             { $field['options']= json_decode( (string) $f->options_json, true ) ?: []; }
        if ( $f->min_value !== null )       { $field['min']    = (int) $f->min_value; }
        if ( $f->max_value !== null )       { $field['max']    = (int) $f->max_value; }
        if ( $f->show_others )              { $field['others'] = true; }
        if ( $f->cond_field_key !== '' ) {
            $field['cond'] = [ 'field' => $f->cond_field_key, 'value' => $f->cond_value, 'op' => $f->cond_op ?? 'equals' ];
        }
        return $field;
    }

    /**
     * Builds the editor's field shape from a gs_form_fields row — keeps the
     * raw column names (id, field_key, field_type, is_required, is_active,
     * cond_field_key, cond_value, placeholder, help_text, min_value,
     * max_value) since that's what adminSaveFormFields() expects back
     * unchanged, but DECODES options_json into a real 'options' array.
     * Without this, the editor was handing the admin a JSON STRING where it
     * expected an array — every existing select/radio/multi_select field's
     * options textarea rendered empty regardless of how many options the
     * field actually had, even though the data was correctly stored in the
     * database the whole time. This is the actual root cause of "options
     * don't appear for existing fields."
     */
    public static function row_to_editor_field( object $f ): array {
        $field = (array) $f;
        $field['options'] = $f->options_json ? ( json_decode( (string) $f->options_json, true ) ?: [] ) : [];
        // Defensive: guarantee cond_op is always present, even on a site where
        // the schema upgrade adding this column hasn't run yet (e.g. the
        // version-bump that should have triggered it never fired, for
        // whatever reason). Without this, (array)$f simply omits the key
        // entirely when the column doesn't exist — not null, ABSENT — and
        // the editor's JS would see cond_op as undefined for every single
        // field, every time, which looks exactly like "every function shows
        // blank" even though every individual function's own logic is correct.
        if ( ! array_key_exists( 'cond_op', $field ) ) { $field['cond_op'] = 'equals'; }
        return $field;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Migration — copies InquiryCategoryData's hardcoded array into the DB.
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Migrates every category in InquiryCategoryData::_registry() into
     * gs_form_categories/gs_form_fields. Idempotent: a category already
     * present (by slug) is skipped entirely, never overwritten — so running
     * this twice, or running it after an admin has already edited a migrated
     * category, never clobbers their changes. Returns a per-slug result map
     * for the admin UI to show exactly what happened.
     */
    public static function migrate_all(): array {
        global $wpdb;
        $results = [];
        foreach ( InquiryCategoryData::get_all() as $slug => $cat ) {
            $results[ $slug ] = self::migrate_one( $slug, $cat );
        }
        // Universal fields (step 2/3, shared across every category) get their
        // own pseudo-category so they're equally editable, not left hardcoded
        // forever. Slug '_universal' can never collide with a real category
        // slug (InquiryCategoryData's slugs are dash-cased, never underscore-prefixed).
        $results['_universal'] = self::migrate_universal_fields();
        return $results;
    }

    private static function migrate_one( string $slug, array $cat ): string {
        global $wpdb;
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_form_categories WHERE slug = %s", $slug
        ) );
        if ( $existing ) { return 'skipped (already migrated)'; }

        // Ghost-success fix: this method runs in a loop (migrate_all()) — a
        // prior iteration's successful insert leaves a non-zero insert_id
        // sitting there (it's never reset on failure), so checking insert_id
        // alone could not reliably detect THIS iteration's insert failing.
        $ok = $wpdb->insert( $wpdb->prefix . 'gs_form_categories', [
            'slug'           => $slug,
            'category_group' => $cat['group'] ?? '',
            'name'           => $cat['name']  ?? $slug,
            'icon'           => $cat['icon']  ?? '',
            'ctas'           => wp_json_encode( $cat['ctas'] ?? [] ),
            'is_active'      => 1,
            'is_legacy'      => 1, // marks "came from the hardcoded array", for admin UI provenance display
            'created_at'     => current_time( 'mysql' ),
            'updated_at'     => current_time( 'mysql' ),
        ] );
        if ( ! $ok ) { return 'FAILED — ' . $wpdb->last_error; }
        $category_id = (int) $wpdb->insert_id;
        if ( ! $category_id ) { return 'FAILED — could not insert category row'; }

        $sort = 0;
        foreach ( $cat['fields'] ?? [] as $f ) {
            self::insert_field_row( $category_id, $f, $sort++ );
        }
        return 'migrated (' . count( $cat['fields'] ?? [] ) . ' fields)';
    }

    /**
     * Real fix, root-cause repair: backfills the 'universal_group'
     * column for '_universal' field rows that were already written by
     * migrate_universal_fields() BEFORE that function persisted this
     * value. Fixing the migration code alone does not help existing
     * installs — their rows already exist with universal_group=''.
     * Matches each row by field_key against the hardcoded source data
     * (the same InquiryCategoryData::universal_fields() the original
     * migration read from) to recover the correct group. Safe to run
     * repeatedly — only touches rows where universal_group is empty.
     */
    public static function repair_universal_field_groups(): string {
        global $wpdb;
        $category_id = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_form_categories WHERE slug = %s", '_universal'
        ) );
        if ( ! $category_id ) { return 'skipped — no _universal category exists yet'; }

        $group_by_key = [];
        foreach ( InquiryCategoryData::universal_fields() as $f ) {
            $group_by_key[ $f['key'] ] = $f['group'] ?? '';
        }

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, field_key FROM {$wpdb->prefix}gs_form_fields WHERE category_id = %d AND (universal_group = '' OR universal_group IS NULL)",
            $category_id
        ) );

        $fixed = 0;
        foreach ( $rows as $row ) {
            $group = $group_by_key[ $row->field_key ] ?? '';
            if ( $group === '' ) { continue; }
            $wpdb->update(
                $wpdb->prefix . 'gs_form_fields',
                [ 'universal_group' => $group ],
                [ 'id' => $row->id ]
            );
            $fixed++;
        }
        self::$cache = null; // force re-read on next get_all() call
        return "repaired {$fixed} of " . count( $rows ) . " row(s) with empty universal_group";
    }

    private static function migrate_universal_fields(): string {
        global $wpdb;
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_form_categories WHERE slug = %s", '_universal'
        ) );
        if ( $existing ) { return 'skipped (already migrated)'; }

        // Ghost-success fix: same root cause as migrate_category() above —
        // insert_id is not reset on failure, so it alone can't be trusted to
        // detect this insert failing if an earlier insert this request left a
        // stale non-zero value.
        $ok = $wpdb->insert( $wpdb->prefix . 'gs_form_categories', [
            'slug'           => '_universal',
            'category_group' => 'System',
            'name'           => 'Universal Fields (shown on every form)',
            'icon'           => '🌐',
            'ctas'           => wp_json_encode( [] ),
            'is_active'      => 1,
            'is_legacy'      => 1,
            'created_at'     => current_time( 'mysql' ),
            'updated_at'     => current_time( 'mysql' ),
        ] );
        if ( ! $ok ) { return 'FAILED — ' . $wpdb->last_error; }
        $category_id = (int) $wpdb->insert_id;
        if ( ! $category_id ) { return 'FAILED — could not insert universal-fields row'; }

        $sort = 0;
        foreach ( InquiryCategoryData::universal_fields() as $f ) {
            self::insert_field_row( $category_id, $f, $sort++ );
        }
        return 'migrated';
    }

    // Ghost-success fix: previously void, discarding the insert's result
    // entirely. The one caller that needs the new row's id (add_field(), via
    // $wpdb->insert_id right after calling this) had no way to tell a failed
    // insert from a successful one other than trusting insert_id — which is
    // not reset to 0 on failure. Now returns the insert() call's own result
    // so the caller can check it directly.
    private static function insert_field_row( int $category_id, array $f, int $sort ): bool {
        global $wpdb;
        $cond = $f['cond'] ?? null;
        // Legacy InquiryCategoryData.php conditions use 'eq'/'in' as their op
        // value — evaluate_condition()'s default case already interprets
        // these correctly (same equality + comma-list logic as before this
        // feature existed), but normalizing to 'equals' here keeps the
        // stored column consistent with the editor's actual dropdown values,
        // so a migrated legacy condition shows the right operator selected
        // instead of nothing/a raw 'eq' string.
        $raw_op = is_array( $cond ) ? ( $cond['op'] ?? 'equals' ) : 'equals';
        $cond_op = in_array( $raw_op, self::VALID_CONDITION_OPERATORS, true ) ? $raw_op : 'equals';
        $ok = $wpdb->insert( $wpdb->prefix . 'gs_form_fields', [
            'category_id'    => $category_id,
            'field_key'      => $f['key']      ?? '',
            'label'          => $f['label']    ?? '',
            'field_type'     => $f['type']     ?? 'text',
            'is_required'    => ! empty( $f['required'] ) ? 1 : 0,
            'step'           => (int) ( $f['step'] ?? 1 ),
            'step_group'     => sanitize_key( (string) ( $f['step_group'] ?? '' ) ),
            'placeholder'    => $f['ph']        ?? '',
            'help_text'      => $f['help']      ?? '',
            'options_json'   => isset( $f['options'] ) ? wp_json_encode( $f['options'] ) : null,
            'min_value'      => isset( $f['min'] ) ? (int) $f['min'] : null,
            'max_value'      => isset( $f['max'] ) ? (int) $f['max'] : null,
            'show_others'    => ! empty( $f['others'] ) ? 1 : 0,
            'cond_field_key' => is_array( $cond ) ? ( $cond['field'] ?? '' ) : '',
            'cond_op'        => $cond_op,
            'cond_value'     => is_array( $cond ) ? (string) ( $cond['value'] ?? '' ) : '',
            'sort_order'     => $sort,
            'is_active'      => 1,
            'universal_group' => $f['group'] ?? '',
            'created_at'     => current_time( 'mysql' ),
            'updated_at'     => current_time( 'mysql' ),
        ] );
        return (bool) $ok;
    }

    /** Allow-list of field types this system actually knows how to render and validate. */
    public const VALID_FIELD_TYPES = [
        'text', 'textarea', 'select', 'radio', 'multi_select', 'date', 'time',
        'datetime', 'date_range', 'toggle', 'slider', 'number', 'file', 'phone',
        'email', 'url',
    ];

    /** Types whose value is a single scalar string — interchangeable with each other with no data-shape impact. */
    private const SCALAR_TEXT_TYPES = [ 'text', 'textarea', 'phone', 'email', 'url' ];
    /** Types that store a single chosen value from a fixed option list. */
    private const SINGLE_CHOICE_TYPES = [ 'select', 'radio' ];
    /** Types requiring an options list at all. */
    private const OPTIONS_TYPES = [ 'select', 'radio', 'multi_select' ];

    /**
     * Checks whether changing a field from $old_type to $new_type (and/or its
     * options) is safe to save. Returns ['valid'=>bool, 'error'=>?string,
     * 'warning'=>?string]. 'error' blocks the save outright (e.g. switching to
     * an options-type with zero options given). 'warning' doesn't block —
     * the caller (adminSaveFormFields) requires the client to explicitly
     * acknowledge it first, since it flags a REAL but non-fatal concern:
     * - switching to/from multi_select changes whether past AND future
     *   submissions store a single value or an array for this key — any
     *   code or report reading this field's history should know that.
     * - removing an option that a field's CONDITION elsewhere depends on
     *   (cond_value referencing it) means that condition can now never be
     *   satisfied again — not broken, just silently dead.
     */
    public static function validate_type_change( string $old_type, string $new_type, ?string $old_options_json, mixed $new_options ): array {
        if ( ! in_array( $new_type, self::VALID_FIELD_TYPES, true ) ) {
            return [ 'valid' => false, 'error' => "Unknown field type \"{$new_type}\".", 'warning' => null ];
        }

        $warning = null;

        if ( in_array( $new_type, self::OPTIONS_TYPES, true ) ) {
            $resolved_options = $new_options;
            if ( is_string( $resolved_options ) ) {
                $resolved_options = array_filter( array_map( 'trim', explode( "\n", $resolved_options ) ) );
            } elseif ( $resolved_options === null ) {
                // No options sent in this save — fall back to whatever's
                // already stored (the admin didn't touch the options field).
                $resolved_options = $old_options_json ? ( json_decode( $old_options_json, true ) ?: [] ) : [];
            }
            if ( empty( $resolved_options ) ) {
                return [ 'valid' => false, 'error' => ucfirst( $new_type ) . ' fields need at least one option.', 'warning' => null ];
            }
        }

        if ( $old_type !== $new_type ) {
            $old_is_multi = $old_type === 'multi_select';
            $new_is_multi = $new_type === 'multi_select';
            if ( $old_is_multi !== $new_is_multi ) {
                $warning = "Changing from \"{$old_type}\" to \"{$new_type}\" changes whether this field stores one value or a list of values. Past submissions already saved under the old type won't be converted — only new submissions will use the new shape.";
            } elseif ( ! in_array( $old_type, self::SCALAR_TEXT_TYPES, true ) || ! in_array( $new_type, self::SCALAR_TEXT_TYPES, true ) ) {
                if ( ! ( in_array( $old_type, self::SINGLE_CHOICE_TYPES, true ) && in_array( $new_type, self::SINGLE_CHOICE_TYPES, true ) ) ) {
                    $warning = "Changing from \"{$old_type}\" to \"{$new_type}\" may not display correctly for submissions made before this change, since the two types expect differently formatted values.";
                }
            }
        }

        // Removed-option-breaks-a-condition check: only meaningful if options
        // actually changed AND something currently has a cond_value matching
        // a removed option. This is checked by the caller against the live
        // DB (it needs to query other fields' conditions, which this pure
        // function intentionally doesn't have access to) — see
        // adminSaveFormFields() for where that cross-field check happens.

        return [ 'valid' => true, 'error' => null, 'warning' => $warning ];
    }

    /**
     * Permanently removes a field. Distinct from is_active=0 (the existing
     * "deactivate" toggle) — that hides the field while keeping past
     * submissions' stored data readable against a known field definition;
     * this actually deletes the row. Snapshots first (same as every other
     * mutation) so a deletion is recoverable via Version History.
     */
    public static function delete_field( int $field_id, int $admin_id = 0 ): array {
        global $wpdb;
        $field = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}gs_form_fields WHERE id = %d", $field_id ) );
        if ( ! $field ) {
            return [ 'success' => false, 'error' => 'Field not found.' ];
        }
        $category_id = (int) $field->category_id;

        // Block deletion if another field's condition depends on this one —
        // same protection already applied to options edits; deleting the
        // trigger field entirely is the same class of problem, just total
        // instead of partial.
        $dependents = $wpdb->get_col( $wpdb->prepare(
            "SELECT label FROM {$wpdb->prefix}gs_form_fields WHERE category_id = %d AND cond_field_key = %s",
            $category_id, $field->field_key
        ) );
        if ( $dependents ) {
            return [ 'success' => false, 'error' => 'Cannot delete — "' . implode( '", "', $dependents ) . '" depends on this field being present. Remove that condition first.' ];
        }

        self::save_snapshot( $category_id, $admin_id, 'Field "' . $field->field_key . '" deleted' );
        $wpdb->delete( $wpdb->prefix . 'gs_form_fields', [ 'id' => $field_id ] );
        $wpdb->update( $wpdb->prefix . 'gs_form_categories', [ 'updated_at' => current_time( 'mysql' ) ], [ 'id' => $category_id ] );
        self::flush_cache();

        return [ 'success' => true, 'error' => null, 'category_id' => $category_id ];
    }

    /**
     * Clones a field within the same category. Needs a NEW, distinct key
     * (the unique-key rule from add_field() applies equally here) — auto-
     * generates one by appending "_copy", "_copy2", etc. until a free key
     * is found, rather than asking the admin to type one for what's
     * otherwise a one-click action. The clone never carries over a
     * condition pointing at the ORIGINAL field by key — that would be fine
     * (conditions can have multiple dependents), but it's deliberately
     * cleared if the duplicated field IS itself someone else's condition
     * target, since the clone is a distinct field with its own key and
     * nothing should silently start depending on it.
     */
    public static function duplicate_field( int $field_id, int $admin_id = 0 ): array {
        global $wpdb;
        $field = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}gs_form_fields WHERE id = %d", $field_id ) );
        if ( ! $field ) {
            return [ 'success' => false, 'error' => 'Field not found.' ];
        }
        $category_id = (int) $field->category_id;

        $existing_keys = $wpdb->get_col( $wpdb->prepare(
            "SELECT field_key FROM {$wpdb->prefix}gs_form_fields WHERE category_id = %d", $category_id
        ) );
        $base_key = $field->field_key . '_copy';
        $new_key = $base_key;
        $suffix = 2;
        while ( in_array( $new_key, $existing_keys, true ) ) {
            $new_key = $base_key . $suffix;
            $suffix++;
        }

        self::save_snapshot( $category_id, $admin_id, 'Field "' . $field->field_key . '" duplicated' );

        $max_sort = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(MAX(sort_order),0) FROM {$wpdb->prefix}gs_form_fields WHERE category_id = %d", $category_id
        ) );

        // Ghost-success fix: insert_id is not reset on a failed insert, so
        // checking it alone below could not reliably detect this insert
        // failing if an earlier query this request left a stale non-zero
        // value (e.g. the sort_order lookup above runs a SELECT, not an
        // insert, but other call paths into this method can differ).
        $ok = $wpdb->insert( $wpdb->prefix . 'gs_form_fields', [
            'category_id'    => $category_id,
            'field_key'       => $new_key,
            'label'           => $field->label . ' (Copy)',
            'field_type'      => $field->field_type,
            'is_required'     => $field->is_required,
            'step'            => $field->step,
            'placeholder'     => $field->placeholder,
            'help_text'       => $field->help_text,
            'options_json'    => $field->options_json,
            'min_value'       => $field->min_value,
            'max_value'       => $field->max_value,
            'show_others'     => $field->show_others,
            'cond_field_key'  => '', // see docblock — deliberately cleared, not copied
            'cond_op'         => 'equals',
            'cond_value'      => '',
            'sort_order'      => $max_sort + 1,
            'is_active'       => 1,
            'created_at'      => current_time( 'mysql' ),
            'updated_at'      => current_time( 'mysql' ),
        ] );
        $new_field_id = $ok ? (int) $wpdb->insert_id : 0;
        if ( ! $new_field_id ) {
            return [ 'success' => false, 'error' => 'Database error — could not duplicate the field.' ];
        }

        $wpdb->update( $wpdb->prefix . 'gs_form_categories', [ 'updated_at' => current_time( 'mysql' ) ], [ 'id' => $category_id ] );
        self::flush_cache();

        return [ 'success' => true, 'error' => null, 'field_id' => $new_field_id, 'category_id' => $category_id ];
    }

    /**
     * Creates a brand-new category with zero fields — fields are added
     * afterward via the existing add_field() flow, which already has its
     * own real validation. Keeping creation and field-population as two
     * separate steps avoids duplicating field-validation logic into a
     * category-creation form.
     *
     * Returns ['success'=>bool, 'error'=>?string, 'category_id'=>?int].
     */
    public static function add_category( array $c, int $admin_id = 0 ): array {
        global $wpdb;

        $raw_slug = (string) ( $c['slug'] ?? '' );
        $slug = sanitize_key( $raw_slug );
        if ( $slug === '' ) {
            return [ 'success' => false, 'error' => 'Category slug is required (letters, numbers, hyphens, underscores only).' ];
        }
        if ( $slug !== $raw_slug ) {
            return [ 'success' => false, 'error' => "\"{$raw_slug}\" isn't a valid slug — use only lowercase letters, numbers, hyphens, and underscores (e.g. \"pet-grooming\", not \"Pet Grooming!\")." ];
        }
        if ( strlen( $slug ) > 60 ) { // matches gs_form_categories.slug VARCHAR(60)
            return [ 'success' => false, 'error' => 'Slug is too long (max 60 characters).' ];
        }
        if ( $slug === '_universal' ) {
            return [ 'success' => false, 'error' => '"_universal" is reserved for the universal-fields pseudo-category.' ];
        }

        // Uniqueness check against BOTH the database (other migrated/created
        // categories) and the hardcoded legacy array (a category not yet
        // migrated still occupies its slug — creating a new DB category with
        // the same slug would create an ambiguous duplicate the moment that
        // legacy category is later migrated, or worse, immediately collide
        // in get_all()'s merge since DB entries win on key collision there).
        $existing_db = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_form_categories WHERE slug = %s", $slug
        ) );
        if ( $existing_db ) {
            return [ 'success' => false, 'error' => "A category with slug \"{$slug}\" already exists." ];
        }
        if ( array_key_exists( $slug, InquiryCategoryData::get_all() ) ) {
            return [ 'success' => false, 'error' => "\"{$slug}\" is already used by a built-in category. Choose a different slug." ];
        }

        $name = sanitize_text_field( (string) ( $c['name'] ?? '' ) );
        if ( $name === '' ) {
            return [ 'success' => false, 'error' => 'Category name is required.' ];
        }

        $group = sanitize_text_field( (string) ( $c['group'] ?? 'Other' ) );
        $icon  = sanitize_text_field( (string) ( $c['icon'] ?? '🔧' ) );
        // CTAs are entirely optional — the renderer already falls back to
        // "Submit Inquiry" / "Book Now" when empty (see inquiry-modules.php).
        $inquiry_cta = sanitize_text_field( (string) ( $c['inquiry_cta'] ?? '' ) );
        $booking_cta = sanitize_text_field( (string) ( $c['booking_cta'] ?? '' ) );
        $ctas = array_values( array_filter( [ $inquiry_cta, $booking_cta ] ) );

        $max_sort = (int) $wpdb->get_var( "SELECT COALESCE(MAX(sort_order),0) FROM {$wpdb->prefix}gs_form_categories" );

        $ok = $wpdb->insert( $wpdb->prefix . 'gs_form_categories', [
            'slug'           => $slug,
            'category_group' => $group,
            'name'           => $name,
            'icon'           => $icon,
            'ctas'           => wp_json_encode( $ctas ),
            'is_active'      => 1,
            'is_legacy'      => 0, // genuinely new, not migrated from the hardcoded array
            'sort_order'     => $max_sort + 1,
            'created_by'     => $admin_id,
            'created_at'     => current_time( 'mysql' ),
            'updated_at'     => current_time( 'mysql' ),
        ] );
        if ( ! $ok ) {
            return [ 'success' => false, 'error' => 'Database error — could not create the category.' ];
        }

        $category_id = (int) $wpdb->insert_id;
        self::flush_cache();

        return [ 'success' => true, 'error' => null, 'category_id' => $category_id ];
    }

    /**
     * Creates a brand-new field in an existing (already-migrated) category.
     * Validates BEFORE inserting: key format, key uniqueness within this
     * category + the universal fields (a collision would make the submitted
     * value ambiguous — two HTML inputs sharing one POST name, two PHP array
     * entries overwriting each other in $all_submitted), a known field type,
     * and — if a condition is supplied — the same dangling-reference /
     * self-reference / circular-dependency checks the editor's save path uses.
     *
     * Returns ['success'=>bool, 'error'=>?string, 'field_id'=>?int].
     */
    public static function add_field( int $category_id, array $f, int $admin_id = 0 ): array {
        global $wpdb;

        $category = $wpdb->get_row( $wpdb->prepare(
            "SELECT slug FROM {$wpdb->prefix}gs_form_categories WHERE id = %d", $category_id
        ) );
        if ( ! $category ) {
            return [ 'success' => false, 'error' => 'Category not found. (Has it been migrated into the editor yet?)' ];
        }

        $raw_key = (string) ( $f['key'] ?? '' );
        $key = sanitize_key( $raw_key );
        if ( $key === '' ) {
            return [ 'success' => false, 'error' => 'Field key is required (letters, numbers, underscores only).' ];
        }
        if ( $key !== $raw_key ) {
            return [ 'success' => false, 'error' => "\"{$raw_key}\" isn't a valid field key — use only lowercase letters, numbers, and underscores (e.g. \"pet_breed\", not \"Pet Breed!\")." ];
        }
        if ( strlen( $key ) > 80 ) { // matches gs_form_fields.field_key VARCHAR(80)
            return [ 'success' => false, 'error' => 'Field key is too long (max 80 characters).' ];
        }

        $existing_keys = $wpdb->get_col( $wpdb->prepare(
            "SELECT field_key FROM {$wpdb->prefix}gs_form_fields WHERE category_id = %d", $category_id
        ) );
        if ( in_array( $key, $existing_keys, true ) ) {
            return [ 'success' => false, 'error' => "A field with key \"{$key}\" already exists in this category." ];
        }
        // Real fix: previously blocked here entirely. A category-owned
        // field sharing a universal field's key is now the deliberate
        // mechanism for per-form customization of a universal field's
        // type/required/options/placeholder/help/conditional logic —
        // resolve_fields_for_category() prefers this category's version
        // over the universal default whenever the keys match. Blocking
        // it here silently prevented the very feature it exists for.

        $type = (string) ( $f['type'] ?? 'text' );
        if ( ! in_array( $type, self::VALID_FIELD_TYPES, true ) ) {
            return [ 'success' => false, 'error' => "Unknown field type \"{$type}\". Valid types: " . implode( ', ', self::VALID_FIELD_TYPES ) . '.' ];
        }

        $label = sanitize_text_field( (string) ( $f['label'] ?? '' ) );
        if ( $label === '' ) {
            return [ 'success' => false, 'error' => 'Label is required.' ];
        }

        $cond_field_key = sanitize_key( (string) ( $f['cond_field_key'] ?? '' ) );
        $cond_op = in_array( $f['cond_op'] ?? '', self::VALID_CONDITION_OPERATORS, true ) ? $f['cond_op'] : 'equals';
        if ( $cond_field_key !== '' ) {
            $all_keys_after_add = array_merge( $existing_keys, [ $key ] );
            $trigger_map = [];
            foreach ( $wpdb->get_results( $wpdb->prepare(
                "SELECT field_key, cond_field_key FROM {$wpdb->prefix}gs_form_fields WHERE category_id = %d AND cond_field_key != ''", $category_id
            ) ) as $row ) {
                $trigger_map[ $row->field_key ] = $row->cond_field_key;
            }
            $result = self::validate_condition( $key, $cond_field_key, $all_keys_after_add, $trigger_map );
            if ( ! $result['valid'] ) {
                return [ 'success' => false, 'error' => $result['error'] ];
            }
        }

        $max_sort = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(MAX(sort_order),0) FROM {$wpdb->prefix}gs_form_fields WHERE category_id = %d", $category_id
        ) );

        $options = null;
        if ( in_array( $type, [ 'select', 'radio', 'multi_select' ], true ) ) {
            $raw_options = $f['options'] ?? [];
            if ( is_string( $raw_options ) ) {
                $raw_options = array_filter( array_map( 'trim', explode( "\n", $raw_options ) ) );
            }
            $options = array_values( array_map( 'sanitize_text_field', (array) $raw_options ) );
            if ( empty( $options ) ) {
                return [ 'success' => false, 'error' => ucfirst( $type ) . ' fields need at least one option.' ];
            }
        }

        // Snapshot BEFORE inserting the new field — rolling back to this
        // version would restore the category to exactly how it looked right
        // before this field was added (the new field simply won't exist in
        // that snapshot, since it wasn't there yet).
        self::save_snapshot( $category_id, $admin_id, 'Field "' . $key . '" added' );

        $__row_ok = self::insert_field_row( $category_id, [
            'key'      => $key,
            'label'    => $label,
            'type'     => $type,
            'required' => ! empty( $f['required'] ),
            'step'     => max( 1, min( 4, (int) ( $f['step'] ?? 1 ) ) ),
            'step_group' => (string) ( $f['step_group'] ?? '' ),
            'ph'       => sanitize_text_field( (string) ( $f['ph'] ?? '' ) ),
            'help'     => sanitize_text_field( (string) ( $f['help'] ?? '' ) ),
            'options'  => $options,
            'cond'     => $cond_field_key !== '' ? [ 'field' => $cond_field_key, 'value' => sanitize_text_field( (string) ( $f['cond_value'] ?? '' ) ), 'op' => $cond_op ] : null,
        ], $max_sort + 1 );

        // Ghost-success fix: insert_field_row() now reports its own result —
        // check it before trusting insert_id, which is not reset to 0 on a
        // failed insert and could otherwise be a stale id from an earlier
        // successful insert in this request.
        if ( ! $__row_ok ) {
            return [ 'success' => false, 'error' => 'Database error — could not create the field.' ];
        }

        $field_id = (int) $wpdb->insert_id;
        if ( ! $field_id ) {
            return [ 'success' => false, 'error' => 'Database error — could not create the field.' ];
        }

        $wpdb->update( $wpdb->prefix . 'gs_form_categories', [ 'updated_at' => current_time( 'mysql' ) ], [ 'id' => $category_id ] );
        self::flush_cache();

        return [ 'success' => true, 'error' => null, 'field_id' => $field_id ];
    }

    /** Clears the in-process cache — call after any admin edit so the change is visible immediately. */
    public static function flush_cache(): void {
        self::$cache = null;
    }

    /** Allow-list of condition operators, matching the editor's dropdown exactly. */
    public const VALID_CONDITION_OPERATORS = [
        'equals', 'not_equals', 'greater_than', 'less_than',
        'greater_equal', 'less_equal', 'contains', 'not_contains',
        'is_empty', 'is_not_empty',
    ];

    /**
     * Evaluates whether a condition is satisfied, given the trigger field's
     * submitted value and the configured operator/expected-value. This is
     * the SINGLE authority for what each operator means — the client-side
     * evaluator in inquiry-modules.php (_iqEval()) must implement IDENTICAL
     * logic for each operator, since the customer-facing show/hide and the
     * server-side custom_fields-stripping decision have to agree (exactly
     * the bug class found and fixed earlier this session with the
     * comma-list 'equals' case — an operator the two evaluators interpret
     * differently produces a field that shows on the form but gets silently
     * discarded on submit, or vice versa).
     *
     * is_empty/is_not_empty ignore $expected entirely. equals/not_equals
     * support the existing comma-separated "any of these" convention.
     * greater_than/less_than/greater_equal/less_equal cast both sides to
     * float — non-numeric input is treated as 0, since these operators only
     * make sense against number/slider/date fields in practice.
     */
    public static function evaluate_condition( string $operator, string $actual, string $expected ): bool {
        switch ( $operator ) {
            case 'is_empty':     return $actual === '';
            case 'is_not_empty': return $actual !== '';
            case 'not_equals':
                if ( str_contains( $expected, ',' ) ) {
                    return ! in_array( $actual, array_map( 'trim', explode( ',', $expected ) ), true );
                }
                return $actual !== $expected;
            case 'greater_than':  return (float) $actual >  (float) $expected;
            case 'less_than':     return (float) $actual <  (float) $expected;
            case 'greater_equal': return (float) $actual >= (float) $expected;
            case 'less_equal':    return (float) $actual <= (float) $expected;
            case 'contains':      return $expected !== '' && str_contains( $actual, $expected );
            case 'not_contains':  return $expected === '' || ! str_contains( $actual, $expected );
            case 'equals':
            default:
                // Default case intentionally falls through to 'equals' — a
                // missing/unrecognized operator (e.g. a row saved before
                // cond_op existed, where the column defaults to 'equals'
                // anyway) behaves exactly like the original equality-only
                // evaluator, so every condition saved before this feature
                // existed keeps working identically, unchanged.
                if ( $expected === '1' && $actual !== '' && $actual !== '0' ) { return true; } // legacy toggle-truthy shorthand, preserved
                if ( str_contains( $expected, ',' ) ) {
                    return in_array( $actual, array_map( 'trim', explode( ',', $expected ) ), true );
                }
                return $actual === $expected;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Conditional-logic safety validation
    // ─────────────────────────────────────────────────────────────────────────
    // Built BEFORE any UI exposes condition editing, deliberately — see the two
    // real bugs found by validate_all_existing() below (resort-booking and
    // bakery-order both had conditions referencing a field key that was never
    // defined, silently making the dependent field permanently hidden). An
    // editor without these checks could recreate that exact failure mode for
    // any of the 29 categories, at the click of a save button.

    /**
     * Checks whether a proposed condition is safe to save for a given field
     * within a category. Returns ['valid'=>bool, 'error'=>?string].
     *
     * @param string $field_key      The field this condition is being set ON.
     * @param string $cond_field_key The trigger field the condition depends on.
     * @param array  $all_field_keys Every field key that exists in this category
     *                               (the field being saved should already be
     *                               included if it's pre-existing, so a no-op
     *                               edit doesn't fail self-reference checks
     *                               incorrectly — see check 2 below).
     * @param array  $trigger_map    field_key => cond_field_key for every OTHER
     *                               field already saved in this category
     *                               (used for the cycle check).
     */
    public static function validate_condition( string $field_key, string $cond_field_key, array $all_field_keys, array $trigger_map ): array {
        if ( $cond_field_key === '' ) {
            return [ 'valid' => true, 'error' => null ]; // no condition — always valid
        }

        // Check 1 — the trigger field must actually exist: either as a field
        // in this same category, or as one of the universal fields merged in
        // at render/submit time (confirmed safe: AjaxController::submitInquiry()
        // merges $all_submitted from both sources before evaluating any cond).
        $universal_keys = array_column( InquiryCategoryData::universal_fields(), 'key' );
        if ( ! in_array( $cond_field_key, $all_field_keys, true ) && ! in_array( $cond_field_key, $universal_keys, true ) ) {
            return [ 'valid' => false, 'error' => "The trigger field \"{$cond_field_key}\" doesn't exist in this category or the universal fields. The condition would never be satisfiable — this field would stay permanently hidden, exactly like the resort-booking/bakery-order bugs found and fixed this session." ];
        }

        // Check 2 — a field cannot depend on itself.
        if ( $cond_field_key === $field_key ) {
            return [ 'valid' => false, 'error' => 'A field cannot be conditional on itself.' ];
        }

        // Check 3 — no circular dependency. Walk the trigger chain starting
        // from the proposed new trigger; if we ever reach back to $field_key,
        // saving this would create a loop (A shows only if B is set, B shows
        // only if A is set — neither could ever show).
        $visited = [ $field_key ];
        $current = $cond_field_key;
        $hops = 0;
        while ( isset( $trigger_map[ $current ] ) && $trigger_map[ $current ] !== '' ) {
            $hops++;
            if ( $hops > 50 ) { break; } // defensive — should be unreachable given the checks below, but never loop forever
            if ( in_array( $current, $visited, true ) ) {
                // Already a cycle further down the chain (shouldn't happen if every
                // prior save was validated, but checked defensively) — not THIS
                // field's fault, so don't block; just stop walking.
                break;
            }
            $visited[] = $current;
            if ( $trigger_map[ $current ] === $field_key ) {
                return [ 'valid' => false, 'error' => "This would create a circular dependency: \"{$field_key}\" → ... → \"{$current}\" → \"{$field_key}\". Neither field could ever display." ];
            }
            $current = $trigger_map[ $current ];
        }

        return [ 'valid' => true, 'error' => null ];
    }

    /**
     * Audits every category (DB-backed and hardcoded-fallback alike) for
     * dangling condition references and circular dependencies. Used by the
     * admin "Run Safety Check" button and can be called from a test/CLI
     * context too. Returns a flat list of issues found, empty if clean.
     */
    public static function validate_all_existing(): array {
        $issues = [];
        $universal_keys = array_column( InquiryCategoryData::universal_fields(), 'key' );

        foreach ( self::get_all() as $slug => $cat ) {
            $field_keys  = array_column( $cat['fields'] ?? [], 'key' );
            $trigger_map = [];
            foreach ( $cat['fields'] ?? [] as $f ) {
                if ( ! empty( $f['cond']['field'] ) ) {
                    $trigger_map[ $f['key'] ] = $f['cond']['field'];
                }
            }
            foreach ( $trigger_map as $field_key => $cond_field_key ) {
                if ( ! in_array( $cond_field_key, $field_keys, true ) && ! in_array( $cond_field_key, $universal_keys, true ) ) {
                    $issues[] = [
                        'category' => $slug, 'field' => $field_key, 'type' => 'dangling_reference',
                        'detail'   => "\"{$field_key}\" depends on \"{$cond_field_key}\", which doesn't exist in this category or universal fields.",
                    ];
                    continue;
                }
                $result = self::validate_condition( $field_key, $cond_field_key, $field_keys, $trigger_map );
                if ( ! $result['valid'] && str_contains( $result['error'] ?? '', 'circular' ) ) {
                    $issues[] = [ 'category' => $slug, 'field' => $field_key, 'type' => 'circular_dependency', 'detail' => $result['error'] ];
                }
            }
        }
        return $issues;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Version history & rollback
    // ─────────────────────────────────────────────────────────────────────────
    // A "version" snapshots the COMPLETE field set for a category at the
    // moment of a save — not individual field-level diffs. Rolling back
    // replaces the category's current gs_form_fields rows with the
    // snapshot's rows in one atomic operation. This is deliberately simpler
    // than per-field diffing: if a save both added a field and edited three
    // others, "undo just the edits" is ambiguous, but "go back to exactly
    // how the whole category looked before this save" is not.

    private const MAX_VERSIONS_PER_CATEGORY = 25;

    /**
     * Snapshots a category's CURRENT field rows into gs_form_field_versions.
     * Call this BEFORE applying a save's changes (so the snapshot is "what it
     * looked like right before this edit", which is what an admin actually
     * wants to roll back TO). Trims old versions beyond
     * MAX_VERSIONS_PER_CATEGORY so this table can't grow unbounded.
     */
    public static function save_snapshot( int $category_id, int $admin_id, string $change_summary = '' ): void {
        global $wpdb;
        $fields = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_form_fields WHERE category_id = %d ORDER BY step ASC, sort_order ASC",
            $category_id
        ) );
        if ( ! $fields ) { return; } // nothing to snapshot yet (e.g. first field ever added)

        $wpdb->insert( $wpdb->prefix . 'gs_form_field_versions', [
            'category_id'    => $category_id,
            'snapshot_json'  => wp_json_encode( $fields ),
            'field_count'    => count( $fields ),
            'change_summary' => sanitize_text_field( $change_summary ),
            'created_by'     => $admin_id,
            'created_at'     => current_time( 'mysql' ),
        ] );

        // Trim old versions beyond the cap, oldest first.
        $excess_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_form_field_versions
             WHERE category_id = %d ORDER BY created_at DESC LIMIT 1000 OFFSET %d",
            $category_id, self::MAX_VERSIONS_PER_CATEGORY
        ) );
        if ( $excess_ids ) {
            $wpdb->query(
                "DELETE FROM {$wpdb->prefix}gs_form_field_versions WHERE id IN (" . implode( ',', array_map( 'intval', $excess_ids ) ) . ')'
            );
        }
    }

    /** Lists every saved version for a category, newest first. */
    public static function get_versions( int $category_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT v.id, v.field_count, v.change_summary, v.created_at, u.display_name AS created_by_name
             FROM {$wpdb->prefix}gs_form_field_versions v
             LEFT JOIN {$wpdb->prefix}users u ON u.ID = v.created_by
             WHERE v.category_id = %d ORDER BY v.created_at DESC",
            $category_id
        ) ) ?: [];
    }

    /**
     * Restores a category's fields to exactly what they were in a given
     * version snapshot. Snapshots the CURRENT state first (so rolling back
     * is itself undoable — rollback creates a new version, it doesn't erase
     * history), then deletes the current rows and re-inserts the snapshot's
     * rows with their original ids preserved (so any condition referencing
     * a field by key still resolves correctly, and the rows aren't
     * orphaned from whatever submissions exist).
     */
    public static function rollback_to_version( int $version_id, int $admin_id ): array {
        global $wpdb;
        $version = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_form_field_versions WHERE id = %d", $version_id
        ) );
        if ( ! $version ) {
            return [ 'success' => false, 'error' => 'Version not found.' ];
        }
        $category_id = (int) $version->category_id;
        $snapshot = json_decode( (string) $version->snapshot_json, true );
        if ( ! is_array( $snapshot ) ) {
            return [ 'success' => false, 'error' => 'This version\'s saved data is corrupted and cannot be restored.' ];
        }

        // Snapshot the CURRENT state before overwriting it, so this rollback
        // itself can be undone — never a one-way operation.
        self::save_snapshot( $category_id, $admin_id, 'Auto-saved before rollback to version #' . $version_id );

        $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}gs_form_fields WHERE category_id = %d", $category_id ) );

        foreach ( $snapshot as $row ) {
            $row = (array) $row;
            unset( $row['updated_at'] ); // let the column default refresh it
            $row['updated_at'] = current_time( 'mysql' );
            // Preserve the original 'id' so it stays a stable identifier
            // (WordPress's $wpdb->insert ignores an 'id' key matching the
            // AUTO_INCREMENT primary key only if we pass it explicitly with
            // a format — simplest correct approach: direct INSERT with id).
            $wpdb->query( $wpdb->prepare(
                "INSERT INTO {$wpdb->prefix}gs_form_fields
                 (id, category_id, field_key, label, field_type, is_required, step, placeholder, help_text,
                  options_json, min_value, max_value, show_others, cond_field_key, cond_value, sort_order, is_active, created_at, updated_at)
                 VALUES (%d,%d,%s,%s,%s,%d,%d,%s,%s,%s,%s,%s,%d,%s,%s,%d,%d,%s,%s)",
                $row['id'], $category_id, $row['field_key'], $row['label'], $row['field_type'],
                (int) $row['is_required'], (int) $row['step'], $row['placeholder'], $row['help_text'],
                $row['options_json'], $row['min_value'], $row['max_value'], (int) $row['show_others'],
                $row['cond_field_key'], $row['cond_value'], (int) $row['sort_order'], (int) $row['is_active'],
                $row['created_at'], $row['updated_at']
            ) );
        }

        $wpdb->update( $wpdb->prefix . 'gs_form_categories', [ 'updated_at' => current_time( 'mysql' ) ], [ 'id' => $category_id ] );
        self::flush_cache();

        return [ 'success' => true, 'error' => null, 'category_id' => $category_id, 'restored_count' => count( $snapshot ) ];
    }
}
