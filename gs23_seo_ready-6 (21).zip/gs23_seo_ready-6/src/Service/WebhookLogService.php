<?php
namespace GoodService\Service;

/**
 * WebhookLogService — persisted webhook dead-letter queue.
 *
 * FIXED — audit gap "webhook dead-letter queue": every inbound webhook
 * (Razorpay, Stripe, WhatsApp, partner booking-status) was previously only
 * ever recorded via gs_write_log() to a plain text file. A rejected
 * signature, a processing exception, or a partial DB failure left no
 * queryable, admin-visible record and no way to retry a failed event short
 * of the sender's own webhook retry policy (which every major provider
 * eventually abandons after a bounded number of attempts). This class is
 * the single write/read path for the gs_webhook_log table so every webhook
 * handler in RestApiController logs consistently, and the admin "Webhooks"
 * screen (see AjaxController::retryWebhook()) has one place to reprocess a
 * failed event from its stored raw payload.
 */
final class WebhookLogService {

    /**
     * Record the outcome of one inbound webhook call. Always called exactly
     * once per delivery attempt — signature rejections included, so a spike
     * of 'rejected' rows is itself a visible security signal an admin can
     * act on (wrong/rotated secret, or someone probing the endpoint).
     */
    public static function log( string $source, string $event_type, string $raw_payload, string $status, string $error_message = '', int $http_status = 200 ): int {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'gs_webhook_log', [
            'source'        => sanitize_key( $source ),
            'event_type'    => sanitize_text_field( $event_type ),
            'payload'       => $raw_payload,
            'status'        => in_array( $status, [ 'processed', 'failed', 'rejected' ], true ) ? $status : 'failed',
            'error_message' => $error_message,
            'http_status'   => $http_status,
            'attempts'      => 1,
            'created_at'    => current_time( 'mysql' ),
            'processed_at'  => $status === 'processed' ? current_time( 'mysql' ) : null,
        ] );
        return (int) $wpdb->insert_id;
    }

    /** Mark a previously-logged row as processed after a successful retry. */
    public static function mark_retried_success( int $id ): void {
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->prefix}gs_webhook_log
             SET status='processed', error_message='', attempts=attempts+1, processed_at=%s
             WHERE id=%d",
            current_time( 'mysql' ), $id
        ) );
    }

    /** Record another failed retry attempt without losing the original error context. */
    public static function mark_retried_failure( int $id, string $error_message ): void {
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->prefix}gs_webhook_log
             SET status='failed', error_message=%s, attempts=attempts+1
             WHERE id=%d",
            $error_message, $id
        ) );
    }

    /** Fetch one logged event by id (used by the retry action). */
    public static function get( int $id ): ?\stdClass {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_webhook_log WHERE id=%d", $id
        ) );
    }

    /** Count of currently-failed events, for the admin nav badge. */
    public static function failed_count(): int {
        global $wpdb;
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_webhook_log'" ) ) { return 0; }
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}gs_webhook_log WHERE status='failed'" );
    }
}
