<?php
namespace GoodService\Service;

/**
 * SchemaGenerator — emits schema.org JSON-LD structured data for listing
 * detail pages.
 *
 * ARCHITECTURAL CONTEXT (Phase 1-4 discovery, documented here so the next
 * engineer doesn't have to re-derive it):
 *
 * This is a purely ADDITIVE service. It does not touch, duplicate, or
 * replace the existing meta-tag SEO system in Router.php (seo_title
 * pixel-width trimming, hex-colour guards, og:image dimension detection,
 * Config-driven title templates) — that system is mature, already
 * correctly handles real edge cases found in production, and is left
 * completely unchanged. This class only adds the one genuinely missing
 * piece: machine-readable JSON-LD alongside the meta tags that already
 * exist.
 *
 * All core fields (name, address, geo, phone, price range, aggregate
 * rating) are read directly off the already-fully-populated $listing
 * object the Router assembles for the page — zero additional queries.
 * The only new query this class runs is a single, indexed (idx_listing),
 * LIMIT-5 fetch of approved reviews, used to embed a representative
 * sample per Google's actual guidance (structured data does not require
 * every review to be embedded, only an accurate, non-misleading sample).
 *
 * VALIDATION RULES ENFORCED (each corresponds to a real Rich-Results-Test
 * failure mode if omitted):
 * - aggregateRating is never emitted when review_count is 0 — schema.org
 *   and Google both reject/penalise an aggregate rating claim with no
 *   underlying reviews.
 * - geo (GeoCoordinates) is only emitted when both lat AND lng are
 *   non-null — a schema with one but not the other is invalid.
 * - priceRange is only emitted when at least price_min is set — an
 *   empty priceRange string is worse than omitting the field.
 * - Every string value is passed through wp_json_encode's native
 *   escaping (JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE, then
 *   re-escaped for safe inline <script> embedding) — never
 *   string-concatenated into the JSON, which is how JSON-LD
 *   implementations typically break on a name/description containing a
 *   quote character.
 */
class SchemaGenerator {

    /**
     * Builds and returns the complete <script type="application/ld+json">
     * block for a listing detail page. Returns an empty string if the
     * listing lacks the minimum fields required for a valid schema (a
     * name), so callers can safely echo the result unconditionally.
     */
    public static function render_listing_schema( object $listing ): string {
        if ( empty( $listing->title ) ) {
            return '';
        }

        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $schema = [
            '@context' => 'https://schema.org',
            // LocalBusiness when a physical address exists (the common
            // case for this platform's vendor categories); falls back to
            // the more generic Service type when a vendor has chosen not
            // to disclose a street address, since LocalBusiness without
            // an address is itself a validation warning in Rich Results.
            '@type'    => ! empty( $listing->address ) ? 'LocalBusiness' : 'Service',
            'name'     => wp_strip_all_tags( $listing->title ),
        ];

        if ( ! empty( $listing->short_desc ) ) {
            $schema['description'] = wp_strip_all_tags( $listing->short_desc );
        } elseif ( ! empty( $listing->seo_desc ) ) {
            $schema['description'] = wp_strip_all_tags( $listing->seo_desc );
        }

        $image = $listing->banner_url ?: ( $listing->og_image ?: ( $listing->logo_url ?: '' ) );
        if ( $image ) {
            $schema['image'] = $image;
        }

        if ( ! empty( $listing->slug ) ) {
            $schema['url'] = home_url( '/' . $listing->slug . '/' );
        }

        if ( ! empty( $listing->phone ) ) {
            $schema['telephone'] = $listing->phone;
        }

        // sameAs — real feature: the vendor's own social profile links,
        // already stored on this same $listing row (raw `social_links`
        // JSON column, decoded here the same way Router.php already
        // decodes it for $vendor->social_links) and already rendered as
        // visible social icons on this page's contact/footer section.
        // Only well-formed http(s) URLs are included — schema.org's
        // sameAs is explicitly for links identifying the same real-world
        // entity elsewhere, not arbitrary text a vendor might have typed.
        $_social = $listing->social_links ?? null;
        if ( is_string( $_social ) ) { $_social = json_decode( $_social, true ) ?: []; }
        if ( is_array( $_social ) ) {
            $_same_as = [];
            foreach ( $_social as $_surl ) {
                $_surl = is_string( $_surl ) ? trim( $_surl ) : '';
                if ( $_surl !== '' && filter_var( $_surl, FILTER_VALIDATE_URL ) && preg_match( '#^https?://#i', $_surl ) ) {
                    $_same_as[] = $_surl;
                }
            }
            $_same_as = array_values( array_unique( $_same_as ) );
            if ( $_same_as ) { $schema['sameAs'] = $_same_as; }
        }

        // Real feature — entity-relationship gap closed without any new
        // page/route/URL: this listing's category (cat_name, already
        // joined onto $listing by the Router's query — verified, not a
        // new query) is expressed as the schema.org `category` string
        // field. Lets an agent/crawler resolve "Vendor A belongs to
        // Category A" directly from the existing vendor page's JSON-LD.
        if ( ! empty( $listing->subcat_name ) ) {
            // Subcategory is the more specific, real classification when the
            // vendor has one set (subcat_name comes from the same joined
            // `sc.name` the Router already selects) — falls back to the
            // top-level category otherwise.
            $schema['category'] = wp_strip_all_tags( $listing->subcat_name );
        } elseif ( ! empty( $listing->cat_name ) ) {
            $schema['category'] = wp_strip_all_tags( $listing->cat_name );
        }

        // Vendor-defined per-service category groupings — real feature:
        // these are the SAME headings ("Plumbing", "Electrical", …) the
        // vendor page already renders visibly above groups of services
        // (templates/pages/vendor-site.php, .vs-svc-cat-heading / the
        // $_svc_cats_active grouping loop). Building an id → name map
        // here lets each individual Service below carry its own, more
        // specific category instead of only the platform-level one.
        $_svc_cat_map = [];
        $_svc_cats_raw = $listing->service_categories ?? null;
        if ( is_string( $_svc_cats_raw ) ) { $_svc_cats_raw = json_decode( $_svc_cats_raw, true ) ?: []; }
        if ( is_array( $_svc_cats_raw ) ) {
            foreach ( $_svc_cats_raw as $_sc ) {
                if ( isset( $_sc['id'], $_sc['name'] ) && $_sc['name'] !== '' ) {
                    $_svc_cat_map[ $_sc['id'] ] = wp_strip_all_tags( $_sc['name'] );
                }
            }
        }

        // areaServed — real feature, same principle: uses the listing's
        // own already-populated city plus its existing service_cities
        // JSON (the same field the vendor page's own "cities we serve"
        // content and the gs_listing_cities table are built from — see
        // ListingRepository::sync_listing_cities()), never a new query
        // or a new page. Dedupes and skips empty values; emits a single
        // Place for one city and a Place[] only when there's genuinely
        // more than one, so the schema never overstates coverage the
        // listing doesn't actually claim.
        $_svc_cities = $listing->service_cities ?? null;
        if ( is_string( $_svc_cities ) ) { $_svc_cities = json_decode( $_svc_cities, true ) ?: []; }
        $_area_cities = [];
        if ( ! empty( $listing->city ) ) { $_area_cities[] = (string) $listing->city; }
        if ( is_array( $_svc_cities ) ) {
            foreach ( $_svc_cities as $_c ) {
                $_c = is_array( $_c ) ? ( $_c['city'] ?? $_c['name'] ?? '' ) : (string) $_c;
                if ( $_c !== '' ) { $_area_cities[] = $_c; }
            }
        }
        $_area_cities = array_values( array_unique( array_filter( array_map( 'trim', $_area_cities ) ) ) );
        if ( count( $_area_cities ) === 1 ) {
            $schema['areaServed'] = [ '@type' => 'Place', 'name' => $_area_cities[0] ];
        } elseif ( count( $_area_cities ) > 1 ) {
            $schema['areaServed'] = array_map( fn( $c ) => [ '@type' => 'Place', 'name' => $c ], $_area_cities );
        }

        // makesOffer — real feature: expresses "Vendor A offers Service
        // X, Y, Z" directly in the existing vendor page's structured
        // data, using the SAME services_data the visible Services
        // section on this single-page microsite already renders
        // (templates/pages/vendor-site.php, #vs-sec-services) — no new
        // service pages/URLs are created; this only describes, in
        // machine-readable form, content already visible on this page.
        // Capped at 30 to keep the block bounded on listings with very
        // long service lists; every visible service is still on the page,
        // this only limits how many are individually itemized in schema.
        $_services = $listing->services_data ?? null;
        if ( is_string( $_services ) ) { $_services = json_decode( $_services, true ) ?: []; }
        if ( is_array( $_services ) && ! empty( $_services ) ) {
            $_offers = [];
            foreach ( array_slice( $_services, 0, 30 ) as $_s ) {
                if ( empty( $_s['name'] ) ) { continue; } // validation rule: an unnamed entry is not a real offer
                $_item = [ '@type' => 'Service', 'name' => wp_strip_all_tags( $_s['name'] ) ];
                if ( ! empty( $_s['description'] ) ) {
                    $_item['description'] = wp_strip_all_tags( $_s['description'] );
                }
                // Prefer this specific service's own vendor-assigned category
                // (real, visible grouping) over the listing-level category —
                // falls back to the listing-level one when the service has
                // no category_id or it doesn't resolve (deleted category).
                $_svc_cat_id = $_s['category_id'] ?? null;
                if ( $_svc_cat_id !== null && isset( $_svc_cat_map[ $_svc_cat_id ] ) ) {
                    $_item['category'] = $_svc_cat_map[ $_svc_cat_id ];
                } elseif ( ! empty( $schema['category'] ) ) {
                    $_item['category'] = $schema['category'];
                }
                $_offer = [ '@type' => 'Offer', 'itemOffered' => $_item ];
                if ( ! empty( $_s['price'] ) && is_numeric( $_s['price'] ) ) {
                    // Only a genuinely numeric price becomes a schema price —
                    // vendors also enter free-text like "Starting ₹500" here,
                    // which is not a valid schema.org Offer.price value and
                    // would be misleading structured data if forced in.
                    $_offer['price']         = (float) $_s['price'];
                    $_offer['priceCurrency'] = 'INR';
                }
                $_offers[] = $_offer;
            }
            if ( $_offers ) {
                $schema['makesOffer'] = $_offers;
            }
        }

        if ( ! empty( $listing->address ) || ! empty( $listing->city ) ) {
            $addr = [ '@type' => 'PostalAddress' ];
            if ( ! empty( $listing->address ) ) { $addr['streetAddress'] = wp_strip_all_tags( $listing->address ); }
            if ( ! empty( $listing->city ) )    { $addr['addressLocality'] = $listing->city; }
            if ( ! empty( $listing->state ) )   { $addr['addressRegion']  = $listing->state; }
            if ( ! empty( $listing->pincode ) ) { $addr['postalCode']     = $listing->pincode; }
            // No country-code config key exists anywhere in this codebase
            // (verified by search) — inventing one here would be scope
            // creep beyond this gap. This platform is confirmed
            // India-focused elsewhere (currency_symbol defaults to ₹,
            // OtpService defaults to country code 91), so a direct
            // default matches the platform's actual current scope
            // without introducing new configuration surface.
            $addr['addressCountry'] = 'IN';
            $schema['address'] = $addr;
        }

        // Validation rule: only emit geo when BOTH coordinates are
        // present — one without the other is an invalid GeoCoordinates
        // object per schema.org, not a partially-useful one.
        if ( ! empty( $listing->lat ) && ! empty( $listing->lng ) ) {
            $schema['geo'] = [
                '@type'     => 'GeoCoordinates',
                'latitude'  => (float) $listing->lat,
                'longitude' => (float) $listing->lng,
            ];
        }

        // Validation rule: priceRange needs at least a floor value to be
        // meaningful; an empty/zero priceRange is a Rich Results warning.
        if ( ! empty( $listing->price_min ) ) {
            $currency_symbol = \GoodService\Core\Config::get( 'currency_symbol', '₹' );
            $max = ! empty( $listing->price_max ) ? $listing->price_max : $listing->price_min;
            $schema['priceRange'] = $currency_symbol . number_format( (float) $listing->price_min, 0 ) . ' - ' . $currency_symbol . number_format( (float) $max, 0 );
        }

        // Validation rule: aggregateRating is never emitted with zero
        // reviews — a claimed rating with no reviews backing it is
        // exactly the kind of structured-data misrepresentation Google's
        // guidelines explicitly warn against and can trigger a manual
        // action, not just a warning.
        if ( ! empty( $listing->review_count ) && (int) $listing->review_count > 0 && ! empty( $listing->avg_rating ) ) {
            $schema['aggregateRating'] = [
                '@type'       => 'AggregateRating',
                'ratingValue' => (float) $listing->avg_rating,
                'reviewCount' => (int) $listing->review_count,
                'bestRating'  => 5,
                'worstRating' => 1,
            ];

            // Single, cheap, indexed (idx_listing) query — a representative
            // sample of 5 approved reviews, not a duplicate of any full
            // review-listing query the page body runs separately.
            $sample_reviews = $wpdb->get_results( $wpdb->prepare(
                "SELECT reviewer_name, rating, review_text FROM {$pfx}reviews
                 WHERE listing_id = %d AND status = 'approved' AND review_text != ''
                 ORDER BY helpful_count DESC, id DESC LIMIT 5",
                (int) $listing->id
            ) );
            if ( $sample_reviews ) {
                $schema['review'] = array_map( function( $r ) {
                    return [
                        '@type'        => 'Review',
                        'reviewRating' => [
                            '@type'       => 'Rating',
                            'ratingValue' => (int) $r->rating,
                            'bestRating'  => 5,
                            'worstRating' => 1,
                        ],
                        'author' => [
                            '@type' => 'Person',
                            'name'  => $r->reviewer_name ?: 'Verified Customer',
                        ],
                        'reviewBody' => wp_strip_all_tags( mb_strimwidth( $r->review_text, 0, 500, '…' ) ),
                    ];
                }, $sample_reviews );
            }
        }

        // opening_hours shape (confirmed against the vendor form, not
        // assumed): { "<day-key>": { "open": "HH:MM", "close": "HH:MM",
        // "closed": "1"|"" }, ... }. Only emitted for days that are
        // explicitly open with both times set — a day with a missing
        // open/close time produces an invalid openingHoursSpecification
        // entry rather than a silently-wrong one.
        $hours = $listing->opening_hours ?? null;
        if ( is_string( $hours ) ) { $hours = json_decode( $hours, true ) ?: []; }
        if ( is_array( $hours ) && ! empty( $hours ) ) {
            $day_map = [
                'mon' => 'Monday', 'tue' => 'Tuesday', 'wed' => 'Wednesday', 'thu' => 'Thursday',
                'fri' => 'Friday', 'sat' => 'Saturday', 'sun' => 'Sunday',
            ];
            $spec = [];
            foreach ( $hours as $day_key => $day ) {
                if ( ! empty( $day['closed'] ) ) { continue; }
                if ( empty( $day['open'] ) || empty( $day['close'] ) ) { continue; } // validation rule: incomplete entries are omitted, not guessed at
                $day_name = $day_map[ strtolower( (string) $day_key ) ] ?? null;
                if ( ! $day_name ) { continue; }
                $spec[] = [
                    '@type'     => 'OpeningHoursSpecification',
                    'dayOfWeek' => 'https://schema.org/' . $day_name,
                    'opens'     => $day['open'],
                    'closes'    => $day['close'],
                ];
            }
            if ( $spec ) {
                $schema['openingHoursSpecification'] = $spec;
            }
        }

        $json = wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        if ( $json === false ) { return ''; } // validation rule: never emit malformed JSON on encode failure

        // </script> inside a JSON string value would prematurely close the
        // tag — the standard, minimal-footprint escape for this exact case.
        $json = str_replace( '</script>', '<\/script>', $json );

        return '<script type="application/ld+json">' . $json . '</script>';
    }

    /**
     * FAQPage structured data — real feature, closing a confirmed gap:
     * this codebase's own SEO auditor already documents FAQ content as
     * "directly eligible for Google's FAQ rich result schema," but no
     * code anywhere actually generated it (verified by grep before
     * writing this). Emitted as its own separate JSON-LD block, per
     * Google's documented pattern for FAQPage, rather than nested
     * inside the main LocalBusiness/Service schema.
     */
    public static function render_faq_schema( object $listing ): string {
        $faqs = $listing->faq_data ?? null;
        if ( is_string( $faqs ) ) { $faqs = json_decode( $faqs, true ) ?: []; }
        if ( ! is_array( $faqs ) || empty( $faqs ) ) { return ''; }

        $entities = [];
        foreach ( $faqs as $f ) {
            $q = trim( (string) ( $f['question'] ?? '' ) );
            $a = trim( wp_strip_all_tags( (string) ( $f['answer'] ?? '' ) ) );
            if ( $q === '' || $a === '' ) { continue; } // validation rule: an incomplete Q&A pair is omitted, not guessed at
            $entities[] = [
                '@type'          => 'Question',
                'name'           => $q,
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text'  => $a,
                ],
            ];
        }
        if ( empty( $entities ) ) { return ''; }

        $schema = [
            '@context'   => 'https://schema.org',
            '@type'      => 'FAQPage',
            'mainEntity' => $entities,
        ];
        $json = wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        if ( $json === false ) { return ''; }
        $json = str_replace( '</script>', '<\/script>', $json );
        return '<script type="application/ld+json">' . $json . '</script>';
    }
}
