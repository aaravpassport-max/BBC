<?php
namespace GoodService\Service;

use GoodService\Core\Config;
use GoodService\Core\EventBus;

/**
 * RazorpayService
 *
 * Handles all Razorpay interactions: order creation, payment signature
 * verification, subscription activation, and booking deposit confirmation.
 *
 * No external SDK — uses wp_remote_post/get directly, consistent with the
 * rest of the codebase's no-Composer philosophy.
 *
 * Keys are read from gs_settings via Config::get():
 *   razorpay_key_id     → publishable key (safe to send to frontend)
 *   razorpay_key_secret → secret key (server-side only, never sent to frontend)
 *
 * Razorpay Checkout flow:
 *   1. Server creates an Order via create_order() → returns order_id
 *   2. Frontend opens Razorpay Checkout JS with order_id + key_id
 *   3. Customer pays → Razorpay calls webhook (already handled by RestApiController)
 *   4. Frontend also calls gs_verify_razorpay_payment → verify_payment() confirms signature
 *   5. On success → activate_subscription() or confirm_booking_deposit()
 */
final class RazorpayService {

    private const API_BASE = 'https://api.razorpay.com/v1';

    // ── Key helpers ────────────────────────────────────────────────────────────

    public static function key_id(): string {
        return (string) Config::get( 'razorpay_key_id', '' );
    }

    private static function key_secret(): string {
        return (string) Config::get( 'razorpay_key_secret', '' );
    }

    public static function is_configured(): bool {
        // Real fix: the admin enable/disable toggle for this gateway must
        // actually gate something, or it's decorative — a vendor could
        // still be offered "Pay with Razorpay" after an admin explicitly
        // switched it off. Defaults to enabled (Config::get(...,true)) so
        // existing installs that already had working keys configured
        // before this toggle existed aren't silently disabled by its
        // introduction.
        if ( ! (bool) Config::get( 'razorpay_enabled', true ) ) { return false; }
        return self::key_id() !== '' && self::key_secret() !== '';
    }

    // ── Order creation ─────────────────────────────────────────────────────────

    /**
     * Create a Razorpay order.
     *
     * @param int    $amount_paise  Amount in paise (₹499 = 49900)
     * @param string $receipt       Short identifier (e.g. "sub_42_monthly" or "bk_17")
     * @param array  $notes         Key-value metadata stored on the order (vendor_id, plan_id, etc.)
     * @return array|false          Razorpay order object array, or false on failure
     */
    /**
     * Real, live test of whether the configured credentials actually
     * work — hits Razorpay's read-only /orders list endpoint (count=1,
     * no order created, no charge possible) purely to confirm the API
     * accepts the key/secret pair. Used by the admin Payment Gateways
     * page's "Test Connection" button, since "keys are non-empty
     * strings" (is_configured()) is not the same guarantee as "these
     * keys are genuinely valid and active."
     *
     * @return array{ok:bool, message:string}
     */
    public static function test_connection(): array {
        if ( ! self::key_id() || ! self::key_secret() ) {
            return [ 'ok' => false, 'message' => 'Key ID and Key Secret must both be set first.' ];
        }
        $response = wp_remote_get( self::API_BASE . '/orders?count=1', [
            'timeout' => 15,
            'headers' => [ 'Authorization' => 'Basic ' . base64_encode( self::key_id() . ':' . self::key_secret() ) ],
        ] );
        if ( is_wp_error( $response ) ) {
            return [ 'ok' => false, 'message' => 'Network error: ' . $response->get_error_message() ];
        }
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code === 200 ) {
            return [ 'ok' => true, 'message' => 'Connected successfully — credentials are valid.' ];
        }
        if ( $code === 401 ) {
            return [ 'ok' => false, 'message' => 'Authentication failed — Key ID or Key Secret is incorrect.' ];
        }
        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        return [ 'ok' => false, 'message' => 'Razorpay returned an error (HTTP ' . $code . '): ' . ( $body['error']['description'] ?? 'Unknown error' ) ];
    }

    public static function create_order( int $amount_paise, string $receipt, array $notes = [] ): array|false {
        if ( ! self::is_configured() ) {
            gs_write_log( 'RazorpayService: keys not configured', 'ERROR' );
            return false;
        }

        $payload = [
            'amount'          => $amount_paise,
            'currency'        => Config::get( 'currency', 'INR' ),
            'receipt'         => substr( $receipt, 0, 40 ), // Razorpay max 40 chars
            'notes'           => $notes,
            'payment_capture' => 1, // auto-capture
        ];

        $response = wp_remote_post( self::API_BASE . '/orders', [
            'timeout' => 20,
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Basic ' . base64_encode( self::key_id() . ':' . self::key_secret() ),
            ],
            'body' => wp_json_encode( $payload ),
        ] );

        if ( is_wp_error( $response ) ) {
            gs_write_log( 'RazorpayService::create_order error: ' . $response->get_error_message(), 'ERROR' );
            return false;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 || empty( $body['id'] ) ) {
            gs_write_log( 'RazorpayService::create_order bad response ' . $code . ': ' . wp_json_encode( $body ), 'ERROR' );
            return false;
        }

        return $body;
    }

    // ── Signature verification ─────────────────────────────────────────────────

    /**
     * Verify a Razorpay payment signature (client-side verification step).
     *
     * After a successful checkout, Razorpay sends razorpay_order_id,
     * razorpay_payment_id, and razorpay_signature to the frontend.
     * We must verify the signature server-side before activating anything.
     *
     * The HMAC string is: order_id + "|" + payment_id
     *
     * @param string $order_id    razorpay_order_id from checkout response
     * @param string $payment_id  razorpay_payment_id from checkout response
     * @param string $signature   razorpay_signature from checkout response
     * @return bool
     */
    public static function verify_payment(
        string $order_id,
        string $payment_id,
        string $signature
    ): bool {
        if ( ! self::key_secret() ) { return false; }
        $expected = hash_hmac( 'sha256', $order_id . '|' . $payment_id, self::key_secret() );
        return hash_equals( $expected, $signature );
    }

    // ── Subscription activation ────────────────────────────────────────────────

    /**
     * Activate (or upgrade) a vendor subscription after payment is verified.
     * Creates the gs_subscriptions row, logs an invoice, fires EventBus event.
     *
     * @param int    $vendor_id    gs_vendor_profiles.id
     * @param int    $plan_id      gs_subscription_plans.id
     * @param string $payment_id   Razorpay payment ID (e.g. pay_Abcd1234)
     * @param string $cycle        'monthly' | 'yearly'
     * @return int|false           New subscription ID or false on failure
     */
    public static function activate_subscription(
        int    $vendor_id,
        int    $plan_id,
        string $payment_id,
        string $cycle = 'monthly'
    ): int|false {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        // Real fix — idempotency, checked here once rather than
        // separately (and inconsistently) at every call site. Both the
        // client-side gs_razorpay_verify_payment AJAX call and the
        // Razorpay webhook can legitimately fire for the exact same
        // payment — that's how webhooks are supposed to work, a backup
        // confirmation path, not an edge case to shrug off. Without this,
        // whichever call arrives second would cancel the subscription the
        // first call just created and activate a brand new one, and
        // generate a second invoice for a single real payment.
        if ( $payment_id !== '' ) {
            $existing_sub_id = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$pfx}subscriptions WHERE payment_id = %s ORDER BY id DESC LIMIT 1", $payment_id
            ) );
            if ( $existing_sub_id ) {
                gs_write_log( "RazorpayService::activate_subscription: payment {$payment_id} already activated as subscription #{$existing_sub_id} — skipping duplicate activation." );
                return $existing_sub_id;
            }
        }

        $plan = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$pfx}subscription_plans WHERE id = %d AND is_active = 1", $plan_id
        ) );
        if ( ! $plan ) { return false; }

        // FIXED (re-audit follow-up): previously only branched yearly vs.
        // "everything else treated as monthly" — a genuinely quarterly-priced
        // plan/cycle would have been billed at the monthly price and expired
        // in 1 month instead of 3. Not reachable through the current live
        // Razorpay order-creation UI (gs_razorpay_create_order restricts
        // cycle to monthly/yearly only), but this is the function any future
        // quarterly checkout, or the still-registered gs_create_subscription
        // action, would call — fixed here rather than left latent.
        $amount   = match ( $cycle ) {
            'yearly'    => (float) $plan->price_yearly,
            'quarterly' => (float) $plan->price_quarterly,
            default     => (float) $plan->price_monthly,
        };
        $expires  = match ( $cycle ) {
            'yearly'    => date( 'Y-m-d H:i:s', strtotime( '+1 year' ) ),
            'quarterly' => date( 'Y-m-d H:i:s', strtotime( '+3 months' ) ),
            default     => date( 'Y-m-d H:i:s', strtotime( '+1 month' ) ),
        };

        // FIXED (re-audit follow-up, duplicate/conflicting-states area): this
        // only ever cancelled an existing status='active' row before inserting
        // the new one — a vendor still on a 'trialing' subscription who then
        // completes a real paid purchase was left with BOTH the trialing row
        // and the new active row simultaneously matching
        // status IN ('active','trialing'), the exact "duplicate subscription
        // state" this audit was asked to eliminate. Now cancels both,
        // matching the pattern SubscriptionService::cancel()/expire_batch() use.
        $wpdb->update(
            "{$pfx}subscriptions",
            [ 'status' => 'cancelled', 'updated_at' => current_time( 'mysql' ) ],
            [ 'vendor_id' => $vendor_id, 'status' => 'active' ]
        );
        $wpdb->update(
            "{$pfx}subscriptions",
            [ 'status' => 'cancelled', 'updated_at' => current_time( 'mysql' ) ],
            [ 'vendor_id' => $vendor_id, 'status' => 'trialing' ]
        );

        // Ghost-success fix: $wpdb->insert_id is NOT reset to 0 on a failed
        // insert — it retains whatever value the last SUCCESSFUL insert in this
        // request set it to (mysqli_insert_id is only updated after a query that
        // actually succeeds). The old "$sub_id = (int) $wpdb->insert_id; if
        // (!$sub_id) return false;" check therefore could not detect this
        // specific insert failing if any earlier insert in the same request had
        // already set a non-zero insert_id — on the real-money "payment
        // confirmed" path, that meant a failed subscription write could
        // silently fall through to generating an invoice, notifying the vendor
        // their plan is "active", and logging success, for a subscription row
        // that was never actually created. Now checked directly against the
        // insert() call's own return value instead.
        $inserted = $wpdb->insert( "{$pfx}subscriptions", [
            'vendor_id'     => $vendor_id,
            'plan_id'       => $plan_id,
            'plan_name'     => $plan->name,
            'billing_cycle' => $cycle,
            'amount'        => $amount,
            'status'        => 'active',
            'gateway'       => 'razorpay',
            'payment_id'    => $payment_id,
            'starts_at'     => current_time( 'mysql' ),
            'expires_at'    => $expires,
            // ENTERPRISE-AUDIT FIX (Part 2, High: plan versioning/grandfathering).
            'plan_snapshot' => \GoodService\Service\SubscriptionService::build_plan_snapshot( $plan_id ),
            'created_at'    => current_time( 'mysql' ),
            'updated_at'    => current_time( 'mysql' ),
        ] );
        if ( ! $inserted ) {
            gs_write_log( "RazorpayService: subscription insert FAILED for vendor {$vendor_id} (plan {$plan_id}) — payment {$payment_id} was received but no subscription row was created: " . $wpdb->last_error, 'ERROR' );
            return false;
        }
        $sub_id = (int) $wpdb->insert_id;
        if ( ! $sub_id ) { return false; }

        // Generate invoice (handles GST, numbering, line items)
        BillingService::generate_invoice( $sub_id );

        // Notify vendor
        $vp = \GoodService\Repository\VendorRepository::get_by_id( $vendor_id );
        if ( $vp ) {
            NotificationService::create(
                (int) $vp->user_id, 'subscription.activated',
                '🎉 ' . $plan->name . ' Plan Active!',
                'Your ' . $plan->name . ' plan is now active' . ( $expires ? ' until ' . date( 'd M Y', strtotime( $expires ) ) : '' ) . '.',
                home_url( '/vendor/dashboard/?section=subscription' ),
                'check-circle', '#059669'
            );
        }

        EventBus::emit( 'subscription.activated', [
            'vendor_id'   => $vendor_id,
            'plan_id'     => $plan_id,
            'plan_name'   => $plan->name,
            'payment_id'  => $payment_id,
            'cycle'       => $cycle,
            'expires_at'  => $expires,
        ] );

        gs_write_log( "RazorpayService: subscription #{$sub_id} activated for vendor {$vendor_id} (plan {$plan_id}, {$cycle})", 'INFO' );

        // FIXED (re-audit follow-up, Audit Trail area): every real paid
        // purchase/upgrade/downgrade goes through here, but this codebase's
        // gs_activity_log only ever captured ADMIN-initiated mutations
        // (grant/cancel/reclassify/delete/hide plan) — the actual "money
        // changed hands" event every dashboard revenue figure is built from
        // had no audit trail entry at all. get_current_user_id() here is the
        // vendor's own user id (this runs inside their own logged-in AJAX
        // request), which is what gs_log_activity() records as the actor —
        // correct, since this genuinely was that vendor's own action.
        if ( function_exists( 'gs_log_activity' ) ) {
            gs_log_activity(
                'purchase_subscription', 'subscription', $sub_id,
                sprintf( 'Vendor #%d purchased "%s" plan (%s, %s) via Razorpay, payment_id=%s.', $vendor_id, $plan->name, $cycle, gs_format_price( $amount ), $payment_id )
            );
        }
        return $sub_id;
    }

    // ── Booking deposit confirmation ───────────────────────────────────────────

    /**
     * Confirm a booking deposit payment.
     * Updates gs_bookings.status to 'confirmed', stores payment_id, logs invoice.
     *
     * @param int    $booking_id  gs_bookings.id
     * @param string $payment_id  Razorpay payment ID
     * @param float  $amount      Amount paid in INR (for invoice)
     * @return bool
     */
    public static function confirm_booking_deposit(
        int    $booking_id,
        string $payment_id
    ): bool {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $booking = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$pfx}bookings WHERE id = %d", $booking_id
        ) );
        if ( ! $booking || $booking->status === 'cancelled' ) { return false; }

        // SECURITY: amount is derived from the booking record set at order-creation
        // time (see AjaxController::razorpayCreateOrder() 'booking_deposit' branch),
        // never from client-supplied POST data. The Razorpay signature only proves
        // order_id/payment_id are genuine — it proves nothing about the amount, so
        // a client-supplied value here would let anyone record an arbitrary invoice
        // total after paying any real amount, however small.
        $amount = (float) $booking->amount;

        $wpdb->update( "{$pfx}bookings", [
            'status'     => 'confirmed',
            'updated_at' => current_time( 'mysql' ),
        ], [ 'id' => $booking_id ] );

        // Real feature — coupon usage incremented here, at genuine
        // payment confirmation, matching the exact same principle
        // BillingService::apply_coupon() already documents for
        // subscriptions: counting usage at preview/order-creation would
        // let a limited-use coupon be exhausted by people who never
        // actually completed payment.
        if ( ! empty( $booking->coupon_id ) ) {
            \GoodService\Service\BillingService::use_coupon( (int) $booking->coupon_id );
        }

        // Log invoice for the deposit
        $gst_rate = (float) Config::get( 'gst_rate', 18 );
        $tax      = round( $amount * $gst_rate / 100, 2 );
        $wpdb->insert( "{$wpdb->prefix}gs_invoices", [
            'invoice_no'  => \GoodService\Core\Helpers::generate_invoice_number(),
            'vendor_id'   => (int) $booking->vendor_id,
            'booking_id'  => $booking_id,
            'amount'      => $amount,
            'tax'         => $tax,
            'total'       => round( $amount + $tax, 2 ),
            'currency'    => Config::get( 'currency', 'INR' ),
            'status'      => 'paid',
            'payment_id'  => $payment_id,
            'gateway'     => 'razorpay',
            'paid_at'     => current_time( 'mysql' ),
            'created_at'  => current_time( 'mysql' ),
        ] );

        EventBus::emit( 'booking.deposit_paid', [
            'booking_id'  => $booking_id,
            'payment_id'  => $payment_id,
            'amount'      => $amount,
            'vendor_id'   => (int) $booking->vendor_id,
            'customer_id' => (int) ( $booking->customer_user_id ?? 0 ),
        ] );

        gs_write_log( "RazorpayService: deposit paid for booking #{$booking_id} (payment {$payment_id})", 'INFO' );
        return true;
    }

    /**
     * Issues a real refund via Razorpay's Refund API. Confirmed missing
     * during Phase 1 discovery — 'refunded' previously existed only as a
     * status label on gs_invoices, with no code anywhere that actually
     * called the gateway to reverse the charge.
     *
     * @param string   $payment_id  The Razorpay payment ID to refund (invoices.payment_id).
     * @param float|null $amount    Amount in rupees for a partial refund; null = full refund.
     * @return array{success:bool, refund_id:?string, error:?string}
     */
    public static function refund( string $payment_id, ?float $amount = null ): array {
        if ( ! $payment_id ) {
            return [ 'success' => false, 'refund_id' => null, 'error' => 'No payment ID provided.' ];
        }

        $payload = [];
        if ( $amount !== null ) {
            // Razorpay amounts are in paise, matching create_order()'s
            // own amount_paise convention exactly.
            $payload['amount'] = (int) round( $amount * 100 );
        }

        $response = wp_remote_post( self::API_BASE . "/payments/{$payment_id}/refund", [
            'timeout' => 20,
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Basic ' . base64_encode( self::key_id() . ':' . self::key_secret() ),
            ],
            'body' => wp_json_encode( $payload ),
        ] );

        if ( is_wp_error( $response ) ) {
            gs_write_log( 'RazorpayService::refund error: ' . $response->get_error_message(), 'ERROR' );
            return [ 'success' => false, 'refund_id' => null, 'error' => $response->get_error_message() ];
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code !== 200 || empty( $body['id'] ) ) {
            $err = $body['error']['description'] ?? "Unexpected response code {$code}";
            gs_write_log( 'RazorpayService::refund bad response ' . $code . ': ' . wp_json_encode( $body ), 'ERROR' );
            return [ 'success' => false, 'refund_id' => null, 'error' => $err ];
        }

        gs_write_log( "RazorpayService: refund {$body['id']} issued for payment {$payment_id}", 'INFO' );
        return [ 'success' => true, 'refund_id' => $body['id'], 'error' => null ];
    }

    /** Shared REST helper matching this class's own auth/error-handling convention. */
    private static function api_request( string $method, string $path, array $payload = [] ): array|false {
        $args = [
            'method'  => $method,
            'timeout' => 20,
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Basic ' . base64_encode( self::key_id() . ':' . self::key_secret() ),
            ],
        ];
        if ( $payload && $method !== 'GET' ) { $args['body'] = wp_json_encode( $payload ); }
        $response = wp_remote_request( self::API_BASE . $path, $args );
        if ( is_wp_error( $response ) ) {
            gs_write_log( 'RazorpayService::api_request error: ' . $response->get_error_message(), 'ERROR' );
            return false;
        }
        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 ) {
            gs_write_log( "RazorpayService::api_request bad response {$code} for {$path}: " . wp_json_encode( $body ), 'ERROR' );
            return false;
        }
        return is_array( $body ) ? $body : false;
    }

    // ── Saved payment methods ───────────────────────────────────────────────────
    // ENTERPRISE-AUDIT FIX (Part 3, large, deliberately deferred: "no saved
    // payment methods"). Razorpay tokenizes a card through its own Standard
    // Checkout when a customer_id + the recurring/"save card" flag are
    // passed (see razorpayCreateOrder()'s subscription branch and the
    // gsRzpStart() checkout options in vendor-dashboard.php) — there is no
    // separate "add a card with no charge" flow the way Stripe's SetupIntent
    // allows, so cards are only ever saved as a side effect of a real
    // subscription payment the vendor already made, with their explicit
    // consent via the checkbox Checkout itself renders. Everything here is
    // best-effort around that side effect: if token capture fails, the
    // actual subscription activation (already verified/idempotent — see
    // activate_subscription()) is never affected or rolled back.

    /** Returns the vendor's Razorpay Customer id, creating one on first use. */
    public static function get_or_create_customer( int $vendor_id ): ?string {
        global $wpdb;
        $vp = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, business_name, email, phone, razorpay_customer_id FROM {$wpdb->prefix}gs_vendor_profiles WHERE id=%d", $vendor_id
        ) );
        if ( ! $vp ) { return null; }
        if ( ! empty( $vp->razorpay_customer_id ) ) { return $vp->razorpay_customer_id; }

        // fail_existing=0: Razorpay returns the existing customer (rather
        // than an error) if one already matches this email/contact —
        // avoids ever creating a duplicate customer for the same vendor.
        $result = self::api_request( 'POST', '/customers', [
            'name'          => $vp->business_name ?: '',
            'email'         => $vp->email ?: '',
            'contact'       => $vp->phone ?: '',
            'fail_existing' => '0',
        ] );
        if ( $result === false || empty( $result['id'] ) ) {
            gs_write_log( "RazorpayService::get_or_create_customer failed for vendor #{$vendor_id}", 'ERROR' );
            return null;
        }
        $wpdb->update( $wpdb->prefix . 'gs_vendor_profiles', [ 'razorpay_customer_id' => $result['id'] ], [ 'id' => $vendor_id ] );
        return $result['id'];
    }

    /**
     * Called after a subscription payment is verified (see
     * AjaxController::razorpayVerifyPayment()) when the checkout was opened
     * with the "save card" option — fetches the completed payment to read
     * its token_id (present only if the customer actually opted to save the
     * card at checkout), then the token's card details for display.
     * Silently no-ops (logs only) on any failure — never throws, since this
     * runs after the real subscription activation has already succeeded.
     */
    public static function capture_token_from_payment( int $vendor_id, string $payment_id ): void {
        global $wpdb;
        $payment = self::api_request( 'GET', "/payments/{$payment_id}" );
        if ( ! $payment || empty( $payment['token_id'] ) ) { return; } // vendor didn't opt to save the card
        $token_id    = $payment['token_id'];
        $customer_id = $payment['customer_id'] ?? self::get_or_create_customer( $vendor_id );
        if ( ! $customer_id ) { return; }

        $token = self::api_request( 'GET', "/customers/{$customer_id}/tokens/{$token_id}" );
        $card  = $token['card'] ?? [];

        $has_default = (bool) $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_saved_payment_methods WHERE vendor_id=%d AND gateway='razorpay' AND is_default=1", $vendor_id
        ) );
        $wpdb->query( $wpdb->prepare(
            "INSERT INTO {$wpdb->prefix}gs_saved_payment_methods (vendor_id, gateway, gateway_ref, card_brand, card_last4, is_default, created_at)
             VALUES (%d,'razorpay',%s,%s,%s,%d,%s)
             ON DUPLICATE KEY UPDATE card_brand=VALUES(card_brand), card_last4=VALUES(card_last4)",
            $vendor_id, $token_id, (string) ( $card['network'] ?? '' ), (string) ( $card['last4'] ?? '' ),
            $has_default ? 0 : 1, current_time( 'mysql' )
        ) );
    }

    /** Detaches a saved card token from Razorpay and removes the local record. */
    public static function delete_token( int $vendor_id, string $token_id ): bool {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_saved_payment_methods WHERE vendor_id=%d AND gateway='razorpay' AND gateway_ref=%s",
            $vendor_id, $token_id
        ) );
        if ( ! $row ) { return false; } // ownership check
        $customer_id = $wpdb->get_var( $wpdb->prepare( "SELECT razorpay_customer_id FROM {$wpdb->prefix}gs_vendor_profiles WHERE id=%d", $vendor_id ) );
        if ( $customer_id ) { self::api_request( 'DELETE', "/customers/{$customer_id}/tokens/{$token_id}" ); }
        $wpdb->delete( $wpdb->prefix . 'gs_saved_payment_methods', [ 'id' => $row->id ] );
        return true;
    }

    /**
     * Charges a previously-saved card token (manual "Renew now with saved
     * card" action only — never called automatically). Uses Razorpay's
     * recurring-payment creation endpoint.
     */
    public static function charge_saved_token( int $vendor_id, string $token_id, float $amount, string $description = '' ): array {
        global $wpdb;
        $vp = $wpdb->get_row( $wpdb->prepare( "SELECT email, phone, razorpay_customer_id FROM {$wpdb->prefix}gs_vendor_profiles WHERE id=%d", $vendor_id ) );
        if ( ! $vp || ! $vp->razorpay_customer_id ) { return [ 'success' => false, 'error' => 'No saved Razorpay customer for this vendor.' ]; }

        $result = self::api_request( 'POST', '/payments/create/recurring', [
            'email'       => $vp->email ?: '',
            'contact'     => $vp->phone ?: '',
            'amount'      => (int) round( $amount * 100 ),
            'currency'    => Config::get( 'currency', 'INR' ),
            'customer_id' => $vp->razorpay_customer_id,
            'token'       => $token_id,
            'description' => $description,
        ] );
        if ( $result === false || empty( $result['id'] ) ) {
            return [ 'success' => false, 'error' => 'Charge failed. The saved card may have been declined or removed.' ];
        }
        if ( ( $result['status'] ?? '' ) === 'failed' ) {
            return [ 'success' => false, 'error' => 'Payment failed (' . ( $result['error_description'] ?? 'declined' ) . ').' ];
        }
        return [ 'success' => true, 'payment_id' => $result['id'] ];
    }
}
