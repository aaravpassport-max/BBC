<?php
namespace GoodService\Service;

/**
 * ENTERPRISE-AUDIT FIX (Part 2, §6, High: "no backup/restore panel — none
 * exists anywhere in scope"). A plugin holding its own fully-custom
 * gs_* tables (subscriptions, invoices, disputes, leads, reviews...) with
 * no backup path beyond "hope the host's automated backups cover it" is a
 * real operational risk this audit named directly. This is deliberately
 * scoped to the plugin's OWN data (every {$wpdb->prefix}gs_* table) rather
 * than a general-purpose WordPress backup tool — that's a much larger,
 * already-solved problem (many dedicated plugins exist for it) and
 * reinventing it here would be exactly the kind of over-scoped rebuild the
 * audit process is meant to avoid. What's missing, and what this adds, is
 * a way to snapshot/restore the vendor-directory data itself, independent
 * of whatever (if anything) the host is backing up at the DB-server level.
 */
final class BackupService {

    /** Files under this directory are never web-accessible — see
     * ensure_backup_dir()'s .htaccess + index.php + web.config triplet. */
    private const DIR_NAME = 'gs23-backups';

    public static function backup_dir(): string {
        $up = wp_upload_dir();
        return trailingslashit( $up['basedir'] ) . self::DIR_NAME;
    }

    /**
     * Creates the backup directory if missing, and — every call, not just
     * on first creation, so a host that wipes dotfiles/index.php on a
     * migration gets them re-created automatically — writes the three
     * standard "deny direct access" guards (Apache .htaccess, a blank
     * index.php against directory listing, and an IIS web.config
     * equivalent for hosts running IIS instead of Apache/Nginx).
     */
    private static function ensure_backup_dir(): string {
        $dir = self::backup_dir();
        if ( ! is_dir( $dir ) ) {
            wp_mkdir_p( $dir );
        }
        $htaccess = $dir . '/.htaccess';
        if ( ! file_exists( $htaccess ) ) {
            file_put_contents( $htaccess, "Require all denied\nDeny from all\n" );
        }
        $index = $dir . '/index.php';
        if ( ! file_exists( $index ) ) {
            file_put_contents( $index, "<?php\n// Silence is golden.\n" );
        }
        $webconfig = $dir . '/web.config';
        if ( ! file_exists( $webconfig ) ) {
            file_put_contents( $webconfig, "<configuration>\n  <system.webServer>\n    <authorization>\n      <deny users=\"*\" />\n    </authorization>\n  </system.webServer>\n</configuration>\n" );
        }
        return $dir;
    }

    /** Every table this plugin owns — dynamic (SHOW TABLES LIKE), not a
     * hardcoded list, so a table added by a future version is automatically
     * included without this file needing to be touched again. */
    public static function plugin_tables(): array {
        global $wpdb;
        $like = $wpdb->esc_like( $wpdb->prefix . 'gs_' ) . '%';
        $rows = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );
        return $rows ?: [];
    }

    /**
     * Dumps every plugin table (schema + data) to a single gzip-compressed
     * .sql.gz file in the protected backup directory. Returns
     * ['success'=>bool, 'filename'=>string, 'size'=>int, 'tables'=>int, 'error'=>string].
     */
    public static function create_backup( string $label = '', int $requested_by = 0 ): array {
        global $wpdb;
        $dir = self::ensure_backup_dir();
        $tables = self::plugin_tables();
        if ( ! $tables ) {
            return [ 'success' => false, 'error' => 'No plugin tables found — nothing to back up.' ];
        }

        $safe_label = $label !== '' ? '-' . preg_replace( '/[^a-z0-9\-]+/i', '', str_replace( ' ', '-', $label ) ) : '';
        $filename = 'gs23-backup-' . gmdate( 'Ymd-His' ) . $safe_label . '.sql.gz';
        $path = $dir . '/' . $filename;

        $gz = gzopen( $path, 'wb9' );
        if ( ! $gz ) {
            return [ 'success' => false, 'error' => 'Could not open backup file for writing — check the uploads directory is writable.' ];
        }

        gzwrite( $gz, "-- GoodService (gs23) data backup\n" );
        gzwrite( $gz, "-- Created: " . gmdate( 'c' ) . " UTC by user #{$requested_by}\n" );
        gzwrite( $gz, "-- Tables: " . count( $tables ) . "\n" );
        gzwrite( $gz, "-- Restoring this file DROPS and RECREATES every table listed below with the\n" );
        gzwrite( $gz, "-- data captured at the time this backup was made. It does not touch any\n" );
        gzwrite( $gz, "-- non-gs23 WordPress table.\n\n" );
        gzwrite( $gz, "SET FOREIGN_KEY_CHECKS=0;\nSET NAMES utf8mb4;\n\n" );

        foreach ( $tables as $table ) {
            $create = $wpdb->get_row( "SHOW CREATE TABLE `{$table}`", ARRAY_N );
            if ( ! $create || empty( $create[1] ) ) { continue; }
            gzwrite( $gz, "-- ----------------------------\n-- Table: {$table}\n-- ----------------------------\n" );
            gzwrite( $gz, "DROP TABLE IF EXISTS `{$table}`;\n" );
            gzwrite( $gz, $create[1] . ";\n\n" );

            // Stream rows in chunks rather than loading the whole table into
            // memory at once — a plugin table like gs_activity_log or
            // gs_leads can genuinely reach hundreds of thousands of rows on
            // an established install, and get_results() with no LIMIT would
            // risk hitting PHP's memory_limit mid-backup.
            $chunk = 500;
            $offset = 0;
            $columns = null;
            while ( true ) {
                $rows = $wpdb->get_results( "SELECT * FROM `{$table}` LIMIT {$chunk} OFFSET {$offset}", ARRAY_A );
                if ( ! $rows ) { break; }
                if ( $columns === null ) {
                    $columns = array_keys( $rows[0] );
                }
                $col_list = '`' . implode( '`,`', $columns ) . '`';
                $value_rows = [];
                foreach ( $rows as $row ) {
                    $vals = [];
                    foreach ( $columns as $c ) {
                        $v = $row[ $c ];
                        $vals[] = $v === null ? 'NULL' : "'" . self::esc_sql_literal( (string) $v ) . "'";
                    }
                    $value_rows[] = '(' . implode( ',', $vals ) . ')';
                }
                gzwrite( $gz, "INSERT INTO `{$table}` ({$col_list}) VALUES\n" . implode( ",\n", $value_rows ) . ";\n" );
                $offset += $chunk;
                if ( count( $rows ) < $chunk ) { break; }
            }
            gzwrite( $gz, "\n" );
        }

        gzwrite( $gz, "SET FOREIGN_KEY_CHECKS=1;\n" );
        gzclose( $gz );

        if ( ! file_exists( $path ) ) {
            return [ 'success' => false, 'error' => 'Backup file was not created.' ];
        }

        return [
            'success' => true,
            'filename' => $filename,
            'size' => filesize( $path ),
            'tables' => count( $tables ),
        ];
    }

    /** Manual escaping for values written into the raw SQL dump text itself
     * (NOT a $wpdb query — there is no placeholder mechanism for a whole
     * multi-row VALUES clause built ahead of time), matching what
     * mysqli_real_escape_string would do for the characters that matter in
     * a single-quoted MySQL string literal. */
    private static function esc_sql_literal( string $v ): string {
        return str_replace(
            [ '\\', "\0", "\n", "\r", "'", '"', "\x1a" ],
            [ '\\\\', '\\0', '\\n', '\\r', "\\'", '\\"', '\\Z' ],
            $v
        );
    }

    /** Lists backups newest-first, with size/date, filtered to files that
     * actually match the expected naming pattern (defense against someone
     * dropping an unrelated file in the same directory). */
    public static function list_backups(): array {
        $dir = self::backup_dir();
        if ( ! is_dir( $dir ) ) { return []; }
        $out = [];
        foreach ( scandir( $dir ) ?: [] as $f ) {
            if ( ! preg_match( '/^gs23-backup-\d{8}-\d{6}(-[a-z0-9\-]+)?\.sql\.gz$/i', $f ) ) { continue; }
            $full = $dir . '/' . $f;
            $out[] = [
                'filename' => $f,
                'size'     => filesize( $full ),
                'created'  => gmdate( 'Y-m-d H:i:s', filemtime( $full ) ),
            ];
        }
        usort( $out, static fn( $a, $b ) => strcmp( $b['filename'], $a['filename'] ) );
        return $out;
    }

    /** Validates a filename against the exact naming pattern before any
     * filesystem operation touches it — the only thing standing between a
     * user-controlled $_POST['filename'] and path traversal outside the
     * backup directory (../../wp-config.php, etc). Every public method
     * below that accepts a filename calls this first. */
    private static function safe_filename( string $filename ): ?string {
        if ( ! preg_match( '/^gs23-backup-\d{8}-\d{6}(-[a-z0-9\-]+)?\.sql\.gz$/i', $filename ) ) {
            return null;
        }
        $path = self::backup_dir() . '/' . $filename;
        // Belt-and-suspenders: even with the regex above, confirm the
        // resolved real path is still inside the backup directory.
        $real_dir = realpath( self::backup_dir() );
        $real_path = realpath( $path );
        if ( ! $real_dir || ! $real_path || strpos( $real_path, $real_dir ) !== 0 ) {
            return null;
        }
        return $real_path;
    }

    public static function delete_backup( string $filename ): bool {
        $path = self::safe_filename( $filename );
        if ( ! $path || ! file_exists( $path ) ) { return false; }
        return unlink( $path );
    }

    public static function backup_path( string $filename ): ?string {
        return self::safe_filename( $filename );
    }

    /**
     * Restores from a backup file: DROPs and recreates every gs23 table
     * present in the dump, statement by statement. Genuinely destructive
     * by design (that is what "restore" means) — the AJAX layer is
     * responsible for requiring the admin to type a confirmation phrase
     * before calling this, and for taking a fresh pre-restore safety
     * backup first (see AjaxController::adminRestoreBackup()).
     */
    public static function restore_backup( string $filename ): array {
        $path = self::safe_filename( $filename );
        if ( ! $path || ! file_exists( $path ) ) {
            return [ 'success' => false, 'error' => 'Backup file not found.' ];
        }
        global $wpdb;
        $gz = gzopen( $path, 'rb' );
        if ( ! $gz ) {
            return [ 'success' => false, 'error' => 'Could not open backup file for reading.' ];
        }

        $sql = '';
        while ( ! gzeof( $gz ) ) {
            $sql .= gzread( $gz, 1024 * 1024 );
        }
        gzclose( $gz );

        if ( trim( $sql ) === '' ) {
            return [ 'success' => false, 'error' => 'Backup file is empty or corrupted.' ];
        }

        // Split into individual statements on a semicolon that ends a line —
        // safe here because every statement this class itself WRITES
        // (DROP TABLE / CREATE TABLE / INSERT / SET) ends its own line with
        // ";\n", and string values were escaped so no literal ";\n"
        // sequence can appear inside a VALUES clause. This restorer is only
        // ever fed files this class produced, not arbitrary user SQL.
        $statements = preg_split( '/;\s*\n/', $sql );
        $applied = 0;
        $errors = [];
        foreach ( $statements as $stmt ) {
            $stmt = trim( $stmt );
            if ( $stmt === '' || str_starts_with( $stmt, '--' ) ) { continue; }
            $result = $wpdb->query( $stmt );
            if ( $result === false ) {
                $errors[] = substr( $stmt, 0, 80 ) . '... : ' . $wpdb->last_error;
                continue;
            }
            $applied++;
        }

        \GoodService\Core\Cache::flush_group();

        if ( $errors ) {
            return [
                'success' => count( $errors ) < $applied, // majority succeeded — surface as a partial success with details, not a hard failure that hides what DID apply
                'applied' => $applied,
                'errors'  => $errors,
                'error'   => count( $errors ) . ' statement(s) failed during restore — see details. Some tables may be in a mixed state; consider restoring the pre-restore safety backup.',
            ];
        }

        return [ 'success' => true, 'applied' => $applied ];
    }
}
