<?php
namespace GoodService\Service;

use GoodService\Core\Cache;
use GoodService\Core\Config;

/**
 * DiagnosisService — AI Problem Diagnosis Engine (Moat 1)
 * Conducts a short AI-powered diagnostic conversation before the inquiry is sent.
 * Uses the same Anthropic API key as the AI Draft feature.
 */
final class DiagnosisService {

    /** Start a new diagnosis session. */
    public static function start_session( string $category_slug, int $listing_id = 0, string $initial_message = '' ): array {
        global $wpdb;

        $template = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_diagnosis_templates WHERE category_slug=%s AND is_active=1",
            $category_slug
        ) );

        $opening = $template->opening_question
            ?? "Please describe the problem you are facing with " . ucwords( str_replace( '-', ' ', $category_slug ) ) . ".";

        $session_id = wp_generate_uuid4();
        $messages   = [];

        if ( $initial_message ) {
            $messages[] = [ 'role' => 'user', 'content' => $initial_message ];
        }

        $wpdb->insert( $wpdb->prefix . 'gs_diagnosis_sessions', [
            'id'              => $session_id,
            'user_id'         => is_user_logged_in() ? get_current_user_id() : null,
            'listing_id'      => $listing_id ?: null,
            'category_slug'   => $category_slug,
            'initial_message' => $initial_message,
            'messages'        => wp_json_encode( $messages ),
            'urgency_level'   => 'normal',
            'started_at'      => current_time( 'mysql' ),
        ] );

        return [
            'session_id'      => $session_id,
            'opening_question'=> $opening,
            'max_turns'       => $template->max_turns ?? 4,
        ];
    }

    /** Send a message in an existing session and get AI response. */
    public static function send_message( string $session_id, string $user_message ): array {
        global $wpdb;

        $session = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_diagnosis_sessions WHERE id=%s",
            $session_id
        ) );
        if ( ! $session ) { return [ 'error' => 'Session not found.' ]; }

        $template = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_diagnosis_templates WHERE category_slug=%s",
            $session->category_slug
        ) );

        $messages    = json_decode( $session->messages ?? '[]', true ) ?: [];
        $messages[]  = [ 'role' => 'user', 'content' => sanitize_textarea_field( $user_message ) ];

        $system_prompt = $template->system_prompt
            ?? "You are a helpful service diagnosis assistant. Ask short follow-up questions to understand the client's problem, then output a JSON diagnosis.";

        $ai_key = Config::get( 'ai_api_key', '' ) ?: get_option( 'gs_anthropic_api_key', '' );
        if ( ! $ai_key ) {
            $messages[] = [ 'role' => 'assistant', 'content' => 'AI diagnosis is not configured. Please describe your problem and we will connect you with a professional.' ];
            $wpdb->update( $wpdb->prefix . 'gs_diagnosis_sessions', [ 'messages' => wp_json_encode( $messages ) ], [ 'id' => $session_id ] );
            return [ 'message' => end( $messages )['content'], 'is_diagnosis' => false ];
        }

        // Call Anthropic API
        $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
            'timeout' => 30,
            'headers' => [
                'x-api-key'         => $ai_key,
                'anthropic-version' => '2023-06-01',
                'Content-Type'      => 'application/json',
            ],
            'body' => wp_json_encode( [
                'model'      => 'claude-sonnet-4-20250514',
                'max_tokens' => 600,
                'system'     => $system_prompt,
                'messages'   => $messages,
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            return [ 'error' => 'AI service temporarily unavailable. Please describe your problem directly.' ];
        }

        $body      = json_decode( wp_remote_retrieve_body( $response ), true );
        $ai_text   = $body['content'][0]['text'] ?? '';
        if ( ! $ai_text ) { return [ 'error' => 'No response from AI.' ]; }

        $messages[] = [ 'role' => 'assistant', 'content' => $ai_text ];

        // Detect if this is a JSON diagnosis output
        $is_diagnosis = false;
        $diagnosis    = null;
        $trimmed      = trim( $ai_text );
        if ( str_starts_with( $trimmed, '{' ) && str_ends_with( $trimmed, '}' ) ) {
            $parsed = json_decode( $trimmed, true );
            if ( json_last_error() === JSON_ERROR_NONE && isset( $parsed['summary'] ) ) {
                $is_diagnosis = true;
                $diagnosis    = $parsed;
            }
        }

        $urgency = $diagnosis['urgency'] ?? $session->urgency_level;

        $wpdb->update( $wpdb->prefix . 'gs_diagnosis_sessions', [
            'messages'     => wp_json_encode( $messages ),
            'diagnosis'    => $diagnosis ? wp_json_encode( $diagnosis ) : null,
            'urgency_level'=> $urgency,
            'completed_at' => $is_diagnosis ? current_time( 'mysql' ) : null,
        ], [ 'id' => $session_id ] );

        return [
            'message'      => $is_diagnosis ? null : $ai_text,
            'is_diagnosis' => $is_diagnosis,
            'diagnosis'    => $diagnosis,
            'urgency'      => $urgency,
            'session_id'   => $session_id,
        ];
    }

    /** Convert a completed diagnosis session into a lead. */
    public static function convert_to_lead( string $session_id, array $contact ): array {
        global $wpdb;

        $session = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_diagnosis_sessions WHERE id=%s",
            $session_id
        ) );
        if ( ! $session || ! $session->diagnosis ) {
            return [ 'error' => 'Diagnosis not complete.' ];
        }

        $diagnosis = json_decode( $session->diagnosis, true ) ?? [];

        // Build a rich description from the diagnosis
        $description = $diagnosis['summary'] ?? $session->initial_message;
        if ( ! empty( $diagnosis['symptoms'] ) ) {
            $description .= "\n\nSymptoms: " . implode( ', ', (array) $diagnosis['symptoms'] );
        }
        if ( ! empty( $diagnosis['vendor_instruction'] ) ) {
            $description .= "\n\nNote for vendor: " . $diagnosis['vendor_instruction'];
        }

        // Ghost-success fix: this insert's result was previously discarded
        // entirely — a DB failure would still return 'success' => true
        // (with lead_id 0, or a stale id from an earlier insert since
        // insert_id is not reset on failure), telling the customer their
        // diagnosis was converted to a real lead when nothing was created.
        $inserted = $wpdb->insert( $wpdb->prefix . 'gs_leads', [
            'listing_id'        => $session->listing_id ?: 0,
            'vendor_id'         => $session->listing_id
                ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT vendor_id FROM {$wpdb->prefix}gs_listings WHERE id=%d", $session->listing_id ) )
                : 0,
            'name'              => sanitize_text_field( $contact['name'] ?? 'Client' ),
            'phone'             => sanitize_text_field( $contact['phone'] ?? '' ),
            'email'             => sanitize_email( $contact['email'] ?? '' ),
            'message'           => $description,
            'inquiry_module'    => $session->category_slug,
            'urgency_level'     => $diagnosis['urgency'] ?? 'normal',
            'status'            => 'new',
            'customer_user_id'  => is_user_logged_in() ? get_current_user_id() : 0,
            'ip_address'        => gs_get_ip(),
            'created_at'        => current_time( 'mysql' ),
        ] );
        if ( ! $inserted ) {
            return [ 'error' => 'Could not create a lead from this diagnosis: ' . $wpdb->last_error ];
        }

        $lead_id = (int) $wpdb->insert_id;
        if ( ! $lead_id ) {
            return [ 'error' => 'Could not create a lead from this diagnosis.' ];
        }

        $wpdb->update( $wpdb->prefix . 'gs_diagnosis_sessions', [
            'converted_to_lead' => 1,
            'lead_id'           => $lead_id,
        ], [ 'id' => $session_id ] );

        return [ 'success' => true, 'lead_id' => $lead_id ];
    }
}
