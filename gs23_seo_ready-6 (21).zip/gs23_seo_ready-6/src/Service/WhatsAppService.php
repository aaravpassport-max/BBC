<?php
namespace GoodService\Service;

use GoodService\Core\Config;

/**
 * WhatsAppService — WhatsApp deep-link generation and optional BSP API integration.
 *
 * Track A: Deep-link (free, all vendors) — generates wa.me URLs with pre-filled text.
 * Track B: BSP API (360dialog / Interakt) — programmatic send for premium vendors.
 *
 * Category templates for pre-filling WhatsApp messages based on service type.
 */
final class WhatsAppService {

    /** Default message templates per service category slug. */
    public const CATEGORY_TEMPLATES = [
        'plumber'        => "Hi {{client_name}}, I am {{vendor_name}} from GoodService. I saw your plumbing inquiry and can help. Are you available for a quick call to discuss the issue?",
        'electrician'    => "Hi {{client_name}}, I am {{vendor_name}} from GoodService. I can assist with your electrical work. When would be a good time to visit?",
        'ca'             => "Hi {{client_name}}, I am {{vendor_name}}, a Chartered Accountant. I reviewed your inquiry and can assist with your tax/GST requirements. Can we connect for 10 minutes?",
        'packers-movers' => "Hi {{client_name}}, this is {{vendor_name}} from GoodService. I can provide shifting services. Can you share your moving date and locations?",
        'pest-control'   => "Hi {{client_name}}, I am {{vendor_name}} from GoodService. I can assist with pest control. Are you available for a site assessment?",
        'ac-repair'      => "Hi {{client_name}}, I am {{vendor_name}} from GoodService. I specialise in AC service and repair. When would be a convenient time to check your unit?",
        'default'        => "Hi {{client_name}}, I am {{vendor_name}} from GoodService. I saw your inquiry and would like to assist. Can we connect to discuss the details?",
    ];

    /** Build a wa.me deep-link with a pre-filled message. */
    public static function build_link( string $phone, string $message ): string {
        $phone_clean = preg_replace( '/\D/', '', $phone );
        if ( ! str_starts_with( $phone_clean, '91' ) && strlen( $phone_clean ) === 10 ) {
            $phone_clean = '91' . $phone_clean;
        }
        return 'https://wa.me/' . $phone_clean . '?text=' . rawurlencode( $message );
    }

    /** Get the category template for a given slug, with token replacement. */
    public static function get_template( string $category_slug, array $vars = [], int $vendor_id = 0, string $language = 'en' ): string {
        // Real fix — Audit Section F: templates are now DB-backed and
        // admin-editable (see the new "WhatsApp Templates" admin page and
        // gs_whatsapp_category_templates, seeded from this exact constant so
        // nothing changes until an admin explicitly edits one). The
        // constant below remains as the fallback for installs that
        // haven't run the DB upgrade yet, or if a category has no
        // corresponding DB row for any other reason.
        $template = self::get_template_from_db( $category_slug, $vendor_id, $language );
        if ( $template === null ) {
            $template = self::CATEGORY_TEMPLATES[ $category_slug ]
                     ?? self::CATEGORY_TEMPLATES['default'];
        }

        foreach ( $vars as $key => $value ) {
            $template = str_replace( '{{' . $key . '}}', esc_html( (string) $value ), $template );
        }
        return $template;
    }

    /**
     * Looks up an active, approved template body from
     * gs_whatsapp_category_templates for the given category. Resolution
     * order (most specific wins), real fix for Audit Section F's "vendor
     * templates" + "localisation support":
     *   1. This vendor's own override, in the requested language.
     *   2. This vendor's own override, in the default language ('en') —
     *      a vendor who only ever wrote one version shouldn't lose their
     *      customization just because a language other than 'en' was
     *      requested.
     *   3. The platform default (vendor_id=0), in the requested language.
     *   4. The platform default, in 'en'.
     *   5. null — caller falls back to the hardcoded constant.
     * Every lookup requires status='approved' — a vendor's pending or
     * draft edit is stored and visible to them and to admin for review,
     * but never affects what customers actually see sent until an admin
     * approves it (see saveWhatsappTemplate()'s status handling).
     */
    private static function get_template_from_db( string $category_slug, int $vendor_id = 0, string $language = 'en' ): ?string {
        global $wpdb;
        $tbl = $wpdb->prefix . 'gs_whatsapp_category_templates';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) { return null; }

        $lookups = [];
        if ( $vendor_id > 0 ) {
            $lookups[] = [ $category_slug, $vendor_id, $language ];
            if ( $language !== 'en' ) { $lookups[] = [ $category_slug, $vendor_id, 'en' ]; }
        }
        $lookups[] = [ $category_slug, 0, $language ];
        if ( $language !== 'en' ) { $lookups[] = [ $category_slug, 0, 'en' ]; }
        // Final fallback: platform default's 'default' category row.
        $lookups[] = [ 'default', 0, $language ];
        if ( $language !== 'en' ) { $lookups[] = [ 'default', 0, 'en' ]; }

        foreach ( $lookups as [ $slug, $vid, $lang ] ) {
            $body = $wpdb->get_var( $wpdb->prepare(
                "SELECT body FROM {$tbl} WHERE category_slug = %s AND vendor_id = %d AND language = %s AND is_active = 1 AND status = 'approved' LIMIT 1",
                $slug, $vid, $lang
            ) );
            if ( $body !== null ) { return (string) $body; }
        }
        return null;
    }

    /** Check if BSP API sending is enabled. */
    public static function is_api_enabled(): bool {
        return (bool) Config::get( 'whatsapp_enabled', false )
            && ! empty( Config::get( 'whatsapp_api_key', '' ) );
    }

    /**
     * Send a text message via WhatsApp Business API (Track B — premium vendors).
     * Returns true on success, false if disabled or on error.
     *
     * @param string $to_phone  Mobile number (with or without country code).
     * @param string $body      Plain text message.
     */
    public static function send_text( string $to_phone, string $body, int $lead_id = 0, int $vendor_id = 0 ): bool {
        if ( ! self::is_api_enabled() ) { return false; }

        $bsp     = Config::get( 'whatsapp_bsp', '360dialog' );
        $api_key = Config::get( 'whatsapp_api_key', '' );
        $phone_clean = preg_replace( '/\D/', '', $to_phone );

        // Meta's own Cloud API (graph.facebook.com) — a genuinely different
        // request shape from the BSP aggregators below: Bearer-token auth
        // and the sending phone number's ID embedded in the URL path
        // itself, rather than a header-based API key. Added specifically
        // because direct Meta Business API compatibility was an explicit
        // requirement, not just BSP aggregator support.
        if ( $bsp === 'meta_cloud_api' ) {
            $phone_number_id = Config::get( 'whatsapp_meta_phone_number_id', '' );
            if ( ! $phone_number_id ) {
                gs_write_log( 'WhatsAppService: whatsapp_meta_phone_number_id is not configured — cannot send via Meta Cloud API.' );
                return false;
            }
            $response = wp_remote_post( "https://graph.facebook.com/v21.0/{$phone_number_id}/messages", [
                'timeout' => 15,
                'headers' => [
                    'Authorization' => 'Bearer ' . $api_key, // whatsapp_api_key holds the Meta System User access token in this mode
                    'Content-Type'  => 'application/json',
                ],
                'body' => wp_json_encode( [
                    'messaging_product' => 'whatsapp',
                    'recipient_type'    => 'individual',
                    'to'                => $phone_clean,
                    'type'              => 'text',
                    'text'              => [ 'body' => $body ],
                ] ),
            ] );
            if ( is_wp_error( $response ) ) {
                gs_write_log( 'WhatsAppService (Meta Cloud API): send failed — ' . $response->get_error_message() );
                self::log( $to_phone, $body, 'failed', $lead_id, $vendor_id, '', $response->get_error_message() );
                return false;
            }
            $code = wp_remote_retrieve_response_code( $response );
            $ok   = $code >= 200 && $code < 300;
            // Real fix: capture the provider's message ID
            // (messages[0].id in Meta's response) so an incoming delivery-
            // status webhook can find this exact row later — previously
            // nothing was captured, so 'sent' was the permanent final
            // state of every message regardless of what actually happened
            // after the API accepted it.
            $msg_id = self::extract_message_id( wp_remote_retrieve_body( $response ) );
            self::log( $to_phone, $body, $ok ? 'sent' : 'failed', $lead_id, $vendor_id, $msg_id, $ok ? '' : wp_remote_retrieve_body( $response ) );
            return $ok;
        }

        $endpoint = $bsp === 'interakt'
            ? 'https://api.interakt.ai/v1/public/message/'
            : 'https://waba.360dialog.io/v1/messages';

        $payload = [
            'messaging_product' => 'whatsapp',
            'to'                => $phone_clean,
            'type'              => 'text',
            'text'              => [ 'body' => $body ],
        ];

        $response = wp_remote_post( $endpoint, [
            'timeout' => 15,
            'headers' => [
                'D360-API-KEY'  => $api_key,
                'Authorization' => 'Basic ' . base64_encode( $api_key . ':' ),
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( $payload ),
        ] );

        if ( is_wp_error( $response ) ) {
            gs_write_log( 'WhatsAppService: send failed — ' . $response->get_error_message() );
            self::log( $to_phone, $body, 'failed', $lead_id, $vendor_id, '', $response->get_error_message() );
            return false;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $ok   = $code >= 200 && $code < 300;
        $msg_id = self::extract_message_id( wp_remote_retrieve_body( $response ) );
        self::log( $to_phone, $body, $ok ? 'sent' : 'failed', $lead_id, $vendor_id, $msg_id, $ok ? '' : wp_remote_retrieve_body( $response ) );
        return $ok;
    }

    // ── Transactional booking messages ────────────────────────────────────────

    /**
     * Send booking confirmation WhatsApp to customer and vendor.
     * Called from NotificationService::on_booking_confirmed() after in-app/push.
     * Gracefully skips if no phone number or API not configured.
     *
     * @param array $d  EventBus booking.confirmed payload
     */
    public static function send_booking_confirmed( array $d ): void {
        $platform   = Config::get( 'platform_name', 'GoodService' );
        $date       = isset( $d['booking_date'] ) ? date( 'D, d M', strtotime( $d['booking_date'] ) ) : '';
        $time       = isset( $d['booking_time'] ) ? date( 'g:i A', strtotime( $d['booking_time'] ) ) : '';
        $slot       = trim( "$date at $time" );
        $track_url  = isset( $d['tracking_token'] ) ? home_url( '/track-job/' . $d['tracking_token'] . '/' ) : '';

        // Message to customer
        if ( ! empty( $d['customer_phone'] ) ) {
            $msg = "✅ *Booking Confirmed* — {$platform}\n\n"
                 . "Hi {$d['customer_name']}, your booking with *{$d['vendor_name']}* is confirmed"
                 . ( $slot ? " for *{$slot}*" : '' ) . ".\n\n"
                 . ( $track_url ? "📍 Track your job: {$track_url}" : '' );
            // Try WhatsApp first; fall back to SMS if not configured
            if ( ! self::send_text( $d['customer_phone'], $msg ) ) {
                $sms_msg = "Booking confirmed with {$d['vendor_name']}" . ( $slot ? " for {$slot}" : '' )
                         . ( $track_url ? ". Track: {$track_url}" : '' ) . " — {$platform}";
                \GoodService\Service\OtpService::send_sms( $d['customer_phone'], $sms_msg );
            }
        }

        // Message to vendor (notify of new confirmed booking)
        if ( ! empty( $d['vendor_phone'] ?? '' ) ) {
            $msg = "📅 *New Booking* — {$platform}\n\n"
                 . "Hi, you have a new booking from *{$d['customer_name']}*"
                 . ( $slot ? " on *{$slot}*" : '' ) . ".\n\n"
                 . "Open your dashboard: " . home_url( '/vendor/dashboard/?section=bookings' );
            if ( ! self::send_text( $d['vendor_phone'], $msg ) ) {
                $sms_msg = "New booking from {$d['customer_name']}" . ( $slot ? " on {$slot}" : '' )
                         . ". Check dashboard: " . home_url( '/vendor/dashboard/?section=bookings' ) . " — {$platform}";
                \GoodService\Service\OtpService::send_sms( $d['vendor_phone'], $sms_msg );
            }
        }
    }

    /**
     * Send booking reminder WhatsApp (24h or 2h before).
     * Called from Cron::dispatch_booking_reminder().
     *
     * @param object $bk     gs_bookings row
     * @param string $window '24h' | '2h'
     */
    public static function send_booking_reminder( object $bk, string $window ): void {
        $platform  = Config::get( 'platform_name', 'GoodService' );
        $label     = $window === '24h' ? 'tomorrow' : 'in 2 hours';
        $slot      = date( 'D, d M', strtotime( $bk->booking_date ) ) . ' at ' . date( 'g:i A', strtotime( $bk->booking_time ) );
        $track_url = home_url( '/track-job/' . $bk->tracking_token . '/' );

        if ( ! empty( $bk->customer_phone ) ) {
            $msg = "⏰ *Reminder* — {$platform}\n\n"
                 . "Hi {$bk->customer_name}, your appointment is *{$label}* on *{$slot}*.\n\n"
                 . "📍 Track: {$track_url}";
            // Try WhatsApp first, fall back to SMS
            if ( ! self::send_text( $bk->customer_phone, $msg ) ) {
                $sms = "Reminder: appointment {$label} on {$slot}. Track: {$track_url} — {$platform}";
                \GoodService\Service\OtpService::send_sms( $bk->customer_phone, $sms );
            }
        }
    }

    /**
     * Send "vendor is on the way" WhatsApp to customer when job_status = travelling.
     * Called from NotificationService::on_job_status_changed().
     *
     * @param array $d  EventBus job.travelling payload (includes eta, customer_phone, vendor_name)
     */
    /**
     * Send a WhatsApp notification to the vendor when a customer inquiry is
     * confirmed (fires from AjaxController::activate_inquiry_lead(), the
     * same point where the existing vendor email notification is sent —
     * i.e. only once the inquiry has passed the email-verification hard
     * gate, matching "successfully confirmed" exactly).
     *
     * Plan-gated by the CALLER (activate_inquiry_lead), not here — this
     * method only knows how to send the message; whether the vendor's
     * current plan is entitled to it is a separate, single-purpose check
     * kept next to the other inquiry-module plan gates already in this
     * codebase, so the gate logic isn't duplicated in two unrelated files.
     *
     * @param array $d {
     *   @type int    $lead_id        Real lead ID — included in the message and the log.
     *   @type int    $vendor_id      Real vendor ID — for the log only.
     *   @type string $vendor_phone   Vendor's WhatsApp number to send to.
     *   @type string $vendor_name    Vendor business name, for the greeting.
     *   @type string $listing_title  Listing the inquiry came in on.
     *   @type string $client_name
     *   @type string $client_phone
     *   @type string $client_email
     *   @type string $client_city
     *   @type string $category_name  Service/category name (e.g. "Plumbing").
     *   @type array  $custom_fields  Every other field the customer submitted —
     *                                rendered dynamically, none omitted, exactly
     *                                mirroring build_inquiry_email()'s own
     *                                "no field left out" behaviour for email.
     * }
     */
    public static function send_inquiry_received( array $d ): void {
        $vendor_phone = trim( (string) ( $d['vendor_phone'] ?? '' ) );
        if ( ! $vendor_phone ) {
            // No registered WhatsApp number for this listing/vendor — nothing
            // to send. Logged (not just silently skipped) so a vendor on an
            // entitled plan who never receives this notification is
            // findable later, rather than the failure being invisible.
            if ( function_exists( 'gs_write_log' ) ) {
                gs_write_log(
                    'WhatsAppService::send_inquiry_received — skipped, no WhatsApp number on file for vendor_id=' . (int) ( $d['vendor_id'] ?? 0 ) . ', lead_id=' . (int) ( $d['lead_id'] ?? 0 ),
                    'INFO'
                );
            }
            return;
        }

        $platform    = Config::get( 'platform_name', 'GoodService' );
        $lead_id     = (int) ( $d['lead_id'] ?? 0 );
        $vendor_name = $d['vendor_name'] ?? 'Vendor';

        // ── Customer Details block ──────────────────────────────────────────
        $msg  = "*New Customer Inquiry Received*\n\n";
        $msg .= "Dear {$vendor_name},\n";
        $msg .= "You have received a new customer inquiry through the {$platform} Platform.\n\n";
        $msg .= "*Customer Details*\n";
        $msg .= "• Customer Name: " . ( $d['client_name']  ?: '—' ) . "\n";
        $msg .= "• Mobile Number: " . ( $d['client_phone'] ?: '—' ) . "\n";
        if ( ! empty( $d['client_email'] ) ) { $msg .= "• Email Address: {$d['client_email']}\n"; }
        if ( ! empty( $d['client_city']  ) ) { $msg .= "• City/Location: {$d['client_city']}\n"; }

        // ── Inquiry Details block ───────────────────────────────────────────
        $msg .= "\n*Inquiry Details*\n";
        if ( ! empty( $d['category_name'] ) ) { $msg .= "• Service/Category: {$d['category_name']}\n"; }
        if ( ! empty( $d['listing_title'] ) ) { $msg .= "• Listing Name: {$d['listing_title']}\n"; }

        // Every other field the customer actually submitted — dynamic, not
        // hardcoded to specific field names, so this works identically for
        // every inquiry form/category in the Inquiry Module. Mirrors
        // build_inquiry_email()'s own field-rendering loop exactly, just in
        // plain text instead of an HTML table (WhatsApp has no table support).
        $known_keys_already_shown = [ '_message', 'city' ];
        foreach ( (array) ( $d['custom_fields'] ?? [] ) as $key => $value ) {
            if ( in_array( $key, $known_keys_already_shown, true ) ) { continue; }
            $val = is_array( $value ) ? implode( ', ', array_map( 'strval', $value ) ) : trim( (string) $value );
            if ( $val === '' ) { continue; } // Don't show fields the customer left blank.
            $label = ucwords( str_replace( [ '_', '-' ], ' ', (string) $key ) );
            $msg .= "• {$label}: {$val}\n";
        }
        // The free-text "Additional Requirements/Message" field, if present,
        // is shown last and on its own line since it's typically the longest.
        if ( ! empty( $d['custom_fields']['_message'] ) ) {
            $msg .= "• Additional Requirements: " . trim( (string) $d['custom_fields']['_message'] ) . "\n";
        }

        $msg .= "\nInquiry ID: INQ-" . str_pad( (string) $lead_id, 5, '0', STR_PAD_LEFT ) . "\n";
        $msg .= "Date & Time: " . current_time( 'd M Y, h:i A' ) . "\n\n";
        $msg .= "Please contact the customer at the earliest to discuss their requirements and provide your services accordingly.\n\n";
        $msg .= "Thank you for being a valued partner of {$platform}.";

        // Real fix: send_text() now logs internally (capturing the
        // provider's message ID for delivery tracking) — previously this
        // method ALSO called log() explicitly right after, with the real
        // lead_id/vendor_id, creating two rows per vendor notification: one
        // generic (0/0, from inside send_text()) and one correct. Passing
        // the real ids straight into send_text() means there's exactly one
        // row, with the real ids AND the provider message ID both present.
        self::send_text( $vendor_phone, $msg, $lead_id, (int) ( $d['vendor_id'] ?? 0 ) );
    }

    public static function send_vendor_enroute( array $d ): void {
        if ( empty( $d['customer_phone'] ) ) { return; }
        $platform = Config::get( 'platform_name', 'GoodService' );
        $eta_text = ! empty( $d['eta'] ) ? " ETA: ~{$d['eta']} minutes." : '';
        $msg = "🚗 *On the way!* — {$platform}\n\n"
             . ( $d['vendor_name'] ?? 'Your professional' ) . " is heading to your location.{$eta_text}\n\n"
             . "📍 Track: " . home_url( '/track-job/' . ( $d['tracking_token'] ?? '' ) . '/' );
        self::send_text( $d['customer_phone'], $msg );
    }

    /**
     * Send job completed WhatsApp with review request link.
     * Called from Cron::booking_post_completion().
     *
     * @param object $bk  gs_bookings row
     */
    public static function send_job_completed( object $bk ): void {
        if ( empty( $bk->customer_phone ) ) { return; }
        $platform  = Config::get( 'platform_name', 'GoodService' );
        $review_url = home_url( '/track-job/' . $bk->tracking_token . '/?review=1' );
        $msg = "🎉 *Job Complete!* — {$platform}\n\n"
             . "Hi {$bk->customer_name}, your job with *" . ( $bk->listing_title ?: 'your professional' ) . "* is done.\n\n"
             . "⭐ Leave a review: {$review_url}";
        self::send_text( $bk->customer_phone, $msg );
    }

    /**
     * Send booking cancellation WhatsApp to the affected customer.
     * Called from NotificationService::on_booking_cancelled().
     *
     * @param array $d  EventBus booking.cancelled payload
     */
    public static function send_booking_cancelled( array $d ): void {
        if ( empty( $d['customer_phone'] ) ) { return; }
        $platform = Config::get( 'platform_name', 'GoodService' );
        $msg = "❌ *Booking Cancelled* — {$platform}\n\n"
             . "Hi " . ( $d['customer_name'] ?? '' ) . ", your booking with *" . ( $d['vendor_name'] ?? 'the vendor' ) . "* has been cancelled.\n\n"
             . "If this wasn't expected, you can reach out via your dashboard or browse other professionals: " . home_url( '/directory/' );
        self::send_text( $d['customer_phone'], $msg );
    }

    /**
     * Send WhatsApp to the customer once a vendor has accepted ('won') or
     * declined ('lost') their inquiry. Called from
     * NotificationService::on_lead_status_decided().
     *
     * @param array $d  EventBus lead.status_decided payload (status: 'won'|'lost')
     */
    public static function send_lead_status_decided( array $d ): void {
        if ( empty( $d['customer_phone'] ) ) { return; }
        $platform = Config::get( 'platform_name', 'GoodService' );
        $won      = ( $d['status'] ?? '' ) === 'won';
        $vendor   = $d['vendor_name'] ?? 'The vendor';
        $msg = $won
            ? "✅ *Inquiry Accepted* — {$platform}\n\nHi " . ( $d['customer_name'] ?? '' ) . ", *{$vendor}* has accepted your inquiry and will be in touch shortly."
            : "*Inquiry Update* — {$platform}\n\nHi " . ( $d['customer_name'] ?? '' ) . ", *{$vendor}* is unable to take on your inquiry right now. You can browse other professionals here: " . home_url( '/directory/' );
        self::send_text( $d['customer_phone'], $msg );
    }

    /**
     * Send an inquiry-received acknowledgement WhatsApp to the CUSTOMER
     * (distinct from send_inquiry_received(), which notifies the vendor).
     * Real fix — Audit Section D gap: on_lead_created() already emails the
     * client a confirmation, but never sent one over WhatsApp even when
     * the client provided a phone number and WhatsApp is configured.
     * Called from NotificationService::on_lead_created().
     *
     * @param array $d  EventBus lead.created payload
     */
    public static function send_inquiry_acknowledgement( array $d ): void {
        if ( empty( $d['customer_phone'] ) ) { return; }
        $platform = Config::get( 'platform_name', 'GoodService' );
        $lead_id  = (int) ( $d['lead_id'] ?? 0 );
        $msg = "✅ *Inquiry Sent* — {$platform}\n\n"
             . "Hi " . ( $d['name'] ?? '' ) . ", your inquiry to *" . ( $d['listing_title'] ?? 'the vendor' ) . "* has been received.\n\n"
             . "Reference: #INQ-" . str_pad( (string) $lead_id, 5, '0', STR_PAD_LEFT ) . "\n"
             . "You'll be notified as soon as they reply. Track it here: " . home_url( '/my-account/?section=inquiries' );
        self::send_text( $d['customer_phone'], $msg );
    }

    // ── Logging ───────────────────────────────────────────────────────────────

    /** Log a WhatsApp send attempt to gs_whatsapp_logs. */
    private static function log( string $phone, string $body, string $status, int $lead_id = 0, int $vendor_id = 0, string $provider_message_id = '', string $error_message = '' ): void {
        global $wpdb;
        $tbl = $wpdb->prefix . 'gs_whatsapp_logs';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) { return; }
        $wpdb->insert( $tbl, [
            'lead_id'             => $lead_id,   // 0 for platform-sent transactional messages not tied to a specific lead
            'vendor_id'           => $vendor_id, // 0 for platform-sent transactional messages
            'direction'           => 'outbound',
            'phone'               => preg_replace( '/\D/', '', $phone ),
            'body'                => substr( $body, 0, 1000 ),
            'status'              => $status,
            'provider_message_id' => substr( $provider_message_id, 0, 128 ),
            'error_message'       => substr( $error_message, 0, 500 ),
            'sent_at'             => current_time( 'mysql' ),
            'created_at'          => current_time( 'mysql' ),
        ] );
    }

    /**
     * Extracts the provider's message ID from a send response body, so a
     * later delivery-status webhook can find the matching log row. Meta
     * Cloud API and 360dialog both return {"messages":[{"id":"wamid...."}]}
     * on success; Interakt's shape differs slightly (top-level "id" or
     * "messageId" depending on endpoint version) — checked as a fallback
     * rather than assumed, since guessing wrong here just means delivery
     * status silently never updates for that provider, not a hard error.
     */
    private static function extract_message_id( string $response_body ): string {
        $data = json_decode( $response_body, true );
        if ( ! is_array( $data ) ) { return ''; }
        if ( ! empty( $data['messages'][0]['id'] ) ) { return (string) $data['messages'][0]['id']; }
        if ( ! empty( $data['id'] ) )                { return (string) $data['id']; }
        if ( ! empty( $data['messageId'] ) )          { return (string) $data['messageId']; }
        return '';
    }
}
