<?php
namespace GoodService\Service;

/**
 * ImageOptimizer — GoodService Platform
 *
 * AVIF-ONLY pipeline (real fix — replaces the previous WebP-primary +
 * AVIF-sidecar design, which never actually satisfied "AVIF only, original
 * deleted, no duplicate formats": that design kept the original file
 * (renamed _orig, never deleted), stored WebP as the file every DB URL
 * pointed to, and only added AVIF as an extra alongside file, delivered by
 * ImageDelivery's <picture>-wrapping — meaning three files existed per
 * image (original + webp + avif) and Media Library / DB URLs referenced
 * WebP, never AVIF.
 *
 * Pipeline per upload, on EVERY upload entry point in this plugin (the
 * unified gs_upload_media AJAX action used for vendor logos/banners/
 * galleries/listing images/forms/drag-and-drop, native WP Media Library
 * uploads, and the WP REST API media endpoint — all three call WordPress's
 * own wp_handle_upload() internally, which is where this hooks in; also
 * hooked on wp_handle_sideload for any future bulk-import-by-URL feature):
 *
 *  1. Convert the uploaded file DIRECTLY to AVIF (resize to max dimension,
 *     auto-orient, preserve alpha) — AVIF is the only file ever written.
 *  2. On success: delete the original upload immediately. $upload['file'],
 *     ['url'], and ['type'] are rewritten to the .avif file BEFORE
 *     wp_insert_attachment() runs, so the Media Library attachment itself
 *     — post_mime_type, _wp_attached_file, and every generated thumbnail
 *     size — is AVIF from the moment it's created. No sidecar, no second
 *     format, nothing left over to clean up.
 *  3. On failure (server has no AVIF encoder available, or encoding this
 *     specific file failed) — the ONLY case where a non-AVIF file is
 *     allowed to remain, per explicit requirement — the original is left
 *     untouched and logged, so the upload doesn't fail outright.
 *
 * Quality settings (filterable or via wp-config.php constants):
 *   GS_IMG_AVIF_QUALITY   default 72   (AVIF is very efficient at this level)
 *   GS_IMG_STRIP_META     default false (EXIF preserved — opt-in to strip)
 *   GS_IMG_MAX_DIMENSION  default 0     (0 = no cap; set e.g. 2400 to cap all images)
 *
 * One explicit, intentional exception: PWA manifest icons
 * (uploadPwaIcon() in AjaxController, assets/pwa/*.png) are written
 * directly to fixed paths referenced by the web app manifest and are NOT
 * routed through this optimizer. AVIF is not a supported manifest icon
 * format in current Android/iOS "Add to Home Screen" installers — encoding
 * these as AVIF would silently break PWA installability. This is the one
 * deliberate carve-out; every other image upload path in the plugin goes
 * through AVIF conversion.
 *
 * Existing content uploaded under the old WebP-primary design (original +
 * .webp + .avif sidecar all on disk) is NOT silently rewritten by this
 * change — only NEW uploads use the new AVIF-only path. Migrating already-
 * stored files is a deliberate, admin-triggered action
 * (see migrate_existing_to_avif_only() / the admin Image Optimization
 * panel), not something this plugin does automatically to live URLs that
 * may already be cached, indexed, or linked externally.
 */
final class ImageOptimizer {

    private const DEFAULT_WEBP_QUALITY = 88;
    private const DEFAULT_AVIF_QUALITY = 72;
    private const DEFAULT_JPEG_QUALITY = 88;
    private const LOSSLESS_QUALITY     = 100;
    // Real fix — confirmed contributing to slow page loads: this used to
    // default to 0 (uncapped), meaning a 4000x3000 phone photo got
    // converted to AVIF at full resolution — still a genuinely large
    // download and decode even with efficient compression, especially
    // across a gallery of several such images on one page. No on-screen
    // use on this platform (hero banners included) needs more than this;
    // still fully overridable via the gs_optimizer_max_dimension filter.
    private const DEFAULT_MAX_DIMENSION = 2400;

    // ── Boot ──────────────────────────────────────────────────────────────────

    public static function register(): void {
        add_filter( 'wp_handle_upload',               [ self::class, 'handle_upload'      ], 20, 2 );
        // Real fix: wp_handle_sideload() (used by any bulk-import-by-URL /
        // "import from external source" feature) fires its OWN filter,
        // 'wp_handle_sideload' — NOT 'wp_handle_upload'. Registering only
        // the upload filter left sideloaded images as a genuine, silent
        // bypass of AVIF conversion. Same handler works for both since it
        // only looks at the $upload array shape, which is identical.
        add_filter( 'wp_handle_sideload',              [ self::class, 'handle_upload'      ], 20, 2 );
        add_filter( 'wp_generate_attachment_metadata', [ self::class, 'optimise_all_sizes' ], 20, 2 );
        add_filter( 'upload_mimes',                   [ self::class, 'allow_modern_mimes' ]         );
        add_filter( 'jpeg_quality',                   [ self::class, 'jpeg_quality'       ], 99     );
        add_filter( 'wp_editor_set_quality',          [ self::class, 'editor_quality'     ], 99     );

        // Real fix — Media Library grid/list view showing broken/missing
        // thumbnails for AVIF attachments, while the frontend (which reads
        // the full-size file directly via the stored URL, never through
        // this validation gate) renders correctly: WordPress core decides
        // whether a file is "displayable" — and therefore whether to even
        // attempt building responsive subsizes / exposing thumbnail data
        // to the JS-based Grid View — using file_is_displayable_image(),
        // which relies on PHP's own getimagesize() to identify the file
        // type from its raw bytes. getimagesize()'s AVIF detection (added
        // in PHP 8.1) uses a narrow internal signature check that doesn't
        // recognize every valid AVIF container structure — notably,
        // several real-world AVIF encoders (including Imagick's own
        // output in some configurations) produce files getimagesize()
        // fails to identify as AVIF at all, even though they're 100%
        // valid and decode correctly everywhere else (browsers, Imagick,
        // GD). When that identification fails, WordPress treats the file
        // as "not displayable" — it may skip generating subsizes
        // entirely, and the admin JS grid has nothing to render a
        // thumbnail from. Since every AVIF file this plugin has ever
        // produced was itself generated and verified by this same
        // server's Imagick/GD (see convert_to_avif()), there's no
        // question of whether it's genuinely valid — this simply trusts
        // that already-established fact instead of PHP's fragile
        // signature sniffing.
        add_filter( 'file_is_displayable_image', [ self::class, 'trust_avif_as_displayable' ], 10, 2 );

        // Defensive second gate: even with the above fixed, WordPress
        // separately checks whether the active image editor (Imagick/GD)
        // *claims* to support a mime type before attempting to generate
        // subsizes from it — WP_Image_Editor_Imagick's own support check
        // can be stricter than what Imagick can actually do on a given
        // build. Forces 'true' specifically for image/avif, consistent
        // with file_is_displayable_image() above — both gates have to
        // agree a file is usable, or WordPress falls back to treating it
        // as undisplayable regardless of which one blocked it.
        add_filter( 'wp_image_editor_supports', [ self::class, 'trust_avif_editor_support' ], 10, 2 );
    }

    // ── wp_handle_upload / wp_handle_sideload ───────────────────────────────────

    public static function handle_upload( array $upload, string $context ): array {
        if ( ! self::is_image( $upload['type'] ?? '' ) ) return $upload;

        $src_path = $upload['file'] ?? '';
        if ( ! $src_path || ! file_exists( $src_path ) ) return $upload;

        $src_mime = $upload['type'];

        // Already AVIF — nothing to do.
        if ( $src_mime === 'image/avif' ) return $upload;

        // Real fix: if this server genuinely cannot encode AVIF at all
        // (no Imagick AVIF support, no GD imageavif()), don't even attempt
        // conversion — leave the original exactly as uploaded. This is the
        // one explicit, documented exception: "unless AVIF conversion
        // fails." Previously this case fell through to WebP conversion
        // instead, which is no longer correct — WebP is not the fallback
        // format here, "leave the original alone" is.
        if ( ! self::avif_supported() ) {
            error_log( '[GoodService ImageOptimizer] AVIF not supported on this server (no Imagick AVIF / GD imageavif) — leaving original file: ' . basename( $src_path ) );
            return $upload;
        }

        try {
            $dest_path = self::avif_path_from( $src_path );
            $ok = self::convert_to_avif( $src_path, $src_mime, $dest_path );

            if ( $ok && file_exists( $dest_path ) && filesize( $dest_path ) > 0 ) {
                // Success — AVIF is now the ONLY file. Delete the original
                // immediately; no _orig backup is kept, matching "no
                // duplicate image formats should remain in storage."
                @unlink( $src_path );

                $upload['file'] = $dest_path;
                $upload['url']  = self::path_to_url( $dest_path );
                $upload['type'] = 'image/avif';
            } else {
                // Conversion genuinely failed for this file (corrupt
                // source, unsupported edge case, etc.) — the explicit
                // exception case. Original stays exactly as uploaded.
                error_log( '[GoodService ImageOptimizer] AVIF conversion failed for ' . basename( $src_path ) . ' — original file kept.' );
                if ( file_exists( $dest_path ) ) { @unlink( $dest_path ); } // clean up any partial output
            }
        } catch ( \Throwable $e ) {
            error_log( '[GoodService ImageOptimizer] handle_upload failed: ' . $e->getMessage() );
        }

        return $upload;
    }

    // ── wp_generate_attachment_metadata ──────────────────────────────────────

    public static function optimise_all_sizes( array $metadata, int $attachment_id ): array {
        $upload_dir = wp_upload_dir();
        $base_dir   = trailingslashit( $upload_dir['basedir'] );
        $sub_dir    = '';

        if ( ! empty( $metadata['file'] ) ) {
            $sub_dir = trailingslashit( dirname( $metadata['file'] ) );
        }

        // Real fix — confirmed by a live example: a "-scaled" file
        // (trust-documentation-services-image-...-scaled.webp). WordPress
        // core's own "Big Image Size Threshold" feature (any upload over
        // 2560px in either dimension) runs INSIDE wp_generate_attachment_metadata()
        // — after handle_upload() has already converted the raw upload
        // to AVIF, but before this filter receives the resulting
        // metadata. Core creates a resized "-scaled" copy and REPLACES
        // metadata['file'] with it; on this server that resize is being
        // saved back out in a non-AVIF format (WebP), and — critically —
        // metadata['file'] (the attachment's own current main file) was
        // never covered by the loop below, which only ever walks
        // metadata['sizes'] (the thumbnail/medium/large crops). A "-scaled"
        // main file could silently stay non-AVIF forever with no code
        // path that would ever catch or convert it. Handling metadata['file']
        // explicitly, the same way, closes that gap regardless of why
        // core chose a different format for it.
        if ( ! empty( $metadata['file'] ) ) {
            $main_file = $base_dir . $metadata['file'];
            if ( file_exists( $main_file ) ) {
                $main_mime = self::mime_from_path( $main_file );
                if ( $main_mime !== 'image/avif' && self::is_image( $main_mime ) && self::avif_supported() ) {
                    try {
                        $dest_path = self::avif_path_from( $main_file );
                        $ok = self::convert_to_avif( $main_file, $main_mime, $dest_path );
                        if ( $ok && file_exists( $dest_path ) && filesize( $dest_path ) > 0 ) {
                            $meta_dirname = dirname( $metadata['file'] );
                            $metadata['file'] = ( $meta_dirname === '.' ? '' : $meta_dirname . '/' ) . basename( $dest_path );
                            @unlink( $main_file );
                        } else {
                            error_log( '[GoodService ImageOptimizer] AVIF conversion failed for main/scaled file ' . basename( $main_file ) . ' — original kept.' );
                            if ( file_exists( $dest_path ) ) { @unlink( $dest_path ); }
                        }
                    } catch ( \Throwable $e ) {
                        error_log( '[GoodService ImageOptimizer] optimise_all_sizes (main file) failed: ' . $e->getMessage() );
                    }
                }
            }
        }

        if ( empty( $metadata['sizes'] ) ) return $metadata;

        foreach ( $metadata['sizes'] as $size_name => &$size_data ) {
            $size_file = $base_dir . $sub_dir . ( $size_data['file'] ?? '' );
            if ( ! file_exists( $size_file ) ) continue;

            $mime = $size_data['mime-type'] ?? self::mime_from_path( $size_file );

            // Already AVIF — nothing to do for this size.
            if ( $mime === 'image/avif' ) continue;

            if ( ! self::is_image( $mime ) ) continue;

            // Same exception as handle_upload(): if this server can't
            // encode AVIF at all, leave every generated size exactly as
            // WordPress produced it rather than attempting conversion.
            if ( ! self::avif_supported() ) continue;

            try {
                $dest_path = self::avif_path_from( $size_file );
                $ok = self::convert_to_avif( $size_file, $mime, $dest_path );

                if ( $ok && file_exists( $dest_path ) && filesize( $dest_path ) > 0 ) {
                    $size_data['file']      = basename( $dest_path );
                    $size_data['mime-type'] = 'image/avif';
                    // Real fix: this used to leave the pre-conversion size
                    // file (jpg/png/webp) on disk permanently alongside the
                    // new one — every thumbnail size existed twice. AVIF is
                    // now the only file for this size.
                    @unlink( $size_file );
                } else {
                    error_log( '[GoodService ImageOptimizer] AVIF conversion failed for size "' . $size_name . '" of ' . basename( $size_file ) . ' — original size file kept.' );
                    if ( file_exists( $dest_path ) ) { @unlink( $dest_path ); }
                }
            } catch ( \Throwable $e ) {
                error_log( '[GoodService ImageOptimizer] optimise_all_sizes failed: ' . $e->getMessage() );
            }
        }
        unset( $size_data );

        return $metadata;
    }

    // ── AVIF sidecar generator ────────────────────────────────────────────────

    /**
     * Generates an AVIF file alongside any existing image.
     * Naming: image.webp → image.avif  |  image.jpg → image.avif
     * Safe to call multiple times — skips if AVIF already exists and is non-empty.
     *
     * @param  string $src_path Absolute path to source image (WebP, JPG, PNG, etc.)
     * @return bool   True if AVIF was generated (or already existed), false on failure.
     */
    public static function generate_avif_sidecar( string $src_path ): bool {
        if ( ! file_exists( $src_path ) ) return false;

        if ( strtolower( pathinfo( $src_path, PATHINFO_EXTENSION ) ) === 'avif' ) return true;

        $avif_path = self::avif_path_from( $src_path );

        if ( file_exists( $avif_path ) && filesize( $avif_path ) > 0 ) return true;

        // ── PREFER ORIGINAL SOURCE FOR AVIF GENERATION ─────────────────────────
        // When src_path is a WebP (our conversion result), prefer the _orig PNG/JPG
        // for AVIF generation.
        //
        // ROOT CAUSE of transparency bug:
        // Imagick::getImageAlphaChannel() returns 0 (false) for WebP files that have
        // alpha, on certain libwebp builds. This caused ALPHACHANNEL_ACTIVATE to be
        // skipped, writing an opaque AVIF. Transparent logos appeared with background.
        //
        // GD: imagecreatefromwebp() on some PHP builds silently loses alpha in the
        // returned GdImage before imageavif() even runs.
        //
        // PNG->AVIF alpha works reliably in all Imagick/GD versions.
        // Using the original PNG as AVIF source guarantees correct transparency.
        $best_source = $src_path;
        $src_no_ext  = preg_replace( '/\.[a-z0-9]+$/i', '', $src_path );
        foreach ( [ 'png', 'gif', 'jpg', 'jpeg' ] as $_ext ) {
            $_candidate = $src_no_ext . '_orig.' . $_ext;
            if ( file_exists( $_candidate ) && filesize( $_candidate ) > 0 ) {
                $best_source = $_candidate;
                break;
            }
        }

        $src_mime       = self::mime_from_path( $best_source );
        $quality        = (int) apply_filters( 'gs_optimizer_avif_quality', self::DEFAULT_AVIF_QUALITY );
        $quality        = max( 1, min( 100, $quality ) );
        $may_have_alpha = in_array( $src_mime, [ 'image/png', 'image/gif', 'image/webp', 'image/avif' ], true );

        // ── Try ImageMagick ───────────────────────────────────────────────────
        if ( extension_loaded( 'imagick' ) ) {
            try {
                if ( ! empty( \Imagick::queryFormats( 'AVIF' ) ) ) {
                    $im = new \Imagick( $best_source );

                    if ( $may_have_alpha ) {
                        // ALPHACHANNEL_ON explicitly enables alpha in output — safer than
                        // ALPHACHANNEL_ACTIVATE which only activates if Imagick detected one.
                        // Imagick misdetects alpha=0 for WebP on many server builds.
                        $im->setImageAlphaChannel( \Imagick::ALPHACHANNEL_ON );
                    } elseif ( $src_mime === 'image/jpeg' ) {
                        $im->setImageColorspace( \Imagick::COLORSPACE_SRGB );
                    }

                    $im->setImageFormat( 'avif' );
                    $im->setImageCompressionQuality( $quality );
                    $im->setOption( 'avif:speed', '6' );

                    $strip = (bool) apply_filters( 'gs_optimizer_strip_metadata', false );
                    if ( $strip ) $im->stripImage();

                    $im->writeImage( $avif_path );
                    $im->clear();
                    $im->destroy();

                    if ( file_exists( $avif_path ) && filesize( $avif_path ) > 0 ) {
                        self::log_avif_savings( $best_source, $avif_path );
                        return true;
                    }
                }
            } catch ( \Throwable $e ) {
                error_log( '[GoodService ImageOptimizer] AVIF/Imagick failed: ' . $e->getMessage() );
            }
        }

        // ── Try GD (PHP 8.1+ with AVIF compiled in) ───────────────────────────
        if ( function_exists( 'imageavif' ) ) {
            try {
                $img = self::gd_open( $best_source, $src_mime );
                if ( $img ) {
                    if ( $may_have_alpha ) {
                        imagealphablending( $img, false );
                        imagesavealpha( $img, true );
                    }
                    imageavif( $img, $avif_path, $quality );
                    imagedestroy( $img );

                    if ( file_exists( $avif_path ) && filesize( $avif_path ) > 0 ) {
                        self::log_avif_savings( $best_source, $avif_path );
                        return true;
                    }
                }
            } catch ( \Throwable $e ) {
                error_log( '[GoodService ImageOptimizer] AVIF/GD failed: ' . $e->getMessage() );
            }
        }

        return false;
    }


    /**
     * Check whether this server can generate AVIF files.
     */
    public static function avif_supported(): bool {
        if ( function_exists( 'imageavif' ) ) return true;
        if ( extension_loaded( 'imagick' ) ) {
            try {
                return ! empty( \Imagick::queryFormats( 'AVIF' ) );
            } catch ( \Throwable $e ) {}
        }
        return false;
    }

    /**
     * Given any image path, return the expected AVIF sidecar path.
     * image.webp → image.avif
     * image.jpg  → image.avif
     */
    public static function avif_path_from( string $path ): string {
        return preg_replace( '/\.[a-z0-9]+$/i', '.avif', $path );
    }

    /**
     * Given any image URL, return the expected AVIF sidecar URL.
     */
    public static function avif_url_from( string $url ): string {
        return preg_replace( '/\.[a-z0-9]+$/i', '.avif', $url );
    }

    // ── Bulk converter — called from AJAX / admin tool ────────────────────────

    /**
     * Find all WebP files in uploads that don't have an AVIF sidecar yet.
     * Returns [ 'converted' => N, 'skipped' => N, 'failed' => N, 'remaining' => N ]
     *
     * @param int $batch Maximum files to process in this call (default 20).
     */

    /**
     * Rewrites every stored reference to an image file so it points at
     * its AVIF replacement instead — the piece that makes it actually
     * safe to delete a "main" image file a WordPress attachment or a
     * plugin table/JSON field still points at.
     *
     * Matches by BASENAME (the filename itself — e.g.
     * "trust-documentation-services-image-92501674o8W9-scaled.webp"),
     * not by full URL. This is the actual root-cause fix for a real,
     * confirmed failure: the original version matched on the full URL
     * computed via wp_upload_dir(), which returns the WordPress origin
     * domain — but on a site with a CDN or URL-rewriting layer, the
     * URL actually STORED in the database can use a different domain
     * (e.g. https://site.cdn-provider.com/... instead of the origin
     * URL), so the exact-URL match silently updated zero rows every
     * time, while the file was deleted regardless — the exact bug that
     * produced broken images with no error anywhere. Every filename
     * this plugin generates includes a random unique component (see
     * uploadMedia()'s $gs_rename_filter), so matching on basename alone
     * is safe — it can't collide with an unrelated file — and works no
     * matter what domain, protocol, or CDN rewriting sits between the
     * database and the file, because it never has to guess or
     * reconstruct that domain at all.
     *
     * Covers three kinds of storage:
     *  1. Every gs_-prefixed plugin table's TEXT/VARCHAR/LONGTEXT columns
     *     (discovered dynamically via INFORMATION_SCHEMA — covers
     *     logo_url/banner_url plus every JSON blob that can carry a
     *     nested image URL).
     *  2. wp_posts.guid + post_mime_type, for the matching attachment.
     *  3. wp_postmeta: _wp_attached_file, and _wp_attachment_metadata
     *     (PHP-serialized — NEVER blind-replaced, since substring
     *     replacement changes string length while the serialized
     *     format's s:N:"..." length prefix stays stale, corrupting the
     *     structure; unserialized, walked recursively, re-serialized
     *     instead).
     *
     * Returns the total number of rows changed across all of the above.
     * A return of 0 means NOTHING referenced this file anywhere this
     * function can see — the caller must treat that as "do not delete",
     * not as "safe to delete, nothing to update".
     */
    public static function rewrite_url_references( string $old_url, string $new_url ): int {
        global $wpdb;
        if ( $old_url === '' || $old_url === $new_url ) return 0;

        $old_basename = basename( $old_url );
        $new_basename = basename( $new_url );
        if ( $old_basename === '' || $old_basename === $new_basename ) return 0;

        $rows_changed = 0;

        // ── 1. Plugin tables (gs_-prefixed), every text-family column ──────────
        $tables = $wpdb->get_col( $wpdb->prepare(
            "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA = %s AND TABLE_NAME LIKE %s",
            DB_NAME, $wpdb->esc_like( $wpdb->prefix . 'gs_' ) . '%'
        ) );

        foreach ( $tables as $table ) {
            $cols = $wpdb->get_col( $wpdb->prepare(
                "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s
                   AND DATA_TYPE IN ('text','mediumtext','longtext','varchar','char')",
                DB_NAME, $table
            ) );
            foreach ( $cols as $col ) {
                // Real, safe SQL identifier — $table/$col come only from
                // INFORMATION_SCHEMA above, never from user input, so
                // backtick-quoting them directly (they can't be
                // parameterised as identifiers) is safe here.
                $sql = "UPDATE `{$table}` SET `{$col}` = REPLACE(`{$col}`, %s, %s) WHERE `{$col}` LIKE %s";
                $affected = $wpdb->query( $wpdb->prepare( $sql, $old_basename, $new_basename, '%' . $wpdb->esc_like( $old_basename ) . '%' ) );
                if ( $affected ) { $rows_changed += (int) $affected; }
            }
        }

        // ── 2. WordPress attachment — guid, post_mime_type, _wp_attached_file,
        // _wp_attachment_metadata — ALL keyed off the SAME attachment lookup,
        // found by basename (LIKE), never an exact full-path/URL match. ────────
        $attachment_id = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta}
             WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s LIMIT 1",
            '%' . $wpdb->esc_like( $old_basename )
        ) );

        // Fallback: guid, by basename, in case _wp_attached_file is
        // somehow missing but guid still carries the old filename.
        if ( ! $attachment_id ) {
            $attachment_id = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE guid LIKE %s AND post_type = 'attachment' LIMIT 1",
                '%' . $wpdb->esc_like( $old_basename )
            ) );
        }

        if ( $attachment_id ) {
            // Rebuild guid/_wp_attached_file from whatever is ACTUALLY
            // stored right now (basename swapped in place), instead of
            // assuming the origin-computed $new_url's domain/path is
            // correct — preserves the real stored domain and directory
            // exactly, whatever it is.
            $current_guid = $wpdb->get_var( $wpdb->prepare( "SELECT guid FROM {$wpdb->posts} WHERE ID = %d", $attachment_id ) );
            $new_guid     = $current_guid ? str_replace( $old_basename, $new_basename, $current_guid ) : $new_url;

            $affected = $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->posts} SET guid = %s, post_mime_type = 'image/avif' WHERE ID = %d",
                $new_guid, $attachment_id
            ) );
            if ( $affected ) { $rows_changed += (int) $affected; }

            $current_attached_file = get_post_meta( $attachment_id, '_wp_attached_file', true );
            $new_attached_file = $current_attached_file
                ? str_replace( $old_basename, $new_basename, $current_attached_file )
                : $new_basename;
            update_post_meta( $attachment_id, '_wp_attached_file', $new_attached_file );
            $rows_changed++;

            // ── _wp_attachment_metadata — PHP-serialized, must be
            // unserialized/walked/re-serialized, never string-replaced. ──
            $meta = get_post_meta( $attachment_id, '_wp_attachment_metadata', true );
            if ( is_array( $meta ) ) {
                $meta = self::rewrite_metadata_array( $meta, $old_basename, $new_basename );
                // Real fix — confirmed by a live example: Media Library's
                // "File size" field does NOT re-stat the file on disk. It
                // reads the cached byte count WordPress stored in
                // _wp_attachment_metadata['filesize'] (and per-size in
                // sizes.*.filesize) at original upload time — see
                // wp_prepare_attachment_for_js() in WP core, which prefers
                // that cached number over a live filesize() call whenever
                // it's present. rewrite_metadata_array() above only
                // renames the filenames inside that metadata to .avif; it
                // never touched the byte-count fields, so they kept
                // showing the old, larger, pre-conversion size forever —
                // correct filename, correct mime type, stale size.
                $meta = self::refresh_metadata_filesizes( $meta );
                update_post_meta( $attachment_id, '_wp_attachment_metadata', $meta );
                $rows_changed++;
            }
        }

        return $rows_changed;
    }

    /**
     * Recalculates every cached byte-count in an attachment metadata
     * array — the top-level 'filesize' (main file) and each entry's
     * sizes.*.filesize (thumbnail/responsive sizes) — from the REAL file
     * on disk at the path that entry's 'file' now points to. Call this
     * any time a file referenced by this metadata has actually changed
     * size (AVIF conversion, or any future re-encode), immediately after
     * renaming the paths themselves — a stale filename with a correct
     * size, or a correct filename with a stale size, are both wrong.
     */
    private static function refresh_metadata_filesizes( array $meta ): array {
        $upload_dir = wp_upload_dir();
        $base_dir   = trailingslashit( $upload_dir['basedir'] );
        $sub_dir    = ! empty( $meta['file'] ) ? trailingslashit( dirname( $meta['file'] ) ) : '';

        if ( ! empty( $meta['file'] ) ) {
            $main_path = $base_dir . $meta['file'];
            if ( file_exists( $main_path ) ) {
                $meta['filesize'] = filesize( $main_path );
            }
        }

        if ( ! empty( $meta['sizes'] ) && is_array( $meta['sizes'] ) ) {
            foreach ( $meta['sizes'] as $size_name => &$size_data ) {
                if ( empty( $size_data['file'] ) ) continue;
                $size_path = $base_dir . $sub_dir . $size_data['file'];
                if ( file_exists( $size_path ) ) {
                    $size_data['filesize'] = filesize( $size_path );
                }
            }
            unset( $size_data );
        }

        return $meta;
    }

    /**
     * Recursively replaces a basename (e.g. "logo.webp") with a new one
     * (e.g. "logo.avif") anywhere it appears as a string value inside a
     * PHP array — used on an already-unserialized _wp_attachment_metadata
     * array (WordPress's get_post_meta()/update_post_meta() handle the
     * serialize/unserialize themselves; this function only ever touches
     * the in-memory array, never a raw serialized string).
     */
    private static function rewrite_metadata_array( array $data, string $old_basename, string $new_basename ): array {
        foreach ( $data as $key => $value ) {
            if ( is_array( $value ) ) {
                $data[ $key ] = self::rewrite_metadata_array( $value, $old_basename, $new_basename );
            } elseif ( is_string( $value ) && str_contains( $value, $old_basename ) ) {
                $data[ $key ] = str_replace( $old_basename, $new_basename, $value );
            }
        }
        return $data;
    }

    /**
     * Real fix — the FULL "no duplicate formats, AVIF only" migration for
     * content uploaded before this fix, under the old WebP-primary +
     * AVIF-sidecar + _orig-backup design. handle_upload()/optimise_all_sizes()
     * above only change behavior for NEW uploads going forward; this is
     * what closes the gap for everything already on disk.
     *
     * Per file basename:
     *   1. Generate the .avif if it doesn't exist yet (same alpha-safe
     *      source-preference logic as generate_avif_sidecar()).
     *   2. Rewrite every stored reference to the "main" file's URL —
     *      vendor logo_url/banner_url, gallery JSON, any other plugin
     *      table/JSON field, and the WordPress attachment itself (guid,
     *      _wp_attached_file, _wp_attachment_metadata) — to point at the
     *      new .avif URL instead, via rewrite_url_references() above.
     *   3. Only once that rewrite has actually run does it delete the
     *      _orig backup AND the now-unreferenced "main" file. Order
     *      matters: URLs are repointed before anything is deleted, so
     *      there's never a window where a stored URL points at a file
     *      that no longer exists.
     *
     * A file that can't be converted, or a rewrite that touches zero rows
     * (meaning this image genuinely isn't referenced anywhere obvious,
     * e.g. an orphaned upload) still gets its main file kept — deletion
     * only proceeds once conversion succeeded, which is the same safety
     * rule this function has always followed for _orig.
     */
    public static function migrate_existing_to_avif_only( int $batch = 20 ): array {
        $upload_dir = wp_upload_dir();
        $base_dir   = $upload_dir['basedir'];

        $groups = self::find_legacy_format_groups( $base_dir, $batch + 1 );

        $converted      = 0;
        $already_avif   = 0;
        $failed         = 0;
        $bytes_freed    = 0;
        $urls_rewritten = 0;
        $not_referenced = 0;
        $remaining      = 0;

        if ( count( $groups ) > $batch ) {
            $remaining = count( $groups ) - $batch;
            $groups    = array_slice( $groups, 0, $batch );
        }

        foreach ( $groups as $group ) {
            $avif_path = $group['avif'];
            $has_avif  = $avif_path && file_exists( $avif_path ) && filesize( $avif_path ) > 0;

            if ( ! $has_avif ) {
                // Prefer the original/highest-quality source over the
                // WebP copy for the same alpha-transparency reason
                // documented in generate_avif_sidecar().
                $source = $group['orig'] ?: ( $group['main'] ?: null );
                if ( ! $source ) { $failed++; continue; }
                $ok = self::generate_avif_sidecar( $source );
                if ( ! $ok ) { $failed++; continue; }
                $avif_path = self::avif_path_from( $source );
                $has_avif  = file_exists( $avif_path ) && filesize( $avif_path ) > 0;
                if ( ! $has_avif ) { $failed++; continue; }
                $converted++;
            } else {
                $already_avif++;
            }

            // AVIF confirmed on disk. _orig is always safe to delete —
            // it was never a stored URL. The "main" file (.webp or
            // original) IS what's stored everywhere, so its URL is
            // rewritten to point at the new .avif FIRST, and only
            // deleted once that rewrite has actually run — never the
            // other way round.
            if ( $group['orig'] && file_exists( $group['orig'] ) ) {
                $bytes_freed += filesize( $group['orig'] );
                @unlink( $group['orig'] );
            }

            if ( $group['main'] && file_exists( $group['main'] ) ) {
                $old_url = self::path_to_url( $group['main'] );
                $new_url = self::path_to_url( $avif_path );
                $changed = self::rewrite_url_references( $old_url, $new_url );

                // Real fix — the actual bug that caused broken images:
                // this used to delete the main file unconditionally,
                // regardless of whether the rewrite above found anything
                // to update. On a site where the URL stored in the
                // database uses a different domain than wp_upload_dir()
                // computes (a CDN, in the confirmed case this was found
                // from), rewrite_url_references() would silently update
                // zero rows — no error, no warning — and the file got
                // deleted anyway, leaving every stored reference pointing
                // at a file that no longer existed. $changed === 0 now
                // means "keep the file, something still points at it
                // that this function couldn't find or update" — the same
                // safety rule already applied to _orig, just enforced
                // for real this time.
                if ( $changed > 0 ) {
                    $urls_rewritten += $changed;
                    $bytes_freed    += filesize( $group['main'] );
                    @unlink( $group['main'] );
                } else {
                    $not_referenced++;
                    error_log( '[GoodService ImageOptimizer] migrate_existing_to_avif_only: kept ' . basename( $group['main'] ) . ' — rewrite_url_references() found zero references to update, so it was not deleted. The AVIF replacement exists at ' . basename( $avif_path ) . '; investigate why nothing references the old file (a domain mismatch, or a genuinely orphaned upload) before deleting it manually.' );
                }
            }
        }

        // Real fix — the actual reason a corrected database can still
        // serve broken images: rewrite_url_references() above updates
        // the database directly via raw SQL, which never fires any of
        // WordPress's normal save/update hooks (save_post, etc.) that a
        // page-caching plugin (WP Super Cache, W3 Total Cache, etc.)
        // listens for to know a page needs regenerating. Those plugins
        // pre-render full static HTML files and serve them directly,
        // bypassing PHP/WordPress entirely — so a page whose static
        // snapshot was generated before this migration ran keeps
        // serving the old .webp URL in its HTML indefinitely, no matter
        // how correct the database now is, until that snapshot is
        // explicitly cleared. Only worth doing once something was
        // actually changed.
        if ( $urls_rewritten > 0 ) {
            self::clear_page_caches();
        }

        return [
            'converted'      => $converted,
            'already_avif'   => $already_avif,
            'failed'         => $failed,
            'remaining'      => $remaining,
            'bytes_freed'    => $bytes_freed,
            'urls_rewritten' => $urls_rewritten,
            'not_referenced' => $not_referenced,
        ];
    }

    /**
     * Best-effort flush of every common WordPress page-caching plugin's
     * cache, plus a direct filesystem sweep for the two known static-
     * cache layouts (WP Super Cache, W3 Total Cache) in case neither
     * plugin's own flush function is available to call (e.g. cache
     * generated by a since-deactivated plugin, or a server-level static
     * file cache with no WordPress-side API at all). Every call is
     * guarded by function_exists()/is_dir() — this never errors just
     * because a given cache plugin isn't installed.
     */
    public static function clear_page_caches(): void {
        $cleared_via_api = false;

        // WP Super Cache
        if ( function_exists( 'wp_cache_clear_cache' ) ) {
            try { wp_cache_clear_cache(); $cleared_via_api = true; } catch ( \Throwable $e ) {}
        }
        // W3 Total Cache
        if ( function_exists( 'w3tc_flush_all' ) ) {
            try { w3tc_flush_all(); $cleared_via_api = true; } catch ( \Throwable $e ) {}
        }
        // WP Rocket
        if ( function_exists( 'rocket_clean_domain' ) ) {
            try { rocket_clean_domain(); $cleared_via_api = true; } catch ( \Throwable $e ) {}
        }
        // LiteSpeed Cache
        if ( class_exists( '\LiteSpeed\Purge' ) && method_exists( '\LiteSpeed\Purge', 'purge_all' ) ) {
            try { \LiteSpeed\Purge::purge_all(); $cleared_via_api = true; } catch ( \Throwable $e ) {}
        }
        do_action( 'gs_image_migration_cache_flush' );

        // Real fix — the actual cause of a real, confirmed site-wide
        // slowdown: this filesystem wipe used to run unconditionally,
        // every single call, regardless of whether wp_cache_clear_cache()
        // (WP Super Cache's own proper flush function) had already
        // succeeded cleanly just above it. A plugin's own flush function
        // does the right, minimal, correctly-scoped invalidation — WP
        // Super Cache in particular rebuilds its cache incrementally as
        // pages are next visited after a normal flush. Blowing away every
        // static file directly on top of that, every time this function
        // ran (which includes every automatic trigger from the migration/
        // repair tools above, plus the manual "Clear Page Cache" button),
        // meant the ENTIRE site's static cache was being wiped repeatedly
        // — forcing every single page to fully regenerate from PHP/DB
        // (plus this plugin's own per-request AVIF/WebP delivery HTML
        // processing) on every visit until it naturally rebuilt, instead
        // of the fast path a warm cache provides. Now only runs as a
        // fallback when no plugin API was available to call at all —
        // e.g. a server-level static cache with no WordPress-side hook.
        if ( ! $cleared_via_api ) {
            $wp_content = defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR : '';
            if ( $wp_content ) {
                foreach ( [ $wp_content . '/cache/supercache', $wp_content . '/cache/page_enhanced' ] as $dir ) {
                    if ( is_dir( $dir ) ) { self::delete_directory_contents( $dir ); }
                }
            }
        }
    }

    /**
     * Recursively deletes every file inside a directory without
     * removing the directory itself (so the cache plugin can keep
     * writing into it normally afterward).
     */
    private static function delete_directory_contents( string $dir ): void {
        try {
            $it = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS ),
                \RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach ( $it as $file ) {
                if ( $file->isDir() ) {
                    @rmdir( $file->getPathname() );
                } else {
                    @unlink( $file->getPathname() );
                }
            }
        } catch ( \Throwable $e ) {
            error_log( '[GoodService ImageOptimizer] clear_page_caches directory sweep failed for ' . $dir . ': ' . $e->getMessage() );
        }
    }

    /**
     * Scans uploads for "groups" of files that represent the same logical
     * image under the old design: {name}_orig.{ext}, {name}.webp,
     * {name}.avif. Groups by the base name with _orig/.webp/.avif
     * stripped, so all three (or however many exist) are found together.
     */
    private static function find_legacy_format_groups( string $base_dir, int $limit ): array {
        $groups = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator( $base_dir, \FilesystemIterator::SKIP_DOTS ),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ( $iterator as $file ) {
            if ( ! $file->isFile() ) continue;
            $ext = strtolower( $file->getExtension() );
            if ( ! in_array( $ext, [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif' ], true ) ) continue;

            $path = $file->getPathname();
            $base = preg_replace( '/(_orig)?\.[a-z0-9]+$/i', '', $path );

            if ( ! isset( $groups[ $base ] ) ) {
                $groups[ $base ] = [ 'orig' => null, 'main' => null, 'avif' => null ];
            }

            if ( str_contains( $file->getBasename(), '_orig.' ) ) {
                $groups[ $base ]['orig'] = $path;
            } elseif ( $ext === 'avif' ) {
                $groups[ $base ]['avif'] = $path;
            } else {
                // webp (or, for content that skipped the WebP step
                // entirely, the original-format main file) is the "main".
                $groups[ $base ]['main'] = $path;
            }
        }

        // Only groups that actually have something left to clean up:
        // either no AVIF yet, or an AVIF plus at least one duplicate.
        $needs_work = array_filter( $groups, function ( $g ) {
            $has_avif = $g['avif'] && file_exists( $g['avif'] ) && filesize( $g['avif'] ) > 0;
            $has_dup  = $g['orig'] || $g['main'];
            return $has_dup && ( ! $has_avif || $has_dup );
        } );

        return array_slice( array_values( $needs_work ), 0, $limit );
    }

    /**
     * Real fix — targeted repair for attachments already left in the
     * mismatched state the two bugs above caused:
     *  1. File renamed to .avif on disk and in _wp_attached_file, but
     *     post_mime_type stuck at the old value ('image/webp' etc.) —
     *     what Media Library's "File type" field displays.
     *  2. "File size" stuck at the old, larger, pre-conversion byte
     *     count for EVERY migrated attachment, mime-mismatched or not —
     *     see refresh_metadata_filesizes()'s docblock for why that
     *     cached number never got touched until this fix.
     * Running migrate_existing_to_avif_only() again would skip these —
     * their file is already .avif, so it has nothing left to convert —
     * which is exactly why this needs its own pass: it looks for
     * attachments whose file is .avif directly, then corrects whichever
     * of the two cached fields is still wrong for each one.
     */
    /**
     * Real fix — recovery tool for the exact breakage the bug above
     * caused: migrate_existing_to_avif_only() used to delete a "main"
     * image file even when rewrite_url_references() found nothing to
     * update (silently, on any site where the stored URL's domain
     * differs from what wp_upload_dir() computes — a CDN, in the
     * confirmed case). The AVIF file itself was already generated
     * successfully BEFORE that deletion happened, so it still exists on
     * disk — this isn't a data-loss situation, it's stale references
     * pointing at a file that's gone, next to a correct replacement that
     * already exists under the same basename with a .avif extension.
     *
     * Scans every gs_-prefixed table's text/JSON columns for URLs ending
     * in a non-AVIF image extension. For each one: if the file it points
     * at no longer exists on disk, AND a same-basename .avif file DOES
     * exist, rewrites that specific reference (via the now-basename-based
     * rewrite_url_references(), which no longer has the domain-mismatch
     * problem) to point at the AVIF that's already there. Also checks
     * WordPress attachments the same way via _wp_attached_file.
     *
     * A URL whose file is missing but has NO matching .avif either is
     * left untouched and reported separately — that's a genuinely lost
     * file (conversion never happened, or the AVIF was deleted too),
     * not something this function can safely repair.
     */
    /**
     * Real fix — recovery for attachments uploaded/converted BEFORE the
     * file_is_displayable_image()/wp_image_editor_supports() fixes above
     * existed: if WordPress's own subsize (thumbnail/medium/large)
     * generation was skipped at the time because it didn't recognize the
     * AVIF file as displayable, _wp_attachment_metadata['sizes'] is
     * empty or missing for that attachment — exactly what makes Media
     * Library's Grid View and List View show broken/blank thumbnails,
     * while the frontend (reading the full-size file directly) is
     * unaffected. Finds every image/avif attachment with no sizes data
     * and regenerates it now that the gates are fixed, via WordPress's
     * own wp_generate_attachment_metadata() — not a custom reimplementation,
     * so the result is byte-identical to what a fresh upload would
     * produce today.
     */
    /**
     * Diagnostic: reveals exactly why Media Library thumbnails are broken
     * for real attachments, instead of guessing further. For each sampled
     * AVIF attachment, reports:
     *   - What WordPress's own URL-construction functions produce
     *     (wp_get_attachment_url, wp_get_attachment_image_src for
     *     'thumbnail') — this is what the admin Grid/List view actually
     *     requests.
     *   - Whether wp_upload_dir()'s baseurl matches the domain actually
     *     stored in this attachment's own guid — if they differ, that's
     *     a live domain mismatch (e.g. a CDN domain the site's content
     *     uses vs whatever wp_upload_dir() resolves to), which would
     *     make WordPress construct thumbnail URLs on a domain nothing
     *     else on the site actually uses.
     *   - Whether the expected file genuinely exists on disk at the path
     *     WordPress's metadata says it should.
     *   - A live HTTP HEAD request to the constructed thumbnail URL, so
     *     "the URL WordPress built" and "whether that URL is actually
     *     reachable from the public internet" are checked directly,
     *     rather than assumed from local file existence alone.
     */
    /**
     * Investigates attachments whose main file wp_generate_attachment_metadata()
     * reported missing — before concluding the file is genuinely gone,
     * searches the entire uploads tree for anything matching, since a
     * filename with no random-suffix component (unlike this plugin's own
     * generated names) is far more likely to have hit a plain WordPress
     * filename collision — where wp_unique_filename() silently appended
     * "-1"/"-2" etc. to the actual saved file, while _wp_attached_file
     * still records the original, un-suffixed name that was requested.
     * Reports every candidate found so a real match can be relinked
     * rather than guessed at, and is explicit when nothing is found
     * anywhere — that's the one case this genuinely can't repair, and
     * needs to be stated plainly rather than implied.
     */
    /**
     * Real fix — confirmed by live investigation: for these attachments,
     * the main (full-size) file is genuinely gone, but every size
     * derived FROM it (thumbnail/medium/large crops) is still sitting on
     * disk untouched. Rather than treating this as unrecoverable data
     * loss, the largest surviving size is promoted into the main file's
     * expected place — copied to the exact path/filename
     * _wp_attached_file already records — and WordPress's own metadata
     * generator rebuilds a complete, correct size set fresh from it
     * (this plugin's own optimise_all_sizes() filter converts each of
     * those fresh sizes to AVIF as part of the same call, same as every
     * other repair in this file). The result won't be pixel-identical to
     * whatever the original upload's exact resolution was — it's built
     * from the largest size WordPress happened to generate at the time,
     * not the untouched original — but it's a real, working, reasonably
     * high-resolution image instead of a permanently broken attachment.
     * A size file only ever gets copied, never moved — nothing that
     * already exists and works is put at risk by this.
     */
    public static function recover_missing_main_from_largest_size( array $attachment_ids ): array {
        if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }
        $upload_dir = wp_upload_dir();
        $base_dir   = trailingslashit( $upload_dir['basedir'] );

        $recovered = [];
        $failed    = [];

        foreach ( $attachment_ids as $id ) {
            $id = (int) $id;
            $expected_path = get_attached_file( $id );
            if ( ! $expected_path ) { $failed[] = [ 'id' => $id, 'reason' => 'No _wp_attached_file recorded for this attachment at all.' ]; continue; }
            if ( file_exists( $expected_path ) ) { $failed[] = [ 'id' => $id, 'reason' => 'Main file already exists — nothing to recover.' ]; continue; }

            $dir       = trailingslashit( dirname( $expected_path ) );
            $basename  = basename( $expected_path );
            $name      = pathinfo( $basename, PATHINFO_FILENAME );
            $ext       = pathinfo( $basename, PATHINFO_EXTENSION );

            // Find every "{name}-{W}x{H}.{ext}" candidate in the SAME
            // directory only — deliberately not a whole-tree search like
            // investigate_missing_main_files() uses for reporting, since
            // this one actually copies a file into place and must not
            // risk grabbing an unrelated same-named file from a
            // different listing/vendor elsewhere in the uploads tree.
            $candidates = [];
            foreach ( glob( $dir . preg_quote( $name, '' ) . '-*x*.' . preg_quote( $ext, '' ) ) ?: [] as $candidate_path ) {
                if ( preg_match( '/-(\d+)x(\d+)\.' . preg_quote( $ext, '/' ) . '$/i', $candidate_path, $m ) ) {
                    $candidates[] = [ 'path' => $candidate_path, 'area' => (int) $m[1] * (int) $m[2], 'w' => (int) $m[1], 'h' => (int) $m[2] ];
                }
            }

            if ( empty( $candidates ) ) {
                $failed[] = [ 'id' => $id, 'reason' => 'No derived size files found in the same folder to recover from.' ];
                continue;
            }

            usort( $candidates, fn( $a, $b ) => $b['area'] <=> $a['area'] );
            $best = $candidates[0];

            if ( ! @copy( $best['path'], $expected_path ) ) {
                $failed[] = [ 'id' => $id, 'reason' => 'Found a candidate (' . basename( $best['path'] ) . ') but the copy to ' . $expected_path . ' failed — check folder write permissions.' ];
                continue;
            }

            $new_metadata = wp_generate_attachment_metadata( $id, $expected_path );
            if ( is_array( $new_metadata ) && ! empty( $new_metadata['sizes'] ) ) {
                wp_update_attachment_metadata( $id, $new_metadata );
                $recovered[] = [ 'id' => $id, 'recovered_from' => basename( $best['path'] ), 'resolution' => $best['w'] . 'x' . $best['h'] ];
            } else {
                @unlink( $expected_path ); // don't leave a half-recovered file with no metadata behind
                $failed[] = [ 'id' => $id, 'reason' => 'Copied ' . basename( $best['path'] ) . ' into place but metadata generation still failed afterward.' ];
            }
        }

        return [ 'recovered' => $recovered, 'failed' => $failed ];
    }

    public static function investigate_missing_main_files( array $attachment_ids ): array {
        $upload_dir = wp_upload_dir();
        $base_dir   = trailingslashit( $upload_dir['basedir'] );
        $index      = self::build_basename_index( $base_dir );

        $results = [];
        foreach ( $attachment_ids as $id ) {
            $id = (int) $id;
            $expected_path     = get_attached_file( $id );
            $attached_file_rel = get_post_meta( $id, '_wp_attached_file', true );
            $title              = get_the_title( $id );
            $basename           = $expected_path ? basename( $expected_path ) : '';
            $name_no_ext        = $basename ? pathinfo( $basename, PATHINFO_FILENAME ) : '';

            $entry = [
                'id'                    => $id,
                'title'                 => $title,
                '_wp_attached_file'     => $attached_file_rel,
                'expected_path'         => $expected_path,
                'exact_basename_found_elsewhere' => null,
                'similar_files_found'   => [],
            ];

            // Exact basename, anywhere in the whole uploads tree (not just
            // the year/month folder WordPress currently expects it in).
            if ( $basename && isset( $index[ $basename ] ) ) {
                $entry['exact_basename_found_elsewhere'] = $index[ $basename ];
            }

            // Broader: any file whose name starts with the same base
            // (catches wp_unique_filename() collisions like
            // "Kaagzaat-1-1.avif", "Kaagzaat-1-2.avif", or a leftover
            // under a different extension such as the pre-conversion
            // original if AVIF conversion itself never completed for
            // this file).
            if ( $name_no_ext ) {
                foreach ( $index as $fname => $fpath ) {
                    if ( $fname === $basename ) continue;
                    if ( str_starts_with( $fname, $name_no_ext ) ) {
                        $entry['similar_files_found'][] = [ 'filename' => $fname, 'path' => $fpath ];
                    }
                }
            }

            $entry['genuinely_not_found'] = ! $entry['exact_basename_found_elsewhere'] && empty( $entry['similar_files_found'] );
            $results[] = $entry;
        }

        return $results;
    }

    public static function diagnose_avif_thumbnails( int $limit = 5 ): array {
        global $wpdb;
        $upload_dir = wp_upload_dir();

        $attachment_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_type='attachment' AND post_mime_type='image/avif' ORDER BY ID DESC LIMIT %d",
            $limit
        ) );

        $report = [
            'wp_upload_dir_baseurl' => $upload_dir['baseurl'],
            'wp_upload_dir_basedir' => $upload_dir['basedir'],
            'site_url'              => site_url(),
            'home_url'              => home_url(),
            'attachments'           => [],
        ];

        foreach ( $attachment_ids as $id ) {
            $guid          = get_the_guid( $id );
            $attached_file = get_post_meta( $id, '_wp_attached_file', true );
            $metadata      = wp_get_attachment_metadata( $id );
            $full_url      = wp_get_attachment_url( $id );
            $full_path     = get_attached_file( $id );

            $thumb_src = wp_get_attachment_image_src( $id, 'thumbnail' );

            // Domain actually embedded in this attachment's own guid, vs
            // the domain wp_upload_dir() (and therefore every URL
            // WordPress core constructs) uses right now — the single
            // most likely divergence to actually check for.
            $guid_host   = $guid ? parse_url( $guid, PHP_URL_HOST ) : null;
            $upload_host = parse_url( $upload_dir['baseurl'], PHP_URL_HOST );

            $entry = [
                'id'                 => $id,
                'guid'               => $guid,
                'guid_host'          => $guid_host,
                'upload_baseurl_host'=> $upload_host,
                'host_mismatch'      => ( $guid_host && $upload_host && $guid_host !== $upload_host ),
                '_wp_attached_file'  => $attached_file,
                'full_size_url'      => $full_url,
                'full_size_path'     => $full_path,
                'full_size_exists_on_disk' => $full_path ? file_exists( $full_path ) : false,
                'metadata_has_sizes' => ! empty( $metadata['sizes'] ),
                'thumbnail_url'      => $thumb_src ? $thumb_src[0] : null,
            ];

            if ( ! empty( $metadata['sizes']['thumbnail'] ) ) {
                $thumb_rel  = ltrim( dirname( $attached_file ), '.' );
                $thumb_path = trailingslashit( $upload_dir['basedir'] ) . ltrim( $thumb_rel . '/' . $metadata['sizes']['thumbnail']['file'], '/' );
                $entry['thumbnail_path']          = $thumb_path;
                $entry['thumbnail_exists_on_disk'] = file_exists( $thumb_path );
            } else {
                $entry['thumbnail_path']           = null;
                $entry['thumbnail_exists_on_disk'] = null;
            }

            // Live reachability check — what a browser loading the admin
            // Grid View would actually experience, checked from the
            // server side. Short timeout since this runs synchronously
            // in an admin request and several of these may run in a row.
            if ( $entry['thumbnail_url'] ) {
                $resp = wp_remote_head( $entry['thumbnail_url'], [ 'timeout' => 5, 'sslverify' => false ] );
                $entry['thumbnail_url_http_status'] = is_wp_error( $resp )
                    ? 'ERROR: ' . $resp->get_error_message()
                    : wp_remote_retrieve_response_code( $resp );
            } else {
                $entry['thumbnail_url_http_status'] = null;
            }

            $report['attachments'][] = $entry;
        }

        return $report;
    }

    /**
     * Real fix — confirmed by live diagnostic evidence, correcting the
     * previous version of this function: that version only looked for
     * attachments with COMPLETELY EMPTY _wp_attachment_metadata, which
     * never matches the actual bug. Real, affected attachments have a
     * fully populated 'sizes' array — it just still references an old
     * pre-AVIF-migration .webp thumbnail file that was deleted at some
     * point without the metadata ever being updated to point at a
     * replacement. WordPress's admin Grid/List view requests that exact
     * (now-404ing) URL — while the frontend, which reads the full-size
     * AVIF file directly, is unaffected. This checks every size entry's
     * file for REAL existence on disk, not just whether the metadata
     * array happens to be non-empty, and regenerates the full metadata
     * via WordPress's own wp_generate_attachment_metadata() for any
     * attachment where even one size is missing — core rebuilds every
     * standard size fresh from the current (real, on-disk) main AVIF
     * file, and this plugin's own optimise_all_sizes() filter (already
     * hooked on the same action) converts each of those fresh sizes to
     * AVIF immediately as part of that same call, so the end result is a
     * complete, consistent, all-AVIF size set — not a repeat of the
     * mixed webp/avif state that caused this in the first place.
     */
    public static function repair_missing_avif_subsizes( int $batch = 20, int $offset = 0 ): array {
        global $wpdb;
        if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $upload_dir  = wp_upload_dir();
        $base_dir    = trailingslashit( $upload_dir['basedir'] );
        $upload_host = parse_url( $upload_dir['baseurl'], PHP_URL_HOST );

        $total = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='attachment' AND post_mime_type='image/avif'"
        );

        $ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_type='attachment' AND post_mime_type='image/avif' ORDER BY ID ASC LIMIT %d OFFSET %d",
            $batch, $offset
        ) );

        $fixed         = 0;
        $already_ok    = 0;
        $failed        = 0;
        $guid_fixed    = 0;
        $failed_details = [];

        foreach ( $ids as $id ) {
            $file_path = get_attached_file( $id );
            if ( ! $file_path || ! file_exists( $file_path ) ) {
                $failed++;
                $failed_details[] = [ 'id' => $id, 'file' => basename( (string) $file_path ), 'reason' => 'Main file does not exist on disk at the path WordPress has recorded for it.' ];
                continue;
            }

            // Secondary fix: guid pointing at a stale domain (e.g. an old
            // staging/CDN host) doesn't cause the thumbnail 404s — that's
            // driven by wp_upload_dir(), not guid — but it's real wrong
            // data other WordPress features do read directly (RSS feeds,
            // the REST API's guid.rendered field). Corrected here as a
            // low-risk bonus while already touching this attachment,
            // never as the primary fix this function exists for.
            $guid      = get_the_guid( $id );
            $guid_host = $guid ? parse_url( $guid, PHP_URL_HOST ) : null;
            if ( $guid_host && $upload_host && $guid_host !== $upload_host ) {
                $old_scheme_host = parse_url( $guid, PHP_URL_SCHEME ) . '://' . $guid_host;
                $new_scheme_host = parse_url( $upload_dir['baseurl'], PHP_URL_SCHEME ) . '://' . $upload_host;
                if ( str_starts_with( $guid, $old_scheme_host ) ) {
                    $new_guid = $new_scheme_host . substr( $guid, strlen( $old_scheme_host ) );
                    $wpdb->update( $wpdb->posts, [ 'guid' => $new_guid ], [ 'ID' => $id ] );
                    $guid_fixed++;
                }
            }

            $metadata   = wp_get_attachment_metadata( $id );
            $needs_fix  = empty( $metadata['sizes'] ); // the original, still-valid case: no sizes at all

            if ( ! $needs_fix ) {
                $sub_dir = trailingslashit( dirname( $metadata['file'] ?? $file_path ) );
                foreach ( $metadata['sizes'] as $size_data ) {
                    if ( empty( $size_data['file'] ) ) continue;
                    $size_path = $base_dir . ( $sub_dir === './' ? '' : $sub_dir ) . $size_data['file'];
                    if ( ! file_exists( $size_path ) ) { $needs_fix = true; break; }
                }
            }

            if ( ! $needs_fix ) { $already_ok++; continue; }

            // Real fix — the actual gap that made 3 failures invisible
            // last run: wp_generate_attachment_metadata() returning empty
            // was only ever logged to the PHP error log, which isn't
            // something an admin can necessarily see. Diagnosed directly
            // here instead, in the same request, and returned in the
            // response — checking each real point of failure in order:
            // is the file dimensions-readable at all, can an image editor
            // (Imagick/GD) actually be constructed for it, and is the
            // destination directory writable.
            $reason = null;
            $dims = @getimagesize( $file_path );
            if ( ! $dims || empty( $dims[0] ) || empty( $dims[1] ) ) {
                $reason = 'Could not read image dimensions from the file — PHP\'s getimagesize() does not recognize it, possibly a corrupt or unusually-encoded AVIF file.';
            } else {
                $editor = wp_get_image_editor( $file_path );
                if ( is_wp_error( $editor ) ) {
                    $reason = 'No image editor (Imagick/GD) could be constructed for this file: ' . $editor->get_error_message();
                } elseif ( ! is_writable( dirname( $file_path ) ) ) {
                    $reason = 'The uploads folder for this file is not writable by PHP — new thumbnail files cannot be saved there: ' . dirname( $file_path );
                }
            }

            $new_metadata = wp_generate_attachment_metadata( $id, $file_path );
            if ( is_array( $new_metadata ) && ! empty( $new_metadata['sizes'] ) ) {
                wp_update_attachment_metadata( $id, $new_metadata );
                $fixed++;
            } else {
                $failed++;
                $reason = $reason ?: 'wp_generate_attachment_metadata() ran without a detected error above but still produced no sizes — dimensions were readable and an editor was available, so this needs the actual server-side exception, not just this summary.';
                $failed_details[] = [ 'id' => $id, 'file' => basename( $file_path ), 'dimensions' => $dims ? ( $dims[0] . 'x' . $dims[1] ) : 'unreadable', 'reason' => $reason ];
                error_log( '[GoodService ImageOptimizer] repair_missing_avif_subsizes: failed for attachment ' . $id . ' (' . basename( $file_path ) . ') — ' . $reason );
            }
        }

        $next_offset = $offset + count( $ids );
        return [
            'fixed'          => $fixed,
            'already_ok'     => $already_ok,
            'failed'         => $failed,
            'failed_details' => $failed_details,
            'guid_fixed'     => $guid_fixed,
            'scanned'        => count( $ids ),
            'next_offset'    => $next_offset,
            'total'          => $total,
            'remaining_hint' => $next_offset < $total,
        ];
    }

    public static function repair_broken_image_references( int $batch = 50 ): array {
        global $wpdb;

        $upload_dir = wp_upload_dir();
        $base_dir   = trailingslashit( $upload_dir['basedir'] );

        $candidates = []; // basename => old_url (first occurrence)

        $tables = $wpdb->get_col( $wpdb->prepare(
            "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA = %s AND TABLE_NAME LIKE %s",
            DB_NAME, $wpdb->esc_like( $wpdb->prefix . 'gs_' ) . '%'
        ) );

        $ext_pattern = '/https?:\/\/[^\s"\'\\\\]+\.(?:jpe?g|png|gif|webp)\b/i';

        foreach ( $tables as $table ) {
            $cols = $wpdb->get_col( $wpdb->prepare(
                "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s
                   AND DATA_TYPE IN ('text','mediumtext','longtext','varchar','char')",
                DB_NAME, $table
            ) );
            foreach ( $cols as $col ) {
                $values = $wpdb->get_col( "SELECT DISTINCT `{$col}` FROM `{$table}` WHERE `{$col}` LIKE '%.webp%' OR `{$col}` LIKE '%.jpg%' OR `{$col}` LIKE '%.jpeg%' OR `{$col}` LIKE '%.png%' OR `{$col}` LIKE '%.gif%'" );
                foreach ( $values as $value ) {
                    if ( ! is_string( $value ) || $value === '' ) continue;
                    if ( ! preg_match_all( $ext_pattern, $value, $m ) ) continue;
                    foreach ( $m[0] as $url ) {
                        $basename = basename( parse_url( $url, PHP_URL_PATH ) ?: $url );
                        if ( $basename && ! isset( $candidates[ $basename ] ) ) {
                            $candidates[ $basename ] = $url;
                        }
                    }
                }
            }
        }

        // Also check WordPress attachments' _wp_attached_file directly —
        // covers cases the table scan above might miss if a value was
        // stored in a way the URL regex doesn't match (e.g. relative path
        // only, no scheme/host).
        $attached_files = $wpdb->get_col(
            "SELECT DISTINCT meta_value FROM {$wpdb->postmeta}
             WHERE meta_key = '_wp_attached_file'
               AND ( meta_value LIKE '%.webp' OR meta_value LIKE '%.jpg' OR meta_value LIKE '%.jpeg' OR meta_value LIKE '%.png' OR meta_value LIKE '%.gif' )"
        );
        foreach ( $attached_files as $rel_path ) {
            $basename = basename( $rel_path );
            if ( $basename && ! isset( $candidates[ $basename ] ) ) {
                $candidates[ $basename ] = trailingslashit( $upload_dir['baseurl'] ) . ltrim( $rel_path, '/' );
            }
        }

        $repaired      = 0;
        $unrecoverable = 0;
        $still_ok      = 0;
        $checked       = 0;

        // Build the basename → path index once for this run, instead of
        // re-walking the entire uploads tree per candidate (which was
        // O(candidates × total files) — fine for a handful of images,
        // painfully slow on a real site's full uploads folder).
        $file_index = self::build_basename_index( $base_dir );

        foreach ( $candidates as $basename => $old_url ) {
            if ( $checked >= $batch ) break;

            $local_path = $file_index[ $basename ] ?? null;
            if ( $local_path && file_exists( $local_path ) ) {
                // File genuinely still exists — nothing broken here.
                $still_ok++;
                continue;
            }

            $checked++;

            // File is missing. Does a same-basename .avif already exist?
            $avif_basename = preg_replace( '/\.[a-z0-9]+$/i', '.avif', $basename );
            $avif_path     = $file_index[ $avif_basename ] ?? null;

            if ( $avif_path && file_exists( $avif_path ) && filesize( $avif_path ) > 0 ) {
                $new_url = self::path_to_url( $avif_path );
                $changed = self::rewrite_url_references( $old_url, $new_url );
                if ( $changed > 0 ) {
                    $repaired++;
                } else {
                    $unrecoverable++;
                    error_log( '[GoodService ImageOptimizer] repair_broken_image_references: found AVIF replacement for missing file ' . $basename . ' but rewrite still matched zero rows — investigate manually.' );
                }
            } else {
                $unrecoverable++;
                error_log( '[GoodService ImageOptimizer] repair_broken_image_references: ' . $basename . ' is missing on disk with NO matching AVIF replacement — this file is genuinely gone, not just a stale reference.' );
            }
        }

        if ( $repaired > 0 ) {
            self::clear_page_caches();
        }

        return [
            'repaired'       => $repaired,
            'unrecoverable'  => $unrecoverable,
            'still_ok'       => $still_ok,
            'checked'        => $checked,
            'total_scanned'  => count( $candidates ),
            'remaining_hint' => count( $candidates ) > ( $still_ok + $checked ),
        ];
    }

    /**
     * Builds a basename → full path map for every file under the uploads
     * directory, in one pass. Uploads are organised in year/month
     * subfolders, so a flat filename doesn't tell you the subdirectory —
     * this is the efficient alternative to walking the tree once per
     * candidate file.
     */
    private static function build_basename_index( string $base_dir ): array {
        $index = [];
        try {
            $it = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator( $base_dir, \FilesystemIterator::SKIP_DOTS )
            );
            foreach ( $it as $file ) {
                if ( $file->isFile() ) {
                    $index[ $file->getFilename() ] = $file->getPathname();
                }
            }
        } catch ( \Throwable $e ) {}
        return $index;
    }

    public static function repair_mismatched_avif_mime_types( int $batch = 100, int $offset = 0 ): array {
        global $wpdb;

        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_wp_attached_file'
             WHERE p.post_type = 'attachment' AND pm.meta_value LIKE %s",
            '%.avif'
        ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.guid, p.post_mime_type, pm.meta_value AS attached_file
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_wp_attached_file'
             WHERE p.post_type = 'attachment'
               AND pm.meta_value LIKE %s
             ORDER BY p.ID ASC
             LIMIT %d OFFSET %d",
            '%.avif', $batch, $offset
        ) );

        $fixed_mime = 0;
        $fixed_size = 0;

        foreach ( $rows as $row ) {
            if ( $row->post_mime_type !== 'image/avif' ) {
                $new_guid = preg_replace( '/\.[a-z0-9]+$/i', '.avif', $row->guid );
                $wpdb->update(
                    $wpdb->posts,
                    [ 'post_mime_type' => 'image/avif', 'guid' => $new_guid ],
                    [ 'ID' => $row->ID ]
                );
                $fixed_mime++;
            }

            $meta = get_post_meta( $row->ID, '_wp_attachment_metadata', true );
            if ( is_array( $meta ) ) {
                $before = wp_json_encode( $meta );
                $meta   = self::refresh_metadata_filesizes( $meta );
                if ( wp_json_encode( $meta ) !== $before ) {
                    update_post_meta( $row->ID, '_wp_attachment_metadata', $meta );
                    $fixed_size++;
                }
            }
        }

        if ( $fixed_mime > 0 || $fixed_size > 0 ) {
            self::clear_page_caches();
        }

        return [
            'fixed'          => $fixed_mime, // kept for JS backward-compat
            'fixed_mime'     => $fixed_mime,
            'fixed_size'     => $fixed_size,
            'scanned'        => count( $rows ),
            'next_offset'    => $offset + count( $rows ),
            'total'          => $total,
            'remaining_hint' => ( $offset + count( $rows ) ) < $total,
        ];
    }

    public static function bulk_generate_avif( int $batch = 20 ): array {
        $upload_dir = wp_upload_dir();
        $base_dir   = $upload_dir['basedir'];

        // Gather WebP (and JPG/PNG) files without AVIF sidecars.
        $files = self::find_files_needing_avif( $base_dir, $batch + 1 );

        $converted = 0;
        $failed    = 0;
        $remaining = 0;

        if ( count( $files ) > $batch ) {
            $remaining = count( $files ) - $batch;
            $files     = array_slice( $files, 0, $batch );
        }

        foreach ( $files as $file ) {
            $ok = self::generate_avif_sidecar( $file );
            $ok ? $converted++ : $failed++;
        }

        return [
            'converted' => $converted,
            'failed'    => $failed,
            'remaining' => $remaining,
        ];
    }

    /**
     * Real feature, the missing half of the existing AVIF backfill tool:
     * images uploaded before this optimizer existed get AVIF via
     * bulk_generate_avif() (which scans original jpg/png too), but never
     * get a WebP sidecar unless re-uploaded, since WebP generation only
     * ever fires on the wp_handle_upload hook. This is the same batch
     * pattern, for the same real gap, on the other format.
     */
    public static function bulk_generate_webp( int $batch = 20 ): array {
        $upload_dir = wp_upload_dir();
        $base_dir   = $upload_dir['basedir'];

        $files = self::find_files_needing_webp( $base_dir, $batch + 1 );

        $converted = 0;
        $failed    = 0;
        $remaining = 0;

        if ( count( $files ) > $batch ) {
            $remaining = count( $files ) - $batch;
            $files     = array_slice( $files, 0, $batch );
        }

        foreach ( $files as $file ) {
            $mime = self::mime_from_path( $file );
            $result = self::convert_to_webp( $file, $mime );
            $result !== null ? $converted++ : $failed++;
        }

        return [
            'converted' => $converted,
            'failed'    => $failed,
            'remaining' => $remaining,
        ];
    }

    /**
     * Real feature: same scanning logic as find_files_needing_avif(),
     * for the WebP gap instead — finds original jpg/png files with no
     * corresponding .webp sidecar yet.
     */
    private static function find_files_needing_webp( string $base_dir, int $limit ): array {
        $results  = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator( $base_dir, \FilesystemIterator::SKIP_DOTS ),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        $exts = [ 'jpg', 'jpeg', 'png' ];

        foreach ( $iterator as $file ) {
            if ( ! $file->isFile() ) continue;
            $ext = strtolower( $file->getExtension() );
            if ( ! in_array( $ext, $exts, true ) ) continue;

            // Skip _orig files — those are AVIF's preserved originals, not
            // independently-served images needing their own WebP version.
            if ( str_contains( $file->getBasename(), '_orig.' ) ) continue;

            $path      = $file->getPathname();
            $webp_path = preg_replace( '/\.[a-z0-9]+$/i', '.webp', $path );

            if ( ! file_exists( $webp_path ) || filesize( $webp_path ) === 0 ) {
                $results[] = $path;
                if ( count( $results ) >= $limit ) break;
            }
        }

        return $results;
    }

    /**
     * Delete ALL .avif sidecar files from the uploads directory.
     * Used when regenerating after a bug fix — wipes corrupt files so they
     * get rebuilt correctly on the next bulk_generate_avif() call.
     *
     * @return int Number of files deleted.
     */
    public static function delete_all_avif(): int {
        $upload_dir = wp_upload_dir();
        $base_dir   = $upload_dir['basedir'];
        $deleted    = 0;

        try {
            $it = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator( $base_dir, \FilesystemIterator::SKIP_DOTS )
            );
            foreach ( $it as $file ) {
                if ( ! $file->isFile() ) continue;
                if ( strtolower( $file->getExtension() ) !== 'avif' ) continue;
                if ( @unlink( $file->getPathname() ) ) {
                    $deleted++;
                }
            }
        } catch ( \Throwable $e ) {
            error_log( '[GoodService ImageOptimizer] delete_all_avif error: ' . $e->getMessage() );
        }

        return $deleted;
    }

    /**
     * Scan uploads directory for image files that lack an AVIF sidecar.
     * Returns up to $limit paths.
     */
    /**
     * Real feature, item 4: safe, explicit-choice cleanup of _orig files.
     * Deliberately does NOT delete indiscriminately — an _orig file is only
     * removed when its corresponding AVIF sidecar genuinely already exists
     * and is valid. This respects the one documented, legitimate reason
     * these files exist: correct transparency handling during AVIF
     * generation, and supporting regeneration after a future bug fix (see
     * delete_all_avif()'s own comment). Deleting an _orig file whose AVIF
     * was never successfully generated would remove the only reliable
     * source for correct transparency, silently reintroducing that bug.
     *
     * @param bool $dry_run If true, reports what WOULD be deleted without
     *                      deleting anything — used for the admin preview.
     */
    public static function cleanup_safe_orig_files( bool $dry_run = true ): array {
        $upload_dir = wp_upload_dir();
        $base_dir   = $upload_dir['basedir'];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator( $base_dir, \FilesystemIterator::SKIP_DOTS ),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        $safe_to_delete = [];
        $kept_no_avif   = 0;
        $total_bytes    = 0;

        foreach ( $iterator as $file ) {
            if ( ! $file->isFile() ) continue;
            if ( ! str_contains( $file->getBasename(), '_orig.' ) ) continue;

            $orig_path = $file->getPathname();
            // The _orig file's sibling WebP is the same path with _orig
            // removed (e.g. logo_orig.png -> logo.webp).
            $webp_path = preg_replace( '/_orig\.[a-z0-9]+$/i', '.webp', $orig_path );
            $avif_path = self::avif_path_from( $webp_path );

            if ( file_exists( $avif_path ) && filesize( $avif_path ) > 0 ) {
                $safe_to_delete[] = $orig_path;
                $total_bytes += $file->getSize();
                if ( ! $dry_run ) { @unlink( $orig_path ); }
            } else {
                $kept_no_avif++;
            }
        }

        return [
            'deleted_or_would_delete' => count( $safe_to_delete ),
            'kept_no_avif_yet'        => $kept_no_avif,
            'bytes_freed_or_freeable' => $total_bytes,
            'dry_run'                 => $dry_run,
        ];
    }

    private static function find_files_needing_avif( string $base_dir, int $limit ): array {
        $results  = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator( $base_dir, \FilesystemIterator::SKIP_DOTS ),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        $exts = [ 'webp', 'jpg', 'jpeg', 'png' ];

        foreach ( $iterator as $file ) {
            if ( ! $file->isFile() ) continue;
            $ext = strtolower( $file->getExtension() );
            if ( ! in_array( $ext, $exts, true ) ) continue;

            // Skip _orig files.
            if ( str_contains( $file->getBasename(), '_orig.' ) ) continue;

            $path      = $file->getPathname();
            $avif_path = self::avif_path_from( $path );

            if ( ! file_exists( $avif_path ) || filesize( $avif_path ) === 0 ) {
                $results[] = $path;
                if ( count( $results ) >= $limit ) break;
            }
        }

        return $results;
    }

    // ── AVIF conversion — the automatic upload-pipeline path ───────────────────
    // Unlike generate_avif_sidecar() (kept below for legacy/manual bulk
    // conversion of already-correctly-sized existing files), this resizes
    // to GS_IMG_MAX_DIMENSION and auto-orients — the same preprocessing
    // the old WebP path used to do — since it's now the ONLY conversion
    // step for a fresh upload, not a re-encode of an already-processed file.

    private static function convert_to_avif( string $src_path, string $src_mime, string $dest_path ): bool {
        $has_gd      = extension_loaded( 'gd' );
        $has_imagick = extension_loaded( 'imagick' );

        if ( ! $has_gd && ! $has_imagick ) return false;

        $quality = (int) apply_filters( 'gs_optimizer_avif_quality', self::DEFAULT_AVIF_QUALITY );
        $quality = max( 1, min( 100, $quality ) );
        $max_dim = (int) apply_filters( 'gs_optimizer_max_dimension', self::DEFAULT_MAX_DIMENSION );
        $strip   = (bool) apply_filters( 'gs_optimizer_strip_metadata', false );

        // Prefer Imagick (queryFormats AVIF check mirrors avif_supported()).
        if ( $has_imagick ) {
            try {
                if ( ! empty( \Imagick::queryFormats( 'AVIF' ) ) ) {
                    $ok = self::convert_with_imagick_avif( $src_path, $src_mime, $dest_path, $quality, $max_dim, $strip );
                    if ( $ok ) return true;
                }
            } catch ( \Throwable $e ) {
                error_log( '[GoodService ImageOptimizer] convert_to_avif/Imagick failed: ' . $e->getMessage() );
            }
        }

        if ( function_exists( 'imageavif' ) ) {
            try {
                $ok = self::convert_with_gd_avif( $src_path, $src_mime, $dest_path, $quality, $max_dim );
                if ( $ok ) return true;
            } catch ( \Throwable $e ) {
                error_log( '[GoodService ImageOptimizer] convert_to_avif/GD failed: ' . $e->getMessage() );
            }
        }

        return false;
    }

    private static function convert_with_imagick_avif(
        string $src_path, string $src_mime, string $dest_path,
        int $quality, int $max_dim, bool $strip
    ): bool {
        try {
            $im = new \Imagick( $src_path );

            if ( $src_mime === 'image/gif' ) {
                $im = $im->coalesceImages();
                $im = $im->current();
            }

            self::imagick_auto_orient( $im );

            if ( $max_dim > 0 ) {
                $w = $im->getImageWidth();
                $h = $im->getImageHeight();
                if ( $w > $max_dim || $h > $max_dim ) {
                    $im->resizeImage( $max_dim, $max_dim, \Imagick::FILTER_LANCZOS, 1, true );
                }
            }

            // Same root-cause fix documented in generate_avif_sidecar():
            // ALPHACHANNEL_ON explicitly enables alpha rather than relying
            // on misdetection-prone getImageAlphaChannel() for formats
            // where that call is unreliable (WebP in particular).
            $may_have_alpha = in_array( $src_mime, [ 'image/png', 'image/gif', 'image/webp', 'image/avif' ], true )
                || (bool) $im->getImageAlphaChannel();
            if ( $may_have_alpha ) {
                $im->setImageAlphaChannel( \Imagick::ALPHACHANNEL_ON );
            } elseif ( $src_mime === 'image/jpeg' ) {
                $im->setImageColorspace( \Imagick::COLORSPACE_SRGB );
            }

            $im->setImageFormat( 'avif' );
            $im->setImageCompressionQuality( $quality );
            $im->setOption( 'avif:speed', '6' );

            if ( $strip ) $im->stripImage();

            $im->writeImage( $dest_path );
            $im->clear();
            $im->destroy();

            $success = file_exists( $dest_path ) && filesize( $dest_path ) > 0;
            if ( ! $success && file_exists( $dest_path ) ) { @unlink( $dest_path ); }
            return $success;

        } catch ( \ImagickException $e ) {
            error_log( '[GoodService ImageOptimizer] Imagick AVIF error: ' . $e->getMessage() );
            if ( file_exists( $dest_path ) ) { @unlink( $dest_path ); }
            return false;
        }
    }

    private static function convert_with_gd_avif(
        string $src_path, string $src_mime, string $dest_path,
        int $quality, int $max_dim
    ): bool {
        $img = self::gd_open( $src_path, $src_mime );
        if ( ! $img ) return false;

        if ( $src_mime === 'image/jpeg' && function_exists( 'exif_read_data' ) ) {
            $img = self::gd_auto_orient( $img, $src_path );
        }

        if ( $max_dim > 0 ) {
            $w = imagesx( $img );
            $h = imagesy( $img );
            if ( $w > $max_dim || $h > $max_dim ) {
                $ratio = $w > $h ? $max_dim / $w : $max_dim / $h;
                $nw    = (int) round( $w * $ratio );
                $nh    = (int) round( $h * $ratio );
                $new   = imagecreatetruecolor( $nw, $nh );
                imagealphablending( $new, false );
                imagesavealpha( $new, true );
                $transparent_fill = imagecolorallocatealpha( $new, 0, 0, 0, 127 );
                imagefill( $new, 0, 0, $transparent_fill );
                imagecolordeallocate( $new, $transparent_fill );
                imagecopyresampled( $new, $img, 0, 0, 0, 0, $nw, $nh, $w, $h );
                imagedestroy( $img );
                $img = $new;
            }
        }

        $may_have_alpha = in_array( $src_mime, [ 'image/png', 'image/gif', 'image/webp', 'image/avif' ], true );
        if ( $may_have_alpha ) {
            imagealphablending( $img, false );
            imagesavealpha( $img, true );
        }

        $ok = imageavif( $img, $dest_path, $quality );
        imagedestroy( $img );

        $success = $ok && file_exists( $dest_path ) && filesize( $dest_path ) > 0;
        if ( ! $success && file_exists( $dest_path ) ) { @unlink( $dest_path ); }
        return $success;
    }

    // ── WebP conversion — kept for the manual bulk_generate_webp() admin
    // tool and legacy content only. No longer part of the automatic
    // upload pipeline (see handle_upload() / optimise_all_sizes() above),
    // which now converts straight to AVIF. ─────────────────────────────────

    private static function convert_to_webp( string $src_path, string $src_mime ): ?array {
        $has_gd      = extension_loaded( 'gd' );
        $has_imagick = extension_loaded( 'imagick' );

        if ( ! $has_gd && ! $has_imagick ) return null;

        $webp_quality = (int) apply_filters( 'gs_optimizer_webp_quality', self::DEFAULT_WEBP_QUALITY );
        $webp_quality = max( 1, min( 100, $webp_quality ) );
        $max_dim      = (int) apply_filters( 'gs_optimizer_max_dimension', self::DEFAULT_MAX_DIMENSION );
        $strip        = (bool) apply_filters( 'gs_optimizer_strip_metadata', false );

        $dest_path = preg_replace( '/\.[a-z0-9]+$/i', '.webp', $src_path );
        $dest_url  = self::path_to_url( $dest_path );

        if ( $has_imagick ) {
            $ok = self::convert_with_imagick( $src_path, $src_mime, $dest_path, $webp_quality, $max_dim, $strip );
            if ( $ok ) return [ 'webp_path' => $dest_path, 'webp_url' => $dest_url ];
        }

        if ( $has_gd ) {
            $ok = self::convert_with_gd( $src_path, $src_mime, $dest_path, $webp_quality, $max_dim );
            if ( $ok ) return [ 'webp_path' => $dest_path, 'webp_url' => $dest_url ];
        }

        return null;
    }

    private static function convert_with_imagick(
        string $src_path, string $src_mime, string $dest_path,
        int $quality, int $max_dim, bool $strip
    ): bool {
        try {
            $im = new \Imagick( $src_path );

            if ( $src_mime === 'image/gif' ) {
                $im = $im->coalesceImages();
                $im = $im->current();
            }

            self::imagick_auto_orient( $im );

            if ( $max_dim > 0 ) {
                $w = $im->getImageWidth();
                $h = $im->getImageHeight();
                if ( $w > $max_dim || $h > $max_dim ) {
                    $im->resizeImage( $max_dim, $max_dim, \Imagick::FILTER_LANCZOS, 1, true );
                }
            }

            // FIX: Use actual image data, not a mime-type allowlist.
            // getImageAlphaChannel() works for any format Imagick supports.
            $has_alpha = (bool) $im->getImageAlphaChannel();

            $im->setImageFormat( 'webp' );
            if ( $has_alpha ) {
                // FIX: Explicitly activate alpha channel before format conversion.
                // Some Imagick builds silently drop alpha without this — resulting
                // in an opaque WebP even when the source PNG/GIF had transparency.
                $im->setImageAlphaChannel( \Imagick::ALPHACHANNEL_ACTIVATE );
                $im->setOption( 'webp:lossless', 'true' );
                $im->setImageCompressionQuality( self::LOSSLESS_QUALITY );
            } else {
                $im->setOption( 'webp:method', '6' );
                $im->setOption( 'webp:lossless', 'false' );
                $im->setImageCompressionQuality( $quality );
            }

            if ( $strip ) $im->stripImage();

            $im->writeImage( $dest_path );
            $im->clear();
            $im->destroy();

            return file_exists( $dest_path ) && filesize( $dest_path ) > 0;

        } catch ( \ImagickException $e ) {
            error_log( '[GoodService ImageOptimizer] Imagick WebP error: ' . $e->getMessage() );
            // Real fix, item 4: a partial/corrupt file may have been
            // written to $dest_path before the exception — clean it up
            // rather than leave orphaned storage behind.
            if ( file_exists( $dest_path ) ) { @unlink( $dest_path ); }
            return false;
        }
    }

    private static function convert_with_gd(
        string $src_path, string $src_mime, string $dest_path,
        int $quality, int $max_dim
    ): bool {
        if ( ! function_exists( 'imagewebp' ) ) return false;

        $img = self::gd_open( $src_path, $src_mime );
        if ( ! $img ) return false;

        if ( $src_mime === 'image/jpeg' && function_exists( 'exif_read_data' ) ) {
            $img = self::gd_auto_orient( $img, $src_path );
        }

        if ( $max_dim > 0 ) {
            $w = imagesx( $img );
            $h = imagesy( $img );
            if ( $w > $max_dim || $h > $max_dim ) {
                $ratio = $w > $h ? $max_dim / $w : $max_dim / $h;
                $nw    = (int) round( $w * $ratio );
                $nh    = (int) round( $h * $ratio );
                $new   = imagecreatetruecolor( $nw, $nh );
                imagealphablending( $new, false );
                imagesavealpha( $new, true );
                // FIX: Fill canvas with transparent pixels before resampling.
                // imagecreatetruecolor() starts with a black background. Any pixel
                // in $new not overwritten by imagecopyresampled() stays black —
                // creating black edges/corners on transparent images after resize.
                $transparent_fill = imagecolorallocatealpha( $new, 0, 0, 0, 127 );
                imagefill( $new, 0, 0, $transparent_fill );
                imagecolordeallocate( $new, $transparent_fill );
                imagecopyresampled( $new, $img, 0, 0, 0, 0, $nw, $nh, $w, $h );
                imagedestroy( $img );
                $img = $new;
            }
        }

        $has_alpha = in_array( $src_mime, [ 'image/png', 'image/gif' ], true );
        if ( $has_alpha ) {
            imagealphablending( $img, false );
            imagesavealpha( $img, true );
            $ok = imagewebp( $img, $dest_path, self::LOSSLESS_QUALITY );
        } else {
            $ok = imagewebp( $img, $dest_path, $quality );
        }

        imagedestroy( $img );
        $success = $ok && file_exists( $dest_path ) && filesize( $dest_path ) > 0;
        // Real fix, item 4: imagewebp() can leave a partial/zero-byte file
        // even when this function correctly detects failure — clean it up.
        if ( ! $success && file_exists( $dest_path ) ) { @unlink( $dest_path ); }
        return $success;
    }

    // ── Quality filters ───────────────────────────────────────────────────────

    public static function jpeg_quality(): int {
        return (int) apply_filters( 'gs_optimizer_jpeg_quality', self::DEFAULT_JPEG_QUALITY );
    }

    public static function editor_quality(): int {
        return (int) apply_filters( 'gs_optimizer_jpeg_quality', self::DEFAULT_JPEG_QUALITY );
    }

    public static function allow_modern_mimes( array $mimes ): array {
        $mimes['webp'] = 'image/webp';
        $mimes['avif'] = 'image/avif';
        return $mimes;
    }

    /**
     * file_is_displayable_image filter callback. $path is the absolute
     * path WordPress is validating — trusts any file WordPress itself
     * already identified as .avif by extension, rather than re-deriving
     * type from file bytes the way core's own getimagesize()-based check
     * does. Only overrides the result for avif specifically; every other
     * format keeps whatever core's own check ($displayable) decided,
     * including a genuine false for a truly corrupt file — even one with
     * a .avif extension, since the real problem this fixes is
     * misidentification, not a blanket "always true".
     */
    public static function trust_avif_as_displayable( bool $displayable, string $path ): bool {
        if ( $displayable ) { return true; }
        if ( strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) !== 'avif' ) { return $displayable; }
        return file_exists( $path ) && filesize( $path ) > 0;
    }

    /**
     * wp_image_editor_supports filter callback. $args typically includes
     * 'mime_type' when WordPress is checking whether an editor can handle
     * a specific format (as opposed to a generic capability check with no
     * mime_type set, which this leaves untouched).
     */
    public static function trust_avif_editor_support( bool $supports, array $args ): bool {
        if ( $supports ) { return true; }
        if ( ( $args['mime_type'] ?? '' ) !== 'image/avif' ) { return $supports; }
        return self::avif_supported();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static function is_image( string $mime ): bool {
        return str_starts_with( $mime, 'image/' )
            && ! in_array( $mime, [ 'image/svg+xml', 'image/svg' ], true );
    }

    private static function make_orig_path( string $path ): string {
        $info = pathinfo( $path );
        return $info['dirname'] . DIRECTORY_SEPARATOR
             . $info['filename'] . '_orig.' . $info['extension'];
    }

    private static function path_to_url( string $abs_path ): string {
        $upload_dir = wp_upload_dir();
        return str_replace(
            trailingslashit( $upload_dir['basedir'] ),
            trailingslashit( $upload_dir['baseurl'] ),
            $abs_path
        );
    }

    /**
     * Path relative to the uploads basedir, matching the exact format
     * WordPress stores in postmeta._wp_attached_file (e.g.
     * "2026/07/logo-abc123.webp", no leading slash).
     */
    private static function path_to_relative( string $abs_path ): string {
        $upload_dir = wp_upload_dir();
        return ltrim( str_replace(
            trailingslashit( $upload_dir['basedir'] ),
            '',
            $abs_path
        ), '/\\' );
    }

    public static function mime_from_path( string $path ): string {
        if ( function_exists( 'mime_content_type' ) ) {
            return mime_content_type( $path ) ?: 'application/octet-stream';
        }
        $map = [
            'jpg'  => 'image/jpeg', 'jpeg' => 'image/jpeg',
            'png'  => 'image/png',  'gif'  => 'image/gif',
            'webp' => 'image/webp', 'avif' => 'image/avif',
        ];
        return $map[ strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) ] ?? 'application/octet-stream';
    }

    private static function gd_open( string $path, string $mime ): \GdImage|false {
        return match ( $mime ) {
            'image/jpeg' => @imagecreatefromjpeg( $path ),
            'image/png'  => @imagecreatefrompng( $path ),
            'image/gif'  => @imagecreatefromgif( $path ),
            'image/webp' => function_exists( 'imagecreatefromwebp' ) ? @imagecreatefromwebp( $path ) : false,
            'image/avif' => function_exists( 'imagecreatefromavif' ) ? @imagecreatefromavif( $path ) : false,
            'image/bmp'  => function_exists( 'imagecreatefrombmp'  ) ? @imagecreatefrombmp( $path )  : false,
            default      => false,
        };
    }

    private static function imagick_auto_orient( \Imagick $im ): void {
        try {
            $o = $im->getImageOrientation();
            // FIX: Use 'none' (transparent) as rotation background for images that
            // have an alpha channel. rotateImage('#000', ...) fills corner pixels
            // with solid black — destroying transparency for logos/icons that have
            // EXIF rotation metadata. For opaque images, '#000' is harmless.
            $rot_bg = (bool) $im->getImageAlphaChannel() ? 'none' : '#000';
            match ( $o ) {
                \Imagick::ORIENTATION_TOPRIGHT    => $im->flopImage(),
                \Imagick::ORIENTATION_BOTTOMRIGHT => $im->rotateImage( $rot_bg, 180 ),
                \Imagick::ORIENTATION_BOTTOMLEFT  => ( $im->flopImage() ?: true ) && $im->rotateImage( $rot_bg, 180 ),
                \Imagick::ORIENTATION_LEFTTOP     => ( $im->flopImage() ?: true ) && $im->rotateImage( $rot_bg, -90 ),
                \Imagick::ORIENTATION_RIGHTTOP    => $im->rotateImage( $rot_bg, 90 ),
                \Imagick::ORIENTATION_RIGHTBOTTOM => ( $im->flopImage() ?: true ) && $im->rotateImage( $rot_bg, 90 ),
                \Imagick::ORIENTATION_LEFTBOTTOM  => $im->rotateImage( $rot_bg, -90 ),
                default                           => null,
            };
            $im->setImageOrientation( \Imagick::ORIENTATION_TOPLEFT );
        } catch ( \ImagickException $e ) {}
    }

    private static function gd_auto_orient( \GdImage $img, string $src_path ): \GdImage {
        try {
            $exif = @exif_read_data( $src_path );
            return match ( $exif['Orientation'] ?? 1 ) {
                3 => imagerotate( $img, 180, 0 ),
                6 => imagerotate( $img, -90, 0 ),
                8 => imagerotate( $img, 90, 0 ),
                default => $img,
            };
        } catch ( \Throwable $e ) {
            return $img;
        }
    }

    private static function log_avif_savings( string $src_path, string $avif_path ): void {
        $src_size  = filesize( $src_path );
        $avif_size = filesize( $avif_path );
        if ( $src_size > 0 ) {
            $pct = round( ( 1 - $avif_size / $src_size ) * 100, 1 );
            error_log( sprintf(
                '[GoodService ImageOptimizer] AVIF generated: %s → %s (%s%% smaller)',
                basename( $src_path ),
                basename( $avif_path ),
                $pct
            ) );
        }
    }
}
