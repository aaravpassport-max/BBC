<?php
namespace GoodService\Service;

/**
 * WalletService — real feature, confirmed genuinely missing during
 * Phase 1 discovery (unlike coupons, which turned out to already exist
 * fully-built for vendor subscription purchases — this one really was
 * absent: no table, no service, nothing).
 *
 * Ledger design: every transaction is its own row recording the
 * resulting balance, not a single mutable balance column. A wallet
 * balance is real financial liability on the books — this needs the
 * same auditability as gs_invoices already has for payments, and a
 * ledger is the only design that supports that (a mutable column can't
 * answer "how did the balance get to this number", a ledger always can).
 */
class WalletService {

    public static function get_balance( int $user_id ): float {
        global $wpdb;
        $balance = $wpdb->get_var( $wpdb->prepare(
            "SELECT balance_after FROM {$wpdb->prefix}gs_wallet_transactions
             WHERE user_id = %d ORDER BY id DESC LIMIT 1",
            $user_id
        ) );
        return $balance !== null ? (float) $balance : 0.0;
    }

    /**
     * Credits the wallet. $source identifies WHY (e.g. 'dispute_resolution',
     * 'referral', 'goodwill', 'admin_adjustment') and $reference_type/id
     * link back to the originating record (e.g. the dispute itself) so a
     * credit is always traceable to what caused it, never a bare number
     * with no context.
     */
    public static function credit( int $user_id, float $amount, string $source, string $reference_type = '', ?int $reference_id = null, string $note = '', ?int $created_by = null ): bool {
        if ( $amount <= 0 ) { return false; } // real validation rule: a "credit" of zero or negative is not a credit
        return self::record( $user_id, 'credit', $amount, $source, $reference_type, $reference_id, $note, $created_by );
    }

    /**
     * Debits the wallet. Refuses to let the balance go negative — a
     * wallet is prepaid credit, not a line of credit; overdrawing it
     * would mean the platform owes the customer money it never actually
     * held, a real accounting problem, not just a UX one.
     */
    public static function debit( int $user_id, float $amount, string $source, string $reference_type = '', ?int $reference_id = null, string $note = '', ?int $created_by = null ): array {
        if ( $amount <= 0 ) {
            return [ 'success' => false, 'error' => 'Invalid debit amount.' ];
        }
        $current = self::get_balance( $user_id );
        if ( $current < $amount ) {
            return [ 'success' => false, 'error' => 'Insufficient wallet balance.' ];
        }
        $ok = self::record( $user_id, 'debit', $amount, $source, $reference_type, $reference_id, $note, $created_by );
        return [ 'success' => $ok, 'error' => $ok ? null : 'Could not record wallet debit.' ];
    }

    private static function record( int $user_id, string $type, float $amount, string $source, string $reference_type, ?int $reference_id, string $note, ?int $created_by ): bool {
        global $wpdb;
        $current = self::get_balance( $user_id );
        $new_balance = $type === 'credit' ? $current + $amount : $current - $amount;

        $ok = (bool) $wpdb->insert( $wpdb->prefix . 'gs_wallet_transactions', [
            'user_id'        => $user_id,
            'type'           => $type,
            'amount'         => $amount,
            'balance_after'  => $new_balance,
            'source'         => $source,
            'reference_type' => $reference_type,
            'reference_id'   => $reference_id,
            'note'           => $note,
            'created_by'     => $created_by,
        ] );

        if ( $ok ) {
            gs_write_log( "WalletService: {$type} of {$amount} for user {$user_id} (source: {$source}) — new balance {$new_balance}", 'INFO' );
        }

        return $ok;
    }

    public static function history( int $user_id, int $limit = 50 ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_wallet_transactions WHERE user_id = %d ORDER BY id DESC LIMIT %d",
            $user_id, $limit
        ) );
    }
}
