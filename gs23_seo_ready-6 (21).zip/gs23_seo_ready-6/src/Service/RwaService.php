<?php
namespace GoodService\Service;

/**
 * RwaService — Society & RWA Portal (Moat 3)
 * Allows RWA secretaries to manage approved vendors for their society,
 * track common area assets, and give residents a curated vendor shortlist.
 */
final class RwaService {

    /** Create a new society (RWA admin). */
    public static function create_society( int $admin_user_id, array $data ): int {
        global $wpdb;

        // Assign gs_rwa_admin role to the user
        $user = get_user_by( 'id', $admin_user_id );
        if ( $user ) { $user->add_role( 'gs_rwa_admin' ); }

        $code = strtoupper( substr( sanitize_title( $data['name'] ?? 'SOC' ), 0, 4 ) . wp_rand( 1000, 9999 ) );

        $__gs_ok = $wpdb->insert( $wpdb->prefix . 'gs_societies', [
            'name'         => sanitize_text_field( $data['name'] ?? '' ),
            'type'         => in_array( $data['type'] ?? '', [ 'apartment', 'villa', 'gated_community', 'office_park' ], true )
                              ? $data['type'] : 'apartment',
            'location_id'  => (int) ( $data['location_id'] ?? 0 ),
            'address'      => sanitize_textarea_field( $data['address'] ?? '' ),
            'total_units'  => (int) ( $data['total_units'] ?? 0 ),
            'pincode'      => sanitize_text_field( $data['pincode'] ?? '' ),
            'admin_user_id'=> $admin_user_id,
            'access_code'  => $code,
            'is_verified'  => 0,
            'created_at'   => current_time( 'mysql' ),
        ] );

        if ( ! $__gs_ok ) { return 0; }
        $society_id = (int) $wpdb->insert_id;

        // Auto-add admin as a member with 'admin' role
        $wpdb->insert( $wpdb->prefix . 'gs_society_members', [
            'society_id'  => $society_id,
            'user_id'     => $admin_user_id,
            'role'        => 'admin',
            'joined_at'   => current_time( 'mysql' ),
        ] );

        return $society_id;
    }

    /** Resident joins a society using an access code. */
    public static function join_society( string $access_code, int $user_id, array $data = [] ): array {
        global $wpdb;

        $society = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_societies WHERE access_code=%s",
            strtoupper( trim( $access_code ) )
        ) );
        if ( ! $society ) { return [ 'error' => 'Invalid access code. Please check with your RWA secretary.' ]; }

        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_society_members WHERE society_id=%d AND user_id=%d",
            $society->id, $user_id
        ) );
        if ( $existing ) { return [ 'success' => true, 'already_member' => true, 'society' => $society ]; }

        $wpdb->insert( $wpdb->prefix . 'gs_society_members', [
            'society_id'  => (int) $society->id,
            'user_id'     => $user_id,
            'flat_number' => sanitize_text_field( $data['flat_number'] ?? '' ),
            'role'        => 'resident',
            'joined_at'   => current_time( 'mysql' ),
        ] );

        // ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "No bulk-invite/
        // CSV import of RWA residents"). If this join matches a pending
        // invite for this society (matched by the joining user's own
        // account email — the only identifier both sides reliably share,
        // since the invite was sent to that address), promote it to
        // 'joined' so the RWA admin's invite tracker reflects reality.
        // Best-effort only: a resident who joins with a different email
        // than the one they were invited on simply stays a normal member
        // with no invite record touched — never blocks or alters the join.
        $joiner = get_userdata( $user_id );
        if ( $joiner && $joiner->user_email ) {
            $wpdb->update( $wpdb->prefix . 'gs_society_invites',
                [ 'status' => 'joined', 'joined_at' => current_time( 'mysql' ) ],
                [ 'society_id' => (int) $society->id, 'email' => $joiner->user_email, 'status' => 'pending' ]
            );
        }

        return [ 'success' => true, 'society' => $society ];
    }

    /**
     * ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "No bulk-invite/CSV
     * import of RWA residents — one-at-a-time self-service via access code
     * only"). Real, non-workaround fix: doesn't change how residents join
     * (still self-service via access code — join_society() above is
     * untouched apart from the promotion hook), just gives the RWA admin a
     * way to REACH many residents at once and TRACK who has actually
     * joined, which is what the finding actually named as missing.
     *
     * $rows: array of ['name'=>, 'email'=>, 'phone'=>, 'flat_number'=>].
     * Returns a summary so the caller can report exactly what happened,
     * rather than a bare success/fail.
     */
    public static function bulk_invite_residents( int $society_id, array $rows, int $invited_by ): array {
        global $wpdb;
        $society = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}gs_societies WHERE id=%d", $society_id ) );
        if ( ! $society ) { return [ 'error' => 'Society not found.' ]; }

        $invited = 0; $skipped_invalid = 0; $skipped_existing_member = 0; $updated_pending = 0;
        $join_url = home_url( '/rwa/dashboard/' );

        foreach ( $rows as $row ) {
            $email = sanitize_email( $row['email'] ?? '' );
            if ( ! $email || ! is_email( $email ) ) { $skipped_invalid++; continue; }
            $name        = sanitize_text_field( $row['name'] ?? '' );
            $phone       = sanitize_text_field( $row['phone'] ?? '' );
            $flat_number = sanitize_text_field( $row['flat_number'] ?? '' );

            // Skip anyone who's already a real member of this society (by
            // matching their WordPress account email, if one exists) —
            // no point inviting someone who's already in.
            $already_member = $wpdb->get_var( $wpdb->prepare(
                "SELECT sm.id FROM {$wpdb->prefix}gs_society_members sm
                 JOIN {$wpdb->users} u ON u.ID = sm.user_id
                 WHERE sm.society_id=%d AND u.user_email=%s",
                $society_id, $email
            ) );
            if ( $already_member ) { $skipped_existing_member++; continue; }

            $existing_invite = $wpdb->get_row( $wpdb->prepare(
                "SELECT id, status FROM {$wpdb->prefix}gs_society_invites WHERE society_id=%d AND email=%s",
                $society_id, $email
            ) );
            if ( $existing_invite ) {
                if ( $existing_invite->status === 'joined' ) { $skipped_existing_member++; continue; }
                // Already invited and still pending — refresh their details
                // (flat/name may have been corrected in a re-upload) and
                // re-send rather than creating a duplicate row (the
                // uniq_society_email key would reject a second insert
                // anyway — this keeps the CSV re-upload path idempotent).
                $wpdb->update( $wpdb->prefix . 'gs_society_invites', [
                    'name' => $name, 'phone' => $phone, 'flat_number' => $flat_number,
                    'invited_by' => $invited_by, 'invited_at' => current_time( 'mysql' ),
                ], [ 'id' => (int) $existing_invite->id ] );
                $updated_pending++;
            } else {
                $wpdb->insert( $wpdb->prefix . 'gs_society_invites', [
                    'society_id' => $society_id, 'name' => $name, 'email' => $email,
                    'phone' => $phone, 'flat_number' => $flat_number,
                    'status' => 'pending', 'invited_by' => $invited_by,
                    'invited_at' => current_time( 'mysql' ),
                ] );
                $invited++;
            }

            \GoodService\Service\EmailService::send( $email, 'rwa_resident_invite', [
                'resident_name' => $name ?: 'there',
                'society_name'  => $society->name,
                'flat_number'   => $flat_number ?: '—',
                'access_code'   => $society->access_code,
                'join_url'      => $join_url,
            ] );
        }

        return [
            'success' => true,
            'invited' => $invited,
            'resent'  => $updated_pending,
            'skipped_invalid' => $skipped_invalid,
            'skipped_existing' => $skipped_existing_member,
        ];
    }

    /** Get approved vendors for a society (for resident shortlist). */
    public static function get_society_vendors( int $society_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT sv.*, li.title, li.slug, li.avg_rating, li.cover_photo,
                    vp.response_rate, vp.business_name
             FROM {$wpdb->prefix}gs_society_vendors sv
             JOIN {$wpdb->prefix}gs_listings li ON li.id = sv.listing_id
             JOIN {$wpdb->prefix}gs_vendor_profiles vp ON vp.id = sv.vendor_id
             WHERE sv.society_id=%d
             ORDER BY FIELD(sv.tier,'preferred','approved','emergency'), li.avg_rating DESC
             LIMIT 200",
            $society_id
        ) ) ?: [];
    }

    /** RWA admin approves a vendor for their society. */
    public static function approve_vendor( int $society_id, int $vendor_id, int $listing_id, int $approved_by, array $data = [] ): void {
        global $wpdb;
        $wpdb->replace( $wpdb->prefix . 'gs_society_vendors', [
            'society_id'       => $society_id,
            'vendor_id'        => $vendor_id,
            'listing_id'       => $listing_id,
            'approved_by'      => $approved_by,
            'tier'             => in_array( $data['tier'] ?? '', [ 'preferred', 'approved', 'emergency' ], true )
                                  ? $data['tier'] : 'approved',
            'notes'            => sanitize_textarea_field( $data['notes'] ?? '' ),
            'negotiated_rate'  => ! empty( $data['negotiated_rate'] ) ? (float) $data['negotiated_rate'] : null,
            'approved_at'      => current_time( 'mysql' ),
        ] );
    }

    /**
     * ENTERPRISE-AUDIT FIX (Part 4 §4, Medium: "RWA Overview tab has no
     * recent-activity feed — secretary can't see what's happened without
     * digging into each sub-tab"). Real fix, not a fabricated log: merges
     * three genuine, already-persisted event sources for this society —
     * member joins (gs_society_members.joined_at), vendor approvals
     * (gs_society_vendors.approved_at, which already exists per-row and
     * needs no parsing of activity_log's free-text description), and
     * admin-side actions already written to gs_activity_log with
     * object_type='society' (covers remove_member/transfer_admin/
     * bulk_invite — see AjaxController's gs_log_activity() calls) — then
     * sorts the merged set by timestamp and returns the newest $limit.
     */
    public static function get_recent_activity( int $society_id, int $limit = 15 ): array {
        global $wpdb;
        $events = [];

        $joins = $wpdb->get_results( $wpdb->prepare(
            "SELECT sm.joined_at AS ts, sm.flat_number, u.display_name
             FROM {$wpdb->prefix}gs_society_members sm
             LEFT JOIN {$wpdb->users} u ON u.ID = sm.user_id
             WHERE sm.society_id=%d ORDER BY sm.joined_at DESC LIMIT %d",
            $society_id, $limit
        ) ) ?: [];
        foreach ( $joins as $j ) {
            if ( ! $j->ts ) continue;
            $who = $j->display_name ?: 'A resident';
            $events[] = [
                'ts'   => $j->ts,
                'icon' => '👋',
                'text' => $who . ( $j->flat_number ? " (Flat {$j->flat_number})" : '' ) . ' joined the society',
            ];
        }

        $approvals = $wpdb->get_results( $wpdb->prepare(
            "SELECT sv.approved_at AS ts, sv.tier, li.title
             FROM {$wpdb->prefix}gs_society_vendors sv
             LEFT JOIN {$wpdb->prefix}gs_listings li ON li.id = sv.listing_id
             WHERE sv.society_id=%d ORDER BY sv.approved_at DESC LIMIT %d",
            $society_id, $limit
        ) ) ?: [];
        foreach ( $approvals as $a ) {
            if ( ! $a->ts ) continue;
            $events[] = [
                'ts'   => $a->ts,
                'icon' => '🏪',
                'text' => esc_html( $a->title ?: 'A vendor' ) . ' approved (' . esc_html( $a->tier ?: 'approved' ) . ')',
            ];
        }

        $admin_actions = $wpdb->get_results( $wpdb->prepare(
            "SELECT created_at AS ts, action, description
             FROM {$wpdb->prefix}gs_activity_log
             WHERE object_type='society' AND object_id=%d
             ORDER BY created_at DESC LIMIT %d",
            $society_id, $limit
        ) ) ?: [];
        foreach ( $admin_actions as $a ) {
            if ( ! $a->ts ) continue;
            $events[] = [
                'ts'   => $a->ts,
                'icon' => '📋',
                'text' => $a->description ?: $a->action,
            ];
        }

        usort( $events, fn( $x, $y ) => strtotime( $y['ts'] ) <=> strtotime( $x['ts'] ) );
        return array_slice( $events, 0, $limit );
    }

    /** Get the society a user belongs to (first match). */
    public static function get_user_society( int $user_id ): ?\stdClass {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT s.* FROM {$wpdb->prefix}gs_societies s
             JOIN {$wpdb->prefix}gs_society_members sm ON sm.society_id=s.id
             WHERE sm.user_id=%d LIMIT 1",
            $user_id
        ) );
    }

    // FIXED — audit gap "RWA dashboard: no member removal or role transfer".
    // The Members tab (templates/pages/rwa-dashboard.php) previously only ever
    // rendered a read-only list — there was no backend path at all to remove a
    // resident or to hand off the admin/secretary role, so a secretary who
    // wanted to correct a wrong join, remove a moved-out resident, or step
    // down had no way to do so short of a developer running raw SQL.

    /**
     * Remove a member from a society. The society's admin (admin_user_id on
     * gs_societies) is the only actor who may call this — enforced by the
     * caller in AjaxController, not here, so this stays a pure data operation.
     * Refuses to remove the society's own admin: an admin must transfer_admin()
     * to someone else first, so a society can never be left admin-less.
     */
    public static function remove_member( int $society_id, int $member_user_id ): array {
        global $wpdb;
        $society = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_societies WHERE id=%d", $society_id
        ) );
        if ( ! $society ) { return [ 'error' => 'Society not found.' ]; }
        if ( (int) $society->admin_user_id === $member_user_id ) {
            return [ 'error' => 'The society admin cannot be removed directly — transfer the admin role to another member first.' ];
        }
        $member = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_society_members WHERE society_id=%d AND user_id=%d",
            $society_id, $member_user_id
        ) );
        if ( ! $member ) { return [ 'error' => 'This person is not a member of your society.' ]; }
        $deleted = $wpdb->delete( $wpdb->prefix . 'gs_society_members', [ 'id' => (int) $member->id ] );
        if ( $deleted === false ) { return [ 'error' => 'Database error — could not remove the member. Please try again.' ]; }
        return [ 'success' => true ];
    }

    /**
     * Transfer the society admin/secretary role to another existing member.
     * The new admin must already be a member of the society (join first, then
     * be promoted) — this deliberately does not silently add them, so a
     * mistyped user can never end up owning someone else's society.
     * Updates both gs_societies.admin_user_id (the authoritative admin flag
     * used by the dashboard's $is_admin check) and the member row's own
     * `role` column, and demotes the outgoing admin's member row to
     * 'resident' so exactly one admin role column is ever authoritative.
     */
    public static function transfer_admin( int $society_id, int $new_admin_user_id, int $current_admin_id ): array {
        global $wpdb;
        $society = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_societies WHERE id=%d", $society_id
        ) );
        if ( ! $society ) { return [ 'error' => 'Society not found.' ]; }
        if ( (int) $society->admin_user_id !== $current_admin_id ) {
            return [ 'error' => 'Only the current society admin can transfer this role.' ];
        }
        if ( $new_admin_user_id === $current_admin_id ) {
            return [ 'error' => 'You are already the admin of this society.' ];
        }
        $new_member = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_society_members WHERE society_id=%d AND user_id=%d",
            $society_id, $new_admin_user_id
        ) );
        if ( ! $new_member ) { return [ 'error' => 'That person must join the society before they can become its admin.' ]; }

        $updated = $wpdb->update( $wpdb->prefix . 'gs_societies',
            [ 'admin_user_id' => $new_admin_user_id ],
            [ 'id' => $society_id ]
        );
        if ( $updated === false ) { return [ 'error' => 'Database error — could not transfer the admin role. Please try again.' ]; }

        $wpdb->update( $wpdb->prefix . 'gs_society_members', [ 'role' => 'admin' ],
            [ 'society_id' => $society_id, 'user_id' => $new_admin_user_id ] );
        $wpdb->update( $wpdb->prefix . 'gs_society_members', [ 'role' => 'resident' ],
            [ 'society_id' => $society_id, 'user_id' => $current_admin_id ] );

        // The gs_rwa_admin WordPress role/capability set follows the same
        // rule as create_society(): grant it to the incoming admin. The
        // outgoing admin keeps the role (harmless — dashboard access is
        // gated by gs_societies.admin_user_id, not the WP role alone, and
        // they may administer another society), matching how this role is
        // granted elsewhere in this class.
        $new_user = get_user_by( 'id', $new_admin_user_id );
        if ( $new_user ) { $new_user->add_role( 'gs_rwa_admin' ); }

        return [ 'success' => true ];
    }
}
