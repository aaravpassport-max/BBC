<?php
namespace GoodService\Service;

use GoodService\Core\Config;

/**
 * EmailService — Templated transactional email sender.
 * Uses gs_email_templates table with {{token}} substitution.
 * Wraps all email in a responsive HTML master layout.
 */
final class EmailService {

    /**
     * Wires the admin-configured SMTP settings (Settings → Email / SMTP)
     * into WordPress's mail sending. Real fix — confirmed root cause of
     * OTP and other transactional emails not arriving: those settings
     * fields have always existed in the admin UI, but nothing in the
     * codebase ever read them. wp_mail() was always falling through to
     * PHP's built-in mail() function no matter what an admin entered
     * here — which silently fails or lands in spam on most modern hosts,
     * especially shared hosting and staging/testing environments that
     * have no local MTA configured at all. Only activates when smtp_host
     * is actually set — an admin who's never touched this section keeps
     * whatever mail delivery already worked before this fix (a properly
     * configured server-level MTA, or a separate SMTP plugin already
     * hooking phpmailer_init at a different priority).
     */
    public static function register(): void {
        add_action( 'phpmailer_init', [ self::class, 'configure_smtp' ] );
    }

    public static function configure_smtp( $phpmailer ): void {
        $host = trim( (string) Config::get( 'smtp_host', '' ) );
        if ( $host === '' ) { return; } // Nothing configured — leave WordPress's default mail transport alone.

        $port      = (int) Config::get( 'smtp_port', 587 );
        $username  = (string) Config::get( 'smtp_username', '' );
        $password  = (string) Config::get( 'smtp_password', '' );
        $from_name = (string) Config::get( 'smtp_from_name', Config::get( 'platform_name', get_bloginfo( 'name' ) ) );
        $from_email = (string) Config::get( 'smtp_from_email', get_option( 'admin_email' ) );

        $phpmailer->isSMTP();
        $phpmailer->Host       = $host;
        $phpmailer->Port       = $port ?: 587;
        // 465 is the conventional implicit-TLS port; anything else
        // (587, 25, etc.) uses STARTTLS instead — matches what every
        // major SMTP provider (Gmail, SendGrid, Mailgun, SES, Zoho)
        // actually expects for each port rather than hardcoding one mode.
        $phpmailer->SMTPSecure = $port === 465 ? 'ssl' : 'tls';
        $phpmailer->SMTPAutoTLS = true;

        if ( $username !== '' ) {
            $phpmailer->SMTPAuth = true;
            $phpmailer->Username = $username;
            $phpmailer->Password = $password;
        } else {
            $phpmailer->SMTPAuth = false;
        }

        if ( $from_email !== '' && is_email( $from_email ) ) {
            $phpmailer->setFrom( $from_email, $from_name ?: get_bloginfo( 'name' ) );
        }
    }

    /**
     * Send a templated email synchronously.
     *
     * @param string $to       Recipient email.
     * @param string $template Template slug (e.g. 'new_lead').
     * @param array  $vars     Token replacement map.
     */
    public static function send( string $to, string $template, array $vars = [] ): bool {
        global $wpdb;

        if ( ! is_email( $to ) ) {
            gs_write_log( "EmailService: invalid email [{$to}] for template [{$template}]" );
            return false;
        }

        $tpl = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_email_templates WHERE slug = %s AND is_active = 1",
            $template
        ) );

        if ( ! $tpl ) {
            gs_write_log( "EmailService: template not found [{$template}]" );
            return false;
        }

        // Merge universal tokens
        $vars = array_merge( [
            'site_name'       => get_bloginfo( 'name' ),
            'site_url'        => home_url( '/' ),
            'platform_name'   => Config::get( 'platform_name', get_bloginfo( 'name' ) ),
            'platform_url'    => home_url( '/' ),
            'year'            => date( 'Y' ),
            'dashboard_url'   => home_url( '/vendor/dashboard/' ),
        ], $vars );

        $subject   = self::parse( $tpl->subject, $vars );
        $body_html = self::parse( $tpl->body,    $vars );
        $full_html = self::wrap_html( $body_html );

        $from_name  = Config::get( 'platform_name', get_bloginfo( 'name' ) );
        $from_email = Config::get( 'platform_email', get_option( 'admin_email' ) );

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            "From: {$from_name} <{$from_email}>",
        ];

        $sent = wp_mail( $to, $subject, $full_html, $headers );

        if ( ! $sent ) {
            gs_write_log( "EmailService: wp_mail failed for [{$template}] to [{$to}]" );

            // H4 FIX: Escalate critical email failures so admins know immediately
            // rather than discovering them days later in the log file.
            // Only escalate for transactional emails (not bulk/marketing sends).
            $critical_templates = [
                'new_lead', 'booking_confirmed_vendor', 'booking_confirmed_client',
                'quote_accepted', 'subscription_expired', 'inquiry_confirmed_client',
                'vendor_welcome', 'admin_booking_stuck_alert',
            ];
            if ( in_array( $template, $critical_templates, true ) ) {
                \GoodService\Core\Helpers::notify_admins(
                    'email.delivery_failed',
                    '⚠️ Email Delivery Failed',
                    "Transactional email [{$template}] failed to deliver to [{$to}]. Check your SMTP/wp_mail configuration.",
                    home_url( '/admin-panel/?section=diagnostics' )
                );
            }
        }

        return (bool) $sent;
    }

    /**
     * Replace {{token}} placeholders in a string.
     */
    public static function parse( string $template, array $vars ): string {
        foreach ( $vars as $key => $value ) {
            $template = str_replace( '{{' . $key . '}}', esc_html( (string) $value ), $template );
        }
        // Remove any unfilled tokens
        $template = preg_replace( '/\{\{[a-zA-Z_]+\}\}/', '', $template );
        return $template;
    }

    /**
     * Wrap HTML body in the master email layout.
     */
    public static function wrap_html( string $body ): string {
        $brand   = Config::get( 'brand_color', '#2563EB' );
        $name    = esc_html( get_bloginfo( 'name' ) );
        $url     = esc_url( home_url( '/' ) );
        $year    = date( 'Y' );

        return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>{$name}</title>
  <style>
    body{margin:0;padding:0;background:#F1F5F9;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;color:#1E293B}
    .wrapper{max-width:600px;margin:0 auto;padding:24px 16px}
    .card{background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 16px rgba(0,0,0,.07)}
    .header{background:{$brand};padding:20px 28px}
    .header a{color:#ffffff;font-size:18px;font-weight:700;text-decoration:none}
    .body{padding:28px 28px 20px;font-size:14px;line-height:1.7}
    .footer{padding:14px 28px 20px;font-size:11px;color:#94A3B8;text-align:center;border-top:1px solid #E2E8F0}
    .btn{display:inline-block;padding:11px 22px;background:{$brand};color:#ffffff!important;border-radius:7px;text-decoration:none;font-weight:600;font-size:13px;margin:10px 0}
    table.data{width:100%;border-collapse:collapse;margin:14px 0}
    table.data th{background:#F8FAFC;padding:9px 12px;font-size:12px;text-align:left;border:1px solid #E2E8F0;font-weight:600}
    table.data td{padding:9px 12px;font-size:13px;border:1px solid #E2E8F0}
    .divider{border:none;border-top:1px solid #E2E8F0;margin:18px 0}
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="card">
      <div class="header"><a href="{$url}">{$name}</a></div>
      <div class="body">{$body}</div>
      <div class="footer">© {$name} {$year} · <a href="{$url}" style="color:#94A3B8">Visit site</a></div>
    </div>
  </div>
</body>
</html>
HTML;
    }

    /**
     * Seed all required email templates if they don't already exist.
     * Called from Seeder::run() on activation.
     */
    public static function seed_templates(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'gs_email_templates';

        $templates = [
            [
                'slug'    => 'new_lead',
                'name'    => 'New Inquiry Alert (Vendor)',
                'subject' => 'New inquiry from {{client_name}} for {{service}}',
                'body'    => '<p>Hi {{vendor_name}},</p><p>You have received a new inquiry on {{platform_name}}.</p><table class="data"><tr><th>Client</th><td>{{client_name}}</td></tr><tr><th>Phone</th><td>{{phone}}</td></tr><tr><th>Service</th><td>{{service}}</td></tr><tr><th>Message</th><td>{{message}}</td></tr></table><a href="{{dashboard_url}}" class="btn">Reply Now</a><p style="font-size:12px;color:#64748B">Vendors who reply within 1 hour win 3× more jobs.</p>',
            ],
            [
                'slug'    => 'missed_inquiry_alert',
                'name'    => 'Missed Inquiry Alert',
                'subject' => '⏰ Inquiry waiting 2+ hours — {{client_name}}',
                'body'    => '<p>Hi {{vendor_name}},</p><p>An inquiry from <strong>{{client_name}}</strong> for <strong>{{listing_title}}</strong> has been waiting over 2 hours.</p><p>Clients who do not get a reply typically contact another vendor.</p><a href="{{dashboard_url}}" class="btn">Reply Now</a>',
            ],
            [
                'slug'    => 'inquiry_confirmed_client',
                'name'    => 'Inquiry Confirmation (Client)',
                'subject' => 'Your inquiry has been sent — {{service}}',
                'body'    => '<p>Hi {{client_name}},</p><p>Your inquiry for <strong>{{service}}</strong> has been sent to <strong>{{vendor_name}}</strong>.</p><p>Most vendors reply within 1–3 hours. We will notify you the moment they respond.</p>',
            ],
            [
                'slug'    => 'vendor_replied',
                'name'    => 'Vendor Reply (Client)',
                'subject' => '{{vendor_name}} has replied to your inquiry',
                'body'    => '<p>Hi {{client_name}},</p><p><strong>{{vendor_name}}</strong> has replied to your inquiry for <strong>{{service}}</strong>.</p><blockquote style="border-left:3px solid #E2E8F0;margin:14px 0;padding:10px 14px;color:#475569">{{reply_text}}</blockquote>',
            ],
            [
                'slug'    => 'quote_sent',
                'name'    => 'Quotation Sent (Client)',
                'subject' => 'Quotation #{{quote_number}} from {{vendor_name}}',
                'body'    => '<p>Hi {{client_name}},</p><p><strong>{{vendor_name}}</strong> has sent you a quotation for <strong>{{service}}</strong>.</p><table class="data"><tr><th>Quote #</th><td>{{quote_number}}</td></tr><tr><th>Total Amount</th><td><strong>{{total_amount}}</strong></td></tr><tr><th>Valid Until</th><td>{{valid_until}}</td></tr></table><p>{{cover_note}}</p><a href="{{accept_url}}" class="btn">Accept This Quote</a>',
            ],
            [
                'slug'    => 'quote_accepted',
                'name'    => 'Quote Accepted (Vendor)',
                'subject' => '✅ {{client_name}} accepted your quote #{{quote_number}}',
                'body'    => '<p>Hi {{vendor_name}},</p><p>Great news! <strong>{{client_name}}</strong> has accepted your quotation #{{quote_number}} for <strong>{{total_amount}}</strong>.</p><p>A booking has been created. Please confirm the appointment details with the client.</p><a href="{{dashboard_url}}" class="btn">View Booking</a>',
            ],
            [
                'slug'    => 'booking_confirmed_vendor',
                'name'    => 'Booking Confirmed (Vendor)',
                'subject' => 'Booking confirmed — {{client_name}} on {{booking_date}}',
                'body'    => '<p>Hi {{vendor_name}},</p><p>A booking has been confirmed for <strong>{{booking_date}} at {{booking_time}}</strong>.</p><table class="data"><tr><th>Client</th><td>{{client_name}}</td></tr><tr><th>Phone</th><td>{{client_phone}}</td></tr><tr><th>Service</th><td>{{service}}</td></tr></table><a href="{{dashboard_url}}" class="btn">View Booking</a>',
            ],
            [
                'slug'    => 'booking_confirmed_client',
                'name'    => 'Booking Confirmed (Client)',
                'subject' => 'Your booking is confirmed — {{service}} on {{booking_date}}',
                'body'    => '<p>Hi {{client_name}},</p><p>Your booking with <strong>{{vendor_name}}</strong> is confirmed.</p><table class="data"><tr><th>Date</th><td>{{booking_date}}</td></tr><tr><th>Time</th><td>{{booking_time}}</td></tr><tr><th>Service</th><td>{{service}}</td></tr><tr><th>Vendor contact</th><td>{{vendor_phone}}</td></tr></table>',
            ],
            [
                'slug'    => 'booking_reminder',
                'name'    => 'Booking Reminder',
                'subject' => 'Reminder: {{service}} appointment in 2 hours',
                'body'    => '<p>Hi {{recipient_name}},</p><p>This is a reminder that your <strong>{{service}}</strong> appointment is scheduled for <strong>{{booking_time}} today</strong>.</p><a href="{{dashboard_url}}" class="btn">View Details</a>',
            ],
            [
                'slug'    => 'review_request',
                'name'    => 'Review Request (Client)',
                'subject' => 'How was your experience with {{vendor_name}}?',
                'body'    => '<p>Hi {{client_name}},</p><p>Your job with <strong>{{vendor_name}}</strong> has been marked complete. How was your experience?</p><a href="{{review_url}}" class="btn">Leave a Review</a><p style="font-size:11px;color:#94A3B8">This is a one-time request. We will not send follow-up reminders.</p>',
            ],
            [
                'slug'    => 'subscription_trial_ending',
                'name'    => 'Trial Ending (Vendor)',
                'subject' => 'Your GoodService trial ends in {{days_left}} days',
                'body'    => '<p>Hi {{vendor_name}},</p><p>Your free trial of the <strong>{{plan_name}}</strong> plan ends in <strong>{{days_left}} days</strong>.</p><p>After the trial, you will lose access to premium features.</p><a href="{{billing_url}}" class="btn">Upgrade Now</a>',
            ],
            [
                'slug'    => 'subscription_expired',
                'name'    => 'Subscription Expired (Vendor)',
                'subject' => 'Your {{plan_name}} subscription has expired',
                'body'    => '<p>Hi {{vendor_name}},</p><p>Your <strong>{{plan_name}}</strong> subscription expired on <strong>{{expired_on}}</strong>.</p><p>Your listing is still active but has returned to the free tier. Upgrade to restore all features.</p><a href="{{billing_url}}" class="btn">Reactivate Plan</a>',
            ],
            [
                'slug'    => 'review_request',
                'name'    => 'Review Request (Client)',
                'subject' => 'How was your experience with {{vendor_name}}?',
                'body'    => '<p>Hi {{client_name}},</p><p>Thanks for using <strong>{{vendor_name}}</strong> for <strong>{{service}}</strong>. We would love to hear how it went — it only takes a minute and really helps other customers.</p><a href="{{review_url}}" class="btn">Leave a Review</a><p style="font-size:12px;color:#64748B">This link is unique to your booking and expires in 30 days.</p>',
            ],
        ];

        foreach ( $templates as $tpl ) {
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$table} WHERE slug = %s", $tpl['slug']
            ) );
            if ( ! $exists ) {
                $wpdb->insert( $table, array_merge( $tpl, [
                    'is_active'  => 1,
                    'created_at' => current_time( 'mysql' ),
                    'updated_at' => current_time( 'mysql' ),
                ] ) );
            }
        }
    }
}
