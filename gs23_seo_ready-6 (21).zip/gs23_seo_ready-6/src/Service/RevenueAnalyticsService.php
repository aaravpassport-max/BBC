<?php
namespace GoodService\Service;

/**
 * ENTERPRISE-AUDIT FIX (Part 2, §9, High: "no MRR/ARR/churn/cohort
 * analytics beyond point-in-time totals" — the existing Subscriptions
 * screen only ever showed "This Month Revenue" / "Total Revenue", both of
 * which answer "how much came in" but not "is the business growing or
 * shrinking" or "how long do vendors actually stay paying"). This adds the
 * three standard SaaS metrics the finding names, computed directly from
 * gs_subscriptions/gs_invoices rather than a separate tracked-over-time
 * table — deliberately point-in-time-computed (not a nightly snapshot job)
 * so the numbers are always exactly consistent with the live subscription
 * rows, at the cost of being a heavier query than a pre-aggregated one;
 * acceptable given this is an admin-only screen, not a customer-facing one.
 */
final class RevenueAnalyticsService {

    /** Normalizes any subscription's billing_cycle amount to a monthly
     * figure — the one conversion every metric below depends on. A
     * 'lifetime' plan contributes 0 to MRR by design: it is a one-time
     * payment, not recurring revenue, so counting it would overstate the
     * business's actual month-over-month revenue run rate. */
    public static function monthly_equivalent( float $amount, string $billing_cycle ): float {
        return match ( $billing_cycle ) {
            'monthly'   => $amount,
            'quarterly' => $amount / 3,
            'yearly'    => $amount / 12,
            'lifetime'  => 0.0,
            default     => $amount,
        };
    }

    /** Current MRR: sum of the monthly-equivalent amount across every
     * currently active or trialing subscription. Trialing subscriptions
     * are included at their eventual paid rate — SaaS convention differs
     * here (some report "MRR" as paying-only), but for a directory with
     * short trials, excluding them would make MRR swing wildly based on
     * trial-conversion timing rather than reflecting committed revenue;
     * this is called out explicitly in the returned array via
     * 'includes_trials' => true so the admin UI can label it accurately. */
    public static function current_mrr(): float {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT amount, billing_cycle FROM {$wpdb->prefix}gs_subscriptions WHERE status IN ('active','trialing')",
            ARRAY_A
        ) ?: [];
        $mrr = 0.0;
        foreach ( $rows as $r ) {
            $mrr += self::monthly_equivalent( (float) $r['amount'], (string) $r['billing_cycle'] );
        }
        return round( $mrr, 2 );
    }

    public static function current_arr(): float {
        return round( self::current_mrr() * 12, 2 );
    }

    /**
     * Monthly churn rate for each of the last $months calendar months:
     * (subscriptions cancelled that month) / (subscriptions that were
     * active at the START of that month). A month with zero subscriptions
     * active at its start returns a null rate (not a fabricated 0%) —
     * genuinely undefined, not "no churn."
     */
    public static function monthly_churn( int $months = 6 ): array {
        global $wpdb;
        $out = [];
        for ( $i = $months - 1; $i >= 0; $i-- ) {
            $month_start = new \DateTimeImmutable( "first day of -{$i} months midnight", new \DateTimeZone( 'UTC' ) );
            $month_end   = $month_start->modify( '+1 month' );
            $label = $month_start->format( 'Y-m' );

            // Active at the START of the month: created before the month
            // started, and not yet cancelled/expired before the month started.
            $active_at_start = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}gs_subscriptions
                 WHERE created_at < %s
                   AND status != 'pending'
                   AND ( cancelled_at IS NULL OR cancelled_at >= %s )
                   AND ( expires_at   IS NULL OR expires_at   >= %s )",
                $month_start->format( 'Y-m-d H:i:s' ), $month_start->format( 'Y-m-d H:i:s' ), $month_start->format( 'Y-m-d H:i:s' )
            ) );

            $cancelled_in_month = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}gs_subscriptions
                 WHERE status = 'cancelled' AND cancelled_at >= %s AND cancelled_at < %s",
                $month_start->format( 'Y-m-d H:i:s' ), $month_end->format( 'Y-m-d H:i:s' )
            ) );

            $rate = $active_at_start > 0 ? round( $cancelled_in_month * 100 / $active_at_start, 1 ) : null;
            $out[] = [
                'month' => $label,
                'active_at_start' => $active_at_start,
                'cancelled' => $cancelled_in_month,
                'churn_rate_pct' => $rate,
            ];
        }
        return $out;
    }

    /**
     * Cohort retention: groups vendors by the calendar month their FIRST
     * subscription ever started, then for each of the following N months
     * reports what % of that cohort still had a non-cancelled/non-expired
     * subscription. Classic SaaS cohort table. Limited to the last
     * $cohort_months starting cohorts and $retention_months of tracking
     * per cohort, both capped, so this stays a bounded number of queries
     * regardless of how old the install is.
     */
    public static function cohort_retention( int $cohort_months = 6, int $retention_months = 6 ): array {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        // Each vendor's cohort = the month of their EARLIEST subscription
        // row (first-ever paid or trial signup), not every subscription
        // they've ever had — a vendor who churned and re-subscribed still
        // belongs to their original cohort.
        $first_subs = $wpdb->get_results(
            "SELECT vendor_id, MIN(created_at) AS first_at FROM {$pfx}subscriptions GROUP BY vendor_id",
            ARRAY_A
        ) ?: [];

        $cohorts = []; // 'Y-m' => [vendor_id, ...]
        $cutoff = new \DateTimeImmutable( "first day of -" . ( $cohort_months - 1 ) . " months midnight", new \DateTimeZone( 'UTC' ) );
        foreach ( $first_subs as $row ) {
            $ts = strtotime( (string) $row['first_at'] );
            if ( $ts === false || $ts < $cutoff->getTimestamp() ) { continue; }
            $label = gmdate( 'Y-m', $ts );
            $cohorts[ $label ][] = (int) $row['vendor_id'];
        }
        ksort( $cohorts );

        $out = [];
        foreach ( $cohorts as $label => $vendor_ids ) {
            $cohort_size = count( $vendor_ids );
            $ids_sql = implode( ',', array_map( 'intval', $vendor_ids ) );
            $cohort_start = \DateTimeImmutable::createFromFormat( 'Y-m-d', $label . '-01', new \DateTimeZone( 'UTC' ) );
            $row = [ 'cohort' => $label, 'size' => $cohort_size, 'retention' => [] ];

            for ( $m = 0; $m <= $retention_months; $m++ ) {
                $check_at = $cohort_start->modify( "+{$m} months" );
                if ( $check_at > new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) ) ) {
                    $row['retention'][] = null; // future month for this cohort — not yet knowable
                    continue;
                }
                $check_str = $check_at->format( 'Y-m-d H:i:s' );
                // "Still retained at month m" = has a subscription row that
                // was active (not yet cancelled/expired) AT that point in time.
                $retained = $ids_sql ? (int) $wpdb->get_var(
                    "SELECT COUNT(DISTINCT vendor_id) FROM {$pfx}subscriptions
                     WHERE vendor_id IN ({$ids_sql})
                       AND created_at <= '{$check_str}'
                       AND ( cancelled_at IS NULL OR cancelled_at > '{$check_str}' )
                       AND ( expires_at   IS NULL OR expires_at   > '{$check_str}' )
                       AND status != 'pending'"
                ) : 0;
                $row['retention'][] = $cohort_size > 0 ? round( $retained * 100 / $cohort_size, 1 ) : null;
            }
            $out[] = $row;
        }
        return $out;
    }

    /** Convenience bundle for the admin AJAX endpoint — one call, all
     * three metrics, so the panel loads in a single round-trip. */
    public static function summary(): array {
        return [
            'mrr' => self::current_mrr(),
            'arr' => self::current_arr(),
            'includes_trials' => true,
            'churn' => self::monthly_churn( 6 ),
            'cohorts' => self::cohort_retention( 6, 6 ),
        ];
    }
}
