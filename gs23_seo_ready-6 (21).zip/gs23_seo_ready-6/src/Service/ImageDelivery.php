<?php
namespace GoodService\Service;

/**
 * ImageDelivery — GoodService Platform
 *
 * Intercepts the ENTIRE page HTML output via PHP output buffering and:
 *
 *  1. Wraps every <img> tag in a <picture> element with AVIF + WebP <source> tags
 *     so browsers automatically receive the smallest format they support —
 *     with zero changes to any template file.
 *
 *  2. Adds native lazy loading (loading="lazy" decoding="async") to all
 *     below-the-fold images automatically.
 *
 *  3. Detects the Largest Contentful Paint (LCP) image — the first real
 *     content image on the page — and injects a <link rel="preload"> in <head>
 *     so browsers start fetching it before parsing the rest of the document.
 *     This is the single highest-impact Core Web Vitals optimisation available.
 *
 *  4. Adds explicit width + height attributes where missing to prevent
 *     Cumulative Layout Shift (CLS).
 *
 * Why output buffering instead of WordPress filters?
 *   GoodService uses its own router (template_redirect) and renders pages via
 *   custom PHP templates that never call wp_get_attachment_image() or
 *   the_content(). Standard WordPress image filters never fire on GoodService
 *   pages. Output buffering captures everything regardless of how it was rendered.
 *
 * Registration: Plugin::boot() calls ImageDelivery::register() which hooks
 *   ob_start() at priority 0 on template_redirect (before the Router at priority 1).
 *   PHP flushes the buffer (calling our callback) when the Router calls exit.
 */
final class ImageDelivery {

    private static string $upload_path = '';
    private static string $upload_url  = '';

    // ── Boot ──────────────────────────────────────────────────────────────────

    public static function register(): void {
        // Never run in WP admin or on REST API calls.
        if ( is_admin() ) return;
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) return;
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) return;

        // Cache upload dir (cheap — called once per request).
        $up                 = wp_upload_dir();
        self::$upload_path  = untrailingslashit( $up['basedir'] );
        self::$upload_url   = untrailingslashit( $up['baseurl'] );

        // Priority -10 — must fire before ALL Router handlers (intercept_vendor_paths
        // and intercept_404_for_listing are at priority 0 and call exit immediately).
        // A lower number = runs earlier. -10 guarantees ob_start() wraps everything.
        add_action( 'template_redirect', [ self::class, 'start_buffer' ], -10 );
    }

    public static function start_buffer(): void {
        ob_start( [ self::class, 'process' ] );
    }

    // ── Main output processor ─────────────────────────────────────────────────

    /**
     * Called by PHP when the output buffer is flushed (on exit or ob_end_flush).
     * Receives the complete HTML page as a string, returns the modified HTML.
     */
    public static function process( string $html ): string {
        if ( empty( $html ) ) return $html;

        // Only process full HTML documents.
        if ( stripos( $html, '<html' ) === false && stripos( $html, '<!DOCTYPE' ) === false ) {
            return $html;
        }

        // ── 1. Find LCP image → inject preload in <head> ──────────────────────
        $html = self::inject_lcp_preload( $html );

        // ── 2. Wrap <img> tags in <picture> with AVIF + WebP sources ─────────
        $html = self::wrap_images( $html );

        return $html;
    }

    // ── Step 1: LCP preload ───────────────────────────────────────────────────

    /**
     * Finds the first meaningful content <img> in the page body and injects
     * a <link rel="preload"> into <head> so the browser fetches it immediately.
     *
     * Also adds fetchpriority="high" loading="eager" to that first image.
     * All other images get loading="lazy" decoding="async".
     */
    private static function inject_lcp_preload( string $html ): string {
        // Extract body content (everything after <body...>).
        if ( ! preg_match( '/<body[^>]*>/i', $html, $m, PREG_OFFSET_CAPTURE ) ) {
            return $html;
        }
        $body_start = $m[0][1] + strlen( $m[0][0] );
        $body_html  = substr( $html, $body_start );

        // Find all <img> tags in the body.
        if ( ! preg_match_all( '/<img\b[^>]*>/i', $body_html, $img_matches ) ) {
            return $html;
        }

        $lcp_img = null;
        $lcp_src = null;

        foreach ( $img_matches[0] as $img_tag ) {
            // Skip tiny decorative images (icons, avatars) — look for real content images.
            if ( preg_match( '/\b(width|height)=["\'](\d+)["\']/', $img_tag, $dim ) ) {
                if ( (int) $dim[2] < 100 ) continue; // Too small to be LCP
            }

            if ( ! preg_match( '/\bsrc=["\']([^"\']+)["\']/', $img_tag, $src_m ) ) continue;

            $src = $src_m[1];

            // Skip data URIs, SVGs, and external images.
            if ( str_starts_with( $src, 'data:' ) ) continue;
            if ( str_contains( $src, '.svg' ) ) continue;
            if ( ! self::is_local_url( $src ) ) continue;

            $lcp_img = $img_tag;
            $lcp_src = $src;
            break;
        }

        if ( ! $lcp_src ) return $html;

        // Determine best preload URL: AVIF if it exists, else WebP, else original.
        $path = self::url_to_path( $lcp_src );
        if ( $path ) {
            $avif_path = ImageOptimizer::avif_path_from( $path );
            if ( file_exists( $avif_path ) && filesize( $avif_path ) > 0 ) {
                $preload_url  = ImageOptimizer::avif_url_from( $lcp_src );
                $preload_type = 'image/avif';
            } else {
                $preload_url  = $lcp_src;
                $preload_type = self::mime_from_url( $lcp_src );
            }
        } else {
            $preload_url  = $lcp_src;
            $preload_type = self::mime_from_url( $lcp_src );
        }

        $preload_tag = '<link rel="preload" as="image" href="' . esc_url( $preload_url ) . '" type="' . esc_attr( $preload_type ) . '" fetchpriority="high">' . "\n";

        // Inject preload before the REAL, genuine </head> tag only — confirmed
        // real, serious bug found via a live console error: the previous,
        // unscoped str_ireplace() across the entire page matched the
        // literal text "</head>" anywhere at all, including inside any
        // JavaScript string on the page (e.g. a diagnostic tool writing a
        // fake HTML document into a popup), silently injecting a real
        // <link> tag and a real newline into the middle of that string and
        // breaking it. Scoped to the real, genuine head region only, the
        // same safe pattern already used for the body/image search above.
        if ( preg_match( '/<head[^>]*>/i', $html, $head_m, PREG_OFFSET_CAPTURE ) ) {
            $real_head_start = $head_m[0][1] + strlen( $head_m[0][0] );
            $real_head_close_pos = stripos( $html, '</head>', $real_head_start );
            if ( $real_head_close_pos !== false ) {
                $html = substr( $html, 0, $real_head_close_pos )
                      . $preload_tag
                      . substr( $html, $real_head_close_pos );
            }
        }

        // Add eager loading + high priority to the LCP img tag itself.
        $lcp_img_modified = self::add_loading_attr( $lcp_img, 'eager', true );
        $html = str_replace( $lcp_img, $lcp_img_modified, $html );

        return $html;
    }

    // ── Step 2: Wrap images in <picture> ─────────────────────────────────────

    /**
     * Replaces all <img> tags (not already inside <picture>) with <picture>
     * elements containing AVIF and WebP <source> tags.
     *
     * Also applies lazy loading to all non-LCP images.
     */
    private static function wrap_images( string $html ): string {
        // Protect existing <picture> blocks — replace with placeholders.
        $pictures    = [];
        $placeholder = "\x00GSPIC%d\x00";

        $html = preg_replace_callback(
            '/<picture[\s\S]*?<\/picture>/i',
            static function ( array $m ) use ( &$pictures, $placeholder ): string {
                $idx             = count( $pictures );
                $pictures[ $idx ] = $m[0];
                return sprintf( $placeholder, $idx );
            },
            $html
        );

        // Protect <script> blocks — JS template literals and innerHTML strings inside
        // scripts can contain literal '<img' text. Without protection the regex below
        // wraps them in <picture> tags, producing invalid JS syntax and breaking all
        // dynamic rendering (dashboard upload previews, archive card rendering, etc.)
        $scripts = [];
        $sc_ph   = "\x00GSSCRIPT%d\x00";
        $html = preg_replace_callback(
            '/<script[\s\S]*?<\/script>/i',
            static function ( array $m ) use ( &$scripts, &$sc_ph ): string {
                $idx = count( $scripts );
                $scripts[ $idx ] = $m[0];
                return sprintf( $sc_ph, $idx );
            },
            $html
        );

        // Also protect <noscript> blocks (they contain raw <img> for no-JS fallback).
        $noscripts   = [];
        $ns_ph       = "\x00GSNS%d\x00";

        $html = preg_replace_callback(
            '/<noscript[\s\S]*?<\/noscript>/i',
            static function ( array $m ) use ( &$noscripts, &$ns_ph ): string {
                $idx               = count( $noscripts );
                $noscripts[ $idx ] = $m[0];
                return sprintf( $ns_ph, $idx );
            },
            $html
        );

        // Process remaining <img> tags.
        $img_count = 0;
        $html = preg_replace_callback(
            '/<img\b[^>]*>/i',
            static function ( array $m ) use ( &$img_count ): string {
                $img_count++;
                return self::build_picture( $m[0], $img_count );
            },
            $html
        );

        // Restore noscript blocks.
        foreach ( $noscripts as $idx => $block ) {
            $html = str_replace( sprintf( $ns_ph, $idx ), $block, $html );
        }

        // Restore script blocks (must come after picture+noscript restores to
        // avoid any placeholder text accidentally appearing inside a restored script).
        foreach ( $scripts as $idx => $block ) {
            $html = str_replace( sprintf( $sc_ph, $idx ), $block, $html );
        }

        // Restore picture blocks.
        foreach ( $pictures as $idx => $block ) {
            $html = str_replace( sprintf( $placeholder, $idx ), $block, $html );
        }

        return $html;
    }

    /**
     * Converts a single <img> tag into a <picture> element with AVIF + WebP sources.
     * Falls back to returning the original <img> if no modern formats are available.
     *
     * @param string $img_tag   The raw <img ...> HTML string.
     * @param int    $img_count 1-based position of this image on the page.
     */
    private static function build_picture( string $img_tag, int $img_count ): string {
        // Extract src.
        if ( ! preg_match( '/\bsrc=["\']([^"\']+)["\']/', $img_tag, $src_m ) ) {
            return $img_tag;
        }
        $src = $src_m[1];

        // Skip data URIs and SVGs.
        if ( str_starts_with( $src, 'data:' ) || str_contains( $src, '.svg' ) ) {
            return $img_tag;
        }

        // Apply lazy / eager loading (img_count=1 is the LCP — already handled above,
        // but we check fetchpriority to avoid double-applying).
        if ( stripos( $img_tag, 'fetchpriority' ) === false ) {
            $img_tag = self::add_loading_attr( $img_tag, 'lazy', false );
        }

        // Only add <source> elements for local uploads.
        if ( ! self::is_local_url( $src ) ) {
            return $img_tag;
        }

        $path = self::url_to_path( $src );
        if ( ! $path ) return $img_tag;

        $sources = '';

        // AVIF source.
        $avif_path = ImageOptimizer::avif_path_from( $path );
        if ( file_exists( $avif_path ) && filesize( $avif_path ) > 0 ) {
            $avif_url = ImageOptimizer::avif_url_from( $src );
            $sources .= '<source srcset="' . esc_url( $avif_url ) . '" type="image/avif">' . "\n";
        }

        // WebP source — if src is already .webp, use it; otherwise look for sidecar.
        $webp_src = '';
        if ( str_ends_with( strtolower( $src ), '.webp' ) ) {
            $webp_src = $src; // Already WebP — use as fallback source.
        } else {
            $webp_path = preg_replace( '/\.[a-z0-9]+$/i', '.webp', $path );
            if ( file_exists( $webp_path ) && filesize( $webp_path ) > 0 ) {
                $webp_src = preg_replace( '/\.[a-z0-9]+$/i', '.webp', $src );
            }
        }

        if ( $webp_src && $webp_src !== $src ) {
            $sources .= '<source srcset="' . esc_url( $webp_src ) . '" type="image/webp">' . "\n";
        }

        // No modern format sources found — return img with just lazy loading applied.
        if ( empty( $sources ) ) return $img_tag;

        return "<picture>\n{$sources}{$img_tag}\n</picture>";
    }

    // ── Lazy loading ──────────────────────────────────────────────────────────

    /**
     * Add or replace the loading= attribute on an <img> tag.
     * Also adds decoding="async" for non-LCP images and fetchpriority="high" for LCP.
     */
    private static function add_loading_attr( string $img_tag, string $mode, bool $is_lcp ): string {
        // Remove existing loading / decoding / fetchpriority attributes.
        $img_tag = preg_replace( '/\s+loading=["\'][^"\']*["\']/i', '', $img_tag );
        $img_tag = preg_replace( '/\s+decoding=["\'][^"\']*["\']/i', '', $img_tag );
        $img_tag = preg_replace( '/\s+fetchpriority=["\'][^"\']*["\']/i', '', $img_tag );

        if ( $is_lcp ) {
            $extra = ' loading="eager" fetchpriority="high"';
        } else {
            $extra = ' loading="lazy" decoding="async"';
        }

        // Insert before the closing > or />.
        return preg_replace( '/(\s*\/?>)$/', $extra . '$1', $img_tag );
    }

    // ── System info (used by admin dashboard) ─────────────────────────────────

    /**
     * Returns current delivery status for display in the GoodService admin panel.
     */
    public static function status(): array {
        $upload_dir = wp_upload_dir();
        $base_dir   = $upload_dir['basedir'];

        $total_images = 0;
        $avif_count   = 0;
        $webp_count   = 0;

        try {
            $it = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator( $base_dir, \FilesystemIterator::SKIP_DOTS )
            );
            foreach ( $it as $file ) {
                if ( ! $file->isFile() ) continue;
                $ext = strtolower( $file->getExtension() );
                if ( $ext === 'avif' ) { $avif_count++; continue; }
                if ( $ext === 'webp' && ! str_contains( $file->getBasename(), '_orig.' ) ) { $webp_count++; }
                if ( in_array( $ext, [ 'webp', 'jpg', 'jpeg', 'png' ], true )
                     && ! str_contains( $file->getBasename(), '_orig.' ) ) {
                    $total_images++;
                }
            }
        } catch ( \Throwable $e ) {}

        return [
            'avif_supported'   => ImageOptimizer::avif_supported(),
            'total_images'     => $total_images,
            'avif_count'       => $avif_count,
            'webp_count'       => $webp_count,
            'avif_coverage_pct'=> $total_images > 0 ? round( $avif_count / $total_images * 100 ) : 0,
        ];
    }

    // ── URL / path helpers ────────────────────────────────────────────────────

    private static function url_to_path( string $url ): ?string {
        $url_norm  = preg_replace( '/^https?:/', '', $url );
        $base_norm = preg_replace( '/^https?:/', '', self::$upload_url );

        if ( ! str_contains( $url_norm, $base_norm ) ) return null;

        $relative = ltrim( str_replace( $base_norm, '', $url_norm ), '/' );
        return self::$upload_path . DIRECTORY_SEPARATOR . $relative;
    }

    private static function is_local_url( string $url ): bool {
        if ( str_starts_with( $url, '/' ) && ! str_starts_with( $url, '//' ) ) return true;
        $base = preg_replace( '/^https?:/', '', self::$upload_url );
        $url  = preg_replace( '/^https?:/', '', $url );
        return str_contains( $url, $base );
    }

    private static function mime_from_url( string $url ): string {
        $ext = strtolower( pathinfo( parse_url( $url, PHP_URL_PATH ) ?? '', PATHINFO_EXTENSION ) );
        return match ( $ext ) {
            'avif'        => 'image/avif',
            'webp'        => 'image/webp',
            'jpg', 'jpeg' => 'image/jpeg',
            'png'         => 'image/png',
            'gif'         => 'image/gif',
            default       => 'image/*',
        };
    }
}
