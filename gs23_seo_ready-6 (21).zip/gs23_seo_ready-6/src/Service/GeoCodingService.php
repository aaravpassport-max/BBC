<?php
namespace GoodService\Service;

/**
 * GeoCodingService — enterprise hardening pass, reusable city-coordinate resolver.
 *
 * ROOT CAUSE FIXED: the Hyperlocal Demand Map admin screen used to hardcode a fixed
 * JS object of ~30 city coordinates; any city outside that list silently never
 * appeared on the map at all (it still showed correctly in the data table below,
 * making the gap easy to miss). This service is the general-purpose replacement:
 * a persistent, database-backed cache of resolved city coordinates that ANY current
 * or future feature needing "plot this city on a map" can reuse, instead of every
 * screen growing its own hardcoded list.
 *
 * Design:
 *  - Cache-first: gs_geo_cache is checked before ever making an external call.
 *  - No per-request network dependency: resolving a not-yet-cached city does NOT
 *    happen synchronously on a dashboard page load (which would make the page's
 *    load time depend on a third-party API's availability/latency). It is instead
 *    queued and resolved by a rate-limited daily cron sweep (see Cron::daily()),
 *    respecting Nominatim's usage policy (max ~1 request/second, custom User-Agent).
 *  - Graceful degradation: if the external geocoding call fails (no network, rate
 *    limited, city not found), the city is marked as a failed attempt with a
 *    retry backoff instead of being retried every single run forever, and callers
 *    are told explicitly "not yet mapped" rather than the point silently vanishing.
 *  - Seeded, not replaced: the original ~30 hardcoded coordinates are preserved as
 *    the initial cache seed (idempotent INSERT IGNORE), so existing behavior for
 *    those cities is unchanged and no re-lookup is wasted on cities we already know.
 */
final class GeoCodingService {

    private const TABLE            = 'gs_geo_cache';
    private const MAX_PER_CRON_RUN = 20;   // Nominatim usage-policy-friendly batch size
    private const RETRY_BACKOFF_DAYS = 7;  // don't hammer a city that failed to resolve

    /** The original hardcoded seed list — preserved so this migration is a pure win, not a regression. */
    private const SEED_COORDS = [
        'Delhi' => [28.6139, 77.2090], 'Mumbai' => [19.0760, 72.8777], 'Bangalore' => [12.9716, 77.5946],
        'Hyderabad' => [17.3850, 78.4867], 'Chennai' => [13.0827, 80.2707], 'Kolkata' => [22.5726, 88.3639],
        'Pune' => [18.5204, 73.8567], 'Ahmedabad' => [23.0225, 72.5714], 'Jaipur' => [26.9124, 75.7873],
        'Surat' => [21.1702, 72.8311], 'Lucknow' => [26.8467, 80.9462], 'Kanpur' => [26.4499, 80.3319],
        'Nagpur' => [21.1458, 79.0882], 'Indore' => [22.7196, 75.8577], 'Bhopal' => [23.2599, 77.4126],
        'Visakhapatnam' => [17.6868, 83.2185], 'Pimpri' => [18.6279, 73.7997], 'Patna' => [25.5941, 85.1376],
        'Vadodara' => [22.3072, 73.1812], 'Ghaziabad' => [28.6692, 77.4538], 'Ludhiana' => [30.9010, 75.8573],
        'Agra' => [27.1767, 78.0081], 'Nashik' => [19.9975, 73.7898], 'Faridabad' => [28.4089, 77.3178],
        'Meerut' => [28.9845, 77.7064], 'Rajkot' => [22.3039, 70.8022], 'Varanasi' => [25.3176, 82.9739],
        'Noida' => [28.5355, 77.3910], 'Gurgaon' => [28.4595, 77.0266], 'Navi Mumbai' => [19.0330, 73.0297],
        // Common alternate spellings — same root cause class (silent drop on name mismatch)
        // that the old hardcoded map also suffered from, closed here once and for all.
        'Bengaluru' => [12.9716, 77.5946], 'Gurugram' => [28.4595, 77.0266],
    ];

    /** Idempotently create the cache table and seed it. Safe to call on every request. */
    public static function ensure_table(): void {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) ) {
            self::seed_if_empty();
            return;
        }
        $charset = $wpdb->get_charset_collate();
        $wpdb->query( "CREATE TABLE IF NOT EXISTS {$table} (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            city_key      VARCHAR(191)    NOT NULL,
            lat           DECIMAL(9,6)    DEFAULT NULL,
            lng           DECIMAL(9,6)    DEFAULT NULL,
            status        ENUM('resolved','failed','pending') DEFAULT 'pending',
            source        VARCHAR(30)     DEFAULT 'seed',
            attempts      SMALLINT UNSIGNED DEFAULT 0,
            last_attempt_at DATETIME      DEFAULT NULL,
            created_at    DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_city (city_key)
        ) {$charset}" );
        self::seed_if_empty();
    }

    private static function seed_if_empty(): void {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        foreach ( self::SEED_COORDS as $city => $coords ) {
            $wpdb->query( $wpdb->prepare(
                "INSERT IGNORE INTO {$table} (city_key, lat, lng, status, source) VALUES (%s, %f, %f, 'resolved', 'seed')",
                strtolower( trim( $city ) ), $coords[0], $coords[1]
            ) );
        }
    }

    /**
     * Return [city => [lat, lng]] for every resolved city among the given list.
     * Cities not yet resolved are simply omitted (caller should render them as
     * "not yet mapped" rather than silently indistinguishable from a resolved
     * city that just has zero circles — see demand_map screen usage).
     */
    public static function get_resolved( array $cities ): array {
        self::ensure_table();
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $keys  = array_map( fn( $c ) => strtolower( trim( $c ) ), $cities );
        if ( ! $keys ) { return []; }
        $placeholders = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT city_key, lat, lng FROM {$table} WHERE status='resolved' AND city_key IN ({$placeholders})",
            ...$keys
        ) );
        $out = [];
        // Map back to the ORIGINAL city casing the caller passed in, not the lowercased key,
        // so display labels stay exactly as they appear in the leads table.
        $orig_by_key = [];
        foreach ( $cities as $c ) { $orig_by_key[ strtolower( trim( $c ) ) ] = $c; }
        foreach ( $rows as $r ) {
            $orig = $orig_by_key[ $r->city_key ] ?? $r->city_key;
            $out[ $orig ] = [ (float) $r->lat, (float) $r->lng ];
        }
        return $out;
    }

    /** Which of the given cities have never been attempted or resolved at all. */
    public static function get_unmapped( array $cities ): array {
        self::ensure_table();
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $keys  = array_map( fn( $c ) => strtolower( trim( $c ) ), $cities );
        if ( ! $keys ) { return []; }
        $placeholders = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
        $resolved_keys = $wpdb->get_col( $wpdb->prepare(
            "SELECT city_key FROM {$table} WHERE status='resolved' AND city_key IN ({$placeholders})",
            ...$keys
        ) );
        $resolved_set = array_flip( $resolved_keys );
        $unmapped = [];
        foreach ( $cities as $c ) {
            if ( ! isset( $resolved_set[ strtolower( trim( $c ) ) ] ) ) { $unmapped[] = $c; }
        }
        return $unmapped;
    }

    /**
     * Cron-driven batch resolver. Rate-limited and failure-tolerant: never throws,
     * never blocks a page request, and backs off on cities that repeatedly fail
     * to resolve instead of retrying them every single run.
     *
     * @param array $candidate_cities Cities seen in recent data that may need geocoding.
     */
    public static function resolve_missing_batch( array $candidate_cities ): void {
        self::ensure_table();
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;

        foreach ( array_unique( $candidate_cities ) as $city ) {
            $city = trim( (string) $city );
            if ( $city === '' ) { continue; }
            $key = strtolower( $city );
            $wpdb->query( $wpdb->prepare(
                "INSERT IGNORE INTO {$table} (city_key, status) VALUES (%s, 'pending')", $key
            ) );
        }

        // Pull a rate-limit-safe batch of pending/failed-and-eligible-for-retry rows.
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, city_key FROM {$table}
             WHERE status='pending'
                OR (status='failed' AND last_attempt_at < DATE_SUB(NOW(), INTERVAL %d DAY))
             ORDER BY attempts ASC, id ASC
             LIMIT %d",
            self::RETRY_BACKOFF_DAYS, self::MAX_PER_CRON_RUN
        ) );

        foreach ( $rows as $row ) {
            // Nominatim usage policy: max 1 request/second, identify via User-Agent.
            usleep( 1100000 );
            $result = self::geocode_via_nominatim( $row->city_key );
            if ( $result ) {
                $wpdb->update( $table, [
                    'lat' => $result[0], 'lng' => $result[1], 'status' => 'resolved',
                    'source' => 'nominatim', 'last_attempt_at' => current_time( 'mysql' ),
                ], [ 'id' => $row->id ] );
            } else {
                $wpdb->query( $wpdb->prepare(
                    "UPDATE {$table} SET status='failed', attempts=attempts+1, last_attempt_at=%s WHERE id=%d",
                    current_time( 'mysql' ), $row->id
                ) );
            }
        }
    }

    /** Single geocoding call, hardened against every network/parsing failure mode. */
    private static function geocode_via_nominatim( string $city_key ): ?array {
        if ( ! function_exists( 'wp_remote_get' ) ) { return null; }
        $url = 'https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=in&q=' . rawurlencode( $city_key );
        $response = wp_remote_get( $url, [
            'timeout'    => 8,
            'user-agent' => 'GoodServicePlatform/1.0 (admin-demand-map-geocoder)',
        ] );
        if ( is_wp_error( $response ) ) {
            gs_write_log( 'GeoCodingService: request failed for "' . $city_key . '": ' . $response->get_error_message(), 'WARNING' );
            return null;
        }
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) { return null; }
        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( ! is_array( $body ) || empty( $body[0]['lat'] ) || empty( $body[0]['lon'] ) ) { return null; }
        $lat = (float) $body[0]['lat'];
        $lng = (float) $body[0]['lon'];
        // Sanity-bound to the Indian subcontinent so a malformed/ambiguous result
        // (e.g. a same-named town in another country) never silently plots wrong.
        if ( $lat < 6 || $lat > 38 || $lng < 68 || $lng > 98 ) { return null; }
        return [ $lat, $lng ];
    }
}
