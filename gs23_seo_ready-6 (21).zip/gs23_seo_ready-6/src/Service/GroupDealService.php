<?php
namespace GoodService\Service;

/**
 * GroupDealService — Colony Deals & Flash Slots (Moat 2)
 * Aggregate demand from multiple clients in the same area for discounted group bookings.
 * Flash Slots let vendors fill cancelled calendar slots at a discount.
 */
final class GroupDealService {

    /** Create a new group deal (vendor-initiated). */
    public static function create_deal( int $vendor_id, int $listing_id, array $data ): string {
        global $wpdb;
        $deal_id = wp_generate_uuid4();
        $wpdb->insert( $wpdb->prefix . 'gs_group_deals', [
            'id'             => $deal_id,
            'vendor_id'      => $vendor_id,
            'listing_id'     => $listing_id,
            'title'          => sanitize_text_field( $data['title'] ?? '' ),
            'description'    => sanitize_textarea_field( $data['description'] ?? '' ),
            'location_id'    => (int) ( $data['location_id'] ?? 0 ),
            'colony_name'    => sanitize_text_field( $data['colony_name'] ?? '' ),
            'service_date'   => sanitize_text_field( $data['service_date'] ?? '' ),
            'original_price' => (float) ( $data['original_price'] ?? 0 ),
            'deal_price'     => (float) ( $data['deal_price'] ?? 0 ),
            'min_bookings'   => max( 2, (int) ( $data['min_bookings'] ?? 3 ) ),
            'max_bookings'   => min( 50, (int) ( $data['max_bookings'] ?? 10 ) ),
            'status'         => 'forming',
            'expires_at'     => date( 'Y-m-d H:i:s', strtotime( '+7 days' ) ),
            'created_at'     => current_time( 'mysql' ),
        ] );
        return $deal_id;
    }

    /** Client joins a group deal. */
    public static function join_deal( string $deal_id, array $member_data ): array {
        global $wpdb;
        $pfx  = $wpdb->prefix;
        $deal = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$pfx}gs_group_deals WHERE id=%s AND status IN ('forming','active') AND expires_at > NOW()",
            $deal_id
        ) );
        if ( ! $deal ) { return [ 'error' => 'Deal not available or has expired.' ]; }
        if ( $deal->current_count >= $deal->max_bookings ) { return [ 'error' => 'This deal is full.' ]; }

        if ( is_user_logged_in() ) {
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$pfx}gs_group_deal_members WHERE deal_id=%s AND user_id=%d",
                $deal_id, get_current_user_id()
            ) );
            if ( $exists ) { return [ 'error' => 'You have already joined this deal.' ]; }
        }

        $wpdb->insert( "{$pfx}gs_group_deal_members", [
            'deal_id'     => $deal_id,
            'user_id'     => is_user_logged_in() ? get_current_user_id() : null,
            'name'        => sanitize_text_field( $member_data['name'] ?? '' ),
            'phone'       => sanitize_text_field( $member_data['phone'] ?? '' ),
            'flat_number' => sanitize_text_field( $member_data['flat_number'] ?? '' ),
            'status'      => 'interested',
            'joined_at'   => current_time( 'mysql' ),
        ] );

        $new_count = (int) $deal->current_count + 1;
        $new_status = $new_count >= $deal->min_bookings ? 'active' : 'forming';
        $wpdb->update( "{$pfx}gs_group_deals", [
            'current_count' => $new_count,
            'status'        => $new_status,
            'activated_at'  => $new_status === 'active' && $deal->status !== 'active' ? current_time( 'mysql' ) : $deal->activated_at,
        ], [ 'id' => $deal_id ] );

        return [ 'success' => true, 'count' => $new_count, 'min' => $deal->min_bookings, 'status' => $new_status ];
    }

    /** Create a flash slot (vendor-initiated discounted slot). */
    public static function create_flash_slot( int $vendor_id, int $listing_id, array $data ): int {
        global $wpdb;
        // Ghost-success fix: $wpdb->insert_id is not reset to 0 on a failed
        // insert (it retains the last successful insert's id from earlier in
        // the request), so returning it directly without checking the
        // insert() call's own result could silently return a stale,
        // unrelated id for a slot that was never actually created.
        $ok = $wpdb->insert( $wpdb->prefix . 'gs_flash_slots', [
            'vendor_id'      => $vendor_id,
            'listing_id'     => $listing_id,
            'slot_date'      => sanitize_text_field( $data['slot_date'] ?? date( 'Y-m-d', strtotime( '+1 day' ) ) ),
            'slot_time'      => sanitize_text_field( $data['slot_time'] ?? '10:00:00' ),
            'original_price' => (float) ( $data['original_price'] ?? 0 ),
            'flash_price'    => (float) ( $data['flash_price'] ?? 0 ),
            'discount_pct'   => min( 80, max( 5, (int) ( $data['discount_pct'] ?? 20 ) ) ),
            'radius_km'      => min( 50, max( 1, (int) ( $data['radius_km'] ?? 5 ) ) ),
            'location_id'    => (int) ( $data['location_id'] ?? 0 ),
            'status'         => 'active',
            'expires_at'     => date( 'Y-m-d H:i:s', strtotime( $data['slot_date'] . ' ' . $data['slot_time'] ) ),
            'created_at'     => current_time( 'mysql' ),
        ] );
        if ( ! $ok ) { return 0; }
        return (int) $wpdb->insert_id;
    }

    /** Book a flash slot (client). */
    public static function book_flash_slot( int $slot_id ): array {
        global $wpdb;
        $slot = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_flash_slots WHERE id=%d AND status='active' AND expires_at > NOW()",
            $slot_id
        ) );
        if ( ! $slot ) { return [ 'error' => 'Slot not available.' ]; }

        $wpdb->update( $wpdb->prefix . 'gs_flash_slots', [
            'status'        => 'booked',
            'booked_by_user'=> get_current_user_id(),
            'booked_at'     => current_time( 'mysql' ),
        ], [ 'id' => $slot_id ] );

        return [ 'success' => true, 'slot' => $slot ];
    }
}
