<?php
namespace GoodService\Service;

/**
 * VerificationService — real feature, closes a confirmed gap found
 * during Phase 1 discovery.
 *
 * DISCOVERY CONTEXT: an unusually sophisticated 8-flag verification data
 * model already existed on gs_vendor_profiles (mobile_verified,
 * email_verified, identity_verified, address_verified,
 * qualification_verified, license_verified, business_verified,
 * experience_verified) plus verification_levels and trust_score_pct
 * columns — but zero code anywhere in the codebase ever set any of
 * these flags, and nothing ever computed verification_levels or
 * trust_score_pct from them. The original audit's "no identity
 * verification pipeline" finding was really this: a complete data model
 * with no application logic behind it. This service is that missing
 * logic — not a redesign of the data model, which was already correct.
 */
class VerificationService {

    private const FLAGS = [
        'mobile_verified', 'email_verified', 'identity_verified', 'address_verified',
        'qualification_verified', 'license_verified', 'business_verified', 'experience_verified',
    ];

    /**
     * Sets one verification flag (admin review action) and recomputes
     * verification_levels (a simple count) and trust_score_pct (a
     * weighted score — identity/business/license count more than the
     * lighter-weight mobile/email checks, since those three are the
     * ones that actually establish this is a real, accountable business)
     * from the resulting flag state, in one atomic update.
     */
    public static function set_flag( int $vendor_id, string $flag, bool $value, int $reviewed_by_admin_id ): bool {
        if ( ! in_array( $flag, self::FLAGS, true ) ) {
            return false; // real validation rule: only the known 8 flags are settable this way
        }

        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        $profile = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pfx}vendor_profiles WHERE id = %d", $vendor_id ) );
        if ( ! $profile ) { return false; }

        $wpdb->update( $pfx . 'vendor_profiles', [ $flag => $value ? 1 : 0 ], [ 'id' => $vendor_id ] );

        // Re-fetch to get the authoritative post-update state rather than
        // mutating the in-memory row ourselves — avoids the class of bug
        // where a second flag change elsewhere in the same request could
        // silently be overwritten by a stale recompute.
        $profile = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pfx}vendor_profiles WHERE id = %d", $vendor_id ) );
        self::recompute( $vendor_id, $profile );

        gs_write_log( "VerificationService: {$flag} set to " . ( $value ? '1' : '0' ) . " for vendor #{$vendor_id} by admin {$reviewed_by_admin_id}", 'INFO' );

        return true;
    }

    /**
     * Weighted score, not a flat percentage-of-8 — identity, business,
     * and license verification are what actually establish this is a
     * real, accountable business (harder to fake, higher-consequence to
     * misrepresent), so they're weighted higher than mobile/email, which
     * mainly just confirm a working contact channel.
     */
    private static function recompute( int $vendor_id, object $profile ): void {
        $weights = [
            'mobile_verified'         => 5,
            'email_verified'          => 5,
            'identity_verified'       => 20,
            'address_verified'        => 10,
            'qualification_verified'  => 10,
            'license_verified'        => 20,
            'business_verified'       => 20,
            'experience_verified'     => 10,
        ]; // sums to 100

        $levels = 0;
        $score  = 0.0;
        foreach ( self::FLAGS as $flag ) {
            if ( ! empty( $profile->$flag ) ) {
                $levels++;
                $score += $weights[ $flag ];
            }
        }

        // verification_status ENUM preserved for backward compatibility,
        // per the existing migration comment's own stated intent — never
        // remove it, only keep it in sync with the granular flags.
        $status = $levels === 0 ? 'unverified' : ( $levels >= 6 ? 'verified' : 'pending' );

        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'gs_vendor_profiles', [
            'verification_levels' => $levels,
            'trust_score_pct'     => $score,
            'trust_score_updated' => current_time( 'mysql' ),
            'verification_status' => $status,
            // trust_score (the pre-existing 0-100 TINYINT column) kept in
            // sync with trust_score_pct rather than left to drift as a
            // second, disconnected number meaning the same thing.
            // Real fix — trust_score is NOT written here. Confirmed
            // during Phase 1 discovery of the SLA enforcement work that
            // Cron.php already owns this column, computed from response
            // rate, review average, and jobs done — writing to it here
            // too would mean whichever system ran last silently erased
            // the other's contribution. trust_score_pct (verification
            // completeness specifically) remains this method's own,
            // non-colliding number; the cron now factors verification
            // in as a bonus component instead of a second writer to the
            // same column.
        ], [ 'id' => $vendor_id ] );
    }

    public static function get_flags( int $vendor_id ): array {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT " . implode( ',', self::FLAGS ) . ", verification_levels, trust_score_pct, verification_status
             FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d",
            $vendor_id
        ), ARRAY_A );
        return $row ?: [];
    }
}
