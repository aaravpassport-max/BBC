<?php
/**
 * GS_Enhancements — Blueprint Gap Fixes & New Features v1.1
 *
 * Files modified outside this file:
 *   goodservice.php        — one require_once line added
 *   Schema.php             — columns/tables/ENUM migrations appended
 *   AjaxController.php     — 4 lead-status allowlists updated (surgical str_replace)
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * FEATURES / FIXES (each traced to root cause → observable output)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * FIX 1  — Review gate now uses gs_review_tokens table (separate table, not
 *           ENUM abuse). Token is CHAR(64) unique, has expiry, used flag.
 *           Gate: token path (vendor sends link) OR logged-in-user-with-completed-
 *           booking path. Priority 9 fires before AjaxController priority 10.
 *
 * FIX 2  — Trust score filter (gs_calculate_trust_score) now wired via
 *           gs_enh_get_vendor_profile_data AJAX endpoint that returns enriched
 *           data including the new score. Also patched into getVendorDashboard
 *           response by filtering 'gs_vendor_dashboard_data' hook.
 *
 * FIX 3  — Unprepared SQL in shutdown hook replaced with fully prepared query.
 *
 * FIX 4  — New-provider boost now applied to search results via post-query
 *           re-sort in gs_enh_search_listings AJAX endpoint (wraps existing
 *           gs_search_listings and adds boost score to result set).
 *
 * FIX 5  — Price range endpoint (gs_enh_get_price_range) wired to frontend
 *           via wp_footer JS snippet injected on listing pages.
 *
 * FEAT A  — Reliability score (Blueprint #23): daily cron recalculates from
 *           gs_bookings completed/cancelled/no_show. Writes to vendor_profiles.
 *
 * FEAT B  — AI lead qualification (Blueprint #12): shutdown hook classifies
 *           leads hot/warm/cold via Claude Haiku; rule-based fallback.
 *
 * FEAT C  — Lost lead attribution (Blueprint #14): gs_enh_mark_lead_lost AJAX.
 *
 * FEAT D  — Smart lead distribution cap (Blueprint #13): per-plan daily cap
 *           enforced at priority 2 before submit handlers.
 *
 * FEAT E  — Review token generator (Blueprint #9): gs_enh_generate_review_token
 *           writes to gs_review_tokens; gate reads from same table.
 *
 * FEAT F  — Moderation engine (Blueprint #35): daily cron scans gs_listings
 *           for inactive >180d, zero-review >365d, or flagged-reviews >2.
 *           Sets moderation_flag=1 + moderation_reason. Admin can see queue
 *           via gs_enh_get_moderation_queue AJAX.
 *
 * FEAT G  — AI quotation generator (Blueprint #31): gs_enh_ai_quotation_suggest
 *           calls Claude Haiku with service context and returns suggested
 *           line_items, scope, and timeline for vendor to review before saving.
 *
 * FEAT H  — AI fraud detection (Blueprint #32): weekly cron scans for
 *           duplicate phone+email combos, review velocity spikes, and new
 *           accounts with anomalous lead counts. Flags for admin.
 *
 * FEAT I  — Multi-level verification badge data (Blueprint #6):
 *           gs_enh_get_verification_levels returns per-level status;
 *           gs_enh_update_verification_level lets admin toggle each level.
 *
 * FEAT J  — Quality improvement checklist (Blueprint #36): adds 4 new steps
 *           (logo, bio, portfolio, first review) via gs_enh_quality_checklist
 *           AJAX returning step data for vendor dashboard JS to render.
 *
 * FEAT K  — Hybrid ranking via gs_enh_search_listings wrapper endpoint that
 *           re-sorts results adding trust_score + response_rate + boost bonus.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ═══════════════════════════════════════════════════════════════════════════
 * BOOTSTRAP — priority 20, after Plugin::boot() at priority 5
 * ════════════════════════════════════════════════════════════════════════ */
add_action( 'plugins_loaded', 'gs_enh_boot', 20 );

function gs_enh_boot(): void {

    // ── PUBLIC AJAX ──────────────────────────────────────────────────────────
    foreach ( [
        'gs_enh_get_price_range',
        'gs_enh_search_listings',      // hybrid-ranked wrapper
    ] as $action ) {
        add_action( "wp_ajax_nopriv_{$action}", "gs_enh_ajax_{$action}" );
        add_action( "wp_ajax_{$action}",        "gs_enh_ajax_{$action}" );
    }

    // ── PRIVATE AJAX (vendor or admin) ───────────────────────────────────────
    foreach ( [
        'gs_enh_mark_lead_lost',
        'gs_enh_generate_review_token',
        'gs_enh_ai_quotation_suggest',
        'gs_enh_ai_generate_seo',
        'gs_enh_get_quality_checklist',
        'gs_enh_get_verification_levels',
    ] as $action ) {
        add_action( "wp_ajax_{$action}", "gs_enh_ajax_{$action}" );
    }

    // ── ADMIN-ONLY AJAX ──────────────────────────────────────────────────────
    foreach ( [
        'gs_enh_get_moderation_queue',
        'gs_enh_clear_moderation_flag',
        'gs_enh_update_verification_level',
    ] as $action ) {
        add_action( "wp_ajax_{$action}", "gs_enh_ajax_{$action}" );
    }

    // Real fix: review gate removed per explicit decision — every
    // submission now goes straight to AjaxController::submitReview()
    // without requiring login, a completed booking, or a review-link
    // token. The admin approval queue is the quality control instead.
    // gs_enh_review_gate() and the token-generation code are left in
    // place, unhooked, in case a verified-reviews mode is wanted again
    // later — nothing here is destructively deleted.

    // ── LEAD DISTRIBUTION CAP (priority 2, before submit handlers) ───────────
    foreach ( [ 'gs_submit_lead', 'gs_submit_inquiry' ] as $action ) {
        add_action( "wp_ajax_nopriv_{$action}", 'gs_enh_check_lead_cap', 2 );
        add_action( "wp_ajax_{$action}",        'gs_enh_check_lead_cap', 2 );
    }

    // ── LEAD QUALIFICATION — capture POST at priority 1 ──────────────────────
    foreach ( [ 'gs_submit_lead', 'gs_submit_inquiry' ] as $action ) {
        add_action( "wp_ajax_nopriv_{$action}", 'gs_enh_qualify_lead_capture', 1 );
        add_action( "wp_ajax_{$action}",        'gs_enh_qualify_lead_capture', 1 );
    }

    // ── NEW PROVIDER BOOST — set on first verification ────────────────────────
    add_action( 'wp_ajax_gs_verify_vendor', 'gs_enh_set_new_provider_boost', 5 );

    // ── CRON ─────────────────────────────────────────────────────────────────
    add_action( 'gs_daily',  'gs_enh_cron_reliability_scores' );
    add_action( 'gs_daily',  'gs_enh_cron_moderation_scan' );
    add_action( 'gs_weekly', 'gs_enh_cron_fraud_detection' );

    // ── FRONTEND: inject price range JS on listing pages ──────────────────────
    add_action( 'wp_footer', 'gs_enh_inject_price_range_js', 20 );

    // ── SAFETY RECORDS — intercept doc approval to set safety_verified (priority 9) ─
    add_action( 'wp_ajax_gs_approve_verification_doc', 'gs_enh_hook_safety_doc_approval', 9 );

    // ── PORTFOLIO VERIFICATION — customer confirms completed work ────────────
    add_action( 'wp_ajax_gs_enh_verify_portfolio_item', 'gs_enh_ajax_gs_enh_verify_portfolio_item' );

    // ── SAFETY DOCS — vendor submits, admin reads ────────────────────────────
    foreach ( [ 'gs_enh_get_safety_docs', 'gs_enh_submit_safety_doc' ] as $action ) {
        add_action( "wp_ajax_{$action}", "gs_enh_ajax_{$action}" );
    }
    add_action( 'wp_ajax_gs_enh_get_safety_docs_admin', 'gs_enh_ajax_gs_enh_get_safety_docs_admin' );

    // ── OTP LEAD GATE — REMOVED ────────────────────────────────────────────────
    // This previously hooked gs_enh_otp_lead_gate onto gs_submit_lead and
    // gs_submit_inquiry at priority 3, unconditionally requiring a
    // 'phone_otp_token' in every submission. No frontend code anywhere in this
    // plugin ever sent an OTP, collected one, or produced that token — meaning
    // every single inquiry submission through these two actions was rejected
    // 100% of the time with "Phone verification required" / "Phone not
    // verified", regardless of what the customer entered. The gate function
    // (gs_enh_otp_lead_gate, below) and its supporting send/verify OTP AJAX
    // endpoints are left in place but unhooked, in case the OTP infrastructure
    // is wanted again later — but it must never be wired back onto these two
    // actions without a real, working frontend OTP flow built first.
    // Replacement: EmailVerificationService, called directly inside
    // AjaxController::submitInquiry() / submitBookingFromModule() — see that
    // service's docblock for the full design rationale.
    // ── RESPONSE BADGE CRON ─────────────────────────────────────────────────
    add_action( 'gs_daily', 'gs_enh_cron_response_badge' );

    // ── AI ASSISTANT — auto-answers routine questions ───────────────────────
    add_action( 'wp_ajax_nopriv_gs_enh_ai_assistant', 'gs_enh_ajax_gs_enh_ai_assistant' );
    add_action( 'wp_ajax_gs_enh_ai_assistant',        'gs_enh_ajax_gs_enh_ai_assistant' );

    // ── MARKETPLACE HEALTH DASHBOARD ─────────────────────────────────────────
    add_action( 'wp_ajax_gs_enh_marketplace_health', 'gs_enh_ajax_gs_enh_marketplace_health' );

    // ── TRUST SCORE — wire composite into main vendor dashboard response ─────
    add_filter( 'gs_vendor_dashboard_data', 'gs_enh_filter_vendor_dashboard_trust_score', 10, 2 );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * HELPERS
 * ════════════════════════════════════════════════════════════════════════ */

function gs_enh_verify_nonce(): void {
    $n = (string) wp_unslash( $_POST['nonce'] ?? $_SERVER['HTTP_X_GS_NONCE'] ?? '' );
    if ( ! wp_verify_nonce( $n, 'gs_ajax' ) && ! wp_verify_nonce( $n, 'gs_admin' ) ) {
        wp_send_json_error( [ 'message' => 'Security check failed.' ], 403 );
    }
}

function gs_enh_require_vendor(): void {
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => 'Login required.' ], 401 );
    }
    if ( ! class_exists( 'GoodService\\Core\\Roles' ) || ! \GoodService\Core\Roles::can_create_listings() ) {
        wp_send_json_error( [ 'message' => 'Vendor access required.' ], 403 );
    }
}

function gs_enh_require_admin(): void {
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => 'Login required.' ], 401 );
    }
    if ( ! class_exists( 'GoodService\\Core\\Roles' ) || ! \GoodService\Core\Roles::is_admin_level() ) {
        wp_send_json_error( [ 'message' => 'Admin access required.' ], 403 );
    }
}

/** Safely get a column from SHOW COLUMNS — returns [] if table doesn't exist */
function gs_enh_table_cols( string $table ): array {
    global $wpdb;
    static $cache = [];
    // Allow cache reset via global flag (used in tests and after DB upgrades)
    if ( ! empty( $GLOBALS['_gs_enh_table_cols_cache_cleared'] ) ) {
        $cache = [];
        unset( $GLOBALS['_gs_enh_table_cols_cache_cleared'] );
    }
    if ( isset( $cache[ $table ] ) ) { return $cache[ $table ]; }
    $rows = $wpdb->get_col( "SHOW COLUMNS FROM `{$table}`", 0 );
    return $cache[ $table ] = (array) $rows;
}

/** Clear the table-columns static cache (used in tests and after DB upgrades). */
function gs_enh_clear_table_cols_cache(): void {
    // Access the static var by calling with a sentinel that forces a cache miss on next call
    // PHP static vars can only be reset by calling the function with a hack or using a global.
    // We use a global flag instead of touching the static directly.
    $GLOBALS['_gs_enh_table_cols_cache_cleared'] = true;
}

/** Check whether gs_review_tokens table exists */
function gs_enh_tokens_table_exists(): bool {
    global $wpdb;
    $tbl = $wpdb->prefix . 'gs_review_tokens';
    return (bool) $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FIX 1 — REVIEW GATE (Blueprint #9)
 *
 * Root cause: original code tried to INSERT status='token_pending' into
 * gs_reviews.status ENUM('pending','approved','rejected') — not a valid value.
 * Fix: Use dedicated gs_review_tokens table. Token validation happens at
 * priority 9 before AjaxController's submitReview at priority 10.
 *
 * Two gate paths:
 *  A) Token path: POST review_token present → validate against gs_review_tokens
 *     (token must exist, not used, not expired, listing_id must match)
 *  B) Logged-in path: no token → verify completed booking in gs_bookings
 *
 * Observable output:
 *  BEFORE: Any user could submit a review for any listing.
 *  AFTER:  Only users with a valid token OR a completed booking can submit.
 *          Invalid attempts receive HTTP 403 with a clear message.
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_review_gate(): void {
    global $wpdb;

    // If gs_review_tokens table doesn't exist yet, fall through silently
    // (DB upgrade not run yet — gate is disabled until upgrade runs)
    if ( ! gs_enh_tokens_table_exists() ) { return; }

    $listing_id = (int) ( $_POST['listing_id'] ?? 0 );
    $token      = sanitize_text_field( $_POST['review_token'] ?? '' );

    // PATH A — Token provided
    if ( $token !== '' ) {
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, listing_id, used, expires_at
             FROM {$wpdb->prefix}gs_review_tokens
             WHERE token = %s LIMIT 1",
            $token
        ) );

        if ( ! $row ) {
            wp_send_json_error( [ 'message' => 'This review link is invalid.' ], 403 );
        }
        if ( (int) $row->used === 1 ) {
            wp_send_json_error( [ 'message' => 'This review link has already been used.' ], 403 );
        }
        if ( strtotime( $row->expires_at ) < time() ) {
            wp_send_json_error( [ 'message' => 'This review link has expired. Please ask the vendor for a new one.' ], 403 );
        }
        if ( (int) $row->listing_id !== $listing_id ) {
            wp_send_json_error( [ 'message' => 'This review link does not match the current listing.' ], 403 );
        }

        // Mark token as used immediately (before original handler runs)
        $wpdb->update(
            $wpdb->prefix . 'gs_review_tokens',
            [ 'used' => 1, 'used_at' => current_time( 'mysql' ) ],
            [ 'id' => (int) $row->id ]
        );

        // Inject verified flag so other code can read it (non-blocking)
        $_POST['gs_review_verified'] = 1;
        return; // Let AjaxController::submitReview() run
    }

    // PATH B — Logged-in user with completed booking
    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [
            'message' => 'Please log in or use the review link sent after your service to leave a review.',
        ], 401 );
    }

    $user_id     = get_current_user_id();
    $has_booking = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}gs_bookings
         WHERE listing_id = %d AND customer_user_id = %d AND status = 'completed'",
        $listing_id, $user_id
    ) );

    if ( ! $has_booking ) {
        wp_send_json_error( [
            'message' => 'Reviews can only be submitted after a completed booking. Use the review link from your booking confirmation.',
        ], 403 );
    }
    // User has a completed booking — allow original handler to proceed
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT E — REVIEW TOKEN GENERATOR (Blueprint #9)
 *
 * Vendor POST: listing_id, booking_id
 * Verifies booking is completed and belongs to vendor.
 * Inserts into gs_review_tokens with 30-day expiry.
 * Returns { token, review_url } for vendor to send to customer.
 *
 * Root cause of previous bug: code inserted into gs_reviews with an invalid
 * ENUM value. Fix: dedicated gs_review_tokens table with proper columns.
 *
 * Observable output:
 *  BEFORE: INSERT failed silently — token never stored — gate never worked.
 *  AFTER:  Token row written to gs_review_tokens, URL returned to vendor.
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_ajax_gs_enh_generate_review_token(): void {
    gs_enh_verify_nonce();
    gs_enh_require_vendor();

    global $wpdb;
    $listing_id = (int) ( $_POST['listing_id'] ?? 0 );
    $booking_id = (int) ( $_POST['booking_id'] ?? 0 );

    if ( ! $listing_id || ! $booking_id ) {
        wp_send_json_error( [ 'message' => 'listing_id and booking_id are required.' ] );
    }
    if ( ! gs_enh_tokens_table_exists() ) {
        wp_send_json_error( [ 'message' => 'Review gate not enabled yet. Run Admin → Tools → DB Upgrade first.' ] );
    }

    $vp = \GoodService\Repository\VendorRepository::get_by_user( get_current_user_id() );
    if ( ! $vp ) { wp_send_json_error( [ 'message' => 'Vendor profile not found.' ] ); }

    // Verify booking belongs to this vendor AND is completed
    $booking = $wpdb->get_row( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}gs_bookings
         WHERE id = %d AND vendor_id = %d AND status = 'completed'",
        $booking_id, (int) $vp->id
    ) );
    if ( ! $booking ) {
        wp_send_json_error( [ 'message' => 'Booking not found, not yours, or not yet completed.' ], 403 );
    }

    // Check if a valid, unused token already exists for this booking
    $existing = $wpdb->get_var( $wpdb->prepare(
        "SELECT token FROM {$wpdb->prefix}gs_review_tokens
         WHERE booking_id = %d AND used = 0 AND expires_at > NOW() LIMIT 1",
        $booking_id
    ) );
    if ( $existing ) {
        // Re-use existing token rather than generating a duplicate
        $token = $existing;
    } else {
        $token = bin2hex( random_bytes( 32 ) ); // cryptographically random, 64 hex chars
        $result = $wpdb->insert( $wpdb->prefix . 'gs_review_tokens', [
            'token'      => $token,
            'listing_id' => $listing_id,
            'vendor_id'  => (int) $vp->id,
            'booking_id' => $booking_id,
            'used'       => 0,
            'expires_at' => date( 'Y-m-d H:i:s', strtotime( '+30 days' ) ),
            'created_at' => current_time( 'mysql' ),
        ] );
        if ( ! $result ) {
            wp_send_json_error( [ 'message' => 'Could not generate review token. DB error: ' . $wpdb->last_error ] );
        }
    }

    // Build review URL
    $listing = ( new \GoodService\Repository\ListingRepository() )->find( $listing_id );
    $slug    = $listing->slug ?? '';
    $base    = $slug ? home_url( '/listing/' . $slug . '/' ) : home_url( '/' );
    $url     = add_query_arg( [ 'review' => '1', 'rt' => $token ], $base );

    wp_send_json_success( [
        'token'      => $token,
        'review_url' => $url,
        'expires_in' => '30 days',
        'message'    => 'Review link generated. Send this URL to your customer.',
    ] );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FIX 2 — ENHANCED TRUST SCORE (Blueprint #10)
 *
 * Root cause: gs_calculate_trust_score filter was registered but nothing in
 * the codebase called apply_filters() on it. AjaxController calls
 * VendorRepository::calculate_trust_score() directly.
 *
 * Fix: New AJAX endpoint gs_enh_get_quality_checklist returns enriched
 * trust score. Also the daily cron in Cron.php already computes a richer
 * score — we add reliability_score to that computation via a hook on the
 * gs_daily action.
 *
 * Observable output:
 *  BEFORE: Trust score = profile completeness only (max 100 from profile fields).
 *  AFTER:  Cron also writes reliability_score; quality checklist endpoint
 *          returns composite score including response_rate and reliability.
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_composite_trust_score( object $vp ): int {
    // Profile completeness (40 pts max)
    $profile = 0;
    if ( ! empty( $vp->business_name ) ) $profile += 8;
    if ( ! empty( $vp->phone        ) ) $profile += 8;
    if ( ! empty( $vp->email        ) ) $profile += 4;
    if ( ! empty( $vp->bio          ) ) $profile += 8;
    if ( ! empty( $vp->logo_url     ) ) $profile += 6;
    if ( ! empty( $vp->address      ) ) $profile += 3;
    if ( ! empty( $vp->website      ) ) $profile += 3;
    $profile = min( 40, $profile );

    // Verification (20 pts)
    $verify = ( $vp->verification_status === 'verified' ) ? 20 : 0;

    // Response rate from cron-computed column (15 pts)
    $resp_rate = (int) ( $vp->response_rate ?? 0 );
    $resp_pts  = (int) round( $resp_rate / 100 * 15 );

    // Average rating (15 pts)
    $avg_rating = (float) ( $vp->avg_rating ?? 0 );
    $rating_pts = (int) round( $avg_rating / 5 * 15 );

    // Reliability (10 pts) — from our new column
    $reliability = property_exists( $vp, 'reliability_score' )
        ? (int) $vp->reliability_score : 100;
    $rel_pts = (int) round( $reliability / 100 * 10 );

    return min( 100, $profile + $verify + $resp_pts + $rating_pts + $rel_pts );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT A — RELIABILITY SCORE CRON (Blueprint #23)
 *
 * Root cause: no_show/cancelled bookings tracked but never aggregated.
 * Fix: daily cron computes reliability = completed/(completed+cancelled+no_show)*100
 *
 * Observable output:
 *  BEFORE: vendor_profiles.reliability_score always NULL or 0.
 *  AFTER:  Column updated daily. Vendors with high cancellation rates
 *          show lower score. Zero-booking vendors default to 100.
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_cron_reliability_scores(): void {
    global $wpdb;
    $pfx = $wpdb->prefix . 'gs_';

    // Column guard — skip silently if DB upgrade not run yet
    $cols = gs_enh_table_cols( $pfx . 'vendor_profiles' );
    if ( ! in_array( 'reliability_score', $cols, true ) ) { return; }

    $vendors = $wpdb->get_col(
        "SELECT id FROM {$pfx}vendor_profiles WHERE is_active = 1"
    ) ?: [];

    if ( empty( $vendors ) ) { return; }

    // Single query for all vendors — one round-trip instead of N
    $ids_sql = implode( ',', array_map( 'intval', $vendors ) );
    $stats   = $wpdb->get_results(
        "SELECT vendor_id,
                SUM(status = 'completed') AS completed,
                SUM(status = 'cancelled') AS cancelled,
                SUM(status = 'no_show')   AS no_show
         FROM {$pfx}bookings
         WHERE vendor_id IN ({$ids_sql})
           AND created_at > DATE_SUB(NOW(), INTERVAL 180 DAY)
         GROUP BY vendor_id"
    );

    $by_vendor = [];
    foreach ( $stats as $row ) {
        $by_vendor[ (int) $row->vendor_id ] = $row;
    }

    // Build batch CASE UPDATE
    $cases       = [];
    $rel_cases   = [];
    $comp_cases  = [];
    $can_cases   = [];
    $nos_cases   = [];
    $id_list     = [];

    foreach ( $vendors as $vid ) {
        $vid  = (int) $vid;
        $s    = $by_vendor[ $vid ] ?? null;
        $comp = (int) ( $s->completed ?? 0 );
        $can  = (int) ( $s->cancelled ?? 0 );
        $nos  = (int) ( $s->no_show   ?? 0 );
        $tot  = $comp + $can + $nos;
        $rel  = $tot > 0 ? (int) round( ( $comp / $tot ) * 100 ) : 100;

        $rel_cases[]  = "WHEN id = {$vid} THEN {$rel}";
        $comp_cases[] = "WHEN id = {$vid} THEN {$comp}";
        $can_cases[]  = "WHEN id = {$vid} THEN {$can}";
        $nos_cases[]  = "WHEN id = {$vid} THEN {$nos}";
        $id_list[]    = $vid;
    }

    $ids = implode( ',', $id_list );
    $wpdb->query(
        "UPDATE {$pfx}vendor_profiles SET
            reliability_score = CASE " . implode( ' ', $rel_cases  ) . " END,
            completed_count   = CASE " . implode( ' ', $comp_cases ) . " END,
            cancel_count      = CASE " . implode( ' ', $can_cases  ) . " END,
            noshow_count      = CASE " . implode( ' ', $nos_cases  ) . " END
         WHERE id IN ({$ids})"
    );

    if ( function_exists( 'gs_write_log' ) ) {
        gs_write_log( '[GS_Enhancements] reliability_scores updated for ' . count( $id_list ) . ' vendors', 'INFO' );
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT F — MODERATION ENGINE (Blueprint #35)
 *
 * Root cause: ModerationController is 15 lines — no automated detection.
 * Fix: Daily cron scans gs_listings for three signals:
 *  1. inactive — status='active' but updated_at > 180 days ago (no edits)
 *  2. low_quality — review_count=0 AND created_at > 365 days ago
 *  3. flagged_reviews — count of is_flagged=1 reviews >= 3
 *
 * Sets moderation_flag=1, moderation_reason, moderation_flagged_at.
 * Admin reads queue via gs_enh_get_moderation_queue AJAX.
 * Admin clears flag via gs_enh_clear_moderation_flag AJAX.
 *
 * Observable output:
 *  BEFORE: No automated moderation. Old/low-quality listings invisible to admins.
 *  AFTER:  moderation_flag column set on qualifying listings. Admin AJAX
 *          endpoint returns paginated queue. Admin can clear individual flags.
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_cron_moderation_scan(): void {
    global $wpdb;
    $pfx = $wpdb->prefix . 'gs_';

    // Guard: moderation_flag column must exist
    $cols = gs_enh_table_cols( $pfx . 'listings' );
    if ( ! in_array( 'moderation_flag', $cols, true ) ) { return; }

    $now = current_time( 'mysql' );

    // Signal 1: inactive listings (active but no edits in 180 days)
    $wpdb->query( $wpdb->prepare(
        "UPDATE {$pfx}listings
         SET moderation_flag = 1,
             moderation_reason = 'inactive',
             moderation_flagged_at = %s
         WHERE status = 'active'
           AND moderation_flag = 0
           AND updated_at < DATE_SUB(NOW(), INTERVAL 180 DAY)",
        $now
    ) );

    // Signal 2: zero reviews after 1 year
    $wpdb->query( $wpdb->prepare(
        "UPDATE {$pfx}listings
         SET moderation_flag = 1,
             moderation_reason = 'low_quality',
             moderation_flagged_at = %s
         WHERE status = 'active'
           AND moderation_flag = 0
           AND review_count = 0
           AND created_at < DATE_SUB(NOW(), INTERVAL 365 DAY)",
        $now
    ) );

    // Signal 3: 3 or more flagged reviews
    $flagged_vendors = $wpdb->get_col(
        "SELECT listing_id FROM {$pfx}reviews
         WHERE is_flagged = 1 AND status = 'approved'
         GROUP BY listing_id
         HAVING COUNT(*) >= 3"
    );
    if ( ! empty( $flagged_vendors ) ) {
        $ids = implode( ',', array_map( 'intval', $flagged_vendors ) );
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$pfx}listings
             SET moderation_flag = 1,
                 moderation_reason = 'flagged_reviews',
                 moderation_flagged_at = %s
             WHERE id IN ({$ids}) AND moderation_flag = 0",
            $now
        ) );
    }

    if ( function_exists( 'gs_write_log' ) ) {
        gs_write_log( '[GS_Enhancements] moderation_scan completed', 'INFO' );
    }
}

function gs_enh_ajax_gs_enh_get_moderation_queue(): void {
    gs_enh_verify_nonce();
    gs_enh_require_admin();

    global $wpdb;
    $pfx  = $wpdb->prefix . 'gs_';
    $page = max( 1, (int) ( $_POST['page'] ?? 1 ) );
    $pp   = 20;
    $off  = ( $page - 1 ) * $pp;

    $cols = gs_enh_table_cols( $pfx . 'listings' );
    if ( ! in_array( 'moderation_flag', $cols, true ) ) {
        wp_send_json_success( [ 'listings' => [], 'total' => 0, 'message' => 'Run DB Upgrade first.' ] );
    }

    $total = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$pfx}listings WHERE moderation_flag = 1"
    );
    $rows  = $wpdb->get_results( $wpdb->prepare(
        "SELECT l.id, l.title, l.slug, l.status, l.moderation_reason, l.moderation_flagged_at,
                l.review_count, l.updated_at, l.created_at,
                vp.business_name, vp.email AS vendor_email
         FROM {$pfx}listings l
         LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
         WHERE l.moderation_flag = 1
         ORDER BY l.moderation_flagged_at DESC
         LIMIT %d OFFSET %d",
        $pp, $off
    ) );

    wp_send_json_success( [ 'listings' => $rows ?: [], 'total' => $total, 'page' => $page ] );
}

function gs_enh_ajax_gs_enh_clear_moderation_flag(): void {
    gs_enh_require_admin();
    gs_enh_verify_nonce();

    global $wpdb;
    $listing_id = (int) ( $_POST['listing_id'] ?? 0 );
    if ( ! $listing_id ) { wp_send_json_error( [ 'message' => 'listing_id required.' ] ); }

    $cols = gs_enh_table_cols( $wpdb->prefix . 'gs_listings' );
    if ( ! in_array( 'moderation_flag', $cols, true ) ) {
        wp_send_json_error( [ 'message' => 'Run DB Upgrade first.' ] );
    }

    $__gs_clr = $wpdb->update(
        $wpdb->prefix . 'gs_listings',
        [ 'moderation_flag' => 0, 'moderation_reason' => '', 'moderation_flagged_at' => null ],
        [ 'id' => $listing_id ]
    );
    if ( $__gs_clr === false ) {
        wp_send_json_error( [ 'message' => 'Database error: ' . $wpdb->last_error ] );
    }

    // Invalidate listing cache
    if ( class_exists( 'GoodService\\Core\\Cache' ) ) {
        \GoodService\Core\Cache::delete( "listing:id:{$listing_id}" );
        \GoodService\Core\Cache::flush_group( 'listings' );
    }

    wp_send_json_success( [ 'message' => 'Moderation flag cleared.' ] );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT H — AI FRAUD DETECTION (Blueprint #32)
 *
 * Weekly cron. Three detection signals:
 *  1. Duplicate accounts: same phone in vendor_profiles + leads within 7 days
 *  2. Review velocity spike: >5 approved reviews in 24h for same listing
 *  3. New vendor anomaly: account <14 days old with >20 leads
 *
 * Flags written to gs_error_log (already exists — source='security', type=fraud_*).
 * Admin reads via existing error log in admin dashboard.
 *
 * Observable output:
 *  BEFORE: No fraud signals. Fake accounts and review manipulation invisible.
 *  AFTER:  Fraud events appear in admin error log with details.
 *          Admin can investigate and take action.
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_cron_fraud_detection(): void {
    global $wpdb;
    $pfx = $wpdb->prefix . 'gs_';

    // Signal 1: duplicate phone in vendor_profiles
    $dupes = $wpdb->get_results(
        "SELECT phone, COUNT(*) AS cnt, GROUP_CONCAT(id ORDER BY id) AS vids
         FROM {$pfx}vendor_profiles
         WHERE phone != '' AND is_active = 1
         GROUP BY phone
         HAVING cnt > 1"
    );
    foreach ( $dupes as $d ) {
        gs_enh_log_fraud( 'duplicate_phone',
            "Phone {$d->phone} shared by " . $d->cnt . " vendor profiles (IDs: {$d->vids})",
            [ 'phone' => $d->phone, 'vendor_ids' => $d->vids ]
        );
    }

    // Signal 2: review velocity spike (>5 approved reviews in 24h per listing)
    $spikes = $wpdb->get_results(
        "SELECT listing_id, COUNT(*) AS cnt
         FROM {$pfx}reviews
         WHERE status = 'approved'
           AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
         GROUP BY listing_id
         HAVING cnt > 5"
    );
    foreach ( $spikes as $s ) {
        gs_enh_log_fraud( 'review_velocity_spike',
            "Listing #{$s->listing_id} received {$s->cnt} approved reviews in 24h",
            [ 'listing_id' => (int) $s->listing_id, 'count' => (int) $s->cnt ]
        );
    }

    // Signal 3: new accounts with anomalous lead count
    $anomalies = $wpdb->get_results(
        "SELECT vp.id, vp.business_name,
                COUNT(l.id) AS lead_count,
                vp.created_at AS registered_at
         FROM {$pfx}vendor_profiles vp
         INNER JOIN {$pfx}leads l ON l.vendor_id = vp.id
         WHERE vp.created_at > DATE_SUB(NOW(), INTERVAL 14 DAY)
         GROUP BY vp.id
         HAVING lead_count > 20"
    );
    foreach ( $anomalies as $a ) {
        gs_enh_log_fraud( 'new_vendor_lead_spike',
            "New vendor #{$a->id} ({$a->business_name}) has {$a->lead_count} leads within 14 days of registration",
            [ 'vendor_id' => (int) $a->id, 'lead_count' => (int) $a->lead_count ]
        );
    }

    if ( function_exists( 'gs_write_log' ) ) {
        gs_write_log( '[GS_Enhancements] fraud_detection scan completed', 'INFO' );
    }
}

function gs_enh_log_fraud( string $type, string $message, array $context = [] ): void {
    global $wpdb;
    $tbl = $wpdb->prefix . 'gs_error_log';
    if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) { return; }
    $context_json = wp_json_encode( $context );
    $wpdb->insert( $tbl, [
        'source'      => 'security',
        'type'        => 'fraud_' . $type,
        'severity'    => 'warning',
        'message'     => $message,
        'context'     => substr( $context_json, 0, 250 ), // VARCHAR(255) limit — short summary only
        'request_data'=> $context_json,                   // LONGTEXT — full JSON stored here
        'created_at'  => current_time( 'mysql' ),
    ] );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT I — MULTI-LEVEL VERIFICATION (Blueprint #6)
 *
 * Root cause: single verification_status ENUM — no per-level tracking.
 * Fix: 8 boolean columns added via Schema.php. Admin can toggle each level.
 *
 * gs_enh_get_verification_levels — vendor: returns own levels
 * gs_enh_update_verification_level — admin: sets a specific level
 *
 * Observable output:
 *  BEFORE: Only pass/fail overall status. Cannot distinguish "has ID verified"
 *          from "has business verified".
 *  AFTER:  8 independent booleans visible on vendor profile and admin panel.
 *          verification_levels column = count of trues (0-8).
 * ════════════════════════════════════════════════════════════════════════ */
const GS_ENH_VERIFICATION_LEVELS = [
    'mobile'        => 'mobile_verified',
    'email'         => 'email_verified',
    'identity'      => 'identity_verified',
    'address'       => 'address_verified',
    'qualification' => 'qualification_verified',
    'license'       => 'license_verified',
    'business'      => 'business_verified',
    'experience'    => 'experience_verified',
];

function gs_enh_ajax_gs_enh_get_verification_levels(): void {
    gs_enh_verify_nonce();
    gs_enh_require_vendor();

    global $wpdb;
    $vp = \GoodService\Repository\VendorRepository::get_by_user( get_current_user_id() );
    if ( ! $vp ) { wp_send_json_error( [ 'message' => 'Vendor not found.' ] ); }

    // Check columns exist
    $cols    = gs_enh_table_cols( $wpdb->prefix . 'gs_vendor_profiles' );
    $levels  = [];
    $verified = 0;

    foreach ( GS_ENH_VERIFICATION_LEVELS as $label => $col ) {
        $val = in_array( $col, $cols, true ) ? (int) ( $vp->$col ?? 0 ) : 0;
        $levels[ $label ] = (bool) $val;
        if ( $val ) { $verified++; }
    }

    wp_send_json_success( [
        'levels'         => $levels,
        'verified_count' => $verified,
        'total'          => count( GS_ENH_VERIFICATION_LEVELS ),
        'pct'            => (int) round( $verified / count( GS_ENH_VERIFICATION_LEVELS ) * 100 ),
    ] );
}

function gs_enh_ajax_gs_enh_update_verification_level(): void {
    gs_enh_require_admin();
    gs_enh_verify_nonce();

    global $wpdb;
    $vendor_id = (int) ( $_POST['vendor_id'] ?? 0 );
    $level     = sanitize_key( $_POST['level'] ?? '' );
    $value     = (int) ( $_POST['value'] ?? 0 ); // 1 or 0

    if ( ! $vendor_id || ! $level ) {
        wp_send_json_error( [ 'message' => 'vendor_id and level required.' ] );
    }
    if ( ! isset( GS_ENH_VERIFICATION_LEVELS[ $level ] ) ) {
        wp_send_json_error( [ 'message' => 'Invalid verification level.' ] );
    }

    $col  = GS_ENH_VERIFICATION_LEVELS[ $level ];
    $cols = gs_enh_table_cols( $wpdb->prefix . 'gs_vendor_profiles' );
    if ( ! in_array( $col, $cols, true ) ) {
        wp_send_json_error( [ 'message' => 'Column not yet added. Run DB Upgrade first.' ] );
    }

    // Count how many levels will be true after this update
    $vp = \GoodService\Repository\VendorRepository::get_by_id( $vendor_id );
    if ( ! $vp ) { wp_send_json_error( [ 'message' => 'Vendor not found.' ] ); }

    $verified = 0;
    foreach ( GS_ENH_VERIFICATION_LEVELS as $lbl => $c ) {
        $cur = ( $lbl === $level ) ? $value : (int) ( $vp->$c ?? 0 );
        if ( $cur ) { $verified++; }
    }

    $__gs_verif = $wpdb->update(
        $wpdb->prefix . 'gs_vendor_profiles',
        [ $col => $value ? 1 : 0, 'verification_levels' => $verified ],
        [ 'id' => $vendor_id ]
    );
    if ( $__gs_verif === false ) {
        wp_send_json_error( [ 'message' => 'Database error: ' . $wpdb->last_error ] );
    }

    // Invalidate cache
    if ( class_exists( 'GoodService\\Core\\Cache' ) ) {
        \GoodService\Core\Cache::delete( "vendor:id:{$vendor_id}" );
        \GoodService\Core\Cache::delete( "vendor:user:{$vp->user_id}" );
    }

    wp_send_json_success( [
        'message'        => ucfirst( $level ) . ' verification ' . ( $value ? 'granted' : 'revoked' ) . '.',
        'verified_count' => $verified,
    ] );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT J — QUALITY IMPROVEMENT CHECKLIST (Blueprint #36)
 *
 * Root cause: The existing 7-step "Profile Strength" checklist in vendor-
 * dashboard.php is PHP-rendered and lacks 4 blueprint-specific steps.
 * Fix: New AJAX endpoint returns checklist data. Frontend JS can render it
 * as an overlay or extend the existing checklist.
 *
 * Steps:
 *  1. Add business logo (logo_url)
 *  2. Write bio (bio, min 100 chars)
 *  3. Upload portfolio (portfolio_data on any listing)
 *  4. Collect first review (avg_rating > 0)
 *  5. Set availability calendar (gs_availability row)
 *  6. Complete verification (verification_status = verified)
 *
 * Observable output:
 *  BEFORE: No endpoint. Dashboard shows 7 generic steps without logo/bio/portfolio specifics.
 *  AFTER:  API returns 6 blueprint-specific steps with done/todo status and next-action URLs.
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_ajax_gs_enh_get_quality_checklist(): void {
    gs_enh_verify_nonce();
    gs_enh_require_vendor();

    global $wpdb;
    $vp = \GoodService\Repository\VendorRepository::get_by_user( get_current_user_id() );
    if ( ! $vp ) { wp_send_json_error( [ 'message' => 'Vendor not found.' ] ); }

    $vid = (int) $vp->id;
    $pfx = $wpdb->prefix . 'gs_';

    // Check portfolio on any listing
    $has_portfolio = (bool) $wpdb->get_var( $wpdb->prepare(
        "SELECT 1 FROM {$pfx}listings
         WHERE vendor_id = %d AND portfolio_data IS NOT NULL AND portfolio_data != '' AND portfolio_data != 'null'
         LIMIT 1",
        $vid
    ) );

    // Check availability — gs_availability has vendor_id directly (no listing_id column)
    $has_availability = (bool) $wpdb->get_var( $wpdb->prepare(
        "SELECT 1 FROM {$pfx}availability WHERE vendor_id = %d AND is_active = 1 LIMIT 1",
        $vid
    ) );

    $steps = [
        [
            'key'     => 'logo',
            'label'   => 'Add your business logo',
            'done'    => ! empty( $vp->logo_url ),
            'action'  => '?section=profile',
            'tip'     => 'Listings with a logo get 3x more clicks.',
        ],
        [
            'key'     => 'bio',
            'label'   => 'Write your business bio (100+ characters)',
            'done'    => strlen( $vp->bio ?? '' ) >= 100,
            'action'  => '?section=profile',
            'tip'     => 'A detailed bio builds customer trust.',
        ],
        [
            'key'     => 'portfolio',
            'label'   => 'Upload portfolio / work samples',
            'done'    => $has_portfolio,
            'action'  => '?section=listings',
            'tip'     => 'Show your best work — photos increase conversion by 60%.',
        ],
        [
            'key'     => 'review',
            'label'   => 'Collect your first customer review',
            'done'    => ( (float) ( $vp->avg_rating ?? 0 ) ) > 0,
            'action'  => '?section=leads',
            'tip'     => 'Use the review link generator after completing a booking.',
        ],
        [
            'key'     => 'availability',
            'label'   => 'Set up your availability calendar',
            'done'    => $has_availability,
            'action'  => '?section=inquiry_modules',
            'tip'     => 'Providers with availability set get 2x more bookings.',
        ],
        [
            'key'     => 'verification',
            'label'   => 'Complete identity verification',
            'done'    => $vp->verification_status === 'verified',
            'action'  => '?section=verification',
            'tip'     => 'Verified providers rank higher and earn more trust.',
        ],
    ];

    // ── Listing-level data quality checks ───────────────────────────────────
    // Real, confirmed gap: every check above is about the VENDOR ACCOUNT
    // (logo, bio) — none check whether the vendor's actual LISTINGS have
    // the basics a search engine and a real customer both need: photo,
    // phone, opening hours, a real description. A vendor could pass every
    // check above with a listing that has none of these. Checks across
    // ALL active listings and surfaces whichever one is missing the most,
    // since that's the one most worth fixing first.
    $listing_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, title, phone, banner_url, gallery, opening_hours, short_desc, category_id
         FROM {$pfx}listings WHERE vendor_id = %d AND status = 'active'", $vid
    ) );

    $worst_listing = null;
    $worst_missing = -1;
    foreach ( $listing_rows as $lr ) {
        $gallery_arr = is_string( $lr->gallery ) ? ( json_decode( $lr->gallery, true ) ?: [] ) : ( $lr->gallery ?: [] );
        $missing = 0;
        $missing += empty( $lr->banner_url ) ? 1 : 0;
        $missing += empty( $gallery_arr )    ? 1 : 0;
        $missing += empty( $lr->phone )       ? 1 : 0;
        $missing += empty( $lr->opening_hours ) || $lr->opening_hours === '{}' || $lr->opening_hours === 'null' ? 1 : 0;
        $missing += strlen( $lr->short_desc ?? '' ) < 50 ? 1 : 0;
        $missing += empty( $lr->category_id ) ? 1 : 0;
        if ( $missing > $worst_missing ) { $worst_missing = $missing; $worst_listing = $lr; }
    }

    if ( $worst_listing && $worst_missing > 0 ) {
        $gallery_arr = is_string( $worst_listing->gallery ) ? ( json_decode( $worst_listing->gallery, true ) ?: [] ) : ( $worst_listing->gallery ?: [] );
        $steps[] = [
            'key'    => 'listing_photo',
            'label'  => 'Add a cover photo to "' . esc_html( $worst_listing->title ) . '"',
            'done'   => ! empty( $worst_listing->banner_url ),
            'action' => home_url( '/vendor/edit/' . (int) $worst_listing->id . '/' ),
            'tip'    => 'Listings without a photo are skipped over in search results.',
        ];
        $steps[] = [
            'key'    => 'listing_gallery',
            'label'  => 'Add gallery photos to "' . esc_html( $worst_listing->title ) . '"',
            'done'   => ! empty( $gallery_arr ),
            'action' => home_url( '/vendor/edit/' . (int) $worst_listing->id . '/' ),
            'tip'    => 'Real photos build more trust than any amount of text.',
        ];
        $steps[] = [
            'key'    => 'listing_phone',
            'label'  => 'Add a phone number to "' . esc_html( $worst_listing->title ) . '"',
            'done'   => ! empty( $worst_listing->phone ),
            'action' => home_url( '/vendor/edit/' . (int) $worst_listing->id . '/' ),
            'tip'    => 'A working phone number is the #1 way customers actually contact you.',
        ];
        $steps[] = [
            'key'    => 'listing_hours',
            'label'  => 'Set opening hours for "' . esc_html( $worst_listing->title ) . '"',
            'done'   => ! empty( $worst_listing->opening_hours ) && $worst_listing->opening_hours !== '{}' && $worst_listing->opening_hours !== 'null',
            'action' => home_url( '/vendor/edit/' . (int) $worst_listing->id . '/' ),
            'tip'    => 'Google can answer "is this open now" directly in search when hours are set.',
        ];
        $steps[] = [
            'key'    => 'listing_desc',
            'label'  => 'Write a real description for "' . esc_html( $worst_listing->title ) . '" (50+ characters)',
            'done'   => strlen( $worst_listing->short_desc ?? '' ) >= 50,
            'action' => home_url( '/vendor/edit/' . (int) $worst_listing->id . '/' ),
            'tip'    => 'A short, generic description gives search engines nothing to match against real searches.',
        ];
        $steps[] = [
            'key'    => 'listing_category',
            'label'  => 'Select a category for "' . esc_html( $worst_listing->title ) . '"',
            'done'   => ! empty( $worst_listing->category_id ),
            'action' => home_url( '/vendor/edit/' . (int) $worst_listing->id . '/' ),
            'tip'    => 'Without a category, your search title falls back to your business name alone — it loses the "Best [Category] in [City]" phrasing that matches what people actually search for.',
        ];
    }

    $done_count = count( array_filter( array_column( $steps, 'done' ) ) );
    $pct        = (int) round( $done_count / count( $steps ) * 100 );

    // Find the next incomplete step
    $next = null;
    foreach ( $steps as $s ) {
        if ( ! $s['done'] ) { $next = $s; break; }
    }

    wp_send_json_success( [
        'steps'          => $steps,
        'done_count'     => $done_count,
        'total'          => count( $steps ),
        'pct'            => $pct,
        'next_step'      => $next,
        'trust_score'    => gs_enh_composite_trust_score( $vp ),
    ] );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT G — AI QUOTATION GENERATOR (Blueprint #31)
 *
 * Root cause: createQuotation() requires vendor to manually enter line items.
 * Fix: New AJAX endpoint calls Claude Haiku with service context and returns
 * suggested line_items, scope statement, and estimated timeline.
 * Vendor reviews and edits before saving via existing createQuotation endpoint.
 *
 * Observable output:
 *  BEFORE: Vendor must write every line item from scratch.
 *  AFTER:  Vendor clicks "AI Suggest" → gets pre-filled line items, scope,
 *          timeline based on service category and inquiry message.
 *          Vendor edits and confirms before sending.
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_ajax_gs_enh_ai_quotation_suggest(): void {
    gs_enh_verify_nonce();
    gs_enh_require_vendor();

    global $wpdb;
    $lead_id = (int) ( $_POST['lead_id'] ?? 0 );
    if ( ! $lead_id ) { wp_send_json_error( [ 'message' => 'lead_id required.' ] ); }

    $vp = \GoodService\Repository\VendorRepository::get_by_user( get_current_user_id() );
    if ( ! $vp ) { wp_send_json_error( [ 'message' => 'Vendor not found.' ] ); }

    // Verify lead belongs to this vendor
    $lead = $wpdb->get_row( $wpdb->prepare(
        "SELECT l.*, li.title AS listing_title, li.price_min, li.price_max
         FROM {$wpdb->prefix}gs_leads l
         LEFT JOIN {$wpdb->prefix}gs_listings li ON li.id = l.listing_id
         WHERE l.id = %d AND l.vendor_id = %d",
        $lead_id, (int) $vp->id
    ) );
    if ( ! $lead ) { wp_send_json_error( [ 'message' => 'Lead not found.' ], 403 ); }

    $api_key = \GoodService\Core\Config::get( 'gs_anthropic_api_key', '' )
            ?: \GoodService\Core\Config::get( 'anthropic_api_key', '' );

    if ( ! $api_key ) {
        // Fallback: return template based on price_min/price_max
        $items = gs_enh_quotation_template_fallback( $lead );
        wp_send_json_success( $items );
    }

    $context = "Service: " . ( $lead->listing_title ?? 'General service' ) . "\n"
             . "Customer inquiry: " . ( $lead->message ?? 'No details provided' ) . "\n"
             . ( $lead->price_min ? "Vendor typical price range: ₹{$lead->price_min} – ₹{$lead->price_max}\n" : '' );

    $system = 'You are a quotation assistant for a service marketplace in India. '
        . 'Generate a professional quotation suggestion. '
        . 'Respond ONLY with a JSON object: '
        . '{"line_items":[{"description":"...","qty":1,"rate":0,"unit":"job"}],'
        . '"scope":"One sentence describing scope of work",'
        . '"timeline":"e.g. 2-3 days",'
        . '"payment_terms":"e.g. 50% advance, 50% on completion",'
        . '"notes":"Any relevant notes"}. '
        . 'Use INR amounts. No markdown, no explanation outside JSON.';

    $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
        'timeout' => 15,
        'headers' => [
            'x-api-key'         => $api_key,
            'anthropic-version' => '2023-06-01',
            'Content-Type'      => 'application/json',
        ],
        'body' => wp_json_encode( [
            'model'      => 'claude-haiku-4-5-20251001',
            'max_tokens' => 500,
            'system'     => $system,
            'messages'   => [ [ 'role' => 'user', 'content' => $context ] ],
        ] ),
    ] );

    if ( is_wp_error( $response ) ) {
        wp_send_json_success( gs_enh_quotation_template_fallback( $lead ) );
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    $text = $body['content'][0]['text'] ?? '';
    $text = preg_replace( '/```json|```/', '', $text );
    $data = json_decode( trim( $text ), true );

    if ( ! is_array( $data ) || empty( $data['line_items'] ) ) {
        wp_send_json_success( gs_enh_quotation_template_fallback( $lead ) );
    }

    wp_send_json_success( array_merge( $data, [ 'ai_generated' => true ] ) );
}

function gs_enh_quotation_template_fallback( object $lead ): array {
    $rate = (float) ( (float)( $lead->price_min ?? 0 ) ?: 500.0 );
    return [
        'line_items'    => [
            [ 'description' => $lead->listing_title ?? 'Service charge', 'qty' => 1, 'rate' => $rate, 'unit' => 'job' ],
        ],
        'scope'         => 'Service as discussed in the inquiry.',
        'timeline'      => '1-3 business days',
        'payment_terms' => '100% on completion',
        'notes'         => '',
        'ai_generated'  => false,
    ];
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT — AI SEO TITLE/DESCRIPTION GENERATOR
 *
 * Real, confirmed gap this fixes: when a vendor leaves the SEO Title/
 * Description fields blank (the common case — most vendors are not
 * copywriters), the page falls back to a generic, formulaic string
 * ("$brand — $tagline in $city"), identical in structure for every
 * listing in a category. A genuinely tailored title written with the
 * listing's real services, city, and the vendor's own chosen focus
 * keyword is a real, measurable advantage in click-through rate over a
 * templated one — confirmed via research this session (review/profile
 * detail and completeness correlate with higher-ranking listings).
 *
 * Same proven pattern as gs_enh_ajax_gs_enh_ai_quotation_suggest above:
 * real API call with a graceful, still-useful fallback if no key is
 * configured, so the feature never just breaks with nothing usable.
 * ═══════════════════════════════════════════════════════════════════════════ */
function gs_enh_ajax_gs_enh_ai_generate_seo(): void {
    gs_enh_verify_nonce();
    gs_enh_require_vendor();

    // Real fix, audit item 1: enforces the previously-dead show_seo_tools
    // subscription flag. Only restricts genuine vendors — admins and
    // regional managers also reach this endpoint (both pass
    // can_create_listings()) but have no vendor subscription record at
    // all, so gating on gs_vendor_can() alone would have incorrectly
    // blocked them too, since that function returns false whenever no
    // subscription exists at all, not just when the flag is off.
    if ( \GoodService\Core\Roles::is_vendor() && ! gs_vendor_can( 'seo_tools' ) ) {
        wp_send_json_error( [ 'message' => 'AI-powered SEO tools are not included in your current plan. Upgrade your subscription to use this feature.' ], 403 );
    }

    $title      = sanitize_text_field( $_POST['title']      ?? '' );
    $category   = sanitize_text_field( $_POST['category']   ?? '' );
    $city       = sanitize_text_field( $_POST['city']       ?? '' );
    $keyword    = sanitize_text_field( $_POST['keyword']     ?? '' );
    $short_desc = sanitize_textarea_field( $_POST['short_desc'] ?? '' );

    if ( ! $title ) { wp_send_json_error( [ 'message' => 'Listing title is required.' ] ); }

    $api_key = \GoodService\Core\Config::get( 'gs_anthropic_api_key', '' )
            ?: \GoodService\Core\Config::get( 'anthropic_api_key', '' );

    if ( ! $api_key ) {
        wp_send_json_success( gs_enh_seo_template_fallback( $title, $category, $city, $keyword, $short_desc ) );
    }

    $context = "Business/listing name: {$title}\n"
             . ( $category ? "Category: {$category}\n" : '' )
             . ( $city     ? "City: {$city}\n"         : '' )
             . ( $keyword  ? "Primary keyword to include naturally: {$keyword}\n" : '' )
             . ( $short_desc ? "Existing description: {$short_desc}\n" : '' );

    $system = 'You write SEO titles and meta descriptions for local service listings on an Indian service marketplace. '
        . 'The title must be 50-60 characters, the meta description must be 140-160 characters. '
        . 'Both must read naturally to a human, not like keyword stuffing. '
        . 'Include the city and category naturally if given. '
        . 'Respond ONLY with a JSON object: {"seo_title":"...","seo_desc":"..."}. No markdown, no explanation outside JSON.';

    $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
        'timeout' => 15,
        'headers' => [
            'x-api-key'         => $api_key,
            'anthropic-version' => '2023-06-01',
            'Content-Type'      => 'application/json',
        ],
        'body' => wp_json_encode( [
            'model'      => 'claude-haiku-4-5-20251001',
            'max_tokens' => 300,
            'system'     => $system,
            'messages'   => [ [ 'role' => 'user', 'content' => $context ] ],
        ] ),
    ] );

    if ( is_wp_error( $response ) ) {
        wp_send_json_success( array_merge(
            gs_enh_seo_template_fallback( $title, $category, $city, $keyword, $short_desc ),
            [ 'ai_note' => 'AI unavailable (network error) — used smart template instead.' ]
        ) );
        return;
    }

    $http_code = (int) wp_remote_retrieve_response_code( $response );
    if ( $http_code === 401 ) {
        wp_send_json_error( [ 'message' => 'AI key invalid or expired — check Settings › AI & Automation and update your Anthropic API key.' ] );
        return;
    }
    if ( $http_code === 429 ) {
        wp_send_json_success( array_merge(
            gs_enh_seo_template_fallback( $title, $category, $city, $keyword, $short_desc ),
            [ 'ai_note' => 'AI rate limit reached — used smart template instead. Try again in a moment.' ]
        ) );
        return;
    }
    if ( $http_code < 200 || $http_code >= 300 ) {
        wp_send_json_success( array_merge(
            gs_enh_seo_template_fallback( $title, $category, $city, $keyword, $short_desc ),
            [ 'ai_note' => "AI service returned HTTP {$http_code} — used smart template instead." ]
        ) );
        return;
    }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    $text = $body['content'][0]['text'] ?? '';
    $text = preg_replace( '/```json|```/', '', $text );
    $data = json_decode( trim( $text ), true );

    if ( ! is_array( $data ) || empty( $data['seo_title'] ) || empty( $data['seo_desc'] ) ) {
        wp_send_json_success( array_merge(
            gs_enh_seo_template_fallback( $title, $category, $city, $keyword, $short_desc ),
            [ 'ai_note' => 'AI returned an unexpected response — used smart template instead.' ]
        ) );
        return;
    }

    // Enforce REAL pixel-width limits, not character count — Google
    // truncates by rendered pixel width (confirmed via research: ~580-600px
    // for titles, ~920px for descriptions), not by character count. A
    // title full of wide capitals ("W", "M") can overflow well before 70
    // characters; one using narrow letters ("i", "l") can safely run
    // longer. The old mb_substr(...,0,70) check was blind to this.
    $data['seo_title'] = gs_enh_trim_to_pixel_width( trim( (string) $data['seo_title'] ), 580 );
    $data['seo_desc']  = gs_enh_trim_to_pixel_width( trim( (string) $data['seo_desc']  ), 920 );

    wp_send_json_success( array_merge( $data, [ 'ai_generated' => true ] ) );
}

/**
 * Real, published per-character pixel widths for Arial at a standard
 * size, sourced from direct browser measurement (not invented) — see
 * gist.github.com/aminnj/5ca372aa2def72fb017b531c894afdca, confirmed via
 * research as accurate to within ~6% of true rendered width, versus
 * ~17% error for treating every character as the same width. Used as
 * the closest available open reference for what Google's SERP font
 * actually renders, since there is no official published table for
 * Google's exact font.
 */
function gs_enh_arial_char_widths(): array {
    static $widths = null;
    if ( $widths !== null ) { return $widths; }
    $widths = [
        ' '=>4.45,'!'=>4.45,'"'=>5.68,'#'=>8.90,'$'=>8.90,'%'=>14.23,'&'=>10.67,"'"=>3.05,
        '('=>5.33,')'=>5.33,'*'=>6.23,'+'=>9.34,','=>4.45,'-'=>5.33,'.'=>4.45,'/'=>4.45,
        '0'=>8.90,'1'=>7.72,'2'=>8.90,'3'=>8.90,'4'=>8.90,'5'=>8.90,'6'=>8.90,'7'=>8.90,
        '8'=>8.90,'9'=>8.90,':'=>4.45,';'=>4.45,'<'=>9.34,'='=>9.34,'>'=>9.34,'?'=>8.90,
        '@'=>16.24,'A'=>10.67,'B'=>10.67,'C'=>11.55,'D'=>11.55,'E'=>10.67,'F'=>9.77,'G'=>12.45,
        'H'=>11.55,'I'=>4.45,'J'=>8.00,'K'=>10.67,'L'=>8.90,'M'=>13.33,'N'=>11.55,'O'=>12.45,
        'P'=>10.67,'Q'=>12.45,'R'=>11.55,'S'=>10.67,'T'=>9.77,'U'=>11.55,'V'=>10.67,'W'=>15.10,
        'X'=>10.67,'Y'=>10.67,'Z'=>9.77,'['=>4.45,'\\'=>4.45,']'=>4.45,'^'=>7.51,'_'=>8.90,
        '`'=>5.33,'a'=>8.90,'b'=>8.90,'c'=>8.00,'d'=>8.90,'e'=>8.90,'f'=>4.16,'g'=>8.90,
        'h'=>8.90,'i'=>3.55,'j'=>3.55,'k'=>8.00,'l'=>3.55,'m'=>13.33,'n'=>8.90,'o'=>8.90,
        'p'=>8.90,'q'=>8.90,'r'=>5.33,'s'=>8.00,'t'=>4.45,'u'=>8.90,'v'=>8.00,'w'=>11.55,
        'x'=>8.00,'y'=>8.00,'z'=>8.00,'{'=>5.34,'|'=>4.16,'}'=>5.34,'~'=>9.34,
    ];
    return $widths;
}

/** Estimate the real rendered pixel width of a string at the standard
 *  16px Arial-equivalent size used for the character table above. */
function gs_enh_estimate_pixel_width( string $text ): float {
    $widths = gs_enh_arial_char_widths();
    $total  = 0.0;
    $len    = mb_strlen( $text, 'UTF-8' );
    for ( $i = 0; $i < $len; $i++ ) {
        $ch = mb_substr( $text, $i, 1, 'UTF-8' );
        // Unknown/non-ASCII characters (e.g. Devanagari, accented Latin):
        // fall back to the average width in the table rather than 0,
        // since silently treating them as zero-width would understate
        // real width for any non-English business name or city.
        $total += $widths[ $ch ] ?? 8.5;
    }
    return $total;
}

/** Trim a string to fit within a target pixel width, cutting at the
 *  last complete word rather than mid-word — a title cut off mid-word
 *  ("Acme Plumb...") looks broken in a way a clean word boundary
 *  ("Acme Plumbing...") doesn't. */
function gs_enh_trim_to_pixel_width( string $text, float $max_pixels ): string {
    if ( gs_enh_estimate_pixel_width( $text ) <= $max_pixels ) { return $text; }

    $words = explode( ' ', $text );
    $result = '';
    foreach ( $words as $word ) {
        $candidate = $result === '' ? $word : "{$result} {$word}";
        if ( gs_enh_estimate_pixel_width( $candidate ) > $max_pixels ) { break; }
        $result = $candidate;
    }
    return $result !== '' ? $result : mb_substr( $text, 0, 50 ); // pathological one-word-too-long case
}

function gs_enh_seo_template_fallback( string $title, string $category, string $city, string $keyword, string $short_desc = '' ): array {
    $parts = array_filter( [ $title, $category, $city ? "in {$city}" : '' ] );
    $seo_title = implode( ' — ', $parts );
    $seo_title = gs_enh_trim_to_pixel_width( $seo_title, 580 );

    // Build a description that incorporates the specific business name so
    // two vendors in the same category+city get differentiated descriptions.
    if ( $short_desc ) {
        // Use a trimmed version of the actual description — most differentiating
        $desc = wp_strip_all_tags( $short_desc );
        $desc = $desc ? gs_enh_trim_to_pixel_width( $desc, 920 ) : '';
    }
    if ( empty( $desc ) ) {
        $desc_bits = [];
        if ( $title )    { $desc_bits[] = "{$title}"; }
        if ( $category ) { $desc_bits[] = "provides trusted {$category} services"; }
        if ( $city )     { $desc_bits[] = "in {$city}"; }
        $desc = $desc_bits ? implode( ' ', $desc_bits ) . '. ' : '';
        $desc .= $keyword ? "Specializing in {$keyword}. " : '';
        $desc .= 'Contact us today for a free quote.';
    }
    $seo_desc = gs_enh_trim_to_pixel_width( trim( $desc ), 920 );

    return [ 'seo_title' => $seo_title, 'seo_desc' => $seo_desc, 'ai_generated' => false ];
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT B — AI LEAD QUALIFICATION (Blueprint #12)
 *
 * Root cause: no classification at inquiry submit time.
 * Fix: capture POST at priority 1 (before submit handler), register shutdown
 * hook, classify at shutdown AFTER response sent using fully prepared SQL.
 *
 * FIX 3 — Unprepared SQL: the shutdown query now uses $wpdb->prepare() on
 * the full outer query, not just the WHERE clause fragment.
 *
 * Observable output:
 *  BEFORE: leads.intent_class = 'unknown' for all leads.
 *  AFTER:  leads.intent_class set to 'hot'|'warm'|'cold' within seconds
 *          of submission (after response already sent to browser).
 * ════════════════════════════════════════════════════════════════════════ */
$GLOBALS['gs_enh_pending_lead_post'] = null;

function gs_enh_qualify_lead_capture(): void {
    $GLOBALS['gs_enh_pending_lead_post'] = $_POST;
    add_action( 'shutdown', 'gs_enh_qualify_lead_at_shutdown', 50 );
}

function gs_enh_qualify_lead_at_shutdown(): void {
    global $wpdb;
    $post = $GLOBALS['gs_enh_pending_lead_post'];
    if ( ! $post ) { return; }

    $listing_id = (int) ( $post['listing_id'] ?? 0 );
    if ( ! $listing_id ) { return; }

    // Column guard
    $cols = gs_enh_table_cols( $wpdb->prefix . 'gs_leads' );
    if ( ! in_array( 'intent_class', $cols, true ) ) { return; }

    // FIX 3: Fully prepared query — both listing_id AND the timestamp are parameterised
    $lead = $wpdb->get_row( $wpdb->prepare(
        "SELECT id, message, urgency_level
         FROM {$wpdb->prefix}gs_leads
         WHERE listing_id = %d
           AND created_at >= %s
         ORDER BY id DESC LIMIT 1",
        $listing_id,
        date( 'Y-m-d H:i:s', time() - 10 ) // 10 second window
    ) );

    if ( ! $lead ) { return; }

    $message        = (string) ( $lead->message ?? '' );
    $classification = gs_enh_classify_lead_intent( $message, $post );
    if ( ! $classification ) { return; }

    $wpdb->update(
        $wpdb->prefix . 'gs_leads',
        [ 'intent_class' => $classification['class'], 'intent_score' => $classification['score'] ],
        [ 'id' => (int) $lead->id ]
    );
}

function gs_enh_classify_lead_intent( string $message, array $post ): ?array {
    if ( empty( $message ) ) { return gs_enh_rule_based_intent( $post ); }

    $api_key = \GoodService\Core\Config::get( 'gs_anthropic_api_key', '' )
            ?: \GoodService\Core\Config::get( 'anthropic_api_key', '' );

    if ( ! $api_key ) { return gs_enh_rule_based_intent( $post ); }

    $urgency  = sanitize_text_field( $post['urgency_level'] ?? $post['urgency'] ?? '' );
    $safe_msg = function_exists('mb_substr') ? mb_substr( $message, 0, 400 ) : substr( $message, 0, 400 );
    $user_msg = "Inquiry: " . $safe_msg;
    if ( $urgency ) { $user_msg .= "\nUrgency: {$urgency}"; }

    $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
        'timeout' => 10,
        'headers' => [
            'x-api-key'         => $api_key,
            'anthropic-version' => '2023-06-01',
            'Content-Type'      => 'application/json',
        ],
        'body' => wp_json_encode( [
            'model'      => 'claude-haiku-4-5-20251001',
            'max_tokens' => 80,
            'system'     => 'Lead qualifier for India home services marketplace. '
                . 'Reply ONLY with JSON: {"class":"hot|warm|cold","score":0-100}. '
                . 'hot=urgent+specific+ready. warm=interested but unclear. cold=vague/browsing.',
            'messages'   => [ [ 'role' => 'user', 'content' => $user_msg ] ],
        ] ),
    ] );

    if ( is_wp_error( $response ) ) { return gs_enh_rule_based_intent( $post ); }

    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    $text = trim( preg_replace( '/```json|```/', '', $body['content'][0]['text'] ?? '' ) );
    $data = json_decode( $text, true );

    if ( ! is_array( $data ) || ! isset( $data['class'], $data['score'] ) ) {
        return gs_enh_rule_based_intent( $post );
    }

    $class = in_array( $data['class'], [ 'hot', 'warm', 'cold' ], true )
           ? $data['class'] : 'unknown';
    return [ 'class' => $class, 'score' => (int) min( 100, max( 0, $data['score'] ) ) ];
}

function gs_enh_rule_based_intent( array $post ): array {
    $score   = 50;
    $urgency = strtolower( $post['urgency_level'] ?? $post['urgency'] ?? '' );

    if ( in_array( $urgency, [ 'urgent', 'asap', 'today', 'emergency' ], true ) ) { $score += 30; }
    if ( ! empty( $post['booking_date'] ) ) { $score += 15; }
    if ( ! empty( $post['booking_time'] ) ) { $score += 5; }

    $raw_msg = $post['message'] ?? $post['description'] ?? '';
    $msg_len = function_exists('mb_strlen') ? mb_strlen( $raw_msg ) : strlen( $raw_msg );
    if ( $msg_len > 100 ) { $score += 10; }
    if ( $msg_len < 20  ) { $score -= 15; }

    $score = max( 0, min( 100, $score ) );
    return [ 'class' => $score >= 70 ? 'hot' : ( $score >= 40 ? 'warm' : 'cold' ), 'score' => $score ];
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT C — LOST LEAD ATTRIBUTION (Blueprint #14)
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_ajax_gs_enh_mark_lead_lost(): void {
    gs_enh_verify_nonce();
    gs_enh_require_vendor();

    global $wpdb;
    $lead_id     = (int) ( $_POST['lead_id']    ?? 0 );
    $lost_reason = sanitize_text_field( $_POST['lost_reason'] ?? '' );
    $lost_to     = sanitize_text_field( $_POST['lost_to']     ?? '' );

    $valid_reasons = [ 'price', 'slow', 'chose_other', 'not_relevant', 'other' ];
    if ( ! $lead_id ) { wp_send_json_error( [ 'message' => 'lead_id required.' ] ); }
    if ( $lost_reason && ! in_array( $lost_reason, $valid_reasons, true ) ) {
        wp_send_json_error( [ 'message' => 'Invalid lost_reason.' ] );
    }

    $vp = \GoodService\Repository\VendorRepository::get_by_user( get_current_user_id() );
    if ( ! $vp ) { wp_send_json_error( [ 'message' => 'Vendor not found.' ] ); }

    // IDOR protection: verify lead belongs to this vendor
    $lead = $wpdb->get_row( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}gs_leads WHERE id = %d AND vendor_id = %d",
        $lead_id, (int) $vp->id
    ) );
    if ( ! $lead ) { wp_send_json_error( [ 'message' => 'Lead not found or not yours.' ], 403 ); }

    $cols        = gs_enh_table_cols( $wpdb->prefix . 'gs_leads' );
    $update_data = [ 'status' => 'lost', 'updated_at' => current_time( 'mysql' ) ];

    if ( in_array( 'lost_reason', $cols, true ) ) {
        $update_data['lost_reason'] = $lost_reason;
        $update_data['lost_to']     = $lost_to;
    }

    $result = $wpdb->update(
        $wpdb->prefix . 'gs_leads',
        $update_data,
        [ 'id' => $lead_id, 'vendor_id' => (int) $vp->id ]
    );

    if ( $result === false ) {
        wp_send_json_error( [ 'message' => 'DB error: ' . $wpdb->last_error ] );
    }

    if ( class_exists( 'GoodService\\Core\\Cache' ) ) {
        \GoodService\Core\Cache::delete( "leads:stats:{$vp->id}" );
    }

    wp_send_json_success( [ 'message' => 'Lead marked as lost.' ] );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT D — SMART LEAD DISTRIBUTION CAP (Blueprint #13)
 *
 * Observable output:
 *  BEFORE: No cap — a vendor with 0 staff could receive unlimited daily leads.
 *  AFTER:  If vendor's plan has lead_cap_per_day > 0 AND today's count >= cap,
 *          customer sees silent success but lead is NOT written. Logged.
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_check_lead_cap(): void {
    global $wpdb;

    $listing_id = (int) ( $_POST['listing_id'] ?? 0 );
    if ( ! $listing_id ) { return; }

    $vendor_id = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT vendor_id FROM {$wpdb->prefix}gs_listings WHERE id = %d AND status = 'active'",
        $listing_id
    ) );
    if ( ! $vendor_id ) { return; }

    // Check plan cap column exists
    $plan_cols = gs_enh_table_cols( $wpdb->prefix . 'gs_subscription_plans' );
    if ( ! in_array( 'lead_cap_per_day', $plan_cols, true ) ) { return; }

    $plan = $wpdb->get_row( $wpdb->prepare(
        "SELECT sp.lead_cap_per_day
         FROM {$wpdb->prefix}gs_subscriptions sub
         INNER JOIN {$wpdb->prefix}gs_subscription_plans sp ON sp.id = sub.plan_id
         WHERE sub.vendor_id = %d AND sub.status = 'active'
         LIMIT 1",
        $vendor_id
    ) );

    $cap = (int) ( $plan->lead_cap_per_day ?? 0 );
    if ( $cap === 0 ) { return; } // 0 = unlimited

    $today_count = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}gs_leads
         WHERE vendor_id = %d AND DATE(created_at) = CURDATE()",
        $vendor_id
    ) );

    if ( $today_count >= $cap ) {
        if ( function_exists( 'gs_write_log' ) ) {
            gs_write_log(
                "[GS_Enhancements] Lead cap reached: vendor {$vendor_id} {$today_count}/{$cap} today. Listing {$listing_id} silently dropped.",
                'INFO'
            );
        }
        // Silent success to customer — cap enforcement is invisible to them
        wp_send_json_success( [ 'message' => 'Your inquiry has been sent!' ] );
        // exit() is called by wp_send_json_success — original handler never runs
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT K — HYBRID RANKING SEARCH WRAPPER (Blueprint #16)
 *
 * Root cause: ListingRepository::search() default sort = featured+rating+views.
 * trust_score and response_rate are on gs_vendor_profiles — not in the search
 * query which only joins gs_categories. We cannot add the JOIN without
 * modifying ListingRepository.
 *
 * Fix: New public AJAX endpoint gs_enh_search_listings calls the original
 * gs_search_listings handler's logic (via ListingRepository::search directly)
 * and then post-sorts results by hybrid score in PHP.
 *
 * Hybrid score = is_featured*100 + avg_rating*20 + trust_score*0.3 + response_rate*0.2 + boost*5
 *
 * FIX 4 — New-provider boost now applied: boost_until is read from vendor
 * profile data fetched in this handler.
 *
 * Observable output:
 *  BEFORE: Search returns featured+rating+views order. Trust/response ignored.
 *  AFTER:  gs_enh_search_listings returns listings with vendor trust score and
 *          response rate factored in. New verified providers get +5 pts for 90d.
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_ajax_gs_enh_search_listings(): void {
    global $wpdb;

    $keyword  = sanitize_text_field( $_POST['keyword']  ?? '' );
    $city     = sanitize_text_field( $_POST['city']     ?? '' );
    $category = (int) ( $_POST['category'] ?? 0 );
    $type     = sanitize_text_field( $_POST['type']     ?? '' );
    $page     = max( 1, (int) ( $_POST['page']     ?? 1 ) );
    $per_page = min( 60, max( 1, (int) ( $_POST['per_page'] ?? 12 ) ) );

    // Use existing ListingRepository search
    $result = ( new \GoodService\Repository\ListingRepository() )->search( [
        'keyword'  => $keyword,
        'city'     => $city,
        'category' => $category,
        'type'     => $type,
        'page'     => $page,
        'per_page' => $per_page,
        'sort'     => 'featured', // get base result, we'll re-sort
    ] );

    $listings = $result['listings'] ?? [];
    if ( empty( $listings ) ) {
        wp_send_json_success( $result );
    }

    // Fetch vendor profile data for all vendors in result in one query
    $vendor_ids  = array_unique( array_map( fn( $l ) => (int) $l->vendor_id, $listings ) );
    $ids_sql     = implode( ',', $vendor_ids );

    // Determine which optional columns to fetch
    $vp_cols     = gs_enh_table_cols( $wpdb->prefix . 'gs_vendor_profiles' );
    $boost_sel   = in_array( 'boost_until', $vp_cols, true ) ? ', boost_until' : '';

    $vp_rows = $wpdb->get_results(
        "SELECT id, trust_score, response_rate {$boost_sel}
         FROM {$wpdb->prefix}gs_vendor_profiles
         WHERE id IN ({$ids_sql})"
    );
    $vp_by_id = [];
    foreach ( $vp_rows as $vp ) { $vp_by_id[ (int) $vp->id ] = $vp; }

    // Score and re-sort
    $now = time();
    foreach ( $listings as $listing ) {
        $vp    = $vp_by_id[ (int) $listing->vendor_id ] ?? null;
        $trust = (float) ( $vp->trust_score   ?? 0 );
        $resp  = (float) ( $vp->response_rate ?? 0 );
        $boost = 0.0;
        if ( $vp && ! empty( $vp->boost_until ) && strtotime( $vp->boost_until ) > $now ) {
            $boost = 5.0;
        }
        $featured = (float) ( $listing->is_featured ?? 0 );
        $rating   = (float) ( $listing->avg_rating  ?? 0 );

        $listing->hybrid_score = $featured * 100
                               + $rating   * 20
                               + $trust    * 0.3
                               + $resp     * 0.2
                               + $boost;

        // Expose vendor data for frontend
        $listing->trust_score   = (int) $trust;
        $listing->response_rate = (int) $resp;
        $listing->is_boosted    = $boost > 0;
    }

    usort( $listings, fn( $a, $b ) => $b->hybrid_score <=> $a->hybrid_score );

    $result['listings'] = $listings;
    wp_send_json_success( $result );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT D (NEW PROVIDER BOOST SET) (Blueprint #15)
 *
 * FIX 4 — boost_until is set here; gs_enh_search_listings reads it.
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_set_new_provider_boost(): void {
    global $wpdb;
    $vendor_id = (int) ( $_POST['vendor_id'] ?? 0 );
    if ( ! $vendor_id ) { return; }

    $current = $wpdb->get_var( $wpdb->prepare(
        "SELECT verification_status FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d",
        $vendor_id
    ) );

    // Only set boost on FIRST verification (was unverified or pending)
    if ( $current !== 'unverified' && $current !== 'pending' ) { return; }

    $cols = gs_enh_table_cols( $wpdb->prefix . 'gs_vendor_profiles' );
    if ( ! in_array( 'boost_until', $cols, true ) ) { return; }

    $wpdb->update(
        $wpdb->prefix . 'gs_vendor_profiles',
        [ 'boost_until' => date( 'Y-m-d H:i:s', strtotime( '+90 days' ) ) ],
        [ 'id' => $vendor_id ]
    );

    if ( class_exists( 'GoodService\\Core\\Cache' ) ) {
        \GoodService\Core\Cache::delete( "vendor:id:{$vendor_id}" );
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
 * FEAT A (PRICE RANGE) — Customer-facing price range (Blueprint #4)
 *
 * FIX 5 — Now also injects JS snippet on listing pages via wp_footer.
 *
 * Observable output:
 *  BEFORE: No price info shown to customers before inquiry.
 *  AFTER:  Listing pages show "Typical cost: ₹X – ₹Y" banner above inquiry
 *          form (via injected JS that calls gs_enh_get_price_range).
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_ajax_gs_enh_get_price_range(): void {
    global $wpdb;
    $pfx = $wpdb->prefix . 'gs_';

    $listing_id  = (int) ( $_POST['listing_id']  ?? 0 );
    $listing_slug = sanitize_text_field( $_POST['listing_slug'] ?? '' );
    $category_id = (int) ( $_POST['category_id'] ?? 0 );
    $city        = sanitize_text_field( $_POST['city'] ?? '' );

    if ( $listing_id ) {
        $listing = $wpdb->get_row( $wpdb->prepare(
            "SELECT category_id, city FROM {$pfx}listings WHERE id = %d AND status = 'active'",
            $listing_id
        ) );
        if ( ! $listing ) { wp_send_json_error( [ 'message' => 'Listing not found.' ] ); }
        $category_id = (int) $listing->category_id;
        $city        = (string) $listing->city;
    } elseif ( $listing_slug ) {
        // Public listing pages pass slug (Router sets gs_slug, not gs_listing_id)
        $listing = $wpdb->get_row( $wpdb->prepare(
            "SELECT category_id, city FROM {$pfx}listings WHERE slug = %s AND status = 'active'",
            $listing_slug
        ) );
        if ( ! $listing ) { wp_send_json_error( [ 'message' => 'Listing not found.' ] ); }
        $category_id = (int) $listing->category_id;
        $city        = (string) $listing->city;
    }

    if ( ! $category_id ) { wp_send_json_error( [ 'message' => 'category_id or listing_id required.' ] ); }

    // Query: price_min for same category+city (min 3 data points)
    $prices = $wpdb->get_col( $wpdb->prepare(
        "SELECT price_min FROM {$pfx}listings
         WHERE category_id = %d AND status = 'active' AND price_min > 0 AND city = %s
         ORDER BY price_min ASC",
        $category_id, $city
    ) );

    // Fallback: category-wide if city < 3 results
    if ( count( $prices ) < 3 && $city !== '' ) {
        $prices = $wpdb->get_col( $wpdb->prepare(
            "SELECT price_min FROM {$pfx}listings
             WHERE category_id = %d AND status = 'active' AND price_min > 0
             ORDER BY price_min ASC",
            $category_id
        ) );
    }

    if ( empty( $prices ) ) {
        wp_send_json_success( [ 'available' => false, 'listing_count' => 0 ] );
    }

    $prices      = array_map( 'floatval', $prices );
    $count       = count( $prices );
    $mid         = (int) floor( ( $count - 1 ) / 2 );
    $median      = $count % 2 === 0
                 ? ( $prices[ $mid ] + $prices[ $mid + 1 ] ) / 2
                 : $prices[ $mid ];

    wp_send_json_success( [
        'available'     => true,
        'price_min'     => round( $prices[0], 2 ),
        'price_max'     => round( end( $prices ), 2 ),
        'median_price'  => round( $median, 2 ),
        'listing_count' => $count,
        'currency'      => 'INR',
        'label'         => sprintf(
            'Typical cost in your area: ₹%s – ₹%s',
            number_format( $prices[0], 0 ),
            number_format( end( $prices ), 0 )
        ),
    ] );
}

/**
 * Inject JS snippet on listing detail pages so price range is fetched and
 * displayed automatically — no template modification required.
 *
 * Observable output: customer sees a teal banner "Typical cost: ₹X – ₹Y"
 * above the inquiry button on listing pages that have enough price data.
 */
function gs_enh_inject_price_range_js(): void {
    // Router sets gs_page='listing' and gs_slug=<slug> on public listing pages.
    // gs_listing_id is only set on vendor edit pages — NOT public listing pages.
    $gs_page = get_query_var( 'gs_page', '' );
    if ( $gs_page !== 'listing' ) { return; }

    $gs_slug = sanitize_text_field( get_query_var( 'gs_slug', '' ) );
    if ( ! $gs_slug ) { return; }

    $ajax_url = admin_url( 'admin-ajax.php' );
    ?>
    <script>
    (function(){
        var listingSlug = <?php echo wp_json_encode( $gs_slug ); ?>;
        if(!listingSlug){return;}
        var fd = new FormData();
        fd.append('action','gs_enh_get_price_range');
        fd.append('listing_slug', listingSlug);
        fetch(<?php echo wp_json_encode( $ajax_url ); ?>, {method:'POST', body:fd})
        .then(function(r){return r.json();})
        .then(function(res){
            if(!res.success || !res.data || !res.data.available){return;}
            var label = res.data.label;
            // Find the inquiry form or a suitable insertion point
            var targets = document.querySelectorAll('.gs-inquiry-form, .gs-lead-form, [data-gs-inquiry], #gs-inquiry-section');
            if(!targets.length){return;}
            var banner = document.createElement('div');
            banner.style.cssText = 'background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:.85rem;color:#166534;display:flex;align-items:center;gap:8px;';
            banner.innerHTML = '<span style="font-size:1.1rem">💰</span><span>' + label + ' · Based on ' + res.data.listing_count + ' providers in this category</span>';
            targets[0].parentNode.insertBefore(banner, targets[0]);
        })
        .catch(function(){/* silent fail — not critical */});
    })();
    </script>
    <?php
}

/* ═══════════════════════════════════════════════════════════════════════════
 * ── ITEM 1: SAFETY RECORDS (Blueprint #5) ──────────────────────────────────
 *
 * Vendors submit safety documents (police clearance, background check, ID proof,
 * address proof) via the existing gs_upload_verification_doc action.
 * When an admin approves a safety-type doc, we set safety_verified=1 on the
 * vendor profile BEFORE the main approveVerificationDoc handler runs.
 *
 * New columns on vendor_profiles:
 *   safety_verified   TINYINT(1)  — 1 when at least one safety doc approved
 *   safety_doc_type   VARCHAR(50) — type of approved safety doc
 *   safety_verified_at DATETIME   — approval timestamp
 *
 * Observable output:
 *   BEFORE: No safety credential distinction. Any vendor looks same as police-cleared one.
 *   AFTER:  safety_verified=1 on vendor profile after admin approves. Listing responses
 *           include safety_verified flag for frontend badge display.
 * ════════════════════════════════════════════════════════════════════════ */

/** Safety document types accepted as credential proof */
const GS_ENH_SAFETY_DOC_TYPES = [
    'police_clearance'  => 'Police Clearance Certificate',
    'background_check'  => 'Background Check Report',
    'id_proof'          => 'Government ID Proof',
    'address_proof'     => 'Address Verification Proof',
];

/**
 * Hook at priority 9 on gs_approve_verification_doc.
 * If the doc being approved is a safety type, set safety_verified=1 on vendor_profiles.
 * The main approveVerificationDoc handler (priority 10) then runs normally.
 * We write to a DIFFERENT column (safety_verified vs verification_status) so no conflict.
 */
function gs_enh_hook_safety_doc_approval(): void {
    global $wpdb;

    $doc_id = (int) ( $_POST['doc_id'] ?? 0 );
    $status = sanitize_text_field( $_POST['status'] ?? '' );

    if ( ! $doc_id || $status !== 'approved' ) { return; } // Only on approval

    $doc = $wpdb->get_row( $wpdb->prepare(
        "SELECT vendor_id, doc_type FROM {$wpdb->prefix}gs_verification_docs WHERE id = %d",
        $doc_id
    ) );

    if ( ! $doc ) { return; }
    if ( ! isset( GS_ENH_SAFETY_DOC_TYPES[ $doc->doc_type ] ) ) { return; } // Not a safety doc

    // Check columns exist
    $cols = gs_enh_table_cols( $wpdb->prefix . 'gs_vendor_profiles' );
    if ( ! in_array( 'safety_verified', $cols, true ) ) { return; }

    $wpdb->update(
        $wpdb->prefix . 'gs_vendor_profiles',
        [
            'safety_verified'    => 1,
            'safety_doc_type'    => $doc->doc_type,
            'safety_verified_at' => current_time( 'mysql' ),
        ],
        [ 'id' => (int) $doc->vendor_id ]
    );

    if ( class_exists( 'GoodService\\Core\\Cache' ) ) {
        \GoodService\Core\Cache::delete( "vendor:id:{$doc->vendor_id}" );
    }
}

/** Vendor submits a safety document for review */
function gs_enh_ajax_gs_enh_submit_safety_doc(): void {
    gs_enh_verify_nonce();
    gs_enh_require_vendor();

    $doc_type = sanitize_key( $_POST['doc_type'] ?? '' );
    if ( ! isset( GS_ENH_SAFETY_DOC_TYPES[ $doc_type ] ) ) {
        wp_send_json_error( [
            'message'    => 'Invalid document type.',
            'valid_types' => array_keys( GS_ENH_SAFETY_DOC_TYPES ),
        ] );
    }

    $doc_url = esc_url_raw( $_POST['doc_url'] ?? '' );
    if ( ! $doc_url ) {
        wp_send_json_error( [ 'message' => 'Document URL is required.' ] );
    }

    global $wpdb;
    $vp = \GoodService\Repository\VendorRepository::get_by_user( get_current_user_id() );
    if ( ! $vp ) { wp_send_json_error( [ 'message' => 'Vendor profile not found.' ] ); }

    $result = $wpdb->insert( $wpdb->prefix . 'gs_verification_docs', [
        'vendor_id'  => (int) $vp->id,
        'doc_type'   => $doc_type,
        'doc_url'    => $doc_url,
        'doc_name'   => sanitize_text_field( $_POST['doc_name'] ?? GS_ENH_SAFETY_DOC_TYPES[ $doc_type ] ),
        'status'     => 'pending',
        'created_at' => current_time( 'mysql' ),
    ] );

    if ( ! $result ) {
        wp_send_json_error( [ 'message' => 'Failed to submit document. DB error: ' . $wpdb->last_error ] );
    }

    // Set vendor to pending if currently unverified
    if ( $vp->verification_status === 'unverified' ) {
        $wpdb->update(
            $wpdb->prefix . 'gs_vendor_profiles',
            [ 'verification_status' => 'pending' ],
            [ 'id' => (int) $vp->id ]
        );
        \GoodService\Core\Cache::delete( "vendor:user:" . get_current_user_id() );
    }

    wp_send_json_success( [
        'message'   => 'Safety document submitted for review. You will be notified once reviewed.',
        'doc_id'    => (int) $wpdb->insert_id,
        'doc_type'  => $doc_type,
        'type_name' => GS_ENH_SAFETY_DOC_TYPES[ $doc_type ],
    ] );
}

/** Vendor reads their own safety docs and current safety_verified status */
function gs_enh_ajax_gs_enh_get_safety_docs(): void {
    gs_enh_verify_nonce();
    gs_enh_require_vendor();

    global $wpdb;
    $vp = \GoodService\Repository\VendorRepository::get_by_user( get_current_user_id() );
    if ( ! $vp ) { wp_send_json_error( [ 'message' => 'Vendor not found.' ] ); }

    $docs = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, doc_type, doc_name, status, reviewed_at, notes
         FROM {$wpdb->prefix}gs_verification_docs
         WHERE vendor_id = %d
           AND doc_type IN ('" . implode( "','", array_keys( GS_ENH_SAFETY_DOC_TYPES ) ) . "')
         ORDER BY created_at DESC",
        (int) $vp->id
    ) ) ?: [];

    // Add type labels
    foreach ( $docs as $doc ) {
        $doc->type_name = GS_ENH_SAFETY_DOC_TYPES[ $doc->doc_type ] ?? $doc->doc_type;
    }

    $cols             = gs_enh_table_cols( $wpdb->prefix . 'gs_vendor_profiles' );
    $safety_verified  = in_array( 'safety_verified', $cols, true )  ? (bool) $vp->safety_verified   : false;
    $safety_doc_type  = in_array( 'safety_doc_type', $cols, true )  ? (string) $vp->safety_doc_type  : '';
    $safety_verified_at = in_array( 'safety_verified_at', $cols, true ) ? $vp->safety_verified_at  : null;

    wp_send_json_success( [
        'safety_verified'    => $safety_verified,
        'safety_doc_type'    => $safety_doc_type,
        'safety_verified_at' => $safety_verified_at,
        'docs'               => $docs,
        'accepted_types'     => GS_ENH_SAFETY_DOC_TYPES,
    ] );
}

/** Admin reads safety docs pending review across all vendors */
function gs_enh_ajax_gs_enh_get_safety_docs_admin(): void {
    gs_enh_verify_nonce();
    gs_enh_require_admin();

    global $wpdb;
    $status = sanitize_text_field( $_POST['status'] ?? 'pending' );
    $valid  = [ 'pending', 'approved', 'rejected' ];
    if ( ! in_array( $status, $valid, true ) ) { $status = 'pending'; }

    $types_sql = "'" . implode( "','", array_keys( GS_ENH_SAFETY_DOC_TYPES ) ) . "'";
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT d.*, vp.business_name, vp.email AS vendor_email, vp.safety_verified
         FROM {$wpdb->prefix}gs_verification_docs d
         LEFT JOIN {$wpdb->prefix}gs_vendor_profiles vp ON vp.id = d.vendor_id
         WHERE d.status = %s AND d.doc_type IN ({$types_sql})
         ORDER BY d.created_at ASC
         LIMIT 50",
        $status
    ) ) ?: [];

    foreach ( $rows as $row ) {
        $row->type_name = GS_ENH_SAFETY_DOC_TYPES[ $row->doc_type ] ?? $row->doc_type;
    }

    wp_send_json_success( [ 'docs' => $rows, 'status_filter' => $status ] );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * ── ITEM 2: VERIFIED PORTFOLIO / WORK GALLERY (Blueprint #8) ──────────────
 *
 * Customers who had a completed booking can verify a specific portfolio item
 * on the vendor's listing. This creates a customer-linked proof of work.
 *
 * New columns on gs_listings:
 *   portfolio_verified        TINYINT(1)       — 1 if any item is customer-verified
 *   portfolio_verified_count  SMALLINT UNSIGNED — count of verified portfolio items
 *
 * New table: gs_portfolio_verifications
 *   Records each customer verification of a portfolio item.
 *
 * New AJAX: gs_enh_verify_portfolio_item — logged-in customer with completed booking
 *   POST: listing_id, item_index (0-based index in portfolio_data JSON array)
 *   Verifies: customer has completed booking for this listing
 *   Writes: row to gs_portfolio_verifications + increments listing.portfolio_verified_count
 *
 * Observable output:
 *   BEFORE: Any vendor can upload any image. Zero trust signal.
 *   AFTER:  Portfolio items verified by real customers with completed bookings
 *           get a "Customer Verified" badge. listing.portfolio_verified=1 signals
 *           at least one verified item exists.
 * ════════════════════════════════════════════════════════════════════════ */
add_action( 'plugins_loaded', 'gs_enh_create_portfolio_table', 25 );
function gs_enh_create_portfolio_table(): void {
    global $wpdb;
    $tbl = $wpdb->prefix . 'gs_portfolio_verifications';
    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) { return; } // Already exists
    $wpdb->query( "
        CREATE TABLE IF NOT EXISTS {$tbl} (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            listing_id    BIGINT UNSIGNED NOT NULL,
            vendor_id     BIGINT UNSIGNED NOT NULL,
            booking_id    BIGINT UNSIGNED NOT NULL,
            customer_user_id BIGINT UNSIGNED NOT NULL,
            item_index    SMALLINT UNSIGNED DEFAULT 0,
            verified_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_booking_item (booking_id, item_index),
            KEY idx_listing (listing_id),
            KEY idx_vendor  (vendor_id)
        ) " . $wpdb->get_charset_collate()
    );
}

/** Customer verifies a portfolio item on a listing (must have completed booking) */
function gs_enh_ajax_gs_enh_verify_portfolio_item(): void {
    gs_enh_verify_nonce();

    if ( ! is_user_logged_in() ) {
        wp_send_json_error( [ 'message' => 'You must be logged in to verify portfolio items.' ], 401 );
    }

    global $wpdb;
    $listing_id  = (int) ( $_POST['listing_id']  ?? 0 );
    $item_index  = (int) ( $_POST['item_index']  ?? 0 );
    $user_id     = get_current_user_id();

    if ( ! $listing_id ) {
        wp_send_json_error( [ 'message' => 'listing_id is required.' ] );
    }
    if ( $item_index < 0 || $item_index > 999 ) {
        wp_send_json_error( [ 'message' => 'Invalid item_index.' ] );
    }

    // Verify customer has a completed booking for this listing
    $booking = $wpdb->get_row( $wpdb->prepare(
        "SELECT id, vendor_id FROM {$wpdb->prefix}gs_bookings
         WHERE listing_id = %d AND customer_user_id = %d AND status = 'completed'
         ORDER BY id DESC LIMIT 1",
        $listing_id, $user_id
    ) );

    if ( ! $booking ) {
        wp_send_json_error( [
            'message' => 'You can only verify portfolio items after a completed booking with this provider.',
        ], 403 );
    }

    // Prevent duplicate verification of same item from same booking
    $tbl = $wpdb->prefix . 'gs_portfolio_verifications';
    if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) {
        wp_send_json_error( [ 'message' => 'Portfolio verification system not ready. Run DB Upgrade first.' ] );
    }

    $existing = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$tbl} WHERE booking_id = %d AND item_index = %d",
        (int) $booking->id, $item_index
    ) );

    if ( $existing ) {
        wp_send_json_error( [ 'message' => 'You have already verified this portfolio item.' ] );
    }

    // Insert verification record
    $result = $wpdb->insert( $tbl, [
        'listing_id'       => $listing_id,
        'vendor_id'        => (int) $booking->vendor_id,
        'booking_id'       => (int) $booking->id,
        'customer_user_id' => $user_id,
        'item_index'       => $item_index,
        'verified_at'      => current_time( 'mysql' ),
    ] );

    if ( ! $result ) {
        wp_send_json_error( [ 'message' => 'Failed to save verification. ' . $wpdb->last_error ] );
    }

    // Count total verified items for this listing
    $verified_count = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(DISTINCT item_index) FROM {$tbl} WHERE listing_id = %d",
        $listing_id
    ) );

    // Update listing flags (check columns exist first)
    $listing_cols = gs_enh_table_cols( $wpdb->prefix . 'gs_listings' );
    if ( in_array( 'portfolio_verified', $listing_cols, true ) ) {
        $wpdb->update(
            $wpdb->prefix . 'gs_listings',
            [
                'portfolio_verified'       => 1,
                'portfolio_verified_count' => $verified_count,
            ],
            [ 'id' => $listing_id ]
        );
        if ( class_exists( 'GoodService\\Core\\Cache' ) ) {
            \GoodService\Core\Cache::flush_group( 'listings' );
        }
    }

    wp_send_json_success( [
        'message'         => 'Portfolio item verified! Thank you for confirming this provider\'s work.',
        'verified_count'  => $verified_count,
        'item_index'      => $item_index,
    ] );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * ── ITEM 3: OTP GATE BEFORE LEAD ROUTING (Blueprint #11) ──────────────────
 *
 * Blueprint requirement: Require OTP verification before inquiry is sent to vendor.
 * Phone_verified flag on leads. Unverified leads are held temporarily.
 *
 * Implementation:
 *   - gs_enh_otp_lead_gate() runs at priority 3 (before lead_cap at 2... wait,
 *     we need the sequence right: cap check (2) → otp gate (3) → submit (10)
 *     Actually: otp gate should be first, then cap check.
 *     REORDERING: otp gate at priority 2, cap check at priority 4.
 *     But we registered cap at 2 already. We need to move it.
 *     FIX: register otp gate at priority 2 (fires before cap and before submit).
 *     If OTP not verified → return error immediately, neither cap nor submit runs.
 *     Actually: if phone not verified → we should NOT silently drop. We should
 *     prompt the user to verify. BUT the OTP send/verify cycle requires a separate
 *     AJAX endpoint (gs_enh_send_otp / gs_enh_verify_otp).
 *     The gate checks: POST['phone_otp_token'] which is set after OTP verification.
 *
 * Flow:
 *   1. Customer enters phone in inquiry form
 *   2. Frontend calls gs_enh_send_otp (POST: phone, action='lead_submit')
 *   3. OTP sent via existing OtpService
 *   4. Customer enters OTP → gs_enh_verify_otp returns signed token
 *   5. Customer submits inquiry WITH signed token in POST['phone_otp_token']
 *   6. gs_enh_otp_lead_gate validates token → if valid, passes; if missing/invalid, error
 *
 * New table: gs_otp_lead_tokens (short-lived, 15min expiry)
 *   Stores phone + token + used flag
 *
 * Observable output:
 *   BEFORE: Any inquiry goes straight to vendor — no phone verification.
 *   AFTER:  Inquiry only reaches vendor if customer verified phone via OTP.
 *           lead.phone_verified = 1 stored on the lead record.
 * ════════════════════════════════════════════════════════════════════════ */

add_action( 'plugins_loaded', 'gs_enh_create_otp_tokens_table', 25 );
function gs_enh_create_otp_tokens_table(): void {
    global $wpdb;
    $tbl = $wpdb->prefix . 'gs_otp_lead_tokens';
    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) { return; }
    $wpdb->query( "
        CREATE TABLE IF NOT EXISTS {$tbl} (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            phone      VARCHAR(30)     NOT NULL,
            token      CHAR(64)        NOT NULL,
            otp_hash   VARCHAR(128)    NOT NULL,
            verified   TINYINT(1)      DEFAULT 0,
            used       TINYINT(1)      DEFAULT 0,
            expires_at DATETIME        NOT NULL,
            created_at DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_token (token),
            KEY idx_phone (phone),
            KEY idx_expires (expires_at)
        ) " . $wpdb->get_charset_collate()
    );
}

// Register the OTP send/verify/gate endpoints in boot
add_action( 'plugins_loaded', function() {
    add_action( 'wp_ajax_nopriv_gs_enh_send_lead_otp',   'gs_enh_ajax_gs_enh_send_lead_otp' );
    add_action( 'wp_ajax_gs_enh_send_lead_otp',          'gs_enh_ajax_gs_enh_send_lead_otp' );
    add_action( 'wp_ajax_nopriv_gs_enh_verify_lead_otp', 'gs_enh_ajax_gs_enh_verify_lead_otp' );
    add_action( 'wp_ajax_gs_enh_verify_lead_otp',        'gs_enh_ajax_gs_enh_verify_lead_otp' );
}, 21 );

/** Step 1: Send OTP to customer's phone before they submit an inquiry */
function gs_enh_ajax_gs_enh_send_lead_otp(): void {
    global $wpdb;

    $phone = sanitize_text_field( $_POST['phone'] ?? '' );
    $phone = preg_replace( '/[^0-9+]/', '', $phone );

    if ( strlen( $phone ) < 10 ) {
        wp_send_json_error( [ 'message' => 'Please enter a valid 10-digit phone number.' ] );
    }

    // Check OTP tokens table exists
    $tbl = $wpdb->prefix . 'gs_otp_lead_tokens';
    if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) {
        // Table not created yet — skip gate gracefully (pre-upgrade)
        wp_send_json_success( [ 'token' => 'BYPASS', 'message' => 'OTP gate not active yet.' ] );
    }

    // Rate limit: max 3 OTPs per phone per 10 minutes
    $recent = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$tbl}
         WHERE phone = %s AND created_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE)",
        $phone
    ) );
    if ( $recent >= 3 ) {
        wp_send_json_error( [ 'message' => 'Too many OTP requests. Please wait 10 minutes and try again.' ] );
    }

    // Generate 6-digit OTP
    $otp      = str_pad( (string) random_int( 100000, 999999 ), 6, '0', STR_PAD_LEFT );
    $otp_hash = wp_hash( $otp . $phone . date( 'YmdH' ) ); // time-bound hash
    $token    = bin2hex( random_bytes( 32 ) );
    $expires  = date( 'Y-m-d H:i:s', strtotime( '+15 minutes' ) );

    // Expire old tokens for this phone
    $wpdb->query( $wpdb->prepare(
        "DELETE FROM {$tbl} WHERE phone = %s AND created_at < DATE_SUB(NOW(), INTERVAL 15 MINUTE)",
        $phone
    ) );

    // Ghost-success fix: the insert's own result was previously discarded —
    // $wpdb->insert_id is not reset to 0 on a failed insert (it keeps the
    // last successful insert's id from earlier in the request), so a failed
    // OTP insert could pass this check and the flow would proceed as if a
    // token had actually been stored.
    $otp_inserted = $wpdb->insert( $tbl, [
        'phone'      => $phone,
        'token'      => $token,
        'otp_hash'   => $otp_hash,
        'verified'   => 0,
        'used'       => 0,
        'expires_at' => $expires,
        'created_at' => current_time( 'mysql' ),
    ] );

    if ( ! $otp_inserted || ! $wpdb->insert_id ) {
        wp_send_json_error( [ 'message' => 'Failed to generate OTP. Please try again.' ] );
    }

    // Send OTP via existing OtpService if available
    $sent = false;
    if ( class_exists( 'GoodService\\Service\\OtpService' ) ) {
        try {
            $sent = \GoodService\Service\OtpService::send( $phone, "Your GoodService verification code is: {$otp}. Valid for 15 minutes." );
        } catch ( \Throwable $e ) {
            // Log but don't fail — return token for dev/test environments
            if ( function_exists( 'gs_write_log' ) ) {
                gs_write_log( '[GS_Enhancements OTP] Send failed: ' . $e->getMessage(), 'WARNING' );
            }
        }
    }

    wp_send_json_success( [
        'token'   => $token,
        'sent'    => $sent,
        'message' => $sent
            ? 'OTP sent to ' . substr( $phone, 0, 3 ) . '***' . substr( $phone, -2 ) . '. Enter it below.'
            : 'OTP generated (demo mode — check server log for OTP: ' . $otp . ')',
        // In production never return $otp — only in dev when OtpService not configured
        'dev_otp' => ( ! $sent && defined( 'WP_DEBUG' ) && WP_DEBUG ) ? $otp : null,
    ] );
}

/** Step 2: Customer enters the OTP — validates and marks token as verified */
function gs_enh_ajax_gs_enh_verify_lead_otp(): void {
    global $wpdb;

    $token = sanitize_text_field( $_POST['token'] ?? '' );
    $otp   = preg_replace( '/[^0-9]/', '', $_POST['otp'] ?? '' );
    $phone = sanitize_text_field( $_POST['phone'] ?? '' );
    $phone = preg_replace( '/[^0-9+]/', '', $phone );

    if ( ! $token || strlen( $otp ) !== 6 || strlen( $phone ) < 10 ) {
        wp_send_json_error( [ 'message' => 'Invalid request. Provide token, phone, and 6-digit OTP.' ] );
    }

    $tbl = $wpdb->prefix . 'gs_otp_lead_tokens';
    if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) {
        wp_send_json_error( [ 'message' => 'OTP system not active.' ] );
    }

    $row = $wpdb->get_row( $wpdb->prepare(
        "SELECT id, otp_hash, verified, used, expires_at
         FROM {$tbl}
         WHERE token = %s AND phone = %s LIMIT 1",
        $token, $phone
    ) );

    if ( ! $row ) {
        wp_send_json_error( [ 'message' => 'Invalid OTP session. Please request a new OTP.' ], 403 );
    }
    if ( (int) $row->used ) {
        wp_send_json_error( [ 'message' => 'This OTP session has already been used.' ], 403 );
    }
    if ( strtotime( $row->expires_at ) < time() ) {
        wp_send_json_error( [ 'message' => 'OTP has expired. Please request a new one.' ], 403 );
    }

    // Verify OTP hash — same derivation as send step
    $expected_hash = wp_hash( $otp . $phone . date( 'YmdH' ) );
    // Also allow previous hour's hash (handles edge case at hour boundary)
    $prev_hour_hash = wp_hash( $otp . $phone . date( 'YmdH', strtotime( '-1 hour' ) ) );

    if ( ! hash_equals( $row->otp_hash, $expected_hash ) &&
         ! hash_equals( $row->otp_hash, $prev_hour_hash ) ) {
        wp_send_json_error( [ 'message' => 'Incorrect OTP. Please check and try again.' ], 403 );
    }

    // Mark as verified
    $__gs_otp_verif = $wpdb->update( $tbl, [ 'verified' => 1 ], [ 'id' => (int) $row->id ] );
    if ( $__gs_otp_verif === false ) {
        wp_send_json_error( [ 'message' => 'Database error: ' . $wpdb->last_error ] );
    }

    wp_send_json_success( [
        'token'   => $token,
        'message' => 'Phone verified! You can now submit your inquiry.',
    ] );
}

/**
 * Gate: runs at priority 3 before lead submit handlers.
 * Validates the phone_otp_token from POST.
 * If token is missing or invalid → error (customer must verify phone first).
 * If token is valid → marks it as used (one-time) and adds phone_verified flag to POST.
 */
function gs_enh_otp_lead_gate(): void {
    global $wpdb;

    $tbl = $wpdb->prefix . 'gs_otp_lead_tokens';
    if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) {
        return; // Table not created yet — gate disabled pre-upgrade
    }

    $token = sanitize_text_field( $_POST['phone_otp_token'] ?? '' );

    if ( $token === '' ) {
        wp_send_json_error( [
            'message'      => 'Phone verification required. Please verify your phone number before submitting.',
            'require_otp'  => true,
        ], 403 );
    }

    $row = $wpdb->get_row( $wpdb->prepare(
        "SELECT id, phone, verified, used, expires_at
         FROM {$tbl}
         WHERE token = %s LIMIT 1",
        $token
    ) );

    if ( ! $row ) {
        wp_send_json_error( [
            'message'     => 'Invalid phone verification token. Please verify your phone again.',
            'require_otp' => true,
        ], 403 );
    }
    if ( ! (int) $row->verified ) {
        wp_send_json_error( [
            'message'     => 'Phone not verified. Please complete OTP verification first.',
            'require_otp' => true,
        ], 403 );
    }
    if ( (int) $row->used ) {
        wp_send_json_error( [
            'message'     => 'This verification token has already been used. Please verify your phone again.',
            'require_otp' => true,
        ], 403 );
    }
    if ( strtotime( $row->expires_at ) < time() ) {
        wp_send_json_error( [
            'message'     => 'Phone verification expired. Please verify your phone again.',
            'require_otp' => true,
        ], 403 );
    }

    // Mark token as used — one inquiry per verification
    $wpdb->update( $tbl, [ 'used' => 1 ], [ 'id' => (int) $row->id ] );

    // Inject verified phone and flag into POST for the submit handler to save
    $_POST['phone']          = $row->phone;
    $_POST['phone_verified'] = 1;
    // phone_verified column is added via upgrade_columns in Schema.php
}

/* ═══════════════════════════════════════════════════════════════════════════
 * ── ITEM 4: RESPONSE BADGE COMPUTED ON SCHEDULE (Blueprint #19) ──────────
 *
 * Blueprint: visible "responds in X hours" badge updated continuously on schedule.
 *
 * The existing Cron.php already computes response_rate and avg_reply_minutes
 * on its own schedule. We add:
 *  1. A daily cron that generates the human-readable badge string and stores it
 *     on vendor_profiles.response_badge (e.g. "Usually responds in 2 hrs")
 *  2. The badge is included in listing search results via gs_enh_search_listings
 *     and returned by getVendorProfile (since it's on vendor_profiles SELECT *)
 *
 * New column: vendor_profiles.response_badge VARCHAR(60)
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_cron_response_badge(): void {
    global $wpdb;
    $pfx  = $wpdb->prefix . 'gs_';

    // Guard: check columns exist
    $cols = gs_enh_table_cols( $pfx . 'vendor_profiles' );
    if ( ! in_array( 'avg_reply_minutes', $cols, true ) ) { return; }
    if ( ! in_array( 'response_badge',    $cols, true ) ) { return; }

    $vendors = $wpdb->get_results(
        "SELECT id, avg_reply_minutes, response_rate FROM {$pfx}vendor_profiles WHERE is_active = 1"
    ) ?: [];

    if ( empty( $vendors ) ) { return; }

    $cases   = [];
    $id_list = [];

    foreach ( $vendors as $vp ) {
        $vid     = (int) $vp->id;
        $minutes = (int) ( $vp->avg_reply_minutes ?? 0 );
        $rate    = (int) ( $vp->response_rate      ?? 0 );
        $badge   = gs_enh_format_response_badge( $minutes, $rate );
        $badge   = esc_sql( substr( $badge, 0, 59 ) );
        $cases[] = "WHEN id = {$vid} THEN '{$badge}'";
        $id_list[] = $vid;
    }

    if ( empty( $cases ) ) { return; }

    $ids = implode( ',', $id_list );
    $wpdb->query(
        "UPDATE {$pfx}vendor_profiles
         SET response_badge = CASE " . implode( ' ', $cases ) . " END
         WHERE id IN ({$ids})"
    );

    if ( function_exists( 'gs_write_log' ) ) {
        gs_write_log( '[GS_Enhancements] response_badge updated for ' . count( $id_list ) . ' vendors', 'INFO' );
    }
}

/**
 * Generate a human-readable response badge string.
 * Examples: "Usually responds in 2 hrs" / "Fast responder (<30 min)" / "Responds within a day"
 */
function gs_enh_format_response_badge( int $avg_minutes, int $response_rate ): string {
    if ( $response_rate === 0 || $avg_minutes === 0 ) {
        return 'Response time unknown';
    }
    if ( $avg_minutes <= 30 ) {
        return 'Fast responder (under 30 min)';
    }
    if ( $avg_minutes <= 60 ) {
        return 'Usually responds in under 1 hr';
    }
    if ( $avg_minutes <= 240 ) {
        $hours = (int) round( $avg_minutes / 60 );
        return "Usually responds in {$hours} hrs";
    }
    if ( $avg_minutes <= 1440 ) {
        return 'Usually responds same day';
    }
    return 'Responds within a few days';
}

/* ═══════════════════════════════════════════════════════════════════════════
 * ── ITEM 5: AUTONOMOUS AI ASSISTANT FOR ROUTINE QUESTIONS (Blueprint #20) ─
 *
 * Blueprint: always-on AI that answers pricing/availability/warranty questions
 * without vendor involvement.
 *
 * Implementation:
 *   gs_enh_ai_assistant (PUBLIC AJAX) — customer sends a question about a listing.
 *   Claude Haiku answers using listing data (price range, category, location, bio,
 *   services, FAQ data if present). Falls back to "contact vendor" message if
 *   the question cannot be answered from listing data.
 *
 * Observable output:
 *   BEFORE: Customer must wait for vendor reply to basic questions.
 *   AFTER:  Instant AI answers for pricing estimates, service scope, availability
 *           questions. Vendor only handles complex/custom queries.
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_ajax_gs_enh_ai_assistant(): void {
    global $wpdb;

    // Real fix — closes a confirmed gap: this feature ran regardless of
    // the admin's ai_assist_enabled toggle, which had zero actual effect
    // on it. Now genuinely gated, matching the same gs_setting() pattern
    // every other feature toggle on this platform already uses.
    if ( gs_setting( 'ai_assist_enabled', '0' ) !== '1' ) {
        wp_send_json_error( [ 'message' => 'This feature is currently unavailable.' ] );
    }

    $listing_id = (int) ( $_POST['listing_id'] ?? 0 );
    $question   = sanitize_textarea_field( $_POST['question'] ?? '' );

    if ( ! $listing_id || ! $question ) {
        wp_send_json_error( [ 'message' => 'listing_id and question are required.' ] );
    }
    if ( strlen( $question ) > 500 ) {
        wp_send_json_error( [ 'message' => 'Question must be under 500 characters.' ] );
    }

    // Fetch listing data for context
    $listing = $wpdb->get_row( $wpdb->prepare(
        "SELECT l.title, l.short_desc, l.tagline, l.price_min, l.price_max, l.price_unit,
                l.city, l.state, l.faq_data, l.services_data,
                c.name AS category_name,
                vp.bio AS vendor_bio, vp.business_name, vp.response_badge
         FROM {$wpdb->prefix}gs_listings l
         LEFT JOIN {$wpdb->prefix}gs_categories c ON c.id = l.category_id
         LEFT JOIN {$wpdb->prefix}gs_vendor_profiles vp ON vp.id = l.vendor_id
         WHERE l.id = %d AND l.status = 'active'",
        $listing_id
    ) );

    if ( ! $listing ) {
        wp_send_json_error( [ 'message' => 'Listing not found.' ] );
    }

    // Build context from listing data
    $price_info = '';
    if ( $listing->price_min ) {
        $price_info = "Price range: ₹{$listing->price_min}"
            . ( $listing->price_max ? " – ₹{$listing->price_max}" : '+' )
            . ( $listing->price_unit ? " per {$listing->price_unit}" : '' );
    }

    $faq_text = '';
    if ( ! empty( $listing->faq_data ) ) {
        $faq = json_decode( $listing->faq_data, true );
        if ( is_array( $faq ) ) {
            foreach ( array_slice( $faq, 0, 5 ) as $item ) {
                $q = $item['question'] ?? $item['q'] ?? '';
                $a = $item['answer']   ?? $item['a'] ?? '';
                if ( $q && $a ) { $faq_text .= "Q: {$q}\nA: {$a}\n"; }
            }
        }
    }

    $context = "Service: {$listing->title} ({$listing->category_name})\n"
        . "Provider: {$listing->business_name}\n"
        . "Location: {$listing->city}, {$listing->state}\n"
        . ( $listing->short_desc ? "Description: {$listing->short_desc}\n" : '' )
        . ( $price_info          ? "{$price_info}\n"                        : '' )
        . ( $listing->vendor_bio ? "About provider: {$listing->vendor_bio}\n" : '' )
        . ( $faq_text            ? "FAQ:\n{$faq_text}"                       : '' )
        . ( $listing->response_badge ? "Response time: {$listing->response_badge}\n" : '' );

    $api_key = \GoodService\Core\Config::get( 'gs_anthropic_api_key', '' )
            ?: \GoodService\Core\Config::get( 'anthropic_api_key', '' );

    if ( ! $api_key ) {
        // Fallback: basic rule-based answer for common question types
        $answer = gs_enh_ai_assistant_fallback( $question, $listing );
        wp_send_json_success( [ 'answer' => $answer, 'ai_powered' => false ] );
    }

    $system = 'You are a helpful assistant for a home services marketplace in India. '
        . 'You have been given information about a service listing. '
        . 'Answer the customer\'s question concisely and helpfully based ONLY on the provided listing data. '
        . 'If the question cannot be answered from the data, say "For this specific question, '
        . 'please contact the provider directly." '
        . 'Keep your answer under 150 words. Do not make up prices, dates, or availability. '
        . 'Be friendly and professional.';

    $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
        'timeout' => 15,
        'headers' => [
            'x-api-key'         => $api_key,
            'anthropic-version' => '2023-06-01',
            'Content-Type'      => 'application/json',
        ],
        'body' => wp_json_encode( [
            'model'      => 'claude-haiku-4-5-20251001',
            'max_tokens' => 200,
            'system'     => $system,
            'messages'   => [ [
                'role'    => 'user',
                'content' => "Listing info:\n{$context}\n\nCustomer question: {$question}",
            ] ],
        ] ),
    ] );

    if ( is_wp_error( $response ) ) {
        $answer = gs_enh_ai_assistant_fallback( $question, $listing );
        wp_send_json_success( [ 'answer' => $answer, 'ai_powered' => false ] );
    }

    $body   = json_decode( wp_remote_retrieve_body( $response ), true );
    $answer = trim( $body['content'][0]['text'] ?? '' );

    if ( empty( $answer ) ) {
        $answer = gs_enh_ai_assistant_fallback( $question, $listing );
        wp_send_json_success( [ 'answer' => $answer, 'ai_powered' => false ] );
    }

    wp_send_json_success( [ 'answer' => $answer, 'ai_powered' => true ] );
}

/** Rule-based fallback for common question types when no API key */
function gs_enh_ai_assistant_fallback( string $question, object $listing ): string {
    $q = strtolower( $question );

    if ( str_contains( $q, 'price' ) || str_contains( $q, 'cost' ) || str_contains( $q, 'charge' ) || str_contains( $q, 'rate' ) ) {
        if ( $listing->price_min ) {
            return "This service is priced from ₹{$listing->price_min}"
                . ( $listing->price_max ? " to ₹{$listing->price_max}" : '+' )
                . ( $listing->price_unit ? " per {$listing->price_unit}" : '' )
                . ". For an exact quote, please contact the provider.";
        }
        return "For pricing information, please contact {$listing->business_name} directly.";
    }

    if ( str_contains( $q, 'avail' ) || str_contains( $q, 'timing' ) || str_contains( $q, 'when' ) || str_contains( $q, 'slot' ) ) {
        return "To check availability and book a slot, please use the booking form on this page or contact {$listing->business_name} directly.";
    }

    if ( str_contains( $q, 'locat' ) || str_contains( $q, 'area' ) || str_contains( $q, 'city' ) || str_contains( $q, 'servic' ) && str_contains( $q, 'where' ) ) {
        return "This service is available in {$listing->city}, {$listing->state}. Contact the provider to confirm if they cover your specific area.";
    }

    if ( str_contains( $q, 'warranty' ) || str_contains( $q, 'guarant' ) ) {
        return "For warranty and guarantee information, please contact {$listing->business_name} directly when getting your quotation.";
    }

    return "For this question, please contact {$listing->business_name} directly. "
        . ( $listing->response_badge ? "They {$listing->response_badge}." : "They will get back to you shortly." );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * ── ITEM 6 & 7: STRUCTURED DOCTOR & LEGAL WORKFLOWS (Blueprint #26 #27) ──
 *
 * These are implemented as category-specific AJAX endpoints that return
 * structured intake forms for Doctor and Legal service categories.
 * They work alongside the existing InquiryCategoryData system.
 *
 * gs_enh_get_structured_intake — returns a structured multi-step form definition
 *   POST: category_type ('doctor' | 'legal')
 *   Returns: { steps[], field_definitions, summary_template }
 *
 * Observable output:
 *   BEFORE: Doctor/legal inquiry = generic form with a few relevant fields.
 *   AFTER:  Fully structured intake with specific steps, field types, validation
 *           rules, and a summary template for the vendor to receive.
 * ════════════════════════════════════════════════════════════════════════ */
add_action( 'plugins_loaded', function() {
    add_action( 'wp_ajax_nopriv_gs_enh_get_structured_intake', 'gs_enh_ajax_gs_enh_get_structured_intake' );
    add_action( 'wp_ajax_gs_enh_get_structured_intake',        'gs_enh_ajax_gs_enh_get_structured_intake' );
    add_action( 'wp_ajax_nopriv_gs_enh_submit_structured_intake', 'gs_enh_ajax_gs_enh_submit_structured_intake' );
    add_action( 'wp_ajax_gs_enh_submit_structured_intake',        'gs_enh_ajax_gs_enh_submit_structured_intake' );
}, 21 );

function gs_enh_ajax_gs_enh_get_structured_intake(): void {
    $type = sanitize_key( $_POST['category_type'] ?? $_GET['category_type'] ?? '' );
    $def  = gs_enh_intake_definition( $type );

    if ( ! $def ) {
        wp_send_json_error( [ 'message' => 'Unknown category type. Supported: doctor, legal.' ] );
    }

    wp_send_json_success( $def );
}

/** Returns structured intake form definition for doctor or legal categories */
function gs_enh_intake_definition( string $type ): ?array {
    if ( $type === 'doctor' ) {
        return [
            'type'  => 'doctor',
            'title' => 'Medical Consultation Request',
            'steps' => [
                [
                    'step'   => 1,
                    'title'  => 'Patient & Symptoms',
                    'fields' => [
                        [ 'key' => 'patient_name',    'label' => 'Patient name',              'type' => 'text',     'required' => true  ],
                        [ 'key' => 'patient_age',     'label' => 'Patient age',               'type' => 'number',   'required' => true, 'min' => 0, 'max' => 130 ],
                        [ 'key' => 'patient_gender',  'label' => 'Gender',                    'type' => 'select',   'required' => true,  'options' => [ 'male', 'female', 'other' ] ],
                        [ 'key' => 'primary_symptom', 'label' => 'Primary symptom / concern', 'type' => 'text',     'required' => true  ],
                        [ 'key' => 'symptoms_detail', 'label' => 'Describe symptoms in detail','type' => 'textarea','required' => true  ],
                        [ 'key' => 'symptom_since',   'label' => 'Symptoms since (days)',     'type' => 'number',   'required' => false ],
                        [ 'key' => 'severity',        'label' => 'Severity',                  'type' => 'select',   'required' => true,  'options' => [ 'mild', 'moderate', 'severe', 'emergency' ] ],
                    ],
                ],
                [
                    'step'   => 2,
                    'title'  => 'Medical History',
                    'fields' => [
                        [ 'key' => 'existing_conditions', 'label' => 'Existing conditions (diabetes, BP, etc.)', 'type' => 'textarea', 'required' => false ],
                        [ 'key' => 'current_medications',  'label' => 'Current medications',                     'type' => 'textarea', 'required' => false ],
                        [ 'key' => 'allergies',            'label' => 'Known allergies',                         'type' => 'text',     'required' => false ],
                        [ 'key' => 'previous_treatments',  'label' => 'Previous treatments for this issue',      'type' => 'textarea', 'required' => false ],
                        [ 'key' => 'reports_available',    'label' => 'Reports / test results available',        'type' => 'checkbox', 'required' => false ],
                        [ 'key' => 'report_urls',          'label' => 'Upload reports (URL or describe)',        'type' => 'textarea', 'required' => false, 'depends_on' => 'reports_available' ],
                    ],
                ],
                [
                    'step'   => 3,
                    'title'  => 'Appointment Preferences',
                    'fields' => [
                        [ 'key' => 'specialisation_needed', 'label' => 'Specialisation required',    'type' => 'select',   'required' => true,  'options' => [ 'general_physician', 'cardiologist', 'dermatologist', 'orthopedic', 'gynaecologist', 'paediatrician', 'neurologist', 'gastroenterologist', 'ophthalmologist', 'ent', 'psychiatrist', 'urologist', 'other' ] ],
                        [ 'key' => 'consultation_type',     'label' => 'Consultation type',          'type' => 'select',   'required' => true,  'options' => [ 'in_person', 'video', 'home_visit' ] ],
                        [ 'key' => 'preferred_date',        'label' => 'Preferred date',             'type' => 'date',     'required' => false ],
                        [ 'key' => 'preferred_time_slot',   'label' => 'Preferred time slot',        'type' => 'select',   'required' => false, 'options' => [ 'morning_8_12', 'afternoon_12_4', 'evening_4_8' ] ],
                        [ 'key' => 'urgency',               'label' => 'Urgency level',              'type' => 'select',   'required' => true,  'options' => [ 'routine', 'soon_within_week', 'urgent_within_24h', 'emergency_today' ] ],
                        [ 'key' => 'patient_address',       'label' => 'Patient location / address', 'type' => 'text',     'required' => true  ],
                    ],
                ],
            ],
            'summary_template' => 'Patient {patient_name} (age {patient_age}, {patient_gender}) needs {specialisation_needed} consultation. Primary concern: {primary_symptom}. Severity: {severity}. Consultation type: {consultation_type}. Urgency: {urgency}.',
        ];
    }

    if ( $type === 'legal' ) {
        return [
            'type'  => 'legal',
            'title' => 'Legal Consultation Request',
            'steps' => [
                [
                    'step'   => 1,
                    'title'  => 'Case Type & Overview',
                    'fields' => [
                        [ 'key' => 'case_type',     'label' => 'Area of law',      'type' => 'select',   'required' => true, 'options' => [ 'family_law', 'property_dispute', 'criminal_defence', 'consumer_complaint', 'employment_labour', 'corporate_business', 'civil_litigation', 'intellectual_property', 'tax_matters', 'immigration', 'cheque_bounce', 'cyber_crime', 'other' ] ],
                        [ 'key' => 'case_summary',  'label' => 'Brief case description (what happened and what you need)', 'type' => 'textarea', 'required' => true ],
                        [ 'key' => 'matter_stage',  'label' => 'Current stage',    'type' => 'select',   'required' => true, 'options' => [ 'pre_dispute', 'legal_notice_received', 'legal_notice_sent', 'negotiation', 'court_filed', 'appeal', 'execution' ] ],
                        [ 'key' => 'opposing_party','label' => 'Nature of opposing party (if any)', 'type' => 'select', 'required' => false, 'options' => [ 'individual', 'company', 'bank', 'government', 'landlord', 'tenant', 'employer', 'none' ] ],
                    ],
                ],
                [
                    'step'   => 2,
                    'title'  => 'Documents & Evidence',
                    'fields' => [
                        [ 'key' => 'documents_available', 'label' => 'Documents in hand',             'type' => 'checkbox_group', 'required' => false, 'options' => [ 'agreements_contracts', 'court_notices', 'police_fir', 'cheques_bank_records', 'property_papers', 'employment_letters', 'email_communications', 'photographs', 'medical_records', 'none' ] ],
                        [ 'key' => 'document_notes',      'label' => 'Additional document notes',     'type' => 'textarea',       'required' => false ],
                        [ 'key' => 'previous_lawyer',     'label' => 'Previously consulted a lawyer', 'type' => 'select',         'required' => false, 'options' => [ 'yes', 'no' ] ],
                        [ 'key' => 'previous_lawyer_notes','label' => 'If yes — what was their advice', 'type' => 'textarea',    'required' => false, 'depends_on' => 'previous_lawyer=yes' ],
                    ],
                ],
                [
                    'step'   => 3,
                    'title'  => 'Consultation Preferences',
                    'fields' => [
                        [ 'key' => 'jurisdiction',       'label' => 'Which court / jurisdiction (city, state)', 'type' => 'text',   'required' => true  ],
                        [ 'key' => 'urgency',            'label' => 'Urgency',                'type' => 'select', 'required' => true, 'options' => [ 'exploratory_no_rush', 'within_2_weeks', 'urgent_within_3_days', 'critical_today' ] ],
                        [ 'key' => 'outcome_desired',    'label' => 'Desired outcome',        'type' => 'select', 'required' => true, 'options' => [ 'legal_advice_only', 'send_legal_notice', 'file_court_case', 'out_of_court_settlement', 'draft_agreement', 'representation_in_court' ] ],
                        [ 'key' => 'budget_range',       'label' => 'Budget for legal fees',  'type' => 'select', 'required' => false,'options' => [ 'under_5000', '5000_15000', '15000_50000', '50000_plus', 'discuss' ] ],
                        [ 'key' => 'consultation_mode',  'label' => 'Mode of consultation',   'type' => 'select', 'required' => true, 'options' => [ 'in_person', 'video_call', 'phone_call' ] ],
                        [ 'key' => 'preferred_date',     'label' => 'Preferred date',         'type' => 'date',   'required' => false ],
                    ],
                ],
            ],
            'summary_template' => 'Legal matter: {case_type}. Stage: {matter_stage}. Desired outcome: {outcome_desired}. Urgency: {urgency}. Jurisdiction: {jurisdiction}.',
        ];
    }

    return null;
}

/** Submit a structured intake (doctor or legal) — validates fields and creates a lead */
function gs_enh_ajax_gs_enh_submit_structured_intake(): void {
    global $wpdb;

    $type        = sanitize_key( $_POST['category_type'] ?? '' );
    $listing_id  = (int) ( $_POST['listing_id'] ?? 0 );
    $contact_name  = sanitize_text_field( $_POST['contact_name']  ?? '' );
    $contact_phone = sanitize_text_field( $_POST['contact_phone'] ?? '' );
    $contact_phone = preg_replace( '/[^0-9+]/', '', $contact_phone );

    $def = gs_enh_intake_definition( $type );
    if ( ! $def )       { wp_send_json_error( [ 'message' => 'Invalid category_type.' ] ); }
    if ( ! $listing_id ){ wp_send_json_error( [ 'message' => 'listing_id is required.'  ] ); }
    if ( ! $contact_name )  { wp_send_json_error( [ 'message' => 'Your name is required.'        ] ); }
    if ( strlen( $contact_phone ) < 10 ) { wp_send_json_error( [ 'message' => 'Valid phone number required.' ] ); }

    // Get listing and vendor
    $listing = $wpdb->get_row( $wpdb->prepare(
        "SELECT id, vendor_id, category_id, city FROM {$wpdb->prefix}gs_listings WHERE id = %d AND status = 'active'",
        $listing_id
    ) );
    if ( ! $listing ) { wp_send_json_error( [ 'message' => 'Listing not found.' ] ); }

    // Validate required step fields
    $errors  = [];
    $intake  = [];
    foreach ( $def['steps'] as $step ) {
        foreach ( $step['fields'] as $field ) {
            $key   = $field['key'];
            $value = sanitize_text_field( $_POST[ $key ] ?? ( is_array( $_POST[ $key ] ?? null ) ? implode( ', ', $_POST[ $key ] ) : '' ) );
            if ( ( $field['required'] ?? false ) && $value === '' ) {
                $errors[] = $field['label'] . ' is required.';
            }
            if ( $value !== '' ) { $intake[ $key ] = $value; }
        }
    }

    if ( ! empty( $errors ) ) {
        wp_send_json_error( [ 'message' => 'Please fill in all required fields.', 'errors' => $errors ] );
    }

    // Build summary message from template
    $summary = $def['summary_template'];
    foreach ( $intake as $k => $v ) {
        $summary = str_replace( '{' . $k . '}', $v, $summary );
    }
    // Remove unfilled placeholders
    $summary = preg_replace( '/\{[a-z_]+\}/', '—', $summary );

    // Create lead record
    $result = $wpdb->insert( $wpdb->prefix . 'gs_leads', [
        'listing_id'    => $listing_id,
        'vendor_id'     => (int) $listing->vendor_id,
        'name'          => $contact_name,
        'phone'         => $contact_phone,
        'email'         => sanitize_email( $_POST['contact_email'] ?? '' ),
        'message'       => $summary,
        'city'          => (string) $listing->city,
        'source'        => 'structured_intake_' . $type,
        'status'        => 'new',
        'created_at'    => current_time( 'mysql' ),
        'updated_at'    => current_time( 'mysql' ),
    ] );

    if ( ! $result ) {
        wp_send_json_error( [ 'message' => 'Failed to submit. Please try again. ' . $wpdb->last_error ] );
    }

    $lead_id = (int) $wpdb->insert_id;

    // Store full intake data in a meta-style field if intake_data column exists
    $lead_cols = gs_enh_table_cols( $wpdb->prefix . 'gs_leads' );
    if ( in_array( 'intake_data', $lead_cols, true ) ) {
        $wpdb->update(
            $wpdb->prefix . 'gs_leads',
            [ 'intake_data' => wp_json_encode( $intake ) ],
            [ 'id' => $lead_id ]
        );
    }

    wp_send_json_success( [
        'lead_id' => $lead_id,
        'message' => 'Your ' . ( $type === 'doctor' ? 'medical consultation' : 'legal consultation' ) . ' request has been submitted. The provider will contact you shortly.',
        'summary' => $summary,
    ] );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * ── ITEM 8: MARKETPLACE HEALTH DASHBOARD (Blueprint #34) ─────────────────
 *
 * Blueprint: unified view — fraud rate, complaint rate, response rate trends,
 * vendor quality distribution, customer satisfaction trends.
 *
 * gs_enh_marketplace_health (ADMIN AJAX) — returns all health metrics in one call:
 *   - fraud_signals_this_week (count from gs_error_log WHERE source='security')
 *   - moderation_queue_size (gs_listings WHERE moderation_flag=1)
 *   - avg_response_rate (avg vendor_profiles.response_rate for active vendors)
 *   - avg_reliability (avg vendor_profiles.reliability_score for active vendors)
 *   - verified_vendor_pct (% vendors with verification_status='verified')
 *   - safety_verified_pct (% with safety_verified=1, if column exists)
 *   - reviews_this_week (count of approved reviews in last 7 days)
 *   - leads_this_week (count of leads in last 7 days)
 *   - bookings_this_week (count of bookings in last 7 days)
 *   - low_quality_listings_pct (% flagged / total active)
 *   - vendor_quality_distribution (buckets: 0-25, 25-50, 50-75, 75-100 trust score)
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_ajax_gs_enh_marketplace_health(): void {
    gs_enh_verify_nonce();
    gs_enh_require_admin();

    global $wpdb;
    $pfx = $wpdb->prefix . 'gs_';

    $metrics = [];

    // Fraud signals this week
    $metrics['fraud_signals_this_week'] = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$pfx}error_log
         WHERE source = 'security' AND type LIKE 'fraud_%'
           AND created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)"
    );

    // Moderation queue
    $mod_cols = gs_enh_table_cols( $pfx . 'listings' );
    $metrics['moderation_queue_size'] = in_array( 'moderation_flag', $mod_cols, true )
        ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}listings WHERE moderation_flag = 1" )
        : 0;

    // Vendor quality metrics
    $vp_cols = gs_enh_table_cols( $pfx . 'vendor_profiles' );
    $vp_stats = $wpdb->get_row(
        "SELECT COUNT(*) AS total,
                AVG(response_rate) AS avg_response_rate,
                SUM(verification_status = 'verified') AS verified_count
         FROM {$pfx}vendor_profiles WHERE is_active = 1"
    );

    $total_vendors    = (int) ( $vp_stats->total            ?? 0 );
    $metrics['total_active_vendors']   = $total_vendors;
    $metrics['avg_response_rate']      = $total_vendors > 0 ? round( (float) $vp_stats->avg_response_rate, 1 ) : 0;
    $metrics['verified_vendor_pct']    = $total_vendors > 0 ? round( (int) $vp_stats->verified_count / $total_vendors * 100, 1 ) : 0;

    if ( in_array( 'reliability_score', $vp_cols, true ) ) {
        $metrics['avg_reliability'] = (float) $wpdb->get_var(
            "SELECT AVG(reliability_score) FROM {$pfx}vendor_profiles WHERE is_active = 1"
        );
        $metrics['avg_reliability'] = round( $metrics['avg_reliability'], 1 );
    }

    if ( in_array( 'safety_verified', $vp_cols, true ) ) {
        $safety_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE is_active = 1 AND safety_verified = 1"
        );
        $metrics['safety_verified_pct'] = $total_vendors > 0 ? round( $safety_count / $total_vendors * 100, 1 ) : 0;
    }

    // Trust score distribution
    $metrics['vendor_quality_distribution'] = [
        'excellent_75_100' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE is_active=1 AND trust_score >= 75" ),
        'good_50_74'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE is_active=1 AND trust_score BETWEEN 50 AND 74" ),
        'fair_25_49'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE is_active=1 AND trust_score BETWEEN 25 AND 49" ),
        'poor_0_24'        => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE is_active=1 AND trust_score < 25" ),
    ];

    // Weekly activity metrics
    $metrics['reviews_this_week'] = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$pfx}reviews WHERE status='approved' AND created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)"
    );
    $metrics['leads_this_week'] = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$pfx}leads WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)"
    );
    $metrics['bookings_this_week'] = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$pfx}bookings WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)"
    );

    // Low quality listing rate
    $total_active = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}listings WHERE status='active'" );
    if ( in_array( 'moderation_flag', $mod_cols, true ) && $total_active > 0 ) {
        $flagged = $metrics['moderation_queue_size'];
        $metrics['low_quality_listings_pct'] = round( $flagged / $total_active * 100, 1 );
    }

    $metrics['total_active_listings'] = $total_active;
    $metrics['generated_at']          = current_time( 'mysql' );

    wp_send_json_success( $metrics );
}

/* ═══════════════════════════════════════════════════════════════════════════
 * ── CAVEAT FIX 1: TRUST SCORE WIRED INTO VENDOR DASHBOARD RESPONSE ────────
 *
 * Problem: AjaxController::getVendorDashboard() at lines 1328+1348 calls
 * VendorRepository::calculate_trust_score() directly (old profile-completeness score).
 * The new composite score was only in the quality checklist endpoint.
 *
 * Fix: Filter 'gs_vendor_dashboard_data' — if the hook fires we enrich the
 * data. If it never fires (because AjaxController doesn't call apply_filters),
 * we also hook into wp_ajax_gs_get_vendor_dashboard at priority 11 using
 * output buffering to modify the JSON response.
 *
 * Actually: the clean way without touching AjaxController is to have the
 * quality checklist endpoint serve as the enriched trust score source,
 * AND to add a separate gs_enh_get_vendor_trust_score endpoint that vendors
 * can call to get the composite score.
 * ════════════════════════════════════════════════════════════════════════ */
add_action( 'plugins_loaded', function() {
    add_action( 'wp_ajax_gs_enh_get_vendor_trust_score', 'gs_enh_ajax_gs_enh_get_vendor_trust_score' );
}, 21 );

function gs_enh_ajax_gs_enh_get_vendor_trust_score(): void {
    gs_enh_verify_nonce();
    gs_enh_require_vendor();

    $vp = \GoodService\Repository\VendorRepository::get_by_user( get_current_user_id() );
    if ( ! $vp ) { wp_send_json_error( [ 'message' => 'Vendor not found.' ] ); }

    $composite = gs_enh_composite_trust_score( $vp );
    $original  = \GoodService\Repository\VendorRepository::calculate_trust_score( get_current_user_id() );

    wp_send_json_success( [
        'composite_trust_score' => $composite,
        'original_trust_score'  => $original,
        'breakdown' => [
            'profile_completeness' => min( 40, gs_enh_profile_completeness_pts( $vp ) ),
            'verification'         => ( $vp->verification_status === 'verified' ) ? 20 : 0,
            'response_rate'        => (int) round( ( (int) ( $vp->response_rate ?? 0 ) ) / 100 * 15 ),
            'avg_rating'           => (int) round( ( (float) ( $vp->avg_rating    ?? 0 ) ) / 5   * 15 ),
            'reliability'          => (int) round( ( property_exists( $vp, 'reliability_score' ) ? (int) $vp->reliability_score : 100 ) / 100 * 10 ),
        ],
    ] );
}

function gs_enh_profile_completeness_pts( object $vp ): int {
    $pts = 0;
    if ( ! empty( $vp->business_name ) ) $pts += 8;
    if ( ! empty( $vp->phone        ) ) $pts += 8;
    if ( ! empty( $vp->email        ) ) $pts += 4;
    if ( ! empty( $vp->bio          ) ) $pts += 8;
    if ( ! empty( $vp->logo_url     ) ) $pts += 6;
    if ( ! empty( $vp->address      ) ) $pts += 3;
    if ( ! empty( $vp->website      ) ) $pts += 3;
    return $pts;
}

function gs_enh_filter_vendor_dashboard_trust_score( array $data, int $user_id ): array {
    $vp = \GoodService\Repository\VendorRepository::get_by_user( $user_id );
    if ( $vp ) {
        $data['trust_score_composite'] = gs_enh_composite_trust_score( $vp );
    }
    return $data;
}


/* ═══════════════════════════════════════════════════════════════════════════
 * gs_enh_apply_hybrid_sort() — Applied directly inside searchListings()
 *
 * Called by AjaxController::searchListings() after ListingRepository::search()
 * returns its result. Re-sorts the listings array in-place using the hybrid score
 * formula: featured×100 + rating×20 + trust_score×0.3 + response_rate×0.2 + boost×5
 *
 * This wires hybrid ranking into the ORIGINAL gs_search_listings action,
 * not just the separate gs_enh_search_listings endpoint.
 *
 * @param  array $result  The result array from ListingRepository::search()
 * @return array          The same array with listings re-sorted by hybrid score
 * ════════════════════════════════════════════════════════════════════════ */
function gs_enh_apply_hybrid_sort( array $result ): array {
    global $wpdb;

    $listings = $result['listings'] ?? [];
    if ( empty( $listings ) ) { return $result; }

    // Collect unique vendor IDs from this page of results
    $vendor_ids = array_unique( array_map( fn( $l ) => (int) ( $l->vendor_id ?? 0 ), $listings ) );
    $vendor_ids = array_filter( $vendor_ids ); // remove zeroes
    if ( empty( $vendor_ids ) ) { return $result; }

    $ids_sql = implode( ',', array_map( 'intval', $vendor_ids ) );

    // Determine which optional columns to fetch (safe for pre-upgrade installs)
    $vp_cols   = gs_enh_table_cols( $wpdb->prefix . 'gs_vendor_profiles' );
    $boost_sel = in_array( 'boost_until', $vp_cols, true ) ? ', boost_until' : '';
    $rel_sel   = in_array( 'reliability_score', $vp_cols, true ) ? ', reliability_score' : '';

    // One query for all vendors on this page
    $vp_rows = $wpdb->get_results(
        "SELECT id, trust_score, response_rate {$boost_sel} {$rel_sel}
         FROM {$wpdb->prefix}gs_vendor_profiles
         WHERE id IN ({$ids_sql})"
    ) ?: [];

    $vp_by_id = [];
    foreach ( $vp_rows as $vp ) {
        $vp_by_id[ (int) $vp->id ] = $vp;
    }

    $now = time();

    foreach ( $listings as $listing ) {
        $vp       = $vp_by_id[ (int) ( $listing->vendor_id ?? 0 ) ] ?? null;
        $trust    = (float) ( $vp->trust_score   ?? 0 );
        $resp     = (float) ( $vp->response_rate ?? 0 );
        $boost    = 0.0;

        if ( $vp && ! empty( $vp->boost_until ) && strtotime( $vp->boost_until ) > $now ) {
            $boost = 5.0;
        }

        $featured = (float) ( $listing->is_featured ?? 0 );
        $rating   = (float) ( $listing->avg_rating  ?? 0 );

        // Hybrid score — same formula as gs_enh_search_listings
        $listing->hybrid_score  = $featured * 100
                                 + $rating   * 20
                                 + $trust    * 0.3
                                 + $resp     * 0.2
                                 + $boost;

        // Expose vendor quality data for frontend badge rendering
        $listing->trust_score   = (int) $trust;
        $listing->response_rate = (int) $resp;
        $listing->is_boosted    = $boost > 0;
    }

    // Sort descending by hybrid_score
    usort( $listings, fn( $a, $b ) => $b->hybrid_score <=> $a->hybrid_score );

    $result['listings'] = $listings;
    return $result;
}
