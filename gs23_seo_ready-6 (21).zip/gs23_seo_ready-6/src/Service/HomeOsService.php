<?php
namespace GoodService\Service;

/**
 * HomeOsService — Home Service OS: Permanent Service Record (Moat 5)
 * Tracks every service done at a client's home with warranty info, 
 * sends automated service reminders, and builds a digital home maintenance history.
 */
final class HomeOsService {

    /** Get or create the primary home profile for a user. */
    public static function get_or_create_profile( int $user_id, string $address = '' ): \stdClass {
        global $wpdb;
        $existing = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_home_profiles WHERE user_id=%d AND is_primary=1",
            $user_id
        ) );
        if ( $existing ) { return $existing; }

        $wpdb->insert( $wpdb->prefix . 'gs_home_profiles', [
            'user_id'       => $user_id,
            'property_name' => 'My Home',
            'address'       => sanitize_text_field( $address ),
            'is_primary'    => 1,
            'created_at'    => current_time( 'mysql' ),
        ] );
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_home_profiles WHERE id=%d",
            (int) $wpdb->insert_id
        ) );
    }

    /** Add a service record after a booking is completed. */
    public static function add_service_record( int $property_id, int $booking_id, array $data ): int {
        global $wpdb;

        $category   = sanitize_key( $data['category'] ?? '' );
        $next_date  = self::get_next_service_date( $category );
        $warranty_m = self::get_default_warranty( $category );
        $warranty_expiry = $warranty_m > 0
            ? date( 'Y-m-d', strtotime( "+{$warranty_m} months" ) ) : null;

        $__gs_ok = $wpdb->insert( $wpdb->prefix . 'gs_service_records', [
            'property_id'    => $property_id,
            'booking_id'     => $booking_id,
            'service_title'  => sanitize_text_field( $data['service_title'] ?? '' ),
            'category_slug'  => $category,
            'vendor_name'    => sanitize_text_field( $data['vendor_name'] ?? '' ),
            'vendor_phone'   => sanitize_text_field( $data['vendor_phone'] ?? '' ),
            'amount_paid'    => (float) ( $data['amount_paid'] ?? 0 ),
            'service_date'   => sanitize_text_field( $data['service_date'] ?? date( 'Y-m-d' ) ),
            'warranty_months'=> $warranty_m,
            'warranty_expiry'=> $warranty_expiry,
            'notes'          => sanitize_textarea_field( $data['notes'] ?? '' ),
            'next_service_due'=> $next_date,
            'created_at'     => current_time( 'mysql' ),
        ] );

        if ( ! $__gs_ok ) { return 0; }
        $record_id = (int) $wpdb->insert_id;

        // Schedule reminder
        if ( $next_date ) {
            $remind_date = date( 'Y-m-d', strtotime( $next_date . ' -7 days' ) );
            $wpdb->insert( $wpdb->prefix . 'gs_service_reminders', [
                'record_id'    => $record_id,
                'property_id'  => $property_id,
                'user_id'      => (int) ( $data['user_id'] ?? 0 ),
                'category'     => $category,
                'service_title'=> sanitize_text_field( $data['service_title'] ?? '' ),
                'remind_date'  => $remind_date,
                'created_at'   => current_time( 'mysql' ),
            ] );
        }

        return $record_id;
    }

    /** Get service history for a property. */
    public static function get_service_history( int $property_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_service_records WHERE property_id=%d ORDER BY service_date DESC",
            $property_id
        ) ) ?: [];
    }

    /** Get warranties expiring in next 60 days. */
    public static function get_expiring_warranties( int $property_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_service_records
             WHERE property_id=%d AND warranty_expiry IS NOT NULL
               AND warranty_expiry > CURDATE() AND warranty_expiry <= DATE_ADD(CURDATE(), INTERVAL 60 DAY)
             ORDER BY warranty_expiry",
            $property_id
        ) ) ?: [];
    }

    public static function get_next_service_date( string $category ): ?string {
        $intervals = [
            'ac-repair' => 365, 'ac-service' => 365, 'pest-control' => 90,
            'water-purifier' => 180, 'geyser' => 365, 'chimney' => 180,
            'cctv' => 365, 'generator' => 180,
        ];
        return isset( $intervals[$category] )
            ? date( 'Y-m-d', strtotime( '+' . $intervals[$category] . ' days' ) )
            : null;
    }

    public static function get_default_warranty( string $category ): int {
        $warranties = [
            'plumber' => 1, 'electrician' => 3, 'ac-repair' => 3,
            'carpenter' => 6, 'waterproofing' => 12, 'painting' => 12,
        ];
        return $warranties[$category] ?? 0;
    }

    /**
     * FIXED — audit gap: a customer who mis-entered a manual service
     * record (wrong date, wrong amount, duplicate) had no way to correct
     * or remove it — "Add Service Record" on /my-home/ had no
     * counterpart delete action anywhere in the codebase. Scoped to
     * property_id (verified by the caller against the current user's own
     * profile — never trusted from client input) so one user can never
     * delete another user's history. Also removes the record's own
     * scheduled reminder row so a deleted record doesn't still trigger a
     * "time to service this again" email for a service that, as far as
     * this tracker is concerned, no longer happened.
     */
    public static function delete_record( int $record_id, int $property_id ): bool {
        global $wpdb;
        $record = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_service_records WHERE id=%d AND property_id=%d",
            $record_id, $property_id
        ) );
        if ( ! $record ) { return false; }
        $wpdb->delete( $wpdb->prefix . 'gs_service_reminders', [ 'record_id' => $record_id ] );
        $deleted = $wpdb->delete( $wpdb->prefix . 'gs_service_records', [ 'id' => $record_id ] );
        return $deleted !== false;
    }

    /** Daily cron: send due service reminders. */
    public static function send_due_reminders(): void {
        global $wpdb;
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_service_reminders'" ) ) { return; }

        $due = $wpdb->get_results(
            "SELECT sr.*, u.user_email, u.display_name
             FROM {$wpdb->prefix}gs_service_reminders sr
             JOIN {$wpdb->users} u ON u.ID = sr.user_id
             WHERE sr.remind_date = CURDATE() AND sr.reminded = 0"
        ) ?: [];

        foreach ( $due as $r ) {
            EmailService::send( $r->user_email, 'service_reminder', [
                'client_name'   => $r->display_name,
                'service_title' => $r->service_title,
                'due_date'      => date( 'd M Y', strtotime( $r->remind_date . ' +7 days' ) ),
                'book_url'      => home_url( '/services/' . $r->category . '/' ),
            ] );
            $wpdb->update( $wpdb->prefix . 'gs_service_reminders', [ 'reminded' => 1 ], [ 'id' => $r->id ] );
        }
    }
}
