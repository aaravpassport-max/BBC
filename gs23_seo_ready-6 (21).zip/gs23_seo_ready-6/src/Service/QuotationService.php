<?php
namespace GoodService\Service;

use GoodService\Core\Config;
use GoodService\Core\JobQueue;

/**
 * QuotationService — Vendor quotation creation, sending, and client acceptance.
 *
 * Quotations are stored in gs_quotations with line_items as JSON.
 * Clients accept via a tokenised link (/quote/accept/[token]/).
 * PDF generation requires dompdf/dompdf — gracefully falls back to HTML email if unavailable.
 */
final class QuotationService {

    /** Generate a cryptographically secure accept token (64 hex chars = 256 bits). */
    public static function generate_token(): string {
        return bin2hex( random_bytes( 32 ) );
    }

    /** Generate a human-readable quote number: QT-[YEAR]-[zero-padded id]. */
    public static function generate_quote_number( int $id ): string {
        return 'QT-' . date( 'Y' ) . '-' . str_pad( $id, 5, '0', STR_PAD_LEFT );
    }

    /**
     * Create and save a quotation record.
     *
     * @param int   $lead_id    Lead this quote is for.
     * @param int   $vendor_id  Vendor profile ID.
     * @param array $data       Quote data: line_items, gst_rate, validity_days, payment_terms, notes, cover_note.
     * @return int|false        Quote ID on success, false on failure.
     */
    public static function create( int $lead_id, int $vendor_id, array $data ): int {
        global $wpdb;

        $line_items = $data['line_items'] ?? [];
        $subtotal   = 0.0;
        $clean_items = [];

        foreach ( $line_items as $item ) {
            $qty   = max( 0, (float) ( $item['qty']        ?? 1 ) );
            $price = max( 0, (float) ( $item['unit_price'] ?? 0 ) );
            $line  = round( $qty * $price, 2 );
            $subtotal += $line;
            $clean_items[] = [
                'description' => sanitize_text_field( $item['description'] ?? '' ),
                'qty'         => $qty,
                'unit_price'  => $price,
                'total'       => $line,
            ];
        }

        // Clamp gst_rate to valid range [0–100]% — prevent negative tax or >100% tax
        $gst_rate  = min( 100.0, max( 0.0, (float) ( $data['gst_rate'] ?? 0 ) ) );
        $gst_amount = $gst_rate > 0 ? round( $subtotal * ( $gst_rate / 100 ), 2 ) : 0;
        $total      = round( $subtotal + $gst_amount, 2 );

        $validity_days = max( 1, (int) ( $data['validity_days'] ?? 7 ) );
        $valid_until   = date( 'Y-m-d', strtotime( "+{$validity_days} days" ) );
        $token         = self::generate_token();

        $__gs_ok = $wpdb->insert( $wpdb->prefix . 'gs_quotations', [
            'lead_id'           => $lead_id,
            'vendor_id'         => $vendor_id,
            'quote_number'      => '',  // filled after insert
            'status'            => 'draft',
            'line_items'        => wp_json_encode( $clean_items ),
            'subtotal'          => $subtotal,
            'gst_rate'          => $gst_rate,
            'gst_amount'        => $gst_amount,
            'total'             => $total,
            'validity_days'     => $validity_days,
            'valid_until'       => $valid_until,
            'payment_terms'     => sanitize_text_field( $data['payment_terms'] ?? '' ),
            'notes'             => sanitize_textarea_field( $data['notes'] ?? '' ),
            'cover_note'        => sanitize_textarea_field( $data['cover_note'] ?? '' ),
            'quote_accept_token'=> $token,
            'token_used'        => 0,
            'created_at'        => current_time( 'mysql' ),
            'updated_at'        => current_time( 'mysql' ),
        ] );

        if ( ! $__gs_ok ) { return 0; }
        $quote_id = (int) $wpdb->insert_id;
        if ( ! $quote_id ) { return 0; }

        // Update the quote number with the actual ID
        $quote_number = self::generate_quote_number( $quote_id );
        $wpdb->update(
            $wpdb->prefix . 'gs_quotations',
            [ 'quote_number' => $quote_number ],
            [ 'id' => $quote_id ]
        );

        return $quote_id;
    }

    /**
     * Mark a quotation as sent and notify the client.
     */
    public static function send_to_client( int $quote_id, int $lead_id, int $vendor_id ): bool {
        global $wpdb;

        $quote  = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_quotations WHERE id = %d AND vendor_id = %d",
            $quote_id, $vendor_id
        ) );
        if ( ! $quote ) { return 0; }

        $lead = $wpdb->get_row( $wpdb->prepare(
            "SELECT l.*, li.title AS listing_title FROM {$wpdb->prefix}gs_leads l
             LEFT JOIN {$wpdb->prefix}gs_listings li ON li.id = l.listing_id
             WHERE l.id = %d",
            $lead_id
        ) );
        if ( ! $lead ) { return 0; }

        $vp = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $vendor_id
        ) );

        // Update status to sent
        $wpdb->update(
            $wpdb->prefix . 'gs_quotations',
            [ 'status' => 'sent', 'updated_at' => current_time( 'mysql' ) ],
            [ 'id' => $quote_id ]
        );

        // Store as a lead reply for timeline visibility
        $wpdb->insert( $wpdb->prefix . 'gs_lead_replies', [
            'lead_id'      => $lead_id,
            'sender_type'  => 'vendor',
            'sender_id'    => $vp ? (int) $vp->user_id : 0,
            'sender_name'  => $vp->business_name ?? 'Vendor',
            'message'      => "Quotation #{$quote->quote_number} sent — Total: ₹" . number_format( $quote->total, 2 ),
            'is_internal'  => 0,
            'sent_via'     => 'quotation',
            'sent_at'      => current_time( 'mysql' ),
            'created_at'   => current_time( 'mysql' ),
        ] );

        // Update lead status to replied
        $wpdb->update(
            $wpdb->prefix . 'gs_leads',
            [ 'status' => 'replied', 'replied_at' => current_time( 'mysql' ), 'replied_by' => get_current_user_id(), 'updated_at' => current_time( 'mysql' ) ],
            [ 'id' => $lead_id ]
        );

        // Send email to client if they have an email
        if ( ! empty( $lead->email ) ) {
            $accept_url = home_url( '/quote/accept/' . $quote->quote_accept_token . '/' );
            $items_html = self::build_items_html( json_decode( $quote->line_items ?? '[]', true ) ?: [] );

            EmailService::send( $lead->email, 'quote_sent', [
                'client_name'  => $lead->name,
                'vendor_name'  => $vp->business_name ?? 'Vendor',
                'service'      => $lead->listing_title ?? $lead->inquiry_module ?? 'your inquiry',
                'quote_number' => $quote->quote_number,
                'total_amount' => '₹' . number_format( $quote->total, 2 ),
                'valid_until'  => date( 'd M Y', strtotime( $quote->valid_until ) ),
                'cover_note'   => $quote->cover_note ?: '',
                'accept_url'   => $accept_url,
                'inquiry_url'  => home_url( '/customer/dashboard/' ),
                'items_html'   => $items_html,
            ] );
        }

        // In-app notification to client (if logged in)
        if ( ! empty( $lead->customer_user_id ) ) {
            \GoodService\Service\NotificationService::create(
                (int) $lead->customer_user_id,
                'quote.received',
                '📄 You received a quote',
                ( $vp->business_name ?? 'A vendor' ) . " sent you a quote for ₹" . number_format( $quote->total, 2 ),
                home_url( '/quote/accept/' . $quote->quote_accept_token . '/' ),
                'file-text', '#2563EB'
            );
        }

        // Part 27.1 — Fire client push + email notification for quote received
        \GoodService\Service\NotificationService::on_quote_sent( [
            'customer_user_id' => (int)( $lead->customer_user_id ?? 0 ),
            'customer_email'   => $lead->email ?? '',
            'vendor_name'      => $quote->business_name ?? '',
            'vendor_user_id'   => (int)( $quote->vendor_user_id ?? 0 ),
            'vendor_email'     => get_userdata( (int)$quote->vendor_user_id )->user_email ?? '',
            'total'            => $quote->total,
            'cover_note'       => $quote->cover_note ?? '',
            'valid_until'      => $quote->valid_until ?? '',
            'accept_url'       => home_url( '/quote/accept/' . $quote->quote_accept_token . '/' ),
        ] );

        return true;
    }

    /**
     * Process a client accepting a quote via the token link.
     * Returns ['success' => bool, 'message' => string, 'booking_id' => int|null]
     */
    public static function accept_by_token( string $token ): array {
        global $wpdb;

        if ( strlen( $token ) !== 64 ) {
            return [ 'success' => false, 'message' => 'Invalid quote link.' ];
        }

        $quote = $wpdb->get_row( $wpdb->prepare(
            "SELECT q.*, l.name AS client_name, l.email AS client_email, l.phone AS client_phone,
                    l.listing_id, l.inquiry_module,
                    vp.user_id AS vendor_user_id, vp.business_name
             FROM {$wpdb->prefix}gs_quotations q
             JOIN {$wpdb->prefix}gs_leads l ON l.id = q.lead_id
             JOIN {$wpdb->prefix}gs_vendor_profiles vp ON vp.id = q.vendor_id
             WHERE q.quote_accept_token = %s",
            $token
        ) );

        if ( ! $quote ) {
            return [ 'success' => false, 'message' => 'Quote not found or link has expired.' ];
        }
        if ( $quote->token_used ) {
            return [ 'success' => false, 'message' => 'This quote link has already been used.' ];
        }
        if ( $quote->status === 'expired' ) {
            return [ 'success' => false, 'message' => 'This quote has expired.' ];
        }
        if ( $quote->valid_until && strtotime( $quote->valid_until ) < time() ) {
            $wpdb->update( $wpdb->prefix . 'gs_quotations', [ 'status' => 'expired' ], [ 'id' => $quote->id ] );
            return [ 'success' => false, 'message' => 'This quote has expired.' ];
        }

        // Mark token as used, update quote status
        $wpdb->update( $wpdb->prefix . 'gs_quotations', [
            'status'      => 'accepted',
            'accepted_at' => current_time( 'mysql' ),
            'token_used'  => 1,
            'updated_at'  => current_time( 'mysql' ),
        ], [ 'id' => $quote->id ] );

        // Mark lead as converted
        $wpdb->update( $wpdb->prefix . 'gs_leads', [
            'status'       => 'converted',
            'converted_at' => current_time( 'mysql' ),
            'updated_at'   => current_time( 'mysql' ),
        ], [ 'id' => $quote->lead_id ] );

        // Notify vendor
        // Fire full notification event (push + email + in-app)
        $vendor_email = '';
        $vendor_ud = get_userdata( (int)$quote->vendor_user_id );
        if ( $vendor_ud ) { $vendor_email = $vendor_ud->user_email; }
        \GoodService\Service\NotificationService::on_quote_accepted( [
            'vendor_user_id' => (int) $quote->vendor_user_id,
            'vendor_name'    => $quote->business_name,
            'vendor_email'   => $vendor_email,
            'client_name'    => $quote->client_name,
            'total'          => $quote->total,
            'quote_number'   => $quote->quote_number,
        ] );

        // Legacy: also keep direct email queue for compatibility
        JobQueue::push( 'send_email', [
            'to'       => $vendor_email,
            'template' => 'quote_accepted',
            'vars'     => [
                'vendor_name'  => $quote->business_name,
                'client_name'  => $quote->client_name,
                'quote_number' => $quote->quote_number,
                'total_amount' => '₹' . number_format( $quote->total, 2 ),
                'dashboard_url'=> home_url( '/vendor/dashboard/?section=leads' ),
            ],
        ] );

        return [
            'success'    => true,
            'message'    => 'Quote accepted successfully. The vendor will contact you to confirm the booking.',
            'quote_id'   => (int) $quote->id,
            'quote_number' => $quote->quote_number,
        ];
    }

    /** Build an HTML items table for email. */
    private static function build_items_html( array $items ): string {
        if ( empty( $items ) ) { return ''; }
        $rows = '';
        foreach ( $items as $item ) {
            $rows .= '<tr>
                <td style="padding:7px 10px;border-bottom:1px solid #F1F5F9">' . esc_html( $item['description'] ?? '' ) . '</td>
                <td style="padding:7px 10px;border-bottom:1px solid #F1F5F9;text-align:center">' . (int) ( $item['qty'] ?? 1 ) . '</td>
                <td style="padding:7px 10px;border-bottom:1px solid #F1F5F9;text-align:right">₹' . number_format( $item['unit_price'] ?? 0, 2 ) . '</td>
                <td style="padding:7px 10px;border-bottom:1px solid #F1F5F9;text-align:right">₹' . number_format( $item['total'] ?? 0, 2 ) . '</td>
            </tr>';
        }
        return '<table style="width:100%;border-collapse:collapse;margin:14px 0;font-size:13px">
            <thead><tr style="background:#F8FAFC">
                <th style="padding:8px 10px;text-align:left">Description</th>
                <th style="padding:8px 10px;text-align:center">Qty</th>
                <th style="padding:8px 10px;text-align:right">Unit Price</th>
                <th style="padding:8px 10px;text-align:right">Total</th>
            </tr></thead>
            <tbody>' . $rows . '</tbody>
        </table>';
    }
}
