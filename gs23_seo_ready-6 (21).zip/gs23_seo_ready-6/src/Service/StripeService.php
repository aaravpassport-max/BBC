<?php
namespace GoodService\Service;

use GoodService\Core\Config;
use GoodService\Core\EventBus;

/**
 * StripeService
 *
 * Real fix — this closes a confirmed gap: stripe_public_key/stripe_secret_key
 * existed as admin settings fields with zero backend implementation behind
 * them, the exact same "collected but never consumed" pattern found and
 * fixed for SMTP earlier. Mirrors RazorpayService's structure and
 * conventions closely — same no-external-SDK philosophy (wp_remote_post
 * directly against Stripe's REST API), same "amount is derived server-side
 * from what was actually recorded at order-creation time, never trusted
 * from client input" security posture, same activate_subscription()
 * shape so both gateways plug into the exact same subscription/invoice
 * pipeline (BillingService::generate_invoice(), NotificationService,
 * EventBus) rather than each gateway inventing its own.
 *
 * Stripe's flow is fundamentally different from Razorpay's, though:
 * Razorpay Checkout is a JS modal that stays on this site; Stripe
 * Checkout is a hosted, Stripe-owned payment page the browser is
 * redirected to, then redirected back afterward. That's Stripe's own
 * standard integration model, not a shortcut taken here.
 *
 *   1. Server creates a Checkout Session via create_checkout_session()
 *   2. Frontend redirects the browser to the returned session URL
 *   3. Customer pays on Stripe's own hosted page
 *   4. Stripe redirects back to success_url with ?session_id=...
 *   5. Stripe also calls the webhook (checkout.session.completed) —
 *      the webhook is the authoritative confirmation, exactly like
 *      Razorpay's; the success_url redirect is only ever a UX nicety,
 *      never trusted on its own to activate anything.
 */
final class StripeService {

    private const API_BASE = 'https://api.stripe.com/v1';

    // ── Key helpers ────────────────────────────────────────────────────────────

    public static function public_key(): string {
        return (string) Config::get( 'stripe_public_key', '' );
    }

    private static function secret_key(): string {
        return (string) Config::get( 'stripe_secret_key', '' );
    }

    public static function is_configured(): bool {
        if ( ! (bool) Config::get( 'stripe_enabled', true ) ) { return false; }
        return self::public_key() !== '' && self::secret_key() !== '';
    }

    /**
     * Stripe requires application/x-www-form-urlencoded, including for
     * nested objects (line_items[0][price_data][...]) — its REST API
     * predates widespread JSON body conventions and has never changed
     * this. http_build_query() with brackets handles the nesting
     * correctly as long as arrays are passed as PHP arrays, not
     * pre-flattened strings.
     */
    private static function request( string $method, string $path, array $params = [] ): array|false {
        if ( ! self::is_configured() ) {
            gs_write_log( 'StripeService: keys not configured', 'ERROR' );
            return false;
        }

        $args = [
            'method'  => $method,
            'timeout' => 20,
            'headers' => [
                'Authorization' => 'Bearer ' . self::secret_key(),
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ],
        ];
        if ( $method !== 'GET' && $params ) {
            $args['body'] = http_build_query( $params );
        }

        $url = self::API_BASE . $path;
        if ( $method === 'GET' && $params ) {
            $url .= '?' . http_build_query( $params );
        }

        $response = wp_remote_request( $url, $args );

        if ( is_wp_error( $response ) ) {
            gs_write_log( 'StripeService request error: ' . $response->get_error_message(), 'ERROR' );
            return false;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code < 200 || $code >= 300 ) {
            gs_write_log( 'StripeService bad response ' . $code . ': ' . wp_json_encode( $body ), 'ERROR' );
            return false;
        }

        return is_array( $body ) ? $body : false;
    }

    /**
     * Real, live test of whether the configured secret key actually
     * works — hits Stripe's read-only /balance endpoint (no session
     * created, no charge possible) purely to confirm the API accepts
     * the key. Same purpose as RazorpayService::test_connection().
     *
     * @return array{ok:bool, message:string}
     */
    public static function test_connection(): array {
        if ( ! self::secret_key() ) {
            return [ 'ok' => false, 'message' => 'Secret Key must be set first.' ];
        }
        $response = wp_remote_get( self::API_BASE . '/balance', [
            'timeout' => 15,
            'headers' => [ 'Authorization' => 'Bearer ' . self::secret_key() ],
        ] );
        if ( is_wp_error( $response ) ) {
            return [ 'ok' => false, 'message' => 'Network error: ' . $response->get_error_message() ];
        }
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code === 200 ) {
            return [ 'ok' => true, 'message' => 'Connected successfully — Secret Key is valid.' ];
        }
        if ( $code === 401 ) {
            return [ 'ok' => false, 'message' => 'Authentication failed — Secret Key is incorrect.' ];
        }
        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        return [ 'ok' => false, 'message' => 'Stripe returned an error (HTTP ' . $code . '): ' . ( $body['error']['message'] ?? 'Unknown error' ) ];
    }

    // ── Checkout Session creation ───────────────────────────────────────────────

    /**
     * Create a Stripe Checkout Session for a one-time subscription
     * payment. Amount is passed in the smallest currency unit (paise for
     * INR, cents for USD — same convention Stripe itself uses).
     *
     * @param int    $amount_minor  Amount in the smallest currency unit
     * @param string $currency      3-letter lowercase ISO code (Stripe requires lowercase)
     * @param string $description   Shown on Stripe's hosted checkout page
     * @param string $success_url   Where Stripe redirects after successful payment
     * @param string $cancel_url    Where Stripe redirects if the customer backs out
     * @param array  $metadata      Key-value pairs stored on the session (vendor_id, plan_id, etc.) —
     *                              retrievable from the webhook payload, exactly like Razorpay's 'notes'.
     * @return array|false  ['id' => session_id, 'url' => checkout_url], or false on failure
     */
    public static function create_checkout_session(
        int    $amount_minor,
        string $currency,
        string $description,
        string $success_url,
        string $cancel_url,
        array  $metadata = []
    ): array|false {
        $params = [
            'mode'                 => 'payment',
            'success_url'          => $success_url,
            'cancel_url'           => $cancel_url,
            'line_items'           => [
                [
                    'quantity'   => 1,
                    'price_data' => [
                        'currency'     => strtolower( $currency ),
                        'unit_amount'  => $amount_minor,
                        'product_data' => [ 'name' => $description ],
                    ],
                ],
            ],
            'metadata' => $metadata,
        ];

        $session = self::request( 'POST', '/checkout/sessions', $params );
        if ( ! $session || empty( $session['id'] ) || empty( $session['url'] ) ) { return false; }

        return $session;
    }

    /**
     * Retrieve a Checkout Session's current state directly from Stripe —
     * used to confirm payment_status is genuinely 'paid' when the
     * customer returns from Stripe's hosted page, rather than trusting
     * the redirect itself as proof of payment.
     */
    public static function get_checkout_session( string $session_id ): array|false {
        return self::request( 'GET', '/checkout/sessions/' . rawurlencode( $session_id ) );
    }

    // ── Webhook signature verification ─────────────────────────────────────────

    /**
     * Verify a Stripe webhook signature. Stripe's own signing scheme
     * (documented at stripe.com/docs/webhooks/signatures): the header is
     * "t=<timestamp>,v1=<signature>[,v0=<legacy>]" and the signed payload
     * is "<timestamp>.<raw body>", HMAC-SHA256 with the webhook signing
     * secret. A tolerance window rejects genuinely old/replayed requests
     * even if the signature itself is somehow valid.
     */
    public static function verify_webhook_signature( string $raw_body, string $sig_header, string $secret ): bool {
        if ( ! $secret || ! $sig_header ) { return false; }

        $parts = [];
        foreach ( explode( ',', $sig_header ) as $part ) {
            $kv = explode( '=', $part, 2 );
            if ( count( $kv ) === 2 ) { $parts[ $kv[0] ] = $kv[1]; }
        }
        if ( empty( $parts['t'] ) || empty( $parts['v1'] ) ) { return false; }

        // Reject requests signed more than 5 minutes ago — Stripe's own
        // recommended tolerance, guards against a captured-and-replayed
        // webhook request being accepted long after the fact.
        if ( abs( time() - (int) $parts['t'] ) > 300 ) {
            gs_write_log( 'StripeService: webhook timestamp outside tolerance window — possible replay.', 'ERROR' );
            return false;
        }

        $expected = hash_hmac( 'sha256', $parts['t'] . '.' . $raw_body, $secret );
        return hash_equals( $expected, $parts['v1'] );
    }

    // ── Subscription activation ────────────────────────────────────────────────

    /**
     * Activate (or upgrade) a vendor subscription after a Stripe payment
     * is confirmed. Mirrors RazorpayService::activate_subscription()
     * exactly — same idempotency guarantee, same invoice generation, same
     * notification — so a vendor's experience and the platform's records
     * are identical regardless of which gateway they paid through.
     */
    public static function activate_subscription(
        int    $vendor_id,
        int    $plan_id,
        string $payment_id,
        string $cycle = 'monthly'
    ): int|false {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';

        // Same idempotency guarantee as Razorpay's — Stripe's webhook and
        // any client-side confirmation can both legitimately fire for the
        // same session; the check lives in one place per gateway, keyed
        // on payment_id, so whichever call arrives second is a safe no-op
        // rather than a duplicate subscription/invoice.
        if ( $payment_id !== '' ) {
            $existing_sub_id = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$pfx}subscriptions WHERE payment_id = %s ORDER BY id DESC LIMIT 1", $payment_id
            ) );
            if ( $existing_sub_id ) {
                gs_write_log( "StripeService::activate_subscription: payment {$payment_id} already activated as subscription #{$existing_sub_id} — skipping duplicate activation." );
                return $existing_sub_id;
            }
        }

        $plan = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$pfx}subscription_plans WHERE id = %d AND is_active = 1", $plan_id
        ) );
        if ( ! $plan ) { return false; }

        $amount   = $cycle === 'yearly' ? (float) $plan->price_yearly : (float) $plan->price_monthly;
        $expires  = $cycle === 'yearly'
            ? date( 'Y-m-d H:i:s', strtotime( '+1 year' ) )
            : date( 'Y-m-d H:i:s', strtotime( '+1 month' ) );

        // Root-cause fix — confirmed gap from full subscription-lifecycle audit:
        // this only ever cancelled an existing status='active' row before
        // inserting the new one. A vendor still on a 'trialing' subscription
        // who completed a real Stripe purchase was left with BOTH the
        // trialing row and the new active row simultaneously matching
        // status IN ('active','trialing') — the exact duplicate-subscription-
        // state bug already found and fixed in this method's Razorpay sibling
        // (RazorpayService::activate_subscription()) but never carried over
        // here. Now cancels both, same pattern.
        $wpdb->update(
            "{$pfx}subscriptions",
            [ 'status' => 'cancelled', 'updated_at' => current_time( 'mysql' ) ],
            [ 'vendor_id' => $vendor_id, 'status' => 'active' ]
        );
        $wpdb->update(
            "{$pfx}subscriptions",
            [ 'status' => 'cancelled', 'updated_at' => current_time( 'mysql' ) ],
            [ 'vendor_id' => $vendor_id, 'status' => 'trialing' ]
        );

        // Ghost-success fix — same root cause found and fixed in RazorpayService::
        // $wpdb->insert_id is not reset to 0 on a failed insert, so checking
        // insert_id alone could not detect this insert failing if an earlier
        // query in the same request had left a stale non-zero insert_id — on the
        // real-money "payment confirmed" path, a failed subscription write
        // could silently fall through to generating an invoice and notifying
        // the vendor of an "active" plan that was never actually recorded.
        $inserted = $wpdb->insert( "{$pfx}subscriptions", [
            'vendor_id'     => $vendor_id,
            'plan_id'       => $plan_id,
            'plan_name'     => $plan->name,
            'billing_cycle' => $cycle,
            'amount'        => $amount,
            'status'        => 'active',
            'gateway'       => 'stripe',
            'payment_id'    => $payment_id,
            'starts_at'     => current_time( 'mysql' ),
            'expires_at'    => $expires,
            // ENTERPRISE-AUDIT FIX (Part 2, High: plan versioning/grandfathering).
            'plan_snapshot' => \GoodService\Service\SubscriptionService::build_plan_snapshot( $plan_id ),
            'created_at'    => current_time( 'mysql' ),
            'updated_at'    => current_time( 'mysql' ),
        ] );
        if ( ! $inserted ) {
            gs_write_log( "StripeService: subscription insert FAILED for vendor {$vendor_id} (plan {$plan_id}) — payment {$payment_id} was received but no subscription row was created: " . $wpdb->last_error, 'ERROR' );
            return false;
        }
        $sub_id = (int) $wpdb->insert_id;
        if ( ! $sub_id ) { return false; }

        BillingService::generate_invoice( $sub_id );

        $vp = \GoodService\Repository\VendorRepository::get_by_id( $vendor_id );
        if ( $vp ) {
            NotificationService::create(
                (int) $vp->user_id, 'subscription.activated',
                '🎉 ' . $plan->name . ' Plan Active!',
                'Your ' . $plan->name . ' plan is now active' . ( $expires ? ' until ' . date( 'd M Y', strtotime( $expires ) ) : '' ) . '.',
                home_url( '/vendor/dashboard/?section=subscription' ),
                'check-circle', '#059669'
            );
        }

        EventBus::emit( 'subscription.activated', [
            'vendor_id'  => $vendor_id,
            'plan_id'    => $plan_id,
            'plan_name'  => $plan->name,
            'payment_id' => $payment_id,
            'cycle'      => $cycle,
            'expires_at' => $expires,
        ] );

        gs_write_log( "StripeService: subscription #{$sub_id} activated for vendor {$vendor_id} (plan {$plan_id}, {$cycle})", 'INFO' );
        return $sub_id;
    }

    /**
     * Issues a real refund via Stripe's Refunds API. Confirmed missing
     * during Phase 1 discovery — 'refunded' previously existed only as a
     * status label on gs_invoices, with no code anywhere that actually
     * called the gateway to reverse the charge. Reuses the existing
     * request() helper rather than duplicating its HTTP/auth logic.
     *
     * @param string     $payment_intent_id  The Stripe PaymentIntent ID to refund (invoices.payment_id).
     * @param float|null $amount             Amount in the invoice's currency units for a partial refund; null = full refund.
     * @return array{success:bool, refund_id:?string, error:?string}
     */
    public static function refund( string $payment_intent_id, ?float $amount = null ): array {
        if ( ! $payment_intent_id ) {
            return [ 'success' => false, 'refund_id' => null, 'error' => 'No payment intent ID provided.' ];
        }

        $params = [ 'payment_intent' => $payment_intent_id ];
        if ( $amount !== null ) {
            // Stripe amounts are in the currency's smallest unit (paise
            // for INR) — matches this class's own amount-handling
            // convention used elsewhere for charges.
            $params['amount'] = (int) round( $amount * 100 );
        }

        $result = self::request( 'POST', '/refunds', $params );
        if ( $result === false ) {
            return [ 'success' => false, 'refund_id' => null, 'error' => 'Refund request failed — see error log for details.' ];
        }
        if ( empty( $result['id'] ) ) {
            return [ 'success' => false, 'refund_id' => null, 'error' => 'Unexpected response from Stripe.' ];
        }

        gs_write_log( "StripeService: refund {$result['id']} issued for payment intent {$payment_intent_id}", 'INFO' );
        return [ 'success' => true, 'refund_id' => $result['id'], 'error' => null ];
    }

    // ── Saved payment methods ───────────────────────────────────────────────────
    // ENTERPRISE-AUDIT FIX (Part 3, large, deliberately deferred: "no saved
    // payment methods"). Uses Stripe's standard SetupIntent + PaymentMethod
    // flow: a SetupIntent lets the browser (via Stripe Elements/Stripe.js)
    // collect and confirm a card WITHOUT charging it, producing a reusable
    // PaymentMethod id that's then attached to the vendor's Customer object
    // for later off-session charges. The raw card number never reaches this
    // server at any point.

    /** Returns the vendor's Stripe Customer id, creating one on first use. */
    public static function get_or_create_customer( int $vendor_id ): ?string {
        global $wpdb;
        $vp = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, business_name, email, stripe_customer_id FROM {$wpdb->prefix}gs_vendor_profiles WHERE id=%d", $vendor_id
        ) );
        if ( ! $vp ) { return null; }
        if ( ! empty( $vp->stripe_customer_id ) ) { return $vp->stripe_customer_id; }

        $result = self::request( 'POST', '/customers', [
            'name'  => $vp->business_name ?: '',
            'email' => $vp->email ?: '',
            'metadata[vendor_id]' => (string) $vendor_id,
        ] );
        if ( $result === false || empty( $result['id'] ) ) {
            gs_write_log( "StripeService::get_or_create_customer failed for vendor #{$vendor_id}", 'ERROR' );
            return null;
        }
        $wpdb->update( $wpdb->prefix . 'gs_vendor_profiles', [ 'stripe_customer_id' => $result['id'] ], [ 'id' => $vendor_id ] );
        return $result['id'];
    }

    /**
     * Creates a SetupIntent for the "Add Card" flow. Returns the
     * client_secret the frontend needs to confirm the card via Stripe.js —
     * nothing is charged and no card details pass through this server.
     */
    public static function create_setup_intent( int $vendor_id ): array|false {
        $customer_id = self::get_or_create_customer( $vendor_id );
        if ( ! $customer_id ) { return false; }
        $result = self::request( 'POST', '/setup_intents', [
            'customer'             => $customer_id,
            'payment_method_types[]' => 'card',
            'usage'                => 'off_session',
        ] );
        if ( $result === false || empty( $result['client_secret'] ) ) { return false; }
        return [ 'client_secret' => $result['client_secret'], 'customer_id' => $customer_id ];
    }

    /**
     * After the browser confirms the SetupIntent and gets back a
     * payment_method id, this attaches it to the customer, fetches its
     * card brand/last4 for display, and records it — called by
     * AjaxController::saveStripePaymentMethod() once per successful setup.
     */
    public static function save_payment_method( int $vendor_id, string $payment_method_id ): array {
        global $wpdb;
        $customer_id = self::get_or_create_customer( $vendor_id );
        if ( ! $customer_id ) { return [ 'success' => false, 'error' => 'Could not resolve Stripe customer.' ]; }

        // Attach — idempotent-safe: Stripe returns an error if it's already
        // attached to this same customer, which we treat as success rather
        // than a hard failure (a double-submit shouldn't surface as an error).
        $attach = self::request( 'POST', "/payment_methods/{$payment_method_id}/attach", [ 'customer' => $customer_id ] );
        if ( $attach === false ) {
            $pm_check = self::request( 'GET', "/payment_methods/{$payment_method_id}" );
            if ( $pm_check === false || ( $pm_check['customer'] ?? '' ) !== $customer_id ) {
                return [ 'success' => false, 'error' => 'Could not save this card. Please try again.' ];
            }
            $attach = $pm_check;
        }

        $card = $attach['card'] ?? [];
        $has_default = (bool) $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_saved_payment_methods WHERE vendor_id=%d AND gateway='stripe' AND is_default=1", $vendor_id
        ) );

        $wpdb->query( $wpdb->prepare(
            "INSERT INTO {$wpdb->prefix}gs_saved_payment_methods (vendor_id, gateway, gateway_ref, card_brand, card_last4, is_default, created_at)
             VALUES (%d,'stripe',%s,%s,%s,%d,%s)
             ON DUPLICATE KEY UPDATE card_brand=VALUES(card_brand), card_last4=VALUES(card_last4)",
            $vendor_id, $payment_method_id, (string) ( $card['brand'] ?? '' ), (string) ( $card['last4'] ?? '' ),
            $has_default ? 0 : 1, current_time( 'mysql' )
        ) );

        if ( ! $has_default ) {
            self::request( 'POST', "/customers/{$customer_id}", [ 'invoice_settings[default_payment_method]' => $payment_method_id ] );
        }

        return [ 'success' => true ];
    }

    /** Sets which saved card Stripe treats as this customer's default. */
    public static function set_default_payment_method( int $vendor_id, string $payment_method_id ): bool {
        $customer_id = self::get_or_create_customer( $vendor_id );
        if ( ! $customer_id ) { return false; }
        return self::request( 'POST', "/customers/{$customer_id}", [ 'invoice_settings[default_payment_method]' => $payment_method_id ] ) !== false;
    }

    /** Detaches a saved card from Stripe and removes the local record. */
    public static function delete_saved_method( int $vendor_id, string $payment_method_id ): bool {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_saved_payment_methods WHERE vendor_id=%d AND gateway='stripe' AND gateway_ref=%s",
            $vendor_id, $payment_method_id
        ) );
        if ( ! $row ) { return false; } // ownership check — can't delete a card that isn't this vendor's
        self::request( 'POST', "/payment_methods/{$payment_method_id}/detach" );
        $wpdb->delete( $wpdb->prefix . 'gs_saved_payment_methods', [ 'id' => $row->id ] );
        return true;
    }

    /**
     * Charges a previously-saved card off-session (e.g. a "Renew now with
     * saved card" button — this is never called automatically/silently;
     * every call site requires the vendor's own explicit click).
     */
    public static function charge_saved_method( int $vendor_id, string $payment_method_id, float $amount, string $description = '' ): array {
        $customer_id = self::get_or_create_customer( $vendor_id );
        if ( ! $customer_id ) { return [ 'success' => false, 'error' => 'Could not resolve Stripe customer.' ]; }
        $result = self::request( 'POST', '/payment_intents', [
            'amount'         => (int) round( $amount * 100 ),
            'currency'       => strtolower( (string) Config::get( 'currency', 'inr' ) ),
            'customer'       => $customer_id,
            'payment_method' => $payment_method_id,
            'off_session'    => 'true',
            'confirm'        => 'true',
            'description'    => $description,
        ] );
        if ( $result === false || empty( $result['id'] ) ) {
            return [ 'success' => false, 'error' => 'Charge failed. The card may have been declined.' ];
        }
        if ( ( $result['status'] ?? '' ) !== 'succeeded' ) {
            return [ 'success' => false, 'error' => 'Payment did not complete (status: ' . ( $result['status'] ?? 'unknown' ) . ').' ];
        }
        return [ 'success' => true, 'payment_intent_id' => $result['id'] ];
    }
}
