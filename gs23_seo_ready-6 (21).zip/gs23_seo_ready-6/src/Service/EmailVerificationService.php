<?php
namespace GoodService\Service;

use GoodService\Core\Config;

/**
 * EmailVerificationService — Inquiry/Booking email verification (Section 1 of spec).
 *
 * Replaces the previous "OTP gate before lead routing" (GS_Enhancements.php,
 * gs_enh_otp_lead_gate / Blueprint #11), which was hooked onto gs_submit_lead and
 * gs_submit_inquiry at wp_ajax priority 3 and unconditionally demanded a
 * `phone_otp_token` in every submission — a token that NOTHING on the frontend
 * ever generated (no phone field, no OTP-send UI, no verify UI were ever built
 * for it). The result: every single inquiry submission through those two actions
 * was rejected with "Phone not verified" / "Phone verification required",
 * 100% of the time, for every visitor. That gate has been removed (see
 * GS_Enhancements.php boot() — the add_action calls for it are gone) and is
 * replaced by this service, which is real and has a working frontend.
 *
 * Design — HARD GATE on vendor notification (per explicit requirement: "unless
 * the client does not submit the OTP/verification, the booking or inquiry will
 * be considered incomplete"):
 *   - gs_leads.email is OPTIONAL (AjaxController::submitInquiry() requires phone
 *     OR email, not both — phone-only inquiries are common and valid in this
 *     market). Phone-only submissions have nothing to verify and complete
 *     immediately, exactly as before — they are NOT held back.
 *   - If an email IS given: the lead row is created immediately (so the
 *     customer's data and message are never lost even if they never click the
 *     link — they can still be found and re-contacted), but is held in an
 *     "incomplete" state — email_verified=0, and LeadRepository::get_vendor_leads()
 *     excludes it from the vendor's inbox entirely. Vendor notification,
 *     leads_count, and analytics tracking are ALL deferred — see
 *     AjaxController::activate_inquiry_lead() / on_lead_email_verified().
 *   - The customer immediately gets a "please verify your email to complete
 *     your inquiry" response instead of "submitted successfully".
 *   - Once the link is clicked (handle_verify_click() below), email_verified
 *     flips to 1 and EventBus::emit('lead.email_verified', ...) fires
 *     AjaxController::on_lead_email_verified(), which runs the exact same
 *     activation logic that a phone-only lead gets immediately — vendor
 *     notification, leads_count increment, analytics, customer auto-reply.
 *   - If the customer never clicks the link, the lead simply stays incomplete
 *     forever — visible to admins (unfiltered) for oversight/recovery, never
 *     visible to the vendor, no notification ever sent.
 */
final class EmailVerificationService {

    private const TOKEN_TTL_HOURS = 48;

    public static function ensure_table(): void {
        global $wpdb;
        $tbl = $wpdb->prefix . 'gs_email_verify_tokens';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) ) {
            $wpdb->query( "
                CREATE TABLE IF NOT EXISTS {$tbl} (
                    id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    lead_id    BIGINT UNSIGNED NOT NULL,
                    email      VARCHAR(255)    NOT NULL,
                    token      CHAR(64)        NOT NULL,
                    code_hash  VARCHAR(64)     DEFAULT NULL,
                    attempts   TINYINT UNSIGNED DEFAULT 0,
                    used       TINYINT(1)      DEFAULT 0,
                    expires_at DATETIME        NOT NULL,
                    created_at DATETIME        DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    UNIQUE KEY uq_token (token),
                    KEY idx_lead (lead_id)
                ) " . $wpdb->get_charset_collate()
            );
            return;
        }
        // Upgrade path — table exists from before the OTP feature was added.
        $existing_cols = $wpdb->get_col( "SHOW COLUMNS FROM {$tbl}", 0 );
        if ( ! in_array( 'code_hash', $existing_cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$tbl} ADD COLUMN code_hash VARCHAR(64) DEFAULT NULL AFTER token" );
        }
        if ( ! in_array( 'attempts', $existing_cols, true ) ) {
            $wpdb->query( "ALTER TABLE {$tbl} ADD COLUMN attempts TINYINT UNSIGNED DEFAULT 0 AFTER code_hash" );
        }
    }

    /**
     * Call right after a lead/inquiry/booking with an email address is created.
     * Sends the verification email; never throws, never blocks the caller —
     * a failure here must not prevent the inquiry itself from succeeding.
     */
    public static function send_verification( int $lead_id, string $email, string $customer_name ): void {
        if ( ! is_email( $email ) ) { return; }
        global $wpdb;
        self::ensure_table();

        $token = bin2hex( random_bytes( 32 ) );
        $ok = $wpdb->insert( $wpdb->prefix . 'gs_email_verify_tokens', [
            'lead_id'    => $lead_id,
            'email'      => $email,
            'token'      => $token,
            'expires_at' => date( 'Y-m-d H:i:s', strtotime( '+' . self::TOKEN_TTL_HOURS . ' hours' ) ),
            'created_at' => current_time( 'mysql' ),
        ] );
        if ( ! $ok ) {
            gs_write_log( "EmailVerificationService: could not create token row for lead #{$lead_id}", 'WARNING' );
            return;
        }

        $wpdb->update( $wpdb->prefix . 'gs_leads',
            [ 'email_verify_sent_at' => current_time( 'mysql' ) ],
            [ 'id' => $lead_id ]
        );

        $verify_url = admin_url( 'admin-ajax.php' ) . '?action=gs_verify_inquiry_email&token=' . $token;

        $sent = EmailService::send( $email, 'inquiry_email_verification', [
            'customer_name' => $customer_name ?: 'there',
            'verify_url'    => $verify_url,
        ] );
        if ( ! $sent ) {
            gs_write_log( "EmailVerificationService: send failed for lead #{$lead_id} to {$email}", 'WARNING' );
        }
    }

    /**
     * OTP-based email verification — sends a 6-digit code instead of a click
     * link. The customer types the code into an inline field on the
     * confirmation screen; verify_otp() below checks it. This is the flow
     * actually wired up to submitInquiry()/submitBookingFromModule() — the
     * link-based send_verification()/handle_verify_click() above remain
     * intact for the admin-triggered gs_admin_force_verify_lead path and as
     * a fallback path (the table row created here is compatible with either
     * method being used against it).
     *
     * @param int    $lead_id       gs_leads.id this verification is for
     * @param string $email         Where to send the code
     * @param string $customer_name For the greeting line in the email
     * @return array{sent:bool, error:?string}
     */
    public static function send_otp( int $lead_id, string $email, string $customer_name ): array {
        if ( ! is_email( $email ) ) {
            return [ 'sent' => false, 'error' => 'Invalid email address.' ];
        }
        global $wpdb;
        self::ensure_table();

        // Rate limit: max 3 OTP sends per lead per 10 minutes, mirroring OtpService's
        // phone-OTP limit. Prevents a customer (or an attacker) from mail-bombing
        // an inbox by repeatedly hitting resend.
        $rate_key = 'gs_email_otp_rate_' . $lead_id;
        $attempts_sent = (int) get_transient( $rate_key );
        if ( $attempts_sent >= 3 ) {
            return [ 'sent' => false, 'error' => 'Too many code requests. Please wait a few minutes and try again.' ];
        }

        $code      = str_pad( (string) random_int( 0, 999999 ), 6, '0', STR_PAD_LEFT );
        $code_hash = hash( 'sha256', $code );
        // 'token' column is NOT NULL + UNIQUE on this table; still populated
        // here purely to satisfy that schema constraint. It is never emailed
        // or exposed for the OTP flow -- verification is by lead_id+email+code only.
        $token = bin2hex( random_bytes( 32 ) );

        $ok = $wpdb->insert( $wpdb->prefix . 'gs_email_verify_tokens', [
            'lead_id'    => $lead_id,
            'email'      => $email,
            'token'      => $token,
            'code_hash'  => $code_hash,
            'attempts'   => 0,
            'expires_at' => date( 'Y-m-d H:i:s', strtotime( '+10 minutes' ) ),
            'created_at' => current_time( 'mysql' ),
        ] );
        if ( ! $ok ) {
            gs_write_log( "EmailVerificationService::send_otp: could not create row for lead #{$lead_id}", 'WARNING' );
            return [ 'sent' => false, 'error' => 'Could not generate a verification code. Please try again.' ];
        }

        $wpdb->update( $wpdb->prefix . 'gs_leads',
            [ 'email_verify_sent_at' => current_time( 'mysql' ) ],
            [ 'id' => $lead_id ]
        );

        $platform = Config::get( 'platform_name', 'GoodService' );
        $sent = EmailService::send( $email, 'inquiry_email_otp', [
            'customer_name' => $customer_name ?: 'there',
            'otp_code'      => $code,
            'platform_name' => $platform,
        ] );
        // Fallback path if the 'inquiry_email_otp' template isn't registered on
        // this install (older ManualPlanService seed data) -- send plain text
        // directly so the feature works immediately without a template migration.
        if ( ! $sent ) {
            $sent = wp_mail(
                $email,
                "Your {$platform} verification code",
                "Hi " . ( $customer_name ?: 'there' ) . ",\n\nYour verification code is: {$code}\n\n"
                . "Enter this code to confirm your inquiry/booking. It expires in 10 minutes.\n\n"
                . "If you didn't request this, you can ignore this email.\n\n-- {$platform} Team",
                [ 'Content-Type: text/plain; charset=UTF-8' ]
            );
        }

        set_transient( $rate_key, $attempts_sent + 1, 10 * MINUTE_IN_SECONDS );

        if ( ! $sent ) {
            gs_write_log( "EmailVerificationService::send_otp: mail send failed for lead #{$lead_id} to {$email}", 'WARNING' );
            return [ 'sent' => false, 'error' => 'Could not send the verification email. Please check the address and try again.' ];
        }
        return [ 'sent' => true, 'error' => null ];
    }

    /**
     * Verifies a submitted 6-digit code against the most recent unused,
     * unexpired OTP row for this lead+email. Single-use and attempt-limited,
     * mirroring OtpService::verify() for the phone-OTP flow.
     *
     * @return array{valid:bool, error:?string}
     */
    public static function verify_otp( int $lead_id, string $email, string $code ): array {
        global $wpdb;
        self::ensure_table();

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_email_verify_tokens
             WHERE lead_id = %d AND email = %s AND used = 0 AND code_hash IS NOT NULL
             ORDER BY id DESC LIMIT 1",
            $lead_id, $email
        ) );

        if ( ! $row ) {
            return [ 'valid' => false, 'error' => 'No pending verification found for this inquiry. Please submit again.' ];
        }
        if ( strtotime( $row->expires_at ) < time() ) {
            return [ 'valid' => false, 'error' => 'This code has expired. Please request a new one.' ];
        }
        if ( (int) $row->attempts >= 5 ) {
            $wpdb->update( $wpdb->prefix . 'gs_email_verify_tokens', [ 'used' => 1 ], [ 'id' => (int) $row->id ] );
            return [ 'valid' => false, 'error' => 'Too many incorrect attempts. Please request a new code.' ];
        }

        if ( ! hash_equals( (string) $row->code_hash, hash( 'sha256', trim( $code ) ) ) ) {
            $wpdb->update( $wpdb->prefix . 'gs_email_verify_tokens',
                [ 'attempts' => (int) $row->attempts + 1 ], [ 'id' => (int) $row->id ] );
            return [ 'valid' => false, 'error' => 'Incorrect code. Please check and try again.' ];
        }

        // Correct code -- mark used, flip the lead to verified, fire the same
        // completion event the link flow uses so vendor notification, leads_count,
        // and analytics all activate exactly as they do today.
        $wpdb->update( $wpdb->prefix . 'gs_email_verify_tokens', [ 'used' => 1 ], [ 'id' => (int) $row->id ] );
        $wpdb->update( $wpdb->prefix . 'gs_leads', [ 'email_verified' => 1 ], [ 'id' => $lead_id ] );
        \GoodService\Core\EventBus::emit( 'lead.email_verified', [ 'lead_id' => $lead_id ] );

        return [ 'valid' => true, 'error' => null ];
    }

    /**
     * Handles the GET click from the verification email. Always renders a plain
     * HTML page (not JSON) since this is opened directly in a browser tab, not
     * called via AJAX from a page that can parse a JSON response.
     */
    public static function handle_verify_click(): void {
        global $wpdb;
        $token = sanitize_text_field( $_GET['token'] ?? '' );
        $platform = Config::get( 'platform_name', 'GoodService' );

        if ( ! $token ) {
            self::render_result_page( false, 'Missing verification token.', $platform );
        }

        self::ensure_table();
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_email_verify_tokens WHERE token = %s LIMIT 1", $token
        ) );

        if ( ! $row ) {
            self::render_result_page( false, 'This verification link is invalid.', $platform );
        }
        if ( (int) $row->used ) {
            // Already verified — show success again rather than an error; clicking
            // a link twice (e.g. an email client pre-fetching it) shouldn't look like a failure.
            self::render_result_page( true, 'Your email is already verified. Thank you!', $platform );
        }
        if ( strtotime( $row->expires_at ) < time() ) {
            self::render_result_page( false, 'This verification link has expired. Please submit a new inquiry to receive a fresh link.', $platform );
        }

        $wpdb->update( $wpdb->prefix . 'gs_email_verify_tokens', [ 'used' => 1 ], [ 'id' => (int) $row->id ] );
        $wpdb->update( $wpdb->prefix . 'gs_leads', [ 'email_verified' => 1 ], [ 'id' => (int) $row->lead_id ] );

        // Hard gate (Section 1 of the inquiry/booking audit): this is the moment
        // the inquiry/booking actually becomes "complete" — fire everything that
        // was held back at submission time (vendor notification, leads_count,
        // analytics). See EventBus::init()'s 'lead.email_verified' listener.
        \GoodService\Core\EventBus::emit( 'lead.email_verified', [ 'lead_id' => (int) $row->lead_id ] );

        self::render_result_page( true, 'Your email has been verified. Thank you!', $platform );
    }

    private static function render_result_page( bool $success, string $message, string $platform ): void {
        $color = $success ? '#059669' : '#DC2626';
        $icon  = $success ? '✅' : '❌';
        echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            . '<title>' . esc_html( $platform ) . '</title></head>'
            . '<body style="font-family:Arial,sans-serif;background:#F8FAFC;margin:0;padding:40px 20px;text-align:center">'
            . '<div style="max-width:420px;margin:0 auto;background:#fff;border-radius:14px;padding:36px 28px;box-shadow:0 4px 20px rgba(0,0,0,.08)">'
            . '<div style="font-size:2.4rem;margin-bottom:10px">' . $icon . '</div>'
            . '<div style="font-weight:800;font-size:1.1rem;color:' . $color . ';margin-bottom:8px">' . esc_html( $message ) . '</div>'
            . '<div style="font-size:.85rem;color:#94A3B8;margin-top:18px">You can close this tab now.</div>'
            . '</div></body></html>';
        exit;
    }

    /**
     * Account-level email verification. Distinct from send_otp()/verify_otp()
     * above (which are per-LEAD) — this verifies the customer's account itself,
     * once, sticky. Uses transients rather than the gs_email_verify_tokens
     * table so rate limiting is correctly scoped by user_id from the start —
     * reusing the lead-scoped table with a sentinel lead_id would have shared
     * one rate-limit bucket across every customer on the platform.
     */
    public static function send_account_otp( int $user_id, string $email, string $name ): array {
        if ( ! $user_id || ! is_email( $email ) ) {
            return [ 'sent' => false, 'error' => 'Invalid account or email address.' ];
        }
        $rate_key = 'gs_acct_email_otp_rate_' . $user_id;
        $sent_count = (int) get_transient( $rate_key );
        if ( $sent_count >= 3 ) {
            return [ 'sent' => false, 'error' => 'Too many code requests. Please wait a few minutes and try again.' ];
        }

        $code = str_pad( (string) random_int( 0, 999999 ), 6, '0', STR_PAD_LEFT );
        set_transient( 'gs_acct_email_otp_' . $user_id, [
            'hash'     => wp_hash_password( $code ),
            'attempts' => 0,
        ], 10 * MINUTE_IN_SECONDS );

        $platform = Config::get( 'platform_name', 'GoodService' );
        $sent = EmailService::send( $email, 'inquiry_email_otp', [
            'customer_name' => $name ?: 'there',
            'otp_code'      => $code,
            'platform_name' => $platform,
        ] );
        if ( ! $sent ) {
            $sent = wp_mail(
                $email,
                "Your {$platform} verification code",
                "Hi " . ( $name ?: 'there' ) . ",\n\nYour account verification code is: {$code}\n\n"
                . "Enter this code on your dashboard to verify your account. It expires in 10 minutes.\n\n— {$platform} Team",
                [ 'Content-Type: text/plain; charset=UTF-8' ]
            );
        }
        if ( ! $sent ) {
            delete_transient( 'gs_acct_email_otp_' . $user_id );
            return [ 'sent' => false, 'error' => 'Could not send the verification email. Please try again.' ];
        }
        set_transient( $rate_key, $sent_count + 1, 10 * MINUTE_IN_SECONDS );
        return [ 'sent' => true, 'error' => null ];
    }

    /**
     * Verifies the account-level email code. On success, sets sticky usermeta
     * (gs_account_email_verified=1) so every future inquiry from this account
     * is automatically marked verified at creation — see
     * AjaxController::submitInquiry()'s account-verification pre-check.
     */
    public static function verify_account_otp( int $user_id, string $code ): array {
        if ( ! $user_id ) { return [ 'valid' => false, 'error' => 'Not logged in.' ]; }
        $data = get_transient( 'gs_acct_email_otp_' . $user_id );
        if ( ! $data || empty( $data['hash'] ) ) {
            return [ 'valid' => false, 'error' => 'Code expired or not found. Please request a new one.' ];
        }
        if ( (int) $data['attempts'] >= 5 ) {
            delete_transient( 'gs_acct_email_otp_' . $user_id );
            return [ 'valid' => false, 'error' => 'Too many incorrect attempts. Please request a new code.' ];
        }
        if ( ! wp_check_password( trim( $code ), $data['hash'] ) ) {
            $data['attempts']++;
            set_transient( 'gs_acct_email_otp_' . $user_id, $data, 10 * MINUTE_IN_SECONDS );
            return [ 'valid' => false, 'error' => 'Incorrect code. Please check and try again.' ];
        }
        delete_transient( 'gs_acct_email_otp_' . $user_id );
        update_user_meta( $user_id, 'gs_account_email_verified', 1 );
        return [ 'valid' => true, 'error' => null ];
    }
}
