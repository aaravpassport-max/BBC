<?php
namespace GoodService\Service;

/**
 * Centralized Typography Engine — single reusable source of truth for
 * every text-styling control on the platform (headings, paragraphs,
 * buttons, labels, forms, menus, cards, badges).
 *
 * Real fix, explicit request: before this existed, every section built
 * its own fragmented pair of fields (svc_title_size + svc_title_color,
 * items_title_size + items_title_color, process_title_size +
 * process_title_color, ...) with no font-family, no responsive sizes,
 * no line-height, no letter-spacing, no text-shadow, no presets — and
 * no shared code between any of them. Confirmed by inventorying every
 * *_title_size / *_title_color / *_title_weight field in
 * create-listing.php before writing a single line here.
 *
 * This class owns the two things every typography-controlled element
 * needs, regardless of which section it belongs to:
 *   1. Turning a set of saved `<prefix>_*` customizer_data keys into
 *      real CSS (including responsive breakpoints).
 *   2. Knowing which Google Fonts are actually in use on a listing, so
 *      only those fonts are ever loaded — never the whole library.
 *
 * The matching form-side control set lives in create-listing.php as
 * cl_typography_fields() — kept there rather than here because every
 * other *_style_fields() helper in this codebase (cl_image_style_fields)
 * already lives beside the form markup it renders, and splitting the
 * pattern for typography alone would be its own new inconsistency.
 */
final class TypographyService {

    /**
     * A curated, genuinely useful set of Google Fonts spanning sans,
     * serif, display, and monospace — not the full ~1800-font library
     * hardcoded (no page builder actually ships that as a literal PHP
     * array; Elementor/Bricks/Oxygen all pair a curated/searchable list
     * with free-text entry for anything else). The "Custom Google Font"
     * text field below covers every font not in this list — the CSS/
     * loading mechanism works identically either way, since both paths
     * end up as a plain font family name fed to the same Google Fonts
     * URL builder.
     */
    public const GOOGLE_FONTS = [
        'Inter', 'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Poppins',
        'Nunito', 'Nunito Sans', 'Work Sans', 'Rubik', 'Manrope', 'DM Sans',
        'Source Sans 3', 'Mulish', 'Karla', 'Barlow', 'Outfit', 'Plus Jakarta Sans',
        'Playfair Display', 'Merriweather', 'Lora', 'PT Serif', 'Bitter',
        'Crimson Text', 'Libre Baskerville', 'Cormorant Garamond',
        'Oswald', 'Bebas Neue', 'Anton', 'Archivo Black', 'Raleway',
        'Fjalla One', 'Abril Fatface', 'Pacifico', 'Dancing Script',
        'Caveat', 'Josefin Sans', 'Quicksand', 'Comfortaa', 'Space Grotesk',
        'IBM Plex Sans', 'IBM Plex Serif', 'IBM Plex Mono', 'Fira Sans',
        'Fira Code', 'JetBrains Mono', 'Source Code Pro', 'Roboto Mono',
        'Roboto Slab', 'Noto Sans', 'Jost',
    ];

    /**
     * Web-safe fonts — no Google Fonts request needed, always available.
     */
    public const WEB_SAFE_FONTS = [
        'System Default' => '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif',
        'Arial'           => 'Arial,Helvetica,sans-serif',
        'Helvetica'       => 'Helvetica,Arial,sans-serif',
        'Georgia'         => 'Georgia,"Times New Roman",serif',
        'Times New Roman' => '"Times New Roman",Times,serif',
        'Courier New'     => '"Courier New",Courier,monospace',
        'Verdana'         => 'Verdana,Geneva,sans-serif',
        'Trebuchet MS'    => '"Trebuchet MS",Helvetica,sans-serif',
        'Tahoma'          => 'Tahoma,Geneva,sans-serif',
    ];

    public const FONT_WEIGHTS = [
        '300' => 'Light (300)', '400' => 'Regular (400)', '500' => 'Medium (500)',
        '600' => 'Semi-Bold (600)', '700' => 'Bold (700)', '800' => 'Extra-Bold (800)', '900' => 'Black (900)',
    ];

    public const TEXT_TRANSFORMS = [ 'none' => 'None', 'uppercase' => 'UPPERCASE', 'lowercase' => 'lowercase', 'capitalize' => 'Capitalize' ];
    public const TEXT_DECORATIONS = [ 'none' => 'None', 'underline' => 'Underline', 'overline' => 'Overline', 'line-through' => 'Line-through' ];
    public const TEXT_ALIGNS = [ 'left' => 'Left', 'center' => 'Center', 'right' => 'Right', 'justify' => 'Justify' ];
    public const FONT_STYLES = [ 'normal' => 'Normal', 'italic' => 'Italic' ];

    /**
     * Ready-made presets — click one to fill every field at once,
     * matching the "Typography presets" requirement. Deliberately small
     * and opinionated rather than huge and generic; each one is a
     * genuinely distinct, usable look.
     */
    public static function presets(): array {
        return [
            'modern'  => [ 'label' => 'Modern Sans', 'font_family' => 'Inter', 'font_weight' => '700', 'letter_spacing' => '-0.02', 'line_height' => '1.2', 'text_transform' => 'none' ],
            'elegant' => [ 'label' => 'Elegant Serif', 'font_family' => 'Playfair Display', 'font_weight' => '600', 'letter_spacing' => '0', 'line_height' => '1.3', 'text_transform' => 'none' ],
            'bold'    => [ 'label' => 'Bold Impact', 'font_family' => 'Archivo Black', 'font_weight' => '900', 'letter_spacing' => '0.02', 'line_height' => '1.1', 'text_transform' => 'uppercase' ],
            'minimal' => [ 'label' => 'Minimal', 'font_family' => 'System Default', 'font_weight' => '500', 'letter_spacing' => '0', 'line_height' => '1.4', 'text_transform' => 'none' ],
            'playful' => [ 'label' => 'Playful', 'font_family' => 'Quicksand', 'font_weight' => '700', 'letter_spacing' => '0', 'line_height' => '1.25', 'text_transform' => 'none' ],
        ];
    }

    /** Resolves a stored font_family value (web-safe key or Google Font name) to a real CSS font-family stack. */
    public static function resolve_font_stack( string $font_family, string $fallback = 'sans-serif' ): string {
        if ( $font_family === '' ) { return 'inherit'; }
        if ( isset( self::WEB_SAFE_FONTS[ $font_family ] ) ) { return self::WEB_SAFE_FONTS[ $font_family ]; }
        // Anything else is treated as a Google Font name (curated list or
        // free-typed custom name — both resolve the same way).
        return '"' . str_replace( '"', '', $font_family ) . '",' . $fallback;
    }

    /** True if a font_family value needs a Google Fonts request (i.e. isn't one of the always-available web-safe stacks). */
    public static function is_google_font( string $font_family ): bool {
        return $font_family !== '' && ! isset( self::WEB_SAFE_FONTS[ $font_family ] );
    }

    /**
     * Scans a decoded customizer_data array for every `<prefix>_font_family`
     * value across the given list of prefixes and returns the distinct
     * set that needs loading from Google Fonts — never the whole
     * library, only fonts actually selected somewhere on this listing.
     */
    public static function collect_used_google_fonts( array $cd, array $prefixes ): array {
        $fonts = [];
        foreach ( $prefixes as $prefix ) {
            $f = trim( (string) ( $cd["{$prefix}_font_family"] ?? '' ) );
            if ( $f !== '' && self::is_google_font( $f ) ) { $fonts[ $f ] = true; }
        }
        return array_keys( $fonts );
    }

    /** Builds a single Google Fonts stylesheet URL for a list of font names, requesting a sensible weight range for each. */
    public static function build_google_fonts_url( array $font_names ): string {
        if ( empty( $font_names ) ) { return ''; }
        $families = array_map( function ( $name ) {
            return 'family=' . rawurlencode( $name ) . ':wght@300;400;500;600;700;800;900';
        }, $font_names );
        return 'https://fonts.googleapis.com/css2?' . implode( '&', $families ) . '&display=swap';
    }

    /**
     * Reads every `<prefix>_*` typography key for one element and
     * returns them normalized with sane defaults — the single place
     * that knows what each field means and what happens if it's unset,
     * so the CSS generator and any future consumer (e.g. a live-preview
     * JS payload) both read the exact same resolved values.
     *
     * @param array $defaults Optional per-field overrides, e.g. ['font_size' => 28, 'font_weight' => '800'].
     */
    public static function resolve( array $cd, string $prefix, array $defaults = [] ): array {
        $d = array_merge( [
            'font_family'      => '',
            'font_size'        => 24,
            'font_size_tablet' => '',
            'font_size_mobile' => '',
            'font_weight'      => '700',
            'font_style'       => 'normal',
            'line_height'      => '1.3',
            'letter_spacing'   => '0',
            'word_spacing'     => '0',
            'text_transform'   => 'none',
            'text_decoration'  => 'none',
            'text_align'       => '',
            'color'            => '',
            'shadow_color'     => '#000000',
            'shadow_h'         => 0,
            'shadow_v'         => 0,
            'shadow_blur'      => 0,
            'shadow_opacity'   => 0,
        ], $defaults );

        $get = fn( string $key, $default ) => array_key_exists( "{$prefix}_{$key}", $cd ) && $cd["{$prefix}_{$key}"] !== ''
            ? $cd["{$prefix}_{$key}"] : $default;

        return [
            'font_family'      => (string) $get( 'font_family', $d['font_family'] ),
            'font_size'        => max( 8, min( 120, (int) $get( 'font_size', $d['font_size'] ) ) ),
            'font_size_tablet' => $get( 'font_size_tablet', $d['font_size_tablet'] ) !== '' ? max( 8, min( 120, (int) $get( 'font_size_tablet', 0 ) ) ) : null,
            'font_size_mobile' => $get( 'font_size_mobile', $d['font_size_mobile'] ) !== '' ? max( 8, min( 120, (int) $get( 'font_size_mobile', 0 ) ) ) : null,
            'font_weight'      => in_array( (int) $get( 'font_weight', $d['font_weight'] ), array_keys( self::FONT_WEIGHTS ), true ) ? (string) (int) $get( 'font_weight', $d['font_weight'] ) : $d['font_weight'],
            'font_style'       => in_array( $get( 'font_style', $d['font_style'] ), array_keys( self::FONT_STYLES ), true ) ? $get( 'font_style', $d['font_style'] ) : 'normal',
            'line_height'      => max( 0.8, min( 3, (float) $get( 'line_height', $d['line_height'] ) ) ),
            'letter_spacing'   => max( -0.1, min( 1, (float) $get( 'letter_spacing', $d['letter_spacing'] ) ) ),
            'word_spacing'     => max( -0.5, min( 3, (float) $get( 'word_spacing', $d['word_spacing'] ) ) ),
            'text_transform'   => in_array( $get( 'text_transform', $d['text_transform'] ), array_keys( self::TEXT_TRANSFORMS ), true ) ? $get( 'text_transform', $d['text_transform'] ) : 'none',
            'text_decoration'  => in_array( $get( 'text_decoration', $d['text_decoration'] ), array_keys( self::TEXT_DECORATIONS ), true ) ? $get( 'text_decoration', $d['text_decoration'] ) : 'none',
            'text_align'       => in_array( $get( 'text_align', $d['text_align'] ), array_keys( self::TEXT_ALIGNS ), true ) ? $get( 'text_align', $d['text_align'] ) : '',
            'color'            => ( is_string( $get( 'color', $d['color'] ) ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $get( 'color', $d['color'] ) ) ) ? $get( 'color', $d['color'] ) : $d['color'],
            'shadow_opacity'   => max( 0, min( 100, (int) $get( 'shadow_opacity', $d['shadow_opacity'] ) ) ),
            'shadow_color'     => ( is_string( $get( 'shadow_color', $d['shadow_color'] ) ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $get( 'shadow_color', $d['shadow_color'] ) ) ) ? $get( 'shadow_color', $d['shadow_color'] ) : $d['shadow_color'],
            'shadow_h'         => max( -50, min( 50, (int) $get( 'shadow_h', $d['shadow_h'] ) ) ),
            'shadow_v'         => max( -50, min( 50, (int) $get( 'shadow_v', $d['shadow_v'] ) ) ),
            'shadow_blur'      => max( 0, min( 50, (int) $get( 'shadow_blur', $d['shadow_blur'] ) ) ),
        ];
    }

    /** Builds the text-shadow CSS value from resolved values, or 'none' when opacity is 0 — same "0 = off" convention as the box-shadow engine elsewhere on this platform. */
    private static function shadow_css( array $t ): string {
        if ( $t['shadow_opacity'] <= 0 ) { return 'none'; }
        $c = $t['shadow_color'];
        $r = hexdec( substr( $c, 1, 2 ) ); $g = hexdec( substr( $c, 3, 2 ) ); $b = hexdec( substr( $c, 5, 2 ) );
        return "{$t['shadow_h']}px {$t['shadow_v']}px {$t['shadow_blur']}px rgba({$r},{$g},{$b}," . round( $t['shadow_opacity'] / 100, 2 ) . ')';
    }

    /**
     * Generates a complete, ready-to-echo CSS rule (including tablet
     * <=1024px and mobile <=640px breakpoints when those sizes are set)
     * for one CSS selector, from resolved typography values. This is
     * the one function every section's render code calls — one rule
     * generator, reused everywhere, instead of each section hand-writing
     * its own font-size/color CSS.
     */
    public static function css_rule( array $cd, string $prefix, string $selector, array $defaults = [] ): string {
        $t = self::resolve( $cd, $prefix, $defaults );
        $decls = [];
        if ( $t['font_family'] !== '' ) { $decls[] = 'font-family:' . self::resolve_font_stack( $t['font_family'] ); }
        $decls[] = 'font-size:' . $t['font_size'] . 'px';
        $decls[] = 'font-weight:' . $t['font_weight'];
        $decls[] = 'font-style:' . $t['font_style'];
        $decls[] = 'line-height:' . $t['line_height'];
        $decls[] = 'letter-spacing:' . $t['letter_spacing'] . 'em';
        $decls[] = 'word-spacing:' . $t['word_spacing'] . 'em';
        $decls[] = 'text-transform:' . $t['text_transform'];
        $decls[] = 'text-decoration:' . $t['text_decoration'];
        if ( $t['text_align'] !== '' ) { $decls[] = 'text-align:' . $t['text_align']; }
        if ( $t['color'] !== '' ) { $decls[] = 'color:' . $t['color']; }
        $shadow = self::shadow_css( $t );
        $decls[] = 'text-shadow:' . $shadow;

        $css = "{$selector}{" . implode( ';', $decls ) . "}\n";
        if ( $t['font_size_tablet'] !== null ) {
            $css .= "@media(max-width:1024px){{$selector}{font-size:{$t['font_size_tablet']}px}}\n";
        }
        if ( $t['font_size_mobile'] !== null ) {
            $css .= "@media(max-width:640px){{$selector}{font-size:{$t['font_size_mobile']}px}}\n";
        }
        return $css;
    }
}
