<?php
namespace GoodService\Service;

use GoodService\Module\ModuleManager;
use GoodService\Core\Config;

/**
 * InquiryModuleDiagnostics
 *
 * Full end-to-end health check for the Inquiry Modules feature.
 * Traces every layer of the pipeline:
 *
 *   1. Schema — required DB columns exist
 *   2. Subscription / plan gate — vendor has allow_inquiry_module=1
 *   3. inquiry_modules_data — at least one module is saved and enabled
 *   4. sections_visible_data — inquiry_modules section not hidden
 *   5. InquiryCategoryData registry — saved slugs exist in the registry
 *   6. vendor_profiles row — vendor profile exists and has correct id
 *   7. Listing status — listing is active or pending
 *   8. ModuleManager — booking module flag (informational)
 *   9. WordPress hooks — AJAX actions are registered
 *  10. JavaScript globals — AJX, NONCE expected from vendor-site.php
 *  11. PHP error log — last 20 error lines for context
 *  12. Cache state — any stale cache entries
 *
 * Usage (AJAX):
 *   gsPost('gs_run_inquiry_diag', {nonce, listing_id})
 *   → returns structured JSON with per-check PASS/FAIL/WARN
 *
 * Usage (PHP):
 *   $report = InquiryModuleDiagnostics::run($listing_id);
 */
final class InquiryModuleDiagnostics {

    // ── Check status constants ─────────────────────────────────────────────
    const PASS = 'PASS';
    const FAIL = 'FAIL';
    const WARN = 'WARN';
    const INFO = 'INFO';

    /**
     * Run all checks for a given listing_id.
     * Returns a structured array suitable for JSON encoding.
     */
    public static function run( int $listing_id ): array {
        global $wpdb;
        $pfx   = $wpdb->prefix . 'gs_';
        $start = microtime( true );

        $checks   = [];
        $errors   = [];
        $warnings = [];

        // ── 1. SCHEMA CHECKS ──────────────────────────────────────────────
        $required_listing_cols = [
            'inquiry_modules_data',
            'sections_visible_data',
            'vendor_id',
            'status',
        ];
        $listing_table = $pfx . 'listings';
        $existing_cols = $wpdb->get_col( "SHOW COLUMNS FROM `{$listing_table}`", 0 ) ?: [];
        $missing_cols  = array_diff( $required_listing_cols, $existing_cols );

        if ( $missing_cols ) {
            $checks['schema_listing'] = [
                'status'  => self::FAIL,
                'label'   => 'DB Schema — gs_listings columns',
                'detail'  => 'Missing columns: ' . implode( ', ', array_values( $missing_cols ) ),
                'action'  => 'Run Admin → Tools → DB Upgrade to add missing columns.',
            ];
            $errors[] = 'schema_listing';
        } else {
            $checks['schema_listing'] = [
                'status'  => self::PASS,
                'label'   => 'DB Schema — gs_listings columns',
                'detail'  => 'All required columns exist: ' . implode( ', ', $required_listing_cols ),
            ];
        }

        $vp_table    = $pfx . 'vendor_profiles';
        $required_vp = [ 'id', 'min_visit_charge', 'business_name', 'avg_reply_minutes' ];
        $existing_vp = $wpdb->get_col( "SHOW COLUMNS FROM `{$vp_table}`", 0 ) ?: [];
        $missing_vp  = array_diff( $required_vp, $existing_vp );
        // NOTE: listing_id is intentionally NOT in vendor_profiles — validate it is absent
        $has_wrong_col = in_array( 'listing_id', $existing_vp, true );

        if ( $missing_vp ) {
            $checks['schema_vendor_profiles'] = [
                'status'  => self::FAIL,
                'label'   => 'DB Schema — gs_vendor_profiles columns',
                'detail'  => 'Missing columns: ' . implode( ', ', array_values( $missing_vp ) ),
                'action'  => 'Run Admin → Tools → DB Upgrade.',
            ];
            $errors[] = 'schema_vendor_profiles';
        } else {
            $checks['schema_vendor_profiles'] = [
                'status'  => self::PASS,
                'label'   => 'DB Schema — gs_vendor_profiles columns',
                'detail'  => 'All required columns exist.' . ( $has_wrong_col ? ' WARNING: listing_id column found — this is a phantom column that should not exist.' : ' Confirmed: no listing_id column (correct).' ),
            ];
        }

        // ── 2. LOAD LISTING ───────────────────────────────────────────────
        $listing = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, vendor_id, status, inquiry_modules_data, sections_visible_data
               FROM {$pfx}listings WHERE id = %d",
            $listing_id
        ) );

        if ( ! $listing ) {
            $checks['listing_exists'] = [
                'status'  => self::FAIL,
                'label'   => 'Listing — record found',
                'detail'  => "No listing found with id={$listing_id}.",
                'action'  => 'Verify listing_id is correct.',
            ];
            $errors[] = 'listing_exists';
            return self::_build_report( $checks, $errors, $warnings, $start );
        }

        $checks['listing_exists'] = [
            'status' => self::PASS,
            'label'  => 'Listing — record found',
            'detail' => "Listing id={$listing_id} found. vendor_id={$listing->vendor_id}, status={$listing->status}.",
        ];

        // ── 3. LISTING STATUS ─────────────────────────────────────────────
        if ( ! in_array( $listing->status, [ 'active', 'pending' ], true ) ) {
            $checks['listing_status'] = [
                'status'  => self::FAIL,
                'label'   => 'Listing — status',
                'detail'  => "Listing status is '{$listing->status}'. submitInquiry() requires status='active'.",
                'action'  => 'Activate the listing from Admin → Listings.',
            ];
            $errors[] = 'listing_status';
        } elseif ( $listing->status === 'pending' ) {
            $checks['listing_status'] = [
                'status'  => self::WARN,
                'label'   => 'Listing — status',
                'detail'  => "Listing status is 'pending'. Public visitors can see the microsite (render_listing_unified allows pending), but submitInquiry() requires status='active'. Inquiry form submissions will fail until listing is approved.",
                'action'  => 'Approve the listing from Admin → Listings.',
            ];
            $warnings[] = 'listing_status';
        } else {
            $checks['listing_status'] = [
                'status' => self::PASS,
                'label'  => 'Listing — status',
                'detail' => "Listing status is 'active'. submitInquiry() will accept submissions.",
            ];
        }

        // ── 4. SUBSCRIPTION / PLAN GATE ───────────────────────────────────
        $plan_row = $wpdb->get_row( $wpdb->prepare(
            "SELECT sp.id AS plan_id, sp.name AS plan_name, sp.allow_inquiry_module, sp.allow_booking_module,
                    sub.status AS sub_status, sub.expires_at
               FROM {$pfx}subscriptions sub
               LEFT JOIN {$pfx}subscription_plans sp ON sp.id = sub.plan_id
              WHERE sub.vendor_id = %d
                AND sub.status IN ('active','trialing')
              ORDER BY sub.id DESC LIMIT 1",
            (int) $listing->vendor_id
        ) );

        if ( ! $plan_row ) {
            $checks['plan_gate'] = [
                'status'  => self::FAIL,
                'label'   => 'Subscription — plan gate',
                'detail'  => "No active/trialing subscription found for vendor_id={$listing->vendor_id}. \$_can_inquiry=false → inquiry_modules section is completely hidden on the microsite.",
                'action'  => 'Assign an active subscription plan to this vendor from Admin → Billing. The plan must have allow_inquiry_module=1.',
            ];
            $errors[] = 'plan_gate';
        } elseif ( ! $plan_row->allow_inquiry_module ) {
            $checks['plan_gate'] = [
                'status'  => self::FAIL,
                'label'   => 'Subscription — plan gate',
                'detail'  => "Vendor has plan '{$plan_row->plan_name}' (id={$plan_row->plan_id}) but allow_inquiry_module=0. \$_can_inquiry=false → section completely hidden.",
                'action'  => 'Edit the subscription plan in Admin → Plans and set allow_inquiry_module=1, OR assign the vendor a plan that includes inquiry modules.',
            ];
            $errors[] = 'plan_gate';
        } else {
            $checks['plan_gate'] = [
                'status' => self::PASS,
                'label'  => 'Subscription — plan gate',
                'detail' => "Plan '{$plan_row->plan_name}' (id={$plan_row->plan_id}), allow_inquiry_module=1, allow_booking_module={$plan_row->allow_booking_module}. Sub status: {$plan_row->sub_status}. Expires: {$plan_row->expires_at}.",
            ];
        }

        // ── 5. INQUIRY_MODULES_DATA ───────────────────────────────────────
        $raw_imd = $listing->inquiry_modules_data ?? '';

        if ( empty( $raw_imd ) ) {
            $checks['inquiry_modules_data_exists'] = [
                'status'  => self::FAIL,
                'label'   => 'inquiry_modules_data — saved',
                'detail'  => 'inquiry_modules_data is NULL or empty. No modules have been configured.',
                'action'  => 'Go to Vendor Dashboard → Inquiry & Booking → enable at least one module and Save Settings.',
            ];
            $errors[] = 'inquiry_modules_data_exists';
        } else {
            $imd = json_decode( $raw_imd, true );
            if ( ! is_array( $imd ) ) {
                $checks['inquiry_modules_data_exists'] = [
                    'status'  => self::FAIL,
                    'label'   => 'inquiry_modules_data — JSON valid',
                    'detail'  => "inquiry_modules_data contains invalid JSON. json_decode returned null. Raw value (first 300 chars): " . substr( $raw_imd, 0, 300 ),
                    'action'  => 'Resave inquiry modules from Vendor Dashboard → Inquiry & Booking.',
                ];
                $errors[] = 'inquiry_modules_data_exists';
                $imd = [];
            } else {
                $enabled_slugs = [];
                $disabled_slugs = [];
                foreach ( $imd as $slug => $cfg ) {
                    if ( ! empty( $cfg['enabled'] ) ) {
                        $enabled_slugs[] = $slug;
                    } else {
                        $disabled_slugs[] = $slug;
                    }
                }
                $total = count( $imd );

                if ( empty( $enabled_slugs ) ) {
                    $checks['inquiry_modules_data_exists'] = [
                        'status'  => self::FAIL,
                        'label'   => 'inquiry_modules_data — enabled modules',
                        'detail'  => "{$total} module(s) saved but NONE are enabled. Disabled: " . implode( ', ', $disabled_slugs ) . ". vendor-site.php checks !empty(\$_inq_cfg['enabled']) — all are false.",
                        'action'  => 'Go to Vendor Dashboard → Inquiry & Booking → check the checkbox next to at least one module → Save Settings.',
                    ];
                    $errors[] = 'inquiry_modules_data_exists';
                } else {
                    $checks['inquiry_modules_data_exists'] = [
                        'status' => self::PASS,
                        'label'  => 'inquiry_modules_data — enabled modules',
                        'detail' => "{$total} module(s) total. Enabled: " . implode( ', ', $enabled_slugs ) . ( $disabled_slugs ? '. Disabled: ' . implode( ', ', $disabled_slugs ) : '' ),
                    ];
                }
            }

            // ── 5a. SLUG REGISTRY VALIDATION ──────────────────────────────
            // Checked against InquiryFormService (DB-backed categories +
            // hardcoded fallback), NOT InquiryCategoryData directly — once a
            // category is migrated into gs_form_categories and edited by an
            // admin, InquiryCategoryData's static array no longer reflects
            // what vendor-site.php actually resolves at runtime. Checking the
            // static array alone would produce a false-positive FAIL here for
            // every correctly-working migrated category.
            if ( ! empty( $enabled_slugs ) ) {
                $registry_slugs = array_keys( InquiryFormService::get_all() );
                $unregistered   = [];
                $registered     = [];
                foreach ( $enabled_slugs as $s ) {
                    if ( in_array( $s, $registry_slugs, true ) ) {
                        $registered[] = $s;
                    } else {
                        $unregistered[] = $s;
                    }
                }
                if ( $unregistered ) {
                    $checks['slug_registry'] = [
                        'status'  => self::FAIL,
                        'label'   => 'Inquiry form registry — slug lookup',
                        'detail'  => 'Enabled slug(s) NOT found in the inquiry form registry (InquiryFormService — checks gs_form_categories first, falls back to InquiryCategoryData): ' . implode( ', ', $unregistered ) . '. vendor-site.php calls InquiryFormService::get($slug) — returns null for unknown slugs → module silently dropped from $_inq_modules_data.',
                        'action'  => 'These slugs were likely saved with a different plugin version, or the category/row was deleted. Resave modules from Vendor Dashboard → Inquiry & Booking to pick valid current slugs.',
                    ];
                    $errors[] = 'slug_registry';
                } else {
                    $checks['slug_registry'] = [
                        'status' => self::PASS,
                        'label'  => 'InquiryCategoryData — slug registry',
                        'detail' => 'All enabled slugs found in registry: ' . implode( ', ', $registered ),
                    ];
                }
            }
        }

        // ── 6. SECTIONS_VISIBLE_DATA ──────────────────────────────────────
        $raw_svd = $listing->sections_visible_data ?? '';
        $svd     = $raw_svd ? ( json_decode( $raw_svd, true ) ?: [] ) : [];

        if ( array_key_exists( 'inquiry_modules', $svd ) && $svd['inquiry_modules'] === false ) {
            $checks['sections_visible_data'] = [
                'status'  => self::FAIL,
                'label'   => 'sections_visible_data — inquiry_modules visibility',
                'detail'  => "sections_visible_data['inquiry_modules'] = false. _sec_show('inquiry_modules') returns false → section HTML is echoed but immediately skipped in the render loop. Raw value: " . $raw_svd,
                'action'  => 'Open Create Listing → find the Inquiry Modules card → click the toggle to set it Visible → Save.',
            ];
            $errors[] = 'sections_visible_data';
        } elseif ( array_key_exists( 'inquiry-modules', $svd ) ) {
            $val = $svd['inquiry-modules'] ? 'true' : 'false';
            $checks['sections_visible_data'] = [
                'status'  => self::WARN,
                'label'   => 'sections_visible_data — key format',
                'detail'  => "sections_visible_data contains key 'inquiry-modules' (hyphen) = {$val}. vendor-site.php looks up 'inquiry_modules' (underscore) — these are different keys. The hyphen key is a legacy write from before the create-listing.php key fix. Current value will be ignored (falls to default=true which is correct), but the ghost key persists.",
                'action'  => "Resave the listing from Create Listing to write the correct underscore key and remove the legacy hyphen key.",
            ];
            $warnings[] = 'sections_visible_data';
        } else {
            $display_val = array_key_exists( 'inquiry_modules', $svd ) ? ( $svd['inquiry_modules'] ? 'true' : 'false' ) : 'not set (defaults to visible)';
            $checks['sections_visible_data'] = [
                'status' => self::PASS,
                'label'  => 'sections_visible_data — inquiry_modules visibility',
                'detail' => "inquiry_modules visibility = {$display_val}. _sec_show('inquiry_modules') will return true. Full svd: " . ( $raw_svd ?: '{}' ),
            ];
        }

        // ── 6b. CUSTOMIZER sections_visible fallback check ─────────────────
        $cd_raw = $wpdb->get_var( $wpdb->prepare(
            "SELECT customizer_data FROM {$pfx}listings WHERE id=%d", $listing_id
        ) );
        $cd  = $cd_raw ? ( json_decode( $cd_raw, true ) ?: [] ) : [];
        $sec_vis_legacy = $cd['sections_visible'] ?? [];
        if ( isset( $sec_vis_legacy['inquiry_modules'] ) && $sec_vis_legacy['inquiry_modules'] === false ) {
            $checks['sections_visible_legacy'] = [
                'status'  => self::WARN,
                'label'   => 'customizer_data — legacy sections_visible',
                'detail'  => "customizer_data['sections_visible']['inquiry_modules'] = false. If sections_visible_data does not explicitly set this key, _sec_show() falls back to this legacy value and returns false → section hidden.",
                'action'  => 'Use the Section Order Manager in Create Listing → Layout tab → check Inquiry Modules → Save.',
            ];
            $warnings[] = 'sections_visible_legacy';
        } else {
            $checks['sections_visible_legacy'] = [
                'status' => self::PASS,
                'label'  => 'customizer_data — legacy sections_visible',
                'detail' => isset( $sec_vis_legacy['inquiry_modules'] ) ? "Legacy sections_visible['inquiry_modules'] = true." : "Legacy sections_visible has no inquiry_modules key (correct — defaults to visible).",
            ];
        }

        // ── 7. VENDOR PROFILE ─────────────────────────────────────────────
        $vp = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, business_name, min_visit_charge, avg_reply_minutes, is_active
               FROM {$pfx}vendor_profiles WHERE id = %d",
            (int) $listing->vendor_id
        ) );

        if ( ! $vp ) {
            $checks['vendor_profile'] = [
                'status'  => self::FAIL,
                'label'   => 'Vendor profile — found by vendor_id',
                'detail'  => "No vendor_profile row found with id = {$listing->vendor_id} (listings.vendor_id). inquiry-modules.php queries gs_vendor_profiles WHERE id=%d — returns NULL → \$_iq_vendor_id=0, vendor_name='', min_visit_charge=0.",
                'action'  => 'This vendor account may have been deleted. Contact platform admin.',
            ];
            $errors[] = 'vendor_profile';
        } else {
            $checks['vendor_profile'] = [
                'status' => self::PASS,
                'label'  => 'Vendor profile — found by vendor_id',
                'detail' => "vendor_profiles.id={$vp->id}, business_name='{$vp->business_name}', min_visit_charge={$vp->min_visit_charge}, avg_reply_minutes={$vp->avg_reply_minutes}, is_active={$vp->is_active}.",
            ];

            if ( ! $vp->is_active ) {
                $checks['vendor_profile_active'] = [
                    'status'  => self::WARN,
                    'label'   => 'Vendor profile — is_active',
                    'detail'  => 'Vendor profile is_active=0. The vendor account is deactivated.',
                    'action'  => 'Reactivate vendor from Admin → Vendors.',
                ];
                $warnings[] = 'vendor_profile_active';
            }
        }

        // ── 8. AJAX ACTION REGISTRATION ───────────────────────────────────
        $required_actions = [
            'wp_ajax_gs_submit_inquiry',
            'wp_ajax_nopriv_gs_submit_inquiry',
            'wp_ajax_gs_save_inquiry_modules',
            'wp_ajax_gs_get_available_slots',
            'wp_ajax_nopriv_gs_get_available_slots',
        ];
        $missing_actions = [];
        foreach ( $required_actions as $hook ) {
            if ( ! has_action( $hook ) ) {
                $missing_actions[] = $hook;
            }
        }
        if ( $missing_actions ) {
            $checks['ajax_hooks'] = [
                'status'  => self::FAIL,
                'label'   => 'WordPress AJAX hooks — registered',
                'detail'  => 'Missing AJAX hooks: ' . implode( ', ', $missing_actions ) . '. AjaxController::register() was not called or the plugin is not fully initialized.',
                'action'  => 'Deactivate and reactivate the GoodService plugin. If the problem persists, check for PHP fatal errors during activation.',
            ];
            $errors[] = 'ajax_hooks';
        } else {
            $checks['ajax_hooks'] = [
                'status' => self::PASS,
                'label'  => 'WordPress AJAX hooks — registered',
                'detail' => 'All required AJAX hooks are registered: ' . implode( ', ', $required_actions ),
            ];
        }

        // ── 9. MODULE MANAGER ─────────────────────────────────────────────
        $booking_on = ModuleManager::is_enabled( 'booking' );
        $checks['module_manager'] = [
            'status' => self::INFO,
            'label'  => 'ModuleManager — booking module',
            'detail' => 'booking module is ' . ( $booking_on ? 'ENABLED' : 'DISABLED' ) . '. This controls whether "Book Now" buttons appear on inquiry panels. Does NOT affect inquiry form display.',
        ];

        // ── 10. INQUIRY FORM REGISTRY ──────────────────────────────────────
        // Checked via InquiryFormService (DB-backed + hardcoded fallback) —
        // see the slug-registry check above for why this isn't checked
        // against InquiryCategoryData directly.
        $all_slugs = array_keys( InquiryFormService::get_all() );
        $checks['registry'] = [
            'status' => self::PASS,
            'label'  => 'Inquiry form registry — loaded',
            'detail' => count( $all_slugs ) . ' categories registered. First 5: ' . implode( ', ', array_slice( $all_slugs, 0, 5 ) ) . '...',
        ];

        // ── 11. PHP CONFIG / ENVIRONMENT ──────────────────────────────────
        $php_ver = PHP_VERSION;
        $checks['php_version'] = [
            'status' => version_compare( $php_ver, '8.0', '>=' ) ? self::PASS : self::WARN,
            'label'  => 'Environment — PHP version',
            'detail' => "PHP {$php_ver}. Plugin requires PHP 8.0+.",
        ];

        $json_ok = function_exists( 'json_encode' ) && function_exists( 'json_decode' );
        $checks['php_json'] = [
            'status' => $json_ok ? self::PASS : self::FAIL,
            'label'  => 'Environment — JSON extension',
            'detail' => $json_ok ? 'json_encode/json_decode available.' : 'JSON extension missing — all DB JSON reads will fail.',
        ];

        $wp_ver = get_bloginfo( 'version' );
        $checks['wp_version'] = [
            'status' => version_compare( $wp_ver, '6.0', '>=' ) ? self::PASS : self::WARN,
            'label'  => 'Environment — WordPress version',
            'detail' => "WordPress {$wp_ver}.",
        ];

        // ── 12. GS_DIR CONSTANT ───────────────────────────────────────────
        $gs_dir_ok = defined( 'GS_DIR' ) && file_exists( GS_DIR . 'templates/pages/partials/inquiry-modules.php' );
        $checks['gs_dir'] = [
            'status' => $gs_dir_ok ? self::PASS : self::FAIL,
            'label'  => 'GS_DIR constant — inquiry-modules.php reachable',
            'detail' => defined( 'GS_DIR' )
                ? ( $gs_dir_ok
                    ? 'GS_DIR=' . GS_DIR . ' — templates/pages/partials/inquiry-modules.php exists.'
                    : 'GS_DIR=' . GS_DIR . ' but templates/pages/partials/inquiry-modules.php NOT FOUND.' )
                : 'GS_DIR constant is not defined — plugin bootstrap did not run.',
            'action' => $gs_dir_ok ? null : 'Reinstall or repair the plugin files.',
        ];

        // ── 13. WPDB ERROR CAPTURE ────────────────────────────────────────
        if ( $wpdb->last_error ) {
            $checks['wpdb_last_error'] = [
                'status'  => self::WARN,
                'label'   => 'wpdb — last error',
                'detail'  => 'wpdb->last_error: ' . $wpdb->last_error,
                'action'  => 'Review DB error above. May indicate a missing column or table.',
            ];
            $warnings[] = 'wpdb_last_error';
        }

        // ── 14. PHP ERROR LOG TAIL ────────────────────────────────────────
        $php_error_log = ini_get( 'error_log' );
        $log_tail = '';
        if ( $php_error_log && file_exists( $php_error_log ) && is_readable( $php_error_log ) ) {
            $lines      = file( $php_error_log );
            $recent     = array_slice( $lines ?: [], -20 );
            $gs_related = array_filter( $recent, fn( $l ) => stripos( $l, 'goodservice' ) !== false || stripos( $l, 'inquiry' ) !== false || stripos( $l, 'gs_' ) !== false );
            $log_tail   = implode( '', $gs_related ?: array_slice( $recent, -5 ) );
        }
        $checks['php_error_log'] = [
            'status' => self::INFO,
            'label'  => 'PHP error log — recent GS-related entries',
            'detail' => $log_tail ? nl2br( esc_html( $log_tail ) ) : 'No recent GS-related PHP errors found (or log not readable).',
        ];

        // ── 15. CACHE STATE ───────────────────────────────────────────────
        $cache_key = 'schema:cols:listings:' . ( defined( 'GS_VERSION' ) ? GS_VERSION : '0' );
        $cached_cols = \GoodService\Core\Cache::get( $cache_key );
        if ( is_array( $cached_cols ) && ! in_array( 'inquiry_modules_data', $cached_cols, true ) ) {
            $checks['cache_schema'] = [
                'status'  => self::FAIL,
                'label'   => 'Cache — schema column cache',
                'detail'  => "Cached DB column list for gs_listings does NOT include 'inquiry_modules_data'. ListingRepository::save() will silently strip this column on every save. Cache key: {$cache_key}.",
                'action'  => 'Run Admin → Tools → DB Upgrade (this flushes the column cache and re-detects columns). Or deactivate/reactivate the plugin.',
            ];
            $errors[] = 'cache_schema';
        } elseif ( is_array( $cached_cols ) ) {
            $checks['cache_schema'] = [
                'status' => self::PASS,
                'label'  => 'Cache — schema column cache',
                'detail' => 'Schema column cache includes inquiry_modules_data. ' . count( $cached_cols ) . ' columns cached.',
            ];
        } else {
            $checks['cache_schema'] = [
                'status' => self::INFO,
                'label'  => 'Cache — schema column cache',
                'detail' => 'No schema column cache found (will be built on next listing save — normal for a fresh install).',
            ];
        }

        // ── GLOBAL CSS SETTINGS — direct read-back check ───────────────────
        // Calls Config::get() with the EXACT same key + default pair the
        // render template (inquiry-modules.php) uses for every one of the
        // 27 global typography/color/spacing settings. This is the single
        // most direct way to answer "did my saved setting actually reach
        // the value the form reads" — if a key shows its hardcoded default
        // here, Config::get() is returning the fallback, which means either
        // it was never saved, or Config::load() never populated the store
        // for this request (e.g. a boot failure — see the boot_error check
        // elsewhere in this report).
        $css_settings = [
            'inq_global_heading_color'            => '#ffffff',
            'inq_global_body_color'               => 'rgba(255,255,255,.82)',
            'inq_global_input_bg'                 => '#F8FAFC',
            'inq_global_input_border'             => '#E2E8F0',
            'inq_global_input_text'               => '#1E293B',
            'inq_global_btn_bg'                   => '(brand color)',
            'inq_global_btn_text'                 => '#ffffff',
            'inq_global_label_color'              => '#475569',
            'inq_global_font_family'              => 'inherit',
            'inq_global_input_font_size'          => '.86rem',
            'inq_global_input_font_weight'        => '400',
            'inq_global_btn_font_size'            => '.87rem',
            'inq_global_btn_font_weight'          => '700',
            'inq_global_help_font_size'           => '.7rem',
            'inq_global_help_color'               => '#94A3B8',
            'inq_global_help_font_weight'         => '400',
            'inq_global_desc_color'               => '#64748B',
            'inq_global_desc_font_size'           => '.8rem',
            'inq_global_desc_font_weight'         => '400',
            'inq_global_placeholder_color'        => '#94A3B8',
            'inq_global_placeholder_font_size'    => '.83rem',
            'inq_global_placeholder_font_weight'  => '400',
            'inq_global_form_shadow'              => 'lg',
            'inq_global_form_radius'              => '24',
            'inq_global_btn_radius'               => '8',
            'inq_global_sec_pt'                   => '72',
            'inq_global_sec_pb'                   => '72',
        ];
        $css_rows = [];
        $css_customized = 0;
        foreach ( $css_settings as $key => $default ) {
            $live = \GoodService\Core\Config::get( $key, '(not in config store — using default)' );
            $is_default = ( (string) $live === (string) $default ) || $live === '(not in config store — using default)';
            if ( ! $is_default ) { $css_customized++; }
            $css_rows[] = [
                'key'             => $key,
                'live_value'      => $live,
                'hardcoded_default' => $default,
                'is_using_default'  => $is_default,
            ];
        }
        $checks['global_css_settings'] = [
            'status'  => self::PASS,
            'label'   => 'Global CSS Settings — live values from Config::get()',
            'detail'  => "{$css_customized} of " . count( $css_settings ) . ' setting(s) have a non-default value currently stored. '
                . 'If you changed a setting in Settings → Inquiry Form — Global Design Defaults and it still shows its default '
                . "value below, the save did not reach the config store under this exact key.",
            'render_as' => 'rows', // tells the admin UI to render $css_rows as a table — NOT the existing 'action' field, which is reserved for human-readable fix text and would otherwise literally print "▶ Fix: rows" on screen
            'rows'    => $css_rows,
        ];

        // ── SUMMARY ───────────────────────────────────────────────────────
        return self::_build_report( $checks, $errors, $warnings, $start );
    }

    // ── Internal: assemble final report ───────────────────────────────────
    private static function _build_report( array $checks, array $errors, array $warnings, float $start ): array {
        $elapsed   = round( ( microtime( true ) - $start ) * 1000, 1 );
        $pass_cnt  = count( array_filter( $checks, fn( $c ) => $c['status'] === self::PASS ) );
        $fail_cnt  = count( $errors );
        $warn_cnt  = count( $warnings );
        $total     = count( $checks );

        $overall = $fail_cnt > 0 ? self::FAIL : ( $warn_cnt > 0 ? self::WARN : self::PASS );

        return [
            'overall'   => $overall,
            'summary'   => "{$pass_cnt}/{$total} checks passed. {$fail_cnt} failure(s), {$warn_cnt} warning(s). Ran in {$elapsed}ms.",
            'checks'    => array_values( array_map( fn( $id, $c ) => array_merge( ['id' => $id], $c ), array_keys( $checks ), array_values( $checks ) ) ),
            'errors'    => $errors,
            'warnings'  => $warnings,
            'timestamp' => current_time( 'mysql' ),
        ];
    }
}
