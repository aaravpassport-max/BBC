<?php
/**
 * GoodService Platform — Uninstall Handler
 *
 * Fired when the plugin is deleted from WP admin (not just deactivated).
 * Removes all 77 gs_* tables, all gs_* options, all transients, and
 * all scheduled cron hooks.
 *
 * WARNING: This is irreversible. All GoodService data is permanently
 * removed when the plugin is deleted. Export data before uninstalling.
 *
 * @package GoodService
 */

// Block direct execution — WordPress sets this constant before calling uninstall.php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// ── 1. Drop all custom tables ──────────────────────────────────────────────────
// Safe: get actual table list from DB instead of hardcoding — handles any
// tables added by upgrade_columns() that may not be in the base schema list.
$gs_tables = $wpdb->get_col(
    $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->esc_like( $wpdb->prefix . 'gs_' ) . '%' )
);

foreach ( $gs_tables as $table ) {
    // Extra safety: only drop tables that start with {prefix}gs_
    if ( str_starts_with( $table, $wpdb->prefix . 'gs_' ) ) {
        $wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL
    }
}

// ── 2. Remove all GoodService wp_options rows ──────────────────────────────────
// Covers: gs_version, gs_db_version, gs_boot_error, gs_activation_error,
//         gs_cv_* (cache version counters), gs_settings_* (legacy), etc.
$wpdb->query(
    "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'gs_%'"   // phpcs:ignore
);

// Remove transients written by Cache::l2_set() (prefix: gsc)
$wpdb->query(
    "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_gsc%'"  // phpcs:ignore
);
$wpdb->query(
    "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_gsc%'"  // phpcs:ignore
);
// Remove any GoodService site transients
$wpdb->query(
    "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_site_transient_gsc%'"  // phpcs:ignore
);

// ── 3. Remove custom user roles ────────────────────────────────────────────────
// Roles persist in wp_user_roles option — must be explicitly removed.
$custom_roles = [ 'gs_vendor', 'gs_manager', 'gs_moderator', 'gs_staff', 'gs_customer' ];
foreach ( $custom_roles as $role ) {
    remove_role( $role );
}

// ── 4. Clear all GoodService scheduled cron events ────────────────────────────
$cron_hooks = [ 'gs_hourly', 'gs_daily', 'gs_weekly', 'gs_monthly', 'gs_process_jobs' ];
foreach ( $cron_hooks as $hook ) {
    wp_clear_scheduled_hook( $hook );
}

// ── 5. Remove any GoodService rewrite rules from DB ───────────────────────────
// Flush rewrite rules so WP rebuilds them without GS rules
// (the rules themselves live in $wp_rewrite, regenerated from active plugins;
//  deleting the plugin removes our add_rewrite_rule() calls automatically)
delete_option( 'rewrite_rules' );

// ── 6. Clean up uploaded media files ───────────────────────────────────────────
// H5 FIX: Remove vendor-uploaded files from wp-content/uploads/gs-uploads/
// to prevent orphaned files accumulating on disk after plugin deletion.
// Only removes files in our dedicated subdirectory — never touches WP media library.
$gs_upload_dir = WP_CONTENT_DIR . '/uploads/gs-uploads/';
if ( is_dir( $gs_upload_dir ) ) {
    // Recursive directory removal using WP_Filesystem for compatibility
    global $wp_filesystem;
    if ( ! function_exists( 'WP_Filesystem' ) ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }
    WP_Filesystem();
    if ( $wp_filesystem ) {
        $wp_filesystem->delete( $gs_upload_dir, true ); // true = recursive
    }
}

// ── 7. Strip GoodService roles from user accounts ────────────────────────────
// H6 FIX: Users assigned a now-removed GS role lose that role assignment.
// WP does not auto-clean roles on remove_role() — users retain the role
// key in usermeta even though the role definition is gone.
$gs_roles_to_strip = [ 'gs_vendor', 'gs_manager', 'gs_moderator', 'gs_staff', 'gs_customer' ];
// Query users who have any GS role in wp_capabilities
$gs_users = $wpdb->get_col(
    "SELECT user_id FROM {$wpdb->usermeta}
     WHERE meta_key = '{$wpdb->prefix}capabilities'
       AND meta_value REGEXP '(gs_vendor|gs_manager|gs_moderator|gs_staff|gs_customer)'"
);
foreach ( (array) $gs_users as $uid ) {
    $user = new WP_User( (int) $uid );
    if ( ! $user->exists() ) { continue; }
    foreach ( $gs_roles_to_strip as $role ) {
        if ( in_array( $role, (array) $user->roles, true ) ) {
            $user->remove_role( $role );
        }
    }
    // If the user now has no roles, assign the WP default
    if ( empty( $user->roles ) ) {
        $user->set_role( get_option( 'default_role', 'subscriber' ) );
    }
}
