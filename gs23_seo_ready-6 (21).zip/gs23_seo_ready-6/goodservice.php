<?php
/**
 * Plugin Name:  GoodService Platform
 * Plugin URI:   https://good-service.in
 * Description:  SaaS directory & marketplace. Custom architecture — zero WP post dependency.
 * Version:      7.475.20-202609091200
 * Author:       GoodService
 * Text Domain:  goodservice
 * Requires PHP: 8.1
 * Requires WP:  6.2
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// ── PHP version guard — must be checked before any PHP 8.x syntax runs ──────
if ( version_compare( PHP_VERSION, '8.1.0', '<' ) ) {
    add_action( 'admin_notices', function () {
        echo '<div class="notice notice-error"><p><strong>GoodService Platform</strong> requires PHP 8.1 or higher. '
           . 'Your server is running PHP ' . PHP_VERSION . '. Please upgrade PHP or contact your hosting provider.</p></div>';
    } );
    // Deactivate gracefully
    add_action( 'admin_init', function () {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }
    } );
    return;
}

// ── Constants ───────────────────────────────────────────────────────────────
// ⚠️ MANDATORY, PERMANENT PRACTICE — read before editing this file ⚠️
// There are TWO version fields in this plugin, and they were found to have
// silently drifted apart: the header comment above ("Version:", the ONLY
// thing WordPress's own Plugins dashboard ever reads or displays) had been
// stuck at an old value for a long time, while GS_VERSION below (used only
// internally, for the automatic database-upgrade check in Plugin::check_
// db_version()) had been bumped repeatedly without anyone noticing the
// header never moved with it. The practical effect: the user could never
// see, from WordPress's own dashboard, that anything had actually changed —
// exactly the report that led to this fix.
// THE RULE, GOING FORWARD, FOR EVERY SINGLE DELIVERY WITH NO EXCEPTIONS:
// update the "Version:" line in the header comment above AND the GS_VERSION
// constant below TOGETHER, to the IDENTICAL value, every time — never one
// without the other. Use the format MAJOR.MINOR.PATCH-YYYYMMDDHHmm (UTC) —
// confirmed directly with version_compare() that a numeric-only suffix
// after the hyphen sorts correctly (never treated as a pre-release, unlike
// the -alpha/-beta/-dev/-rc keywords version_compare() has special, LOWER-
// ranking behavior for), so this format is safe for the automatic upgrade
// check to keep comparing against correctly, forever, going forward.
define( 'GS_VERSION',  '7.475.20-202609091200' );
// Build fingerprint — a literal timestamp baked into THIS exact file at the
// moment it was last edited. Distinct from GS_VERSION (which requires
// remembering to bump it) and from filesystem mtimes (which some deploy
// tools / zip extractors silently preserve from the ORIGINAL source files,
// making a stale deployment look identical to a fresh one by every normal
// signal). Compared live against PHP OPcache's cached compile time for this
// same file in the new "Deployment & Build Integrity" diagnostic check — if
// they don't match, the server is running different bytecode than what's on
// disk right now, which is the exact failure mode that caused a confirmed,
// verified-correct code change to have zero effect after multiple deploys.
// H1/L1 FIX: Build fingerprint derived from this file's own modification time
// instead of a hardcoded timestamp. Automatically changes on every deploy
// whenever goodservice.php is written to disk — no manual update required.
// The OPcache diagnostic compares this value against the bytecode compile time;
// a mismatch reliably indicates the server is running stale OPcache bytecode.
define( 'GS_BUILD_FINGERPRINT', filemtime( __FILE__ ) );
define( 'GS_DIR',      plugin_dir_path( __FILE__ ) );
define( 'GS_URL',      plugin_dir_url(  __FILE__ ) );
define( 'GS_BASENAME', plugin_basename( __FILE__ ) );
define( 'GS_SRC',      GS_DIR . 'src/' );
define( 'GS_LOG_FILE', WP_CONTENT_DIR . '/gs-debug.log' );

// ── Image Optimizer defaults (override in wp-config.php if needed) ──────────
// These can also be changed at runtime via WordPress filters.
//   add_filter( 'gs_optimizer_webp_quality',    fn() => 90 );
//   add_filter( 'gs_optimizer_strip_metadata',  '__return_true' );
//   add_filter( 'gs_optimizer_max_dimension',   fn() => 2400 );
if ( ! defined( 'GS_IMG_WEBP_QUALITY'  ) ) define( 'GS_IMG_WEBP_QUALITY',   88 );
if ( ! defined( 'GS_IMG_AVIF_QUALITY'  ) ) define( 'GS_IMG_AVIF_QUALITY',   80 );
if ( ! defined( 'GS_IMG_JPEG_QUALITY'  ) ) define( 'GS_IMG_JPEG_QUALITY',   88 );
if ( ! defined( 'GS_IMG_STRIP_META'    ) ) define( 'GS_IMG_STRIP_META',    false );
if ( ! defined( 'GS_IMG_MAX_DIMENSION' ) ) define( 'GS_IMG_MAX_DIMENSION',    0 ); // 0 = no cap

// Wire constants → filters so ImageOptimizer picks them up automatically.
add_filter( 'gs_optimizer_webp_quality',   fn() => GS_IMG_WEBP_QUALITY   );
add_filter( 'gs_optimizer_avif_quality',   fn() => GS_IMG_AVIF_QUALITY   );
add_filter( 'gs_optimizer_jpeg_quality',   fn() => GS_IMG_JPEG_QUALITY   );
add_filter( 'gs_optimizer_strip_metadata', fn() => GS_IMG_STRIP_META     );
add_filter( 'gs_optimizer_max_dimension',  fn() => GS_IMG_MAX_DIMENSION  );

// ── Error logger (zero dependencies, always available) ──────────────────────
if ( ! function_exists( 'gs_write_log' ) ) {
    function gs_write_log( string $msg, string $level = 'ERROR' ): void {
        $line = '[' . date( 'Y-m-d H:i:s' ) . '][' . $level . '] ' . $msg . PHP_EOL;
        @file_put_contents( WP_CONTENT_DIR . '/gs-debug.log', $line, FILE_APPEND | LOCK_EX );
    }
}

// ── Shutdown: catches parse errors / fatal errors that kill PHP ──────────────
// Registered FIRST so it fires even when subsequent requires crash.
register_shutdown_function( function () {
    $e = error_get_last();
    if ( ! $e ) { return; }
    if ( ! in_array( $e['type'], [ E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR ], true ) ) { return; }
    $msg = 'PHP Fatal [' . $e['type'] . ']: ' . $e['message']
         . ' in ' . str_replace( ABSPATH, '', $e['file'] ) . ':' . $e['line'];
    gs_write_log( $msg );
    // Capture in DB-backed error log (Section 4 — backend errors)
    if ( class_exists( '\GoodService\Core\DiagnosticsEngine' ) ) {
        try {
            \GoodService\Core\DiagnosticsEngine::capture(
                \GoodService\Core\DiagnosticsEngine::SRC_PHP,
                'php_fatal',
                \GoodService\Core\DiagnosticsEngine::SEV_CRITICAL,
                $msg,
                [ 'file' => $e['file'], 'line' => $e['line'] ]
            );
        } catch ( \Throwable $ignored ) { /* never let diagnostics crash the shutdown handler */ }
    }
    // Try to store in options for display in admin
    global $wpdb;
    if ( $wpdb instanceof \wpdb ) {
        $wpdb->replace( $wpdb->options, [ 'option_name' => 'gs_activation_error', 'option_value' => $msg, 'autoload' => 'yes' ] );
    }
} );

// ── Autoloader ────────────────────────────────────────────────────────────────
spl_autoload_register( static function ( string $class ): void {
    if ( ! str_starts_with( $class, 'GoodService\\' ) ) { return; }
    $path = GS_SRC . str_replace( [ 'GoodService\\', '\\' ], [ '', '/' ], $class ) . '.php';
    if ( file_exists( $path ) ) { require_once $path; }
} );

// ── Global helpers ─────────────────────────────────────────────────────────
require_once GS_SRC . 'functions.php';

// ── Modular listing architecture: register every migrated module ───────────
// See src/Modules/ModulesBootstrap.php for why this call exists — no
// equivalent registration point existed anywhere in the codebase before
// this was added (a real, previously-undocumented gap found this session).
\GoodService\Modules\ModulesBootstrap::register_all();

// Real feature: applies every admin-made section-configuration change
// (Section Manager screen — category mapping, active/inactive, label,
// order — plus any pure no-code sections built via the Section Builder)
// on top of the code-registered defaults above. Deferred to the 'init'
// hook rather than called immediately here: $wpdb is a WordPress global
// only guaranteed available once WordPress itself has finished its own
// bootstrap, and this file loads earlier than that in the request
// lifecycle. apply_admin_overrides() is idempotent (guarded by its own
// $overrides_applied flag), so this is safe even if something else also
// happens to trigger it earlier on a given request.
add_action( 'init', function () {
    global $wpdb;
    \GoodService\Core\ModuleRegistry::apply_admin_overrides( $wpdb, $wpdb->prefix . 'gs_' );
}, 5 );

// ── Blueprint Enhancements (new features added on top of existing plugin) ──
require_once GS_SRC . 'Service/GS_Enhancements.php';

// ── Show activation error as admin notice (plugin must be active) ────────────
add_action( 'admin_notices', function () {
    // Show boot error (plugin loaded but failed to initialise)
    $boot_err = get_option( 'gs_boot_error', '' );
    if ( $boot_err && current_user_can( 'manage_options' ) ) {
        $dismiss_boot = wp_nonce_url( add_query_arg( 'gs_dismiss_boot_err', '1' ), 'gs_dismiss_boot_err' );
        echo '<div style="background:#FFF7ED;border:1px solid #FED7AA;border-left:5px solid #F97316;border-radius:4px;margin:6px 0;padding:12px 16px">';
        echo '<strong style="color:#9A3412">⚠️ GoodService — Boot Error (plugin cannot initialise):</strong><br>';
        echo '<code style="font-size:.82rem;color:#7C2D12">' . esc_html( $boot_err ) . '</code>';
        echo '<br><a href="' . esc_url( $dismiss_boot ) . '" style="display:inline-block;margin-top:8px;background:#F1F5F9;color:#334155;padding:4px 10px;border-radius:4px;font-size:.82rem;border:1px solid #CBD5E1;text-decoration:none">✕ Dismiss</a>';
        echo '</div>';
    }
    $err = get_option( 'gs_activation_error', '' );
    if ( ! $err || ! current_user_can( 'manage_options' ) ) { return; }
    $dismiss = wp_nonce_url( add_query_arg( 'gs_dismiss_err', '1' ), 'gs_dismiss_err' );
    ?>
    <div style="background:#FEF2F2;border:1px solid #FECACA;border-left:5px solid #DC2626;border-radius:4px;margin:6px 0;padding:14px 18px">
      <strong style="color:#991B1B;display:block;margin-bottom:6px">🚨 GoodService — Activation Error</strong>
      <code style="display:block;background:#fff;border:1px solid #FECACA;border-radius:4px;padding:10px;font-size:.82rem;color:#7F1D1D;white-space:pre-wrap;max-height:180px;overflow-y:auto;margin-bottom:10px"><?php echo esc_html( $err ); ?></code>
      <a href="<?php echo esc_url( admin_url( 'admin.php?page=goodservice&section=debug' ) ); ?>"
         style="background:#DC2626;color:#fff;padding:5px 12px;border-radius:4px;font-size:.82rem;font-weight:700;text-decoration:none;margin-right:8px">📋 Debug Log</a>
      <a href="<?php echo esc_url( $dismiss ); ?>"
         style="background:#F1F5F9;color:#334155;padding:5px 12px;border-radius:4px;font-size:.82rem;border:1px solid #CBD5E1;text-decoration:none">✕ Dismiss</a>
    </div>
    <?php
} );

add_action( 'admin_init', function () {
    // L4 FIX: wp_nonce_url() puts the nonce in $_GET['_wpnonce'], not in
    // $_GET['gs_dismiss_err']. The old check used the value '1' as the nonce,
    // which always failed verification — the dismiss link never worked.
    if ( isset( $_GET['gs_dismiss_err'] ) && wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'gs_dismiss_err' ) ) {
        delete_option( 'gs_activation_error' );
        wp_safe_redirect( remove_query_arg( [ 'gs_dismiss_err', '_wpnonce' ] ) );
        exit;
    }
    // Dismiss boot error notice
    if ( isset( $_GET['gs_dismiss_boot_err'] ) && wp_verify_nonce( sanitize_text_field( $_GET['gs_dismiss_boot_err'] ), 'gs_dismiss_boot_err' ) ) {
        delete_option( 'gs_boot_error' );
        wp_safe_redirect( remove_query_arg( 'gs_dismiss_boot_err' ) );
        exit;
    }
    // Handle diagnostic panel POST actions
    if ( class_exists( '\GoodService\Core\GSDiagnostics' ) ) {
        \GoodService\Core\GSDiagnostics::handle_panel_post();
    }
} );

// ── Admin notice: missing DB columns (surfaces silently-stripped save fields) ──
add_action( 'admin_notices', function () {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $warn = get_option( 'gs_missing_cols_warning', [] );
    if ( empty( $warn['cols'] ) ) return;
    $age_mins = round( ( time() - strtotime( $warn['time'] ?? 'now' ) ) / 60 );
    if ( $age_mins > 60 ) return; // only show for 1 hour
    $dismiss = wp_nonce_url( add_query_arg( 'gs_dismiss_col_warn', '1' ), 'gs_dismiss_col_warn' );
    ?>
    <div style="background:#FFFBEB;border:1px solid #FDE68A;border-left:5px solid #F59E0B;border-radius:4px;margin:6px 0;padding:14px 18px">
        <strong style="color:#92400E;display:block;margin-bottom:6px">
            ⚠️ GoodService — Listing Save Incomplete (Missing DB Columns)
        </strong>
        <p style="margin:0 0 8px;color:#78350F;font-size:.88rem">
            A listing was saved <?php echo $age_mins; ?> minute(s) ago but some fields were <strong>silently dropped</strong> because
            these database columns don't exist yet:
            <code style="background:#FEF3C7;padding:2px 6px;border-radius:3px"><?php echo esc_html( implode( ', ', $warn['cols'] ) ); ?></code>
        </p>
        <p style="margin:0;font-size:.85rem">
            👉 Go to <a href="<?php echo esc_url( home_url('/admin-panel/?section=tools') ); ?>" target="_blank" style="color:#B45309;font-weight:700">Admin Panel → Tools → DB Upgrade</a>
            and click <strong>"Run DB Upgrade"</strong> to add the missing columns.
            After that, re-save the listing.
        </p>
        <a href="<?php echo esc_url($dismiss); ?>" style="display:inline-block;margin-top:8px;font-size:.8rem;color:#92400E">Dismiss</a>
    </div>
    <?php
} );
add_action( 'admin_init', function () {
    if ( isset( $_GET['gs_dismiss_col_warn'] ) && wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'gs_dismiss_col_warn' ) ) {
        delete_option( 'gs_missing_cols_warning' );
        wp_safe_redirect( remove_query_arg( [ 'gs_dismiss_col_warn', '_wpnonce' ] ) );
        exit;
    }
} );


// ── MySQL session-level performance tuning ────────────────────────────────────
// Applied once per PHP request as soon as the DB connection is available.
// These are SESSION-scoped (never permanent) and only set if GoodService is
// the active page handler — they do not affect other plugins.
//
// For permanent MySQL tuning, add to your my.cnf / my.ini:
//   [mysqld]
//   innodb_buffer_pool_size    = 2G          # 70 % of available RAM
//   innodb_log_file_size       = 256M
//   innodb_flush_log_at_trx_commit = 2       # slight durability trade-off for speed
//   ft_min_word_len            = 2           # shorter keyword search (rebuild FT indexes after)
//   innodb_ft_min_token_size   = 2
//   query_cache_type           = 0           # disabled in MySQL 8 — leave off
//
// For Redis object cache, add to wp-config.php:
//   define( 'WP_REDIS_HOST', '127.0.0.1' );
//   define( 'WP_REDIS_PORT', 6379 );
//   define( 'WP_CACHE', true );
//
add_action( 'init', static function (): void {
    // Only tune when GoodService is actually serving a page or handling AJAX.
    // Previously this ran on ALL front-end requests (WooCommerce, blog posts, etc.),
    // adding 4 unnecessary SET SESSION queries per non-GoodService page load.
    if ( is_admin() && ! wp_doing_ajax() ) { return; }
    if ( ! wp_doing_ajax() && ! get_query_var( 'gs_page' ) ) { return; }
    global $wpdb;
    // Ensure the connection uses utf8mb4 so 4-byte emoji characters are
    // never silently truncated to '?' by the MySQL server.
    // wp-config.php may define DB_CHARSET as 'utf8' (3-byte only) on older
    // installs; this overrides it for all GoodService DB operations.
    if ( $wpdb->charset !== 'utf8mb4' ) {
        $wpdb->set_charset( $wpdb->dbh, 'utf8mb4', 'utf8mb4_unicode_ci' );
    }
    $wpdb->query( "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci" );
    // Raise sort/join buffers for complex multi-table queries with ORDER BY.
    // These are per-session and do not persist beyond this PHP process.
    $wpdb->query( "SET SESSION sort_buffer_size   = 4194304" );   // 4 MB
    $wpdb->query( "SET SESSION join_buffer_size    = 4194304" );   // 4 MB
    $wpdb->query( "SET SESSION tmp_table_size      = 67108864" );  // 64 MB
    $wpdb->query( "SET SESSION max_heap_table_size = 67108864" );  // 64 MB
}, 1 );

// ── Bootstrap ─────────────────────────────────────────────────────────────────
// NOTE: Admin menu registration is handled inside Plugin::boot() via
// WPAdminController::register(). It was previously also registered here,
// causing all 7 WP admin submenus to appear TWICE (CRITICAL BUG FIX #3).
add_action( 'plugins_loaded', function () {
    try {
        \GoodService\Core\Plugin::boot();
        // Boot succeeded — clear any stale error from a previous failed boot.
        delete_option( 'gs_boot_error' );
    } catch ( \Throwable $e ) {
        // boot() failed — still register the admin menu so the admin can
        // navigate to the GoodService panel to view the error notice.
        if ( is_admin() ) {
            add_action( 'admin_menu', [ \GoodService\Controller\WPAdminController::class, 'register_menu' ] );
            add_action( 'admin_bar_menu', [ \GoodService\Controller\WPAdminController::class, 'admin_bar_links' ], 100 );
        }
        $msg = get_class($e) . ': ' . $e->getMessage() . ' in ' . str_replace(ABSPATH,'',$e->getFile()) . ':' . $e->getLine();
        gs_write_log( 'Plugin boot() failed: ' . $msg );
        update_option( 'gs_boot_error', $msg );
    }
}, 5 );

// ── Activation ────────────────────────────────────────────────────────────────
register_activation_hook( __FILE__, function () {
    delete_option( 'gs_activation_error' );
    gs_write_log( 'Activation started — GoodService v' . GS_VERSION, 'INFO' );

    try {
        gs_write_log( '[1/5] Registering roles', 'INFO' );
        \GoodService\Core\Roles::register();

        gs_write_log( '[2/5] Installing DB schema', 'INFO' );
        \GoodService\Database\Schema::install();

        gs_write_log( '[3/5] Seeding default data', 'INFO' );
        \GoodService\Database\Seeder::run();
        \GoodService\Service\EmailService::seed_templates();

        gs_write_log( '[4/5] Registering rewrite rules', 'INFO' );
        \GoodService\Router\Router::register_rewrites();

        gs_write_log( '[5/5] Creating pages', 'INFO' );
        \GoodService\Core\Plugin::create_pages();

        flush_rewrite_rules();
        update_option( 'gs_version',    GS_VERSION );
        update_option( 'gs_db_version', GS_VERSION );
        delete_option( 'gs_activation_error' );
        gs_write_log( 'Activation complete!', 'INFO' );

    } catch ( \Throwable $e ) {
        $msg  = get_class($e) . ': ' . $e->getMessage() . PHP_EOL;
        $msg .= 'File: ' . str_replace(ABSPATH,'',$e->getFile()) . '  Line: ' . $e->getLine() . PHP_EOL;
        $msg .= $e->getTraceAsString();
        gs_write_log( $msg );
        update_option( 'gs_activation_error', $msg );
        throw $e;
    }
} );

register_deactivation_hook( __FILE__, [ \GoodService\Core\Plugin::class, 'deactivate' ] );

// Uninstall — handled by uninstall.php (WordPress calls it on plugin deletion)
// This ensures all 77 gs_* tables, options, transients, roles, and cron hooks
// are cleaned up permanently when the plugin is deleted from WP admin.
register_uninstall_hook( __FILE__, '__return_false' ); // Signals WP to use uninstall.php

// Auto-flush rewrite rules when plugin version changes (handles updates without deactivate/reactivate)
add_action( 'init', function () {
    // GS_REWRITE_VER is separate from GS_VERSION so rule additions
    // (e.g. /login/, /create-listing/, /track-job/{token}/) trigger a flush
    // without a plugin version bump.
    $gs_rewrite_ver = GS_VERSION . '-r3';
    if ( get_option( 'gs_rewrite_version' ) !== $gs_rewrite_ver ) {
        flush_rewrite_rules( false );
        update_option( 'gs_rewrite_version', $gs_rewrite_ver );
    }
}, 20 );

// ── Global mail failure capture — real fix ──────────────────────────────────
// Confirmed gap: no wp_mail_failed handler existed anywhere in this plugin,
// meaning every email failure (SMTP rejection, PHPMailer exception, a
// misconfigured mail plugin intercepting wp_mail entirely) was completely
// invisible — the code calling wp_mail() has no way to know it failed
// unless something is listening for this specific WordPress hook. This
// also stores the last 20 failures as an option so the admin diagnostic
// tool can show real, current failures directly, not just log-file entries
// someone has to go find.
add_action( 'wp_mail_failed', function ( \WP_Error $error ) {
    $entry = [
        'time'    => current_time( 'mysql' ),
        'message' => $error->get_error_message(),
        'data'    => $error->get_error_data(),
    ];
    if ( function_exists( 'gs_write_log' ) ) {
        gs_write_log( 'wp_mail_failed: ' . $entry['message'] . ' | ' . wp_json_encode( $entry['data'] ), 'ERROR' );
    }
    $recent = get_option( 'gs_recent_mail_failures', [] );
    array_unshift( $recent, $entry );
    update_option( 'gs_recent_mail_failures', array_slice( $recent, 0, 20 ), false );
} );

// ── PWA Manifest Links (served at root) ─────────────────────────────────────
// These must be served as proper JSON with the correct MIME type.
// WordPress doesn't serve arbitrary files, so we register a rewrite rule.
add_action( 'init', function () {
    // My Home Dashboard (Moat 5)
    add_rewrite_rule( '^my-home/?$', 'index.php?gs_page=my_home', 'top' );
    // RWA Society Dashboard (Moat 3)
    add_rewrite_rule( '^rwa/dashboard/?$', 'index.php?gs_page=rwa_dashboard', 'top' );
    // Part 26.1 — SEO Location pages: /service/{category}/{city}/
    add_rewrite_rule(
        'service/([a-z0-9-]+)/([a-z0-9-]+)/?$',
        'index.php?gs_page=seo_location&gs_cat_slug=$matches[1]&gs_city_slug=$matches[2]',
        'top'
    );
    // Quote acceptance
    add_rewrite_rule(
        'quote/accept/([a-f0-9]{64})/?$',
        'index.php?gs_page=quote-accept&gs_quote_token=$matches[1]',
        'top'
    );
    // Job tracking
    add_rewrite_rule(
        'track/([a-zA-Z0-9_\-]{8,64})/?$',
        'index.php?gs_page=job-track&gs_track_token=$matches[1]',
        'top'
    );
    // Vendor manifest
    add_rewrite_rule(
        'goodservice-vendor\.webmanifest$',
        'index.php?gs_pwa_manifest=vendor',
        'top'
    );
    // Client manifest
    add_rewrite_rule(
        'goodservice-client\.webmanifest$',
        'index.php?gs_pwa_manifest=client',
        'top'
    );
}, 10 );

add_filter( 'query_vars', function ( $vars ) {
    $vars[] = 'gs_pwa_manifest';
    $vars[] = 'gs_quote_token';
    $vars[] = 'gs_cat_slug';
    $vars[] = 'gs_city_slug';
    $vars[] = 'gs_track_token';
    return $vars;
} );

add_action( 'template_redirect', function () {
    $manifest = get_query_var( 'gs_pwa_manifest' );
    if ( ! $manifest ) { return; }

    $file = GS_DIR . "goodservice-{$manifest}.webmanifest";
    if ( ! file_exists( $file ) ) { return; }

    header( 'Content-Type: application/manifest+json; charset=UTF-8' );
    header( 'Cache-Control: public, max-age=86400' );
    readfile( $file );
    exit;
} );


// ── GDPR / India DPDPA: Personal Data Export and Erasure hooks ─────────────
// Registers GoodService with WordPress's built-in privacy tools so that
// Tools → Export Personal Data and Tools → Erase Personal Data work for
// PII stored in custom gs_* tables (gs_leads, gs_vendor_profiles, etc.)

add_filter( 'wp_privacy_personal_data_exporters', function( array $exporters ): array {
    $exporters['goodservice'] = [
        'exporter_friendly_name' => 'GoodService Platform',
        'callback'               => function( string $email, int $page = 1 ): array {
            global $wpdb;
            $items = [];

            // Export lead/inquiry data submitted by this email
            $leads = $wpdb->get_results( $wpdb->prepare(
                "SELECT id, name, phone, email, message, city, created_at, status
                 FROM {$wpdb->prefix}gs_leads WHERE email = %s ORDER BY created_at DESC LIMIT 50",
                $email
            ) );
            foreach ( $leads as $l ) {
                $items[] = [
                    'group_id'    => 'gs_inquiries',
                    'group_label' => 'GoodService Inquiries',
                    'item_id'     => 'lead-' . $l->id,
                    'data'        => [
                        [ 'name' => 'Inquiry ID',   'value' => $l->id ],
                        [ 'name' => 'Name',         'value' => $l->name ],
                        [ 'name' => 'Email',        'value' => $l->email ],
                        [ 'name' => 'Phone',        'value' => $l->phone ],
                        [ 'name' => 'Message',      'value' => $l->message ],
                        [ 'name' => 'City',         'value' => $l->city ],
                        [ 'name' => 'Submitted At', 'value' => $l->created_at ],
                    ],
                ];
            }

            // Export vendor profile data for this email
            $vp = $wpdb->get_row( $wpdb->prepare(
                "SELECT id, business_name, email, phone, city, bio, created_at
                 FROM {$wpdb->prefix}gs_vendor_profiles WHERE email = %s LIMIT 1",
                $email
            ) );
            if ( $vp ) {
                $items[] = [
                    'group_id'    => 'gs_vendor_profile',
                    'group_label' => 'GoodService Vendor Profile',
                    'item_id'     => 'vendor-' . $vp->id,
                    'data'        => [
                        [ 'name' => 'Business Name', 'value' => $vp->business_name ],
                        [ 'name' => 'Email',         'value' => $vp->email ],
                        [ 'name' => 'Phone',         'value' => $vp->phone ],
                        [ 'name' => 'City',          'value' => $vp->city ],
                        [ 'name' => 'Bio',           'value' => $vp->bio ],
                        [ 'name' => 'Joined At',     'value' => $vp->created_at ],
                    ],
                ];
            }

            return [ 'data' => $items, 'done' => true ];
        },
    ];
    return $exporters;
} );

add_filter( 'wp_privacy_personal_data_erasers', function( array $erasers ): array {
    $erasers['goodservice'] = [
        'eraser_friendly_name' => 'GoodService Platform',
        'callback'             => function( string $email, int $page = 1 ): array {
            global $wpdb;
            $removed = 0;
            $retained = [];

            // Anonymise leads (not hard-delete — preserve for vendor's records)
            $anon = $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->prefix}gs_leads
                 SET name='[deleted]', email='[deleted]', phone='[deleted]',
                     message='[deleted]', ip_address='', user_agent='', city=''
                 WHERE email = %s",
                $email
            ) );
            if ( $anon ) { $removed += $anon; }

            // Remove push subscriptions (device tokens)
            $del_push = $wpdb->get_col( $wpdb->prepare(
                "SELECT ps.id FROM {$wpdb->prefix}gs_push_subscriptions ps
                 INNER JOIN {$wpdb->prefix}users u ON u.ID = ps.user_id
                 WHERE u.user_email = %s", $email
            ) );
            if ( $del_push ) {
                $wpdb->query( $wpdb->prepare(
                    "DELETE FROM {$wpdb->prefix}gs_push_subscriptions WHERE id IN ("
                    . implode( ',', array_fill( 0, count( $del_push ), '%d' ) ) . ")",
                    ...$del_push
                ) );
                $removed += count( $del_push );
            }

            // Retain vendor profile (contains business records required for accounting)
            $vp = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}gs_vendor_profiles WHERE email = %s LIMIT 1",
                $email
            ) );
            if ( $vp ) {
                $retained[] = 'Vendor profile retained for accounting/legal compliance (business records).';
            }

            return [
                'items_removed'  => $removed > 0,
                'items_retained' => count( $retained ) > 0,
                'messages'       => $retained,
                'done'           => true,
            ];
        },
    ];
    return $erasers;
} );
