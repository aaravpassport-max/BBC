# Build Tooling — GoodService Platform

This documents how the minified assets (`assets/js/goodservice.min.js` and
`assets/css/goodservice.min.css`) are generated. Both npm scripts below were
actually run and verified to reproduce the exact minified files already
shipped in this package before this file was written — not just assumed to
work from the command syntax.

## Requirements

- Node.js and npm
- The `node_modules/` folder included in this archive already has everything
  installed. If you ever need to reinstall from scratch instead, delete
  `node_modules/` and run `npm install`.

## Regenerating the minified assets

After editing the real source files (`assets/js/goodservice.js` or
`assets/css/goodservice.css`), regenerate their minified versions:

```bash
npm run build:js    # regenerates assets/js/goodservice.min.js via terser
npm run build:css   # regenerates assets/css/goodservice.min.css via clean-css
npm run build       # runs both
```

## Why this matters — read before editing the source files

The plugin has a built-in safety mechanism (`gs_asset_url()` in
`src/functions.php`) that automatically checks whether the minified file is
genuinely *newer* than its real source before ever using it. If you edit
`goodservice.js` or `goodservice.css` and forget to rebuild, the plugin will
correctly and automatically fall back to serving the real, unminified file —
it will never silently serve a stale minified version. This was a deliberate
fix for a real bug that existed in an earlier version of this plugin, where a
stale minified pair silently shadowed real fixes.

**In short:** forgetting to run `npm run build` after an edit costs you the
performance benefit of minification until you do — it does not risk serving
broken or outdated code either way.

## Tooling versions used

- terser 5.49.0 (JS minification)
- clean-css-cli 5.6.3 (CSS minification)

Both are pinned as devDependencies in `package.json`.
