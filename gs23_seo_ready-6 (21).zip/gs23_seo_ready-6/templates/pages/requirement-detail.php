<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
global $wpdb;
$pfx = $wpdb->prefix . 'gs_';
$req_id = intval( get_query_var('gs_requirement_id', 0) );
if ( ! $req_id ) { wp_redirect( home_url('/directory/') ); exit; }
$req  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pfx}requirements WHERE id=%d AND status='open'", $req_id ) );
if ( ! $req ) { wp_redirect( home_url('/directory/') ); exit; }
$bids = $wpdb->get_results( $wpdb->prepare(
    "SELECT rb.*,vp.business_name,vp.logo_url,vp.verification_status FROM {$pfx}requirement_bids rb
     LEFT JOIN {$pfx}vendor_profiles vp ON rb.vendor_id=vp.user_id
     WHERE rb.requirement_id=%d ORDER BY rb.created_at ASC", $req_id
) );
$sym = gs_setting('currency_symbol','₹');
?>
<div class="gs-root">
  <!-- Page header -->
  <div style="background:linear-gradient(135deg,#1E3A5F,#2563EB);padding:36px 0">
    <div class="gs-container">
      <div style="color:rgba(255,255,255,.6);font-size:.8rem;margin-bottom:8px"><a href="<?php echo home_url('/'); ?>" style="color:rgba(255,255,255,.6)">Home</a> › Requirements</div>
      <h1 style="font-size:1.6rem;font-weight:900;color:white;margin:0 0 8px"><?php echo esc_html($req->title); ?></h1>
      <div style="display:flex;flex-wrap:wrap;gap:16px">
        <?php if($req->poster_city): ?><span style="color:rgba(255,255,255,.75);font-size:.88rem">📍 <?php echo esc_html($req->poster_city); ?></span><?php endif; ?>
        <?php if($req->budget_max): ?><span style="color:rgba(255,255,255,.75);font-size:.88rem">💰 Budget up to <?php echo $sym.number_format($req->budget_max); ?></span><?php endif; ?>
        <span style="color:rgba(255,255,255,.75);font-size:.88rem">📅 <?php echo gs_time_ago($req->created_at); ?></span>
        <span style="color:rgba(255,255,255,.75);font-size:.88rem">💬 <?php echo count($bids); ?> responses</span>
      </div>
    </div>
  </div>
  <div class="gs-container" style="padding-top:32px;padding-bottom:60px">
    <div style="display:grid;grid-template-columns:1fr 360px;gap:28px;align-items:start">
      <div>
        <?php if($req->description): ?>
        <div class="gs-card" style="margin-bottom:20px">
          <div class="gs-card-title" style="margin-bottom:12px">📋 Requirement Details</div>
          <div style="font-size:.92rem;line-height:1.8;color:#475569"><?php echo nl2br(esc_html($req->description)); ?></div>
        </div>
        <?php endif; ?>
        <h2 style="font-size:1.1rem;font-weight:700;color:#1E3A5F;margin:0 0 16px">Responses (<?php echo count($bids); ?>)</h2>
        <?php if($bids): ?>
        <div style="display:flex;flex-direction:column;gap:16px">
          <?php foreach($bids as $b): ?>
          <div class="gs-card">
            <div style="display:flex;align-items:center;gap:14px;margin-bottom:12px">
              <?php if($b->logo_url): ?><img src="<?php echo esc_url($b->logo_url); ?>" style="width:48px;height:48px;border-radius:10px;object-fit:cover"><?php else: ?><div style="width:48px;height:48px;border-radius:10px;background:var(--gs-primary);color:white;font-weight:700;font-size:1.1rem;display:flex;align-items:center;justify-content:center"><?php echo strtoupper(substr($b->business_name??'V',0,1)); ?></div><?php endif; ?>
              <div>
                <div style="font-weight:700;font-size:.95rem"><?php echo esc_html($b->business_name??'Vendor'); ?></div>
                <div style="font-size:.78rem;color:#64748B"><?php echo gs_time_ago($b->created_at); ?></div>
              </div>
              <?php if($b->bid_amount): ?><div style="margin-left:auto;font-weight:900;font-size:1.1rem;color:var(--gs-primary)"><?php echo $sym.number_format($b->bid_amount); ?></div><?php endif; ?>
            </div>
            <div style="font-size:.88rem;line-height:1.7;color:#475569"><?php echo nl2br(esc_html($b->message??'')); ?></div>
            <?php if($b->timeline): ?><div style="margin-top:10px;font-size:.8rem;color:#64748B">⏱ Timeline: <?php echo esc_html($b->timeline); ?></div><?php endif; ?>
          </div>
          <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div style="text-align:center;padding:40px;color:#94A3B8;background:#F8FAFC;border-radius:12px"><div style="font-size:2rem;margin-bottom:10px">💬</div><div>No responses yet.</div></div>
        <?php endif; ?>
      </div>
      <div style="position:sticky;top:90px">
        <?php if(gs_is_vendor()): ?>
        <div class="gs-card">
          <div class="gs-card-title" style="margin-bottom:14px">Submit Your Quote</div>
          <form id="gs-bid-form-page">
            <input type="hidden" name="requirement_id" value="<?php echo $req->id; ?>">
            <div class="gs-form-group"><label class="gs-form-label">Quote Amount (<?php echo $sym; ?>)</label><input type="number" name="bid_amount" class="gs-input" placeholder="Leave blank if negotiable"></div>
            <div class="gs-form-group"><label class="gs-form-label">Delivery Timeline</label><input type="text" name="timeline" class="gs-input" placeholder="e.g. 3–5 days"></div>
            <div class="gs-form-group"><label class="gs-form-label">Message *</label><textarea name="message" class="gs-textarea" rows="4" placeholder="Introduce yourself and explain how you can help..." required></textarea></div>
            <button type="submit" class="gs-btn gs-btn-primary gs-btn-lg gs-btn-full">Submit Quote</button>
          </form>
          <script>jQuery('#gs-bid-form-page').on('submit',function(e){e.preventDefault();var $b=jQuery(this).find('[type=submit]');gsBtnLoading($b,true,'Submitting…');var d={};jQuery(this).serializeArray().forEach(function(f){d[f.name]=f.value;});gsPost('gs_submit_bid',d,function(r){gsBtnLoading($b,false);gsToast(r.message||'Quote submitted!','success');jQuery('#gs-bid-form-page')[0].reset();},function(m){gsBtnLoading($b,false);gsToast(m,'error');});});</script>
        </div>
        <?php elseif(!is_user_logged_in()): ?>
        <div class="gs-card" style="text-align:center;padding:24px">
          <div style="font-size:1.8rem;margin-bottom:10px">🏢</div>
          <div style="font-weight:700;margin-bottom:8px;color:#1E3A5F">Are you a vendor?</div>
          <div style="font-size:.85rem;color:#64748B;margin-bottom:16px">Login or register to submit a quote.</div>
          <a href="<?php echo home_url('/vendor/login/'); ?>" class="gs-btn gs-btn-primary gs-btn-md gs-btn-full">Login to Respond</a>
        </div>
        <?php endif; ?>
        <div class="gs-card" style="margin-top:16px">
          <div style="font-size:.82rem;color:#64748B"><strong>Posted by:</strong> <?php echo esc_html($req->poster_name??'Anonymous'); ?></div>
          <?php if($req->budget_min&&$req->budget_max): ?><div style="font-size:.82rem;color:#64748B;margin-top:6px"><strong>Budget:</strong> <?php echo $sym.number_format($req->budget_min); ?> – <?php echo $sym.number_format($req->budget_max); ?></div><?php endif; ?>
          <div style="font-size:.82rem;color:#64748B;margin-top:6px"><strong>Status:</strong> <span class="gs-badge gs-badge-green"><?php echo ucfirst($req->status); ?></span></div>
        </div>
      </div>
    </div>
  </div>
</div>
