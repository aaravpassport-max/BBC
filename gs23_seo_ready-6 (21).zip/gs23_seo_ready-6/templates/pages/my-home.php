<?php
/**
 * GoodService — My Home Dashboard (Moat 5: Home Service OS)
 * Accessible at /my-home/ for logged-in clients.
 * Shows service history, warranty alerts, and upcoming reminders.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! is_user_logged_in() ) {
    wp_safe_redirect( wp_login_url( home_url( '/my-home/' ) ) );
    exit;
}

$user_id  = get_current_user_id();
$user     = wp_get_current_user();
global $wpdb;

// Check tables exist
$has_table = $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_home_profiles'" );

if ( ! $has_table ) {
    get_header();
    echo '<div style="max-width:600px;margin:60px auto;text-align:center;padding:24px">
        <div style="font-size:2rem;margin-bottom:12px">⚠️</div>
        <h2 style="color:#92400E">Home OS not yet activated</h2>
        <p style="color:#64748B">Please ask the admin to run DB Upgrade to activate this feature.</p>
    </div>';
    get_footer();
    exit;
}

$profile  = \GoodService\Service\HomeOsService::get_or_create_profile( $user_id );
$history  = \GoodService\Service\HomeOsService::get_service_history( (int) $profile->id );
$expiring = \GoodService\Service\HomeOsService::get_expiring_warranties( (int) $profile->id );
$nonce    = wp_create_nonce( 'gs_ajax' );
$ajax_url = admin_url( 'admin-ajax.php' );

get_header();
?>
<style>
.mh-wrap{max-width:960px;margin:0 auto;padding:24px 16px}
.mh-hd{background:linear-gradient(135deg,#1E3A5F,#2563EB);color:#fff;border-radius:14px;padding:24px;margin-bottom:20px}
.mh-card{background:#fff;border:1px solid #E2E8F0;border-radius:12px;padding:20px;margin-bottom:16px;box-shadow:0 2px 8px rgba(0,0,0,.04)}
.mh-card-title{font-weight:700;font-size:.95rem;color:#1E293B;margin-bottom:14px;display:flex;align-items:center;gap:8px}
.mh-rec{display:flex;align-items:flex-start;gap:12px;padding:12px 0;border-bottom:1px solid #F1F5F9}
.mh-rec-icon{width:40px;height:40px;border-radius:8px;background:#EFF6FF;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0}
</style>

<div class="mh-wrap">
  <!-- Header -->
  <div class="mh-hd">
    <div style="font-size:.8rem;opacity:.7;margin-bottom:4px">Welcome back</div>
    <div style="font-size:1.3rem;font-weight:700"><?php echo esc_html( $user->display_name ); ?></div>
    <div style="font-size:.8rem;opacity:.75;margin-top:4px">🏠 <?php echo esc_html( $profile->property_name ); ?><?php if($profile->address): ?> · <?php echo esc_html( $profile->address ); ?><?php endif; ?></div>
  </div>

  <!-- Warranty alerts -->
  <?php if ( ! empty( $expiring ) ): ?>
  <div class="mh-card" style="border-color:#FDE68A;background:#FFFBEB">
    <div class="mh-card-title" style="color:#92400E">⚠️ Warranties Expiring Soon</div>
    <?php foreach ( $expiring as $w ): ?>
    <div class="mh-rec">
      <div class="mh-rec-icon" style="background:#FEF3C7">🛡️</div>
      <div>
        <div style="font-weight:600;font-size:.88rem"><?php echo esc_html( $w->service_title ); ?></div>
        <div style="font-size:.75rem;color:#92400E">Expires <?php echo date( 'd M Y', strtotime( $w->warranty_expiry ) ); ?>
          (<?php echo human_time_diff( time(), strtotime( $w->warranty_expiry ) ); ?> remaining)
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <!-- Quick stats -->
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px">
    <div class="mh-card" style="text-align:center;padding:16px">
      <div style="font-size:1.4rem;font-weight:700;color:#2563EB"><?php echo count( $history ); ?></div>
      <div style="font-size:.75rem;color:#64748B;margin-top:3px">Services Done</div>
    </div>
    <div class="mh-card" style="text-align:center;padding:16px">
      <div style="font-size:1.4rem;font-weight:700;color:#D97706"><?php echo count( $expiring ); ?></div>
      <div style="font-size:.75rem;color:#64748B;margin-top:3px">Warranties Expiring</div>
    </div>
    <div class="mh-card" style="text-align:center;padding:16px">
      <?php $total = array_sum( array_column( $history, 'amount_paid' ) ); ?>
      <div style="font-size:1.4rem;font-weight:700;color:#059669">₹<?php echo number_format( $total ); ?></div>
      <div style="font-size:.75rem;color:#64748B;margin-top:3px">Total Spent</div>
    </div>
  </div>

  <!-- Add service record manually -->
  <div class="mh-card">
    <div class="mh-card-title">➕ Add Service Record</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div><label style="font-size:.75rem;font-weight:600;color:#334155;display:block;margin-bottom:4px">Service *</label>
        <input id="mh-svc" type="text" class="gs-input" placeholder="e.g. AC Service, Painting"></div>
      <div><label style="font-size:.75rem;font-weight:600;color:#334155;display:block;margin-bottom:4px">Date *</label>
        <input id="mh-date" type="date" class="gs-input" max="<?php echo date('Y-m-d'); ?>"></div>
      <div><label style="font-size:.75rem;font-weight:600;color:#334155;display:block;margin-bottom:4px">Vendor Name</label>
        <input id="mh-vendor" type="text" class="gs-input" placeholder="Vendor name"></div>
      <div><label style="font-size:.75rem;font-weight:600;color:#334155;display:block;margin-bottom:4px">Amount Paid (₹)</label>
        <input id="mh-amount" type="number" class="gs-input" placeholder="0"></div>
    </div>
    <div style="margin-top:10px"><label style="font-size:.75rem;font-weight:600;color:#334155;display:block;margin-bottom:4px">Notes</label>
      <textarea id="mh-notes" class="gs-textarea" rows="2" placeholder="Any additional notes…"></textarea></div>
    <button onclick="mhAdd()" class="gs-btn gs-btn-primary" style="margin-top:12px">Save Record</button>
  </div>

  <!-- Service history -->
  <div class="mh-card">
    <div class="mh-card-title">📋 Service History</div>
    <?php if ( empty( $history ) ): ?>
    <p style="color:#94A3B8;font-size:.83rem;text-align:center;padding:12px">No service records yet. Add your first one above!</p>
    <?php else: ?>
    <?php
    $cat_icons = [ 'plumber'=>'🔧','electrician'=>'⚡','ac-repair'=>'❄️','ac-service'=>'❄️','pest-control'=>'🪳','carpenter'=>'🪚','painting'=>'🎨','cleaning'=>'🧹' ];
    foreach ( $history as $h ):
      $icon = $cat_icons[$h->category_slug ?? ''] ?? '🏠';
    ?>
    <div class="mh-rec" id="mh-rec-<?php echo (int) $h->id; ?>">
      <div class="mh-rec-icon"><?php echo $icon; ?></div>
      <div style="flex:1">
        <div style="font-weight:600;font-size:.87rem"><?php echo esc_html( $h->service_title ); ?></div>
        <div style="font-size:.75rem;color:#64748B">
          📅 <?php echo date( 'd M Y', strtotime( $h->service_date ) ); ?>
          <?php if ( $h->vendor_name ): ?> · 👤 <?php echo esc_html( $h->vendor_name ); ?><?php endif; ?>
          <?php if ( $h->amount_paid > 0 ): ?> · ₹<?php echo number_format( $h->amount_paid ); ?><?php endif; ?>
        </div>
        <?php if ( $h->warranty_expiry ): ?>
        <div style="font-size:.7rem;color:<?php echo strtotime($h->warranty_expiry) < time() ? '#DC2626' : '#059669'; ?>;margin-top:2px">
          🛡 Warranty <?php echo strtotime($h->warranty_expiry) < time() ? 'expired' : 'until'; ?> <?php echo date('d M Y',strtotime($h->warranty_expiry)); ?>
        </div>
        <?php endif; ?>
      </div>
      <?php if ( $h->next_service_due ): ?>
      <div style="font-size:.7rem;background:#EFF6FF;color:#1D4ED8;border-radius:20px;padding:3px 8px;flex-shrink:0">
        Next: <?php echo date('d M Y',strtotime($h->next_service_due)); ?>
      </div>
      <?php endif; ?>
      <?php
      // FIXED — audit gap: no way to correct or remove a mis-entered
      // record. "Delete" here removes the record from this personal
      // tracker only — it does not touch any underlying booking.
      ?>
      <button onclick="mhDelete(<?php echo (int) $h->id; ?>,'<?php echo esc_js( $h->service_title ); ?>')" title="Delete this record" style="background:none;border:none;color:#CBD5E1;font-size:1rem;cursor:pointer;flex-shrink:0;padding:4px" onmouseover="this.style.color='#DC2626'" onmouseout="this.style.color='#CBD5E1'">✕</button>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<script>
function mhDelete(recordId,title){
  if(!confirm('Delete the record for "'+title+'"? This cannot be undone.')){return;}
  var fd=new FormData();
  fd.append('action','gs_delete_service_record'); fd.append('nonce','<?php echo esc_js($nonce); ?>');
  fd.append('record_id',recordId);
  fetch('<?php echo esc_js($ajax_url); ?>',{method:'POST',credentials:'same-origin',body:fd})
    .then(function(r){return r.json();})
    .then(function(j){
      if(j.success){
        // Reload rather than just removing the row in place — the Services
        // Done / Total Spent quick-stat tiles above are computed from
        // $history server-side and would otherwise go stale until the
        // next full page load, same reasoning as mhAdd()'s own reload.
        if(typeof gsToast!=='undefined')gsToast('Record deleted.','success');
        setTimeout(function(){location.reload();},400);
      } else {
        alert((j.data&&j.data.message)||'Failed to delete.');
      }
    })
    .catch(function(){
      alert('Network error — could not delete this record. Please try again.');
    });
}
function mhAdd(){
  var svc=document.getElementById('mh-svc').value.trim();
  var date=document.getElementById('mh-date').value;
  if(!svc||!date){if(typeof gsToast!=='undefined')gsToast('Service and date are required.','error');else alert('Service and date are required.');return;}
  var fd=new FormData();
  fd.append('action','gs_add_service_record'); fd.append('nonce','<?php echo esc_js($nonce); ?>');
  fd.append('service_title',svc); fd.append('service_date',date);
  fd.append('vendor_name',document.getElementById('mh-vendor').value);
  fd.append('amount_paid',document.getElementById('mh-amount').value||0);
  fd.append('notes',document.getElementById('mh-notes').value);
  fetch('<?php echo esc_js($ajax_url); ?>',{method:'POST',credentials:'same-origin',body:fd})
    .then(function(r){return r.json();})
    .then(function(j){
      if(j.success){if(typeof gsToast!=='undefined')gsToast('Record saved!','success');else alert('Record saved!');setTimeout(function(){location.reload();},800);}
      else{alert((j.data&&j.data.message)||'Failed to save.');}
    })
    // Real fix — a network error previously gave no feedback at all.
    .catch(function(){
      alert('Network error — could not save this record. Please try again.');
    });
}
</script>
<?php get_footer(); ?>
