<?php
/**
 * GoodService — "About Us" page.
 * URL: /about-us/
 * Real feature — extends the same design system as the other marketing
 * pages built this session. Every number shown is a live query against
 * this platform's own data — no invented "founded in" story or fabricated
 * milestones, since this platform's own database is the only source of
 * truth available for this page.
 *
 * Deliberately does NOT include its own <!DOCTYPE>/<html>/<head> —
 * render_page() already provides that wrapper, matching the same
 * documented precedent as the other marketing pages.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

global $wpdb;
$pfx = $wpdb->prefix . 'gs_';

$total_vendors  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE is_active = 1" );
$total_listings = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}listings WHERE status = 'active'" );
$total_cities   = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT city) FROM {$pfx}listings WHERE status = 'active' AND city != ''" );
$total_reviews  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}reviews WHERE status = 'approved'" );

$platform     = function_exists('gs_setting') ? gs_setting('platform_name', get_bloginfo('name')) : get_bloginfo('name');
$logo_url     = function_exists('gs_setting') ? gs_setting('logo_url', '') : '';
$search_url   = home_url('/');
$register_url = home_url('/advertise/');
$howitworks_url = home_url('/how-it-works/');
$trust_url    = home_url('/trust-safety/');
$contact_url  = home_url('/contact-us/');
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Inter:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@500;600&display=swap');
*,*::before,*::after{box-sizing:border-box}
.ab-body{font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#14162B;background:#FBFAF7}
.ab-mono{font-family:'IBM Plex Mono',monospace}
.ab-wrap{max-width:1180px;margin:0 auto;padding:0 24px}
.ab-header{background:#FBFAF7;border-bottom:1px solid rgba(20,22,43,.08);position:sticky;top:0;z-index:50}
.ab-header-inner{display:flex;align-items:center;justify-content:space-between;padding:14px 0}
.ab-logo{display:flex;align-items:center;gap:10px;text-decoration:none;color:#14162B;font-weight:800;font-size:1.1rem;font-family:'Fraunces',serif}
.ab-logo img{height:32px;border-radius:6px}
.ab-header-links{display:flex;align-items:center;gap:28px}
.ab-header-links a{color:#14162B;text-decoration:none;font-size:.87rem;font-weight:600}
.ab-header-links a:not(.ab-header-cta):hover{color:#FF6B35}
.ab-header-cta{background:#14162B;color:#FBFAF7!important;padding:9px 20px;border-radius:8px;font-weight:700!important;transition:background .18s}
.ab-header-cta:hover{background:#FF6B35}
@media(max-width:820px){.ab-header-links a:not(.ab-header-cta){display:none}}

.ab-hero{padding:64px 0 40px;text-align:center}
.ab-eyebrow{display:inline-flex;align-items:center;gap:8px;font-family:'IBM Plex Mono',monospace;font-weight:600;font-size:.72rem;text-transform:uppercase;letter-spacing:.14em;margin-bottom:22px;padding:6px 14px 6px 10px;border:1px solid rgba(20,22,43,.14);border-radius:99px}
.ab-eyebrow-dot{width:6px;height:6px;border-radius:50%;background:#FF6B35}
.ab-hero h1{font-family:'Fraunces',serif;font-weight:600;font-size:2.9rem;line-height:1.1;letter-spacing:-.015em;margin-bottom:20px;color:#14162B;max-width:680px;margin-left:auto;margin-right:auto}
.ab-hero h1 em{font-style:normal;color:#FF6B35}
.ab-hero p{font-size:1.08rem;line-height:1.6;color:rgba(20,22,43,.65);max-width:540px;margin:0 auto}

/* Signature element — a large, live "by the numbers" display: for an
   About page, the platform's own real activity is the most honest thing
   to lead with, more distinctive than an invented founding story. */
.ab-numbers{padding:36px 0 88px}
.ab-numbers-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:2px;background:rgba(20,22,43,.1);border-radius:18px;overflow:hidden;max-width:920px;margin:0 auto}
@media(max-width:760px){.ab-numbers-grid{grid-template-columns:repeat(2,1fr)}}
.ab-num-cell{background:#fff;padding:36px 24px;text-align:center}
.ab-num-cell b{display:block;font-family:'Fraunces',serif;font-size:2.4rem;font-weight:600;color:#14162B;margin-bottom:6px}
.ab-num-cell span{font-size:.76rem;font-family:'IBM Plex Mono',monospace;text-transform:uppercase;letter-spacing:.07em;color:rgba(20,22,43,.5)}

.ab-section{padding:88px 0;background:#fff;border-top:1px solid rgba(20,22,43,.08)}
.ab-mission{display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center;max-width:1020px;margin:0 auto}
@media(max-width:880px){.ab-mission{grid-template-columns:1fr;gap:32px}}
.ab-mission h2{font-family:'Fraunces',serif;font-size:2rem;font-weight:600;color:#14162B;margin-bottom:18px;letter-spacing:-.01em}
.ab-mission p{font-size:1rem;line-height:1.75;color:rgba(20,22,43,.65);margin-bottom:16px}
.ab-mission-side{background:#FBFAF7;border:1px solid rgba(20,22,43,.08);border-radius:18px;padding:36px}
.ab-mission-side .ab-quote{font-family:'Fraunces',serif;font-size:1.3rem;line-height:1.5;color:#14162B;margin-bottom:14px}
.ab-mission-side .ab-quote-tag{font-family:'IBM Plex Mono',monospace;font-size:.74rem;color:rgba(20,22,43,.5);text-transform:uppercase;letter-spacing:.06em}

.ab-values{padding:88px 0}
.ab-section-head{max-width:600px;margin:0 auto 56px;text-align:center}
.ab-section-head h2{font-family:'Fraunces',serif;font-size:2.1rem;font-weight:600;color:#14162B;letter-spacing:-.01em}
.ab-values-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:28px}
@media(max-width:900px){.ab-values-grid{grid-template-columns:1fr}}
.ab-value{border:1px solid rgba(20,22,43,.08);border-radius:16px;padding:32px;background:#fff}
.ab-value h3{font-size:1.08rem;font-weight:700;margin-bottom:10px;color:#14162B}
.ab-value p{font-size:.89rem;line-height:1.65;color:rgba(20,22,43,.62)}

.ab-cta{padding:90px 0;text-align:center;background:#14162B;color:#FBFAF7}
.ab-cta h2{font-family:'Fraunces',serif;font-size:2.1rem;font-weight:600;margin-bottom:16px}
.ab-cta p{color:rgba(251,250,247,.65);margin-bottom:32px;font-size:1.02rem}
.ab-cta-ctas{display:flex;gap:14px;justify-content:center;flex-wrap:wrap}
.ab-btn-primary{background:#FF6B35;color:#14162B;padding:14px 26px;border-radius:9px;text-decoration:none;font-weight:700;font-size:.95rem;transition:transform .18s;display:inline-block}
.ab-btn-primary:hover{transform:translateY(-1px)}
.ab-btn-ghost{border:1.5px solid rgba(251,250,247,.35);color:#FBFAF7;padding:13px 24px;border-radius:9px;text-decoration:none;font-weight:700;font-size:.95rem;transition:border-color .18s}
.ab-btn-ghost:hover{border-color:#FBFAF7}

a.ab-header-cta:focus-visible,a.ab-btn-primary:focus-visible,a.ab-btn-ghost:focus-visible{outline:2px solid #FF6B35;outline-offset:2px}
</style>

<div class="ab-body">
  <header class="ab-header">
    <div class="ab-wrap ab-header-inner">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="ab-logo">
        <?php if ($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($platform); ?>"><?php else: echo esc_html($platform); endif; ?>
      </a>
      <nav class="ab-header-links">
        <a href="<?php echo esc_url($howitworks_url); ?>">How It Works</a>
        <a href="<?php echo esc_url($trust_url); ?>">Trust &amp; Safety</a>
        <a href="<?php echo esc_url($contact_url); ?>">Contact</a>
        <a href="<?php echo esc_url($search_url); ?>" class="ab-header-cta">Find a Pro →</a>
      </nav>
    </div>
  </header>

  <section class="ab-hero">
    <div class="ab-wrap">
      <div class="ab-eyebrow"><span class="ab-eyebrow-dot"></span>About <?php echo esc_html($platform); ?></div>
      <h1>Finding a good, reliable pro <em>shouldn't</em> take five phone calls and a leap of faith.</h1>
      <p>We built <?php echo esc_html($platform); ?> so you can see who you're hiring — real profiles, real reviews, real verification — before you ever make contact.</p>
    </div>
  </section>

  <?php if ( $total_vendors > 0 || $total_listings > 0 ): ?>
  <section class="ab-numbers">
    <div class="ab-wrap">
      <div class="ab-numbers-grid">
        <?php if ($total_vendors > 0): ?><div class="ab-num-cell"><b><?php echo esc_html(number_format($total_vendors)); ?>+</b><span>Verified Pros</span></div><?php endif; ?>
        <?php if ($total_listings > 0): ?><div class="ab-num-cell"><b><?php echo esc_html(number_format($total_listings)); ?>+</b><span>Active Listings</span></div><?php endif; ?>
        <?php if ($total_cities > 0): ?><div class="ab-num-cell"><b><?php echo esc_html(number_format($total_cities)); ?>+</b><span>Cities</span></div><?php endif; ?>
        <?php if ($total_reviews > 0): ?><div class="ab-num-cell"><b><?php echo esc_html(number_format($total_reviews)); ?>+</b><span>Real Reviews</span></div><?php endif; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <section class="ab-section">
    <div class="ab-wrap">
      <div class="ab-mission">
        <div>
          <h2>Why we exist</h2>
          <p>Most people don't hire a plumber, electrician, or photographer often enough to have one they already trust. So the search starts from zero, every single time — a search engine, a few calls, a lot of guessing.</p>
          <p><?php echo esc_html($platform); ?> exists to close that gap: real verification before you book, real reviews from real jobs, and a real process if something goes wrong — so choosing a pro takes minutes, not days.</p>
        </div>
        <div class="ab-mission-side">
          <div class="ab-quote">"Trust shouldn't be something you hope for — it should be something you can actually see, before you ever pick up the phone."</div>
          <div class="ab-quote-tag">What we build toward</div>
        </div>
      </div>
    </div>
  </section>

  <section class="ab-values">
    <div class="ab-wrap">
      <div class="ab-section-head">
        <h2>What we actually optimize for</h2>
      </div>
      <div class="ab-values-grid">
        <div class="ab-value">
          <h3>Real information, not marketing copy</h3>
          <p>Verification badges, review counts, and response times are computed from real activity on the platform — not written to sound good.</p>
        </div>
        <div class="ab-value">
          <h3>Pros who deserve the work</h3>
          <p>We built verification and review tools so a skilled, honest pro's reputation actually shows up — not just whoever paid for placement.</p>
        </div>
        <div class="ab-value">
          <h3>A real path when things go wrong</h3>
          <p>Bookings and disputes are handled by an actual process with a resolution window — not a support inbox that goes quiet.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="ab-cta">
    <div class="ab-wrap">
      <h2>See how it actually works</h2>
      <p>Browse real pros near you, or bring your own business onto the platform.</p>
      <div class="ab-cta-ctas">
        <a href="<?php echo esc_url($search_url); ?>" class="ab-btn-primary">Find a Pro Near You →</a>
        <a href="<?php echo esc_url($register_url); ?>" class="ab-btn-ghost">List Your Business</a>
      </div>
    </div>
  </section>

  <?php
  $df_site = $platform; $df_home = home_url('/');
  // Real bug fix (v7.475.7): these two links had a style="color:..." but no
  // hover state at all — unlike the homepage's rich footer (hf-links,
  // fixed v7.471.0), this bottom-bar footer never got the same treatment,
  // so hovering here produced literally no visual change. Same
  // onmouseover/onmouseout-to-brand-color pattern already used elsewhere
  // in this codebase (see home.php's city links) rather than adding a new
  // CSS block, since this footer has no <style> section of its own.
  $_ftr_primary = function_exists('gs_setting') ? gs_setting('platform_color_primary', '#2563EB') : '#2563EB';
  ?>
  <footer style="background:#14162B;color:rgba(251,250,247,.6);padding:32px 0;text-align:center;font-size:.78rem;font-family:'IBM Plex Mono',monospace">
    <div class="ab-wrap">© <?php echo esc_html( gmdate('Y') ); ?> <?php echo esc_html($df_site); ?>. All rights reserved. &nbsp;·&nbsp;
      <a href="<?php echo esc_url($df_home); ?>" style="color:rgba(251,250,247,.75);transition:color .15s" onmouseover="this.style.color='<?php echo esc_js($_ftr_primary); ?>'" onmouseout="this.style.color='rgba(251,250,247,.75)'">Home</a> &nbsp;·&nbsp;
      <a href="<?php echo esc_url($contact_url); ?>" style="color:rgba(251,250,247,.75);transition:color .15s" onmouseover="this.style.color='<?php echo esc_js($_ftr_primary); ?>'" onmouseout="this.style.color='rgba(251,250,247,.75)'">Contact</a>
    </div>
  </footer>
</div>
