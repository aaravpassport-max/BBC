<?php
/**
 * GoodService — Multi-Vendor Quote Comparison Page (Part 14.2)
 * URL: /compare-quotes/[group_uuid]/
 * Context: $group_uuid set by Router
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

global $wpdb;
$pfx      = $wpdb->prefix . 'gs_';
$group_uuid = sanitize_text_field( get_query_var( 'gs_quote_group', '' ) );

// Fetch the group
$group = $group_uuid ? $wpdb->get_row( $wpdb->prepare(
    "SELECT * FROM {$pfx}quote_groups WHERE group_uuid = %s", $group_uuid
) ) : null;

// Fetch the leads in this group with their vendor info and quotes
$group_leads = [];
if ( $group ) {
    $group_leads = $wpdb->get_results( $wpdb->prepare(
        "SELECT l.*, vp.business_name, vp.response_rate, vp.avg_reply_minutes, vp.trust_score,
                vp.avg_rating, li.logo_url AS vendor_logo, li.city AS vendor_city,
                q.total AS quote_total, q.line_items, q.cover_note, q.valid_until,
                q.payment_terms, q.quote_number, q.status AS quote_status, q.id AS quote_id,
                q.accept_token AS quote_token
         FROM {$pfx}leads l
         LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
         LEFT JOIN {$pfx}listings li ON li.id = l.listing_id
         LEFT JOIN {$pfx}quotations q ON q.lead_id = l.id AND q.status IN ('sent','accepted')
         WHERE l.quote_group_id = %s
         ORDER BY vp.trust_score DESC",
        $group_uuid
    ) ) ?: [];
}

$site = get_bloginfo( 'name' );
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Compare Quotes — <?php echo esc_html( $site ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( GS_URL . 'assets/css/goodservice.css?v=' . GS_VERSION ); ?>">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#F8FAFC;color:#1E293B;min-height:100vh}
.cq-header{background:linear-gradient(135deg,#1E3A5F,#2563EB);padding:16px 24px;display:flex;align-items:center;justify-content:space-between}
.cq-logo{color:#fff;font-weight:800;font-size:.95rem;text-decoration:none}
.cq-wrap{max-width:1140px;margin:0 auto;padding:24px 16px 60px}
.cq-hero{background:#fff;border-radius:14px;padding:24px;margin-bottom:24px;border:1px solid #E2E8F0}
.cq-hero-title{font-size:1.3rem;font-weight:800;color:#1E293B;margin-bottom:6px}
.cq-hero-sub{font-size:.88rem;color:#64748B}
.cq-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px}
.cq-card{background:#fff;border:2px solid #E2E8F0;border-radius:14px;overflow:hidden;transition:box-shadow .15s,border-color .15s}
.cq-card:hover{box-shadow:0 8px 28px rgba(0,0,0,.1)}
.cq-card.cq-best{border-color:#2563EB}
.cq-card-head{padding:18px;display:flex;align-items:center;gap:12px;border-bottom:1px solid #F1F5F9}
.cq-vendor-logo{width:44px;height:44px;border-radius:9px;object-fit:cover;background:#E2E8F0}
.cq-vendor-init{width:44px;height:44px;border-radius:9px;background:#2563EB;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1.1rem;flex-shrink:0}
.cq-vendor-name{font-weight:700;font-size:.92rem;color:#1E293B}
.cq-vendor-meta{font-size:.74rem;color:#64748B;margin-top:2px}
.cq-best-badge{background:#2563EB;color:#fff;font-size:.65rem;font-weight:700;padding:2px 8px;border-radius:10px;margin-left:auto;flex-shrink:0}
.cq-body{padding:18px}
.cq-no-quote{text-align:center;padding:24px;color:#94A3B8}
.cq-no-quote-icon{font-size:2rem;margin-bottom:8px}
.cq-no-quote-text{font-size:.84rem}
.cq-price{font-size:1.6rem;font-weight:900;color:#1E293B;margin-bottom:4px}
.cq-price-note{font-size:.74rem;color:#64748B}
.cq-items{margin:14px 0;display:flex;flex-direction:column;gap:6px}
.cq-item{display:flex;justify-content:space-between;font-size:.8rem;padding:6px 0;border-bottom:1px solid #F8FAFC}
.cq-item-desc{color:#475569;flex:1}
.cq-item-price{font-weight:700;color:#1E293B;margin-left:8px;white-space:nowrap}
.cq-cover{font-size:.82rem;color:#475569;line-height:1.6;margin-bottom:14px;padding:10px;background:#F8FAFC;border-radius:7px;border-left:3px solid #E2E8F0}
.cq-meta-row{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:14px}
.cq-meta-chip{font-size:.72rem;color:#64748B;display:flex;align-items:center;gap:4px}
.cq-trust{display:flex;gap:8px;margin-bottom:14px}
.cq-trust-pill{font-size:.68rem;font-weight:700;padding:2px 8px;border-radius:10px}
.cq-foot{padding:14px 18px;background:#F8FAFC;border-top:1px solid #F1F5F9;display:flex;flex-direction:column;gap:8px}
.cq-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:11px 18px;border-radius:9px;font-size:.86rem;font-weight:700;text-decoration:none;cursor:pointer;border:none;font-family:inherit;transition:all .15s;width:100%}
.cq-btn-primary{background:#059669;color:#fff}
.cq-btn-primary:hover{background:#047857}
.cq-btn-ghost{background:#F1F5F9;color:#1E293B}
.cq-status-decided{text-align:center;padding:16px;background:#F0FDF4;border-radius:8px;font-size:.84rem;color:#166534;font-weight:600}
.cq-waiting{text-align:center;padding:20px;color:#94A3B8;font-size:.82rem}
.cq-expire{font-size:.72rem;color:#D97706}
@media(max-width:640px){.cq-grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<header class="cq-header">
  <a href="<?php echo esc_url(home_url('/')); ?>" class="cq-logo"><?php echo esc_html($site); ?></a>
</header>

<div class="cq-wrap">

<?php if ( ! $group ): ?>
<div class="cq-hero" style="text-align:center;padding:48px">
  <div style="font-size:3rem;margin-bottom:12px">🔗</div>
  <div class="cq-hero-title">Invalid Link</div>
  <p class="cq-hero-sub" style="margin-top:8px">This quote comparison link appears to be invalid or has expired.</p>
  <a href="<?php echo esc_url(home_url('/')); ?>" style="display:inline-block;margin-top:16px;background:#2563EB;color:#fff;padding:10px 24px;border-radius:9px;text-decoration:none;font-weight:700">← Find Professionals</a>
</div>

<?php elseif ( $group->status === 'decided' ): ?>
<div class="cq-hero">
  <div class="cq-status-decided">✅ You have already accepted a quote for this request. Thank you!</div>
  <?php if ( is_user_logged_in() ): ?>
  <div style="text-align:center;margin-top:16px"><a href="<?php echo esc_url(home_url('/my-account/?section=bookings')); ?>" class="cq-btn cq-btn-primary" style="width:auto;display:inline-flex">View My Bookings →</a></div>
  <?php endif; ?>
</div>

<?php else: ?>
<div class="cq-hero">
  <div class="cq-hero-title">Compare Quotes for <?php echo esc_html( ucwords( str_replace('-', ' ', $group->category) ) ); ?></div>
  <div class="cq-hero-sub">
    <?php $waiting = count(array_filter($group_leads, fn($l) => !$l->quote_total)); ?>
    <?php $ready   = count($group_leads) - $waiting; ?>
    <?php if ($waiting > 0): ?>
    <?php echo $ready; ?> of <?php echo count($group_leads); ?> vendors have responded. <?php echo $waiting; ?> still preparing their quote.
    <?php else: ?>
    All vendors have submitted their quotes. Review and choose the best fit for you.
    <?php endif; ?>
  </div>
</div>

<div class="cq-grid">
<?php
// Mark best quote (lowest price among sent quotes)
$prices = array_filter(array_column($group_leads, 'quote_total'));
$best_price = $prices ? min($prices) : null;

foreach ( $group_leads as $lead ):
    $is_best = $best_price && $lead->quote_total == $best_price;
    $rr  = (float)($lead->response_rate ?? 0);
    $rat = (float)($lead->avg_rating ?? 0);
    $replied_mins = (int)($lead->avg_reply_minutes ?? 0);
    $reply_txt = $replied_mins > 0
        ? ($replied_mins < 60 ? "~{$replied_mins}m reply" : "~".round($replied_mins/60,1)."h reply")
        : '';
    $line_items = $lead->line_items ? json_decode($lead->line_items, true) : [];
    $days_left  = $lead->valid_until ? ceil((strtotime($lead->valid_until) - time()) / 86400) : null;
?>
<div class="cq-card<?php echo $is_best ? ' cq-best' : ''; ?>">
  <div class="cq-card-head">
    <?php if ($lead->vendor_logo): ?>
    <img src="<?php echo esc_url($lead->vendor_logo); ?>" class="cq-vendor-logo" alt="">
    <?php else: ?>
    <div class="cq-vendor-init"><?php echo strtoupper(substr($lead->business_name ?? 'V', 0, 1)); ?></div>
    <?php endif; ?>
    <div style="flex:1;min-width:0">
      <div class="cq-vendor-name"><?php echo esc_html($lead->business_name ?? 'Unknown Vendor'); ?></div>
      <div class="cq-vendor-meta">
        <?php if ($rat > 0): ?>★ <?php echo number_format($rat, 1); ?><?php endif; ?>
        <?php if ($rr > 0): ?> · <?php echo round($rr); ?>% reply rate<?php endif; ?>
        <?php if ($reply_txt): ?> · <?php echo esc_html($reply_txt); ?><?php endif; ?>
      </div>
    </div>
    <?php if ($is_best): ?><span class="cq-best-badge">Best Price</span><?php endif; ?>
  </div>

  <div class="cq-body">
    <?php if ( ! $lead->quote_total ): ?>
      <div class="cq-no-quote">
        <div class="cq-no-quote-icon">⏳</div>
        <div class="cq-no-quote-text"><?php echo esc_html($lead->business_name); ?> is preparing their quote…</div>
        <div class="cq-waiting" style="margin-top:8px">Check back shortly</div>
      </div>
    <?php else: ?>
      <div class="cq-price">₹<?php echo number_format((float)$lead->quote_total); ?></div>
      <?php if ($lead->payment_terms): ?>
      <div class="cq-price-note"><?php echo esc_html(str_replace('_', ' ', $lead->payment_terms)); ?></div>
      <?php endif; ?>

      <?php if ($lead->cover_note): ?>
      <div class="cq-cover" style="margin-top:12px"><?php echo nl2br(esc_html($lead->cover_note)); ?></div>
      <?php endif; ?>

      <?php if ($line_items): ?>
      <div class="cq-items">
        <?php foreach (array_slice($line_items, 0, 4) as $item): ?>
        <div class="cq-item">
          <span class="cq-item-desc"><?php echo esc_html($item['description'] ?? ''); ?> <?php if (($item['qty']??1)>1): ?><span style="color:#94A3B8">×<?php echo $item['qty']; ?></span><?php endif; ?></span>
          <span class="cq-item-price">₹<?php echo number_format((float)($item['total'] ?? $item['unit_price'] ?? 0)); ?></span>
        </div>
        <?php endforeach; ?>
        <?php if (count($line_items) > 4): ?>
        <div style="font-size:.72rem;color:#94A3B8;text-align:right">+<?php echo count($line_items)-4; ?> more items</div>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <div class="cq-meta-row">
        <?php if ($lead->quote_number): ?>
        <span class="cq-meta-chip">📋 <?php echo esc_html($lead->quote_number); ?></span>
        <?php endif; ?>
        <?php if ($days_left !== null && $days_left > 0): ?>
        <span class="cq-meta-chip cq-expire">⏰ Valid <?php echo $days_left; ?> more day<?php echo $days_left>1?'s':''; ?></span>
        <?php elseif ($days_left !== null && $days_left <= 0): ?>
        <span class="cq-meta-chip" style="color:#DC2626">❌ Expired</span>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>

  <?php if ($lead->quote_total && $lead->quote_status === 'sent' && $group->status === 'open'): ?>
  <div class="cq-foot">
    <?php if ($lead->quote_token): ?>
    <a href="<?php echo esc_url(home_url('/quote/accept/' . $lead->quote_token . '/')); ?>"
       class="cq-btn cq-btn-primary">✅ Accept this Quote</a>
    <?php endif; ?>
    <button class="cq-btn cq-btn-ghost" onclick="cqRequestChanges('<?php echo esc_js($lead->quote_id); ?>', '<?php echo esc_js($lead->business_name); ?>')">
      💬 Request Changes
    </button>
  </div>
  <?php elseif ($lead->quote_status === 'accepted'): ?>
  <div class="cq-foot">
    <div style="text-align:center;color:#059669;font-weight:700;font-size:.88rem;padding:8px">✅ You selected this vendor</div>
  </div>
  <?php endif; ?>
</div>
<?php endforeach; ?>
</div>

<!-- Request changes modal -->
<div id="cq-changes-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:14px;padding:24px;width:min(460px,95vw)">
    <div style="font-weight:700;font-size:1rem;color:#1E293B;margin-bottom:12px">Request Changes to Quote</div>
    <div style="font-size:.84rem;color:#64748B;margin-bottom:10px" id="cq-changes-vendor">From: </div>
    <textarea id="cq-changes-text" style="width:100%;padding:10px;border:1.5px solid #E2E8F0;border-radius:8px;font-size:.84rem;min-height:100px;resize:vertical;font-family:inherit;outline:none" placeholder="Describe what changes you'd like to the quote..."></textarea>
    <div style="display:flex;gap:10px;margin-top:12px;justify-content:flex-end">
      <button onclick="document.getElementById('cq-changes-modal').style.display='none'" style="padding:9px 18px;border-radius:8px;border:1.5px solid #E2E8F0;background:#fff;cursor:pointer;font-family:inherit">Cancel</button>
      <button onclick="cqSubmitChanges()" style="padding:9px 18px;border-radius:8px;background:#2563EB;color:#fff;border:none;cursor:pointer;font-family:inherit;font-weight:700">Send Request</button>
    </div>
  </div>
</div>

<script>
var _cqQuoteId = null;
function cqRequestChanges(quoteId, vendorName) {
  _cqQuoteId = quoteId;
  document.getElementById('cq-changes-vendor').textContent = 'Quote from: ' + vendorName;
  document.getElementById('cq-changes-text').value = '';
  document.getElementById('cq-changes-modal').style.display = 'flex';
}
function cqSubmitChanges() {
  var msg = document.getElementById('cq-changes-text').value.trim();
  if (!msg) { alert('Please describe the changes you need.'); return; }
  var fd = new FormData();
  fd.append('action', 'gs_request_quote_changes');
  fd.append('nonce', '<?php echo wp_create_nonce('gs_ajax'); ?>');
  fd.append('quote_id', _cqQuoteId);
  fd.append('message', msg);
  fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', { method:'POST', body:fd })
    .then(r => r.json()).then(d => {
      // Real fix — ghost success: this previously closed the modal and
      // told the customer "Request sent!" unconditionally, even when
      // d.success was false (e.g. quote not found, already accepted) —
      // the vendor would never actually receive the change request.
      if (!d.success) {
        alert((d.data && d.data.message) || 'Could not send your request. Please try again.');
        return;
      }
      document.getElementById('cq-changes-modal').style.display = 'none';
      alert('Request sent! The vendor will update their quote shortly.');
    })
    .catch(function(){
      alert('Network error — could not send your request. Please try again.');
    });
}
</script>

<?php endif; ?>
</div>

<?php get_footer(); ?>
