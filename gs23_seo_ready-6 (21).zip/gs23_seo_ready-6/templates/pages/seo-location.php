<?php
/**
 * GoodService — Programmatic SEO Location Pages (Part 26.1)
 * URL: /service/[category]/[city]/  e.g. /service/plumbers/bangalore/
 * Context vars supplied by Router: $category_slug, $city (real name), $city_slug
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

global $wpdb;
$pfx           = $wpdb->prefix . 'gs_';
$category_slug = sanitize_key( $category_slug ?? get_query_var( 'gs_cat_slug', '' ) );
// $city is now the real display name (e.g. "New Delhi") resolved by the Router.
// $city_slug is the URL form (e.g. "new-delhi") — used for canonical URLs only.
$city      = sanitize_text_field( $city ?? get_query_var( 'gs_city', '' ) );
$city_slug = sanitize_title( $city_slug ?? $city );

if ( ! $category_slug || ! $city ) { wp_redirect( home_url( '/directory/' ) ); exit; }

// Fetch category info
$category = $wpdb->get_row( $wpdb->prepare(
    "SELECT * FROM {$pfx}categories WHERE slug=%s AND is_active=1 LIMIT 1", $category_slug
) );
if ( ! $category ) { wp_redirect( home_url( '/directory/' ) ); exit; }

$category_name = $category_name ?? $category->name;

// Top 10 vendors in this category + city, sorted by trust score
$vendors = $wpdb->get_results( $wpdb->prepare(
    "SELECT li.id, li.slug, li.title, li.tagline, li.logo_url, li.avg_rating, li.review_count, li.is_verified,
            vp.response_rate, vp.avg_reply_minutes, vp.trust_score, vp.total_jobs_done,
            vp.neighbourhood_count, vp.neighbourhood_area, vp.avg_rating AS vp_rating
     FROM {$pfx}listings li
     LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = li.vendor_id
     WHERE li.status='active'
       AND li.category_id = %d
       AND (li.city=%s OR li.area=%s OR li.locations_served LIKE %s)
     ORDER BY vp.trust_score DESC, li.avg_rating DESC, li.is_featured DESC
     LIMIT 10",
    (int) $category->id, $city, $city, '%' . $wpdb->esc_like($city) . '%'
) ) ?: [];

$vendor_count = count( $vendors );

// Thin-content guard — redirect to directory if fewer than 3 vendors.
// This prevents indexing empty or near-empty pages that have no real value.
if ( $vendor_count < 3 ) {
    wp_redirect( home_url( '/directory/?category=' . urlencode( $category_slug ) . '&city=' . urlencode( $city ) ), 302 );
    exit;
}

// Average cost from closed inquiries in this category + city
$avg_cost = (float) $wpdb->get_var( $wpdb->prepare(
    "SELECT AVG(l.budget) FROM {$pfx}leads l
     WHERE l.inquiry_module = %s AND l.city = %s AND l.budget > 0
     AND l.status IN('converted','closed') AND l.created_at > DATE_SUB(NOW(),INTERVAL 90 DAY)",
    $category_slug, $city
) );

// Recent reviews from this city
$recent_reviews = $wpdb->get_results( $wpdb->prepare(
    "SELECT r.reviewer_name, r.rating, r.review_text, r.created_at, li.title AS listing_title
     FROM {$pfx}reviews r
     JOIN {$pfx}listings li ON li.id = r.listing_id
     WHERE r.status='approved' AND li.city=%s AND li.category_id=%d
     ORDER BY r.created_at DESC LIMIT 5",
    $city, (int) $category->id
) ) ?: [];

// Try to read stored h1_text and meta_desc from gs_seo_location_pages —
// the cron populates these monthly. Fall back to inline generation when
// the row doesn't exist yet.
$_seo_loc_row = null;
$_seo_loc_tbl = $wpdb->prefix . 'gs_seo_location_pages';
if ( $wpdb->get_var( "SHOW TABLES LIKE '{$_seo_loc_tbl}'" ) ) {
    $_seo_loc_row = $wpdb->get_row( $wpdb->prepare(
        "SELECT h1_text, meta_desc FROM {$_seo_loc_tbl} WHERE category_slug = %s AND city = %s LIMIT 1",
        $category_slug, $city
    ) );
}

// Page meta — use stored values when available, fall back to inline generation
$page_title = "Trusted {$category_name} in {$city} — Get Free Quotes";
$meta_desc  = ! empty( $_seo_loc_row->meta_desc )
    ? $_seo_loc_row->meta_desc
    : "Find verified {$category_name} professionals in {$city}. Compare quotes, see reviews, book instantly. {$vendor_count} vendors available.";
$h1_text    = ! empty( $_seo_loc_row->h1_text )
    ? $_seo_loc_row->h1_text
    : "Trusted {$category_name} in {$city}";

// FAQ data for this page
$faqs = [
    [ "How do I find a good {$category_name} in {$city}?",
      "Browse verified {$category_name} professionals on GoodService, compare their ratings and response rates, then send a free inquiry to get quotes." ],
    [ "What is the average cost of a {$category_name} in {$city}?",
      $avg_cost > 0
        ? "Based on recent bookings, the average cost for {$category_name} services in {$city} is approximately ₹" . number_format($avg_cost) . ". Prices vary based on scope and urgency."
        : "Costs vary depending on the type of work. Send a free inquiry to get accurate quotes from local professionals." ],
    [ "Are the {$category_name} professionals on GoodService verified?",
      "Yes. All professionals are verified with identity checks, business credentials, and customer reviews. Many hold GST registration and trade licences." ],
    [ "How quickly will a {$category_name} reply to my inquiry?",
      "Most professionals in {$city} reply within 1–2 hours. You'll receive a WhatsApp or email notification as soon as they respond." ],
    [ "Can I compare quotes from multiple {$category_name} professionals in {$city}?",
      "Yes! Use the 'Get quotes from multiple vendors' option on the search results page to receive quotes from up to 3 verified professionals at once." ],
];

get_header(); ?>
<style>
.sl-wrap{max-width:1100px;margin:0 auto;padding:28px 16px 60px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
.sl-hero{background:linear-gradient(135deg,#1E3A5F,#2563EB);color:#fff;padding:32px 28px;border-radius:14px;margin-bottom:28px}
.sl-h1{font-size:1.6rem;font-weight:900;margin:0 0 8px;line-height:1.3}
.sl-meta{font-size:.84rem;opacity:.82;margin-bottom:20px}
.sl-search-link{display:inline-flex;align-items:center;gap:8px;background:#fff;color:#1E3A5F;padding:11px 22px;border-radius:10px;font-weight:800;text-decoration:none;font-size:.9rem}
.sl-section-title{font-size:1.1rem;font-weight:800;color:#1E293B;margin:28px 0 14px}
.sl-vendor-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:14px;margin-bottom:28px}
.sl-vcard{background:#fff;border:1px solid #E2E8F0;border-radius:12px;padding:16px;display:flex;gap:12px;align-items:flex-start;text-decoration:none;color:inherit;transition:box-shadow .15s,border-color .15s}
.sl-vcard:hover{box-shadow:0 4px 20px rgba(0,0,0,.1);border-color:#BFDBFE}
.sl-vlogo{width:48px;height:48px;border-radius:10px;object-fit:cover;background:#EFF6FF;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1.1rem;color:#2563EB}
.sl-vname{font-weight:700;font-size:.9rem;color:#1E293B;margin-bottom:3px}
.sl-vmeta{font-size:.74rem;color:#64748B;line-height:1.5}
.sl-vpill{display:inline-flex;align-items:center;gap:3px;font-size:.64rem;font-weight:700;padding:2px 7px;border-radius:8px;margin-right:4px}
.sl-avg-cost{background:linear-gradient(135deg,#FFFBEB,#FEF3C7);border:1px solid #FDE68A;border-radius:12px;padding:20px;margin-bottom:28px;text-align:center}
.sl-rev-card{background:#fff;border:1px solid #E2E8F0;border-radius:10px;padding:14px 16px;margin-bottom:10px}
.sl-faq{margin-bottom:28px}
.sl-faq-item{border:1px solid #E2E8F0;border-radius:10px;overflow:hidden;margin-bottom:8px}
.sl-faq-q{padding:14px 16px;font-weight:700;font-size:.88rem;cursor:pointer;background:#F8FAFC;display:flex;justify-content:space-between;align-items:center}
.sl-faq-a{padding:12px 16px;font-size:.84rem;color:#475569;line-height:1.6;display:none}
.sl-cta{background:linear-gradient(135deg,#2563EB,#1D4ED8);color:#fff;padding:28px;border-radius:14px;text-align:center;margin-top:28px}
</style>

<div class="sl-wrap">
  <?php
  // Real fix, item A from the follow-up audit: a genuine, visible
  // breadcrumb trail — this page previously emitted BreadcrumbList schema
  // with no matching visible element at all, built from the same,
  // now-corrected trail data as the JSON-LD schema further down.
  ?>
  <nav class="vs-breadcrumb" aria-label="Breadcrumb" style="margin-bottom:16px;font-size:.82rem">
    <ol class="vs-breadcrumb-list" style="list-style:none;display:flex;flex-wrap:wrap;gap:6px;padding:0;margin:0">
      <li class="vs-breadcrumb-item"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a><span aria-hidden="true"> › </span></li>
      <li class="vs-breadcrumb-item"><a href="<?php echo esc_url( home_url( '/directory/' ) ); ?>">Directory</a><span aria-hidden="true"> › </span></li>
      <li class="vs-breadcrumb-item"><a href="<?php echo esc_url( home_url( '/directory/?category=' . urlencode( $category_slug ) ) ); ?>"><?php echo esc_html( $category_name ); ?></a><span aria-hidden="true"> › </span></li>
      <li class="vs-breadcrumb-item"><span aria-current="page"><?php echo esc_html( $category_name . ' in ' . $city ); ?></span></li>
    </ol>
  </nav>
  <!-- Hero -->
  <div class="sl-hero">
    <h1 class="sl-h1"><?php echo esc_html($h1_text); ?></h1>
    <p class="sl-meta">
      <?php echo $vendor_count; ?> verified professional<?php echo $vendor_count!==1?'s':''; ?> available in <?php echo esc_html($city); ?>
      · Free quotes · No commitment
    </p>
    <a href="<?php echo esc_url(home_url('/directory/?category='.$category_slug.'&city='.urlencode($city))); ?>" class="sl-search-link">
      🔍 Browse All <?php echo esc_html($category_name); ?> in <?php echo esc_html($city); ?> →
    </a>
  </div>

  <!-- Average cost section -->
  <?php if ($avg_cost > 0): ?>
  <div class="sl-avg-cost">
    <div style="font-size:.72rem;font-weight:700;color:#B45309;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px">PRICE GUIDE</div>
    <div style="font-size:1.6rem;font-weight:900;color:#92400E">₹<?php echo number_format($avg_cost, 0); ?></div>
    <div style="font-size:.82rem;color:#B45309;margin-top:4px">Average <?php echo esc_html($category_name); ?> cost in <?php echo esc_html($city); ?> (based on last 90 days)</div>
    <div style="font-size:.74rem;color:#D97706;margin-top:6px">Actual cost varies · Get free quotes to compare</div>
  </div>
  <?php endif; ?>

  <?php
  // Real feature, priority 5 (content depth): genuine, data-driven prose
  // — not generic template filler. Built from the actual vendors, ratings,
  // and cost data already queried on this specific page, with real
  // conditional branches so two different city/category combinations
  // produce genuinely different sentences, not the same paragraph with
  // two words swapped. Directly addresses the real thin-content risk this
  // exact programmatic-SEO pattern is known to carry at scale.
  $_verified_count = count( array_filter( $vendors, fn( $v ) => ! empty( $v->is_verified ) ) );
  $_top_rated = null;
  $_best_rating = 0;
  foreach ( $vendors as $v ) {
    if ( (float) ( $v->avg_rating ?? 0 ) > $_best_rating && (int) ( $v->review_count ?? 0 ) >= 3 ) {
      $_best_rating = (float) $v->avg_rating;
      $_top_rated = $v;
    }
  }
  ?>
  <div class="sl-about-section" style="margin:28px 0;padding:20px 0;border-top:1px solid #E5E7EB;font-size:.92rem;line-height:1.75;color:#374151">
    <h2 style="font-size:1.1rem;font-weight:800;margin-bottom:12px">Finding <?php echo esc_html( $category_name ); ?> Services in <?php echo esc_html( $city ); ?></h2>
    <p>
      <?php echo esc_html( $city ); ?> currently has <?php echo $vendor_count; ?> verified <?php echo esc_html( strtolower( $category_name ) ); ?>
      professional<?php echo $vendor_count !== 1 ? 's' : ''; ?> listed on <?php echo esc_html( $platform ?? get_bloginfo( 'name' ) ); ?>,
      <?php if ( $_verified_count > 0 ): ?>
        with <?php echo $_verified_count; ?> having completed identity and business verification.
      <?php else: ?>
        each reviewed before being listed.
      <?php endif; ?>
      <?php if ( $_top_rated ): ?>
        <?php echo esc_html( $_top_rated->title ); ?> currently holds the highest rating in this category locally, at <?php echo number_format( $_best_rating, 1 ); ?> out of 5<?php echo ( (int) $_top_rated->review_count > 0 ) ? ' from ' . (int) $_top_rated->review_count . ' review' . ( (int) $_top_rated->review_count !== 1 ? 's' : '' ) : ''; ?>.
      <?php endif; ?>
    </p>
    <p>
      <?php if ( $avg_cost > 0 ): ?>
        Based on recent bookings in <?php echo esc_html( $city ); ?>, <?php echo esc_html( strtolower( $category_name ) ); ?> services typically cost around ₹<?php echo number_format( $avg_cost ); ?>, though the final price depends on the specific job — always compare a few quotes before committing.
      <?php else: ?>
        Pricing for <?php echo esc_html( strtolower( $category_name ) ); ?> work in <?php echo esc_html( $city ); ?> varies by scope and urgency — request free quotes from a few listed professionals to compare before deciding.
      <?php endif; ?>
      All enquiries made through this page go directly to the vendor, with no booking fee or commission added on top.
    </p>
  </div>

  <!-- Top vendors -->
  <?php if ($vendors): ?>
  <div class="sl-section-title">Top <?php echo esc_html($category_name); ?> in <?php echo esc_html($city); ?></div>
  <div class="sl-vendor-grid">
    <?php foreach ($vendors as $i => $v):
      $lurl = home_url('/' . ltrim($v->slug, '/') . '/');
      $rr   = (float)($v->response_rate ?? 0);
      $rt   = (int)($v->avg_reply_minutes ?? 0);
      $rt_txt = $rt > 0 ? ($rt < 60 ? "~{$rt}m reply" : "~".round($rt/60,1)."h reply") : '';
    ?>
    <a href="<?php echo esc_url($lurl); ?>" class="sl-vcard">
      <?php if ($v->logo_url): ?>
      <img src="<?php echo esc_url($v->logo_url); ?>" alt="<?php echo esc_attr($v->title); ?>" class="sl-vlogo" width="48" height="48">
      <?php else: ?>
      <div class="sl-vlogo"><?php echo strtoupper(substr($v->title, 0, 1)); ?></div>
      <?php endif; ?>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:2px">
          <?php if($i===0): ?><span style="font-size:.6rem;background:#2563EB;color:#fff;padding:1px 6px;border-radius:8px;font-weight:700">#1</span><?php endif; ?>
          <div class="sl-vname"><?php echo esc_html($v->title); ?></div>
        </div>
        <div class="sl-vmeta">
          <?php if ($v->avg_rating > 0): ?>⭐ <?php echo number_format($v->avg_rating, 1); ?> · <?php endif; ?>
          <?php if ($v->review_count > 0): ?><?php echo $v->review_count; ?> reviews<?php if($rr>0||$rt_txt) echo ' · '; endif; ?>
          <?php if ($rr >= 80): ?><span class="sl-vpill" style="background:#F0FDF4;color:#059669">⚡ <?php echo round($rr); ?>% reply rate</span><?php endif; ?>
          <?php if ($rt_txt): ?><?php echo esc_html($rt_txt); ?><?php endif; ?>
          <?php if ($v->total_jobs_done > 5): ?> · <?php echo $v->total_jobs_done; ?>+ jobs<?php endif; ?>
        </div>
        <?php if ($v->tagline): ?><div style="font-size:.74rem;color:#64748B;margin-top:3px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html($v->tagline); ?></div><?php endif; ?>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <!-- Recent reviews -->
  <?php if ($recent_reviews): ?>
  <div class="sl-section-title">Recent Reviews in <?php echo esc_html($city); ?></div>
  <?php foreach ($recent_reviews as $rev): ?>
  <div class="sl-rev-card">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
      <div style="width:32px;height:32px;border-radius:50%;background:#EFF6FF;display:flex;align-items:center;justify-content:center;font-weight:800;color:#2563EB;font-size:.84rem;flex-shrink:0"><?php echo strtoupper(substr($rev->reviewer_name??'?',0,1)); ?></div>
      <div>
        <div style="font-weight:600;font-size:.84rem"><?php echo esc_html($rev->reviewer_name??'Customer'); ?></div>
        <div style="font-size:.7rem;color:#94A3B8"><?php echo esc_html($rev->listing_title??''); ?> · <?php echo date('d M Y', strtotime($rev->created_at??'now')); ?></div>
      </div>
      <div style="margin-left:auto;color:#F59E0B;font-size:.9rem"><?php echo str_repeat('★', (int)$rev->rating); ?></div>
    </div>
    <?php if ($rev->review_text): ?><div style="font-size:.82rem;color:#475569;line-height:1.5"><?php echo esc_html(substr($rev->review_text, 0, 200)); ?><?php echo strlen($rev->review_text)>200?'…':''; ?></div><?php endif; ?>
  </div>
  <?php endforeach; ?>
  <?php endif; ?>

  <!-- FAQ section -->
  <div class="sl-faq">
    <div class="sl-section-title">How to find a good <?php echo esc_html($category_name); ?> in <?php echo esc_html($city); ?></div>
    <?php foreach ($faqs as $i => $faq): ?>
    <div class="sl-faq-item">
      <div class="sl-faq-q" onclick="slToggleFaq(<?php echo $i; ?>)">
        <span><?php echo esc_html($faq[0]); ?></span>
        <span id="sl-faq-arrow-<?php echo $i; ?>">+</span>
      </div>
      <div id="sl-faq-ans-<?php echo $i; ?>" class="sl-faq-a"><?php echo esc_html($faq[1]); ?></div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- CTA -->
  <div class="sl-cta">
    <div style="font-size:1.1rem;font-weight:800;margin-bottom:8px">Get Free Quotes from <?php echo esc_html($category_name); ?> in <?php echo esc_html($city); ?></div>
    <div style="font-size:.84rem;opacity:.85;margin-bottom:18px">Send one inquiry — receive quotes from up to 3 verified professionals</div>
    <a href="<?php echo esc_url(home_url('/directory/?category='.$category_slug.'&city='.urlencode($city))); ?>"
       style="background:#fff;color:#1E3A5F;padding:13px 28px;border-radius:10px;font-weight:800;text-decoration:none;font-size:.9rem">
      Find <?php echo esc_html($category_name); ?> Now →
    </a>
  </div>
</div>

<!-- FAQPage JSON-LD for SEO (Part 21.3 / 26.1) -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    <?php foreach ($faqs as $i => $faq): ?>
    <?php echo $i > 0 ? ',' : ''; ?>
    {
      "@type": "Question",
      "name": <?php echo wp_json_encode($faq[0]); ?>,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": <?php echo wp_json_encode($faq[1]); ?>
      }
    }
    <?php endforeach; ?>
  ]
}
</script>

<!-- LocalBusiness JSON-LD for the page -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": <?php echo wp_json_encode($page_title); ?>,
  "description": <?php echo wp_json_encode($meta_desc); ?>,
  "url": <?php echo wp_json_encode(home_url('/service/' . $category_slug . '/' . $city_slug . '/')); ?>,
  "breadcrumb": {
    "@type": "BreadcrumbList",
    "itemListElement": [
      {"@type":"ListItem","position":1,"name":"Home","item":<?php echo wp_json_encode(home_url('/')); ?>},
      {"@type":"ListItem","position":2,"name":"Directory","item":<?php echo wp_json_encode(home_url('/directory/')); ?>},
      {"@type":"ListItem","position":3,"name":<?php echo wp_json_encode($category_name); ?>,"item":<?php echo wp_json_encode(home_url('/directory/?category=' . urlencode($category_slug))); ?>},
      {"@type":"ListItem","position":4,"name":<?php echo wp_json_encode($category_name.' in '.$city); ?>,"item":<?php echo wp_json_encode(home_url('/service/' . $category_slug . '/' . $city_slug . '/')); ?>}
    ]
  }
}
</script>

<script>
function slToggleFaq(i) {
  var ans   = document.getElementById('sl-faq-ans-'+i);
  var arrow = document.getElementById('sl-faq-arrow-'+i);
  var open  = ans.style.display === 'block';
  ans.style.display   = open ? 'none' : 'block';
  arrow.textContent   = open ? '+' : '−';
}
</script>

<?php get_footer(); ?>
