<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( is_user_logged_in() ) {
    $dest = function_exists('gs_login_redirect') ? gs_login_redirect() : (gs_is_admin_level() ? home_url('/admin-panel/') : home_url('/vendor/dashboard/'));
    wp_redirect( $dest ); exit;
}
$platform = gs_setting('platform_name', 'GoodService');
$color    = gs_setting('platform_color_primary', '#2563EB');
$logo_url = gs_setting('logo_url', '');
$ajax_url = admin_url('admin-ajax.php');
$nonce    = wp_create_nonce('gs_ajax');
?>
<style>
.gsauth-wrap{min-height:100vh;background:linear-gradient(135deg,#F0F9FF,#EFF6FF);display:flex;align-items:center;justify-content:center;padding:20px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif}
.gsauth-box{width:100%;max-width:440px}
.gsauth-logo{text-align:center;margin-bottom:28px}
.gsauth-logo img{height:52px;margin:0 auto 12px;display:block;border-radius:8px}
.gsauth-logo h1{font-size:1.45rem;font-weight:800;color:#1E3A5F;margin:0}
.gsauth-logo p{color:#64748B;margin:5px 0 0;font-size:.88rem}
.gsauth-card{background:#fff;border-radius:18px;box-shadow:0 10px 40px rgba(0,0,0,.1);padding:36px}
.gsauth-tabs{display:flex;background:#F1F5F9;border-radius:10px;padding:4px;margin-bottom:28px;gap:4px}
.gsauth-tab{flex:1;padding:10px;border:none;border-radius:8px;font-weight:700;font-size:.88rem;cursor:pointer;background:transparent;color:#64748B;transition:all .2s;font-family:inherit}
.gsauth-tab.active{background:#fff;color:#1E3A5F;box-shadow:0 1px 4px rgba(0,0,0,.1)}
.gsauth-err,.gsauth-ok{display:none;padding:12px 14px;border-radius:8px;font-size:.84rem;margin-bottom:16px;border-left:4px solid}
.gsauth-err{background:#FEF2F2;color:#DC2626;border-color:#DC2626}
.gsauth-ok{background:#F0FDF4;color:#059669;border-color:#059669}
.gsauth-label{display:block;font-size:.8rem;font-weight:600;color:#475569;margin-bottom:6px}
.gsauth-field-wrap{position:relative;margin-bottom:16px}
.gsauth-input{display:block;width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:8px;font-size:.93rem;color:#1E293B;background:#fff;font-family:inherit;outline:none;transition:border-color .18s,box-shadow .18s;box-sizing:border-box}
.gsauth-input:focus{border-color:<?php echo esc_attr($color); ?>;box-shadow:0 0 0 3px <?php echo esc_attr($color); ?>22}
.gsauth-input::placeholder{color:#94A3B8}
.gsauth-pw-toggle{position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:1rem;color:#94A3B8;padding:2px}
.gsauth-btn{display:block;width:100%;padding:12px;border:none;border-radius:9px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;transition:all .18s;text-align:center}
.gsauth-btn-primary{background:<?php echo esc_attr($color); ?>;color:#fff}
.gsauth-btn-primary:hover{filter:brightness(1.08)}
.gsauth-btn-primary:disabled{opacity:.65;cursor:not-allowed}
.gsauth-forgot{text-align:center;margin-top:14px}
.gsauth-forgot a{font-size:.8rem;color:#64748B;text-decoration:none}
.gsauth-forgot a:hover{color:<?php echo esc_attr($color); ?>}
.gsauth-back{text-align:center;margin-top:20px;font-size:.82rem}
.gsauth-back a{color:#64748B;text-decoration:none}
.gsauth-strength{height:4px;background:#E2E8F0;border-radius:2px;margin-top:7px;overflow:hidden}
.gsauth-strength-bar{height:100%;width:0%;border-radius:2px;transition:width .3s,background .3s}
.gsauth-terms{display:flex;gap:10px;align-items:flex-start;font-size:.82rem;color:#475569;padding:12px 14px;background:#F0F9FF;border-radius:8px;border:1px solid #BAE6FD;margin-bottom:20px;cursor:pointer}
</style>

<div class="gsauth-wrap">
  <div class="gsauth-box">

    <!-- Logo -->
    <div class="gsauth-logo">
      <?php if($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($platform); ?>"><?php endif; ?>
      <h1><?php echo esc_html($platform); ?></h1>
      <p><?php echo ( sanitize_key( $_GET['role'] ?? '' ) === 'admin' ) ? 'Administrator sign-in' : 'Sign in to your account'; ?></p>
    </div>

    <!-- Card -->
    <div class="gsauth-card">

      <!-- Tabs -->
      <div class="gsauth-tabs">
        <button class="gsauth-tab active" id="tab-login" onclick="gsTab('login')">Sign In</button>
        <button class="gsauth-tab" id="tab-register" onclick="gsTab('register')">Create Account</button>
      </div>

      <!-- ── LOGIN PANEL ── -->
      <div id="panel-login">
        <div id="login-err" class="gsauth-err"></div>

        <div class="gsauth-field-wrap" style="margin-bottom:16px">
          <label class="gsauth-label" for="gs-login-id">Email Address or Username</label>
          <input type="text" id="gs-login-id" class="gsauth-input"
            placeholder="your@email.com or username"
            autocomplete="username" autocapitalize="none" spellcheck="false">
        </div>

        <div class="gsauth-field-wrap" style="margin-bottom:22px">
          <label class="gsauth-label" for="gs-login-pass">Password</label>
          <input type="password" id="gs-login-pass" class="gsauth-input"
            placeholder="Enter your password"
            autocomplete="current-password" style="padding-right:44px">
          <button class="gsauth-pw-toggle" onclick="gsPwToggle('gs-login-pass')" type="button" tabindex="-1" aria-label="Toggle password visibility">👁</button>
        </div>

        <button class="gsauth-btn gsauth-btn-primary" id="login-btn" onclick="gsLogin()">
          Sign In
        </button>

        <div class="gsauth-forgot">
          <a href="<?php echo esc_url(home_url('/forgot-password/')); ?>">Forgot password?</a>
        </div>
      </div>

      <!-- ── 2FA CHALLENGE PANEL — real feature, hidden until vendorLogin() ── -->
      <!-- ── returns needs_2fa:true ──────────────────────────────────────── -->
      <div id="panel-2fa" style="display:none">
        <div id="tfa-err" class="gsauth-err"></div>
        <p style="font-size:.85rem;color:#64748B;margin-bottom:18px">Enter the 6-digit verification code sent to your registered phone. It expires in 5 minutes.</p>
        <input type="hidden" id="gs-2fa-token">
        <div class="gsauth-field-wrap" style="margin-bottom:22px">
          <label class="gsauth-label" for="gs-2fa-code">Verification Code</label>
          <input type="text" id="gs-2fa-code" class="gsauth-input" inputmode="numeric" pattern="[0-9]*" maxlength="6"
            placeholder="000000" autocomplete="one-time-code" style="letter-spacing:.3em;font-size:1.2rem;text-align:center">
        </div>
        <button class="gsauth-btn gsauth-btn-primary" id="tfa-btn" onclick="gsVerify2fa()">Verify &amp; Sign In</button>
        <div class="gsauth-forgot">
          <a href="#" onclick="gs2faBack();return false;">← Back to sign in</a>
        </div>
      </div>

      <!-- ── REGISTER PANEL ── -->
      <div id="panel-register" style="display:none">
        <div id="reg-err" class="gsauth-err"></div>
        <div id="reg-ok"  class="gsauth-ok"></div>

        <div class="gsauth-field-wrap" style="margin-bottom:14px">
          <label class="gsauth-label" for="gs-reg-name">Full Name <span style="color:#DC2626">*</span></label>
          <input type="text" id="gs-reg-name" class="gsauth-input"
            placeholder="Your full name" autocomplete="name">
        </div>

        <div class="gsauth-field-wrap" style="margin-bottom:14px">
          <label class="gsauth-label" for="gs-reg-email">Email Address <span style="color:#DC2626">*</span></label>
          <input type="email" id="gs-reg-email" class="gsauth-input"
            placeholder="your@email.com" autocomplete="email">
        </div>

        <div class="gsauth-field-wrap" style="margin-bottom:14px">
          <label class="gsauth-label" for="gs-reg-phone">Phone Number <span style="color:#DC2626">*</span></label>
          <input type="tel" id="gs-reg-phone" class="gsauth-input"
            placeholder="10-digit mobile number" autocomplete="tel">
        </div>

        <div class="gsauth-field-wrap" style="margin-bottom:20px">
          <label class="gsauth-label" for="gs-reg-pass">Password <span style="color:#DC2626">*</span></label>
          <input type="password" id="gs-reg-pass" class="gsauth-input"
            placeholder="Min 8 characters"
            autocomplete="new-password" style="padding-right:44px"
            oninput="gsPassStrength(this.value)">
          <button class="gsauth-pw-toggle" onclick="gsPwToggle('gs-reg-pass')" type="button" tabindex="-1" aria-label="Toggle password visibility">👁</button>
          <div class="gsauth-strength"><div class="gsauth-strength-bar" id="gs-strength-bar"></div></div>
        </div>

        <label class="gsauth-terms">
          <input type="checkbox" id="gs-reg-terms"
            style="accent-color:<?php echo esc_attr($color); ?>;margin-top:2px;flex-shrink:0">
          <span>I agree to the
            <a href="<?php echo esc_url(home_url('/terms/')); ?>" target="_blank" style="color:<?php echo esc_attr($color); ?>">Terms of Service</a>
            and
            <a href="<?php echo esc_url(home_url('/privacy/')); ?>" target="_blank" style="color:<?php echo esc_attr($color); ?>">Privacy Policy</a>
          </span>
        </label>

        <button class="gsauth-btn gsauth-btn-primary" id="reg-btn" onclick="gsRegister()">
          Create Account
        </button>
        <p style="font-size:.77rem;color:#94A3B8;text-align:center;margin-top:12px">Free to register · No credit card required</p>
      </div>

    </div><!-- .gsauth-card -->

    <div class="gsauth-back">
      <a href="<?php echo esc_url(home_url('/')); ?>">← Back to <?php echo esc_html($platform); ?></a>
    </div>
  </div>
</div>

<script>
/* ── Helpers ──────────────────────────────────────────────────────── */
var GS_AJAX   = '<?php echo esc_js($ajax_url); ?>';
var GS_NONCE  = '<?php echo esc_js($nonce); ?>';
var GS_VENDOR = '<?php echo esc_js(home_url('/vendor/dashboard/')); ?>';

function gsTab(t) {
  document.getElementById('panel-login').style.display    = t === 'login' ? 'block' : 'none';
  document.getElementById('panel-register').style.display = t === 'register' ? 'block' : 'none';
  document.getElementById('tab-login').className    = 'gsauth-tab' + (t === 'login' ? ' active' : '');
  document.getElementById('tab-register').className = 'gsauth-tab' + (t === 'register' ? ' active' : '');
}
function gsPwToggle(id) {
  var el = document.getElementById(id);
  el.type = el.type === 'password' ? 'text' : 'password';
}
function gsShowErr(id, msg) {
  var el = document.getElementById(id);
  el.textContent = msg; el.style.display = 'block';
}
function gsHideErr(id) {
  var el = document.getElementById(id);
  el.style.display = 'none'; el.textContent = '';
}
function gsPassStrength(val) {
  var s = 0;
  if (val.length >= 8)  s++;
  if (val.length >= 12) s++;
  if (/[A-Z]/.test(val)) s++;
  if (/[0-9]/.test(val)) s++;
  if (/[^A-Za-z0-9]/.test(val)) s++;
  var cols = ['#DC2626','#F59E0B','#F59E0B','#059669','#059669'];
  var bar = document.getElementById('gs-strength-bar');
  bar.style.width = (s / 5 * 100) + '%';
  bar.style.background = cols[s - 1] || '#E2E8F0';
}

/* ── Login ────────────────────────────────────────────────────────── */
function gsLogin() {
  gsHideErr('login-err');
  var id   = document.getElementById('gs-login-id').value.trim();
  var pass = document.getElementById('gs-login-pass').value;

  if (!id || !pass) {
    gsShowErr('login-err', 'Please enter your email / username and password.');
    return;
  }

  var btn = document.getElementById('login-btn');
  btn.disabled = true; btn.textContent = 'Signing in…';

  var fd = new FormData();
  fd.append('action',   'gs_vendor_login');
  fd.append('nonce',    (typeof GS !== 'undefined' && GS.nonce) ? GS.nonce : GS_NONCE);
  fd.append('email',    id);      // field named 'email' for backwards compat
  fd.append('password', pass);

  fetch((typeof GS !== 'undefined' && GS.ajax_url) ? GS.ajax_url : GS_AJAX, {
    method: 'POST', body: fd, credentials: 'same-origin'
  })
  .then(function(res) {
    return res.text().then(function(txt) {
      var json = {};
      try { json = JSON.parse(txt); } catch(e) {}
      return { status: res.status, json: json };
    });
  })
  .then(function(r) {
    btn.disabled = false; btn.textContent = 'Sign In';
    if (r.json && r.json.success && r.json.data && r.json.data.needs_2fa) {
      // Real feature — 2FA challenge. Must be checked before the redirect
      // branch below: this response is success:true (correctly, it's not
      // an error) but no session has been created yet, so redirecting
      // here would be treating an unauthenticated state as authenticated.
      gsShow2faChallenge(r.json.data.pending_token);
      return;
    }
    if (r.json && r.json.success) {
      btn.textContent = '✓ Redirecting…';
      var dest = (r.json.data && r.json.data.redirect)
        ? r.json.data.redirect
        : GS_VENDOR;
      window.location.href = dest;
    } else {
      var msg = (r.json && r.json.data && r.json.data.message)
        ? r.json.data.message
        : (r.status === 403
            ? 'Security check failed. Please refresh and try again.'
            : 'Login failed. Please check your credentials and try again.');
      gsShowErr('login-err', msg);
    }
  })
  .catch(function() {
    btn.disabled = false; btn.textContent = 'Sign In';
    gsShowErr('login-err', 'Connection error. Please check your internet and try again.');
  });
}

/* ── 2FA Challenge — real feature ─────────────────────────────────── */
function gsShow2faChallenge(pendingToken) {
  document.getElementById('gs-2fa-token').value = pendingToken;
  document.getElementById('panel-login').style.display = 'none';
  document.getElementById('panel-2fa').style.display = '';
  document.getElementById('gs-2fa-code').value = '';
  gsHideErr('tfa-err');
  document.getElementById('gs-2fa-code').focus();
}

function gs2faBack() {
  document.getElementById('panel-2fa').style.display = 'none';
  document.getElementById('panel-login').style.display = '';
}

function gsVerify2fa() {
  gsHideErr('tfa-err');
  var code = document.getElementById('gs-2fa-code').value.trim();
  var token = document.getElementById('gs-2fa-token').value;
  if (!code || code.length !== 6) {
    gsShowErr('tfa-err', 'Please enter the 6-digit code.');
    return;
  }

  var btn = document.getElementById('tfa-btn');
  btn.disabled = true; btn.textContent = 'Verifying…';

  var fd = new FormData();
  fd.append('action', 'gs_verify_2fa');
  fd.append('nonce', (typeof GS !== 'undefined' && GS.nonce) ? GS.nonce : GS_NONCE);
  fd.append('pending_token', token);
  fd.append('otp', code);

  fetch((typeof GS !== 'undefined' && GS.ajax_url) ? GS.ajax_url : GS_AJAX, {
    method: 'POST', body: fd, credentials: 'same-origin'
  })
  .then(function(res) { return res.text().then(function(txt){ var j={}; try{j=JSON.parse(txt);}catch(e){} return {status:res.status, json:j}; }); })
  .then(function(r) {
    btn.disabled = false; btn.textContent = 'Verify & Sign In';
    if (r.json && r.json.success) {
      btn.textContent = '✓ Redirecting…';
      var dest = (r.json.data && r.json.data.redirect) ? r.json.data.redirect : GS_VENDOR;
      window.location.href = dest;
    } else {
      var msg = (r.json && r.json.data && r.json.data.message) ? r.json.data.message : 'Incorrect or expired code. Please try again.';
      gsShowErr('tfa-err', msg);
    }
  })
  .catch(function() {
    btn.disabled = false; btn.textContent = 'Verify & Sign In';
    gsShowErr('tfa-err', 'Connection error. Please check your internet and try again.');
  });
}

/* ── Register ─────────────────────────────────────────────────────── */
function gsRegister() {
  gsHideErr('reg-err');
  document.getElementById('reg-ok').style.display = 'none';

  var name  = document.getElementById('gs-reg-name').value.trim();
  var email = document.getElementById('gs-reg-email').value.trim();
  var phone = document.getElementById('gs-reg-phone').value.trim();
  var pass  = document.getElementById('gs-reg-pass').value;
  var terms = document.getElementById('gs-reg-terms').checked;

  if (!name || !email || !phone || !pass) {
    gsShowErr('reg-err', 'All fields are required.');
    return;
  }
  if (!terms) {
    gsShowErr('reg-err', 'Please accept the Terms of Service to continue.');
    return;
  }
  if (pass.length < 8) {
    gsShowErr('reg-err', 'Password must be at least 8 characters long.');
    return;
  }

  var btn = document.getElementById('reg-btn');
  btn.disabled = true; btn.textContent = 'Creating account…';

  /* Register uses gsPost (jQuery-based) from goodservice.js */
  if (typeof gsPost === 'function') {
    gsPost('gs_register_vendor', { name: name, email: email, phone: phone, password: pass },
      function(d) {
        btn.disabled = false; btn.textContent = 'Create Account';
        var ok = document.getElementById('reg-ok');
        ok.style.display = 'block';
        ok.textContent = '🎉 ' + (d.message || 'Account created!') + ' Redirecting…';
        setTimeout(function() {
          window.location.href = (d.redirect || GS_VENDOR);
        }, 1500);
      },
      function(m) {
        btn.disabled = false; btn.textContent = 'Create Account';
        gsShowErr('reg-err', m);
      }
    );
  } else {
    /* Fallback: fetch-based if jQuery/gsPost not loaded yet */
    var fd = new FormData();
    fd.append('action', 'gs_register_vendor');
    fd.append('nonce',  (typeof GS !== 'undefined' && GS.nonce) ? GS.nonce : GS_NONCE);
    fd.append('name', name); fd.append('email', email);
    fd.append('phone', phone); fd.append('password', pass);

    fetch((typeof GS !== 'undefined' && GS.ajax_url) ? GS.ajax_url : GS_AJAX, {
      method: 'POST', body: fd, credentials: 'same-origin'
    })
    .then(function(res) { return res.json(); })
    .then(function(r) {
      btn.disabled = false; btn.textContent = 'Create Account';
      if (r.success) {
        var ok = document.getElementById('reg-ok');
        ok.style.display = 'block';
        ok.textContent = '🎉 ' + (r.data && r.data.message ? r.data.message : 'Account created!') + ' Redirecting…';
        setTimeout(function() { window.location.href = (r.data && r.data.redirect) ? r.data.redirect : GS_VENDOR; }, 1500);
      } else {
        gsShowErr('reg-err', r.data && r.data.message ? r.data.message : 'Registration failed. Please try again.');
      }
    })
    .catch(function() {
      btn.disabled = false; btn.textContent = 'Create Account';
      gsShowErr('reg-err', 'Connection error. Please try again.');
    });
  }
}

/* ── Keyboard shortcuts ───────────────────────────────────────────── */
document.getElementById('gs-login-pass').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') gsLogin();
});
document.getElementById('gs-login-id').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') document.getElementById('gs-login-pass').focus();
});

/* ── Auto-switch tab from URL ─────────────────────────────────────── */
if (window.location.search.includes('tab=register') ||
    window.location.hash === '#register') {
  gsTab('register');
}
</script>
