<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
// Vendor public profile page — handled by other-dashboards.php
// Set the gs_page var so the router knows which section to render
if ( ! get_query_var('gs_page') ) {
    set_query_var( 'gs_page', 'vendor_profile' );
}
require GS_DIR . 'templates/pages/other-dashboards.php';
