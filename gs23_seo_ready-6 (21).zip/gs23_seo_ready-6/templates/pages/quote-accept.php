<?php
/**
 * GoodService — Client Quote Acceptance Page (Part 6.4)
 * Accessible at: /quote/accept/{token}/
 * Requires rewrite rule in Router.php or goodservice.php.
 *
 * Context variables supplied by Router:
 *   $token  string  Quote acceptance token (64 hex chars)
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$token  = sanitize_text_field( get_query_var( 'gs_quote_token', '' ) );
$result = null;

if ( $token && strlen( $token ) === 64 ) {
    $result = \GoodService\Service\QuotationService::accept_by_token( $token );
}

get_header();
?>
<div style="min-height:80vh;display:flex;align-items:center;justify-content:center;background:#F1F5F9;padding:24px">
  <div style="max-width:480px;width:100%;background:#fff;border-radius:16px;padding:40px 32px;box-shadow:0 8px 32px rgba(0,0,0,.08);text-align:center">
    <?php if ( ! $token ): ?>
      <div style="font-size:3rem;margin-bottom:16px">🔗</div>
      <h1 style="font-size:1.3rem;font-weight:700;color:#1E293B;margin:0 0 10px">Invalid Link</h1>
      <p style="color:#64748B;font-size:.9rem">This quote acceptance link appears to be invalid or incomplete.</p>
      <a href="<?php echo esc_url(home_url('/')); ?>" class="gs-btn gs-btn-primary" style="margin-top:16px;display:inline-block;text-decoration:none">← Go Home</a>

    <?php elseif ( $result && $result['success'] ): ?>
      <div style="font-size:3rem;margin-bottom:16px">✅</div>
      <h1 style="font-size:1.3rem;font-weight:700;color:#059669;margin:0 0 10px">Quote Accepted!</h1>
      <p style="color:#64748B;font-size:.9rem;line-height:1.6;margin:0 0 20px"><?php echo esc_html($result['message']); ?></p>
      <div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;padding:14px 16px;margin-bottom:20px;font-size:.85rem;color:#065F46">
        <strong>Quote #<?php echo esc_html($result['quote_number'] ?? ''); ?></strong> has been confirmed.<br>
        The vendor will contact you shortly to arrange the service.
      </div>
      <?php if ( is_user_logged_in() ): ?>
      <a href="<?php echo esc_url(home_url('/customer/dashboard/?section=bookings')); ?>" class="gs-btn gs-btn-primary" style="display:inline-block;text-decoration:none;margin-right:8px">View My Bookings</a>
      <?php endif; ?>
      <a href="<?php echo esc_url(home_url('/')); ?>" class="gs-btn gs-btn-ghost" style="display:inline-block;text-decoration:none">Go Home</a>

    <?php else: ?>
      <div style="font-size:3rem;margin-bottom:16px">⚠️</div>
      <h1 style="font-size:1.3rem;font-weight:700;color:#DC2626;margin:0 0 10px">Unable to Accept Quote</h1>
      <p style="color:#64748B;font-size:.9rem;line-height:1.6;margin:0 0 20px"><?php echo esc_html($result['message'] ?? 'This quote link is invalid or has expired.'); ?></p>
      <a href="<?php echo esc_url(home_url('/')); ?>" class="gs-btn gs-btn-ghost" style="display:inline-block;text-decoration:none">← Go Home</a>
    <?php endif; ?>
  </div>
</div>
<?php get_footer(); ?>
