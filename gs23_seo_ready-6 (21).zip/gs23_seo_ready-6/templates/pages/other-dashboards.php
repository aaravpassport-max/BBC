<?php
// ── STAFF DASHBOARD ──────────────────────────────────────────────────────────
if ( ! defined( 'ABSPATH' ) ) { exit; }
// This file handles multiple dashboard types via gs_page query var
$gs_page = get_query_var('gs_page','');

if ($gs_page === 'staff_dashboard'):
if (!is_user_logged_in()) { wp_redirect(home_url('/staff/login/')); exit; }
if (!gs_user_can('gs_approve_listings')) { wp_redirect(home_url('/staff/login/')); exit; }
$section = sanitize_text_field($_GET['section']??'dashboard');
$user    = wp_get_current_user();
global $wpdb; $pfx = $wpdb->prefix.'gs_';
// ENTERPRISE-AUDIT FIX (Part 1, Critical — staff RBAC granularity): a
// restricted staff/moderator account (rows exist for them in
// gs_staff_permissions) gets bounced off any of the 3 sections they were
// not explicitly granted, straight back to their own dashboard home — this
// is defense-in-depth for the view layer only; the real security boundary
// is Roles::can_access_section() enforced server-side in each AJAX handler.
if ( in_array( $section, [ 'listings', 'reviews', 'complaints' ], true )
    && ! \GoodService\Core\Roles::can_access_section( $section, $user->ID ) ) {
    wp_redirect( home_url( '/staff/dashboard/' ) ); exit;
}
$gs_staff_can_listings  = \GoodService\Core\Roles::can_access_section( 'listings', $user->ID );
$gs_staff_can_reviews   = \GoodService\Core\Roles::can_access_section( 'reviews', $user->ID );
$gs_staff_can_complaints = \GoodService\Core\Roles::can_access_section( 'complaints', $user->ID );
// ── Admin impersonation banner ─────────────────────────────────────────────
// New: staff dashboard now supports the same "Switch to Any User" system
// already proven on the vendor and customer dashboards, via the shared
// gs_render_impersonation_banner() function — no duplicated detection logic.
gs_render_impersonation_banner( $user->display_name ?: $user->user_email );
?>
<div class="gs-root gs-dashboard" style="font-family:var(--gs-font);background:#F8FAFC;min-height:100vh;display:flex">
<aside class="gs-sidebar">
  <div class="gs-sidebar-logo">
    <div style="width:38px;height:38px;border-radius:8px;background:#0EA5E9;color:white;display:flex;align-items:center;justify-content:center;font-weight:700">S</div>
    <div><div class="gs-sidebar-logo-text"><?php echo esc_html($user->display_name); ?></div><div class="gs-sidebar-logo-sub">Staff</div></div>
  </div>
  <?php
  // ENTERPRISE-AUDIT FIX (Part 4, Medium-High: "No caching layer for
  // manager/moderation dashboard counts — every page load re-runs 5-8
  // uncached COUNT queries on every request"). This staff dashboard was
  // actually worse than the finding's own wording: the same 3 counts
  // (pending listings/reviews, open complaints) were each queried a SECOND
  // time for the nav badges below, AND the $stats array a few lines down
  // used to be built unconditionally even on sections where it's never
  // displayed (anything other than section=dashboard) — computed and then
  // thrown away on every single non-dashboard page view. Cached once here
  // (60s TTL, same convention as manager-dashboard.php's equivalent fix and
  // admin-dashboard.php's $dash cache) and reused for both the nav badges
  // and the stats widget below, with the stats array itself only built
  // when section=dashboard actually needs it.
  if ( isset( $_GET['dash_refresh'] ) ) { \GoodService\Core\Cache::delete( 'staff_dash_counts' ); }
  $_staff_counts = \GoodService\Core\Cache::remember( 'staff_dash_counts', function() use ( $wpdb, $pfx ) {
      return [
          'pend_listings' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}listings WHERE status='pending'" ),
          'pend_reviews'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}reviews WHERE status='pending'" ),
          'open_comps'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}complaints WHERE status NOT IN('resolved','closed')" ),
      ];
  }, 60 );
  ?>
  <nav class="gs-sidebar-nav">
    <a href="?section=dashboard" class="gs-nav-item <?php echo $section==='dashboard'?'active':''; ?>">📊 Dashboard</a>
    <?php if ( $gs_staff_can_listings ): ?>
    <a href="?section=listings" class="gs-nav-item <?php echo $section==='listings'?'active':''; ?>">🏢 Review Listings <?php $p=$_staff_counts['pend_listings']; if($p): ?><span class="gs-nav-badge"><?php echo $p; ?></span><?php endif; ?></a>
    <?php endif; ?>
    <?php if ( $gs_staff_can_reviews ): ?>
    <a href="?section=reviews" class="gs-nav-item <?php echo $section==='reviews'?'active':''; ?>">⭐ Approve Reviews</a>
    <?php endif; ?>
    <?php if ( $gs_staff_can_complaints ): ?>
    <a href="?section=complaints" class="gs-nav-item <?php echo $section==='complaints'?'active':''; ?>">⚠️ Complaints <?php $oc=$_staff_counts['open_comps']; if($oc): ?><span class="gs-nav-badge"><?php echo $oc; ?></span><?php endif; ?></a>
    <?php endif; ?>
    <div style="padding:16px;border-top:1px solid rgba(255,255,255,.1);margin-top:auto"><a href="<?php echo wp_logout_url(home_url('/')); ?>" class="gs-btn gs-btn-ghost gs-btn-sm" style="width:100%;color:rgba(255,255,255,.6);border-color:rgba(255,255,255,.15)">Logout</a></div>
  </nav>
</aside>
<main class="gs-main">
  <header class="gs-topbar"><div style="font-weight:700;color:#1E3A5F;text-transform:capitalize"><?php echo str_replace('_',' ',$section); ?></div></header>
  <div class="gs-page-content">
  <?php
  $stats = $section === 'dashboard' ? [
      ['Pending Listings',$_staff_counts['pend_listings'],'⏳','#FFFBEB','#D97706'],
      ['Pending Reviews',$_staff_counts['pend_reviews'],'⭐','#EFF6FF','#2563EB'],
      ['Open Complaints',$_staff_counts['open_comps'],'⚠️','#FEF2F2','#DC2626'],
  ] : [];
  ?>
  <?php if($section==='dashboard'): ?>
  <div class="gs-page-header"><div class="gs-page-title">Staff Dashboard</div></div>
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:24px">
    <?php foreach($stats as $s): ?><div class="gs-stat-card"><div class="gs-stat-icon" style="background:<?php echo $s[3]; ?>"><?php echo $s[2]; ?></div><div><div class="gs-stat-value" style="color:<?php echo $s[4]; ?>"><?php echo $s[1]; ?></div><div class="gs-stat-label"><?php echo $s[0]; ?></div></div></div><?php endforeach; ?>
  </div>
  <?php $pending=$wpdb->get_results("SELECT l.*,vp.business_name as vendor_name FROM {$pfx}listings l LEFT JOIN {$pfx}vendor_profiles vp ON l.vendor_id=vp.user_id WHERE l.status='pending' ORDER BY l.created_at ASC LIMIT 5"); ?>
  <?php if($pending): ?>
  <div class="gs-card"><div class="gs-card-header"><div class="gs-card-title">Pending Listings</div></div>
  <div style="display:flex;flex-direction:column;gap:10px">
  <?php foreach($pending as $l): ?>
  <div style="display:flex;align-items:center;justify-content:space-between;padding:12px;background:#F8FAFC;border-radius:8px;border:1px solid #E2E8F0">
    <div><div style="font-weight:600;font-size:.9rem"><?php echo esc_html($l->title); ?></div><div style="font-size:.78rem;color:#64748B"><?php echo esc_html($l->vendor_name??'—'); ?> • <?php echo gs_time_ago($l->created_at); ?></div></div>
    <div style="display:flex;gap:6px"><button class="gs-btn gs-btn-xs gs-btn-success gs-approve-listing" data-id="<?php echo $l->id; ?>">✓</button><button class="gs-btn gs-btn-xs gs-btn-danger gs-reject-listing" data-id="<?php echo $l->id; ?>">✕</button></div>
  </div>
  <?php endforeach; ?></div></div><?php endif; ?>
  <?php
  // ENTERPRISE-AUDIT FIX (root-cause bug, confirmed): this used to only
  // handle 'listings' and 'reviews' — 'complaints' had a nav link (above)
  // but no matching branch here at all, so clicking it just rendered a
  // blank content area with nothing in it, despite gs_staff/gs_moderator
  // both holding the gs_manage_complaints capability and a fully working
  // AJAX handler (updateComplaint()) existing already. Added the missing
  // branch, reusing the same trusted, capability-scoped include as the
  // other two sections.
  //
  // GS_MGR_TRUSTED_INCLUDE — see the matching check in manager-dashboard.php
  // for the full explanation: this constant tells that file its own
  // is_manager()-only gate can be skipped because THIS file has already
  // independently verified gs_user_can('gs_approve_listings') at the top of
  // this page (line 9 above) and only reaches this require for these three
  // explicitly whitelisted section values — never for 'vendors', 'leads',
  // or any other manager-only section. Every actual mutating action
  // reachable from the included markup (vendor verify/suspend, etc.) is
  // still independently capability-checked server-side at the AJAX layer,
  // so this only unblocks legitimate viewing, not any new permission.
  ?>
  <?php elseif( in_array( $section, [ 'listings', 'reviews', 'complaints' ], true ) ):
    if ( ! defined( 'GS_MGR_TRUSTED_INCLUDE' ) ) { define( 'GS_MGR_TRUSTED_INCLUDE', true ); }
    require GS_DIR.'templates/pages/manager-dashboard.php';
  endif; ?>
  </div>
</main>
</div>
<?php

// ── VENDOR STAFF DASHBOARD ───────────────────────────────────────────────────
elseif ($gs_page === 'vendor_staff_dashboard'):
if (!gs_is_vendor()) { wp_redirect(home_url('/vendor/login/')); exit; }
$user    = wp_get_current_user();
global $wpdb; $pfx = $wpdb->prefix.'gs_';
$vstaff  = $wpdb->get_row($wpdb->prepare("SELECT vs.* FROM {$pfx}vendor_staff vs WHERE vs.user_id=%d",$user->ID));
$vendor_id = $vstaff ? $vstaff->vendor_id : 0;
$my_leads  = $vendor_id ? $wpdb->get_results($wpdb->prepare("SELECT l.*,li.title as listing_title FROM {$pfx}leads l LEFT JOIN {$pfx}listings li ON l.listing_id=li.id WHERE l.vendor_id=%d AND l.status='new' ORDER BY l.created_at DESC LIMIT 10",$vendor_id)) : [];
?>
<div class="gs-root gs-dashboard" style="font-family:var(--gs-font);background:#F8FAFC;min-height:100vh">
  <div style="background:#1E3A5F;padding:16px 24px;display:flex;align-items:center;justify-content:space-between">
    <div style="color:white;font-weight:700">Vendor Staff Portal</div>
    <div style="color:rgba(255,255,255,.7);font-size:.85rem"><?php echo esc_html($user->display_name); ?> • Staff</div>
  </div>
  <div class="gs-container" style="padding-top:24px">
    <div class="gs-grid-2">
      <div class="gs-card">
        <div class="gs-card-title" style="margin-bottom:14px">📞 New Leads (<?php echo count($my_leads); ?>)</div>
        <?php if($my_leads): ?>
        <div style="display:flex;flex-direction:column;gap:10px">
          <?php foreach($my_leads as $l): ?>
          <div style="padding:12px;background:#F0F9FF;border-radius:8px;border:1.5px solid #BAE6FD">
            <div style="font-weight:600"><?php echo esc_html($l->name); ?></div>
            <div style="font-size:.82rem;color:#64748B"><?php echo esc_html($l->phone); ?> • <?php echo esc_html($l->listing_title??''); ?></div>
            <div style="display:flex;gap:6px;margin-top:8px">
              <a href="tel:<?php echo esc_attr($l->phone); ?>" class="gs-btn gs-btn-xs gs-btn-success">📞 Call</a>
              <?php if($l->phone): ?><a href="https://wa.me/<?php echo preg_replace('/[^0-9]/','',esc_attr($l->phone)); ?>" target="_blank" class="gs-btn gs-btn-xs" style="background:#25D366;color:white">💬</a><?php endif; ?>
              <button onclick="gsPost('gs_update_lead_status',{lead_id:<?php echo $l->id; ?>,status:'contacted'},function(){this.closest('.gs-repeater-item,div').style.opacity='.5';gsToast('Marked contacted','success');}.bind(this))" class="gs-btn gs-btn-xs gs-btn-ghost">Mark Contacted</button>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div style="text-align:center;padding:32px;color:#94A3B8"><div style="font-size:2rem">📞</div><div>No new leads</div></div>
        <?php endif; ?>
      </div>
      <div class="gs-card">
        <div class="gs-card-title" style="margin-bottom:14px">💬 Messages</div>
        <div style="text-align:center;padding:32px;color:#94A3B8">
          <a href="<?php echo home_url('/vendor/dashboard/?section=messages'); ?>" class="gs-btn gs-btn-primary gs-btn-md">Open Messages</a>
        </div>
      </div>
    </div>
  </div>
</div>
<?php

// ── VISITOR / CLIENT ACCOUNT DASHBOARD ───────────────────────────────────────
elseif ($gs_page === 'visitor_dashboard'):
if (!is_user_logged_in()) { wp_redirect(home_url('/vendor-login/')); exit; }
$user    = wp_get_current_user();
$uid     = (int)$user->ID;
global $wpdb; $pfx = $wpdb->prefix.'gs_';
$nonce   = wp_create_nonce('gs_ajax');
$section = sanitize_text_field($_GET['section']??'dashboard');

// Pre-fetch data for current section
$saved = [];
$my_leads = [];
// Real fix: separate, minimal, always-running query for the bottom nav's
// Call Vendor link. The main $my_leads query below only runs for specific
// sections (inquiries/dashboard), but the bottom nav is visible on every
// section — this ensures it always has a real vendor to link to, using the
// same "most recent inquiry" logic already established elsewhere.
$latest_vendor_contact = $wpdb->get_row( $wpdb->prepare(
    "SELECT li.phone AS vendor_phone, li.whatsapp AS vendor_wa, vp.business_name AS vendor_name
     FROM {$pfx}leads l
     LEFT JOIN {$pfx}listings li ON li.id = l.listing_id
     LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
     WHERE l.customer_user_id = %d OR (l.customer_user_id = 0 AND l.email = %s)
     ORDER BY l.created_at DESC LIMIT 1",
    $uid, $user->user_email
) );
if ($section === 'saved' || $section === 'dashboard') {
    $saved = $wpdb->get_results($wpdb->prepare(
        "SELECT sl.*,l.title,l.slug,l.city,l.avg_rating,l.banner_url,l.logo_url,l.phone,l.whatsapp
         FROM {$pfx}saved_listings sl
         LEFT JOIN {$pfx}listings l ON sl.listing_id=l.id
         WHERE sl.user_id=%d ORDER BY sl.folder ASC, sl.created_at DESC", $uid
    )) ?: [];
}
if ($section === 'inquiries' || $section === 'dashboard') {
    $my_leads = $wpdb->get_results($wpdb->prepare(
        "SELECT l.*, li.title AS listing_title, li.slug AS listing_slug,
                li.phone     AS vendor_phone,
                li.whatsapp  AS vendor_wa,
                li.logo_url  AS vendor_logo,
                vp.business_name AS vendor_name,
                (SELECT COUNT(*) FROM {$pfx}lead_replies r
                 WHERE r.lead_id=l.id AND r.sender_type='vendor' AND r.is_internal=0
                   AND r.created_at > COALESCE(
                     (SELECT MAX(rr.created_at) FROM {$pfx}lead_replies rr
                      WHERE rr.lead_id=l.id AND rr.sender_type='customer'),
                     l.created_at
                   )
                ) AS unread_replies
         FROM {$pfx}leads l
         LEFT JOIN {$pfx}listings li ON li.id = l.listing_id
         LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
         WHERE l.customer_user_id = %d
            OR (l.customer_user_id = 0 AND l.email = %s)
         ORDER BY l.created_at DESC",
        $uid, $user->user_email
    )) ?: [];
}
$total_saved = count($saved);
if ($section === 'bookings' || $section === 'dashboard') {
    $my_bookings = $wpdb->get_results($wpdb->prepare(
        "SELECT b.*, li.title AS listing_title, li.slug AS listing_slug,
                li.phone AS vendor_phone, li.whatsapp AS vendor_wa,
                vp.business_name AS vendor_name,
                d.id AS dispute_id, d.status AS dispute_status
         FROM {$pfx}bookings b
         LEFT JOIN {$pfx}listings li ON li.id = b.listing_id
         LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = b.vendor_id
         LEFT JOIN {$pfx}disputes d ON d.booking_id = b.id AND d.status NOT IN ('resolved','closed')
         WHERE b.user_id = %d
            OR (b.user_id = 0 AND b.customer_email = %s)
         ORDER BY b.created_at DESC",
        $uid, $user->user_email
    )) ?: [];
}
$total_bookings = $section === 'bookings' ? count($my_bookings) :
    (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$pfx}bookings WHERE user_id=%d OR (user_id=0 AND customer_email=%s)",
        $uid, $user->user_email
    ));
$total_leads = $section === 'inquiries' ? count($my_leads) :
    (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$pfx}leads WHERE customer_user_id=%d OR (customer_user_id=0 AND email=%s)",
        $uid, $user->user_email
    ));
$new_replies = (int)$wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$pfx}lead_replies r
     INNER JOIN {$pfx}leads l ON l.id=r.lead_id
     WHERE (l.customer_user_id=%d OR (l.customer_user_id=0 AND l.email=%s))
       AND r.sender_type='vendor' AND r.is_internal=0
       AND r.created_at > COALESCE((SELECT MAX(created_at) FROM {$pfx}lead_replies
                                    WHERE lead_id=r.lead_id AND sender_type='customer'),l.created_at)",
    $uid, $user->user_email
));
$profile_name    = $user->display_name ?: ($user->first_name . ' ' . $user->last_name);
// ── Account verification status ─────────────────────────────────────────────
// Real fix: this exact card previously existed only in customer-dashboard.php,
// a file nothing in the router ever includes — /my-account/ has always
// rendered THIS file (other-dashboards.php, gs_page=visitor_dashboard), so
// that card was never actually visible to any real client. Ported here, into
// the file that's genuinely served, using the same already-working backend
// (AjaxController::sendAccountEmailOtp() / verifyAccountEmailOtp() /
// sendAccountWhatsappOtp() / verifyAccountWhatsappOtp() and
// EmailVerificationService / WhatsAppVerificationService) — no new
// verification logic, just the missing UI wired to what already works.
$acct_email_verified = (int) get_user_meta( $uid, 'gs_account_email_verified', true );
$acct_phone_verified = (int) get_user_meta( $uid, 'gs_account_phone_verified', true );
// Real fix (Section 4 of the verification spec): admin now has a global,
// dedicated toggle for whether WhatsApp verification is offered to clients
// AT ALL in the dashboard — separate from 'whatsapp_verify_enabled', which
// only ever controlled the optional pre-submission step on the INQUIRY FORM
// itself, a different feature. When off, the WhatsApp side of this card is
// completely hidden (not just disabled) and only email verification shows,
// exactly as specified. This is a hard gate the client dashboard always
// obeys — it does not participate in the module→vendor→global override
// chain WhatsAppVerificationService::is_enabled() uses for the inquiry-form
// step, since the spec describes it as a simple, unconditional admin switch.
$show_whatsapp_verify = (bool) \GoodService\Core\Config::get( 'client_dashboard_whatsapp_verify_enabled', false );
$acct_fully_verified  = $acct_email_verified && ( ! $show_whatsapp_verify || $acct_phone_verified );
$acct_needs_verify    = ! $acct_fully_verified;
$profile_phone   = get_user_meta($uid,'gs_phone',true);
$profile_city    = get_user_meta($uid,'gs_city',true);
$profile_company = get_user_meta($uid,'gs_company',true);
?>
<style>
.gsc-root{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;background:#F8FAFC;min-height:100vh}
.gsc-header{background:linear-gradient(135deg,#1E3A5F 0%,#2563EB 100%);padding:0 24px;display:flex;align-items:center;justify-content:space-between;height:56px;position:sticky;top:0;z-index:50;box-shadow:0 2px 12px rgba(0,0,0,.18)}
.gsc-header-logo{color:#fff;font-weight:800;font-size:1rem;text-decoration:none}
.gsc-header-user{display:flex;align-items:center;gap:12px}
.gsc-header-name{color:rgba(255,255,255,.75);font-size:.82rem}
.gsc-logout{color:rgba(255,255,255,.5);font-size:.78rem;text-decoration:none;padding:4px 10px;border:1px solid rgba(255,255,255,.2);border-radius:6px;transition:.15s}
.gsc-logout:hover{background:rgba(255,255,255,.1);color:#fff}
.gsc-nav{background:#fff;border-bottom:1px solid #E2E8F0;display:flex;overflow-x:auto;scrollbar-width:none}
.gsc-nav::-webkit-scrollbar{display:none}
.gsc-nav-item{flex-shrink:0;padding:14px 18px;font-size:.82rem;font-weight:600;color:#64748B;text-decoration:none;border-bottom:2px solid transparent;white-space:nowrap;transition:.12s;display:flex;align-items:center;gap:5px}
.gsc-nav-item:hover{color:#2563EB;background:#F8FAFC}
.gsc-nav-item.on{border-bottom-color:#2563EB;color:#2563EB}
.gsc-nav-badge{background:#EF4444;color:#fff;border-radius:20px;padding:1px 6px;font-size:.62rem;font-weight:700}
.gsc-container{max-width:1100px;margin:0 auto;padding:24px 16px 60px}
.gsc-stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin-bottom:22px}
.gsc-sc{background:#fff;border:1px solid #E2E8F0;border-radius:10px;padding:14px 16px;display:flex;align-items:center;gap:12px}
.gsc-sc-icon{width:40px;height:40px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0}
.gsc-sc-val{font-weight:800;font-size:1.3rem;color:#1E293B;line-height:1}
.gsc-sc-lbl{font-size:.7rem;color:#64748B;margin-top:3px}
.gsc-card{background:#fff;border:1px solid #E2E8F0;border-radius:10px;padding:18px;margin-bottom:16px}
.gsc-card-title{font-weight:700;font-size:.9rem;color:#1E293B;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between}
.gsc-ph{display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;flex-wrap:wrap;gap:8px}
.gsc-ph-title{font-weight:800;font-size:1.1rem;color:#1E293B}
.gsc-ph-sub{font-size:.8rem;color:#64748B;margin-top:2px}
/* Inquiry list */
.gsc-inq-wrap{display:flex;gap:0;background:#F1F5F9;border-radius:12px;overflow:hidden;border:1px solid #E2E8F0;min-height:500px}
.gsc-inq-left{width:36%;min-width:240px;max-width:360px;border-right:1px solid #E2E8F0;background:#fff;display:flex;flex-direction:column}
.gsc-inq-list{flex:1;overflow-y:auto}
.gsc-inq-item{padding:12px 14px;border-bottom:1px solid #F1F5F9;cursor:pointer;transition:.1s;display:flex;gap:8px;align-items:flex-start}
.gsc-inq-item.gsc-inq-unread .gsc-inq-name{font-weight:800}
.gsc-inq-unread-dot{width:8px;height:8px;border-radius:50%;background:#EF4444;flex-shrink:0;margin-top:5px}
.gsc-inq-item:hover{background:#F8FAFC}
.gsc-inq-item.on{background:#EFF6FF;border-bottom-color:#DBEAFE}
.gsc-inq-bar{width:3px;border-radius:2px;margin-top:4px;height:36px;flex-shrink:0}
.gsc-inq-body{flex:1;min-width:0}
.gsc-inq-name{font-weight:700;font-size:.82rem;color:#1E293B;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.gsc-inq-prod{font-size:.74rem;color:#64748B;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.gsc-inq-time{font-size:.67rem;color:#94A3B8;margin-top:5px}
.gsc-inq-right{flex:1;background:#F8FAFC;display:flex;flex-direction:column;overflow:hidden}
.gsc-inq-right-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;flex:1;color:#94A3B8;text-align:center;padding:40px}
.gsc-inq-detail{display:none;flex-direction:column;flex:1;overflow:hidden}
.gsc-inq-detail-scroll{flex:1;overflow-y:auto;padding:16px}
.gsc-vendor-card{background:#fff;border:1px solid #E2E8F0;border-radius:10px;padding:14px;margin-bottom:14px;display:flex;align-items:center;gap:14px}
.gsc-vendor-logo{width:46px;height:46px;border-radius:8px;object-fit:cover;background:#F1F5F9;flex-shrink:0}
.gsc-vendor-name{font-weight:700;font-size:.9rem;color:#1E293B}
.gsc-vendor-meta{font-size:.76rem;color:#64748B;margin-top:3px}
.gsc-info-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px}
.gsc-info-cell{background:#F8FAFC;border-radius:8px;padding:10px 12px}
.gsc-info-lbl{font-size:.67rem;font-weight:700;color:#94A3B8;text-transform:uppercase;letter-spacing:.04em;margin-bottom:3px}
.gsc-info-val{font-size:.82rem;color:#1E293B;font-weight:500}
.gsc-inq-msg{background:#fff;border:1px solid #E2E8F0;border-radius:8px;padding:12px;font-size:.84rem;color:#334155;line-height:1.65;margin-bottom:14px}
.gsc-timeline-item{display:flex;flex-direction:column;margin-bottom:12px}
.gsc-bubble{border-radius:10px;padding:10px 14px;font-size:.83rem;line-height:1.65;max-width:88%}
.gsc-bubble.vendor{background:#EFF6FF;align-self:flex-start}
.gsc-bubble.customer{background:#F0FDF4;align-self:flex-end}
.gsc-bubble-meta{font-size:.67rem;color:#94A3B8;margin-top:4px}
.gsc-bubble-meta.right{text-align:right}
.gsc-status-badge{display:inline-block;padding:2px 9px;border-radius:20px;font-size:.7rem;font-weight:700;text-transform:capitalize}
.badge-new{background:#DBEAFE;color:#1D4ED8}
.badge-viewed,.badge-seen{background:#E2E8F0;color:#475569}
.badge-replied,.badge-contacted{background:#DCFCE7;color:#166534}
.badge-converted,.badge-qualified{background:#F3E8FF;color:#7C3AED}
.badge-junk{background:#FEE2E2;color:#DC2626}
/* Profile form */
.gsc-fg{margin-bottom:14px}
.gsc-lbl{display:block;font-size:.78rem;font-weight:600;color:#374151;margin-bottom:5px}
.gsc-inp{width:100%;border:1px solid #E2E8F0;border-radius:7px;padding:8px 11px;font-size:.87rem;font-family:inherit;outline:none;background:#fff;transition:.15s}
.gsc-inp:focus{border-color:#2563EB;box-shadow:0 0 0 3px rgba(37,99,235,.08)}
.gsc-g2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.gsc-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:8px 18px;border-radius:8px;font-size:.84rem;font-weight:600;cursor:pointer;border:none;font-family:inherit;transition:.15s;text-decoration:none}
.gsc-btn-primary{background:#2563EB;color:#fff}
.gsc-btn-primary:hover{background:#1D4ED8}
.gsc-btn-ghost{background:#F1F5F9;color:#374151;border:1px solid #E2E8F0}
.gsc-btn-ghost:hover{background:#E2E8F0}
.gsc-btn-green{background:#16A34A;color:#fff}
.gsc-btn-green:hover{background:#15803D}
.gsc-imsg{padding:8px 12px;border-radius:7px;font-size:.8rem;margin-bottom:12px;display:none}
.gsc-imsg.ok{display:block;background:#F0FDF4;color:#166534;border:1px solid #BBF7D0}
.gsc-imsg.err{display:block;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA}
@media(max-width:768px){
.gsc-inq-left{width:100%;max-width:none;border-right:none;border-bottom:1px solid #E2E8F0;max-height:280px}
.gsc-inq-wrap{flex-direction:column}
.gsc-g2{grid-template-columns:1fr}
.gsc-stat-grid{grid-template-columns:repeat(2,1fr)}
}
</style>

<div class="gsc-root">

  <!-- Header -->
  <div class="gsc-header">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="gsc-header-logo">
      <?php echo esc_html(get_bloginfo('name')); ?>
    </a>
    <div class="gsc-header-user">
      <span class="gsc-header-name">👤 <?php echo esc_html($profile_name ?: $user->display_name); ?></span>
      <a href="<?php echo esc_url(wp_logout_url(home_url('/'))); ?>" class="gsc-logout">Logout</a>
    </div>
  </div>

  <!-- Navigation -->
  <nav class="gsc-nav">
    <a href="?section=dashboard"  class="gsc-nav-item <?php echo $section==='dashboard'  ? 'on':''; ?>">📊 Dashboard</a>
    <a href="?section=inquiries"  class="gsc-nav-item <?php echo $section==='inquiries'  ? 'on':''; ?>">
      📬 My Inquiries
      <?php if($total_leads>0): ?><span class="gsc-nav-badge"><?php echo $total_leads; ?></span><?php endif; ?>
    </a>
    <a href="?section=bookings"   class="gsc-nav-item <?php echo $section==='bookings'   ? 'on':''; ?>">
      📅 My Bookings
      <?php if($total_bookings>0): ?><span class="gsc-nav-badge" style="background:#64748B"><?php echo $total_bookings; ?></span><?php endif; ?>
    </a>
    <a href="?section=saved"      class="gsc-nav-item <?php echo $section==='saved'      ? 'on':''; ?>">❤️ Saved <?php if($total_saved): ?><span class="gsc-nav-badge" style="background:#64748B"><?php echo $total_saved; ?></span><?php endif; ?></a>
    <a href="?section=profile"    class="gsc-nav-item <?php echo $section==='profile'    ? 'on':''; ?>">👤 My Profile</a>
  </nav>

  <!-- Bottom app-style navigation — same pattern already proven on the
       homepage (app-bottom-nav), pointed at this dashboard's own real
       sections instead. -->
  <nav id="gsc-bottom-nav" aria-label="Dashboard navigation">
    <a href="?section=dashboard" class="gbn-item <?php echo $section==='dashboard'?'gbn-active':''; ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/></svg>
      <span>Overview</span>
    </a>
    <a href="?section=inquiries" class="gbn-item <?php echo $section==='inquiries'?'gbn-active':''; ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-6.6 8.2 8.5 8.5 0 0 1-7.6-2.3L3 21l1.9-5.7A8.38 8.38 0 0 1 3 11.5a8.5 8.5 0 0 1 8.5-8.5h.5a8.48 8.48 0 0 1 8 8v.5Z"/></svg>
      <span>Inquiries</span>
      <?php if($total_leads>0): ?><span class="gbn-badge"><?php echo $total_leads; ?></span><?php endif; ?>
    </a>
    <a href="?section=saved" class="gbn-item <?php echo $section==='saved'?'gbn-active':''; ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s-6.5-4.35-9.3-8.1C.8 10.2 1.3 6.6 4.2 5c2.3-1.3 5-.6 6.8 1.4l1 1.1 1-1.1C14.8 4.4 17.5 3.7 19.8 5c2.9 1.6 3.4 5.2 1.5 7.9C18.5 16.65 12 21 12 21Z"/></svg>
      <span>Saved</span>
      <?php if($total_saved>0): ?><span class="gbn-badge" style="background:#64748B"><?php echo $total_saved; ?></span><?php endif; ?>
    </a>
    <a href="?section=profile" class="gbn-item <?php echo $section==='profile'?'gbn-active':''; ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.5-7 8-7s8 3 8 7"/></svg>
      <span>Profile</span>
    </a>
    <?php if ( $latest_vendor_contact && $latest_vendor_contact->vendor_phone ): ?>
    <a href="tel:<?php echo esc_attr($latest_vendor_contact->vendor_phone); ?>" id="gbn-call-btn" data-default-phone="<?php echo esc_attr($latest_vendor_contact->vendor_phone); ?>" data-default-name="<?php echo esc_attr($latest_vendor_contact->vendor_name ?: 'your vendor'); ?>" class="gbn-item" title="Call <?php echo esc_attr($latest_vendor_contact->vendor_name ?: 'your vendor'); ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92Z"/></svg>
      <span id="gbn-call-label">Call</span>
    </a>
    <?php else: ?>
    <a href="?section=inquiries" id="gbn-call-btn" class="gbn-item" title="Connect with a vendor">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92Z"/></svg>
      <span id="gbn-call-label">Connect</span>
    </a>
    <?php endif; ?>
  </nav>
  <style>
  #gsc-bottom-nav{
    display:none;position:fixed;left:0;right:0;bottom:0;z-index:400;
    background:rgba(255,255,255,.97);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);
    border-top:1px solid #E2E8F0;padding:8px 4px calc(8px + env(safe-area-inset-bottom));
    justify-content:space-around;align-items:stretch;
    box-shadow:0 -4px 16px rgba(0,0,0,.06);
  }
  .gbn-item{
    display:flex;flex-direction:column;align-items:center;gap:3px;position:relative;
    color:#64748B;font-size:10.5px;font-weight:600;text-decoration:none;
    padding:4px 10px;border-radius:12px;flex:1;transition:color .15s;
  }
  .gbn-item svg{width:22px;height:22px;flex-shrink:0}
  .gbn-item.gbn-active{color:#2563EB}
  .gbn-item:active{background:#F8FAFC}
  .gbn-badge{position:absolute;top:0;right:18%;background:#EF4444;color:#fff;font-size:9px;font-weight:700;border-radius:10px;padding:1px 5px;min-width:14px;text-align:center}
  @media(max-width:768px){
    #gsc-bottom-nav{display:flex}
    body{padding-bottom:calc(64px + env(safe-area-inset-bottom))}
  }
  </style>

  <div class="gsc-container" id="gsc-container">

  <?php if ( $acct_needs_verify && $section !== 'dashboard' ): ?>
  <!-- ══ VERIFICATION REMINDER (persists across every other section) ══════ -->
  <div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:8px;padding:10px 14px;margin-bottom:16px;font-size:.83rem;color:#92400E;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
    <span>⚠ <?php
      if ( ! $acct_email_verified && $show_whatsapp_verify && ! $acct_phone_verified ) {
        echo 'Email and WhatsApp verification pending.';
      } elseif ( ! $acct_email_verified ) {
        echo 'Email verification pending.';
      } else {
        echo 'WhatsApp verification pending.';
      }
    ?> Complete verification to increase trust and ensure smooth communication.</span>
    <a href="?section=dashboard" style="color:#92400E;font-weight:700;text-decoration:underline;white-space:nowrap">Verify now →</a>
  </div>
  <?php endif; ?>

  <?php if ($section === 'dashboard'): ?>
  <!-- ══ DASHBOARD HOME ═════════════════════════════════════════════════ -->
  <div class="gsc-ph">
    <div>
      <div class="gsc-ph-title">Welcome back, <?php echo esc_html(explode(' ',$profile_name ?: $user->display_name)[0]); ?>! 👋</div>
      <div class="gsc-ph-sub">Here's a summary of your activity on <?php echo esc_html(get_bloginfo('name')); ?></div>
    </div>
  </div>

  <!-- ══ ACCOUNT VERIFICATION ═══════════════════════════════════════════ -->
  <div class="gsc-card" id="gsc-verify-card" style="border-left:4px solid <?php echo $acct_fully_verified ? '#059669' : '#F59E0B'; ?>;margin-bottom:16px">
    <?php if ( ! $acct_fully_verified ): ?>
    <div style="background:#FFFBEB;border-radius:8px;padding:10px 14px;margin-bottom:14px;font-size:.85rem;color:#92400E">
      ⚠ Verify your account so your inquiries are considered authentic, vendors can trust them, and future communication is easier.
    </div>
    <?php endif; ?>
    <div class="gsc-card-title">Account Verification</div>
    <div id="gsc-verify-status-line" style="margin:10px 0 16px">
      <div style="font-size:.88rem;margin-bottom:6px" id="gsc-verify-email-line"><?php echo $acct_email_verified ? '✓ Email Verified' : '⚠ Email Not Verified'; ?></div>
      <?php if ( $show_whatsapp_verify ): ?>
      <div style="font-size:.88rem" id="gsc-verify-phone-line"><?php echo $acct_phone_verified ? '✓ WhatsApp Verified' : '⚠ WhatsApp Not Verified'; ?></div>
      <?php endif; ?>
    </div>
    <?php if ( $acct_fully_verified ): ?>
      <div style="color:#059669;font-weight:700;font-size:.9rem">Status: Verified Account</div>
    <?php else: ?>
      <div style="font-size:.83rem;color:#64748B;margin-bottom:14px">Complete verification to make your inquiries appear as <strong>Verified Inquiry</strong> to suppliers instead of <em>Verification Pending</em>.</div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <?php if ( ! $acct_email_verified ): ?>
        <button class="gsc-btn gsc-btn-primary" onclick="gscShowEmailVerify()">Verify Email</button>
        <?php endif; ?>
        <?php if ( $show_whatsapp_verify && ! $acct_phone_verified ): ?>
        <button class="gsc-btn" style="background:#059669;color:#fff" onclick="gscShowWaVerify()">Verify WhatsApp</button>
        <?php endif; ?>
      </div>
      <div id="gsc-verify-inline-panel" style="margin-top:14px"></div>
    <?php endif; ?>
  </div>
  <script>
  (function(){
    var nonce = '<?php echo esc_js( wp_create_nonce( "gs_ajax" ) ); ?>';
    function gscVerifyPost(action, data, onOk, onErr) {
      var body = new URLSearchParams(Object.assign({ action: action, nonce: nonce }, data || {}));
      fetch('<?php echo esc_js( admin_url("admin-ajax.php") ); ?>', { method: 'POST', body: body, headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(function(r){ return r.json(); })
        .then(function(r){
          if (r && r.success) { onOk(r.data || {}); }
          else { onErr((r && r.data && r.data.message) ? r.data.message : 'Something went wrong.'); }
        })
        .catch(function(e){ onErr('Network error: ' + e.message); });
    }
    function gscReload(which) {
      if (which === 'email') document.getElementById('gsc-verify-email-line').textContent = '✓ Email Verified';
      if (which === 'phone') { var l = document.getElementById('gsc-verify-phone-line'); if (l) l.textContent = '✓ WhatsApp Verified'; }
      // Reload to refresh the card into its fully-verified state and any reminder banners elsewhere on the page.
      setTimeout(function(){ location.reload(); }, 900);
    }

    // Real fix — Resend OTP cooldown: previously the "Resend Code" link had
    // no cooldown UI at all — always clickable, with the only real limit
    // being the backend's blunt rejection after 3 attempts in 10 minutes.
    // This shows a live countdown using the cooldown the server actually
    // enforces (Settings → SMS/OTP → Resend Cooldown), and disables the
    // link until it expires.
    function gscStartResendCooldown(linkEl, seconds, onResend) {
      if (!linkEl || !seconds) return;
      var remaining = seconds;
      var originalText = 'Resend Code';
      linkEl.style.pointerEvents = 'none';
      linkEl.style.color = '#94A3B8';
      linkEl.textContent = 'Resend in ' + remaining + 's';
      var timer = setInterval(function() {
        remaining--;
        if (remaining <= 0) {
          clearInterval(timer);
          linkEl.style.pointerEvents = '';
          linkEl.style.color = '#2563EB';
          linkEl.textContent = originalText;
          linkEl.onclick = function() { onResend(); return false; };
        } else {
          linkEl.textContent = 'Resend in ' + remaining + 's';
        }
      }, 1000);
    }

    window.gscShowEmailVerify = function() {
      var panel = document.getElementById('gsc-verify-inline-panel');
      panel.innerHTML = '<div style="font-size:.8rem;color:#64748B;margin-bottom:8px">We\'ll send a verification code to your registered email.</div>'
        + '<button class="gsc-btn gsc-btn-primary" id="gsc-em-send-btn" onclick="gscSendEmailOtp()">Send Code</button>'
        + '<div id="gsc-em-msg" style="font-size:.8rem;margin-top:8px"></div>';
    };
    window.gscSendEmailOtp = function() {
      var btn = document.getElementById('gsc-em-send-btn');
      if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }
      gscVerifyPost('gs_send_account_email_otp', {}, function(d) {
        var panel = document.getElementById('gsc-verify-inline-panel');
        panel.innerHTML = '<div style="font-size:.8rem;color:#64748B;margin-bottom:8px">' + (d.message || 'Code sent. Check your email.') + '</div>'
          + '<input type="text" id="gsc-em-code" placeholder="Enter 6-digit code" maxlength="6" style="padding:8px 10px;border:1px solid #E2E8F0;border-radius:6px;font-size:.85rem;margin-right:8px">'
          + '<button class="gsc-btn gsc-btn-primary" id="gsc-em-verify-btn" onclick="gscVerifyEmailOtp()">Verify</button>'
          + '<div id="gsc-em-msg" style="font-size:.8rem;margin-top:8px;color:#DC2626"></div>'
          + '<a href="#" id="gsc-em-resend" style="font-size:.78rem;color:#2563EB;display:inline-block;margin-top:8px">Resend Code</a>';
        gscStartResendCooldown(document.getElementById('gsc-em-resend'), d.cooldown_seconds || 60, gscSendEmailOtp);
      }, function(err) {
        if (btn) { btn.disabled = false; btn.textContent = 'Send Code'; }
        var msgEl = document.getElementById('gsc-em-msg');
        if (msgEl) { msgEl.textContent = err; msgEl.style.color = '#DC2626'; }
      });
    };
    window.gscVerifyEmailOtp = function() {
      var code = document.getElementById('gsc-em-code').value.trim();
      if (!code) return;
      var btn = document.getElementById('gsc-em-verify-btn');
      btn.disabled = true; btn.textContent = 'Verifying…';
      gscVerifyPost('gs_verify_account_email_otp', { code: code }, function() {
        document.getElementById('gsc-em-msg').style.color = '#059669';
        document.getElementById('gsc-em-msg').textContent = 'Email verified!';
        gscReload('email');
      }, function(err) {
        btn.disabled = false; btn.textContent = 'Verify';
        document.getElementById('gsc-em-msg').textContent = err;
      });
    };
    window.gscShowWaVerify = function() {
      var panel = document.getElementById('gsc-verify-inline-panel');
      panel.innerHTML = '<div style="font-size:.8rem;color:#64748B;margin-bottom:8px">Enter your WhatsApp number to receive a verification code.</div>'
        + '<input type="text" id="gsc-wa-phone" placeholder="WhatsApp number" style="padding:8px 10px;border:1px solid #E2E8F0;border-radius:6px;font-size:.85rem;margin-right:8px">'
        + '<button class="gsc-btn" style="background:#059669;color:#fff" id="gsc-wa-send-btn" onclick="gscSendWaOtp()">Send OTP</button>'
        + '<div id="gsc-wa-msg" style="font-size:.8rem;margin-top:8px;color:#DC2626"></div>';
    };
    window.gscSendWaOtp = function() {
      var phoneEl = document.getElementById('gsc-wa-phone');
      var phone = phoneEl ? phoneEl.value.trim() : window._gscWaPhone;
      if (!phone) return;
      window._gscWaPhone = phone; // remembered so the resend link (no phone input visible anymore) can reuse it
      var btn = document.getElementById('gsc-wa-send-btn');
      if (btn) { btn.disabled = true; btn.textContent = 'Sending…'; }
      gscVerifyPost('gs_send_account_whatsapp_otp', { phone: phone }, function(d) {
        var panel = document.getElementById('gsc-verify-inline-panel');
        panel.innerHTML = '<div style="font-size:.8rem;color:#64748B;margin-bottom:8px">' + (d.message || 'Code sent via WhatsApp.') + '</div>'
          + '<input type="text" id="gsc-wa-code" placeholder="Enter 6-digit code" maxlength="6" style="padding:8px 10px;border:1px solid #E2E8F0;border-radius:6px;font-size:.85rem;margin-right:8px">'
          + '<button class="gsc-btn" style="background:#059669;color:#fff" id="gsc-wa-verify-btn" onclick="gscVerifyWaOtp()">Verify</button>'
          + '<div id="gsc-wa-msg2" style="font-size:.8rem;margin-top:8px;color:#DC2626"></div>'
          + '<a href="#" id="gsc-wa-resend" style="font-size:.78rem;color:#2563EB;display:inline-block;margin-top:8px">Resend Code</a>';
        gscStartResendCooldown(document.getElementById('gsc-wa-resend'), d.cooldown_seconds || 60, gscSendWaOtp);
      }, function(err) {
        if (btn) { btn.disabled = false; btn.textContent = 'Send OTP'; }
        var msgEl = document.getElementById('gsc-wa-msg');
        if (msgEl) { msgEl.textContent = err; }
      });
    };
    window.gscVerifyWaOtp = function() {
      var code = document.getElementById('gsc-wa-code').value.trim();
      if (!code) return;
      var btn = document.getElementById('gsc-wa-verify-btn');
      btn.disabled = true; btn.textContent = 'Verifying…';
      gscVerifyPost('gs_verify_account_whatsapp_otp', { code: code }, function() {
        document.getElementById('gsc-wa-msg2').style.color = '#059669';
        document.getElementById('gsc-wa-msg2').textContent = 'WhatsApp verified!';
        gscReload('phone');
      }, function(err) {
        btn.disabled = false; btn.textContent = 'Verify';
        document.getElementById('gsc-wa-msg2').textContent = err;
      });
    };
  })();
  </script>

  <div class="gsc-stat-grid">
    <div class="gsc-sc"><div class="gsc-sc-icon" style="background:#EFF6FF">📬</div><div><div class="gsc-sc-val" style="color:#2563EB"><?php echo $total_leads; ?></div><div class="gsc-sc-lbl">Total Inquiries</div></div></div>
    <div class="gsc-sc"><div class="gsc-sc-icon" style="background:<?php echo $new_replies>0?'#FFFBEB':'#F0FDF4'; ?>">💬</div><div><div class="gsc-sc-val" style="color:<?php echo $new_replies>0?'#D97706':'#059669'; ?>"><?php echo $new_replies; ?></div><div class="gsc-sc-lbl">New Replies</div></div></div>
    <div class="gsc-sc"><div class="gsc-sc-icon" style="background:#FEF2F2">❤️</div><div><div class="gsc-sc-val" style="color:#DC2626"><?php echo $total_saved; ?></div><div class="gsc-sc-lbl">Saved Listings</div></div></div>
  </div>

  <?php if ($my_leads): ?>
  <div class="gsc-card">
    <div class="gsc-card-title">📬 Recent Inquiries <a href="?section=inquiries" style="font-size:.75rem;font-weight:400;color:#2563EB">View all →</a></div>
    <?php foreach (array_slice($my_leads,0,5) as $ld):
      $sc = ['new'=>'badge-new','seen'=>'badge-viewed','viewed'=>'badge-viewed','replied'=>'badge-replied',
             'contacted'=>'badge-replied','converted'=>'badge-converted','qualified'=>'badge-converted','junk'=>'badge-junk'];
      $bc = $sc[$ld->status??'new'] ?? 'badge-viewed';
    ?>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid #F1F5F9">
      <div style="flex:1;min-width:0;margin-right:10px">
        <div style="font-weight:600;font-size:.86rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html($ld->listing_title??'—'); ?></div>
        <div style="font-size:.74rem;color:#64748B;margin-top:2px"><?php echo esc_html($ld->vendor_name??''); ?> · <?php echo esc_html(gs_time_ago($ld->created_at)); ?></div>
      </div>
      <span class="gsc-status-badge <?php echo $bc; ?>"><?php echo ucfirst($ld->status??'new'); ?></span>
    </div>
    <?php endforeach; ?>
  </div>
  <?php else: ?>
  <div class="gsc-card" style="text-align:center;padding:40px 24px">
    <div style="font-size:2.5rem;margin-bottom:12px">📬</div>
    <div style="font-weight:700;font-size:1rem;color:#1E293B;margin-bottom:6px">No inquiries yet</div>
    <div style="font-size:.84rem;color:#64748B;margin-bottom:18px">Browse the directory and contact businesses you're interested in.</div>
    <a href="<?php echo esc_url(home_url('/directory/')); ?>" class="gsc-btn gsc-btn-primary">Browse Directory →</a>
  </div>
  <?php endif; ?>

  <?php elseif ($section === 'inquiries'): ?>
  <!-- ══ MY INQUIRIES ═══════════════════════════════════════════════════ -->
  <div class="gsc-ph">
    <div><div class="gsc-ph-title">📬 My Inquiries</div><div class="gsc-ph-sub"><?php echo $total_leads; ?> inquiry<?php echo $total_leads!==1?'s':''; ?> submitted</div></div>
  </div>

  <?php if ($my_leads): ?>
  <div class="gsc-inq-wrap">
    <!-- Left: inquiry list -->
    <div class="gsc-inq-left">
      <div class="gsc-inq-list" id="gsc-inq-list">
        <?php foreach ($my_leads as $ld):
          $bar_c = ['new'=>'#2563EB','seen'=>'#94A3B8','viewed'=>'#94A3B8','replied'=>'#059669',
                    'contacted'=>'#059669','converted'=>'#7C3AED','qualified'=>'#7C3AED','junk'=>'#DC2626'][$ld->status??'new'] ?? '#94A3B8';
        ?>
        <div class="gsc-inq-item<?php echo ($ld->unread_replies??0) ? ' gsc-inq-unread' : ''; ?>" data-id="<?php echo (int)$ld->id; ?>" onclick="gscOpenInquiry(this,<?php echo (int)$ld->id; ?>)">
          <div class="gsc-inq-bar" style="background:<?php echo $bar_c; ?>"></div>
          <div class="gsc-inq-body">
            <div class="gsc-inq-name"><?php echo esc_html($ld->listing_title??'Unknown Listing'); ?></div>
            <div class="gsc-inq-prod">
              <?php
              // Real fix: matches the vendor's smart subject-line fallback
              // exactly (gsiqBuildItem() in inquiry-manager.php) — previously
              // this line showed only the vendor name with no fallback,
              // meaning an inquiry with no product_name showed nothing
              // meaningful in the subtitle at all.
              if ($ld->inquiry_module) {
                echo '📋 ' . esc_html( ucwords( str_replace( '-', ' ', $ld->inquiry_module ) ) );
              } elseif ($ld->product_name) {
                echo '📦 ' . esc_html( substr($ld->product_name, 0, 28) );
              } else {
                echo '📨 General Inquiry';
              }
              ?>
            </div>
            <div class="gsc-inq-time"><?php echo esc_html(gs_time_ago($ld->created_at)); ?></div>
          </div>
          <?php if($ld->unread_replies??0): ?><div class="gsc-inq-unread-dot" title="<?php echo (int)$ld->unread_replies; ?> new repl<?php echo (int)$ld->unread_replies===1?'y':'ies'; ?>"></div><?php endif; ?>
          <?php
          $sc = ['new'=>'badge-new','seen'=>'badge-viewed','viewed'=>'badge-viewed','replied'=>'badge-replied',
                 'contacted'=>'badge-replied','converted'=>'badge-converted','qualified'=>'badge-converted','junk'=>'badge-junk'];
          $bc = $sc[$ld->status??'new'] ?? 'badge-viewed';
          ?>
          <span class="gsc-status-badge <?php echo $bc; ?>" style="flex-shrink:0;font-size:.64rem"><?php echo ucfirst($ld->status??'new'); ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <!-- Right: detail panel -->
    <div class="gsc-inq-right">
      <div class="gsc-inq-right-empty" id="gsc-inq-empty">
        <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
        <div style="font-weight:600;font-size:.92rem;margin-top:12px;color:#64748B">Select an inquiry to view details</div>
      </div>
      <div class="gsc-inq-detail" id="gsc-inq-detail">
        <div class="gsc-inq-detail-scroll" id="gsc-inq-scroll">
          <div id="gsc-inq-content"></div>
        </div>
      </div>
    </div>
  </div>
  <?php else: ?>
  <div class="gsc-card" style="text-align:center;padding:50px 24px">
    <div style="font-size:2.5rem;margin-bottom:12px">📬</div>
    <div style="font-weight:700;color:#1E293B;margin-bottom:6px">No inquiries yet</div>
    <div style="font-size:.84rem;color:#64748B;margin-bottom:18px">Browse businesses and submit inquiries to see them here.</div>
    <a href="<?php echo esc_url(home_url('/directory/')); ?>" class="gsc-btn gsc-btn-primary">Browse Directory →</a>
  </div>
  <?php endif; ?>

  <!-- Inline inquiry data for JS rendering -->
  <script>
  var _gscLeads = <?php echo wp_json_encode( array_map( function($ld) use ($wpdb,$pfx) {
      $replies = $wpdb->get_results($wpdb->prepare(
          "SELECT * FROM {$pfx}lead_replies WHERE lead_id=%d AND is_internal=0 ORDER BY created_at ASC",
          $ld->id
      )) ?: [];
      $ef = !empty($ld->extra_fields) ? json_decode($ld->extra_fields,true) : [];
      // Real fix: custom_fields is a completely separate column from
      // extra_fields, used specifically by module-based inquiries (when
      // inquiry_module is set) — confirmed by tracing the vendor's actual
      // rendering code (inquiry-manager.php), which reads custom_fields for
      // exactly this case. My client-side code never fetched this at all.
      $cf = !empty($ld->custom_fields) ? json_decode($ld->custom_fields,true) : [];
      return [
          'id'            => (int)$ld->id,
          'listing_title' => $ld->listing_title ?? '',
          'listing_slug'  => $ld->listing_slug  ?? '',
          'vendor_name'   => $ld->vendor_name   ?? '',
          'vendor_phone'  => $ld->vendor_phone  ?? '',
          'vendor_wa'     => $ld->vendor_wa     ?? '',
          'vendor_logo'   => $ld->vendor_logo   ?? '',
          'status'        => $ld->status        ?? 'new',
          'product_name'  => $ld->product_name  ?? '',
          'message'       => $ld->message       ?? '',
          'city'          => $ld->city          ?? '',
          'quantity'      => $ld->quantity      ?? '',
          'product_price' => $ld->product_price ?? '',
          'created_at'    => $ld->created_at    ?? '',
          'extra_fields'  => is_array($ef) ? $ef : [],
          'inquiry_module'=> $ld->inquiry_module ?? '',
          'custom_fields' => is_array($cf) ? $cf : [],
          'replies'       => array_map(fn($r) => [
              'sender_type' => $r->sender_type,
              'sender_name' => $r->sender_name,
              'message'     => $r->message,
              'sent_via'    => $r->sent_via,
              'created_at'  => $r->created_at,
          ], $replies),
      ];
  }, $my_leads ) ); ?>;

  var _gscHomeUrl = <?php echo wp_json_encode( rtrim( home_url('/'), '/' ) ); ?>;

  function gscEsc(s){ var d=document.createElement('div'); d.textContent=String(s||''); return d.innerHTML; }
  // Real fix: replicates the vendor's fmtKey/fmtVal functions exactly
  // (inquiry-manager.php) — this is what turns a raw field key like
  // "stay_dates_from" into the polished label "Stay Dates (From)" seen in
  // the vendor's actual rendering.
  function gscFmtKey(k){
    return k.replace(/_(from|to|date|time)$/, ' ($1)')
            .replace(/_/g, ' ')
            .replace(/\b\w/g, function(c){ return c.toUpperCase(); });
  }
  function gscFmtVal(v){
    if (Array.isArray(v)) return v.join(', ');
    if (v === '1' || v === true) return 'Yes';
    if (v === '0' || v === false) return 'No';
    return String(v);
  }
  function gscTimeAgo(ts){
    if(!ts)return '';
    var d=new Date(ts.replace(' ','T')+'Z'), now=new Date(), diff=Math.floor((now-d)/1000);
    if(diff<60)return 'just now';
    if(diff<3600)return Math.floor(diff/60)+'m ago';
    if(diff<86400)return Math.floor(diff/3600)+'h ago';
    if(diff<604800)return Math.floor(diff/86400)+'d ago';
    return d.toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'});
  }
  // Real fix: produces the exact MySQL datetime format (space-separated,
  // no timezone marker) that gscTimeAgo() expects — matching what the
  // server actually returns for real replies. Uses UTC getters since the
  // server stores/returns UTC and gscTimeAgo() appends 'Z' assuming the
  // value it's given is already UTC.
  function gscMysqlNow(){
    var d = new Date();
    function p(n){ return String(n).padStart(2,'0'); }
    return d.getUTCFullYear()+'-'+p(d.getUTCMonth()+1)+'-'+p(d.getUTCDate())+' '+
           p(d.getUTCHours())+':'+p(d.getUTCMinutes())+':'+p(d.getUTCSeconds());
  }

  function gscOpenInquiry(el, id) {
    document.querySelectorAll('.gsc-inq-item').forEach(function(i){ i.classList.remove('on'); });
    el.classList.add('on');
    var lead = _gscLeads.find(function(l){ return l.id === id; });
    if (!lead) return;
    document.getElementById('gsc-inq-empty').style.display  = 'none';
    document.getElementById('gsc-inq-detail').style.display = 'flex';

    // Real bug fix: the bottom nav Call button previously always pointed to
    // the most recent inquiry's vendor regardless of which inquiry is
    // actually being viewed — a client scrolled into an older conversation
    // with a different vendor could tap Call and reach the wrong person
    // entirely. Update it to the currently open inquiry's real vendor.
    var callBtn = document.getElementById('gbn-call-btn');
    var callLabel = document.getElementById('gbn-call-label');
    if (callBtn) {
      if (lead.vendor_phone) {
        callBtn.setAttribute('href', 'tel:' + lead.vendor_phone);
        callBtn.setAttribute('title', 'Call ' + (lead.vendor_name || 'this vendor'));
        if (callLabel) callLabel.textContent = 'Call';
      } else {
        // This specific vendor has no phone on file — do not leave a stale,
        // wrong number active from whichever inquiry was open before.
        callBtn.setAttribute('href', '?section=inquiries&thread=' + lead.id);
        callBtn.setAttribute('title', (lead.vendor_name || 'This vendor') + ' has no phone number on file');
        if (callLabel) callLabel.textContent = 'Contact';
      }
    }

    var waPhone = (lead.vendor_wa||lead.vendor_phone||'').replace(/[^0-9]/g,'');
    var statusColors = {new:'#DBEAFE',viewed:'#E2E8F0',seen:'#E2E8F0',replied:'#DCFCE7',
                        contacted:'#DCFCE7',converted:'#F3E8FF',qualified:'#F3E8FF',junk:'#FEE2E2'};
    var statusTextColors = {new:'#1D4ED8',viewed:'#475569',seen:'#475569',replied:'#166534',
                            contacted:'#166534',converted:'#7C3AED',qualified:'#7C3AED',junk:'#DC2626'};
    var sBg = statusColors[lead.status]||'#E2E8F0';
    var sTx = statusTextColors[lead.status]||'#475569';

    var extraHtml = '';
    // Real fix, module-based inquiry fields — the actual root cause found by
    // tracing the vendor's real rendering code (inquiry-manager.php): this
    // exact card, using custom_fields (not extra_fields), was completely
    // absent from the client dashboard. gscFmtKey/gscFmtVal replicate the
    // vendor's fmtKey/fmtVal functions exactly.
    if (lead.inquiry_module && lead.custom_fields && Object.keys(lead.custom_fields).length) {
      var modName = lead.inquiry_module.replace(/-/g,' ').replace(/\b\w/g, function(c){return c.toUpperCase();});
      var cfKeys = Object.keys(lead.custom_fields).filter(function(k){ return k !== '_message'; });
      extraHtml += '<div style="border:1.5px solid #DBEAFE;border-radius:10px;padding:16px;margin-bottom:14px;background:#F8FBFF">';
      extraHtml += '<div style="font-size:.72rem;font-weight:800;color:#1D4ED8;text-transform:uppercase;letter-spacing:.06em;margin-bottom:12px">📋 ' + gscEsc(modName) + ' — Inquiry Details</div>';
      if (cfKeys.length) {
        extraHtml += '<table style="width:100%;table-layout:fixed;border-collapse:collapse;font-size:.82rem">';
        cfKeys.forEach(function(k){
          var raw = lead.custom_fields[k];
          var val = gscFmtVal(raw);
          if (val === '' || val === null || val === undefined) return; // skip only genuinely empty values — 'No' is a real answer
          extraHtml += '<tr>';
          extraHtml += '<td style="padding:5px 10px 5px 0;color:#64748B;font-weight:600;word-break:break-word;vertical-align:top;width:42%;border-bottom:1px solid #EFF6FF">' + gscEsc(gscFmtKey(k)) + '</td>';
          extraHtml += '<td style="padding:5px 0 5px 10px;color:#1E293B;border-bottom:1px solid #EFF6FF;word-break:break-word;overflow-wrap:break-word">' + gscEsc(val) + '</td>';
          extraHtml += '</tr>';
        });
        extraHtml += '</table>';
      }
      if (lead.custom_fields._message && String(lead.custom_fields._message).trim()) {
        extraHtml += '<div style="margin-top:10px;padding-top:10px;border-top:1px solid #DBEAFE">';
        extraHtml += '<span style="font-size:.72rem;font-weight:700;color:#1D4ED8;text-transform:uppercase">Message</span>';
        extraHtml += '<p style="font-size:.82rem;color:#1E293B;margin:5px 0 0">' + gscEsc(lead.custom_fields._message) + '</p>';
        extraHtml += '</div>';
      }
      extraHtml += '</div>';
    }
    // Legacy extra_fields — only for non-module leads, matching the vendor's
    // own explicit mutual-exclusivity behavior (a lead is either module-based
    // using custom_fields, or legacy using extra_fields, never both).
    if (!lead.inquiry_module && lead.extra_fields && Object.keys(lead.extra_fields).length) {
      extraHtml += '<div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:8px;padding:12px;margin-bottom:12px">' +
        '<div style="font-size:.7rem;font-weight:700;color:#92400E;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">Additional Details</div>';
      Object.keys(lead.extra_fields).forEach(function(k){
        extraHtml += '<div style="font-size:.82rem;color:#334155;margin-bottom:4px"><strong>' + gscEsc(k) + ':</strong> ' + gscEsc(lead.extra_fields[k]) + '</div>';
      });
      extraHtml += '</div>';
    }

    var repliesHtml = '';
    if (lead.replies && lead.replies.length) {
      repliesHtml = '<div style="margin-top:16px"><div style="font-size:.75rem;font-weight:700;color:#94A3B8;text-transform:uppercase;letter-spacing:.05em;margin-bottom:10px">Conversation</div>';
      lead.replies.forEach(function(r){
        var isVendor = r.sender_type === 'vendor';
        var bg   = isVendor ? '#EFF6FF' : '#F0FDF4';
        var align = isVendor ? 'flex-start' : 'flex-end';
        var meta = gscEsc(r.sender_name || (isVendor ? 'Vendor' : 'You')) + ' · ' + gscTimeAgo(r.created_at);
        repliesHtml += '<div style="display:flex;flex-direction:column;align-items:' + align + ';margin-bottom:10px">' +
          '<div style="background:' + bg + ';border-radius:10px;padding:10px 14px;font-size:.83rem;color:#334155;line-height:1.65;max-width:88%">' +
          gscEsc(r.message).replace(/\n/g,'<br>') + '</div>' +
          '<div style="font-size:.67rem;color:#94A3B8;margin-top:3px">' + meta + '</div>' +
          '</div>';
      });
      repliesHtml += '</div>';
    }

    var logoHtml = lead.vendor_logo
      ? '<img src="' + gscEsc(lead.vendor_logo) + '" class="gsc-vendor-logo" alt="">'
      : '<div class="gsc-vendor-logo" style="display:flex;align-items:center;justify-content:center;font-size:1.2rem">🏢</div>';

    document.getElementById('gsc-inq-content').innerHTML =
      // Vendor card
      '<div class="gsc-vendor-card">' +
        logoHtml +
        '<div style="flex:1;min-width:0">' +
          '<div class="gsc-vendor-name">' + gscEsc(lead.listing_title) + '</div>' +
          '<div class="gsc-vendor-meta">' + gscEsc(lead.vendor_name) + '</div>' +
        '</div>' +
        '<span style="padding:3px 10px;border-radius:20px;font-size:.72rem;font-weight:700;background:' + sBg + ';color:' + sTx + '">' + (lead.status||'new') + '</span>' +
      '</div>' +

      // Info grid
      '<div class="gsc-info-grid">' +
        (lead.product_name ? '<div class="gsc-info-cell"><div class="gsc-info-lbl">Product / Service</div><div class="gsc-info-val">' + gscEsc(lead.product_name) + '</div></div>' : '') +
        (lead.city         ? '<div class="gsc-info-cell"><div class="gsc-info-lbl">Your City</div><div class="gsc-info-val">' + gscEsc(lead.city) + '</div></div>' : '') +
        (lead.quantity     ? '<div class="gsc-info-cell"><div class="gsc-info-lbl">Quantity</div><div class="gsc-info-val">' + gscEsc(lead.quantity) + '</div></div>' : '') +
        (lead.product_price? '<div class="gsc-info-cell"><div class="gsc-info-lbl">Budget</div><div class="gsc-info-val">' + gscEsc(lead.product_price) + '</div></div>' : '') +
        '<div class="gsc-info-cell"><div class="gsc-info-lbl">Submitted</div><div class="gsc-info-val">' + gscTimeAgo(lead.created_at) + '</div></div>' +
      '</div>' +

      // Original message
      (lead.message ? '<div class="gsc-inq-msg"><div style="font-size:.7rem;font-weight:700;color:#94A3B8;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px">Your Message</div>' + gscEsc(lead.message).replace(/\n/g,'<br>') + '</div>' : '') +

      extraHtml +
      repliesHtml +

      // Reply box — real fix: this was entirely missing. Mirrors the
      // vendor's actual reply pattern (gsiqSendReply in inquiry-manager.php)
      // structurally, but calls the already-existing, already
      // security-checked gs_customer_reply_lead action (customerReplyLead()
      // in AjaxController.php) rather than the vendor-only gs_reply_to_inquiry.
      '<div style="margin-top:16px;padding-top:14px;border-top:1px solid #E2E8F0">' +
        '<textarea id="gsc-reply-ta" rows="3" placeholder="Write a reply…" style="width:100%;border:1.5px solid #E2E8F0;border-radius:9px;padding:10px 12px;font-size:.85rem;font-family:inherit;outline:none;resize:vertical"></textarea>' +
        '<div style="display:flex;justify-content:flex-end;margin-top:8px">' +
          '<button class="gsc-btn gsc-btn-primary" onclick="gscSendReply(' + lead.id + ')">Send Reply</button>' +
        '</div>' +
      '</div>' +

      // Quick actions
      '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px;padding-top:14px;border-top:1px solid #E2E8F0">' +
        (lead.vendor_phone ? '<a href="tel:' + gscEsc(lead.vendor_phone) + '" class="gsc-btn gsc-btn-green">📞 Call Vendor</a>' : '') +
        (waPhone ? '<a href="https://wa.me/' + gscEsc(waPhone) + '?text=' + encodeURIComponent('Hi, I submitted an inquiry for ' + (lead.product_name||lead.listing_title) + '. Could you please get back to me?') + '" target="_blank" class="gsc-btn" style="background:#25D366;color:#fff">💬 WhatsApp</a>' : '') +
        '<a href="' + _gscHomeUrl + '/' + (lead.listing_slug||'') + '/" target="_blank" class="gsc-btn gsc-btn-ghost">View Listing →</a>' +
      '</div>';

    setTimeout(function(){
      var scroll = document.getElementById('gsc-inq-scroll');
      if(scroll) scroll.scrollTop = 0;
    }, 50);
  }

  // Real fix: this was entirely missing — the reply box had no send
  // function behind it. Calls the already-existing, already
  // security-checked gs_customer_reply_lead action (customerReplyLead() in
  // AjaxController.php), which already has the same ownership check
  // pattern the vendor's replyToInquiry() uses.
  window.gscSendReply = function(leadId) {
    var ta = document.getElementById('gsc-reply-ta');
    var msg = ta ? ta.value.trim() : '';
    if (!msg) { alert('Please type a reply first.'); return; }
    jQuery.post(GS.ajax_url, { action:'gs_customer_reply_lead', nonce:GS.nonce, lead_id:leadId, message:msg }, function(d){
      if (!d.success) { alert((d.data && d.data.message) || 'Failed to send reply.'); return; }
      var lead = _gscLeads.find(function(l){ return l.id === leadId; });
      if (lead) {
        lead.replies = lead.replies || [];
        lead.replies.push({ sender_type:'customer', sender_name:'You', message:msg, sent_via:'my_account', created_at:gscMysqlNow() });
      }
      if (ta) ta.value = '';
      var el = document.querySelector('.gsc-inq-item.on');
      if (el) gscOpenInquiry(el, leadId);
    }, 'json');
  };

  // Auto-open first inquiry if ?view= param is set
  (function(){
    var params = new URLSearchParams(window.location.search);
    var viewId = parseInt(params.get('view')||'0');
    if(viewId){
      var el = document.querySelector('.gsc-inq-item[data-id="'+viewId+'"]');
      if(el) gscOpenInquiry(el, viewId);
    }
  })();
  </script>

  <?php elseif ($section === 'bookings'): ?>
  <!-- ══ MY BOOKINGS — real feature, closes the last major audit gap ══════ -->
  <div class="gsc-ph">
    <div><div class="gsc-ph-title">📅 My Bookings</div><div class="gsc-ph-sub"><?php echo $total_bookings; ?> booking<?php echo $total_bookings!==1?'s':''; ?></div></div>
  </div>

  <?php if ($my_bookings): ?>
  <div style="display:flex;flex-direction:column;gap:12px">
    <?php foreach ($my_bookings as $bk):
      $bk_sc = ['pending'=>'#D97706','confirmed'=>'#059669','cancelled'=>'#DC2626','completed'=>'#64748B','no_show'=>'#DC2626'][$bk->status] ?? '#94A3B8';
    ?>
    <div class="gsc-card" style="padding:16px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px">
        <div>
          <div style="font-weight:700;color:#1E293B"><?php echo esc_html($bk->listing_title ?: $bk->service_name ?: 'Booking'); ?></div>
          <div style="font-size:.8rem;color:#64748B;margin-top:2px"><?php echo esc_html($bk->vendor_name ?: 'Vendor'); ?><?php if($bk->booking_date): ?> — <?php echo esc_html(date('d M Y', strtotime($bk->booking_date))); ?><?php endif; ?></div>
          <?php if ($bk->amount): ?><div style="font-size:.8rem;color:#334155;margin-top:4px">₹<?php echo number_format((float)$bk->amount); ?><?php if($bk->discount_amount>0): ?> <span style="color:#059669">(₹<?php echo number_format((float)$bk->discount_amount); ?> coupon applied)</span><?php endif; ?></div><?php endif; ?>
          <?php if ($bk->dispute_id): ?><div style="font-size:.76rem;color:#DC2626;margin-top:4px">⚖️ Dispute <?php echo esc_html(ucwords(str_replace('_',' ',$bk->dispute_status))); ?></div><?php endif; ?>
        </div>
        <span style="background:<?php echo $bk_sc; ?>1A;color:<?php echo $bk_sc; ?>;padding:4px 10px;border-radius:6px;font-size:.72rem;font-weight:700"><?php echo esc_html(ucfirst($bk->status)); ?></span>
      </div>
      <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
        <?php if ($bk->listing_slug): ?><a href="<?php echo esc_url(home_url('/'.$bk->listing_slug.'/')); ?>" class="gsc-btn gsc-btn-ghost" style="font-size:.78rem;padding:6px 12px">View Listing</a><?php endif; ?>
        <?php if ($bk->vendor_phone): ?><a href="tel:<?php echo esc_attr($bk->vendor_phone); ?>" class="gsc-btn gsc-btn-ghost" style="font-size:.78rem;padding:6px 12px">📞 Call Vendor</a><?php endif; ?>
        <?php /* ENTERPRISE-AUDIT FIX (Critical, confirmed): no cancel action existed anywhere on this screen for a still-upcoming booking — see AjaxController::customerCancelBooking(). */ ?>
        <?php if (in_array($bk->status, ['pending','confirmed'], true)): ?>
        <button onclick="gscCancelBooking(<?php echo (int)$bk->id; ?>,this)" class="gsc-btn gsc-btn-ghost" style="font-size:.78rem;padding:6px 12px;color:#DC2626;border-color:#FECACA">✕ Cancel Booking</button>
        <?php endif; ?>
        <?php if (in_array($bk->status, ['completed','cancelled'], true) && ! $bk->dispute_id): ?>
        <button onclick="gscReportIssue(<?php echo (int)$bk->id; ?>,this)" class="gsc-btn gsc-btn-ghost" style="font-size:.78rem;padding:6px 12px;color:#DC2626;border-color:#FECACA">⚖️ Report Issue</button>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <script>
  function gscReportIssue(bookingId, btn) {
    var reason = prompt('Briefly describe the issue:');
    if (!reason) return;
    btn.disabled = true; btn.textContent = 'Submitting…';
    gsPost('gs_open_dispute', { nonce: '<?php echo esc_js(wp_create_nonce('gs_ajax')); ?>', booking_id: bookingId, reason: reason, description: reason },
      function(){ gsToast('Dispute opened — our team will review it.', 'success'); setTimeout(function(){ location.reload(); }, 1200); },
      function(e){ btn.disabled = false; btn.textContent = '⚖️ Report Issue'; gsToast(e || 'Could not open dispute.', 'error'); }
    );
  }
  function gscCancelBooking(bookingId, btn) {
    if (!confirm('Cancel this booking? This cannot be undone, and the vendor will be notified.')) return;
    btn.disabled = true; btn.textContent = 'Cancelling…';
    gsPost('gs_customer_cancel_booking', { nonce: '<?php echo esc_js(wp_create_nonce('gs_ajax')); ?>', booking_id: bookingId },
      function(){ gsToast('Booking cancelled.', 'success'); setTimeout(function(){ location.reload(); }, 1000); },
      function(e){ btn.disabled = false; btn.textContent = '✕ Cancel Booking'; gsToast(e || 'Could not cancel booking.', 'error'); }
    );
  }
  </script>
  <?php else: ?>
  <div class="gsc-card" style="text-align:center;padding:50px 24px">
    <div style="font-size:2.5rem;margin-bottom:12px">📅</div>
    <div style="font-weight:700;color:#1E293B;margin-bottom:6px">No bookings yet</div>
    <div style="font-size:.84rem;color:#64748B;margin-bottom:18px">Bookings you make with vendors will appear here.</div>
    <a href="<?php echo esc_url(home_url('/directory/')); ?>" class="gsc-btn gsc-btn-primary">Browse Directory →</a>
  </div>
  <?php endif; ?>

  <?php elseif ($section === 'saved'): ?>
  <!-- ══ SAVED LISTINGS ════════════════════════════════════════════════ -->
  <div class="gsc-ph"><div><div class="gsc-ph-title">❤️ Saved Listings</div><div class="gsc-ph-sub"><?php echo $total_saved; ?> saved</div></div></div>
  <?php if ($saved):
    // Real gap fix: group by folder ('' = "Uncategorized") so the added
    // folder attribute is actually visible/usable, not just stored.
    $__saved_groups = [];
    foreach ($saved as $__s) { $__saved_groups[(string)($__s->folder ?: '')][] = $__s; }
    if (isset($__saved_groups['']) && count($__saved_groups) > 1) {
        $__uncat = $__saved_groups['']; unset($__saved_groups['']);
        $__saved_groups['Uncategorized'] = $__uncat;
    }
  ?>
  <?php foreach ($__saved_groups as $__folder => $__items): ?>
  <?php if (count($__saved_groups) > 1 || $__folder !== ''): ?>
  <div style="font-weight:700;font-size:.82rem;color:#334155;margin:18px 0 8px;text-transform:uppercase;letter-spacing:.03em">📁 <?php echo esc_html($__folder ?: 'Uncategorized'); ?> (<?php echo count($__items); ?>)</div>
  <?php endif; ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px;margin-bottom:8px">
    <?php foreach ($__items as $s): ?>
    <div class="gsc-card" style="padding:0;overflow:hidden">
      <div style="height:120px;background:#F1F5F9;overflow:hidden">
        <img src="<?php echo esc_url($s->banner_url ?: GS_URL.'assets/images/placeholder.jpg'); ?>"
             alt="<?php echo esc_attr($s->title); ?>" loading="lazy"
             style="width:100%;height:100%;object-fit:cover">
      </div>
      <div style="padding:12px 14px">
        <div style="font-weight:700;font-size:.87rem;color:#1E293B;margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html($s->title); ?></div>
        <?php if ($s->city): ?><div style="font-size:.74rem;color:#64748B;margin-bottom:6px">📍 <?php echo esc_html($s->city); ?></div><?php endif; ?>
        <?php if (!empty($s->note)): ?><div style="font-size:.74rem;color:#475569;background:#F8FAFC;border-radius:6px;padding:5px 8px;margin-bottom:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?php echo esc_attr($s->note); ?>">📝 <?php echo esc_html($s->note); ?></div><?php endif; ?>
        <div style="display:flex;gap:6px">
          <a href="<?php echo esc_url(home_url('/'.$s->slug.'/')); ?>" class="gsc-btn gsc-btn-ghost" style="flex:1;font-size:.78rem;padding:6px">View</a>
          <?php if ($s->phone): ?><a href="tel:<?php echo esc_attr($s->phone); ?>" class="gsc-btn gsc-btn-green" style="font-size:.78rem;padding:6px 10px">📞</a><?php endif; ?>
          <button type="button" onclick='gscEditSavedModal(<?php echo (int)$s->listing_id; ?>,<?php echo wp_json_encode((string)$s->folder); ?>,<?php echo wp_json_encode((string)$s->note); ?>)' class="gsc-btn gsc-btn-ghost" style="font-size:.78rem;padding:6px 10px" aria-label="Edit folder and note">✏️</button>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endforeach; ?>

  <div id="gsc-saved-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.5);z-index:9999;align-items:center;justify-content:center">
    <div class="gsc-card" style="width:min(420px,92vw);padding:20px">
      <div style="font-weight:700;font-size:1rem;margin-bottom:14px">Organize saved listing</div>
      <input type="hidden" id="gsc-saved-lid">
      <label style="font-size:.8rem;font-weight:600;color:#334155;display:block;margin-bottom:4px">Folder</label>
      <input type="text" id="gsc-saved-folder" maxlength="100" placeholder="e.g. Wedding, Shortlist..." style="width:100%;padding:8px 10px;border:1px solid #E2E8F0;border-radius:8px;margin-bottom:12px;font-size:.85rem">
      <label style="font-size:.8rem;font-weight:600;color:#334155;display:block;margin-bottom:4px">Note</label>
      <textarea id="gsc-saved-note" rows="3" placeholder="Personal note..." style="width:100%;padding:8px 10px;border:1px solid #E2E8F0;border-radius:8px;margin-bottom:14px;font-size:.85rem;resize:vertical"></textarea>
      <div id="gsc-saved-msg" class="gsc-imsg"></div>
      <div style="display:flex;gap:8px">
        <button type="button" onclick="gscCloseSavedModal()" class="gsc-btn gsc-btn-ghost" style="flex:1">Cancel</button>
        <button type="button" onclick="gscSubmitSavedModal()" class="gsc-btn gsc-btn-primary" style="flex:1">Save</button>
      </div>
    </div>
  </div>
  <script>
  function gscEditSavedModal(lid, folder, note) {
    document.getElementById('gsc-saved-lid').value = lid;
    document.getElementById('gsc-saved-folder').value = folder || '';
    document.getElementById('gsc-saved-note').value = note || '';
    document.getElementById('gsc-saved-msg').textContent = '';
    document.getElementById('gsc-saved-modal').style.display = 'flex';
  }
  function gscCloseSavedModal() { document.getElementById('gsc-saved-modal').style.display = 'none'; }
  function gscSubmitSavedModal() {
    var lid = document.getElementById('gsc-saved-lid').value;
    var folder = document.getElementById('gsc-saved-folder').value;
    var note = document.getElementById('gsc-saved-note').value;
    var msg = document.getElementById('gsc-saved-msg');
    msg.textContent = 'Saving...';
    gsPost('gs_update_saved_listing', {listing_id: lid, folder: folder, note: note}, function(r){
      if (r && r.success) { location.reload(); } else { msg.textContent = '❌ ' + (r && r.data && r.data.message ? r.data.message : 'Save failed.'); }
    });
  }
  </script>
  <?php else: ?>
  <div class="gsc-card" style="text-align:center;padding:50px">
    <div style="font-size:2.5rem;margin-bottom:12px">❤️</div>
    <div style="font-weight:700;color:#1E293B;margin-bottom:6px">No saved listings yet</div>
    <div style="font-size:.84rem;color:#64748B;margin-bottom:18px">Browse the directory and click 🤍 to save listings you like.</div>
    <a href="<?php echo esc_url(home_url('/directory/')); ?>" class="gsc-btn gsc-btn-primary">Browse Directory →</a>
  </div>
  <?php endif; ?>

  <?php elseif ($section === 'profile'): ?>
  <!-- ══ MY PROFILE ════════════════════════════════════════════════════ -->
  <div class="gsc-ph">
    <div><div class="gsc-ph-title">👤 My Profile</div><div class="gsc-ph-sub">Update your contact information</div></div>
    <button onclick="gscSaveProfile()" class="gsc-btn gsc-btn-primary">💾 Save Profile</button>
  </div>
  <div id="gsc-prof-msg" class="gsc-imsg"></div>
  <div style="display:grid;grid-template-columns:2fr 1fr;gap:16px;align-items:start">
    <div>
      <div class="gsc-card">
        <div class="gsc-card-title">Personal Information</div>
        <div class="gsc-g2">
          <div class="gsc-fg"><label class="gsc-lbl">Full Name</label><input type="text" id="gsc-name" class="gsc-inp" value="<?php echo esc_attr($profile_name); ?>" placeholder="Your full name"></div>
          <div class="gsc-fg"><label class="gsc-lbl">Email Address</label><input type="email" class="gsc-inp" value="<?php echo esc_attr($user->user_email); ?>" disabled style="opacity:.6;cursor:not-allowed" title="Email cannot be changed here"></div>
        </div>
        <div class="gsc-g2">
          <div class="gsc-fg"><label class="gsc-lbl">Phone / Mobile</label><input type="tel" id="gsc-phone" class="gsc-inp" value="<?php echo esc_attr($profile_phone); ?>" placeholder="+91 98765 43210"></div>
          <div class="gsc-fg"><label class="gsc-lbl">City</label><input type="text" id="gsc-city" class="gsc-inp" value="<?php echo esc_attr($profile_city); ?>" placeholder="Your city"></div>
        </div>
        <div class="gsc-fg"><label class="gsc-lbl">Company / Organisation</label><input type="text" id="gsc-company" class="gsc-inp" value="<?php echo esc_attr($profile_company); ?>" placeholder="Your company name (optional)"></div>
      </div>
      <div class="gsc-card">
        <div class="gsc-card-title">Change Password</div>
        <div id="gsc-pw-msg" class="gsc-imsg"></div>
        <div class="gsc-g2">
          <div class="gsc-fg"><label class="gsc-lbl">Current Password</label><input type="password" id="gsc-pw-cur" class="gsc-inp" placeholder="Current password" autocomplete="current-password"></div>
          <div class="gsc-fg"><label class="gsc-lbl">New Password</label><input type="password" id="gsc-pw-new" class="gsc-inp" placeholder="Min 8 characters" autocomplete="new-password"></div>
        </div>
        <div class="gsc-fg"><label class="gsc-lbl">Confirm New Password</label><input type="password" id="gsc-pw-cf" class="gsc-inp" placeholder="Repeat new password" autocomplete="new-password"></div>
        <button onclick="gscChangePw()" class="gsc-btn gsc-btn-ghost">🔒 Update Password</button>
      </div>
      <div class="gsc-card">
        <div class="gsc-card-title">🔒 Privacy &amp; Data</div>
        <p style="font-size:.82rem;color:#64748B;margin-bottom:12px">Request a copy of your personal data (profile, inquiries, bookings, reviews, saved listings). We'll email you a download link when it's ready — usually within a few minutes.</p>
        <button onclick="gscRequestDataExport()" id="gsc-de-btn" class="gsc-btn gsc-btn-ghost">📥 Request My Data Export</button>
        <div id="gsc-de-msg" class="gsc-imsg" style="margin-top:8px"></div>
        <div id="gsc-de-status" style="margin-top:8px;font-size:.78rem;color:#64748B"></div>
      </div>
    </div>
    <div class="gsc-card">
      <div class="gsc-card-title">Account Info</div>
      <div style="font-size:.82rem;color:#64748B;line-height:1.8">
        <div><strong>Username:</strong> <?php echo esc_html($user->user_login); ?></div>
        <div><strong>Member since:</strong> <?php echo esc_html(date('M Y', strtotime($user->user_registered))); ?></div>
        <div><strong>Inquiries:</strong> <?php echo $total_leads; ?></div>
        <div><strong>Saved:</strong> <?php echo $total_saved; ?></div>
      </div>
      <div style="margin-top:16px;padding-top:14px;border-top:1px solid #E2E8F0">
        <a href="<?php echo esc_url(home_url('/directory/')); ?>" class="gsc-btn gsc-btn-ghost" style="width:100%;justify-content:center">🔍 Browse Directory</a>
      </div>
    </div>
  </div>
  <script>
  function gscSaveProfile(){
    var name=document.getElementById('gsc-name').value;
    var phone=document.getElementById('gsc-phone').value;
    var city=document.getElementById('gsc-city').value;
    var company=document.getElementById('gsc-company').value;
    var msg=document.getElementById('gsc-prof-msg');
    jQuery.post(GS.ajax_url,{
      action:'gs_update_customer_profile', nonce:GS.nonce,
      display_name:name, phone:phone, city:city, company:company
    },function(r){
      msg.className='gsc-imsg '+(r.success?'ok':'err');
      msg.textContent=r.success?'✅ Profile saved!':'❌ '+(r.data&&r.data.message?r.data.message:'Save failed.');
      setTimeout(function(){msg.className='gsc-imsg';},4000);
    },'json');
  }
  function gscChangePw(){
    var cur=document.getElementById('gsc-pw-cur').value;
    var nw=document.getElementById('gsc-pw-new').value;
    var cf=document.getElementById('gsc-pw-cf').value;
    var msg=document.getElementById('gsc-pw-msg');
    if(!cur||!nw||!cf){msg.className='gsc-imsg err';msg.textContent='❌ All password fields are required.';return;}
    if(nw.length<8){msg.className='gsc-imsg err';msg.textContent='❌ New password must be at least 8 characters.';return;}
    if(nw!==cf){msg.className='gsc-imsg err';msg.textContent='❌ Passwords do not match.';return;}
    jQuery.post(GS.ajax_url,{action:'gs_change_password',nonce:GS.nonce,current_password:cur,new_password:nw,confirm_password:cf},function(r){
      msg.className='gsc-imsg '+(r.success?'ok':'err');
      msg.textContent=r.success?'✅ Password changed!':'❌ '+(r.data&&r.data.message?r.data.message:'Failed.');
      if(r.success){document.getElementById('gsc-pw-cur').value='';document.getElementById('gsc-pw-new').value='';document.getElementById('gsc-pw-cf').value='';}
      setTimeout(function(){msg.className='gsc-imsg';},5000);
    },'json');
  }
  function gscRenderExportStatus(exp){
    var box=document.getElementById('gsc-de-status');
    if(!exp){box.textContent='';return;}
    if(exp.status==='pending'||exp.status==='processing'){box.textContent='⏳ An export is being prepared — we\'ll email you when it\'s ready.';}
    else if(exp.status==='done'){box.textContent='✅ Last export ready — check your email for the download link.';}
    else if(exp.status==='failed'){box.textContent='❌ Last export attempt failed. Try requesting again.';}
    else{box.textContent='';}
  }
  function gscRequestDataExport(){
    var btn=document.getElementById('gsc-de-btn');
    var msg=document.getElementById('gsc-de-msg');
    btn.disabled=true;
    jQuery.post(GS.ajax_url,{action:'gs_request_data_export',nonce:GS.nonce},function(r){
      btn.disabled=false;
      msg.className='gsc-imsg '+(r.success?'ok':'err');
      msg.textContent=r.success?('✅ '+r.data.message):'❌ '+(r.data&&r.data.message?r.data.message:'Request failed.');
      setTimeout(function(){msg.className='gsc-imsg';},6000);
    },'json').fail(function(){btn.disabled=false;msg.className='gsc-imsg err';msg.textContent='❌ Network error — please try again.';});
  }
  jQuery.post(GS.ajax_url,{action:'gs_get_my_data_export_status',nonce:GS.nonce},function(r){
    if(r.success&&r.data&&r.data.export){gscRenderExportStatus(r.data.export);}
  },'json');
  </script>

  <?php endif; ?>

  </div><!-- /gsc-container -->

  <script>
  (function(){
    'use strict';
    // Real fix, Issue 4: client-side navigation between dashboard
    // sections — previously every nav click was a plain <a href> causing
    // a full page reload (fresh HTTP request, full HTML/CSS/JS re-parse,
    // scroll position reset, visible flash). This intercepts clicks on
    // dashboard nav links, fetches the target section's page in the
    // background, and swaps ONLY the #gsc-container content into the
    // current page — the header/nav chrome never reloads, so switching
    // feels instant, like a single-page app, without needing any new
    // backend endpoint: it reuses the exact same server-rendered HTML
    // every direct page load already produces, just fetched via AJAX
    // and had its relevant piece extracted, so there's no risk of the
    // AJAX version ever drifting from what a full reload would show —
    // there's only one render path, not two to keep in sync.
    var container = document.getElementById('gsc-container');
    if (!container) return;

    function isDashboardNavLink(a) {
      if (!a || !a.getAttribute) return false;
      var href = a.getAttribute('href') || '';
      // Only intercept same-dashboard section links (?section=xxx, no
      // hash-only anchors, no external/other-page links like Logout,
      // "tel:" call buttons, or "View Full Reply" deep links elsewhere).
      return /^\?section=[a-z_]+$/.test(href);
    }

    function runScriptsIn(el) {
      // innerHTML assignment does NOT execute <script> tags — each one
      // has to be recreated and re-inserted to actually run, or every
      // section's own interactive behavior (verification card, WhatsApp
      // template panel, etc.) would silently stop working the moment
      // it's loaded via this AJAX path instead of a full page load.
      var scripts = el.querySelectorAll('script');
      scripts.forEach(function(old) {
        var fresh = document.createElement('script');
        for (var i = 0; i < old.attributes.length; i++) {
          fresh.setAttribute(old.attributes[i].name, old.attributes[i].value);
        }
        fresh.textContent = old.textContent;
        old.parentNode.replaceChild(fresh, old);
      });
    }

    function updateActiveNav(section) {
      document.querySelectorAll('.gsc-nav-item, .gbn-item').forEach(function(a) {
        var href = a.getAttribute('href') || '';
        var isMatch = href === '?section=' + section;
        a.classList.toggle('on', isMatch && a.classList.contains('gsc-nav-item'));
        a.classList.toggle('gbn-active', isMatch && a.classList.contains('gbn-item'));
      });
    }

    function showLoading(show) {
      container.style.opacity = show ? '0.45' : '1';
      container.style.pointerEvents = show ? 'none' : '';
      container.style.transition = 'opacity .12s';
    }

    function navigateTo(url, pushState) {
      var params = new URLSearchParams(url.split('?')[1] || '');
      var section = params.get('section') || 'dashboard';

      showLoading(true);
      fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(function(r) {
          if (!r.ok) throw new Error('HTTP ' + r.status);
          return r.text();
        })
        .then(function(html) {
          var parsed = new DOMParser().parseFromString(html, 'text/html');
          var newContainer = parsed.getElementById('gsc-container');
          if (!newContainer) throw new Error('Section content not found in response');

          container.innerHTML = newContainer.innerHTML;
          runScriptsIn(container);
          updateActiveNav(section);
          if (pushState) { history.pushState({ gscSection: section }, '', url); }
          window.scrollTo({ top: 0, behavior: 'auto' });
          document.dispatchEvent(new CustomEvent('gscSectionLoaded', { detail: { section: section } }));
        })
        .catch(function(e) {
          // Real fallback: any failure (network error, unexpected
          // response shape, a future page structure change this script
          // doesn't know about) falls straight back to a normal full
          // navigation rather than leaving the user stuck on a half-
          // loaded, broken page with no way forward.
          window.location.href = url;
        })
        .finally(function() { showLoading(false); });
    }

    document.addEventListener('click', function(e) {
      var a = e.target.closest('a');
      if (!a || !isDashboardNavLink(a)) return;
      e.preventDefault();
      var href = a.getAttribute('href');
      if (href === window.location.search) return; // already on this section
      navigateTo(href, true);
    });

    window.addEventListener('popstate', function(e) {
      // Browser back/forward — re-derive the URL from the current
      // location rather than trusting only history.state, so this also
      // works correctly if the user arrived via a bookmarked/typed URL
      // rather than a click this script handled.
      navigateTo(window.location.pathname + window.location.search, false);
    });

    // Ensure the very first load also has a proper history entry with
    // state, so the first "back" press after any AJAX navigation lands
    // somewhere sensible instead of leaving the SPA state/history out of sync.
    if (!history.state || !history.state.gscSection) {
      var initialParams = new URLSearchParams(window.location.search);
      history.replaceState({ gscSection: initialParams.get('section') || 'dashboard' }, '', window.location.href);
    }
  })();
  </script>

</div><!-- /gsc-root -->
<?php
// Real bug fix: removed a second, entirely separate, mostly-broken
// dashboard system that used to render unconditionally right after this
// point, with no if/else gating it — causing this real, complete
// dashboard above and that other block to both appear stacked on the
// same page every time. That second block's own nav had only one of
// its three tabs (Saved Listings) with any actual content behind it;
// My Requirements and Profile rendered a completely blank area, and
// Saved Listings itself duplicated functionality already present and
// working in the real dashboard above. Nothing unique or functional
// was lost by removing it.

// ── VENDOR PROFILE PUBLIC PAGE ───────────────────────────────────────────────
elseif ($gs_page === 'vendor_profile'):
global $wpdb; $pfx = $wpdb->prefix.'gs_';
$vendor_slug = sanitize_text_field(get_query_var('gs_vendor_slug',''));
if (!$vendor_slug) { wp_redirect(home_url('/directory/')); exit; }
$vp = $wpdb->get_row($wpdb->prepare("SELECT vp.*,u.user_email FROM {$pfx}vendor_profiles vp LEFT JOIN {$wpdb->prefix}users u ON vp.user_id=u.ID WHERE vp.slug=%s AND vp.is_active=1",$vendor_slug));
if (!$vp) { wp_redirect(home_url('/directory/')); exit; }
$vp->social_links = json_decode($vp->social_links??'{}',true)?:[];
$listings = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$pfx}listings WHERE vendor_id=%d AND status='active' ORDER BY is_featured DESC,avg_rating DESC",$vp->user_id));
$total_reviews = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}reviews WHERE vendor_id=%d AND status='approved'",$vp->user_id));
$trust_score   = gs_calculate_trust_score($vp->user_id);
?>
<div class="gs-root">
<div style="background:linear-gradient(135deg,#1E3A5F,#2563EB);padding:48px 0">
  <div class="gs-container">
    <div style="display:flex;align-items:flex-start;gap:24px;flex-wrap:wrap">
      <div style="width:100px;height:100px;border-radius:16px;overflow:hidden;border:3px solid rgba(255,255,255,.3);background:rgba(255,255,255,.1);flex-shrink:0">
        <?php if($vp->logo_url): ?><img src="<?php echo esc_url($vp->logo_url); ?>" style="width:100%;height:100%;object-fit:cover"><?php else: ?><div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:2.5rem;font-weight:900;color:white"><?php echo strtoupper(substr($vp->business_name,0,1)); ?></div><?php endif; ?>
      </div>
      <div style="flex:1">
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:8px">
          <h1 style="font-size:1.8rem;font-weight:900;color:white;margin:0"><?php echo esc_html($vp->business_name); ?></h1>
          <?php if($vp->verification_status==='verified'): ?><span class="gs-badge gs-badge-green">✅ Verified</span><?php endif; ?>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:16px;margin-bottom:16px">
          <?php if($vp->city): ?><span style="color:rgba(255,255,255,.8);font-size:.9rem">📍 <?php echo esc_html($vp->city); ?></span><?php endif; ?>
          <span style="color:rgba(255,255,255,.8);font-size:.9rem">🏢 <?php echo count($listings); ?> Active Listings</span>
          <?php if($total_reviews): ?><span style="color:rgba(255,255,255,.8);font-size:.9rem">⭐ <?php echo number_format($vp->avg_rating,1); ?> (<?php echo $total_reviews; ?> reviews)</span><?php endif; ?>
          <span style="color:rgba(255,255,255,.8);font-size:.9rem">🛡️ Trust Score: <?php echo $trust_score; ?>/100</span>
        </div>
        <?php if($vp->bio): ?><p style="color:rgba(255,255,255,.8);font-size:.9rem;max-width:600px;line-height:1.6;margin:0 0 16px"><?php echo esc_html(substr($vp->bio,0,300)); ?></p><?php endif; ?>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <?php if($vp->phone): ?><a href="tel:<?php echo esc_attr($vp->phone); ?>" class="gs-btn gs-btn-success gs-btn-md">📞 Call</a><?php endif; ?>
          <?php if($vp->whatsapp): ?><a href="https://wa.me/<?php echo preg_replace('/[^0-9]/','',esc_attr($vp->whatsapp)); ?>" target="_blank" class="gs-btn gs-btn-md" style="background:#25D366;color:white">💬 WhatsApp</a><?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="gs-container" style="padding-top:40px;padding-bottom:60px">
  <h2 class="gs-h2" style="margin-bottom:24px">Listings by <?php echo esc_html($vp->business_name); ?></h2>
  <?php if($listings): ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:20px">
    <?php foreach($listings as $l): ?>
    <div class="gs-listing-card">
      <div class="gs-listing-card-img"><img src="<?php echo esc_url($l->banner_url?:GS_URL.'assets/images/placeholder.jpg'); ?>" alt="<?php echo esc_attr($l->title); ?>" loading="lazy"></div>
      <div class="gs-listing-card-body">
        <div class="gs-listing-card-name"><?php echo esc_html($l->title); ?></div>
        <div class="gs-listing-card-meta"><?php if($l->avg_rating>0): ?><?php echo gs_stars($l->avg_rating); ?> <?php echo number_format($l->avg_rating,1); ?><?php endif; ?><?php if($l->city): ?><div class="gs-listing-card-loc">📍 <?php echo esc_html($l->city); ?></div><?php endif; ?></div>
        <?php if($l->tagline): ?><div class="gs-listing-card-desc"><?php echo esc_html(substr($l->tagline,0,90)); ?></div><?php endif; ?>
      </div>
      <div class="gs-listing-card-footer">
        <a href="<?php echo home_url('/listing/'.esc_attr($l->slug).'/'); ?>" class="gs-btn gs-btn-ghost gs-btn-sm">View</a>
        <?php if($l->phone): ?><a href="tel:<?php echo esc_attr($l->phone); ?>" class="gs-btn gs-btn-success gs-btn-sm">📞</a><?php endif; ?>
        <?php if($l->whatsapp): ?><a href="https://wa.me/<?php echo preg_replace('/[^0-9]/','',esc_attr($l->whatsapp)); ?>" target="_blank" class="gs-btn gs-btn-sm" style="background:#25D366;color:white">💬</a><?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php else: ?>
  <div style="text-align:center;padding:60px;color:#94A3B8"><div style="font-size:2.5rem;margin-bottom:12px">🏢</div><div>No active listings found for this vendor.</div></div>
  <?php endif; ?>
</div>
</div>
<?php

// ── MODERATION DASHBOARD (standalone) ────────────────────────────────────────
elseif ($gs_page === 'moderation_dashboard'):
if (!is_user_logged_in()) { wp_redirect(home_url('/staff/login/')); exit; }
if (!gs_user_can('gs_approve_listings')) { wp_redirect(home_url('/staff/login/')); exit; }
$user = wp_get_current_user();
global $wpdb; $pfx = $wpdb->prefix.'gs_';
$tab = sanitize_text_field($_GET['tab']??'listings');
?>
<div class="gs-root" style="font-family:var(--gs-font);background:#F8FAFC;min-height:100vh">
  <div style="background:#1E3A5F;padding:0 24px;height:56px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100">
    <div style="color:white;font-weight:700;font-size:1rem">🛡️ Moderation Panel</div>
    <div style="display:flex;align-items:center;gap:10px"><span style="color:rgba(255,255,255,.6);font-size:.85rem"><?php echo esc_html($user->display_name); ?></span><a href="<?php echo wp_logout_url(home_url('/')); ?>" style="color:rgba(255,255,255,.4);font-size:.82rem">Logout</a></div>
  </div>
  <div style="background:white;border-bottom:1px solid #E2E8F0;padding:0 24px;display:flex;gap:0;overflow-x:auto">
    <?php
    $tabs_mod = ['listings'=>'Listings','reviews'=>'Reviews','complaints'=>'Complaints','verification'=>'Verification'];
    foreach($tabs_mod as $tv=>$tl):
    $count_mod = 0;
    if($tv==='listings') $count_mod=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$pfx}listings WHERE status='pending'");
    if($tv==='reviews')  $count_mod=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$pfx}reviews WHERE status='pending'");
    if($tv==='complaints') $count_mod=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$pfx}complaints WHERE status='open'");
    if($tv==='verification') $count_mod=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE verification_status='pending'");
    ?>
    <a href="?tab=<?php echo $tv; ?>" style="padding:14px 20px;font-size:.88rem;font-weight:600;color:<?php echo $tab===$tv?'#2563EB':'#64748B'; ?>;border-bottom:2px solid <?php echo $tab===$tv?'#2563EB':'transparent'; ?>;text-decoration:none;white-space:nowrap;display:flex;align-items:center;gap:6px">
      <?php echo $tl; ?><?php if($count_mod): ?><span style="background:#DC2626;color:white;font-size:.65rem;padding:2px 6px;border-radius:10px;font-weight:700"><?php echo $count_mod; ?></span><?php endif; ?>
    </a>
    <?php endforeach; ?>
  </div>
  <div class="gs-container" style="padding:24px">
    <?php if($tab==='listings'):
      $pending_mod=$wpdb->get_results("SELECT l.*,vp.business_name as vendor_name FROM {$pfx}listings l LEFT JOIN {$pfx}vendor_profiles vp ON l.vendor_id=vp.id WHERE l.status='pending' ORDER BY l.created_at ASC");
      ?>
      <div class="gs-page-header"><div class="gs-page-title">Pending Listings (<?php echo count($pending_mod); ?>)</div></div>
      <?php if($pending_mod): ?>
      <div style="display:flex;flex-direction:column;gap:14px">
        <?php foreach($pending_mod as $l): ?>
        <div style="background:white;border:1.5px solid #E2E8F0;border-radius:12px;padding:18px;display:flex;gap:16px;align-items:flex-start">
          <?php if($l->banner_url): ?><img src="<?php echo esc_url($l->banner_url); ?>" style="width:80px;height:60px;border-radius:8px;object-fit:cover;flex-shrink:0" loading="lazy"><?php endif; ?>
          <div style="flex:1;min-width:0">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
              <div style="font-weight:700;font-size:1rem"><?php echo esc_html($l->title); ?></div>
              <span class="gs-badge gs-badge-<?php echo $l->listing_type==='product'?'purple':'primary'; ?>"><?php echo ucfirst($l->listing_type); ?></span>
            </div>
            <div style="font-size:.82rem;color:#64748B;margin-bottom:6px"><?php echo esc_html($l->vendor_name??'—'); ?> • <?php echo esc_html($l->city); ?><?php if($l->state): ?>, <?php echo esc_html($l->state); ?><?php endif; ?> • Submitted <?php echo gs_time_ago($l->created_at); ?></div>
            <?php if($l->short_desc): ?><div style="font-size:.85rem;color:#475569;line-height:1.5"><?php echo esc_html(substr($l->short_desc,0,150)); ?></div><?php endif; ?>
            <?php if($l->phone||$l->email): ?><div style="font-size:.78rem;color:#94A3B8;margin-top:6px"><?php echo $l->phone?'📞 '.$l->phone.' ':''; ?><?php echo $l->email?'📧 '.$l->email:''; ?></div><?php endif; ?>
          </div>
          <div style="display:flex;flex-direction:column;gap:8px;flex-shrink:0">
            <button class="gs-btn gs-btn-success gs-btn-sm gs-approve-listing" data-id="<?php echo $l->id; ?>">✓ Approve</button>
            <button class="gs-btn gs-btn-danger gs-btn-sm gs-reject-listing" data-id="<?php echo $l->id; ?>">✕ Reject</button>
            <?php if($l->status==='active'): ?><a href="<?php echo home_url('/listing/'.esc_attr($l->slug).'/'); ?>" target="_blank" class="gs-btn gs-btn-ghost gs-btn-sm">Preview →</a><?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php else: ?><div style="text-align:center;padding:60px;color:#94A3B8"><div style="font-size:3rem">✅</div><div style="margin-top:10px">All listings have been reviewed!</div></div><?php endif; ?>
    <?php elseif($tab==='reviews'):
      $pending_rev=$wpdb->get_results("SELECT r.*,l.title as listing_title FROM {$pfx}reviews r LEFT JOIN {$pfx}listings l ON r.listing_id=l.id WHERE r.status='pending' ORDER BY r.created_at DESC");
      ?>
      <div class="gs-page-header"><div class="gs-page-title">Pending Reviews (<?php echo count($pending_rev); ?>)</div></div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:16px">
        <?php foreach($pending_rev as $r): ?>
        <div class="gs-card">
          <div class="gs-review-header"><div><div class="gs-reviewer-name"><?php echo esc_html($r->reviewer_name); ?></div><div style="font-size:.78rem;color:#64748B"><?php echo esc_html($r->listing_title??''); ?> • <?php echo gs_time_ago($r->created_at); ?></div></div><div><?php for($i=1;$i<=5;$i++) echo '<span style="color:'.($i<=$r->rating?'#F59E0B':'#E2E8F0').'">★</span>'; ?></div></div>
          <?php if($r->review_text): ?><div style="font-size:.88rem;color:#475569;margin:10px 0;line-height:1.6"><?php echo nl2br(esc_html($r->review_text)); ?></div><?php endif; ?>
          <div style="display:flex;gap:8px">
            <button class="gs-btn gs-btn-success gs-btn-sm gs-approve-review" data-id="<?php echo $r->id; ?>">✓ Approve</button>
            <button class="gs-btn gs-btn-danger gs-btn-sm gs-reject-review" data-id="<?php echo $r->id; ?>">✕ Reject</button>
          </div>
        </div>
        <?php endforeach; ?>
        <?php if(!$pending_rev): ?><div style="text-align:center;padding:48px;color:#94A3B8;grid-column:1/-1"><div style="font-size:2.5rem">⭐</div><div style="margin-top:10px">No pending reviews</div></div><?php endif; ?>
      </div>
    <?php elseif($tab==='verification'):
      $pend_ver=$wpdb->get_results("SELECT vp.*,u.user_email FROM {$pfx}vendor_profiles vp LEFT JOIN {$wpdb->prefix}users u ON vp.user_id=u.ID WHERE vp.verification_status='pending'");
      $pend_docs=$wpdb->get_results("SELECT vd.*,vp.business_name FROM {$pfx}verification_docs vd LEFT JOIN {$pfx}vendor_profiles vp ON vd.vendor_id=vp.user_id WHERE vd.status='pending'");
      ?>
      <div class="gs-page-header"><div class="gs-page-title">Verification Requests (<?php echo count($pend_ver); ?>)</div></div>
      <?php foreach($pend_ver as $v): ?>
      <div style="background:white;border:1.5px solid #E2E8F0;border-radius:12px;padding:18px;margin-bottom:14px;display:flex;align-items:center;justify-content:space-between">
        <div>
          <div style="font-weight:700"><?php echo esc_html($v->business_name); ?></div>
          <div style="font-size:.82rem;color:#64748B"><?php echo esc_html($v->user_email); ?> • <?php echo esc_html($v->city); ?></div>
          <?php if($v->gst_number): ?><div style="font-size:.78rem;color:#94A3B8">GST: <?php echo esc_html($v->gst_number); ?></div><?php endif; ?>
        </div>
        <div style="display:flex;gap:8px">
          <button class="gs-btn gs-btn-success gs-btn-sm gs-verify-vendor" data-id="<?php echo $v->user_id; ?>">✅ Verify</button>
          <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsPost('gs_verify_vendor',{vendor_user_id:<?php echo $v->user_id; ?>,status:'unverified'},function(){gsToast('Verification rejected','info');location.reload();})">✕ Reject</button>
        </div>
      </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>
