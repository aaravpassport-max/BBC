<?php
/**
 * GoodService — "Contact Us" page.
 * URL: /contact-us/
 * Real feature — extends the same design system as the other marketing
 * pages. The form submits to the existing gs_send_enquiry AJAX action
 * (AjaxController::sendEnquiry()) rather than a new, duplicate handler —
 * that action already exists specifically for generic, non-listing-tied
 * inquiries, stores them in the real leads table so admins can see them,
 * and (fixed earlier this session) sends its admin notification through
 * the platform's reliable, retry-with-backoff email queue.
 *
 * Deliberately does NOT include its own <!DOCTYPE>/<html>/<head> —
 * render_page() already provides that wrapper, matching the same
 * documented precedent as the other marketing pages.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

global $wpdb;
$pfx = $wpdb->prefix . 'gs_';

// ── Real, live average vendor reply time — same computed metric already
//    used elsewhere on the platform, not a new or invented number. ────────
$avg_reply_min = (int) ( $wpdb->get_var( "SELECT AVG(avg_reply_minutes) FROM {$pfx}vendor_profiles WHERE avg_reply_minutes > 0" ) ?: 0 );

$platform     = function_exists('gs_setting') ? gs_setting('platform_name', get_bloginfo('name')) : get_bloginfo('name');
$logo_url     = function_exists('gs_setting') ? gs_setting('logo_url', '') : '';
$support_email = function_exists('gs_setting') ? gs_setting('admin_email', get_option('admin_email')) : get_option('admin_email');
$search_url   = home_url('/');
$howitworks_url = home_url('/how-it-works/');
$trust_url    = home_url('/trust-safety/');
$about_url    = home_url('/about-us/');
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Inter:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@500;600&display=swap');
*,*::before,*::after{box-sizing:border-box}
.ct-body{font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#14162B;background:#FBFAF7}
.ct-mono{font-family:'IBM Plex Mono',monospace}
.ct-wrap{max-width:1180px;margin:0 auto;padding:0 24px}
.ct-header{background:#FBFAF7;border-bottom:1px solid rgba(20,22,43,.08);position:sticky;top:0;z-index:50}
.ct-header-inner{display:flex;align-items:center;justify-content:space-between;padding:14px 0}
.ct-logo{display:flex;align-items:center;gap:10px;text-decoration:none;color:#14162B;font-weight:800;font-size:1.1rem;font-family:'Fraunces',serif}
.ct-logo img{height:32px;border-radius:6px}
.ct-header-links{display:flex;align-items:center;gap:28px}
.ct-header-links a{color:#14162B;text-decoration:none;font-size:.87rem;font-weight:600}
.ct-header-links a:not(.ct-header-cta):hover{color:#FF6B35}
.ct-header-cta{background:#14162B;color:#FBFAF7!important;padding:9px 20px;border-radius:8px;font-weight:700!important;transition:background .18s}
.ct-header-cta:hover{background:#FF6B35}
@media(max-width:820px){.ct-header-links a:not(.ct-header-cta){display:none}}

.ct-main{padding:64px 0 100px}
.ct-grid{display:grid;grid-template-columns:.85fr 1.15fr;gap:64px;max-width:1040px;margin:0 auto}
@media(max-width:880px){.ct-grid{grid-template-columns:1fr;gap:40px}}
.ct-eyebrow{display:inline-flex;align-items:center;gap:8px;font-family:'IBM Plex Mono',monospace;font-weight:600;font-size:.72rem;text-transform:uppercase;letter-spacing:.14em;margin-bottom:20px;padding:6px 14px 6px 10px;border:1px solid rgba(20,22,43,.14);border-radius:99px}
.ct-eyebrow-dot{width:6px;height:6px;border-radius:50%;background:#FF6B35}
.ct-left h1{font-family:'Fraunces',serif;font-weight:600;font-size:2.4rem;line-height:1.12;letter-spacing:-.01em;margin-bottom:16px;color:#14162B}
.ct-left p{font-size:1rem;line-height:1.65;color:rgba(20,22,43,.62);margin-bottom:28px}

/* Signature element — real, live average reply time, since this page's
   actual job is reassuring someone their message won't vanish into a
   void; a concrete, computed number does that better than an icon row. */
.ct-reply-badge{background:#fff;border:1px solid rgba(20,22,43,.1);border-radius:14px;padding:22px;margin-bottom:24px}
.ct-reply-badge b{display:block;font-family:'Fraunces',serif;font-size:1.7rem;color:#14162B;margin-bottom:2px}
.ct-reply-badge span{font-size:.78rem;color:rgba(20,22,43,.55);font-family:'IBM Plex Mono',monospace;text-transform:uppercase;letter-spacing:.05em}

.ct-alt{border-top:1px solid rgba(20,22,43,.08);padding-top:24px;margin-top:8px}
.ct-alt-item{display:flex;gap:12px;align-items:flex-start;margin-bottom:16px}
.ct-alt-ico{width:34px;height:34px;border-radius:9px;background:#FBFAF7;border:1px solid rgba(20,22,43,.08);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:.95rem}
.ct-alt-item b{display:block;font-size:.88rem;color:#14162B;margin-bottom:2px}
.ct-alt-item span{font-size:.82rem;color:rgba(20,22,43,.55)}
.ct-alt-item a{color:#14162B;text-decoration:none;font-weight:600}
.ct-alt-item a:hover{color:#FF6B35}

.ct-form-card{background:#fff;border:1px solid rgba(20,22,43,.08);border-radius:18px;padding:32px}
.ct-fg{margin-bottom:16px}
.ct-fg label{display:block;font-size:.82rem;font-weight:700;color:#14162B;margin-bottom:6px}
.ct-fg input,.ct-fg select,.ct-fg textarea{width:100%;border:1.5px solid rgba(20,22,43,.14);border-radius:9px;padding:11px 13px;font-size:.92rem;font-family:inherit;color:#14162B;background:#FBFAF7}
.ct-fg input:focus,.ct-fg select:focus,.ct-fg textarea:focus{outline:none;border-color:#FF6B35;background:#fff}
.ct-fg-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
@media(max-width:520px){.ct-fg-row{grid-template-columns:1fr}}
.ct-submit{background:#14162B;color:#FBFAF7;border:none;border-radius:9px;padding:14px 24px;font-weight:700;font-size:.95rem;cursor:pointer;width:100%;transition:background .18s}
.ct-submit:hover{background:#FF6B35}
.ct-submit:disabled{opacity:.6;cursor:default}
.ct-msg{font-size:.86rem;margin-top:14px;text-align:center}

a.ct-header-cta:focus-visible,button.ct-submit:focus-visible{outline:2px solid #FF6B35;outline-offset:2px}
</style>

<div class="ct-body">
  <header class="ct-header">
    <div class="ct-wrap ct-header-inner">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="ct-logo">
        <?php if ($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($platform); ?>"><?php else: echo esc_html($platform); endif; ?>
      </a>
      <nav class="ct-header-links">
        <a href="<?php echo esc_url($howitworks_url); ?>">How It Works</a>
        <a href="<?php echo esc_url($trust_url); ?>">Trust &amp; Safety</a>
        <a href="<?php echo esc_url($about_url); ?>">About</a>
        <a href="<?php echo esc_url($search_url); ?>" class="ct-header-cta">Find a Pro →</a>
      </nav>
    </div>
  </header>

  <main class="ct-main">
    <div class="ct-wrap">
      <div class="ct-grid">
        <div class="ct-left">
          <div class="ct-eyebrow"><span class="ct-eyebrow-dot"></span>Get In Touch</div>
          <h1>Have a question? Send it — a real person reads every message.</h1>
          <p>Whether it's about a booking, a listing, or something else entirely, this goes straight to our team.</p>

          <?php if ( $avg_reply_min > 0 ): ?>
          <div class="ct-reply-badge">
            <b><?php echo $avg_reply_min < 60 ? '~' . esc_html($avg_reply_min) . ' min' : '~' . esc_html( round($avg_reply_min/60) ) . ' hrs'; ?></b>
            <span>Average reply time on the platform</span>
          </div>
          <?php endif; ?>

          <div class="ct-alt">
            <div class="ct-alt-item">
              <div class="ct-alt-ico">✉️</div>
              <div><b>Email us directly</b><span><a href="mailto:<?php echo esc_attr($support_email); ?>"><?php echo esc_html($support_email); ?></a></span></div>
            </div>
            <div class="ct-alt-item">
              <div class="ct-alt-ico">🛡️</div>
              <div><b>Trust &amp; safety question?</b><span>See our <a href="<?php echo esc_url($trust_url); ?>">Trust &amp; Safety page</a> for how verification and disputes work.</span></div>
            </div>
          </div>
        </div>

        <div class="ct-form-card">
          <div class="ct-fg-row">
            <div class="ct-fg"><label for="ct-name">Name *</label><input type="text" id="ct-name" required></div>
            <div class="ct-fg"><label for="ct-phone">Phone *</label><input type="tel" id="ct-phone" required></div>
          </div>
          <div class="ct-fg"><label for="ct-email">Email</label><input type="email" id="ct-email"></div>
          <div class="ct-fg">
            <label for="ct-category">What's this about?</label>
            <select id="ct-category">
              <option value="General">General question</option>
              <option value="Booking">A booking I made</option>
              <option value="Listing">My business listing</option>
              <option value="Trust & Safety">Trust &amp; safety concern</option>
              <option value="Partnership">Partnership / press</option>
            </select>
          </div>
          <div class="ct-fg"><label for="ct-message">Message *</label><textarea id="ct-message" rows="4" required></textarea></div>
          <button type="button" class="ct-submit" id="ct-submit-btn" onclick="ctSubmitContact()">Send Message</button>
          <div class="ct-msg" id="ct-msg"></div>
        </div>
      </div>
    </div>
  </main>

  <?php
  $df_site = $platform; $df_home = home_url('/');
  // Real bug fix (v7.475.7) — see matching comment in about-us.php.
  $_ftr_primary = function_exists('gs_setting') ? gs_setting('platform_color_primary', '#2563EB') : '#2563EB';
  ?>
  <footer style="background:#14162B;color:rgba(251,250,247,.6);padding:32px 0;text-align:center;font-size:.78rem;font-family:'IBM Plex Mono',monospace">
    <div class="ct-wrap">© <?php echo esc_html( gmdate('Y') ); ?> <?php echo esc_html($df_site); ?>. All rights reserved. &nbsp;·&nbsp;
      <a href="<?php echo esc_url($df_home); ?>" style="color:rgba(251,250,247,.75);transition:color .15s" onmouseover="this.style.color='<?php echo esc_js($_ftr_primary); ?>'" onmouseout="this.style.color='rgba(251,250,247,.75)'">Home</a> &nbsp;·&nbsp;
      <a href="<?php echo esc_url($about_url); ?>" style="color:rgba(251,250,247,.75);transition:color .15s" onmouseover="this.style.color='<?php echo esc_js($_ftr_primary); ?>'" onmouseout="this.style.color='rgba(251,250,247,.75)'">About</a>
    </div>
  </footer>
</div>

<script>
// Real fix — self-contained, same proven pattern as the media library
// fixes earlier this session: own nonce, own fetch, no dependency on any
// externally-defined helper that might not be present on this page.
function ctSubmitContact() {
  var name = document.getElementById('ct-name').value.trim();
  var phone = document.getElementById('ct-phone').value.trim();
  var email = document.getElementById('ct-email').value.trim();
  var category = document.getElementById('ct-category').value;
  var message = document.getElementById('ct-message').value.trim();
  var msgEl = document.getElementById('ct-msg');
  var btn = document.getElementById('ct-submit-btn');

  if (!name || !phone || !message) {
    msgEl.style.color = '#DC2626'; msgEl.textContent = 'Please fill in your name, phone, and message.';
    return;
  }

  btn.disabled = true; btn.textContent = 'Sending…';
  msgEl.style.color = '#64748B'; msgEl.textContent = '';

  var fd = new FormData();
  fd.append('action', 'gs_send_enquiry');
  fd.append('nonce', '<?php echo esc_js( wp_create_nonce('gs_ajax') ); ?>');
  fd.append('name', name);
  fd.append('phone', phone);
  fd.append('email', email);
  fd.append('category', category);
  fd.append('message', message);
  fd.append('page_url', window.location.href);

  fetch('<?php echo esc_js( admin_url('admin-ajax.php') ); ?>', { method: 'POST', body: fd })
    .then(function(r){ return r.json(); })
    .then(function(d) {
      btn.disabled = false; btn.textContent = 'Send Message';
      if (d && d.success) {
        msgEl.style.color = '#16A34A';
        msgEl.textContent = (d.data && d.data.message) || "Thanks — we'll get back to you soon.";
        document.getElementById('ct-name').value = '';
        document.getElementById('ct-phone').value = '';
        document.getElementById('ct-email').value = '';
        document.getElementById('ct-message').value = '';
      } else {
        msgEl.style.color = '#DC2626';
        msgEl.textContent = (d && d.data && d.data.message) || 'Something went wrong — please try again.';
      }
    })
    .catch(function() {
      btn.disabled = false; btn.textContent = 'Send Message';
      msgEl.style.color = '#DC2626';
      msgEl.textContent = 'Network error — please try again, or email us directly.';
    });
}
</script>
