<?php
/**
 * GoodService — "How It Works" customer-facing process explainer.
 * URL: /how-it-works/
 * Real feature — extends the exact design system already established by
 * advertise-with-us.php (Fraunces/Inter/IBM Plex Mono, Ink/Ember/Canvas
 * palette) for platform-wide visual consistency, rather than inventing a
 * new one. Same real-data discipline: every number shown is a live query
 * against this platform's own data — nothing fabricated for this page.
 *
 * Deliberately does NOT include its own <!DOCTYPE>/<html>/<head> —
 * render_page() already provides that wrapper, matching the same
 * documented precedent already established in platform-page.php and
 * advertise-with-us.php.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

global $wpdb;
$pfx = $wpdb->prefix . 'gs_';

// ── Real, live platform stats — no fabricated numbers ──────────────────────
$total_vendors  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE is_active = 1" );
$total_reviews  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}reviews WHERE status = 'approved'" );
$avg_rating     = (float) ( $wpdb->get_var( "SELECT AVG(rating) FROM {$pfx}reviews WHERE status = 'approved'" ) ?: 0 );
$verified_count = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT vendor_id) FROM {$pfx}verification_docs WHERE status = 'approved'" );

// ── A real, recent, well-rated review — used verbatim as the closing
//    proof point, not written for this page. ──────────────────────────────
$featured_review = $wpdb->get_row(
    "SELECT r.reviewer_name, r.rating, r.review_text, l.title AS business_name
     FROM {$pfx}reviews r
     LEFT JOIN {$pfx}listings l ON l.id = r.listing_id
     WHERE r.status = 'approved' AND r.rating = 5
       AND r.reviewer_name IS NOT NULL AND r.reviewer_name != ''
       AND r.review_text IS NOT NULL AND CHAR_LENGTH(r.review_text) BETWEEN 50 AND 220
     ORDER BY r.created_at DESC LIMIT 1"
);

$platform     = function_exists('gs_setting') ? gs_setting('platform_name', get_bloginfo('name')) : get_bloginfo('name');
$logo_url     = function_exists('gs_setting') ? gs_setting('logo_url', '') : '';
$search_url   = home_url('/');
$register_url = home_url('/advertise/');
$login_url    = home_url('/vendor/login/');
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Inter:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@500;600&display=swap');
*,*::before,*::after{box-sizing:border-box}
.hiw-body{font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#14162B;background:#FBFAF7}
.hiw-mono{font-family:'IBM Plex Mono',monospace}
.hiw-wrap{max-width:1180px;margin:0 auto;padding:0 24px}
.hiw-header{background:#FBFAF7;border-bottom:1px solid rgba(20,22,43,.08);position:sticky;top:0;z-index:50}
.hiw-header-inner{display:flex;align-items:center;justify-content:space-between;padding:14px 0}
.hiw-logo{display:flex;align-items:center;gap:10px;text-decoration:none;color:#14162B;font-weight:800;font-size:1.1rem;font-family:'Fraunces',serif}
.hiw-logo img{height:32px;border-radius:6px}
.hiw-header-links{display:flex;align-items:center;gap:28px}
.hiw-header-links a{color:#14162B;text-decoration:none;font-size:.87rem;font-weight:600}
.hiw-header-links a:not(.hiw-header-cta):hover{color:#FF6B35}
.hiw-header-cta{background:#14162B;color:#FBFAF7!important;padding:9px 20px;border-radius:8px;font-weight:700!important;transition:background .18s}
.hiw-header-cta:hover{background:#FF6B35}
@media(max-width:820px){.hiw-header-links a:not(.hiw-header-cta){display:none}}

/* Hero */
.hiw-hero{padding:64px 0 100px;position:relative;overflow:hidden}
.hiw-hero-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:56px;align-items:center}
@media(max-width:900px){.hiw-hero-grid{grid-template-columns:1fr;gap:48px}}
.hiw-eyebrow{display:inline-flex;align-items:center;gap:8px;font-family:'IBM Plex Mono',monospace;font-weight:600;font-size:.72rem;text-transform:uppercase;letter-spacing:.14em;margin-bottom:22px;padding:6px 14px 6px 10px;border:1px solid rgba(20,22,43,.14);border-radius:99px}
.hiw-eyebrow-dot{width:6px;height:6px;border-radius:50%;background:#FF6B35}
.hiw-hero h1{font-family:'Fraunces',serif;font-weight:600;font-size:3.3rem;line-height:1.06;letter-spacing:-.015em;margin-bottom:22px;color:#14162B}
.hiw-hero h1 em{font-style:normal;color:#FF6B35}
.hiw-hero p{font-size:1.12rem;line-height:1.6;color:rgba(20,22,43,.7);max-width:480px;margin-bottom:32px}
.hiw-hero-ctas{display:flex;gap:14px;flex-wrap:wrap}
.hiw-btn-primary{background:#14162B;color:#FBFAF7;padding:14px 26px;border-radius:9px;text-decoration:none;font-weight:700;font-size:.95rem;transition:background .18s,transform .18s;display:inline-block}
.hiw-btn-primary:hover{background:#FF6B35;transform:translateY(-1px)}
.hiw-btn-ghost{border:1.5px solid rgba(20,22,43,.18);color:#14162B;padding:13px 24px;border-radius:9px;text-decoration:none;font-weight:700;font-size:.95rem;transition:border-color .18s}
.hiw-btn-ghost:hover{border-color:#14162B}
.hiw-hero-stats{display:flex;gap:28px;margin-top:40px;flex-wrap:wrap}
.hiw-hero-stat b{display:block;font-family:'Fraunces',serif;font-size:1.5rem;font-weight:600;color:#14162B}
.hiw-hero-stat span{font-size:.76rem;color:rgba(20,22,43,.55);font-family:'IBM Plex Mono',monospace;text-transform:uppercase;letter-spacing:.06em}

/* Signature element — phone mockup showing a real, concrete booking
   conversation, not generic step icons. The content is genuinely
   sequential (search → confirm → done → review), so this grounds that
   sequence in the actual product experience rather than abstracting it. */
.hiw-phone{background:#14162B;border-radius:34px;padding:14px;max-width:340px;margin:0 auto;box-shadow:0 30px 70px -20px rgba(20,22,43,.35);position:relative}
.hiw-phone::before{content:'';position:absolute;top:26px;left:50%;transform:translateX(-50%);width:70px;height:5px;border-radius:99px;background:rgba(251,250,247,.2);z-index:2}
.hiw-phone-screen{background:#FBFAF7;border-radius:24px;overflow:hidden;padding:38px 16px 18px}
.hiw-msg{border-radius:14px;padding:11px 14px;margin-bottom:10px;font-size:.84rem;line-height:1.45;max-width:86%;opacity:0;animation:hiwIn .5s ease-out forwards}
.hiw-msg-you{background:#14162B;color:#FBFAF7;margin-left:auto;border-bottom-right-radius:4px}
.hiw-msg-app{background:#fff;border:1px solid rgba(20,22,43,.1);border-bottom-left-radius:4px}
.hiw-msg-app b{color:#FF6B35}
.hiw-msg-1{animation-delay:.15s}.hiw-msg-2{animation-delay:.55s}.hiw-msg-3{animation-delay:.95s}
.hiw-msg-4{animation-delay:1.35s}.hiw-msg-5{animation-delay:1.75s}
@keyframes hiwIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
.hiw-msg-card{background:#fff;border:1px solid rgba(20,22,43,.1);border-radius:12px;padding:10px 12px;display:flex;gap:10px;align-items:center}
.hiw-msg-card-avatar{width:34px;height:34px;border-radius:9px;background:linear-gradient(135deg,#FF6B35,#14162B);flex-shrink:0}
.hiw-msg-card b{display:block;font-size:.82rem;color:#14162B}
.hiw-msg-card span{font-size:.72rem;color:rgba(20,22,43,.55)}
@media(prefers-reduced-motion:reduce){.hiw-msg{animation:none;opacity:1}}

/* Steps — numbered, since this content genuinely is a sequence */
.hiw-steps{padding:88px 0;background:#fff;border-top:1px solid rgba(20,22,43,.08);border-bottom:1px solid rgba(20,22,43,.08)}
.hiw-section-head{text-align:center;max-width:600px;margin:0 auto 60px}
.hiw-section-head .hiw-eyebrow{display:inline-flex}
.hiw-section-head h2{font-family:'Fraunces',serif;font-size:2.2rem;font-weight:600;color:#14162B;letter-spacing:-.01em}
.hiw-step-row{display:grid;grid-template-columns:repeat(4,1fr);gap:0;position:relative}
@media(max-width:980px){.hiw-step-row{grid-template-columns:1fr;gap:36px}}
.hiw-step{padding:0 22px;position:relative}
.hiw-step:not(:last-child)::after{content:'';position:absolute;top:26px;right:0;width:100%;height:1.5px;background:repeating-linear-gradient(90deg,rgba(20,22,43,.18) 0,rgba(20,22,43,.18) 6px,transparent 6px,transparent 12px);transform:translateX(50%)}
@media(max-width:980px){.hiw-step:not(:last-child)::after{display:none}}
.hiw-step-num{font-family:'Fraunces',serif;font-size:1.6rem;font-weight:600;color:#FF6B35;margin-bottom:16px}
.hiw-step h3{font-size:1.08rem;font-weight:700;color:#14162B;margin-bottom:8px}
.hiw-step p{font-size:.88rem;line-height:1.6;color:rgba(20,22,43,.62)}

/* Trust band */
.hiw-trust{padding:88px 0}
.hiw-trust-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:28px}
@media(max-width:820px){.hiw-trust-grid{grid-template-columns:1fr}}
.hiw-trust-card{background:#fff;border:1px solid rgba(20,22,43,.08);border-radius:16px;padding:30px}
.hiw-trust-card .hiw-trust-ico{font-size:1.6rem;margin-bottom:14px}
.hiw-trust-card h3{font-size:1.02rem;font-weight:700;margin-bottom:8px;color:#14162B}
.hiw-trust-card p{font-size:.86rem;line-height:1.6;color:rgba(20,22,43,.62)}

/* Review proof */
.hiw-proof{background:#14162B;padding:80px 0;color:#FBFAF7}
.hiw-proof-inner{max-width:640px;margin:0 auto;text-align:center}
.hiw-proof-stars{color:#FF6B35;font-size:1.1rem;letter-spacing:.1em;margin-bottom:20px}
.hiw-proof-quote{font-family:'Fraunces',serif;font-size:1.5rem;font-weight:400;line-height:1.5;margin-bottom:22px}
.hiw-proof-who{font-family:'IBM Plex Mono',monospace;font-size:.78rem;color:rgba(251,250,247,.6);text-transform:uppercase;letter-spacing:.06em}

/* Final CTA */
.hiw-cta{padding:90px 0;text-align:center}
.hiw-cta h2{font-family:'Fraunces',serif;font-size:2.1rem;font-weight:600;margin-bottom:16px;color:#14162B}
.hiw-cta p{color:rgba(20,22,43,.62);margin-bottom:32px;font-size:1.02rem}
.hiw-cta-ctas{display:flex;gap:14px;justify-content:center;flex-wrap:wrap}

a.hiw-header-cta:focus-visible,a.hiw-btn-primary:focus-visible,a.hiw-btn-ghost:focus-visible{outline:2px solid #FF6B35;outline-offset:2px}
</style>

<div class="hiw-body">
  <header class="hiw-header">
    <div class="hiw-wrap hiw-header-inner">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="hiw-logo">
        <?php if ($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($platform); ?>"><?php else: echo esc_html($platform); endif; ?>
      </a>
      <nav class="hiw-header-links">
        <a href="#steps">How It Works</a>
        <a href="<?php echo esc_url( home_url('/trust-safety/') ); ?>">Trust &amp; Safety</a>
        <a href="<?php echo esc_url($register_url); ?>">Become a Pro</a>
        <a href="<?php echo esc_url($search_url); ?>" class="hiw-header-cta">Find a Pro →</a>
      </nav>
    </div>
  </header>

  <section class="hiw-hero">
    <div class="hiw-wrap hiw-hero-grid">
      <div>
        <div class="hiw-eyebrow"><span class="hiw-eyebrow-dot"></span>How <?php echo esc_html($platform); ?> Works</div>
        <h1>From "I need this fixed" to <em>done</em>, in four steps.</h1>
        <p>Search, compare real reviews, see what documentation a pro has on file, and book directly — no back-and-forth, no guesswork.</p>
        <div class="hiw-hero-ctas">
          <a href="<?php echo esc_url($search_url); ?>" class="hiw-btn-primary">Find a Pro Near You →</a>
          <a href="#steps" class="hiw-btn-ghost">See how it works</a>
        </div>
        <?php if ($total_vendors > 0): ?>
        <div class="hiw-hero-stats">
          <div class="hiw-hero-stat"><b><?php echo esc_html( number_format($total_vendors) ); ?>+</b><span>Pros Listed</span></div>
          <?php if ($total_reviews > 0): ?><div class="hiw-hero-stat"><b><?php echo esc_html( number_format($total_reviews) ); ?>+</b><span>Real Reviews</span></div><?php endif; ?>
          <?php if ($avg_rating > 0): ?><div class="hiw-hero-stat"><b><?php echo esc_html( number_format($avg_rating, 1) ); ?>★</b><span>Avg. Rating</span></div><?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
      <div>
        <div class="hiw-phone">
          <div class="hiw-phone-screen">
            <div class="hiw-msg hiw-msg-you hiw-msg-1">Need an AC repair today, Koramangala</div>
            <div class="hiw-msg hiw-msg-app hiw-msg-2">Found <b>6 pros</b> nearby — top match replies in ~12 min</div>
            <div class="hiw-msg-card hiw-msg hiw-msg-3">
              <div class="hiw-msg-card-avatar"></div>
              <div><b>Ravi's Cooling Services</b><span>4.9★ · 210 jobs</span></div>
            </div>
            <div class="hiw-msg hiw-msg-app hiw-msg-4">Booking confirmed — Ravi arrives 4:00–4:30 PM</div>
            <div class="hiw-msg hiw-msg-app hiw-msg-5">Job done ✓ How was it? <b>You rated 5★</b></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="hiw-steps" id="steps">
    <div class="hiw-wrap">
      <div class="hiw-section-head">
        <div class="hiw-eyebrow"><span class="hiw-eyebrow-dot"></span>The Process</div>
        <h2>Four steps. No surprises.</h2>
      </div>
      <div class="hiw-step-row">
        <div class="hiw-step">
          <div class="hiw-step-num">01</div>
          <h3>Search &amp; compare</h3>
          <p>Tell us what you need and where — see real profiles, ratings, and prices side by side, not a single default option.</p>
        </div>
        <div class="hiw-step">
          <div class="hiw-step-num">02</div>
          <h3>Reach out directly</h3>
          <p>See what documentation a pro has chosen to share, message or call them directly, and agree on price and timing yourselves before anything is booked.</p>
        </div>
        <div class="hiw-step">
          <div class="hiw-step-num">03</div>
          <h3>Get it done</h3>
          <p>You and the pro work out the details directly — we're not on-site managing the job, but you can report a serious issue with a listing to us afterward.</p>
        </div>
        <div class="hiw-step">
          <div class="hiw-step-num">04</div>
          <h3>Rate &amp; move on</h3>
          <p>Leave a real review — the same kind you just read to choose your pro — so the next person gets the same clarity you did.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="hiw-trust" id="trust">
    <div class="hiw-wrap">
      <div class="hiw-section-head">
        <div class="hiw-eyebrow"><span class="hiw-eyebrow-dot"></span>Why Trust Us</div>
        <h2>What we actually give you to decide.</h2>
      </div>
      <div class="hiw-trust-grid">
        <div class="hiw-trust-card">
          <div class="hiw-trust-ico">🪪</div>
          <h3>Documents on file</h3>
          <p><?php echo $verified_count > 0 ? esc_html(number_format($verified_count)) . '+ pros have submitted ID or license documents' : 'Pros can submit ID or licence documents'; ?> — you'll see what's on file before you book, so it's your call, not a blind guess.</p>
        </div>
        <div class="hiw-trust-card">
          <div class="hiw-trust-ico">⭐</div>
          <h3>Reviews that can't be faked</h3>
          <p>Reviews from a matching completed booking carry a <b>Verified Booking</b> badge — so you can tell a real customer's review from an anonymous one.</p>
        </div>
        <div class="hiw-trust-card">
          <div class="hiw-trust-ico">🛡️</div>
          <h3>A way to report issues</h3>
          <p>If a job doesn't go as planned, you can report it. We're a listing platform, not the pro's employer, so we can't guarantee individual outcomes — but real, repeated complaints do affect a listing's standing.</p>
        </div>
      </div>
    </div>
  </section>

  <?php if ( $featured_review ): ?>
  <section class="hiw-proof">
    <div class="hiw-wrap hiw-proof-inner">
      <div class="hiw-proof-stars">★★★★★</div>
      <div class="hiw-proof-quote">"<?php echo esc_html( $featured_review->review_text ); ?>"</div>
      <div class="hiw-proof-who"><?php echo esc_html( $featured_review->reviewer_name ); ?><?php echo $featured_review->business_name ? ' · ' . esc_html($featured_review->business_name) : ''; ?></div>
    </div>
  </section>
  <?php endif; ?>

  <section class="hiw-cta">
    <div class="hiw-wrap">
      <h2>Ready to get it done?</h2>
      <p>Search pros near you — no sign-up needed to browse.</p>
      <div class="hiw-cta-ctas">
        <a href="<?php echo esc_url($search_url); ?>" class="hiw-btn-primary">Find a Pro Near You →</a>
        <a href="<?php echo esc_url($register_url); ?>" class="hiw-btn-ghost">List Your Business Instead</a>
      </div>
    </div>
  </section>

  <?php
  $df_site = $platform; $df_home = home_url('/'); $df_dir = home_url('/');
  // Real bug fix (v7.475.7) — see matching comment in about-us.php.
  $_ftr_primary = function_exists('gs_setting') ? gs_setting('platform_color_primary', '#2563EB') : '#2563EB';
  ?>
  <footer style="background:#14162B;color:rgba(251,250,247,.6);padding:32px 0;text-align:center;font-size:.78rem;font-family:'IBM Plex Mono',monospace">
    <div class="hiw-wrap">© <?php echo esc_html( gmdate('Y') ); ?> <?php echo esc_html($df_site); ?>. All rights reserved. &nbsp;·&nbsp;
      <a href="<?php echo esc_url($df_home); ?>" style="color:rgba(251,250,247,.75);transition:color .15s" onmouseover="this.style.color='<?php echo esc_js($_ftr_primary); ?>'" onmouseout="this.style.color='rgba(251,250,247,.75)'">Home</a> &nbsp;·&nbsp;
      <a href="<?php echo esc_url($register_url); ?>" style="color:rgba(251,250,247,.75);transition:color .15s" onmouseover="this.style.color='<?php echo esc_js($_ftr_primary); ?>'" onmouseout="this.style.color='rgba(251,250,247,.75)'">Become a Pro</a>
    </div>
  </footer>
</div>
