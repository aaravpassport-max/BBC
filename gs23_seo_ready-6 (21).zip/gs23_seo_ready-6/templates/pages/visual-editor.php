<?php
/**
 * Visual Editor — GoodService Platform v7
 * Elementor-style live preview editor for listing microsites.
 * URL: /vendor/visual-edit/{listing_id}/
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! is_user_logged_in() || ! gs_is_vendor() ) {
    wp_redirect( home_url( '/vendor/login/' ) ); exit;
}

global $wpdb;
$pfx        = $wpdb->prefix . 'gs_';
$user       = wp_get_current_user();
$listing_id = intval( get_query_var( 'gs_listing_id', 0 ) ) ?: intval( $_GET['listing_id'] ?? 0 );
$is_admin   = \GoodService\Core\Roles::is_admin_level();

if ( ! $listing_id ) { wp_redirect( home_url( '/vendor/dashboard/?section=listings' ) ); exit; }

$listing = $is_admin
    ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$pfx}listings WHERE id=%d", $listing_id ) )
    : $wpdb->get_row( $wpdb->prepare( "SELECT l.* FROM {$pfx}listings l JOIN {$pfx}vendor_profiles vp ON vp.id=l.vendor_id WHERE l.id=%d AND vp.user_id=%d", $listing_id, $user->ID ) );

if ( ! $listing ) { wp_redirect( home_url( '/vendor/dashboard/?section=listings' ) ); exit; }

foreach ( ['hero_data','about_data','feedback_data','footer_data','customizer_data','mobile_data',
           'services_data','products_data','process_data','faq_data','why_choose_data','stats_data',
           'gallery','service_cities','opening_hours','items_data'] as $f ) {
    $listing->$f = json_decode( $listing->$f ?? '[]', true ) ?: [];
}

$cd  = $listing->customizer_data;
$hd  = $listing->hero_data;
$ad  = $listing->about_data;
$ftd = $listing->footer_data;

$preview_url = home_url( '/' . $listing->slug . '/?gs_ve_preview=1&ve_token=' . wp_create_nonce('gs_ve_preview') );
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Visual Editor — <?php echo esc_html($listing->title); ?></title>
<link rel="stylesheet" href="<?php echo GS_URL; ?>assets/css/goodservice.css?v=<?php echo GS_VERSION; ?>">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --ve-sidebar:320px;
  --ve-topbar:52px;
  --ve-font:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  --ve-dark:#1A1F2E;
  --ve-panel:#22293A;
  --ve-panel2:#2A3245;
  --ve-border:#3A4460;
  --ve-accent:#3B82F6;
  --ve-text:#E2E8F0;
  --ve-text2:#94A3B8;
  --ve-input-bg:#1A1F2E;
  --ve-input-border:#3A4460;
  --ve-radius:8px;
  --ve-gold:#F59E0B;
}
html,body{height:100%;overflow:hidden;font-family:var(--ve-font);background:var(--ve-dark)}

/* ── Topbar ── */
.ve-top{position:fixed;top:0;left:0;right:0;height:var(--ve-topbar);background:var(--ve-dark);border-bottom:1px solid var(--ve-border);display:flex;align-items:center;justify-content:space-between;padding:0 16px;z-index:1000}
.ve-top-left{display:flex;align-items:center;gap:12px}
.ve-top-logo{color:var(--ve-gold);font-weight:800;font-size:.95rem;display:flex;align-items:center;gap:6px}
.ve-top-sep{width:1px;height:22px;background:var(--ve-border)}
.ve-top-title{color:var(--ve-text2);font-size:.82rem;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ve-top-right{display:flex;align-items:center;gap:8px}
.ve-btn{display:inline-flex;align-items:center;gap:5px;padding:6px 14px;border-radius:6px;font-size:.8rem;font-weight:600;cursor:pointer;border:none;font-family:inherit;transition:all .15s}
.ve-btn-primary{background:var(--ve-accent);color:#fff}
.ve-btn-primary:hover{background:#2563EB}
.ve-btn-success{background:#059669;color:#fff}
.ve-btn-success:hover{background:#047857}
.ve-btn-ghost{background:transparent;border:1px solid var(--ve-border);color:var(--ve-text2)}
.ve-btn-ghost:hover{border-color:var(--ve-text2);color:var(--ve-text)}
.ve-save-status{font-size:.75rem;color:var(--ve-text2)}

/* ── Layout ── */
.ve-layout{display:flex;height:100vh;padding-top:var(--ve-topbar)}

/* ── Sidebar ── */
.ve-sidebar{width:var(--ve-sidebar);background:var(--ve-panel);border-right:1px solid var(--ve-border);display:flex;flex-direction:column;flex-shrink:0;overflow:hidden}
.ve-sidebar-tabs{display:flex;border-bottom:1px solid var(--ve-border);flex-shrink:0}
.ve-tab{flex:1;padding:10px 6px;text-align:center;font-size:.72rem;font-weight:600;color:var(--ve-text2);cursor:pointer;border-bottom:2px solid transparent;transition:all .15s}
.ve-tab.on{color:var(--ve-accent);border-bottom-color:var(--ve-accent);background:rgba(59,130,246,.07)}
.ve-tab:hover:not(.on){color:var(--ve-text)}

.ve-sidebar-body{flex:1;overflow-y:auto;padding:0}
.ve-sidebar-body::-webkit-scrollbar{width:4px}
.ve-sidebar-body::-webkit-scrollbar-track{background:transparent}
.ve-sidebar-body::-webkit-scrollbar-thumb{background:var(--ve-border);border-radius:2px}

/* ── Sections nav ── */
.ve-section-nav{display:flex;flex-direction:column;padding:8px}
.ve-sec-btn{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:7px;cursor:pointer;color:var(--ve-text2);font-size:.82rem;font-weight:500;transition:all .15s;border:1px solid transparent}
.ve-sec-btn:hover{background:var(--ve-panel2);color:var(--ve-text);border-color:var(--ve-border)}
.ve-sec-btn.on{background:rgba(59,130,246,.12);color:var(--ve-accent);border-color:rgba(59,130,246,.3);font-weight:600}
.ve-sec-icon{font-size:1rem;width:24px;text-align:center;flex-shrink:0}
.ve-sec-badge{margin-left:auto;background:var(--ve-panel2);color:var(--ve-text2);border-radius:4px;padding:1px 6px;font-size:.68rem}
.ve-sec-btn.on .ve-sec-badge{background:rgba(59,130,246,.2);color:var(--ve-accent)}

/* ── Panel content ── */
.ve-panel-content{display:none;flex-direction:column}
.ve-panel-content.on{display:flex}
.ve-panel-section{padding:16px;border-bottom:1px solid var(--ve-border)}
.ve-panel-section:last-child{border-bottom:none}
.ve-panel-title{font-size:.72rem;font-weight:700;color:var(--ve-text2);text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px;display:flex;align-items:center;gap:6px}

/* ── Controls ── */
.ve-fg{margin-bottom:12px}
.ve-label{font-size:.75rem;color:var(--ve-text2);display:block;margin-bottom:5px;font-weight:500}
.ve-input,.ve-select,.ve-textarea{width:100%;background:var(--ve-input-bg);border:1px solid var(--ve-input-border);border-radius:5px;padding:7px 9px;font-size:.8rem;color:var(--ve-text);font-family:inherit;transition:border-color .15s}
.ve-input:focus,.ve-select:focus,.ve-textarea:focus{outline:none;border-color:var(--ve-accent)}
.ve-textarea{resize:vertical;min-height:70px}
.ve-select option{background:var(--ve-panel)}
.ve-grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.ve-range-row{display:flex;align-items:center;gap:8px}
.ve-range{flex:1;accent-color:var(--ve-accent);cursor:pointer}
.ve-range-val{font-size:.75rem;color:var(--ve-text2);min-width:38px;text-align:right}
.ve-color-row{display:flex;align-items:center;gap:7px}
.ve-color-swatch{width:32px;height:32px;border-radius:5px;border:1px solid var(--ve-border);cursor:pointer;flex-shrink:0}
.ve-toggle-row{display:flex;align-items:center;justify-content:space-between;padding:6px 0}
.ve-toggle{position:relative;width:36px;height:20px;flex-shrink:0}
.ve-toggle input{opacity:0;width:0;height:0}
.ve-toggle-slider{position:absolute;inset:0;background:var(--ve-border);border-radius:10px;cursor:pointer;transition:.2s}
.ve-toggle-slider:before{content:'';position:absolute;width:14px;height:14px;left:3px;top:3px;background:#fff;border-radius:50%;transition:.2s}
.ve-toggle input:checked+.ve-toggle-slider{background:var(--ve-accent)}
.ve-toggle input:checked+.ve-toggle-slider:before{transform:translateX(16px)}

/* ── Image upload in sidebar ── */
.ve-upload-zone{border:2px dashed var(--ve-border);border-radius:7px;padding:14px;text-align:center;cursor:pointer;transition:all .15s;background:var(--ve-input-bg)}
.ve-upload-zone:hover{border-color:var(--ve-accent);background:rgba(59,130,246,.05)}
.ve-upload-zone img{max-width:100%;max-height:120px;object-fit:contain;border-radius:4px;display:block;margin:0 auto}
.ve-upload-placeholder{color:var(--ve-text2);font-size:.75rem}
.ve-upload-placeholder span{font-size:1.4rem;display:block;margin-bottom:4px}

/* ── Repeater in sidebar ── */
.ve-repeater-item{background:var(--ve-input-bg);border:1px solid var(--ve-border);border-radius:6px;padding:10px;margin-bottom:8px;position:relative}
.ve-repeater-header{display:flex;align-items:center;justify-content:space-between;cursor:pointer;margin-bottom:8px}
.ve-repeater-label{font-size:.78rem;font-weight:600;color:var(--ve-text)}
.ve-repeater-remove{background:none;border:none;color:#DC2626;cursor:pointer;font-size:.85rem;padding:2px 6px;border-radius:4px}
.ve-repeater-remove:hover{background:rgba(220,38,38,.15)}
.ve-add-btn{width:100%;padding:8px;background:transparent;border:1px dashed var(--ve-border);border-radius:6px;color:var(--ve-text2);font-size:.78rem;cursor:pointer;font-family:inherit;font-weight:600;transition:all .15s;display:flex;align-items:center;justify-content:center;gap:5px}
.ve-add-btn:hover{border-color:var(--ve-accent);color:var(--ve-accent);background:rgba(59,130,246,.05)}

/* ── Preview iframe ── */
.ve-preview{flex:1;display:flex;flex-direction:column;overflow:hidden;background:#f0f0f0}
.ve-preview-toolbar{background:var(--ve-dark);border-bottom:1px solid var(--ve-border);padding:8px 16px;display:flex;align-items:center;gap:10px;flex-shrink:0}
.ve-preview-url{flex:1;background:var(--ve-panel2);border:1px solid var(--ve-border);border-radius:20px;padding:5px 14px;font-size:.78rem;color:var(--ve-text2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ve-device-btns{display:flex;gap:4px}
.ve-device-btn{background:transparent;border:1px solid var(--ve-border);border-radius:5px;color:var(--ve-text2);cursor:pointer;padding:4px 8px;font-size:.85rem;transition:all .15s}
.ve-device-btn.on{border-color:var(--ve-accent);color:var(--ve-accent);background:rgba(59,130,246,.1)}
.ve-iframe-wrap{flex:1;display:flex;justify-content:center;align-items:flex-start;padding:16px;overflow:auto;background:#E5E7EB}
.ve-iframe-wrap.mobile{align-items:flex-start}
#ve-preview-frame{border:none;border-radius:10px;box-shadow:0 8px 32px rgba(0,0,0,.18);transition:width .3s,height .3s;background:#fff}
.ve-iframe-wrap:not(.mobile) #ve-preview-frame{width:100%;height:100%;min-height:500px}
.ve-iframe-wrap.mobile #ve-preview-frame{width:390px;height:720px;border-radius:24px;box-shadow:0 0 0 10px #1A1F2E,0 20px 60px rgba(0,0,0,.5)}

/* ── Loading overlay ── */
.ve-loading{position:fixed;inset:0;background:rgba(26,31,46,.85);display:flex;align-items:center;justify-content:center;z-index:9999;flex-direction:column;gap:12px}
.ve-spinner{width:40px;height:40px;border:3px solid var(--ve-border);border-top-color:var(--ve-accent);border-radius:50%;animation:ve-spin .7s linear infinite}
@keyframes ve-spin{to{transform:rotate(360deg)}}
.ve-loading-text{color:var(--ve-text2);font-size:.85rem}

/* ── Section highlight in preview ── */
.ve-highlight-hint{position:absolute;top:4px;right:4px;background:rgba(59,130,246,.9);color:#fff;font-size:.65rem;font-weight:700;padding:2px 7px;border-radius:4px;pointer-events:none;letter-spacing:.04em}

/* ═══════════════════════════════════════════════════════════════════════════
   ELEMENT INSPECTOR (Yellow Pencil-style)
   ═══════════════════════════════════════════════════════════════════════════ */
.ei-topbar{padding:10px 14px;border-bottom:1px solid var(--ve-border);display:flex;align-items:center;gap:8px;flex-shrink:0}
.ei-inspect-btn{flex:1;display:flex;align-items:center;justify-content:center;gap:7px;padding:9px 12px;border-radius:7px;font-size:.8rem;font-weight:700;cursor:pointer;border:1.5px solid var(--ve-border);background:var(--ve-panel2);color:var(--ve-text2);font-family:inherit;transition:all .2s}
.ei-inspect-btn:hover{border-color:var(--ve-accent);color:var(--ve-accent)}
.ei-inspect-btn.active{background:#F59E0B;border-color:#F59E0B;color:#1A1F2E;box-shadow:0 0 0 3px rgba(245,158,11,.25)}
.ei-scope-bar{padding:8px 14px;border-bottom:1px solid var(--ve-border);display:flex;align-items:center;gap:8px;flex-shrink:0}
.ei-scope-label{font-size:.68rem;font-weight:700;color:var(--ve-text2);text-transform:uppercase;letter-spacing:.07em;flex-shrink:0}
.ei-scope-tabs{display:flex;background:var(--ve-input-bg);border-radius:5px;padding:2px;border:1px solid var(--ve-border);flex:1}
.ei-scope-opt{flex:1;text-align:center;padding:5px 6px;border-radius:3px;font-size:.73rem;font-weight:600;cursor:pointer;color:var(--ve-text2);transition:all .15s}
.ei-scope-opt.on{background:var(--ve-accent);color:#fff}
.ei-scope-global.on{background:#7C3AED}
.ei-empty-state{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:32px 20px;text-align:center;color:var(--ve-text2)}
.ei-empty-icon{font-size:3rem;margin-bottom:12px;opacity:.35;line-height:1}
.ei-empty-text{font-size:.8rem;line-height:1.6}
.ei-empty-text strong{color:var(--ve-text)}
.ei-props-wrap{flex:1;overflow-y:auto;display:flex;flex-direction:column}
.ei-props-wrap::-webkit-scrollbar{width:4px}
.ei-props-wrap::-webkit-scrollbar-thumb{background:var(--ve-border);border-radius:2px}
.ei-element-bar{padding:9px 14px;background:rgba(0,0,0,.2);border-bottom:1px solid var(--ve-border);display:flex;align-items:center;gap:8px;flex-shrink:0}
.ei-el-tag{background:rgba(59,130,246,.25);color:#93C5FD;font-size:.7rem;font-weight:700;padding:2px 7px;border-radius:4px;font-family:monospace;flex-shrink:0}
.ei-el-sel{font-size:.7rem;color:var(--ve-text2);font-family:monospace;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
.ei-el-reset{background:none;border:1px solid rgba(220,38,38,.4);color:#F87171;border-radius:4px;padding:2px 8px;font-size:.68rem;font-weight:600;cursor:pointer;font-family:inherit;flex-shrink:0;transition:all .15s}
.ei-el-reset:hover{background:rgba(220,38,38,.15)}
.ei-group{border-bottom:1px solid var(--ve-border)}
.ei-group-head{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;cursor:pointer;transition:background .15s}
.ei-group-head:hover{background:rgba(255,255,255,.03)}
.ei-group-title{font-size:.71rem;font-weight:700;color:var(--ve-text2);text-transform:uppercase;letter-spacing:.07em;display:flex;align-items:center;gap:6px}
.ei-group-arrow{font-size:.6rem;color:var(--ve-text2);transition:transform .2s}
.ei-group.open .ei-group-arrow{transform:rotate(180deg)}
.ei-group-body{display:none;padding:6px 14px 14px}
.ei-group.open .ei-group-body{display:block}
.ei-row2{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px}
.ei-row3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:8px}
.ei-row4{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:4px;margin-bottom:8px}
.ei-fg{margin-bottom:8px}
.ei-label{font-size:.7rem;color:var(--ve-text2);display:block;margin-bottom:4px;font-weight:500}
.ei-input{width:100%;background:var(--ve-input-bg);border:1px solid var(--ve-input-border);border-radius:5px;padding:5px 7px;font-size:.78rem;color:var(--ve-text);font-family:inherit;transition:border-color .15s}
.ei-input:focus{outline:none;border-color:var(--ve-accent)}
.ei-select{width:100%;background:var(--ve-input-bg);border:1px solid var(--ve-input-border);border-radius:5px;padding:5px 7px;font-size:.78rem;color:var(--ve-text);font-family:inherit}
.ei-select option{background:var(--ve-panel)}
.ei-color-row{display:flex;align-items:center;gap:6px}
.ei-color-swatch{width:30px;height:30px;border-radius:5px;border:1px solid var(--ve-border);cursor:pointer;flex-shrink:0}
.ei-range-row{display:flex;align-items:center;gap:6px}
.ei-range{flex:1;accent-color:var(--ve-accent);cursor:pointer}
.ei-range-val{font-size:.7rem;color:var(--ve-text2);min-width:36px;text-align:right;flex-shrink:0}
.ei-4way{display:grid;grid-template-columns:1fr 1fr;gap:5px}
.ei-4way-center{grid-column:1/-1;display:flex;align-items:center;justify-content:center;gap:4px}
.ei-shadow-presets{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px}
.ei-sh-preset{padding:4px 10px;border-radius:4px;font-size:.7rem;cursor:pointer;border:1px solid var(--ve-border);color:var(--ve-text2);transition:all .15s;background:var(--ve-input-bg)}
.ei-sh-preset:hover,.ei-sh-preset.on{border-color:var(--ve-accent);color:var(--ve-accent)}
.ei-css-output{font-size:.68rem;font-family:monospace;color:#6EE7B7;background:rgba(0,0,0,.35);padding:8px 10px;border-radius:5px;word-break:break-all;line-height:1.7;max-height:90px;overflow-y:auto;border:1px solid rgba(110,231,183,.2)}
.ei-copy-btn{width:100%;background:transparent;border:1px solid var(--ve-border);color:var(--ve-text2);border-radius:5px;padding:5px;font-size:.72rem;font-weight:600;cursor:pointer;font-family:inherit;transition:all .15s;margin-top:5px}
.ei-copy-btn:hover{border-color:var(--ve-accent);color:var(--ve-accent)}
.ei-global-badge{display:inline-block;background:#7C3AED;color:#fff;font-size:.65rem;font-weight:700;padding:1px 6px;border-radius:3px;margin-left:5px}
</style>
</head>
<body>

<!-- Loading overlay -->
<div class="ve-loading" id="ve-loading">
  <div class="ve-spinner"></div>
  <div class="ve-loading-text">Loading Visual Editor…</div>
</div>

<!-- Top Bar -->
<div class="ve-top">
  <div class="ve-top-left">
    <div class="ve-top-logo">✏️ Visual Editor</div>
    <div class="ve-top-sep"></div>
    <div class="ve-top-title"><?php echo esc_html($listing->title); ?></div>
  </div>
  <div class="ve-top-right">
    <span class="ve-save-status" id="ve-save-status"></span>
    <a href="<?php echo home_url('/vendor/edit/'.$listing_id.'/'); ?>" class="ve-btn ve-btn-ghost">📋 Form View</a>
    <a href="<?php echo home_url('/'.$listing->slug.'/'); ?>" target="_blank" class="ve-btn ve-btn-ghost">👁 Live Page</a>
    <button class="ve-btn ve-btn-success" id="ve-save-btn">💾 Save Changes</button>
  </div>
</div>

<div class="ve-layout">

  <!-- ══ SIDEBAR ══════════════════════════════════════════════════════════════ -->
  <div class="ve-sidebar">

    <!-- Tab bar -->
    <div class="ve-sidebar-tabs">
      <div class="ve-tab on" data-tab="sections" onclick="veTab('sections',this)">Sections</div>
      <div class="ve-tab" data-tab="style" onclick="veTab('style',this)">Style</div>
      <div class="ve-tab" data-tab="settings" onclick="veTab('settings',this)">Settings</div>
      <div class="ve-tab" data-tab="elements" onclick="veTab('elements',this)">🎯 Pick</div>
    </div>

    <!-- SECTIONS TAB -->
    <div class="ve-sidebar-body" id="ve-tab-sections">
      <div class="ve-section-nav" id="ve-section-nav">
        <?php
        $sections = [
          ['id'=>'header',  'icon'=>'🏠','label'=>'Header & Logo'],
          ['id'=>'hero',    'icon'=>'🦸','label'=>'Hero Banner'],
          ['id'=>'about',   'icon'=>'ℹ️', 'label'=>'About Section'],
          ['id'=>'services','icon'=>'🛠️','label'=>'Services'],
          ['id'=>'products','icon'=>'📦','label'=>'Products'],
          ['id'=>'process', 'icon'=>'⚙️','label'=>'How It Works'],
          ['id'=>'gallery', 'icon'=>'🖼️','label'=>'Gallery'],
          ['id'=>'stats',   'icon'=>'📊','label'=>'Stats'],
          ['id'=>'why',     'icon'=>'⭐','label'=>'Why Choose Us'],
          ['id'=>'faq',     'icon'=>'❓','label'=>'FAQ'],
          ['id'=>'contact', 'icon'=>'📍','label'=>'Contact'],
          ['id'=>'reviews', 'icon'=>'💬','label'=>'Reviews'],
          ['id'=>'footer',  'icon'=>'🔻','label'=>'Footer'],
        ];
        foreach($sections as $s): ?>
        <div class="ve-sec-btn" data-sec="<?php echo $s['id']; ?>" onclick="veSection('<?php echo $s['id']; ?>')">
          <span class="ve-sec-icon"><?php echo $s['icon']; ?></span>
          <span><?php echo $s['label']; ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div><!-- /sections tab -->

    <!-- STYLE TAB -->
    <div class="ve-sidebar-body" id="ve-tab-style" style="display:none">
      <div class="ve-panel-section">
        <div class="ve-panel-title">🎨 Brand Colours</div>
        <?php foreach([
          ['brand_color',  'Primary Colour',  $listing->brand_color  ?: '#F5A623'],
          ['brand_color2', 'Dark Colour',      $listing->brand_color2 ?: '#1E3A5F'],
          ['accent_color', 'Accent Colour',    $listing->accent_color ?: '#2563EB'],
        ] as [$k,$l,$v]): ?>
        <div class="ve-fg">
          <label class="ve-label"><?php echo $l; ?></label>
          <div class="ve-color-row">
            <input type="color" class="ve-color-swatch" value="<?php echo esc_attr($v); ?>"
              oninput="document.getElementById('ve-c-<?php echo $k; ?>').value=this.value;veLiveUpdate()">
            <input type="text" id="ve-c-<?php echo $k; ?>" class="ve-input" value="<?php echo esc_attr($v); ?>"
              oninput="if(/^#[0-9A-Fa-f]{6}$/.test(this.value)){this.previousElementSibling.value=this.value;veLiveUpdate()}"
              data-field="<?php echo $k; ?>">
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="ve-panel-section">
        <div class="ve-panel-title">🔻 Footer Links Colour</div>
        <?php
        // Real bug fix: the Footer panel (see the `footer:` section builder
        // below) only ever gave vendors plain-text content fields for their
        // Service Links / Quick Links columns — there was NO color control
        // anywhere in this screen for them, even though the platform's
        // TypographyService::resolve()/css_rule() already reads
        // footer_service_links_color / footer_quick_links_color from
        // customizer_data and fully supports it (that plumbing was only ever
        // exposed via the separate, more complex admin "Edit Listing"
        // screen's typography panel). Without a control here, a vendor using
        // THIS screen had no way to ever set these, so the footer always
        // rendered whatever the CSS fallback resolves to — reported as
        // "links color are blue permanent, they should be changed once
        // vendor change in vendor site footer links customization."
        foreach([
          ['footer_service_links_color', 'Service Links Colour', $cd['footer_service_links_color'] ?? '#FFFFFF'],
          ['footer_quick_links_color',   'Quick Links Colour',   $cd['footer_quick_links_color']   ?? '#FFFFFF'],
        ] as [$k,$l,$v]): ?>
        <div class="ve-fg">
          <label class="ve-label"><?php echo $l; ?></label>
          <div class="ve-color-row">
            <input type="color" class="ve-color-swatch" value="<?php echo esc_attr($v); ?>"
              oninput="document.getElementById('ve-c-<?php echo $k; ?>').value=this.value;veLiveUpdate()">
            <input type="text" id="ve-c-<?php echo $k; ?>" class="ve-input" value="<?php echo esc_attr($v); ?>"
              oninput="if(/^#[0-9A-Fa-f]{6}$/.test(this.value)){this.previousElementSibling.value=this.value;veLiveUpdate()}"
              data-field="<?php echo $k; ?>">
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="ve-panel-section">
        <div class="ve-panel-title">📐 Section Spacing</div>
        <div class="ve-fg">
          <label class="ve-label">Top Padding (px)</label>
          <div class="ve-range-row">
            <input type="range" class="ve-range" min="20" max="160" step="4"
              value="<?php echo (int)($cd['section_pt']??64); ?>"
              oninput="document.getElementById('ve-spt-val').textContent=this.value+'px';veLiveUpdate()" data-field="section_pt">
            <span class="ve-range-val" id="ve-spt-val"><?php echo (int)($cd['section_pt']??64); ?>px</span>
          </div>
        </div>
        <div class="ve-fg">
          <label class="ve-label">Bottom Padding (px)</label>
          <div class="ve-range-row">
            <input type="range" class="ve-range" min="20" max="160" step="4"
              value="<?php echo (int)($cd['section_pb']??64); ?>"
              oninput="document.getElementById('ve-spb-val').textContent=this.value+'px';veLiveUpdate()" data-field="section_pb">
            <span class="ve-range-val" id="ve-spb-val"><?php echo (int)($cd['section_pb']??64); ?>px</span>
          </div>
        </div>
        <div class="ve-fg">
          <label class="ve-label">Section Alt Background</label>
          <div class="ve-color-row">
            <input type="color" class="ve-color-swatch" value="<?php echo esc_attr($cd['section_bg']??'#F8FAFC'); ?>"
              oninput="document.getElementById('ve-c-section_bg').value=this.value;veLiveUpdate()">
            <input type="text" id="ve-c-section_bg" class="ve-input" value="<?php echo esc_attr($cd['section_bg']??'#F8FAFC'); ?>"
              oninput="if(/^#[0-9A-Fa-f]{6}$/.test(this.value)){this.previousElementSibling.value=this.value;veLiveUpdate()}" data-field="section_bg">
          </div>
        </div>
      </div>
      <div class="ve-panel-section">
        <div class="ve-panel-title">🔲 Cards</div>
        <div class="ve-fg">
          <label class="ve-label">Card Corner Radius (px)</label>
          <div class="ve-range-row">
            <input type="range" class="ve-range" min="0" max="32" step="2"
              value="<?php echo (int)($cd['card_radius']??12); ?>"
              oninput="document.getElementById('ve-cr-val').textContent=this.value+'px';veLiveUpdate()" data-field="card_radius">
            <span class="ve-range-val" id="ve-cr-val"><?php echo (int)($cd['card_radius']??12); ?>px</span>
          </div>
        </div>
        <div class="ve-fg">
          <label class="ve-label">Card Shadow</label>
          <select class="ve-select" data-field="card_shadow" onchange="veLiveUpdate()">
            <?php foreach(['none'=>'None','sm'=>'Subtle','md'=>'Medium','lg'=>'Strong'] as $v=>$l): ?>
            <option value="<?php echo $v; ?>" <?php echo ($cd['card_shadow']??'sm')===$v?'selected':'';?>><?php echo $l; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="ve-fg">
          <label class="ve-label">Button Corner Radius (px)</label>
          <div class="ve-range-row">
            <input type="range" class="ve-range" min="0" max="50" step="2"
              value="<?php echo (int)($cd['btn_radius']??8); ?>"
              oninput="document.getElementById('ve-br-val').textContent=this.value+'px';veLiveUpdate()" data-field="btn_radius">
            <span class="ve-range-val" id="ve-br-val"><?php echo (int)($cd['btn_radius']??8); ?>px</span>
          </div>
        </div>
      </div>
    </div><!-- /style tab -->

    <!-- SETTINGS TAB -->
    <div class="ve-sidebar-body" id="ve-tab-settings" style="display:none">
      <div class="ve-panel-section">
        <div class="ve-panel-title">📱 Mobile Settings</div>
        <?php
        $md = $listing->mobile_data;
        $toggles = [
          ['show_wa',       'Show WhatsApp Button', $md['show_wa']??1],
          ['show_phone',    'Show Phone Button',    $md['show_phone']??1],
          ['show_trust_bar','Show Trust Bar',        $md['show_trust_bar']??1],
          ['show_stats',    'Show Stats Section',    $md['show_stats']??1],
          ['show_gallery',  'Show Gallery',          $md['show_gallery']??1],
          ['float_cta',     'Floating CTA Bar',      $md['float_cta']??1],
          ['show_wnav',     'Right-Side Navigation', $md['show_wnav']??1],
        ];
        foreach($toggles as [$k,$l,$v]): ?>
        <div class="ve-toggle-row">
          <span class="ve-label" style="margin:0"><?php echo $l; ?></span>
          <label class="ve-toggle">
            <input type="checkbox" <?php echo $v?'checked':''; ?> data-mobile="<?php echo $k; ?>" onchange="veLiveUpdate()">
            <span class="ve-toggle-slider"></span>
          </label>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="ve-panel-section">
        <div class="ve-panel-title">📋 SEO</div>
        <div class="ve-fg">
          <label class="ve-label">SEO Title</label>
          <input type="text" class="ve-input" data-seo="seo_title" value="<?php echo esc_attr($listing->seo_title??''); ?>" placeholder="Auto-generated">
        </div>
        <div class="ve-fg">
          <label class="ve-label">SEO Description</label>
          <textarea class="ve-textarea" data-seo="seo_desc" placeholder="Auto-generated"><?php echo esc_textarea($listing->seo_desc??''); ?></textarea>
        </div>
        <div class="ve-fg">
          <label class="ve-label">Focus Keyword</label>
          <input type="text" class="ve-input" data-seo="seo_focus_keyword" value="<?php echo esc_attr($listing->seo_focus_keyword??''); ?>" placeholder="e.g. plumber in Delhi">
        </div>
        <div class="ve-fg">
          <label class="ve-label">Keywords</label>
          <input type="text" class="ve-input" data-seo="seo_keywords" value="<?php echo esc_attr($listing->seo_keywords??''); ?>" placeholder="keyword1, keyword2">
        </div>
        <div class="ve-fg">
          <label class="ve-label">OG Image URL <span style="font-size:.7rem;color:var(--ve-text2)">(social sharing)</span></label>
          <input type="url" class="ve-input" data-seo="og_image" value="<?php echo esc_attr($listing->og_image??''); ?>" placeholder="https://">
        </div>
        <div class="ve-fg">
          <label class="ve-label">Robots</label>
          <select class="ve-input" data-seo="seo_robots">
            <option value="index,follow" <?php selected($listing->seo_robots??'index,follow','index,follow'); ?>>Index, Follow</option>
            <option value="noindex,follow" <?php selected($listing->seo_robots??'','noindex,follow'); ?>>No Index, Follow</option>
            <option value="noindex,nofollow" <?php selected($listing->seo_robots??'','noindex,nofollow'); ?>>No Index, No Follow</option>
          </select>
        </div>
        <div class="ve-fg">
          <label class="ve-label">URL Slug</label>
          <input type="text" class="ve-input" data-seo="slug" value="<?php echo esc_attr($listing->slug); ?>">
          <span style="font-size:.7rem;color:var(--ve-text2);margin-top:3px;display:block"><?php echo home_url('/'); ?>{slug}/</span>
        </div>
      </div>
    </div><!-- /settings tab -->

    <!-- SECTION PANELS (appear below nav when section selected) -->
    <div class="ve-sidebar-body" id="ve-section-panels" style="display:none;flex:1;overflow-y:auto">
      <div style="padding:10px 14px 6px;display:flex;align-items:center;gap:8px;border-bottom:1px solid var(--ve-border);flex-shrink:0">
        <button onclick="veBack()" style="background:none;border:none;color:var(--ve-text2);cursor:pointer;font-size:.8rem;padding:4px 8px;border-radius:4px;font-family:inherit">← Back</button>
        <span id="ve-section-title" style="font-size:.82rem;font-weight:600;color:var(--ve-text)"></span>
      </div>
      <div id="ve-section-panel-body" style="padding:14px"></div>
    </div>

    <!-- ══ ELEMENTS TAB ════════════════════════════════════════════════════════ -->
    <div class="ve-sidebar-body" id="ve-tab-elements" style="display:none;flex-direction:column;height:100%;padding:0;overflow:hidden">

      <!-- Inspector toggle button -->
      <div class="ei-topbar">
        <button class="ei-inspect-btn" id="ei-inspect-btn" onclick="eiToggle()">
          <span id="ei-btn-icon">🎯</span>
          <span id="ei-btn-text">Start Inspecting</span>
        </button>
      </div>

      <!-- Scope selector -->
      <div class="ei-scope-bar">
        <span class="ei-scope-label">Scope:</span>
        <div class="ei-scope-tabs">
          <div class="ei-scope-opt on" id="ei-scope-page" onclick="eiScope('page',this)">📄 This Page</div>
          <div class="ei-scope-opt ei-scope-global" id="ei-scope-global" onclick="eiScope('global',this)">🌐 Global</div>
        </div>
      </div>

      <!-- Empty state -->
      <div class="ei-empty-state" id="ei-empty">
        <div class="ei-empty-icon">🖱️</div>
        <div class="ei-empty-text">
          Click <strong>Start Inspecting</strong><br>
          then click any element on<br>
          the preview to edit its styles.<br><br>
          <span style="font-size:.72rem;color:var(--ve-text2);opacity:.7">
            📄 Page scope = affects only this listing<br>
            🌐 Global scope = affects all microsites
          </span>
        </div>
      </div>

      <!-- Properties panel (shown after selection) -->
      <div class="ei-props-wrap" id="ei-props-wrap" style="display:none">

        <!-- Selected element info bar -->
        <div class="ei-element-bar" id="ei-element-bar">
          <span class="ei-el-tag" id="ei-el-tag">div</span>
          <span class="ei-el-sel" id="ei-el-sel" title=""></span>
          <button class="ei-el-reset" onclick="eiReset()">✕ Reset</button>
        </div>

        <!-- ── Typography ── -->
        <div class="ei-group open" id="ei-g-typo">
          <div class="ei-group-head" onclick="eiGroupToggle('typo')">
            <span class="ei-group-title">🔤 Typography</span>
            <span class="ei-group-arrow">▼</span>
          </div>
          <div class="ei-group-body">
            <div class="ei-fg">
              <label class="ei-label">Text Color</label>
              <div class="ei-color-row">
                <input type="color" class="ei-color-swatch" id="ei-color-color" oninput="eiProp('color',this.value);document.getElementById('ei-text-color').value=this.value">
                <input type="text" class="ei-input" id="ei-text-color" placeholder="#000000" oninput="eiColorTextChange('color',this)" style="font-family:monospace">
              </div>
            </div>
            <div class="ei-row2">
              <div class="ei-fg">
                <label class="ei-label">Font Size</label>
                <input type="text" class="ei-input" id="ei-font-size" placeholder="16px" oninput="eiProp('font-size',this.value)">
              </div>
              <div class="ei-fg">
                <label class="ei-label">Font Weight</label>
                <select class="ei-select" id="ei-font-weight" onchange="eiProp('font-weight',this.value)">
                  <option value="">–</option>
                  <option value="300">Light 300</option>
                  <option value="400">Regular 400</option>
                  <option value="500">Medium 500</option>
                  <option value="600">SemiBold 600</option>
                  <option value="700">Bold 700</option>
                  <option value="800">ExtraBold 800</option>
                </select>
              </div>
            </div>
            <div class="ei-row2">
              <div class="ei-fg">
                <label class="ei-label">Line Height</label>
                <input type="text" class="ei-input" id="ei-line-height" placeholder="1.5" oninput="eiProp('line-height',this.value)">
              </div>
              <div class="ei-fg">
                <label class="ei-label">Letter Spacing</label>
                <input type="text" class="ei-input" id="ei-letter-spacing" placeholder="0px" oninput="eiProp('letter-spacing',this.value)">
              </div>
            </div>
            <div class="ei-row2">
              <div class="ei-fg">
                <label class="ei-label">Text Align</label>
                <select class="ei-select" id="ei-text-align" onchange="eiProp('text-align',this.value)">
                  <option value="">–</option>
                  <option value="left">Left</option>
                  <option value="center">Center</option>
                  <option value="right">Right</option>
                  <option value="justify">Justify</option>
                </select>
              </div>
              <div class="ei-fg">
                <label class="ei-label">Transform</label>
                <select class="ei-select" id="ei-text-transform" onchange="eiProp('text-transform',this.value)">
                  <option value="">–</option>
                  <option value="none">None</option>
                  <option value="uppercase">UPPERCASE</option>
                  <option value="lowercase">lowercase</option>
                  <option value="capitalize">Capitalize</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <!-- ── Background ── -->
        <div class="ei-group" id="ei-g-bg">
          <div class="ei-group-head" onclick="eiGroupToggle('bg')">
            <span class="ei-group-title">🎨 Background</span>
            <span class="ei-group-arrow">▼</span>
          </div>
          <div class="ei-group-body">
            <div class="ei-fg">
              <label class="ei-label">Background Color</label>
              <div class="ei-color-row">
                <input type="color" class="ei-color-swatch" id="ei-color-bg" oninput="eiProp('background-color',this.value);document.getElementById('ei-text-bg').value=this.value">
                <input type="text" class="ei-input" id="ei-text-bg" placeholder="transparent" oninput="eiColorTextChange('background-color',this)" style="font-family:monospace">
              </div>
            </div>
            <div class="ei-fg">
              <label class="ei-label">Opacity</label>
              <div class="ei-range-row">
                <input type="range" class="ei-range" id="ei-opacity" min="0" max="1" step="0.05" value="1"
                  oninput="document.getElementById('ei-opacity-val').textContent=Math.round(this.value*100)+'%';eiProp('opacity',this.value)">
                <span class="ei-range-val" id="ei-opacity-val">100%</span>
              </div>
            </div>
          </div>
        </div>

        <!-- ── Spacing ── -->
        <div class="ei-group" id="ei-g-spacing">
          <div class="ei-group-head" onclick="eiGroupToggle('spacing')">
            <span class="ei-group-title">📐 Spacing</span>
            <span class="ei-group-arrow">▼</span>
          </div>
          <div class="ei-group-body">
            <div class="ei-label" style="margin-bottom:6px">Padding (px)</div>
            <div class="ei-row2" style="margin-bottom:4px">
              <div class="ei-fg" style="margin-bottom:0">
                <label class="ei-label">Top</label>
                <input type="text" class="ei-input" id="ei-pt" placeholder="0" oninput="eiProp('padding-top',this.value)">
              </div>
              <div class="ei-fg" style="margin-bottom:0">
                <label class="ei-label">Right</label>
                <input type="text" class="ei-input" id="ei-pr" placeholder="0" oninput="eiProp('padding-right',this.value)">
              </div>
            </div>
            <div class="ei-row2" style="margin-bottom:12px">
              <div class="ei-fg" style="margin-bottom:0">
                <label class="ei-label">Bottom</label>
                <input type="text" class="ei-input" id="ei-pb" placeholder="0" oninput="eiProp('padding-bottom',this.value)">
              </div>
              <div class="ei-fg" style="margin-bottom:0">
                <label class="ei-label">Left</label>
                <input type="text" class="ei-input" id="ei-pl" placeholder="0" oninput="eiProp('padding-left',this.value)">
              </div>
            </div>
            <div class="ei-label" style="margin-bottom:6px">Margin (px)</div>
            <div class="ei-row2" style="margin-bottom:4px">
              <div class="ei-fg" style="margin-bottom:0">
                <label class="ei-label">Top</label>
                <input type="text" class="ei-input" id="ei-mt" placeholder="0" oninput="eiProp('margin-top',this.value)">
              </div>
              <div class="ei-fg" style="margin-bottom:0">
                <label class="ei-label">Right</label>
                <input type="text" class="ei-input" id="ei-mr" placeholder="auto" oninput="eiProp('margin-right',this.value)">
              </div>
            </div>
            <div class="ei-row2">
              <div class="ei-fg" style="margin-bottom:0">
                <label class="ei-label">Bottom</label>
                <input type="text" class="ei-input" id="ei-mb" placeholder="0" oninput="eiProp('margin-bottom',this.value)">
              </div>
              <div class="ei-fg" style="margin-bottom:0">
                <label class="ei-label">Left</label>
                <input type="text" class="ei-input" id="ei-ml" placeholder="auto" oninput="eiProp('margin-left',this.value)">
              </div>
            </div>
          </div>
        </div>

        <!-- ── Border ── -->
        <div class="ei-group" id="ei-g-border">
          <div class="ei-group-head" onclick="eiGroupToggle('border')">
            <span class="ei-group-title">🔲 Border</span>
            <span class="ei-group-arrow">▼</span>
          </div>
          <div class="ei-group-body">
            <div class="ei-row2">
              <div class="ei-fg">
                <label class="ei-label">Width</label>
                <input type="text" class="ei-input" id="ei-border-w" placeholder="0px" oninput="eiProp('border-width',this.value)">
              </div>
              <div class="ei-fg">
                <label class="ei-label">Style</label>
                <select class="ei-select" id="ei-border-style" onchange="eiProp('border-style',this.value)">
                  <option value="">–</option>
                  <option value="solid">Solid</option>
                  <option value="dashed">Dashed</option>
                  <option value="dotted">Dotted</option>
                  <option value="none">None</option>
                </select>
              </div>
            </div>
            <div class="ei-fg">
              <label class="ei-label">Border Color</label>
              <div class="ei-color-row">
                <input type="color" class="ei-color-swatch" id="ei-color-border" oninput="eiProp('border-color',this.value);document.getElementById('ei-text-border').value=this.value">
                <input type="text" class="ei-input" id="ei-text-border" placeholder="#E2E8F0" oninput="eiColorTextChange('border-color',this)" style="font-family:monospace">
              </div>
            </div>
            <div class="ei-fg">
              <label class="ei-label">Border Radius</label>
              <div class="ei-range-row">
                <input type="range" class="ei-range" id="ei-border-radius" min="0" max="50" step="1"
                  oninput="document.getElementById('ei-br-val').textContent=this.value+'px';eiProp('border-radius',this.value+'px')">
                <span class="ei-range-val" id="ei-br-val">0px</span>
              </div>
            </div>
          </div>
        </div>

        <!-- ── Shadow ── -->
        <div class="ei-group" id="ei-g-shadow">
          <div class="ei-group-head" onclick="eiGroupToggle('shadow')">
            <span class="ei-group-title">💫 Shadow</span>
            <span class="ei-group-arrow">▼</span>
          </div>
          <div class="ei-group-body">
            <div class="ei-shadow-presets" id="ei-shadow-presets">
              <div class="ei-sh-preset" onclick="eiShadowPreset('none',this)">None</div>
              <div class="ei-sh-preset" onclick="eiShadowPreset('sm',this)">Small</div>
              <div class="ei-sh-preset" onclick="eiShadowPreset('md',this)">Medium</div>
              <div class="ei-sh-preset" onclick="eiShadowPreset('lg',this)">Large</div>
              <div class="ei-sh-preset" onclick="eiShadowPreset('xl',this)">Extra</div>
            </div>
            <div class="ei-fg">
              <label class="ei-label">Custom Shadow</label>
              <input type="text" class="ei-input" id="ei-box-shadow" placeholder="0 4px 16px rgba(0,0,0,.1)"
                oninput="eiProp('box-shadow',this.value)">
            </div>
          </div>
        </div>

        <!-- ── Size & Layout ── -->
        <div class="ei-group" id="ei-g-size">
          <div class="ei-group-head" onclick="eiGroupToggle('size')">
            <span class="ei-group-title">📏 Size & Layout</span>
            <span class="ei-group-arrow">▼</span>
          </div>
          <div class="ei-group-body">
            <div class="ei-row2">
              <div class="ei-fg">
                <label class="ei-label">Width</label>
                <input type="text" class="ei-input" id="ei-width" placeholder="auto" oninput="eiProp('width',this.value)">
              </div>
              <div class="ei-fg">
                <label class="ei-label">Max Width</label>
                <input type="text" class="ei-input" id="ei-max-width" placeholder="none" oninput="eiProp('max-width',this.value)">
              </div>
            </div>
            <div class="ei-row2">
              <div class="ei-fg">
                <label class="ei-label">Min Height</label>
                <input type="text" class="ei-input" id="ei-min-height" placeholder="auto" oninput="eiProp('min-height',this.value)">
              </div>
              <div class="ei-fg">
                <label class="ei-label">Display</label>
                <select class="ei-select" id="ei-display" onchange="eiProp('display',this.value)">
                  <option value="">–</option>
                  <option value="block">block</option>
                  <option value="flex">flex</option>
                  <option value="grid">grid</option>
                  <option value="inline">inline</option>
                  <option value="inline-block">inline-block</option>
                  <option value="none">none (hide)</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <!-- ── Custom CSS ── -->
        <div class="ei-group" id="ei-g-custom">
          <div class="ei-group-head" onclick="eiGroupToggle('custom')">
            <span class="ei-group-title">💻 Custom CSS</span>
            <span class="ei-group-arrow">▼</span>
          </div>
          <div class="ei-group-body">
            <div class="ei-fg">
              <label class="ei-label">CSS Declarations</label>
              <textarea class="ei-input" id="ei-custom-css" rows="4" placeholder="e.g. transform: rotate(2deg);
transition: all .3s ease;"
                oninput="eiCustomCSS(this.value)" style="resize:vertical;font-family:monospace;font-size:.75rem"></textarea>
            </div>
            <div class="ei-label" style="margin-top:6px">Generated CSS Preview</div>
            <div class="ei-css-output" id="ei-css-output"></div>
            <button class="ei-copy-btn" onclick="eiCopyCSS()">📋 Copy CSS</button>
          </div>
        </div>

        <div style="padding:14px">
          <button class="ei-el-reset" style="width:100%;padding:8px" onclick="eiReset()">✕ Reset This Element</button>
        </div>

      </div><!-- /ei-props-wrap -->

    </div><!-- /elements tab -->

  </div><!-- /sidebar -->

  <!-- ══ PREVIEW AREA ════════════════════════════════════════════════════════ -->
  <div class="ve-preview">
    <div class="ve-preview-toolbar">
      <span style="font-size:.75rem;color:var(--ve-text2)">Preview</span>
      <div class="ve-device-btns">
        <button class="ve-device-btn on" onclick="veDevice('desktop',this)" title="Desktop">🖥</button>
        <button class="ve-device-btn" onclick="veDevice('tablet',this)" title="Tablet">📱</button>
        <button class="ve-device-btn" onclick="veDevice('mobile',this)" title="Mobile">📲</button>
      </div>
      <div class="ve-preview-url" id="ve-preview-url"><?php echo esc_html(home_url('/'.$listing->slug.'/')); ?></div>
      <button class="ve-btn ve-btn-ghost" onclick="veRefresh()" style="font-size:.75rem;padding:4px 10px">↺ Refresh</button>
    </div>
    <div class="ve-iframe-wrap" id="ve-iframe-wrap">
      <iframe id="ve-preview-frame" src="<?php echo esc_url($preview_url); ?>" onload="veFrameLoaded()"></iframe>
    </div>
  </div>

</div><!-- /layout -->

<!-- Hidden data store -->
<input type="hidden" id="ve-listing-id" value="<?php echo $listing_id; ?>">
<textarea id="ve-data-store" style="display:none"><?php echo esc_textarea(wp_json_encode([
  'title'          => $listing->title,
  'tagline'        => $listing->tagline ?? '',
  'brand_color'    => $listing->brand_color ?: '#F5A623',
  'brand_color2'   => $listing->brand_color2 ?: '#1E3A5F',
  'accent_color'   => $listing->accent_color ?: '#2563EB',
  'logo_url'       => $listing->logo_url ?? '',
  'banner_url'     => $listing->banner_url ?? '',
  'phone'          => $listing->phone ?? '',
  'whatsapp'       => $listing->whatsapp ?? '',
  'email'          => $listing->email ?? '',
  'city'           => $listing->city ?? '',
  'address'        => $listing->address ?? '',
  'hero_data'      => $hd,
  'about_data'     => $ad,
  'footer_data'    => $ftd,
  'customizer_data'=> $cd,
  'mobile_data'    => $listing->mobile_data,
  'services_data'  => $listing->services_data,
  'process_data'   => $listing->process_data,
  'faq_data'       => $listing->faq_data,
  'why_choose_data'=> $listing->why_choose_data,
  'stats_data'     => $listing->stats_data,
  'gallery'        => $listing->gallery,
  'opening_hours'  => $listing->opening_hours,
  'seo_title'         => $listing->seo_title         ?? '',
  'seo_desc'          => $listing->seo_desc           ?? '',
  'seo_keywords'      => $listing->seo_keywords       ?? '',
  'seo_focus_keyword' => $listing->seo_focus_keyword  ?? '',
  'og_image'          => $listing->og_image           ?? '',
  'seo_robots'        => $listing->seo_robots         ?? 'index,follow',
  'slug'           => $listing->slug,
  'short_desc'     => $listing->short_desc ?? '',
  'full_desc'      => $listing->full_desc ?? '',
  'trust_bar_text' => $listing->trust_bar_text ?? '',
  'gallery_title'  => $listing->gallery_title ?? '',
  'services_section_title' => $listing->services_section_title ?? '',
  'services_section_desc'  => $listing->services_section_desc ?? '',
  'process_section_title'  => $listing->process_section_title ?? '',
  'products_data'  => $listing->products_data,
  'feedback_data'  => $listing->feedback_data,
])); ?></textarea>

<script src="<?php echo includes_url('js/jquery/jquery.min.js'); ?>"></script>
<script>
var GS=<?php echo wp_json_encode(\GoodService\Core\Assets::js_config()); ?>;
// Safety: ensure critical fields always present
if(!GS.ajax_url) GS.ajax_url='<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
if(!GS.nonce)    GS.nonce   ='<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>';
if(!GS.i18n)     GS.i18n    ={error:'Something went wrong. Please try again.'};
</script>
<script src="<?php echo GS_URL; ?>assets/js/goodservice.js?v=<?php echo GS_VERSION; ?>"></script>
<script>
var VE = {
  data: JSON.parse(document.getElementById('ve-data-store').value),
  dirty: false,
  saveTimer: null,
  currentSection: null,
  previewBase: '<?php echo esc_js(home_url("/".$listing->slug."/")); ?>',
  nonce: '<?php echo wp_create_nonce("gs_ajax"); ?>',
  listingId: <?php echo $listing_id; ?>,
};

// ── Init ──────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  setTimeout(function(){ document.getElementById('ve-loading').style.display='none'; }, 800);
  veBindStyleTab();
  veAutoSave();
});

function veFrameLoaded() {
  document.getElementById('ve-loading').style.display='none';
}

// ── Tabs ────────────────────────────────────────────────────────────────────
function veTab(tab, el) {
  document.querySelectorAll('.ve-tab').forEach(function(t){ t.classList.remove('on'); });
  el.classList.add('on');
  document.getElementById('ve-tab-sections').style.display  = tab==='sections' ? '' : 'none';
  document.getElementById('ve-tab-style').style.display     = tab==='style'    ? '' : 'none';
  document.getElementById('ve-tab-settings').style.display  = tab==='settings' ? '' : 'none';
  document.getElementById('ve-tab-elements').style.display  = tab==='elements' ? 'flex' : 'none';
  document.getElementById('ve-section-panels').style.display = 'none';
}

// ── Section panel ─────────────────────────────────────────────────────────
var sectionPanels = {
  header: function() {
    return vePanelHtml('Header & Logo', [
      veFieldText('Listing Name', 'title', VE.data.title),
      veFieldText('Tagline', 'tagline', VE.data.tagline),
      veFieldImage('Logo Image', 'logo_url', VE.data.logo_url),
      veFieldText('Nav CTA Button Text', 'header_cta_text', VE.data.hero_data.header_cta_text||'Get Free Quote'),
      veFieldText('Trust Bar Text', 'trust_bar_text', VE.data.trust_bar_text),
    ]);
  },
  hero: function() {
    return vePanelHtml('Hero Section', [
      veFieldImage('Hero Right Image', 'hero_right_image', VE.data.hero_data.hero_right_image||''),
      veFieldImage('Banner/Background', 'banner_url', VE.data.banner_url),
      veFieldText('Heading', 'hero_left_heading', VE.data.hero_data.hero_left_heading||''),
      veFieldTextarea('Description', 'hero_left_description', VE.data.hero_data.hero_left_description||''),
      veFieldText('Button Text', 'hero_btn_text', VE.data.hero_data.hero_btn_text||"Let's Talk Now"),
      veFieldRange('Banner Height (px)', 'banner_height', VE.data.customizer_data.banner_height||400, 200, 700),
      veFieldSelect('Hero Image Fit', 'hero_img_fit', VE.data.customizer_data.hero_img_fit||'cover',
        {cover:'Cover (fill)',contain:'Contain (full image)',auto:'Auto'}),
    ]);
  },
  about: function() {
    return vePanelHtml('About Section', [
      veFieldText('Section Title', 'about_title', VE.data.about_data.about_title||''),
      veFieldTextarea('Description', 'about_description', VE.data.about_data.about_description||''),
      veFieldImage('Side Image', 'about_image', VE.data.about_data.about_image||''),
      veFieldRange('Image Height (px)', 'about_img_height', VE.data.customizer_data.about_img_height||350, 150, 600),
      veFieldSelect('Image Fit', 'about_img_fit', VE.data.customizer_data.about_img_fit||'cover',
        {cover:'Cover',contain:'Contain (full)',auto:'Auto'}),
      veFieldTextarea('Key Highlights (one per line)', 'highlights', VE.data.highlights||''),
    ]);
  },
  services: function() {
    return vePanelHtml('Services', [
      veFieldText('Section Title', 'services_section_title', VE.data.services_section_title||'Our Services'),
      veFieldText('Section Description', 'services_section_desc', VE.data.services_section_desc||''),
    ]) + veRepeaterHtml('services', VE.data.services_data, ['name','icon','description','price']);
  },
  products: function() {
    return vePanelHtml('Products', [
      veFieldText('Section Title', 'products_section_title', VE.data.hero_data.products_section_title||'Our Products'),
    ]) + veRepeaterHtml('products', VE.data.products_data, ['name','description','price','image']);
  },
  process: function() {
    return vePanelHtml('How It Works', [
      veFieldText('Section Title', 'process_section_title', VE.data.process_section_title||'How It Works'),
    ]) + veRepeaterHtml('process', VE.data.process_data, ['title','icon','description']);
  },
  gallery: function() {
    return vePanelHtml('Gallery', [
      veFieldText('Gallery Title', 'gallery_title', VE.data.gallery_title||'View All Gallery'),
      veFieldRange('Image Height (px)', 'gallery_img_height', VE.data.customizer_data.gallery_img_height||240, 150, 500),
      veFieldSelect('Image Fit', 'gallery_img_fit', VE.data.customizer_data.gallery_img_fit||'cover',
        {cover:'Cover (uniform grid)',contain:'Contain (no crop)',auto:'Auto'}),
    ]);
  },
  stats: function() {
    var sd = VE.data.stats_data || {};
    return vePanelHtml('Stats / Numbers', [
      veFieldText('Services Offered', 'stat_total_services', sd.total_services||''),
      veFieldText('Years Experience', 'stat_experience_years', sd.experience_years||''),
      veFieldText('Happy Clients', 'stat_happy_clients', sd.happy_clients||''),
      veFieldText('Projects Completed', 'stat_projects_completed', sd.projects_completed||''),
      veFieldText('Positive Reviews', 'stat_positive_reviews', sd.positive_reviews||''),
      veFieldText('Cities Served', 'stat_cities_served', sd.cities_served||''),
    ]);
  },
  why: function() {
    return vePanelHtml('Why Choose Us', [
      veFieldText('Section Title', 'why_section_title', VE.data.why_choose_data.section_title||'Why Choose Us'),
    ]) + veRepeaterHtml('why', VE.data.why_choose_data, ['icon','title','description']);
  },
  faq: function() {
    return vePanelHtml('FAQ', [
      veFieldText('Section Title', 'faq_section_title', VE.data.hero_data.faq_section_title||'Frequently Asked Questions'),
    ]) + veRepeaterHtml('faq', VE.data.faq_data, ['question','answer']);
  },
  contact: function() {
    return vePanelHtml('Contact', [
      veFieldText('Phone', 'phone', VE.data.phone),
      veFieldText('WhatsApp', 'whatsapp', VE.data.whatsapp),
      veFieldText('Email', 'email', VE.data.email),
      veFieldText('City', 'city', VE.data.city),
      veFieldTextarea('Address', 'address', VE.data.address),
    ]);
  },
  reviews: function() {
    var fbd = VE.data.feedback_data || {};
    return vePanelHtml('Reviews', [
      veFieldText('Section Title', 'reviews_section_title', fbd.reviews_section_title||'Customer Reviews'),
      veFieldText('Form Title', 'review_form_title', fbd.review_form_title||'Submit Your Feedback'),
    ]);
  },
  footer: function() {
    var ftd = VE.data.footer_data || {};
    return vePanelHtml('Footer', [
      veFieldTextarea('Footer About Text', 'footer_about_text', ftd.footer_about_text||''),
      veFieldTextarea('Service Links (one per line)', 'footer_service_links', ftd.footer_service_links||''),
      veFieldTextarea('Quick Links (Label|URL, one per line)', 'footer_quick_links', ftd.footer_quick_links||''),
    ]);
  },
};

function veSection(id) {
  VE.currentSection = id;
  var labels = {
    header:'Header & Logo',hero:'Hero Section',about:'About',services:'Services',
    products:'Products',process:'How It Works',gallery:'Gallery',stats:'Stats',
    why:'Why Choose Us',faq:'FAQ',contact:'Contact',reviews:'Reviews',footer:'Footer'
  };
  document.querySelectorAll('.ve-sec-btn').forEach(function(b){ b.classList.toggle('on', b.dataset.sec===id); });
  document.getElementById('ve-section-title').textContent = labels[id] || id;

  // Hide nav, show panel
  document.getElementById('ve-section-nav').style.display = 'none';
  document.getElementById('ve-section-panels').style.display = 'flex';

  var body = document.getElementById('ve-section-panel-body');
  body.innerHTML = (sectionPanels[id] ? sectionPanels[id]() : '<p style="color:var(--ve-text2);font-size:.82rem;padding:8px">No controls for this section yet.</p>');

  // Bind events on newly rendered controls
  veBindPanelControls(body);

  // Scroll preview to section
  var frame = document.getElementById('ve-preview-frame');
  try {
    var sec = frame.contentDocument.getElementById('vs-sec-'+id);
    if (sec) sec.scrollIntoView({behavior:'smooth',block:'start'});
  } catch(e){}
}

function veBack() {
  document.getElementById('ve-section-nav').style.display = '';
  document.getElementById('ve-section-panels').style.display = 'none';
  document.querySelectorAll('.ve-sec-btn').forEach(function(b){ b.classList.remove('on'); });
  VE.currentSection = null;
}

// ── Panel HTML builders ──────────────────────────────────────────────────────
function vePanelHtml(title, fields) {
  return '<div style="margin-bottom:16px"><div style="font-size:.72rem;font-weight:700;color:var(--ve-text2);text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px">'+title+'</div>'
    + fields.join('') + '</div>';
}
function veFieldText(label, key, val) {
  return '<div class="ve-fg"><label class="ve-label">'+label+'</label>'
    +'<input type="text" class="ve-input" data-ve="'+key+'" value="'+escHtml(val)+'" oninput="veFieldChange(this)"></div>';
}
function veFieldTextarea(label, key, val) {
  return '<div class="ve-fg"><label class="ve-label">'+label+'</label>'
    +'<textarea class="ve-textarea" data-ve="'+key+'" oninput="veFieldChange(this)">'+escHtml(val)+'</textarea></div>';
}
function veFieldRange(label, key, val, min, max) {
  return '<div class="ve-fg"><label class="ve-label">'+label+'</label>'
    +'<div class="ve-range-row"><input type="range" class="ve-range" min="'+min+'" max="'+max+'" step="10" value="'+val+'" data-ve="'+key+'" oninput="document.getElementById(\'ve-r-'+key+'\').textContent=this.value+\'px\';veFieldChange(this)">'
    +'<span class="ve-range-val" id="ve-r-'+key+'">'+val+'px</span></div></div>';
}
function veFieldSelect(label, key, val, options) {
  var opts = Object.keys(options).map(function(v){
    return '<option value="'+v+'"'+(val===v?' selected':'')+'>'+options[v]+'</option>';
  }).join('');
  return '<div class="ve-fg"><label class="ve-label">'+label+'</label>'
    +'<select class="ve-select" data-ve="'+key+'" onchange="veFieldChange(this)">'+opts+'</select></div>';
}
function veFieldImage(label, key, val) {
  var preview = val ? '<img src="'+escHtml(val)+'" style="max-width:100%;max-height:100px;object-fit:contain;display:block;margin-bottom:6px">' : '';
  return '<div class="ve-fg"><label class="ve-label">'+label+'</label>'
    +'<div class="ve-upload-zone" onclick="vePickImage(\''+key+'\',this)">'
    +preview
    +'<div class="ve-upload-placeholder"><span>📤</span>Click to upload / change</div>'
    +'</div>'
    +'<input type="hidden" class="ve-img-hidden" data-ve="'+key+'" value="'+escHtml(val)+'"></div>';
}
function veRepeaterHtml(type, items, fields) {
  var html = '<div id="ve-rep-'+type+'"><div style="font-size:.72rem;font-weight:700;color:var(--ve-text2);text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px">Items</div>';
  var arr = Array.isArray(items) ? items : Object.values(items).filter(function(v){ return typeof v === 'object'; });
  arr.forEach(function(item, i) {
    html += '<div class="ve-repeater-item" data-rep-idx="'+i+'">';
    html += '<div class="ve-repeater-header"><span class="ve-repeater-label">'+(item.name||item.title||item.question||('Item '+(i+1)))+'</span>';
    html += '<button class="ve-repeater-remove" onclick="veRepRemove(\''+type+'\','+i+')">✕</button></div>';
    fields.forEach(function(f) {
      var v = item[f] || '';
      if (f === 'answer' || f === 'description') {
        html += '<div class="ve-fg"><label class="ve-label">'+f+'</label><textarea class="ve-textarea" data-rep="'+type+'" data-rep-i="'+i+'" data-rep-f="'+f+'" oninput="veRepChange(this)">'+escHtml(v)+'</textarea></div>';
      } else if (f === 'image') {
        html += veFieldImage(f, 'rep_'+type+'_'+i+'_image', v);
      } else {
        html += '<div class="ve-fg"><label class="ve-label">'+f+'</label><input type="text" class="ve-input" data-rep="'+type+'" data-rep-i="'+i+'" data-rep-f="'+f+'" value="'+escHtml(v)+'" oninput="veRepChange(this)"></div>';
      }
    });
    html += '</div>';
  });
  html += '<button class="ve-add-btn" onclick="veRepAdd(\''+type+'\')">+ Add Item</button></div>';
  return html;
}

// ── Field change handlers ─────────────────────────────────────────────────────
function veFieldChange(el) {
  var key = el.dataset.ve;
  var val = el.value;
  veSetField(key, val);
  veMarkDirty();
  veSchedulePreviewUpdate();
}
function veSetField(key, val) {
  // Route to correct data path
  var heroKeys = ['hero_left_heading','hero_left_description','hero_btn_text','hero_btn_link','hero_right_image','header_cta_text','header_cta_link','nav_items','faq_section_title','products_section_title'];
  var aboutKeys = ['about_title','about_description','about_image'];
  var footerKeys = ['footer_about_text','footer_service_links','footer_quick_links','footer_nl_btn'];
  var custKeys = ['section_pt','section_pb','section_bg','card_radius','card_shadow','btn_radius','banner_height','hero_img_height','hero_img_fit','about_img_height','about_img_fit','gallery_img_height','gallery_img_fit','logo_display_size','logo_fit','footer_service_links_color','footer_quick_links_color'];
  var mobileKeys = ['show_wa','show_phone','show_trust_bar','show_stats','show_gallery','float_cta','show_wnav'];
  var feedbackKeys = ['reviews_section_title','review_form_title'];

  if (heroKeys.indexOf(key) !== -1) { if(!VE.data.hero_data) VE.data.hero_data={}; VE.data.hero_data[key] = val; }
  else if (aboutKeys.indexOf(key) !== -1) { if(!VE.data.about_data) VE.data.about_data={}; VE.data.about_data[key] = val; }
  else if (footerKeys.indexOf(key) !== -1) { if(!VE.data.footer_data) VE.data.footer_data={}; VE.data.footer_data[key] = val; }
  else if (custKeys.indexOf(key) !== -1) { if(!VE.data.customizer_data) VE.data.customizer_data={}; VE.data.customizer_data[key] = val; }
  else if (mobileKeys.indexOf(key) !== -1) { if(!VE.data.mobile_data) VE.data.mobile_data={}; VE.data.mobile_data[key] = val; }
  else if (feedbackKeys.indexOf(key) !== -1) { if(!VE.data.feedback_data) VE.data.feedback_data={}; VE.data.feedback_data[key] = val; }
  else if (key.startsWith('stat_')) { if(!VE.data.stats_data) VE.data.stats_data={}; VE.data.stats_data[key.replace('stat_','')] = val; }
  else { VE.data[key] = val; }
}
function veRepChange(el) {
  var type = el.dataset.rep, i = parseInt(el.dataset.repI), f = el.dataset.repF;
  var arr = getRepArr(type);
  if (!arr[i]) arr[i] = {};
  arr[i][f] = el.value;
  setRepArr(type, arr);
  veMarkDirty();
  veSchedulePreviewUpdate();
}
function veRepRemove(type, i) {
  var arr = getRepArr(type);
  arr.splice(i, 1);
  setRepArr(type, arr);
  veSection(VE.currentSection); // re-render panel
  veMarkDirty();
  veSchedulePreviewUpdate();
}
function veRepAdd(type) {
  var arr = getRepArr(type);
  arr.push({});
  setRepArr(type, arr);
  veSection(VE.currentSection);
  veMarkDirty();
}
function getRepArr(type) {
  var map = {services:'services_data',products:'products_data',process:'process_data',faq:'faq_data',why:'why_choose_data'};
  var key = map[type] || type+'_data';
  if (!Array.isArray(VE.data[key])) {
    VE.data[key] = Object.values(VE.data[key]||{}).filter(function(v){ return typeof v==='object'; });
  }
  return VE.data[key];
}
function setRepArr(type, arr) {
  var map = {services:'services_data',products:'products_data',process:'process_data',faq:'faq_data',why:'why_choose_data'};
  var key = map[type] || type+'_data';
  VE.data[key] = arr;
}

// ── Image picking ────────────────────────────────────────────────────────────
function vePickImage(key, zoneEl) {
  var input = document.createElement('input');
  input.type = 'file'; input.accept = 'image/*';
  input.onchange = function() {
    if (!input.files[0]) return;
    var fd = new FormData();
    fd.append('action','gs_upload_media');
    fd.append('nonce', VE.nonce);
    fd.append('file', input.files[0]);
    zoneEl.innerHTML = '<div class="ve-upload-placeholder"><span>⏳</span>Uploading…</div>';
    jQuery.ajax({url:GS.ajax_url,type:'POST',data:fd,processData:false,contentType:false,
      success:function(r){
        if (r.success && r.data && r.data.url) {
          veSetField(key, r.data.url);
          // Show clear success preview in sidebar
          zoneEl.innerHTML = '<div style="position:relative;margin-bottom:6px">'
            + '<img src="'+r.data.url+'" style="max-width:100%;max-height:120px;object-fit:contain;display:block;border-radius:6px">'
            + '<div style="position:absolute;top:4px;right:4px;background:#059669;color:#fff;border-radius:3px;padding:1px 7px;font-size:.68rem;font-weight:700">✓ Uploaded</div>'
            + '</div><div class="ve-upload-placeholder" style="font-size:.7rem">Click to change</div>';
          // Update hidden field if present
          var hid = zoneEl.nextElementSibling;
          if (hid && hid.dataset.ve === key) hid.value = r.data.url;
          veMarkDirty();
          // Auto-save to DB then reload iframe so image appears on website immediately
          document.getElementById('ve-save-status').textContent = 'Saving image…';
          veSave(true);
        } else {
          var errMsg = (r.data && r.data.message) ? r.data.message : 'Upload failed';
          zoneEl.innerHTML = '<div class="ve-upload-placeholder"><span>❌</span>'+errMsg+'</div>';
        }
      },
      // Real fix — confirmed silent-hang bug: this jQuery.ajax() call had no
      // error callback, so a network failure, timeout, or server 500 left
      // the upload zone stuck on "⏳ Uploading…" forever with no way to
      // retry short of reloading the whole editor and losing unsaved work.
      error: function() {
        zoneEl.innerHTML = '<div class="ve-upload-placeholder"><span>❌</span>Upload failed — network error. Click to retry.</div>';
      }
    });
  };
  input.click();
}

// ── Style tab binding ─────────────────────────────────────────────────────────
function veBindStyleTab() {
  document.querySelectorAll('#ve-tab-style [data-field]').forEach(function(el){
    el.addEventListener('change', function(){ veSetField(el.dataset.field, el.value); veMarkDirty(); veSchedulePreviewUpdate(); });
    el.addEventListener('input',  function(){ veSetField(el.dataset.field, el.value); veMarkDirty(); veSchedulePreviewUpdate(); });
  });
  document.querySelectorAll('#ve-tab-settings [data-seo]').forEach(function(el){
    el.addEventListener('input',  function(){ VE.data[el.dataset.seo] = el.value; veMarkDirty(); });
    el.addEventListener('change', function(){ VE.data[el.dataset.seo] = el.value; veMarkDirty(); });
  });
  document.querySelectorAll('[data-mobile]').forEach(function(el){
    el.addEventListener('change', function(){
      if (!VE.data.mobile_data) VE.data.mobile_data = {};
      VE.data.mobile_data[el.dataset.mobile] = el.checked ? 1 : 0;
      veMarkDirty(); veSchedulePreviewUpdate();
    });
  });
}
function veBindPanelControls(container) {
  // Range labels
  container.querySelectorAll('[data-ve]').forEach(function(el){
    // already bound via inline oninput/onchange in HTML
  });
}

// ── Live preview update ───────────────────────────────────────────────────────
var veUpdateTimer = null;
function veSchedulePreviewUpdate() {
  clearTimeout(veUpdateTimer);
  veUpdateTimer = setTimeout(function(){
    var frame = document.getElementById('ve-preview-frame');
    try {
      // Try to inject CSS vars without reload (fast path)
      var cd = VE.data.customizer_data || {};
      var css = ':root{';
      if (VE.data.brand_color)  css += '--vs-primary:'+VE.data.brand_color+';';
      if (VE.data.brand_color2) css += '--vs-dark:'+VE.data.brand_color2+';';
      if (VE.data.accent_color) css += '--vs-accent:'+VE.data.accent_color+';';
      css += '}';
      var doc = frame.contentDocument;
      var styleEl = doc.getElementById('ve-live-css');
      if (!styleEl) { styleEl = doc.createElement('style'); styleEl.id='ve-live-css'; doc.head.appendChild(styleEl); }
      styleEl.textContent = css;
    } catch(e) {}
  }, 300);
}
function veLiveUpdate() { veSchedulePreviewUpdate(); }

// ── Device preview ───────────────────────────────────────────────────────────
function veDevice(mode, btn) {
  document.querySelectorAll('.ve-device-btn').forEach(function(b){ b.classList.remove('on'); });
  btn.classList.add('on');
  var wrap = document.getElementById('ve-iframe-wrap');
  var frame = document.getElementById('ve-preview-frame');
  if (mode === 'desktop') { wrap.classList.remove('mobile'); frame.style.width=''; frame.style.height=''; }
  else if (mode === 'tablet') { wrap.classList.add('mobile'); frame.style.width='768px'; frame.style.height='1024px'; }
  else { wrap.classList.add('mobile'); frame.style.width='390px'; frame.style.height='720px'; }
}
function veRefresh() {
  document.getElementById('ve-preview-frame').src = document.getElementById('ve-preview-frame').src;
}

// ── Save ──────────────────────────────────────────────────────────────────────
function veMarkDirty() {
  VE.dirty = true;
  document.getElementById('ve-save-status').textContent = '● Unsaved';
  document.getElementById('ve-save-status').style.color = '#F59E0B';
}
function veSave(silent) {
  var d = VE.data;
  var payload = {
    listing_id:       VE.listingId,
    title:            d.title,
    tagline:          d.tagline,
    short_desc:       d.short_desc,
    full_desc:        d.full_desc,
    brand_color:      d.brand_color,
    brand_color2:     d.brand_color2,
    accent_color:     d.accent_color,
    logo_url:         d.logo_url,
    banner_url:       d.banner_url,
    phone:            d.phone,
    whatsapp:         d.whatsapp,
    email:            d.email,
    city:             d.city,
    address:          d.address,
    trust_bar_text:   d.trust_bar_text,
    gallery_title:    d.gallery_title,
    services_section_title: d.services_section_title,
    services_section_desc:  d.services_section_desc,
    process_section_title:  d.process_section_title,
    seo_title:          d.seo_title,
    seo_desc:           d.seo_desc,
    seo_keywords:       d.seo_keywords       || '',
    seo_focus_keyword:  d.seo_focus_keyword  || '',
    og_image:           d.og_image           || '',
    seo_robots:         d.seo_robots         || 'index,follow',
    slug:             d.slug,
    hero_data:        JSON.stringify(d.hero_data    || {}),
    about_data:       JSON.stringify(d.about_data   || {}),
    footer_data:      JSON.stringify(d.footer_data  || {}),
    feedback_data:    JSON.stringify(d.feedback_data|| {}),
    customizer_data:  JSON.stringify(d.customizer_data||{}),
    mobile_data:      JSON.stringify(d.mobile_data  || {}),
    services_data:    JSON.stringify(Array.isArray(d.services_data) ? d.services_data : []),
    products_data:    JSON.stringify(Array.isArray(d.products_data) ? d.products_data : []),
    process_data:     JSON.stringify(Array.isArray(d.process_data)  ? d.process_data  : []),
    faq_data:         JSON.stringify(Array.isArray(d.faq_data)      ? d.faq_data      : []),
    why_choose_data:  JSON.stringify(Array.isArray(d.why_choose_data)?d.why_choose_data:[]),
    stats_data:       JSON.stringify(d.stats_data   || {}),
    opening_hours:    JSON.stringify(d.opening_hours|| {}),
    gallery:          JSON.stringify(Array.isArray(d.gallery) ? d.gallery : []),
  };
  document.getElementById('ve-save-status').textContent = 'Saving…';
  gsPost('gs_save_listing', payload, function(r){
    VE.dirty = false;
    document.getElementById('ve-save-status').textContent = '✓ Saved';
    document.getElementById('ve-save-status').style.color = '#059669';
    if (!silent) gsToast('Changes saved!','success');
    setTimeout(function(){ document.getElementById('ve-save-status').textContent=''; }, 3000);
    // Always reload iframe after save so all changes (images, text) reflect immediately
    setTimeout(function(){ veRefresh(); }, 500);
  }, function(m){
    document.getElementById('ve-save-status').textContent = '⚠ Save failed: ' + m;
    document.getElementById('ve-save-status').style.color = '#DC2626';
    if (!silent) gsToast(m, 'error');
    console.error('VE save error:', m);
  });
}
document.getElementById('ve-save-btn').addEventListener('click', function(){ veSave(false); });
function veAutoSave() { setInterval(function(){ if(VE.dirty) veSave(true); }, 60000); }

// ── Helpers ──────────────────────────────────────────────────────────────────
function escHtml(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// Keyboard shortcut: Ctrl+S / Cmd+S
document.addEventListener('keydown', function(e){
  if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); veSave(false); }
});

// Warn before leaving with unsaved changes
window.addEventListener('beforeunload', function(e){
  if (VE.dirty) { e.preventDefault(); e.returnValue=''; }
});

// ═══════════════════════════════════════════════════════════════════════════
// ELEMENT INSPECTOR — Yellow Pencil-style click-to-edit
// ═══════════════════════════════════════════════════════════════════════════

var EI = {
  active:      false,
  scope:       'page',            // 'page' | 'global'
  selected:    null,              // { selector, tagName, name, styles }
  pageStyles:  {},                // { selector: { prop: value } }
  globalStyles:{},                // { selector: { prop: value } }
};

// ── Toggle inspector mode ─────────────────────────────────────────────────
function eiToggle() {
  EI.active = !EI.active;
  var btn  = document.getElementById('ei-inspect-btn');
  var icon = document.getElementById('ei-btn-icon');
  var text = document.getElementById('ei-btn-text');
  if (EI.active) {
    btn.classList.add('active');
    icon.textContent = '⏹';
    text.textContent = 'Stop Inspecting';
    eiInjectScript();
  } else {
    btn.classList.remove('active');
    icon.textContent = '🎯';
    text.textContent = 'Start Inspecting';
    eiStopScript();
  }
}

// ── Inject inspector into iframe ──────────────────────────────────────────
function eiInjectScript() {
  var frame = document.getElementById('ve-preview-frame');
  try {
    var doc = frame.contentDocument || frame.contentWindow.document;
    if (doc.getElementById('gsei-script')) return; // already injected
    var s = doc.createElement('script');
    s.id = 'gsei-script';
    s.textContent = '(' + eiIframeScript.toString() + ')()';
    doc.body.appendChild(s);
  } catch(e) { console.warn('GSEI inject failed:', e); }
}

function eiStopScript() {
  var frame = document.getElementById('ve-preview-frame');
  try {
    frame.contentWindow.postMessage({type:'gsei_stop'}, '*');
  } catch(e) {}
}

// ── The script that runs INSIDE the iframe ───────────────────────────────
function eiIframeScript() {
  if (window.__GSEI_RUNNING) return;
  window.__GSEI_RUNNING = true;

  // Highlight overlay
  var box = document.createElement('div');
  box.id = 'gsei-box';
  box.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483646;outline:2px solid #3B82F6;background:rgba(59,130,246,.07);box-sizing:border-box;transition:top .08s,left .08s,width .08s,height .08s';
  document.body.appendChild(box);

  var lbl = document.createElement('div');
  lbl.id = 'gsei-lbl';
  lbl.style.cssText = 'position:fixed;z-index:2147483647;background:#3B82F6;color:#fff;font:700 10px/1 monospace;padding:3px 8px;border-radius:3px;pointer-events:none;white-space:nowrap';
  document.body.appendChild(lbl);

  function getSelector(el) {
    if (!el || el.tagName === 'HTML' || el.tagName === 'BODY') return el ? el.tagName.toLowerCase() : 'body';
    if (el.id) return '#' + el.id;
    var classes = Array.prototype.slice.call(el.classList);
    var gsClass = classes.find(function(c){ return c.indexOf('vs-')===0 || c.indexOf('gs-')===0; });
    if (gsClass) return '.' + gsClass;
    // Path builder (max 4 levels)
    var parts = [];
    var cur = el;
    for (var i=0; i<5 && cur && cur.nodeType===1 && cur.tagName !== 'HTML'; i++) {
      var tag = cur.tagName.toLowerCase();
      if (cur.id) { parts.unshift('#'+cur.id); break; }
      var curClasses = Array.prototype.slice.call(cur.classList);
      var gc = curClasses.find(function(c){ return c.indexOf('vs-')===0 || c.indexOf('gs-')===0; });
      if (gc) { parts.unshift(tag+'.'+gc); break; }
      var sibs = cur.parentElement ? Array.prototype.slice.call(cur.parentElement.children).filter(function(s){ return s.tagName===cur.tagName; }) : [];
      if (sibs.length > 1) tag += ':nth-of-type('+(sibs.indexOf(cur)+1)+')';
      parts.unshift(tag);
      cur = cur.parentElement;
    }
    return parts.join(' > ');
  }

  function pickStyles(el) {
    var cs = window.getComputedStyle(el);
    function px(v){ return v && v !== 'auto' && v !== 'normal' ? v : ''; }
    return {
      color: cs.color, backgroundColor: cs.backgroundColor,
      fontSize: cs.fontSize, fontWeight: cs.fontWeight,
      lineHeight: cs.lineHeight, letterSpacing: px(cs.letterSpacing),
      textAlign: cs.textAlign, textTransform: cs.textTransform,
      paddingTop: cs.paddingTop, paddingRight: cs.paddingRight,
      paddingBottom: cs.paddingBottom, paddingLeft: cs.paddingLeft,
      marginTop: cs.marginTop, marginRight: cs.marginRight,
      marginBottom: cs.marginBottom, marginLeft: cs.marginLeft,
      borderRadius: px(cs.borderRadius), borderWidth: px(cs.borderWidth),
      borderStyle: cs.borderStyle === 'none' ? '' : cs.borderStyle,
      borderColor: cs.borderColor, boxShadow: cs.boxShadow === 'none' ? '' : cs.boxShadow,
      opacity: cs.opacity, width: cs.width, display: cs.display,
    };
  }

  var lastEl = null;
  document.addEventListener('mouseover', function(e) {
    if (!window.__GSEI_RUNNING) return;
    var el = e.target;
    if (el === box || el === lbl) return;
    lastEl = el;
    var r = el.getBoundingClientRect();
    box.style.top=r.top+'px'; box.style.left=r.left+'px';
    box.style.width=r.width+'px'; box.style.height=r.height+'px';
    var name = el.tagName.toLowerCase();
    var cls = Array.prototype.slice.call(el.classList).find(function(c){ return c.indexOf('vs-')===0||c.indexOf('gs-')===0; });
    lbl.textContent = name + (cls ? '.'+cls : '') + ' ' + Math.round(r.width)+'×'+Math.round(r.height);
    lbl.style.top = Math.max(0, r.top-22)+'px';
    lbl.style.left = r.left+'px';
  }, true);

  document.addEventListener('click', function(e) {
    if (!window.__GSEI_RUNNING) return;
    e.preventDefault(); e.stopPropagation();
    var el = e.target;
    if (el === box || el === lbl) return;
    box.style.outline = '2px solid #F59E0B';
    box.style.background = 'rgba(245,158,11,.07)';
    setTimeout(function(){ box.style.outline='2px solid #3B82F6'; box.style.background='rgba(59,130,246,.07)'; }, 600);
    window.parent.postMessage({
      type: 'gsei_pick',
      selector: getSelector(el),
      tagName:  el.tagName.toLowerCase(),
      name:     el.tagName.toLowerCase() + (el.id?'#'+el.id:'') + (el.className?' .'+el.className.trim().split(/\s+/)[0]:''),
      styles:   pickStyles(el),
      text:     (el.innerText||'').replace(/\s+/g,' ').substring(0,40),
    }, '*');
  }, true);

  // Receive CSS injection from parent
  window.addEventListener('message', function(e) {
    if (!e.data) return;
    if (e.data.type === 'gsei_css') {
      var st = document.getElementById('gsei-custom');
      if (!st) { st=document.createElement('style'); st.id='gsei-custom'; document.head.appendChild(st); }
      st.textContent = e.data.css;
    }
    if (e.data.type === 'gsei_stop') {
      window.__GSEI_RUNNING = false;
      if (box.parentNode) box.parentNode.removeChild(box);
      if (lbl.parentNode) lbl.parentNode.removeChild(lbl);
    }
  });
}

// ── Re-inject after iframe reload ─────────────────────────────────────────
document.getElementById('ve-preview-frame').addEventListener('load', function() {
  if (EI.active) {
    setTimeout(eiInjectScript, 300);
  }
  // Always re-apply saved element CSS into fresh iframe
  setTimeout(eiInjectCSS, 400);
});

// ── Receive pick events from iframe ──────────────────────────────────────
window.addEventListener('message', function(e) {
  if (e.data && e.data.type === 'gsei_pick') {
    eiOnPick(e.data);
  }
});

function eiOnPick(data) {
  EI.selected = data;
  // Show properties panel
  document.getElementById('ei-empty').style.display = 'none';
  document.getElementById('ei-props-wrap').style.display = 'flex';
  document.getElementById('ei-props-wrap').style.flexDirection = 'column';
  // Update element info bar
  document.getElementById('ei-el-tag').textContent = '<' + data.tagName + '>';
  var selEl = document.getElementById('ei-el-sel');
  selEl.textContent = data.selector;
  selEl.title = data.selector;
  // Populate fields from computed styles + any existing overrides
  var existing = (EI.scope==='page' ? EI.pageStyles : EI.globalStyles)[data.selector] || {};
  eiPopulateFields(data.styles, existing);
  // Switch to elements tab
  veTab('elements', document.querySelector('[data-tab="elements"]'));
}

// ── Populate property fields ──────────────────────────────────────────────
function eiPopulateFields(cs, overrides) {
  // Typography
  var color = overrides['color'] || rgbaToHex(cs.color) || '';
  setEiColor('color', 'color', color);
  setVal('ei-font-size',       overrides['font-size']       || cs.fontSize || '');
  setOpt('ei-font-weight',     overrides['font-weight']     || cs.fontWeight || '');
  setVal('ei-line-height',     overrides['line-height']      || (cs.lineHeight !== 'normal' ? cs.lineHeight : '') || '');
  setVal('ei-letter-spacing',  overrides['letter-spacing']  || (cs.letterSpacing !== 'normal' ? cs.letterSpacing : '') || '');
  setOpt('ei-text-align',      overrides['text-align']      || cs.textAlign || '');
  setOpt('ei-text-transform',  overrides['text-transform']  || cs.textTransform || '');
  // Background
  var bgColor = overrides['background-color'] || rgbaToHex(cs.backgroundColor) || '';
  setEiColor('bg', 'background-color', bgColor);
  var op = overrides['opacity'] || cs.opacity || '1';
  var opEl = document.getElementById('ei-opacity');
  if(opEl){ opEl.value=op; document.getElementById('ei-opacity-val').textContent=Math.round(parseFloat(op)*100)+'%'; }
  // Spacing
  setVal('ei-pt', overrides['padding-top']    || cs.paddingTop    || '');
  setVal('ei-pr', overrides['padding-right']  || cs.paddingRight  || '');
  setVal('ei-pb', overrides['padding-bottom'] || cs.paddingBottom || '');
  setVal('ei-pl', overrides['padding-left']   || cs.paddingLeft   || '');
  setVal('ei-mt', overrides['margin-top']     || cs.marginTop     || '');
  setVal('ei-mr', overrides['margin-right']   || cs.marginRight   || '');
  setVal('ei-mb', overrides['margin-bottom']  || cs.marginBottom  || '');
  setVal('ei-ml', overrides['margin-left']    || cs.marginLeft    || '');
  // Border
  setVal('ei-border-w',      overrides['border-width']  || cs.borderWidth  || '');
  setOpt('ei-border-style',  overrides['border-style']  || cs.borderStyle  || '');
  var bc = overrides['border-color'] || rgbaToHex(cs.borderColor) || '';
  setEiColor('border', 'border-color', bc);
  var brVal = parseInt(overrides['border-radius'] || cs.borderRadius || 0) || 0;
  var brEl = document.getElementById('ei-border-radius');
  if(brEl){ brEl.value=Math.min(50,brVal); document.getElementById('ei-br-val').textContent=brVal+'px'; }
  // Shadow
  var sh = overrides['box-shadow'] || (cs.boxShadow !== 'none' ? cs.boxShadow : '') || '';
  setVal('ei-box-shadow', sh);
  // Size
  setVal('ei-width',      overrides['width']      || '');
  setVal('ei-max-width',  overrides['max-width']  || '');
  setVal('ei-min-height', overrides['min-height'] || '');
  setOpt('ei-display',    overrides['display']    || '');
  // Custom CSS
  setVal('ei-custom-css', overrides['__custom__'] || '');
  // Update CSS output
  eiUpdateOutput();
}

function setVal(id, v){ var el=document.getElementById(id); if(el) el.value=v||''; }
function setOpt(id, v){
  var el=document.getElementById(id);
  if(!el) return;
  var opt=Array.prototype.slice.call(el.options).find(function(o){ return o.value===v; });
  el.value = opt ? v : '';
}
function setEiColor(type, prop, hex) {
  var sw = document.getElementById('ei-color-'+type);
  var tx = document.getElementById('ei-text-'+type);
  if(sw) sw.value = hex || '#000000';
  if(tx) tx.value = hex || '';
}

// ── Property change handler ───────────────────────────────────────────────
function eiProp(prop, val) {
  if (!EI.selected) return;
  var sel = EI.selected.selector;
  var store = EI.scope==='page' ? EI.pageStyles : EI.globalStyles;
  if (!store[sel]) store[sel] = {};
  if (val !== '' && val !== null && val !== undefined) {
    store[sel][prop] = val;
  } else {
    delete store[sel][prop];
  }
  veMarkDirty();
  eiInjectCSS();
  eiUpdateOutput();
}

function eiCustomCSS(raw) {
  if (!EI.selected) return;
  var sel = EI.selected.selector;
  var store = EI.scope==='page' ? EI.pageStyles : EI.globalStyles;
  if (!store[sel]) store[sel] = {};
  store[sel]['__custom__'] = raw;
  veMarkDirty();
  eiInjectCSS();
  eiUpdateOutput();
}

function eiColorTextChange(prop, input) {
  var v = input.value;
  if (/^#[0-9A-Fa-f]{3,6}$/.test(v)) {
    var sw = input.previousElementSibling;
    if(sw && sw.tagName==='INPUT') sw.value = v;
    eiProp(prop, v);
  }
}

// ── Scope switch ─────────────────────────────────────────────────────────
function eiScope(scope, el) {
  EI.scope = scope;
  document.getElementById('ei-scope-page').classList.toggle('on', scope==='page');
  document.getElementById('ei-scope-global').classList.toggle('on', scope==='global');
  // Re-populate fields for the new scope if element is selected
  if (EI.selected) {
    var existing = (scope==='page' ? EI.pageStyles : EI.globalStyles)[EI.selected.selector] || {};
    eiPopulateFields(EI.selected.styles, existing);
  }
}

// ── Group accordion ──────────────────────────────────────────────────────
function eiGroupToggle(id) {
  var g = document.getElementById('ei-g-'+id);
  if (g) g.classList.toggle('open');
}

// ── Shadow presets ────────────────────────────────────────────────────────
var EI_SHADOWS = {
  none: 'none',
  sm:   '0 1px 4px rgba(0,0,0,.08)',
  md:   '0 4px 16px rgba(0,0,0,.12)',
  lg:   '0 8px 32px rgba(0,0,0,.18)',
  xl:   '0 20px 60px rgba(0,0,0,.25)',
};
function eiShadowPreset(key, btn) {
  document.querySelectorAll('.ei-sh-preset').forEach(function(b){ b.classList.remove('on'); });
  btn.classList.add('on');
  var val = EI_SHADOWS[key] || '';
  setVal('ei-box-shadow', val);
  eiProp('box-shadow', val==='none' ? '' : val);
}

// ── Reset element ─────────────────────────────────────────────────────────
function eiReset() {
  if (!EI.selected) return;
  var sel = EI.selected.selector;
  var store = EI.scope==='page' ? EI.pageStyles : EI.globalStyles;
  delete store[sel];
  eiInjectCSS();
  eiUpdateOutput();
  veMarkDirty();
  // Clear all fields
  eiPopulateFields(EI.selected.styles, {});
  gsToast('Element styles reset', 'success');
}

// ── Build CSS strings ─────────────────────────────────────────────────────
function eiStylesToCSS(store) {
  var css = '';
  Object.keys(store).forEach(function(sel) {
    var props = store[sel];
    var decls = '';
    Object.keys(props).forEach(function(p) {
      if (p === '__custom__') return; // handled below
      if (props[p] && props[p] !== '') decls += p+':'+props[p]+'!important;';
    });
    if (props['__custom__']) decls += props['__custom__'];
    if (decls) css += sel+'{'+decls+'}\n';
  });
  return css;
}

// ── Inject CSS into preview iframe ────────────────────────────────────────
function eiInjectCSS() {
  var pageCss   = eiStylesToCSS(EI.pageStyles);
  var globalCss = eiStylesToCSS(EI.globalStyles);
  var fullCss   = '/* GS Element Inspector — Page */\n' + pageCss + '\n/* GS Element Inspector — Global */\n' + globalCss;
  var frame = document.getElementById('ve-preview-frame');
  try {
    frame.contentWindow.postMessage({type:'gsei_css', css: fullCss}, '*');
  } catch(e) {}
  // Also sync to VE.data for saving
  if (!VE.data.customizer_data) VE.data.customizer_data = {};
  VE.data.customizer_data.element_css = pageCss;
  VE.data.global_element_css = globalCss;
}

// ── Update CSS output panel ───────────────────────────────────────────────
function eiUpdateOutput() {
  if (!EI.selected) return;
  var sel = EI.selected.selector;
  var store = EI.scope==='page' ? EI.pageStyles : EI.globalStyles;
  var props = store[sel] || {};
  var css = sel + ' {\n';
  Object.keys(props).forEach(function(p) {
    if (p === '__custom__' || !props[p]) return;
    css += '  ' + p + ': ' + props[p] + ';\n';
  });
  if (props['__custom__']) css += '  /* custom */\n  ' + props['__custom__'] + '\n';
  css += '}';
  var out = document.getElementById('ei-css-output');
  if (out) out.textContent = css;
}

// ── Copy CSS ──────────────────────────────────────────────────────────────
function eiCopyCSS() {
  var out = document.getElementById('ei-css-output');
  if (!out) return;
  navigator.clipboard.writeText(out.textContent).then(function(){
    gsToast('CSS copied!', 'success');
  }).catch(function(){});
}

// ── rgba → hex helper ─────────────────────────────────────────────────────
function rgbaToHex(rgba) {
  if (!rgba || rgba === 'transparent' || rgba === 'rgba(0, 0, 0, 0)') return '';
  var m = rgba.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
  if (!m) return rgba.indexOf('#')===0 ? rgba : '';
  return '#' + [m[1],m[2],m[3]].map(function(x){
    return ('0'+parseInt(x).toString(16)).slice(-2);
  }).join('');
}

// ── Load existing element CSS on init ────────────────────────────────────
(function eiInit(){
  // Parse existing page element_css from VE.data.customizer_data
  var cd = VE.data.customizer_data || {};
  // We store CSS as string; can't trivially parse back but we can replay it as-is
  // Store the raw string so saving round-trips it
  if (cd.element_css) {
    EI._savedPageCSS = cd.element_css;
  }
  if (VE.data.global_element_css) {
    EI._savedGlobalCSS = VE.data.global_element_css;
  }
})();

// ── Patch veSave to include element CSS ──────────────────────────────────
var _origVeSave = veSave;
veSave = function(silent) {
  // Sync element CSS into customizer_data before save
  var pageCss = eiStylesToCSS(EI.pageStyles) || (EI._savedPageCSS||'');
  if (!VE.data.customizer_data) VE.data.customizer_data = {};
  VE.data.customizer_data.element_css = pageCss;
  // Save global CSS via separate call
  var globalCss = eiStylesToCSS(EI.globalStyles) || (EI._savedGlobalCSS||'');
  if (globalCss) {
    jQuery.post(GS.ajax_url, {
      action: 'gs_save_global_element_css',
      nonce:  VE.nonce,
      css:    globalCss,
    });
  }
  _origVeSave(silent);
};

</script>
</body>
</html>
<?php
