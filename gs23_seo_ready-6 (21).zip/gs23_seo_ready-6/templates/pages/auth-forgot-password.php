<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( is_user_logged_in() ) {
    wp_redirect( function_exists('gs_login_redirect') ? gs_login_redirect() : home_url('/vendor/dashboard/') );
    exit;
}
$platform = gs_setting('platform_name', 'GoodService');
$color    = gs_setting('platform_color_primary', '#2563EB');
$logo_url = gs_setting('logo_url', '');
$ajax_url = admin_url('admin-ajax.php');
$nonce    = wp_create_nonce('gs_ajax');

// Handle URL error messages
$url_error = sanitize_text_field( $_GET['error'] ?? '' );
$url_sent  = sanitize_text_field( $_GET['sent']  ?? '' );
?>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:linear-gradient(135deg,#F0F9FF,#EFF6FF);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.gsfp-wrap{width:100%;max-width:420px}
.gsfp-logo{text-align:center;margin-bottom:28px}
.gsfp-logo img{height:50px;margin:0 auto 12px;display:block;border-radius:8px}
.gsfp-logo h1{font-size:1.4rem;font-weight:800;color:#1E3A5F;margin:0}
.gsfp-logo p{color:#64748B;margin:5px 0 0;font-size:.85rem}
.gsfp-card{background:#fff;border-radius:18px;box-shadow:0 10px 40px rgba(0,0,0,.1);padding:36px 32px}
.gsfp-icon{width:64px;height:64px;border-radius:16px;background:#EFF6FF;display:flex;align-items:center;justify-content:center;font-size:1.8rem;margin:0 auto 20px}
.gsfp-title{font-size:1.2rem;font-weight:700;color:#1E3A5F;text-align:center;margin-bottom:8px}
.gsfp-sub{font-size:.85rem;color:#64748B;text-align:center;margin-bottom:24px;line-height:1.6}
.gsfp-err,.gsfp-ok{display:none;padding:12px 14px;border-radius:8px;font-size:.84rem;margin-bottom:16px;border-left:4px solid}
.gsfp-err{background:#FEF2F2;color:#DC2626;border-color:#DC2626}
.gsfp-ok{background:#F0FDF4;color:#059669;border-color:#059669}
.gsfp-label{display:block;font-size:.8rem;font-weight:600;color:#475569;margin-bottom:6px}
.gsfp-field{margin-bottom:18px}
.gsfp-input{display:block;width:100%;padding:12px 14px;border:1.5px solid #E2E8F0;border-radius:9px;font-size:.92rem;color:#1E293B;background:#fff;outline:none;transition:border-color .18s,box-shadow .18s;font-family:inherit}
.gsfp-input:focus{border-color:<?php echo esc_attr($color); ?>;box-shadow:0 0 0 3px <?php echo esc_attr($color); ?>22}
.gsfp-btn{display:block;width:100%;padding:13px;border:none;border-radius:10px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;transition:all .18s;text-align:center;background:<?php echo esc_attr($color); ?>;color:#fff}
.gsfp-btn:hover{filter:brightness(1.08)}
.gsfp-btn:disabled{opacity:.6;cursor:not-allowed}
.gsfp-links{text-align:center;margin-top:20px;font-size:.82rem}
.gsfp-links a{color:#64748B;text-decoration:none;margin:0 8px}
.gsfp-links a:hover{color:<?php echo esc_attr($color); ?>}
.gsfp-back{text-align:center;margin-top:20px;font-size:.82rem}
.gsfp-back a{color:#64748B;text-decoration:none}
.gsfp-back a:hover{color:<?php echo esc_attr($color); ?>}
</style>

<div class="gsfp-wrap">
  <div class="gsfp-logo">
    <?php if($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($platform); ?>"><?php endif; ?>
    <h1><?php echo esc_html($platform); ?></h1>
    <p>Password Recovery</p>
  </div>

  <div class="gsfp-card">
    <div class="gsfp-icon">🔑</div>
    <div class="gsfp-title">Forgot your password?</div>
    <div class="gsfp-sub">Enter your email address or username below and we'll send you a link to reset your password.</div>

    <?php if($url_error === 'invalid_link'): ?>
    <div class="gsfp-err" style="display:block">This password reset link is invalid or has expired. Please request a new one.</div>
    <?php endif; ?>
    <?php if($url_sent): ?>
    <div class="gsfp-ok" style="display:block">✓ Reset link sent! Please check your email inbox and spam folder.</div>
    <?php endif; ?>

    <div id="fp-err" class="gsfp-err"></div>
    <div id="fp-ok"  class="gsfp-ok"></div>

    <div class="gsfp-field">
      <label class="gsfp-label" for="fp-login">Email Address or Username</label>
      <input type="text" id="fp-login" class="gsfp-input"
        placeholder="your@email.com or username"
        autocomplete="username" autocapitalize="none" spellcheck="false">
    </div>

    <button class="gsfp-btn" id="fp-btn" onclick="fpSubmit()">Send Reset Link</button>

    <div class="gsfp-links">
      <a href="<?php echo esc_url(home_url('/vendor/login/')); ?>">← Back to Login</a>
      <a href="<?php echo esc_url(home_url('/vendor/register/')); ?>">Create Account</a>
    </div>
  </div>

  <div class="gsfp-back"><a href="<?php echo esc_url(home_url('/')); ?>">← Back to <?php echo esc_html($platform); ?></a></div>
</div>

<script>
var GS_AJAX  = '<?php echo esc_js($ajax_url); ?>';
var GS_NONCE = '<?php echo esc_js($nonce); ?>';

function fpSubmit() {
  document.getElementById('fp-err').style.display = 'none';
  document.getElementById('fp-ok').style.display  = 'none';

  var login = document.getElementById('fp-login').value.trim();
  if (!login) {
    document.getElementById('fp-err').textContent = 'Please enter your email address or username.';
    document.getElementById('fp-err').style.display = 'block';
    return;
  }

  var btn = document.getElementById('fp-btn');
  btn.disabled = true; btn.textContent = 'Sending…';

  var fd = new FormData();
  fd.append('action', 'gs_forgot_password');
  fd.append('nonce',  GS_NONCE);
  fd.append('login',  login);

  fetch(GS_AJAX, { method:'POST', body:fd, credentials:'same-origin' })
    .then(function(r){ return r.json(); })
    .then(function(r){
      btn.disabled = false; btn.textContent = 'Send Reset Link';
      if (r.success) {
        var ok = document.getElementById('fp-ok');
        ok.textContent = r.data && r.data.message ? r.data.message : '✓ If an account was found, a reset link has been emailed to you.';
        ok.style.display = 'block';
        document.getElementById('fp-login').value = '';
      } else {
        var err = document.getElementById('fp-err');
        err.textContent = (r.data && r.data.message) ? r.data.message : 'Something went wrong. Please try again.';
        err.style.display = 'block';
      }
    })
    .catch(function(){
      btn.disabled = false; btn.textContent = 'Send Reset Link';
      document.getElementById('fp-err').textContent = 'Connection error. Please try again.';
      document.getElementById('fp-err').style.display = 'block';
    });
}

document.getElementById('fp-login').addEventListener('keydown', function(e){ if(e.key==='Enter') fpSubmit(); });
</script>
