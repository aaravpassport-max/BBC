<?php
/**
 * GoodService — RWA / Society Admin Dashboard (Moat 3)
 * Accessible at /rwa/dashboard/ for users with gs_rwa_admin role.
 * Allows RWA secretaries to: manage approved vendors, track common area assets,
 * view member list, and share the society access code with residents.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! is_user_logged_in() ) {
    wp_safe_redirect( wp_login_url( home_url( '/rwa/dashboard/' ) ) );
    exit;
}

$user_id  = get_current_user_id();
$user     = wp_get_current_user();
global $wpdb;

// Check tables exist
$has_table = $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_societies'" );
if ( ! $has_table ) {
    get_header();
    echo '<div style="max-width:600px;margin:60px auto;text-align:center;padding:24px">
        <div style="font-size:2rem;margin-bottom:12px">⚠️</div>
        <h2 style="color:#92400E">RWA Portal not yet activated</h2>
        <p style="color:#64748B">Please ask the admin to run DB Upgrade to activate this feature.</p>
    </div>';
    get_footer();
    exit;
}

// Get society for this user
$society = \GoodService\Service\RwaService::get_user_society( $user_id );
$is_admin = $society && (int)$society->admin_user_id === $user_id;
$nonce    = wp_create_nonce( 'gs_ajax' );
$section  = sanitize_key( $_GET['section'] ?? 'overview' );

if ( ! $society && ! isset( $_POST['create_society'] ) ) {
    // Show join/create form
    get_header();
    ?>
    <div style="max-width:500px;margin:60px auto;padding:24px">
      <h1 style="font-size:1.4rem;font-weight:700;color:#1E293B;margin-bottom:20px">🏢 RWA Society Portal</h1>

      <!-- Join existing society -->
      <div style="background:#fff;border:1px solid #E2E8F0;border-radius:12px;padding:20px;margin-bottom:16px">
        <h2 style="font-size:1rem;font-weight:700;margin-bottom:12px">Join Your Society</h2>
        <p style="font-size:.83rem;color:#64748B;margin-bottom:12px">Enter the access code given by your RWA secretary.</p>
        <input id="rwa-code" type="text" class="gs-input" placeholder="e.g. SUNR4821" style="text-transform:uppercase;letter-spacing:.1em">
        <input id="rwa-flat" type="text" class="gs-input" placeholder="Your flat number (e.g. B-204)" style="margin-top:8px">
        <button onclick="rwaJoin()" class="gs-btn gs-btn-primary" style="margin-top:12px;width:100%">Join Society</button>
        <div id="rwa-join-msg" style="display:none;margin-top:8px;font-size:.82rem"></div>
      </div>

      <!-- Create new society -->
      <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;padding:20px">
        <h2 style="font-size:1rem;font-weight:700;margin-bottom:4px">Register Your Society</h2>
        <p style="font-size:.83rem;color:#64748B;margin-bottom:12px">Are you an RWA secretary? Register your society and get an access code for residents.</p>
        <input id="rwa-name" type="text" class="gs-input" placeholder="Society name e.g. Sunrise Apartments">
        <input id="rwa-address" type="text" class="gs-input" placeholder="Address" style="margin-top:8px">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">
          <input id="rwa-pincode" type="text" class="gs-input" placeholder="Pincode" maxlength="6">
          <input id="rwa-units" type="number" class="gs-input" placeholder="Total units">
        </div>
        <button onclick="rwaCreate()" class="gs-btn gs-btn-ghost" style="margin-top:12px;width:100%">Register as RWA Admin</button>
        <div id="rwa-create-msg" style="display:none;margin-top:8px;font-size:.82rem"></div>
      </div>
    </div>
    <script>
    function rwaJoin(){
      var code=document.getElementById('rwa-code').value.trim();
      if(!code){alert('Enter access code.');return;}
      var fd=new FormData();fd.append('action','gs_join_society');fd.append('nonce','<?php echo esc_js($nonce);?>');
      fd.append('access_code',code);fd.append('flat_number',document.getElementById('rwa-flat').value);
      fetch('<?php echo esc_js(admin_url("admin-ajax.php"));?>',{method:'POST',credentials:'same-origin',body:fd})
        .then(function(r){return r.json();})
        .then(function(j){
          var el=document.getElementById('rwa-join-msg');el.style.display='block';
          if(j.success){el.style.color='#059669';el.textContent='Joined! Refreshing…';setTimeout(function(){location.reload();},1200);}
          else{el.style.color='#DC2626';el.textContent=(j.data&&j.data.message)||'Failed.';}
        })
        // Real fix — a network error previously gave no feedback at all.
        .catch(function(){
          var el=document.getElementById('rwa-join-msg');el.style.display='block';el.style.color='#DC2626';
          el.textContent='Network error — could not reach the server. Please try again.';
        });
    }
    function rwaCreate(){
      var name=document.getElementById('rwa-name').value.trim();
      if(!name){alert('Enter society name.');return;}
      var fd=new FormData();fd.append('action','gs_create_society');fd.append('nonce','<?php echo esc_js($nonce);?>');
      fd.append('name',name);fd.append('address',document.getElementById('rwa-address').value);
      fd.append('pincode',document.getElementById('rwa-pincode').value);
      fd.append('total_units',document.getElementById('rwa-units').value||0);
      fetch('<?php echo esc_js(admin_url("admin-ajax.php"));?>',{method:'POST',credentials:'same-origin',body:fd})
        .then(function(r){return r.json();})
        .then(function(j){
          var el=document.getElementById('rwa-create-msg');el.style.display='block';
          if(j.success){el.style.color='#059669';el.textContent='Society created! Refreshing…';setTimeout(function(){location.reload();},1200);}
          else{el.style.color='#DC2626';el.textContent=(j.data&&j.data.message)||'Failed.';}
        })
        // Real fix — a network error previously gave no feedback at all.
        .catch(function(){
          var el=document.getElementById('rwa-create-msg');el.style.display='block';el.style.color='#DC2626';
          el.textContent='Network error — could not reach the server. Please try again.';
        });
    }
    </script>
    <?php
    get_footer();
    exit;
}

// Load society data
$members  = $wpdb->get_results( $wpdb->prepare(
    "SELECT sm.*, u.display_name, u.user_email
     FROM {$wpdb->prefix}gs_society_members sm
     LEFT JOIN {$wpdb->users} u ON u.ID = sm.user_id
     WHERE sm.society_id = %d ORDER BY sm.role DESC, sm.joined_at ASC",
    $society->id
) ) ?: [];

$vendors = \GoodService\Service\RwaService::get_society_vendors( (int)$society->id );

get_header();
?>
<style>
.rwa-wrap{max-width:1000px;margin:0 auto;padding:24px 16px}
.rwa-hd{background:linear-gradient(135deg,#1E3A5F,#2563EB);color:#fff;border-radius:14px;padding:24px;margin-bottom:20px}
.rwa-nav{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap}
.rwa-nav a{padding:8px 16px;border-radius:7px;text-decoration:none;font-size:.83rem;font-weight:600;color:#334155;background:#F1F5F9;border:1px solid #E2E8F0}
.rwa-nav a.on{background:#2563EB;color:#fff;border-color:#2563EB}
.rwa-card{background:#fff;border:1px solid #E2E8F0;border-radius:12px;padding:20px;margin-bottom:16px;box-shadow:0 2px 6px rgba(0,0,0,.04)}
.rwa-card-title{font-weight:700;font-size:.93rem;color:#1E293B;margin-bottom:14px}
</style>

<div class="rwa-wrap">
  <!-- Header -->
  <div class="rwa-hd">
    <div style="font-size:.8rem;opacity:.7;margin-bottom:4px">RWA Admin Dashboard</div>
    <div style="font-size:1.3rem;font-weight:700">🏢 <?php echo esc_html($society->name); ?></div>
    <div style="display:flex;gap:16px;margin-top:10px;flex-wrap:wrap;font-size:.8rem;opacity:.85">
      <span>📍 <?php echo esc_html($society->address); ?></span>
      <span>🏠 <?php echo $society->total_units; ?> units</span>
      <span>👥 <?php echo count($members); ?> members</span>
    </div>
    <?php if($is_admin): ?>
    <div style="margin-top:12px;background:rgba(255,255,255,.15);border-radius:8px;padding:10px 14px;display:inline-flex;align-items:center;gap:10px">
      <span style="font-size:.78rem">🔑 Access Code:</span>
      <strong style="font-size:1.1rem;letter-spacing:.15em"><?php echo esc_html($society->access_code); ?></strong>
      <span style="font-size:.72rem;opacity:.75">Share with residents to join</span>
    </div>
    <?php endif; ?>
  </div>

  <!-- Nav -->
  <div class="rwa-nav">
    <a href="?section=overview" class="<?php echo $section==='overview'?'on':''; ?>">📊 Overview</a>
    <a href="?section=vendors"  class="<?php echo $section==='vendors'?'on':''; ?>">🏪 Approved Vendors</a>
    <a href="?section=members"  class="<?php echo $section==='members'?'on':''; ?>">👥 Members</a>
    <?php // ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "No bulk-invite/
          // CSV import of RWA residents — one-at-a-time self-service via
          // access code only"). Admin-only, same as the access-code panel. ?>
    <?php if($is_admin): ?><a href="?section=invites" class="<?php echo $section==='invites'?'on':''; ?>">✉️ Invites</a><?php endif; ?>
  </div>

  <?php if($section === 'overview'): ?>

  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px">
    <?php foreach([
      ['Members',count($members),'👥','#EFF6FF','#2563EB'],
      ['Approved Vendors',count($vendors),'🏪','#F0FDF4','#059669'],
      ['Total Units',$society->total_units,'🏠','#FFFBEB','#D97706'],
    ] as [$lbl,$val,$ic,$bg,$cl]): ?>
    <div class="rwa-card" style="text-align:center;padding:16px;background:<?php echo $bg;?>">
      <div style="font-size:1.5rem"><?php echo $ic;?></div>
      <div style="font-size:1.4rem;font-weight:700;color:<?php echo $cl;?>"><?php echo $val;?></div>
      <div style="font-size:.75rem;color:#64748B"><?php echo $lbl;?></div>
    </div>
    <?php endforeach;?>
  </div>

  <div class="rwa-card">
    <div class="rwa-card-title">ℹ️ About <?php echo esc_html($society->name); ?></div>
    <table style="font-size:.83rem;width:100%;border-collapse:collapse">
      <tr><td style="color:#64748B;padding:5px 0;width:140px">Society Type</td><td><?php echo ucfirst($society->type??'apartment'); ?></td></tr>
      <tr><td style="color:#64748B;padding:5px 0">Address</td><td><?php echo esc_html($society->address); ?></td></tr>
      <tr><td style="color:#64748B;padding:5px 0">Pincode</td><td><?php echo esc_html($society->pincode); ?></td></tr>
      <tr><td style="color:#64748B;padding:5px 0">Total Units</td><td><?php echo $society->total_units; ?></td></tr>
      <tr><td style="color:#64748B;padding:5px 0">Verified</td><td><?php echo $society->is_verified ? '✅ Yes' : '⏳ Pending'; ?></td></tr>
    </table>
  </div>

  <?php
  // ENTERPRISE-AUDIT FIX (Part 4 §4, Medium: "RWA Overview tab has no
  // recent-activity feed"). See RwaService::get_recent_activity() —
  // merges real member-join/vendor-approval/admin-action history, not a
  // fabricated log.
  $rwa_activity = \GoodService\Service\RwaService::get_recent_activity( (int)$society->id, 15 );
  ?>
  <div class="rwa-card">
    <div class="rwa-card-title">🕒 Recent Activity</div>
    <?php if ($rwa_activity): ?>
    <div style="display:flex;flex-direction:column;gap:10px">
      <?php foreach ($rwa_activity as $ev): ?>
      <div style="display:flex;gap:10px;align-items:flex-start;font-size:.83rem;border-bottom:1px solid #F1F5F9;padding-bottom:8px">
        <span style="font-size:1rem"><?php echo $ev['icon']; ?></span>
        <div style="flex:1">
          <div style="color:#1E293B"><?php echo esc_html($ev['text']); ?></div>
          <div style="color:#94A3B8;font-size:.72rem;margin-top:2px"><?php echo esc_html( human_time_diff( strtotime($ev['ts']), current_time('timestamp') ) . ' ago' ); ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div style="color:#94A3B8;font-size:.83rem;text-align:center;padding:16px">No activity yet.</div>
    <?php endif; ?>
  </div>

  <?php elseif($section === 'vendors'): ?>

  <!-- Approved vendors list -->
  <div class="rwa-card" style="margin-bottom:16px">
    <div class="rwa-card-title">✅ Society Approved Vendors</div>
    <?php if(empty($vendors)): ?>
    <p style="color:#94A3B8;font-size:.83rem;text-align:center;padding:16px">No vendors approved yet. Browse the directory and approve vendors for your society.</p>
    <a href="<?php echo esc_url(home_url('/directory/')); ?>" class="gs-btn gs-btn-primary" style="text-decoration:none;display:inline-block">Browse Directory →</a>
    <?php else: ?>
    <?php foreach($vendors as $v):
      $tier_colors=['preferred'=>'#D97706','approved'=>'#059669','emergency'=>'#DC2626'];
      $tc=$tier_colors[$v->tier??'approved']??'#64748B';
    ?>
    <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid #F1F5F9">
      <?php if($v->cover_photo): ?><img src="<?php echo esc_url($v->cover_photo);?>" style="width:44px;height:44px;border-radius:8px;object-fit:cover"><?php endif;?>
      <div style="flex:1">
        <div style="font-weight:600;font-size:.88rem"><?php echo esc_html($v->title); ?></div>
        <div style="font-size:.75rem;color:#64748B"><?php echo esc_html($v->business_name??''); ?><?php if($v->avg_rating>0): ?> · ★<?php echo number_format($v->avg_rating,1);?><?php endif;?></div>
        <?php if($v->notes): ?><div style="font-size:.72rem;color:#94A3B8;margin-top:2px"><?php echo esc_html($v->notes); ?></div><?php endif;?>
        <?php if($v->negotiated_rate): ?><div style="font-size:.72rem;color:#059669;margin-top:2px">Negotiated rate: ₹<?php echo number_format($v->negotiated_rate);?></div><?php endif;?>
      </div>
      <span style="background:<?php echo $tc;?>20;color:<?php echo $tc;?>;border-radius:20px;padding:2px 10px;font-size:.7rem;font-weight:700"><?php echo ucfirst($v->tier??'approved');?></span>
    </div>
    <?php endforeach;?>
    <?php endif;?>
  </div>

  <?php if($is_admin): ?>
  <!-- Approve a new vendor -->
  <div class="rwa-card">
    <div class="rwa-card-title">➕ Approve a Vendor</div>
    <?php
    // FIXED — audit gap "RWA vendor-approval search UI": this previously
    // required the admin to already know a listing's raw numeric ID — the
    // one piece of information nobody browsing the directory ever sees.
    // Now a real live search against the same public gs_search_listings
    // action the directory page itself uses, so the admin can find a
    // vendor by name the way they'd actually recognize one.
    ?>
    <p style="font-size:.82rem;color:#64748B;margin-bottom:12px">Search for a vendor by business name to add them as approved for your society.</p>
    <div style="position:relative;margin-bottom:10px">
      <input id="rwa-vendor-search" type="text" class="gs-input" placeholder="Start typing a business name…" autocomplete="off" style="width:100%;box-sizing:border-box">
      <div id="rwa-vendor-results" style="display:none;position:absolute;top:100%;left:0;right:0;background:#fff;border:1px solid #E2E8F0;border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.1);max-height:260px;overflow-y:auto;z-index:20;margin-top:4px"></div>
    </div>
    <div id="rwa-selected-vendor" style="display:none;background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;padding:10px 12px;margin-bottom:10px;font-size:.83rem;display:flex;align-items:center;justify-content:space-between">
      <span>✅ Selected: <strong id="rwa-selected-vendor-name"></strong></span>
      <a href="#" onclick="rwaClearSelection();return false;" style="color:#DC2626;font-size:.78rem">Change</a>
    </div>
    <div style="display:flex;gap:10px">
      <select id="rwa-tier" class="gs-select" style="flex-shrink:0">
        <option value="approved">Approved</option>
        <option value="preferred">Preferred</option>
        <option value="emergency">Emergency</option>
      </select>
      <input id="rwa-vendor-notes" type="text" class="gs-input" placeholder="Notes (optional)">
      <button onclick="rwaApprove()" id="rwa-approve-btn" class="gs-btn gs-btn-primary" style="flex-shrink:0" disabled>Approve</button>
    </div>
    <div id="rwa-approve-msg" style="display:none;margin-top:8px;font-size:.82rem"></div>
  </div>
  <script>
  (function(){
    var selectedListingId = 0;
    var searchTimer = null;
    var searchInput = document.getElementById('rwa-vendor-search');
    var resultsBox  = document.getElementById('rwa-vendor-results');
    var approveBtn  = document.getElementById('rwa-approve-btn');

    window.rwaClearSelection = function(){
      selectedListingId = 0;
      document.getElementById('rwa-selected-vendor').style.display = 'none';
      searchInput.value = '';
      searchInput.style.display = '';
      approveBtn.disabled = true;
    };

    searchInput.addEventListener('input', function(){
      var q = searchInput.value.trim();
      clearTimeout(searchTimer);
      if (q.length < 2) { resultsBox.style.display = 'none'; resultsBox.innerHTML = ''; return; }
      searchTimer = setTimeout(function(){
        var fd = new FormData();
        fd.append('action','gs_search_listings');
        fd.append('keyword', q);
        fd.append('per_page', 8);
        fetch('<?php echo esc_js(admin_url("admin-ajax.php"));?>',{method:'POST',credentials:'same-origin',body:fd})
          .then(function(r){return r.json();})
          .then(function(j){
            var listings = (j.success && j.data && j.data.listings) ? j.data.listings : [];
            if (!listings.length) {
              resultsBox.innerHTML = '<div style="padding:12px;font-size:.82rem;color:#94A3B8">No matching listings found.</div>';
              resultsBox.style.display = 'block';
              return;
            }
            var html = '';
            listings.forEach(function(l){
              var title = (l.title || 'Untitled').replace(/</g,'&lt;');
              var city  = (l.city || '').replace(/</g,'&lt;');
              html += '<div class="rwa-vendor-result" data-id="'+l.id+'" data-title="'+title+'" '
                + 'style="padding:10px 12px;cursor:pointer;border-bottom:1px solid #F1F5F9;font-size:.85rem" '
                + 'onmouseover="this.style.background=\'#F8FAFC\'" onmouseout="this.style.background=\'#fff\'">'
                + '<strong>'+title+'</strong>'+(city?' <span style="color:#94A3B8;font-size:.76rem">· '+city+'</span>':'')+'</div>';
            });
            resultsBox.innerHTML = html;
            resultsBox.style.display = 'block';
          })
          .catch(function(){
            resultsBox.innerHTML = '<div style="padding:12px;font-size:.82rem;color:#DC2626">Search failed — network error.</div>';
            resultsBox.style.display = 'block';
          });
      }, 300);
    });

    resultsBox.addEventListener('click', function(e){
      var row = e.target.closest('.rwa-vendor-result');
      if (!row) return;
      selectedListingId = parseInt(row.getAttribute('data-id'), 10) || 0;
      document.getElementById('rwa-selected-vendor-name').textContent = row.getAttribute('data-title');
      document.getElementById('rwa-selected-vendor').style.display = 'flex';
      searchInput.style.display = 'none';
      resultsBox.style.display = 'none';
      resultsBox.innerHTML = '';
      approveBtn.disabled = !selectedListingId;
    });

    document.addEventListener('click', function(e){
      if (!resultsBox.contains(e.target) && e.target !== searchInput) { resultsBox.style.display = 'none'; }
    });

    window.rwaApprove = function(){
      if (!selectedListingId) { alert('Please search for and select a vendor first.'); return; }
      var fd=new FormData();
      fd.append('action','gs_approve_society_vendor');fd.append('nonce','<?php echo esc_js($nonce);?>');
      fd.append('society_id',<?php echo (int)$society->id;?>);
      fd.append('listing_id',selectedListingId);fd.append('vendor_id',0); // server resolves
      fd.append('tier',document.getElementById('rwa-tier').value);
      fd.append('notes',document.getElementById('rwa-vendor-notes').value);
      fetch('<?php echo esc_js(admin_url("admin-ajax.php"));?>',{method:'POST',credentials:'same-origin',body:fd})
        .then(function(r){return r.json();}). then(function(j){
          var el=document.getElementById('rwa-approve-msg');el.style.display='block';
          if(j.success){el.style.color='#059669';el.textContent='Vendor approved! Refreshing…';setTimeout(function(){location.reload();},1000);}
          else{el.style.color='#DC2626';el.textContent=(j.data&&j.data.message)||'Failed. Please try a different listing.';}
        })
        // Real fix — a network error previously gave no feedback at all.
        .catch(function(){
          var el=document.getElementById('rwa-approve-msg');el.style.display='block';el.style.color='#DC2626';
          el.textContent='Network error — could not reach the server. Please try again.';
        });
    };
  })();
  </script>
  <?php endif;?>

  <?php elseif($section === 'members'): ?>

  <div class="rwa-card">
    <div class="rwa-card-title">👥 Society Members (<?php echo count($members); ?>)</div>
    <?php if(empty($members)): ?>
    <p style="color:#94A3B8;font-size:.83rem;text-align:center;padding:16px">No members yet. Share the access code to invite residents.</p>
    <?php else: ?>
    <table class="gs-tbl">
      <thead><tr><th>Name</th><th>Flat</th><th>Role</th><th>Joined</th><?php if($is_admin): ?><th>Actions</th><?php endif; ?></tr></thead>
      <tbody>
      <?php foreach($members as $m):
        $_m_uid = (int) $m->user_id;
        $_is_this_member_admin = $_m_uid === (int) $society->admin_user_id;
      ?>
      <tr id="rwa-member-row-<?php echo $_m_uid; ?>">
        <td style="font-weight:600"><?php echo esc_html($m->display_name??'Resident'); ?></td>
        <td><?php echo esc_html($m->flat_number??'—'); ?></td>
        <td><span style="background:#EFF6FF;color:#1D4ED8;border-radius:4px;padding:2px 7px;font-size:.72rem;font-weight:600"><?php echo ucfirst($m->role); ?></span></td>
        <td style="font-size:.75rem;color:#94A3B8"><?php echo human_time_diff(strtotime($m->joined_at)); ?> ago</td>
        <?php
        // FIXED — audit gap "RWA dashboard: no member removal or role
        // transfer". Only the society's own admin sees these controls, and
        // the admin's own row never gets a "Remove" button — they must
        // transfer the role away first (enforced server-side too, in
        // RwaService::remove_member()), so a society can never be left
        // without an admin.
        if($is_admin): ?>
        <td style="white-space:nowrap">
          <?php if($_is_this_member_admin): ?>
          <span style="font-size:.72rem;color:#94A3B8">— you (admin) —</span>
          <?php else: ?>
          <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="rwaTransferAdmin(<?php echo $_m_uid; ?>,'<?php echo esc_js($m->display_name??'this resident'); ?>')">Make Admin</button>
          <button class="gs-btn gs-btn-ghost gs-btn-sm" style="color:#DC2626" onclick="rwaRemoveMember(<?php echo $_m_uid; ?>,'<?php echo esc_js($m->display_name??'this resident'); ?>')">Remove</button>
          <?php endif; ?>
        </td>
        <?php endif; ?>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <div id="rwa-member-msg" style="display:none;margin-top:10px;font-size:.82rem"></div>
    <?php endif; ?>
  </div>

  <?php if($is_admin): ?>
  <script>
  function rwaRemoveMember(userId,name){
    if(!confirm('Remove '+name+' from the society? They will need the access code to rejoin.')){return;}
    var fd=new FormData();
    fd.append('action','gs_remove_society_member');fd.append('nonce','<?php echo esc_js($nonce);?>');
    fd.append('society_id',<?php echo (int)$society->id;?>);fd.append('member_user_id',userId);
    fetch('<?php echo esc_js(admin_url("admin-ajax.php"));?>',{method:'POST',credentials:'same-origin',body:fd})
      .then(function(r){return r.json();}).then(function(j){
        var el=document.getElementById('rwa-member-msg');el.style.display='block';
        if(j.success){el.style.color='#059669';el.textContent='Member removed. Refreshing…';setTimeout(function(){location.reload();},900);}
        else{el.style.color='#DC2626';el.textContent=(j.data&&j.data.message)||'Failed.';}
      })
      .catch(function(){
        var el=document.getElementById('rwa-member-msg');el.style.display='block';el.style.color='#DC2626';
        el.textContent='Network error — could not reach the server. Please try again.';
      });
  }
  function rwaTransferAdmin(userId,name){
    if(!confirm('Make '+name+' the new admin of this society? You will become a regular resident and lose admin access.')){return;}
    var fd=new FormData();
    fd.append('action','gs_transfer_society_admin');fd.append('nonce','<?php echo esc_js($nonce);?>');
    fd.append('society_id',<?php echo (int)$society->id;?>);fd.append('new_admin_user_id',userId);
    fetch('<?php echo esc_js(admin_url("admin-ajax.php"));?>',{method:'POST',credentials:'same-origin',body:fd})
      .then(function(r){return r.json();}).then(function(j){
        var el=document.getElementById('rwa-member-msg');el.style.display='block';
        if(j.success){el.style.color='#059669';el.textContent='Admin role transferred. Refreshing…';setTimeout(function(){location.reload();},900);}
        else{el.style.color='#DC2626';el.textContent=(j.data&&j.data.message)||'Failed.';}
      })
      .catch(function(){
        var el=document.getElementById('rwa-member-msg');el.style.display='block';el.style.color='#DC2626';
        el.textContent='Network error — could not reach the server. Please try again.';
      });
  }
  </script>
  <?php endif; ?>

  <?php elseif($section === 'invites' && $is_admin):
    // ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "No bulk-invite/CSV
    // import of RWA residents — one-at-a-time self-service via access code
    // only"). See RwaService::bulk_invite_residents() for the real logic;
    // this is just the CSV-paste UI + the invite tracker table.
    $invites = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}gs_society_invites WHERE society_id=%d ORDER BY status ASC, invited_at DESC LIMIT 500",
        $society->id
    ) ) ?: [];
    $pending_count = count( array_filter( $invites, fn( $i ) => $i->status === 'pending' ) );
  ?>
  <div class="rwa-card">
    <div class="rwa-card-title">✉️ Bulk-Invite Residents</div>
    <p style="color:#64748B;font-size:.83rem;margin-bottom:10px">Paste one resident per line: <strong>Name, Email, Phone, Flat Number</strong>. Each invite includes your society's access code so they can join in one step.</p>
    <textarea id="rwa-invite-csv" rows="6" class="gs-input" style="font-family:monospace;font-size:.8rem;width:100%" placeholder="Priya Sharma, priya@example.com, 9876543210, B-204&#10;Rahul Verma, rahul@example.com, 9876543211, C-101"></textarea>
    <button onclick="rwaBulkInvite()" class="gs-btn gs-btn-primary" style="margin-top:10px">Send Invites</button>
    <div id="rwa-invite-msg" style="display:none;margin-top:10px;font-size:.82rem"></div>
  </div>

  <div class="rwa-card">
    <div class="rwa-card-title">📋 Invite Tracker (<?php echo $pending_count; ?> pending, <?php echo count($invites)-$pending_count; ?> joined)</div>
    <?php if(empty($invites)): ?>
    <p style="color:#94A3B8;font-size:.83rem;text-align:center;padding:16px">No invites sent yet.</p>
    <?php else: ?>
    <table class="gs-tbl">
      <thead><tr><th>Name</th><th>Email</th><th>Flat</th><th>Status</th><th>Invited</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach($invites as $inv): ?>
      <tr id="rwa-invite-row-<?php echo (int)$inv->id; ?>">
        <td style="font-weight:600"><?php echo esc_html($inv->name?:'—'); ?></td>
        <td style="font-size:.8rem"><?php echo esc_html($inv->email); ?></td>
        <td><?php echo esc_html($inv->flat_number?:'—'); ?></td>
        <td><?php if($inv->status==='joined'): ?><span style="background:#ECFDF5;color:#059669;border-radius:4px;padding:2px 7px;font-size:.72rem;font-weight:600">✅ Joined</span><?php else: ?><span style="background:#FFFBEB;color:#B45309;border-radius:4px;padding:2px 7px;font-size:.72rem;font-weight:600">⏳ Pending</span><?php endif; ?></td>
        <td style="font-size:.75rem;color:#94A3B8"><?php echo human_time_diff(strtotime($inv->invited_at)); ?> ago</td>
        <td><?php if($inv->status==='pending'): ?><button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="rwaResendInvite(<?php echo (int)$inv->id; ?>)">Resend</button><?php endif; ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

  <script>
  function rwaBulkInvite(){
    var csv = document.getElementById('rwa-invite-csv').value.trim();
    if(!csv){alert('Paste at least one resident row first.');return;}
    var fd=new FormData();
    fd.append('action','gs_rwa_bulk_invite_residents');fd.append('nonce','<?php echo esc_js($nonce);?>');
    fd.append('society_id',<?php echo (int)$society->id;?>);fd.append('csv',csv);
    fetch('<?php echo esc_js(admin_url("admin-ajax.php"));?>',{method:'POST',credentials:'same-origin',body:fd})
      .then(function(r){return r.json();}).then(function(j){
        var el=document.getElementById('rwa-invite-msg');el.style.display='block';
        if(j.success){el.style.color='#059669';el.textContent=(j.data&&j.data.message)||'Invites sent. Refreshing…';setTimeout(function(){location.reload();},900);}
        else{el.style.color='#DC2626';el.textContent=(j.data&&j.data.message)||'Failed.';}
      })
      .catch(function(){
        var el=document.getElementById('rwa-invite-msg');el.style.display='block';el.style.color='#DC2626';
        el.textContent='Network error — could not reach the server. Please try again.';
      });
  }
  function rwaResendInvite(inviteId){
    var fd=new FormData();
    fd.append('action','gs_rwa_resend_invite');fd.append('nonce','<?php echo esc_js($nonce);?>');
    fd.append('invite_id',inviteId);
    fetch('<?php echo esc_js(admin_url("admin-ajax.php"));?>',{method:'POST',credentials:'same-origin',body:fd})
      .then(function(r){return r.json();}).then(function(j){
        if(j.success){alert('Invite re-sent.');}
        else{alert((j.data&&j.data.message)||'Failed.');}
      })
      .catch(function(){alert('Network error — could not reach the server. Please try again.');});
  }
  </script>

  <?php endif; ?>
</div>

<?php get_footer(); ?>
