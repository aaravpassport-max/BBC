<?php
/**
 * GoodService — Customer / Visitor Dashboard (UNREACHABLE — DEAD CODE)
 *
 * ENTERPRISE-AUDIT FIX (Part 4, High: "Two parallel, drifting
 * implementations of the customer dashboard exist"). CONFIRMED via a full
 * grep of the codebase (Router.php, AjaxController.php, other-dashboards.php)
 * that nothing anywhere requires/includes this file. The comment this one
 * used to carry — "Served by VisitorController::dashboard() →
 * other-dashboards.php which delegates here when $dash_type === 'visitor'"
 * — was itself inaccurate: no such delegation exists or ever has in this
 * codebase's router. The real, live /my-account/ page (gs_page=
 * visitor_dashboard) is entirely self-contained inside
 * templates/pages/other-dashboards.php's `elseif ($gs_page ===
 * 'visitor_dashboard')` block — see Router.php:352/489-491 for the actual
 * dispatch (customer_dashboard → VisitorController::dashboard(), which sets
 * gs_page=customer_dashboard/visitor_dashboard and renders other-dashboards.php,
 * never this file). The one genuinely-missing feature this file had that the
 * live version lacked (an account email/WhatsApp verification card) was
 * already ported over — see other-dashboards.php's "Account verification
 * status" section for that fix and its own explanation of this exact gap.
 *
 * This file is being left in place (not deleted) rather than risk removing
 * ~1,150 lines with no way to fully regression-test the removal in this
 * environment — but it renders nothing a real visitor will ever see. Do NOT
 * edit this file expecting a live-site change; edit other-dashboards.php's
 * visitor_dashboard block instead.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! is_user_logged_in() ) {
    wp_redirect( home_url( '/vendor/login/?redirect=' . urlencode( home_url( '/my-account/' ) ) ) );
    exit;
}

$user    = wp_get_current_user();
$uid     = (int) $user->ID;
global $wpdb;
$pfx     = $wpdb->prefix . 'gs_';
$section = sanitize_text_field( $_GET['section'] ?? 'dashboard' );
$site    = get_bloginfo( 'name' );
$color   = '#2563EB';

// ── Record last_login for this user ──────────────────────────────────────────
update_user_meta( $uid, 'gs_last_login', current_time( 'mysql' ) );

// ── Pre-fetch section data ────────────────────────────────────────────────────
$saved = $my_leads = [];

if ( in_array( $section, ['saved','dashboard'], true ) ) {
    $saved = $wpdb->get_results( $wpdb->prepare(
        "SELECT sl.*,l.title,l.slug,l.city,l.avg_rating,l.banner_url,l.logo_url,l.phone,l.whatsapp
         FROM {$pfx}saved_listings sl
         LEFT JOIN {$pfx}listings l ON sl.listing_id=l.id
         WHERE sl.user_id=%d ORDER BY sl.created_at DESC LIMIT 50", $uid
    ) ) ?: [];
}

if ( in_array( $section, ['inquiries','dashboard'], true ) ) {
    $my_leads = $wpdb->get_results( $wpdb->prepare(
        "SELECT l.*,
                li.title       AS listing_title,
                li.slug        AS listing_slug,
                li.phone       AS vendor_phone,
                li.whatsapp    AS vendor_wa,
                li.logo_url    AS vendor_logo,
                vp.business_name AS vendor_name,
                (SELECT COUNT(*) FROM {$pfx}lead_replies r
                 WHERE r.lead_id=l.id AND r.sender_type='vendor' AND r.is_internal=0
                   AND r.created_at > COALESCE(
                     (SELECT MAX(rr.created_at) FROM {$pfx}lead_replies rr
                      WHERE rr.lead_id=l.id AND rr.sender_type='customer'),
                     l.created_at
                   )
                ) AS unread_replies
         FROM {$pfx}leads l
         LEFT JOIN {$pfx}listings  li ON li.id = l.listing_id
         LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
         WHERE l.customer_user_id = %d
            OR (l.customer_user_id = 0 AND l.email = %s)
         ORDER BY l.created_at DESC LIMIT 100",
        $uid, $user->user_email
    ) ) ?: [];
}

$total_saved  = count( $saved );
$total_leads  = $section === 'inquiries' ? count( $my_leads )
    : (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$pfx}leads
         WHERE customer_user_id=%d OR (customer_user_id=0 AND email=%s)",
        $uid, $user->user_email ) );

$total_unread = (int) $wpdb->get_var( $wpdb->prepare(
    "SELECT COUNT(*) FROM {$pfx}lead_replies r
     INNER JOIN {$pfx}leads l ON l.id=r.lead_id
     WHERE (l.customer_user_id=%d OR (l.customer_user_id=0 AND l.email=%s))
       AND r.sender_type='vendor' AND r.is_internal=0
       AND r.created_at > COALESCE(
           (SELECT MAX(created_at) FROM {$pfx}lead_replies
            WHERE lead_id=r.lead_id AND sender_type='customer'), l.created_at)",
    $uid, $user->user_email ) );

// New: unread private-message count, matching the same unread_a/unread_b
// pattern already correctly used on the vendor side of this same table.
$total_unread_msgs = (int) $wpdb->get_var( $wpdb->prepare(
    "SELECT COALESCE(SUM(CASE WHEN participant_a=%d THEN unread_a ELSE unread_b END),0)
     FROM {$pfx}message_threads WHERE (participant_a=%d OR participant_b=%d) AND status='open'",
    $uid, $uid, $uid ) );

$profile_name    = trim( $user->display_name ?: ( $user->first_name . ' ' . $user->last_name ) );
$profile_phone   = get_user_meta( $uid, 'gs_phone',   true );
$profile_city    = get_user_meta( $uid, 'gs_city',    true );
$profile_company = get_user_meta( $uid, 'gs_company', true );
$profile_initials= strtoupper( substr( $profile_name ?: $user->user_email, 0, 1 ) );

// ── Admin impersonation banner ─────────────────────────────────────────────
// New: this dashboard now supports the same "Switch to Any User" impersonation
// system already used on the vendor dashboard — via the shared, generic
// gs_render_impersonation_banner() function (src/functions.php), not a
// second, duplicated copy of the detection/rendering logic.
gs_render_impersonation_banner( $profile_name ?: $user->user_email );

// ── Account verification status ───────────────────────────────────────────────
// Reads the exact two flags set by the already-working backend handlers
// (AjaxController::verifyAccountEmailOtp() / verifyAccountWhatsappOtp()) —
// see src/Service/EmailVerificationService.php:verify_account_otp() and
// WhatsAppVerificationService::verify_otp() for where these are written.
$acct_email_verified = (int) get_user_meta( $uid, 'gs_account_email_verified', true );
$acct_phone_verified = (int) get_user_meta( $uid, 'gs_account_phone_verified', true );
$acct_phone_number   = get_user_meta( $uid, 'gs_account_verified_phone', true );
$acct_fully_verified = $acct_email_verified && $acct_phone_verified;

// ── Profile update handler ────────────────────────────────────────────────────
if ( $_SERVER['REQUEST_METHOD'] === 'POST' && isset( $_POST['gs_customer_profile_nonce'] )
     && wp_verify_nonce( $_POST['gs_customer_profile_nonce'], 'gs_customer_profile_' . $uid ) ) {
    $new_name  = sanitize_text_field( $_POST['display_name'] ?? '' );
    $new_phone = sanitize_text_field( $_POST['phone'] ?? '' );
    $new_city  = sanitize_text_field( $_POST['city']  ?? '' );
    $new_comp  = sanitize_text_field( $_POST['company'] ?? '' );
    if ( $new_name ) { wp_update_user( ['ID' => $uid, 'display_name' => $new_name] ); }
    update_user_meta( $uid, 'gs_phone',   $new_phone );
    update_user_meta( $uid, 'gs_city',    $new_city  );
    update_user_meta( $uid, 'gs_company', $new_comp  );
    wp_redirect( home_url( '/my-account/?section=profile&updated=1' ) ); exit;
}
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>My Account — <?php echo esc_html( $site ); ?></title>
<link rel="stylesheet" href="<?php echo esc_url( GS_URL . 'assets/css/goodservice.css?v=' . GS_VERSION ); ?>">
<style>
:root{--cd-primary:#2563EB;--cd-primary-dark:#1D4ED8;--cd-bg:#F8FAFC;--cd-card:#fff;--cd-border:#E2E8F0;--cd-text:#1E293B;--cd-muted:#64748B;--cd-radius:10px}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;background:var(--cd-bg);color:var(--cd-text);min-height:100vh}

/* Header */
.cd-header{background:linear-gradient(135deg,#1E3A5F 0%,#2563EB 100%);padding:0 20px;display:flex;align-items:center;justify-content:space-between;height:54px;position:sticky;top:0;z-index:50;box-shadow:0 2px 12px rgba(0,0,0,.18)}
.cd-logo{color:#fff;font-weight:800;font-size:.95rem;text-decoration:none;display:flex;align-items:center;gap:8px}
.cd-logo-badge{width:28px;height:28px;border-radius:6px;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:.8rem}
.cd-huser{display:flex;align-items:center;gap:10px}
.cd-hname{color:rgba(255,255,255,.75);font-size:.8rem;display:none}
.cd-havatar{width:30px;height:30px;border-radius:50%;background:rgba(255,255,255,.2);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.8rem}
.cd-hlogout{color:rgba(255,255,255,.5);font-size:.75rem;text-decoration:none;padding:4px 10px;border:1px solid rgba(255,255,255,.2);border-radius:6px;transition:.15s}
.cd-hlogout:hover{background:rgba(255,255,255,.1);color:#fff}
@media(min-width:640px){.cd-hname{display:block}}

/* Nav */
.cd-nav{background:#fff;border-bottom:1px solid var(--cd-border);display:flex;overflow-x:auto;scrollbar-width:none}
.cd-nav::-webkit-scrollbar{display:none}
.cd-nav-a{flex-shrink:0;padding:13px 16px;font-size:.8rem;font-weight:600;color:var(--cd-muted);text-decoration:none;border-bottom:2px solid transparent;white-space:nowrap;transition:.12s;display:flex;align-items:center;gap:5px}
.cd-nav-a:hover{color:var(--cd-primary);background:#F8FAFC}
.cd-nav-a.on{border-bottom-color:var(--cd-primary);color:var(--cd-primary)}
.cd-badge{background:#EF4444;color:#fff;border-radius:20px;padding:1px 6px;font-size:.6rem;font-weight:700}

/* Layout */
.cd-wrap{max-width:1080px;margin:0 auto;padding:22px 14px 60px}
.cd-ph{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:10px}
.cd-ph-title{font-weight:800;font-size:1.05rem;color:var(--cd-text)}
.cd-ph-sub{font-size:.78rem;color:var(--cd-muted);margin-top:3px}

/* Stats grid */
.cd-stats{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin-bottom:20px}
.cd-stat{background:#fff;border:1px solid var(--cd-border);border-radius:var(--cd-radius);padding:14px;display:flex;align-items:center;gap:12px}
.cd-stat-ico{width:38px;height:38px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0}
.cd-stat-val{font-weight:800;font-size:1.2rem;line-height:1}
.cd-stat-lbl{font-size:.68rem;color:var(--cd-muted);margin-top:3px}

/* Card */
.cd-card{background:#fff;border:1px solid var(--cd-border);border-radius:var(--cd-radius);padding:18px;margin-bottom:14px}
.cd-card-title{font-weight:700;font-size:.88rem;color:var(--cd-text);margin-bottom:14px;display:flex;align-items:center;justify-content:space-between}

/* Inquiry list (two-pane) */
.cd-inq{display:flex;background:#F1F5F9;border-radius:12px;overflow:hidden;border:1px solid var(--cd-border);min-height:480px}
.cd-inq-left{width:35%;min-width:220px;max-width:320px;border-right:1px solid var(--cd-border);background:#fff;display:flex;flex-direction:column;overflow:hidden}
.cd-inq-search{padding:10px;border-bottom:1px solid #F1F5F9}
.cd-inq-search input{width:100%;padding:7px 10px;border:1px solid var(--cd-border);border-radius:7px;font-size:.78rem;outline:none;font-family:inherit}
.cd-inq-list{flex:1;overflow-y:auto}
.cd-inq-item{padding:11px 12px;border-bottom:1px solid #F1F5F9;cursor:pointer;transition:.1s;display:flex;gap:8px;align-items:flex-start}
.cd-inq-item:hover{background:#F8FAFC}
.cd-inq-item.on{background:#EFF6FF;border-left:3px solid var(--cd-primary)}
.cd-inq-dot{width:8px;height:8px;border-radius:50%;background:#EF4444;flex-shrink:0;margin-top:5px;display:none}
.cd-inq-dot.show{display:block}
.cd-inq-vname{font-weight:700;font-size:.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cd-inq-prod{font-size:.72rem;color:var(--cd-muted);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cd-inq-meta{font-size:.65rem;color:#94A3B8;margin-top:4px;display:flex;align-items:center;gap:6px}
.cd-status{display:inline-block;padding:1px 7px;border-radius:10px;font-size:.64rem;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
.cd-status-new{background:#EFF6FF;color:#1D4ED8}
.cd-status-seen{background:#F1F5F9;color:#475569}
.cd-status-contacted{background:#FFFBEB;color:#D97706}
.cd-status-converted{background:#F0FDF4;color:#15803D}
.cd-status-lost{background:#FEF2F2;color:#B91C1C}

.cd-inq-right{flex:1;display:flex;flex-direction:column;overflow:hidden}
.cd-inq-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;flex:1;color:#94A3B8;text-align:center;padding:40px}
.cd-inq-detail{display:none;flex-direction:column;flex:1;overflow:hidden}
.cd-inq-detail.show{display:flex}
.cd-inq-dhead{padding:14px 16px;background:#fff;border-bottom:1px solid var(--cd-border);display:flex;align-items:center;gap:12px}
.cd-inq-dhead-logo{width:40px;height:40px;border-radius:8px;object-fit:cover}
.cd-inq-dhead-init{width:40px;height:40px;border-radius:8px;background:var(--cd-primary);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.9rem;flex-shrink:0}
.cd-inq-scroll{flex:1;overflow-y:auto;padding:14px 16px;display:flex;flex-direction:column;gap:10px}
.cd-msg{max-width:80%;padding:9px 12px;border-radius:10px;font-size:.82rem;line-height:1.5}
.cd-msg-you{background:#EFF6FF;color:#1E3A5F;align-self:flex-end;border-bottom-right-radius:2px}
.cd-msg-vendor{background:#fff;border:1px solid var(--cd-border);color:#334155;align-self:flex-start;border-bottom-left-radius:2px}
.cd-msg-meta{font-size:.65rem;color:#94A3B8;margin-top:3px;text-align:right}
.cd-inq-reply{padding:10px 14px;border-top:1px solid var(--cd-border);background:#fff;display:flex;gap:8px}

/* ── Messages section (private DM with a vendor) ── */
.cd-msg-grid{display:grid;grid-template-columns:280px 1fr;background:#fff;border:1px solid var(--cd-border);border-radius:var(--cd-radius);overflow:hidden;min-height:520px}
.cd-msg-list{border-right:1px solid var(--cd-border);overflow-y:auto;max-height:640px}
.cd-msg-thread-item{padding:12px 14px;cursor:pointer;border-bottom:1px solid #F1F5F9;display:flex;gap:10px;align-items:center;transition:.12s}
.cd-msg-thread-item:hover{background:#F8FAFC}
.cd-msg-thread-item.on{background:#EFF6FF}
.cd-msg-av{width:36px;height:36px;border-radius:50%;background:var(--cd-primary);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.84rem;flex-shrink:0}
.cd-msg-thread-name{font-weight:600;font-size:.85rem;display:flex;align-items:center;gap:6px}
.cd-msg-thread-preview{font-size:.74rem;color:var(--cd-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px}
.cd-msg-chat{display:flex;flex-direction:column}
.cd-msg-chat-hdr{padding:13px 16px;border-bottom:1px solid var(--cd-border);font-weight:700;font-size:.9rem;color:#1E293B}
.cd-msg-chat-area{flex:1;overflow-y:auto;padding:16px;max-height:480px}
.cd-msg-compose{padding:12px;border-top:1px solid var(--cd-border);display:flex;gap:8px}
.cd-msg-compose textarea{flex:1;min-height:0;resize:none;border:1.5px solid var(--cd-border);border-radius:9px;padding:9px 12px;font-size:.85rem;font-family:inherit;outline:none}
@media(max-width:700px){.cd-msg-grid{grid-template-columns:1fr;min-height:auto}.cd-msg-list{border-right:none;border-bottom:1px solid var(--cd-border);max-height:220px}.cd-msg-chat-area{max-height:320px}}
.cd-inq-reply textarea{flex:1;padding:8px 10px;border:1px solid var(--cd-border);border-radius:8px;font-size:.8rem;resize:none;font-family:inherit;outline:none}
.cd-inq-reply button{padding:8px 14px;background:var(--cd-primary);color:#fff;border:none;border-radius:8px;font-size:.8rem;font-weight:700;cursor:pointer;align-self:flex-end;font-family:inherit}

.cd-inq-formdetails{padding:12px 16px;background:#F8FAFC;border-bottom:1px solid var(--cd-border)}
.cd-inq-formdetails-title{font-size:.75rem;font-weight:700;color:var(--cd-muted);text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px}
.cd-inq-formdetails-grid{display:flex;flex-direction:column;gap:6px}
.cd-fd-row{display:flex;align-items:baseline;gap:8px;font-size:.82rem;flex-wrap:wrap}
.cd-fd-label{color:var(--cd-muted);flex-shrink:0;min-width:120px}
.cd-fd-val{color:#1E293B;font-weight:600;word-break:break-word}

@media(max-width:600px){.cd-inq{flex-direction:column}.cd-inq-left{width:100%;max-width:100%;border-right:none;border-bottom:1px solid var(--cd-border);max-height:280px}.cd-fd-row{flex-direction:column;gap:2px}.cd-fd-label{min-width:0;font-size:.72rem}}

/* Saved listings */
.cd-saved-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
.cd-saved-card{background:#fff;border:1px solid var(--cd-border);border-radius:var(--cd-radius);overflow:hidden;transition:.15s}
.cd-saved-card:hover{box-shadow:0 4px 18px rgba(0,0,0,.08);transform:translateY(-2px)}
.cd-saved-img{height:110px;background:#E2E8F0;overflow:hidden;position:relative}
.cd-saved-img img{width:100%;height:100%;object-fit:cover}
.cd-saved-body{padding:12px}
.cd-saved-name{font-weight:700;font-size:.86rem;color:var(--cd-text);margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cd-saved-city{font-size:.74rem;color:var(--cd-muted);margin-bottom:8px}
.cd-saved-actions{display:flex;gap:6px}
.cd-btn{display:inline-flex;align-items:center;gap:4px;padding:6px 12px;border-radius:7px;font-size:.75rem;font-weight:700;text-decoration:none;border:none;cursor:pointer;font-family:inherit;transition:.12s}
.cd-btn-primary{background:var(--cd-primary);color:#fff}
.cd-btn-primary:hover{background:var(--cd-primary-dark)}
.cd-btn-ghost{background:#F1F5F9;color:var(--cd-text)}
.cd-btn-ghost:hover{background:var(--cd-border)}
.cd-btn-danger{background:#FEF2F2;color:#DC2626}
.cd-btn-danger:hover{background:#FEE2E2}

/* Profile form */
.cd-form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
@media(max-width:540px){.cd-form-grid{grid-template-columns:1fr}}
.cd-fg label{display:block;font-size:.76rem;font-weight:700;color:var(--cd-muted);margin-bottom:5px;text-transform:uppercase;letter-spacing:.04em}
.cd-input{width:100%;padding:9px 12px;border:1.5px solid var(--cd-border);border-radius:8px;font-size:.86rem;font-family:inherit;outline:none;transition:.15s;background:#fff}
.cd-input:focus{border-color:var(--cd-primary);box-shadow:0 0 0 3px rgba(37,99,235,.1)}

/* Empty state */
.cd-empty{text-align:center;padding:48px 20px;color:#94A3B8}
.cd-empty-icon{font-size:2.5rem;margin-bottom:10px}
.cd-empty-title{font-weight:700;font-size:.95rem;color:var(--cd-text);margin-bottom:6px}
.cd-empty-sub{font-size:.82rem}

/* Success toast */
.cd-toast{position:fixed;bottom:24px;right:20px;background:#065F46;color:#fff;padding:10px 18px;border-radius:8px;font-size:.82rem;font-weight:600;z-index:9999;display:none;box-shadow:0 4px 20px rgba(0,0,0,.18)}
</style>
</head>
<body>

<!-- Header -->
<header class="cd-header">
  <a href="<?php echo esc_url( home_url('/') ); ?>" class="cd-logo">
    <div class="cd-logo-badge">🏠</div>
    <?php echo esc_html( $site ); ?>
  </a>
  <div class="cd-huser">
    <span class="cd-hname"><?php echo esc_html( $profile_name ?: $user->user_email ); ?><?php if ( $acct_fully_verified ): ?> <span style="display:inline-block;background:#059669;color:#fff;font-size:.65rem;font-weight:700;padding:1px 7px;border-radius:10px;vertical-align:middle;margin-left:4px" title="Email and WhatsApp verified">✓ Verified</span><?php endif; ?></span>
    <div class="cd-havatar"><?php echo esc_html( $profile_initials ); ?></div>
    <a href="<?php echo esc_url( wp_logout_url( home_url('/') ) ); ?>" class="cd-hlogout">Logout</a>
  </div>
</header>

<!-- Nav -->
<nav class="cd-nav">
  <a href="?section=dashboard"  class="cd-nav-a <?php echo $section==='dashboard' ?'on':''; ?>">📊 Overview</a>
  <a href="?section=inquiries"  class="cd-nav-a <?php echo $section==='inquiries' ?'on':''; ?>">
    📬 My Inquiries
    <?php if($total_unread): ?><span class="cd-badge"><?php echo $total_unread; ?></span><?php endif; ?>
  </a>
  <a href="?section=saved"      class="cd-nav-a <?php echo $section==='saved' ?'on':''; ?>">
    ❤️ Saved
    <?php if($total_saved): ?><span class="cd-badge" style="background:#64748B"><?php echo $total_saved; ?></span><?php endif; ?>
  </a>
  <a href="?section=messages"   class="cd-nav-a <?php echo $section==='messages' ?'on':''; ?>">
    💬 Messages
    <?php if($total_unread_msgs): ?><span class="cd-badge"><?php echo $total_unread_msgs; ?></span><?php endif; ?>
  </a>
  <a href="?section=profile"    class="cd-nav-a <?php echo $section==='profile' ?'on':''; ?>">👤 My Profile</a>
  <a href="?section=track"      class="cd-nav-a <?php echo $section==='track' ?'on':''; ?>">📍 Track Jobs</a>
  <a href="?section=privacy"    class="cd-nav-a <?php echo $section==='privacy' ?'on':''; ?>">🔒 Privacy & Data</a>
  <a href="<?php echo esc_url(home_url('/my-home/')); ?>" class="cd-nav-a">🏠 My Home</a>
  <a href="<?php echo esc_url(home_url('/rwa/dashboard/')); ?>" class="cd-nav-a">🏢 My Society</a>
  <a href="<?php echo esc_url( home_url('/directory/') ); ?>" class="cd-nav-a">🔍 Browse Listings</a>
</nav>

<div class="cd-wrap">

<?php /* ══════════════════════ OVERVIEW ══════════════════════════════ */ ?>
<?php if ( $section === 'dashboard' ): ?>

<div class="cd-ph">
  <div>
    <div class="cd-ph-title">👋 Welcome back, <?php echo esc_html( $profile_name ?: 'there' ); ?>!</div>
    <div class="cd-ph-sub">Here's a summary of your activity on <?php echo esc_html( $site ); ?></div>
  </div>
  <a href="<?php echo esc_url( home_url('/directory/') ); ?>" class="cd-btn cd-btn-primary">🔍 Browse Listings</a>
</div>

<!-- Account Verification card -->
<div class="cd-card" id="cd-verify-card" style="border-left:4px solid <?php echo $acct_fully_verified ? '#059669' : '#F59E0B'; ?>;margin-bottom:16px">
  <?php if ( ! $acct_fully_verified ): ?>
  <div style="background:#FFFBEB;border-radius:8px;padding:10px 14px;margin-bottom:14px;font-size:.85rem;color:#92400E">
    ⚠ Verify your account to increase trust and activate your inquiries.
  </div>
  <?php endif; ?>
  <div class="cd-card-title">Account Verification</div>
  <div id="cd-verify-status-line" style="margin:10px 0 16px">
    <div style="font-size:.88rem;margin-bottom:6px" id="cd-verify-email-line"><?php echo $acct_email_verified ? '✓ Email Verified' : '⚠ Email Not Verified'; ?></div>
    <div style="font-size:.88rem" id="cd-verify-phone-line"><?php echo $acct_phone_verified ? '✓ WhatsApp Verified' : '⚠ WhatsApp Not Verified'; ?></div>
  </div>
  <?php if ( $acct_fully_verified ): ?>
    <div style="color:#059669;font-weight:700;font-size:.9rem">Status: Verified Account</div>
  <?php else: ?>
    <div style="font-size:.83rem;color:var(--cd-muted);margin-bottom:14px">Complete verification to make your inquiries appear as <strong>Verified Inquiry</strong> to suppliers instead of <em>Verification Pending</em>.</div>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <?php if ( ! $acct_email_verified ): ?>
      <button class="cd-btn" style="background:#2563EB;color:#fff" onclick="cdShowEmailVerify()">Verify Email</button>
      <?php endif; ?>
      <?php if ( ! $acct_phone_verified ): ?>
      <button class="cd-btn" style="background:#059669;color:#fff" onclick="cdShowWaVerify()">Verify WhatsApp</button>
      <?php endif; ?>
    </div>
    <div id="cd-verify-inline-panel" style="margin-top:14px"></div>
  <?php endif; ?>
</div>
<script>
(function(){
  var nonce = '<?php echo esc_js( wp_create_nonce( "gs_ajax" ) ); ?>';
  var ajaxUrl = '<?php echo esc_js( admin_url( "admin-ajax.php" ) ); ?>';
  var panel = document.getElementById('cd-verify-inline-panel');

  function post(action, data, ok, err) {
    var fd = new FormData();
    fd.append('action', action);
    fd.append('nonce', nonce);
    for (var k in data) { fd.append(k, data[k]); }
    fetch(ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(d){ if (d && d.success) ok(d.data); else err((d && d.data && d.data.message) || 'Something went wrong.'); })
      .catch(function(){ err('Network error. Please try again.'); });
  }

  function markVerified(which) {
    if (which === 'email') document.getElementById('cd-verify-email-line').textContent = '✓ Email Verified';
    if (which === 'phone') document.getElementById('cd-verify-phone-line').textContent = '✓ WhatsApp Verified';
    // Reload to refresh the card into its fully-verified state and the header badge.
    setTimeout(function(){ window.location.reload(); }, 900);
  }

  window.cdShowEmailVerify = function() {
    panel.innerHTML = '<div style="font-size:.8rem;color:var(--cd-muted);margin-bottom:8px">We\'ll send a 6-digit code to <strong><?php echo esc_js( $user->user_email ); ?></strong>.</div>'
      + '<div id="cd-em-msg" style="font-size:.8rem;margin-bottom:8px;min-height:18px"></div>'
      + '<input id="cd-em-code" type="text" inputmode="numeric" maxlength="6" placeholder="Enter code" style="border:2px solid #E2E8F0;border-radius:8px;padding:9px;font-size:1rem;letter-spacing:.2em;width:160px;margin-right:8px">'
      + '<button class="cd-btn" style="background:#2563EB;color:#fff" id="cd-em-send-btn" onclick="cdSendEmailOtp()">Send Code</button> '
      + '<button class="cd-btn" style="background:#F1F5F9;color:#334155;display:none" id="cd-em-verify-btn" onclick="cdVerifyEmailOtp()">Verify</button>';
  };
  window.cdSendEmailOtp = function() {
    var btn = document.getElementById('cd-em-send-btn'); btn.disabled = true; btn.textContent = 'Sending…';
    post('gs_send_account_email_otp', {}, function(d) {
      btn.textContent = 'Resend Code'; btn.disabled = false;
      document.getElementById('cd-em-msg').style.color = '#059669';
      document.getElementById('cd-em-msg').textContent = d.message || 'Code sent!';
      document.getElementById('cd-em-verify-btn').style.display = 'inline-block';
    }, function(msg) {
      btn.disabled = false; btn.textContent = 'Send Code';
      document.getElementById('cd-em-msg').style.color = '#DC2626';
      document.getElementById('cd-em-msg').textContent = msg;
    });
  };
  window.cdVerifyEmailOtp = function() {
    var code = document.getElementById('cd-em-code').value.trim();
    if (!code) { return; }
    post('gs_verify_account_email_otp', { code: code }, function() {
      document.getElementById('cd-em-msg').style.color = '#059669';
      document.getElementById('cd-em-msg').textContent = 'Email verified!';
      markVerified('email');
    }, function(msg) {
      document.getElementById('cd-em-msg').style.color = '#DC2626';
      document.getElementById('cd-em-msg').textContent = msg;
    });
  };

  window.cdShowWaVerify = function() {
    panel.innerHTML = '<div style="font-size:.8rem;color:var(--cd-muted);margin-bottom:8px">Enter your WhatsApp number to receive a verification code.</div>'
      + '<div id="cd-wa-msg" style="font-size:.8rem;margin-bottom:8px;min-height:18px"></div>'
      + '<input id="cd-wa-phone" type="tel" placeholder="WhatsApp number" style="border:2px solid #E2E8F0;border-radius:8px;padding:9px;font-size:.9rem;width:180px;margin-right:8px">'
      + '<button class="cd-btn" style="background:#059669;color:#fff" id="cd-wa-send-btn" onclick="cdSendWaOtp()">Send Code</button>'
      + '<div id="cd-wa-code-row" style="display:none;margin-top:10px">'
      + '<input id="cd-wa-code" type="text" inputmode="numeric" maxlength="6" placeholder="Enter code" style="border:2px solid #E2E8F0;border-radius:8px;padding:9px;font-size:1rem;letter-spacing:.2em;width:160px;margin-right:8px">'
      + '<button class="cd-btn" style="background:#F1F5F9;color:#334155" onclick="cdVerifyWaOtp()">Verify</button></div>';
  };
  window.cdSendWaOtp = function() {
    var phone = document.getElementById('cd-wa-phone').value.trim();
    if (!phone) { return; }
    var btn = document.getElementById('cd-wa-send-btn'); btn.disabled = true; btn.textContent = 'Sending…';
    post('gs_send_account_whatsapp_otp', { phone: phone }, function(d) {
      btn.textContent = 'Resend Code'; btn.disabled = false;
      document.getElementById('cd-wa-msg').style.color = '#059669';
      document.getElementById('cd-wa-msg').textContent = d.message || 'Code sent via WhatsApp!';
      document.getElementById('cd-wa-code-row').style.display = 'block';
    }, function(msg) {
      btn.disabled = false; btn.textContent = 'Send Code';
      document.getElementById('cd-wa-msg').style.color = '#DC2626';
      document.getElementById('cd-wa-msg').textContent = msg;
    });
  };
  window.cdVerifyWaOtp = function() {
    var code = document.getElementById('cd-wa-code').value.trim();
    if (!code) { return; }
    post('gs_verify_account_whatsapp_otp', { code: code }, function() {
      document.getElementById('cd-wa-msg').style.color = '#059669';
      document.getElementById('cd-wa-msg').textContent = 'WhatsApp verified!';
      markVerified('phone');
    }, function(msg) {
      document.getElementById('cd-wa-msg').style.color = '#DC2626';
      document.getElementById('cd-wa-msg').textContent = msg;
    });
  };
})();
</script>

<!-- Stats -->
<div class="cd-stats">
  <div class="cd-stat">
    <div class="cd-stat-ico" style="background:#EFF6FF">📬</div>
    <div>
      <div class="cd-stat-val"><?php echo $total_leads; ?></div>
      <div class="cd-stat-lbl">Inquiries Sent</div>
    </div>
  </div>
  <div class="cd-stat">
    <div class="cd-stat-ico" style="background:<?php echo $total_unread ? '#FEF2F2' : '#F0FDF4'; ?>">
      <?php echo $total_unread ? '🔔' : '✅'; ?>
    </div>
    <div>
      <div class="cd-stat-val" style="color:<?php echo $total_unread ? '#DC2626' : '#059669'; ?>"><?php echo $total_unread; ?></div>
      <div class="cd-stat-lbl">Unread Replies</div>
    </div>
  </div>
  <div class="cd-stat">
    <div class="cd-stat-ico" style="background:#FFF7ED">❤️</div>
    <div>
      <div class="cd-stat-val"><?php echo $total_saved; ?></div>
      <div class="cd-stat-lbl">Saved Listings</div>
    </div>
  </div>
</div>

<!-- Recent inquiries -->
<?php if ( $my_leads ): ?>
<div class="cd-card">
  <div class="cd-card-title">
    📬 Recent Inquiries
    <a href="?section=inquiries" style="font-size:.74rem;font-weight:400;color:var(--cd-primary)">View all →</a>
  </div>
  <div style="display:flex;flex-direction:column;gap:8px">
  <?php foreach( array_slice($my_leads,0,5) as $l ): ?>
  <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:#F8FAFC;border-radius:8px;gap:10px;flex-wrap:wrap">
    <div style="flex:1;min-width:0">
      <div style="font-weight:700;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo esc_html($l->vendor_name??'Unknown'); ?></div>
      <div style="font-size:.74rem;color:var(--cd-muted);margin-top:2px"><?php echo esc_html($l->listing_title??'—'); ?></div>
    </div>
    <div style="display:flex;align-items:center;gap:8px">
      <?php if($l->unread_replies??0): ?>
      <span style="background:#EF4444;color:#fff;border-radius:20px;padding:2px 8px;font-size:.65rem;font-weight:700"><?php echo (int)$l->unread_replies; ?> new</span>
      <?php endif; ?>
      <span class="cd-status cd-status-<?php echo esc_attr($l->status??'new'); ?>"><?php echo ucfirst($l->status??'new'); ?></span>
      <span style="font-size:.72rem;color:#94A3B8"><?php echo gs_time_ago($l->created_at); ?></span>
    </div>
  </div>
  <?php endforeach; ?>
  </div>
</div>
<?php else: ?>
<div class="cd-card">
  <div class="cd-empty"><div class="cd-empty-icon">📬</div><div class="cd-empty-title">No inquiries yet</div><div class="cd-empty-sub">Submit an enquiry on any listing and it will appear here.</div><a href="<?php echo esc_url(home_url('/directory/')); ?>" class="cd-btn cd-btn-primary" style="margin-top:14px">Browse Listings</a></div>
</div>
<?php endif; ?>

<!-- Saved listings preview -->
<?php if ( $saved ): ?>
<div class="cd-card">
  <div class="cd-card-title">
    ❤️ Saved Listings
    <a href="?section=saved" style="font-size:.74rem;font-weight:400;color:var(--cd-primary)">View all →</a>
  </div>
  <div class="cd-saved-grid">
  <?php foreach( array_slice($saved,0,4) as $s ): ?>
    <div class="cd-saved-card">
      <div class="cd-saved-img">
        <?php if($s->banner_url||$s->logo_url): ?>
        <img src="<?php echo esc_url($s->banner_url?:$s->logo_url); ?>" alt="<?php echo esc_attr($s->title); ?>" loading="lazy">
        <?php else: ?>
        <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#94A3B8;font-size:1.8rem">🏢</div>
        <?php endif; ?>
      </div>
      <div class="cd-saved-body">
        <div class="cd-saved-name"><?php echo esc_html($s->title??'—'); ?></div>
        <div class="cd-saved-city">📍 <?php echo esc_html($s->city??'—'); ?></div>
        <div class="cd-saved-actions">
          <a href="<?php echo esc_url(home_url('/'.$s->slug.'/')); ?>" class="cd-btn cd-btn-primary">View</a>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<?php /* ══════════════════════ INQUIRIES ══════════════════════════════ */ ?>
<?php elseif ( $section === 'inquiries' ): ?>

<div class="cd-ph">
  <div><div class="cd-ph-title">📬 My Inquiries</div><div class="cd-ph-sub"><?php echo $total_leads; ?> total<?php if($total_unread): ?> · <strong style="color:#DC2626"><?php echo $total_unread; ?> unread</strong><?php endif; ?></div></div>
</div>

<?php if ( $my_leads ): ?>
<div class="cd-inq" id="cd-inq-wrap">
  <!-- Left pane: list -->
  <div class="cd-inq-left">
    <div class="cd-inq-search">
      <input type="text" placeholder="🔍  Search inquiries…" id="cd-inq-search" oninput="cdFilterInq(this.value)">
    </div>
    <div class="cd-inq-list" id="cd-inq-list">
    <?php foreach( $my_leads as $i => $l ): ?>
    <div class="cd-inq-item <?php echo $i===0?'on':''; ?>" data-idx="<?php echo $i; ?>"
         data-vendor="<?php echo esc_attr(strtolower($l->vendor_name??'')); ?>"
         data-product="<?php echo esc_attr(strtolower($l->product_name??'')); ?>"
         onclick="cdShowInq(<?php echo $i; ?>)">
      <div class="cd-inq-dot <?php echo ($l->unread_replies??0)?'show':''; ?>"></div>
      <div style="flex:1;min-width:0">
        <div class="cd-inq-vname"><?php echo esc_html($l->vendor_name??'Unknown Vendor'); ?></div>
        <div class="cd-inq-prod"><?php echo esc_html($l->product_name ?: ($l->listing_title??'General Inquiry')); ?></div>
        <div class="cd-inq-meta">
          <span class="cd-status cd-status-<?php echo esc_attr($l->status??'new'); ?>"><?php echo ucfirst($l->status??'new'); ?></span>
          <span><?php echo gs_time_ago($l->created_at); ?></span>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    </div>
  </div>

  <!-- Right pane: detail + replies -->
  <div class="cd-inq-right" id="cd-inq-right">
    <div class="cd-inq-empty" id="cd-inq-empty" style="display:none">
      <div style="font-size:2rem;margin-bottom:8px">💬</div>
      <div style="font-weight:600;font-size:.9rem">Select an inquiry to view details</div>
    </div>
    <?php foreach( $my_leads as $i => $l ):
      // Fetch replies for this lead
      $replies = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$pfx}lead_replies
         WHERE lead_id=%d AND is_internal=0
         ORDER BY sent_at ASC, created_at ASC LIMIT 50",
        $l->id
      ));
    ?>
    <div class="cd-inq-detail <?php echo $i===0?'show':''; ?>" id="cd-inq-detail-<?php echo $i; ?>">
      <!-- Detail header -->
      <div class="cd-inq-dhead">
        <?php if($l->vendor_logo): ?>
        <img src="<?php echo esc_url($l->vendor_logo); ?>" class="cd-inq-dhead-logo" alt="">
        <?php else: ?>
        <div class="cd-inq-dhead-init"><?php echo strtoupper(substr($l->vendor_name??'V',0,1)); ?></div>
        <?php endif; ?>
        <div style="flex:1;min-width:0">
          <div style="font-weight:700;font-size:.88rem"><?php echo esc_html($l->vendor_name??'Unknown'); ?></div>
          <div style="font-size:.74rem;color:var(--cd-muted)"><?php echo esc_html($l->listing_title??'—'); ?></div>
        </div>
        <div style="display:flex;gap:6px;flex-shrink:0;flex-wrap:wrap">
          <?php if($l->vendor_phone): ?><a href="tel:<?php echo esc_attr($l->vendor_phone); ?>" class="cd-btn cd-btn-ghost" style="font-size:.72rem">📞 Call</a><?php endif; ?>
          <?php if($l->vendor_wa): ?>
          <?php $wac=preg_replace('/[^0-9]/','',($l->vendor_wa??'')); ?>
          <a href="https://wa.me/<?php echo esc_attr($wac); ?>" target="_blank" class="cd-btn cd-btn-ghost" style="font-size:.72rem;background:#F0FDF4;color:#059669">💬 WhatsApp</a>
          <?php endif; ?>
          <?php if(in_array($l->status??'',['converted','closed','done'])): ?>
          <a href="<?php echo esc_url(home_url('/'.$l->listing_slug.'/#vs-sec-inquiry-modules')); ?>" class="cd-btn cd-btn-primary" style="font-size:.72rem;background:#7C3AED">🔁 Book Again</a>
          <?php
          // Part 12.4 — Review only available after booking is marked done
          $has_booking_done = false;
          if($l->id && $pfx) {
            $has_booking_done = (bool)$wpdb->get_var($wpdb->prepare(
              "SELECT COUNT(*) FROM {$pfx}bookings WHERE lead_id=%d AND job_status='done' LIMIT 1",
              (int)$l->id
            ));
          }
          if($has_booking_done): ?>
          <a href="<?php echo esc_url(home_url('/'.$l->listing_slug.'/?leave_review=1')); ?>" class="cd-btn cd-btn-primary" style="font-size:.72rem;background:#D97706">⭐ Leave Review</a>
          <?php elseif(in_array($l->status??'',['converted','closed','done'])): ?>
          <button disabled title="Review available after job is marked complete by vendor" style="font-size:.68rem;opacity:.5;padding:5px 10px;border:1px solid #E2E8F0;border-radius:7px;cursor:not-allowed;background:#F8FAFC;color:#94A3B8">⭐ Review (available after job done)</button>
          <?php endif; ?>
          <?php endif; ?>
        </div>
      </div>

      <!-- Inquiry status timeline (Part 3.3) -->
      <div style="padding:10px 16px;background:#F8FAFC;border-bottom:1px solid #F1F5F9">
        <div style="display:flex;align-items:center;gap:0;position:relative">
          <?php
          $stages = [
            ['submitted','📤','Submitted'],
            ['viewed','👁','Viewed'],
            ['replied','💬','Replied'],
            ['converted','✅','Booked'],
          ];
          $current_stage = match($l->status??'new'){
            'new'=>0, 'viewed'=>1, 'replied'=>2, 'converted','closed'=>3, default=>0
          };
          foreach($stages as $si=>$stage):
            $done = $si <= $current_stage;
            $active = $si === $current_stage;
          ?>
          <?php if($si>0): ?><div style="flex:1;height:2px;background:<?php echo $done?'#2563EB':'#E2E8F0'; ?>;margin-top:-10px"></div><?php endif; ?>
          <div style="display:flex;flex-direction:column;align-items:center;gap:3px;position:relative">
            <div style="width:26px;height:26px;border-radius:50%;background:<?php echo $done?'#2563EB':'#E2E8F0'; ?>;color:<?php echo $done?'#fff':'#94A3B8'; ?>;display:flex;align-items:center;justify-content:center;font-size:.75rem;font-weight:700;border:2px solid <?php echo $done?'#2563EB':'#E2E8F0'; ?>"><?php echo $done?'✓':($si+1); ?></div>
            <div style="font-size:.6rem;color:<?php echo $done?'#2563EB':'#94A3B8'; ?>;font-weight:<?php echo $active?700:400; ?>;white-space:nowrap"><?php echo $stage[2]; ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Submitted form details — the actual data collected at inquiry time,
           distinct from the back-and-forth conversation below. Previously
           none of this was shown here even though it was already being
           fetched (SELECT l.* already includes every one of these columns). -->
      <?php
      $has_form_details = $l->product_name || $l->product_price || $l->quantity
        || $l->purchase_date || $l->callback_date || $l->booking_date || $l->booking_time;
      $extra = [];
      if ( ! empty( $l->extra_fields ) ) {
          $extra = is_array( $l->extra_fields ) ? $l->extra_fields : ( json_decode( $l->extra_fields, true ) ?: [] );
      }
      ?>
      <?php if ( $has_form_details || ! empty( $extra ) ): ?>
      <div class="cd-inq-formdetails">
        <div class="cd-inq-formdetails-title">📋 Submitted Details</div>
        <div class="cd-inq-formdetails-grid">
          <?php if ( $l->product_name ): ?><div class="cd-fd-row"><span class="cd-fd-label">Product / Service</span><span class="cd-fd-val"><?php echo esc_html( $l->product_name ); ?></span></div><?php endif; ?>
          <?php if ( $l->product_price ): ?><div class="cd-fd-row"><span class="cd-fd-label">Price / Budget</span><span class="cd-fd-val"><?php echo esc_html( $l->product_price ); ?></span></div><?php endif; ?>
          <?php if ( $l->quantity ): ?><div class="cd-fd-row"><span class="cd-fd-label">Quantity</span><span class="cd-fd-val"><?php echo esc_html( $l->quantity ); ?></span></div><?php endif; ?>
          <?php if ( $l->purchase_date && $l->purchase_date !== '0000-00-00' ): ?><div class="cd-fd-row"><span class="cd-fd-label">Purchase Date</span><span class="cd-fd-val"><?php echo esc_html( date_i18n( 'j M Y', strtotime( $l->purchase_date ) ) ); ?></span></div><?php endif; ?>
          <?php if ( $l->callback_date && $l->callback_date !== '0000-00-00 00:00:00' ): ?><div class="cd-fd-row"><span class="cd-fd-label">Requested Callback</span><span class="cd-fd-val"><?php echo esc_html( date_i18n( 'j M Y, g:i A', strtotime( $l->callback_date ) ) ); ?></span></div><?php endif; ?>
          <?php if ( $l->booking_date && $l->booking_date !== '0000-00-00' ): ?><div class="cd-fd-row"><span class="cd-fd-label">Booking Date</span><span class="cd-fd-val"><?php echo esc_html( date_i18n( 'j M Y', strtotime( $l->booking_date ) ) ); ?><?php if ( $l->booking_time ): ?> at <?php echo esc_html( $l->booking_time ); ?><?php endif; ?></span></div><?php endif; ?>
          <?php foreach ( $extra as $ek => $ev ):
            if ( $ev === '' || $ev === null || is_array( $ev ) && empty( $ev ) ) continue;
            $ev_display = is_array( $ev ) ? implode( ', ', array_map( 'strval', $ev ) ) : $ev;
          ?>
          <div class="cd-fd-row"><span class="cd-fd-label"><?php echo esc_html( ucwords( str_replace( ['_','-'], ' ', (string) $ek ) ) ); ?></span><span class="cd-fd-val"><?php echo esc_html( $ev_display ); ?></span></div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <!-- Messages -->
      <div class="cd-inq-scroll" id="cd-inq-scroll-<?php echo $i; ?>">
        <?php if($l->message): ?>
        <div style="align-self:flex-end;max-width:80%">
          <div class="cd-msg cd-msg-you"><?php echo nl2br(esc_html($l->message)); ?></div>
          <div class="cd-msg-meta">You · <?php echo gs_time_ago($l->created_at); ?></div>
        </div>
        <?php endif; ?>
        <?php foreach($replies as $r): ?>
        <?php $is_me = ($r->sender_type === 'customer'); ?>
        <div style="align-self:<?php echo $is_me?'flex-end':'flex-start'; ?>;max-width:80%">
          <div class="cd-msg <?php echo $is_me?'cd-msg-you':'cd-msg-vendor'; ?>"><?php echo nl2br(esc_html($r->message)); ?></div>
          <div class="cd-msg-meta" style="text-align:<?php echo $is_me?'right':'left'; ?>"><?php echo $is_me?'You':esc_html($l->vendor_name??'Vendor'); ?> · <?php echo gs_time_ago($r->sent_at??$r->created_at); ?></div>
        </div>
        <?php endforeach; ?>
        <?php if(!$l->message && !$replies): ?>
        <div style="text-align:center;color:#94A3B8;font-size:.82rem;padding:20px">No messages yet</div>
        <?php endif; ?>
      </div>

      <!-- Reply input -->
      <div class="cd-inq-reply">
        <textarea id="cd-reply-<?php echo $l->id; ?>" rows="2" placeholder="Write a reply…"></textarea>
        <button onclick="cdSendReply(<?php echo $l->id; ?>, <?php echo $i; ?>)">Send</button>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php else: ?>
<div class="cd-empty"><div class="cd-empty-icon">📬</div><div class="cd-empty-title">No inquiries yet</div><div class="cd-empty-sub">Your submitted inquiries will appear here.</div><a href="<?php echo esc_url(home_url('/directory/')); ?>" class="cd-btn cd-btn-primary" style="margin-top:14px">Browse Listings</a></div>
<?php endif; ?>

<?php /* ══════════════════════ SAVED ══════════════════════════════════ */ ?>
<?php elseif ( $section === 'saved' ): ?>

<div class="cd-ph">
  <div><div class="cd-ph-title">❤️ Saved Listings</div><div class="cd-ph-sub"><?php echo $total_saved; ?> saved</div></div>
  <a href="<?php echo esc_url(home_url('/directory/')); ?>" class="cd-btn cd-btn-primary">🔍 Browse More</a>
</div>

<?php if ( $saved ): ?>
<div class="cd-saved-grid">
<?php foreach( $saved as $s ): ?>
<div class="cd-saved-card">
  <div class="cd-saved-img">
    <?php if($s->banner_url||$s->logo_url): ?>
    <img src="<?php echo esc_url($s->banner_url?:$s->logo_url); ?>" alt="<?php echo esc_attr($s->title); ?>" loading="lazy">
    <?php else: ?>
    <div style="width:100%;height:100%;background:#E2E8F0;display:flex;align-items:center;justify-content:center;color:#94A3B8;font-size:1.8rem">🏢</div>
    <?php endif; ?>
  </div>
  <div class="cd-saved-body">
    <div class="cd-saved-name"><?php echo esc_html($s->title??'—'); ?></div>
    <div class="cd-saved-city">📍 <?php echo esc_html($s->city??'—'); ?></div>
    <?php if(!empty($s->avg_rating)): ?>
    <div style="font-size:.74rem;color:#F59E0B;margin-bottom:8px">★ <?php echo number_format($s->avg_rating,1); ?></div>
    <?php endif; ?>
    <div class="cd-saved-actions">
      <a href="<?php echo esc_url(home_url('/'.$s->slug.'/'));?>" class="cd-btn cd-btn-primary">View</a>
      <a href="<?php echo esc_url(home_url('/'.$s->slug.'/#vs-sec-inquiry-modules'));?>" class="cd-btn cd-btn-ghost">📋 Enquire</a>
      <button class="cd-btn cd-btn-danger" onclick="cdUnsave(<?php echo (int)$s->listing_id;?>,this)" title="Remove from saved">♡</button>
    </div>
  </div>
</div>
<?php endforeach; ?>
</div>
<?php else: ?>
<div class="cd-empty"><div class="cd-empty-icon">❤️</div><div class="cd-empty-title">Nothing saved yet</div><div class="cd-empty-sub">Click the ♡ button on any listing to save it here.</div><a href="<?php echo esc_url(home_url('/directory/')); ?>" class="cd-btn cd-btn-primary" style="margin-top:14px">Browse Listings</a></div>
<?php endif; ?>

<?php /* ══ MESSAGES ══════════════════════════════════════════════════ */ ?>
<?php elseif ( $section === 'messages' ):
  $thread_id = (int) ( $_GET['thread'] ?? 0 );
  $threads   = $wpdb->get_results( $wpdb->prepare(
    "SELECT t.*, u.display_name AS oname FROM {$pfx}message_threads t
     LEFT JOIN {$wpdb->prefix}users u ON u.ID = (CASE WHEN t.participant_a=%d THEN t.participant_b ELSE t.participant_a END)
     WHERE (t.participant_a=%d OR t.participant_b=%d) AND t.status='open'
     ORDER BY t.last_message_at DESC",
    $uid, $uid, $uid
  ) );
?>
<div class="cd-ph"><div><div class="cd-ph-title">💬 Messages</div><div class="cd-ph-sub"><?php echo count($threads); ?> conversation<?php echo count($threads)===1?'':'s'; ?></div></div></div>

<div class="cd-msg-grid">
  <div class="cd-msg-list">
    <?php foreach($threads as $t):
      $uk = $t->participant_a==$uid ? 'unread_a' : 'unread_b'; $unr = $t->$uk;
    ?>
    <div onclick="cdLoadThread(<?php echo (int)$t->id; ?>)" id="cd-thr-<?php echo (int)$t->id; ?>" class="cd-msg-thread-item<?php echo $thread_id==$t->id?' on':''; ?>">
      <div class="cd-msg-av"><?php echo strtoupper(substr($t->oname??'V',0,1)); ?></div>
      <div style="flex:1;min-width:0">
        <div class="cd-msg-thread-name"><?php echo esc_html($t->oname??'Vendor'); ?><?php if($unr): ?><span class="cd-badge"><?php echo (int)$unr; ?></span><?php endif; ?></div>
        <div class="cd-msg-thread-preview"><?php echo esc_html(substr($t->last_message??'',0,40)); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if(!$threads): ?>
    <div class="cd-empty" style="padding:32px 14px"><div class="cd-empty-icon">💬</div><div class="cd-empty-title">No conversations yet</div><div class="cd-empty-sub">Messages with vendors will appear here.</div></div>
    <?php endif; ?>
  </div>
  <div class="cd-msg-chat">
    <div id="cd-msg-chat-hdr" class="cd-msg-chat-hdr">Select a conversation</div>
    <div id="cd-msg-chat-area" class="cd-msg-chat-area">
      <div style="text-align:center;color:#94A3B8;font-size:.82rem;padding-top:60px">Select a conversation to read messages</div>
    </div>
    <div class="cd-msg-compose">
      <textarea id="cd-msg-inp" rows="2" placeholder="Type a message… (Enter to send, Shift+Enter for new line)"></textarea>
      <button id="cd-msg-send" class="cd-btn cd-btn-primary">Send</button>
    </div>
  </div>
</div>
<script>
(function(){
  var activeThread = <?php echo (int) $thread_id; ?>;
  var myUid = <?php echo (int) $uid; ?>;
  // Real fix: self-contained nonce/URL, not dependent on the global NONCE/AJX
  // variables declared later in this file (line ~990) — this section renders
  // earlier in the page, so referencing those globals here would throw
  // ReferenceError before they exist.
  var msgNonce = <?php echo wp_json_encode( wp_create_nonce('gs_ajax') ); ?>;
  var msgAjaxUrl = <?php echo wp_json_encode( admin_url('admin-ajax.php') ); ?>;
  window.cdLoadThread = function(tid) {
    activeThread = tid;
    document.querySelectorAll('[id^="cd-thr-"]').forEach(function(el){ el.classList.remove('on'); });
    var row = document.getElementById('cd-thr-'+tid); if (row) row.classList.add('on');
    document.getElementById('cd-msg-chat-area').innerHTML = '<div style="text-align:center;color:#94A3B8;font-size:.8rem;padding:30px">Loading…</div>';
    var fd = new FormData();
    fd.append('action','gs_get_messages'); fd.append('nonce', msgNonce); fd.append('thread_id', tid);
    fetch(msgAjaxUrl,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(d){
      if (!d.success) { document.getElementById('cd-msg-chat-area').innerHTML = '<div style="text-align:center;color:#DC2626;font-size:.82rem;padding:30px">Could not load this conversation.</div>'; return; }
      var msgs = (d.data && d.data.messages) || [];
      var html = '';
      if (msgs.length) {
        msgs.forEach(function(m){
          var mine = m.sender_id == myUid;
          html += '<div style="display:flex;justify-content:'+(mine?'flex-end':'flex-start')+';margin-bottom:8px">'
            + '<div style="max-width:70%;background:'+(mine?'var(--cd-primary)':'#F1F5F9')+';color:'+(mine?'#fff':'#1E293B')+';padding:9px 13px;border-radius:12px;font-size:.84rem;line-height:1.5">'
            + document.createElement('div').appendChild(document.createTextNode(m.message||'')).parentNode.innerHTML
            + '<div style="font-size:.62rem;opacity:.55;margin-top:3px;text-align:right">'+m.created_at+'</div></div></div>';
        });
      } else {
        html = '<div style="text-align:center;color:#94A3B8;font-size:.8rem;padding:40px 0">No messages yet. Start the conversation!</div>';
      }
      document.getElementById('cd-msg-chat-area').innerHTML = html;
      document.getElementById('cd-msg-chat-area').scrollTop = 999999;
      if (d.data && d.data.other_name) document.getElementById('cd-msg-chat-hdr').textContent = d.data.other_name;
    })
    // Real fix — a network error previously left "Loading…" on screen
    // forever with no way to tell the conversation had actually failed
    // to load.
    .catch(function(){
      document.getElementById('cd-msg-chat-area').innerHTML = '<div style="text-align:center;color:#DC2626;font-size:.82rem;padding:30px">Network error — could not load this conversation. Please try again.</div>';
    });
  };
  document.getElementById('cd-msg-send').addEventListener('click', function(){
    if (!activeThread) { cdToast('Select a conversation first.'); return; }
    var txt = document.getElementById('cd-msg-inp').value.trim();
    if (!txt) return;
    var fd = new FormData();
    fd.append('action','gs_send_message'); fd.append('nonce', msgNonce);
    fd.append('thread_id', activeThread); fd.append('message', txt);
    fetch(msgAjaxUrl,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(){
      document.getElementById('cd-msg-inp').value = '';
      cdLoadThread(activeThread);
    })
    // Real fix — a network error previously left the message box exactly
    // as the customer left it with zero feedback that the send failed —
    // indistinguishable from a successful send that just hadn't rendered
    // yet, so a customer could easily believe their message went through
    // when it never left the browser.
    .catch(function(){
      cdToast('Message not sent — network error. Please try again.');
    });
  });
  document.getElementById('cd-msg-inp').addEventListener('keydown', function(e){
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); document.getElementById('cd-msg-send').click(); }
  });
  <?php if ($thread_id): ?>cdLoadThread(<?php echo (int) $thread_id; ?>);<?php endif; ?>
})();
</script>

<?php elseif ( $section === 'track' ):
  // Phase 2: guest-to-account conversion — fall back to email match for
  // bookings made before the customer had an account (user_id=0 at booking
  // time), mirroring the same pattern already used for $my_leads above.
  $track_bookings = $wpdb->get_results($wpdb->prepare(
      "SELECT b.*, li.title AS listing_title FROM {$pfx}bookings b
       LEFT JOIN {$pfx}listings li ON li.id=b.listing_id
       WHERE (b.user_id=%d OR (b.user_id=0 AND b.customer_email=%s AND b.customer_email!=''))
         AND b.status NOT IN ('cancelled') AND b.booking_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
       ORDER BY b.booking_date DESC LIMIT 10", $uid, $user->user_email
  )) ?: [];
?>
<div class="cd-ph"><div><div class="cd-ph-title">📍 Track Your Jobs</div><div class="cd-ph-sub">Live status of recent bookings</div></div></div>
<?php if(empty($track_bookings)):?>
<div class="cd-empty"><div class="cd-empty-icon">📍</div><div class="cd-empty-title">No recent bookings</div><div class="cd-empty-sub">Confirmed bookings from the last 7 days will appear here.</div><a href="<?php echo esc_url(home_url('/directory/'));?>" class="cd-btn cd-btn-primary" style="margin-top:14px">Browse Listings</a></div>
<?php else:?>
<?php foreach($track_bookings as $tb):
  $s_icons=['confirmed'=>'✅','travelling'=>'🚗','arrived'=>'📍','in_progress'=>'🔧','done'=>'🎉'];
  $s_colors=['confirmed'=>'#2563EB','travelling'=>'#D97706','arrived'=>'#7C3AED','in_progress'=>'#059669','done'=>'#059669'];
  $sk=$tb->job_status??$tb->status??'confirmed';
  $si=$s_icons[$sk]??'✅'; $sc=$s_colors[$sk]??'#2563EB';
?>
<div class="cd-card" style="margin-bottom:12px">
  <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
    <div style="font-size:2rem"><?php echo $si;?></div>
    <div style="flex:1">
      <div style="font-weight:700;font-size:.9rem"><?php echo esc_html($tb->listing_title??'Service');?></div>
      <div style="font-size:.78rem;color:#64748B">📅 <?php echo esc_html($tb->booking_date.' '.($tb->booking_time??''));?></div>
    </div>
    <span style="background:<?php echo $sc;?>20;color:<?php echo $sc;?>;border-radius:20px;padding:4px 12px;font-size:.78rem;font-weight:700"><?php echo ucwords(str_replace('_',' ',$sk));?></span>
    <?php if(!empty($tb->tracking_token)):?>
    <a href="<?php echo esc_url(home_url('/track-job/'.esc_attr($tb->tracking_token).'/'));?>" class="cd-btn cd-btn-ghost" style="font-size:.78rem">🔴 Live →</a>
    <?php endif;?>
  </div>
</div>
<?php endforeach;?>
<?php endif;?>

<?php /* ══════════════════════ PROFILE ════════════════════════════════ */ ?>
<?php elseif ( $section === 'profile' ): ?>

<div class="cd-ph">
  <div><div class="cd-ph-title">👤 My Profile</div><div class="cd-ph-sub">Update your account information</div></div>
</div>

<?php if ( isset($_GET['updated']) ): ?>
<div style="background:#F0FDF4;border:1px solid #BBF7D0;color:#15803D;padding:10px 14px;border-radius:8px;margin-bottom:16px;font-size:.84rem;font-weight:600">✅ Profile updated successfully.</div>
<?php endif; ?>

<div class="cd-card">
  <div class="cd-card-title">Account Information</div>
  <form method="POST">
    <?php wp_nonce_field( 'gs_customer_profile_' . $uid, 'gs_customer_profile_nonce' ); ?>
    <div class="cd-form-grid" style="margin-bottom:14px">
      <div class="cd-fg"><label>Full Name</label><input type="text" name="display_name" class="cd-input" value="<?php echo esc_attr($profile_name); ?>" placeholder="Your full name"></div>
      <div class="cd-fg"><label>Email Address</label><input type="email" class="cd-input" value="<?php echo esc_attr($user->user_email); ?>" disabled style="background:#F8FAFC;color:var(--cd-muted)"><div style="font-size:.7rem;color:#94A3B8;margin-top:3px">Email cannot be changed here</div></div>
      <div class="cd-fg"><label>Phone Number</label><input type="tel" name="phone" class="cd-input" value="<?php echo esc_attr($profile_phone); ?>" placeholder="+91 98765 43210"></div>
      <div class="cd-fg"><label>City</label><input type="text" name="city" class="cd-input" value="<?php echo esc_attr($profile_city); ?>" placeholder="Mumbai"></div>
      <div class="cd-fg" style="grid-column:1/-1"><label>Company / Organisation</label><input type="text" name="company" class="cd-input" value="<?php echo esc_attr($profile_company); ?>" placeholder="Optional"></div>
    </div>
    <button type="submit" class="cd-btn cd-btn-primary" style="padding:9px 22px;font-size:.85rem">💾 Save Changes</button>
  </form>
</div>

<div class="cd-card" style="border-color:#FEE2E2">
  <div class="cd-card-title" style="color:#DC2626">⚠️ Delete Account</div>
  <p style="font-size:.83rem;color:var(--cd-muted);margin-bottom:14px">Permanently delete your account and all associated data. This cannot be undone. See the <a href="?section=privacy" style="color:#DC2626;text-decoration:underline">Privacy</a> tab for details on how deletion requests are processed.</p>
  <button class="cd-btn cd-btn-danger" id="cd-profile-delete-btn" onclick="cdProfileRequestDeletion()">🗑 Delete My Account</button>
</div>
<script>
window.cdProfileRequestDeletion = function() {
  if (!confirm('Request deletion of your account and all your data? This cannot be undone and may take up to 30 days to complete.')) return;
  var btn = document.getElementById('cd-profile-delete-btn');
  btn.disabled = true; btn.textContent = 'Submitting…';
  var fd = new FormData();
  fd.append('action', 'gs_request_data_deletion');
  fd.append('nonce', '<?php echo esc_js( wp_create_nonce( "gs_ajax" ) ); ?>');
  fetch('<?php echo esc_js( admin_url( "admin-ajax.php" ) ); ?>', { method: 'POST', body: fd, credentials: 'same-origin' })
    .then(function(r){ return r.json(); })
    .then(function(d){
      if (d && d.success) {
        btn.closest('.cd-card').innerHTML = '<div style="color:#059669;font-weight:700;padding:12px">✅ ' + ((d.data && d.data.message) || 'Deletion request submitted.') + '</div>';
      } else {
        btn.disabled = false; btn.textContent = '🗑 Delete My Account';
        alert((d && d.data && d.data.message) || 'Failed to submit request. Please try again.');
      }
    })
    .catch(function(){ btn.disabled = false; btn.textContent = '🗑 Delete My Account'; alert('Network error. Please try again.'); });
};
</script>

<?php elseif ( $section === 'privacy' ):
  $deletion_requested = get_option( "gs_deletion_requested_{$uid}" );
  $platform_name = gs_setting( 'platform_name', 'GoodService' );
?>
<div class="cd-card">
  <div style="font-size:1rem;font-weight:800;margin-bottom:4px">🔒 Your Privacy & Data Rights</div>
  <div style="font-size:.84rem;color:#64748B;margin-bottom:20px">
    Under India's Digital Personal Data Protection (DPDP) Act, you have the right to access and request deletion of your personal data.
  </div>

  <div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:10px;padding:16px;margin-bottom:16px">
    <div style="font-weight:700;margin-bottom:6px">📥 Download Your Data</div>
    <div style="font-size:.83rem;color:#14532D;margin-bottom:12px">
      Export all your personal data stored on <?php echo esc_html($platform_name); ?> — including your profile, inquiries, bookings, reviews, messages, and invoices — as a JSON file.
    </div>
    <button id="cd-export-btn" class="cd-btn cd-btn-primary" onclick="cdExportData()">⬇ Download My Data</button>
  </div>

  <div style="background:#FEF2F2;border:1px solid #FECACA;border-radius:10px;padding:16px">
    <div style="font-weight:700;margin-bottom:6px;color:#991B1B">🗑 Request Account Deletion</div>
    <div style="font-size:.83rem;color:#7F1D1D;margin-bottom:12px">
      Request permanent deletion of your account and all associated personal data. This cannot be undone.
      <?php if($deletion_requested): ?>
      <br><br><strong>✅ Your deletion request was received on <?php echo date('d M Y', strtotime($deletion_requested)); ?>.</strong>
      We will process it within 30 days and email you at <?php echo esc_html($user->user_email ?? ''); ?> when complete.
      <?php else: ?>
      <br><br>Our team will process your request within 30 days as required by law and notify you by email.
      <?php endif; ?>
    </div>
    <?php if(!$deletion_requested): ?>
    <button id="cd-delete-btn" class="cd-btn" style="background:#DC2626;color:#fff;border:none" onclick="cdRequestDeletion()">Request Account Deletion</button>
    <?php endif; ?>
  </div>
</div>
<script>
window.cdExportData = function() {
  var btn = document.getElementById('cd-export-btn');
  btn.disabled = true; btn.textContent = 'Preparing…';
  var form = document.createElement('form');
  form.method = 'POST';
  form.action = '<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
  [['action','gs_export_my_data'],['nonce','<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>']].forEach(function(p){
    var i=document.createElement('input'); i.type='hidden'; i.name=p[0]; i.value=p[1]; form.appendChild(i);
  });
  document.body.appendChild(form); form.submit(); form.remove();
  setTimeout(function(){ btn.disabled=false; btn.textContent='⬇ Download My Data'; }, 3000);
};
window.cdRequestDeletion = function() {
  if(!confirm('Are you sure you want to request deletion of your account and all your data? This action cannot be undone and may take up to 30 days to complete.')) return;
  var btn = document.getElementById('cd-delete-btn');
  btn.disabled = true; btn.textContent = 'Submitting…';
  var fd = new FormData();
  fd.append('action','gs_request_data_deletion');
  fd.append('nonce','<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>');
  fetch('<?php echo esc_js(admin_url("admin-ajax.php")); ?>', {method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();})
    .then(function(d){
      if(d&&d.success){
        (btn.closest('.cd-card')||btn.closest('div')).innerHTML='<div style="color:#059669;font-weight:700;padding:12px">✅ '+(d.data&&d.data.message||'Deletion request submitted.')+' Refreshing…</div>';
        setTimeout(function(){location.reload();},2500);
      } else {
        btn.disabled=false; btn.textContent='Request Account Deletion';
        alert((d&&d.data&&d.data.message)||'Failed to submit request. Please try again.');
      }
    })
    .catch(function(){ btn.disabled=false; btn.textContent='Request Account Deletion'; alert('Network error. Please try again.'); });
};
</script>

<?php endif; ?>
</div><!-- .cd-wrap -->

<div class="cd-toast" id="cd-toast"></div>

<script>
(function(){
var NONCE = <?php echo wp_json_encode( wp_create_nonce('gs_ajax') ); ?>;
var AJX   = <?php echo wp_json_encode( admin_url('admin-ajax.php') ); ?>;
var LEADS = <?php echo wp_json_encode( $my_leads ); ?>;

function cdToast(msg, ok) {
  var t = document.getElementById('cd-toast');
  t.textContent = msg;
  t.style.display = 'block';
  t.style.background = ok===false ? '#7F1D1D' : '#065F46';
  setTimeout(function(){ t.style.display='none'; }, 3000);
}

// Inquiry list navigation
window.cdShowInq = function(idx) {
  document.querySelectorAll('.cd-inq-item').forEach(function(el){ el.classList.remove('on'); });
  document.querySelectorAll('.cd-inq-detail').forEach(function(el){ el.classList.remove('show'); });
  var item = document.querySelector('.cd-inq-item[data-idx="'+idx+'"]');
  var detail = document.getElementById('cd-inq-detail-'+idx);
  if (item) item.classList.add('on');
  if (detail) {
    detail.classList.add('show');
    // Scroll to bottom of messages
    var scroll = document.getElementById('cd-inq-scroll-'+LEADS[idx].id);
    if (scroll) setTimeout(function(){ scroll.scrollTop = scroll.scrollHeight; }, 50);
  }
};

// Filter inquiry list
window.cdFilterInq = function(q) {
  q = (q||'').toLowerCase();
  document.querySelectorAll('.cd-inq-item').forEach(function(el){
    var v = (el.dataset.vendor||'') + (el.dataset.product||'');
    el.style.display = (!q || v.includes(q)) ? '' : 'none';
  });
};

// Send reply
window.cdSendReply = function(leadId, idx) {
  var ta = document.getElementById('cd-reply-'+leadId);
  var msg = (ta ? ta.value : '').trim();
  if (!msg) return;
  var fd = new FormData();
  fd.append('action','gs_customer_reply_lead');
  fd.append('nonce', NONCE);
  fd.append('lead_id', leadId);
  fd.append('message', msg);
  fetch(AJX,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(d){
    if (d.success) {
      if (ta) ta.value = '';
      var scroll = document.getElementById('cd-inq-scroll-'+leadId);
      if (scroll) {
        var div = document.createElement('div');
        div.style.cssText = 'align-self:flex-end;max-width:80%';
        div.innerHTML = '<div class="cd-msg cd-msg-you">'+d.data.message.replace(/\n/g,'<br>')+'</div><div class="cd-msg-meta" style="text-align:right">You · just now</div>';
        scroll.appendChild(div);
        scroll.scrollTop = scroll.scrollHeight;
      }
      cdToast('Reply sent!');
    } else {
      cdToast(d.data&&d.data.message ? d.data.message : 'Failed to send.', false);
    }
  })
  // Real fix — a network error previously gave zero feedback: the reply
  // box wasn't cleared but nothing told the customer it hadn't sent,
  // indistinguishable from a slow-but-successful send.
  .catch(function(){
    cdToast('Reply not sent — network error. Please try again.', false);
  });
};

// Remove saved listing
window.cdUnsave = function(listingId, btn) {
  var fd = new FormData();
  fd.append('action','gs_save_listing_bookmark');
  fd.append('nonce', NONCE);
  fd.append('listing_id', listingId);
  fetch(AJX,{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(d){
    if (d.success) {
      // Only remove the card if the toggle actually removed the bookmark.
      // Without this check, a race condition (e.g. double-click, or the
      // bookmark already being removed in another tab moments earlier)
      // could cause the toggle to re-save instead — the card would still
      // vanish from the UI even though the listing remains saved.
      if (d.data && d.data.saved === false) {
        var card = btn.closest('.cd-saved-card');
        if (card) card.remove();
        cdToast('Removed from saved.');
      } else {
        cdToast('This listing is saved.');
      }
    }
  })
  // Real fix — a network error previously left the card in place with no
  // feedback at all, giving no indication the unsave click had failed.
  .catch(function(){
    cdToast('Could not update — network error. Please try again.', false);
  });
};

// Inquiry confirmation screen (Part 11.2)
window.cdShowConfirmation = function(inqId, vendorName, category) {
  var el = document.getElementById('cd-inq-confirm');
  if (!el) {
    el = document.createElement('div');
    el.id = 'cd-inq-confirm';
    el.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px';
    el.innerHTML = '<div style="background:#fff;border-radius:16px;padding:32px;max-width:420px;width:100%;text-align:center">' +
      '<div style="font-size:2.5rem;margin-bottom:12px">✅</div>' +
      '<div style="font-weight:800;font-size:1.1rem;color:#1E293B;margin-bottom:6px">Inquiry sent to ' + (vendorName||'vendor') + '!</div>' +
      '<div style="font-size:.84rem;color:#64748B;margin-bottom:4px">Reference: <strong>#INQ-' + String(inqId).padStart(5,'0') + '</strong></div>' +
      '<div style="font-size:.82rem;color:#64748B;margin-bottom:20px">You will receive an email when they reply.</div>' +
      '<a href="?section=inquiries" style="display:inline-block;background:#2563EB;color:#fff;padding:10px 24px;border-radius:9px;font-weight:700;text-decoration:none;font-size:.88rem">View My Inquiries →</a>' +
      '<button onclick="this.closest(\'#cd-inq-confirm\').remove()" style="display:block;margin:12px auto 0;background:none;border:none;font-size:.78rem;color:#94A3B8;cursor:pointer">Dismiss</button>' +
      '</div>';
    document.body.appendChild(el);
  }
  el.style.display = 'flex';
};

// Auto-show if redirect from inquiry submission
(function(){
  var params = new URLSearchParams(window.location.search);
  var inqId = params.get('inquiry_sent');
  if (inqId) window.cdShowConfirmation(inqId);
})();

// Scroll to bottom on load for first inquiry
document.addEventListener('DOMContentLoaded', function(){
  var leads = document.querySelectorAll('.cd-inq-detail.show');
  leads.forEach(function(d){
    var scrollEl = d.querySelector('[id^="cd-inq-scroll-"]');
    if (scrollEl) scrollEl.scrollTop = scrollEl.scrollHeight;
  });
});
})();
</script>
</body></html>
