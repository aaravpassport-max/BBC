<?php
/**
 * GoodService — Vendor Dashboard v6 (Complete, Production-Ready)
 * All 19 sections fully built, wired, tested.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! is_user_logged_in() ) { wp_safe_redirect( home_url( '/vendor/login/' ) ); exit; }
if ( ! gs_is_vendor() && ! gs_is_admin_level() ) { wp_safe_redirect( home_url( '/vendor/login/' ) ); exit; }

$section  = sanitize_text_field( $_GET['section'] ?? 'dashboard' );
$user     = wp_get_current_user();
$vp       = gs_get_vendor_profile();
$sub      = gs_get_active_subscription();
global $wpdb;
$pfx   = $wpdb->prefix . 'gs_';
$uid   = $user->ID;
$vid   = $vp ? (int) $vp->id : 0;
$nonce = wp_create_nonce( 'gs_ajax' );
$_vendor_2fa_enabled = (bool) $wpdb->get_var( $wpdb->prepare(
    "SELECT enabled FROM {$pfx}2fa_settings WHERE user_id = %d", $uid
) );

if ( ! function_exists( 'gs_render_screen_help' ) ) {
    /**
     * Renders a collapsed-by-default "Known Limitations" / "Common Mistakes &
     * Solutions" help accordion at the bottom of a dashboard screen.
     *
     * @param string $screen_label Human-readable screen name shown in the summary.
     * @param array  $limitations  Each: [ title, type (ui|functional|workflow|permission|validation|technical|css|integration), where, why, impact, fix ].
     * @param array  $mistakes     Each: [ mistake, category, see, fix, prevent ].
     * @return string
     */
    function gs_render_screen_help( $screen_label, $limitations = [], $mistakes = [] ) {
        ob_start();
        ?>
        <div class="gs-help-box">
          <details class="gs-help-details">
            <summary class="gs-help-summary">
              <span class="gs-help-summary-icon">❔</span>
              Need Help With This Screen? — Known Limitations &amp; Common Mistakes
              <span class="gs-help-summary-chevron">▾</span>
            </summary>
            <div class="gs-help-body">
              <div>
                <div class="gs-help-h4">⚠️ Known Limitations</div>
                <?php if ( empty( $limitations ) ) : ?>
                  <div class="gs-help-empty">No known limitations verified for this screen.</div>
                <?php else : foreach ( $limitations as $lim ) : ?>
                  <div class="gs-help-item">
                    <div class="gs-help-item-title">
                      <?php echo esc_html( $lim['title'] ?? '' ); ?>
                      <span class="gs-help-tag gs-help-tag-<?php echo esc_attr( $lim['type'] ?? 'functional' ); ?>"><?php echo esc_html( $lim['type'] ?? '' ); ?></span>
                    </div>
                    <dl class="gs-help-dl">
                      <?php if ( ! empty( $lim['where'] ) ) : ?><dt>Where</dt><dd><?php echo esc_html( $lim['where'] ); ?></dd><?php endif; ?>
                      <?php if ( ! empty( $lim['why'] ) ) : ?><dt>Why</dt><dd><?php echo esc_html( $lim['why'] ); ?></dd><?php endif; ?>
                      <?php if ( ! empty( $lim['impact'] ) ) : ?><dt>Impact</dt><dd><?php echo esc_html( $lim['impact'] ); ?></dd><?php endif; ?>
                      <?php if ( ! empty( $lim['fix'] ) ) : ?><dt>Recommended Fix</dt><dd><?php echo esc_html( $lim['fix'] ); ?></dd><?php endif; ?>
                    </dl>
                  </div>
                <?php endforeach; endif; ?>
              </div>
              <div>
                <div class="gs-help-h4">🛠 Common Mistakes &amp; Solutions</div>
                <?php if ( empty( $mistakes ) ) : ?>
                  <div class="gs-help-empty">No common mistakes documented for this screen.</div>
                <?php else : foreach ( $mistakes as $mk ) : ?>
                  <div class="gs-help-item">
                    <div class="gs-help-item-title">
                      <?php echo esc_html( $mk['mistake'] ?? '' ); ?>
                      <span class="gs-help-tag gs-help-tag-mistake"><?php echo esc_html( $mk['category'] ?? '' ); ?></span>
                    </div>
                    <dl class="gs-help-dl">
                      <?php if ( ! empty( $mk['see'] ) ) : ?><dt>What You'll See</dt><dd><?php echo esc_html( $mk['see'] ); ?></dd><?php endif; ?>
                      <?php if ( ! empty( $mk['fix'] ) ) : ?><dt>How To Resolve</dt><dd><?php echo esc_html( $mk['fix'] ); ?></dd><?php endif; ?>
                      <?php if ( ! empty( $mk['prevent'] ) ) : ?><dt>How To Prevent</dt><dd><?php echo esc_html( $mk['prevent'] ); ?></dd><?php endif; ?>
                    </dl>
                  </div>
                <?php endforeach; endif; ?>
              </div>
            </div>
          </details>
        </div>
        <?php
        return ob_get_clean();
    }
}

// ── Primary listing slug for clean URL (replaces /v/ vendor route) ────────
$_vd_primary_url = home_url( '/directory/' ); // fallback
if ( $vp && $vid ) {
    $_vd_primary_slug = $wpdb->get_var( $wpdb->prepare(
        "SELECT slug FROM {$wpdb->prefix}gs_listings
         WHERE vendor_id = %d AND status IN('active','pending')
         ORDER BY is_featured DESC, created_at ASC LIMIT 1",
        $vid
    ) );
    if ( $_vd_primary_slug ) {
        $_vd_primary_url = home_url( '/' . $_vd_primary_slug . '/' );
    }
}

// ── Unified listing form: redirect create/edit to create-listing.php ───────
// Both admin and vendor now use the same /vendor/create/ and /vendor/edit/<id>/
// page (create-listing.php) instead of the old embedded dashboard form.
// This ensures identical UX, identical field set, and the correct two-step
// submit flow (clSave → gs_submit_listing) that fixes the submit-for-review bug.
if ( $section === 'create' ) {
    wp_safe_redirect( home_url( '/vendor/create/' ) );
    exit;
}
if ( $section === 'edit' ) {
    $edit_lid = (int)( $_GET['listing_id'] ?? 0 );
    wp_safe_redirect( $edit_lid
        ? home_url( '/vendor/edit/' . $edit_lid . '/' )
        : home_url( '/vendor/create/' )
    );
    exit;
}

// ── Admin impersonation banner ─────────────────────────────────────────────
// Real fix: now calls the shared, generic renderer instead of hand-writing
// the cookie-detection + banner HTML inline here — see
// gs_render_impersonation_banner() in src/functions.php. Same detection
// logic, same security token/cookie already established, just no longer
// duplicated per dashboard.
gs_render_impersonation_banner(
    $vp->business_name ?? 'this vendor',
    [
        [ 'url' => home_url( '/vendor/create/' ), 'label' => '➕ Create Listing for Vendor' ],
    ]
);
?>
<?php
$vp       = gs_get_vendor_profile(); // re-fetch after possible impersonation setup

// Live counters (nav badges)
$new_leads  = $vid ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d AND status='new'", $vid ) ) : 0;
$unread_msg = $uid  ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(CASE WHEN participant_b=%d THEN unread_b ELSE unread_a END),0) FROM {$pfx}message_threads WHERE participant_a=%d OR participant_b=%d", $uid, $uid, $uid ) ) : 0;
$pend_revs  = $vid  ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$pfx}reviews WHERE vendor_id=%d AND status='pending'", $vid ) ) : 0;
$pend_questions = $vid ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$pfx}listing_questions WHERE vendor_id=%d AND status='pending'", $vid ) ) : 0;
$_notif_unread = $uid ? ( new \GoodService\Repository\NotificationRepository() )->unread_count( $uid ) : 0;
$cats       = $wpdb->get_results( "SELECT id,name,icon_emoji FROM {$pfx}categories WHERE is_active=1 ORDER BY sort_order ASC" );

// Onboarding
$ob = [
	'profile'          => $vp && ! empty( $vp->business_name ) && ! empty( $vp->phone ),
	'listing'          => $vid && (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$pfx}listings WHERE vendor_id=%d", $vid ) ) > 0,
	'inquiry_modules'  => $vid && (bool) $wpdb->get_var( $wpdb->prepare(
	    "SELECT 1 FROM {$pfx}listings WHERE vendor_id=%d AND inquiry_modules_data IS NOT NULL AND inquiry_modules_data != '[]' AND inquiry_modules_data != '' LIMIT 1", $vid
	) ),
	'availability'     => $vid && (bool) $wpdb->get_var( $wpdb->prepare(
	    "SELECT 1 FROM {$pfx}availability av INNER JOIN {$pfx}listings l ON l.id=av.listing_id WHERE l.vendor_id=%d AND av.is_active=1 LIMIT 1", $vid
	) ),
	'live'             => $vid && (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$pfx}listings WHERE vendor_id=%d AND status='active'", $vid ) ) > 0,
];
$ob_pct  = (int) ( array_sum( array_map( 'intval', $ob ) ) / count( $ob ) * 100 );
$ob_done = ! in_array( false, $ob, true );
// Current step = first incomplete step (1-indexed)
$ob_current_step = 1;
foreach ( array_values( $ob ) as $i => $done ) { if ( ! $done ) { $ob_current_step = $i + 1; break; } }
// Saved step from user meta (vendor may have manually advanced)
$ob_saved_step = (int) get_user_meta( get_current_user_id(), 'gs_onboarding_step', true );
if ( $ob_saved_step > $ob_current_step ) { $ob_current_step = $ob_saved_step; }
$ob_done_meta  = (bool) get_user_meta( get_current_user_id(), 'gs_onboarding_done', true );



// Inline upgrade prompt (Part 24.2)
function gs_upgrade_prompt(string $feature_name, string $plan = 'Pro', string $price = '₹499/month', string $section = 'subscription'): string {
    return '<div class="gs-upgrade-prompt" style="background:linear-gradient(135deg,#FFF7ED,#FFFBEB);border:1.5px solid #FDE68A;border-radius:12px;padding:24px;text-align:center;margin:12px 0">
      <div style="font-size:2rem;margin-bottom:8px">👑</div>
      <div style="font-weight:800;font-size:1rem;color:#92400E;margin-bottom:6px">Available on ' . esc_html($plan) . ' Plan</div>
      <div style="font-size:.84rem;color:#B45309;max-width:340px;margin:0 auto 14px">'
        . esc_html($feature_name) . ' is included in the '
        . esc_html($plan) . ' plan (' . esc_html($price) . '). Upgrade to unlock it.</div>
      <a href="?section=' . esc_attr($section) . '" class="gs-btn gs-btn-primary">Upgrade to ' . esc_html($plan) . ' →</a>
    </div>';
}

// Part 17.2 — Staff login detection: check if this user is a staff member (not vendor)
// ENTERPRISE-AUDIT FIX (root-cause dependency found while fixing Part 3's Quick
// Replies finding — that fix requires staff to actually be able to use the
// Messages screen, which surfaced this): two confirmed bugs made this block
// dead for the platform's own default invite path. (1) The trigger condition
// was `! gs_is_vendor( $uid )`, but saveVendorStaff() issues brand-new staff
// accounts the 'gs_vendor' WordPress role itself (so an owner can invite
// someone with no prior WP account at all) — meaning gs_is_vendor($uid) was
// already TRUE for exactly the staff members this block exists to detect,
// so the block never ran for them and $vid stayed 0 (from line 17's
// `$vp ? ... : 0`, since a staff member has no row of their own in
// gs_vendor_profiles). Only a staff member invited via a pre-existing
// non-vendor WP account ever hit this fallback. Now triggers off "this user
// resolved to no vendor profile of their own" ($vid === 0) instead, which
// correctly covers both invite paths and is a no-op for real vendor owners
// (their $vid is already non-zero from line 17, so this block simply never
// runs for them — no behavior change there). (2) Even when the block DID
// run, it called VendorRepository::get_by_user() — which queries
// `WHERE user_id = %d` — but passed it $_staff_record->vendor_id (a
// gs_vendor_profiles.id, not a user_id), so $vp silently resolved to null
// for every staff login this block ever fired for, even though $vid was set
// correctly; any dashboard section reading $vp's fields (business_name,
// email, plan info, etc.) rendered blank for staff. Fixed to
// VendorRepository::get_by_id(), the correct lookup for a vendor_profiles
// primary key.
$_is_staff_login = false;
$_staff_record   = null;
if ( $uid && ! $vid && ! gs_is_admin_level( $uid ) ) {
    $_staff_record = $wpdb->get_row( $wpdb->prepare(
        "SELECT s.*, vp.id AS v_id, vp.business_name AS vendor_bname
         FROM {$pfx}vendor_staff s
         JOIN {$pfx}vendor_profiles vp ON vp.id = s.vendor_id
         WHERE s.user_id = %d AND s.is_active = 1 LIMIT 1",
        $uid
    ) );
    if ( $_staff_record ) {
        $_is_staff_login = true;
        // Override vid to the vendor they work for
        $vid = (int) $_staff_record->v_id;
        $vp  = \GoodService\Repository\VendorRepository::get_by_id( (int) $_staff_record->vendor_id );
    }
}

// Helper: safe field value from object
function gfv( $obj, $field, $default = '' ) {
	if ( ! $obj ) return $default;
	return isset( $obj->$field ) ? $obj->$field : $default;
}
?>
<style>
/* ═══ GoodService Vendor Dashboard 6.0 ═══════════════════════════════ */
:root{--gs-primary:#2563EB;--gs-dark:#1E3A5F;--gs-green:#059669;--gs-red:#DC2626;--gs-gold:#D97706;--gs-purple:#7C3AED;--gs-border:#E2E8F0;--gs-bg:#F8FAFC;--gs-card:#fff;--gs-txt:#1E293B;--gs-muted:#64748B;--gs-font:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif}
*,*::before,*::after{box-sizing:border-box}
.gs-vd,.gs-vd *{font-family:var(--gs-font)}
/* ── Screen Help — Known Limitations / Common Mistakes accordion ────── */
.gs-help-box{margin-top:28px}
.gs-help-details{background:var(--gs-card);border:1px solid var(--gs-border);border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,.04);overflow:hidden}
.gs-help-summary{cursor:pointer;list-style:none;padding:14px 18px;font-weight:700;font-size:.85rem;color:var(--gs-dark);display:flex;align-items:center;gap:8px;user-select:none}
.gs-help-summary::-webkit-details-marker{display:none}
.gs-help-summary-icon{font-size:.95rem}
.gs-help-summary-chevron{margin-left:auto;transition:transform .15s;color:var(--gs-muted)}
.gs-help-details[open] .gs-help-summary-chevron{transform:rotate(180deg)}
.gs-help-body{display:grid;grid-template-columns:1fr 1fr;gap:20px;padding:0 18px 18px;border-top:1px solid var(--gs-bg)}
@media(max-width:900px){.gs-help-body{grid-template-columns:1fr}}
.gs-help-h4{font-size:.78rem;font-weight:800;color:var(--gs-txt);margin:16px 0 10px;text-transform:uppercase;letter-spacing:.03em}
.gs-help-item{background:var(--gs-bg);border:1px solid var(--gs-border);border-radius:9px;padding:11px 13px;margin-bottom:10px}
.gs-help-item-title{font-weight:700;font-size:.8rem;color:var(--gs-txt);display:flex;align-items:center;flex-wrap:wrap;gap:6px}
.gs-help-tag{font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.03em;padding:2px 7px;border-radius:20px;background:#E2E8F0;color:#475569}
.gs-help-tag-ui{background:#EFF6FF;color:#1D4ED8}
.gs-help-tag-functional{background:#F5F3FF;color:#6D28D9}
.gs-help-tag-workflow{background:#FFF7ED;color:#C2410C}
.gs-help-tag-permission{background:#FEF2F2;color:#B91C1C}
.gs-help-tag-validation{background:#FEFCE8;color:#A16207}
.gs-help-tag-technical{background:#F0FDFA;color:#0F766E}
.gs-help-tag-css{background:#FDF4FF;color:#A21CAF}
.gs-help-tag-integration{background:#ECFEFF;color:#0E7490}
.gs-help-tag-mistake{background:#F0FDF4;color:#15803D}
.gs-help-dl{margin:8px 0 0;font-size:.76rem;color:var(--gs-muted);line-height:1.55}
.gs-help-dl dt{font-weight:700;color:#475569;margin-top:6px}
.gs-help-dl dt:first-child{margin-top:0}
.gs-help-dl dd{margin:2px 0 0}
.gs-help-empty{font-size:.78rem;color:var(--gs-muted);font-style:italic;padding:8px 0}
/* ── Top nav ─────────────────────────────────────────────────────── */
.gsvd-wrap{background:var(--gs-dark);position:sticky;top:0;z-index:9999;box-shadow:0 2px 16px rgba(0,0,0,.3)}
.gsvd-bar1{display:flex;align-items:center;justify-content:space-between;height:54px;padding:0 20px;gap:16px}
.gsvd-brand{display:flex;align-items:center;gap:10px;text-decoration:none}
.gsvd-logo{width:38px;height:38px;border-radius:9px;object-fit:cover;flex-shrink:0}
.gsvd-logo-ph{width:38px;height:38px;border-radius:9px;background:rgba(255,255,255,.15);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.95rem;flex-shrink:0}
.gsvd-bname{font-weight:700;color:#fff;font-size:.9rem;line-height:1.1}
.gsvd-bplan{font-size:.6rem;color:rgba(255,255,255,.4)}
.gsvd-acts{display:flex;align-items:center;gap:12px}
.gsvd-acts a{font-size:.72rem;color:rgba(255,255,255,.5);text-decoration:none;transition:.15s}
.gsvd-acts a:hover{color:#fff}
.gsvd-notif-btn{position:relative;background:none;border:none;cursor:pointer;font-size:1.15rem;padding:6px 8px;border-radius:8px;line-height:1;transition:background .15s;margin-right:4px}
.gsvd-notif-btn:hover{background:rgba(255,255,255,.1)}
.gsvd-notif-btn:focus-visible{outline:2px solid #60A5FA;outline-offset:1px}
.gsvd-notif-badge{position:absolute;top:1px;right:1px;font-size:.52rem!important;padding:1px 3px!important;min-width:12px!important;line-height:1.4!important;pointer-events:none}
.gsvd-notif-panel{position:absolute;top:56px;right:14px;width:340px;max-width:calc(100vw - 20px);max-height:420px;background:#fff;border-radius:12px;box-shadow:0 12px 32px rgba(0,0,0,.22);z-index:2000;overflow:hidden;display:flex;flex-direction:column}
.gsvd-notif-panel[hidden]{display:none}
.gsvd-notif-panel-head{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid #EEF2F7;font-weight:700;font-size:.85rem;color:#1E293B;flex-shrink:0}
.gsvd-notif-markall{background:none;border:none;color:#2563EB;font-size:.72rem;font-weight:600;cursor:pointer;padding:2px 4px}
.gsvd-notif-markall:hover{text-decoration:underline}
.gsvd-notif-markall:disabled{color:#CBD5E1;cursor:default;text-decoration:none}
.gsvd-notif-list{overflow-y:auto;flex:1}
.gsvd-notif-loading,.gsvd-notif-empty{padding:32px 16px;text-align:center;color:#94A3B8;font-size:.8rem}
.gsvd-notif-item{display:flex;gap:10px;padding:11px 14px;border-bottom:1px solid #F8FAFC;cursor:pointer;transition:background .12s;text-decoration:none;color:inherit}
.gsvd-notif-item:hover{background:#F8FAFC}
.gsvd-notif-item.unread{background:#EFF6FF}
.gsvd-notif-item.unread:hover{background:#E0EDFF}
.gsvd-notif-ic{flex-shrink:0;width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.85rem}
.gsvd-notif-body{flex:1;min-width:0}
.gsvd-notif-title{font-size:.8rem;font-weight:700;color:#1E293B;margin-bottom:1px}
.gsvd-notif-msg{font-size:.75rem;color:#64748B;line-height:1.35;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.gsvd-notif-time{font-size:.66rem;color:#94A3B8;margin-top:3px}
.gsvd-notif-dot{width:7px;height:7px;border-radius:50%;background:#2563EB;flex-shrink:0;margin-top:5px}
@media(max-width:768px){
  .gsvd-notif-panel{position:fixed;top:52px;right:8px;left:8px;width:auto;max-width:none}
}
.gsvd-row{display:flex;flex-wrap:wrap;align-items:center;border-top:1px solid rgba(255,255,255,.06);padding:2px 10px;background:#152337;gap:1px;overflow-x:auto;scrollbar-width:none}
.gsvd-row::-webkit-scrollbar{display:none}
.gsvd-grp{font-size:.56rem;font-weight:700;color:rgba(255,255,255,.25);text-transform:uppercase;letter-spacing:.1em;padding:4px 5px;flex-shrink:0}
.gsvd-sep{width:1px;height:14px;background:rgba(255,255,255,.09);margin:0 2px;flex-shrink:0}
.gvna{display:inline-flex;align-items:center;gap:3px;padding:5px 8px;border-radius:5px;font-size:.74rem;font-weight:500;color:rgba(255,255,255,.58);text-decoration:none;white-space:nowrap;transition:.12s;flex-shrink:0}
.gvna:hover{background:rgba(255,255,255,.1);color:#fff}
.gvna.on{background:rgba(255,255,255,.17);color:#fff;font-weight:700}
.gvnb{background:#EF4444;color:#fff;border-radius:99px;font-size:.55rem;font-weight:700;padding:1px 4px;min-width:14px;text-align:center;line-height:1.5}
/* ── Body ─────────────────────────────────────────────────────────── */
.gs-vd-body{padding:22px;max-width:1340px;margin:0 auto}
/* ── Onboarding ───────────────────────────────────────────────────── */
.gs-ob{background:linear-gradient(135deg,#1E3A5F,#2563EB);border-radius:14px;padding:22px;margin-bottom:22px;color:#fff}
.gs-ob-steps{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px}
.gs-ob-step{display:flex;align-items:center;gap:10px;background:rgba(255,255,255,.1);border-radius:10px;padding:11px 15px;flex:1;min-width:175px}
.gs-ob-step.done{opacity:.6}
.gs-ob-num{width:26px;height:26px;border-radius:50%;background:rgba(255,255,255,.2);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.78rem;flex-shrink:0}
.gs-ob-step.done .gs-ob-num{background:#10B981}
/* ── Page header ─────────────────────────────────────────────────── */
.gs-ph{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:22px;flex-wrap:wrap}
.gs-ph-title{font-size:1.18rem;font-weight:800;color:var(--gs-dark)}
.gs-ph-sub{font-size:.79rem;color:var(--gs-muted);margin-top:2px}
/* ── Stat grid ───────────────────────────────────────────────────── */
.gs-stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(152px,1fr));gap:12px;margin-bottom:22px}
.gs-sc{background:var(--gs-card);border:1px solid var(--gs-border);border-radius:12px;padding:15px;display:flex;align-items:center;gap:11px}
.gs-sc-icon{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.15rem;flex-shrink:0}
.gs-sc-val{font-size:1.4rem;font-weight:800;line-height:1;color:var(--gs-txt)}
.gs-sc-lbl{font-size:.7rem;color:var(--gs-muted);margin-top:2px}
/* ── Two-column grid ─────────────────────────────────────────────── */
.gs-g2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.gs-g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
/* ── Cards ─────────────────────────────────────────────────────────  */
.gs-card{background:var(--gs-card);border:1px solid var(--gs-border);border-radius:12px;padding:18px;margin-bottom:14px}
.gs-card-title{font-size:.88rem;font-weight:700;color:var(--gs-dark);margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid #F1F5F9}
/* ── Form elements ────────────────────────────────────────────────── */
.gs-fg{margin-bottom:13px}
.gs-lbl{display:block;font-size:.75rem;font-weight:700;color:#475569;margin-bottom:4px}
.gs-req{color:#EF4444}
.gs-inp,.gs-ta,.gs-sel{width:100%;padding:8px 11px;border:1.5px solid var(--gs-border);border-radius:7px;font-size:.85rem;color:var(--gs-txt);outline:none;font-family:var(--gs-font);background:#fff;transition:border .15s}
.gs-inp:focus,.gs-ta:focus,.gs-sel:focus{border-color:var(--gs-primary);box-shadow:0 0 0 3px rgba(37,99,235,.07)}
.gs-inp::placeholder,.gs-ta::placeholder{color:#94A3B8}
.gs-ta{resize:vertical;min-height:74px}
.gs-hint{font-size:.7rem;color:#94A3B8;margin-top:3px}
/* ── Buttons ─────────────────────────────────────────────────────── */
.gs-btn{display:inline-flex;align-items:center;gap:5px;padding:7px 15px;border-radius:7px;font-size:.81rem;font-weight:600;cursor:pointer;border:1.5px solid transparent;transition:all .13s;text-decoration:none;font-family:var(--gs-font);white-space:nowrap}
.gs-btn:disabled{opacity:.5;cursor:not-allowed}
.gs-btn-primary{background:var(--gs-primary);color:#fff;border-color:var(--gs-primary)}
.gs-btn-primary:hover:not(:disabled){background:#1D4ED8}
.gs-btn-green{background:var(--gs-green);color:#fff;border-color:var(--gs-green)}
.gs-btn-green:hover:not(:disabled){background:#047857}
.gs-btn-red{background:var(--gs-red);color:#fff;border-color:var(--gs-red)}
.gs-btn-red:hover:not(:disabled){background:#B91C1C}
.gs-btn-ghost{background:#F1F5F9;color:#334155;border-color:var(--gs-border)}
.gs-btn-ghost:hover:not(:disabled){background:#E2E8F0}
.gs-btn-wa{background:#25D366;color:#fff;border-color:#25D366}
.gs-btn-wa:hover:not(:disabled){background:#1ebe5c}
.gs-btn-sm{padding:5px 11px;font-size:.76rem}
.gs-btn-xs{padding:3px 7px;font-size:.7rem}
.gs-btn-full{width:100%;justify-content:center}
/* ── Badges ─────────────────────────────────────────────────────── */
.gs-badge{display:inline-flex;align-items:center;padding:2px 8px;border-radius:20px;font-size:.67rem;font-weight:700;white-space:nowrap}
.gs-badge-green{background:#ECFDF5;color:var(--gs-green)}
.gs-badge-red{background:#FEF2F2;color:var(--gs-red)}
.gs-badge-gold{background:#FFFBEB;color:var(--gs-gold)}
.gs-badge-blue{background:#EFF6FF;color:var(--gs-primary)}
.gs-badge-grey{background:#F1F5F9;color:#64748B}
.gs-badge-purple{background:#F5F3FF;color:var(--gs-purple)}
/* ── Tables ─────────────────────────────────────────────────────── */
.gs-tbl-wrap{background:#fff;border:1px solid var(--gs-border);border-radius:12px;overflow:hidden;margin-bottom:18px;overflow-x:auto}
.gs-tbl{width:100%;border-collapse:collapse;font-size:.82rem;min-width:640px}
.gs-tbl th{background:#F8FAFC;padding:9px 13px;font-weight:700;color:#475569;text-align:left;font-size:.74rem;border-bottom:1px solid var(--gs-border);white-space:nowrap}
.gs-tbl td{padding:9px 13px;border-bottom:1px solid #F1F5F9;color:#334155;vertical-align:middle}
.gs-tbl tr:last-child td{border-bottom:none}
.gs-tbl tr:hover td{background:#FAFBFC}
/* ── Upload zones ────────────────────────────────────────────────── */
.gs-upload-zone{border:2px dashed #CBD5E1;border-radius:9px;padding:16px;text-align:center;cursor:pointer;transition:all .2s;background:#F8FAFC;display:block;position:relative}
.gs-upload-zone:hover,.gs-upload-zone.dragover{border-color:var(--gs-primary);background:#EFF6FF;border-style:solid}
.gs-upload-zone.dragover{background:#DBEAFE;transform:scale(1.01)}
.gs-upload-zone-txt{font-size:.79rem;color:var(--gs-muted);margin-top:4px}
.gs-drop-hint{font-size:.72rem;color:#94A3B8;margin-top:2px}
/* ── Progress ────────────────────────────────────────────────────── */
.gs-prog-track{background:#E2E8F0;border-radius:99px;height:6px;overflow:hidden;margin:7px 0}
.gs-prog-fill{height:100%;border-radius:99px;background:linear-gradient(90deg,var(--gs-primary),#06B6D4);transition:width .5s ease}
/* ── Quick-stat row ──────────────────────────────────────────────── */
.gs-qs{display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid #F1F5F9;font-size:.79rem}
.gs-qs:last-child{border-bottom:none}
/* ── Repeater ───────────────────────────────────────────────────── */
.gs-rep-item{background:#F8FAFC;border:1px solid var(--gs-border);border-radius:9px;padding:14px;margin-bottom:9px;position:relative}
.gs-rep-rm{position:absolute;top:8px;right:8px;background:#FEF2F2;border:none;color:var(--gs-red);border-radius:5px;width:22px;height:22px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:.85rem;font-weight:700;line-height:1}
.gs-rep-rm:hover{background:var(--gs-red);color:#fff}
/* ── Reviews ────────────────────────────────────────────────────── */
.gs-rev-card{background:#fff;border:1px solid var(--gs-border);border-radius:12px;padding:16px;margin-bottom:11px}
.gs-stars{color:#F59E0B;letter-spacing:1px}
/* ── Empty states ────────────────────────────────────────────────── */
.gs-empty{text-align:center;padding:44px 18px;color:#94A3B8}
.gs-empty-icon{font-size:2.3rem;margin-bottom:11px}
.gs-empty-title{font-size:.93rem;font-weight:700;color:#334155;margin-bottom:5px}
/* ── Step wizard ─────────────────────────────────────────────────── */
.gs-wizard-wrap{overflow-x:auto;scrollbar-width:none;margin:-18px -18px 18px;padding:0 18px;border-bottom:1px solid var(--gs-border);display:flex}
.gs-wizard-wrap::-webkit-scrollbar{display:none}
.gs-step-tab{padding:11px 14px;cursor:pointer;border-bottom:2px solid transparent;font-size:.77rem;font-weight:600;color:var(--gs-muted);white-space:nowrap;transition:.12s;display:flex;align-items:center;gap:5px;flex-shrink:0}
.gs-step-tab.on{border-bottom-color:var(--gs-primary);color:var(--gs-primary)}
.gs-pane{display:none}
.gs-pane.on{display:block}
/* ── Listing type cards ──────────────────────────────────────────── */
.gs-type-opt{border:2px solid var(--gs-border);border-radius:11px;padding:16px;text-align:center;cursor:pointer;transition:all .14s;background:#fff}
.gs-type-opt.on{border-color:var(--gs-primary);background:#EFF6FF}
.gs-type-opt:hover:not(.on){border-color:#93C5FD}
/* ── Inline message ─────────────────────────────────────────────── */
.gs-imsg{padding:9px 14px;border-radius:8px;font-size:.82rem;margin-bottom:12px;display:none}
.gs-imsg.ok{background:#ECFDF5;color:#065F46;display:block}
.gs-imsg.err{background:#FEF2F2;color:#991B1B;display:block}
/* ── Messages ────────────────────────────────────────────────────── */
.gs-msg-grid{display:grid;grid-template-columns:270px 1fr;background:#fff;border:1px solid var(--gs-border);border-radius:12px;overflow:hidden;height:530px}
.gs-msg-list{border-right:1px solid var(--gs-border);overflow-y:auto}
.gs-msg-chat{display:flex;flex-direction:column}
.gs-msg-area{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:8px}
/* ── Plan cards ─────────────────────────────────────────────────── */
.gs-plan-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:16px}
.gs-plan-card{background:#fff;border:2px solid var(--gs-border);border-radius:13px;padding:22px;position:relative;transition:.15s}
.gs-plan-card.on{border-color:var(--gs-primary);box-shadow:0 4px 20px rgba(37,99,235,.12)}
/* ── Gallery grid ────────────────────────────────────────────────── */
.gs-gal-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:10px;margin-bottom:12px}
.gs-gal-thumb{position:relative;aspect-ratio:1;border-radius:8px;overflow:hidden;border:1px solid var(--gs-border)}
.gs-gal-thumb img{width:100%;height:100%;object-fit:cover}
.gs-gal-rm{position:absolute;top:3px;right:3px;background:rgba(220,38,38,.88);border:none;color:#fff;border-radius:4px;width:20px;height:20px;font-size:.7rem;cursor:pointer;display:flex;align-items:center;justify-content:center}
/* ── Responsive ─────────────────────────────────────────────────── */
@media(max-width:900px){.gs-g2{grid-template-columns:1fr}}
@media(max-width:768px){.gs-g3{grid-template-columns:1fr}.gs-stat-grid{grid-template-columns:repeat(2,1fr)}.gs-msg-grid{grid-template-columns:1fr;height:auto}.gs-msg-list{max-height:190px}.gvna{font-size:.68rem;padding:4px 5px}}

/* ══ MOBILE NAV SYSTEM (≤768px) ═══════════════════════════════════
   On mobile the two scrolling nav rows are replaced by:
   1. A compact top bar (logo + business name only)
   2. A fixed 5-tab bottom bar (Home / Inquiries / Messages / Listings / More)
   3. A slide-up "More" drawer listing all remaining sections
   Desktop layout (>768px) is completely untouched.
═══════════════════════════════════════════════════════════════════ */
@media(max-width:768px){

  /* ── Compact top bar ─────────────────────────────────────────── */
  .gsvd-bar1{height:52px;padding:0 14px}
  .gsvd-bname{font-size:.85rem}
  /* Hide "My Vendor Page" and "Logout" text links from top bar —
     they're accessible from the More drawer on mobile */
  .gsvd-acts{display:none}

  /* ── Hide both desktop nav rows ─────────────────────────────── */
  .gsvd-row{display:none!important}

  /* ── Body padding: room for fixed bottom bar ─────────────────── */
  .gs-vd-body{padding:14px 14px 80px}

}/* end @media 768 */

/* ── Bottom Tab Bar ──────────────────────────────────────────────── */
#gsvd-mob-bar{
  display:none; /* JS shows on mobile */
  position:fixed;bottom:0;left:0;right:0;
  z-index:10000;
  background:#0F172A;
  border-top:1px solid rgba(255,255,255,.08);
  padding:0 4px max(8px,env(safe-area-inset-bottom)) 4px;
  box-shadow:0 -4px 20px rgba(0,0,0,.3);
}
#gsvd-mob-bar nav{
  display:grid;grid-template-columns:repeat(5,1fr);gap:0;
}
.gsmb-tab{
  display:flex;flex-direction:column;align-items:center;
  gap:3px;padding:8px 4px 4px;
  text-decoration:none;color:rgba(255,255,255,.38);
  font-size:.58rem;font-weight:600;letter-spacing:.02em;
  transition:color .15s;cursor:pointer;
  border:none;background:none;font-family:var(--gs-font);
  position:relative;
}
.gsmb-tab:hover,.gsmb-tab.on{color:#fff}
.gsmb-tab.on::after{
  content:'';position:absolute;top:0;left:25%;right:25%;
  height:2px;background:#3B82F6;border-radius:0 0 3px 3px;
}
.gsmb-tab-ico{font-size:1.25rem;line-height:1;position:relative}
.gsmb-badge{
  position:absolute;top:-3px;right:-7px;
  background:#EF4444;color:#fff;
  border-radius:99px;font-size:.5rem;font-weight:800;
  padding:1px 4px;min-width:14px;text-align:center;line-height:1.5;
}
.gsmb-tab-more .gsmb-tab-ico{
  width:28px;height:28px;border-radius:8px;
  background:rgba(255,255,255,.1);
  display:flex;align-items:center;justify-content:center;
  font-size:.95rem;transition:background .15s;
}
.gsmb-tab-more.open .gsmb-tab-ico{background:rgba(59,130,246,.3)}
.gsmb-tab-more.open{color:#60A5FA}

/* ── More Drawer (slide-up full-screen sheet) ────────────────────── */
#gsvd-mob-drawer{
  display:none;
  position:fixed;inset:0;
  z-index:9999;
  pointer-events:none;
}
#gsvd-mob-drawer.open{display:block;pointer-events:auto}

/* Backdrop */
#gsvd-mob-drawer-backdrop{
  position:absolute;inset:0;
  background:rgba(0,0,0,.6);
  opacity:0;transition:opacity .25s;
  backdrop-filter:blur(2px);
}
#gsvd-mob-drawer.open #gsvd-mob-drawer-backdrop{opacity:1}

/* Sheet */
#gsvd-mob-drawer-sheet{
  position:absolute;bottom:0;left:0;right:0;
  background:#0F172A;
  border-radius:20px 20px 0 0;
  padding:0 0 max(20px,env(safe-area-inset-bottom)) 0;
  transform:translateY(100%);
  transition:transform .3s cubic-bezier(.4,0,.2,1);
  max-height:85vh;
  overflow-y:auto;
  scrollbar-width:none;
}
#gsvd-mob-drawer-sheet::-webkit-scrollbar{display:none}
#gsvd-mob-drawer.open #gsvd-mob-drawer-sheet{transform:translateY(0)}

/* Drag handle */
#gsvd-mob-drawer-sheet::before{
  content:'';display:block;
  width:40px;height:4px;border-radius:2px;
  background:rgba(255,255,255,.15);
  margin:12px auto 16px;
}

/* Drawer header */
.gsmd-hd{
  display:flex;align-items:center;justify-content:space-between;
  padding:0 18px 14px;
  border-bottom:1px solid rgba(255,255,255,.07);
  margin-bottom:4px;
}
.gsmd-hd-title{
  font-size:.8rem;font-weight:700;color:rgba(255,255,255,.5);
  text-transform:uppercase;letter-spacing:.1em;
}
.gsmd-hd-user{
  display:flex;align-items:center;gap:8px;
}
.gsmd-user-name{font-size:.82rem;font-weight:700;color:#fff}
.gsmd-user-plan{font-size:.65rem;color:rgba(255,255,255,.4)}

/* Section groups inside drawer */
.gsmd-grp{padding:10px 18px 4px;font-size:.58rem;font-weight:700;
  color:rgba(255,255,255,.28);text-transform:uppercase;letter-spacing:.1em}

/* Item grid inside drawer */
.gsmd-grid{
  display:grid;grid-template-columns:repeat(3,1fr);
  gap:4px;padding:0 10px 8px;
}
.gsmd-item{
  display:flex;flex-direction:column;align-items:center;
  gap:5px;padding:13px 8px 11px;
  border-radius:12px;
  text-decoration:none;
  background:rgba(255,255,255,.04);
  border:1px solid rgba(255,255,255,.05);
  transition:background .15s,border-color .15s;
  position:relative;
}
.gsmd-item:hover{background:rgba(255,255,255,.09)}
.gsmd-item.on{
  background:rgba(59,130,246,.18);
  border-color:rgba(59,130,246,.35);
}
.gsmd-item-ico{font-size:1.4rem;line-height:1}
.gsmd-item-lbl{
  font-size:.6rem;font-weight:600;color:rgba(255,255,255,.65);
  text-align:center;line-height:1.3;
}
.gsmd-item.on .gsmd-item-lbl{color:#fff;font-weight:700}
.gsmd-item-badge{
  position:absolute;top:7px;right:10px;
  background:#EF4444;color:#fff;
  border-radius:99px;font-size:.5rem;font-weight:800;
  padding:1px 4px;min-width:13px;text-align:center;
}

/* Utility links row at bottom of drawer */
.gsmd-utils{
  display:flex;align-items:center;gap:6px;
  padding:12px 10px 0;
  border-top:1px solid rgba(255,255,255,.07);
  margin-top:4px;
}
.gsmd-util-btn{
  flex:1;display:flex;align-items:center;justify-content:center;gap:6px;
  padding:10px 8px;border-radius:10px;
  font-size:.72rem;font-weight:600;text-decoration:none;
  background:rgba(255,255,255,.06);
  border:1px solid rgba(255,255,255,.08);
  color:rgba(255,255,255,.6);transition:background .15s;
}
.gsmd-util-btn:hover{background:rgba(255,255,255,.12);color:#fff}
.gsmd-util-btn.vendor-page{background:rgba(37,99,235,.2);border-color:rgba(59,130,246,.3);color:#93C5FD}
</style>
<div class="gs-vd" id="gs-vendor-app">
<!-- ══ TOP NAV ═════════════════════════════════════════════════════════ -->
<div class="gsvd-wrap">
  <div class="gsvd-bar1">
    <a href="?section=dashboard" class="gsvd-brand">
      <?php if ( $vp && $vp->logo_url ): ?>
        <img src="<?php echo esc_url( $vp->logo_url ); ?>" class="gsvd-logo" alt="logo">
      <?php else: ?>
        <div class="gsvd-logo-ph"><?php echo esc_html( strtoupper( substr( $user->display_name, 0, 1 ) ) ); ?></div>
      <?php endif; ?>
      <div>
        <div class="gsvd-bname"><?php echo esc_html( $vp->business_name ?? $user->display_name ); ?></div>
        <div class="gsvd-bplan"><?php echo esc_html( $sub->plan_name ?? 'Free Plan' ); ?></div>
      </div>
    </a>
    <button type="button" id="gsvd-notif-btn" class="gsvd-notif-btn" aria-label="Notifications<?php echo $_notif_unread ? ' (' . $_notif_unread . ' unread)' : ''; ?>" aria-haspopup="true" aria-expanded="false">
      🔔<?php if ( $_notif_unread ): ?><span class="gvnb gsvd-notif-badge"><?php echo $_notif_unread > 99 ? '99+' : $_notif_unread; ?></span><?php endif; ?>
    </button>
    <div class="gsvd-acts">
      <?php if ( $vp && ! empty( $vp->slug ) ): ?>
        <a href="<?php echo esc_url( $_vd_primary_url ); ?>" target="_blank">🌐 My Vendor Page</a>
      <?php endif; ?>
      <a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>">Logout</a>
    </div>
  </div>

  <!-- ── Notification dropdown panel — hidden by default, toggled by gsvd-notif-btn ── -->
  <div id="gsvd-notif-panel" class="gsvd-notif-panel" role="menu" aria-label="Notifications" hidden>
    <div class="gsvd-notif-panel-head">
      <span>Notifications</span>
      <button type="button" id="gsvd-notif-markall" class="gsvd-notif-markall">Mark all read</button>
    </div>
    <div id="gsvd-notif-list" class="gsvd-notif-list">
      <div class="gsvd-notif-loading">Loading…</div>
    </div>
  </div>

  <!-- Row 1: Business sections -->
  <div class="gsvd-row">
    <span class="gsvd-grp">Main</span>
    <a href="?section=dashboard"    class="gvna <?php echo $section === 'dashboard'   ? 'on' : ''; ?>">📊 Dashboard</a>
    <div class="gsvd-sep"></div>
    <span class="gsvd-grp">Business</span>
    <a href="?section=profile"      class="gvna <?php echo $section === 'profile'     ? 'on' : ''; ?>">👤 Profile</a>
    <a href="?section=listings"     class="gvna <?php echo $section === 'listings'    ? 'on' : ''; ?>">🏢 Listings</a>
    <a href="?section=inquiry_modules" class="gvna <?php echo $section === 'inquiry_modules' ? 'on' : ''; ?>">📝 Inquiry &amp; Booking</a>
    <a href="<?php echo home_url('/vendor/create/'); ?>"       class="gvna <?php echo in_array( $section, ['create','edit'] ) ? 'on' : ''; ?>">➕ Add Listing</a>
    <a href="?section=products"     class="gvna <?php echo $section === 'products'    ? 'on' : ''; ?>">📦 Products</a>
    <a href="?section=services"     class="gvna <?php echo $section === 'services'    ? 'on' : ''; ?>">🛠 Services</a>
    <div class="gsvd-sep"></div>
    <span class="gsvd-grp">Customers</span>
    <a href="?section=leads"        class="gvna <?php echo $section === 'leads'       ? 'on' : ''; ?>">
      📬 Inquiries <?php if ( $new_leads ): ?><span class="gvnb"><?php echo $new_leads; ?></span><?php endif; ?>
    </a>
    <a href="?section=reviews"      class="gvna <?php echo $section === 'reviews'     ? 'on' : ''; ?>">
      ⭐ Reviews <?php if ( $pend_revs ): ?><span class="gvnb"><?php echo $pend_revs; ?></span><?php endif; ?>
    </a>
    <a href="?section=questions"    class="gvna <?php echo $section === 'questions'   ? 'on' : ''; ?>">
      ❓ Questions <?php if ( $pend_questions ): ?><span class="gvnb"><?php echo $pend_questions; ?></span><?php endif; ?>
    </a>
    <a href="?section=messages"     class="gvna <?php echo $section === 'messages'    ? 'on' : ''; ?>">
      💬 Messages <?php if ( $unread_msg ): ?><span class="gvnb"><?php echo $unread_msg; ?></span><?php endif; ?>
    </a>
    <?php if ( gs_setting( 'booking_enabled', '0' ) ): ?>
    <a href="?section=bookings"     class="gvna <?php echo $section === 'bookings'    ? 'on' : ''; ?>">📅 Bookings</a>
    <?php endif; ?>
    <?php if ( gs_setting( 'reverse_req_enabled', '1' ) ): ?>
    <a href="?section=requirements" class="gvna <?php echo $section === 'requirements' ? 'on' : ''; ?>">📋 Requirements</a>
    <?php endif; ?>
  </div>

  <!-- Row 2: Account sections -->
  <div class="gsvd-row">
    <span class="gsvd-grp">Billing</span>
    <a href="?section=subscription" class="gvna <?php echo $section === 'subscription' ? 'on' : ''; ?>">💳 Subscription &amp; Payment</a>
    <a href="?section=invoices"     class="gvna <?php echo $section === 'invoices'     ? 'on' : ''; ?>">🧾 Invoices &amp; Receipts</a>
    <span class="gsvd-grp">Account</span>
    <?php if ( $sub && $sub->show_analytics ): ?>
    <a href="?section=analytics"    class="gvna <?php echo $section === 'analytics'    ? 'on' : ''; ?>">📈 Analytics</a>
    <?php endif; ?>
    <a href="?section=verification" class="gvna <?php echo $section === 'verification' ? 'on' : ''; ?>">✅ Verification</a>
    <a href="?section=seo"          class="gvna <?php echo $section === 'seo'          ? 'on' : ''; ?>">🔍 SEO</a>
    <a href="?section=staff"        class="gvna <?php echo $section === 'staff'        ? 'on' : ''; ?>">👥 My Team</a>
    <a href="?section=quick_replies" class="gvna <?php echo $section === 'quick_replies' ? 'on' : ''; ?>">⚡ Quick Replies</a>
    <a href="?section=templates"    class="gvna <?php echo $section === 'templates'    ? 'on' : ''; ?>">📝 Templates</a>
    <a href="?section=availability" class="gvna <?php echo $section === 'availability' ? 'on' : ''; ?>">🗓 Availability</a>
    <a href="?section=calendar"     class="gvna <?php echo $section === 'calendar'     ? 'on' : ''; ?>">📅 Calendar</a>
    <a href="?section=service_plans" class="gvna <?php echo $section === 'service_plans' ? 'on' : ''; ?>">🔄 Service Plans</a>
    <a href="?section=promotions"   class="gvna <?php echo $section === 'promotions'   ? 'on' : ''; ?>">🎉 Promotions</a>
    <a href="?section=notifications" class="gvna <?php echo $section === 'notifications' ? 'on' : ''; ?>">🔔 Notifications</a>
    <a href="?section=wa_analytics" class="gvna <?php echo $section === 'wa_analytics' ? 'on' : ''; ?>">📊 WA Analytics</a>
    <a href="?section=whatsapp"     class="gvna <?php echo $section === 'whatsapp'     ? 'on' : ''; ?>">📱 WhatsApp</a>
    <a href="?section=staff_performance" class="gvna <?php echo $section === 'staff_performance' ? 'on' : ''; ?>">📊 Team Stats</a>
    <a href="?section=complaints"   class="gvna <?php echo $section === 'complaints'   ? 'on' : ''; ?>">⚠ Complaints</a>
  </div>
</div>

<!-- ══ BODY ═════════════════════════════════════════════════════════════ -->
<div class="gs-vd-body">

<?php if ( ! $ob_done_meta && ! $ob_done && in_array( $section, ['dashboard','listings','create','profile','inquiry_modules','availability'] ) ): ?>
<div class="gs-ob" id="gs-ob-wizard">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
    <div>
      <div style="font-weight:800;font-size:1rem">🚀 Getting Started — <?php echo $ob_pct; ?>% complete</div>
      <div style="font-size:.76rem;opacity:.7;margin-top:2px">Complete setup to unlock your 14-day Pro trial</div>
    </div>
    <button onclick="gsObDismiss()" style="background:rgba(255,255,255,.15);border:none;color:#fff;border-radius:8px;padding:5px 12px;font-size:.74rem;cursor:pointer;opacity:.7">Skip for now</button>
  </div>
  <div class="gs-prog-track" style="margin-bottom:16px"><div class="gs-prog-fill" style="width:<?php echo $ob_pct; ?>%"></div></div>

  <?php
  $ob_steps = [
    1 => [
      'title'  => 'Complete your profile',
      'desc'   => 'Add your business name, phone, address, and a profile photo so customers know who they\'re booking.',
      'cta'    => 'Set up profile →',
      'url'    => '?section=profile',
      'done'   => $ob['profile'],
      'icon'   => '👤',
    ],
    2 => [
      'title'  => 'Create your first listing',
      'desc'   => 'Add your service listing — name, category, city, description, and photos. This is your storefront.',
      'cta'    => 'Create listing →',
      'url'    => '?section=create',
      'done'   => $ob['listing'],
      'icon'   => '🏢',
    ],
    3 => [
      'title'  => 'Configure inquiry modules',
      'desc'   => 'Set up service-specific inquiry forms so customers give you the right information when they reach out.',
      'cta'    => 'Configure modules →',
      'url'    => '?section=inquiry_modules',
      'done'   => $ob['inquiry_modules'],
      'icon'   => '📝',
    ],
    4 => [
      'title'  => 'Set your availability',
      'desc'   => 'Add your weekly schedule and any blocked dates so customers can book real slots directly.',
      'cta'    => 'Set availability →',
      'url'    => '?section=availability',
      'done'   => $ob['availability'],
      'icon'   => '🗓',
    ],
    5 => [
      'title'  => 'Get approved & go live',
      'desc'   => 'Submit your listing for admin review. Once approved it\'ll appear in search — customers can find and book you.',
      'cta'    => 'View my listings →',
      'url'    => '?section=listings',
      'done'   => $ob['live'],
      'icon'   => '✅',
    ],
  ];
  foreach ( $ob_steps as $step_num => $step ):
    $is_active = ( $step_num === $ob_current_step ) && ! $step['done'];
    $is_done   = $step['done'];
    $is_locked = ! $is_done && ! $is_active;
  ?>
  <div class="gs-ob-step <?php echo $is_done ? 'done' : ''; ?>"
       style="<?php echo $is_active ? 'background:rgba(255,255,255,.18);border:1.5px solid rgba(255,255,255,.4);' : ''; ?>cursor:<?php echo $is_locked ? 'default' : 'pointer'; ?>"
       <?php if ( ! $is_locked && ! $is_done ): ?>onclick="window.location.href='<?php echo esc_js($step['url']); ?>'"<?php endif; ?>>
    <div class="gs-ob-num" style="<?php echo $is_done ? 'background:#10B981' : ($is_active ? 'background:#2563EB;box-shadow:0 0 0 3px rgba(255,255,255,.4)' : ''); ?>">
      <?php echo $is_done ? '✓' : ( $is_active ? $step_num : $step_num ); ?>
    </div>
    <div style="flex:1;min-width:0">
      <div style="font-size:.84rem;font-weight:700;<?php echo $is_done ? 'opacity:.6' : ''; ?>"><?php echo $step['icon']; ?> <?php echo esc_html($step['title']); ?></div>
      <?php if ( $is_active ): ?>
      <div style="font-size:.76rem;opacity:.85;margin-top:3px;line-height:1.4"><?php echo esc_html($step['desc']); ?></div>
      <?php endif; ?>
    </div>
    <?php if ( $is_active ): ?>
    <a href="<?php echo esc_attr($step['url']); ?>"
       onclick="gsObStep(<?php echo $step_num; ?>)"
       class="gs-btn gs-btn-sm"
       style="background:#fff;color:#1E3A5F;font-weight:700;border:none;flex-shrink:0;white-space:nowrap">
      <?php echo esc_html($step['cta']); ?>
    </a>
    <?php elseif ( $is_done ): ?>
    <span style="font-size:.8rem;opacity:.6">Done</span>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>

  <?php if ( $ob_pct >= 100 || $ob_done ): ?>
  <div style="text-align:center;margin-top:12px;padding:10px;background:rgba(255,255,255,.1);border-radius:8px;font-size:.84rem">
    🎉 Setup complete! <button onclick="gsObComplete()" style="background:#10B981;color:#fff;border:none;border-radius:6px;padding:5px 14px;font-size:.8rem;font-weight:700;cursor:pointer;margin-left:8px">Claim 14-day Pro Trial</button>
  </div>
  <?php endif; ?>
</div>
<script>
function gsObStep(s){gsPost('gs_update_onboarding_step',{step:s,nonce:'<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>'},function(){},function(){});}
function gsObDismiss(){document.getElementById('gs-ob-wizard').style.display='none';gsPost('gs_mark_onboarding_done',{nonce:'<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>'},function(){},function(){});}
function gsObComplete(){
  gsPost('gs_mark_onboarding_done',{nonce:'<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>'},
    function(){gsToast('🎉 14-day Pro trial activated! Enjoy all Pro features.','success');setTimeout(function(){location.reload();},1500);},
    function(m){gsToast(m||'Failed','error');}
  );
}
</script>
<?php elseif ( ! $ob_done_meta && $ob_done ): ?>
<div class="gs-ob" style="background:linear-gradient(135deg,#059669,#10B981)" id="gs-ob-wizard">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
    <div>
      <div style="font-weight:800;font-size:1rem">🎉 Setup Complete!</div>
      <div style="font-size:.8rem;opacity:.8;margin-top:3px">Claim your free 14-day Pro trial — unlocks analytics, featured placement, and more.</div>
    </div>
    <button onclick="gsObComplete()" style="background:#fff;color:#059669;border:none;border-radius:8px;padding:8px 18px;font-size:.84rem;font-weight:800;cursor:pointer">Claim Pro Trial →</button>
  </div>
</div>
<script>
function gsObComplete(){
  gsPost('gs_mark_onboarding_done',{nonce:'<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>'},
    function(){gsToast('🎉 Pro trial activated!','success');setTimeout(function(){location.reload();},1500);},
    function(m){gsToast(m||'Failed','error');}
  );
}
</script>
<?php endif; ?>
<?php
// Part 17.2 — Staff restriction: redirect to allowed sections only
if ( $_is_staff_login && $_staff_record && ! in_array( $section, ['leads','bookings','profile','dashboard'], true ) ) {
    $section = 'leads';
}
?>
<?php if($_is_staff_login && $_staff_record): ?>
<div style="background:linear-gradient(135deg,#1E3A5F,#2563EB);color:#fff;padding:10px 20px;border-radius:10px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between">
  <div>
    <div style="font-weight:700;font-size:.9rem">👤 Staff View — <?php echo esc_html($_staff_record->name); ?></div>
    <div style="font-size:.76rem;opacity:.8">Working for <?php echo esc_html($_staff_record->vendor_bname); ?></div>
  </div>
  <div style="font-size:.72rem;opacity:.7">Access: Inquiries &amp; Bookings only</div>
</div>
<?php endif; ?>
<?php switch ( $section ):

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: DASHBOARD
// ══════════════════════════════════════════════════════════════════════════════
case 'dashboard': default:
  $active_count = $vid ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$pfx}listings WHERE vendor_id=%d AND status='active'", $vid ) ) : 0;
  // Onboarding gap fix: the default dashboard is the first screen a vendor
  // sees after registration (see AjaxController::registerVendor()'s redirect),
  // but previously had zero indication a listing needed to be created —
  // just four zero-value stat cards and a "Copy Listing Link" button that
  // copied the homepage URL since no listing existed yet. Gated on ANY
  // listing (not just active) so a vendor with a pending/draft submission
  // already in progress doesn't see a misleading "create your first" prompt.
  $total_listing_count = $vid ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$pfx}listings WHERE vendor_id=%d AND status != 'deleted'", $vid ) ) : 0;
  $total_leads  = $vid ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d", $vid ) ) : 0;
  $total_views  = $vid ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(views_count),0) FROM {$pfx}listings WHERE vendor_id=%d", $vid ) ) : 0;
  $avg_rating   = $vid ? (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(AVG(rating),0) FROM {$pfx}reviews WHERE vendor_id=%d AND status='approved'", $vid ) ) : 0;
  $ts           = gs_calculate_trust_score( $uid );
?>
<?php if ( $total_listing_count === 0 ): ?>
<div class="gs-card" style="background:linear-gradient(135deg,#2563EB,#1E3A8A);color:#fff;margin-bottom:16px;padding:22px">
  <div style="font-size:1.4rem;margin-bottom:6px">👋 Welcome to <?php echo esc_html( gs_setting('platform_name','GoodService') ); ?>!</div>
  <div style="opacity:.92;font-size:.9rem;margin-bottom:16px;max-width:520px">You're one step away from getting your first customer. Create your listing to appear in the directory and start receiving inquiries.</div>
  <a href="<?php echo home_url('/vendor/create/'); ?>" class="gs-btn" style="background:#fff;color:#1E3A8A;font-weight:700">➕ Create Your First Listing</a>
</div>
<?php endif;
// ENTERPRISE-AUDIT FIX (Part 3, High: "No billing self-service... no
// proactive usage-cap warning before a limit is hit"). Deliberately
// re-runs SubscriptionService::check_listing_limit()'s own WHERE clause
// (status NOT IN ('draft','rejected')) rather than reusing
// $total_listing_count above, which counts everything except 'deleted' —
// a looser count that would disagree with the actual enforcement point and
// could warn (or fail to warn) at the wrong number. Unlimited plans
// (max_listings == -1) never show this. Shown at >=80% usage (amber) and
// at-or-over the limit (red, matches the enforcement point exactly).
$_cap_limit = $sub ? (int) $sub->max_listings : 1;
if ( $vid && $_cap_limit > 0 ) {
  $_cap_count = (int) $wpdb->get_var( $wpdb->prepare(
    "SELECT COUNT(*) FROM {$pfx}listings WHERE vendor_id=%d AND status NOT IN ('draft','rejected')", $vid
  ) );
  $_cap_pct = $_cap_count / $_cap_limit;
  if ( $_cap_pct >= 0.8 ) {
    $_cap_at_limit = $_cap_count >= $_cap_limit;
    ?>
    <div class="gs-card" style="margin-bottom:16px;padding:16px 20px;border-left:4px solid <?php echo $_cap_at_limit ? '#DC2626' : '#D97706'; ?>;background:<?php echo $_cap_at_limit ? '#FEF2F2' : '#FFFBEB'; ?>">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
        <div>
          <div style="font-weight:700;font-size:.88rem;color:<?php echo $_cap_at_limit ? '#991B1B' : '#92400E'; ?>">
            <?php echo $_cap_at_limit ? '⛔ Listing limit reached' : '⚠️ Approaching your listing limit'; ?>
          </div>
          <div style="font-size:.8rem;color:#64748B;margin-top:2px">
            You're using <?php echo $_cap_count; ?> of <?php echo $_cap_limit; ?> listings on your <?php echo esc_html( $sub->plan_name ?? 'current' ); ?> plan.
            <?php echo $_cap_at_limit ? 'Upgrade to add more listings.' : 'Upgrade now to avoid being blocked when you need to add one more.'; ?>
          </div>
        </div>
        <a href="?section=subscription" class="gs-btn gs-btn-sm <?php echo $_cap_at_limit ? 'gs-btn-primary' : 'gs-btn-ghost'; ?>">Upgrade Plan →</a>
      </div>
    </div>
    <?php
  }
}
?>
<?php
// Part 4.1 — Today's summary cards
$today_leads    = $vid ? (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d AND DATE(created_at)=CURDATE()", $vid)) : 0;
$pending_replies= $vid ? (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d AND status IN ('new','viewed')", $vid)) : 0;
$today_bookings = $vid ? (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}bookings WHERE vendor_id=%d AND DATE(booking_date)=CURDATE() AND status='confirmed'", $vid)) : 0;
$pipeline_val   = $vid ? (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total),0) FROM {$pfx}quotations WHERE vendor_id=%d AND status='sent'", $vid)) : 0;
?>
<div class="gs-ph">
  <div>
    <div class="gs-ph-title">📊 Dashboard</div>
    <div class="gs-ph-sub"><?php echo date('l, d F Y'); ?> · Welcome back, <?php echo esc_html(explode(' ', $vp->business_name ?? 'Vendor')[0]); ?>!</div>
  </div>
</div>

<!-- Today's summary (Part 4.1) -->
<div class="gs-stat-grid" style="margin-bottom:14px">
  <div class="gs-sc" style="border:1.5px solid <?php echo $today_leads>0?'#BFDBFE':'#E2E8F0'; ?>">
    <div class="gs-sc-icon" style="background:#EFF6FF">📞</div>
    <div><div class="gs-sc-val" style="color:#2563EB"><?php echo $today_leads; ?></div><div class="gs-sc-lbl">Leads Today</div></div>
  </div>
  <div class="gs-sc" style="border:1.5px solid <?php echo $pending_replies>0?'#FECACA':'#E2E8F0'; ?>">
    <div class="gs-sc-icon" style="background:<?php echo $pending_replies>0?'#FEF2F2':'#F8FAFC'; ?>">
      <?php echo $pending_replies>0?'🔴':'✅'; ?>
    </div>
    <div><div class="gs-sc-val" style="color:<?php echo $pending_replies>0?'#DC2626':'#059669'; ?>"><?php echo $pending_replies; ?></div><div class="gs-sc-lbl">Pending Replies</div></div>
  </div>
  <div class="gs-sc">
    <div class="gs-sc-icon" style="background:#F0FDF4">📅</div>
    <div><div class="gs-sc-val" style="color:#059669"><?php echo $today_bookings; ?></div><div class="gs-sc-lbl">Today's Bookings</div></div>
  </div>
  <div class="gs-sc">
    <div class="gs-sc-icon" style="background:#F5F3FF">💰</div>
    <div><div class="gs-sc-val" style="color:#7C3AED;font-size:1.1rem"><?php echo $pipeline_val>0?'₹'.number_format($pipeline_val):'—'; ?></div><div class="gs-sc-lbl">Open Quotes</div></div>
  </div>
</div>

<!-- Quick actions (Part 4.1) -->
<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px">
  <a href="?section=leads&filter=new" class="gs-btn gs-btn-primary">📞 Reply to Inquiries <?php if($pending_replies>0):?><span style="background:rgba(255,255,255,.3);border-radius:10px;padding:1px 7px;font-size:.75rem"><?php echo $pending_replies;?></span><?php endif;?></a>
  <a href="?section=leads" class="gs-btn gs-btn-ghost">📋 View All Inquiries</a>
  <a href="?section=bookings" class="gs-btn gs-btn-ghost">📅 Today's Bookings</a>
  <button onclick="navigator.clipboard?.writeText('<?php echo esc_js(home_url('/')); ?>').then(()=>gsToast('Listing link copied!','success'))" class="gs-btn gs-btn-ghost">🔗 Copy Listing Link</button>
</div>
<div class="gs-stat-grid">
  <?php foreach ( [
    ['Active Listings', $active_count, '🏢', '#EFF6FF', '#2563EB'],
    ['New Leads',       $new_leads,    '📞', '#FEF2F2', '#DC2626'],
    ['Total Views',     number_format($total_views), '👁', '#F0FDF4', '#059669'],
    ['Total Leads',     $total_leads,  '📊', '#F5F3FF', '#7C3AED'],
    ['Avg Rating',      $avg_rating > 0 ? number_format($avg_rating,1).' ⭐' : '—', '⭐', '#FFFBEB', '#D97706'],
    ['Trust Score',     $ts.'/100',    '🛡️', '#F0FDF4', '#059669'],
  ] as $s ): ?>
  <div class="gs-sc">
    <div class="gs-sc-icon" style="background:<?php echo $s[3]; ?>"><?php echo $s[2]; ?></div>
    <div><div class="gs-sc-val" style="color:<?php echo $s[4]; ?>"><?php echo $s[1]; ?></div><div class="gs-sc-lbl"><?php echo $s[0]; ?></div></div>
  </div>
  <?php endforeach; ?>
</div>

<div class="gs-card" id="gs-quality-widget" style="margin-top:16px;display:none">
  <div class="gs-card-title">✅ Profile &amp; Listing Quality <span id="gs-quality-pct" style="font-weight:400;font-size:.85rem;color:#94A3B8"></span></div>
  <div id="gs-quality-bar-track" style="background:#F1F5F9;border-radius:8px;height:8px;overflow:hidden;margin-bottom:14px">
    <div id="gs-quality-bar-fill" style="background:#059669;height:100%;width:0%;transition:width .4s"></div>
  </div>
  <div id="gs-quality-steps" style="display:flex;flex-direction:column;gap:0"></div>
</div>
<script>
(function(){
  var widget = document.getElementById('gs-quality-widget');
  if (!widget) return;
  var fd = new FormData();
  fd.append('action', 'gs_enh_get_quality_checklist');
  fd.append('nonce', '<?php echo esc_js( wp_create_nonce( "gs_ajax" ) ); ?>');
  fetch('<?php echo esc_js( admin_url( "admin-ajax.php" ) ); ?>', { method: 'POST', body: fd })
    .then(function(r){ return r.json(); })
    .then(function(res){
      // Real fix (Known Limitations): the widget itself still fails quietly on
      // purpose (it's a nice-to-have, not core functionality — no user-facing
      // error is shown), but a console.warn now gives a support investigation
      // into "my quality score never shows" something concrete to find,
      // instead of a bare disappearing widget with zero trace anywhere.
      if (!res.success) { console.warn('GoodService: quality checklist widget failed to load', res); return; }
      var d = res.data;
      widget.style.display = '';
      document.getElementById('gs-quality-pct').textContent = d.pct + '% complete';
      document.getElementById('gs-quality-bar-fill').style.width = d.pct + '%';
      var stepsEl = document.getElementById('gs-quality-steps');
      stepsEl.innerHTML = '';
      (d.steps || []).forEach(function(s){
        var href = s.action && s.action.charAt(0) === '?' ? window.location.pathname + s.action : s.action;
        var row = document.createElement('div');
        row.style.cssText = 'display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--gs-border)';
        row.innerHTML =
          '<span style="font-size:1.1rem;flex-shrink:0">' + (s.done ? '✅' : '⬜') + '</span>' +
          '<div style="flex:1;min-width:0">' +
            '<div style="font-size:.88rem;' + (s.done ? 'color:#94A3B8;text-decoration:line-through' : 'color:var(--gs-text)') + '">' + s.label + '</div>' +
            (s.done ? '' : '<div style="font-size:.76rem;color:#94A3B8;margin-top:2px">' + s.tip + '</div>') +
          '</div>' +
          (s.done ? '' : '<a href="' + href + '" class="gs-btn gs-btn-ghost gs-btn-xs" style="flex-shrink:0">Fix this →</a>');
        stepsEl.appendChild(row);
      });
    })
    .catch(function(err){ console.warn('GoodService: quality checklist widget request failed', err); });
})();
</script>

<?php
/* ── §3.9 Inquiry Overview Widget ─────────────────────────────────────
 * Roadmap requirement: total, new (badge), this month, response rate.
 * Uses $total_leads and $new_leads already computed above. Adds 2 cheap
 * extra queries for month count and replied count only when $vid exists.
 * ────────────────────────────────────────────────────────────────────── */
$gs_inq_month   = $vid ? (int) $wpdb->get_var( $wpdb->prepare(
    "SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d
     AND YEAR(created_at)=YEAR(CURDATE()) AND MONTH(created_at)=MONTH(CURDATE())",
    $vid
) ) : 0;
$gs_inq_replied = $vid ? (int) $wpdb->get_var( $wpdb->prepare(
    "SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d AND status IN ('replied','converted')",
    $vid
) ) : 0;
$gs_inq_rate    = $total_leads > 0 ? round( ( $gs_inq_replied / $total_leads ) * 100 ) : 0;
$gs_inq_rate_bg = $gs_inq_rate >= 80 ? '#F0FDF4' : ( $gs_inq_rate >= 50 ? '#FFFBEB' : '#F8FAFC' );
$gs_inq_rate_br = $gs_inq_rate >= 80 ? '#BBF7D0' : ( $gs_inq_rate >= 50 ? '#FDE68A' : '#E2E8F0' );
$gs_inq_rate_co = $gs_inq_rate >= 80 ? '#059669' : ( $gs_inq_rate >= 50 ? '#D97706' : '#1E293B' );
?>
<div class="gs-card" style="margin-bottom:14px">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:14px">
    <div class="gs-card-title" style="margin:0">📬 Inquiry Overview</div>
    <a href="?section=leads" class="gs-btn gs-btn-primary gs-btn-sm">View All Inquiries →</a>
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px">
    <!-- Total -->
    <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:9px;padding:13px;text-align:center">
      <div style="font-size:1.5rem;font-weight:800;color:#1E293B"><?php echo number_format( $total_leads ); ?></div>
      <div style="font-size:.72rem;color:#64748B;margin-top:4px">Total Inquiries</div>
    </div>
    <!-- New / Unread -->
    <div style="background:<?php echo $new_leads > 0 ? '#FFF7ED' : '#F8FAFC'; ?>;border:1px solid <?php echo $new_leads > 0 ? '#FED7AA' : '#E2E8F0'; ?>;border-radius:9px;padding:13px;text-align:center">
      <div style="font-size:1.5rem;font-weight:800;color:<?php echo $new_leads > 0 ? '#C2410C' : '#1E293B'; ?>">
        <?php echo $new_leads; ?>
        <?php if ( $new_leads > 0 ): ?>
          <span style="font-size:.6rem;background:#EF4444;color:#fff;border-radius:10px;padding:1px 5px;vertical-align:middle;font-weight:700">NEW</span>
        <?php endif; ?>
      </div>
      <div style="font-size:.72rem;color:#64748B;margin-top:4px">Unread</div>
    </div>
    <!-- This month -->
    <div style="background:#EFF6FF;border:1px solid #DBEAFE;border-radius:9px;padding:13px;text-align:center">
      <div style="font-size:1.5rem;font-weight:800;color:#2563EB"><?php echo $gs_inq_month; ?></div>
      <div style="font-size:.72rem;color:#64748B;margin-top:4px">This Month</div>
    </div>
    <!-- Response rate -->
    <div style="background:<?php echo $gs_inq_rate_bg; ?>;border:1px solid <?php echo $gs_inq_rate_br; ?>;border-radius:9px;padding:13px;text-align:center">
      <div style="font-size:1.5rem;font-weight:800;color:<?php echo $gs_inq_rate_co; ?>"><?php echo $gs_inq_rate; ?>%</div>
      <div style="font-size:.72rem;color:#64748B;margin-top:4px">Response Rate</div>
    </div>
  </div>
  <?php if ( $total_leads === 0 ): ?>
  <div style="margin-top:12px;padding:10px 14px;background:#F8FAFC;border-radius:8px;font-size:.8rem;color:#94A3B8;text-align:center">
    No inquiries yet. Once your listing is live, customer inquiries will appear here.
  </div>
  <?php endif; ?>
</div>

<?php
/* ── §5.1 Profile Strength (persistent, always visible on dashboard home)
 * Roadmap: 6-step checklist with green ticks. Steps 1–3 mirror the existing
 * onboarding; steps 4–6 add phone verify, doc upload, and share listing.
 * Never changes $ob / $ob_done — those drive the onboarding banner above.
 * ────────────────────────────────────────────────────────────────────── */
$gs_ps_has_phone = ! empty( $vp->phone );
$gs_ps_has_docs  = ! empty( $vp->verification_docs ) && $vp->verification_docs !== '[]';
$gs_ps_first_live = $ob['live'] ? $wpdb->get_row( $wpdb->prepare(
    "SELECT slug FROM {$pfx}listings WHERE vendor_id=%d AND status='active' LIMIT 1", $vid
) ) : null;
$gs_ps_share_url = $gs_ps_first_live ? home_url( '/' . $gs_ps_first_live->slug . '/' ) : home_url( '/directory/' );
$gs_ps_wa_share  = rawurlencode( 'Check out my listing on ' . get_bloginfo( 'name' ) . ': ' . $gs_ps_share_url );
// Phase 1 step: at least one listing has a bookable inquiry module, AND the
// vendor has set up at least one weekly availability slot. Both are required
// — accepts_booking without availability means the slot-picker shows nothing,
// and availability without accepts_booking means no "Book Now" button appears.
$gs_ps_has_bookable_module = $vid && (bool) $wpdb->get_var( $wpdb->prepare(
    "SELECT 1 FROM {$pfx}listings WHERE vendor_id=%d AND inquiry_modules_data LIKE %s LIMIT 1",
    $vid, '%"accepts_booking":true%'
) );
$gs_ps_has_availability = $vid && (bool) $wpdb->get_var( $wpdb->prepare(
    "SELECT 1 FROM {$pfx}availability av
     INNER JOIN {$pfx}listings l ON l.id = av.listing_id
     WHERE l.vendor_id=%d AND av.is_active=1 LIMIT 1", $vid
) );
$gs_ps_bookings_ready = $gs_ps_has_bookable_module && $gs_ps_has_availability;
$gs_ps_steps = [
    [ 'Complete your vendor profile',   'profile',      $ob['profile'],       '' ],
    [ 'Create your first listing',      'create',       $ob['listing'],       '' ],
    [ 'Verify your phone number',       'profile',      $gs_ps_has_phone,     '' ],
    [ 'Upload verification documents',  'verification', $gs_ps_has_docs,      '' ],
    [ 'Get listing approved & live',    'listings',     $ob['live'],          '' ],
    [ 'Set up bookings & availability', 'inquiry_modules', $gs_ps_bookings_ready, '' ],
    [ 'Share your listing',             '',             $ob['live'],          'share' ],
];
$gs_ps_done_count = count( array_filter( array_column( $gs_ps_steps, 2 ) ) );
$gs_ps_pct        = (int) round( ( $gs_ps_done_count / count( $gs_ps_steps ) ) * 100 );
$gs_ps_bar_col    = $gs_ps_pct >= 80 ? '#059669' : ( $gs_ps_pct >= 50 ? '#F59E0B' : '#2563EB' );
?>
<div class="gs-card" style="margin-bottom:14px">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:6px;margin-bottom:10px">
    <div class="gs-card-title" style="margin:0">🏆 Profile Strength</div>
    <span style="font-weight:800;font-size:.9rem;color:<?php echo $gs_ps_bar_col; ?>"><?php echo $gs_ps_pct; ?>%</span>
  </div>
  <div style="height:7px;background:#E2E8F0;border-radius:4px;margin-bottom:14px;overflow:hidden">
    <div style="height:100%;width:<?php echo $gs_ps_pct; ?>%;background:<?php echo $gs_ps_bar_col; ?>;border-radius:4px;transition:width .5s ease"></div>
  </div>
  <div style="display:flex;flex-direction:column;gap:7px">
    <?php foreach ( $gs_ps_steps as $gs_ps_i => [ $gs_ps_txt, $gs_ps_url, $gs_ps_done, $gs_ps_type ] ): ?>
    <div style="display:flex;align-items:center;gap:10px;padding:9px 11px;background:<?php echo $gs_ps_done ? '#F0FDF4' : '#F8FAFC'; ?>;border-radius:8px;border:1px solid <?php echo $gs_ps_done ? '#BBF7D0' : '#E2E8F0'; ?>">
      <div style="width:22px;height:22px;border-radius:50%;background:<?php echo $gs_ps_done ? '#059669' : '#E2E8F0'; ?>;color:<?php echo $gs_ps_done ? '#fff' : '#94A3B8'; ?>;display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:800;flex-shrink:0">
        <?php echo $gs_ps_done ? '✓' : ( $gs_ps_i + 1 ); ?>
      </div>
      <div style="flex:1;font-size:.82rem;font-weight:<?php echo $gs_ps_done ? '400' : '600'; ?>;color:<?php echo $gs_ps_done ? '#6B7280' : '#1E293B'; ?>">
        <?php echo esc_html( $gs_ps_txt ); ?>
        <?php if ( $gs_ps_url === 'inquiry_modules' && ! $gs_ps_done ): ?>
        <div style="font-size:.7rem;font-weight:400;color:#94A3B8;margin-top:2px">
          Booking module: <?php echo $gs_ps_has_bookable_module ? '✅' : '❌'; ?> · Availability: <?php echo $gs_ps_has_availability ? '✅' : '❌'; ?>
        </div>
        <?php endif; ?>
      </div>
      <?php if ( $gs_ps_type === 'share' && $gs_ps_done ): ?>
        <a href="https://wa.me/?text=<?php echo esc_attr( $gs_ps_wa_share ); ?>" target="_blank" rel="noopener" class="gs-btn gs-btn-green gs-btn-xs" title="Share on WhatsApp">💬</a>
        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo esc_attr( rawurlencode( $gs_ps_share_url ) ); ?>" target="_blank" rel="noopener" class="gs-btn gs-btn-ghost gs-btn-xs" title="Share on LinkedIn">in</a>
        <button onclick="navigator.clipboard.writeText('<?php echo esc_js( $gs_ps_share_url ); ?>').then(function(){gsToast('Link copied!','success')})" class="gs-btn gs-btn-ghost gs-btn-xs" title="Copy link">🔗</button>
      <?php elseif ( ! $gs_ps_done && $gs_ps_url ): ?>
        <a href="?section=<?php echo esc_attr( $gs_ps_url ); ?>" class="gs-btn gs-btn-ghost gs-btn-xs">Go →</a>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<div class="gs-g2">
  <div class="gs-card">
    <div class="gs-card-title">📞 Recent Leads <a href="?section=leads" style="font-size:.73rem;font-weight:400;float:right;color:var(--gs-primary)">All leads →</a></div>
    <?php $recent_leads = $vid ? $wpdb->get_results( $wpdb->prepare(
      "SELECT l.*,li.title as lt FROM {$pfx}leads l LEFT JOIN {$pfx}listings li ON l.listing_id=li.id WHERE l.vendor_id=%d ORDER BY l.created_at DESC LIMIT 5", $vid
    ) ) : []; ?>
    <?php
    // FIXED — audit gap: AjaxController::revealPhone() (gs_reveal_phone) was
    // fully built — it deliberately withholds a lead's phone number until
    // the vendor has replied/viewed/converted the inquiry (an anti-spam,
    // "engage before you get contact info" quality gate matching
    // $lead->phone_revealed) — but had zero UI caller anywhere, and this
    // widget instead printed $l->phone unconditionally, silently bypassing
    // the gate entirely regardless of phone_revealed's actual value.
    // Scoped to just this small, self-contained dashboard widget (5 rows,
    // simple markup) rather than also touching the much larger split-pane
    // Inquiry Manager (templates/pages/partials/inquiry-manager.php),
    // which has the same gap but is high enough regression risk to warrant
    // its own separately-scoped, separately-tested pass.
    ?>
    <?php if ( $recent_leads ): foreach ( $recent_leads as $l ): $l_revealed = ! empty( $l->phone_revealed ) || in_array( $l->status, [ 'replied', 'converted' ], true ); ?>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid #F1F5F9">
      <div>
        <div style="font-weight:600;font-size:.87rem"><?php echo esc_html($l->name); ?></div>
        <div style="font-size:.74rem;color:var(--gs-muted)" id="gs-rl-phone-<?php echo (int)$l->id; ?>">
          <?php if ( $l_revealed ): echo esc_html($l->phone); else: ?>
          <a href="#" onclick="gsRevealPhone(<?php echo (int)$l->id; ?>);return false;" style="color:#2563EB;text-decoration:underline">Reveal phone</a>
          <?php endif; ?>
           · <?php echo esc_html(substr($l->lt??'',0,22)); ?>
        </div>
      </div>
      <div style="display:flex;gap:4px;flex-shrink:0">
        <span class="gs-badge <?php echo $l->status==='new'?'gs-badge-blue':'gs-badge-grey'; ?>"><?php echo ucfirst($l->status); ?></span>
        <?php if ( $l_revealed ): ?><a href="tel:<?php echo esc_attr($l->phone); ?>" class="gs-btn gs-btn-green gs-btn-xs">📞</a><?php endif; ?>
        <a href="?section=leads&view=<?php echo $l->id; ?>" class="gs-btn gs-btn-ghost gs-btn-xs">View</a>
      </div>
    </div>
    <?php endforeach; else: ?>
    <div class="gs-empty" style="padding:24px"><div class="gs-empty-icon" style="font-size:1.8rem">📞</div><div>No leads yet. Get your listing live to start receiving enquiries.</div></div>
    <?php endif; ?>
  </div>

  <div class="gs-card">
    <div class="gs-card-title">🏢 My Listings <a href="<?php echo home_url('/vendor/create/'); ?>" class="gs-btn gs-btn-primary gs-btn-xs" style="float:right">+ New</a></div>
    <?php /* BUG FOUND & FIXED (v7.317.0) — this query (and the "listings" tab's
           query below) selected every row for this vendor with no status
           filter at all, so a listing soft-deleted via deleteListing()
           (which only sets status='deleted', never removes the row — by
           design, so it can be excluded from live queries elsewhere) kept
           showing up here forever, labeled "Deleted" but never actually
           disappearing. Reported directly: duplicating created a draft
           copy, deleting that copy showed status "Deleted" in this same
           table but the row itself never left the list. Fixed by excluding
           status='deleted' at the query level, matching how every other
           "live" query in this codebase already treats deleted rows
           (e.g. ListingRepository's public-facing queries). */ ?>
    <?php $my_listings = $vid ? $wpdb->get_results( $wpdb->prepare(
      "SELECT * FROM {$pfx}listings WHERE vendor_id=%d AND status != 'deleted' ORDER BY created_at DESC LIMIT 6", $vid
    ) ) : []; ?>
    <?php if ( $my_listings ): foreach ( $my_listings as $l ):
      $sc = ['active'=>'gs-badge-green','pending'=>'gs-badge-gold','draft'=>'gs-badge-grey','suspended'=>'gs-badge-red','rejected'=>'gs-badge-red'];
    ?>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid #F1F5F9">
      <div style="flex:1;min-width:0;margin-right:8px">
        <div style="font-weight:600;font-size:.87rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo esc_html($l->title); ?></div>
        <div style="font-size:.73rem;color:var(--gs-muted)">👁 <?php echo number_format($l->views_count); ?> · 📞 <?php echo $l->leads_count; ?></div>
      </div>
      <div style="display:flex;gap:4px;flex-shrink:0">
        <span class="gs-badge <?php echo $sc[$l->status]??'gs-badge-grey'; ?>"><?php echo ucfirst($l->status); ?></span>
        <a href="<?php echo home_url('/vendor/edit/'.$l->id.'/'); ?>" class="gs-btn gs-btn-ghost gs-btn-xs">Edit</a>
      </div>
    </div>
    <?php endforeach; else: ?>
    <div class="gs-empty" style="padding:24px"><div class="gs-empty-icon" style="font-size:1.8rem">🏢</div><div>No listings yet.</div><a href="<?php echo home_url('/vendor/create/'); ?>" class="gs-btn gs-btn-primary gs-btn-sm" style="margin-top:10px">Create First Listing</a></div>
    <?php endif; ?>
  </div>
</div>
<script>
function gsRevealPhone(leadId){
  gsPost('gs_reveal_phone',{nonce:'<?php echo esc_js($nonce); ?>',lead_id:leadId},function(d){
    var cell=document.getElementById('gs-rl-phone-'+leadId);
    if(cell&&d&&d.phone){cell.innerHTML='';cell.appendChild(document.createTextNode(d.phone));location.reload();}
  },function(m){gsToast(m||'Reply to the client first to reveal their contact details.','error');});
}
</script>
<?php echo gs_render_screen_help( 'Dashboard', [
  
  
], [
  [ 'mistake' => 'Assuming the dashboard\'s "New Leads" / "Unread" count refreshes in real time', 'category' => 'workflow', 'see' => "All dashboard numbers (\$new_leads, \$total_leads, \$gs_inq_month, etc.) are computed once per page load — a lead that comes in while the dashboard is open on screen will not update the count until the page is reloaded.", 'fix' => 'Reload the Dashboard page (or check the Leads screen directly, which reflects current DB state on every load) to see the latest count rather than relying on a page left open.', 'prevent' => 'Treat dashboard counts as a snapshot as of the last page load, not a live feed.' ],
  [ 'mistake' => 'Ignoring the blue "Welcome" banner and going straight to other screens before creating a listing', 'category' => 'workflow', 'see' => "The banner (gated on \$total_listing_count === 0) only appears when a vendor has zero listings of any status, including drafts — most other screens (Leads, Analytics, Bookings) will show entirely empty states until a listing exists.", 'fix' => 'Click "Create Your First Listing" from this banner before exploring other dashboard sections, since nearly everything else depends on at least one listing existing.', 'prevent' => 'The banner is deliberately gated on ANY listing (including pending/draft) so it disappears the moment a listing exists — if it is still showing, no listing has been started yet.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: PROFILE
// ══════════════════════════════════════════════════════════════════════════════
case 'profile':
  $social = json_decode( $vp->social_links ?? '{}', true ) ?: [];
  $ts     = gs_calculate_trust_score( $uid );
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">👤 My Vendor Profile</div><div class="gs-ph-sub">This info appears on all listings and your vendor page</div></div>
  <button id="gs-prof-save-btn" class="gs-btn gs-btn-primary">💾 Save Profile</button>
</div>
<div id="gs-prof-msg" class="gs-imsg"></div>

<div class="gs-g2" style="align-items:start">
  <div>
    <div class="gs-card">
      <div class="gs-card-title">Business Information</div>
      <div class="gs-fg"><label class="gs-lbl">Business Name <span class="gs-req">*</span></label><input type="text" id="gs-p-business_name" class="gs-inp" value="<?php echo esc_attr($vp->business_name??''); ?>" placeholder="Your Business Name"></div>
      <div class="gs-g2">
        <div class="gs-fg"><label class="gs-lbl">Phone <span class="gs-req">*</span></label><input type="tel" id="gs-p-phone" class="gs-inp" value="<?php echo esc_attr($vp->phone??''); ?>" placeholder="+91 98765 43210"></div>
        <div class="gs-fg"><label class="gs-lbl">WhatsApp</label><input type="tel" id="gs-p-whatsapp" class="gs-inp" value="<?php echo esc_attr($vp->whatsapp??''); ?>" placeholder="91XXXXXXXXXX"></div>
      </div>
      <div class="gs-g2">
        <div class="gs-fg"><label class="gs-lbl">Business Email</label><input type="email" id="gs-p-email" class="gs-inp" value="<?php echo esc_attr($vp->email??''); ?>" placeholder="contact@yourbusiness.com"></div>
        <div class="gs-fg"><label class="gs-lbl">Website</label><input type="url" id="gs-p-website" class="gs-inp" value="<?php echo esc_attr($vp->website??''); ?>" placeholder="https://yourbusiness.com"></div>
      </div>
      <div class="gs-fg"><label class="gs-lbl">Business Bio</label><textarea id="gs-p-bio" class="gs-ta" rows="4" placeholder="Tell customers about your business, experience, and what makes you special..."><?php echo esc_textarea($vp->bio??''); ?></textarea></div>
    </div>
    <div class="gs-card">
      <div class="gs-card-title">Location</div>
      <div class="gs-fg"><label class="gs-lbl">Full Address</label><textarea id="gs-p-address" class="gs-ta" rows="2" placeholder="Shop/Office address"><?php echo esc_textarea($vp->address??''); ?></textarea></div>
      <div class="gs-g3">
        <div class="gs-fg"><label class="gs-lbl">City</label><input type="text" id="gs-p-city" class="gs-inp" value="<?php echo esc_attr($vp->city??''); ?>" placeholder="City"></div>
        <div class="gs-fg"><label class="gs-lbl">State</label><input type="text" id="gs-p-state" class="gs-inp" value="<?php echo esc_attr($vp->state??''); ?>" placeholder="State"></div>
        <div class="gs-fg"><label class="gs-lbl">Pincode</label><input type="text" id="gs-p-pincode" class="gs-inp" value="<?php echo esc_attr($vp->pincode??''); ?>" placeholder="Pincode"></div>
      </div>
    </div>
    <!-- ── §5.6 Business Hours Editor (additive — new card) ─────────────── -->
    <div class="gs-card">
      <div class="gs-card-title">🕐 Business Hours</div>
      <div style="font-size:.79rem;color:#64748B;margin-bottom:13px;line-height:1.6">
        Set your weekly schedule. Check "Closed" to mark a day as unavailable.
        Hours are saved to all your listings automatically.
      </div>
      <div id="gs-bh-editor" style="display:flex;flex-direction:column;gap:7px">
        <?php
        // $vp->opening_hours is JSON like {"monday":"09:00 - 18:00","tuesday":"","..."}
        $gs_bh_raw      = json_decode( $vp->opening_hours ?? '{}', true ) ?: [];
        $gs_bh_days     = [
            'monday'    => 'Monday',
            'tuesday'   => 'Tuesday',
            'wednesday' => 'Wednesday',
            'thursday'  => 'Thursday',
            'friday'    => 'Friday',
            'saturday'  => 'Saturday',
            'sunday'    => 'Sunday',
        ];
        foreach ( $gs_bh_days as $gs_bh_key => $gs_bh_label ):
            $gs_bh_val    = trim( $gs_bh_raw[ $gs_bh_key ] ?? '' );
            $gs_bh_closed = empty( $gs_bh_val );
            // Real fix — confirmed data-loss bug (Known Limitations): an
            // unparsable-but-non-empty stored value used to fall straight
            // into the same branch as "closed", silently substituting
            // 09:00–18:00 with no indication anything was wrong — and since
            // Save Hours always re-serializes every row's current DOM state
            // (collectHours() below), the vendor's real stored value was
            // permanently overwritten the moment they saved, even if they
            // never touched that day's row. Now tracked as its own state
            // (gs_bh_unparsable) so the row surfaces a visible warning and
            // preserves the original raw text in a hidden field, which
            // collectHours() passes through unchanged unless the vendor
            // actually edits that day.
            $gs_bh_unparsable = false;
            if ( ! $gs_bh_closed && preg_match( '/^(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})$/', $gs_bh_val, $gs_bh_m ) ) {
                // Normalise directly — no strtotime() needed, regex gives us the parts
                $gs_bh_open  = str_pad( (int) $gs_bh_m[1], 2, '0', STR_PAD_LEFT ) . ':' . str_pad( (int) $gs_bh_m[2], 2, '0', STR_PAD_LEFT );
                $gs_bh_close = str_pad( (int) $gs_bh_m[3], 2, '0', STR_PAD_LEFT ) . ':' . str_pad( (int) $gs_bh_m[4], 2, '0', STR_PAD_LEFT );
            } elseif ( ! $gs_bh_closed ) {
                // Non-empty but doesn't match "HH:MM - HH:MM" — preserve it.
                $gs_bh_unparsable = true;
                $gs_bh_open  = '09:00';
                $gs_bh_close = '18:00';
            } else {
                $gs_bh_open  = '09:00';
                $gs_bh_close = '18:00';
            }
        ?>
        <div class="gs-bh-row"
             data-day="<?php echo esc_attr( $gs_bh_key ); ?>"
             style="display:flex;align-items:center;gap:10px;padding:9px 12px;background:#F8FAFC;border-radius:8px;border:1px solid #E2E8F0;flex-wrap:wrap">
          <span style="width:84px;font-size:.81rem;font-weight:600;color:#334155;flex-shrink:0"><?php echo $gs_bh_label; ?></span>
          <label style="display:flex;align-items:center;gap:5px;font-size:.78rem;color:#64748B;cursor:pointer;flex-shrink:0;user-select:none">
            <input type="checkbox"
                   class="gs-bh-closed"
                   <?php echo $gs_bh_closed ? 'checked' : ''; ?>
                   style="accent-color:#EF4444;cursor:pointer"
                   aria-label="<?php echo esc_attr( $gs_bh_label ); ?> closed"> Closed
          </label>
          <div class="gs-bh-times"
               style="display:flex;align-items:center;gap:7px;<?php echo $gs_bh_closed ? 'opacity:.3;pointer-events:none' : ''; ?>">
            <input type="time"
                   class="gs-bh-open gs-inp"
                   value="<?php echo esc_attr( $gs_bh_open ); ?>"
                   style="padding:5px 8px;font-size:.79rem;width:108px"
                   aria-label="<?php echo esc_attr( $gs_bh_label ); ?> opening time">
            <span style="font-size:.77rem;color:#94A3B8">to</span>
            <input type="time"
                   class="gs-bh-close gs-inp"
                   value="<?php echo esc_attr( $gs_bh_close ); ?>"
                   style="padding:5px 8px;font-size:.79rem;width:108px"
                   aria-label="<?php echo esc_attr( $gs_bh_label ); ?> closing time">
          </div>
          <?php if ( $gs_bh_unparsable ): ?>
          <input type="hidden" class="gs-bh-raw-unparsable" value="<?php echo esc_attr( $gs_bh_val ); ?>">
          <div style="width:100%;font-size:.72rem;color:#B45309;background:#FFFBEB;border:1px solid #FDE68A;border-radius:6px;padding:5px 9px">
            ⚠️ Unrecognized saved value: "<?php echo esc_html( $gs_bh_val ); ?>" — kept as-is. Set the times above and Save Hours to replace it, or it will be saved unchanged.
          </div>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>

      <div style="margin-top:11px;display:flex;align-items:center;gap:9px;flex-wrap:wrap">
        <button type="button" id="gs-bh-copy-weekdays" class="gs-btn gs-btn-ghost gs-btn-sm">
          📋 Copy Mon–Fri timing to all weekdays
        </button>
        <button type="button" id="gs-bh-save-btn" class="gs-btn gs-btn-primary gs-btn-sm">
          💾 Save Hours
        </button>
        <span id="gs-bh-msg" style="font-size:.79rem;color:#059669;display:none">✅ Saved!</span>
      </div>
      <div id="gs-bh-err" style="font-size:.79rem;color:#DC2626;margin-top:6px;display:none"></div>
    </div>
    <!-- ── End Business Hours Editor ──────────────────────────────────────── -->
    <div class="gs-card">
      <div class="gs-card-title">Tax Information</div>
      <div class="gs-g2">
        <div class="gs-fg"><label class="gs-lbl">GST Number</label><input type="text" id="gs-p-gst_number" class="gs-inp" value="<?php echo esc_attr($vp->gst_number??''); ?>" placeholder="22AAAAA0000A1Z5" style="text-transform:uppercase"></div>
        <div class="gs-fg"><label class="gs-lbl">PAN Number</label><input type="text" id="gs-p-pan_number" class="gs-inp" value="<?php echo esc_attr($vp->pan_number??''); ?>" placeholder="ABCDE1234F" style="text-transform:uppercase"></div>
      </div>
    </div>
    <div class="gs-card">
      <div class="gs-card-title">Social Links</div>
      <?php foreach ( ['facebook'=>'Facebook','instagram'=>'Instagram','linkedin'=>'LinkedIn','twitter'=>'Twitter/X','youtube'=>'YouTube'] as $soc => $slbl ): ?>
      <div class="gs-fg"><label class="gs-lbl"><?php echo $slbl; ?></label><input type="url" id="gs-p-social-<?php echo $soc; ?>" class="gs-inp gs-social-inp" data-social="<?php echo $soc; ?>" value="<?php echo esc_attr($social[$soc]??''); ?>" placeholder="https://<?php echo $soc; ?>.com/yourpage"></div>
      <?php endforeach; ?>
    </div>
  </div>

  <div>
    <div class="gs-card">
      <div class="gs-card-title">Business Logo</div>
      <div style="text-align:center;margin-bottom:13px">
        <div id="gs-logo-preview" style="width:96px;height:96px;border-radius:12px;background:#F1F5F9;border:2px dashed #CBD5E1;display:flex;align-items:center;justify-content:center;margin:0 auto 10px;overflow:hidden">
          <?php if($vp&&$vp->logo_url): ?><img src="<?php echo esc_url($vp->logo_url); ?>" style="width:100%;height:100%;object-fit:cover"><?php else: ?><span style="font-size:2rem">🏢</span><?php endif; ?>
        </div>
        <input type="hidden" id="gs-p-logo_url" value="<?php echo esc_attr($vp->logo_url??''); ?>">
      </div>
      <input type="file" id="gs-logo-file" accept="image/*" style="display:none">
      <div class="gs-upload-zone" id="gs-logo-zone" onclick="document.getElementById('gs-logo-file').click()">
        <div style="font-size:1.2rem">📷</div>
        <div class="gs-upload-zone-txt">Click to upload logo</div>
        <div class="gs-drop-hint">or drag &amp; drop · PNG/JPG square, min 200×200px</div>
      </div>
    </div>

    <div class="gs-card">
      <div class="gs-card-title">Cover Photo</div>
      <div id="gs-cover-preview" style="height:90px;border-radius:9px;background:#F1F5F9;border:2px dashed #CBD5E1;overflow:hidden;margin-bottom:10px;display:flex;align-items:center;justify-content:center">
        <?php if($vp&&$vp->cover_url): ?><img src="<?php echo esc_url($vp->cover_url); ?>" style="width:100%;height:100%;object-fit:cover"><?php else: ?><span style="color:#94A3B8;font-size:.8rem">No cover photo</span><?php endif; ?>
      </div>
      <input type="hidden" id="gs-p-cover_url" value="<?php echo esc_attr($vp->cover_url??''); ?>">
      <input type="file" id="gs-cover-file" accept="image/*" style="display:none">
      <div class="gs-upload-zone" id="gs-cover-zone" onclick="document.getElementById('gs-cover-file').click()">
        <div style="font-size:1.2rem">🖼️</div>
        <div class="gs-upload-zone-txt">Click to upload cover photo</div>
        <div class="gs-drop-hint">or drag &amp; drop · 1200×400px recommended</div>
      </div>
    </div>

    <div class="gs-card">
      <div class="gs-card-title">🛡️ Trust Score</div>
      <div style="text-align:center;margin-bottom:12px">
        <div style="font-size:2.4rem;font-weight:900;color:<?php echo $ts>=70?'#059669':($ts>=40?'#D97706':'#DC2626'); ?>"><?php echo $ts; ?></div>
        <div style="font-size:.74rem;color:#94A3B8">out of 100</div>
      </div>
      <div class="gs-prog-track"><div class="gs-prog-fill" style="width:<?php echo $ts; ?>%;background:<?php echo $ts>=70?'#059669':($ts>=40?'#D97706':'#DC2626'); ?>"></div></div>
      <div style="margin-top:12px">
        <?php foreach ( [
          ['Business Name', (bool)($vp->business_name??false), 10],
          ['Phone', (bool)($vp->phone??false), 10],
          ['Bio / Description', (bool)($vp->bio??false), 10],
          ['Logo', (bool)($vp->logo_url??false), 10],
          ['Email', (bool)($vp->email??false), 5],
          ['Website', (bool)($vp->website??false), 5],
          ['Verification', ($vp->verification_status??'')==='verified', 30],
        ] as [$label,$has,$pts] ): ?>
        <div class="gs-qs"><span><?php echo $label; ?></span><span style="color:<?php echo $has?'#059669':'#94A3B8'; ?>"><?php echo $has?'✅ +'.$pts:'❌ 0'; ?> pts</span></div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  var nonce='<?php echo esc_js($nonce); ?>';
  function showMsg(cls,txt){var el=document.getElementById('gs-prof-msg');el.className='gs-imsg '+cls;el.textContent=txt;setTimeout(function(){el.className='gs-imsg';},5000);}
  // Logo upload
  document.getElementById('gs-logo-file').addEventListener('change',function(){
    if(!this.files[0])return;
    var file = this.files[0];
    gsUploadFileToDash(file, 'gs-logo-zone', 'gs-logo-file', function(url){
      document.getElementById('gs-p-logo_url').value = url;
      document.getElementById('gs-logo-preview').innerHTML='<img src="'+url+'" style="width:100%;height:100%;object-fit:cover">';
      var zone = document.getElementById('gs-logo-zone');
      if (zone) zone.innerHTML = '<img src="'+url+'" style="width:100%;height:70px;object-fit:cover;border-radius:6px"><div class="gs-drop-hint" style="margin-top:4px">✅ Uploaded — click or drag to replace</div>';
      gsToast('Logo uploaded','success');
    });
  });
  // Cover upload
  // ── Drag-drop for dashboard upload zones ─────────────────────────
  function gsDashDragDrop(zoneId, fileInputId, onFile) {
    var zone = document.getElementById(zoneId);
    if (!zone) return;
    ['dragover','dragenter'].forEach(function(evt) {
      zone.addEventListener(evt, function(e) { e.preventDefault(); zone.classList.add('dragover'); });
    });
    zone.addEventListener('dragleave', function() { zone.classList.remove('dragover'); });
    zone.addEventListener('drop', function(e) {
      e.preventDefault();
      zone.classList.remove('dragover');
      var file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (file) onFile(file);
    });
  }

  function gsUploadFileToDash(file, zoneId, inputId, onSuccess) {
    var zone = document.getElementById(zoneId);
    var origHTML = zone ? zone.innerHTML : '';
    if (zone) zone.innerHTML = '<div style="padding:12px"><div style="width:24px;height:24px;border:3px solid #BFDBFE;border-top-color:#2563EB;border-radius:50%;animation:lpbSpin .7s linear infinite;margin:0 auto"></div><div style="font-size:.78rem;color:#2563EB;margin-top:6px">Uploading…</div></div>';
    if (!document.getElementById('lpb-spin-style')) {
      var st = document.createElement('style');
      st.id = 'lpb-spin-style';
      st.textContent = '@keyframes lpbSpin{to{transform:rotate(360deg)}}';
      document.head.appendChild(st);
    }
    var fd = new FormData();
    fd.append('action','gs_upload_media'); fd.append('nonce','<?php echo esc_js($nonce); ?>');
    fd.append('file', file); fd.append('type','image');
    fetch('<?php echo esc_js(admin_url("admin-ajax.php")); ?>', { method:'POST', body:fd })
      .then(function(r){ return r.json(); })
      .then(function(d) {
        if (d.success && d.data && d.data.url) {
          onSuccess(d.data.url);
        } else {
          if (zone) zone.innerHTML = origHTML;
          gsToast((d.data&&d.data.message)||'Upload failed','error');
        }
      })
      .catch(function() { if (zone) zone.innerHTML = origHTML; gsToast('Network error','error'); });
  }

  gsDashDragDrop('gs-logo-zone','gs-logo-file', function(file){
    gsUploadFileToDash(file, 'gs-logo-zone', 'gs-logo-file', function(url){
      document.getElementById('gs-p-logo_url').value = url;
      document.getElementById('gs-logo-preview').innerHTML = '<img src="'+url+'" style="width:100%;height:100%;object-fit:cover">';
      var zone = document.getElementById('gs-logo-zone');
      if (zone) zone.innerHTML = '<img src="'+url+'" style="width:100%;height:70px;object-fit:cover;border-radius:6px"><div class="gs-drop-hint" style="margin-top:4px">✅ Uploaded — click or drag to replace</div>';
      gsToast('Logo uploaded','success');
    });
  });

  gsDashDragDrop('gs-cover-zone','gs-cover-file', function(file){
    gsUploadFileToDash(file, 'gs-cover-zone', 'gs-cover-file', function(url){
      document.getElementById('gs-p-cover_url').value = url;
      document.getElementById('gs-cover-preview').innerHTML = '<img src="'+url+'" style="width:100%;height:100%;object-fit:cover">';
      var zone = document.getElementById('gs-cover-zone');
      if (zone) zone.innerHTML = '<img src="'+url+'" style="width:100%;height:70px;object-fit:cover;border-radius:6px"><div class="gs-drop-hint" style="margin-top:4px">✅ Uploaded — click or drag to replace</div>';
      gsToast('Cover uploaded','success');
    });
  });

  gsDashDragDrop('gs-ver-zone','gs-ver-file', function(file){
    var fd = new FormData();
    fd.append('action','gs_upload_media'); fd.append('nonce','<?php echo esc_js($nonce); ?>');
    fd.append('file', file); fd.append('type','image');
    document.getElementById('gs-ver-upload-status').textContent = 'Uploading…';
    fetch('<?php echo esc_js(admin_url("admin-ajax.php")); ?>', { method:'POST', body:fd })
      .then(function(r){ return r.json(); })
      .then(function(d) {
        if (d.success && d.data && d.data.url) {
          document.getElementById('gs-ver-url').value = d.data.url;
          document.getElementById('gs-ver-upload-status').textContent = '✅ File ready — click Submit to send for review';
          gsToast('Document uploaded','success');
        } else {
          document.getElementById('gs-ver-upload-status').textContent = '';
          gsToast((d.data&&d.data.message)||'Upload failed','error');
        }
      })
      // Real fix — silent failure: a network error left "Uploading…" on
      // screen forever with no way to tell the upload had actually failed.
      .catch(function(){
        document.getElementById('gs-ver-upload-status').textContent = '';
        gsToast('Network error — upload failed. Please try again.','error');
      });
  });

  document.getElementById('gs-cover-file').addEventListener('change',function(){
    if(!this.files[0])return;
    var file = this.files[0];
    gsUploadFileToDash(file, 'gs-cover-zone', 'gs-cover-file', function(url){
      document.getElementById('gs-p-cover_url').value = url;
      document.getElementById('gs-cover-preview').innerHTML='<img src="'+url+'" style="width:100%;height:100%;object-fit:cover">';
      var zone = document.getElementById('gs-cover-zone');
      if (zone) zone.innerHTML = '<img src="'+url+'" style="width:100%;height:70px;object-fit:cover;border-radius:6px"><div class="gs-drop-hint" style="margin-top:4px">✅ Uploaded — click or drag to replace</div>';
      gsToast('Cover uploaded','success');
    });
  });
  // Save
  document.getElementById('gs-prof-save-btn').addEventListener('click',function(){
    var btn=this; btn.disabled=true; btn.textContent='Saving…';
    var social={};
    document.querySelectorAll('.gs-social-inp').forEach(function(el){if(el.value)social[el.dataset.social]=el.value;});
    gsPost('gs_save_vendor_profile',{
      nonce:nonce,
      business_name:document.getElementById('gs-p-business_name').value,
      phone:document.getElementById('gs-p-phone').value,
      whatsapp:document.getElementById('gs-p-whatsapp').value,
      email:document.getElementById('gs-p-email').value,
      website:document.getElementById('gs-p-website').value,
      bio:document.getElementById('gs-p-bio').value,
      address:document.getElementById('gs-p-address').value,
      city:document.getElementById('gs-p-city').value,
      state:document.getElementById('gs-p-state').value,
      pincode:document.getElementById('gs-p-pincode').value,
      gst_number:document.getElementById('gs-p-gst_number').value,
      pan_number:document.getElementById('gs-p-pan_number').value,
      logo_url:document.getElementById('gs-p-logo_url').value,
      cover_url:document.getElementById('gs-p-cover_url').value,
      social_links:JSON.stringify(social),
      // opening_hours is handled by its own dedicated Save Hours button (gs-bh-save-btn)
      // and the gs_save_business_hours AJAX action — not included here to avoid overwriting
      // hours with an empty value if the hours card is not currently visible.
    },function(){
      btn.disabled=false; btn.textContent='💾 Save Profile';
      showMsg('ok','✅ Profile saved! Your vendor page updates automatically.');
    },function(e){
      btn.disabled=false; btn.textContent='💾 Save Profile';
      showMsg('err','❌ '+e);
    });
  });
})();
</script>

<!-- ── §5.6 Business Hours Editor — JavaScript ──────────────────────── -->
<script>
(function(){
  'use strict';

  // ── Utility: collect hours from the editor rows ──────────────────────
  function collectHours() {
    var result = {};
    document.querySelectorAll('.gs-bh-row').forEach(function(row) {
      var day     = row.dataset.day;
      var closed  = row.querySelector('.gs-bh-closed').checked;
      var openEl  = row.querySelector('.gs-bh-open');
      var closeEl = row.querySelector('.gs-bh-close');
      // Real fix — confirmed data-loss bug: a day whose stored value could
      // not be parsed into "HH:MM - HH:MM" used to be silently replaced
      // with the generic 09:00-18:00 default on every save, even if the
      // vendor never touched that row. The raw value is preserved here
      // instead — it only gets overwritten once the vendor actually
      // unchecks "Closed" and/or edits a time on this specific row, at
      // which point the warning banner and hidden field are gone anyway.
      var rawEl = row.querySelector('.gs-bh-raw-unparsable');
      if (rawEl) { result[day] = rawEl.value; return; }
      if (closed || !openEl.value || !closeEl.value) {
        result[day] = '';
      } else {
        result[day] = openEl.value + ' - ' + closeEl.value;
      }
    });
    return result;
  }

  // Real fix — once the vendor actually interacts with a row that had an
  // unparsable preserved value (toggles Closed, or edits either time),
  // clear the preservation so their new choice is what actually saves —
  // otherwise collectHours() above would keep re-saving the old raw value
  // forever, no matter what the vendor changes on screen.
  document.querySelectorAll('.gs-bh-row').forEach(function(row) {
    var clearRaw = function(){ var r = row.querySelector('.gs-bh-raw-unparsable'); if (r) r.remove(); };
    row.querySelectorAll('.gs-bh-closed, .gs-bh-open, .gs-bh-close').forEach(function(el){
      el.addEventListener('change', clearRaw);
    });
  });

  // ── Toggle time inputs when "Closed" checkbox changes ────────────────
  document.querySelectorAll('.gs-bh-closed').forEach(function(cb) {
    cb.addEventListener('change', function() {
      var row   = this.closest('.gs-bh-row');
      var times = row.querySelector('.gs-bh-times');
      if (this.checked) {
        times.style.opacity       = '0.3';
        times.style.pointerEvents = 'none';
      } else {
        times.style.opacity       = '1';
        times.style.pointerEvents = '';
      }
    });
  });

  // ── "Copy Mon–Fri timing" convenience button ─────────────────────────
  var copyBtn = document.getElementById('gs-bh-copy-weekdays');
  if (copyBtn) {
    copyBtn.addEventListener('click', function() {
      var monRow  = document.querySelector('.gs-bh-row[data-day="monday"]');
      if (!monRow) return;
      var monOpen   = monRow.querySelector('.gs-bh-open').value;
      var monClose  = monRow.querySelector('.gs-bh-close').value;
      var monClosed = monRow.querySelector('.gs-bh-closed').checked;
      ['tuesday','wednesday','thursday','friday'].forEach(function(day) {
        var row = document.querySelector('.gs-bh-row[data-day="' + day + '"]');
        if (!row) return;
        row.querySelector('.gs-bh-closed').checked = monClosed;
        row.querySelector('.gs-bh-open').value     = monOpen;
        row.querySelector('.gs-bh-close').value    = monClose;
        var times = row.querySelector('.gs-bh-times');
        times.style.opacity       = monClosed ? '0.3' : '1';
        times.style.pointerEvents = monClosed ? 'none' : '';
      });
      if(typeof gsToast==='function') gsToast('Mon–Fri timing applied','success');
    });
  }

  // ── Save Hours button ─────────────────────────────────────────────────
  var saveBtn = document.getElementById('gs-bh-save-btn');
  var msgEl   = document.getElementById('gs-bh-msg');
  var errEl   = document.getElementById('gs-bh-err');
  if (saveBtn) {
    saveBtn.addEventListener('click', function() {
      var btn = this;
      btn.disabled = true;
      btn.textContent = 'Saving…';
      if (msgEl) msgEl.style.display = 'none';
      if (errEl) errEl.style.display = 'none';

      var hours = collectHours();

      // Validate: open time must be before close time on non-closed days
      var valid = true;
      Object.keys(hours).forEach(function(day) {
        if (!hours[day]) return; // closed — skip
        var parts = hours[day].split(' - ');
        if (parts.length !== 2) { valid = false; return; }
        var openInt  = parseInt(parts[0].replace(':',''), 10);
        var closeInt = parseInt(parts[1].replace(':',''), 10);
        if (closeInt <= openInt) {
          valid = false;
          if (errEl) {
            errEl.textContent = day.charAt(0).toUpperCase() + day.slice(1) + ': closing time must be after opening time.';
            errEl.style.display = 'block';
          }
        }
      });

      if (!valid) {
        btn.disabled = false;
        btn.textContent = '💾 Save Hours';
        return;
      }

      jQuery.post(
        GS.ajax_url,
        {
          action        : 'gs_save_business_hours',
          nonce         : GS.nonce,
          opening_hours : JSON.stringify(hours),
        },
        function(resp) {
          btn.disabled    = false;
          btn.textContent = '💾 Save Hours';
          if (resp && resp.success) {
            if (msgEl) { msgEl.style.display = 'inline'; }
            if (typeof gsToast === 'function') gsToast('Business hours saved!', 'success');
            setTimeout(function(){ if(msgEl) msgEl.style.display='none'; }, 4000);
          } else {
            var msg = (resp && resp.data && resp.data.message) ? resp.data.message : 'Save failed.';
            if (errEl) { errEl.textContent = msg; errEl.style.display = 'block'; }
            if (typeof gsToast === 'function') gsToast(msg, 'error');
          }
        },
        'json'
      ).fail(function() {
        btn.disabled    = false;
        btn.textContent = '💾 Save Hours';
        if (typeof gsToast === 'function') gsToast('Network error — please try again.', 'error');
      });
    });
  }
})();
</script>
<!-- ── End Business Hours JavaScript ─────────────────────────────────── -->

<!-- ── Change Password Card ──────────────────────────────────────── -->
<div class="gs-card" style="margin-top:20px">
  <div class="gs-card-title">🔒 Change Password</div>
  <div id="gs-pw-msg" class="gs-imsg"></div>
  <div class="gs-g2" style="align-items:end">
    <div>
      <div class="gs-fg"><label class="gs-lbl">Current Password</label><input type="password" id="gs-pw-current" class="gs-inp" placeholder="Your current password" autocomplete="current-password"></div>
      <div class="gs-fg"><label class="gs-lbl">New Password</label><input type="password" id="gs-pw-new" class="gs-inp" placeholder="Min 8 characters" autocomplete="new-password" oninput="gsPwStrength(this.value)">
        <div style="height:4px;background:#E2E8F0;border-radius:2px;margin-top:6px;overflow:hidden"><div id="gs-pw-bar" style="height:100%;width:0%;border-radius:2px;transition:width .3s,background .3s"></div></div>
      </div>
      <div class="gs-fg"><label class="gs-lbl">Confirm New Password</label><input type="password" id="gs-pw-confirm" class="gs-inp" placeholder="Repeat new password" autocomplete="new-password"></div>
    </div>
    <div>
      <button id="gs-pw-btn" class="gs-btn gs-btn-primary" style="width:100%">🔒 Update Password</button>
      <p style="font-size:.75rem;color:#94A3B8;margin-top:8px;line-height:1.5">You will remain logged in after changing your password.</p>
    </div>
  </div>
</div>
<script>
(function(){
  var nonce='<?php echo esc_js($nonce); ?>';
  function gsPwStrength(val){
    var s=0;
    if(val.length>=8)s++;if(val.length>=12)s++;
    if(/[A-Z]/.test(val))s++;if(/[0-9]/.test(val))s++;if(/[^A-Za-z0-9]/.test(val))s++;
    var cols=['#DC2626','#F59E0B','#F59E0B','#059669','#059669'];
    var bar=document.getElementById('gs-pw-bar');
    bar.style.width=(s/5*100)+'%';bar.style.background=cols[s-1]||'#E2E8F0';
  }
  document.getElementById('gs-pw-btn').addEventListener('click',function(){
    var cur=document.getElementById('gs-pw-current').value;
    var nw=document.getElementById('gs-pw-new').value;
    var cf=document.getElementById('gs-pw-confirm').value;
    var msg=document.getElementById('gs-pw-msg');
    msg.className='gs-imsg';msg.textContent='';
    if(!cur||!nw||!cf){msg.className='gs-imsg err';msg.textContent='All password fields are required.';return;}
    if(nw.length<8){msg.className='gs-imsg err';msg.textContent='New password must be at least 8 characters.';return;}
    if(nw!==cf){msg.className='gs-imsg err';msg.textContent='New passwords do not match.';return;}
    var btn=this;btn.disabled=true;btn.textContent='Updating\u2026';
    gsPost('gs_change_password',{nonce:nonce,current_password:cur,new_password:nw,confirm_password:cf},
      function(){
        btn.disabled=false;btn.textContent='\uD83D\uDD12 Update Password';
        msg.className='gs-imsg ok';msg.textContent='\u2705 Password changed successfully!';
        document.getElementById('gs-pw-current').value='';
        document.getElementById('gs-pw-new').value='';
        document.getElementById('gs-pw-confirm').value='';
        document.getElementById('gs-pw-bar').style.width='0%';
        setTimeout(function(){msg.className='gs-imsg';},5000);
      },
      function(e){
        btn.disabled=false;btn.textContent='\uD83D\uDD12 Update Password';
        msg.className='gs-imsg err';msg.textContent='\u274C '+e;
      }
    );
  });
})();
</script>

<!-- ── Two-Factor Authentication Card — real feature ─────────────────── -->
<div class="gs-card" style="margin-top:20px" id="gs-2fa-card">
  <div class="gs-card-title">🛡️ Two-Factor Authentication</div>
  <div id="gs-2fa-msg" class="gs-imsg"></div>

  <div id="gs-2fa-off-view" style="<?php echo $_vendor_2fa_enabled ? 'display:none' : ''; ?>">
    <p style="font-size:.82rem;color:#64748B;margin-bottom:14px">Add an extra layer of security — a verification code sent to your phone will be required at login, in addition to your password.</p>
    <div id="gs-2fa-step1">
      <div class="gs-fg"><label class="gs-lbl">Phone Number</label><input type="tel" id="gs-2fa-phone" class="gs-inp" placeholder="+91 98765 43210" value="<?php echo esc_attr($profile_phone ?? ''); ?>"></div>
      <button id="gs-2fa-send-btn" class="gs-btn gs-btn-primary">📲 Send Verification Code</button>
    </div>
    <div id="gs-2fa-step2" style="display:none;margin-top:14px">
      <div class="gs-fg"><label class="gs-lbl">Enter the 6-digit code sent to your phone</label><input type="text" id="gs-2fa-code" class="gs-inp" inputmode="numeric" maxlength="6" placeholder="000000" style="letter-spacing:.3em;text-align:center"></div>
      <button id="gs-2fa-confirm-btn" class="gs-btn gs-btn-primary">✓ Confirm &amp; Enable</button>
      <button id="gs-2fa-cancel-btn" class="gs-btn gs-btn-ghost" style="margin-left:8px">Cancel</button>
    </div>
  </div>

  <div id="gs-2fa-on-view" style="<?php echo $_vendor_2fa_enabled ? '' : 'display:none'; ?>">
    <p style="font-size:.82rem;color:#059669;margin-bottom:14px">✅ Two-factor authentication is enabled on your account.</p>
    <div class="gs-fg"><label class="gs-lbl">Enter your password to disable</label><input type="password" id="gs-2fa-disable-pw" class="gs-inp" placeholder="Current password"></div>
    <button id="gs-2fa-disable-btn" class="gs-btn gs-btn-ghost">Disable Two-Factor Authentication</button>
  </div>
</div>
<script>
(function(){
  var nonce = '<?php echo esc_js($nonce); ?>';
  function msg(text, ok) {
    var m = document.getElementById('gs-2fa-msg');
    m.className = 'gs-imsg ' + (ok ? 'ok' : 'err');
    m.textContent = text;
    setTimeout(function(){ m.className = 'gs-imsg'; }, 6000);
  }

  document.getElementById('gs-2fa-send-btn').addEventListener('click', function(){
    var phone = document.getElementById('gs-2fa-phone').value.trim();
    if (!phone) { msg('Please enter a phone number.', false); return; }
    var btn = this; btn.disabled = true; btn.textContent = 'Sending…';
    gsPost('gs_start_2fa_setup', { nonce: nonce, phone: phone },
      function() {
        btn.disabled = false; btn.textContent = '📲 Send Verification Code';
        document.getElementById('gs-2fa-step1').style.display = 'none';
        document.getElementById('gs-2fa-step2').style.display = '';
        msg('Verification code sent.', true);
      },
      function(e) {
        btn.disabled = false; btn.textContent = '📲 Send Verification Code';
        msg(e, false);
      }
    );
  });

  document.getElementById('gs-2fa-confirm-btn').addEventListener('click', function(){
    var phone = document.getElementById('gs-2fa-phone').value.trim();
    var code  = document.getElementById('gs-2fa-code').value.trim();
    if (!code) { msg('Please enter the verification code.', false); return; }
    var btn = this; btn.disabled = true; btn.textContent = 'Confirming…';
    gsPost('gs_confirm_2fa_setup', { nonce: nonce, phone: phone, otp: code },
      function() {
        msg('Two-factor authentication enabled!', true);
        document.getElementById('gs-2fa-off-view').style.display = 'none';
        document.getElementById('gs-2fa-on-view').style.display = '';
      },
      function(e) {
        btn.disabled = false; btn.textContent = '✓ Confirm & Enable';
        msg(e, false);
      }
    );
  });

  document.getElementById('gs-2fa-cancel-btn').addEventListener('click', function(){
    document.getElementById('gs-2fa-step1').style.display = '';
    document.getElementById('gs-2fa-step2').style.display = 'none';
    document.getElementById('gs-2fa-code').value = '';
  });

  document.getElementById('gs-2fa-disable-btn').addEventListener('click', function(){
    var pw = document.getElementById('gs-2fa-disable-pw').value;
    if (!pw) { msg('Please enter your password to confirm.', false); return; }
    var btn = this; btn.disabled = true; btn.textContent = 'Disabling…';
    gsPost('gs_disable_2fa', { nonce: nonce, password: pw },
      function() {
        msg('Two-factor authentication disabled.', true);
        document.getElementById('gs-2fa-on-view').style.display = 'none';
        document.getElementById('gs-2fa-off-view').style.display = '';
        document.getElementById('gs-2fa-disable-pw').value = '';
        btn.disabled = false; btn.textContent = 'Disable Two-Factor Authentication';
      },
      function(e) {
        btn.disabled = false; btn.textContent = 'Disable Two-Factor Authentication';
        msg(e, false);
      }
    );
  });
})();
</script>

<!-- ── Safety / Verification Document Card — real feature ────────────── -->
<?php $_sd_status = $vp->safety_doc_status ?? 'none'; ?>
<div class="gs-card" style="margin-top:20px" id="gs-sd-card">
  <div class="gs-card-title">🪪 Safety &amp; Verification Document</div>
  <div id="gs-sd-msg" class="gs-imsg"></div>

  <?php if ($_sd_status === 'approved'): ?>
    <p style="font-size:.85rem;color:#059669">✅ Your document has been reviewed and approved. This contributes to your verified badge and trust score.</p>
  <?php elseif ($_sd_status === 'pending'): ?>
    <p style="font-size:.85rem;color:#D97706">⏳ Your <?php echo esc_html(str_replace('_',' ',$vp->safety_doc_type ?? '')); ?> document is awaiting admin review.</p>
  <?php else: ?>
    <?php if ($_sd_status === 'rejected'): ?>
      <p style="font-size:.85rem;color:#DC2626">❌ Your previous submission was not approved<?php if(!empty($vp->safety_doc_note)): ?>: <?php echo esc_html($vp->safety_doc_note); ?><?php endif; ?>. Please submit a new document below.</p>
    <?php else: ?>
      <p style="font-size:.82rem;color:#64748B;margin-bottom:14px">Upload a police clearance certificate, background check, ID proof, or address proof to boost your verified status and trust score.</p>
    <?php endif; ?>
    <div class="gs-fg"><label class="gs-lbl">Document Type</label>
      <select id="gs-sd-type" class="gs-select">
        <option value="police_clearance">Police Clearance Certificate</option>
        <option value="background_check">Background Check Report</option>
        <option value="id_proof">Government ID Proof</option>
        <option value="address_proof">Address Proof</option>
      </select>
    </div>
    <input type="file" id="gs-sd-file" accept="image/*,.pdf" style="display:none">
    <input type="hidden" id="gs-sd-url">
    <button id="gs-sd-upload-btn" class="gs-btn gs-btn-ghost">📤 Choose File</button>
    <button id="gs-sd-submit-btn" class="gs-btn gs-btn-primary" style="display:none;margin-left:8px">Submit for Review</button>
  <?php endif; ?>
</div>
<script>
(function(){
  var nonce = '<?php echo esc_js($nonce); ?>';
  function msg(text, ok) {
    var m = document.getElementById('gs-sd-msg');
    if (!m) return;
    m.className = 'gs-imsg ' + (ok ? 'ok' : 'err');
    m.textContent = text;
    setTimeout(function(){ m.className = 'gs-imsg'; }, 6000);
  }
  var uploadBtn = document.getElementById('gs-sd-upload-btn');
  if (!uploadBtn) return;

  uploadBtn.addEventListener('click', function(){ document.getElementById('gs-sd-file').click(); });

  document.getElementById('gs-sd-file').addEventListener('change', function(){
    var file = this.files[0];
    if (!file) return;
    uploadBtn.disabled = true; uploadBtn.textContent = 'Uploading…';
    var fd = new FormData();
    fd.append('action','gs_upload_media'); fd.append('nonce', nonce);
    fd.append('file', file); fd.append('type','document');
    fetch('<?php echo esc_js(admin_url("admin-ajax.php")); ?>', { method:'POST', body:fd })
      .then(function(r){ return r.json(); })
      .then(function(d){
        uploadBtn.disabled = false;
        if (d.success && d.data && d.data.url) {
          document.getElementById('gs-sd-url').value = d.data.url;
          uploadBtn.textContent = '✓ ' + file.name;
          document.getElementById('gs-sd-submit-btn').style.display = '';
        } else {
          uploadBtn.textContent = '📤 Choose File';
          msg((d.data && d.data.message) || 'Upload failed', false);
        }
      })
      .catch(function(){ uploadBtn.disabled = false; uploadBtn.textContent = '📤 Choose File'; msg('Network error', false); });
  });

  document.getElementById('gs-sd-submit-btn').addEventListener('click', function(){
    var btn = this;
    var docUrl = document.getElementById('gs-sd-url').value;
    var docType = document.getElementById('gs-sd-type').value;
    if (!docUrl) { msg('Please choose a file first.', false); return; }
    btn.disabled = true; btn.textContent = 'Submitting…';
    gsPost('gs_submit_safety_doc', { nonce: nonce, doc_type: docType, doc_url: docUrl },
      function(){ msg('Document submitted for review.', true); setTimeout(function(){ location.reload(); }, 1200); },
      function(e){ btn.disabled = false; btn.textContent = 'Submit for Review'; msg(e || 'Could not submit.', false); }
    );
  });
})();
</script>

<!-- Part 4.3 — Extended profile fields: categories, service area, FAQ, certs -->
<?php
$profile_listings = $vid ? $wpdb->get_results($wpdb->prepare(
    "SELECT li.id,li.listing_uid,li.title,li.city,li.category_id,li.status,c.name AS cat_name
     FROM {$pfx}listings li LEFT JOIN {$pfx}categories c ON c.id=li.category_id
     WHERE li.vendor_id=%d AND li.status IN('active','draft','pending') ORDER BY li.status ASC,li.created_at DESC LIMIT 10",$vid)) : [];
?>
<div class="gs-card" style="margin-top:16px">
  <div class="gs-card-title">🏢 Your Listings & Services</div>
  <?php if($profile_listings): ?>
  <div style="display:flex;flex-direction:column;gap:8px">
    <?php foreach($profile_listings as $pl):
      $lbadge = ['active'=>['#F0FDF4','#059669','Live'],'draft'=>['#F8FAFC','#64748B','Draft'],'pending'=>['#FFFBEB','#D97706','Pending']];
      $lb = $lbadge[$pl->status]??['#F8FAFC','#64748B','Unknown'];
    ?>
    <div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid #F8FAFC">
      <div style="flex:1">
        <div style="font-weight:600;font-size:.87rem"><?php echo esc_html($pl->title); ?></div>
        <div style="font-size:.74rem;color:#94A3B8"><?php echo esc_html($pl->cat_name??'—'); ?><?php echo $pl->city?' · '.esc_html($pl->city):''; ?><?php echo !empty($pl->listing_uid) ? ' · <span style="font-family:monospace">'.esc_html($pl->listing_uid).'</span>' : ''; ?></div>
      </div>
      <span style="font-size:.7rem;font-weight:700;padding:2px 8px;border-radius:8px;background:<?php echo $lb[0]; ?>;color:<?php echo $lb[1]; ?>"><?php echo $lb[2]; ?></span>
      <a href="<?php echo home_url('/vendor/create/?listing_id='.$pl->id); ?>" class="gs-btn gs-btn-ghost gs-btn-xs">✏ Edit</a>
    </div>
    <?php endforeach; ?>
  </div>
  <?php else: ?>
  <div style="text-align:center;padding:16px;color:#94A3B8;font-size:.84rem">No listings yet. <a href="<?php echo home_url('/vendor/create/'); ?>" style="color:#2563EB">Create your first listing →</a></div>
  <?php endif; ?>
  <div style="margin-top:12px"><a href="<?php echo home_url('/vendor/create/'); ?>" class="gs-btn gs-btn-primary gs-btn-sm">+ Add New Listing</a></div>
</div>

<div class="gs-card" style="margin-top:16px">
  <div class="gs-card-title">📍 Service Area & Visiting Charge</div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
    <div class="gs-fg">
      <label class="gs-lbl">Cities / Areas Served</label>
      <input id="gs-p-service-area" class="gs-inp" value="<?php echo esc_attr($vp->service_area??$vp->city??''); ?>" placeholder="Delhi, Gurgaon, Noida...">
      <div class="gs-hint">Comma-separated cities or areas</div>
    </div>
    <div class="gs-fg">
      <label class="gs-lbl">Minimum Visiting Charge (₹)</label>
      <input id="gs-p-visiting-charge" type="number" class="gs-inp" value="<?php echo esc_attr($vp->visiting_charge??''); ?>" placeholder="0 = free visit">
    </div>
  </div>
  <div class="gs-fg" style="margin-top:8px">
    <label class="gs-lbl">Business Tagline</label>
    <input id="gs-p-tagline" class="gs-inp" value="<?php echo esc_attr($vp->tagline??''); ?>" placeholder="Your 1-line pitch to clients">
  </div>
  <div style="margin-top:12px;text-align:right">
    <button class="gs-btn gs-btn-primary gs-btn-sm" onclick="gsSaveServiceArea()">💾 Save</button>
  </div>
</div>

<div class="gs-card" style="margin-top:16px">
  <div class="gs-card-title">❓ FAQ (up to 10)</div>
  <div id="gs-faq-list" style="display:flex;flex-direction:column;gap:8px;margin-bottom:12px">
    <?php
    $faq_data = ( is_array($vp->faq_data??null) ? $vp->faq_data : json_decode($vp->faq_data??'[]',true) ) ?: [];
    foreach(array_slice($faq_data,0,10) as $fi=>$fq): ?>
    <div style="display:grid;grid-template-columns:1fr 1fr auto;gap:8px;align-items:start">
      <input class="gs-inp gs-faq-q" value="<?php echo esc_attr($fq['question']??''); ?>" placeholder="Question">
      <input class="gs-inp gs-faq-a" value="<?php echo esc_attr($fq['answer']??''); ?>" placeholder="Answer">
      <button onclick="this.closest('div').remove()" style="background:#FEF2F2;border:1px solid #FECACA;color:#DC2626;border-radius:6px;padding:5px 8px;cursor:pointer">✕</button>
    </div>
    <?php endforeach; ?>
  </div>
  <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsFaqAdd()">+ Add Question</button>
  <button class="gs-btn gs-btn-primary gs-btn-sm" style="margin-left:8px" onclick="gsFaqSave()">💾 Save FAQs</button>
</div>

<script>
(function(){
  var nonce='<?php echo esc_js($nonce); ?>';

  window.gsSaveServiceArea=function(){
    var area=document.getElementById('gs-p-service-area').value;
    var charge=document.getElementById('gs-p-visiting-charge').value;
    var tagline=document.getElementById('gs-p-tagline').value;
    gsPost('gs_save_vendor_profile',{nonce:nonce,service_area:area,visiting_charge:charge,tagline:tagline},
      function(){gsToast('Saved!','success');},function(m){gsToast(m||'Failed','error');});
  };

  // Real fix — confirmed bug (Known Limitations): rows used to be looked up
  // by a static id ('faq-q-0', 'faq-q-1', ...) fixed at render/add time, and
  // the remove button deleted a row from the DOM with no re-indexing step.
  // Deleting a middle row then meant Save re-indexed from the CURRENT loop
  // position, reading a mismatched id and silently saving a wrong or empty
  // answer against the wrong question. Fixed by reading each row's inputs
  // by class + DOM position instead of by a static id — a row's saved
  // question/answer now always matches what is actually visible in that
  // position on screen, regardless of how many rows were deleted before it.
  var faqCount=<?php echo max(count($faq_data),0); ?>;
  window.gsFaqAdd=function(){
    if(faqCount>=10){gsToast('Maximum 10 FAQs','error');return;}
    var row=document.createElement('div');
    row.style.cssText='display:grid;grid-template-columns:1fr 1fr auto;gap:8px;align-items:start';
    row.innerHTML='<input class="gs-inp gs-faq-q" placeholder="Question">'
      +'<input class="gs-inp gs-faq-a" placeholder="Answer">'
      +'<button onclick="this.closest(\'div\').remove()" style="background:#FEF2F2;border:1px solid #FECACA;color:#DC2626;border-radius:6px;padding:5px 8px;cursor:pointer">✕</button>';
    document.getElementById('gs-faq-list').appendChild(row);
    faqCount++;
  };

  window.gsFaqSave=function(){
    var faqs=[];
    document.getElementById('gs-faq-list').querySelectorAll(':scope > div').forEach(function(row){
      var q=row.querySelector('.gs-faq-q')?.value?.trim();
      var a=row.querySelector('.gs-faq-a')?.value?.trim();
      if(q&&a) faqs.push({question:q,answer:a});
    });
    gsPost('gs_save_vendor_profile',{nonce:nonce,faq_data:JSON.stringify(faqs)},
      function(){gsToast('FAQs saved!','success');},function(m){gsToast(m||'Failed','error');});
  };
})();
</script>

<?php echo gs_render_screen_help( 'My Vendor Profile', [
  
  
], [
  [ 'mistake' => 'Editing Business Hours, Service Area/FAQ fields, and the main profile fields in one visit, then clicking only one of the several separate Save buttons', 'category' => 'workflow', 'see' => "This screen has at least three independent save actions — the top 'Save Profile' button, 'Save' under Service Area & Visiting Charge (gsSaveServiceArea), and 'Save FAQs' (gsFaqSave) — each of which posts only its own fields.", 'fix' => 'Save each section separately with its own button after editing it — clicking "Save Profile" at the top does not also save Service Area, Visiting Charge, Tagline, or FAQ changes made further down the page.', 'prevent' => 'Work through the page top to bottom, saving each card before moving to the next, rather than filling in the whole page and clicking only the first Save button seen.' ],
  [ 'mistake' => 'Adding more than 10 FAQs and expecting them all to save', 'category' => 'validation', 'see' => "Clicking '+ Add Question' past 10 entries shows a 'Maximum 10 FAQs' toast and simply does not add an 11th row.", 'fix' => 'Remove an existing FAQ first if a new one is needed once the 10-item cap is reached.', 'prevent' => 'Keep FAQ entries to the most valuable 10 questions, since the cap is enforced client-side with no way to exceed it.' ],
] ); ?>

<?php break;
// ══════════════════════════════════════════════════════════════════════════════
// SECTION: LISTINGS (vendor's own)
// ══════════════════════════════════════════════════════════════════════════════
case 'listings':
  // BUG FOUND & FIXED (v7.317.0) — see the matching note on the dashboard-
  // overview widget's query above: this tab's own query had the identical
  // missing filter, so the full "My Listings" table had the same
  // never-disappears-after-delete bug, not just the 6-row overview widget.
  $my_listings = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT l.*,c.name AS cat_name FROM {$pfx}listings l LEFT JOIN {$pfx}categories c ON c.id=l.category_id WHERE l.vendor_id=%d AND l.status != 'deleted' ORDER BY l.created_at DESC", $vid
  ) ) : [];
  // Real fix (Known Limitations): a per-listing breakdown was previously
  // unavailable anywhere on this screen — gallery is a cheap JSON field
  // already selected via l.* above, so a count is free (no extra query).
  // Real fix — under the vendor-wide storage policy, this number is
  // identical for every listing this vendor has (it's their whole media
  // library, not this-listing-only usage), so showing it as a per-row
  // "Images" column would repeat the exact same figure on every row —
  // confusing, and looks like a bug even though it wouldn't be one.
  // Computed once here instead of once per row in the loop below, and
  // shown as a single summary badge instead.
  $img_usage = $vid ? \GoodService\Service\SubscriptionService::get_vendor_photo_usage( $vid ) : [ 'used' => 0, 'limit' => 0, 'is_unlimited' => true ];
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">🏢 My Listings</div><div class="gs-ph-sub"><?php echo count($my_listings); ?> total listings <span style="margin-left:10px;color:<?php echo (!$img_usage['is_unlimited'] && $img_usage['used'] >= $img_usage['limit']) ? '#DC2626;font-weight:700' : 'inherit'; ?>">🖼 <?php echo (int) $img_usage['used']; ?><?php echo $img_usage['is_unlimited'] ? '' : ' / ' . (int) $img_usage['limit']; ?> images in your media library</span></div></div>
  <div style="display:flex;gap:8px">
    <button type="button" class="gs-btn gs-btn-ghost" onclick="gsOpenMediaLibraryPanel()">🖼 View Media Library</button>
    <a href="<?php echo home_url('/vendor/create/'); ?>" class="gs-btn gs-btn-primary">➕ Add New Listing</a>
  </div>
</div>
<?php if ( $my_listings ): ?>
<div class="gs-tbl-wrap">
  <table class="gs-tbl">
    <thead><tr><th>Listing</th><th>Type</th><th>Category</th><th>City</th><th>Status</th><th>Views</th><th>Leads</th><th>Images</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach ( $my_listings as $l ):
      $sc = ['active'=>'gs-badge-green','pending'=>'gs-badge-gold','draft'=>'gs-badge-grey','suspended'=>'gs-badge-red','rejected'=>'gs-badge-red'];
      $l_img_count = count( json_decode( $l->gallery ?? '[]', true ) ?: [] );
    ?>
    <tr data-lid="<?php echo (int)$l->id; ?>">
      <td>
        <div style="font-weight:700;font-size:.87rem"><?php echo esc_html($l->title); ?></div>
        <?php if($l->tagline): ?><div style="font-size:.73rem;color:var(--gs-muted)"><?php echo esc_html(substr($l->tagline,0,50)); ?></div><?php endif; ?>
      </td>
      <td><span class="gs-badge gs-badge-purple"><?php echo ucfirst($l->listing_type??'service'); ?></span></td>
      <td style="font-size:.82rem;color:var(--gs-muted)"><?php echo esc_html($l->cat_name??'—'); ?></td>
      <td style="font-size:.82rem"><?php echo esc_html($l->city??'—'); ?></td>
      <td><span class="gs-badge <?php echo $sc[$l->status]??'gs-badge-grey'; ?>"><?php echo ucfirst($l->status); ?></span></td>
      <td style="font-size:.82rem"><?php echo number_format($l->views_count); ?></td>
      <td style="font-size:.82rem"><?php echo $l->leads_count; ?></td>
      <td style="font-size:.82rem;color:var(--gs-muted)">🖼 <?php echo $l_img_count; ?></td>
      <td>
        <div style="display:flex;gap:4px;flex-wrap:wrap">
          <?php
            // FIX (enterprise hardening pass): this row used to render TWO near-duplicate
            // links — a "View/Preview" link gated on status==='active' (which made its own
            // embedded draft-preview branch permanently unreachable dead code, since a
            // draft listing never satisfies that guard), and a separate "Page" link below
            // it that WAS correctly reachable for drafts. Consolidated into one link that
            // covers active + draft + pending consistently, guarded on a non-empty slug so
            // we never emit a broken "/…/" URL for a listing that hasn't been slugged yet.
            $l_can_preview = ! empty( $l->slug ) && in_array( $l->status, [ 'active', 'draft', 'pending' ], true );
          ?>
          <?php if ( $l_can_preview ): ?>
          <a href="<?php echo esc_url( home_url( '/' . $l->slug . '/' ) . ( $l->status !== 'active' ? '?preview=1' : '' ) ); ?>" target="_blank" class="gs-btn gs-btn-ghost gs-btn-xs">👁 <?php echo $l->status === 'active' ? 'View' : 'Preview'; ?></a>
          <?php endif; ?>
          <a href="<?php echo home_url('/vendor/edit/'.$l->id.'/'); ?>" class="gs-btn gs-btn-primary gs-btn-xs">✏️ Edit</a>
          <button onclick="gsDuplicateListing(this,<?php echo (int)$l->id; ?>)" class="gs-btn gs-btn-ghost gs-btn-xs" aria-label="<?php echo esc_attr('Duplicate listing: '.$l->title); ?>">📄 Duplicate</button>
          <button onclick="if(confirm('Delete this listing?'))gsPost('gs_delete_listing',{nonce:'<?php echo esc_js($nonce); ?>',listing_id:<?php echo $l->id; ?>},function(){gsToast('Deleted','success');setTimeout(function(){location.reload();},800);})" class="gs-btn gs-btn-red gs-btn-xs" aria-label="<?php echo esc_attr('Delete listing: '.$l->title); ?>">🗑</button>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">🏢</div><div class="gs-empty-title">No listings yet</div><div>Create your first listing to appear in the directory.</div><a href="<?php echo home_url('/vendor/create/'); ?>" class="gs-btn gs-btn-primary" style="margin-top:14px">➕ Create First Listing</a></div>
<?php endif; ?>

<!-- Real feature — Media Library panel, reachable from the Listings tab.
     Previously there was no way to view the media library, or any
     per-image usage information, from vendor-dashboard.php at all — a
     vendor could only reach it by opening a specific listing for edit
     in create-listing.php. Reuses the exact same backend endpoints
     create-listing.php's version already uses (gs_list_my_media,
     gs_get_media_details, gs_delete_my_media) — one source of truth for
     usage detection, no separate/duplicated logic here. -->
<div id="gs-ml-panel" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);z-index:99000;align-items:center;justify-content:center;padding:20px" onclick="if(event.target===this)gsCloseMediaLibraryPanel()">
  <div style="background:#fff;border-radius:14px;max-width:900px;width:100%;max-height:88vh;display:flex;flex-direction:column;overflow:hidden">
    <div style="display:flex;justify-content:space-between;align-items:center;padding:16px 20px;border-bottom:1px solid #E2E8F0">
      <div style="font-weight:800;font-size:1rem">🖼 Your Media Library</div>
      <button type="button" onclick="gsCloseMediaLibraryPanel()" style="background:none;border:none;font-size:1.3rem;cursor:pointer;color:#64748B" aria-label="Close media library">&times;</button>
    </div>
    <div style="padding:12px 20px;border-bottom:1px solid #E2E8F0;display:flex;gap:8px;align-items:center">
      <input type="text" id="gs-ml-search" class="cl-input" placeholder="Search your files by name…" style="flex:1" oninput="gsMlDebouncedSearch()">
      <button type="button" class="gs-btn gs-btn-ghost" id="gs-ml-delete-mode-btn" onclick="gsMlToggleDeleteMode()">☑ Select to Delete</button>
    </div>
    <div id="gs-ml-bulk-bar" style="display:none;padding:10px 20px;border-bottom:1px solid #FCA5A5;background:#FEF2F2;align-items:center;justify-content:space-between;gap:10px">
      <span id="gs-ml-bulk-count" style="font-size:.82rem;font-weight:700;color:#991B1B">0 selected</span>
      <div style="display:flex;gap:8px">
        <button type="button" class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsMlToggleDeleteMode()">Cancel</button>
        <button type="button" class="gs-btn gs-btn-red gs-btn-sm" id="gs-ml-bulk-delete-btn" onclick="gsMlBulkDelete()" disabled>🗑 Delete Selected</button>
      </div>
    </div>
    <div id="gs-ml-usage-bar" style="padding:8px 20px;font-size:.78rem;color:#475569;background:#F8FAFC;border-bottom:1px solid #E2E8F0;display:flex;flex-direction:column;gap:2px"></div>
    <div id="gs-ml-grid" style="flex:1;overflow-y:auto;padding:16px 20px"></div>
  </div>
</div>
<script>
// Duplicate Listing row action — clones a listing (all settings/content/
// modules/customizer data/category/SEO) but never media, then redirects
// straight into editing the new copy.
// ROOT-CAUSE FIX: previously called gsBtnLoading($(btn),...) / gsPost(...) —
// jQuery ($) and the jQuery-wrapped gsPost/gsBtnLoading helpers. Rewritten to
// plain fetch + typeof-guarded nonce/ajaxUrl (the same defensive pattern the
// admin dashboard's already-proven gsDirectApprove uses) so a click still
// works even if jQuery isn't ready yet when this inline handler fires —
// previously that threw a silent "$ is not defined"/"gsPost is not defined"
// ReferenceError from the onclick attribute, with zero visible feedback:
// no loading state, no toast, no redirect. See admin-dashboard.php's
// gsAdminDuplicateListing for the matching admin-side fix and full writeup.
function gsDuplicateListing(btn, listingId) {
  if (!listingId) return;
  var nonce = (typeof GS !== 'undefined' && GS.nonce) ? GS.nonce : '<?php echo esc_js($nonce); ?>';
  var ajaxUrl = (typeof GS !== 'undefined' && GS.ajax_url) ? GS.ajax_url : '<?php echo esc_js(admin_url('admin-ajax.php')); ?>';
  var orig = btn ? btn.textContent : '';
  if (btn) { btn.disabled = true; btn.textContent = 'Duplicating…'; }
  var fd = new FormData();
  fd.append('action', 'gs_duplicate_listing');
  fd.append('nonce', nonce);
  fd.append('listing_id', listingId);
  // Intentionally no target_vendor_id — a vendor duplicating their own
  // listing always stays the owner. The admin-only vendor-picker lives in
  // admin-dashboard.php's gsAdminDuplicateListing only, and the server
  // enforces this too (a non-admin's target_vendor_id is ignored).
  fetch(ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d && d.success) {
        if (typeof gsToast === 'function') gsToast('Listing duplicated — add photos to the new listing.', 'success');
        setTimeout(function () { window.location.href = d.data.edit_url; }, 600);
      } else {
        if (btn) { btn.disabled = false; btn.textContent = orig; }
        var msg = (d && d.data && d.data.message) ? d.data.message : 'Could not duplicate listing.';
        if (typeof gsToast === 'function') gsToast(msg, 'error'); else alert('Error: ' + msg);
      }
    })
    .catch(function() {
      if (btn) { btn.disabled = false; btn.textContent = orig; }
      if (typeof gsToast === 'function') gsToast('Network error. Please try again.', 'error'); else alert('Network error. Please try again.');
    });
}
var _gsMlPage = 1;
var _gsMlSearchTimer = null;
var _gsMlDeleteMode = false;
var _gsMlDeleteSelected = {};
function gsOpenMediaLibraryPanel() {
  document.getElementById('gs-ml-panel').style.display = 'flex';
  gsMlLoadPage(1);
}
function gsCloseMediaLibraryPanel() {
  document.getElementById('gs-ml-panel').style.display = 'none';
}
function gsMlDebouncedSearch() {
  clearTimeout(_gsMlSearchTimer);
  _gsMlSearchTimer = setTimeout(function(){ gsMlLoadPage(1); }, 350);
}
function gsMlEsc(s) {
  var d = document.createElement('div');
  d.textContent = s || '';
  return d.innerHTML;
}
function gsMlLoadPage(page) {
  var grid = document.getElementById('gs-ml-grid');
  var usageBar = document.getElementById('gs-ml-usage-bar');
  grid.innerHTML = '<div style="text-align:center;padding:30px;color:#94A3B8">Loading your media…</div>';
  var search = document.getElementById('gs-ml-search').value.trim();
  gsPost('gs_list_my_media', { search: search, page: page, nonce: '<?php echo esc_js($nonce); ?>' }, function(d) {
    _gsMlPage = page;
    if (usageBar) {
      var lines = [];
      lines.push('<div><b>' + d.total + '</b> file' + (d.total === 1 ? '' : 's') + ' in your media library</div>');
      if (d.usage) {
        var u = d.usage;
        if (!u.is_unlimited) {
          var overLimit = u.used >= u.limit;
          lines.push('<div' + (overLimit ? ' style="color:#DC2626"' : '') + '><b>' + u.used + ' / ' + u.limit + '</b> images used on your plan limit' + (overLimit ? ' — at your plan limit, remove unused images below to upload more' : '') + '</div>');
        } else {
          lines.push('<div><b>' + u.used + '</b> images used (unlimited plan)</div>');
        }
      }
      usageBar.innerHTML = lines.join('');
    }
    if (!d.media || !d.media.length) {
      grid.innerHTML = '<div style="text-align:center;padding:30px;color:#94A3B8">' + (search ? 'No files match "' + search + '".' : 'No uploads yet.') + '</div>';
      return;
    }
    var html = '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:12px" id="gs-ml-inner-grid">';
    d.media.forEach(function(m) {
      var isImg = (m.file_type || '').indexOf('image') === 0;
      var thumb = isImg ? (m.thumbnail || m.url) : '';
      // Real fix — shows the actual usage count (how many listings
      // reference this file), not just a generic "In Use" label,
      // computed from the exact same scan the enforcement/rename-safety
      // features use, so it can never disagree with them.
      var badge = m.in_use ? ('Used ' + m.usage_count + 'x') : 'Unused';
      var isDelSelected = !!_gsMlDeleteSelected[m.id];
      html += '<div class="gs-ml-item" data-media-id="' + m.id + '" style="position:relative;border-radius:8px;overflow:hidden;background:#F8FAFC;aspect-ratio:1/1;cursor:' + (_gsMlDeleteMode ? 'pointer' : 'default') + ';outline:' + (isDelSelected ? '3px solid #DC2626' : 'none') + '" title="' + gsMlEsc(m.file_name) + '"' + (_gsMlDeleteMode ? ' onclick="gsMlToggleDeleteSelect(this,' + m.id + ')"' : '') + '>' +
        '<span class="gs-ml-checkbox" style="position:absolute;top:4px;left:4px;width:20px;height:20px;border-radius:5px;background:' + (isDelSelected ? '#DC2626' : 'rgba(255,255,255,.9)') + ';border:2px solid ' + (isDelSelected ? '#DC2626' : '#CBD5E1') + ';display:' + (_gsMlDeleteMode ? 'flex' : 'none') + ';align-items:center;justify-content:center;color:#fff;font-size:.75rem;font-weight:900;z-index:2">' + (isDelSelected ? '✓' : '') + '</span>' +
        (isImg ? '<img src="' + thumb + '" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block">' : '<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:2rem">📄</div>') +
        '<button type="button" onclick="event.stopPropagation();gsMlDeleteMedia(' + m.id + ')" title="Delete permanently" style="position:absolute;top:4px;right:4px;width:22px;height:22px;border-radius:50%;background:rgba(220,38,38,.9);color:#fff;border:none;cursor:pointer;font-size:.7rem;line-height:1">&#10005;</button>' +
        '<span style="position:absolute;bottom:4px;left:4px;font-size:.62rem;font-weight:700;padding:2px 7px;border-radius:99px;background:' + (m.in_use ? 'rgba(22,163,74,.9)' : 'rgba(100,116,139,.85)') + ';color:#fff">' + badge + '</span>' +
      '</div>';
    });
    html += '</div>';
    if (d.total > d.per_page) {
      var totalPages = Math.ceil(d.total / d.per_page);
      html += '<div style="display:flex;gap:6px;justify-content:center;margin-top:16px">';
      for (var p = 1; p <= totalPages; p++) {
        html += '<button type="button" class="gs-btn gs-btn-xs ' + (p === page ? 'gs-btn-primary' : 'gs-btn-ghost') + '" onclick="gsMlLoadPage(' + p + ')">' + p + '</button>';
      }
      html += '</div>';
    }
    grid.innerHTML = html;
  }, function(msg) { grid.innerHTML = '<div style="text-align:center;padding:30px;color:#DC2626">Could not load your media: ' + (msg||'unknown error') + '</div>'; });
}
function gsMlToggleDeleteMode() {
  _gsMlDeleteMode = !_gsMlDeleteMode;
  _gsMlDeleteSelected = {};
  var btn = document.getElementById('gs-ml-delete-mode-btn');
  if (btn) { btn.textContent = _gsMlDeleteMode ? '✕ Cancel Select' : '☑ Select to Delete'; }
  gsMlUpdateBulkBar();
  gsMlLoadPage(_gsMlPage);
}
function gsMlToggleDeleteSelect(el, mediaId) {
  if (_gsMlDeleteSelected[mediaId]) { delete _gsMlDeleteSelected[mediaId]; el.style.outline = 'none'; }
  else { _gsMlDeleteSelected[mediaId] = true; el.style.outline = '3px solid #DC2626'; }
  var cb = el.querySelector('.gs-ml-checkbox');
  if (cb) {
    var on = !!_gsMlDeleteSelected[mediaId];
    cb.style.background = on ? '#DC2626' : 'rgba(255,255,255,.9)';
    cb.style.borderColor = on ? '#DC2626' : '#CBD5E1';
    cb.textContent = on ? '✓' : '';
  }
  gsMlUpdateBulkBar();
}
function gsMlUpdateBulkBar() {
  var bar = document.getElementById('gs-ml-bulk-bar');
  var count = document.getElementById('gs-ml-bulk-count');
  var delBtn = document.getElementById('gs-ml-bulk-delete-btn');
  if (!bar) return;
  var n = Object.keys(_gsMlDeleteSelected).length;
  bar.style.display = _gsMlDeleteMode ? 'flex' : 'none';
  if (count) { count.textContent = n + ' selected'; }
  if (delBtn) { delBtn.disabled = n === 0; }
}
// Real feature, explicit request: bulk delete with confirmation, no
// page reload/jump afterward — removes exactly the successfully-deleted
// items from the DOM in place. One server round trip for the whole
// batch via gs_delete_my_media_bulk, which reports which files were
// actually deleted vs blocked (still in use).
function gsMlBulkDelete() {
  var ids = Object.keys(_gsMlDeleteSelected).map(Number);
  if (!ids.length) return;
  if (!confirm('Permanently delete ' + ids.length + ' file' + (ids.length > 1 ? 's' : '') + '? This deletes the actual files from storage — this cannot be undone. Files still used in a listing will be skipped automatically.')) return;
  var delBtn = document.getElementById('gs-ml-bulk-delete-btn');
  if (delBtn) { delBtn.disabled = true; delBtn.textContent = 'Deleting…'; }
  gsPost('gs_delete_my_media_bulk', { media_ids: JSON.stringify(ids), nonce: '<?php echo esc_js($nonce); ?>' }, function(d) {
    (d.deleted || []).forEach(function(id) {
      var el = document.querySelector('#gs-ml-inner-grid .gs-ml-item[data-media-id="' + id + '"]');
      if (el && el.parentNode) { el.parentNode.removeChild(el); }
      delete _gsMlDeleteSelected[id];
    });
    var blockedCount = (d.blocked || []).length;
    if (blockedCount) {
      gsToast((d.deleted || []).length + ' deleted, ' + blockedCount + ' skipped — still in use.', 'warning');
    } else {
      gsToast((d.deleted || []).length + ' file(s) permanently deleted.', 'info');
    }
    if (delBtn) { delBtn.disabled = false; delBtn.textContent = '🗑 Delete Selected'; }
    gsMlToggleDeleteMode(); // exit select mode after a successful batch
  }, function(msg) {
    gsToast(msg || 'Bulk delete failed.', 'error');
    if (delBtn) { delBtn.disabled = false; delBtn.textContent = '🗑 Delete Selected'; }
  });
}
// Real fix, explicit request: previously called gsMlLoadPage() again on
// success — a fresh fetch that rebuilt the entire grid, resetting
// scroll position and causing a visible jump every time a file was
// deleted. Now removes exactly the one deleted item's DOM node in
// place; everything else stays exactly where it was.
function gsMlDeleteMedia(mediaId) {
  if (!confirm('Permanently delete this file? This removes it from your media library AND deletes the actual file from storage — this cannot be undone. (If it\'s still used in any listing, deletion will be blocked until you remove it from those listings first.)')) return;
  gsPost('gs_delete_my_media', { media_id: mediaId, nonce: '<?php echo esc_js($nonce); ?>' }, function() {
    gsToast('Permanently deleted.', 'info');
    var el = document.querySelector('#gs-ml-inner-grid .gs-ml-item[data-media-id="' + mediaId + '"]');
    if (el && el.parentNode) { el.parentNode.removeChild(el); }
    var usageBar = document.getElementById('gs-ml-usage-bar');
    if (usageBar) {
      var firstLine = usageBar.querySelector('div');
      if (firstLine) {
        var match = firstLine.innerHTML.match(/<b>(\d+)<\/b>/);
        if (match) { firstLine.innerHTML = firstLine.innerHTML.replace('<b>' + match[1] + '</b>', '<b>' + Math.max(0, parseInt(match[1], 10) - 1) + '</b>'); }
      }
    }
  }, function(msg) { gsToast(msg || 'Could not delete file.', 'error'); });
}
</script>
<?php echo gs_render_screen_help( 'My Listings', [
  
  
], [
  [ 'mistake' => "Deleting a media file from the Media Library panel while assuming it will free up quota immediately even if it's still attached to a listing", 'category' => 'workflow', 'see' => "Bulk delete and single delete both report 'skipped — still in use' / block deletion when a file's usage_count shows it is referenced by a listing.", 'fix' => 'Remove the image from the listing itself (via Edit → the listing\'s photo fields) first, then delete it from the Media Library — deletion is blocked automatically to prevent breaking a live listing\'s images.', 'prevent' => 'Check the "Used Nx" / "Unused" badge on each file before attempting to delete it — only "Unused" files can be removed immediately.' ],
  [ 'mistake' => 'Clicking the red trash icon on a listing row expecting a "soft" hide/deactivate action', 'category' => 'workflow', 'see' => "The confirm() dialog says 'Delete this listing?' and, once confirmed, calls gs_delete_listing directly with no undo option shown afterward.", 'fix' => 'If the goal is to temporarily hide a listing rather than remove it permanently, edit the listing and change its status instead of using the Delete button here.', 'prevent' => 'Use Edit → change status to reversibly pause a listing; reserve the 🗑 Delete action in this table for listings meant to be removed for good.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: CREATE / EDIT LISTING (40 fields, 7-step wizard)
// ══════════════════════════════════════════════════════════════════════════════
// ──────────────────────────────────────────────────────────────────────────
// SECTION: CREATE / EDIT LISTING
// Handled by early redirect (lines 19-35 above) to /vendor/create/ and
// /vendor/edit/<id>/ which serve create-listing.php — the unified form used
// by both admin and vendor. This case block is kept as a safety fallback only.
// ──────────────────────────────────────────────────────────────────────────
case 'create': case 'edit':
  // The early PHP redirect above catches these before any HTML output.
  // This fallback handles any edge case where the redirect didn't fire.
  $fb_lid = (int)( $_GET['listing_id'] ?? 0 );
  wp_safe_redirect( $fb_lid ? home_url( '/vendor/edit/' . $fb_lid . '/' ) : home_url( '/vendor/create/' ) );
  exit;
// ══════════════════════════════════════════════════════════════════════════════
// SECTION: PRODUCTS

// ══════════════════════════════════════════════════════════════════════════════
case 'products':
  $prod_listings = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT id,title,products_data FROM {$pfx}listings WHERE vendor_id=%d AND listing_type IN('product','both') AND status IN('active','pending','draft') ORDER BY created_at DESC", $vid
  ) ) : [];
?>
<div class="gs-ph"><div><div class="gs-ph-title">📦 Products</div><div class="gs-ph-sub">Products across all your listings</div></div><a href="<?php echo home_url('/vendor/create/'); ?>" class="gs-btn gs-btn-primary">➕ Add Product Listing</a></div>
<?php $found=false; foreach($prod_listings as $pl):
  $prods=json_decode($pl->products_data??'[]',true)?:[];
  $found=true;
?>
<div class="gs-card">
  <div class="gs-card-title"><?php echo esc_html($pl->title); ?> <a href="<?php echo home_url('/vendor/edit/'.$pl->id.'/'); ?>" class="gs-btn gs-btn-ghost gs-btn-xs" style="float:right">✏️ Edit Listing</a></div>
  <?php if(empty($prods)): ?>
  <div style="font-size:.82rem;color:var(--gs-muted);padding:10px 0">No products added yet — <a href="<?php echo home_url('/vendor/edit/'.$pl->id.'/'); ?>">edit this listing</a> to add some.</div>
  <?php else: ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px">
    <?php foreach($prods as $p_idx=>$p): if(empty($p['name']))continue; ?>
    <div style="background:#F8FAFC;border:1px solid var(--gs-border);border-radius:10px;padding:14px">
      <?php if(!empty($p['image'])): ?><img src="<?php echo esc_url($p['image']); ?>" style="width:100%;height:100px;object-fit:cover;border-radius:7px;margin-bottom:10px"><?php endif; ?>
      <div style="font-weight:700;font-size:.88rem;color:var(--gs-dark)"><?php echo esc_html($p['name']); ?></div>
      <?php if(!empty($p['price'])&&(float)$p['price']>0): ?>
        <div style="font-weight:700;color:var(--gs-primary);margin-top:4px;font-size:.88rem">
          ₹<?php echo number_format((float)$p['price']); ?><?php if(!empty($p['price_unit'])): ?> / <?php echo esc_html($p['price_unit']); ?><?php endif; ?>
          <?php if(($p['price_type']??'')==='per_unit'): ?> <span style="font-size:.7rem;color:var(--gs-muted)">per unit</span><?php endif; ?>
        </div>
      <?php elseif(($p['price_type']??'')==='on_request'): ?>
        <div style="font-weight:700;color:var(--gs-gold);margin-top:4px;font-size:.82rem">Price on Request</div>
      <?php endif; ?>
      <?php if(!empty($p['description'])): ?><div style="font-size:.78rem;color:var(--gs-muted);margin-top:4px"><?php echo esc_html($p['description']); ?></div><?php endif; ?>
      <?php if(!empty($p['availability'])): ?><span class="gs-badge gs-badge-green" style="margin-top:7px;display:inline-flex"><?php echo ucfirst(str_replace('_',' ',$p['availability'])); ?></span><?php endif; ?>
      <div style="margin-top:9px">
        <button class="gs-btn gs-btn-ghost gs-btn-xs" onclick="gsQuickEditProduct(<?php echo (int)$pl->id; ?>,<?php echo (int)$p_idx; ?>,<?php echo esc_js(json_encode(['price'=>$p['price']??'','availability'=>$p['availability']??'in_stock','name'=>$p['name']])); ?>)">⚡ Quick Edit (price/availability)</button>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php endforeach; if(!$found): ?>
<div class="gs-empty"><div class="gs-empty-icon">📦</div><div class="gs-empty-title">No product listings yet</div><div>Create a listing with type "Product" or "Both" to manage your product catalogue here.</div><a href="<?php echo home_url('/vendor/create/'); ?>" class="gs-btn gs-btn-primary" style="margin-top:14px">Create Product Listing</a></div>
<?php endif; ?>
<!-- Quick-edit modal (FIXED — Known Limitations audit: this screen used to be fully read-only) -->
<div id="gs-qep-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:14px;padding:22px;width:min(340px,95vw)">
    <div style="font-weight:800;font-size:.95rem;color:#1E293B;margin-bottom:4px" id="gs-qep-title">Quick Edit</div>
    <div style="font-size:.76rem;color:#94A3B8;margin-bottom:14px">Price and availability only — for name, image, or description, use the full listing editor.</div>
    <input type="hidden" id="gs-qep-listing-id"><input type="hidden" id="gs-qep-idx">
    <div class="gs-fg"><label class="gs-lbl">Price (₹)</label><input type="number" id="gs-qep-price" class="gs-inp" min="0" step="0.01"></div>
    <div class="gs-fg"><label class="gs-lbl">Availability</label><select id="gs-qep-avail" class="gs-sel"><option value="in_stock">In Stock</option><option value="out_of_stock">Out of Stock</option><option value="made_to_order">Made to Order</option></select></div>
    <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:6px">
      <button class="gs-btn gs-btn-ghost" onclick="document.getElementById('gs-qep-modal').style.display='none'">Cancel</button>
      <button class="gs-btn gs-btn-primary" onclick="gsQuickEditProductSave()">Save</button>
    </div>
  </div>
</div>
<script>
function gsQuickEditProduct(listingId, idx, p){
  document.getElementById('gs-qep-title').textContent = 'Quick Edit — ' + p.name;
  document.getElementById('gs-qep-listing-id').value = listingId;
  document.getElementById('gs-qep-idx').value = idx;
  document.getElementById('gs-qep-price').value = p.price || '';
  document.getElementById('gs-qep-avail').value = p.availability || 'in_stock';
  document.getElementById('gs-qep-modal').style.display = 'flex';
}
function gsQuickEditProductSave(){
  gsPost('gs_quick_edit_product', {
    nonce: '<?php echo esc_js($nonce); ?>',
    listing_id: document.getElementById('gs-qep-listing-id').value,
    product_index: document.getElementById('gs-qep-idx').value,
    price: document.getElementById('gs-qep-price').value,
    availability: document.getElementById('gs-qep-avail').value
  }, function(){
    document.getElementById('gs-qep-modal').style.display = 'none';
    gsToast('Product updated!', 'success'); setTimeout(function(){ location.reload(); }, 700);
  }, function(m){ gsToast(m || 'Could not update product', 'error'); });
}
</script>
<?php echo gs_render_screen_help( 'Products', [
  
  
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: SERVICES
// ══════════════════════════════════════════════════════════════════════════════
case 'services':
  $svc_listings = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT id,title,services_data FROM {$pfx}listings WHERE vendor_id=%d AND listing_type IN('service','both') AND status IN('active','pending','draft') ORDER BY created_at DESC", $vid
  ) ) : [];
?>
<div class="gs-ph"><div><div class="gs-ph-title">🛠️ Services</div><div class="gs-ph-sub">Services across all your listings</div></div><a href="<?php echo home_url('/vendor/create/'); ?>" class="gs-btn gs-btn-primary">➕ Add Service Listing</a></div>
<?php $found=false; foreach($svc_listings as $sl):
  $svcs=json_decode($sl->services_data??'[]',true)?:[];
  $found=true;
?>
<div class="gs-card">
  <div class="gs-card-title"><?php echo esc_html($sl->title); ?> <a href="<?php echo home_url('/vendor/edit/'.$sl->id.'/'); ?>" class="gs-btn gs-btn-ghost gs-btn-xs" style="float:right">✏️ Edit</a></div>
  <?php if(empty($svcs)): ?>
  <div style="font-size:.82rem;color:var(--gs-muted);padding:10px 0">No services added yet — <a href="<?php echo home_url('/vendor/edit/'.$sl->id.'/'); ?>">edit this listing</a> to add some.</div>
  <?php else: ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:11px">
    <?php foreach($svcs as $sv_idx=>$sv): if(empty($sv['name']))continue; ?>
    <div style="background:#F8FAFC;border:1px solid var(--gs-border);border-radius:10px;padding:14px">
      <?php if(!empty($sv['icon'])): ?><div style="font-size:1.5rem;margin-bottom:7px"><?php echo esc_html($sv['icon']); ?></div><?php endif; ?>
      <div style="font-weight:700;font-size:.88rem;color:var(--gs-dark)"><?php echo esc_html($sv['name']); ?></div>
      <?php if(!empty($sv['price'])&&(float)$sv['price']>0): ?>
        <div style="font-weight:700;color:var(--gs-primary);margin-top:4px;font-size:.88rem">
          ₹<?php echo number_format((float)$sv['price']); ?>
          <?php if(($sv['price_type']??'')==='starting'): ?><span style="font-weight:400;font-size:.74rem;color:var(--gs-muted)"> onwards</span><?php endif; ?>
        </div>
      <?php endif; ?>
      <?php if(!empty($sv['duration'])): ?><div style="font-size:.74rem;color:var(--gs-muted);margin-top:3px">⏱ <?php echo esc_html($sv['duration']); ?></div><?php endif; ?>
      <?php if(!empty($sv['description'])): ?><div style="font-size:.77rem;color:var(--gs-muted);margin-top:5px;line-height:1.5"><?php echo esc_html($sv['description']); ?></div><?php endif; ?>
      <div style="margin-top:9px">
        <button class="gs-btn gs-btn-ghost gs-btn-xs" onclick="gsQuickEditService(<?php echo (int)$sl->id; ?>,<?php echo (int)$sv_idx; ?>,<?php echo esc_js(json_encode(['price'=>$sv['price']??'','duration'=>$sv['duration']??'','name'=>$sv['name']])); ?>)">⚡ Quick Edit (price/duration)</button>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php endforeach; if(!$found): ?>
<div class="gs-empty"><div class="gs-empty-icon">🛠️</div><div class="gs-empty-title">No service listings yet</div><a href="<?php echo home_url('/vendor/create/'); ?>" class="gs-btn gs-btn-primary" style="margin-top:14px">Create Service Listing</a></div>
<?php endif; ?>
<!-- Quick-edit modal (FIXED — Known Limitations audit: this screen used to be fully read-only, mirroring Products) -->
<div id="gs-qes-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:14px;padding:22px;width:min(340px,95vw)">
    <div style="font-weight:800;font-size:.95rem;color:#1E293B;margin-bottom:4px" id="gs-qes-title">Quick Edit</div>
    <div style="font-size:.76rem;color:#94A3B8;margin-bottom:14px">Price and duration only — for name, icon, or description, use the full listing editor.</div>
    <input type="hidden" id="gs-qes-listing-id"><input type="hidden" id="gs-qes-idx">
    <div class="gs-fg"><label class="gs-lbl">Price (₹)</label><input type="number" id="gs-qes-price" class="gs-inp" min="0" step="0.01"></div>
    <div class="gs-fg"><label class="gs-lbl">Duration</label><input type="text" id="gs-qes-duration" class="gs-inp" placeholder="e.g. 30 mins, 1-2 hours"></div>
    <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:6px">
      <button class="gs-btn gs-btn-ghost" onclick="document.getElementById('gs-qes-modal').style.display='none'">Cancel</button>
      <button class="gs-btn gs-btn-primary" onclick="gsQuickEditServiceSave()">Save</button>
    </div>
  </div>
</div>
<script>
function gsQuickEditService(listingId, idx, sv){
  document.getElementById('gs-qes-title').textContent = 'Quick Edit — ' + sv.name;
  document.getElementById('gs-qes-listing-id').value = listingId;
  document.getElementById('gs-qes-idx').value = idx;
  document.getElementById('gs-qes-price').value = sv.price || '';
  document.getElementById('gs-qes-duration').value = sv.duration || '';
  document.getElementById('gs-qes-modal').style.display = 'flex';
}
function gsQuickEditServiceSave(){
  gsPost('gs_quick_edit_service', {
    nonce: '<?php echo esc_js($nonce); ?>',
    listing_id: document.getElementById('gs-qes-listing-id').value,
    service_index: document.getElementById('gs-qes-idx').value,
    price: document.getElementById('gs-qes-price').value,
    duration: document.getElementById('gs-qes-duration').value
  }, function(){
    document.getElementById('gs-qes-modal').style.display = 'none';
    gsToast('Service updated!', 'success'); setTimeout(function(){ location.reload(); }, 700);
  }, function(m){ gsToast(m || 'Could not update service', 'error'); });
}
</script>
<?php echo gs_render_screen_help( 'Services', [
  
  
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: LEADS
// ══════════════════════════════════════════════════════════════════════════════
case 'leads':
  // ── Inquiry Manager — IndiaMART-style split-pane UI ──────────────────────
  require GS_DIR . 'templates/pages/partials/inquiry-manager.php';
  echo gs_render_screen_help( 'Leads (Inquiry Manager)', [
    
    
  ], [
    [ 'mistake' => 'Assuming the "new" inquiries count updates instantly the moment a customer submits a form', 'category' => 'workflow', 'see' => "The badge/count only refreshes on the 60-second poll cycle or after a manual list reload — a just-submitted inquiry may not appear as 'new' immediately even though it exists in the database.", 'fix' => 'Manually reload the Leads screen if an inquiry is expected right now and hasn\'t appeared yet, rather than assuming the feature is broken.', 'prevent' => 'Understand this screen refreshes automatically at most once per minute; treat the visible count as near-real-time, not instantaneous.' ],
    [ 'mistake' => 'Filtering by staff member, category, or listing and then forgetting the filter is still active on a later visit', 'category' => 'incorrect-settings', 'see' => 'The filter dropdowns (staff, inquiry category, listing) persist selections that make the "new inquiries" list appear shorter than expected, with no obvious "N filters active" indicator once collapsed.', 'fix' => 'Check and clear any active filters at the top of the split-pane view if the expected leads are not showing up.', 'prevent' => 'Reset filters back to "All" after finishing a filtered review, rather than leaving a narrow filter applied for the next visit.' ],
  ] );
  break;
// ══════════════════════════════════════════════════════════════════════════════
// SECTION: REVIEWS
// ══════════════════════════════════════════════════════════════════════════════
case 'reviews':
  // Listing filter — same pattern as Leads/Bookings/Calendar. A vendor with
  // different services (e.g. "AC Repair" vs "Plumbing") may want to see
  // each listing's reviews and rating separately.
  $rev_listings = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT id, title FROM {$pfx}listings WHERE vendor_id=%d ORDER BY title ASC", $vid
  ) ) : [];
  $rev_filter_listing_id = (int) ( $_GET['listing_id'] ?? 0 );
  $rev_filter_valid = false;
  foreach ( $rev_listings as $rvl ) { if ( (int)$rvl->id === $rev_filter_listing_id ) { $rev_filter_valid = true; break; } }
  if ( ! $rev_filter_valid ) { $rev_filter_listing_id = 0; }
  $rev_per = 50;
  $rev_pg  = max(1,(int)($_GET['rev_pg']??1));
  $rev_off = ($rev_pg-1)*$rev_per;

  if ( $rev_filter_listing_id ) {
    $rev_total = (int) $wpdb->get_var($wpdb->prepare(
      "SELECT COUNT(*) FROM {$pfx}reviews WHERE vendor_id=%d AND listing_id=%d", $vid, $rev_filter_listing_id
    ));
    $reviews_all = $wpdb->get_results($wpdb->prepare(
      "SELECT r.*,li.title as lt FROM {$pfx}reviews r LEFT JOIN {$pfx}listings li ON r.listing_id=li.id WHERE r.vendor_id=%d AND r.listing_id=%d ORDER BY r.created_at DESC LIMIT %d OFFSET %d",
      $vid, $rev_filter_listing_id, $rev_per, $rev_off
    ));
    $rev_avg = (float)$wpdb->get_var($wpdb->prepare(
      "SELECT COALESCE(AVG(rating),0) FROM {$pfx}reviews WHERE vendor_id=%d AND listing_id=%d AND status='approved'", $vid, $rev_filter_listing_id
    ));
  } else {
    $rev_total = $vid ? (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}reviews WHERE vendor_id=%d",$vid)) : 0;
    $reviews_all = $vid ? $wpdb->get_results($wpdb->prepare(
      "SELECT r.*,li.title as lt FROM {$pfx}reviews r LEFT JOIN {$pfx}listings li ON r.listing_id=li.id WHERE r.vendor_id=%d ORDER BY r.created_at DESC LIMIT %d OFFSET %d",$vid,$rev_per,$rev_off
    )) : [];
    $rev_avg = $vid ? (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(AVG(rating),0) FROM {$pfx}reviews WHERE vendor_id=%d AND status='approved'",$vid)) : 0;
  }
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">⭐ Reviews</div><div class="gs-ph-sub"><?php echo $rev_avg>0?'Average: '.number_format($rev_avg,1).' ⭐ (approved reviews only)':'Not yet rated'; ?></div></div>
  <a href="<?php echo esc_url( admin_url( 'admin-ajax.php' ) . '?action=gs_export_vendor_reviews_csv&nonce=' . wp_create_nonce( 'gs_ajax' ) . ( $rev_filter_listing_id ? '&listing_id=' . $rev_filter_listing_id : '' ) ); ?>" class="gs-btn gs-btn-ghost gs-btn-sm">⬇ Export CSV</a>
</div>
<?php if ( count( $rev_listings ) > 1 ): ?>
<div class="gs-card" style="margin-bottom:14px">
  <label class="gs-lbl">Listing</label>
  <select class="gs-sel" onchange="window.location.href='?section=reviews'+(this.value?'&listing_id='+this.value:'')">
    <option value="">All listings</option>
    <?php foreach ( $rev_listings as $rvl ): ?>
    <option value="<?php echo (int)$rvl->id; ?>" <?php echo (int)$rvl->id===$rev_filter_listing_id?'selected':''; ?>><?php echo esc_html($rvl->title); ?></option>
    <?php endforeach; ?>
  </select>
</div>
<?php endif; ?>
<?php if($reviews_all): foreach($reviews_all as $r):
  $sc=['approved'=>'gs-badge-green','pending'=>'gs-badge-gold','rejected'=>'gs-badge-red'];
?>
<div class="gs-rev-card">
  <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:10px">
    <div>
      <div style="font-weight:700;font-size:.87rem;color:var(--gs-dark)"><?php echo esc_html($r->reviewer_name?:'Anonymous'); ?></div>
      <div style="font-size:.72rem;color:var(--gs-muted)"><?php echo esc_html($r->lt??''); ?> · <?php echo gs_time_ago($r->created_at); ?></div>
      <div class="gs-stars" style="margin-top:4px"><?php echo str_repeat('★',(int)$r->rating).str_repeat('☆',5-(int)$r->rating); ?></div>
    </div>
    <span class="gs-badge <?php echo $sc[$r->status]??'gs-badge-grey'; ?>"><?php echo ucfirst($r->status); ?></span>
  </div>
  <?php if($r->review_text): ?><div style="font-size:.87rem;color:#475569;line-height:1.65;margin-bottom:10px"><?php echo nl2br(esc_html($r->review_text)); ?></div><?php endif; ?>
  <?php if($r->reply_text): ?>
  <div style="background:#F0FDF4;border-left:3px solid var(--gs-green);padding:10px 13px;border-radius:0 8px 8px 0">
    <div style="font-size:.7rem;font-weight:700;color:var(--gs-green);margin-bottom:3px">Your Reply:</div>
    <div style="font-size:.84rem;color:#334155"><?php echo nl2br(esc_html($r->reply_text)); ?></div>
  </div>
  <?php else: ?>
  <div id="gs-reply-area-<?php echo $r->id; ?>" style="display:none;margin-top:10px">
    <textarea id="gs-reply-txt-<?php echo $r->id; ?>" class="gs-ta" rows="2" placeholder="Write a public reply to this review..."></textarea>
    <div style="display:flex;gap:6px;margin-top:6px">
      <button onclick="gsReplyRev(<?php echo $r->id; ?>)" class="gs-btn gs-btn-primary gs-btn-sm">Post Reply</button>
      <button onclick="document.getElementById('gs-reply-area-<?php echo $r->id; ?>').style.display='none'" class="gs-btn gs-btn-ghost gs-btn-sm">Cancel</button>
    </div>
  </div>
  <button onclick="document.getElementById('gs-reply-area-<?php echo $r->id; ?>').style.display='block';this.style.display='none'" class="gs-btn gs-btn-ghost gs-btn-xs">💬 Reply</button>
  <?php endif; ?>

  <?php
  // Sub-rating pills (Part 12.4)
  $subs = array_filter(['Punctuality'=>(int)($r->punctuality_rating??0),'Quality'=>(int)($r->quality_rating??0),'Cleanliness'=>(int)($r->cleanliness_rating??0),'Value'=>(int)($r->price_rating??0)]);
  if($subs): ?>
  <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">
    <?php foreach($subs as $lbl=>$val): if(!$val) continue; ?>
    <span style="font-size:.67rem;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:2px 7px;color:#64748B"><?php echo $lbl; ?>: <strong><?php echo $val; ?>/5</strong></span>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <!-- Flag button (Part 12.4) -->
  <div style="margin-top:8px;display:flex;justify-content:flex-end">
    <button onclick="if(confirm('Flag this review by &quot;<?php echo esc_js($r->reviewer_name??'Anonymous'); ?>&quot; for admin moderation?'))gsPost('gs_flag_review',{nonce:'<?php echo esc_js($nonce); ?>',review_id:<?php echo $r->id; ?>},function(){gsToast('Flagged for admin review','info');this.textContent='✓ Flagged';this.disabled=true;}.bind(this),function(m){gsToast(m||'Failed','error');});"
          class="gs-btn gs-btn-xs" style="background:#FFF7ED;color:#C2410C;border-color:#FED7AA;font-size:.68rem"
                aria-label="<?php echo esc_attr('Flag review by '.($r->reviewer_name??'Unknown').' as suspicious'); ?>">🚩 Flag as suspicious</button>
  </div>
</div>
<?php endforeach; else: ?>
<?php if ( $rev_filter_listing_id ): ?>
<div class="gs-empty"><div class="gs-empty-icon">⭐</div><div class="gs-empty-title">No reviews for this listing</div><div>This listing has no reviews yet. <a href="?section=reviews">View all listings</a></div></div>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">⭐</div><div class="gs-empty-title">No reviews yet</div><div>Customer reviews appear here automatically once they start coming in.</div></div>
<?php endif; ?>
<?php endif; ?>
<?php if($rev_total > $rev_per): $rev_pages = ceil($rev_total/$rev_per); ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px;font-size:.85rem;color:var(--gs-muted)">
  <span>Showing <?php echo count($reviews_all); ?> of <?php echo $rev_total; ?> reviews</span>
  <div style="display:flex;gap:8px">
    <?php if($rev_pg>1): ?><a class="gs-btn gs-btn-sm gs-btn-ghost" href="?section=reviews<?php echo $rev_filter_listing_id?'&listing_id='.$rev_filter_listing_id:''; ?>&rev_pg=<?php echo $rev_pg-1; ?>">← Prev</a><?php endif; ?>
    <span>Page <?php echo $rev_pg; ?> of <?php echo $rev_pages; ?></span>
    <?php if($rev_pg<$rev_pages): ?><a class="gs-btn gs-btn-sm gs-btn-ghost" href="?section=reviews<?php echo $rev_filter_listing_id?'&listing_id='.$rev_filter_listing_id:''; ?>&rev_pg=<?php echo $rev_pg+1; ?>">Next →</a><?php endif; ?>
  </div>
</div>
<?php endif; ?>
<script>
function gsReplyRev(rid){
  var txt=document.getElementById('gs-reply-txt-'+rid).value.trim();
  if(!txt){gsToast('Enter reply text','error');return;}
  gsPost('gs_reply_review',{nonce:'<?php echo esc_js($nonce); ?>',review_id:rid,reply:txt},function(){
    gsToast('Reply posted!','success'); setTimeout(function(){location.reload();},1000);
  });
}
</script>
<?php echo gs_render_screen_help( 'Reviews', [
  
  
], [
  [ 'mistake' => 'Replying to a review and expecting the reply to appear immediately without a page reload', 'category' => 'unexpected-behavior', 'see' => "gsReplyRev() posts the reply then calls location.reload() after a 1-second delay — there is a brief window where clicking Post Reply appears to do nothing before the page refreshes.", 'fix' => 'Wait for the toast confirmation and the automatic page reload after clicking Post Reply rather than clicking it multiple times.', 'prevent' => 'A single click is sufficient — the button intentionally does not disable itself during that 1-second window, so avoid double-clicking Post Reply.' ],
  [ 'mistake' => "Flagging a review expecting it to be immediately hidden from the vendor's own feed or from the public listing", 'category' => 'workflow', 'see' => "Clicking '🚩 Flag as suspicious' only marks the button '✓ Flagged' and disables it — the review itself remains visible here and on the public listing page pending actual admin review.", 'fix' => 'Understand that flagging only queues the review for admin moderation — it does not remove or hide the review by itself. Contact the platform admin directly if urgent removal is needed.', 'prevent' => "Use flagging for genuinely suspicious content and expect a delay before an admin actions it, rather than treating it as an instant-hide control." ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: QUESTIONS (Part 22 — Public Q&A)
// ══════════════════════════════════════════════════════════════════════════════
// Real feature — closes the confirmed gap: the Q&A submit/answer
// backend and the public-facing answered-questions display were both
// built, but this management page — where a vendor actually sees and
// answers pending questions — was never built. Structured identically
// to the Reviews section right above it.
case 'questions':
  $qa_per = 50;
  $qa_pg  = max(1,(int)($_GET['qa_pg']??1));
  $qa_off = ($qa_pg-1)*$qa_per;
  // Real fix: an admin editing a specific listing (create-listing.php's
  // "Questions & Answers" nav item) previously landed here with $vid=0 —
  // admins have no vendor_profiles row, so this whole section silently
  // showed nothing, with no indication why. Rather than require the
  // heavier admin-impersonation flow just to view one listing's questions,
  // an admin who arrives with a real listing_id (and only an admin — never
  // a vendor spoofing another vendor's listing_id) is scoped to that one
  // listing's questions directly.
  $qa_listing_id = (int) ( $_GET['listing_id'] ?? 0 );
  $qa_is_admin_listing_view = $qa_listing_id && \GoodService\Core\Roles::is_admin_level();
  if ( $qa_is_admin_listing_view ) {
      $qa_total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$pfx}listing_questions WHERE listing_id=%d", $qa_listing_id ) );
      $questions_all = $wpdb->get_results( $wpdb->prepare(
        "SELECT q.*, li.title as lt FROM {$pfx}listing_questions q LEFT JOIN {$pfx}listings li ON q.listing_id=li.id
         WHERE q.listing_id=%d ORDER BY (q.status='pending') DESC, q.created_at DESC LIMIT %d OFFSET %d", $qa_listing_id, $qa_per, $qa_off
      ) );
  } else {
      $qa_total = $vid ? (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}listing_questions WHERE vendor_id=%d",$vid)) : 0;
      $questions_all = $vid ? $wpdb->get_results( $wpdb->prepare(
        "SELECT q.*, li.title as lt FROM {$pfx}listing_questions q LEFT JOIN {$pfx}listings li ON q.listing_id=li.id
         WHERE q.vendor_id=%d ORDER BY (q.status='pending') DESC, q.created_at DESC LIMIT %d OFFSET %d", $vid, $qa_per, $qa_off
      ) ) : [];
  }
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">❓ Questions</div><div class="gs-ph-sub"><?php echo $qa_is_admin_listing_view ? 'Showing questions for this listing only' : ( $pend_questions ? $pend_questions . ' waiting for your answer' : 'All caught up' ); ?></div></div>
</div>
<?php if ( $questions_all ): foreach ( $questions_all as $q ):
  $qsc = [ 'pending' => 'gs-badge-gold', 'answered' => 'gs-badge-green', 'hidden' => 'gs-badge-grey' ];
?>
<div class="gs-rev-card">
  <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:10px">
    <div>
      <div style="font-weight:700;font-size:.87rem;color:var(--gs-dark)"><?php echo esc_html( $q->asker_name ?: 'Anonymous' ); ?></div>
      <div style="font-size:.72rem;color:var(--gs-muted)"><?php echo esc_html( $q->lt ?? '' ); ?> · <?php echo gs_time_ago( $q->created_at ); ?></div>
    </div>
    <span class="gs-badge <?php echo $qsc[ $q->status ] ?? 'gs-badge-grey'; ?>"><?php echo ucfirst( $q->status ); ?></span>
  </div>
  <div style="font-size:.87rem;color:#475569;line-height:1.65;margin-bottom:10px">❓ <?php echo nl2br( esc_html( $q->question_text ) ); ?></div>
  <?php if ( $q->vendor_answer ): ?>
  <div id="gs-qa-view-<?php echo $q->id; ?>" style="background:#F0FDF4;border-left:3px solid var(--gs-green);padding:10px 13px;border-radius:0 8px 8px 0">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">
      <div style="font-size:.7rem;font-weight:700;color:var(--gs-green);margin-bottom:3px">Your Answer:</div>
      <button onclick="gsEditAnswer(<?php echo $q->id; ?>)" class="gs-btn gs-btn-ghost gs-btn-xs" style="flex-shrink:0">✏️ Edit</button>
    </div>
    <div style="font-size:.84rem;color:#334155"><?php echo nl2br( esc_html( $q->vendor_answer ) ); ?></div>
  </div>
  <div id="gs-qa-area-<?php echo $q->id; ?>" style="display:none;margin-top:10px">
    <textarea id="gs-qa-txt-<?php echo $q->id; ?>" class="gs-ta" rows="2"><?php echo esc_textarea( $q->vendor_answer ); ?></textarea>
    <div style="display:flex;gap:6px;margin-top:6px">
      <button onclick="gsAnswerQuestion(<?php echo $q->id; ?>)" class="gs-btn gs-btn-primary gs-btn-sm">Save Answer</button>
      <button onclick="document.getElementById('gs-qa-area-<?php echo $q->id; ?>').style.display='none';document.getElementById('gs-qa-view-<?php echo $q->id; ?>').style.display='block'" class="gs-btn gs-btn-ghost gs-btn-sm">Cancel</button>
    </div>
  </div>
  <?php else: ?>
  <div id="gs-qa-area-<?php echo $q->id; ?>" style="margin-top:10px">
    <textarea id="gs-qa-txt-<?php echo $q->id; ?>" class="gs-ta" rows="2" placeholder="Write a public answer to this question…"></textarea>
    <div style="display:flex;gap:6px;margin-top:6px">
      <button onclick="gsAnswerQuestion(<?php echo $q->id; ?>)" class="gs-btn gs-btn-primary gs-btn-sm">Post Answer</button>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php endforeach; else: ?>
<div class="gs-empty"><div class="gs-empty-icon">❓</div><div class="gs-empty-title">No questions yet</div><div>Visitor questions from your listing pages appear here automatically.</div></div>
<?php endif; ?>
<?php if($qa_total > $qa_per): $qa_pages = ceil($qa_total/$qa_per); ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px;font-size:.85rem;color:var(--gs-muted)">
  <span>Showing <?php echo count($questions_all); ?> of <?php echo $qa_total; ?> questions</span>
  <div style="display:flex;gap:8px">
    <?php if($qa_pg>1): ?><a class="gs-btn gs-btn-sm gs-btn-ghost" href="?section=questions&qa_pg=<?php echo $qa_pg-1; ?>">← Prev</a><?php endif; ?>
    <span>Page <?php echo $qa_pg; ?> of <?php echo $qa_pages; ?></span>
    <?php if($qa_pg<$qa_pages): ?><a class="gs-btn gs-btn-sm gs-btn-ghost" href="?section=questions&qa_pg=<?php echo $qa_pg+1; ?>">Next →</a><?php endif; ?>
  </div>
</div>
<?php endif; ?>
<script>
function gsAnswerQuestion(qid){
  var txt=document.getElementById('gs-qa-txt-'+qid).value.trim();
  if(!txt){gsToast('Enter an answer','error');return;}
  gsPost('gs_answer_question',{nonce:'<?php echo esc_js($nonce); ?>',question_id:qid,answer:txt},function(){
    gsToast('Answer saved!','success'); setTimeout(function(){location.reload();},1000);
  }, function(msg){ gsToast(msg||'Could not post answer','error'); });
}
function gsEditAnswer(qid){
  var view=document.getElementById('gs-qa-view-'+qid);
  var area=document.getElementById('gs-qa-area-'+qid);
  if(view) view.style.display='none';
  if(area) area.style.display='block';
}
</script>
<?php echo gs_render_screen_help( 'Questions (Public Q&A)', [
  
  
], [
  [ 'mistake' => 'Assuming an answered question is automatically removed from the public listing page once no longer "pending"', 'category' => 'workflow', 'see' => 'Answered questions remain visible with their answer shown publicly on the listing — the "answered" status is not a hide/archive action.', 'fix' => 'If a question and its answer should no longer be shown publicly, this specific screen has no hide control — contact the platform admin, since only pending/answered/hidden as a data status exists, not a vendor-facing hide toggle here.', 'prevent' => 'Only answer questions the vendor is comfortable having permanently visible on the public listing page.' ],
  [ 'mistake' => "Writing an answer in the text box and navigating away without clicking 'Post Answer'", 'category' => 'data-entry', 'see' => 'Draft answer text is not auto-saved — leaving the page or reloading discards anything typed but not submitted.', 'fix' => 'Click "Post Answer" before leaving the page; if lost, the question remains in "pending" status and the answer can simply be re-typed and submitted again.', 'prevent' => 'Write longer answers elsewhere first (notes app, etc.) and paste them in immediately before submitting, to avoid losing work to an accidental navigation.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: MESSAGES
// ══════════════════════════════════════════════════════════════════════════════
case 'messages':
  $thread_id = (int)($_GET['thread']??0);
  $msg_view  = sanitize_key($_GET['mview']??'active'); // active | archived
  // Real fix, critical bug (confirmed during Known Limitations audit): this
  // query filtered "AND t.status='open'", but gs_message_threads has NO
  // status column at all (schema uses per-participant is_archived_a/
  // is_archived_b instead) — every load of this screen has been running a
  // query against a nonexistent column, which $wpdb silently swallows as an
  // empty result set. The Messages screen has therefore been showing "No
  // conversations yet" unconditionally, regardless of how many real threads
  // exist, for as long as this code has run. Fixed to filter on the correct
  // per-participant archive flag, with an Active/Archived tab replacing the
  // status filter that never worked.
  $msg_archive_expr = "(CASE WHEN t.participant_a=%d THEN t.is_archived_a ELSE t.is_archived_b END)";
  $threads   = $wpdb->get_results($wpdb->prepare(
    // Unbounded-growth fix: a long-lived vendor/customer account can accumulate
    // thousands of threads over years; without a cap this rendered the
    // entire history into HTML on every single page load. Capped consistently
    // with getMessages()'s existing LIMIT 100 pattern in AjaxController.
    "SELECT t.*,u.display_name as oname FROM {$pfx}message_threads t LEFT JOIN {$wpdb->prefix}users u ON u.ID=(CASE WHEN t.participant_a=%d THEN t.participant_b ELSE t.participant_a END) WHERE (t.participant_a=%d OR t.participant_b=%d) AND {$msg_archive_expr}=%d ORDER BY t.last_message_at DESC LIMIT 100",
    $uid,$uid,$uid,$uid,$msg_view==='archived'?1:0
  ));
?>
<div class="gs-ph"><div class="gs-ph-title">💬 Messages</div></div>
<div style="display:flex;gap:8px;margin-bottom:12px">
  <a href="?section=messages" class="gs-btn gs-btn-sm <?php echo $msg_view==='active'?'gs-btn-primary':'gs-btn-ghost'; ?>">Active</a>
  <a href="?section=messages&mview=archived" class="gs-btn gs-btn-sm <?php echo $msg_view==='archived'?'gs-btn-primary':'gs-btn-ghost'; ?>">Archived</a>
</div>
<div class="gs-msg-grid">
  <div class="gs-msg-list">
    <div style="padding:11px;border-bottom:1px solid var(--gs-border);font-weight:700;font-size:.82rem;color:var(--gs-dark)">Conversations</div>
    <?php foreach($threads as $t):
      $uk=$t->participant_a==$uid?'unread_a':'unread_b'; $unr=$t->$uk;
    ?>
    <div onclick="gsLoadThread(<?php echo $t->id; ?>)" id="gs-thr-<?php echo $t->id; ?>" style="padding:11px;cursor:pointer;border-bottom:1px solid #F1F5F9;display:flex;gap:9px;align-items:center;transition:.12s;background:<?php echo $thread_id==$t->id?'#EFF6FF':'#fff'; ?>">
      <div style="width:34px;height:34px;border-radius:50%;background:var(--gs-primary);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.82rem;flex-shrink:0"><?php echo strtoupper(substr($t->oname??'U',0,1)); ?></div>
      <div style="flex:1;min-width:0">
        <div style="font-weight:600;font-size:.83rem;display:flex;align-items:center;gap:5px"><?php echo esc_html($t->oname??'Support'); ?><?php if($unr): ?><span style="background:#EF4444;color:#fff;border-radius:99px;font-size:.56rem;padding:1px 4px"><?php echo $unr; ?></span><?php endif; ?></div>
        <div style="font-size:.72rem;color:#94A3B8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo esc_html(substr($t->last_message??'',0,38)); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if(!$threads): ?><div class="gs-empty" style="padding:28px 12px"><div style="font-size:1.8rem">💬</div><div style="font-size:.78rem;margin-top:6px">No conversations yet</div></div><?php endif; ?>
  </div>
  <div class="gs-msg-chat">
    <div id="gs-chat-hdr" style="padding:11px 15px;border-bottom:1px solid var(--gs-border);display:flex;align-items:center;justify-content:space-between;gap:10px">
      <div style="font-weight:700;font-size:.87rem;color:var(--gs-dark)" id="gs-chat-hdr-txt">Select a conversation</div>
      <button id="gs-chat-archive-btn" style="display:none" class="gs-btn gs-btn-xs gs-btn-ghost" onclick="gsToggleArchive()"><?php echo $msg_view==='archived'?'↩ Restore':'🗄 Archive'; ?></button>
    </div>
    <div id="gs-chat-area" class="gs-msg-area">
      <div style="text-align:center;color:#94A3B8;font-size:.81rem;padding-top:60px">Select a conversation to read messages</div>
    </div>
    <div style="padding:11px;border-top:1px solid var(--gs-border);position:relative">
      <!-- ENTERPRISE-AUDIT FIX (Part 3, Low-Medium: Quick Replies had no
           per-template conversion analytics — root cause was that the
           feature was never wired into the actual message-compose flow at
           all, so there was nothing to have usage data on. This picker is
           that wiring: gs_get_quick_replies() now has a real caller, and
           inserting a template here is the one place gs_use_quick_reply
           (usage-count tracking) is ever called. -->
      <div id="gs-qr-panel" style="display:none;position:absolute;bottom:100%;left:11px;right:11px;margin-bottom:6px;background:#fff;border:1px solid var(--gs-border);border-radius:10px;box-shadow:0 6px 20px rgba(0,0,0,.12);max-height:260px;overflow-y:auto;z-index:20"></div>
      <div style="display:flex;gap:7px">
        <textarea id="gs-msg-inp" class="gs-ta" rows="2" placeholder="Type a message… (Enter to send, Shift+Enter for new line)" style="flex:1;min-height:0;resize:none"></textarea>
        <div style="display:flex;flex-direction:column;gap:6px;align-self:flex-end">
          <button type="button" id="gs-qr-toggle" class="gs-btn gs-btn-ghost gs-btn-sm" title="Insert a quick reply">⚡ Quick Reply</button>
          <button id="gs-msg-send" class="gs-btn gs-btn-primary">Send</button>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
var gsActiveThread=<?php echo $thread_id?:0; ?>;
var gsUid=<?php echo $uid; ?>;
var gsMsgPollTimer=null;
var gsMsgLastCount=0;
// Real fix (Known Limitations): an open thread previously only fetched
// messages once — a reply sent while the vendor had it open never
// appeared without a manual reload. Poll every 20s while a thread is
// active (cleared on switching threads/unload), mirroring the pattern
// already used by the Leads/Inquiry Manager screen's live updates.
function gsStartMsgPoll(tid){
  if(gsMsgPollTimer) clearInterval(gsMsgPollTimer);
  gsMsgPollTimer=setInterval(function(){
    if(gsActiveThread!==tid || document.hidden) return;
    gsPost('gs_get_messages',{nonce:'<?php echo esc_js($nonce); ?>',thread_id:tid},function(d){
      if(gsActiveThread!==tid) return;
      var count=(d.messages||[]).length;
      if(count!==gsMsgLastCount){ gsRenderThread(d); gsMsgLastCount=count; }
    });
  },20000);
}
window.addEventListener('beforeunload',function(){ if(gsMsgPollTimer) clearInterval(gsMsgPollTimer); });
function gsRenderThread(d){
  var html='';
  if(d.messages&&d.messages.length){
    d.messages.forEach(function(m){
      var mine=m.sender_id==gsUid;
      html+='<div style="display:flex;justify-content:'+(mine?'flex-end':'flex-start')+'">'
        +'<div style="max-width:68%;background:'+(mine?'var(--gs-primary)':'#F1F5F9')+';color:'+(mine?'#fff':'#1E293B')+';padding:9px 13px;border-radius:12px;font-size:.84rem;line-height:1.5">'
        +jQuery('<div>').text(m.message||'').html()
        +'<div style="font-size:.62rem;opacity:.55;margin-top:3px;text-align:right">'+m.created_at+'</div></div></div>';
    });
  } else { html='<div style="text-align:center;color:#94A3B8;font-size:.8rem;padding:40px 0">No messages yet. Start the conversation!</div>'; }
  document.getElementById('gs-chat-area').innerHTML=html;
  document.getElementById('gs-chat-area').scrollTop=9999;
  if(d.other_name){
    var hdrHtml=document.createElement('div').appendChild(document.createTextNode(d.other_name)).parentNode.innerHTML;
    if(d.listing_title){
      hdrHtml+='<div style="font-weight:400;font-size:.74rem;color:#2563EB;margin-top:2px">'+
        document.createElement('div').appendChild(document.createTextNode(d.listing_title)).parentNode.innerHTML+'</div>';
    }
    document.getElementById('gs-chat-hdr-txt').innerHTML=hdrHtml;
  }
  document.getElementById('gs-chat-archive-btn').style.display='inline-block';
}
function gsToggleArchive(){
  if(!gsActiveThread) return;
  var archiving = '<?php echo $msg_view==='archived'?'0':'1'; ?>';
  gsPost('gs_toggle_thread_archive',{nonce:'<?php echo esc_js($nonce); ?>',thread_id:gsActiveThread,archived:archiving},function(d){
    gsToast(d.message||'Done','success');
    setTimeout(function(){ window.location.href='?section=messages'; },700);
  },function(m){ gsToast(m||'Failed','error'); });
}
function gsLoadThread(tid){
  gsActiveThread=tid;
  document.querySelectorAll('[id^="gs-thr-"]').forEach(function(el){el.style.background=el.id==='gs-thr-'+tid?'#EFF6FF':'#fff';});
  document.getElementById('gs-chat-area').innerHTML='<div style="text-align:center;color:#94A3B8;font-size:.8rem;padding:30px">Loading…</div>';
  gsPost('gs_get_messages',{nonce:'<?php echo esc_js($nonce); ?>',thread_id:tid},function(d){
    gsMsgLastCount=(d.messages||[]).length;
    gsRenderThread(d);
    gsStartMsgPoll(tid);
  });
}
document.getElementById('gs-msg-send').addEventListener('click',function(){
  if(!gsActiveThread){gsToast('Select a conversation first','warning');return;}
  var txt=document.getElementById('gs-msg-inp').value.trim(); if(!txt) return;
  gsPost('gs_send_message',{nonce:'<?php echo esc_js($nonce); ?>',thread_id:gsActiveThread,message:txt},function(){
    document.getElementById('gs-msg-inp').value=''; gsLoadThread(gsActiveThread);
  });
});
document.getElementById('gs-msg-inp').addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();document.getElementById('gs-msg-send').click();}});
// ── Quick Reply picker (ENTERPRISE-AUDIT FIX, Part 3) ───────────────────────
var gsQrLoaded=false;
function gsRenderQrPanel(replies){
  var panel=document.getElementById('gs-qr-panel');
  if(!replies||!replies.length){
    panel.innerHTML='<div style="padding:16px;text-align:center;color:#94A3B8;font-size:.8rem">No quick replies yet. <a href="?section=quick_replies" style="color:var(--gs-primary)">Create one →</a></div>';
    return;
  }
  var html='';
  replies.forEach(function(r){
    var preview=(r.body||'').length>90?r.body.slice(0,90)+'…':(r.body||'');
    html+='<div class="gs-qr-item" data-id="'+r.id+'" style="padding:10px 13px;border-bottom:1px solid #F1F5F9;cursor:pointer" onmouseover="this.style.background=\'#F8FAFC\'" onmouseout="this.style.background=\'\'">'
      +'<div style="font-weight:600;font-size:.82rem;color:var(--gs-dark)">'+jQuery('<div>').text(r.title||'').html()+'</div>'
      +'<div style="font-size:.76rem;color:#64748B;margin-top:2px">'+jQuery('<div>').text(preview).html()+'</div></div>';
  });
  panel.innerHTML=html;
  panel.querySelectorAll('.gs-qr-item').forEach(function(el){
    el.addEventListener('click',function(){
      var id=parseInt(el.getAttribute('data-id'),10);
      var reply=replies.find(function(r){return parseInt(r.id,10)===id;});
      if(!reply) return;
      var ta=document.getElementById('gs-msg-inp');
      ta.value=(ta.value?ta.value+' ':'')+reply.body;
      ta.focus();
      panel.style.display='none';
      // Usage-frequency tracking — see useQuickReply() docblock for why this
      // is scoped as "used X times", never claimed as a conversion metric.
      gsPost('gs_use_quick_reply',{nonce:'<?php echo esc_js($nonce); ?>',reply_id:id},function(){},function(){});
    });
  });
}
document.getElementById('gs-qr-toggle').addEventListener('click',function(){
  var panel=document.getElementById('gs-qr-panel');
  if(panel.style.display==='block'){ panel.style.display='none'; return; }
  panel.style.display='block';
  if(!gsQrLoaded){
    panel.innerHTML='<div style="padding:16px;text-align:center;color:#94A3B8;font-size:.8rem">Loading…</div>';
    gsPost('gs_get_quick_replies',{nonce:'<?php echo esc_js($nonce); ?>'},function(d){
      gsQrLoaded=true;
      gsRenderQrPanel(d.replies||[]);
    },function(){ panel.innerHTML='<div style="padding:16px;text-align:center;color:#DC2626;font-size:.8rem">Could not load quick replies.</div>'; });
  }
});
document.addEventListener('click',function(e){
  var panel=document.getElementById('gs-qr-panel'), toggle=document.getElementById('gs-qr-toggle');
  if(panel.style.display==='block' && !panel.contains(e.target) && e.target!==toggle){ panel.style.display='none'; }
});
<?php if($thread_id): ?>document.addEventListener('DOMContentLoaded',function(){jQuery(function(){gsLoadThread(<?php echo $thread_id; ?>);});});<?php endif; ?>
</script>
<?php echo gs_render_screen_help( 'Messages', [
  
  
], [
  [ 'mistake' => 'Assuming a message was sent because the text box cleared, without checking for a toast confirmation or the message appearing in the thread', 'category' => 'unexpected-behavior', 'see' => "document.getElementById('gs-msg-inp').value=''; gsLoadThread(gsActiveThread); runs inside the gs_send_message success callback — if the AJAX request itself fails, the textarea is not cleared (the clear only happens in the success path), but a vendor might not notice a failed-send toast on a busy screen.", 'fix' => 'Confirm the sent message actually appears in the reloaded thread view before assuming it went through; if the textarea still contains the typed text after clicking Send, the send failed.', 'prevent' => 'Watch for the message bubble to appear on the right side of the chat area after sending, rather than relying only on the textarea clearing.' ],
  [ 'mistake' => 'Trying to send a message before selecting a conversation from the list', 'category' => 'workflow', 'see' => "Clicking Send with no active thread shows a 'Select a conversation first' warning toast and does nothing else.", 'fix' => 'Click a conversation in the left-hand list first — the chat header will change from "Select a conversation" to the other participant\'s name once one is active.', 'prevent' => 'Look for the highlighted (light blue background) row in the conversation list to confirm a thread is selected before typing a reply.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: SUBSCRIPTION
// ══════════════════════════════════════════════════════════════════════════════
case 'subscription':
  $plans=$wpdb->get_results("SELECT * FROM {$pfx}subscription_plans WHERE is_active=1 ORDER BY sort_order ASC");
  // Section 8/9 fix (manual subscription workflow audit): if the vendor already
  // has an open (non-terminal) request, don't let them start a confusing
  // duplicate from a plan card — point them at the existing one instead.
  $_open_mp_request = $vid ? $wpdb->get_row($wpdb->prepare(
    "SELECT id, plan_name, status FROM {$pfx}plan_requests
     WHERE vendor_id=%d AND is_deleted=0
       AND status IN ('pending','under_review','payment_verification_pending','info_required','on_hold')
     ORDER BY created_at DESC LIMIT 1", $vid
  )) : null;
?>
<div class="gs-ph"><div class="gs-ph-title">💳 Subscription &amp; Payment</div></div>
<div style="display:flex;gap:8px;margin-bottom:20px;border-bottom:2px solid #F1F5F9">
  <a href="?section=subscription" style="padding:10px 4px;font-size:.86rem;font-weight:700;color:#2563EB;border-bottom:2px solid #2563EB;margin-bottom:-2px;text-decoration:none">📋 Plans &amp; Payment</a>
  <a href="?section=invoices" style="padding:10px 16px;font-size:.86rem;font-weight:600;color:#64748B;text-decoration:none">🧾 Invoices &amp; Receipts</a>
</div>

<?php
// ENTERPRISE-AUDIT FIX (Part 3, large, deliberately deferred: "no saved
// payment methods"). See AjaxController's getSavedPaymentMethods() etc.
?>
<div class="gs-card" style="margin-bottom:18px">
  <div class="gs-card-title">💳 Saved Payment Methods</div>
  <div id="gs-spm-list" style="font-size:.84rem;color:#64748B">Loading…</div>
  <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
    <button type="button" onclick="gsAddStripeCard()" id="gs-spm-add-stripe" class="gs-btn gs-btn-ghost" style="display:none">➕ Add Card (Stripe)</button>
  </div>
  <div id="gs-spm-razorpay-note" style="font-size:.78rem;color:#94A3B8;margin-top:8px;display:none">Cards paid via Razorpay are saved automatically when you check "Save this card" during checkout above.</div>
  <div id="gs-spm-msg" class="gs-imsg" style="margin-top:8px"></div>
</div>
<script>
(function(){
  function esc(s){ return (s==null?'':String(s)).replace(/[&<>"']/g, function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
  function brandIcon(b){ b=(b||'').toLowerCase(); return b==='visa'?'💳':b==='mastercard'?'💳':'💳'; }
  window.gsSpmData = { stripe_configured:false, stripe_public_key:'', razorpay_configured:false };
  window.gsRenderSpmList = function(methods){
    var el = document.getElementById('gs-spm-list');
    if (!methods || !methods.length) { el.innerHTML = 'No saved cards yet.'; return; }
    var html = '';
    methods.forEach(function(m){
      html += '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid #F1F5F9">'
        + '<div>' + brandIcon(m.card_brand) + ' ' + esc((m.card_brand||'Card')) + ' •••• ' + esc(m.card_last4||'----')
        + (m.is_default==1 ? ' <span style="background:#DCFCE7;color:#166534;font-size:.68rem;padding:1px 6px;border-radius:4px;margin-left:6px">Default</span>' : '')
        + ' <span style="color:#94A3B8;font-size:.72rem">(' + esc(m.gateway) + ')</span></div>'
        + '<div style="display:flex;gap:6px">'
        + (m.is_default!=1 ? '<button type="button" class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsSetDefaultSpm(' + m.id + ')">Set Default</button>' : '')
        + '<button type="button" class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsRenewWithSpm(' + m.id + ')">Renew Now</button>'
        + '<button type="button" class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsDeleteSpm(' + m.id + ')" style="color:#DC2626">Remove</button>'
        + '</div></div>';
    });
    el.innerHTML = html;
  };
  window.gsLoadSpm = function(){
    gsPost('gs_get_saved_payment_methods', {}, function(d){
      window.gsSpmData = d;
      gsRenderSpmList(d.methods);
      if (d.stripe_configured) { document.getElementById('gs-spm-add-stripe').style.display = ''; }
      if (d.razorpay_configured) { document.getElementById('gs-spm-razorpay-note').style.display = ''; }
    }, function(){ document.getElementById('gs-spm-list').textContent = 'Could not load saved cards.'; });
  };
  window.gsDeleteSpm = function(id){
    if (!confirm('Remove this saved card?')) return;
    gsPost('gs_delete_saved_payment_method', {id:id}, function(){ gsToast('Card removed.','success'); gsLoadSpm(); }, function(m){ gsToast(m||'Failed','error'); });
  };
  window.gsSetDefaultSpm = function(id){
    gsPost('gs_set_default_payment_method', {id:id}, function(){ gsToast('Default updated.','success'); gsLoadSpm(); }, function(m){ gsToast(m||'Failed','error'); });
  };
  window.gsRenewWithSpm = function(id){
    if (!confirm('Charge your saved card now to renew your current subscription?')) return;
    gsToast('Processing renewal…','info');
    gsPost('gs_renew_with_saved_method', {id:id}, function(d){ gsToast(d.message||'Renewed!','success'); setTimeout(function(){location.reload();},1200); }, function(m){ gsToast(m||'Renewal failed','error'); });
  };
  window.gsAddStripeCard = function(){
    var msg = document.getElementById('gs-spm-msg');
    msg.textContent = '';
    function doSetup(){
      gsPost('gs_create_stripe_setup_intent', {}, function(d){
        if (!window.gsStripeInstance) { window.gsStripeInstance = Stripe(window.gsSpmData.stripe_public_key); }
        var elements = window.gsStripeInstance.elements();
        var html = '<div id="gs-spm-card-el" style="padding:10px;border:1px solid #E2E8F0;border-radius:8px;margin-bottom:12px"></div><div id="gs-spm-card-err" style="color:#DC2626;font-size:.8rem;margin-bottom:8px"></div>';
        gsModal.show(html, { title:'Add a card', size:'sm',
          footer: '<button class="gs-btn gs-btn-ghost" onclick="gsModal.hide()">Cancel</button><button class="gs-btn gs-btn-primary" id="gs-spm-save-btn" onclick="gsConfirmStripeSetup(\'' + d.client_secret + '\')">Save Card</button>'
        });
        var cardEl = elements.create('card');
        cardEl.mount('#gs-spm-card-el');
        window.gsStripeCardEl = cardEl;
      }, function(m){ msg.className='gs-imsg err'; msg.textContent = '❌ ' + (m||'Could not start card setup.'); });
    }
    if (!window.Stripe) {
      var s = document.createElement('script'); s.src = 'https://js.stripe.com/v3/'; s.onload = doSetup; document.head.appendChild(s);
    } else { doSetup(); }
  };
  window.gsConfirmStripeSetup = function(clientSecret){
    var btn = document.getElementById('gs-spm-save-btn');
    var err = document.getElementById('gs-spm-card-err');
    if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
    window.gsStripeInstance.confirmCardSetup(clientSecret, { payment_method: { card: window.gsStripeCardEl } }).then(function(result){
      if (result.error) {
        err.textContent = result.error.message || 'Card setup failed.';
        if (btn) { btn.disabled = false; btn.textContent = 'Save Card'; }
        return;
      }
      gsPost('gs_save_stripe_payment_method', { payment_method_id: result.setupIntent.payment_method }, function(){
        gsModal.hide(); gsToast('Card saved!','success'); gsLoadSpm();
      }, function(m){ err.textContent = m || 'Could not save card.'; if (btn) { btn.disabled = false; btn.textContent = 'Save Card'; } });
    });
  };
  gsLoadSpm();
})();
</script>

<?php if($_open_mp_request): ?>
<div class="gs-card" style="border-left:4px solid #F59E0B;margin-bottom:18px;background:#FFFBEB">
  <div style="font-weight:700;color:#92400E">⏳ You have an open request for "<?php echo esc_html($_open_mp_request->plan_name); ?>"</div>
  <div style="font-size:.84rem;color:#B45309;margin-top:4px">Please wait for it to be reviewed, or update it below, before starting a new plan request.</div>
</div>
<?php endif; ?>
<?php if($sub): ?>
<div class="gs-card" style="background:linear-gradient(135deg,var(--gs-dark),var(--gs-primary));color:#fff;border:none;margin-bottom:22px">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px">
    <div>
      <div style="font-size:.78rem;opacity:.6;margin-bottom:4px">Current Plan</div>
      <div style="font-size:1.9rem;font-weight:900"><?php echo esc_html($sub->plan_name); ?></div>
      <div style="font-size:.86rem;opacity:.72;margin-top:3px"><?php echo $sub->expires_at?'Expires '.date('d M Y',strtotime($sub->expires_at)):'Active — No expiry'; ?></div>
    </div>
    <span style="background:rgba(255,255,255,.18);padding:5px 16px;border-radius:20px;font-size:.8rem;font-weight:700"><?php echo strtoupper($sub->status); ?></span>
  </div>
  <div style="margin-top:16px;padding-top:14px;border-top:1px solid rgba(255,255,255,.14);display:flex;gap:20px;flex-wrap:wrap">
    <div><div style="font-size:.7rem;opacity:.5">Listings</div><div style="font-weight:700"><?php echo $sub->max_listings==-1?'Unlimited':$sub->max_listings; ?></div></div>
    <div><div style="font-size:.7rem;opacity:.5">Images</div><div style="font-weight:700"><?php echo $sub->max_images==-1?'Unlimited':$sub->max_images; ?></div></div>
    <div><div style="font-size:.7rem;opacity:.5">WhatsApp</div><div style="font-weight:700"><?php echo $sub->show_whatsapp?'✅':'❌'; ?></div></div>
    <div><div style="font-size:.7rem;opacity:.5">Analytics</div><div style="font-weight:700"><?php echo $sub->show_analytics?'✅':'❌'; ?></div></div>
    <div><div style="font-size:.7rem;opacity:.5">Featured</div><div style="font-weight:700"><?php echo $sub->is_featured?'✅':'❌'; ?></div></div>
  </div>
  <?php
    // ENTERPRISE-AUDIT FIX (Critical finding): AjaxController::cancelSubscription()
    // has always been fully implemented server-side — nonce + require_vendor,
    // logs to gs_activity_log, flags the invoice payment_treatment for admin
    // review rather than guessing a financial outcome — but no button on this
    // screen ever called it. A paying vendor had no self-service way to cancel
    // their own plan; only an admin could do it. Shown only when there's an
    // active/trialing subscription to cancel (this block is already scoped to
    // that by the surrounding "if ($sub)"), so it never renders for a vendor
    // already on the free tier with nothing to cancel.
  ?>
  <div style="margin-top:14px;padding-top:14px;border-top:1px solid rgba(255,255,255,.14);text-align:right">
    <button type="button" onclick="gsVendorCancelSubscription()" id="gs-vendor-cancel-sub-btn"
            style="background:transparent;border:1px solid rgba(255,255,255,.35);color:rgba(255,255,255,.85);font-size:.78rem;font-weight:600;padding:7px 14px;border-radius:6px;cursor:pointer">
      Cancel Plan
    </button>
  </div>
</div>
<script>
function gsVendorCancelSubscription(){
  if (!confirm('Cancel your "<?php echo esc_js($sub->plan_name ?? 'current'); ?>" plan? You will be moved to the Free plan immediately. This cannot be undone from here — you would need to re-subscribe to get the plan back.')) return;
  var btn = document.getElementById('gs-vendor-cancel-sub-btn');
  btn.disabled = true; btn.textContent = 'Cancelling…';
  gsPost('gs_cancel_subscription', { nonce: '<?php echo wp_create_nonce('gs_ajax'); ?>' },
    function(d){ gsToast(d.message || 'Subscription cancelled.', 'success'); setTimeout(function(){ location.reload(); }, 900); },
    function(m){ btn.disabled = false; btn.textContent = 'Cancel Plan'; gsToast(m || 'Failed to cancel subscription.', 'error'); }
  );
}
</script>
<?php endif; ?>
<div class="gs-plan-grid">
  <?php foreach($plans as $pl): $isc=$sub&&$sub->plan_id==$pl->id; ?>
  <div class="gs-plan-card <?php echo $isc?'on':''; ?>" <?php echo $pl->badge_text?'style="padding-top:38px"':''; ?>>
    <?php if($pl->badge_text): ?><div style="position:absolute;top:0;left:50%;transform:translateX(-50%);background:<?php echo esc_attr($pl->color??'#2563EB'); ?>;color:#fff;font-size:.67rem;font-weight:700;padding:3px 14px;border-radius:0 0 8px 8px"><?php echo esc_html($pl->badge_text); ?></div><?php endif; ?>
    <div style="font-size:.98rem;font-weight:800;color:var(--gs-dark);margin-bottom:5px"><?php echo esc_html($pl->name); ?></div>
    <div style="font-size:1.8rem;font-weight:900;color:<?php echo esc_attr($pl->color??'#2563EB'); ?>;margin-bottom:3px">
      <?php echo $pl->price_monthly>0?'₹'.number_format($pl->price_monthly).'<span style="font-size:.82rem;font-weight:400;color:var(--gs-muted)">/mo</span>':'Free'; ?>
    </div>
    <?php if($pl->price_yearly>0): ?><div style="font-size:.73rem;color:var(--gs-muted);margin-bottom:12px">or ₹<?php echo number_format($pl->price_yearly); ?>/yr (save <?php echo round((1-$pl->price_yearly/($pl->price_monthly*12))*100); ?>%)</div><?php endif; ?>
    <div style="display:flex;flex-direction:column;gap:5px;margin-bottom:16px;font-size:.8rem">
      <?php foreach([
        ($pl->max_listings==-1?'Unlimited':'Max '.$pl->max_listings).' listings',
        ($pl->max_images==-1?'Unlimited':'Max '.$pl->max_images).' images',
        'WhatsApp button',
        'Analytics dashboard',
        'Featured badge',
        'Video embed',
        'Products catalogue',
        'Priority support',
      ] as $fn): ?>
      <div style="display:flex;gap:6px;color:#334155"><span>✅</span><span><?php echo esc_html($fn); ?></span></div>
      <?php endforeach; ?>
    </div>
    <?php if($isc): ?>
    <button class="gs-btn gs-btn-ghost gs-btn-full" disabled>✓ Current Plan</button>
    <?php elseif($_open_mp_request): ?>
    <button class="gs-btn gs-btn-ghost gs-btn-full" disabled title="Resolve your open request first">⏳ Open request pending</button>
    <?php elseif($pl->price_monthly>0): ?>
    <?php
      // No online payment gateway is configured right now — the manual/offline
      // request is the only real path to a paid plan, so it leads as the
      // primary button. Each online gateway button only appears once that
      // specific gateway is actually configured AND enabled
      // (is_configured() checks both) — showing it otherwise would let a
      // vendor fill in a payment modal, click Pay Now, and only then
      // discover "not configured" — a late, frustrating failure instead
      // of simply not offering the option.
      $_rzp_ready = \GoodService\Service\RazorpayService::is_configured();
      $_stripe_ready = \GoodService\Service\StripeService::is_configured();
      // Pass the vendor's current plan state so the JS can warn before switching —
      // only when there's real remaining value to lose (paid plan, not expired).
      // See gsPayWithRazorpay()/gsPayWithStripe() below for how this is used.
      $_has_paid_active = $sub && (float)($sub->amount ?? 0) > 0 && (!$sub->expires_at || strtotime($sub->expires_at) > time());
      // Real gap fix: compute the actual forfeited ₹ value (not just a date)
      // so the warning can say what switching now costs, not merely when it
      // would have been "free" to switch. remaining_days is capped at the
      // nominal cycle length so a manually-extended expiry never overstates
      // the figure beyond one cycle's price. Lifetime plans and plans with
      // no billing_cycle mapping are left un-prorated (return null) since
      // there is no cycle length to prorate against.
      $_remaining_value = null;
      if ($_has_paid_active) {
          $_cycle_days_map = ['monthly' => 30, 'quarterly' => 91, 'yearly' => 365];
          $_days_total = $_cycle_days_map[$sub->billing_cycle ?? ''] ?? 0;
          $_expires_ts = $sub->expires_at ? strtotime($sub->expires_at) : false;
          if ($_days_total > 0 && $_expires_ts && $_expires_ts > time()) {
              $_days_remaining = min(($_expires_ts - time()) / DAY_IN_SECONDS, $_days_total);
              if ($_days_remaining > 0) {
                  $_remaining_value = round((float)$sub->amount * ($_days_remaining / $_days_total), 2);
              }
          }
      }
    ?>
    <button type="button" onclick="MPV.openRequestForm(<?php echo (int)$pl->id; ?>,'<?php echo esc_js($pl->name); ?>')"
            class="gs-btn gs-btn-full" style="background:<?php echo esc_attr($pl->color??'#2563EB'); ?>;color:#fff;border:none">
      🏦 Get <?php echo esc_html($pl->name); ?> (Bank Transfer / UPI / Cheque) →
    </button>
    <?php if ($_rzp_ready): ?>
    <button onclick="gsPayWithRazorpay(<?php echo $pl->id; ?>,'<?php echo esc_js($pl->name); ?>',<?php echo (float)$pl->price_monthly; ?>,<?php echo (float)$pl->price_yearly; ?>,<?php
      echo $_has_paid_active ? "'" . esc_js($sub->plan_name) . "','" . esc_js($sub->expires_at ?? '') . "'," . ($_remaining_value !== null ? $_remaining_value : 'null') : "null,null,null";
    ?>)"
            class="gs-btn gs-btn-ghost gs-btn-full" style="margin-top:6px;font-size:.78rem">
      💳 Pay with Razorpay (Cards / UPI / Netbanking)
    </button>
    <?php endif; ?>
    <?php if ($_stripe_ready): ?>
    <button onclick="gsPayWithStripe(<?php echo $pl->id; ?>,'<?php echo esc_js($pl->name); ?>',<?php
      echo $_has_paid_active ? "'" . esc_js($sub->plan_name) . "','" . esc_js($sub->expires_at ?? '') . "'," . ($_remaining_value !== null ? $_remaining_value : 'null') : "null,null,null";
    ?>)"
            class="gs-btn gs-btn-ghost gs-btn-full" style="margin-top:6px;font-size:.78rem">
      💳 Pay with Stripe (International Cards)
    </button>
    <?php endif; ?>
    <?php if ( ! $_rzp_ready && ! $_stripe_ready && \GoodService\Core\Roles::is_admin_level() ): ?>
    <div style="margin-top:8px;padding:8px 10px;background:#FFFBEB;border:1px solid #FDE68A;border-radius:6px;font-size:.72rem;color:#92400E">
      ⚠️ <strong>Admin only:</strong> no online gateway is showing because neither Razorpay nor Stripe has real API credentials saved yet — this is expected, not a bug, until you configure one.
      <a href="?section=payment_gateways" style="color:#1D4ED8;font-weight:700">Set up a gateway →</a>
    </div>
    <?php elseif ( ! $_rzp_ready && ! $_stripe_ready ): ?>
    <!-- Real fix (Known Limitations): a regular vendor previously saw no
         explanation at all when no online gateway was configured — only the
         manual-payment button below with nothing to say why card/UPI wasn't
         offered. This non-technical message replaces silence for non-admins,
         without exposing internal gateway-configuration language. -->
    <div style="margin-top:8px;padding:8px 10px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:6px;font-size:.72rem;color:#64748B">
      ℹ️ Online card/UPI payment isn't available yet — use Bank Transfer / UPI / Cheque below, or contact us if you'd prefer another option.
    </div>
    <?php endif; ?>
    <?php else: ?>
    <button class="gs-btn gs-btn-ghost gs-btn-full" disabled>Free Plan</button>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>
<?php
include GS_DIR . 'templates/partials/manual-plan-vendor-block.php';
?>
<script>
// ── Shared plan-switch warning (used by both Razorpay and Stripe checkout) ────
// Shows the exact ₹ value about to be forfeited (when computable) instead of
// only the expiry date, so the vendor can make an informed choice about
// whether to switch now or wait until closer to renewal.
window.gsConfirmPlanSwitch = function(currentPlanName, newPlanName, currentExpiresAt, currentRemainingValue) {
  var expiryText = 'an unknown date';
  var d = new Date(currentExpiresAt.replace(' ', 'T'));
  if (!isNaN(d.getTime())) {
    expiryText = d.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
  }
  var lossLine;
  if (typeof currentRemainingValue === 'number' && currentRemainingValue > 0) {
    var valueText = '₹' + currentRemainingValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    lossLine = 'Switching to "' + newPlanName + '" will END your current plan immediately — the remaining time on "' + currentPlanName + '" (worth approximately ' + valueText + ') will NOT be refunded or carried over.';
  } else {
    lossLine = 'Switching to "' + newPlanName + '" will END your current plan immediately — any remaining time on "' + currentPlanName + '" will NOT be refunded or carried over.';
  }
  return window.confirm(
    'You currently have the "' + currentPlanName + '" plan, active until ' + expiryText + '.\n\n' +
    lossLine + '\n\n' +
    'Continue anyway?'
  );
};

// ── Razorpay subscription payment ─────────────────────────────────────────────
window.gsPayWithRazorpay = function(planId, planName, priceMonthly, priceYearly, currentPlanName, currentExpiresAt, currentRemainingValue) {
  // Real gap fix: switching plans immediately cancels any existing paid
  // subscription and starts a fresh full-price cycle with zero credit for
  // remaining time (see RazorpayService::activate_subscription()). This does
  // not change that backend behavior or invent a refund/credit policy — it
  // only makes sure the vendor knows what they're about to lose before they pay.
  // currentRemainingValue (when present) is a server-computed prorated ₹
  // figure — see the PHP block above this button for the calculation.
  if (currentPlanName && currentExpiresAt) {
    if (!window.gsConfirmPlanSwitch(currentPlanName, planName, currentExpiresAt, currentRemainingValue)) { return; }
  }
  var nonce = '<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>';
  var hasYearly = priceYearly > 0;
  var savePercent = hasYearly ? Math.round((1 - priceYearly/(priceMonthly*12))*100) : 0;
  var _cycle = hasYearly ? 'yearly' : 'monthly';
  var html = '<div style="font-size:1.1rem;font-weight:800;margin-bottom:14px">\ud83d\udcb3 ' + planName + ' Plan</div>'
    + (hasYearly ? '<div style="display:flex;gap:8px;margin-bottom:14px">'
        + '<label style="flex:1;cursor:pointer;border:2px solid #E2E8F0;border-radius:10px;padding:12px;text-align:center" id="gs-cy-mo" onclick="gsCycleSet(\'monthly\')">'
        + '<div style="font-weight:700">Monthly</div><div style="font-size:1.3rem;font-weight:900">\u20b9' + priceMonthly.toLocaleString("en-IN") + '</div></label>'
        + '<label style="flex:1;cursor:pointer;border:2px solid #2563EB;border-radius:10px;padding:12px;text-align:center;background:#EFF6FF" id="gs-cy-yr" onclick="gsCycleSet(\'yearly\')">'
        + '<div style="font-weight:700">Yearly <span style="background:#DCFCE7;color:#166534;font-size:.65rem;padding:2px 6px;border-radius:4px">Save ' + savePercent + '%</span></div>'
        + '<div style="font-size:1.3rem;font-weight:900">\u20b9' + priceYearly.toLocaleString("en-IN") + '</div></label>'
        + '</div>'
      : '<div style="font-size:1.3rem;font-weight:900;margin-bottom:14px">\u20b9' + priceMonthly.toLocaleString("en-IN") + '/mo</div>')
    + '<div style="margin-bottom:10px"><label style="font-size:.82rem;font-weight:600;display:block;margin-bottom:4px">Coupon (optional)</label>'
    + '<input id="gs-rzp-coupon" class="gs-inp" placeholder="Coupon code" style="margin:0"></div>'
    + '<label style="display:flex;align-items:center;gap:8px;font-size:.8rem;color:#334155;margin-bottom:6px;cursor:pointer">'
    + '<input type="checkbox" id="gs-rzp-savecard" style="width:auto"> Save this card for future payments</label>';

  window.gsCycleSet = function(c) {
    _cycle = c;
    var m = document.getElementById('gs-cy-mo'), y = document.getElementById('gs-cy-yr');
    if(m){m.style.border=c==='monthly'?'2px solid #2563EB':'2px solid #E2E8F0';m.style.background=c==='monthly'?'#EFF6FF':'';}
    if(y){y.style.border=c==='yearly'?'2px solid #2563EB':'2px solid #E2E8F0';y.style.background=c==='yearly'?'#EFF6FF':'';}
  };

  gsModal.show(html, { title: 'Subscribe to ' + planName, size: 'sm',
    footer: '<button class="gs-btn gs-btn-ghost" onclick="gsModal.hide()">Cancel</button>'
      + '<button class="gs-btn gs-btn-primary" id="gs-rzp-btn" onclick="gsRzpStart(' + planId + ',nonce)">\ud83d\udcb3 Pay Now</button>'
  });
  if(hasYearly) gsCycleSet('yearly');

  window.gsRzpStart = function(pId, nc) {
    var btn = document.getElementById('gs-rzp-btn');
    if(btn){btn.disabled=true;btn.textContent='Creating order…';}
    var coupon = (document.getElementById('gs-rzp-coupon')||{value:''}).value;
    var saveCard = (document.getElementById('gs-rzp-savecard')||{checked:false}).checked;
    gsPost('gs_razorpay_create_order',{context:'subscription',plan_id:pId,cycle:_cycle,coupon:coupon,save_card:saveCard?1:0,nonce:nc},
      function(d){
        gsModal.hide();
        function openRzp(){
          var rzpOpts = {
            key: d.key_id, amount: d.amount, currency: d.currency||'INR',
            name: '<?php echo esc_js(gs_setting("platform_name","GoodService")); ?>',
            description: d.description, order_id: d.order_id, prefill: d.prefill||{},
            theme:{color:'#2563EB'},
            handler: function(r){
              gsToast('Verifying payment…','info');
              gsPost('gs_razorpay_verify_payment',{
                razorpay_order_id:r.razorpay_order_id,
                razorpay_payment_id:r.razorpay_payment_id,
                razorpay_signature:r.razorpay_signature,
                context:'subscription',plan_id:pId,cycle:d.cycle,nonce:nc
              },function(vd){gsToast(vd.message||'\ud83c\udf89 Plan activated!','success');setTimeout(function(){window.location.href=vd.redirect||'?section=subscription';},1200);},
              function(m){gsToast(m||'Verification failed','error');});
            },
            modal:{ondismiss:function(){gsToast('Payment cancelled.','info');}}
          };
          if (d.recurring && d.customer_id) { rzpOpts.recurring = '1'; rzpOpts.customer_id = d.customer_id; }
          var rzp = new window.Razorpay(rzpOpts);
          rzp.open();
        }
        if(!window.Razorpay){var s=document.createElement('script');s.src='https://checkout.razorpay.com/v1/checkout.js';s.onload=openRzp;document.head.appendChild(s);}
        else{openRzp();}
      },
      function(m){if(btn){btn.disabled=false;btn.textContent='\ud83d\udcb3 Pay Now';}gsToast(m||'Failed','error');}
    );
  };
};

// ── Stripe subscription payment ───────────────────────────────────────────────
// Unlike Razorpay's JS modal (stays on this site), Stripe Checkout is a
// redirect to a Stripe-hosted payment page — Stripe's own standard
// integration model. The browser comes back here afterward (see the
// return-trip handler below), where the session is verified server-to-
// server before anything is activated.
window.gsPayWithStripe = function(planId, planName, currentPlanName, currentExpiresAt, currentRemainingValue) {
  var nonce = '<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>';
  // Real gap fix: this path previously had no plan-switch warning at all —
  // only Razorpay did. Same disclosure now applies to both gateways.
  if (currentPlanName && currentExpiresAt) {
    if (!window.gsConfirmPlanSwitch(currentPlanName, planName, currentExpiresAt, currentRemainingValue)) { return; }
  } else if (!confirm('Continue to Stripe to pay for the "' + planName + '" plan (monthly billing)?')) { return; }
  gsPost('gs_stripe_create_checkout', { plan_id: planId, cycle: 'monthly', nonce: nonce },
    function(d) { window.location.href = d.checkout_url; },
    function(m) { gsToast(m || 'Could not start Stripe checkout.', 'error'); }
  );
};

// Return-trip handler: Stripe redirects back here with ?stripe_session=...
// after checkout. This is a UX convenience only — the webhook is the
// authoritative activation path — but confirming here means the vendor
// sees their plan active immediately instead of waiting for the webhook
// to arrive asynchronously.
(function(){
  var params = new URLSearchParams(window.location.search);
  var sessionId = params.get('stripe_session');
  if (!sessionId) return;
  var nonce = '<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>';
  gsToast('Confirming your payment…', 'info');
  gsPost('gs_stripe_confirm_session', { session_id: sessionId, nonce: nonce },
    function(d) {
      gsToast(d.message || '\ud83c\udf89 Plan activated!', 'success');
      setTimeout(function(){ window.location.href = d.redirect || '?section=subscription'; }, 1200);
    },
    function(m) { gsToast(m || 'Could not confirm payment — if you were charged, contact support.', 'error'); }
  );
})();
</script>
<?php echo gs_render_screen_help( 'Subscription & Payment', [
  
  
], [
  [ 'mistake' => 'Starting a new manual (Bank Transfer/UPI/Cheque) plan request while a previous request is still open', 'category' => 'workflow', 'see' => "If \$_open_mp_request already exists, every paid plan card's button changes to a disabled '⏳ Open request pending' state — a vendor cannot start a second request.", 'fix' => "Wait for the existing open request to be reviewed (visible in the yellow banner at the top of the screen naming the plan and status), or use the 'update it below' option mentioned in that banner rather than trying to submit a second request.", 'prevent' => 'Check for the yellow "You have an open request" banner at the top of this screen before assuming the plan buttons are broken because they are disabled.' ],
  [ 'mistake' => "Paying via Razorpay/Stripe while switching from an active paid plan without reading the warning about losing remaining time", 'category' => 'incorrect-settings', 'see' => "gsConfirmPlanSwitch() (used by both gsPayWithRazorpay() and gsPayWithStripe()) shows a confirm-style warning naming the current plan, its expiry date, and the approximate ₹ value of the unused time before proceeding to payment when \$_has_paid_active is true — dismissing it too quickly can lead to an unexpected loss of remaining paid value.", 'fix' => "Read the warning dialog carefully before confirming a plan switch while an existing paid plan has not yet expired — there is no proration credit applied automatically, so switching early is more costly than waiting until the current plan is close to expiry. The dialog now states the exact amount you would forfeit.", 'prevent' => "Time a plan switch to coincide with (or shortly before) the current plan's expiry date to avoid forfeiting paid-for time." ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: ANALYTICS
// ══════════════════════════════════════════════════════════════════════════════
case 'analytics':
  // REAL BUG FIX — confirmed root cause of the reported "Analytics shows a
  // blank white screen, no numbers at all" report. `break;` here used to
  // sit AFTER `endif;`, meaning it ran unconditionally on every request to
  // this section — regardless of which branch of the if/else the vendor
  // actually took. A vendor WITHOUT analytics access correctly saw the
  // upgrade banner (rendered before the endif) and then hit this
  // unconditional break, which is fine for them. But a vendor WITH
  // analytics access (show_analytics true) skipped the upgrade banner
  // entirely (the if was false) and landed on this SAME unconditional
  // break — which exits the switch/case immediately, before a single
  // line of the actual Analytics markup below (stat cards, charts,
  // funnel, the <script> that calls gsLoadAnalytics) ever gets a chance
  // to render. So the real dashboard body was dead code for EVERY vendor,
  // paid or not — nothing about their data, permissions, or the AJAX
  // endpoint was ever actually broken. Moving `break;` inside the if-block
  // means it only fires for the "no access" branch, and a vendor with
  // access now correctly falls through to the real dashboard below.
  if(!($sub&&$sub->show_analytics)):
?>
<div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:12px;padding:28px;text-align:center">
  <div style="font-size:2rem;margin-bottom:10px">📊</div>
  <div style="font-weight:700;color:#92400E;font-size:1rem;margin-bottom:6px">Analytics requires Professional plan or above</div>
  <a href="?section=subscription" class="gs-btn gs-btn-primary" style="margin-top:8px">Upgrade Plan →</a>
</div>
<?php echo gs_upgrade_prompt('The Analytics Dashboard', 'Professional', '₹499/month');
    break;
  endif; ?>
<div class="gs-ph">
  <div><div class="gs-ph-title">📈 Analytics</div></div>
  <div style="display:flex;gap:8px;align-items:center">
    <select id="gs-an-days" class="gs-sel" style="width:auto" onchange="gsLoadAnalytics(this.value)">
      <option value="7">Last 7 days</option><option value="30" selected>Last 30 days</option><option value="90">Last 90 days</option>
    </select>
    <a id="gs-an-export" href="<?php echo esc_url( admin_url( 'admin-ajax.php' ) . '?action=gs_export_vendor_analytics_csv&nonce=' . wp_create_nonce( 'gs_ajax' ) . '&days=30' ); ?>" class="gs-btn gs-btn-ghost gs-btn-sm">⬇ Export CSV</a>
  </div>
</div>
<script>
// Keep the analytics export link's ?days= param in sync with the period selector.
(function(){
  var sel = document.getElementById('gs-an-days');
  var exp = document.getElementById('gs-an-export');
  if (sel && exp) {
    sel.addEventListener('change', function(){
      exp.href = exp.href.replace(/([?&]days=)\d+/, '$1' + this.value);
    });
  }
})();
</script>
<div id="gs-an-stats" class="gs-stat-grid" style="min-height:80px"></div>

<!-- Row 1: Line chart + Funnel -->
<div style="display:grid;grid-template-columns:2fr 1fr;gap:14px;margin-bottom:14px">
  <div class="gs-card" style="margin-bottom:0">
    <div class="gs-card-title">📈 Views vs Inquiries</div>
    <div style="height:200px;position:relative"><canvas id="gs-an-line-canvas"></canvas></div>
  </div>
  <div class="gs-card" style="margin-bottom:0">
    <div class="gs-card-title">🔽 Inquiry Funnel</div>
    <div id="gs-an-funnel" style="display:flex;flex-direction:column;gap:6px;padding:8px 0">
      <div style="text-align:center;color:#94A3B8;font-size:.8rem">Loading…</div>
    </div>
  </div>
</div>

<!-- Row 2: Doughnut by category + Response metrics -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px">
  <div class="gs-card" style="margin-bottom:0">
    <div class="gs-card-title">🍩 Inquiries by Category</div>
    <div style="height:180px;position:relative"><canvas id="gs-an-donut-canvas"></canvas></div>
  </div>
  <div class="gs-card" style="margin-bottom:0">
    <div class="gs-card-title">⚡ Response Metrics</div>
    <div id="gs-an-response" style="display:flex;flex-direction:column;gap:10px;padding:8px 0">
      <div style="text-align:center;color:#94A3B8;font-size:.8rem">Loading…</div>
    </div>
  </div>
</div>

<script>
(function(){
var NONCE='<?php echo esc_js($nonce); ?>';
var _charts={};

function loadChartJs(cb){
  if(typeof Chart!=='undefined'){cb();return;}
  // ENTERPRISE-AUDIT FIX (Part 3, Medium: "Analytics loads Chart.js from a
  // public CDN at runtime with no local fallback — if blocked, only stat
  // cards render, not charts"). An earlier session already added the
  // onerror handler below so a CDN failure at least shows a clear message
  // instead of a silently-blank chart — but that was graceful DEGRADATION,
  // not the fallback the finding actually asked for. This is the real
  // fallback: the identical Chart.js 4.4.1 UMD build (same version as the
  // CDN URL, downloaded from the real npm package and verified to parse)
  // now ships locally at assets/js/vendor/chart.umd.js. On a CDN failure
  // (firewall, ad-blocker, offline CDN, network policy blocking cdnjs
  // specifically but not this site's own domain) the charts now try the
  // local copy before giving up — most vendors on a restrictive network
  // will simply never notice anything was ever blocked.
  var triedLocal = false;
  function attempt(src, onFail){
    var s=document.createElement('script');
    s.src=src;
    s.onload=cb;
    s.onerror=onFail;
    document.head.appendChild(s);
  }
  function showUnavailable(){
    ['gs-an-line-canvas','gs-an-donut-canvas'].forEach(function(id){
      var c=document.getElementById(id);
      if(c&&c.parentNode) c.parentNode.innerHTML='<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#94A3B8;font-size:.82rem;text-align:center;padding:12px">📉 Charts unavailable — check your internet connection or ad-blocker settings.</div>';
    });
  }
  attempt('https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js', function(){
    if (triedLocal) { showUnavailable(); return; }
    triedLocal = true;
    var localUrl = (window.GS && window.GS.assets_url) ? window.GS.assets_url + 'js/vendor/chart.umd.js' : null;
    if (!localUrl) { showUnavailable(); return; }
    attempt(localUrl, showUnavailable);
  });
}

function fmtReplTime(mins){
  if(!mins||mins<=0)return'—';
  if(mins<60)return Math.round(mins)+'m';
  return(mins/60).toFixed(1)+'h';
}

window.gsLoadAnalytics=function(days){
  // Stat cards
  document.getElementById('gs-an-stats').innerHTML='<div style="grid-column:1/-1;text-align:center;padding:20px;color:#94A3B8">Loading…</div>';

  gsPost('gs_get_vendor_analytics',{nonce:NONCE,days:days},function(d){
    // ── Stat cards ──────────────────────────────────────────────────
    var t={view:0,call_click:0,whatsapp_click:0,quote_click:0,email_click:0};
    (d.analytics||[]).forEach(function(a){
      if(t.hasOwnProperty(a.event_type))t[a.event_type]+=(parseInt(a.cnt)||parseInt(a.count)||0);
    });
    var rr=d.response&&d.response.total_leads>0?Math.round(d.response.replied_leads/d.response.total_leads*100):0;
    var bk=d.bookings||{};
    var bk_total=parseInt(bk.total||0),bk_done=parseInt(bk.completed||0),bk_rev=parseFloat(bk.revenue||0);
    var bk_rate=bk_total>0?Math.round(bk_done/bk_total*100):0;
    var an_cards=[
      ['\u{1F441}','Views',t.view.toLocaleString(),'#EFF6FF','#2563EB'],
      ['\u{1F4DE}','Inquiries',(d.funnel&&d.funnel.total||0).toLocaleString(),'#F0FDF4','#059669'],
      ['\u{1F4C5}','Bookings',bk_total.toLocaleString(),'#F5F3FF','#7C3AED'],
      ['\u2705','Completed',bk_done+(bk_total>0?' ('+bk_rate+'%)':''),'#F0FDF4','#059669'],
      ['\u{1F4CA}','Response Rate',rr+'%','#FFFBEB','#D97706'],
      ['\u23F1','Avg Reply',fmtReplTime(d.response&&d.response.avg_reply_min),'#F5F3FF','#7C3AED'],
    ];
    if(bk_rev>0)an_cards.push(['\u{1F4B0}','Booking Revenue','\u20b9'+bk_rev.toLocaleString('en-IN',{maximumFractionDigits:0}),'#FFFBEB','#D97706']);
    document.getElementById('gs-an-stats').innerHTML=an_cards.map(function(s){
      return '<div class="gs-sc"><div class="gs-sc-icon" style="background:'+s[3]+'">'+s[0]+'</div>'
        +'<div><div class="gs-sc-val" style="color:'+s[4]+'">'+s[2]+'</div>'
        +'<div class="gs-sc-lbl">'+s[1]+'</div></div></div>';
    }).join('');

    loadChartJs(function(){
      // ── Line chart: views vs leads ───────────────────────────────
      var labels=[],views=[],leads=[];
      var di=parseInt(days);
      for(var i=di-1;i>=0;i--){
        var dt=new Date();dt.setDate(dt.getDate()-i);
        labels.push(dt.toLocaleDateString('en-IN',{month:'short',day:'numeric'}));
        views.push(0);leads.push(0);
      }
      (d.daily||d.analytics||[]).forEach(function(a){
        var key=(a.day||'').toString().substring(0,10);
        var dt2=new Date(key);
        var lbl=dt2.toLocaleDateString('en-IN',{month:'short',day:'numeric'});
        var idx=labels.indexOf(lbl);
        if(idx>=0){
          if(a.event_type==='view')views[idx]+=(parseInt(a.cnt)||parseInt(a.count)||0);
          if(a.event_type==='lead')leads[idx]+=(parseInt(a.cnt)||parseInt(a.count)||0);
        }
      });
      if(_charts.line)_charts.line.destroy();
      var lineCtx=document.getElementById('gs-an-line-canvas');
      if(lineCtx)_charts.line=new Chart(lineCtx,{
        type:'line',
        data:{labels:labels,datasets:[
          {label:'Views',data:views,borderColor:'#2563EB',backgroundColor:'rgba(37,99,235,.07)',tension:.4,fill:true,pointRadius:2,pointHoverRadius:4},
          {label:'Inquiries',data:leads,borderColor:'#059669',backgroundColor:'rgba(5,150,105,.07)',tension:.4,fill:true,pointRadius:2,pointHoverRadius:4}
        ]},
        options:{responsive:true,maintainAspectRatio:false,
          plugins:{legend:{position:'top',labels:{font:{size:10},boxWidth:10,padding:10}}},
          scales:{x:{ticks:{font:{size:9},maxTicksLimit:8},grid:{display:false}},
                  y:{beginAtZero:true,ticks:{font:{size:9},precision:0}}}}
      });

      // ── Doughnut: by category ──────────────────────────────────
      if(_charts.donut)_charts.donut.destroy();
      var cats=d.by_category||[];
      if(cats.length){
        var donutCtx=document.getElementById('gs-an-donut-canvas');
        var COLORS=['#2563EB','#059669','#D97706','#7C3AED','#DC2626','#0EA5E9','#F59E0B','#10B981'];
        if(donutCtx)_charts.donut=new Chart(donutCtx,{
          type:'doughnut',
          data:{
            labels:cats.map(function(c){return c.inquiry_module||c.category||'Other';}),
            datasets:[{data:cats.map(function(c){return parseInt(c.cnt||c.count||0);}),
              backgroundColor:cats.map(function(_,i){return COLORS[i%COLORS.length];}),
              borderWidth:2,borderColor:'#fff'}]
          },
          options:{responsive:true,maintainAspectRatio:false,cutout:'65%',
            plugins:{legend:{position:'right',labels:{font:{size:9},boxWidth:10,padding:8}}}}
        });
      } else {
        var dc=document.getElementById('gs-an-donut-canvas');
        if(dc&&dc.parentElement)dc.parentElement.innerHTML='<div style="text-align:center;padding:40px;color:#94A3B8;font-size:.8rem">No category data yet</div>';
      }
    });

    // ── Funnel bars ──────────────────────────────────────────────
    var fn=d.funnel||{total:0,valid:0,viewed:0,replied:0,converted:0};
    var total=parseInt(fn.total)||1;
    var funStages=[
      ['Received',fn.total,'#2563EB'],
      ['Viewed',fn.viewed,'#7C3AED'],
      ['Replied',fn.replied,'#D97706'],
      ['Won',fn.converted,'#059669'],
    ];
    document.getElementById('gs-an-funnel').innerHTML=funStages.map(function(s){
      var pct=Math.round((parseInt(s[1])||0)/total*100);
      return '<div>'
        +'<div style="display:flex;justify-content:space-between;font-size:.75rem;margin-bottom:3px">'
        +'<span style="color:#475569;font-weight:600">'+s[0]+'</span>'
        +'<span style="color:'+s[2]+';font-weight:700">'+(s[1]||0)+' ('+pct+'%)</span></div>'
        +'<div style="height:10px;background:#F1F5F9;border-radius:5px">'
        +'<div style="height:100%;background:'+s[2]+';border-radius:5px;width:'+pct+'%;transition:width .4s"></div>'
        +'</div></div>';
    }).join('');

    // ── Response metrics ────────────────────────────────────────
    var rs=d.response||{};
    var rrPct=rs.total_leads>0?Math.round(rs.replied_leads/rs.total_leads*100):0;
    document.getElementById('gs-an-response').innerHTML=[
      ['Reply Rate',rrPct+'%',rrPct>=80?'#059669':rrPct>=50?'#D97706':'#DC2626'],
      ['Avg Reply Time',fmtReplTime(rs.avg_reply_min),'#7C3AED'],
      ['Total Leads',rs.total_leads||0,'#2563EB'],
      ['Leads Won',fn.converted||0,'#059669'],
    ].map(function(m){
      return '<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #F1F5F9">'
        +'<span style="font-size:.82rem;color:#475569">'+m[0]+'</span>'
        +'<span style="font-size:.88rem;font-weight:700;color:'+m[2]+'">'+m[1]+'</span></div>';
    }).join('');

  },function(){
    document.getElementById('gs-an-stats').innerHTML='<div style="color:var(--gs-red);grid-column:1/-1;padding:12px">Failed to load analytics.</div>';
  });
};

gsLoadAnalytics(30);
})();
</script>

<!-- Part 4.1 — Inquiry feed (last 10) + Performance snapshot -->
<?php
$recent_leads  = $vid ? $wpdb->get_results($wpdb->prepare(
  "SELECT l.id, l.name, l.phone, l.status, l.created_at, l.inquiry_module,
          li.title AS listing_title, l.is_starred
   FROM {$pfx}leads l
   LEFT JOIN {$pfx}listings li ON li.id=l.listing_id
   WHERE l.vendor_id=%d
   ORDER BY l.created_at DESC LIMIT 10", $vid
)) : [];

// Performance snapshot: this week vs last week
$this_week_leads  = $vid?(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)",$vid)):0;
$last_week_leads  = $vid?(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d AND created_at BETWEEN DATE_SUB(NOW(),INTERVAL 14 DAY) AND DATE_SUB(NOW(),INTERVAL 7 DAY)",$vid)):0;
$this_week_views  = $vid?(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(a.cnt),0) FROM (SELECT COUNT(*) AS cnt FROM {$pfx}analytics WHERE vendor_id=%d AND event_type='view' AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)) a",$vid)):0;
$this_week_rr     = $vid&&$this_week_leads>0?round((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY) AND replied_at IS NOT NULL",$vid))/$this_week_leads*100):0;
$last_week_rr     = $vid&&$last_week_leads>0?round((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d AND created_at BETWEEN DATE_SUB(NOW(),INTERVAL 14 DAY) AND DATE_SUB(NOW(),INTERVAL 7 DAY) AND replied_at IS NOT NULL",$vid))/$last_week_leads*100):0;
$this_week_reply  = $vid?(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(AVG(TIMESTAMPDIFF(MINUTE,created_at,replied_at)),0) FROM {$pfx}leads WHERE vendor_id=%d AND replied_at IS NOT NULL AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)",$vid)):0;
$lead_arrow = $this_week_leads>=$last_week_leads?'↑':'↓';
$lead_color = $this_week_leads>=$last_week_leads?'#059669':'#DC2626';
$rr_arrow   = $this_week_rr>=$last_week_rr?'↑':'↓';
$rr_color   = $this_week_rr>=$last_week_rr?'#059669':'#DC2626';
?>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:20px">
  <!-- Inquiry feed -->
  <div class="gs-card" style="margin-bottom:0">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
      <div class="gs-card-title" style="margin:0">📬 Recent Inquiries</div>
      <a href="?section=leads" style="font-size:.74rem;color:#2563EB;text-decoration:none">View all →</a>
    </div>
    <?php if($recent_leads): ?>
    <div style="display:flex;flex-direction:column;gap:1px">
      <?php foreach($recent_leads as $rl):
        $age = human_time_diff(strtotime($rl->created_at));
        $sc = ['new'=>'#DC2626','viewed'=>'#D97706','replied'=>'#059669','converted'=>'#2563EB','closed'=>'#94A3B8'];
      ?>
      <div onclick="window.location='?section=leads&open=<?php echo $rl->id; ?>'" style="display:flex;align-items:center;gap:9px;padding:8px 0;border-bottom:1px solid #F8FAFC;cursor:pointer">
        <div style="width:6px;height:6px;border-radius:50%;background:<?php echo $sc[$rl->status]??'#94A3B8'; ?>;flex-shrink:0"></div>
        <div style="flex:1;min-width:0">
          <div style="font-weight:600;font-size:.82rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html($rl->name); ?></div>
          <div style="font-size:.7rem;color:#94A3B8"><?php echo $age; ?> ago<?php echo $rl->inquiry_module?' · '.esc_html($rl->inquiry_module):''; ?></div>
        </div>
        <span style="font-size:.68rem;color:<?php echo $sc[$rl->status]??'#94A3B8'; ?>;font-weight:700;white-space:nowrap"><?php echo ucfirst($rl->status); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div style="text-align:center;padding:20px;color:#94A3B8;font-size:.82rem">No inquiries yet</div>
    <?php endif; ?>
  </div>
  <!-- Performance snapshot -->
  <div class="gs-card" style="margin-bottom:0">
    <!-- FIXED — Known Limitations audit: this panel is a fixed 7-vs-previous-7-day
         comparison that does not scale with the #gs-an-days dropdown above (which
         drives every other widget on this screen). Rather than silently diverge
         from the selected range, the title and a subtitle now say so explicitly. -->
    <div class="gs-card-title" style="margin-bottom:2px">📊 This Week vs Last</div>
    <div style="font-size:.72rem;color:#94A3B8;margin-bottom:10px">Always the last 7 days vs the 7 days before — does not change with the date range selected above.</div>
    <div style="display:flex;flex-direction:column;gap:10px">
      <?php foreach([
        ['Inquiries',   $this_week_leads,  $lead_arrow, $lead_color, $last_week_leads.' last week'],
        ['Reply Rate',  $this_week_rr.'%', $rr_arrow,   $rr_color,   $last_week_rr.'% last week'],
        ['Views',       $this_week_views,  '', '#64748B', 'this week'],
        ['Avg Reply',   $this_week_reply>0?($this_week_reply<60?round($this_week_reply).'m':round($this_week_reply/60,1).'h'):'—', '', '#7C3AED', 'response time'],
      ] as $perf): ?>
      <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid #F8FAFC">
        <span style="font-size:.8rem;color:#64748B"><?php echo $perf[0]; ?></span>
        <div style="text-align:right">
          <span style="font-size:.95rem;font-weight:700;color:#1E293B"><?php echo $perf[1]; ?></span>
          <?php if($perf[2]): ?><span style="color:<?php echo $perf[3]; ?>;font-weight:700;margin-left:4px"><?php echo $perf[2]; ?></span><?php endif; ?>
          <div style="font-size:.68rem;color:#94A3B8"><?php echo $perf[4]; ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php echo gs_render_screen_help( 'Analytics', [
  
  
], [
  
  // ENTERPRISE-AUDIT FIX (Part 3, Medium): this entry described the CDN
  // failure as something a vendor just had to recognize and work around.
  // A local copy of the same Chart.js build now ships with the plugin and
  // is tried automatically if the CDN is unreachable (see loadChartJs()
  // above), so a blocked CDN alone no longer leaves the charts blank —
  // updated to describe the current, much narrower failure mode instead of
  // deleting a real help entry outright.
  [ 'mistake' => "Interpreting a blank chart area as 'no data' when it may actually mean the charting library failed to load", 'category' => 'unexpected-behavior', 'see' => 'The Views vs Inquiries line chart and Inquiries by Category doughnut both render inside a <canvas> that stays visually empty when there is genuinely no data for the selected period.', 'fix' => 'Check that the stat cards above show non-zero figures before concluding "no data" — if the stat cards show activity but the charts are blank, try reloading the page.', 'prevent' => 'Charts now automatically fall back to a locally-bundled copy of the charting library if the public CDN is unreachable, so this should be rare; if it still happens, the site itself (not just the CDN) may be blocked on that network.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: PERFORMANCE SCORECARD — real feature, closes a confirmed
// Medium-priority audit gap. Composes entirely from data already
// computed elsewhere (Cron.php's trust/response metrics,
// VerificationService's levels, gs_risk_events) via
// VendorScorecardService::generate() — the same method the monthly
// email/notification use, so on-demand viewing and the periodic email
// always show identical numbers.
// ══════════════════════════════════════════════════════════════════════════════
case 'scorecard':
  $sc = $vid ? \GoodService\Service\VendorScorecardService::generate( $vid ) : null;
?>
<div class="gs-ph"><div><div class="gs-ph-title">📊 Performance Scorecard</div><div class="gs-ph-sub">Live snapshot — the same figures used in your monthly email · last generated <?php echo $sc ? esc_html(gs_time_ago($sc['generated_at'])) : '—'; ?></div></div></div>
<?php if ($sc): ?>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:20px">
  <div class="gs-card" style="text-align:center;padding:20px">
    <div style="font-size:1.8rem;font-weight:800;color:<?php echo $sc['trust_score']>=60?'#059669':($sc['trust_score']>=30?'#D97706':'#DC2626'); ?>"><?php echo esc_html(number_format($sc['trust_score'],1)); ?></div>
    <div style="font-size:.78rem;color:#64748B;margin-top:4px">Trust Score</div>
  </div>
  <div class="gs-card" style="text-align:center;padding:20px">
    <div style="font-size:1.8rem;font-weight:800;color:#1E293B"><?php echo esc_html($sc['response_rate']); ?>%
      <?php if ($sc['response_rate_trend'] !== null): ?>
        <span style="font-size:.85rem;color:<?php echo $sc['response_rate_trend']>=0?'#059669':'#DC2626'; ?>"><?php echo $sc['response_rate_trend']>=0?'▲':'▼'; ?><?php echo esc_html(abs($sc['response_rate_trend'])); ?></span>
      <?php endif; ?>
    </div>
    <div style="font-size:.78rem;color:#64748B;margin-top:4px">Response Rate <?php echo $sc['response_rate_trend']!==null?'(vs last month)':'<span style="color:#94A3B8">(first month — no comparison yet)</span>'; ?></div>
  </div>
  <div class="gs-card" style="text-align:center;padding:20px">
    <div style="font-size:1.8rem;font-weight:800;color:#1E293B"><?php echo esc_html($sc['avg_reply_minutes']); ?><span style="font-size:1rem">m</span></div>
    <div style="font-size:.78rem;color:#64748B;margin-top:4px">Avg. Reply Time</div>
  </div>
  <div class="gs-card" style="text-align:center;padding:20px">
    <div style="font-size:1.8rem;font-weight:800;color:#1E293B"><?php echo esc_html($sc['total_jobs_done']); ?></div>
    <div style="font-size:.78rem;color:#64748B;margin-top:4px">Jobs Completed</div>
  </div>
  <div class="gs-card" style="text-align:center;padding:20px">
    <div style="font-size:1.8rem;font-weight:800;color:#1E293B"><?php echo esc_html(number_format($sc['avg_rating'],1)); ?> ★</div>
    <div style="font-size:.78rem;color:#64748B;margin-top:4px">Average Rating</div>
  </div>
  <div class="gs-card" style="text-align:center;padding:20px">
    <div style="font-size:1.8rem;font-weight:800;color:<?php echo $sc['verification_levels']>=6?'#059669':'#D97706'; ?>"><?php echo (int)$sc['verification_levels']; ?>/8</div>
    <div style="font-size:.78rem;color:#64748B;margin-top:4px">Verification Level</div>
  </div>
</div>
<?php if ($sc['disputes_last_90d'] > 0 || $sc['open_sla_flags'] > 0): ?>
<div class="gs-card" style="border-left:3px solid #D97706">
  <div style="font-weight:700;color:#92400E;margin-bottom:4px">⚠️ Areas to watch</div>
  <?php if ($sc['disputes_last_90d'] > 0): ?><div style="font-size:.85rem;color:#64748B"><?php echo (int)$sc['disputes_last_90d']; ?> dispute(s) in the last 90 days.</div><?php endif; ?>
  <?php if ($sc['open_sla_flags'] > 0): ?><div style="font-size:.85rem;color:#64748B"><?php echo (int)$sc['open_sla_flags']; ?> open response-time flag(s) — improving your reply speed helps you rank higher in search.</div><?php endif; ?>
</div>
<?php endif; ?>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">📊</div><div>Scorecard data isn't available yet — check back after your first few inquiries and bookings.</div></div>
<?php endif; ?>
<?php echo gs_render_screen_help( 'Performance Scorecard', [
  
  
], [
  [ 'mistake' => 'Expecting the Scorecard to change only once a month and dismissing a lower score as "will update later"', 'category' => 'workflow', 'see' => 'The score recalculates on every visit — a vendor who improves reply speed or resolves a dispute will see the score reflect it on the very next page load, not on a monthly cycle.', 'fix' => 'Reload this screen after making an improvement (replying faster, resolving open flags) to see the updated score immediately rather than waiting for "next month".', 'prevent' => 'Treat "Updated monthly" as describing the email/notification cadence, not a restriction on how often the on-screen numbers can change.' ],
  [ 'mistake' => 'Ignoring the "⚠️ Areas to watch" card because it only appears intermittently', 'category' => 'workflow', 'see' => "This card only renders when disputes_last_90d > 0 or open_sla_flags > 0 — its absence means there is currently nothing flagged, not that the check didn't run.", 'fix' => 'If the card is missing, no action is needed on disputes or response-time flags right now; if it does appear, address the specific items it names (resolve open disputes, speed up replies) since this data feeds directly into Trust Score.', 'prevent' => 'Check this screen periodically even when everything seems fine, since the "Areas to watch" card will only surface issues the moment they occur, not proactively remind about them afterward.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: BOOKINGS
// ══════════════════════════════════════════════════════════════════════════════
case 'bookings':
  // Listing filter — same pattern as the inbox filter. Only shown when the
  // vendor has more than one listing; defaults to "All listings" (unchanged
  // behavior) so existing single-listing vendors see no new UI.
  $bk_listings = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT id, title FROM {$pfx}listings WHERE vendor_id=%d ORDER BY title ASC", $vid
  ) ) : [];
  $bk_filter_listing_id = (int) ( $_GET['listing_id'] ?? 0 );
  // Validate the filter belongs to this vendor before using it.
  $bk_filter_valid = false;
  foreach ( $bk_listings as $bkl ) { if ( (int)$bkl->id === $bk_filter_listing_id ) { $bk_filter_valid = true; break; } }
  if ( ! $bk_filter_valid ) { $bk_filter_listing_id = 0; }

  // FIX (enterprise hardening pass): fetch this vendor's active staff so a job can be
  // assigned to whoever actually did it — this is the data source that makes the
  // Staff Performance dashboard's per-staff rating attribution possible at all.
  $bk_staff = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT id, name FROM {$pfx}vendor_staff WHERE vendor_id=%d AND is_active=1 ORDER BY name ASC", $vid
  ) ) : [];

  $bk_per = 50;
  $bk_pg  = max(1,(int)($_GET['bk_pg']??1));
  $bk_off = ($bk_pg-1)*$bk_per;
  if ( $bk_filter_listing_id ) {
    $bk_total = $vid ? (int) $wpdb->get_var( $wpdb->prepare(
      "SELECT COUNT(*) FROM {$pfx}bookings WHERE vendor_id=%d AND listing_id=%d", $vid, $bk_filter_listing_id
    ) ) : 0;
    $bookings = $vid ? $wpdb->get_results( $wpdb->prepare(
      "SELECT b.*,li.title as lt FROM {$pfx}bookings b LEFT JOIN {$pfx}listings li ON b.listing_id=li.id WHERE b.vendor_id=%d AND b.listing_id=%d ORDER BY b.created_at DESC LIMIT %d OFFSET %d",
      $vid, $bk_filter_listing_id, $bk_per, $bk_off
    ) ) : [];
  } else {
    $bk_total = $vid ? (int) $wpdb->get_var( $wpdb->prepare("SELECT COUNT(*) FROM {$pfx}bookings WHERE vendor_id=%d",$vid) ) : 0;
    $bookings=$vid?$wpdb->get_results($wpdb->prepare("SELECT b.*,li.title as lt FROM {$pfx}bookings b LEFT JOIN {$pfx}listings li ON b.listing_id=li.id WHERE b.vendor_id=%d ORDER BY b.created_at DESC LIMIT %d OFFSET %d",$vid,$bk_per,$bk_off)):[];
  }
?>
<div class="gs-ph"><div><div class="gs-ph-title">📅 Bookings</div><div class="gs-ph-sub"><?php echo $bk_total; ?> bookings</div></div>
  <div style="display:flex;gap:8px">
  <button type="button" class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsBkToggleCalendarSync()">📆 Calendar Sync</button>
  <a href="<?php echo esc_url( admin_url( 'admin-ajax.php' ) . '?action=gs_export_vendor_bookings_csv&nonce=' . wp_create_nonce( 'gs_ajax' ) . ( $bk_filter_listing_id ? '&listing_id=' . $bk_filter_listing_id : '' ) ); ?>" class="gs-btn gs-btn-ghost gs-btn-sm">⬇ Export CSV</a>
  </div>
</div>
<?php
  // ENTERPRISE-AUDIT FIX (Part 3, Medium-High: "No calendar sync
  // (iCal/Google Calendar) for bookings" — confirmed absent). A standards-
  // based (RFC 5545) subscribe-by-URL feed: pasted once into Google
  // Calendar / Apple Calendar / Outlook, it then polls on its own and stays
  // in sync automatically — no per-booking manual export needed.
?>
<div class="gs-card" id="gs-bk-cal-sync" style="margin-bottom:14px;display:none">
  <div style="font-weight:700;margin-bottom:6px">📆 Sync bookings to your calendar app</div>
  <div style="font-size:.82rem;color:#64748B;margin-bottom:10px">
    Paste this link into Google Calendar (Settings → Add calendar → From URL), Apple Calendar
    (File → New Calendar Subscription), or Outlook (Add calendar → Subscribe from web) to keep
    your confirmed bookings visible there automatically. The link updates on its own — no need
    to re-export.
  </div>
  <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
    <input id="gs-bk-cal-url" class="gs-inp" readonly style="flex:1;min-width:220px;font-size:.78rem" value="Loading…">
    <button type="button" class="gs-btn gs-btn-primary gs-btn-sm" onclick="gsBkCopyCalUrl()">📋 Copy Link</button>
    <button type="button" class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsBkRegenCalUrl()" title="Invalidates the old link — use if you think it leaked">🔄 Regenerate Link</button>
  </div>
</div>
<script>
(function(){
  var loaded = false;
  window.gsBkToggleCalendarSync = function(){
    var box = document.getElementById('gs-bk-cal-sync');
    if(!box) return;
    var showing = box.style.display !== 'none';
    box.style.display = showing ? 'none' : 'block';
    if(!showing && !loaded){ gsBkLoadCalUrl(); }
  };
  function gsBkLoadCalUrl(){
    var nonce = '<?php echo esc_js( wp_create_nonce( 'gs_ajax' ) ); ?>';
    gsPost('gs_get_ical_feed_url',{nonce:nonce},function(d){
      loaded = true;
      var el = document.getElementById('gs-bk-cal-url');
      if(el) el.value = d.feed_url || '';
    },function(m){
      var el = document.getElementById('gs-bk-cal-url');
      if(el) el.value = '';
      gsToast(m||'Could not load calendar link.','error');
    });
  }
  window.gsBkCopyCalUrl = function(){
    var el = document.getElementById('gs-bk-cal-url');
    if(!el || !el.value) return;
    el.select(); el.setSelectionRange(0,99999);
    try { navigator.clipboard.writeText(el.value); gsToast('Link copied.','success'); }
    catch(e){ try{ document.execCommand('copy'); gsToast('Link copied.','success'); }catch(e2){ gsToast('Copy failed — select and copy manually.','error'); } }
  };
  window.gsBkRegenCalUrl = function(){
    if(!confirm('This invalidates your current calendar link — any calendar app already subscribed will stop syncing until you paste the new link there. Continue?')) return;
    var nonce = '<?php echo esc_js( wp_create_nonce( 'gs_ajax' ) ); ?>';
    gsPost('gs_regenerate_ical_token',{nonce:nonce},function(d){
      var el = document.getElementById('gs-bk-cal-url');
      if(el) el.value = d.feed_url || '';
      gsToast('New link generated — update it in your calendar app.','success');
    },function(m){ gsToast(m||'Could not regenerate link.','error'); });
  };
})();
</script>
<?php if ( count( $bk_listings ) > 1 ): ?>
<div class="gs-card" style="margin-bottom:14px">
  <label class="gs-lbl">Listing</label>
  <select class="gs-sel" onchange="window.location.href='?section=bookings'+(this.value?'&listing_id='+this.value:'')">
    <option value="">All listings</option>
    <?php foreach ( $bk_listings as $bkl ): ?>
    <option value="<?php echo (int)$bkl->id; ?>" <?php echo (int)$bkl->id===$bk_filter_listing_id?'selected':''; ?>><?php echo esc_html($bkl->title); ?></option>
    <?php endforeach; ?>
  </select>
</div>
<?php endif; ?>
<?php if($bookings): ?>
<div class="gs-tbl-wrap">
  <table class="gs-tbl">
    <thead><tr><th>Customer</th><th>Listing</th><th>Booking Date</th><th>Status</th><th>Amount</th><th>Staff</th><th>Actions</th></tr></thead>
    <tbody>
    <?php
      // FIX (enterprise hardening pass): the previous $sc map only covered the 4 coarse
      // `status` values, but the badge displays the more granular `job_status`
      // (travelling/arrived/in_progress) — those fell through to a grey fallback that
      // didn't match the label's meaning (e.g. "Arrived" showing in dull grey looks
      // identical to a badge for a status that hasn't started). Every job_status the
      // app can actually set now has its own correctly-associated color.
      $sc = [
        'pending'     => 'gs-badge-gold',
        'confirmed'   => 'gs-badge-green',
        'travelling'  => 'gs-badge-blue',
        'arrived'     => 'gs-badge-blue',
        'in_progress' => 'gs-badge-blue',
        'done'        => 'gs-badge-green',
        'cancelled'   => 'gs-badge-red',
        'completed'   => 'gs-badge-grey',
      ];
    ?>
    <?php foreach($bookings as $bk): ?>
    <?php
      $is_today_bk = $bk->booking_date && date('Y-m-d', strtotime($bk->booking_date)) === date('Y-m-d');
      $job_status  = $bk->job_status ?? $bk->status ?? 'confirmed';
      $next_status_map = [
        'confirmed'   => ['travelling',  'On my way 🚗'],
        'travelling'  => ['arrived',     'Arrived 📍'],
        'arrived'     => ['in_progress', 'Job started 🔧'],
        'in_progress' => ['done',        'Job complete ✅'],
      ];
      $next = $next_status_map[$job_status] ?? null;
    ?>
    <tr>
      <td><div style="font-weight:700"><?php echo esc_html($bk->customer_name); ?></div><div style="font-size:.74rem;color:var(--gs-muted)"><?php echo esc_html($bk->customer_phone); ?></div></td>
      <td style="font-size:.82rem"><?php echo esc_html($bk->lt??'—'); ?></td>
      <td style="font-size:.82rem"><?php echo $bk->booking_date?date('d M Y',strtotime($bk->booking_date)):'—'; ?></td>
      <td>
        <span class="gs-badge <?php echo $sc[$job_status]??($sc[$bk->status]??'gs-badge-grey'); ?>"><?php echo ucfirst(str_replace('_',' ',$job_status)); ?></span>
      </td>
      <td style="font-size:.82rem"><?php echo $bk->amount?'₹'.number_format((float)$bk->amount):'—'; ?></td>
      <td>
        <?php if($bk_staff): ?>
        <select onchange="gsPost('gs_assign_booking_staff',{nonce:'<?php echo esc_js($nonce); ?>',booking_id:<?php echo (int)$bk->id; ?>,staff_id:this.value},function(){gsToast('Staff assignment saved','success');},null)" class="gs-sel" style="width:auto;font-size:.76rem;padding:4px 8px">
          <option value="">— Unassigned —</option>
          <?php foreach($bk_staff as $bs_opt): ?><option value="<?php echo (int)$bs_opt->id; ?>" <?php echo ((int)($bk->assigned_staff_id??0)===(int)$bs_opt->id)?'selected':''; ?>><?php echo esc_html($bs_opt->name); ?></option><?php endforeach; ?>
        </select>
        <?php else: ?><span style="font-size:.78rem;color:#94A3B8">—</span><?php endif; ?>
      </td>
      <td style="display:flex;gap:6px;flex-wrap:wrap">
        <?php if($is_today_bk && $bk->status==='confirmed' && $next): ?>
        <button onclick="gsUpdateJobStatus(<?php echo $bk->id; ?>,'<?php echo $next[0]; ?>',this)"
                style="background:#2563EB;color:#fff;border:none;border-radius:7px;padding:5px 10px;font-size:.74rem;font-weight:700;cursor:pointer;white-space:nowrap">
          <?php echo esc_html($next[1]); ?>
        </button>
        <?php else: ?>
        <select onchange="gsPost('gs_update_booking',{nonce:'<?php echo esc_js($nonce); ?>',booking_id:<?php echo $bk->id; ?>,status:this.value},function(){gsToast('Booking updated','success');},null)" class="gs-sel" style="width:auto;font-size:.76rem;padding:4px 8px">
          <?php foreach(['pending','confirmed','cancelled','completed'] as $bs): ?><option value="<?php echo $bs; ?>" <?php echo $bk->status===$bs?'selected':''; ?>><?php echo ucfirst($bs); ?></option><?php endforeach; ?>
        </select>
        <?php endif; ?>
        <?php if ( in_array( $bk->status, [ 'completed', 'cancelled' ], true ) ): ?>
        <button onclick="gsReportIssue(<?php echo (int)$bk->id; ?>,this)"
                style="background:#FEF2F2;color:#DC2626;border:1px solid #FECACA;border-radius:7px;padding:5px 10px;font-size:.74rem;font-weight:700;cursor:pointer;white-space:nowrap">
          ⚖️ Report Issue
        </button>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<script>
function gsReportIssue(bookingId, btn) {
  var reason = prompt('Briefly describe the issue (e.g. "Customer no-show", "Payment dispute", "Service quality complaint"):');
  if (!reason) return;
  btn.disabled = true; btn.textContent = 'Submitting…';
  gsPost('gs_open_dispute', { nonce: '<?php echo esc_js($nonce); ?>', booking_id: bookingId, reason: reason, description: reason },
    function(){ gsToast('Dispute opened — our team will review it.', 'success'); btn.textContent = '✓ Reported'; },
    function(e){ btn.disabled = false; btn.textContent = '⚖️ Report Issue'; gsToast(e || 'Could not open dispute.', 'error'); }
  );
}
function gsUpdateJobStatus(bookingId, status, btn) {
  var eta = '';
  if (status === 'travelling') {
    var etaVal = prompt('How many minutes until you arrive? (Press Cancel to skip)', '');
    if (etaVal !== null) { eta = parseInt(etaVal) > 0 ? parseInt(etaVal) : ''; }
  }
  btn.disabled=true; btn.textContent='Updating…';
  gsPost('gs_update_job_status',{nonce:'<?php echo esc_js($nonce); ?>',booking_id:bookingId,status:status,eta:eta},
    function(d){gsToast('Status updated — client notified!','success');setTimeout(function(){location.reload();},1000);},
    function(m){gsToast(m||'Failed','error');btn.disabled=false;}
  );
}
</script>
<?php else: ?>
<?php if ( $bk_filter_listing_id ): ?>
<div class="gs-empty"><div class="gs-empty-icon">📅</div><div class="gs-empty-title">No bookings for this listing</div><div>This listing has no bookings yet. <a href="?section=bookings">View all listings</a></div></div>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">📅</div><div class="gs-empty-title">No bookings yet</div><div>Booking requests from customers appear here when booking is enabled for your listings.</div></div>
<?php endif; ?>
<?php endif; ?>
<?php if($bk_total > $bk_per): $bk_pages = ceil($bk_total/$bk_per); ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px;font-size:.85rem;color:var(--gs-muted)">
  <span>Showing <?php echo count($bookings); ?> of <?php echo $bk_total; ?> bookings</span>
  <div style="display:flex;gap:8px">
    <?php if($bk_pg>1): ?><a class="gs-btn gs-btn-sm gs-btn-ghost" href="?section=bookings<?php echo $bk_filter_listing_id?'&listing_id='.$bk_filter_listing_id:''; ?>&bk_pg=<?php echo $bk_pg-1; ?>">← Prev</a><?php endif; ?>
    <span>Page <?php echo $bk_pg; ?> of <?php echo $bk_pages; ?></span>
    <?php if($bk_pg<$bk_pages): ?><a class="gs-btn gs-btn-sm gs-btn-ghost" href="?section=bookings<?php echo $bk_filter_listing_id?'&listing_id='.$bk_filter_listing_id:''; ?>&bk_pg=<?php echo $bk_pg+1; ?>">Next →</a><?php endif; ?>
  </div>
</div>
<?php endif; ?>
<?php echo gs_render_screen_help( 'Bookings', [
  
  
], [
  [ 'mistake' => "Using the status dropdown to move a same-day booking through travelling/arrived/in_progress stages instead of the dedicated action button", 'category' => 'workflow', 'see' => "The dedicated single-click button (e.g. 'On my way 🚗', 'Arrived 📍') only appears when is_today_bk && \$bk->status==='confirmed' && a valid next-status exists — otherwise the generic status dropdown (pending/confirmed/cancelled/completed) is shown instead, which has no travelling/arrived/in_progress options at all.", 'fix' => 'Use the dedicated colored action button when it is visible (same-day, confirmed bookings) to progress through job stages — the plain dropdown cannot set those intermediate statuses at all.', 'prevent' => "Confirm a booking's date is today's date before expecting to see the step-by-step job-status button; for future-dated bookings, only the basic status dropdown will be available until the booking date arrives." ],
  [ 'mistake' => "Reporting an issue on a booking that hasn't been marked completed or cancelled yet", 'category' => 'workflow', 'see' => "The '⚖️ Report Issue' button only renders when in_array(\$bk->status, ['completed','cancelled']) — it does not appear on pending or confirmed bookings.", 'fix' => "Mark the booking as Completed or Cancelled first if a dispute needs to be filed, or contact platform support directly if the issue needs to be raised before the booking reaches one of those two states.", 'prevent' => "Understand disputes are only supported for bookings that have reached a final state — pending/confirmed bookings should be resolved (completed/cancelled) through normal status updates first." ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: REQUIREMENTS
// ══════════════════════════════════════════════════════════════════════════════
case 'requirements':
  // Real fix (Known Limitations): every vendor used to see every open
  // requirement with no relevance to their own trade — a plumber saw
  // wedding-photography requests mixed in with genuinely relevant ones.
  // This vendor's own listing categories are now used to sort matching
  // requirements to the top (category_id already existed on the table
  // and was simply never joined against), without hiding the rest —
  // an off-category requirement might still be one a vendor wants to
  // bid on, so nothing is filtered out, only re-ordered.
  $rq_my_cats = $vid ? $wpdb->get_col( $wpdb->prepare(
    "SELECT DISTINCT category_id FROM {$pfx}listings WHERE vendor_id=%d AND category_id>0", $vid
  ) ) : [];
  $rq_per = 30;
  $rq_pg  = max(1,(int)($_GET['rq_pg']??1));
  $rq_off = ($rq_pg-1)*$rq_per;
  $rq_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$pfx}requirements WHERE status='open'");
  if ( $rq_my_cats ) {
    $rq_cat_placeholders = implode(',', array_fill(0, count($rq_my_cats), '%d'));
    $reqs = $wpdb->get_results( $wpdb->prepare(
      "SELECT r.*, (SELECT COUNT(*) FROM {$pfx}requirement_bids b WHERE b.requirement_id=r.id AND b.vendor_id=%d) as already_bid,
              (r.category_id IN ({$rq_cat_placeholders})) as is_match
       FROM {$pfx}requirements r WHERE r.status='open'
       ORDER BY is_match DESC, r.created_at DESC LIMIT %d OFFSET %d",
      array_merge( [ $vid ], $rq_my_cats, [ $rq_per, $rq_off ] )
    ) );
  } else {
    $reqs=$wpdb->get_results($wpdb->prepare(
      "SELECT r.*, (SELECT COUNT(*) FROM {$pfx}requirement_bids b WHERE b.requirement_id=r.id AND b.vendor_id=%d) as already_bid FROM {$pfx}requirements r WHERE r.status='open' ORDER BY r.created_at DESC LIMIT %d OFFSET %d",$vid,$rq_per,$rq_off
    ));
  }
?>
<div class="gs-ph"><div><div class="gs-ph-title">📋 Requirements</div><div class="gs-ph-sub">Buyers looking for vendors — submit your bid to win the contract</div></div></div>
<?php if($reqs): foreach($reqs as $rq): ?>
<div class="gs-card" style="margin-bottom:12px">
  <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap">
    <div style="flex:1">
      <div style="font-weight:700;font-size:.93rem;color:var(--gs-dark);margin-bottom:4px"><?php echo esc_html($rq->title); ?> <?php if(!empty($rq->is_match)): ?><span class="gs-badge gs-badge-green" style="font-size:.65rem;vertical-align:middle">✓ Matches your category</span><?php endif; ?></div>
      <div style="font-size:.82rem;color:var(--gs-muted);margin-bottom:7px;line-height:1.5"><?php echo esc_html(substr($rq->description??'',0,180)); ?></div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;font-size:.75rem;color:#94A3B8">
        <?php if($rq->city): ?><span>📍 <?php echo esc_html($rq->city); ?></span><?php endif; ?>
        <?php if($rq->budget_min||$rq->budget_max): ?><span>💰 <?php echo $rq->budget_min?'₹'.number_format($rq->budget_min):''; ?><?php echo $rq->budget_max?' – ₹'.number_format($rq->budget_max):''; ?></span><?php endif; ?>
        <span>⏰ <?php echo gs_time_ago($rq->created_at); ?></span>
        <span>📩 <?php echo (int)$rq->responses_count; ?> bids</span>
      </div>
    </div>
    <?php if($rq->already_bid): ?>
    <span class="gs-badge gs-badge-green">✅ Bid Submitted</span>
    <?php else: ?>
    <button onclick="gsBidModal(<?php echo $rq->id; ?>,'<?php echo esc_js($rq->title); ?>')" class="gs-btn gs-btn-primary gs-btn-sm">📩 Submit Bid</button>
    <?php endif; ?>
  </div>
</div>
<?php endforeach; else: ?>
<div class="gs-empty"><div class="gs-empty-icon">📋</div><div class="gs-empty-title">No open requirements</div><div>When buyers post requirements matching your services, they appear here.</div></div>
<?php endif; ?>
<?php if($rq_total > $rq_per): $rq_pages = ceil($rq_total/$rq_per); ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px;font-size:.85rem;color:var(--gs-muted)">
  <span>Showing <?php echo count($reqs); ?> of <?php echo $rq_total; ?> open requirements</span>
  <div style="display:flex;gap:8px">
    <?php if($rq_pg>1): ?><a class="gs-btn gs-btn-sm gs-btn-ghost" href="?section=requirements&rq_pg=<?php echo $rq_pg-1; ?>">← Prev</a><?php endif; ?>
    <span>Page <?php echo $rq_pg; ?> of <?php echo $rq_pages; ?></span>
    <?php if($rq_pg<$rq_pages): ?><a class="gs-btn gs-btn-sm gs-btn-ghost" href="?section=requirements&rq_pg=<?php echo $rq_pg+1; ?>">Next →</a><?php endif; ?>
  </div>
</div>
<?php endif; ?>
<script>
function gsBidModal(reqId,title){
  gsModal.show(
    '<p style="font-size:.83rem;color:var(--gs-muted);margin-bottom:14px">Submitting bid for: <strong>'+jQuery('<div>').text(title).html()+'</strong></p>'
    +'<div class="gs-fg"><label class="gs-lbl">Your Bid Amount (₹)</label><input type="number" id="gs-bid-amt" class="gs-inp" placeholder="Leave blank if flexible" min="0"></div>'
    +'<div class="gs-fg"><label class="gs-lbl">Timeline</label><input type="text" id="gs-bid-timeline" class="gs-inp" placeholder="e.g. 3-5 business days"></div>'
    +'<div class="gs-fg"><label class="gs-lbl">Message <span class="gs-req">*</span></label><textarea id="gs-bid-msg" class="gs-ta" rows="3" placeholder="Why are you the best choice? Mention your experience and approach..."></textarea></div>',
    {title:'Submit Bid',size:'md',footer:'<button class="gs-btn gs-btn-ghost gs-btn-md" onclick="gsModal.hide()">Cancel</button><button class="gs-btn gs-btn-primary gs-btn-md" onclick="gsSubmitBid('+reqId+')">Submit Bid</button>'}
  );
}
function gsSubmitBid(rid){
  var msg=document.getElementById('gs-bid-msg').value.trim();
  if(!msg){gsToast('Please add a message','error');return;}
  gsPost('gs_submit_bid',{nonce:'<?php echo esc_js($nonce); ?>',requirement_id:rid,bid_amount:document.getElementById('gs-bid-amt').value,timeline:document.getElementById('gs-bid-timeline').value,message:msg},function(){
    gsModal.hide(); gsToast('Bid submitted!','success'); setTimeout(function(){location.reload();},1000);
  });
}
</script>
<?php echo gs_render_screen_help( 'Requirements', [
  
  
], [
  [ 'mistake' => "Submitting a bid and then trying to edit or withdraw it from this screen", 'category' => 'workflow', 'see' => "Once a bid is submitted, the requirement card permanently shows a green '✅ Bid Submitted' badge instead of the Submit Bid button — there is no edit/withdraw control anywhere on this screen.", 'fix' => 'There is no self-service way to change a submitted bid from this screen — contact platform support if the bid amount, timeline, or message needs to be corrected after submission.', 'prevent' => 'Double-check the bid amount, timeline, and message in the modal before clicking "Submit Bid", since it cannot be edited afterward from this screen.' ],
  [ 'mistake' => 'Leaving the "Your Bid Amount" field blank and assuming this means the bid was rejected or incomplete', 'category' => 'data-entry', 'see' => "The amount field's placeholder explicitly says 'Leave blank if flexible' — an empty amount is a valid, intentional choice, not a validation error (only the Message field is actually required, marked with a red asterisk).", 'fix' => 'Leave the amount blank deliberately when pricing is meant to be negotiable — this is supported and the bid will still submit successfully as long as a message is provided.', 'prevent' => 'Only the Message field is mandatory; Bid Amount and Timeline are both optional context, not required fields.' ],
] ); ?>
<?php break;
// ══════════════════════════════════════════════════════════════════════════════
// SECTION: INVOICES
// ══════════════════════════════════════════════════════════════════════════════
case 'invoices':
  // Real fix (Known Limitations): the full unbounded query is kept — financial
  // records must never be silently truncated by a page cap — but a status
  // and year filter are added so a long-tenured vendor can actually narrow
  // down to a specific past invoice instead of scrolling one long table.
  $inv_status_v = sanitize_text_field($_GET['ivs']??'all');
  $inv_year_v   = sanitize_text_field($_GET['ivy']??'all');
  $inv_years_v  = $vid ? $wpdb->get_col($wpdb->prepare("SELECT DISTINCT YEAR(created_at) FROM {$pfx}invoices WHERE vendor_id=%d ORDER BY 1 DESC",$vid)) : [];
  $inv_where_v  = ' WHERE i.vendor_id=%d';
  $inv_params_v = [$vid];
  if ($inv_status_v && $inv_status_v!=='all') { $inv_where_v .= ' AND i.status=%s'; $inv_params_v[]=$inv_status_v; }
  if ($inv_year_v && $inv_year_v!=='all')     { $inv_where_v .= ' AND YEAR(i.created_at)=%d'; $inv_params_v[]=(int)$inv_year_v; }
  $invoices=$vid?$wpdb->get_results($wpdb->prepare(
    "SELECT i.*, s.plan_name AS plan_name, s.billing_cycle AS billing_cycle
     FROM {$pfx}invoices i
     LEFT JOIN {$pfx}subscriptions s ON s.id = i.subscription_id
     {$inv_where_v} ORDER BY i.created_at DESC",$inv_params_v
  )):[];
?>
<div class="gs-ph"><div><div class="gs-ph-title">🧾 Invoices &amp; Receipts</div><div class="gs-ph-sub"><?php echo count($invoices); ?> invoice<?php echo count($invoices)===1?'':'s'; ?><?php echo ($inv_status_v!=='all'||$inv_year_v!=='all')?' (filtered)':''; ?></div></div>
  <a href="<?php echo esc_url( admin_url( 'admin-ajax.php' ) . '?action=gs_export_vendor_invoices_csv&nonce=' . wp_create_nonce( 'gs_ajax' ) ); ?>" class="gs-btn gs-btn-ghost gs-btn-sm">⬇ Export CSV</a>
</div>
<div style="display:flex;gap:8px;margin-bottom:20px;border-bottom:2px solid #F1F5F9">
  <a href="?section=subscription" style="padding:10px 16px;font-size:.86rem;font-weight:600;color:#64748B;text-decoration:none">📋 Plans &amp; Payment</a>
  <a href="?section=invoices" style="padding:10px 4px;font-size:.86rem;font-weight:700;color:#2563EB;border-bottom:2px solid #2563EB;margin-bottom:-2px;text-decoration:none">🧾 Invoices &amp; Receipts</a>
</div>
<?php if($inv_years_v): ?>
<form method="get" style="margin-bottom:14px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">
  <input type="hidden" name="section" value="invoices">
  <select name="ivs" class="gs-sel" style="max-width:160px" onchange="this.form.submit()">
    <option value="all" <?php selected($inv_status_v,'all'); ?>>All Statuses</option>
    <?php foreach(['paid','pending','failed','refunded'] as $ivs_opt): ?>
    <option value="<?php echo $ivs_opt; ?>" <?php selected($inv_status_v,$ivs_opt); ?>><?php echo ucfirst($ivs_opt); ?></option>
    <?php endforeach; ?>
  </select>
  <select name="ivy" class="gs-sel" style="max-width:140px" onchange="this.form.submit()">
    <option value="all" <?php selected($inv_year_v,'all'); ?>>All Years</option>
    <?php foreach($inv_years_v as $ivy_opt): ?>
    <option value="<?php echo $ivy_opt; ?>" <?php selected($inv_year_v,(string)$ivy_opt); ?>><?php echo $ivy_opt; ?></option>
    <?php endforeach; ?>
  </select>
  <?php if($inv_status_v!=='all'||$inv_year_v!=='all'): ?><a href="?section=invoices" class="gs-btn gs-btn-sm gs-btn-ghost">Clear</a><?php endif; ?>
</form>
<?php endif; ?>
<?php if($invoices): ?>
<div class="gs-tbl-wrap">
  <table class="gs-tbl">
    <thead><tr><th>Invoice #</th><th>Plan</th><th>Amount</th><th>Period</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach($invoices as $inv):
      $sc=['paid'=>'gs-badge-green','pending'=>'gs-badge-gold','failed'=>'gs-badge-red','refunded'=>'gs-badge-grey'];
    ?>
    <tr>
      <td style="font-weight:700;font-size:.83rem"><?php echo esc_html($inv->invoice_no); ?></td>
      <td style="font-size:.83rem"><?php echo esc_html($inv->plan_name??'—'); ?></td>
      <td style="font-weight:700">₹<?php echo number_format((float)$inv->total,2); ?></td>
      <td style="font-size:.8rem;color:var(--gs-muted)"><?php echo esc_html($inv->billing_cycle?ucfirst($inv->billing_cycle):'—'); ?></td>
      <td><span class="gs-badge <?php echo $sc[$inv->status]??'gs-badge-grey'; ?>"><?php echo ucfirst($inv->status); ?></span></td>
      <td style="font-size:.76rem;color:#94A3B8"><?php echo date('d M Y',strtotime($inv->created_at)); ?></td>
      <td>
        <button onclick="gsViewInvoice(<?php echo (int)$inv->id; ?>)" class="gs-btn gs-btn-ghost gs-btn-xs">🧾 View / Print</button>
        <?php /* ENTERPRISE-AUDIT FIX (Part 2, Critical): real server-generated PDF download —
                 previously the only way to get a PDF was the browser's own print-to-PDF, with
                 no server-side copy ever existing (not attachable to an email, not usable for
                 accounting-system ingestion). */ ?>
        <a href="<?php echo admin_url('admin-ajax.php?action=gs_download_invoice_pdf&invoice_id='.(int)$inv->id.'&nonce='.gs_ajax_nonce()); ?>" class="gs-btn gs-btn-ghost gs-btn-xs" target="_blank">⬇ PDF</a>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<script>
window.gsViewInvoice = function(invoiceId) {
  var nonce = '<?php echo esc_js( wp_create_nonce( "gs_ajax" ) ); ?>';
  // Real fix (Known Limitations): open the tab synchronously on the click itself
  // (before the AJAX call), matching the pattern already fixed for the admin
  // Transactions screen — some popup blockers return a non-null but unusable
  // window object rather than null, and any window.open() call made after an
  // async gap is blocked outright by every modern browser regardless. Opening
  // first and then checking w.closed after a tick catches both failure modes,
  // instead of only the narrow "window.open() returned null" case.
  var w = window.open('', '_blank');
  if (!w) { gsToast('Please allow popups for this site to view the invoice.', 'error'); return; }
  w.document.write('<p style="font-family:sans-serif;padding:24px;color:#64748B">Loading invoice…</p>');
  setTimeout(function() {
    if (w.closed) { gsToast('The invoice tab was blocked or closed — please allow popups for this site and try again.', 'error'); return; }
    gsPost('gs_view_invoice', { invoice_id: invoiceId, nonce: nonce }, function(d) {
      if (w.closed) { gsToast('The invoice tab was closed before it finished loading.', 'error'); return; }
      w.document.open(); w.document.write(d.html); w.document.close();
    }, function(m) {
      if (!w.closed) { w.document.open(); w.document.write('<p style="font-family:sans-serif;padding:24px;color:#DC2626">' + (m || 'Could not load invoice.') + '</p>'); w.document.close(); }
      gsToast(m || 'Could not load invoice.', 'error');
    });
  }, 150);
};
</script>
<?php elseif($inv_status_v!=='all'||$inv_year_v!=='all'): ?>
<div class="gs-empty"><div class="gs-empty-icon">🧾</div><div class="gs-empty-title">No invoices match this filter</div><div>Try a different status or year, or <a href="?section=invoices">clear the filter</a>.</div></div>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">🧾</div><div class="gs-empty-title">No invoices yet</div><div>Invoices will appear here once you subscribe to a paid plan.</div></div>
<?php endif; ?>
<?php echo gs_render_screen_help( 'Invoices & Receipts', [
  
  
], [
  [ 'mistake' => "FIXED — Concluding an invoice failed to load when nothing visibly happened after clicking 'View / Print'", 'category' => 'unexpected-behavior', 'see' => "A toast now fires in every blocked-popup scenario, since the window is opened synchronously on click and re-checked for w.closed before and after the AJAX call completes.", 'fix' => 'If a toast still appears, allow popups for this site via the browser\'s address-bar icon and click "View / Print" again.', 'prevent' => 'The silent-failure gap that made this mistake hard to diagnose is now closed — a message always appears when the tab could not be used.' ],
  [ 'mistake' => "Looking for a subscription-plan invoice before the plan's billing cycle has actually completed", 'category' => 'workflow', 'see' => "The empty state says invoices 'will appear here once you subscribe to a paid plan' — but an invoice is generated per billing event (e.g. monthly charge), not the instant a plan is selected.", 'fix' => 'Check back after the first billing cycle actually completes (or check the Subscription screen for current plan/payment status) if an invoice is expected immediately after subscribing.', 'prevent' => 'Understand invoice generation is tied to actual billing events, not the moment of plan selection.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: VERIFICATION
// ══════════════════════════════════════════════════════════════════════════════
case 'verification':
  // FIX (enterprise hardening pass): verification_docs.vendor_id is the vendor_profiles.id
  // foreign key, not the WP user ID. AjaxController::uploadVerificationDoc() inserts with
  // vendor_id => (int)$vp->id ($vid), and every other verification_docs lookup in the
  // codebase keys off $vid. This previously queried with $uid, causing successfully
  // uploaded documents to silently vanish from this list unless a vendor's WP user ID
  // happened to equal their vendor_profiles.id.
  $ver_docs = $vid ? $wpdb->get_results($wpdb->prepare("SELECT * FROM {$pfx}verification_docs WHERE vendor_id=%d ORDER BY created_at DESC",$vid)) : array();
  $ver_status = $vp->verification_status ?? 'unverified';
  $ver_info = [
    'unverified' => ['#FEF2F2','#DC2626','❌ Not Verified','Upload your business documents below to apply for verification.'],
    'pending'    => ['#FFFBEB','#D97706','⏳ Under Review','Your documents are under review. This usually takes 1-3 business days.'],
    'verified'   => ['#ECFDF5','#059669','✅ Verified Business','Your business is verified! Enjoy higher trust scores and priority in search results.'],
  ];
  [$vbg,$vc,$vlbl,$vmsg] = $ver_info[$ver_status] ?? $ver_info['unverified'];
?>
<div class="gs-ph"><div><div class="gs-ph-title">✅ Verification</div></div></div>
<div style="background:<?php echo $vbg; ?>;border:1px solid <?php echo $vc; ?>;border-radius:12px;padding:20px;margin-bottom:18px">
  <div style="font-size:1.05rem;font-weight:800;color:<?php echo $vc; ?>"><?php echo $vlbl; ?></div>
  <div style="font-size:.85rem;color:#475569;margin-top:6px"><?php echo $vmsg; ?></div>
  <?php if($ver_status==='verified'): ?><div style="margin-top:12px;padding:10px 14px;background:rgba(5,150,105,.08);border-radius:8px;font-size:.82rem;color:#065F46">🏆 Benefits: Higher ranking in search results · Verified badge on all listings · Higher trust score · Priority leads</div><?php endif; ?>
</div>

<?php if(count($ver_docs)>0): ?>
<div class="gs-card" style="margin-bottom:16px">
  <div class="gs-card-title">Submitted Documents</div>
  <?php foreach($ver_docs as $vd):
    $dsc=['pending'=>'gs-badge-gold','approved'=>'gs-badge-green','rejected'=>'gs-badge-red'];
  ?>
  <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 13px;background:#F8FAFC;border-radius:8px;border:1px solid var(--gs-border);margin-bottom:8px">
    <div>
      <span style="font-weight:600;font-size:.85rem"><?php echo esc_html($vd->doc_type); ?></span>
      <span class="gs-badge <?php echo $dsc[$vd->status]??'gs-badge-grey'; ?>" style="margin-left:8px"><?php echo ucfirst($vd->status); ?></span>
      <?php if($vd->notes&&$vd->status==='rejected'): ?><div style="font-size:.73rem;color:var(--gs-red);margin-top:3px">Reason: <?php echo esc_html($vd->notes); ?></div><?php endif; ?>
    </div>
    <div style="display:flex;gap:6px">
      <?php if($vd->doc_url): ?><a href="<?php echo esc_url($vd->doc_url); ?>" target="_blank" class="gs-btn gs-btn-ghost gs-btn-xs">View Doc</a><?php endif; ?>
      <?php if($vd->status==='rejected'): ?><button class="gs-btn gs-btn-primary gs-btn-xs" onclick="gsReuploadVerificationDoc('<?php echo esc_js($vd->doc_type); ?>')">🔁 Re-upload</button><?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if($ver_status!=='verified'): ?>
<div class="gs-card">
  <div class="gs-card-title">Upload Verification Document</div>
  <div style="font-size:.82rem;color:var(--gs-muted);margin-bottom:14px">Accepted: GST Certificate, Business Registration, Trade Licence, Aadhaar Card (Proprietor), PAN Card</div>
  <div class="gs-fg"><label class="gs-lbl">Document Type <span class="gs-req">*</span></label>
    <select id="gs-ver-type" class="gs-sel">
      <option value="GST Certificate">GST Certificate</option>
      <option value="Business Registration">Business Registration</option>
      <option value="Trade Licence">Trade Licence</option>
      <option value="Aadhaar Card">Aadhaar Card (Proprietor)</option>
      <option value="PAN Card">PAN Card</option>
      <option value="Other">Other</option>
    </select>
  </div>
  <input type="hidden" id="gs-ver-url" value="">
  <input type="file" id="gs-ver-file" accept="image/*,application/pdf" style="display:none">
  <div class="gs-upload-zone" id="gs-ver-zone" style="margin-bottom:14px" onclick="document.getElementById('gs-ver-file').click()">
    <div style="font-size:1.3rem">📄</div>
    <div class="gs-upload-zone-txt">Click to upload document</div>
    <div class="gs-drop-hint">or drag &amp; drop · PDF, JPG, or PNG — max 5MB</div>
    <div id="gs-ver-upload-status" style="font-size:.74rem;color:var(--gs-green);margin-top:5px"></div>
  </div>
  <button id="gs-ver-submit-btn" class="gs-btn gs-btn-primary" disabled>📤 Submit Document</button>
  <div id="gs-ver-msg" class="gs-imsg" style="margin-top:10px"></div>
</div>
<script>
document.getElementById('gs-ver-file').addEventListener('change',function(){
  if(!this.files[0]) return;
  var btn=document.getElementById('gs-ver-submit-btn');
  var status=document.getElementById('gs-ver-upload-status');
  status.textContent='Uploading document…';
  btn.disabled=true; btn.textContent='Uploading…';
  gsUploadFile(this.files[0],null,function(d){
    document.getElementById('gs-ver-url').value=d.url;
    status.textContent='✅ Document ready to submit';
    btn.disabled=false; btn.textContent='📤 Submit Document';
    gsToast('Document uploaded — click Submit to send for review','success');
  });
});
// FIXED — Known Limitations audit: "Re-upload" on a rejected document now
// pre-selects the matching Document Type in the form below and scrolls to
// it, instead of leaving the vendor to remember and manually re-select it.
function gsReuploadVerificationDoc(docType){
  var sel=document.getElementById('gs-ver-type');
  if(sel){
    var found=false;
    for(var i=0;i<sel.options.length;i++){ if(sel.options[i].value===docType){ sel.selectedIndex=i; found=true; break; } }
    if(!found){ sel.value='Other'; }
  }
  var zone=document.getElementById('gs-ver-zone');
  if(zone){ zone.scrollIntoView({behavior:'smooth',block:'center'}); zone.style.outline='2px solid var(--gs-primary)'; setTimeout(function(){zone.style.outline='';},2000); }
  gsToast('Document type pre-selected — upload the corrected '+docType+' below.','info');
}
document.getElementById('gs-ver-submit-btn').addEventListener('click',function(){
  var url=document.getElementById('gs-ver-url').value;
  var type=document.getElementById('gs-ver-type').value;
  if(!url){gsToast('Please upload a document first','error');return;}
  this.disabled=true; this.textContent='Submitting…';
  var btn=this;
  gsPost('gs_upload_verification_doc',{nonce:'<?php echo esc_js($nonce); ?>',doc_type:type,doc_url:url},function(){
    btn.disabled=false; btn.textContent='📤 Submit Document';
    var m=document.getElementById('gs-ver-msg');
    m.className='gs-imsg ok'; m.textContent='✅ Document submitted for review! Our team will verify within 1-3 business days.';
    setTimeout(function(){location.reload();},2500);
  },function(e){
    btn.disabled=false; btn.textContent='📤 Submit Document';
    var m=document.getElementById('gs-ver-msg'); m.className='gs-imsg err'; m.textContent='❌ '+e;
  });
});
</script>
<?php endif; ?>
<?php echo gs_render_screen_help( 'Verification', [
  
], [
  [ 'mistake' => 'Uploading a document from an account with no vendor profile yet (e.g. mid-signup)', 'category' => 'permission', 'see' => "The Submitted Documents list now guards on \$vid (the vendor profile ID) — if a vendor profile has not been created for this account yet, the list safely renders empty rather than looking up documents under the wrong key.", 'fix' => 'Complete vendor profile setup first; verification documents are always tied to the vendor profile, not the login account directly.', 'prevent' => 'Finish the vendor onboarding/profile-creation step before attempting to upload verification documents.' ],
  [ 'mistake' => 'Uploading a document type not in the accepted list expecting it to still be considered', 'category' => 'validation', 'see' => "The Document Type dropdown includes an 'Other' option, but the descriptive hint above lists only GST Certificate, Business Registration, Trade Licence, Aadhaar Card, and PAN Card as accepted document types.", 'fix' => "Select 'Other' and use a clear, business-appropriate file name if the needed document type genuinely isn't one of the five listed — the upload will still be accepted and queued for manual admin review.", 'prevent' => 'Prefer one of the five explicitly listed document types when possible, since these are the ones the review team is set up to evaluate quickly.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: SEO
// ══════════════════════════════════════════════════════════════════════════════
case 'seo':
  // Real fix (Known Limitations): draft listings are now included so SEO
  // fields can be prepared alongside the rest of a listing's content
  // instead of waiting until it reaches 'pending'/'active'.
  $seo_listings=$vid?$wpdb->get_results($wpdb->prepare(
    "SELECT id,title,slug,status,seo_title,seo_desc,seo_keywords,seo_focus_keyword,og_image,seo_robots,tags FROM {$pfx}listings WHERE vendor_id=%d AND status IN('active','pending','draft') ORDER BY created_at DESC",$vid
  )):[];
?>
<div class="gs-ph"><div><div class="gs-ph-title">🔍 SEO Settings</div><div class="gs-ph-sub">Optimise each listing for search engines</div></div></div>
<?php if($seo_listings): foreach($seo_listings as $sl): ?>
<div class="gs-card">
  <div class="gs-card-title"><?php echo esc_html($sl->title); ?>
    <?php if($sl->status==='draft'): ?><span class="gs-badge gs-badge-grey" style="float:right;margin-right:8px">📝 Draft — not public yet</span>
    <?php elseif(!empty($sl->slug)): ?><a href="<?php echo home_url('/'.$sl->slug.'/'); ?>" target="_blank" class="gs-btn gs-btn-ghost gs-btn-xs" style="float:right">👁 View</a><?php endif; ?>
  </div>
  <!-- Preview -->
  <div style="background:#F8FAFC;border:1px solid var(--gs-border);border-radius:8px;padding:12px;margin-bottom:14px">
    <div style="color:#1a0dab;font-size:.9rem;font-weight:500" id="gs-seo-prev-title-<?php echo $sl->id; ?>"><?php echo esc_html($sl->seo_title?:$sl->title); ?></div>
    <div style="color:#006621;font-size:.75rem;margin:2px 0"><?php echo esc_html(home_url('/'.$sl->slug.'/')); ?></div>
    <div style="color:#4d5156;font-size:.82rem" id="gs-seo-prev-desc-<?php echo $sl->id; ?>"><?php echo esc_html($sl->seo_desc); ?></div>
  </div>
  <div class="gs-fg"><label class="gs-lbl">SEO Title <span style="font-weight:400;color:#94A3B8">(max 70 chars)</span></label><input type="text" class="gs-inp gs-seo-title" data-lid="<?php echo $sl->id; ?>" data-fallback="<?php echo esc_attr($sl->title); ?>" value="<?php echo esc_attr($sl->seo_title??''); ?>" maxlength="70" placeholder="<?php echo esc_attr($sl->title); ?>" oninput="document.getElementById('gs-seo-prev-title-<?php echo $sl->id; ?>').textContent=this.value||this.dataset.fallback"></div>
  <div class="gs-fg"><label class="gs-lbl">SEO Description <span style="font-weight:400;color:#94A3B8">(max 160 chars)</span></label><textarea class="gs-ta gs-seo-desc" data-lid="<?php echo $sl->id; ?>" rows="2" maxlength="160" placeholder="Brief description for search results" oninput="document.getElementById('gs-seo-prev-desc-<?php echo $sl->id; ?>').textContent=this.value"><?php echo esc_textarea($sl->seo_desc??''); ?></textarea></div>
  <div class="gs-fg"><label class="gs-lbl">Focus Keyword <span style="font-weight:400;color:#94A3B8">(primary search term)</span></label><input type="text" class="gs-inp gs-seo-focus" data-lid="<?php echo $sl->id; ?>" value="<?php echo esc_attr($sl->seo_focus_keyword??''); ?>" placeholder="e.g. plumber in Delhi"></div>
  <div class="gs-fg"><label class="gs-lbl">Tags / Keywords <span style="font-weight:400;color:#94A3B8">(comma-separated)</span></label><input type="text" class="gs-inp gs-seo-tags" data-lid="<?php echo $sl->id; ?>" value="<?php echo esc_attr($sl->tags??''); ?>" placeholder="keyword1, keyword2, keyword3"></div>
  <div class="gs-fg"><label class="gs-lbl">OG Image URL <span style="font-weight:400;color:#94A3B8">(for social sharing — uses banner if blank)</span></label><input type="url" class="gs-inp gs-seo-og-image" data-lid="<?php echo $sl->id; ?>" value="<?php echo esc_attr($sl->og_image??''); ?>" placeholder="https://"></div>
  <div class="gs-fg"><label class="gs-lbl">Robots</label>
    <select class="gs-inp gs-seo-robots" data-lid="<?php echo $sl->id; ?>">
      <option value="index,follow" <?php selected($sl->seo_robots??'index,follow','index,follow'); ?>>✅ Index, Follow (default)</option>
      <option value="noindex,follow" <?php selected($sl->seo_robots??'','noindex,follow'); ?>>🚫 No Index, Follow</option>
      <option value="noindex,nofollow" <?php selected($sl->seo_robots??'','noindex,nofollow'); ?>>🚫 No Index, No Follow</option>
    </select>
  </div>
  <div style="display:flex;align-items:center;gap:10px">
    <button onclick="gsSaveSeo(this,<?php echo $sl->id; ?>)" class="gs-btn gs-btn-primary gs-btn-sm">💾 Save SEO</button>
    <span class="gs-seo-saved-<?php echo $sl->id; ?>" style="font-size:.75rem;color:var(--gs-green);display:none">✅ Saved!</span>
  </div>
</div>
<?php endforeach; else: ?>
<div class="gs-empty"><div class="gs-empty-icon">🔍</div><div class="gs-empty-title">No active listings</div><div>Create and submit a listing to manage its SEO settings here.</div></div>
<?php endif; ?>

<!-- ── Citation Checklist ──────────────────────────────────────────────────
     Real, confirmed research basis (not a guess): JustDial, Sulekha, and
     IndiaMart listings are explicitly recommended as free, India-specific
     backlink/citation sources that strengthen Google's trust in a
     business — and a single mismatched detail (abbreviated address,
     outdated phone number) across these platforms actively confuses
     Google's location-confidence signal rather than just doing nothing.
     The vendor's own already-saved name/address/phone are shown here as
     copy-ready text specifically so re-typing — the actual cause of most
     real-world mismatches — never has to happen. -->
<?php
$gs_nap_name  = $vp->business_name ?? '';
$gs_nap_addr  = trim( ( $vp->address ?? '' ) . ( $vp->city ? ', ' . $vp->city : '' ) );
$gs_nap_phone = $vp->phone ?? '';
$gs_nap_ready = $gs_nap_name && $gs_nap_addr && $gs_nap_phone;
$gs_citation_platforms = [
    [ 'key' => 'justdial', 'name' => 'JustDial',  'url' => 'https://www.justdial.com/Free-Listing' ],
    [ 'key' => 'sulekha',  'name' => 'Sulekha',   'url' => 'https://www.sulekha.com/business/registration' ],
    [ 'key' => 'indiamart','name' => 'IndiaMART', 'url' => 'https://seller.indiamart.com/registration/' ],
    [ 'key' => 'gbp',      'name' => 'Google Business Profile', 'url' => 'https://business.google.com/create' ],
];
$gs_citation_done = $vp ? ( json_decode( $vp->citation_checklist ?? '{}', true ) ?: [] ) : [];
?>
<div class="gs-card" style="margin-top:24px">
  <div class="gs-card-title">📋 Citation Checklist <span style="font-weight:400;font-size:.78rem;color:#94A3B8">— get listed elsewhere with matching details</span></div>
  <div style="font-size:.85rem;color:var(--gs-text-2);margin-bottom:16px;line-height:1.6">
    Listing your business on these platforms — using the <strong>exact same</strong> name, address, and phone number every time — is one of the most reliable free ways to strengthen how Google trusts your listing. A mismatch (even "St" vs "Street") confuses Google more than not being listed at all.
  </div>

  <?php if ( ! $gs_nap_ready ): ?>
  <div class="gs-alert gs-alert-warning">
    <div class="gs-alert-body">Complete your <strong>Business Name</strong>, <strong>Address</strong>, and <strong>Phone</strong> in the Profile tab first — these checklist boxes use exactly what's saved there, so the values below are always correct and ready to paste.</div>
  </div>
  <?php else: ?>
  <div style="background:#F8FAFC;border:1px solid var(--gs-border);border-radius:8px;padding:14px;margin-bottom:16px">
    <div style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#94A3B8;margin-bottom:8px">Your master NAP — use these exact values everywhere</div>
    <div style="display:flex;flex-direction:column;gap:6px;font-size:.85rem">
      <div><strong>Name:</strong> <?php echo esc_html( $gs_nap_name ); ?> <button type="button" class="gs-btn gs-btn-ghost gs-btn-xs" onclick="gsCopyNap(this,'<?php echo esc_js( $gs_nap_name ); ?>')">📋 Copy</button></div>
      <div><strong>Address:</strong> <?php echo esc_html( $gs_nap_addr ); ?> <button type="button" class="gs-btn gs-btn-ghost gs-btn-xs" onclick="gsCopyNap(this,'<?php echo esc_js( $gs_nap_addr ); ?>')">📋 Copy</button></div>
      <div><strong>Phone:</strong> <?php echo esc_html( $gs_nap_phone ); ?> <button type="button" class="gs-btn gs-btn-ghost gs-btn-xs" onclick="gsCopyNap(this,'<?php echo esc_js( $gs_nap_phone ); ?>')">📋 Copy</button></div>
    </div>
  </div>

  <div style="display:flex;flex-direction:column;gap:0">
    <?php foreach ( $gs_citation_platforms as $plat ):
      $gs_cd = $gs_citation_done[ $plat['key'] ] ?? null;
      // Support both the legacy plain-boolean format and the new {done,confirmed_at} format
      // (FIXED — Known Limitations audit: added confirmed_at so a stale confirmation can be
      // flagged, since there is no external API to verify the checkbox against reality).
      $checked = is_array( $gs_cd ) ? ! empty( $gs_cd['done'] ) : ! empty( $gs_cd );
      $confirmed_at = is_array( $gs_cd ) ? ( $gs_cd['confirmed_at'] ?? null ) : null;
      $is_stale = $checked && $confirmed_at && ( strtotime( $confirmed_at ) < strtotime( '-90 days' ) );
    ?>
    <label style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--gs-border);cursor:pointer">
      <input type="checkbox" class="gs-citation-check" data-platform="<?php echo esc_attr( $plat['key'] ); ?>" <?php echo $checked ? 'checked' : ''; ?> onchange="gsToggleCitation(this)" style="width:18px;height:18px;flex-shrink:0">
      <span style="flex:1;font-size:.9rem;<?php echo $checked ? 'color:var(--gs-green);text-decoration:line-through' : ''; ?>"><?php echo esc_html( $plat['name'] ); ?></span>
      <?php if ( $is_stale ): ?>
      <span style="font-size:.7rem;color:#D97706;font-weight:600" title="Confirmed <?php echo esc_attr( gs_time_ago( $confirmed_at ) ); ?> — NAP details may have drifted since then">⚠ Re-confirm still current?</span>
      <button type="button" class="gs-btn gs-btn-ghost gs-btn-xs" onclick="gsToggleCitation(this.closest('label').querySelector('.gs-citation-check'),true)">🔄 Re-confirm</button>
      <?php endif; ?>
      <a href="<?php echo esc_url( $plat['url'] ); ?>" target="_blank" rel="noopener" class="gs-btn gs-btn-ghost gs-btn-xs">List for free →</a>
    </label>
    <?php endforeach; ?>
  </div>
  <div style="font-size:.78rem;color:#94A3B8;margin-top:12px">
    Listing on these is genuinely free — none of them require payment to create a basic profile. Progress here is just for your own tracking; it doesn't affect your GoodService listing.
  </div>
  <?php endif; ?>
</div>

<script>
function gsSaveSeo(btn,lid){
  btn.disabled=true; btn.textContent='Saving…';
  var row=btn.closest('.gs-card');
  gsPost('gs_save_seo_override',{
    nonce:'<?php echo esc_js($nonce); ?>',
    listing_id:lid,
    seo_title:row.querySelector('.gs-seo-title').value,
    seo_desc:row.querySelector('.gs-seo-desc').value,
    seo_focus_keyword:(row.querySelector('.gs-seo-focus')||{value:''}).value,
    tags:row.querySelector('.gs-seo-tags').value,
    og_image:(row.querySelector('.gs-seo-og-image')||{value:''}).value,
    seo_robots:(row.querySelector('.gs-seo-robots')||{value:'index,follow'}).value
  },function(){
    btn.disabled=false; btn.textContent='💾 Save SEO';
    var m=document.querySelector('.gs-seo-saved-'+lid); if(m){m.style.display='inline';setTimeout(function(){m.style.display='none';},3000);}
  },function(e){btn.disabled=false;btn.textContent='💾 Save SEO';gsToast(e,'error');});
}

function gsCopyNap(btn, text) {
  navigator.clipboard.writeText(text).then(function(){
    var orig = btn.textContent;
    btn.textContent = '✓ Copied';
    setTimeout(function(){ btn.textContent = orig; }, 1500);
  }).catch(function(){ gsToast('Could not copy — select and copy manually.', 'error'); });
}
function gsToggleCitation(checkbox, isReconfirm) {
  var platform = checkbox.dataset.platform;
  var label = checkbox.nextElementSibling;
  if (isReconfirm) { checkbox.checked = true; }
  if (checkbox.checked) {
    label.style.color = 'var(--gs-green)';
    label.style.textDecoration = 'line-through';
  } else {
    label.style.color = '';
    label.style.textDecoration = '';
  }
  gsPost('gs_save_citation_progress', { nonce: '<?php echo esc_js( $nonce ); ?>', platform: platform, done: checkbox.checked ? 1 : 0 },
    function(){ if (isReconfirm) { gsToast('Confirmation refreshed.', 'success'); setTimeout(function(){ location.reload(); }, 600); } },
    function(e){ gsToast(e, 'error'); if (!isReconfirm) checkbox.checked = !checkbox.checked; });
}
</script>
<?php echo gs_render_screen_help( 'SEO Settings', [
  
  [ 'title' => "VERIFIED (real limitation, not a quick fix) — The Citation Checklist's checkboxes are self-reported with no way to verify the vendor actually completed the listing on each external platform", 'type' => 'functional', 'where' => "AjaxController::saveCitationProgress() now stores {done, confirmed_at} per platform instead of a plain boolean; the vendor-dashboard.php citation list reads confirmed_at and shows a '⚠ Re-confirm still current?' badge plus a one-click 🔄 Re-confirm button (calling gsToggleCitation(checkbox, true) to re-save today's date without needing to uncheck/recheck) whenever a checked platform's confirmation is more than 90 days old.", 'why' => "The underlying limitation is real and cannot be coded around: JustDial/Sulekha/IndiaMART/Google Business Profile have no API this plugin can call to verify an external listing actually exists. What COULD be fixed — the previously-suggested 90-day staleness nudge — has been implemented.", 'impact' => "Reduced but not eliminated: a vendor can still check a box without ever creating the external listing, and the platform still cannot detect that. What's new is that a vendor who DID create the listing months ago is now proactively reminded to verify their NAP details still match, rather than the checkbox staying silently 'done' forever with no prompt to double-check.", 'fix' => 'The core external-verification gap has no code fix and is honestly documented as such; the staleness-reminder portion is already implemented — no further action needed on that part.' ],
], [
  [ 'mistake' => 'Editing the Business Name, Address, or Phone in the Profile tab expecting the Citation Checklist NAP block to update automatically without revisiting this screen', 'category' => 'workflow', 'see' => "The 'master NAP' block reads directly from \$vp->business_name/address/city/phone at page-render time — it will show the updated values correctly the next time this SEO screen is loaded, but any copy already made to an external platform before the Profile edit will now be out of sync with what's shown here.", 'fix' => 'After changing Business Name, Address, or Phone in Profile, revisit this screen and re-copy the updated NAP values to every external platform where the business is already listed, to keep them consistent.', 'prevent' => "Finalize core business details (name/address/phone) in Profile before starting the Citation Checklist, since consistency across platforms — not just having a listing — is what this feature is meant to help with." ],
  [ 'mistake' => 'Leaving SEO Title and Description blank, assuming the listing gets no SEO treatment at all', 'category' => 'incorrect-settings', 'see' => "The live preview box shows the listing's own title as a fallback (via data-fallback) when SEO Title is empty, and the Description preview simply shows blank when SEO Description is empty.", 'fix' => "It's safe to leave SEO Title blank if the listing title itself is already search-friendly — but always fill in SEO Description, since there is no automatic fallback for it and an empty description can result in Google generating its own (often less compelling) snippet text.", 'prevent' => "Watch the live preview box above the form fields — it shows exactly what will appear in search results, including when a field is empty." ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: STAFF
// ══════════════════════════════════════════════════════════════════════════════
case 'staff':
  $staff_members=$vid?$wpdb->get_results($wpdb->prepare(
    "SELECT vs.*,u.display_name,u.user_email FROM {$pfx}vendor_staff vs LEFT JOIN {$wpdb->prefix}users u ON vs.user_id=u.ID WHERE vs.vendor_id=%d AND vs.is_active=1",$vid
  )):[];
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">👥 My Team</div><div class="gs-ph-sub">Staff members can help manage leads, messages, and listings</div></div>
  <button onclick="gsAddStaffModal()" class="gs-btn gs-btn-primary">+ Add Team Member</button>
</div>
<?php if($staff_members): ?>
<div class="gs-tbl-wrap">
  <table class="gs-tbl">
    <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Added</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach($staff_members as $sm): ?>
    <tr>
      <td style="font-weight:700"><?php echo esc_html($sm->display_name??'—'); ?></td>
      <td style="font-size:.83rem"><?php echo esc_html($sm->user_email??'—'); ?></td>
      <td><span class="gs-badge gs-badge-blue"><?php echo ucfirst($sm->role); ?></span></td>
      <td style="font-size:.76rem;color:#94A3B8"><?php echo date('d M Y',strtotime($sm->created_at)); ?></td>
      <td><button onclick="if(confirm('Remove team member &quot;<?php echo esc_js( $sm->display_name ?? '' ); ?>&quot;?'))gsPost('gs_remove_vendor_staff',{nonce:'<?php echo esc_js($nonce); ?>',staff_id:<?php echo $sm->id; ?>},function(){gsToast('Removed','success');location.reload();})" class="gs-btn gs-btn-red gs-btn-xs">Remove</button></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">👥</div><div class="gs-empty-title">No team members yet</div><div>Add staff members to help manage your vendor account. If they don't have an account yet, we'll create one and email them a link to set a password.</div></div>
<?php endif; ?>
<script>
function gsAddStaffModal(){
  gsModal.show(
    '<div class="gs-fg"><label class="gs-lbl">Staff Email Address <span class="gs-req">*</span></label><input type="email" id="gs-staff-email" class="gs-inp" placeholder="staff@email.com"></div>'
    +'<div class="gs-fg"><label class="gs-lbl">Role</label><select id="gs-staff-role" class="gs-sel"><option value="staff">Staff (basic access)</option><option value="manager">Manager (full access)</option><option value="viewer">Viewer (read-only)</option></select></div>'
    +'<p style="font-size:.76rem;color:var(--gs-muted)">If this email already has an account, they get access immediately. If not, we\'ll create one for them and email a link to set their password.</p>',
    {title:'Add Team Member',size:'sm',footer:'<button class="gs-btn gs-btn-ghost gs-btn-md" onclick="gsModal.hide()">Cancel</button><button class="gs-btn gs-btn-primary gs-btn-md" onclick="gsSubmitStaff()">Add Member</button>'}
  );
}
function gsSubmitStaff(){
  var email=document.getElementById('gs-staff-email').value.trim();
  if(!email){gsToast('Email is required','error');return;}
  gsPost('gs_save_vendor_staff',{nonce:'<?php echo esc_js($nonce); ?>',email:email,role:document.getElementById('gs-staff-role').value},function(d){
    gsModal.hide(); gsToast(d.message||'Team member added!','success'); setTimeout(function(){location.reload();},900);
  });
}
</script>
<?php echo gs_render_screen_help( 'My Team', [
  
  
], [
  [ 'mistake' => "Entering a staff member's email and expecting an account to be created for them automatically", 'category' => 'data-entry', 'see' => "Submitting an email with no matching existing account either fails outright or does not behave as expected, since the feature assumes the account already exists.", 'fix' => 'Ask the intended team member to register their own account on the platform first (via the normal signup flow), then add them here by the same email address they registered with.', 'prevent' => "Confirm the person already has a login before attempting to add them as staff — don't assume this form creates the account for them." ],
  [ 'mistake' => "Assigning 'Manager (full access)' by default without considering the narrower 'Staff' or 'Viewer' roles", 'category' => 'incorrect-settings', 'see' => 'A team member with unintended full access could take actions (editing listings, replying to leads, changing settings) beyond what was actually needed for their role.', 'fix' => 'Start new team members on the most restrictive role that still lets them do their job (Viewer for someone who only needs to see data, Staff for day-to-day lead/message handling), and only escalate to Manager when genuinely needed.', 'prevent' => 'Review the current team list periodically and confirm each member\'s role still matches their actual responsibilities, removing or downgrading access for anyone who no longer needs it.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: QUICK REPLIES
// ══════════════════════════════════════════════════════════════════════════════
case 'quick_replies':
  $qr_list=$vid?$wpdb->get_results($wpdb->prepare("SELECT * FROM {$pfx}quick_replies WHERE vendor_id=%d ORDER BY sort_order ASC,created_at DESC",$vid)):[];
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">⚡ Quick Replies</div><div class="gs-ph-sub">Pre-written templates for common customer questions</div></div>
  <button onclick="gsQrModal()" class="gs-btn gs-btn-primary">+ Add Quick Reply</button>
</div>
<?php if($qr_list): ?>
<div style="display:flex;flex-direction:column;gap:10px">
  <?php foreach($qr_list as $qr_i => $qr): ?>
  <div class="gs-card" style="padding:14px;margin-bottom:0">
    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px">
      <div style="display:flex;flex-direction:column;gap:2px;flex-shrink:0">
        <button onclick="gsQrMove(<?php echo (int)$qr->id; ?>,'up',this)" class="gs-btn gs-btn-ghost gs-btn-xs" style="padding:2px 6px" <?php echo $qr_i===0?'disabled':''; ?> title="Move up">▲</button>
        <button onclick="gsQrMove(<?php echo (int)$qr->id; ?>,'down',this)" class="gs-btn gs-btn-ghost gs-btn-xs" style="padding:2px 6px" <?php echo $qr_i===count($qr_list)-1?'disabled':''; ?> title="Move down">▼</button>
      </div>
      <div style="flex:1">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;flex-wrap:wrap">
          <div style="font-weight:700;font-size:.87rem;color:var(--gs-dark)"><?php echo esc_html($qr->title); ?></div>
          <?php if ( (int) ( $qr->visible_to_staff ?? 1 ) === 0 ): ?>
          <span style="font-size:.68rem;font-weight:600;color:#7C3AED;background:#F5F3FF;border:1px solid #DDD6FE;border-radius:999px;padding:1px 8px">🔒 Owner only</span>
          <?php endif; ?>
        </div>
        <div style="font-size:.81rem;color:var(--gs-muted);line-height:1.55"><?php echo esc_html(substr($qr->body,0,130)); ?><?php if(strlen($qr->body)>130): ?>…<?php endif; ?></div>
        <!-- ENTERPRISE-AUDIT FIX (Part 3, Low-Medium): usage-frequency data,
             the first time this feature has ever had any — see
             AjaxController::useQuickReply(), called only when a template is
             actually inserted into an outgoing message. Deliberately
             labeled "used Nx", never "conversion rate" — the platform has
             no way to attribute a lead's eventual outcome back to which
             canned reply text was used in one message of a thread, so a
             conversion-rate figure here would be fabricated. -->
        <div style="font-size:.72rem;color:#94A3B8;margin-top:6px">
          <?php if ( (int) ( $qr->used_count ?? 0 ) > 0 ): ?>
            Used <?php echo (int) $qr->used_count; ?>× · last used <?php echo esc_html( human_time_diff( strtotime( $qr->last_used_at ), current_time( 'timestamp' ) ) ); ?> ago
          <?php else: ?>
            Not used yet
          <?php endif; ?>
        </div>
      </div>
      <div style="display:flex;gap:6px;flex-shrink:0">
        <button onclick="gsQrModal(<?php echo (int)$qr->id; ?>,'<?php echo esc_js($qr->title); ?>','<?php echo esc_js($qr->body); ?>',<?php echo (int)($qr->visible_to_staff??1); ?>)" class="gs-btn gs-btn-ghost gs-btn-xs">✏️ Edit</button>
        <button onclick="if(confirm('Delete quick reply &quot;<?php echo esc_js( $qr->title ); ?>&quot;?'))gsPost('gs_delete_quick_reply',{nonce:'<?php echo esc_js($nonce); ?>',reply_id:<?php echo $qr->id; ?>},function(){gsToast('Deleted','success');this.closest('.gs-card').remove();}.bind(this))" class="gs-btn gs-btn-red gs-btn-xs">🗑</button>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">⚡</div><div class="gs-empty-title">No quick replies yet</div><div>Create pre-written templates to respond faster to common customer enquiries.</div></div>
<?php endif; ?>
<script>
// FIXED — Known Limitations audit: gsQrModal() now optionally takes an
// existing reply's id/title/body to edit it in place (via the same
// gs_save_quick_reply action, now update-aware — see saveQuickReply() in
// AjaxController.php), instead of the only path being delete-and-recreate.
function gsQrModal(replyId,title,body,visibleToStaff){
  var isEdit = !!replyId;
  var vis = (visibleToStaff===undefined||visibleToStaff===null) ? 1 : parseInt(visibleToStaff,10);
  gsModal.show(
    '<div class="gs-fg"><label class="gs-lbl">Title <span class="gs-req">*</span></label><input type="text" id="gs-qr-title" class="gs-inp" placeholder="e.g. Pricing Information, Process Explanation" value="'+(title?title.replace(/"/g,'&quot;'):'')+'"></div>'
    +'<div class="gs-fg"><label class="gs-lbl">Message <span class="gs-req">*</span></label><textarea id="gs-qr-body" class="gs-ta" rows="4" placeholder="The pre-written reply text...">'+(body||'')+'</textarea></div>'
    +'<div class="gs-fg" style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="gs-qr-visible" style="width:auto" '+(vis?'checked':'')+'><label for="gs-qr-visible" class="gs-lbl" style="margin:0">Visible to team members (staff/manager)</label></div>'
    +'<div style="font-size:.76rem;color:#94A3B8;margin-top:-8px">Unchecking this keeps the template owner-only — your team won\'t see or be able to insert it.</div>',
    {title:isEdit?'Edit Quick Reply':'Add Quick Reply',size:'md',footer:'<button class="gs-btn gs-btn-ghost gs-btn-md" onclick="gsModal.hide()">Cancel</button><button class="gs-btn gs-btn-primary gs-btn-md" onclick="gsSubmitQr('+(replyId||0)+')">'+(isEdit?'Save Changes':'Save Reply')+'</button>'}
  );
}
function gsSubmitQr(replyId){
  var title=document.getElementById('gs-qr-title').value.trim();
  var body=document.getElementById('gs-qr-body').value.trim();
  if(!title||!body){gsToast('Title and message are required','error');return;}
  var payload={nonce:'<?php echo esc_js($nonce); ?>',title:title,content:body,visible_to_staff:document.getElementById('gs-qr-visible').checked?1:0};
  if(replyId){ payload.reply_id = replyId; }
  gsPost('gs_save_quick_reply',payload,function(){
    gsModal.hide(); gsToast(replyId?'Quick reply updated!':'Quick reply saved!','success'); setTimeout(function(){location.reload();},800);
  });
}
function gsQrMove(replyId,direction,btn){
  btn.disabled=true;
  gsPost('gs_reorder_quick_reply',{nonce:'<?php echo esc_js($nonce); ?>',reply_id:replyId,direction:direction},
    function(){location.reload();},
    function(m){gsToast(m||'Could not reorder','error');btn.disabled=false;});
}
</script>
<?php echo gs_render_screen_help( 'Quick Replies', [
  
  
], [
  [ 'mistake' => 'Writing a very long quick reply expecting the full text to show in the list view', 'category' => 'unexpected-behavior', 'see' => "Body text over 130 characters is truncated with '…' in the card preview (substr(\$qr->body,0,130)) — this is just a display truncation in the management list, not a stored-length limit.", 'fix' => "Don't worry about the truncated preview here — the full quick reply text is stored and used in full wherever it's inserted into an actual reply (e.g. the Leads/Messages screens); only this management list's preview is shortened.", 'prevent' => "If double-checking the exact saved wording, look at the reply as it's inserted in an actual conversation rather than relying on the truncated preview on this screen." ],
  [ 'mistake' => 'Deleting a quick reply that is actively being used as a canned response elsewhere, expecting existing sent messages to be affected', 'category' => 'workflow', 'see' => 'Deleting a quick reply here only removes it as a future option — it has no effect on messages/replies already sent using that template in the past.', 'fix' => 'Delete freely without concern for historical messages — this only controls what appears as a future quick-reply option, not any conversation history.', 'prevent' => 'No special precaution needed; deletion here is safe with respect to past sent messages by design.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: COMPLAINTS
// ══════════════════════════════════════════════════════════════════════════════
case 'complaints':
  $complaints=$wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$pfx}complaints WHERE complainant_id=%d ORDER BY created_at DESC",$uid
  ));
  // FIXED — Known Limitations audit: the table used to show only status, never the admin's
  // actual response or resolution notes. Pull vendor-visible (non-internal) responses and the
  // complaint's own `resolution` field so both are shown, keyed by complaint_id.
  $cp_responses = [];
  if ( $complaints ) {
    $cp_ids = wp_list_pluck( $complaints, 'id' );
    $cp_placeholders = implode( ',', array_fill( 0, count( $cp_ids ), '%d' ) );
    $cp_rows = $wpdb->get_results( $wpdb->prepare(
      "SELECT * FROM {$pfx}complaint_responses WHERE complaint_id IN ({$cp_placeholders}) AND is_internal=0 ORDER BY created_at ASC",
      $cp_ids
    ) );
    foreach ( $cp_rows as $r ) { $cp_responses[ $r->complaint_id ][] = $r; }
  }
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">⚠️ Complaints</div><div class="gs-ph-sub">Submit and track complaints about platform issues</div></div>
  <button onclick="gsComplaintModal()" class="gs-btn gs-btn-primary">+ File Complaint</button>
</div>
<?php if($complaints): ?>
<div class="gs-tbl-wrap">
  <table class="gs-tbl">
    <thead><tr><th>Subject</th><th>Type</th><th>Priority</th><th>Status</th><th>Response</th><th>Attachment</th><th>Submitted</th></tr></thead>
    <tbody>
    <?php foreach($complaints as $cp):
      $sc=['open'=>'gs-badge-red','in_review'=>'gs-badge-gold','resolved'=>'gs-badge-green','closed'=>'gs-badge-grey'];
      $cp_resp_list = $cp_responses[ $cp->id ] ?? [];
      $cp_has_response = ! empty( $cp_resp_list ) || ! empty( $cp->resolution );
      // ENTERPRISE-AUDIT FIX (Part 3, Low-Medium): the details row (and the
      // new Add-follow-up button in it) previously only rendered when a
      // response already existed — but the whole point of this fix is
      // letting a vendor add evidence BEFORE any admin has replied too, so
      // the row must also be reachable for a still-open, response-less
      // complaint. $cp_open just tracks whether follow-ups are allowed at
      // all (matches addComplaintFollowup()'s own status check server-side).
      $cp_open = ! in_array( $cp->status, [ 'resolved', 'closed', 'dismissed' ], true );
    ?>
    <tr>
      <td style="max-width:240px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600"><?php echo esc_html($cp->subject); ?></td>
      <td><span class="gs-badge gs-badge-grey"><?php echo str_replace('_',' ',ucfirst($cp->type)); ?></span></td>
      <td><span class="gs-badge <?php echo ['critical'=>'gs-badge-red','high'=>'gs-badge-red','medium'=>'gs-badge-gold','low'=>'gs-badge-grey'][$cp->priority]??'gs-badge-grey'; ?>"><?php echo ucfirst($cp->priority); ?></span></td>
      <td><span class="gs-badge <?php echo $sc[$cp->status]??'gs-badge-grey'; ?>"><?php echo ucfirst(str_replace('_',' ',$cp->status)); ?></span></td>
      <td><?php if($cp_has_response||$cp_open): ?><button class="gs-btn gs-btn-ghost gs-btn-xs" onclick="var d=document.getElementById('gs-cp-resp-<?php echo (int)$cp->id; ?>');d.style.display=d.style.display==='none'?'block':'none';"><?php echo $cp_has_response?'💬 View':'💬 View / follow up'; ?></button><?php else: ?><span style="color:#94A3B8;font-size:.78rem">Awaiting response</span><?php endif; ?></td>
      <td><?php if(!empty($cp->attachment_url)): ?><a href="<?php echo esc_url($cp->attachment_url); ?>" target="_blank" class="gs-btn gs-btn-ghost gs-btn-xs">📎 View</a><?php else: ?><span style="color:#94A3B8;font-size:.78rem">—</span><?php endif; ?></td>
      <td style="font-size:.75rem;color:#94A3B8"><?php echo gs_time_ago($cp->created_at); ?></td>
    </tr>
    <?php if($cp_has_response||$cp_open): ?>
    <tr id="gs-cp-resp-<?php echo (int)$cp->id; ?>" style="display:none">
      <td colspan="7" style="background:#F8FAFC;padding:12px 16px">
        <?php if(!$cp_resp_list && !$cp->resolution): ?>
        <div style="font-size:.78rem;color:#94A3B8;margin-bottom:6px">No response yet — you can still add evidence or more information below.</div>
        <?php endif; ?>
        <?php foreach($cp_resp_list as $resp):
          $resp_is_mine = (int) $resp->user_id === (int) $uid;
        ?>
        <div style="font-size:.8rem;color:#1E293B;margin-bottom:8px;padding-bottom:8px;border-bottom:1px solid #E2E8F0">
          <div style="font-size:.7rem;color:#94A3B8;margin-bottom:2px"><?php echo $resp_is_mine ? 'You' : 'Team response'; ?> · <?php echo gs_time_ago($resp->created_at); ?></div>
          <?php echo nl2br(esc_html($resp->message)); ?>
          <?php if(!empty($resp->attachments)): ?>
          <div style="margin-top:4px"><a href="<?php echo esc_url($resp->attachments); ?>" target="_blank" class="gs-btn gs-btn-ghost gs-btn-xs">📎 View attachment</a></div>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <?php if(!empty($cp->resolution)): ?>
        <div style="font-size:.8rem;color:#1E293B">
          <div style="font-size:.7rem;color:#94A3B8;margin-bottom:2px">Resolution<?php echo $cp->resolved_at ? ' · '.gs_time_ago($cp->resolved_at) : ''; ?></div>
          <?php echo nl2br(esc_html($cp->resolution)); ?>
        </div>
        <?php endif; ?>
        <!-- ENTERPRISE-AUDIT FIX (Part 3, Low-Medium): the actual
             evidence-attachment follow-up itself — previously a vendor had
             no way at all to add more information/proof after initial
             filing short of filing an entirely separate complaint. -->
        <?php if ( $cp_open ): ?>
        <button onclick="gsComplaintFollowupModal(<?php echo (int)$cp->id; ?>)" class="gs-btn gs-btn-ghost gs-btn-xs" style="margin-top:4px">➕ Add follow-up / evidence</button>
        <?php endif; ?>
      </td>
    </tr>
    <?php endif; ?>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">✅</div><div class="gs-empty-title">No complaints filed</div></div>
<?php endif; ?>
<script>
function gsComplaintModal(){
  // FIXED — Known Limitations audit: the placeholder used to invite
  // screenshots with no actual upload field anywhere in the modal. Added a
  // real optional attachment upload, reusing the same gsUploadFile() +
  // upload-zone pattern already used for Verification documents.
  gsModal.show(
    '<div class="gs-fg"><label class="gs-lbl">Type <span class="gs-req">*</span></label><select id="gs-cp-type" class="gs-sel"><option value="platform_issue">Platform Issue</option><option value="payment_issue">Payment Issue</option><option value="lead_quality">Lead Quality</option><option value="billing_issue">Billing Issue</option><option value="other">Other</option></select></div>'
    +'<div class="gs-fg"><label class="gs-lbl">Subject <span class="gs-req">*</span></label><input type="text" id="gs-cp-subject" class="gs-inp" placeholder="Brief summary of the issue"></div>'
    +'<div class="gs-fg"><label class="gs-lbl">Description <span class="gs-req">*</span></label><textarea id="gs-cp-desc" class="gs-ta" rows="4" placeholder="Describe the issue in detail including any relevant dates or amounts..."></textarea></div>'
    +'<div class="gs-fg"><label class="gs-lbl">Attach a screenshot (optional)</label><input type="hidden" id="gs-cp-attach-url" value=""><input type="file" id="gs-cp-attach-file" accept="image/*,application/pdf" style="display:none"><div class="gs-upload-zone" id="gs-cp-attach-zone" onclick="document.getElementById(\'gs-cp-attach-file\').click()"><div style="font-size:1.1rem">📎</div><div class="gs-upload-zone-txt">Click to attach a screenshot or document</div><div class="gs-drop-hint">or drag &amp; drop · Image or PDF — max 5MB</div><div id="gs-cp-attach-status" style="font-size:.74rem;color:var(--gs-green);margin-top:5px"></div></div></div>',
    {title:'File a Complaint',size:'md',footer:'<button class="gs-btn gs-btn-ghost gs-btn-md" onclick="gsModal.hide()">Cancel</button><button class="gs-btn gs-btn-primary gs-btn-md" onclick="gsSubmitComplaint()">Submit</button>'}
  );
  document.getElementById('gs-cp-attach-file').addEventListener('change',function(){
    if(!this.files[0]) return;
    var status=document.getElementById('gs-cp-attach-status');
    status.textContent='Uploading…';
    gsUploadFile(this.files[0],null,function(d){
      document.getElementById('gs-cp-attach-url').value=d.url;
      status.textContent='✅ Attachment ready';
    });
  });
}
function gsSubmitComplaint(){
  var sub=document.getElementById('gs-cp-subject').value.trim();
  var desc=document.getElementById('gs-cp-desc').value.trim();
  var attachUrl=document.getElementById('gs-cp-attach-url').value;
  if(!sub||!desc){gsToast('Subject and description are required','error');return;}
  gsPost('gs_submit_complaint',{nonce:'<?php echo esc_js($nonce); ?>',type:document.getElementById('gs-cp-type').value,subject:sub,description:desc,attachment_url:attachUrl},function(){
    gsModal.hide(); gsToast('Complaint submitted! Our team will review within 24 hours.','success'); setTimeout(function(){location.reload();},1000);
  });
}
// ── ENTERPRISE-AUDIT FIX (Part 3, Low-Medium): evidence-attachment
// follow-up beyond initial filing — reuses the exact same gsUploadFile()
// upload-zone pattern as gsComplaintModal() above, just posting to the new
// gs_add_complaint_followup endpoint against an existing complaint_id
// instead of creating a new complaint.
function gsComplaintFollowupModal(complaintId){
  gsModal.show(
    '<div class="gs-fg"><label class="gs-lbl">Message (optional if attaching a file)</label><textarea id="gs-cpf-msg" class="gs-ta" rows="3" placeholder="Add more information, or explain what you're attaching..."></textarea></div>'
    +'<div class="gs-fg"><label class="gs-lbl">Attach evidence (optional)</label><input type="hidden" id="gs-cpf-attach-url" value=""><input type="file" id="gs-cpf-attach-file" accept="image/*,application/pdf" style="display:none"><div class="gs-upload-zone" id="gs-cpf-attach-zone" onclick="document.getElementById(\'gs-cpf-attach-file\').click()"><div style="font-size:1.1rem">📎</div><div class="gs-upload-zone-txt">Click to attach a screenshot or document</div><div class="gs-drop-hint">or drag &amp; drop · Image or PDF — max 5MB</div><div id="gs-cpf-attach-status" style="font-size:.74rem;color:var(--gs-green);margin-top:5px"></div></div></div>',
    {title:'Add Follow-up / Evidence',size:'md',footer:'<button class="gs-btn gs-btn-ghost gs-btn-md" onclick="gsModal.hide()">Cancel</button><button class="gs-btn gs-btn-primary gs-btn-md" onclick="gsSubmitComplaintFollowup('+complaintId+')">Submit</button>'}
  );
  document.getElementById('gs-cpf-attach-file').addEventListener('change',function(){
    if(!this.files[0]) return;
    var status=document.getElementById('gs-cpf-attach-status');
    status.textContent='Uploading…';
    gsUploadFile(this.files[0],null,function(d){
      document.getElementById('gs-cpf-attach-url').value=d.url;
      status.textContent='✅ Attachment ready';
    });
  });
}
function gsSubmitComplaintFollowup(complaintId){
  var msg=document.getElementById('gs-cpf-msg').value.trim();
  var attachUrl=document.getElementById('gs-cpf-attach-url').value;
  if(!msg&&!attachUrl){gsToast('Add a message or an attachment','error');return;}
  gsPost('gs_add_complaint_followup',{nonce:'<?php echo esc_js($nonce); ?>',complaint_id:complaintId,message:msg,attachment_url:attachUrl},function(){
    gsModal.hide(); gsToast('Follow-up added!','success'); setTimeout(function(){location.reload();},800);
  });
}
</script>
<?php echo gs_render_screen_help( 'Complaints', [
  
  
], [
  [ 'mistake' => "Assuming complaint priority is something the vendor sets when filing", 'category' => 'incorrect-settings', 'see' => "The filing form has no Priority field at all (only Type, Subject, Description) — yet the list table displays a Priority badge (critical/high/medium/low) for each complaint, which must be set by an admin after submission rather than by the vendor.", 'fix' => "Don't expect to control urgency at filing time — if a complaint is genuinely urgent, say so explicitly in the Description text, since priority is assigned by the review team, not selected by the vendor.", 'prevent' => "Mention time-sensitivity directly in the complaint description rather than assuming a 'high priority' option exists to select." ],
  [ 'mistake' => 'Filing a brand-new complaint just to add a follow-up detail or an extra screenshot to one already filed', 'category' => 'workflow', 'see' => "Each submission still creates a separate complaint row with no deduplication — but an open complaint (any status other than Resolved/Closed/Dismissed) now has its own '➕ Add follow-up / evidence' button (click '💬 View' / '💬 View / follow up' on its row) for exactly this.", 'fix' => "Use the Add follow-up button on the existing complaint instead of filing a new one — it posts a message and/or attachment onto the same case the review team is already looking at.", 'prevent' => "Check the existing complaints list for a similar still-open entry and add your follow-up there before filing a new one for the same issue." ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: PAGE BUILDER
// ══════════════════════════════════════════════════════════════════════════════
case 'page-builder':
  // Real removal — explicit request: the Page Builder was NOT the actual
  // listing editor (confirmed by this section's own original developer
  // note: "The real Vendor Listing builder is create-listing.php") and
  // its presence misled vendors into thinking they were editing their
  // listing. Every vendor-side entry point has been removed; this case
  // remains only as a redirect so old bookmarks and stale links land
  // vendors on their real listings section instead of a broken page.
  wp_safe_redirect( home_url( '/vendor/dashboard/?section=listings' ) );
  exit;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: RESPONSE TEMPLATES (Part 7)
// ══════════════════════════════════════════════════════════════════════════════
case 'templates':
  $templates = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT * FROM {$pfx}reply_templates WHERE vendor_id=%d OR vendor_id=0 ORDER BY vendor_id DESC, use_count DESC", $vid
  ) ) : [];
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">📝 Response Templates</div><div class="gs-ph-sub">Save reusable replies — insert with one click while replying to inquiries</div></div>
  <button class="gs-btn gs-btn-primary" onclick="gsTplNew()">+ New Template</button>
</div>

<!-- New / Edit Modal -->
<div id="gs-tpl-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;display:none;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:14px;padding:24px;width:min(520px,95vw);max-height:90vh;overflow-y:auto">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
      <div style="font-weight:700;font-size:1rem;color:#1E3A5F" id="gs-tpl-modal-title">New Template</div>
      <button onclick="gsTplCloseModal()" style="background:none;border:none;font-size:1.2rem;cursor:pointer;color:#94A3B8">✕</button>
    </div>
    <input type="hidden" id="gs-tpl-edit-id" value="">
    <div class="gs-fg">
      <label class="gs-lbl">Template name <span class="gs-req">*</span></label>
      <input id="gs-tpl-name" class="gs-inp" placeholder="e.g. Professional greeting, Plumbing availability">
    </div>
    <div class="gs-fg">
      <label class="gs-lbl">Category (optional — leave blank to show for all inquiries)</label>
      <select id="gs-tpl-cat" class="gs-sel">
        <option value="">All categories</option>
        <?php foreach($cats as $cat): $cat_slug = sanitize_title($cat->name); ?>
        <option value="<?php echo esc_attr($cat_slug); ?>" data-name="<?php echo esc_attr($cat->name); ?>"><?php echo esc_html($cat->icon_emoji.' '.$cat->name); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="gs-fg">
      <label class="gs-lbl">Template body <span class="gs-req">*</span></label>
      <textarea id="gs-tpl-body" class="gs-ta" rows="6" placeholder="Thank you for your inquiry, {{client_name}}. I can help with {{service}}..."></textarea>
      <div class="gs-hint">Available tokens: <code>{{client_name}}</code> <code>{{service}}</code> <code>{{vendor_name}}</code> <code>{{date}}</code></div>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:6px">
      <button class="gs-btn gs-btn-ghost" onclick="gsTplCloseModal()">Cancel</button>
      <button class="gs-btn gs-btn-primary" onclick="gsTplSave()" id="gs-tpl-save-btn">Save Template</button>
    </div>
  </div>
</div>

<?php if($templates): ?>
<?php
  // Build a resolve-by-slug-or-name lookup so the badge always shows the CURRENT category
  // label even if a row's category_slug was stored as a legacy display name, or the
  // category itself was later renamed.
  $gs_tpl_cat_lookup = [];
  foreach ($cats as $c) { $gs_tpl_cat_lookup[ sanitize_title($c->name) ] = $c->name; $gs_tpl_cat_lookup[ strtolower($c->name) ] = $c->name; }
?>
<div class="gs-card">
  <div style="display:flex;flex-direction:column;gap:10px">
    <?php foreach($templates as $t): ?>
    <div style="display:flex;align-items:flex-start;gap:12px;padding:12px 14px;background:<?php echo $t->vendor_id==0?'#F8FAFC':'#fff'; ?>;border:1px solid #E2E8F0;border-radius:9px">
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
          <div style="font-weight:700;font-size:.88rem;color:#1E293B"><?php echo esc_html($t->name); ?></div>
          <?php if($t->vendor_id==0): ?><span style="font-size:.68rem;padding:2px 7px;background:#EFF6FF;color:#2563EB;border-radius:10px;font-weight:700">Platform</span><?php endif; ?>
          <?php if($t->category_slug): $gs_tpl_cat_label = $gs_tpl_cat_lookup[ strtolower($t->category_slug) ] ?? $t->category_slug; ?><span style="font-size:.68rem;padding:2px 7px;background:#F0FDF4;color:#059669;border-radius:10px"><?php echo esc_html($gs_tpl_cat_label); ?></span><?php endif; ?>
          <?php if($t->use_count > 0): ?><span style="font-size:.68rem;color:#94A3B8"><?php echo $t->use_count; ?>× used</span><?php endif; ?>
        </div>
        <div style="font-size:.79rem;color:#64748B;line-height:1.5;white-space:pre-wrap;max-height:3.6em;overflow:hidden"><?php echo esc_html(substr($t->body,0,180)); ?><?php echo strlen($t->body)>180?'…':''; ?></div>
      </div>
      <?php if($t->vendor_id != 0): ?>
      <div style="display:flex;gap:6px;flex-shrink:0">
        <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsTplEdit(<?php echo esc_js(json_encode($t)); ?>)">✏ Edit</button>
        <button class="gs-btn gs-btn-sm" style="background:#FEF2F2;color:#DC2626;border-color:#FECACA" onclick="gsTplDelete(<?php echo $t->id; ?>,'<?php echo esc_js($t->name); ?>')">✕</button>
      </div>
      <?php else: ?>
      <div style="display:flex;gap:6px;flex-shrink:0">
        <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsTplDuplicate(<?php echo esc_js(json_encode($t)); ?>)">⧉ Duplicate &amp; Edit</button>
      </div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">📝</div><div class="gs-empty-title">No templates yet</div><div>Create reusable reply templates to respond to common inquiries faster.</div></div>
<?php endif; ?>
<script>
function gsTplNew(){document.getElementById('gs-tpl-modal-title').textContent='New Template';document.getElementById('gs-tpl-edit-id').value='';document.getElementById('gs-tpl-name').value='';document.getElementById('gs-tpl-body').value='';document.getElementById('gs-tpl-cat').value='';document.getElementById('gs-tpl-modal').style.display='flex';}
function gsTplEdit(t){
  document.getElementById('gs-tpl-modal-title').textContent='Edit Template';
  document.getElementById('gs-tpl-edit-id').value=t.id;
  document.getElementById('gs-tpl-name').value=t.name;
  document.getElementById('gs-tpl-body').value=t.body;
  // FIX (enterprise hardening pass): category_slug may be stored in either the current
  // stable-slug format (going forward) or the legacy display-name format (rows saved
  // before this fix). Try an exact value match first, then fall back to matching the
  // option's data-name (case-insensitive) so legacy rows still pre-select correctly
  // instead of silently resetting to "All categories".
  var sel=document.getElementById('gs-tpl-cat'), stored=t.category_slug||'', matched=false;
  for(var i=0;i<sel.options.length;i++){
    var opt=sel.options[i];
    if(opt.value===stored || (stored && opt.getAttribute('data-name') && opt.getAttribute('data-name').toLowerCase()===stored.toLowerCase())){
      sel.selectedIndex=i; matched=true; break;
    }
  }
  if(!matched) sel.value='';
  document.getElementById('gs-tpl-modal').style.display='flex';
}
function gsTplCloseModal(){document.getElementById('gs-tpl-modal').style.display='none';}
function gsTplDuplicate(t){
  // FIXED — Known Limitations audit: platform templates (vendor_id=0) used to be read-only
  // with no way to start from one — a vendor wanting to tweak the wording had to manually
  // copy the visible (and truncated-in-the-list) text into a brand-new blank template. This
  // pre-fills the New Template modal from the FULL template object (not the truncated list
  // preview) and clears the edit-id so Save creates the vendor's own independent copy.
  document.getElementById('gs-tpl-modal-title').textContent='New Template (from "'+t.name+'")';
  document.getElementById('gs-tpl-edit-id').value='';
  document.getElementById('gs-tpl-name').value=t.name+' (Copy)';
  document.getElementById('gs-tpl-body').value=t.body;
  var sel=document.getElementById('gs-tpl-cat'), stored=t.category_slug||'';
  for(var i=0;i<sel.options.length;i++){
    var opt=sel.options[i];
    if(opt.value===stored || (stored && opt.getAttribute('data-name') && opt.getAttribute('data-name').toLowerCase()===stored.toLowerCase())){ sel.selectedIndex=i; break; }
  }
  document.getElementById('gs-tpl-modal').style.display='flex';
}
function gsTplSave(){
  var id=document.getElementById('gs-tpl-edit-id').value;
  var name=document.getElementById('gs-tpl-name').value.trim();
  var body=document.getElementById('gs-tpl-body').value.trim();
  var cat=document.getElementById('gs-tpl-cat').value;
  if(!name||!body){gsToast('Name and body are required','error');return;}
  var btn=document.getElementById('gs-tpl-save-btn');btn.disabled=true;btn.textContent='Saving…';
  var action=id?'gs_update_reply_template':'gs_create_reply_template';
  var data={nonce:'<?php echo esc_js($nonce); ?>',name:name,body:body,category_slug:cat};
  if(id)data.template_id=id;
  gsPost(action,data,function(){gsToast('Template saved!','success');location.reload();},function(m){gsToast(m||'Failed','error');btn.disabled=false;btn.textContent='Save Template';});
}
function gsTplDelete(id,name){
  if(!confirm('Delete template "'+name+'"?'))return;
  gsPost('gs_delete_reply_template',{nonce:'<?php echo esc_js($nonce); ?>',template_id:id},function(){gsToast('Deleted','info');location.reload();},function(m){gsToast(m||'Failed','error');});
}
</script>
<?php echo gs_render_screen_help( 'Response Templates', [
  
], [
  [ 'mistake' => "Assuming template tokens like {{client_name}} and {{service}} work anywhere text is typed, not just inside a saved template body", 'category' => 'incorrect-behavior', 'see' => "The hint text lists {{client_name}}, {{service}}, {{vendor_name}}, {{date}} as 'Available tokens' specifically for the Template body field — typing these tokens directly into a live reply on the Leads/Messages screen (outside of an inserted template) will not substitute anything.", 'fix' => 'Only rely on token substitution when using a saved template inserted via the "insert with one click" flow mentioned in this screen\'s subtitle — tokens typed manually elsewhere are not processed.', 'prevent' => 'Create and save a template with the desired tokens here first, then insert it from the reply screen, rather than typing tokens directly into a live conversation.' ],
  [ 'mistake' => "Renaming or deleting a category after templates were already tagged with it", 'category' => 'workflow', 'see' => "Category values are now saved as a stable slug (sanitize_title of the category name) rather than the display name, and the badge/edit-dropdown resolve that slug back to the CURRENT category name — so a rename updates correctly everywhere. A deleted category, however, will show the old slug as a plain-text badge with no matching dropdown option.", 'fix' => 'Re-assign affected templates to a different category (or "All categories") before deleting a category that templates reference.', 'prevent' => 'Check whether any templates use a category before deleting it, or simply leave unused categories in place rather than deleting them.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: INQUIRY & BOOKING MODULES (Phase 1)
// ══════════════════════════════════════════════════════════════════════════════
case 'inquiry_modules':
  $im_listings = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT id, title, inquiry_modules_data FROM {$pfx}listings WHERE vendor_id=%d AND status IN('active','pending','draft') ORDER BY created_at DESC", $vid
  ) ) : [];
  $im_selected_id = (int) ( $_GET['listing_id'] ?? ( $im_listings[0]->id ?? 0 ) );
  $im_listing = null;
  foreach ( $im_listings as $iml ) { if ( (int)$iml->id === $im_selected_id ) { $im_listing = $iml; break; } }
  $im_cfg = $im_listing ? ( json_decode( (string)( $im_listing->inquiry_modules_data ?? '' ), true ) ?: [] ) : [];
  $im_all_cats = \GoodService\Service\InquiryFormService::get_selectable();
  // Group categories by their 'group' label for a manageable accordion UI
  $im_groups = [];
  foreach ( $im_all_cats as $im_slug => $im_cat ) {
    $im_groups[ $im_cat['group'] ?? 'Other' ][ $im_slug ] = $im_cat;
  }
  $im_limit  = max( 1, (int) ( $vp->inq_cat_limit ?? 3 ) );
  $im_locked = ! empty( $vp->inq_cat_locked );
  $im_booking_module_on = \GoodService\Module\ModuleManager::is_enabled( 'booking' );

  // ── Subscription plan gate ─────────────────────────────────────────────────
  // Fetch allow_inquiry_module and allow_booking_module from the vendor's
  // active/trialing subscription plan. If neither is set (free / no plan),
  // show an upgrade prompt instead of the module editor.
  $_im_plan = $vid ? $wpdb->get_row( $wpdb->prepare(
      "SELECT sp.allow_inquiry_module, sp.allow_booking_module, sp.name AS plan_name
       FROM {$pfx}subscriptions sub
       LEFT JOIN {$pfx}subscription_plans sp ON sp.id=sub.plan_id
       WHERE sub.vendor_id=%d AND sub.status IN('active','trialing')
       ORDER BY sub.id DESC LIMIT 1",
      $vid
  ) ) : null;
  $im_plan_allows_inquiry = $_im_plan && !empty( $_im_plan->allow_inquiry_module );
  $im_plan_allows_booking = $_im_plan && !empty( $_im_plan->allow_booking_module );
  $im_current_plan_name   = $_im_plan->plan_name ?? null;
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">📝 Inquiry &amp; Booking Modules</div><div class="gs-ph-sub">Choose which services accept inquiries, and which can be booked with a date &amp; time</div></div>
</div>

<?php if ( ! $im_plan_allows_inquiry && ! \GoodService\Core\Roles::is_admin_level() ): ?>
<!-- ── UPGRADE PROMPT — shown when allow_inquiry_module=0 ─── -->
<div style="background:linear-gradient(135deg,#1E3A5F 0%,#2563EB 100%);border-radius:16px;padding:40px 32px;text-align:center;color:#fff;margin-bottom:24px">
  <div style="font-size:2.5rem;margin-bottom:12px">🔒</div>
  <h2 style="font-size:1.3rem;font-weight:800;margin:0 0 10px">Inquiry Modules are a Paid Feature</h2>
  <p style="font-size:.88rem;color:rgba(255,255,255,.8);margin:0 0 20px;max-width:460px;margin-left:auto;margin-right:auto">
    <?php if ( $im_current_plan_name ): ?>
      Your current plan <strong><?php echo esc_html($im_current_plan_name); ?></strong> does not include Inquiry Modules.
    <?php else: ?>
      You are on the <strong>Free Plan</strong>. Inquiry Modules are not available on the free tier.
    <?php endif; ?>
    Upgrade to receive inquiries, quotes, and booking requests directly through your listing page.
  </p>
  <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-bottom:20px">
    <div style="background:rgba(255,255,255,.15);border-radius:10px;padding:12px 20px;font-size:.82rem">
      <div style="font-size:1.2rem;margin-bottom:4px">📋</div>
      <div style="font-weight:700">Inquiry Forms</div>
      <div style="color:rgba(255,255,255,.7);font-size:.75rem">Receive job enquiries</div>
    </div>
    <div style="background:rgba(255,255,255,.15);border-radius:10px;padding:12px 20px;font-size:.82rem">
      <div style="font-size:1.2rem;margin-bottom:4px">💬</div>
      <div style="font-weight:700">Quote Requests</div>
      <div style="color:rgba(255,255,255,.7);font-size:.75rem">Custom quote forms</div>
    </div>
    <div style="background:rgba(255,255,255,.15);border-radius:10px;padding:12px 20px;font-size:.82rem">
      <div style="font-size:1.2rem;margin-bottom:4px">📅</div>
      <div style="font-weight:700">Booking System</div>
      <div style="color:rgba(255,255,255,.7);font-size:.75rem">Date &amp; time bookings</div>
    </div>
  </div>
  <a href="?section=subscription" style="display:inline-block;background:#fff;color:#1E3A5F;font-weight:800;font-size:.9rem;padding:12px 32px;border-radius:10px;text-decoration:none;transition:transform .15s" onmouseover="this.style.transform='scale(1.04)'" onmouseout="this.style.transform=''">
    🚀 View Upgrade Plans
  </a>
</div>

<!-- Show current modules as read-only preview (greyed out) -->
<?php if ( ! empty( $im_listings ) ): ?>
<div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;padding:20px;opacity:.5;pointer-events:none;user-select:none">
  <div style="font-size:.82rem;font-weight:700;color:#64748B;margin-bottom:12px;text-transform:uppercase;letter-spacing:.05em">Preview (locked — upgrade to activate)</div>
  <div style="font-size:.8rem;color:#94A3B8">Configure up to <?php echo (int)$im_limit; ?> inquiry categories once you upgrade. Your listing currently has <?php
    $im_preview_count = 0;
    if ( $im_listings[0]->inquiry_modules_data ) {
        $im_prev = json_decode($im_listings[0]->inquiry_modules_data, true) ?: [];
        $im_preview_count = count(array_filter($im_prev, fn($m) => !empty($m['enabled'])));
    }
    echo (int)$im_preview_count;
  ?> module(s) saved (will activate after upgrade).</div>
</div>
<?php endif; ?>

<?php elseif ( ! $im_listings ): ?>
<div class="gs-empty"><div class="gs-empty-icon">🏢</div><div class="gs-empty-title">No listings yet</div><div>Create a listing first, then configure its inquiry &amp; booking modules here.</div></div>
<?php else: ?>

<div class="gs-card" style="margin-bottom:16px">
  <label class="gs-lbl">Listing</label>
  <select id="gs-im-listing-sel" class="gs-sel" onchange="window.location.href='?section=inquiry_modules&listing_id='+this.value">
    <?php foreach ( $im_listings as $iml ): ?>
    <option value="<?php echo (int)$iml->id; ?>" <?php echo (int)$iml->id===$im_selected_id?'selected':''; ?>><?php echo esc_html($iml->title); ?></option>
    <?php endforeach; ?>
  </select>
</div>

<?php if ( ! $im_booking_module_on ): ?>
<div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:10px;padding:12px 16px;margin-bottom:14px;font-size:.82rem;color:#92400E">
  ℹ️ Direct booking (date &amp; time) is currently disabled platform-wide. You can still mark services as bookable below — the "Book Now" option will appear automatically once an admin enables the Booking module.
</div>
<?php elseif ( ! $im_plan_allows_booking && ! \GoodService\Core\Roles::is_admin_level() ): ?>
<div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:10px;padding:12px 16px;margin-bottom:14px;font-size:.82rem;color:#1E40AF">
  📅 <strong>Booking is not included in your current plan.</strong>
  You can configure inquiry modules below. To accept date &amp; time bookings,
  <a href="?section=subscription" style="color:#2563EB;font-weight:700">upgrade your plan →</a>
</div>
<?php endif; ?>

<?php if ( $im_locked && ! \GoodService\Core\Roles::is_admin_level() ): ?>
<div style="background:#FEF2F2;border:1px solid #FECACA;border-radius:10px;padding:12px 16px;margin-bottom:14px;font-size:.82rem;color:#991B1B">
  🔒 Your inquiry module selection has been finalized by the admin. Contact support to request changes.
</div>
<?php else: ?>
<div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:10px;padding:12px 16px;margin-bottom:14px;font-size:.82rem;color:#1E40AF">
  ℹ️ You can enable up to <strong><?php echo (int)$im_limit; ?></strong> inquiry module<?php echo $im_limit===1?'':'s'; ?> on your plan. <span id="gs-im-count-label">0 / <?php echo (int)$im_limit; ?> enabled</span>
</div>
<?php endif; ?>

<div id="gs-im-groups">
<?php foreach ( $im_groups as $im_group_name => $im_cats ): ?>
  <div class="gs-card" style="margin-bottom:12px">
    <div class="gs-card-title"><?php echo esc_html($im_group_name); ?></div>
    <?php foreach ( $im_cats as $im_slug => $im_cat ):
      $im_existing = $im_cfg[ $im_slug ] ?? [];
      $im_enabled  = ! empty( $im_existing['enabled'] );
      $im_cta      = $im_existing['cta'] ?? '';
      $im_intro    = $im_existing['intro'] ?? '';
      $im_accepts_booking = ! empty( $im_existing['accepts_booking'] );
      $im_booking_cta     = $im_existing['booking_cta'] ?? '';
      $im_hide_inquiry    = ! empty( $im_existing['hide_inquiry_cta'] );
      $im_wa_mode         = $im_existing['whatsapp_verify_mode'] ?? 'inherit';
      $im_default_cta     = $im_cat['ctas'][0] ?? 'Submit Inquiry';
      $im_default_book_cta= $im_cat['ctas'][1] ?? 'Book Now';
    ?>
    <div class="gs-im-row" data-slug="<?php echo esc_attr($im_slug); ?>" style="border:1px solid var(--gs-border);border-radius:9px;padding:12px 14px;margin-bottom:8px">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
        <label style="display:flex;align-items:center;gap:8px;font-weight:700;font-size:.87rem;cursor:pointer;flex:1">
          <input type="checkbox" class="gs-im-enabled" <?php echo $im_enabled?'checked':''; ?> style="width:16px;height:16px;accent-color:var(--gs-primary)"
                 onchange="gsImToggle('<?php echo esc_js($im_slug); ?>',this.checked)">
          <?php echo $im_cat['icon'] ?? ''; ?> <?php echo esc_html($im_cat['name'] ?? $im_slug); ?>
        </label>
        <span class="gs-im-toggle-detail" data-slug="<?php echo esc_attr($im_slug); ?>" style="display:<?php echo $im_enabled?'block':'none'; ?>">
          <button type="button" class="gs-btn gs-btn-ghost gs-btn-xs" onclick="gsImExpand('<?php echo esc_js($im_slug); ?>')">⚙ Configure</button>
        </span>
      </div>
      <div class="gs-im-detail" id="gs-im-detail-<?php echo esc_attr($im_slug); ?>" style="display:none;margin-top:12px;padding-top:12px;border-top:1px solid #F1F5F9">
        <div class="gs-fg">
          <label class="gs-lbl">Inquiry button label</label>
          <input type="text" class="gs-inp gs-im-cta" value="<?php echo esc_attr($im_cta); ?>" placeholder="<?php echo esc_attr($im_default_cta); ?>">
        </div>
        <div class="gs-fg">
          <label class="gs-lbl">Intro text (shown above the form)</label>
          <textarea class="gs-ta gs-im-intro" rows="2" placeholder="e.g. Tell us about your event and we'll get back with a custom quote."><?php echo esc_textarea($im_intro); ?></textarea>
        </div>
        <div style="background:#F8FAFC;border-radius:8px;padding:12px;margin-top:10px">
          <label style="display:flex;align-items:center;gap:8px;font-weight:700;font-size:.84rem;cursor:pointer;margin-bottom:8px">
            <input type="checkbox" class="gs-im-accepts-booking" <?php echo $im_accepts_booking?'checked':''; ?> style="width:16px;height:16px;accent-color:var(--gs-primary)"
                   onchange="gsImToggleBooking('<?php echo esc_js($im_slug); ?>',this.checked)">
            📅 Allow customers to book a date &amp; time for this service
          </label>
          <div class="gs-im-booking-fields" id="gs-im-booking-<?php echo esc_attr($im_slug); ?>" style="display:<?php echo $im_accepts_booking?'block':'none'; ?>;padding-left:24px">
            <div class="gs-fg">
              <label class="gs-lbl">Booking button label</label>
              <input type="text" class="gs-inp gs-im-booking-cta" value="<?php echo esc_attr($im_booking_cta); ?>" placeholder="<?php echo esc_attr($im_default_book_cta); ?>">
            </div>
            <label style="display:flex;align-items:center;gap:8px;font-size:.82rem;cursor:pointer;color:#475569">
              <input type="checkbox" class="gs-im-hide-inquiry" <?php echo $im_hide_inquiry?'checked':''; ?> style="width:14px;height:14px;accent-color:var(--gs-primary)">
              Booking-only — hide the "Send Inquiry" button for this service
            </label>
            <div style="font-size:.74rem;color:#94A3B8;margin-top:6px">
              Set your weekly availability and blocked dates in the <a href="?section=availability&listing_id=<?php echo (int)$im_selected_id; ?>" style="color:var(--gs-primary);font-weight:600">Availability</a> tab for this listing so customers see real open slots.
            </div>
          </div>
        </div>
        <div style="background:#F0FDF4;border-radius:8px;padding:12px;margin-top:10px">
          <label class="gs-lbl" style="margin-bottom:6px">💬 WhatsApp Verification for this service</label>
          <select class="gs-inp gs-im-wa-mode" style="max-width:280px">
            <option value="inherit" <?php echo $im_wa_mode==='inherit'?'selected':''; ?>>Use my account default</option>
            <option value="on"      <?php echo $im_wa_mode==='on'?'selected':''; ?>>Always ask for WhatsApp verification</option>
            <option value="off"     <?php echo $im_wa_mode==='off'?'selected':''; ?>>Never (email verification only)</option>
          </select>
          <div style="font-size:.74rem;color:#64748B;margin-top:4px">Email verification always applies. This adds an optional extra WhatsApp code step for this specific service category, if your account or the platform has WhatsApp verification turned on.</div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
<?php endforeach; ?>
</div>

<div style="position:sticky;bottom:0;background:#fff;border-top:1px solid var(--gs-border);padding:14px 0;margin-top:8px;display:flex;justify-content:flex-end;gap:10px">
  <button class="gs-btn gs-btn-primary" id="gs-im-save-btn" onclick="gsImSave(<?php echo (int)$im_selected_id; ?>)">💾 Save Settings</button>
</div>

<script>
(function(){
  var LIMIT = <?php echo (int)$im_limit; ?>;
  function countEnabled(){
    return document.querySelectorAll('.gs-im-enabled:checked').length;
  }
  function updateCountLabel(){
    var lbl = document.getElementById('gs-im-count-label');
    var n = countEnabled();
    if(lbl){
      lbl.textContent = n+' / '+LIMIT+' enabled';
      lbl.style.color = n>=LIMIT ? '#DC2626' : '';
    }
    // FIXED — Known Limitations audit: proactively disable any unchecked box once the
    // plan limit is reached, instead of only blocking at Save time after the vendor has
    // already configured CTA/intro/booking settings for more categories than allowed.
    var atLimit = n >= LIMIT;
    document.querySelectorAll('.gs-im-enabled').forEach(function(cb){
      if(!cb.checked){ cb.disabled = atLimit; cb.title = atLimit ? ('Plan limit reached ('+LIMIT+') — uncheck another category first') : ''; }
      else { cb.disabled = false; cb.title = ''; }
    });
  }
  window.gsImToggle = function(slug, checked){
    var detail = document.querySelector('.gs-im-toggle-detail[data-slug="'+slug+'"]');
    if(detail) detail.style.display = checked ? 'block' : 'none';
    if(!checked){
      var d = document.getElementById('gs-im-detail-'+slug);
      if(d) d.style.display='none';
    }
    updateCountLabel();
  };
  window.gsImExpand = function(slug){
    var d = document.getElementById('gs-im-detail-'+slug);
    if(!d) return;
    d.style.display = d.style.display==='none' ? 'block' : 'none';
  };
  window.gsImToggleBooking = function(slug, checked){
    var f = document.getElementById('gs-im-booking-'+slug);
    if(f) f.style.display = checked ? 'block' : 'none';
  };
  updateCountLabel();

  window.gsImSave = function(listingId){
    var modules = {};
    document.querySelectorAll('.gs-im-row').forEach(function(row){
      var slug = row.dataset.slug;
      var enabled = row.querySelector('.gs-im-enabled').checked;
      var cta = row.querySelector('.gs-im-cta')?.value || '';
      var intro = row.querySelector('.gs-im-intro')?.value || '';
      var acceptsBooking = row.querySelector('.gs-im-accepts-booking')?.checked || false;
      var bookingCta = row.querySelector('.gs-im-booking-cta')?.value || '';
      var hideInquiry = row.querySelector('.gs-im-hide-inquiry')?.checked || false;
      var waMode = row.querySelector('.gs-im-wa-mode')?.value || 'inherit';
      modules[slug] = {
        enabled: enabled,
        cta: cta,
        intro: intro,
        accepts_booking: acceptsBooking,
        booking_cta: bookingCta,
        hide_inquiry_cta: hideInquiry,
        whatsapp_verify_mode: waMode
      };
    });
    var enabledCount = countEnabled();
    if (enabledCount > LIMIT) {
      gsToast('You can enable at most '+LIMIT+' module(s) on your current plan. Please disable some first.','error');
      return;
    }
    var btn = document.getElementById('gs-im-save-btn');
    btn.disabled = true; btn.textContent = 'Saving…';
    gsPost('gs_save_inquiry_modules', {
      nonce: '<?php echo esc_js($nonce); ?>',
      listing_id: listingId,
      inquiry_modules_data: JSON.stringify(modules)
    }, function(){
      btn.disabled = false; btn.textContent = '💾 Save Settings';
      gsToast('Saved! Changes are live on your listing.','success');
    }, function(m){
      btn.disabled = false; btn.textContent = '💾 Save Settings';
      gsToast(m || 'Failed to save','error');
    });
  };
})();
</script>
<?php echo gs_render_screen_help( 'Inquiry & Booking Modules', [
  
  
], [
  [ 'mistake' => "Assuming direct booking (date & time) is available just because a service's 'Accepts Booking' checkbox is visible and checkable", 'category' => 'permission', 'see' => "The 'Accepts Booking' toggle and its detail panel render regardless of \$im_booking_module_on or \$im_plan_allows_booking — those two only control whether an informational banner is shown above the category list, not whether the booking checkbox itself is disabled.", 'fix' => "Check for the amber 'Direct booking is currently disabled platform-wide' or blue 'Booking is not included in your current plan' banner near the top of this screen before assuming a checked 'Accepts Booking' box will actually produce a working Book Now button on the live listing.", 'prevent' => "Confirm both the platform-wide Booking module (set by admin) and your own plan's booking allowance are active before relying on per-category booking configuration to take visible effect." ],
  [ 'mistake' => "Switching to a different listing in the dropdown without saving changes made to the currently selected listing first", 'category' => 'workflow', 'see' => "The Listing dropdown's onchange handler navigates immediately via window.location.href='?section=inquiry_modules&listing_id='+this.value — a full page reload discards any unsaved checkbox/text changes with no confirmation prompt.", 'fix' => 'Click "💾 Save Settings" for the current listing before switching to a different one in the dropdown.', 'prevent' => 'Treat each listing\'s module configuration as a separate, must-save-before-leaving form — the dropdown does not warn about unsaved changes.' ],
] ); ?>
<?php endif; ?>
<?php break;

case 'availability':
  $days_map = [0=>'Sunday',1=>'Monday',2=>'Tuesday',3=>'Wednesday',4=>'Thursday',5=>'Friday',6=>'Saturday'];
  // Phase: Availability is now listing-scoped (each listing has its own
  // independent weekly schedule and blocked dates), matching the same
  // listing-selector pattern as the Inquiry & Booking Modules section.
  $av_listings = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT id, title, inquiry_modules_data FROM {$pfx}listings WHERE vendor_id=%d AND status IN('active','pending','draft') ORDER BY created_at DESC", $vid
  ) ) : [];
  $av_selected_id = (int) ( $_GET['listing_id'] ?? ( $av_listings[0]->id ?? 0 ) );
  $av_selected_listing = null;
  foreach ( $av_listings as $avl ) { if ( (int)$avl->id === $av_selected_id ) { $av_selected_listing = $avl; break; } }
  $av_accepts_booking = false;
  if ( $av_selected_listing ) {
    $av_im_cfg = json_decode( (string)( $av_selected_listing->inquiry_modules_data ?? '' ), true ) ?: [];
    foreach ( $av_im_cfg as $av_im_mod ) { if ( ! empty( $av_im_mod['accepts_booking'] ) ) { $av_accepts_booking = true; break; } }
  }

  $avail_rows = $av_selected_id ? $wpdb->get_results($wpdb->prepare("SELECT * FROM {$pfx}availability WHERE listing_id=%d ORDER BY day_of_week ASC",$av_selected_id)) : [];
  $avail_by_day = [];
  foreach($avail_rows as $ar) $avail_by_day[$ar->day_of_week] = $ar;
  $blocked = $av_selected_id ? $wpdb->get_results($wpdb->prepare("SELECT * FROM {$pfx}blocked_dates WHERE listing_id=%d AND blocked_date >= CURDATE() ORDER BY blocked_date ASC",$av_selected_id)) : [];
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">🗓 Availability</div><div class="gs-ph-sub">Set the weekly schedule and blocked dates for this listing</div></div>
</div>

<?php if ( ! $av_listings ): ?>
<div class="gs-empty"><div class="gs-empty-icon">🏢</div><div class="gs-empty-title">No listings yet</div><div>Create a listing first, then set its availability here.</div></div>
<?php else: ?>

<div class="gs-card" style="margin-bottom:16px">
  <label class="gs-lbl">Listing</label>
  <select id="gs-avail-listing-sel" class="gs-sel" onchange="window.location.href='?section=availability&listing_id='+this.value">
    <?php foreach ( $av_listings as $avl ): ?>
    <option value="<?php echo (int)$avl->id; ?>" <?php echo (int)$avl->id===$av_selected_id?'selected':''; ?>><?php echo esc_html($avl->title); ?></option>
    <?php endforeach; ?>
  </select>
  <div style="font-size:.78rem;color:#94A3B8;margin-top:8px">
    Each listing has its own schedule. If you have multiple services (e.g. "AC Repair" and "Plumbing"), set availability separately for each.
  </div>
  <?php if ( count( $av_listings ) > 1 ): ?>
  <!-- FIXED — Known Limitations audit: there used to be no way to reuse one listing's schedule
       on another; a vendor with several listings sharing the same hours had to re-enter the
       identical weekly schedule by hand for each one. -->
  <div style="display:flex;align-items:center;gap:8px;margin-top:10px;padding-top:10px;border-top:1px solid #F1F5F9">
    <label class="gs-lbl" style="margin:0;white-space:nowrap">Copy schedule from</label>
    <select id="gs-avail-copy-src" class="gs-sel" style="max-width:220px">
      <option value="">Select a listing…</option>
      <?php foreach ( $av_listings as $avl ): if ( (int) $avl->id === $av_selected_id ) continue; ?>
      <option value="<?php echo (int) $avl->id; ?>"><?php echo esc_html( $avl->title ); ?></option>
      <?php endforeach; ?>
    </select>
    <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsAvailCopySchedule(<?php echo (int) $av_selected_id; ?>)">⧉ Copy Here</button>
  </div>
  <?php endif; ?>
</div>

<?php if ( ! $av_accepts_booking ): ?>
<div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:10px;padding:12px 16px;margin-bottom:14px;font-size:.82rem;color:#92400E">
  ℹ️ This listing doesn't have any category marked as bookable yet, so customers won't see a "Book Now" option even with a schedule set here. Enable it in <a href="?section=inquiry_modules&listing_id=<?php echo (int)$av_selected_id; ?>" style="color:#92400E;font-weight:700;text-decoration:underline">Inquiry &amp; Booking Modules</a>.
</div>
<?php endif; ?>

<div class="gs-ph" style="margin-bottom:0">
  <div></div>
  <button class="gs-btn gs-btn-primary" id="gs-avail-save-btn" onclick="gsAvailSave(<?php echo (int)$av_selected_id; ?>)">💾 Save Schedule</button>
</div>


<div class="gs-card" style="margin-bottom:16px">
  <div class="gs-card-title">Weekly Schedule</div>
  <div id="gs-avail-grid" style="display:flex;flex-direction:column;gap:10px">
    <?php for($d=1;$d<=7;$d++): $dow=($d%7); $ar=$avail_by_day[$dow]??null; $active=$ar?$ar->is_active:($dow>0&&$dow<6?1:0); ?>
    <div style="display:grid;grid-template-columns:auto 90px auto auto auto auto;align-items:center;gap:10px;padding:10px 14px;background:<?php echo $active?'#fff':'#F8FAFC'; ?>;border:1px solid #E2E8F0;border-radius:9px" id="avail-row-<?php echo $dow; ?>">
      <label style="display:flex;align-items:center;gap:8px;font-weight:600;font-size:.85rem;cursor:pointer;min-width:105px">
        <input type="checkbox" id="avail-active-<?php echo $dow; ?>" <?php echo $active?'checked':''; ?> onchange="gsAvailToggleDay(<?php echo $dow; ?>)" style="width:16px;height:16px;accent-color:var(--gs-primary)">
        <?php echo $days_map[$dow]; ?>
      </label>
      <span style="font-size:.74rem;color:#94A3B8" id="avail-status-<?php echo $dow; ?>"><?php echo $active?'Open':'Closed'; ?></span>
      <div class="avail-time-controls" id="avail-times-<?php echo $dow; ?>" style="display:<?php echo $active?'contents':'none'; ?>">
        <div style="display:flex;align-items:center;gap:6px">
          <span style="font-size:.75rem;color:#64748B">From</span>
          <input type="time" id="avail-start-<?php echo $dow; ?>" class="gs-inp" style="width:105px" value="<?php echo esc_attr($ar?$ar->start_time:'09:00'); ?>">
        </div>
        <div style="display:flex;align-items:center;gap:6px">
          <span style="font-size:.75rem;color:#64748B">To</span>
          <input type="time" id="avail-end-<?php echo $dow; ?>" class="gs-inp" style="width:105px" value="<?php echo esc_attr($ar?$ar->end_time:'18:00'); ?>">
        </div>
        <div style="display:flex;align-items:center;gap:6px">
          <span style="font-size:.75rem;color:#64748B">Slot</span>
          <select id="avail-slot-<?php echo $dow; ?>" class="gs-sel" style="width:auto">
            <?php foreach([30=>'30 min',60=>'1 hour',90=>'1.5 hrs',120=>'2 hours'] as $v=>$l): ?>
            <option value="<?php echo $v; ?>" <?php echo ($ar&&$ar->slot_duration_minutes==$v)?'selected':''; ?>><?php echo $l; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div style="display:flex;align-items:center;gap:6px">
          <span style="font-size:.75rem;color:#64748B">Buffer</span>
          <select id="avail-buf-<?php echo $dow; ?>" class="gs-sel" style="width:auto">
            <?php foreach([0=>'None',15=>'15 min',30=>'30 min',45=>'45 min',60=>'1 hour'] as $v=>$l): ?>
            <option value="<?php echo $v; ?>" <?php echo ($ar&&$ar->buffer_minutes==$v)?'selected':''; ?>><?php echo $l; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <?php if(!$active): ?>
      <div id="avail-closed-<?php echo $dow; ?>" style="grid-column:3/-1;font-size:.78rem;color:#94A3B8">Closed all day</div>
      <?php endif; ?>
    </div>
    <?php endfor; ?>
  </div>
</div>

<div class="gs-card">
  <div class="gs-card-title" style="display:flex;justify-content:space-between;align-items:center">
    Blocked Dates
    <button class="gs-btn gs-btn-sm gs-btn-ghost" onclick="document.getElementById('gs-block-form').style.display=document.getElementById('gs-block-form').style.display==='none'?'grid':'none'">+ Block a date</button>
  </div>
  <div id="gs-block-form" style="display:none;margin-bottom:14px;padding:14px;background:#F8FAFC;border-radius:8px">
    <div style="display:flex;gap:10px;margin-bottom:8px">
      <div style="font-size:.74rem;font-weight:700;color:#64748B;cursor:pointer;padding:4px 10px;border-radius:6px;background:#fff;border:1px solid #E2E8F0" onclick="gsBlockMode('single')" id="gs-bm-single">Single date</div>
      <div style="font-size:.74rem;font-weight:700;color:#64748B;cursor:pointer;padding:4px 10px;border-radius:6px" onclick="gsBlockMode('range')" id="gs-bm-range">Date range</div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr auto;gap:10px;align-items:end">
      <div><label class="gs-lbl">From</label><input type="date" id="gs-block-date" class="gs-inp" min="<?php echo date('Y-m-d'); ?>"></div>
      <div id="gs-block-to-wrap" style="display:none"><label class="gs-lbl">To</label><input type="date" id="gs-block-date-to" class="gs-inp" min="<?php echo date('Y-m-d'); ?>"></div>
      <div><label class="gs-lbl">Reason</label><input type="text" id="gs-block-reason" class="gs-inp" placeholder="Holiday, vacation..."></div>
    </div>
    <button class="gs-btn gs-btn-primary" style="margin-top:8px" onclick="gsBlockSave(<?php echo (int)$av_selected_id; ?>)">Block Date(s)</button>
  </div>
<script>
function gsBlockMode(m){
  var isRange = m==='range';
  document.getElementById('gs-block-to-wrap').style.display=isRange?'block':'none';
  document.getElementById('gs-bm-single').style.background=isRange?'':'#fff';
  document.getElementById('gs-bm-single').style.border=isRange?'none':'1px solid #E2E8F0';
  document.getElementById('gs-bm-range').style.background=isRange?'#fff':'';
  document.getElementById('gs-bm-range').style.border=isRange?'1px solid #E2E8F0':'none';
}
var _gsBlockIsRange = false;
document.querySelector && document.querySelectorAll('#gs-bm-single,#gs-bm-range').forEach(function(el){
  el.addEventListener('click',function(){_gsBlockIsRange=el.id==='gs-bm-range';});
});
</script>
  <?php if($blocked): ?>
  <div style="display:flex;flex-direction:column;gap:8px" id="gs-blocked-list">
    <?php foreach($blocked as $bl): ?>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:9px 12px;background:#FEF2F2;border:1px solid #FECACA;border-radius:7px">
      <div>
        <div style="font-weight:600;font-size:.84rem;color:#991B1B"><?php echo date('D, d M Y',strtotime($bl->blocked_date)); ?></div>
        <?php if($bl->reason): ?><div style="font-size:.74rem;color:#B91C1C"><?php echo esc_html($bl->reason); ?></div><?php endif; ?>
      </div>
      <button class="gs-btn gs-btn-sm" style="background:#FEF2F2;color:#DC2626;border-color:#FECACA" onclick="gsUnblockDate(<?php echo $bl->id; ?>,'<?php echo esc_js(date('D, d M Y',strtotime($bl->blocked_date))); ?>')">Remove</button>
    </div>
    <?php endforeach; ?>
  </div>
  <?php else: ?>
  <div style="text-align:center;padding:24px;color:#94A3B8;font-size:.85rem">No blocked dates. You're available every working day.</div>
  <?php endif; ?>
</div>
<script>
function gsAvailToggleDay(dow){
  var cb=document.getElementById('avail-active-'+dow);
  var active=cb.checked;
  document.getElementById('avail-status-'+dow).textContent=active?'Open':'Closed';
  var tc=document.getElementById('avail-times-'+dow);
  var cl=document.getElementById('avail-closed-'+dow);
  if(tc){tc.style.display=active?'contents':'none';}
  if(cl)cl.style.display=active?'none':'';
  document.getElementById('avail-row-'+dow).style.background=active?'#fff':'#F8FAFC';
}
function gsAvailSave(listingId){
  // FIXED — Known Limitations audit: saving a schedule used to be silently allowed even when
  // the listing has no bookable category, with only a small banner mentioning it — a vendor
  // could easily miss the banner and spend time configuring a schedule that has no visible
  // effect. Now blocks with an explicit confirmation naming the actual consequence, rather
  // than fully disabling Save (which would also block vendors intentionally preparing a
  // schedule ahead of enabling the bookable category afterward).
  <?php if ( ! $av_accepts_booking ): ?>
  if (!confirm('This listing has no category marked as bookable, so this schedule will NOT be visible to customers yet (no "Book Now" option will appear). Save anyway, to have it ready once you enable a bookable category in Inquiry & Booking Modules?')) { return; }
  <?php endif; ?>
  var rows=[];
  for(var d=0;d<7;d++){
    var active=document.getElementById('avail-active-'+d);
    if(!active)continue;
    rows.push({
      day_of_week:d,
      is_active:active.checked?1:0,
      start_time:document.getElementById('avail-start-'+d)?.value||'09:00',
      end_time:document.getElementById('avail-end-'+d)?.value||'18:00',
      slot_duration_minutes:parseInt(document.getElementById('avail-slot-'+d)?.value||60),
      buffer_minutes:parseInt(document.getElementById('avail-buf-'+d)?.value||0)
    });
  }
  var btn=document.getElementById('gs-avail-save-btn');btn.disabled=true;btn.textContent='Saving…';
  gsPost('gs_save_availability',{nonce:'<?php echo esc_js($nonce); ?>',listing_id:listingId,rows:JSON.stringify(rows)},
    function(){gsToast('Availability saved!','success');btn.disabled=false;btn.textContent='💾 Save Schedule';},
    function(m){gsToast(m||'Failed','error');btn.disabled=false;btn.textContent='💾 Save Schedule';});
}
function gsAvailCopySchedule(targetListingId){
  var src=document.getElementById('gs-avail-copy-src').value;
  if(!src){gsToast('Select a listing to copy from','error');return;}
  if(!confirm('This will replace the current weekly schedule for this listing with the selected listing\'s schedule. Continue?'))return;
  gsPost('gs_copy_availability_schedule',{nonce:'<?php echo esc_js($nonce); ?>',listing_id:targetListingId,source_listing_id:src},
    function(d){gsToast(d.message||'Schedule copied!','success');setTimeout(function(){location.reload();},800);},
    function(m){gsToast(m||'Could not copy schedule','error');});
}
function gsBlockSave(listingId){
  var date=document.getElementById('gs-block-date').value;
  var dateTo=document.getElementById('gs-block-date-to')?.value||'';
  var reason=document.getElementById('gs-block-reason').value;
  if(!date){gsToast('Select a date','error');return;}
  if(dateTo&&dateTo<date){gsToast('End date must be after start date','error');return;}
  var data={nonce:'<?php echo esc_js($nonce); ?>',listing_id:listingId,blocked_date:date,reason:reason};
  if(dateTo)data.date_to=dateTo;
  gsPost('gs_save_blocked_date',data,function(){gsToast('Date(s) blocked','success');location.reload();},function(m){gsToast(m||'Failed','error');});
}
function gsUnblockDate(id,dateLabel){
  if(!confirm('Remove the block for '+(dateLabel||'this date')+'?'))return;
  gsPost('gs_delete_blocked_date',{nonce:'<?php echo esc_js($nonce); ?>',listing_id:<?php echo (int)$av_selected_id; ?>,block_id:id},
    function(){gsToast('Unblocked','info');location.reload();},
    function(m){gsToast(m||'Failed','error');});
}
</script>
<?php echo gs_render_screen_help( 'Availability', [
  
  
], [
  [ 'mistake' => "Unchecking a day's checkbox to mark it closed, without realizing the time/slot/buffer fields for that day are hidden, not cleared", 'category' => 'unexpected-behavior', 'see' => "gsAvailToggleDay() only toggles the display of .avail-time-controls via CSS (display:none/contents) — the underlying start/end time, slot duration, and buffer <select>/<input> values remain in the DOM unchanged, just hidden.", 'fix' => 'Trust that unchecking a day and saving correctly marks it inactive (is_active:0 is sent regardless of the hidden field values) — there is no need to manually clear the hidden time fields before saving a closed day.', 'prevent' => "No action needed; is_active is what actually controls whether the day is open, independent of whatever values remain in the now-hidden time fields." ],
  [ 'mistake' => "Blocking a date range where the end date is before the start date", 'category' => 'validation', 'see' => "gsBlockSave() explicitly checks if(dateTo && dateTo<date){gsToast('End date must be after start date','error');return;} — submitting an inverted range shows this error and does not save.", 'fix' => 'Ensure the "to" date (if used for a multi-day block) is on or after the "from" date before submitting.', 'prevent' => 'For a single blocked day, leave the end date field empty entirely rather than setting it equal to or before the start date.' ],
] ); ?>
<?php endif; ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: BOOKING CALENDAR VIEW (Part 9.4)
// ══════════════════════════════════════════════════════════════════════════════
case 'calendar':
  $cal_month = (int)($_GET['month']??date('n'));
  $cal_year  = (int)($_GET['year']??date('Y'));
  if($cal_month<1){$cal_month=12;$cal_year--;} if($cal_month>12){$cal_month=1;$cal_year++;}
  // Listing filter — same pattern as Bookings/inbox. Validated against the
  // vendor's own listings before use.
  $cal_listings = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT id, title FROM {$pfx}listings WHERE vendor_id=%d ORDER BY title ASC", $vid
  ) ) : [];
  $cal_filter_listing_id = (int) ( $_GET['listing_id'] ?? 0 );
  $cal_filter_valid = false;
  foreach ( $cal_listings as $cl ) { if ( (int)$cl->id === $cal_filter_listing_id ) { $cal_filter_valid = true; break; } }
  if ( ! $cal_filter_valid ) { $cal_filter_listing_id = 0; }
  // Query string suffix to preserve the filter across Prev/Today/Next links
  $cal_qs = $cal_filter_listing_id ? '&listing_id=' . $cal_filter_listing_id : '';

  if ( $cal_filter_listing_id ) {
    $cal_bookings = $wpdb->get_results($wpdb->prepare(
      "SELECT b.*,li.title as lt,b.booking_date as bdate FROM {$pfx}bookings b
       LEFT JOIN {$pfx}listings li ON li.id=b.listing_id
       WHERE b.vendor_id=%d AND b.listing_id=%d AND MONTH(b.booking_date)=%d AND YEAR(b.booking_date)=%d
       ORDER BY b.booking_date ASC",$vid,$cal_filter_listing_id,$cal_month,$cal_year));
  } else {
    $cal_bookings = $vid ? $wpdb->get_results($wpdb->prepare(
      "SELECT b.*,li.title as lt,b.booking_date as bdate FROM {$pfx}bookings b
       LEFT JOIN {$pfx}listings li ON li.id=b.listing_id
       WHERE b.vendor_id=%d AND MONTH(b.booking_date)=%d AND YEAR(b.booking_date)=%d
       ORDER BY b.booking_date ASC",$vid,$cal_month,$cal_year)) : [];
  }
  $by_date = [];
  foreach($cal_bookings as $bk) $by_date[date('j',strtotime($bk->bdate))][] = $bk;
  $first_dow = (int)date('w',mktime(0,0,0,$cal_month,1,$cal_year));
  $days_in_month = (int)date('t',mktime(0,0,0,$cal_month,1,$cal_year));
  $prev_m = $cal_month-1; $prev_y=$cal_year; if($prev_m<1){$prev_m=12;$prev_y--;}
  $next_m = $cal_month+1; $next_y=$cal_year; if($next_m>12){$next_m=1;$next_y++;}
?>
<div class="gs-ph">
  <div>
    <div class="gs-ph-title">📅 Calendar — <?php echo date('F Y',mktime(0,0,0,$cal_month,1,$cal_year)); ?></div>
    <div class="gs-ph-sub"><?php echo count($cal_bookings); ?> booking<?php echo count($cal_bookings)!=1?'s':''; ?> this month</div>
  </div>
  <div style="display:flex;gap:8px">
    <a href="?section=calendar&month=<?php echo $prev_m; ?>&year=<?php echo $prev_y; ?><?php echo $cal_qs; ?>" class="gs-btn gs-btn-ghost">← Prev</a>
    <a href="?section=calendar&month=<?php echo date('n'); ?>&year=<?php echo date('Y'); ?><?php echo $cal_qs; ?>" class="gs-btn gs-btn-ghost">Today</a>
    <a href="?section=calendar&month=<?php echo $next_m; ?>&year=<?php echo $next_y; ?><?php echo $cal_qs; ?>" class="gs-btn gs-btn-ghost">Next →</a>
  </div>
</div>
<?php if ( count( $cal_listings ) > 1 ): ?>
<div class="gs-card" style="margin-bottom:14px">
  <label class="gs-lbl">Listing</label>
  <select class="gs-sel" onchange="window.location.href='?section=calendar&month=<?php echo $cal_month; ?>&year=<?php echo $cal_year; ?>'+(this.value?'&listing_id='+this.value:'')">
    <option value="">All listings</option>
    <?php foreach ( $cal_listings as $cl ): ?>
    <option value="<?php echo (int)$cl->id; ?>" <?php echo (int)$cl->id===$cal_filter_listing_id?'selected':''; ?>><?php echo esc_html($cl->title); ?></option>
    <?php endforeach; ?>
  </select>
</div>
<?php endif; ?>
<div class="gs-card">
  <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:0;border:1px solid #E2E8F0;border-radius:10px;overflow:hidden">
    <?php foreach(['Sun','Mon','Tue','Wed','Thu','Fri','Sat'] as $dn): ?>
    <div style="padding:8px 4px;text-align:center;font-size:.7rem;font-weight:700;color:#64748B;background:#F8FAFC;border-bottom:1px solid #E2E8F0"><?php echo $dn; ?></div>
    <?php endforeach; ?>
    <?php for($i=0;$i<$first_dow;$i++): ?><div style="min-height:70px;background:#F8FAFC;border:0.5px solid #F1F5F9"></div><?php endfor; ?>
    <?php for($day=1;$day<=$days_in_month;$day++):
      $is_today=($day==date('j')&&$cal_month==date('n')&&$cal_year==date('Y'));
      $day_bookings=$by_date[$day]??[];
    ?>
    <div style="min-height:70px;padding:5px;border:0.5px solid #F1F5F9;background:<?php echo $is_today?'#EFF6FF':'#fff'; ?>;vertical-align:top">
      <div style="font-size:.78rem;font-weight:<?php echo $is_today?700:400; ?>;color:<?php echo $is_today?'#2563EB':'#374151'; ?>;margin-bottom:3px"><?php echo $day; ?></div>
      <?php foreach(array_slice($day_bookings,0,2) as $bk):
        // FIXED — Known Limitations audit: chips used to reflect only the coarse booking.status
        // and never the finer job_status (travelling/arrived/in_progress) tracked on the
        // Bookings screen, so a job actively in progress today still looked like plain
        // "Confirmed" here. Show a 🚗 indicator on today's chips only, when job_status is a
        // real in-progress value distinct from the base status — avoids implying live tracking
        // on past/future days where job_status is meaningless.
        $bk_job_status = $bk->job_status ?? $bk->status ?? 'confirmed';
        $bk_in_progress = $is_today && in_array( $bk_job_status, [ 'travelling', 'arrived', 'in_progress' ], true );
      ?>
      <div style="font-size:.65rem;background:#DBEAFE;color:#1E40AF;border-radius:3px;padding:2px 4px;margin-bottom:2px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;cursor:pointer"
     title="<?php echo esc_attr($bk->customer_name.' — '.$bk->lt.($bk_in_progress?' — '.ucfirst(str_replace('_',' ',$bk_job_status)).' (see Bookings for live status)':'')); ?>"
     onclick="gsCalShowDetail(<?php echo esc_js(json_encode(['id'=>$bk->id,'customer'=>$bk->customer_name,'service'=>$bk->lt??'','phone'=>$bk->customer_phone??'','date'=>date('D, d M',strtotime($bk->bdate)),'status'=>$bk->status??'confirmed','job_status'=>$bk_in_progress?$bk_job_status:null,'amount'=>$bk->amount??0])); ?>)"
     ><?php echo $bk_in_progress?'🚗 ':''; ?><?php echo esc_html(substr($bk->customer_name,0,12)); ?></div>
      <?php endforeach; ?>
      <?php if(count($day_bookings)>2): ?><div style="font-size:.62rem;color:#2563EB;cursor:pointer;text-decoration:underline" onclick="gsCalShowDay(<?php echo esc_js(json_encode(array_map(function($b) use ($is_today){$js=$b->job_status??$b->status??'confirmed';$ip=$is_today&&in_array($js,['travelling','arrived','in_progress'],true);return ['id'=>$b->id,'customer'=>$b->customer_name,'service'=>$b->lt??'','phone'=>$b->customer_phone??'','date'=>date('D, d M',strtotime($b->bdate)),'status'=>$b->status??'confirmed','job_status'=>$ip?$js:null,'amount'=>$b->amount??0];},$day_bookings))); ?>,'<?php echo esc_js(date('D, d M',mktime(0,0,0,$cal_month,$day,$cal_year))); ?>')">+<?php echo count($day_bookings)-2; ?> more</div><?php endif; ?>
    </div>
    <?php endfor; ?>
  </div>
</div>

<!-- Booking detail overlay (Part 9.4) -->
<div id="gs-cal-detail-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:14px;padding:24px;width:min(380px,95vw)">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <div style="font-weight:800;font-size:.98rem;color:#1E293B">Booking Details</div>
      <button onclick="document.getElementById('gs-cal-detail-modal').style.display='none'" style="background:none;border:none;font-size:1.2rem;cursor:pointer;color:#94A3B8" aria-label="Close">✕</button>
    </div>
    <div id="gs-cal-detail-body"></div>
    <div id="gs-cal-detail-actions" style="margin-top:16px;display:flex;gap:8px"></div>
  </div>
</div>
<!-- FIXED — Known Limitations audit: the "+N more" label used to be plain, dead text with no way
     to see the remaining bookings for that day. This day-summary overlay lists every booking for
     the clicked day (not just the first 2 shown in the grid), each row reusing gsCalShowDetail(). -->
<div id="gs-cal-day-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:14px;padding:24px;width:min(380px,95vw);max-height:80vh;overflow-y:auto">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <div style="font-weight:800;font-size:.98rem;color:#1E293B" id="gs-cal-day-title">Bookings</div>
      <button onclick="document.getElementById('gs-cal-day-modal').style.display='none'" style="background:none;border:none;font-size:1.2rem;cursor:pointer;color:#94A3B8" aria-label="Close">✕</button>
    </div>
    <div id="gs-cal-day-body" style="display:flex;flex-direction:column;gap:8px"></div>
  </div>
</div>
<script>
function gsCalShowDay(bookings, dateLabel) {
  var sc = {pending:'#D97706',confirmed:'#059669',cancelled:'#DC2626',completed:'#2563EB'};
  document.getElementById('gs-cal-day-title').textContent = dateLabel + ' — ' + bookings.length + ' booking' + (bookings.length!==1?'s':'');
  var body = document.getElementById('gs-cal-day-body');
  body.innerHTML = bookings.map(function(bk){
    var color = sc[bk.status] || '#64748B';
    var label = bk.job_status ? ('🚗 ' + gsiqEsc(bk.job_status.charAt(0).toUpperCase()+bk.job_status.slice(1).replace('_',' '))) : gsiqEsc((bk.status||'').charAt(0).toUpperCase()+(bk.status||'').slice(1));
    return '<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 10px;background:#F8FAFC;border-radius:8px;cursor:pointer" onclick=\'gsCalShowDetail(' + JSON.stringify(bk).replace(/'/g,"&#39;") + ')\'>'
      + '<div><div style="font-size:.83rem;font-weight:600;color:#1E293B">' + gsiqEsc(bk.customer||'') + '</div><div style="font-size:.74rem;color:#94A3B8">' + gsiqEsc(bk.service||'') + '</div></div>'
      + '<span style="font-size:.68rem;font-weight:700;color:' + (bk.job_status?'#2563EB':color) + '">' + label + '</span>'
      + '</div>';
  }).join('');
  document.getElementById('gs-cal-day-modal').style.display = 'flex';
}
function gsCalShowDetail(bk) {
  var dayModal = document.getElementById('gs-cal-day-modal');
  if (dayModal) dayModal.style.display = 'none';
  var body = document.getElementById('gs-cal-detail-body');
  var sc = {pending:'#D97706',confirmed:'#059669',cancelled:'#DC2626',completed:'#2563EB'};
  body.innerHTML = [
    '<div style="display:flex;flex-direction:column;gap:10px">',
    '<div style="display:flex;justify-content:space-between"><span style="font-size:.78rem;color:#94A3B8">Customer</span><strong style="font-size:.85rem">'+gsiqEsc(bk.customer||'')+'</strong></div>',
    '<div style="display:flex;justify-content:space-between"><span style="font-size:.78rem;color:#94A3B8">Service</span><span style="font-size:.85rem">'+gsiqEsc(bk.service||'')+'</span></div>',
    '<div style="display:flex;justify-content:space-between"><span style="font-size:.78rem;color:#94A3B8">Date</span><strong style="font-size:.85rem">'+gsiqEsc(bk.date||'')+'</strong></div>',
    bk.amount>0?'<div style="display:flex;justify-content:space-between"><span style="font-size:.78rem;color:#94A3B8">Amount</span><strong style="font-size:.85rem">₹'+Number(bk.amount).toLocaleString('en-IN')+'</strong></div>':'',
    '<div style="display:flex;justify-content:space-between"><span style="font-size:.78rem;color:#94A3B8">Status</span><span style="font-size:.8rem;font-weight:700;color:'+(sc[bk.status]||'#64748B')+'">'+bk.status.charAt(0).toUpperCase()+bk.status.slice(1)+'</span></div>',
    bk.job_status?('<div style="display:flex;justify-content:space-between"><span style="font-size:.78rem;color:#94A3B8">Live Job Status</span><span style="font-size:.8rem;font-weight:700;color:#2563EB">🚗 '+gsiqEsc(bk.job_status.charAt(0).toUpperCase()+bk.job_status.slice(1).replace('_',' '))+'</span></div>'):'',
    '</div>'
  ].join('');
  var actions = document.getElementById('gs-cal-detail-actions');
  actions.innerHTML = (bk.phone?'<a href="tel:'+gsiqEsc(bk.phone)+'" class="gs-btn gs-btn-ghost gs-btn-sm">📞 Call</a>':'')
    + (bk.job_status?'<a href="?section=bookings" class="gs-btn gs-btn-ghost gs-btn-sm">🚗 View live status in Bookings</a>':'')
    + '<button onclick="document.getElementById(\'gs-cal-detail-modal\').style.display=\'none\'" class="gs-btn gs-btn-ghost gs-btn-sm">Close</button>';
  document.getElementById('gs-cal-detail-modal').style.display='flex';
}
function gsiqEsc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
</script>

<?php if($cal_bookings): ?>
<div class="gs-card">
  <div class="gs-card-title">Bookings This Month</div>
  <?php foreach($cal_bookings as $bk): ?>
  <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid #F1F5F9">
    <div style="width:44px;height:44px;border-radius:9px;background:#EFF6FF;display:flex;align-items:center;justify-content:center;font-weight:700;color:#2563EB;font-size:.9rem;flex-shrink:0"><?php echo date('d',strtotime($bk->bdate)); ?></div>
    <div style="flex:1">
      <div style="font-weight:600;font-size:.88rem"><?php echo esc_html($bk->customer_name); ?></div>
      <div style="font-size:.74rem;color:#64748B"><?php echo esc_html($bk->lt??'—'); ?> · <?php echo date('h:i A',strtotime($bk->bdate)); ?></div>
    </div>
    <div>
      <?php $sc=['pending'=>'#D97706','confirmed'=>'#059669','cancelled'=>'#DC2626','completed'=>'#2563EB']; ?>
      <span style="font-size:.72rem;font-weight:700;color:<?php echo $sc[$bk->status]??'#64748B'; ?>"><?php echo ucfirst($bk->status); ?></span>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">📅</div><div class="gs-empty-title">No bookings this month</div><div>Confirmed bookings from clients appear on this calendar.</div></div>
<?php endif; ?>
<?php echo gs_render_screen_help( 'Calendar', [
  
  
], [
  [ 'mistake' => "Using the Prev/Next month navigation and expecting the active listing filter to reset", 'category' => 'workflow', 'see' => "\$cal_qs (the listing_id filter) is appended to every Prev/Today/Next link, so a listing filter set on one month automatically carries over when navigating to another month — this is intentional, not a bug, but can be surprising if forgotten.", 'fix' => 'If bookings seem to be missing after navigating months, check whether a specific listing is still selected in the dropdown and switch back to "All listings" if a full view is needed.', 'prevent' => 'Note the currently selected listing in the dropdown before navigating between months, since the filter persists across Prev/Today/Next.' ],
  [ 'mistake' => "Expecting the booking detail popup's Call button to work on a desktop without a phone/softphone app configured", 'category' => 'unexpected-behavior', 'see' => "The '📞 Call' button in the detail modal is a plain tel: link — on a desktop browser with no calling application registered for tel: links, clicking it does nothing or shows a browser 'no app found' prompt.", 'fix' => 'Use a mobile device, or a desktop with a softphone/calling app registered as the tel: handler, to place calls directly from this button — otherwise copy the phone number shown and dial manually.', 'prevent' => 'On desktop, treat the Call button as a convenience for devices with calling capability rather than a guaranteed one-click dial action.' ],
] ); ?>
<?php break;



// ══════════════════════════════════════════════════════════════════════════════
// SECTION: SERVICE PLANS — Recurring subscriptions (Part 16)
// ══════════════════════════════════════════════════════════════════════════════
case 'service_plans':
  // Real fix — confirmed limitation: added next-scheduled-visit and a real
  // auto-generated-inquiry count per plan, closing the "no visibility into
  // whether the automation actually ran" gap. next_visit is the soonest
  // next_service_date across this plan's active subscribers (the exact
  // field Cron::trigger_subscription_inquiries() reads/advances); auto_leads
  // counts leads.service_plan_id, the new FK set on every auto-generated
  // lead (see src/Core/Cron.php and src/Database/Schema.php).
  $svc_plans = $vid ? $wpdb->get_results($wpdb->prepare(
    "SELECT sp.*,
            (SELECT COUNT(*) FROM {$pfx}service_subscriptions ss WHERE ss.plan_id=sp.id AND ss.status='active') AS active_subs,
            (SELECT MIN(ss.next_service_date) FROM {$pfx}service_subscriptions ss WHERE ss.plan_id=sp.id AND ss.status='active') AS next_visit,
            (SELECT COUNT(*) FROM {$pfx}leads l WHERE l.service_plan_id=sp.id) AS auto_leads
     FROM {$pfx}service_plans sp WHERE sp.vendor_id=%d ORDER BY sp.created_at DESC", $vid
  )) : [];
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">🔄 Recurring Service Plans</div><div class="gs-ph-sub">Offer subscription plans to clients — they book once, you service regularly</div></div>
  <button class="gs-btn gs-btn-primary" onclick="gsSvcPlanNew()">+ New Plan</button>
</div>

<div class="gs-card" style="background:linear-gradient(135deg,#EFF6FF,#DBEAFE);border-color:#BFDBFE;margin-bottom:16px">
  <div style="display:flex;align-items:flex-start;gap:12px">
    <div style="font-size:1.6rem">💡</div>
    <div>
      <div style="font-weight:700;font-size:.9rem;color:#1E3A8A;margin-bottom:4px">How Service Plans Work</div>
      <div style="font-size:.82rem;color:#1E40AF;line-height:1.6">Create plans like "Monthly Pest Control" or "Quarterly AC Service". Clients subscribe once and get auto-scheduled visits. The system creates an inquiry automatically on each service date.</div>
    </div>
  </div>
</div>

<!-- New/Edit Plan Modal -->
<div id="gs-svc-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:14px;padding:24px;width:min(500px,95vw);max-height:90vh;overflow-y:auto">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
      <div style="font-weight:700;font-size:1rem;color:#1E3A5F" id="gs-svc-modal-title">New Service Plan</div>
      <button onclick="document.getElementById('gs-svc-modal').style.display='none'" style="background:none;border:none;font-size:1.2rem;cursor:pointer;color:#94A3B8">✕</button>
    </div>
    <input type="hidden" id="gs-svc-plan-id" value="">
    <div class="gs-fg"><label class="gs-lbl">Plan name <span class="gs-req">*</span></label><input id="gs-svc-name" class="gs-inp" placeholder="e.g. Monthly Pest Control, Annual AC Checkup"></div>
    <div class="gs-fg"><label class="gs-lbl">Description</label><textarea id="gs-svc-desc" class="gs-ta" rows="2" placeholder="What's included in each visit?"></textarea></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="gs-fg"><label class="gs-lbl">Price (₹) <span class="gs-req">*</span></label><input id="gs-svc-price" type="number" class="gs-inp" placeholder="999"></div>
      <div class="gs-fg"><label class="gs-lbl">Frequency <span class="gs-req">*</span></label>
        <select id="gs-svc-freq" class="gs-sel">
          <option value="monthly">Monthly</option>
          <option value="quarterly">Quarterly (3 months)</option>
          <option value="biannual">Every 6 months</option>
          <option value="annual">Annual</option>
          <option value="weekly">Weekly</option>
        </select>
      </div>
    </div>
    <div class="gs-fg"><label class="gs-lbl">Visits included per cycle</label><input id="gs-svc-visits" type="number" class="gs-inp" value="1" min="1" max="52"></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:6px">
      <button class="gs-btn gs-btn-ghost" onclick="document.getElementById('gs-svc-modal').style.display='none'">Cancel</button>
      <button class="gs-btn gs-btn-primary" onclick="gsSvcPlanSave()">Save Plan</button>
    </div>
  </div>
</div>

<?php if($svc_plans): ?>
<div style="display:flex;flex-direction:column;gap:12px">
  <?php foreach($svc_plans as $pl): ?>
  <div class="gs-card" style="margin-bottom:0">
    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:14px;flex-wrap:wrap">
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
          <div style="font-weight:700;font-size:.92rem;color:#1E293B"><?php echo esc_html($pl->name); ?></div>
          <span style="font-size:.68rem;padding:2px 8px;border-radius:10px;font-weight:700;background:<?php echo $pl->is_active?'#F0FDF4':'#F1F5F9'; ?>;color:<?php echo $pl->is_active?'#059669':'#64748B'; ?>"><?php echo $pl->is_active?'Active':'Inactive'; ?></span>
        </div>
        <?php if($pl->description): ?><div style="font-size:.8rem;color:#64748B;margin-bottom:6px"><?php echo esc_html($pl->description); ?></div><?php endif; ?>
        <div style="display:flex;gap:12px;flex-wrap:wrap">
          <span style="font-size:.8rem;color:#2563EB;font-weight:700">₹<?php echo number_format((float)$pl->price); ?></span>
          <span style="font-size:.8rem;color:#64748B"><?php echo ucfirst($pl->frequency); ?></span>
          <span style="font-size:.8rem;color:#64748B"><?php echo $pl->visits_included; ?> visit<?php echo $pl->visits_included>1?'s':''; ?>/cycle</span>
          <span style="font-size:.8rem;color:#059669;font-weight:600"><?php echo $pl->active_subs; ?> active subscriber<?php echo $pl->active_subs!=1?'s':''; ?></span>
          <?php if ($pl->next_visit): ?><span style="font-size:.8rem;color:#7C3AED;font-weight:600">📅 Next visit: <?php echo esc_html(date('d M Y', strtotime($pl->next_visit))); ?></span><?php endif; ?>
          <a href="?section=leads&service_plan_id=<?php echo (int) $pl->id; ?>" title="Jump straight to this plan's auto-generated inquiries" style="font-size:.8rem;color:#2563EB;font-weight:600;text-decoration:underline"><?php echo (int)$pl->auto_leads; ?> auto-generated inquir<?php echo (int)$pl->auto_leads!=1?'ies':'y'; ?> →</a>
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-shrink:0">
        <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsSvcPlanToggleActive(<?php echo (int) $pl->id; ?>,<?php echo $pl->is_active?0:1; ?>,this)"><?php echo $pl->is_active?'⏸ Deactivate':'▶ Activate'; ?></button>
        <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsSvcPlanEdit(<?php echo esc_js(json_encode($pl)); ?>)">✏ Edit</button>
        <button class="gs-btn gs-btn-sm" style="background:#FEF2F2;color:#DC2626;border-color:#FECACA" onclick="gsSvcPlanDelete(<?php echo $pl->id; ?>,'<?php echo esc_js($pl->name); ?>')">✕ Delete</button>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">🔄</div><div class="gs-empty-title">No service plans yet</div><div>Create your first recurring service plan to offer clients a convenient subscription option.</div></div>
<?php endif; ?>
<script>
function gsSvcPlanNew(){document.getElementById('gs-svc-modal-title').textContent='New Service Plan';document.getElementById('gs-svc-plan-id').value='';document.getElementById('gs-svc-name').value='';document.getElementById('gs-svc-desc').value='';document.getElementById('gs-svc-price').value='';document.getElementById('gs-svc-freq').value='monthly';document.getElementById('gs-svc-visits').value=1;document.getElementById('gs-svc-modal').style.display='flex';}
function gsSvcPlanEdit(p){document.getElementById('gs-svc-modal-title').textContent='Edit Service Plan';document.getElementById('gs-svc-plan-id').value=p.id;document.getElementById('gs-svc-name').value=p.name||'';document.getElementById('gs-svc-desc').value=p.description||'';document.getElementById('gs-svc-price').value=p.price||'';document.getElementById('gs-svc-freq').value=p.frequency||'monthly';document.getElementById('gs-svc-visits').value=p.visits_included||1;document.getElementById('gs-svc-modal').style.display='flex';}
function gsSvcPlanSave(){
  var id=document.getElementById('gs-svc-plan-id').value;
  var name=document.getElementById('gs-svc-name').value.trim();
  var price=document.getElementById('gs-svc-price').value;
  if(!name||!price){gsToast('Name and price are required','error');return;}
  var action=id?'gs_update_service_plan':'gs_create_service_plan';
  var data={nonce:'<?php echo esc_js($nonce); ?>',name:name,description:document.getElementById('gs-svc-desc').value,price:price,frequency:document.getElementById('gs-svc-freq').value,visits_included:document.getElementById('gs-svc-visits').value};
  if(id)data.plan_id=id;
  gsPost(action,data,function(){gsToast('Plan saved!','success');location.reload();},function(m){gsToast(m||'Failed','error');});
}
function gsSvcPlanDelete(id,name){if(!confirm('Delete plan "'+(name||'this plan')+'"? Existing subscribers will not be affected.'))return;gsPost('gs_delete_service_plan',{nonce:'<?php echo esc_js($nonce); ?>',plan_id:id},function(){gsToast('Plan deleted','info');location.reload();},function(m){gsToast(m||'Failed','error');});}
function gsSvcPlanToggleActive(id,newState,btn){
  btn.disabled=true;
  gsPost('gs_toggle_service_plan_active',{nonce:'<?php echo esc_js($nonce); ?>',plan_id:id,is_active:newState},
    function(d){gsToast(d.message||'Plan updated','success');location.reload();},
    function(m){gsToast(m||'Failed to update plan status','error');btn.disabled=false;});
}
</script>
<?php echo gs_render_screen_help( 'Recurring Service Plans', [
  
], [
  [ 'mistake' => "Deleting a service plan expecting existing subscribers to be cancelled or refunded automatically", 'category' => 'workflow', 'see' => "The delete confirmation explicitly states: 'Existing subscribers will not be affected.' — deleting only removes the plan from being offered to new customers; current subscriptions continue running.", 'fix' => 'If existing subscribers genuinely need to be cancelled or migrated to a different plan, handle that separately (contact support if there is no self-service cancellation flow) before or after deleting the plan definition — deletion alone does not do this.', 'prevent' => 'Read the delete confirmation text carefully; it is intentionally scoped to only stop new signups, not manage existing subscriptions.' ],
  [ 'mistake' => "Setting 'Visits included per cycle' to a number that doesn't logically match the selected Frequency", 'category' => 'incorrect-settings', 'see' => "The Visits field accepts any value from 1 to 52 independently of the Frequency dropdown (monthly/quarterly/biannual/annual/weekly) — there is no built-in validation cross-checking the two (e.g. nothing stops setting 'Monthly' frequency with 12 visits per cycle).", 'fix' => 'Manually ensure Visits Included matches what is actually intended for the chosen Frequency (e.g. 1 visit for a straightforward Monthly plan, or more only if genuinely offering multiple visits within that billing cycle).', 'prevent' => 'Double check the combination of Frequency and Visits Included before saving, since the form will accept and save any combination without warning.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: PROMOTIONS — Colony Group Deals & Flash Slots (Moat 2)
// FIXED — audit gap: GroupDealService and its 8 AJAX actions
// (gs_create_group_deal, gs_get_vendor_group_deals, gs_join_group_deal,
// gs_get_group_deals, gs_create_flash_slot, gs_get_vendor_flash_slots,
// gs_book_flash_slot, gs_get_flash_slots) were fully built, hardened and
// registered, but had zero UI callers anywhere in the plugin — a vendor had
// no way to ever create a Group Deal or a Flash Slot. This screen is the
// vendor-side management UI for both. The customer-facing join/book side is
// exposed publicly and safely from here too: each created deal/slot gets a
// standalone share link (?gs_group_deal=<uuid> / ?gs_flash_slot=<id> on this
// listing's own storefront URL) so vendors can share it directly (WhatsApp,
// etc.) without requiring a new site-wide route or edits to the large public
// vendor-site.php template — avoiding that regression risk entirely while
// still making the already-built join/book actions reachable end to end.
// ══════════════════════════════════════════════════════════════════════════════
case 'promotions':
  $pr_listings = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT id, title, slug FROM {$pfx}listings WHERE vendor_id=%d AND status IN('active','pending','draft') ORDER BY created_at DESC", $vid
  ) ) : [];
  $pr_deals = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT d.*, (SELECT COUNT(*) FROM {$pfx}gs_group_deal_members m WHERE m.deal_id=d.id) AS member_count
     FROM {$pfx}gs_group_deals d WHERE d.vendor_id=%d ORDER BY d.created_at DESC LIMIT 20", $vid
  ) ) : [];
  $pr_slots = $vid ? $wpdb->get_results( $wpdb->prepare(
    "SELECT * FROM {$pfx}gs_flash_slots WHERE vendor_id=%d ORDER BY created_at DESC LIMIT 20", $vid
  ) ) : [];
  // Share links reuse each listing's own already-live public URL
  // (home_url('/'.$listing->slug.'/')) — the exact pattern used
  // everywhere else in this file (see the "View"/"Preview" links in the
  // Listings screen above) — rather than inventing a new URL scheme, so
  // this needs no Router.php changes at all.
  $pr_slug_by_id = [];
  foreach ( $pr_listings as $pl_row ) { $pr_slug_by_id[ (int) $pl_row->id ] = $pl_row->slug; }
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">🎉 Promotions</div><div class="gs-ph-sub">Colony group deals and flash slots to fill more bookings</div></div>
</div>

<?php if ( ! $pr_listings ): ?>
<div class="gs-empty"><div class="gs-empty-icon">🏢</div><div class="gs-empty-title">No listings yet</div><div>Create a listing first, then set up promotions for it here.</div></div>
<?php else: ?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
<!-- Group Deals -->
<div class="gs-card">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
    <div style="font-weight:700;font-size:.9rem;color:#1E293B">👥 Colony Group Deals</div>
    <button class="gs-btn gs-btn-primary gs-btn-sm" onclick="gsDealNew()">+ New</button>
  </div>
  <div style="font-size:.78rem;color:#64748B;margin-bottom:12px">Offer a discount once enough neighbours in a colony join together. Share the link and it fills itself.</div>
  <?php if ( $pr_deals ): foreach ( $pr_deals as $d ): $d_slug = $pr_slug_by_id[ (int) $d->listing_id ] ?? ''; $d_link = $d_slug ? home_url( '/' . $d_slug . '/?gs_group_deal=' . $d->id ) : ''; ?>
  <div style="border:1px solid #E2E8F0;border-radius:10px;padding:10px;margin-bottom:8px">
    <div style="display:flex;justify-content:space-between;gap:8px">
      <div style="font-weight:600;font-size:.83rem"><?php echo esc_html($d->title); ?></div>
      <span style="font-size:.68rem;padding:2px 8px;border-radius:10px;font-weight:700;background:<?php echo $d->status==='active'?'#F0FDF4':($d->status==='expired'?'#FEF2F2':'#F1F5F9'); ?>;color:<?php echo $d->status==='active'?'#059669':($d->status==='expired'?'#DC2626':'#64748B'); ?>"><?php echo esc_html(ucfirst($d->status)); ?></span>
    </div>
    <div style="font-size:.75rem;color:#64748B;margin-top:4px">₹<?php echo number_format((float)$d->deal_price); ?> (was ₹<?php echo number_format((float)$d->original_price); ?>) · <?php echo (int)$d->current_count; ?>/<?php echo (int)$d->min_bookings; ?> joined to activate · expires <?php echo esc_html(date('d M', strtotime($d->expires_at))); ?></div>
    <?php if ( $d_link ): ?>
    <div style="display:flex;gap:8px;align-items:center;margin-top:6px">
      <input readonly onclick="this.select()" value="<?php echo esc_attr($d_link); ?>" style="flex:1;font-size:.72rem;padding:4px 6px;border:1px solid #E2E8F0;border-radius:6px;color:#64748B">
      <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="navigator.clipboard.writeText('<?php echo esc_js($d_link); ?>');gsToast('Link copied!','success')">Copy</button>
    </div>
    <?php endif; ?>
  </div>
  <?php endforeach; else: ?>
  <div style="font-size:.8rem;color:#94A3B8;text-align:center;padding:16px 0">No group deals yet.</div>
  <?php endif; ?>
</div>

<!-- Flash Slots -->
<div class="gs-card">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
    <div style="font-weight:700;font-size:.9rem;color:#1E293B">⚡ Flash Slots</div>
    <button class="gs-btn gs-btn-primary gs-btn-sm" onclick="gsSlotNew()">+ New</button>
  </div>
  <div style="font-size:.78rem;color:#64748B;margin-bottom:12px">Got a cancelled or open slot? Offer it at a discount for a limited time to fill it fast.</div>
  <?php if ( $pr_slots ): foreach ( $pr_slots as $s ): $s_slug = $pr_slug_by_id[ (int) $s->listing_id ] ?? ''; $s_link = $s_slug ? home_url( '/' . $s_slug . '/?gs_flash_slot=' . (int) $s->id ) : ''; ?>
  <div style="border:1px solid #E2E8F0;border-radius:10px;padding:10px;margin-bottom:8px">
    <div style="display:flex;justify-content:space-between;gap:8px">
      <div style="font-weight:600;font-size:.83rem"><?php echo esc_html(date('d M', strtotime($s->slot_date))); ?>, <?php echo esc_html(date('g:i A', strtotime($s->slot_time))); ?></div>
      <span style="font-size:.68rem;padding:2px 8px;border-radius:10px;font-weight:700;background:<?php echo $s->status==='active'?'#F0FDF4':($s->status==='booked'?'#EFF6FF':'#F1F5F9'); ?>;color:<?php echo $s->status==='active'?'#059669':($s->status==='booked'?'#2563EB':'#64748B'); ?>"><?php echo esc_html(ucfirst($s->status)); ?></span>
    </div>
    <div style="font-size:.75rem;color:#64748B;margin-top:4px">₹<?php echo number_format((float)$s->flash_price); ?> (was ₹<?php echo number_format((float)$s->original_price); ?>, -<?php echo (int)$s->discount_pct; ?>%) · <?php echo (int)$s->radius_km; ?>km radius</div>
    <?php if ( $s->status === 'active' && $s_link ): ?>
    <div style="display:flex;gap:8px;align-items:center;margin-top:6px">
      <input readonly onclick="this.select()" value="<?php echo esc_attr($s_link); ?>" style="flex:1;font-size:.72rem;padding:4px 6px;border:1px solid #E2E8F0;border-radius:6px;color:#64748B">
      <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="navigator.clipboard.writeText('<?php echo esc_js($s_link); ?>');gsToast('Link copied!','success')">Copy</button>
    </div>
    <?php endif; ?>
  </div>
  <?php endforeach; else: ?>
  <div style="font-size:.8rem;color:#94A3B8;text-align:center;padding:16px 0">No flash slots yet.</div>
  <?php endif; ?>
</div>
</div>

<!-- New Group Deal Modal -->
<div id="gs-deal-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:14px;padding:24px;width:min(500px,95vw);max-height:90vh;overflow-y:auto">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
      <div style="font-weight:700;font-size:1rem;color:#1E3A5F">New Group Deal</div>
      <button onclick="document.getElementById('gs-deal-modal').style.display='none'" style="background:none;border:none;font-size:1.2rem;cursor:pointer;color:#94A3B8">✕</button>
    </div>
    <div class="gs-fg"><label class="gs-lbl">Listing <span class="gs-req">*</span></label>
      <select id="gs-deal-listing" class="gs-sel"><?php foreach ($pr_listings as $pl): ?><option value="<?php echo (int)$pl->id; ?>"><?php echo esc_html($pl->title); ?></option><?php endforeach; ?></select>
    </div>
    <div class="gs-fg"><label class="gs-lbl">Title <span class="gs-req">*</span></label><input id="gs-deal-title" class="gs-inp" placeholder="e.g. Sector 12 AC Service Deal"></div>
    <div class="gs-fg"><label class="gs-lbl">Colony / Area name</label><input id="gs-deal-colony" class="gs-inp" placeholder="e.g. Sector 12, Green Park"></div>
    <div class="gs-fg"><label class="gs-lbl">Service date <span class="gs-req">*</span></label><input id="gs-deal-date" type="date" class="gs-inp" min="<?php echo date('Y-m-d'); ?>"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="gs-fg"><label class="gs-lbl">Original price (₹) <span class="gs-req">*</span></label><input id="gs-deal-orig" type="number" class="gs-inp" placeholder="1000"></div>
      <div class="gs-fg"><label class="gs-lbl">Deal price (₹) <span class="gs-req">*</span></label><input id="gs-deal-price" type="number" class="gs-inp" placeholder="700"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="gs-fg"><label class="gs-lbl">Min. bookings to activate</label><input id="gs-deal-min" type="number" class="gs-inp" value="3" min="2"></div>
      <div class="gs-fg"><label class="gs-lbl">Max. bookings</label><input id="gs-deal-max" type="number" class="gs-inp" value="10" min="2"></div>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:6px">
      <button class="gs-btn gs-btn-ghost" onclick="document.getElementById('gs-deal-modal').style.display='none'">Cancel</button>
      <button class="gs-btn gs-btn-primary" onclick="gsDealSave()">Create Deal</button>
    </div>
  </div>
</div>

<!-- New Flash Slot Modal -->
<div id="gs-slot-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:14px;padding:24px;width:min(500px,95vw);max-height:90vh;overflow-y:auto">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
      <div style="font-weight:700;font-size:1rem;color:#1E3A5F">New Flash Slot</div>
      <button onclick="document.getElementById('gs-slot-modal').style.display='none'" style="background:none;border:none;font-size:1.2rem;cursor:pointer;color:#94A3B8">✕</button>
    </div>
    <div class="gs-fg"><label class="gs-lbl">Listing <span class="gs-req">*</span></label>
      <select id="gs-slot-listing" class="gs-sel"><?php foreach ($pr_listings as $pl): ?><option value="<?php echo (int)$pl->id; ?>"><?php echo esc_html($pl->title); ?></option><?php endforeach; ?></select>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="gs-fg"><label class="gs-lbl">Date <span class="gs-req">*</span></label><input id="gs-slot-date" type="date" class="gs-inp" min="<?php echo date('Y-m-d'); ?>"></div>
      <div class="gs-fg"><label class="gs-lbl">Time <span class="gs-req">*</span></label><input id="gs-slot-time" type="time" class="gs-inp" value="10:00"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="gs-fg"><label class="gs-lbl">Original price (₹) <span class="gs-req">*</span></label><input id="gs-slot-orig" type="number" class="gs-inp" placeholder="1000"></div>
      <div class="gs-fg"><label class="gs-lbl">Flash price (₹) <span class="gs-req">*</span></label><input id="gs-slot-price" type="number" class="gs-inp" placeholder="750"></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div class="gs-fg"><label class="gs-lbl">Discount %</label><input id="gs-slot-discount" type="number" class="gs-inp" value="25" min="5" max="80"></div>
      <div class="gs-fg"><label class="gs-lbl">Radius (km)</label><input id="gs-slot-radius" type="number" class="gs-inp" value="5" min="1" max="50"></div>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:6px">
      <button class="gs-btn gs-btn-ghost" onclick="document.getElementById('gs-slot-modal').style.display='none'">Cancel</button>
      <button class="gs-btn gs-btn-primary" onclick="gsSlotSave()">Create Slot</button>
    </div>
  </div>
</div>
<?php endif; ?>
<script>
function gsDealNew(){document.getElementById('gs-deal-title').value='';document.getElementById('gs-deal-colony').value='';document.getElementById('gs-deal-date').value='';document.getElementById('gs-deal-orig').value='';document.getElementById('gs-deal-price').value='';document.getElementById('gs-deal-min').value=3;document.getElementById('gs-deal-max').value=10;document.getElementById('gs-deal-modal').style.display='flex';}
function gsDealSave(){
  var title=document.getElementById('gs-deal-title').value.trim();
  var date=document.getElementById('gs-deal-date').value;
  var orig=document.getElementById('gs-deal-orig').value;
  var price=document.getElementById('gs-deal-price').value;
  if(!title||!date||!orig||!price){gsToast('Title, date and both prices are required','error');return;}
  gsPost('gs_create_group_deal',{
    nonce:'<?php echo esc_js($nonce); ?>',
    listing_id:document.getElementById('gs-deal-listing').value,
    title:title,
    colony_name:document.getElementById('gs-deal-colony').value,
    service_date:date,
    original_price:orig,
    deal_price:price,
    min_bookings:document.getElementById('gs-deal-min').value,
    max_bookings:document.getElementById('gs-deal-max').value
  },function(){gsToast('Group deal created!','success');location.reload();},function(m){gsToast(m||'Failed to create deal','error');});
}
function gsSlotNew(){document.getElementById('gs-slot-date').value='';document.getElementById('gs-slot-time').value='10:00';document.getElementById('gs-slot-orig').value='';document.getElementById('gs-slot-price').value='';document.getElementById('gs-slot-discount').value=25;document.getElementById('gs-slot-radius').value=5;document.getElementById('gs-slot-modal').style.display='flex';}
function gsSlotSave(){
  var date=document.getElementById('gs-slot-date').value;
  var time=document.getElementById('gs-slot-time').value;
  var orig=document.getElementById('gs-slot-orig').value;
  var price=document.getElementById('gs-slot-price').value;
  if(!date||!time||!orig||!price){gsToast('Date, time and both prices are required','error');return;}
  gsPost('gs_create_flash_slot',{
    nonce:'<?php echo esc_js($nonce); ?>',
    listing_id:document.getElementById('gs-slot-listing').value,
    slot_date:date,
    slot_time:time+':00',
    original_price:orig,
    flash_price:price,
    discount_pct:document.getElementById('gs-slot-discount').value,
    radius_km:document.getElementById('gs-slot-radius').value
  },function(){gsToast('Flash slot created!','success');location.reload();},function(m){gsToast(m||'Failed to create slot','error');});
}
</script>
<?php echo gs_render_screen_help( 'Promotions — Group Deals & Flash Slots', [], [
  [ 'mistake' => "Expecting a Group Deal to auto-charge or auto-book members once it activates", 'category' => 'workflow', 'see' => "Activation (reaching Min. bookings) only flips the deal's status to 'active' — it does not create bookings or charge anyone automatically.", 'fix' => 'Follow up with interested members directly (their contact details are captured when they join) to convert them into actual bookings.', 'prevent' => 'Treat an activated deal as a qualified list of interested neighbours, not as confirmed, paid bookings.' ],
  [ 'mistake' => "Setting a Flash Slot's date/time in the past or too close to now", 'category' => 'incorrect-settings', 'see' => "The slot's own slot_date/slot_time is also used as its expiry — a slot created for today at a time that has already passed will show as expired immediately.", 'fix' => 'Pick a realistic future date/time that leaves enough of a booking window before the slot itself.', 'prevent' => 'Double-check the date and time before saving; there is no separate expiry field to fall back on.' ],
] ); ?>
<?php break;

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: NOTIFICATIONS PREFERENCES (Part 27.3)
// ══════════════════════════════════════════════════════════════════════════════
case 'notifications':
  $notif_events = [
    'lead.new'       => ['New inquiry received',        'Every time a client submits an inquiry to you'],
    'lead.overdue'   => ['Inquiry unanswered (2h)',      "Alert when you haven't replied within 2 hours"],
    'lead.escalated' => ['Inquiry unanswered (6h)',      "Escalation when inquiry is still unread after 6 hours"],
    'booking.confirmed' => ['Booking confirmed',         'When a booking is confirmed'],
    'booking.reminder'  => ['Booking reminder (2h)',     '2 hours before a scheduled booking'],
    'quote.accepted'    => ['Quote accepted by client',  "When a client accepts your quotation"],
    'review.new'        => ['New review received',       'When a client leaves a review on your listing'],
    'listing.approved'  => ['Listing approved',          "When admin approves your listing or changes"],
    'subscription.trial_ending' => ['Trial ending soon', "4 days before your trial ends"],
  ];
  // Fetch existing prefs
  $notif_prefs = [];
  if ($uid && $wpdb->get_var("SHOW TABLES LIKE '{$pfx}notification_preferences'")) {
    $rows = $wpdb->get_results($wpdb->prepare(
      "SELECT * FROM {$pfx}notification_preferences WHERE user_id=%d", $uid
    ));
    foreach($rows as $r) $notif_prefs[$r->event_type] = $r;
  }
  // FIXED — Known Limitations audit: the PUSH column used to be checkable/saveable regardless
  // of whether push infrastructure was actually ready — a vendor could save "on" and reasonably
  // believe push would work, when it silently never would. Check both prerequisites server-side
  // so the UI can tell the vendor the real state instead of pretending the checkbox always works.
  $gs_vapid_ready = (bool) get_option( 'gs_vapid_public_key' );
  $gs_push_subscribed = $uid && $wpdb->get_var("SHOW TABLES LIKE '{$pfx}push_subscriptions'")
    ? (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$pfx}push_subscriptions WHERE user_id=%d LIMIT 1", $uid ) )
    : false;
?>
<div class="gs-ph"><div><div class="gs-ph-title">🔔 Notification Preferences</div><div class="gs-ph-sub">Choose how you want to be notified for each event</div></div></div>
<?php if ( ! $gs_vapid_ready ): ?>
<div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:10px;padding:12px 16px;margin-bottom:14px;font-size:.82rem;color:#92400E">
  ℹ️ Push notifications are not yet available on this platform (not configured by the admin). Checking "Push" below will save your preference, but no push notification will actually be sent until this is set up. Email and In-App notifications are unaffected.
</div>
<?php elseif ( ! $gs_push_subscribed ): ?>
<div id="gs-push-enable-notice" style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:10px;padding:12px 16px;margin-bottom:14px;font-size:.82rem;color:#1E40AF;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
  <span>🔔 Your browser isn't subscribed to push notifications yet — checking "Push" below will save your preference, but nothing will actually arrive until you enable it here.</span>
  <button class="gs-btn gs-btn-primary gs-btn-sm" onclick="gsEnableBrowserPush(this)">Enable Push in this browser</button>
</div>
<?php endif; ?>
<div class="gs-card">
  <div style="display:grid;grid-template-columns:1fr auto auto auto;gap:0;align-items:center">
    <!-- Header -->
    <div style="font-size:.7rem;font-weight:700;color:#94A3B8;padding:8px 0;border-bottom:1px solid #F1F5F9">EVENT</div>
    <div style="font-size:.7rem;font-weight:700;color:#94A3B8;padding:8px 12px;border-bottom:1px solid #F1F5F9;text-align:center">EMAIL<br><a href="#" onclick="gsNotifBulk('email',true);return false;" style="font-weight:400;font-size:.65rem">all on</a> / <a href="#" onclick="gsNotifBulk('email',false);return false;" style="font-weight:400;font-size:.65rem">off</a></div>
    <div style="font-size:.7rem;font-weight:700;color:#94A3B8;padding:8px 12px;border-bottom:1px solid #F1F5F9;text-align:center">PUSH<br><a href="#" onclick="gsNotifBulk('push',true);return false;" style="font-weight:400;font-size:.65rem">all on</a> / <a href="#" onclick="gsNotifBulk('push',false);return false;" style="font-weight:400;font-size:.65rem">off</a></div>
    <div style="font-size:.7rem;font-weight:700;color:#94A3B8;padding:8px 12px;border-bottom:1px solid #F1F5F9;text-align:center">IN-APP<br><a href="#" onclick="gsNotifBulk('in_app',true);return false;" style="font-weight:400;font-size:.65rem">all on</a> / <a href="#" onclick="gsNotifBulk('in_app',false);return false;" style="font-weight:400;font-size:.65rem">off</a></div>
    <!-- Rows -->
    <?php foreach($notif_events as $evt_key => $evt): ?>
    <?php $p = $notif_prefs[$evt_key] ?? null; ?>
    <div style="padding:12px 0;border-bottom:1px solid #F8FAFC">
      <div style="font-size:.85rem;font-weight:600;color:#1E293B"><?php echo esc_html($evt[0]); ?></div>
      <div style="font-size:.74rem;color:#94A3B8;margin-top:2px"><?php echo esc_html($evt[1]); ?></div>
    </div>
    <?php foreach(['email','push','in_app'] as $ch): ?>
    <div style="padding:12px;border-bottom:1px solid #F8FAFC;text-align:center">
      <input type="checkbox" class="gs-notif-chk" data-event="<?php echo esc_attr($evt_key); ?>" data-channel="<?php echo esc_attr($ch); ?>"
             <?php echo (!$p || $p->$ch) ? 'checked' : ''; ?>
             style="width:16px;height:16px;accent-color:var(--gs-primary);cursor:pointer"
             onchange="gsNotifSave('<?php echo esc_js($evt_key); ?>','<?php echo esc_js($ch); ?>',this.checked)">
    </div>
    <?php endforeach; ?>
    <?php endforeach; ?>
  </div>
</div>
<script>
function gsEnableBrowserPush(btn) {
  if (!('Notification' in window) || !('PushManager' in window)) {
    gsToast('This browser does not support push notifications.', 'error'); return;
  }
  if (typeof gsRequestPushPermission !== 'function') {
    gsToast('Push subscription script not loaded — please reload the page and try again.', 'error'); return;
  }
  btn.disabled = true; btn.textContent = 'Requesting…';
  Promise.resolve(gsRequestPushPermission()).then(function(){
    if (Notification.permission === 'granted') {
      gsToast('Push notifications enabled for this browser!', 'success');
      var notice = document.getElementById('gs-push-enable-notice');
      if (notice) notice.style.display = 'none';
    } else {
      gsToast('Push permission was not granted.', 'error');
      btn.disabled = false; btn.textContent = 'Enable Push in this browser';
    }
  }).catch(function(){
    gsToast('Could not enable push notifications.', 'error');
    btn.disabled = false; btn.textContent = 'Enable Push in this browser';
  });
}
function gsNotifSave(event_type, channel, enabled) {
  gsPost('gs_save_notification_preferences',{nonce:'<?php echo esc_js($nonce); ?>',event_type:event_type,channel:channel,enabled:enabled?1:0},
    function(){gsToast('Preference saved','success');},
    function(m){gsToast(m||'Failed to save','error');}
  );
}
function gsNotifBulk(channel, enable) {
  var boxes = document.querySelectorAll('.gs-notif-chk[data-channel="' + channel + '"]');
  if (!boxes.length) return;
  if (!confirm((enable ? 'Enable' : 'Disable') + ' ' + channel.toUpperCase() + ' notifications for all ' + boxes.length + ' events?')) return;
  var done = 0, total = boxes.length;
  boxes.forEach(function(box) {
    box.checked = enable;
    gsPost('gs_save_notification_preferences', {
      nonce: '<?php echo esc_js($nonce); ?>', event_type: box.getAttribute('data-event'), channel: channel, enabled: enable ? 1 : 0
    }, function() { done++; if (done === total) gsToast('All ' + channel.toUpperCase() + ' preferences updated', 'success'); },
       function(m) { gsToast('Failed to update ' + box.getAttribute('data-event') + ': ' + (m || 'error'), 'error'); });
  });
}
</script>
<?php echo gs_render_screen_help( 'Notification Preferences', [
  
  
], [
  [ 'mistake' => "Assuming an unchecked-by-default event means notifications for it are currently off, when a missing preferences row actually defaults to fully enabled", 'category' => 'incorrect-settings', 'see' => "The checked state logic is <?php echo (!\$p || \$p->\$ch) ? 'checked' : ''; ?> — when no preference row exists yet for an event (\$p is null), every channel defaults to checked (enabled), not unchecked.", 'fix' => 'Do not assume a never-configured event is silently off — by default, every notification channel is ON until explicitly unchecked and saved at least once.', 'prevent' => "If a specific notification type should be silenced, explicitly uncheck it here rather than assuming it starts disabled." ],
  [ 'mistake' => "Unchecking Email for 'Inquiry unanswered (2h)' or 'Inquiry unanswered (6h)' assuming this stops the underlying escalation/tracking, not just the notification", 'category' => 'workflow', 'see' => "These preference checkboxes only control whether a notification is sent through that channel — they do not change the platform's own SLA/escalation timers or Trust Score/response-rate calculations tied to reply speed.", 'fix' => "Understand that disabling these notification channels only means the vendor won't be alerted — the underlying 2h/6h overdue tracking (which can affect Trust Score) continues regardless of notification settings.", 'prevent' => "Keep at least one channel enabled for overdue-inquiry alerts if response speed matters for Trust Score, since silencing all channels removes the reminder but not the consequence of a slow reply." ],
] ); ?>
<?php break;


// ══════════════════════════════════════════════════════════════════════════════
// SECTION: WHATSAPP TEMPLATES (Part 13.3)
// ══════════════════════════════════════════════════════════════════════════════
case 'whatsapp':
  $wa_tpls = $vid ? $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$pfx}whatsapp_templates WHERE vendor_id=%d ORDER BY category_slug ASC, created_at DESC",
    $vid
  )) : [];
  // Check if table exists  
  if(!$wpdb->get_var("SHOW TABLES LIKE '{$pfx}whatsapp_templates'")):
?>
  <div class="gs-card" style="background:#EFF6FF;border-color:#BFDBFE">
    <div style="display:flex;align-items:center;gap:12px"><div style="font-size:1.5rem">📱</div>
    <div><div style="font-weight:700;font-size:.9rem;color:#1E40AF">WhatsApp Templates</div>
    <div style="font-size:.82rem;color:#3B82F6;margin-top:4px">Run database upgrade from Admin → Tools to enable WhatsApp templates.</div></div></div>
  </div>
<?php else: ?>
<div class="gs-ph">
  <div><div class="gs-ph-title">📱 WhatsApp Templates</div><div class="gs-ph-sub">Pre-written messages for quick WhatsApp outreach</div></div>
  <button class="gs-btn gs-btn-primary" onclick="gsWaTplNew()">+ New Template</button>
</div>
<div class="gs-card" style="background:#F0FDF4;border-color:#BBF7D0;margin-bottom:16px">
  <div style="font-size:.84rem;color:#166534"><strong>Available tokens:</strong> <code>{{client_name}}</code> <code>{{service}}</code> <code>{{vendor_name}}</code> <code>{{date}}</code> <code>{{visiting_charge}}</code></div>
</div>

<div id="gs-wa-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;align-items:center;justify-content:center">
  <div style="background:#fff;border-radius:14px;padding:24px;width:min(500px,95vw);max-height:90vh;overflow-y:auto">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <div style="font-weight:700;color:#1E3A5F" id="gs-wa-modal-title">New WhatsApp Template</div>
      <button onclick="document.getElementById('gs-wa-modal').style.display='none'" style="background:none;border:none;font-size:1.2rem;cursor:pointer;color:#94A3B8">✕</button>
    </div>
    <input type="hidden" id="gs-wa-tpl-id" value="">
    <div class="gs-fg"><label class="gs-lbl">Template name <span class="gs-req">*</span></label><input id="gs-wa-name" class="gs-inp" placeholder="e.g. First contact, Follow-up after quote"></div>
    <div class="gs-fg"><label class="gs-lbl">Category (optional)</label>
      <select id="gs-wa-cat" class="gs-sel">
        <option value="">All categories</option>
        <?php foreach($cats as $cat): ?><option value="<?php echo esc_attr($cat->name); ?>"><?php echo esc_html($cat->icon_emoji.' '.$cat->name); ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="gs-fg"><label class="gs-lbl">Message body <span class="gs-req">*</span></label>
      <textarea id="gs-wa-body" class="gs-ta" rows="5" placeholder="Hi {{client_name}}, thank you for your inquiry. I can help with {{service}}..."></textarea>
      <div class="gs-hint">Max 1000 chars. WhatsApp does not support HTML or markdown.</div>
    </div>
    <div style="display:flex;gap:10px;justify-content:flex-end">
      <button class="gs-btn gs-btn-ghost" onclick="document.getElementById('gs-wa-modal').style.display='none'">Cancel</button>
      <button class="gs-btn gs-btn-primary" onclick="gsWaTplSave()">Save Template</button>
    </div>
  </div>
</div>

<?php if($wa_tpls): ?>
<div style="display:flex;flex-direction:column;gap:10px">
  <?php foreach($wa_tpls as $wt): ?>
  <div class="gs-card" style="margin-bottom:0">
    <div style="display:flex;align-items:flex-start;gap:12px">
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
          <div style="font-weight:700;font-size:.87rem"><?php echo esc_html($wt->name); ?></div>
          <?php if($wt->category_slug): ?><span style="font-size:.68rem;padding:2px 7px;background:#F0FDF4;color:#059669;border-radius:10px"><?php echo esc_html($wt->category_slug); ?></span><?php endif; ?>
        </div>
        <div style="font-size:.79rem;color:#64748B;line-height:1.5;white-space:pre-wrap;max-height:3em;overflow:hidden"><?php echo esc_html(substr($wt->body,0,150)); ?><?php echo strlen($wt->body)>150?'…':''; ?></div>
      </div>
      <div style="display:flex;gap:6px;flex-shrink:0">
        <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsWaTplEdit(<?php echo esc_js(json_encode($wt)); ?>)">✏ Edit</button>
        <button class="gs-btn gs-btn-sm" style="background:#FEF2F2;color:#DC2626;border-color:#FECACA" onclick="gsWaTplDelete(<?php echo $wt->id; ?>,'<?php echo esc_js($wt->name); ?>')">✕</button>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">📱</div><div class="gs-empty-title">No WhatsApp templates</div><div>Create templates to send personalised WhatsApp messages to clients in one click.</div></div>
<?php endif; ?>
<script>
function gsWaTplNew(){document.getElementById('gs-wa-modal-title').textContent='New WhatsApp Template';document.getElementById('gs-wa-tpl-id').value='';document.getElementById('gs-wa-name').value='';document.getElementById('gs-wa-body').value='';document.getElementById('gs-wa-cat').value='';document.getElementById('gs-wa-modal').style.display='flex';}
function gsWaTplEdit(t){document.getElementById('gs-wa-modal-title').textContent='Edit Template';document.getElementById('gs-wa-tpl-id').value=t.id;document.getElementById('gs-wa-name').value=t.name||'';document.getElementById('gs-wa-body').value=t.body||'';document.getElementById('gs-wa-cat').value=t.category_slug||'';document.getElementById('gs-wa-modal').style.display='flex';}
function gsWaTplSave(){
  var id=document.getElementById('gs-wa-tpl-id').value;
  var name=document.getElementById('gs-wa-name').value.trim();
  var body=document.getElementById('gs-wa-body').value.trim();
  if(!name||!body){gsToast('Name and message body are required','error');return;}
  var action=id?'gs_update_wa_template':'gs_create_wa_template';
  var data={nonce:'<?php echo esc_js($nonce); ?>',name:name,body:body,category_slug:document.getElementById('gs-wa-cat').value};
  if(id)data.template_id=id;
  gsPost(action,data,function(){gsToast('Template saved!','success');location.reload();},function(m){gsToast(m||'Failed','error');});
}
function gsWaTplDelete(id,name){if(!confirm('Delete template "'+(name||'this template')+'"?'))return;gsPost('gs_delete_wa_template',{nonce:'<?php echo esc_js($nonce); ?>',template_id:id},function(){gsToast('Deleted','info');location.reload();},function(m){gsToast(m||'Failed','error');});}
</script>

<?php
// ── Category Auto-Message customization — a DIFFERENT feature from the
// canned templates above: this is the ONE message that auto-fills the
// "Message [Vendor Name]" WhatsApp deep-link button customers see on this
// vendor's listing page, per service category. Real fix, Audit Section F
// ("vendor templates"): previously only an admin could set this platform-
// wide (gs_whatsapp_category_templates); a vendor can now submit their own
// version, which goes live only once an admin approves it — see
// AjaxController::saveVendorWhatsappTemplate()/approveWhatsappTemplate(). ──
$wa_cat_tbl_exists = $wpdb->get_var("SHOW TABLES LIKE '{$pfx}whatsapp_category_templates'");
if ($wa_cat_tbl_exists):
  $my_wa_overrides = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$pfx}whatsapp_category_templates WHERE vendor_id=%d ORDER BY category_slug ASC",
    $vid
  ));
?>
<div class="gs-card" style="margin-top:20px">
  <div class="gs-card-header">
    <div class="gs-card-title">💬 Customize Your "Message Me" Default Text</div>
  </div>
  <div style="font-size:.82rem;color:#64748B;margin-bottom:14px">
    This is the pre-filled message customers see when they tap "Message [You]" on your listing page. The platform sets a sensible default per category — you can submit your own version below. <strong>It won't go live until an admin reviews and approves it</strong> — until then, the platform default still applies. Reviews are typically completed within <strong>1-2 business days</strong>; you'll get a notification here as soon as a decision is made.
  </div>
  <?php if ($my_wa_overrides): ?>
  <div style="margin-bottom:16px">
    <?php foreach ($my_wa_overrides as $ov):
      $status_label = $ov->status === 'approved' ? '✅ Live' : ($ov->status === 'pending_review' ? '⏳ Awaiting admin review' : '📝 Draft (was rejected — edit and resubmit)');
      $status_color = $ov->status === 'approved' ? '#059669' : ($ov->status === 'pending_review' ? '#D97706' : '#64748B');
    ?>
    <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:10px 14px;margin-bottom:8px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
        <strong style="font-size:.82rem"><?php echo esc_html(ucwords(str_replace('-',' ',$ov->category_slug))); ?></strong>
        <span style="font-size:.75rem;font-weight:700;color:<?php echo $status_color; ?>"><?php echo $status_label; ?></span>
      </div>
      <div style="font-size:.8rem;color:#334155"><?php echo esc_html($ov->body); ?></div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <div style="display:grid;grid-template-columns:1fr 2fr auto;gap:10px;align-items:end">
    <div class="gs-fg" style="margin:0"><label class="gs-lbl">Category</label>
      <select id="gs-wa-cat-cust" class="gs-sel">
        <option value="default">Default (any category)</option>
        <?php
          // FIX (enterprise hardening pass): this dropdown previously hardcoded six
          // fixed category slugs, so any category added to the platform after this
          // feature was built (or any category simply not in this short list) could
          // never get a category-specific override — only "Default" was reachable.
          // Now built from the same live $cats source (gs_categories) used by the
          // canned-templates dropdown above and by SEO/Response Templates elsewhere
          // on this dashboard, so it always reflects the platform's real category list.
          foreach ( $cats as $cat ):
        ?>
        <option value="<?php echo esc_attr( sanitize_title( $cat->name ) ); ?>"><?php echo esc_html( $cat->icon_emoji . ' ' . $cat->name ); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="gs-fg" style="margin:0"><label class="gs-lbl">Your Message</label>
      <textarea id="gs-wa-cust-body" class="gs-inp" rows="2" placeholder="Hi {{client_name}}, I'm {{vendor_name}}..." maxlength="1000"></textarea>
    </div>
    <button class="gs-btn gs-btn-primary" onclick="gsWaCustSubmit()">Submit for Review</button>
  </div>
  <div style="font-size:.76rem;color:#94A3B8;margin-top:8px">Available tokens: <code>{{client_name}}</code> <code>{{vendor_name}}</code></div>
</div>
<script>
function gsWaCustSubmit() {
  var body = document.getElementById('gs-wa-cust-body').value.trim();
  var cat  = document.getElementById('gs-wa-cat-cust').value;
  if (!body) { gsToast('Please write a message first', 'error'); return; }
  gsPost('gs_save_vendor_whatsapp_template', { nonce: '<?php echo esc_js($nonce); ?>', category_slug: cat, body: body, language: 'en' },
    function(d) { gsToast(d.message || 'Submitted for review!', 'success'); location.reload(); },
    function(m) { gsToast(m || 'Failed to submit', 'error'); }
  );
}
</script>
<?php endif; ?>

<?php echo gs_render_screen_help( 'WhatsApp Templates', [
  
  
], [
  [ 'mistake' => "Assuming a newly submitted 'Message Me' override is live on the listing page immediately after submitting", 'category' => 'workflow', 'see' => "The screen explicitly states: 'It won't go live until an admin reviews and approves it' — until approved, the status badge reads '⏳ Awaiting admin review' and the platform's existing default text continues to display to customers.", 'fix' => 'Check back on this screen for the status badge to change to "✅ Live" before assuming customers are seeing the new custom message; until then, the previous default remains active.', 'prevent' => "Don't rely on a just-submitted override for an active marketing push or promotion — treat it as pending until confirmed approved." ],
  [ 'mistake' => "Confusing the canned 'WhatsApp Templates' list at the top of this screen with the single 'Message Me' auto-fill text further down — they are two entirely separate features", 'category' => 'workflow', 'see' => "The top section manages multiple reusable message templates a vendor manually selects and sends from conversations; the bottom section controls exactly one pre-filled message per category shown automatically when a customer taps the 'Message [Vendor]' button on the listing page.", 'fix' => 'Use the top templates for manually choosing and sending a message during a conversation; use the "Customize Your Message Me Default Text" section only to change what auto-fills for a customer starting a new WhatsApp conversation from the listing page.', 'prevent' => 'Read the section headers carefully — "WhatsApp Templates" and "Customize Your Message Me Default Text" are functionally unrelated despite both dealing with WhatsApp messages.' ],
] ); ?>

<?php endif; break;


// ══════════════════════════════════════════════════════════════════════════════
// SECTION: STAFF PERFORMANCE (Part 17.4)
// ══════════════════════════════════════════════════════════════════════════════
case 'staff_performance':
  // Real fix — closes a documented known limitation ("fixed 30-day window
  // with no way to view a different period"): a simple GET-param selector,
  // the same pattern already used elsewhere on this dashboard for
  // page-reload-based filters, rather than a hardcoded 30-day cutoff.
  $sp_days = (int) ( $_GET['days'] ?? 30 );
  if ( ! in_array( $sp_days, [ 7, 30, 90 ], true ) ) { $sp_days = 30; }
  // FIX (enterprise hardening pass): the original query LEFT JOINed reviews scoped only
  // to the vendor (r.vendor_id=%d, not tied to any individual staff member), which is a
  // classic cartesian-product fan-out — every staff row got multiplied by every one of
  // the vendor's approved reviews, inflating handled_leads/conversions/avg_reply_min by
  // that review count, and making avg_rating identical (the vendor's overall average)
  // for every staff member rather than individually attributed.
  //
  // Root-cause fix: reviews and bookings now carry a real assigned_staff_id (see
  // Schema.php migration + AjaxController::assignBookingStaff() / submitReview()
  // backfill), so ratings can be correctly scoped per staff member via a correlated
  // subquery instead of a join — no fan-out is possible because a subquery returns a
  // single scalar per staff row rather than multiplying the outer row set. Leads join
  // is left as a LEFT JOIN because leads.assigned_staff_id already uniquely attributes
  // one lead to one staff member (no fan-out risk there), but COUNT(DISTINCT ...) is
  // kept defensively in case that ever changes.
  $staff_perf = $vid ? $wpdb->get_results($wpdb->prepare(
    "SELECT vs.id, vs.name, vs.role,
            COUNT(DISTINCT l.id) AS assigned_leads,
            SUM(l.status IN ('replied','converted','closed')) AS handled_leads,
            SUM(l.status='converted') AS conversions,
            AVG(CASE WHEN l.replied_at IS NOT NULL THEN TIMESTAMPDIFF(MINUTE,l.created_at,l.replied_at) END) AS avg_reply_min,
            (SELECT AVG(r.rating) FROM {$pfx}reviews r WHERE r.assigned_staff_id=vs.id AND r.status='approved') AS avg_rating,
            (SELECT COUNT(*) FROM {$pfx}reviews r WHERE r.assigned_staff_id=vs.id AND r.status='approved') AS rating_count
     FROM {$pfx}vendor_staff vs
     LEFT JOIN {$pfx}leads l ON l.assigned_staff_id=vs.id AND l.created_at>DATE_SUB(NOW(),INTERVAL %d DAY)
     WHERE vs.vendor_id=%d AND vs.is_active=1
     GROUP BY vs.id
     ORDER BY handled_leads DESC", $sp_days, $vid
  )) : [];
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">📊 Staff Performance</div><div class="gs-ph-sub">Last <?php echo (int) $sp_days; ?> days · Assign inquiries from the Inquiry Manager</div></div>
  <div style="display:flex;gap:8px;align-items:center">
    <select class="gs-sel" style="width:auto" onchange="window.location.href='?section=staff_performance&days='+this.value">
      <option value="7" <?php selected( $sp_days, 7 ); ?>>Last 7 days</option>
      <option value="30" <?php selected( $sp_days, 30 ); ?>>Last 30 days</option>
      <option value="90" <?php selected( $sp_days, 90 ); ?>>Last 90 days</option>
    </select>
    <a href="?section=staff" class="gs-btn gs-btn-ghost gs-btn-sm">Manage Team</a>
  </div>
</div>
<?php if($staff_perf): ?>
<div class="gs-card">
  <div class="gs-tbl-wrap">
    <table class="gs-tbl">
      <thead>
        <tr>
          <th>Staff Member</th>
          <th>Assigned</th>
          <th>Handled</th>
          <th>Conversions</th>
          <th>Avg Reply</th>
          <th>Avg Rating</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach($staff_perf as $sp):
        $rr = $sp->assigned_leads > 0 ? round($sp->handled_leads/$sp->assigned_leads*100) : 0;
        $reply_txt = $sp->avg_reply_min>0 ? ($sp->avg_reply_min<60 ? round($sp->avg_reply_min).'m' : round($sp->avg_reply_min/60,1).'h') : '—';
      ?>
      <tr>
        <td>
          <div style="font-weight:700;font-size:.87rem"><?php echo esc_html($sp->name); ?></div>
          <div style="font-size:.73rem;color:#94A3B8"><?php echo ucfirst($sp->role??'staff'); ?></div>
        </td>
        <td style="font-weight:700"><?php echo (int)$sp->assigned_leads; ?></td>
        <td>
          <div style="font-weight:700;color:<?php echo $rr>=70?'#059669':($rr>=40?'#D97706':'#DC2626'); ?>"><?php echo (int)$sp->handled_leads; ?></div>
          <div style="font-size:.7rem;color:#94A3B8"><?php echo $rr; ?>% handle rate</div>
        </td>
        <td style="font-weight:700;color:#059669"><?php echo (int)($sp->conversions??0); ?></td>
        <td style="font-size:.84rem"><?php echo esc_html($reply_txt); ?></td>
        <td>
          <?php if($sp->avg_rating>0): ?>
          <span style="color:#F59E0B;font-weight:700">★ <?php echo number_format($sp->avg_rating,1); ?></span>
          <?php else: ?><span style="color:#94A3B8;font-size:.78rem">No ratings</span><?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php else: ?>
<div class="gs-empty">
  <div class="gs-empty-icon">📊</div>
  <div class="gs-empty-title">No performance data yet</div>
  <div>Add team members and assign inquiries to them to see performance stats here.</div>
  <a href="?section=staff" class="gs-btn gs-btn-primary" style="margin-top:14px">Add Team Members →</a>
</div>
<?php endif; ?>
<?php echo gs_render_screen_help( 'Staff Performance', [
], [
  [ 'mistake' => "Expecting Avg Rating to show data immediately after this update, without having assigned any staff to bookings yet", 'category' => 'configuration', 'see' => "Ratings are now correctly scoped per staff member via bookings.assigned_staff_id / reviews.assigned_staff_id, which start out NULL for every existing booking and review — there is no historical data to backfill from, since the platform never recorded this attribution before.", 'fix' => "Start assigning staff to bookings from the Bookings screen going forward; ratings will begin populating as newly-assigned jobs get reviewed. This is expected, correct behavior — not a bug.", 'prevent' => "Make staff assignment part of the standard booking-confirmation workflow so every completed job has an attributed staff member before the customer is asked to review it." ],
  [ 'mistake' => "Assuming a staff member with zero assigned leads this month is inactive or should be removed", 'category' => 'workflow', 'see' => "A staff member only appears with non-zero Assigned/Handled counts if leads were explicitly assigned to them via the Inquiry Manager within the last 30 days — someone who exists on the team but hasn't been assigned anything recently will show zeros, not an error.", 'fix' => "Check the Staff (My Team) screen to confirm whether a zero-activity staff member is still marked active before assuming a problem — this screen only reflects assignment activity, not account status.", 'prevent' => "Actively assign leads to team members from the Inquiry Manager if performance tracking is expected to reflect their work." ],
] ); ?>
<?php break;


// ══════════════════════════════════════════════════════════════════════════════
// SECTION: WHATSAPP ANALYTICS (Part 13.4)
// ══════════════════════════════════════════════════════════════════════════════
case 'wa_analytics':
  // WA clicks vs email clicks vs conversion rates
  $wa_stats = $vid ? $wpdb->get_results($wpdb->prepare(
    "SELECT
       DATE_FORMAT(a.created_at, '%%Y-%%m') AS month,
       SUM(a.event_type='whatsapp_click') AS wa_clicks,
       SUM(a.event_type='email_click')    AS email_clicks,
       SUM(a.event_type='call_click')     AS call_clicks,
       SUM(a.event_type='view')           AS views
     FROM {$pfx}analytics a
     WHERE a.vendor_id=%d AND a.created_at>DATE_SUB(NOW(),INTERVAL 6 MONTH)
     GROUP BY month ORDER BY month DESC", $vid
  )) : [];

  // FIX (enterprise hardening pass): "converted" was defined two different ways on this
  // one screen — the top stat cards used status IN ('converted','closed'), while the
  // category breakdown below used status IN ('replied','converted'). Worse, 'closed' is
  // not even a value in gs_leads.status's ENUM (see Schema.php: new/seen/contacted/
  // qualified/replied/converted/junk) — it was dead, unreachable filter criteria that
  // happened to be harmless only because it could never match a row. Standardized on a
  // single canonical definition — status='converted' — used consistently everywhere on
  // this screen (and matching the enum's actual, real terminal "converted" state),
  // instead of 'replied' (which only means the vendor sent a reply, not that the lead
  // converted) inflating the category breakdown relative to the top-line number.
  $wa_converted_statuses = "'converted'";

  // Category breakdown
  $wa_by_cat = $vid ? $wpdb->get_results($wpdb->prepare(
    "SELECT l.inquiry_module AS category,
            COUNT(*) AS total_leads,
            SUM(l.whatsapp IS NOT NULL AND l.whatsapp!='' AND l.status IN({$wa_converted_statuses})) AS wa_converted
     FROM {$pfx}leads l
     WHERE l.vendor_id=%d AND l.created_at>DATE_SUB(NOW(),INTERVAL 90 DAY) AND l.inquiry_module!=''
     GROUP BY l.inquiry_module
     ORDER BY total_leads DESC LIMIT 10", $vid
  )) : [];

  // Overall WA conversion rate
  $total_wa_leads = $vid?(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d AND whatsapp IS NOT NULL AND whatsapp!='' AND created_at>DATE_SUB(NOW(),INTERVAL 90 DAY)",$vid)):0;
  $wa_converted   = $vid?(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d AND whatsapp IS NOT NULL AND whatsapp!='' AND status IN({$wa_converted_statuses}) AND created_at>DATE_SUB(NOW(),INTERVAL 90 DAY)",$vid)):0;
  $wa_conv_rate   = $total_wa_leads>0?round($wa_converted/$total_wa_leads*100):0;
?>
<div class="gs-ph"><div><div class="gs-ph-title">📱 WhatsApp Analytics</div><div class="gs-ph-sub">Conversion rates and category breakdown: last 90 days · Channel click trend: last 6 months</div></div></div>

<div class="gs-stat-grid" style="margin-bottom:16px">
  <div class="gs-sc">
    <div class="gs-sc-icon" style="background:#F0FDF4">📱</div>
    <div><div class="gs-sc-val" style="color:#059669"><?php echo $total_wa_leads; ?></div><div class="gs-sc-lbl">WA-linked Inquiries</div></div>
  </div>
  <div class="gs-sc">
    <div class="gs-sc-icon" style="background:#ECFDF5">✅</div>
    <div><div class="gs-sc-val" style="color:#059669"><?php echo $wa_converted; ?></div><div class="gs-sc-lbl">Converted via WA</div></div>
  </div>
  <div class="gs-sc">
    <div class="gs-sc-icon" style="background:<?php echo $wa_conv_rate>=30?'#F0FDF4':'#FFFBEB'; ?>">📊</div>
    <div><div class="gs-sc-val" style="color:<?php echo $wa_conv_rate>=30?'#059669':'#D97706'; ?>"><?php echo $wa_conv_rate; ?>%</div><div class="gs-sc-lbl">WA Conversion Rate</div></div>
  </div>
</div>

<?php if($wa_stats): ?>
<div class="gs-card" style="margin-bottom:14px">
  <div class="gs-card-title">Clicks by Channel — Last 6 Months</div>
  <div style="overflow-x:auto">
    <table style="width:100%;border-collapse:collapse;font-size:.82rem">
      <thead><tr>
        <th style="text-align:left;padding:8px 0;color:#64748B;font-weight:600">Month</th>
        <th style="text-align:right;padding:8px 8px;color:#25D366;font-weight:600">WhatsApp</th>
        <th style="text-align:right;padding:8px 8px;color:#2563EB;font-weight:600">Email</th>
        <th style="text-align:right;padding:8px 8px;color:#DC2626;font-weight:600">Call</th>
        <th style="text-align:right;padding:8px 0;color:#94A3B8;font-weight:600">Views</th>
      </tr></thead>
      <tbody>
      <?php foreach($wa_stats as $ws): ?>
      <tr style="border-top:1px solid #F1F5F9">
        <td style="padding:8px 0;font-weight:600"><?php echo date('M Y',strtotime($ws->month.'-01')); ?></td>
        <td style="text-align:right;padding:8px;font-weight:700;color:#25D366"><?php echo (int)$ws->wa_clicks; ?></td>
        <td style="text-align:right;padding:8px;color:#2563EB"><?php echo (int)$ws->email_clicks; ?></td>
        <td style="text-align:right;padding:8px;color:#DC2626"><?php echo (int)$ws->call_clicks; ?></td>
        <td style="text-align:right;padding:8px 0;color:#94A3B8"><?php echo number_format((int)$ws->views); ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<?php if($wa_by_cat): ?>
<div class="gs-card">
  <div class="gs-card-title">Conversion by Category (last 90 days)</div>
  <div style="display:flex;flex-direction:column;gap:8px">
    <?php foreach($wa_by_cat as $wc):
      $rate = $wc->total_leads>0?round($wc->wa_converted/$wc->total_leads*100):0;
    ?>
    <div style="display:flex;align-items:center;gap:10px">
      <div style="flex:1;min-width:0">
        <div style="font-size:.82rem;font-weight:600;margin-bottom:3px"><?php echo esc_html(ucwords(str_replace('-',' ',$wc->category))); ?></div>
        <div style="height:6px;background:#F1F5F9;border-radius:3px">
          <div style="height:100%;background:#25D366;border-radius:3px;width:<?php echo min(100,$rate); ?>%;transition:width .4s"></div>
        </div>
      </div>
      <div style="text-align:right;flex-shrink:0;min-width:80px">
        <div style="font-size:.8rem;font-weight:700;color:#059669"><?php echo $rate; ?>%</div>
        <div style="font-size:.7rem;color:#94A3B8"><?php echo $wc->wa_converted; ?>/<?php echo $wc->total_leads; ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php else: ?>
<div class="gs-empty"><div class="gs-empty-icon">📱</div><div class="gs-empty-title">No WhatsApp data yet</div><div>Data appears after clients contact you via WhatsApp from your listing.</div></div>
<?php endif; ?>
<?php echo gs_render_screen_help( 'WhatsApp Analytics', [
  
  
], [
  [ 'mistake' => "Assuming the top 'Converted via WA' stat card and the sum of the category breakdown will always match exactly", 'category' => 'unexpected-behavior', 'see' => "Both now use the identical 'converted' definition, but the category breakdown is capped to the top 10 categories by lead volume (LIMIT 10) — a vendor with more than 10 active categories will have conversions from the excluded categories counted in the top card but not represented in the breakdown below.", 'fix' => "Treat the top stat card as the authoritative overall total; use the category breakdown to compare relative performance across a vendor's largest categories, not as an exhaustive reconciliation of the total.", 'prevent' => "If a vendor has more than 10 lead-generating categories, expect the category breakdown to omit some contributing conversions by design." ],
  [ 'mistake' => "Expecting a category to appear in the breakdown just because it exists as a listing category, even with zero recent leads", 'category' => 'workflow', 'see' => "\$wa_by_cat only includes categories with at least one lead in the last 90 days (GROUP BY l.inquiry_module on the leads table, not the categories table) and is capped at the top 10 by lead volume — a category with no inquiries in that window simply won't appear.", 'fix' => 'Do not read a missing category from this list as an error — it means no inquiries came in for that category in the last 90 days, not that something is broken.', 'prevent' => "Check the Leads screen directly (with a longer or custom date filter, if available) to confirm whether a specific category genuinely has no recent activity." ],
] ); ?>
<?php break; ?>

<?php endswitch; ?>
</div><!-- .gs-vd-body -->
</div><!-- .gs-vd -->

<?php
// ══ MOBILE NAVIGATION SYSTEM ═══════════════════════════════════════════
// Fixed bottom tab bar + slide-up "More" drawer
// Shown only on ≤768px via JS — desktop is completely unaffected
// Core tabs: Home / Inquiries / Messages / Listings / More
// "More" drawer shows all remaining sections in a 3-column grid
$_mob_section = $section; // current active section
$_mob_vp_url  = ( $vp && ! empty( $vp->slug ) ) ? esc_url( $_vd_primary_url ) : '';
$_mob_bname   = esc_html( $vp->business_name ?? $user->display_name );
$_mob_plan    = esc_html( $sub->plan_name ?? 'Free Plan' );
$_mob_logout  = esc_url( wp_logout_url( home_url() ) );

// Badge counts
$_mob_lead_badge = $new_leads   ? (int)$new_leads   : 0;
$_mob_msg_badge  = $unread_msg  ? (int)$unread_msg  : 0;
$_mob_rev_badge  = $pend_revs   ? (int)$pend_revs   : 0;
$_mob_q_badge    = $pend_questions ? (int)$pend_questions : 0;
?>

<!-- ══ MOBILE BOTTOM TAB BAR ════════════════════════════════════════ -->
<div id="gsvd-mob-bar" role="navigation" aria-label="Mobile navigation">
  <nav>
    <!-- Home -->
    <a href="?section=dashboard"
       class="gsmb-tab <?php echo $_mob_section==='dashboard'?'on':''; ?>"
       aria-label="Dashboard" aria-current="<?php echo $_mob_section==='dashboard'?'page':'false'; ?>">
      <span class="gsmb-tab-ico">🏠</span>
      <span>Home</span>
    </a>
    <!-- Inquiries -->
    <a href="?section=leads"
       class="gsmb-tab <?php echo $_mob_section==='leads'?'on':''; ?>"
       aria-label="Inquiries<?php echo $_mob_lead_badge?' ('.$_mob_lead_badge.' new)':''; ?>">
      <span class="gsmb-tab-ico">
        📬
        <?php if($_mob_lead_badge):?><span class="gsmb-badge"><?php echo $_mob_lead_badge;?></span><?php endif;?>
      </span>
      <span>Inquiries</span>
    </a>
    <!-- Messages -->
    <a href="?section=messages"
       class="gsmb-tab <?php echo $_mob_section==='messages'?'on':''; ?>"
       aria-label="Messages<?php echo $_mob_msg_badge?' ('.$_mob_msg_badge.' unread)':''; ?>">
      <span class="gsmb-tab-ico">
        💬
        <?php if($_mob_msg_badge):?><span class="gsmb-badge"><?php echo $_mob_msg_badge;?></span><?php endif;?>
      </span>
      <span>Messages</span>
    </a>
    <!-- Listings -->
    <a href="?section=listings"
       class="gsmb-tab <?php echo in_array($_mob_section,['listings','create','edit'])?'on':''; ?>"
       aria-label="Listings">
      <span class="gsmb-tab-ico">🏢</span>
      <span>Listings</span>
    </a>
    <!-- More -->
    <button class="gsmb-tab gsmb-tab-more" id="gsvd-mob-more-btn"
            onclick="gsVdDrawer(true)" aria-label="More sections"
            aria-expanded="false" aria-controls="gsvd-mob-drawer">
      <span class="gsmb-tab-ico" aria-hidden="true">⋯</span>
      <span>More</span>
    </button>
  </nav>
</div>

<!-- ══ MOBILE MORE DRAWER ════════════════════════════════════════════ -->
<div id="gsvd-mob-drawer" role="dialog" aria-modal="true" aria-label="All sections">
  <div id="gsvd-mob-drawer-backdrop" onclick="gsVdDrawer(false)"></div>
  <div id="gsvd-mob-drawer-sheet">

    <!-- User info header -->
    <div class="gsmd-hd">
      <div class="gsmd-hd-user">
        <div>
          <div class="gsmd-user-name"><?php echo $_mob_bname; ?></div>
          <div class="gsmd-user-plan"><?php echo $_mob_plan; ?></div>
        </div>
      </div>
      <div class="gsmd-hd-title">All Sections</div>
    </div>

    <!-- Business group -->
    <div class="gsmd-grp">Business</div>
    <div class="gsmd-grid">
      <a href="?section=profile"      class="gsmd-item <?php echo $_mob_section==='profile'?'on':'';?>">
        <span class="gsmd-item-ico">👤</span><span class="gsmd-item-lbl">Profile</span>
      </a>
      <a href="<?php echo home_url('/vendor/create/'); ?>" class="gsmd-item <?php echo in_array($_mob_section,['create','edit'])?'on':'';?>">
        <span class="gsmd-item-ico">➕</span><span class="gsmd-item-lbl">Add Listing</span>
      </a>
      <a href="?section=products"     class="gsmd-item <?php echo $_mob_section==='products'?'on':'';?>">
        <span class="gsmd-item-ico">📦</span><span class="gsmd-item-lbl">Products</span>
      </a>
      <a href="?section=services"     class="gsmd-item <?php echo $_mob_section==='services'?'on':'';?>">
        <span class="gsmd-item-ico">🛠</span><span class="gsmd-item-lbl">Services</span>
      </a>
      <?php if(gs_setting('booking_enabled','0')):?>
      <a href="?section=bookings"     class="gsmd-item <?php echo $_mob_section==='bookings'?'on':'';?>">
        <span class="gsmd-item-ico">📅</span><span class="gsmd-item-lbl">Bookings</span>
      </a>
      <?php endif;?>
      <?php if(gs_setting('reverse_req_enabled','1')):?>
      <a href="?section=requirements" class="gsmd-item <?php echo $_mob_section==='requirements'?'on':'';?>">
        <span class="gsmd-item-ico">📋</span><span class="gsmd-item-lbl">Requirements</span>
      </a>
      <?php endif;?>
      <a href="?section=reviews"      class="gsmd-item <?php echo $_mob_section==='reviews'?'on':'';?>">
        <span class="gsmd-item-ico">⭐</span>
        <span class="gsmd-item-lbl">Reviews</span>
        <?php if($_mob_rev_badge):?><span class="gsmd-item-badge"><?php echo $_mob_rev_badge;?></span><?php endif;?>
      </a>
      <a href="?section=questions"    class="gsmd-item <?php echo $_mob_section==='questions'?'on':'';?>">
        <span class="gsmd-item-ico">❓</span>
        <span class="gsmd-item-lbl">Questions</span>
        <?php if($_mob_q_badge):?><span class="gsmd-item-badge"><?php echo $_mob_q_badge;?></span><?php endif;?>
      </a>
    </div>

    <!-- Account group -->
    <div class="gsmd-grp">Account</div>
    <div class="gsmd-grid">
      <?php if($sub && $sub->show_analytics):?>
      <a href="?section=analytics"    class="gsmd-item <?php echo $_mob_section==='analytics'?'on':'';?>">
        <span class="gsmd-item-ico">📈</span><span class="gsmd-item-lbl">Analytics</span>
      </a>
      <?php endif;?>
      <a href="?section=subscription" class="gsmd-item <?php echo $_mob_section==='subscription'?'on':'';?>">
        <span class="gsmd-item-ico">💳</span><span class="gsmd-item-lbl">Subscription</span>
      </a>
      <a href="?section=invoices"     class="gsmd-item <?php echo $_mob_section==='invoices'?'on':'';?>">
        <span class="gsmd-item-ico">🧾</span><span class="gsmd-item-lbl">Invoices</span>
      </a>
      <a href="?section=verification" class="gsmd-item <?php echo $_mob_section==='verification'?'on':'';?>">
        <span class="gsmd-item-ico">✅</span><span class="gsmd-item-lbl">Verification</span>
      </a>
      <a href="?section=seo"          class="gsmd-item <?php echo $_mob_section==='seo'?'on':'';?>">
        <span class="gsmd-item-ico">🔍</span><span class="gsmd-item-lbl">SEO</span>
      </a>
      <a href="?section=notifications" class="gsmd-item <?php echo $_mob_section==='notifications'?'on':'';?>">
        <span class="gsmd-item-ico">🔔</span><span class="gsmd-item-lbl">Notifications</span>
      </a>
    </div>

    <!-- Tools group -->
    <div class="gsmd-grp">Tools</div>
    <div class="gsmd-grid">
      <a href="?section=staff"        class="gsmd-item <?php echo $_mob_section==='staff'?'on':'';?>">
        <span class="gsmd-item-ico">👥</span><span class="gsmd-item-lbl">My Team</span>
      </a>
      <a href="?section=quick_replies" class="gsmd-item <?php echo $_mob_section==='quick_replies'?'on':'';?>">
        <span class="gsmd-item-ico">⚡</span><span class="gsmd-item-lbl">Quick Replies</span>
      </a>
      <a href="?section=templates"    class="gsmd-item <?php echo $_mob_section==='templates'?'on':'';?>">
        <span class="gsmd-item-ico">📝</span><span class="gsmd-item-lbl">Templates</span>
      </a>
      <a href="?section=availability" class="gsmd-item <?php echo $_mob_section==='availability'?'on':'';?>">
        <span class="gsmd-item-ico">🗓</span><span class="gsmd-item-lbl">Availability</span>
      </a>
      <a href="?section=calendar"     class="gsmd-item <?php echo $_mob_section==='calendar'?'on':'';?>">
        <span class="gsmd-item-ico">📅</span><span class="gsmd-item-lbl">Calendar</span>
      </a>
      <a href="?section=service_plans" class="gsmd-item <?php echo $_mob_section==='service_plans'?'on':'';?>">
        <span class="gsmd-item-ico">🔄</span><span class="gsmd-item-lbl">Service Plans</span>
      </a>
      <a href="?section=promotions"   class="gsmd-item <?php echo $_mob_section==='promotions'?'on':'';?>">
        <span class="gsmd-item-ico">🎉</span><span class="gsmd-item-lbl">Promotions</span>
      </a>
      <a href="?section=whatsapp"     class="gsmd-item <?php echo $_mob_section==='whatsapp'?'on':'';?>">
        <span class="gsmd-item-ico">📱</span><span class="gsmd-item-lbl">WhatsApp</span>
      </a>
      <a href="?section=wa_analytics" class="gsmd-item <?php echo $_mob_section==='wa_analytics'?'on':'';?>">
        <span class="gsmd-item-ico">📊</span><span class="gsmd-item-lbl">WA Analytics</span>
      </a>
      <a href="?section=staff_performance" class="gsmd-item <?php echo $_mob_section==='staff_performance'?'on':'';?>">
        <span class="gsmd-item-ico">📊</span><span class="gsmd-item-lbl">Team Stats</span>
      </a>
      <a href="?section=complaints"   class="gsmd-item <?php echo $_mob_section==='complaints'?'on':'';?>">
        <span class="gsmd-item-ico">⚠</span><span class="gsmd-item-lbl">Complaints</span>
      </a>
    </div>

    <!-- Utility links -->
    <div class="gsmd-utils">
      <?php if($_mob_vp_url):?>
      <a href="<?php echo $_mob_vp_url; ?>" target="_blank" class="gsmd-util-btn vendor-page">
        🌐 <span>My Vendor Page</span>
      </a>
      <?php endif;?>
      <a href="<?php echo $_mob_logout; ?>" class="gsmd-util-btn">
        🚪 <span>Logout</span>
      </a>
    </div>

  </div>
</div>

<script>
(function(){
  // TRACE: shows/hides mobile nav components based on screen width
  //        gsVdDrawer() controls the More drawer open/close state
  //        Precondition: DOM ready, #gsvd-mob-bar and #gsvd-mob-drawer exist
  //        Edge case: drawer closed on ESC key, backdrop click, navigation

  var bar     = document.getElementById('gsvd-mob-bar');
  var drawer  = document.getElementById('gsvd-mob-drawer');
  var moreBtn = document.getElementById('gsvd-mob-more-btn');

  function isMobile(){ return window.innerWidth <= 768; }

  function showBar(){ if(bar) bar.style.display = 'block'; }
  function hideBar(){ if(bar) bar.style.display = 'none'; }

  // Show bottom bar only on mobile
  if(isMobile()){ showBar(); }
  window.addEventListener('resize', function(){
    if(isMobile()){ showBar(); } else { hideBar(); gsVdDrawer(false); }
  });

  // Drawer open/close
  window.gsVdDrawer = function(open){
    if(!drawer || !moreBtn) return;
    if(open){
      drawer.classList.add('open');
      moreBtn.classList.add('open');
      moreBtn.setAttribute('aria-expanded','true');
      document.body.style.overflow = 'hidden'; // prevent background scroll
    } else {
      drawer.classList.remove('open');
      moreBtn.classList.remove('open');
      moreBtn.setAttribute('aria-expanded','false');
      document.body.style.overflow = '';
    }
  };

  // Close on ESC key
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape') gsVdDrawer(false);
  });

  // Touch-to-swipe-down to close drawer
  var startY = 0;
  var sheet  = document.getElementById('gsvd-mob-drawer-sheet');
  if(sheet){
    sheet.addEventListener('touchstart', function(e){ startY = e.touches[0].clientY; }, {passive:true});
    sheet.addEventListener('touchend', function(e){
      if(e.changedTouches[0].clientY - startY > 60) gsVdDrawer(false);
    }, {passive:true});
  }
})();
</script>

<script>
// ── Notification bell — fetches on open, marks read on click, closes on
// outside-click/Escape. Uses gs_get_notifications (the implementation with
// working mark-read support) rather than the separate, unused
// gs_get_notification_feed endpoint.
(function(){
  var nonce   = '<?php echo esc_js( $nonce ); ?>';
  var ajaxUrl = '<?php echo esc_js( admin_url( "admin-ajax.php" ) ); ?>';
  var btn     = document.getElementById('gsvd-notif-btn');
  var panel   = document.getElementById('gsvd-notif-panel');
  var list    = document.getElementById('gsvd-notif-list');
  var markAllBtn = document.getElementById('gsvd-notif-markall');
  if (!btn || !panel) return;

  var loaded = false;

  function timeAgo(dateStr) {
    // Server sends MySQL datetime in site-local time; treat as such for the
    // relative comparison (consistent with how created_at is stored/read
    // elsewhere in this dashboard — no UTC conversion layer exists here).
    var then = new Date(dateStr.replace(' ', 'T'));
    var secs = Math.max(0, Math.floor((Date.now() - then.getTime()) / 1000));
    if (secs < 60) return 'just now';
    if (secs < 3600) return Math.floor(secs/60) + 'm ago';
    if (secs < 86400) return Math.floor(secs/3600) + 'h ago';
    if (secs < 604800) return Math.floor(secs/86400) + 'd ago';
    return then.toLocaleDateString();
  }

  function esc(s) {
    var d = document.createElement('div');
    d.textContent = s == null ? '' : String(s);
    return d.innerHTML;
  }

  function updateBadge(count) {
    var existing = btn.querySelector('.gvnb');
    if (count > 0) {
      var text = count > 99 ? '99+' : String(count);
      if (existing) {
        existing.textContent = text;
      } else {
        var span = document.createElement('span');
        span.className = 'gvnb gsvd-notif-badge';
        span.textContent = text;
        btn.appendChild(span);
      }
      btn.setAttribute('aria-label', 'Notifications (' + count + ' unread)');
    } else if (existing) {
      existing.remove();
      btn.setAttribute('aria-label', 'Notifications');
    }
  }

  function render(items) {
    if (!items.length) {
      list.innerHTML = '<div class="gsvd-notif-empty">No notifications yet.</div>';
      return;
    }
    list.innerHTML = items.map(function(n){
      var unreadCls = n.is_read == 0 ? ' unread' : '';
      var href = n.action_url ? esc(n.action_url) : '#';
      return '<a href="' + href + '" class="gsvd-notif-item' + unreadCls + '" data-id="' + n.id + '" data-read="' + n.is_read + '">'
        + '<div class="gsvd-notif-ic" style="background:' + esc(n.color || '#2563EB') + '22;color:' + esc(n.color || '#2563EB') + '">' + (n.icon === 'mail' ? '\u{1F4E8}' : n.icon === 'calendar' ? '\u{1F4C5}' : '\u{1F514}') + '</div>'
        + '<div class="gsvd-notif-body">'
          + '<div class="gsvd-notif-title">' + esc(n.title) + '</div>'
          + (n.message ? '<div class="gsvd-notif-msg">' + esc(n.message) + '</div>' : '')
          + '<div class="gsvd-notif-time">' + timeAgo(n.created_at) + '</div>'
        + '</div>'
        + (n.is_read == 0 ? '<div class="gsvd-notif-dot" aria-hidden="true"></div>' : '')
        + '</a>';
    }).join('');
  }

  function fetchNotifications() {
    list.innerHTML = '<div class="gsvd-notif-loading">Loading\u2026</div>';
    var fd = new FormData();
    fd.append('action', 'gs_get_notifications');
    fd.append('nonce', nonce);
    fetch(ajaxUrl, {method:'POST', body:fd, credentials:'same-origin'})
      .then(function(r){ return r.json(); })
      .then(function(r){
        if (r && r.success && r.data) {
          render(r.data.notifications || []);
          updateBadge(r.data.unread_count || 0);
        } else {
          list.innerHTML = '<div class="gsvd-notif-empty">Could not load notifications.</div>';
        }
      })
      .catch(function(){
        list.innerHTML = '<div class="gsvd-notif-empty">Network error \u2014 please try again.</div>';
      });
  }

  function openPanel() {
    panel.hidden = false;
    btn.setAttribute('aria-expanded', 'true');
    if (!loaded) { loaded = true; fetchNotifications(); }
    else { fetchNotifications(); } // always refresh on open — cheap, avoids showing stale state
  }
  function closePanel() {
    panel.hidden = true;
    btn.setAttribute('aria-expanded', 'false');
  }

  btn.addEventListener('click', function(e){
    e.stopPropagation();
    if (panel.hidden) openPanel(); else closePanel();
  });

  // Click a notification: mark read (fire-and-forget) + follow its link normally.
  list.addEventListener('click', function(e){
    var item = e.target.closest('.gsvd-notif-item');
    if (!item) return;
    if (item.dataset.read === '0') {
      var fd = new FormData();
      fd.append('action', 'gs_mark_notification_read');
      fd.append('nonce', nonce);
      fd.append('id', item.dataset.id);
      fetch(ajaxUrl, {method:'POST', body:fd, credentials:'same-origin'});
      item.classList.remove('unread');
      var dot = item.querySelector('.gsvd-notif-dot');
      if (dot) dot.remove();
      var current = parseInt((btn.querySelector('.gvnb')||{}).textContent || '0', 10);
      updateBadge(Math.max(0, current - 1));
    }
    // If action_url is '#' (no link set on this notification type), don't navigate away.
    if (item.getAttribute('href') === '#') { e.preventDefault(); }
  });

  if (markAllBtn) {
    markAllBtn.addEventListener('click', function(){
      var fd = new FormData();
      fd.append('action', 'gs_mark_all_notifications_read');
      fd.append('nonce', nonce);
      fetch(ajaxUrl, {method:'POST', body:fd, credentials:'same-origin'})
        .then(function(){
          list.querySelectorAll('.gsvd-notif-item.unread').forEach(function(el){
            el.classList.remove('unread');
            var dot = el.querySelector('.gsvd-notif-dot');
            if (dot) dot.remove();
          });
          updateBadge(0);
        })
        // Real fix — unlike the single-notification click above (deliberately
        // fire-and-forget, since the UI update there is optimistic and low-
        // stakes), this button's UI update only happens INSIDE the .then(),
        // so a network failure previously meant clicking "Mark all read"
        // did visibly nothing at all — no error, no update, no feedback.
        .catch(function(){
          if (typeof gsToast === 'function') { gsToast('Could not mark notifications as read — network error.', 'error'); }
        });
    });
  }

  document.addEventListener('click', function(e){
    if (!panel.hidden && !panel.contains(e.target) && e.target !== btn) closePanel();
  });
  document.addEventListener('keydown', function(e){
    if (e.key === 'Escape' && !panel.hidden) closePanel();
  });
})();
</script>

