<?php
/**
 * ═══════════════════════════════════════════════════════════════════════
 * ═══════════════════════════════════════════════════════════════════════
 * ██   ⚠️⚠️⚠️  STOP — READ THIS BEFORE TOUCHING THIS FILE  ⚠️⚠️⚠️   ██
 * ═══════════════════════════════════════════════════════════════════════
 * ═══════════════════════════════════════════════════════════════════════
 *
 *   THIS FILE IS **NOT** USED FOR ANYTHING RELATED TO THE VENDOR SITE.
 *   NOT FOR ANY VENDOR-FACING FEATURE. NOT FOR ANY REASON. AT ALL.
 *
 * - This is NOT the Vendor Listing Page Builder. It is NOT reachable by
 *   any vendor, anywhere, under any circumstance. Confirmed by grepping
 *   the entire codebase: this file is required from exactly ONE place —
 *   templates/pages/admin-dashboard.php, inside the ADMIN's own Listings
 *   section (section=listings&view=ID) — and nowhere else. It is not
 *   linked from vendor-dashboard.php, not routed from Router.php's
 *   vendor routes. A logged-in vendor cannot reach this page.
 * - The vendor-side entry point that used to point here has been
 *   deliberately REMOVED and now just redirects away — see
 *   vendor-dashboard.php, case 'page-builder', which literally says:
 *   "the Page Builder was NOT the actual listing editor ... The real
 *   Vendor Listing builder is create-listing.php."
 * - The one place this file IS reached (an admin editing a listing),
 *   admins bypass plan-limit/quota enforcement entirely — see
 *   AjaxController::uploadMedia(), "admins bypass this check" — so
 *   quota/limit logic added here has ZERO effect even in that one path.
 * - The real, actively-used Vendor Listing builder — content, gallery,
 *   products, services, images, quota, everything — is
 *   templates/pages/create-listing.php. That is the ONLY correct file
 *   for any Vendor Listing–related work.
 *
 * KNOWN INCIDENT: an AI assistant already edited this file's upload
 * logic (twice) believing it was vendor-facing, before reading this
 * notice. That work had zero real effect (unreachable by vendors, and
 * moot even for admins per the quota bypass above) and was reverted.
 * Read this notice FIRST — before grepping, before editing, before
 * assuming anything about what this file does or who uses it.
 *
 * ANY DEVELOPER OR AI ASSISTANT working on Vendor Listing features,
 * fixes, image/quota logic, or analysis of any kind should IGNORE THIS
 * FILE ENTIRELY and treat create-listing.php as the sole authoritative
 * Vendor Listing builder.
 *
 * Do not reference, modify, or reason about this file in the context
 * of Vendor Listing debugging, development, image counting, subscription
 * plan logic, or SEO/scoring features — unless there is an explicit,
 * stated requirement to work on THIS specific file — e.g. a task that
 * names "listing-page-builder.php" or "the Admin's listing page builder"
 * directly.
 *
 * (The docblock below, inherited from this file's original
 * implementation, claims every section here "maps 1-to-1 to the
 * vendor-site.php front end" — that claim is outdated/inaccurate
 * given the current architecture and should not be relied on.)
 * ═══════════════════════════════════════════════════════════════════════
 * ═══════════════════════════════════════════════════════════════════════
 */

/**
 * Listing Page Builder — GoodService Platform
 * Dynamic microsite builder form for vendors/admins.
 * Every section maps 1-to-1 to the vendor-site.php front end.
 *
 * Accessed at: /vendor/dashboard/?section=page-builder&listing_id=N
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! is_user_logged_in() || ( ! gs_is_vendor() && ! gs_is_admin_level() ) ) {
    wp_redirect( home_url( '/vendor/login/' ) ); exit;
}
$lpb_is_admin = gs_is_admin_level();

global $wpdb;
$pfx        = $wpdb->prefix . 'gs_';
$user       = wp_get_current_user();
$listing_id = intval( $_GET['listing_id'] ?? 0 );

if ( ! $listing_id ) {
    echo '<div style="padding:40px;text-align:center;color:#DC2626">Invalid listing ID.</div>';
    return;
}

// Admin can edit any listing; vendor only their own
if ( $lpb_is_admin ) {
    $listing = $wpdb->get_row( $wpdb->prepare(
        "SELECT l.*, vp.slug AS vendor_slug, vp.id AS vendor_prof_id FROM {$pfx}listings l
         LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
         WHERE l.id = %d",
        $listing_id
    ) );
} else {
    $listing = $wpdb->get_row( $wpdb->prepare(
        "SELECT l.*, vp.slug AS vendor_slug, vp.id AS vendor_prof_id FROM {$pfx}listings l
         LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
         WHERE l.id=%d AND l.vendor_id=(SELECT id FROM {$pfx}vendor_profiles WHERE user_id=%d LIMIT 1)",
        $listing_id, $user->ID
    ) );
}

if ( ! $listing ) {
    if ( $lpb_is_admin ) {
        wp_redirect( home_url( '/admin-panel/?section=listings' ) );
    } else {
        wp_redirect( home_url( '/vendor/dashboard/?section=listings' ) );
    }
    exit;
}

// Decode JSON fields
foreach ( [ 'hero_data', 'about_data', 'items_data', 'feedback_data', 'footer_data',
             'services_data', 'products_data', 'process_data', 'faq_data', 'why_choose_data', 'stats_data',
             'customizer_data', 'mobile_data' ] as $f ) {
    $listing->$f = json_decode( $listing->$f ?? '[]', true ) ?: [];
}

if ( ! function_exists( 'lpb_val' ) ) {
function lpb_val( $listing, $field, $default = '' ) {
    return isset( $listing->$field ) ? $listing->$field : $default;
}
}
if ( ! function_exists( 'lpb_json' ) ) {
function lpb_json( $arr, $default = '[]' ) {
    if ( empty( $arr ) ) return $default;
    return htmlspecialchars( json_encode( $arr ), ENT_QUOTES );
}
}
if ( ! function_exists( 'lpb_cd' ) ) {
// Read from customizer_data (styling controls saved by page builder)
function lpb_cd( $listing, $key, $default = '' ) {
    $cd = json_decode( $listing->customizer_data ?? '', true ) ?: [];
    return is_array($cd) ? ($cd[$key] ?? $default) : $default;
}
}

if ( ! function_exists( 'lpb_image_style_fields' ) ) {
/**
 * Renders the shared Image Fit / Image Position / Border / Box-Shadow control
 * set. Used identically by the Gallery (gallery_img_*), Products
 * (items_img_*) and Services (svc_img_*) styling panels so all three offer
 * the same level of image styling flexibility from one implementation,
 * instead of three hand-duplicated copies. Border Radius is intentionally
 * NOT included here — each section already has its own radius field
 * (gallery_radius / items_img_box_radius / svc_img_radius) which continues
 * to be used unchanged, avoiding a duplicate control.
 *
 * @param object $listing The listing being edited.
 * @param string $prefix  Field-name prefix, e.g. 'gallery_img', 'items_img', 'svc_img'.
 * @param string $default_fit Default object-fit value for this section ('cover' or 'contain').
 */
function lpb_image_style_fields( $listing, $prefix, $default_fit = 'cover' ) {
    $fit_opts = [
        'cover'      => 'Cover (fill box, crop)',
        'contain'    => 'Contain (show full, letterboxed)',
        'fill'       => 'Fill (stretch to box)',
        'scale-down' => 'Scale Down (contain or original, whichever is smaller)',
        'none'       => 'None (original size, no resizing)',
    ];
    $pos_opts = [
        'center'       => 'Center',
        'top'          => 'Top',
        'bottom'       => 'Bottom',
        'left'         => 'Left',
        'right'        => 'Right',
        'top left'     => 'Top Left',
        'top right'    => 'Top Right',
        'bottom left'  => 'Bottom Left',
        'bottom right' => 'Bottom Right',
    ];
    $style_opts = [
        'solid'  => 'Solid',
        'dashed' => 'Dashed',
        'dotted' => 'Dotted',
        'double' => 'Double',
        'none'   => 'None',
    ];
    ?>
    <div class="lpb-grid-2" style="margin-bottom:12px">
      <div class="lpb-field" style="margin:0">
        <label class="lpb-label">Image Fit</label>
        <select class="lpb-select lpb-cd-field" data-cd="<?php echo esc_attr($prefix); ?>_fit">
          <?php foreach ($fit_opts as $fv => $fl): ?>
          <option value="<?php echo esc_attr($fv); ?>" <?php selected(lpb_cd($listing,"{$prefix}_fit",$default_fit),$fv); ?>><?php echo esc_html($fl); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="lpb-field" style="margin:0">
        <label class="lpb-label">Image Position</label>
        <select class="lpb-select lpb-cd-field" data-cd="<?php echo esc_attr($prefix); ?>_position">
          <?php foreach ($pos_opts as $pv => $pl): ?>
          <option value="<?php echo esc_attr($pv); ?>" <?php selected(lpb_cd($listing,"{$prefix}_position",'center'),$pv); ?>><?php echo esc_html($pl); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <div class="lpb-design-group-title" style="margin-top:16px">▭ Image Border</div>
    <div class="lpb-grid-3" style="margin-bottom:12px">
      <div class="lpb-field" style="margin:0">
        <label class="lpb-label">Border Width (px)</label>
        <input type="number" class="lpb-input lpb-cd-field" data-cd="<?php echo esc_attr($prefix); ?>_border_width" value="<?php echo esc_attr(lpb_cd($listing,"{$prefix}_border_width",'0')); ?>" min="0" max="20" placeholder="0">
      </div>
      <div class="lpb-field" style="margin:0">
        <label class="lpb-label">Border Style</label>
        <select class="lpb-select lpb-cd-field" data-cd="<?php echo esc_attr($prefix); ?>_border_style">
          <?php foreach ($style_opts as $sv => $sl): ?>
          <option value="<?php echo esc_attr($sv); ?>" <?php selected(lpb_cd($listing,"{$prefix}_border_style",'solid'),$sv); ?>><?php echo esc_html($sl); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="lpb-field" style="margin:0">
        <label class="lpb-label">Border Color</label>
        <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-<?php echo esc_attr($prefix); ?>_border_color" value="<?php echo esc_attr(lpb_cd($listing,"{$prefix}_border_color",'#E2E8F0')); ?>"></div>
        <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="<?php echo esc_attr($prefix); ?>_border_color" id="lpb-cd-<?php echo esc_attr($prefix); ?>_border_color_text" value="<?php echo esc_attr(lpb_cd($listing,"{$prefix}_border_color",'#E2E8F0')); ?>" maxlength="7" placeholder="#E2E8F0"></div>
      </div>
    </div>

    <div class="lpb-design-group-title" style="margin-top:16px">🌗 Image Shadow <span style="font-size:.72rem;color:#94A3B8;font-weight:400">(opacity 0 = no shadow)</span></div>
    <div class="lpb-grid-2" style="margin-bottom:12px">
      <div class="lpb-field" style="margin:0">
        <label class="lpb-label">Shadow Color</label>
        <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-<?php echo esc_attr($prefix); ?>_shadow_color" value="<?php echo esc_attr(lpb_cd($listing,"{$prefix}_shadow_color",'#000000')); ?>"></div>
        <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="<?php echo esc_attr($prefix); ?>_shadow_color" id="lpb-cd-<?php echo esc_attr($prefix); ?>_shadow_color_text" value="<?php echo esc_attr(lpb_cd($listing,"{$prefix}_shadow_color",'#000000')); ?>" maxlength="7" placeholder="#000000"></div>
      </div>
      <div class="lpb-field" style="margin:0">
        <label class="lpb-label">Opacity (%)</label>
        <input type="number" class="lpb-input lpb-cd-field" data-cd="<?php echo esc_attr($prefix); ?>_shadow_opacity" value="<?php echo esc_attr(lpb_cd($listing,"{$prefix}_shadow_opacity",'0')); ?>" min="0" max="100" placeholder="0">
      </div>
    </div>
    <div class="lpb-grid-4" style="margin-bottom:0;display:grid;grid-template-columns:repeat(4,1fr);gap:10px">
      <div class="lpb-field" style="margin:0">
        <label class="lpb-label" style="font-size:.7rem">H Offset (px)</label>
        <input type="number" class="lpb-input lpb-cd-field" data-cd="<?php echo esc_attr($prefix); ?>_shadow_h" value="<?php echo esc_attr(lpb_cd($listing,"{$prefix}_shadow_h",'0')); ?>" min="-200" max="200" placeholder="0">
      </div>
      <div class="lpb-field" style="margin:0">
        <label class="lpb-label" style="font-size:.7rem">V Offset (px)</label>
        <input type="number" class="lpb-input lpb-cd-field" data-cd="<?php echo esc_attr($prefix); ?>_shadow_v" value="<?php echo esc_attr(lpb_cd($listing,"{$prefix}_shadow_v",'4')); ?>" min="-200" max="200" placeholder="4">
      </div>
      <div class="lpb-field" style="margin:0">
        <label class="lpb-label" style="font-size:.7rem">Blur Radius (px)</label>
        <input type="number" class="lpb-input lpb-cd-field" data-cd="<?php echo esc_attr($prefix); ?>_shadow_blur" value="<?php echo esc_attr(lpb_cd($listing,"{$prefix}_shadow_blur",'12')); ?>" min="0" max="200" placeholder="12">
      </div>
      <div class="lpb-field" style="margin:0">
        <label class="lpb-label" style="font-size:.7rem">Spread Radius (px)</label>
        <input type="number" class="lpb-input lpb-cd-field" data-cd="<?php echo esc_attr($prefix); ?>_shadow_spread" value="<?php echo esc_attr(lpb_cd($listing,"{$prefix}_shadow_spread",'0')); ?>" min="-100" max="100" placeholder="0">
      </div>
    </div>
    <?php
}
}

// Preview URL uses the listing's own slug (canonical clean URL — no /v/ prefix)
$preview_url = ! empty( $listing->slug )
    ? home_url( '/' . $listing->slug . '/' )
    : '#';
?>
<div class="gs-root lpb-root" style="background:#F0F4F8;min-height:100vh;font-family:var(--gs-font,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif)">

<style>
/* ── Page Builder Styles ───────────────────────────────────── */
.lpb-topbar{background:#1E3A5F;height:56px;display:flex;align-items:center;justify-content:space-between;padding:0 24px;position:sticky;top:0;z-index:200}
.lpb-topbar-title{color:#fff;font-weight:700;font-size:.95rem;display:flex;align-items:center;gap:10px}
.lpb-topbar-actions{display:flex;align-items:center;gap:8px}
.lpb-layout{display:grid;grid-template-columns:220px 1fr;min-height:calc(100vh - 56px)}
.lpb-sidebar{background:#fff;border-right:1px solid #E2E8F0;padding:16px 0;position:sticky;top:56px;height:calc(100vh - 56px);overflow-y:auto}
.lpb-sidebar-item{display:flex;align-items:center;gap:10px;padding:11px 18px;font-size:.85rem;font-weight:500;color:#475569;cursor:pointer;border-left:3px solid transparent;transition:all .15s}
.lpb-sidebar-item:hover{background:#F8FAFC;color:#1E3A5F}
.lpb-sidebar-item.active{background:#EFF6FF;color:#2563EB;border-left-color:#2563EB;font-weight:600}
.lpb-sidebar-item .lpb-icon{font-size:1rem;width:20px;text-align:center}
.lpb-main{padding:24px;overflow-y:auto;max-height:calc(100vh - 56px)}
.lpb-section{background:#fff;border-radius:16px;border:1px solid #E2E8F0;margin-bottom:20px;display:none}
.lpb-section.active{display:block}
.lpb-section-head{padding:20px 24px 0;display:flex;align-items:center;gap:12px;border-bottom:1px solid #F1F5F9;padding-bottom:16px;margin-bottom:24px}
.lpb-section-icon{font-size:1.4rem}
.lpb-section-title{font-size:1rem;font-weight:700;color:#1E3A5F}
.lpb-section-sub{font-size:.78rem;color:#64748B;margin-top:2px}
.lpb-body{padding:0 24px 24px}
.lpb-field{margin-bottom:18px}
.lpb-label{display:block;font-size:.78rem;font-weight:700;color:#374151;margin-bottom:5px;text-transform:uppercase;letter-spacing:.04em}
.lpb-hint{font-size:.73rem;color:#94A3B8;margin-top:3px}
.lpb-input,.lpb-textarea,.lpb-select{width:100%;padding:9px 12px;border:1.5px solid #E2E8F0;border-radius:8px;font-size:.88rem;color:#1E293B;background:#fff;outline:none;transition:border .2s;box-sizing:border-box}
.lpb-input:focus,.lpb-textarea:focus,.lpb-select:focus{border-color:#2563EB}
.lpb-textarea{resize:vertical;min-height:80px;line-height:1.6}
.lpb-grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.lpb-grid-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}
/* Repeater */
.lpb-repeater{border:1px solid #E2E8F0;border-radius:12px;overflow:hidden}
.lpb-repeater-item{border-bottom:1px solid #F1F5F9;padding:16px}
.lpb-repeater-item:last-child{border-bottom:none}
.lpb-repeater-item-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.lpb-repeater-item-label{font-size:.8rem;font-weight:700;color:#64748B}
.lpb-repeater-footer{padding:12px 16px;background:#F8FAFC;display:flex;justify-content:center}
.lpb-btn{display:inline-flex;align-items:center;gap:6px;padding:8px 18px;border-radius:8px;font-size:.85rem;font-weight:600;cursor:pointer;border:none;transition:all .2s}
.lpb-btn-primary{background:#2563EB;color:#fff}
.lpb-btn-primary:hover{background:#1D4ED8}
.lpb-btn-ghost{background:#F1F5F9;color:#374151;border:1px solid #E2E8F0}
.lpb-btn-ghost:hover{background:#E2E8F0}
.lpb-btn-danger{background:#FEF2F2;color:#DC2626;border:1px solid #FECACA}
.lpb-btn-danger:hover{background:#FEE2E2}
.lpb-btn-sm{padding:5px 12px;font-size:.78rem}
.lpb-btn-save{background:#059669;color:#fff;padding:9px 24px}
.lpb-btn-save:hover{background:#047857}
/* Toggle */
.lpb-toggle{display:flex;align-items:center;gap:10px;cursor:pointer}
.lpb-toggle-track{width:40px;height:22px;border-radius:99px;background:#CBD5E1;position:relative;transition:background .2s}
.lpb-toggle-track.on{background:#2563EB}
.lpb-toggle-thumb{position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:left .2s}
.lpb-toggle-track.on .lpb-toggle-thumb{left:21px}
/* Upload */
.lpb-upload-zone{border:2px dashed #CBD5E1;border-radius:10px;padding:18px;text-align:center;cursor:pointer;transition:all .2s;background:#F8FAFC;position:relative}
.lpb-upload-zone:hover,.lpb-upload-zone.lpb-dragover{border-color:#2563EB;background:#EFF6FF;border-style:solid}
.lpb-upload-zone.lpb-dragover{background:#DBEAFE;transform:scale(1.01)}
.lpb-upload-zone-text{font-size:.82rem;color:#64748B;margin-top:6px}
.lpb-drop-hint{font-size:.72rem;color:#94A3B8;margin-top:3px}
.lpb-img-preview{width:80px;height:60px;object-fit:cover;border-radius:8px;border:1px solid #E2E8F0;margin-top:6px}
/* Save bar */
.lpb-save-bar{background:#fff;border-top:1px solid #E2E8F0;padding:12px 24px;display:flex;align-items:center;justify-content:space-between;position:sticky;bottom:0;z-index:100}
.lpb-save-status{font-size:.82rem;color:#64748B}
/* Color picker */
.lpb-color-row{display:flex;align-items:center;gap:8px}
.lpb-color-swatch{width:36px;height:36px;border-radius:8px;border:1.5px solid #CBD5E1;cursor:pointer;overflow:hidden;flex-shrink:0}
.lpb-color-swatch input[type=color]{width:50px;height:50px;margin:-7px;border:none;cursor:pointer}
.lpb-color-hex{font-family:'Courier New',monospace;font-size:.82rem!important;flex:1;min-width:80px}
.lpb-design-group-title{font-size:.76rem;font-weight:800;color:#1E293B;letter-spacing:.05em;text-transform:uppercase;margin:0 0 14px;padding:8px 0 8px;border-bottom:2px solid #E2E8F0;display:flex;align-items:center;gap:6px}
/* Item type badge */
.lpb-type-badge{display:inline-flex;align-items:center;gap:4px;padding:2px 10px;border-radius:99px;font-size:.72rem;font-weight:700}
.lpb-type-service{background:#EFF6FF;color:#2563EB}
.lpb-type-product{background:#F0FDF4;color:#059669}
/* Section divider */
.lpb-divider{height:1px;background:#F1F5F9;margin:20px 0}
@media(max-width:768px){
  .lpb-layout{grid-template-columns:1fr}
  .lpb-sidebar{display:none}
  .lpb-grid-2,.lpb-grid-3{grid-template-columns:1fr}
}
</style>

<!-- Top Bar -->
<?php if ( $lpb_is_admin ): ?>
<div style="background:linear-gradient(90deg,#7C3AED,#4F46E5);padding:8px 24px;display:flex;align-items:center;gap:12px;font-size:.8rem;color:rgba(255,255,255,.9)">
  <span>⚙️ <strong>Admin Mode</strong> — Editing listing for vendor</span>
  <a href="<?php echo home_url('/admin-panel/?section=listings'); ?>" style="background:rgba(255,255,255,.2);border:1px solid rgba(255,255,255,.3);color:#fff;border-radius:6px;padding:4px 12px;font-size:.75rem;font-weight:700;text-decoration:none;margin-left:auto">← Back to Admin Listings</a>
  <a href="<?php echo esc_url($preview_url); ?>" target="_blank" style="background:rgba(255,255,255,.2);border:1px solid rgba(255,255,255,.3);color:#fff;border-radius:6px;padding:4px 12px;font-size:.75rem;font-weight:700;text-decoration:none">👁 Preview Site</a>
</div>
<?php endif; ?>
<div class="lpb-topbar">
  <div class="lpb-topbar-title">
    <span>🎨</span>
    <span>Listing Page Builder</span>
    <span style="background:rgba(255,255,255,.1);padding:2px 10px;border-radius:99px;font-size:.75rem;font-weight:500"><?php echo esc_html( $listing->title ); ?></span>
    <?php if ( $lpb_is_admin ): ?>
      <span style="background:#7C3AED;padding:2px 10px;border-radius:99px;font-size:.72rem;font-weight:700">ADMIN</span>
    <?php endif; ?>
  </div>
  <div class="lpb-topbar-actions">
    <span id="lpb-save-indicator" style="font-size:.78rem;color:rgba(255,255,255,.5)"></span>
    <a href="<?php echo esc_url( $preview_url ); ?>" target="_blank" class="lpb-btn lpb-btn-ghost lpb-btn-sm">👁 Preview</a>
    <?php if ( $lpb_is_admin ): ?>
      <a href="<?php echo home_url('/admin-panel/?section=listings'); ?>" class="lpb-btn lpb-btn-ghost lpb-btn-sm">← Admin</a>
    <?php else: ?>
      <a href="<?php echo home_url('/vendor/dashboard/?section=listings'); ?>" class="lpb-btn lpb-btn-ghost lpb-btn-sm">← Back</a>
    <?php endif; ?>
    <button onclick="lpbSave()" class="lpb-btn lpb-btn-save">💾 Save Changes</button>
  </div>
</div>

<input type="hidden" id="lpb-listing-id" value="<?php echo $listing_id; ?>">

<div class="lpb-layout">

  <!-- Sidebar Navigation -->
  <div class="lpb-sidebar">
    <?php
    $sections = [
      'branding'  => [ '🎨', 'Branding & Colors',     'Logo, colors, header' ],
      'hero'      => [ '🖼', 'Hero Section',           'Headline & CTA' ],
      'trustbar'  => [ '📢', 'Trust Bar',              'Scrolling marquee strip' ],
      'about'     => [ 'ℹ️', 'About / Intro',         'Company description' ],
      'services-cat' => [ '🗂', 'Services Category',  'Category grid' ],
      'process'   => [ '⚙️', 'How It Works',          'Step-by-step process' ],
      'items'     => [ '📦', 'Services & Products',   'Main listing cards' ],
      'gallery'   => [ '🖼',  'Photo Gallery',         'Shop, interior, exterior photos' ],
      'stats'     => [ '📊', 'Stats / Achievements',  'Numbers & milestones' ],
      'why'       => [ '✅', 'Why Choose Us',         'Benefits & USPs' ],
      'faq'       => [ '❓', 'FAQ',                   'Accordion questions' ],
      'contact'   => [ '📍', 'Contact',               'Address, map & form' ],
      'feedback'  => [ '⭐', 'Feedback',              'Review submission' ],
      'footer'    => [ '🦶', 'Footer',                'Links & newsletter' ],
      'mobile'    => [ '📱', 'Mobile Settings',       'Right-side nav & mobile toggles' ],
    ];
    foreach ( $sections as $id => [ $icon, $label, $hint ] ):
    ?>
    <div class="lpb-sidebar-item <?php echo $id === 'branding' ? 'active' : ''; ?>" data-section="<?php echo esc_attr($id); ?>" onclick="lpbActivate('<?php echo esc_js($id); ?>')">
      <span class="lpb-icon"><?php echo $icon; ?></span>
      <div>
        <div><?php echo esc_html($label); ?></div>
        <div style="font-size:.72rem;color:#94A3B8;margin-top:1px"><?php echo esc_html($hint); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Main Content -->
  <div class="lpb-main">

    <!-- ══ BRANDING ══════════════════════════════════════════════════ -->
    <div class="lpb-section active" id="lpb-sec-branding">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">🎨</div>
        <div>
          <div class="lpb-section-title">Branding & Colors</div>
          <div class="lpb-section-sub">Full design control — colors, images, spacing, borders, shadows</div>
        </div>
      </div>
      <div class="lpb-body">

        <!-- ── LISTING IDENTITY (title + slug) ──────────────────────── -->
        <div class="lpb-design-group-title">🏷 Listing Identity</div>
        <div class="lpb-field">
          <label class="lpb-label">Listing / Business Name</label>
          <input type="text" class="lpb-input" id="lpb-title"
                 value="<?php echo esc_attr( lpb_val($listing,'title','') ); ?>"
                 placeholder="e.g. Kaagzaat Document Services" maxlength="255"
                 oninput="lpbSlugSyncFromTitle(this.value)">
          <?php if ( $listing && $listing->title === 'Untitled Listing' ): ?>
          <div style="margin-top:6px;padding:8px 12px;background:#FEF9C3;border:1px solid #FDE047;border-radius:8px;font-size:.8rem;color:#854D0E">
            ⚠️ This listing is named <strong>Untitled Listing</strong>. Update the name above and save.
          </div>
          <?php endif; ?>
          <div class="lpb-hint">The primary brand name shown in the header and throughout the microsite.</div>
        </div>
        <div class="lpb-field">
          <label class="lpb-label">URL Slug</label>
          <div style="display:flex;align-items:center;gap:8px">
            <span style="font-size:.78rem;color:#64748B;white-space:nowrap"><?php echo esc_html(home_url('/')); ?></span>
            <input type="text" class="lpb-input" id="lpb-slug" style="flex:1"
                   value="<?php echo esc_attr( lpb_val($listing,'slug','') ); ?>"
                   placeholder="business-name" maxlength="200"
                   oninput="this.value=this.value.toLowerCase().replace(/[^a-z0-9-]/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'')">
            <button type="button" class="lpb-btn" style="font-size:.75rem;padding:5px 10px;white-space:nowrap"
                    onclick="lpbSlugFromTitle()">↺ From title</button>
          </div>
          <div class="lpb-hint">URL path for this listing. Only lowercase, numbers, hyphens. <strong>Changing breaks saved links.</strong></div>
        </div>

        <!-- ── COLOR PALETTE ─────────────────────────────────── -->
        <div class="lpb-design-group-title">🎨 Brand Color Palette</div>
        <div class="lpb-grid-2">
          <?php
          $color_fields = [
            ['id'=>'brand_color',  'label'=>'Primary Color',      'default'=>'#2563EB', 'hint'=>'Buttons, accents, headings'],
            ['id'=>'brand_color2', 'label'=>'Secondary / Dark',   'default'=>'#1E3A5F', 'hint'=>'Dark sections, hero background'],
          ];
          foreach($color_fields as $cf):
            $val = esc_attr(lpb_val($listing,$cf['id'],$cf['default']));
          ?>
          <div class="lpb-field">
            <label class="lpb-label"><?php echo esc_html($cf['label']); ?></label>
            <div class="lpb-color-row">
              <div class="lpb-color-swatch"><input type="color" id="lpb-<?php echo $cf['id']; ?>" value="<?php echo $val; ?>"></div>
              <input type="text" class="lpb-input lpb-color-hex" id="lpb-<?php echo $cf['id']; ?>_text" value="<?php echo $val; ?>" placeholder="<?php echo esc_attr($cf['default']); ?>" maxlength="7">
            </div>
            <div class="lpb-hint"><?php echo esc_html($cf['hint']); ?></div>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- More colors -->
        <details style="margin-bottom:16px">
          <summary style="cursor:pointer;font-size:.8rem;font-weight:700;color:#64748B;padding:8px 0;list-style:none;display:flex;align-items:center;gap:6px">
            <span>▶</span> Advanced Colors (Button, Text, Background)
          </summary>
          <div style="margin-top:12px">
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field">
                <label class="lpb-label">Gold / Accent Color</label>
                <div class="lpb-color-row">
                  <div class="lpb-color-swatch"><input type="color" id="lpb-accent_color" value="<?php echo esc_attr(lpb_val($listing,'accent_color','#F5A623')); ?>"></div>
                  <input type="text" class="lpb-input lpb-color-hex" id="lpb-accent_color_text" value="<?php echo esc_attr(lpb_val($listing,'accent_color','#F5A623')); ?>" maxlength="7" placeholder="#F5A623">
                </div>
                <div class="lpb-hint">Trust bar, highlights, CTA accents</div>
              </div>
              <div class="lpb-field">
                <label class="lpb-label">Section Background</label>
                <div class="lpb-color-row">
                  <div class="lpb-color-swatch"><input type="color" id="lpb-section_bg" value="<?php echo esc_attr(lpb_val($listing,'section_bg','#F8FAFC')); ?>"></div>
                  <input type="text" class="lpb-input lpb-color-hex" id="lpb-section_bg_text" value="<?php echo esc_attr(lpb_val($listing,'section_bg','#F8FAFC')); ?>" maxlength="7" placeholder="#F8FAFC">
                </div>
                <div class="lpb-hint">Alt section background color</div>
              </div>
            </div>
            <div class="lpb-grid-2">
              <div class="lpb-field">
                <label class="lpb-label">Body Text Color</label>
                <div class="lpb-color-row">
                  <div class="lpb-color-swatch"><input type="color" id="lpb-text_color" value="<?php echo esc_attr(lpb_val($listing,'text_color','#1E293B')); ?>"></div>
                  <input type="text" class="lpb-input lpb-color-hex" id="lpb-text_color_text" value="<?php echo esc_attr(lpb_val($listing,'text_color','#1E293B')); ?>" maxlength="7" placeholder="#1E293B">
                </div>
              </div>
              <div class="lpb-field">
                <label class="lpb-label">Muted / Description Text</label>
                <div class="lpb-color-row">
                  <div class="lpb-color-swatch"><input type="color" id="lpb-muted_color" value="<?php echo esc_attr(lpb_val($listing,'muted_color','#64748B')); ?>"></div>
                  <input type="text" class="lpb-input lpb-color-hex" id="lpb-muted_color_text" value="<?php echo esc_attr(lpb_val($listing,'muted_color','#64748B')); ?>" maxlength="7" placeholder="#64748B">
                </div>
              </div>
            </div>
          </div>
        </details>

        <div class="lpb-divider"></div>

        <!-- ── LOGO & BANNER ─────────────────────────────────── -->
        <div class="lpb-design-group-title">🖼 Logo & Banner</div>
        <div class="lpb-grid-2">
          <div class="lpb-field">
            <label class="lpb-label">Business Logo</label>
            <div class="lpb-upload-zone" onclick="lpbUpload('logo_url','lpb-logo-preview','image')" id="lpb-logo-zone">
              <?php if($listing->logo_url): ?>
                <img src="<?php echo esc_url($listing->logo_url); ?>" style="width:100%;max-height:80px;object-fit:contain;border-radius:6px">
                <div style="font-size:.72rem;color:#059669;margin-top:4px">✅ Click to replace</div>
              <?php else: ?>
                <div>📤</div><div class="lpb-upload-zone-text">Click to upload logo (square, PNG/WebP)</div>
              <?php endif; ?>
            </div>
            <img src="<?php echo esc_url($listing->logo_url ?? ''); ?>" class="lpb-img-preview" id="lpb-logo-preview" style="<?php echo $listing->logo_url ? 'display:block' : 'display:none'; ?>">
            <input type="hidden" id="lpb-logo_url" value="<?php echo esc_attr($listing->logo_url ?? ''); ?>">
          </div>
          <div class="lpb-field">
            <label class="lpb-label">Cover / Banner Image</label>
            <div class="lpb-upload-zone" onclick="lpbUpload('banner_url','lpb-banner-preview','image')" id="lpb-banner-zone">
              <?php if($listing->banner_url): ?>
                <img src="<?php echo esc_url($listing->banner_url); ?>" style="width:100%;max-height:80px;object-fit:cover;border-radius:6px">
                <div style="font-size:.72rem;color:#059669;margin-top:4px">✅ Click to replace</div>
              <?php else: ?>
                <div>📤</div><div class="lpb-upload-zone-text">Click to upload banner (1200×400px)</div>
              <?php endif; ?>
            </div>
            <img src="<?php echo esc_url($listing->banner_url ?? ''); ?>" class="lpb-img-preview" id="lpb-banner-preview" style="<?php echo $listing->banner_url ? 'display:block;width:100%' : 'display:none'; ?>">
            <input type="hidden" id="lpb-banner_url" value="<?php echo esc_attr($listing->banner_url ?? ''); ?>">
          </div>
        </div>

        <!-- ── IMAGE STYLE CONTROLS (Elementor-style) ─────────── -->
        <details style="margin-bottom:16px">
          <summary style="cursor:pointer;font-size:.8rem;font-weight:700;color:#64748B;padding:8px 0;list-style:none;display:flex;align-items:center;gap:6px">
            <span>▶</span> Image Style Controls (Padding, Border, Radius, Shadow, Background)
          </summary>
          <div style="margin-top:12px;background:#F8FAFC;border-radius:10px;padding:16px">
            <div style="font-size:.78rem;font-weight:700;color:#475569;margin-bottom:12px">Logo Styling</div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label">Border Radius</label>
                <div style="display:flex;gap:6px;align-items:center">
                  <input type="range" id="lpb-logo_radius" min="0" max="50" value="<?php echo esc_attr(lpb_val($listing,'logo_radius','10')); ?>" oninput="document.getElementById('lpb-logo_radius_val').textContent=this.value+'px'" style="flex:1">
                  <span id="lpb-logo_radius_val" style="font-size:.78rem;color:#64748B;width:40px"><?php echo esc_html(lpb_val($listing,'logo_radius','10')); ?>px</span>
                </div>
              </div>
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label">Box Shadow</label>
                <select class="lpb-select" id="lpb-logo_shadow">
                  <option value="none" <?php selected(lpb_val($listing,'logo_shadow','none'),'none'); ?>>None</option>
                  <option value="sm" <?php selected(lpb_val($listing,'logo_shadow','none'),'sm'); ?>>Small</option>
                  <option value="md" <?php selected(lpb_val($listing,'logo_shadow','none'),'md'); ?>>Medium</option>
                  <option value="lg" <?php selected(lpb_val($listing,'logo_shadow','none'),'lg'); ?>>Large</option>
                  <option value="xl" <?php selected(lpb_val($listing,'logo_shadow','none'),'xl'); ?>>Extra Large</option>
                </select>
              </div>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:16px">
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label">Border Width (px)</label>
                <input type="number" class="lpb-input" id="lpb-logo_border_w" value="<?php echo esc_attr(lpb_val($listing,'logo_border_w','0')); ?>" min="0" max="10" placeholder="0">
              </div>
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label">Border Color</label>
                <div class="lpb-color-row">
                  <div class="lpb-color-swatch"><input type="color" id="lpb-logo_border_c" value="<?php echo esc_attr(lpb_val($listing,'logo_border_c','#E2E8F0')); ?>"></div>
                  <input type="text" class="lpb-input lpb-color-hex" id="lpb-logo_border_c_text" value="<?php echo esc_attr(lpb_val($listing,'logo_border_c','#E2E8F0')); ?>" maxlength="7" placeholder="#E2E8F0">
                </div>
              </div>
            </div>
            <div style="font-size:.78rem;font-weight:700;color:#475569;margin-bottom:12px">Logo &amp; Banner Padding (px)</div>
            <div class="lpb-grid-2">
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label">Logo Container Padding</label>
                <input type="number" class="lpb-input" id="lpb-logo_padding" value="<?php echo esc_attr(lpb_val($listing,'logo_padding','0')); ?>" min="0" max="60" placeholder="0">
              </div>
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label">Logo Background Color</label>
                <div class="lpb-color-row">
                  <div class="lpb-color-swatch"><input type="color" id="lpb-logo_bg" value="<?php echo esc_attr(lpb_val($listing,'logo_bg','')); ?>"></div>
                  <input type="text" class="lpb-input lpb-color-hex" id="lpb-logo_bg_text" value="<?php echo esc_attr(lpb_val($listing,'logo_bg','')); ?>" maxlength="7" placeholder="transparent">
                </div>
              </div>
            </div>

            <div style="font-size:.78rem;font-weight:700;color:#475569;margin:16px 0 12px">Banner Image Styling</div>
            <div class="lpb-grid-2">
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label">Banner Height (px)</label>
                <input type="number" class="lpb-input" id="lpb-banner_height" value="<?php echo esc_attr(lpb_val($listing,'banner_height','400')); ?>" min="200" max="800" placeholder="400">
              </div>
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label">Banner Border Radius</label>
                <div style="display:flex;gap:6px;align-items:center">
                  <input type="range" id="lpb-banner_radius" min="0" max="30" value="<?php echo esc_attr(lpb_val($listing,'banner_radius','0')); ?>" oninput="document.getElementById('lpb-banner_radius_val').textContent=this.value+'px'" style="flex:1">
                  <span id="lpb-banner_radius_val" style="font-size:.78rem;color:#64748B;width:40px"><?php echo esc_html(lpb_val($listing,'banner_radius','0')); ?>px</span>
                </div>
              </div>
            </div>
            <div class="lpb-grid-2" style="margin-top:12px">
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label">Banner Overlay Color</label>
                <div class="lpb-color-row">
                  <div class="lpb-color-swatch"><input type="color" id="lpb-banner_overlay" value="<?php echo esc_attr(lpb_val($listing,'banner_overlay','#000000')); ?>"></div>
                  <input type="text" class="lpb-input lpb-color-hex" id="lpb-banner_overlay_text" value="<?php echo esc_attr(lpb_val($listing,'banner_overlay','#000000')); ?>" maxlength="7">
                </div>
              </div>
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label">Banner Overlay Opacity (0–100)</label>
                <div style="display:flex;gap:6px;align-items:center">
                  <input type="range" id="lpb-banner_opacity" min="0" max="100" value="<?php echo esc_attr(lpb_val($listing,'banner_opacity','0')); ?>" oninput="document.getElementById('lpb-banner_opacity_val').textContent=this.value+'%'" style="flex:1">
                  <span id="lpb-banner_opacity_val" style="font-size:.78rem;color:#64748B;width:40px"><?php echo esc_html(lpb_val($listing,'banner_opacity','0')); ?>%</span>
                </div>
              </div>
            </div>
          </div>
        </details>

        <div class="lpb-divider"></div>

        <!-- ── HEADER CTA ─────────────────────────────────────── -->
        <div class="lpb-design-group-title">🔗 Navigation CTA</div>
        <div class="lpb-grid-2">
          <div class="lpb-field">
            <label class="lpb-label">Header CTA Text</label>
            <?php $hero_data = $listing->hero_data ?: []; ?>
            <input type="text" class="lpb-input lpb-hero-field" data-key="header_cta_text" value="<?php echo esc_attr($hero_data['header_cta_text'] ?? 'Get Free Quote'); ?>" placeholder="Get Free Quote">
          </div>
          <div class="lpb-field">
            <label class="lpb-label">Header CTA Link</label>
            <input type="text" class="lpb-input lpb-hero-field" data-key="header_cta_link" value="<?php echo esc_attr($hero_data['header_cta_link'] ?? '#vs-sec-contact'); ?>" placeholder="#vs-sec-contact">
          </div>
        </div>

      </div>
    </div>

    <!-- ══ HERO ══════════════════════════════════════════════════════ -->
    <div class="lpb-section" id="lpb-sec-hero">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">🖼</div>
        <div>
          <div class="lpb-section-title">Hero Section</div>
          <div class="lpb-section-sub">The main headline area at the top of your page — leave blank to auto-generate from listing data</div>
        </div>
      </div>
      <div class="lpb-body">
        <div class="lpb-grid-2">
          <div>
            <div class="lpb-field">
              <label class="lpb-label">Left Heading</label>
              <input type="text" class="lpb-input lpb-hero-field" data-key="hero_left_heading" value="<?php echo esc_attr($hero_data['hero_left_heading'] ?? ''); ?>" placeholder="Your Trusted Consultant for...">
              <div class="lpb-hint">Leave blank to use listing title</div>
            </div>
            <div class="lpb-field">
              <label class="lpb-label">Left Description</label>
              <textarea class="lpb-textarea lpb-hero-field" data-key="hero_left_description" rows="4" placeholder="Brief description shown in hero..."><?php echo esc_textarea($hero_data['hero_left_description'] ?? ''); ?></textarea>
            </div>
            <div class="lpb-grid-2">
              <div class="lpb-field">
                <label class="lpb-label">CTA Button Text</label>
                <input type="text" class="lpb-input lpb-hero-field" data-key="hero_left_cta_text" value="<?php echo esc_attr($hero_data['hero_left_cta_text'] ?? 'Learn More'); ?>" placeholder="Learn More">
              </div>
              <div class="lpb-field">
                <label class="lpb-label">CTA Button Link</label>
                <input type="text" class="lpb-input lpb-hero-field" data-key="hero_left_cta_link" value="<?php echo esc_attr($hero_data['hero_left_cta_link'] ?? '#gs-vs-contact'); ?>" placeholder="#gs-vs-contact or URL">
              </div>
            </div>
          </div>
          <div>
            <div class="lpb-field">
              <label class="lpb-label">Right Side Image</label>
              <div class="lpb-upload-zone" onclick="lpbUpload('hero_right_image','lpb-hero-img-preview','image')">
                <div>📤</div>
                <div class="lpb-upload-zone-text">Upload hero right image</div>
              </div>
              <?php $hri = $hero_data['hero_right_image'] ?? ''; ?>
              <?php if($hri): ?><img src="<?php echo esc_url($hri); ?>" class="lpb-img-preview" id="lpb-hero-img-preview" style="width:100%;margin-top:10px;height:140px;object-fit:cover"><?php else: ?><img src="" id="lpb-hero-img-preview" style="display:none;width:100%;margin-top:10px;height:140px;object-fit:cover;border-radius:8px"><?php endif; ?>
              <input type="hidden" id="lpb-hero_right_image_hidden" value="<?php echo esc_attr($hri); ?>">
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ══ TRUST BAR ═════════════════════════════════════════════════ -->
    <div class="lpb-section" id="lpb-sec-trustbar">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">📢</div>
        <div>
          <div class="lpb-section-title">Trust Bar / Marquee Strip</div>
          <div class="lpb-section-sub">A scrolling strip below the hero — leave blank to hide</div>
        </div>
      </div>
      <div class="lpb-body">
        <div class="lpb-field">
          <label class="lpb-label">Trust Bar Text</label>
          <input type="text" class="lpb-input" id="lpb-trust_bar_text" value="<?php echo esc_attr( lpb_val($listing,'trust_bar_text','') ); ?>" placeholder="✔ PAN Card  •  ✔ Aadhaar  •  ✔ Passport  •  ✔ Marriage Certificate  •  ...">
          <div class="lpb-hint">Use • to separate items. Will scroll as a marquee. Leave blank to hide this strip.</div>
        </div>
        <div class="lpb-field">
          <label class="lpb-label">Marquee Scroll Speed</label>
          <div style="display:flex;align-items:center;gap:12px;margin-top:4px">
            <input type="range" id="lpb-cd-trust_bar_speed" min="5" max="120" step="1"
              value="<?php echo esc_attr(lpb_cd($listing,'trust_bar_speed','28')); ?>"
              class="lpb-cd-field" data-cd="trust_bar_speed"
              oninput="document.getElementById('lpb-speed-val').textContent=this.value+'s'"
              style="flex:1">
            <span id="lpb-speed-val" style="font-size:.82rem;color:#64748B;min-width:32px;text-align:right"><?php echo esc_html(lpb_cd($listing,'trust_bar_speed','28')); ?>s</span>
          </div>
          <div class="lpb-hint">Lower value = faster scroll. Range: 5s (very fast) → 120s (very slow). Default: 28s.</div>
          <div style="display:flex;gap:8px;margin-top:8px">
            <?php foreach([10=>'Fast',28=>'Normal',50=>'Slow',80=>'Very Slow'] as $spd=>$lbl): ?>
            <button type="button" class="lpb-btn lpb-btn-ghost lpb-btn-sm"
              onclick="document.getElementById('lpb-cd-trust_bar_speed').value=<?php echo $spd;?>;document.getElementById('lpb-speed-val').textContent='<?php echo $spd;?>s'"
              style="font-size:.72rem;padding:4px 10px"><?php echo esc_html($lbl); ?></button>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- ══ ABOUT ══════════════════════════════════════════════════════ -->
    <div class="lpb-section" id="lpb-sec-about">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">ℹ️</div>
        <div>
          <div class="lpb-section-title">About / Intro Section</div>
          <div class="lpb-section-sub">2-column layout: text on left, image + badges on right</div>
        </div>
      </div>
      <div class="lpb-body">
        <?php $about_data = $listing->about_data ?: []; ?>
        <div class="lpb-grid-2">
          <div>
            <div class="lpb-field">
              <label class="lpb-label">Section Title</label>
              <input type="text" class="lpb-input lpb-about-field" data-key="about_title" value="<?php echo esc_attr($about_data['about_title'] ?? ''); ?>" placeholder="About Us">
            </div>
            <div class="lpb-field">
              <label class="lpb-label">Description</label>
              <textarea class="lpb-textarea lpb-about-field" data-key="about_description" rows="6" placeholder="Describe your company, expertise, mission..."><?php echo esc_textarea($about_data['about_description'] ?? ''); ?></textarea>
            </div>
            <div class="lpb-grid-2">
              <div class="lpb-field">
                <label class="lpb-label">CTA Button Text</label>
                <input type="text" class="lpb-input lpb-about-field" data-key="about_cta_text" value="<?php echo esc_attr($about_data['about_cta_text'] ?? ''); ?>" placeholder="Learn More">
              </div>
              <div class="lpb-field">
                <label class="lpb-label">CTA Button Link</label>
                <input type="text" class="lpb-input lpb-about-field" data-key="about_cta_link" value="<?php echo esc_attr($about_data['about_cta_link'] ?? ''); ?>" placeholder="#gs-vs-contact">
              </div>
            </div>
          </div>
          <div>
            <div class="lpb-field">
              <label class="lpb-label">About Image (Right Column)</label>
              <div class="lpb-upload-zone" onclick="lpbUpload('about_image','lpb-about-img','image')">
                <div>📤</div><div class="lpb-upload-zone-text">Upload about section image</div>
              </div>
              <?php $ai = $about_data['about_image'] ?? ''; ?>
              <?php if($ai): ?><img src="<?php echo esc_url($ai); ?>" class="lpb-img-preview" id="lpb-about-img" style="width:100%;height:120px;object-fit:cover"><?php else: ?><img src="" id="lpb-about-img" style="display:none;width:100%;height:120px;object-fit:cover;border-radius:8px"><?php endif; ?>
              <input type="hidden" id="lpb-about_image_hidden" value="<?php echo esc_attr($ai); ?>">
            </div>
            <div class="lpb-field" style="margin-top:12px">
              <label class="lpb-label">Badge / Trust Images (up to 4)</label>
              <div class="lpb-hint">Upload certification logos, partner logos, award badges etc.</div>
              <?php $badges = $about_data['about_badges'] ?? []; ?>
              <div id="lpb-badges-container" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">
                <?php for($bi=0;$bi<4;$bi++): $bv=$badges[$bi]??''; ?>
                <div>
                  <div class="lpb-upload-zone" style="padding:10px" onclick="lpbUpload('about_badge_<?php echo $bi; ?>','lpb-badge-img-<?php echo $bi; ?>','image')">
                    <div style="font-size:.75rem;color:#94A3B8">Badge <?php echo $bi+1; ?></div>
                  </div>
                  <?php if($bv): ?><img src="<?php echo esc_url($bv); ?>" class="lpb-img-preview" id="lpb-badge-img-<?php echo $bi; ?>" style="width:60px;height:40px"><?php else: ?><img src="" id="lpb-badge-img-<?php echo $bi; ?>" style="display:none;width:60px;height:40px"><?php endif; ?>
                  <input type="hidden" id="lpb-about_badge_<?php echo $bi; ?>_hidden" value="<?php echo esc_attr($bv); ?>">
                </div>
                <?php endfor; ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ══ SERVICES CATEGORY ═════════════════════════════════════════ -->
    <div class="lpb-section" id="lpb-sec-services-cat">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">🗂</div>
        <div>
          <div class="lpb-section-title">Services Category Section</div>
          <div class="lpb-section-sub">Icon grid of service categories (maps to services_data field)</div>
        </div>
      </div>
      <div class="lpb-body">
        <div class="lpb-grid-2">
          <div class="lpb-field">
            <label class="lpb-label">Section Title</label>
            <input type="text" class="lpb-input" id="lpb-services_section_title" value="<?php echo esc_attr( lpb_val($listing,'services_section_title','Our Services') ); ?>" placeholder="Our Services">
          </div>
          <div class="lpb-field">
            <label class="lpb-label">Section Description</label>
            <input type="text" class="lpb-input" id="lpb-services_section_desc" value="<?php echo esc_attr( lpb_val($listing,'services_section_desc','') ); ?>" placeholder="Short subtitle under the heading">
          </div>
        </div>

        <!-- ── SERVICES CAT: Full Styling Controls ─────────────── -->
        <details style="margin:20px 0">
          <summary style="cursor:pointer;font-size:.84rem;font-weight:700;color:#1E3A5F;padding:10px 14px;background:#EFF6FF;border-radius:10px;border:1px solid #BFDBFE;list-style:none;display:flex;align-items:center;gap:8px">
            <span>🎨</span> Full Styling Controls — Services Category Section
            <span style="margin-left:auto;font-size:.75rem;font-weight:500;color:#3B82F6">▼ Expand</span>
          </summary>
          <div style="margin-top:14px;background:#F8FAFC;border-radius:12px;padding:20px;border:1px solid #E2E8F0">

            <div class="lpb-design-group-title">📐 Section Padding & Background</div>
            <div class="lpb-grid-2" style="margin-bottom:14px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Padding Top (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="svc_sec_pt" value="<?php echo esc_attr(lpb_cd($listing,'svc_sec_pt','64')); ?>" min="0" max="200" placeholder="64"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Padding Bottom (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="svc_sec_pb" value="<?php echo esc_attr(lpb_cd($listing,'svc_sec_pb','64')); ?>" min="0" max="200" placeholder="64"></div>
            </div>
            <div class="lpb-field">
              <label class="lpb-label">Section Background Color</label>
              <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-svc_sec_bg" value="<?php echo esc_attr(lpb_cd($listing,'svc_sec_bg','#F8FAFC')); ?>"></div>
              <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="svc_sec_bg" id="lpb-cd-svc_sec_bg_text" value="<?php echo esc_attr(lpb_cd($listing,'svc_sec_bg','#F8FAFC')); ?>" maxlength="7" placeholder="#F8FAFC"></div>
            </div>

            <div class="lpb-design-group-title" style="margin-top:16px">🃏 Card Styling</div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Card Background</label>
                <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-svc_card_bg" value="<?php echo esc_attr(lpb_cd($listing,'svc_card_bg','#ffffff')); ?>"></div>
                <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="svc_card_bg" id="lpb-cd-svc_card_bg_text" value="<?php echo esc_attr(lpb_cd($listing,'svc_card_bg','#ffffff')); ?>" maxlength="7" placeholder="#ffffff"></div>
              </div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Border Radius (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="svc_card_radius" value="<?php echo esc_attr(lpb_cd($listing,'svc_card_radius','16')); ?>" min="0" max="40" placeholder="16"></div>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Border Width (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="svc_card_border_width" value="<?php echo esc_attr(lpb_cd($listing,'svc_card_border_width','1')); ?>" min="0" max="8" placeholder="1"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Border Color</label>
                <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-svc_card_border_color" value="<?php echo esc_attr(lpb_cd($listing,'svc_card_border_color','#E2E8F0')); ?>"></div>
                <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="svc_card_border_color" id="lpb-cd-svc_card_border_color_text" value="<?php echo esc_attr(lpb_cd($listing,'svc_card_border_color','#E2E8F0')); ?>" maxlength="7" placeholder="#E2E8F0"></div>
              </div>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Card Padding (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="svc_card_padding" value="<?php echo esc_attr(lpb_cd($listing,'svc_card_padding','20')); ?>" min="0" max="60" placeholder="20"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Card Margin (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="svc_card_margin" value="<?php echo esc_attr(lpb_cd($listing,'svc_card_margin','0')); ?>" min="0" max="40" placeholder="0"></div>
            </div>
            <div class="lpb-field">
              <label class="lpb-label">Card Shadow</label>
              <select class="lpb-select lpb-cd-field" data-cd="svc_card_shadow">
                <?php foreach(['none'=>'None','sm'=>'Small','md'=>'Medium','lg'=>'Large'] as $sv=>$sl): ?>
                <option value="<?php echo $sv; ?>" <?php selected(lpb_cd($listing,'svc_card_shadow','none'),$sv); ?>><?php echo $sl; ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="lpb-design-group-title" style="margin-top:16px">🖼 Icon & Image Styling</div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Icon Size (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="svc_icon_size" value="<?php echo esc_attr(lpb_cd($listing,'svc_icon_size','32')); ?>" min="16" max="72" placeholder="32"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Icon Border Radius (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="svc_icon_radius" value="<?php echo esc_attr(lpb_cd($listing,'svc_icon_radius','12')); ?>" min="0" max="50" placeholder="12"></div>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Icon BG Color</label>
                <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-svc_icon_bg" value="<?php echo esc_attr(lpb_cd($listing,'svc_icon_bg','#EFF6FF')); ?>"></div>
                <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="svc_icon_bg" id="lpb-cd-svc_icon_bg_text" value="<?php echo esc_attr(lpb_cd($listing,'svc_icon_bg','#EFF6FF')); ?>" maxlength="7" placeholder="#EFF6FF"></div>
              </div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Icon Color</label>
                <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-svc_icon_color" value="<?php echo esc_attr(lpb_cd($listing,'svc_icon_color','#2563EB')); ?>"></div>
                <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="svc_icon_color" id="lpb-cd-svc_icon_color_text" value="<?php echo esc_attr(lpb_cd($listing,'svc_icon_color','#2563EB')); ?>" maxlength="7" placeholder="#2563EB"></div>
              </div>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Image Height (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="svc_img_height" value="<?php echo esc_attr(lpb_cd($listing,'svc_img_height','80')); ?>" min="40" max="200" placeholder="80"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Image Border Radius (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="svc_img_radius" value="<?php echo esc_attr(lpb_cd($listing,'svc_img_radius','10')); ?>" min="0" max="40" placeholder="10"></div>
            </div>
            <div style="font-size:.76rem;color:#64748B;margin:0 0 10px">The controls below apply when a service uses a full photo (Image field on the service item) rather than an emoji icon.</div>
            <?php lpb_image_style_fields( $listing, 'svc_img', 'contain' ); ?>

            <div class="lpb-design-group-title" style="margin-top:16px">✍ Title Styling</div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Font Size (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="svc_title_size" value="<?php echo esc_attr(lpb_cd($listing,'svc_title_size','14')); ?>" min="10" max="32" placeholder="14"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Font Weight</label>
                <select class="lpb-select lpb-cd-field" data-cd="svc_title_weight">
                  <?php foreach(['400'=>'Regular','500'=>'Medium','600'=>'Semi-Bold','700'=>'Bold','800'=>'Extra-Bold'] as $wv=>$wl): ?>
                  <option value="<?php echo $wv; ?>" <?php selected(lpb_cd($listing,'svc_title_weight','600'),$wv); ?>><?php echo $wl; ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            <div class="lpb-field">
              <label class="lpb-label">Title Color</label>
              <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-svc_title_color" value="<?php echo esc_attr(lpb_cd($listing,'svc_title_color','#1E293B')); ?>"></div>
              <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="svc_title_color" id="lpb-cd-svc_title_color_text" value="<?php echo esc_attr(lpb_cd($listing,'svc_title_color','#1E293B')); ?>" maxlength="7" placeholder="#1E293B"></div>
            </div>

            <div class="lpb-design-group-title" style="margin-top:16px">📝 Description Styling</div>
            <div class="lpb-grid-2">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Font Size (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="svc_desc_size" value="<?php echo esc_attr(lpb_cd($listing,'svc_desc_size','13')); ?>" min="10" max="22" placeholder="13"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Description Color</label>
                <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-svc_desc_color" value="<?php echo esc_attr(lpb_cd($listing,'svc_desc_color','#64748B')); ?>"></div>
                <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="svc_desc_color" id="lpb-cd-svc_desc_color_text" value="<?php echo esc_attr(lpb_cd($listing,'svc_desc_color','#64748B')); ?>" maxlength="7" placeholder="#64748B"></div>
              </div>
            </div>

          </div>
        </details>

        <div class="lpb-divider"></div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
          <div style="font-size:.88rem;font-weight:700;color:#1E3A5F">Service Items <span style="font-size:.75rem;color:#64748B;font-weight:400">(icon tiles, shown in 4-col grid)</span></div>
          <button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddRow('services-list','services')">+ Add Service</button>
        </div>
        <div id="lpb-services-list" class="lpb-repeater">
          <?php if( !empty($listing->services_data) ): foreach($listing->services_data as $si => $svc): ?>
          <div class="lpb-repeater-item" data-type="services">
            <div class="lpb-repeater-item-head">
              <span class="lpb-repeater-item-label">Service <?php echo $si+1; ?></span>
              <button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕ Remove</button>
            </div>
            <div class="lpb-grid-3" style="margin-bottom:10px">
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label" style="font-size:.7rem">Title *</label>
                <input type="text" class="lpb-input svc-name" value="<?php echo esc_attr($svc['name']??''); ?>" placeholder="e.g. Passport Services">
              </div>
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label" style="font-size:.7rem">Emoji / Icon</label>
                <input type="text" class="lpb-input svc-icon" value="<?php echo esc_attr($svc['icon']??''); ?>" placeholder="🛂 (leave blank to use image)">
              </div>
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label" style="font-size:.7rem">Link (optional)</label>
                <input type="text" class="lpb-input svc-link" value="<?php echo esc_attr($svc['link']??''); ?>" placeholder="#gs-vs-contact">
              </div>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:0">
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label" style="font-size:.7rem">Image (overrides emoji if set)</label>
                <div style="display:flex;align-items:center;gap:8px">
                  <div class="lpb-upload-zone svc-img-zone" style="flex:1;padding:8px;cursor:pointer" onclick="lpbUploadSvcImage(this)">
                    <?php if(!empty($svc['image'])): ?>
                      <img src="<?php echo esc_url($svc['image']); ?>" style="width:100%;height:54px;object-fit:cover;border-radius:6px;display:block">
                      <div style="font-size:.7rem;color:#059669;margin-top:3px">✅ Click to replace</div>
                    <?php else: ?>
                      <div style="font-size:.75rem;color:#94A3B8">📤 Click to upload image</div>
                    <?php endif; ?>
                  </div>
                  <?php if(!empty($svc['image'])): ?>
                    <button type="button" onclick="lpbClearSvcImage(this)" style="background:#fee2e2;color:#dc2626;border:none;border-radius:6px;padding:4px 8px;font-size:.72rem;cursor:pointer;white-space:nowrap">✕ Clear</button>
                  <?php endif; ?>
                  <input type="hidden" class="svc-image" value="<?php echo esc_attr($svc['image']??''); ?>">
                </div>
              </div>
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label" style="font-size:.7rem">Description (optional)</label>
                <textarea class="lpb-input lpb-textarea svc-description" rows="2" style="resize:vertical;font-size:.82rem" placeholder="Brief description of this service…"><?php echo esc_textarea($svc['description']??''); ?></textarea>
              </div>
            </div>
          </div>
          <?php endforeach; else: ?>
          <div class="lpb-repeater-item" data-type="services">
            <div class="lpb-repeater-item-head">
              <span class="lpb-repeater-item-label">Service 1</span>
              <button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕ Remove</button>
            </div>
            <div class="lpb-grid-3" style="margin-bottom:10px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Title *</label><input type="text" class="lpb-input svc-name" placeholder="e.g. Passport Services"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Emoji / Icon</label><input type="text" class="lpb-input svc-icon" placeholder="🛂 (leave blank to use image)"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Link (optional)</label><input type="text" class="lpb-input svc-link" placeholder="#gs-vs-contact"></div>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:0">
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label" style="font-size:.7rem">Image (overrides emoji if set)</label>
                <div style="display:flex;align-items:center;gap:8px">
                  <div class="lpb-upload-zone svc-img-zone" style="flex:1;padding:8px;cursor:pointer" onclick="lpbUploadSvcImage(this)"><div style="font-size:.75rem;color:#94A3B8">📤 Click to upload image</div></div>
                  <input type="hidden" class="svc-image" value="">
                </div>
              </div>
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label" style="font-size:.7rem">Description (optional)</label>
                <textarea class="lpb-input lpb-textarea svc-description" rows="2" style="resize:vertical;font-size:.82rem" placeholder="Brief description of this service…"></textarea>
              </div>
            </div>
          </div>
          <?php endif; ?>
          <div class="lpb-repeater-footer"><button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddRow('services-list','services')">+ Add Service</button></div>
        </div>
      </div>
    </div>

    <!-- ══ PROCESS ════════════════════════════════════════════════════ -->
    <div class="lpb-section" id="lpb-sec-process">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">⚙️</div>
        <div>
          <div class="lpb-section-title">How It Works (Process)</div>
          <div class="lpb-section-sub">Horizontal step-by-step process — icons in a row</div>
        </div>
      </div>
      <div class="lpb-body">
        <div class="lpb-field">
          <label class="lpb-label">Section Title</label>
          <input type="text" class="lpb-input" id="lpb-process_section_title" value="<?php echo esc_attr( lpb_val($listing,'process_section_title','How Process Works') ); ?>" placeholder="How Process Works">
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
          <div style="font-size:.88rem;font-weight:700;color:#1E3A5F">Process Steps</div>
          <button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddRow('process-list','process')">+ Add Step</button>
        </div>
        <div id="lpb-process-list" class="lpb-repeater">
          <?php if(!empty($listing->process_data)): foreach($listing->process_data as $pi => $step): ?>
          <div class="lpb-repeater-item" data-type="process">
            <div class="lpb-repeater-item-head">
              <span class="lpb-repeater-item-label">Step <?php echo $pi+1; ?></span>
              <button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕</button>
            </div>
            <div class="lpb-grid-2">
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Step Title</label><input type="text" class="lpb-input proc-title" value="<?php echo esc_attr($step['title']??''); ?>" placeholder="Step title"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Icon (emoji)</label><input type="text" class="lpb-input proc-icon" value="<?php echo esc_attr($step['icon']??''); ?>" placeholder="📋"></div>
            </div>
          </div>
          <?php endforeach; else: ?>
          <div class="lpb-repeater-item" data-type="process">
            <div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Step 1</span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕</button></div>
            <div class="lpb-grid-2">
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Step Title</label><input type="text" class="lpb-input proc-title" placeholder="Register"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Icon (emoji)</label><input type="text" class="lpb-input proc-icon" placeholder="📝"></div>
            </div>
          </div>
          <?php endif; ?>
          <div class="lpb-repeater-footer"><button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddRow('process-list','process')">+ Add Step</button></div>
        </div>
      </div>
    </div>

    <!-- ══ ITEMS (Services + Products unified) ══════════════════════ -->
    <div class="lpb-section" id="lpb-sec-items">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">📦</div>
        <div>
          <div class="lpb-section-title">Services & Products (Main Listing Cards)</div>
          <div class="lpb-section-sub">⚠️ Most Important — unified card grid. Product cards show "Get Quote" button; service cards do not.</div>
        </div>
      </div>
      <div class="lpb-body">
        <div style="background:#FFF7ED;border:1px solid #FED7AA;border-radius:10px;padding:12px 16px;margin-bottom:18px;font-size:.83rem;color:#92400E">
          <strong>📌 Rule:</strong> Set <strong>Item Type = Product</strong> to show "Get Quote" button. Set <strong>Item Type = Service</strong> to show without quote button.
        </div>

        <!-- ── ITEMS: Full Styling Controls ─────────────────────── -->
        <details style="margin-bottom:20px">
          <summary style="cursor:pointer;font-size:.84rem;font-weight:700;color:#1E3A5F;padding:10px 14px;background:#F0FDF4;border-radius:10px;border:1px solid #BBF7D0;list-style:none;display:flex;align-items:center;gap:8px">
            <span>🎨</span> Full Styling Controls — Products & Services Cards
            <span style="margin-left:auto;font-size:.75rem;font-weight:500;color:#059669">▼ Expand</span>
          </summary>
          <div style="margin-top:14px;background:#F8FAFC;border-radius:12px;padding:20px;border:1px solid #E2E8F0">

            <div class="lpb-design-group-title">📐 Section Padding & Background</div>
            <div class="lpb-grid-2" style="margin-bottom:14px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Padding Top (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_sec_pt" value="<?php echo esc_attr(lpb_cd($listing,'items_sec_pt','64')); ?>" min="0" max="200" placeholder="64"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Padding Bottom (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_sec_pb" value="<?php echo esc_attr(lpb_cd($listing,'items_sec_pb','64')); ?>" min="0" max="200" placeholder="64"></div>
            </div>
            <div class="lpb-field">
              <label class="lpb-label">Section Background Color</label>
              <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-items_sec_bg" value="<?php echo esc_attr(lpb_cd($listing,'items_sec_bg','#ffffff')); ?>"></div>
              <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="items_sec_bg" id="lpb-cd-items_sec_bg_text" value="<?php echo esc_attr(lpb_cd($listing,'items_sec_bg','#ffffff')); ?>" maxlength="7" placeholder="#ffffff"></div>
            </div>

            <div class="lpb-design-group-title" style="margin-top:16px">🃏 Card Styling</div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Card Background</label>
                <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-items_card_bg" value="<?php echo esc_attr(lpb_cd($listing,'items_card_bg','#ffffff')); ?>"></div>
                <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="items_card_bg" id="lpb-cd-items_card_bg_text" value="<?php echo esc_attr(lpb_cd($listing,'items_card_bg','#ffffff')); ?>" maxlength="7" placeholder="#ffffff"></div>
              </div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Border Radius (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_card_radius" value="<?php echo esc_attr(lpb_cd($listing,'items_card_radius','16')); ?>" min="0" max="40" placeholder="16"></div>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Border Width (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_card_border_width" value="<?php echo esc_attr(lpb_cd($listing,'items_card_border_width','1')); ?>" min="0" max="8" placeholder="1"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Border Color</label>
                <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-items_card_border_color" value="<?php echo esc_attr(lpb_cd($listing,'items_card_border_color','#E8ECF2')); ?>"></div>
                <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="items_card_border_color" id="lpb-cd-items_card_border_color_text" value="<?php echo esc_attr(lpb_cd($listing,'items_card_border_color','#E8ECF2')); ?>" maxlength="7" placeholder="#E8ECF2"></div>
              </div>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Card Padding (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_card_padding" value="<?php echo esc_attr(lpb_cd($listing,'items_card_padding','16')); ?>" min="0" max="60" placeholder="16"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Card Margin (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_card_margin" value="<?php echo esc_attr(lpb_cd($listing,'items_card_margin','0')); ?>" min="0" max="40" placeholder="0"></div>
            </div>
            <div class="lpb-field">
              <label class="lpb-label">Card Shadow</label>
              <select class="lpb-select lpb-cd-field" data-cd="items_card_shadow">
                <?php foreach(['none'=>'None','sm'=>'Small (default)','md'=>'Medium','lg'=>'Large'] as $sv=>$sl): ?>
                <option value="<?php echo $sv; ?>" <?php selected(lpb_cd($listing,'items_card_shadow','sm'),$sv); ?>><?php echo $sl; ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="lpb-design-group-title" style="margin-top:16px">🖼 Image Box Styling</div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Image Box Height (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_img_box_height" value="<?php echo esc_attr(lpb_cd($listing,'items_img_box_height','200')); ?>" min="80" max="500" placeholder="200"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Image Box Border Radius (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_img_box_radius" value="<?php echo esc_attr(lpb_cd($listing,'items_img_box_radius','0')); ?>" min="0" max="40" placeholder="0"></div>
            </div>
            <div class="lpb-field" style="margin-bottom:12px">
              <label class="lpb-label">Image Box Background Color</label>
              <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-items_img_box_bg" value="<?php echo esc_attr(lpb_cd($listing,'items_img_box_bg','#F8FAFC')); ?>"></div>
              <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="items_img_box_bg" id="lpb-cd-items_img_box_bg_text" value="<?php echo esc_attr(lpb_cd($listing,'items_img_box_bg','#F8FAFC')); ?>" maxlength="7" placeholder="#F8FAFC"></div>
            </div>
            <?php lpb_image_style_fields( $listing, 'items_img', 'cover' ); ?>

            <div class="lpb-design-group-title" style="margin-top:16px">✍ Title Styling</div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Font Size (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_title_size" value="<?php echo esc_attr(lpb_cd($listing,'items_title_size','16')); ?>" min="10" max="42" placeholder="16"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Font Weight</label>
                <select class="lpb-select lpb-cd-field" data-cd="items_title_weight">
                  <?php foreach(['400'=>'Regular','500'=>'Medium','600'=>'Semi-Bold','700'=>'Bold','800'=>'Extra-Bold'] as $wv=>$wl): ?>
                  <option value="<?php echo $wv; ?>" <?php selected(lpb_cd($listing,'items_title_weight','700'),$wv); ?>><?php echo $wl; ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            <div class="lpb-field">
              <label class="lpb-label">Title Color</label>
              <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-items_title_color" value="<?php echo esc_attr(lpb_cd($listing,'items_title_color','#1E293B')); ?>"></div>
              <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="items_title_color" id="lpb-cd-items_title_color_text" value="<?php echo esc_attr(lpb_cd($listing,'items_title_color','#1E293B')); ?>" maxlength="7" placeholder="#1E293B"></div>
            </div>

            <div class="lpb-design-group-title" style="margin-top:16px">📝 Description Styling</div>
            <div class="lpb-grid-2">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Font Size (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_desc_size" value="<?php echo esc_attr(lpb_cd($listing,'items_desc_size','14')); ?>" min="10" max="24" placeholder="14"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Description Color</label>
                <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-items_desc_color" value="<?php echo esc_attr(lpb_cd($listing,'items_desc_color','#64748B')); ?>"></div>
                <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="items_desc_color" id="lpb-cd-items_desc_color_text" value="<?php echo esc_attr(lpb_cd($listing,'items_desc_color','#64748B')); ?>" maxlength="7" placeholder="#64748B"></div>
              </div>
            </div>

            <div class="lpb-design-group-title" style="margin-top:16px">💰 Price Styling</div>
            <div class="lpb-grid-2">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Font Size (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_price_size" value="<?php echo esc_attr(lpb_cd($listing,'items_price_size','18')); ?>" min="10" max="32" placeholder="18"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Price Color</label>
                <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-items_price_color" value="<?php echo esc_attr(lpb_cd($listing,'items_price_color','#2563EB')); ?>"></div>
                <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="items_price_color" id="lpb-cd-items_price_color_text" value="<?php echo esc_attr(lpb_cd($listing,'items_price_color','#2563EB')); ?>" maxlength="7" placeholder="#2563EB"></div>
              </div>
            </div>

            <div class="lpb-design-group-title" style="margin-top:16px">🔘 Quote Button Styling</div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Button Background</label>
                <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-items_btn_bg" value="<?php echo esc_attr(lpb_cd($listing,'items_btn_bg','#2563EB')); ?>"></div>
                <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="items_btn_bg" id="lpb-cd-items_btn_bg_text" value="<?php echo esc_attr(lpb_cd($listing,'items_btn_bg','#2563EB')); ?>" maxlength="7" placeholder="#2563EB"></div>
              </div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Button Text Color</label>
                <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-items_btn_text" value="<?php echo esc_attr(lpb_cd($listing,'items_btn_text','#ffffff')); ?>"></div>
                <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="items_btn_text" id="lpb-cd-items_btn_text_text" value="<?php echo esc_attr(lpb_cd($listing,'items_btn_text','#ffffff')); ?>" maxlength="7" placeholder="#ffffff"></div>
              </div>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:12px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Border Radius (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_btn_radius" value="<?php echo esc_attr(lpb_cd($listing,'items_btn_radius','8')); ?>" min="0" max="50" placeholder="8"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label">Border Width (px)</label><input type="number" class="lpb-input lpb-cd-field" data-cd="items_btn_border_width" value="<?php echo esc_attr(lpb_cd($listing,'items_btn_border_width','0')); ?>" min="0" max="4" placeholder="0"></div>
            </div>
            <div class="lpb-field">
              <label class="lpb-label">Border Color</label>
              <div class="lpb-color-row"><div class="lpb-color-swatch"><input type="color" id="lpb-cd-items_btn_border_color" value="<?php echo esc_attr(lpb_cd($listing,'items_btn_border_color','#2563EB')); ?>"></div>
              <input type="text" class="lpb-input lpb-color-hex lpb-cd-field" data-cd="items_btn_border_color" id="lpb-cd-items_btn_border_color_text" value="<?php echo esc_attr(lpb_cd($listing,'items_btn_border_color','#2563EB')); ?>" maxlength="7" placeholder="#2563EB"></div>
            </div>

          </div>
        </details>

        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
          <div style="font-size:.88rem;font-weight:700;color:#1E3A5F">Items</div>
          <div style="display:flex;gap:8px">
            <button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddItem('service')">+ Service</button>
            <button class="lpb-btn lpb-btn-primary lpb-btn-sm" onclick="lpbAddItem('product')">+ Product</button>
          </div>
        </div>
        <div id="lpb-items-list" class="lpb-repeater">
          <?php
          $items_data = $listing->items_data ?: [];
          // Also backfill from products_data / services_data if items_data empty
          if ( empty($items_data) ) {
              foreach ( $listing->products_data as $p ) {
                  $items_data[] = array_merge(['item_type'=>'product','show_quote_button'=>true], $p);
              }
              foreach ( $listing->services_data as $s ) {
                  $items_data[] = array_merge(['item_type'=>'service','show_quote_button'=>false], $s);
              }
          }
          if ( ! empty($items_data) ): foreach($items_data as $ii => $item): $itype = $item['item_type'] ?? 'service'; ?>
          <div class="lpb-repeater-item" data-type="item">
            <div class="lpb-repeater-item-head">
              <div style="display:flex;align-items:center;gap:8px">
                <span class="lpb-repeater-item-label">Item <?php echo $ii+1; ?></span>
                <span class="lpb-type-badge <?php echo $itype==='product'?'lpb-type-product':'lpb-type-service'; ?>"><?php echo $itype==='product'?'📦 Product':'🛠 Service'; ?></span>
              </div>
              <button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕ Remove</button>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:10px">
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label" style="font-size:.7rem">Item Type *</label>
                <select class="lpb-select item-type" onchange="lpbToggleQuoteBtn(this)">
                  <option value="service" <?php echo $itype==='service'?'selected':''; ?>>🛠 Service</option>
                  <option value="product" <?php echo $itype==='product'?'selected':''; ?>>📦 Product</option>
                </select>
              </div>
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label" style="font-size:.7rem">Title *</label>
                <input type="text" class="lpb-input item-title" value="<?php echo esc_attr($item['name']??$item['item_title']??''); ?>" placeholder="Item title">
              </div>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:10px">
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label" style="font-size:.7rem">Category (optional)</label>
                <input type="text" class="lpb-input item-category" value="<?php echo esc_attr($item['category']??''); ?>" placeholder="e.g. Government Documents">
              </div>
              <div class="lpb-field" style="margin:0">
                <label class="lpb-label" style="font-size:.7rem">Price (optional)</label>
                <input type="text" class="lpb-input item-price" value="<?php echo esc_attr($item['price']??''); ?>" placeholder="e.g. ₹499 or Free">
              </div>
            </div>
            <div class="lpb-field" style="margin-bottom:10px">
              <label class="lpb-label" style="font-size:.7rem">Description</label>
              <textarea class="lpb-textarea item-description" rows="2"><?php echo esc_textarea($item['description']??''); ?></textarea>
            </div>
            <div class="lpb-field" style="margin-bottom:10px">
              <label class="lpb-label" style="font-size:.7rem">Item Image</label>
              <div style="display:flex;align-items:center;gap:10px">
                <div class="lpb-upload-zone" style="flex:1;padding:8px" onclick="lpbUploadItemImage(this)">
                  <div style="font-size:.75rem;color:#94A3B8">Click to upload image</div>
                </div>
                <?php $iimg = $item['image']??''; ?>
                <?php if($iimg): ?><img src="<?php echo esc_url($iimg); ?>" style="width:70px;height:50px;object-fit:cover;border-radius:6px;border:1px solid #E2E8F0" class="item-img-preview"><?php else: ?><img src="" class="item-img-preview" style="display:none;width:70px;height:50px;object-fit:cover;border-radius:6px"><?php endif; ?>
                <input type="hidden" class="item-image" value="<?php echo esc_attr($iimg); ?>">
              </div>
            </div>
            <div class="lpb-field" style="margin:0">
              <label class="lpb-toggle">
                <div class="lpb-toggle-track <?php echo !empty($item['show_quote_button'])||$itype==='product'?'on':''; ?> quote-toggle-track">
                  <div class="lpb-toggle-thumb"></div>
                </div>
                <input type="checkbox" class="item-show-quote" style="display:none" <?php echo !empty($item['show_quote_button'])||$itype==='product'?'checked':''; ?>>
                <span style="font-size:.82rem;color:#374151">Show "Get Quote" Button</span>
                <span style="font-size:.72rem;color:#94A3B8;margin-left:4px">(auto-enabled for Products)</span>
              </label>
            </div>
          </div>
          <?php endforeach; else: ?>
          <div class="lpb-repeater-item" data-type="item">
            <div class="lpb-repeater-item-head">
              <span class="lpb-repeater-item-label">Item 1 <span class="lpb-type-badge lpb-type-service">🛠 Service</span></span>
              <button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕ Remove</button>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:10px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Item Type *</label>
                <select class="lpb-select item-type" onchange="lpbToggleQuoteBtn(this)"><option value="service">🛠 Service</option><option value="product">📦 Product</option></select></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Title *</label><input type="text" class="lpb-input item-title" placeholder="Item title"></div>
            </div>
            <div class="lpb-grid-2" style="margin-bottom:10px">
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Category</label><input type="text" class="lpb-input item-category" placeholder="Category"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Price</label><input type="text" class="lpb-input item-price" placeholder="₹499"></div>
            </div>
            <div class="lpb-field" style="margin-bottom:10px"><label class="lpb-label" style="font-size:.7rem">Description</label><textarea class="lpb-textarea item-description" rows="2"></textarea></div>
            <div class="lpb-field" style="margin-bottom:10px"><label class="lpb-label" style="font-size:.7rem">Item Image</label>
              <div style="display:flex;align-items:center;gap:10px">
                <div class="lpb-upload-zone" style="flex:1;padding:8px" onclick="lpbUploadItemImage(this)"><div style="font-size:.75rem;color:#94A3B8">Click to upload image</div></div>
                <img src="" class="item-img-preview" style="display:none;width:70px;height:50px;object-fit:cover;border-radius:6px">
                <input type="hidden" class="item-image" value="">
              </div></div>
            <div class="lpb-field" style="margin:0"><label class="lpb-toggle"><div class="lpb-toggle-track quote-toggle-track"><div class="lpb-toggle-thumb"></div></div><input type="checkbox" class="item-show-quote" style="display:none"><span style="font-size:.82rem;color:#374151">Show "Get Quote" Button</span></label></div>
          </div>
          <?php endif; ?>
          <div class="lpb-repeater-footer" style="gap:8px;display:flex;justify-content:center">
            <button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddItem('service')">+ Add Service</button>
            <button class="lpb-btn lpb-btn-primary lpb-btn-sm" onclick="lpbAddItem('product')">+ Add Product</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ══ GALLERY ════════════════════════════════════════════════════ -->
    <div class="lpb-section" id="lpb-sec-gallery">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">🖼</div>
        <div>
          <div class="lpb-section-title">Photo Gallery</div>
          <div class="lpb-section-sub">Upload photos of your shop, office, interior, exterior, team, work etc. Completely separate from products/services.</div>
        </div>
      </div>

      <div class="lpb-field">
        <label class="lpb-label">Gallery Title <span style="font-size:.72rem;color:#94A3B8">(optional override)</span></label>
        <input type="text" class="lpb-input" id="lpb-gallery_title" value="<?php echo esc_attr(lpb_val($listing,'gallery_title','')); ?>" placeholder="Our Gallery (leave blank for default)">
      </div>

      <!-- Gallery Layout & Styling Controls -->
      <details style="margin-bottom:20px">
        <summary style="cursor:pointer;font-size:.84rem;font-weight:700;color:#1E3A5F;padding:10px 14px;background:#F0F9FF;border-radius:10px;border:1px solid #BAE6FD;list-style:none;display:flex;align-items:center;gap:8px">
          <span>🎨</span> Gallery Layout & Styling Controls
          <span style="margin-left:auto;font-size:.75rem;font-weight:500;color:#0284C7">▼ Expand</span>
        </summary>
        <div style="margin-top:14px;background:#F8FAFC;border-radius:12px;padding:20px;border:1px solid #E2E8F0">

          <div class="lpb-design-group-title">📐 Layout</div>
          <div class="lpb-grid-3" style="margin-bottom:14px">
            <div class="lpb-field" style="margin:0">
              <label class="lpb-label">Columns (Desktop)</label>
              <select class="lpb-select lpb-cd-field" data-cd="gallery_cols">
                <?php foreach([2=>'2 Columns',3=>'3 Columns',4=>'4 Columns (default)',5=>'5 Columns',6=>'6 Columns'] as $cv=>$cl): ?>
                <option value="<?php echo $cv; ?>" <?php selected((int)lpb_cd($listing,'gallery_cols','4'),$cv); ?>><?php echo $cl; ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="lpb-field" style="margin:0">
              <label class="lpb-label">Grid Gap (px)</label>
              <input type="number" class="lpb-input lpb-cd-field" data-cd="gallery_gap" value="<?php echo esc_attr(lpb_cd($listing,'gallery_gap','16')); ?>" min="0" max="40" placeholder="16">
            </div>
            <div class="lpb-field" style="margin:0">
              <label class="lpb-label">Image Aspect Ratio</label>
              <select class="lpb-select lpb-cd-field" data-cd="gallery_aspect">
                <?php foreach(['4/3'=>'4:3 (Landscape)','1/1'=>'1:1 (Square)','16/9'=>'16:9 (Wide)','3/4'=>'3:4 (Portrait)'] as $av=>$al): ?>
                <option value="<?php echo $av; ?>" <?php selected(lpb_cd($listing,'gallery_aspect','4/3'),$av); ?>><?php echo $al; ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="lpb-design-group-title" style="margin-top:16px">🖼 Image Box Styling</div>
          <div class="lpb-grid-2" style="margin-bottom:12px">
            <div class="lpb-field" style="margin:0">
              <label class="lpb-label">Border Radius (px) <span style="font-size:.72rem;color:#94A3B8">default 25px</span></label>
              <input type="number" class="lpb-input lpb-cd-field" data-cd="gallery_radius" value="<?php echo esc_attr(lpb_cd($listing,'gallery_radius','25')); ?>" min="0" max="50" placeholder="25">
            </div>
          </div>
          <?php lpb_image_style_fields( $listing, 'gallery_img', 'cover' ); ?>
          <div style="background:#FFF7ED;border:1px solid #FED7AA;border-radius:8px;padding:10px 14px;font-size:.8rem;color:#92400E;margin-top:12px">
            ✅ <strong>Auto-uniform sizing:</strong> All images are automatically fitted to the same rectangular box regardless of original dimensions. Choose aspect ratio above and Image Fit above to control how each photo fills that box.
          </div>

        </div>
      </details>

      <!-- Tag filter chips the visitor will see -->
      <div class="lpb-field">
        <label class="lpb-label">Category Tags Shown to Visitors</label>
        <div style="font-size:.78rem;color:#64748B;margin-bottom:8px">Tags are auto-generated from the photos below — no extra setup needed.</div>
      </div>

      <!-- Photo uploader grid -->
      <div class="lpb-field">
        <label class="lpb-label">Photos <span style="font-size:.72rem;color:#94A3B8" id="lpb-gal-count">0 uploaded</span></label>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:12px" id="lpb-gal-grid">
          <?php
          // Load existing gallery — could be plain URLs or {url,caption,tag} objects
          $gal_items = [];
          if ($primary && !empty($listing->gallery)) {
              foreach ($listing->gallery as $g) {
                  if (is_array($g)) $gal_items[] = $g;
                  elseif (is_string($g) && $g) $gal_items[] = ['url'=>$g,'caption'=>'','tag'=>''];
              }
          }
          foreach ($gal_items as $gi):
              $gurl = $gi['url'] ?? ''; if (!$gurl) continue;
              $gcap = $gi['caption'] ?? ''; $gtag = $gi['tag'] ?? '';
          ?>
          <div class="lpb-gal-item" data-url="<?php echo esc_attr($gurl); ?>" data-caption="<?php echo esc_attr($gcap); ?>" data-tag="<?php echo esc_attr($gtag); ?>" style="position:relative;border-radius:10px;overflow:hidden;border:1.5px solid #E2E8F0">
            <img src="<?php echo esc_url($gurl); ?>" style="width:100%;aspect-ratio:1;object-fit:cover;display:block">
            <div style="padding:6px">
              <input type="text" class="lpb-input lpb-gal-caption" value="<?php echo esc_attr($gcap); ?>" placeholder="Caption…" style="font-size:.72rem;padding:4px 7px;margin-bottom:4px">
              <select class="lpb-select lpb-gal-tag" style="font-size:.72rem;padding:4px 7px">
                <?php foreach (['','Interior','Exterior','Shop Front','Team','Work Sample','Equipment','Event','Other'] as $topt): ?>
                  <option value="<?php echo esc_attr($topt); ?>" <?php selected($gtag,$topt); ?>><?php echo $topt ?: '— Tag —'; ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <button onclick="this.closest('.lpb-gal-item').remove();lpbSyncGallery()" style="position:absolute;top:5px;right:5px;background:rgba(0,0,0,.55);border:none;color:#fff;border-radius:50%;width:22px;height:22px;font-size:.75rem;cursor:pointer;display:flex;align-items:center;justify-content:center;line-height:1">✕</button>
          </div>
          <?php endforeach; ?>

          <!-- Add photo tile -->
          <div onclick="document.getElementById('lpb-gal-upload').click()" style="border:2px dashed #CBD5E1;border-radius:10px;aspect-ratio:1;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;color:#94A3B8;gap:6px;font-size:.75rem;transition:border-color .2s" onmouseover="this.style.borderColor='var(--lpb-primary)'" onmouseout="this.style.borderColor='#CBD5E1'" id="lpb-gal-add-btn">
            <span style="font-size:1.8rem">📷</span>
            <span>Add Photos</span>
            <span style="font-size:.68rem">JPG, PNG, WebP</span>
          </div>
        </div>
        <input type="file" id="lpb-gal-upload" accept="image/*" multiple style="display:none">
        <input type="hidden" id="lpb-gallery-data" value="<?php echo esc_attr(json_encode(array_values($gal_items))); ?>">
        <div style="font-size:.75rem;color:#94A3B8;margin-top:4px">Each photo can have an optional caption and category tag. Drag to reorder (coming soon).</div>
      </div>
    </div>

    <!-- ══ STATS ══════════════════════════════════════════════════════ -->
    <div class="lpb-section" id="lpb-sec-stats">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">📊</div>
        <div>
          <div class="lpb-section-title">Stats / Achievements</div>
          <div class="lpb-section-sub">Numbers that build trust (e.g. 142+ Services, 4+ Years)</div>
        </div>
      </div>
      <div class="lpb-body">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
          <div style="font-size:.88rem;font-weight:700;color:#1E3A5F">Stats</div>
          <button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddRow('stats-list','stat')">+ Add Stat</button>
        </div>
        <div id="lpb-stats-list" class="lpb-repeater">
          <?php if(!empty($listing->stats_data)): foreach($listing->stats_data as $sti => $st): ?>
          <div class="lpb-repeater-item" data-type="stat">
            <div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Stat <?php echo $sti+1; ?></span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕</button></div>
            <div class="lpb-grid-2">
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Number / Value</label><input type="text" class="lpb-input stat-number" value="<?php echo esc_attr($st['number']??$st['stat_number']??''); ?>" placeholder="142+"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Label</label><input type="text" class="lpb-input stat-label" value="<?php echo esc_attr($st['label']??$st['stat_label']??''); ?>" placeholder="Services Offered"></div>
            </div>
          </div>
          <?php endforeach; else: ?>
          <div class="lpb-repeater-item" data-type="stat">
            <div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Stat 1</span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕</button></div>
            <div class="lpb-grid-2">
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Number / Value</label><input type="text" class="lpb-input stat-number" placeholder="142+"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Label</label><input type="text" class="lpb-input stat-label" placeholder="Services Offered"></div>
            </div>
          </div>
          <?php endif; ?>
          <div class="lpb-repeater-footer"><button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddRow('stats-list','stat')">+ Add Stat</button></div>
        </div>
      </div>
    </div>

    <!-- ══ WHY CHOOSE US ═════════════════════════════════════════════ -->
    <div class="lpb-section" id="lpb-sec-why">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">✅</div>
        <div>
          <div class="lpb-section-title">Why Choose Us</div>
          <div class="lpb-section-sub">Benefits, USPs, and differentiators</div>
        </div>
      </div>
      <div class="lpb-body">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
          <div style="font-size:.88rem;font-weight:700;color:#1E3A5F">Benefits</div>
          <button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddRow('why-list','why')">+ Add Benefit</button>
        </div>
        <div id="lpb-why-list" class="lpb-repeater">
          <?php if(!empty($listing->why_choose_data)): foreach($listing->why_choose_data as $wi => $w): ?>
          <div class="lpb-repeater-item" data-type="why">
            <div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Benefit <?php echo $wi+1; ?></span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕</button></div>
            <div class="lpb-grid-3">
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Title</label><input type="text" class="lpb-input why-title" value="<?php echo esc_attr($w['title']??''); ?>" placeholder="Fast Service"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Icon (emoji)</label><input type="text" class="lpb-input why-icon" value="<?php echo esc_attr($w['icon']??''); ?>" placeholder="⚡"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Description</label><input type="text" class="lpb-input why-desc" value="<?php echo esc_attr($w['description']??''); ?>" placeholder="We process in 24 hours"></div>
            </div>
          </div>
          <?php endforeach; else: ?>
          <div class="lpb-repeater-item" data-type="why">
            <div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Benefit 1</span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕</button></div>
            <div class="lpb-grid-3">
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Title</label><input type="text" class="lpb-input why-title" placeholder="Fast Service"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Icon (emoji)</label><input type="text" class="lpb-input why-icon" placeholder="⚡"></div>
              <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Description</label><input type="text" class="lpb-input why-desc" placeholder="We process in 24 hours"></div>
            </div>
          </div>
          <?php endif; ?>
          <div class="lpb-repeater-footer"><button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddRow('why-list','why')">+ Add Benefit</button></div>
        </div>
      </div>
    </div>

    <!-- ══ FAQ ════════════════════════════════════════════════════════ -->
    <div class="lpb-section" id="lpb-sec-faq">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">❓</div>
        <div>
          <div class="lpb-section-title">FAQ Section</div>
          <div class="lpb-section-sub">Accordion questions and answers</div>
        </div>
      </div>
      <div class="lpb-body">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
          <div style="font-size:.88rem;font-weight:700;color:#1E3A5F">Questions</div>
          <button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddRow('faq-list','faq')">+ Add FAQ</button>
        </div>
        <div id="lpb-faq-list" class="lpb-repeater">
          <?php if(!empty($listing->faq_data)): foreach($listing->faq_data as $fi => $faq): ?>
          <div class="lpb-repeater-item" data-type="faq">
            <div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Q<?php echo $fi+1; ?></span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕</button></div>
            <div class="lpb-field" style="margin-bottom:10px"><label class="lpb-label" style="font-size:.7rem">Question</label><input type="text" class="lpb-input faq-question" value="<?php echo esc_attr($faq['question']??''); ?>" placeholder="How long does it take?"></div>
            <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Answer</label><textarea class="lpb-textarea faq-answer" rows="3"><?php echo esc_textarea($faq['answer']??''); ?></textarea></div>
          </div>
          <?php endforeach; else: ?>
          <div class="lpb-repeater-item" data-type="faq">
            <div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Q1</span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕</button></div>
            <div class="lpb-field" style="margin-bottom:10px"><label class="lpb-label" style="font-size:.7rem">Question</label><input type="text" class="lpb-input faq-question" placeholder="How long does it take?"></div>
            <div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Answer</label><textarea class="lpb-textarea faq-answer" rows="3"></textarea></div>
          </div>
          <?php endif; ?>
          <div class="lpb-repeater-footer"><button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddRow('faq-list','faq')">+ Add FAQ</button></div>
        </div>
      </div>
    </div>

    <!-- ══ CONTACT ════════════════════════════════════════════════════ -->
    <div class="lpb-section" id="lpb-sec-contact">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">📍</div>
        <div>
          <div class="lpb-section-title">Contact Section</div>
          <div class="lpb-section-sub">Address, map embed, and quick connect form (data comes from main listing profile)</div>
        </div>
      </div>
      <div class="lpb-body">
        <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:10px;padding:14px 16px;font-size:.83rem;color:#1D4ED8;margin-bottom:16px">
          ℹ️ Contact details (phone, email, address, WhatsApp) are pulled from your main listing profile. To update them, go to <a href="<?php echo home_url('/vendor/dashboard/?section=listings'); ?>" style="color:#1D4ED8;font-weight:600">Edit Listing</a>.
        </div>
        <div class="lpb-field">
          <label class="lpb-label">Map Embed Code (optional)</label>
          <textarea class="lpb-textarea" id="lpb-map_embed" rows="4" placeholder="Paste Google Maps iframe embed code here..."><?php echo esc_textarea( lpb_val($listing,'map_embed','') ); ?></textarea>
          <div class="lpb-hint">Go to Google Maps → Share → Embed a map → Copy HTML</div>
        </div>
      </div>
    </div>

    <!-- ══ FEEDBACK ═══════════════════════════════════════════════════ -->
    <div class="lpb-section" id="lpb-sec-feedback">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">⭐</div>
        <div>
          <div class="lpb-section-title">Feedback Section</div>
          <div class="lpb-section-sub">Allow visitors to submit star ratings and reviews</div>
        </div>
      </div>
      <div class="lpb-body">
        <?php $feedback_data = $listing->feedback_data ?: []; ?>
        <div class="lpb-grid-2">
          <div class="lpb-field">
            <label class="lpb-label">Section Title</label>
            <input type="text" class="lpb-input lpb-feedback-field" data-key="feedback_title" value="<?php echo esc_attr($feedback_data['feedback_title'] ?? 'Submit Your Feedback'); ?>" placeholder="Submit Your Feedback">
          </div>
          <div class="lpb-field">
            <label class="lpb-label">Section Subtitle</label>
            <input type="text" class="lpb-input lpb-feedback-field" data-key="feedback_subtitle" value="<?php echo esc_attr($feedback_data['feedback_subtitle'] ?? 'Rate Your Experience'); ?>" placeholder="Rate Your Experience">
          </div>
        </div>
        <div class="lpb-field">
          <label class="lpb-toggle">
            <div class="lpb-toggle-track <?php echo !empty($feedback_data['show_feedback'])?'on':''; ?>" id="lpb-feedback-toggle-track">
              <div class="lpb-toggle-thumb"></div>
            </div>
            <input type="checkbox" id="lpb-feedback-show" style="display:none" <?php echo !empty($feedback_data['show_feedback'])?'checked':''; ?>>
            <span style="font-size:.88rem;color:#374151;font-weight:500">Show Feedback Section on Page</span>
          </label>
          <div class="lpb-hint">When enabled, a star-rating form will appear at the bottom of your listing page</div>
        </div>
      </div>
    </div>

    <!-- ══ FOOTER ═════════════════════════════════════════════════════ -->
    <div class="lpb-section" id="lpb-sec-footer">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">🦶</div>
        <div>
          <div class="lpb-section-title">Footer</div>
          <div class="lpb-section-sub">Footer logo, about text, links, and newsletter</div>
        </div>
      </div>
      <div class="lpb-body">
        <?php $footer_data = $listing->footer_data ?: []; ?>
        <div class="lpb-field">
          <label class="lpb-label">Footer About Text</label>
          <textarea class="lpb-textarea lpb-footer-field" data-key="footer_about_text" rows="3" placeholder="Brief tagline or description in the footer..."><?php echo esc_textarea($footer_data['footer_about_text'] ?? ''); ?></textarea>
        </div>

        <div class="lpb-divider"></div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
          <div style="font-size:.88rem;font-weight:700;color:#1E3A5F">Quick Links</div>
          <button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddRow('footer-links-list','footer-link')">+ Add Link</button>
        </div>
        <div id="lpb-footer-links-list" class="lpb-repeater" style="margin-bottom:16px">
          <?php $fl = $footer_data['footer_links'] ?? []; if(!empty($fl)): foreach($fl as $fli => $link): ?>
          <div class="lpb-repeater-item" data-type="footer-link">
            <div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Link <?php echo $fli+1; ?></span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕</button></div>
            <div class="lpb-grid-2"><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Label</label><input type="text" class="lpb-input footer-link-label" value="<?php echo esc_attr($link['label']??''); ?>" placeholder="About Us"></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">URL</label><input type="text" class="lpb-input footer-link-url" value="<?php echo esc_attr($link['url']??''); ?>" placeholder="#gs-vs-about"></div></div>
          </div>
          <?php endforeach; else: ?>
          <div class="lpb-repeater-item" data-type="footer-link">
            <div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Link 1</span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest('.lpb-repeater-item').remove()">✕</button></div>
            <div class="lpb-grid-2"><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Label</label><input type="text" class="lpb-input footer-link-label" placeholder="Home"></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">URL</label><input type="text" class="lpb-input footer-link-url" placeholder="#"></div></div>
          </div>
          <?php endif; ?>
          <div class="lpb-repeater-footer"><button class="lpb-btn lpb-btn-ghost lpb-btn-sm" onclick="lpbAddRow('footer-links-list','footer-link')">+ Add Link</button></div>
        </div>

        <div class="lpb-field">
          <label class="lpb-toggle">
            <div class="lpb-toggle-track <?php echo !empty($footer_data['show_newsletter'])?'on':''; ?>" id="lpb-newsletter-toggle-track">
              <div class="lpb-toggle-thumb"></div>
            </div>
            <input type="checkbox" id="lpb-newsletter-show" style="display:none" <?php echo !empty($footer_data['show_newsletter'])?'checked':''; ?>>
            <span style="font-size:.88rem;color:#374151;font-weight:500">Show Newsletter Signup in Footer</span>
          </label>
        </div>
        <div class="lpb-field">
          <label class="lpb-label">Newsletter Placeholder Text</label>
          <input type="text" class="lpb-input lpb-footer-field" data-key="newsletter_placeholder" value="<?php echo esc_attr($footer_data['newsletter_placeholder'] ?? 'Enter your email...'); ?>" placeholder="Enter your email...">
        </div>
      </div>
    </div>

    <!-- ══ MOBILE SETTINGS ═════════════════════════════════════════════ -->
    <?php $lpb_md = $listing->mobile_data ?: []; ?>
    <div class="lpb-section" id="lpb-sec-mobile">
      <div class="lpb-section-head">
        <div class="lpb-section-icon">📱</div>
        <div>
          <div class="lpb-section-title">Mobile Settings</div>
          <div class="lpb-section-sub">Control what visitors see on mobile devices</div>
        </div>
      </div>
      <div class="lpb-body">
        <div class="lpb-design-group-title">📱 Mobile Visibility Toggles</div>
        <?php
        $lpb_mob_toggles = [
          ['show_wnav',      'Right-Side Navigation',   'Floating icon strip on the right edge of mobile screens',    $lpb_md['show_wnav']??1],
          ['float_cta',      'Floating CTA Bar',        'Fixed "Get Quote" bar at the bottom of mobile screens',      $lpb_md['float_cta']??1],
          ['show_wa',        'WhatsApp Button',         'Show the WhatsApp quick-connect button',                     $lpb_md['show_wa']??1],
          ['show_phone',     'Phone Button',            'Show the call button on mobile',                             $lpb_md['show_phone']??1],
          ['show_trust_bar', 'Trust Bar',               'Scrolling trust marquee strip',                              $lpb_md['show_trust_bar']??1],
          ['show_gallery',   'Photo Gallery Section',   'Show or hide the gallery on mobile',                         $lpb_md['show_gallery']??1],
          ['show_stats',     'Stats / Numbers Section', 'Show or hide the stats achievements section on mobile',      $lpb_md['show_stats']??1],
        ];
        foreach ($lpb_mob_toggles as [$k, $lbl, $hint, $val]): ?>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid #F1F5F9">
          <div>
            <div style="font-size:.87rem;font-weight:600;color:#1E293B"><?php echo esc_html($lbl); ?></div>
            <div style="font-size:.74rem;color:#94A3B8;margin-top:2px"><?php echo esc_html($hint); ?></div>
          </div>
          <label class="lpb-toggle" style="flex-shrink:0;margin-left:16px">
            <div class="lpb-toggle-track <?php echo $val ? 'on' : ''; ?>" id="lpb-mob-track-<?php echo esc_attr($k); ?>">
              <div class="lpb-toggle-thumb"></div>
            </div>
            <input type="hidden" id="lpb-mob-<?php echo esc_attr($k); ?>" value="<?php echo $val ? '1' : '0'; ?>">
          </label>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Save bar at bottom -->
    <div class="lpb-save-bar">
      <span class="lpb-save-status" id="lpb-bottom-status"></span>
      <div style="display:flex;gap:10px;align-items:center">
        <a href="<?php echo esc_url($preview_url); ?>" target="_blank" class="lpb-btn lpb-btn-ghost">👁 Preview Page</a>
        <?php if ( ! $lpb_is_admin && ($listing->status ?? 'draft') !== 'active' ): ?>
          <button onclick="lpbSubmitForReview()" class="lpb-btn" style="background:#7C3AED;color:#fff;padding:9px 24px">📋 Submit for Review</button>
        <?php endif; ?>
        <button onclick="lpbSave()" class="lpb-btn lpb-btn-save">💾 Save All Changes</button>
      </div>
    </div>

  </div><!-- .lpb-main -->
</div><!-- .lpb-layout -->

</div><!-- .lpb-root -->

<script>
/* ═══════════════════════════════════════════════════════════════════════
 * ⚠️  REMINDER — this JS is NOT vendor-facing. See the file-header
 * notice at the top of this file before touching any upload/quota/
 * context logic below. This file is admin-only and unreachable by
 * vendors; create-listing.php is the real Vendor Listing builder.
 * ═══════════════════════════════════════════════════════════════════════ */
(function(){
  var AJAX_URL = '<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
  var NONCE    = '<?php echo wp_create_nonce("gs_ajax"); ?>';
  var LID      = <?php echo $listing_id; ?>;

  // ── Section navigation ────────────────────────────────────────────
  window.lpbActivate = function(id) {
    document.querySelectorAll('.lpb-sidebar-item').forEach(function(el){ el.classList.remove('active'); });
    document.querySelectorAll('.lpb-section').forEach(function(el){ el.classList.remove('active'); });
    var si = document.querySelector('.lpb-sidebar-item[data-section="'+id+'"]');
    var se = document.getElementById('lpb-sec-'+id);
    if(si) si.classList.add('active');
    if(se) se.classList.add('active');
  };

  // ── Color sync for ALL color pickers (including lpb-cd- styling fields) ────
  document.querySelectorAll('.lpb-color-swatch input[type="color"]').forEach(function(picker){
    var fieldId = picker.id; // e.g. lpb-brand_color or lpb-cd-svc_card_bg
    var textId  = fieldId + '_text';
    var textEl  = document.getElementById(textId);
    if (!textEl) return;
    picker.addEventListener('input', function(){ textEl.value = this.value; });
    textEl.addEventListener('input', function(){
      var v = this.value.trim();
      if (/^#[0-9A-Fa-f]{6}$/.test(v)) picker.value = v;
    });
    textEl.addEventListener('blur', function(){
      var v = this.value.trim();
      if (!/^#[0-9A-Fa-f]{6}$/.test(v) && !/^#[0-9A-Fa-f]{3}$/.test(v)) {
        this.style.borderColor = '#EF4444';
      } else {
        this.style.borderColor = '';
        if (/^#[0-9A-Fa-f]{3}$/.test(v)) {
          this.value = '#' + v[1]+v[1]+v[2]+v[2]+v[3]+v[3];
          picker.value = this.value;
        }
      }
    });
  });

  // ── Toggle helper ─────────────────────────────────────────────────
  document.querySelectorAll('.lpb-toggle-track').forEach(function(track){
    track.addEventListener('click', function(){
      this.classList.toggle('on');
      var cb = this.nextElementSibling;
      if(cb && cb.type==='checkbox') cb.checked = this.classList.contains('on');
      // Mobile setting toggles use a hidden input instead of checkbox
      if(cb && cb.type==='hidden') cb.value = this.classList.contains('on') ? '1' : '0';
    });
  });

  // ── Item type toggle (auto-enable quote button for products) ──────
  window.lpbToggleQuoteBtn = function(sel) {
    var item = sel.closest('.lpb-repeater-item');
    var badge = item.querySelector('.lpb-type-badge');
    var track = item.querySelector('.quote-toggle-track');
    var cb = item.querySelector('.item-show-quote');
    if(sel.value==='product'){
      badge.className='lpb-type-badge lpb-type-product'; badge.textContent='📦 Product';
      if(track){track.classList.add('on');} if(cb){cb.checked=true;}
    } else {
      badge.className='lpb-type-badge lpb-type-service'; badge.textContent='🛠 Service';
    }
  };

  // ── Add repeater rows ─────────────────────────────────────────────
  var templates = {
    services: '<div class="lpb-repeater-item" data-type="services"><div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Service</span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest(\'.lpb-repeater-item\').remove()">✕ Remove</button></div><div class="lpb-grid-3" style="margin-bottom:10px"><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Title *</label><input type="text" class="lpb-input svc-name" placeholder="e.g. Passport Services"></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Emoji / Icon</label><input type="text" class="lpb-input svc-icon" placeholder="🛂 (or upload image)"></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Link (optional)</label><input type="text" class="lpb-input svc-link" placeholder="#gs-vs-contact"></div></div><div class="lpb-grid-2" style="margin-bottom:0"><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Image (overrides emoji if set)</label><div style="display:flex;align-items:center;gap:8px"><div class="lpb-upload-zone svc-img-zone" style="flex:1;padding:8px;cursor:pointer" onclick="lpbUploadSvcImage(this)"><div style="font-size:.75rem;color:#94A3B8">📤 Click to upload image</div></div><input type="hidden" class="svc-image" value=""></div></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Description (optional)</label><textarea class="lpb-input lpb-textarea svc-description" rows="2" style="resize:vertical;font-size:.82rem" placeholder="Brief description…"></textarea></div></div></div>',
    process: '<div class="lpb-repeater-item" data-type="process"><div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Step</span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest(\'.lpb-repeater-item\').remove()">✕</button></div><div class="lpb-grid-2"><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Title</label><input type="text" class="lpb-input proc-title" placeholder="Step title"></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Icon</label><input type="text" class="lpb-input proc-icon" placeholder="📋"></div></div></div>',
    stat: '<div class="lpb-repeater-item" data-type="stat"><div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Stat</span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest(\'.lpb-repeater-item\').remove()">✕</button></div><div class="lpb-grid-2"><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Number</label><input type="text" class="lpb-input stat-number" placeholder="142+"></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Label</label><input type="text" class="lpb-input stat-label" placeholder="Services"></div></div></div>',
    why: '<div class="lpb-repeater-item" data-type="why"><div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Benefit</span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest(\'.lpb-repeater-item\').remove()">✕</button></div><div class="lpb-grid-3"><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Title</label><input type="text" class="lpb-input why-title" placeholder="Fast Service"></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Icon</label><input type="text" class="lpb-input why-icon" placeholder="⚡"></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Description</label><input type="text" class="lpb-input why-desc" placeholder="24 hour turnaround"></div></div></div>',
    faq: '<div class="lpb-repeater-item" data-type="faq"><div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">FAQ</span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest(\'.lpb-repeater-item\').remove()">✕</button></div><div class="lpb-field" style="margin-bottom:10px"><label class="lpb-label" style="font-size:.7rem">Question</label><input type="text" class="lpb-input faq-question" placeholder="How long does it take?"></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Answer</label><textarea class="lpb-textarea faq-answer" rows="3"></textarea></div></div>',
    'footer-link': '<div class="lpb-repeater-item" data-type="footer-link"><div class="lpb-repeater-item-head"><span class="lpb-repeater-item-label">Link</span><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest(\'.lpb-repeater-item\').remove()">✕</button></div><div class="lpb-grid-2"><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Label</label><input type="text" class="lpb-input footer-link-label" placeholder="Home"></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">URL</label><input type="text" class="lpb-input footer-link-url" placeholder="#"></div></div></div>'
  };
  window.lpbAddRow = function(listId, type) {
    var list = document.getElementById('lpb-'+listId);
    var footer = list.querySelector('.lpb-repeater-footer');
    var tmpl = templates[type];
    if(!tmpl || !list) return;
    var div = document.createElement('div');
    div.innerHTML = tmpl;
    list.insertBefore(div.firstChild, footer);
  };

  // ── Add item (services/products) ──────────────────────────────────
  var itemTemplate = '<div class="lpb-repeater-item" data-type="item"><div class="lpb-repeater-item-head"><div style="display:flex;align-items:center;gap:8px"><span class="lpb-repeater-item-label">Item</span><span class="lpb-type-badge {BADGE_CLASS}">{BADGE_TEXT}</span></div><button class="lpb-btn lpb-btn-danger lpb-btn-sm" onclick="this.closest(\'.lpb-repeater-item\').remove()">✕ Remove</button></div><div class="lpb-grid-2" style="margin-bottom:10px"><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Item Type *</label><select class="lpb-select item-type" onchange="lpbToggleQuoteBtn(this)"><option value="service" {SVC_SEL}>🛠 Service</option><option value="product" {PRD_SEL}>📦 Product</option></select></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Title *</label><input type="text" class="lpb-input item-title" placeholder="Item title"></div></div><div class="lpb-grid-2" style="margin-bottom:10px"><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Category</label><input type="text" class="lpb-input item-category" placeholder="Category"></div><div class="lpb-field" style="margin:0"><label class="lpb-label" style="font-size:.7rem">Price</label><input type="text" class="lpb-input item-price" placeholder="₹499"></div></div><div class="lpb-field" style="margin-bottom:10px"><label class="lpb-label" style="font-size:.7rem">Description</label><textarea class="lpb-textarea item-description" rows="2"></textarea></div><div class="lpb-field" style="margin-bottom:10px"><label class="lpb-label" style="font-size:.7rem">Item Image</label><div style="display:flex;align-items:center;gap:10px"><div class="lpb-upload-zone" style="flex:1;padding:8px" onclick="lpbUploadItemImage(this)"><div style="font-size:.75rem;color:#94A3B8">Click to upload image</div></div><img src="" class="item-img-preview" style="display:none;width:70px;height:50px;object-fit:cover;border-radius:6px"><input type="hidden" class="item-image" value=""></div></div><div class="lpb-field" style="margin:0"><label class="lpb-toggle"><div class="lpb-toggle-track {QUOTE_TRACK} quote-toggle-track"><div class="lpb-toggle-thumb"></div></div><input type="checkbox" class="item-show-quote" style="display:none" {QUOTE_CHECKED}><span style="font-size:.82rem;color:#374151">Show "Get Quote" Button</span></label></div></div>';
  window.lpbAddItem = function(type) {
    var list = document.getElementById('lpb-items-list');
    var footer = list.querySelector('.lpb-repeater-footer');
    var isProduct = type === 'product';
    var html = itemTemplate
      .replace('{BADGE_CLASS}', isProduct?'lpb-type-product':'lpb-type-service')
      .replace('{BADGE_TEXT}', isProduct?'📦 Product':'🛠 Service')
      .replace('{SVC_SEL}', isProduct?'':'selected')
      .replace('{PRD_SEL}', isProduct?'selected':'')
      .replace('{QUOTE_TRACK}', isProduct?'on':'')
      .replace('{QUOTE_CHECKED}', isProduct?'checked':'');
    var div = document.createElement('div');
    div.innerHTML = html;
    // Attach toggle listener to new track
    div.querySelector('.lpb-toggle-track').addEventListener('click', function(){
      this.classList.toggle('on');
      var cb = this.nextElementSibling;
      if(cb && cb.type==='checkbox') cb.checked = this.classList.contains('on');
    });
    list.insertBefore(div.firstChild, footer);
  };

  // ── Upload helper ─────────────────────────────────────────────────
  /* ── Shared drag-drop upload utility ─────────────────────────────────────
     Works for all upload zones in the page builder.
     Drag a file onto the zone OR click to open file picker.
     lpbUpload      — generic zones (logo, banner, hero, about)
     lpbUploadFile  — core upload+callback, used by all three functions
  ─────────────────────────────────────────────────────────────────────── */
  function lpbUploadFile(file, zone, onSuccess, onError) {
    var origHTML = zone ? zone.innerHTML : '';
    if (zone) {
      zone.innerHTML = '<div style="display:flex;flex-direction:column;align-items:center;gap:6px;padding:8px">'
        + '<div style="width:28px;height:28px;border:3px solid #BFDBFE;border-top-color:#2563EB;border-radius:50%;animation:lpbSpin .7s linear infinite"></div>'
        + '<div style="font-size:.78rem;color:#2563EB">Uploading…</div></div>';
    }
    var fd = new FormData();
    fd.append('action', 'gs_upload_media');
    fd.append('nonce',  NONCE);
    fd.append('file',   file);
    fd.append('type',   'image');
    fetch(AJAX_URL, { method:'POST', body:fd })
      .then(function(r){ return r.json(); })
      .then(function(d) {
        if (d.success && d.data && d.data.url) {
          onSuccess(d.data.url);
        } else {
          if (zone) zone.innerHTML = origHTML;
          var msg = (d.data && d.data.message) ? d.data.message : 'Upload failed';
          onError(msg);
        }
      })
      .catch(function(e) {
        if (zone) zone.innerHTML = origHTML;
        onError('Network error');
      });
  }

  /* Add spinner keyframes once */
  if (!document.getElementById('lpb-spin-style')) {
    var st = document.createElement('style');
    st.id = 'lpb-spin-style';
    st.textContent = '@keyframes lpbSpin{to{transform:rotate(360deg)}}';
    document.head.appendChild(st);
  }

  /* Initialise drag-drop on a zone element */
  function lpbInitDragDrop(zone, onFileDrop) {
    zone.addEventListener('dragover', function(e) {
      e.preventDefault();
      e.stopPropagation();
      zone.classList.add('lpb-dragover');
    });
    zone.addEventListener('dragleave', function(e) {
      e.preventDefault();
      zone.classList.remove('lpb-dragover');
    });
    zone.addEventListener('drop', function(e) {
      e.preventDefault();
      e.stopPropagation();
      zone.classList.remove('lpb-dragover');
      var file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      if (file && file.type.startsWith('image/')) {
        onFileDrop(file);
      }
    });
  }

  /* Attach drag-drop to all static zones on page load */
  function lpbBindAllDragDrop() {
    /* Generic zones (logo, banner, hero, about etc.) */
    document.querySelectorAll('.lpb-upload-zone:not([data-dd-bound])').forEach(function(zone) {
      zone.setAttribute('data-dd-bound', '1');
      /* Add drop hint text */
      if (!zone.querySelector('.lpb-drop-hint')) {
        var hint = document.createElement('div');
        hint.className = 'lpb-drop-hint';
        hint.textContent = 'or drag & drop here';
        zone.appendChild(hint);
      }
      lpbInitDragDrop(zone, function(file) {
        var onclick = zone.getAttribute('onclick') || '';
        /* Dispatch to the right handler based on onclick attribute */
        if (onclick.indexOf('lpbUploadSvcImage') !== -1) {
          lpbDoSvcUpload(file, zone);
        } else if (onclick.indexOf('lpbUploadItemImage') !== -1) {
          lpbDoItemUpload(file, zone);
        } else {
          /* Generic lpbUpload zone — extract fieldId and previewId */
          var m = onclick.match(/lpbUpload\('([^']+)','([^']+)'/);
          if (m) lpbDoGenericUpload(file, zone, m[1], m[2]);
        }
      });
    });
  }

  function lpbDoGenericUpload(file, zone, fieldId, previewId) {
    lpbUploadFile(file, zone, function(url) {
      var hidden = document.getElementById('lpb-' + fieldId + '_hidden')
                || document.getElementById('lpb-' + fieldId);
      if (hidden) hidden.value = url;
      var prev = document.getElementById(previewId);
      if (prev) { prev.src = url; prev.style.display = 'block'; }
      if (zone) {
        zone.innerHTML = '<img src="' + url + '" style="width:100%;height:70px;object-fit:cover;border-radius:6px;display:block">'
                       + '<div style="font-size:.72rem;color:#059669;margin-top:4px">✅ Uploaded — click or drag to replace</div>';
      }
    }, function(msg) {
      var sb = document.getElementById('lpb-bottom-status');
      if (sb) { sb.textContent = '❌ ' + msg; sb.style.color = '#DC2626'; setTimeout(function(){ sb.textContent=''; }, 5000); }
    });
  }

  window.lpbUpload = function(fieldId, previewId, type) {
    var zone = document.querySelector('[onclick*="lpbUpload(\'' + fieldId + '\'"]');
    var input = document.createElement('input');
    input.type = 'file'; input.accept = 'image/*';
    input.onchange = function() {
      if (!this.files[0]) return;
      lpbDoGenericUpload(this.files[0], zone, fieldId, previewId);
    };
    input.click();
  };

  function lpbDoItemUpload(file, zone) {
    lpbUploadFile(file, zone, function(url) {
      var item = zone.closest('.lpb-repeater-item');
      if (item) {
        var imgField = item.querySelector('.item-image');
        var prev     = item.querySelector('.item-img-preview');
        if (imgField) imgField.value = url;
        if (prev) { prev.src = url; prev.style.display = 'block'; }
      }
      zone.innerHTML = '<img src="' + url + '" style="width:100%;height:60px;object-fit:cover;border-radius:6px;display:block">'
                     + '<div style="font-size:.7rem;color:#059669;margin-top:3px">✅ Click or drag to replace</div>';
      // drag-drop already bound — no rebind needed
    }, function(msg) {
      var sb = document.getElementById('lpb-bottom-status');
      if (sb) { sb.textContent = '❌ ' + msg; sb.style.color = '#DC2626'; }
    });
  }

  window.lpbUploadItemImage = function(zone) {
    if (!zone.getAttribute('data-dd-bound')) {
      zone.setAttribute('data-dd-bound', '1');
      if (!zone.querySelector('.lpb-drop-hint')) {
        var h = document.createElement('div');
        h.className = 'lpb-drop-hint';
        h.textContent = 'or drag & drop';
        zone.appendChild(h);
      }
      lpbInitDragDrop(zone, function(f){ lpbDoItemUpload(f, zone); });
    }
    var input = document.createElement('input');
    input.type = 'file'; input.accept = 'image/*';
    input.onchange = function() {
      if (!this.files[0]) return;
      lpbDoItemUpload(this.files[0], zone);
    };
    input.click();
  };

  // ── Service image upload (with drag-drop) ─────────────────────────
  function lpbDoSvcUpload(file, zone) {
    lpbUploadFile(file, zone, function(url) {
      var item = zone.closest('.lpb-repeater-item');
      if (item) {
        var imgField = item.querySelector('.svc-image');
        if (imgField) imgField.value = url;
        if (!item.querySelector('.svc-clear-btn')) {
          var clearBtn = document.createElement('button');
          clearBtn.type = 'button';
          clearBtn.className = 'svc-clear-btn';
          clearBtn.setAttribute('onclick', 'lpbClearSvcImage(this)');
          clearBtn.style.cssText = 'background:#fee2e2;color:#dc2626;border:none;border-radius:6px;padding:4px 8px;font-size:.72rem;cursor:pointer;white-space:nowrap';
          clearBtn.textContent = '✕ Clear';
          zone.parentNode.insertBefore(clearBtn, imgField);
        }
      }
      zone.innerHTML = '<img src="' + url + '" style="width:100%;height:54px;object-fit:cover;border-radius:6px;display:block">'
                     + '<div style="font-size:.7rem;color:#059669;margin-top:3px">✅ Click or drag to replace</div>';
      // drag-drop already bound — no rebind needed
    }, function(msg) {
      var sb = document.getElementById('lpb-bottom-status');
      if (sb) { sb.textContent = '❌ ' + msg; sb.style.color = '#DC2626'; }
    });
  }

  window.lpbUploadSvcImage = function(zone) {
    if (!zone.getAttribute('data-dd-bound')) {
      zone.setAttribute('data-dd-bound', '1');
      if (!zone.querySelector('.lpb-drop-hint')) {
        var h = document.createElement('div');
        h.className = 'lpb-drop-hint';
        h.textContent = 'or drag & drop';
        zone.appendChild(h);
      }
      lpbInitDragDrop(zone, function(f){ lpbDoSvcUpload(f, zone); });
    }
    var input = document.createElement('input');
    input.type = 'file'; input.accept = 'image/*';
    input.onchange = function() {
      if (!this.files[0]) return;
      lpbDoSvcUpload(this.files[0], zone);
    };
    input.click();
  };

  window.lpbClearSvcImage = function(btn) {
    var item = btn.closest('.lpb-repeater-item');
    if (!item) return;
    var imgField = item.querySelector('.svc-image');
    if (imgField) imgField.value = '';
    var zone = item.querySelector('.svc-img-zone');
    if (zone) zone.innerHTML = '<div style="font-size:.75rem;color:#94A3B8">📤 Click to upload image</div>';
    btn.remove();
  };

  // ── Collect data ──────────────────────────────────────────────────
  function collectHeroData() {
    var d = {};
    document.querySelectorAll('.lpb-hero-field').forEach(function(el){
      d[el.dataset.key] = el.value;
    });
    var hi = document.getElementById('lpb-hero_right_image_hidden');
    if(hi) d.hero_right_image = hi.value;
    return d;
  }

  function collectAboutData() {
    var d = {};
    document.querySelectorAll('.lpb-about-field').forEach(function(el){
      d[el.dataset.key] = el.value;
    });
    var ai = document.getElementById('lpb-about_image_hidden');
    if(ai) d.about_image = ai.value;
    var badges = [];
    for(var i=0;i<4;i++){
      var bh = document.getElementById('lpb-about_badge_'+i+'_hidden');
      if(bh && bh.value) badges.push(bh.value);
    }
    d.about_badges = badges;
    return d;
  }

  function collectItems() {
    var items = [];
    document.querySelectorAll('#lpb-items-list .lpb-repeater-item[data-type="item"]').forEach(function(row){
      var title = (row.querySelector('.item-title')||{}).value || '';
      if(!title) return;
      items.push({
        item_type:         (row.querySelector('.item-type')||{}).value || 'service',
        item_title:        title,
        name:              title,
        item_category:     (row.querySelector('.item-category')||{}).value || '',
        category:          (row.querySelector('.item-category')||{}).value || '',
        item_description:  (row.querySelector('.item-description')||{}).value || '',
        description:       (row.querySelector('.item-description')||{}).value || '',
        item_price:        (row.querySelector('.item-price')||{}).value || '',
        price:             (row.querySelector('.item-price')||{}).value || '',
        item_image:        (row.querySelector('.item-image')||{}).value || '',
        image:             (row.querySelector('.item-image')||{}).value || '',
        show_quote_button: (row.querySelector('.item-show-quote')||{}).checked || false
      });
    });
    return items;
  }

  function collectServices() {
    var services = [];
    document.querySelectorAll('#lpb-services-list .lpb-repeater-item[data-type="services"]').forEach(function(row){
      var name = (row.querySelector('.svc-name')||{}).value || '';
      if(!name) return;
      var svcObj = {
        name:        name,
        icon:        (row.querySelector('.svc-icon')||{}).value||'',
        image:       (row.querySelector('.svc-image')||{}).value||'',
        link:        (row.querySelector('.svc-link')||{}).value||'',
        description: (row.querySelector('.svc-description')||{}).value||''
      };
      services.push(svcObj);
    });
    return services;
  }

  function collectProcess() {
    var steps = [];
    document.querySelectorAll('#lpb-process-list .lpb-repeater-item[data-type="process"]').forEach(function(row){
      var title = (row.querySelector('.proc-title')||{}).value || '';
      if(!title) return;
      steps.push({ title: title, icon: (row.querySelector('.proc-icon')||{}).value||'' });
    });
    return steps;
  }

  function collectStats() {
    var stats = [];
    document.querySelectorAll('#lpb-stats-list .lpb-repeater-item[data-type="stat"]').forEach(function(row){
      var number = (row.querySelector('.stat-number')||{}).value || '';
      if(!number) return;
      stats.push({ number: number, stat_number: number, label: (row.querySelector('.stat-label')||{}).value||'', stat_label: (row.querySelector('.stat-label')||{}).value||'' });
    });
    return stats;
  }

  function collectWhy() {
    var why = [];
    document.querySelectorAll('#lpb-why-list .lpb-repeater-item[data-type="why"]').forEach(function(row){
      var title = (row.querySelector('.why-title')||{}).value || '';
      if(!title) return;
      why.push({ title: title, icon: (row.querySelector('.why-icon')||{}).value||'✅', description: (row.querySelector('.why-desc')||{}).value||'' });
    });
    return why;
  }

  function collectFaq() {
    var faqs = [];
    document.querySelectorAll('#lpb-faq-list .lpb-repeater-item[data-type="faq"]').forEach(function(row){
      var q = (row.querySelector('.faq-question')||{}).value || '';
      if(!q) return;
      faqs.push({ question: q, answer: (row.querySelector('.faq-answer')||{}).value||'' });
    });
    return faqs;
  }

  function collectFeedback() {
    var d = {};
    document.querySelectorAll('.lpb-feedback-field').forEach(function(el){ d[el.dataset.key]=el.value; });
    var show = document.getElementById('lpb-feedback-show');
    d.show_feedback = show ? show.checked : false;
    return d;
  }

  function collectFooter() {
    var d = {};
    document.querySelectorAll('.lpb-footer-field').forEach(function(el){ d[el.dataset.key]=el.value; });
    var links=[];
    document.querySelectorAll('#lpb-footer-links-list .lpb-repeater-item[data-type="footer-link"]').forEach(function(row){
      var lbl=(row.querySelector('.footer-link-label')||{}).value||'';
      if(lbl) links.push({label:lbl,url:(row.querySelector('.footer-link-url')||{}).value||''});
    });
    d.footer_links = links;
    var ns = document.getElementById('lpb-newsletter-show');
    d.show_newsletter = ns ? ns.checked : false;
    return d;
  }

  // ── Save ──────────────────────────────────────────────────────────
  // ── Collect customizer_data (styling controls) ───────────────────
  function collectCustomizerData() {
    var cd = {};
    // Read all .lpb-cd-field inputs (text/number/select)
    document.querySelectorAll('.lpb-cd-field').forEach(function(el) {
      var key = el.getAttribute('data-cd');
      if (!key) return;
      cd[key] = el.value;
    });
    return cd;
  }

  // ── LPB Slug helpers ──────────────────────────────────────────
  function lpbSlugFromTitle() {
    var te = document.getElementById('lpb-title');
    var se = document.getElementById('lpb-slug');
    if (!te || !se) return;
    se.value = te.value.toLowerCase()
      .replace(/[^a-z0-9\s-]/g,'').trim()
      .replace(/\s+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'').substring(0,200)
      || 'listing';
    gsToast && gsToast('Slug updated — save to apply.','info');
  }
  function lpbSlugSyncFromTitle(v) {
    var se = document.getElementById('lpb-slug');
    if (!se) return;
    var c = se.value;
    if (c===''||c==='untitled-listing'||c==='listing') {
      se.value = v.toLowerCase().replace(/[^a-z0-9\s-]/g,'').trim()
        .replace(/\s+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'').substring(0,200);
    }
  }

  window.lpbSave = function(silent) {
    var indicator = document.getElementById('lpb-save-indicator');
    var statusBar = document.getElementById('lpb-bottom-status');
    if(!silent){
      if(indicator) { indicator.textContent='Saving…'; indicator.style.color='rgba(255,255,255,.6)'; }
      if(statusBar) statusBar.textContent='Saving…';
    }

    var heroData = collectHeroData();

    var fd = new FormData();
    fd.append('action','gs_save_listing');
    fd.append('nonce', NONCE);
    fd.append('listing_id', LID);

    // Identity (title + slug)
    var lpbTitle = document.getElementById('lpb-title');
    var lpbSlug  = document.getElementById('lpb-slug');
    if (lpbTitle) fd.append('title', lpbTitle.value);
    if (lpbSlug && lpbSlug.value) fd.append('slug', lpbSlug.value);

    // Branding
    var bc = document.getElementById('lpb-brand_color');
    var bc2 = document.getElementById('lpb-brand_color2');
    fd.append('brand_color',  bc  ? bc.value  : '');
    fd.append('brand_color2', bc2 ? bc2.value : '');

    // Additional color fields
    ['accent_color','section_bg','text_color','muted_color',
     'logo_border_c','logo_bg','banner_overlay'].forEach(function(id){
      var el = document.getElementById('lpb-'+id);
      if (el) fd.append(id, el.value);
    });

    // Image style fields
    ['logo_radius','logo_shadow','logo_border_w','logo_padding',
     'banner_height','banner_radius','banner_opacity'].forEach(function(id){
      var el = document.getElementById('lpb-'+id);
      if (el) fd.append(id, el.value);
    });

    // Logo/Banner
    var logoUrl   = document.getElementById('lpb-logo_url');
    var bannerUrl = document.getElementById('lpb-banner_url');
    if(logoUrl)   fd.append('logo_url',   logoUrl.value);
    if(bannerUrl) fd.append('banner_url', bannerUrl.value);

    // Hero
    fd.append('hero_data',        JSON.stringify(heroData));

    // Trust bar
    var tb = document.getElementById('lpb-trust_bar_text');
    fd.append('trust_bar_text', tb ? tb.value : '');

    // About
    fd.append('about_data', JSON.stringify(collectAboutData()));

    // Services section heading
    var sst = document.getElementById('lpb-services_section_title');
    var ssd = document.getElementById('lpb-services_section_desc');
    fd.append('services_section_title', sst ? sst.value : '');
    fd.append('services_section_desc',  ssd ? ssd.value : '');

    // Process heading
    var pst = document.getElementById('lpb-process_section_title');
    fd.append('process_section_title', pst ? pst.value : '');

    // Repeater data
    fd.append('services_data',   JSON.stringify(collectServices()));
    fd.append('process_data',    JSON.stringify(collectProcess()));
    fd.append('items_data',      JSON.stringify(collectItems()));
    fd.append('stats_data',      JSON.stringify(collectStats()));
    fd.append('why_choose_data', JSON.stringify(collectWhy()));
    fd.append('faq_data',        JSON.stringify(collectFaq()));
    fd.append('feedback_data',   JSON.stringify(collectFeedback()));
    fd.append('footer_data',     JSON.stringify(collectFooter()));

    // Gallery (rich objects: {url, caption, tag})
    fd.append('gallery',       document.getElementById('lpb-gallery-data') ? document.getElementById('lpb-gallery-data').value : '[]');
    var gTitle = document.getElementById('lpb-gallery_title');
    if(gTitle) fd.append('gallery_title', gTitle.value);

    // Map embed
    var me = document.getElementById('lpb-map_embed');
    if(me) fd.append('map_embed', me.value);

    // Customizer styling data (section-specific controls)
    fd.append('customizer_data', JSON.stringify(collectCustomizerData()));

    // Mobile settings (show_wnav, float_cta, show_wa, etc.)
    var mobileData = {};
    document.querySelectorAll('[id^="lpb-mob-"]').forEach(function(el){
      var key = el.id.replace('lpb-mob-', '');
      mobileData[key] = el.value === '1' ? 1 : 0;
    });
    fd.append('mobile_data', JSON.stringify(mobileData));

    // Also sync products_data from items of type product (backward compat)
    var products = collectItems().filter(function(i){ return i.item_type==='product'; });
    var services = collectItems().filter(function(i){ return i.item_type==='service'; });
    fd.append('products_data', JSON.stringify(products));

    // Keep status as-is (don't change to pending on page builder save)
    fd.append('status', '<?php echo esc_js($listing->status ?? 'active'); ?>');

    // BUG-FIX: this promise is now RETURNED so callers (like
    // lpbSubmitForReview) can chain off the real save completion instead of
    // guessing a fixed delay — see the fix note there for why that mattered.
    return fetch(AJAX_URL, { method:'POST', body:fd })
      .then(r=>r.json())
      .then(d=>{
        if(d.success){
          if(!silent){
            if(indicator){ indicator.textContent='✅ Saved!'; setTimeout(function(){ indicator.textContent=''; },3000); }
            if(statusBar){ statusBar.textContent='✅ All changes saved successfully!'; statusBar.style.color='#059669'; setTimeout(function(){ statusBar.textContent=''; },4000); }
          }
        } else {
          // Failure is always surfaced, even for a "silent" save — a caller
          // chaining off this promise (lpbSubmitForReview) still needs to
          // know the save didn't succeed, and a vendor should never see a
          // save silently vanish.
          if(indicator){ indicator.textContent='❌ Save failed'; indicator.style.color='#FCA5A5'; }
          if(statusBar){ statusBar.textContent='❌ '+(d.data && d.data.message ? d.data.message : 'Failed to save.'); statusBar.style.color='#DC2626'; }
        }
        return d;
      })
      .catch(function(err){
        if(indicator){ indicator.textContent='❌ Error'; indicator.style.color='#FCA5A5'; }
        if(statusBar){ statusBar.textContent='❌ Network error.'; statusBar.style.color='#DC2626'; }
        throw err;
      });
  };

  // Bind drag-drop to all static upload zones
  lpbBindAllDragDrop();

  // Keyboard shortcut Ctrl+S
  document.addEventListener('keydown', function(e){
    if((e.ctrlKey||e.metaKey) && e.key==='s'){ e.preventDefault(); lpbSave(); }
  });

  // ── Submit for Review ────────────────────────────────────────────
  window.lpbSubmitForReview = function() {
    if (!confirm('Submit this listing for admin review?\n\nAll your current changes will be saved and the listing will be sent for review.')) return;
    var indicator = document.getElementById('lpb-save-indicator');
    var statusBar = document.getElementById('lpb-bottom-status');
    if (indicator) { indicator.textContent = 'Saving…'; indicator.style.color = 'rgba(255,255,255,.6)'; }
    if (statusBar) { statusBar.textContent = 'Saving changes…'; }

    // ── FIX: Previously this re-built a partial FormData that missed 20+ fields ──
    // (title, category, slug, phone, city, price, SEO, customizer, mobile, etc.)
    // Those missing fields defaulted to '' in saveListing() and WIPED the listing.
    // FIX: Step 1 — do a full save (same as lpbSave) to preserve ALL data.
    //      Step 2 — then do a status-only submit via gs_submit_listing.
    //
    // Real fix — root cause of the intermittent stuck-on-"Saving…" indicator
    // here: this used to fire the submit request after a hardcoded 1500ms
    // setTimeout("give lpbSave() time to complete") instead of actually
    // waiting for it. On a slow save (large listing, many repeater sections,
    // DB write pressure under load) that guess was too short: the submit
    // request fired while the save was still in flight, and when the save's
    // OWN .then() later resolved it overwrote the indicator/statusBar text
    // the submit flow had already written — leaving stale/stuck text behind,
    // with the actual timing making it intermittent rather than constant.
    // lpbSave() now returns its real promise, so this chains off genuine
    // completion instead of a guess, and a failed save is caught here too
    // (previously a failed silent save was never even checked — submit just
    // proceeded regardless).
    lpbSave(true).then(function(d){ // silent=true (no success toast from the save itself)
      if (!d || !d.success) {
        if (indicator) { indicator.textContent = '❌ Save failed'; indicator.style.color = '#FCA5A5'; }
        if (statusBar) { statusBar.textContent = '❌ ' + (d && d.data && d.data.message ? d.data.message : 'Could not save changes before submitting.'); statusBar.style.color = '#DC2626'; }
        return;
      }
      if (indicator) { indicator.textContent = 'Submitting…'; }
      if (statusBar) { statusBar.textContent = 'Submitting for review…'; }
      gsPost('gs_submit_listing', { listing_id: LID }, function(d2) {
        VE && (VE.dirty = false);
        if (indicator) { indicator.textContent = '✅ Submitted!'; setTimeout(function(){ indicator.textContent=''; }, 4000); }
        if (statusBar) { statusBar.textContent = '✅ Listing submitted for review! Admin will approve shortly.'; statusBar.style.color = '#059669'; }
        var submitBtn = document.querySelector('button[onclick="lpbSubmitForReview()"]');
        if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = '⏳ Pending Review'; submitBtn.style.opacity = '.6'; }
      }, function(m) {
        if (indicator) { indicator.textContent = '❌ Submit failed'; indicator.style.color = '#FCA5A5'; }
        if (statusBar) { statusBar.textContent = '❌ ' + m; statusBar.style.color = '#DC2626'; }
      });
    }).catch(function(){
      if (indicator) { indicator.textContent = '❌ Save failed'; indicator.style.color = '#FCA5A5'; }
      if (statusBar) { statusBar.textContent = '❌ Network error while saving. Submission cancelled.'; statusBar.style.color = '#DC2626'; }
    });
  };

  // ── Gallery builder ──────────────────────────────────────────────
  window.lpbSyncGallery = function() {
    var items = [];
    document.querySelectorAll('#lpb-gal-grid .lpb-gal-item').forEach(function(el){
      var url = el.dataset.url;
      if (!url) return;
      var cap = (el.querySelector('.lpb-gal-caption') || {}).value || '';
      var tag = (el.querySelector('.lpb-gal-tag') || {}).value || '';
      items.push({ url: url, caption: cap, tag: tag });
    });
    var hid = document.getElementById('lpb-gallery-data');
    if (hid) hid.value = JSON.stringify(items);
    var cnt = document.getElementById('lpb-gal-count');
    if (cnt) cnt.textContent = items.length + ' uploaded';
  };

  // Live sync when captions/tags change
  document.getElementById('lpb-gal-grid').addEventListener('change', function(e){
    if (e.target.classList.contains('lpb-gal-caption') || e.target.classList.contains('lpb-gal-tag')) {
      lpbSyncGallery();
    }
  });

  // Upload new gallery photos
  document.getElementById('lpb-gal-upload').addEventListener('change', function(){
    var files = Array.from(this.files);
    var grid  = document.getElementById('lpb-gal-grid');
    var addBtn = document.getElementById('lpb-gal-add-btn');
    files.forEach(function(file){
      var fd = new FormData();
      fd.append('action', 'gs_upload_media');
      fd.append('nonce',  NONCE);
      fd.append('file',   file);
      fd.append('type',   'gallery');

      // Show placeholder while uploading
      var ph = document.createElement('div');
      ph.style.cssText = 'border-radius:10px;border:1.5px solid #E2E8F0;aspect-ratio:1;display:flex;align-items:center;justify-content:center;font-size:1.5rem;background:#F8FAFC;color:#94A3B8';
      ph.textContent = '⏳';
      grid.insertBefore(ph, addBtn);

      fetch(AJAX_URL, { method:'POST', body:fd })
        .then(r => r.json())
        .then(function(d){
          if (d.success && d.data && d.data.url) {
            var url = d.data.url;
            var item = document.createElement('div');
            item.className = 'lpb-gal-item';
            item.dataset.url = url;
            item.dataset.caption = '';
            item.dataset.tag = '';
            item.style.cssText = 'position:relative;border-radius:10px;overflow:hidden;border:1.5px solid #E2E8F0';
            item.innerHTML =
              '<img src="'+url+'" style="width:100%;aspect-ratio:1;object-fit:cover;display:block">'
              +'<div style="padding:6px">'
              +'<input type="text" class="lpb-input lpb-gal-caption" value="" placeholder="Caption…" style="font-size:.72rem;padding:4px 7px;margin-bottom:4px">'
              +'<select class="lpb-select lpb-gal-tag" style="font-size:.72rem;padding:4px 7px">'
              +'<option value="">— Tag —</option>'
              +'<option value="Interior">Interior</option>'
              +'<option value="Exterior">Exterior</option>'
              +'<option value="Shop Front">Shop Front</option>'
              +'<option value="Team">Team</option>'
              +'<option value="Work Sample">Work Sample</option>'
              +'<option value="Equipment">Equipment</option>'
              +'<option value="Event">Event</option>'
              +'<option value="Other">Other</option>'
              +'</select></div>'
              +'<button onclick="this.closest(\'.lpb-gal-item\').remove();lpbSyncGallery()" style="position:absolute;top:5px;right:5px;background:rgba(0,0,0,.55);border:none;color:#fff;border-radius:50%;width:22px;height:22px;font-size:.75rem;cursor:pointer;display:flex;align-items:center;justify-content:center;line-height:1">✕</button>';
            grid.replaceChild(item, ph);
          } else {
            ph.textContent = '❌';
          }
          lpbSyncGallery();
        })
        .catch(function(){ ph.textContent = '❌'; });
    });
    this.value = '';
  });

  // Init count
  lpbSyncGallery();
})();
</script>
