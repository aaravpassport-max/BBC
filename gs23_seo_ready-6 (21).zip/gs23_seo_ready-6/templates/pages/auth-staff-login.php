<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( is_user_logged_in() ) {
    $dest = \GoodService\Core\Roles::is_moderator() ? home_url('/moderation/') : home_url('/vendor/login/');
    wp_redirect( $dest ); exit;
}
$platform = gs_setting('platform_name', 'GoodService');
$logo_url = gs_setting('logo_url', '');
$ajax_url = admin_url('admin-ajax.php');
$nonce    = wp_create_nonce('gs_ajax');
$forgot   = home_url('/forgot-password/');
?>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:linear-gradient(135deg,#0F172A 0%,#1E3A5F 50%,#0EA5E9 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.gsst-wrap{width:100%;max-width:420px}
.gsst-badge{text-align:center;margin-bottom:24px}
.gsst-pill{display:inline-flex;align-items:center;gap:8px;background:rgba(14,165,233,.18);border:1px solid rgba(14,165,233,.35);border-radius:99px;padding:8px 20px;color:#7DD3FC;font-size:.82rem;font-weight:600;text-transform:uppercase;letter-spacing:.04em}
.gsst-dot{width:8px;height:8px;border-radius:50%;background:#34D399;flex-shrink:0;animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
.gsst-logo{text-align:center;margin-bottom:28px}
.gsst-logo h1{font-size:1.5rem;font-weight:800;color:#fff;margin-bottom:4px}
.gsst-logo p{color:rgba(255,255,255,.6);font-size:.85rem}
.gsst-card{background:#fff;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,.3);padding:36px 32px}
.gsst-title{font-size:1.1rem;font-weight:700;color:#0F172A;margin-bottom:6px}
.gsst-sub{font-size:.83rem;color:#64748B;margin-bottom:24px}
.gsst-err,.gsst-ok{display:none;padding:12px 14px;border-radius:8px;font-size:.84rem;margin-bottom:16px;border-left:4px solid}
.gsst-err{background:#FEF2F2;color:#DC2626;border-color:#DC2626}
.gsst-ok{background:#F0FDF4;color:#059669;border-color:#059669}
.gsst-label{display:block;font-size:.78rem;font-weight:600;color:#475569;margin-bottom:6px;text-transform:uppercase;letter-spacing:.04em}
.gsst-field{position:relative;margin-bottom:16px}
.gsst-input{display:block;width:100%;padding:12px 14px;border:1.5px solid #E2E8F0;border-radius:9px;font-size:.92rem;color:#1E293B;background:#fff;outline:none;transition:border-color .18s,box-shadow .18s;font-family:inherit}
.gsst-input:focus{border-color:#0EA5E9;box-shadow:0 0 0 3px rgba(14,165,233,.12)}
.gsst-toggle{position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:1rem;color:#94A3B8;padding:2px}
.gsst-btn{display:block;width:100%;padding:13px;border:none;border-radius:10px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;transition:all .18s;text-align:center;background:linear-gradient(135deg,#0F172A,#0EA5E9);color:#fff;margin-top:8px}
.gsst-btn:hover{opacity:.92}
.gsst-btn:disabled{opacity:.55;cursor:not-allowed}
.gsst-links{display:flex;justify-content:space-between;align-items:center;margin-top:18px;font-size:.8rem}
.gsst-links a{color:#64748B;text-decoration:none}
.gsst-links a:hover{color:#0EA5E9}
.gsst-back{text-align:center;margin-top:20px;font-size:.82rem}
.gsst-back a{color:rgba(255,255,255,.6);text-decoration:none}
.gsst-back a:hover{color:#fff}
</style>

<div class="gsst-wrap">
  <div class="gsst-badge">
    <div class="gsst-pill"><span class="gsst-dot"></span>Staff Portal</div>
  </div>

  <div class="gsst-logo">
    <?php if($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($platform); ?>" style="height:44px;margin:0 auto 12px;display:block;border-radius:8px"><?php endif; ?>
    <h1><?php echo esc_html($platform); ?></h1>
    <p>Staff &amp; Moderation Access</p>
  </div>

  <div class="gsst-card">
    <div class="gsst-title">Staff Sign In</div>
    <div class="gsst-sub">Access the moderation and review dashboard.</div>

    <div id="st-err" class="gsst-err"></div>
    <div id="st-ok"  class="gsst-ok"></div>

    <div class="gsst-field">
      <label class="gsst-label">Email or Username</label>
      <input type="text" id="st-id" class="gsst-input"
        placeholder="staff@example.com"
        autocomplete="username" autocapitalize="none" spellcheck="false">
    </div>

    <div class="gsst-field">
      <label class="gsst-label">Password</label>
      <input type="password" id="st-pass" class="gsst-input"
        placeholder="Enter your password"
        autocomplete="current-password" style="padding-right:44px">
      <button class="gsst-toggle" onclick="stTogglePw()" type="button" tabindex="-1">👁</button>
    </div>

    <button class="gsst-btn" id="st-btn" onclick="stLogin()">Sign In to Staff Portal</button>

    <div class="gsst-links">
      <a href="<?php echo esc_url($forgot); ?>">Forgot password?</a>
      <a href="<?php echo esc_url(home_url('/vendor/login/')); ?>">← Other login</a>
    </div>
  </div>

  <div class="gsst-back"><a href="<?php echo esc_url(home_url('/')); ?>">← Back to <?php echo esc_html($platform); ?></a></div>
</div>

<script>
var GS_AJAX  = '<?php echo esc_js($ajax_url); ?>';
var GS_NONCE = '<?php echo esc_js($nonce); ?>';

function stTogglePw() {
  var el = document.getElementById('st-pass');
  el.type = el.type === 'password' ? 'text' : 'password';
}
function stShowErr(msg) {
  var el = document.getElementById('st-err');
  el.textContent = msg; el.style.display = 'block';
  document.getElementById('st-ok').style.display = 'none';
}
function stShowOk(msg) {
  var el = document.getElementById('st-ok');
  el.textContent = msg; el.style.display = 'block';
  document.getElementById('st-err').style.display = 'none';
}

function stLogin() {
  document.getElementById('st-err').style.display = 'none';
  var id   = document.getElementById('st-id').value.trim();
  var pass = document.getElementById('st-pass').value;
  if (!id || !pass) { stShowErr('Please enter your email / username and password.'); return; }

  var btn = document.getElementById('st-btn');
  btn.disabled = true; btn.textContent = 'Signing in…';

  var fd = new FormData();
  fd.append('action',   'gs_vendor_login');
  fd.append('nonce',    GS_NONCE);
  fd.append('email',    id);
  fd.append('password', pass);

  fetch(GS_AJAX, { method:'POST', body:fd, credentials:'same-origin' })
    .then(function(r){ return r.json(); })
    .then(function(r){
      btn.disabled = false; btn.textContent = 'Sign In to Staff Portal';
      if (r.success) {
        var dest = (r.data && r.data.redirect) ? r.data.redirect : '<?php echo esc_js(home_url('/moderation/')); ?>';
        // Enforce staff-only — if server sends to vendor dashboard, redirect to moderation
        if (dest.includes('/vendor/dashboard')) dest = '<?php echo esc_js(home_url('/moderation/')); ?>';
        stShowOk('✓ Login successful. Redirecting…');
        setTimeout(function(){ window.location.href = dest; }, 800);
      } else {
        stShowErr((r.data && r.data.message) ? r.data.message : 'Login failed. Check your credentials or contact your manager.');
      }
    })
    .catch(function(){
      btn.disabled = false; btn.textContent = 'Sign In to Staff Portal';
      stShowErr('Connection error. Please try again.');
    });
}

document.getElementById('st-pass').addEventListener('keydown', function(e){ if(e.key==='Enter') stLogin(); });
document.getElementById('st-id').addEventListener('keydown',   function(e){ if(e.key==='Enter') document.getElementById('st-pass').focus(); });
</script>
