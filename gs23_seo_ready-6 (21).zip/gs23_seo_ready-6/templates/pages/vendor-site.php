<?php
/**
 * Vendor One-Page Microsite Template — GoodService Platform v7
 * Kaagzaat-style dynamic listing page. All content driven by DB fields.
 *
 * Variables (set by Router::render_vendor_site):
 *   $vendor, $listings, $primary, $reviews, $review_avg
 *   $brand, $logo, $cover, $phone, $wa, $email, $city, $address, $color
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// ── Module engine master switch ──────────────────────────────────────────
// GS_USE_MODULE_ENGINE_ALL, when true, turns ON every individual
// GS_USE_MODULE_ENGINE_* flag's fixed/migrated behavior at once — a single
// switch to test everything together, instead of enabling 25 separate
// flags one at a time. It does NOT change what each flag actually does or
// how it's verified: every individual flag check below still runs the
// exact same, already-tested module code; this master switch is checked
// alongside each one, not instead of it. Deliberately NOT built as a
// wholesale replacement of the page's real section-ordering/visibility
// system ($_sec_order / $_sec_show, further down this file) with the newer
// ModuleRegistry-based "module assignment" concept — that system has no
// real per-vendor data yet and doesn't yet track per-vendor section order
// or show/hide choices, so switching to it now would risk regressing
// exactly the behavior vendors currently rely on. This master switch
// reuses the real, working system as-is and simply changes which code
// populates each section's content within it.
$_gs_all_modules_on = defined('GS_USE_MODULE_ENGINE_ALL') && GS_USE_MODULE_ENGINE_ALL;

// Real fix, the actual comprehensive, deployment-proof correction: this
// investigation directly proved that a fix placed earlier in Router.php
// was not reliably the code actually running there, despite being
// logically correct and directly tested. Rather than depend on that
// upstream fix having genuinely landed, this completely separate file
// re-validates $brand independently, right here, before ANY of the 10
// places below (WhatsApp popup, sticky bar, inquiry form text, about
// section, nav bar, etc.) ever reads it. This cannot be bypassed by
// whatever caused the upstream inconsistency, since it runs in this
// file's own execution, not Router.php's.
$_vs_platform_color = \GoodService\Core\Config::get( 'platform_color_primary', '#2563EB' );
if ( empty( $_vs_platform_color ) ) { $_vs_platform_color = '#2563EB'; } // Real fix: Config::get()'s default only applies to null, not empty string
$_vs_is_corrupted = fn( $v ) => $v !== null && $v !== '' && $_vs_platform_color && stripos( (string) $v, $_vs_platform_color ) !== false;
$_vs_brand_was_corrupt = isset( $brand ) && $_vs_is_corrupted( $brand );
if ( $_vs_brand_was_corrupt ) {
    $_vs_brand_fix = trim( (string) ( $primary->title ?? '' ) );
    if ( $_vs_brand_fix === '' || $_vs_is_corrupted( $_vs_brand_fix ) ) {
        global $wpdb;
        $_vs_vid = $primary->vendor_id ?? ( $vendor->id ?? 0 );
        if ( $_vs_vid ) {
            $_vs_bn = $wpdb->get_var( $wpdb->prepare(
                "SELECT business_name FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d LIMIT 1", $_vs_vid
            ) );
            $_vs_brand_fix = trim( (string) $_vs_bn );
        }
    }
    if ( $_vs_brand_fix === '' || $_vs_is_corrupted( $_vs_brand_fix ) ) {
        $_vs_brand_fix = trim( (string) \GoodService\Core\Config::get( 'platform_name', 'GoodService' ) );
    }
    if ( $_vs_brand_fix === '' || $_vs_is_corrupted( $_vs_brand_fix ) ) {
        $_vs_brand_fix = 'GoodService';
    }
    $brand = $_vs_brand_fix;
}
// Real feature: a direct, visible marker proving whether THIS specific
// file has picked up this update — verifiable the same way the
// Router.php marker was, since that technique is what actually
// resolved the earlier part of this investigation. If this comment is
// missing from the live page, this file has not been updated, even if
// Router.php has.

// Real feature, closing the identical gap found within Router.php but
// this time inside vendor-site.php itself: the same symptom has now
// shown up twice — a fix correct near the top of a large file, not
// reliably reflected thousands of lines later in that same file.
// Rather than trust $brand to stay correct across this file's full
// length, re-validates fresh, every single call, safe against whatever
// caused the earlier inconsistency.
if ( ! function_exists( 'gs_vs_safe_brand' ) ) {
    function gs_vs_safe_brand( $brand_val, $primary_obj, $vendor_obj ) {
        global $wpdb;
        $color = \GoodService\Core\Config::get( 'platform_color_primary', '#2563EB' );
        if ( empty( $color ) ) { $color = '#2563EB'; }
        $bad = fn( $v ) => $v !== null && $v !== '' && $color && stripos( (string) $v, $color ) !== false;
        if ( ! $bad( $brand_val ) ) { return $brand_val; }
        $fix = trim( (string) ( $primary_obj->title ?? '' ) );
        if ( $fix === '' || $bad( $fix ) ) {
            $vid = $primary_obj->vendor_id ?? ( $vendor_obj->id ?? 0 );
            if ( $vid ) {
                $fix = trim( (string) $wpdb->get_var( $wpdb->prepare(
                    "SELECT business_name FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d LIMIT 1", $vid
                ) ) );
            }
        }
        if ( $fix === '' || $bad( $fix ) ) {
            $fix = trim( (string) \GoodService\Core\Config::get( 'platform_name', 'GoodService' ) );
        }
        if ( $fix === '' || $bad( $fix ) ) { $fix = 'GoodService'; }
        return $fix;
    }
}

// Real fix — confirmed by live diagnostic (TypeError: sections.forEach is
// not a function, raw data showed as the literal string '"[]"' rather
// than a bare array): view_more_sections is saved as a JSON string
// nested inside each service/product item — the Manage Details builder's
// hidden input holds JSON.stringify(sections), and the generic repeater
// collection this form already uses just carries that string through
// as-is into services_data/products_data's own JSON. The top-level
// $json_fields decode loop above only decodes the OUTER array (each
// item's fields), never a field NESTED inside an item — so
// view_more_sections stayed a raw string, and wp_json_encode() on an
// already-JSON string produces a double-encoded string, not the array
// the frontend expects. This decodes it once, in one place, for every
// consumer (services and products/items both) rather than patching each
// of the three display call sites separately.

if ( ! function_exists( 'gs_vs_minify_css_safe' ) ) {
    /**
     * Safe CSS minification — strips only comments and blank lines, never
     * collapsing whitespace inside rules. Measured 11% real savings on
     * the actual ~127KB main stylesheet with zero risk of breaking a
     * selector that depends on specific spacing (e.g. a descendant
     * combinator), unlike aggressive minification.
     */
    function gs_vs_minify_css_safe( string $css ): string {
        // Step 1 — strip /* ... */ comments (including multi-line ones).
        // Safe: comments are never functional CSS, only documentation.
        $css = preg_replace( '#/\*.*?\*/#s', '', $css );

        // Step 2 — collapse consecutive blank lines left behind by step 1
        // (or already present in the source) down to a single newline.
        // Safe: blank lines carry no meaning in CSS.
        $css = preg_replace( "/\n\s*\n+/", "\n", $css );

        // Add future steps here, each as its own clearly-commented block —
        // e.g. a Step 3 stripping trailing semicolons before a closing
        // brace. Keeping each step isolated and named means adding one
        // doesn't require re-reasoning about how it might interact with
        // an existing regex; remove any single step just as easily by
        // deleting its block, without touching the others.

        return $css;
    }
}

if ( ! function_exists( 'gs_vs_field_label' ) ) {
    /**
     * Per-vendor customizable field label — the PHP-side counterpart to
     * the existing client-side _vsBWT() helper. Both read from the exact
     * same customizer_data key ($cd['wizard_text_{mode}']), so a vendor
     * renaming a field's label in the "Customize Wizard Text" admin panel
     * sees that change applied consistently in both the View Details
     * popup (rendered here, server-side) and the Wizard Step 1 display
     * (rendered client-side via _vsBWT()) — one edit, one source of
     * truth, no separate admin UI or data structure needed.
     *
     * @param array  $cd      The listing's customizer_data array.
     * @param string $mode    'services' or 'products' — matches the
     *                        wizard_text_{mode} key exactly.
     * @param string $key     The specific label's key, e.g. 'step1_highlights_label'.
     * @param string $default Fallback shown when the vendor hasn't customized it.
     */
    function gs_vs_field_label( array $cd, string $mode, string $key, string $default ): string {
        $overrides = $cd[ "wizard_text_{$mode}" ] ?? null;
        if ( is_array( $overrides ) && ! empty( $overrides[ $key ] ) ) {
            return $overrides[ $key ];
        }
        return $default;
    }
}

if ( ! function_exists( 'gs_vs_build_service_wizard_extra' ) ) {
    /**
     * Real fix — root cause of the "Get Quote" button on the Pricing-at-
     * a-Glance table showing fewer fields than the same service's own
     * card. Two independent places were each building this exact JSON
     * blob (full_description/duration/availability/highlights) for
     * vsOpenSvcEnquiry — the Services card, and this compact pricing
     * table — and they had drifted apart: the pricing table's version
     * never included availability at all. One shared builder now used
     * by both, so a future field can't drift out of sync between them
     * again. $duration_field exists because the two source shapes name
     * this field differently: the dedicated Services section's own data
     * calls it 'duration' directly, while Products & Services items call
     * it 'delivery_info'.
     */
    function gs_vs_build_service_wizard_extra( array $data, string $duration_field = 'duration' ): string {
        $highlights_raw = $data['highlights'] ?? $data['key_features'] ?? null;
        $highlights = is_array( $highlights_raw )
            ? $highlights_raw
            : array_filter( array_map( 'trim', explode( "\n", (string) $highlights_raw ) ) );
        return wp_json_encode( [
            'full_description' => $data['full_description'] ?? '',
            'duration'         => $data[ $duration_field ] ?? '',
            'availability'     => $data['availability'] ?? '',
            'highlights'       => array_values( $highlights ),
        ] );
    }
}

if ( ! function_exists( 'gs_vs_filter_css_by_visibility' ) ) {
    /**
     * Conditional CSS loading by section visibility — Phase 1. Strips CSS
     * blocks belonging exclusively to hidden sections, using ONLY the
     * prefix list below (sections whose CSS namespace is fully understood
     * and verified isolated, built during this same engagement). Every
     * other prefix in the file (legacy/shared sections, utility classes)
     * is left untouched — this is a deliberately conservative first phase,
     * not a full rewrite, to avoid risking a regression on CSS this
     * function's author doesn't have complete certainty about.
     *
     * Uses a brace-depth-aware scan rather than a regex — CSS can nest
     * rules inside @media blocks, which a naive "match to next }" regex
     * cannot safely handle. Any block this function isn't fully confident
     * is exclusively tied to one hidden section (e.g. a @media wrapper,
     * or a selector also referencing an unlisted/shared class) is always
     * kept, never stripped — safety over completeness.
     *
     * @param string   $css      The full captured CSS text (including the
     *                           <style> and </style> tags themselves —
     *                           they pass through unchanged since they
     *                           never match a selector pattern).
     * @param callable $sec_show The $_sec_show closure — same visibility
     *                           source of truth the HTML rendering uses.
     * @return string Filtered CSS.
     */
    function gs_vs_filter_css_by_visibility( string $css, callable $sec_show ): string {
        // section_key => CSS class prefix, verified exclusive to that
        // section (built and owned entirely within this engagement).
        $section_prefixes = [
            'highlights'      => 'vs-hl-',
            'amenities'       => 'vs-am-',
            'languages'       => 'vs-lang-',
            'facilities'      => 'vs-fac-',
            'awards'          => 'vs-awd-',
            'certifications'  => 'vs-awd-', // shares Awards' badge-wall classes by design
            'memberships'     => 'vs-mem-',
            'warranty'        => 'vs-war-',
            'terms'           => 'vs-terms-',
        ];

        $hidden_prefixes = [];
        // Group sections by their shared prefix first (e.g. Awards and
        // Certifications both use vs-awd-) — a prefix is only added to
        // the strip list when EVERY section using it is hidden, never if
        // even one of them is still visible and needs it. Confirmed this
        // matters via direct testing: the naive per-section loop would
        // have stripped vs-awd- whenever Awards alone was hidden, even
        // with Certifications still visible.
        $prefix_to_sections = [];
        foreach ( $section_prefixes as $key => $prefix ) {
            $prefix_to_sections[ $prefix ][] = $key;
        }
        foreach ( $prefix_to_sections as $prefix => $keys ) {
            $all_hidden = true;
            foreach ( $keys as $key ) {
                if ( $sec_show( $key ) ) { $all_hidden = false; break; }
            }
            if ( $all_hidden ) { $hidden_prefixes[] = $prefix; }
        }

        if ( empty( $hidden_prefixes ) ) { return $css; } // nothing hidden among the sections we understand — no-op, return unchanged

        $len = strlen( $css );
        $out = '';
        $i = 0;
        while ( $i < $len ) {
            $brace_pos = strpos( $css, '{', $i );
            if ( $brace_pos === false ) {
                $out .= substr( $css, $i );
                break;
            }
            $selector = substr( $css, $i, $brace_pos - $i );
            // Walk forward from the opening brace, tracking depth, to find
            // this block's true matching closing brace — correctly
            // handles a nested @media { selector { ... } } block.
            $depth = 1;
            $j = $brace_pos + 1;
            while ( $j < $len && $depth > 0 ) {
                if ( $css[ $j ] === '{' ) { $depth++; }
                elseif ( $css[ $j ] === '}' ) { $depth--; }
                $j++;
            }
            $block_end = $j;
            $full_block = substr( $css, $i, $block_end - $i );

            $strip = false;
            foreach ( $hidden_prefixes as $hp ) {
                if ( str_contains( $selector, $hp ) ) {
                    $only_hidden = true;
                    if ( preg_match_all( '/\.(vs-[a-z0-9-]+)/', $selector, $m ) ) {
                        foreach ( $m[1] as $found_class ) {
                            $matches_any_hidden = false;
                            foreach ( $hidden_prefixes as $hp2 ) {
                                if ( str_starts_with( '.' . $found_class, rtrim( $hp2, '-' ) ) || str_starts_with( $found_class . '-', $hp2 ) ) { $matches_any_hidden = true; break; }
                            }
                            if ( ! $matches_any_hidden ) { $only_hidden = false; break; }
                        }
                    }
                    if ( $only_hidden ) { $strip = true; }
                    break;
                }
            }

            if ( ! $strip ) { $out .= $full_block; }
            $i = $block_end;
        }
        return $out;
    }
}

if ( ! function_exists( 'gs_vs_img_display_style' ) ) {
    /**
     * Reusable image display controls — generalizes the exact fit/
     * position/zoom logic already proven correct in the Swiper slides
     * code (same valid-value whitelists, same clamping range), extended
     * with per-device height override, aspect-ratio, and border-radius.
     * Used by the 10 new sections' image fields so every one of them gets
     * the same professional display controls rather than each section
     * inventing its own.
     *
     * @param array  $s         Settings, e.g. ['fit'=>'cover','position'=>'center','zoom'=>100,'height_desktop'=>0,'height_mobile'=>0,'aspect_ratio'=>'','radius'=>0]
     * @param bool   $is_mobile Whether to use the mobile height override
     * @return array ['container' => 'css string', 'img' => 'css string']
     */
    function gs_vs_img_display_style( array $s, bool $is_mobile = false ): array {
        $valid_fits = [ 'cover', 'contain', 'fill', 'scale-down', 'none' ];
        $valid_positions = [ 'center', 'top', 'bottom', 'left', 'right', 'top left', 'top right', 'bottom left', 'bottom right' ];

        $raw_fit = $s['fit'] ?? 'cover';
        $raw_position = $s['position'] ?? 'center';
        $fit      = in_array( $raw_fit, $valid_fits, true ) ? $raw_fit : 'cover';
        $position = in_array( $raw_position, $valid_positions, true ) ? $raw_position : 'center';
        // Custom X/Y position overrides the preset when both are given.
        if ( isset( $s['position_x'] ) && isset( $s['position_y'] ) && $s['position_x'] !== '' && $s['position_y'] !== '' ) {
            $position = (int) $s['position_x'] . '% ' . (int) $s['position_y'] . '%';
        }
        $zoom     = max( 50, min( 200, (int) ( $s['zoom'] ?? 100 ) ) );

        $img_style = "object-fit:{$fit};object-position:{$position};" . ( $zoom !== 100 ? 'transform:scale(' . ( $zoom / 100 ) . ');' : '' );

        $height = (int) ( $is_mobile ? ( $s['height_mobile'] ?? 0 ) : ( $s['height_desktop'] ?? 0 ) );
        $radius = (int) ( $s['radius'] ?? 0 );
        $overflow = ( $s['overflow'] ?? 'hidden' ) === 'visible' ? 'visible' : 'hidden';
        $aspect = trim( (string) ( $s['aspect_ratio'] ?? '' ) );

        $container_style = "overflow:{$overflow};";
        if ( $radius > 0 ) { $container_style .= "border-radius:{$radius}px;"; }
        if ( $height > 0 ) {
            $container_style .= "height:{$height}px;";
        } elseif ( $aspect !== '' && preg_match( '/^\d+\s*\/\s*\d+$/', $aspect ) ) {
            $container_style .= "aspect-ratio:{$aspect};";
        }

        return [ 'container' => $container_style, 'img' => $img_style ];
    }
}

if ( ! function_exists( 'gs_vs_section_style_vars' ) ) {
    /**
     * Shared element-style-control resolver for section-level customization
     * (border-radius, shadow, colors, sizes, gaps, etc.).
     *
     * WHY THIS EXISTS: every section used to hardcode these values directly
     * in shared CSS classes (e.g. ".gs-beauty-card{border-radius:4px}"),
     * which meant two problems: (1) a class shared by lookalike markup in
     * two different sections could only ever have ONE value platform-wide —
     * changing it for one section changed it for all of them — and (2) the
     * only way to make each section independently customizable without
     * duplicating this sanitization logic in every module would be to
     * copy/paste it per section, which is exactly the "unnecessary
     * duplicate logic" this helper avoids.
     *
     * HOW ISOLATION WORKS: this function only ever transforms ONE section's
     * own saved settings array into a CSS custom-property declaration
     * STRING (e.g. "--gs-bf-media-radius:6px;--gs-bf-check-color:#C9A867;").
     * The caller wraps that string in "#vs-sec-{that_section}{...}" so the
     * variables only exist inside that section's own DOM subtree. The
     * section's CSS then reads them with var(--the-var, fallback) — the
     * SAME var name can be reused in a completely different section's own
     * scoped block with a completely different value, because CSS custom
     * properties resolve against the nearest enclosing scope, never
     * globally. Two sections can never cross-contaminate through this
     * mechanism, by construction, not by convention.
     *
     * HOW THIS KEEPS LOAD DOWN: no DB query (reads from the already-loaded
     * $cd blob), no per-element inline style="" repeated on every card (one
     * short var block per section instead), and the caller is expected to
     * only invoke this — and only emit the returned string — when the
     * section itself is visible ($_sec_show()), matching the existing
     * per-section CSS gating convention already used throughout this file.
     *
     * @param array $saved  The section's own saved sub-array, e.g.
     *                      $cd['beauty_facilities_style'] — never any other
     *                      section's key.
     * @param array $schema Map of setting-name => [
     *                        'var'     => CSS custom property name to emit,
     *                        'type'    => 'px'|'em'|'color'|'shadow'|'raw',
     *                        'default' => fallback value if unset/invalid,
     *                        'min','max' => optional numeric clamp (px/em),
     *                      ]
     * @return string CSS custom-property declarations, semicolon-joined,
     *                 ready to place inside a "{...}" rule body. Never
     *                 includes a selector — the caller supplies the scope.
     */
    function gs_vs_section_style_vars( array $saved, array $schema ): string {
        $decls = '';
        foreach ( $schema as $key => $spec ) {
            $var     = $spec['var'];
            $type    = $spec['type'] ?? 'raw';
            $default = $spec['default'] ?? '';
            $raw     = $saved[ $key ] ?? null;
            switch ( $type ) {
                case 'px':
                    $n = is_numeric( $raw ) ? (float) $raw : $default;
                    if ( isset( $spec['min'] ) ) { $n = max( $spec['min'], $n ); }
                    if ( isset( $spec['max'] ) ) { $n = min( $spec['max'], $n ); }
                    $value = $n . 'px';
                    break;
                case 'em':
                    $n = is_numeric( $raw ) ? (float) $raw : $default;
                    if ( isset( $spec['min'] ) ) { $n = max( $spec['min'], $n ); }
                    if ( isset( $spec['max'] ) ) { $n = min( $spec['max'], $n ); }
                    $value = $n . 'em';
                    break;
                case 'rem':
                    $n = is_numeric( $raw ) ? (float) $raw : $default;
                    if ( isset( $spec['min'] ) ) { $n = max( $spec['min'], $n ); }
                    if ( isset( $spec['max'] ) ) { $n = min( $spec['max'], $n ); }
                    $value = $n . 'rem';
                    break;
                case 'color':
                    // Only accept well-formed hex/rgb(a)/hsl(a)/'transparent'
                    // — never pass raw vendor input straight into a <style>
                    // block.
                    $candidate = is_string( $raw ) ? trim( $raw ) : '';
                    $value = ( $candidate === 'transparent' || ( $candidate !== '' && preg_match( '/^(#[0-9a-fA-F]{3,8}|rgba?\([0-9.,%\s]+\)|hsla?\([0-9.,%\s]+\))$/', $candidate ) ) )
                        ? $candidate : $default;
                    break;
                case 'shadow':
                    // Constrained to "off" or the platform default — full
                    // free-text box-shadow injection is not accepted from
                    // vendor input.
                    $value = ( $raw === 'none' ) ? 'none' : $default;
                    break;
                default:
                    $value = is_scalar( $raw ) && $raw !== '' ? (string) $raw : $default;
            }
            $decls .= $var . ':' . $value . ';';
        }
        return $decls;
    }
}

if ( ! function_exists( 'gs_vs_compose_section_bg' ) ) {
    /**
     * Shared section-BACKGROUND composer — reused by every section that
     * gets a "Section Background" control (color / image+overlay / none),
     * so this sanitization logic exists exactly once, not once per module.
     *
     * @param array $s {
     *   @type string $bg_type    'none' | 'color' | 'image'
     *   @type string $bg_color   hex/rgb(a)/hsl(a), used when bg_type=color
     *   @type string $bg_image   image URL, used when bg_type=image
     *   @type string $overlay_color hex, used when bg_type=image
     *   @type float  $overlay_opacity 0–1, used when bg_type=image
     * }
     * @return string A ready-to-use CSS `background` shorthand value.
     */
    function gs_vs_compose_section_bg( array $s ): string {
        $type = in_array( $s['bg_type'] ?? 'none', [ 'none', 'color', 'image' ], true ) ? $s['bg_type'] : 'none';
        if ( $type === 'color' ) {
            $c = is_string( $s['bg_color'] ?? null ) ? trim( $s['bg_color'] ) : '';
            return ( $c !== '' && preg_match( '/^(#[0-9a-fA-F]{3,8}|rgba?\([0-9.,%\s]+\)|hsla?\([0-9.,%\s]+\))$/', $c ) ) ? $c : 'transparent';
        }
        if ( $type === 'image' && ! empty( $s['bg_image'] ) ) {
            $url = esc_url( (string) $s['bg_image'] );
            if ( $url === '' ) { return 'transparent'; }
            $oc = is_string( $s['overlay_color'] ?? null ) && preg_match( '/^#[0-9a-fA-F]{3,8}$/', trim( $s['overlay_color'] ) )
                ? trim( $s['overlay_color'] ) : '#000000';
            $oo = is_numeric( $s['overlay_opacity'] ?? null ) ? max( 0, min( 1, (float) $s['overlay_opacity'] ) ) : 0;
            $r = hexdec( substr( $oc, 1, 2 ) ); $g = hexdec( substr( $oc, 3, 2 ) ); $b = hexdec( substr( $oc, 5, 2 ) );
            return "linear-gradient(rgba({$r},{$g},{$b},{$oo}),rgba({$r},{$g},{$b},{$oo})),url('{$url}') center/cover no-repeat";
        }
        return 'transparent';
    }
}

if ( ! function_exists( 'gs_vs_normalize_view_more_sections' ) ) {
    function gs_vs_normalize_view_more_sections( $list ) {
        if ( ! is_array( $list ) ) { return $list; }
        foreach ( $list as &$entry ) {
            if ( ! is_array( $entry ) || empty( $entry['view_more_sections'] ) ) { continue; }
            if ( is_string( $entry['view_more_sections'] ) ) {
                $entry['view_more_sections'] = json_decode( $entry['view_more_sections'], true ) ?: [];
            }
        }
        unset( $entry );
        return $list;
    }
}


/* ── Subscription plan: check allow_inquiry_module and allow_booking_module ─ */
// Gate: fetch the vendor's active subscription plan flags.
// If the vendor has no active/trialing subscription, or their plan has
// allow_inquiry_module=0, the inquiry modules section is completely hidden
// from the public page and all related AJAX is blocked server-side.
$_can_inquiry = false;
$_can_booking = false;
if ( isset( $vendor ) && $vendor ) {
    global $wpdb;
    $_pfx_vs = $wpdb->prefix . 'gs_';
    $_plan_flags = $wpdb->get_row( $wpdb->prepare(
        "SELECT sp.allow_inquiry_module, sp.allow_booking_module
         FROM {$_pfx_vs}subscriptions sub
         LEFT JOIN {$_pfx_vs}subscription_plans sp ON sp.id = sub.plan_id
         WHERE sub.vendor_id = %d
           AND sub.status IN ('active','trialing')
         ORDER BY sub.id DESC LIMIT 1",
        (int) $vendor->id
    ) );
    if ( $_plan_flags ) {
        $_can_inquiry = (bool) $_plan_flags->allow_inquiry_module;
        $_can_booking = (bool) $_plan_flags->allow_booking_module;
    }
    unset( $_pfx_vs, $_plan_flags );
}
// Real fix: the generic "Send Enquiry / Get Free Quote" popup (#vs-inq-overlay,
// action gs_submit_lead, table wp_gs_leads) was incorrectly wrapped in
// $_can_inquiry — the premium plan flag meant only for the separate,
// category-specific "Inquiry Modules" dynamic-form feature
// (inquiry_modules_data, action gs_submit_inquiry). submitLead() itself has
// no plan check, the 'leads' module is hardcoded core=true (always on), and
// the vendor's inquiry list (getInquiries()) has no plan restriction either
// — so gating the popup's UI behind $_can_inquiry silently hid a free
// feature and meant its submissions could never be created in the first
// place. The popup is always available; only the genuinely premium
// Inquiry Modules section (line ~219) remains behind $_can_inquiry.
$_can_lead_popup = true;

// C8 FIX: Enforce subscription feature flags on the public listing page.
// Previously gs_vendor_can() was only called in listing-detail.php (dead code path).
// These flags are now applied here so the live vendor-site.php respects the plan.
// The vendor's user_id comes from $listing->vendor_user_id (fetched in Router SELECT).
$_plan_vendor_user_id = (int) ( $listing->vendor_user_id ?? 0 );
if ( $_plan_vendor_user_id ) {
    $_sub_flags = \GoodService\Service\SubscriptionService::get_active( $_plan_vendor_user_id );
    // Phone: hide if plan has show_phone=0
    if ( $_sub_flags && ! (bool)( $_sub_flags->show_phone ?? 1 ) ) {
        $phone = '';
    }
    // Email: hide if plan has show_email=0
    if ( $_sub_flags && ! (bool)( $_sub_flags->show_email ?? 1 ) ) {
        $email = '';
    }
    // Website: hide if plan has show_website=0
    if ( $_sub_flags && ! (bool)( $_sub_flags->show_website ?? 1 ) ) {
        $website = '';
    }
    unset( $_sub_flags );
}
unset( $_plan_vendor_user_id );

$brand_color  = ( $primary && ! empty( $primary->brand_color  ) ) ? $primary->brand_color  : ( $color ?: '#F5A623' );
$brand_color2 = ( $primary && ! empty( $primary->brand_color2 ) ) ? $primary->brand_color2 : '#1E3A5F';

/* ── Decode all JSON blobs (safe: handles string OR already-decoded array) ── */
$json_fields = [ 'hero_data','about_data','items_data','feedback_data','footer_data',
                 'services_data','products_data','process_data','faq_data','why_choose_data','stats_data','gallery',
                 'customizer_data','mobile_data','service_categories','product_categories',
                 // ── Premium sections ──
                 'team_data','clients_data','pricing_data','portfolio_data','testimonials_data' ];
foreach ( $json_fields as $f ) {
    if ( ! $primary ) break;
    if ( ! isset( $primary->$f ) ) {
        $primary->$f = [];
    } elseif ( is_string( $primary->$f ) ) {
        $primary->$f = json_decode( $primary->$f, true ) ?: [];
    }
    // If already an array (decoded by Router), leave it as-is.
}

/* ── Hero data shorthand ─────────────────────────────── */
$hd = ( $primary && ! empty( $primary->hero_data ) ) ? $primary->hero_data : [];
$ad = ( $primary && ! empty( $primary->about_data ) ) ? $primary->about_data : [];
$fd = ( $primary && ! empty( $primary->feedback_data ) ) ? $primary->feedback_data : [];
$ftd = ( $primary && ! empty( $primary->footer_data ) ) ? $primary->footer_data : [];

/* ── Items: Products & Services card grid — ONLY from items_data or products_data.
   services_data belongs EXCLUSIVELY to the Services Category section (#vs-sec-services).
   It must NEVER appear here — these are two completely independent sections. ─── */
$all_items = [];
if ( $primary ) {
    if ( ! empty( $primary->items_data ) ) {
        // Page builder items (new canonical format)
        $all_items = gs_vs_normalize_view_more_sections( $primary->items_data );
    } else {
        // Listing form legacy format — products_data ONLY (services_data stays in services section)
        foreach ( (array)($primary->products_data ?? []) as $p ) {
            if ( ! empty( $p['name'] ) ) {
                $all_items[] = [
                    'item_type'        => $p['item_type']      ?? 'product',
                    'item_title'       => $p['name'],
                    'item_category'    => $p['category']        ?? '',
                    'item_price'       => $p['price']           ?? '',
                    'item_description' => $p['description']     ?? '',
                    'item_image'       => $p['image']           ?? '',
                    'show_quote_button'=> !empty($p['show_quote_button']),
                    'view_more_sections' => is_string( $p['view_more_sections'] ?? null ) ? ( json_decode( $p['view_more_sections'], true ) ?: [] ) : ( $p['view_more_sections'] ?? [] ),
                    'category_id'      => $p['category_id']     ?? '',
                    'full_description' => $p['full_description'] ?? '',
                    'key_features'     => $p['key_features']     ?? '',
                    // Real fix — this transform is the single source
                    // every vendor using the standard admin form
                    // actually goes through (products_data is the
                    // only place the form saves to), and it was
                    // silently dropping these three fields before
                    // they ever reached the popup at all. Confirmed:
                    // this explains both the missing image gallery
                    // and, going back further, why availability/
                    // delivery_info never actually reached the
                    // inquiry wizard either, despite that fix being
                    // verified correct in isolation earlier — neither
                    // fix was ever broken, this transform just never
                    // let their input reach them on a real page.
                    'additional_images' => is_array( $p['additional_images'] ?? null ) ? $p['additional_images'] : [],
                    'availability'      => $p['availability']    ?? '',
                    'delivery_info'     => $p['delivery_info']   ?? '',
                ];
            }
        }
    }
}

/* ── Nav: only sections that have data ──────────────── */
$nav = [];
$hero_heading = $hd['hero_left_heading'] ?? gs_vs_safe_brand( $brand, $primary, $vendor );
// About always shows — use any available content
$about_desc_check = $ad['about_description']
    ?? $vendor->bio
    ?? ($primary ? ($primary->full_desc ?: $primary->short_desc) : '');
// About: show only if vendor has description, bio, or about section data
$_has_about_content = !empty($about_desc_check) || !empty($ad['about_description']) || !empty($primary->short_desc ?? '') || !empty($vendor->bio ?? '');
if ($_has_about_content) $nav['about'] = 'About';
if ( $primary && ! empty( $primary->services_data ) )                                 $nav['services'] = 'Services';
if ( $primary && ! empty( $primary->process_data ) )                                  $nav['process']  = 'How It Works';
if ( ! empty( $all_items ) )                                                           $nav['items']    = 'Listings';
if ( $primary && ! empty( $primary->gallery ) )                                        $nav['gallery']  = 'Gallery';
if ( $primary && ! empty( $primary->stats_data ) )                                     $nav['stats']    = 'Numbers';
if ( $primary && ! empty( $primary->why_choose_data ) )                                $nav['why']      = 'Why Us';
// ── New premium sections — checked via the cheap LENGTH()-based flag,
//    not the actual field, which is deliberately empty here (real content
//    is fetched later, only for sections confirmed non-empty — see
//    fetch_premium_section_content() further down this file). ──
if ( $primary && ! empty( $primary->_premium_has_content['team_data'] ?? false ) )         $nav['team']        = 'Team';
if ( $primary && ! empty( $primary->_premium_has_content['clients_data'] ?? false ) )      $nav['clients']     = 'Clients';
if ( $primary && ! empty( $primary->_premium_has_content['pricing_data'] ?? false ) )      $nav['pricing']     = 'Pricing';
if ( $primary && ! empty( $primary->_premium_has_content['portfolio_data'] ?? false ) )    $nav['portfolio']   = 'Portfolio';
if ( $primary && ! empty( $primary->_premium_has_content['testimonials_data'] ?? false ) ) $nav['testimonials']= 'Testimonials';
// Reviews: show nav link whenever the vendor's feedback setting allows it,
// matching the section itself — which now always renders when enabled,
// with a real empty state when there are no reviews yet (not just hidden).
if ( ( $primary->feedback_data['show_reviews'] ?? '1' ) !== '0' ) $nav['reviews'] = 'Reviews';
if ( $primary && ! empty( $primary->faq_data ) )                                       $nav['faq']      = 'FAQ';
// Contact: show only when vendor has at least phone, email, whatsapp, or address
if (!empty($phone) || !empty($email) || !empty($wa) || !empty($address)) $nav['contact'] = 'Contact';
// Inquiry modules nav registration — only if plan allows inquiry modules
$_inq_modules_data = array();
if ( $_can_inquiry && $primary && ! empty( $primary->inquiry_modules_data ) ) {
    $_inq_raw = json_decode( $primary->inquiry_modules_data, true );
    if ( is_array( $_inq_raw ) ) {
        foreach ( $_inq_raw as $_inq_slug => $_inq_cfg ) {
            if ( ! empty( $_inq_cfg['enabled'] ) ) {
                $_inq_def = \GoodService\Service\InquiryFormService::get( $_inq_slug );
                if ( $_inq_def ) {
                    $_inq_modules_data[ $_inq_slug ] = array_merge( $_inq_def, (array)$_inq_cfg );
                    $nav[ 'inq_' . $_inq_slug ] = $_inq_def['icon'] . ' ' . $_inq_def['name'];
                }
            }
        }
    }
}


$wa_clean  = preg_replace( '/[^0-9]/', '', $wa );
$verified  = isset( $vendor->verification_status ) && $vendor->verification_status === 'verified';

// Part 25.1 — Phone obfuscation: mask last 5 digits, reveal on click
function gs_mask_phone( string $phone ): string {
    $clean = preg_replace( '/[^0-9+]/', '', $phone );
    if ( strlen( $clean ) >= 8 ) {
        return substr( $clean, 0, -5 ) . 'XXXXX';
    }
    return $phone;
}
$_phone_masked = $phone ? gs_mask_phone( $phone ) : '';

// Part 12.2 — Neighbourhood social proof data
$_nb_count = (int)($vendor_profile->neighbourhood_count ?? 0);
$_nb_area  = $vendor_profile->neighbourhood_area ?? '';

// Part 12.2b — Response time text, computed early so both the mobile
// and desktop sticky bars can use it (real fix: this was previously
// only computed right before the desktop bar, well after the mobile
// bar had already rendered, so mobile visitors never saw it at all).
$_avg_reply = $vendor_profile->avg_reply_minutes ?? 0;
$_reply_txt = '';
if ( $_avg_reply > 0 ) {
    if ( $_avg_reply < 60 ) { $_reply_txt = 'Replies in ~' . (int) $_avg_reply . ' min'; }
    elseif ( $_avg_reply < 120 ) { $_reply_txt = 'Replies in ~1 hour'; }
    else { $_reply_txt = 'Replies in ~' . round( $_avg_reply / 60 ) . ' hours'; }
}
// Part 12.3 — Load document verification badges
$_ver_docs = [];
if ( $vendor ) {
    $_ver_raw = $wpdb->get_results( $wpdb->prepare(
        "SELECT badge_type FROM {$pfx}verification_docs
         WHERE vendor_id = %d AND status = 'approved' AND badge_type != ''",
        (int) $vendor->id
    ) );
    foreach ( $_ver_raw as $_vd ) {
        $_ver_docs[] = $_vd->badge_type;
    }
}
$_badge_map = [
    'aadhaar'             => [ '🪪', 'ID on File',        '#F0FDF4', '#059669' ],
    'gst'                 => [ '📋', 'GST on File',       '#EFF6FF', '#2563EB' ],
    'trade_licence'       => [ '📜', 'Licence on File',   '#F5F3FF', '#7C3AED' ],
    'police_verification' => [ '🛡️', 'Police Doc on File', '#FEF3C7', '#B45309' ],
    'platform_verified'   => [ '✅', 'GS Reviewed',        '#ECFDF5', '#059669' ],
];
$trust_bar           = $primary?->trust_bar_text ?? '';
$gallery_title_field = $primary?->gallery_title  ?? '';
$header_cta_text = $hd['header_cta_text'] ?? 'Get Free Quote';
$header_cta_link = $hd['header_cta_link'] ?? '#vs-sec-contact';
$lid = $primary ? (int)$primary->id : 0;

/* ── Customizer CSS variables ────────────────────────── */
// Real fix: customizer_data/mobile_data are already decoded into real
// arrays by the generic $json_fields loop above (it uses $primary->$f —
// dynamic property access — which is why an earlier fix here, based on
// a grep for the literal text "primary->customizer_data", incorrectly
// concluded nothing decoded it and added a second, redundant
// json_decode() call. Re-decoding an already-decoded array produces the
// string "Array" (PHP's array-to-string conversion), which json_decode()
// fails to parse, silently discarding every saved customization. Plain
// assignment is correct here — decoding already happened.
$cd = ( $primary && ! empty( $primary->customizer_data ) ) ? $primary->customizer_data : [];
$md = ( $primary && ! empty( $primary->mobile_data    ) ) ? $primary->mobile_data    : [];

// ── ON-PAGE IMAGE FIT DIAGNOSTIC ────────────────────────────────────
// Built to answer one exact support question with evidence instead of
// guesswork: "I changed Image Fit and saved, but the live page never
// changes." That symptom has three, and only three, possible real
// causes, and this panel checks all three directly against THIS
// request, live, in front of the person looking at the page:
//   1. The value never reached the database (save-side bug).
//   2. It's in the database, but a caching layer (page-cache plugin,
//      CDN, or stale PHP opcode cache) is serving an old, frozen copy
//      of this exact page instead of running this code again.
//   3. It's in the database AND this code is running fresh, but the
//      computed CSS the fit produces happens to look identical for
//      this particular photo (not a bug at all).
// Gated to the listing owner or a site admin only — this echoes real,
// unfiltered database content (the full customizer_data blob), so it
// must never be reachable by a random visitor. Silently does nothing
// (no hint it exists) for anyone else or without the query param.
if ( isset( $_GET['gs_diag_imgfit'] ) && $primary ) {
    $_diag_uid       = get_current_user_id();
    $_diag_is_owner  = is_user_logged_in() && ( (int) ( $primary->vendor_user_id ?? 0 ) === $_diag_uid );
    $_diag_is_admin  = function_exists( 'current_user_can' ) && current_user_can( 'manage_options' );
    if ( $_diag_is_owner || $_diag_is_admin ) {
        // Independent, fresh, uncached re-query straight from the DB —
        // deliberately NOT reusing $primary/$cd above, so this proves
        // whether the row this exact request is about to render from
        // matches what a brand-new query returns right now. If they
        // differ, something upstream (a plugin, a DB replica lag, an
        // object-cache drop-in) is feeding this render stale data —
        // if they match, the database itself is confirmed current and
        // any remaining staleness is a page/CDN cache problem, not a
        // save problem.
        global $wpdb;
        $_diag_pfx     = $wpdb->prefix . 'gs_';
        $_diag_raw_cd  = $wpdb->get_var( $wpdb->prepare( "SELECT customizer_data FROM {$_diag_pfx}listings WHERE id = %d", (int) $primary->id ) );
        $_diag_fresh_cd = is_string( $_diag_raw_cd ) ? ( json_decode( $_diag_raw_cd, true ) ?: [] ) : [];

        // Every section this session's Image Fit rollout touches —
        // flat `_img_fit` fields and nested `_img_display.fit` fields
        // both, matched exactly to how each one is actually read in
        // this same file's render calls above/below, not re-guessed.
        $_diag_flat_fields = [
            'hero_img_fit', 'about_img_fit', 'gallery_img_fit', 'items_img_fit',
            'svc_icon_img_fit', 'svc_img_fit',
            'team_img_fit', 'clients_img_fit', 'portfolio_img_fit', 'testimonials_img_fit',
            'process_img_fit', 'why_img_fit', 'property_types_img_fit',
            'wedding_services_img_fit', 'wedding_team_img_fit',
        ];
        $_diag_nested_fields = [
            'beauty_facilities_img_display', 'project_categories_img_display',
            'three_d_before_after_img_display', 'room_types_img_display',
            'featured_properties_img_display', 'property_gallery_img_display',
            'ida_fp_img_display', 'ida_pc_img_display', 'ida_3d_img_display',
            'ida_ds_img_display', 'ida_dp_img_display',
            'hw_fs_img_display', 'hw_dept_img_display', 'hw_dr_img_display', 'hw_pf_img_display',
            'highlights_img_display', 'amenities_img_display',
            'home_services_before_after_img_display',
        ];
        $_diag_rows = [];
        foreach ( $_diag_flat_fields as $_df ) {
            $_saved_val = $cd[ $_df ] ?? null;
            $_fresh_val = $_diag_fresh_cd[ $_df ] ?? null;
            $_computed  = \gs_vs_img_display_style( [ 'fit' => $_saved_val ?? 'cover' ] )['img'];
            $_diag_rows[] = [ $_df, $_saved_val, $_fresh_val, $_computed ];
        }
        foreach ( $_diag_nested_fields as $_nf ) {
            $_saved_arr = is_array( $cd[ $_nf ] ?? null ) ? $cd[ $_nf ] : [];
            $_fresh_arr = is_array( $_diag_fresh_cd[ $_nf ] ?? null ) ? $_diag_fresh_cd[ $_nf ] : [];
            $_saved_val = $_saved_arr['fit'] ?? null;
            $_fresh_val = $_fresh_arr['fit'] ?? null;
            $_computed  = \gs_vs_img_display_style( $_saved_arr )['img'];
            $_diag_rows[] = [ $_nf . '.fit', $_saved_val, $_fresh_val, $_computed ];
        }

        // Page-caching plugin detection — same constants DiagnosticsEngine
        // already checks elsewhere in this plugin, reused verbatim here
        // so this panel and the admin-side audit never disagree.
        $_diag_cache_plugins = [
            'WP_ROCKET_VERSION' => 'WP Rocket', 'LSCWP_V' => 'LiteSpeed Cache',
            'W3TC_VERSION' => 'W3 Total Cache', 'WPCACHEHOME' => 'WP Super Cache',
            'SG_CACHEPRESS_VERSION' => 'SiteGround Optimizer',
        ];
        $_diag_detected_cache = [];
        foreach ( $_diag_cache_plugins as $_dc_const => $_dc_name ) {
            if ( defined( $_dc_const ) ) { $_diag_detected_cache[] = $_dc_name; }
        }
        $_diag_opcache_on = function_exists( 'opcache_get_status' ) && ( @opcache_get_status( false ) !== false );
        ?>
        <div style="position:relative;z-index:99999;background:#0F172A;color:#E2E8F0;font:13px/1.6 -apple-system,Segoe UI,sans-serif;padding:20px 24px;border-bottom:4px solid #F59E0B">
          <div style="font-weight:800;font-size:15px;color:#F59E0B;margin-bottom:10px">🩺 Image Fit Diagnostic — visible only to you (owner/admin), never to real visitors</div>
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;margin-bottom:14px">
            <div><b>Plugin version running:</b> <?php echo esc_html( defined('GS_VERSION') ? GS_VERSION : 'unknown' ); ?></div>
            <div><b>Server time right now:</b> <?php echo esc_html( date('Y-m-d H:i:s') ); ?> <span style="color:#94A3B8">(reload — if this timestamp never changes, a page cache is freezing this page)</span></div>
            <div><b>Random request token:</b> <?php echo esc_html( substr( md5( microtime() . random_int(0, PHP_INT_MAX) ), 0, 8 ) ); ?> <span style="color:#94A3B8">(same reload test as above)</span></div>
            <div><b>PHP OPcache:</b> <?php echo $_diag_opcache_on ? 'ON — if you just uploaded new files, restart PHP / clear OPcache from your host panel' : 'off or unavailable'; ?></div>
            <div><b>Page-cache plugin detected:</b> <?php echo $_diag_detected_cache ? esc_html( implode( ', ', $_diag_detected_cache ) ) . ' — purge its cache after every save' : 'none detected'; ?></div>
          </div>
          <table style="width:100%;border-collapse:collapse;font-size:12.5px">
            <thead><tr style="text-align:left;border-bottom:1px solid #334155;color:#94A3B8">
              <th style="padding:4px 8px">Field</th>
              <th style="padding:4px 8px">Saved value used for THIS render</th>
              <th style="padding:4px 8px">Fresh value, re-queried from DB right now</th>
              <th style="padding:4px 8px">CSS this would actually produce</th>
            </tr></thead>
            <tbody>
            <?php foreach ( $_diag_rows as $_dr ):
                list( $_dr_name, $_dr_saved, $_dr_fresh, $_dr_css ) = $_dr;
                $_dr_mismatch = ( $_dr_saved !== $_dr_fresh ) && ( $_dr_saved !== null || $_dr_fresh !== null );
            ?>
              <tr style="border-bottom:1px solid #1E293B<?php echo $_dr_mismatch ? ';background:#7C2D1244' : ''; ?>">
                <td style="padding:4px 8px;font-family:monospace"><?php echo esc_html( $_dr_name ); ?></td>
                <td style="padding:4px 8px"><?php echo $_dr_saved === null ? '<span style="color:#64748B">(not set — using default)</span>' : esc_html( (string) $_dr_saved ); ?></td>
                <td style="padding:4px 8px"><?php echo $_dr_fresh === null ? '<span style="color:#64748B">(not set)</span>' : esc_html( (string) $_dr_fresh ); ?><?php if ( $_dr_mismatch ): ?> <span style="color:#FCA5A5;font-weight:700">← DIFFERENT FROM WHAT THIS PAGE USED — this render is stale, not the database</span><?php endif; ?></td>
                <td style="padding:4px 8px;font-family:monospace;color:#7DD3FC"><?php echo esc_html( $_dr_css ); ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <div style="margin-top:12px;color:#94A3B8">How to read this: only touch the row for the section you changed. If "Fresh value" matches what you picked in the admin panel, your save worked and the database is correct — reload with a hard refresh (Ctrl/Cmd+Shift+R) or purge any page-cache/CDN listed above. If "Fresh value" does NOT match what you picked, the save itself isn't reaching this field — tell me this row's name and its Fresh value and I'll trace the save path for that exact field next.</div>
        </div>
        <?php
    }
}

// Marquee speed: stored in customizer_data['trust_bar_speed'] (seconds, default 28)
// NOTE: must be computed AFTER $cd is decoded above.
$cv_marquee_speed = max( 5, min( 120, (int)( $cd['trust_bar_speed'] ?? 28 ) ) );
// Real feature, item 2: full trust bar customization.
$cv_tb_direction   = in_array( $cd['trust_bar_direction'] ?? '', ['left','right'], true ) ? $cd['trust_bar_direction'] : 'left';
$cv_tb_pause_hover = ( $cd['trust_bar_pause_hover'] ?? 1 ) ? true : false;
$cv_tb_gap         = max( 0, min( 200, (int) ( $cd['trust_bar_gap'] ?? 48 ) ) );
$cv_tb_bg          = $cd['trust_bar_bg']    ?? '';
$cv_tb_padding     = max( 0, min( 60, (int) ( $cd['trust_bar_padding'] ?? 12 ) ) );
$cv_tb_radius      = max( 0, min( 40, (int) ( $cd['trust_bar_radius'] ?? 0 ) ) );
$cv_tb_align       = in_array( $cd['trust_bar_align'] ?? '', ['left','center','right'], true ) ? $cd['trust_bar_align'] : 'left';

/* ── Section order & visibility ─────────────────────── */
// Real fix: 'questions' (Questions & Answers) was added to this list.
// It was previously a hardcoded block that always rendered immediately
// after the reorderable-section loop below, regardless of vendor
// preference — no visibility toggle, no position in Section Order, no
// entry in $sec_labels, no style config. Adding it here lets it
// participate in the exact same reorder/hide/show machinery as every
// other section (see the ob_start()/$_vs_sections buffering right above
// the render loop, and $_sec_show() below). Kept as a single-line array
// literal — deliberately, not just for consistency — because
// tools/audit-section-detachment.php parses this exact declaration with
// a regex that does not span newlines; a multi-line version of this
// array silently breaks that audit tool for every section, not just this
// one.
$_default_sec_order = ['about','inquiry_modules','services','process','items','stats','gallery','why','highlights','amenities','facilities','awards','languages','packages','memberships','room_types','hotel_event_spaces','hotel_events_showcase','hotel_dining','hotel_amenities','hotel_virtual_tour','hotel_closing_banner','property_listings','featured_properties','property_types','property_gallery','featured_projects','project_categories','three_d_before_after','design_styles','design_process','featured_services','beauty_services','beauty_gallery','beauty_experts','beauty_facilities','beauty_packages','beauty_booking_cta','wedding_portfolio','wedding_stories','wedding_services','wedding_packages','wedding_style','wedding_team','wedding_venue_specialization','wedding_locations','wedding_availability','wedding_quote','wedding_closing_banner','home_services_catalogue','home_services_packages','home_services_technicians','home_services_guarantee','home_services_before_after','departments','doctors','patient_facilities','patient_journey','certifications','warranty','terms','team','clients','pricing','portfolio','testimonials','reviews','faq','questions','contact','related_listings'];
$_sec_order   = is_array( $cd['sections_order']   ?? null ) ? $cd['sections_order']   : $_default_sec_order;
// Real fix — a listing saved before a new section (e.g. Key Highlights)
// existed has an older sections_order array that simply doesn't contain
// its key, so the render loop below would silently skip it forever even
// though its content renders fine — appends any missing default section
// to the end, so newly-added sections show up without requiring every
// vendor to re-open and re-save their Section Layout tab.
foreach ( $_default_sec_order as $_ds ) { if ( ! in_array( $_ds, $_sec_order, true ) ) { $_sec_order[] = $_ds; } }
// Per-section width settings (stored in customizer_data['section_widths'])
$_sec_widths  = is_array( $cd['section_widths'] ?? null ) ? $cd['section_widths'] : [];
// Real feature, item 4: per-section left/right margin settings.
$_sec_margins = is_array( $cd['section_margins'] ?? null ) ? $cd['section_margins'] : [];
$_sec_visible = is_array( $cd['sections_visible'] ?? null ) ? $cd['sections_visible'] : [];
// Ensure all sections present (add any missing to end)
foreach ( $_default_sec_order as $_ds ) { if ( ! in_array( $_ds, $_sec_order ) ) $_sec_order[] = $_ds; }
// Helper: is a section visible? Default true unless explicitly set to false
// Returns inline style string for the .vs-wrap inside a section
$_sec_wrap_style = function( string $key ) use ( $_sec_widths, $_sec_margins ): string {
    $w = (int)( $_sec_widths[ $key ] ?? 0 );
    $m = $_sec_margins[ $key ] ?? [];
    $ml = max( 0, min( 500, (int) ( $m['l'] ?? 0 ) ) );
    $mr = max( 0, min( 500, (int) ( $m['r'] ?? 0 ) ) );
    $styles = [];
    if ( $w >= 600 ) { $styles[] = 'max-width:' . $w . 'px'; }
    if ( $ml > 0 ) { $styles[] = 'margin-left:' . $ml . 'px'; }
    if ( $mr > 0 ) { $styles[] = 'margin-right:' . $mr . 'px'; }
    return $styles ? 'style="' . esc_attr( implode( ';', $styles ) ) . '"' : '';
};

// Also load sections_visible_data (per-card visibility toggle)
$_svd_raw = isset( $primary->sections_visible_data ) ? $primary->sections_visible_data : '{}';
$_svd     = json_decode( $_svd_raw, true ) ?: [];
$_svd_mandatory = ['header','contact'];

// Real feature: resolve this listing's FULL category row (id, parent_id,
// slug) once, so $_sec_show() below can check category eligibility for
// any module registered with specific categories (not 'all') — using
// ModuleRegistry::category_matches(), which understands both the
// legacy flat-slug format and the new structured main/subcategory
// group format built by the redesigned Section Manager category
// assignment UI. get_by_id() deliberately used over get_all_active()
// — the latter only returns top-level categories and would silently
// miss a listing whose category_id points to a subcategory.
$_listing_category_row = null;
if ( ! empty( $primary->category_id ) ) {
    $_listing_category_row = ( new \GoodService\Repository\CategoryRepository() )->get_by_id( (int) $primary->category_id );
}

// Real feature: which modules has this specific listing actually been
// assigned (vendor explicitly opted in), fetched once per page load —
// not once per module — exactly as get_assigned_module_keys()'s own
// docblock specifies. Needed for any module with default_enabled=false
// (a category-specific module like Room Types): the listing's category
// matching is necessary but not sufficient — the vendor must have also
// explicitly ticked it on, per the real requirement this was built to.
global $wpdb;
$_assigned_module_keys = \GoodService\Core\ModuleRegistry::get_assigned_module_keys( $wpdb, $wpdb->prefix . 'gs_', (int) ( $primary->id ?? 0 ) );

$_sec_show = function( string $key ) use ( $_sec_visible, $_svd, $_svd_mandatory, $_listing_category_row, $_assigned_module_keys ): bool {
    // Mandatory sections are always shown
    if ( in_array( $key, $_svd_mandatory, true ) ) { return true; }
    // Category eligibility: a module registered with specific categories
    // (not 'all') is not shown at all for a listing outside those
    // categories, regardless of any vendor visibility setting — this is a
    // platform-level eligibility gate, not a vendor preference, so it is
    // checked before, and takes precedence over, everything below.
    if ( \GoodService\Core\ModuleRegistry::exists( $key ) ) {
        $_mod = \GoodService\Core\ModuleRegistry::get_all()[ $key ];
        $_mod_cats = $_mod['categories'] ?? 'all';
        if ( ! \GoodService\Core\ModuleRegistry::category_matches( $_mod_cats, $_listing_category_row ) ) {
            return false;
        }
        // Explicit vendor opt-in: a module with default_enabled=false only
        // shows if this specific listing has a real assignment row — the
        // category matching above is necessary but not, by itself,
        // sufficient. is_assigned() already correctly returns true with
        // no row needed for every default_enabled=true (regular/common)
        // module, so this check has zero effect on any of those.
        if ( ! \GoodService\Core\ModuleRegistry::is_assigned( $key, $_assigned_module_keys ) ) {
            return false;
        }
    }
    // Check new per-card toggle (sections_visible_data)
    if ( array_key_exists( $key, $_svd ) ) { return (bool) $_svd[ $key ]; }
    // Fall back to legacy sections_visible
    return isset( $_sec_visible[ $key ] ) ? (bool) $_sec_visible[ $key ] : true;
};

/**
 * Real fix — replaces !empty($primary->X_data) for the 10 new sections.
 * empty() on a raw JSON string only tells you the STRING isn't empty
 * ("[]" and '{"title":""}' both pass it) — not whether it decodes to any
 * actual content. Without this, a section that was ever saved with its
 * required field left blank renders a full, styled, empty <section> on
 * the live page (a "blank white box"). $required_key is checked against
 * every item for repeater sections (JSON array), or directly for
 * single-block sections (JSON object) — same logic the New Sections
 * diagnostic already uses to classify NO_DATA, kept in sync deliberately.
 */
$_json_has_real_content = function( $raw, string $required_key ): bool {
    if ( empty( $raw ) ) { return false; }
    $decoded = json_decode( (string) $raw, true );
    if ( ! is_array( $decoded ) ) { return false; }
    if ( array_key_exists( $required_key, $decoded ) ) {
        // Single-block shape (e.g. warranty_data, terms_data): check directly.
        return ! empty( $decoded[ $required_key ] );
    }
    // Repeater shape: at least one item must have the required field filled.
    foreach ( $decoded as $item ) {
        if ( is_array( $item ) && ! empty( $item[ $required_key ] ?? null ) ) { return true; }
    }
    return false;
};

/* ── Element-level config: visibility, section assignment, order ──────────── */
$_elcfg = is_array( $cd['element_config'] ?? null ) ? $cd['element_config'] : [];

// Master element registry: [id => [default_section, default_order, label]]
$_el_registry = [
  // Hero section elements
  'hero_eyebrow'       => ['hero',     10, 'Location / Verified Badge'],
  'hero_name'          => ['hero',     20, 'Business Name (H1)'],
  'hero_tagline'       => ['hero',     30, 'Tagline'],
  'hero_description'   => ['hero',     40, 'Hero Description'],
  'hero_highlights'    => ['hero',     50, 'Hero Highlights Checklist'],
  'hero_cta_buttons'   => ['hero',     60, 'CTA + Phone Buttons'],
  'hero_image'         => ['hero',     70, 'Hero Right Image + Rating'],
  'trust_bar'          => ['hero',     80, 'Trust Bar (scrolling)'],
  // About section elements
  'about_eyebrow'      => ['about',    10, 'About — Brand Eyebrow'],
  'about_title'        => ['about',    20, 'About — Section Title'],
  'about_stats_row'    => ['about',    30, 'About — Founded / Team / Price / Rating badges'],
  'about_description'  => ['about',    40, 'About — Description Text'],
  'about_highlights'   => ['about',    50, 'About — Highlights List'],
  'about_cta'          => ['about',    60, 'About — CTA Button'],
  'about_image'        => ['about_right', 10, 'About — Image (right column)'],
  'about_video'        => ['about_right', 20, 'About — Video Embed'],
  'about_badges'       => ['about_right', 30, 'About — Trust Badges'],
  // Services section
  'services_title'     => ['services', 10, 'Services — Section Title'],
  'services_grid'      => ['services', 20, 'Services — Cards Grid'],
  // Process section
  'process_title'      => ['process',  10, 'Process — Section Title'],
  'process_steps'      => ['process',  20, 'Process — Steps'],
  // Items section
  'items_title'        => ['items',    10, 'Items — Section Title'],
  'items_grid'         => ['items',    20, 'Items / Products Grid'],
  // Stats section
  'stats_title'        => ['stats',    10, 'Stats — Section Title'],
  'stats_grid'         => ['stats',    20, 'Stats — Number Cards'],
  // Gallery section
  'gallery_title'      => ['gallery',  10, 'Gallery — Title'],
  'gallery_filters'    => ['gallery',  20, 'Gallery — Tag Filters'],
  'gallery_grid'       => ['gallery',  30, 'Gallery — Image Grid'],
  // Why Choose Us
  'why_title'          => ['why',      10, 'Why Choose Us — Title'],
  'why_grid'           => ['why',      20, 'Why Choose Us — Items'],
  // Reviews
  'reviews_title'      => ['reviews',  10, 'Reviews — Section Title'],
  'reviews_grid'       => ['reviews',  20, 'Reviews — Cards'],
  // FAQ
  'faq_title'          => ['faq',      10, 'FAQ — Title'],
  'faq_items'          => ['faq',      20, 'FAQ — Accordion'],
  // Contact section
  'contact_phone'      => ['contact',  10, 'Contact — Phone'],
  'contact_whatsapp'   => ['contact',  20, 'Contact — WhatsApp'],
  'contact_email'      => ['contact',  30, 'Contact — Email'],
  'contact_website'    => ['contact',  40, 'Contact — Website'],
  'contact_address'    => ['contact',  50, 'Contact — Address'],
  'contact_certs'      => ['contact',  60, 'Contact — Certifications'],
  'contact_awards'     => ['contact',  70, 'Contact — Awards'],
  'contact_hours'      => ['contact',  80, 'Contact — Opening Hours'],
  'contact_map'        => ['contact',  90, 'Contact — Map Embed'],
  'contact_cities'     => ['contact', 100, 'Contact — Service Cities'],
  'contact_tags'       => ['contact', 110, 'Contact — Tags'],
  'contact_inquiry'    => ['contact', 120, 'Contact — Inquiry / Quote Form'],
  // ── Premium: Team section
  'team_title'         => ['team',      10, 'Team — Section Title'],
  'team_grid'          => ['team',      20, 'Team — Member Cards'],
  // ── Premium: Clients / Trusted By section
  'clients_title'      => ['clients',   10, 'Clients — Section Title'],
  'clients_logos'      => ['clients',   20, 'Clients — Logo Wall'],
  // ── Premium: Pricing Table section
  'pricing_title'      => ['pricing',   10, 'Pricing — Section Title'],
  'pricing_grid'       => ['pricing',   20, 'Pricing — Plan Cards'],
  // ── Premium: Portfolio / Case Studies section
  'portfolio_title'    => ['portfolio', 10, 'Portfolio — Section Title'],
  'portfolio_grid'     => ['portfolio', 20, 'Portfolio — Project Cards'],
  // ── Premium: Testimonials / Video Testimonials section
  'testimonials_title' => ['testimonials', 10, 'Testimonials — Section Title'],
  'testimonials_grid'  => ['testimonials', 20, 'Testimonials — Cards'],
  // ── New Vendor Listing Form sections (v14) — every $_el_capture() call
  // for these 10 sections MUST have a matching entry here, or its content
  // silently never renders (defaults to section='about', which never matches).
  'highlights_title'      => ['highlights',      10, 'Key Highlights — Section Title'],
  'highlights_grid'       => ['highlights',      20, 'Key Highlights — Cards'],
  'amenities_title'       => ['amenities',       10, 'Features & Amenities — Section Title'],
  'amenities_grid'        => ['amenities',       20, 'Features & Amenities — Cards'],
  'facilities_title'      => ['facilities',      10, 'Facilities — Section Title'],
  'facilities_grid'       => ['facilities',      20, 'Facilities — Cards'],
  'awards_title'          => ['awards',          10, 'Awards & Recognition — Section Title'],
  'awards_grid'           => ['awards',          20, 'Awards & Recognition — Cards'],
  'languages_title'       => ['languages',       10, 'Languages Spoken — Section Title'],
  'languages_list'        => ['languages',       20, 'Languages Spoken — Tag List'],
  'packages_title'        => ['packages',        10, 'Packages & Pricing — Section Title'],
  'packages_grid'         => ['packages',        20, 'Packages & Pricing — Cards'],
  'memberships_title'     => ['memberships',     10, 'Membership Plans — Section Title'],
  'memberships_grid'      => ['memberships',     20, 'Membership Plans — Cards'],
  'certifications_title'  => ['certifications',  10, 'Licences & Certifications — Section Title'],
  'certifications_grid'   => ['certifications',  20, 'Licences & Certifications — Cards'],
  'warranty_block'        => ['warranty',        10, 'Warranty / Guarantee — Block'],
  'terms_block'           => ['terms',           10, 'Terms & Conditions — Block'],
];

// Helper: get element config (visibility, assigned section, order)
$_elget = function(string $id) use ($_elcfg, $_el_registry): array {
    $user = $_elcfg[$id] ?? [];
    [$def_sec, $def_ord] = $_el_registry[$id] ?? ['about', 99];
    return [
        'vis' => (bool)($user['visible'] ?? true),
        'sec' => $user['section'] ?? $def_sec,
        'ord' => (int)($user['order']   ?? $def_ord),
    ];
};

// Element buffer system: collect HTML for each section, then render in order
$_el_bufs = []; // ['section_id' => ['order' => 'html']]

$_el_capture = function(string $id, string $current_section, callable $render_fn) 
               use (&$_el_bufs, $_elget, $_sec_show): void {
    if (!$_sec_show($current_section)) return; // section itself is hidden — skip all render work, not just the output
    $cfg = $_elget($id);
    if (!$cfg['vis']) return; // hidden globally
    if ($cfg['sec'] !== $current_section) return; // belongs to a different section
    ob_start();
    $render_fn();
    $html = ob_get_clean();
    if ($html !== '' && $html !== false) {
        $_el_bufs[$current_section][$cfg['ord']] = $html;
    }
};

// Render all elements for a section in configured order
$_sec_el_render = function(string $section_id) use (&$_el_bufs): string {
    if (empty($_el_bufs[$section_id])) return '';
    ksort($_el_bufs[$section_id]);
    return implode('', $_el_bufs[$section_id]);
};

// Helper closer used on first use below
// Real fix: object-fit only accepts cover|contain|fill|scale-down|none in CSS.
// The previous version accepted 'auto' (not a valid object-fit value — browsers
// ignore it and silently fall back to the initial value 'fill') and rejected
// 'none' (a real, useful value meaning "don't resize the image at all").
// 'auto' is kept as a legacy input alias mapping to 'none' so listings saved
// under the old, buggy value set keep rendering exactly as they did before.
$_fit_v = function ( $v, $d ) {
    $v = ( $v === 'auto' ) ? 'none' : $v;
    return in_array( $v, [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? $v : $d;
};
// Shared object-position validator — same 9-value set already used by the
// hero/banner swiper slides ($valid_positions further down in this file),
// now reused for Gallery, Products (items_) and Services (svc_) image controls
// so all image-bearing sections offer identical position options.
$_pos_v = function ( $v, $d = 'center' ) {
    return in_array( $v, [ 'center', 'top', 'bottom', 'left', 'right', 'top left', 'top right', 'bottom left', 'bottom right' ], true ) ? $v : $d;
};
// Shared border-style validator — same value set already used by
// why_icon_border_style below, reused for image border controls.
$_bstyle_v = function ( $v, $d = 'solid' ) {
    return in_array( $v, [ 'solid', 'dashed', 'dotted', 'double', 'none' ], true ) ? $v : $d;
};
// Shared 6-digit hex color validator.
$_hex_v = function ( $v, $d ) {
    return ( is_string( $v ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $v ) ) ? $v : $d;
};
// Shared full box-shadow builder (color, h-offset, v-offset, blur, spread,
// opacity) — the only shadow control that previously existed anywhere in
// this file was a 4-value preset dropdown (none/sm/md/lg, see $shadow_map
// below) applied to whole cards. This builds a real, fully custom
// box-shadow string for an individual image, defaulting to 'none' so
// existing listings that have never touched this control render with zero
// visual change.
$_img_shadow_css = function ( array $cd, string $prefix ) use ( $_hex_v ) {
    $opacity = max( 0, min( 100, (int) ( $cd["{$prefix}_shadow_opacity"] ?? 0 ) ) );
    if ( $opacity <= 0 ) { return 'none'; }
    $color  = $_hex_v( $cd["{$prefix}_shadow_color"] ?? null, '#000000' );
    $h      = max( -200, min( 200, (int) ( $cd["{$prefix}_shadow_h"] ?? 0 ) ) );
    $v      = max( -200, min( 200, (int) ( $cd["{$prefix}_shadow_v"] ?? 4 ) ) );
    $blur   = max( 0, min( 200, (int) ( $cd["{$prefix}_shadow_blur"] ?? 12 ) ) );
    $spread = max( -100, min( 100, (int) ( $cd["{$prefix}_shadow_spread"] ?? 0 ) ) );
    $r = hexdec( substr( $color, 1, 2 ) );
    $g = hexdec( substr( $color, 3, 2 ) );
    $b = hexdec( substr( $color, 5, 2 ) );
    return "{$h}px {$v}px {$blur}px {$spread}px rgba({$r},{$g},{$b}," . round( $opacity / 100, 2 ) . ')';
};

// ── Delayed fetch for the five "premium" optional sections ─────────────────
// The main listing query (Router.php) deliberately leaves team_data,
// clients_data, pricing_data, portfolio_data, and testimonials_data empty,
// having already determined cheaply (via LENGTH(), not the real content)
// whether each one genuinely has anything saved. This fetches the REAL
// content for exactly one field, exactly once, and only when the earlier
// cheap check confirmed it's worth fetching at all — a vendor who never
// touched any of these five sections costs this page nothing beyond the
// one small LENGTH() query already run.
$_premium_fetch_cache = [];
$_fetch_premium_section = function( string $field ) use ( $primary, &$_premium_fetch_cache ): array {
    if ( ! $primary ) { return []; }
    if ( array_key_exists( $field, $_premium_fetch_cache ) ) { return $_premium_fetch_cache[ $field ]; }
    $has_content = $primary->_premium_has_content[ $field ] ?? false;
    if ( ! $has_content ) {
        $_premium_fetch_cache[ $field ] = [];
        return [];
    }
    global $wpdb;
    $pfx_local = $wpdb->prefix . 'gs_';
    $raw = $wpdb->get_var( $wpdb->prepare(
        "SELECT {$field} FROM {$pfx_local}listings WHERE id = %d", (int) $primary->id
    ) );
    $decoded = is_string( $raw ) ? ( json_decode( $raw, true ) ?: [] ) : ( (array) ( $raw ?? [] ) );
    $_premium_fetch_cache[ $field ] = $decoded;
    return $decoded;
};
$_px    = fn($v,$d) => (int)($v ?? $d); // no clamp — user can set any value
$_wpx   = fn($v,$d) => (int)($v ?? $d); // width in px, 0 = auto
$cv_heading    = $cd['heading_color']   ?? '#1E293B';
$cv_text       = $cd['text_color']      ?? '#475569';
$cv_muted      = $cd['muted_color']     ?? '#64748B';
$cv_accent     = $cd['accent_color']    ?? '#2563EB';
$cv_section_bg = $cd['section_bg']      ?? '#F8FAFC';
// Per-section colors
$cv_hero_bg           = $cd['hero_bg']               ?? '';
$cv_hero_right_bg     = $cd['hero_right_bg']         ?? '';
$cv_about_bg          = $cd['about_bg']               ?? '';
$cv_about_eyebrow     = $cd['about_eyebrow_color']    ?? '';
$cv_services_bg       = $cd['services_bg']            ?? '';
$cv_services_card_h   = $cd['services_card_heading']  ?? '';
$cv_services_icon     = $cd['services_icon_color']    ?? '';
$cv_process_bg        = $cd['process_bg']             ?? '';
$cv_process_num       = $cd['process_step_num_color'] ?? '';
$cv_process_num_bg    = $cd['process_step_num_bg']    ?? '';
$cv_process_num_border = $cd['process_step_num_border_color'] ?? '';
$cv_process_sec_desc  = $cd['process_desc_section_color'] ?? '';
$cv_process_item_desc_color = $cd['process_item_desc_color'] ?? '';
$cv_process_card_bg   = $cd['process_card_bg']        ?? '';
$cv_process_card_border_color = $cd['process_card_border_color'] ?? '';
$cv_process_card_border_width = max( 0, min( 8, (int) ( $cd['process_card_border_width'] ?? 0 ) ) );
$cv_process_card_radius = max( 0, min( 40, (int) ( $cd['process_card_radius'] ?? 0 ) ) );
$cv_process_card_shadow = in_array( $cd['process_card_shadow'] ?? '', ['none','sm','md','lg'], true ) ? $cd['process_card_shadow'] : 'none';
$cv_items_bg          = $cd['items_bg']               ?? '';
$cv_items_price       = $cd['items_price_color']      ?? '';
$cv_items_btn         = $cd['items_btn_color']        ?? '';
$cv_stats_bg          = $cd['stats_bg']               ?? '';
$cv_stats_num         = $cd['stats_num_color']        ?? '';
$cv_stats_label       = $cd['stats_label_color']      ?? '';
// Real feature: the footer had no per-listing background override at all
// (unlike Process/Stats/etc., which all follow this same --vs-{section}-bg
// pattern) — it always fell straight through to the global --vs-dark brand
// variable, which is also used for unrelated things (nav text, buttons,
// headings), so a vendor could never darken/lighten just their footer.
$cv_footer_bg         = $cd['footer_bg']              ?? '';
$cv_why_bg            = $cd['why_bg']                 ?? '';
$cv_why_icon          = $cd['why_icon_color']         ?? '';
$cv_why_card_h        = $cd['why_card_heading']       ?? '';
$cv_gallery_bg        = $cd['gallery_bg']             ?? '';
$cv_gallery_filter    = $cd['gallery_filter_active_color'] ?? '';
$cv_faq_bg            = $cd['faq_bg']                 ?? '';
$cv_faq_icon          = $cd['faq_icon_color']         ?? '';
// Real feature: Questions & Answers section background — same pattern as
// every other section's own _bg override (faq_bg, reviews_bg, etc.), added
// as part of turning this section into a properly configurable one.
$cv_questions_bg      = $cd['questions_bg']           ?? '';
$cv_contact_bg        = $cd['contact_bg']             ?? '';
$cv_contact_icon      = $cd['contact_icon_color']     ?? '';
$cv_contact_link      = $cd['contact_link_color']     ?? '';
// Popup colors
$cv_popup_overlay     = $cd['popup_overlay_bg']       ?? 'rgba(15,23,42,.65)';
$cv_popup_modal_bg    = $cd['popup_modal_bg']         ?? '#ffffff';
$cv_popup_header_bg   = $cd['popup_header_bg']        ?? '#1E293B';
$cv_popup_svc_hdr_bg  = $cd['popup_svc_header_bg']    ?? $cv_popup_header_bg;
$cv_popup_prd_hdr_bg  = $cd['popup_prd_header_bg']    ?? $cv_popup_header_bg;
$cv_popup_header_text = $cd['popup_header_text']      ?? '#ffffff';
$cv_popup_sub_color   = $cd['popup_sub_color']        ?? '';
$cv_popup_btn_bg      = $cd['popup_btn_bg']           ?? '';
$cv_popup_btn_text    = $cd['popup_btn_text']         ?? '#ffffff';
// Real fix — the inquiry module's own styling fields were being saved
// but never actually applied to the real, rendered inline form
// (.vs-contact-form-card / .vs-input / submit button), which used
// entirely hardcoded colors instead. Extracted here so they can
// finally be wired into the actual CSS below.
$cv_inq_sec_bg           = $cd['inq_sec_bg']           ?? '';
$cv_inq_form_bg          = $cd['inq_form_bg']          ?? '';
$cv_inq_form_border_color= $cd['inq_form_border_color']?? '';
$cv_inq_form_border_width= $cd['inq_form_border_width']?? '0';
$cv_inq_form_radius      = $cd['inq_form_radius']      ?? '';
$cv_inq_input_bg         = $cd['inq_input_bg']         ?? '';
$cv_inq_input_border     = $cd['inq_input_border']     ?? '';
$cv_inq_input_border_w   = $cd['inq_input_border_width']?? '1.5';
$cv_inq_input_text       = $cd['inq_input_text']       ?? '';
// Real fix — font-size/weight/family were hardcoded on form inputs;
// extends the existing color/border/bg controls without touching them.
$cv_inq_input_size       = max( 12, min( 20, (int) ( $cd['inq_input_font_size'] ?? 14 ) ) );
$cv_inq_input_weight     = in_array( (string) ( $cd['inq_input_font_weight'] ?? '400' ), ['400','500','600','700'], true ) ? (string) ( $cd['inq_input_font_weight'] ?? '400' ) : '400';
$cv_inq_input_font       = trim( (string) ( $cd['inq_input_font_family'] ?? '' ) );
$cv_inq_input_font_stack = $cv_inq_input_font !== '' ? \GoodService\Service\TypographyService::resolve_font_stack( $cv_inq_input_font ) : 'inherit';
// Styling audit — the contact input/submit typography sub-system was
// missing letter-spacing and line-height, unlike the full TypographyService
// set every other section gets. Extends this existing custom sub-system
// (rather than replacing it, since it also carries its own bg/border/color
// fields already working correctly) with the two missing properties.
$cv_inq_input_ls         = max( -0.05, min( 0.3, (float) ( $cd['inq_input_letter_spacing'] ?? 0 ) ) );
$cv_inq_input_lh         = max( 1, min( 2.4, (float) ( $cd['inq_input_line_height'] ?? 1.4 ) ) );
$cv_inq_btn_bg           = $cd['inq_btn_bg']           ?? '';
$cv_inq_btn_text         = $cd['inq_btn_text']         ?? '';
// Real fix — inq_heading_color is actually the contact form header BAR's
// background color (confirmed by its one consumer, .vs-contact-form-hdr,
// below), despite its vendor-facing label literally saying "Heading
// Colour" — a vendor picking a light color there, reasonably expecting
// it to set the TITLE TEXT color, instead painted the background light
// while the title text stayed hardcoded to white with no control of its
// own, making it disappear. This is a genuinely new, independent field
// for the text itself, defaulting to white to match the old hardcoded
// behavior exactly for every listing that hasn't touched it yet.
$cv_inq_heading_text_color = $_hex_v( $cd['inq_heading_text_color'] ?? null, '#ffffff' );
$cv_inq_heading_color    = $cd['inq_heading_color']    ?? '';
$cv_inq_label_color      = $cd['inq_label_color']      ?? '';
$cv_inq_body_color       = $cd['inq_body_color']       ?? '';
// Helpers for optional color inline style
$_ics = fn(?string $col, string $prop='color') => $col ? "{$prop}:{$col};" : '';
$cv_banner_h   = $_px( $cd['banner_height'] ?? null, 400 ); // no limit — fully user-controlled
$cv_banner_r   = max( 0, min( 40,  (int)( $cd['banner_radius']  ?? 0  ) ) );
$cv_banner_op  = max( 0, min( 100, (int)( $cd['banner_opacity'] ?? 60 ) ) ) / 100;
// FIX: Default transparent so vendor logos with PNG/WebP transparency show correctly.
// '#ffffff' was adding a white CSS background behind every logo image.
$cv_logo_bg    = ( isset($cd['logo_bg']) && $cd['logo_bg'] !== '' && $cd['logo_bg'] !== '#ffffff' )
                 ? $cd['logo_bg'] : 'transparent';
$cv_logo_bc    = $cd['logo_border_c']   ?? '#E2E8F0';
$cv_logo_bw    = max( 0, min( 10,  (int)( $cd['logo_border_w']  ?? 2  ) ) );
$cv_logo_r     = max( 0, min( 99,  (int)( $cd['logo_radius']    ?? 10 ) ) );
$cv_logo_pad   = max( 0, min( 40,  (int)( $cd['logo_padding']   ?? 4  ) ) );
$cv_logo_sh    = $cd['logo_shadow']     ?? 'none';
$cv_card_bc    = $cd['card_border']     ?? '#E2E8F0';
$cv_card_r     = max( 0, min( 40,  (int)( $cd['card_radius']    ?? 12 ) ) );
$cv_card_pad   = max( 0, min( 60,  (int)( $cd['card_pad']       ?? 20 ) ) );
$cv_card_sh    = $cd['card_shadow']     ?? 'sm';
$cv_card_imgr  = max( 0, min( 40,  (int)( $cd['card_img_radius']?? 10 ) ) );
// Styling audit — Reviews & Testimonials previously had no card
// background/border control at all (unlike every other card-based
// section); wired to the generic card fallback so nothing changes
// visually until an admin sets these explicitly.
$cv_reviews_card_bg = $cd['reviews_card_bg']           ?? '#ffffff';
$cv_reviews_card_bc = $cd['reviews_card_border_color'] ?? $cv_card_bc;
$cv_testi_card_bg   = $cd['testimonials_card_bg']           ?? '#ffffff';
$cv_testi_card_bc   = $cd['testimonials_card_border_color'] ?? '#E2E8F0';
$cv_btn_bg     = $cd['btn_bg']          ?? $brand_color;
$cv_btn_text   = $cd['btn_text']        ?? '#ffffff';
$cv_btn_r      = max( 0, min( 50,  (int)( $cd['btn_radius']     ?? 8  ) ) );
$cv_qbtn_style = $cd['quote_btn_style'] ?? 'filled';
$cv_sec_pt     = max( 0, min( 200, (int)( $cd['section_pt']     ?? 64 ) ) );
$cv_sec_pb     = max( 0, min( 200, (int)( $cd['section_pb']     ?? 64 ) ) );
// ── Image sizing — NO hard limits, fully controlled per field ────────────
// Height: 0 = auto/unset. Width: 0 = 100%/auto depending on field.
// (closures $_fit_v, $_px, $_wpx defined above before first use)

// Logo
$cv_logo_size       = $_px( $cd['logo_display_size'] ?? null, 80 ); // legacy height
$cv_logo_h          = $_px( $cd['logo_height']       ?? null, $cv_logo_size );
$cv_logo_w          = $_wpx($cd['logo_width']        ?? null, 0 ); // 0 = auto
$cv_logo_fit        = $_fit_v($cd['logo_fit']         ?? null, 'contain');
// Banner
$cv_banner_fit      = $_fit_v($cd['banner_fit']       ?? null, 'cover');
$cv_banner_w        = $_wpx($cd['banner_width']       ?? null, 0 ); // 0 = 100%
// Hero image
$cv_hero_img_h      = $_px( $cd['hero_img_height']   ?? null, 400 );
$cv_hero_img_w      = $_wpx($cd['hero_img_width']    ?? null, 0 ); // 0 = 100%
$cv_hero_img_fit    = $_fit_v($cd['hero_img_fit']     ?? null, 'cover');
// About image
$cv_about_img_h     = $_px( $cd['about_img_height']  ?? null, 520 );
$cv_about_img_w     = $_wpx($cd['about_img_width']   ?? null, 0 ); // 0 = 100%
$cv_about_left_w    = $_wpx($cd['about_left_width']  ?? null, 0 ); // 0 = auto (1fr)
$cv_about_img_fit   = $_fit_v($cd['about_img_fit']   ?? null, 'cover');
// Gallery images
$cv_gallery_img_h   = $_px( $cd['gallery_img_height']?? null, 240 );
$cv_gallery_img_w   = $_wpx($cd['gallery_img_width'] ?? null, 0 ); // 0 = 100%
$cv_gallery_img_fit = $_fit_v($cd['gallery_img_fit'] ?? null, 'cover');
// Gallery — image position, border, box-shadow (border-radius reuses the
// existing gallery_radius field above; not duplicated here).
$cv_gallery_img_position     = $_pos_v( $cd['gallery_img_position']      ?? null, 'center' );
$cv_gallery_img_border_w     = max( 0, min( 20, (int) ( $cd['gallery_img_border_width'] ?? 0 ) ) );
$cv_gallery_img_border_style = $_bstyle_v( $cd['gallery_img_border_style'] ?? null, 'solid' );
$cv_gallery_img_border_color = $_hex_v( $cd['gallery_img_border_color']  ?? null, '#E2E8F0' );
$cv_gallery_img_shadow_val   = $_img_shadow_css( $cd, 'gallery_img' );
// Items/services card images
$cv_items_img_h     = $_px( $cd['items_img_height']  ?? null, 200 );
$cv_items_img_w     = $_wpx($cd['items_img_width']   ?? null, 0 ); // 0 = 100%
$cv_items_img_fit   = $_fit_v($cd['items_img_fit']   ?? null, 'cover');
// Products (items_) — image position, border, box-shadow (border-radius
// reuses the existing items_img_box_radius field; not duplicated here).
$cv_items_img_position     = $_pos_v( $cd['items_img_position']      ?? null, 'center' );
$cv_items_img_border_w     = max( 0, min( 20, (int) ( $cd['items_img_border_width'] ?? 0 ) ) );
$cv_items_img_border_style = $_bstyle_v( $cd['items_img_border_style'] ?? null, 'solid' );
$cv_items_img_border_color = $_hex_v( $cd['items_img_border_color']  ?? null, '#E2E8F0' );
$cv_items_img_shadow_val   = $_img_shadow_css( $cd, 'items_img' );
// Real feature, items 3 & 4: configurable grid columns for Services and
// Product & Service sections — same established pattern as the existing
// mobile-only $mv_items_cols setting, extended to desktop/tablet. Card
// sizing adapts automatically: CSS grid's repeat(N,1fr) naturally
// redistributes available width across however many columns are set.
$cv_svc_grid_cols   = max( 1, min( 6, (int) ( $cd['svc_grid_cols']   ?? 4 ) ) );
$cv_items_grid_cols = max( 1, min( 6, (int) ( $cd['items_grid_cols'] ?? 3 ) ) );
// Real fix — card/column gap controls, previously missing for these
// three sections (Gallery already had this exact pattern; Services,
// Products & Services, and Packages did not). Same clamped range and
// resolution style as Gallery's own proven gallery_gap control.
$cv_svc_gap   = max( 4, min( 40, (int) ( $cd['svc_gap']   ?? 16 ) ) );
$cv_items_gap = max( 4, min( 40, (int) ( $cd['items_gap'] ?? 20 ) ) );
$cv_pkg_gap   = max( 4, min( 40, (int) ( $cd['pkg_gap']   ?? 20 ) ) );
// Real fix — extending the same card/column gap control to every
// other card-grid section on the platform, per the request's own
// explicit "check whether other section types are missing this
// functionality... make the control available there as well" —
// same clamped pattern, each default matching that section's own
// original hardcoded value so nothing changes until a vendor adjusts it.
$cv_am_gap        = max( 4, min( 40, (int) ( $cd['am_gap']        ?? 14 ) ) );
$cv_awd_gap       = max( 4, min( 40, (int) ( $cd['awd_gap']       ?? 24 ) ) );
$cv_fac_gap       = max( 4, min( 40, (int) ( $cd['fac_gap']       ?? 22 ) ) );
$cv_feat_prop_gap = max( 4, min( 40, (int) ( $cd['feat_prop_gap'] ?? 24 ) ) );
$cv_hl_gap        = max( 4, min( 40, (int) ( $cd['hl_gap']        ?? 18 ) ) );
$cv_hw_dept_gap   = max( 4, min( 40, (int) ( $cd['hw_dept_gap']   ?? 24 ) ) );
// Real fix — same pattern as Project Categories: --vs-hw-dept-cols
// was referenced in .vs-hw-dept-grid but never actually resolved
// anywhere, meaning Departments' existing "Columns" dropdown has had
// no effect on the live page. Fixed alongside the gap control.
$cv_hw_dept_cols  = max( 2, min( 5, (int) ( $cd['departments_grid_cols'] ?? 3 ) ) );
$cv_ida_3d_gap    = max( 4, min( 40, (int) ( $cd['ida_3d_gap']    ?? 28 ) ) );
$cv_ida_ba_gap    = max( 4, min( 40, (int) ( $cd['ida_ba_gap']    ?? 28 ) ) );
$cv_ida_cat_gap   = max( 4, min( 40, (int) ( $cd['ida_cat_gap']   ?? 20 ) ) );
// Real fix — --vs-ida-cat-cols was referenced in this section's own
// CSS (.vs-ida-cat-grid) but never actually resolved or output
// anywhere, meaning the existing "Columns" dropdown in Project
// Categories' admin panel has had no effect on the live page at all
// since it was built. Fixed here alongside the gap control this
// section was otherwise about to get, since leaving a column control
// broken right next to a newly-working gap control would be an odd
// place to stop.
$cv_ida_cat_cols  = max( 2, min( 5, (int) ( $cd['project_categories_grid_cols'] ?? 3 ) ) );
$cv_lang_gap      = max( 4, min( 40, (int) ( $cd['lang_gap']      ?? 16 ) ) );
$cv_mem_gap       = max( 4, min( 40, (int) ( $cd['mem_gap']       ?? 22 ) ) );
$cv_portfolio_gap = max( 4, min( 40, (int) ( $cd['portfolio_gap'] ?? 20 ) ) );
$cv_pricing_gap   = max( 4, min( 40, (int) ( $cd['pricing_gap']   ?? 20 ) ) );
$cv_prop_gap      = max( 4, min( 40, (int) ( $cd['prop_gap']      ?? 20 ) ) );
$cv_prop_type_gap = max( 4, min( 40, (int) ( $cd['prop_type_gap'] ?? 18 ) ) );
$cv_reviews_gap   = max( 4, min( 40, (int) ( $cd['reviews_gap']   ?? 18 ) ) );
$cv_room_gap      = max( 4, min( 40, (int) ( $cd['room_gap']      ?? 20 ) ) );
$cv_team_gap      = max( 4, min( 40, (int) ( $cd['team_gap']      ?? 20 ) ) );
$cv_testi_gap     = max( 4, min( 40, (int) ( $cd['testi_gap']     ?? 20 ) ) );
// Real feature — a genuinely separate mobile gap control for the 9
// sections whose mobile view had its own deliberately tighter,
// hardcoded spacing, independent of the desktop gap control above.
// Each defaults to that section's own original mobile value, so this
// is invisible until a vendor explicitly adjusts it — the desktop gap
// setting was confirmed NOT safe to reuse here directly, since it's
// always resolved (never genuinely absent), which would have silently
// widened every existing vendor's mobile view the moment this shipped.
$cv_svc_gap_mobile       = max( 4, min( 40, (int) ( $cd['svc_gap_mobile']       ?? 10 ) ) );
$cv_items_gap_mobile     = max( 4, min( 40, (int) ( $cd['items_gap_mobile']     ?? 10 ) ) );
$cv_pkg_gap_mobile       = max( 4, min( 40, (int) ( $cd['pkg_gap_mobile']       ?? 14 ) ) );
$cv_room_gap_mobile      = max( 4, min( 40, (int) ( $cd['room_gap_mobile']      ?? 12 ) ) );
$cv_prop_gap_mobile      = max( 4, min( 40, (int) ( $cd['prop_gap_mobile']      ?? 12 ) ) );
$cv_prop_type_gap_mobile = max( 4, min( 40, (int) ( $cd['prop_type_gap_mobile'] ?? 12 ) ) );
$cv_ida_cat_gap_mobile   = max( 4, min( 40, (int) ( $cd['ida_cat_gap_mobile']   ?? 14 ) ) );
$cv_hw_dept_gap_mobile   = max( 4, min( 40, (int) ( $cd['hw_dept_gap_mobile']   ?? 16 ) ) );
$cv_svc_max_rows    = max( 0, min( 10, (int) ( $cd['svc_max_rows']   ?? 0 ) ) ); // 0 = unlimited
$cv_items_max_rows  = max( 0, min( 10, (int) ( $cd['items_max_rows'] ?? 0 ) ) ); // 0 = unlimited
// Real feature — Room Types configuration, matching the same
// established resolution pattern as Items/Services immediately above
// (rows/columns) and Packages (section title, photo display), so this
// section reaches the same level of configurability through the exact
// same reusable architecture, not a one-off mechanism.
$cv_room_types_grid_cols = max( 1, min( 6, (int) ( $cd['room_types_grid_cols'] ?? 3 ) ) );
$cv_room_types_max_rows  = max( 0, min( 10, (int) ( $cd['room_types_max_rows'] ?? 0 ) ) ); // 0 = unlimited
$cv_room_types_section_title = ! empty( $cd['room_types_section_title'] ) ? $cd['room_types_section_title'] : 'Room Types';
$cv_room_types_img = is_array( $cd['room_types_img_display'] ?? null ) ? $cd['room_types_img_display'] : [];
$cv_room_types_img_fit = $_fit_v( $cv_room_types_img['fit'] ?? 'cover', 'cover' );
$cv_room_popup_img_fit = $_fit_v( $cd['room_popup_img_fit'] ?? 'cover', 'cover' );
$cv_room_types_img_position = in_array( $cv_room_types_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_room_types_img['position'] : 'center';
$cv_room_types_img_zoom = max( 50, min( 200, (int) ( $cv_room_types_img['zoom'] ?? 100 ) ) );
$cv_room_slider_interval = max( 0, min( 30, (float) ( $cd['room_slider_interval'] ?? 0 ) ) ) * 1000;
$cv_hev_section_title = ! empty( $cd['hotel_event_spaces_section_title'] ) ? $cd['hotel_event_spaces_section_title'] : 'Celebrate Your Moments Here';
$cv_hev_section_desc  = $cd['hotel_event_spaces_section_description'] ?? '';
$cv_hev_img           = is_array( $cd['hotel_event_spaces_img_display'] ?? null ) ? $cd['hotel_event_spaces_img_display'] : [];
$cv_hevs_section_title = ! empty( $cd['hotel_events_showcase_section_title'] ) ? $cd['hotel_events_showcase_section_title'] : 'Events at the Property';
$cv_hevs_section_desc  = $cd['hotel_events_showcase_section_description'] ?? '';
$cv_hevs_img           = is_array( $cd['hotel_events_showcase_img_display'] ?? null ) ? $cd['hotel_events_showcase_img_display'] : [];
$cv_hdin_section_title = ! empty( $cd['hotel_dining_section_title'] ) ? $cd['hotel_dining_section_title'] : 'Dining & Culinary Experience';
$cv_hdin_section_desc  = $cd['hotel_dining_section_description'] ?? '';
$cv_hdin_img           = is_array( $cd['hotel_dining_img_display'] ?? null ) ? $cd['hotel_dining_img_display'] : [];
$cv_hamn_section_title = ! empty( $cd['hotel_amenities_section_title'] ) ? $cd['hotel_amenities_section_title'] : 'Amenities & Facilities';
$cv_hamn_section_desc  = $cd['hotel_amenities_section_description'] ?? '';
$cv_hvt_section_title  = ! empty( $cd['hotel_virtual_tour_section_title'] ) ? $cd['hotel_virtual_tour_section_title'] : 'Take a Virtual Tour';
$cv_hvt_section_desc   = $cd['hotel_virtual_tour_section_description'] ?? '';
$cv_hcb_business_type  = (string) ( $cd['hotel_closing_banner_business_type'] ?? '' );
$cv_hcb_section_title  = $cd['hotel_closing_banner_section_title'] ?? '';
$cv_hcb_section_desc   = $cd['hotel_closing_banner_section_description'] ?? '';
// Real estate module 1 of 4 — Property Listings. Same resolution
// pattern as Room Types immediately above, plus a section description
// field and the show/hide field toggles the request's own "Section
// Settings" list specifies.
$cv_prop_grid_cols = max( 1, min( 6, (int) ( $cd['property_listings_grid_cols'] ?? 3 ) ) );
$cv_prop_max_rows  = max( 0, min( 10, (int) ( $cd['property_listings_max_rows'] ?? 0 ) ) );
$cv_prop_section_title = ! empty( $cd['property_listings_section_title'] ) ? $cd['property_listings_section_title'] : 'Available Properties';
$cv_prop_section_desc  = $cd['property_listings_section_description'] ?? '';
$cv_prop_img = is_array( $cd['property_listings_img_display'] ?? null ) ? $cd['property_listings_img_display'] : [];
$cv_prop_img_fit = $_fit_v( $cv_prop_img['fit'] ?? 'cover', 'cover' );
$cv_prop_img_position = in_array( $cv_prop_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_prop_img['position'] : 'center';
$cv_prop_img_zoom = max( 50, min( 200, (int) ( $cv_prop_img['zoom'] ?? 100 ) ) );
$cv_prop_display = is_array( $cd['property_listings_display'] ?? null ) ? $cd['property_listings_display'] : [];
$cv_prop_sort = in_array( $cd['property_listings_sort'] ?? 'default', array_keys( \GoodService\Modules\PropertyListingsModule::SORT_MODES ), true ) ? $cd['property_listings_sort'] : 'default';
// Real estate module 2 of 4 — Featured Properties. Independent
// resolution from Property Listings above — its own section title,
// selection mode/filter, limit, grid columns, and photo settings.
$cv_feat_grid_cols = max( 1, min( 4, (int) ( $cd['featured_properties_grid_cols'] ?? 2 ) ) );
$cv_feat_limit = max( 0, min( 20, (int) ( $cd['featured_properties_limit'] ?? 0 ) ) );
$cv_feat_section_title = ! empty( $cd['featured_properties_section_title'] ) ? $cd['featured_properties_section_title'] : 'Featured Properties';
$cv_feat_section_desc = $cd['featured_properties_section_description'] ?? '';
$cv_feat_selection_mode = in_array( $cd['featured_properties_selection_mode'] ?? 'manual', array_keys( \GoodService\Modules\FeaturedPropertiesModule::SELECTION_MODES ), true ) ? $cd['featured_properties_selection_mode'] : 'manual';
$cv_feat_selection_filter = is_array( $cd['featured_properties_selection_filter'] ?? null ) ? $cd['featured_properties_selection_filter'] : [];
$cv_feat_img = is_array( $cd['featured_properties_img_display'] ?? null ) ? $cd['featured_properties_img_display'] : [];
$cv_feat_img_fit = $_fit_v( $cv_feat_img['fit'] ?? 'cover', 'cover' );
$cv_feat_img_position = in_array( $cv_feat_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_feat_img['position'] : 'center';
$cv_feat_img_zoom = max( 50, min( 200, (int) ( $cv_feat_img['zoom'] ?? 100 ) ) );
$cv_feat_display = is_array( $cd['featured_properties_display'] ?? null ) ? $cd['featured_properties_display'] : [];
// Real estate module 3 of 4 — Property Types/Categories. enabled_types
// empty array = show every type that has at least one property
// (PropertyTypesModule's own sensible default for a vendor who hasn't
// curated this yet); a non-empty array is the vendor's explicit
// selection, matching the request's own "Residential ✓, Commercial ✓,
// Industrial ✕" example exactly.
$cv_types_section_title = ! empty( $cd['property_types_section_title'] ) ? $cd['property_types_section_title'] : 'Browse by Property Type';
$cv_types_section_desc = $cd['property_types_section_description'] ?? '';
$cv_types_enabled = is_array( $cd['property_types_enabled'] ?? null ) ? $cd['property_types_enabled'] : [];
$cv_types_images = is_array( $cd['property_types_images'] ?? null ) ? $cd['property_types_images'] : [];
$cv_types_grid_cols = max( 1, min( 6, (int) ( $cd['property_types_grid_cols'] ?? 3 ) ) );
// Real estate module 4 of 4 — Property Gallery.
$cv_gal_section_title = ! empty( $cd['property_gallery_section_title'] ) ? $cd['property_gallery_section_title'] : 'Property Gallery';
$cv_gal_section_desc = $cd['property_gallery_section_description'] ?? '';
$cv_gal_layout = in_array( $cd['property_gallery_layout'] ?? 'grid', array_keys( \GoodService\Modules\PropertyGalleryModule::LAYOUTS ), true ) ? $cd['property_gallery_layout'] : 'grid';
$cv_gal_grid_cols = max( 2, min( 6, (int) ( $cd['property_gallery_grid_cols'] ?? 4 ) ) );
$cv_gal_lightbox = ( $cd['property_gallery_lightbox'] ?? 1 ) ? true : false;
$cv_gal_captions = ( $cd['property_gallery_captions'] ?? 1 ) ? true : false;
$cv_gal_max_images = max( 0, min( 60, (int) ( $cd['property_gallery_max_images'] ?? 0 ) ) );
$cv_gal_aspect = in_array( $cd['property_gallery_aspect'] ?? '4/3', [ '4/3', '1/1', '16/9', '3/4' ], true ) ? $cd['property_gallery_aspect'] : '4/3';
$cv_gal_radius = max( 0, min( 40, (int) ( $cd['property_gallery_radius'] ?? 12 ) ) ) . 'px';
$cv_gal_gap = max( 0, min( 60, (int) ( $cd['property_gallery_gap'] ?? 16 ) ) );
$cv_gal_img = is_array( $cd['property_gallery_img_display'] ?? null ) ? $cd['property_gallery_img_display'] : [];
$cv_gal_img_fit = $_fit_v( $cv_gal_img['fit'] ?? 'cover', 'cover' );
$cv_gal_img_position = in_array( $cv_gal_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_gal_img['position'] : 'center';
$cv_gal_img_zoom = max( 50, min( 200, (int) ( $cv_gal_img['zoom'] ?? 100 ) ) );
// Interior Designers & Architects module 1 of 5 — Featured Projects.
$cv_ida_fp_section_title = ! empty( $cd['featured_projects_section_title'] ) ? $cd['featured_projects_section_title'] : 'Featured Projects';
$cv_ida_fp_section_desc = $cd['featured_projects_section_description'] ?? '';
$cv_ida_fp_layout = in_array( $cd['featured_projects_layout'] ?? 'editorial', array_keys( \GoodService\Modules\FeaturedProjectsModule::LAYOUTS ), true ) ? $cd['featured_projects_layout'] : 'editorial';
$cv_ida_fp_selected_ids = is_array( $cd['featured_projects_selected_ids'] ?? null ) ? $cd['featured_projects_selected_ids'] : [];
$cv_ida_fp_max = max( 0, min( 30, (int) ( $cd['featured_projects_max'] ?? 0 ) ) );
$cv_ida_fp_display = is_array( $cd['featured_projects_display'] ?? null ) ? $cd['featured_projects_display'] : [];
$cv_ida_fp_img = is_array( $cd['featured_projects_img_display'] ?? null ) ? $cd['featured_projects_img_display'] : [];
$cv_ida_fp_img_fit = $_fit_v( $cv_ida_fp_img['fit'] ?? 'cover', 'cover' );
$cv_ida_fp_popup_img_fit = $_fit_v( $cd['ida_fp_popup_img_fit'] ?? 'cover', 'cover' );
$cv_ida_fp_img_position = in_array( $cv_ida_fp_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_ida_fp_img['position'] : 'center';
$cv_ida_fp_img_zoom = max( 50, min( 200, (int) ( $cv_ida_fp_img['zoom'] ?? 100 ) ) );
$cv_ida_fp_slider_interval = max( 0, min( 30, (float) ( $cd['ida_fp_slider_interval'] ?? 0 ) ) ) * 1000;
// Interior Designers & Architects module 2 of 5 — Project Categories.
$cv_ida_pc_section_title = ! empty( $cd['project_categories_section_title'] ) ? $cd['project_categories_section_title'] : 'Project Categories';
$cv_ida_pc_section_desc = $cd['project_categories_section_description'] ?? '';
$cv_ida_pc_defs = is_array( $cd['project_categories_defs'] ?? null ) ? $cd['project_categories_defs'] : [];
$cv_ida_pc_grid_cols = max( 2, min( 5, (int) ( $cd['project_categories_grid_cols'] ?? 3 ) ) );
$cv_ida_pc_img = is_array( $cd['project_categories_img_display'] ?? null ) ? $cd['project_categories_img_display'] : [];
$cv_ida_pc_img_fit = $_fit_v( $cv_ida_pc_img['fit'] ?? 'cover', 'cover' );
$cv_ida_pc_img_position = in_array( $cv_ida_pc_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_ida_pc_img['position'] : 'center';
$cv_ida_pc_img_zoom = max( 50, min( 200, (int) ( $cv_ida_pc_img['zoom'] ?? 100 ) ) );
// Interior Designers & Architects module 3 of 5 — 3D Designs & Before/After.
$cv_ida_3d_section_title = ! empty( $cd['three_d_before_after_section_title'] ) ? $cd['three_d_before_after_section_title'] : '3D Designs & Before/After';
$cv_ida_3d_section_desc = $cd['three_d_before_after_section_description'] ?? '';
$cv_ida_3d_ba_layout = in_array( $cd['three_d_before_after_ba_layout'] ?? 'slider', array_keys( \GoodService\Modules\ThreeDBeforeAfterModule::BA_LAYOUTS ), true ) ? $cd['three_d_before_after_ba_layout'] : 'slider';
$cv_ida_3d_img = is_array( $cd['three_d_before_after_img_display'] ?? null ) ? $cd['three_d_before_after_img_display'] : [];
$cv_ida_3d_img_fit = $_fit_v( $cv_ida_3d_img['fit'] ?? 'cover', 'cover' );
$cv_ida_3d_img_position = in_array( $cv_ida_3d_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_ida_3d_img['position'] : 'center';
$cv_ida_3d_img_zoom = max( 50, min( 200, (int) ( $cv_ida_3d_img['zoom'] ?? 100 ) ) );
// Interior Designers & Architects module 4 of 5 — Design Styles & Expertise.
$cv_ida_ds_section_title = ! empty( $cd['design_styles_section_title'] ) ? $cd['design_styles_section_title'] : 'Design Styles & Expertise';
$cv_ida_ds_section_desc = $cd['design_styles_section_description'] ?? '';
$cv_ida_ds_style_defs = is_array( $cd['design_styles_style_defs'] ?? null ) ? $cd['design_styles_style_defs'] : [];
$cv_ida_ds_expertise_defs = is_array( $cd['design_styles_expertise_defs'] ?? null ) ? $cd['design_styles_expertise_defs'] : [];
$cv_ida_ds_img = is_array( $cd['design_styles_img_display'] ?? null ) ? $cd['design_styles_img_display'] : [];
$cv_ida_ds_img_fit = $_fit_v( $cv_ida_ds_img['fit'] ?? 'cover', 'cover' );
$cv_ida_ds_img_position = in_array( $cv_ida_ds_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_ida_ds_img['position'] : 'center';
$cv_ida_ds_img_zoom = max( 50, min( 200, (int) ( $cv_ida_ds_img['zoom'] ?? 100 ) ) );
// Interior Designers & Architects module 5 of 5 — Design Process.
$cv_ida_dp_section_title = ! empty( $cd['design_process_section_title'] ) ? $cd['design_process_section_title'] : 'Our Design Process';
$cv_ida_dp_section_desc = $cd['design_process_section_description'] ?? '';
$cv_ida_dp_layout = in_array( $cd['design_process_layout'] ?? 'timeline', array_keys( \GoodService\Modules\DesignProcessModule::LAYOUTS ), true ) ? $cd['design_process_layout'] : 'timeline';
$cv_ida_dp_steps = is_array( $cd['design_process_steps'] ?? null ) ? $cd['design_process_steps'] : [];
$cv_ida_dp_img = is_array( $cd['design_process_img_display'] ?? null ) ? $cd['design_process_img_display'] : [];
$cv_ida_dp_img_fit = $_fit_v( $cv_ida_dp_img['fit'] ?? 'cover', 'cover' );
$cv_ida_dp_img_position = in_array( $cv_ida_dp_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_ida_dp_img['position'] : 'center';
$cv_ida_dp_img_zoom = max( 50, min( 200, (int) ( $cv_ida_dp_img['zoom'] ?? 100 ) ) );
// Health & Wellness module 1 of 5 — Featured Services & Treatments.
$cv_hw_fs_section_title = ! empty( $cd['featured_services_section_title'] ) ? $cd['featured_services_section_title'] : 'Our Services & Treatments';
$cv_hw_fs_section_desc = $cd['featured_services_section_description'] ?? '';
$cv_hw_fs_layout = in_array( $cd['featured_services_layout'] ?? 'directory', array_keys( \GoodService\Modules\FeaturedServicesModule::LAYOUTS ), true ) ? $cd['featured_services_layout'] : 'directory';
$cv_hw_fs_img = is_array( $cd['featured_services_img_display'] ?? null ) ? $cd['featured_services_img_display'] : [];
// Beauty & Salon, section 01 of 6 — Beauty Service Discovery.
// PERF: same fully-gated shape as beauty_facilities — safe defaults
// outside, everything else (verified via grep to be used ONLY at this
// section's own already-gated render call site) inside one
// $_sec_show('beauty_services') block, so a non-Beauty listing (or one
// with this section off) does none of this work.
$cv_bs_section_title = 'Beauty & Salon Services';
$cv_bs_section_desc  = '';
$cv_bs_img           = [];
$cv_bs_style_css = $cv_bs_container_css = $cv_bs_heading_css = '';
if ( $_sec_show( 'beauty_services' ) ) {
    $cv_bs_section_title = ! empty( $cd['beauty_services_section_title'] ) ? $cd['beauty_services_section_title'] : 'Beauty & Salon Services';
    $cv_bs_section_desc  = $cd['beauty_services_section_description'] ?? '';
    $cv_bs_img           = is_array( $cd['beauty_services_img_display'] ?? null ) ? $cd['beauty_services_img_display'] : [];
    // Element style controls — card, grid, badge, CTA. Same shared
    // resolver as every other section; isolated to 'beauty_services_style'.
    $_bs_style = is_array( $cd['beauty_services_style'] ?? null ) ? $cd['beauty_services_style'] : [];
    // Grid columns is a whitelisted count, not free text — validated
    // before it can reach the 'raw' resolver type (same discipline as
    // every other raw-typed field: never pass unvalidated input through).
    $_bs_style['grid_columns_resolved'] = in_array( (int) ( $_bs_style['grid_columns'] ?? 3 ), [ 2, 3, 4 ], true ) ? (int) $_bs_style['grid_columns'] : 3;
    $cv_bs_style_css = \gs_vs_section_style_vars(
        $_bs_style,
        [
            'grid_columns_resolved' => [ 'var' => '--gs-bs-grid-cols',   'type' => 'raw',   'default' => 3 ],
            'grid_gap'              => [ 'var' => '--gs-bs-grid-gap',    'type' => 'px',    'default' => 28, 'min' => 8, 'max' => 60 ],
            'card_radius'           => [ 'var' => '--gs-bs-card-radius', 'type' => 'px',    'default' => 4,  'min' => 0, 'max' => 32 ],
            'card_border'           => [ 'var' => '--gs-bs-card-border', 'type' => 'color', 'default' => '#E7E0D6' ],
            'card_padding'          => [ 'var' => '--gs-bs-card-padding','type' => 'px',    'default' => 24, 'min' => 8, 'max' => 48 ],
            'badge_bg'              => [ 'var' => '--gs-bs-badge-bg',    'type' => 'color', 'default' => '#FFFDFB' ],
            'badge_color'           => [ 'var' => '--gs-bs-badge-color', 'type' => 'color', 'default' => '#2B2620' ],
            'cta_bg'                => [ 'var' => '--gs-bs-cta-bg',      'type' => 'color', 'default' => '#2B2620' ],
            'cta_radius'            => [ 'var' => '--gs-bs-cta-radius',  'type' => 'px',    'default' => 2,  'min' => 0, 'max' => 24 ],
        ]
    );
    // Section CONTAINER style.
    $_bs_cs = is_array( $cd['beauty_services_container_style'] ?? null ) ? $cd['beauty_services_container_style'] : [];
    $_bs_cs['bg_resolved'] = \gs_vs_compose_section_bg( $_bs_cs );
    $_bs_cs_shadow_key = in_array( $_bs_cs['shadow'] ?? 'none', [ 'none', 'soft', 'strong' ], true ) ? $_bs_cs['shadow'] : 'none';
    $_bs_cs['shadow_resolved'] = [ 'none' => 'none', 'soft' => '0 8px 24px -12px rgba(43,38,32,.18)', 'strong' => '0 24px 56px -16px rgba(43,38,32,.35)' ][ $_bs_cs_shadow_key ];
    $cv_bs_container_css = \gs_vs_section_style_vars( $_bs_cs, [
        'bg_resolved'    => [ 'var' => '--gs-bs-sec-bg',       'type' => 'raw',   'default' => 'transparent' ],
        'padding_top'    => [ 'var' => '--gs-bs-pad-t',        'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 160 ],
        'padding_bottom' => [ 'var' => '--gs-bs-pad-b',        'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 160 ],
        'padding_left'   => [ 'var' => '--gs-bs-pad-l',        'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 120 ],
        'padding_right'  => [ 'var' => '--gs-bs-pad-r',        'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 120 ],
        'border_width'   => [ 'var' => '--gs-bs-border-w',     'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 12 ],
        'border_color'   => [ 'var' => '--gs-bs-border-color', 'type' => 'color', 'default' => 'transparent' ],
        'border_radius'  => [ 'var' => '--gs-bs-border-radius','type' => 'px',    'default' => 0, 'min' => 0, 'max' => 40 ],
        'shadow_resolved'=> [ 'var' => '--gs-bs-sec-shadow',   'type' => 'raw',   'default' => 'none' ],
    ] );
    // Section HEADING style — title font-size/weight/color/alignment are
    // already handled by the pre-existing, shared
    // TypographyService::css_rule() call for 'beauty_services_heading'
    // (wired below to '#vs-sec-beauty_services .vs-sec-title', with its
    // matching cl_typography_fields() admin panel). Not duplicated here
    // — same corrected pattern as beauty_facilities. Description
    // typography has its own TypographyService prefix,
    // 'beauty_services_desc'.
    $_bs_hs = is_array( $cd['beauty_services_heading_style'] ?? null ) ? $cd['beauty_services_heading_style'] : [];
    $cv_bs_heading_css = \gs_vs_section_style_vars( $_bs_hs, [
        'eyebrow_color' => [ 'var' => '--gs-bs-eyebrow-color', 'type' => 'color', 'default' => '#C9A867' ],
        'heading_gap'   => [ 'var' => '--gs-bs-heading-gap',   'type' => 'px',    'default' => 44,  'min' => 0, 'max' => 100 ],
    ] );
}
// Beauty & Salon, section 02 of 6 — Signature Looks & Transformations.
// PERF: same fully-gated shape as beauty_facilities/beauty_services —
// safe defaults outside, everything else inside one
// $_sec_show('beauty_gallery') block, so a non-Beauty listing (or one
// with this section off) does none of this work.
$cv_bg_section_title = 'Signature Looks & Transformations';
$cv_bg_section_desc  = '';
$cv_bg_img           = [];
$cv_bg_style_css = $cv_bg_container_css = $cv_bg_heading_css = '';
if ( $_sec_show( 'beauty_gallery' ) ) {
    $cv_bg_section_title = ! empty( $cd['beauty_gallery_section_title'] ) ? $cd['beauty_gallery_section_title'] : 'Signature Looks & Transformations';
    $cv_bg_section_desc  = $cd['beauty_gallery_section_description'] ?? '';
    $cv_bg_img           = is_array( $cd['beauty_gallery_img_display'] ?? null ) ? $cd['beauty_gallery_img_display'] : [];
    // Element style controls — grid gap, item corner radius, caption
    // typography, before/after handle color. Isolated to
    // 'beauty_gallery_style'.
    $_bg_style = is_array( $cd['beauty_gallery_style'] ?? null ) ? $cd['beauty_gallery_style'] : [];
    $cv_bg_style_css = \gs_vs_section_style_vars( $_bg_style, [
        'grid_gap'      => [ 'var' => '--gs-bg-grid-gap',   'type' => 'px',    'default' => 24, 'min' => 8,  'max' => 60 ],
        'item_radius'   => [ 'var' => '--gs-bg-item-radius','type' => 'px',    'default' => 4,  'min' => 0,  'max' => 32 ],
        'caption_color' => [ 'var' => '--gs-bg-caption-color','type' => 'color','default' => '#2B2620' ],
        'handle_color'  => [ 'var' => '--gs-bg-handle-color','type' => 'color','default' => '#FFFDFB' ],
    ] );
    // Section CONTAINER style — same shared shape as every other section.
    $_bg_cs = is_array( $cd['beauty_gallery_container_style'] ?? null ) ? $cd['beauty_gallery_container_style'] : [];
    $_bg_cs['bg_resolved'] = \gs_vs_compose_section_bg( $_bg_cs );
    $_bg_cs_shadow_key = in_array( $_bg_cs['shadow'] ?? 'none', [ 'none', 'soft', 'strong' ], true ) ? $_bg_cs['shadow'] : 'none';
    $_bg_cs['shadow_resolved'] = [ 'none' => 'none', 'soft' => '0 8px 24px -12px rgba(43,38,32,.18)', 'strong' => '0 24px 56px -16px rgba(43,38,32,.35)' ][ $_bg_cs_shadow_key ];
    $cv_bg_container_css = \gs_vs_section_style_vars( $_bg_cs, [
        'bg_resolved'    => [ 'var' => '--gs-bg-sec-bg',       'type' => 'raw',   'default' => 'transparent' ],
        'padding_top'    => [ 'var' => '--gs-bg-pad-t',        'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 160 ],
        'padding_bottom' => [ 'var' => '--gs-bg-pad-b',        'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 160 ],
        'padding_left'   => [ 'var' => '--gs-bg-pad-l',        'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 120 ],
        'padding_right'  => [ 'var' => '--gs-bg-pad-r',        'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 120 ],
        'border_width'   => [ 'var' => '--gs-bg-border-w',     'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 12 ],
        'border_color'   => [ 'var' => '--gs-bg-border-color', 'type' => 'color', 'default' => 'transparent' ],
        'border_radius'  => [ 'var' => '--gs-bg-border-radius','type' => 'px',    'default' => 0, 'min' => 0, 'max' => 40 ],
        'shadow_resolved'=> [ 'var' => '--gs-bg-sec-shadow',   'type' => 'raw',   'default' => 'none' ],
    ] );
    // Section HEADING style — title font-size/weight/color/alignment are
    // already handled by the pre-existing, shared
    // TypographyService::css_rule() call for 'beauty_gallery_heading'.
    // Not duplicated here (same corrected pattern as beauty_facilities/
    // beauty_services). Description typography has its own
    // TypographyService prefix, 'beauty_gallery_desc'.
    $_bg_hs = is_array( $cd['beauty_gallery_heading_style'] ?? null ) ? $cd['beauty_gallery_heading_style'] : [];
    $cv_bg_heading_css = \gs_vs_section_style_vars( $_bg_hs, [
        'eyebrow_color' => [ 'var' => '--gs-bg-eyebrow-color', 'type' => 'color', 'default' => '#C9A867' ],
        'heading_gap'   => [ 'var' => '--gs-bg-heading-gap',   'type' => 'px',    'default' => 44,  'min' => 0, 'max' => 100 ],
    ] );
}
// Beauty & Salon, section 03 of 6 — Beauty Experts / Stylists.
// PERF: same fully-gated shape as beauty_facilities/beauty_services/
// beauty_gallery.
$cv_be_section_title = 'Meet Our Beauty Experts';
$cv_be_section_desc  = '';
$cv_be_img           = [];
$cv_be_style_css = $cv_be_container_css = $cv_be_heading_css = '';
if ( $_sec_show( 'beauty_experts' ) ) {
    $cv_be_section_title = ! empty( $cd['beauty_experts_section_title'] ) ? $cd['beauty_experts_section_title'] : 'Meet Our Beauty Experts';
    $cv_be_section_desc  = $cd['beauty_experts_section_description'] ?? '';
    $cv_be_img           = is_array( $cd['beauty_experts_img_display'] ?? null ) ? $cd['beauty_experts_img_display'] : [];
    // Element style controls — grid columns, card, media, badge, tag,
    // book-button colors. Isolated to 'beauty_experts_style'.
    $_be_style = is_array( $cd['beauty_experts_style'] ?? null ) ? $cd['beauty_experts_style'] : [];
    $_be_style['grid_columns_resolved'] = in_array( (int) ( $_be_style['grid_columns'] ?? 4 ), [ 2, 3, 4 ], true ) ? (int) $_be_style['grid_columns'] : 4;
    $cv_be_style_css = \gs_vs_section_style_vars( $_be_style, [
        'grid_columns_resolved' => [ 'var' => '--gs-be-grid-cols',  'type' => 'raw',   'default' => 4 ],
        'grid_gap'              => [ 'var' => '--gs-be-grid-gap',   'type' => 'px',    'default' => 24, 'min' => 8, 'max' => 60 ],
        'card_radius'           => [ 'var' => '--gs-be-card-radius','type' => 'px',    'default' => 4,  'min' => 0, 'max' => 32 ],
        'card_border'           => [ 'var' => '--gs-be-card-border','type' => 'color', 'default' => '#E7E0D6' ],
        'name_color'            => [ 'var' => '--gs-be-name-color', 'type' => 'color', 'default' => '#2B2620' ],
        'role_color'            => [ 'var' => '--gs-be-role-color', 'type' => 'color', 'default' => '#8A7B6C' ],
        'tag_bg'                => [ 'var' => '--gs-be-tag-bg',     'type' => 'color', 'default' => '#FAF7F2' ],
        'tag_color'             => [ 'var' => '--gs-be-tag-color',  'type' => 'color', 'default' => '#2B2620' ],
        'book_btn_bg'           => [ 'var' => '--gs-be-book-bg',    'type' => 'color', 'default' => '#2B2620' ],
        'verified_bg'           => [ 'var' => '--gs-be-verified-bg','type' => 'color', 'default' => '#FFFDFB' ],
    ] );
    // Section CONTAINER style — same shared shape as every other section.
    $_be_cs = is_array( $cd['beauty_experts_container_style'] ?? null ) ? $cd['beauty_experts_container_style'] : [];
    $_be_cs['bg_resolved'] = \gs_vs_compose_section_bg( $_be_cs );
    $_be_cs_shadow_key = in_array( $_be_cs['shadow'] ?? 'none', [ 'none', 'soft', 'strong' ], true ) ? $_be_cs['shadow'] : 'none';
    $_be_cs['shadow_resolved'] = [ 'none' => 'none', 'soft' => '0 8px 24px -12px rgba(43,38,32,.18)', 'strong' => '0 24px 56px -16px rgba(43,38,32,.35)' ][ $_be_cs_shadow_key ];
    $cv_be_container_css = \gs_vs_section_style_vars( $_be_cs, [
        'bg_resolved'    => [ 'var' => '--gs-be-sec-bg',       'type' => 'raw',   'default' => 'transparent' ],
        'padding_top'    => [ 'var' => '--gs-be-pad-t',        'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 160 ],
        'padding_bottom' => [ 'var' => '--gs-be-pad-b',        'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 160 ],
        'padding_left'   => [ 'var' => '--gs-be-pad-l',        'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 120 ],
        'padding_right'  => [ 'var' => '--gs-be-pad-r',        'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 120 ],
        'border_width'   => [ 'var' => '--gs-be-border-w',     'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 12 ],
        'border_color'   => [ 'var' => '--gs-be-border-color', 'type' => 'color', 'default' => 'transparent' ],
        'border_radius'  => [ 'var' => '--gs-be-border-radius','type' => 'px',    'default' => 0, 'min' => 0, 'max' => 40 ],
        'shadow_resolved'=> [ 'var' => '--gs-be-sec-shadow',   'type' => 'raw',   'default' => 'none' ],
    ] );
    // Section HEADING style — title typography stays with the
    // pre-existing shared TypographyService for 'beauty_experts_heading';
    // not duplicated here. Description has its own TypographyService
    // prefix, 'beauty_experts_desc'.
    $_be_hs = is_array( $cd['beauty_experts_heading_style'] ?? null ) ? $cd['beauty_experts_heading_style'] : [];
    $cv_be_heading_css = \gs_vs_section_style_vars( $_be_hs, [
        'eyebrow_color' => [ 'var' => '--gs-be-eyebrow-color', 'type' => 'color', 'default' => '#C9A867' ],
        'heading_gap'   => [ 'var' => '--gs-be-heading-gap',   'type' => 'px',    'default' => 44,  'min' => 0, 'max' => 100 ],
    ] );
}
// Beauty & Salon, section 04 of 6 — Salon Experience & Facilities.
// PERF: EVERYTHING for this section — the pre-existing title/description/
// img_display reads AND the newer element/container/heading style
// resolution — is gated behind $_sec_show('beauty_facilities'), the SAME
// gate that decides whether this section's HTML/CSS gets emitted at all.
// A listing whose category never shows this section (any non-Beauty
// vertical — the large majority of listings on the platform), or one
// that simply toggled it off, now does ZERO array lookups / string
// building / regex validation for it — not just zero output. Every one
// of these variables is used ONLY at this section's own render call site
// (verified: grepped for each variable name across the whole file before
// moving it in here), which is itself already behind this same gate, so
// nothing outside this block can ever need them.
$cv_bf_section_title = 'The Salon Experience';
$cv_bf_section_desc  = '';
$cv_bf_img           = [];
$cv_bf_style_css = $cv_bf_container_css = $cv_bf_heading_css = '';
if ( $_sec_show( 'beauty_facilities' ) ) {
    $cv_bf_section_title = ! empty( $cd['beauty_facilities_section_title'] ) ? $cd['beauty_facilities_section_title'] : 'The Salon Experience';
    $cv_bf_section_desc  = $cd['beauty_facilities_section_description'] ?? '';
    $cv_bf_img           = is_array( $cd['beauty_facilities_img_display'] ?? null ) ? $cd['beauty_facilities_img_display'] : [];
    // Element style controls (radius/shadow/icon/list) — see
    // gs_vs_section_style_vars() below. Isolated per-section: this call
    // only ever reads/writes the 'beauty_facilities_style' key, so it
    // cannot affect any other section's own style block.
    $cv_bf_style_css = \gs_vs_section_style_vars(
        is_array( $cd['beauty_facilities_style'] ?? null ) ? $cd['beauty_facilities_style'] : [],
        [
            'media_radius'   => [ 'var' => '--gs-bf-media-radius',   'type' => 'px',   'default' => 6,  'min' => 0, 'max' => 40 ],
            'media_shadow'   => [ 'var' => '--gs-bf-media-shadow',   'type' => 'shadow','default' => '0 24px 48px -20px rgba(43,38,32,.28)' ],
            'check_color'    => [ 'var' => '--gs-bf-check-color',    'type' => 'color', 'default' => '#C9A867' ],
            'check_size'     => [ 'var' => '--gs-bf-check-size',     'type' => 'px',   'default' => 26, 'min' => 16, 'max' => 48 ],
            'item_font_size' => [ 'var' => '--gs-bf-item-font-size', 'type' => 'em',   'default' => .92, 'min' => .7, 'max' => 1.3 ],
            'item_color'     => [ 'var' => '--gs-bf-item-color',     'type' => 'color','default' => '#2B2620' ],
            'split_gap'      => [ 'var' => '--gs-bf-split-gap',      'type' => 'px',   'default' => 64, 'min' => 16, 'max' => 120 ],
        ]
    );
    // Section CONTAINER style (background/padding/border/shadow) — same
    // isolation guarantees as the element-style block above, using the
    // same shared resolver + the shared gs_vs_compose_section_bg() helper.
    $_bf_cs = is_array( $cd['beauty_facilities_container_style'] ?? null ) ? $cd['beauty_facilities_container_style'] : [];
    $_bf_cs['bg_resolved'] = \gs_vs_compose_section_bg( $_bf_cs );
    $_bf_cs_shadow_key = in_array( $_bf_cs['shadow'] ?? 'none', [ 'none', 'soft', 'strong' ], true ) ? $_bf_cs['shadow'] : 'none';
    $_bf_cs['shadow_resolved'] = [
        'none'   => 'none',
        'soft'   => '0 8px 24px -12px rgba(43,38,32,.18)',
        'strong' => '0 24px 56px -16px rgba(43,38,32,.35)',
    ][ $_bf_cs_shadow_key ];
    $cv_bf_container_css = \gs_vs_section_style_vars( $_bf_cs, [
        'bg_resolved'    => [ 'var' => '--gs-bf-sec-bg',      'type' => 'raw',   'default' => 'transparent' ],
        'padding_top'    => [ 'var' => '--gs-bf-pad-t',       'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 160 ],
        'padding_bottom' => [ 'var' => '--gs-bf-pad-b',       'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 160 ],
        'padding_left'   => [ 'var' => '--gs-bf-pad-l',       'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 120 ],
        'padding_right'  => [ 'var' => '--gs-bf-pad-r',       'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 120 ],
        'border_width'   => [ 'var' => '--gs-bf-border-w',    'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 12 ],
        'border_color'   => [ 'var' => '--gs-bf-border-color','type' => 'color', 'default' => 'transparent' ],
        'border_radius'  => [ 'var' => '--gs-bf-border-radius','type' => 'px',   'default' => 0, 'min' => 0, 'max' => 40 ],
        'shadow_resolved'=> [ 'var' => '--gs-bf-sec-shadow',  'type' => 'raw',   'default' => 'none' ],
    ] );
    // Section HEADING style — title font-size/weight/color/alignment are
    // handled by the pre-existing, shared TypographyService::css_rule()
    // call for 'beauty_facilities_heading' (already wired below to
    // '#vs-sec-beauty_facilities .vs-sec-title', with its matching
    // cl_typography_fields() admin panel). Building a second, competing
    // set of controls for the same properties would be exactly the
    // "unnecessary duplicate logic" to avoid, so this resolver is scoped
    // to only what TypographyService does NOT cover: eyebrow color,
    // description color, and the spacing below the heading block.
    // Description typography (size/align) is covered by its own
    // TypographyService prefix, 'beauty_facilities_desc'.
    $_bf_hs = is_array( $cd['beauty_facilities_heading_style'] ?? null ) ? $cd['beauty_facilities_heading_style'] : [];
    $cv_bf_heading_css = \gs_vs_section_style_vars( $_bf_hs, [
        'eyebrow_color' => [ 'var' => '--gs-bf-eyebrow-color', 'type' => 'color', 'default' => '#C9A867' ],
        'heading_gap'   => [ 'var' => '--gs-bf-heading-gap',   'type' => 'px',    'default' => 44,  'min' => 0, 'max' => 100 ],
    ] );
}
// Beauty & Salon, section 05 of 6 — Beauty Packages & Offers.
$cv_bp_section_title = 'Packages & Offers';
$cv_bp_section_desc  = '';
$cv_bp_img           = [];
$cv_bp_style_css = $cv_bp_container_css = $cv_bp_heading_css = '';
if ( $_sec_show( 'beauty_packages' ) ) {
    $cv_bp_section_title = ! empty( $cd['beauty_packages_section_title'] ) ? $cd['beauty_packages_section_title'] : 'Packages & Offers';
    $cv_bp_section_desc  = $cd['beauty_packages_section_description'] ?? '';
    $cv_bp_img           = is_array( $cd['beauty_packages_img_display'] ?? null ) ? $cd['beauty_packages_img_display'] : [];

    // Element style: only the properties genuinely specific to package
    // cards (grid/card/badge/price/save/CTA). Title typography is handled
    // by the pre-existing, shared TypographyService::css_rule() call for
    // 'beauty_packages_heading' (already wired below to
    // '#vs-sec-beauty_packages .vs-sec-title', with its matching
    // cl_typography_fields() admin panel) — never duplicated here.
    // Description typography has its own TypographyService prefix,
    // 'beauty_packages_desc' (added below), since that was a genuine gap.
    $_bp_style = is_array( $cd['beauty_packages_style'] ?? null ) ? $cd['beauty_packages_style'] : [];
    $cv_bp_style_css = \gs_vs_section_style_vars( $_bp_style, [
        'grid_gap'    => [ 'var' => '--gs-bp-grid-gap',    'type' => 'px',    'default' => 28,  'min' => 0, 'max' => 80 ],
        'card_radius' => [ 'var' => '--gs-bp-card-radius', 'type' => 'px',    'default' => 4,   'min' => 0, 'max' => 40 ],
        'card_border' => [ 'var' => '--gs-bp-card-border', 'type' => 'color', 'default' => '#E7E0D6' ],
        'badge_bg'    => [ 'var' => '--gs-bp-badge-bg',    'type' => 'color', 'default' => '#2B2620' ],
        'badge_color' => [ 'var' => '--gs-bp-badge-color', 'type' => 'color', 'default' => '#FFFDFB' ],
        'price_color' => [ 'var' => '--gs-bp-price-color', 'type' => 'color', 'default' => '#2B2620' ],
        'save_color'  => [ 'var' => '--gs-bp-save-color',  'type' => 'color', 'default' => '#3F7D58' ],
        'cta_bg'      => [ 'var' => '--gs-bp-cta-bg',      'type' => 'color', 'default' => '#2B2620' ],
        'cta_hover_bg'=> [ 'var' => '--gs-bp-cta-hover-bg','type' => 'color', 'default' => '#C9A867' ],
    ] );

    // Container style: standard background/padding/border/shadow, scoped
    // to #vs-sec-beauty_packages only. Same shared resolver +
    // gs_vs_compose_section_bg() helper used by every other Beauty module.
    $_bp_cs = is_array( $cd['beauty_packages_container_style'] ?? null ) ? $cd['beauty_packages_container_style'] : [];
    $_bp_cs['bg_resolved'] = \gs_vs_compose_section_bg( $_bp_cs );
    $_bp_cs_shadow_key = in_array( $_bp_cs['shadow'] ?? 'none', [ 'none', 'soft', 'strong' ], true ) ? $_bp_cs['shadow'] : 'none';
    $_bp_cs['shadow_resolved'] = [
        'none'   => 'none',
        'soft'   => '0 8px 24px -12px rgba(43,38,32,.18)',
        'strong' => '0 24px 56px -16px rgba(43,38,32,.35)',
    ][ $_bp_cs_shadow_key ];
    $cv_bp_container_css = \gs_vs_section_style_vars( $_bp_cs, [
        'bg_resolved'    => [ 'var' => '--gs-bp-sec-bg',      'type' => 'raw',   'default' => 'transparent' ],
        'padding_top'    => [ 'var' => '--gs-bp-pad-t',       'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 160 ],
        'padding_bottom' => [ 'var' => '--gs-bp-pad-b',       'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 160 ],
        'padding_left'   => [ 'var' => '--gs-bp-pad-l',       'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 120 ],
        'padding_right'  => [ 'var' => '--gs-bp-pad-r',       'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 120 ],
        'border_width'   => [ 'var' => '--gs-bp-border-w',    'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 12 ],
        'border_color'   => [ 'var' => '--gs-bp-border-color','type' => 'color', 'default' => 'transparent' ],
        'border_radius'  => [ 'var' => '--gs-bp-border-radius','type' => 'px',   'default' => 0, 'min' => 0, 'max' => 40 ],
        'shadow_resolved'=> [ 'var' => '--gs-bp-sec-shadow',  'type' => 'raw',   'default' => 'none' ],
    ] );

    // Heading style: eyebrow color + spacing below the heading block only
    // — never title_* fields (see comment above).
    $_bp_hs = is_array( $cd['beauty_packages_heading_style'] ?? null ) ? $cd['beauty_packages_heading_style'] : [];
    $cv_bp_heading_css = \gs_vs_section_style_vars( $_bp_hs, [
        'eyebrow_color' => [ 'var' => '--gs-bp-eyebrow-color', 'type' => 'color', 'default' => '#C9A867' ],
        'heading_gap'   => [ 'var' => '--gs-bp-heading-gap',   'type' => 'px',    'default' => 44,  'min' => 0, 'max' => 100 ],
    ] );
}
// Beauty & Salon, section 06 of 6 — Appointment/Booking Conversion.
$cv_bc_section_title = 'Ready to Book Your Appointment?';
$cv_bc_section_desc  = '';
$cv_bc_button_text   = 'Book Your Appointment';
$cv_bc_image         = '';
$cv_bc_img           = [];
$cv_bc_style_css = $cv_bc_container_css = $cv_bc_heading_css = '';
if ( $_sec_show( 'beauty_booking_cta' ) ) {
    $cv_bc_section_title = ! empty( $cd['beauty_booking_cta_section_title'] ) ? $cd['beauty_booking_cta_section_title'] : 'Ready to Book Your Appointment?';
    $cv_bc_section_desc  = $cd['beauty_booking_cta_section_description'] ?? '';
    $cv_bc_button_text   = $cd['beauty_booking_cta_button_text'] ?? 'Book Your Appointment';
    $cv_bc_image         = (string) ( $cd['beauty_booking_cta_image'] ?? '' );
    $cv_bc_img           = is_array( $cd['beauty_booking_cta_img_display'] ?? null ) ? $cd['beauty_booking_cta_img_display'] : [];

    // Element style: the visible closing-CTA panel itself (background,
    // corner radii, step markers, button colors). Title typography is
    // handled by the pre-existing, shared TypographyService::css_rule()
    // call for 'beauty_booking_cta_heading' (already wired below to
    // '#vs-sec-beauty_booking_cta .vs-sec-title') — never duplicated here.
    // This section has no separate "description" typography prefix added
    // (unlike the other 5 Beauty modules) because its description sits
    // directly in the same content block as the title with no distinct
    // class-level typography gap to close beyond what's already covered.
    $_bc_style = is_array( $cd['beauty_booking_cta_style'] ?? null ) ? $cd['beauty_booking_cta_style'] : [];
    $cv_bc_style_css = \gs_vs_section_style_vars( $_bc_style, [
        'panel_bg'       => [ 'var' => '--gs-bc-panel-bg',      'type' => 'color', 'default' => '#FAF7F2' ],
        'panel_radius'   => [ 'var' => '--gs-bc-panel-radius',  'type' => 'px',    'default' => 4,  'min' => 0, 'max' => 40 ],
        'media_radius'   => [ 'var' => '--gs-bc-media-radius',  'type' => 'px',    'default' => 4,  'min' => 0, 'max' => 40 ],
        'step_num_bg'    => [ 'var' => '--gs-bc-step-num-bg',   'type' => 'color', 'default' => '#2B2620' ],
        'step_num_color' => [ 'var' => '--gs-bc-step-num-color','type' => 'color', 'default' => '#FFFDFB' ],
        'step_text_color'=> [ 'var' => '--gs-bc-step-text-color','type' => 'color', 'default' => '#2B2620' ],
        'btn_bg'         => [ 'var' => '--gs-bc-btn-bg',        'type' => 'color', 'default' => '#2B2620' ],
        'btn_hover_bg'   => [ 'var' => '--gs-bc-btn-hover-bg',  'type' => 'color', 'default' => '#C9A867' ],
    ] );

    // Container style: standard outer-section background/padding/border/
    // shadow, scoped to #vs-sec-beauty_booking_cta only. Distinct from the
    // panel_bg above — this is the page-section wrapper AROUND the CTA
    // panel, not the panel itself.
    $_bc_cs = is_array( $cd['beauty_booking_cta_container_style'] ?? null ) ? $cd['beauty_booking_cta_container_style'] : [];
    $_bc_cs['bg_resolved'] = \gs_vs_compose_section_bg( $_bc_cs );
    $_bc_cs_shadow_key = in_array( $_bc_cs['shadow'] ?? 'none', [ 'none', 'soft', 'strong' ], true ) ? $_bc_cs['shadow'] : 'none';
    $_bc_cs['shadow_resolved'] = [
        'none'   => 'none',
        'soft'   => '0 8px 24px -12px rgba(43,38,32,.18)',
        'strong' => '0 24px 56px -16px rgba(43,38,32,.35)',
    ][ $_bc_cs_shadow_key ];
    $cv_bc_container_css = \gs_vs_section_style_vars( $_bc_cs, [
        'bg_resolved'    => [ 'var' => '--gs-bc-sec-bg',      'type' => 'raw',   'default' => 'transparent' ],
        'padding_top'    => [ 'var' => '--gs-bc-pad-t',       'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 160 ],
        'padding_bottom' => [ 'var' => '--gs-bc-pad-b',       'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 160 ],
        'padding_left'   => [ 'var' => '--gs-bc-pad-l',       'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 120 ],
        'padding_right'  => [ 'var' => '--gs-bc-pad-r',       'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 120 ],
        'border_width'   => [ 'var' => '--gs-bc-border-w',    'type' => 'px',    'default' => 0, 'min' => 0, 'max' => 12 ],
        'border_color'   => [ 'var' => '--gs-bc-border-color','type' => 'color', 'default' => 'transparent' ],
        'border_radius'  => [ 'var' => '--gs-bc-border-radius','type' => 'px',   'default' => 0, 'min' => 0, 'max' => 40 ],
        'shadow_resolved'=> [ 'var' => '--gs-bc-sec-shadow',  'type' => 'raw',   'default' => 'none' ],
    ] );

    // Heading style: eyebrow color only. This module has no
    // '.gs-beauty-sec-head' wrapper (eyebrow/title/desc sit directly in
    // '.gs-beauty-cta-content' with the panel's own layout spacing), so
    // there is no separate "heading gap" control to add without inventing
    // a structural change beyond what BeautyBookingCtaModule actually
    // renders.
    $_bc_hs = is_array( $cd['beauty_booking_cta_heading_style'] ?? null ) ? $cd['beauty_booking_cta_heading_style'] : [];
    $cv_bc_heading_css = \gs_vs_section_style_vars( $_bc_hs, [
        'eyebrow_color' => [ 'var' => '--gs-bc-eyebrow-color', 'type' => 'color', 'default' => '#C9A867' ],
    ] );
}
// Events & Wedding, section 01 — Signature Portfolio.
$cv_wp_section_title = ! empty( $cd['wedding_portfolio_section_title'] ) ? $cd['wedding_portfolio_section_title'] : '';
$cv_wp_section_desc  = $cd['wedding_portfolio_section_description'] ?? '';
$cv_wp_img           = is_array( $cd['wedding_portfolio_img_display'] ?? null ) ? $cd['wedding_portfolio_img_display'] : [];
$cv_wp_layout        = in_array( $cd['wedding_portfolio_layout'] ?? 'editorial', array_keys( \GoodService\Modules\WeddingPortfolioModule::LAYOUTS ), true ) ? $cd['wedding_portfolio_layout'] : 'editorial';
// Events & Wedding, section 02 — Real Weddings / Real Events.
$cv_ws_section_title = ! empty( $cd['wedding_stories_section_title'] ) ? $cd['wedding_stories_section_title'] : '';
$cv_ws_section_desc  = $cd['wedding_stories_section_description'] ?? '';
$cv_ws_img           = is_array( $cd['wedding_stories_img_display'] ?? null ) ? $cd['wedding_stories_img_display'] : [];

$cv_wsv_section_title = ! empty( $cd['wedding_services_section_title'] ) ? $cd['wedding_services_section_title'] : '';
$cv_wsv_section_desc  = $cd['wedding_services_section_description'] ?? '';
// Events & Wedding, section 04 — Packages & Collections. Distinct
// $cv_wpk_* prefix (not $cv_wp_*, already used by wedding_portfolio) to
// avoid a variable-name collision between these two sections.
$cv_wpk_section_title = ! empty( $cd['wedding_packages_section_title'] ) ? $cd['wedding_packages_section_title'] : '';
$cv_wpk_section_desc  = $cd['wedding_packages_section_description'] ?? '';
$cv_wpk_layout        = in_array( $cd['wedding_packages_layout'] ?? 'grid', array_keys( \GoodService\Modules\WeddingPackagesModule::LAYOUTS ), true ) ? $cd['wedding_packages_layout'] : 'grid';
// Events & Wedding, section 05 — Experience & Style.
$cv_wst_section_title = ! empty( $cd['wedding_style_section_title'] ) ? $cd['wedding_style_section_title'] : '';
$cv_wst_section_desc  = $cd['wedding_style_section_description'] ?? '';
// Events & Wedding, section 06 — Team / Creative Experts. Distinct
// $cv_wtm_* prefix — checked against every prior wedding_* prefix
// above ($cv_wp_*, $cv_ws_*, $cv_wsv_*, $cv_wpk_*, $cv_wst_*) to avoid
// any variable-name collision.
$cv_wtm_section_title = ! empty( $cd['wedding_team_section_title'] ) ? $cd['wedding_team_section_title'] : '';
$cv_wtm_section_desc  = $cd['wedding_team_section_description'] ?? '';
$cv_wtm_layout        = in_array( $cd['wedding_team_layout'] ?? 'grid', array_keys( \GoodService\Modules\WeddingTeamModule::LAYOUTS ), true ) ? $cd['wedding_team_layout'] : 'grid';
// Events & Wedding, section 07 — Venue / Event Specialisation. Distinct
// $cv_wvs_* prefix — checked against every prior wedding_* prefix above
// ($cv_wp_*, $cv_ws_*, $cv_wsv_*, $cv_wpk_*, $cv_wst_*, $cv_wtm_*) to
// avoid any variable-name collision.
$cv_wvs_section_title = ! empty( $cd['wedding_venue_spec_section_title'] ) ? $cd['wedding_venue_spec_section_title'] : '';
$cv_wvs_section_desc  = $cd['wedding_venue_spec_section_description'] ?? '';
// Events & Wedding, section 08 — Location & Destination Coverage.
// Distinct $cv_wloc_* prefix — checked against every prior wedding_*
// prefix above ($cv_wp_*, $cv_ws_*, $cv_wsv_*, $cv_wpk_*, $cv_wst_*,
// $cv_wtm_*, $cv_wvs_*) to avoid any variable-name collision.
$cv_wloc_section_title = ! empty( $cd['wedding_locations_section_title'] ) ? $cd['wedding_locations_section_title'] : '';
$cv_wloc_section_desc  = $cd['wedding_locations_section_description'] ?? '';
// Events & Wedding, section 10 — Check Availability. Distinct $cv_wav_*
// prefix — checked against every prior wedding_* prefix above ($cv_wp_*,
// $cv_ws_*, $cv_wsv_*, $cv_wpk_*, $cv_wst_*, $cv_wtm_*, $cv_wvs_*,
// $cv_wloc_*) to avoid any variable-name collision.
$cv_wav_section_title = ! empty( $cd['wedding_availability_section_title'] ) ? $cd['wedding_availability_section_title'] : '';
$cv_wav_section_desc  = $cd['wedding_availability_section_description'] ?? '';
// Events & Wedding, section 11 — Request a Quote. Distinct $cv_wq_*
// prefix — checked against every prior wedding_* prefix above ($cv_wp_*,
// $cv_ws_*, $cv_wsv_*, $cv_wpk_*, $cv_wst_*, $cv_wtm_*, $cv_wvs_*,
// $cv_wloc_*, $cv_wav_*) to avoid any variable-name collision.
$cv_wq_section_title = ! empty( $cd['wedding_quote_section_title'] ) ? $cd['wedding_quote_section_title'] : '';
$cv_wq_section_desc  = $cd['wedding_quote_section_description'] ?? '';
// Events & Wedding, section 12 (final) — Premium Conversion Banner.
// Distinct $cv_wcb_* prefix — checked against every prior wedding_*
// prefix above ($cv_wp_*, $cv_ws_*, $cv_wsv_*, $cv_wpk_*, $cv_wst_*,
// $cv_wtm_*, $cv_wvs_*, $cv_wloc_*, $cv_wav_*, $cv_wq_*) to avoid any
// variable-name collision.
$cv_wcb_section_title = ! empty( $cd['wedding_closing_banner_section_title'] ) ? $cd['wedding_closing_banner_section_title'] : '';
$cv_wcb_section_desc  = $cd['wedding_closing_banner_section_description'] ?? '';
$wedding_vendor_types = \GoodService\Modules\WeddingEventsModule::get_vendor_types( $cd );
$wedding_style_tags   = \GoodService\Modules\WeddingEventsModule::get_style_tags( $cd );
// Home Services, module 1 — Service Catalogue & Problem Solver.
$cv_hsvc_section_title = ! empty( $cd['home_services_catalogue_section_title'] ) ? $cd['home_services_catalogue_section_title'] : 'Home Services You Can Rely On';
$cv_hsvc_section_desc  = $cd['home_services_catalogue_section_description'] ?? '';
$cv_hsvc_img           = is_array( $cd['home_services_catalogue_img_display'] ?? null ) ? $cd['home_services_catalogue_img_display'] : [];
$cv_hpkg_section_title = ! empty( $cd['home_services_packages_section_title'] ) ? $cd['home_services_packages_section_title'] : 'Packages & Maintenance Plans';
$cv_hpkg_section_desc  = $cd['home_services_packages_section_description'] ?? '';
$cv_hpkg_img           = is_array( $cd['home_services_packages_img_display'] ?? null ) ? $cd['home_services_packages_img_display'] : [];
$cv_htech_section_title = ! empty( $cd['home_services_technicians_section_title'] ) ? $cd['home_services_technicians_section_title'] : 'Meet Our Technicians';
$cv_htech_section_desc  = $cd['home_services_technicians_section_description'] ?? '';
$cv_htech_img           = is_array( $cd['home_services_technicians_img_display'] ?? null ) ? $cd['home_services_technicians_img_display'] : [];
$cv_hgty_section_title  = ! empty( $cd['home_services_guarantee_section_title'] ) ? $cd['home_services_guarantee_section_title'] : 'Licensed, Insured & Guaranteed';
$cv_hgty_section_desc   = $cd['home_services_guarantee_section_description'] ?? '';
$cv_hba_section_title   = ! empty( $cd['home_services_before_after_section_title'] ) ? $cd['home_services_before_after_section_title'] : 'Before & After — See Our Work';
$cv_hba_section_desc    = $cd['home_services_before_after_section_description'] ?? '';
$cv_hba_img             = is_array( $cd['home_services_before_after_img_display'] ?? null ) ? $cd['home_services_before_after_img_display'] : [];
$cv_hw_fs_img_fit = $_fit_v( $cv_hw_fs_img['fit'] ?? 'cover', 'cover' );
$cv_hw_fs_popup_img_fit = $_fit_v( $cd['hw_fs_popup_img_fit'] ?? 'cover', 'cover' );
$cv_hw_fs_img_position = in_array( $cv_hw_fs_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_hw_fs_img['position'] : 'center';
$cv_hw_fs_img_zoom = max( 50, min( 200, (int) ( $cv_hw_fs_img['zoom'] ?? 100 ) ) );
$cv_hw_fs_slider_interval = max( 0, min( 30, (float) ( $cd['hw_fs_slider_interval'] ?? 0 ) ) ) * 1000;
// Health & Wellness module 2 of 5 — Departments & Specialties.
$cv_hw_dept_section_title = ! empty( $cd['departments_section_title'] ) ? $cd['departments_section_title'] : 'Departments & Specialties';
$cv_hw_dept_section_desc = $cd['departments_section_description'] ?? '';
$cv_hw_dept_defs = is_array( $cd['departments_defs'] ?? null ) ? $cd['departments_defs'] : [];
$cv_hw_dept_grid_cols = max( 2, min( 5, (int) ( $cd['departments_grid_cols'] ?? 3 ) ) );
$cv_hw_dept_img = is_array( $cd['departments_img_display'] ?? null ) ? $cd['departments_img_display'] : [];
$cv_hw_dept_img_fit = $_fit_v( $cv_hw_dept_img['fit'] ?? 'cover', 'cover' );
$cv_hw_dept_popup_img_fit = $_fit_v( $cd['hw_dept_popup_img_fit'] ?? 'cover', 'cover' );
$cv_hw_dept_img_position = in_array( $cv_hw_dept_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_hw_dept_img['position'] : 'center';
$cv_hw_dept_img_zoom = max( 50, min( 200, (int) ( $cv_hw_dept_img['zoom'] ?? 100 ) ) );
$cv_hw_dept_slider_interval = max( 0, min( 30, (float) ( $cd['hw_dept_slider_interval'] ?? 0 ) ) ) * 1000;
// Health & Wellness module 3 of 5 — Doctors & Healthcare Professionals.
$cv_hw_dr_section_title = ! empty( $cd['doctors_section_title'] ) ? $cd['doctors_section_title'] : 'Our Doctors';
$cv_hw_dr_section_desc = $cd['doctors_section_description'] ?? '';
$cv_hw_dr_layout = in_array( $cd['doctors_layout'] ?? 'grid', array_keys( \GoodService\Modules\DoctorsModule::LAYOUTS ), true ) ? $cd['doctors_layout'] : 'grid';
$cv_hw_dr_img = is_array( $cd['doctors_img_display'] ?? null ) ? $cd['doctors_img_display'] : [];
$cv_hw_dr_img_fit = $_fit_v( $cv_hw_dr_img['fit'] ?? 'cover', 'cover' );
$cv_hw_dr_popup_img_fit = $_fit_v( $cd['hw_dr_popup_img_fit'] ?? 'cover', 'cover' );
$cv_hw_dr_img_position = in_array( $cv_hw_dr_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_hw_dr_img['position'] : 'center';
$cv_hw_dr_img_zoom = max( 50, min( 200, (int) ( $cv_hw_dr_img['zoom'] ?? 100 ) ) );
$cv_hw_dr_slider_interval = max( 0, min( 30, (float) ( $cd['hw_dr_slider_interval'] ?? 0 ) ) ) * 1000;
// Health & Wellness module 4 of 5 — Facilities & Patient Experience.
$cv_hw_pf_section_title = ! empty( $cd['patient_facilities_section_title'] ) ? $cd['patient_facilities_section_title'] : 'Facilities & Patient Experience';
$cv_hw_pf_section_desc = $cd['patient_facilities_section_description'] ?? '';
$cv_hw_pf_layout = in_array( $cd['patient_facilities_layout'] ?? 'tabs', array_keys( \GoodService\Modules\PatientFacilitiesModule::LAYOUTS ), true ) ? $cd['patient_facilities_layout'] : 'tabs';
$cv_hw_pf_img = is_array( $cd['patient_facilities_img_display'] ?? null ) ? $cd['patient_facilities_img_display'] : [];
$cv_hw_pf_img_fit = $_fit_v( $cv_hw_pf_img['fit'] ?? 'cover', 'cover' );
$cv_hw_pf_img_position = in_array( $cv_hw_pf_img['position'] ?? 'center', [ 'center', 'top', 'bottom' ], true ) ? $cv_hw_pf_img['position'] : 'center';
$cv_hw_pf_img_zoom = max( 50, min( 200, (int) ( $cv_hw_pf_img['zoom'] ?? 100 ) ) );
// Health & Wellness module 5 of 5 — Patient Journey/Treatment Process.
$cv_hw_pj_section_title = ! empty( $cd['patient_journey_section_title'] ) ? $cd['patient_journey_section_title'] : 'Your Patient Journey';
$cv_hw_pj_section_desc = $cd['patient_journey_section_description'] ?? '';
$cv_hw_pj_layout = in_array( $cd['patient_journey_layout'] ?? 'timeline', array_keys( \GoodService\Modules\PatientJourneyModule::LAYOUTS ), true ) ? $cd['patient_journey_layout'] : 'timeline';
$cv_hw_pj_steps = is_array( $cd['patient_journey_steps'] ?? null ) ? $cd['patient_journey_steps'] : [];
// Real feature, item 3: Why Choose Us icon customization.
$cv_why_icon_size    = max( 20, min( 200, (int) ( $cd['why_icon_wrap_size'] ?? 72 ) ) );
$cv_why_icon_width   = max( 0, min( 200, (int) ( $cd['why_icon_wrap_width'] ?? 0 ) ) ); // 0 = same as size (square)
$cv_why_icon_radius  = max( 0, min( 100, (int) ( $cd['why_icon_wrap_radius'] ?? 20 ) ) );
$cv_why_icon_bg      = $cd['why_icon_wrap_bg'] ?? '';
$cv_why_icon_bg_opacity = max( 0, min( 100, (int) ( $cd['why_icon_bg_opacity'] ?? 100 ) ) ) / 100;
$cv_why_icon_border  = $cd['why_icon_wrap_border'] ?? '';
$cv_why_icon_border_w = max( 0, min( 20, (int) ( $cd['why_icon_border_width'] ?? 1 ) ) );
$cv_why_icon_border_style = in_array( $cd['why_icon_border_style'] ?? '', ['solid','dashed','dotted','double','none'], true ) ? $cd['why_icon_border_style'] : 'solid';
$cv_why_icon_shadow  = in_array( $cd['why_icon_shadow'] ?? '', ['none','sm','md','lg'], true ) ? $cd['why_icon_shadow'] : 'md';
$cv_why_icon_padding = max( 0, min( 60, (int) ( $cd['why_icon_padding'] ?? 0 ) ) );
$cv_why_icon_margin  = max( 0, min( 60, (int) ( $cd['why_icon_margin'] ?? 20 ) ) );
$cv_why_icon_align   = in_array( $cd['why_icon_align'] ?? '', ['left','center','right'], true ) ? $cd['why_icon_align'] : 'center';
$cv_why_icon_fit     = $_fit_v( $cd['why_icon_fit'] ?? null, 'contain' );
$cv_why_icon_rotation = max( -180, min( 180, (int) ( $cd['why_icon_rotation'] ?? 0 ) ) );
$cv_why_icon_opacity = max( 0, min( 100, (int) ( $cd['why_icon_opacity'] ?? 100 ) ) ) / 100;
// Real feature: Why Choose Us layout/alignment/spacing controls.
$cv_why_icon_position = in_array( $cd['why_icon_position'] ?? '', ['top','center','left','right','bottom'], true ) ? $cd['why_icon_position'] : 'top';
$cv_why_title_align  = in_array( $cd['why_title_align'] ?? '', ['left','center','right'], true ) ? $cd['why_title_align'] : 'center';
$cv_why_desc_align   = in_array( $cd['why_desc_align'] ?? '', ['left','center','right','justify'], true ) ? $cd['why_desc_align'] : 'center';
$cv_why_gap          = max( 0, min( 60, (int) ( $cd['why_gap'] ?? 16 ) ) );
$cv_why_box_padding  = max( 0, min( 80, (int) ( $cd['why_box_padding'] ?? 28 ) ) );
$cv_why_box_margin   = max( 0, min( 60, (int) ( $cd['why_box_margin'] ?? 0 ) ) );
$cv_why_title_margin = max( 0, min( 40, (int) ( $cd['why_title_margin'] ?? 8 ) ) );
$cv_why_desc_margin  = max( 0, min( 40, (int) ( $cd['why_desc_margin'] ?? 0 ) ) );
$cv_why_row_gap      = max( 0, min( 60, (int) ( $cd['why_row_gap'] ?? 20 ) ) );
$cv_why_col_gap      = max( 0, min( 60, (int) ( $cd['why_col_gap'] ?? 20 ) ) );
// Real fix: individual title/description padding, distinct from box padding.
$cv_why_title_padding = max( 0, min( 40, (int) ( $cd['why_title_padding'] ?? 0 ) ) );
$cv_why_desc_padding  = max( 0, min( 40, (int) ( $cd['why_desc_padding'] ?? 0 ) ) );
// Real feature: Stats section customization — same complete pattern as
// Why Choose Us, applied consistently per the "same level of
// customization for these sections" request.
$cv_stat_icon_position = in_array( $cd['stat_icon_position'] ?? '', ['top','center','left','right','bottom','none'], true ) ? $cd['stat_icon_position'] : 'top';
$cv_stat_val_align   = in_array( $cd['stat_val_align'] ?? '', ['left','center','right'], true ) ? $cd['stat_val_align'] : 'center';
$cv_stat_lbl_align   = in_array( $cd['stat_lbl_align'] ?? '', ['left','center','right'], true ) ? $cd['stat_lbl_align'] : 'center';
$cv_stat_gap         = max( 0, min( 60, (int) ( $cd['stat_gap'] ?? 8 ) ) );
$cv_stat_box_padding = max( 0, min( 80, (int) ( $cd['stat_box_padding'] ?? 32 ) ) );
$cv_stat_box_margin  = max( 0, min( 60, (int) ( $cd['stat_box_margin'] ?? 0 ) ) );
$cv_stat_val_margin  = max( 0, min( 40, (int) ( $cd['stat_val_margin'] ?? 0 ) ) );
$cv_stat_lbl_margin  = max( 0, min( 40, (int) ( $cd['stat_lbl_margin'] ?? 8 ) ) );
$cv_stat_val_padding = max( 0, min( 40, (int) ( $cd['stat_val_padding'] ?? 0 ) ) );
$cv_stat_lbl_padding = max( 0, min( 40, (int) ( $cd['stat_lbl_padding'] ?? 0 ) ) );
$cv_stat_row_gap     = max( 0, min( 60, (int) ( $cd['stat_row_gap'] ?? 20 ) ) );
$cv_stat_col_gap     = max( 0, min( 60, (int) ( $cd['stat_col_gap'] ?? 20 ) ) );
$cv_stat_box_radius  = max( 0, min( 60, (int) ( $cd['stat_box_radius'] ?? 20 ) ) );
$cv_stat_box_bg      = $cd['stat_box_bg'] ?? '';
$cv_stat_val_size    = max( 12, min( 80, (int) ( $cd['stat_val_size'] ?? 45 ) ) );
$cv_stat_val_weight  = in_array( (string) ( $cd['stat_val_weight'] ?? '' ), ['400','600','700','800','900'], true ) ? $cd['stat_val_weight'] : '900';
$cv_stat_lbl_weight  = in_array( (string) ( $cd['stat_lbl_weight'] ?? '' ), ['400','600','700','800'], true ) ? $cd['stat_lbl_weight'] : '600';
// Real feature: How It Works (Process Steps) layout customization —
// extends the existing icon size/radius controls from an earlier round.
$cv_proc_icon_position = in_array( $cd['proc_icon_position'] ?? '', ['top','center','left','right','bottom'], true ) ? $cd['proc_icon_position'] : 'top';
$cv_proc_title_align = in_array( $cd['proc_title_align'] ?? '', ['left','center','right'], true ) ? $cd['proc_title_align'] : 'center';
$cv_proc_desc_align  = in_array( $cd['proc_desc_align'] ?? '', ['left','center','right','justify'], true ) ? $cd['proc_desc_align'] : 'center';
$cv_proc_gap         = max( 0, min( 60, (int) ( $cd['proc_gap'] ?? 12 ) ) );
$cv_proc_box_padding = max( 0, min( 80, (int) ( $cd['proc_box_padding'] ?? 24 ) ) );
$cv_proc_box_margin  = max( 0, min( 60, (int) ( $cd['proc_box_margin'] ?? 0 ) ) );
$cv_proc_title_margin = max( 0, min( 40, (int) ( $cd['proc_title_margin'] ?? 8 ) ) );
$cv_proc_desc_margin  = max( 0, min( 40, (int) ( $cd['proc_desc_margin'] ?? 0 ) ) );
$cv_proc_title_padding = max( 0, min( 40, (int) ( $cd['proc_title_padding'] ?? 0 ) ) );
$cv_proc_desc_padding  = max( 0, min( 40, (int) ( $cd['proc_desc_padding'] ?? 0 ) ) );
$cv_proc_row_gap     = max( 0, min( 60, (int) ( $cd['proc_row_gap'] ?? 20 ) ) );
$cv_proc_col_gap     = max( 0, min( 60, (int) ( $cd['proc_col_gap'] ?? 20 ) ) );
// Real feature: Client/Brand Logos customization.
$cv_client_logo_height = max( 20, min( 150, (int) ( $cd['client_logo_height'] ?? 44 ) ) );
$cv_client_logo_width  = max( 0, min( 300, (int) ( $cd['client_logo_width'] ?? 120 ) ) );
$cv_client_grayscale   = ( $cd['client_grayscale'] ?? 1 ) ? true : false;
$cv_client_hover_fx    = ( $cd['client_hover_fx'] ?? 1 ) ? true : false;
$cv_client_opacity     = max( 0, min( 100, (int) ( $cd['client_opacity'] ?? 55 ) ) ) / 100;
$cv_client_gap         = max( 0, min( 100, (int) ( $cd['client_gap'] ?? 32 ) ) );
$cv_client_row_gap     = max( 0, min( 100, (int) ( $cd['client_row_gap'] ?? 28 ) ) );
$cv_client_align       = in_array( $cd['client_align'] ?? '', ['left','center','right'], true ) ? $cd['client_align'] : 'center';
$cv_client_box_padding = max( 0, min( 40, (int) ( $cd['client_box_padding'] ?? 0 ) ) );
$cv_client_box_margin  = max( 0, min( 40, (int) ( $cd['client_box_margin'] ?? 0 ) ) );
// Real feature, item 3: Process Steps icon customization — same complete
// property set as Why Choose Us, per "every other section" in the request.
$cv_proc_icon_size   = max( 30, min( 250, (int) ( $cd['proc_icon_size'] ?? 108 ) ) );
$cv_proc_icon_width  = max( 0, min( 250, (int) ( $cd['proc_icon_width'] ?? 0 ) ) ); // 0 = same as size
$cv_proc_icon_radius = max( 0, min( 999, (int) ( $cd['proc_icon_radius'] ?? 999 ) ) ); // 999 = fully round
$cv_proc_icon_bg_opacity = max( 0, min( 100, (int) ( $cd['proc_icon_bg_opacity'] ?? 100 ) ) ) / 100;
$cv_proc_icon_border_w = max( 0, min( 20, (int) ( $cd['proc_icon_border_width'] ?? 2 ) ) );
$cv_proc_icon_shadow = in_array( $cd['proc_icon_shadow'] ?? '', ['none','sm','md','lg'], true ) ? $cd['proc_icon_shadow'] : 'none';
$cv_proc_icon_padding = max( 0, min( 60, (int) ( $cd['proc_icon_padding'] ?? 0 ) ) );
$cv_proc_icon_margin = max( 0, min( 60, (int) ( $cd['proc_icon_margin'] ?? 20 ) ) );
$cv_proc_icon_align  = in_array( $cd['proc_icon_align'] ?? '', ['left','center','right'], true ) ? $cd['proc_icon_align'] : 'center';
$cv_proc_icon_fit    = $_fit_v( $cd['proc_icon_fit'] ?? null, 'contain' );
$cv_proc_icon_rotation = max( -180, min( 180, (int) ( $cd['proc_icon_rotation'] ?? 0 ) ) );
$cv_proc_icon_opacity = max( 0, min( 100, (int) ( $cd['proc_icon_opacity'] ?? 100 ) ) ) / 100;
// Real feature, item 3: Services icon-image customization — this section
// was missed entirely last round despite being one of the sections the
// image/icon upload system was built for.
$cv_svc_icon_img_size   = max( 20, min( 250, (int) ( $cd['svc_icon_img_size'] ?? 56 ) ) );
$cv_svc_icon_img_width  = max( 0, min( 250, (int) ( $cd['svc_icon_img_width'] ?? 0 ) ) );
$cv_svc_icon_img_radius = max( 0, min( 999, (int) ( $cd['svc_icon_img_radius'] ?? 14 ) ) );
$cv_svc_icon_img_bg_opacity = max( 0, min( 100, (int) ( $cd['svc_icon_img_bg_opacity'] ?? 100 ) ) ) / 100;
$cv_svc_icon_img_border_w = max( 0, min( 20, (int) ( $cd['svc_icon_img_border_width'] ?? 0 ) ) );
$cv_svc_icon_img_shadow = in_array( $cd['svc_icon_img_shadow'] ?? '', ['none','sm','md','lg'], true ) ? $cd['svc_icon_img_shadow'] : 'none';
$cv_svc_icon_img_padding = max( 0, min( 60, (int) ( $cd['svc_icon_img_padding'] ?? 0 ) ) );
$cv_svc_icon_img_fit    = $_fit_v( $cd['svc_icon_img_fit'] ?? null, 'contain' );
$cv_svc_icon_img_rotation = max( -180, min( 180, (int) ( $cd['svc_icon_img_rotation'] ?? 0 ) ) );
$cv_svc_icon_img_opacity = max( 0, min( 100, (int) ( $cd['svc_icon_img_opacity'] ?? 100 ) ) ) / 100;
// Shadow map
$shadow_map = ['none'=>'none','sm'=>'0 2px 8px rgba(0,0,0,.06)','md'=>'0 4px 16px rgba(0,0,0,.1)','lg'=>'0 8px 32px rgba(0,0,0,.15)'];
$cv_logo_shadow_val = $shadow_map[$cv_logo_sh] ?? 'none';
$cv_card_shadow_val = $shadow_map[$cv_card_sh] ?? $shadow_map['sm'];

// ── Extended Items section customization (page builder styling controls)
$cv_items_sec_pt        = max(0, (int)($cd['items_sec_pt']           ?? $cv_sec_pt));
$cv_items_sec_pb        = max(0, (int)($cd['items_sec_pb']           ?? $cv_sec_pb));
$cv_items_sec_bg        = $cd['items_sec_bg']            ?? '';
$cv_items_card_bg       = $cd['items_card_bg']           ?? '#ffffff';
$cv_items_card_bc       = $cd['items_card_border_color'] ?? $cv_card_bc;
$cv_items_card_bw       = max(0, min(8, (int)($cd['items_card_border_width'] ?? 1)));
$cv_items_card_r        = max(0, min(40, (int)($cd['items_card_radius']      ?? $cv_card_r)));
$cv_items_card_sh_key   = $cd['items_card_shadow']       ?? $cv_card_sh;
$cv_items_card_pad      = max(0, min(60, (int)($cd['items_card_padding']     ?? $cv_card_pad)));
$cv_items_card_margin   = max(0, min(40, (int)($cd['items_card_margin']      ?? 0)));
$cv_items_price_color   = $cd['items_price_color']       ?? '';
$cv_items_price_size    = max(10, min(32, (int)($cd['items_price_size']      ?? 18)));
$cv_items_btn_bg        = $cd['items_btn_bg']            ?? $cv_btn_bg;
$cv_items_btn_text      = $cd['items_btn_text_color']    ?? $cv_btn_text;
$cv_items_btn_r         = max(0, min(50, (int)($cd['items_btn_radius']       ?? $cv_btn_r)));
$cv_items_btn_bc        = $cd['items_btn_border_color']  ?? 'transparent';
$cv_items_btn_bw        = max(0, min(4, (int)($cd['items_btn_border_width']  ?? 0)));
// Real fix — font-size/weight/letter-spacing/font-family were hardcoded
// on this button (the same class of gap as the Enquire Now button);
// extends the existing bg/text/radius/border inline-style mechanism
// without touching the working color logic.
$cv_items_btn_size      = max( 10, min( 22, (int) ( $cd['items_btn_font_size'] ?? 13 ) ) );
$cv_items_btn_weight    = in_array( (string) ( $cd['items_btn_font_weight'] ?? '700' ), ['400','500','600','700','800','900'], true ) ? (string) ( $cd['items_btn_font_weight'] ?? '700' ) : '700';
$cv_items_btn_ls        = max( -0.05, min( 0.3, (float) ( $cd['items_btn_letter_spacing'] ?? 0 ) ) );
$cv_items_btn_font      = trim( (string) ( $cd['items_btn_font_family'] ?? '' ) );
$cv_items_btn_font_stack = $cv_items_btn_font !== '' ? \GoodService\Service\TypographyService::resolve_font_stack( $cv_items_btn_font ) : '';
$cv_items_img_box_bg    = $cd['items_img_box_bg']        ?? '#F8FAFC';
$cv_items_img_box_r     = max(0, min(40, (int)($cd['items_img_box_radius']   ?? $cv_card_imgr)));
$cv_items_img_box_h     = (int)($cd['items_img_box_height'] ?? $cv_items_img_h);
$cv_items_card_shadow_val = $shadow_map[$cv_items_card_sh_key] ?? $cv_card_shadow_val;

// ── Extended Services Category section customization
$cv_svc_sec_pt          = max(0, (int)($cd['svc_sec_pt']             ?? $cv_sec_pt));
$cv_svc_sec_pb          = max(0, (int)($cd['svc_sec_pb']             ?? $cv_sec_pb));
$cv_svc_sec_bg          = $cd['svc_sec_bg']              ?? '';
$cv_svc_card_bg         = $cd['svc_card_bg']             ?? '#ffffff';
$cv_svc_card_bc         = $cd['svc_card_border_color']   ?? $cv_card_bc;
$cv_svc_card_bw         = max(0, min(8, (int)($cd['svc_card_border_width']   ?? 1)));
$cv_svc_card_r          = max(0, min(40, (int)($cd['svc_card_radius']        ?? $cv_card_r)));
$cv_svc_card_sh_key     = $cd['svc_card_shadow']         ?? $cv_card_sh;
$cv_svc_card_pad        = max(0, min(60, (int)($cd['svc_card_padding']       ?? 20)));
$cv_svc_card_margin     = max(0, min(40, (int)($cd['svc_card_margin']        ?? 0)));
$cv_svc_desc_color      = $cd['svc_desc_color']          ?? '';
$cv_svc_desc_size       = max(10, min(22, (int)($cd['svc_desc_size']         ?? 13)));
$cv_svc_icon_bg         = $cd['svc_icon_bg']             ?? '';
$cv_svc_icon_color      = $cd['svc_icon_color']          ?? '';
$cv_svc_btn_color       = $cd['svc_btn_color']            ?? '';
// Real fix — the Services "Enquire Now" button (.vs-svc-enquire-btn) had
// zero dedicated customization; it was hardcoded to the site's global
// --vs-primary color with white text, unlike every other primary action
// button on this page (Products' "Get Quote" button has its own bg/text/
// border/radius controls — items_btn_* below). Mirrors that exact
// pattern so Services gets the same level of control.
$cv_svc_enq_btn_bg      = $_hex_v( $cd['svc_enquire_btn_bg'] ?? null, '' );
$cv_svc_enq_btn_text    = $_hex_v( $cd['svc_enquire_btn_text_color'] ?? null, '' );
$cv_svc_enq_btn_bc      = $_hex_v( $cd['svc_enquire_btn_border_color'] ?? null, '' );
$cv_svc_enq_btn_bw      = max( 0, min( 8, (int) ( $cd['svc_enquire_btn_border_width'] ?? 0 ) ) );
$cv_svc_enq_btn_r       = max( 0, min( 50, (int) ( $cd['svc_enquire_btn_radius'] ?? 8 ) ) );
// Real fix — font-size/weight/font-family/letter-spacing were hardcoded
// on this button; extends the same lightweight CSS-var pattern the
// existing bg/text/border/radius controls already use. Deliberately NOT
// using the full Typography Engine here — that generates its own color
// declaration, which would conflict with the working bg/text-color
// system above rather than extend it.
$cv_svc_enq_btn_size    = max( 10, min( 22, (int) ( $cd['svc_enquire_btn_font_size'] ?? 13 ) ) );
$cv_svc_enq_btn_weight  = in_array( (string) ( $cd['svc_enquire_btn_font_weight'] ?? '700' ), ['400','500','600','700','800','900'], true ) ? (string) ( $cd['svc_enquire_btn_font_weight'] ?? '700' ) : '700';
$cv_svc_enq_btn_font    = trim( (string) ( $cd['svc_enquire_btn_font_family'] ?? '' ) );
$cv_svc_enq_btn_ls      = max( -0.05, min( 0.3, (float) ( $cd['svc_enquire_btn_letter_spacing'] ?? 0.02 ) ) );
$cv_svc_icon_size       = max(16, min(72, (int)($cd['svc_icon_size']         ?? 32)));
$cv_svc_icon_r          = max(0, min(50, (int)($cd['svc_icon_radius']        ?? 12)));
$cv_svc_img_h           = (int)($cd['svc_img_height']       ?? 80);
$cv_svc_img_w           = $_wpx($cd['svc_img_width']         ?? null, 0 ); // 0 = 100%
$cv_svc_img_fit         = $_fit_v($cd['svc_img_fit']         ?? null, 'contain');
$cv_svc_img_r           = max(0, min(40, (int)($cd['svc_img_radius']         ?? 10)));
// Services (svc_) — image position, border, box-shadow (border-radius
// reuses the existing svc_img_radius field above; not duplicated here).
$cv_svc_img_position     = $_pos_v( $cd['svc_img_position']      ?? null, 'center' );
$cv_svc_img_border_w     = max( 0, min( 20, (int) ( $cd['svc_img_border_width'] ?? 0 ) ) );
$cv_svc_img_border_style = $_bstyle_v( $cd['svc_img_border_style'] ?? null, 'solid' );
$cv_svc_img_border_color = $_hex_v( $cd['svc_img_border_color']  ?? null, '#E2E8F0' );
$cv_svc_img_shadow_val   = $_img_shadow_css( $cd, 'svc_img' );
$cv_svc_card_shadow_val = $shadow_map[$cv_svc_card_sh_key] ?? $cv_card_shadow_val;

// ── Gallery uniform sizing
$cv_gallery_radius      = max(0, min(50, (int)($cd['gallery_radius']   ?? 25)));
$cv_gallery_cols        = max(2, min(6,  (int)($cd['gallery_cols']     ?? 4)));
$cv_gallery_gap         = max(4, min(40, (int)($cd['gallery_gap']      ?? 16)));
$cv_gallery_aspect      = $cd['gallery_aspect'] ?? '4/3'; // e.g. "4/3", "1/1", "16/9"
$cv_gallery_cols_mobile = max(1, min(4, (int)($cd['gallery_cols_mobile'] ?? 2)));
$cv_gallery_max_rows    = max(0, min(20, (int)($cd['gallery_max_rows'] ?? 0))); // 0 = unlimited
$cv_gallery_layout      = in_array($cd['gallery_layout'] ?? '', ['grid','masonry'], true) ? $cd['gallery_layout'] : 'grid';
$cv_gallery_hover       = in_array($cd['gallery_hover'] ?? '', ['zoom','none','darken','brighten','grayscale-color'], true) ? $cd['gallery_hover'] : 'zoom';
$cv_gallery_lightbox    = ($cd['gallery_lightbox'] ?? 1) ? true : false;
$cv_gallery_captions    = ($cd['gallery_captions'] ?? 0) ? true : false;
// Banner overlay hex to rgba
$cv_banner_overlay_hex = $cd['banner_overlay'] ?? $brand_color2;
// Mobile
$mv_hero_h     = max( 200, min( 700, (int)( $md['hero_height']   ?? 320 ) ) );
$mv_font_scale = in_array($md['font_scale']??'1.0',['0.85','0.9','1.0']) ? ($md['font_scale']??'1.0') : '1.0';
$mv_items_cols = (int)($md['items_cols']??2); // default 2 cols on mobile
$mv_gallery_cols=(int)($md['gallery_cols']??2);
$mv_float_cta  = ($md['float_cta']??1) ? true : false;
$mv_float_cta_txt = $md['float_cta_text'] ?? 'Get Quote';
// Real fix — events-wedding vendor-type-adaptive mobile sticky CTA label.
// Purely additive: only overrides the generic default above when this
// listing's real category is events-wedding AND it has at least one
// recognized vendor_type (via WeddingEventsModule::get_vendor_types(),
// already computed above as $wedding_vendor_types); every other
// category, and an events-wedding listing with no recognized type,
// keeps the existing $mv_float_cta_txt value untouched.
if ( ( $_listing_category_row->slug ?? '' ) === 'events-wedding' ) {
    $mv_float_cta_txt = \GoodService\Modules\WeddingEventsModule::mobile_cta_label( $wedding_vendor_types, $mv_float_cta_txt );
}
// ── Mobile CTA per-button individual colors ──
$cv_mcta_quote_bg   = $cd['mcta_quote_bg']   ?? $brand_color;
$cv_mcta_quote_text = $cd['mcta_quote_text']  ?? '#ffffff';
$cv_mcta_call_bg    = $cd['mcta_call_bg']     ?? '#EFF6FF';
$cv_mcta_call_text  = $cd['mcta_call_text']   ?? $brand_color;
$cv_mcta_wa_bg      = $cd['mcta_wa_bg']       ?? '#E8FDF2';
$cv_mcta_wa_text    = $cd['mcta_wa_text']     ?? '#25D366';
$mv_show_wa    = ($md['show_wa']??1) ? true : false;
$mv_show_phone = ($md['show_phone']??1) ? true : false;
$mv_show_trust = ($md['show_trust_bar']??1) ? true : false;
$mv_show_stats = ($md['show_stats']??1) ? true : false;
$mv_show_gallery=($md['show_gallery']??1) ? true : false;
$mv_show_proc  = ($md['show_process']??1) ? true : false;
$mv_show_why   = ($md['show_why']??1) ? true : false;
$mv_show_faq   = ($md['show_faq']??1) ? true : false;
$mv_show_rev   = ($md['show_reviews']??1) ? true : false;
$mv_show_map   = ($md['show_map']??1) ? true : false;
// Quote button style
$qbtn_inline = '';
if ($cv_qbtn_style === 'filled') {
    $qbtn_inline = "background:{$cv_btn_bg};color:{$cv_btn_text};border:2px solid {$cv_btn_bg};border-radius:{$cv_btn_r}px";
} elseif ($cv_qbtn_style === 'outline') {
    $qbtn_inline = "background:transparent;color:{$cv_btn_bg};border:2px solid {$cv_btn_bg};border-radius:{$cv_btn_r}px";
} else {
    $qbtn_inline = "background:rgba(0,0,0,.05);color:{$cv_btn_bg};border:none;border-radius:{$cv_btn_r}px";
}
// Items-section specific button style — uses per-section vars when vendor has set them
$items_qbtn_inline = "background:{$cv_items_btn_bg};color:{$cv_items_btn_text};border-radius:{$cv_items_btn_r}px"
    . ($cd['items_btn_border_width'] ?? 0 ? ";border:" . (int)($cd['items_btn_border_width']) . "px solid " . ($cd['items_btn_border_color'] ?? 'transparent') : "")
    . ";font-size:{$cv_items_btn_size}px;font-weight:{$cv_items_btn_weight};letter-spacing:{$cv_items_btn_ls}em"
    . ($cv_items_btn_font_stack !== '' ? ";font-family:" . $cv_items_btn_font_stack : "");

/* ── Template CSS (admin-configured, applies to all vendor site pages) ── */
$_template_css = \GoodService\Core\Config::get( 'global_element_css', '' );
?>
<!-- GoodService Vendor Site -->
<?php if ( isset($primary) && ($primary->status ?? '') === 'draft' ): ?>
<div style="background:#F59E0B;color:#fff;text-align:center;padding:10px 20px;font-size:.88rem;font-weight:700;position:sticky;top:0;z-index:9999;letter-spacing:.03em">
  ⚠️ DRAFT PREVIEW — This listing is not yet published. Only you can see this page.
  &nbsp;·&nbsp;
  <a href="<?php echo home_url('/vendor/dashboard/?section=listings'); ?>" style="color:#fff;text-decoration:underline">Back to Dashboard</a>
</div>
<?php endif; ?>

<!-- Scroll Progress Bar -->
<div class="vs-scroll-progress" id="vs-scroll-prog" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" aria-label="Page reading progress"></div>

<!-- Social proof toast removed -->
<?php
// Real feature — Centralized Typography Engine: Google Fonts loading.
// Scans every typography-enabled prefix for a selected Google Font and
// requests only those from Google's CDN — never the whole ~1800-font
// library. As more sections adopt cl_typography_fields()/TypographyService,
// add their prefix to this one list and font loading covers them
// automatically; nothing else needs to change.
$_gs_typography_prefixes = [
    'svc_title', 'items_title', 'process_title',
    'svc_desc', 'items_desc', 'process_desc', 'about_text',
    'hero_heading', 'hero_desc', 'trust_bar', 'nav_brand', 'nav_links',
    'faq_q', 'faq_a', 'review_name', 'review_text', 'team_name', 'team_role', 'portfolio_title', 'highlights_heading', 'amenities_heading', 'facilities_heading', 'awards_heading', 'languages_heading', 'packages_heading', 'memberships_heading', 'certifications_heading', 'warranty_title',
    'svc_enquire_btn', 'items_btn', 'hero_cta', 'inq_label', 'inq_input', 'inq_submit', 'item_badge', 'pricing_badge',
    'about_heading', 'contact_heading', 'faq_heading', 'gallery_heading',
    // Real feature — Questions & Answers section heading typography (see
    // the new cl_typography_fields('questions_heading', ...) admin
    // control and its matching TypographyService::css_rule() call).
    // Without this entry a vendor choosing a custom Google Font for this
    // heading would have the CSS font-family applied but the actual font
    // file never loaded — the exact class of bug this array exists to
    // prevent for every other typography field.
    'questions_heading',
    'process_heading', 'services_heading', 'why_heading', 'items_heading',
    'stats_heading', 'team_heading', 'clients_heading', 'portfolio_heading', 'testimonials_heading',
    // Styling/typography audit — newly-covered prefixes (see matching
    // comment in create-listing.php's TYPOGRAPHY_PREFIXES array).
    'languages_name', 'languages_level', 'memberships_name', 'memberships_price', 'memberships_desc',
    'warranty_desc', 'terms_heading', 'terms_body',
    // Phase 2 — v14 batch (highlights/amenities/facilities/awards/certifications/packages):
    // card title+description typography, decoupled per section so identical-looking
    // cards (Awards vs Certifications) can be styled independently.
    'highlights_title', 'highlights_desc', 'amenities_title', 'amenities_desc',
    'facilities_title', 'facilities_desc', 'awards_title', 'awards_desc',
    'certifications_title', 'certifications_desc',
    'packages_badge', 'packages_name', 'packages_short_desc', 'packages_price', 'packages_features',
    // Bug fix — the Testimonials editor previously had a "Reviewer
    // Name"/"Review Quote" panel wired to review_name/review_text, but
    // those prefixes' css_rule() calls target the REVIEWS section's
    // .vs-review-name/.vs-review-text classes, not this section's
    // .vs-testi-name/.vs-testi-text/.vs-testi-company — so it silently
    // controlled the wrong section. Testimonials now has its own prefixes;
    // Reviews (which had zero typography controls anywhere) reuses its
    // original review_name/review_text prefixes, now exposed via its own panel.
    'testimonials_name', 'testimonials_company', 'testimonials_text',
    // Bug fix — Pricing had no section-heading typography prefix at all,
    // unlike every sibling section (its <h2> was 100% hardcoded), and no
    // typography for plan name/price/description/features.
    'pricing_heading', 'pricing_name', 'pricing_price', 'pricing_desc', 'pricing_features',
    // Team bio and Portfolio category/description previously had no
    // typography controls at all.
    'team_bio', 'portfolio_cat', 'portfolio_desc',
    // Phase 4 — small targeted gaps in already-strong sections.
    'hero_eyebrow', 'hero_tagline', 'about_stat_val', 'about_stat_lbl', 'about_highlights',
    'gallery_caption', 'why_title', 'why_desc',
    // Bug fix — these 15 industry-vertical module headings (including
    // room_types_heading, which had an admin panel + save-gate entry but
    // was missing only from this Google Fonts array) were rendered via
    // css_rule() but never registered here, so a custom Google Font chosen
    // for any of them would never actually load.
    'room_types_heading', 'hotel_event_spaces_heading', 'hotel_events_showcase_heading', 'hotel_dining_heading', 'hotel_amenities_heading', 'hotel_virtual_tour_heading', 'hotel_closing_banner_heading',
    // Same bug, same fix, for the 9 per-component Hospitality fields
    // (Module 2's card title/desc/badge/meta, Module 3's item name/
    // price/desc, Module 4's group title/item) — each already had a
    // working cl_typography_fields() admin control AND a css_rule() call
    // in this same file (added in the Module 6 wrap-up audit), but a
    // custom Google Font picked for any of them would still never load
    // without an entry here, exactly like the room_types_heading bug
    // this comment block already describes.
    'hotel_events_showcase_title', 'hotel_events_showcase_desc', 'hotel_events_showcase_badge', 'hotel_events_showcase_meta',
    'hotel_dining_name', 'hotel_dining_price', 'hotel_dining_desc',
    'hotel_amenities_group_title', 'hotel_amenities_item',
    'hotel_closing_banner_desc', 'hotel_closing_banner_cta',
    // Bug fix — 7-category compliance audit: 36 Events & Wedding
    // per-component typography fields (each already has a working
    // cl_typography_fields() admin control AND a css_rule() call in this
    // same file) were never registered here, so a custom Google Font
    // picked for any of them would never actually load — exactly the
    // same bug class already found and fixed for Hospitality above.
    'wedding_portfolio_caption', 'wedding_portfolio_cat',
    'wedding_stories_title', 'wedding_stories_desc', 'wedding_stories_badge', 'wedding_stories_meta',
    'wedding_services_title', 'wedding_services_desc', 'wedding_services_tag', 'wedding_services_duration',
    'wedding_packages_title', 'wedding_packages_desc', 'wedding_packages_tag', 'wedding_packages_price_main', 'wedding_packages_price_orig', 'wedding_packages_price_prefix', 'wedding_packages_includes', 'wedding_packages_cta',
    'wedding_style_label', 'wedding_style_desc',
    'wedding_team_name', 'wedding_team_role', 'wedding_team_bio',
    'wedding_venue_spec_label', 'wedding_venue_spec_note',
    'wedding_locations_name', 'wedding_locations_note', 'wedding_locations_home_badge', 'wedding_locations_badge_title', 'wedding_locations_badge_note',
    'wedding_availability_step_title', 'wedding_availability_desc', 'wedding_availability_cta',
    'wedding_quote_label', 'wedding_quote_cta',
    'wedding_closing_banner_desc', 'wedding_closing_banner_cta',
    'property_listings_heading', 'featured_properties_heading', 'property_types_heading',
    'property_gallery_heading', 'featured_projects_heading', 'project_categories_heading',
    'three_d_before_after_heading', 'design_styles_heading', 'design_process_heading',
    'featured_services_heading', 'departments_heading', 'doctors_heading',
    'patient_facilities_heading', 'patient_journey_heading',
    'beauty_services_heading', 'beauty_gallery_heading', 'beauty_experts_heading', 'beauty_facilities_heading', 'beauty_packages_heading', 'beauty_booking_cta_heading', 'wedding_portfolio_heading', 'wedding_stories_heading', 'wedding_services_heading', 'wedding_packages_heading', 'wedding_style_heading', 'wedding_team_heading', 'wedding_venue_spec_heading', 'wedding_locations_heading', 'wedding_availability_heading', 'wedding_quote_heading', 'wedding_closing_banner_heading', 'home_services_catalogue_heading', 'home_services_packages_heading', 'home_services_technicians_heading', 'home_services_guarantee_heading', 'home_services_before_after_heading',
    // Real feature — Footer typography overhaul: About Text, Service
    // Links, and Quick Links each get their own independent typography
    // prefix (font, size, weight, line-height, spacing, alignment) so a
    // vendor can compact any one of them without affecting the others.
    'footer_about', 'footer_service_links', 'footer_quick_links',
];
$_gs_google_fonts_used = \GoodService\Service\TypographyService::collect_used_google_fonts( $cd, $_gs_typography_prefixes );
if ( ! empty( $_gs_google_fonts_used ) ):
    $_gs_fonts_url = \GoodService\Service\TypographyService::build_google_fonts_url( $_gs_google_fonts_used );
    if ( $_gs_fonts_url ):
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="<?php echo esc_url( $_gs_fonts_url ); ?>">
<?php endif; endif; ?>
<?php
// Real feature — conditional CSS loading by section visibility. Captures
// the entire main CSS block via output buffering rather than physically
// reorganizing 126KB of interspersed CSS text (which would risk
// introducing syntax errors or accidentally dropping rules during a large
// manual edit), then filters it through gs_vs_filter_css_by_visibility()
// once the closing </style> is reached below.
ob_start();
?>
<style>
/* ────────────────────────────────────────────────────
   GoodService Vendor Site v7  •  Kaagzaat Style
──────────────────────────────────────────────────── */
/* Real feature — closes a confirmed SEO crawlability gap: Products/
   Services "View More" popup content previously existed only inside a
   data-sections JSON attribute, inserted into the visible DOM solely by
   a click-triggered JS handler — content a crawler that doesn't
   simulate clicks would never see as real, readable text. The standard
   sr-only pattern (not display:none) keeps this content in the
   accessibility tree for screen readers and genuinely present in the
   server-rendered HTML for crawlers, while remaining completely
   invisible to sighted users — the existing popup click-to-view UX is
   entirely unchanged. */
.vs-sr-only{
  position:absolute!important;
  width:1px!important;height:1px!important;
  padding:0!important;margin:-1px!important;
  overflow:hidden!important;
  clip:rect(0,0,0,0)!important;
  white-space:nowrap!important;
  border:0!important;
}
.gs-vs{
  --vs-primary:<?php echo esc_attr($brand_color);?>;
  --vs-dark:<?php echo esc_attr($brand_color2);?>;
  --vs-yellow:#F5A623;
  --vs-font:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
  /* Customizer CSS variables */
  --vs-heading:<?php echo esc_attr($cv_heading);?>;
  --vs-text:<?php echo esc_attr($cv_text);?>;
  --vs-muted:<?php echo esc_attr($cv_muted);?>;
  --vs-accent:<?php echo esc_attr($cv_accent);?>;
  --vs-section-bg:<?php echo esc_attr($cv_section_bg);?>;
  --vs-card-shadow:<?php echo esc_attr($cv_card_shadow_val);?>;
  --vs-card-radius:<?php echo $cv_card_r;?>px;
  --vs-card-pad:<?php echo $cv_card_pad;?>px;
  --vs-card-border:<?php echo esc_attr($cv_card_bc);?>;
  --vs-card-img-radius:<?php echo $cv_card_imgr;?>px;
  --vs-btn-bg:<?php echo esc_attr($cv_btn_bg);?>;
  --vs-btn-text:<?php echo esc_attr($cv_btn_text);?>;
  --vs-btn-radius:<?php echo $cv_btn_r;?>px;
  --vs-sec-pt:<?php echo $cv_sec_pt;?>px;
  --vs-sec-pb:<?php echo $cv_sec_pb;?>px;
  font-family:var(--vs-font);color:var(--vs-heading);
  /* Per-section color overrides from vendor customizer */
  <?php if($cv_hero_bg):           ?>--vs-hero-bg:<?php echo esc_attr($cv_hero_bg); ?>;<?php endif; ?>
  <?php if($cv_hero_right_bg):     ?>--vs-hero-right-bg:<?php echo esc_attr($cv_hero_right_bg); ?>;<?php endif; ?>
  <?php $_hero_desc_resolved_color = \GoodService\Service\TypographyService::resolve( $cd, 'hero_desc', [ 'color' => '#E2E8F0' ] )['color']; ?>
  --vs-hero-text:<?php echo esc_attr( $_hero_desc_resolved_color ); ?>;
  <?php if($cv_about_bg):          ?>--vs-about-bg:<?php echo esc_attr($cv_about_bg); ?>;<?php endif; ?>
  <?php if($cv_about_eyebrow):     ?>--vs-about-eyebrow:<?php echo esc_attr($cv_about_eyebrow); ?>;<?php endif; ?>
  <?php if($cv_services_bg):       ?>--vs-services-bg:<?php echo esc_attr($cv_services_bg); ?>;<?php endif; ?>
  <?php if($cv_services_icon):     ?>--vs-services-icon:<?php echo esc_attr($cv_services_icon); ?>;<?php endif; ?>
  <?php if($cv_process_bg):        ?>--vs-process-bg:<?php echo esc_attr($cv_process_bg); ?>;<?php endif; ?>
  <?php if($cv_process_num):       ?>--vs-process-num:<?php echo esc_attr($cv_process_num); ?>;<?php endif; ?>
  <?php if($cv_process_num_bg):    ?>--vs-process-num-bg:<?php echo esc_attr($cv_process_num_bg); ?>;<?php endif; ?>
  <?php if($cv_process_num_border): ?>--vs-process-num-border:<?php echo esc_attr($cv_process_num_border); ?>;<?php endif; ?>
  <?php if($cv_process_sec_desc):  ?>--vs-process-sec-desc:<?php echo esc_attr($cv_process_sec_desc); ?>;<?php endif; ?>
  <?php if($cv_process_item_desc_color): ?>--vs-process-item-desc:<?php echo esc_attr($cv_process_item_desc_color); ?>;<?php endif; ?>
  <?php if($cv_process_card_bg):   ?>--vs-process-card-bg:<?php echo esc_attr($cv_process_card_bg); ?>;<?php endif; ?>
  <?php if($cv_process_card_border_color): ?>--vs-process-card-border:<?php echo esc_attr($cv_process_card_border_color); ?>;<?php endif; ?>
  <?php if($cv_items_bg):          ?>--vs-items-bg:<?php echo esc_attr($cv_items_bg); ?>;<?php endif; ?>
  <?php if($cv_items_price):       ?>--vs-items-price:<?php echo esc_attr($cv_items_price); ?>;<?php endif; ?>
  <?php if($cv_stats_bg):          ?>--vs-stats-bg:<?php echo esc_attr($cv_stats_bg); ?>;<?php endif; ?>
  <?php if($cv_footer_bg):         ?>--vs-footer-bg:<?php echo esc_attr($cv_footer_bg); ?>;<?php endif; ?>
  <?php if($cv_stats_num):         ?>--vs-stats-num:<?php echo esc_attr($cv_stats_num); ?>;<?php endif; ?>
  <?php if($cv_stats_label):       ?>--vs-stats-label:<?php echo esc_attr($cv_stats_label); ?>;<?php endif; ?>
  <?php if($cv_why_bg):            ?>--vs-why-bg:<?php echo esc_attr($cv_why_bg); ?>;<?php endif; ?>
  <?php if($cv_why_icon):          ?>--vs-why-icon:<?php echo esc_attr($cv_why_icon); ?>;<?php endif; ?>
  <?php if($cv_gallery_bg):        ?>--vs-gallery-bg:<?php echo esc_attr($cv_gallery_bg); ?>;<?php endif; ?>
  <?php if($cv_gallery_filter):    ?>--vs-gallery-filter:<?php echo esc_attr($cv_gallery_filter); ?>;<?php endif; ?>
  <?php if($cv_faq_bg):            ?>--vs-faq-bg:<?php echo esc_attr($cv_faq_bg); ?>;<?php endif; ?>
  <?php if($cv_questions_bg):      ?>--vs-questions-bg:<?php echo esc_attr($cv_questions_bg); ?>;<?php endif; ?>
  <?php if($cv_contact_bg):        ?>--vs-contact-bg:<?php echo esc_attr($cv_contact_bg); ?>;<?php endif; ?>
  <?php if($cv_contact_icon):      ?>--vs-contact-icon:<?php echo esc_attr($cv_contact_icon); ?>;<?php endif; ?>
  /* ── Extended Items section CSS vars ── */
  --vs-items-sec-pt:<?php echo $cv_items_sec_pt;?>px;
  --vs-items-sec-pb:<?php echo $cv_items_sec_pb;?>px;
  <?php if($cv_items_sec_bg):      ?>--vs-items-sec-bg:<?php echo esc_attr($cv_items_sec_bg); ?>;<?php endif; ?>
  --vs-items-card-bg:<?php echo esc_attr($cv_items_card_bg);?>;
  --vs-items-card-bc:<?php echo esc_attr($cv_items_card_bc);?>;
  --vs-items-card-bw:<?php echo $cv_items_card_bw;?>px;
  --vs-items-card-r:<?php echo $cv_items_card_r;?>px;
  --vs-items-card-sh:<?php echo esc_attr($cv_items_card_shadow_val);?>;
  --vs-items-card-pad:<?php echo $cv_items_card_pad;?>px;
  --vs-items-card-margin:<?php echo $cv_items_card_margin;?>px;
  <?php if($cv_items_price_color): ?>--vs-items-price-color:<?php echo esc_attr($cv_items_price_color); ?>;<?php endif; ?>
  --vs-items-price-size:<?php echo $cv_items_price_size;?>px;
  --vs-items-btn-bg:<?php echo esc_attr($cv_items_btn_bg);?>;
  --vs-items-btn-text:<?php echo esc_attr($cv_items_btn_text);?>;
  --vs-items-btn-r:<?php echo $cv_items_btn_r;?>px;
  --vs-items-btn-bc:<?php echo esc_attr($cv_items_btn_bc);?>;
  --vs-items-btn-bw:<?php echo $cv_items_btn_bw;?>px;
  --vs-items-img-box-bg:<?php echo esc_attr($cv_items_img_box_bg);?>;
  --vs-items-img-box-r:<?php echo $cv_items_img_box_r;?>px;
  --vs-items-img-box-h:<?php echo $cv_items_img_box_h;?>px;
  --vs-items-img-position:<?php echo esc_attr($cv_items_img_position);?>;
  --vs-items-img-border-w:<?php echo $cv_items_img_border_w;?>px;
  --vs-items-img-border-style:<?php echo esc_attr($cv_items_img_border_style);?>;
  --vs-items-img-border-color:<?php echo esc_attr($cv_items_img_border_color);?>;
  --vs-items-img-shadow:<?php echo esc_attr($cv_items_img_shadow_val);?>;
  /* ── Extended Services Category CSS vars ── */
  --vs-svc-sec-pt:<?php echo $cv_svc_sec_pt;?>px;
  --vs-svc-sec-pb:<?php echo $cv_svc_sec_pb;?>px;
  <?php if($cv_svc_sec_bg):        ?>--vs-svc-sec-bg:<?php echo esc_attr($cv_svc_sec_bg); ?>;<?php endif; ?>
  --vs-svc-card-bg:<?php echo esc_attr($cv_svc_card_bg);?>;
  --vs-svc-card-bc:<?php echo esc_attr($cv_svc_card_bc);?>;
  --vs-svc-card-bw:<?php echo $cv_svc_card_bw;?>px;
  --vs-svc-card-r:<?php echo $cv_svc_card_r;?>px;
  --vs-svc-card-sh:<?php echo esc_attr($cv_svc_card_shadow_val);?>;
  --vs-svc-card-pad:<?php echo $cv_svc_card_pad;?>px;
  --vs-svc-card-margin:<?php echo $cv_svc_card_margin;?>px;
  <?php if($cv_svc_desc_color):    ?>--vs-svc-desc-color:<?php echo esc_attr($cv_svc_desc_color); ?>;<?php endif; ?>
  --vs-svc-desc-size:<?php echo $cv_svc_desc_size;?>px;
  <?php if($cv_svc_icon_bg):       ?>--vs-svc-icon-bg:<?php echo esc_attr($cv_svc_icon_bg); ?>;<?php endif; ?>
  <?php if($cv_svc_icon_color):    ?>--vs-svc-icon-color:<?php echo esc_attr($cv_svc_icon_color); ?>;<?php endif; ?>
  <?php if($cv_svc_btn_color):     ?>--vs-svc-btn-color:<?php echo esc_attr($cv_svc_btn_color); ?>;<?php endif; ?>
  <?php if($cv_svc_enq_btn_bg):    ?>--vs-svc-enq-btn-bg:<?php echo esc_attr($cv_svc_enq_btn_bg); ?>;<?php endif; ?>
  <?php if($cv_svc_enq_btn_text):  ?>--vs-svc-enq-btn-text:<?php echo esc_attr($cv_svc_enq_btn_text); ?>;<?php endif; ?>
  --vs-svc-enq-btn-border:<?php echo $cv_svc_enq_btn_bw; ?>px solid <?php echo esc_attr($cv_svc_enq_btn_bc ?: 'transparent'); ?>;
  --vs-svc-enq-btn-size:<?php echo $cv_svc_enq_btn_size; ?>px;
  --vs-svc-enq-btn-weight:<?php echo esc_attr($cv_svc_enq_btn_weight); ?>;
  --vs-svc-enq-btn-ls:<?php echo $cv_svc_enq_btn_ls; ?>em;
  <?php if($cv_svc_enq_btn_font): ?>--vs-svc-enq-btn-font:<?php echo esc_attr( \GoodService\Service\TypographyService::resolve_font_stack($cv_svc_enq_btn_font) ); ?>;<?php endif; ?>
  --vs-svc-enq-btn-r:<?php echo $cv_svc_enq_btn_r; ?>px;
  --vs-inq-heading-text-color:<?php echo esc_attr($cv_inq_heading_text_color); ?>;
  --vs-svc-icon-size:<?php echo $cv_svc_icon_size;?>px;
  --vs-svc-icon-r:<?php echo $cv_svc_icon_r;?>px;
  --vs-svc-img-h:<?php echo $cv_svc_img_h;?>px;
  --vs-svc-img-w:<?php echo $cv_svc_img_w > 0 ? $cv_svc_img_w.'px' : '100%'; ?>;
  --vs-svc-img-fit:<?php echo esc_attr($cv_svc_img_fit); ?>;
  --vs-items-img-fit:<?php echo esc_attr($cv_items_img_fit); ?>;
  --vs-svc-img-r:<?php echo $cv_svc_img_r;?>px;
  --vs-svc-img-position:<?php echo esc_attr($cv_svc_img_position);?>;
  --vs-svc-img-border-w:<?php echo $cv_svc_img_border_w;?>px;
  --vs-svc-img-border-style:<?php echo esc_attr($cv_svc_img_border_style);?>;
  --vs-svc-img-border-color:<?php echo esc_attr($cv_svc_img_border_color);?>;
  --vs-svc-img-shadow:<?php echo esc_attr($cv_svc_img_shadow_val);?>;
  --vs-svc-grid-cols:<?php echo $cv_svc_grid_cols; ?>;
  --vs-items-grid-cols:<?php echo $cv_items_grid_cols; ?>;
  --vs-svc-gap:<?php echo $cv_svc_gap; ?>px;
  --vs-items-gap:<?php echo $cv_items_gap; ?>px;
  --vs-pkg-gap:<?php echo $cv_pkg_gap; ?>px;
  --vs-am-gap:<?php echo $cv_am_gap; ?>px;
  --vs-awd-gap:<?php echo $cv_awd_gap; ?>px;
  --vs-fac-gap:<?php echo $cv_fac_gap; ?>px;
  --vs-feat-prop-gap:<?php echo $cv_feat_prop_gap; ?>px;
  --vs-hl-gap:<?php echo $cv_hl_gap; ?>px;
  --vs-hw-dept-gap:<?php echo $cv_hw_dept_gap; ?>px;
  --vs-hw-dept-cols:<?php echo $cv_hw_dept_cols; ?>;
  --vs-ida-3d-gap:<?php echo $cv_ida_3d_gap; ?>px;
  --vs-ida-ba-gap:<?php echo $cv_ida_ba_gap; ?>px;
  --vs-ida-cat-gap:<?php echo $cv_ida_cat_gap; ?>px;
  --vs-ida-cat-cols:<?php echo $cv_ida_cat_cols; ?>;
  --vs-lang-gap:<?php echo $cv_lang_gap; ?>px;
  --vs-mem-gap:<?php echo $cv_mem_gap; ?>px;
  --vs-portfolio-gap:<?php echo $cv_portfolio_gap; ?>px;
  --vs-pricing-gap:<?php echo $cv_pricing_gap; ?>px;
  --vs-prop-gap:<?php echo $cv_prop_gap; ?>px;
  --vs-prop-type-gap:<?php echo $cv_prop_type_gap; ?>px;
  --vs-reviews-gap:<?php echo $cv_reviews_gap; ?>px;
  --vs-room-gap:<?php echo $cv_room_gap; ?>px;
  --vs-team-gap:<?php echo $cv_team_gap; ?>px;
  --vs-testi-gap:<?php echo $cv_testi_gap; ?>px;
  --vs-svc-gap-mobile:<?php echo $cv_svc_gap_mobile; ?>px;
  --vs-items-gap-mobile:<?php echo $cv_items_gap_mobile; ?>px;
  --vs-pkg-gap-mobile:<?php echo $cv_pkg_gap_mobile; ?>px;
  --vs-room-gap-mobile:<?php echo $cv_room_gap_mobile; ?>px;
  --vs-prop-gap-mobile:<?php echo $cv_prop_gap_mobile; ?>px;
  --vs-prop-type-gap-mobile:<?php echo $cv_prop_type_gap_mobile; ?>px;
  --vs-ida-cat-gap-mobile:<?php echo $cv_ida_cat_gap_mobile; ?>px;
  --vs-hw-dept-gap-mobile:<?php echo $cv_hw_dept_gap_mobile; ?>px;
  --vs-room-types-grid-cols:<?php echo $cv_room_types_grid_cols; ?>;
  --vs-property-listings-grid-cols:<?php echo $cv_prop_grid_cols; ?>;
  --vs-featured-properties-grid-cols:<?php echo $cv_feat_grid_cols; ?>;
  --vs-property-types-grid-cols:<?php echo $cv_types_grid_cols; ?>;
  --vs-why-icon-size:<?php echo $cv_why_icon_size; ?>px;
  --vs-why-icon-radius:<?php echo $cv_why_icon_radius; ?>px;
  --vs-proc-icon-size:<?php echo $cv_proc_icon_size; ?>px;
  --vs-proc-icon-radius:<?php echo $cv_proc_icon_radius; ?>px;
  /* ── Gallery CSS vars ── */
  --vs-gallery-radius:<?php echo $cv_gallery_radius;?>px;
  --vs-gallery-gap:<?php echo $cv_gallery_gap;?>px;
  --vs-gallery-cols:<?php echo $cv_gallery_cols;?>;
  --vs-gallery-img-position:<?php echo esc_attr($cv_gallery_img_position);?>;
  --vs-gallery-img-border-w:<?php echo $cv_gallery_img_border_w;?>px;
  --vs-gallery-img-border-style:<?php echo esc_attr($cv_gallery_img_border_style);?>;
  --vs-gallery-img-border-color:<?php echo esc_attr($cv_gallery_img_border_color);?>;
  --vs-gallery-img-shadow:<?php echo esc_attr($cv_gallery_img_shadow_val);?>;
}
.gs-vs *{box-sizing:border-box;margin:0;padding:0}
.gs-vs a{text-decoration:none;color:inherit}
.gs-vs img{max-width:100%;height:auto}
.vs-wrap{max-width:var(--vs-wrap-w,1280px);margin:0 auto;padding:0 24px}
/* Nav uses a tighter inline padding so the brand + links + CTAs have maximum room.
   Content sections keep the full 24px gutter via .vs-wrap alone. */
.vs-nav .vs-wrap{padding:0 16px}
/* Per-section width overrides via CSS custom properties on the section element */
/* Usage: style="--vs-wrap-w:1500px" on any section */
.vs-about-section .vs-wrap{max-width:var(--vs-about-w,1480px)}
.vs-section.vs-about-section{--vs-wrap-w:1480px}

/* ── NAV ─────────────────────────────────────────── */
/*
 * LOGO OVERFLOW FIX:
 * The nav bar is exactly 66px tall. Previously the logo could be taller than
 * that (the user-controlled cv_logo_h has no upper bound), causing it to burst
 * out of the header both vertically and — if cv_logo_w was wide — horizontally.
 *
 * Fixes applied:
 *  • .vs-nav gets overflow:hidden — clips anything that escapes the strip.
 *  • .vs-nav-inner gets overflow:hidden for the same reason.
 *  • .vs-nav-brand gets overflow:hidden + max-width:220px so it can never push
 *    the nav-links and CTA buttons off-screen.
 *  • .vs-nav-brand img gets hard max-height (52px = 66px - 7px top/bottom
 *    breathing room) and max-width:100% so it always stays within the brand
 *    column width, no matter what values cv_logo_h / cv_logo_w are set to.
 *    The user-defined height / width values still act as a *preferred* size
 *    (they're set via the height / width properties); the max-* values are the
 *    safety caps that prevent overflow.
 */
.vs-nav{
  position:fixed;top:0;left:0;right:0;width:100%;z-index:9998;
  background:#fff;
  border-bottom:2px solid #F1F5F9;
  box-shadow:0 2px 12px rgba(0,0,0,.06);
}
/* Visible breadcrumb bar — matches the BreadcrumbList schema in Router.php
   exactly, since Google checks that visible structure matches markup. */
.vs-breadcrumb{
  background:#FAFBFC;
  border-bottom:1px solid #F1F5F9;
}
.vs-breadcrumb-list{
  display:flex;align-items:center;flex-wrap:wrap;
  list-style:none;margin:0;padding:10px 0;
  font-size:.82rem;
}
.vs-breadcrumb-item{
  display:flex;align-items:center;gap:6px;
  min-width:0; /* allows text-overflow ellipsis on the last (current-page) item */
}
.vs-breadcrumb-item a{
  color:#64748B;text-decoration:none;
  white-space:nowrap;
  transition:color .15s;
}
.vs-breadcrumb-item a:hover{color:#1A1A1A;text-decoration:underline}
.vs-breadcrumb-item span[aria-current="page"]{
  color:#1A1A1A;font-weight:500;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
  max-width:280px; /* prevents a very long business name from overflowing the bar on narrow viewports */
}
.vs-breadcrumb-sep{
  color:#CBD5E1;font-size:.78rem;
}
@media (max-width:480px){
  .vs-breadcrumb-item span[aria-current="page"]{max-width:140px}
}
html{scroll-behavior:smooth}
/* Compensate for fixed nav height so content starts below it */
.gs-vs{padding-top:66px;min-height:100vh}
.vs-nav-inner{
  display:flex;align-items:center;gap:16px;
  height:66px;
  overflow:hidden;          /* clips content without breaking parent sticky */
}
.vs-nav-brand{
  display:flex;align-items:center;gap:10px;
  flex-shrink:0;
  /* min-width changed from fixed 160px to auto so brand never overflows on
     narrow viewports; nav-links have flex:1 so they absorb any spare space. */
  min-width:0;
  max-width:220px;          /* hard cap — brand never squeezes out nav links */
  overflow:hidden;          /* clip any text/image that exceeds the column */
}
.vs-nav-brand img{
  /* Preferred / user-controlled dimensions */
  height:<?php echo $cv_logo_h>0?$cv_logo_h.'px':'auto';?>;
  width:<?php echo $cv_logo_w>0?$cv_logo_w.'px':'auto';?>;
  /* Safety caps — NEVER exceed these regardless of user settings */
  max-height:52px;          /* 66px header − 7px breathing room top & bottom */
  max-width:100%;           /* never wider than the .vs-nav-brand column */
  /* Rendering */
  border-radius:10px;
  object-fit:<?php echo $cv_logo_fit;?>;
  display:block;
  flex-shrink:0;
}
.vs-nav-brand-init{width:44px;height:44px;border-radius:10px;background:var(--vs-primary);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1.15rem}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'nav_brand', '.vs-nav-brand-name', [ 'font_size' => 15, 'font_weight' => '800', 'color' => '#1E293B', 'line_height' => '1.2' ] ); ?>
.vs-nav-brand-name--standalone{font-size:1.05rem;font-weight:900;color:var(--vs-dark);letter-spacing:-.02em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px}
.vs-nav-links{display:flex;align-items:center;gap:2px;flex:1;overflow-x:auto;scrollbar-width:none}
.vs-nav-links::-webkit-scrollbar{display:none}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'nav_links', '.vs-nav-links a', [ 'font_size' => 13, 'font_weight' => '600', 'color' => '#64748B' ] ); ?>
.vs-nav-links a{white-space:nowrap;padding:6px 13px;border-radius:20px;transition:all .2s}
.vs-nav-links a:hover,.vs-nav-links a.act{background:var(--vs-primary);color:#fff}
.vs-nav-ctas{display:flex;gap:8px;flex-shrink:0;align-items:center}
.vs-btn{display:inline-flex;align-items:center;gap:6px;padding:9px 20px;border-radius:8px;font-size:.87rem;font-weight:700;cursor:pointer;border:none;transition:all .2s;white-space:nowrap}
.vs-btn-primary{background:var(--vs-primary);color:#fff}
.vs-btn-primary:hover{filter:brightness(1.1);transform:translateY(-1px)}
.vs-btn-dark{background:var(--vs-dark);color:#fff}
.vs-btn-wa{background:#25D366;color:#fff}
.vs-btn-ghost{background:#F1F5F9;color:var(--vs-dark)}
.vs-btn-ghost:hover{background:#E2E8F0}
.vs-btn-outline-w{background:transparent;border:2px solid rgba(255,255,255,.55);color:#fff}
.vs-btn-outline-w:hover{background:rgba(255,255,255,.15)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'hero_cta', '.vs-btn-yellow', [ 'font_size' => 14, 'font_weight' => '700', 'color' => '#ffffff' ] ); ?>
.vs-btn-yellow{background:var(--vs-yellow)}
.vs-btn-yellow:hover{filter:brightness(1.08)}
.vs-btn-sm{padding:7px 14px;font-size:.8rem}
/* Real fix: Download App button — reuses .vs-btn/.vs-btn-primary, only adds
   the small tweaks specific to sitting in the nav bar (slightly tighter
   padding so it doesn't dominate next to the hamburger). */
.vs-nav-install-btn{padding:8px 14px;font-size:.8rem}
/* Real fix: genuine hamburger icon — did not exist anywhere on this page
   before. Three lines that animate into an X when the menu is open, giving
   clear visual feedback of state rather than a static icon. */
.vs-nav-hamburger{
  display:none;flex-direction:column;justify-content:center;gap:5px;
  width:38px;height:38px;padding:0;border:1.5px solid #E2E8F0;border-radius:8px;
  background:#fff;cursor:pointer;flex-shrink:0;
}
.vs-nav-hamburger span{
  display:block;width:18px;height:2px;background:var(--vs-dark);margin:0 auto;
  transition:transform .25s ease,opacity .2s ease;
}
.vs-nav-hamburger-open span:nth-child(1){transform:translateY(7px) rotate(45deg)}
.vs-nav-hamburger-open span:nth-child(2){opacity:0}
.vs-nav-hamburger-open span:nth-child(3){transform:translateY(-7px) rotate(-45deg)}
@media(max-width:768px){
  /* Real fix: previously .vs-nav-links{display:none} made the nav links
     vanish completely on mobile with zero alternative way to reach them —
     confirmed by searching this entire file for any hamburger/mobile-menu
     mechanism and finding none. Now a proper dropdown panel instead. */
  .vs-nav-links{
    display:flex;flex-direction:column;align-items:stretch;gap:0;
    position:absolute;top:100%;left:0;right:0;background:#fff;
    border-top:1px solid #E2E8F0;box-shadow:0 8px 24px rgba(0,0,0,.08);
    max-height:0;overflow:hidden;opacity:0;
    transition:max-height .25s ease,opacity .2s ease;
    padding:0 16px;
  }
  .vs-nav-links.vs-nav-links-open{max-height:70vh;overflow-y:auto;opacity:1;padding:8px 16px}
  .vs-nav-links a{padding:12px 4px;border-radius:0;border-bottom:1px solid #F1F5F9;text-align:left}
  .vs-nav-links a:hover,.vs-nav-links a.act{background:none;color:var(--vs-primary)}
  .vs-nav-ctas .vs-btn-ghost{display:none}
  .vs-nav-hamburger{display:flex}
  .vs-nav-install-label{display:none}
  .vs-nav-install-btn{padding:8px 10px}
  /* Real fix: .vs-nav-links is position:absolute on mobile (see above),
     which removes it from the flex layout entirely regardless of its
     display value — meaning nothing was reliably pushing the CTA group to
     the right edge. It only looked correctly positioned when the brand
     name happened to be long; a short business name would leave a visible
     gap instead of the buttons sitting flush right. */
  .vs-nav-ctas{margin-left:auto}
  /* Real fix: .vs-nav-links is taken out of the flex flow entirely by
     position:absolute above (needed for the dropdown), leaving only the
     brand and the CTAs as actual flex participants here. Without this,
     the CTAs' right-alignment only worked by coincidence when the brand
     name happened to be long enough to fill the remaining space. */
  .vs-nav-ctas{margin-left:auto}
  /* On mobile the brand area gets full available width minus the CTA buttons
     (download icon + hamburger), recalculated now that both exist. */
  .vs-nav-brand{max-width:calc(100% - 100px)}
  .vs-nav-brand img{max-height:40px}
  /* Real fix: .vs-nav-inner's base rule has overflow:hidden (needed for the
     desktop horizontal-scroll nav strip) — without this override, the
     absolutely-positioned dropdown above would be clipped and invisible no
     matter how correct its own CSS is. Safe to override here since that
     original overflow concern doesn't apply once .vs-nav-links switches to
     position:absolute on mobile. */
  .vs-nav-inner{position:relative;overflow:visible}
}
@media(max-width:480px){
  /* Do NOT add padding:0 Npx here — .vs-nav-inner already sits inside .vs-wrap
     which contributes padding:0 24px. Adding more here doubles the inset and
     squeezes out nav links / brand text on small phones. */
  .vs-nav-inner{gap:6px}
  .vs-nav-brand img{max-height:36px}
  .vs-nav-brand{max-width:calc(100% - 88px)}
}

/* ── HERO ────────────────────────────────────────── */
.vs-hero{background:#F8FAFF;padding:0;contain:layout}
.vs-hero-inner{display:grid;grid-template-columns:1fr 1fr;gap:0;min-height:<?php echo $cv_banner_h;?>px}
.vs-hero-left{background:var(--vs-hero-bg,var(--vs-dark));padding:56px 48px 56px 48px;display:flex;flex-direction:column;justify-content:center;position:relative}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'hero_eyebrow', '.vs-hero-eyebrow', [ 'font_size' => 12, 'font_weight' => '700', 'color' => 'rgba(255,255,255,.9)' ] ); ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'hero_tagline', '.vs-hero-tagline', [ 'font_size' => 16, 'font_weight' => '700', 'color' => 'rgba(255,255,255,.85)', 'text_transform' => 'uppercase', 'letter_spacing' => '0.05' ] ); ?>
.vs-hero-tagline{margin-bottom:10px}
.vs-hero-eyebrow{display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:20px;padding:4px 14px;margin-bottom:18px;width:fit-content}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'hero_heading', '.vs-hero-h1', [ 'font_size' => 38, 'font_size_tablet' => 30, 'font_size_mobile' => 25, 'font_weight' => '900', 'color' => '#ffffff', 'line_height' => '1.18' ] ); ?>
.vs-hero-h1{margin-bottom:16px}
.vs-hero-h1 span{color:var(--vs-yellow)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'hero_desc', '.vs-hero-desc', [ 'font_size' => 15, 'font_weight' => '400', 'color' => '#E2E8F0', 'line_height' => '1.75' ] ); ?>
.vs-hero-desc{margin-bottom:24px;max-width:480px}
.vs-hero-highlights{display:flex;flex-direction:column;gap:8px;margin-bottom:28px}
.vs-hero-hl-item{display:flex;align-items:center;gap:9px;font-size:.87rem;color:rgba(255,255,255,.88)}
.vs-hero-hl-dot{width:20px;height:20px;border-radius:50%;background:var(--vs-yellow);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:.65rem;color:#fff;font-weight:800}
.vs-hero-btns{display:flex;flex-wrap:wrap;gap:10px}
.vs-hero-right{position:relative;background:var(--vs-hero-right-bg,#fff);display:flex;align-items:stretch;overflow:hidden}
.vs-hero-right-img{width:<?php echo $cv_hero_img_w>0?$cv_hero_img_w.'px':'100%';?>;height:<?php echo $cv_hero_img_h>0?$cv_hero_img_h.'px':'auto';?>;object-fit:<?php echo $cv_hero_img_fit;?>}
.vs-hero-right-placeholder{width:100%;background:var(--vs-hero-right-bg,linear-gradient(135deg,#EFF6FF,#DBEAFE));display:flex;align-items:center;justify-content:center;font-size:4rem;height:<?php echo $cv_hero_img_h;?>px}
.vs-hero-rating-badge{position:absolute;bottom:24px;left:20px;background:#fff;border-radius:14px;padding:12px 16px;box-shadow:0 8px 24px rgba(0,0,0,.14);display:flex;align-items:center;gap:10px;z-index:3}
.vs-hero-rating-num{font-size:1.4rem;font-weight:900;color:var(--vs-dark)}
.vs-hero-rating-stars{color:#F59E0B;font-size:.9rem;line-height:1}
.vs-hero-rating-lbl{font-size:.7rem;color:#647388;margin-top:2px}
@media(max-width:900px){
  .vs-hero-inner{grid-template-columns:1fr}
  .vs-hero-left{padding:40px 20px;border-radius:0}
  .vs-hero-right{min-height:260px}
  .vs-hero-right-img{min-height:260px}
  .vs-hero-rating-badge{left:16px}
}

/* ── TRUST BAR ───────────────────────────────────── */
<?php $_tb_cfg_css = $_elget('trust_bar'); if ( $_tb_cfg_css['vis'] && $trust_bar ): ?>
.vs-trust-bar{background:var(--vs-dark);color:#fff;padding:12px 0;overflow:hidden}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'trust_bar', '.vs-trust-marquee', [ 'font_size' => 14, 'font_weight' => '400', 'color' => '#ffffff' ] ); ?>
.vs-trust-marquee{display:flex;gap:48px;animation:vs-marquee 28s linear infinite;white-space:nowrap;will-change:transform;animation-delay:.1s}
.vs-tb-pause-hover:hover .vs-trust-marquee{animation-play-state:paused}
.vs-trust-marquee span{display:inline-flex;align-items:center;gap:8px;font-size:.83rem;font-weight:600}
.vs-trust-marquee span::before{content:'✔';color:var(--vs-yellow);font-size:.8rem}
@keyframes vs-marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}
<?php endif; ?>

/* ── SECTION SHELL ───────────────────────────────── */
.vs-section{padding:var(--vs-sec-pt,64px) 0 var(--vs-sec-pb,64px)}
.vs-section-alt{background:var(--vs-section-bg,#F8FAFC)}
.vs-sec-eyebrow{font-size:.73rem;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--vs-primary);margin-bottom:8px}
.vs-sec-title{font-size:clamp(1.3rem,2.5vw,1.75rem);font-weight:900;color:var(--vs-dark);margin-bottom:8px}
.vs-sec-sub{font-size:.93rem;color:#64748B;margin-bottom:36px;max-width:600px}
.vs-divider{width:44px;height:4px;background:var(--vs-primary);border-radius:99px;margin-bottom:32px}

/* ── ABOUT 2-COL ──────────────────────────────────── */
<?php if ( $_sec_show('about') ): ?>
.vs-about-grid{display:grid;grid-template-columns:<?php
$_lc = $cv_about_left_w > 0 ? $cv_about_left_w . 'px' : '1fr';
$_rc = $cv_about_img_w  > 0 ? $cv_about_img_w  . 'px' : ($cv_about_left_w > 0 ? '1fr' : '1.1fr');
echo $_lc . ' ' . $_rc;
?>;gap:48px;align-items:start}
.vs-about-stats{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:24px}
.vs-about-stat{background:#EFF6FF;border-radius:12px;padding:14px 20px;text-align:center;min-width:100px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'about_stat_val', '.vs-about-stat-val', [ 'font_size' => 24, 'font_weight' => '900', 'color' => '#2563EB' ] ); ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'about_stat_lbl', '.vs-about-stat-lbl', [ 'font_size' => 12, 'font_weight' => '400', 'color' => '#64748B' ] ); ?>
.vs-about-stat-lbl{margin-top:2px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'about_highlights', '.vs-about-hl', [ 'font_size' => 14, 'font_weight' => '400', 'color' => '#1E293B' ] ); ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'about_text', '.vs-about-desc', [ 'font_size' => 15, 'font_weight' => '400', 'color' => '#475569', 'line_height' => '1.85' ] ); ?>
.vs-about-desc{margin-bottom:20px}
.vs-about-hl{display:flex;align-items:center;gap:10px;font-size:.88rem;color:#1E293B;padding:6px 0}
.vs-about-hl-icon{color:var(--vs-primary);font-size:1rem}
.vs-about-right{position:relative}
.vs-about-img{width:100%;border-radius:18px;object-fit:<?php echo $cv_about_img_fit;?>;height:<?php echo $cv_about_img_h>0?$cv_about_img_h.'px':'auto';?>;display:block}
.vs-about-img-placeholder{width:100%;background:#EFF6FF;border-radius:18px;aspect-ratio:4/3;display:flex;align-items:center;justify-content:center;font-size:3rem}
.vs-about-badges{display:flex;flex-wrap:wrap;gap:10px;margin-top:16px}
.vs-about-badge img{height:48px;width:auto;border-radius:8px;object-fit:contain}
@media(max-width:820px){.vs-about-grid{grid-template-columns:1fr}}
<?php endif; ?>

/* ── SERVICES CATEGORY GRID ──────────────────────── */
<?php if ( $_sec_show('services') ): ?>
.vs-svc-grid{display:grid;grid-template-columns:repeat(var(--vs-svc-grid-cols,4),1fr);gap:var(--vs-svc-gap,16px)}
.vs-svc-cat-heading{font-size:1.15rem;font-weight:800;color:#0F172A;margin:28px 0 14px;padding-bottom:8px;border-bottom:2px solid #F1F5F9}
.vs-svc-cat-heading:first-of-type{margin-top:0}
@media(max-width:900px){.vs-svc-grid{grid-template-columns:repeat(min(var(--vs-svc-grid-cols,4),2),1fr)}}
@media(max-width:480px){.vs-svc-grid{grid-template-columns:repeat(2,1fr);gap:var(--vs-svc-gap-mobile,10px)}}
/* Services section custom padding */
#vs-sec-services.vs-section{
  padding-top:var(--vs-svc-sec-pt,var(--vs-sec-pt,64px))!important;
  padding-bottom:var(--vs-svc-sec-pb,var(--vs-sec-pb,64px))!important;
}
#vs-sec-services{background:var(--vs-svc-sec-bg,var(--vs-section-bg,#F8FAFC))!important}
.vs-svc-card{
  background:var(--vs-svc-card-bg,#fff);
  border:var(--vs-svc-card-bw,1.5px) solid var(--vs-svc-card-bc,#E2E8F0);
  border-radius:var(--vs-svc-card-r,16px);
  overflow:hidden;text-align:center;
  transition:all .22s;cursor:pointer;
  /* flex column so footer always sticks to bottom */
  display:flex;flex-direction:column;
  box-shadow:var(--vs-svc-card-sh,none);
  margin:var(--vs-svc-card-margin,0);
}
.vs-svc-card:hover{border-color:var(--vs-primary);box-shadow:0 8px 24px rgba(0,0,0,.08);transform:translateY(-3px)}
/* Card body grows to fill space — description pushes footer to bottom */
.vs-svc-card-body{
  padding:var(--vs-svc-card-pad,18px) var(--vs-svc-card-pad,18px) 0;
  flex:1;display:flex;flex-direction:column;
}
/* Fixed footer — price + enquire button always at the bottom */
.vs-svc-card-footer{
  padding:12px var(--vs-svc-card-pad,18px) var(--vs-svc-card-pad,18px);
  margin-top:auto;
  border-top:1px solid #F1F5F9;
  display:flex;flex-direction:column;gap:8px;
}
/* Icon-only mode (no image): original layout */
.vs-svc-icon{
  width:var(--vs-svc-icon-size,56px);height:var(--vs-svc-icon-size,56px);
  border-radius:var(--vs-svc-icon-r,14px);
  background:var(--vs-svc-icon-bg,var(--vs-services-icon,#EFF6FF));
  color:var(--vs-svc-icon-color,var(--vs-primary,#2563EB));
  margin:0 auto 14px;display:flex;align-items:center;justify-content:center;
  font-size:calc(var(--vs-svc-icon-size,56px) * 0.55);overflow:hidden;
}
.vs-svc-icon img{width:100%;height:100%;object-fit:contain;padding:6px}
<?php endif; ?>
/* Shared clip utility: overflow:hidden + border-radius must live on an INNER
   element, not the same element that also carries a box-shadow — a box-shadow
   is clipped by its own element's overflow:hidden. This inner wrapper handles
   corner-clipping and the hover-zoom transform; the outer element (.vs-svc-img,
   .vs-item-img-wrap, .vs-gallery-item) is free to carry border + box-shadow
   without clipping its own shadow. Reused identically by Gallery, Products
   (items_) and Services (svc_) image styling. */
.vs-img-clip{position:absolute;inset:0;overflow:hidden;border-radius:inherit}
.vs-img-clip img{width:100%;height:100%;display:block}
<?php if ( $_sec_show('services') ): ?>
/* Image mode: full-width cover like product card */
.vs-svc-img{
  aspect-ratio:4/3;background:#F1F5F9;width:100%;flex-shrink:0;position:relative;
  height:var(--vs-svc-img-h,auto);
  border-radius:var(--vs-svc-img-r,0) var(--vs-svc-img-r,0) 0 0;
  border:var(--vs-svc-img-border-w,0) var(--vs-svc-img-border-style,solid) var(--vs-svc-img-border-color,transparent);
  box-shadow:var(--vs-svc-img-shadow,none);
}
.vs-svc-img .vs-img-clip img{width:var(--vs-svc-img-w,100%);object-fit:var(--vs-svc-img-fit,contain);object-position:var(--vs-svc-img-position,center);background:#F8FAFC;transition:transform .3s}
.vs-svc-card:hover .vs-svc-img img{transform:scale(1.05)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'svc_title', '.vs-svc-name', [ 'font_size' => 14, 'font_weight' => '600', 'color' => esc_attr( $brand_color2 ) ] ); ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'svc_desc', '.vs-svc-desc', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.55' ] ); ?>
.vs-svc-price{
  font-size:.9rem;font-weight:700;
  color:var(--vs-primary,#2563EB);
}
/* Enquire Now button — full width, consistent across all cards */
.vs-svc-enquire-btn{
  display:block;width:100%;
  padding:10px 16px;
  background:var(--vs-svc-enq-btn-bg,var(--vs-primary,#2563EB));
  color:var(--vs-svc-enq-btn-text,#fff);
  border:var(--vs-svc-enq-btn-border,none);
  border-radius:var(--vs-svc-enq-btn-r,8px);
  font-size:var(--vs-svc-enq-btn-size,.82rem);font-weight:var(--vs-svc-enq-btn-weight,700);
  cursor:pointer;font-family:var(--vs-svc-enq-btn-font,inherit);
  transition:filter .18s,transform .18s;
  letter-spacing:var(--vs-svc-enq-btn-ls,.02em);
}
.vs-svc-enquire-btn:hover{filter:brightness(1.1);transform:translateY(-1px)}
.vs-svc-enquire-btn:active{transform:translateY(0)}
<?php endif; ?>

/* ── PROCESS ─────────────────────────────────────── */
<?php if ( $_sec_show('process') ): ?>
.vs-process-section{background:var(--vs-process-bg, var(--vs-dark));color:#fff}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'process_heading', '.vs-process-section .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#ffffff' ] ); ?>
<?php endif; ?>
<?php
// Real fix — six section headings (about/services/why/faq/contact/items)
// had either no CSS var at all, or a var that was emitted but never
// actually consumed by anything — meaning the color control (where one
// existed in the form) never did anything, and font-size/weight/family/
// etc never existed as controls at all. Each now gets a real, working
// rule via the same centralized engine as every other section.
echo \GoodService\Service\TypographyService::css_rule( $cd, 'about_heading', '#vs-sec-about .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'services_heading', '#vs-sec-services .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'why_heading', '#vs-sec-why .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'highlights_heading', '#vs-sec-highlights .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'amenities_heading', '#vs-sec-amenities .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'facilities_heading', '#vs-sec-facilities .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'awards_heading', '#vs-sec-awards .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'languages_heading', '#vs-sec-languages .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'packages_heading', '#vs-sec-packages .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'room_types_heading', '#vs-sec-room_types .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_event_spaces_heading', '#vs-sec-hotel_event_spaces .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_events_showcase_heading', '#vs-sec-hotel_events_showcase .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
// Per-component typography controls: create-listing.php exposes
// cl_typography_fields() for these 4 fields (Card Title/Description/
// Event Type Badge/Meta line), but until this fix vendor-site.php never
// emitted a matching css_rule() — the admin controls existed and saved
// correctly but had zero visible effect on the live page (a config-key
// consistency gap: written, never read). Fixed by wiring all 4 to their
// real render()-time classes.
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_events_showcase_title', '#vs-sec-hotel_events_showcase .gs-hevs-card-title', [ 'font_size' => 17, 'font_weight' => '700', 'line_height' => '1.35', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_events_showcase_desc', '#vs-sec-hotel_events_showcase .gs-hevs-card-desc', [ 'font_size' => 14, 'line_height' => '1.6', 'color' => '#7A6B60' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_events_showcase_badge', '#vs-sec-hotel_events_showcase .gs-hevs-badge', [ 'font_size' => 11, 'font_weight' => '700', 'letter_spacing' => '0.06', 'text_transform' => 'uppercase', 'color' => '#FFFFFF' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_events_showcase_meta', '#vs-sec-hotel_events_showcase .gs-hevs-meta', [ 'font_size' => 12, 'font_weight' => '600', 'letter_spacing' => '0.02', 'color' => '#D97706' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_dining_heading', '#vs-sec-hotel_dining .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
// Same config-key consistency fix as above, for the 3 per-item Dining
// fields (Item Name/Price/Description) admin-panel exposes.
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_dining_name', '#vs-sec-hotel_dining .gs-hdin-name', [ 'font_size' => 16, 'font_weight' => '700', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_dining_price', '#vs-sec-hotel_dining .gs-hdin-price', [ 'font_size' => 15, 'font_weight' => '700', 'color' => '#B45309' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_dining_desc', '#vs-sec-hotel_dining .gs-hdin-desc-line', [ 'font_size' => 13, 'line_height' => '1.55', 'color' => '#7A6B60' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_amenities_heading', '#vs-sec-hotel_amenities .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
// Same config-key consistency fix as above, for the 2 per-item Amenities
// fields (Group Title/Amenity Item) admin-panel exposes.
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_amenities_group_title', '#vs-sec-hotel_amenities .gs-hamn-group-title', [ 'font_size' => 17, 'font_weight' => '700', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_amenities_item', '#vs-sec-hotel_amenities .gs-hamn-item-title', [ 'font_size' => 14, 'font_weight' => '600', 'color' => '#334155' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_virtual_tour_heading', '#vs-sec-hotel_virtual_tour .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_closing_banner_heading', '#vs-sec-hotel_closing_banner .gs-hcb-heading', [ 'font_size' => 40, 'font_weight' => '800', 'color' => '#FFFFFF' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_closing_banner_desc', '#vs-sec-hotel_closing_banner .gs-hcb-desc', [ 'font_size' => 17, 'line_height' => '1.6' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'hotel_closing_banner_cta', '#vs-sec-hotel_closing_banner .gs-hcb-btn', [ 'font_size' => 17, 'font_weight' => '800', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'property_listings_heading', '#vs-sec-property_listings .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'featured_properties_heading', '#vs-sec-featured_properties .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'property_types_heading', '#vs-sec-property_types .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'property_gallery_heading', '#vs-sec-property_gallery .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'featured_projects_heading', '#vs-sec-featured_projects .vs-sec-title', [ 'font_size' => 44, 'font_weight' => '700', 'color' => '#18181B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'project_categories_heading', '#vs-sec-project_categories .vs-sec-title', [ 'font_size' => 44, 'font_weight' => '700', 'color' => '#18181B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'three_d_before_after_heading', '#vs-sec-three_d_before_after .vs-sec-title', [ 'font_size' => 44, 'font_weight' => '700', 'color' => '#18181B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'design_styles_heading', '#vs-sec-design_styles .vs-sec-title', [ 'font_size' => 44, 'font_weight' => '700', 'color' => '#18181B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'design_process_heading', '#vs-sec-design_process .vs-sec-title', [ 'font_size' => 44, 'font_weight' => '700', 'color' => '#18181B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'featured_services_heading', '#vs-sec-featured_services .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'beauty_services_heading', '#vs-sec-beauty_services .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'beauty_gallery_heading', '#vs-sec-beauty_gallery .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'beauty_experts_heading', '#vs-sec-beauty_experts .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'beauty_facilities_heading', '#vs-sec-beauty_facilities .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'beauty_packages_heading', '#vs-sec-beauty_packages .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'beauty_booking_cta_heading', '#vs-sec-beauty_booking_cta .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_portfolio_heading', '#vs-sec-wedding_portfolio .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_portfolio_caption', '#vs-sec-wedding_portfolio .gs-wedding-portfolio-caption', [ 'font_size' => 14, 'font_weight' => '600', 'line_height' => '1.4' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_portfolio_cat', '#vs-sec-wedding_portfolio .gs-wedding-portfolio-cat', [ 'font_size' => 11, 'font_weight' => '700', 'letter_spacing' => '0.08', 'text_transform' => 'uppercase', 'color' => '#D97706' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_stories_heading', '#vs-sec-wedding_stories .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_stories_title', '#vs-sec-wedding_stories .gs-wedding-story-title', [ 'font_size' => 17, 'font_weight' => '700', 'line_height' => '1.35', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_stories_desc', '#vs-sec-wedding_stories .gs-wedding-story-desc', [ 'font_size' => 14, 'line_height' => '1.6', 'color' => '#7A6B60' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_stories_badge', '#vs-sec-wedding_stories .gs-wedding-story-badge', [ 'font_size' => 11, 'font_weight' => '700', 'letter_spacing' => '0.06', 'text_transform' => 'uppercase', 'color' => '#FFFFFF' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_stories_meta', '#vs-sec-wedding_stories .gs-wedding-story-meta', [ 'font_size' => 12, 'font_weight' => '600', 'letter_spacing' => '0.02', 'color' => '#D97706' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_services_heading', '#vs-sec-wedding_services .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_services_title', '#vs-sec-wedding_services .gs-wedding-service-title', [ 'font_size' => 17, 'font_weight' => '700', 'line_height' => '1.35', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_services_desc', '#vs-sec-wedding_services .gs-wedding-service-desc', [ 'font_size' => 14, 'line_height' => '1.6', 'color' => '#7A6B60' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_services_tag', '#vs-sec-wedding_services .gs-wedding-service-tag', [ 'font_size' => 11, 'font_weight' => '700', 'letter_spacing' => '0.06', 'text_transform' => 'uppercase', 'color' => '#FFFFFF' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_services_duration', '#vs-sec-wedding_services .gs-wedding-service-duration', [ 'font_size' => 13, 'font_weight' => '700', 'color' => '#D97706' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_packages_heading', '#vs-sec-wedding_packages .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_packages_title', '#vs-sec-wedding_packages .gs-wedding-pkg-title', [ 'font_size' => 18, 'font_weight' => '700', 'line_height' => '1.35', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_packages_desc', '#vs-sec-wedding_packages .gs-wedding-pkg-desc', [ 'font_size' => 14, 'line_height' => '1.6', 'color' => '#7A6B60' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_packages_tag', '#vs-sec-wedding_packages .gs-wedding-pkg-tag', [ 'font_size' => 11, 'font_weight' => '700', 'letter_spacing' => '0.06', 'text_transform' => 'uppercase', 'color' => '#FFFFFF' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_packages_price_main', '#vs-sec-wedding_packages .gs-wedding-pkg-price-main', [ 'font_size' => 22, 'font_weight' => '800', 'color' => '#D97706' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_packages_price_orig', '#vs-sec-wedding_packages .gs-wedding-pkg-price-orig', [ 'font_size' => 15, 'text_decoration' => 'line-through', 'color' => '#7A6B60' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_packages_price_prefix', '#vs-sec-wedding_packages .gs-wedding-pkg-price-prefix', [ 'font_size' => 12, 'font_weight' => '600', 'letter_spacing' => '0.02', 'text_transform' => 'uppercase', 'color' => '#7A6B60' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_packages_includes', '#vs-sec-wedding_packages .gs-wedding-pkg-includes', [ 'font_size' => 14, 'line_height' => '1.7', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_packages_cta', '#vs-sec-wedding_packages .gs-wedding-pkg-cta', [ 'font_size' => 14, 'font_weight' => '700', 'color' => '#FFFFFF' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_style_heading', '#vs-sec-wedding_style .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_style_label', '#vs-sec-wedding_style .gs-wedding-style-card-label', [ 'font_size' => 16, 'font_weight' => '700', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_style_desc', '#vs-sec-wedding_style .gs-wedding-style-card-desc', [ 'font_size' => 13, 'line_height' => '1.55', 'color' => '#7A6B60' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_team_heading', '#vs-sec-wedding_team .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_team_name', '#vs-sec-wedding_team .gs-wedding-team-name', [ 'font_size' => 17, 'font_weight' => '700', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_team_role', '#vs-sec-wedding_team .gs-wedding-team-role', [ 'font_size' => 13, 'font_weight' => '600', 'letter_spacing' => '0.02', 'color' => '#D97706' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_team_bio', '#vs-sec-wedding_team .gs-wedding-team-bio', [ 'font_size' => 14, 'line_height' => '1.6', 'color' => '#7A6B60' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_venue_spec_heading', '#vs-sec-wedding_venue_specialization .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_venue_spec_label', '#vs-sec-wedding_venue_specialization .gs-wedding-venuespec-card-label', [ 'font_size' => 15, 'font_weight' => '700', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_venue_spec_note', '#vs-sec-wedding_venue_specialization .gs-wedding-venuespec-card-note', [ 'font_size' => 13, 'line_height' => '1.55', 'color' => '#7A6B60' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_locations_heading', '#vs-sec-wedding_locations .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_locations_name', '#vs-sec-wedding_locations .gs-wedding-location-card-name', [ 'font_size' => 15, 'font_weight' => '700', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_locations_note', '#vs-sec-wedding_locations .gs-wedding-location-card-note', [ 'font_size' => 13, 'line_height' => '1.55', 'color' => '#7A6B60' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_locations_home_badge', '#vs-sec-wedding_locations .gs-wedding-location-home-badge', [ 'font_size' => 11, 'font_weight' => '800', 'letter_spacing' => '0.04', 'text_transform' => 'uppercase', 'color' => '#FFFFFF' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_locations_badge_title', '#vs-sec-wedding_locations .gs-wedding-location-badge-title', [ 'font_size' => 16, 'font_weight' => '800', 'letter_spacing' => '0.01', 'color' => '#FFFFFF' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_locations_badge_note', '#vs-sec-wedding_locations .gs-wedding-location-badge-note', [ 'font_size' => 14, 'line_height' => '1.55' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_availability_heading', '#vs-sec-wedding_availability .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_availability_desc', '#vs-sec-wedding_availability .gs-wedding-availability-desc', [ 'font_size' => 16, 'line_height' => '1.65', 'color' => '#7A6B60' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_availability_step_title', '#vs-sec-wedding_availability .gs-wedding-availability-step-title', [ 'font_size' => 15, 'font_weight' => '700', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_availability_cta', '#vs-sec-wedding_availability .gs-wedding-availability-btn', [ 'font_size' => 15, 'font_weight' => '700', 'color' => '#FFFFFF' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_quote_heading', '#vs-sec-wedding_quote .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_quote_label', '#vs-sec-wedding_quote .gs-wedding-quote-lbl', [ 'font_size' => 12, 'font_weight' => '700', 'letter_spacing' => '0.04', 'text_transform' => 'uppercase', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_quote_cta', '#vs-sec-wedding_quote .gs-wedding-quote-btn', [ 'font_size' => 15, 'font_weight' => '700', 'color' => '#FFFFFF' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_closing_banner_heading', '#vs-sec-wedding_closing_banner .vs-sec-title', [ 'font_size' => 40, 'font_weight' => '800', 'color' => '#FFFFFF' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_closing_banner_desc', '#vs-sec-wedding_closing_banner .gs-wedding-closing-banner-desc', [ 'font_size' => 17, 'line_height' => '1.6' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'wedding_closing_banner_cta', '#vs-sec-wedding_closing_banner .gs-wedding-closing-banner-btn', [ 'font_size' => 17, 'font_weight' => '800', 'color' => '#231A14' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'home_services_catalogue_heading', '#vs-sec-home_services_catalogue .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'home_services_packages_heading', '#vs-sec-home_services_packages .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'home_services_technicians_heading', '#vs-sec-home_services_technicians .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'home_services_guarantee_heading', '#vs-sec-home_services_guarantee .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'home_services_before_after_heading', '#vs-sec-home_services_before_after .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'departments_heading', '#vs-sec-departments .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'doctors_heading', '#vs-sec-doctors .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'patient_facilities_heading', '#vs-sec-patient_facilities .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'patient_journey_heading', '#vs-sec-patient_journey .vs-sec-title', [ 'font_size' => 36, 'font_weight' => '700', 'color' => '#0F172A' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'memberships_heading', '#vs-sec-memberships .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'certifications_heading', '#vs-sec-certifications .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
// Bug fix: this control's selector was '#vs-sec-warranty .vs-sec-title',
// a class that never actually renders anywhere in the Warranty section
// (the section has no separate heading — the banner IS the section).
// The real heading element is .vs-war-title. The admin panel and its
// saved values were genuine dead weight — visible in the editor,
// completely inert on the frontend. Defaults below match this
// section's actual pre-existing hardcoded look (20px, #14532D dark
// green) so fixing the selector causes zero visual change for anyone
// who never touched this (previously non-functional) control.
echo \GoodService\Service\TypographyService::css_rule( $cd, 'warranty_title', '.vs-war-title', [ 'font_size' => 20, 'font_weight' => '800', 'color' => '#14532D' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'faq_heading', '#vs-sec-faq .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'contact_heading', '#vs-sec-contact .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'items_heading', '#vs-sec-items .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
// Real fix — stats/team/clients/portfolio/testimonials headings had no
// styling control of any kind before (not even color) — stats also had
// a hardcoded inline style="color:#fff" (removed above) that would have
// silently defeated any CSS rule regardless of specificity.
echo \GoodService\Service\TypographyService::css_rule( $cd, 'stats_heading', '#vs-sec-stats .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#ffffff' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'team_heading', '#vs-sec-team .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'clients_heading', '#vs-sec-clients .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'portfolio_heading', '#vs-sec-portfolio .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'testimonials_heading', '#vs-sec-testimonials .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] );
?>
<?php if ( $_sec_show('process') ): ?>
.vs-process-section .vs-sec-sub{color:var(--vs-process-sec-desc, rgba(255,255,255,.65))}
.vs-proc-grid{
  display:grid;grid-template-columns:repeat(auto-fit,minmax(175px,1fr));
  row-gap:<?php echo $cv_proc_row_gap; ?>px;column-gap:<?php echo $cv_proc_col_gap; ?>px;
  position:relative;
}
@media(max-width:680px){.vs-proc-grid{grid-template-columns:1fr 1fr}}
@media(max-width:400px){.vs-proc-grid{grid-template-columns:1fr}}
.vs-proc-step{
  display:flex;
  flex-direction:<?php echo $cv_proc_icon_position === 'left' ? 'row' : ( $cv_proc_icon_position === 'right' ? 'row-reverse' : ( $cv_proc_icon_position === 'bottom' ? 'column-reverse' : 'column' ) ); ?>;
  align-items:center;text-align:<?php echo $cv_proc_title_align; ?>;
  padding:<?php echo $cv_proc_box_padding; ?>px;margin:<?php echo $cv_proc_box_margin; ?>px;
  gap:<?php echo $cv_proc_gap; ?>px;
  background:var(--vs-process-card-bg, transparent);
  border:<?php echo $cv_process_card_border_width; ?>px solid var(--vs-process-card-border, transparent);
  border-radius:<?php echo $cv_process_card_radius; ?>px;
  box-shadow:<?php echo $shadow_map[$cv_process_card_shadow] ?? 'none'; ?>;
  transition:box-shadow .2s,transform .2s;
  position:relative;
}
.vs-proc-step:hover{transform:translateY(-3px)}
<?php if ($cv_proc_icon_position === 'center'): ?>
.vs-proc-step .vs-proc-title{order:1}
.vs-proc-step .vs-proc-num{order:2}
.vs-proc-step .vs-proc-desc{order:3}
<?php endif; ?>
.vs-proc-step:not(:last-child)::after{content:"→";position:absolute;top:46px;right:-10px;font-size:1.2rem;color:rgba(255,255,255,.28);z-index:2;font-weight:700;line-height:1}
@media(max-width:680px){.vs-proc-step:not(:last-child)::after{display:none}}
.vs-proc-num{
  width:<?php echo $cv_proc_icon_width > 0 ? $cv_proc_icon_width.'px' : 'var(--vs-proc-icon-size,108px)'; ?>;
  height:var(--vs-proc-icon-size,108px);border-radius:var(--vs-proc-icon-radius,50%);
  background:var(--vs-process-num-bg, rgba(255,255,255,.1));opacity:<?php echo $cv_proc_icon_bg_opacity; ?>;
  color:var(--vs-process-num, inherit);
  border:<?php echo $cv_proc_icon_border_w; ?>px solid var(--vs-process-num-border, rgba(255,255,255,.2));
  display:flex;align-items:center;justify-content:center;
  padding:<?php echo $cv_proc_icon_padding; ?>px;
  <?php
    if ($cv_proc_icon_position === 'left') {
        echo 'margin-right:'.$cv_proc_icon_margin.'px;';
    } elseif ($cv_proc_icon_position === 'right') {
        echo 'margin-left:'.$cv_proc_icon_margin.'px;';
    } else {
        echo 'margin-bottom:'.$cv_proc_icon_margin.'px;';
    }
  ?>
  position:relative;overflow:hidden;font-size:calc(var(--vs-proc-icon-size,108px) * 0.24);
  transform:rotate(<?php echo $cv_proc_icon_rotation; ?>deg);
  transition:transform .2s,background .2s;
  box-shadow:<?php echo $shadow_map[$cv_proc_icon_shadow] ?? 'none'; ?>;
}
.vs-proc-step:hover .vs-proc-num{background:var(--vs-process-num-bg, rgba(255,255,255,.18));transform:scale(1.07)}
.vs-proc-num img{width:100%;height:100%;object-fit:<?php echo esc_attr($cv_proc_icon_fit); ?>;opacity:<?php echo $cv_proc_icon_opacity; ?>}
.vs-proc-num-badge{position:absolute;bottom:3px;right:3px;width:30px;height:30px;border-radius:50%;background:var(--vs-primary);color:#fff;font-size:.78rem;font-weight:800;display:flex;align-items:center;justify-content:center}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'process_title', '.vs-proc-title', [ 'font_size' => 15, 'font_weight' => '800', 'color' => '#ffffff', 'line_height' => '1.3' ] ); ?>
.vs-proc-title{
  width:100%;
  text-align:<?php echo $cv_proc_title_align; ?>;margin-bottom:<?php echo $cv_proc_title_margin; ?>px;
  padding:<?php echo $cv_proc_title_padding; ?>px;
}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'process_desc', '.vs-proc-desc', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#E2E8F0', 'line_height' => '1.65' ] ); ?>
.vs-proc-desc{
  width:100%;
  text-align:<?php echo $cv_proc_desc_align; ?>;margin:<?php echo $cv_proc_desc_margin; ?>px 0 0;
  padding:<?php echo $cv_proc_desc_padding; ?>px;
}
<?php endif; ?>

/* ── ITEMS GRID ──────────────────────────────────── */
<?php if ( $_sec_show('items') ): ?>
.vs-items-grid{display:grid;grid-template-columns:repeat(var(--vs-items-grid-cols,3),1fr);gap:var(--vs-items-gap,20px)}
@media(max-width:900px){.vs-items-grid{grid-template-columns:repeat(min(var(--vs-items-grid-cols,3),2),1fr)}}
@media(max-width:480px){.vs-items-grid{grid-template-columns:repeat(2,1fr);gap:var(--vs-items-gap-mobile,10px)}}
.vs-item-card{background:#fff;border:1.5px solid var(--vs-card-border,#E2E8F0);border-radius:var(--vs-card-radius,16px);overflow:hidden;transition:all .22s;display:flex;flex-direction:column}
.vs-item-card:hover{box-shadow:var(--vs-card-shadow,0 10px 28px rgba(0,0,0,.09));transform:translateY(-3px)}
.vs-item-img{aspect-ratio:4/3;overflow:hidden;background:#F1F5F9}
.vs-item-img img{width:100%;height:100%;object-fit:var(--vs-items-img-fit,contain);background:#F1F5F9;transition:transform .3s}
.vs-item-card:hover .vs-item-img img{transform:scale(1.06)}
.vs-item-img-ph{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:2.5rem}
.vs-item-body{padding:var(--vs-card-pad,18px);flex:1;display:flex;flex-direction:column}
.vs-item-cat{display:inline-block;background:#EFF6FF;color:var(--vs-primary);border-radius:20px;padding:3px 10px;font-size:.72rem;font-weight:700;margin-bottom:8px}
.vs-item-title{font-weight:800;color:var(--vs-dark);font-size:.95rem;margin-bottom:6px}
.vs-item-desc{font-size:.83rem;color:#64748B;line-height:1.6;flex:1;margin-bottom:12px}
.vs-item-price{font-weight:800;color:var(--vs-primary);font-size:.95rem;margin-bottom:12px}
.vs-item-footer{margin-top:auto}
/* ── GET QUOTE BUTTON — modern, professional ────── */
/* ── ITEM CARDS — Full customization via CSS vars ── */
.vs-items-grid{display:grid;grid-template-columns:repeat(var(--vs-items-grid-cols,3),1fr);gap:var(--vs-items-gap,20px)}
@media(max-width:680px){.vs-items-grid{grid-template-columns:repeat(min(var(--vs-items-grid-cols,3),2),1fr);gap:var(--vs-items-gap-mobile,12px)}}
@media(max-width:400px){.vs-items-grid{grid-template-columns:1fr}}
/* Section uses custom padding vars if set */
#vs-sec-items.vs-section{
  padding-top:var(--vs-items-sec-pt,var(--vs-sec-pt,64px))!important;
  padding-bottom:var(--vs-items-sec-pb,var(--vs-sec-pb,64px))!important;
}
#vs-sec-items{background:var(--vs-items-sec-bg,transparent)!important}
.vs-item-card{
  background:var(--vs-items-card-bg,#fff);
  border:var(--vs-items-card-bw,1px) solid var(--vs-items-card-bc,#E8ECF2);
  border-radius:var(--vs-items-card-r,16px);
  overflow:hidden;display:flex;flex-direction:column;
  transition:box-shadow .22s,transform .22s;
  box-shadow:var(--vs-items-card-sh,0 2px 8px rgba(0,0,0,.05));
  margin:var(--vs-items-card-margin,0);
}
.vs-item-card:hover{box-shadow:0 8px 32px rgba(0,0,0,.12);transform:translateY(-3px)}
/* Type badge — top-left pill */
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'item_badge', '.vs-item-badge', [ 'font_size' => 10, 'font_weight' => '800', 'color' => '#ffffff', 'text_transform' => 'uppercase', 'letter_spacing' => '0.1' ] ); ?>
.vs-item-badge{
  position:absolute;top:14px;left:14px;z-index:2;
  background:#1E293B;
  padding:4px 10px;border-radius:6px;
}
/* Image wrapper with padding around image */
.vs-item-img-wrap{
  position:relative;
  background:var(--vs-items-img-box-bg,#F8FAFC);
  padding:20px 20px 16px;
  min-height:var(--vs-items-img-box-h,200px);
  height:var(--vs-items-img-box-h,200px);
  display:flex;align-items:center;justify-content:center;
  border-radius:var(--vs-items-img-box-r,0);
  border:var(--vs-items-img-border-w,0) var(--vs-items-img-border-style,solid) var(--vs-items-img-border-color,transparent);
  box-shadow:var(--vs-items-img-shadow,none);
}
.vs-item-img-wrap .vs-img-clip img{
  /* Real fix: object-fit was hardcoded to "cover" here, silently ignoring
     the items_img_fit setting even when the vendor configured it. */
  object-fit:var(--vs-items-img-fit,cover);
  object-position:var(--vs-items-img-position,center);
}
.vs-item-img-placeholder{
  width:100%;height:100%;display:flex;align-items:center;justify-content:center;
  font-size:3.5rem;color:#CBD5E1;background:var(--vs-items-img-box-bg,#F8FAFC);
}
/* Card body */
.vs-item-body{
  padding:var(--vs-items-card-pad,16px) calc(var(--vs-items-card-pad,16px) + 2px) calc(var(--vs-items-card-pad,16px) + 2px);
  display:flex;flex-direction:column;flex:1;gap:6px;
}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'items_title', '.vs-item-title', [ 'font_size' => 16, 'font_weight' => '700', 'color' => $cv_heading, 'line_height' => '1.35' ] ); ?>
/* Description: paragraph mode */
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'items_desc', '.vs-item-desc', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.65' ] ); ?>
.vs-item-desc{margin:0}
/* Description: list mode */
.vs-item-desc-list{
  list-style:none;margin:0;padding:0;
  display:flex;flex-direction:column;gap:3px;
}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'items_desc', '.vs-item-desc-list li', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.5' ] ); ?>
.vs-item-desc-list li{
  display:flex;align-items:flex-start;gap:6px;
}
.vs-item-desc-list li::before{content:'•';color:var(--vs-primary,#2563EB);flex-shrink:0;font-weight:700}
/* Price + CTA row */
.vs-item-footer{
  display:flex;align-items:center;justify-content:space-between;
  gap:10px;margin-top:auto;padding-top:12px;
  border-top:1px solid #F1F5F9;
}
.vs-item-price{
  font-size:var(--vs-items-price-size,1.05rem);
  font-weight:800;
  color:var(--vs-items-price-color,var(--vs-primary,#2563EB));
}
/* Real feature, item 5: on mobile, the price becomes its own distinct,
   full-width strip stacked above the button, rather than sharing a tight
   side-by-side row with it. */
@media(max-width:680px){
  .vs-item-footer{flex-wrap:wrap}
  .vs-item-price{
    width:100%;font-size:1.15rem;padding:8px 0;
    border-bottom:1px dashed #E2E8F0;margin-bottom:4px;
  }
  .vs-item-quote-btn{width:100%;justify-content:center}
}
.vs-item-quote-btn{
  display:inline-flex;align-items:center;gap:6px;
  padding:9px 18px;
  border-radius:var(--vs-items-btn-r,8px);
  background:var(--vs-items-btn-bg,var(--vs-primary,#2563EB));
  color:var(--vs-items-btn-text,#fff);
  border:var(--vs-items-btn-bw,0) solid var(--vs-items-btn-bc,transparent);
  font-size:.82rem;font-weight:700;cursor:pointer;
  font-family:inherit;transition:all .2s;
  white-space:nowrap;flex-shrink:0;
  letter-spacing:.02em;
  box-shadow:0 2px 8px rgba(0,0,0,.1);
}
.vs-item-quote-btn:hover{transform:translateY(-2px);box-shadow:0 6px 18px rgba(0,0,0,.16);filter:brightness(1.08)}
.vs-item-quote-btn:active{transform:translateY(0);box-shadow:0 2px 8px rgba(0,0,0,.1)}
<?php endif; ?>

/* ── STATS ────────────────────────────────────────── */
<?php if ( $_sec_show('stats') ): ?>
.vs-stats-section{background:var(--vs-stats-bg, var(--vs-dark))}
.vs-stats-grid{
  display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));
  row-gap:<?php echo $cv_stat_row_gap; ?>px;column-gap:<?php echo $cv_stat_col_gap; ?>px;
}
.vs-stat-card{
  display:flex;
  flex-direction:<?php echo $cv_stat_icon_position === 'left' ? 'row' : ( $cv_stat_icon_position === 'right' ? 'row-reverse' : ( $cv_stat_icon_position === 'bottom' ? 'column-reverse' : 'column' ) ); ?>;
  align-items:center;justify-content:center;
  text-align:<?php echo $cv_stat_val_align; ?>;
  padding:<?php echo $cv_stat_box_padding; ?>px;
  margin:<?php echo $cv_stat_box_margin; ?>px;
  gap:<?php echo $cv_stat_gap; ?>px;
  border:1px solid rgba(255,255,255,.12);border-radius:<?php echo $cv_stat_box_radius; ?>px;
  background:<?php echo $cv_stat_box_bg ? esc_attr($cv_stat_box_bg) : 'rgba(255,255,255,.05)'; ?>;backdrop-filter:blur(4px);
  transition:transform .2s,background .2s;
}
.vs-stat-card:hover{transform:translateY(-4px);background:<?php echo $cv_stat_box_bg ? esc_attr($cv_stat_box_bg) : 'rgba(255,255,255,.1)'; ?>}
.vs-stat-icon{font-size:1.8rem;line-height:1;<?php if ($cv_stat_icon_position === 'none') echo 'display:none;'; ?>}
<?php if ($cv_stat_icon_position === 'center'): ?>
.vs-stat-card .vs-stat-val{order:1}
.vs-stat-card .vs-stat-icon{order:2}
.vs-stat-card .vs-stat-lbl{order:3}
<?php endif; ?>
.vs-stat-val{
  font-size:<?php echo $cv_stat_val_size; ?>px;font-weight:<?php echo esc_attr($cv_stat_val_weight); ?>;color:var(--vs-stats-num, var(--vs-yellow));line-height:1;letter-spacing:-.02em;
  text-align:<?php echo $cv_stat_val_align; ?>;margin:<?php echo $cv_stat_val_margin; ?>px 0;padding:<?php echo $cv_stat_val_padding; ?>px;width:100%;
}
.vs-stat-unit{font-size:1.4rem;font-weight:900;color:var(--vs-yellow);vertical-align:super;line-height:0}
.vs-stat-lbl{
  font-size:.75rem;color:var(--vs-stats-label, rgba(255,255,255,.7));text-transform:uppercase;letter-spacing:.08em;font-weight:<?php echo esc_attr($cv_stat_lbl_weight); ?>;
  text-align:<?php echo $cv_stat_lbl_align; ?>;margin:<?php echo $cv_stat_lbl_margin; ?>px 0 0;padding:<?php echo $cv_stat_lbl_padding; ?>px;width:100%;
}
<?php endif; ?>

/* ── GALLERY ─────────────────────────────────────── */
<?php if ( $_sec_show('gallery') ): ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'gallery_heading', '#vs-sec-gallery .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] ); ?>
/* Real feature — .vs-gal-filter had zero CSS rules anywhere in this
   file, confirmed by grep before writing this: these buttons rendered
   as completely unstyled browser defaults. Active state uses the
   vendor's chosen color if set (gallery_filter_active_color), falling
   back to this platform's own primary brand color. */
.vs-gal-filters{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-bottom:24px}
.vs-gal-filter{
  padding:8px 18px;border-radius:999px;border:1.5px solid #E2E8F0;background:#fff;
  color:#475569;font-size:.82rem;font-weight:600;cursor:pointer;transition:all .18s;font-family:inherit;
}
.vs-gal-filter:hover{border-color:var(--vs-gallery-filter, var(--vs-primary,#2563EB));color:var(--vs-gallery-filter, var(--vs-primary,#2563EB))}
.vs-gal-filter.on{
  background:var(--vs-gallery-filter, var(--vs-primary,#2563EB));
  border-color:var(--vs-gallery-filter, var(--vs-primary,#2563EB));
  color:#fff;
}
.vs-gallery-grid{
  display:grid;grid-template-columns:repeat(var(--vs-gallery-cols,4),1fr);gap:var(--vs-gallery-gap,16px);
  <?php if ($cv_gallery_layout === 'masonry'): ?>grid-auto-rows:10px;<?php endif; ?>
}
@media(max-width:760px){.vs-gallery-grid{grid-template-columns:repeat(<?php echo $cv_gallery_cols_mobile; ?>,1fr)}}
<?php if ($cv_gallery_max_rows > 0): ?>
/* Real feature: max rows — hides items beyond cols × max_rows */
.vs-gallery-grid .vs-gallery-item:nth-child(n+<?php echo ($cv_gallery_cols * $cv_gallery_max_rows) + 1; ?>){display:none}
@media(max-width:760px){.vs-gallery-grid .vs-gallery-item{display:flex!important}
  .vs-gallery-grid .vs-gallery-item:nth-child(n+<?php echo ($cv_gallery_cols_mobile * $cv_gallery_max_rows) + 1; ?>){display:none!important}}
<?php endif; ?>
/* Uniform rectangular image boxes — all images same size regardless of source dimensions */
.vs-gallery-item{
  <?php
  // Real fix: $cv_gallery_img_h ("Gallery Image Height" in the editor) was
  // computed above and passed all the way into this closure's use() list,
  // but this box's actual height only ever came from aspect-ratio (grid
  // layout) or a hardcoded "span 24" (masonry layout) — $cv_gallery_img_h
  // itself was never once written into any CSS or HTML here, so changing
  // it from the editor had literally zero effect on the live page. A value
  // of 0 is the documented "natural dimensions" default and correctly
  // keeps the old aspect-ratio/span-24 behavior; any value above 0 now
  // overrides it with an explicit height, for both layouts. Masonry's
  // "span 24" was really just 24 × grid-auto-rows:10px = 240px hardcoded
  // (itself equal to this field's own default) — now computed from the
  // real setting instead of a hardcoded number.
  if ( $cv_gallery_layout !== 'masonry' ) {
      echo $cv_gallery_img_h > 0
          ? 'height:' . (int) $cv_gallery_img_h . 'px;'
          : 'aspect-ratio:' . esc_attr( $cv_gallery_aspect ) . ';';
  } else {
      $_gal_masonry_h = $cv_gallery_img_h > 0 ? $cv_gallery_img_h : 240;
      echo 'grid-row-end:span ' . max( 1, (int) round( $_gal_masonry_h / 10 ) ) . ';';
  }
  ?>
  border-radius:var(--vs-gallery-radius,25px);
  <?php echo $cv_gallery_img_w > 0 ? 'max-width:'.$cv_gallery_img_w.'px;margin:0 auto;' : ''; ?>
  cursor:<?php echo $cv_gallery_lightbox ? 'zoom-in' : 'default'; ?>;
  background:#F1F5F9;
  position:relative;
  display:block;
  border:var(--vs-gallery-img-border-w,0) var(--vs-gallery-img-border-style,solid) var(--vs-gallery-img-border-color,transparent);
  box-shadow:var(--vs-gallery-img-shadow,none);
}
.vs-gallery-item img{
  width:100%!important;
  height:100%!important;
  /* Real fix: was hardcoded to cover with !important, silently ignoring
     the gallery_img_fit setting no matter what a vendor chose. */
  object-fit:<?php echo esc_attr($cv_gallery_img_fit); ?>!important;
  object-position:var(--vs-gallery-img-position,center)!important;
  transition:transform .35s cubic-bezier(.25,.46,.45,.94),filter .35s,opacity .35s;
  display:block;
}
<?php if ($cv_gallery_hover === 'zoom'): ?>
.vs-gallery-item:hover img{transform:scale(1.06)}
<?php elseif ($cv_gallery_hover === 'darken'): ?>
.vs-gallery-item:hover img{filter:brightness(.7)}
<?php elseif ($cv_gallery_hover === 'brighten'): ?>
.vs-gallery-item:hover img{filter:brightness(1.2)}
<?php elseif ($cv_gallery_hover === 'grayscale-color'): ?>
.vs-gallery-item img{filter:grayscale(1)}
.vs-gallery-item:hover img{filter:grayscale(0)}
<?php endif; ?>
<?php if ($cv_gallery_captions): ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'gallery_caption', '.vs-gallery-caption', [ 'font_size' => 12, 'font_weight' => '400', 'color' => '#FFFFFF' ] ); ?>
.vs-gallery-caption{position:absolute;bottom:0;left:0;right:0;background:linear-gradient(transparent,rgba(0,0,0,.75));padding:20px 10px 8px;opacity:0;transition:opacity .25s;pointer-events:none}
.vs-gallery-item:hover .vs-gallery-caption{opacity:1}
<?php endif; ?>
<?php endif; ?>

/* ── WHY CHOOSE US ───────────────────────────────── */
<?php if ( $_sec_show('why') ): ?>
.vs-why-grid{
  display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
  row-gap:<?php echo $cv_why_row_gap; ?>px;column-gap:<?php echo $cv_why_col_gap; ?>px;
}
@media(max-width:500px){.vs-why-grid{grid-template-columns:repeat(2,1fr)}}

/* Why card — redesigned to match reference: white card, bottom accent bar */
.vs-why-card{
  background:#fff;
  border:1px solid #E8EFF6;
  border-radius:20px;
  padding:<?php echo $cv_why_box_padding; ?>px;
  margin:<?php echo $cv_why_box_margin; ?>px;
  text-align:<?php echo $cv_why_title_align; ?>;
  transition:transform .25s,box-shadow .25s,border-color .25s;
  position:relative;overflow:hidden;
  box-shadow:0 2px 12px rgba(0,0,0,.05);
  display:flex;
  flex-direction:<?php echo $cv_why_icon_position === 'left' ? 'row' : ( $cv_why_icon_position === 'right' ? 'row-reverse' : ( $cv_why_icon_position === 'bottom' ? 'column-reverse' : 'column' ) ); ?>;
  align-items:<?php echo in_array($cv_why_icon_position, ['left','right'], true) ? 'center' : ( $cv_why_title_align === 'left' ? 'flex-start' : ( $cv_why_title_align === 'right' ? 'flex-end' : 'center' ) ); ?>;
  gap:<?php echo $cv_why_gap; ?>px;
}
<?php if ($cv_why_icon_position === 'center'): ?>
/* Real fix: "Center" places the icon between title and description via order */
.vs-why-card .vs-why-title{order:1}
.vs-why-card .vs-why-icon-wrap{order:2}
.vs-why-card .vs-why-desc{order:3}
<?php endif; ?>
/* Bottom accent bar — matches the reference design's colored underline */
.vs-why-card::before{
  content:'';position:absolute;bottom:0;left:0;right:0;height:4px;
  background:linear-gradient(90deg,var(--vs-primary),var(--vs-yellow,#F59E0B));
  transform:scaleX(0);transform-origin:left;
  transition:transform .35s cubic-bezier(.4,0,.2,1);
}
/* Subtle background shimmer on hover */
.vs-why-card::after{
  content:'';position:absolute;inset:0;
  background:linear-gradient(135deg,rgba(37,99,235,.02) 0%,rgba(245,166,35,.02) 100%);
  opacity:0;transition:opacity .25s;pointer-events:none;
}
.vs-why-card:hover{
  transform:translateY(-5px);
  box-shadow:0 16px 40px rgba(0,0,0,.11);
  border-color:#CBD5E1;
}
.vs-why-card:hover::before{transform:scaleX(1)}
.vs-why-card:hover::after{opacity:1}

/* Icon wrap — softer gradient, larger emoji */
.vs-why-icon-wrap{
  width:<?php echo $cv_why_icon_width > 0 ? $cv_why_icon_width.'px' : 'var(--vs-why-icon-size,72px)'; ?>;
  height:var(--vs-why-icon-size,72px);border-radius:var(--vs-why-icon-radius,20px);
  background:<?php echo $cv_why_icon_bg ? 'var(--vs-why-icon-bg-custom)' : 'linear-gradient(145deg,#F0F7FF,#DBEAFE)'; ?>;
  <?php if ($cv_why_icon_bg): ?>--vs-why-icon-bg-custom:<?php echo esc_attr($cv_why_icon_bg); ?>;opacity:<?php echo $cv_why_icon_bg_opacity; ?>;<?php endif; ?>
  border:<?php echo $cv_why_icon_border_w; ?>px <?php echo esc_attr($cv_why_icon_border_style); ?> <?php echo $cv_why_icon_border ? esc_attr($cv_why_icon_border) : 'rgba(37,99,235,.1)'; ?>;
  display:flex;align-items:center;justify-content:center;
  padding:<?php echo $cv_why_icon_padding; ?>px;
  <?php
    // Real fix: margin-bottom on a flex child within a row layout
    // (align-items:center) shifts that child's vertical center, which
    // visually looks like unwanted margin on other sides. Apply the
    // margin in the direction that actually matches "space after the
    // icon" for the current layout instead of always using bottom.
    if ($cv_why_icon_position === 'left') {
        echo 'margin-right:'.$cv_why_icon_margin.'px;';
    } elseif ($cv_why_icon_position === 'right') {
        echo 'margin-left:'.$cv_why_icon_margin.'px;';
    } else {
        echo 'margin-bottom:'.$cv_why_icon_margin.'px;';
    }
  ?>
  flex-shrink:0;
  font-size:calc(var(--vs-why-icon-size,72px) * 0.29);line-height:1;
  transform:rotate(<?php echo $cv_why_icon_rotation; ?>deg);
  opacity:<?php echo $cv_why_icon_opacity; ?>;
  box-shadow:<?php echo $shadow_map[$cv_why_icon_shadow] ?? $shadow_map['md']; ?>;
}
.vs-why-icon-wrap img{width:70%;height:70%;object-fit:<?php echo esc_attr($cv_why_icon_fit); ?>}

<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'why_title', '.vs-why-title', [ 'font_size' => 16, 'font_weight' => '800', 'color' => '#2563EB', 'line_height' => '1.35' ] ); ?>
.vs-why-title{
  margin-bottom:<?php echo $cv_why_title_margin; ?>px;
  text-align:<?php echo $cv_why_title_align; ?>;width:100%;
  padding:<?php echo $cv_why_title_padding; ?>px;
}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'why_desc', '.vs-why-desc', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.72' ] ); ?>
.vs-why-desc{
  text-align:<?php echo $cv_why_desc_align; ?>;
  margin:<?php echo $cv_why_desc_margin; ?>px 0 0;width:100%;
  padding:<?php echo $cv_why_desc_padding; ?>px;
}
/* Legacy selector kept for backward compat */
.vs-why-icon{font-size:2rem;display:none}
<?php endif; ?>

/* ── REVIEWS ─────────────────────────────────────── */
<?php if ( $_sec_show('reviews') ): ?>
/* ══ REVIEWS — premium redesign ══════════════════════════════════ */
.vs-reviews-header{display:flex;align-items:center;gap:32px;margin-bottom:32px;flex-wrap:wrap}
/* Rating summary widget */
.vs-rev-header{
  display:flex;align-items:center;gap:40px;margin-bottom:44px;
  background:linear-gradient(135deg,#F8FAFF 0%,#fff 100%);
  border:1.5px solid #E2E8F0;border-radius:22px;
  padding:32px 36px;box-shadow:0 4px 24px rgba(0,0,0,.06);
}
@media(max-width:640px){.vs-rev-header{flex-direction:column;gap:24px;padding:22px 20px}}
.vs-rev-summary{text-align:center;min-width:110px;flex-shrink:0}
.vs-rev-big-score{
  font-size:4rem;font-weight:900;color:#1E293B;line-height:1;
  letter-spacing:-.04em;font-variant-numeric:tabular-nums;
}
.vs-rev-big-stars{font-size:1.6rem;margin:8px 0 6px;letter-spacing:2px}
.vs-rev-count{font-size:.82rem;color:#64748B;font-weight:700;text-transform:uppercase;letter-spacing:.05em}
.vs-rev-bars{flex:1;display:flex;flex-direction:column;gap:8px}
.vs-rev-bar-row{display:flex;align-items:center;gap:10px}
.vs-rev-bar-lbl{font-size:.78rem;color:#475569;width:30px;text-align:right;flex-shrink:0;font-weight:600}
.vs-rev-bar-track{flex:1;height:10px;background:#F1F5F9;border-radius:99px;overflow:hidden}
.vs-rev-bar-fill{height:100%;background:linear-gradient(90deg,#F59E0B,#FBBF24);border-radius:99px;transition:width .6s cubic-bezier(.4,0,.2,1)}
.vs-rev-bar-cnt{font-size:.74rem;color:#647388;width:20px;flex-shrink:0;text-align:right}
/* Review cards grid */
.vs-reviews-carousel-wrap{position:relative;overflow:hidden;width:100%;padding-bottom:8px}
.vs-reviews-carousel-track{display:flex;gap:20px;animation:vs-rev-scroll 35s linear infinite;width:max-content;will-change:transform}
.vs-reviews-carousel-wrap:hover .vs-reviews-carousel-track{animation-play-state:paused}
@keyframes vs-rev-scroll{from{transform:translateX(0)}to{transform:translateX(-50%)}}
.vs-review-card{background:<?php echo esc_attr($cv_reviews_card_bg); ?>;border:1.5px solid <?php echo esc_attr($cv_reviews_card_bc); ?>;border-radius:16px;padding:22px;width:320px;flex-shrink:0;transition:box-shadow .2s;box-shadow:0 1px 4px rgba(0,0,0,.04)}
@media(max-width:600px){.vs-review-card{width:280px}}
.vs-review-card:hover{box-shadow:0 4px 16px rgba(0,0,0,.1);border-color:#C8D5E8}
  background:#fff;border:1.5px solid #E8EFF6;border-radius:18px;
  padding:22px;display:flex;flex-direction:column;
  transition:box-shadow .2s,transform .2s,border-color .2s;
  box-shadow:0 2px 8px rgba(0,0,0,.05);position:relative;
}
.vs-review-card:hover{box-shadow:0 8px 28px rgba(0,0,0,.1);transform:translateY(-3px);border-color:#C8D5E8}
.vs-review-head{display:flex;align-items:flex-start;gap:13px;margin-bottom:14px}
.vs-review-avatar{
  width:46px;height:46px;border-radius:50%;
  color:#fff;display:flex;align-items:center;justify-content:center;
  font-weight:800;font-size:1.1rem;flex-shrink:0;
  box-shadow:0 2px 8px rgba(0,0,0,.15);
}
.vs-review-name{font-weight:800;color:#1E293B;font-size:.92rem;line-height:1.2}
.vs-review-date{font-size:.73rem;color:#647388;margin-top:3px;font-weight:500}
.vs-review-stars{letter-spacing:1px;margin-top:3px;font-size:.9rem}
.vs-review-text{
  font-size:.85rem;color:#475569;line-height:1.75;
  border-top:1px solid #F1F5F9;padding-top:13px;margin-top:4px;flex:1;
}
.vs-review-helpful{
  display:inline-flex;align-items:center;gap:5px;
  font-size:.74rem;color:#647388;
  background:#F8FAFC;border:1px solid #E2E8F0;
  border-radius:99px;padding:4px 12px;cursor:pointer;
  margin-top:12px;transition:all .15s;font-family:inherit;
  align-self:flex-start;
}
.vs-review-helpful:hover{background:#EFF6FF;color:#2563EB;border-color:#93C5FD}
/* Review form */
.vs-review-form-wrap{margin-top:44px;text-align:center}
.vs-review-form-toggle{
  display:inline-flex;align-items:center;gap:9px;
  padding:13px 32px;background:var(--vs-dark,#1E3A5F);color:#fff;
  border:none;border-radius:12px;font-size:.92rem;font-weight:700;
  cursor:pointer;transition:all .2s;font-family:inherit;
  box-shadow:0 4px 16px rgba(30,58,95,.25);
}
.vs-review-form-toggle:hover{filter:brightness(1.12);transform:translateY(-2px);box-shadow:0 8px 24px rgba(30,58,95,.3)}
.vs-review-form-box{
  max-width:660px;margin:24px auto 0;
  background:#fff;border:1.5px solid #E2E8F0;border-radius:22px;
  padding:36px;box-shadow:0 8px 40px rgba(0,0,0,.08);text-align:left;
}
.vs-review-form-title{font-size:1.15rem;font-weight:800;color:#1E293B;margin-bottom:6px;text-align:center}
.vs-review-form-sub{font-size:.84rem;color:#64748B;text-align:center;margin-bottom:24px}
.vs-review-stars-pick{display:flex;justify-content:center;gap:10px;margin-bottom:6px}
.vs-star-pick{
  font-size:2.8rem;color:#E2E8F0;cursor:pointer;
  transition:color .12s,transform .15s;display:inline-block;line-height:1;
}
.vs-star-pick.lit{color:#F59E0B}
.vs-star-pick:hover{transform:scale(1.25)}
.vs-review-star-hint{text-align:center;font-size:.82rem;color:#647388;margin-bottom:22px;font-weight:600;min-height:20px}
.vs-review-form-fields{display:flex;flex-direction:column;gap:13px;margin-bottom:18px}
.vs-review-input-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
@media(max-width:480px){.vs-review-input-grid{grid-template-columns:1fr}}
.vs-review-field-label{display:block;font-size:.74rem;font-weight:700;color:#475569;margin-bottom:4px;text-transform:uppercase;letter-spacing:.06em}
.vs-review-submit-btn{
  width:100%;padding:14px 20px;
  background:linear-gradient(135deg,var(--vs-primary,#2563EB),#1D4ED8);
  color:#fff;border:none;border-radius:12px;font-size:.95rem;font-weight:800;
  cursor:pointer;transition:all .2s;font-family:inherit;letter-spacing:.02em;
  box-shadow:0 4px 16px rgba(37,99,235,.3);
}
.vs-review-submit-btn:hover{filter:brightness(1.1);transform:translateY(-2px);box-shadow:0 8px 24px rgba(37,99,235,.4)}
.vs-review-submit-btn:disabled{opacity:.7;transform:none;cursor:not-allowed}
.vs-review-big{font-size:3.5rem;font-weight:900;color:var(--vs-dark);line-height:1}
.vs-review-stars-row{color:#F59E0B;font-size:1.2rem;margin-bottom:4px}
.vs-reviews-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:var(--vs-reviews-gap,18px)}
@media(max-width:760px){.vs-reviews-grid{grid-template-columns:1fr}}
.vs-review-card{background:<?php echo esc_attr($cv_reviews_card_bg); ?>;border:1.5px solid <?php echo esc_attr($cv_reviews_card_bc); ?>;border-radius:16px;padding:22px}
.vs-review-head{display:flex;align-items:center;gap:12px;margin-bottom:12px}
.vs-review-av{width:44px;height:44px;border-radius:50%;background:var(--vs-primary);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1rem;flex-shrink:0}
.vs-review-name{font-weight:700;color:var(--vs-dark);font-size:.88rem}
.vs-review-date{font-size:.75rem;color:#647388}
.vs-review-stars{color:#F59E0B;font-size:.95rem;margin-bottom:9px}
.vs-review-text{font-size:.85rem;color:#475569;line-height:1.7}
<?php endif; ?>

/* ── FAQ ──────────────────────────────────────────── */
<?php if ( $_sec_show('faq') ): ?>
.vs-faq-list{max-width:780px}
.vs-faq-list{max-width:820px;margin:0 auto}
.vs-faq-item{border:1.5px solid #E2E8F0;border-radius:12px;margin-bottom:10px;overflow:hidden;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.04)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'faq_q', '.vs-faq-q', [ 'font_size' => 15, 'font_weight' => '700', 'color' => '#1E293B' ] ); ?>
.vs-faq-q{padding:18px 22px;cursor:pointer;display:flex;justify-content:space-between;align-items:center;background:#fff;transition:background .15s;user-select:none}
.vs-faq-item.on .vs-faq-q{background:#F8FAFF;color:var(--vs-primary)}
.vs-faq-q .vs-faq-arr{transition:transform .25s ease;flex-shrink:0;margin-left:12px;font-size:1.1rem;color:#647388;display:inline-block}
.vs-faq-item.on .vs-faq-arr{transform:rotate(180deg);color:var(--vs-primary)}
.vs-faq-arrow{transition:transform .25s ease;flex-shrink:0;margin-left:12px;font-size:1rem;color:#647388;display:inline-block}
.vs-faq-item.on .vs-faq-arrow{transform:rotate(180deg);color:var(--vs-primary)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'faq_a', '.vs-faq-a', [ 'font_size' => 14, 'font_weight' => '400', 'color' => '#475569', 'line_height' => '1.75' ] ); ?>
.vs-faq-a{max-height:0;overflow:hidden;transition:max-height .32s ease,padding .22s ease;padding:0 22px;background:#F8FAFF}
.vs-faq-item.on .vs-faq-a{max-height:800px;padding:16px 22px 20px;border-top:1px solid #E2E8F0}
<?php endif; ?>

/* ── QUESTIONS & ANSWERS ──────────────────────────────
 * Real feature: this section previously had zero CSS-level config of its
 * own — it reused .vs-faq-* classes with hardcoded colors and no
 * background var, because it was never wired into the section-config
 * system at all. Gated behind $_sec_show('questions') like every other
 * section; --vs-questions-bg falls back to --vs-dark exactly like
 * footer_bg / faq_bg do, so a vendor who never touches the new color
 * field sees the same look as before this fix. */
<?php if ( $_sec_show('questions') ): ?>
#vs-sec-questions{background:var(--vs-questions-bg, transparent)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'questions_heading', '#vs-sec-questions .vs-sec-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] ); ?>
<?php endif; ?>

/* ── CONTACT (v9 redesign — clean, professional, monochrome) ──── */
<?php if ( $_sec_show('contact') ): ?>
/* Contact section background */
.vs-section-contact-new{background:#F8FAFC}

/* Two-column grid */
.vs-contact-new-grid{
  display:grid;
  grid-template-columns:1fr 1.15fr;
  gap:40px;
  align-items:start;
}
@media(max-width:760px){
  .vs-contact-new-grid{grid-template-columns:1fr;gap:28px}
}

/* Left panel: details list */
.vs-contact-details-panel{
  background:#fff;
  border:1px solid #E5E7EB;
  border-radius:16px;
  overflow:hidden;
  box-shadow:0 2px 16px rgba(0,0,0,.06);
}
.vs-contact-details-list{
  display:flex;
  flex-direction:column;
  padding:8px 24px 16px;
}

/* Individual detail row — replaces old vs-contact-info-item */
.vs-cd-row{
  display:flex;
  align-items:center;
  gap:14px;
  padding:14px 0;
  border-bottom:1px solid #EAEEF3;
}
.vs-cd-row:last-of-type{border-bottom:none}
.vs-cd-row-top{align-items:flex-start}
.vs-cd-ico{
  width:36px;height:36px;flex-shrink:0;
  border:1px solid #E2E8F0;
  border-radius:8px;
  background:#fff;
  display:flex;align-items:center;justify-content:center;
  color:#475569;
}
.vs-cd-lbl{
  font-size:.68rem;font-weight:700;color:#647388;
  text-transform:uppercase;letter-spacing:.08em;margin-bottom:3px;
}
.vs-cd-val{
  font-size:.9rem;font-weight:600;color:#1E293B;
  text-decoration:none;word-break:break-word;
  transition:color .15s;
}
a.vs-cd-val:hover{color:#1E3A5F;text-decoration:underline}

/* Contact hours block */
.vs-contact-hours{
  padding:14px 0;
  border-bottom:1px solid #EAEEF3;
}

/* Map */
.vs-map-wrap{margin-top:16px;border-radius:12px;overflow:hidden;border:1px solid #E2E8F0}
.vs-map-wrap iframe{display:block;width:100%;height:200px;border:0}

/* Right panel: form card */
.vs-contact-form-panel{}
/* ── Fluent Form scoped inside our card ── */
.vs-fluent-form-wrap .ff-el-form-check-label{cursor:pointer}
.vs-fluent-form-wrap input,.vs-fluent-form-wrap textarea,.vs-fluent-form-wrap select{font-family:inherit}
.vs-fluent-form-wrap .ff-btn-submit{background:<?php echo esc_attr( $cv_inq_btn_bg ?: 'var(--vs-dark,#1E3A5F)' ); ?>!important;color:<?php echo esc_attr( $cv_inq_btn_text ?: '#fff' ); ?>!important;border-radius:8px!important;font-family:inherit!important;font-weight:700!important;padding:12px 24px!important;width:100%;border:none!important;cursor:pointer!important;font-size:.92rem!important}
.vs-fluent-form-wrap .ff-btn-submit:hover{filter:brightness(1.1)!important}
.vs-contact-form-card{
  background:<?php echo esc_attr( $cv_inq_form_bg ?: '#fff' ); ?>;
  border:<?php echo (int) $cv_inq_form_border_width; ?>px solid <?php echo esc_attr( $cv_inq_form_border_color ?: '#E5E7EB' ); ?>;
  border-radius:<?php echo esc_attr( $cv_inq_form_radius !== '' ? $cv_inq_form_radius . 'px' : '16px' ); ?>;
  overflow:hidden;
  box-shadow:0 2px 16px rgba(0,0,0,.06);
}
<?php if ( $cv_inq_sec_bg ): ?>.vs-contact-form-panel{background:<?php echo esc_attr($cv_inq_sec_bg); ?>}<?php endif; ?>
.vs-contact-form-hdr{
  background:<?php echo esc_attr( $cv_inq_heading_color ?: '#1E3A5F' ); ?>;
  padding:24px 28px 20px;
}
.vs-contact-form-hdr-title{
  font-size:1.1rem;font-weight:800;color:var(--vs-inq-heading-text-color,#fff);margin-bottom:4px;
}
.vs-contact-form-hdr-sub{
  font-size:.82rem;color:var(--vs-inq-heading-text-color,#fff);opacity:.7;
}

/* Input fields */
.vs-input{
  width:100%;padding:11px 14px;
  border:<?php echo esc_attr($cv_inq_input_border_w); ?>px solid <?php echo esc_attr( $cv_inq_input_border ?: '#E5E7EB' ); ?>;border-radius:8px;
  font-size:<?php echo $cv_inq_input_size; ?>px;font-weight:<?php echo esc_attr($cv_inq_input_weight); ?>;color:<?php echo esc_attr( $cv_inq_input_text ?: '#1E293B' ); ?>;outline:none;background:<?php echo esc_attr( $cv_inq_input_bg ?: '#fff' ); ?>;
  font-family:<?php echo esc_attr($cv_inq_input_font_stack); ?>;box-sizing:border-box;
  letter-spacing:<?php echo $cv_inq_input_ls; ?>em;line-height:<?php echo $cv_inq_input_lh; ?>;
  transition:border-color .15s;
}
.vs-input:focus{border-color:#1E3A5F;box-shadow:0 0 0 3px rgba(30,58,95,.08)}
.vs-input::placeholder{color:#9CA3AF}
.vs-textarea{resize:vertical;min-height:90px}

/* Backwards compat: old classes that may still appear */
.vs-contact-wrap{display:block}
.vs-contact-info-item{display:flex;align-items:flex-start;gap:14px;margin-bottom:16px}
.vs-contact-icon{width:36px;height:36px;border-radius:8px;background:#F1F5F9;color:#475569;display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0}
.vs-contact-lbl{font-size:.68rem;font-weight:700;color:#647388;text-transform:uppercase;letter-spacing:.08em}
.vs-contact-val{font-size:.9rem;color:#1E293B;font-weight:600;margin-top:2px}
<?php endif; ?>

/* ── FEEDBACK ────────────────────────────────────── */
.vs-feedback-wrap{max-width:560px;margin:0 auto;text-align:center}
.vs-stars-row{display:flex;justify-content:center;gap:8px;margin:20px 0}
.vs-star-btn{font-size:2rem;cursor:pointer;color:#D1D5DB;transition:color .15s}
.vs-star-btn.lit,.vs-star-btn:hover~.vs-star-btn,.vs-stars-row:hover .vs-star-btn{color:#F59E0B}
.vs-stars-row:hover .vs-star-btn:hover~.vs-star-btn{color:#D1D5DB}
.vs-feedback-form{background:#fff;border:1.5px solid #E2E8F0;border-radius:16px;padding:28px;margin-top:16px;text-align:left}

/* ── FOOTER ──────────────────────────────────────── */
.vs-footer{background:var(--vs-footer-bg, var(--vs-dark));color:rgba(255,255,255,.75);padding:48px 0 20px}
/* FIX: ensure footer is never covered by fixed bottom bars or floating buttons */
@media(max-width:768px){
  /* On mobile, .vs-mobile-cta-bar is position:fixed;bottom:0 (~66px tall).
     Add matching padding-bottom so the last footer row is never hidden behind it. */
  .vs-footer{padding-bottom:calc(80px + env(safe-area-inset-bottom,0))}
}
@media(min-width:769px){
  /* On desktop, .vs-float-wa (bottom:28px right) and .vs-float-call (bottom:28px left)
     sit over the footer corners. Push the footer-bottom row up enough to clear them. */
  .vs-footer-bottom{padding-bottom:calc(28px + 52px)}
}
.vs-footer-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1.4fr;gap:32px;margin-bottom:40px}
@media(max-width:840px){.vs-footer-grid{grid-template-columns:1fr 1fr;gap:28px 24px}}
<?php
/* Real fix — mobile footer overhaul: below 840px this used to collapse
   straight to a single, full-width column at 500px, producing a long,
   sparse, unbalanced stack on real phone widths (one narrow column of
   short link lists with the rest of the viewport empty on either side) —
   not the "clean, balanced, professional" look expected of an enterprise
   footer. Below 640px the grid now stays genuinely 2-column: the Brand
   column (logo + about text + social icons — the block with the most
   content) spans the full width on its own row, while Services / Quick
   Links / Contact+Newsletter pair up 2-across beneath it, matching how a
   real responsive footer actually compacts on a phone rather than just
   stacking everything vertically. Only below 380px (a genuinely tiny
   screen where even 2-up link columns get cramped once a label wraps to
   2 lines) does it drop to a single column — still tightened, not the
   old sparse full-bleed stack. */
?>
@media(max-width:640px){
  .vs-footer{padding-top:36px}
  .vs-footer-grid{grid-template-columns:1fr 1fr;gap:26px 20px;margin-bottom:28px}
  .vs-footer-brand{grid-column:1 / -1}
}
@media(max-width:380px){
  .vs-footer-grid{grid-template-columns:1fr;gap:24px}
  .vs-footer-brand{grid-column:auto}
}
.vs-footer-brand img{height:44px;margin-bottom:14px;border-radius:8px}
.vs-footer-brand-init{height:44px;width:100px;background:rgba(255,255,255,.1);border-radius:8px;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;font-size:1rem;margin-bottom:14px}
.vs-footer-about{font-size:.85rem;line-height:1.75;max-width:260px}
<?php // On mobile the Brand column spans the full grid width (above), so the
      // narrow-column max-width no longer applies — letting About Text use
      // the full available width instead of wrapping needlessly narrow. ?>
@media(max-width:640px){.vs-footer-about{max-width:none}}
.vs-footer-about p{margin:0 0 .6em}
.vs-footer-about p:last-child{margin-bottom:0}
.vs-footer-about ul,.vs-footer-about ol{margin:.4em 0 .6em;padding-left:1.2em}
.vs-footer-about a{color:var(--vs-yellow);text-decoration:underline}
.vs-footer-social{display:flex;gap:10px;margin-top:18px;flex-wrap:wrap}
.vs-footer-social a{width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;font-size:.9rem;color:#fff;transition:background .2s,box-shadow .2s}
/* Same fix as .vs-footer-links li a:hover above — background:var(--vs-primary)
   alone could visually merge into the footer if a vendor's --vs-primary is
   close to their chosen --vs-footer-bg. A white outline ring stays visible
   as a shape change regardless of color match. */
.vs-footer-social a:hover{background:var(--vs-primary);box-shadow:0 0 0 2px rgba(255,255,255,.4)}
.vs-footer-col-title{font-size:.8rem;font-weight:800;text-transform:uppercase;letter-spacing:.08em;color:#fff;margin-bottom:16px}
@media(max-width:640px){.vs-footer-col-title{font-size:.74rem;margin-bottom:10px}}
.vs-footer-links{list-style:none;display:flex;flex-direction:column;gap:9px}
@media(max-width:640px){.vs-footer-links{gap:8px}}
.vs-footer-links li a{font-size:.83rem;color:rgba(255,255,255,.65);transition:color .2s,text-decoration-color .2s;line-height:1.4;word-break:break-word}
/* Real bug fix (v7.475.8): hover used var(--vs-yellow) — a fixed color
   that looks fine against the default dark footer, but --vs-footer-bg is
   vendor-customizable (see $cv_footer_bg above), so a vendor who picks a
   footer background close to --vs-yellow (or sets --vs-primary/--vs-dark
   to something close to it) gets the exact same "hover color invisible
   against its own background" bug the platform footer had before
   v7.471.0 — just per-vendor instead of platform-wide, so it wasn't
   caught by that fix. Solid white + underline is visible against ANY
   footer background regardless of a vendor's chosen brand colors, since
   it's always a bigger jump from the base rgba(255,255,255,.65) than any
   single-hue color swap could guarantee. */
.vs-footer-links li a:hover{color:#fff;text-decoration:underline}
.vs-footer-nl{display:flex;margin-top:14px;border-radius:9px;overflow:hidden}
<?php // Real fix: a flex child with no min-width default (min-width:auto)
      // refuses to shrink below its content's natural width — on a narrow
      // phone viewport this pushed the Subscribe button out of the visible
      // column instead of letting the email input actually shrink. ?>
.vs-footer-nl input{flex:1;min-width:0;padding:10px 14px;border:none;background:#fff;font-size:.84rem;outline:none;font-family:inherit}
.vs-footer-nl button{background:var(--vs-yellow);color:#fff;border:none;padding:10px 16px;font-weight:700;font-size:.82rem;cursor:pointer;font-family:inherit;flex-shrink:0}
.vs-footer-bottom{border-top:1px solid rgba(255,255,255,.1);padding-top:20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;font-size:.78rem}
@media(max-width:640px){.vs-footer-bottom{justify-content:center;text-align:center;gap:12px;padding-top:18px}}
<?php
// Real feature — independent typography for each footer content field.
// Footer isn't a toggleable $_sec_show() section (always rendered), so no
// visibility gate is needed here — just the same css_rule() call every
// other typography-enabled field on the site already uses. Each of these
// three prefixes is fully independent, so a vendor can shrink just the
// About Text's line height (the specific complaint) without touching
// Service Links or Quick Links, or vice versa.
//
// Note: 'color' is deliberately left out of every defaults array below.
// TypographyService::resolve() only accepts a strict 6-digit #hex (it
// validates with a regex) and silently falls back otherwise — the
// footer's actual default colors are semi-transparent whites
// (rgba(255,255,255,.75) / .65), which the engine cannot represent as a
// default. Omitting 'color' here means css_rule() emits no color
// declaration at all when the vendor hasn't picked one, so the existing
// static CSS color rules below (.vs-footer-links li a, and inheritance
// from .vs-footer for About Text) remain the visual default — a vendor
// can still override with a real hex color via the typography panel's
// own color picker (the standard _color field every prefix already has).
echo \GoodService\Service\TypographyService::css_rule( $cd, 'footer_about', '.vs-footer-about', [ 'font_size' => 14, 'font_weight' => '400', 'line_height' => '1.75' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'footer_service_links', '.vs-footer-links--services li a', [ 'font_size' => 13, 'font_weight' => '400', 'line_height' => '1.4' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'footer_quick_links', '.vs-footer-links--quicklinks li a', [ 'font_size' => 13, 'font_weight' => '400', 'line_height' => '1.4' ] );
?>

/* ── TEAM ────────────────────────────────────────── */
<?php if ( $_sec_show('team') ): ?>
.vs-team-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:var(--vs-team-gap,20px)}
<?php
$cv_team_card_bg = $cd['team_card_bg']           ?? '#ffffff';
$cv_team_card_bc = $cd['team_card_border_color'] ?? '#E2E8F0';
?>
.vs-team-card{background:<?php echo esc_attr($cv_team_card_bg); ?>;border:1.5px solid <?php echo esc_attr($cv_team_card_bc); ?>;border-radius:16px;overflow:hidden;text-align:center;transition:.22s;box-shadow:0 2px 8px rgba(0,0,0,.05)}
.vs-team-card:hover{box-shadow:0 10px 30px rgba(0,0,0,.1);transform:translateY(-4px);border-color:var(--vs-primary)}
.vs-team-photo{width:100%;aspect-ratio:1/1;object-fit:cover;display:block;background:#F1F5F9}
.vs-team-photo-placeholder{width:100%;aspect-ratio:1/1;background:linear-gradient(135deg,var(--vs-primary),var(--vs-dark));display:flex;align-items:center;justify-content:center;font-size:2.2rem;font-weight:900;color:rgba(255,255,255,.85)}
.vs-team-body{padding:16px 14px 18px}
.vs-team-name{font-weight:800;font-size:.92rem;color:var(--vs-dark);margin-bottom:3px}
.vs-team-role{font-size:.78rem;color:var(--vs-primary);font-weight:700;margin-bottom:5px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'team_bio', '.vs-team-bio', [ 'font_size' => 12, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.6' ] ); ?>
.vs-team-bio{margin-bottom:10px}
.vs-team-socials{display:flex;justify-content:center;gap:10px}
.vs-team-social-link{width:36px;height:36px;border-radius:50%;background:#F1F5F9;display:flex;align-items:center;justify-content:center;font-size:.7rem;color:#475569;transition:.15s;text-decoration:none}
.vs-team-social-link:hover{background:var(--vs-primary);color:#fff}
<?php endif; ?>

/* ── CLIENTS / TRUSTED BY ────────────────────────── */
<?php if ( $_sec_show('clients') ): ?>
.vs-clients-grid{
  display:flex;flex-wrap:wrap;align-items:center;
  justify-content:<?php echo $cv_client_align === 'left' ? 'flex-start' : ( $cv_client_align === 'right' ? 'flex-end' : 'center' ); ?>;
  row-gap:<?php echo $cv_client_row_gap; ?>px;column-gap:<?php echo $cv_client_gap; ?>px;
}
.vs-client-logo{
  height:<?php echo $cv_client_logo_height; ?>px;
  <?php echo $cv_client_logo_width > 0 ? 'max-width:'.$cv_client_logo_width.'px;' : ''; ?>
  object-fit:contain;
  <?php echo $cv_client_grayscale ? 'filter:grayscale(1);' : ''; ?>
  opacity:<?php echo $cv_client_opacity; ?>;
  padding:<?php echo $cv_client_box_padding; ?>px;margin:<?php echo $cv_client_box_margin; ?>px;
  transition:.25s;display:block;
}
<?php if ($cv_client_hover_fx): ?>
.vs-client-logo:hover{<?php echo $cv_client_grayscale ? 'filter:grayscale(0);' : ''; ?>opacity:1;transform:scale(1.06)}
<?php endif; ?>
.vs-clients-text-item{background:#F8FAFC;border:1.5px solid #E2E8F0;border-radius:10px;padding:10px 18px;font-size:.84rem;font-weight:700;color:#475569;transition:.2s}
.vs-clients-text-item:hover{border-color:var(--vs-primary);color:var(--vs-primary);background:#EFF6FF}
<?php endif; ?>

/* ── PRICING TABLE ───────────────────────────────── */
<?php if ( $_sec_show('pricing') ): ?>
.vs-pricing-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:var(--vs-pricing-gap,20px);align-items:stretch}
.vs-pricing-card{background:#fff;border:2px solid #E2E8F0;border-radius:18px;padding:28px;display:flex;flex-direction:column;position:relative;transition:.2s;box-shadow:0 2px 8px rgba(0,0,0,.04)}
.vs-pricing-card.featured{border-color:var(--vs-primary);box-shadow:0 12px 40px rgba(0,0,0,.12);transform:scale(1.02)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'pricing_badge', '.vs-pricing-badge', [ 'font_size' => 10, 'font_weight' => '800', 'color' => '#ffffff', 'text_transform' => 'uppercase', 'letter_spacing' => '0.05' ] ); ?>
.vs-pricing-badge{position:absolute;top:-13px;left:50%;transform:translateX(-50%);background:var(--vs-primary);padding:4px 16px;border-radius:20px;white-space:nowrap}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'pricing_heading', '.vs-pricing-title', [ 'font_size' => 28, 'font_weight' => '800', 'color' => '#1E293B' ] ); ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'pricing_name', '.vs-pricing-name', [ 'font_size' => 16, 'font_weight' => '800', 'color' => '#1E293B' ] ); ?>
.vs-pricing-name{margin-bottom:6px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'pricing_price', '.vs-pricing-price', [ 'font_size' => 32, 'font_weight' => '900', 'color' => '#2563EB', 'line_height' => '1' ] ); ?>
.vs-pricing-price{margin-bottom:4px}
.vs-pricing-price span{font-size:.85rem;font-weight:600;color:#647388}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'pricing_desc', '.vs-pricing-desc', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.6' ] ); ?>
.vs-pricing-desc{margin-bottom:18px}
.vs-pricing-features{flex:1;display:flex;flex-direction:column;gap:9px;margin-bottom:22px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'pricing_features', '.vs-pricing-feat', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#334155' ] ); ?>
.vs-pricing-feat{display:flex;align-items:flex-start;gap:8px}
.vs-pricing-feat-ico{width:18px;height:18px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:.62rem;font-weight:800;margin-top:1px}
.vs-pricing-feat-ico.yes{background:#DCFCE7;color:#166534}
.vs-pricing-feat-ico.no{background:#F1F5F9;color:#647388}
.vs-pricing-feat.no-feat{color:#647388}
.vs-pricing-cta{display:block;text-align:center;padding:12px 20px;border-radius:10px;font-size:.88rem;font-weight:700;cursor:pointer;border:none;font-family:inherit;transition:.18s}
.vs-pricing-card.featured .vs-pricing-cta{background:var(--vs-primary);color:#fff}
.vs-pricing-card.featured .vs-pricing-cta:hover{filter:brightness(1.1)}
.vs-pricing-card:not(.featured) .vs-pricing-cta{background:#F1F5F9;color:var(--vs-dark);border:1.5px solid #E2E8F0}
.vs-pricing-card:not(.featured) .vs-pricing-cta:hover{background:#E2E8F0}
<?php endif; ?>

/* ── Packages & Pricing — dedicated card layout (does not share classes
   with .vs-pricing-* above, deliberately, so Pricing Table and Membership
   Plans — which reuse .vs-pricing-* — cannot regress from this redesign) ── */
<?php if ( $_sec_show('packages') ): ?>
.vs-pkg-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:var(--vs-pkg-gap,20px)}
@media(max-width:900px){.vs-pkg-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:560px){.vs-pkg-grid{grid-template-columns:1fr;gap:var(--vs-pkg-gap-mobile,14px)}}
.vs-pkg-card{background:#fff;border:1px solid #E7E7E9;border-radius:16px;overflow:hidden;transition:.2s;box-shadow:0 1px 3px rgba(0,0,0,.03);display:flex;flex-direction:column}
.vs-pkg-card:hover{box-shadow:0 10px 28px rgba(0,0,0,.09);transform:translateY(-3px);border-color:#D6D6DA}
.vs-pkg-img{width:100%;aspect-ratio:4/3;overflow:hidden;background:#F1F1F3;flex-shrink:0}
<?php endif; ?>

/* ── Facilities — dedicated photo-first showcase card ── */
<?php if ( $_sec_show('facilities') ): ?>
.vs-fac-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:var(--vs-fac-gap,22px)}
@media(max-width:900px){.vs-fac-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:560px){.vs-fac-grid{grid-template-columns:1fr}}
.vs-fac-card{background:#fff;border:1px solid #E7E7E9;border-radius:16px;overflow:hidden;transition:.25s;box-shadow:0 1px 3px rgba(0,0,0,.03)}
.vs-fac-card:hover{box-shadow:0 12px 32px rgba(0,0,0,.1);transform:translateY(-4px)}
.vs-fac-photo{width:100%;aspect-ratio:5/4;overflow:hidden;position:relative;background:linear-gradient(145deg,#F0F7FF,#DBEAFE)}
.vs-fac-photo img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s ease}
.vs-fac-card:hover .vs-fac-photo img{transform:scale(1.08)}
.vs-fac-photo-fallback{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:3rem;color:var(--vs-primary,#2563EB);opacity:.4}
.vs-fac-icon-badge{position:absolute;bottom:-18px;left:18px;width:44px;height:44px;border-radius:12px;background:#fff;box-shadow:0 4px 14px rgba(0,0,0,.15);display:flex;align-items:center;justify-content:center;font-size:1.25rem}
.vs-fac-body{padding:28px 20px 20px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'facilities_title', '.vs-fac-title', [ 'font_size' => 17, 'font_weight' => '800', 'color' => '#1E293B' ] ); ?>
.vs-fac-title{margin-bottom:8px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'facilities_desc', '.vs-fac-desc', [ 'font_size' => 14, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.6' ] ); ?>
<?php endif; ?>

/* ── Awards & Recognition — badge wall (also used by Certifications,
   which shares the same "trust mark" visual identity) ── */
<?php if ( $_sec_show('awards') || $_sec_show('certifications') ): ?>
.vs-awd-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:var(--vs-awd-gap,24px)}
.vs-awd-card{background:#fff;border:1px solid #E7E7E9;border-radius:18px;padding:30px 22px 24px;text-align:center;transition:.25s;position:relative}
.vs-awd-card:hover{box-shadow:0 14px 36px rgba(0,0,0,.1);transform:translateY(-4px);border-color:transparent}
.vs-awd-badge-ring{width:112px;height:112px;border-radius:50%;margin:0 auto 18px;display:flex;align-items:center;justify-content:center;background:conic-gradient(from 180deg,#FEF3C7,#FDE68A,#FEF3C7);padding:5px;flex-shrink:0}
.vs-awd-badge{width:100%;height:100%;border-radius:50%;overflow:hidden;background:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.08)}
.vs-awd-badge img{width:100%;height:100%;object-fit:cover}
.vs-awd-badge-emoji{font-size:2.6rem}
<?php if ( $_sec_show('awards') ): ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'awards_title', '.vs-awd-title', [ 'font_size' => 16, 'font_weight' => '800', 'color' => '#1E293B', 'line_height' => '1.35' ] ); ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'awards_desc', '.vs-awd-desc', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.55' ] ); ?>
<?php endif; ?>
<?php if ( $_sec_show('certifications') ): ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'certifications_title', '.vs-cert-title', [ 'font_size' => 16, 'font_weight' => '800', 'color' => '#1E293B', 'line_height' => '1.35' ] ); ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'certifications_desc', '.vs-cert-desc', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.55' ] ); ?>
<?php endif; ?>
.vs-awd-title,.vs-cert-title{margin-bottom:6px}
.vs-awd-meta{font-size:.8rem;font-weight:700;color:var(--vs-primary,#2563EB);margin-bottom:8px}
.vs-awd-credential{display:inline-block;font-size:.7rem;color:#475569;background:#F8FAFC;border-radius:6px;padding:3px 10px;margin-top:10px}
.vs-awd-verify{display:inline-flex;align-items:center;gap:4px;font-size:.78rem;font-weight:700;color:var(--vs-primary,#2563EB);text-decoration:none;margin-top:10px}
.vs-awd-verify:hover{text-decoration:underline}
<?php endif; ?>

/* ── Key Highlights — bold stat-tile identity ── */
<?php if ( $_sec_show('highlights') ): ?>
.vs-hl-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:var(--vs-hl-gap,18px)}
.vs-hl-card{display:flex;align-items:center;gap:16px;background:#fff;border:1px solid #E7E7E9;border-radius:16px;padding:20px;transition:.2s}
.vs-hl-card:hover{box-shadow:0 8px 24px rgba(0,0,0,.08);transform:translateY(-2px)}
.vs-hl-icon{width:60px;height:60px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.7rem;flex-shrink:0;color:#fff}
.vs-hl-icon img{width:100%;height:100%;object-fit:cover;border-radius:14px}
.vs-hl-body{flex:1;min-width:0}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'highlights_title', '.vs-hl-title', [ 'font_size' => 15, 'font_weight' => '800', 'color' => '#1E293B', 'line_height' => '1.3' ] ); ?>
.vs-hl-title{margin-bottom:3px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'highlights_desc', '.vs-hl-desc', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.5' ] ); ?>
/* Rotating accent palette — each card cycles through 6 colors for visual
   variety across a grid of highlights, rather than one flat repeated color */
.vs-hl-card:nth-child(6n+1) .vs-hl-icon{background:linear-gradient(145deg,#818CF8,#6366F1)}
.vs-hl-card:nth-child(6n+2) .vs-hl-icon{background:linear-gradient(145deg,#34D399,#10B981)}
.vs-hl-card:nth-child(6n+3) .vs-hl-icon{background:linear-gradient(145deg,#FBBF24,#F59E0B)}
.vs-hl-card:nth-child(6n+4) .vs-hl-icon{background:linear-gradient(145deg,#F472B6,#EC4899)}
.vs-hl-card:nth-child(6n+5) .vs-hl-icon{background:linear-gradient(145deg,#60A5FA,#3B82F6)}
.vs-hl-card:nth-child(6n+6) .vs-hl-icon{background:linear-gradient(145deg,#FB923C,#F97316)}
<?php endif; ?>

/* ── Features & Amenities — compact checklist grid ── */
<?php if ( $_sec_show('amenities') ): ?>
.vs-am-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:var(--vs-am-gap,14px)}
.vs-am-tile{display:flex;align-items:flex-start;gap:12px;background:#F8FAFC;border:1px solid #EEF2F6;border-radius:12px;padding:14px 16px;transition:.18s}
.vs-am-tile:hover{background:#F0FDF4;border-color:#BBF7D0}
.vs-am-check{width:32px;height:32px;border-radius:9px;background:#DCFCE7;color:#16A34A;display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0;overflow:hidden}
.vs-am-check img{width:100%;height:100%;object-fit:cover}
.vs-am-body{flex:1;min-width:0;padding-top:2px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'amenities_title', '.vs-am-title', [ 'font_size' => 14, 'font_weight' => '700', 'color' => '#1E293B', 'line_height' => '1.35' ] ); ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'amenities_desc', '.vs-am-desc', [ 'font_size' => 12, 'font_weight' => '400', 'color' => '#8E9BAA', 'line_height' => '1.45' ] ); ?>
.vs-am-desc{margin-top:2px}
<?php endif; ?>

/* ── Languages Spoken — proficiency-bar cards ── */
<?php if ( $_sec_show('languages') ): ?>
.vs-lang-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:var(--vs-lang-gap,16px)}
.vs-lang-card{background:#fff;border:1px solid #E7E7E9;border-radius:14px;padding:18px;text-align:center;transition:.18s}
.vs-lang-card:hover{box-shadow:0 8px 22px rgba(0,0,0,.07);transform:translateY(-2px)}
.vs-lang-globe{width:44px;height:44px;border-radius:50%;background:linear-gradient(145deg,#EFF6FF,#DBEAFE);display:flex;align-items:center;justify-content:center;font-size:1.3rem;margin:0 auto 10px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'languages_name', '.vs-lang-name', [ 'font_size' => 15, 'font_weight' => '800', 'color' => '#1E293B' ] ); ?>
.vs-lang-name{margin-bottom:8px}
.vs-lang-bar{display:flex;gap:4px;justify-content:center;margin-bottom:6px}
.vs-lang-seg{width:22px;height:6px;border-radius:3px;background:#E2E8F0}
.vs-lang-seg.filled{background:var(--vs-primary,#2563EB)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'languages_level', '.vs-lang-level', [ 'font_size' => 12, 'font_weight' => '700', 'color' => '#475569', 'text_transform' => 'uppercase', 'letter_spacing' => '0.03' ] ); ?>
<?php endif; ?>

/* ── Membership Plans — tier-badge identity ── */
<?php if ( $_sec_show('memberships') ): ?>
.vs-mem-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:var(--vs-mem-gap,22px);align-items:stretch}
.vs-mem-card{background:#fff;border:2px solid #E7E7E9;border-radius:18px;padding:28px 24px;display:flex;flex-direction:column;position:relative;transition:.25s}
.vs-mem-card:hover{box-shadow:0 12px 32px rgba(0,0,0,.09);transform:translateY(-4px)}
.vs-mem-card.featured{border-color:var(--vs-primary,#2563EB);box-shadow:0 8px 26px rgba(37,99,235,.15)}
.vs-mem-tier-badge{width:52px;height:52px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.4rem;margin-bottom:14px}
.vs-mem-tier-1{background:linear-gradient(145deg,#FEF3C7,#D97706);color:#78350F}
.vs-mem-tier-2{background:linear-gradient(145deg,#F1F5F9,#475569);color:#334155}
.vs-mem-tier-3{background:linear-gradient(145deg,#FEF9C3,#EAB308);color:#713F12}
.vs-mem-tier-4{background:linear-gradient(145deg,#EDE9FE,#7C3AED);color:#fff}
.vs-mem-badge{position:absolute;top:-11px;right:20px;background:var(--vs-primary,#2563EB);color:#fff;font-size:.65rem;font-weight:800;letter-spacing:.04em;text-transform:uppercase;padding:4px 12px;border-radius:20px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'memberships_name', '.vs-mem-name', [ 'font_size' => 18, 'font_weight' => '800', 'color' => '#1E293B' ] ); ?>
.vs-mem-name{margin-bottom:4px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'memberships_price', '.vs-mem-price', [ 'font_size' => 30, 'font_weight' => '900', 'color' => '#2563EB', 'line_height' => '1' ] ); ?>
.vs-mem-price{margin-bottom:2px}
.vs-mem-price span{font-size:.85rem;font-weight:600;color:#647388}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'memberships_desc', '.vs-mem-desc', [ 'font_size' => 14, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.55' ] ); ?>
.vs-mem-desc{margin:8px 0 16px}
.vs-mem-benefits{list-style:none;margin:0 0 20px;padding:0;display:flex;flex-direction:column;gap:9px;flex:1}
.vs-mem-benefits li{font-size:.86rem;color:#334155;display:flex;align-items:flex-start;gap:8px;line-height:1.45}
.vs-mem-benefits li.no-benefit{color:#B0B8C1}
.vs-mem-benefit-ico{flex-shrink:0;width:18px;height:18px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.68rem;font-weight:800;margin-top:1px}
.vs-mem-benefit-ico.yes{background:#DCFCE7;color:#16A34A}
.vs-mem-benefit-ico.no{background:#F1F5F9;color:#475569}
.vs-mem-cta{display:block;text-align:center;padding:12px 20px;border-radius:10px;background:var(--vs-primary,#2563EB);color:#fff !important;font-weight:700;font-size:.9rem;text-decoration:none;transition:.15s}
.vs-mem-cta:hover{filter:brightness(1.08)}
<?php endif; ?>

/* ── Warranty / Guarantee — trust-seal hero ── */
<?php if ( $_sec_show('warranty') ): ?>
.vs-war-banner{display:flex;align-items:center;gap:28px;background:linear-gradient(135deg,#F0FDF4,#ECFDF5);border:1.5px solid #BBF7D0;border-radius:20px;padding:32px;max-width:820px;margin:0 auto}
@media(max-width:640px){.vs-war-banner{flex-direction:column;text-align:center;padding:26px 22px}}
.vs-war-seal{width:88px;height:88px;border-radius:50%;background:#fff;box-shadow:0 0 0 6px rgba(22,163,74,.1);display:flex;align-items:center;justify-content:center;font-size:2.6rem;flex-shrink:0}
.vs-war-title{margin-bottom:6px}
.vs-war-duration{display:inline-block;font-weight:700;font-size:.8rem;color:#fff;background:#16A34A;padding:4px 14px;border-radius:20px;margin-bottom:12px}
.vs-war-checklist{list-style:none;margin:10px 0 0;padding:0;display:flex;flex-direction:column;gap:8px}
.vs-war-checklist li{display:flex;align-items:flex-start;gap:8px}
.vs-war-checklist li::before{content:"✓";color:#16A34A;font-weight:800;flex-shrink:0}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'warranty_desc', '.vs-war-checklist li, .vs-war-desc-plain', [ 'font_size' => 14, 'font_weight' => '400', 'color' => '#334155', 'line_height' => '1.6' ] ); ?>
<?php endif; ?>

/* ── Terms & Conditions — numbered clause accordion ── */
<?php if ( $_sec_show('terms') ): ?>
.vs-terms-wrap{max-width:820px;margin:0 auto;display:flex;flex-direction:column;gap:10px}
.vs-terms-clause{border:1.5px solid #E2E8F0;border-radius:12px;overflow:hidden}
.vs-terms-clause summary{cursor:pointer;padding:16px 20px;background:#F8FAFC;list-style:none;display:flex;align-items:center;gap:12px}
.vs-terms-clause summary::-webkit-details-marker{display:none}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'terms_heading', '.vs-terms-title', [ 'font_size' => 14, 'font_weight' => '700', 'color' => '#1E293B' ] ); ?>
.vs-terms-num{width:26px;height:26px;border-radius:50%;background:var(--vs-primary,#2563EB);color:#fff !important;font-size:.75rem;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.vs-terms-clause-arrow{margin-left:auto;font-size:.95rem;color:#475569;transition:transform .2s}
.vs-terms-clause[open] .vs-terms-clause-arrow{transform:rotate(180deg)}
.vs-terms-clause-body{padding:16px 20px 18px 58px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'terms_body', '.vs-terms-clause-body', [ 'font_size' => 14, 'font_weight' => '400', 'color' => '#475569', 'line_height' => '1.7' ] ); ?>
<?php endif; ?>
<?php if ( $_sec_show('packages') ): ?>
.vs-pkg-img img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .3s}
.vs-pkg-card:hover .vs-pkg-img img{transform:scale(1.05)}
.vs-pkg-img-fallback{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:2.2rem;color:#C7C7CC}
.vs-pkg-main{flex:1;min-width:0;padding:18px;display:flex;flex-direction:column}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'packages_badge', '.vs-pkg-badge', [ 'font_size' => 11, 'font_weight' => '800', 'color' => '#FFFFFF', 'text_transform' => 'uppercase', 'letter_spacing' => '0.04' ] ); ?>
.vs-pkg-badge{display:inline-block;background:var(--vs-primary,#2563EB);padding:3px 10px;border-radius:20px;margin-bottom:9px;align-self:flex-start}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'packages_name', '.vs-pkg-name', [ 'font_size' => 17, 'font_weight' => '800', 'color' => '#1E293B', 'line_height' => '1.3' ] ); ?>
.vs-pkg-name{margin-bottom:6px}
.vs-pkg-meta{display:flex;align-items:center;gap:6px;font-size:.8rem;color:#647388;margin-bottom:8px;flex-wrap:wrap}
.vs-pkg-rating{display:inline-flex;align-items:center;gap:4px;font-weight:700;color:#1E293B}
.vs-pkg-rating-star{color:#1E293B}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'packages_short_desc', '.vs-pkg-short-desc', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.55' ] ); ?>
.vs-pkg-short-desc{margin-bottom:10px;flex:1}
.vs-pkg-price-row{display:flex;align-items:baseline;gap:8px;margin-bottom:10px}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'packages_price', '.vs-pkg-price', [ 'font_size' => 17, 'font_weight' => '800', 'color' => '#1E293B' ] ); ?>
.vs-pkg-duration{font-size:.8rem;color:#647388}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'packages_features', '.vs-pkg-features li', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#48484A', 'line_height' => '1.5' ] ); ?>
.vs-pkg-features{list-style:none;margin:0 0 12px;padding:0;display:flex;flex-direction:column;gap:5px}
.vs-pkg-features li{position:relative;padding-left:16px}
.vs-pkg-features li::before{content:"•";position:absolute;left:0;color:#8E8E93}
.vs-pkg-view-details{font-size:.84rem;font-weight:700;color:var(--vs-primary,#2563EB);background:none;border:none;padding:0;cursor:pointer;font-family:inherit;text-decoration:none;text-align:left;margin-bottom:12px}
.vs-pkg-view-details:hover{text-decoration:underline}
.vs-pkg-add-btn{width:100%;padding:10px 4px;border-radius:9px;border:1.5px solid var(--vs-primary,#2563EB);background:#fff;color:var(--vs-primary,#2563EB);font-weight:700;font-size:.85rem;cursor:pointer;font-family:inherit;transition:.15s;white-space:nowrap;margin-top:auto}
.vs-pkg-add-btn:hover{background:var(--vs-primary,#2563EB);color:#fff}
<?php endif; ?>

/* ── PORTFOLIO / CASE STUDIES ────────────────────── */
<?php if ( $_sec_show('portfolio') ): ?>
.vs-portfolio-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:var(--vs-portfolio-gap,20px)}
<?php
$cv_portfolio_card_bg = $cd['portfolio_card_bg']           ?? '#ffffff';
$cv_portfolio_card_bc = $cd['portfolio_card_border_color'] ?? '#E2E8F0';
?>
.vs-portfolio-card{background:<?php echo esc_attr($cv_portfolio_card_bg); ?>;border:1.5px solid <?php echo esc_attr($cv_portfolio_card_bc); ?>;border-radius:16px;overflow:hidden;transition:.22s;box-shadow:0 2px 8px rgba(0,0,0,.05);display:flex;flex-direction:column}
.vs-portfolio-card:hover{box-shadow:0 12px 36px rgba(0,0,0,.1);transform:translateY(-4px);border-color:var(--vs-primary)}
.vs-portfolio-img{width:100%;height:200px;object-fit:cover;display:block;background:#F1F5F9}
.vs-portfolio-img-placeholder{width:100%;height:200px;background:linear-gradient(135deg,#EFF6FF,#DBEAFE);display:flex;align-items:center;justify-content:center;font-size:2.5rem}
.vs-portfolio-body{padding:18px 20px;flex:1;display:flex;flex-direction:column}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'portfolio_cat', '.vs-portfolio-cat', [ 'font_size' => 11, 'font_weight' => '800', 'color' => '#2563EB', 'text_transform' => 'uppercase', 'letter_spacing' => '0.08' ] ); ?>
.vs-portfolio-cat{margin-bottom:6px}
.vs-portfolio-title{font-weight:800;font-size:.97rem;color:var(--vs-dark);margin-bottom:7px;line-height:1.4}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'portfolio_desc', '.vs-portfolio-desc', [ 'font_size' => 13, 'font_weight' => '400', 'color' => '#64748B', 'line_height' => '1.65' ] ); ?>
.vs-portfolio-desc{flex:1;margin-bottom:12px}
.vs-portfolio-stats{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px}
.vs-portfolio-stat{background:#F0FDF4;border-radius:8px;padding:5px 11px;font-size:.75rem;font-weight:700;color:#166534}
.vs-portfolio-link{font-size:.8rem;font-weight:700;color:var(--vs-primary);text-decoration:none;display:inline-flex;align-items:center;gap:4px}
.vs-portfolio-link:hover{text-decoration:underline}
<?php endif; ?>

/* ── TESTIMONIALS ─────────────────────────────────── */
<?php if ( $_sec_show('testimonials') ): ?>
.vs-testi-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:var(--vs-testi-gap,20px)}
.vs-testi-card{background:<?php echo esc_attr($cv_testi_card_bg); ?>;border:1.5px solid <?php echo esc_attr($cv_testi_card_bc); ?>;border-radius:16px;padding:24px;transition:.22s;box-shadow:0 2px 8px rgba(0,0,0,.05);display:flex;flex-direction:column;position:relative}
.vs-testi-card:hover{box-shadow:0 10px 30px rgba(0,0,0,.1);transform:translateY(-3px);border-color:var(--vs-primary)}
.vs-testi-quote{font-size:2.4rem;line-height:1;color:var(--vs-primary);opacity:.2;position:absolute;top:18px;right:20px;font-weight:900;pointer-events:none}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'testimonials_text', '.vs-testi-text', [ 'font_size' => 14, 'font_weight' => '400', 'color' => '#475569', 'line_height' => '1.75', 'font_style' => 'italic' ] ); ?>
.vs-testi-text{flex:1;margin-bottom:16px}
.vs-testi-video-wrap{border-radius:10px;overflow:hidden;margin-bottom:14px;position:relative;background:#000;cursor:pointer}
.vs-testi-video-thumb{width:100%;height:160px;object-fit:cover;display:block}
.vs-testi-video-play{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.3)}
.vs-testi-video-play-btn{width:52px;height:52px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:1.3rem;transition:.2s}
.vs-testi-video-wrap:hover .vs-testi-video-play-btn{transform:scale(1.1);background:var(--vs-primary);color:#fff}
.vs-testi-stars{color:#F59E0B;font-size:.88rem;margin-bottom:12px;letter-spacing:1px}
.vs-testi-footer{display:flex;align-items:center;gap:12px;border-top:1px solid #F1F5F9;padding-top:14px}
.vs-testi-avatar{width:42px;height:42px;border-radius:50%;object-fit:cover;flex-shrink:0;background:var(--vs-primary);display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;font-size:.95rem}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'testimonials_name', '.vs-testi-name', [ 'font_size' => 14, 'font_weight' => '800', 'color' => '#1E293B' ] ); ?>
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'testimonials_company', '.vs-testi-company', [ 'font_size' => 12, 'font_weight' => '400', 'color' => '#647388' ] ); ?>
.vs-testi-company{margin-top:2px}
<?php endif; ?>

/* ── ROOM TYPES (new module — Phase 3e) ────────────── */
<?php if ( $_sec_show('room_types') ): ?>
.vs-room-grid{display:grid;grid-template-columns:repeat(var(--vs-room-types-grid-cols,3),1fr);gap:var(--vs-room-gap,20px)}
@media(max-width:900px){.vs-room-grid{grid-template-columns:repeat(min(var(--vs-room-types-grid-cols,3),2),1fr)}}
@media(max-width:680px){.vs-room-grid{grid-template-columns:repeat(min(var(--vs-room-types-grid-cols,3),2),1fr);gap:var(--vs-room-gap-mobile,12px)}}
.vs-room-card{background:#fff;border:1px solid #E2E8F0;border-radius:16px;overflow:hidden;transition:.2s;box-shadow:0 1px 3px rgba(0,0,0,.03);display:flex;flex-direction:column}
.vs-room-card:hover{box-shadow:0 10px 28px rgba(0,0,0,.09);transform:translateY(-3px)}
.vs-room-img{width:100%;height:180px;object-fit:cover}
.vs-room-img-placeholder{width:100%;height:180px;background:linear-gradient(135deg,#EFF6FF,#DBEAFE);display:flex;align-items:center;justify-content:center;font-size:2.4rem}
.vs-room-body{padding:18px;display:flex;flex-direction:column;flex:1}
.vs-room-top-row{display:flex;justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:8px}
.vs-room-name{font-weight:800;font-size:1.02rem;color:#1E293B}
.vs-room-avail{font-size:.7rem;font-weight:700;padding:3px 10px;border-radius:20px;background:#DCFCE7;color:#166534;white-space:nowrap}
.vs-room-avail.unavailable{background:#FEF2F2;color:#DC2626}
.vs-room-meta{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:10px}
.vs-room-meta-item{font-size:.78rem;color:#64748B;font-weight:600}
.vs-room-desc{font-size:.85rem;color:#475569;line-height:1.55;margin-bottom:12px}
.vs-room-amenities{list-style:none;display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-bottom:14px;padding:0}
.vs-room-amenities li{font-size:.78rem;color:#334155}
.vs-room-footer{margin-top:auto;display:flex;justify-content:space-between;align-items:center;gap:10px;padding-top:12px;border-top:1px solid #F1F5F9}
.vs-room-price{font-weight:800;font-size:1.05rem;color:#2563EB}
.vs-room-price span{font-size:.72rem;font-weight:600;color:#94A3B8}
.vs-room-cta{font-size:.8rem;padding:8px 16px;white-space:nowrap}
<?php endif; ?>

/* ── HOTELS / BANQUETS / HOSPITALITY — BANQUET & EVENT SPACES (Module 1) ──
   CSS isolation: every selector below is scoped under .gs-hev-*. */
<?php if ( $_sec_show('hotel_event_spaces') ): ?>
.gs-hev-sec-head{margin-bottom:32px}
.gs-hev-eyebrow{font-family:'Jost',sans-serif;font-size:.76rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:#B45309;margin-bottom:12px}
.gs-hev-title{font-family:'Jost',sans-serif;font-size:clamp(1.9rem,3.4vw,2.6rem);font-weight:700;letter-spacing:-.01em;line-height:1.2;color:#0F172A}
.gs-hev-desc{margin-top:14px;font-size:1rem;line-height:1.7;color:#5B6B82;max-width:640px}
.gs-hev-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-bottom:32px}
@media(max-width:1024px){.gs-hev-grid{grid-template-columns:repeat(2,1fr);gap:18px}}
@media(max-width:680px){.gs-hev-grid{grid-template-columns:1fr;gap:16px}}
.gs-hev-card{background:#fff;border:1px solid #E2E8F0;border-radius:16px;overflow:hidden;transition:box-shadow .2s,transform .2s;display:flex;flex-direction:column}
.gs-hev-card:hover{box-shadow:0 12px 30px rgba(15,23,42,.09);transform:translateY(-3px)}
.gs-hev-card-media{position:relative;aspect-ratio:16/10;overflow:hidden;background:#F1F5F9}
.gs-hev-card-img{width:100%;height:100%;object-fit:cover;display:block}
.gs-hev-card-type-badge{position:absolute;top:14px;left:14px;font-family:'Jost',sans-serif;font-size:.68rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:#0F172A;background:#fff;padding:5px 12px;border-radius:999px}
.gs-hev-card-body{padding:20px;display:flex;flex-direction:column;flex:1}
.gs-hev-card-name{font-family:'Jost',sans-serif;font-size:1.12rem;font-weight:700;color:#0F172A;margin-bottom:10px}
.gs-hev-card-meta{display:flex;flex-wrap:wrap;gap:12px;margin-bottom:10px}
.gs-hev-meta-item{font-size:.8rem;color:#64748B;font-weight:600}
.gs-hev-card-events{font-size:.82rem;color:#B45309;font-weight:600;margin-bottom:10px}
.gs-hev-card-desc{font-size:.86rem;line-height:1.6;color:#475569;margin-bottom:14px}
.gs-hev-card-footer{margin-top:auto;display:flex;align-items:center;justify-content:space-between;gap:12px;padding-top:14px;border-top:1px solid #F1F5F9}
.gs-hev-card-price{font-weight:800;font-size:1.02rem;color:#0F172A}
.gs-hev-card-ctas{display:flex;align-items:center;gap:10px}
.gs-hev-cta-secondary{font-size:.8rem;font-weight:600;color:#0F172A;text-decoration:none;border-bottom:1.5px solid #CBD5E1;padding-bottom:2px;white-space:nowrap}
.gs-hev-cta-primary{font-size:.8rem;font-weight:700;color:#fff;background:#B45309;padding:9px 16px;border-radius:8px;text-decoration:none;white-space:nowrap;transition:background .2s}
.gs-hev-cta-primary:hover{background:#92400E}
.gs-hev-matrix-wrap{margin-top:8px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:14px;padding:22px}
.gs-hev-matrix-title{font-family:'Jost',sans-serif;font-weight:700;font-size:.92rem;color:#0F172A;margin-bottom:14px}
.gs-hev-matrix-scroll{overflow-x:auto}
.gs-hev-matrix{width:100%;border-collapse:collapse;font-size:.85rem;white-space:nowrap}
.gs-hev-matrix th{text-align:center;font-weight:700;color:#64748B;font-size:.72rem;text-transform:uppercase;letter-spacing:.04em;padding:8px 14px;border-bottom:2px solid #E2E8F0}
.gs-hev-matrix td{text-align:center;padding:10px 14px;border-bottom:1px solid #E2E8F0;color:#1E293B;font-variant-numeric:tabular-nums}
.gs-hev-matrix-venue{text-align:left!important;font-weight:700}
.gs-hev-matrix th:first-child,.gs-hev-matrix td.gs-hev-matrix-venue{text-align:left}
@media(prefers-reduced-motion:reduce){.gs-hev-card,.gs-hev-card-img,.gs-hev-cta-primary{transition:none}}
<?php endif; ?>

/* ── HOTELS / BANQUETS / HOSPITALITY — EVENTS AT THE PROPERTY (Module 2) ──
   CSS isolation: every selector below is scoped under .gs-hevs-*. Reuses
   the shared window.vsLightbox() mechanism — no new gallery engine. */
<?php if ( $_sec_show('hotel_events_showcase') ): ?>
.gs-hevs-sec-head{margin-bottom:32px}
.gs-hevs-eyebrow{font-family:'Jost',sans-serif;font-size:.76rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:#B45309;margin-bottom:12px}
.gs-hevs-title{font-family:'Jost',sans-serif;font-size:clamp(1.9rem,3.4vw,2.6rem);font-weight:700;letter-spacing:-.01em;line-height:1.2;color:#0F172A}
.gs-hevs-desc{margin-top:14px;font-size:1rem;line-height:1.7;color:#5B6B82;max-width:640px}
.gs-hevs-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
@media(max-width:1024px){.gs-hevs-grid{grid-template-columns:repeat(2,1fr);gap:18px}}
@media(max-width:680px){.gs-hevs-grid{grid-template-columns:1fr;gap:16px}}
.gs-hevs-card{background:#fff;border:1px solid #E2E8F0;border-radius:16px;overflow:hidden;transition:box-shadow .2s,transform .2s;display:flex;flex-direction:column}
.gs-hevs-card:hover{box-shadow:0 12px 30px rgba(15,23,42,.09);transform:translateY(-3px)}
.gs-hevs-cover{position:relative;aspect-ratio:4/3;overflow:hidden;background:#F1F5F9;border:none;padding:0;cursor:pointer;display:block;width:100%}
.gs-hevs-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .3s}
.gs-hevs-cover:hover .gs-hevs-img{transform:scale(1.04)}
.gs-hevs-badge{position:absolute;top:14px;left:14px;font-family:'Jost',sans-serif;font-size:.68rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:#0F172A;background:#fff;padding:5px 12px;border-radius:999px}
.gs-hevs-count{position:absolute;bottom:0;left:0;right:0;padding:10px 14px;font-size:.78rem;font-weight:600;color:#fff;background:linear-gradient(0deg,rgba(15,23,42,.75),transparent);text-align:left}
.gs-hevs-body{padding:18px 20px;display:flex;flex-direction:column;flex:1}
.gs-hevs-card-title{font-family:'Jost',sans-serif;font-size:1.08rem;font-weight:700;color:#0F172A;margin-bottom:8px}
.gs-hevs-meta{font-size:.8rem;color:#B45309;font-weight:600;margin-bottom:8px}
.gs-hevs-card-desc{font-size:.86rem;line-height:1.6;color:#475569}
.gs-hevs-details-link{display:inline-block;margin-top:10px;font-size:.82rem;font-weight:700;color:#B45309;text-decoration:none;border-bottom:1.5px solid transparent;transition:border-color .2s}
.gs-hevs-details-link:hover{border-color:#B45309}
.gs-hevs-hidden-photos{display:none}
@media(prefers-reduced-motion:reduce){.gs-hevs-card,.gs-hevs-img{transition:none}}
<?php endif; ?>

/* ── HOTELS / BANQUETS / HOSPITALITY — DINING & CULINARY EXPERIENCE (Module 3) ──
   CSS isolation: every selector below is scoped under .gs-hdin-*. Tab
   filtering reuses the plain data-attribute mechanism, not a new engine. */
<?php if ( $_sec_show('hotel_dining') ): ?>
.gs-hdin-sec-head{margin-bottom:32px}
.gs-hdin-eyebrow{font-family:'Jost',sans-serif;font-size:.76rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:#B45309;margin-bottom:12px}
.gs-hdin-title{font-family:'Jost',sans-serif;font-size:clamp(1.9rem,3.4vw,2.6rem);font-weight:700;letter-spacing:-.01em;line-height:1.2;color:#0F172A}
.gs-hdin-desc{margin-top:14px;font-size:1rem;line-height:1.7;color:#5B6B82;max-width:640px}
.gs-hdin-tabs{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:28px;overflow-x:auto;-webkit-overflow-scrolling:touch;padding-bottom:2px}
.gs-hdin-tab{font-family:'Jost',sans-serif;flex-shrink:0;font-size:.82rem;font-weight:500;letter-spacing:.02em;color:#64748B;background:transparent;border:1px solid #E2E8F0;border-radius:999px;padding:10px 20px;cursor:pointer;transition:background .2s,color .2s,border-color .2s;min-height:44px}
.gs-hdin-tab:hover{border-color:#B45309;color:#0F172A}
.gs-hdin-tab.is-active{background:#0F172A;border-color:#0F172A;color:#fff}
.gs-hdin-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:20px}
@media(max-width:680px){.gs-hdin-grid{grid-template-columns:1fr}}
.gs-hdin-card{background:#fff;border:1px solid #E2E8F0;border-radius:14px;overflow:hidden;display:flex;flex-direction:column}
.gs-hdin-media{position:relative;aspect-ratio:4/3;overflow:hidden;background:#F1F5F9}
.gs-hdin-img{width:100%;height:100%;object-fit:cover;display:block}
.gs-hdin-chef-badge{position:absolute;top:12px;left:12px;font-size:.7rem;font-weight:700;color:#B45309;background:#fff;padding:4px 10px;border-radius:999px}
.gs-hdin-chef-badge-inline{position:static;display:inline-block;margin-bottom:8px}
.gs-hdin-body{padding:16px 18px;display:flex;flex-direction:column;flex:1}
.gs-hdin-top-row{display:flex;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:6px}
.gs-hdin-name-row{display:flex;align-items:center;gap:8px}
.gs-hdin-dot{width:11px;height:11px;border-radius:2px;border:1.5px solid;flex-shrink:0;display:inline-block}
.gs-hdin-dot-veg{border-color:#16A34A;background:#DCFCE7}
.gs-hdin-dot-nonveg{border-color:#DC2626;background:#FEE2E2}
.gs-hdin-dot-egg{border-color:#B45309;background:#FEF3C7}
.gs-hdin-name{font-family:'Jost',sans-serif;font-size:1rem;font-weight:700;color:#1E293B}
.gs-hdin-price{font-weight:700;font-size:.95rem;color:#B45309;white-space:nowrap}
.gs-hdin-cuisine{font-size:.75rem;color:#94A3B8;font-weight:600;text-transform:uppercase;letter-spacing:.03em;margin-bottom:6px}
.gs-hdin-desc-line{font-size:.83rem;line-height:1.55;color:#7A6B60}
@media(prefers-reduced-motion:reduce){.gs-hdin-tab{transition:none}}
<?php endif; ?>

/* ── HOTELS / BANQUETS / HOSPITALITY — AMENITIES & FACILITIES GROUPED (Module 4) ──
   CSS isolation: every selector below is scoped under .gs-hamn-*. */
<?php if ( $_sec_show('hotel_amenities') ): ?>
.gs-hamn-sec-head{margin-bottom:32px;text-align:center}
.gs-hamn-title{font-family:'Jost',sans-serif;font-size:clamp(1.9rem,3.4vw,2.6rem);font-weight:700;letter-spacing:-.01em;line-height:1.2;color:#0F172A}
.gs-hamn-desc{margin-top:14px;font-size:1rem;line-height:1.7;color:#5B6B82;max-width:640px;margin-left:auto;margin-right:auto}
.gs-hamn-wrap{display:grid;grid-template-columns:repeat(2,1fr);gap:32px}
@media(max-width:780px){.gs-hamn-wrap{grid-template-columns:1fr}}
.gs-hamn-group-title{font-family:'Jost',sans-serif;font-size:1.05rem;font-weight:700;color:#1E293B;margin-bottom:16px;padding-bottom:10px;border-bottom:2px solid #F1F5F9}
.gs-hamn-group-list{display:flex;flex-direction:column;gap:14px}
.gs-hamn-item{display:flex;align-items:flex-start;gap:12px}
.gs-hamn-icon{flex-shrink:0;width:34px;height:34px;border-radius:9px;background:#FEF3E2;display:flex;align-items:center;justify-content:center;font-size:1.05rem}
.gs-hamn-item-body{display:flex;flex-direction:column;gap:2px}
.gs-hamn-item-title{font-weight:600;font-size:.92rem;color:#334155}
.gs-hamn-item-desc{font-size:.8rem;color:#94A3B8;line-height:1.4}
<?php endif; ?>

/* ── HOTELS / BANQUETS / HOSPITALITY — VIRTUAL TOUR (Module 5) ──
   CSS isolation: every selector below is scoped under .gs-hvt-*. */
<?php if ( $_sec_show('hotel_virtual_tour') ): ?>
.gs-hvt-sec-head{margin-bottom:28px;text-align:center}
.gs-hvt-title{font-family:'Jost',sans-serif;font-size:clamp(1.9rem,3.4vw,2.6rem);font-weight:700;letter-spacing:-.01em;line-height:1.2;color:#0F172A}
.gs-hvt-desc{margin-top:14px;font-size:1rem;line-height:1.7;color:#5B6B82;max-width:640px;margin-left:auto;margin-right:auto}
.gs-hvt-wrap{max-width:960px;margin:0 auto}
.gs-hvt-frame{position:relative;aspect-ratio:16/9;border-radius:16px;overflow:hidden;background:#0F172A;box-shadow:0 12px 30px rgba(15,23,42,.12)}
.gs-hvt-frame iframe{position:absolute;inset:0;width:100%;height:100%;border:0}
<?php endif; ?>

/* ── PROPERTY LISTINGS (real estate module 1 of 4) ─── */
<?php if ( $_sec_show('property_listings') ): ?>
.vs-prop-grid{display:grid;grid-template-columns:repeat(var(--vs-property-listings-grid-cols,3),1fr);gap:var(--vs-prop-gap,20px)}
@media(max-width:900px){.vs-prop-grid{grid-template-columns:repeat(min(var(--vs-property-listings-grid-cols,3),2),1fr)}}
@media(max-width:680px){.vs-prop-grid{grid-template-columns:repeat(min(var(--vs-property-listings-grid-cols,3),2),1fr);gap:var(--vs-prop-gap-mobile,12px)}}
.vs-prop-card{background:#fff;border:1px solid #E2E8F0;border-radius:16px;overflow:hidden;transition:.2s;box-shadow:0 1px 3px rgba(0,0,0,.03);display:flex;flex-direction:column}
.vs-prop-card:hover{box-shadow:0 10px 28px rgba(0,0,0,.09);transform:translateY(-3px)}
.vs-prop-img-wrap{position:relative}
.vs-prop-img{width:100%;height:220px;object-fit:cover;display:block}
.vs-prop-img-placeholder{width:100%;height:220px;background:linear-gradient(135deg,#EFF6FF,#DBEAFE);display:flex;align-items:center;justify-content:center;font-size:2.6rem}
.vs-prop-badges{position:absolute;top:10px;left:10px;right:10px;display:flex;flex-wrap:wrap;gap:6px}
.vs-prop-badge{font-size:.68rem;font-weight:700;padding:3px 9px;border-radius:20px;background:rgba(255,255,255,.95);color:#1E293B;box-shadow:0 1px 3px rgba(0,0,0,.1)}
.vs-prop-badge-purpose{background:#2563EB;color:#fff}
.vs-prop-badge-featured{background:#F59E0B;color:#fff}
.vs-prop-badge-verified{background:#16A34A;color:#fff}
.vs-prop-badge-unavailable{background:#DC2626;color:#fff}
.vs-prop-body{padding:18px;display:flex;flex-direction:column;flex:1}
.vs-prop-title{font-weight:800;font-size:1.05rem;color:#1E293B;margin-bottom:4px}
.vs-prop-type{font-size:.76rem;color:#64748B;font-weight:600;margin-bottom:6px}
.vs-prop-location{font-size:.8rem;color:#475569;margin-bottom:8px}
.vs-prop-price{font-weight:800;font-size:1.15rem;color:#2563EB;margin-bottom:10px}
.vs-prop-specs{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:14px;font-size:.78rem;color:#64748B;font-weight:600}
.vs-prop-cta{margin-top:auto;font-size:.85rem;padding:10px 16px;width:100%;text-align:center}
<?php endif; ?>

/* ── FEATURED PROPERTIES (real estate module 2 of 4) ── */
<?php if ( $_sec_show('featured_properties') ): ?>
.vs-feat-prop-grid{display:grid;grid-template-columns:repeat(var(--vs-featured-properties-grid-cols,2),1fr);gap:var(--vs-feat-prop-gap,24px)}
@media(max-width:900px){.vs-feat-prop-grid{grid-template-columns:repeat(min(var(--vs-featured-properties-grid-cols,2),1),1fr)}}
.vs-feat-prop-card{background:#fff;border:1px solid #E2E8F0;border-radius:18px;overflow:hidden;transition:.2s;box-shadow:0 4px 14px rgba(0,0,0,.05);display:flex;flex-direction:column}
.vs-feat-prop-card:hover{box-shadow:0 14px 34px rgba(0,0,0,.1);transform:translateY(-4px)}
.vs-feat-prop-img-wrap{position:relative}
.vs-feat-prop-img{width:100%;height:320px;object-fit:cover;display:block}
.vs-feat-prop-img-placeholder{width:100%;height:320px;background:linear-gradient(135deg,#FEF3C7,#FDE68A);display:flex;align-items:center;justify-content:center;font-size:3.2rem}
.vs-feat-prop-ribbon{position:absolute;top:14px;left:14px;background:#F59E0B;color:#fff;font-size:.74rem;font-weight:800;padding:5px 14px;border-radius:20px;box-shadow:0 2px 6px rgba(0,0,0,.15)}
.vs-feat-prop-body{padding:22px;display:flex;flex-direction:column;flex:1}
.vs-feat-prop-title{font-weight:800;font-size:1.25rem;color:#1E293B;margin-bottom:6px}
.vs-feat-prop-type{font-size:.78rem;color:#64748B;font-weight:600;margin-bottom:6px}
.vs-feat-prop-location{font-size:.85rem;color:#475569;margin-bottom:10px}
.vs-feat-prop-price{font-weight:800;font-size:1.4rem;color:#2563EB;margin-bottom:14px}
.vs-feat-prop-specs{display:flex;flex-wrap:wrap;gap:14px;margin-bottom:18px;font-size:.82rem;color:#64748B;font-weight:600}
.vs-feat-prop-cta{margin-top:auto;font-size:.9rem;padding:12px 18px;width:100%;text-align:center}
<?php endif; ?>

/* ── PROPERTY TYPES/CATEGORIES (real estate module 3 of 4) ── */
<?php if ( $_sec_show('property_types') ): ?>
.vs-prop-type-grid{display:grid;grid-template-columns:repeat(var(--vs-property-types-grid-cols,3),1fr);gap:var(--vs-prop-type-gap,18px)}
@media(max-width:900px){.vs-prop-type-grid{grid-template-columns:repeat(min(var(--vs-property-types-grid-cols,3),2),1fr)}}
@media(max-width:680px){.vs-prop-type-grid{grid-template-columns:repeat(min(var(--vs-property-types-grid-cols,3),2),1fr);gap:var(--vs-prop-type-gap-mobile,12px)}}
.vs-prop-type-card{background:#fff;border:1px solid #E2E8F0;border-radius:14px;overflow:hidden;cursor:pointer;transition:.2s;box-shadow:0 1px 3px rgba(0,0,0,.03);text-align:center}
.vs-prop-type-card:hover{box-shadow:0 10px 26px rgba(0,0,0,.08);transform:translateY(-3px)}
.vs-prop-type-img{width:100%;height:140px;object-fit:cover;display:block}
.vs-prop-type-icon{width:100%;height:140px;background:linear-gradient(135deg,#EFF6FF,#DBEAFE);display:flex;align-items:center;justify-content:center;font-size:2.8rem}
.vs-prop-type-body{padding:16px}
.vs-prop-type-name{font-weight:800;font-size:1rem;color:#1E293B;margin-bottom:4px}
.vs-prop-type-count{font-size:.8rem;color:#2563EB;font-weight:700}
<?php endif; ?>

/* ── PROPERTY GALLERY (real estate module 4 of 4) ── */
<?php if ( $_sec_show('property_gallery') ): ?>
.vs-prop-gallery-grid{display:grid;grid-template-columns:repeat(var(--vs-prop-gallery-cols,4),1fr);gap:var(--vs-prop-gallery-gap,16px)}
@media(max-width:900px){.vs-prop-gallery-grid{grid-template-columns:repeat(min(var(--vs-prop-gallery-cols,4),3),1fr)}}
@media(max-width:680px){.vs-prop-gallery-grid{grid-template-columns:repeat(min(var(--vs-prop-gallery-cols,4),2),1fr);gap:calc(var(--vs-prop-gallery-gap,16px) * .6)}}
.vs-prop-gallery-masonry{columns:var(--vs-prop-gallery-cols,4);column-gap:var(--vs-prop-gallery-gap,16px)}
@media(max-width:900px){.vs-prop-gallery-masonry{columns:min(var(--vs-prop-gallery-cols,4),3)}}
@media(max-width:680px){.vs-prop-gallery-masonry{columns:min(var(--vs-prop-gallery-cols,4),2)}}
.vs-prop-gallery-masonry .vs-prop-gallery-item{break-inside:avoid;margin-bottom:var(--vs-prop-gallery-gap,16px)}
.vs-prop-gallery-masonry .vs-prop-gallery-img{aspect-ratio:auto}
.vs-prop-gallery-carousel{display:flex;gap:var(--vs-prop-gallery-gap,16px);overflow-x:auto;scroll-snap-type:x mandatory;padding-bottom:8px}
.vs-prop-gallery-carousel .vs-prop-gallery-item{flex:0 0 auto;width:min(320px,80vw);scroll-snap-align:start}
.vs-prop-gallery-item{position:relative;border-radius:var(--vs-prop-gallery-radius,12px);overflow:hidden;cursor:pointer}
.vs-prop-gallery-img{width:100%;aspect-ratio:var(--vs-prop-gallery-aspect,4/3);object-fit:cover;display:block;transition:.2s}
.vs-prop-gallery-item:hover .vs-prop-gallery-img{transform:scale(1.04)}
.vs-prop-gallery-caption{position:absolute;left:0;right:0;bottom:0;background:linear-gradient(to top,rgba(0,0,0,.65),transparent);color:#fff;font-size:.78rem;font-weight:600;padding:16px 10px 8px}
.vs-prop-gallery-carousel-wrap{position:relative}
.vs-prop-gallery-nav{position:absolute;top:50%;transform:translateY(-50%);width:38px;height:38px;border-radius:50%;background:rgba(255,255,255,.95);border:1px solid #E2E8F0;box-shadow:0 2px 8px rgba(0,0,0,.12);font-size:1.4rem;line-height:1;color:#1E293B;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:2}
.vs-prop-gallery-nav:hover{background:#fff;box-shadow:0 4px 14px rgba(0,0,0,.18)}
.vs-prop-gallery-nav-prev{left:6px}
.vs-prop-gallery-nav-next{right:6px}
@media(max-width:680px){.vs-prop-gallery-nav{width:32px;height:32px;font-size:1.15rem}}
<?php endif; ?>

/* ── INTERIOR DESIGNERS & ARCHITECTS — FEATURED PROJECTS (module 1 of 5) ── */
<?php
// Bug fix — same shared-header CSS-gating defect found and fixed for
// Beauty & Salon (see that block's own comment for the full mechanism):
// .vs-ida-sec-head/-eyebrow/-title/-desc are used by all 5 Interior
// Designers & Architects modules (FeaturedProjects, ProjectCategories,
// ThreeDBeforeAfter, DesignStyles, DesignProcess — confirmed via grep)
// but were defined only inside the featured_projects gate, so any
// vendor running a sibling module without Featured Projects enabled
// got an unstyled heading/eyebrow/description. Hoisted to its own
// OR-gated block. ?>
<?php if ( $_sec_show('featured_projects') || $_sec_show('project_categories') || $_sec_show('three_d_before_after') || $_sec_show('design_styles') || $_sec_show('design_process') ): ?>
.vs-ida-sec-head{max-width:640px;margin:0 0 48px}
.vs-ida-eyebrow{font-size:.72rem;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:#94A3B8;margin-bottom:14px}
.vs-ida-title{font-size:clamp(2rem,4vw,2.75rem);font-weight:700;letter-spacing:-.02em;line-height:1.15;color:#18181B}
.vs-ida-desc{margin-top:16px;font-size:1.02rem;line-height:1.6;color:#52525B;max-width:62ch}
<?php endif; ?>
<?php if ( $_sec_show('featured_projects') ): ?>
.vs-ida-projects{display:grid;gap:2px;background:#E4E4E7}
.vs-ida-layout-editorial{grid-template-columns:repeat(2,1fr)}
.vs-ida-layout-minimal{grid-template-columns:repeat(3,1fr)}
.vs-ida-layout-showcase{grid-template-columns:1fr}
@media(max-width:900px){.vs-ida-layout-editorial,.vs-ida-layout-minimal{grid-template-columns:repeat(2,1fr)}}
@media(max-width:680px){.vs-ida-layout-editorial,.vs-ida-layout-minimal{grid-template-columns:1fr}.vs-ida-projects{gap:1px}}
.vs-ida-project-card{background:#fff;display:flex;flex-direction:column;position:relative;overflow:hidden}
.vs-ida-layout-editorial .vs-ida-project-primary{grid-column:span 2}
@media(max-width:680px){.vs-ida-layout-editorial .vs-ida-project-primary{grid-column:span 1}}
.vs-ida-project-media{position:relative;overflow:hidden;background:#F4F4F5}
.vs-ida-layout-editorial .vs-ida-project-media{aspect-ratio:16/10}
.vs-ida-layout-minimal .vs-ida-project-media{aspect-ratio:4/5}
.vs-ida-layout-showcase .vs-ida-project-media{aspect-ratio:21/9}
.vs-ida-project-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .6s cubic-bezier(.16,1,.3,1)}
.vs-ida-project-card:hover .vs-ida-project-img{transform:scale(1.035)}
.vs-ida-project-img-placeholder{width:100%;height:100%;min-height:260px;background:linear-gradient(135deg,#F4F4F5,#E4E4E7);display:flex;align-items:center;justify-content:center;font-size:2.4rem;color:#A1A1AA}
.vs-ida-project-badge{position:absolute;top:18px;left:18px;font-size:.68rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#fff;background:rgba(24,24,27,.72);backdrop-filter:blur(6px);padding:6px 12px}
.vs-ida-project-body{padding:28px 26px 26px}
.vs-ida-project-name{font-size:1.28rem;font-weight:700;letter-spacing:-.01em;color:#18181B;margin-bottom:4px}
.vs-ida-project-subtitle{font-size:.88rem;color:#71717A;margin-bottom:14px}
.vs-ida-project-meta{display:flex;flex-wrap:wrap;gap:16px;font-size:.74rem;font-weight:600;letter-spacing:.04em;text-transform:uppercase;color:#A1A1AA;margin-bottom:18px}
.vs-ida-view-case-study{display:inline-block;font-size:.78rem;font-weight:700;letter-spacing:.03em;color:#18181B;text-decoration:none;border-bottom:1.5px solid #18181B;padding-bottom:2px;transition:opacity .2s}
.vs-ida-view-case-study:hover{opacity:.6}
<?php endif; ?>

/* ── INTERIOR DESIGNERS & ARCHITECTS — PROJECT CATEGORIES (module 2 of 5) ── */
<?php if ( $_sec_show('project_categories') ): ?>
.vs-ida-cat-grid{display:grid;grid-template-columns:repeat(var(--vs-ida-cat-cols,3),1fr);gap:var(--vs-ida-cat-gap,20px)}
@media(max-width:900px){.vs-ida-cat-grid{grid-template-columns:repeat(min(var(--vs-ida-cat-cols,3),2),1fr)}}
@media(max-width:680px){.vs-ida-cat-grid{grid-template-columns:1fr;gap:var(--vs-ida-cat-gap-mobile,14px)}}
.vs-ida-cat-tile{position:relative;aspect-ratio:4/5;overflow:hidden;cursor:pointer;background:#18181B}
.vs-ida-cat-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .6s cubic-bezier(.16,1,.3,1);opacity:.85}
.vs-ida-cat-tile:hover .vs-ida-cat-img{transform:scale(1.06);opacity:1}
.vs-ida-cat-img-placeholder{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:3rem;background:linear-gradient(135deg,#27272A,#18181B);color:#71717A}
.vs-ida-cat-overlay{position:absolute;left:0;right:0;bottom:0;padding:28px 24px;background:linear-gradient(to top,rgba(0,0,0,.82) 0%,rgba(0,0,0,.35) 55%,transparent 100%)}
.vs-ida-cat-name{font-size:1.4rem;font-weight:700;letter-spacing:-.01em;color:#fff;margin-bottom:6px}
.vs-ida-cat-count{font-size:.72rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:rgba(255,255,255,.7);margin-bottom:10px}
.vs-ida-cat-desc{font-size:.85rem;line-height:1.5;color:rgba(255,255,255,.85);margin-bottom:14px;max-width:32ch}
.vs-ida-cat-featured{font-size:.72rem;font-weight:600;color:#FDE68A;margin-bottom:10px}
.vs-ida-cat-cta{display:inline-block;font-size:.76rem;font-weight:700;letter-spacing:.03em;color:#fff;border-bottom:1.5px solid rgba(255,255,255,.6)}
<?php endif; ?>

/* ── INTERIOR DESIGNERS & ARCHITECTS — 3D DESIGNS & BEFORE/AFTER (module 3 of 5) ── */
<?php if ( $_sec_show('three_d_before_after') ): ?>
.vs-ida-subhead{font-size:1.15rem;font-weight:700;letter-spacing:-.01em;color:#18181B;margin-bottom:22px}
.vs-ida-3d-subsection{margin-bottom:56px}
.vs-ida-3d-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:var(--vs-ida-3d-gap,28px)}
@media(max-width:900px){.vs-ida-3d-grid{grid-template-columns:1fr}}
.vs-ida-3d-card{background:#fff}
.vs-ida-3d-images{display:grid;grid-template-columns:1fr;gap:2px}
.vs-ida-3d-panes-2{grid-template-columns:1fr 1fr}
.vs-ida-3d-panes-3{grid-template-columns:1fr 1fr 1fr}
@media(max-width:680px){.vs-ida-3d-panes-2,.vs-ida-3d-panes-3{grid-template-columns:1fr}}
.vs-ida-3d-pane{position:relative;aspect-ratio:4/3;overflow:hidden;background:#F4F4F5}
.vs-ida-3d-pane img{width:100%;height:100%;object-fit:cover;display:block}
.vs-ida-3d-label{position:absolute;top:12px;left:12px;font-size:.66rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#fff;background:rgba(24,24,27,.72);padding:5px 10px;z-index:2}
.vs-ida-3d-body{padding:18px 4px}
.vs-ida-3d-name{font-size:1.05rem;font-weight:700;color:#18181B;margin-bottom:2px}
.vs-ida-3d-meta{font-size:.76rem;color:#71717A;margin-bottom:8px}
.vs-ida-3d-desc{font-size:.88rem;line-height:1.6;color:#52525B}

.vs-ida-ba-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:var(--vs-ida-ba-gap,28px)}
.vs-ida-ba-layout-side_by_side{grid-template-columns:repeat(2,1fr)}
@media(max-width:900px){.vs-ida-ba-grid{grid-template-columns:1fr}}
.vs-ida-ba-slider{position:relative;aspect-ratio:16/10;overflow:hidden;cursor:ew-resize;user-select:none;touch-action:pan-y;background:#F4F4F5}
.vs-ida-ba-img{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;display:block;pointer-events:none}
.vs-ida-ba-before-wrap{position:absolute;top:0;left:0;width:100%;height:100%;clip-path:inset(0 50% 0 0)}
.vs-ida-ba-handle{position:absolute;top:0;bottom:0;width:2px;background:#fff;transform:translateX(-50%);z-index:3;box-shadow:0 0 0 1px rgba(0,0,0,.1)}
.vs-ida-ba-handle-grip{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:38px;height:38px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:1.05rem;color:#18181B;box-shadow:0 2px 10px rgba(0,0,0,.2);cursor:ew-resize}
.vs-ida-ba-tag{position:absolute;top:12px;font-size:.66rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#fff;background:rgba(24,24,27,.72);padding:5px 10px;z-index:2;pointer-events:none}
.vs-ida-ba-tag-before{left:12px}
.vs-ida-ba-tag-after{right:12px}
.vs-ida-ba-sidebyside{display:grid;grid-template-columns:1fr 1fr;gap:2px}
@media(max-width:480px){.vs-ida-ba-sidebyside{grid-template-columns:1fr}}
.vs-ida-ba-sidebyside>div{position:relative;aspect-ratio:4/3;overflow:hidden;background:#F4F4F5}
.vs-ida-ba-sidebyside img{width:100%;height:100%;object-fit:cover;display:block}
.vs-ida-ba-tag-static{position:absolute;top:12px;left:12px;font-size:.66rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#fff;background:rgba(24,24,27,.72);padding:5px 10px;z-index:2}
.vs-ida-ba-body{padding:18px 4px}
.vs-ida-ba-name{font-size:1.05rem;font-weight:700;color:#18181B;margin-bottom:2px}
.vs-ida-ba-meta{font-size:.76rem;color:#71717A;margin-bottom:8px}
.vs-ida-ba-desc{font-size:.88rem;line-height:1.6;color:#52525B}
<?php endif; ?>

/* ── INTERIOR DESIGNERS & ARCHITECTS — DESIGN STYLES & EXPERTISE (module 4 of 5) ── */
<?php if ( $_sec_show('design_styles') ): ?>
.vs-ida-style-row{display:flex;gap:20px;overflow-x:auto;padding-bottom:12px;scroll-snap-type:x proximity;margin-bottom:36px}
.vs-ida-style-row::-webkit-scrollbar{height:5px}
.vs-ida-style-row::-webkit-scrollbar-thumb{background:#E4E4E7;border-radius:3px}
.vs-ida-style-tile{flex:0 0 auto;width:min(300px,78vw);cursor:pointer;scroll-snap-align:start}
.vs-ida-style-img{width:100%;aspect-ratio:4/5;object-fit:cover;display:block;transition:transform .5s cubic-bezier(.16,1,.3,1)}
.vs-ida-style-tile:hover .vs-ida-style-img{transform:scale(1.04)}
.vs-ida-style-img-placeholder{width:100%;aspect-ratio:4/5;display:flex;align-items:center;justify-content:center;font-size:2.4rem;background:linear-gradient(135deg,#F4F4F5,#E4E4E7);color:#A1A1AA}
.vs-ida-style-body{padding-top:16px}
.vs-ida-style-name{font-size:1.15rem;font-weight:700;letter-spacing:-.01em;color:#18181B;margin-bottom:4px}
.vs-ida-style-count{font-size:.7rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#A1A1AA;margin-bottom:10px}
.vs-ida-style-desc{font-size:.86rem;line-height:1.55;color:#52525B;margin-bottom:8px}
.vs-ida-style-materials{font-size:.76rem;color:#71717A;font-style:italic}
.vs-ida-style-palette{display:flex;gap:6px;margin-bottom:8px}
.vs-ida-style-swatch{width:20px;height:20px;border-radius:50%;border:1.5px solid rgba(0,0,0,.08);display:inline-block}
.vs-ida-expertise-subhead{font-size:.78rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#71717A;margin-bottom:16px}
.vs-ida-expertise-row{display:flex;flex-wrap:wrap;gap:10px}
.vs-ida-expertise-tag{display:inline-flex;align-items:center;gap:8px;padding:9px 18px;border:1.5px solid #E4E4E7;border-radius:999px;font-size:.84rem;font-weight:600;color:#27272A;transition:.2s}
.vs-ida-expertise-tag[onclick]{cursor:pointer}
.vs-ida-expertise-tag[onclick]:hover{border-color:#18181B;background:#18181B;color:#fff}
.vs-ida-expertise-tag[onclick]:hover .vs-ida-expertise-count{color:#fff}
.vs-ida-expertise-count{font-size:.72rem;font-weight:700;color:#A1A1AA}
@media(max-width:680px){.vs-ida-style-tile{width:min(240px,72vw)}}
<?php endif; ?>

/* ── INTERIOR DESIGNERS & ARCHITECTS — DESIGN PROCESS (module 5 of 5) ── */
<?php if ( $_sec_show('design_process') ): ?>
.vs-ida-process-num{font-size:.78rem;font-weight:800;letter-spacing:.03em;color:#A1A1AA}
.vs-ida-process-name{font-size:1.1rem;font-weight:700;letter-spacing:-.01em;color:#18181B;margin-bottom:6px}
.vs-ida-process-desc{font-size:.9rem;line-height:1.6;color:#52525B}
.vs-ida-process-meta{display:flex;flex-wrap:wrap;gap:16px;margin-top:12px;font-size:.78rem;color:#71717A;font-weight:600}

/* Timeline — compact connected numbers, horizontal on desktop */
.vs-ida-process-timeline{display:flex;gap:0;overflow-x:auto;padding-bottom:8px}
.vs-ida-process-timeline .vs-ida-process-step{position:relative;flex:1 0 220px;padding:0 20px 0 0}
.vs-ida-process-timeline .vs-ida-process-num{display:block;font-size:1.6rem;color:#18181B;margin-bottom:10px}
.vs-ida-process-timeline .vs-ida-process-connector{position:absolute;top:14px;left:calc(1.6rem + 14px);right:20px;height:1.5px;background:#E4E4E7}
@media(max-width:900px){.vs-ida-process-timeline{flex-direction:column;gap:28px}.vs-ida-process-timeline .vs-ida-process-connector{display:none}}

/* Vertical — large numbered steps, always stacked */
.vs-ida-process-vertical{display:flex;flex-direction:column;gap:0}
.vs-ida-process-vertical .vs-ida-process-step{position:relative;display:flex;gap:24px;padding-bottom:36px}
.vs-ida-process-vertical .vs-ida-process-num{font-size:2.2rem;color:#E4E4E7;line-height:1;flex-shrink:0;width:64px}
.vs-ida-process-vertical .vs-ida-process-connector{position:absolute;top:44px;bottom:0;left:31px;width:1.5px;background:#E4E4E7}

/* Horizontal — scrollable full cards; auto-stacks vertically on mobile */
.vs-ida-process-horizontal{display:flex;gap:24px;overflow-x:auto;padding-bottom:12px;scroll-snap-type:x proximity}
.vs-ida-process-horizontal .vs-ida-process-step{flex:0 0 auto;width:min(300px,80vw);background:#F8FAFC;padding:24px;scroll-snap-align:start;position:relative}
.vs-ida-process-horizontal .vs-ida-process-num{display:block;font-size:1.8rem;margin-bottom:10px}
.vs-ida-process-horizontal .vs-ida-process-connector{display:none}
@media(max-width:680px){.vs-ida-process-horizontal{flex-direction:column;overflow-x:visible}.vs-ida-process-horizontal .vs-ida-process-step{width:100%}}

/* Editorial — large number + image + description */
.vs-ida-process-editorial{display:flex;flex-direction:column;gap:48px}
.vs-ida-process-editorial .vs-ida-process-step{display:grid;grid-template-columns:auto 1fr;gap:28px;align-items:start}
.vs-ida-process-editorial .vs-ida-process-num{font-size:3rem;color:#E4E4E7;line-height:1}
.vs-ida-process-editorial .vs-ida-process-img-wrap{grid-column:1/-1;aspect-ratio:21/9;overflow:hidden;background:#F4F4F5;margin-top:8px}
.vs-ida-process-editorial .vs-ida-process-img{width:100%;height:100%;object-fit:cover;display:block}
.vs-ida-process-editorial .vs-ida-process-connector{display:none}
@media(max-width:680px){.vs-ida-process-editorial .vs-ida-process-step{grid-template-columns:1fr}}
<?php endif; ?>

/* ── HEALTH & WELLNESS — FEATURED SERVICES/TREATMENTS (module 1 of 5) ── */
<?php
// Bug fix — same shared-header CSS-gating defect as Beauty & Salon and
// Interior Designers & Architects (see those blocks' own comments):
// .vs-hw-sec-head/-eyebrow/-title/-desc are used by all 5 Health &
// Wellness modules (FeaturedServices, Departments, Doctors,
// PatientFacilities, PatientJourney — confirmed via grep) but were
// defined only inside the featured_services gate. Hoisted to its own
// OR-gated block. ?>
<?php if ( $_sec_show('featured_services') || $_sec_show('departments') || $_sec_show('doctors') || $_sec_show('patient_facilities') || $_sec_show('patient_journey') ): ?>
.vs-hw-sec-head{max-width:640px;margin:0 0 40px}
.vs-hw-eyebrow{font-size:.74rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:#2563EB;margin-bottom:12px}
.vs-hw-title{font-size:clamp(1.9rem,3.6vw,2.5rem);font-weight:700;letter-spacing:-.01em;line-height:1.2;color:#0F172A}
.vs-hw-desc{margin-top:14px;font-size:1rem;line-height:1.65;color:#475569;max-width:62ch}
<?php endif; ?>
<?php if ( $_sec_show('featured_services') ): ?>
.vs-hw-services-inner{display:grid;gap:20px}
.vs-hw-layout-directory .vs-hw-services-inner,.vs-hw-layout-departments .vs-hw-services-inner{grid-template-columns:repeat(2,1fr)}
.vs-hw-layout-featured .vs-hw-services-inner,.vs-hw-layout-image_led .vs-hw-services-inner{grid-template-columns:repeat(3,1fr)}
@media(max-width:900px){.vs-hw-layout-directory .vs-hw-services-inner,.vs-hw-layout-departments .vs-hw-services-inner,.vs-hw-layout-featured .vs-hw-services-inner,.vs-hw-layout-image_led .vs-hw-services-inner{grid-template-columns:repeat(2,1fr)}}
@media(max-width:680px){.vs-hw-services-inner{grid-template-columns:1fr!important;gap:14px}}
.vs-hw-dept-group-label{font-size:.8rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:#2563EB;margin:28px 0 14px;padding-top:20px;border-top:1px solid #E2E8F0}
.vs-hw-dept-group-label:first-child{margin-top:0;padding-top:0;border-top:none}
.vs-hw-service-card{background:#fff;border:1px solid #E2E8F0;border-radius:14px;overflow:hidden;display:flex;flex-direction:column;transition:box-shadow .2s,transform .2s}
.vs-hw-service-card:hover{box-shadow:0 8px 24px rgba(15,23,42,.08);transform:translateY(-2px)}
.vs-hw-service-featured{grid-column:span 2;border-color:#93C5FD}
@media(max-width:680px){.vs-hw-service-featured{grid-column:span 1}}
.vs-hw-layout-featured .vs-hw-service-featured .vs-hw-service-media{aspect-ratio:21/9}
.vs-hw-service-media{aspect-ratio:16/10;overflow:hidden;background:#F1F5F9}
.vs-hw-layout-image_led .vs-hw-service-media{aspect-ratio:4/5}
.vs-hw-service-img{width:100%;height:100%;object-fit:cover;display:block}
.vs-hw-service-body{padding:22px;flex:1;display:flex;flex-direction:column}
.vs-hw-service-icon{font-size:1.6rem;margin-bottom:10px}
.vs-hw-service-name{font-size:1.08rem;font-weight:700;color:#0F172A;margin-bottom:6px}
.vs-hw-service-desc{font-size:.88rem;line-height:1.55;color:#64748B;margin-bottom:14px}
.vs-hw-service-meta{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:10px}
.vs-hw-service-dept{font-size:.72rem;font-weight:600;color:#2563EB;background:#EFF6FF;padding:4px 10px;border-radius:6px}
.vs-hw-service-price{font-size:.78rem;font-weight:700;color:#0F172A}
.vs-hw-service-modes{display:flex;gap:14px;font-size:.78rem;color:#64748B;margin-bottom:16px}
.vs-hw-service-ctas{display:flex;align-items:center;gap:10px;margin-top:auto;padding-top:12px}
.vs-hw-cta-primary{font-size:.84rem;font-weight:700;color:#2563EB;text-decoration:none;border-bottom:1.5px solid #2563EB;padding-bottom:1px}
.vs-hw-cta-secondary{font-size:.84rem;font-weight:600;color:#fff;background:#2563EB;padding:8px 16px;border-radius:8px;text-decoration:none;transition:background .2s}
.vs-hw-cta-secondary:hover{background:#1D4ED8}
.vs-hw-cta-icon{width:34px;height:34px;border-radius:50%;border:1px solid #E2E8F0;display:flex;align-items:center;justify-content:center;text-decoration:none;font-size:1rem;flex-shrink:0}
.vs-hw-cta-icon:hover{border-color:#2563EB;background:#EFF6FF}
<?php endif; ?>

/* ── BEAUTY & SALON — SECTION 01 OF 6: BEAUTY SERVICE DISCOVERY ──
   CSS isolation: every selector below is scoped under .gs-beauty-*
   (a namespace unique to this build) — no global element selector
   (h1/h2/button/img/.card/.container/.row/.col) is ever touched, per
   the master build prompt's explicit CSS-isolation mandate. */
<?php
// Bug fix — root-cause CSS architecture audit (Salon Experience &
// Facilities premium-UI review): the :root custom-property palette and
// the 4 shared header classes (.gs-beauty-sec-head/-eyebrow/-title/-desc)
// used by EVERY ONE of the 6 Beauty & Salon modules (Services, Gallery,
// Experts, Facilities, Packages, Booking CTA — confirmed via grep
// against every BeautyXModule.php render_title()) were defined ONLY
// inside the beauty_services-gated block below. Since every beauty_*
// module is independently activatable by design (see each module's own
// registration docblock — "independently-gated, not dependent on
// beauty_services being enabled"), a vendor who enabled ONLY
// beauty_facilities (or any sibling without beauty_services) got a
// completely unstyled eyebrow/heading/description on every one of their
// active beauty sections: default browser heading instead of the
// intended 2.6rem Jost semi-bold, no champagne eyebrow color, no taupe
// description color — exactly the "basic, unfinished" appearance
// reported. Fixed by hoisting this truly shared block out to its own
// gate, OR'd across all 6 sibling modules, instead of tying it to one
// module's visibility — the CSS-payload-minimization discipline this
// file follows everywhere else is preserved (nothing ships when the
// whole category is off), it just no longer silently depends on one
// arbitrary sibling module being the one left enabled. ?>
<?php if ( $_sec_show('beauty_services') || $_sec_show('beauty_gallery') || $_sec_show('beauty_experts') || $_sec_show('beauty_facilities') || $_sec_show('beauty_packages') || $_sec_show('beauty_booking_cta') ): ?>
:root{--beauty-ivory:#FAF7F2;--beauty-warm-white:#FFFDFB;--beauty-charcoal:#2B2620;--beauty-taupe:#8A7B6C;--beauty-blush:#E8C4C0;--beauty-champagne:#C9A867;--beauty-line:#E7E0D6}
.gs-beauty-sec-head{max-width:680px;margin:0 0 44px}
.gs-beauty-eyebrow{font-family:'Jost',sans-serif;font-size:.76rem;font-weight:600;letter-spacing:.16em;text-transform:uppercase;color:var(--beauty-champagne);margin-bottom:14px}
.gs-beauty-title{font-family:'Jost',sans-serif;font-size:clamp(1.9rem,3.4vw,2.6rem);font-weight:600;letter-spacing:-.01em;line-height:1.2;color:var(--beauty-charcoal)}
.gs-beauty-desc{margin-top:16px;font-size:1rem;line-height:1.7;color:var(--beauty-taupe);max-width:60ch}
<?php endif; ?>
<?php if ( $_sec_show('beauty_services') ): ?>
/* Section-scoped element/container/heading variables — isolated to THIS
   section only, same mechanism as beauty_facilities. */
#vs-sec-beauty_services{<?php echo $cv_bs_style_css . $cv_bs_container_css . $cv_bs_heading_css; ?>background:var(--gs-bs-sec-bg,transparent);padding:var(--gs-bs-pad-t,0) var(--gs-bs-pad-r,0) var(--gs-bs-pad-b,0) var(--gs-bs-pad-l,0);border:var(--gs-bs-border-w,0) solid var(--gs-bs-border-color,transparent);border-radius:var(--gs-bs-border-radius,0);box-shadow:var(--gs-bs-sec-shadow,none)}
#vs-sec-beauty_services .gs-beauty-sec-head{margin-bottom:var(--gs-bs-heading-gap,44px)}
#vs-sec-beauty_services .gs-beauty-eyebrow{color:var(--gs-bs-eyebrow-color,#C9A867)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'beauty_services_desc', '#vs-sec-beauty_services .gs-beauty-desc', [ 'font_size' => 16, 'color' => '#8A7B6C' ] ); ?>
.gs-beauty-services{font-family:inherit}
.gs-beauty-tabs{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:32px;overflow-x:auto;-webkit-overflow-scrolling:touch;padding-bottom:2px}
.gs-beauty-tab{font-family:'Jost',sans-serif;flex-shrink:0;font-size:.82rem;font-weight:500;letter-spacing:.03em;color:var(--beauty-taupe);background:transparent;border:1px solid var(--beauty-line);border-radius:999px;padding:10px 20px;cursor:pointer;transition:background .2s,color .2s,border-color .2s;min-height:44px}
.gs-beauty-tab:hover{border-color:var(--beauty-champagne);color:var(--beauty-charcoal)}
.gs-beauty-tab.is-active{background:var(--beauty-charcoal);border-color:var(--beauty-charcoal);color:var(--beauty-warm-white)}
.gs-beauty-grid{display:grid;grid-template-columns:repeat(var(--gs-bs-grid-cols,3),1fr);gap:var(--gs-bs-grid-gap,28px)}
@media(max-width:1024px){.gs-beauty-grid{grid-template-columns:repeat(2,1fr);gap:22px}}
@media(max-width:680px){.gs-beauty-grid{grid-template-columns:1fr;gap:18px}}
.gs-beauty-card{background:var(--beauty-warm-white);border:1px solid var(--gs-bs-card-border,var(--beauty-line));border-radius:var(--gs-bs-card-radius,4px);overflow:hidden;display:flex;flex-direction:column;transition:box-shadow .25s,transform .25s}
.gs-beauty-card:hover{box-shadow:0 18px 40px rgba(43,38,32,.1);transform:translateY(-3px)}
.gs-beauty-card[hidden],.gs-beauty-card.gs-beauty-card-hidden{display:none}
.gs-beauty-card-media{position:relative;aspect-ratio:4/5;overflow:hidden;background:var(--beauty-ivory)}
.gs-beauty-card-img{width:100%;height:100%;object-fit:cover;display:block}
.gs-beauty-card-flags{position:absolute;top:14px;left:14px;display:flex;flex-direction:column;gap:6px}
.gs-beauty-flag{font-family:'Jost',sans-serif;font-size:.66rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--gs-bs-badge-color,var(--beauty-charcoal));background:var(--gs-bs-badge-bg,var(--beauty-warm-white));padding:4px 10px;border-radius:999px;width:fit-content}
.gs-beauty-card-body{padding:var(--gs-bs-card-padding,24px);flex:1;display:flex;flex-direction:column}
.gs-beauty-card-name{font-family:'Jost',sans-serif;font-size:1.08rem;font-weight:600;color:var(--beauty-charcoal);margin-bottom:8px}
.gs-beauty-card-desc{font-size:.86rem;line-height:1.6;color:var(--beauty-taupe);margin-bottom:16px}
.gs-beauty-card-meta{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:18px;font-size:.8rem;color:var(--beauty-taupe)}
.gs-beauty-card-price{font-weight:600;color:var(--beauty-charcoal)}
.gs-beauty-card-ctas{display:flex;align-items:center;gap:12px;margin-top:auto;padding-top:14px;border-top:1px solid var(--beauty-line)}
.gs-beauty-cta-primary{font-family:'Jost',sans-serif;font-size:.8rem;font-weight:600;letter-spacing:.02em;color:var(--beauty-charcoal);text-decoration:none;border-bottom:1.5px solid var(--beauty-champagne);padding-bottom:2px;min-height:44px;display:inline-flex;align-items:center}
.gs-beauty-cta-secondary{font-family:'Jost',sans-serif;font-size:.8rem;font-weight:600;color:var(--beauty-warm-white);background:var(--gs-bs-cta-bg,var(--beauty-charcoal));padding:10px 18px;border-radius:var(--gs-bs-cta-radius,2px);text-decoration:none;transition:background .2s;min-height:44px;display:inline-flex;align-items:center}
.gs-beauty-cta-secondary:hover{background:var(--beauty-champagne)}
.gs-beauty-cta-icon{width:40px;height:40px;border-radius:50%;border:1px solid var(--beauty-line);display:flex;align-items:center;justify-content:center;text-decoration:none;font-size:1rem;flex-shrink:0}
.gs-beauty-cta-icon:hover{border-color:var(--beauty-champagne);background:var(--beauty-ivory)}
@media(prefers-reduced-motion:reduce){.gs-beauty-card,.gs-beauty-tab,.gs-beauty-cta-secondary{transition:none}}
<?php endif; ?>

/* ── BEAUTY & SALON — SECTION 02 OF 6: SIGNATURE LOOKS & TRANSFORMATIONS ──
   Reuses the platform's existing before/after drag-slider engine
   (window.vsIdaInitBeforeAfterSlider) via its required .vs-ida-ba-*
   structural hook classes — those three selectors below are the
   mechanism's fixed integration contract, not a namespace violation;
   every other selector here is gs-beauty-* scoped. */
<?php if ( $_sec_show('beauty_gallery') ): ?>
/* Section-scoped element/container/heading variables — isolated to THIS
   section only, same mechanism as beauty_facilities/beauty_services. */
#vs-sec-beauty_gallery{<?php echo $cv_bg_style_css . $cv_bg_container_css . $cv_bg_heading_css; ?>background:var(--gs-bg-sec-bg,transparent);padding:var(--gs-bg-pad-t,0) var(--gs-bg-pad-r,0) var(--gs-bg-pad-b,0) var(--gs-bg-pad-l,0);border:var(--gs-bg-border-w,0) solid var(--gs-bg-border-color,transparent);border-radius:var(--gs-bg-border-radius,0);box-shadow:var(--gs-bg-sec-shadow,none)}
#vs-sec-beauty_gallery .gs-beauty-sec-head{margin-bottom:var(--gs-bg-heading-gap,44px)}
#vs-sec-beauty_gallery .gs-beauty-eyebrow{color:var(--gs-bg-eyebrow-color,#C9A867)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'beauty_gallery_desc', '#vs-sec-beauty_gallery .gs-beauty-desc', [ 'font_size' => 16, 'color' => '#8A7B6C' ] ); ?>
.gs-beauty-gallery-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:var(--gs-bg-grid-gap,24px)}
@media(max-width:1024px){.gs-beauty-gallery-grid{grid-template-columns:repeat(2,1fr);gap:18px}}
@media(max-width:680px){.gs-beauty-gallery-grid{grid-template-columns:1fr;gap:16px}}
.gs-beauty-gallery-item{border-radius:var(--gs-bg-item-radius,4px);overflow:hidden;background:var(--beauty-ivory,#FAF7F2)}
.gs-beauty-gallery-item[style*="cursor:pointer"]{cursor:pointer}
.gs-beauty-gallery-link{display:block;aspect-ratio:4/5;overflow:hidden;cursor:zoom-in}
.gs-beauty-gallery-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s}
.gs-beauty-gallery-item:hover .gs-beauty-gallery-img{transform:scale(1.04)}
.gs-beauty-gallery-caption{font-family:'Jost',sans-serif;font-size:.82rem;font-weight:500;color:var(--gs-bg-caption-color,var(--beauty-charcoal));padding:12px 4px 4px}
.gs-beauty-ba-slider.vs-ida-ba-slider{position:relative;aspect-ratio:4/5;overflow:hidden;border-radius:var(--gs-bg-item-radius,4px);cursor:ew-resize;touch-action:none;user-select:none}
.gs-beauty-ba-img.vs-ida-ba-img{width:100%;height:100%;object-fit:cover;display:block;position:absolute;top:0;left:0}
.gs-beauty-ba-slider .vs-ida-ba-before-wrap{position:absolute;inset:0;overflow:hidden}
.gs-beauty-ba-handle.vs-ida-ba-handle{position:absolute;top:0;bottom:0;width:3px;background:var(--gs-bg-handle-color,var(--beauty-warm-white));transform:translateX(-50%);pointer-events:none}
.gs-beauty-ba-handle-grip.vs-ida-ba-handle-grip{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:40px;height:40px;border-radius:50%;background:var(--gs-bg-handle-color,var(--beauty-warm-white));display:flex;align-items:center;justify-content:center;font-size:1.1rem;box-shadow:0 4px 14px rgba(43,38,32,.25)}
.gs-beauty-ba-tag{position:absolute;top:14px;font-family:'Jost',sans-serif;font-size:.66rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--beauty-charcoal,#2B2620);background:var(--beauty-warm-white,#FFFDFB);padding:4px 10px;border-radius:999px;z-index:2}
.gs-beauty-ba-tag-before{left:14px}
.gs-beauty-ba-tag-after{right:14px}
@media(prefers-reduced-motion:reduce){.gs-beauty-gallery-img{transition:none}}
<?php endif; ?>

/* ── BEAUTY & SALON — SECTION 03 OF 6: BEAUTY EXPERTS / STYLISTS ── */
<?php if ( $_sec_show('beauty_experts') ): ?>
/* Section-scoped element/container/heading variables — isolated to THIS
   section only, same mechanism as beauty_facilities/beauty_services/
   beauty_gallery. */
#vs-sec-beauty_experts{<?php echo $cv_be_style_css . $cv_be_container_css . $cv_be_heading_css; ?>background:var(--gs-be-sec-bg,transparent);padding:var(--gs-be-pad-t,0) var(--gs-be-pad-r,0) var(--gs-be-pad-b,0) var(--gs-be-pad-l,0);border:var(--gs-be-border-w,0) solid var(--gs-be-border-color,transparent);border-radius:var(--gs-be-border-radius,0);box-shadow:var(--gs-be-sec-shadow,none)}
#vs-sec-beauty_experts .gs-beauty-sec-head{margin-bottom:var(--gs-be-heading-gap,44px)}
#vs-sec-beauty_experts .gs-beauty-eyebrow{color:var(--gs-be-eyebrow-color,#C9A867)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'beauty_experts_desc', '#vs-sec-beauty_experts .gs-beauty-desc', [ 'font_size' => 16, 'color' => '#8A7B6C' ] ); ?>
.gs-beauty-experts-grid{display:grid;grid-template-columns:repeat(var(--gs-be-grid-cols,4),1fr);gap:var(--gs-be-grid-gap,24px)}
@media(max-width:1200px){.gs-beauty-experts-grid{grid-template-columns:repeat(3,1fr)}}
@media(max-width:900px){.gs-beauty-experts-grid{grid-template-columns:repeat(2,1fr);gap:18px}}
@media(max-width:560px){.gs-beauty-experts-grid{grid-template-columns:1fr;gap:16px}}
.gs-beauty-expert-card{background:var(--beauty-warm-white,#FFFDFB);border:1px solid var(--gs-be-card-border,var(--beauty-line));border-radius:var(--gs-be-card-radius,4px);overflow:hidden;transition:box-shadow .25s,transform .25s}
.gs-beauty-expert-card:hover{box-shadow:0 18px 40px rgba(43,38,32,.1);transform:translateY(-3px)}
.gs-beauty-expert-media{position:relative;aspect-ratio:3/4;overflow:hidden;background:var(--beauty-ivory,#FAF7F2)}
.gs-beauty-expert-img{width:100%;height:100%;object-fit:cover;display:block}
.gs-beauty-expert-verified{position:absolute;bottom:12px;left:12px;font-family:'Jost',sans-serif;font-size:.68rem;font-weight:600;letter-spacing:.04em;color:var(--beauty-charcoal,#2B2620);background:var(--gs-be-verified-bg,var(--beauty-warm-white));padding:4px 10px;border-radius:999px}
.gs-beauty-expert-body{padding:20px}
.gs-beauty-expert-name{font-family:'Jost',sans-serif;font-size:1.02rem;font-weight:600;color:var(--gs-be-name-color,var(--beauty-charcoal))}
.gs-beauty-expert-role{font-size:.8rem;color:var(--gs-be-role-color,var(--beauty-taupe));margin-top:2px}
.gs-beauty-expert-rating{font-size:.82rem;font-weight:600;color:var(--beauty-champagne,#C9A867);margin-top:8px}
.gs-beauty-expert-tags{display:flex;flex-wrap:wrap;gap:6px;margin-top:12px}
.gs-beauty-expert-tag{font-size:.7rem;font-weight:500;color:var(--gs-be-tag-color,var(--beauty-charcoal));background:var(--gs-be-tag-bg,var(--beauty-ivory));padding:4px 9px;border-radius:999px}
.gs-beauty-expert-bio{font-size:.82rem;line-height:1.6;color:var(--beauty-taupe,#8A7B6C);margin-top:12px}
.gs-beauty-expert-meta{display:flex;flex-direction:column;gap:4px;margin-top:14px;font-size:.76rem;color:var(--beauty-taupe,#8A7B6C)}
.gs-beauty-expert-book-btn{font-family:'Jost',sans-serif;width:100%;margin-top:16px;font-size:.8rem;font-weight:600;color:var(--beauty-warm-white,#FFFDFB);background:var(--gs-be-book-bg,var(--beauty-charcoal));border:none;padding:12px;border-radius:2px;cursor:pointer;transition:background .2s;min-height:44px}
.gs-beauty-expert-book-btn:hover{background:var(--beauty-champagne,#C9A867)}
@media(prefers-reduced-motion:reduce){.gs-beauty-expert-card,.gs-beauty-expert-book-btn{transition:none}}
<?php endif; ?>

/* ── BEAUTY & SALON — SECTION 04 OF 6: SALON EXPERIENCE & FACILITIES ──
   Editorial split layout, deliberately not a generic icon-box grid. */
<?php if ( $_sec_show('beauty_facilities') ): ?>
/* Section-scoped element style variables — isolated to THIS section only.
   See gs_vs_section_style_vars() for why this can never leak into another
   section that happens to reuse the same class names or var() calls. */
#vs-sec-beauty_facilities{<?php echo $cv_bf_style_css . $cv_bf_container_css . $cv_bf_heading_css; ?>background:var(--gs-bf-sec-bg,transparent);padding:var(--gs-bf-pad-t,0) var(--gs-bf-pad-r,0) var(--gs-bf-pad-b,0) var(--gs-bf-pad-l,0);border:var(--gs-bf-border-w,0) solid var(--gs-bf-border-color,transparent);border-radius:var(--gs-bf-border-radius,0);box-shadow:var(--gs-bf-sec-shadow,none)}
/* Heading controls scoped to this section only — same shared classes
   (.gs-beauty-eyebrow/-title/-desc/-sec-head) are used by every other
   Beauty module, but this rule's higher specificity (ID ancestor + class)
   applies ONLY inside #vs-sec-beauty_facilities, so no other section's
   heading is affected by these vars. */
#vs-sec-beauty_facilities .gs-beauty-sec-head{margin-bottom:var(--gs-bf-heading-gap,44px)}
#vs-sec-beauty_facilities .gs-beauty-eyebrow{color:var(--gs-bf-eyebrow-color,#C9A867)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'beauty_facilities_desc', '#vs-sec-beauty_facilities .gs-beauty-desc', [ 'font_size' => 16, 'color' => '#8A7B6C' ] ); ?>
.gs-beauty-facilities-split{display:grid;grid-template-columns:1.1fr 1fr;gap:var(--gs-bf-split-gap,64px);align-items:stretch}
.gs-beauty-facilities-split.gs-beauty-facilities-no-img{grid-template-columns:1fr;max-width:640px}
@media(max-width:900px){.gs-beauty-facilities-split{grid-template-columns:1fr;gap:32px}}
/* Real fix: this box used to be a FIXED aspect-ratio:4/5 with the grid row
   set to align-items:center. Whenever the facilities checklist column was
   taller than that fixed 4:5 box (the common case), the grid row grew to
   match the taller column, and the media box was then centered inside
   that taller row — leaving blank space above/below it no matter what
   Image Fit was set to, because the box itself never grew past 4:5.
   align-items:stretch (grid's own default, which this rule was overriding)
   makes the box fill the full row height every time, so object-fit
   (cover/contain/fill) now actually controls the ENTIRE visible area with
   no leftover gap. min-height keeps the box from collapsing too short
   when the checklist has very few items. */
.gs-beauty-facilities-media{position:relative;min-height:360px;overflow:hidden;border-radius:var(--gs-bf-media-radius,6px);box-shadow:var(--gs-bf-media-shadow,0 24px 48px -20px rgba(43,38,32,.28))}
.gs-beauty-facilities-img{width:100%;height:100%;object-fit:cover;display:block}
.gs-beauty-facilities-list{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:1fr 1fr;gap:20px 28px}
@media(max-width:560px){.gs-beauty-facilities-list{grid-template-columns:1fr;gap:16px}}
.gs-beauty-facilities-item{display:flex;align-items:center;gap:14px;font-family:'Jost',sans-serif;font-size:var(--gs-bf-item-font-size,.92em);font-weight:500;line-height:1.3;color:var(--gs-bf-item-color,#2B2620)}
.gs-beauty-facilities-check{flex-shrink:0;width:var(--gs-bf-check-size,26px);height:var(--gs-bf-check-size,26px);border-radius:50%;background:var(--gs-bf-check-color,#C9A867);color:var(--beauty-warm-white,#FFFDFB);display:flex;align-items:center;justify-content:center;font-size:.76rem;box-shadow:0 4px 10px -2px rgba(201,168,103,.55)}
<?php endif; ?>

/* ── BEAUTY & SALON — SECTION 05 OF 6: BEAUTY PACKAGES & OFFERS ──
   Offer cards. No countdown timer or fabricated scarcity copy exists
   anywhere in this block — the only time/price signals are the plain
   "Valid until <real date>" badge and a plain-arithmetic savings line,
   both driven entirely by real vendor-entered values. */
<?php if ( $_sec_show('beauty_packages') ): ?>
#vs-sec-beauty_packages{<?php echo $cv_bp_style_css . $cv_bp_container_css . $cv_bp_heading_css; ?>background:var(--gs-bp-sec-bg,transparent);padding:var(--gs-bp-pad-t,0) var(--gs-bp-pad-r,0) var(--gs-bp-pad-b,0) var(--gs-bp-pad-l,0);border:var(--gs-bp-border-w,0) solid var(--gs-bp-border-color,transparent);border-radius:var(--gs-bp-border-radius,0);box-shadow:var(--gs-bp-sec-shadow,none)}
#vs-sec-beauty_packages .gs-beauty-sec-head{margin-bottom:var(--gs-bp-heading-gap,44px)}
#vs-sec-beauty_packages .gs-beauty-eyebrow{color:var(--gs-bp-eyebrow-color,#C9A867)}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'beauty_packages_desc', '#vs-sec-beauty_packages .gs-beauty-desc', [ 'font_size' => 16, 'color' => '#8A7B6C' ] ); ?>
.gs-beauty-pkg-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:var(--gs-bp-grid-gap,28px)}
.gs-beauty-pkg-card{background:var(--beauty-warm-white,#FFFDFB);border:1px solid var(--gs-bp-card-border,var(--beauty-line,#E7E0D6));border-radius:var(--gs-bp-card-radius,4px);overflow:hidden;display:flex;flex-direction:column;transition:box-shadow .25s,transform .25s}
.gs-beauty-pkg-card:hover{box-shadow:0 18px 40px -20px rgba(43,38,32,.25);transform:translateY(-2px)}
.gs-beauty-pkg-media{position:relative;aspect-ratio:4/3;overflow:hidden}
.gs-beauty-pkg-img{width:100%;height:100%;object-fit:cover;display:block}
.gs-beauty-pkg-badge{position:absolute;top:12px;left:12px;font-family:'Jost',sans-serif;font-size:.68rem;font-weight:600;letter-spacing:.04em;color:var(--gs-bp-badge-color,#FFFDFB);background:var(--gs-bp-badge-bg,#2B2620);padding:5px 12px;border-radius:999px}
.gs-beauty-pkg-badge-noimg{display:inline-block;margin:16px 16px 0}
.gs-beauty-pkg-body{padding:20px;display:flex;flex-direction:column;flex-grow:1}
.gs-beauty-pkg-name{font-family:'Jost',sans-serif;font-size:1.12rem;font-weight:600;color:var(--beauty-charcoal,#2B2620);margin-bottom:6px}
.gs-beauty-pkg-desc{font-size:.85rem;line-height:1.6;color:var(--beauty-taupe,#8A7B6C);margin-bottom:14px}
.gs-beauty-pkg-price-row{display:flex;align-items:baseline;gap:10px;margin-top:auto}
.gs-beauty-pkg-price-orig{font-size:.85rem;color:var(--beauty-taupe,#8A7B6C);text-decoration:line-through}
.gs-beauty-pkg-price-offer{font-family:'Jost',sans-serif;font-size:1.3rem;font-weight:600;color:var(--gs-bp-price-color,#2B2620)}
.gs-beauty-pkg-save{font-size:.76rem;font-weight:600;color:var(--gs-bp-save-color,#3F7D58);margin-top:4px}
.gs-beauty-pkg-valid{font-size:.74rem;color:var(--beauty-taupe,#8A7B6C);margin-top:6px}
.gs-beauty-pkg-cta{font-family:'Jost',sans-serif;width:100%;margin-top:16px;font-size:.8rem;font-weight:600;color:var(--beauty-warm-white,#FFFDFB);background:var(--gs-bp-cta-bg,#2B2620);border:none;padding:12px;border-radius:2px;cursor:pointer;transition:background .2s;min-height:44px}
.gs-beauty-pkg-cta:hover{background:var(--gs-bp-cta-hover-bg,#C9A867)}
@media(max-width:560px){.gs-beauty-pkg-grid{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.gs-beauty-pkg-card,.gs-beauty-pkg-cta{transition:none}}
<?php endif; ?>

/* ── BEAUTY & SALON — SECTION 06 OF 6: APPOINTMENT/BOOKING CONVERSION ──
   Closing CTA. The step list is populated server-side from real data
   (see the render block above) — no JS or CSS trick is used to fake
   step count here. */
<?php if ( $_sec_show('beauty_booking_cta') ): ?>
#vs-sec-beauty_booking_cta{<?php echo $cv_bc_style_css . $cv_bc_container_css . $cv_bc_heading_css; ?>background:var(--gs-bc-sec-bg,transparent);padding:var(--gs-bc-pad-t,0) var(--gs-bc-pad-r,0) var(--gs-bc-pad-b,0) var(--gs-bc-pad-l,0);border:var(--gs-bc-border-w,0) solid var(--gs-bc-border-color,transparent);border-radius:var(--gs-bc-border-radius,0);box-shadow:var(--gs-bc-sec-shadow,none)}
#vs-sec-beauty_booking_cta .gs-beauty-eyebrow{color:var(--gs-bc-eyebrow-color,#C9A867)}
.gs-beauty-cta{display:grid;grid-template-columns:1fr 1fr;gap:56px;align-items:center;background:var(--gs-bc-panel-bg,#FAF7F2);border-radius:var(--gs-bc-panel-radius,4px);padding:56px;overflow:hidden}
.gs-beauty-cta.gs-beauty-cta-no-img{grid-template-columns:1fr;max-width:680px;margin:0 auto;text-align:center}
@media(max-width:900px){.gs-beauty-cta{grid-template-columns:1fr;gap:28px;padding:36px 24px}}
.gs-beauty-cta-media{aspect-ratio:4/3;overflow:hidden;border-radius:var(--gs-bc-media-radius,4px)}
.gs-beauty-cta-img{width:100%;height:100%;object-fit:cover;display:block}
.gs-beauty-cta-steps{list-style:none;margin:20px 0 28px;padding:0;display:flex;flex-direction:column;gap:12px}
.gs-beauty-cta-no-img .gs-beauty-cta-steps{align-items:center}
.gs-beauty-cta-step{display:flex;align-items:center;gap:12px;font-family:'Jost',sans-serif;font-size:.9rem;color:var(--gs-bc-step-text-color,#2B2620)}
.gs-beauty-cta-step-num{flex-shrink:0;width:24px;height:24px;border-radius:50%;background:var(--gs-bc-step-num-bg,#2B2620);color:var(--gs-bc-step-num-color,#FFFDFB);display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:600}
.gs-beauty-cta-step-icon{font-size:1rem}
.gs-beauty-cta-btn{font-family:'Jost',sans-serif;font-size:.88rem;font-weight:600;letter-spacing:.02em;color:var(--beauty-warm-white,#FFFDFB);background:var(--gs-bc-btn-bg,#2B2620);border:none;padding:16px 36px;border-radius:2px;cursor:pointer;transition:background .2s;min-height:48px}
.gs-beauty-cta-btn:hover{background:var(--gs-bc-btn-hover-bg,#C9A867)}
@media(prefers-reduced-motion:reduce){.gs-beauty-cta-btn{transition:none}}
<?php endif; ?>

<?php
if ( ! function_exists( 'gs_wedding_card_style_vars' ) ) {
    /**
     * Config-floor "Card Styling" CSS custom properties for the 7
     * Events & Wedding sections brought up to ServicesModule's
     * enterprise bar (v7.308.0). Mirrors the exact resolution pattern
     * already used for svc_card_* in this file (see $cv_svc_card_bc /
     * $cv_svc_card_bw / $cv_svc_card_sh_key above): every value is
     * clamped/whitelisted server-side so a forged POST value (an
     * out-of-range width, or a shadow key like "xl-fake" that isn't a
     * real key in $shadow_map) can never reach the rendered CSS —
     * it safely falls back to this section's own default instead.
     * $defaults = ['bg'=>'#FDF8F3','radius'=>14,'border_width'=>1,'border_color'=>'#EDE1D3','shadow'=>'lg']
     */
    function gs_wedding_card_style_vars( array $cd, array $shadow_map, string $prefix, array $defaults ): string {
        // Real, deliberate choice: only emit a custom property when the
        // vendor actually set it. Several of these sections' default
        // "card" backgrounds are a gradient (wedding_closing_banner) or
        // a hardcoded value the type=color admin field cannot represent
        // — so an unset field must leave the original CSS default alone
        // (the var()'s own CSS-side fallback) rather than this PHP side
        // silently overwriting it with a flattened default. Same
        // "unset = use CSS default" discipline already established for
        // color fields in create-listing.php's clCollectData().
        $out = '';
        if ( isset( $cd[ $prefix . '_card_bg' ] ) && $cd[ $prefix . '_card_bg' ] !== '' ) {
            $out .= '--wedding-card-bg:' . esc_html( $cd[ $prefix . '_card_bg' ] ) . ';';
        }
        $radius = max( 0, min( 60, (int) ( $cd[ $prefix . '_card_radius' ] ?? $defaults['radius'] ) ) );
        $out   .= '--wedding-card-radius:' . $radius . 'px;';
        $bw     = max( 0, min( 8, (int) ( $cd[ $prefix . '_card_border_width' ] ?? $defaults['border_width'] ) ) );
        $out   .= '--wedding-card-border-width:' . $bw . 'px;';
        if ( isset( $cd[ $prefix . '_card_border_color' ] ) && $cd[ $prefix . '_card_border_color' ] !== '' ) {
            $out .= '--wedding-card-border-color:' . esc_html( $cd[ $prefix . '_card_border_color' ] ) . ';';
        }
        $sh_key = $cd[ $prefix . '_card_shadow' ] ?? $defaults['shadow'];
        // Whitelist check first: a forged/unknown value (e.g. "xl-fake")
        // is never looked up in $shadow_map at all — it falls straight
        // to this section's own default shadow key, exactly like
        // $cv_svc_icon_img_shadow's in_array() guard above.
        if ( ! in_array( $sh_key, [ 'none', 'sm', 'md', 'lg' ], true ) ) { $sh_key = $defaults['shadow']; }
        $sh_val = $shadow_map[ $sh_key ] ?? $shadow_map['none'];
        $out   .= '--wedding-card-shadow:' . esc_html( $sh_val ) . ';';
        return $out;
    }
}
if ( ! function_exists( 'gs_wedding_btn_style_vars' ) ) {
    /**
     * Config-floor button CSS custom properties (bg/text/radius — a
     * deliberate subset of ServicesModule's full 10-property button
     * system; see the version-bump changelog for the scoping
     * rationale) for the 3 Events & Wedding sections with a real
     * primary CTA button: wedding_packages, wedding_quote,
     * wedding_closing_banner. Same "only emit what's actually set"
     * discipline as gs_wedding_card_style_vars() above.
     */
    function gs_wedding_btn_style_vars( array $cd, string $prefix, array $defaults ): string {
        $out = '';
        if ( isset( $cd[ $prefix . '_btn_bg' ] ) && $cd[ $prefix . '_btn_bg' ] !== '' ) {
            $out .= '--wedding-btn-bg:' . esc_html( $cd[ $prefix . '_btn_bg' ] ) . ';';
        }
        if ( isset( $cd[ $prefix . '_btn_text_color' ] ) && $cd[ $prefix . '_btn_text_color' ] !== '' ) {
            $out .= '--wedding-btn-text:' . esc_html( $cd[ $prefix . '_btn_text_color' ] ) . ';';
        }
        $radius = max( 0, min( 60, (int) ( $cd[ $prefix . '_btn_radius' ] ?? $defaults['radius'] ) ) );
        $out   .= '--wedding-btn-radius:' . $radius . 'px;';
        return $out;
    }
}
?>
/* ── EVENTS & WEDDING — SCROLL REVEAL (section-level, not per-card) ──
   Restrained per the client brief: a single, shared, subtle treatment
   across all 12 sections rather than bespoke per-section variants.
   Default state is visible (opacity 1, no offset) so content is never
   stuck hidden if JS fails or the section starts in view — .is-visible
   only ever moves it *from* a slightly-reduced starting state, never
   the reverse, and prefers-reduced-motion disables the effect outright
   by matching the base (visible) state at all times. */
.gs-wedding-reveal{opacity:1;transform:none;transition:opacity .5s ease,transform .5s ease}
.gs-wedding-reveal.gs-wedding-reveal-pending{opacity:.4;transform:translateY(12px)}
.gs-wedding-reveal.is-visible{opacity:1;transform:none}
@media(prefers-reduced-motion:reduce){.gs-wedding-reveal,.gs-wedding-reveal.gs-wedding-reveal-pending{opacity:1;transform:none;transition:none}}
/* ── EVENTS & WEDDING — SECTION 01 OF 6: SIGNATURE PORTFOLIO ──
   CSS isolation: every selector below is scoped under .gs-wedding-*
   and/or #vs-sec-wedding_portfolio, matching the isolation approach
   used for every other category-specific section in this file. */
<?php if ( $_sec_show('wedding_portfolio') ): ?>
#vs-sec-wedding_portfolio{--wedding-bg:#FFFFFF;--wedding-surface:#FDF8F3;--wedding-text:#231A14;--wedding-muted:#7A6B60;--wedding-accent:#D97706;--wedding-border:#EDE1D3;--wedding-shadow:0 18px 40px rgba(35,26,20,.12);<?php echo gs_wedding_card_style_vars( $cd, $shadow_map, 'wedding_portfolio', [ 'bg' => '#FDF8F3', 'radius' => 10, 'border_width' => 0, 'border_color' => '#EDE1D3', 'shadow' => 'lg' ] ); ?>}
.gs-wedding-sec-head{max-width:680px;margin:0 0 40px}
.gs-wedding-eyebrow{font-size:.76rem;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--wedding-accent);margin-bottom:12px}
.gs-wedding-title{font-size:clamp(1.9rem,3.4vw,2.6rem);font-weight:700;letter-spacing:-.01em;line-height:1.2;color:var(--wedding-text)}
.gs-wedding-desc{margin-top:14px;font-size:1rem;line-height:1.7;color:var(--wedding-muted)}
.gs-wedding-tabs{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:30px;overflow-x:auto;-webkit-overflow-scrolling:touch;padding-bottom:2px}
.gs-wedding-tab{flex-shrink:0;font-size:.82rem;font-weight:600;letter-spacing:.02em;color:var(--wedding-muted);background:var(--wedding-surface);border:1px solid var(--wedding-border);border-radius:999px;padding:10px 20px;cursor:pointer;transition:background .2s,color .2s,border-color .2s;min-height:44px}
.gs-wedding-tab:hover{border-color:var(--wedding-accent);color:var(--wedding-text)}
.gs-wedding-tab.is-active{background:var(--wedding-accent);border-color:var(--wedding-accent);color:#fff}
.gs-wedding-portfolio-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:18px}
.gs-wedding-portfolio-item{position:relative;cursor:pointer;overflow:hidden;border-radius:var(--wedding-card-radius,10px);grid-column:span 2;aspect-ratio:3/4;background:var(--wedding-card-bg,var(--wedding-surface));border:var(--wedding-card-border-width,0) solid var(--wedding-card-border-color,var(--wedding-border));box-shadow:var(--wedding-card-shadow,var(--wedding-shadow))}
.gs-wedding-portfolio-item.is-featured{grid-column:span 4;grid-row:span 2;aspect-ratio:auto}
.gs-wedding-portfolio-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .35s}
.gs-wedding-portfolio-item:hover .gs-wedding-portfolio-img{transform:scale(1.04)}
.gs-wedding-portfolio-overlay{position:absolute;left:0;right:0;bottom:0;padding:36px 16px 14px;background:linear-gradient(180deg,rgba(35,26,20,0) 0%,rgba(35,26,20,.78) 100%);color:#fff;opacity:0;transform:translateY(6px);transition:opacity .25s,transform .25s}
.gs-wedding-portfolio-item:hover .gs-wedding-portfolio-overlay{opacity:1;transform:translateY(0)}
.gs-wedding-portfolio-cat{font-size:.68rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--wedding-accent);margin-bottom:4px}
.gs-wedding-portfolio-caption{font-size:.86rem;font-weight:600;line-height:1.4}
@media(max-width:900px){.gs-wedding-portfolio-grid{grid-template-columns:repeat(4,1fr)}.gs-wedding-portfolio-item.is-featured{grid-column:span 4;grid-row:span 1;aspect-ratio:16/10}.gs-wedding-portfolio-item{grid-column:span 2}}
@media(max-width:680px){.gs-wedding-portfolio-grid{grid-template-columns:1fr;gap:14px}.gs-wedding-portfolio-item,.gs-wedding-portfolio-item.is-featured{grid-column:span 1;grid-row:span 1;aspect-ratio:4/3}.gs-wedding-portfolio-overlay{opacity:1;transform:none}}
@media(prefers-reduced-motion:reduce){.gs-wedding-portfolio-img,.gs-wedding-portfolio-overlay{transition:none}}
/* Layout: masonry — reuses GalleryModule's own gallery_layout masonry
   mechanism verbatim (see .vs-gallery-grid/.vs-gallery-item above): a
   JS-free CSS grid trick, fine grid-auto-rows plus a fixed
   grid-row-end span per item, image aspect-ratio left auto — not CSS
   columns, since that isn't what the platform's own precedent uses. */
.gs-wedding-portfolio-layout-masonry{grid-auto-rows:10px}
.gs-wedding-portfolio-layout-masonry .gs-wedding-portfolio-item{grid-column:span 2;grid-row-end:span 24;aspect-ratio:auto}
.gs-wedding-portfolio-layout-masonry .gs-wedding-portfolio-item.is-featured{grid-column:span 2;grid-row-end:span 24}
@media(max-width:900px){.gs-wedding-portfolio-layout-masonry .gs-wedding-portfolio-item{grid-column:span 2}}
@media(max-width:680px){.gs-wedding-portfolio-layout-masonry .gs-wedding-portfolio-item{grid-column:span 1;grid-row-end:span 24;aspect-ratio:auto}}
<?php endif; ?>
<?php if ( $_sec_show('wedding_stories') ): ?>
#vs-sec-wedding_stories{--wedding-bg:#FFFFFF;--wedding-surface:#FDF8F3;--wedding-text:#231A14;--wedding-muted:#7A6B60;--wedding-accent:#D97706;--wedding-border:#EDE1D3;--wedding-shadow:0 18px 40px rgba(35,26,20,.12);<?php echo gs_wedding_card_style_vars( $cd, $shadow_map, 'wedding_stories', [ 'bg' => '#FDF8F3', 'radius' => 14, 'border_width' => 1, 'border_color' => '#EDE1D3', 'shadow' => 'lg' ] ); ?>}
.gs-wedding-stories-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
.gs-wedding-story-card{background:var(--wedding-card-bg,var(--wedding-surface));border:var(--wedding-card-border-width,1px) solid var(--wedding-card-border-color,var(--wedding-border));border-radius:var(--wedding-card-radius,14px);overflow:hidden;box-shadow:var(--wedding-card-shadow,var(--wedding-shadow));transition:transform .25s ease,box-shadow .25s ease}
.gs-wedding-story-card:hover{transform:translateY(-3px);box-shadow:0 24px 48px rgba(35,26,20,.18)}
.gs-wedding-story-cover{position:relative;display:block;width:100%;padding:0;margin:0;border:none;cursor:pointer;aspect-ratio:4/3;background:var(--wedding-surface)}
.gs-wedding-story-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .35s}
.gs-wedding-story-cover:hover .gs-wedding-story-img{transform:scale(1.04)}
.gs-wedding-story-badge{position:absolute;top:12px;left:12px;font-size:.68rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#fff;background:var(--wedding-accent);border-radius:999px;padding:5px 12px}
.gs-wedding-story-count{position:absolute;left:0;right:0;bottom:0;padding:28px 14px 12px;font-size:.8rem;font-weight:600;color:#fff;text-align:left;background:linear-gradient(180deg,rgba(35,26,20,0) 0%,rgba(35,26,20,.78) 100%)}
.gs-wedding-story-body{padding:16px 18px 20px}
.gs-wedding-story-title{font-size:1.06rem;font-weight:700;color:var(--wedding-text);line-height:1.35}
.gs-wedding-story-meta{margin-top:6px;font-size:.78rem;font-weight:600;letter-spacing:.02em;color:var(--wedding-accent)}
.gs-wedding-story-desc{margin-top:10px;font-size:.88rem;line-height:1.6;color:var(--wedding-muted)}
@media(max-width:900px){.gs-wedding-stories-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:680px){.gs-wedding-stories-grid{grid-template-columns:1fr;gap:16px}}
@media(prefers-reduced-motion:reduce){.gs-wedding-story-img,.gs-wedding-story-card{transition:none}}
<?php endif; ?>

/* ── EVENTS & WEDDING — SECTION 03 OF 6: SERVICES & EXPERIENCE ──
   CSS isolation: every selector below is scoped under .gs-wedding-*
   and/or #vs-sec-wedding_services, matching the isolation approach
   used for every other category-specific section in this file. The
   shared --wedding-* custom properties are redeclared here under this
   section's own id (never a duplicated literal hex value) exactly the
   way #vs-sec-wedding_stories redeclares them above. Deliberately
   text-forward: no images, no lightbox — just an optional tag badge,
   a title, and a description. */
<?php if ( $_sec_show('wedding_services') ): ?>
#vs-sec-wedding_services{--wedding-bg:#FFFFFF;--wedding-surface:<?php echo esc_html( $cd['wedding_services_card_bg'] ?? '#FDF8F3' ); ?>;--wedding-text:#231A14;--wedding-muted:#7A6B60;--wedding-accent:#D97706;--wedding-border:#EDE1D3;--wedding-shadow:0 18px 40px rgba(35,26,20,.12);--wedding-card-radius:<?php echo (int) ( $cd['wedding_services_card_radius'] ?? 14 ); ?>px}
.gs-wedding-services-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
.gs-wedding-service-card{background:var(--wedding-surface);border:1px solid var(--wedding-border);border-radius:var(--wedding-card-radius,14px);padding:0;box-shadow:var(--wedding-shadow);overflow:hidden;display:flex;flex-direction:column;transition:transform .25s ease,box-shadow .25s ease}
.gs-wedding-service-card:hover{transform:translateY(-3px);box-shadow:0 24px 48px rgba(35,26,20,.18)}
.gs-wedding-service-card-body{padding:26px 24px}
.gs-wedding-service-card:not(.gs-wedding-service-card-has-img) .gs-wedding-service-card-body{padding:26px 24px}
.gs-wedding-service-img-wrap{overflow:hidden;aspect-ratio:16/10}
.gs-wedding-service-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .35s ease}
.gs-wedding-service-card:hover .gs-wedding-service-img{transform:scale(1.06)}
.gs-wedding-service-tag{display:inline-block;font-size:.68rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#fff;background:var(--wedding-accent);border-radius:999px;padding:5px 12px;margin-bottom:14px}
.gs-wedding-service-title{font-size:1.08rem;font-weight:700;color:var(--wedding-text);line-height:1.35}
.gs-wedding-service-desc{margin-top:10px;font-size:.88rem;line-height:1.6;color:var(--wedding-muted)}
.gs-wedding-service-duration{margin-top:12px;font-size:.8rem;font-weight:700;color:var(--wedding-accent)}
.gs-wedding-service-enquire-btn{margin-top:16px;display:inline-flex;align-items:center;gap:6px;font-size:.82rem;font-weight:700;color:#fff;background:var(--wedding-accent);border:none;border-radius:8px;padding:10px 16px;cursor:pointer;transition:background .2s}
.gs-wedding-service-enquire-btn:hover{background:#B45309}
@media(prefers-reduced-motion:reduce){.gs-wedding-service-card,.gs-wedding-service-img{transition:none}}
@media(max-width:900px){.gs-wedding-services-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:680px){.gs-wedding-services-grid{grid-template-columns:1fr;gap:16px}}
<?php endif; ?>

/* ── EVENTS & WEDDING — SECTION 04 OF 6: PACKAGES & COLLECTIONS ──
   CSS isolation: every selector below is scoped under .gs-wedding-pkg-*
   and/or #vs-sec-wedding_packages, matching the isolation approach used
   for every other category-specific section in this file. The shared
   --wedding-* custom properties are redeclared here under this
   section's own id (never a duplicated literal hex value), same as
   every prior Events & Wedding section. No fake urgency anywhere: the
   only two price signals are a genuine strikethrough discount (real
   original vs. real, lower fixed price) and a plain "Starting from"
   prefix on a real minimum price — a "Price on Request" card carries
   no number at all. */
<?php if ( $_sec_show('wedding_packages') ): ?>
#vs-sec-wedding_packages{--wedding-bg:#FFFFFF;--wedding-surface:#FDF8F3;--wedding-text:#231A14;--wedding-muted:#7A6B60;--wedding-accent:#D97706;--wedding-border:#EDE1D3;--wedding-shadow:0 18px 40px rgba(35,26,20,.12);<?php echo gs_wedding_card_style_vars( $cd, $shadow_map, 'wedding_packages', [ 'bg' => '#FDF8F3', 'radius' => 14, 'border_width' => 1, 'border_color' => '#EDE1D3', 'shadow' => 'lg' ] ); echo gs_wedding_btn_style_vars( $cd, 'wedding_packages', [ 'bg' => '#D97706', 'text' => '#FFFFFF', 'radius' => 10 ] ); ?>}
.gs-wedding-pkg-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
.gs-wedding-pkg-card{display:flex;flex-direction:column;background:var(--wedding-card-bg,var(--wedding-surface));border:var(--wedding-card-border-width,1px) solid var(--wedding-card-border-color,var(--wedding-border));border-radius:var(--wedding-card-radius,14px);padding:26px 24px;box-shadow:var(--wedding-card-shadow,var(--wedding-shadow));transition:transform .25s ease,box-shadow .25s ease}
.gs-wedding-pkg-card:hover{transform:translateY(-3px);box-shadow:0 24px 48px rgba(35,26,20,.18)}
@media(prefers-reduced-motion:reduce){.gs-wedding-pkg-card{transition:none}}
.gs-wedding-pkg-tag{align-self:flex-start;display:inline-block;font-size:.68rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#fff;background:var(--wedding-accent);border-radius:999px;padding:5px 12px;margin-bottom:14px}
.gs-wedding-pkg-title{font-size:1.12rem;font-weight:700;color:var(--wedding-text);line-height:1.35}
.gs-wedding-pkg-desc{margin-top:10px;font-size:.88rem;line-height:1.6;color:var(--wedding-muted)}
.gs-wedding-pkg-price-row{margin-top:16px;display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.gs-wedding-pkg-price-orig{font-size:.92rem;color:var(--wedding-muted);text-decoration:line-through}
.gs-wedding-pkg-price-main{font-size:1.4rem;font-weight:800;color:var(--wedding-accent)}
.gs-wedding-pkg-price-prefix{font-size:.78rem;font-weight:600;letter-spacing:.02em;color:var(--wedding-muted);text-transform:uppercase}
.gs-wedding-pkg-price-quote{font-size:1rem;font-weight:700;color:var(--wedding-muted);font-style:italic}
.gs-wedding-pkg-save{margin-top:4px;font-size:.8rem;font-weight:600;color:#15803D}
.gs-wedding-pkg-includes{margin:16px 0 0;padding:0 0 0 18px;font-size:.85rem;line-height:1.7;color:var(--wedding-text)}
.gs-wedding-pkg-includes li{margin-bottom:2px}
.gs-wedding-pkg-cta{margin-top:20px;width:100%;padding:12px 18px;border-radius:var(--wedding-btn-radius,10px);border:none;background:var(--wedding-btn-bg,var(--wedding-accent));color:var(--wedding-btn-text,#fff);font-weight:700;font-size:.9rem;cursor:pointer;transition:opacity .2s,background .2s ease,transform .15s ease}
.gs-wedding-pkg-cta:hover{opacity:.88;transform:translateY(-1px)}
.gs-wedding-pkg-cta-quote{background:transparent;border:1.5px solid var(--wedding-accent);color:var(--wedding-accent)}
@media(prefers-reduced-motion:reduce){.gs-wedding-pkg-cta{transition:opacity .2s}.gs-wedding-pkg-cta:hover{transform:none}}
@media(max-width:900px){.gs-wedding-pkg-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:680px){.gs-wedding-pkg-grid{grid-template-columns:1fr;gap:16px}}
/* Layout: featured — directly reuses DoctorsModule's own featured-layout
   mechanism (.vs-hw-doctor-featured{grid-column:span 2}), applied to
   whichever package the vendor has marked 📌 in the admin panel. Border
   illumination on hover is reserved for this one already-special card,
   per the brief's "spend your boldness in one place" restraint. */
.gs-wedding-pkg-featured{grid-column:span 2}
.gs-wedding-pkg-featured:hover{box-shadow:0 0 0 2px var(--wedding-accent),0 24px 48px rgba(35,26,20,.18)}
@media(max-width:680px){.gs-wedding-pkg-featured{grid-column:span 1}}
<?php endif; ?>

/* ── EVENTS & WEDDING — SECTION 05 OF 6: EXPERIENCE & STYLE ──
   CSS isolation: every selector below is scoped under .gs-wedding-style-*
   and/or #vs-sec-wedding_style, matching every prior Events & Wedding
   section. The shared --wedding-* custom properties are redeclared here
   under this section's own id (never a duplicated literal hex value).
   Deliberately light section: a heading plus a wrapping row of chips —
   no images, no pricing, nothing heavier. */
<?php if ( $_sec_show('wedding_style') ): ?>
#vs-sec-wedding_style{--wedding-bg:#FFFFFF;--wedding-surface:<?php echo esc_html( $cd['wedding_style_card_bg'] ?? '#FDF8F3' ); ?>;--wedding-text:#231A14;--wedding-muted:#7A6B60;--wedding-accent:#D97706;--wedding-border:#EDE1D3;--wedding-shadow:0 18px 40px rgba(35,26,20,.12);--wedding-card-radius:<?php echo (int) ( $cd['wedding_style_card_radius'] ?? 14 ); ?>px}
.gs-wedding-style-row{display:flex;flex-wrap:wrap;justify-content:center;gap:14px}
.gs-wedding-style-chip{display:inline-block;font-size:.9rem;font-weight:600;color:var(--wedding-accent);background:var(--wedding-surface);border:1.5px solid var(--wedding-accent);border-radius:999px;padding:10px 22px;letter-spacing:.01em}
.gs-wedding-style-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px}
.gs-wedding-style-card{background:var(--wedding-surface);border:1px solid var(--wedding-border);border-radius:var(--wedding-card-radius,14px);box-shadow:var(--wedding-shadow);padding:18px 20px;transition:transform .2s ease,box-shadow .2s ease}
.gs-wedding-style-card:hover{transform:translateY(-3px);box-shadow:0 22px 44px rgba(35,26,20,.16)}
.gs-wedding-style-card-label{font-size:.98rem;font-weight:700;color:var(--wedding-text)}
.gs-wedding-style-card-desc{margin-top:6px;font-size:.82rem;line-height:1.55;color:var(--wedding-muted)}
@media(prefers-reduced-motion:reduce){.gs-wedding-style-card{transition:none}}
@media(max-width:900px){.gs-wedding-style-row{gap:10px}.gs-wedding-style-chip{font-size:.85rem;padding:9px 18px}.gs-wedding-style-grid{grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}}
@media(max-width:680px){.gs-wedding-style-row{gap:8px}.gs-wedding-style-chip{font-size:.8rem;padding:8px 14px}.gs-wedding-style-grid{grid-template-columns:1fr 1fr;gap:10px}}
<?php endif; ?>

/* ── EVENTS & WEDDING — SECTION 06 OF 6: TEAM / CREATIVE EXPERTS ──
   CSS isolation: every selector below is scoped under .gs-wedding-team-*
   and/or #vs-sec-wedding_team, matching every prior Events & Wedding
   section. The shared --wedding-* custom properties are redeclared here
   under this section's own id (never a duplicated literal hex value).
   A member with no photo gets a graceful initial-avatar fallback tile
   (.gs-wedding-team-img-fallback) rather than a broken image or being
   dropped — same rounded-square media box either way. */
<?php if ( $_sec_show('wedding_team') ): ?>
#vs-sec-wedding_team{--wedding-bg:#FFFFFF;--wedding-surface:#FDF8F3;--wedding-text:#231A14;--wedding-muted:#7A6B60;--wedding-accent:#D97706;--wedding-border:#EDE1D3;--wedding-shadow:0 18px 40px rgba(35,26,20,.12);<?php echo gs_wedding_card_style_vars( $cd, $shadow_map, 'wedding_team', [ 'bg' => '#FDF8F3', 'radius' => 14, 'border_width' => 1, 'border_color' => '#EDE1D3', 'shadow' => 'lg' ] ); ?>}
.gs-wedding-team-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
.gs-wedding-team-card{position:relative;background:var(--wedding-card-bg,var(--wedding-surface));border:var(--wedding-card-border-width,1px) solid var(--wedding-card-border-color,var(--wedding-border));border-radius:var(--wedding-card-radius,14px);overflow:hidden;box-shadow:var(--wedding-card-shadow,var(--wedding-shadow));text-align:center;transition:transform .25s ease,box-shadow .25s ease}
.gs-wedding-team-card:hover{transform:translateY(-3px);box-shadow:0 24px 48px rgba(35,26,20,.18)}
@media(prefers-reduced-motion:reduce){.gs-wedding-team-card,.gs-wedding-team-img{transition:none}}
.gs-wedding-team-img{width:100%;aspect-ratio:1/1;object-fit:cover;display:block;background:var(--wedding-border);transition:transform .35s ease}
.gs-wedding-team-card:hover .gs-wedding-team-img{transform:scale(1.05)}
.gs-wedding-team-img-fallback{display:flex;align-items:center;justify-content:center;font-size:2.6rem;font-weight:800;color:#fff;background:linear-gradient(135deg,var(--wedding-accent),#B45309)}
.gs-wedding-team-body{padding:20px 18px 24px}
.gs-wedding-team-name{font-size:1.05rem;font-weight:700;color:var(--wedding-text)}
.gs-wedding-team-role{margin-top:4px;font-size:.82rem;font-weight:600;letter-spacing:.02em;color:var(--wedding-accent)}
.gs-wedding-team-bio{margin-top:10px;font-size:.85rem;line-height:1.6;color:var(--wedding-muted)}
.gs-wedding-team-link{display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;margin-top:14px;border-radius:50%;border:1.5px solid var(--wedding-accent);color:var(--wedding-accent);text-decoration:none;font-size:1rem;transition:background .2s,color .2s}
.gs-wedding-team-link:hover{background:var(--wedding-accent);color:#fff}
@media(max-width:900px){.gs-wedding-team-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:680px){.gs-wedding-team-grid{grid-template-columns:1fr;gap:16px}}
/* Layout: featured — directly copies DoctorsModule's own featured-layout
   mechanism verbatim (.vs-hw-doctor-featured{grid-column:span 2}); the
   first team member in stored order gets the larger slot. */
.gs-wedding-team-featured{grid-column:span 2}
.gs-wedding-team-featured:hover{box-shadow:0 0 0 2px var(--wedding-accent),0 24px 48px rgba(35,26,20,.18)}
@media(max-width:680px){.gs-wedding-team-featured{grid-column:span 1}}
<?php endif; ?>

/* ── EVENTS & WEDDING — SECTION 07 OF 7: VENUE / EVENT SPECIALISATION ──
   CSS isolation: every selector below is scoped under .gs-wedding-venuespec-*
   and/or #vs-sec-wedding_venue_specialization, matching every prior
   Events & Wedding section. The shared --wedding-* custom properties are
   redeclared here under this section's own id (never a duplicated
   literal hex value). Render rule: a checked item WITH a note renders as
   a small card (.gs-wedding-venuespec-card); a checked item with no note
   renders as a plain pill chip (.gs-wedding-venuespec-chip) — the two
   freely mix in the same wrapping grid/flex row. */
<?php if ( $_sec_show('wedding_venue_specialization') ): ?>
#vs-sec-wedding_venue_specialization{--wedding-bg:#FFFFFF;--wedding-surface:<?php echo esc_html( $cd['wedding_venue_spec_card_bg'] ?? '#FDF8F3' ); ?>;--wedding-text:#231A14;--wedding-muted:#7A6B60;--wedding-accent:#D97706;--wedding-border:#EDE1D3;--wedding-shadow:0 18px 40px rgba(35,26,20,.12);--wedding-card-radius:<?php echo (int) ( $cd['wedding_venue_spec_card_radius'] ?? 14 ); ?>px}
.gs-wedding-venuespec-grid{display:flex;flex-wrap:wrap;gap:14px;justify-content:center;align-items:flex-start}
.gs-wedding-venuespec-chip{display:inline-flex;align-items:center;gap:8px;font-size:.9rem;font-weight:600;color:var(--wedding-accent);background:var(--wedding-surface);border:1.5px solid var(--wedding-accent);border-radius:999px;padding:10px 22px;letter-spacing:.01em;transition:transform .2s ease}
.gs-wedding-venuespec-chip:hover{transform:translateY(-2px)}
.gs-wedding-venuespec-chip-icon{font-size:1.05rem;line-height:1}
.gs-wedding-venuespec-card{text-align:left;min-width:220px;max-width:320px;background:var(--wedding-surface);border:1px solid var(--wedding-border);border-radius:var(--wedding-card-radius,14px);box-shadow:var(--wedding-shadow);padding:16px 18px;transition:transform .2s ease,box-shadow .2s ease}
.gs-wedding-venuespec-card:hover{transform:translateY(-3px);box-shadow:0 22px 44px rgba(35,26,20,.16)}
.gs-wedding-venuespec-card-icon{font-size:1.7rem;line-height:1;margin-bottom:8px}
.gs-wedding-venuespec-card-label{font-size:.95rem;font-weight:700;color:var(--wedding-text)}
.gs-wedding-venuespec-card-note{margin-top:6px;font-size:.82rem;line-height:1.55;color:var(--wedding-muted)}
@media(prefers-reduced-motion:reduce){.gs-wedding-venuespec-chip,.gs-wedding-venuespec-card{transition:none}}
@media(max-width:900px){.gs-wedding-venuespec-grid{gap:10px}.gs-wedding-venuespec-chip{font-size:.85rem;padding:9px 18px}.gs-wedding-venuespec-card{min-width:180px}}
@media(max-width:680px){.gs-wedding-venuespec-grid{gap:8px}.gs-wedding-venuespec-chip{font-size:.8rem;padding:8px 14px}.gs-wedding-venuespec-card{min-width:0;width:100%}}
<?php endif; ?>

/* ── EVENTS & WEDDING — SECTION 08 OF 8: LOCATION & DESTINATION COVERAGE ──
   CSS isolation: every selector below is scoped under .gs-wedding-location-*
   and/or #vs-sec-wedding_locations, matching every prior Events & Wedding
   section. The shared --wedding-* custom properties are redeclared here
   under this section's own id (never a duplicated literal hex value).
   Render rule: same visual family as Section 07 — a location WITH a note
   renders as a small card (.gs-wedding-location-card); a location with no
   note renders as a plain pill chip (.gs-wedding-location-chip). The
   "Available for Destination Weddings" flag gets a distinct, prominent
   accent-colored banner (.gs-wedding-location-badge) with its own icon,
   shown above the location grid — visually distinct from the plain chips/
   cards below it so it reads as a standout claim, not just another item. */
<?php if ( $_sec_show('wedding_locations') ): ?>
#vs-sec-wedding_locations{--wedding-bg:#FFFFFF;--wedding-surface:<?php echo esc_html( $cd['wedding_locations_card_bg'] ?? '#FDF8F3' ); ?>;--wedding-text:#231A14;--wedding-muted:#7A6B60;--wedding-accent:#D97706;--wedding-border:#EDE1D3;--wedding-shadow:0 18px 40px rgba(35,26,20,.12);--wedding-card-radius:<?php echo (int) ( $cd['wedding_locations_card_radius'] ?? 14 ); ?>px}
.gs-wedding-location-badge{display:flex;align-items:flex-start;gap:14px;max-width:640px;margin:0 auto 28px;background:linear-gradient(135deg,var(--wedding-accent),#B45309);color:#fff;border-radius:16px;padding:18px 22px;box-shadow:0 14px 32px rgba(217,119,6,.28)}
.gs-wedding-location-badge-icon{flex:none;font-size:1.6rem;line-height:1}
.gs-wedding-location-badge-title{font-size:1.02rem;font-weight:800;letter-spacing:.01em}
.gs-wedding-location-badge-note{margin-top:6px;font-size:.85rem;line-height:1.55;color:rgba(255,255,255,.9)}
.gs-wedding-location-grid{display:flex;flex-wrap:wrap;gap:14px;justify-content:center;align-items:flex-start}
.gs-wedding-location-grid-dense{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px}
.gs-wedding-location-chip{display:inline-block;font-size:.9rem;font-weight:600;color:var(--wedding-accent);background:var(--wedding-surface);border:1.5px solid var(--wedding-accent);border-radius:999px;padding:10px 22px;letter-spacing:.01em}
.gs-wedding-location-card{text-align:left;min-width:220px;max-width:320px;background:var(--wedding-surface);border:1px solid var(--wedding-border);border-radius:var(--wedding-card-radius,14px);box-shadow:var(--wedding-shadow);padding:16px 18px;transition:transform .2s ease,box-shadow .2s ease}
.gs-wedding-location-grid-dense .gs-wedding-location-card{max-width:none;min-width:0}
.gs-wedding-location-card:hover{transform:translateY(-3px);box-shadow:0 22px 44px rgba(35,26,20,.16)}
.gs-wedding-location-card-home{border-color:var(--wedding-accent);border-width:2px;box-shadow:0 20px 44px rgba(217,119,6,.22)}
.gs-wedding-location-home-badge{display:inline-block;font-size:.68rem;font-weight:800;letter-spacing:.04em;text-transform:uppercase;color:#fff;background:var(--wedding-accent);border-radius:999px;padding:4px 10px;margin-bottom:8px}
.gs-wedding-location-card-name{font-size:.95rem;font-weight:700;color:var(--wedding-text)}
.gs-wedding-location-card-note{margin-top:6px;font-size:.82rem;line-height:1.55;color:var(--wedding-muted)}
@media(prefers-reduced-motion:reduce){.gs-wedding-location-card{transition:none}}
@media(max-width:900px){.gs-wedding-location-badge{padding:16px 18px;gap:12px}.gs-wedding-location-grid{gap:10px}.gs-wedding-location-chip{font-size:.85rem;padding:9px 18px}.gs-wedding-location-card{min-width:180px}.gs-wedding-location-grid-dense{grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}}
@media(max-width:680px){.gs-wedding-location-badge{flex-direction:column;align-items:flex-start;gap:8px}.gs-wedding-location-grid{gap:8px}.gs-wedding-location-chip{font-size:.8rem;padding:8px 14px}.gs-wedding-location-card{min-width:0;width:100%}.gs-wedding-location-grid-dense{grid-template-columns:1fr}}
<?php endif; ?>

/* ── EVENTS & WEDDING — SECTION 10 OF 10: CHECK AVAILABILITY ──
   CSS isolation: every selector below is scoped under
   .gs-wedding-availability-* and/or #vs-sec-wedding_availability,
   matching every prior Events & Wedding section. The shared
   --wedding-* custom properties are redeclared here under this
   section's own id (never a duplicated literal hex value). No fake
   calendar grid here — a clean two-column card (copy left, date
   picker + CTA right), stacking on mobile. */
<?php if ( $_sec_show('wedding_availability') ): ?>
#vs-sec-wedding_availability{--wedding-bg:#FFFFFF;--wedding-surface:<?php echo esc_html( $cd['wedding_availability_card_bg'] ?? '#FDF8F3' ); ?>;--wedding-text:#231A14;--wedding-muted:#7A6B60;--wedding-accent:#D97706;--wedding-border:#EDE1D3;--wedding-shadow:0 18px 40px rgba(35,26,20,.12);--wedding-card-radius:<?php echo (int) ( $cd['wedding_availability_card_radius'] ?? 18 ); ?>px}
.gs-wedding-availability-steps{display:flex;flex-wrap:wrap;gap:20px;justify-content:center;max-width:900px;margin:0 auto 28px}
.gs-wedding-availability-step{flex:1 1 200px;min-width:180px;text-align:left}
.gs-wedding-availability-step-num{font-size:1.4rem;font-weight:800;color:var(--wedding-accent);line-height:1}
.gs-wedding-availability-step-title{margin-top:6px;font-size:.95rem;font-weight:700;color:var(--wedding-text)}
.gs-wedding-availability-step-body{margin-top:4px;font-size:.82rem;line-height:1.5;color:var(--wedding-muted)}
.gs-wedding-availability-card{display:grid;grid-template-columns:1.1fr .9fr;gap:32px;align-items:center;max-width:900px;margin:0 auto;background:var(--wedding-surface);border:1px solid var(--wedding-border);border-radius:var(--wedding-card-radius,18px);box-shadow:var(--wedding-shadow);padding:32px 36px}
.gs-wedding-availability-desc{font-size:1rem;line-height:1.65;color:var(--wedding-muted)}
.gs-wedding-availability-trust{margin-top:10px;font-size:.82rem;line-height:1.5;color:var(--wedding-accent);font-weight:600}
.gs-wedding-availability-action{display:flex;flex-direction:column;gap:12px}
.gs-wedding-availability-lbl{font-size:.8rem;font-weight:700;color:var(--wedding-text);text-transform:uppercase;letter-spacing:.04em}
.gs-wedding-availability-input{font-size:.95rem;padding:12px 14px;border:1.5px solid var(--wedding-border);border-radius:10px;background:var(--wedding-bg);color:var(--wedding-text)}
.gs-wedding-availability-btn{display:inline-block;font-size:.92rem;font-weight:700;color:#fff;background:var(--wedding-accent);border:none;border-radius:10px;padding:13px 20px;cursor:pointer;transition:background .2s ease,transform .15s ease}
.gs-wedding-availability-btn:hover{background:#B45309;transform:translateY(-1px)}
@media(prefers-reduced-motion:reduce){.gs-wedding-availability-btn{transition:background .2s}.gs-wedding-availability-btn:hover{transform:none}}
@media(max-width:900px){.gs-wedding-availability-card{grid-template-columns:1fr;gap:20px;padding:26px 24px}}
@media(max-width:680px){.gs-wedding-availability-card{padding:20px;border-radius:14px}.gs-wedding-availability-steps{gap:14px}}
<?php endif; ?>

/* ── EVENTS & WEDDING — SECTION 11 OF 11: REQUEST A QUOTE ──
   CSS isolation: every selector below is scoped under
   .gs-wedding-quote-* and/or #vs-sec-wedding_quote, matching every
   prior Events & Wedding section. The shared --wedding-* custom
   properties are redeclared here under this section's own id (never a
   duplicated literal hex value). This is meant to read as one of the
   more prominent conversion CTAs on the page — a full-bleed accent
   banner, not a plain white card like Section 10 — so its surface
   uses --wedding-accent as the banner background itself rather than
   only as a small button colour. */
<?php if ( $_sec_show('wedding_quote') ): ?>
#vs-sec-wedding_quote{--wedding-bg:#FFFFFF;--wedding-surface:#FDF8F3;--wedding-text:#231A14;--wedding-muted:#7A6B60;--wedding-accent:#D97706;--wedding-border:#EDE1D3;--wedding-shadow:0 24px 55px rgba(180,83,9,.28);<?php echo gs_wedding_card_style_vars( $cd, $shadow_map, 'wedding_quote', [ 'bg' => '#FFFFFF', 'radius' => 16, 'border_width' => 0, 'border_color' => '#EDE1D3', 'shadow' => 'md' ] ); echo gs_wedding_btn_style_vars( $cd, 'wedding_quote', [ 'bg' => '#231A14', 'text' => '#FFFFFF', 'radius' => 10 ] ); ?>}
#vs-sec-wedding_quote .vs-wrap{max-width:1100px}
.gs-wedding-quote-banner{display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:center;background:linear-gradient(135deg,var(--wedding-accent),#B45309);border-radius:22px;box-shadow:var(--wedding-shadow);padding:44px 48px;color:#fff}
.gs-wedding-quote-eyebrow{color:rgba(255,255,255,.85)}
.gs-wedding-quote-heading{color:#fff}
.gs-wedding-quote-desc{font-size:1rem;line-height:1.65;color:rgba(255,255,255,.9);margin-top:8px;max-width:44ch}
.gs-wedding-quote-form{display:flex;flex-direction:column;gap:14px;background:var(--wedding-card-bg,#fff);border:var(--wedding-card-border-width,0) solid var(--wedding-card-border-color,var(--wedding-border));border-radius:var(--wedding-card-radius,16px);padding:26px 28px;box-shadow:var(--wedding-card-shadow,0 10px 30px rgba(35,26,20,.18))}
.gs-wedding-quote-row{display:flex;flex-direction:column;gap:6px}
.gs-wedding-quote-lbl{font-size:.78rem;font-weight:700;color:var(--wedding-text);text-transform:uppercase;letter-spacing:.04em}
.gs-wedding-quote-input{font-size:.95rem;padding:11px 13px;border:1.5px solid var(--wedding-border);border-radius:10px;background:var(--wedding-surface);color:var(--wedding-text);font-family:inherit}
.gs-wedding-quote-textarea{resize:vertical;min-height:44px}
.gs-wedding-quote-btn{margin-top:4px;display:inline-block;font-size:.95rem;font-weight:700;color:var(--wedding-btn-text,#fff);background:var(--wedding-btn-bg,var(--wedding-text));border:none;border-radius:var(--wedding-btn-radius,10px);padding:14px 20px;cursor:pointer;transition:background .2s ease,transform .15s ease}
.gs-wedding-quote-btn:hover{background:#3a2b20;transform:translateY(-1px)}
@media(prefers-reduced-motion:reduce){.gs-wedding-quote-btn{transition:background .2s}.gs-wedding-quote-btn:hover{transform:none}}
@media(max-width:900px){.gs-wedding-quote-banner{grid-template-columns:1fr;gap:24px;padding:32px 28px}}
@media(max-width:680px){.gs-wedding-quote-banner{padding:22px;border-radius:16px}.gs-wedding-quote-form{padding:20px}}
<?php endif; ?>

/* ── EVENTS & WEDDING — PREMIUM CONVERSION BANNER (section 12 of 12,
   final) ── #vs-sec-wedding_closing_banner. This is the closing
   full-bleed bookend to Section 11's card-shaped form, so it is
   deliberately the boldest treatment of any wedding_* section: the
   whole section surface (not just a card inside it) is the
   --wedding-accent gradient, edge to edge within .vs-wrap, with large
   centered white type and a single high-contrast button. Shared
   --wedding-* custom properties are redeclared here under this
   section's own id, matching every prior Events & Wedding section. */
<?php if ( $_sec_show('wedding_closing_banner') ): ?>
#vs-sec-wedding_closing_banner{--wedding-bg:#FFFFFF;--wedding-surface:#FDF8F3;--wedding-text:#231A14;--wedding-muted:#7A6B60;--wedding-accent:#D97706;--wedding-border:#EDE1D3;--wedding-shadow:0 24px 55px rgba(180,83,9,.28);<?php echo gs_wedding_card_style_vars( $cd, $shadow_map, 'wedding_closing_banner', [ 'bg' => '#D97706', 'radius' => 26, 'border_width' => 0, 'border_color' => '#EDE1D3', 'shadow' => 'lg' ] ); echo gs_wedding_btn_style_vars( $cd, 'wedding_closing_banner', [ 'bg' => '#FFFFFF', 'text' => '#231A14', 'radius' => 12 ] ); ?>}
#vs-sec-wedding_closing_banner .vs-wrap{max-width:1100px;padding-top:0;padding-bottom:0}
.gs-wedding-closing-banner-inner{background:var(--wedding-card-bg,linear-gradient(135deg,var(--wedding-accent),#7C2D12));border:var(--wedding-card-border-width,0) solid var(--wedding-card-border-color,var(--wedding-border));border-radius:var(--wedding-card-radius,26px);box-shadow:var(--wedding-card-shadow,var(--wedding-shadow));padding:72px 48px;text-align:center;display:flex;flex-direction:column;align-items:center;gap:18px}
.gs-wedding-closing-banner-heading{color:#fff;font-size:2.4rem;line-height:1.2;max-width:26ch}
.gs-wedding-closing-banner-desc{color:rgba(255,255,255,.92);font-size:1.08rem;line-height:1.6;max-width:52ch;margin:0}
.gs-wedding-closing-banner-btn{margin-top:10px;display:inline-block;font-size:1.05rem;font-weight:800;color:var(--wedding-text);background:#fff;border:none;border-radius:12px;padding:18px 40px;cursor:pointer;box-shadow:0 14px 30px rgba(0,0,0,.22);transition:transform .2s,box-shadow .2s}
.gs-wedding-closing-banner-btn:hover{transform:translateY(-2px);box-shadow:0 18px 36px rgba(0,0,0,.28)}
@media(prefers-reduced-motion:reduce){.gs-wedding-closing-banner-btn{transition:box-shadow .2s}.gs-wedding-closing-banner-btn:hover{transform:none}}
@media(max-width:900px){.gs-wedding-closing-banner-inner{padding:52px 32px;border-radius:20px}.gs-wedding-closing-banner-heading{font-size:1.9rem}}
@media(max-width:680px){.gs-wedding-closing-banner-inner{padding:40px 22px;border-radius:16px;gap:14px}.gs-wedding-closing-banner-heading{font-size:1.5rem}.gs-wedding-closing-banner-desc{font-size:.95rem}.gs-wedding-closing-banner-btn{width:100%;padding:16px 20px}}
<?php endif; ?>

/* ── HOTELS / BANQUETS / HOSPITALITY, MODULE 6 — FINAL CONVERSION
   BANNER ── #vs-sec-hotel_closing_banner. Same full-bleed closing-
   bookend treatment as wedding_closing_banner (its exact precedent —
   see HotelClosingBannerModule's own docblock), reusing the same
   generic gs_wedding_card_style_vars()/gs_wedding_btn_style_vars()
   helpers under this section's own 'hotel_closing_banner' prefix and
   its own hospitality accent palette (amber/brown, matching
   .gs-hevs-*/.gs-hdin-*/.gs-hamn-*/.gs-hvt-* already used in this
   category) rather than the wedding accent. */
<?php if ( $_sec_show('hotel_closing_banner') ): ?>
#vs-sec-hotel_closing_banner{--wedding-bg:#FFFFFF;--wedding-surface:#FDF3E7;--wedding-text:#231A14;--wedding-muted:#7A6B60;--wedding-accent:#B45309;--wedding-border:#EDE1D3;--wedding-shadow:0 24px 55px rgba(180,83,9,.28);<?php echo gs_wedding_card_style_vars( $cd, $shadow_map, 'hotel_closing_banner', [ 'bg' => '#B45309', 'radius' => 26, 'border_width' => 0, 'border_color' => '#EDE1D3', 'shadow' => 'lg' ] ); echo gs_wedding_btn_style_vars( $cd, 'hotel_closing_banner', [ 'bg' => '#FFFFFF', 'text' => '#231A14', 'radius' => 12 ] ); ?>}
#vs-sec-hotel_closing_banner .vs-wrap{max-width:1100px;padding-top:0;padding-bottom:0}
.gs-hcb-inner{background:var(--wedding-card-bg,linear-gradient(135deg,var(--wedding-accent),#7C2D12));border:var(--wedding-card-border-width,0) solid var(--wedding-card-border-color,var(--wedding-border));border-radius:var(--wedding-card-radius,26px);box-shadow:var(--wedding-card-shadow,var(--wedding-shadow));padding:72px 48px;text-align:center;display:flex;flex-direction:column;align-items:center;gap:18px}
.gs-hcb-heading{color:#fff;font-size:2.4rem;line-height:1.2;max-width:26ch}
.gs-hcb-desc{color:rgba(255,255,255,.92);font-size:1.08rem;line-height:1.6;max-width:52ch;margin:0}
.gs-hcb-btn{margin-top:10px;display:inline-block;font-size:1.05rem;font-weight:800;color:var(--wedding-text);background:#fff;border:none;border-radius:12px;padding:18px 40px;cursor:pointer;box-shadow:0 14px 30px rgba(0,0,0,.22);transition:transform .2s,box-shadow .2s}
.gs-hcb-btn:hover{transform:translateY(-2px);box-shadow:0 18px 36px rgba(0,0,0,.28)}
@media(prefers-reduced-motion:reduce){.gs-hcb-btn{transition:box-shadow .2s}.gs-hcb-btn:hover{transform:none}}
@media(max-width:900px){.gs-hcb-inner{padding:52px 32px;border-radius:20px}.gs-hcb-heading{font-size:1.9rem}}
@media(max-width:680px){.gs-hcb-inner{padding:40px 22px;border-radius:16px;gap:14px}.gs-hcb-heading{font-size:1.5rem}.gs-hcb-desc{font-size:.95rem}.gs-hcb-btn{width:100%;padding:16px 20px}}
<?php endif; ?>

/* ── HOME SERVICES — MODULE 1: SERVICE CATALOGUE & PROBLEM SOLVER ──
   CSS isolation: every selector below is scoped under .gs-hsvc-* (a
   namespace unique to this build) — no global element selector
   (h1/h2/button/img/.card/.container/.row) is ever touched, per the
   master build prompt's explicit CSS-isolation mandate. */
<?php if ( $_sec_show('home_services_catalogue') ): ?>
:root{--hsvc-ink:#0F172A;--hsvc-muted:#5B6B82;--hsvc-line:#E2E8F0;--hsvc-surface:#F8FAFC;--hsvc-accent:#2563EB;--hsvc-accent-ink:#FFFFFF}
.gs-hsvc-catalogue{font-family:inherit}
.gs-hsvc-sec-head{max-width:680px;margin:0 0 36px}
.gs-hsvc-eyebrow{font-family:'Jost',sans-serif;font-size:.76rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--hsvc-accent);margin-bottom:12px}
.gs-hsvc-title{font-family:'Jost',sans-serif;font-size:clamp(1.8rem,3.2vw,2.5rem);font-weight:700;letter-spacing:-.01em;line-height:1.2;color:var(--hsvc-ink)}
.gs-hsvc-desc{margin-top:14px;font-size:1rem;line-height:1.7;color:var(--hsvc-muted)}
.gs-hsvc-problems{background:var(--hsvc-surface);border:1px solid var(--hsvc-line);border-radius:14px;padding:20px 22px;margin-bottom:28px}
.gs-hsvc-problems-label{font-family:'Jost',sans-serif;font-size:.86rem;font-weight:600;color:var(--hsvc-ink);margin-bottom:12px}
.gs-hsvc-problem-chips{display:flex;flex-wrap:wrap;gap:10px}
.gs-hsvc-problem-chip{font-size:.82rem;font-weight:500;color:var(--hsvc-ink);background:#fff;border:1px solid var(--hsvc-line);border-radius:999px;padding:9px 16px;cursor:pointer;transition:border-color .2s,background .2s,color .2s;min-height:40px}
.gs-hsvc-problem-chip:hover{border-color:var(--hsvc-accent);color:var(--hsvc-accent)}
.gs-hsvc-problem-chip.is-active{background:var(--hsvc-accent);border-color:var(--hsvc-accent);color:var(--hsvc-accent-ink)}
.gs-hsvc-tabs{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:28px;overflow-x:auto;-webkit-overflow-scrolling:touch;padding-bottom:2px}
.gs-hsvc-tab{font-family:'Jost',sans-serif;flex-shrink:0;font-size:.82rem;font-weight:500;letter-spacing:.02em;color:var(--hsvc-muted);background:transparent;border:1px solid var(--hsvc-line);border-radius:999px;padding:10px 20px;cursor:pointer;transition:background .2s,color .2s,border-color .2s;min-height:44px}
.gs-hsvc-tab:hover{border-color:var(--hsvc-accent);color:var(--hsvc-ink)}
.gs-hsvc-tab.is-active{background:var(--hsvc-ink);border-color:var(--hsvc-ink);color:#fff}
.gs-hsvc-grid{display:grid;grid-template-columns:repeat(var(--vs-home_services_catalogue-cols,3),1fr);gap:26px}
@media(max-width:900px){.gs-hsvc-grid{grid-template-columns:repeat(min(var(--vs-home_services_catalogue-cols,3),2),1fr);gap:20px}}
@media(max-width:680px){.gs-hsvc-grid{grid-template-columns:1fr;gap:16px}}
.gs-hsvc-card{background:#fff;border:1px solid var(--hsvc-line);border-radius:14px;overflow:hidden;display:flex;flex-direction:column;transition:box-shadow .25s,transform .25s}
.gs-hsvc-card:hover{box-shadow:0 16px 36px rgba(15,23,42,.1);transform:translateY(-3px)}
.gs-hsvc-card[hidden]{display:none}
.gs-hsvc-card-media{position:relative;aspect-ratio:4/3;overflow:hidden;background:var(--hsvc-surface)}
.gs-hsvc-card-img{width:100%;height:100%;object-fit:cover;display:block}
.gs-hsvc-card-flags{position:absolute;top:12px;left:12px;display:flex;flex-direction:column;gap:6px}
.gs-hsvc-flag{font-family:'Jost',sans-serif;font-size:.64rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:var(--hsvc-ink);background:#fff;padding:4px 10px;border-radius:999px;width:fit-content}
.gs-hsvc-card-body{padding:22px;flex:1;display:flex;flex-direction:column}
.gs-hsvc-card-cat{font-size:.72rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--hsvc-accent);margin-bottom:6px}
.gs-hsvc-card-name{font-family:'Jost',sans-serif;font-size:1.08rem;font-weight:700;color:var(--hsvc-ink);margin-bottom:8px}
.gs-hsvc-card-desc{font-size:.86rem;line-height:1.6;color:var(--hsvc-muted);margin-bottom:12px}
.gs-hsvc-card-includes{margin:0 0 14px;padding-left:18px;font-size:.82rem;line-height:1.7;color:var(--hsvc-muted)}
.gs-hsvc-card-meta{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:16px;font-size:.8rem;color:var(--hsvc-muted)}
.gs-hsvc-card-price{font-weight:700;color:var(--hsvc-ink)}
.gs-hsvc-card-ctas{display:flex;align-items:center;gap:12px;margin-top:auto;padding-top:14px;border-top:1px solid var(--hsvc-line)}
.gs-hsvc-cta-primary{font-family:'Jost',sans-serif;font-size:.8rem;font-weight:600;letter-spacing:.02em;color:var(--hsvc-ink);text-decoration:none;border-bottom:1.5px solid var(--hsvc-accent);padding-bottom:2px;min-height:44px;display:inline-flex;align-items:center}
.gs-hsvc-cta-secondary{font-family:'Jost',sans-serif;font-size:.8rem;font-weight:700;color:#fff;background:var(--hsvc-accent);padding:10px 18px;border-radius:8px;text-decoration:none;transition:background .2s;min-height:44px;display:inline-flex;align-items:center}
.gs-hsvc-cta-secondary:hover{background:#1D4ED8}
.gs-hsvc-cta-icon{width:40px;height:40px;border-radius:50%;border:1px solid var(--hsvc-line);display:flex;align-items:center;justify-content:center;text-decoration:none;font-size:1rem;flex-shrink:0}
.gs-hsvc-cta-icon:hover{border-color:var(--hsvc-accent);background:var(--hsvc-surface)}
@media(prefers-reduced-motion:reduce){.gs-hsvc-card,.gs-hsvc-tab,.gs-hsvc-problem-chip,.gs-hsvc-cta-secondary{transition:none}}
<?php endif; ?>

/* ── HOME SERVICES — PACKAGES & MAINTENANCE PLANS (Module 2) ──
   CSS isolation: every selector below is scoped under .gs-hpkg-* — no
   global element selector is ever touched. */
<?php if ( $_sec_show('home_services_packages') ): ?>
.gs-hpkg-eyebrow{font-family:'Jost',sans-serif;font-size:.76rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:#2563EB;margin-bottom:12px}
.gs-hpkg-title{font-family:'Jost',sans-serif;font-size:clamp(1.8rem,3.2vw,2.5rem);font-weight:700;letter-spacing:-.01em;line-height:1.2;color:#0F172A}
.gs-hpkg-desc{margin-top:14px;font-size:1rem;line-height:1.7;color:#5B6B82}
.gs-hpkg-sec-head{max-width:680px;margin:0 0 36px}
.gs-hpkg-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:28px}
.gs-hpkg-card{position:relative;background:#fff;border:1px solid #E2E8F0;border-radius:14px;overflow:hidden;display:flex;flex-direction:column;transition:box-shadow .25s,transform .25s}
.gs-hpkg-card:hover{box-shadow:0 16px 36px rgba(15,23,42,.1);transform:translateY(-3px)}
.gs-hpkg-recommended{border-color:#2563EB;box-shadow:0 0 0 2px #2563EB}
.gs-hpkg-rec-ribbon{position:absolute;top:14px;right:-32px;transform:rotate(45deg);background:#2563EB;color:#fff;font-family:'Jost',sans-serif;font-size:.66rem;font-weight:700;letter-spacing:.05em;text-transform:uppercase;padding:5px 40px;z-index:1}
.gs-hpkg-media{position:relative;aspect-ratio:4/3;overflow:hidden;background:#F8FAFC}
.gs-hpkg-img{width:100%;height:100%;object-fit:cover;display:block}
.gs-hpkg-badge{position:absolute;top:12px;left:12px;font-family:'Jost',sans-serif;font-size:.68rem;font-weight:600;letter-spacing:.04em;color:#fff;background:#0F172A;padding:5px 12px;border-radius:999px}
.gs-hpkg-badge-noimg{display:inline-block;margin:16px 16px 0}
.gs-hpkg-body{padding:22px;display:flex;flex-direction:column;flex-grow:1}
.gs-hpkg-type{font-size:.72rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:#2563EB;margin-bottom:6px}
.gs-hpkg-name{font-family:'Jost',sans-serif;font-size:1.12rem;font-weight:700;color:#0F172A;margin-bottom:8px}
.gs-hpkg-card-desc{font-size:.86rem;line-height:1.6;color:#5B6B82;margin-bottom:12px}
.gs-hpkg-price-row{display:flex;align-items:baseline;gap:10px}
.gs-hpkg-price-orig{font-size:.85rem;color:#94A3B8;text-decoration:line-through}
.gs-hpkg-price-offer{font-family:'Jost',sans-serif;font-size:1.3rem;font-weight:700;color:#0F172A}
.gs-hpkg-save{font-size:.76rem;font-weight:600;color:#15803D;margin-top:4px}
.gs-hpkg-visits{font-size:.8rem;color:#5B6B82;margin-top:10px}
.gs-hpkg-features{margin:12px 0 0;padding-left:18px;font-size:.82rem;line-height:1.7;color:#5B6B82}
.gs-hpkg-valid{font-size:.74rem;color:#94A3B8;margin-top:8px}
.gs-hpkg-cta{font-family:'Jost',sans-serif;width:100%;margin-top:16px;font-size:.8rem;font-weight:700;color:#fff;background:#2563EB;border:none;padding:12px;border-radius:8px;cursor:pointer;transition:background .2s;min-height:44px}
.gs-hpkg-cta:hover{background:#1D4ED8}
@media(max-width:560px){.gs-hpkg-grid{grid-template-columns:1fr}}
@media(prefers-reduced-motion:reduce){.gs-hpkg-card,.gs-hpkg-cta{transition:none}}
<?php endif; ?>

/* ── HOME SERVICES — TECHNICIANS & EXPERTS (Module 3) ──
   CSS isolation: every selector below is scoped under .gs-htech-* — no
   global element selector is ever touched. */
<?php if ( $_sec_show('home_services_technicians') ): ?>
.gs-htech-sec-head{max-width:680px;margin:0 0 36px}
.gs-htech-eyebrow{font-family:'Jost',sans-serif;font-size:.76rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:#2563EB;margin-bottom:12px}
.gs-htech-title{font-family:'Jost',sans-serif;font-size:clamp(1.8rem,3.2vw,2.5rem);font-weight:700;letter-spacing:-.01em;line-height:1.2;color:#0F172A}
.gs-htech-desc{margin-top:14px;font-size:1rem;line-height:1.7;color:#5B6B82}
.gs-htech-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:24px}
@media(max-width:1200px){.gs-htech-grid{grid-template-columns:repeat(3,1fr)}}
@media(max-width:900px){.gs-htech-grid{grid-template-columns:repeat(2,1fr);gap:18px}}
@media(max-width:560px){.gs-htech-grid{grid-template-columns:1fr;gap:16px}}
.gs-htech-card{background:#fff;border:1px solid #E2E8F0;border-radius:14px;overflow:hidden;transition:box-shadow .25s,transform .25s}
.gs-htech-card:hover{box-shadow:0 16px 36px rgba(15,23,42,.1);transform:translateY(-3px)}
.gs-htech-media{position:relative;aspect-ratio:3/4;overflow:hidden;background:#F8FAFC}
.gs-htech-img{width:100%;height:100%;object-fit:cover;display:block}
.gs-htech-verified{position:absolute;bottom:12px;left:12px;font-family:'Jost',sans-serif;font-size:.68rem;font-weight:600;letter-spacing:.04em;color:#fff;background:#0F172A;padding:4px 10px;border-radius:999px}
.gs-htech-body{padding:20px}
.gs-htech-name{font-family:'Jost',sans-serif;font-size:1.02rem;font-weight:700;color:#0F172A}
.gs-htech-role{font-size:.8rem;color:#5B6B82;margin-top:2px}
.gs-htech-rating{font-size:.82rem;font-weight:600;color:#B45309;margin-top:8px}
.gs-htech-bg-badge{display:inline-flex;align-items:center;gap:4px;font-size:.72rem;font-weight:700;color:#15803D;background:#F0FDF4;border:1px solid #BBF7D0;padding:4px 10px;border-radius:999px;margin-top:8px}
.gs-htech-tags{display:flex;flex-wrap:wrap;gap:6px;margin-top:12px}
.gs-htech-tag{font-size:.7rem;font-weight:500;color:#0F172A;background:#F8FAFC;padding:4px 9px;border-radius:999px}
.gs-htech-bio{font-size:.82rem;line-height:1.6;color:#5B6B82;margin-top:12px}
.gs-htech-meta{display:flex;flex-direction:column;gap:4px;margin-top:14px;font-size:.76rem;color:#5B6B82}
.gs-htech-book-btn{font-family:'Jost',sans-serif;width:100%;margin-top:16px;font-size:.8rem;font-weight:700;color:#fff;background:#2563EB;border:none;padding:12px;border-radius:8px;cursor:pointer;transition:background .2s;min-height:44px}
.gs-htech-book-btn:hover{background:#1D4ED8}
@media(prefers-reduced-motion:reduce){.gs-htech-card,.gs-htech-book-btn{transition:none}}
<?php endif; ?>

/* ── HOME SERVICES — LICENSE, INSURANCE & GUARANTEE (Module 4) ──
   CSS isolation: every selector below is scoped under .gs-hgty-* — no
   global element selector is ever touched. */
<?php if ( $_sec_show('home_services_guarantee') ): ?>
.gs-hgty-eyebrow{font-family:'Jost',sans-serif;font-size:.76rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:#2563EB;margin-bottom:12px}
.gs-hgty-title{font-family:'Jost',sans-serif;font-size:clamp(1.8rem,3.2vw,2.5rem);font-weight:700;letter-spacing:-.01em;line-height:1.2;color:#0F172A}
.gs-hgty-desc{margin-top:14px;font-size:1rem;line-height:1.7;color:#5B6B82;margin-bottom:28px}
.gs-hgty-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:24px}
.gs-hgty-tile{background:#F8FAFC;border:1px solid #E2E8F0;border-radius:14px;padding:22px 18px;text-align:center}
.gs-hgty-icon{font-size:1.8rem;margin-bottom:10px}
.gs-hgty-label{font-family:'Jost',sans-serif;font-size:.92rem;font-weight:700;color:#0F172A}
.gs-hgty-value{font-size:.8rem;color:#5B6B82;margin-top:4px}
.gs-hgty-guarantee{display:flex;align-items:flex-start;gap:16px;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:14px;padding:22px}
.gs-hgty-guarantee-icon{font-size:1.6rem;flex-shrink:0}
.gs-hgty-guarantee-text{font-size:.94rem;line-height:1.7;color:#1E3A5F;margin:0}
@media(max-width:560px){.gs-hgty-grid{grid-template-columns:repeat(2,1fr)}}
<?php endif; ?>

/* ── HOME SERVICES — BEFORE & AFTER WORK GALLERY (Module 5) ──
   CSS isolation: every selector below is scoped under .gs-hba-* except
   the fixed .vs-ida-ba-* integration-contract hook classes required by
   the shared window.vsIdaInitBeforeAfterSlider() engine — same
   documented exception BeautyGalleryModule already established. */
<?php if ( $_sec_show('home_services_before_after') ): ?>
.gs-hba-sec-head{margin-bottom:28px}
.gs-hba-eyebrow{font-family:'Jost',sans-serif;font-size:.76rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:#2563EB;margin-bottom:12px}
.gs-hba-title{font-family:'Jost',sans-serif;font-size:clamp(1.8rem,3.2vw,2.5rem);font-weight:700;letter-spacing:-.01em;line-height:1.2;color:#0F172A}
.gs-hba-desc{margin-top:14px;font-size:1rem;line-height:1.7;color:#5B6B82}
.gs-hba-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
@media(max-width:1024px){.gs-hba-grid{grid-template-columns:repeat(2,1fr);gap:18px}}
@media(max-width:680px){.gs-hba-grid{grid-template-columns:1fr;gap:16px}}
.gs-hba-item{border-radius:10px;overflow:hidden;background:#F8FAFC;border:1px solid #E2E8F0}
.gs-hba-link{display:block;aspect-ratio:4/3;overflow:hidden;cursor:zoom-in}
.gs-hba-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .4s}
.gs-hba-link:hover .gs-hba-img{transform:scale(1.04)}
.gs-hba-caption{padding:14px 16px}
.gs-hba-caption-title{font-size:.92rem;font-weight:700;color:#0F172A}
.gs-hba-caption-desc{font-size:.82rem;color:#5B6B82;margin-top:4px;line-height:1.5}
.gs-hba-ba-slider.vs-ida-ba-slider{position:relative;aspect-ratio:4/3;overflow:hidden;cursor:ew-resize;touch-action:none;user-select:none}
.gs-hba-ba-img.vs-ida-ba-img{width:100%;height:100%;object-fit:cover;display:block;position:absolute;top:0;left:0}
.gs-hba-ba-slider .vs-ida-ba-before-wrap{position:absolute;inset:0;overflow:hidden}
.gs-hba-ba-handle.vs-ida-ba-handle{position:absolute;top:0;bottom:0;width:3px;background:#fff;transform:translateX(-50%);pointer-events:none}
.gs-hba-ba-handle-grip.vs-ida-ba-handle-grip{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:40px;height:40px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:1.1rem;box-shadow:0 4px 14px rgba(15,23,42,.25)}
.gs-hba-ba-tag{position:absolute;top:14px;font-family:'Jost',sans-serif;font-size:.66rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:#0F172A;background:#fff;padding:4px 10px;border-radius:999px;z-index:2}
.gs-hba-ba-tag-before{left:14px}
.gs-hba-ba-tag-after{right:14px}
@media(prefers-reduced-motion:reduce){.gs-hba-img{transition:none}}
<?php endif; ?>

/* ── HEALTH & WELLNESS — DEPARTMENTS/SPECIALTIES (module 2 of 5) ── */
<?php if ( $_sec_show('departments') ): ?>
.vs-hw-dept-grid{display:grid;grid-template-columns:repeat(var(--vs-hw-dept-cols,3),1fr);gap:var(--vs-hw-dept-gap,24px)}
@media(max-width:900px){.vs-hw-dept-grid{grid-template-columns:repeat(min(var(--vs-hw-dept-cols,3),2),1fr)}}
@media(max-width:680px){.vs-hw-dept-grid{grid-template-columns:1fr;gap:var(--vs-hw-dept-gap-mobile,16px)}}
.vs-hw-dept-tile{background:#fff;border:1px solid #E2E8F0;border-radius:14px;overflow:hidden;transition:box-shadow .2s,transform .2s}
.vs-hw-dept-tile:hover{box-shadow:0 10px 28px rgba(15,23,42,.08);transform:translateY(-2px)}
.vs-hw-dept-img{width:100%;aspect-ratio:4/3;object-fit:cover;display:block}
.vs-hw-dept-img-placeholder{width:100%;aspect-ratio:4/3;display:flex;align-items:center;justify-content:center;font-size:2.4rem;background:linear-gradient(135deg,#EFF6FF,#DBEAFE)}
.vs-hw-dept-body{padding:22px}
.vs-hw-dept-name{font-size:1.15rem;font-weight:700;color:#0F172A;margin-bottom:8px}
.vs-hw-dept-desc{font-size:.88rem;line-height:1.55;color:#64748B;margin-bottom:12px}
.vs-hw-dept-count{font-size:.76rem;font-weight:700;color:#2563EB;margin-bottom:16px}
.vs-hw-dept-cta{display:inline-block;font-size:.84rem;font-weight:700;color:#2563EB;text-decoration:none;border-bottom:1.5px solid #2563EB;padding-bottom:1px}
<?php endif; ?>

/* ── HEALTH & WELLNESS — DOCTORS & HEALTHCARE PROFESSIONALS (module 3 of 5) ── */
<?php if ( $_sec_show('doctors') ): ?>
.vs-hw-doctors{display:grid;gap:24px}
.vs-hw-doctors-layout-grid{grid-template-columns:repeat(3,1fr)}
.vs-hw-doctors-layout-editorial{grid-template-columns:repeat(2,1fr)}
.vs-hw-doctors-layout-featured{grid-template-columns:repeat(3,1fr)}
@media(max-width:900px){.vs-hw-doctors-layout-grid,.vs-hw-doctors-layout-featured{grid-template-columns:repeat(2,1fr)}.vs-hw-doctors-layout-editorial{grid-template-columns:1fr}}
@media(max-width:680px){.vs-hw-doctors{grid-template-columns:1fr!important;gap:16px}}
.vs-hw-doctor-card{background:#fff;border:1px solid #E2E8F0;border-radius:14px;overflow:hidden;transition:box-shadow .2s,transform .2s}
.vs-hw-doctor-card:hover{box-shadow:0 10px 28px rgba(15,23,42,.08);transform:translateY(-2px)}
.vs-hw-doctor-featured{grid-column:span 2}
@media(max-width:680px){.vs-hw-doctor-featured{grid-column:span 1}}
.vs-hw-doctor-media{aspect-ratio:3/4;overflow:hidden;background:#F1F5F9}
.vs-hw-doctors-layout-editorial .vs-hw-doctor-media{aspect-ratio:16/10}
.vs-hw-doctor-img{width:100%;height:100%;object-fit:cover;display:block}
.vs-hw-doctor-img-placeholder{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:2.6rem;background:linear-gradient(135deg,#EFF6FF,#DBEAFE)}
.vs-hw-doctor-body{padding:22px}
.vs-hw-doctor-name{font-size:1.12rem;font-weight:700;color:#0F172A;margin-bottom:4px}
.vs-hw-doctor-title{font-size:.86rem;color:#2563EB;font-weight:600;margin-bottom:6px}
.vs-hw-doctor-dept{font-size:.78rem;color:#64748B;margin-bottom:12px}
.vs-hw-doctor-bio{font-size:.88rem;line-height:1.55;color:#64748B;margin-bottom:12px}
.vs-hw-doctor-exp{font-size:.76rem;font-weight:600;color:#0F172A;margin-bottom:10px}
.vs-hw-doctor-modes{display:flex;gap:14px;font-size:.78rem;color:#64748B;margin-bottom:16px}
.vs-hw-doctor-ctas{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
<?php endif; ?>

/* ── HEALTH & WELLNESS — FACILITIES & PATIENT EXPERIENCE (module 4 of 5) ── */
<?php if ( $_sec_show('patient_facilities') ): ?>
.vs-hw-fac-group-label{font-size:.8rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:#2563EB;margin:28px 0 14px;padding-top:20px;border-top:1px solid #E2E8F0}
.vs-hw-fac-group-label:first-child{margin-top:0;padding-top:0;border-top:none}
.vs-hw-facilities-inner{display:grid;gap:20px}
.vs-hw-facilities-layout-tabs .vs-hw-facilities-inner,.vs-hw-facilities-layout-split .vs-hw-facilities-inner{grid-template-columns:repeat(3,1fr)}
.vs-hw-facilities-layout-grid .vs-hw-facilities-inner{grid-template-columns:repeat(4,1fr)}
@media(max-width:900px){.vs-hw-facilities-layout-tabs .vs-hw-facilities-inner,.vs-hw-facilities-layout-split .vs-hw-facilities-inner{grid-template-columns:repeat(2,1fr)}.vs-hw-facilities-layout-grid .vs-hw-facilities-inner{grid-template-columns:repeat(3,1fr)}}
@media(max-width:680px){.vs-hw-facilities-inner{grid-template-columns:repeat(2,1fr)!important;gap:12px}}
.vs-hw-fac-card{background:#fff;border:1px solid #E2E8F0;border-radius:12px;overflow:hidden}
.vs-hw-facilities-layout-grid .vs-hw-fac-card{border:none;background:#F8FAFC;text-align:center;padding:20px 14px}
.vs-hw-fac-media{aspect-ratio:4/3;overflow:hidden;background:#F1F5F9}
.vs-hw-fac-img{width:100%;height:100%;object-fit:cover;display:block}
.vs-hw-fac-body{padding:18px}
.vs-hw-facilities-layout-grid .vs-hw-fac-body{padding:0}
.vs-hw-fac-icon{font-size:1.5rem;margin-bottom:8px}
.vs-hw-fac-name{font-size:.95rem;font-weight:700;color:#0F172A;margin-bottom:6px}
.vs-hw-fac-desc{font-size:.82rem;line-height:1.5;color:#64748B;margin-bottom:8px}
.vs-hw-fac-branch{font-size:.72rem;font-weight:600;color:#2563EB}
.vs-hw-gallery-subhead{font-size:.78rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#71717A;margin:40px 0 18px}
.vs-hw-fac-gallery{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
@media(max-width:900px){.vs-hw-fac-gallery{grid-template-columns:repeat(3,1fr)}}
@media(max-width:680px){.vs-hw-fac-gallery{grid-template-columns:repeat(2,1fr);gap:10px}}
.vs-hw-fac-gallery-item{position:relative;aspect-ratio:1/1;overflow:hidden;border-radius:10px;cursor:pointer}
.vs-hw-fac-gallery-img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .3s}
.vs-hw-fac-gallery-item:hover .vs-hw-fac-gallery-img{transform:scale(1.05)}
.vs-hw-fac-gallery-caption{position:absolute;left:0;right:0;bottom:0;background:linear-gradient(to top,rgba(0,0,0,.6),transparent);color:#fff;font-size:.7rem;font-weight:600;padding:14px 8px 6px}
<?php endif; ?>

/* ── HEALTH & WELLNESS — PATIENT JOURNEY/TREATMENT PROCESS (module 5 of 5) ── */
<?php if ( $_sec_show('patient_journey') ): ?>
.vs-hw-journey-num{font-size:.78rem;font-weight:800;letter-spacing:.03em;color:#93C5FD}
.vs-hw-journey-name{font-size:1.05rem;font-weight:700;color:#0F172A;margin-bottom:6px}
.vs-hw-journey-desc{font-size:.88rem;line-height:1.6;color:#64748B}
.vs-hw-journey-duration{margin-top:10px;font-size:.76rem;color:#2563EB;font-weight:600}

.vs-hw-journey-timeline{display:flex;gap:0;overflow-x:auto;padding-bottom:8px}
.vs-hw-journey-timeline .vs-hw-journey-step{position:relative;flex:1 0 220px;padding:0 20px 0 0}
.vs-hw-journey-timeline .vs-hw-journey-num{display:block;font-size:1.5rem;color:#2563EB;margin-bottom:10px}
.vs-hw-journey-timeline .vs-hw-journey-connector{position:absolute;top:13px;left:calc(1.5rem + 14px);right:20px;height:1.5px;background:#DBEAFE}
@media(max-width:900px){.vs-hw-journey-timeline{flex-direction:column;gap:28px}.vs-hw-journey-timeline .vs-hw-journey-connector{display:none}}

.vs-hw-journey-vertical{display:flex;flex-direction:column;gap:0}
.vs-hw-journey-vertical .vs-hw-journey-step{position:relative;display:flex;gap:22px;padding-bottom:32px}
.vs-hw-journey-vertical .vs-hw-journey-num{font-size:1.9rem;color:#DBEAFE;line-height:1;flex-shrink:0;width:56px}
.vs-hw-journey-vertical .vs-hw-journey-connector{position:absolute;top:38px;bottom:0;left:27px;width:1.5px;background:#DBEAFE}

.vs-hw-journey-horizontal{display:flex;gap:20px;overflow-x:auto;padding-bottom:12px}
.vs-hw-journey-horizontal .vs-hw-journey-step{flex:0 0 auto;width:min(280px,78vw);background:#F8FAFC;padding:22px;border-radius:12px}
.vs-hw-journey-horizontal .vs-hw-journey-num{display:block;font-size:1.6rem;color:#2563EB;margin-bottom:10px}
.vs-hw-journey-horizontal .vs-hw-journey-connector{display:none}
@media(max-width:680px){.vs-hw-journey-horizontal{flex-direction:column}.vs-hw-journey-horizontal .vs-hw-journey-step{width:100%}}
<?php endif; ?>

/* ── SCROLL PROGRESS BAR ─────────────────────────── */
.vs-scroll-progress{position:fixed;top:0;left:0;z-index:9999;height:3px;background:var(--vs-primary);width:0;transition:width .1s linear;pointer-events:none}

/* ── SOCIAL SHARE BAR ────────────────────────────── */
.vs-share-bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.vs-share-btn{display:inline-flex;align-items:center;gap:6px;padding:7px 14px;border-radius:8px;font-size:.78rem;font-weight:700;text-decoration:none;border:none;cursor:pointer;font-family:inherit;transition:.15s}
.vs-share-btn:hover{filter:brightness(1.12);transform:translateY(-1px)}

/* ── SOCIAL PROOF TOAST ──────────────────────────── */
/* ── ── ── */
/* ── View More Detail Popup ─────────────────────────────────────────── */
.vs-view-more-link{display:inline-block;margin-top:6px;font-size:.78rem;font-weight:700;color:var(--vs-svc-btn-color,var(--vs-primary,#2563EB));text-decoration:none}
.vs-view-more-link:hover{text-decoration:underline}
.vs-dp-overlay{display:none;position:fixed;inset:0;background:rgba(15,23,42,.65);backdrop-filter:blur(3px);z-index:99998;align-items:center;justify-content:center;padding:16px}
.vs-dp-overlay.open{display:flex;animation:vsDpFadeIn .2s ease}
@keyframes vsDpFadeIn{from{opacity:0}to{opacity:1}}
.vs-dp-sheet{background:#fff;border-radius:18px;width:100%;max-width:720px;max-height:92vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 24px 70px rgba(0,0,0,.3);animation:vsDpSlideUp .25s cubic-bezier(.16,1,.3,1)}
@keyframes vsDpSlideUp{from{opacity:0;transform:translateY(24px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}
.vs-dp-header{position:sticky;top:0;z-index:2;display:flex;align-items:center;justify-content:space-between;padding:16px 22px;background:#fff;border-bottom:1px solid #F1F5F9;flex-shrink:0}
.vs-dp-header-title{font-weight:800;font-size:1.05rem;color:#0F172A}
.vs-dp-close{background:#F1F5F9;border:none;width:32px;height:32px;border-radius:50%;cursor:pointer;font-size:.9rem;color:#475569;flex-shrink:0;transition:background .15s}
.vs-dp-close:hover{background:#E2E8F0}
.vs-dp-body{flex:1;overflow-y:auto;padding:0 22px 22px}
.vs-dp-hero{margin:0 -22px 20px;height:280px;max-height:280px;overflow:hidden}
/* Real feature — reusable popup image area, platform-level component
   used by Products & Services, Services, Packages, and any future
   section using this same detail popup. Single-image mode reuses
   .vs-dp-hero unchanged (zero visual change for the common case);
   multi-image mode adds real slider chrome, every image clickable to
   open the existing, already-proven vsLightbox() — not a new one. */
.vs-dp-hero img,.vs-dp-slider-track img{cursor:zoom-in}
.vs-dp-slider{position:relative;margin:0 -22px 20px;max-height:280px;overflow:hidden}
.vs-dp-slider-track{display:flex;height:280px;transition:transform .35s ease;will-change:transform}
.vs-dp-slider-track img{width:100%;height:100%;flex:0 0 100%;display:block}
.vs-dp-slider-arrow{position:absolute;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.5);color:#fff;border:none;width:38px;height:38px;border-radius:50%;font-size:1.3rem;cursor:pointer;z-index:2;display:flex;align-items:center;justify-content:center}
.vs-dp-slider-arrow:hover{background:rgba(0,0,0,.72)}
.vs-dp-slider-prev{left:12px}
.vs-dp-slider-next{right:12px}
.vs-dp-slider-dots{position:absolute;bottom:12px;left:50%;transform:translateX(-50%);display:flex;gap:6px;z-index:2}
.vs-dp-slider-counter{position:absolute;bottom:12px;left:50%;transform:translateX(-50%);z-index:2;background:rgba(0,0,0,.55);color:#fff;font-size:.72rem;font-weight:600;padding:4px 10px;border-radius:12px}
.vs-dp-slider-dot{width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.5);border:none;padding:0;cursor:pointer}
.vs-dp-slider-dot.active{background:#fff;width:18px;border-radius:4px;transition:width .2s}
@media(max-width:680px){.vs-dp-slider,.vs-dp-slider-track{height:200px;max-height:200px}}
.vs-dp-hero img{width:100%;height:100%;object-fit:cover;display:block}
.vs-dp-section{margin-top:var(--vs-dp-gap,22px);padding-top:var(--vs-dp-gap,22px);border-top:1px solid #F1F5F9}
.vs-dp-section:first-of-type{margin-top:0;padding-top:0;border-top:none}
.vs-dp-sec-head{display:flex;align-items:center;gap:10px;margin-bottom:12px}
.vs-dp-sec-icon{font-size:1.1rem;flex-shrink:0}
.vs-dp-sec-head h3{font-size:1rem;font-weight:800;color:#0F172A;margin:0}
.vs-dp-sec-body{font-size:.88rem;color:#334155;line-height:1.7}
.vs-dp-richtext p{margin-bottom:10px}
.vs-dp-richtext ul,.vs-dp-richtext ol{margin:0 0 10px 20px}
.vs-dp-richtext table{width:100%;border-collapse:collapse;margin-bottom:10px}
.vs-dp-richtext table td,.vs-dp-richtext table th{border:1px solid #E2E8F0;padding:6px 10px}
.vs-dp-list{margin:0;padding-left:20px}
.vs-dp-list li{margin-bottom:6px}
.vs-dp-table{width:100%;border-collapse:collapse;font-size:.85rem}
.vs-dp-table td{border:1px solid #E2E8F0;padding:8px 12px}
.vs-dp-table tr:first-child td{background:#F8FAFC;font-weight:700}
/* Specifications / Features table — real feature, explicitly requested.
   .vs-dp-specs-wrap gives its own horizontal scroll only if a value is
   genuinely too wide to wrap (rare — values wrap by default), so this
   table can never force the whole popup to scroll sideways on mobile. */
.vs-dp-specs-wrap{width:100%;overflow-x:auto}
.vs-dp-specs-table{width:100%;border-collapse:collapse;font-size:.85rem;table-layout:fixed}
.vs-dp-specs-table td{border:1px solid #E2E8F0;padding:10px 14px;vertical-align:top;word-break:break-word}
.vs-dp-specs-table td.vs-dp-specs-name{background:#F8FAFC;font-weight:700;color:#334155;width:38%}
.vs-dp-specs-table td.vs-dp-specs-value{color:#475569;line-height:1.6}
@media (max-width:640px){
  .vs-dp-specs-table{table-layout:auto}
  .vs-dp-specs-table td.vs-dp-specs-name{width:40%}
}
.vs-dp-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}
.vs-dp-card{background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;padding:16px}
.vs-dp-card-icon{font-size:1.4rem;margin-bottom:8px}
.vs-dp-card-title{font-weight:700;font-size:.88rem;color:#0F172A;margin-bottom:4px}
.vs-dp-card-text{font-size:.8rem;color:#64748B;line-height:1.5}
.vs-dp-gallery{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:8px}
.vs-dp-gallery img{width:100%;height:100px;object-fit:cover;border-radius:8px;cursor:pointer;transition:transform .15s}
.vs-dp-gallery img:hover{transform:scale(1.04)}
.vs-dp-highlight{display:flex;gap:12px;align-items:flex-start;border-radius:12px;padding:16px 18px;font-size:.85rem;color:#78350F;line-height:1.6}
.vs-dp-accordion{border:1px solid #E2E8F0;border-radius:10px;overflow:hidden}
.vs-dp-acc-item{border-bottom:1px solid #E2E8F0}
.vs-dp-acc-item:last-child{border-bottom:none}
.vs-dp-acc-q{width:100%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:#F8FAFC;border:none;padding:12px 16px;font-size:.85rem;font-weight:700;color:#1E293B;text-align:left;cursor:pointer}
.vs-dp-acc-arrow{transition:transform .2s;color:#475569;flex-shrink:0}
.vs-dp-acc-item.open .vs-dp-acc-arrow{transform:rotate(180deg)}
.vs-dp-acc-a{max-height:0;overflow:hidden;transition:max-height .25s ease;padding:0 16px;font-size:.83rem;color:#475569;line-height:1.6}
.vs-dp-acc-item.open .vs-dp-acc-a{max-height:500px;padding:12px 16px}
.vs-dp-empty{text-align:center;color:#475569;font-size:.85rem;padding:30px 10px}
.vs-dp-docs{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}
.vs-dp-doc-link{display:inline-flex;align-items:center;gap:6px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:7px 14px;font-size:.8rem;font-weight:600;color:#1D4ED8;text-decoration:none;transition:background .15s}
.vs-dp-doc-link:hover{background:#EFF6FF}

/* ── Client Reviews (inside the reused View Details popup) ── */
.vs-dp-reviews-loading,.vs-dp-reviews-empty{text-align:center;color:#475569;font-size:.85rem;padding:20px 10px}
.vs-dp-reviews-list{display:flex;flex-direction:column;gap:16px}
.vs-dp-review-card{padding-bottom:16px;border-bottom:1px solid #F1F5F9}
.vs-dp-review-card:last-child{border-bottom:none;padding-bottom:0}
.vs-dp-review-top{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:4px}
.vs-dp-review-name{font-weight:700;font-size:.92rem;color:#1E293B}
.vs-dp-review-rating{font-size:.78rem;font-weight:800;color:#fff;padding:2px 9px;border-radius:6px;display:inline-flex;align-items:center;gap:3px;flex-shrink:0}
.vs-dp-review-rating.good{background:#15803D}
.vs-dp-review-rating.mid{background:#B45309}
.vs-dp-review-rating.low{background:#B91C1C}
.vs-dp-review-date{font-size:.75rem;color:#475569;margin-bottom:8px}
.vs-dp-review-text{font-size:.86rem;color:#334155;line-height:1.65}
.vs-dp-reviews-more{display:block;margin:16px auto 0;padding:9px 22px;border-radius:8px;border:1.5px solid #E2E8F0;background:#F8FAFC;color:#1E293B;font-weight:700;font-size:.83rem;cursor:pointer;font-family:inherit;transition:.15s}
.vs-dp-reviews-more:hover{background:#EFF6FF;border-color:#BFDBFE}

.vs-dp-cta{position:sticky;bottom:0;background:#fff;border-top:1px solid #F1F5F9;padding:14px 22px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-shrink:0}
.vs-dp-cta-price{font-size:1.1rem;font-weight:800;color:#0F172A}

/* ── Booking Wizard ─────────────────────────────────────────────── */
.vs-bw-overlay{position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:100000;display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .25s ease;padding:16px}
.vs-bw-overlay.open{opacity:1}
.vs-bw-sheet{background:#fff;border-radius:18px;width:100%;max-width:620px;max-height:88vh;display:flex;flex-direction:column;overflow:hidden;transform:translateY(16px) scale(.98);transition:transform .25s ease;box-shadow:0 30px 80px rgba(0,0,0,.3)}
.vs-bw-overlay.open .vs-bw-sheet{transform:translateY(0) scale(1)}
.vs-bw-header{display:flex;align-items:center;gap:14px;padding:18px 20px 14px;border-bottom:1px solid #F1F5F9;flex-shrink:0}
.vs-bw-close{background:#F1F5F9;border:none;width:32px;height:32px;border-radius:50%;font-size:.85rem;cursor:pointer;flex-shrink:0;color:#647388;transition:.15s}
.vs-bw-close:hover{background:#E2E8F0;color:#1E293B}
.vs-bw-progress{display:flex;align-items:center;flex:1;overflow-x:auto}
.vs-bw-step{display:flex;flex-direction:column;align-items:center;gap:4px;flex-shrink:0;min-width:64px}
.vs-bw-step-dot{width:26px;height:26px;border-radius:50%;background:#F1F5F9;color:#475569;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:800;transition:.2s}
.vs-bw-step.active .vs-bw-step-dot{background:var(--vs-primary,#2563EB);color:#fff}
.vs-bw-step.done .vs-bw-step-dot{background:#DCFCE7;color:#166534}
.vs-bw-step-label{font-size:.62rem;color:#475569;font-weight:600;text-align:center}
.vs-bw-step.active .vs-bw-step-label{color:var(--vs-primary,#2563EB)}
.vs-bw-step-line{width:20px;height:2px;background:#F1F5F9;margin:0 2px 16px;flex-shrink:0}
.vs-bw-step-line.done{background:#86EFAC}
.vs-bw-body{overflow-y:auto;padding:24px 22px;flex:1}
.vs-bw-step-content{opacity:0;transition:opacity .2s ease}
.vs-bw-body.vs-bw-fade-in .vs-bw-step-content{opacity:1}
.vs-bw-title{font-size:1.25rem;font-weight:800;color:#0F172A;margin:0 0 18px}
.vs-bw-step-intro{font-size:.85rem;color:#64748B;line-height:1.6;margin:-12px 0 18px}
.vs-bw-subhead{font-size:.8rem;font-weight:700;color:#64748B;text-transform:uppercase;letter-spacing:.03em;margin-bottom:10px}
.vs-bw-meta-rows{margin:16px 0;display:flex;flex-direction:column;gap:8px}
.vs-bw-meta-row{display:flex;justify-content:space-between;align-items:baseline;gap:12px;padding:10px 14px;background:#F8FAFC;border-radius:8px;font-size:.84rem}
.vs-bw-meta-label{color:#64748B;font-weight:600}
.vs-bw-meta-value{color:#0F172A;font-weight:600;text-align:right}
.vs-bw-pkg-card{display:flex;gap:14px;background:#F8FAFC;border-radius:12px;padding:16px;margin-bottom:18px}
.vs-bw-pkg-img{width:72px;height:72px;border-radius:10px;object-fit:cover;flex-shrink:0}
.vs-bw-pkg-name{font-weight:800;font-size:1.02rem;color:#0F172A;margin-bottom:4px}
.vs-bw-pkg-price{font-weight:800;color:var(--vs-primary,#2563EB);margin-bottom:6px}
.vs-bw-pkg-price span{font-weight:600;color:#647388;font-size:.82rem}
.vs-bw-pkg-desc{font-size:.82rem;color:#64748B;line-height:1.5}
.vs-bw-feat-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px}
.vs-bw-feat-list li{font-size:.85rem;color:#334155;padding-left:20px;position:relative}
.vs-bw-feat-list li::before{content:"✓";position:absolute;left:0;color:#16A34A;font-weight:800}
.vs-bw-cal{border:1.5px solid #E2E8F0;border-radius:12px;padding:14px}
.vs-bw-cal-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
.vs-bw-cal-header strong{font-size:.92rem;color:#1E293B}
.vs-bw-cal-nav{width:30px;height:30px;border-radius:8px;border:1.5px solid #E2E8F0;background:#fff;font-size:1rem;color:#334155;cursor:pointer;font-family:inherit}
.vs-bw-cal-nav:hover:not(:disabled){border-color:var(--vs-primary,#2563EB);color:var(--vs-primary,#2563EB)}
.vs-bw-cal-nav:disabled{opacity:.35;cursor:not-allowed}
.vs-bw-cal-weekdays{display:grid;grid-template-columns:repeat(7,1fr);text-align:center;font-size:.68rem;font-weight:700;color:#475569;margin-bottom:4px}
.vs-bw-cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:4px}
.vs-bw-cal-day{aspect-ratio:1;border:none;background:none;border-radius:8px;font-size:.85rem;font-weight:600;color:#334155;cursor:pointer;font-family:inherit;transition:.15s}
.vs-bw-cal-day.empty{visibility:hidden;pointer-events:none}
.vs-bw-cal-day:hover:not(.disabled):not(.selected){background:#F1F5F9}
.vs-bw-cal-day.today{box-shadow:inset 0 0 0 1.5px var(--vs-primary,#2563EB)}
.vs-bw-cal-day.selected{background:var(--vs-primary,#2563EB);color:#fff}
.vs-bw-cal-day.disabled{color:#CBD5E1;cursor:not-allowed;text-decoration:line-through}
.vs-bw-slots{display:flex;flex-wrap:wrap;gap:8px}
.vs-bw-slot-chip{padding:9px 16px;border-radius:9px;border:1.5px solid #E2E8F0;background:#fff;font-size:.82rem;font-weight:600;color:#334155;cursor:pointer;font-family:inherit;transition:.15s}
.vs-bw-slot-chip:hover:not(.disabled){border-color:var(--vs-primary,#2563EB);color:var(--vs-primary,#2563EB)}
.vs-bw-slot-chip.selected{background:var(--vs-primary,#2563EB);border-color:var(--vs-primary,#2563EB);color:#fff}
.vs-bw-slot-chip.disabled,.vs-bw-slot-chip:disabled{opacity:.4;text-decoration:line-through;cursor:not-allowed}
.vs-bw-slots-placeholder{color:#475569;font-size:.85rem;padding:14px 0}
.vs-bw-addons-list{display:flex;flex-direction:column;gap:10px}
.vs-bw-addon-card{display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:12px;border:1.5px solid #E2E8F0;cursor:pointer;transition:.15s}
.vs-bw-addon-card.selected{border-color:var(--vs-primary,#2563EB);background:#F5F3FF}
.vs-bw-addon-card input{width:18px;height:18px;accent-color:var(--vs-primary,#2563EB);flex-shrink:0}
.vs-bw-addon-name{font-weight:700;font-size:.9rem;color:#1E293B}
.vs-bw-addon-price{font-weight:800;color:var(--vs-primary,#2563EB);margin-left:auto;flex-shrink:0}
.vs-bw-field{margin-bottom:16px}
.vs-bw-field label{display:block;font-size:.8rem;font-weight:700;color:#334155;margin-bottom:6px}
.vs-bw-field label span{font-weight:400;color:#475569}
.vs-bw-field input,.vs-bw-field textarea{width:100%;padding:11px 14px;border:1.5px solid #E2E8F0;border-radius:9px;font-size:.9rem;font-family:inherit;box-sizing:border-box}
.vs-bw-field input:focus,.vs-bw-field textarea:focus{outline:none;border-color:var(--vs-primary,#2563EB)}
.vs-bw-error{color:#DC2626;font-size:.82rem;min-height:18px;margin-bottom:6px}
.vs-bw-summary-block{background:#F8FAFC;border-radius:12px;padding:16px}
.vs-bw-sum-row{display:flex;justify-content:space-between;gap:12px;padding:6px 0;font-size:.88rem;color:#334155}
.vs-bw-sum-row span:first-child{color:#647388}
.vs-bw-divider{height:1px;background:#F1F5F9;margin:16px 0}
.vs-bw-sum-total{border-top:1.5px dashed #E2E8F0;margin-top:6px;padding-top:12px;font-size:1.05rem;font-weight:800;color:#0F172A}
.vs-bw-payment-note{font-size:.78rem;color:#647388;background:#FFFBEB;border:1px solid #FDE68A;border-radius:9px;padding:10px 14px;margin-top:14px;line-height:1.5}
.vs-bw-nav{display:flex;justify-content:space-between;align-items:center;padding:16px 22px;border-top:1px solid #F1F5F9;background:#fff;flex-shrink:0}
.vs-bw-btn-primary{background:var(--vs-primary,#2563EB);color:#fff;border:none;padding:12px 24px;border-radius:10px;font-weight:700;font-size:.9rem;cursor:pointer;font-family:inherit;transition:.15s}
.vs-bw-btn-primary:hover{filter:brightness(1.08)}
.vs-bw-btn-primary:disabled{opacity:.45;cursor:not-allowed}
.vs-bw-btn-secondary{background:#F1F5F9;color:#334155;border:none;padding:12px 22px;border-radius:10px;font-weight:700;font-size:.9rem;cursor:pointer;font-family:inherit;transition:.15s}
.vs-bw-btn-secondary:hover{background:#E2E8F0}
.vs-bw-confirmation{text-align:center;padding:20px 0}
.vs-bw-confirm-icon{width:64px;height:64px;border-radius:50%;background:#DCFCE7;color:#16A34A;font-size:1.8rem;font-weight:800;display:flex;align-items:center;justify-content:center;margin:0 auto 18px}
.vs-bw-confirm-sub{font-size:.88rem;color:#64748B;line-height:1.6;margin-bottom:18px}
@media(max-width:520px){
  .vs-bw-sheet{max-height:94vh;border-radius:14px}
  .vs-bw-step-label{display:none}
  .vs-bw-body{padding:20px 16px}
}
.vs-dp-cta-btn{background:var(--vs-primary,#2563EB);color:#fff;border:none;padding:11px 24px;border-radius:10px;font-weight:700;font-size:.88rem;cursor:pointer;white-space:nowrap;margin-left:auto;transition:transform .15s}
.vs-dp-cta-btn:hover{transform:scale(1.03)}
@media(max-width:600px){
  .vs-dp-overlay{padding:0;align-items:flex-end}
  .vs-dp-sheet{max-width:100%;max-height:92vh;border-radius:18px 18px 0 0}
  .vs-dp-hero{height:200px;max-height:200px}
  /* Real fix: a vendor-chosen column count (2/3/4) is a desktop inline
     style — without this override it would force too-narrow columns on
     small screens regardless of how many were chosen. */
  .vs-dp-cards{grid-template-columns:1fr!important}
}

.vs-inq-overlay{
  display:none;position:fixed;inset:0;
  background:<?php echo esc_attr($cv_popup_overlay); ?>;
  backdrop-filter:blur(4px);
  z-index:9998;align-items:center;justify-content:center;padding:16px;
  animation:none;
}
.vs-inq-overlay.open{display:flex}
.vs-inq-modal{
  background:<?php echo esc_attr($cv_popup_modal_bg); ?>;border-radius:16px;
  max-width:520px;width:100%;max-height:94vh;overflow-y:auto;
  box-shadow:0 20px 60px rgba(0,0,0,.22),0 4px 16px rgba(0,0,0,.08);
  position:relative;
  animation:vs-inq-in .22s cubic-bezier(.4,0,.2,1);
}
@keyframes vs-inq-in{from{opacity:0;transform:translateY(16px) scale(.97)}to{opacity:1;transform:none}}
/* Modal header — clean, professional, sober */
.vs-inq-header{
  background:var(--vs-inq-hdr-bg,<?php echo esc_attr($cv_popup_header_bg); ?>);
  padding:24px 28px 20px;
  border-radius:16px 16px 0 0;
  color:#fff;
  position:relative;
}
.vs-inq-header-top{display:flex;align-items:flex-start;gap:14px}
.vs-inq-icon-wrap{
  width:44px;height:44px;flex-shrink:0;
  background:rgba(255,255,255,.1);
  border:1px solid rgba(255,255,255,.15);
  border-radius:10px;
  display:flex;align-items:center;justify-content:center;
  font-size:1.3rem;
}
.vs-inq-title{font-size:1.05rem;font-weight:800;margin-bottom:3px;line-height:1.3;color:<?php echo esc_attr($cv_popup_header_text); ?>}
.vs-inq-sub{font-size:.81rem;color:<?php echo esc_attr($cv_popup_sub_color ?: 'rgba(255,255,255,.65)'); ?>;line-height:1.4}
.vs-inq-badge{
  display:inline-flex;align-items:center;gap:6px;
  background:#2D3D52;
  border:1px solid rgba(255,255,255,.1);
  border-radius:8px;padding:6px 12px;
  font-size:.77rem;font-weight:700;margin-top:10px;
  color:rgba(255,255,255,.85);
}
.vs-inq-close{
  position:absolute;top:14px;right:14px;
  background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.15);
  color:rgba(255,255,255,.8);border-radius:8px;
  width:30px;height:30px;font-size:.95rem;cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  transition:background .15s;line-height:1;
}
.vs-inq-close:hover{background:rgba(255,255,255,.2);color:#fff}
/* Modal body */
.vs-inq-body{padding:24px 28px 20px}
.vs-inq-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}
@media(max-width:480px){.vs-inq-row{grid-template-columns:1fr}}
<?php echo \GoodService\Service\TypographyService::css_rule( $cd, 'inq_label', '.vs-inq-lbl', [ 'font_size' => 12, 'font_weight' => '700', 'color' => '#64748B', 'text_transform' => 'uppercase', 'letter_spacing' => '0.05' ] ); ?>
.vs-inq-lbl{display:block;margin-bottom:5px}
.vs-inq-body .vs-input{margin-bottom:0;font-size:.87rem}
.vs-inq-body .vs-input:focus{border-color:#1E293B;box-shadow:0 0 0 3px rgba(30,41,59,.08)}
/* Submit button — professional dark */
<?php
$cv_inq_submit_size = max( 12, min( 20, (int) ( $cd['inq_submit_font_size'] ?? 15 ) ) );
$cv_inq_submit_weight = in_array( (string) ( $cd['inq_submit_font_weight'] ?? '800' ), ['400','500','600','700','800','900'], true ) ? (string) ( $cd['inq_submit_font_weight'] ?? '800' ) : '800';
$cv_inq_submit_ls = max( -0.05, min( 0.3, (float) ( $cd['inq_submit_letter_spacing'] ?? 0.03 ) ) );
$cv_inq_submit_font = trim( (string) ( $cd['inq_submit_font_family'] ?? '' ) );
$cv_inq_submit_font_stack = $cv_inq_submit_font !== '' ? \GoodService\Service\TypographyService::resolve_font_stack( $cv_inq_submit_font ) : 'inherit';
$cv_inq_submit_lh = max( 1, min( 2.4, (float) ( $cd['inq_submit_line_height'] ?? 1.2 ) ) );
?>
.vs-inq-submit-btn{
  background:<?php echo esc_attr( $cv_popup_btn_bg ?: '#1E293B' ); ?>;color:<?php echo esc_attr( $cv_popup_btn_text ?: '#ffffff' ); ?>;
  width:100%;padding:13px 20px;margin-top:16px;
  border:none;border-radius:10px;
  font-size:<?php echo $cv_inq_submit_size; ?>px;font-weight:<?php echo esc_attr($cv_inq_submit_weight); ?>;cursor:pointer;
  font-family:<?php echo esc_attr($cv_inq_submit_font_stack); ?>;letter-spacing:<?php echo $cv_inq_submit_ls; ?>em;line-height:<?php echo $cv_inq_submit_lh; ?>;
  transition:background .2s,transform .15s,box-shadow .15s;
  display:flex;align-items:center;justify-content:center;gap:8px;
}
.vs-inq-submit-btn:hover{background:#0F172A;transform:translateY(-1px);box-shadow:0 6px 20px rgba(15,23,42,.25)}
.vs-inq-submit-btn:disabled{opacity:.6;transform:none;cursor:not-allowed}
.vs-privacy{text-align:center;font-size:.71rem;color:#647388;margin-top:12px;display:flex;align-items:center;justify-content:center;gap:5px}

/* ── LIGHTBOX ────────────────────────────────────── */
#vs-lightbox{display:none;position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:999999;align-items:center;justify-content:center;cursor:zoom-out}
#vs-lightbox.open{display:flex}
#vs-lb-img{max-width:90vw;max-height:90vh;border-radius:10px;object-fit:contain}

/* ── UTILITY ─────────────────────────────────────── */
.vs-badge-verified{display:inline-flex;align-items:center;gap:4px;background:#ECFDF5;color:#059669;border-radius:99px;padding:3px 10px;font-size:.72rem;font-weight:700}
.vs-text-center{text-align:center}
@media(max-width:480px){.vs-btn-sm{font-size:.75rem;padding:6px 10px}}

/* ── CUSTOMIZER: Logo Styling ──────────────────── */
.vs-nav-brand img,.vs-listing-logo{
  border:<?php echo $cv_logo_bw;?>px solid <?php echo esc_attr($cv_logo_bc);?>;
  border-radius:<?php echo $cv_logo_r;?>px;
  padding:<?php echo $cv_logo_pad;?>px;
  background:<?php echo esc_attr($cv_logo_bg);?>;
  box-shadow:<?php echo esc_attr($cv_logo_shadow_val);?>;
}
/* ── CUSTOMIZER: Text Colors ──────────────────── */
.vs-sec-title,.vs-why-title,.vs-review-name,.vs-faq-q{color:var(--vs-heading,#1E293B)}
/* Real fix — removed an obsolete !important override that predated
   process_title_color existing at all. It was added as a safeguard so
   .vs-proc-title wouldn't inherit the generic heading-color rule above
   (meant for other, light-background sections), hardcoding white with
   !important so literally nothing could override it — including the
   vendor-controllable color this section now correctly supports. The
   rule at line ~1423 already falls back to #fff by default, so removing
   this preserves identical appearance for every listing that hasn't set
   a custom color, while finally letting the setting apply for ones that have. */
.vs-why-desc,.vs-review-text,.vs-faq-a,.vs-contact-meta{color:var(--vs-text,#475569)}
/* Real fix — .vs-stat-lbl removed from this generic list: it has its own
   dedicated, vendor-controllable color rule earlier in this file
   (stats_label_color), but this generic rule shared equal CSS
   specificity and came later in the cascade, so it silently won
   regardless of what a vendor set — the same bug class as the process
   title !important override, just via ordering instead. That earlier
   rule already falls back to the same rgba default, so this preserves
   identical appearance for listings that haven't set a custom color. */
.vs-sec-sub,.vs-item-cat,.vs-review-date,.vs-contact-lbl{color:var(--vs-muted,#64748B)}
/* Real fix — root cause of "footer link colors always show the theme
   accent blue no matter what a vendor sets": this generic rule gives
   every plain link the accent color by default, and only excluded
   buttons and the top nav. It never excluded footer links, which each
   have their OWN dedicated, vendor-controllable color rule (services,
   quick links, about text, base footer color) further down in this
   file — e.g. .vs-footer-links--services li a{color:#e30202}. Those
   rules use one class + two tags (specificity 0,1,2), but this rule
   uses two :not() pseudo-classes (specificity 0,2,2), which is HIGHER
   — so this rule silently won regardless of source order, and every
   footer link rendered in the accent color's fallback blue (#2563EB)
   even when a vendor picked red/magenta/anything else. Verified via
   the browser's own Styles panel: the vendor's color rule showed
   struck-through/losing under this exact selector. Adding the footer
   exclusion here means this element no longer matches this rule at
   all, so the cascade correctly falls through to the footer's own
   dedicated color rules instead. */
a:not(.vs-btn):not(.vs-nav-links a):not(.vs-footer-links a){color:var(--vs-accent,#2563EB)}
/* ── CUSTOMIZER: Gallery image radius ──────────── */
.vs-gallery-item img{border-radius:var(--vs-card-img-radius,0)}
.vs-item-img img{border-radius:var(--vs-card-img-radius,0) var(--vs-card-img-radius,0) 0 0}
/* ── CUSTOMIZER: Why card border/shadow ──────── */
.vs-why-card{background:#fff;border:1.5px solid var(--vs-card-border,#E2E8F0);border-radius:var(--vs-card-radius,16px)}
.vs-why-card:hover{box-shadow:var(--vs-card-shadow,0 6px 20px rgba(0,0,0,.07))}
/* ── CUSTOMIZER: Button styling ──────────────── */
.vs-btn-primary{background:var(--vs-btn-bg,var(--vs-primary));color:var(--vs-btn-text,#fff);border-radius:var(--vs-btn-radius,8px)}

/* ── MOBILE VIEW SETTINGS ─────────────────────── */
<?php if (!$mv_show_trust): ?>
@media(max-width:768px){ .vs-trust-bar { display:none !important; } }
<?php endif; ?>
<?php if (!$mv_show_stats): ?>
@media(max-width:768px){ #vs-sec-stats { display:none !important; } }
<?php endif; ?>
<?php if (!$mv_show_gallery): ?>
@media(max-width:768px){ #vs-sec-gallery { display:none !important; } }
<?php endif; ?>
<?php if (!$mv_show_proc): ?>
@media(max-width:768px){ #vs-sec-process { display:none !important; } }
<?php endif; ?>
<?php if (!$mv_show_why): ?>
@media(max-width:768px){ #vs-sec-why { display:none !important; } }
<?php endif; ?>
<?php if (!$mv_show_faq): ?>
/* FAQ visible on all screen sizes */
<?php endif; ?>
<?php if (!$mv_show_rev): ?>
/* Reviews section visible on all screens */
/* ── RATING SUMMARY WIDGET ──────────────────────────────────────── */
.vs-rev-header{display:flex;align-items:flex-start;gap:40px;margin-bottom:40px;background:#fff;border:1.5px solid #E2E8F0;border-radius:18px;padding:28px 32px;box-shadow:0 2px 12px rgba(0,0,0,.05)}
@media(max-width:600px){.vs-rev-header{flex-direction:column;gap:20px;padding:20px}}
.vs-rev-summary{text-align:center;min-width:100px;flex-shrink:0}
.vs-rev-big-score{font-size:3.5rem;font-weight:900;color:var(--vs-dark);line-height:1}
.vs-rev-big-stars{font-size:1.4rem;margin:6px 0 4px}
.vs-rev-count{font-size:.82rem;color:#64748B;font-weight:600}
.vs-rev-bars{flex:1;display:flex;flex-direction:column;gap:6px;justify-content:center}
.vs-rev-bar-row{display:flex;align-items:center;gap:8px}
.vs-rev-bar-lbl{font-size:.78rem;color:#64748B;width:28px;text-align:right;flex-shrink:0}
.vs-rev-bar-track{flex:1;height:8px;background:#F1F5F9;border-radius:4px;overflow:hidden}
.vs-rev-bar-fill{height:100%;background:#F59E0B;border-radius:4px;transition:width .4s ease}
.vs-rev-bar-cnt{font-size:.74rem;color:#647388;width:18px;flex-shrink:0}
/* ── REVIEW CARDS ───────────────────────────────────────────────── */
.vs-review-card{background:<?php echo esc_attr($cv_reviews_card_bg); ?>;border:1.5px solid <?php echo esc_attr($cv_reviews_card_bc); ?>;border-radius:14px;padding:20px;display:flex;flex-direction:column;gap:0;transition:box-shadow .2s;box-shadow:0 1px 4px rgba(0,0,0,.04)}
.vs-review-card:hover{box-shadow:0 4px 16px rgba(0,0,0,.1);border-color:#C8D5E8}
.vs-review-head{display:flex;align-items:flex-start;gap:12px;margin-bottom:12px}
.vs-review-text{font-size:.85rem;color:#475569;line-height:1.7;border-top:1px solid #F1F5F9;padding-top:12px;margin-top:4px}
<?php
// Real fix — .vs-review-card/.vs-review-name/.vs-review-text are defined
// 3 times in this file (legacy evolution), each with slightly different
// values. CSS cascade means the LAST one (right above) always wins for
// anything it sets. Placing these new rules immediately after it
// guarantees they take final precedence over all 3 duplicates without
// needing to untangle that pre-existing legacy duplication.
echo \GoodService\Service\TypographyService::css_rule( $cd, 'review_name', '.vs-review-name', [ 'font_size' => 14, 'font_weight' => '700', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'review_text', '.vs-review-text', [ 'font_size' => 14, 'font_weight' => '400', 'color' => '#475569', 'line_height' => '1.7' ] );
// team-name/role and portfolio-title had zero styling control before.
echo \GoodService\Service\TypographyService::css_rule( $cd, 'team_name', '.vs-team-name', [ 'font_size' => 15, 'font_weight' => '800', 'color' => '#1E293B' ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'team_role', '.vs-team-role', [ 'font_size' => 13, 'font_weight' => '700', 'color' => esc_attr( $brand_color ) ] );
echo \GoodService\Service\TypographyService::css_rule( $cd, 'portfolio_title', '.vs-portfolio-title', [ 'font_size' => 16, 'font_weight' => '800', 'color' => '#1E293B', 'line_height' => '1.4' ] );
?>
<?php endif; ?>
<?php if (!$mv_show_map): ?>
@media(max-width:768px){ .vs-map-wrap { display:none !important; } }
<?php endif; ?>
@media(max-width:768px){
  .vs-hero-inner{min-height:<?php echo $mv_hero_h;?>px}
  .vs-hero-right-img{height:<?php echo $mv_hero_h;?>px}
  .vs-hero-left{min-height:<?php echo $mv_hero_h;?>px}
  html .gs-vs{font-size:<?php echo ($mv_font_scale*100);?>%}
  .vs-items-grid{grid-template-columns:repeat(<?php echo $mv_items_cols;?>,1fr) !important}
  .vs-gallery-grid{grid-template-columns:repeat(<?php echo $mv_gallery_cols;?>,1fr) !important}
  <?php if ( $_sec_show('services') ): ?>
  .vs-svc-grid{grid-template-columns:repeat(2,1fr) !important}
  <?php endif; ?>

/* ── REVIEW FORM ──────────────────────────────────────────────── */
.vs-review-form-wrap{margin-top:36px;text-align:center}
.vs-review-form-toggle{display:inline-flex;align-items:center;gap:8px;padding:12px 28px;background:var(--vs-primary);color:#fff;border:none;border-radius:10px;font-size:.9rem;font-weight:700;cursor:pointer;transition:all .2s;font-family:inherit}
.vs-review-form-toggle:hover{filter:brightness(1.1);transform:translateY(-2px)}
.vs-review-form-box{max-width:620px;margin:20px auto 0;background:#fff;border:1.5px solid #E2E8F0;border-radius:16px;padding:32px;box-shadow:0 4px 20px rgba(0,0,0,.07);text-align:left}
.vs-review-form-title{font-size:1.05rem;font-weight:800;color:var(--vs-dark);margin-bottom:20px;text-align:center}
.vs-review-stars-pick{display:flex;justify-content:center;gap:8px;margin-bottom:8px}
.vs-star-pick{font-size:2.4rem;color:#D1D5DB;cursor:pointer;transition:color .12s,transform .12s;display:inline-block;line-height:1}
.vs-star-pick.lit{color:#F59E0B}
.vs-star-pick:hover{transform:scale(1.2)}
.vs-review-star-hint{text-align:center;font-size:.8rem;color:#647388;margin-bottom:20px}
.vs-review-form-fields{display:flex;flex-direction:column;gap:12px;margin-bottom:16px}
.vs-review-submit-btn{width:100%;padding:13px 20px;background:var(--vs-dark,#1E3A5F);color:#fff;border:none;border-radius:10px;font-size:.92rem;font-weight:700;cursor:pointer;transition:background .2s;font-family:inherit}
.vs-review-submit-btn:hover{background:var(--vs-primary)}
/* ── FLUENT FORM compact file upload ─────────────────────────── */
.ff-el-input--file input[type=file]{padding:6px 10px!important;height:36px!important;line-height:1!important;font-size:.82rem!important;cursor:pointer}
.fluentform .ff-el-input--file .ff-upload-btn{padding:4px 12px!important;font-size:.82rem!important;height:32px!important;line-height:32px!important}

/* ── Fixed nav scroll offset — sections must not hide under the nav ── */
html{scroll-padding-top:80px}
[id^="vs-sec-"]{scroll-margin-top:80px}
html.gsab-on{scroll-padding-top:112px}
html.gsab-on [id^="vs-sec-"]{scroll-margin-top:112px}

/* Admin bar offset for fixed nav */
html.gsab-on .vs-nav{top:32px}
html.gsab-on .gs-vs{padding-top:98px}   /* 66px nav + 32px adminbar */
</style>
<?php
$_main_css_raw = ob_get_clean();
$_gs_vs_css_filtered = gs_vs_filter_css_by_visibility( $_main_css_raw, $_sec_show );
// Real feature — minification can be disabled instantly in the future via
// this filter (e.g. add_filter('gs_vs_minify_css_enabled', '__return_false')
// in a theme's functions.php, a small debug plugin, or WP-CLI) — no need
// to edit this function or find this call site again. Defaults to on.
echo apply_filters( 'gs_vs_minify_css_enabled', true ) ? gs_vs_minify_css_safe( $_gs_vs_css_filtered ) : $_gs_vs_css_filtered;
?>
<?php if ( $_template_css ): ?>
<style id="gs-template-css">
<?php echo wp_strip_all_tags( $_template_css ); ?>
</style>
<?php endif; ?>
<?php
$_custom_css = trim( $primary->custom_css ?? '' );
if ( $_custom_css ):
?>
<style id="vs-custom-css">
/* ── Vendor Custom CSS ─────────────────────────────────────────────── */
<?php echo wp_strip_all_tags( $_custom_css ); ?>
</style>
<?php endif; ?>

<div class="gs-vs" style="padding-top:66px" id="gs-vs-root">

<!-- ══ NAV ═══════════════════════════════════════════════════════ -->
<nav class="vs-nav">
  <div class="vs-wrap">
    <div class="vs-nav-inner">
      <?php
      /* Clean listing URL — the canonical /{slug}/ form (never /listing/slug/) */
      $listing_clean_url = $primary
          ? esc_url( home_url( '/' . ltrim( $primary->slug, '/' ) . '/' ) )
          : esc_url( home_url( '/' ) );
      ?>
      <a href="<?php echo $listing_clean_url; ?>" class="vs-nav-brand" style="text-decoration:none;">
        <?php if ($logo):
          // Real fix, PageSpeed audit: always above-the-fold, same proven
          // cached-dimension pattern already used for hero/about images.
          $_navlogo_dim_w = $cv_logo_w; $_navlogo_dim_h = $cv_logo_h;
          if ( $_navlogo_dim_w <= 0 || $_navlogo_dim_h <= 0 ) {
              $_navlogo_dim_cache_key = 'gs_navlogo_dim_' . md5( $logo );
              $_navlogo_dim = get_transient( $_navlogo_dim_cache_key );
              if ( $_navlogo_dim === false ) {
                  $_navlogo_dim = @getimagesize( $logo ) ?: [ 0, 0 ];
                  set_transient( $_navlogo_dim_cache_key, $_navlogo_dim, 30 * DAY_IN_SECONDS );
              }
              if ( $_navlogo_dim_w <= 0 && ! empty( $_navlogo_dim[0] ) ) { $_navlogo_dim_w = (int) $_navlogo_dim[0]; }
              if ( $_navlogo_dim_h <= 0 && ! empty( $_navlogo_dim[1] ) ) { $_navlogo_dim_h = (int) $_navlogo_dim[1]; }
          }
        ?>
          <!-- Logo exists: show logo only, no text -->
          <img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?>"<?php if($_navlogo_dim_w>0): ?> width="<?php echo (int)$_navlogo_dim_w; ?>"<?php endif; ?><?php if($_navlogo_dim_h>0): ?> height="<?php echo (int)$_navlogo_dim_h; ?>"<?php endif; ?>>
        <?php else: ?>
          <!-- No logo: show business name only, no initials circle -->
          <div class="vs-nav-brand-name vs-nav-brand-name--standalone"><?php echo esc_html( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?></div>
        <?php endif; ?>
      </a>
      <div class="vs-nav-links" id="vsNavLinks">
        <?php foreach ($nav as $id => $label):
          // Strip the inq_ prefix used for inquiry module nav entries
          $_nav_sec_key = strpos($id, 'inq_') === 0 ? 'inquiry_modules' : $id;
          // Skip nav link if section is hidden
          if ( ! $_sec_show( $_nav_sec_key ) ) { continue; }
        ?>
          <a href="#vs-sec-<?php echo esc_attr($id); ?>"><?php echo esc_html($label); ?></a>
        <?php endforeach; ?>
      </div>
      <!-- Real fix: header CTAs, previously removed with nothing in their
           place — now a prominent Download App button plus a genuine
           hamburger menu, since the nav links above disappear completely on
           mobile (.vs-nav-links{display:none}) with no alternative access. -->
      <div class="vs-nav-ctas">
        <button type="button" id="vsNavInstallBtn" class="vs-btn vs-btn-primary vs-nav-install-btn" aria-label="Install app" onclick="if(typeof gsInstallPWA==='function')gsInstallPWA();">
          <span aria-hidden="true">⬇</span> <span class="vs-nav-install-label">Download App</span>
        </button>
        <button type="button" id="vsNavHamburger" class="vs-nav-hamburger" aria-label="Open menu" aria-expanded="false" onclick="vsToggleMobileNav()">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </div>
</nav>
<script>
(function(){
  // Real fix: previously hidden by default and only revealed once Chrome's
  // own beforeinstallprompt event had already fired — but gsInstallPWA()
  // now has a real, helpful fallback for every case (native prompt, iOS
  // instructions, or generic "look for the install icon" guidance), so
  // there's no longer a reason to hide the button while waiting on Chrome's
  // own internal timing. Visible by default now, matching what was
  // actually requested ("prominent"); only hidden when the app is already
  // installed, where showing an install button makes no sense at all.
  function isStandalone(){
    return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  }
  function maybeHideInstallBtn(){
    var btn = document.getElementById('vsNavInstallBtn');
    if (btn && isStandalone()) { btn.style.display = 'none'; }
  }
  document.addEventListener('DOMContentLoaded', maybeHideInstallBtn);
  maybeHideInstallBtn();

  window.vsToggleMobileNav = function(){
    var links = document.getElementById('vsNavLinks');
    var btn = document.getElementById('vsNavHamburger');
    if (!links || !btn) return;
    var open = links.classList.toggle('vs-nav-links-open');
    btn.classList.toggle('vs-nav-hamburger-open', open);
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  };
})();
</script>

<?php
// ── Visible breadcrumb bar ────────────────────────────────────────────────
// Confirmed real gap: the BreadcrumbList schema (further down this same
// render path, in Router.php) existed with no matching visible HTML —
// Google explicitly checks that structured data matches what a visitor
// actually sees. Built from the SAME trail logic as that schema (Home >
// Directory > Category if set > Business, last item unlinked as the
// current page) so the two can never disagree with each other.
$_bc_trail = [
    [ 'label' => 'Home',      'url' => home_url( '/' ) ],
    [ 'label' => 'Directory', 'url' => home_url( '/directory/' ) ],
];
if ( $listing && ! empty( $listing->cat_name ) ) {
    $_bc_trail[] = [
        'label' => $listing->cat_name,
        'url'   => ! empty( $listing->cat_slug )
            ? home_url( '/directory/?category=' . urlencode( $listing->cat_slug ) )
            : home_url( '/directory/?category_id=' . (int)( $listing->category_id ?? 0 ) ),
    ];
}
$_bc_trail[] = [ 'label' => gs_vs_safe_brand( $brand, $primary, $vendor ), 'url' => null ]; // current page — no link, matches schema's unlinked last item
?>
<nav class="vs-breadcrumb" aria-label="Breadcrumb">
  <div class="vs-wrap">
    <ol class="vs-breadcrumb-list">
      <?php foreach ( $_bc_trail as $_bc_i => $_bc_item ): ?>
      <li class="vs-breadcrumb-item">
        <?php if ( $_bc_item['url'] ): ?>
          <a href="<?php echo esc_url( $_bc_item['url'] ); ?>"><?php echo esc_html( $_bc_item['label'] ); ?></a>
        <?php else: ?>
          <span aria-current="page"><?php echo esc_html( $_bc_item['label'] ); ?></span>
        <?php endif; ?>
        <?php if ( $_bc_i < count( $_bc_trail ) - 1 ): ?><span class="vs-breadcrumb-sep" aria-hidden="true">›</span><?php endif; ?>
      </li>
      <?php endforeach; ?>
    </ol>
  </div>
</nav>

<?php
// ── Pre-define variables used in closures below ──────────────────────────
// Must be defined BEFORE the closures that capture them via use(), because
// PHP closures capture the value at creation time, not at call time.
$_listing_tagline = $primary ? ($primary->tagline ?? '') : '';
$_hero_desc       = $hd['hero_left_description'] ?? ($primary ? ($primary->full_desc ?: $primary->short_desc ?: '') : '');

// ── Fill element buffers for ALL sections ─────────────────────────────────
// ── HERO elements ─────────────────────────────────────────────────────────
$_cur = 'hero';
$_el_capture('hero_eyebrow', $_cur, function() use ($verified, $city, $vendor, $_ver_docs, $_badge_map) {
    if ($verified): ?><div class="vs-hero-eyebrow">✅ Verified Business</div>
    <?php elseif ($verified && $city): ?><div class="vs-hero-eyebrow">✅ Verified</div>
    <?php endif; // Location intentionally removed from hero per design requirement
});
$_el_capture('hero_name', $_cur, function() use ($hd, $brand, $listing, $city, $primary, $vendor, $seo_entry) { ?>
    <?php
        // A page must have exactly one real <h1>. When an SEO Search Entry
        // URL provides its own keyword-specific heading, THAT one lives in
        // the About section below (the section confirmed to always render);
        // this hero heading demotes itself to a styled <div> with its
        // normal, unchanged, primary-microsite text so no page ever ends
        // up with two <h1> tags. On the primary /{slug}/ URL (no
        // $seo_entry), this renders exactly as it always has — untouched.
        $_hero_tag = $seo_entry ? 'div' : 'h1';
    ?>
    <<?php echo $_hero_tag; ?> class="vs-hero-h1"><?php
        if ( ! empty( $hd['hero_left_heading'] ) ) {
            echo wp_kses_post( $hd['hero_left_heading'] );
        } else {
            $h1_category = $listing->subcat_name ?? $listing->cat_name ?? '';
            $h1_phrase    = \GoodService\Core\Helpers::intent_phrase( $h1_category, $city );
            $_h1_brand = gs_vs_safe_brand( $brand, $primary, $vendor );
            echo $h1_phrase
                ? esc_html( $h1_phrase ) . ' — <span>' . esc_html( $_h1_brand ) . '</span>'
                : '<span>' . esc_html( $_h1_brand ) . '</span>';
        }
    ?></<?php echo $_hero_tag; ?>>
<?php });
// Real fix: the Listing ID was previously shown here, directly on the
// public hero — removed entirely per explicit correction. This is an
// internal platform reference and must never be visible to a public
// visitor. It's shown instead in the vendor's own Contact Details
// management section, an authorized-user-only screen.
$_el_capture('hero_tagline', $_cur, function() use ($_listing_tagline) {
    $display_tagline = $_listing_tagline ?: '';
    if ($display_tagline): ?><p class="vs-hero-tagline"><?php echo esc_html($display_tagline); ?></p><?php endif;
});
$_el_capture('hero_description', $_cur, function() use ($_hero_desc) {
    if ($_hero_desc): ?><p class="vs-hero-desc"><?php echo wp_kses_post($_hero_desc); ?></p><?php endif;
});
// NOTE: $_hero_desc falls back to short_desc/full_desc. If all are empty, this element outputs nothing.
// To show something: fill Hero Description or Short Description in the form.
$_el_capture('hero_highlights', $_cur, function() use ($primary) {
    if ($primary && $primary->highlights): ?>
    <div class="vs-hero-highlights">
        <?php foreach (array_filter(explode("\n", $primary->highlights)) as $hl): ?>
        <div class="vs-hero-hl-item"><span class="vs-hero-hl-dot">✓</span><?php echo esc_html(trim($hl)); ?></div>
        <?php endforeach; ?>
    </div>
    <?php endif;
});
$_el_capture('hero_cta_buttons', $_cur, function() use ($hd, $phone, $_phone_masked, $primary, $listing_id) {
    $cta_text = $hd['hero_btn_text'] ?? $hd['hero_left_cta_text'] ?? "Let's Talk Now";
    $cta_link = $hd['hero_btn_link'] ?? $hd['hero_left_cta_link'] ?? '#vs-sec-contact'; ?>
    <div class="vs-hero-btns">
        <a href="<?php echo esc_url($cta_link); ?>" class="vs-btn vs-btn-yellow"><?php echo esc_html($cta_text); ?></a>
        <?php if ($phone): ?>
<span id="vs-phone-wrap">
  <button id="vs-phone-reveal-btn"
          onclick="vsRevealPhone(this,'<?php echo esc_js($listing_id ?? ($primary->id ?? 0)); ?>')"
          class="vs-btn vs-btn-outline-w"
          aria-label="Reveal and call <?php echo esc_attr($vendor_name); ?>">
    📞 <?php echo esc_html($_phone_masked); ?> — Tap to reveal
  </button>
</span>
<?php endif; ?>
    </div>
<?php });
// hero_image and trust_bar are rendered directly in the hero HTML below (not via el_capture)
// because they have fixed positions (hero_image = right column, trust_bar = full-width below)
?>

<!-- ══ HERO ═══════════════════════════════════════════════════════ -->
<?php if ( $_sec_show( 'hero' ) ): ?>
<section class="vs-hero">
  <div class="vs-hero-inner" style="min-height:<?php echo (int)$cv_banner_h; ?>px">
    <div class="vs-hero-left">
      <div class="vs-wrap" style="padding-right:48px">
        <?php
        // Hero text elements in configured order (excludes hero_image + trust_bar handled separately)
        $_hero_bufs = $_el_bufs['hero'] ?? [];
        ksort($_hero_bufs);
        foreach ($_hero_bufs as $html) { echo $html; }
        ?>
      </div>
    </div>
    <?php
    $hi_cfg = $_elget('hero_image');
    if ($hi_cfg['vis']): $hero_img = $hd['hero_right_image'] ?? ''; ?>
    <div class="vs-hero-right" style="min-height:<?php echo $cv_hero_img_h>0?(int)$cv_hero_img_h : (int)$cv_banner_h; ?>px">
      <?php
      // Video intro (Part 21.1): if vendor has a video_intro_url, show it in hero
      $_vp_video = $vendor_profile->video_intro_url ?? '';
      if ($_vp_video):
        // Detect YouTube/Vimeo for embed, otherwise treat as direct video URL
        $_vi_embed = null;
        if (preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([A-Za-z0-9_-]+)/', $_vp_video, $_vm))
            $_vi_embed = 'https://www.youtube.com/embed/' . $_vm[1] . '?autoplay=1&mute=1&loop=1&playlist=' . $_vm[1];
        elseif (preg_match('/vimeo\.com\/(\d+)/', $_vp_video, $_vm))
            $_vi_embed = 'https://player.vimeo.com/video/' . $_vm[1] . '?autoplay=1&muted=1&loop=1';
      ?>
        <?php if ($_vi_embed): ?>
          <iframe src="<?php echo esc_url($_vi_embed); ?>" style="width:100%;height:100%;min-height:320px;border:none" allow="autoplay; encrypted-media" loading="lazy" title="Introduction video"></iframe>
        <?php else: ?>
          <video src="<?php echo esc_url($_vp_video); ?>" autoplay muted loop playsinline style="width:100%;height:100%;object-fit:cover" poster="<?php echo esc_url($cover ?: ''); ?>"></video>
        <?php endif; ?>
      <?php elseif ($hero_img):
        // Real fix, PageSpeed audit item 2.4: cached hero-image dimension
        // detection — same proven pattern already used for og:image
        // dimensions this session. Only used as a fallback when a vendor
        // hasn't manually set a custom width/height; their explicit
        // choice (via $cv_hero_img_w/h) always still wins.
        $_hero_dim_w = $cv_hero_img_w; $_hero_dim_h = $cv_hero_img_h;
        if ( $_hero_dim_w <= 0 || $_hero_dim_h <= 0 ) {
            $_hero_dim_cache_key = 'gs_hero_dim_' . md5( $hero_img );
            $_hero_dim = get_transient( $_hero_dim_cache_key );
            if ( $_hero_dim === false ) {
                $_hero_dim = @getimagesize( $hero_img ) ?: [ 0, 0 ];
                set_transient( $_hero_dim_cache_key, $_hero_dim, 30 * DAY_IN_SECONDS );
            }
            if ( $_hero_dim_w <= 0 && ! empty( $_hero_dim[0] ) ) { $_hero_dim_w = (int) $_hero_dim[0]; }
            if ( $_hero_dim_h <= 0 && ! empty( $_hero_dim[1] ) ) { $_hero_dim_h = (int) $_hero_dim[1]; }
        }
      ?>
        <img src="<?php echo esc_url($hero_img); ?>" alt="<?php echo esc_attr( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?>" class="vs-hero-right-img" loading="eager" fetchpriority="high"<?php if($_hero_dim_w>0): ?> width="<?php echo (int)$_hero_dim_w; ?>"<?php endif; ?><?php if($_hero_dim_h>0): ?> height="<?php echo (int)$_hero_dim_h; ?>"<?php endif; ?>>
      <?php else: ?>
        <div class="vs-hero-right-placeholder">🏢</div>
      <?php endif; ?>
      <?php /* Rating badge removed from hero — shown in Reviews section */ ?>
    </div>
    <?php endif; ?>
  </div>
</section>
<?php endif; // $_sec_show('hero') ?>

<!-- ══ SWIPER / IMAGE SLIDER — completely independent of the Hero section.
     Own enable flag (swiper_enabled), own settings (swiper_settings),
     own slide source (gs_swiper_slides) — confirmed zero shared state
     with the hero, so either, both, or neither can be shown per the
     requirement. ══ -->
<?php
$_sw_enabled = (bool) ( $primary->swiper_enabled ?? 0 );
if ( $_sw_enabled ):
    $_sw_tbl_key    = 'gs_sw_tbl_exists';
    $_sw_tbl_cached = wp_cache_get( $_sw_tbl_key );
    if ( $_sw_tbl_cached === false ) {
        $_sw_tbl_cached = $wpdb->get_var( "SHOW TABLES LIKE '{$pfx}swiper_slides'" ) ? '1' : '0';
        wp_cache_set( $_sw_tbl_key, $_sw_tbl_cached, '', 300 );
    }
    // Fetch desktop slides (device = 'desktop' or legacy 'all')
    $_sw_slides_desk = ( $_sw_tbl_cached === '1' && $primary ) ? $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$pfx}swiper_slides WHERE listing_id = %d AND device IN ('desktop','all') ORDER BY sort_order ASC", $primary->id
    ) ) : [];
    // Fetch mobile slides (device = 'mobile' or legacy 'all')
    $_sw_slides_mob  = ( $_sw_tbl_cached === '1' && $primary ) ? $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$pfx}swiper_slides WHERE listing_id = %d AND device IN ('mobile','all') ORDER BY sort_order ASC", $primary->id
    ) ) : [];
    // Show the section if either list has slides
    $_sw_slides = array_merge( $_sw_slides_desk, $_sw_slides_mob );
    if ( $_sw_slides ):
        $_sw_settings  = json_decode( $primary->swiper_settings ?? '', true ) ?: [];
        $_sw_autoplay  = $_sw_settings['autoplay']   ?? true;
        $_sw_mobile_autoplay_off = (bool) ( $_sw_settings['mobile_autoplay_off'] ?? false );
        $_sw_loop      = $_sw_settings['loop']       ?? true;
        $_sw_arrows    = $_sw_settings['arrows']     ?? true;
        $_sw_dots      = $_sw_settings['dots']       ?? true;
        $_sw_interval  = (int) ( $_sw_settings['interval']  ?? 5000 );
        $_sw_speed     = (int) ( $_sw_settings['speed']     ?? 600 );
        $_sw_valid_effects = [ 'slide', 'fade', 'cube', 'coverflow', 'flip', 'cards', 'creative' ];
        $_sw_effect    = in_array( $_sw_settings['effect'] ?? 'slide', $_sw_valid_effects, true ) ? $_sw_settings['effect'] : 'slide';
        // Real feature — advanced 3D effects need the real Swiper.js
        // engine; the existing hand-rolled carousel below only ever
        // supported slide/fade and stays completely untouched for those
        // two, which is what every existing listing already uses today.
        $_sw_use_enhanced_engine = ! in_array( $_sw_effect, [ 'slide', 'fade' ], true );
        // Admin-configurable slider height — vendor-level setting takes
        // priority over the platform-wide default when the vendor has set
        // one; falls back to the site default otherwise. Tablet is a
        // genuinely new tier — this breakpoint never existed before.
        $_sw_h_desk    = ! empty( $cd['swiper_height_desktop'] ) ? (int) $cd['swiper_height_desktop'] : (int) gs_setting( 'slider_height_desktop', 0 );
        $_sw_h_tab     = ! empty( $cd['swiper_height_tablet'] )  ? (int) $cd['swiper_height_tablet']  : (int) gs_setting( 'slider_height_tablet', 0 );
        $_sw_h_mob     = ! empty( $cd['swiper_height_mobile'] )  ? (int) $cd['swiper_height_mobile']  : (int) gs_setting( 'slider_height_mobile',  0 );
        // Real feature — per-slide height override. Architectural note:
        // all slides in one device's carousel share a single absolutely-
        // positioned container (they crossfade in place), so a true
        // per-slide height isn't structurally possible here — this
        // applies as a per-device override instead, using the first
        // slide that sets one, taking priority over the admin default.
        foreach ( $_sw_slides_desk as $_sw_s ) {
            if ( ! empty( $_sw_s->height_override_desktop ) ) { $_sw_h_desk = (int) $_sw_s->height_override_desktop; break; }
        }
        foreach ( $_sw_slides_mob as $_sw_s ) {
            if ( ! empty( $_sw_s->height_override_mobile ) ) { $_sw_h_mob = (int) $_sw_s->height_override_mobile; break; }
        }
        $_sw_id_desk   = 'vs-swiper-desk-' . (int)$primary->id;
        $_sw_id_mob    = 'vs-swiper-mob-'  . (int)$primary->id;

        // Helper: render a slider section for a given slide list and ID
        $_sw_render = function( array $slides, string $id, bool $is_mobile ) use (
            $_sw_autoplay, $_sw_mobile_autoplay_off, $_sw_loop, $_sw_arrows, $_sw_dots,
            $_sw_interval, $_sw_speed, $_sw_effect,
            $_sw_h_desk, $_sw_h_tab, $_sw_h_mob, $brand, $primary, $vendor
        ): void {
            if ( empty( $slides ) ) { return; }
            $h = $is_mobile ? $_sw_h_mob : $_sw_h_desk;
            $ar = $is_mobile ? '4/3' : '16/6';
            $pb = $is_mobile ? '75%' : '37.5%';
            $_effective_autoplay = $_sw_autoplay && ! ( $is_mobile && $_sw_mobile_autoplay_off );
?>
<section class="vs-swiper<?php echo $is_mobile ? ' vs-swiper--mobile' : ' vs-swiper--desktop'; ?>" id="<?php echo $id; ?>"
  data-autoplay="<?php echo $_effective_autoplay?'1':'0'; ?>"
  data-loop="<?php echo $_sw_loop?'1':'0'; ?>"
  data-interval="<?php echo (int)$_sw_interval; ?>"
  data-speed="<?php echo (int)$_sw_speed; ?>"
  data-effect="<?php echo esc_attr($_sw_effect); ?>"
  data-arrows="<?php echo $_sw_arrows?'1':'0'; ?>"
  data-dots="<?php echo $_sw_dots?'1':'0'; ?>">
  <div class="vs-swiper-track">
    <?php foreach ( $slides as $i => $s ):
        $valid_fits = [ 'cover', 'contain', 'fill', 'scale-down', 'none' ];
        $valid_positions = [ 'center', 'top', 'bottom', 'left', 'right', 'top left', 'top right', 'bottom left', 'bottom right' ];
        $s_fit      = $is_mobile ? ( $s->img_fit_mobile ?? 'cover' ) : ( $s->img_fit_desktop ?? 'cover' );
        $s_position = $is_mobile ? ( $s->img_position_mobile ?? 'center' ) : ( $s->img_position_desktop ?? 'center' );
        $s_zoom     = max( 50, min( 200, (int) ( $is_mobile ? ( $s->img_zoom_mobile ?? 100 ) : ( $s->img_zoom_desktop ?? 100 ) ) ) );
        $s_fit      = in_array( $s_fit, $valid_fits, true ) ? $s_fit : 'cover';
        $s_position = in_array( $s_position, $valid_positions, true ) ? $s_position : 'center';
        $s_img_style = "object-fit:{$s_fit};object-position:{$s_position};" . ( $s_zoom !== 100 ? "transform:scale(" . ( $s_zoom / 100 ) . ");" : '' );
    ?>
    <div class="vs-swiper-slide<?php echo $i===0?' active':''; ?>" data-index="<?php echo (int)$i; ?>">
      <img src="<?php echo esc_url( $is_mobile ? ( $s->image_mobile ?: $s->image_desktop ) : $s->image_desktop ); ?>"
           alt="<?php echo esc_attr( $s->title ?: gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?>"
           loading="<?php echo $i===0?'eager':'lazy'; ?>"
           <?php echo $i===0?'fetchpriority="high"':''; ?>
           style="<?php echo esc_attr( $s_img_style ); ?>"
           class="vs-swiper-img">
      <?php if ( $s->title || $s->subtitle || $s->description || $s->button_text ): ?>
      <div class="vs-swiper-content">
        <?php if ( $s->subtitle ): ?><div class="vs-swiper-subtitle"><?php echo esc_html( $s->subtitle ); ?></div><?php endif; ?>
        <?php if ( $s->title ): ?><h2 class="vs-swiper-title"><?php echo esc_html( $s->title ); ?></h2><?php endif; ?>
        <?php if ( $s->description ): ?><p class="vs-swiper-desc"><?php echo esc_html( $s->description ); ?></p><?php endif; ?>
        <?php if ( $s->button_text && $s->button_url ): ?>
        <a href="<?php echo esc_url( $s->button_url ); ?>" class="vs-swiper-btn"><?php echo esc_html( $s->button_text ); ?></a>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <button type="button" class="vs-swiper-arrow vs-swiper-prev" aria-label="Previous slide"<?php echo !$_sw_arrows||count($slides)<2?' style="display:none"':''; ?>>‹</button>
  <button type="button" class="vs-swiper-arrow vs-swiper-next" aria-label="Next slide"<?php echo !$_sw_arrows||count($slides)<2?' style="display:none"':''; ?>>›</button>
  <?php if ( $_sw_dots && count( $slides ) > 1 ): ?>
  <div class="vs-swiper-dots">
    <?php foreach ( $slides as $i => $s ): ?>
    <button type="button" class="vs-swiper-dot<?php echo $i===0?' active':''; ?>" data-slide="<?php echo (int)$i; ?>" aria-label="Go to slide <?php echo (int)$i+1; ?>"></button>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>
<?php  // Height CSS scoped to this slider's ID
        echo "<style>#${id}{"
            . "position:relative;width:100%;overflow:hidden;background:#0F172A;"
            . ( $h > 0 ? "height:{$h}px;" : "aspect-ratio:{$ar};height:0;padding-bottom:{$pb};" )
            . "}"
            . "@supports(aspect-ratio:1){#${id}{"
            . ( $h > 0 ? "height:{$h}px;padding-bottom:0;" : "aspect-ratio:{$ar};height:auto;padding-bottom:0;" )
            . "}}</style>";
        };
?>
<?php if ( $_sw_use_enhanced_engine ):
        // Real feature — enhanced engine markup, real Swiper.js DOM
        // structure (swiper > swiper-wrapper > swiper-slide). Kept as a
        // separate render path so the existing, working hand-rolled
        // engine below is never touched by this branch.
        $_sw_render_enhanced = function( array $slides, string $id, bool $is_mobile ) use (
            $_sw_autoplay, $_sw_mobile_autoplay_off, $_sw_loop, $_sw_arrows, $_sw_dots,
            $_sw_interval, $_sw_speed, $_sw_effect,
            $_sw_h_desk, $_sw_h_mob, $brand, $primary, $vendor
        ): void {
            if ( empty( $slides ) ) { return; }
            $h  = $is_mobile ? $_sw_h_mob : $_sw_h_desk;
            $ar = $is_mobile ? '4/3' : '16/6';
            $pb = $is_mobile ? '75%' : '37.5%';
            $valid_fits = [ 'cover', 'contain', 'fill', 'scale-down', 'none' ];
            $valid_positions = [ 'center', 'top', 'bottom', 'left', 'right', 'top left', 'top right', 'bottom left', 'bottom right' ];
?>
<section class="vs-swiper-enhanced<?php echo $is_mobile ? ' vs-swiper--mobile' : ' vs-swiper--desktop'; ?>">
<div class="swiper" id="<?php echo esc_attr( $id ); ?>">
  <div class="swiper-wrapper">
    <?php foreach ( $slides as $i => $s ):
        $s_fit      = $is_mobile ? ( $s->img_fit_mobile ?? 'cover' ) : ( $s->img_fit_desktop ?? 'cover' );
        $s_position = $is_mobile ? ( $s->img_position_mobile ?? 'center' ) : ( $s->img_position_desktop ?? 'center' );
        $s_zoom     = max( 50, min( 200, (int) ( $is_mobile ? ( $s->img_zoom_mobile ?? 100 ) : ( $s->img_zoom_desktop ?? 100 ) ) ) );
        $s_fit      = in_array( $s_fit, $valid_fits, true ) ? $s_fit : 'cover';
        $s_position = in_array( $s_position, $valid_positions, true ) ? $s_position : 'center';
        $s_img_style = "object-fit:{$s_fit};object-position:{$s_position};" . ( $s_zoom !== 100 ? "transform:scale(" . ( $s_zoom / 100 ) . ");" : '' );
    ?>
    <div class="swiper-slide">
      <img src="<?php echo esc_url( $is_mobile ? ( $s->image_mobile ?: $s->image_desktop ) : $s->image_desktop ); ?>"
           alt="<?php echo esc_attr( $s->title ?: gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?>"
           loading="<?php echo $i===0?'eager':'lazy'; ?>"
           <?php echo $i===0?'fetchpriority="high"':''; ?>
           style="<?php echo esc_attr( $s_img_style ); ?>"
           class="vs-swiper-img">
      <?php if ( $s->title || $s->subtitle || $s->description || $s->button_text ): ?>
      <div class="vs-swiper-content">
        <?php if ( $s->subtitle ): ?><div class="vs-swiper-subtitle"><?php echo esc_html( $s->subtitle ); ?></div><?php endif; ?>
        <?php if ( $s->title ): ?><h2 class="vs-swiper-title"><?php echo esc_html( $s->title ); ?></h2><?php endif; ?>
        <?php if ( $s->description ): ?><p class="vs-swiper-desc"><?php echo esc_html( $s->description ); ?></p><?php endif; ?>
        <?php if ( $s->button_text && $s->button_url ): ?>
        <a href="<?php echo esc_url( $s->button_url ); ?>" class="vs-swiper-btn"><?php echo esc_html( $s->button_text ); ?></a>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php if ( $_sw_arrows && count( $slides ) > 1 ): ?>
  <div class="swiper-button-prev"></div>
  <div class="swiper-button-next"></div>
  <?php endif; ?>
  <?php if ( $_sw_dots && count( $slides ) > 1 ): ?>
  <div class="swiper-pagination"></div>
  <?php endif; ?>
</div>
<style>
#<?php echo esc_attr( $id ); ?>{
  position:relative;width:100%;overflow:hidden;background:#0F172A;
  <?php echo $h > 0 ? "height:{$h}px;" : "aspect-ratio:{$ar};height:0;padding-bottom:{$pb};"; ?>
}
@supports(aspect-ratio:1){#<?php echo esc_attr( $id ); ?>{
  <?php echo $h > 0 ? "height:{$h}px;padding-bottom:0;" : "aspect-ratio:{$ar};height:auto;padding-bottom:0;"; ?>
}}
<?php if ( ! $is_mobile && $_sw_h_tab > 0 ): ?>
/* Real feature — tablet height tier. Applies only in the range where this
   desktop-rendered instance is still the one shown (above the existing
   768px desktop→mobile switch below), giving tablets their own height
   independent of both desktop and mobile. */
@media(max-width:1024px) and (min-width:769px){
  #<?php echo esc_attr( $id ); ?>{ height:<?php echo (int) $_sw_h_tab; ?>px !important; aspect-ratio:unset; padding-bottom:0; }
}
<?php endif; ?>
</style>
</section>
<?php
        };
        $_sw_render_enhanced( $_sw_slides_desk, $_sw_id_desk, false );
        $_sw_render_enhanced( $_sw_slides_mob,  $_sw_id_mob,  true  );
?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
<style>
.vs-swiper--mobile{display:none}
@media(max-width:768px){ .vs-swiper--desktop{display:none} .vs-swiper--mobile{display:block} }
.vs-swiper-enhanced .swiper-slide{position:relative}
.vs-swiper-enhanced .vs-swiper-img{width:100%;height:100%;display:block}
.vs-swiper-enhanced .vs-swiper-content{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:center;padding:32px 48px;background:linear-gradient(90deg,rgba(0,0,0,.55) 0%,transparent 70%);color:#fff;max-width:600px;z-index:5}
.vs-swiper-enhanced .vs-swiper-subtitle{font-size:.8rem;font-weight:600;text-transform:uppercase;letter-spacing:.12em;opacity:.85;margin-bottom:8px}
.vs-swiper-enhanced .vs-swiper-title{font-size:2rem;font-weight:800;line-height:1.2;margin:0 0 12px}
.vs-swiper-enhanced .vs-swiper-desc{font-size:.95rem;opacity:.88;margin-bottom:20px;line-height:1.5}
.vs-swiper-enhanced .vs-swiper-btn{display:inline-block;padding:10px 24px;background:#2563EB;color:#fff;border-radius:8px;font-weight:700;font-size:.9rem;text-decoration:none}
@media(max-width:768px){
  .vs-swiper-enhanced .vs-swiper-content{padding:20px 24px}
  .vs-swiper-enhanced .vs-swiper-title{font-size:1.3rem}
  .vs-swiper-enhanced .vs-swiper-desc{font-size:.85rem;margin-bottom:12px}
}
</style>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
(function(){
  var mobileAutoplayOff = <?php echo $_sw_mobile_autoplay_off ? 'true' : 'false'; ?>;
  var baseAutoplay = <?php echo $_sw_autoplay ? '{ delay: ' . (int) $_sw_interval . ', disableOnInteraction: false, pauseOnMouseEnter: true }' : 'false'; ?>;
  var vsSwiperInstances = {};
  function init(id, isMobile) {
    var el = document.getElementById(id);
    if (!el || !window.Swiper) return;
    vsSwiperInstances[id] = new Swiper('#' + id, {
      effect: '<?php echo esc_js( $_sw_effect ); ?>',
      speed: <?php echo (int) $_sw_speed; ?>,
      loop: <?php echo $_sw_loop ? 'true' : 'false'; ?>,
      autoplay: (isMobile && mobileAutoplayOff) ? false : baseAutoplay,
      spaceBetween: <?php echo max( 0, min( 200, (int) ( $_sw_settings['space_between'] ?? 20 ) ) ); ?>,
      autoHeight: <?php echo ! empty( $_sw_settings['auto_height'] ) ? 'true' : 'false'; ?>,
      navigation: { nextEl: '#' + id + ' .swiper-button-next', prevEl: '#' + id + ' .swiper-button-prev' },
      pagination: { el: '#' + id + ' .swiper-pagination', clickable: true },
      grabCursor: true,
      keyboard: { enabled: true },
      // Real fix — root cause: this container gets toggled display:none/
      // block by a CSS media query (not by Swiper itself), and Swiper's
      // own resize handler recalculates from offsetWidth even while
      // hidden (0px), corrupting slide positions. observer/observeParents
      // enables Swiper's built-in MutationObserver-based detection of
      // visibility and size changes on this element and its ancestors —
      // Swiper's own documented mechanism for exactly this situation.
      observer: true,
      observeParents: true,
      observeSlideChildren: true,
      <?php if ( $_sw_effect === 'coverflow' ): ?>
      coverflowEffect: { rotate: 30, stretch: 0, depth: 120, modifier: 1, slideShadows: false },
      <?php elseif ( $_sw_effect === 'creative' ): ?>
      creativeEffect: { prev: { shadow: false, translate: [0, 0, -200], opacity: 0 }, next: { translate: ['100%', 0, 0] } },
      <?php endif; ?>
    });
  }
  init('<?php echo esc_js( $_sw_id_desk ); ?>', false);
  init('<?php echo esc_js( $_sw_id_mob ); ?>', true);
  // Real fix — second, independent safeguard alongside the observer
  // above: on every resize (covers orientation change too, since that
  // fires 'resize' in every modern browser), explicitly call update()
  // on whichever instance is now actually visible. offsetParent is null
  // exactly when an element or an ancestor has display:none, which is
  // the correct, standard way to check real visibility here — checking
  // this element's own style wouldn't catch a hidden ancestor.
  var vsSwResizeTimer = null;
  window.addEventListener('resize', function() {
    clearTimeout(vsSwResizeTimer);
    vsSwResizeTimer = setTimeout(function() {
      Object.keys(vsSwiperInstances).forEach(function(id) {
        var inst = vsSwiperInstances[id];
        var el = document.getElementById(id);
        if (inst && el && el.offsetParent !== null) { inst.update(); }
      });
    }, 150);
  });
})();
</script>
<?php else: ?>
<?php $_sw_render( $_sw_slides_desk, $_sw_id_desk, false ); ?>
<?php $_sw_render( $_sw_slides_mob,  $_sw_id_mob,  true  ); ?>
<style>
/* ── Shared swiper styles ── */
.vs-swiper-track{position:relative;width:100%;height:100%}
.vs-swiper-slide{
  position:absolute;inset:0;opacity:0;z-index:1;
  transition:opacity <?php echo (int)$_sw_speed; ?>ms ease;
  will-change:opacity,transform;
}
.vs-swiper-slide.active{opacity:1;z-index:2}
.vs-swiper[data-effect="slide"] .vs-swiper-slide{
  transform:translateX(100%);opacity:1;
  transition:transform <?php echo (int)$_sw_speed; ?>ms cubic-bezier(.4,0,.2,1);
}
.vs-swiper[data-effect="slide"] .vs-swiper-slide.active{transform:translateX(0);z-index:3}
.vs-swiper[data-effect="slide"] .vs-swiper-slide.vs-leaving{transform:translateX(-100%);z-index:2}
.vs-swiper-slide img{width:100%;height:100%;object-fit:cover;display:block}
.vs-swiper-content{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:center;padding:32px 48px;background:linear-gradient(90deg,rgba(0,0,0,.55) 0%,transparent 70%);color:#fff;max-width:600px}
.vs-swiper-subtitle{font-size:.8rem;font-weight:600;text-transform:uppercase;letter-spacing:.12em;opacity:.85;margin-bottom:8px}
.vs-swiper-title{font-size:2rem;font-weight:800;line-height:1.2;margin:0 0 12px}
.vs-swiper-desc{font-size:.95rem;opacity:.88;margin-bottom:20px;line-height:1.5}
.vs-swiper-btn{display:inline-block;padding:10px 24px;background:#2563EB;color:#fff;border-radius:8px;font-weight:700;font-size:.9rem;text-decoration:none;transition:background .2s}
.vs-swiper-btn:hover{background:#1D4ED8}
.vs-swiper-arrow{position:absolute;top:50%;transform:translateY(-50%);z-index:10;background:rgba(255,255,255,.18);border:none;color:#fff;width:44px;height:44px;border-radius:50%;font-size:1.6rem;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:background .2s;backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px)}
.vs-swiper-arrow:hover{background:rgba(255,255,255,.32)}
.vs-swiper-prev{left:16px}.vs-swiper-next{right:16px}
.vs-swiper-dots{position:absolute;bottom:14px;left:50%;transform:translateX(-50%);display:flex;z-index:10}
.vs-swiper-dot{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.45);background-clip:content-box;border:none;cursor:pointer;padding:8px;box-sizing:content-box;transition:background .2s,transform .2s}
.vs-swiper-dot.active{background:#fff;transform:scale(1.3)}
/* ── Device visibility — pure CSS, no JS required ── */
.vs-swiper--mobile{display:none}
@media(max-width:768px){
  .vs-swiper--desktop{display:none}
  .vs-swiper--mobile{display:block}
  .vs-swiper-content{padding:20px 24px}
  .vs-swiper-title{font-size:1.3rem}
  .vs-swiper-desc{font-size:.85rem;margin-bottom:12px}
  .vs-swiper-arrow{width:38px;height:38px;font-size:1.3rem}
  .vs-swiper-prev{left:8px}.vs-swiper-next{right:8px}
}
</style>
<script>
function vsInitSwiper(id) {
  var root = document.getElementById(id);
  if (!root) return;
  var slides = Array.from(root.querySelectorAll('.vs-swiper-slide'));
  var dots   = Array.from(root.querySelectorAll('.vs-swiper-dot'));
  var total  = slides.length;
  if (total < 1) return;

  var effect    = root.dataset.effect || 'slide';
  var speed     = parseInt(root.dataset.speed, 10) || 600;
  var interval  = parseInt(root.dataset.interval, 10) || 5000;
  var doAutoplay= root.dataset.autoplay === '1';
  var doLoop    = root.dataset.loop === '1';
  var current   = 0;
  var animating = false;
  var timer     = null;

  if (total < 2) { startAutoplay(); return; }

  function goTo(next, dir) {
    if (animating) return;
    if (next === current) return;
    if (!doLoop && (next < 0 || next >= total)) return;
    next = ((next % total) + total) % total;
    animating = true; clearAutoplay();
    var leaving = slides[current], coming = slides[next];
    dots.forEach(function(d, i) { d.classList.toggle('active', i === next); });
    if (effect === 'fade') {
      coming.classList.add('active');
      setTimeout(function() {
        leaving.classList.remove('active'); current = next; animating = false; startAutoplay();
      }, speed);
    } else {
      var inFrom = dir === 'prev' ? '-100%' : '100%';
      var outTo  = dir === 'prev' ? '100%' : '-100%';
      coming.style.transition = 'none';
      coming.style.transform  = 'translateX(' + inFrom + ')';
      coming.style.zIndex = '3';
      coming.classList.add('active');
      leaving.style.zIndex = '2';
      void coming.offsetWidth;
      var trans = 'transform ' + speed + 'ms cubic-bezier(.4,0,.2,1)';
      coming.style.transition = trans; leaving.style.transition = trans;
      coming.style.transform = 'translateX(0)'; leaving.style.transform = 'translateX(' + outTo + ')';
      setTimeout(function() {
        leaving.classList.remove('active');
        [leaving, coming].forEach(function(el) { el.style.transform = ''; el.style.transition = ''; el.style.zIndex = ''; });
        current = next; animating = false; startAutoplay();
      }, speed + 20);
    }
  }
  function startAutoplay() {
    if (!doAutoplay) return;
    clearAutoplay();
    timer = setInterval(function() { goTo(current + 1, 'next'); }, interval);
  }
  function clearAutoplay() { if (timer) { clearInterval(timer); timer = null; } }

  var prevBtn = root.querySelector('.vs-swiper-prev');
  var nextBtn = root.querySelector('.vs-swiper-next');
  if (prevBtn) prevBtn.addEventListener('click', function() { goTo(current - 1, 'prev'); });
  if (nextBtn) nextBtn.addEventListener('click', function() { goTo(current + 1, 'next'); });
  dots.forEach(function(d, i) { d.addEventListener('click', function() { goTo(i, i > current ? 'next' : 'prev'); }); });

  var tx = 0, ty = 0;
  root.addEventListener('touchstart', function(e) { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, {passive:true});
  root.addEventListener('touchend', function(e) {
    var dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty;
    if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 40) { dx < 0 ? goTo(current+1,'next') : goTo(current-1,'prev'); }
  }, {passive:true});
  root.addEventListener('mouseenter', clearAutoplay);
  root.addEventListener('mouseleave', startAutoplay);
  root.setAttribute('tabindex', '0');
  root.addEventListener('keydown', function(e) {
    if (e.key === 'ArrowLeft')  { goTo(current-1,'prev'); e.preventDefault(); }
    if (e.key === 'ArrowRight') { goTo(current+1,'next'); e.preventDefault(); }
  });
  startAutoplay();
}
vsInitSwiper('<?php echo $_sw_id_desk; ?>');
vsInitSwiper('<?php echo $_sw_id_mob; ?>');
</script>
<?php endif; ?>
<?php endif; endif; ?>
<?php
$_tb_cfg = $_elget('trust_bar');
if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_TRUST_BAR') && GS_USE_MODULE_ENGINE_TRUST_BAR ) ) {
    echo \GoodService\Modules\TrustBarModule::render_bar(
        (bool) $_tb_cfg['vis'], $trust_bar, $cv_tb_bg, $cv_tb_padding, $cv_tb_radius,
        $cv_tb_pause_hover, $cv_marquee_speed, $cv_tb_direction, $cv_tb_gap, $cv_tb_align
    );
} else {
if ($_tb_cfg['vis'] && $trust_bar):
  $_tb_items = array_filter(array_map('trim', explode('•', $trust_bar)));
  if (empty($_tb_items)) $_tb_items = array_filter(array_map('trim', explode(',', $trust_bar)));
  if (empty($_tb_items)) $_tb_items = [$trust_bar];
  $_tb_html = '';
  foreach ($_tb_items as $_tbi) $_tb_html .= '<span>'.esc_html($_tbi).'</span>';
?>
<div class="vs-trust-bar" style="<?php
    if ($cv_tb_bg) echo 'background:'.esc_attr($cv_tb_bg).';';
    echo 'padding:'.$cv_tb_padding.'px 0;';
    if ($cv_tb_radius) echo 'border-radius:'.$cv_tb_radius.'px;';
  ?>"><div style="overflow:hidden;<?php echo $cv_tb_pause_hover ? '' : ''; ?>" class="<?php echo $cv_tb_pause_hover ? 'vs-tb-pause-hover' : ''; ?>"><div class="vs-trust-marquee" style="animation-duration:<?php echo $cv_marquee_speed; ?>s;animation-direction:<?php echo $cv_tb_direction === 'right' ? 'reverse' : 'normal'; ?>;gap:<?php echo $cv_tb_gap; ?>px;justify-content:<?php echo $cv_tb_align === 'center' ? 'center' : ( $cv_tb_align === 'right' ? 'flex-end' : 'flex-start' ); ?>"><?php echo $_tb_html.$_tb_html; ?></div></div></div>
<?php endif; ?>
<?php } ?>
<?php if ($_nb_count >= 5 && $_nb_area): ?>
<div style="background:#F0FDF4;border-bottom:1px solid #BBF7D0;padding:7px 20px;text-align:center;font-size:.8rem;color:#166534;display:flex;align-items:center;justify-content:center;gap:6px">
  <span>📍</span><span>Booked by <strong><?php echo (int)$_nb_count; ?>+</strong> clients in <strong><?php echo esc_html($_nb_area); ?></strong></span>
</div>
<?php endif; ?>
<?php if ( ! empty( $_ver_docs ) || $_reply_txt ): ?>
<div style="background:#F8FAFC;border-bottom:1px solid #E2E8F0;padding:8px 20px;display:flex;align-items:center;gap:10px;flex-wrap:wrap">
  <?php if ( ! empty( $_ver_docs ) ): ?>
  <span style="font-size:.72rem;font-weight:700;color:#647388;text-transform:uppercase;letter-spacing:.05em">Verified:</span>
  <?php foreach ( $_ver_docs as $_bd ):
    $bm = $_badge_map[$_bd] ?? null;
    if ( ! $bm ) continue;
  ?>
  <span style="display:inline-flex;align-items:center;gap:4px;background:<?php echo $bm[2]; ?>;color:<?php echo $bm[3]; ?>;border-radius:20px;padding:3px 10px;font-size:.72rem;font-weight:700"><?php echo $bm[0].' '.esc_html($bm[1]); ?></span>
  <?php endforeach; ?>
  <?php endif; ?>
  <?php if ( $_reply_txt ): ?>
  <span style="display:inline-flex;align-items:center;gap:4px;background:#EFF6FF;color:#2563EB;border-radius:20px;padding:3px 10px;font-size:.72rem;font-weight:700">🕐 <?php echo esc_html( $_reply_txt ); ?></span>
  <?php endif; ?>
</div>
<?php endif; ?>
<?php
// Social proof ticker (Part 21.4) — show recent booking from this listing
$_recent_lead = null;
if ( $primary ) {
    $_recent_lead = $wpdb->get_row( $wpdb->prepare(
        "SELECT l.name, loc.name AS area, l.created_at
         FROM {$pfx}leads l
         LEFT JOIN {$pfx}locations loc ON loc.id = l.location_id
         WHERE l.listing_id = %d AND l.created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
         AND l.status != 'junk'
         ORDER BY l.created_at DESC LIMIT 1",
        $primary->id
    ) );
}
if ( $_recent_lead ):
    $_first_name = explode(' ', trim($_recent_lead->name))[0];
    $_time_ago   = human_time_diff( strtotime($_recent_lead->created_at) ) . ' ago';
    $_area_txt   = $_recent_lead->area ? ' in ' . esc_html($_recent_lead->area) : '';
?>
<div id="vs-social-proof" style="background:#F0FDF4;border-bottom:1px solid #BBF7D0;padding:8px 20px;text-align:center;font-size:.82rem;color:#166534;display:flex;align-items:center;justify-content:center;gap:8px;min-height:34px;box-sizing:border-box">
  <span style="font-size:.95rem">✅</span>
  <span id="vs-social-proof-text"><strong><?php echo esc_html($_first_name); ?></strong><?php echo $_area_txt; ?> sent an inquiry <?php echo esc_html($_time_ago); ?></span>
  <button onclick="this.parentElement.style.display='none';this.parentElement.dataset.dismissed='1'" aria-label="Dismiss notification" style="background:none;border:none;color:#166534;cursor:pointer;font-size:.9rem;margin-left:6px;opacity:.6">×</button>
</div>
<?php endif; ?>
<script>
// Part 21.4 — Auto-refresh social proof ticker every 60 seconds
(function(){
  var el = document.getElementById('vs-social-proof');
  if (!el) return;
  var listingId = <?php echo (int)($primary->id ?? 0); ?>;
  if (!listingId) return;
  function vsRefreshProof() {
    // Real fix — if the user dismissed this, respect that permanently
    // for the rest of the page's lifetime rather than silently bringing
    // it back and shifting layout at an unpredictable moment.
    if (el.dataset.dismissed === '1') return;
    var fd = new FormData();
    fd.append('action','gs_get_social_proof_ticker');
    fd.append('listing_id', listingId);
    fetch((window.GS&&GS.ajax_url)||'/wp-admin/admin-ajax.php',{method:'POST',body:fd})
      .then(function(r){return r.json();})
      .then(function(d){
        if(d.success && d.data && d.data.text) {
          var txt = document.getElementById('vs-social-proof-text');
          if(txt) txt.innerHTML = d.data.text;
          el.style.display='flex';
        }
      });
  }
  setInterval(vsRefreshProof, 60000);
})();
</script>

<?php
// ── Pre-compute all data for element rendering ────────────────────────────
$_about_desc      = $ad['about_description'] ?? $vendor->bio ?? ($primary ? ($primary->full_desc ?: $primary->short_desc) : '');
$_about_title_txt = $ad['about_title'] ?? 'About ' . gs_vs_safe_brand( $brand, $primary, $vendor );
$_listing_tagline = $primary->tagline ?? '';
$_hero_desc       = $hd['hero_left_description'] ?? ($primary ? ($primary->full_desc ?: $primary->short_desc ?: '') : '');
$_about_img       = $ad['about_image'] ?? ($primary->banner_url ?? $cover ?: '');
$_video_url       = $primary->video_url ?? '';
$_badges          = $ad['about_badges'] ?? [];
$_certs           = $primary->certifications ?? '';
$_awards          = $primary->awards ?? '';
$_website         = $primary->website ?? $vendor->website ?? '';
$_gallery_sec_title = !empty($primary->gallery_title) ? $primary->gallery_title : 'Photo Gallery';
$_items_title_raw = '';
if (!empty($all_items)) {
    $_types = array_unique(array_column($all_items, 'item_type'));
    if (in_array('product',$_types)&&in_array('service',$_types)) $_items_title_raw='Our Services & Products';
    elseif (in_array('product',$_types)) $_items_title_raw='Our Products';
    else $_items_title_raw='Our Services';
}


// ── ABOUT elements ─────────────────────────────────────────────────────────
$_cur = 'about';
$_el_capture('about_eyebrow', $_cur, function() use ($brand, $primary, $vendor) { ?>
    <div class="vs-sec-eyebrow"><?php echo esc_html( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?></div>
<?php });
$_el_capture('about_title', $_cur, function() use ($_about_title_txt, $seo_entry) { ?>
    <?php if ( ! empty( $seo_entry->h1 ) ): ?>
    <!-- SEO Search Entry URL: this is the page's one real <h1>, using the
         keyword-specific heading generated by SeoEntryService. Kept as the
         SAME "vs-sec-title" style as the normal About heading below, so
         nothing visually changes except the tag name and text — the rest
         of the microsite (including this section's own layout) stays
         identical, per the earlier "don't change the microsite" decision. -->
    <h1 class="vs-sec-title"><?php echo esc_html( $seo_entry->h1 ); ?></h1>
    <?php if ( ! empty( $seo_entry->intro_content ) ): ?>
    <p class="vs-seo-entry-intro" style="max-width:720px;margin:6px 0 0;font-size:.95rem;line-height:1.55;color:#475569"><?php echo esc_html( $seo_entry->intro_content ); ?></p>
    <?php endif; ?>
    <?php else: ?>
    <h2 class="vs-sec-title"><?php echo esc_html($_about_title_txt); ?></h2>
    <?php endif; ?>
    <div class="vs-divider"></div>
<?php });
$_el_capture('about_stats_row', $_cur, function() use ($primary, $review_avg) {
    if (!$primary) return;
    if (!$primary->established_year && !$primary->team_size && $review_avg<=0 && !($primary->price_min??null) && !($primary->price_max??null)) return;
    $_cur_sym = gs_setting('currency_symbol','₹'); ?>
    <div class="vs-about-stats">
        <?php if ($primary->established_year): ?><div class="vs-about-stat"><div class="vs-about-stat-val"><?php echo esc_html($primary->established_year); ?></div><div class="vs-about-stat-lbl">Founded</div></div><?php endif; ?>
        <?php if ($primary->team_size): ?><div class="vs-about-stat"><div class="vs-about-stat-val"><?php echo esc_html($primary->team_size); ?></div><div class="vs-about-stat-lbl">Team Size</div></div><?php endif; ?>
        <?php if (($primary->price_min??null)||($primary->price_max??null)):
            if (($primary->price_min??null)&&($primary->price_max??null)) $_pd=$_cur_sym.number_format($primary->price_min).'–'.$_cur_sym.number_format($primary->price_max);
            elseif ($primary->price_min??null) $_pd='From '.$_cur_sym.number_format($primary->price_min);
            else $_pd='Up to '.$_cur_sym.number_format($primary->price_max); ?>
            <div class="vs-about-stat"><div class="vs-about-stat-val" style="font-size:1.05rem"><?php echo esc_html($_pd); ?></div><div class="vs-about-stat-lbl"><?php echo ($primary->price_unit??'')?esc_html('per '.$primary->price_unit):'Price Range'; ?></div></div>
        <?php endif; ?>
        <?php if ($review_avg>0): ?><div class="vs-about-stat"><div class="vs-about-stat-val">⭐ <?php echo number_format($review_avg,1); ?></div><div class="vs-about-stat-lbl">Avg Rating</div></div><?php endif; ?>
    </div>
<?php });
$_el_capture('about_description', $_cur, function() use ($_about_desc, $brand, $primary, $vendor, $seo_entry) {
    if ($_about_desc): ?><div class="vs-about-desc"><?php echo wpautop(wp_kses_post($_about_desc)); ?></div>
    <?php else: ?><div class="vs-about-desc" style="color:#647388;font-style:italic"><?php echo esc_html( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?> — Professional service provider. Update your listing description to tell customers about your business.</div>
    <?php endif;
    // Internal-linking signal (favours indexing of sibling entry URLs):
    // small, plain-text link list to this listing's other approved entry
    // URLs, placed at the end of the About section's description text (per
    // request), only rendered on entry-URL views — the primary canonical
    // page is completely unaffected, per the earlier "no change on main
    // page" decision. Google weighs internal links far more heavily than
    // sitemap presence alone as evidence a URL is worth indexing.
    // BUG FIX: this used to hard-cap the list at 6, which is the actual
    // reason only a handful of the vendor's generated Related Searches
    // ever appeared here — every row this query can return is already an
    // approved/'indexable' entry, so there's no valid reason to hide any
    // of them. 0 = unlimited (see SeoEntryService::indexable_siblings()).
    $_seo_siblings = ! empty( $seo_entry->listing_id )
        ? \GoodService\SEO\SeoEntryService::indexable_siblings( (int) $seo_entry->listing_id, (string) $seo_entry->keyword_slug, 0 )
        : [];
    if ( $_seo_siblings ): ?>
    <div class="vs-seo-related" style="margin:14px 0 0;font-size:6px;line-height:1.9;color:#64748b">
        <span>Related searches:</span>
        <?php foreach ( $_seo_siblings as $_i => $_sib ): ?><?php echo $_i ? ' · ' : ' '; ?><a href="<?php echo esc_url( $_sib->canonical_url ); ?>" style="color:#475569;text-decoration:underline"><?php echo esc_html( $_sib->keyword ); ?></a><?php endforeach; ?>
    </div>
    <?php endif;
});
$_el_capture('about_highlights', $_cur, function() use ($primary) {
    if ($primary && $primary->highlights):
        foreach (array_filter(explode("\n", $primary->highlights)) as $hl):
            ?><div class="vs-about-hl"><span class="vs-about-hl-icon">✔</span><?php echo esc_html(trim($hl)); ?></div><?php
        endforeach;
    endif;
});
$_el_capture('about_cta', $_cur, function() use ($ad) {
    if (!empty($ad['about_cta_text'])): ?><div style="margin-top:24px"><a href="<?php echo esc_url($ad['about_cta_link']??'#vs-sec-contact'); ?>" class="vs-btn vs-btn-primary"><?php echo esc_html($ad['about_cta_text']); ?></a></div><?php endif;
});
$_el_capture('about_image', 'about_right', function() use ($_about_img, $brand, $primary, $vendor) { ?>
    <?php if ($_about_img): ?><img src="<?php echo esc_url($_about_img); ?>" alt="<?php echo esc_attr( 'About ' . gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?>" class="vs-about-img" loading="lazy" width="600" height="<?php echo (int) $cv_about_img_h; ?>">
    <?php else: ?><div class="vs-about-img-placeholder">🏢</div><?php endif; ?>
<?php });
$_el_capture('about_video', 'about_right', function() use ($_video_url) {
    if (!$_video_url) return;
    $embed = '';
    if (preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([A-Za-z0-9_-]+)/', $_video_url, $m)) $embed='https://www.youtube.com/embed/'.$m[1];
    elseif (preg_match('/vimeo\.com\/(\d+)/', $_video_url, $m)) $embed='https://player.vimeo.com/video/'.$m[1]; ?>
    <div style="margin-top:16px;border-radius:12px;overflow:hidden;box-shadow:0 4px 16px rgba(0,0,0,.1)">
        <?php if ($embed): ?><iframe src="<?php echo esc_url($embed); ?>" width="100%" height="260" frameborder="0" allow="autoplay;encrypted-media" allowfullscreen loading="lazy"></iframe>
        <?php else: ?><a href="<?php echo esc_url($_video_url); ?>" target="_blank" class="vs-btn vs-btn-ghost" style="margin-top:8px">▶ Watch Video</a><?php endif; ?>
    </div>
<?php });
$_el_capture('about_badges', 'about_right', function() use ($_badges, $brand, $primary, $vendor) {
    if (empty($_badges)) return; ?>
    <div class="vs-about-badges">
        <?php foreach ($_badges as $b): $burl=is_array($b)?($b['url']??$b):$b; if(!$burl)continue; $_ab_brand = gs_vs_safe_brand( $brand, $primary, $vendor ); $balt=is_array($b)?($b['name']??($_ab_brand.' certification badge')):($_ab_brand.' certification badge'); ?>
        <img src="<?php echo esc_url($burl); ?>" alt="<?php echo esc_attr($balt); ?>" loading="lazy" width="80" height="80">
        <?php endforeach; ?>
    </div>
<?php });

// ── SERVICES elements ──────────────────────────────────────────────────────
$_cur = 'services';
$_el_capture('services_title', $_cur, function() use ($primary, $hd, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_SERVICES') && GS_USE_MODULE_ENGINE_SERVICES ) ) {
        echo \GoodService\Modules\ServicesModule::render_title( $primary, $hd );
        return;
    }
    $sec_title = $primary->services_section_title ?? 'Our Services';
    $sec_desc  = $primary->services_section_desc  ?? ''; ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow"><?php echo esc_html($hd['services_section_subtitle']??'What We Offer'); ?></div>
        <h2 class="vs-sec-title"><?php echo esc_html($sec_title); ?></h2>
        <?php if($sec_desc): ?><div class="vs-sec-sub"><?php echo esc_html($sec_desc); ?></div><?php endif; ?>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('services_grid', $_cur, function() use (
    $primary, $cd, $cv_svc_grid_cols, $cv_svc_max_rows, $_can_lead_popup,
    $cv_svc_icon_img_width, $cv_svc_icon_img_size, $cv_svc_icon_img_radius,
    $cv_svc_icon_img_bg_opacity, $cv_svc_icon_img_border_w, $cv_svc_icon_img_padding,
    $cv_svc_icon_img_shadow, $cv_svc_icon_img_rotation, $cv_svc_icon_img_fit,
    $cv_svc_icon_img_opacity, $shadow_map
) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_SERVICES') && GS_USE_MODULE_ENGINE_SERVICES ) ) {
        echo \GoodService\Modules\ServicesModule::render_grid(
            $primary, $cd, $cv_svc_grid_cols, $cv_svc_max_rows, $_can_lead_popup,
            $cv_svc_icon_img_width, $cv_svc_icon_img_size, $cv_svc_icon_img_radius,
            $cv_svc_icon_img_bg_opacity, $cv_svc_icon_img_border_w, $cv_svc_icon_img_padding,
            $cv_svc_icon_img_shadow, $cv_svc_icon_img_rotation, $cv_svc_icon_img_fit,
            $cv_svc_icon_img_opacity, $shadow_map
        );
        return;
    }
    if (empty($primary->services_data)) return;
    // Real feature, items 3 & 4: limits total visible services to
    // columns × rows when a max-rows limit is set (0 = unlimited).
    $_svc_render_list = gs_vs_normalize_view_more_sections( $primary->services_data );
    if ( $cv_svc_max_rows > 0 ) {
        $_svc_render_list = array_slice( $_svc_render_list, 0, $cv_svc_grid_cols * $cv_svc_max_rows );
    }

    // ── Category grouping — real feature, explicitly requested ─────────────
    // Points 4/5: if no categories exist, OR categories exist but nothing
    // is actually assigned to any of them, this must render byte-for-byte
    // identical to today's flat grid — never switch to a grouped layout
    // just because empty categories happen to exist.
    $_svc_cats = is_array( $primary->service_categories ?? null ) ? $primary->service_categories : [];
    $_svc_cat_ids_used = [];
    foreach ( $_svc_render_list as $_s ) {
        if ( ! empty( $_s['category_id'] ) ) { $_svc_cat_ids_used[ $_s['category_id'] ] = true; }
    }
    // Only categories that (a) still exist in the vendor's own list AND
    // (b) have at least one real item assigned ever get a heading —
    // point 7's "empty categories must never be shown."
    $_svc_cats_active = array_values( array_filter( $_svc_cats, fn( $c ) => isset( $_svc_cat_ids_used[ $c['id'] ?? null ] ) ) );
    $_svc_is_categorized = ! empty( $_svc_cats_active );

    // Single card renderer, shared by both the flat and grouped paths below
    // — avoids duplicating the two-mode (image/icon) card markup.
    $_render_svc_card = function( $svc ) use (
        $_can_lead_popup,
        $cv_svc_icon_img_width, $cv_svc_icon_img_size, $cv_svc_icon_img_radius,
        $cv_svc_icon_img_bg_opacity, $cv_svc_icon_img_border_w, $cv_svc_icon_img_padding,
        $cv_svc_icon_img_shadow, $cv_svc_icon_img_rotation, $cv_svc_icon_img_fit,
        $cv_svc_icon_img_opacity, $shadow_map, $cd, $primary
    ) {
        $_svc_has_vms = !empty($svc['view_more_sections']);
        // Real feature — Services field structure, designed after analyzing
        // the Packages pipeline rather than duplicating it: highlights and
        // full_description are genuinely new, service-specific fields (not
        // present in the original Services structure at all), inserted in
        // the same order Packages uses — structured fields first, then the
        // vendor's own custom Manage Details sections, then reviews last.
        $_svc_structured_sections = [];
        $_svc_highlights = is_array( $svc['highlights'] ?? null ) ? $svc['highlights'] : array_filter( array_map( 'trim', explode( "\n", $svc['highlights'] ?? '' ) ) );
        if ( ! empty( $_svc_highlights ) ) {
            $_svc_structured_sections[] = [ '_field' => 'highlights', 'content_type' => 'list', 'title' => gs_vs_field_label( $cd, 'services', 'step1_highlights_label', 'Highlights' ), 'icon' => '✨', 'list_items' => array_values( $_svc_highlights ) ];
        }
        if ( ! empty( $svc['full_description'] ) ) {
            $_svc_structured_sections[] = [ '_field' => 'full_description', 'content_type' => 'richtext', 'title' => gs_vs_field_label( $cd, 'services', 'field_full_description_label', 'About this service' ), 'icon' => '📝', 'body' => esc_html( $svc['full_description'] ) ];
        }
        $_svc_custom_sections = $_svc_has_vms
            ? ( is_string( $svc['view_more_sections'] ) ? ( json_decode( $svc['view_more_sections'], true ) ?: [] ) : $svc['view_more_sections'] )
            : [];
        $_svc_sections = array_merge( $_svc_structured_sections, $_svc_custom_sections );
        if ( ! empty( $_svc_structured_sections ) ) { $_svc_has_vms = true; }
        // Real feature — merges in Client Reviews (reusing the exact same
        // popup content-type and AJAX endpoint already built for Packages)
        // when the vendor has this enabled, alongside whatever custom
        // sections they've already built via Manage Details.
        $_svc_show_reviews = ( $cd['services_show_reviews'] ?? 1 ) ? true : false;
        if ( $_svc_show_reviews && ! empty( $primary->id ) ) {
            $_svc_sections[] = [ 'content_type' => 'reviews', 'title' => 'Client Reviews', 'icon' => '⭐', 'listing_id' => (int) $primary->id ];
            $_svc_has_vms = true;
        }
        ?>
        <div class="vs-svc-card"<?php if ($_svc_has_vms): ?> style="cursor:pointer" onclick="vsOpenDetailPopup(event,this)"
              data-title="<?php echo esc_attr($svc['name']); ?>" data-duration="<?php echo esc_attr($svc['duration']??''); ?>"
              data-image="<?php echo esc_attr($svc['image'] ?? ($svc['icon_image'] ?? '')); ?>"
              data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $svc['additional_images'] ?? null ) ? $svc['additional_images'] : [] ) ) ) ); ?>"
              data-img-fit="<?php echo esc_attr( in_array( $cd['svc_popup_img_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $cd['svc_popup_img_fit'] ?? 'cover' ) : 'cover' ); ?>"
                       data-slider-interval="<?php echo esc_attr( (int) ( ( (float) ( $cd['svc_slider_interval'] ?? 0 ) ) * 1000 ) ); ?>"
              data-price="<?php echo esc_attr($svc['price'] ?? ''); ?>"
              data-sections="<?php echo esc_attr( wp_json_encode( $_svc_sections ) ); ?>"<?php endif; ?>>
            <?php if (!empty($svc['image'])): ?>
              <!-- Image mode: cover photo at top -->
              <div class="vs-svc-img">
                <div class="vs-img-clip">
                  <img src="<?php echo esc_url($svc['image']); ?>" alt="<?php echo esc_attr($svc['name']); ?>" loading="lazy" width="400" height="300">
                </div>
              </div>
              <div class="vs-svc-card-body">
                <div class="vs-svc-name"><?php echo esc_html($svc['name']); ?></div>
                <?php if (!empty($svc['description'])): ?>
                  <div class="vs-svc-desc" style="margin-top:6px;flex:1"><?php echo esc_html($svc['description']); ?></div>
                <?php endif; ?>
                <?php if ($_svc_has_vms): ?>
                  <a href="#" class="vs-view-more-link" onclick="event.stopPropagation();vsOpenDetailPopup(event,this)"
                     data-title="<?php echo esc_attr($svc['name']); ?>" data-duration="<?php echo esc_attr($svc['duration']??''); ?>"
                     data-image="<?php echo esc_attr($svc['image'] ?? ''); ?>"
                     data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $svc['additional_images'] ?? null ) ? $svc['additional_images'] : [] ) ) ) ); ?>"
                     data-img-fit="<?php echo esc_attr( in_array( $cd['svc_popup_img_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $cd['svc_popup_img_fit'] ?? 'cover' ) : 'cover' ); ?>"
                       data-slider-interval="<?php echo esc_attr( (int) ( ( (float) ( $cd['svc_slider_interval'] ?? 0 ) ) * 1000 ) ); ?>"
                     data-price="<?php echo esc_attr($svc['price'] ?? ''); ?>"
                     data-sections="<?php echo esc_attr( wp_json_encode( $_svc_sections ) ); ?>">View More →</a>
                <?php endif; ?>
              </div>
              <?php if (!empty($svc['price']) || !empty($svc['link']) || $_can_lead_popup): ?>
              <div class="vs-svc-card-footer">
                <?php if (!empty($svc['price'])): ?><div class="vs-svc-price"><?php echo esc_html($svc['price']); ?></div><?php endif; ?>
                <?php if (!empty($svc['link'])): ?><a href="<?php echo esc_url($svc['link']); ?>" onclick="event.stopPropagation()" class="vs-btn vs-btn-ghost" style="font-size:.8rem">Learn More →</a><?php endif; ?>
                <?php if ( $_can_lead_popup ): ?><button onclick="event.stopPropagation();vsOpenSvcEnquiry('<?php echo esc_js($svc['name']); ?>','<?php echo esc_js($svc['price']??''); ?>','<?php echo esc_js( gs_vs_build_service_wizard_extra( $svc ) ); ?>')" class="vs-svc-enquire-btn">📋 Enquire Now</button><?php endif; ?>
              </div>
              <?php endif; ?>
            <?php else: ?>
              <!-- Icon/emoji mode: centred layout -->
              <div class="vs-svc-card-body">
                <div class="vs-svc-icon" <?php if (!empty($svc['icon_image'])): ?>style="
                  width:<?php echo $cv_svc_icon_img_width > 0 ? $cv_svc_icon_img_width.'px' : $cv_svc_icon_img_size.'px'; ?>;
                  height:<?php echo $cv_svc_icon_img_size; ?>px;
                  border-radius:<?php echo $cv_svc_icon_img_radius; ?>px;
                  opacity:<?php echo $cv_svc_icon_img_bg_opacity; ?>;
                  border-width:<?php echo $cv_svc_icon_img_border_w; ?>px;border-style:solid;
                  padding:<?php echo $cv_svc_icon_img_padding; ?>px;
                  box-shadow:<?php echo $shadow_map[$cv_svc_icon_img_shadow] ?? 'none'; ?>;
                  transform:rotate(<?php echo $cv_svc_icon_img_rotation; ?>deg);
                "<?php endif; ?>>
                  <?php if (!empty($svc['icon_image'])): ?>
                    <img src="<?php echo esc_url($svc['icon_image']); ?>" alt="<?php echo esc_attr($svc['name']); ?>" loading="lazy" width="56" height="56" style="object-fit:<?php echo esc_attr($cv_svc_icon_img_fit); ?>;opacity:<?php echo $cv_svc_icon_img_opacity; ?>">
                  <?php else: ?>
                    <span style="font-size:1.6rem"><?php echo !empty($svc['icon']) ? esc_html($svc['icon']) : '🛠️'; ?></span>
                  <?php endif; ?>
                </div>
                <div class="vs-svc-name"><?php echo esc_html($svc['name']); ?></div>
                <?php if (!empty($svc['description'])): ?>
                  <div class="vs-svc-desc" style="margin-top:6px;flex:1"><?php echo esc_html($svc['description']); ?></div>
                <?php endif; ?>
                <?php if ($_svc_has_vms): ?>
                  <a href="#" class="vs-view-more-link" onclick="event.stopPropagation();vsOpenDetailPopup(event,this)"
                     data-title="<?php echo esc_attr($svc['name']); ?>" data-duration="<?php echo esc_attr($svc['duration']??''); ?>"
                     data-image="<?php echo esc_attr($svc['icon_image'] ?? ''); ?>"
                     data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $svc['additional_images'] ?? null ) ? $svc['additional_images'] : [] ) ) ) ); ?>"
                     data-img-fit="<?php echo esc_attr( in_array( $cd['svc_popup_img_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $cd['svc_popup_img_fit'] ?? 'cover' ) : 'cover' ); ?>"
                       data-slider-interval="<?php echo esc_attr( (int) ( ( (float) ( $cd['svc_slider_interval'] ?? 0 ) ) * 1000 ) ); ?>"
                     data-price="<?php echo esc_attr($svc['price'] ?? ''); ?>"
                     data-sections="<?php echo esc_attr( wp_json_encode( $_svc_sections ) ); ?>">View More →</a>
                <?php endif; ?>
              </div>
              <?php if (!empty($svc['price']) || !empty($svc['link']) || $_can_lead_popup): ?>
              <div class="vs-svc-card-footer">
                <?php if (!empty($svc['price'])): ?><div class="vs-svc-price"><?php echo esc_html($svc['price']); ?></div><?php endif; ?>
                <?php if (!empty($svc['link'])): ?><a href="<?php echo esc_url($svc['link']); ?>" onclick="event.stopPropagation()" class="vs-btn vs-btn-ghost" style="font-size:.8rem">Learn More →</a><?php endif; ?>
                <?php if ( $_can_lead_popup ): ?><button onclick="event.stopPropagation();vsOpenSvcEnquiry('<?php echo esc_js($svc['name']); ?>','<?php echo esc_js($svc['price']??''); ?>','<?php echo esc_js( gs_vs_build_service_wizard_extra( $svc ) ); ?>')" class="vs-svc-enquire-btn">📋 Enquire Now</button><?php endif; ?>
              </div>
              <?php endif; ?>
            <?php endif; ?>
            <?php
            // Real feature — closes the confirmed crawlability gap: the
            // View More popup's real content (view_more_sections) only
            // ever existed inside the data-sections JSON attribute above,
            // revealed to sighted users solely via a click-triggered JS
            // handler. Rendered here as genuine, server-rendered text —
            // present for search crawlers and screen readers, invisible
            // to sighted users via .vs-sr-only (not display:none, so it
            // stays in the accessibility tree). Uses the exact same
            // SeoContentExtractor already powering SEO scoring, so the
            // crawlable text and the scored text can never drift apart
            // into two different extraction implementations.
            if ( $_svc_has_vms ) {
                $_svc_popup_text = \GoodService\SEO\SeoContentExtractor::extract_view_more_text( $svc['view_more_sections'] );
                if ( $_svc_popup_text !== '' ) {
                    echo '<div class="vs-sr-only">' . esc_html( $_svc_popup_text ) . '</div>';
                }
            }
            ?>
        </div>
        <?php
    }; // end $_render_svc_card

    if ( ! $_svc_is_categorized ) {
        // ── Flat path — identical to the original, always-worked layout.
        // Points 4/5/10: this is the ONLY path that runs for a vendor with
        // no categories, or categories nothing is assigned to.
        ?>
        <div class="vs-svc-grid">
            <?php foreach ($_svc_render_list as $svc): if (empty($svc['name'])) continue; $_render_svc_card($svc); endforeach; ?>
        </div>
        <?php
    } else {
        // ── Grouped path — point 7: one section per category, heading =
        // category name, only that category's items underneath. Runs only
        // once real assignments exist, per point 6.
        foreach ( $_svc_cats_active as $_cat ) {
            $_cat_items = array_filter( $_svc_render_list, fn( $s ) => ! empty( $s['name'] ) && ( $s['category_id'] ?? '' ) === $_cat['id'] );
            if ( empty( $_cat_items ) ) continue; // safety net — never render an empty heading
            ?>
            <div class="vs-svc-cat-heading"><?php echo esc_html( $_cat['name'] ); ?></div>
            <div class="vs-svc-grid" style="margin-bottom:28px">
                <?php foreach ( $_cat_items as $svc ) { $_render_svc_card($svc); } ?>
            </div>
            <?php
        }
        // Uncategorised items (no category_id, or one pointing at a
        // deleted category) still display — point 6 never says to hide
        // them, only to group what IS assigned. Shown last, unlabeled,
        // so nothing a vendor added silently disappears from their page.
        $_svc_uncat = array_filter( $_svc_render_list, function( $s ) use ( $_svc_cats ) {
            if ( empty( $s['name'] ) ) return false;
            $cid = $s['category_id'] ?? '';
            if ( $cid === '' ) return true;
            return ! in_array( $cid, array_column( $_svc_cats, 'id' ), true );
        } );
        if ( ! empty( $_svc_uncat ) ) {
            ?>
            <div class="vs-svc-grid">
                <?php foreach ( $_svc_uncat as $svc ) { $_render_svc_card($svc); } ?>
            </div>
            <?php
        }
    }
    ?>
    <!-- Part 21.2 — Compact pricing table for quick scanning -->
    <?php
    $priced_svcs = array_filter($primary->services_data ?? [], fn($s) => !empty($s['price']) && !empty($s['name']));
    // Real fix: the count requirement was previously stacked on top of the
    // toggle unconditionally, meaning the toggle produced zero visible
    // effect for any listing with fewer than 3 priced services — exactly
    // why it appeared non-functional. An explicit vendor choice (the key
    // genuinely exists in customizer_data) is now the sole, independent
    // gate; the 3+ count only applies as the default when untouched,
    // matching "work independently of other service-related settings."
    $_pricing_glance_explicit = array_key_exists( 'show_pricing_glance', (array) $cd );
    $_show_pricing_glance = ! empty( $priced_svcs ) && ( $_pricing_glance_explicit
        ? ( (bool) $cd['show_pricing_glance'] )
        : ( count( $priced_svcs ) >= 3 ) );
    if ($_show_pricing_glance):
    ?>
    <div style="margin-top:20px;background:#F8FAFC;border-radius:12px;overflow:hidden;border:1px solid #E2E8F0">
      <div style="padding:12px 18px;font-weight:700;font-size:.85rem;color:#475569;background:#F1F5F9;border-bottom:1px solid #E2E8F0">💰 Pricing at a glance</div>
      <table style="width:100%;border-collapse:collapse">
        <?php foreach(array_slice($priced_svcs, 0, 8) as $psvc): ?>
        <tr style="border-bottom:1px solid #F1F5F9">
          <td style="padding:10px 18px;font-size:.85rem;color:#334155"><?php echo esc_html($psvc['name']); ?></td>
          <td style="padding:10px 18px;font-size:.85rem;font-weight:700;color:#2563EB;text-align:right;white-space:nowrap"><?php echo esc_html($psvc['price']); ?></td>
          <td style="padding:10px 14px;text-align:right">
            <?php if ( $_can_lead_popup ): ?><button onclick="vsOpenSvcEnquiry('<?php echo esc_js($psvc['name']); ?>','<?php echo esc_js($psvc['price']); ?>','<?php echo esc_js( gs_vs_build_service_wizard_extra( $psvc ) ); ?>')"
                    style="background:none;border:1.5px solid #2563EB;color:#2563EB;border-radius:7px;padding:4px 10px;font-size:.72rem;font-weight:700;cursor:pointer">
              Get Quote
            </button><?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </table>
      <div style="padding:10px 18px;font-size:.74rem;color:#647388;border-top:1px solid #F1F5F9">Prices are indicative. Final quote after site visit.</div>
    </div>
    <?php endif; ?>
<?php });

// ── PROCESS elements ────────────────────────────────────────────────────────
$_cur = 'process';
$_el_capture('process_title', $_cur, function() use ($primary, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_PROCESS') && GS_USE_MODULE_ENGINE_PROCESS ) ) {
        echo \GoodService\Modules\ProcessModule::render_title( $primary->process_section_title ?? null );
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($primary->process_section_title ?? 'How Process Works'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0;background:var(--vs-yellow)"></div>
    </div>
<?php });
$_el_capture('process_steps', $_cur, function() use ($primary, $_gs_all_modules_on, $cd) {
    $_proc_img_fit = (string) ( $cd['process_img_fit'] ?? 'contain' );
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_PROCESS') && GS_USE_MODULE_ENGINE_PROCESS ) ) {
        echo \GoodService\Modules\ProcessModule::render_steps( $primary->process_data ?? null, $_proc_img_fit );
        return;
    }
    if (empty($primary->process_data)) return;
    $_proc_img_style = \gs_vs_img_display_style( [ 'fit' => $_proc_img_fit ] )['img']; ?>
    <div class="vs-proc-grid">
        <?php foreach ($primary->process_data as $i => $step): if (empty($step['title'])) continue; ?>
        <div class="vs-proc-step">
            <div class="vs-proc-num">
                <?php if (!empty($step['icon_image'])): ?>
                    <img src="<?php echo esc_url($step['icon_image']); ?>" alt="<?php echo esc_attr($step['title']); ?>" loading="lazy" width="108" height="108" style="<?php echo esc_attr( $_proc_img_style ); ?>">
                <?php else: ?>
                    <?php echo !empty($step['icon'])?esc_html($step['icon']):($i+1); ?>
                <?php endif; ?>
            </div>
            <div class="vs-proc-title"><?php echo esc_html($step['title']); ?></div>
            <?php if (!empty($step['description'])): ?><div class="vs-proc-desc"><?php echo esc_html($step['description']); ?></div><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── ITEMS elements ──────────────────────────────────────────────────────────
// $_gs_items_cd_snapshot: a same-value copy of $cd under a different name,
// used ONLY by the GS_USE_MODULE_ENGINE_ITEMS flag-on branch below. This is
// deliberate, not accidental: the original items_grid closure never captures
// $cd itself (a real, pre-existing bug — see ProductsItemsModule's docblock),
// and adding $cd to that closure's own use() list under its real name would
// silently FIX that bug even when the flag is off, since the closure's own
// inner card-renderer also does `use($cd)` and would then pick up the newly
// non-null value. Capturing the same data under a different name avoids that
// — the flag-off path's $cd remains exactly as undefined as it always was.
$_gs_items_cd_snapshot = $cd;
$_cur = 'items';
$_el_capture('items_title', $_cur, function() use ($_items_title_raw, $hd, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_ITEMS') && GS_USE_MODULE_ENGINE_ITEMS ) ) {
        echo \GoodService\Modules\ProductsItemsModule::render_title( $_items_title_raw, $hd );
        return;
    }
    $title = $hd['items_section_title'] ?? $_items_title_raw; ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($title); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('items_grid', $_cur, function() use ($all_items, $cv_items_img_h, $cv_items_img_w, $cv_items_img_fit, $cv_card_r, $cv_card_pad, $cv_card_shadow_val, $cv_card_imgr, $cv_btn_bg, $cv_btn_text, $cv_btn_r, $cv_qbtn_style, $qbtn_inline, $items_qbtn_inline, $lid, $cv_items_grid_cols, $cv_items_max_rows, $primary, $_gs_items_cd_snapshot, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_ITEMS') && GS_USE_MODULE_ENGINE_ITEMS ) ) {
        echo \GoodService\Modules\ProductsItemsModule::render_grid(
            $all_items, $primary, $_gs_items_cd_snapshot, $items_qbtn_inline, $cv_items_grid_cols, $cv_items_max_rows
        );
        return;
    }
    if (empty($all_items)) return;
    // Real feature, items 3 & 4: limits total visible items to
    // columns × rows when a max-rows limit is set (0 = unlimited).
    $_items_render_list = $all_items;
    if ( $cv_items_max_rows > 0 ) {
        $_items_render_list = array_slice( $_items_render_list, 0, $cv_items_grid_cols * $cv_items_max_rows );
    }

    // ── Category grouping — real feature, explicitly requested. Same rules
    // as Services: flat and unchanged unless real assignments exist, empty
    // categories never shown, independent from the Services category list.
    $_item_cats = is_array( $primary->product_categories ?? null ) ? $primary->product_categories : [];
    $_item_cat_ids_used = [];
    foreach ( $_items_render_list as $_it ) {
        if ( ! empty( $_it['category_id'] ) ) { $_item_cat_ids_used[ $_it['category_id'] ] = true; }
    }
    $_item_cats_active = array_values( array_filter( $_item_cats, fn( $c ) => isset( $_item_cat_ids_used[ $c['id'] ?? null ] ) ) );
    $_item_is_categorized = ! empty( $_item_cats_active );

    // Single card renderer, shared by the flat and grouped paths — only
    // $items_qbtn_inline is needed from outer scope (confirmed by
    // extracting every variable reference in this block before writing
    // this closure, after the Services closure-scope bug).
    $_render_item_card = function( $item ) use ( $items_qbtn_inline, $cd, $primary ) {
        $iname  = $item['item_title'] ?? $item['name'] ?? ''; if (!$iname) return;
        $iimg   = $item['item_image']    ?? $item['image']       ?? '';
        $iprice = $item['item_price']    ?? $item['price']       ?? '';
        $idesc  = $item['item_description'] ?? $item['description'] ?? '';
        $itype  = $item['item_type']     ?? 'service';
        $iquote = (bool)($item['show_quote_button'] ?? false);
        $icat   = $item['item_category'] ?? $item['category'] ?? '';
        // List format: desc starts with "- " or "* " lines → render as bullets
        $desc_is_list = false;
        $desc_lines   = [];
        if ($idesc) {
            $lines = array_filter(array_map('trim', explode("\n", $idesc)));
            $list_lines = array_filter($lines, fn($l) => preg_match('/^[-*•]\s+/', $l));
            if (count($list_lines) >= 2 && count($list_lines) >= count($lines) * 0.6) {
                $desc_is_list = true;
                $desc_lines   = array_map(fn($l) => preg_replace('/^[-*•]\s+/', '', $l), $lines);
            }
        }
        // Real feature — merges in Client Reviews (same content-type and
        // AJAX endpoint already built for Packages/Services) alongside
        // whatever custom sections the vendor has built via Manage Details.
        // Real feature — Products & Services field structure, designed
        // separately from Services (different field names: key_features
        // not highlights, no duration concept) since products and
        // services genuinely need different information. Same proven
        // ordering as Services: structured fields first, then the
        // vendor's own custom Manage Details sections, then reviews last.
        $_item_structured_sections = [];
        $_item_key_features = is_array( $item['key_features'] ?? null ) ? $item['key_features'] : array_filter( array_map( 'trim', explode( "\n", $item['key_features'] ?? '' ) ) );
        if ( ! empty( $_item_key_features ) ) {
            $_item_structured_sections[] = [ '_field' => 'key_features', 'content_type' => 'list', 'title' => gs_vs_field_label( $cd, 'products', 'step1_features_label', 'Key Features' ), 'icon' => '✨', 'list_items' => array_values( $_item_key_features ) ];
        }
        if ( ! empty( $item['full_description'] ) ) {
            $_item_structured_sections[] = [ '_field' => 'full_description', 'content_type' => 'richtext', 'title' => gs_vs_field_label( $cd, 'products', 'field_full_description_label', 'About this item' ), 'icon' => '📝', 'body' => esc_html( $item['full_description'] ) ];
        }
        $_item_has_vms = !empty($item['view_more_sections']);
        $_item_show_reviews = ( $cd['items_show_reviews'] ?? 1 ) ? true : false;
        $_item_custom_sections = $_item_has_vms
            ? ( is_string( $item['view_more_sections'] ) ? ( json_decode( $item['view_more_sections'], true ) ?: [] ) : $item['view_more_sections'] )
            : [];
        $_item_sections = array_merge( $_item_structured_sections, $_item_custom_sections );
        if ( ! empty( $_item_structured_sections ) ) { $_item_has_vms = true; }
        if ( $_item_show_reviews && ! empty( $primary->id ) ) {
            $_item_sections[] = [ 'content_type' => 'reviews', 'title' => 'Client Reviews', 'icon' => '⭐', 'listing_id' => (int) $primary->id ];
            $_item_has_vms = true;
        }
        ?>
        <div class="vs-item-card"<?php if ($_item_has_vms): ?> style="cursor:pointer" onclick="vsOpenDetailPopup(event,this)"
              data-title="<?php echo esc_attr($iname); ?>" data-availability="<?php echo esc_attr($item['availability']??''); ?>" data-delivery="<?php echo esc_attr($item['delivery_info']??''); ?>"
              data-image="<?php echo esc_attr($iimg ?: ''); ?>"
              data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $item['additional_images'] ?? null ) ? $item['additional_images'] : [] ) ) ) ); ?>"
              data-img-fit="<?php echo esc_attr( in_array( $cd['items_popup_img_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $cd['items_popup_img_fit'] ?? 'cover' ) : 'cover' ); ?>"
                       data-slider-interval="<?php echo esc_attr( (int) ( ( (float) ( $cd['items_slider_interval'] ?? 0 ) ) * 1000 ) ); ?>"
              data-price="<?php echo esc_attr($iprice ?: ''); ?>"
              data-item-type="<?php echo esc_attr($itype); ?>"
              data-sections="<?php echo esc_attr( wp_json_encode( $_item_sections ) ); ?>"<?php endif; ?>>
            <!-- Image section with padding -->
            <div class="vs-item-img-wrap">
                <span class="vs-item-badge"><?php echo esc_html(ucfirst($itype)); ?></span>
                <?php if ($iimg): ?>
                <div class="vs-img-clip">
                  <img src="<?php echo esc_url($iimg); ?>" alt="<?php echo esc_attr($iname); ?>" loading="lazy" width="400" height="300">
                </div>
                <?php else: ?>
                <div class="vs-item-img-placeholder">
                    <?php echo $itype === 'product' ? '📦' : '🛠️'; ?>
                </div>
                <?php endif; ?>
            </div>
            <!-- Card body -->
            <div class="vs-item-body">
                <?php if ($icat): ?><div style="font-size:.7rem;font-weight:700;color:var(--vs-primary,#2563EB);text-transform:uppercase;letter-spacing:.08em;margin-bottom:2px"><?php echo esc_html($icat); ?></div><?php endif; ?>
                <div class="vs-item-title"><?php echo esc_html($iname); ?></div>
                <?php if ($idesc): ?>
                    <?php if ($desc_is_list && !empty($desc_lines)): ?>
                    <ul class="vs-item-desc-list">
                        <?php foreach (array_slice($desc_lines, 0, 5) as $dl): ?>
                        <li><?php echo esc_html($dl); ?></li>
                        <?php endforeach; ?>
                        <?php if (count($desc_lines) > 5): ?><li style="color:#647388">+<?php echo count($desc_lines)-5; ?> more…</li><?php endif; ?>
                    </ul>
                    <?php else: ?>
                    <p class="vs-item-desc"><?php echo esc_html(mb_strimwidth($idesc, 0, 120, '…')); ?></p>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if ($_item_has_vms): ?>
                    <a href="#" class="vs-view-more-link" onclick="event.stopPropagation();vsOpenDetailPopup(event,this)"
                       data-title="<?php echo esc_attr($iname); ?>" data-availability="<?php echo esc_attr($item['availability']??''); ?>" data-delivery="<?php echo esc_attr($item['delivery_info']??''); ?>"
                       data-image="<?php echo esc_attr($iimg ?: ''); ?>"
                       data-price="<?php echo esc_attr($iprice ?: ''); ?>"
                       data-item-type="<?php echo esc_attr($itype); ?>"
                       data-sections="<?php echo esc_attr( wp_json_encode( $_item_sections ) ); ?>">View More →</a>
                <?php endif; ?>
                <!-- Footer: price + CTA -->
                <?php if ($iprice || $itype === 'product' || $iquote || !empty($item['item_price'])): ?>
                <div class="vs-item-footer">
                    <?php if ($iprice): ?>
                    <div class="vs-item-price"><?php echo esc_html($iprice); ?></div>
                    <?php else: ?><div></div><?php endif; ?>
                    <?php if ($itype === 'product' || $iquote || !empty($item['item_price'])): ?>
                    <button onclick="event.stopPropagation();<?php
                        $_item_extra_product = wp_json_encode( ['full_description'=>$item['full_description']??'','availability'=>$item['availability']??'','delivery_info'=>$item['delivery_info']??'','key_features'=>array_values(is_array($item['key_features']??null)?$item['key_features']:array_filter(array_map('trim',explode(chr(10),$item['key_features']??''))))] );
                        $_item_extra_service = gs_vs_build_service_wizard_extra( $item, 'delivery_info' );
                        echo $itype === 'product'
                            ? "vsOpenQuote('" . esc_js($iname) . "','" . esc_js($iprice) . "','" . esc_js($_item_extra_product) . "')"
                            : "vsOpenSvcEnquiry('" . esc_js($iname) . "','" . esc_js($iprice) . "','" . esc_js($_item_extra_service) . "')";
                    ?>"
                            class="vs-item-quote-btn" style="<?php echo esc_attr($items_qbtn_inline); ?>">
                        ✉ Send Inquiry
                    </button>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <?php
            // Real feature — same crawlability fix as the services card
            // renderer: view_more_sections' real content only ever
            // existed inside the data-sections JSON attribute above,
            // revealed solely via a click-triggered JS handler. Uses the
            // same SeoContentExtractor already powering SEO scoring, so
            // this can never drift out of sync with what's actually scored.
            if ( ! empty( $item['view_more_sections'] ) ) {
                $_item_popup_text = \GoodService\SEO\SeoContentExtractor::extract_view_more_text( $item['view_more_sections'] );
                if ( $_item_popup_text !== '' ) {
                    echo '<div class="vs-sr-only">' . esc_html( $_item_popup_text ) . '</div>';
                }
            }
            ?>
        </div>
        <?php
    }; // end $_render_item_card

    if ( ! $_item_is_categorized ) {
        // ── Flat path — identical to the original, always-worked layout.
        ?>
        <div class="vs-items-grid">
            <?php foreach ($_items_render_list as $item) { $_render_item_card($item); } ?>
        </div>
        <?php
    } else {
        // ── Grouped path — one section per category with real items.
        foreach ( $_item_cats_active as $_cat ) {
            $_cat_items = array_filter( $_items_render_list, fn( $it ) => ( $it['category_id'] ?? '' ) === $_cat['id'] );
            if ( empty( $_cat_items ) ) continue;
            ?>
            <div class="vs-svc-cat-heading"><?php echo esc_html( $_cat['name'] ); ?></div>
            <div class="vs-items-grid" style="margin-bottom:28px">
                <?php foreach ( $_cat_items as $item ) { $_render_item_card($item); } ?>
            </div>
            <?php
        }
        // Uncategorised items still display, shown last, unlabeled.
        $_item_uncat = array_filter( $_items_render_list, function( $it ) use ( $_item_cats ) {
            $cid = $it['category_id'] ?? '';
            if ( $cid === '' ) return true;
            return ! in_array( $cid, array_column( $_item_cats, 'id' ), true );
        } );
        if ( ! empty( $_item_uncat ) ) {
            ?>
            <div class="vs-items-grid">
                <?php foreach ( $_item_uncat as $item ) { $_render_item_card($item); } ?>
            </div>
            <?php
        }
    }
?>
<?php });

// ── STATS elements ──────────────────────────────────────────────────────────
$_cur = 'stats';
$_el_capture('stats_title', $_cur, function() use ($hd) { ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow" style="color:rgba(255,255,255,.55)">Trusted by our customers</div>
        <h2 class="vs-sec-title"><?php echo esc_html($hd['stats_section_title'] ?? 'Proven Success in Numbers'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0;background:var(--vs-yellow)"></div>
    </div>
<?php });
$_el_capture('stats_grid', $_cur, function() use ($primary, $hd) {
    if (empty($primary->stats_data)) return;
    // stats_data is saved as flat {key=>value} from the form, e.g. {total_services:'5', happy_clients:'200'}
    // The label map matches the form's stats_map in create-listing.php
    $stats_labels = [
        'total_services'     => ['Services Offered',  '🛠️'],
        'experience_years'   => ['Years Experience',  '📅'],
        'happy_clients'      => ['Happy Clients',     '😊'],
        'projects_completed' => ['Projects Completed','✅'],
        'positive_reviews'   => ['Positive Reviews',  '⭐'],
        'cities_served'      => ['Cities Served',     '🏙️'],
    ];
    $stats_array = $primary->stats_data;
    // Support both flat {key:val} format (from form) and array-of-objects format
    $is_flat = is_array($stats_array) && !empty($stats_array) && !isset(array_values($stats_array)[0]['stat_number']);
    ?>
    <div class="vs-stats-grid">
        <?php if ($is_flat): ?>
        <?php foreach ($stats_array as $sk => $sv): ?>
            <?php if (!$sv || $sv === '0' || $sv === '') continue; ?>
            <?php
            // Real fix — the title was previously always the hardcoded
            // label below, with no way for a vendor to customize it. Now
            // uses the vendor's own custom title (stats_label_<key>,
            // configured in the admin form) when set, falling back to the
            // original hardcoded label unchanged for every vendor who
            // hasn't customized it — zero behavior change unless they opt in.
            $lbl = !empty($hd['stats_label_' . $sk]) ? $hd['stats_label_' . $sk] : ($stats_labels[$sk][0] ?? ucwords(str_replace('_', ' ', $sk)));
            $ico = $stats_labels[$sk][1] ?? '';
            // Splits a numeric value from any trailing non-numeric suffix
            // (e.g. "500K" -> numeric part 500, suffix "K") so the counter
            // animation only counts the number, not letters.
            preg_match('/^([\d,.]+)(.*)$/', trim((string) $sv), $_sv_m);
            $sv_num = isset($_sv_m[1]) ? (float) str_replace(',', '', $_sv_m[1]) : (float) $sv;
            $sv_suffix = trim($_sv_m[2] ?? '') . '+';
            ?>
            <div class="vs-stat-card">
                <?php if ($ico && $cv_stat_icon_position !== 'none'): ?><div class="vs-stat-icon"><?php echo esc_html($ico); ?></div><?php endif; ?>
                <div class="vs-stat-val vs-stat-counter" data-count-to="<?php echo esc_attr($sv_num); ?>" data-count-suffix="<?php echo esc_attr($sv_suffix); ?>">0<?php echo esc_html($sv_suffix); ?></div>
                <div class="vs-stat-lbl"><?php echo esc_html($lbl); ?></div>
            </div>
        <?php endforeach; ?>
        <?php else: ?>
        <?php foreach ($stats_array as $st): ?>
            <?php if (empty($st['stat_number'])) continue; ?>
            <div class="vs-stat-card">
                <?php if (!empty($st['stat_icon']) && $cv_stat_icon_position !== 'none'): ?><div class="vs-stat-icon"><?php echo esc_html($st['stat_icon']); ?></div><?php endif; ?>
                <div class="vs-stat-val"><?php echo esc_html($st['stat_number']); ?></div>
                <?php if (!empty($st['stat_label'])): ?>
                <div class="vs-stat-lbl"><?php echo esc_html($st['stat_label']); ?></div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
<?php });

// ── GALLERY elements ─────────────────────────────────────────────────────────
// $_gs_gallery_aspect_snapshot: same reasoning as $_gs_items_cd_snapshot
// above — the original 'gallery_grid' closure never captures
// $cv_gallery_aspect in its own use() list (a real, minor bug — see
// GalleryModule's docblock), so adding $cv_gallery_aspect itself to that
// closure's use() list would silently fix the bug even when the flag is
// off. Capturing the same value under a different name avoids that.
$_gs_gallery_aspect_snapshot = $cv_gallery_aspect;
$_cur = 'gallery';
$_el_capture('gallery_title', $_cur, function() use ($_gallery_sec_title, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_GALLERY') && GS_USE_MODULE_ENGINE_GALLERY ) ) {
        echo \GoodService\Modules\GalleryModule::render_title( $_gallery_sec_title );
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:20px">
        <div class="vs-sec-eyebrow">Visual Showcase</div>
        <h2 class="vs-sec-title"><?php echo esc_html($_gallery_sec_title); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('gallery_filters', $_cur, function() use ($primary, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_GALLERY') && GS_USE_MODULE_ENGINE_GALLERY ) ) {
        echo \GoodService\Modules\GalleryModule::render_filters( $primary->gallery ?? null );
        return;
    }
    if (empty($primary->gallery)) return;
    $tags = [];
    foreach ($primary->gallery as $g) { if (!empty($g['tag'])) $tags[$g['tag']]=true; }
    if (empty($tags)) return; ?>
    <div class="vs-gal-filters" id="vs-gal-filters">
        <button class="vs-gal-filter on" data-tag="all">All</button>
        <?php foreach (array_keys($tags) as $t): ?><button class="vs-gal-filter" data-tag="<?php echo esc_attr($t); ?>"><?php echo esc_html($t); ?></button><?php endforeach; ?>
    </div>
<?php });
$_el_capture('gallery_grid', $_cur, function() use ($primary, $cv_gallery_img_h, $cv_gallery_img_w, $cv_gallery_img_fit, $cv_gallery_lightbox, $cv_gallery_captions, $_gs_gallery_aspect_snapshot, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_GALLERY') && GS_USE_MODULE_ENGINE_GALLERY ) ) {
        echo \GoodService\Modules\GalleryModule::render_grid(
            $primary, $primary->gallery ?? null, $cv_gallery_img_h, $cv_gallery_img_w, $cv_gallery_img_fit,
            $cv_gallery_lightbox, $cv_gallery_captions, $_gs_gallery_aspect_snapshot
        );
        return;
    }
    if (empty($primary->gallery)) return;
    $images = array_filter(array_map(fn($g) => is_array($g) ? ($g['url'] ?? $g) : $g, $primary->gallery));
    if (empty($images)) return; ?>
    <div class="vs-gallery-grid" id="vs-gallery-grid">
        <?php foreach ($images as $i => $img_url): $_gal_caption = ( $primary->title ?? 'Gallery' ) . ' — photo ' . ( (int) $i + 1 ); ?>
        <div class="vs-gallery-item"<?php echo $cv_gallery_lightbox ? ' onclick="vsLightbox(\''.esc_js($img_url).'\',\''.esc_js($_gal_caption).'\')"' : ''; ?>>
            <div class="vs-img-clip">
                <?php
                $_gal_ar_parts = array_map('intval', explode('/', $cv_gallery_aspect));
                $_gal_w = 400;
                $_gal_h = ( count($_gal_ar_parts) === 2 && $_gal_ar_parts[0] > 0 ) ? (int) round( 400 * $_gal_ar_parts[1] / $_gal_ar_parts[0] ) : 300;
                ?>
                <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($_gal_caption); ?>" loading="lazy" width="<?php echo $_gal_w; ?>" height="<?php echo $_gal_h; ?>">
                <?php if ($cv_gallery_captions): ?><div class="vs-gallery-caption"><?php echo esc_html($_gal_caption); ?></div><?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── WHY elements ─────────────────────────────────────────────────────────────
$_cur = 'why';
$_el_capture('why_title', $_cur, function() use ($hd, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_WHY') && GS_USE_MODULE_ENGINE_WHY ) ) {
        echo \GoodService\Modules\WhyModule::render_title( $hd );
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Our Promise</div>
        <h2 class="vs-sec-title"><?php echo esc_html($hd['why_section_title'] ?? 'Why Choose Us'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('why_grid', $_cur, function() use ($primary, $_gs_all_modules_on, $cd) {
    $_why_img_fit = (string) ( $cd['why_img_fit'] ?? 'contain' );
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_WHY') && GS_USE_MODULE_ENGINE_WHY ) ) {
        echo \GoodService\Modules\WhyModule::render_grid( $primary->why_choose_data ?? null, $_why_img_fit );
        return;
    }
    if (empty($primary->why_choose_data)) return;
    $items = $primary->why_choose_data;
    if (isset($items['section_title'])) unset($items['section_title']);
    $_why_img_style = \gs_vs_img_display_style( [ 'fit' => $_why_img_fit ] )['img']; ?>
    <div class="vs-why-grid">
        <?php foreach ($items as $w): if (empty($w['title'])) continue;
            $wicon = !empty($w['icon_image']) ? $w['icon_image'] : ($w['icon'] ?? '✅'); ?>
        <div class="vs-why-card">
            <div class="vs-why-icon-wrap"><?php
                if (filter_var($wicon, FILTER_VALIDATE_URL)) {
                    echo '<img src="' . esc_url($wicon) . '" alt="' . esc_attr($w['title']) . '" loading="lazy" width="88" height="88" style="' . esc_attr( $_why_img_style ) . '">';
                } else {
                    echo '<span style="font-size:2rem;line-height:1">' . esc_html($wicon) . '</span>';
                }
            ?></div>
            <div class="vs-why-title"><?php echo esc_html($w['title']); ?></div>
            <?php if (!empty($w['description'])): ?>
            <div class="vs-why-desc"><?php echo esc_html($w['description']); ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── KEY HIGHLIGHTS elements ────────────────────────────────────────────────
$_cur = 'highlights';
$_el_capture('highlights_title', $_cur, function() use ($cd) {
    // Real feature — flag-gated module-engine integration point (Phase 1
    // of the modular architecture roadmap). Defaults to OFF (constant
    // undefined) so every live vendor sees ZERO behavior change unless
    // this is explicitly enabled on a real staging environment first —
    // never intended to be silently switched on. When enabled, calls the
    // proven, byte-for-byte-verified HighlightsModule::render_title()
    // instead of the inline markup below; the surrounding $_el_capture
    // wrapper is untouched either way, so Layout & Element Manager's
    // reordering/hiding of this element keeps working identically.
    if ( defined( 'GS_USE_MODULE_ENGINE_HIGHLIGHTS' ) && GS_USE_MODULE_ENGINE_HIGHLIGHTS ) {
        echo \GoodService\Modules\HighlightsModule::render_title( $cd );
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['highlights_section_title'] ?? 'Key Highlights'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('highlights_grid', $_cur, function() use ($primary, $_json_has_real_content, $cd) {
    // Same flag-gated integration point, for the grid half. See the
    // 'highlights_title' callback above for the full rationale — kept
    // identical here rather than factored out, so each callback remains
    // independently readable and independently safe to revert.
    if ( defined( 'GS_USE_MODULE_ENGINE_HIGHLIGHTS' ) && GS_USE_MODULE_ENGINE_HIGHLIGHTS ) {
        echo \GoodService\Modules\HighlightsModule::render_grid( $primary->highlights_data ?? null, $cd );
        return;
    }
    if (!$_json_has_real_content($primary->highlights_data ?? null, 'title')) return;
    $items = is_string($primary->highlights_data) ? (json_decode($primary->highlights_data, true) ?: []) : $primary->highlights_data;
    $_hl_img_settings = is_array( $cd['highlights_img_display'] ?? null ) ? $cd['highlights_img_display'] : [];
    $_hl_icon_size_style = ! empty( $_hl_img_settings['icon_size'] ) ? 'width:' . (int) $_hl_img_settings['icon_size'] . 'px;height:' . (int) $_hl_img_settings['icon_size'] . 'px;' : '';
    $_hl_icon_fit = ( $_hl_img_settings['fit'] ?? 'cover' ) === 'contain' ? 'contain' : 'cover';
    ?>
    <div class="vs-hl-grid">
        <?php foreach ($items as $h): if (empty($h['title'])) continue;
            $hicon = !empty($h['icon_image']) ? $h['icon_image'] : ($h['icon'] ?? '✨'); ?>
        <div class="vs-hl-card">
            <div class="vs-hl-icon" style="<?php echo esc_attr($_hl_icon_size_style); ?>"><?php
                if (filter_var($hicon, FILTER_VALIDATE_URL)) {
                    echo '<img src="' . esc_url($hicon) . '" alt="' . esc_attr($h['title']) . '" loading="lazy" width="' . (!empty($_hl_img_settings['icon_size']) ? (int)$_hl_img_settings['icon_size'] : 60) . '" height="' . (!empty($_hl_img_settings['icon_size']) ? (int)$_hl_img_settings['icon_size'] : 60) . '" style="object-fit:' . $_hl_icon_fit . ($_hl_icon_fit === 'contain' ? ';padding:8px;box-sizing:border-box' : '') . '">';
                } else {
                    echo esc_html($hicon);
                }
            ?></div>
            <div class="vs-hl-body">
                <div class="vs-hl-title"><?php echo esc_html($h['title']); ?></div>
                <?php if (!empty($h['description'])): ?>
                <div class="vs-hl-desc"><?php echo esc_html($h['description']); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── FEATURES & AMENITIES elements ──────────────────────────────────────────
$_cur = 'amenities';
$_el_capture('amenities_title', $_cur, function() use ($cd) {
    // Real feature — flag-gated module-engine integration point (Phase 2).
    // Same rationale as the Highlights integration point: defaults OFF,
    // zero behavior change for any live vendor unless explicitly enabled.
    if ( defined( 'GS_USE_MODULE_ENGINE_AMENITIES' ) && GS_USE_MODULE_ENGINE_AMENITIES ) {
        echo \GoodService\Modules\AmenitiesModule::render_title( $cd );
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['amenities_section_title'] ?? 'Features & Amenities'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('amenities_grid', $_cur, function() use ($primary, $_json_has_real_content, $cd) {
    if ( defined( 'GS_USE_MODULE_ENGINE_AMENITIES' ) && GS_USE_MODULE_ENGINE_AMENITIES ) {
        echo \GoodService\Modules\AmenitiesModule::render_grid( $primary->amenities_data ?? null, $cd );
        return;
    }
    if (!$_json_has_real_content($primary->amenities_data ?? null, 'title')) return;
    $items = is_string($primary->amenities_data) ? (json_decode($primary->amenities_data, true) ?: []) : $primary->amenities_data;
    $_am_img_settings = is_array( $cd['amenities_img_display'] ?? null ) ? $cd['amenities_img_display'] : [];
    $_am_icon_size_style = ! empty( $_am_img_settings['icon_size'] ) ? 'width:' . (int) $_am_img_settings['icon_size'] . 'px;height:' . (int) $_am_img_settings['icon_size'] . 'px;' : '';
    $_am_icon_fit = ( $_am_img_settings['fit'] ?? 'cover' ) === 'contain' ? 'contain' : 'cover';
    ?>
    <div class="vs-am-grid">
        <?php foreach ($items as $a): if (empty($a['title'])) continue;
            $aicon = !empty($a['icon_image']) ? $a['icon_image'] : ($a['icon'] ?? '✅'); ?>
        <div class="vs-am-tile">
            <div class="vs-am-check" style="<?php echo esc_attr($_am_icon_size_style); ?>"><?php
                if (filter_var($aicon, FILTER_VALIDATE_URL)) {
                    echo '<img src="' . esc_url($aicon) . '" alt="' . esc_attr($a['title']) . '" loading="lazy" width="' . (!empty($_am_img_settings['icon_size']) ? (int)$_am_img_settings['icon_size'] : 32) . '" height="' . (!empty($_am_img_settings['icon_size']) ? (int)$_am_img_settings['icon_size'] : 32) . '" style="object-fit:' . $_am_icon_fit . ($_am_icon_fit === 'contain' ? ';padding:4px;box-sizing:border-box' : '') . '">';
                } else {
                    echo esc_html($aicon);
                }
            ?></div>
            <div class="vs-am-body">
                <div class="vs-am-title"><?php echo esc_html($a['title']); ?></div>
                <?php if (!empty($a['description'])): ?>
                <div class="vs-am-desc"><?php echo esc_html($a['description']); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── FACILITIES elements ────────────────────────────────────────────────────
$_cur = 'facilities';
$_el_capture('facilities_title', $_cur, function() use ($cd) {
    if ( defined( 'GS_USE_MODULE_ENGINE_FACILITIES' ) && GS_USE_MODULE_ENGINE_FACILITIES ) {
        echo \GoodService\Modules\FacilitiesModule::render_title( $cd );
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['facilities_section_title'] ?? 'Our Facilities'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('facilities_grid', $_cur, function() use ($primary, $_json_has_real_content, $cd) {
    if ( defined( 'GS_USE_MODULE_ENGINE_FACILITIES' ) && GS_USE_MODULE_ENGINE_FACILITIES ) {
        echo \GoodService\Modules\FacilitiesModule::render_grid( $primary->facilities_data ?? null, $cd );
        return;
    }
    if (!$_json_has_real_content($primary->facilities_data ?? null, 'title')) return;
    $items = is_string($primary->facilities_data) ? (json_decode($primary->facilities_data, true) ?: []) : $primary->facilities_data;
    $_fac_img_settings = is_array( $cd['facilities_img_display'] ?? null ) ? $cd['facilities_img_display'] : [];
    $_fac_style_desk = gs_vs_img_display_style( $_fac_img_settings, false );
    $_fac_style_mob  = gs_vs_img_display_style( $_fac_img_settings, true );
    ?>
    <div class="vs-fac-grid">
        <?php foreach ($items as $f): if (empty($f['title'])) continue;
            $ficon = !empty($f['icon_image']) ? $f['icon_image'] : ($f['icon'] ?? '🏢');
            $has_photo = !empty($f['image']);
        ?>
        <div class="vs-fac-card">
            <div class="vs-fac-photo vs-fac-photo-custom" style="<?php echo esc_attr($_fac_style_desk['container']); ?>">
                <?php if ($has_photo): ?>
                    <img src="<?php echo esc_url($f['image']); ?>" alt="<?php echo esc_attr($f['title']); ?>" loading="lazy" width="400" height="320" style="<?php echo esc_attr($_fac_style_desk['img']); ?>">
                <?php else: ?>
                    <div class="vs-fac-photo-fallback"><?php
                        if (filter_var($ficon, FILTER_VALIDATE_URL)) {
                            echo '<img src="' . esc_url($ficon) . '" alt="" loading="lazy" width="400" height="320" style="width:100%;height:100%;object-fit:cover">';
                        } else {
                            echo esc_html($ficon);
                        }
                    ?></div>
                <?php endif; ?>
                <?php if ($has_photo && !filter_var($ficon, FILTER_VALIDATE_URL)): ?>
                <div class="vs-fac-icon-badge"><?php echo esc_html($ficon); ?></div>
                <?php endif; ?>
            </div>
            <div class="vs-fac-body">
                <div class="vs-fac-title"><?php echo esc_html($f['title']); ?></div>
                <?php if (!empty($f['description'])): ?>
                <div class="vs-fac-desc"><?php echo esc_html($f['description']); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php if ( ! empty( $_fac_img_settings['height_mobile'] ) ): ?>
    <style>
    @media(max-width:640px){
      .vs-fac-photo-custom{ height:<?php echo (int) $_fac_img_settings['height_mobile']; ?>px !important; }
    }
    </style>
    <?php endif; ?>
<?php });

// ── AWARDS & RECOGNITION elements ──────────────────────────────────────────
$_cur = 'awards';
$_el_capture('awards_title', $_cur, function() use ($cd) {
    if ( defined( 'GS_USE_MODULE_ENGINE_AWARDS' ) && GS_USE_MODULE_ENGINE_AWARDS ) {
        echo \GoodService\Modules\AwardsModule::render_title( $cd );
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['awards_section_title'] ?? 'Awards & Recognition'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('awards_grid', $_cur, function() use ($primary, $_json_has_real_content, $cd) {
    if ( defined( 'GS_USE_MODULE_ENGINE_AWARDS' ) && GS_USE_MODULE_ENGINE_AWARDS ) {
        echo \GoodService\Modules\AwardsModule::render_grid( $primary->awards_data ?? null, $cd );
        return;
    }
    if (!$_json_has_real_content($primary->awards_data ?? null, 'title')) return;
    $items = is_string($primary->awards_data) ? (json_decode($primary->awards_data, true) ?: []) : $primary->awards_data;
    $_awd_img_settings = is_array( $cd['awards_img_display'] ?? null ) ? $cd['awards_img_display'] : [];
    $_awd_style = gs_vs_img_display_style( $_awd_img_settings );
    $_awd_ring_style = ! empty( $_awd_img_settings['badge_size'] ) ? 'width:' . (int) $_awd_img_settings['badge_size'] . 'px;height:' . (int) $_awd_img_settings['badge_size'] . 'px;' : '';
    ?>
    <div class="vs-awd-grid">
        <?php foreach ($items as $a): if (empty($a['title'])) continue; ?>
        <div class="vs-awd-card">
            <div class="vs-awd-badge-ring" style="<?php echo esc_attr($_awd_ring_style); ?>">
                <div class="vs-awd-badge">
                    <?php if (!empty($a['image'])): ?>
                        <img src="<?php echo esc_url($a['image']); ?>" alt="<?php echo esc_attr($a['title']); ?>" loading="lazy" width="100" height="100" style="<?php echo esc_attr($_awd_style['img']); ?>">
                    <?php else: ?>
                        <span class="vs-awd-badge-emoji">🏆</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="vs-awd-title"><?php echo esc_html($a['title']); ?></div>
            <?php if (!empty($a['issuer']) || !empty($a['year'])): ?>
            <div class="vs-awd-meta"><?php echo esc_html(trim(($a['issuer'] ?? '') . (!empty($a['issuer']) && !empty($a['year']) ? ' · ' : '') . ($a['year'] ?? ''))); ?></div>
            <?php endif; ?>
            <?php if (!empty($a['description'])): ?>
            <div class="vs-awd-desc"><?php echo esc_html($a['description']); ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── LANGUAGES SPOKEN elements ──────────────────────────────────────────────
$_cur = 'languages';
$_el_capture('languages_title', $_cur, function() use ($cd) {
    if ( defined( 'GS_USE_MODULE_ENGINE_LANGUAGES' ) && GS_USE_MODULE_ENGINE_LANGUAGES ) {
        echo \GoodService\Modules\LanguagesModule::render_title( $cd );
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['languages_section_title'] ?? 'Languages Spoken'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('languages_list', $_cur, function() use ($primary, $_json_has_real_content) {
    if ( defined( 'GS_USE_MODULE_ENGINE_LANGUAGES' ) && GS_USE_MODULE_ENGINE_LANGUAGES ) {
        echo \GoodService\Modules\LanguagesModule::render_grid( $primary->languages_data ?? null );
        return;
    }
    if (!$_json_has_real_content($primary->languages_data ?? null, 'name')) return;
    $items = is_string($primary->languages_data) ? (json_decode($primary->languages_data, true) ?: []) : $primary->languages_data;
    $proficiency_levels = [ 'Native' => 4, 'Fluent' => 3, 'Conversational' => 2, 'Basic' => 1 ];
    ?>
    <div class="vs-lang-grid">
        <?php foreach ($items as $l): if (empty($l['name'])) continue;
            $level = $l['proficiency'] ?? 'Fluent';
            $filled = $proficiency_levels[$level] ?? 3;
        ?>
        <div class="vs-lang-card">
            <div class="vs-lang-globe">🌐</div>
            <div class="vs-lang-name"><?php echo esc_html($l['name']); ?></div>
            <div class="vs-lang-bar">
                <?php for ($i = 1; $i <= 4; $i++): ?>
                <div class="vs-lang-seg<?php echo $i <= $filled ? ' filled' : ''; ?>"></div>
                <?php endfor; ?>
            </div>
            <div class="vs-lang-level"><?php echo esc_html($level); ?></div>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── PACKAGES & PRICING elements ────────────────────────────────────────────
$_cur = 'packages';
$_el_capture('packages_title', $_cur, function() use ($cd, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_PACKAGES') && GS_USE_MODULE_ENGINE_PACKAGES ) ) {
        echo \GoodService\Modules\PackagesModule::render_title( $cd );
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['packages_section_title'] ?? 'Our Packages'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('packages_grid', $_cur, function() use ($primary, $_json_has_real_content, $cd, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_PACKAGES') && GS_USE_MODULE_ENGINE_PACKAGES ) ) {
        echo \GoodService\Modules\PackagesModule::render_grid( $primary, $cd );
        return;
    }
    if (!$_json_has_real_content($primary->packages_data ?? null, 'name')) return;
    $items = is_string($primary->packages_data) ? (json_decode($primary->packages_data, true) ?: []) : $primary->packages_data;
    $currency = gs_setting('currency_symbol', '₹');
    ?>
    <div class="vs-pkg-grid">
        <?php
        $show_reviews = ( $cd['packages_show_reviews'] ?? 1 ) ? true : false;
        foreach ($items as $p): if (empty($p['name'])) continue;
            $features_full = is_array($p['features'] ?? null) ? $p['features'] : array_filter(array_map('trim', explode("\n", $p['features'] ?? '')));
            $features_full = array_values(array_filter(array_map(function($f){ return ltrim(trim((string)$f), '-✕+✓ '); }, $features_full)));
            $features_preview = array_slice($features_full, 0, 2);
            $cta_text   = $p['cta_text'] ?? 'Book Now';

            // Build the popup's "sections" — reuses the exact same vsOpenDetailPopup /
            // vsRenderDetailSection system Products already use, so this popup is
            // the same component, not a new one.
            $dp_sections = [];
            if ( ! empty( $features_full ) ) {
                $dp_sections[] = [ 'content_type' => 'list', 'title' => "What's Included", 'icon' => '✅', 'list_items' => $features_full ];
            }
            if ( ! empty( $p['description'] ) ) {
                $dp_sections[] = [ 'content_type' => 'richtext', 'title' => 'About this package', 'icon' => '📝', 'body' => esc_html( $p['description'] ) ];
            }
            // Real fix — merges in the vendor's own custom "Manage Details"
            // sections (built via the same clOpenDetailBuilder tool Products
            // and Services already have), which were previously never wired
            // up for packages at all — vendors had no way to add custom FAQ/
            // table/image sections to a package's popup before this.
            $custom_vms = is_string( $p['view_more_sections'] ?? null ) ? ( json_decode( $p['view_more_sections'], true ) ?: [] ) : ( $p['view_more_sections'] ?? [] );
            if ( is_array( $custom_vms ) ) {
                foreach ( $custom_vms as $vms_section ) {
                    if ( is_array( $vms_section ) ) { $dp_sections[] = $vms_section; }
                }
            }
            if ( $show_reviews && ! empty( $primary->id ) ) {
                $dp_sections[] = [ 'content_type' => 'reviews', 'title' => 'Client Reviews', 'icon' => '⭐', 'listing_id' => (int) $primary->id ];
            }
            $price_display = ! empty( $p['price'] ) ? ( $currency . $p['price'] . ( ! empty( $p['period'] ) ? ' · ' . $p['period'] : '' ) ) : 'Custom';

            // ── Booking Wizard data payload ──────────────────────────────
            // Parses this package's own "addons" text field ("Name|Price"
            // per line, same format convention as "features") into a
            // structured array, and bundles everything the wizard's JS
            // needs client-side — avoids a second server round-trip just to
            // fetch package details the page already rendered once.
            $addons_raw = is_array( $p['addons'] ?? null ) ? $p['addons'] : array_filter( array_map( 'trim', explode( "\n", $p['addons'] ?? '' ) ) );
            $addons_parsed = [];
            foreach ( $addons_raw as $addon_line ) {
                $parts = array_map( 'trim', explode( '|', $addon_line, 2 ) );
                if ( empty( $parts[0] ) ) { continue; }
                $addons_parsed[] = [ 'name' => $parts[0], 'price' => isset( $parts[1] ) ? (float) preg_replace( '/[^0-9.]/', '', $parts[1] ) : 0 ];
            }
            $wizard_payload = [
                'name'        => $p['name'],
                'price'       => (float) preg_replace( '/[^0-9.]/', '', (string) ( $p['price'] ?? 0 ) ),
                'period'      => $p['period'] ?? '',
                'description' => $p['description'] ?? '',
                'image'       => $p['image'] ?? '',
                'features'    => $features_full,
                'addons'      => $addons_parsed,
                'gst_type'    => $p['gst_type'] ?? 'not_applicable',
                'gst_percent' => (float) ( $p['gst_percent'] ?? 0 ),
                'currency'    => $currency,
                'listing_id'  => (int) ( $primary->id ?? 0 ),
            ];
            $use_wizard = ( $cd['packages_booking_wizard'] ?? 1 ) ? true : false;
        ?>
        <div class="vs-pkg-card">
            <div class="vs-pkg-img">
                <?php if (!empty($p['image'])): ?>
                    <img src="<?php echo esc_url($p['image']); ?>" alt="<?php echo esc_attr($p['name']); ?>" loading="lazy" width="400" height="300" style="<?php echo esc_attr( gs_vs_img_display_style( is_array( $cd['packages_img_display'] ?? null ) ? $cd['packages_img_display'] : [] )['img'] ); ?>">
                <?php else: ?>
                    <div class="vs-pkg-img-fallback">📦</div>
                <?php endif; ?>
            </div>
            <div class="vs-pkg-main">
                <?php if (!empty($p['badge'])): ?><div class="vs-pkg-badge"><?php echo esc_html($p['badge']); ?></div><?php endif; ?>
                <div class="vs-pkg-name"><?php echo esc_html($p['name']); ?></div>
                <?php if (!empty($primary->avg_rating) && !empty($primary->review_count)): ?>
                <div class="vs-pkg-meta">
                    <span class="vs-pkg-rating"><span class="vs-pkg-rating-star">★</span> <?php echo esc_html(number_format((float)$primary->avg_rating, 2)); ?></span>
                    <span>(<?php echo esc_html((int)$primary->review_count); ?> reviews)</span>
                </div>
                <?php endif; ?>
                <?php if (!empty($p['short_description'])): ?>
                <div class="vs-pkg-short-desc"><?php echo esc_html($p['short_description']); ?></div>
                <?php endif; ?>
                <div class="vs-pkg-price-row">
                    <span class="vs-pkg-price"><?php echo esc_html($price_display); ?></span>
                </div>
                <?php if (!empty($features_preview)): ?>
                <ul class="vs-pkg-features">
                    <?php foreach ($features_preview as $feat): ?>
                    <li><?php echo esc_html($feat); ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
                <button type="button" class="vs-pkg-view-details"
                        data-title="<?php echo esc_attr($p['name']); ?>"
                        data-price="<?php echo esc_attr($price_display); ?>"
                        data-image="<?php echo esc_attr($p['image'] ?? ''); ?>"
                        data-images="<?php echo esc_attr( wp_json_encode( array_values( array_filter( is_array( $p['additional_images'] ?? null ) ? $p['additional_images'] : [] ) ) ) ); ?>"
                        data-img-fit="<?php echo esc_attr( in_array( $cd['pkg_popup_img_fit'] ?? 'cover', [ 'cover', 'contain', 'fill', 'scale-down', 'none' ], true ) ? ( $cd['pkg_popup_img_fit'] ?? 'cover' ) : 'cover' ); ?>"
                       data-slider-interval="<?php echo esc_attr( (int) ( ( (float) ( $cd['pkg_slider_interval'] ?? 0 ) ) * 1000 ) ); ?>"
                        data-sections="<?php echo esc_attr(wp_json_encode($dp_sections)); ?>"
                        data-pkg="<?php echo $use_wizard ? esc_attr(wp_json_encode($wizard_payload)) : ''; ?>"
                        onclick="vsOpenDetailPopup(event, this)">View details</button>
                <?php if ($use_wizard): ?>
                <button type="button" class="vs-pkg-add-btn" data-pkg="<?php echo esc_attr(wp_json_encode($wizard_payload)); ?>" onclick="vsOpenBookingWizard(this)"><?php echo esc_html($cta_text); ?></button>
                <?php else: ?>
                <button type="button" class="vs-pkg-add-btn" onclick="vsOpenInquiry({name:'<?php echo esc_js($p['name']); ?>',type:'service',price:'<?php echo esc_js($price_display); ?>'})"><?php echo esc_html($cta_text); ?></button>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── MEMBERSHIP PLANS elements ──────────────────────────────────────────────
$_cur = 'memberships';
$_el_capture('memberships_title', $_cur, function() use ($cd) {
    if ( defined( 'GS_USE_MODULE_ENGINE_MEMBERSHIPS' ) && GS_USE_MODULE_ENGINE_MEMBERSHIPS ) {
        echo \GoodService\Modules\MembershipsModule::render_title( $cd );
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['memberships_section_title'] ?? 'Membership Plans'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('memberships_grid', $_cur, function() use ($primary, $_json_has_real_content) {
    if ( defined( 'GS_USE_MODULE_ENGINE_MEMBERSHIPS' ) && GS_USE_MODULE_ENGINE_MEMBERSHIPS ) {
        echo \GoodService\Modules\MembershipsModule::render_grid( $primary->memberships_data ?? null );
        return;
    }
    if (!$_json_has_real_content($primary->memberships_data ?? null, 'name')) return;
    $items = is_string($primary->memberships_data) ? (json_decode($primary->memberships_data, true) ?: []) : $primary->memberships_data;
    $currency = gs_setting('currency_symbol', '₹');
    $cycle_labels = ['month'=>'month','year'=>'year','quarter'=>'quarter','week'=>'week','one-time'=>''];
    $tier_icons = ['🥉','🥈','🥇','💎'];
    ?>
    <div class="vs-mem-grid">
        <?php foreach ($items as $mi => $m): if (empty($m['name'])) continue;
            $featured   = !empty($m['featured']);
            $badge_text = $m['badge'] ?? ($featured ? 'Most Popular' : '');
            $benefits   = is_array($m['benefits'] ?? null) ? $m['benefits'] : array_filter(array_map('trim', explode("\n", $m['benefits'] ?? '')));
            $cta_text   = $m['cta_text'] ?? 'Join Now';
            $cta_link   = $m['cta_link'] ?? '#vs-inq-open';
            $cycle      = $cycle_labels[$m['billing_cycle'] ?? 'month'] ?? ($m['billing_cycle'] ?? '');
            $tier_n     = min($mi + 1, 4);
        ?>
        <div class="vs-mem-card<?php echo $featured ? ' featured' : ''; ?>">
            <?php if ($badge_text): ?><div class="vs-mem-badge"><?php echo esc_html($badge_text); ?></div><?php endif; ?>
            <div class="vs-mem-tier-badge vs-mem-tier-<?php echo $tier_n; ?>"><?php echo $tier_icons[$tier_n-1]; ?></div>
            <div class="vs-mem-name"><?php echo esc_html($m['name']); ?></div>
            <div class="vs-mem-price">
                <?php if (!empty($m['price'])): ?>
                    <?php echo esc_html($currency . $m['price']); ?><span><?php echo $cycle ? '/' . esc_html($cycle) : ''; ?></span>
                <?php else: ?>
                    <span style="font-size:1.1rem">Custom</span>
                <?php endif; ?>
            </div>
            <?php if (!empty($m['description'])): ?><div class="vs-mem-desc"><?php echo esc_html($m['description']); ?></div><?php endif; ?>
            <?php if (!empty($benefits)): ?>
            <ul class="vs-mem-benefits">
                <?php foreach ($benefits as $b):
                    $included = !(str_starts_with($b, '-') || str_starts_with($b, '✕'));
                    $b_txt = ltrim($b, '-✕+✓ ');
                    if (!$b_txt) continue;
                ?>
                <li class="<?php echo $included ? '' : 'no-benefit'; ?>">
                    <span class="vs-mem-benefit-ico <?php echo $included ? 'yes' : 'no'; ?>"><?php echo $included ? '✓' : '–'; ?></span>
                    <?php echo esc_html($b_txt); ?>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
            <a href="<?php echo esc_url($cta_link); ?>" class="vs-mem-cta"
               onclick="if(this.getAttribute('href')==='#vs-inq-open'){event.preventDefault();vsOpenInquiry({name:'<?php echo esc_js($m['name']); ?>',type:'service'});}">
                <?php echo esc_html($cta_text); ?>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── LICENCES & CERTIFICATIONS elements ─────────────────────────────────────
$_cur = 'certifications';
$_el_capture('certifications_title', $_cur, function() use ($cd) {
    if ( defined( 'GS_USE_MODULE_ENGINE_CERTIFICATIONS' ) && GS_USE_MODULE_ENGINE_CERTIFICATIONS ) {
        echo \GoodService\Modules\CertificationsModule::render_title( $cd );
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <h2 class="vs-sec-title"><?php echo esc_html($cd['certifications_section_title'] ?? 'Licences & Certifications'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('certifications_grid', $_cur, function() use ($primary, $_json_has_real_content, $cd) {
    if ( defined( 'GS_USE_MODULE_ENGINE_CERTIFICATIONS' ) && GS_USE_MODULE_ENGINE_CERTIFICATIONS ) {
        echo \GoodService\Modules\CertificationsModule::render_grid( $primary->certifications_data ?? null, $cd );
        return;
    }
    if (!$_json_has_real_content($primary->certifications_data ?? null, 'title')) return;
    $items = is_string($primary->certifications_data) ? (json_decode($primary->certifications_data, true) ?: []) : $primary->certifications_data;
    $_cert_img_settings = is_array( $cd['certifications_img_display'] ?? null ) ? $cd['certifications_img_display'] : [];
    $_cert_style = gs_vs_img_display_style( $_cert_img_settings );
    $_cert_size_style = ! empty( $_cert_img_settings['badge_size'] ) ? 'width:' . (int) $_cert_img_settings['badge_size'] . 'px;height:' . (int) $_cert_img_settings['badge_size'] . 'px;' : '';
    ?>
    <div class="vs-awd-grid">
        <?php foreach ($items as $c): if (empty($c['title'])) continue; ?>
        <div class="vs-awd-card">
            <div class="vs-awd-badge-ring" style="border-radius:20px;background:conic-gradient(from 180deg,#DBEAFE,#BFDBFE,#DBEAFE);<?php echo esc_attr($_cert_size_style); ?>">
                <div class="vs-awd-badge" style="border-radius:16px">
                    <?php if (!empty($c['image'])): ?>
                        <img src="<?php echo esc_url($c['image']); ?>" alt="<?php echo esc_attr($c['title']); ?>" loading="lazy" width="100" height="100" style="<?php echo esc_attr($_cert_style['img']); ?>">
                    <?php else: ?>
                        <span class="vs-awd-badge-emoji">📜</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="vs-cert-title"><?php echo esc_html($c['title']); ?></div>
            <?php if (!empty($c['issuer']) || !empty($c['year'])): ?>
            <div class="vs-awd-meta"><?php echo esc_html(trim(($c['issuer'] ?? '') . (!empty($c['issuer']) && !empty($c['year']) ? ' · ' : '') . ($c['year'] ?? ''))); ?></div>
            <?php endif; ?>
            <?php if (!empty($c['description'])): ?>
            <div class="vs-cert-desc"><?php echo esc_html($c['description']); ?></div>
            <?php endif; ?>
            <?php if (!empty($c['credential_id'])): ?>
            <div class="vs-awd-credential">ID: <?php echo esc_html($c['credential_id']); ?></div>
            <?php endif; ?>
            <?php if (!empty($c['verify_url'])): ?>
            <br><a href="<?php echo esc_url($c['verify_url']); ?>" target="_blank" rel="noopener noreferrer" class="vs-awd-verify">✓ Verify Credential →</a>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── WARRANTY / GUARANTEE elements ──────────────────────────────────────────
$_cur = 'warranty';
$_el_capture('warranty_block', $_cur, function() use ($primary, $_json_has_real_content) {
    if ( defined( 'GS_USE_MODULE_ENGINE_WARRANTY' ) && GS_USE_MODULE_ENGINE_WARRANTY ) {
        echo \GoodService\Modules\WarrantyModule::render_block( $primary->warranty_data ?? null );
        return;
    }
    if (!$_json_has_real_content($primary->warranty_data ?? null, 'title')) return;
    $w = is_string($primary->warranty_data) ? (json_decode($primary->warranty_data, true) ?: []) : $primary->warranty_data;
    if (empty($w['title'])) return;
    $desc_lines = !empty($w['description']) ? array_values(array_filter(array_map('trim', explode("\n", $w['description'])))) : [];
    ?>
    <div class="vs-war-banner">
        <div class="vs-war-seal"><?php echo esc_html($w['icon'] ?? '🛡️'); ?></div>
        <div>
            <div class="vs-war-title"><?php echo esc_html($w['title']); ?></div>
            <?php if (!empty($w['duration'])): ?>
            <div class="vs-war-duration"><?php echo esc_html($w['duration']); ?></div>
            <?php endif; ?>
            <?php if (count($desc_lines) > 1): ?>
            <ul class="vs-war-checklist">
                <?php foreach ($desc_lines as $line): ?>
                <li><?php echo esc_html(ltrim($line, '-✓• ')); ?></li>
                <?php endforeach; ?>
            </ul>
            <?php elseif (!empty($w['description'])): ?>
            <div class="vs-war-desc-plain"><?php echo nl2br(esc_html($w['description'])); ?></div>
            <?php endif; ?>
        </div>
    </div>
<?php });

// ── TERMS & CONDITIONS elements ────────────────────────────────────────────
$_cur = 'terms';
$_el_capture('terms_block', $_cur, function() use ($primary, $_json_has_real_content) {
    if ( defined( 'GS_USE_MODULE_ENGINE_TERMS' ) && GS_USE_MODULE_ENGINE_TERMS ) {
        echo \GoodService\Modules\TermsModule::render_block( $primary->terms_data ?? null );
        return;
    }
    if (!$_json_has_real_content($primary->terms_data ?? null, 'content')) return;
    $t = is_string($primary->terms_data) ? (json_decode($primary->terms_data, true) ?: []) : $primary->terms_data;
    if (empty($t['content'])) return;
    $clauses = array_values(array_filter(array_map('trim', explode("\n", $t['content']))));
    ?>
    <details class="vs-terms-clause" style="max-width:820px;margin:0 auto">
        <summary>
            <span class="vs-terms-title" style="flex:1"><?php echo esc_html($t['title'] ?? 'Terms & Conditions'); ?></span>
            <span class="vs-terms-clause-arrow">▾</span>
        </summary>
        <div class="vs-terms-clause-body" style="padding-left:20px">
            <?php if (count($clauses) > 1): ?>
            <div class="vs-terms-wrap">
                <?php foreach ($clauses as $i => $clause): ?>
                <div style="display:flex;gap:12px;align-items:flex-start">
                    <span class="vs-terms-num" style="margin-top:2px"><?php echo $i + 1; ?></span>
                    <span><?php echo esc_html(ltrim($clause, '-•0123456789. ')); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <span style="white-space:pre-line"><?php echo esc_html($t['content']); ?></span>
            <?php endif; ?>
        </div>
    </details>
<?php });

// ── REVIEWS elements ──────────────────────────────────────────────────────────
$_cur = 'reviews';
$_el_capture('reviews_title', $_cur, function() use ($reviews, $review_avg) {
    $total = count($reviews);
    $dist = [5=>0, 4=>0, 3=>0, 2=>0, 1=>0];
    foreach ($reviews as $rv) { $r = max(1,min(5,(int)($rv->rating??5))); $dist[$r]++; }
    ?>
    <!-- Rating Summary Widget -->
    <div class="vs-rev-header">
        <div class="vs-rev-summary">
            <?php if ($review_avg > 0): ?>
            <div class="vs-rev-big-score"><?php echo number_format($review_avg,1); ?></div>
            <div class="vs-rev-big-stars"><?php
                for ($s=1;$s<=5;$s++){ echo '<span style="color:'.($s<=$review_avg?'#F59E0B':'#D1D5DB').'">★</span>'; }
            ?></div>
            <div class="vs-rev-count"><?php echo $total; ?> Review<?php echo $total!==1?'s':''; ?></div>
            <?php else: ?>
            <div style="font-size:2.5rem;margin-bottom:8px">⭐</div>
            <div style="font-weight:800;color:#1E293B;font-size:1rem">No Reviews Yet</div>
            <div style="font-size:.82rem;color:#64748B;margin-top:4px">Be the first to review</div>
            <?php endif; ?>
        </div>
        <?php if ($review_avg > 0 && $total > 0): ?>
        <div class="vs-rev-bars">
            <?php foreach ([5,4,3,2,1] as $star):
                $pct = $total > 0 ? round(($dist[$star]/$total)*100) : 0; ?>
            <div class="vs-rev-bar-row">
                <span class="vs-rev-bar-lbl"><?php echo $star; ?>★</span>
                <div class="vs-rev-bar-track"><div class="vs-rev-bar-fill" style="width:<?php echo $pct; ?>%"></div></div>
                <span class="vs-rev-bar-cnt"><?php echo $dist[$star]; ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">What Our Clients Say</div>
        <h2 class="vs-sec-title">Customer Reviews</h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });

$_el_capture('reviews_grid', 'reviews', function() use ($reviews, $review_avg, $lid) { ?>
    <?php if (!empty($reviews)): ?>
    <div class="vs-reviews-carousel-wrap">
      <div class="vs-reviews-carousel-track" id="vs-rev-track">
        <?php
        // Duplicate cards for seamless loop (need at least 2x for infinite scroll)
        $rev_html = '';
        foreach ($reviews as $rv):
            $rname   = $rv->reviewer_name ?? $rv->wp_name ?? 'Customer';
            $rrating = max(1,min(5,(int)($rv->rating??5)));
            $rtext   = $rv->review_text ?? '';
            $rdate   = !empty($rv->created_at) ? date('M Y',strtotime($rv->created_at)) : '';
            $rhelpful= (int)($rv->helpful_count??0);
            $rvid    = (int)($rv->id??0);
            $bgs     = ['#2563EB','#7C3AED','#059669','#D97706','#DC2626','#0891B2','#0F766E','#9333EA'];
            $bg      = $bgs[abs(crc32($rname)) % count($bgs)];
            ob_start(); ?>
        <div class="vs-review-card">
            <div class="vs-review-head">
                <div class="vs-review-avatar" style="background:<?php echo $bg; ?>"><?php echo esc_html(strtoupper(mb_substr($rname,0,1))); ?></div>
                <div style="flex:1;min-width:0">
                    <div class="vs-review-name"><?php echo esc_html($rname); ?></div>
                    <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin-top:2px">
                        <div class="vs-review-stars"><?php
                            for($s=1;$s<=5;$s++){
                                echo '<span style="color:'.($s<=$rrating?'#F59E0B':'#E2E8F0').'">★</span>';
                            }
                        ?></div>
                        <?php if ($rdate): ?><div class="vs-review-date"><?php echo esc_html($rdate); ?></div><?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if ($rtext): ?>
            <div class="vs-review-text">"<?php echo esc_html($rtext); ?>"</div>
            <?php endif; ?>
            <?php if ($rvid): ?>
            <button class="vs-review-helpful" onclick="vsHelpfulReview(<?php echo $rvid; ?>,this)">
                👍 Helpful<?php if ($rhelpful > 0): ?> (<?php echo $rhelpful; ?>)<?php endif; ?>
            </button>
            <?php endif; ?>
        </div>
            <?php $rev_html .= ob_get_clean();
        endforeach;
        // Real fix: only duplicate for the seamless infinite-loop technique
        // when there are enough cards that the seam is invisible. With too
        // few reviews, duplicating makes the same review visibly appear
        // twice in a row — show each review exactly once instead.
        $_rev_count = count($reviews);
        if ($_rev_count >= 4) {
            echo $rev_html . $rev_html;
        } else {
            echo $rev_html;
        }
        ?>
      </div>
    </div>
    <script>
    (function(){
      // Adjust animation duration based on card count for smooth constant speed
      var track = document.getElementById('vs-rev-track');
      if (!track) return;
      var cards = track.querySelectorAll('.vs-review-card').length;
      var reviewCount = <?php echo $_rev_count; ?>;
      if (reviewCount < 4) {
        // Real fix: too few reviews to loop seamlessly — disable the
        // scrolling animation entirely and just show them statically.
        track.style.animation = 'none';
        track.style.justifyContent = 'center';
        return;
      }
      var uniqueCards = Math.round(cards / 2);
      // ~4s per card for readable pace
      var dur = Math.max(20, uniqueCards * 5) + 's';
      track.style.animationDuration = dur;
    })();
    </script>
    <?php else: ?>
    <div style="text-align:center;padding:48px 20px">
        <div style="font-size:3.5rem;margin-bottom:16px">💬</div>
        <div style="font-weight:800;color:#1E293B;font-size:1.05rem;margin-bottom:8px">No Reviews Yet</div>
        <div style="font-size:.87rem;color:#64748B;max-width:360px;margin:0 auto;line-height:1.65">Be the first to share your experience.</div>
    </div>
    <?php endif; ?>

    <!-- Review Submission Form -->
    <div class="vs-review-form-wrap" id="vs-review-form-wrap">
        <button class="vs-review-form-toggle" id="vs-review-form-toggle" onclick="vsToggleReviewForm()">
            ✏️ Write a Review
        </button>
        <div class="vs-review-form-box" id="vs-review-form-box" style="display:none">
            <div class="vs-review-form-title">Share Your Experience</div>
            <div class="vs-review-form-sub">Your honest feedback helps others make better decisions.</div>
            <div class="vs-review-stars-pick" id="vs-star-picker">
                <span class="vs-star-pick" data-v="1">★</span>
                <span class="vs-star-pick" data-v="2">★</span>
                <span class="vs-star-pick" data-v="3">★</span>
                <span class="vs-star-pick" data-v="4">★</span>
                <span class="vs-star-pick" data-v="5">★</span>
            </div>
            <input type="hidden" id="vs-review-rating" value="0">
            <div class="vs-review-star-hint" id="vs-star-hint">Click a star to rate</div>
            <div class="vs-review-form-fields">
                <div class="vs-review-input-grid">
                    <div>
                        <label class="vs-review-field-label">Full Name <span style="color:#DC2626">*</span></label>
                        <input class="vs-input" id="vs-rv-name" type="text" placeholder="Your full name" autocomplete="name">
                    </div>
                    <div>
                        <label class="vs-review-field-label">Mobile Number <span style="color:#DC2626">*</span></label>
                        <input class="vs-input" id="vs-rv-phone" type="tel" placeholder="+91 98765 43210" autocomplete="tel">
                    </div>
                </div>
                <div>
                    <label class="vs-review-field-label">Email Address <span style="color:#DC2626">*</span></label>
                    <input class="vs-input" id="vs-rv-email" type="email" placeholder="you@email.com" autocomplete="email">
                </div>
                <!-- Part 12.4 — Sub-ratings -->
                <div style="background:#F8FAFC;border-radius:9px;padding:14px;margin-top:4px">
                  <div style="font-size:.74rem;font-weight:700;color:#475569;margin-bottom:10px;text-transform:uppercase;letter-spacing:.06em">Rate the experience</div>
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
                    <?php foreach(['punctuality_rating'=>'⏰ Punctuality','quality_rating'=>'⭐ Quality','cleanliness_rating'=>'🧹 Cleanliness','price_rating'=>'💰 Value'] as $fid=>$flbl): ?>
                    <div>
                      <div style="font-size:.72rem;color:#64748B;margin-bottom:4px"><?php echo $flbl; ?></div>
                      <div style="display:flex;gap:4px">
                        <?php for($si=1;$si<=5;$si++): ?>
                        <span style="cursor:pointer;font-size:1.1rem;color:#E2E8F0" class="vs-sub-star" data-field="<?php echo $fid; ?>" data-val="<?php echo $si; ?>" onclick="vsSetSubRating('<?php echo $fid; ?>',<?php echo $si; ?>,this)">★</span>
                        <?php endfor; ?>
                      </div>
                      <input type="hidden" id="vs-rv-<?php echo $fid; ?>" value="0">
                    </div>
                    <?php endforeach; ?>
                  </div>
                </div>
                <div>
                    <label class="vs-review-field-label">Your Review <span style="color:#DC2626">*</span></label>
                    <textarea class="vs-input vs-textarea" id="vs-rv-msg" rows="4" placeholder="Describe your experience… (minimum 30 characters)"></textarea>
                    <div id="vs-rv-char" style="font-size:.7rem;color:#647388;margin-top:3px;text-align:right">0/500</div>
                </div>
                <div>
                  <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:.84rem">
                    <input type="checkbox" id="vs-rv-recommend" style="width:16px;height:16px;accent-color:#059669"> Would you recommend this vendor?
                  </label>
                </div>
            </div>
            <button class="vs-review-submit-btn" id="vs-rv-submit" onclick="vsSubmitReview()">Submit Review →</button>
            <div id="vs-rv-msg-status" style="margin-top:12px;font-size:.84rem;text-align:center;padding:10px;border-radius:8px;display:none"></div>
            <p style="text-align:center;font-size:.73rem;color:#647388;margin-top:14px">🔒 Reviews are moderated and published after verification.</p>
        </div>
    </div>
<?php });

// ── FAQ elements ─────────────────────────────────────────────────────────────
$_cur = 'faq';
$_el_capture('faq_title', $_cur, function() use ($hd) {
    if ( defined( 'GS_USE_MODULE_ENGINE_FAQ' ) && GS_USE_MODULE_ENGINE_FAQ ) {
        echo \GoodService\Modules\FaqModule::render_title( $hd );
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Got Questions?</div>
        <h2 class="vs-sec-title"><?php echo esc_html($hd['faq_section_title'] ?? 'Frequently Asked Questions'); ?></h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('faq_items', $_cur, function() use ($primary) {
    if ( defined( 'GS_USE_MODULE_ENGINE_FAQ' ) && GS_USE_MODULE_ENGINE_FAQ ) {
        echo \GoodService\Modules\FaqModule::render_items( $primary->faq_data ?? null );
        return;
    }
    if (empty($primary->faq_data)) return; ?>
    <div class="vs-faq-list">
        <?php foreach ($primary->faq_data as $i => $faq): if (empty($faq['question'])) continue; ?>
        <div class="vs-faq-item" onclick="this.classList.toggle('on')">
            <div class="vs-faq-q">
                <span><?php echo esc_html($faq['question']); ?></span>
                <span class="vs-faq-arrow">▾</span>
            </div>
            <div class="vs-faq-a"><?php echo wp_kses_post($faq['answer'] ?? ''); ?></div>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── CONTACT elements ──────────────────────────────────────────────────────────
$_cur = 'contact';
$_el_capture('contact_phone', $_cur, function() use ($phone, $_phone_masked, $primary, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_CONTACT') && GS_USE_MODULE_ENGINE_CONTACT ) ) {
        echo \GoodService\Modules\ContactModule::render_phone( $phone, $_phone_masked, $primary->id ?? 0 );
        return;
    }
    if (!$phone) return; ?>
    <div class="vs-cd-row"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 11.5a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.62 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 9.91a16 16 0 0 0 6.29 6.29l.91-.91a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg></div><div><div class="vs-cd-lbl">Phone</div>
<a href="#" id="vs-cd-phone-link" onclick="vsRevealPhone(this,'<?php echo esc_js($primary->id ?? 0); ?>');return false;" class="vs-cd-val">
  <?php echo esc_html($_phone_masked); ?> <span style="font-size:.72rem;color:#2563EB">(tap to reveal)</span>
</a></div></div>
<?php });
$_el_capture('contact_whatsapp', $_cur, function() use ($wa, $wa_clean, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_CONTACT') && GS_USE_MODULE_ENGINE_CONTACT ) ) {
        echo \GoodService\Modules\ContactModule::render_whatsapp( $wa, $wa_clean );
        return;
    }
    if (!$wa_clean) return; ?>
    <div class="vs-cd-row"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div><div><div class="vs-cd-lbl">WhatsApp</div><a href="https://wa.me/<?php echo esc_attr($wa_clean); ?>" target="_blank" class="vs-cd-val"><?php echo esc_html($wa); ?></a></div></div>
<?php });
$_el_capture('contact_email', $_cur, function() use ($email, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_CONTACT') && GS_USE_MODULE_ENGINE_CONTACT ) ) {
        echo \GoodService\Modules\ContactModule::render_email( $email );
        return;
    }
    if (!$email) return; ?>
    <div class="vs-cd-row"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div><div><div class="vs-cd-lbl">Email</div><a href="mailto:<?php echo esc_attr($email); ?>" class="vs-cd-val"><?php echo esc_html($email); ?></a></div></div>
<?php });
$_el_capture('contact_website', $_cur, function() use ($_website, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_CONTACT') && GS_USE_MODULE_ENGINE_CONTACT ) ) {
        echo \GoodService\Modules\ContactModule::render_website( $_website );
        return;
    }
    if (!$_website) return; ?>
    <div class="vs-cd-row"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></div><div><div class="vs-cd-lbl">Website</div><a href="<?php echo esc_url($_website); ?>" target="_blank" class="vs-cd-val"><?php echo esc_html(preg_replace('#^https?://#','',$_website)); ?></a></div></div>
<?php });
$_el_capture('contact_address', $_cur, function() use ($address, $city, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_CONTACT') && GS_USE_MODULE_ENGINE_CONTACT ) ) {
        echo \GoodService\Modules\ContactModule::render_address( $address, $city );
        return;
    }
    if (!$address && !$city) return; ?>
    <div class="vs-cd-row vs-cd-row-top"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div><div><div class="vs-cd-lbl">Address</div><div class="vs-cd-val"><?php echo nl2br(esc_html($address ?: $city)); ?></div></div></div>
<?php });
$_el_capture('contact_certs', $_cur, function() use ($_certs, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_CONTACT') && GS_USE_MODULE_ENGINE_CONTACT ) ) {
        echo \GoodService\Modules\ContactModule::render_certs( $_certs );
        return;
    }
    if (!$_certs) return; ?>
    <div class="vs-cd-row"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg></div><div><div class="vs-cd-lbl">Certifications</div><div class="vs-cd-val"><?php echo esc_html($_certs); ?></div></div></div>
<?php });
$_el_capture('contact_awards', $_cur, function() use ($_awards, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_CONTACT') && GS_USE_MODULE_ENGINE_CONTACT ) ) {
        echo \GoodService\Modules\ContactModule::render_awards( $_awards );
        return;
    }
    if (!$_awards) return; ?>
    <div class="vs-cd-row"><div class="vs-cd-ico"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg></div><div><div class="vs-cd-lbl">Awards</div><div class="vs-cd-val"><?php echo esc_html($_awards); ?></div></div></div>
<?php });
$_el_capture('contact_hours', $_cur, function() use ($primary, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_CONTACT') && GS_USE_MODULE_ENGINE_CONTACT ) ) {
        echo \GoodService\Modules\ContactModule::render_hours( $primary->opening_hours ?? null );
        return;
    }
    $oh = is_array($primary->opening_hours??null) ? $primary->opening_hours : (json_decode($primary->opening_hours??'[]', true)?:[]);
    if (empty($oh)) return;
    // Keys must match what both editors store: full lowercase day names (monday, tuesday…)
    // create-listing.php stores: {"monday":{"open":"09:00","close":"18:00","closed":false}}
    // vendor-dashboard.php stores: {"monday":"09:00 - 18:00"}
    // date('D') returns 3-letter abbreviation → use date('l') lowercased for full name
    $days = ['monday'=>'Monday','tuesday'=>'Tuesday','wednesday'=>'Wednesday','thursday'=>'Thursday','friday'=>'Friday','saturday'=>'Saturday','sunday'=>'Sunday'];
    $today_key = strtolower(date('l')); // "monday", "tuesday", etc.
    // Determine open status for today
    $today = $oh[$today_key] ?? null;
    $is_open_today = false; $status_str = '';
    if ($today) {
        if (is_array($today)) {
            if (!empty($today['closed'])) { $status_str = 'Closed Today'; }
            elseif (!empty($today['open']) && !empty($today['close'])) {
                $now = date('H:i');
                $is_open_today = $now >= $today['open'] && $now <= $today['close'];
                $fmt = fn($t) => date('g:i A', strtotime($t));
                $status_str = $is_open_today
                    ? 'Open Now · Closes ' . $fmt($today['close'])
                    : 'Closed · Opens ' . $fmt($today['open']);
            }
        } else {
            $status_str = $today;
        }
    }
    ?>
    <div class="vs-contact-hours">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
            <div style="font-weight:700;font-size:.85rem;color:#334155">🕐 Opening Hours</div>
            <?php if ($status_str): ?>
            <span style="font-size:.75rem;font-weight:700;padding:3px 10px;border-radius:20px;background:<?php echo $is_open_today?'#DCFCE7':'#FEF2F2'; ?>;color:<?php echo $is_open_today?'#166534':'#DC2626'; ?>"><?php echo esc_html($status_str); ?></span>
            <?php endif; ?>
        </div>
        <?php foreach ($days as $k => $label):
            $d = $oh[$k] ?? null; if(!$d) continue;
            $is_today = ($k === $today_key);
            if (is_array($d)) {
                if (!empty($d['closed'])) $display = 'Closed';
                else $display = (!empty($d['open'])&&!empty($d['close']))
                    ? date('g:i A',strtotime($d['open'])) . ' – ' . date('g:i A',strtotime($d['close']))
                    : '—';
            } else { $display = $d; }
        ?>
        <div style="display:flex;justify-content:space-between;font-size:.82rem;padding:5px 0;border-bottom:1px solid #F8FAFC;<?php echo $is_today?'font-weight:700':''; ?>">
            <span style="color:<?php echo $is_today?'var(--vs-primary)':'#64748B'; ?>"><?php echo $is_today?'→ ':'' ?><?php echo $label; ?></span>
            <span style="font-weight:<?php echo $is_today?'800':'600'; ?>"><?php echo esc_html($display); ?></span>
        </div>
        <?php endforeach; ?>
    </div>
<?php });
$_el_capture('contact_map', $_cur, function() use ($primary, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_CONTACT') && GS_USE_MODULE_ENGINE_CONTACT ) ) {
        echo \GoodService\Modules\ContactModule::render_map( $primary->map_embed ?? '' );
        return;
    }
    $map = $primary->map_embed ?? '';
    if (!$map) return; ?>
    <div class="vs-map-wrap"><div style="border-radius:14px;overflow:hidden"><?php echo wp_kses($map, ['iframe'=>['src'=>true,'width'=>true,'height'=>true,'frameborder'=>true,'allowfullscreen'=>true,'loading'=>true,'referrerpolicy'=>true,'style'=>true]]); ?></div></div>
<?php });
$_el_capture('contact_cities', $_cur, function() use ($primary, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_CONTACT') && GS_USE_MODULE_ENGINE_CONTACT ) ) {
        echo \GoodService\Modules\ContactModule::render_cities( $primary->service_cities ?? null );
        return;
    }
    $cities = is_array($primary->service_cities??null) ? $primary->service_cities : (json_decode($primary->service_cities??'[]',true)?:[]);
    if (empty($cities)) return; ?>
    <div style="margin-top:20px"><div style="font-size:.75rem;font-weight:700;color:#647388;text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px">🗺 Service Areas</div><div style="display:flex;flex-wrap:wrap;gap:6px"><?php foreach ($cities as $sc): if(!$sc)continue; ?><span style="background:#EFF6FF;color:#2563EB;border-radius:20px;padding:4px 12px;font-size:.78rem;font-weight:600"><?php echo esc_html($sc); ?></span><?php endforeach; ?></div></div>
<?php });
$_el_capture('contact_tags', $_cur, function() use ($primary) {
    if (!$primary || !$primary->tags) return;
    $tags = array_filter(array_map('trim', explode(',', $primary->tags)));
    if (empty($tags)) return; ?>
    <div style="margin-top:12px;display:flex;flex-wrap:wrap;gap:6px"><?php foreach ($tags as $t): ?><span style="background:#F1F5F9;color:#64748B;border-radius:20px;padding:3px 11px;font-size:.75rem;font-weight:600"><?php echo esc_html($t); ?></span><?php endforeach; ?></div>
<?php });
// contact_inquiry is rendered in the right column of the contact section (see vs-contact-form-panel below)

// ═══════════════════════════════════════════════════════════════════════════
// ── PREMIUM SECTION ELEMENT CAPTURES ──────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════

// ── TEAM elements ──────────────────────────────────────────────────────────
$_cur = 'team';
// Real performance fix: this query previously ran unconditionally on
// every page load, even when the Team section is hidden (visibility
// toggle off, or category-gated and not assigned). Confirmed safe to
// gate — $_team_data is used exclusively within Team's own rendering,
// nowhere else on the page depends on it. $_sec_show() is already
// defined above this point in the file, so this can check it directly.
$_team_data = $_sec_show('team') ? $_fetch_premium_section('team_data') : [];
$_el_capture('team_title', $_cur, function() {
    if ( defined( 'GS_USE_MODULE_ENGINE_TEAM' ) && GS_USE_MODULE_ENGINE_TEAM ) {
        echo \GoodService\Modules\TeamModule::render_title();
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">The People Behind The Work</div>
        <h2 class="vs-sec-title">Meet Our Team</h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('team_grid', $_cur, function() use ($_team_data, $cd) {
    $_team_img_fit = (string) ( $cd['team_img_fit'] ?? 'cover' );
    if ( defined( 'GS_USE_MODULE_ENGINE_TEAM' ) && GS_USE_MODULE_ENGINE_TEAM ) {
        echo \GoodService\Modules\TeamModule::render_grid( $_team_data ?: [], $_team_img_fit );
        return;
    }
    if ( empty( $_team_data ) ) return;
    $_team_img_style = \gs_vs_img_display_style( [ 'fit' => $_team_img_fit ] )['img']; ?>
    <div class="vs-team-grid">
        <?php foreach ( $_team_data as $tm ):
            if ( empty( $tm['name'] ) ) continue;
            $initials = strtoupper( implode( '', array_map( fn($w) => $w[0], array_slice( explode( ' ', trim( $tm['name'] ) ), 0, 2 ) ) ) );
        ?>
        <div class="vs-team-card">
            <?php if ( ! empty( $tm['photo'] ) ): ?>
                <img src="<?php echo esc_url( $tm['photo'] ); ?>" alt="<?php echo esc_attr( $tm['name'] ); ?>" class="vs-team-photo" loading="lazy" width="400" height="400" style="<?php echo esc_attr( $_team_img_style ); ?>">
            <?php else: ?>
                <div class="vs-team-photo-placeholder"><?php echo esc_html( $initials ); ?></div>
            <?php endif; ?>
            <div class="vs-team-body">
                <div class="vs-team-name"><?php echo esc_html( $tm['name'] ); ?></div>
                <?php if ( ! empty( $tm['role'] ) ): ?>
                    <div class="vs-team-role"><?php echo esc_html( $tm['role'] ); ?></div>
                <?php endif; ?>
                <?php if ( ! empty( $tm['bio'] ) ): ?>
                    <div class="vs-team-bio"><?php echo esc_html( $tm['bio'] ); ?></div>
                <?php endif; ?>
                <?php
                $socials = [
                    'linkedin'  => [ $tm['linkedin']  ?? '', 'in',  'LinkedIn'  ],
                    'twitter'   => [ $tm['twitter']   ?? '', 'X',   'X/Twitter' ],
                    'instagram' => [ $tm['instagram'] ?? '', '📷',  'Instagram' ],
                    'email'     => [ $tm['email']     ?? '', '✉',   'Email'     ],
                ];
                $has_social = array_filter( array_column( $socials, 0 ) );
                if ( $has_social ): ?>
                <div class="vs-team-socials">
                    <?php foreach ( $socials as [$url, $icon, $label] ):
                        if ( ! $url ) continue;
                        $href = ( $label === 'Email' ) ? 'mailto:' . $url : $url;
                    ?>
                    <a href="<?php echo esc_url( $href ); ?>" class="vs-team-social-link" target="<?php echo $label==='Email'?'_self':'_blank'; ?>" rel="noopener" title="<?php echo esc_attr( $label ); ?>"><?php echo $icon; ?></a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── CLIENTS / TRUSTED BY elements ──────────────────────────────────────────
$_cur = 'clients';
// Real performance fix: same reasoning as $_team_data above — query
// skipped entirely when Clients is hidden, confirmed safe since
// $_clients_data has no use anywhere else on the page.
$_clients_data = $_sec_show('clients') ? $_fetch_premium_section('clients_data') : [];
$_el_capture('clients_title', $_cur, function() {
    if ( defined( 'GS_USE_MODULE_ENGINE_CLIENTS' ) && GS_USE_MODULE_ENGINE_CLIENTS ) {
        echo \GoodService\Modules\ClientsModule::render_title();
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Our Clients</div>
        <h2 class="vs-sec-title">Trusted by Leading Brands</h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('clients_logos', $_cur, function() use ($_clients_data, $cv_client_logo_height, $cd) {
    $_clients_img_fit = (string) ( $cd['clients_img_fit'] ?? 'contain' );
    if ( defined( 'GS_USE_MODULE_ENGINE_CLIENTS' ) && GS_USE_MODULE_ENGINE_CLIENTS ) {
        echo \GoodService\Modules\ClientsModule::render_logos( $_clients_data ?: [], (int) $cv_client_logo_height, $_clients_img_fit );
        return;
    }
    if ( empty( $_clients_data ) ) return;
    $_clients_img_style = \gs_vs_img_display_style( [ 'fit' => $_clients_img_fit ] )['img']; ?>
    <div class="vs-clients-grid">
        <?php foreach ( $_clients_data as $cl ):
            if ( empty( $cl['name'] ) && empty( $cl['logo'] ) ) continue;
            // Real fix, PageSpeed audit: height is fixed platform-wide via
            // CSS, but each logo's natural width varies — computes the
            // real width at that fixed height from the actual image's
            // aspect ratio, same cached getimagesize() pattern already
            // proven correct for the hero/about images.
            $_cl_dim_w = 0;
            if ( ! empty( $cl['logo'] ) ) {
                $_cl_dim_cache_key = 'gs_cllogo_dim_' . md5( $cl['logo'] );
                $_cl_dim = get_transient( $_cl_dim_cache_key );
                if ( $_cl_dim === false ) {
                    $_cl_dim = @getimagesize( $cl['logo'] ) ?: [ 0, 0 ];
                    set_transient( $_cl_dim_cache_key, $_cl_dim, 30 * DAY_IN_SECONDS );
                }
                if ( ! empty( $_cl_dim[0] ) && ! empty( $_cl_dim[1] ) ) {
                    $_cl_dim_w = (int) round( ( $_cl_dim[0] / $_cl_dim[1] ) * $cv_client_logo_height );
                }
            }
        ?>
        <?php if ( ! empty( $cl['logo'] ) ): ?>
            <?php $wrap_tag = ! empty( $cl['url'] ) ? 'a' : 'span'; ?>
            <<?php echo $wrap_tag; ?><?php if($wrap_tag==='a'): ?> href="<?php echo esc_url($cl['url']); ?>" target="_blank" rel="noopener nofollow"<?php endif; ?>>
                <img src="<?php echo esc_url( $cl['logo'] ); ?>"
                     alt="<?php echo esc_attr( $cl['name'] ?? '' ); ?>"
                     class="vs-client-logo" loading="lazy"
                     height="<?php echo (int) $cv_client_logo_height; ?>"<?php if($_cl_dim_w>0): ?> width="<?php echo (int) $_cl_dim_w; ?>"<?php endif; ?>
                     style="<?php echo esc_attr( $_clients_img_style ); ?>"
                     title="<?php echo esc_attr( $cl['name'] ?? '' ); ?>">
            </<?php echo $wrap_tag; ?>>
        <?php elseif ( ! empty( $cl['name'] ) ): ?>
            <span class="vs-clients-text-item"><?php echo esc_html( $cl['name'] ); ?></span>
        <?php endif; ?>
        <?php endforeach; ?>
    </div>
<?php });

// ── PRICING TABLE elements ──────────────────────────────────────────────────
$_cur = 'pricing';
// Real performance fix: same reasoning as $_team_data above — query
// skipped entirely when Pricing is hidden, confirmed safe since
// $_pricing_data has no use anywhere else on the page.
$_pricing_data = $_sec_show('pricing') ? $_fetch_premium_section('pricing_data') : [];
$_el_capture('pricing_title', $_cur, function() use ($_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_PRICING') && GS_USE_MODULE_ENGINE_PRICING ) ) {
        echo \GoodService\Modules\PricingModule::render_title();
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:40px">
        <div class="vs-sec-eyebrow">Transparent Pricing</div>
        <h2 class="vs-sec-title vs-pricing-title">Choose the Right Plan</h2>
        <p class="vs-sec-sub" style="margin:8px auto 0">No hidden charges. Cancel anytime.</p>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('pricing_grid', $_cur, function() use ($_pricing_data, $lid, $_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_PRICING') && GS_USE_MODULE_ENGINE_PRICING ) ) {
        echo \GoodService\Modules\PricingModule::render_grid( $_pricing_data );
        return;
    }
    if ( empty( $_pricing_data ) ) return;
    $currency = gs_setting( 'currency_symbol', '₹' ); ?>
    <div class="vs-pricing-grid">
        <?php foreach ( $_pricing_data as $plan ):
            if ( empty( $plan['name'] ) ) continue;
            $featured     = ! empty( $plan['featured'] );
            $badge_text   = $plan['badge']    ?? ( $featured ? 'Most Popular' : '' );
            $features     = is_array( $plan['features'] ?? null ) ? $plan['features'] : array_filter( array_map( 'trim', explode( "\n", $plan['features'] ?? '' ) ) );
            $cta_text     = $plan['cta_text'] ?? 'Get Started';
            $cta_link     = $plan['cta_link'] ?? '#vs-sec-contact';
        ?>
        <div class="vs-pricing-card<?php echo $featured ? ' featured' : ''; ?>">
            <?php if ( $badge_text ): ?>
                <div class="vs-pricing-badge"><?php echo esc_html( $badge_text ); ?></div>
            <?php endif; ?>
            <div class="vs-pricing-name"><?php echo esc_html( $plan['name'] ); ?></div>
            <div class="vs-pricing-price">
                <?php if ( ! empty( $plan['price'] ) ): ?>
                    <?php echo esc_html( $currency . $plan['price'] ); ?><span><?php echo ! empty( $plan['period'] ) ? '/' . esc_html( $plan['period'] ) : ''; ?></span>
                <?php else: ?>
                    <span style="font-size:.95rem;font-weight:700;color:#647388">Custom</span>
                <?php endif; ?>
            </div>
            <?php if ( ! empty( $plan['description'] ) ): ?>
                <div class="vs-pricing-desc"><?php echo esc_html( $plan['description'] ); ?></div>
            <?php endif; ?>
            <?php if ( ! empty( $features ) ): ?>
            <ul class="vs-pricing-features" style="list-style:none">
                <?php foreach ( $features as $feat ):
                    $included = ! ( str_starts_with( $feat, '-' ) || str_starts_with( $feat, '✕' ) );
                    $feat_txt = ltrim( $feat, '-✕+✓ ' );
                    if ( ! $feat_txt ) continue;
                ?>
                <li class="vs-pricing-feat<?php echo $included ? '' : ' no-feat'; ?>">
                    <span class="vs-pricing-feat-ico <?php echo $included ? 'yes' : 'no'; ?>"><?php echo $included ? '✓' : '–'; ?></span>
                    <?php echo esc_html( $feat_txt ); ?>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
            <a href="<?php echo esc_url( $cta_link ); ?>" class="vs-pricing-cta"
               onclick="if(this.getAttribute('href')==='#vs-inq-open'){event.preventDefault();vsOpenInquiry({name:'<?php echo esc_js($plan['name']); ?> Plan',type:'service'});}">
                <?php echo esc_html( $cta_text ); ?>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── PORTFOLIO / CASE STUDIES elements ──────────────────────────────────────
$_cur = 'portfolio';
// Real performance fix: same reasoning as $_team_data above — query
// skipped entirely when Portfolio is hidden, confirmed safe since
// $_portfolio_data has no use anywhere else on the page.
$_portfolio_data = $_sec_show('portfolio') ? $_fetch_premium_section('portfolio_data') : [];
$_el_capture('portfolio_title', $_cur, function() use ($_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_PORTFOLIO') && GS_USE_MODULE_ENGINE_PORTFOLIO ) ) {
        echo \GoodService\Modules\PortfolioModule::render_title();
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Our Work</div>
        <h2 class="vs-sec-title">Projects & Case Studies</h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('portfolio_grid', $_cur, function() use ($_portfolio_data, $_gs_all_modules_on, $cd) {
    $_portfolio_img_fit = (string) ( $cd['portfolio_img_fit'] ?? 'cover' );
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_PORTFOLIO') && GS_USE_MODULE_ENGINE_PORTFOLIO ) ) {
        echo \GoodService\Modules\PortfolioModule::render_grid( $_portfolio_data, $_portfolio_img_fit );
        return;
    }
    if ( empty( $_portfolio_data ) ) return;
    $_portfolio_img_style = \gs_vs_img_display_style( [ 'fit' => $_portfolio_img_fit ] )['img']; ?>
    <div class="vs-portfolio-grid">
        <?php foreach ( $_portfolio_data as $proj ):
            if ( empty( $proj['title'] ) ) continue;
            $results = is_array( $proj['results'] ?? null )
                ? $proj['results']
                : array_filter( array_map( 'trim', explode( "\n", $proj['results'] ?? '' ) ) );
            // Real fix, PageSpeed audit: fixed CSS height (200px), but
            // width scales to fill the card — computes the real width at
            // that fixed height from the actual image's aspect ratio,
            // same cached getimagesize() pattern used elsewhere.
        ?>
        <div class="vs-portfolio-card">
            <?php if ( ! empty( $proj['image'] ) ): ?>
                <img src="<?php echo esc_url( $proj['image'] ); ?>" alt="<?php echo esc_attr( $proj['title'] ); ?>" class="vs-portfolio-img" loading="lazy" width="400" height="200" style="<?php echo esc_attr( $_portfolio_img_style ); ?>">
            <?php else: ?>
                <div class="vs-portfolio-img-placeholder">📁</div>
            <?php endif; ?>
            <div class="vs-portfolio-body">
                <?php if ( ! empty( $proj['category'] ) ): ?>
                    <div class="vs-portfolio-cat"><?php echo esc_html( $proj['category'] ); ?></div>
                <?php endif; ?>
                <div class="vs-portfolio-title"><?php echo esc_html( $proj['title'] ); ?></div>
                <?php if ( ! empty( $proj['description'] ) ): ?>
                    <div class="vs-portfolio-desc"><?php echo esc_html( $proj['description'] ); ?></div>
                <?php endif; ?>
                <?php if ( ! empty( $results ) ): ?>
                    <div class="vs-portfolio-stats">
                        <?php foreach ( array_slice( (array)$results, 0, 3 ) as $r ):
                            if ( ! trim( $r ) ) continue;
                        ?>
                        <span class="vs-portfolio-stat">✅ <?php echo esc_html( trim( $r ) ); ?></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <?php if ( ! empty( $proj['link'] ) ): ?>
                    <a href="<?php echo esc_url( $proj['link'] ); ?>" target="_blank" rel="noopener" class="vs-portfolio-link">View Case Study →</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php });

// ── TESTIMONIALS elements ───────────────────────────────────────────────────
$_cur = 'testimonials';
// Real performance fix: same reasoning as $_team_data above — query
// skipped entirely when Testimonials is hidden, confirmed safe since
// $_testi_data has no use anywhere else on the page.
$_testi_data = $_sec_show('testimonials') ? $_fetch_premium_section('testimonials_data') : [];
$_el_capture('testimonials_title', $_cur, function() use ($_gs_all_modules_on) {
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_TESTIMONIALS') && GS_USE_MODULE_ENGINE_TESTIMONIALS ) ) {
        echo \GoodService\Modules\TestimonialsModule::render_title();
        return;
    }
    ?>
    <div class="vs-text-center" style="margin-bottom:36px">
        <div class="vs-sec-eyebrow">Social Proof</div>
        <h2 class="vs-sec-title">What Our Clients Say</h2>
        <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
<?php });
$_el_capture('testimonials_grid', $_cur, function() use ($_testi_data, $_gs_all_modules_on, $cd) {
    $_testi_img_fit = (string) ( $cd['testimonials_img_fit'] ?? 'cover' );
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_TESTIMONIALS') && GS_USE_MODULE_ENGINE_TESTIMONIALS ) ) {
        echo \GoodService\Modules\TestimonialsModule::render_grid( $_testi_data, $_testi_img_fit );
        return;
    }
    if ( empty( $_testi_data ) ) return;
    $_testi_img_style = \gs_vs_img_display_style( [ 'fit' => $_testi_img_fit ] )['img'];
    $star_hints = [ 1=>'Poor', 2=>'Fair', 3=>'Good', 4=>'Very Good', 5=>'Excellent' ]; ?>
    <div class="vs-testi-grid">
        <?php foreach ( $_testi_data as $t ):
            if ( empty( $t['name'] ) && empty( $t['text'] ) && empty( $t['video_url'] ) ) continue;
            $rating    = max( 0, min( 5, (int)( $t['rating'] ?? 5 ) ) );
            $initials  = strtoupper( substr( trim( $t['name'] ?? 'C' ), 0, 1 ) );
            $is_video  = ! empty( $t['video_url'] );
            $video_embed = '';
            if ( $is_video ) {
                if ( preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([A-Za-z0-9_-]+)/', $t['video_url'], $vm ) ) {
                    $video_embed = 'https://www.youtube.com/embed/' . $vm[1] . '?autoplay=1&rel=0';
                } elseif ( preg_match('/vimeo\.com\/(\d+)/', $t['video_url'], $vm ) ) {
                    $video_embed = 'https://player.vimeo.com/video/' . $vm[1] . '?autoplay=1';
                }
            }
        ?>
        <div class="vs-testi-card">
            <div class="vs-testi-quote">"</div>

            <?php if ( $is_video ): ?>
            <?php if ( $video_embed ): ?>
            <!-- Video testimonial with play-in-place -->
            <div class="vs-testi-video-wrap"
                 onclick="this.innerHTML='<iframe src=\'<?php echo esc_js($video_embed); ?>\' width=\'100%\' height=\'160\' frameborder=\'0\' allow=\'autoplay;encrypted-media\' allowfullscreen style=\'display:block;border-radius:10px\'></iframe>'"
                 title="Play testimonial video">
                <?php if ( ! empty( $t['video_thumb'] ) ): ?>
                    <img src="<?php echo esc_url( $t['video_thumb'] ); ?>" alt="Video testimonial" class="vs-testi-video-thumb" loading="lazy" width="400" height="160">
                <?php else: ?>
                    <div class="vs-testi-video-thumb" style="background:#1E293B;display:flex;align-items:center;justify-content:center;font-size:2rem">🎥</div>
                <?php endif; ?>
                <div class="vs-testi-video-play">
                    <div class="vs-testi-video-play-btn">▶</div>
                </div>
            </div>
            <?php else: ?>
            <a href="<?php echo esc_url( $t['video_url'] ); ?>" target="_blank" rel="noopener" class="vs-btn vs-btn-ghost" style="margin-bottom:12px;font-size:.8rem">▶ Watch Testimonial</a>
            <?php endif; ?>
            <?php endif; ?>

            <?php if ( $rating > 0 ): ?>
            <div class="vs-testi-stars"><?php echo str_repeat( '★', $rating ) . str_repeat( '☆', 5 - $rating ); ?></div>
            <?php endif; ?>

            <?php if ( ! empty( $t['text'] ) ): ?>
            <p class="vs-testi-text"><?php echo nl2br( esc_html( $t['text'] ) ); ?></p>
            <?php endif; ?>

            <div class="vs-testi-footer">
                <?php if ( ! empty( $t['photo'] ) ): ?>
                    <?php /* Real audit finding, item 4: deliberately left as alt="" — the customer's
                             name is already shown as visible text right below this avatar (see $t['name']
                             a few lines down), so an empty alt is the WCAG-correct choice here, avoiding a
                             redundant screen-reader announcement, unlike the genuine gaps fixed elsewhere
                             in this file where no equivalent visible text existed nearby. */ ?>
                    <img src="<?php echo esc_url( $t['photo'] ); ?>" alt="" class="vs-testi-avatar" loading="lazy" width="42" height="42" style="<?php echo esc_attr( $_testi_img_style ); ?>">
                <?php else: ?>
                    <div class="vs-testi-avatar"><?php echo esc_html( $initials ); ?></div>
                <?php endif; ?>
                <div>
                    <div class="vs-testi-name"><?php echo esc_html( $t['name'] ?? '' ); ?></div>
                    <?php if ( ! empty( $t['company'] ) || ! empty( $t['role'] ) ): ?>
                        <div class="vs-testi-company"><?php echo esc_html( implode( ', ', array_filter( [ $t['role'] ?? '', $t['company'] ?? '' ] ) ) ); ?></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php });


// ── Sections rendered in user-configured order with visibility control ─────
$_vs_sections = [];
ob_start(); ?>
<!-- ══ ABOUT ══════════════════════════════════════════════════════ -->
<?php if ($_sec_show('about') && isset($nav['about'])): ?>
<section class="vs-section" id="vs-sec-about">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('about'); ?>>
    <div class="vs-about-grid">
      <div>
        <?php echo $_sec_el_render('about'); ?>
      </div>
      <div class="vs-about-right">
        <?php echo $_sec_el_render('about_right'); ?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>
<?php $_vs_sections['about'] = ob_get_clean(); ob_start(); ?>
<!-- ══ SERVICES ════════════════════════════════════════════════════ -->
<?php if ($_sec_show('services') && isset($nav['services']) && $primary && !empty($primary->services_data)): ?>
<section class="vs-section vs-section-alt" id="vs-sec-services">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('services'); ?>><?php echo $_sec_el_render('services'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['services'] = ob_get_clean(); ob_start(); ?>
<!-- ══ PROCESS ══════════════════════════════════════════════════════ -->
<?php if ($_sec_show('process') && isset($nav['process']) && $primary && !empty($primary->process_data)): ?>
<section class="vs-section vs-process-section" id="vs-sec-process">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('process'); ?>><?php echo $_sec_el_render('process'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['process'] = ob_get_clean(); ob_start(); ?>
<!-- ══ ITEMS ════════════════════════════════════════════════════════ -->
<?php if ($_sec_show('items') && !empty($all_items)): ?>
<section class="vs-section" id="vs-sec-items">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('items'); ?>><?php echo $_sec_el_render('items'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['items'] = ob_get_clean(); ob_start(); ?>
<!-- ══ STATS ════════════════════════════════════════════════════════ -->
<?php if ($_sec_show('stats') && isset($nav['stats']) && $primary && !empty($primary->stats_data)): ?>
<section class="vs-section vs-stats-section" id="vs-sec-stats">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('stats'); ?>><?php echo $_sec_el_render('stats'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['stats'] = ob_get_clean(); ob_start(); ?>
<!-- ══ GALLERY ══════════════════════════════════════════════════════ -->
<?php if ($_sec_show('gallery') && isset($nav['gallery']) && $primary && !empty($primary->gallery)): ?>
<section class="vs-section vs-section-alt" id="vs-sec-gallery" style="<?php echo $cv_gallery_bg ? 'background:'.esc_attr($cv_gallery_bg).';' : ''; ?>">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('gallery'); ?>><?php echo $_sec_el_render('gallery'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['gallery'] = ob_get_clean(); ob_start(); ?>
<!-- ══ WHY CHOOSE US ════════════════════════════════════════════════ -->
<?php if ($_sec_show('why') && isset($nav['why']) && $primary && !empty($primary->why_choose_data)): ?>
<section class="vs-section" id="vs-sec-why">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('why'); ?>><?php echo $_sec_el_render('why'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['why'] = ob_get_clean(); ob_start(); ?>
<!-- ══ KEY HIGHLIGHTS ══════════════════════════════════════════════ -->
<?php if ($_sec_show('highlights') && $primary && $_json_has_real_content($primary->highlights_data ?? null, 'title')): ?>
<section class="vs-section" id="vs-sec-highlights">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('highlights'); ?>><?php echo $_sec_el_render('highlights'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['highlights'] = ob_get_clean(); ob_start(); ?>
<!-- ══ FEATURES & AMENITIES ══════════════════════════════════════════ -->
<?php if ($_sec_show('amenities') && $primary && $_json_has_real_content($primary->amenities_data ?? null, 'title')): ?>
<section class="vs-section" id="vs-sec-amenities">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('amenities'); ?>><?php echo $_sec_el_render('amenities'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['amenities'] = ob_get_clean(); ob_start(); ?>
<!-- ══ FACILITIES ══════════════════════════════════════════════════ -->
<?php if ($_sec_show('facilities') && $primary && $_json_has_real_content($primary->facilities_data ?? null, 'title')): ?>
<section class="vs-section" id="vs-sec-facilities">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('facilities'); ?>><?php echo $_sec_el_render('facilities'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['facilities'] = ob_get_clean(); ob_start(); ?>
<!-- ══ AWARDS & RECOGNITION ════════════════════════════════════════ -->
<?php if ($_sec_show('awards') && $primary && $_json_has_real_content($primary->awards_data ?? null, 'title')): ?>
<section class="vs-section" id="vs-sec-awards">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('awards'); ?>><?php echo $_sec_el_render('awards'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['awards'] = ob_get_clean(); ob_start(); ?>
<!-- ══ LANGUAGES SPOKEN ════════════════════════════════════════════ -->
<?php if ($_sec_show('languages') && $primary && $_json_has_real_content($primary->languages_data ?? null, 'name')): ?>
<section class="vs-section" id="vs-sec-languages">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('languages'); ?>><?php echo $_sec_el_render('languages'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['languages'] = ob_get_clean(); ob_start(); ?>
<!-- ══ PACKAGES & PRICING ══════════════════════════════════════════ -->
<?php if ($_sec_show('packages') && $primary && $_json_has_real_content($primary->packages_data ?? null, 'name')): ?>
<section class="vs-section" id="vs-sec-packages">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('packages'); ?>><?php echo $_sec_el_render('packages'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['packages'] = ob_get_clean(); ob_start(); ?>
<!-- ══ MEMBERSHIP PLANS ════════════════════════════════════════════ -->
<?php if ($_sec_show('memberships') && $primary && $_json_has_real_content($primary->memberships_data ?? null, 'name')): ?>
<section class="vs-section" id="vs-sec-memberships">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('memberships'); ?>><?php echo $_sec_el_render('memberships'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['memberships'] = ob_get_clean(); ob_start(); ?>
<!-- ══ LICENCES & CERTIFICATIONS ═══════════════════════════════════ -->
<?php if ($_sec_show('certifications') && $primary && $_json_has_real_content($primary->certifications_data ?? null, 'title')): ?>
<section class="vs-section" id="vs-sec-certifications">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('certifications'); ?>><?php echo $_sec_el_render('certifications'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['certifications'] = ob_get_clean(); ob_start(); ?>
<!-- ══ WARRANTY / GUARANTEE ════════════════════════════════════════ -->
<?php if ($_sec_show('warranty') && $primary && $_json_has_real_content($primary->warranty_data ?? null, 'title')): ?>
<section class="vs-section" id="vs-sec-warranty">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('warranty'); ?>><?php echo $_sec_el_render('warranty'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['warranty'] = ob_get_clean(); ob_start(); ?>
<!-- ══ TERMS & CONDITIONS ══════════════════════════════════════════ -->
<?php if ($_sec_show('terms') && $primary && $_json_has_real_content($primary->terms_data ?? null, 'content')): ?>
<section class="vs-section" id="vs-sec-terms">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('terms'); ?>><?php echo $_sec_el_render('terms'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['terms'] = ob_get_clean(); ob_start(); ?>
<!-- ══ REVIEWS ══════════════════════════════════════════════════════ -->
<?php
// Real fix, correcting a regression from an earlier fix: $_sec_el_render
// ('reviews') already has its own correct "No Reviews Yet" empty state
// AND the review submission form built directly into it. Wrapping it in
// an outer !empty($reviews) check (as an earlier fix here mistakenly did)
// meant that entire render — including the submission form — never ran
// at all when there were no reviews yet. Always call it when the section
// is genuinely enabled; it already handles both cases correctly.
$_reviews_section_enabled = $_sec_show('reviews') && ( $primary->feedback_data['show_reviews'] ?? '1' ) !== '0';
?>
<?php if ($_reviews_section_enabled): ?>
<section class="vs-section vs-section-alt" id="vs-sec-reviews">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('reviews'); ?>><?php echo $_sec_el_render('reviews'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['reviews'] = ob_get_clean(); ob_start(); ?>
<!-- ══ FAQ ══════════════════════════════════════════════════════════ -->
<?php if ($_sec_show('faq') && isset($nav['faq']) && $primary && !empty($primary->faq_data)): ?>
<section class="vs-section" id="vs-sec-faq">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('faq'); ?>><?php echo $_sec_el_render('faq'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['faq'] = ob_get_clean(); ob_start(); ?>

<!-- ══ TEAM ════════════════════════════════════════════════════════ -->
<?php if ($_sec_show('team') && isset($nav['team']) && !empty($_team_data)): ?>
<section class="vs-section vs-section-alt" id="vs-sec-team">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('team'); ?>><?php echo $_sec_el_render('team'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['team'] = ob_get_clean(); ob_start(); ?>

<!-- ══ CLIENTS / TRUSTED BY ══════════════════════════════════════ -->
<?php if ($_sec_show('clients') && isset($nav['clients']) && !empty($_clients_data)): ?>
<section class="vs-section" id="vs-sec-clients">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('clients'); ?>><?php echo $_sec_el_render('clients'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['clients'] = ob_get_clean(); ob_start(); ?>

<!-- ══ PRICING ═════════════════════════════════════════════════════ -->
<?php if ($_sec_show('pricing') && isset($nav['pricing']) && !empty($_pricing_data)): ?>
<section class="vs-section vs-section-alt" id="vs-sec-pricing">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('pricing'); ?>><?php echo $_sec_el_render('pricing'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['pricing'] = ob_get_clean(); ob_start(); ?>

<!-- ══ PORTFOLIO / CASE STUDIES ══════════════════════════════════ -->
<?php if ($_sec_show('portfolio') && isset($nav['portfolio']) && !empty($_portfolio_data)): ?>
<section class="vs-section" id="vs-sec-portfolio">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('portfolio'); ?>><?php echo $_sec_el_render('portfolio'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['portfolio'] = ob_get_clean(); ob_start(); ?>

<!-- ══ TESTIMONIALS ════════════════════════════════════════════════ -->
<?php if ($_sec_show('testimonials') && isset($nav['testimonials']) && !empty($_testi_data)): ?>
<section class="vs-section vs-section-alt" id="vs-sec-testimonials">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('testimonials'); ?>><?php echo $_sec_el_render('testimonials'); ?></div>
</section>
<?php endif; ?>
<?php $_vs_sections['testimonials'] = ob_get_clean(); ob_start(); ?>
<!-- ══ CONTACT ══════════════════════════════════════════════════════ -->
<?php if ($_sec_show('contact') && isset($nav['contact'])): ?>
<section class="vs-section vs-section-contact-new" id="vs-sec-contact">
  <div class="vs-wrap" <?php echo $_sec_wrap_style('contact'); ?>>
    <div class="vs-text-center" style="margin-bottom:40px">
      <div class="vs-sec-eyebrow">Reach Out</div>
      <h2 class="vs-sec-title">Get in Touch</h2>
      <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
    <div class="vs-contact-new-grid">

      <!-- LEFT: Contact Details -->
      <div class="vs-contact-details-panel">
        <div style="background:#1E3A5F;padding:24px 24px 20px">
          <div style="font-size:1.05rem;font-weight:800;color:#fff;margin-bottom:4px">Contact Information</div>
          <div style="font-size:.82rem;color:rgba(255,255,255,.7)">Reach out through any of the channels below.</div>
        </div>
        <div class="vs-contact-details-list">
          <?php echo $_sec_el_render('contact'); ?>
        </div>
      </div>

      <!-- RIGHT: Inquiry form — Fluent Form removed; uses built-in inquiry system -->
      <div class="vs-contact-form-panel">
        <?php if ( ! empty( $_inq_modules_data ) ):
            // Use the first enabled inquiry module's form inline in the contact section
            // Uses unique IDs prefixed with 'cx_' to avoid conflicts with the inquiry_modules section
            reset($_inq_modules_data);
            $cx_slug   = key($_inq_modules_data);
            $cx_mod    = current($_inq_modules_data);
            // Real fix: was reading the single global universal array
            // unconditionally — now respects this category's own
            // enable/disable and label overrides, same as the main form.
            $cx_resolved = \GoodService\Service\InquiryFormService::resolve_fields_for_category($cx_slug);
            // Real fix — this caller was missing the per-vendor option-
            // visibility filter that inquiry-modules.php already has,
            // meaning a vendor's Service Type restrictions applied in the
            // main form but not here, a real inconsistency a customer
            // could notice (seeing a restricted list in one place and the
            // full list in another for the same vendor).
            $_cx_opt_vis = is_array( $cd['inquiry_option_visibility'] ?? null ) ? $cd['inquiry_option_visibility'] : [];
            if ( ! empty( $_cx_opt_vis[ $cx_slug ] ) && is_array( $_cx_opt_vis[ $cx_slug ] ) ) {
                foreach ( $cx_resolved as $_cx_grp_key => $_cx_grp_fields ) {
                    foreach ( $_cx_grp_fields as $_cx_fi => $_cx_fld ) {
                        $_cx_allowed = $_cx_opt_vis[ $cx_slug ][ $_cx_fld['key'] ] ?? null;
                        if ( is_array( $_cx_allowed ) && ! empty( $_cx_allowed ) && ! empty( $_cx_fld['options'] ) ) {
                            $cx_resolved[ $_cx_grp_key ][ $_cx_fi ]['options'] = array_values( array_intersect( $_cx_fld['options'], $_cx_allowed ) );
                        }
                    }
                }
            }
            $cx_fields = array_values(array_slice($cx_resolved['own_step_1'], 0, 4));
            // Real fix, confirmed root cause of missing Name/Phone fields:
            // was a hardcoded 'contact' key — but the main inquiry form
            // never assumes that literal string, it dynamically reads
            // whichever step-category key actually exists in the
            // database (see inquiry-modules.php's $_sc['step_key']
            // usage). If that category was ever renamed via the admin
            // UI, this hardcoded lookup would silently return nothing
            // while the main form kept working correctly. Uses the same
            // dynamic discovery here — the last configured step category
            // is the contact-details one by convention (scheduling
            // first, contact last).
            $_cx_step_cats = \GoodService\Service\InquiryFormService::get_step_categories();
            $_cx_contact_key = end( $_cx_step_cats )['step_key'] ?? 'contact';
            $cx_step3  = array_values($cx_resolved[ $_cx_contact_key ] ?? []); // contact fields, identified by role — not step number
            // Real fix — root cause of missing fields (stay_dates,
            // group_type, etc. silently vanished) and the unlabeled blue
            // dot after Email (contact_method rendered as a bare, empty
            // <input type="radio">, submitting the browser-default "on"):
            // this form used to hand-roll its own field renderer that
            // only understood text/email/phone/number/select/textarea and
            // dropped or mis-rendered everything else. render_iq_field()
            // already handles every field type correctly — including
            // radio/multi_select/toggle/date/date_range/file — and is the
            // exact same function the main Inquiry Modules panel uses, so
            // both forms now render identically and completely. Required
            // early here since inquiry-modules.php (which used to define
            // it inline) is only included further down the page.
            require_once GS_DIR . 'templates/pages/partials/inquiry-field-renderer.php';
        ?>
        <div class="vs-contact-form-card">
          <div class="vs-contact-form-hdr">
            <div class="vs-contact-form-hdr-title"><?php echo esc_html($cx_mod['icon']??'📋'); ?> <?php echo esc_html($cx_mod['name'] ?? 'Send an Inquiry'); ?></div>
            <div class="vs-contact-form-hdr-sub"><?php echo esc_html($cx_mod['intro'] ?? 'Fill in the form — we\'ll respond promptly.'); ?></div>
          </div>
          <div style="padding:24px 28px;display:flex;flex-direction:column;gap:10px">
            <!-- Service-specific fields (first 4) -->
            <?php foreach ($cx_fields as $cf):
                $cfk=$cf['key']??''; $cfl=$cf['label']??''; $cft=$cf['type']??'text';
                $cfreq=!empty($cf['required']); $cfo=array_values($cf['options']??[]);
                $cfph = $cf['ph']??$cfl; $cfhp = $cf['help']??'';
                $cfothers = !empty($cf['others']);
                $cfid = 'cx_'.$cx_slug.'_'.$cfk; $cfn = 'gs_f_'.$cfk;
                $cfcd = $cf['cond']??null; $ccattr='';
                if ( is_array($cfcd) && isset($cfcd['field'],$cfcd['value']) ) {
                    $ccattr = ' data-sif="gs_f_'.esc_attr($cfcd['field']).'" data-siv="'.esc_attr($cfcd['value']).'" data-sio="'.esc_attr($cfcd['op']??'equals').'"';
                }
            ?>
            <?php echo render_iq_field($cfid,$cfn,$cfl,$cft,$cfreq,$cfo,$cfph,$cfhp,$ccattr,$cfothers,$cf,$cx_slug); ?>
            <?php endforeach; ?>
            <!-- Universal contact fields (name, phone, email, contact method, file upload, notes) -->
            <?php foreach ($cx_step3 as $cf):
                $cfk=$cf['key']??''; $cfl=$cf['label']??ucfirst($cfk); $cft=$cf['type']??'text';
                $cfreq=!empty($cf['required']); $cfo=array_values($cf['options']??[]);
                $cfph=$cf['ph']??$cfl; $cfhp=$cf['help']??''; $cfothers=!empty($cf['others']);
                $cfid='cx_c_'.$cx_slug.'_'.$cfk; $cfn='gs_f_'.$cfk;
            ?>
            <?php echo render_iq_field($cfid,$cfn,$cfl,$cft,$cfreq,$cfo,$cfph,$cfhp,'',$cfothers,$cf,$cx_slug); ?>
            <?php endforeach; ?>
            <textarea class="vs-input vs-textarea" id="cx_msg_<?php echo esc_attr($cx_slug); ?>"
                      name="gs_f_message" placeholder="Describe your requirement…" rows="3" data-fk="message"></textarea>
            <input type="hidden" id="cx_lid_<?php echo esc_attr($cx_slug); ?>" value="<?php echo $lid; ?>">
            <button onclick="cxSubmit('<?php echo esc_js($cx_slug); ?>',<?php echo $lid; ?>)"
                    id="cx_btn_<?php echo esc_attr($cx_slug); ?>"
                    style="width:100%;background:var(--vs-dark,#1E3A5F);color:#fff;border:none;padding:13px 20px;border-radius:8px;font-size:.92rem;font-weight:700;cursor:pointer;transition:background .2s;letter-spacing:.02em;display:flex;align-items:center;justify-content:center;gap:8px">
              📩 Submit Enquiry
            </button>
            <div id="cx_msg_out_<?php echo esc_attr($cx_slug); ?>" style="display:none;font-size:.84rem;text-align:center;margin-top:2px"></div>
          </div>
        </div>

        <?php else: // No modules — fall back to generic contact form ?>
        <div class="vs-contact-form-card">
          <div class="vs-contact-form-hdr">
            <div class="vs-contact-form-hdr-title">Send an Enquiry</div>
            <div class="vs-contact-form-hdr-sub">We typically respond within 24 hours.</div>
          </div>
          <div style="padding:28px;display:flex;flex-direction:column;gap:12px">
            <input class="vs-input" id="vs-qc-name"    type="text"  placeholder="Your Full Name *">
            <input class="vs-input" id="vs-qc-phone"   type="tel"   placeholder="Phone Number *">
            <input class="vs-input" id="vs-qc-email"   type="email" placeholder="Email Address (optional)">
            <?php if (!empty($all_items)): ?>
            <select class="vs-input" id="vs-qc-service" aria-label="Select Service / Product (optional)">
              <option value="">Select Service / Product (optional)</option>
              <?php foreach ($all_items as $ai): $aname=$ai['item_title']??$ai['name']??''; if(!$aname)continue; ?>
              <option value="<?php echo esc_attr($aname); ?>"><?php echo esc_html($aname); ?></option>
              <?php endforeach; ?>
            </select>
            <?php elseif ($primary && !empty($primary->services_data)): ?>
            <select class="vs-input" id="vs-qc-service" aria-label="Select Service (optional)">
              <option value="">Select Service (optional)</option>
              <?php foreach ($primary->services_data as $sv): if(empty($sv['name']))continue; ?>
              <option value="<?php echo esc_attr($sv['name']); ?>"><?php echo esc_html($sv['name']); ?></option>
              <?php endforeach; ?>
            </select>
            <?php endif; ?>
            <textarea class="vs-input vs-textarea" id="vs-qc-message" rows="4" placeholder="Describe your requirement…"></textarea>
            <input type="hidden" id="vs-qc-lid" value="<?php echo $lid; ?>">
            <button onclick="vsSubmitQC()" id="vs-qc-submit"
              style="width:100%;background:#1E3A5F;color:#fff;border:none;padding:13px 20px;border-radius:8px;font-size:.92rem;font-weight:700;cursor:pointer;transition:background .2s;letter-spacing:.02em"
              onmouseover="this.style.background='#16304f'" onmouseout="this.style.background='#1E3A5F'">
              Submit Enquiry →
            </button>
            <div id="vs-qc-msg" style="display:none;margin-top:4px;font-size:.84rem;text-align:center"></div>
          </div>
        </div>
        <?php endif; ?>
      </div>

    </div><!-- .vs-contact-new-grid -->
  </div>
</section>
<?php endif; ?>
<?php
$_vs_sections['contact'] = ob_get_clean();

// Room Types section (new module — Phase 3e, category-gated to 'hotels')
ob_start();
if ( $_sec_show( 'room_types' ) ) {
    global $wpdb;
    $_room_types_data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $wpdb->prefix . 'gs_', 'room_types', $lid );
    $_room_types_html = \GoodService\Modules\RoomTypesModule::render( [
        'room_types'    => $_room_types_data['rooms'] ?? [],
        'listing_id'    => (int) ( $primary->id ?? 0 ),
        'section_title' => $cv_room_types_section_title,
        'img_display'   => [ 'fit' => $cv_room_types_img_fit, 'position' => $cv_room_types_img_position, 'zoom' => $cv_room_types_img_zoom, 'interval' => $cv_room_slider_interval, 'popup_fit' => $cv_room_popup_img_fit ],
        'grid_cols'     => $cv_room_types_grid_cols,
        'max_rows'      => $cv_room_types_max_rows,
    ] );
    // Real fix — this section was missing the .vs-wrap wrapper every
    // other section in this file has (confirmed by direct count: all
    // 25 pre-existing sections use it, Room Types was the only one
    // that didn't). $_sec_wrap_style() is what actually reads the
    // Section Container Width and Section Margins settings and turns
    // them into real CSS on the frontend — without this wrapper, those
    // settings had nothing to apply to at all, regardless of whether
    // they were saved correctly. This is the actual root cause of both
    // the width control and the margin control not working for this
    // section specifically. The outer <section id="vs-sec-room_types">
    // is also added here for the same reason every other section has
    // one: it is what the Section Heading Typography CSS rule targets
    // (see '#vs-sec-room_types .vs-sec-title' below) — without it, that
    // selector would never match anything at all.
    if ( $_room_types_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-room_types"><div class="vs-wrap" ' . $_sec_wrap_style( 'room_types' ) . '>' . $_room_types_html . '</div></section>';
    }
}
$_vs_sections['room_types'] = ob_get_clean();

// Hotels / Banquets / Hospitality, module 1 — Banquet & Event Spaces
// (with the Event Capacity Matrix). Own, independently-gated data —
// not dependent on room_types being active. See
// HotelEventSpacesModule's own docblock for the 'hotels' category
// slug and the universal modules already investigated and NOT
// duplicated.
ob_start();
if ( $_sec_show( 'hotel_event_spaces' ) ) {
    global $wpdb;
    $_hev_venues = \GoodService\Modules\HotelEventSpacesModule::get_venues( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hev_html = \GoodService\Modules\HotelEventSpacesModule::render( [
        'venues'               => $_hev_venues,
        'section_title'        => $cv_hev_section_title,
        'section_description'  => $cv_hev_section_desc,
        'img_display'          => $cv_hev_img,
    ] );
    if ( $_hev_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-hotel_event_spaces"><div class="vs-wrap" ' . $_sec_wrap_style( 'hotel_event_spaces' ) . '>' . $_hev_html . '</div></section>';
    }
}
$_vs_sections['hotel_event_spaces'] = ob_get_clean();

// Hotels / Banquets / Hospitality, module 2 — Events at the Property.
// Own, independently-gated data. See HotelEventsShowcaseModule's own
// docblock for why it reuses WeddingStoriesModule's proven story-card
// structure (and the shared window.vsLightbox() mechanism) rather than
// reusing that module directly (it is gated to a different category).
ob_start();
if ( $_sec_show( 'hotel_events_showcase' ) ) {
    global $wpdb;
    $_hevs_items = \GoodService\Modules\HotelEventsShowcaseModule::get_events( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hevs_html = \GoodService\Modules\HotelEventsShowcaseModule::render( [
        'items'                => $_hevs_items,
        'section_title'        => $cv_hevs_section_title,
        'section_description'  => $cv_hevs_section_desc,
        'img_display'          => $cv_hevs_img,
    ] );
    if ( $_hevs_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-hotel_events_showcase"><div class="vs-wrap" ' . $_sec_wrap_style( 'hotel_events_showcase' ) . '>' . $_hevs_html . '</div></section>';
    }
}
$_vs_sections['hotel_events_showcase'] = ob_get_clean();

// Hotels / Banquets / Hospitality, module 3 — Dining & Culinary
// Experience. Own, independently-gated data. See HotelDiningModule's
// own docblock for why it reuses HomeServicesCatalogueModule's
// category-tab filtering mechanism rather than inventing a second one.
ob_start();
if ( $_sec_show( 'hotel_dining' ) ) {
    global $wpdb;
    $_hdin_items = \GoodService\Modules\HotelDiningModule::get_items( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hdin_html = \GoodService\Modules\HotelDiningModule::render( [
        'items'                => $_hdin_items,
        'section_title'        => $cv_hdin_section_title,
        'section_description'  => $cv_hdin_section_desc,
        'img_display'          => $cv_hdin_img,
    ] );
    if ( $_hdin_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-hotel_dining"><div class="vs-wrap" ' . $_sec_wrap_style( 'hotel_dining' ) . '>' . $_hdin_html . '</div></section>';
    }
}
$_vs_sections['hotel_dining'] = ob_get_clean();

// Hotels / Banquets / Hospitality, module 4 — Amenities & Facilities
// (Grouped). Own, independently-gated data — additive alongside, not
// a replacement for, the universal Amenities/Facilities sections. See
// HotelAmenitiesModule's own docblock for why a grouped presentation
// is a real gap neither universal module fills.
ob_start();
if ( $_sec_show( 'hotel_amenities' ) ) {
    global $wpdb;
    $_hamn_items = \GoodService\Modules\HotelAmenitiesModule::get_items( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hamn_html = \GoodService\Modules\HotelAmenitiesModule::render( [
        'items'                => $_hamn_items,
        'section_title'        => $cv_hamn_section_title,
        'section_description'  => $cv_hamn_section_desc,
    ] );
    if ( $_hamn_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-hotel_amenities"><div class="vs-wrap" ' . $_sec_wrap_style( 'hotel_amenities' ) . '>' . $_hamn_html . '</div></section>';
    }
}
$_vs_sections['hotel_amenities'] = ob_get_clean();

// Hotels / Banquets / Hospitality, module 5 — Virtual Tour. Own,
// independently-gated single-item data (a video URL or an embed
// code), not a repeater. See HotelVirtualTourModule's own docblock
// for the reused YouTube-regex and iframe-sanitization patterns.
ob_start();
if ( $_sec_show( 'hotel_virtual_tour' ) ) {
    global $wpdb;
    $_hvt_data = \GoodService\Modules\HotelVirtualTourModule::get_data( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hvt_html = \GoodService\Modules\HotelVirtualTourModule::render( [
        'video_url'            => $_hvt_data['video_url'],
        'embed_code'           => $_hvt_data['embed_code'],
        'section_title'        => $cv_hvt_section_title,
        'section_description'  => $cv_hvt_section_desc,
    ] );
    if ( $_hvt_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-hotel_virtual_tour"><div class="vs-wrap" ' . $_sec_wrap_style( 'hotel_virtual_tour' ) . '>' . $_hvt_html . '</div></section>';
    }
}
$_vs_sections['hotel_virtual_tour'] = ob_get_clean();

// Hotels / Banquets / Hospitality, module 6 (final) — Final Conversion
// Banner. No repeater data to fetch — just business_type plus
// section_title/description context, same shape as
// wedding_closing_banner. Never empty (always renders once enabled):
// the banner + CTA is meaningful with zero vendor-entered content.
ob_start();
if ( $_sec_show( 'hotel_closing_banner' ) ) {
    $_hcb_html = \GoodService\Modules\HotelClosingBannerModule::render( [
        'business_type'        => $cv_hcb_business_type,
        'section_title'        => $cv_hcb_section_title,
        'section_description'  => $cv_hcb_section_desc,
    ] );
    if ( $_hcb_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-hotel_closing_banner"><div class="vs-wrap" ' . $_sec_wrap_style( 'hotel_closing_banner' ) . '>' . $_hcb_html . '</div></section>';
    }
}
$_vs_sections['hotel_closing_banner'] = ob_get_clean();

// Property Listings section (real estate module 1 of 4, category-gated
// to 'real-estate'). Built with the outer <section id="vs-sec-..."> and
// .vs-wrap wrapper included from the start — the exact two pieces Room
// Types was originally missing and needed a follow-up fix to add — so
// Section Container Widths, Section Margins, and Section Heading
// Typography all correctly apply to this section from its first version.
ob_start();
if ( $_sec_show( 'property_listings' ) ) {
    global $wpdb;
    $_properties = \GoodService\Modules\PropertyListingsModule::get_properties( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_prop_html = \GoodService\Modules\PropertyListingsModule::render( [
        'properties'          => $_properties,
        'section_title'       => $cv_prop_section_title,
        'section_description' => $cv_prop_section_desc,
        'display'             => $cv_prop_display,
        'grid_cols'           => $cv_prop_grid_cols,
        'max_rows'            => $cv_prop_max_rows,
        'sort'                => $cv_prop_sort,
        'img_display'         => [ 'fit' => $cv_prop_img_fit, 'position' => $cv_prop_img_position, 'zoom' => $cv_prop_img_zoom ],
    ] );
    if ( $_prop_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-property_listings"><div class="vs-wrap" ' . $_sec_wrap_style( 'property_listings' ) . '>' . $_prop_html . '</div></section>';
    }
}
$_vs_sections['property_listings'] = ob_get_clean();

// Featured Properties section (real estate module 2 of 4). Critical
// independence requirement, satisfied structurally: this block checks
// ONLY $_sec_show('featured_properties') — its own, separate gate —
// never $_sec_show('property_listings') or any assignment state for
// that other module. The property data itself is fetched directly via
// PropertyListingsModule::get_properties(), a pure data-access call
// with no dependency on whether that other section/module is active,
// so Featured Properties can be ON while Property Listings is OFF and
// still have real data to show, exactly as required.
ob_start();
if ( $_sec_show( 'featured_properties' ) ) {
    global $wpdb;
    $_all_properties_for_featured = \GoodService\Modules\PropertyListingsModule::get_properties( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_feat_html = \GoodService\Modules\FeaturedPropertiesModule::render( [
        'properties'          => $_all_properties_for_featured,
        'selection_mode'       => $cv_feat_selection_mode,
        'selection_filter'     => $cv_feat_selection_filter,
        'limit'                => $cv_feat_limit,
        'section_title'        => $cv_feat_section_title,
        'section_description'  => $cv_feat_section_desc,
        'display'              => $cv_feat_display,
        'grid_cols'            => $cv_feat_grid_cols,
        'img_display'          => [ 'fit' => $cv_feat_img_fit, 'position' => $cv_feat_img_position, 'zoom' => $cv_feat_img_zoom ],
    ] );
    if ( $_feat_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-featured_properties"><div class="vs-wrap" ' . $_sec_wrap_style( 'featured_properties' ) . '>' . $_feat_html . '</div></section>';
    }
}
$_vs_sections['featured_properties'] = ob_get_clean();

// Property Types/Categories section (real estate module 3 of 4). Same
// independence pattern as Featured Properties: own gate, own
// activation, property data fetched directly rather than depending on
// property_listings being active.
ob_start();
if ( $_sec_show( 'property_types' ) ) {
    global $wpdb;
    $_all_properties_for_types = \GoodService\Modules\PropertyListingsModule::get_properties( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_types_html = \GoodService\Modules\PropertyTypesModule::render( [
        'properties'          => $_all_properties_for_types,
        'section_title'        => $cv_types_section_title,
        'section_description'  => $cv_types_section_desc,
        'enabled_types'        => $cv_types_enabled,
        'images'               => $cv_types_images,
        'grid_cols'            => $cv_types_grid_cols,
        'img_fit'              => (string) ( $cd['property_types_img_fit'] ?? 'cover' ),
    ] );
    if ( $_types_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-property_types"><div class="vs-wrap" ' . $_sec_wrap_style( 'property_types' ) . '>' . $_types_html . '</div></section>';
    }
}
$_vs_sections['property_types'] = ob_get_clean();

// Property Gallery section (real estate module 4 of 4, the last one).
// Fully independent — its own gate, its own data (a vendor-curated
// selection from the existing media library), no dependency on any
// of the other three real-estate modules.
ob_start();
if ( $_sec_show( 'property_gallery' ) ) {
    global $wpdb;
    $_gallery_images = \GoodService\Modules\PropertyGalleryModule::get_images( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_gal_html = \GoodService\Modules\PropertyGalleryModule::render( [
        'images'             => $_gallery_images,
        'section_title'      => $cv_gal_section_title,
        'section_description'=> $cv_gal_section_desc,
        'layout'             => $cv_gal_layout,
        'grid_cols'          => $cv_gal_grid_cols,
        'lightbox_enabled'   => $cv_gal_lightbox,
        'captions_enabled'   => $cv_gal_captions,
        'max_images'         => $cv_gal_max_images,
        'aspect_ratio'       => $cv_gal_aspect,
        'border_radius'      => $cv_gal_radius,
        'gap'                => $cv_gal_gap,
        'img_display'        => [ 'fit' => $cv_gal_img_fit, 'position' => $cv_gal_img_position, 'zoom' => $cv_gal_img_zoom ],
    ] );
    if ( $_gal_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-property_gallery"><div class="vs-wrap" ' . $_sec_wrap_style( 'property_gallery' ) . '>' . $_gal_html . '</div></section>';
    }
}
$_vs_sections['property_gallery'] = ob_get_clean();

// Interior Designers & Architects, module 1 of 5 — Featured Projects.
ob_start();
if ( $_sec_show( 'featured_projects' ) ) {
    global $wpdb;
    $_ida_all_projects = \GoodService\Modules\ProjectsModule::get_projects( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_ida_fp_html = \GoodService\Modules\FeaturedProjectsModule::render( [
        'projects'             => $_ida_all_projects,
        'selected_ids'         => $cv_ida_fp_selected_ids,
        'max'                  => $cv_ida_fp_max,
        'layout'               => $cv_ida_fp_layout,
        'section_title'        => $cv_ida_fp_section_title,
        'section_description'  => $cv_ida_fp_section_desc,
        'display'              => $cv_ida_fp_display,
        'img_display'          => [ 'fit' => $cv_ida_fp_img_fit, 'position' => $cv_ida_fp_img_position, 'zoom' => $cv_ida_fp_img_zoom, 'interval' => $cv_ida_fp_slider_interval, 'popup_fit' => $cv_ida_fp_popup_img_fit ],
    ] );
    if ( $_ida_fp_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-featured_projects"><div class="vs-wrap" ' . $_sec_wrap_style( 'featured_projects' ) . '>' . $_ida_fp_html . '</div></section>';
    }
}
$_vs_sections['featured_projects'] = ob_get_clean();

// Interior Designers & Architects, module 2 of 5 — Project
// Categories. Independent gate; fetches project data directly.
ob_start();
if ( $_sec_show( 'project_categories' ) ) {
    global $wpdb;
    $_ida_pc_all_projects = \GoodService\Modules\ProjectsModule::get_projects( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_ida_pc_html = \GoodService\Modules\ProjectCategoriesModule::render( [
        'category_defs'        => $cv_ida_pc_defs,
        'projects'              => $_ida_pc_all_projects,
        'section_title'         => $cv_ida_pc_section_title,
        'section_description'   => $cv_ida_pc_section_desc,
        'grid_cols'             => $cv_ida_pc_grid_cols,
        'img_display'           => [ 'fit' => $cv_ida_pc_img_fit, 'position' => $cv_ida_pc_img_position, 'zoom' => $cv_ida_pc_img_zoom ],
    ] );
    if ( $_ida_pc_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-project_categories"><div class="vs-wrap" ' . $_sec_wrap_style( 'project_categories' ) . '>' . $_ida_pc_html . '</div></section>';
    }
}
$_vs_sections['project_categories'] = ob_get_clean();

// Interior Designers & Architects, module 3 of 5 — 3D Designs & Before/After.
ob_start();
if ( $_sec_show( 'three_d_before_after' ) ) {
    global $wpdb;
    $_ida_3d_data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $wpdb->prefix . 'gs_', 'three_d_before_after', $lid );
    $_ida_3d_html = \GoodService\Modules\ThreeDBeforeAfterModule::render( [
        'designs'              => $_ida_3d_data['designs'] ?? [],
        'before_afters'        => $_ida_3d_data['before_afters'] ?? [],
        'ba_layout'             => $cv_ida_3d_ba_layout,
        'section_title'         => $cv_ida_3d_section_title,
        'section_description'   => $cv_ida_3d_section_desc,
        'img_display'           => [ 'fit' => $cv_ida_3d_img_fit, 'position' => $cv_ida_3d_img_position, 'zoom' => $cv_ida_3d_img_zoom ],
    ] );
    if ( $_ida_3d_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-three_d_before_after"><div class="vs-wrap" ' . $_sec_wrap_style( 'three_d_before_after' ) . '>' . $_ida_3d_html . '</div></section>';
    }
}
$_vs_sections['three_d_before_after'] = ob_get_clean();

// Interior Designers & Architects, module 4 of 5 — Design Styles & Expertise.
ob_start();
if ( $_sec_show( 'design_styles' ) ) {
    global $wpdb;
    $_ida_ds_all_projects = \GoodService\Modules\ProjectsModule::get_projects( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_ida_ds_html = \GoodService\Modules\DesignStylesModule::render( [
        'style_defs'            => $cv_ida_ds_style_defs,
        'expertise_defs'        => $cv_ida_ds_expertise_defs,
        'projects'              => $_ida_ds_all_projects,
        'section_title'         => $cv_ida_ds_section_title,
        'section_description'   => $cv_ida_ds_section_desc,
        'img_display'           => [ 'fit' => $cv_ida_ds_img_fit, 'position' => $cv_ida_ds_img_position, 'zoom' => $cv_ida_ds_img_zoom ],
    ] );
    if ( $_ida_ds_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-design_styles"><div class="vs-wrap" ' . $_sec_wrap_style( 'design_styles' ) . '>' . $_ida_ds_html . '</div></section>';
    }
}
$_vs_sections['design_styles'] = ob_get_clean();

// Interior Designers & Architects, module 5 of 5 — Design Process,
// the final module in this category build. Steps are pure vendor-
// authored configuration with no cross-referencing to Projects
// needed, so — like Project Categories and Design Styles — they live
// in customizer_data rather than gs_listing_module_data, and no
// separate database fetch is needed here at all.
ob_start();
if ( $_sec_show( 'design_process' ) ) {
    $_ida_dp_html = \GoodService\Modules\DesignProcessModule::render( [
        'steps'                => $cv_ida_dp_steps,
        'layout'                => $cv_ida_dp_layout,
        'section_title'         => $cv_ida_dp_section_title,
        'section_description'   => $cv_ida_dp_section_desc,
        'img_display'           => [ 'fit' => $cv_ida_dp_img_fit, 'position' => $cv_ida_dp_img_position, 'zoom' => $cv_ida_dp_img_zoom ],
    ] );
    if ( $_ida_dp_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-design_process"><div class="vs-wrap" ' . $_sec_wrap_style( 'design_process' ) . '>' . $_ida_dp_html . '</div></section>';
    }
}
$_vs_sections['design_process'] = ob_get_clean();

// Health & Wellness, module 1 of 5 — Featured Services & Treatments.
// Reads doctor data directly for related-doctor matching, independent
// of whether the Doctors module itself is enabled on this listing.
ob_start();
if ( $_sec_show( 'featured_services' ) ) {
    global $wpdb;
    $_hw_services = \GoodService\Modules\HealthWellnessModule::get_services( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hw_doctors_for_fs = \GoodService\Modules\HealthWellnessModule::get_doctors( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hw_fs_html = \GoodService\Modules\FeaturedServicesModule::render( [
        'services'             => $_hw_services,
        'doctors'              => $_hw_doctors_for_fs,
        'layout'               => $cv_hw_fs_layout,
        'section_title'        => $cv_hw_fs_section_title,
        'section_description'  => $cv_hw_fs_section_desc,
        'img_display'          => [ 'fit' => $cv_hw_fs_img_fit, 'position' => $cv_hw_fs_img_position, 'zoom' => $cv_hw_fs_img_zoom, 'interval' => $cv_hw_fs_slider_interval, 'popup_fit' => $cv_hw_fs_popup_img_fit ],
        'phone'                => $phone,
        'wa_clean'             => $wa_clean,
    ] );
    if ( $_hw_fs_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-featured_services"><div class="vs-wrap" ' . $_sec_wrap_style( 'featured_services' ) . '>' . $_hw_fs_html . '</div></section>';
    }
}
$_vs_sections['featured_services'] = ob_get_clean();

// Beauty & Salon, section 01 of 6 — Beauty Service Discovery. Own
// data-owning module, independent of every other Beauty & Salon
// section still to be built (each gated by its own $_sec_show()).
ob_start();
if ( $_sec_show( 'beauty_services' ) ) {
    global $wpdb;
    $_bs_services = \GoodService\Modules\BeautySalonModule::get_services( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_bs_html = \GoodService\Modules\BeautyServicesModule::render( [
        'services'            => $_bs_services,
        'section_title'       => $cv_bs_section_title,
        'section_description' => $cv_bs_section_desc,
        'img_display'         => $cv_bs_img,
        'phone'               => $phone,
        'wa_clean'            => $wa_clean,
    ] );
    if ( $_bs_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-beauty_services"><div class="vs-wrap" ' . $_sec_wrap_style( 'beauty_services' ) . '>' . $_bs_html . '</div></section>';
    }
}
$_vs_sections['beauty_services'] = ob_get_clean();

// Beauty & Salon, section 02 of 6 — Signature Looks & Transformations.
// Own, independently-gated data — not dependent on beauty_services.
ob_start();
if ( $_sec_show( 'beauty_gallery' ) ) {
    global $wpdb;
    $_bg_items = \GoodService\Modules\BeautySalonModule::get_gallery_items( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_bg_html = \GoodService\Modules\BeautyGalleryModule::render( [
        'items'                => $_bg_items,
        'section_title'        => $cv_bg_section_title,
        'section_description'  => $cv_bg_section_desc,
        'img_display'          => $cv_bg_img,
    ] );
    if ( $_bg_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-beauty_gallery"><div class="vs-wrap" ' . $_sec_wrap_style( 'beauty_gallery' ) . '>' . $_bg_html . '</div></section>';
    }
}
$_vs_sections['beauty_gallery'] = ob_get_clean();

// Beauty & Salon, section 03 of 6 — Beauty Experts / Stylists. Own,
// independently-gated data — not dependent on beauty_services or
// beauty_gallery.
ob_start();
if ( $_sec_show( 'beauty_experts' ) ) {
    global $wpdb;
    $_be_experts = \GoodService\Modules\BeautySalonModule::get_experts( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_be_html = \GoodService\Modules\BeautyExpertsModule::render( [
        'experts'              => $_be_experts,
        'section_title'        => $cv_be_section_title,
        'section_description'  => $cv_be_section_desc,
        'img_display'          => $cv_be_img,
    ] );
    if ( $_be_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-beauty_experts"><div class="vs-wrap" ' . $_sec_wrap_style( 'beauty_experts' ) . '>' . $_be_html . '</div></section>';
    }
}
$_vs_sections['beauty_experts'] = ob_get_clean();

// Beauty & Salon, section 04 of 6 — Salon Experience & Facilities.
// Own, independently-gated data.
ob_start();
if ( $_sec_show( 'beauty_facilities' ) ) {
    global $wpdb;
    $_bf_data = \GoodService\Modules\BeautySalonModule::get_facilities_data( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_bf_html = \GoodService\Modules\BeautyFacilitiesModule::render( [
        'image'                => $_bf_data['image'],
        'facilities'           => $_bf_data['facilities'],
        'custom_facilities'    => $_bf_data['custom_facilities'],
        'section_title'        => $cv_bf_section_title,
        'section_description'  => $cv_bf_section_desc,
        'img_display'          => $cv_bf_img,
    ] );
    if ( $_bf_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-beauty_facilities"><div class="vs-wrap" ' . $_sec_wrap_style( 'beauty_facilities' ) . '>' . $_bf_html . '</div></section>';
    }
}
$_vs_sections['beauty_facilities'] = ob_get_clean();

// Beauty & Salon, section 05 of 6 — Beauty Packages & Offers. Own,
// independently-gated data.
ob_start();
if ( $_sec_show( 'beauty_packages' ) ) {
    global $wpdb;
    $_bp_packages = \GoodService\Modules\BeautySalonModule::get_packages( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_bp_html = \GoodService\Modules\BeautyPackagesModule::render( [
        'packages'             => $_bp_packages,
        'section_title'        => $cv_bp_section_title,
        'section_description'  => $cv_bp_section_desc,
        'img_display'          => $cv_bp_img,
        'currency'             => \gs_setting( 'currency_symbol', '₹' ),
    ] );
    if ( $_bp_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-beauty_packages"><div class="vs-wrap" ' . $_sec_wrap_style( 'beauty_packages' ) . '>' . $_bp_html . '</div></section>';
    }
}
$_vs_sections['beauty_packages'] = ob_get_clean();

// Beauty & Salon, section 06 of 6 — Appointment/Booking Conversion.
// No ModuleRegistry-stored data of its own (all customizer_data
// settings) — but the "adaptive steps" list is built from the real
// output of get_services()/get_experts(), the same foundation methods
// Sections 01 and 03 already use, so the steps shown here can never
// promise a specialist-selection step to a vendor who hasn't added
// any real experts.
ob_start();
if ( $_sec_show( 'beauty_booking_cta' ) ) {
    global $wpdb;
    $_bc_has_services = ! empty( \GoodService\Modules\BeautySalonModule::get_services( $wpdb, $wpdb->prefix . 'gs_', $lid ) );
    $_bc_has_experts  = ! empty( \GoodService\Modules\BeautySalonModule::get_experts( $wpdb, $wpdb->prefix . 'gs_', $lid ) );
    $_bc_html = \GoodService\Modules\BeautyBookingCtaModule::render( [
        'has_services'         => $_bc_has_services,
        'has_experts'          => $_bc_has_experts,
        'section_title'        => $cv_bc_section_title,
        'section_description'  => $cv_bc_section_desc,
        'cta_text'             => $cv_bc_button_text,
        'image'                => $cv_bc_image,
        'img_display'          => $cv_bc_img,
    ] );
    if ( $_bc_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-beauty_booking_cta"><div class="vs-wrap" ' . $_sec_wrap_style( 'beauty_booking_cta' ) . '>' . $_bc_html . '</div></section>';
    }
}
$_vs_sections['beauty_booking_cta'] = ob_get_clean();

// Events & Wedding, section 01 of 6 — Signature Portfolio.
ob_start();
if ( $_sec_show( 'wedding_portfolio' ) ) {
    global $wpdb;
    $_wp_items = \GoodService\Modules\WeddingEventsModule::get_portfolio_items( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_wp_html  = \GoodService\Modules\WeddingPortfolioModule::render( [
        'items'               => $_wp_items,
        'vendor_types'        => $wedding_vendor_types,
        'section_title'       => $cv_wp_section_title,
        'section_description' => $cv_wp_section_desc,
        'img_display'         => $cv_wp_img,
        'layout'              => $cv_wp_layout,
    ] );
    if ( $_wp_html !== '' ) {
        echo '<section class="vs-section gs-wedding-reveal" id="vs-sec-wedding_portfolio"><div class="vs-wrap" ' . $_sec_wrap_style( 'wedding_portfolio' ) . '>' . $_wp_html . '</div></section>';
    }
}
$_vs_sections['wedding_portfolio'] = ob_get_clean();

// Events & Wedding, section 02 of 6 — Real Weddings / Real Events.
ob_start();
if ( $_sec_show( 'wedding_stories' ) ) {
    global $wpdb;
    $_ws_items = \GoodService\Modules\WeddingEventsModule::get_stories( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_ws_html  = \GoodService\Modules\WeddingStoriesModule::render( [
        'items'               => $_ws_items,
        'vendor_types'        => $wedding_vendor_types,
        'section_title'       => $cv_ws_section_title,
        'section_description' => $cv_ws_section_desc,
        'img_display'         => $cv_ws_img,
    ] );
    if ( $_ws_html !== '' ) {
        echo '<section class="vs-section gs-wedding-reveal" id="vs-sec-wedding_stories"><div class="vs-wrap" ' . $_sec_wrap_style( 'wedding_stories' ) . '>' . $_ws_html . '</div></section>';
    }
}
$_vs_sections['wedding_stories'] = ob_get_clean();

// Events & Wedding, section 03 of 6 — Services & Experience.
ob_start();
if ( $_sec_show( 'wedding_services' ) ) {
    global $wpdb;
    $_wsv_items = \GoodService\Modules\WeddingEventsModule::get_services( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_wsv_html  = \GoodService\Modules\WeddingServicesModule::render( [
        'items'               => $_wsv_items,
        'vendor_types'        => $wedding_vendor_types,
        'section_title'       => $cv_wsv_section_title,
        'section_description' => $cv_wsv_section_desc,
        'img_fit'             => (string) ( $cd['wedding_services_img_fit'] ?? 'cover' ),
    ] );
    if ( $_wsv_html !== '' ) {
        echo '<section class="vs-section gs-wedding-reveal" id="vs-sec-wedding_services"><div class="vs-wrap" ' . $_sec_wrap_style( 'wedding_services' ) . '>' . $_wsv_html . '</div></section>';
    }
}
$_vs_sections['wedding_services'] = ob_get_clean();

// Events & Wedding, section 04 of 6 — Packages & Collections.
ob_start();
if ( $_sec_show( 'wedding_packages' ) ) {
    global $wpdb;
    $_wpk_items = \GoodService\Modules\WeddingEventsModule::get_packages( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_wpk_html  = \GoodService\Modules\WeddingPackagesModule::render( [
        'items'               => $_wpk_items,
        'vendor_types'        => $wedding_vendor_types,
        'section_title'       => $cv_wpk_section_title,
        'section_description' => $cv_wpk_section_desc,
        'layout'              => $cv_wpk_layout,
    ] );
    if ( $_wpk_html !== '' ) {
        echo '<section class="vs-section gs-wedding-reveal" id="vs-sec-wedding_packages"><div class="vs-wrap" ' . $_sec_wrap_style( 'wedding_packages' ) . '>' . $_wpk_html . '</div></section>';
    }
}
$_vs_sections['wedding_packages'] = ob_get_clean();

// Events & Wedding, section 05 of 6 — Experience & Style. A pure
// customizer_data setting, not module-registry repeater content — no
// ModuleRegistry::fetch_module_data() call here; style_tags is read
// directly from $cd (already validated) and passed straight through.
ob_start();
if ( $_sec_show( 'wedding_style' ) ) {
    $_wst_html = \GoodService\Modules\WeddingStyleModule::render( [
        'style_tags'          => $wedding_style_tags,
        'vendor_types'        => $wedding_vendor_types,
        'section_title'       => $cv_wst_section_title,
        'section_description' => $cv_wst_section_desc,
    ] );
    if ( $_wst_html !== '' ) {
        echo '<section class="vs-section gs-wedding-reveal" id="vs-sec-wedding_style"><div class="vs-wrap" ' . $_sec_wrap_style( 'wedding_style' ) . '>' . $_wst_html . '</div></section>';
    }
}
$_vs_sections['wedding_style'] = ob_get_clean();

// Events & Wedding, section 06 of 6 — Team / Creative Experts.
ob_start();
if ( $_sec_show( 'wedding_team' ) ) {
    global $wpdb;
    $_wtm_items = \GoodService\Modules\WeddingEventsModule::get_team( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_wtm_html  = \GoodService\Modules\WeddingTeamModule::render( [
        'items'               => $_wtm_items,
        'vendor_types'        => $wedding_vendor_types,
        'section_title'       => $cv_wtm_section_title,
        'section_description' => $cv_wtm_section_desc,
        'layout'              => $cv_wtm_layout,
        'img_fit'             => (string) ( $cd['wedding_team_img_fit'] ?? 'cover' ),
    ] );
    if ( $_wtm_html !== '' ) {
        echo '<section class="vs-section gs-wedding-reveal" id="vs-sec-wedding_team"><div class="vs-wrap" ' . $_sec_wrap_style( 'wedding_team' ) . '>' . $_wtm_html . '</div></section>';
    }
}
$_vs_sections['wedding_team'] = ob_get_clean();

// Events & Wedding, section 07 of 7 — Venue / Event Specialisation.
// OPTIONAL — only ever meaningful for venue-adjacent vendor types, but
// deliberately not vendor-type-gated here either: same as every prior
// section, an empty items array from get_venue_specializations()
// naturally makes WeddingVenueSpecModule::render() return '', so a
// vendor with nothing checked simply gets no section, no special-casing
// needed.
ob_start();
if ( $_sec_show( 'wedding_venue_specialization' ) ) {
    global $wpdb;
    $_wvs_items = \GoodService\Modules\WeddingEventsModule::get_venue_specializations( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_wvs_html  = \GoodService\Modules\WeddingVenueSpecModule::render( [
        'items'               => $_wvs_items,
        'vendor_types'        => $wedding_vendor_types,
        'section_title'       => $cv_wvs_section_title,
        'section_description' => $cv_wvs_section_desc,
    ] );
    if ( $_wvs_html !== '' ) {
        echo '<section class="vs-section gs-wedding-reveal" id="vs-sec-wedding_venue_specialization"><div class="vs-wrap" ' . $_sec_wrap_style( 'wedding_venue_specialization' ) . '>' . $_wvs_html . '</div></section>';
    }
}
$_vs_sections['wedding_venue_specialization'] = ob_get_clean();

// Events & Wedding, section 08 of 8 — Location & Destination Coverage.
// Empty-state is deliberately an OR at this level too: get_locations()
// can return an empty array while get_destination_availability() is
// still true (a vendor with no fixed cities who only does destination
// weddings), and WeddingLocationsModule::render() itself only returns
// '' when BOTH are empty/false — never gated on the location list
// alone the way every prior section's items array is.
ob_start();
if ( $_sec_show( 'wedding_locations' ) ) {
    global $wpdb;
    $_wloc_items = \GoodService\Modules\WeddingEventsModule::get_locations( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_wloc_dest  = \GoodService\Modules\WeddingEventsModule::get_destination_availability( $cd );
    $_wloc_html  = \GoodService\Modules\WeddingLocationsModule::render( [
        'items'                 => $_wloc_items,
        'destination_available' => $_wloc_dest['available'],
        'destination_note'      => $_wloc_dest['note'],
        'vendor_types'          => $wedding_vendor_types,
        'section_title'         => $cv_wloc_section_title,
        'section_description'   => $cv_wloc_section_desc,
    ] );
    if ( $_wloc_html !== '' ) {
        echo '<section class="vs-section gs-wedding-reveal" id="vs-sec-wedding_locations"><div class="vs-wrap" ' . $_sec_wrap_style( 'wedding_locations' ) . '>' . $_wloc_html . '</div></section>';
    }
}
$_vs_sections['wedding_locations'] = ob_get_clean();

// Events & Wedding, section 10 of 10 — Check Availability. No repeater
// data to fetch — just section_title/description context, same as any
// other section with no per-item content. Never empty (always renders
// once enabled): the date-picker + enquiry CTA is meaningful with zero
// vendor-entered content.
ob_start();
if ( $_sec_show( 'wedding_availability' ) ) {
    $_wav_html = \GoodService\Modules\WeddingAvailabilityModule::render( [
        'vendor_types'        => $wedding_vendor_types,
        'section_title'       => $cv_wav_section_title,
        'section_description' => $cv_wav_section_desc,
    ] );
    if ( $_wav_html !== '' ) {
        echo '<section class="vs-section gs-wedding-reveal" id="vs-sec-wedding_availability"><div class="vs-wrap" ' . $_sec_wrap_style( 'wedding_availability' ) . '>' . $_wav_html . '</div></section>';
    }
}
$_vs_sections['wedding_availability'] = ob_get_clean();

// Events & Wedding, section 11 of 11 — Request a Quote. No repeater
// data to fetch — just section_title/description context, same as
// Section 10. Never empty (always renders once enabled): the form +
// enquiry CTA is meaningful with zero vendor-entered content.
ob_start();
if ( $_sec_show( 'wedding_quote' ) ) {
    $_wq_html = \GoodService\Modules\WeddingQuoteModule::render( [
        'vendor_types'        => $wedding_vendor_types,
        'section_title'       => $cv_wq_section_title,
        'section_description' => $cv_wq_section_desc,
    ] );
    if ( $_wq_html !== '' ) {
        echo '<section class="vs-section gs-wedding-reveal" id="vs-sec-wedding_quote"><div class="vs-wrap" ' . $_sec_wrap_style( 'wedding_quote' ) . '>' . $_wq_html . '</div></section>';
    }
}
$_vs_sections['wedding_quote'] = ob_get_clean();

// Events & Wedding, section 12 of 12 (final) — Premium Conversion
// Banner. No repeater data to fetch — just section_title/description
// context, same as Section 11. Never empty (always renders once
// enabled): the banner + CTA is meaningful with zero vendor-entered
// content.
ob_start();
if ( $_sec_show( 'wedding_closing_banner' ) ) {
    $_wcb_html = \GoodService\Modules\WeddingClosingBannerModule::render( [
        'vendor_types'        => $wedding_vendor_types,
        'section_title'       => $cv_wcb_section_title,
        'section_description' => $cv_wcb_section_desc,
    ] );
    if ( $_wcb_html !== '' ) {
        echo '<section class="vs-section gs-wedding-reveal" id="vs-sec-wedding_closing_banner"><div class="vs-wrap" ' . $_sec_wrap_style( 'wedding_closing_banner' ) . '>' . $_wcb_html . '</div></section>';
    }
}
$_vs_sections['wedding_closing_banner'] = ob_get_clean();

// Home Services, module 1 (of a planned multi-module category build)
// — Service Catalogue & Problem Solver. Own data-owning module,
// independent of every other Home Services section still to be built.
ob_start();
if ( $_sec_show( 'home_services_catalogue' ) ) {
    global $wpdb;
    $_hsvc_services = \GoodService\Modules\HomeServicesModule::get_services( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hsvc_html = \GoodService\Modules\HomeServicesCatalogueModule::render( [
        'services'            => $_hsvc_services,
        'section_title'       => $cv_hsvc_section_title,
        'section_description' => $cv_hsvc_section_desc,
        'img_display'         => $cv_hsvc_img,
        'phone'               => $phone,
        'wa_clean'            => $wa_clean,
    ] );
    if ( $_hsvc_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-home_services_catalogue"><div class="vs-wrap" ' . $_sec_wrap_style( 'home_services_catalogue' ) . '>' . $_hsvc_html . '</div></section>';
    }
}
$_vs_sections['home_services_catalogue'] = ob_get_clean();

// Home Services, Module 2 — Packages & Maintenance Plans. Own
// data-owning module (module_key 'home_services_packages'),
// independent of home_services_catalogue.
ob_start();
if ( $_sec_show( 'home_services_packages' ) ) {
    global $wpdb;
    $_hpkg_plans = \GoodService\Modules\HomeServicesPackagesModule::get_plans( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hpkg_html  = \GoodService\Modules\HomeServicesPackagesModule::render( [
        'plans'                => $_hpkg_plans,
        'section_title'        => $cv_hpkg_section_title,
        'section_description'  => $cv_hpkg_section_desc,
        'img_display'          => $cv_hpkg_img,
        'currency'             => \gs_setting( 'currency_symbol', '₹' ),
    ] );
    if ( $_hpkg_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-home_services_packages"><div class="vs-wrap" ' . $_sec_wrap_style( 'home_services_packages' ) . '>' . $_hpkg_html . '</div></section>';
    }
}
$_vs_sections['home_services_packages'] = ob_get_clean();

// Home Services, Module 3 — Technicians & Experts. Own data-owning
// module (module_key 'home_services_technicians'), independent of
// both prior Home Services modules.
ob_start();
if ( $_sec_show( 'home_services_technicians' ) ) {
    global $wpdb;
    $_htech_technicians = \GoodService\Modules\HomeServicesTechniciansModule::get_technicians( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_htech_html = \GoodService\Modules\HomeServicesTechniciansModule::render( [
        'technicians'          => $_htech_technicians,
        'section_title'        => $cv_htech_section_title,
        'section_description'  => $cv_htech_section_desc,
        'img_display'          => $cv_htech_img,
    ] );
    if ( $_htech_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-home_services_technicians"><div class="vs-wrap" ' . $_sec_wrap_style( 'home_services_technicians' ) . '>' . $_htech_html . '</div></section>';
    }
}
$_vs_sections['home_services_technicians'] = ob_get_clean();

// Home Services, Module 4 — License, Insurance & Guarantee. Own
// data-owning module (module_key 'home_services_guarantee'), a flat
// single-record block rather than a repeater — see
// HomeServicesGuaranteeModule's docblock for why this is not a
// duplicate of the universal `why`/`trust_bar` modules.
ob_start();
if ( $_sec_show( 'home_services_guarantee' ) ) {
    global $wpdb;
    $_hgty_data = \GoodService\Modules\HomeServicesGuaranteeModule::get_data( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hgty_html = \GoodService\Modules\HomeServicesGuaranteeModule::render( [
        'data'                 => (array) ( $_hgty_data['data'] ?? [] ),
        'section_title'        => $cv_hgty_section_title,
        'section_description'  => $cv_hgty_section_desc,
    ] );
    if ( $_hgty_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-home_services_guarantee"><div class="vs-wrap" ' . $_sec_wrap_style( 'home_services_guarantee' ) . '>' . $_hgty_html . '</div></section>';
    }
}
$_vs_sections['home_services_guarantee'] = ob_get_clean();

// Home Services, Module 5 — Before & After Work Gallery. Own,
// independently-gated data — not dependent on any other Home Services
// module. Reuses the shared before/after slider engine and lightbox —
// see HomeServicesBeforeAfterModule's own docblock.
ob_start();
if ( $_sec_show( 'home_services_before_after' ) ) {
    global $wpdb;
    $_hba_items = \GoodService\Modules\HomeServicesBeforeAfterModule::get_items( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hba_html = \GoodService\Modules\HomeServicesBeforeAfterModule::render( [
        'items'                => $_hba_items,
        'section_title'        => $cv_hba_section_title,
        'section_description'  => $cv_hba_section_desc,
        'img_display'          => $cv_hba_img,
    ] );
    if ( $_hba_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-home_services_before_after"><div class="vs-wrap" ' . $_sec_wrap_style( 'home_services_before_after' ) . '>' . $_hba_html . '</div></section>';
    }
}
$_vs_sections['home_services_before_after'] = ob_get_clean();

// Health & Wellness, module 2 of 5 — Departments & Specialties.
// Independent gate; fetches both services and doctors data directly.
ob_start();
if ( $_sec_show( 'departments' ) ) {
    global $wpdb;
    $_hw_dept_services = \GoodService\Modules\HealthWellnessModule::get_services( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hw_dept_doctors = \GoodService\Modules\HealthWellnessModule::get_doctors( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hw_dept_html = \GoodService\Modules\DepartmentsModule::render( [
        'dept_defs'             => $cv_hw_dept_defs,
        'services'              => $_hw_dept_services,
        'doctors'               => $_hw_dept_doctors,
        'section_title'         => $cv_hw_dept_section_title,
        'section_description'   => $cv_hw_dept_section_desc,
        'grid_cols'             => $cv_hw_dept_grid_cols,
        'img_display'           => [ 'fit' => $cv_hw_dept_img_fit, 'position' => $cv_hw_dept_img_position, 'zoom' => $cv_hw_dept_img_zoom, 'interval' => $cv_hw_dept_slider_interval, 'popup_fit' => $cv_hw_dept_popup_img_fit ],
    ] );
    if ( $_hw_dept_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-departments"><div class="vs-wrap" ' . $_sec_wrap_style( 'departments' ) . '>' . $_hw_dept_html . '</div></section>';
    }
}
$_vs_sections['departments'] = ob_get_clean();

// Health & Wellness, module 3 of 5 — Doctors & Healthcare
// Professionals. Reads service data directly for the "Available
// Services" cross-reference, independent of Featured Services' own
// activation state.
ob_start();
if ( $_sec_show( 'doctors' ) ) {
    global $wpdb;
    $_hw_doctors = \GoodService\Modules\HealthWellnessModule::get_doctors( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hw_services_for_dr = \GoodService\Modules\HealthWellnessModule::get_services( $wpdb, $wpdb->prefix . 'gs_', $lid );
    $_hw_dr_html = \GoodService\Modules\DoctorsModule::render( [
        'doctors'              => $_hw_doctors,
        'services'              => $_hw_services_for_dr,
        'layout'                => $cv_hw_dr_layout,
        'section_title'         => $cv_hw_dr_section_title,
        'section_description'   => $cv_hw_dr_section_desc,
        'img_display'           => [ 'fit' => $cv_hw_dr_img_fit, 'position' => $cv_hw_dr_img_position, 'zoom' => $cv_hw_dr_img_zoom, 'interval' => $cv_hw_dr_slider_interval, 'popup_fit' => $cv_hw_dr_popup_img_fit ],
        'phone'                 => $phone,
    ] );
    if ( $_hw_dr_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-doctors"><div class="vs-wrap" ' . $_sec_wrap_style( 'doctors' ) . '>' . $_hw_dr_html . '</div></section>';
    }
}
$_vs_sections['doctors'] = ob_get_clean();

// Health & Wellness, module 4 of 5 — Facilities & Patient Experience.
ob_start();
if ( $_sec_show( 'patient_facilities' ) ) {
    global $wpdb;
    $_hw_pf_data = \GoodService\Core\ModuleRegistry::fetch_module_data( $wpdb, $wpdb->prefix . 'gs_', 'patient_facilities', $lid );
    $_hw_pf_html = \GoodService\Modules\PatientFacilitiesModule::render( [
        'facilities'            => $_hw_pf_data['facilities'] ?? [],
        'gallery_images'        => $_hw_pf_data['gallery_images'] ?? [],
        'layout'                => $cv_hw_pf_layout,
        'section_title'         => $cv_hw_pf_section_title,
        'section_description'   => $cv_hw_pf_section_desc,
        'img_display'           => [ 'fit' => $cv_hw_pf_img_fit, 'position' => $cv_hw_pf_img_position, 'zoom' => $cv_hw_pf_img_zoom ],
    ] );
    if ( $_hw_pf_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-patient_facilities"><div class="vs-wrap" ' . $_sec_wrap_style( 'patient_facilities' ) . '>' . $_hw_pf_html . '</div></section>';
    }
}
$_vs_sections['patient_facilities'] = ob_get_clean();

// Health & Wellness, module 5 of 5 — Patient Journey/Treatment
// Process, the final module in this five-module category build.
// Steps are pure vendor-authored configuration with no cross-
// referencing needed, so — like Design Process — they live in
// customizer_data rather than gs_listing_module_data, and no separate
// database fetch is needed here at all.
ob_start();
if ( $_sec_show( 'patient_journey' ) ) {
    $_hw_pj_html = \GoodService\Modules\PatientJourneyModule::render( [
        'steps'                => $cv_hw_pj_steps,
        'layout'                => $cv_hw_pj_layout,
        'section_title'         => $cv_hw_pj_section_title,
        'section_description'   => $cv_hw_pj_section_desc,
    ] );
    if ( $_hw_pj_html !== '' ) {
        echo '<section class="vs-section" id="vs-sec-patient_journey"><div class="vs-wrap" ' . $_sec_wrap_style( 'patient_journey' ) . '>' . $_hw_pj_html . '</div></section>';
    }
}
$_vs_sections['patient_journey'] = ob_get_clean();

// Inquiry Modules section
ob_start();
if ( $_sec_show( 'inquiry_modules' ) && ! empty( $_inq_modules_data ) ) {
    $brand_color = isset( $brand_color ) ? $brand_color : '#2563EB';
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_INQUIRY_MODULES') && GS_USE_MODULE_ENGINE_INQUIRY_MODULES ) ) {
        echo \GoodService\Modules\InquiryModulesModule::render( [
            'inq_modules_data' => $_inq_modules_data,
            'cd' => $cd,
            'primary' => $primary,
            'brand_color' => $brand_color,
            'lid' => $lid,
        ] );
    } else {
        include GS_DIR . 'templates/pages/partials/inquiry-modules.php';
    }
}
$_vs_sections['inquiry_modules'] = ob_get_clean();

// Questions & Answers section
//
// Real fix: this used to be a hardcoded block that always rendered
// immediately after the reorderable-section loop below, with no
// visibility toggle, no position in Section Order, no entry in
// $sec_labels, and no style/content config — reported directly: "should
// work like any other section which we/admin or vendor can hide and
// configure ... so it works similar to other sections properly." Moved
// into the same ob_start()/$_vs_sections buffering every other section
// uses so it now participates in $_sec_order (repositionable) and
// $_sec_show('questions') (hideable via the same per-card toggle create-
// listing.php already uses everywhere else). Content that was previously
// hardcoded (eyebrow, heading, ask-box heading, empty-state text) now
// reads from $hd with the exact old copy as the default, so an existing
// listing that has never touched the new fields renders identically to
// before this fix.
ob_start();
if ( $_sec_show( 'questions' ) && \GoodService\Module\ModuleManager::is_enabled( 'reviews' ) && $primary ) {
    $_qa_pfx = $wpdb->prefix . 'gs_';
    $_qa_items = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, asker_name, question_text, vendor_answer, vendor_answer_at
         FROM {$_qa_pfx}listing_questions
         WHERE listing_id = %d AND status = 'answered'
         ORDER BY vendor_answer_at DESC LIMIT 20",
        $primary->id
    ) );
    $_qa_eyebrow   = $hd['questions_eyebrow']       ?? 'Ask Away';
    $_qa_heading   = $hd['questions_section_title'] ?? 'Questions & Answers';
    $_qa_ask_head  = $hd['questions_ask_heading']   ?? 'Have a question for this business?';
    $_qa_empty_txt = $hd['questions_empty_text']    ?? 'No questions yet — be the first to ask.';
?>
<section class="vs-section" id="vs-sec-questions">
  <div class="vs-wrap" <?php echo $_sec_wrap_style( 'questions' ); ?>>
    <div class="vs-text-center" style="margin-bottom:36px">
      <div class="vs-sec-eyebrow"><?php echo esc_html( $_qa_eyebrow ); ?></div>
      <h2 class="vs-sec-title"><?php echo esc_html( $_qa_heading ); ?></h2>
      <div class="vs-divider" style="margin:16px auto 0"></div>
    </div>
    <?php if ( ! empty( $_qa_items ) ): ?>
    <div class="vs-faq-list">
      <?php foreach ( $_qa_items as $_qa ): ?>
      <div class="vs-faq-item" onclick="this.classList.toggle('on')">
        <div class="vs-faq-q">
          <span>❓ <?php echo esc_html( $_qa->question_text ); ?></span>
          <span class="vs-faq-arrow">▾</span>
        </div>
        <div class="vs-faq-a">
          <strong>Answer:</strong> <?php echo esc_html( $_qa->vendor_answer ); ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div style="text-align:center;color:#8B8D9E;font-size:.88rem;padding:16px 0 8px"><?php echo esc_html( $_qa_empty_txt ); ?></div>
    <?php endif; ?>

    <div style="max-width:560px;margin:28px auto 0;background:#F8FAFC;border-radius:14px;padding:22px">
      <div style="font-weight:700;font-size:.92rem;color:var(--vs-dark,#1E293B);margin-bottom:10px"><?php echo esc_html( $_qa_ask_head ); ?></div>
      <textarea id="vs-qa-text" maxlength="500" placeholder="Ask anything — e.g. do you serve my area, what's included, how long does it take…" style="width:100%;min-height:70px;border:1.5px solid #E2E8F0;border-radius:10px;padding:10px 12px;font-size:.87rem;font-family:inherit;resize:vertical;box-sizing:border-box"></textarea>
      <div style="display:flex;gap:8px;margin-top:10px">
        <input type="text" id="vs-qa-name" placeholder="Your name (optional)" style="flex:1;border:1.5px solid #E2E8F0;border-radius:8px;padding:8px 10px;font-size:.85rem;font-family:inherit;box-sizing:border-box">
        <button type="button" onclick="vsSubmitQuestion(<?php echo (int) $primary->id; ?>)" id="vs-qa-submit-btn" style="background:var(--vs-primary,#2563EB);color:#fff;border:none;border-radius:8px;padding:8px 20px;font-weight:700;font-size:.85rem;cursor:pointer;white-space:nowrap">Ask</button>
      </div>
      <div id="vs-qa-msg" style="font-size:.8rem;margin-top:8px"></div>
    </div>
  </div>
</section>
<script>
var VS_QA_NONCE = '<?php echo esc_js( wp_create_nonce( "gs_ajax" ) ); ?>';
var VS_QA_AJAX_URL = '<?php echo esc_js( admin_url( "admin-ajax.php" ) ); ?>';
function vsSubmitQuestion(listingId) {
  var textEl, nameEl, msgEl, btn;
  try {
    textEl = document.getElementById('vs-qa-text');
    nameEl = document.getElementById('vs-qa-name');
    msgEl  = document.getElementById('vs-qa-msg');
    btn    = document.getElementById('vs-qa-submit-btn');
    if (!textEl || !msgEl || !btn) { return; }
    var text = textEl.value.trim();
    if (text.length < 5) { msgEl.style.color = '#DC2626'; msgEl.textContent = 'Please enter a real question — at least a few words.'; return; }

    btn.disabled = true; btn.textContent = 'Sending…';
    // Real fix — this whole call is self-contained (its own nonce, its
    // own AJAX URL, its own fetch) rather than depending on globals from
    // a separate script block, so nothing outside this function can
    // cause it to hang. A 15s watchdog guarantees the button resets even
    // if the network request itself never settles.
    var settled = false;
    var watchdog = setTimeout(function() {
      if (settled) { return; }
      settled = true;
      btn.disabled = false; btn.textContent = 'Ask';
      msgEl.style.color = '#DC2626'; msgEl.textContent = 'This is taking longer than expected — please try again.';
    }, 15000);

    var fd = new FormData();
    fd.append('action', 'gs_submit_question');
    fd.append('nonce', VS_QA_NONCE);
    fd.append('listing_id', listingId);
    fd.append('question_text', text);
    fd.append('asker_name', nameEl ? nameEl.value.trim() : '');

    fetch(VS_QA_AJAX_URL, { method: 'POST', body: fd })
      .then(function(r){ return r.json(); })
      .then(function(d) {
        if (settled) { return; }
        settled = true; clearTimeout(watchdog);
        btn.disabled = false; btn.textContent = 'Ask';
        if (d && d.success) {
          msgEl.style.color = '#16A34A'; msgEl.textContent = (d.data && d.data.message) || 'Thanks! Your question has been sent.';
          textEl.value = ''; if (nameEl) { nameEl.value = ''; }
        } else {
          msgEl.style.color = '#DC2626'; msgEl.textContent = (d && d.data && d.data.message) || 'Something went wrong — please try again.';
        }
      })
      .catch(function() {
        if (settled) { return; }
        settled = true; clearTimeout(watchdog);
        btn.disabled = false; btn.textContent = 'Ask';
        msgEl.style.color = '#DC2626'; msgEl.textContent = 'Network error — please try again.';
      });
  } catch (e) {
    // Real fix — belt-and-suspenders: even a completely unexpected
    // synchronous error (e.g. a missing element) resets the button
    // rather than leaving it stuck with no explanation.
    if (btn) { btn.disabled = false; btn.textContent = 'Ask'; }
    if (msgEl) { msgEl.style.color = '#DC2626'; msgEl.textContent = 'Something went wrong — please refresh and try again.'; }
  }
}
</script>
<?php
}
$_vs_sections['questions'] = ob_get_clean();
?>


<?php
// Render in configured order, skipping hidden sections
foreach ( $_sec_order as $_sec_key ) {
    if ( ! $_sec_show( $_sec_key ) ) continue;
    if ( ! empty( $_vs_sections[ $_sec_key ] ) ) {
        echo $_vs_sections[ $_sec_key ];
    }
}
?>
<!-- ══ FEEDBACK ═══════════════════════════════════════════════════ -->
<?php
$show_feedback = !empty($fd['show_feedback']);
$fb_title = $fd['feedback_title'] ?? 'Submit Your Feedback';
$fb_sub   = $fd['feedback_subtitle'] ?? 'Rate Your Experience';
if ($show_feedback):
?>
<section class="vs-section" id="vs-sec-feedback">
  <div class="vs-wrap">
    <div class="vs-feedback-wrap">
      <div class="vs-sec-eyebrow">Share Your Experience</div>
      <h2 class="vs-sec-title"><?php echo esc_html($fb_title); ?></h2>
      <p class="vs-sec-sub" style="margin:8px auto"><?php echo esc_html($fb_sub); ?></p>
      <div class="vs-stars-row" id="vs-fb-stars">
        <?php for ($s=1;$s<=5;$s++): ?>
          <span class="vs-star-btn" data-val="<?php echo $s; ?>" onclick="vsSetRating(<?php echo $s; ?>)">★</span>
        <?php endfor; ?>
      </div>
      <div class="vs-feedback-form">
        <input type="text" class="vs-input" id="vs-fb-name" placeholder="Your Name">
        <textarea class="vs-input vs-textarea" id="vs-fb-msg" rows="3" placeholder="Share your experience..."></textarea>
        <input type="hidden" id="vs-fb-rating" value="0">
        <input type="hidden" id="vs-fb-lid" value="<?php echo $lid; ?>">
        <button onclick="vsSubmitFeedback()" class="vs-btn vs-btn-primary" style="width:100%;justify-content:center;margin-top:6px" id="vs-fb-submit">Submit Feedback</button>
        <div id="vs-fb-result" style="display:none;margin-top:10px;font-size:.85rem;text-align:center"></div>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ══ FOOTER ══════════════════════════════════════════════════════ -->
<?php if ( $_sec_show( 'related_listings' ) && ! empty( $related_listings ) ):
    if ( $_gs_all_modules_on || ( defined('GS_USE_MODULE_ENGINE_RELATED_LISTINGS') && GS_USE_MODULE_ENGINE_RELATED_LISTINGS ) ) {
        echo \GoodService\Modules\RelatedListingsModule::render_grid( $related_listings );
    } else { ?>
<section class="vs-related" style="max-width:1100px;margin:0 auto;padding:40px 20px">
  <h2 style="font-size:1.3rem;font-weight:800;margin-bottom:18px">Similar Businesses Near You</h2>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px">
    <?php foreach ( $related_listings as $rl ): ?>
      <a href="<?php echo esc_url( home_url( '/' . $rl->slug . '/' ) ); ?>" style="display:block;text-decoration:none;color:inherit;border:1px solid #E5E7EB;border-radius:12px;padding:14px;transition:box-shadow .15s" onmouseover="this.style.boxShadow='0 4px 14px rgba(0,0,0,.08)'" onmouseout="this.style.boxShadow='none'">
        <?php if ( $rl->logo_url ): ?>
          <img src="<?php echo esc_url( $rl->logo_url ); ?>" alt="<?php echo esc_attr( $rl->title ); ?>" loading="lazy" width="220" height="100" style="width:100%;height:100px;object-fit:cover;border-radius:8px;margin-bottom:10px">
        <?php endif; ?>
        <div style="font-weight:700;font-size:.92rem;margin-bottom:4px"><?php echo esc_html( $rl->title ); ?></div>
        <div style="font-size:.78rem;color:#6B7280"><?php echo esc_html( $rl->city ?: '' ); ?><?php if ( $rl->review_count > 0 ): ?> · ★ <?php echo number_format( (float) $rl->avg_rating, 1 ); ?> (<?php echo (int) $rl->review_count; ?>)<?php endif; ?></div>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php
    }
endif; ?>
<footer class="vs-footer">
  <div class="vs-wrap">
    <div class="vs-footer-grid">

      <!-- Col 1: Brand -->
      <div>
        <?php
          // Real feature: a separate footer logo, configurable per-listing.
          // Falls back to the main site $logo (identical behaviour to
          // before) whenever no footer-specific logo has been set, so this
          // is fully backward-compatible with every listing that hasn't
          // touched the new field.
          $_ftr_logo = $ftd['footer_logo_url'] ?? '';
          $_ftr_logo = $_ftr_logo ?: $logo;
        ?>
        <?php if ($_ftr_logo):
          // Real fix, PageSpeed audit: fixed 44px height here — reuses
          // the real dimensions already fetched for the nav logo (same
          // $logo file) ONLY when the footer is actually using that same
          // file — a distinct footer logo gets its own dimension lookup
          // so its width isn't computed from the wrong image's aspect
          // ratio, avoiding a duplicate getimagesize() call in the common
          // (no override) case.
          $_ftrlogo_dim_w = 0;
          if ( $_ftr_logo === $logo ) {
              if ( ! empty( $_navlogo_dim[0] ) && ! empty( $_navlogo_dim[1] ) ) {
                  $_ftrlogo_dim_w = (int) round( ( $_navlogo_dim[0] / $_navlogo_dim[1] ) * 44 );
              }
          } else {
              $_ftrlogo_dim_cache_key = 'gs_footerlogo_dim_' . md5( $_ftr_logo );
              $_ftrlogo_dim = get_transient( $_ftrlogo_dim_cache_key );
              if ( $_ftrlogo_dim === false ) {
                  $_ftrlogo_dim = @getimagesize( $_ftr_logo ) ?: [ 0, 0 ];
                  set_transient( $_ftrlogo_dim_cache_key, $_ftrlogo_dim, DAY_IN_SECONDS );
              }
              if ( ! empty( $_ftrlogo_dim[0] ) && ! empty( $_ftrlogo_dim[1] ) ) {
                  $_ftrlogo_dim_w = (int) round( ( $_ftrlogo_dim[0] / $_ftrlogo_dim[1] ) * 44 );
              }
          }
        ?>
          <div class="vs-footer-brand"><img src="<?php echo esc_url($_ftr_logo); ?>" alt="<?php echo esc_attr( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?>" loading="lazy" height="44"<?php if($_ftrlogo_dim_w>0): ?> width="<?php echo (int)$_ftrlogo_dim_w; ?>"<?php endif; ?>></div>
        <?php else: ?>
          <div class="vs-footer-brand-init"><?php echo esc_html(strtoupper(substr( gs_vs_safe_brand( $brand, $primary, $vendor ),0,2))); ?></div>
        <?php endif; ?>
        <?php $ft_about = $ftd['footer_about_text'] ?? ($primary && ($primary->full_desc ?: $primary->short_desc) ? wp_trim_words($primary->full_desc ?: $primary->short_desc, 20) : ''); ?>
        <?php if ($ft_about): ?>
        <?php
        // Real fix — Footer About Text now has a full rich-text editor
        // (bold/italic/underline, headings, alignment, lists, links) in
        // the admin form, saving real HTML instead of a plain string.
        // esc_html() would have printed that HTML as literal visible tags
        // ("<strong>Since 2010</strong>" showing up as text) rather than
        // rendering it — the exact "formatting configured in the form
        // must accurately reflect on the public page" requirement. Uses
        // the identical, already-proven wpautop(wp_kses_post()) pattern
        // the platform's own About Description section already uses.
        // Wrapper changed from <p> to <div> because rich content can now
        // legitimately contain block-level elements (headings, lists,
        // multiple paragraphs) that are invalid nested inside a <p> tag.
        ?>
        <div class="vs-footer-about"><?php echo wpautop( wp_kses_post( $ft_about ) ); ?></div>
        <?php endif; ?>
        <?php if (!empty($vendor->social_links)): ?>
          <div class="vs-footer-social">
            <?php $si = ['facebook'=>'🔵','instagram'=>'📸','twitter'=>'🐦','linkedin'=>'💼','youtube'=>'▶️']; ?>
            <?php foreach ($vendor->social_links as $net => $surl): if (!$surl) continue; ?>
              <a href="<?php echo esc_url($surl); ?>" target="_blank" title="<?php echo esc_attr(ucfirst($net)); ?>"><?php echo $si[$net] ?? '🔗'; ?></a>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>

      <!-- Col 2: Services links -->
      <div>
        <div class="vs-footer-col-title">Services</div>
        <?php // Modifier class (base .vs-footer-links class kept for the
              // shared list styling) lets Service Links get typography
              // independent of Quick Links — see the css_rule() calls
              // above for --services vs --quicklinks. ?>
        <ul class="vs-footer-links vs-footer-links--services">
          <?php
          // Real fix: previously always auto-generated from services_data,
          // completely ignoring the vendor's actual footer_service_links
          // field — the real root cause of "footer settings not working."
          // Uses the vendor's explicit text when provided, falling back to
          // the existing auto-generated list for listings that haven't set it.
          $_footer_svc_raw = trim( (string) ( $ftd['footer_service_links'] ?? '' ) );
          if ( $_footer_svc_raw ):
              foreach ( array_filter( array_map( 'trim', explode( "\n", $_footer_svc_raw ) ) ) as $_fsl ):
          ?>
            <li><a href="#vs-sec-services"><?php echo esc_html( $_fsl ); ?></a></li>
          <?php
              endforeach;
          elseif ($primary && !empty($primary->services_data)):
          ?>
            <?php foreach (array_slice($primary->services_data,0,6) as $sv): if (empty($sv['name'])) continue; ?>
              <li><a href="<?php echo esc_url($sv['link'] ?? '#vs-sec-services'); ?>"><?php echo esc_html($sv['name']); ?></a></li>
            <?php endforeach; ?>
          <?php endif; ?>
        </ul>
      </div>

      <!-- Col 3: Footer links -->
      <div>
        <div class="vs-footer-col-title">Quick Links</div>
        <ul class="vs-footer-links vs-footer-links--quicklinks">
          <?php
          // Real fix: previously read a completely different, unrelated
          // key (footer_links) that the form never actually wrote to at
          // all — the vendor's real footer_quick_links field (format:
          // "Label|URL" per line, confirmed directly from the form) was
          // silently ignored. Falls back to the old key for any listing
          // that might have data there from a different source.
          $_footer_ql_raw = trim( (string) ( $ftd['footer_quick_links'] ?? '' ) );
          $fl = [];
          if ( $_footer_ql_raw ) {
              foreach ( array_filter( array_map( 'trim', explode( "\n", $_footer_ql_raw ) ) ) as $_line ) {
                  $_parts = array_map( 'trim', explode( '|', $_line, 2 ) );
                  if ( ! empty( $_parts[0] ) ) {
                      $fl[] = [ 'text' => $_parts[0], 'url' => $_parts[1] ?? '#' ];
                  }
              }
          } else {
              $fl = $ftd['footer_links'] ?? [];
          }
          foreach ($fl as $flitem): if (empty($flitem['text'])) continue; ?>
            <li><a href="<?php echo esc_url($flitem['url'] ?? '#'); ?>"><?php echo esc_html($flitem['text']); ?></a></li>
          <?php endforeach; ?>
          <li><a href="#vs-sec-contact">Contact Us</a></li>
        </ul>
      </div>

      <!-- Col 4: Contact + newsletter -->
      <div>
        <div class="vs-footer-col-title">Contact Us</div>
        <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:20px">
          <?php if ($phone): ?><div style="font-size:.83rem">📞 <?php echo esc_html($phone); ?></div><?php endif; ?>
          <?php if ($email): ?><div style="font-size:.83rem">📧 <?php echo esc_html($email); ?></div><?php endif; ?>
          <?php if ($city): ?><div style="font-size:.83rem">📍 <?php echo esc_html($city); ?></div><?php endif; ?>
        </div>
        <?php if (!empty($ftd['show_newsletter'])): ?>
          <div class="vs-footer-col-title">Subscribe</div>
          <div class="vs-footer-nl">
            <input type="email" id="vs-nl-email" placeholder="<?php echo esc_attr($ftd['newsletter_placeholder'] ?? 'Enter your email...'); ?>">
            <button onclick="vsSubmitNewsletter()">Go</button>
          </div>
          <div id="vs-nl-msg" style="display:none;font-size:.75rem;margin-top:6px"></div>
        <?php endif; ?>
      </div>

    </div>

    <div class="vs-footer-bottom">
      <div>Copyright &copy; <?php echo date('Y'); ?> All Rights Reserved.</div>
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
        <!-- Share buttons -->
        <?php
        // FIXED: get_permalink() depends on a real WP post/page context. This
        // platform is "zero WP post dependency" — the $post global at render
        // time is a synthetic Yellow-Pencil CSS-scoping post shared across ALL
        // vendor sites (see Router.php "template" scope), so get_permalink()
        // here always returned the SAME wrong URL for every listing instead of
        // this listing's own page. Use the canonical-URL pattern already used
        // elsewhere on this page / in Router.php's OG tags instead.
        $share_url    = ! empty( $primary->slug )
            ? esc_url( home_url( '/' . ltrim( $primary->slug, '/' ) . '/' ) )
            : esc_url( home_url( '/' ) );
        $_share_brand = gs_vs_safe_brand( $brand, $primary, $vendor );
        $share_title = esc_attr( $_share_brand . ' — ' . ( $primary->tagline ?? get_bloginfo('name') ) );
        $wa_share    = rawurlencode( $_share_brand . ' — Check them out: ' . $share_url );
        ?>
        <span style="font-size:.72rem;color:rgba(255,255,255,.4);font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin-right:4px">Share</span>
        <a href="https://wa.me/?text=<?php echo $wa_share; ?>" target="_blank" rel="noopener" class="vs-share-btn" style="background:#25D366;color:#fff;padding:5px 11px" title="Share on WhatsApp" aria-label="Share on WhatsApp">💬</a>
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo rawurlencode($share_url); ?>" target="_blank" rel="noopener" class="vs-share-btn" style="background:#1877F2;color:#fff;padding:5px 11px" title="Share on Facebook" aria-label="Share on Facebook">f</a>
        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo rawurlencode($share_url); ?>" target="_blank" rel="noopener" class="vs-share-btn" style="background:#0077B5;color:#fff;padding:5px 11px" title="Share on LinkedIn" aria-label="Share on LinkedIn">in</a>
        <a href="https://twitter.com/intent/tweet?url=<?php echo rawurlencode($share_url); ?>&text=<?php echo rawurlencode($_share_brand); ?>" target="_blank" rel="noopener" class="vs-share-btn" style="background:#1DA1F2;color:#fff;padding:5px 11px" title="Share on X/Twitter" aria-label="Share on Twitter">𝕏</a>
        <button onclick="navigator.clipboard.writeText('<?php echo esc_js($share_url); ?>').then(function(){var t=this;t.textContent='✅';setTimeout(function(){t.textContent='🔗'},2000);}.bind(this)).catch(function(){})" class="vs-share-btn" style="background:rgba(255,255,255,.16);color:#fff;padding:5px 11px" title="Copy link" aria-label="Copy link">🔗</button>
      </div>
      <div>Design &amp; Maintain By <a href="https://good-service.in" target="_blank" style="color:rgba(255,255,255,.7);font-weight:600">Good-Service.In</a></div>
    </div>
  </div>
</footer>

<!-- ══ SHARE — floating desktop side panel (reuses the same fixed $share_url as the footer share bar above; no duplicate URL logic) ══ -->
<?php if ( ! empty( $share_url ) ): ?>
<div class="vs-share-rail" id="vs-share-rail" aria-label="Share this listing">
  <span class="vs-share-rail-label">Share</span>
  <span class="vs-share-rail-div"></span>
  <a href="https://wa.me/?text=<?php echo $wa_share; ?>" target="_blank" rel="noopener" class="vs-share-rail-btn" style="background:#25D366" title="Share on WhatsApp" aria-label="Share on WhatsApp"><svg viewBox="0 0 24 24" width="17" height="17" fill="#fff" aria-hidden="true"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.39 1.26 4.81L2.05 22l5.44-1.31c1.36.71 2.9 1.12 4.55 1.12 5.46 0 9.91-4.45 9.91-9.91C21.95 6.45 17.5 2 12.04 2zm5.8 14.05c-.24.68-1.4 1.3-1.93 1.35-.5.05-1.02.24-3.44-.72-2.9-1.16-4.77-4.09-4.92-4.28-.15-.19-1.17-1.56-1.17-2.98 0-1.42.75-2.11 1.02-2.4.27-.29.58-.36.78-.36.19 0 .39.002.56.01.18.008.42-.07.66.5.24.58.83 2 .9 2.15.07.15.12.33.02.52-.1.19-.15.31-.3.48-.15.17-.31.38-.44.51-.15.15-.3.31-.13.6.17.29.75 1.24 1.62 2.01 1.11.99 2.05 1.3 2.34 1.45.29.15.46.13.63-.08.17-.21.72-.84.91-1.13.19-.29.38-.24.64-.14.26.1 1.65.78 1.94.92.29.14.48.21.55.33.08.12.08.68-.16 1.36z"/></svg></a>
  <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo rawurlencode( $share_url ); ?>" target="_blank" rel="noopener" class="vs-share-rail-btn" style="background:#0866FF" title="Share on Facebook" aria-label="Share on Facebook"><svg viewBox="0 0 24 24" width="15" height="15" fill="#fff" aria-hidden="true"><path d="M22 12.06C22 6.51 17.52 2 12 2S2 6.51 2 12.06C2 17.08 5.66 21.23 10.44 22v-7.03H7.9v-2.91h2.54V9.85c0-2.51 1.49-3.9 3.77-3.9 1.09 0 2.24.2 2.24.2v2.47h-1.26c-1.24 0-1.63.78-1.63 1.57v1.88h2.78l-.44 2.91h-2.34V22C18.34 21.23 22 17.08 22 12.06z"/></svg></a>
  <a href="https://twitter.com/intent/tweet?url=<?php echo rawurlencode( $share_url ); ?>&text=<?php echo rawurlencode( $_share_brand ); ?>" target="_blank" rel="noopener" class="vs-share-rail-btn" style="background:#000" title="Share on X" aria-label="Share on X"><svg viewBox="0 0 24 24" width="15" height="15" fill="#fff" aria-hidden="true"><path d="M18.9 2H22l-7.6 8.7L23.3 22h-7l-5.5-7.2L4.5 22H1.4l8.1-9.3L1 2h7.2l5 6.6L18.9 2zm-1.2 18h1.7L6.4 3.9H4.6L17.7 20z"/></svg></a>
  <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo rawurlencode( $share_url ); ?>" target="_blank" rel="noopener" class="vs-share-rail-btn" style="background:#0A66C2" title="Share on LinkedIn" aria-label="Share on LinkedIn"><svg viewBox="0 0 24 24" width="15" height="15" fill="#fff" aria-hidden="true"><path d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.34V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.38-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.07 2.07 0 1 1 0-4.13 2.07 2.07 0 0 1 0 4.13zM7.12 20.45H3.56V9h3.56v11.45z"/></svg></a>
  <span class="vs-share-rail-div"></span>
  <button type="button" class="vs-share-rail-btn vs-share-rail-copy" onclick="vsShareRailCopy(this,'<?php echo esc_js( $share_url ); ?>')" title="Copy link" aria-label="Copy listing link"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" class="vs-share-rail-icon"><path d="M10 13a5 5 0 0 0 7.07 0l2.83-2.83a5 5 0 0 0-7.07-7.07L11.5 4.5"/><path d="M14 11a5 5 0 0 0-7.07 0L4.1 13.83a5 5 0 0 0 7.07 7.07l1.36-1.36"/></svg><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" class="vs-share-rail-check"><polyline points="20 6 9 17 4 12"/></svg></button>
</div>
<style>
.vs-share-rail{position:fixed;left:20px;top:50%;transform:translateY(-50%);z-index:8970;display:flex;flex-direction:column;align-items:center;gap:10px;background:#fff;padding:16px 10px;border-radius:18px;box-shadow:0 4px 10px rgba(15,23,42,.06),0 16px 40px rgba(15,23,42,.14);border:1px solid rgba(15,23,42,.07)}
.vs-share-rail-label{font-size:.66rem;font-weight:800;text-transform:uppercase;letter-spacing:.12em;color:#475569;margin-bottom:2px;writing-mode:vertical-rl;transform:rotate(180deg)}
.vs-share-rail-div{width:22px;height:1px;background:rgba(15,23,42,.09);flex-shrink:0}
.vs-share-rail-btn{width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:1rem;text-decoration:none;border:none;cursor:pointer;transition:transform .18s cubic-bezier(.34,1.56,.64,1),box-shadow .18s;box-shadow:0 2px 6px rgba(15,23,42,.15)}
.vs-share-rail-btn:hover,.vs-share-rail-btn:focus-visible{transform:scale(1.14);box-shadow:0 6px 16px rgba(15,23,42,.28)}
.vs-share-rail-btn:focus-visible{outline:2px solid #2563EB;outline-offset:2px}
.vs-share-rail-copy{background:linear-gradient(135deg,#334155,#1e293b)}
.vs-share-rail-copy.copied{background:linear-gradient(135deg,#16A34A,#15803D)}
.vs-share-rail-check{display:none}
.vs-share-rail-copy.copied .vs-share-rail-icon{display:none}
.vs-share-rail-copy.copied .vs-share-rail-check{display:block}
@media(max-width:992px){ .vs-share-rail{display:none} } /* desktop-only, as requested — mobile keeps the footer share bar */
@media(prefers-color-scheme:dark){
  .vs-share-rail{background:#1e293b;border-color:rgba(255,255,255,.08);box-shadow:0 4px 10px rgba(0,0,0,.3),0 16px 40px rgba(0,0,0,.4)}
  .vs-share-rail-label{color:#cbd5e1}
  .vs-share-rail-div{background:rgba(255,255,255,.12)}
}
</style>
<script>
function vsShareRailCopy(btn, url){
  if (!navigator.clipboard) return;
  navigator.clipboard.writeText(url).then(function(){
    btn.classList.add('copied');
    setTimeout(function(){ btn.classList.remove('copied'); }, 2000);
  }).catch(function(){});
}
</script>
<?php endif; ?>

<!-- ══ ENQUIRY / QUOTE MODAL — generic lead-capture popup (gs_submit_lead → wp_gs_leads), always available; not gated by the premium Inquiry Modules plan flag ══ -->
<?php if ( $_can_lead_popup ): ?>
<div class="vs-inq-overlay" id="vs-inq-overlay" role="dialog" aria-modal="true" aria-labelledby="vs-inq-title" onclick="if(event.target===this)vsCloseInquiry()">
  <div class="vs-inq-modal">
    <div class="vs-inq-header">
      <button class="vs-inq-close" onclick="vsCloseInquiry()" aria-label="Close enquiry form">✕</button>
      <div class="vs-inq-header-top">
        <div class="vs-inq-icon-wrap" id="vs-inq-icon">📋</div>
        <div style="flex:1;min-width:0">
          <div class="vs-inq-title" id="vs-inq-title">Send Enquiry</div>
          <div class="vs-inq-sub">to <strong><?php echo esc_html( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?></strong> · We respond within 24 hrs</div>
        </div>
      </div>
      <div id="vs-inq-badge" class="vs-inq-badge" style="display:none"></div>
    </div>
    <div class="vs-inq-body">
      <input type="hidden" id="vs-inq-lid"    value="<?php echo $lid; ?>">
      <input type="hidden" id="vs-inq-iname"  value="">
      <input type="hidden" id="vs-inq-iprice" value="">
      <input type="hidden" id="vs-inq-itype"  value="">
      <div class="vs-inq-row">
        <div>
          <label class="vs-inq-lbl" for="vs-inq-name">Full Name <span style="color:#EF4444" aria-hidden="true">*</span></label>
          <input type="text" class="vs-input" id="vs-inq-name" placeholder="Your full name" autocomplete="name" aria-required="true">
        </div>
        <div>
          <label class="vs-inq-lbl" for="vs-inq-phone">Phone Number <span style="color:#EF4444" aria-hidden="true">*</span></label>
          <input type="tel" class="vs-input" id="vs-inq-phone" placeholder="+91 98765 43210" autocomplete="tel" aria-required="true">
        </div>
      </div>
      <div class="vs-inq-row">
        <div>
          <label class="vs-inq-lbl" for="vs-inq-email">Email Address</label>
          <input type="email" class="vs-input" id="vs-inq-email" placeholder="you@email.com" autocomplete="email">
        </div>
        <div>
          <label class="vs-inq-lbl" for="vs-inq-city">City <span style="color:#EF4444" aria-hidden="true">*</span></label>
          <input type="text" class="vs-input" id="vs-inq-city" placeholder="Your city" aria-required="true">
        </div>
      </div>
      <div class="vs-inq-row" id="vs-inq-qty-row" style="display:none">
        <div>
          <label class="vs-inq-lbl" for="vs-inq-qty">Quantity Required</label>
          <input type="number" class="vs-input" id="vs-inq-qty" placeholder="e.g. 10" min="1">
        </div>
        <div>
          <label class="vs-inq-lbl" for="vs-inq-pdate">Preferred Purchase Date</label>
          <input type="date" class="vs-input" id="vs-inq-pdate">
        </div>
      </div>
      <div style="margin-bottom:13px">
        <label class="vs-inq-lbl" for="vs-inq-cdate">Preferred Callback Time</label>
        <input type="datetime-local" class="vs-input" id="vs-inq-cdate">
      </div>
      <div style="margin-bottom:4px">
        <label class="vs-inq-lbl" for="vs-inq-remarks">Requirements / Message</label>
        <textarea class="vs-input vs-textarea" id="vs-inq-remarks" rows="3"
          placeholder="Describe your requirement, budget, or timeline…"></textarea>
      </div>
      <button onclick="vsSubmitInquiry()" class="vs-inq-submit-btn" id="vs-inq-submit">
        <span aria-hidden="true">📤</span><span id="vs-inq-submit-txt">Send Enquiry</span>
      </button>
      <div id="vs-inq-msg" role="alert" style="display:none;margin-top:10px;font-size:.84rem;text-align:center;padding:10px 14px;border-radius:8px"></div>
      <?php
      $privacy_url = get_privacy_policy_url();
      ?>
      <div style="margin-top:10px;display:flex;align-items:flex-start;gap:8px">
        <input type="checkbox" id="vs-inq-consent" required style="margin-top:2px;flex-shrink:0">
        <label for="vs-inq-consent" style="font-size:.72rem;color:#64748B;line-height:1.4;cursor:pointer">
          I agree that my contact details will be shared with <?php echo esc_html( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?> to process my enquiry.
          <?php if ( $privacy_url ): ?><a href="<?php echo esc_url($privacy_url); ?>" target="_blank" style="color:#2563EB">Privacy Policy</a>.<?php endif; ?>
        </label>
      </div>
      <p class="vs-privacy"><span>🔒</span> Shared only with <?php echo esc_html( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?></p>
    </div>
  </div>
</div>
<?php endif; /* $_can_lead_popup */ ?>

<!-- ══ LIGHTBOX ═══════════════════════════════════════════════════ -->
<div id="vs-lightbox" onclick="if(event.target===this)vsCloseLightbox()">
  <button id="vs-lb-prev" onclick="event.stopPropagation();vsLightboxNav(-1)" aria-label="Previous image" style="position:absolute;left:16px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.5);color:#fff;border:none;width:48px;height:48px;border-radius:50%;font-size:1.6rem;cursor:pointer;z-index:2;display:flex;align-items:center;justify-content:center">‹</button>
  <img id="vs-lb-img" src="" alt="lightbox">
  <button id="vs-lb-next" onclick="event.stopPropagation();vsLightboxNav(1)" aria-label="Next image" style="position:absolute;right:16px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.5);color:#fff;border:none;width:48px;height:48px;border-radius:50%;font-size:1.6rem;cursor:pointer;z-index:2;display:flex;align-items:center;justify-content:center">›</button>
  <button onclick="event.stopPropagation();vsCloseLightbox()" aria-label="Close" style="position:absolute;top:16px;right:16px;background:rgba(0,0,0,.5);color:#fff;border:none;width:40px;height:40px;border-radius:50%;font-size:1.3rem;cursor:pointer;z-index:2">✕</button>
  <div id="vs-lb-counter" style="position:absolute;top:16px;left:16px;background:rgba(0,0,0,.5);color:#fff;border-radius:14px;padding:4px 14px;font-size:.8rem;pointer-events:none"></div>
  <div id="vs-lb-cap" style="display:none;position:absolute;bottom:28px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.7);color:#fff;border-radius:8px;padding:8px 18px;font-size:.85rem;max-width:80vw;text-align:center;pointer-events:none"></div>
</div>

<!-- ══ SCRIPTS ════════════════════════════════════════════════════ -->
<script>
(function(){
var AJX='<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
var NONCE='<?php echo esc_js( wp_create_nonce("gs_ajax") ); ?>';
// Expose AJX and NONCE on window so the inquiry-modules partial (loaded in a
// separate script block) can read them. Without this, NONCE is trapped in the
// IIFE closure and typeof NONCE === 'undefined' in other script blocks,
// causing every inquiry form submission to return "Security check failed."
window.AJX   = AJX;
window.NONCE = NONCE;
var LID=<?php echo $lid; ?>;
// Real root-cause fix — LID was declared inside this IIFE without being
// exposed on window, exactly the same bug already fixed for NONCE/AJX
// above (same comment explains it: trapped in the closure, undefined in
// any other script block). Every function reading window.LID — the
// Service/Product wizard triggers and their listing-id fallback — was
// silently getting 0 as a result, causing both the "Could not load time
// slots" and "Invalid Listing" errors. Packages was unaffected because it
// gets its listing_id from a server-embedded PHP value baked directly
// into data-pkg, never touching window.LID at all.
window.LID = LID;
window.GS_SVC_WIZARD_ENABLED = <?php echo ( $cd['services_booking_wizard'] ?? 1 ) ? 'true' : 'false'; ?>;
window.GS_PROD_WIZARD_ENABLED = <?php echo ( $cd['items_booking_wizard'] ?? 1 ) ? 'true' : 'false'; ?>;
window.GS_WIZ_TEXT = {
  packages: <?php echo wp_json_encode( is_array( $cd['wizard_text_packages'] ?? null ) ? array_filter( $cd['wizard_text_packages'] ) : new stdClass() ); ?>,
  service: <?php echo wp_json_encode( is_array( $cd['wizard_text_services'] ?? null ) ? array_filter( $cd['wizard_text_services'] ) : new stdClass() ); ?>,
  product: <?php echo wp_json_encode( is_array( $cd['wizard_text_products'] ?? null ) ? array_filter( $cd['wizard_text_products'] ) : new stdClass() ); ?>
};

/* Geolocation handler removed */


/* ── Inquiry modal ─────────────────────────────── */
/* vsOpenQuote: called by product card "Get Quote" buttons — bridges to the full inquiry modal */
/* vsOpenSvcEnquiry — called by Service card "Enquire" buttons.
   Receives plain string args so onclick="vsOpenSvcEnquiry('...')" 
   never has double-quote conflicts in HTML attributes. */
var _vsInqHdrGen = <?php echo wp_json_encode($cv_popup_header_bg); ?>;
var _vsInqHdrSvc = <?php echo wp_json_encode($cv_popup_svc_hdr_bg); ?>;
var _vsInqHdrPrd = <?php echo wp_json_encode($cv_popup_prd_hdr_bg); ?>;
// ═══════════════════════════════════════════════════════════════════════════
// View More Detail Popup — real feature per explicit request: renders the
// structured content a vendor built in the listing form's detail builder.
// Built dynamically on first use (same "build once, reuse" pattern as the
// rest of this file's modals) rather than server-rendering a hidden popup
// per card — with potentially many service/product cards on one page, a
// single shared popup populated on click is far lighter than N pre-built
// hidden popups.
// ═══════════════════════════════════════════════════════════════════════════
function vsBuildDetailPopup() {
  var existing = document.getElementById('vs-detail-popup');
  if (existing) return existing;
  var overlay = document.createElement('div');
  overlay.id = 'vs-detail-popup';
  overlay.className = 'vs-dp-overlay';
  overlay.onclick = function(e) { if (e.target === overlay) vsCloseDetailPopup(); };
  overlay.innerHTML =
    '<div class="vs-dp-sheet">' +
      '<div class="vs-dp-header">' +
        '<div class="vs-dp-header-title" id="vs-dp-title"></div>' +
        '<button type="button" class="vs-dp-close" onclick="vsCloseDetailPopup()" aria-label="Close">&#10005;</button>' +
      '</div>' +
      '<div class="vs-dp-body" id="vs-dp-body"></div>' +
      '<div class="vs-dp-cta" id="vs-dp-cta"></div>' +
    '</div>';
  document.body.appendChild(overlay);
  return overlay;
}

// Auto-hides a section entirely if it has no real content — per explicit
// request ("hide empty sections automatically") — rather than rendering a
// heading with nothing under it.
function vsSectionHasContent(sec) {
  if (sec.content_type === 'reviews') return !!sec.listing_id;
  if (sec.body && sec.body.replace(/<[^>]*>/g, '').trim()) return true;
  if (sec.faq_items && sec.faq_items.some(function(f){ return f.q || f.a; })) return true;
  if (sec.spec_items && sec.spec_items.some(function(s){ return s.name || s.value; })) return true;
  if (sec.list_items && sec.list_items.length) return true;
  if (sec.images && sec.images.length) return true;
  if (sec.documents && sec.documents.length) return true;
  return false;
}

// Real feature — reusable platform-level image/slider component for
// the shared detail popup, built once and used by every section that
// calls vsOpenDetailPopup (Products & Services, Services, Packages,
// and any future section), rather than a one-off fix for a single
// popup. One image renders exactly as the existing .vs-dp-hero markup
// always has (genuinely zero change for the common case, matching
// this session's own "don't disturb what already works" standard);
// multiple images get a real slider. Every image, in both modes, is
// clickable to open the platform's own existing, already-proven
// vsLightbox() — not a new lightbox built to duplicate it. vsLightbox
// itself already correctly hides prev/next/counter chrome for a
// single-image grid, so that requirement needed no new code at all.
function vsRenderPopupImageArea(images, imgFit, title) {
  images = (images || []).filter(Boolean);
  if (!images.length) { return ''; }
  var fit = ['cover','contain','fill','scale-down','none'].indexOf(imgFit) !== -1 ? imgFit : 'cover';
  var imgStyle = 'object-fit:' + fit + ';';
  var altText = vsEsc(title || '');

  if (images.length === 1) {
    return '<div class="vs-dp-hero" id="vs-dp-img-area">' +
      '<img src="' + images[0] + '" alt="' + altText + '" loading="lazy" style="' + imgStyle + '" onclick="vsLightbox(\'' + images[0] + '\',\'\',\'vs-dp-img-area\')">' +
      '</div>';
  }

  var slidesHtml = images.map(function(url) {
    return '<img src="' + url + '" alt="' + altText + '" loading="lazy" style="' + imgStyle + '" onclick="vsLightbox(\'' + url + '\',\'\',\'vs-dp-img-area\')">';
  }).join('');
  // Real fix — a row of individual dots has no bound on width and
  // would overflow a large gallery's fixed-width popup with no
  // wrapping or scrolling, breaking the layout exactly the way the
  // requirement's own "large image galleries" case warns against.
  // Past 8 images, a compact "N / Total" counter is used instead,
  // which stays a fixed size regardless of how many images there are.
  var useDots = images.length <= 8;
  var navHtml = useDots
    ? '<div class="vs-dp-slider-dots" id="vs-dp-slider-dots">' + images.map(function(url, i) {
        return '<button type="button" class="vs-dp-slider-dot' + (i === 0 ? ' active' : '') + '" onclick="event.stopPropagation();vsPopupSliderGoto(' + i + ');vsPopupSliderRestartAuto()" aria-label="Image ' + (i + 1) + '"></button>';
      }).join('') + '</div>'
    : '<div class="vs-dp-slider-counter" id="vs-dp-slider-counter">1 / ' + images.length + '</div>';

  return '<div class="vs-dp-slider" id="vs-dp-img-area">' +
    '<div class="vs-dp-slider-track" id="vs-dp-slider-track">' + slidesHtml + '</div>' +
    '<button type="button" class="vs-dp-slider-arrow vs-dp-slider-prev" onclick="event.stopPropagation();vsPopupSliderNav(-1)" aria-label="Previous image">‹</button>' +
    '<button type="button" class="vs-dp-slider-arrow vs-dp-slider-next" onclick="event.stopPropagation();vsPopupSliderNav(1)" aria-label="Next image">›</button>' +
    navHtml +
  '</div>';
}

window.vsPopupSliderIndex = 0;
window.vsPopupSliderCount = 0;
window.vsPopupSliderTimer = null;
window.vsPopupSliderGoto = function(idx) {
  var track = document.getElementById('vs-dp-slider-track');
  if (!track) return;
  window.vsPopupSliderIndex = ((idx % window.vsPopupSliderCount) + window.vsPopupSliderCount) % window.vsPopupSliderCount;
  track.style.transform = 'translateX(-' + (window.vsPopupSliderIndex * 100) + '%)';
  document.querySelectorAll('#vs-dp-slider-dots .vs-dp-slider-dot').forEach(function(dot, i) {
    dot.classList.toggle('active', i === window.vsPopupSliderIndex);
  });
  var counter = document.getElementById('vs-dp-slider-counter');
  if (counter) { counter.textContent = (window.vsPopupSliderIndex + 1) + ' / ' + window.vsPopupSliderCount; }
};
window.vsPopupSliderNav = function(dir) {
  vsPopupSliderGoto(window.vsPopupSliderIndex + dir);
  // Real feature — manual navigation resets the auto-advance clock,
  // so clicking to the next image doesn't get immediately followed
  // by another automatic advance a moment later.
  vsPopupSliderRestartAuto();
};
// Real feature — auto-advance with a configurable interval, per the
// explicit requirement this was missing entirely. Stored separately
// from the interval value itself so start/stop/restart can be called
// without needing to know or re-pass the configured interval each time.
window.vsPopupSliderIntervalMs = 0;
window.vsPopupSliderStartAuto = function(intervalMs) {
  vsPopupSliderStopAuto();
  window.vsPopupSliderIntervalMs = intervalMs || 0;
  if (window.vsPopupSliderIntervalMs > 0 && window.vsPopupSliderCount > 1) {
    window.vsPopupSliderTimer = setInterval(function() {
      vsPopupSliderGoto(window.vsPopupSliderIndex + 1);
    }, window.vsPopupSliderIntervalMs);
  }
};
window.vsPopupSliderStopAuto = function() {
  if (window.vsPopupSliderTimer) { clearInterval(window.vsPopupSliderTimer); window.vsPopupSliderTimer = null; }
};
window.vsPopupSliderRestartAuto = function() {
  vsPopupSliderStartAuto(window.vsPopupSliderIntervalMs);
};
// Real fix — touch swipe navigation for the popup slider, confirmed
// genuinely missing (every existing touchstart/touchend listener on
// the platform belongs to the lightbox or an unrelated component, not
// this one) against the explicit "work smoothly on both desktop and
// mobile" requirement. Delegated on document rather than attached
// directly to the track, since the track is destroyed and rebuilt
// every time the popup opens/closes — a direct listener would need
// re-attaching each time and risk being silently lost.
(function(){
  var startX = 0, startY = 0, tracking = false;
  document.addEventListener('touchstart', function(e){
    var track = e.target.closest && e.target.closest('.vs-dp-slider-track');
    if (!track) { tracking = false; return; }
    tracking = true;
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
  }, { passive: true });
  document.addEventListener('touchend', function(e){
    if (!tracking) return;
    tracking = false;
    var dx = (e.changedTouches[0].clientX - startX);
    var dy = (e.changedTouches[0].clientY - startY);
    // Ignore mostly-vertical swipes (scrolling the popup) so this
    // doesn't fight the popup's own vertical scroll on a tall body.
    if (Math.abs(dx) < 40 || Math.abs(dx) < Math.abs(dy)) return;
    vsPopupSliderNav(dx < 0 ? 1 : -1);
  }, { passive: true });
})();

function vsRenderDetailSection(sec) {
  if (!vsSectionHasContent(sec)) return '';
  var headHtml = sec.show_title === false ? '' : '<div class="vs-dp-sec-head"><span class="vs-dp-sec-icon">' + (sec.icon || '📋') + '</span><h3>' + vsEsc(sec.title || '') + '</h3></div>';
  var spacingMap = { compact: '10px', normal: '22px', spacious: '38px' };
  var vGap = spacingMap[sec.spacing] || spacingMap.normal;
  var sectionStyle = '--vs-dp-gap:' + vGap + ';';
  if (sec.bg_color) { sectionStyle += 'background:' + sec.bg_color + ';border-radius:12px;padding:18px;'; }
  if (sec.full_width) { sectionStyle += 'margin-left:-22px;margin-right:-22px;padding-left:22px;padding-right:22px;'; }
  var html = '<div class="vs-dp-section" style="' + sectionStyle + '">' + headHtml + '<div class="vs-dp-sec-body">';

  switch (sec.content_type) {
    case 'faq':
    case 'accordion':
      html += '<div class="vs-dp-accordion">';
      (sec.faq_items || []).forEach(function(item, i) {
        if (!item.q && !item.a) return;
        html += '<div class="vs-dp-acc-item">' +
          '<button type="button" class="vs-dp-acc-q" onclick="this.parentElement.classList.toggle(\'open\')">' + vsEsc(item.q || '') + '<span class="vs-dp-acc-arrow">&#9660;</span></button>' +
          '<div class="vs-dp-acc-a">' + vsEsc(item.a || '') + '</div>' +
        '</div>';
      });
      html += '</div>';
      break;

    case 'list':
      html += '<ul class="vs-dp-list">' + (sec.list_items || []).map(function(li){ return '<li>' + vsEsc(li) + '</li>'; }).join('') + '</ul>';
      break;

    case 'numbered_list':
      html += '<ol class="vs-dp-list">' + (sec.list_items || []).map(function(li){ return '<li>' + vsEsc(li) + '</li>'; }).join('') + '</ol>';
      break;

    case 'table':
      html += '<table class="vs-dp-table"><tbody>';
      (sec.list_items || []).forEach(function(row) {
        var cells = row.split('|').map(function(c){ return c.trim(); });
        html += '<tr>' + cells.map(function(c){ return '<td>' + vsEsc(c) + '</td>'; }).join('') + '</tr>';
      });
      html += '</tbody></table>';
      break;

    case 'specs':
      // Real feature — Specifications/Features table, explicitly
      // requested: always a clean two-column Name → Value layout (the
      // shaded left column matches the requested screenshot), built
      // from sec.spec_items rather than the freeform pipe-delimited
      // rows the 'table' case above uses. Long/multi-line values wrap
      // naturally (no fixed height, no truncation) and the table sits
      // inside the same overflow-safe .vs-dp-sec-body wrapper every
      // other section type here already uses, so it can never cause
      // horizontal overflow on mobile.
      html += '<div class="vs-dp-specs-wrap"><table class="vs-dp-specs-table"><tbody>';
      (sec.spec_items || []).forEach(function(s) {
        if (!s.name && !s.value) return;
        var _specValLines = (s.value || '').split('\n').map(function(l){ return vsEsc(l); }).join('<br>');
        html += '<tr><td class="vs-dp-specs-name">' + vsEsc(s.name || '') + '</td><td class="vs-dp-specs-value">' + _specValLines + '</td></tr>';
      });
      html += '</tbody></table></div>';
      break;

    case 'cards':
      var colCount = sec.columns || 3;
      html += '<div class="vs-dp-cards" style="grid-template-columns:repeat(' + colCount + ',1fr)">';
      (sec.list_items || []).forEach(function(item) {
        var parts = (item || '').split('||');
        if (!parts[1] && !parts[2]) return;
        html += '<div class="vs-dp-card"><div class="vs-dp-card-icon">' + vsEsc(parts[0]||'📌') + '</div><div class="vs-dp-card-title">' + vsEsc(parts[1]||'') + '</div><div class="vs-dp-card-text">' + vsEsc(parts[2]||'') + '</div></div>';
      });
      html += '</div>';
      break;

    case 'gallery':
      html += '<div class="vs-dp-gallery">' + (sec.images || []).map(function(url, idx){ return '<img src="' + url + '" alt="' + vsEsc((sec.title || 'Gallery') + ' photo ' + (idx + 1)) + '" loading="lazy" width="110" height="100" onclick="window.open(this.src,\'_blank\')">'; }).join('') + '</div>';
      break;

    case 'highlight':
      html = '<div class="vs-dp-section"><div class="vs-dp-highlight" style="background:' + (sec.color || '#FEF3C7') + '"><span class="vs-dp-sec-icon">' + (sec.icon || '⚠️') + '</span><div><strong>' + vsEsc(sec.title || '') + '</strong><div>' + vsEsc(sec.body || '') + '</div></div></div></div>';
      return html; // highlight has its own full-section markup, skip the standard wrapper below

    case 'reviews':
      html += '<div class="vs-dp-reviews-container" data-listing-id="' + (sec.listing_id || 0) + '" data-page="1"><div class="vs-dp-reviews-loading">Loading reviews…</div></div>';
      break;

    default: // richtext and anything else — TinyMCE-produced HTML, already sanitised on save via wp_kses when the listing itself was saved
      html += '<div class="vs-dp-richtext">' + (sec.body || '') + '</div>';
  }

  if (sec.documents && sec.documents.length) {
    html += '<div class="vs-dp-docs">' + sec.documents.map(function(doc) {
      return '<a href="' + doc.url + '" target="_blank" rel="noopener" class="vs-dp-doc-link">📄 ' + vsEsc(doc.name || 'Download document') + '</a>';
    }).join('') + '</div>';
  }

  html += '</div></div>';
  return html;
}

function vsEsc(s) {
  var d = document.createElement('div');
  d.textContent = s || '';
  return d.innerHTML;
}

// Real fix — root cause of the "View Details → Get Quote/Enquire Now"
// wizard missing fields: two separate button handlers were each
// rebuilding their own version of this extraction, and had drifted
// out of sync with each other (the Product handler didn't extract
// anything at all; the Service handler extracted description/
// highlights but not availability). One shared function now used by
// both, so a future field addition only needs to be taught here once.
// full_description and key_features/highlights are pulled from the
// already-parsed sections array via their _field markers (the same
// data already rendered in the popup itself, so this can never drift
// from what the visitor already saw); availability/delivery_info/
// duration are read from the trigger element's own data attributes,
// since those were never embedded in sections to begin with.
function vsExtractWizardExtras(triggerEl, sections) {
  var fullDescription = '', keyFeatures = [];
  (sections || []).forEach(function(sec) {
    if (sec.content_type === 'richtext' && sec._field === 'full_description') { fullDescription = sec.body || ''; }
    if (sec.content_type === 'list' && (sec._field === 'key_features' || sec._field === 'highlights')) { keyFeatures = sec.list_items || []; }
  });
  var availability = triggerEl.getAttribute('data-availability') || '';
  var deliveryInfo = triggerEl.getAttribute('data-delivery') || '';
  var duration = triggerEl.getAttribute('data-duration') || deliveryInfo;
  return {
    full_description: fullDescription,
    key_features: keyFeatures,
    highlights: keyFeatures,
    availability: availability,
    delivery_info: deliveryInfo,
    duration: duration
  };
}

// Beauty & Salon, section 01 of 6 — Beauty Service Discovery category
// tabs. Plain client-side data-attribute filtering, no AJAX round trip
// and no page reload — matches the spec's explicit requirement, and
// the small number of already-rendered cards makes a second network
// request unnecessary. Delegated at document level so it keeps working
// through any future re-render of the grid.
document.addEventListener('click', function(e) {
  var tab = e.target.closest ? e.target.closest('.gs-beauty-tab') : null;
  if (!tab) return;
  var wrap = tab.closest('.gs-beauty-services');
  if (!wrap) return;
  wrap.querySelectorAll('.gs-beauty-tab').forEach(function(t){ t.classList.remove('is-active'); t.setAttribute('aria-selected','false'); });
  tab.classList.add('is-active'); tab.setAttribute('aria-selected','true');
  var group = tab.getAttribute('data-group');
  wrap.querySelectorAll('.gs-beauty-card').forEach(function(card){
    var show = (group === 'all') || (card.getAttribute('data-group') === group);
    card.hidden = !show;
  });
});

// Home Services, module 1 — Service Catalogue & Problem Solver.
// Category tabs: identical mechanism to the Beauty & Salon tabs above
// (plain client-side data-attribute filtering, no AJAX round trip).
// Clicking a group tab also clears any active problem-chip filter, so
// only one filter is ever active at a time (mutual exclusivity between
// "browse by category" and "find by problem" — the custom build
// spec's own stated flow: Problem → Recommended Service, not a
// combined filter).
document.addEventListener('click', function(e) {
  var tab = e.target.closest ? e.target.closest('.gs-hsvc-tab') : null;
  if (!tab) return;
  var wrap = tab.closest('.gs-hsvc-catalogue');
  if (!wrap) return;
  wrap.querySelectorAll('.gs-hsvc-tab').forEach(function(t){ t.classList.remove('is-active'); t.setAttribute('aria-selected','false'); });
  tab.classList.add('is-active'); tab.setAttribute('aria-selected','true');
  wrap.querySelectorAll('.gs-hsvc-problem-chip').forEach(function(c){ c.classList.remove('is-active'); });
  var group = tab.getAttribute('data-group');
  wrap.querySelectorAll('.gs-hsvc-card').forEach(function(card){
    var show = (group === 'all') || (card.getAttribute('data-group') === group);
    card.hidden = !show;
  });
});

// Home Services problem-picker chips: clicking a problem filters the
// grid to the service(s) whose vendor-entered `problems` list contains
// it (built server-side into each card's pipe-separated data-problems
// attribute — see HomeServicesCatalogueModule::render_grid()).
// Clicking the same chip again clears the filter back to "all",
// matching the toggle behaviour a customer expects from a picker like
// this. Clicking a chip also resets category tabs to "All Services".
document.addEventListener('click', function(e) {
  var chip = e.target.closest ? e.target.closest('.gs-hsvc-problem-chip') : null;
  if (!chip) return;
  var wrap = chip.closest('.gs-hsvc-catalogue');
  if (!wrap) return;
  var wasActive = chip.classList.contains('is-active');
  wrap.querySelectorAll('.gs-hsvc-problem-chip').forEach(function(c){ c.classList.remove('is-active'); });
  wrap.querySelectorAll('.gs-hsvc-tab').forEach(function(t){
    t.classList.toggle('is-active', t.getAttribute('data-group') === 'all');
    t.setAttribute('aria-selected', t.getAttribute('data-group') === 'all' ? 'true' : 'false');
  });
  if (wasActive) {
    wrap.querySelectorAll('.gs-hsvc-card').forEach(function(card){ card.hidden = false; });
    return;
  }
  chip.classList.add('is-active');
  var problem = chip.getAttribute('data-problem');
  wrap.querySelectorAll('.gs-hsvc-card').forEach(function(card){
    var list = (card.getAttribute('data-problems') || '').split('|');
    card.hidden = list.indexOf(problem) === -1;
  });
});

// Hotels / Banquets / Hospitality, Dining menu category tabs. Same
// plain client-side data-attribute filtering mechanism as the Home
// Services / Beauty & Salon tabs above — no new tab engine.
document.addEventListener('click', function(e) {
  var tab = e.target.closest ? e.target.closest('.gs-hdin-tab') : null;
  if (!tab) return;
  var wrap = tab.closest('.gs-hdin-menu');
  if (!wrap) return;
  wrap.querySelectorAll('.gs-hdin-tab').forEach(function(t){ t.classList.remove('is-active'); t.setAttribute('aria-selected','false'); });
  tab.classList.add('is-active'); tab.setAttribute('aria-selected','true');
  var cat = tab.getAttribute('data-cat');
  wrap.querySelectorAll('.gs-hdin-card').forEach(function(card){
    var show = (cat === 'all') || (card.getAttribute('data-cat') === cat);
    card.hidden = !show;
  });
});

window.vsOpenDetailPopup = function(e, triggerEl) {
  // Real fix: this must be the first thing that happens, unconditionally.
  // The previous "onclick="fn();return false;"" pattern only prevented
  // the default '#' scroll-to-top if fn() completed without throwing —
  // any error anywhere inside the popup logic meant return false never
  // ran, and the browser fell through to its default anchor behavior
  // (scroll to top), which is exactly the symptom reported: click does
  // nothing except scroll up.
  if (e && e.preventDefault) { e.preventDefault(); }

  // Comprehensive diagnostic — every step is individually wrapped and
  // labeled so the exact failing step is identified precisely, and shown
  // directly on the page (not just the console), since the failure
  // happens on every item — this points to something structural, not
  // per-item data corruption, so pinpointing the exact step matters more
  // than the specific data involved.
  var step = 'start';
  try {
    step = 'reading data-sections attribute';
    var rawSections = triggerEl.getAttribute('data-sections');

    step = 'parsing data-sections JSON';
    var sections = [];
    try { sections = JSON.parse(rawSections || '[]'); } catch(parseErr) { sections = []; }
    if (!Array.isArray(sections)) { sections = []; } // real fix: guards against the exact double-encoding failure mode this diagnostic just caught

    step = 'reading data-title/data-image/data-price attributes';
    var title = triggerEl.getAttribute('data-title') || '';
    var image = triggerEl.getAttribute('data-image') || '';
    var price = triggerEl.getAttribute('data-price') || '';

    step = 'reading optional data-images (gallery) / data-img-fit attributes';
    // Real feature — reusable image gallery for the shared detail
    // popup. data-images is entirely optional: when a section/call
    // site never sets it (every pre-existing one), this falls back to
    // the single data-image alone, so nothing about any existing
    // section's behavior changes at all.
    var extraImages = [];
    try { extraImages = JSON.parse(triggerEl.getAttribute('data-images') || '[]'); } catch(imgErr) { extraImages = []; }
    if (!Array.isArray(extraImages)) { extraImages = []; }
    var popupImages = image ? [image].concat(extraImages.filter(function(u) { return u && u !== image; })) : extraImages;
    var imgFit = triggerEl.getAttribute('data-img-fit') || 'cover';
    // Real feature — configurable auto-advance interval, in
    // milliseconds. 0 (or absent) disables auto-advance entirely,
    // matching every existing call site that never sets this
    // attribute — the slider still works fully via manual navigation.
    var sliderIntervalMs = parseInt(triggerEl.getAttribute('data-slider-interval') || '0', 10) || 0;

    step = 'checking vsBuildDetailPopup is defined';
    if (typeof vsBuildDetailPopup !== 'function') { throw new Error('vsBuildDetailPopup is not defined — the script block containing it may not have loaded.'); }

    step = 'building/finding the popup DOM (vsBuildDetailPopup)';
    var popup = vsBuildDetailPopup();
    if (!popup) { throw new Error('vsBuildDetailPopup() returned nothing.'); }

    step = 'finding #vs-dp-title element';
    var titleEl = document.getElementById('vs-dp-title');
    if (!titleEl) { throw new Error('#vs-dp-title element not found in the popup — vsBuildDetailPopup() may not have attached correctly.'); }
    titleEl.textContent = title;

    step = 'building image/slider area (reusable component)';
    var bodyHtml = '';
    if (typeof vsRenderPopupImageArea !== 'function') { throw new Error('vsRenderPopupImageArea is not defined — the script block containing it may not have loaded.'); }
    window.vsPopupSliderIndex = 0;
    window.vsPopupSliderCount = popupImages.filter(Boolean).length;
    bodyHtml += vsRenderPopupImageArea(popupImages, imgFit, title);

    step = 'checking vsRenderDetailSection is defined';
    if (typeof vsRenderDetailSection !== 'function') { throw new Error('vsRenderDetailSection is not defined — the script block containing it may not have loaded.'); }

    step = 'rendering ' + sections.length + ' section(s)';
    var anyRendered = false;
    sections.forEach(function(sec, idx) {
      step = 'rendering section #' + idx + ' (content_type: ' + (sec && sec.content_type) + ')';
      var s = vsRenderDetailSection(sec);
      if (s) { anyRendered = true; bodyHtml += s; }
    });
    if (!anyRendered) {
      bodyHtml += '<div class="vs-dp-empty">More details coming soon for this ' + (title ? '"' + vsEsc(title) + '"' : 'item') + '.</div>';
    }

    step = 'finding #vs-dp-body element';
    var bodyEl = document.getElementById('vs-dp-body');
    if (!bodyEl) { throw new Error('#vs-dp-body element not found in the popup.'); }
    bodyEl.innerHTML = bodyHtml;

    step = 'starting slider auto-advance, if configured';
    vsPopupSliderStartAuto(sliderIntervalMs);

    step = 'loading reviews container(s), if any';
    bodyEl.querySelectorAll('.vs-dp-reviews-container').forEach(function(container) {
      vsLoadDetailPopupReviews(container, 1);
    });

    step = 'building CTA HTML';
    var ctaHtml = '';
    if (price) { ctaHtml += '<div class="vs-dp-cta-price">' + vsEsc(price) + '</div>'; }
    var pkgDataForWizard = triggerEl.getAttribute('data-pkg');
    var isSvcCard = !!triggerEl.closest('.vs-svc-card');
    var isItemCard = !!triggerEl.closest('.vs-item-card');
    // Real fix — within the Products & Services section, an item's own
    // type (service vs product) determines which wizard fits, not just
    // which section/card class it lives in. Defaults to 'product' only
    // when the attribute is genuinely absent (e.g. Services-section
    // cards, which have no data-item-type at all).
    var itemType = triggerEl.getAttribute('data-item-type') || (isItemCard ? 'product' : '');
    if (pkgDataForWizard) {
      // Real feature — this trigger is a Package & Pricing "View Details"
      // button, which already carries the full wizard payload (data-pkg).
      // Reuse it directly rather than rebuilding it, and open the exact
      // same Booking Wizard used everywhere else on the platform, so the
      // booking experience stays consistent regardless of entry point.
      ctaHtml += '<button type="button" class="vs-dp-cta-btn" id="vs-dp-book-now-btn">📅 Book Now</button>';
    } else if ((isSvcCard || (isItemCard && itemType === 'service')) && window.GS_SVC_WIZARD_ENABLED) {
      ctaHtml += '<button type="button" class="vs-dp-cta-btn" id="vs-dp-svcwiz-btn">📅 Enquire Now</button>';
    } else if (isItemCard && itemType === 'product' && window.GS_PROD_WIZARD_ENABLED) {
      ctaHtml += '<button type="button" class="vs-dp-cta-btn" id="vs-dp-prodwiz-btn">📅 Get Quote</button>';
    } else if (<?php echo $_can_lead_popup ? 'true' : 'false'; ?>) {
      ctaHtml += '<button type="button" class="vs-dp-cta-btn" onclick="vsCloseDetailPopup();vsOpenInquiry({name:\'' + title.replace(/'/g,"\\'") + '\',type:\'service\',price:\'' + price.replace(/'/g,"\\'") + '\'});">📋 Enquire Now</button>';
    }

    step = 'finding #vs-dp-cta element';
    var ctaEl = document.getElementById('vs-dp-cta');
    if (!ctaEl) { throw new Error('#vs-dp-cta element not found in the popup.'); }
    ctaEl.innerHTML = ctaHtml;

    step = 'wiring Book Now / wizard buttons, if present';
    var bookNowBtn = document.getElementById('vs-dp-book-now-btn');
    if (bookNowBtn) {
      bookNowBtn.addEventListener('click', function() {
        vsCloseDetailPopup();
        vsOpenBookingWizard(triggerEl);
      });
    }
    var svcWizBtn = document.getElementById('vs-dp-svcwiz-btn');
    if (svcWizBtn) {
      svcWizBtn.addEventListener('click', function() {
        vsCloseDetailPopup();
        var extras = vsExtractWizardExtras(triggerEl, sections);
        vsOpenServiceWizard({ name: title, price: price || '', listing_id: window.LID || 0, currency: '₹', image: image || '', full_description: extras.full_description, availability: extras.availability, duration: extras.duration, highlights: extras.highlights });
      });
    }
    var prodWizBtn = document.getElementById('vs-dp-prodwiz-btn');
    if (prodWizBtn) {
      prodWizBtn.addEventListener('click', function() {
        vsCloseDetailPopup();
        var extras = vsExtractWizardExtras(triggerEl, sections);
        vsOpenProductWizard({ name: title, price: price || '', listing_id: window.LID || 0, currency: '₹', image: image || '', full_description: extras.full_description, availability: extras.availability, delivery_info: extras.delivery_info, key_features: extras.key_features });
      });
    }

    step = 'opening the popup';
    popup.classList.add('open');
    document.body.style.overflow = 'hidden';

  } catch (err) {
    // Shown directly on the page — no devtools needed to read this.
    console.error('View More popup failed at step "' + step + '":', err);
    vsShowDetailPopupDiagnostic(step, err, triggerEl);
  }
};

// Comprehensive on-page diagnostic panel — shows exactly which step
// failed, the real error name/message/stack, and the raw data this
// specific click was working with, so the failure can be pinpointed
// precisely from a screenshot alone rather than requiring console access.
function vsShowDetailPopupDiagnostic(step, err, triggerEl) {
  var existing = document.getElementById('vs-dp-diagnostic');
  if (existing) existing.remove();
  var box = document.createElement('div');
  box.id = 'vs-dp-diagnostic';
  box.style.cssText = 'position:fixed;top:16px;right:16px;left:16px;max-width:560px;margin-left:auto;background:#1E1B2E;color:#E9E4FF;padding:18px;border-radius:12px;box-shadow:0 20px 50px rgba(0,0,0,.4);z-index:999999;font-family:monospace;font-size:.76rem;line-height:1.6;max-height:70vh;overflow-y:auto';
  var rawData = triggerEl ? (triggerEl.getAttribute('data-sections') || '(empty)') : '(no trigger element)';
  box.innerHTML =
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">' +
      '<strong style="color:#F87171;font-family:-apple-system,sans-serif;font-size:.9rem">⚠️ View More Diagnostic</strong>' +
      '<button onclick="document.getElementById(\'vs-dp-diagnostic\').remove()" aria-label="Close diagnostic panel" style="background:#374151;color:#fff;border:none;width:24px;height:24px;border-radius:50%;cursor:pointer">&#10005;</button>' +
    '</div>' +
    '<div style="margin-bottom:8px"><span style="color:#475569">Failed at step:</span> <strong style="color:#FBBF24">' + vsEsc(step) + '</strong></div>' +
    '<div style="margin-bottom:8px"><span style="color:#475569">Error type:</span> ' + vsEsc(err && err.name || 'Unknown') + '</div>' +
    '<div style="margin-bottom:8px"><span style="color:#475569">Error message:</span> ' + vsEsc(err && err.message || String(err)) + '</div>' +
    '<div style="margin-bottom:8px"><span style="color:#475569">Stack trace:</span><pre style="white-space:pre-wrap;word-break:break-all;background:#000;padding:8px;border-radius:6px;margin-top:4px;font-size:.68rem">' + vsEsc(err && err.stack || '(none)') + '</pre></div>' +
    '<div><span style="color:#475569">Raw section data for this click:</span><pre style="white-space:pre-wrap;word-break:break-all;background:#000;padding:8px;border-radius:6px;margin-top:4px;font-size:.68rem;max-height:120px;overflow-y:auto">' + vsEsc(rawData.substring(0, 2000)) + '</pre></div>' +
    '<div style="margin-top:10px;font-size:.68rem;color:#475569;font-family:-apple-system,sans-serif">Screenshot this whole box and send it back — it has everything needed to fix this precisely.</div>';
  document.body.appendChild(box);
}

// ═══════════════════════════════════════════════════════════════════════════
// Booking Wizard — premium multi-step booking flow for Packages & Pricing.
// Reuses: gs_get_available_slots (the same real availability/schedule/
// buffer/blocked-dates system already used elsewhere), and gs_submit_lead
// (the same universal, category-agnostic lead endpoint every other
// Enquire/Quick Connect button already uses) — so this works for any
// vendor/industry without depending on category-specific bookable
// inquiry-module configuration.
// ═══════════════════════════════════════════════════════════════════════════
<?php
// Real feature — the entire booking/enquiry wizard system (state, all
// step functions for Packages/Services/Products, calendar, submit,
// confirmation, and its diagnostic tool) is verified reachable only via
// 5 call sites, every one of which is already independently gated by
// one of these same three toggles. When all three are off, none of this
// ~15KB is downloaded at all — not just unused, genuinely absent.
$_any_wizard_enabled = ( $cd['packages_booking_wizard'] ?? 1 ) || ( $cd['services_booking_wizard'] ?? 1 ) || ( $cd['items_booking_wizard'] ?? 1 );
if ( $_any_wizard_enabled ):
?>
var _vsBW = { mode: 'package', pkg: null, svc: null, prod: null, step: 1, totalSteps: 5, date: null, time: null, addons: [], cust: {} };

// Real feature — shared accessor so Step 2's calendar/slot logic (and
// anything else mode-agnostic) can be reused by Services without
// duplicating it. Packages behavior is unchanged: mode defaults to
// 'package', so this returns _vsBW.pkg exactly as every reference did
// before this existed.
function _vsBWItem() { return _vsBW.mode === 'service' ? _vsBW.svc : ( _vsBW.mode === 'product' ? _vsBW.prod : _vsBW.pkg ); }

// Real feature — per-section wizard text customization. Vendors can
// override step titles, button labels, notes, and confirmation content
// per section (Packages/Services/Products) without any code change or
// workflow change — this only ever substitutes display text, never
// fields, validation, or step order. window.GS_WIZ_TEXT is emitted
// server-side with ONLY the keys a vendor has actually customized; every
// call site here supplies its own hardcoded fallback, so an untouched
// vendor sees exactly the original text, unchanged.
function _vsBWT(key, fallback) {
  var mode = _vsBW.mode === 'service' ? 'service' : ( _vsBW.mode === 'product' ? 'product' : 'packages' );
  if (window.GS_WIZ_TEXT && window.GS_WIZ_TEXT[mode] && window.GS_WIZ_TEXT[mode][key]) {
    return window.GS_WIZ_TEXT[mode][key];
  }
  return fallback;
}

function vsBWCurrency(n) { return (_vsBW.pkg.currency || '₹') + Number(n || 0).toFixed(2).replace(/\.00$/, ''); }

function vsBWComputeTotals() {
  var base = _vsBW.pkg.price || 0;
  var addonsTotal = _vsBW.addons.reduce(function(sum, idx) { return sum + (_vsBW.pkg.addons[idx] ? _vsBW.pkg.addons[idx].price : 0); }, 0);
  var subtotal = base + addonsTotal;
  var gst = 0, gstLabel = '';
  if (_vsBW.pkg.gst_type === 'added') { gst = subtotal * 0.18; gstLabel = 'GST (18%)'; }
  else if (_vsBW.pkg.gst_type === 'custom') { gst = subtotal * ((_vsBW.pkg.gst_percent || 0) / 100); gstLabel = 'GST (' + (_vsBW.pkg.gst_percent || 0) + '%)'; }
  else if (_vsBW.pkg.gst_type === 'included') { gstLabel = 'GST included in price'; }
  var total = subtotal + gst;
  return { base: base, addonsTotal: addonsTotal, subtotal: subtotal, gst: gst, gstLabel: gstLabel, total: total };
}

window.vsOpenBookingWizard = function(triggerEl) {
  try {
    _vsBW.pkg = JSON.parse(triggerEl.getAttribute('data-pkg') || '{}');
  } catch (e) { _vsBW.pkg = {}; }
  _vsBW.mode = 'package';
  _vsBW.step = 1; _vsBW.date = null; _vsBW.time = null; _vsBW.addons = []; _vsBW.cust = {};
  _vsBWCalMonth = null;
  _vsBWOpenSharedOverlay();
};

window.vsOpenServiceWizard = function(triggerOrPayload) {
  try {
    if (triggerOrPayload && typeof triggerOrPayload.getAttribute === 'function') {
      _vsBW.svc = JSON.parse(triggerOrPayload.getAttribute('data-svc') || '{}');
    } else {
      _vsBW.svc = triggerOrPayload || {};
    }
  } catch (e) { _vsBW.svc = {}; }
  _vsBW.mode = 'service';
  _vsBW.step = 1; _vsBW.date = null; _vsBW.time = null; _vsBW.addons = []; _vsBW.cust = {}; _vsBW.requirements = '';
  // Real feature — Beauty & Salon, section 03 of 6 (specialist
  // selection persisting through to date/time/confirmation), built by
  // extending this one real, shared wizard rather than a parallel
  // booking system, per the confirmed approach. `specialist` is
  // entirely optional and only ever set by a caller that passes it
  // (BeautyExpertsModule's "Book With {Name}" button) — every existing
  // caller across every other category is completely unaffected, since
  // they simply never set this field and it stays undefined/falsy
  // everywhere below.
  _vsBW.specialist = (_vsBW.svc && _vsBW.svc.specialist) ? _vsBW.svc.specialist : null;
  _vsBWCalMonth = null;
  _vsBWOpenSharedOverlay();
};

window.vsOpenProductWizard = function(triggerOrPayload) {
  try {
    if (triggerOrPayload && typeof triggerOrPayload.getAttribute === 'function') {
      _vsBW.prod = JSON.parse(triggerOrPayload.getAttribute('data-prod') || '{}');
    } else {
      _vsBW.prod = triggerOrPayload || {};
    }
  } catch (e) { _vsBW.prod = {}; }
  _vsBW.mode = 'product';
  _vsBW.step = 1; _vsBW.cust = {}; _vsBW.quantity = 1; _vsBW.specs = ''; _vsBW.requirements = ''; _vsBW.attachedFile = null;
  _vsBWOpenSharedOverlay();
};

function _vsBWOpenSharedOverlay() {
  var existing = document.getElementById('vs-bw-overlay');
  if (existing) existing.remove();
  var overlay = document.createElement('div');
  overlay.id = 'vs-bw-overlay';
  overlay.className = 'vs-bw-overlay';
  overlay.onclick = function(e) { if (e.target === overlay) vsCloseBookingWizard(); };
  overlay.innerHTML =
    '<div class="vs-bw-sheet">' +
      '<div class="vs-bw-header">' +
        '<div class="vs-bw-progress" id="vs-bw-progress"></div>' +
        '<button type="button" class="vs-bw-close" onclick="vsCloseBookingWizard()" aria-label="Close">&#10005;</button>' +
      '</div>' +
      '<div class="vs-bw-body" id="vs-bw-body"></div>' +
      '<div class="vs-bw-nav" id="vs-bw-nav"></div>' +
    '</div>';
  document.body.appendChild(overlay);
  requestAnimationFrame(function() { overlay.classList.add('open'); document.body.style.overflow = 'hidden'; });
  vsBWRenderStep();
}

window.vsCloseBookingWizard = function() {
  var overlay = document.getElementById('vs-bw-overlay');
  if (overlay) { overlay.classList.remove('open'); setTimeout(function() { overlay.remove(); }, 250); }
  document.body.style.overflow = '';
};

function vsBWProgressHtml() {
  var labels = _vsBW.mode === 'service'
    ? ['Service', 'Date & Time', 'Requirements', 'Your Details', 'Summary']
    : _vsBW.mode === 'product'
    ? ['Product', 'Quantity', 'Requirements', 'Your Details', 'Summary']
    : ['Package', 'Date & Time', 'Add-ons', 'Your Details', 'Summary'];
  var html = '';
  for (var i = 1; i <= _vsBW.totalSteps; i++) {
    var state = i < _vsBW.step ? 'done' : (i === _vsBW.step ? 'active' : '');
    html += '<div class="vs-bw-step ' + state + '"><div class="vs-bw-step-dot">' + (i < _vsBW.step ? '✓' : i) + '</div><div class="vs-bw-step-label">' + labels[i - 1] + '</div></div>';
    if (i < _vsBW.totalSteps) html += '<div class="vs-bw-step-line ' + (i < _vsBW.step ? 'done' : '') + '"></div>';
  }
  return html;
}

function vsBWRenderStep() {
  document.getElementById('vs-bw-progress').innerHTML = vsBWProgressHtml();
  var bodyEl = document.getElementById('vs-bw-body');
  var navEl = document.getElementById('vs-bw-nav');
  bodyEl.classList.remove('vs-bw-fade-in');
  var result = {};
  var isService = _vsBW.mode === 'service';
  var isProduct = _vsBW.mode === 'product';
  if (_vsBW.step === 1) result = isService ? vsSvcWizStep1() : (isProduct ? vsProdWizStep1() : vsBWStep1());
  else if (_vsBW.step === 2) result = isProduct ? vsProdWizStep2() : vsBWStep2();
  else if (_vsBW.step === 3) result = isService ? vsSvcWizStep3() : (isProduct ? vsProdWizStep3() : vsBWStep3());
  else if (_vsBW.step === 4) result = vsBWStep4();
  else if (_vsBW.step === 5) result = isService ? vsSvcWizStep5() : (isProduct ? vsProdWizStep5() : vsBWStep5());
  bodyEl.innerHTML = result.content || '';
  navEl.innerHTML = result.nav || '';
  requestAnimationFrame(function() { bodyEl.classList.add('vs-bw-fade-in'); });
  if (_vsBW.step === 2 && !isProduct) vsBWInitStep2();
}

/* ── Step 1: Package Review ── */
function vsBWStep1() {
  var p = _vsBW.pkg;
  var featHtml = (p.features || []).map(function(f) { return '<li>' + vsEsc(f) + '</li>'; }).join('');
  var content = '<div class="vs-bw-step-content">' +
    '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('step1_title', 'Review your package')) + '</h2>' +
    (_vsBWT('step1_intro', '') ? '<p class="vs-bw-step-intro">' + vsEsc(_vsBWT('step1_intro', '')) + '</p>' : '') +
    '<div class="vs-bw-pkg-card">' +
      (p.image ? '<img src="' + p.image + '" class="vs-bw-pkg-img" alt="" width="72" height="72">' : '') +
      '<div><div class="vs-bw-pkg-name">' + vsEsc(p.name || '') + '</div>' +
      '<div class="vs-bw-pkg-price">' + vsBWCurrency(p.price) + (p.period ? ' <span>· ' + vsEsc(p.period) + '</span>' : '') + '</div>' +
      (p.description ? '<div class="vs-bw-pkg-desc">' + vsEsc(p.description) + '</div>' : '') + '</div>' +
    '</div>' +
    (featHtml ? '<div class="vs-bw-subhead">' + vsEsc(_vsBWT('step1_features_label', "What's included")) + '</div><ul class="vs-bw-feat-list">' + featHtml + '</ul>' : '') +
  '</div>';
  var nav = '<span></span><button type="button" class="vs-bw-btn-primary" onclick="vsBWNext()">' + vsEsc(_vsBWT('btn_continue', 'Continue →')) + '</button>';
  return { content: content, nav: nav };
}

/* ── Step 2: Date & Time (reuses gs_get_available_slots) ── */
function vsBWStep2() {
  var content = '<div class="vs-bw-step-content">' +
    '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('step2_title', 'Choose date & time')) + '</h2>' +
    '<div class="vs-bw-cal" id="vs-bw-cal"></div>' +
    '<div class="vs-bw-subhead" style="margin-top:20px">' + vsEsc(_vsBWT('step2_slots_label', 'Available time slots')) + '</div>' +
    '<div class="vs-bw-slots" id="vs-bw-slots"><div class="vs-bw-slots-placeholder">Select a date above to see available times.</div></div>' +
  '</div>';
  var nav = '<button type="button" class="vs-bw-btn-secondary" onclick="vsBWBack()">' + vsEsc(_vsBWT('btn_back', '← Back')) + '</button><button type="button" class="vs-bw-btn-primary" id="vs-bw-step2-next" onclick="vsBWNext()" disabled>' + vsEsc(_vsBWT('btn_continue', 'Continue →')) + '</button>';
  return { content: content, nav: nav };
}
var _vsBWCalMonth = null; // {year, month} of the month currently displayed
function vsBWInitStep2() {
  var now = new Date();
  if (!_vsBWCalMonth) {
    var base = _vsBW.date ? new Date(_vsBW.date + 'T00:00:00') : now;
    _vsBWCalMonth = { year: base.getFullYear(), month: base.getMonth() };
  }
  vsBWRenderCalendar();
  if (_vsBW.date) vsBWLoadSlots(_vsBW.date);
}
function vsBWRenderCalendar() {
  var y = _vsBWCalMonth.year, m = _vsBWCalMonth.month;
  var today = new Date(); today.setHours(0, 0, 0, 0);
  var monthLabel = new Date(y, m, 1).toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
  var firstDow = new Date(y, m, 1).getDay();
  var daysInMonth = new Date(y, m + 1, 0).getDate();
  var minMonth = today.getFullYear() * 12 + today.getMonth();
  var thisMonthIdx = y * 12 + m;

  var html = '<div class="vs-bw-cal-header">' +
    '<button type="button" class="vs-bw-cal-nav" aria-label="Previous month" ' + (thisMonthIdx <= minMonth ? 'disabled' : '') + ' onclick="vsBWCalMonthShift(-1)">‹</button>' +
    '<strong>' + monthLabel + '</strong>' +
    '<button type="button" class="vs-bw-cal-nav" aria-label="Next month" onclick="vsBWCalMonthShift(1)">›</button>' +
  '</div>' +
  '<div class="vs-bw-cal-weekdays">' + ['Su','Mo','Tu','We','Th','Fr','Sa'].map(function(d) { return '<span>' + d + '</span>'; }).join('') + '</div>' +
  '<div class="vs-bw-cal-grid">';
  for (var i = 0; i < firstDow; i++) { html += '<span class="vs-bw-cal-day empty"></span>'; }
  for (var day = 1; day <= daysInMonth; day++) {
    var d = new Date(y, m, day);
    var iso = y + '-' + String(m + 1).padStart(2, '0') + '-' + String(day).padStart(2, '0');
    var isPast = d < today;
    var isSelected = iso === _vsBW.date;
    var isToday = d.getTime() === today.getTime();
    html += '<button type="button" class="vs-bw-cal-day' + (isPast ? ' disabled' : '') + (isSelected ? ' selected' : '') + (isToday ? ' today' : '') + '" ' + (isPast ? 'disabled' : 'onclick="vsBWSelectDate(\'' + iso + '\', this)"') + '>' + day + '</button>';
  }
  html += '</div>';
  document.getElementById('vs-bw-cal').innerHTML = html;
}
window.vsBWCalMonthShift = function(delta) {
  var d = new Date(_vsBWCalMonth.year, _vsBWCalMonth.month + delta, 1);
  _vsBWCalMonth = { year: d.getFullYear(), month: d.getMonth() };
  vsBWRenderCalendar();
};
window.vsBWSelectDate = function(iso, btnEl) {
  document.querySelectorAll('.vs-bw-cal-day').forEach(function(b) { b.classList.remove('selected'); });
  if (btnEl) btnEl.classList.add('selected');
  _vsBW.date = iso; _vsBW.time = null;
  document.getElementById('vs-bw-step2-next').disabled = true;
  vsBWLoadSlots(iso);
};
function vsBWLoadSlots(iso) {
  var slotsEl = document.getElementById('vs-bw-slots');
  slotsEl.innerHTML = '<div class="vs-bw-slots-placeholder">Loading available times…</div>';
  gsPost('gs_get_available_slots', { listing_id: _vsBWItem().listing_id, date: iso }, function(d) {
    var slots = d.slots || [];
    if (!slots.length) {
      if (d.no_schedule_at_all) {
        slotsEl.innerHTML = '<div class="vs-bw-slots-placeholder">' + vsEsc(d.message || 'Online booking is not set up for this business yet.') +
          '<br><button type="button" class="vs-bw-btn-secondary" style="margin-top:12px" onclick="vsCloseBookingWizard();vsOpenInquiry({name:\'' + (_vsBWItem().name || '').replace(/'/g,"\\'") + '\',type:\'service\'});">📋 Enquire Instead</button></div>';
      } else {
        slotsEl.innerHTML = '<div class="vs-bw-slots-placeholder">' + vsEsc(d.message || 'No slots available on this date — try another day.') + '</div>';
      }
      return;
    }
    slotsEl.innerHTML = slots.map(function(s) {
      return '<button type="button" class="vs-bw-slot-chip' + (!s.available ? ' disabled' : '') + '" ' + (s.available ? 'onclick="vsBWSelectTime(\'' + s.time + '\', this)"' : 'disabled') + '>' + s.label + '</button>';
    }).join('');
  }, function() { slotsEl.innerHTML = '<div class="vs-bw-slots-placeholder">Could not load time slots. Please try again.</div>'; });
}
window.vsBWSelectTime = function(time, btnEl) {
  document.querySelectorAll('.vs-bw-slot-chip').forEach(function(b) { b.classList.remove('selected'); });
  btnEl.classList.add('selected');
  _vsBW.time = time;
  document.getElementById('vs-bw-step2-next').disabled = false;
};

/* ── Step 3: Add-ons ── */
function vsBWStep3() {
  var addons = _vsBW.pkg.addons || [];
  if (!addons.length) { _vsBW.step = 4; return vsBWStep4(); }
  var html = addons.map(function(a, i) {
    var checked = _vsBW.addons.indexOf(i) !== -1;
    return '<label class="vs-bw-addon-card' + (checked ? ' selected' : '') + '"><input type="checkbox" ' + (checked ? 'checked' : '') + ' onchange="vsBWToggleAddon(' + i + ', this)"><div class="vs-bw-addon-info"><div class="vs-bw-addon-name">' + vsEsc(a.name) + '</div></div><div class="vs-bw-addon-price">+' + vsBWCurrency(a.price) + '</div></label>';
  }).join('');
  var content = '<div class="vs-bw-step-content">' +
    '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('step3_title', 'Add-ons & extras')) + '</h2>' +
    '<div class="vs-bw-subhead">' + vsEsc(_vsBWT('step3_subhead', 'Optional — enhance your booking')) + '</div>' +
    '<div class="vs-bw-addons-list">' + html + '</div>' +
  '</div>';
  var nav = '<button type="button" class="vs-bw-btn-secondary" onclick="vsBWBack()">' + vsEsc(_vsBWT('btn_back', '← Back')) + '</button><button type="button" class="vs-bw-btn-primary" onclick="vsBWNext()">' + vsEsc(_vsBWT('btn_continue', 'Continue →')) + '</button>';
  return { content: content, nav: nav };
}
window.vsBWToggleAddon = function(i, checkboxEl) {
  var idx = _vsBW.addons.indexOf(i);
  if (checkboxEl.checked && idx === -1) { _vsBW.addons.push(i); checkboxEl.closest('.vs-bw-addon-card').classList.add('selected'); }
  else if (!checkboxEl.checked && idx !== -1) { _vsBW.addons.splice(idx, 1); checkboxEl.closest('.vs-bw-addon-card').classList.remove('selected'); }
};

/* ── Step 4: Your Details ── */
function vsBWStep4() {
  var c = _vsBW.cust;
  var content = '<div class="vs-bw-step-content">' +
    '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('step4_title', 'Your details')) + '</h2>' +
    '<div class="vs-bw-field"><label>Full Name *</label><input type="text" id="vs-bw-name" value="' + vsEsc(c.name || '') + '" placeholder="Your name"></div>' +
    '<div class="vs-bw-field"><label>Phone *</label><input type="tel" id="vs-bw-phone" value="' + vsEsc(c.phone || '') + '" placeholder="10-digit mobile number"></div>' +
    '<div class="vs-bw-field"><label>Email</label><input type="email" id="vs-bw-email" value="' + vsEsc(c.email || '') + '" placeholder="you@example.com (optional)"></div>' +
    '<div class="vs-bw-field"><label>Notes for the vendor <span>(optional)</span></label><textarea id="vs-bw-notes" rows="3" placeholder="Any special requests...">' + vsEsc(c.notes || '') + '</textarea></div>' +
    '<div class="vs-bw-error" id="vs-bw-step4-error"></div>' +
  '</div>';
  var nav = '<button type="button" class="vs-bw-btn-secondary" onclick="vsBWBack()">' + vsEsc(_vsBWT('btn_back', '← Back')) + '</button><button type="button" class="vs-bw-btn-primary" onclick="vsBWStep4Next()">' + vsEsc(_vsBWT('btn_continue', 'Continue →')) + '</button>';
  return { content: content, nav: nav };
}
window.vsBWStep4Next = function() {
  var name = document.getElementById('vs-bw-name').value.trim();
  var phone = document.getElementById('vs-bw-phone').value.trim();
  var email = document.getElementById('vs-bw-email').value.trim();
  var notes = document.getElementById('vs-bw-notes').value.trim();
  var errEl = document.getElementById('vs-bw-step4-error');
  if (!name || !phone) { errEl.textContent = _vsBWT('step4_error', 'Please enter your name and phone number.'); return; }
  errEl.textContent = '';
  _vsBW.cust = { name: name, phone: phone, email: email, notes: notes };
  vsBWNext();
};

/* ── Step 5: Summary (GST + payment terms folded in) + Submit ── */
function vsBWStep5() {
  var t = vsBWComputeTotals();
  var p = _vsBW.pkg;
  var addonsHtml = _vsBW.addons.map(function(i) { return '<div class="vs-bw-sum-row"><span>' + vsEsc(p.addons[i].name) + '</span><span>' + vsBWCurrency(p.addons[i].price) + '</span></div>'; }).join('');
  var dateLabel = _vsBW.date ? new Date(_vsBW.date + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' }) : '';
  var content = '<div class="vs-bw-step-content">' +
    '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('step5_title', 'Booking summary')) + '</h2>' +
    '<div class="vs-bw-summary-block">' +
      '<div class="vs-bw-sum-row"><span>Package</span><strong>' + vsEsc(p.name) + '</strong></div>' +
      '<div class="vs-bw-sum-row"><span>Date & time</span><strong>' + vsEsc(dateLabel) + ', ' + vsEsc(_vsBW.time || '') + '</strong></div>' +
      (p.period ? '<div class="vs-bw-sum-row"><span>Duration</span><strong>' + vsEsc(p.period) + '</strong></div>' : '') +
      '<div class="vs-bw-sum-row"><span>Customer</span><strong>' + vsEsc(_vsBW.cust.name) + ' · ' + vsEsc(_vsBW.cust.phone) + '</strong></div>' +
    '</div>' +
    '<div class="vs-bw-divider"></div>' +
    '<div class="vs-bw-summary-block">' +
      '<div class="vs-bw-sum-row"><span>Base price</span><span>' + vsBWCurrency(t.base) + '</span></div>' +
      addonsHtml +
      (t.gstLabel ? '<div class="vs-bw-sum-row"><span>' + vsEsc(t.gstLabel) + '</span><span>' + (t.gst ? vsBWCurrency(t.gst) : '—') + '</span></div>' : '') +
      '<div class="vs-bw-sum-row vs-bw-sum-total"><span>Grand Total</span><span>' + vsBWCurrency(t.total) + '</span></div>' +
    '</div>' +
    '<div class="vs-bw-payment-note">' + vsEsc(_vsBWT('step5_payment_note', '💳 Payment collected at time of service, unless the vendor specifies otherwise. This booking request will be confirmed by the vendor directly.')) + '</div>' +
    '<div class="vs-bw-error" id="vs-bw-step5-error"></div>' +
  '</div>';
  var nav = '<button type="button" class="vs-bw-btn-secondary" onclick="vsBWBack()">' + vsEsc(_vsBWT('btn_back', '← Back')) + '</button><button type="button" class="vs-bw-btn-primary" id="vs-bw-submit-btn" onclick="vsBWSubmit()">' + vsEsc(_vsBWT('btn_submit', 'Confirm Booking →')) + '</button>';
  return { content: content, nav: nav };
}

window.vsBWSubmit = function() {
  var btn = document.getElementById('vs-bw-submit-btn');
  btn.disabled = true; btn.textContent = 'Submitting…';
  var t = vsBWComputeTotals();
  var p = _vsBW.pkg;
  var addonNames = _vsBW.addons.map(function(i) { return p.addons[i].name; }).join(', ') || 'None';
  var dateLabel = _vsBW.date ? new Date(_vsBW.date + 'T00:00:00').toLocaleDateString() : '';
  var message = 'BOOKING REQUEST via Booking Wizard\n' +
    'Package: ' + p.name + '\n' +
    'Date & Time: ' + dateLabel + ' at ' + (_vsBW.time || '') + '\n' +
    'Add-ons: ' + addonNames + '\n' +
    'Base Price: ' + vsBWCurrency(t.base) + '\n' +
    (t.gst ? (t.gstLabel + ': ' + vsBWCurrency(t.gst) + '\n') : '') +
    'Grand Total: ' + vsBWCurrency(t.total) + '\n' +
    (_vsBW.cust.notes ? ('Notes: ' + _vsBW.cust.notes) : '');
  gsPost('gs_submit_lead', {
    listing_id: _vsBW.pkg.listing_id, name: _vsBW.cust.name, phone: _vsBW.cust.phone,
    email: _vsBW.cust.email || '', product_name: p.name, message: message, source: 'booking_wizard',
    booking_date: _vsBW.date, booking_time: _vsBW.time
  }, function(d) {
    vsBWShowConfirmation(t);
  }, function(errMsg) {
    document.getElementById('vs-bw-step5-error').textContent = errMsg || 'Something went wrong. Please try again.';
    btn.disabled = false; btn.textContent = 'Confirm Booking →';
  });
};

function vsBWShowConfirmation(t) {
  var p = _vsBW.pkg;
  var dateLabel = _vsBW.date ? new Date(_vsBW.date + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' }) : '';
  var msgTemplate = _vsBWT('confirm_message', 'The vendor has received your request for {name} on {date} at {time} and will confirm shortly.');
  var msg = msgTemplate
    .replace('{name}', '<strong>' + vsEsc(p.name) + '</strong>')
    .replace('{date}', '<strong>' + vsEsc(dateLabel) + '</strong>')
    .replace('{time}', '<strong>' + vsEsc(_vsBW.time || '') + '</strong>');
  document.getElementById('vs-bw-progress').innerHTML = '';
  document.getElementById('vs-bw-nav').innerHTML = '';
  document.getElementById('vs-bw-body').innerHTML =
    '<div class="vs-bw-step-content vs-bw-confirmation">' +
      '<div class="vs-bw-confirm-icon">✓</div>' +
      '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('confirm_title', 'Booking request sent!')) + '</h2>' +
      '<p class="vs-bw-confirm-sub">' + msg + '</p>' +
      '<div class="vs-bw-summary-block"><div class="vs-bw-sum-row vs-bw-sum-total"><span>Total</span><span>' + vsBWCurrency(t.total) + '</span></div></div>' +
      '<button type="button" class="vs-bw-btn-primary" onclick="vsCloseBookingWizard()" style="width:100%;margin-top:20px">' + vsEsc(_vsBWT('btn_done', 'Done')) + '</button>' +
    '</div>';
}

window.vsBWNext = function() { if (_vsBW.step < _vsBW.totalSteps) { _vsBW.step++; vsBWRenderStep(); } };
window.vsBWBack = function() { if (_vsBW.step > 1) { _vsBW.step--; vsBWRenderStep(); } };

/* ═══════════════════════════════════════════════════════════════════════
   Service Wizard steps — tailored to a service booking/enquiry journey:
   review the service, pick a date & time (reuses Step 2 directly), describe
   project requirements, provide contact details (reuses Step 4 directly),
   then a summary tailored to an enquiry rather than a priced purchase.
   ═══════════════════════════════════════════════════════════════════════ */

function vsSvcWizStep1() {
  var s = _vsBW.svc;
  var hlHtml = (s.highlights || []).map(function(h) { return '<li>' + vsEsc(h) + '</li>'; }).join('');
  var metaRows = [];
  if (s.availability) { metaRows.push('<div class="vs-bw-meta-row"><span class="vs-bw-meta-label">' + vsEsc(_vsBWT('step1_availability_label', 'Availability')) + '</span><span class="vs-bw-meta-value">' + vsEsc(s.availability) + '</span></div>'); }
  if (s.duration) { metaRows.push('<div class="vs-bw-meta-row"><span class="vs-bw-meta-label">' + vsEsc(_vsBWT('step1_duration_label', 'Delivery / Response Time')) + '</span><span class="vs-bw-meta-value">' + vsEsc(s.duration) + '</span></div>'); }
  var content = '<div class="vs-bw-step-content">' +
    '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('step1_title', 'Review this service')) + '</h2>' +
    (_vsBWT('step1_intro', '') ? '<p class="vs-bw-step-intro">' + vsEsc(_vsBWT('step1_intro', '')) + '</p>' : '') +
    '<div class="vs-bw-pkg-card">' +
      (s.image ? '<img src="' + s.image + '" class="vs-bw-pkg-img" alt="" width="72" height="72">' : '') +
      '<div><div class="vs-bw-pkg-name">' + vsEsc(s.name || '') + '</div>' +
      (s.price ? '<div class="vs-bw-pkg-price">' + (s.currency || '₹') + s.price + '</div>' : '') +
      (s.full_description ? '<div class="vs-bw-pkg-desc">' + vsEsc(s.full_description) + '</div>' : '') + '</div>' +
    '</div>' +
    (metaRows.length ? '<div class="vs-bw-meta-rows">' + metaRows.join('') + '</div>' : '') +
    (hlHtml ? '<div class="vs-bw-subhead">' + vsEsc(_vsBWT('step1_highlights_label', 'Highlights')) + '</div><ul class="vs-bw-feat-list">' + hlHtml + '</ul>' : '') +
  '</div>';
  var nav = '<span></span><button type="button" class="vs-bw-btn-primary" onclick="vsBWNext()">' + vsEsc(_vsBWT('btn_continue', 'Continue →')) + '</button>';
  return { content: content, nav: nav };
}

function vsSvcWizStep3() {
  var content = '<div class="vs-bw-step-content">' +
    '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('step3_title', 'Tell us about your requirements')) + '</h2>' +
    '<div class="vs-bw-field"><label>' + vsEsc(_vsBWT('step3_field_label', 'What do you need help with?')) + ' <span>(optional but helps the vendor prepare)</span></label>' +
    '<textarea id="vs-svc-requirements" rows="5" placeholder="Describe your project, requirements, or any specific details...">' + vsEsc(_vsBW.requirements || '') + '</textarea></div>' +
  '</div>';
  var nav = '<button type="button" class="vs-bw-btn-secondary" onclick="vsBWBack()">' + vsEsc(_vsBWT('btn_back', '← Back')) + '</button><button type="button" class="vs-bw-btn-primary" onclick="vsSvcWizStep3Next()">' + vsEsc(_vsBWT('btn_continue', 'Continue →')) + '</button>';
  return { content: content, nav: nav };
}
window.vsSvcWizStep3Next = function() {
  var el = document.getElementById('vs-svc-requirements');
  _vsBW.requirements = el ? el.value.trim() : '';
  vsBWNext();
};

function vsSvcWizStep5() {
  var s = _vsBW.svc;
  var dateLabel = _vsBW.date ? new Date(_vsBW.date + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' }) : '';
  var content = '<div class="vs-bw-step-content">' +
    '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('step5_title', 'Review & submit')) + '</h2>' +
    '<div class="vs-bw-summary-block">' +
      '<div class="vs-bw-sum-row"><span>Service</span><strong>' + vsEsc(s.name) + '</strong></div>' +
      (_vsBW.specialist && _vsBW.specialist.specialist_name ? '<div class="vs-bw-sum-row"><span>Specialist</span><strong>' + vsEsc(_vsBW.specialist.specialist_name) + '</strong></div>' : '') +
      '<div class="vs-bw-sum-row"><span>Preferred date & time</span><strong>' + vsEsc(dateLabel) + ', ' + vsEsc(_vsBW.time || '') + '</strong></div>' +
      '<div class="vs-bw-sum-row"><span>Customer</span><strong>' + vsEsc(_vsBW.cust.name) + ' · ' + vsEsc(_vsBW.cust.phone) + '</strong></div>' +
    '</div>' +
    (_vsBW.requirements ? '<div class="vs-bw-divider"></div><div class="vs-bw-summary-block"><div class="vs-bw-sum-row" style="flex-direction:column;align-items:flex-start"><span style="margin-bottom:6px">Your requirements</span><span style="color:#334155">' + vsEsc(_vsBW.requirements) + '</span></div></div>' : '') +
    '<div class="vs-bw-payment-note">' + vsEsc(_vsBWT('step5_note', '📋 This is a booking enquiry — the vendor will confirm availability and pricing directly with you.')) + '</div>' +
    '<div class="vs-bw-error" id="vs-bw-step5-error"></div>' +
  '</div>';
  var nav = '<button type="button" class="vs-bw-btn-secondary" onclick="vsBWBack()">' + vsEsc(_vsBWT('btn_back', '← Back')) + '</button><button type="button" class="vs-bw-btn-primary" id="vs-bw-submit-btn" onclick="vsSvcWizSubmit()">' + vsEsc(_vsBWT('btn_submit', 'Submit Enquiry →')) + '</button>';
  return { content: content, nav: nav };
}

window.vsSvcWizSubmit = function() {
  var btn = document.getElementById('vs-bw-submit-btn');
  var s = _vsBW.svc;
  var effectiveListingId = s.listing_id || window.LID || 0;
  if (!effectiveListingId) {
    document.getElementById('vs-bw-step5-error').textContent = 'Could not identify this listing — please refresh the page and try again.';
    return;
  }
  btn.disabled = true; btn.textContent = 'Submitting…';
  var dateLabel = _vsBW.date ? new Date(_vsBW.date + 'T00:00:00').toLocaleDateString() : '';
  var message = 'SERVICE BOOKING ENQUIRY via Service Wizard\n' +
    'Service: ' + s.name + '\n' +
    (_vsBW.specialist && _vsBW.specialist.specialist_name ? ('Preferred Specialist: ' + _vsBW.specialist.specialist_name + '\n') : '') +
    'Preferred Date & Time: ' + dateLabel + ' at ' + (_vsBW.time || '') + '\n' +
    (_vsBW.requirements ? ('Requirements: ' + _vsBW.requirements + '\n') : '');
  gsPost('gs_submit_lead', {
    listing_id: effectiveListingId, name: _vsBW.cust.name, phone: _vsBW.cust.phone,
    email: _vsBW.cust.email || '', product_name: s.name, message: message, source: 'service_wizard',
    booking_date: _vsBW.date, booking_time: _vsBW.time,
    specialist_id: (_vsBW.specialist && _vsBW.specialist.specialist_id) || '',
    specialist_name: (_vsBW.specialist && _vsBW.specialist.specialist_name) || ''
  }, function(d) {
    vsSvcWizShowConfirmation();
  }, function(errMsg) {
    var displayMsg = errMsg || 'Something went wrong. Please try again.';
    if (errMsg && /invalid listing/i.test(errMsg)) {
      displayMsg += ' [Diagnostic: s.listing_id=' + JSON.stringify(s.listing_id) + ', window.LID=' + JSON.stringify(window.LID) + ', sent=' + JSON.stringify(effectiveListingId) + ' — please screenshot this and share it]';
    }
    document.getElementById('vs-bw-step5-error').textContent = displayMsg;
    btn.disabled = false; btn.textContent = 'Submit Enquiry →';
  });
};

function vsSvcWizShowConfirmation() {
  var s = _vsBW.svc;
  var dateLabel = _vsBW.date ? new Date(_vsBW.date + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' }) : '';
  var msgTemplate = _vsBWT('confirm_message', 'The vendor has received your enquiry for {name} on {date} at {time} and will get back to you shortly.');
  var msg = msgTemplate
    .replace('{name}', '<strong>' + vsEsc(s.name) + '</strong>')
    .replace('{date}', '<strong>' + vsEsc(dateLabel) + '</strong>')
    .replace('{time}', '<strong>' + vsEsc(_vsBW.time || '') + '</strong>');
  if (_vsBW.specialist && _vsBW.specialist.specialist_name) {
    msg += ' Requested specialist: <strong>' + vsEsc(_vsBW.specialist.specialist_name) + '</strong>.';
  }
  document.getElementById('vs-bw-progress').innerHTML = '';
  document.getElementById('vs-bw-nav').innerHTML = '';
  document.getElementById('vs-bw-body').innerHTML =
    '<div class="vs-bw-step-content vs-bw-confirmation">' +
      '<div class="vs-bw-confirm-icon">✓</div>' +
      '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('confirm_title', 'Enquiry sent!')) + '</h2>' +
      '<p class="vs-bw-confirm-sub">' + msg + '</p>' +
      '<button type="button" class="vs-bw-btn-primary" onclick="vsCloseBookingWizard()" style="width:100%;margin-top:10px">' + vsEsc(_vsBWT('btn_done', 'Done')) + '</button>' +
    '</div>';
}

/* ═══════════════════════════════════════════════════════════════════════
   Product Quote wizard steps — a genuinely different journey from both
   Packages and Services: no date/time step at all (a quote request isn't
   scheduled), replaced with quantity/specifications, and requirements
   with a file-attachment field. NOTE: file upload is intentionally NOT
   wired to a backend endpoint here — gs_upload_media is scoped to
   authenticated vendors (their own quota/media-library ownership), which
   is the wrong fit for an anonymous customer attaching a file to a quote
   request. Building a properly secured public upload endpoint (file type
   validation, size limits, storage isolation) is real, separate work
   this pass doesn't responsibly cover — the field is shown but disabled
   with a clear explanation rather than silently doing nothing on submit.
   ═══════════════════════════════════════════════════════════════════════ */

function vsProdWizStep1() {
  var p = _vsBW.prod;
  var kfHtml = (p.key_features || []).map(function(k) { return '<li>' + vsEsc(k) + '</li>'; }).join('');
  var metaRows = [];
  if (p.availability) { metaRows.push('<div class="vs-bw-meta-row"><span class="vs-bw-meta-label">' + vsEsc(_vsBWT('step1_availability_label', 'Availability')) + '</span><span class="vs-bw-meta-value">' + vsEsc(p.availability) + '</span></div>'); }
  if (p.delivery_info) { metaRows.push('<div class="vs-bw-meta-row"><span class="vs-bw-meta-label">' + vsEsc(_vsBWT('step1_delivery_label', 'Delivery / Response Time')) + '</span><span class="vs-bw-meta-value">' + vsEsc(p.delivery_info) + '</span></div>'); }
  var content = '<div class="vs-bw-step-content">' +
    '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('step1_title', 'Review this product')) + '</h2>' +
    (_vsBWT('step1_intro', '') ? '<p class="vs-bw-step-intro">' + vsEsc(_vsBWT('step1_intro', '')) + '</p>' : '') +
    '<div class="vs-bw-pkg-card">' +
      (p.image ? '<img src="' + p.image + '" class="vs-bw-pkg-img" alt="" width="72" height="72">' : '') +
      '<div><div class="vs-bw-pkg-name">' + vsEsc(p.name || '') + '</div>' +
      (p.price ? '<div class="vs-bw-pkg-price">' + (p.currency || '₹') + p.price + '</div>' : '') +
      (p.full_description ? '<div class="vs-bw-pkg-desc">' + vsEsc(p.full_description) + '</div>' : '') + '</div>' +
    '</div>' +
    (metaRows.length ? '<div class="vs-bw-meta-rows">' + metaRows.join('') + '</div>' : '') +
    (kfHtml ? '<div class="vs-bw-subhead">' + vsEsc(_vsBWT('step1_features_label', 'Key Features')) + '</div><ul class="vs-bw-feat-list">' + kfHtml + '</ul>' : '') +
  '</div>';
  var nav = '<span></span><button type="button" class="vs-bw-btn-primary" onclick="vsBWNext()">' + vsEsc(_vsBWT('btn_continue', 'Continue →')) + '</button>';
  return { content: content, nav: nav };
}

function vsProdWizStep2() {
  var content = '<div class="vs-bw-step-content">' +
    '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('step2_title', 'Quantity & specifications')) + '</h2>' +
    '<div class="vs-bw-field"><label>' + vsEsc(_vsBWT('step2_qty_label', 'Quantity needed')) + '</label><input type="number" id="vs-prod-qty" min="1" value="' + (_vsBW.quantity || 1) + '"></div>' +
    '<div class="vs-bw-field"><label>' + vsEsc(_vsBWT('step2_specs_label', 'Specifications')) + ' <span>(size, color, custom options, etc. — optional)</span></label>' +
    '<textarea id="vs-prod-specs" rows="3" placeholder="Any specific variant, size, or customization needed...">' + vsEsc(_vsBW.specs || '') + '</textarea></div>' +
  '</div>';
  var nav = '<button type="button" class="vs-bw-btn-secondary" onclick="vsBWBack()">' + vsEsc(_vsBWT('btn_back', '← Back')) + '</button><button type="button" class="vs-bw-btn-primary" onclick="vsProdWizStep2Next()">' + vsEsc(_vsBWT('btn_continue', 'Continue →')) + '</button>';
  return { content: content, nav: nav };
}
window.vsProdWizStep2Next = function() {
  var qtyEl = document.getElementById('vs-prod-qty');
  var specsEl = document.getElementById('vs-prod-specs');
  _vsBW.quantity = qtyEl ? (parseInt(qtyEl.value, 10) || 1) : 1;
  _vsBW.specs = specsEl ? specsEl.value.trim() : '';
  vsBWNext();
};

function vsProdWizStep3() {
  var content = '<div class="vs-bw-step-content">' +
    '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('step3_title', 'Purchase requirements')) + '</h2>' +
    '<div class="vs-bw-field"><label>' + vsEsc(_vsBWT('step3_field_label', 'Tell us more about your requirements')) + ' <span>(optional)</span></label>' +
    '<textarea id="vs-prod-requirements" rows="4" placeholder="Delivery timeline, bulk order details, or anything else the vendor should know...">' + vsEsc(_vsBW.requirements || '') + '</textarea></div>' +
    '<div class="vs-bw-field"><label>Attach a file <span>(coming soon)</span></label>' +
    '<input type="file" disabled style="width:100%;padding:10px;border:1.5px dashed #E2E8F0;border-radius:9px;color:#475569;cursor:not-allowed">' +
    '<div class="vs-bw-payment-note" style="margin-top:8px">📎 File attachments aren\'t available yet — mention any reference files in your message above and the vendor can request them directly.</div></div>' +
  '</div>';
  var nav = '<button type="button" class="vs-bw-btn-secondary" onclick="vsBWBack()">' + vsEsc(_vsBWT('btn_back', '← Back')) + '</button><button type="button" class="vs-bw-btn-primary" onclick="vsProdWizStep3Next()">' + vsEsc(_vsBWT('btn_continue', 'Continue →')) + '</button>';
  return { content: content, nav: nav };
}
window.vsProdWizStep3Next = function() {
  var el = document.getElementById('vs-prod-requirements');
  _vsBW.requirements = el ? el.value.trim() : '';
  vsBWNext();
};

function vsProdWizStep5() {
  var p = _vsBW.prod;
  var content = '<div class="vs-bw-step-content">' +
    '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('step5_title', 'Review & submit quote request')) + '</h2>' +
    '<div class="vs-bw-summary-block">' +
      '<div class="vs-bw-sum-row"><span>Product</span><strong>' + vsEsc(p.name) + '</strong></div>' +
      '<div class="vs-bw-sum-row"><span>Quantity</span><strong>' + (_vsBW.quantity || 1) + '</strong></div>' +
      (_vsBW.specs ? '<div class="vs-bw-sum-row"><span>Specifications</span><strong>' + vsEsc(_vsBW.specs) + '</strong></div>' : '') +
      '<div class="vs-bw-sum-row"><span>Customer</span><strong>' + vsEsc(_vsBW.cust.name) + ' · ' + vsEsc(_vsBW.cust.phone) + '</strong></div>' +
    '</div>' +
    (_vsBW.requirements ? '<div class="vs-bw-divider"></div><div class="vs-bw-summary-block"><div class="vs-bw-sum-row" style="flex-direction:column;align-items:flex-start"><span style="margin-bottom:6px">Your requirements</span><span style="color:#334155">' + vsEsc(_vsBW.requirements) + '</span></div></div>' : '') +
    '<div class="vs-bw-payment-note">' + vsEsc(_vsBWT('step5_note', '📋 This is a quote request — the vendor will confirm pricing and availability directly with you.')) + '</div>' +
    '<div class="vs-bw-error" id="vs-bw-step5-error"></div>' +
  '</div>';
  var nav = '<button type="button" class="vs-bw-btn-secondary" onclick="vsBWBack()">' + vsEsc(_vsBWT('btn_back', '← Back')) + '</button><button type="button" class="vs-bw-btn-primary" id="vs-bw-submit-btn" onclick="vsProdWizSubmit()">' + vsEsc(_vsBWT('btn_submit', 'Submit Quote Request →')) + '</button>';
  return { content: content, nav: nav };
}

window.vsProdWizSubmit = function() {
  var btn = document.getElementById('vs-bw-submit-btn');
  var p = _vsBW.prod;
  var effectiveListingId = p.listing_id || window.LID || 0;
  if (!effectiveListingId) {
    document.getElementById('vs-bw-step5-error').textContent = 'Could not identify this listing — please refresh the page and try again.';
    return;
  }
  btn.disabled = true; btn.textContent = 'Submitting…';
  var message = 'PRODUCT QUOTE REQUEST via Product Wizard\n' +
    'Product: ' + p.name + '\n' +
    'Quantity: ' + (_vsBW.quantity || 1) + '\n' +
    (_vsBW.specs ? ('Specifications: ' + _vsBW.specs + '\n') : '') +
    (_vsBW.requirements ? ('Requirements: ' + _vsBW.requirements + '\n') : '');
  gsPost('gs_submit_lead', {
    listing_id: effectiveListingId, name: _vsBW.cust.name, phone: _vsBW.cust.phone,
    email: _vsBW.cust.email || '', product_name: p.name, message: message, source: 'product_wizard'
  }, function(d) {
    vsProdWizShowConfirmation();
  }, function(errMsg) {
    var displayMsg = errMsg || 'Something went wrong. Please try again.';
    if (errMsg && /invalid listing/i.test(errMsg)) {
      displayMsg += ' [Diagnostic: p.listing_id=' + JSON.stringify(p.listing_id) + ', window.LID=' + JSON.stringify(window.LID) + ', sent=' + JSON.stringify(effectiveListingId) + ' — please screenshot this and share it]';
    }
    document.getElementById('vs-bw-step5-error').textContent = displayMsg;
    btn.disabled = false; btn.textContent = 'Submit Quote Request →';
  });
};

function vsProdWizShowConfirmation() {
  var p = _vsBW.prod;
  var msgTemplate = _vsBWT('confirm_message', 'The vendor has received your quote request for {name} (Qty: {qty}) and will get back to you with pricing shortly.');
  var msg = msgTemplate
    .replace('{name}', '<strong>' + vsEsc(p.name) + '</strong>')
    .replace('{qty}', String(_vsBW.quantity || 1));
  document.getElementById('vs-bw-progress').innerHTML = '';
  document.getElementById('vs-bw-nav').innerHTML = '';
  document.getElementById('vs-bw-body').innerHTML =
    '<div class="vs-bw-step-content vs-bw-confirmation">' +
      '<div class="vs-bw-confirm-icon">✓</div>' +
      '<h2 class="vs-bw-title">' + vsEsc(_vsBWT('confirm_title', 'Quote request sent!')) + '</h2>' +
      '<p class="vs-bw-confirm-sub">' + msg + '</p>' +
      '<button type="button" class="vs-bw-btn-primary" onclick="vsCloseBookingWizard()" style="width:100%;margin-top:10px">' + vsEsc(_vsBWT('btn_done', 'Done')) + '</button>' +
    '</div>';
}

// ═══════════════════════════════════════════════════════════════════════════
// Comprehensive Booking Wizard diagnostic — answers "is this the new code
// or a stale/cached version, and exactly what does the DOM look like right
// now" with hard facts, not guesses. Call from the browser console as
// vsDiagBookingWizard(), or click the 🔬 button injected next to any
// "Book Now"/Add button when this script loads (see bottom of this
// function for the auto-injected trigger).
// ═══════════════════════════════════════════════════════════════════════════
window.vsDiagBookingWizard = function() {
  var report = [];
  var pass = function(label, detail) { report.push({ ok: true, label: label, detail: detail }); };
  var fail = function(label, detail) { report.push({ ok: false, label: label, detail: detail }); };

  // ── Check 1: are the wizard functions even defined? (catches: script
  // block didn't load at all, or an earlier JS error on the page stopped
  // parsing before this block ran) ──
  ['vsOpenBookingWizard', 'vsBWRenderStep', 'vsBWStep1', 'vsCloseBookingWizard'].forEach(function(fn) {
    if (typeof window[fn] === 'function' || typeof fn === 'function') {
      pass('Function "' + fn + '" is defined', 'typeof = function');
    } else {
      fail('Function "' + fn + '" is defined', 'typeof = ' + (typeof window[fn]));
    }
  });

  // ── Check 2: THE definitive check — what does the ACTUAL, currently
  // running vsBWStep1 function's source code look like? If this deployment
  // didn't take effect (stale cache, wrong file, etc.), this will show the
  // OLD source (nav embedded in content) instead of the NEW one
  // (content/nav returned separately) — no guessing needed, the literal
  // running code is shown verbatim. ──
  try {
    var src = (typeof vsBWStep1 === 'function' ? vsBWStep1.toString() : 'vsBWStep1 is not a function');
    var hasNewShape = src.indexOf('return { content: content, nav: nav }') !== -1;
    var hasOldEmbeddedNav = src.indexOf('vs-bw-nav\\"><span></span><button') !== -1 && !hasNewShape;
    if (hasNewShape) {
      pass('vsBWStep1 source shape', 'NEW code confirmed — returns {content, nav} separately (the version with the fix).');
    } else if (hasOldEmbeddedNav) {
      fail('vsBWStep1 source shape', 'OLD/STALE code detected — the nav button is still embedded inside the scrollable content string. This means the deployed file does NOT contain the fix, regardless of what was uploaded — check for page/object/opcode caching, a CDN, or that the correct file actually got deployed to the live path.');
    } else {
      fail('vsBWStep1 source shape', 'Could not determine shape — here is the literal running source for manual inspection: ' + src.substring(0, 400));
    }
  } catch (e) {
    fail('vsBWStep1 source shape', 'Threw an error while inspecting: ' + e.message);
  }

  // ── Check 3: actually open the wizard with a real, minimal package and
  // inspect the real DOM afterward — not a simulation, the actual overlay
  // this page builds. ──
  var testPkg = { name: 'Diagnostic Test Package', price: 999, period: '1 hr', description: 'Test', image: '', features: ['Test feature 1', 'Test feature 2'], addons: [], gst_type: 'not_applicable', gst_percent: 0, currency: '₹', listing_id: (window.LID || 0) };
  var fakeTrigger = document.createElement('button');
  fakeTrigger.setAttribute('data-pkg', JSON.stringify(testPkg));

  try {
    vsOpenBookingWizard(fakeTrigger);
    pass('vsOpenBookingWizard() executed', 'No error thrown.');
  } catch (e) {
    fail('vsOpenBookingWizard() executed', 'Threw: ' + e.message + '\n' + e.stack);
  }

  setTimeout(function() {
    var overlay = document.getElementById('vs-bw-overlay');
    var navEl = document.getElementById('vs-bw-nav');
    var bodyEl = document.getElementById('vs-bw-body');

    if (!overlay) { fail('#vs-bw-overlay exists in DOM', 'NOT FOUND — the overlay was never created or was immediately removed.'); }
    else { pass('#vs-bw-overlay exists in DOM', 'Found.'); }

    if (!navEl) {
      fail('#vs-bw-nav exists in DOM', 'NOT FOUND — this element should be a sibling of #vs-bw-body inside .vs-bw-sheet. If missing, the overlay HTML itself is stale (old skeleton without this element).');
    } else {
      pass('#vs-bw-nav exists in DOM', 'Found.');
      var navStyle = window.getComputedStyle(navEl);
      var navRect = navEl.getBoundingClientRect();
      report.push({ ok: navRect.height > 0, label: '#vs-bw-nav computed layout', detail:
        'display=' + navStyle.display + ', visibility=' + navStyle.visibility + ', height=' + navRect.height + 'px, width=' + navRect.width + 'px, top=' + navRect.top + ', innerHTML length=' + navEl.innerHTML.length + ', innerHTML="' + navEl.innerHTML.substring(0, 200) + '"'
      });
      var btn = navEl.querySelector('button');
      if (!btn) {
        fail('Continue button inside #vs-bw-nav', 'NOT FOUND inside #vs-bw-nav. #vs-bw-nav innerHTML was: "' + navEl.innerHTML + '"');
      } else {
        var btnRect = btn.getBoundingClientRect();
        var btnStyle = window.getComputedStyle(btn);
        report.push({ ok: btnRect.height > 0 && btnStyle.display !== 'none' && btnStyle.visibility !== 'hidden', label: 'Continue button computed layout', detail:
          'text="' + btn.textContent + '", display=' + btnStyle.display + ', visibility=' + btnStyle.visibility + ', opacity=' + btnStyle.opacity + ', height=' + btnRect.height + 'px, top=' + btnRect.top + ', left=' + btnRect.left + ', in-viewport=' + (btnRect.top >= 0 && btnRect.top < window.innerHeight)
        });
      }
    }

    if (bodyEl) {
      report.push({ ok: true, label: '#vs-bw-body content (first 300 chars)', detail: bodyEl.innerHTML.substring(0, 300) });
    }

    vsRenderDiagBookingWizardReport(report);
    vsCloseBookingWizard();
  }, 150);
};

function vsRenderDiagBookingWizardReport(report) {
  var existing = document.getElementById('vs-bw-diag-panel');
  if (existing) existing.remove();
  var failCount = report.filter(function(r) { return !r.ok; }).length;
  var box = document.createElement('div');
  box.id = 'vs-bw-diag-panel';
  box.style.cssText = 'position:fixed;top:16px;right:16px;left:16px;max-width:680px;margin-left:auto;background:#0F172A;color:#E2E8F0;padding:20px;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,.5);z-index:999999;font-family:monospace;font-size:.74rem;line-height:1.6;max-height:82vh;overflow-y:auto';
  var html = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">' +
    '<strong style="color:' + (failCount ? '#F87171' : '#4ADE80') + ';font-family:-apple-system,sans-serif;font-size:.95rem">' + (failCount ? '⚠️ ' + failCount + ' check(s) failed' : '✅ All checks passed') + ' — Booking Wizard Diagnostic</strong>' +
    '<button onclick="document.getElementById(\'vs-bw-diag-panel\').remove()" style="background:#374151;color:#fff;border:none;width:26px;height:26px;border-radius:50%;cursor:pointer;flex-shrink:0">✕</button>' +
  '</div>';
  report.forEach(function(r) {
    html += '<div style="margin-bottom:10px;padding:8px 10px;background:' + (r.ok ? 'rgba(74,222,128,.08)' : 'rgba(248,113,113,.1)') + ';border-left:3px solid ' + (r.ok ? '#4ADE80' : '#F87171') + ';border-radius:4px">' +
      '<div style="color:' + (r.ok ? '#4ADE80' : '#F87171') + ';font-weight:700">' + (r.ok ? '✓' : '✗') + ' ' + r.label.replace(/</g,'&lt;') + '</div>' +
      '<div style="color:#475569;margin-top:3px;word-break:break-all;white-space:pre-wrap">' + String(r.detail).replace(/</g,'&lt;') + '</div>' +
    '</div>';
  });
  html += '<div style="margin-top:10px;font-size:.68rem;color:#64748B;font-family:-apple-system,sans-serif">Screenshot this whole panel and send it — it has everything needed to fix this precisely, no guessing required.</div>';
  box.innerHTML = html;
  document.body.appendChild(box);
}
<?php endif; // $_any_wizard_enabled ?>

window.vsCloseDetailPopup = function() {
  var popup = document.getElementById('vs-detail-popup');
  if (popup) popup.classList.remove('open');
  document.body.style.overflow = '';
  vsPopupSliderStopAuto();
};
document.addEventListener('keydown', function(e){
  if (e.key !== 'Escape') return;
  var lb = document.getElementById('vs-lightbox');
  if (lb && lb.classList.contains('open')) { return; } // the lightbox's own Escape handler closes it and leaves the popup underneath intact
  vsCloseDetailPopup();
});

// Real feature — Client Reviews section inside the reused View Details
// popup. Fetches one page at a time (rather than embedding every review
// in data-sections, which would be heavy and non-paginatable) via a new
// lightweight endpoint that reuses the existing ReviewRepository.
<?php
// Real feature — reviews-loading JS is only ever called when a "reviews"
// content-type section is actually rendered in a View More popup, which
// itself only happens when one of these three toggles is on. Small
// (~2.3KB), isolated, single call site — safe to gate independently.
$_any_reviews_enabled = ( $cd['packages_show_reviews'] ?? 1 ) || ( $cd['services_show_reviews'] ?? 1 ) || ( $cd['items_show_reviews'] ?? 1 );
if ( $_any_reviews_enabled ):
?>
function vsLoadDetailPopupReviews(container, page) {
  var listingId = container.getAttribute('data-listing-id');
  if (!listingId || listingId === '0') {
    container.innerHTML = '<div class="vs-dp-reviews-empty">No reviews yet.</div>';
    return;
  }
  container.setAttribute('data-page', page);
  if (page === 1) { container.innerHTML = '<div class="vs-dp-reviews-loading">Loading reviews…</div>'; }
  gsPost('gs_get_popup_reviews_page', { listing_id: listingId, page: page }, function(d) {
    var html = '';
    if (page === 1) {
      if (!d.reviews || !d.reviews.length) {
        container.innerHTML = '<div class="vs-dp-reviews-empty">No reviews yet.</div>';
        return;
      }
      html += '<div class="vs-dp-reviews-list" id="vs-dp-reviews-list-' + listingId + '"></div>';
      container.innerHTML = html;
    }
    var listEl = document.getElementById('vs-dp-reviews-list-' + listingId);
    var existingBtn = container.querySelector('.vs-dp-reviews-more');
    if (existingBtn) existingBtn.remove();
    (d.reviews || []).forEach(function(r) {
      var stars = '★'.repeat(r.rating) + '☆'.repeat(5 - r.rating);
      var ratingClass = r.rating >= 4 ? 'good' : (r.rating >= 3 ? 'mid' : 'low');
      var card = document.createElement('div');
      card.className = 'vs-dp-review-card';
      card.innerHTML =
        '<div class="vs-dp-review-top">' +
          '<div class="vs-dp-review-name">' + vsEsc(r.reviewer_name || 'Anonymous') + '</div>' +
          '<div class="vs-dp-review-rating ' + ratingClass + '">' + r.rating + ' ' + stars.charAt(0) + '</div>' +
        '</div>' +
        '<div class="vs-dp-review-date">' + vsEsc(r.date_display || '') + '</div>' +
        '<div class="vs-dp-review-text">' + vsEsc(r.review_text || '') + '</div>';
      listEl.appendChild(card);
    });
    if (d.has_more) {
      var moreBtn = document.createElement('button');
      moreBtn.type = 'button';
      moreBtn.className = 'vs-dp-reviews-more';
      moreBtn.textContent = 'Load more reviews';
      moreBtn.onclick = function() { vsLoadDetailPopupReviews(container, page + 1); };
      container.appendChild(moreBtn);
    }
  }, function() {
    if (page === 1) { container.innerHTML = '<div class="vs-dp-reviews-empty">Could not load reviews right now.</div>'; }
  });
}
<?php endif; // $_any_reviews_enabled ?>

window.vsOpenSvcEnquiry=function(name,price,extraJson){
  if (window.GS_SVC_WIZARD_ENABLED) {
    var extra = {};
    try { extra = extraJson ? JSON.parse(extraJson) : {}; } catch(e) { extra = {}; }
    vsOpenServiceWizard({
      name: name || '', price: price || '', listing_id: window.LID || 0, currency: '₹',
      full_description: extra.full_description || '', duration: extra.duration || '', availability: extra.availability || '',
      highlights: Array.isArray(extra.highlights) ? extra.highlights : []
    });
    return;
  }
  vsOpenInquiry({name:name||'',type:'service',price:price||''});
};
window.vsOpenQuote=function(name,price,extraJson){
  if (window.GS_PROD_WIZARD_ENABLED) {
    var extra = {};
    try { extra = extraJson ? JSON.parse(extraJson) : {}; } catch(e) { extra = {}; }
    vsOpenProductWizard({
      name: name || '', price: price || '', listing_id: window.LID || 0, currency: '₹',
      full_description: extra.full_description || '', availability: extra.availability || '',
      delivery_info: extra.delivery_info || '',
      key_features: Array.isArray(extra.key_features) ? extra.key_features : []
    });
    return;
  }
  vsOpenInquiry({name:name||'',type:'product',price:price||''});
};
window.vsOpenInquiry=function(item){
  var o      = document.getElementById('vs-inq-overlay');
  var title  = document.getElementById('vs-inq-title');
  var badge  = document.getElementById('vs-inq-badge');
  var iconEl = document.getElementById('vs-inq-icon');
  var qr     = document.getElementById('vs-inq-qty-row');
  if (!o) return; // safety guard

  // Switch header colour based on popup type
  var hdrBg = _vsInqHdrGen;
  if (item && item.type === 'service') hdrBg = _vsInqHdrSvc;
  else if (item && item.type === 'product') hdrBg = _vsInqHdrPrd;
  o.style.setProperty('--vs-inq-hdr-bg', hdrBg);

  if (item && item.name) {
    var isProduct = (item.type === 'product');
    title.textContent = (isProduct ? 'Product Quote: ' : 'Service Enquiry: ') + item.name;
    if (iconEl) iconEl.textContent = isProduct ? '📦' : '🛠️';
    badge.style.display = 'inline-flex';
    badge.textContent   = (isProduct ? '📦 ' : '🛠️ ') + item.name +
                          (item.price ? '  ·  ' + item.price : '');
    document.getElementById('vs-inq-iname').value  = item.name;
    document.getElementById('vs-inq-iprice').value = item.price || '';
    document.getElementById('vs-inq-itype').value  = item.type  || '';
    qr.style.display = isProduct ? 'grid' : 'none';
  } else {
    title.textContent = 'Send Enquiry';
    if (iconEl) iconEl.textContent = '📋';
    badge.style.display = 'none';
    document.getElementById('vs-inq-iname').value  = '';
    document.getElementById('vs-inq-iprice').value = '';
    document.getElementById('vs-inq-itype').value  = '';
    qr.style.display = 'none';
  }

  // Set min dates to today/now
  var today = new Date().toISOString().split('T')[0];
  var now   = new Date(); now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  var nowStr = now.toISOString().slice(0,16);
  var pd = document.getElementById('vs-inq-pdate');  if (pd) pd.min = today;
  var cd = document.getElementById('vs-inq-cdate');  if (cd) cd.min = nowStr;

  // Reset submit button + message
  var msgEl = document.getElementById('vs-inq-msg');
  if (msgEl) { msgEl.style.display = 'none'; msgEl.textContent = ''; }
  var btn    = document.getElementById('vs-inq-submit');
  var btnTxt = document.getElementById('vs-inq-submit-txt');
  if (btn)    { btn.disabled = false; }
  if (btnTxt) { btnTxt.textContent = 'Send Enquiry'; }

  o.classList.add('open');
  document.body.style.overflow = 'hidden';
  setTimeout(function(){ var n = document.getElementById('vs-inq-name'); if (n) n.focus(); }, 140);
};
window.vsCloseInquiry=function(){
  var o = document.getElementById('vs-inq-overlay');
  if (o) o.classList.remove('open');
  document.body.style.overflow = '';
};

/* ── Events & Wedding, Section 10 — Check Availability ────────────
   No real per-date calendar exists for this vertical (see
   WeddingAvailabilityModule's header comment), so this does not check
   anything itself — it reuses the platform's real, existing enquiry
   popup (window.vsOpenInquiry, the same mechanism wedding_packages'
   "Request a Quote" CTA already opens) verbatim, folding the customer's
   picked date into the enquiry's own Requirements/Message field so the
   vendor sees exactly what date is being asked about. */
window.vsWeddingCheckAvailability=function(){
  var dateEl = document.getElementById('gs-wedding-avail-date');
  var picked = dateEl ? dateEl.value : '';
  vsOpenInquiry({ name: 'Event Date Availability', type: 'service' });
  var remarksEl = document.getElementById('vs-inq-remarks');
  if (remarksEl) {
    remarksEl.value = picked
      ? 'Requesting availability for event date: ' + picked
      : 'Requesting availability — please advise on open dates.';
  }
};

/* ── Events & Wedding, Section 11 — Request a Quote ────────────────
   Same honest-reuse discipline as vsWeddingCheckAvailability() above
   (see WeddingQuoteModule's header comment for the full investigation):
   no new submission path is invented. Every value the visitor typed
   into this section's own fields (name, event date, the one
   vendor-type-adaptive extra field, and their message) is folded into
   the platform's real, existing window.vsOpenInquiry() popup's own
   real fields before it opens — nothing typed here is silently
   discarded, and nothing fake is submitted either. */
window.vsWeddingRequestQuote=function(btn){
  var nameEl  = document.getElementById('gs-wq-name');
  var dateEl  = document.getElementById('gs-wq-date');
  var extraEl = document.getElementById('gs-wq-extra');
  var msgEl   = document.getElementById('gs-wq-message');
  var extraLabel = btn && btn.getAttribute('data-extra-label') ? btn.getAttribute('data-extra-label') : 'Detail';

  vsOpenInquiry({ name: 'Quote Request', type: 'service' });

  var inqName = document.getElementById('vs-inq-name');
  if (inqName && nameEl && nameEl.value) inqName.value = nameEl.value;

  var pd = document.getElementById('vs-inq-pdate');
  if (pd && dateEl && dateEl.value) pd.value = dateEl.value;

  var remarksEl = document.getElementById('vs-inq-remarks');
  if (remarksEl) {
    var lines = [];
    if (dateEl && dateEl.value) lines.push('Event Date: ' + dateEl.value);
    if (extraEl && extraEl.value) lines.push(extraLabel + ': ' + extraEl.value);
    if (msgEl && msgEl.value) lines.push(msgEl.value);
    remarksEl.value = lines.length ? lines.join(' — ') : 'Requesting a quote for my event.';
  }
};

/* ── Inquiry submit ─────────────────────────────── */
window.vsSubmitInquiry=function(){
  // Consent gate — DPDP Act 2023 requires explicit consent before processing PII
  var consentEl = document.getElementById('vs-inq-consent');
  if ( consentEl && ! consentEl.checked ) {
    var msgEl2 = document.getElementById('vs-inq-msg');
    if(msgEl2){msgEl2.style.display='block';msgEl2.style.background='#FEF2F2';msgEl2.style.color='#991B1B';msgEl2.textContent='Please agree to the consent statement before submitting.';}
    return;
  }
  var n  = val('vs-inq-name');
  var p  = val('vs-inq-phone');
  var e  = val('vs-inq-email');
  var c  = val('vs-inq-city');
  var q  = val('vs-inq-qty');
  var pd = val('vs-inq-pdate');
  var cd = val('vs-inq-cdate');
  var rm = val('vs-inq-remarks');
  var iname  = val('vs-inq-iname');
  var iprice = val('vs-inq-iprice');

  var msgEl  = document.getElementById('vs-inq-msg');
  var btn    = document.getElementById('vs-inq-submit');
  var btnTxt = document.getElementById('vs-inq-submit-txt');

  function setBtn(text, disabled) {
    if (btn) btn.disabled = !!disabled;
    if (btnTxt) btnTxt.textContent = text;
  }
  function showInqMsg(txt, col, bg) {
    if (!msgEl) return;
    msgEl.style.display   = 'block';
    msgEl.style.color     = col;
    msgEl.style.background = bg || (col === '#059669' ? '#F0FDF4' : '#FEF2F2');
    msgEl.textContent = txt;
  }

  if (!n) { showInqMsg('⚠️ Please enter your full name.', '#DC2626'); return; }
  if (!p) { showInqMsg('⚠️ Please enter your phone number.', '#DC2626'); return; }
  if (!c) { showInqMsg('⚠️ Please enter your city.', '#DC2626'); return; }

  setBtn('Sending…', true);
  post({
    action:'gs_submit_lead', nonce:NONCE, listing_id:LID,
    name:n, phone:p, email:e, city:c,
    product_name:iname, product_price:iprice, quantity:q,
    purchase_date:pd, callback_date:cd, remarks:rm,
    source:'enquiry_modal_v2'
  }, function(d) {
    if (d.success) {
      showInqMsg('✅ Enquiry sent! We will contact you shortly.', '#059669', '#F0FDF4');
      setBtn('✅ Sent!', true);
      ['vs-inq-name','vs-inq-phone','vs-inq-email','vs-inq-city',
       'vs-inq-qty','vs-inq-pdate','vs-inq-cdate','vs-inq-remarks'].forEach(function(id){
        var el = document.getElementById(id); if (el) el.value = '';
      });
      // Auto-login: if server created/found a user account, redirect after brief delay
      if (d.data && d.data.logged_in && d.data.redirect_url) {
        showInqMsg('✅ Enquiry sent! You have been logged in automatically. Redirecting…', '#059669', '#F0FDF4');
        setTimeout(function(){ window.location.href = d.data.redirect_url; }, 2000);
      } else {
        setTimeout(vsCloseInquiry, 2800);
      }
    } else {
      showInqMsg('❌ ' + (d.data && d.data.message ? d.data.message : 'Failed. Please call us directly.'), '#DC2626', '#FEF2F2');
      setBtn('Send Enquiry', false);
    }
  });
};

/* ── Quick Connect ─────────────────────────────── */
window.vsSubmitQC=function(){
  var n=val('vs-qc-name'),p=val('vs-qc-phone'),e=val('vs-qc-email'),sv=val('vs-qc-service'),m=val('vs-qc-message');
  var msg=document.getElementById('vs-qc-msg'),btn=document.getElementById('vs-qc-submit');
  if(!n||!p){showMsg(msg,'Name and phone required.','#DC2626');return;}
  btn.disabled=true; btn.textContent='Sending…';
  post({action:'gs_submit_lead',nonce:NONCE,listing_id:LID,name:n,phone:p,email:e,
    product_name:sv,message:m,source:'quick_connect'},
  function(d){
    if(d.success){
      showMsg(msg,'✅ Sent! We\'ll contact you soon.','#fff'); btn.textContent='✅ Sent!';
      if(d.data && d.data.logged_in && d.data.redirect_url){
        setTimeout(function(){ window.location.href=d.data.redirect_url; }, 2000);
      }
    } else {
      showMsg(msg,'❌ Failed. Call us directly.','#fff'); btn.disabled=false; btn.textContent='Submit Enquiry →';
    }
  });
};

/* ── Contact-section inline inquiry form submission ── */
window.cxSubmit = function(slug, lid) {
  var btn = document.getElementById('cx_btn_' + slug);
  var out = document.getElementById('cx_msg_out_' + slug);
  // Collect all cx_ prefixed inputs for this slug
  var panel = btn ? btn.closest('.vs-contact-form-card') : null;
  if (!panel) return;
  var fd = new FormData();
  fd.append('action', 'gs_submit_inquiry');
  fd.append('nonce', NONCE);
  fd.append('listing_id', String(lid));
  fd.append('inquiry_module', slug);
  fd.append('inquiry_type', 'inquiry');
  panel.querySelectorAll('[name]').forEach(function(inp) {
    if (inp.name && inp.value) fd.append(inp.name, inp.value);
  });
  // Basic validation
  var phone = panel.querySelector('input[type="tel"]');
  if (phone && !phone.value.trim()) {
    if (out) { out.style.display='block'; out.style.color='#DC2626'; out.textContent='Phone number is required.'; }
    return;
  }
  if (btn) { btn.disabled = true; btn.innerHTML = '⏳ Sending…'; }
  fetch(AJX, { method: 'POST', body: fd })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d.success) {
        if (btn) { btn.innerHTML = '✅ Sent!'; }
        if (out) { out.style.display='block'; out.style.color='#059669'; out.textContent = 'Thank you! We will contact you shortly.'; }
      } else {
        if (btn) { btn.disabled = false; btn.innerHTML = '📩 Submit Enquiry'; }
        if (out) { out.style.display='block'; out.style.color='#DC2626'; out.textContent = (d.data && d.data.message) ? d.data.message : 'Submission failed. Please try again.'; }
      }
    })
    .catch(function() {
      if (btn) { btn.disabled = false; btn.innerHTML = '📩 Submit Enquiry'; }
      if (out) { out.style.display='block'; out.style.color='#DC2626'; out.textContent = 'Network error. Please try again.'; }
    });
};

/* ── Feedback ─────────────────────────────────── */
var currentRating=0;
window.vsSetRating=function(v){
  currentRating=v;
  document.getElementById('vs-fb-rating').value=v;
  document.querySelectorAll('.vs-star-btn').forEach(function(s,i){
    s.style.color=i<v?'#F59E0B':'#D1D5DB';
  });
};
window.vsSubmitFeedback=function(){
  var n=val('vs-fb-name'),m=val('vs-fb-msg'),r=currentRating;
  var res=document.getElementById('vs-fb-result'),btn=document.getElementById('vs-fb-submit');
  if(!r){showMsg(res,'Please select a star rating.','#DC2626');return;}
  if(!n){showMsg(res,'Please enter your name.','#DC2626');return;}
  btn.disabled=true; btn.textContent='Submitting…';
  post({action:'gs_submit_review',nonce:NONCE,listing_id:LID,rating:r,reviewer_name:n,review_text:m,source:'feedback_form'},
  function(d){
    if(d.success){showMsg(res,'✅ Thank you for your feedback!','#059669');btn.textContent='✅ Submitted';}
    else{showMsg(res,'Failed. Please try again.','#DC2626');btn.disabled=false;btn.textContent='Submit Feedback';}
  });
};

/* ── Newsletter ─────────────────────────────────── */
window.vsSubmitNewsletter=function(){
  var e=val('vs-nl-email'),msg=document.getElementById('vs-nl-msg');
  if(!e){showMsg(msg,'Enter your email.','rgba(255,255,255,.7)');return;}
  post({action:'gs_newsletter_signup',nonce:NONCE,email:e,listing_id:LID},
  function(d){showMsg(msg,d.success?'✅ Subscribed!':'Already subscribed.','rgba(255,255,255,.8)');});
};

/* ── Gallery filter tabs ────────────────────────── */
window.vsGalFilter=function(tag,btn){
  document.querySelectorAll('.vs-gal-tab').forEach(function(b){b.classList.remove('active');});
  btn.classList.add('active');
  document.querySelectorAll('#vs-gallery-grid .vs-gallery-item').forEach(function(el){
    el.style.display=(tag==='all'||el.dataset.galTag===tag)?'block':'none';
  });
};

/* ── Lightbox (with caption) ────────────────────── */
window.vsLightboxImages = [];
window.vsLightboxIndex = 0;
// Real fix, found during a full audit against the original
// requirements: this function was referenced from PropertyTypesModule's
// onclick handler but was never actually defined anywhere — clicking a
// Property Types card silently did nothing at all. Filters the
// Property Listings grid (if present on the page — Property Types must
// keep working correctly even when Property Listings is disabled, so
// this degrades to "just scroll, nothing to filter" rather than
// erroring when that grid doesn't exist) to only the clicked type, and
// scrolls to it.
window.vsFilterPropertiesByType = function(type) {
  var section = document.getElementById('vs-sec-property_listings');
  if (!section) { return; } // Property Listings not enabled on this listing — nothing to filter, nothing to scroll to.
  section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  var cards = section.querySelectorAll('.vs-prop-card[data-property-type]');
  cards.forEach(function(card) {
    card.style.display = (card.dataset.propertyType === type) ? '' : 'none';
  });
};

// Real fix — completes the missing "Navigation controls where
// applicable" requirement for the Property Gallery carousel layout.
// Scrolls by roughly one card's width in either direction, using the
// carousel's own real item width rather than a hardcoded guess, so
// this stays correct regardless of the configured aspect ratio or
// column count.
window.vsPropGalleryScroll = function(direction) {
  var grid = document.getElementById('vs-property-gallery-grid');
  if (!grid) { return; }
  var firstItem = grid.querySelector('.vs-prop-gallery-item');
  var scrollAmount = firstItem ? firstItem.offsetWidth + 16 : 320;
  grid.scrollBy({ left: direction * scrollAmount, behavior: 'smooth' });
};

// Interior Designers & Architects, module 2 of 5 — Project
// Categories. Same real, established filter/scroll pattern as
// vsFilterPropertiesByType (Real Estate's Property Types →
// Listings), applied to Featured Projects' own cards this time.
// Gracefully degrades to doing nothing if Featured Projects isn't
// enabled on this listing, exactly matching the independence
// requirement — Project Categories must keep working even when
// Featured Projects is off.
window.vsIdaFilterProjectsByCategory = function(category) {
  var section = document.getElementById('vs-sec-featured_projects');
  if (!section) { return; }
  section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  var cards = section.querySelectorAll('.vs-ida-project-card[data-category]');
  cards.forEach(function(card) {
    card.style.display = (card.dataset.category === category) ? '' : 'none';
  });
};

// Interior Designers & Architects, module 4 of 5 — Design Styles &
// Expertise. Same real, established filter/scroll pattern as the
// category filter above, reused rather than reimplemented.
window.vsIdaFilterProjectsByStyle = function(style) {
  var section = document.getElementById('vs-sec-featured_projects');
  if (!section) { return; }
  section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  var cards = section.querySelectorAll('.vs-ida-project-card[data-style]');
  cards.forEach(function(card) {
    card.style.display = (card.dataset.style === style) ? '' : 'none';
  });
};

// Expertise differs from category/style: a project can have several,
// stored as a JSON array in data-expertise, so this checks array
// membership rather than a simple equality match.
window.vsIdaFilterProjectsByExpertise = function(expertise) {
  var section = document.getElementById('vs-sec-featured_projects');
  if (!section) { return; }
  section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  var cards = section.querySelectorAll('.vs-ida-project-card[data-expertise]');
  cards.forEach(function(card) {
    var list = [];
    try { list = JSON.parse(card.dataset.expertise || '[]'); } catch(e) { list = []; }
    card.style.display = (list.indexOf(expertise) !== -1) ? '' : 'none';
  });
};

// Interior Designers & Architects, module 3 of 5 — the real,
// native before/after drag-to-compare slider. No external library:
// pointer events cover mouse and touch in one handler (the
// "touch-friendly" requirement from the spec), and clip-path is used
// on the "before" image's wrapper rather than resizing the image
// itself, so the image never distorts as the handle moves — only how
// much of it is visible changes.
window.vsIdaInitBeforeAfterSlider = function(sliderId) {
  var slider = document.getElementById(sliderId);
  if (!slider || slider.dataset.vsBaInit) { return; } // never double-initialize the same slider
  slider.dataset.vsBaInit = '1';
  var beforeWrap = slider.querySelector('.vs-ida-ba-before-wrap');
  var handle = slider.querySelector('.vs-ida-ba-handle');
  if (!beforeWrap || !handle) { return; }

  function setPosition(percent) {
    percent = Math.max(0, Math.min(100, percent));
    beforeWrap.style.clipPath = 'inset(0 ' + (100 - percent) + '% 0 0)';
    handle.style.left = percent + '%';
  }

  var dragging = false;
  function positionFromEvent(e) {
    var rect = slider.getBoundingClientRect();
    var x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
    return (x / rect.width) * 100;
  }
  function onMove(e) {
    if (!dragging) { return; }
    setPosition(positionFromEvent(e));
  }
  function onUp() { dragging = false; }

  handle.addEventListener('pointerdown', function(e) { dragging = true; e.preventDefault(); });
  slider.addEventListener('pointerdown', function(e) { dragging = true; setPosition(positionFromEvent(e)); });
  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup', onUp);
  // Touch fallback for older mobile browsers without full pointer event support.
  handle.addEventListener('touchstart', function(e) { dragging = true; }, { passive: true });
  slider.addEventListener('touchstart', function(e) { dragging = true; setPosition(positionFromEvent(e)); }, { passive: true });
  window.addEventListener('touchmove', onMove, { passive: true });
  window.addEventListener('touchend', onUp);

  setPosition(50); // start centered
};

window.vsCloseLightbox = function() {
  var lb = document.getElementById('vs-lightbox');
  if (lb) { lb.classList.remove('open'); }
  // Real feature — the popup's own slider was paused while the
  // lightbox was open (see vsLightbox() below); resume it here, the
  // one place every close path (outside click, close button, Escape)
  // now goes through.
  if (typeof vsPopupSliderRestartAuto === 'function' && document.getElementById('vs-detail-popup') && document.getElementById('vs-detail-popup').classList.contains('open')) {
    vsPopupSliderRestartAuto();
  }
};
window.vsLightbox=function(url,caption,gridId){
  // Real fix — this previously hardcoded 'vs-gallery-grid', meaning
  // any OTHER section trying to reuse this same lightbox (Property
  // Gallery, built this session, needs exactly this) would either
  // navigate through the wrong section's images or silently fall back
  // to a single, non-navigable image if that other grid didn't exist
  // on the page at all. Now accepts which grid to read from, with the
  // original grid as the default — every existing call site (the
  // Gallery section's own onclick handlers, which only ever pass two
  // arguments) is completely unaffected and keeps behaving exactly as
  // before.
  var grid = document.getElementById(gridId || 'vs-gallery-grid');
  window.vsLightboxImages = grid ? Array.from(grid.querySelectorAll('img')).map(function(img){
    return { url: img.src, caption: img.alt || '' };
  }) : [{ url: url, caption: caption || '' }];
  var idx = window.vsLightboxImages.findIndex(function(i){ return i.url === url; });
  window.vsLightboxIndex = idx >= 0 ? idx : 0;
  vsLightboxRender();
  document.getElementById('vs-lightbox').classList.add('open');
  // Real feature — pauses the popup's own slider auto-advance while
  // the lightbox covers it, since the slide would otherwise keep
  // silently changing behind a fully opaque overlay; vsCloseLightbox()
  // is the single place that resumes it again.
  if (typeof vsPopupSliderStopAuto === 'function') { vsPopupSliderStopAuto(); }
};
window.vsLightboxNav = function(dir){
  var imgs = window.vsLightboxImages;
  if (!imgs || imgs.length < 2) return;
  window.vsLightboxIndex = (window.vsLightboxIndex + dir + imgs.length) % imgs.length;
  vsLightboxRender();
};
window.vsLightboxRender = function(){
  var imgs = window.vsLightboxImages;
  var current = imgs[window.vsLightboxIndex];
  if (!current) return;
  document.getElementById('vs-lb-img').src = current.url;
  var cap = document.getElementById('vs-lb-cap');
  if (cap) { cap.textContent = current.caption || ''; cap.style.display = current.caption ? 'block' : 'none'; }
  var counter = document.getElementById('vs-lb-counter');
  var prevBtn = document.getElementById('vs-lb-prev');
  var nextBtn = document.getElementById('vs-lb-next');
  if (imgs.length > 1) {
    if (counter) { counter.style.display = 'block'; counter.textContent = (window.vsLightboxIndex + 1) + ' / ' + imgs.length; }
    if (prevBtn) prevBtn.style.display = 'flex';
    if (nextBtn) nextBtn.style.display = 'flex';
  } else {
    if (counter) counter.style.display = 'none';
    if (prevBtn) prevBtn.style.display = 'none';
    if (nextBtn) nextBtn.style.display = 'none';
  }
};
// Real feature: keyboard navigation (arrow keys, Escape to close).
document.addEventListener('keydown', function(e){
  var lb = document.getElementById('vs-lightbox');
  if (!lb || !lb.classList.contains('open')) return;
  if (e.key === 'ArrowLeft') vsLightboxNav(-1);
  else if (e.key === 'ArrowRight') vsLightboxNav(1);
  else if (e.key === 'Escape') vsCloseLightbox();
});
// Real feature: touch swipe navigation for mobile.
(function(){
  var lb = document.getElementById('vs-lightbox');
  if (!lb) return;
  var startX = null;
  lb.addEventListener('touchstart', function(e){ startX = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener('touchend', function(e){
    if (startX === null) return;
    var diff = e.changedTouches[0].clientX - startX;
    if (Math.abs(diff) > 50) { vsLightboxNav(diff > 0 ? -1 : 1); }
    startX = null;
  }, { passive: true });
})();

/* ── Item filter tabs ───────────────────────────── */
window.vsFilterItems=function(type,btn){
  document.querySelectorAll('.vs-filter-tab').forEach(function(b){b.classList.remove('active');});
  btn.classList.add('active');
  document.querySelectorAll('#vs-items-grid .vs-item-card').forEach(function(card){
    if(type==='all'||card.dataset.itemType===type){
      card.style.display='flex';
    } else {
      card.style.display='none';
    }
  });
};
var links=document.querySelectorAll('.vs-nav-links a');
var secs=[];
links.forEach(function(a){
  var id=a.getAttribute('href').replace('#','');
  var el=document.getElementById(id);
  if(el)secs.push({a:a,el:el});
});
window.addEventListener('scroll',function(){
  var pos=window.scrollY+80;
  secs.forEach(function(s){
    var active=pos>=s.el.offsetTop&&pos<s.el.offsetTop+s.el.offsetHeight;
    s.a.classList.toggle('act',active);
  });},{passive:true});

/* ── Scroll Progress Bar ─────────────────────────── */
(function(){
  var bar = document.getElementById('vs-scroll-prog');
  if (!bar) return;
  function update(){
    var st  = window.scrollY || document.documentElement.scrollTop;
    var sh  = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    var pct = sh > 0 ? Math.min(100, Math.round((st / sh) * 100)) : 0;
    bar.style.width = pct + '%';
    bar.setAttribute('aria-valuenow', pct);
  }
  window.addEventListener('scroll', update, { passive: true });
  update();
})();

/* Social proof toast removed */

/* ── Back to Top ─────────────────────────────────── */
(function(){
  var btn = document.getElementById('vs-back-top');
  if (!btn) return;
  window.addEventListener('scroll', function(){
    btn.style.opacity          = window.scrollY > 400 ? '1' : '0';
    btn.style.pointerEvents    = window.scrollY > 400 ? 'auto' : 'none';
    btn.style.transform        = window.scrollY > 400 ? 'translateY(0)' : 'translateY(10px)';
  }, { passive: true });
  btn.addEventListener('click', function(){
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
})();

/* ── Helpers ───────────────────────────────────── */
function val(id){var el=document.getElementById(id);return el?(el.value||'').trim():'';}
function showMsg(el,txt,color){el.style.display='block';el.style.color=color;el.textContent=txt;}
function post(data,cb){
  var fd=new FormData();
  Object.keys(data).forEach(function(k){fd.append(k,data[k]);});
  fetch(AJX,{method:'POST',body:fd}).then(function(r){return r.json();}).then(cb).catch(function(){cb({success:false});});
}

/* ── Review form ─────────────────────────────────────────────── */
window.vsToggleReviewForm = function(){
  var box = document.getElementById('vs-review-form-box');
  var btn = document.getElementById('vs-review-form-toggle');
  if(!box) return;
  var open = box.style.display === 'none';
  box.style.display = open ? 'block' : 'none';
  if(btn) btn.textContent = open ? '✕ Close' : '✏️ Write a Review';
  if(open) {
    box.scrollIntoView({behavior:'smooth', block:'nearest'});
  }
};

// Star rating picker
(function(){
  var picked = 0;
  document.addEventListener('click', function(e){
    var star = e.target.closest('.vs-star-pick');
    if(!star) return;
    picked = parseInt(star.dataset.v);
    var inp = document.getElementById('vs-review-rating');
    if(inp) inp.value = picked;
    var hint = document.getElementById('vs-star-hint');
    var labels = ['','Poor','Fair','Good','Very Good','Excellent'];
    if(hint) hint.textContent = labels[picked] || '';
    document.querySelectorAll('.vs-star-pick').forEach(function(s){
      s.classList.toggle('lit', parseInt(s.dataset.v) <= picked);
    });
  });
  document.addEventListener('mouseover', function(e){
    var star = e.target.closest('.vs-star-pick');
    if(!star) return;
    var v = parseInt(star.dataset.v);
    document.querySelectorAll('.vs-star-pick').forEach(function(s){
      s.classList.toggle('lit', parseInt(s.dataset.v) <= v);
    });
  });
  document.addEventListener('mouseout', function(e){
    if(!e.target.closest('#vs-star-picker')) {
      document.querySelectorAll('.vs-star-pick').forEach(function(s){
        s.classList.toggle('lit', parseInt(s.dataset.v) <= picked);
      });
    }
  });
})();

window.vsSetSubRating = function(field, val, el) {
  document.getElementById('vs-rv-'+field).value = val;
  document.querySelectorAll('.vs-sub-star[data-field="'+field+'"]').forEach(function(s,i){
    s.style.color = i < val ? '#F59E0B' : '#E2E8F0';
  });
};
document.addEventListener('input', function(e){
  if(e.target.id==='vs-rv-msg'){
    var len = e.target.value.length;
    var ch = document.getElementById('vs-rv-char');
    if(ch) ch.textContent = len+'/500';
    if(len > 500) e.target.value = e.target.value.slice(0,500);
  }
});
window.vsSubmitReview = function(){
  var rating = parseInt(document.getElementById('vs-review-rating')?.value || 0);
  var name   = (document.getElementById('vs-rv-name')?.value || '').trim();
  var phone  = (document.getElementById('vs-rv-phone')?.value || '').trim();
  var email  = (document.getElementById('vs-rv-email')?.value || '').trim();
  var msg    = (document.getElementById('vs-rv-msg')?.value || '').trim();
  var status = document.getElementById('vs-rv-msg-status');
  var btn    = document.getElementById('vs-rv-submit');

  function showStatus(txt, col){
    if(status){
      status.textContent=txt;
      status.style.color=col;
      status.style.background=(col==='#DC2626')?'#FEF2F2':'#F0FDF4';
      status.style.padding='10px 14px';
      status.style.borderRadius='8px';
      status.style.display='block';
    }
  }
  if(!rating){ showStatus('Please select a star rating.','#DC2626'); return; }
  if(!name)  { showStatus('Please enter your full name.','#DC2626'); return; }
  if(!phone) { showStatus('Mobile number is required.','#DC2626'); return; }
  if(!email) { showStatus('Email address is required.','#DC2626'); return; }
  // Basic email format check
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){ showStatus('Please enter a valid email address.','#DC2626'); return; }
  // Basic phone check — at least 7 digits
  if(phone.replace(/\D/g,'').length < 7){ showStatus('Please enter a valid mobile number.','#DC2626'); return; }

  if(msg.length < 30){ showStatus('Please write at least 30 characters in your review.','#DC2626'); return; }
  var punctuality = document.getElementById('vs-rv-punctuality_rating')?.value || 0;
  var quality     = document.getElementById('vs-rv-quality_rating')?.value || 0;
  var cleanliness = document.getElementById('vs-rv-cleanliness_rating')?.value || 0;
  var price       = document.getElementById('vs-rv-price_rating')?.value || 0;
  var recommend   = document.getElementById('vs-rv-recommend')?.checked ? 1 : 0;
  btn.disabled = true; btn.textContent = 'Submitting…';
  post({action:'gs_submit_review', nonce:NONCE, listing_id:LID,
    rating:rating, reviewer_name:name, reviewer_phone:phone, reviewer_email:email,
    review_text:msg, source:'review_form_v2',
    punctuality_rating:punctuality, quality_rating:quality,
    cleanliness_rating:cleanliness, price_rating:price,
    would_recommend:recommend},
    function(d){
      if (!d.success) {
        var errMsg = (d.data && d.data.message) ? d.data.message : 'Error submitting review. Try again.';
        showStatus(errMsg, '#DC2626');
        btn.disabled = false; btn.textContent = 'Submit Review →';
        return;
      }
      showStatus('Thank you! Your review has been submitted for approval.','#059669');
      btn.textContent = '✅ Submitted';
      document.getElementById('vs-review-rating').value = 0;
      if(document.getElementById('vs-rv-name')) document.getElementById('vs-rv-name').value = '';
      if(document.getElementById('vs-rv-phone')) document.getElementById('vs-rv-phone').value = '';
      if(document.getElementById('vs-rv-email')) document.getElementById('vs-rv-email').value = '';
      if(document.getElementById('vs-rv-msg')) document.getElementById('vs-rv-msg').value = '';
      document.querySelectorAll('.vs-star-pick').forEach(function(s){ s.classList.remove('lit'); });
    }
  );
};

/* ── Helpful review ─────────────────────────────────────────────── */
window.vsHelpfulReview = function(reviewId, btn) {
  if (btn.dataset.voted) return;
  btn.dataset.voted = '1';
  btn.style.color = '#2563EB';
  btn.style.borderColor = '#2563EB';
  btn.style.background = '#EFF6FF';
  post({action:'gs_helpful_review', nonce:NONCE, review_id:reviewId},
    function(d){
      var cnt = btn.querySelector('span');
      var newCount = (d.helpful_count || 1);
      if (!cnt) { var s=document.createElement('span'); s.textContent='('+newCount+')'; btn.appendChild(s); }
      else { cnt.textContent='('+newCount+')'; }
    },
    function(){ btn.dataset.voted=''; }
  );
};
})();
</script>

<?php if ($wa_clean || $phone): ?>
<!-- ══ FLOATING WHATSAPP + CALL BUTTONS ════════════════════════════ -->
<link rel="preload" as="style" href="<?php echo esc_url( GS_URL . 'assets/css/vendor-site-static.css?v=' . GS_VERSION ); ?>" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="<?php echo esc_url( GS_URL . 'assets/css/vendor-site-static.css?v=' . GS_VERSION ); ?>"></noscript>

<?php if ($phone): ?>
<!-- Back to Top Button -->
<button id="vs-back-top"
  style="position:fixed;bottom:90px;right:24px;z-index:8980;width:40px;height:40px;border-radius:50%;background:var(--vs-dark);color:#fff;border:none;cursor:pointer;font-size:1rem;font-weight:700;box-shadow:0 4px 14px rgba(0,0,0,.18);opacity:0;pointer-events:none;transform:translateY(10px);transition:opacity .25s,transform .25s;font-family:var(--vs-font)"
  title="Back to top"
  aria-label="Scroll back to top">↑</button>

<!-- Floating Call button (bottom-left) -->
<div class="vs-float-call">
  <a href="tel:<?php echo esc_attr($phone); ?>" class="vs-call-fab" title="Call Now">
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1-9.4 0-17-7.6-17-17 0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z" fill="var(--vs-primary)"/>
    </svg>
    <span class="vs-call-fab-lbl">📞 <?php echo esc_html($phone); ?></span>
  </a>
</div>
<?php endif; ?>

<?php if ($wa_clean): ?>
<!-- Floating WhatsApp button + chat popup (bottom-right, desktop always visible) -->
<div class="vs-float-wa" id="vs-wa-float">

  <!-- Chat popup -->
  <div class="vs-wa-popup" id="vs-wa-popup">
    <div class="vs-wa-pop-head">
      <div class="vs-wa-pop-av">
        <?php if ($logo): ?><img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?>" width="32" height="32" style="width:32px;height:32px;border-radius:50%;object-fit:cover"><?php else: ?><?php echo esc_html(strtoupper(substr( gs_vs_safe_brand( $brand, $primary, $vendor ),0,1))); ?><?php endif; ?>
      </div>
      <div>
        <div class="vs-wa-pop-name"><?php echo esc_html( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?></div>
        <div class="vs-wa-pop-status">🟢 Typically replies within minutes</div>
      </div>
      <button class="vs-wa-pop-close" onclick="vsWaClose()" title="Close">✕</button>
    </div>
    <div class="vs-wa-pop-body">
      <div class="vs-wa-bubble">
        <?php
        $wa_greeting = sprintf(
          'Hi! 👋 Welcome to %s. How can we help you today?',
          esc_html( gs_vs_safe_brand( $brand, $primary, $vendor ) )
        );
        echo $wa_greeting;
        ?>
        <div class="vs-wa-bubble-time"><?php echo date('g:i A'); ?> ✓✓</div>
      </div>
    </div>
    <div class="vs-wa-pop-footer">
      <input type="text" class="vs-wa-pop-input" id="vs-wa-msg-input" placeholder="Type a message…" onkeydown="if(event.key==='Enter')vsWaSend()">
      <button class="vs-wa-pop-send" onclick="vsWaSend()" title="Send" aria-label="Send message">
        <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M2 21l21-9L2 3v7l15 2-15 2z"/></svg>
      </button>
    </div>
  </div>

  <!-- FAB -->
  <button class="vs-wa-fab" id="vs-wa-fab" onclick="vsWaToggle()" title="Chat on WhatsApp" aria-label="Chat on WhatsApp">
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
    </svg>
    <span class="vs-wa-notif" id="vs-wa-notif">1</span>
  </button>

</div>

<script>
(function(){
var WA_NUM='<?php echo esc_js($wa_clean); ?>';
var BRAND='<?php echo esc_js( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?>';
var opened=false;

// Auto-open after 4 seconds (first visit only)
if(!sessionStorage.getItem('vs_wa_seen')){
  setTimeout(function(){
    if(!opened) vsWaOpen();
  },4000);
}

window.vsWaToggle=function(){
  var popup=document.getElementById('vs-wa-popup');
  if(popup.classList.contains('open')) vsWaClose(); else vsWaOpen();
};
window.vsWaOpen=function(){
  document.getElementById('vs-wa-popup').classList.add('open');
  document.getElementById('vs-wa-notif').style.display='none';
  sessionStorage.setItem('vs_wa_seen','1');
  opened=true;
  setTimeout(function(){var inp=document.getElementById('vs-wa-msg-input');if(inp)inp.focus();},200);
};
window.vsWaClose=function(){
  document.getElementById('vs-wa-popup').classList.remove('open');
};
window.vsWaSend=function(){
  var inp=document.getElementById('vs-wa-msg-input');
  var msg=(inp.value||'').trim();
  if(!msg) msg='Hi '+BRAND+'! I found you online and would like to know more.';
  var url='https://wa.me/'+WA_NUM+'?text='+encodeURIComponent(msg);
  window.open(url,'_blank');
  inp.value='';
  vsWaClose();
};
})();
</script>
<?php endif; ?>
<?php endif; ?>
<?php if ($mv_float_cta): ?>
<!-- ══ MOBILE FLOATING CTA BAR — Always shows 3 action buttons ══════ -->

<div class="vs-mobile-cta-bar" id="vs-mobile-cta">
  <!-- Get Quote Button — generic lead-capture popup, always available -->
  <?php if ( $_can_lead_popup ): ?>
  <button onclick="vsOpenInquiry(null)" class="vs-mcta-btn-labeled"
    style="background:<?php echo esc_attr($cv_mcta_quote_bg); ?>;color:<?php echo esc_attr($cv_mcta_quote_text); ?>;">
    <span class="vs-mcta-icon-em">✉</span>
    <span class="vs-mcta-lbl"><?php echo esc_html($mv_float_cta_txt ?: 'Get Quote'); ?></span>
  </button>
  <?php endif; ?>
  <!-- Call Button — hidden entirely when no phone is set (real fix: previously
       showed a grayed-out disabled button, which read as "broken" rather than
       "not applicable" to anyone unfamiliar with the intentional fallback state) -->
  <?php if ($phone): ?>
  <a href="tel:<?php echo esc_attr($phone); ?>" class="vs-mcta-btn-labeled"
     style="background:<?php echo esc_attr($cv_mcta_call_bg); ?>;color:<?php echo esc_attr($cv_mcta_call_text); ?>;">
    <span class="vs-mcta-icon-em">📞</span>
    <span class="vs-mcta-lbl">Call</span>
  </a>
  <?php endif; ?>
  <!-- WhatsApp Button — same fix, hidden entirely when no number is set -->
  <?php if ($wa_clean): ?>
  <a href="https://wa.me/<?php echo esc_attr($wa_clean); ?>" target="_blank" rel="noopener"
     class="vs-mcta-btn-labeled" style="background:<?php echo esc_attr($cv_mcta_wa_bg); ?>;color:<?php echo esc_attr($cv_mcta_wa_text); ?>;">
    <span class="vs-mcta-icon-em">💬</span>
    <span class="vs-mcta-lbl">WhatsApp</span>
  </a>
  <?php endif; ?>
  <!-- Save / Bookmark Button (Phase 2 — flagged as missing) -->
  <button id="vs-save-btn" onclick="vsSaveListing()" class="vs-mcta-btn-labeled"
     style="background:#F5F3FF;color:#7C3AED;"
     title="Save to My Vendors"
     aria-label="Save this listing">
    <span class="vs-mcta-icon-em" id="vs-save-icon">🤍</span>
    <span class="vs-mcta-lbl">Save</span>
  </button>
</div>
<script>
// Save button logic for vendor-site — mirrors the archive.php implementation.
// For logged-in users: syncs to gs_saved_listings via gs_save_listing_bookmark.
// For guests: stores in localStorage with a login nudge.
(function(){
  var LID = <?php echo (int)$lid; ?>;
  var NONCE = '<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>';
  var AJAX  = '<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
  var IS_LOGGED_IN = <?php echo is_user_logged_in() ? 'true' : 'false'; ?>;

  // Check if already saved (localStorage for guests, will be synced server-side for logged-in)
  var savedKey = 'gs_saved_' + LID;
  function isSaved() {
    return IS_LOGGED_IN
      ? document.getElementById('vs-save-btn').dataset.saved === '1'
      : !!localStorage.getItem(savedKey);
  }

  // Set initial state from server (for logged-in users)
  <?php if ( is_user_logged_in() ):
    global $wpdb;
    $is_saved = (bool) $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}gs_saved_listings WHERE user_id=%d AND listing_id=%d",
        get_current_user_id(), $lid
    ) );
  ?>
  document.addEventListener('DOMContentLoaded', function() {
    var btn = document.getElementById('vs-save-btn');
    if (btn) {
      btn.dataset.saved = '<?php echo $is_saved ? '1' : '0'; ?>';
      updateSaveUI(<?php echo $is_saved ? 'true' : 'false'; ?>);
    }
  });
  <?php else: ?>
  document.addEventListener('DOMContentLoaded', function() {
    updateSaveUI(!!localStorage.getItem(savedKey));
  });
  <?php endif; ?>

  <?php if ( $_sec_show('stats') ): ?>
  // Real feature — animated stat counters. Counts from 0 up to each
  // stat's real value once the stats section scrolls into view, using
  // IntersectionObserver (fires once, no continuous scroll-listener
  // polling) and requestAnimationFrame with an ease-out curve.
  (function() {
    var counters = document.querySelectorAll('.vs-stat-counter');
    if (!counters.length) return;
    var hasAnimated = new WeakSet();
    function animateCounter(el) {
      if (hasAnimated.has(el)) return;
      hasAnimated.add(el);
      var target = parseFloat(el.getAttribute('data-count-to')) || 0;
      var suffix = el.getAttribute('data-count-suffix') || '';
      var isInt = Number.isInteger(target);
      var duration = 1400;
      var startTime = null;
      function tick(now) {
        if (!startTime) startTime = now;
        var progress = Math.min((now - startTime) / duration, 1);
        var eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
        var current = target * eased;
        el.textContent = (isInt ? Math.round(current) : current.toFixed(1)) + suffix;
        if (progress < 1) requestAnimationFrame(tick);
        else el.textContent = (isInt ? target : target.toFixed(1)) + suffix;
      }
      requestAnimationFrame(tick);
    }
    if ('IntersectionObserver' in window) {
      var observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
          if (entry.isIntersecting) {
            animateCounter(entry.target);
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.3 });
      counters.forEach(function(el) { observer.observe(el); });
    } else {
      // Fallback for browsers without IntersectionObserver support —
      // animate immediately rather than leave the counters stuck at 0.
      counters.forEach(function(el) { animateCounter(el); });
    }
  })();
  <?php endif; ?>

  // Events & Wedding — single lightweight scroll-reveal (IntersectionObserver
  // + CSS class toggle only, no animation library). Wedding-scoped: selects
  // only .gs-wedding-reveal, never a generic ".reveal" that could touch any
  // other category's markup. Sections default to fully visible in CSS, so a
  // section already in the viewport at load — or any environment where JS
  // does not run at all — is never left stuck at a reduced-opacity state:
  // the "pending" (slightly-dimmed/offset) class is only ever added right
  // before the section is observed, and only when it is NOT already in
  // view and the user has not requested reduced motion.
  (function() {
    var sections = document.querySelectorAll('.gs-wedding-reveal');
    if (!sections.length) return;
    var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion || !('IntersectionObserver' in window)) return; // stays in the always-visible base state
    var vh = window.innerHeight || document.documentElement.clientHeight;
    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          entry.target.classList.remove('gs-wedding-reveal-pending');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    sections.forEach(function(el) {
      var rect = el.getBoundingClientRect();
      var alreadyInView = rect.top < vh && rect.bottom > 0;
      if (alreadyInView) {
        el.classList.add('is-visible');
        return; // never gets the pending class — no flash of dimmed content
      }
      el.classList.add('gs-wedding-reveal-pending');
      observer.observe(el);
    });
  })();

  function updateSaveUI(saved) {
    var icon = document.getElementById('vs-save-icon');
    var btn  = document.getElementById('vs-save-btn');
    if (icon) icon.textContent = saved ? '❤️' : '🤍';
    if (btn)  { btn.dataset.saved = saved ? '1' : '0'; btn.style.background = saved ? '#FDF4FF' : '#F5F3FF'; }
  }

  window.vsSaveListing = function() {
    var saved = isSaved();
    if (!IS_LOGGED_IN) {
      // Guest: toggle localStorage and show nudge
      if (saved) {
        localStorage.removeItem(savedKey);
        updateSaveUI(false);
      } else {
        localStorage.setItem(savedKey, '1');
        updateSaveUI(true);
        // Show login nudge after a short delay
        setTimeout(function() {
          var nudge = document.createElement('div');
          nudge.style.cssText = 'position:fixed;bottom:80px;left:50%;transform:translateX(-50%);background:#1E3A5F;color:#fff;padding:12px 18px;border-radius:10px;font-size:.82rem;z-index:9999;text-align:center;white-space:nowrap';
          nudge.innerHTML = '❤️ Saved! <a href="/vendor/login/?redirect='+encodeURIComponent(window.location.href)+'" style="color:#93C5FD;font-weight:700">Sign in</a> to access it anywhere.';
          document.body.appendChild(nudge);
          setTimeout(function(){ nudge.remove(); }, 4000);
        }, 300);
      }
      return;
    }
    // Logged-in: sync to server
    var btn = document.getElementById('vs-save-btn');
    if (btn) btn.disabled = true;
    var fd = new FormData();
    fd.append('action','gs_save_listing_bookmark');
    fd.append('nonce', NONCE);
    fd.append('listing_id', LID);
    fd.append('save', saved ? '0' : '1');
    fetch(AJAX, {method:'POST',body:fd,credentials:'same-origin'})
      .then(function(r){return r.json();})
      .then(function(d){
        if(d&&d.success){
          var nowSaved = !saved;
          updateSaveUI(nowSaved);
          var msg = nowSaved ? '❤️ Saved to My Vendors!' : 'Removed from saved.';
          // Brief toast if gsToast exists, otherwise silent
          if(typeof gsToast==='function') gsToast(msg,'success');
        }
        if(btn) btn.disabled = false;
      })
      .catch(function(){ if(btn) btn.disabled = false; });
  };
})();
</script>
<?php endif; ?>


<?php
// Real fix: the "Right Wall Nav" (mobile-only vertical jump-to-section
// pill bar, right edge of screen) has been completely removed per
// explicit request — it's no longer required, and it visually competed
// with the bottom mobile CTA bar it sat directly above. Removed: the
// <nav class="vs-wnav"> markup, its icon-set PHP, and its scroll-sync
// JS. The CSS for it (.vs-wnav and children) was removed from
// assets/css/vendor-site-static.css in the same pass — nothing
// references those classes anymore.
// Part 25.2 — On-platform communication incentives (shown near inquiry form)
?>
<div id="vs-platform-guarantee" style="display:none;background:linear-gradient(135deg,#F0FDF4,#ECFDF5);border:1.5px solid #86EFAC;border-radius:12px;padding:14px 16px;margin:12px 0;font-size:.8rem;color:#166534">
  <div style="font-weight:700;margin-bottom:6px">🛡️ Booking on-platform helps you</div>
  <div style="display:flex;flex-direction:column;gap:4px;color:#15803D">
    <div>✅ Your inquiry and booking details are on record with us</div>
    <div>✅ Verified reviews only after on-platform job completion</div>
    <div>✅ You can report a serious issue, and repeated complaints affect a listing's standing</div>
  </div>
</div>
<script>
// Show platform guarantee when inquiry form opens
(function(){
  var orig = window.vsOpenInquiry;
  window.vsOpenInquiry = function() {
    var g = document.getElementById('vs-platform-guarantee');
    if (g) g.style.display = 'block';
    if (orig) orig.apply(this, arguments);
  };
})();
</script>

<script>
function vsRevealPhone(el, listingId) {
  if (!listingId) return;
  el.disabled = true;
  el.textContent = 'Loading…';
  // H8 FIX: Phone fetched server-side on reveal — never stored in HTML source.
  var fd = new FormData();
  fd.append('action','gs_get_listing_phone');
  fd.append('nonce', window.GS&&GS.nonce?GS.nonce:'');
  fd.append('listing_id', listingId);
  fetch(window.GS&&GS.ajax_url?GS.ajax_url:'/wp-admin/admin-ajax.php', {method:'POST',body:fd})
    .then(function(r){ return r.json(); })
    .then(function(r){
      var phone = r&&r.success&&r.data&&r.data.phone ? r.data.phone : '';
      if (!phone) { el.disabled=false; el.textContent='📞 Tap to reveal'; return; }
      var parent = el.closest('span') || el.parentElement;
      parent.innerHTML = '<a href="tel:'+phone+'" style="color:inherit;font-weight:700;text-decoration:none">📞 '+phone+'</a>';
    })
    .catch(function(){ el.disabled=false; el.textContent='📞 Tap to reveal'; });
}
</script>

<?php
// ── Sticky Desktop CTA Bar (Part 21.5) ───────────────────────────────────
// Shows on desktop when user scrolls past the hero inquiry form.
// $_reply_txt already computed earlier (Part 12.2b) — reused here as-is.
?>
<div id="vs-desktop-sticky-cta" style="display:none;position:fixed;bottom:0;left:0;right:0;z-index:8980;background:#fff;border-top:1.5px solid #E2E8F0;box-shadow:0 -4px 20px rgba(0,0,0,.10);padding:12px 24px">
  <div style="max-width:1200px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:16px">
    <div style="display:flex;align-items:center;gap:12px">
      <?php if($logo): ?>
      <img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?>" width="38" height="38" style="width:38px;height:38px;border-radius:8px;object-fit:cover" loading="lazy">
      <?php endif; ?>
      <div>
        <div style="font-weight:700;font-size:.92rem;color:#1E293B"><?php echo esc_html( gs_vs_safe_brand( $brand, $primary, $vendor ) ); ?></div>
        <div style="font-size:.74rem;color:#64748B">
          <?php if($review_avg > 0): ?>★ <?php echo number_format($review_avg,1); ?> · <?php endif; ?>
          <?php echo esc_html($_reply_txt ?: 'Verified professional'); ?>
        </div>
      </div>
    </div>
    <div style="display:flex;align-items:center;gap:10px">
      <?php if($wa_clean): ?>
      <a href="https://wa.me/<?php echo esc_attr($wa_clean); ?>" target="_blank" rel="noopener"
         style="display:inline-flex;align-items:center;gap:6px;padding:9px 16px;background:#25D366;color:#fff;border-radius:9px;font-size:.84rem;font-weight:700;text-decoration:none">
        <span>📱</span> WhatsApp
      </a>
      <?php endif; ?>
      <?php if ($_can_lead_popup): ?>
      <a href="#vs-sec-inquiry-modules" onclick="vsOpenInquiry();return false;"
         style="display:inline-flex;align-items:center;gap:6px;padding:9px 20px;background:#2563EB;color:#fff;border-radius:9px;font-size:.88rem;font-weight:700;text-decoration:none">
        📋 Get Free Quote
      </a>
      <?php elseif ($phone): ?>
      <a href="tel:<?php echo esc_attr($phone); ?>"
         style="display:inline-flex;align-items:center;gap:6px;padding:9px 20px;background:#2563EB;color:#fff;border-radius:9px;font-size:.88rem;font-weight:700;text-decoration:none">
        📞 Call Now
      </a>
      <?php endif; ?>
    </div>
  </div>
</div>
<script>
(function(){
  var bar = document.getElementById('vs-desktop-sticky-cta');
  if (!bar) return;
  var threshold = 600;
  // Real fix: this used to check window.innerWidth ONCE when the page
  // first loaded and never again — if that single check ran under any
  // unusual condition (viewport not fully settled yet, a tablet in an
  // in-between width, a later resize/rotation), there was nothing to
  // catch it afterward, since the scroll listener it attached kept
  // running unconditionally forever. Using matchMedia with the exact
  // same 768px breakpoint the CSS uses keeps this in sync with the CSS
  // safety net (assets/css/vendor-site-static.css) instead of drifting
  // from it, and re-evaluates on every resize, not just once.
  var mq = window.matchMedia('(min-width: 769px)');

  function vsCheckSticky() {
    if (!mq.matches) { bar.style.display = 'none'; return; }
    bar.style.display = window.scrollY > threshold ? 'block' : 'none';
  }

  window.addEventListener('scroll', vsCheckSticky, { passive: true });
  if (mq.addEventListener) { mq.addEventListener('change', vsCheckSticky); }
  else if (mq.addListener) { mq.addListener(vsCheckSticky); } // Safari <14 fallback
  vsCheckSticky();
})();
</script>

<?php
// ══════════════════════════════════════════════════════════════════════════════
// FIXED — audit gap: GroupDealService's public join/book actions
// (gs_join_group_deal, gs_get_group_deals, gs_book_flash_slot,
// gs_get_flash_slots) had no customer-facing UI anywhere, despite being
// fully built and hardened (nonce + rate-limited). Deliberately appended
// here, at the very end of the file, entirely gated behind isset() checks
// on two new-only query params this page never previously read — so this
// block cannot change anything about the page's existing rendering,
// existing variables, or existing behavior for the vast majority of
// visits that don't carry these params. Reached via the share link
// generated on the vendor's own Promotions screen
// (templates/pages/vendor-dashboard.php, case 'promotions').
// ══════════════════════════════════════════════════════════════════════════════
$_vs_deal_id = isset( $_GET['gs_group_deal'] ) ? sanitize_text_field( wp_unslash( $_GET['gs_group_deal'] ) ) : '';
$_vs_slot_id = isset( $_GET['gs_flash_slot'] ) ? (int) $_GET['gs_flash_slot'] : 0;

if ( $_vs_deal_id || $_vs_slot_id ) :
    global $wpdb;
    $_vs_deal = null; $_vs_slot = null;
    if ( $_vs_deal_id && $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_group_deals'" ) ) {
        $_vs_deal = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_group_deals WHERE id=%s AND listing_id=%d AND status IN ('forming','active') AND expires_at > NOW()",
            $_vs_deal_id, (int) ( $primary->id ?? 0 )
        ) );
    }
    if ( $_vs_slot_id && $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}gs_flash_slots'" ) ) {
        $_vs_slot = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}gs_flash_slots WHERE id=%d AND listing_id=%d AND status='active' AND expires_at > NOW()",
            $_vs_slot_id, (int) ( $primary->id ?? 0 )
        ) );
    }
    if ( $_vs_deal || $_vs_slot ) :
        $_vs_nonce = wp_create_nonce( 'gs_ajax' );
        $_vs_ajax  = admin_url( 'admin-ajax.php' );
?>
<div id="gs-promo-banner" style="position:fixed;left:0;right:0;bottom:0;z-index:99998;background:#fff;border-top:1px solid #E2E8F0;box-shadow:0 -4px 20px rgba(0,0,0,.1);padding:14px 16px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;font-family:inherit">
  <?php if ( $_vs_deal ): ?>
  <div style="flex:1;min-width:200px">
    <div style="font-weight:700;font-size:.9rem;color:#1E293B">🎉 <?php echo esc_html( $_vs_deal->title ); ?></div>
    <div style="font-size:.8rem;color:#64748B">₹<?php echo number_format( (float) $_vs_deal->deal_price ); ?> <span style="text-decoration:line-through;color:#94A3B8">₹<?php echo number_format( (float) $_vs_deal->original_price ); ?></span> · <span id="gs-promo-count"><?php echo (int) $_vs_deal->current_count; ?></span>/<?php echo (int) $_vs_deal->min_bookings; ?> neighbours joined so far</div>
  </div>
  <div id="gs-promo-form" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
    <input id="gs-promo-name" placeholder="Your name" style="padding:8px 10px;border:1px solid #E2E8F0;border-radius:8px;font-size:.82rem;width:130px">
    <input id="gs-promo-phone" placeholder="Phone" style="padding:8px 10px;border:1px solid #E2E8F0;border-radius:8px;font-size:.82rem;width:120px">
    <input id="gs-promo-flat" placeholder="Flat / house no." style="padding:8px 10px;border:1px solid #E2E8F0;border-radius:8px;font-size:.82rem;width:130px">
    <button onclick="gsPromoJoin('<?php echo esc_js( $_vs_deal->id ); ?>')" style="background:#2563EB;color:#fff;border:none;border-radius:8px;padding:9px 18px;font-weight:700;font-size:.85rem;cursor:pointer">Join This Deal</button>
  </div>
  <?php elseif ( $_vs_slot ): ?>
  <div style="flex:1;min-width:200px">
    <div style="font-weight:700;font-size:.9rem;color:#1E293B">⚡ Flash Slot — <?php echo esc_html( date( 'd M', strtotime( $_vs_slot->slot_date ) ) ); ?>, <?php echo esc_html( date( 'g:i A', strtotime( $_vs_slot->slot_time ) ) ); ?></div>
    <div style="font-size:.8rem;color:#64748B">₹<?php echo number_format( (float) $_vs_slot->flash_price ); ?> <span style="text-decoration:line-through;color:#94A3B8">₹<?php echo number_format( (float) $_vs_slot->original_price ); ?></span> · <?php echo (int) $_vs_slot->discount_pct; ?>% off, limited time</div>
  </div>
  <div id="gs-promo-form">
    <?php if ( is_user_logged_in() ): ?>
    <button onclick="gsPromoBookSlot(<?php echo (int) $_vs_slot->id; ?>)" style="background:#059669;color:#fff;border:none;border-radius:8px;padding:9px 18px;font-weight:700;font-size:.85rem;cursor:pointer">Book This Slot</button>
    <?php else: ?>
    <a href="<?php echo esc_url( wp_login_url( home_url( add_query_arg( [], $_SERVER['REQUEST_URI'] ?? '' ) ) ) ); ?>" style="background:#059669;color:#fff;border:none;border-radius:8px;padding:9px 18px;font-weight:700;font-size:.85rem;cursor:pointer;text-decoration:none;display:inline-block">Log In to Book</a>
    <?php endif; ?>
  </div>
  <?php endif; ?>
  <button onclick="document.getElementById('gs-promo-banner').style.display='none'" style="background:none;border:none;color:#94A3B8;font-size:1.1rem;cursor:pointer;padding:4px 8px" title="Dismiss">✕</button>
</div>
<script>
function gsPromoJoin(dealId){
  var name=document.getElementById('gs-promo-name').value.trim();
  var phone=document.getElementById('gs-promo-phone').value.trim();
  if(!name||!phone){alert('Please enter your name and phone number.');return;}
  var fd=new FormData();
  fd.append('action','gs_join_group_deal'); fd.append('nonce','<?php echo esc_js( $_vs_nonce ); ?>');
  fd.append('deal_id',dealId); fd.append('name',name); fd.append('phone',phone);
  fd.append('flat_number',document.getElementById('gs-promo-flat').value.trim());
  fetch('<?php echo esc_js( $_vs_ajax ); ?>',{method:'POST',credentials:'same-origin',body:fd})
    .then(function(r){return r.json();})
    .then(function(j){
      if(j.success){
        document.getElementById('gs-promo-form').innerHTML='<span style="color:#059669;font-weight:700;font-size:.85rem">✓ You\'re in! We\'ll be in touch.</span>';
        var cd=document.getElementById('gs-promo-count'); if(cd&&j.data&&j.data.count)cd.textContent=j.data.count;
      } else {
        alert((j.data&&j.data.message)||'Could not join this deal. It may have just filled up or expired.');
      }
    })
    .catch(function(){ alert('Network error — please try again.'); });
}
function gsPromoBookSlot(slotId){
  var fd=new FormData();
  fd.append('action','gs_book_flash_slot'); fd.append('nonce','<?php echo esc_js( $_vs_nonce ); ?>');
  fd.append('slot_id',slotId);
  fetch('<?php echo esc_js( $_vs_ajax ); ?>',{method:'POST',credentials:'same-origin',body:fd})
    .then(function(r){return r.json();})
    .then(function(j){
      if(j.success){
        document.getElementById('gs-promo-form').innerHTML='<span style="color:#059669;font-weight:700;font-size:.85rem">✓ Slot booked! The vendor will contact you to confirm.</span>';
      } else {
        alert((j.data&&j.data.message)||'This slot is no longer available.');
      }
    })
    .catch(function(){ alert('Network error — please try again.'); });
}
</script>
<?php endif; ?>
<?php endif; ?>
