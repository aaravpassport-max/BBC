<?php
/**
 * GoodService — Section Manager
 *
 * The admin-facing home of the module registry built across this
 * project: shows every section (hand-built and no-code alike, no
 * distinction made in this list beyond a small type badge), which
 * categories each is mapped to, whether it's active, and lets an admin
 * change all of that plus build brand-new sections from scratch —
 * fields only, no PHP.
 *
 * Modelled directly on category-manager.php's own structure and AJAX
 * conventions (same nonce action, same fetch/FormData pattern, same
 * gs-cm-* visual language reused here as gs-sm-* for consistency).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
global $wpdb;
$pfx = $wpdb->prefix . 'gs_';
$nonce = wp_create_nonce( 'gs_ajax' );

\GoodService\Modules\ModulesBootstrap::register_all();
\GoodService\Core\ModuleRegistry::apply_admin_overrides( $wpdb, $pfx );
$all_modules = \GoodService\Core\ModuleRegistry::get_all();

// Real feature — category-assignment redesign. Normalizes a module's
// stored `categories` value (which may be 'all', the legacy flat-slug
// array a code-registered module like RoomTypesModule still uses, or
// the new group format) into the single display shape the Edit
// modal's JS always works with: an array of {main_id, main_name,
// subs}. This is what makes the legacy format retire naturally on
// first save through the new UI, without a disruptive one-time
// migration that could silently misinterpret an edge case — the
// display normalization here is read-only and never itself writes
// anything back to the database.
function gs_sm_normalize_categories_for_display( $categories, array $category_tree ): array {
    if ( $categories === 'all' || ! is_array( $categories ) ) { return []; }
    $by_id = [];
    $by_slug = [];
    // Real fix — confirmed root cause of a reported bug ("sections not
    // showing under the Sections tab"): this only ever indexed TOP-LEVEL
    // categories by slug, so a legacy flat-slug module registration
    // (RoomTypesModule's own ['hotels'], and every one of the 6
    // Hospitality modules built the same way) whose slug actually
    // belongs to a SUBcategory — confirmed live on this site: "Hotels"
    // is a subcategory of "Travel & Tourism", not a top-level category
    // at all — silently resolved to nothing and rendered as a blank
    // Categories cell here. This is a display-only bug: ModuleRegistry::
    // category_matches() itself matches directly against the listing's
    // own resolved category row's slug column regardless of hierarchy,
    // so the actual vendor-facing page and the Widths/Layout admin tools
    // were never affected by this — confirmed by a direct test. Fixed by
    // also indexing every subcategory by its own slug here, tagged with
    // its real parent, so a legacy entry matching a subcategory now
    // displays "Parent → Subcategory" exactly like the structured format
    // already does, instead of silently disappearing.
    $sub_by_slug = []; // slug => [ 'main' => $mc, 'sub' => $sc ]
    foreach ( $category_tree as $mc ) {
        $by_id[ (int) $mc->id ] = $mc;
        $by_slug[ $mc->slug ] = $mc;
        foreach ( $mc->subcategories as $sc ) {
            $sub_by_slug[ $sc->slug ] = [ 'main' => $mc, 'sub' => $sc ];
        }
    }
    $groups = [];
    foreach ( $categories as $entry ) {
        if ( is_string( $entry ) ) {
            // Legacy flat-slug entry. Try a top-level category first
            // (the original, pre-fix behavior — unchanged for a slug
            // that really is a main category), then fall back to a
            // subcategory match, displaying that subcategory specifically
            // rather than the broader "ALL subcategories" reading, since
            // a subcategory-slug match means the assignment really was
            // scoped to just that one subcategory all along.
            $mc = $by_slug[ $entry ] ?? null;
            if ( $mc !== null ) {
                $groups[ (int) $mc->id ] = [ 'main_id' => (int) $mc->id, 'main_name' => $mc->name, 'subs' => 'all' ];
                continue;
            }
            $sub_match = $sub_by_slug[ $entry ] ?? null;
            if ( $sub_match !== null ) {
                $main_id = (int) $sub_match['main']->id;
                $existing = $groups[ $main_id ]['subs'] ?? [];
                if ( $existing !== 'all' ) {
                    $existing[] = [ 'id' => (int) $sub_match['sub']->id, 'name' => $sub_match['sub']->name ];
                    $groups[ $main_id ] = [ 'main_id' => $main_id, 'main_name' => $sub_match['main']->name, 'subs' => $existing ];
                }
                continue;
            }
            continue; // category no longer exists at all — skip gracefully, don't crash
        }
        $entry = (array) $entry;
        if ( ! array_key_exists( 'main_id', $entry ) ) { continue; }
        $main_id = (int) $entry['main_id'];
        $mc = $by_id[ $main_id ] ?? null;
        if ( $mc === null ) { continue; } // category no longer exists — skip gracefully
        $subs = $entry['subs'] ?? 'all';
        if ( $subs === 'all' ) {
            $groups[ $main_id ] = [ 'main_id' => $main_id, 'main_name' => $mc->name, 'subs' => 'all' ];
        } else {
            $sub_display = [];
            foreach ( (array) $subs as $sub_id ) {
                foreach ( $mc->subcategories as $sc ) {
                    if ( (int) $sc->id === (int) $sub_id ) { $sub_display[] = [ 'id' => (int) $sc->id, 'name' => $sc->name ]; break; }
                }
            }
            $groups[ $main_id ] = [ 'main_id' => $main_id, 'main_name' => $mc->name, 'subs' => $sub_display ];
        }
    }
    return array_values( $groups );
}

// Deactivated sections don't appear in get_all() at all (by design — see
// apply_admin_overrides()'s own docblock) but the admin still needs to
// see and be able to reactivate them, so fetch those separately.
$inactive_rows = $wpdb->get_results( "SELECT * FROM {$pfx}module_config WHERE is_active = 0 ORDER BY module_key ASC" ) ?: [];

// Real feature — category-assignment redesign. Replaces the flat
// category list (which fed the old checkbox-wall UI) with the real
// main-category → subcategory hierarchy, via the repository's own
// existing get_with_subcategories() — needed for the new cascading
// Main Category → Subcategory dropdown flow.
$category_tree = ( new \GoodService\Repository\CategoryRepository() )->get_with_subcategories();
$field_type_labels = [
    'text' => 'Text', 'textarea' => 'Paragraph', 'number' => 'Number',
    'image' => 'Image', 'checkbox' => 'Yes/No', 'select' => 'Dropdown', 'url' => 'Link',
];
?>
<style>
.gs-sm { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 1280px; }
/* Real fix — root cause of the broken/question-mark icon in Admin → Sections
   (and the identical symptom in the Inquiry Module screen, which shares this
   same mechanism): these icons are plain emoji CHARACTERS with no SVG/image
   file behind them at all — there is no broken file path to fix. The
   question-mark/tofu box some admins see is the OS/browser's OWN fallback
   glyph for an emoji codepoint (often one using a variation-selector or
   ZWJ sequence, e.g. 🏷️/🗣️/🛎️/🗺️) that its installed system font doesn't
   render, most common on older Windows/Linux font stacks. Forcing an
   explicit color-emoji font stack — rather than leaving it to whatever text
   font the browser already chose for the surrounding UI — makes the browser
   pick a font that actually has these glyphs wherever one is installed. */
.gs-icon-emoji, .gs-sm-hdr-icon { font-family: "Segoe UI Emoji","Noto Color Emoji","Apple Color Emoji","Twemoji Mozilla",sans-serif; }
.gs-sm *, .gs-sm *::before, .gs-sm *::after { box-sizing: border-box; }
.gs-sm-hdr { background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border-radius: 12px; margin: 0 0 20px; padding: 24px 28px; color: #fff; box-shadow: 0 4px 24px rgba(0,0,0,.18); display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px; }
.gs-sm-hdr-left { display: flex; align-items: center; gap: 16px; }
.gs-sm-hdr-icon { font-size: 2.4rem; line-height: 1; }
.gs-sm-hdr h1 { margin: 0; font-size: 1.3rem; }
.gs-sm-hdr p { margin: 4px 0 0; opacity: .75; font-size: .85rem; }
.gs-sm-btn { background: #2563EB; color: #fff; border: none; border-radius: 8px; padding: 10px 18px; font-size: .85rem; font-weight: 700; cursor: pointer; }
.gs-sm-btn:hover { background: #1D4ED8; }
.gs-sm-btn-ghost { background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.25); color: #fff; }
.gs-sm-table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.gs-sm-table th { text-align: left; font-size: .72rem; text-transform: uppercase; letter-spacing: .05em; color: #64748B; background: #F8FAFC; padding: 10px 14px; border-bottom: 1px solid #E2E8F0; }
.gs-sm-table td { padding: 12px 14px; border-bottom: 1px solid #F1F5F9; font-size: .87rem; vertical-align: middle; }
.gs-sm-badge { display: inline-block; font-size: .68rem; font-weight: 700; padding: 2px 8px; border-radius: 20px; }
.gs-sm-badge-custom { background: #EFF6FF; color: #2563EB; }
.gs-sm-badge-schema { background: #F0FDF4; color: #16A34A; }
.gs-sm-badge-all { background: #F1F5F9; color: #475569; }
.gs-sm-badge-cat { background: #FEF3C7; color: #92400E; margin: 2px 3px 2px 0; }
.gs-sm-badge-inactive { background: #FEF2F2; color: #DC2626; }
.gs-sm-toggle { width: 40px; height: 22px; border-radius: 20px; position: relative; cursor: pointer; border: none; padding: 0; }
.gs-sm-toggle.on { background: #16A34A; } .gs-sm-toggle.off { background: #CBD5E1; }
.gs-sm-toggle::after { content: ''; position: absolute; top: 2px; width: 18px; height: 18px; border-radius: 50%; background: #fff; transition: .15s; }
.gs-sm-toggle.on::after { left: 20px; } .gs-sm-toggle.off::after { left: 2px; }
.gs-sm-modal-overlay { display: none; position: fixed; inset: 0; background: rgba(15,23,42,.5); z-index: 9998; align-items: center; justify-content: center; padding: 20px; }
.gs-sm-modal-overlay.show { display: flex; }
.gs-sm-modal { background: #fff; border-radius: 14px; max-width: 560px; width: 100%; max-height: 88vh; overflow-y: auto; padding: 24px; }
.gs-sm-modal h2 { margin: 0 0 4px; font-size: 1.1rem; }
.gs-sm-modal .sub { color: #64748B; font-size: .82rem; margin-bottom: 18px; }
.gs-sm-fg { margin-bottom: 14px; }
.gs-sm-label { display: block; font-size: .78rem; font-weight: 700; color: #334155; margin-bottom: 5px; }
.gs-sm-input, .gs-sm-select { width: 100%; padding: 8px 10px; border: 1px solid #E2E8F0; border-radius: 7px; font-size: .85rem; }
.gs-sm-cat-checks { display: flex; flex-wrap: wrap; gap: 8px; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px; }
.gs-sm-cat-checks label { display: flex; align-items: center; gap: 5px; font-size: .8rem; background: #F8FAFC; padding: 4px 9px; border-radius: 6px; cursor: pointer; }
.gs-sm-field-row { display: grid; grid-template-columns: 1fr 1fr 110px 70px 30px; gap: 8px; margin-bottom: 8px; align-items: center; }
.gs-sm-notice { position: fixed; top: 20px; right: 20px; z-index: 10000; padding: 12px 18px; border-radius: 8px; font-size: .85rem; font-weight: 600; box-shadow: 0 4px 20px rgba(0,0,0,.15); display: none; }
.gs-sm-notice.ok { background: #DCFCE7; color: #166534; } .gs-sm-notice.err { background: #FEF2F2; color: #DC2626; }
</style>

<div class="gs-sm">
  <div class="gs-sm-hdr">
    <div class="gs-sm-hdr-left">
      <div class="gs-sm-hdr-icon">🧩</div>
      <div>
        <h1>Section Manager</h1>
        <p><?php echo count( $all_modules ); ?> active sections · <?php echo count( $inactive_rows ); ?> inactive</p>
      </div>
    </div>
    <button class="gs-sm-btn gs-sm-btn-ghost" onclick="gsSmOpenBuilder()">➕ Build New Section</button>
  </div>

  <div id="gs-sm-notice" class="gs-sm-notice"></div>

  <table class="gs-sm-table">
    <thead><tr><th>Section</th><th>Type</th><th>Categories</th><th>Vendor Opt-In</th><th>Order</th><th>Active</th><th></th></tr></thead>
    <tbody id="gs-sm-tbody">
      <?php foreach ( $all_modules as $key => $mod ): ?>
      <tr data-key="<?php echo esc_attr( $key ); ?>">
        <td><span class="gs-icon-emoji"><?php echo esc_html( $mod['icon'] ); ?></span> <strong><?php echo esc_html( $mod['label'] ); ?></strong><div style="font-size:.72rem;color:#94A3B8"><?php echo esc_html( $key ); ?></div></td>
        <td><span class="gs-sm-badge gs-sm-badge-<?php echo $mod['type'] === 'schema' ? 'schema' : 'custom'; ?>"><?php echo $mod['type'] === 'schema' ? 'No-Code' : 'Built-In'; ?></span></td>
        <td>
          <?php if ( $mod['categories'] === 'all' ): ?>
            <span class="gs-sm-badge gs-sm-badge-all">All Categories</span>
          <?php else:
            // Real fix: this previously assumed every entry in
            // $mod['categories'] was a plain slug string to print
            // directly — true for the legacy format, but a real
            // display bug for the new {main_id, subs} group format
            // (an array printed via esc_html()). Reused the same
            // normalizer already built for the Edit modal, so both
            // places read the exact same, correctly-handled shape.
            $_display_groups = gs_sm_normalize_categories_for_display( $mod['categories'], $category_tree );
            foreach ( $_display_groups as $_g ):
              $_subs_label = $_g['subs'] === 'all' ? 'All' : implode( ', ', array_column( $_g['subs'], 'name' ) );
          ?>
            <span class="gs-sm-badge gs-sm-badge-cat"><?php echo esc_html( $_g['main_name'] . ' → ' . $_subs_label ); ?></span>
          <?php endforeach; endif; ?>
        </td>
        <td><?php echo $mod['default_enabled'] ? 'Always on' : 'Vendor selects'; ?></td>
        <td><?php echo (int) ( $mod['sort_order'] ?? 0 ); ?></td>
        <td><button class="gs-sm-toggle on" onclick="gsSmDeactivate('<?php echo esc_js( $key ); ?>', this)"></button></td>
        <td><button class="gs-sm-btn gs-sm-btn-ghost" style="color:#2563EB;border-color:#2563EB;padding:6px 12px" onclick='gsSmOpenEdit(<?php echo wp_json_encode( [ "key" => $key, "label" => $mod["label"], "icon" => $mod["icon"], "categories" => $mod["categories"] === "all" ? "all" : gs_sm_normalize_categories_for_display( $mod["categories"], $category_tree ), "default_enabled" => $mod["default_enabled"], "sort_order" => $mod["sort_order"] ?? 0, "is_active" => 1 ] ); ?>)'>Edit</button></td>
      </tr>
      <?php endforeach; ?>
      <?php foreach ( $inactive_rows as $row ): ?>
      <tr data-key="<?php echo esc_attr( $row->module_key ); ?>" style="opacity:.6">
        <td><span class="gs-icon-emoji"><?php echo esc_html( $row->icon ?: '🧩' ); ?></span> <strong><?php echo esc_html( $row->label ?: $row->module_key ); ?></strong><div style="font-size:.72rem;color:#94A3B8"><?php echo esc_html( $row->module_key ); ?></div></td>
        <td><span class="gs-sm-badge gs-sm-badge-inactive">Inactive</span></td>
        <td colspan="3">—</td>
        <td><button class="gs-sm-toggle off" onclick="gsSmReactivate('<?php echo esc_js( $row->module_key ); ?>', this)"></button></td>
        <td></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<!-- Edit existing section's config -->
<div class="gs-sm-modal-overlay" id="gs-sm-edit-overlay">
  <div class="gs-sm-modal">
    <h2>Edit Section</h2>
    <div class="sub">Changes apply immediately — no code, no deploy.</div>
    <input type="hidden" id="gs-sm-edit-key">
    <!-- Real fix: preserves the section's current active state through
         an edit — editing category/subcategory assignments must never
         change whether the section is active, but the save endpoint
         needs SOME value for is_active in every request. Populated by
         gsSmOpenEdit() from the row's own known-active state (every
         row in this table is, by definition, currently active) and
         sent back unchanged by gsSmSaveEdit() — never touched by
         anything else in this modal. -->
    <input type="hidden" id="gs-sm-edit-is-active" value="1">
    <div class="gs-sm-fg"><label class="gs-sm-label">Display Name</label><input type="text" id="gs-sm-edit-label" class="gs-sm-input"></div>
    <div class="gs-sm-fg"><label class="gs-sm-label">Icon (emoji)</label><input type="text" id="gs-sm-edit-icon" class="gs-sm-input" style="width:80px"></div>
    <div class="gs-sm-fg">
      <label class="gs-sm-label">Available For</label>
      <label style="display:flex;align-items:center;gap:6px;margin-bottom:10px;font-size:.85rem"><input type="checkbox" id="gs-sm-edit-all-cats" onchange="gsSmToggleAllCats()"> All categories (regular/common section)</label>
      <!-- Real feature — category-assignment redesign. Replaces the
           old checkbox wall (every main + subcategory shown at once)
           with the required flow: pick a main category, then pick
           ALL or specific subcategories under it, add it as a group,
           repeat for as many main categories as needed. -->
      <div id="gs-sm-edit-cat-groups" style="display:flex;flex-direction:column;gap:8px;margin-bottom:10px"></div>
      <div id="gs-sm-edit-cat-adder" style="display:flex;gap:8px;align-items:flex-start;background:#F8FAFC;border:1px dashed #CBD5E1;border-radius:8px;padding:10px">
        <select id="gs-sm-edit-main-select" class="gs-sm-select" style="flex:1" onchange="gsSmPopulateSubcats('edit')">
          <option value="">— Main Category —</option>
          <?php foreach ( $category_tree as $mc ): ?>
          <option value="<?php echo (int) $mc->id; ?>"><?php echo esc_html( $mc->name ); ?></option>
          <?php endforeach; ?>
        </select>
        <div id="gs-sm-edit-sub-picker" style="flex:2;display:none">
          <label style="display:flex;align-items:center;gap:5px;font-size:.78rem;font-weight:700;margin-bottom:4px"><input type="checkbox" id="gs-sm-edit-sub-all" checked onchange="gsSmToggleSubAll('edit')"> ALL subcategories</label>
          <div id="gs-sm-edit-sub-list" style="display:none;flex-wrap:wrap;gap:6px;max-height:120px;overflow-y:auto"></div>
        </div>
        <button type="button" class="gs-sm-btn" style="padding:8px 14px;font-size:.78rem;flex-shrink:0" onclick="gsSmAddCatGroup('edit')">+ Add</button>
      </div>
    </div>
    <div class="gs-sm-fg">
      <label style="display:flex;align-items:center;gap:6px;font-size:.85rem" id="gs-sm-edit-default-row"><input type="checkbox" id="gs-sm-edit-default"> Show automatically for every matching listing (only possible for "All categories")</label>
    </div>
    <div class="gs-sm-fg"><label class="gs-sm-label">Sort Order</label><input type="number" id="gs-sm-edit-order" class="gs-sm-input" style="width:100px"></div>
    <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:10px">
      <button class="gs-sm-btn gs-sm-btn-ghost" style="background:#F1F5F9;color:#334155" onclick="gsSmCloseModals()">Cancel</button>
      <button class="gs-sm-btn" onclick="gsSmSaveEdit()">Save Changes</button>
    </div>
  </div>
</div>

<!-- Build a brand new no-code section -->
<div class="gs-sm-modal-overlay" id="gs-sm-builder-overlay">
  <div class="gs-sm-modal" style="max-width:680px">
    <h2>Build New Section</h2>
    <div class="sub">No code. Define the fields below and this becomes a real, assignable section immediately.</div>
    <div class="gs-sm-fg"><label class="gs-sm-label">Section Name</label><input type="text" id="gs-sm-new-label" class="gs-sm-input" placeholder="e.g. Gym Facilities"></div>
    <div class="gs-sm-fg"><label class="gs-sm-label">Icon (emoji)</label><input type="text" id="gs-sm-new-icon" class="gs-sm-input" style="width:80px" value="🧩"></div>
    <div class="gs-sm-fg">
      <label class="gs-sm-label">Available For</label>
      <label style="display:flex;align-items:center;gap:6px;margin-bottom:10px;font-size:.85rem"><input type="checkbox" id="gs-sm-new-all-cats" onchange="gsSmToggleAllCatsNew()"> All categories</label>
      <div id="gs-sm-new-cat-groups" style="display:flex;flex-direction:column;gap:8px;margin-bottom:10px"></div>
      <div id="gs-sm-new-cat-adder" style="display:flex;gap:8px;align-items:flex-start;background:#F8FAFC;border:1px dashed #CBD5E1;border-radius:8px;padding:10px">
        <select id="gs-sm-new-main-select" class="gs-sm-select" style="flex:1" onchange="gsSmPopulateSubcats('new')">
          <option value="">— Main Category —</option>
          <?php foreach ( $category_tree as $mc ): ?>
          <option value="<?php echo (int) $mc->id; ?>"><?php echo esc_html( $mc->name ); ?></option>
          <?php endforeach; ?>
        </select>
        <div id="gs-sm-new-sub-picker" style="flex:2;display:none">
          <label style="display:flex;align-items:center;gap:5px;font-size:.78rem;font-weight:700;margin-bottom:4px"><input type="checkbox" id="gs-sm-new-sub-all" checked onchange="gsSmToggleSubAll('new')"> ALL subcategories</label>
          <div id="gs-sm-new-sub-list" style="display:none;flex-wrap:wrap;gap:6px;max-height:120px;overflow-y:auto"></div>
        </div>
        <button type="button" class="gs-sm-btn" style="padding:8px 14px;font-size:.78rem;flex-shrink:0" onclick="gsSmAddCatGroup('new')">+ Add</button>
      </div>
    </div>
    <div class="gs-sm-fg">
      <label class="gs-sm-label">Fields</label>
      <div id="gs-sm-new-fields"></div>
      <button type="button" class="gs-sm-btn gs-sm-btn-ghost" style="background:#F1F5F9;color:#334155;margin-top:6px" onclick="gsSmAddFieldRow()">+ Add Field</button>
    </div>
    <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:14px">
      <button class="gs-sm-btn gs-sm-btn-ghost" style="background:#F1F5F9;color:#334155" onclick="gsSmCloseModals()">Cancel</button>
      <button class="gs-sm-btn" onclick="gsSmCreateSection()">Create Section</button>
    </div>
  </div>
</div>

<script>
(function(){
var AJX = '<?php echo esc_js( admin_url( "admin-ajax.php" ) ); ?>';
var NONCE = '<?php echo esc_js( $nonce ); ?>';
// Real feature — category-assignment redesign: main_id -> [{id, name}, ...],
// so the subcategory dropdown populates instantly with no round-trip
// once a main category is chosen.
var CAT_TREE = <?php
    $_cat_tree_js = [];
    foreach ( $category_tree as $mc ) {
        $_cat_tree_js[ (int) $mc->id ] = [
            'name' => $mc->name,
            'subs' => array_map( fn( $sc ) => [ 'id' => (int) $sc->id, 'name' => $sc->name ], $mc->subcategories ),
        ];
    }
    echo wp_json_encode( $_cat_tree_js );
?>;
var FIELD_TYPES = <?php echo wp_json_encode( $field_type_labels ); ?>;

function post(data, cb) {
  var fd = new FormData();
  fd.append('nonce', NONCE);
  Object.keys(data).forEach(function(k){ fd.append(k, data[k]); });
  fetch(AJX, {method:'POST', body:fd})
    .then(function(r){ return r.json(); })
    .then(cb)
    .catch(function(){ showNotice('Network error — please try again.', 'err'); });
}
function showNotice(msg, type) {
  var n = document.getElementById('gs-sm-notice');
  n.textContent = msg; n.className = 'gs-sm-notice ' + type; n.style.display = 'block';
  setTimeout(function(){ n.style.display = 'none'; }, 3500);
}
window.gsSmCloseModals = function() {
  document.getElementById('gs-sm-edit-overlay').classList.remove('show');
  document.getElementById('gs-sm-builder-overlay').classList.remove('show');
};

// ── Deactivate / reactivate ──
window.gsSmDeactivate = function(key, btn) {
  if (!confirm('Hide "' + key + '" from every listing? Existing data is kept — you can reactivate it later.')) return;
  post({action:'gs_admin_section_deactivate', module_key:key}, function(d) {
    if (d.success) { showNotice('Section deactivated.', 'ok'); setTimeout(function(){ location.reload(); }, 600); }
    else { showNotice(d.data.message || 'Failed.', 'err'); }
  });
};
window.gsSmReactivate = function(key, btn) {
  post({action:'gs_admin_section_reactivate', module_key:key}, function(d) {
    if (d.success) { showNotice('Section reactivated.', 'ok'); setTimeout(function(){ location.reload(); }, 600); }
    else { showNotice(d.data.message || 'Failed.', 'err'); }
  });
};

// ── Edit existing ──
// Real feature — category-assignment redesign. Each context ('edit' or
// 'new') keeps its own in-memory array of {main_id, main_name, subs}
// groups — subs is either the string 'all' or an array of {id, name}
// objects for display, serialized to just IDs on save. This is the
// actual state the Add/Remove/Save flow operates on; the DOM only
// reflects it, never the other way around, so there is exactly one
// source of truth per modal instance.
window.gsSmEditGroups = [];
window.gsSmNewGroups = [];

function gsSmGroupsVar(ctx) { return ctx === 'edit' ? window.gsSmEditGroups : window.gsSmNewGroups; }
function gsSmSetGroupsVar(ctx, val) { if (ctx === 'edit') window.gsSmEditGroups = val; else window.gsSmNewGroups = val; }

// Shows the subcategory picker for whichever main category was just
// selected in the adder row, and resets it back to "ALL" checked with
// the individual list collapsed — a fresh, predictable starting point
// each time a different main category is picked.
window.gsSmPopulateSubcats = function(ctx) {
  var mainSel = document.getElementById('gs-sm-' + ctx + '-main-select');
  var picker = document.getElementById('gs-sm-' + ctx + '-sub-picker');
  var list = document.getElementById('gs-sm-' + ctx + '-sub-list');
  var allCb = document.getElementById('gs-sm-' + ctx + '-sub-all');
  var mainId = mainSel.value;
  if (!mainId) { picker.style.display = 'none'; return; }
  var subs = (CAT_TREE[mainId] && CAT_TREE[mainId].subs) || [];
  picker.style.display = 'block';
  allCb.checked = true;
  list.style.display = 'none';
  list.innerHTML = subs.map(function(s) {
    return '<label style="display:flex;align-items:center;gap:4px;font-size:.76rem;background:#fff;border:1px solid #E2E8F0;border-radius:5px;padding:3px 7px">' +
      '<input type="checkbox" class="gs-sm-' + ctx + '-sub-cb" value="' + s.id + '" data-name="' + s.name.replace(/"/g,'&quot;') + '">' + s.name + '</label>';
  }).join('');
};

// "ALL subcategories" and "pick specific ones" are mutually exclusive
// within one group being added — unticking ALL reveals the individual
// list so specific ones can be chosen instead, matching the required
// "removing ALL should allow individual subcategory selection" behavior.
window.gsSmToggleSubAll = function(ctx) {
  var all = document.getElementById('gs-sm-' + ctx + '-sub-all').checked;
  document.getElementById('gs-sm-' + ctx + '-sub-list').style.display = all ? 'none' : 'flex';
};

// Reads the adder row's current selection, appends it as a new group,
// and resets the adder for the next addition. Adding a main category
// that's already present replaces its existing group rather than
// creating a confusing duplicate entry for the same main category.
window.gsSmAddCatGroup = function(ctx) {
  var mainSel = document.getElementById('gs-sm-' + ctx + '-main-select');
  var mainId = parseInt(mainSel.value, 10);
  if (!mainId) { showNotice('Choose a main category first.', 'err'); return; }
  var mainName = CAT_TREE[mainId] ? CAT_TREE[mainId].name : ('#' + mainId);
  var allChecked = document.getElementById('gs-sm-' + ctx + '-sub-all').checked;
  var subs;
  if (allChecked) {
    subs = 'all';
  } else {
    subs = Array.from(document.querySelectorAll('.gs-sm-' + ctx + '-sub-cb:checked')).map(function(cb) {
      return { id: parseInt(cb.value, 10), name: cb.dataset.name };
    });
    if (!subs.length) { showNotice('Pick at least one subcategory, or tick ALL.', 'err'); return; }
  }
  var groups = gsSmGroupsVar(ctx).filter(function(g) { return g.main_id !== mainId; });
  groups.push({ main_id: mainId, main_name: mainName, subs: subs });
  gsSmSetGroupsVar(ctx, groups);
  gsSmRenderGroups(ctx);
  mainSel.value = '';
  document.getElementById('gs-sm-' + ctx + '-sub-picker').style.display = 'none';
};

window.gsSmRemoveCatGroup = function(ctx, mainId) {
  gsSmSetGroupsVar(ctx, gsSmGroupsVar(ctx).filter(function(g) { return g.main_id !== mainId; }));
  gsSmRenderGroups(ctx);
};

// Renders each group as a removable chip: "Main Category → ALL" or
// "Main Category → Sub A, Sub B" — the actual, persistent record of
// what's been added so far, kept visibly selected as required.
function gsSmRenderGroups(ctx) {
  var wrap = document.getElementById('gs-sm-' + ctx + '-cat-groups');
  var groups = gsSmGroupsVar(ctx);
  wrap.innerHTML = groups.map(function(g) {
    var subsLabel = g.subs === 'all' ? 'ALL' : g.subs.map(function(s){ return s.name; }).join(', ');
    return '<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:7px;padding:7px 10px;font-size:.8rem">' +
      '<span><strong>' + g.main_name + '</strong> → ' + subsLabel + '</span>' +
      '<button type="button" onclick="gsSmRemoveCatGroup(\'' + ctx + '\',' + g.main_id + ')" style="background:none;border:none;color:#DC2626;cursor:pointer;font-size:.9rem">✕</button>' +
      '</div>';
  }).join('') || '<div style="font-size:.78rem;color:#94A3B8;padding:4px 0">No categories added yet.</div>';
}

// Converts the in-memory groups array into the exact JSON shape
// ModuleRegistry::category_matches() expects on the server.
function gsSmGroupsToPayload(ctx) {
  return gsSmGroupsVar(ctx).map(function(g) {
    return { main_id: g.main_id, subs: g.subs === 'all' ? 'all' : g.subs.map(function(s){ return s.id; }) };
  });
}

window.gsSmOpenEdit = function(mod) {
  document.getElementById('gs-sm-edit-key').value = mod.key;
  document.getElementById('gs-sm-edit-label').value = mod.label;
  document.getElementById('gs-sm-edit-icon').value = mod.icon;
  document.getElementById('gs-sm-edit-order').value = mod.sort_order;
  document.getElementById('gs-sm-edit-default').checked = !!mod.default_enabled;
  // Real fix: capture the section's current active state when the
  // modal opens, so saving category/subcategory changes can send it
  // back completely unchanged — editing assignments must never affect
  // whether the section is active, only the toggle button itself may.
  document.getElementById('gs-sm-edit-is-active').value = mod.is_active ? '1' : '0';
  var allCats = mod.categories === 'all';
  document.getElementById('gs-sm-edit-all-cats').checked = allCats;
  // mod.categories, when not 'all', is ALREADY normalized server-side
  // (see section-manager.php's own PHP loop) into the {main_id, subs,
  // main_name} display shape below, regardless of whether the real,
  // stored value is the new group format or the legacy flat-slug
  // format — the edit UI never needs to know which one it originally
  // was; saving always writes the new format going forward, which is
  // how the legacy format is naturally, safely retired without a
  // disruptive one-time migration that could lose data if it guessed
  // wrong about any edge case.
  window.gsSmEditGroups = allCats ? [] : ( Array.isArray(mod.categories) ? mod.categories : [] );
  gsSmRenderGroups('edit');
  gsSmToggleAllCats();
  document.getElementById('gs-sm-edit-overlay').classList.add('show');
};
window.gsSmToggleAllCats = function() {
  var all = document.getElementById('gs-sm-edit-all-cats').checked;
  document.getElementById('gs-sm-edit-cat-groups').style.opacity = all ? '.4' : '1';
  document.getElementById('gs-sm-edit-cat-adder').style.display = all ? 'none' : 'flex';
  // A category-specific section can never be "always on" (enforced by
  // disabling+unchecking below) — and, the exact reported bug, the
  // reverse is equally true: a section with NO category restrictions
  // has no way for a vendor to ever opt into it (the opt-in checklist
  // only ever shows genuinely category-specific sections), so "All
  // categories" must always imply default_enabled=true — locked ON
  // here, not left as an optional choice, matching the server-side fix
  // that now forces this automatically regardless of what gets sent.
  document.getElementById('gs-sm-edit-default').disabled = true;
  document.getElementById('gs-sm-edit-default').checked = all;
};
window.gsSmSaveEdit = function() {
  var allCats = document.getElementById('gs-sm-edit-all-cats').checked;
  var cats = allCats ? 'all' : gsSmGroupsToPayload('edit');
  if (!allCats && !cats.length) { showNotice('Add at least one category, or tick "All categories".', 'err'); return; }
  post({
    action: 'gs_admin_section_save_config',
    module_key: document.getElementById('gs-sm-edit-key').value,
    label: document.getElementById('gs-sm-edit-label').value,
    icon: document.getElementById('gs-sm-edit-icon').value,
    categories: JSON.stringify(cats),
    default_enabled: document.getElementById('gs-sm-edit-default').checked ? '1' : '',
    is_active: document.getElementById('gs-sm-edit-is-active').value,
    sort_order: document.getElementById('gs-sm-edit-order').value,
  }, function(d) {
    if (d.success) { showNotice('Saved.', 'ok'); setTimeout(function(){ location.reload(); }, 500); }
    else { showNotice(d.data.message || 'Failed.', 'err'); }
  });
};

// ── Build new section ──
window.gsSmOpenBuilder = function() {
  document.getElementById('gs-sm-new-label').value = '';
  document.getElementById('gs-sm-new-icon').value = '🧩';
  document.getElementById('gs-sm-new-all-cats').checked = false;
  window.gsSmNewGroups = [];
  gsSmRenderGroups('new');
  document.getElementById('gs-sm-new-cat-adder').style.display = 'flex';
  document.getElementById('gs-sm-new-main-select').value = '';
  document.getElementById('gs-sm-new-sub-picker').style.display = 'none';
  document.getElementById('gs-sm-new-fields').innerHTML = '';
  gsSmAddFieldRow();
  document.getElementById('gs-sm-builder-overlay').classList.add('show');
};
window.gsSmToggleAllCatsNew = function() {
  var all = document.getElementById('gs-sm-new-all-cats').checked;
  document.getElementById('gs-sm-new-cat-groups').style.opacity = all ? '.4' : '1';
  document.getElementById('gs-sm-new-cat-adder').style.display = all ? 'none' : 'flex';
};
window.gsSmAddFieldRow = function() {
  var wrap = document.getElementById('gs-sm-new-fields');
  var opts = Object.keys(FIELD_TYPES).map(function(k){ return '<option value="'+k+'">'+FIELD_TYPES[k]+'</option>'; }).join('');
  var row = document.createElement('div');
  row.className = 'gs-sm-field-row';
  row.innerHTML =
    '<input type="text" class="gs-sm-input gs-sm-f-label" placeholder="Field label (e.g. Room Name)">' +
    '<input type="text" class="gs-sm-input gs-sm-f-key" placeholder="field_key (auto)">' +
    '<select class="gs-sm-select gs-sm-f-type">' + opts + '</select>' +
    '<label style="font-size:.72rem;display:flex;align-items:center;gap:3px"><input type="checkbox" class="gs-sm-f-repeater" checked>Repeats</label>' +
    '<button type="button" onclick="this.closest(\'.gs-sm-field-row\').remove()" style="background:none;border:none;color:#94A3B8;cursor:pointer;font-size:1rem">✕</button>';
  wrap.appendChild(row);
  row.querySelector('.gs-sm-f-label').addEventListener('input', function(e) {
    var keyInput = row.querySelector('.gs-sm-f-key');
    if (!keyInput.dataset.touched) {
      keyInput.value = e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
    }
  });
  row.querySelector('.gs-sm-f-key').addEventListener('input', function(e) { e.target.dataset.touched = '1'; });
};
window.gsSmCreateSection = function() {
  var label = document.getElementById('gs-sm-new-label').value.trim();
  if (!label) { showNotice('Section name is required.', 'err'); return; }
  var allCats = document.getElementById('gs-sm-new-all-cats').checked;
  var cats = allCats ? 'all' : gsSmGroupsToPayload('new');
  if (!allCats && !cats.length) { showNotice('Add at least one category, or tick "All categories".', 'err'); return; }
  var fields = Array.from(document.querySelectorAll('#gs-sm-new-fields .gs-sm-field-row')).map(function(row) {
    return {
      label: row.querySelector('.gs-sm-f-label').value.trim(),
      key: row.querySelector('.gs-sm-f-key').value.trim(),
      type: row.querySelector('.gs-sm-f-type').value,
      repeater: row.querySelector('.gs-sm-f-repeater').checked,
    };
  }).filter(function(f){ return f.label && f.key; });
  if (!fields.length) { showNotice('Add at least one field.', 'err'); return; }
  post({
    action: 'gs_admin_section_create',
    label: label,
    icon: document.getElementById('gs-sm-new-icon').value || '🧩',
    categories: JSON.stringify(cats),
    fields: JSON.stringify(fields),
  }, function(d) {
    if (d.success) { showNotice('Section "' + label + '" created!', 'ok'); setTimeout(function(){ location.reload(); }, 700); }
    else { showNotice(d.data.message || 'Failed.', 'err'); }
  });
};
})();
</script>
