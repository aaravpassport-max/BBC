<?php
/**
 * GoodService — Category Manager
 * UI modelled after the Category Manager Pro reference plugin.
 * Uses gs_categories table (not WP taxonomy).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
global $wpdb;
$pfx   = $wpdb->prefix . 'gs_';
$nonce = wp_create_nonce( 'gs_ajax' );

/* ── Build category tree ─────────────────────────────────── */
if ( ! function_exists( 'gs_cm_tree' ) ) {
    function gs_cm_tree( array $cats, int $parent = 0, int $depth = 0 ): array {
        $out = [];
        foreach ( $cats as $c ) {
            if ( (int)$c->parent_id !== $parent ) continue;
            $c->depth = $depth;
            $out[]    = $c;
            $out      = array_merge( $out, gs_cm_tree( $cats, (int)$c->id, $depth + 1 ) );
        }
        return $out;
    }
}
if ( ! function_exists( 'gs_cm_options' ) ) {
    function gs_cm_options( array $tree, array $selected = [], int $exclude = 0 ): void {
        foreach ( $tree as $c ) {
            if ( (int)$c->id === $exclude ) continue;
            $indent = str_repeat( '&nbsp;&nbsp;&nbsp;&nbsp;', $c->depth ) . ( $c->depth ? '└ ' : '' );
            $sel    = in_array( $c->id, $selected, true ) ? 'selected' : '';
            $cnt    = (int)( $c->active_listings ?? $c->listing_count ?? 0 );
            $lbl    = $cnt ? " ({$cnt})" : '';
            echo "<option value='{$c->id}' {$sel}>{$indent}" . esc_html( $c->name ) . esc_html( $lbl ) . '</option>';
        }
    }
}

$table_ok   = (bool) $wpdb->get_var( "SHOW TABLES LIKE '{$pfx}categories'" );
$all_raw    = $table_ok ? ( $wpdb->get_results(
    "SELECT c.*, (SELECT COUNT(*) FROM {$pfx}listings l WHERE (l.category_id=c.id OR l.subcategory_id=c.id) AND l.status='active') AS active_listings
     FROM {$pfx}categories c ORDER BY c.sort_order ASC, c.name ASC"
) ?: [] ) : [];
$all_tree   = gs_cm_tree( $all_raw );
$total_cats = count( $all_raw );
$total_listings = array_sum( array_map( fn($c) => (int)($c->active_listings ?? 0), $all_raw ) );
?>
<style>
/* ── Category Manager Pro – GoodService Edition ─── */
.gs-cm { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 1280px; }
.gs-cm *, .gs-cm *::before, .gs-cm *::after { box-sizing: border-box; }

/* Header */
.gs-cm-hdr {
    background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    border-radius: 12px; margin: 0 0 20px; padding: 24px 28px;
    color: #fff; box-shadow: 0 4px 24px rgba(0,0,0,0.18);
    display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px;
}
.gs-cm-hdr-left { display: flex; align-items: center; gap: 16px; }
.gs-cm-hdr-icon { font-size: 2.4rem; line-height: 1; }
.gs-cm-hdr-title { margin: 0 0 4px; font-size: 1.4rem; font-weight: 700; color: #fff; line-height: 1.2; }
.gs-cm-hdr-title .badge {
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    font-size: .65rem; font-weight: 700; padding: 2px 8px; border-radius: 20px;
    letter-spacing: 1px; vertical-align: middle; margin-left: 6px;
}
.gs-cm-hdr-sub { margin: 0; font-size: .82rem; color: #94a3b8; }
.gs-cm-hdr-stats { display: flex; gap: 16px; }
.gs-cm-hdr-stat {
    text-align: center; background: rgba(255,255,255,.07);
    padding: 12px 20px; border-radius: 10px; min-width: 80px;
}
.gs-cm-hdr-stat-num { display: block; font-size: 1.8rem; font-weight: 700; color: #818cf8; line-height: 1; }
.gs-cm-hdr-stat-lbl { font-size: .72rem; color: #94a3b8; text-transform: uppercase; letter-spacing: .5px; margin-top: 4px; display: block; }

/* Grid */
.gs-cm-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
@media (max-width: 900px) { .gs-cm-grid { grid-template-columns: 1fr; } }
.gs-cm-col { display: flex; flex-direction: column; gap: 20px; }

/* Card */
.gs-cm-card {
    background: #fff; border: 1px solid #e2e8f0; border-radius: 10px;
    overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,.06); transition: box-shadow .2s;
}
.gs-cm-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.10); }
.gs-cm-card-head {
    display: flex; align-items: center; gap: 8px;
    background: linear-gradient(90deg, #f8fafc, #f1f5f9);
    border-bottom: 1px solid #e2e8f0; padding: 13px 18px;
    font-size: .87rem; font-weight: 600; color: #1e293b;
}
.gs-cm-card-head .head-icon { color: #6366f1; font-size: 1.1rem; }
.gs-cm-card-head .head-link {
    margin-left: auto; font-size: .73rem; color: #6366f1; text-decoration: none;
    background: rgba(99,102,241,.08); padding: 3px 10px; border-radius: 20px;
}
.gs-cm-card-head .head-link:hover { background: rgba(99,102,241,.15); }
.gs-cm-body { padding: 18px; }

/* Fields */
.gs-cm-fg { margin-bottom: 13px; }
.gs-cm-fg:last-child { margin-bottom: 0; }
.gs-cm-lbl { display: block; font-size: .72rem; font-weight: 700; color: #475569; margin-bottom: 4px; text-transform: uppercase; letter-spacing: .4px; }
.gs-cm-lbl .muted { font-weight: 400; color: #94a3b8; text-transform: none; letter-spacing: 0; }
.gs-cm-inp, .gs-cm-ta, .gs-cm-sel {
    width: 100%; padding: 9px 12px;
    border: 1px solid #cbd5e1; border-radius: 7px;
    font-size: .87rem; color: #1e293b; background: #fff;
    transition: border-color .15s, box-shadow .15s; font-family: inherit; outline: none;
}
.gs-cm-inp:focus, .gs-cm-ta:focus, .gs-cm-sel:focus { border-color: #6366f1; box-shadow: 0 0 0 3px rgba(99,102,241,.12); }
.gs-cm-ta { resize: vertical; min-height: 80px; }
.gs-cm-mono { font-family: 'Courier New', monospace; font-size: .82rem; }

/* Hint */
.gs-cm-hint {
    background: #f8fafc; border-left: 3px solid #6366f1;
    padding: 10px 14px; border-radius: 0 6px 6px 0;
    font-size: .76rem; color: #475569; line-height: 1.6; margin-bottom: 12px;
}
.gs-cm-hint code { background: #e2e8f0; padding: 1px 5px; border-radius: 4px; font-size: .72rem; font-family: 'Courier New', monospace; }

/* File Upload */
.gs-cm-file-lbl {
    display: flex; align-items: center; gap: 10px;
    padding: 16px; border: 2px dashed #cbd5e1; border-radius: 8px;
    cursor: pointer; transition: border-color .2s, background .2s;
    color: #64748b; font-size: .87rem;
}
.gs-cm-file-lbl:hover { border-color: #6366f1; background: #f5f3ff; color: #6366f1; }
.gs-cm-file-input { position: absolute; opacity: 0; width: 0; height: 0; }

/* Toggle */
.gs-cm-toggle-lbl { display: flex; align-items: center; gap: 10px; cursor: pointer; font-size: .87rem; color: #1e293b; }
.gs-cm-toggle-inp { position: absolute; opacity: 0; width: 0; height: 0; }
.gs-cm-toggle-sw {
    position: relative; display: inline-block;
    width: 38px; height: 22px; background: #cbd5e1; border-radius: 11px;
    transition: background .2s; flex-shrink: 0;
}
.gs-cm-toggle-sw::after {
    content: ''; position: absolute; top: 3px; left: 3px;
    width: 16px; height: 16px; background: #fff; border-radius: 50%;
    box-shadow: 0 1px 3px rgba(0,0,0,.2); transition: transform .2s;
}
.gs-cm-toggle-inp:checked + .gs-cm-toggle-sw { background: #6366f1; }
.gs-cm-toggle-inp:checked + .gs-cm-toggle-sw::after { transform: translateX(16px); }

/* Notice */
.gs-cm-notice {
    display: flex; align-items: flex-start; gap: 10px;
    padding: 14px 18px; border-radius: 8px; margin-bottom: 18px;
    font-size: .87rem; line-height: 1.5; border-left: 4px solid;
}
.gs-cm-notice-success { background: #f0fdf4; border-color: #22c55e; color: #15803d; }
.gs-cm-notice-error   { background: #fef2f2; border-color: #ef4444; color: #b91c1c; }
.gs-cm-notice-info    { background: #eff6ff; border-color: #3b82f6; color: #1d4ed8; }

/* Tree */
.gs-cm-tree { margin: 0; padding: 0; list-style: none; max-height: 260px; overflow-y: auto; }
.gs-cm-tree-item {
    padding: 6px 8px; border-bottom: 1px solid #f1f5f9;
    font-size: .83rem; display: flex; align-items: center; gap: 5px;
}
.gs-cm-tree-item:last-child { border-bottom: none; }
.gs-cm-tree-item a { color: #1e293b; text-decoration: none; flex: 1; }
.gs-cm-tree-item a:hover { color: #6366f1; }
.gs-cm-tree-branch { color: #94a3b8; }
.gs-cm-tree-count { background: #f1f5f9; color: #64748b; font-size: .72rem; padding: 1px 7px; border-radius: 20px; flex-shrink: 0; }
.gs-cm-tree-del { background: none; border: none; color: #dc2626; font-size: .85rem; cursor: pointer; padding: 0 4px; opacity: .5; }
.gs-cm-tree-del:hover { opacity: 1; }

/* Grid row for inline edit */
.gs-cm-inline-row {
    display: flex; align-items: center; gap: 8px;
    padding: 7px 8px; border-bottom: 1px solid #f1f5f9; font-size: .83rem;
}
.gs-cm-inline-row:last-child { border-bottom: none; }
.gs-cm-inline-input { flex: 1; padding: 5px 8px; border: 1px solid #cbd5e1; border-radius: 5px; font-size: .82rem; outline: none; }
.gs-cm-inline-input:focus { border-color: #6366f1; }
.gs-cm-inline-btn { padding: 5px 10px; border: none; border-radius: 5px; font-size: .75rem; font-weight: 600; cursor: pointer; }
.gs-cm-inline-save { background: #059669; color: #fff; }
.gs-cm-inline-del  { background: #dc2626; color: #fff; }

/* Submit bar */
.gs-cm-submit-bar {
    display: flex; align-items: center; gap: 12px;
    padding: 18px; margin-top: 18px;
    background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;
}
.gs-cm-btn-primary {
    display: inline-flex; align-items: center; gap: 7px;
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    color: #fff; border: none; padding: 11px 26px;
    font-size: .87rem; font-weight: 600; border-radius: 8px;
    cursor: pointer; transition: opacity .15s, transform .1s;
    box-shadow: 0 2px 8px rgba(99,102,241,.35); font-family: inherit;
}
.gs-cm-btn-primary:hover { opacity: .92; transform: translateY(-1px); }
.gs-cm-btn-secondary {
    display: inline-flex; align-items: center;
    background: #fff; color: #475569; border: 1px solid #e2e8f0;
    padding: 11px 20px; font-size: .87rem; border-radius: 8px;
    cursor: pointer; transition: border-color .15s; font-family: inherit;
}
.gs-cm-btn-secondary:hover { border-color: #6366f1; color: #6366f1; }

/* Msg */
.gs-cm-msg { font-size: .87rem; line-height: 1.6; padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; }
.gs-cm-msg:empty { display: none; }
</style>

<?php if ( ! $table_ok ): ?>
<div class="gs-cm-notice gs-cm-notice-error">
  ⚠️ Categories table not found. Please go to <strong>WP Admin → GoodService → Flush Routes</strong> to rebuild the database.
</div>
<?php endif; ?>

<div class="gs-cm" id="gs-cm-root">

<!-- ── Header ─────────────────────────────────────── -->
<div class="gs-cm-hdr">
  <div class="gs-cm-hdr-left">
    <div class="gs-cm-hdr-icon">📂</div>
    <div>
      <h2 class="gs-cm-hdr-title">Category Manager <span class="badge">PRO</span></h2>
      <p class="gs-cm-hdr-sub">Bulk create · Hierarchy · Icon/Emoji · CSV Import · Quick Edit</p>
    </div>
  </div>
  <div class="gs-cm-hdr-stats">
    <div class="gs-cm-hdr-stat">
      <span class="gs-cm-hdr-stat-num" id="gs-cm-stat-cats"><?php echo $total_cats; ?></span>
      <span class="gs-cm-hdr-stat-lbl">Categories</span>
    </div>
    <div class="gs-cm-hdr-stat">
      <span class="gs-cm-hdr-stat-num"><?php echo $total_listings; ?></span>
      <span class="gs-cm-hdr-stat-lbl">Listings</span>
    </div>
  </div>
</div>

<div id="gs-cm-notice-bar"></div>

<div class="gs-cm-grid">

  <!-- ══ LEFT COLUMN ══════════════════════════════════════════ -->
  <div class="gs-cm-col">

    <!-- Card: Add Single Category -->
    <div class="gs-cm-card">
      <div class="gs-cm-card-head"><span class="head-icon">➕</span> Add Single Category</div>
      <div class="gs-cm-body">
        <div class="gs-cm-fg">
          <label class="gs-cm-lbl">Category Name *</label>
          <input type="text" id="gs-cm-name" class="gs-cm-inp" placeholder="e.g. Document Services" autocomplete="off">
        </div>
        <div class="gs-cm-fg">
          <label class="gs-cm-lbl">Slug <span class="muted">(auto-generated if blank)</span></label>
          <input type="text" id="gs-cm-slug" class="gs-cm-inp" placeholder="e.g. document-services" autocomplete="off">
        </div>
        <div class="gs-cm-fg">
          <label class="gs-cm-lbl">Icon / Emoji</label>
          <input type="text" id="gs-cm-icon" class="gs-cm-inp" placeholder="📄 or icon class" maxlength="10">
        </div>
        <div class="gs-cm-fg">
          <label class="gs-cm-lbl">Parent Category</label>
          <select id="gs-cm-parent" class="gs-cm-sel">
            <option value="0">— No Parent (Top Level) —</option>
            <?php gs_cm_options( $all_tree ); ?>
          </select>
        </div>
        <div class="gs-cm-fg">
          <label class="gs-cm-lbl">Description <span class="muted">(optional)</span></label>
          <textarea id="gs-cm-desc" class="gs-cm-ta" rows="2" placeholder="Short description…"></textarea>
        </div>
        <button onclick="gsCmAddSingle()" class="gs-cm-btn-primary" style="width:100%;justify-content:center">➕ Add Category</button>
      </div>
    </div>

    <!-- Card: Bulk / Hierarchy Create -->
    <div class="gs-cm-card">
      <div class="gs-cm-card-head"><span class="head-icon">📋</span> Bulk / Hierarchy Create</div>
      <div class="gs-cm-body">
        <div class="gs-cm-hint">
          Use <code>-</code> prefix for child levels. One category per line.<br>
          <strong>Example:</strong><br>
          <code>Certificates</code><br>
          <code>-Birth Certificate</code><br>
          <code>-Marriage Certificate</code><br>
          <code>Legal Services</code>
        </div>
        <textarea id="gs-cm-bulk" class="gs-cm-ta gs-cm-mono" rows="9" placeholder="Certificates&#10;-Birth Certificate&#10;-Marriage Certificate&#10;Legal Services"></textarea>
        <div class="gs-cm-fg" style="margin-top:12px">
          <label class="gs-cm-lbl">Default Parent <span class="muted">(for top-level items)</span></label>
          <select id="gs-cm-bulk-parent" class="gs-cm-sel">
            <option value="0">— No Parent —</option>
            <?php gs_cm_options( $all_tree ); ?>
          </select>
        </div>
        <button onclick="gsCmBulkCreate()" class="gs-cm-btn-primary" style="width:100%;justify-content:center;margin-top:8px">📋 Bulk Create</button>
      </div>
    </div>

    <!-- Card: CSV Import -->
    <div class="gs-cm-card">
      <div class="gs-cm-card-head"><span class="head-icon">📥</span> CSV Import</div>
      <div class="gs-cm-body">
        <div class="gs-cm-hint">
          Columns: <code>name</code>, <code>slug</code> (opt), <code>parent_name</code> (opt), <code>icon</code> (opt), <code>description</code> (opt)<br>
          First row must be headers: <code>name,slug,parent_name,icon,description</code>
        </div>
        <label class="gs-cm-file-lbl">
          <span style="font-size:1.3rem">📊</span>
          <span id="gs-cm-file-lbl-txt">Choose CSV file…</span>
          <input type="file" id="gs-cm-csv" accept=".csv" class="gs-cm-file-input" onchange="document.getElementById('gs-cm-file-lbl-txt').textContent=this.files[0]?this.files[0].name:'Choose CSV file…'">
        </label>
        <button onclick="gsCmCsvImport()" class="gs-cm-btn-primary" style="width:100%;justify-content:center;margin-top:12px">📥 Import CSV</button>
      </div>
    </div>

  </div><!-- /.gs-cm-col -->

  <!-- ══ RIGHT COLUMN ══════════════════════════════════════════ -->
  <div class="gs-cm-col">

    <!-- Card: Current Category Tree -->
    <div class="gs-cm-card" style="flex:1">
      <div class="gs-cm-card-head">
        <span class="head-icon">🌳</span> Current Category Tree
        <span id="gs-cm-tree-count" style="background:#f1f5f9;color:#64748b;font-size:.72rem;padding:2px 8px;border-radius:20px;margin-left:6px"><?php echo $total_cats; ?></span>
        <?php /* ENTERPRISE-AUDIT FIX (Critical, confirmed): CSV import existed here already; export never did. Exported columns match the CSV Import card's own format above, so an export round-trips straight back in. */ ?>
        <a href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=gs_admin_category_export&nonce=' . $nonce ) ); ?>" class="head-link" style="margin-left:8px">⬇ Export CSV</a>
        <a href="#" onclick="gsCmReloadTree();return false" class="head-link">Refresh ↻</a>
      </div>
      <div class="gs-cm-body" style="padding:12px">
        <?php if ( empty( $all_tree ) ): ?>
          <p style="color:#94a3b8;font-size:.83rem;padding:8px">No categories yet. Add your first category.</p>
        <?php else: ?>
          <ul class="gs-cm-tree" id="gs-cm-tree-list">
            <?php foreach ( $all_tree as $c ): ?>
              <li class="gs-cm-tree-item" data-id="<?php echo (int)$c->id; ?>" style="padding-left:<?php echo 8 + $c->depth * 18; ?>px">
                <?php if ( $c->depth ): ?><span class="gs-cm-tree-branch">└</span><?php endif; ?>
                <?php if ( $c->icon_emoji ): ?><span><?php echo esc_html( $c->icon_emoji ); ?></span><?php endif; ?>
                <a href="#" onclick="gsCmEditInline(<?php echo (int)$c->id; ?>,<?php echo (int)($c->parent_id??0); ?>,this);return false"><?php echo esc_html( $c->name ); ?></a>
                <span class="gs-cm-tree-count"><?php echo (int)($c->active_listings??0); ?></span>
                <button class="gs-cm-tree-del" onclick="gsCmDelete(<?php echo (int)$c->id; ?>,this,'<?php echo esc_js( $c->name ); ?>')" title="Delete">✕</button>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>

    <!-- Card: Quick Edit / Reorder -->
    <div class="gs-cm-card">
      <div class="gs-cm-card-head"><span class="head-icon">✏️</span> Quick Edit</div>
      <div class="gs-cm-body">
        <div style="color:#64748b;font-size:.82rem;margin-bottom:10px">Click any category name in the tree above to edit it inline, or use the form below to edit by ID.</div>
        <div id="gs-cm-quick-edit-form" style="display:none">
          <input type="hidden" id="gs-cm-qe-id">
          <div class="gs-cm-fg">
            <label class="gs-cm-lbl">Name *</label>
            <input type="text" id="gs-cm-qe-name" class="gs-cm-inp">
          </div>
          <div class="gs-cm-fg">
            <label class="gs-cm-lbl">Icon / Emoji</label>
            <input type="text" id="gs-cm-qe-icon" class="gs-cm-inp" maxlength="10">
          </div>
          <div class="gs-cm-fg">
            <label class="gs-cm-lbl">Photo URL <span style="font-weight:400;color:#94a3b8">(shown in the homepage category gallery, if set)</span></label>
            <input type="url" id="gs-cm-qe-image" class="gs-cm-inp" placeholder="https://…">
          </div>
          <div class="gs-cm-fg">
            <label class="gs-cm-lbl">Parent</label>
            <select id="gs-cm-qe-parent" class="gs-cm-sel">
              <option value="0">— Top Level —</option>
              <?php gs_cm_options( $all_tree ); ?>
            </select>
          </div>
          <div class="gs-cm-fg">
            <label class="gs-cm-lbl">Description</label>
            <textarea id="gs-cm-qe-desc" class="gs-cm-ta" rows="2"></textarea>
          </div>
          <div style="display:flex;gap:8px">
            <button onclick="gsCmSaveEdit()" class="gs-cm-btn-primary" style="flex:1;justify-content:center">💾 Save Changes</button>
            <button onclick="gsCmCancelEdit()" class="gs-cm-btn-secondary">Cancel</button>
          </div>
        </div>
        <div id="gs-cm-quick-edit-hint" style="background:#f8fafc;border-radius:8px;padding:20px;text-align:center;color:#94a3b8;font-size:.83rem">
          Click a category name in the tree to start editing
        </div>
      </div>
    </div>

    <!-- Card: Sort Order -->
    <div class="gs-cm-card">
      <div class="gs-cm-card-head"><span class="head-icon">⚙️</span> Settings</div>
      <div class="gs-cm-body">
        <label class="gs-cm-toggle-lbl">
          <input type="checkbox" class="gs-cm-toggle-inp" id="gs-cm-hide-empty" <?php echo get_option('gs_cm_hide_empty') ? 'checked' : ''; ?>>
          <span class="gs-cm-toggle-sw"></span>
          <span>Hide empty categories in directory</span>
        </label>
        <div style="margin-top:12px">
          <label class="gs-cm-toggle-lbl">
            <input type="checkbox" class="gs-cm-toggle-inp" id="gs-cm-show-count" <?php echo get_option('gs_cm_show_count','1') ? 'checked' : ''; ?>>
            <span class="gs-cm-toggle-sw"></span>
            <span>Show listing count badges on directory</span>
          </label>
        </div>
        <button onclick="gsCmSaveSettings()" class="gs-cm-btn-primary" style="margin-top:14px;width:100%;justify-content:center">💾 Save Settings</button>
      </div>
    </div>

  </div><!-- /.gs-cm-col -->
</div><!-- /.gs-cm-grid -->
</div><!-- /.gs-cm -->

<script>
(function(){
var AJX   = '<?php echo esc_js( admin_url("admin-ajax.php") ); ?>';
var NONCE = '<?php echo esc_js( $nonce ); ?>';
var editingId = 0;

function post(data, cb) {
    var fd = new FormData();
    fd.append('nonce', NONCE);
    Object.keys(data).forEach(function(k){ fd.append(k, data[k]); });
    fetch(AJX, {method:'POST',body:fd})
        .then(function(r){ return r.json(); })
        .then(cb)
        .catch(function(){ showMsg('Network error — please try again.', 'error'); });
}

function showMsg(msg, type) {
    var bar = document.getElementById('gs-cm-notice-bar');
    var cls = type === 'error' ? 'gs-cm-notice-error' : type === 'info' ? 'gs-cm-notice-info' : 'gs-cm-notice-success';
    bar.className = 'gs-cm-notice ' + cls;
    bar.innerHTML = msg;
    bar.scrollIntoView({behavior:'smooth', block:'nearest'});
    setTimeout(function(){ bar.innerHTML = ''; bar.className = ''; }, 6000);
}

/* ── Add single category ── */
window.gsCmAddSingle = function() {
    var name = document.getElementById('gs-cm-name').value.trim();
    if (!name) { showMsg('⚠️ Category name is required.', 'error'); return; }
    post({
        action: 'gs_admin_category_add',
        name:   name,
        slug:   document.getElementById('gs-cm-slug').value.trim(),
        icon:   document.getElementById('gs-cm-icon').value.trim(),
        parent: document.getElementById('gs-cm-parent').value,
        desc:   document.getElementById('gs-cm-desc').value.trim(),
    }, function(d) {
        if (d.success) {
            showMsg('✅ Category <strong>' + name + '</strong> created successfully.', 'success');
            document.getElementById('gs-cm-name').value = '';
            document.getElementById('gs-cm-slug').value = '';
            document.getElementById('gs-cm-icon').value = '';
            document.getElementById('gs-cm-desc').value = '';
            gsCmReloadTree();
        } else {
            showMsg('❌ ' + (d.data && d.data.message ? d.data.message : 'Failed to create category.'), 'error');
        }
    });
};

/* ── Bulk create ── */
window.gsCmBulkCreate = function() {
    var lines = document.getElementById('gs-cm-bulk').value.trim();
    if (!lines) { showMsg('⚠️ Enter at least one category name.', 'error'); return; }
    post({
        action: 'gs_admin_category_bulk',
        lines:  lines,
        parent: document.getElementById('gs-cm-bulk-parent').value,
    }, function(d) {
        if (d.success) {
            showMsg('✅ ' + (d.data.message || 'Bulk create complete.'), 'success');
            document.getElementById('gs-cm-bulk').value = '';
            gsCmReloadTree();
        } else {
            showMsg('❌ ' + (d.data && d.data.message ? d.data.message : 'Bulk create failed.'), 'error');
        }
    });
};

/* ── CSV import ── */
window.gsCmCsvImport = function() {
    var file = document.getElementById('gs-cm-csv').files[0];
    if (!file) { showMsg('⚠️ Please select a CSV file first.', 'error'); return; }
    var fd = new FormData();
    fd.append('nonce', NONCE);
    fd.append('action', 'gs_admin_category_csv');
    fd.append('csv_file', file);
    fetch(AJX, {method:'POST', body:fd})
        .then(function(r){ return r.json(); })
        .then(function(d) {
            if (d.success) {
                showMsg('✅ ' + (d.data.message || 'CSV import complete.'), 'success');
                document.getElementById('gs-cm-csv').value = '';
                document.getElementById('gs-cm-file-lbl-txt').textContent = 'Choose CSV file…';
                gsCmReloadTree();
            } else {
                showMsg('❌ ' + (d.data && d.data.message ? d.data.message : 'CSV import failed.'), 'error');
            }
        })
        // Real fix — silent failure: a network error left the "Import"
        // click with no feedback at all, unlike every other action on
        // this screen which shows a message either way.
        .catch(function(){
            showMsg('❌ Network error — the file could not be uploaded. Please try again.', 'error');
        });
};

/* ── Delete category ── */
window.gsCmDelete = function(id, btn, name) {
    // Real fix — confirmation now names the category being deleted,
    // matching the pattern used for vendor/plan/coupon deletes elsewhere
    // in this file, instead of the generic "this category" that gave no
    // way to double-check which row the ✕ button actually belonged to.
    if (!confirm('Delete category "' + (name || 'this category') + '"? Listings will be unassigned.')) return;
    post({ action: 'gs_admin_category_delete', id: id }, function(d) {
        if (d.success) {
            btn.closest('.gs-cm-tree-item').remove();
            var stat = document.getElementById('gs-cm-stat-cats');
            if (stat) stat.textContent = Math.max(0, parseInt(stat.textContent) - 1);
            showMsg('✅ Category deleted.', 'success');
        } else {
            showMsg('❌ Failed to delete.', 'error');
        }
    });
};

/* ── Inline edit (click name) ── */
window.gsCmEditInline = function(id, parentId, linkEl) {
    editingId = id;
    document.getElementById('gs-cm-qe-id').value    = id;
    document.getElementById('gs-cm-qe-parent').value = parentId;
    document.getElementById('gs-cm-quick-edit-form').style.display = 'block';
    document.getElementById('gs-cm-quick-edit-hint').style.display = 'none';
    // Real fix: load the actual category record instead of scraping the DOM
    // and hardcoding description to blank (which silently wiped every
    // category's real description on save, since nothing ever loaded it).
    post({ action: 'gs_admin_category_get', id: id }, function(d) {
        if (d.success && d.data && d.data.category) {
            var c = d.data.category;
            document.getElementById('gs-cm-qe-name').value  = c.name || '';
            document.getElementById('gs-cm-qe-icon').value  = c.icon_emoji || '';
            document.getElementById('gs-cm-qe-image').value = c.icon_url || '';
            document.getElementById('gs-cm-qe-desc').value  = c.description || '';
            document.getElementById('gs-cm-qe-name').focus();
        } else {
            showMsg('❌ Could not load category details.', 'error');
        }
    });
};

window.gsCmCancelEdit = function() {
    editingId = 0;
    document.getElementById('gs-cm-quick-edit-form').style.display = 'none';
    document.getElementById('gs-cm-quick-edit-hint').style.display = 'block';
};

window.gsCmSaveEdit = function() {
    var id = document.getElementById('gs-cm-qe-id').value;
    var name = document.getElementById('gs-cm-qe-name').value.trim();
    if (!name) { showMsg('⚠️ Name is required.', 'error'); return; }
    post({
        action: 'gs_admin_category_edit',
        id: id, name: name,
        icon:   document.getElementById('gs-cm-qe-icon').value.trim(),
        image:  document.getElementById('gs-cm-qe-image').value.trim(),
        parent: document.getElementById('gs-cm-qe-parent').value,
        desc:   document.getElementById('gs-cm-qe-desc').value.trim(),
    }, function(d) {
        if (d.success) {
            showMsg('✅ Category updated.', 'success');
            gsCmCancelEdit();
            gsCmReloadTree();
        } else {
            showMsg('❌ ' + (d.data && d.data.message ? d.data.message : 'Update failed.'), 'error');
        }
    });
};

/* ── Save settings ── */
window.gsCmSaveSettings = function() {
    post({
        action:      'gs_admin_save_settings',
        hide_empty:  document.getElementById('gs-cm-hide-empty').checked ? 1 : 0,
        show_count:  document.getElementById('gs-cm-show-count').checked ? 1 : 0,
    }, function(d) {
        showMsg(d.success ? '✅ Settings saved.' : '❌ Failed to save.', d.success ? 'success' : 'error');
    });
};

/* ── Reload tree ── */
window.gsCmReloadTree = function() {
    post({ action: 'gs_admin_category_tree_html' }, function(d) {
        if (d.success && d.data.html !== undefined) {
            var list = document.getElementById('gs-cm-tree-list');
            if (list) list.outerHTML = d.data.html;
            var cnt = document.getElementById('gs-cm-tree-count');
            if (cnt && d.data.count !== undefined) cnt.textContent = d.data.count;
            var stat = document.getElementById('gs-cm-stat-cats');
            if (stat && d.data.count !== undefined) stat.textContent = d.data.count;
        }
    });
};
})();
</script>
