<?php
/**
 * GoodService — Vendor Inquiry Manager
 * IndiaMART-style split-pane UI: left list panel + right detail panel.
 * Included from vendor-dashboard.php under case 'leads'.
 *
 * Available context variables from parent:
 *   $vid   int     Vendor profile ID
 *   $nonce string  WP nonce (gs_ajax)
 *   $vp    object  Vendor profile row
 *   $wpdb  wpdb
 *   $pfx   string  Table prefix e.g. "wp_gs_"
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// Fetch quick stats for badge counts (server-side on first render)
$inq_stats = [];
if ( $vid ) {
    $stat_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT status, COUNT(*) AS cnt FROM {$pfx}leads WHERE vendor_id = %d GROUP BY status", $vid
    ) ) ?: [];
    foreach ( $stat_rows as $sr ) { $inq_stats[ $sr->status ] = (int) $sr->cnt; }
    $inq_stats['total']   = array_sum( $inq_stats );
    $inq_stats['starred'] = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=%d AND is_starred=1", $vid
    ) );
}
$inq_new = $inq_stats['new'] ?? 0;
$inq_staff = $vid ? $wpdb->get_results($wpdb->prepare(
    "SELECT id, name FROM {$pfx}staff WHERE vendor_id=%d AND status='active' ORDER BY name ASC", $vid
)) ?? [] : [];
$inq_modules = [];
if ( $vid ) {
    $inq_modules = $wpdb->get_col( $wpdb->prepare(
        "SELECT DISTINCT inquiry_module FROM {$pfx}leads
         WHERE vendor_id = %d AND inquiry_module != '' ORDER BY inquiry_module ASC", $vid
    ) ) ?: [];
}
// Inbox listing filter — only relevant if the vendor has more than one
// listing (otherwise every inquiry is already for "the" listing and a
// filter dropdown with a single option adds nothing).
$inq_listings = [];
if ( $vid ) {
    $inq_listings = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, title FROM {$pfx}listings WHERE vendor_id = %d ORDER BY title ASC", $vid
    ) ) ?: [];
}
?>

<style>
/* ══ Inquiry Manager — Premium UI (complete rewrite, all layout rules preserved) ══ */

/* ── Outer wrap ──────────────────────────────────────────────────────────── */
.gsiq-wrap{display:flex;height:calc(100vh - 120px);min-height:560px;gap:0;overflow:hidden;
  border-radius:16px;border:none;
  box-shadow:0 8px 40px rgba(15,23,42,.14),0 2px 8px rgba(15,23,42,.06);
  background:#fff}

/* ══ LEFT PANEL — dark sidebar ════════════════════════════════════════════ */
.gsiq-left{width:35%;min-width:270px;max-width:390px;
  display:flex;flex-direction:column;flex-shrink:0;
  background:#0F172A;border-right:none}
.gsiq-left-hd{padding:14px 14px 0;flex-shrink:0}

/* Tabs */
.gsiq-tabs{display:flex;flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none;
  gap:2px;padding:10px 10px 0;
  border-bottom:1px solid rgba(255,255,255,.08);background:#0F172A}
.gsiq-tabs::-webkit-scrollbar{display:none}
.gsiq-tab{flex-shrink:0;cursor:pointer;white-space:nowrap;
  display:flex;align-items:center;gap:5px;
  padding:8px 11px;font-size:.72rem;font-weight:700;
  color:rgba(255,255,255,.4);
  border-bottom:2px solid transparent;
  transition:color .15s,background .15s}
.gsiq-tab:hover{color:rgba(255,255,255,.7);background:rgba(255,255,255,.05);border-radius:6px 6px 0 0}
.gsiq-tab.on{color:#60A5FA;border-bottom-color:#3B82F6;background:rgba(59,130,246,.08);border-radius:6px 6px 0 0}
.gsiq-tab-cnt{border-radius:20px;padding:1px 7px;font-size:.63rem;font-weight:800;
  background:rgba(255,255,255,.1);color:rgba(255,255,255,.45)}
.gsiq-tab.on .gsiq-tab-cnt{background:rgba(59,130,246,.25);color:#93C5FD}
.gsiq-tab-cnt.urgent{background:rgba(239,68,68,.25);color:#FCA5A5}

/* Search */
.gsiq-search{display:flex;align-items:center;gap:8px;flex-shrink:0;
  padding:11px 14px;border-bottom:1px solid rgba(255,255,255,.07);background:#0F172A}
.gsiq-search input{flex:1;font-family:inherit;outline:none;
  border:1.5px solid rgba(255,255,255,.1);border-radius:9px;
  padding:7px 11px;font-size:.82rem;
  background:rgba(255,255,255,.07);color:#F1F5F9}
.gsiq-search input::placeholder{color:rgba(255,255,255,.28)}
.gsiq-search input:focus{border-color:#3B82F6;background:rgba(255,255,255,.1);
  box-shadow:0 0 0 3px rgba(59,130,246,.2)}

/* Filter rows */
.gsiq-filter-row{display:flex;align-items:center;gap:6px;flex-shrink:0;
  padding:8px 14px;background:#0F172A;border-bottom:1px solid rgba(255,255,255,.05)}
.gsiq-filter-sel{flex:1;font-family:inherit;outline:none;
  border:1.5px solid rgba(255,255,255,.1);border-radius:8px;
  padding:5px 9px;font-size:.75rem;
  background:rgba(255,255,255,.07);color:rgba(255,255,255,.7)}
.gsiq-filter-sel:focus{border-color:#3B82F6;box-shadow:0 0 0 2px rgba(59,130,246,.2)}
.gsiq-filter-sel option{background:#1E293B;color:#F1F5F9}
.gsiq-starred-toggle{flex-shrink:0;cursor:pointer;font-family:inherit;
  padding:5px 9px;font-size:.75rem;
  border:1.5px solid rgba(255,255,255,.1);border-radius:8px;
  background:rgba(255,255,255,.07);color:rgba(255,255,255,.45);
  transition:all .15s}
.gsiq-starred-toggle:hover{background:rgba(245,158,11,.15);border-color:rgba(245,158,11,.4);color:#FCD34D}
.gsiq-starred-toggle.on{background:rgba(245,158,11,.15);border-color:#F59E0B;color:#FCD34D}

/* List */
.gsiq-list{flex:1;overflow-y:auto;padding:6px 8px;background:#0F172A;
  scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.1) transparent}

/* List items */
.gsiq-item{display:flex;align-items:flex-start;gap:9px;cursor:pointer;position:relative;
  padding:11px 12px;
  background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
  border-radius:10px;margin-bottom:5px;
  transition:background .12s,border-color .12s,transform .1s}
.gsiq-item:hover{background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.13);transform:translateX(2px)}
.gsiq-item.on{background:rgba(59,130,246,.18);border-color:rgba(59,130,246,.4);transform:translateX(2px)}
.gsiq-item-bar{width:3px;border-radius:2px;flex-shrink:0;margin-top:3px;height:40px}
.bar-new{background:linear-gradient(180deg,#3B82F6,#60A5FA)}
.bar-viewed{background:rgba(255,255,255,.2)}
.bar-replied{background:linear-gradient(180deg,#10B981,#34D399)}
.bar-converted{background:linear-gradient(180deg,#8B5CF6,#A78BFA)}
.bar-closed{background:rgba(255,255,255,.1)}
.bar-junk{background:#F87171}
.gsiq-item-star{cursor:pointer;flex-shrink:0;margin-top:1px;line-height:1;padding:2px;
  font-size:.9rem;color:rgba(255,255,255,.2);transition:color .15s,transform .15s}
.gsiq-item-star:hover{color:#FCD34D;transform:scale(1.2)}
.gsiq-item-star.starred{color:#F59E0B}
.gsiq-item-body{flex:1;min-width:0}
.gsiq-item-name{display:flex;align-items:center;gap:5px;flex-wrap:wrap;
  font-weight:700;font-size:.84rem;color:#F1F5F9}
.gsiq-item-co{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
  font-size:.72rem;color:rgba(255,255,255,.38);margin-top:2px}
.gsiq-item-prod{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
  font-size:.73rem;color:rgba(255,255,255,.5);margin-top:5px;
  background:rgba(255,255,255,.07);padding:2px 7px;border-radius:5px;
  display:inline-block;max-width:100%}
.gsiq-item-foot{display:flex;align-items:center;justify-content:space-between;margin-top:6px;flex-wrap:wrap;gap:3px}
.gsiq-item-time{font-size:.68rem;color:rgba(255,255,255,.28);font-weight:500}
.gsiq-prio-badge{text-transform:uppercase;letter-spacing:.04em;
  font-size:.61rem;font-weight:800;padding:2px 6px;border-radius:20px}
.prio-high{background:rgba(251,146,60,.2);color:#FDBA74;border:1px solid rgba(251,146,60,.3)}
.prio-urgent{background:rgba(239,68,68,.2);color:#FCA5A5;border:1px solid rgba(239,68,68,.3)}
.gsiq-unread-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0;margin-top:5px;
  background:#3B82F6;box-shadow:0 0 0 3px rgba(59,130,246,.25)}
.gsiq-list-footer{padding:10px 14px;text-align:center}
.gsiq-load-more{width:100%;cursor:pointer;font-family:inherit;
  padding:9px;font-size:.78rem;font-weight:700;
  border:1.5px solid rgba(255,255,255,.1);border-radius:8px;
  background:rgba(255,255,255,.05);color:#60A5FA;transition:.15s}
.gsiq-load-more:hover{background:rgba(59,130,246,.15);border-color:rgba(59,130,246,.4)}
.gsiq-list-empty{padding:44px 20px;text-align:center;color:rgba(255,255,255,.32)}
.gsiq-list-empty-icon{font-size:2.2rem;margin-bottom:10px;opacity:.5}
.gsiq-list-empty-title{font-weight:700;font-size:.9rem;margin-bottom:5px;color:rgba(255,255,255,.45)}

/* ══ RIGHT PANEL ══════════════════════════════════════════════════════════ */
.gsiq-right{flex:1;display:flex;flex-direction:column;overflow:hidden;min-width:0;
  background:#F0F4FA}
.gsiq-right-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;
  flex:1;text-align:center;padding:60px 24px;color:#94A3B8}
.gsiq-right-empty svg{opacity:.2;margin-bottom:18px}
.gsiq-detail{display:flex;flex-direction:column;flex:1;overflow:hidden}

/* Action bar */
.gsiq-action-bar{display:flex;align-items:center;gap:7px;flex-shrink:0;flex-wrap:wrap;
  padding:10px 14px;border-bottom:1px solid #E2EAF6;
  background:#fff;box-shadow:0 1px 6px rgba(15,23,42,.06)}
.gsiq-sel{font-family:inherit;outline:none;cursor:pointer;
  border:1.5px solid #E2E8F0;border-radius:9px;padding:7px 11px;
  font-size:.78rem;font-weight:600;background:#F4F7FD;color:#334155;
  transition:border-color .15s}
.gsiq-sel:focus{border-color:#3B82F6;box-shadow:0 0 0 3px rgba(59,130,246,.1)}
.gsiq-ico-btn{cursor:pointer;font-family:inherit;white-space:nowrap;
  padding:7px 12px;font-size:.79rem;font-weight:600;
  border:1.5px solid #E2E8F0;border-radius:9px;
  background:#F4F7FD;color:#475569;transition:all .15s}
.gsiq-ico-btn:hover{background:#EFF6FF;border-color:#93C5FD;color:#1D4ED8;
  box-shadow:0 2px 8px rgba(37,99,235,.1)}
.gsiq-ico-btn.starred{background:#FFFBEB;border-color:#FDE68A;color:#B45309}
.gsiq-ico-btn.danger{background:#FEF2F2;border-color:#FECACA;color:#DC2626}
.gsiq-ico-btn.danger:hover{background:#FEE2E2;border-color:#F87171;
  box-shadow:0 2px 8px rgba(220,38,38,.12)}
.gsiq-action-spacer{flex:1}

/* Scroll area */
.gsiq-scroll{flex:1;overflow-y:auto;padding:16px;
  scrollbar-width:thin;scrollbar-color:#CBD5E1 transparent}

/* Customer card — hero style */
.gsiq-cust-card{margin-bottom:16px;overflow:hidden;
  border:none;border-radius:16px;padding:0;background:#fff;
  box-shadow:0 4px 20px rgba(15,23,42,.08),0 1px 4px rgba(15,23,42,.05)}
.gsiq-cust-card-hd{display:flex;align-items:center;gap:14px;margin-bottom:0;
  padding:20px 20px 16px;
  background:linear-gradient(135deg,#1E3A5F 0%,#2563EB 60%,#3B82F6 100%)}
.gsiq-avatar{display:flex;align-items:center;justify-content:center;flex-shrink:0;
  width:52px;height:52px;font-size:1.2rem;font-weight:900;color:#fff;
  border-radius:14px;background:rgba(255,255,255,.2);
  border:2px solid rgba(255,255,255,.3);
  box-shadow:0 4px 16px rgba(0,0,0,.2)}
.gsiq-cust-name{font-weight:800;font-size:1.05rem;color:#fff;text-shadow:0 1px 3px rgba(0,0,0,.2)}
.gsiq-cust-co{font-size:.8rem;color:rgba(255,255,255,.7)}
.gsiq-cust-time{font-size:.72rem;color:rgba(255,255,255,.52);margin-top:3px;font-weight:500}
.gsiq-info-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:14px 16px}
.gsiq-info-cell{background:#F8FAFD;border-radius:10px;padding:10px 13px;
  border:1.5px solid #EEF2FB;transition:background .15s,border-color .15s}
.gsiq-info-cell:hover{background:#EEF6FF;border-color:#BFDBFE}
.gsiq-info-lbl{font-size:.62rem;font-weight:800;color:#94A3B8;
  letter-spacing:.07em;text-transform:uppercase;margin-bottom:4px}
.gsiq-info-val{font-size:.83rem;color:#0F172A;font-weight:700;word-break:break-word;line-height:1.4}
.gsiq-info-val a{color:#2563EB;text-decoration:none;font-weight:700}
.gsiq-info-val a:hover{text-decoration:underline}
.gsiq-msg-block{margin-top:0;margin-left:16px;margin-right:16px;margin-bottom:14px;
  background:linear-gradient(135deg,#EFF6FF,#F0F9FF);
  border-left:4px solid #3B82F6;padding:13px 16px;
  border-radius:0 12px 12px 0;font-size:.85rem;color:#1E293B;line-height:1.75}
.gsiq-msg-lbl{font-size:.65rem;font-weight:800;color:#2563EB;
  text-transform:uppercase;letter-spacing:.08em;margin-bottom:6px}
.gsiq-extra-fields{margin-top:0;margin-left:16px;margin-right:16px;margin-bottom:14px;
  background:linear-gradient(135deg,#FFFBEB,#FEF3C7);
  border:1.5px solid #FDE68A;border-radius:12px;padding:13px 16px;font-size:.82rem}
.gsiq-extra-title{font-size:.65rem;font-weight:800;color:#92400E;
  text-transform:uppercase;letter-spacing:.07em;margin-bottom:9px}

/* Reply box */
.gsiq-reply-box{background:#fff;border:none;border-radius:16px;padding:18px;margin-bottom:16px;
  box-shadow:0 4px 20px rgba(15,23,42,.07),0 1px 4px rgba(15,23,42,.04)}
.gsiq-reply-box-hd{font-weight:800;font-size:.84rem;color:#0F172A;margin-bottom:9px}
.gsiq-reply-ta{width:100%;font-family:inherit;resize:vertical;outline:none;
  min-height:96px;border:1.5px solid #E2EAF6;border-radius:10px;
  padding:12px 14px;font-size:.87rem;color:#0F172A;background:#F8FAFD;line-height:1.65;
  transition:border-color .15s,background .15s,box-shadow .15s}
.gsiq-reply-ta:focus{border-color:#3B82F6;background:#fff;box-shadow:0 0 0 3px rgba(59,130,246,.1)}
.gsiq-reply-ta::placeholder{color:#B0BBCF}
.gsiq-reply-actions{display:flex;align-items:center;gap:8px;margin-top:10px;flex-wrap:wrap}
.gsiq-reply-char{margin-left:auto;font-size:.7rem;color:#94A3B8;font-weight:500}

/* Timeline */
.gsiq-timeline{background:#fff;border:none;border-radius:16px;padding:18px;
  box-shadow:0 4px 20px rgba(15,23,42,.07),0 1px 4px rgba(15,23,42,.04)}
.gsiq-timeline-hd{font-weight:800;font-size:.84rem;color:#0F172A;
  display:flex;align-items:center;gap:7px;
  margin-bottom:15px;padding-bottom:12px;border-bottom:1.5px solid #F1F5F9}
.gsiq-bubble-wrap{margin-bottom:14px;display:flex;flex-direction:column}
.gsiq-bubble-wrap.vendor{align-items:flex-end}
.gsiq-bubble-wrap.customer{align-items:flex-start}
.gsiq-bubble-wrap.internal{align-items:center}
.gsiq-bubble{word-break:break-word;max-width:82%;padding:11px 14px;
  font-size:.85rem;line-height:1.7}
.gsiq-bubble.vendor{background:linear-gradient(135deg,#2563EB,#1D4ED8);color:#fff;
  border-radius:16px 16px 4px 16px;box-shadow:0 4px 14px rgba(37,99,235,.3)}
.gsiq-bubble.customer{background:#F4F7FD;color:#1E293B;
  border:1.5px solid #E8EEF8;border-radius:16px 16px 16px 4px;
  box-shadow:0 2px 8px rgba(15,23,42,.05)}
.gsiq-bubble.internal{background:linear-gradient(135deg,#FFFBEB,#FEF3C7);color:#78350F;
  border:1.5px dashed #FCD34D;font-size:.8rem;text-align:center;
  border-radius:10px;padding:9px 13px}
.gsiq-bubble-meta{font-size:.67rem;margin-top:4px;opacity:.6;
  display:flex;align-items:center;gap:5px;font-weight:500}
.gsiq-bubble-wrap.vendor .gsiq-bubble-meta{justify-content:flex-end;color:#475569}
.gsiq-bubble-wrap.customer .gsiq-bubble-meta{color:#94A3B8}
.gsiq-bubble-wrap.internal .gsiq-bubble-meta{justify-content:center;color:#92400E;opacity:.55}
.gsiq-lock-icon{font-size:.7rem}

/* Bulk bar */
.gsiq-bulk-bar{display:none;position:sticky;top:0;z-index:10;
  align-items:center;gap:10px;flex-wrap:wrap;
  padding:10px 16px;font-size:.8rem;font-weight:700;
  background:linear-gradient(135deg,#0F172A,#1E293B);color:#fff;
  box-shadow:0 4px 20px rgba(15,23,42,.25)}
.gsiq-bulk-bar.show{display:flex}

/* Responsive */
@media(max-width:768px){
  .gsiq-wrap{flex-direction:column;height:auto;min-height:unset;border-radius:12px}
  .gsiq-left{width:100%;max-width:100%;border-right:none;border-bottom:1px solid rgba(255,255,255,.08)}
  .gsiq-right{display:none}
  .gsiq-right.show{display:flex}
  .gsiq-left.hide{display:none}
  .gsiq-info-grid{grid-template-columns:1fr}
  .gsiq-bubble{max-width:88%}
  /* Hide back button from action bar on mobile — it lives in the dedicated back bar instead */
  #gsiq-back-btn{display:none !important}
  /* Inquiry field-details table: on mobile, stack label above value instead
     of a cramped two-column layout. table-layout:fixed above prevents the
     character-per-line wrap bug; this goes further so values like dates or
     multi-word descriptions get the full row width to read comfortably. */
  .gsiq-inq-fields, .gsiq-inq-fields tbody, .gsiq-inq-fields tr, .gsiq-inq-fields td{display:block;width:100% !important}
  .gsiq-inq-fields tr{padding:6px 0;border-bottom:1px solid #EFF6FF}
  .gsiq-inq-fields td{padding:2px 0 !important;border-bottom:none !important}
  .gsiq-inq-fields td:first-child{color:#94A3B8;font-size:.72rem;text-transform:uppercase;letter-spacing:.03em;font-weight:700}
}

/* ── Mobile-only sticky back bar ─────────────────────────────────
   Appears at the top of the detail view on mobile when an inquiry
   is opened. Gives the vendor a clear, always-visible way to
   return to the list. Hidden on desktop (>768px).
──────────────────────────────────────────────────────────────────*/
#gsiq-mob-back-bar{
  display:none; /* shown by JS only on mobile */
  align-items:center;gap:10px;
  padding:10px 14px;
  background:#0F172A;
  border-bottom:1px solid rgba(255,255,255,.08);
  flex-shrink:0;
  position:sticky;top:0;z-index:20;
}
#gsiq-mob-back-bar button{
  display:flex;align-items:center;gap:7px;
  background:rgba(255,255,255,.1);
  border:1px solid rgba(255,255,255,.15);
  border-radius:8px;
  padding:7px 13px;
  color:#fff;font-size:.82rem;font-weight:700;
  cursor:pointer;font-family:inherit;
  transition:background .15s;
  flex-shrink:0;
}
#gsiq-mob-back-bar button:hover{background:rgba(255,255,255,.18)}
#gsiq-mob-back-bar button:active{background:rgba(255,255,255,.25)}
#gsiq-mob-back-bar-title{
  flex:1;font-size:.82rem;font-weight:700;
  color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;
}
#gsiq-mob-back-bar-sub{
  font-size:.68rem;color:rgba(255,255,255,.45);
  margin-top:1px;font-weight:400;
}

/* Spinner */
.gsiq-spinner{display:inline-block;width:16px;height:16px;
  border:2px solid rgba(255,255,255,.15);border-top-color:#3B82F6;
  border-radius:50%;animation:gsiq-spin .7s linear infinite;vertical-align:middle}
@keyframes gsiq-spin{to{transform:rotate(360deg)}}

/* Badges */
.gsiq-badge-overdue{font-size:.6rem;font-weight:800;padding:2px 6px;border-radius:20px;
  background:rgba(251,146,60,.2);color:#FDBA74;border:1px solid rgba(251,146,60,.3)}
.gsiq-badge-hot{font-size:.6rem;font-weight:800;padding:2px 6px;border-radius:20px;
  background:rgba(239,68,68,.2);color:#FCA5A5;border:1px solid rgba(239,68,68,.3)}
.gsiq-quality-badge{font-size:.6rem;font-weight:800;padding:2px 6px;border-radius:20px}
.gsiq-q-high{background:rgba(16,185,129,.2);color:#6EE7B7;border:1px solid rgba(16,185,129,.3)}
.gsiq-q-med{background:rgba(245,158,11,.2);color:#FDE68A;border:1px solid rgba(245,158,11,.3)}
.gsiq-q-low{background:rgba(255,255,255,.08);color:rgba(255,255,255,.4);border:1px solid rgba(255,255,255,.1)}

/* Quote builder overlay */
.gsiq-qb-overlay{display:none;position:fixed;inset:0;z-index:9990;
  align-items:flex-end;justify-content:center;
  background:rgba(15,23,42,.7);backdrop-filter:blur(4px)}
.gsiq-qb-overlay.open{display:flex}
.gsiq-qb-panel{display:flex;flex-direction:column;overflow:hidden;
  background:#fff;width:100%;max-width:700px;max-height:90vh;
  border-radius:22px 22px 0 0;box-shadow:0 -12px 48px rgba(15,23,42,.22)}
.gsiq-qb-hd{display:flex;align-items:center;gap:10px;flex-shrink:0;
  padding:20px 24px;border-bottom:1.5px solid #F0F4FA;
  background:linear-gradient(135deg,#F8FAFF,#fff)}
.gsiq-qb-hd h3{margin:0;flex:1;font-size:15px;font-weight:800;color:#0F172A}
.gsiq-qb-body{flex:1;overflow-y:auto;padding:20px 24px}
.gsiq-qb-foot{display:flex;gap:9px;justify-content:flex-end;flex-shrink:0;
  padding:14px 24px;border-top:1.5px solid #F0F4FA;background:#F8FAFD}
.qb-row{display:grid;grid-template-columns:1fr 60px 90px 28px;gap:7px;align-items:center;margin-bottom:7px}
.gsiq-inp{font-family:inherit;outline:none;width:100%;
  border:1.5px solid #E2EAF6;border-radius:9px;padding:8px 12px;
  font-size:.83rem;background:#F8FAFD;color:#0F172A;
  transition:border-color .15s,box-shadow .15s}
.gsiq-inp:focus{border-color:#3B82F6;background:#fff;box-shadow:0 0 0 3px rgba(59,130,246,.1)}

/* Template picker */
.gsiq-tpl-overlay{display:none;position:fixed;inset:0;z-index:9991;
  align-items:center;justify-content:center;
  background:rgba(15,23,42,.7);backdrop-filter:blur(4px)}
.gsiq-tpl-overlay.open{display:flex}
.gsiq-tpl-panel{display:flex;flex-direction:column;overflow:hidden;
  background:#fff;width:90%;max-width:560px;max-height:80vh;
  border-radius:18px;box-shadow:0 28px 72px rgba(15,23,42,.24)}
.gsiq-tpl-hd{display:flex;align-items:center;gap:10px;flex-shrink:0;
  padding:18px 22px;border-bottom:1.5px solid #F0F4FA;
  background:linear-gradient(135deg,#F8FAFF,#fff)}
.gsiq-tpl-hd h3{margin:0;flex:1;font-size:14px;font-weight:800;color:#0F172A}
.gsiq-tpl-list{flex:1;overflow-y:auto}
.gsiq-tpl-item{padding:13px 22px;border-bottom:1px solid #F8FAFC;cursor:pointer;transition:.12s}
.gsiq-tpl-item:hover{background:#EFF6FF}
.gsiq-tpl-name{font-weight:700;font-size:.84rem;color:#0F172A}
.gsiq-tpl-body{font-size:.77rem;color:#64748B;margin-top:3px;overflow:hidden;
  text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.gsiq-tpl-empty{padding:32px;text-align:center;color:#CBD5E1;font-size:.83rem}

/* AI row */
.gsiq-ai-row{display:flex;gap:6px;align-items:center;margin-top:6px;flex-wrap:wrap}
.gsiq-tone-sel{font-family:inherit;outline:none;
  border:1.5px solid #E2E8F0;border-radius:8px;padding:5px 10px;
  font-size:.74rem;font-weight:600;background:#F4F7FD;color:#475569}
</style>

<div class="gs-ph" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
  <div>
    <div class="gs-ph-title">📬 Inquiries</div>
    <div class="gs-ph-sub"><?php echo number_format( $inq_stats['total'] ?? 0 ); ?> total
      <?php if ( $inq_new ): ?> · <strong style="color:#2563EB"><?php echo $inq_new; ?> new</strong><?php endif; ?></div>
  </div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <button onclick="gsiqExportCsv()" class="gs-btn gs-btn-ghost gs-btn-sm">⬇ Export CSV</button>
  </div>
</div>

<!-- Bulk action bar (appears when items are selected) -->
<div class="gsiq-bulk-bar" id="gsiq-bulk-bar">
  <span id="gsiq-bulk-count">0 selected</span>
  <select class="gsiq-filter-sel" id="gsiq-bulk-sel" style="background:#334155;color:#fff;border-color:#475569">
    <option value="">— Bulk Action —</option>
    <option value="status_viewed">Mark as Viewed</option>
    <option value="status_replied">Mark as Replied</option>
    <option value="status_closed">Mark as Closed</option>
    <option value="status_junk">Mark as Junk</option>
    <option value="delete">Delete</option>
    <option value="send_template">📝 Send Template to Selected</option>
    <option value="assign_staff">👤 Assign to Staff</option>
  </select>
  <button onclick="gsiqBulkApply()" class="gs-btn gs-btn-primary gs-btn-sm">Apply</button>
  <button onclick="gsiqClearSelection()" class="gs-btn gs-btn-ghost gs-btn-sm" style="color:#fff;border-color:#475569">Clear</button>
</div>

<div class="gsiq-wrap" id="gsiq-wrap">

  <!-- ── LEFT PANEL — inquiry list ─────────────────────────── -->
  <div class="gsiq-left" id="gsiq-left">

    <!-- Status tabs -->
    <div class="gsiq-tabs" id="gsiq-tabs">
      <div class="gsiq-tab on" data-status="" onclick="gsiqSetTab(this,'')">
        All <span class="gsiq-tab-cnt" id="cnt-all"><?php echo $inq_stats['total'] ?? 0; ?></span>
      </div>
      <div class="gsiq-tab" data-status="new" onclick="gsiqSetTab(this,'new')">
        New <span class="gsiq-tab-cnt<?php echo $inq_new ? ' urgent' : ''; ?>" id="cnt-new"><?php echo $inq_new; ?></span>
      </div>
      <div class="gsiq-tab" data-status="viewed" onclick="gsiqSetTab(this,'viewed')">
        Viewed <span class="gsiq-tab-cnt" id="cnt-viewed"><?php echo $inq_stats['viewed'] ?? 0; ?></span>
      </div>
      <div class="gsiq-tab" data-status="replied" onclick="gsiqSetTab(this,'replied')">
        Replied <span class="gsiq-tab-cnt" id="cnt-replied"><?php echo $inq_stats['replied'] ?? 0; ?></span>
      </div>
      <div class="gsiq-tab" data-status="converted" onclick="gsiqSetTab(this,'converted')">
        Won <span class="gsiq-tab-cnt" id="cnt-converted"><?php echo $inq_stats['converted'] ?? 0; ?></span>
      </div>
      <div class="gsiq-tab" data-status="closed" onclick="gsiqSetTab(this,'closed')">
        Closed <span class="gsiq-tab-cnt" id="cnt-closed"><?php echo $inq_stats['closed'] ?? 0; ?></span>
      </div>
      <div class="gsiq-tab" data-status="junk" onclick="gsiqSetTab(this,'junk')">
        Junk <span class="gsiq-tab-cnt" id="cnt-junk"><?php echo $inq_stats['junk'] ?? 0; ?></span>
      </div>
    </div>

    <?php
    // Real fix — closes a documented known limitation ("the auto-generated
    // inquiries count on Service Plans links to Leads generally, not
    // pre-filtered to that plan"). A real server-side service_plan_id
    // filter (see getInquiries() in AjaxController.php) is now wired from
    // this ?service_plan_id= URL param straight into the initial load.
    $_gsiq_plan_id = (int) ( $_GET['service_plan_id'] ?? 0 );
    if ( $_gsiq_plan_id > 0 ):
    ?>
    <div id="gsiq-plan-filter-banner" style="display:flex;align-items:center;justify-content:space-between;gap:8px;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;padding:6px 10px;margin-bottom:8px;font-size:.78rem;color:#1D4ED8">
      <span>📅 Showing inquiries auto-generated by this service plan only</span>
      <a href="?section=leads" style="color:#1D4ED8;font-weight:700;text-decoration:none">✕ Clear</a>
    </div>
    <?php endif; ?>
    <!-- Search -->
    <div class="gsiq-search">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
      <input type="text" id="gsiq-search" placeholder="Search by name, phone, product…" oninput="gsiqDebounceSearch()" autocomplete="off">
    </div>

    <!-- Filters row -->
    <div class="gsiq-filter-row">
      <?php if ( count( $inq_listings ) > 1 ): ?>
      <select class="gsiq-filter-sel" id="gsiq-listing-filter" onchange="gsiqLoadList(1)" title="Filter by listing">
        <option value="">All listings</option>
        <?php foreach ( $inq_listings as $il ): ?>
        <option value="<?php echo (int)$il->id; ?>"><?php echo esc_html($il->title); ?></option>
        <?php endforeach; ?>
      </select>
      <?php endif; ?>
      <select class="gsiq-filter-sel" id="gsiq-prio-filter" onchange="gsiqLoadList(1)">
        <option value="">All priorities</option>
        <option value="urgent">🔴 Urgent</option>
        <option value="high">🟠 High</option>
        <option value="normal">⚪ Normal</option>
      </select>
      <?php if ( ! empty( $inq_modules ) ): ?>
      <select class="gsiq-filter-sel" id="gsiq-module-filter" onchange="gsiqLoadList(1)" title="Filter by service category">
        <option value="">All categories</option>
        <?php foreach ( $inq_modules as $m ):
            $label = ucwords( str_replace( ['-','_'], ' ', $m ) ); ?>
        <option value="<?php echo esc_attr($m); ?>"><?php echo esc_html($label); ?></option>
        <?php endforeach; ?>
      </select>
      <?php endif; ?>
      <button class="gsiq-starred-toggle" id="gsiq-starred-toggle" onclick="gsiqToggleStarred()" title="Show starred only">⭐</button>
    </div>
    <!-- Date range + sort row (Part 4.2) -->
    <div class="gsiq-filter-row" style="gap:4px">
      <!-- Smart date presets -->
      <button onclick="(function(){var t=new Date(),d=t.toISOString().slice(0,10);document.getElementById('gsiq-date-from').value=d;document.getElementById('gsiq-date-to').value=d;gsiqLoadList(1);})()" style="background:none;border:1px solid #475569;border-radius:6px;cursor:pointer;font-size:.68rem;color:#94A3B8;padding:2px 6px;flex-shrink:0" title="Today">Today</button>
      <button onclick="(function(){var t=new Date(),day=t.getDay(),mon=new Date(t);mon.setDate(t.getDate()-day);var sun=new Date(mon);sun.setDate(mon.getDate()+6);document.getElementById('gsiq-date-from').value=mon.toISOString().slice(0,10);document.getElementById('gsiq-date-to').value=sun.toISOString().slice(0,10);gsiqLoadList(1);})()" style="background:none;border:1px solid #475569;border-radius:6px;cursor:pointer;font-size:.68rem;color:#94A3B8;padding:2px 6px;flex-shrink:0" title="This week">Week</button>
      <button onclick="(function(){var t=new Date(),f=new Date(t);f.setDate(t.getDate()-30);document.getElementById('gsiq-date-from').value=f.toISOString().slice(0,10);document.getElementById('gsiq-date-to').value=t.toISOString().slice(0,10);gsiqLoadList(1);})()" style="background:none;border:1px solid #475569;border-radius:6px;cursor:pointer;font-size:.68rem;color:#94A3B8;padding:2px 6px;flex-shrink:0" title="Last 30 days">30d</button>
      <input type="date" id="gsiq-date-from" class="gsiq-filter-sel" style="flex:none;width:108px;font-size:.72rem"
             title="From date" onchange="gsiqLoadList(1)">
      <span style="font-size:.7rem;color:#94A3B8;flex-shrink:0">–</span>
      <input type="date" id="gsiq-date-to" class="gsiq-filter-sel" style="flex:none;width:108px;font-size:.72rem"
             title="To date" onchange="gsiqLoadList(1)">
      <button onclick="document.getElementById('gsiq-date-from').value='';document.getElementById('gsiq-date-to').value='';gsiqLoadList(1);"
              style="background:none;border:none;cursor:pointer;font-size:.75rem;color:#94A3B8;padding:0 2px;flex-shrink:0" title="Clear date filter">✕</button>
      <select class="gsiq-filter-sel" id="gsiq-sort-sel" onchange="gsiqLoadList(1)" title="Sort inquiries" style="flex:1">
        <option value="newest">Newest first</option>
        <option value="oldest">Oldest first</option>
        <option value="urgency">By urgency</option>
        <option value="unanswered">Unanswered first</option>
      </select>
    </div>

    <!-- List container -->
    <div class="gsiq-list" id="gsiq-list">
      <div class="gsiq-list-empty"><div class="gsiq-spinner"></div></div>
    </div>
  </div>

  <!-- ── RIGHT PANEL — detail view ─────────────────────────── -->
  <div class="gsiq-right" id="gsiq-right">
    <div class="gsiq-right-empty" id="gsiq-right-empty">
      <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="#CBD5E1" stroke-width="1.5"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
      <div style="font-weight:600;font-size:.9rem;color:#64748B;margin-bottom:5px">Select an inquiry to view details</div>
      <div style="font-size:.78rem">Click any inquiry on the left to open it here</div>
    </div>

    <!-- Detail pane (hidden until an inquiry is selected) -->
    <div class="gsiq-detail" id="gsiq-detail" style="display:none">

      <!-- Mobile-only sticky back bar — shown by JS when a lead is opened on narrow screens -->
      <div id="gsiq-mob-back-bar" role="navigation" aria-label="Back to inquiry list">
        <button onclick="gsiqMobileBack()" aria-label="Back to all inquiries">
          ← Back
        </button>
        <div>
          <div id="gsiq-mob-back-bar-title">Inquiry Details</div>
          <div id="gsiq-mob-back-bar-sub">Tap ← to return to list</div>
        </div>
      </div>

      <!-- Action bar -->
      <div class="gsiq-action-bar" id="gsiq-action-bar">
        <!-- Back button (mobile) -->
        <button class="gsiq-ico-btn" id="gsiq-back-btn" onclick="gsiqMobileBack()" style="display:none">← Back</button>
        <select class="gsiq-sel" id="gsiq-status-sel" onchange="gsiqUpdateStatus()">
          <option value="new">⚪ New</option>
          <option value="viewed">👁 Viewed</option>
          <option value="replied">✅ Replied</option>
          <option value="converted">🏆 Converted</option>
          <option value="closed">🔒 Closed</option>
          <option value="junk">🗑 Junk</option>
        </select>
        <select class="gsiq-sel" id="gsiq-prio-sel" onchange="gsiqUpdatePriority()">
          <option value="normal">⚪ Normal</option>
          <option value="high">🟠 High</option>
          <option value="urgent">🔴 Urgent</option>
        </select>
        <button class="gsiq-ico-btn" id="gsiq-star-btn" onclick="gsiqToggleStar()" title="Star this inquiry">☆ Star</button>
        <button class="gsiq-ico-btn" onclick="gsiqOpenQuoteBuilder()" title="Build and send a quotation">📄 Quote</button>
        <div class="gsiq-action-spacer"></div>
        <button class="gsiq-ico-btn" onclick="gsiqArchiveInquiry()" title="Archive this inquiry">📦</button>
        <button class="gsiq-ico-btn danger" onclick="gsiqDeleteInquiry()" title="Delete inquiry">🗑</button>
      </div>

      <div class="gsiq-scroll" id="gsiq-scroll">

        <!-- Customer info card -->
        <div class="gsiq-cust-card" id="gsiq-cust-card">
          <!-- Populated by JS -->
        </div>

        <!-- Reply box -->
        <div class="gsiq-reply-box">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:9px;flex-wrap:wrap">
            <div class="gsiq-reply-box-hd" style="margin:0;flex:1">Reply to Customer</div>
            <button class="gsiq-ico-btn" onclick="gsiqOpenTemplatePicker()" title="Insert a saved response template">📋 Template</button>
            <div class="gsiq-ai-row" style="margin:0">
              <button class="gsiq-ico-btn" onclick="gsiqAiDraft()" title="Generate an AI reply draft">✨ AI Draft</button>
              <select class="gsiq-tone-sel" id="gsiq-ai-tone" title="Reply tone">
                <option value="professional">Professional</option>
                <option value="friendly">Friendly</option>
                <option value="formal">Formal</option>
              </select>
            </div>
          </div>
          <div id="gsiq-ai-loading" style="display:none;text-align:center;padding:10px;color:#2563EB;font-size:.82rem"><span class="gsiq-spinner"></span> Generating draft…</div>
          <textarea class="gsiq-reply-ta" id="gsiq-reply-ta" placeholder="Type your reply, or use AI Draft / Template…" oninput="gsiqUpdateCharCount()"></textarea>
          <div class="gsiq-reply-actions">
            <button class="gs-btn gs-btn-primary gs-btn-sm" onclick="gsiqSendReply(false)">✉ Send Reply</button>
            <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsiqSendReply(true)" title="Saves the note for your reference only — not sent to the customer">🔒 Add Internal Note</button>
            <span class="gsiq-reply-char" id="gsiq-char-count">0 chars</span>
          </div>
        </div>

        <!-- Conversation timeline -->
        <div class="gsiq-timeline">
          <div class="gsiq-timeline-hd">
            💬 Conversation History
            <span style="font-size:.7rem;color:#94A3B8;font-weight:400" id="gsiq-reply-count"></span>
          </div>
          <div id="gsiq-timeline-body">
            <!-- Populated by JS -->
          </div>
        </div>

      </div>
    </div><!-- /gsiq-detail -->
  </div><!-- /gsiq-right -->

</div><!-- /gsiq-wrap -->

<!-- ── Quotation Builder Overlay (Part 6.2) ──────────────────────────────── -->
<div class="gsiq-qb-overlay" id="gsiq-qb-overlay">
  <div class="gsiq-qb-panel">
    <div class="gsiq-qb-hd">
      <h3>📄 Build a Quotation</h3>
      <small id="gsiq-qb-inq-ref" style="color:#94A3B8;font-size:.75rem"></small>
      <button class="gsiq-ico-btn" onclick="gsiqCloseQuoteBuilder()" style="margin-left:auto">✕ Close</button>
    </div>
    <div class="gsiq-qb-body">
      <div style="margin-bottom:12px">
        <label style="font-size:.75rem;font-weight:600;color:#64748B;display:block;margin-bottom:4px">Cover note to client (optional)</label>
        <textarea class="gsiq-inp" id="gsiq-qb-cover" rows="2" placeholder="e.g. Thank you for reaching out. Please find our quotation below…" style="resize:vertical"></textarea>
      </div>
      <!-- Line items -->
      <div style="font-size:.75rem;font-weight:700;color:#64748B;display:grid;grid-template-columns:1fr 60px 90px 28px;gap:6px;margin-bottom:6px;padding:0 2px">
        <span>Description</span><span style="text-align:center">Qty</span><span style="text-align:right">Unit Price (₹)</span><span></span>
      </div>
      <div id="gsiq-qb-items"></div>
      <button onclick="gsiqQbAddRow()" class="gs-btn gs-btn-ghost gs-btn-sm" style="margin-top:6px;width:100%">+ Add line item</button>
      <!-- Totals -->
      <div style="margin-top:14px;background:#F8FAFC;border-radius:8px;padding:12px 14px">
        <div style="display:flex;justify-content:space-between;font-size:.82rem;margin-bottom:6px">
          <span style="color:#64748B">Subtotal</span>
          <strong id="gsiq-qb-subtotal">₹0</strong>
        </div>
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
          <label style="font-size:.8rem;color:#64748B;display:flex;align-items:center;gap:5px">
            <input type="checkbox" id="gsiq-qb-gst" onchange="gsiqQbRecalc()"> Include 18% GST
          </label>
        </div>
        <div id="gsiq-qb-gst-row" style="display:none;justify-content:space-between;font-size:.82rem;margin-bottom:6px">
          <span style="color:#64748B">GST (18%)</span>
          <strong id="gsiq-qb-gst-amt">₹0</strong>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:1rem;border-top:1px solid #E2E8F0;padding-top:8px;margin-top:4px">
          <span style="font-weight:700">Total</span>
          <strong style="color:#2563EB;font-size:1.05rem" id="gsiq-qb-total">₹0</strong>
        </div>
      </div>
      <!-- Settings -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px">
        <div>
          <label style="font-size:.75rem;font-weight:600;color:#64748B;display:block;margin-bottom:4px">Valid for (days)</label>
          <input type="number" class="gsiq-inp" id="gsiq-qb-validity" value="7" min="1" max="90">
        </div>
        <div>
          <label style="font-size:.75rem;font-weight:600;color:#64748B;display:block;margin-bottom:4px">Payment terms</label>
          <select class="gsiq-inp" id="gsiq-qb-terms">
            <option value="">Select…</option>
            <option value="50% advance, 50% on completion">50% advance, 50% on completion</option>
            <option value="100% advance">100% advance</option>
            <option value="Full payment on completion">Full payment on completion</option>
            <option value="Net 7 days">Net 7 days</option>
            <option value="Net 15 days">Net 15 days</option>
          </select>
        </div>
      </div>
      <div style="margin-top:10px">
        <label style="font-size:.75rem;font-weight:600;color:#64748B;display:block;margin-bottom:4px">Internal notes (not shown to client)</label>
        <input type="text" class="gsiq-inp" id="gsiq-qb-notes" placeholder="e.g. Includes travel charges">
      </div>
    </div>
    <div class="gsiq-qb-foot">
      <button class="gs-btn gs-btn-ghost gs-btn-sm" onclick="gsiqQbSaveDraft()">💾 Save Draft</button>
      <button class="gs-btn gs-btn-primary" id="gsiq-qb-send-btn" onclick="gsiqQbSend()">📤 Send Quote to Client</button>
    </div>
  </div>
</div>

<!-- ── Template Picker Modal (Part 7.2) ──────────────────────────────────── -->
<div class="gsiq-tpl-overlay" id="gsiq-tpl-overlay">
  <div class="gsiq-tpl-panel">
    <div class="gsiq-tpl-hd">
      <h3>📋 Choose a Template</h3>
      <button class="gsiq-ico-btn" onclick="gsiqCloseTplPicker()" title="Close">✕</button>
    </div>
    <div style="padding:8px 14px;border-bottom:1px solid #F1F5F9">
      <input type="text" class="gsiq-inp" id="gsiq-tpl-search" placeholder="Search templates…" oninput="gsiqFilterTemplates(this.value)">
    </div>
    <div class="gsiq-tpl-list" id="gsiq-tpl-list">
      <div class="gsiq-tpl-empty">Loading templates…</div>
    </div>
    <div style="padding:10px 18px;border-top:1px solid #F1F5F9;display:flex;justify-content:space-between;align-items:center">
      <a href="?section=leads&manage_templates=1" style="font-size:.78rem;color:#2563EB;text-decoration:none">+ Manage my templates</a>
      <button class="gsiq-ico-btn gs-btn-ghost gs-btn-sm" onclick="gsiqCloseTplPicker()">Cancel</button>
    </div>
  </div>
</div>

<script>
(function(){
'use strict';

/* ── State ─────────────────────────────────────────────────── */
var _nonce    = <?php echo wp_json_encode( $nonce ); ?>;
var _ajaxUrl  = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
var _status   = '';          // current tab filter
var _priority = '';          // priority filter
var _module   = '';          // category/module filter
var _starred  = 0;           // starred-only filter
var _search   = '';          // search string
var _page     = 1;
var _hasMore  = false;
var _loading  = false;
var _curLead  = null;        // currently open lead object
var _selected = {};          // bulk selection: {lead_id: true}
var _debounce = null;
var _servicePlanId = <?php echo (int) ( $_GET['service_plan_id'] ?? 0 ); ?>; // real fix: wired from Service Plans screen's link

/* ── AJAX helper ─────────────────────────────────────────────── */
function gsiqPost(action, data, cb, errCb) {
  data.action = action;
  data.nonce  = _nonce;
  jQuery.post(_ajaxUrl, data, function(r) {
    if (r && r.success) { cb(r.data); }
    else { (errCb || function(m){ gsiqToast(m || 'Something went wrong', 'error'); })(r && r.data && r.data.message ? r.data.message : 'Error'); }
  }, 'json').fail(function(){ (errCb || function(m){gsiqToast(m,'error');})('Network error. Please try again.'); });
}

function gsiqToast(msg, type) {
  if (typeof GS_Toast !== 'undefined') { GS_Toast.show(msg, type||'success'); return; }
  if (typeof gsToast !== 'undefined') { gsToast(msg, type||'success'); return; }
  alert(msg);
}

/* ── Tab ─────────────────────────────────────────────────────── */
window.gsiqSetTab = function(el, status) {
  document.querySelectorAll('.gsiq-tab').forEach(function(t){ t.classList.remove('on'); });
  el.classList.add('on');
  _status = status;
  gsiqLoadList(1);
};

/* ── Filters ─────────────────────────────────────────────────── */
window.gsiqToggleStarred = function() {
  _starred = _starred ? 0 : 1;
  var btn = document.getElementById('gsiq-starred-toggle');
  btn.classList.toggle('on', !!_starred);
  gsiqLoadList(1);
};

window.gsiqDebounceSearch = function() {
  clearTimeout(_debounce);
  _debounce = setTimeout(function(){ _search = document.getElementById('gsiq-search').value; gsiqLoadList(1); }, 350);
};

/* ── Load list ───────────────────────────────────────────────── */
function gsiqLoadList(page) {
  if (_loading) return; // block any duplicate request regardless of page number
  _loading = true;
  var list = document.getElementById('gsiq-list');
  if (page === 1) {
    list.innerHTML = '<div class="gsiq-list-empty"><div class="gsiq-spinner"></div></div>';
    _selected = {};
    gsiqUpdateBulkBar();
  }
  _priority   = document.getElementById('gsiq-prio-filter').value;
  _module     = (document.getElementById('gsiq-module-filter') || {value:''}).value;
  var _listingId = (document.getElementById('gsiq-listing-filter') || {value:''}).value;
  var _dateFrom = (document.getElementById('gsiq-date-from') || {value:''}).value;
  var _dateTo   = (document.getElementById('gsiq-date-to')   || {value:''}).value;
  var _sortBy   = (document.getElementById('gsiq-sort-sel')  || {value:'newest'}).value;
  gsiqPost('gs_get_inquiries', {
    status:   _status,
    priority: _priority,
    module:   _module,
    listing_id: _listingId,
    service_plan_id: _servicePlanId,
    starred:  _starred,
    search:   _search,
    date_from: _dateFrom,
    date_to:   _dateTo,
    sort_by:   _sortBy,
    page:     page,
    per_page: 25,
  }, function(d) {
    _loading  = false;
    _page     = page;
    _hasMore  = d.has_more;
    if (page === 1) list.innerHTML = '';
    if (!d.leads || !d.leads.length) {
      if (page === 1) list.innerHTML = '<div class="gsiq-list-empty"><div class="gsiq-list-empty-icon">📬</div><div class="gsiq-list-empty-title">No inquiries found</div><div>Try a different filter or search term</div></div>';
    } else {
      d.leads.forEach(function(lead){ list.appendChild(gsiqBuildItem(lead)); });
    }
    // Load more button
    var lf = list.querySelector('.gsiq-list-footer');
    if (lf) lf.remove();
    if (d.has_more) {
      var footer = document.createElement('div');
      footer.className = 'gsiq-list-footer';
      footer.innerHTML = '<button class="gsiq-load-more" onclick="gsiqLoadMore()">Load more inquiries</button>';
      list.appendChild(footer);
    }
    gsiqRefreshStats();
  }, function(m){ _loading = false; list.innerHTML = '<div class="gsiq-list-empty">' + m + '</div>'; });
}

window.gsiqLoadMore = function() {
  gsiqLoadList(_page + 1);
};

function gsiqBuildItem(lead) {
  var div = document.createElement('div');
  div.className = 'gsiq-item' + (lead.status === 'new' ? ' gsiq-unread' : '');
  div.dataset.id = lead.id;

  var barCls = 'bar-' + (lead.status || 'new');
  var starCls = parseInt(lead.is_starred) ? 'starred' : '';
  var starChar = parseInt(lead.is_starred) ? '★' : '☆';
  var prioHtml = '';
  if (lead.priority === 'high')   prioHtml = '<span class="gsiq-prio-badge prio-high">High</span>';
  if (lead.priority === 'urgent') prioHtml = '<span class="gsiq-prio-badge prio-urgent">Urgent</span>';
  // Quality badge (Part 22.2)
  var qScore      = parseInt(lead.quality_score) || 0;
  var qualityHtml = '';
  if (qScore >= 8)      qualityHtml = '<span class="gsiq-quality-badge gsiq-q-high" title="High quality lead">★' + qScore + '</span>';
  else if (qScore >= 5) qualityHtml = '<span class="gsiq-quality-badge gsiq-q-med" title="Medium quality">◈' + qScore + '</span>';
  else if (qScore > 0)  qualityHtml = '<span class="gsiq-quality-badge gsiq-q-low" title="Low detail">' + qScore + '</span>';
  // Overdue badge — unanswered new inquiry over 2 hours
  var overdueHtml = '';
  if (lead.status === 'new' && lead.created_at) {
    var ageHours = (Date.now() - new Date(lead.created_at.replace(' ','T')).getTime()) / 3600000;
    if (ageHours > 2) overdueHtml = '<span class="gsiq-badge-overdue" title="Unanswered over 2 hours">⏰ Overdue</span>';
  }
  // Hot badge — urgent priority with significant budget
  var hotHtml = '';
  if (lead.priority === 'urgent' && (parseFloat(lead.product_price) || 0) >= 5000) {
    hotHtml = '<span class="gsiq-badge-hot" title="High-value urgent">🔥 Hot</span>';
  }
  // Account verification badge — set from the customer's account-level
  // email/WhatsApp verification (see submitInquiry()'s account-verification
  // stamp at creation time). Gives suppliers a quick trust signal without
  // gating whether the inquiry reaches them at all.
  var verifyHtml = (parseInt(lead.email_verified) && parseInt(lead.phone_verified))
    ? '<span style="font-size:.62rem;background:#ECFDF5;color:#047857;border-radius:8px;padding:1px 6px;font-weight:700" title="Customer verified both email and WhatsApp">✓ Verified Inquiry</span>'
    : '<span style="font-size:.62rem;background:#F1F5F9;color:#64748B;border-radius:8px;padding:1px 6px;font-weight:600" title="Customer has not completed account verification">Verification Pending</span>';
  var unread = lead.status === 'new' ? '<div class="gsiq-unread-dot"></div>' : '';
  var timeAgo = gsiqTimeAgo(lead.created_at);

  // Phase 2: booking badge — shown for leads created via the "Book Now" flow.
  // Shows the booking date and, if available, the live job status icon
  // (confirmed/travelling/arrived/in_progress/done) from gs_bookings.
  var bookingHtml = '';
  if (lead.inquiry_type === 'booking' && lead.booking_date) {
    var jsIcons = {confirmed:'\uD83D\uDCC5',travelling:'\uD83D\uDE97',arrived:'\uD83D\uDCCD',in_progress:'\uD83D\uDD27',done:'\uD83C\uDF89',cancelled:'\u274C'};
    var js = (lead.booking_info && lead.booking_info.job_status) ? lead.booking_info.job_status : 'confirmed';
    var jsIcon = jsIcons[js] || '\uD83D\uDCC5';
    bookingHtml = '<span style="font-size:.62rem;background:#ECFDF5;color:#047857;border-radius:8px;padding:1px 6px;font-weight:700;white-space:nowrap">' + jsIcon + ' ' + gsiqEsc(lead.booking_date) + (lead.booking_time ? ' ' + gsiqEsc(lead.booking_time) : '') + '</span>';
  }

  div.innerHTML =
    '<input type="checkbox" style="margin-top:3px;flex-shrink:0" onchange="gsiqToggleSelect(this,' + lead.id + ')">' +
    '<div class="gsiq-item-bar ' + barCls + '"></div>' +
    '<div class="gsiq-item-body" onclick="gsiqOpenLead(' + lead.id + ')">' +
      '<div class="gsiq-item-name">' + gsiqEsc(lead.name) + (lead.company_name ? '' : '') + '</div>' +
      (lead.company_name ? '<div class="gsiq-item-co">🏢 ' + gsiqEsc(lead.company_name) + '</div>' : '') +
      '<div class="gsiq-item-prod">' + (lead.inquiry_module ? '📋 ' + gsiqEsc(lead.inquiry_module.replace(/-/g,' ').replace(/\b\w/g, function(l){return l.toUpperCase();})) : (lead.product_name ? '📦 ' + gsiqEsc(lead.product_name) : '📨 General Inquiry')) + '</div>' +
      '<div class="gsiq-item-foot"><span class="gsiq-item-time">' + timeAgo + '</span>' + prioHtml + overdueHtml + hotHtml + qualityHtml + verifyHtml + bookingHtml +
      (parseInt(lead.is_multi_quote) ? '<span style="font-size:.62rem;background:#FEF3C7;color:#92400E;border-radius:8px;padding:1px 5px;font-weight:700">⚡ Competing</span>' : '') +
      '</div>' +
    '</div>' +
    unread +
    '<span class="gsiq-item-star ' + starCls + '" onclick="gsiqQuickStar(event,' + lead.id + ',this)">' + starChar + '</span>';
  return div;
}

/* ── Open lead detail ─────────────────────────────────────────── */
window.gsiqOpenLead = function(id) {
  var detailDiv = document.getElementById('gsiq-detail');
  var emptyDiv  = document.getElementById('gsiq-right-empty');
  detailDiv.style.display = 'flex';
  emptyDiv.style.display  = 'none';

  // Highlight selected item in list
  document.querySelectorAll('.gsiq-item').forEach(function(el){ el.classList.remove('on'); });
  var selItem = document.querySelector('.gsiq-item[data-id="' + id + '"]');
  if (selItem) selItem.classList.add('on');

  // Mobile: show right panel + sticky back bar
  if (window.innerWidth <= 768) {
    document.getElementById('gsiq-left').classList.add('hide');
    document.getElementById('gsiq-right').classList.add('show');
    document.getElementById('gsiq-back-btn').style.display = 'none'; // old btn stays hidden
    // Show the dedicated mobile back bar
    var backBar = document.getElementById('gsiq-mob-back-bar');
    if (backBar) {
      backBar.style.display = 'flex';
      // Update title with customer name once data loads (updated in gsiqRenderCard)
      var titleEl = document.getElementById('gsiq-mob-back-bar-title');
      if (titleEl) titleEl.textContent = 'Loading…';
    }
  }

  // Fetch full detail
  var card     = document.getElementById('gsiq-cust-card');
  var timeline = document.getElementById('gsiq-timeline-body');
  card.innerHTML    = '<div style="text-align:center;padding:20px"><div class="gsiq-spinner"></div></div>';
  timeline.innerHTML = '';

  // Mark as viewed immediately (fire-and-forget)
  gsiqPost('gs_mark_inquiry_viewed', { lead_id: id }, function(){}, function(){});

  gsiqPost('gs_get_inquiry_detail', { lead_id: id }, function(d) {
    _curLead = d.lead;
    gsiqRenderCard(d.lead);
    gsiqRenderTimeline(d.replies);
    gsiqSyncActionBar(d.lead);
  });
};

window.gsiqMobileBack = function() {
  document.getElementById('gsiq-left').classList.remove('hide');
  document.getElementById('gsiq-right').classList.remove('show');
  document.getElementById('gsiq-back-btn').style.display = 'none';
  var backBar = document.getElementById('gsiq-mob-back-bar');
  if (backBar) backBar.style.display = 'none';
};

/* ── Render customer card ─────────────────────────────────────── */
function gsiqRenderCard(lead) {
  var card    = document.getElementById('gsiq-cust-card');
  var initial = (lead.name || '?').charAt(0).toUpperCase();
  var waPhone = (lead.phone || '').replace(/[^0-9]/g,'');
  var inqNo   = 'INQ-' + String(lead.id).padStart(5,'0');

  // Update mobile back bar title with customer name now that we have data
  if (window.innerWidth <= 768) {
    var titleEl = document.getElementById('gsiq-mob-back-bar-title');
    var subEl   = document.getElementById('gsiq-mob-back-bar-sub');
    if (titleEl) titleEl.textContent = lead.name || 'Inquiry Detail';
    if (subEl)   subEl.textContent   = inqNo;
  }
  var srcLabels = {
    fluent_form:         '📋 Contact Form',
    organic:             '🌐 Website',
    enquiry_modal_v2:    '📋 Enquiry Form',
    quick_connect:       '⚡ Quick Connect',
    quote_popup:         '💬 Get a Quote',
    contact_section:     '✉ Contact Section',
    directory_enquiry:   '🗂 Directory',
    api:                 '🔌 API',
  };
  var src     = srcLabels[lead.source] || ('🌐 ' + (lead.source || 'Website'));

  var extraHtml = '';


  // ── Helper: format a field key into a readable label ─────────────────────
  function fmtKey(k) {
    return k.replace(/_(from|to|date|time)$/, ' ($1)')
            .replace(/_/g, ' ')
            .replace(/\b\w/g, function(c){ return c.toUpperCase(); });
  }
  function fmtVal(v) {
    if (Array.isArray(v)) return v.join(', ');
    if (v === '1' || v === true) return 'Yes';
    if (v === '0' || v === false) return 'No';
    return String(v);
  }

  // ── Phase 2: Booking status card (unified vendor inbox) ────────────────────
  // Shown for leads created via the "Book Now" flow (Phase 1). booking_info is
  // attached server-side by LeadRepository::get_vendor_leads() when
  // custom_fields.booking_id resolves to a gs_bookings row.
  if (lead.inquiry_type === 'booking') {
    var bi = lead.booking_info || null;
    var js = bi ? (bi.job_status || 'confirmed') : 'confirmed';
    var jsLabels = {confirmed:'Confirmed',travelling:'Vendor en route',arrived:'Vendor arrived',in_progress:'In progress',done:'Completed',cancelled:'Cancelled'};
    var jsColors = {confirmed:'#2563EB',travelling:'#D97706',arrived:'#7C3AED',in_progress:'#059669',done:'#059669',cancelled:'#DC2626'};
    var jsCol = jsColors[js] || '#2563EB';
    extraHtml += '<div style="border:1.5px solid #BBF7D0;border-radius:10px;padding:16px;margin-bottom:14px;background:#F0FDF4">';
    extraHtml += '<div style="font-size:.72rem;font-weight:800;color:#047857;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px">📅 Booking</div>';
    extraHtml += '<div style="font-size:.86rem;font-weight:700;color:#1E293B;margin-bottom:4px">' + gsiqEsc(lead.booking_date||'') + (lead.booking_time ? ' at ' + gsiqEsc(lead.booking_time) : '') + '</div>';
    extraHtml += '<div style="margin-bottom:10px"><span style="background:' + jsCol + '20;color:' + jsCol + ';border-radius:20px;padding:3px 11px;font-size:.78rem;font-weight:700">' + (jsLabels[js]||js) + '</span></div>';
    if (bi && bi.tracking_token) {
      var trackUrl = window.location.origin + '/track-job/' + bi.tracking_token + '/';
      extraHtml += '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">';
      extraHtml += '<button type="button" class="gs-btn gs-btn-ghost gs-btn-xs" onclick="navigator.clipboard.writeText(\'' + trackUrl.replace(/'/g,"\\'") + '\').then(function(){gsToast(\'Tracking link copied!\',\'success\')})">🔗 Copy tracking link</button>';
      extraHtml += '<a href="' + trackUrl + '" target="_blank" rel="noopener" class="gs-btn gs-btn-ghost gs-btn-xs">👁 View tracking page</a>';
      extraHtml += '</div>';
    }
    if (bi && js !== 'done' && js !== 'cancelled') {
      var nextSteps = {confirmed:['travelling','🚗 On my way'],travelling:['arrived','📍 Arrived'],arrived:['in_progress','🔧 Start job'],in_progress:['done','🎉 Mark done']};
      var nx = nextSteps[js];
      if (nx) {
        extraHtml += '<button type="button" class="gs-btn gs-btn-primary gs-btn-xs" onclick="gsiqUpdateJobStatus(' + bi.id + ',\'' + nx[0] + '\',this)">' + nx[1] + '</button>';
      }
    } else if (!bi) {
      extraHtml += '<div style="font-size:.76rem;color:#94A3B8">Booking record not found — this inquiry may have been created before the booking system was enabled.</div>';
    }
    extraHtml += '</div>';
  }

  if (lead.inquiry_module) {
    var modName = lead.inquiry_module.replace(/-/g,' ').replace(/\b\w/g, function(c){return c.toUpperCase();});
    var cfData = (lead.custom_fields && typeof lead.custom_fields === 'object') ? lead.custom_fields : {};
    var cfKeys = Object.keys(cfData).filter(function(k){ return k !== '_message'; });

    // Build the inquiry fields card
    extraHtml += '<div style="border:1.5px solid #DBEAFE;border-radius:10px;padding:16px;margin-bottom:14px;background:#F8FBFF">';
    extraHtml += '<div style="font-size:.72rem;font-weight:800;color:#1D4ED8;text-transform:uppercase;letter-spacing:.06em;margin-bottom:12px">📋 ' + gsiqEsc(modName) + ' — Inquiry Details</div>';

    if (cfKeys.length) {
      extraHtml += '<table class="gsiq-inq-fields" style="width:100%;table-layout:fixed;border-collapse:collapse;font-size:.82rem">';
      cfKeys.forEach(function(k) {
        var raw = cfData[k];
        var val = fmtVal(raw);
        if (val === '' || val === null || val === undefined) return; // skip only genuinely empty values — 'No' is a real, meaningful answer and must stay visible
        extraHtml += '<tr>';
        extraHtml += '<td style="padding:5px 10px 5px 0;color:#64748B;font-weight:600;word-break:break-word;vertical-align:top;width:42%;border-bottom:1px solid #EFF6FF">' + gsiqEsc(fmtKey(k)) + '</td>';
        extraHtml += '<td style="padding:5px 0 5px 10px;color:#1E293B;border-bottom:1px solid #EFF6FF;word-break:break-word;overflow-wrap:break-word">' + gsiqEsc(val) + '</td>';
        extraHtml += '</tr>';
      });
      extraHtml += '</table>';
    } else {
      extraHtml += '<p style="color:#94A3B8;font-size:.8rem;margin:0">No additional field data recorded.</p>';
    }

    // Show submitter message if stored separately in custom_fields._message
    if (cfData._message && cfData._message.trim()) {
      extraHtml += '<div style="margin-top:10px;padding-top:10px;border-top:1px solid #DBEAFE">';
      extraHtml += '<span style="font-size:.72rem;font-weight:700;color:#1D4ED8;text-transform:uppercase">Message</span>';
      extraHtml += '<p style="font-size:.82rem;color:#1E293B;margin:5px 0 0">' + gsiqEsc(cfData._message) + '</p>';
      extraHtml += '</div>';
    }
    extraHtml += '</div>';
  }

  // ── Legacy extra_fields (non-module leads) ────────────────────────────────
  if (!lead.inquiry_module && lead.extra_fields && typeof lead.extra_fields === 'object') {
    var efKeys = Object.keys(lead.extra_fields);
    if (efKeys.length) {
      extraHtml += '<div class="gsiq-extra-fields"><div class="gsiq-extra-title">Additional Details</div>';
      efKeys.forEach(function(k){
        var v = fmtVal(lead.extra_fields[k]);
        if (!v) return;
        extraHtml += '<div style="margin-bottom:5px;font-size:.83rem"><strong>' + gsiqEsc(fmtKey(k)) + ':</strong> ' + gsiqEsc(v) + '</div>';
      });
      extraHtml += '</div>';
    }
  }

  card.innerHTML =
    '<div class="gsiq-cust-card-hd">' +
      '<div class="gsiq-avatar">' + initial + '</div>' +
      '<div>' +
        '<div class="gsiq-cust-name">' + gsiqEsc(lead.name) + '</div>' +
        (lead.company_name ? '<div class="gsiq-cust-co">🏢 ' + gsiqEsc(lead.company_name) + '</div>' : '') +
        '<div class="gsiq-cust-time">' + gsiqTimeAgo(lead.created_at) + ' · ' + inqNo + '</div>' +
      '</div>' +
    '</div>' +
    '<div class="gsiq-info-grid">' +
      gsiqInfoCell('Mobile', lead.phone ? '<a href="tel:' + gsiqAttr(lead.phone) + '">' + gsiqEsc(lead.phone) + '</a>' : '—') +
      gsiqInfoCell('Email', lead.email ? '<a href="mailto:' + gsiqAttr(lead.email) + '">' + gsiqEsc(lead.email) + '</a>' : '—') +
      gsiqInfoCell('City / Location', lead.city || '—') +
      gsiqInfoCell('Inquiry Source', src) +
      gsiqInfoCell('Received', gsiqFmtDate(lead.created_at)) +
      (lead.replied_at ? gsiqInfoCell('Last Reply', gsiqFmtDate(lead.replied_at)) : '') +
    '</div>' +
    // Real fix: Product & Service popup inquiries (product_name/quantity/
    // product_price/purchase_date/callback_date) previously only showed as
    // scattered cells mixed in with generic fields above, AND the same data
    // was duplicated as flattened text inside the message box (see
    // AjaxController::submitLead()) — making the whole record read like an
    // unstructured message rather than a proper inquiry. This mirrors the
    // exact same "Inquiry Details" table treatment used for category-form
    // (inquiry_module) leads below, so both types are equally well-formatted.
    ( !lead.inquiry_module && ( lead.product_name || lead.quantity || lead.product_price || lead.purchase_date || lead.callback_date ) ?
      '<div style="border:1.5px solid #DBEAFE;border-radius:10px;padding:16px;margin-bottom:14px;background:#F8FBFF">' +
      '<div style="font-size:.72rem;font-weight:800;color:#1D4ED8;text-transform:uppercase;letter-spacing:.06em;margin-bottom:12px">📦 Product / Service Inquiry — Details</div>' +
      '<table class="gsiq-inq-fields" style="width:100%;table-layout:fixed;border-collapse:collapse;font-size:.82rem">' +
        (lead.product_name ? '<tr><td style="padding:5px 10px 5px 0;color:#64748B;font-weight:600;vertical-align:top;width:42%;border-bottom:1px solid #EFF6FF">Product / Service</td><td style="padding:5px 0 5px 10px;color:#1E293B;border-bottom:1px solid #EFF6FF;word-break:break-word">' + gsiqEsc(lead.product_name) + '</td></tr>' : '') +
        (lead.quantity ? '<tr><td style="padding:5px 10px 5px 0;color:#64748B;font-weight:600;vertical-align:top;width:42%;border-bottom:1px solid #EFF6FF">Quantity</td><td style="padding:5px 0 5px 10px;color:#1E293B;border-bottom:1px solid #EFF6FF">' + gsiqEsc(lead.quantity) + '</td></tr>' : '') +
        (lead.product_price ? '<tr><td style="padding:5px 10px 5px 0;color:#64748B;font-weight:600;vertical-align:top;width:42%;border-bottom:1px solid #EFF6FF">Expected Budget</td><td style="padding:5px 0 5px 10px;color:#1E293B;border-bottom:1px solid #EFF6FF">' + gsiqEsc(lead.product_price) + '</td></tr>' : '') +
        (lead.purchase_date ? '<tr><td style="padding:5px 10px 5px 0;color:#64748B;font-weight:600;vertical-align:top;width:42%;border-bottom:1px solid #EFF6FF">Purchase Date</td><td style="padding:5px 0 5px 10px;color:#1E293B;border-bottom:1px solid #EFF6FF">' + gsiqEsc(lead.purchase_date) + '</td></tr>' : '') +
        (lead.callback_date ? '<tr><td style="padding:5px 10px 5px 0;color:#64748B;font-weight:600;vertical-align:top;width:42%;border-bottom:1px solid #EFF6FF">Callback Date</td><td style="padding:5px 0 5px 10px;color:#1E293B;border-bottom:1px solid #EFF6FF">' + gsiqEsc(gsiqFmtDate(lead.callback_date)) + '</td></tr>' : '') +
      '</table>' +
      '</div>'
    : '' ) +
    (lead.message ? '<div class="gsiq-msg-block"><div class="gsiq-msg-lbl">Customer Message / Requirement</div>' + gsiqEsc(lead.message).replace(/\n/g,'<br>') + '</div>' : '') +
    extraHtml +
    // WhatsApp quick-connect
    (waPhone ? '<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">' +
      '<a href="tel:' + gsiqAttr(lead.phone) + '" class="gs-btn gs-btn-green gs-btn-sm">📞 Call</a>' +
      '<a href="https://wa.me/' + waPhone + '?text=' + encodeURIComponent('Hi ' + (lead.name||'') + ', we received your inquiry' + (lead.product_name ? ' for ' + lead.product_name : '') + '. We will get back to you shortly.') + '" target="_blank" class="gs-btn gs-btn-sm" style="background:#25D366;color:#fff;border:none" onclick="gsiqLogWhatsApp(' + lead.id + ')">💬 WhatsApp</a>' +
      (lead.email ? '<a href="mailto:' + gsiqAttr(lead.email) + '" class="gs-btn gs-btn-ghost gs-btn-sm">✉ Email</a>' : '') +
    '</div>' : '');
}

function gsiqInfoCell(lbl, val) {
  return '<div class="gsiq-info-cell"><div class="gsiq-info-lbl">' + gsiqEsc(lbl) + '</div><div class="gsiq-info-val">' + val + '</div></div>';
}

/* ── Sync action bar with current lead ───────────────────────── */
function gsiqSyncActionBar(lead) {
  var statSel = document.getElementById('gsiq-status-sel');
  var prioSel = document.getElementById('gsiq-prio-sel');
  var starBtn = document.getElementById('gsiq-star-btn');
  if (statSel) statSel.value = lead.status || 'new';
  if (prioSel) prioSel.value = lead.priority || 'normal';
  if (starBtn) {
    var starred = parseInt(lead.is_starred) ? true : false;
    starBtn.textContent = starred ? '★ Starred' : '☆ Star';
    starBtn.classList.toggle('starred', starred);
  }
}

/* ── Render timeline ─────────────────────────────────────────── */
function gsiqRenderTimeline(replies) {
  var body  = document.getElementById('gsiq-timeline-body');
  var count = document.getElementById('gsiq-reply-count');
  if (!replies || !replies.length) {
    body.innerHTML = '<div style="text-align:center;color:#94A3B8;font-size:.8rem;padding:12px">No conversation yet. Send a reply above to start the conversation.</div>';
    if (count) count.textContent = '';
    return;
  }
  if (count) count.textContent = '(' + replies.length + ' message' + (replies.length > 1 ? 's' : '') + ')';
  body.innerHTML = '';
  replies.forEach(function(r){
    var wrap = document.createElement('div');
    var type = r.sender_type === 'customer' ? 'customer' : (r.is_internal == 1 ? 'internal' : 'vendor');
    wrap.className = 'gsiq-bubble-wrap ' + type;
    var sent = r.sent_via === 'email' ? '✉ email' : (r.sent_via === 'whatsapp' ? '💬 WhatsApp' : (r.is_internal == 1 ? '🔒 internal note' : 'form'));
    var metaText = gsiqEsc(r.sender_name || (type === 'customer' ? 'Customer' : 'Vendor')) + ' · ' + gsiqTimeAgo(r.created_at) + ' · ' + sent;
    var msgHtml  = gsiqEsc(r.message).replace(/\n/g, '<br>');
    var intLabel = (r.is_internal == 1) ? '<div style="font-size:.68rem;font-weight:700;margin-bottom:4px">🔒 INTERNAL NOTE — not sent to customer</div>' : '';
    wrap.innerHTML = '<div class="gsiq-bubble ' + type + '">' + intLabel + msgHtml + '</div>' +
                     '<div class="gsiq-bubble-meta">' + metaText + '</div>';
    body.appendChild(wrap);
  });
  // Scroll timeline to bottom
  var scroll = document.getElementById('gsiq-scroll');
  if (scroll) setTimeout(function(){ scroll.scrollTop = scroll.scrollHeight; }, 50);
}

/* ── Action bar handlers ─────────────────────────────────────── */
window.gsiqUpdateStatus = function() {
  if (!_curLead) return;
  var sel = document.getElementById('gsiq-status-sel');
  gsiqPost('gs_update_inquiry_status', { lead_id: _curLead.id, status: sel.value }, function(d) {
    _curLead.status = d.status;
    gsiqToast('Status updated to ' + d.status, 'success');
    gsiqRefreshStats();
    gsiqRefreshListItem(_curLead.id, { status: d.status });
  });
};

window.gsiqUpdatePriority = function() {
  if (!_curLead) return;
  var sel = document.getElementById('gsiq-prio-sel');
  gsiqPost('gs_update_inquiry_priority', { lead_id: _curLead.id, priority: sel.value }, function(d) {
    _curLead.priority = d.priority;
    gsiqToast('Priority set to ' + d.priority, 'success');
    gsiqRefreshListItem(_curLead.id, { priority: d.priority });
  });
};

window.gsiqToggleStar = function() {
  if (!_curLead) return;
  gsiqPost('gs_toggle_inquiry_star', { lead_id: _curLead.id }, function(d) {
    _curLead.is_starred = d.is_starred;
    var btn = document.getElementById('gsiq-star-btn');
    btn.textContent = d.is_starred ? '★ Starred' : '☆ Star';
    btn.classList.toggle('starred', !!d.is_starred);
    gsiqRefreshListItem(_curLead.id, { is_starred: d.is_starred });
    gsiqToast(d.is_starred ? 'Inquiry starred.' : 'Star removed.', 'success');
  });
};

/* ── Reply and notes ─────────────────────────────────────────── */
window.gsiqUpdateCharCount = function() {
  var ta = document.getElementById('gsiq-reply-ta');
  var cc = document.getElementById('gsiq-char-count');
  if (cc) cc.textContent = (ta ? ta.value.length : 0) + ' chars';
};

window.gsiqSendReply = function(isInternal) {
  if (!_curLead) return;
  var ta  = document.getElementById('gsiq-reply-ta');
  var msg = ta ? ta.value.trim() : '';
  if (!msg) { gsiqToast('Please type a reply first.', 'error'); return; }

  var action = isInternal ? 'gs_add_inquiry_note' : 'gs_reply_to_inquiry';
  var dataKey = isInternal ? 'note' : 'message';
  var postData = { lead_id: _curLead.id };
  postData[dataKey] = msg;

  gsiqPost(action, postData, function(d) {
    if (ta) ta.value = '';
    gsiqUpdateCharCount();
    var timeline = document.getElementById('gsiq-timeline-body');
    // Remove "no replies yet" message if present
    if (timeline.querySelector('div[style*="No conversation"]')) timeline.innerHTML = '';

    var wrap = document.createElement('div');
    var type = isInternal ? 'internal' : 'vendor';
    wrap.className = 'gsiq-bubble-wrap ' + type;
    var r = d.reply || { sender_name: 'You', message: msg, sent_via: isInternal ? 'internal' : 'email', created_at: 'Just now', is_internal: isInternal ? 1 : 0 };
    var intLabel = isInternal ? '<div style="font-size:.68rem;font-weight:700;margin-bottom:4px">🔒 INTERNAL NOTE — not sent to customer</div>' : '';
    wrap.innerHTML = '<div class="gsiq-bubble ' + type + '">' + intLabel + gsiqEsc(r.message).replace(/\n/g,'<br>') + '</div>' +
                     '<div class="gsiq-bubble-meta">You · Just now · ' + (isInternal ? '🔒 internal note' : '✉ email') + '</div>';
    timeline.appendChild(wrap);

    var scrollDiv = document.getElementById('gsiq-scroll');
    if (scrollDiv) scrollDiv.scrollTop = scrollDiv.scrollHeight;

    if (!isInternal) {
      // Update status to 'replied' locally
      _curLead.status = 'replied';
      var statSel = document.getElementById('gsiq-status-sel');
      if (statSel) statSel.value = 'replied';
      gsiqRefreshListItem(_curLead.id, { status: 'replied' });
      gsiqRefreshStats();
    }

    var replyCount = document.getElementById('gsiq-reply-count');
    if (replyCount) {
      var n = parseInt(replyCount.textContent) || 0;
      replyCount.textContent = '(' + (n+1) + ' message' + (n+1>1?'s':'') + ')';
    }
    gsiqToast(d.message || (isInternal ? 'Note saved.' : 'Reply sent.'), 'success');
  });
};

/* ── Quick star from list ────────────────────────────────────── */
window.gsiqQuickStar = function(e, id, el) {
  e.stopPropagation();
  gsiqPost('gs_toggle_inquiry_star', { lead_id: id }, function(d) {
    el.textContent  = d.is_starred ? '★' : '☆';
    el.className    = 'gsiq-item-star' + (d.is_starred ? ' starred' : '');
    gsiqToast(d.is_starred ? 'Starred.' : 'Unstarred.', 'success');
  });
};

/* ── Phase 2: Advance a booking's job status from the inbox detail pane ──── */
window.gsiqUpdateJobStatus = function(bookingId, status, btn) {
  if (btn) { btn.disabled = true; btn.textContent = 'Updating…'; }
  gsiqPost('gs_update_job_status', { booking_id: bookingId, status: status }, function() {
    gsiqToast('Status updated!', 'success');
    if (_curLead) { gsiqOpenLead(_curLead.id); } // re-fetch detail to refresh booking card
  }, function(m) {
    if (btn) { btn.disabled = false; }
    gsiqToast(m || 'Failed to update status', 'error');
  });
};

/* ── Delete ──────────────────────────────────────────────────── */
window.gsiqAssignStaff = function() {
  if (!_curLead) return;
  var sel = document.getElementById('gsiq-assign-sel');
  var staffId = sel ? sel.value : '';
  gsiqPost('gs_assign_staff', { lead_id: _curLead.id, staff_id: staffId }, function() {
    gsiqToast(staffId ? 'Inquiry assigned to staff.' : 'Assignment removed.', 'success');
  }, function(m){ gsiqToast(m, 'error'); });
};

window.gsiqArchiveInquiry = function() {
  if (!_curLead) return;
  gsiqPost('gs_bulk_inquiry_action', { bulk_action: 'status_closed', lead_ids: [_curLead.id] }, function() {
    gsiqToast('Inquiry archived.', 'success');
    gsiqRefreshListItem(_curLead.id, { status: 'closed' });
    gsiqRefreshStats();
  });
};

window.gsiqDeleteInquiry = function() {
  if (!_curLead) return;
  if (!confirm('Delete this inquiry? This cannot be undone.')) return;
  gsiqPost('gs_bulk_inquiry_action', { bulk_action: 'delete', lead_ids: [_curLead.id] }, function(d) {
    gsiqToast('Inquiry deleted.', 'success');
    var item = document.querySelector('.gsiq-item[data-id="' + _curLead.id + '"]');
    if (item) item.remove();
    document.getElementById('gsiq-detail').style.display    = 'none';
    document.getElementById('gsiq-right-empty').style.display = 'flex';
    _curLead = null;
    gsiqRefreshStats();
  });
};

/* ── Bulk select ─────────────────────────────────────────────── */
window.gsiqToggleSelect = function(cb, id) {
  if (cb.checked) { _selected[id] = true; } else { delete _selected[id]; }
  gsiqUpdateBulkBar();
};
function gsiqUpdateBulkBar() {
  var bar  = document.getElementById('gsiq-bulk-bar');
  var cnt  = document.getElementById('gsiq-bulk-count');
  var keys = Object.keys(_selected);
  bar.classList.toggle('show', keys.length > 0);
  if (cnt) cnt.textContent = keys.length + ' selected';
}
window.gsiqClearSelection = function() {
  _selected = {};
  document.querySelectorAll('.gsiq-item input[type=checkbox]').forEach(function(cb){ cb.checked = false; });
  gsiqUpdateBulkBar();
};
window.gsiqBulkApply = function() {
  var action = document.getElementById('gsiq-bulk-sel').value;
  var ids    = Object.keys(_selected).map(Number);
  if (!action || !ids.length) { gsiqToast('Select an action first.', 'error'); return; }
  if (action === 'delete' && !confirm('Delete ' + ids.length + ' inquiries? This cannot be undone.')) return;
  if (action === 'send_template') {
    // Open template picker and send template to all selected
    var tpicker = document.getElementById('gsiq-tpl-modal');
    if (tpicker) {
      window._gsiqBulkTemplateIds = ids;
      tpicker.style.display = 'flex';
    } else {
      gsToast('Template manager not loaded', 'error');
    }
    return;
  }
  gsiqPost('gs_bulk_inquiry_action', { bulk_action: action, lead_ids: ids }, function(d) {
    gsiqToast(d.message || ids.length + ' inquiries updated.', 'success');
    gsiqClearSelection();
    gsiqLoadList(1);
    gsiqRefreshStats();
  });
};

/* ── Export CSV ──────────────────────────────────────────────── */
window.gsiqExportCsv = function() {
  var form = document.createElement('form');
  form.method = 'POST';
  form.action = _ajaxUrl;
  var fields  = { action:'gs_export_inquiries_csv', nonce:_nonce, status:_status, priority:_priority, starred:_starred, search:_search, date_from:_dateFrom||'', date_to:_dateTo||'', sort_by:_sortBy||'newest', module:_module };
  Object.keys(fields).forEach(function(k){ var i=document.createElement('input'); i.type='hidden'; i.name=k; i.value=fields[k]; form.appendChild(i); });
  document.body.appendChild(form);
  form.submit();
  document.body.removeChild(form);
};

/* ── Refresh helpers ─────────────────────────────────────────── */
function gsiqRefreshStats() {
  gsiqPost('gs_get_inquiry_stats', {}, function(d) {
    if (!d.stats) return;
    var map = { '':d.stats.total, 'new':d.stats.new, 'viewed':d.stats.viewed, 'replied':d.stats.replied, 'converted':d.stats.converted, 'closed':d.stats.closed, 'junk':d.stats.junk };
    Object.keys(map).forEach(function(k){
      var el = document.getElementById('cnt-' + (k||'all'));
      if (el) el.textContent = map[k] || 0;
    });
    if (d.stats.new > 0) document.getElementById('cnt-new').classList.add('urgent');
    else document.getElementById('cnt-new').classList.remove('urgent');
  }, function(){});
}

function gsiqRefreshListItem(id, updates) {
  var item = document.querySelector('.gsiq-item[data-id="' + id + '"]');
  if (!item) return;
  var bar = item.querySelector('.gsiq-item-bar');
  if (bar && updates.status) {
    bar.className = 'gsiq-item-bar bar-' + updates.status;
  }
  var star = item.querySelector('.gsiq-item-star');
  if (star && typeof updates.is_starred !== 'undefined') {
    star.textContent  = updates.is_starred ? '★' : '☆';
    star.className    = 'gsiq-item-star' + (updates.is_starred ? ' starred' : '');
  }
  var unread = item.querySelector('.gsiq-unread-dot');
  if (updates.status && updates.status !== 'new' && unread) unread.remove();
}

/* ── Auto-polling every 60 s ─────────────────────────────────── */
function gsiqPoll() {
  // Real fix (Known Limitations): skip the request entirely while the tab
  // is hidden — the interval itself is never torn down (this is a
  // full-page-navigation app, so it's expected to end when the vendor
  // navigates away), but there is no reason to keep firing background
  // requests once the vendor has switched to another tab or app.
  if (document.hidden) return;
  gsiqPost('gs_get_inquiry_stats', {}, function(d) {
    if (!d.stats) return;
    var newNow = parseInt(d.stats.new) || 0;
    var el = document.getElementById('cnt-new');
    var was = parseInt(el ? el.textContent : '0') || 0;
    if (newNow > was) {
      gsiqToast('📬 You have ' + newNow + ' new inquiries!', 'info');
      gsiqLoadList(1);
    }
    gsiqRefreshStats();
  }, function(){});
}
/* FIXED — Known Limitations audit: replaced the flat 60-second
   setInterval with WordPress core's own Heartbeat API, which this page
   asks to tick at a 15-second interval (Plugin::gs_heartbeat_settings()) —
   a real "push-adjacent" mechanism (Heartbeat batches with any other
   admin-bar/session activity already happening) rather than a bespoke
   WebSocket/SSE build-out, exactly as this limitation's own proposed fix
   named. 'heartbeat-send' flags the request so the server only does the
   extra query when this screen is actually open (see
   AjaxController::inject_inquiry_heartbeat()); 'heartbeat-tick' reads the
   response the same way gsiqPoll() used to read its own AJAX response.
   The manual setInterval is kept ONLY as a safety-net fallback for the
   rare case Heartbeat itself is disabled (e.g. by a caching/performance
   plugin) — at its original, unchanged 60s cadence, so nothing regresses
   if that happens. */
if (typeof jQuery !== 'undefined' && jQuery(document).on) {
  jQuery(document).on('heartbeat-send', function(e, data) {
    if (document.hidden) return;
    data.gs_inquiry_stats = true;
  });
  jQuery(document).on('heartbeat-tick', function(e, data) {
    if (!data || !data.gs_inquiry_stats) return;
    var d = data.gs_inquiry_stats;
    var newNow = parseInt(d.new) || 0;
    var el = document.getElementById('cnt-new');
    var was = parseInt(el ? el.textContent : '0') || 0;
    if (newNow > was) {
      gsiqToast('📬 You have ' + newNow + ' new inquiries!', 'info');
      gsiqLoadList(1);
    }
    var map = { '':d.total, 'new':d.new, 'viewed':d.viewed, 'replied':d.replied, 'converted':d.converted, 'closed':d.closed, 'junk':d.junk };
    Object.keys(map).forEach(function(k){
      var mel = document.getElementById('cnt-' + (k||'all'));
      if (mel) mel.textContent = map[k] || 0;
    });
    if (d.new > 0) document.getElementById('cnt-new').classList.add('urgent');
    else document.getElementById('cnt-new').classList.remove('urgent');
  });
}
var _pollTimer = setInterval(gsiqPoll, 60000);
document.addEventListener('visibilitychange', function() {
  // Catch up immediately on return, rather than waiting up to 60s for the
  // next tick, so a vendor coming back to the tab sees current counts right away.
  if (!document.hidden) gsiqPoll();
});
window.addEventListener('beforeunload', function() { clearInterval(_pollTimer); });

/* ── Utility ─────────────────────────────────────────────────── */
function gsiqEsc(s) {
  if (!s) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function gsiqAttr(s) { return encodeURIComponent(s||''); }

function gsiqTimeAgo(dt) {
  if (!dt) return '—';
  var then = new Date(dt.replace(' ','T'));
  var secs = Math.max(0, Math.floor((Date.now() - then.getTime()) / 1000));
  if (secs < 60)    return 'just now';
  if (secs < 3600)  return Math.floor(secs/60)   + 'm ago';
  if (secs < 86400) return Math.floor(secs/3600)  + 'h ago';
  if (secs < 2592000) return Math.floor(secs/86400) + 'd ago';
  return then.toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
}

function gsiqFmtDate(dt) {
  if (!dt) return '—';
  return new Date(dt.replace(' ','T')).toLocaleString('en-IN', { day:'numeric', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });
}

/* ── WhatsApp logging (Part 13.2) ────────────────────────────── */
window.gsiqLogWhatsApp = function(leadId) {
  gsiqPost('gs_log_whatsapp_contact', { lead_id: leadId, type: 'deep_link' }, function(){}, function(){});
};

/* ── AI Draft (Part 8.1–8.2) ────────────────────────────────── */
window.gsiqAiDraft = function() {
  if (!_curLead) { gsiqToast('Select an inquiry first.', 'error'); return; }
  var tone    = (document.getElementById('gsiq-ai-tone') || {value:'professional'}).value;
  var loading = document.getElementById('gsiq-ai-loading');
  var ta      = document.getElementById('gsiq-reply-ta');
  if (loading) loading.style.display = 'block';
  gsiqPost('gs_ai_generate_content', {
    lead_id: _curLead.id,
    type:    'reply',
    tone:    tone,
  }, function(d) {
    if (loading) loading.style.display = 'none';
    if (d.text) {
      if (ta) { ta.value = d.text; gsiqUpdateCharCount(); }
      gsiqToast('AI draft ready — review before sending.', 'success');
    }
  }, function(msg) {
    if (loading) loading.style.display = 'none';
    gsiqToast(msg || 'AI draft failed. Check API key in Admin → Settings.', 'error');
  });
};

/* ── Template Picker (Part 7.2) ──────────────────────────────── */
var _tplCache = null;
window.gsiqOpenTemplatePicker = function() {
  document.getElementById('gsiq-tpl-overlay').classList.add('open');
  document.getElementById('gsiq-tpl-search').value = '';
  gsiqLoadTemplates();
};
window.gsiqCloseTplPicker = function() {
  document.getElementById('gsiq-tpl-overlay').classList.remove('open');
};
function gsiqLoadTemplates() {
  if (_tplCache) { gsiqRenderTemplates(_tplCache); return; }
  var module = _curLead ? (_curLead.inquiry_module || '') : '';
  gsiqPost('gs_get_reply_templates', { module_slug: module }, function(d) {
    _tplCache = d.templates || [];
    gsiqRenderTemplates(_tplCache);
  }, function() {
    document.getElementById('gsiq-tpl-list').innerHTML = '<div class="gsiq-tpl-empty">Could not load templates.</div>';
  });
}
function gsiqRenderTemplates(templates, filter) {
  var list = document.getElementById('gsiq-tpl-list');
  var items = filter ? templates.filter(function(t){ return (t.name + t.body).toLowerCase().indexOf(filter.toLowerCase()) > -1; }) : templates;
  if (!items.length) {
    list.innerHTML = '<div class="gsiq-tpl-empty">No templates found.<br><a href="?section=leads&manage_templates=1" style="color:#2563EB">Create your first template →</a></div>';
    return;
  }
  list.innerHTML = '';
  items.forEach(function(t) {
    var div = document.createElement('div');
    div.className = 'gsiq-tpl-item';
    div.innerHTML = '<div class="gsiq-tpl-name">' + gsiqEsc(t.name) + '</div>' +
                    '<div class="gsiq-tpl-body">' + gsiqEsc(t.body) + '</div>';
    div.onclick = function() { gsiqSelectTemplate(t); };
    list.appendChild(div);
  });
}
window.gsiqFilterTemplates = function(q) {
  if (_tplCache) gsiqRenderTemplates(_tplCache, q);
};
window.gsiqSelectTemplate = function(tpl) {
  var ta = document.getElementById('gsiq-reply-ta');
  if (ta) {
    ta.value = tpl.body;
    gsiqUpdateCharCount();
    ta.focus();
  }
  gsiqPost('gs_increment_template_use', { template_id: tpl.id }, function(){}, function(){});
  gsiqCloseTplPicker();
  gsiqToast('Template inserted.', 'success');
};

/* ── Quotation Builder (Part 6.2) ────────────────────────────── */
window.gsiqOpenQuoteBuilder = function() {
  if (!_curLead) { gsiqToast('Select an inquiry first.', 'error'); return; }
  var overlay = document.getElementById('gsiq-qb-overlay');
  overlay.classList.add('open');
  var ref = document.getElementById('gsiq-qb-inq-ref');
  if (ref) ref.textContent = 'INQ-' + String(_curLead.id).padStart(5,'0') + ' · ' + gsiqEsc(_curLead.name);
  var items = document.getElementById('gsiq-qb-items');
  items.innerHTML = '';
  gsiqQbAddRow();
  gsiqQbRecalc();
};
window.gsiqCloseQuoteBuilder = function() {
  document.getElementById('gsiq-qb-overlay').classList.remove('open');
};
window.gsiqQbAddRow = function(desc, qty, price) {
  var items = document.getElementById('gsiq-qb-items');
  var div = document.createElement('div');
  div.className = 'qb-row';
  div.innerHTML =
    '<input class="gsiq-inp qb-desc" placeholder="Service / item" value="' + gsiqEsc(desc||'') + '" oninput="gsiqQbRecalc()">' +
    '<input class="gsiq-inp qb-qty" type="number" value="' + (qty||1) + '" min="1" style="text-align:center" oninput="gsiqQbRecalc()">' +
    '<input class="gsiq-inp qb-price" type="number" value="' + (price||0) + '" placeholder="0" oninput="gsiqQbRecalc()" style="text-align:right">' +
    '<button onclick="this.closest(\'.qb-row\').remove();gsiqQbRecalc()" style="background:none;border:none;color:#DC2626;cursor:pointer;font-size:1.1rem;padding:0" title="Remove">×</button>';
  items.appendChild(div);
};
window.gsiqQbRecalc = function() {
  var subtotal = 0;
  document.querySelectorAll('#gsiq-qb-items .qb-row').forEach(function(row) {
    var qty   = parseFloat(row.querySelector('.qb-qty').value)   || 0;
    var price = parseFloat(row.querySelector('.qb-price').value) || 0;
    subtotal += qty * price;
  });
  var gstOn  = document.getElementById('gsiq-qb-gst').checked;
  var gst    = gstOn ? Math.round(subtotal * 0.18 * 100) / 100 : 0;
  var total  = subtotal + gst;
  var fmt    = function(v){ return '₹' + Math.round(v).toLocaleString('en-IN'); };
  document.getElementById('gsiq-qb-subtotal').textContent = fmt(subtotal);
  document.getElementById('gsiq-qb-gst-row').style.display = gstOn ? 'flex' : 'none';
  if (gstOn) document.getElementById('gsiq-qb-gst-amt').textContent = fmt(gst);
  document.getElementById('gsiq-qb-total').textContent = fmt(total);
};
window.gsiqQbSend = function() {
  if (!_curLead) return;
  var items = [];
  document.querySelectorAll('#gsiq-qb-items .qb-row').forEach(function(row) {
    var desc  = row.querySelector('.qb-desc').value.trim();
    var qty   = parseFloat(row.querySelector('.qb-qty').value)   || 1;
    var price = parseFloat(row.querySelector('.qb-price').value) || 0;
    if (desc) items.push({ description: desc, qty: qty, unit_price: price, total: qty * price });
  });
  if (!items.length) { gsiqToast('Add at least one line item.', 'error'); return; }
  var btn = document.getElementById('gsiq-qb-send-btn');
  btn.disabled = true; btn.textContent = 'Sending…';
  gsiqPost('gs_create_quotation', {
    lead_id:       _curLead.id,
    line_items:    JSON.stringify(items),
    gst_rate:      document.getElementById('gsiq-qb-gst').checked ? 18 : 0,
    validity_days: document.getElementById('gsiq-qb-validity').value || 7,
    payment_terms: document.getElementById('gsiq-qb-terms').value || '',
    notes:         document.getElementById('gsiq-qb-notes').value || '',
    cover_note:    document.getElementById('gsiq-qb-cover').value || '',
  }, function(data) {
    gsiqPost('gs_send_quotation', { quote_id: data.quote_id, lead_id: _curLead.id }, function() {
      gsiqToast('Quote sent to client!', 'success');
      gsiqCloseQuoteBuilder();
      btn.disabled = false; btn.textContent = '📤 Send Quote to Client';
      // Refresh timeline to show quotation entry
      gsiqPost('gs_get_inquiry_detail', { lead_id: _curLead.id }, function(d) {
        gsiqRenderTimeline(d.replies);
      }, function(){});
    }, function(msg) {
      gsiqToast(msg || 'Send failed.', 'error');
      btn.disabled = false; btn.textContent = '📤 Send Quote to Client';
    });
  }, function(msg) {
    gsiqToast(msg || 'Failed to create quote.', 'error');
    btn.disabled = false; btn.textContent = '📤 Send Quote to Client';
  });
};
window.gsiqQbSaveDraft = function() {
  if (!_curLead) return;
  var items = [];
  document.querySelectorAll('#gsiq-qb-items .qb-row').forEach(function(row) {
    var desc  = row.querySelector('.qb-desc').value.trim();
    var qty   = parseFloat(row.querySelector('.qb-qty').value)   || 1;
    var price = parseFloat(row.querySelector('.qb-price').value) || 0;
    if (desc) items.push({ description: desc, qty: qty, unit_price: price, total: qty * price });
  });
  gsiqPost('gs_save_quote_draft', {
    lead_id:    _curLead.id,
    line_items: JSON.stringify(items),
    gst_rate:   document.getElementById('gsiq-qb-gst').checked ? 18 : 0,
    validity_days: document.getElementById('gsiq-qb-validity').value || 7,
    cover_note: document.getElementById('gsiq-qb-cover').value || '',
    notes:      document.getElementById('gsiq-qb-notes').value || '',
  }, function() { gsiqToast('Draft saved.', 'success'); }, function(m){ gsiqToast(m,'error'); });
};

/* ── Init ────────────────────────────────────────────────────── */
(function init(){
  gsiqLoadList(1);
  gsiqRefreshStats();

  // If URL has ?view=NNN open that inquiry directly
  var urlParams = new URLSearchParams(window.location.search);
  var viewId = parseInt(urlParams.get('view')) || 0;
  if (viewId) {
    setTimeout(function(){ gsiqOpenLead(viewId); }, 600);
  }
})();

})();
</script>
