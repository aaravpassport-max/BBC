<?php
/**
 * Real fix — root cause: the "Contact section" inline inquiry form
 * (vendor-site.php, $cx_fields / $cx_step3 loops) used to be a separate,
 * hand-rolled, hardcoded field renderer that only understood
 * text/email/phone/number/select/textarea and fell back to a bare
 * <input type="{$field_type}"> for everything else — silently dropping
 * date_range/radio/multi_select/toggle/date fields entirely, and for
 * 'radio' specifically producing an unlabeled, option-less
 * <input type="radio"> (rendering as a lone dot, submitting the
 * browser-default value "on") wherever a radio-type universal field
 * such as "Preferred Contact Method" appeared.
 *
 * render_iq_field() already handles every field type correctly and is
 * the single source of truth used by the main multi-step Inquiry
 * Modules panel (inquiry-modules.php). Extracted here into its own
 * file, guarded by function_exists(), so both the contact-section form
 * (which needs it before inquiry-modules.php's own panel is included
 * further down the page) and the main panel itself can safely
 * require_once() it — one implementation, no duplicate/incomplete
 * reimplementation, no redeclaration risk regardless of include order.
 */
if ( ! function_exists( 'render_iq_field' ) ) {
function render_iq_field($fid,$fn,$fl,$ft,$req,$fo,$fph,$fhp,$cattr,$fothers,$fdef,$slug) {
    $hide = $cattr ? ' style="display:none"' : '';
    $cclass = $cattr ? ' iq-cond' : '';
    $slug_fk = str_replace(['iq_','iq_u_','iq_c_'], '', $fid);
    $others_id = 'iq-oth-'.$slug.'_'.($fdef['key']??'');
    // Real feature: show_label — defaults to true (today's exact behavior:
    // toggle shows its label, other types use the label as their
    // placeholder). When explicitly false, the toggle's <label> element is
    // omitted, and other types fall back to a generic, non-label
    // placeholder rather than silently keeping the label text visible.
    $show_label = ! isset( $fdef['show_label'] ) || $fdef['show_label'];
    if ( ! $show_label ) { $fph = str_replace( $fl, '', $fph ); if ( trim( $fph, ' -' ) === '' ) { $fph = 'Enter value'; } }
    ob_start();
?>
<div class="iq-fg<?php echo $cclass;?>" id="<?php echo esc_attr('iq-fg-'.$fid);?>"<?php echo $cattr; echo $hide;?>>
<?php
    $star = $req ? ' *' : '';
    if($ft==='toggle'){
?>
  <div class="iq-trow">
    <div class="iq-tog" id="<?php echo esc_attr($fid);?>"
         onclick="iqTog(this,'<?php echo esc_js($fn);?>','<?php echo esc_js($slug);?>')"></div>
    <?php if ( $show_label ): ?>
    <label class="iq-tlbl" onclick="document.getElementById('<?php echo esc_attr($fid);?>').click()"><?php echo esc_html($fl); ?></label>
    <?php endif; ?>
    <input type="hidden" name="<?php echo esc_attr($fn);?>" value="0" data-fk="<?php echo esc_attr($fn);?>">
  </div>
<?php
    } elseif(in_array($ft,['text','email','phone','number','url'],true)){
        $type = $ft==='phone'?'tel':$ft;
?>
  <input type="<?php echo esc_attr($type);?>" class="iq-inp" id="<?php echo esc_attr($fid);?>"
         name="<?php echo esc_attr($fn);?>" placeholder="<?php echo esc_attr($fph.$star);?>"
         <?php echo $req?'required':''; ?> data-fk="<?php echo esc_attr($fn);?>"
         <?php if($ft==='number') echo 'min="'.esc_attr($fdef['min']??0).'" max="'.esc_attr($fdef['max']??9999).'"'; ?>>
<?php
    } elseif($ft==='textarea'){
?>
  <textarea class="iq-ta" id="<?php echo esc_attr($fid);?>" name="<?php echo esc_attr($fn);?>"
            placeholder="<?php echo esc_attr($fph.$star);?>" <?php echo $req?'required':''; ?>
            data-fk="<?php echo esc_attr($fn);?>"></textarea>
<?php
    } elseif($ft==='select'){
?>
  <select class="iq-sel" id="<?php echo esc_attr($fid);?>" name="<?php echo esc_attr($fn);?>"
          aria-label="<?php echo esc_attr($fl); ?>"
          <?php echo $req?'required':''; ?> data-fk="<?php echo esc_attr($fn);?>"
          onchange="iqSelChange(this,'<?php echo esc_js($others_id);?>')">
    <option value=""><?php echo esc_html($fph.$star); ?></option>
    <?php foreach($fo as $o): ?><option value="<?php echo esc_attr((string)$o);?>"><?php echo esc_html((string)$o);?></option><?php endforeach; ?>
  </select>
  <?php if($fothers): ?>
  <div id="<?php echo esc_attr($others_id);?>" style="display:none;margin-top:7px">
    <textarea class="iq-ta iq-others-ta" name="<?php echo esc_attr($fn.'_others');?>"
              placeholder="Please describe your specific requirement so we can match you with the right expert."
              style="min-height:64px" data-fk="<?php echo esc_attr($fn.'_others');?>"></textarea>
  </div>
  <?php endif; ?>
<?php
    } elseif($ft==='radio'){
?>
  <div class="iq-ch-hdr"><?php echo esc_html($fl.$star); ?></div>
  <div class="iq-chips" data-fk="<?php echo esc_attr($fn);?>" data-req="<?php echo $req?'1':'0'; ?>"
       data-others-id="<?php echo esc_attr($others_id);?>">
    <?php foreach($fo as $o): ?>
    <span class="iq-chip" data-v="<?php echo esc_attr((string)$o);?>"
          onclick="iqRad(this,'<?php echo esc_js($fn);?>','<?php echo esc_js($slug);?>','<?php echo esc_js($others_id);?>')"><?php echo esc_html((string)$o);?></span>
    <?php endforeach; ?>
    <input type="hidden" name="<?php echo esc_attr($fn);?>" data-fk="<?php echo esc_attr($fn);?>">
  </div>
  <?php if($fothers): ?>
  <div id="<?php echo esc_attr($others_id);?>" style="display:none;margin-top:7px">
    <textarea class="iq-ta iq-others-ta" name="<?php echo esc_attr($fn.'_others');?>"
              placeholder="Please describe your specific requirement so we can match you with the right expert."
              style="min-height:64px"></textarea>
  </div>
  <?php endif; ?>
<?php
    } elseif($ft==='multi_select'||$ft==='checkbox'){
?>
  <div class="iq-ch-hdr"><?php echo esc_html($fl); ?> <span style="font-weight:400;font-size:.67rem">(select all that apply)</span></div>
  <div class="iq-chips">
    <?php foreach($fo as $o): ?>
    <span class="iq-chip" data-v="<?php echo esc_attr((string)$o);?>"
          onclick="iqMul(this,'<?php echo esc_js($fn);?>','<?php echo esc_js($slug.'_'.($fdef['key']??''));?>')"><?php echo esc_html((string)$o);?></span>
    <?php endforeach; ?>
  </div>
  <div id="iq-ms-<?php echo esc_attr($slug.'_'.($fdef['key']??''));?>" style="display:none"></div>
<?php
    } elseif($ft==='date'){
?>
  <div class="iq-dlbl"><?php echo esc_html($fl.$star); ?></div>
  <input type="date" class="iq-inp" id="<?php echo esc_attr($fid);?>" name="<?php echo esc_attr($fn);?>"
         aria-label="<?php echo esc_attr($fl);?>" min="<?php echo esc_attr(date('Y-m-d'));?>"
         <?php echo $req?'required':''; ?> data-fk="<?php echo esc_attr($fn);?>">
<?php
    } elseif($ft==='date_range'){
?>
  <div class="iq-dlbl"><?php echo esc_html($fl.$star); ?></div>
  <div class="iq-dp">
    <div>
      <input type="date" class="iq-inp" name="<?php echo esc_attr($fn);?>_from"
             min="<?php echo esc_attr(date('Y-m-d'));?>" <?php echo $req?'required':''; ?> data-fk="<?php echo esc_attr($fn.'_from');?>">
      <div class="iq-dlbl" style="margin-top:3px">Check-in / From</div>
    </div>
    <div>
      <input type="date" class="iq-inp" name="<?php echo esc_attr($fn);?>_to" data-fk="<?php echo esc_attr($fn.'_to');?>">
      <div class="iq-dlbl" style="margin-top:3px">Check-out / To</div>
    </div>
  </div>
<?php
    } elseif($ft==='time'){
?>
  <div class="iq-dlbl"><?php echo esc_html($fl.$star); ?></div>
  <input type="time" class="iq-inp" id="<?php echo esc_attr($fid);?>" name="<?php echo esc_attr($fn);?>"
         aria-label="<?php echo esc_attr($fl);?>" <?php echo $req?'required':''; ?> data-fk="<?php echo esc_attr($fn);?>">
<?php
    } elseif($ft==='datetime'){
?>
  <div class="iq-dlbl"><?php echo esc_html($fl.$star); ?></div>
  <div class="iq-dp">
    <div>
      <input type="date" class="iq-inp" name="<?php echo esc_attr($fn);?>_date"
             min="<?php echo esc_attr(date('Y-m-d'));?>" <?php echo $req?'required':''; ?> data-fk="<?php echo esc_attr($fn.'_date');?>">
      <div class="iq-dlbl" style="margin-top:3px">Date</div>
    </div>
    <div>
      <input type="time" class="iq-inp" name="<?php echo esc_attr($fn);?>_time" data-fk="<?php echo esc_attr($fn.'_time');?>">
      <div class="iq-dlbl" style="margin-top:3px">Time</div>
    </div>
  </div>
<?php
    } elseif($ft==='slider'){
        $slo=(int)($fdef['min']??0); $shi=(int)($fdef['max']??100000); $smid=(int)(($slo+$shi)/2);
?>
  <div class="iq-ch-hdr"><?php echo esc_html($fl); ?></div>
  <input type="range" class="iq-range" id="<?php echo esc_attr($fid);?>"
         name="<?php echo esc_attr($fn);?>" min="<?php echo (int)$slo;?>" max="<?php echo (int)$shi;?>"
         value="<?php echo (int)$smid;?>" data-fk="<?php echo esc_attr($fn);?>"
         oninput="document.getElementById('<?php echo esc_attr($fid);?>_v').textContent='&#8377;'+parseInt(this.value).toLocaleString('en-IN')">
  <div class="iq-rval" id="<?php echo esc_attr($fid);?>_v">&#8377;<?php echo number_format((int)$smid);?></div>
<?php
    } elseif($ft==='file'){
?>
  <div class="iq-ch-hdr"><?php echo esc_html($fl); ?></div>
  <div class="iq-file-zone" id="<?php echo esc_attr($fid);?>_zone"
       onclick="document.getElementById('<?php echo esc_attr($fid);?>_inp').click()"
       ondragover="event.preventDefault();this.classList.add('drag')"
       ondragleave="this.classList.remove('drag')"
       ondrop="iqFileDrop(event,'<?php echo esc_attr($fid);?>')">
    <div style="font-size:1.4rem;margin-bottom:6px">📎</div>
    <div style="font-size:.82rem;font-weight:600;color:#475569">Click to upload or drag &amp; drop</div>
    <p>Up to 5 files — JPG, PNG, WEBP, MP4 (max 30s) · Max 10MB each</p>
    <div class="iq-upload-bar" id="<?php echo esc_attr($fid);?>_bar"></div>
  </div>
  <div class="iq-thumbs" id="<?php echo esc_attr($fid);?>_thumbs"></div>
  <input type="file" id="<?php echo esc_attr($fid);?>_inp" name="<?php echo esc_attr($fn);?>[]"
         accept=".jpg,.jpeg,.png,.webp,.mp4" multiple style="display:none"
         onchange="iqFileChange(this,'<?php echo esc_attr($fid);?>')">
<?php
    }
    if($fhp){ echo '<div class="iq-help-text">'.esc_html($fhp).'</div>'; }
    echo '<div class="iq-ferr" id="iq-fe-'.esc_attr($fid).'"></div>';
?>
</div>
<?php
    return ob_get_clean();
}

}
