<?php
/**
 * Inquiry Modules — 4-Step Premium Form
 * LEFT:  Image/banner + CTA
 * RIGHT: 4-step form (Step 1: Service Details, Step 2: Schedule+Location,
 *                      Step 3: Contact+Prefs, Step 4: Review+Submit)
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( empty( $_inq_modules_data ) ) { return; }

// ─── Field renderer helper — a shared, function_exists()-guarded file so
// the contact-section form (vendor-site.php) can also require_once it
// before this panel is included further down the page, without any
// duplicate/incomplete reimplementation and without a "cannot redeclare"
// risk either way. Loaded here at the top (not after the loops that call
// it) since require_once — unlike a plain function declaration — is not
// hoisted; calling render_iq_field() before this line executes would be
// a fatal "Call to undefined function" error. ──────────────────────────
require_once GS_DIR . 'templates/pages/partials/inquiry-field-renderer.php';

$_vs = function( string $k, string $d = '' ) use ( $cd ) {
    return ( isset( $cd[$k] ) && $cd[$k] !== '' ) ? (string)$cd[$k] : $d;
};
$_vn = function( string $k, int $d, int $lo = 0, int $hi = 999 ) use ( $cd ) {
    return max( $lo, min( $hi, (int)( $cd[$k] ?? $d ) ) );
};

$brand         = isset( $brand_color ) ? $brand_color : '#2563EB';
// Backgrounds stay listing-specific ONLY — no global default layer for these,
// per explicit instruction. Each listing's own value (or a neutral hardcoded
// fallback) is all that applies here.
$s_sec_bg      = $_vs( 'inq_sec_bg' );
$s_left_img    = $_vs( 'inq_left_img' );
$s_left_pos    = $_vs( 'inq_left_img_pos', 'center center' );
$s_left_bg     = $_vs( 'inq_left_bg',      '#1E3A5F' );
// Overlay color/opacity for the left-panel gradient — previously fully
// hardcoded (rgba(0,0,0,.05) / rgba(0,0,0,.2)), no per-listing control
// existed at all. Converts the stored hex color to rgb() components so the
// opacity can be applied independently via rgba().
$s_overlay_hex = $_vs( 'inq_overlay_color', '#000000' );
$s_overlay_op  = $_vn( 'inq_overlay_opacity', 20, 0, 80 ) / 100;
$s_overlay_rgb = ( function( string $hex ): string {
    $hex = ltrim( $hex, '#' );
    if ( strlen( $hex ) === 3 ) { $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2]; }
    if ( strlen( $hex ) !== 6 || ! ctype_xdigit( $hex ) ) { return '0,0,0'; } // safe fallback for an invalid/empty value
    return implode( ',', [ hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) ] );
} )( $s_overlay_hex );
$s_cta_h       = $_vs( 'inq_cta_heading' );
$s_cta_p       = $_vs( 'inq_cta_body' );
$s_cta_btn_lbl = $_vs( 'inq_cta_btn_text' );
$s_cta_btn_url = $_vs( 'inq_cta_btn_link', '#vs-sec-inquiry-modules' );
$s_cta_btn_bg  = $_vs( 'inq_cta_btn_bg',   '#F59E0B' );
$s_cta_btn_col = $_vs( 'inq_cta_btn_color','#ffffff' );
$s_form_bg     = $_vs( 'inq_form_bg',      '#ffffff' );

// Typography, inputs, buttons, structure — these get a real GLOBAL DEFAULT
// layer for the first time. Resolution order: this listing's own override
// (unchanged behaviour) → site-wide global default (NEW — Settings →
// Inquiry Form Design) → hardcoded fallback (unchanged, used only if the
// admin has never configured the global default either). Previously there
// was no middle tier: every un-overridden listing fell straight through to
// the hardcoded literal, so changing the look platform-wide meant editing
// this PHP file. Now an admin can change it once for every form that
// doesn't have its own override, exactly the "one place controls every
// form" requirement — built only for the settings that should genuinely be
// global, not the ones already correctly scoped per-listing.
$s_hd_col      = $_vs( 'inq_heading_color', \GoodService\Core\Config::get( 'inq_global_heading_color', '#ffffff' ) );
$s_bd_col      = $_vs( 'inq_body_color',    \GoodService\Core\Config::get( 'inq_global_body_color', 'rgba(255,255,255,.82)' ) );
$s_inp_bg      = $_vs( 'inq_input_bg',      \GoodService\Core\Config::get( 'inq_global_input_bg', '#F8FAFC' ) );
$s_inp_bdr     = $_vs( 'inq_input_border',  \GoodService\Core\Config::get( 'inq_global_input_border', '#E2E8F0' ) );
$s_inp_txt     = $_vs( 'inq_input_text',    \GoodService\Core\Config::get( 'inq_global_input_text', '#1E293B' ) );
$s_btn_bg      = $_vs( 'inq_btn_bg',        \GoodService\Core\Config::get( 'inq_global_btn_bg', $brand ) );
$s_btn_txt     = $_vs( 'inq_btn_text',      \GoodService\Core\Config::get( 'inq_global_btn_text', '#ffffff' ) );
$s_lbl         = $_vs( 'inq_label_color',   \GoodService\Core\Config::get( 'inq_global_label_color', '#475569' ) );
// Typography — font-family is set ONCE at the top container and inherited by
// everything inside via font-family:inherit (already the existing pattern
// for every text element in this form — confirmed before adding this, not
// assumed). One global setting correctly cascades to all of them; per-element
// font-family overrides would fight that cascade for no visible benefit.
$s_font_family = \GoodService\Core\Config::get( 'inq_global_font_family', 'inherit' );
// Font size/weight ARE genuinely distinct per text role today — confirmed by
// reading the actual CSS rather than assumed: input/placeholder text, button
// text, and field help text are each their own hardcoded rule. Field LABELS
// are NOT a separate element from placeholder text in this form's existing
// design (most field types use the label as a floating placeholder, not a
// separate visible label — see $_fph = $_f['ph'] ?? $_fl in this same file),
// so there is no independent "label font" to control without first changing
// that design, which is out of scope here.
$s_input_fsize = \GoodService\Core\Config::get( 'inq_global_input_font_size', '.86rem' );
$s_input_fwt   = \GoodService\Core\Config::get( 'inq_global_input_font_weight', '400' );
$s_btn_fsize   = \GoodService\Core\Config::get( 'inq_global_btn_font_size', '.87rem' );
$s_btn_fwt     = \GoodService\Core\Config::get( 'inq_global_btn_font_weight', '700' );
$s_help_fsize  = \GoodService\Core\Config::get( 'inq_global_help_font_size', '.7rem' );
// Description text (.iq-fs — the form's intro/subtitle line shown above the
// fields) and placeholder text (the ::placeholder pseudo-element on inputs)
// were both fully hardcoded with zero global control until now — neither
// is the same element as $s_bd_col (that's the LEFT PANEL's marketing copy,
// .iq-cta-p, a different part of the page) or $s_inp_txt (that's what the
// customer actually TYPES, not the greyed-out placeholder hint shown before
// they type). Help text's color/weight were also still hardcoded — only its
// font-size had a global setting from the earlier typography work.
$s_desc_color  = \GoodService\Core\Config::get( 'inq_global_desc_color', '#64748B' );
$s_desc_fsize  = \GoodService\Core\Config::get( 'inq_global_desc_font_size', '.8rem' );
$s_desc_fwt    = \GoodService\Core\Config::get( 'inq_global_desc_font_weight', '400' );
$s_ph_color    = \GoodService\Core\Config::get( 'inq_global_placeholder_color', '#94A3B8' );
$s_ph_fsize    = \GoodService\Core\Config::get( 'inq_global_placeholder_font_size', '.83rem' );
$s_ph_fwt      = \GoodService\Core\Config::get( 'inq_global_placeholder_font_weight', '400' );
$s_help_color  = \GoodService\Core\Config::get( 'inq_global_help_color', '#94A3B8' );
$s_help_fwt    = \GoodService\Core\Config::get( 'inq_global_help_font_weight', '400' );
$s_ratio       = $_vs( 'inq_left_ratio',    '50%' );
$s_shadow_k    = $_vs( 'inq_form_shadow',   \GoodService\Core\Config::get( 'inq_global_form_shadow', 'lg' ) );
$s_f_r         = $_vn( 'inq_form_radius',   (int) \GoodService\Core\Config::get( 'inq_global_form_radius', 24 ), 0, 40 );
$s_b_r         = $_vn( 'inq_btn_radius',    (int) \GoodService\Core\Config::get( 'inq_global_btn_radius', 8 ),  0, 50 );
$s_pt          = $_vn( 'inq_sec_pt',        (int) \GoodService\Core\Config::get( 'inq_global_sec_pt', 72 ), 0, 160 );
$s_pb          = $_vn( 'inq_sec_pb',        (int) \GoodService\Core\Config::get( 'inq_global_sec_pb', 72 ), 0, 160 );

$shadows       = ['none'=>'none','sm'=>'0 4px 20px rgba(0,0,0,.07)','md'=>'0 8px 32px rgba(0,0,0,.11)','lg'=>'0 20px 60px rgba(0,0,0,.16)'];
$s_shadow      = $shadows[$s_shadow_k] ?? $shadows['lg'];

$mod_count = count( $_inq_modules_data );
$univ      = \GoodService\Service\InquiryFormService::universal_fields();

// Vendor's min visit charge (for review step notice), plus vendor identity
// data needed by the slot-picker (vendor_id) and confirmation screen
// (vendor name, avg reply time). Phase 1 — previously these were referenced
// in JS via data-vendor-name/data-avg-reply attributes that were never
// rendered anywhere, so the lookups silently fell back to defaults.
$min_charge   = 0;
$_iq_vendor_id   = 0;
$_iq_vendor_name = '';
$_iq_avg_reply   = 0;
if ( isset( $primary ) && $primary ) {
    // BUG-FIX: gs_vendor_profiles has NO listing_id column. The correct
    // relationship is: listings.vendor_id → vendor_profiles.id.
    // The old query (WHERE listing_id=%d with $primary->id) always returned
    // NULL, so $_iq_vendor_id was always 0 and vendor_name was always ''.
    $vp_meta = $GLOBALS['wpdb']->get_row( $GLOBALS['wpdb']->prepare(
        'SELECT id, min_visit_charge, business_name, avg_reply_minutes FROM ' . $GLOBALS['wpdb']->prefix . 'gs_vendor_profiles WHERE id=%d',
        (int)$primary->vendor_id
    ) );
    if ( $vp_meta ) {
        $min_charge      = (float) $vp_meta->min_visit_charge;
        $_iq_vendor_id   = (int)   $vp_meta->id;
        $_iq_vendor_name = (string) $vp_meta->business_name;
        $_iq_avg_reply   = (int)   $vp_meta->avg_reply_minutes;
    }
}
?>
<style>
/* Real fix — same broken/question-mark icon symptom reported in Admin →
   Sections shares this exact same root cause: these are plain emoji
   CHARACTERS (from InquiryCategoryData.php), not SVG/image files, so there
   is no file path to break. The question-mark/tofu box is the browser's own
   fallback glyph when its default UI font lacks that emoji's glyph (common
   for variation-selector/ZWJ sequences on older Windows/Linux). Forcing an
   explicit color-emoji font stack fixes rendering wherever such a font is
   installed, same as the Section Manager fix. */
.gs-icon-emoji, .iq-fic { font-family: "Segoe UI Emoji","Noto Color Emoji","Apple Color Emoji","Twemoji Mozilla",-apple-system,BlinkMacSystemFont,sans-serif; }
/* ─── Inquiry Section ─────────────────────────────────────────────────── */
.iq-s{padding:<?php echo (int)$s_pt;?>px 0 <?php echo (int)$s_pb;?>px;<?php echo $s_sec_bg?'background:'.esc_attr($s_sec_bg).';':'background:linear-gradient(160deg,#EEF2FF,#F8FAFF 50%,#F0F7FF);';?>}
.iq-card{display:grid;grid-template-columns:<?php echo esc_attr($s_ratio);?> 1fr;border-radius:<?php echo (int)$s_f_r;?>px;overflow:hidden;box-shadow:<?php echo esc_attr($s_shadow);?>;max-width:1240px;margin:0 auto;font-family:<?php echo esc_attr($s_font_family);?>}
/* LEFT */
.iq-l{position:relative;display:flex;flex-direction:column;min-height:560px;overflow:hidden;background:<?php echo esc_attr($s_left_bg);?>}
.iq-l-img{position:absolute;inset:0;background-size:cover;background-position:<?php echo esc_attr($s_left_pos);?>;z-index:0}
.iq-l-grad{position:absolute;inset:0;background:linear-gradient(to bottom,rgba(<?php echo $s_overlay_rgb;?>,<?php echo round($s_overlay_op*0.25,3);?>) 0%,rgba(<?php echo $s_overlay_rgb;?>,<?php echo round($s_overlay_op,3);?>) 40%,<?php echo esc_attr($s_left_bg);?>e5 100%);z-index:1}
.iq-cta{position:relative;z-index:2;margin-top:auto;padding:44px 36px 40px}
.iq-cta-h{font-size:1.5rem;font-weight:800;line-height:1.24;color:<?php echo esc_attr($s_hd_col);?>;margin:0 0 10px}
.iq-cta-p{font-size:.88rem;line-height:1.65;color:<?php echo esc_attr($s_bd_col);?>;margin:0 0 22px}
.iq-cta-btn{display:inline-flex;align-items:center;gap:6px;padding:12px 24px;border-radius:<?php echo (int)$s_b_r;?>px;background:<?php echo esc_attr($s_cta_btn_bg);?>;color:<?php echo esc_attr($s_cta_btn_col);?>;font-weight:700;font-size:.87rem;text-decoration:none;border:none;cursor:pointer;font-family:inherit;transition:filter .15s,transform .15s}
.iq-cta-btn:hover{filter:brightness(1.1);transform:translateY(-1px)}
.iq-trust{display:flex;flex-wrap:wrap;gap:12px;margin-top:18px}
.iq-trust span{font-size:.74rem;color:rgba(255,255,255,.58);display:flex;align-items:center;gap:5px}
.iq-trust span::before{content:'✓';color:<?php echo esc_attr($s_cta_btn_bg);?>;font-weight:700}
/* RIGHT */
.iq-r{background:<?php echo esc_attr($s_form_bg);?>;padding:36px 40px;display:flex;flex-direction:column}
/* Module tabs */
.iq-tabs{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:24px;padding-bottom:16px;border-bottom:1.5px solid <?php echo esc_attr($s_inp_bdr);?>}
.iq-tab{display:inline-flex;align-items:center;gap:5px;padding:7px 14px;border-radius:20px;font-size:.79rem;font-weight:600;cursor:pointer;border:1.5px solid <?php echo esc_attr($s_inp_bdr);?>;color:<?php echo esc_attr($s_lbl);?>;background:transparent;font-family:inherit;transition:all .16s}
.iq-tab:hover{border-color:<?php echo esc_attr($s_btn_bg);?>;color:<?php echo esc_attr($s_btn_bg);?>}
.iq-tab.active{background:<?php echo esc_attr($s_btn_bg);?>;color:<?php echo esc_attr($s_btn_txt);?>;border-color:<?php echo esc_attr($s_btn_bg);?>}
/* Form panel */
.iq-fp{display:none;flex-direction:column;flex:1}
.iq-fp.active{display:flex}
/* 4-step progress */
.iq-prog{display:flex;align-items:center;margin-bottom:22px;gap:0}
.iq-prog-step{display:flex;flex-direction:column;align-items:center;position:relative}
.iq-prog-dot{width:28px;height:28px;border-radius:50%;background:#E2E8F0;color:#94A3B8;font-size:.7rem;font-weight:700;display:flex;align-items:center;justify-content:center;transition:all .2s;cursor:pointer;z-index:1}
.iq-prog-dot.done{background:#059669;color:#fff}
.iq-prog-dot.act{background:<?php echo esc_attr($s_btn_bg);?>;color:<?php echo esc_attr($s_btn_txt);?>;box-shadow:0 0 0 4px <?php echo esc_attr($s_btn_bg);?>25}
.iq-prog-line{flex:1;height:2px;background:#E2E8F0;margin:0;position:relative;top:-14px}
.iq-prog-line.done{background:#059669}
.iq-prog-lbl{font-size:.59rem;color:#94A3B8;margin-top:4px;text-align:center;white-space:nowrap}
.iq-prog-wrap{display:flex;align-items:flex-start;flex:1}
.iq-prog-wrap:last-child .iq-prog-line{display:none}
/* Form header */
.iq-fhdr{margin-bottom:18px}
.iq-fic{font-size:1.6rem;margin-bottom:6px}
.iq-ft{font-size:1.1rem;font-weight:800;color:#1E293B;margin:0 0 2px}
.iq-fs{font-size:<?php echo esc_attr($s_desc_fsize);?>;font-weight:<?php echo esc_attr($s_desc_fwt);?>;color:<?php echo esc_attr($s_desc_color);?>;margin:0}
/* Step panel */
.iq-step{overflow:auto}
/* Back arrow — top-left of each step */
.iq-back-arrow{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:50%;border:1.5px solid <?php echo esc_attr($s_inp_bdr);?>;background:transparent;cursor:pointer;font-size:1rem;color:<?php echo esc_attr($s_lbl);?>;margin-bottom:14px;transition:all .14s;flex-shrink:0}
.iq-back-arrow:hover{border-color:<?php echo esc_attr($s_btn_bg);?>;color:<?php echo esc_attr($s_btn_bg);?>}
/* Fields */
.iq-fg{margin-bottom:11px}
.iq-inp,.iq-sel,.iq-ta{width:100%;padding:11px 13px;border:1.5px solid <?php echo esc_attr($s_inp_bdr);?>;border-radius:8px;font-size:<?php echo esc_attr($s_input_fsize);?>;font-weight:<?php echo esc_attr($s_input_fwt);?>;color:<?php echo esc_attr($s_inp_txt);?>;background:<?php echo esc_attr($s_inp_bg);?>;outline:none;font-family:inherit;transition:border-color .14s,box-shadow .14s;box-sizing:border-box}
.iq-inp:focus,.iq-sel:focus,.iq-ta:focus{border-color:<?php echo esc_attr($s_btn_bg);?>;box-shadow:0 0 0 3px <?php echo esc_attr($s_btn_bg);?>18;background:#fff}
.iq-inp::placeholder,.iq-ta::placeholder{color:<?php echo esc_attr($s_ph_color);?>;font-size:<?php echo esc_attr($s_ph_fsize);?>;font-weight:<?php echo esc_attr($s_ph_fwt);?>}
.iq-inp:focus::placeholder,.iq-ta:focus::placeholder{color:<?php echo esc_attr($s_ph_color);?>;opacity:.7}
.iq-ta{resize:vertical;min-height:76px}
.iq-sel option[value=""]{color:#94A3B8}
/* Chips */
.iq-ch-hdr{font-size:.7rem;font-weight:700;color:#94A3B8;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px;margin-top:2px}
.iq-chips{display:flex;flex-wrap:wrap;gap:6px}
.iq-chip{padding:6px 13px;border:1.5px solid <?php echo esc_attr($s_inp_bdr);?>;border-radius:20px;font-size:.8rem;cursor:pointer;user-select:none;transition:all .13s;background:<?php echo esc_attr($s_inp_bg);?>;color:<?php echo esc_attr($s_lbl);?>}
.iq-chip:hover{border-color:<?php echo esc_attr($s_btn_bg);?>;color:<?php echo esc_attr($s_btn_bg);?>}
.iq-chip.sel{background:<?php echo esc_attr($s_btn_bg);?>;color:<?php echo esc_attr($s_btn_txt);?>;border-color:<?php echo esc_attr($s_btn_bg);?>}
/* Others textarea */
.iq-others-ta{margin-top:7px}
/* Toggle */
.iq-trow{display:flex;align-items:center;gap:10px;padding:7px 0}
.iq-tog{width:40px;height:22px;background:#CBD5E1;border-radius:20px;cursor:pointer;position:relative;transition:.2s;flex-shrink:0}
.iq-tog::after{content:'';position:absolute;width:16px;height:16px;background:#fff;border-radius:50%;top:3px;left:3px;transition:.2s}
.iq-tog.on{background:<?php echo esc_attr($s_btn_bg);?>}
.iq-tog.on::after{left:21px}
.iq-tlbl{font-size:.84rem;color:<?php echo esc_attr($s_lbl);?>;cursor:pointer}
/* Date / time */
.iq-dp{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.iq-dlbl{font-size:.7rem;color:#94A3B8;margin-bottom:3px;font-weight:600}
/* Slider */
.iq-range{width:100%;accent-color:<?php echo esc_attr($s_btn_bg);?>;margin:4px 0 2px}
.iq-rval{text-align:center;font-weight:700;color:<?php echo esc_attr($s_btn_bg);?>;font-size:.85rem}
/* File upload */
.iq-file-zone{border:2px dashed <?php echo esc_attr($s_inp_bdr);?>;border-radius:8px;padding:18px;text-align:center;cursor:pointer;transition:border-color .14s;background:<?php echo esc_attr($s_inp_bg);?>}
.iq-file-zone:hover,.iq-file-zone.drag{border-color:<?php echo esc_attr($s_btn_bg);?>;background:#EFF6FF}
.iq-file-zone p{font-size:.8rem;color:#94A3B8;margin:4px 0 0}
.iq-thumbs{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
.iq-thumb{width:52px;height:52px;border-radius:6px;object-fit:cover;border:1.5px solid <?php echo esc_attr($s_inp_bdr);?>}
.iq-file-name{font-size:.73rem;color:<?php echo esc_attr($s_lbl);?>;background:<?php echo esc_attr($s_inp_bg);?>;border-radius:4px;padding:4px 7px;border:1px solid <?php echo esc_attr($s_inp_bdr);?>}
.iq-upload-bar{height:3px;background:<?php echo esc_attr($s_btn_bg);?>;border-radius:3px;width:0;transition:width .3s}
/* Review step */
.iq-review-group{margin-bottom:14px}
.iq-review-title{font-size:.7rem;font-weight:700;color:<?php echo esc_attr($s_btn_bg);?>;text-transform:uppercase;letter-spacing:.05em;display:flex;align-items:center;justify-content:space-between;margin-bottom:7px;padding-bottom:4px;border-bottom:1px solid <?php echo esc_attr($s_inp_bdr);?>}
.iq-review-edit{font-size:.72rem;font-weight:600;color:<?php echo esc_attr($s_btn_bg);?>;cursor:pointer;text-decoration:underline}
.iq-review-row{font-size:.81rem;display:flex;gap:8px;padding:4px 0;color:<?php echo esc_attr($s_lbl);?>}
.iq-review-lbl{font-weight:600;min-width:120px;flex-shrink:0}
.iq-review-val{color:#1E293B;word-break:break-word}
.iq-min-charge-notice{background:#FFF8E7;border:1.5px solid #FDE68A;border-radius:8px;padding:10px 14px;font-size:.8rem;color:#92400E;margin-bottom:16px;display:flex;align-items:flex-start;gap:8px}
.iq-min-charge-notice::before{content:'ℹ️';flex-shrink:0}
/* Error */
.iq-err{background:#FEF2F2;border:1px solid #FECACA;border-radius:8px;padding:9px 13px;font-size:.79rem;color:#DC2626;margin-bottom:12px;display:none}
.iq-ferr{font-size:.7rem;color:#DC2626;margin-top:2px;display:none}
.iq-help-text{font-size:<?php echo esc_attr($s_help_fsize);?>;font-weight:<?php echo esc_attr($s_help_fwt);?>;color:<?php echo esc_attr($s_help_color);?>;margin-top:2px}
/* Buttons */
.iq-nav{display:flex;align-items:center;gap:10px;margin-top:20px;padding-top:16px;border-top:1px solid #F1F5F9}
.iq-btn{padding:11px 26px;border-radius:<?php echo (int)$s_b_r;?>px;font-size:<?php echo esc_attr($s_btn_fsize);?>;font-weight:<?php echo esc_attr($s_btn_fwt);?>;cursor:pointer;border:none;font-family:inherit;transition:all .14s;display:inline-flex;align-items:center;justify-content:center;gap:6px}
.iq-btn-p{background:<?php echo esc_attr($s_btn_bg);?>;color:<?php echo esc_attr($s_btn_txt);?>}
.iq-btn-p:hover:not([disabled]){filter:brightness(1.07);transform:translateY(-1px)}
.iq-btn-p:disabled{opacity:.5;cursor:not-allowed;transform:none}
.iq-btn-o{background:transparent;color:<?php echo esc_attr($s_btn_bg);?>;border:2px solid <?php echo esc_attr($s_btn_bg);?>}
.iq-btn-o:hover:not([disabled]){background:<?php echo esc_attr($s_btn_bg);?>18}
.iq-btn-o:disabled{opacity:.5;cursor:not-allowed}
/* Success */
.iq-ok{text-align:center;padding:52px 20px;flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center}
.iq-ok-ic{font-size:3rem;margin-bottom:12px}
.iq-ok-h{font-size:1.15rem;font-weight:800;color:#059669;margin:0 0 6px}
.iq-ok-ref{font-size:.74rem;color:#94A3B8;margin-top:6px}
/* Honeypot */
.iq-hp{position:absolute;left:-9999px;opacity:0;pointer-events:none}
/* Responsive */
@media(max-width:920px){
  .iq-card{grid-template-columns:1fr}
  .iq-l{min-height:240px}
  .iq-cta{padding:22px 20px 26px}
  .iq-r{padding:26px 20px}
  .iq-btn-p,.iq-btn-o{flex:1}
}
@media(max-width:500px){
  .iq-dp{grid-template-columns:1fr}
  .iq-s{padding:36px 0}
  .iq-r,.iq-cta{padding:16px 14px}
  .iq-prog-lbl{display:none}
}
</style>

<?php
$first_m = array_values($_inq_modules_data)[0];
$auto_h  = $mod_count > 1 ? 'Get the right help, fast.' : ($first_m['name'] ?? 'Send an Inquiry');
$auto_p  = 'Fill in your details on the right — we\'ll get back to you as soon as possible.';
$step_names = ['Service Info','More Details','Scheduling','Contact','Review & Submit'];
?>

<section class="iq-s" id="vs-sec-inquiry-modules" data-lid="<?php echo (int)$lid; ?>">
<div class="vs-wrap">

  <div style="text-align:center;margin-bottom:32px">
    <div class="vs-sec-eyebrow">Inquiries &amp; Bookings</div>
    <h2 class="vs-sec-title"><?php echo $mod_count>1 ? 'Choose a Service &amp; Enquire' : 'Send an Inquiry'; ?></h2>
    <div class="vs-divider" style="margin:12px auto 0"></div>
  </div>

  <div class="iq-card">
    <!-- LEFT -->
    <div class="iq-l">
      <?php if($s_left_img): ?>
      <div class="iq-l-img" style="background-image:url('<?php echo esc_url($s_left_img);?>')"></div>
      <?php endif; ?>
      <div class="iq-l-grad"></div>
      <div class="iq-cta">
        <h3 class="iq-cta-h"><?php echo esc_html($s_cta_h ?: $auto_h); ?></h3>
        <p  class="iq-cta-p"><?php echo esc_html($s_cta_p ?: $auto_p); ?></p>
        <?php if($s_cta_btn_lbl): ?>
        <a class="iq-cta-btn" href="<?php echo esc_url($s_cta_btn_url); ?>"><?php echo esc_html($s_cta_btn_lbl); ?> &#8594;</a>
        <?php else: ?>
        <button class="iq-cta-btn" type="button"
                onclick="document.getElementById('iq-form-<?php echo esc_js(array_key_first($_inq_modules_data));?>') && document.getElementById('iq-form-<?php echo esc_js(array_key_first($_inq_modules_data));?>').scrollIntoView({behavior:'smooth',block:'center'})">
          <?php echo esc_html(!empty($_cat['ctas'][0])?$_cat['ctas'][0]:'Get a Free Callback'); ?> &#8594;
        </button>
        <?php endif; ?>
        <div class="iq-trust">
          <?php foreach(['Fast Response','No Spam','Free Consultation'] as $tp): ?>
          <span><?php echo esc_html($tp); ?></span>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- RIGHT -->
    <div class="iq-r">
      <?php if($mod_count>1): ?>
      <div class="iq-tabs" role="tablist">
        <?php $fi=true; foreach($_inq_modules_data as $_ms=>$_mm): ?>
        <button type="button" class="iq-tab<?php echo $fi?' active':''; ?>" role="tab"
                data-target="<?php echo esc_attr($_ms); ?>"
                onclick="iqSw('<?php echo esc_js($_ms); ?>')"
                aria-selected="<?php echo $fi?'true':'false'; ?>">
          <span class="gs-icon-emoji"><?php echo $_mm['icon']; ?></span> <?php echo esc_html($_mm['name']); ?>
        </button>
        <?php $fi=false; endforeach; ?>
      </div>
      <?php endif; ?>

      <?php $fp=true; foreach($_inq_modules_data as $_slug=>$_mod):
        $_cta_lbl = !empty($_mod['cta']) ? $_mod['cta'] : ($_mod['ctas'][0]??'Submit Inquiry');
        $_intro   = $_mod['intro'] ?? '';
        // Real fix: was "step 1 = category only, step 2/3 = universal only,
        // no per-form override possible, Scheduling/Contact hardcoded to
        // step numbers 2/3" — now resolved by semantic role, never by a
        // fixed step number, so a form's own field count doesn't collide
        // with where Scheduling/Contact happen to render.
        $_resolved_flds = \GoodService\Service\InquiryFormService::resolve_fields_for_category($_slug);
        // Real feature — per-vendor Type of Service visibility for
        // Documentation Services (and, by the same generic mechanism, any
        // future category/field that needs this). Stored in this
        // listing's own customizer_data, following the exact same
        // "absence of a setting = unchanged default behavior" principle
        // already proven in form_universal_overrides — a vendor who has
        // never touched this sees the full, original option list.
        $_inq_opt_vis = is_array( $cd['inquiry_option_visibility'] ?? null ) ? $cd['inquiry_option_visibility'] : [];
        if ( ! empty( $_inq_opt_vis[ $_slug ] ) && is_array( $_inq_opt_vis[ $_slug ] ) ) {
            foreach ( $_resolved_flds as $_grp_key => $_grp_fields ) {
                foreach ( $_grp_fields as $_fi => $_fld ) {
                    $_allowed = $_inq_opt_vis[ $_slug ][ $_fld['key'] ] ?? null;
                    // A non-empty allowed-list filters the options down to
                    // only those the vendor selected. An empty array (every
                    // checkbox unchecked) is treated the same as "not
                    // configured" — showing all options — rather than
                    // silently rendering a dropdown with zero choices,
                    // which would make the form unusable.
                    if ( is_array( $_allowed ) && ! empty( $_allowed ) && ! empty( $_fld['options'] ) ) {
                        $_resolved_flds[ $_grp_key ][ $_fi ]['options'] = array_values( array_intersect( $_fld['options'], $_allowed ) );
                    }
                }
            }
        }
        $_own_s1  = $_resolved_flds['own_step_1'];
        $_own_s2  = $_resolved_flds['own_step_2'];
        $_s1_flds_all = array_values($_own_s1);
        $_s1_flds     = array_slice($_s1_flds_all, 0, 4);
        $_s2_extra    = array_slice($_s1_flds_all, 4);

        // Real fix: the actual dynamic-groups mechanism — builds the list
        // of default-step-category blocks from the real registry (today
        // Scheduling + Contact; a genuinely new one an admin adds shows
        // up here automatically), each carrying its own computed step
        // number (3, 4, 5, ... — however many precede it), title, and
        // field list, rather than two hardcoded blocks for exactly two
        // named groups.
        $_step_categories = \GoodService\Service\InquiryFormService::get_step_categories();
        $_dynamic_groups = [];
        $_gstep = 3;
        foreach ($_step_categories as $_sc) {
            $_dynamic_groups[] = [
                'key'    => $_sc['step_key'],
                'title'  => $_sc['label'],
                'step'   => $_gstep,
                'fields' => array_values($_resolved_flds[ $_sc['step_key'] ] ?? []),
            ];
            $_gstep++;
        }
        $_review_step = $_gstep; // whatever number comes after every dynamic group

        // Real fix: which physical step positions genuinely have content
        // for THIS category — computed from the actual dynamic group
        // list's real length, not a fixed 1-5 range.
        $_step_empty = [
            1 => empty($_s1_flds),
            2 => empty($_s2_extra),
        ];
        $_step_names_full = [1 => 'Service Info', 2 => 'More Details'];
        foreach ($_dynamic_groups as $_dg) {
            $_step_empty[ $_dg['step'] ] = empty($_dg['fields']);
            $_step_names_full[ $_dg['step'] ] = $_dg['title'];
        }
        $_step_empty[ $_review_step ] = false; // Review & Submit always exists
        $_step_names_full[ $_review_step ] = 'Review & Submit';
        $_max_step = $_review_step;
        // Computed early so both the panel's data-accepts-booking attribute
        // (used by the slot-picker) and the Step 5 dual-CTA block (further
        // below) use the same platform-gated value.
        $_panel_accepts_booking = ! empty( $_mod['accepts_booking'] ) && \GoodService\Module\ModuleManager::is_enabled( 'booking' );
        // Optional WhatsApp verification (Section 2 of the inquiry/booking audit) —
        // resolved via the real service (module → vendor → global), not
        // reimplemented here, so this can never drift out of sync with the
        // actual resolution logic used server-side when send/verify OTP fires.
        $_panel_wa_verify = isset( $primary ) ? \GoodService\Service\WhatsAppVerificationService::is_enabled( $primary, $_slug ) : false;
      ?>
      <div class="iq-fp<?php echo $fp?' active':''; ?>" id="iq-panel-<?php echo esc_attr($_slug); ?>" role="tabpanel"
           data-vendor-id="<?php echo (int)$_iq_vendor_id; ?>"
           data-listing-id="<?php echo (int)$lid; ?>"
           data-vendor-name="<?php echo esc_attr($_iq_vendor_name); ?>"
           data-avg-reply="<?php echo $_iq_avg_reply>0 ? esc_attr($_iq_avg_reply<60 ? $_iq_avg_reply.' minutes' : round($_iq_avg_reply/60,1).' hours') : ''; ?>"
           data-accepts-booking="<?php echo $_panel_accepts_booking ? '1' : '0'; ?>">
        <div class="iq-fhdr">
          <div class="iq-fic"><?php echo $_mod['icon']; ?></div>
          <h3 class="iq-ft"><?php echo esc_html($_mod['name']); ?></h3>
          <p  class="iq-fs"><?php echo $_intro ? esc_html($_intro) : 'Complete the form below — we\'ll respond with a tailored quote or appointment slot.'; ?></p>
        </div>
        <div id="iq-form-<?php echo esc_attr($_slug); ?>">
          <input type="hidden" name="listing_id" value="<?php echo (int)$lid; ?>">
          <input type="hidden" name="vendor_id" value="<?php echo (int)$_iq_vendor_id; ?>">

        <!-- Progress bar — real fix: only shows dots for steps that genuinely have content for this category, not a fixed 5-step bar -->
        <div class="iq-prog" id="iq-prog-<?php echo esc_attr($_slug); ?>">
          <?php $_visible_steps = array_values(array_filter(range(1,$_max_step), fn($n) => empty($_step_empty[$n]))); $_vc = count($_visible_steps); ?>
          <?php foreach($_visible_steps as $_vidx=>$_pi): ?>
          <div class="iq-prog-wrap">
            <div class="iq-prog-step">
              <div class="iq-prog-dot<?php echo $_vidx===0?' act':''; ?>"
                   id="iq-pd-<?php echo esc_attr($_slug); ?>-<?php echo (int)$_pi; ?>"
                   onclick="iqJump('<?php echo esc_js($_slug);?>',<?php echo (int)$_pi;?>)"
                   title="<?php echo esc_attr($_step_names_full[$_pi-1]); ?>"><?php echo $_vidx+1; ?></div>
              <span class="iq-prog-lbl"><?php echo esc_html($_step_names_full[$_pi-1]); ?></span>
            </div>
            <?php if($_vidx<$_vc-1): ?>
            <div class="iq-prog-line" id="iq-pl-<?php echo esc_attr($_slug); ?>-<?php echo (int)$_pi; ?>"></div>
            <?php endif; ?>
          </div>
          <?php endforeach; ?>
        </div>

        <div class="iq-err" id="iq-err-<?php echo esc_attr($_slug); ?>"></div>
        <div class="iq-hp" aria-hidden="true"><input type="text" name="gs_hp_field" tabindex="-1" autocomplete="off"></div>


        <!-- STEP 1: Core Service Info (first 4 category-specific fields) -->
        <div class="iq-step" id="iq-s1-<?php echo esc_attr($_slug); ?>" data-empty="<?php echo !empty($_step_empty[1])?'1':'0'; ?>" data-role="field-step" data-title="Service Details">
          <?php
          foreach($_s1_flds as $_f):
            $_fk=$_f['key']??''; $_fl=$_f['label']??''; $_ft=$_f['type']??'text';
            $_req=!empty($_f['required']); $_fo=array_values($_f['options']??[]);
            $_fcd=$_f['cond']??null; $_fph=$_f['ph']??$_fl; $_fhp=$_f['help']??'';
            $_fothers=!empty($_f['others']); $_fn='gs_f_'.$_fk; $_fid='iq_'.$_slug.'_'.$_fk;
            $_cattr=''; if(is_array($_fcd)&&isset($_fcd['field'],$_fcd['value'])){$_cattr=' data-sif="gs_f_'.esc_attr($_fcd['field']).'" data-siv="'.esc_attr($_fcd['value']).'" data-sio="'.esc_attr($_fcd['op']??'equals').'"';}
          ?>
          <?php echo render_iq_field($_fid,$_fn,$_fl,$_ft,!empty($_f['required']),$_fo,$_fph,$_fhp,$_cattr,$_fothers,$_f,$_slug); ?>
          <?php endforeach; ?>
          <div class="iq-nav" style="border-top:none;padding-top:0;margin-top:16px">
            <div style="flex:1"></div>
            <button type="button" class="iq-btn iq-btn-p" onclick="iqNx('<?php echo esc_js($_slug);?>',1,<?php echo (int) $_max_step; ?>)">
              Continue &#8594;
            </button>
          </div>
        </div>

        <!-- STEP 2: More Details (remaining category-specific fields) -->
        <div class="iq-step" id="iq-s2-<?php echo esc_attr($_slug); ?>" data-empty="<?php echo !empty($_step_empty[2])?'1':'0'; ?>" data-role="field-step" data-title="More Details" style="display:none">
          <button type="button" class="iq-back-arrow" onclick="iqBk('<?php echo esc_js($_slug);?>',2)"
                  title="Go back" aria-label="Go back to previous step">&#8592;</button>
          <?php if(!empty($_s2_extra)): foreach($_s2_extra as $_f):
            $_fk=$_f['key']??''; $_fl=$_f['label']??''; $_ft=$_f['type']??'text';
            $_req=!empty($_f['required']); $_fo=array_values($_f['options']??[]);
            $_fcd=$_f['cond']??null; $_fph=$_f['ph']??$_fl; $_fhp=$_f['help']??'';
            $_fothers=!empty($_f['others']); $_fn='gs_f_'.$_fk; $_fid='iq_x_'.$_slug.'_'.$_fk;
            $_cattr=''; if(is_array($_fcd)&&isset($_fcd['field'],$_fcd['value'])){$_cattr=' data-sif="gs_f_'.esc_attr($_fcd['field']).'" data-siv="'.esc_attr($_fcd['value']).'" data-sio="'.esc_attr($_fcd['op']??'equals').'"';}
          ?>
          <?php echo render_iq_field($_fid,$_fn,$_fl,$_ft,!empty($_f['required']),$_fo,$_fph,$_fhp,$_cattr,$_fothers,$_f,$_slug); ?>
          <?php endforeach; else: ?>
          <p style="font-size:.84rem;color:#64748B;padding:12px 0">All service details captured — please continue.</p>
          <?php endif; ?>
          <div class="iq-nav" style="border-top:none;padding-top:0;margin-top:16px">
            <div style="flex:1"></div>
            <button type="button" class="iq-btn iq-btn-p" onclick="iqNx('<?php echo esc_js($_slug);?>',2,<?php echo (int) $_max_step; ?>)">
              Continue &#8594;
            </button>
          </div>
        </div>

        <?php foreach ($_dynamic_groups as $_dgi => $_dg): $_gs = $_dg['step']; $_is_last_group = ($_dgi === count($_dynamic_groups) - 1); ?>
        <!-- Dynamic step: <?php echo esc_html($_dg['title']); ?> (registry-driven, not hardcoded) -->
        <div class="iq-step" id="iq-s<?php echo $_gs; ?>-<?php echo esc_attr($_slug); ?>" data-empty="<?php echo !empty($_step_empty[$_gs])?'1':'0'; ?>" data-role="field-step" data-title="<?php echo esc_attr($_dg['title']); ?>" style="display:none">
          <button type="button" class="iq-back-arrow" onclick="iqBk('<?php echo esc_js($_slug);?>',<?php echo $_gs; ?>)"
                  title="Go back" aria-label="Go back to previous step">&#8592;</button>
          <?php foreach($_dg['fields'] as $_f):
            $_fk=$_f['key']??''; $_fl=$_f['label']??''; $_ft=$_f['type']??'text';
            $_fo=array_values($_f['options']??[]); $_fph=$_f['ph']??$_fl; $_fhp=$_f['help']??'';
            $_fcd=$_f['cond']??null; $_fothers=!empty($_f['others']);
            $_fn='gs_f_'.$_fk; $_fid='iq_grp_'.$_dg['key'].'_'.$_slug.'_'.$_fk;
            $_cattr=''; if(is_array($_fcd)&&isset($_fcd['field'],$_fcd['value'])){$_cattr=' data-sif="gs_f_'.esc_attr($_fcd['field']).'" data-siv="'.esc_attr($_fcd['value']).'" data-sio="'.esc_attr($_fcd['op']??'equals').'"';}
          ?>
          <?php echo render_iq_field($_fid,$_fn,$_fl,$_ft,!empty($_f['required']),$_fo,$_fph,$_fhp,$_cattr,$_fothers,$_f,$_slug); ?>
          <?php endforeach; ?>
          <?php if ($_dg['key'] === 'scheduling'): ?>
          <!-- Part 9.3: Slot picker — shown when preferred_date is picked and vendor has availability set. Tied to the 'scheduling' group specifically, not to a fixed step position. -->
          <div id="iq-slots-<?php echo esc_attr($_slug); ?>" style="display:none;margin:10px 0">
            <div style="font-size:.8rem;font-weight:600;color:#334155;margin-bottom:8px">Available time slots</div>
            <div id="iq-slots-list-<?php echo esc_attr($_slug); ?>" style="display:flex;flex-wrap:wrap;gap:8px">
              <!-- populated by JS -->
            </div>
            <input type="hidden" id="gs_f_time_slot_<?php echo esc_attr($_slug); ?>" name="gs_f_time_slot" value="">
          </div>
          <?php endif; ?>
          <div class="iq-nav" style="border-top:none;padding-top:0;margin-top:16px">
            <div style="flex:1"></div>
            <?php if ($_is_last_group): ?>
            <button type="button" class="iq-btn iq-btn-p" onclick="iqBuildReview('<?php echo esc_js($_slug);?>')">
              Review &amp; Submit &#8594;
            </button>
            <?php else: ?>
            <button type="button" class="iq-btn iq-btn-p" onclick="iqNx('<?php echo esc_js($_slug);?>',<?php echo $_gs; ?>,<?php echo $_max_step; ?>)">
              Continue &#8594;
            </button>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>

        <!-- STEP 5: Review & Submit -->
        <div class="iq-step" id="iq-s<?php echo $_review_step; ?>-<?php echo esc_attr($_slug); ?>" data-empty="<?php echo !empty($_step_empty[$_review_step])?'1':'0'; ?>" data-role="review" style="display:none">
          <button type="button" class="iq-back-arrow" onclick="iqBk('<?php echo esc_js($_slug);?>',<?php echo $_review_step; ?>)"
                  title="Go back" aria-label="Go back to previous step">&#8592;</button>
          <div id="iq-review-<?php echo esc_attr($_slug); ?>"></div>
          <?php if($min_charge>0): ?>
          <div class="iq-min-charge-notice">
            Note: This vendor charges a minimum visit fee of <strong>&#8377;<?php echo number_format($min_charge,0); ?></strong>. This will apply even if no work is carried out.
          </div>
          <?php endif; ?>
          <?php if ( $_panel_wa_verify ): ?>
          <div class="iq-wa-verify" id="iq-wa-<?php echo esc_attr($_slug); ?>" style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:9px;padding:12px 14px;margin-bottom:12px">
            <div id="iq-wa-step-send-<?php echo esc_attr($_slug); ?>">
              <div style="font-weight:700;font-size:.83rem;color:#166534;margin-bottom:6px">💬 Verify your WhatsApp number (optional)</div>
              <div style="font-size:.78rem;color:#15803D;margin-bottom:8px">This vendor offers faster confirmation for WhatsApp-verified inquiries. You can skip this — email verification will still apply.</div>
              <button type="button" class="iq-btn iq-btn-o" style="font-size:.78rem;padding:7px 14px"
                      onclick="iqWaSendOtp('<?php echo esc_js($_slug);?>')">Send WhatsApp code</button>
              <span id="iq-wa-send-msg-<?php echo esc_attr($_slug); ?>" style="font-size:.76rem;color:#64748B;margin-left:8px"></span>
            </div>
            <div id="iq-wa-step-verify-<?php echo esc_attr($_slug); ?>" style="display:none">
              <div style="font-weight:700;font-size:.83rem;color:#166534;margin-bottom:6px">Enter the 6-digit code sent via WhatsApp</div>
              <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
                <input type="text" inputmode="numeric" maxlength="6" id="iq-wa-otp-<?php echo esc_attr($_slug); ?>"
                       style="width:110px;padding:8px 10px;border:1.5px solid #BBF7D0;border-radius:7px;font-size:1rem;letter-spacing:.1em;text-align:center">
                <button type="button" class="iq-btn iq-btn-p" style="font-size:.78rem;padding:7px 14px"
                        onclick="iqWaVerifyOtp('<?php echo esc_js($_slug);?>')">Verify</button>
                <span id="iq-wa-verify-msg-<?php echo esc_attr($_slug); ?>" style="font-size:.76rem;color:#64748B"></span>
              </div>
            </div>
            <div id="iq-wa-step-done-<?php echo esc_attr($_slug); ?>" style="display:none;font-size:.83rem;color:#166534;font-weight:700">✅ WhatsApp verified</div>
          </div>
          <?php endif; ?>
          <?php
            // Phase 1: Dual CTA — vendor controls whether this category accepts
            // bookings (accepts_booking), shows booking-only (hide_inquiry_cta),
            // and the booking button's custom label (booking_cta).
            // Also gated on the platform-wide ModuleManager booking flag — if an
            // admin disables booking site-wide, the "Book Now" button must not
            // appear even for vendors who previously opted a category in,
            // otherwise customers would fill the whole form only to be rejected
            // by the server-side check in submitBookingFromModule().
            $_accepts_booking = $_panel_accepts_booking;
            $_hide_inquiry    = $_accepts_booking && ! empty( $_mod['hide_inquiry_cta'] );
            $_booking_lbl     = $_mod['booking_cta'] ?? '';
            if ( $_booking_lbl === '' ) {
                $_booking_lbl = $_mod['ctas'][1] ?? 'Book Now';
            }
          ?>
          <div class="iq-nav" style="padding-top:14px">
            <?php if ( ! $_hide_inquiry ): ?>
            <button type="button" class="iq-btn iq-btn-p" style="flex:1"
                    id="iq-inq-btn-<?php echo esc_attr($_slug); ?>"
                    data-cta="<?php echo esc_attr($_cta_lbl); ?>"
                    onclick="iqSubmitForm('<?php echo esc_js($_slug);?>',<?php echo (int)$lid;?>,'inquiry')">
              <span class="iq-btn-txt"><?php echo esc_html($_cta_lbl); ?></span>
              <span class="iq-spinner" style="display:none">&#9696;</span>
            </button>
            <?php endif; ?>
            <?php if ( $_accepts_booking ): ?>
            <button type="button" class="<?php echo $_hide_inquiry ? 'iq-btn iq-btn-p' : 'iq-btn iq-btn-o'; ?>" style="flex:1"
                    id="iq-book-btn-<?php echo esc_attr($_slug); ?>"
                    data-cta="<?php echo esc_attr($_booking_lbl); ?>"
                    onclick="iqSubmitForm('<?php echo esc_js($_slug);?>',<?php echo (int)$lid;?>,'booking')">
              <span class="iq-btn-txt"><?php echo esc_html($_booking_lbl); ?></span>
              <span class="iq-spinner" style="display:none">&#9696;</span>
            </button>
            <?php endif; ?>
          </div>
        </div>
        </div><!-- /#iq-form -->


      </div>
      <?php $fp=false; endforeach; ?>
    </div>
  </div>
</div>
</section>

<script>
/* ── GoodService Inquiry Engine v2 ──────────────────────────────────────── */
(function(){
'use strict';
var _st={};
function gs(s){if(!_st[s])_st[s]={step:1,data:{}};return _st[s];}
window._iqS=_st;

/* ── Module tab switch ─────────────────────────────────────────────────── */
window.iqSw=function(slug){
  document.querySelectorAll('.iq-tab').forEach(function(t){t.classList.remove('active');t.setAttribute('aria-selected','false');});
  document.querySelectorAll('.iq-fp').forEach(function(p){p.classList.remove('active');p.style.display='none';});
  var tb=document.querySelector('.iq-tab[data-target="'+slug+'"]');
  if(tb){tb.classList.add('active');tb.setAttribute('aria-selected','true');}
  var pl=document.getElementById('iq-panel-'+slug);
  if(pl){pl.classList.add('active');pl.style.display='flex';}
  // Lazy init: wire events and run iqCd only on first open
  if(typeof iqEnsureInit==='function') iqEnsureInit(slug); else iqCd(slug);
};

/* ── Conditional ───────────────────────────────────────────────────────── */
// Build a trigger-to-fields map per panel for O(1) lookups
var _iqCdMap={};
function _iqBuildMap(slug){
  var pan=document.getElementById('iq-panel-'+slug);if(!pan)return;
  var map={};
  pan.querySelectorAll('.iq-cond').forEach(function(fg){
    var tf=fg.dataset.sif;if(!tf)return;
    if(!map[tf])map[tf]=[];
    map[tf].push(fg);
  });
  _iqCdMap[slug]=map;
}
// Evaluate visibility for fields triggered by a specific field name (or all if tf not given)
function _iqEval(slug,tf){
  var pan=document.getElementById('iq-panel-'+slug);if(!pan)return;
  if(!_iqCdMap[slug])_iqBuildMap(slug);
  var map=_iqCdMap[slug];
  var keys=tf?[tf]:Object.keys(map);
  keys.forEach(function(k){
    var te=pan.querySelector('[name="'+k+'"],[data-fk="'+k+'"]');
    var cv=te?te.value:'';
    (map[k]||[]).forEach(function(fg){
      var tv=fg.dataset.siv;
      var op=fg.dataset.sio||'equals';
      var show=_iqEvalOp(op,cv,tv);
      fg.style.display=show?'':'none';
      if(!show)fg.querySelectorAll('input,select,textarea').forEach(function(i){i.value='';i.removeAttribute('required');});
    });
  });
}
/* Mirrors InquiryFormService::evaluate_condition() — keep both in sync. */
function _iqEvalOp(op,actual,expected){
  switch(op){
    case 'is_empty':     return actual==='';
    case 'is_not_empty':  return actual!=='';
    case 'not_equals':
      if(expected&&expected.indexOf(',')>=0){
        return expected.split(',').map(function(v){return v.trim();}).indexOf(actual)<0;
      }
      return actual!==expected;
    case 'greater_than':  return parseFloat(actual||0) >  parseFloat(expected||0);
    case 'less_than':     return parseFloat(actual||0) <  parseFloat(expected||0);
    case 'greater_equal': return parseFloat(actual||0) >= parseFloat(expected||0);
    case 'less_equal':    return parseFloat(actual||0) <= parseFloat(expected||0);
    case 'contains':      return !!expected && actual.indexOf(expected)>=0;
    case 'not_contains':  return !expected || actual.indexOf(expected)<0;
    case 'equals':
    default:
      if(expected&&expected.indexOf(',')>=0){
        return expected.split(',').map(function(v){return v.trim();}).indexOf(actual)>=0;
      }
      return (actual===expected)||(expected==='1'&&actual!==''&&actual!=='0');
  }
}
window.iqCd=function(slug,changedField){
  _iqEval(slug,changedField||null);
};

/* ── Radio with Others ─────────────────────────────────────────────────── */
window.iqRad=function(el,fn,slug,othId){
  var g=el.closest('.iq-chips');
  g.querySelectorAll('.iq-chip').forEach(function(c){c.classList.remove('sel');});
  el.classList.add('sel');
  var h=g.querySelector('input[type=hidden]');if(h)h.value=el.dataset.v;
  var oth=document.getElementById(othId);
  if(oth){
    var show=el.dataset.v==='Others'||el.dataset.v.indexOf('Others')===0||el.dataset.v.indexOf('Custom')===0;
    oth.style.display=show?'':'none';
    if(!show){var ta=oth.querySelector('textarea');if(ta){ta.value='';ta.removeAttribute('required');}}
    if(show){var ta=oth.querySelector('textarea');if(ta)ta.setAttribute('required','');}
  }
  iqCd(slug);
};

/* ── Select with Others ─────────────────────────────────────────────────── */
window.iqSelChange=function(sel,othId){
  var oth=document.getElementById(othId);
  if(oth){
    var show=sel.value==='Others'||sel.value.indexOf('Others')===0||sel.value.indexOf('Custom')===0;
    oth.style.display=show?'':'none';
    if(!show){var ta=oth.querySelector('textarea');if(ta){ta.value='';ta.removeAttribute('required');}}
    if(show){var ta=oth.querySelector('textarea');if(ta)ta.setAttribute('required','');}
  }
};

/* ── Multi-select ──────────────────────────────────────────────────────── */
window.iqMul=function(el,fn,cid){
  el.classList.toggle('sel');
  var c=document.getElementById('iq-ms-'+cid);
  if(!c)c=el.closest('.iq-chips').nextElementSibling;
  if(c){
    c.innerHTML='';
    el.closest('.iq-chips').querySelectorAll('.iq-chip.sel').forEach(function(s){
      var i=document.createElement('input');i.type='hidden';i.name=fn+'[]';i.value=s.dataset.v;c.appendChild(i);
    });
  }
};

/* ── Toggle ────────────────────────────────────────────────────────────── */
window.iqTog=function(el,fn,slug){
  el.classList.toggle('on');
  var h=el.parentElement.querySelector('input[type=hidden]');
  if(h)h.value=el.classList.contains('on')?'1':'0';
  iqCd(slug);
};

/* ── Step validation ───────────────────────────────────────────────────── */
function iqVl(slug,stepNum){
  var p=document.getElementById('iq-s'+stepNum+'-'+slug);if(!p)return true;
  var eb=document.getElementById('iq-err-'+slug);if(eb)eb.style.display='none';
  var ok=true;
  p.querySelectorAll('[required]').forEach(function(inp){
    var fg=inp.closest('.iq-fg');if(fg&&fg.style.display==='none')return;
    if(!inp.value.trim()){
      ok=false;inp.style.borderColor='#EF4444';
      var ev=fg?fg.querySelector('.iq-ferr'):null;
      if(ev){ev.style.display='block';ev.textContent='This field is required.';}
    } else {
      inp.style.borderColor='';
      var ev=fg?fg.querySelector('.iq-ferr'):null;
      if(ev)ev.style.display='none';
    }
  });
  // Radio required
  p.querySelectorAll('.iq-chips[data-req="1"]').forEach(function(g){
    var fg=g.closest('.iq-fg');if(fg&&fg.style.display==='none')return;
    var h=g.querySelector('input[type=hidden]');
    if(h&&!h.value){ok=false;var ev=fg?fg.querySelector('.iq-ferr'):null;if(ev){ev.style.display='block';ev.textContent='Please make a selection.';}}
  });
  if(!ok&&eb){eb.style.display='block';eb.textContent='Please fill in all required fields before continuing.';eb.scrollIntoView({behavior:'smooth',block:'nearest'});}
  return ok;
}

/* ── Progress bar update ───────────────────────────────────────────────── */
function iqProg(slug,step){
  for(var i=1;i<=5;i++){
    var d=document.getElementById('iq-pd-'+slug+'-'+i);
    var l=document.getElementById('iq-pl-'+slug+'-'+i);
    if(d){d.classList.remove('act','done');if(i<step)d.classList.add('done');if(i===step)d.classList.add('act');}
    if(l)l.classList.toggle('done',i<step);
  }
}

/* ── Next step ─────────────────────────────────────────────────────────── */
// Real fix: finds the next/previous step for this slug that is NOT
// marked data-empty — the actual mechanism that makes step position
// dynamic per form instead of assuming Scheduling/Contact always sit at
// fixed step numbers.
function iqNextVisible(slug, fromStep, dir) {
  var s = fromStep;
  // Real fix: was hardcoded to a max of 5 steps — silently stopped
  // working past step 5 the instant a third default step category
  // existed. 30 is a generous, safe, non-infinite bound that's
  // practically unlimited for any realistic form.
  for (var i = 0; i < 30; i++) {
    s += dir;
    if (s < 1 || s > 30) return null;
    var el = document.getElementById('iq-s' + s + '-' + slug);
    if (el && el.getAttribute('data-empty') !== '1') return s;
  }
  return null;
}
window.iqNx=function(slug,fromStep,totalSteps){
  if(!iqVl(slug,fromStep))return;
  var next = iqNextVisible(slug, fromStep, 1);
  if (next === null) return;
  var cur=document.getElementById('iq-s'+fromStep+'-'+slug);
  var nxt=document.getElementById('iq-s'+next+'-'+slug);
  if(cur)cur.style.display='none';
  if(nxt)nxt.style.display='';
  gs(slug).step=next;
  iqProg(slug,next);
  iqCd(slug);
  var top=document.getElementById('iq-panel-'+slug);
  if(top)top.scrollIntoView({behavior:'smooth',block:'start'});
};

/* ── Back step ─────────────────────────────────────────────────────────── */
window.iqBk=function(slug,fromStep){
  var prevStep = iqNextVisible(slug, fromStep, -1);
  if (prevStep === null) return;
  var cur=document.getElementById('iq-s'+fromStep+'-'+slug);
  var prv=document.getElementById('iq-s'+prevStep+'-'+slug);
  if(cur)cur.style.display='none';
  if(prv)prv.style.display='';
  gs(slug).step=prevStep;
  iqProg(slug,prevStep);
};

/* ── Jump to step (from progress dot) ─────────────────────────────────── */
window.iqJump=function(slug,toStep){
  var s=gs(slug);
  var tgtEl = document.getElementById('iq-s'+toStep+'-'+slug);
  // Real fix: removed the hardcoded "toStep>5" bound — with more or
  // fewer step categories active, valid step numbers can genuinely be
  // anything. The element-existence and data-empty checks below already
  // correctly validate any target step, for any step count.
  if(toStep>=s.step||toStep<1)return; // can only go back to prior completed step
  if(!tgtEl||tgtEl.getAttribute('data-empty')==='1')return; // real fix: never jump to an empty step
  var cur=document.getElementById('iq-s'+s.step+'-'+slug);
  var tgt=tgtEl;
  if(cur)cur.style.display='none';
  if(tgt)tgt.style.display='';
  s.step=toStep;
  iqProg(slug,toStep);
};

/* ── Edit link from review — jump directly to a specific step ──────────── */
window.iqJumpEdit=function(slug,toStep,fromStep){
  var cur=document.getElementById('iq-s'+fromStep+'-'+slug);
  var tgt=document.getElementById('iq-s'+toStep+'-'+slug);
  if(cur)cur.style.display='none';
  if(tgt)tgt.style.display='';
  gs(slug).step=toStep;
  iqProg(slug,toStep);
  var top=document.getElementById('iq-panel-'+slug);
  if(top)top.scrollIntoView({behavior:'smooth',block:'start'});
};

// Real fix: if Step 1 itself is empty for some category (e.g. a form with
// zero of its own fields), auto-advance to the first genuinely non-empty
// step on load rather than showing a blank first screen.
document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('.iq-step[id^="iq-s1-"]').forEach(function(step1){
    if (step1.getAttribute('data-empty') !== '1') return;
    var slug = step1.id.replace('iq-s1-', '');
    var next = iqNextVisible(slug, 1, 1);
    if (next === null) return;
    step1.style.display = 'none';
    var tgt = document.getElementById('iq-s' + next + '-' + slug);
    if (tgt) tgt.style.display = '';
    if (window.gs) { gs(slug).step = next; }
    if (window.iqProg) { iqProg(slug, next); }
  });
});

/* ── Optional WhatsApp verification (Section 2 of inquiry/booking audit) ── */
window.iqWaSendOtp=function(slug){
  var panel=document.getElementById('iq-panel-'+slug);
  var phoneField=panel?panel.querySelector('input[name="phone"], input[id*="phone"], input[type="tel"]'):null;
  var phone=phoneField?phoneField.value.trim():'';
  var msgEl=document.getElementById('iq-wa-send-msg-'+slug);
  if(!phone){ if(msgEl)msgEl.textContent='Please enter your phone number in Step 2 first.'; return; }
  if(msgEl){msgEl.style.color='#64748B';msgEl.textContent='Sending…';}
  var lid=(panel.dataset.listingId)||'';
  gsPost('gs_send_whatsapp_verify_otp',{listing_id:lid,inquiry_module:slug,phone:phone},function(d){
    document.getElementById('iq-wa-step-send-'+slug).style.display='none';
    document.getElementById('iq-wa-step-verify-'+slug).style.display='';
  },function(m){
    if(msgEl){msgEl.style.color='#DC2626';msgEl.textContent=m||'Could not send code.';}
  });
};
window.iqWaVerifyOtp=function(slug){
  var panel=document.getElementById('iq-panel-'+slug);
  var phoneField=panel?panel.querySelector('input[name="phone"], input[id*="phone"], input[type="tel"]'):null;
  var phone=phoneField?phoneField.value.trim():'';
  var otpEl=document.getElementById('iq-wa-otp-'+slug);
  var msgEl=document.getElementById('iq-wa-verify-msg-'+slug);
  var otp=otpEl?otpEl.value.trim():'';
  if(!otp){ if(msgEl){msgEl.style.color='#DC2626';msgEl.textContent='Enter the code.';} return; }
  gsPost('gs_verify_whatsapp_otp',{phone:phone,otp:otp},function(d){
    window['_iqWaToken_'+slug]=d.whatsapp_verify_token||'';
    document.getElementById('iq-wa-step-verify-'+slug).style.display='none';
    document.getElementById('iq-wa-step-done-'+slug).style.display='';
  },function(m){
    if(msgEl){msgEl.style.color='#DC2626';msgEl.textContent=m||'Invalid code.';}
  });
};

/* ── Build review summary ──────────────────────────────────────────────── */
window.iqBuildReview=function(slug){
  var panel=document.getElementById('iq-panel-'+slug);
  if(!panel)return;
  // Real fix: discover every genuinely visible field-step for this form,
  // in DOM order, instead of assuming there are always exactly 4 at
  // fixed step numbers 1-4. A step marked data-empty is skipped, exactly
  // like iqNx/iqBk/iqJump already do.
  var fieldSteps=[];
  panel.querySelectorAll('.iq-step[data-role="field-step"]').forEach(function(el){
    if(el.getAttribute('data-empty')==='1')return;
    var m=el.id.match(/^iq-s(\d+)-/);
    fieldSteps.push({ step: m?parseInt(m[1],10):0, id: el.id, title: el.getAttribute('data-title')||'Details' });
  });
  var reviewEl=panel.querySelector('.iq-step[data-role="review"]');
  if(!reviewEl)return;
  var reviewM=reviewEl.id.match(/^iq-s(\d+)-/);
  var reviewStep=reviewM?parseInt(reviewM[1],10):0;

  // Validate the true LAST visible field-step before review — not a
  // hardcoded "step 4" — since with fewer or more active groups this
  // could genuinely be any step number.
  var lastFieldStep=fieldSteps.length?fieldSteps[fieldSteps.length-1].step:0;
  if(lastFieldStep && !iqVl(slug,lastFieldStep))return;

  var rev=document.getElementById('iq-review-'+slug);
  if(!rev)return;

  var html='';
  fieldSteps.forEach(function(g){
    var stepEl=document.getElementById(g.id);if(!stepEl)return;
    var rows='';
    stepEl.querySelectorAll('[data-fk]').forEach(function(inp){
      var fg=inp.closest('.iq-fg');if(fg&&fg.style.display==='none')return;
      var v=inp.value;if(!v||v==='0')return;
      var label=inp.placeholder||inp.getAttribute('aria-label')||inp.name||'';
      label=label.replace(/\s*\*$/,'').replace(/gs_f_/,'').replace(/_/g,' ');
      if(Array.isArray(v))v=v.join(', ');
      if(inp.type==='range')v='&#8377;'+parseInt(v).toLocaleString('en-IN');
      rows+='<div class="iq-review-row"><span class="iq-review-lbl">'+label+'</span><span class="iq-review-val">'+v+'</span></div>';
    });
    // Collect hidden multi-select
    stepEl.querySelectorAll('[id^="iq-ms-"]').forEach(function(ms){
      var vals=[];ms.querySelectorAll('input[type=hidden]').forEach(function(h){if(h.value)vals.push(h.value);});
      if(!vals.length)return;
      var label=ms.previousElementSibling?ms.previousElementSibling.textContent:'';
      rows+='<div class="iq-review-row"><span class="iq-review-lbl">'+label+'</span><span class="iq-review-val">'+vals.join(', ')+'</span></div>';
    });
    if(!rows)return;
    html+='<div class="iq-review-group">';
    html+='<div class="iq-review-title">'+g.title+' <span class="iq-review-edit" onclick="iqJumpEdit(\''+slug+'\','+g.step+','+reviewStep+')">Edit</span></div>';
    html+=rows+'</div>';
  });
  rev.innerHTML=html||'<p style="color:#94A3B8;font-size:.82rem">No data to display.</p>';

  // Hide the last field-step, show Review — using the actual discovered
  // step numbers, not hardcoded 4/5.
  if(lastFieldStep){ var cur=document.getElementById('iq-s'+lastFieldStep+'-'+slug); if(cur)cur.style.display='none'; }
  reviewEl.style.display='';
  gs(slug).step=reviewStep;
  iqProg(slug,reviewStep);
  var top=document.getElementById('iq-panel-'+slug);
  if(top)top.scrollIntoView({behavior:'smooth',block:'start'});
};

/* ── Form submission ───────────────────────────────────────────────────── */
window.iqSubmitForm=function(slug,lid,type){
  var iqBtn=document.getElementById('iq-inq-btn-'+slug);
  var bkBtn=document.getElementById('iq-book-btn-'+slug);
  var eb=document.getElementById('iq-err-'+slug);
  var activeBtn=type==='booking'?bkBtn:iqBtn;
  var otherBtn =type==='booking'?iqBtn:bkBtn;

  // Disable both buttons to prevent double submission
  [iqBtn,bkBtn].forEach(function(b){if(b)b.disabled=true;});
  if(activeBtn){
    var t=activeBtn.querySelector('.iq-btn-txt');var s=activeBtn.querySelector('.iq-spinner');
    if(t)t.textContent='Sending\u2026';if(s)s.style.display='inline';
  }
  if(eb)eb.style.display='none';

  // Safety timeout: re-enable after 30s if no response
  var _safetyTimer=setTimeout(function(){
    [iqBtn,bkBtn].forEach(function(b){if(b)b.disabled=false;});
    if(activeBtn){
      var t=activeBtn.querySelector('.iq-btn-txt');var s=activeBtn.querySelector('.iq-spinner');
      if(t)t.textContent=activeBtn.dataset.cta||'Submit';if(s)s.style.display='none';
    }
    if(otherBtn){
      var t=otherBtn.querySelector('.iq-btn-txt');if(t)t.textContent=otherBtn.dataset.cta||'Submit';
    }
    if(eb){eb.style.display='block';eb.textContent='Request timed out. Please try again.';}
  },30000);

  var panel=document.getElementById('iq-panel-'+slug);

  // Phase 1: booking requires a selected date + time slot before submission.
  if(type==='booking'){
    var dateInp = panel.querySelector('input[type="date"][name="gs_f_preferred_date"], input[type="date"]');
    var slotHidden = document.getElementById('gs_f_time_slot_'+slug);
    if(!dateInp || !dateInp.value){
      if(eb){eb.style.display='block';eb.textContent='Please select a preferred date to see available time slots.';}
      [iqBtn,bkBtn].forEach(function(b){if(b)b.disabled=false;});
      if(activeBtn){var t=activeBtn.querySelector('.iq-btn-txt');var s=activeBtn.querySelector('.iq-spinner');if(t)t.textContent=activeBtn.dataset.cta||'Submit';if(s)s.style.display='none';}
      clearTimeout(_safetyTimer);
      return;
    }
    if(!slotHidden || !slotHidden.value){
      if(eb){eb.style.display='block';eb.textContent='Please select an available time slot to continue.';}
      [iqBtn,bkBtn].forEach(function(b){if(b)b.disabled=false;});
      if(activeBtn){var t=activeBtn.querySelector('.iq-btn-txt');var s=activeBtn.querySelector('.iq-spinner');if(t)t.textContent=activeBtn.dataset.cta||'Submit';if(s)s.style.display='none';}
      clearTimeout(_safetyTimer);
      return;
    }
  }

  var fd=new FormData();
  fd.append('action', type==='booking' ? 'gs_submit_booking_from_module' : 'gs_submit_inquiry');
  // Use AJX (defined in vendor-site.php) or fall back to ajaxurl or wp-admin path
  var _ajaxUrl=(typeof AJX!=='undefined'&&AJX)?AJX:(typeof ajaxurl!=='undefined'?ajaxurl:'/wp-admin/admin-ajax.php');
  fd.append('nonce',typeof NONCE!=='undefined'?NONCE:(window.gs_nonce||''));
  fd.set('listing_id', panel.dataset.listingId || String(lid));
  fd.set('vendor_id', panel.dataset.vendorId || '');
  fd.append('inquiry_module',slug);
  fd.append('inquiry_type',type);
  if(type==='booking'){
    var dateInp2 = panel.querySelector('input[type="date"][name="gs_f_preferred_date"], input[type="date"]');
    var slotHidden2 = document.getElementById('gs_f_time_slot_'+slug);
    fd.set('booking_date', dateInp2 ? dateInp2.value : '');
    fd.set('booking_time', slotHidden2 ? slotHidden2.value : '');
  }
  // Optional WhatsApp verification token, if the customer completed that step.
  // Not currently read server-side — WhatsAppVerificationService::mark_lead_verified()
  // matches by phone number + recency instead (see its docblock). Sent anyway
  // so a future tighter token-based check can be added without a client change.
  var waToken = window['_iqWaToken_'+slug];
  if (waToken) { fd.append('whatsapp_verify_token', waToken); }

  // Collect ALL fields across all steps
  panel.querySelectorAll('[name]').forEach(function(inp){
    if(!inp.name)return;
    if(inp.name==='listing_id'||inp.name==='vendor_id')return; // already set above from data-attrs
    if(inp.id&&inp.id.indexOf('iq-co-')===0&&inp.type==='checkbox')return;
    if(inp.type==='file')return;
    var cond=inp.closest('.iq-cond');
    if(cond&&cond.style.display==='none')return;
    fd.append(inp.name,inp.value);
  });
  // Hidden multi-select
  panel.querySelectorAll('[id^="iq-ms-"]').forEach(function(ms){
    ms.querySelectorAll('input[type=hidden]').forEach(function(h){if(h.name&&h.value)fd.append(h.name,h.value);});
  });
  var hp=panel.querySelector('[name="gs_hp_field"]');if(hp)fd.set('gs_hp_field',hp.value);

  fetch(_ajaxUrl,{method:'POST',body:fd})
    .then(function(r){return r.json();})
    .then(function(d){
      clearTimeout(_safetyTimer);
      if(d.success){
        // Full confirmation screen
        var formEl=document.getElementById('iq-form-'+slug);
        if(formEl){
          // Part 11.2 — Rich confirmation screen
        var ref = d.data&&d.data.lead_id ? 'INQ-'+String(d.data.lead_id).padStart(5,'0') : '';
        var vendorName = formEl.closest('[data-vendor-name]')?.dataset.vendorName || 'the vendor';
        var avgReply = formEl.closest('[data-avg-reply]')?.dataset.avgReply || '1–3 hours';
        var trackingUrl = (type==='booking' && d.data && d.data.tracking_url) ? d.data.tracking_url : '';
        var justLoggedIn = !!(d.data && d.data.logged_in && d.data.auto_login_message);
        // Architecture change: verification is a trust badge (shown on the
        // dashboard and in the vendor's inbox), not a submission-time gate —
        // the vendor already has this lead the moment it was submitted (see
        // AjaxController::submitInquiry()/submitBookingFromModule()). This
        // screen always shows immediately; if an email was given, needs_verify
        // tells the customer their next step (completed on /my-account/, not here).
        var needsVerify = !!(d.data && d.data.needs_verify);
        var redirectUrl = (d.data && d.data.redirect_url) || '/my-account/';

        formEl.innerHTML='<div class="iq-ok">'
          +'<div class="iq-ok-ic">'+(type==='booking'?'\uD83D\uDCC5':'\u2705')+'</div>'
          +'<h3 class="iq-ok-h">'+(type==='booking'?'Booking Confirmed!':'Inquiry Sent!')+'</h3>'
          +(ref?'<div class="iq-ok-ref">Reference: '+ref+'</div>':'')
          +'<p style="color:#64748B;font-size:.85rem;margin:8px 0 4px;line-height:1.5">'+(type==='booking'?'Your booking request has been sent to <strong>':'Your inquiry has been sent to <strong>')+String(vendorName).replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</strong>. They typically reply within <strong>'+String(avgReply).replace(/&/g,'&amp;')+'</strong>.</p>'
          +(justLoggedIn?'<p style="background:#EFF6FF;color:#1E40AF;font-size:.78rem;padding:8px 12px;border-radius:7px;margin:0 0 10px">\uD83D\uDC64 '+String(d.data.auto_login_message).replace(/&/g,'&amp;')+'</p>':'')
          +(needsVerify?'<p style="background:#FFFBEB;color:#92400E;font-size:.78rem;padding:8px 12px;border-radius:7px;margin:0 0 14px">\u2728 Taking you to your account to verify your email — this upgrades your inquiry to a <strong>Verified Inquiry</strong> badge.</p>':'')
          +'<p id="iq-redirect-msg" style="color:#94A3B8;font-size:.8rem;margin:0 0 14px">Redirecting to your account…</p>'
          +(trackingUrl?'<a href="'+trackingUrl+'" style="display:inline-block;background:#059669;color:#fff;border-radius:7px;padding:9px 18px;font-size:.84rem;font-weight:600;text-decoration:none;margin-right:8px">Track this booking</a>':'')
          +'<a href="'+redirectUrl+'" style="display:inline-block;background:#2563EB;color:#fff;border-radius:7px;padding:9px 18px;font-size:.84rem;font-weight:600;text-decoration:none">Go now →</a>'
          +'</div>';

        // Land on the dashboard automatically, per the requested flow — a
        // short delay lets the customer actually read the confirmation
        // (reference number, reply-time estimate) before the page changes.
        setTimeout(function(){ window.location.href = redirectUrl; }, 2200);

        // Phase 9 — A2HS prompt after first booking (fires before the redirect
        // above completes; harmless if the redirect happens first, since it's
        // a one-time localStorage-gated prompt that will simply show again on
        // the next booking if it never got to display here).
        if (type === 'booking' && !localStorage.getItem('gs_a2hs_dismissed')) {
          setTimeout(function(){ gsShowA2HS(); }, 800);
        }
        }
      } else {
        if(eb){eb.style.display='block';eb.textContent=(d.data&&d.data.message)?d.data.message:'Submission failed. Please try again.';}
        // Re-enable both buttons on error
        [iqBtn,bkBtn].forEach(function(b){
          if(!b)return;
          b.disabled=false;
          var t=b.querySelector('.iq-btn-txt');var s=b.querySelector('.iq-spinner');
          if(t)t.textContent=b.dataset.cta||'Submit';if(s)s.style.display='none';
        });
      }
    })
    .catch(function(err){
      clearTimeout(_safetyTimer);
      if(eb){eb.style.display='block';eb.textContent='Network error — please check your connection and try again.';}
      [iqBtn,bkBtn].forEach(function(b){
        if(!b)return;
        b.disabled=false;
        var t=b.querySelector('.iq-btn-txt');var s=b.querySelector('.iq-spinner');
        if(t)t.textContent=b.dataset.cta||'Submit';if(s)s.style.display='none';
      });
    });
};

/* ── File upload ───────────────────────────────────────────────────────── */
window.iqFileChange=function(input,baseId){
  var thumbs=document.getElementById(baseId+'_thumbs');
  var bar=document.getElementById(baseId+'_bar');
  if(!thumbs)return;
  var files=Array.from(input.files).slice(0,5);
  thumbs.innerHTML='';
  if(bar){bar.style.width='0';bar.style.display='block';}
  var loaded=0;
  files.forEach(function(f){
    if(f.type.startsWith('image/')){
      var img=document.createElement('img');img.className='iq-thumb';
      var reader=new FileReader();
      reader.onload=function(e){img.src=e.target.result;loaded++;if(bar)bar.style.width=Math.round(loaded/files.length*100)+'%';};
      reader.readAsDataURL(f);thumbs.appendChild(img);
    } else {
      var sp=document.createElement('span');sp.className='iq-file-name';sp.textContent=f.name;thumbs.appendChild(sp);
      loaded++;if(bar)bar.style.width=Math.round(loaded/files.length*100)+'%';
    }
  });
  setTimeout(function(){if(bar)bar.style.display='none';},800);
};
window.iqFileDrop=function(e,baseId){
  e.preventDefault();e.currentTarget.classList.remove('drag');
  var zone=e.currentTarget;var inp=document.getElementById(baseId+'_inp');
  if(inp&&e.dataTransfer.files.length){
    var dt=new DataTransfer();
    Array.from(e.dataTransfer.files).slice(0,5).forEach(function(f){dt.items.add(f);});
    inp.files=dt.files;iqFileChange(inp,baseId);
  }
};

/* ── Wire change events for conditionals ──────────────────────────────── */
document.addEventListener('DOMContentLoaded',function(){
  // Build maps first, then wire targeted change events
  document.querySelectorAll('[id^="iq-panel-"]').forEach(function(p){
    var slug=p.id.replace('iq-panel-','');
    _iqBuildMap(slug);
  });
  // Wire each trigger input to call iqCd with just that field name
  var _wired={};
  document.querySelectorAll('[data-sif]').forEach(function(fg){
    var tf=fg.dataset.sif;
    if(_wired[tf])return; _wired[tf]=true;
    document.querySelectorAll('[name="'+tf+'"],[data-fk="'+tf+'"]').forEach(function(inp){
      inp.addEventListener('change',function(){
        var panel=inp.closest('[id^="iq-panel-"]');if(!panel)return;
        iqCd(panel.id.replace('iq-panel-',''),tf);
      });
    });
  });
  // Init: evaluate all panels fully once
  document.querySelectorAll('.iq-fp.active').forEach(function(p){p.style.display='flex';});
  document.querySelectorAll('[id^="iq-panel-"]').forEach(function(p){iqCd(p.id.replace('iq-panel-',''));});
  // Blur validation
  document.querySelectorAll('.iq-inp,.iq-sel,.iq-ta').forEach(function(inp){
    inp.addEventListener('blur',function(){
      if(inp.required&&!inp.value.trim()){
        inp.style.borderColor='#EF4444';
        var fg=inp.closest('.iq-fg');
        var ev=fg?fg.querySelector('.iq-ferr'):null;
        if(ev){ev.style.display='block';ev.textContent='This field is required.';}
      }
    });
    inp.addEventListener('input',function(){
      if(inp.value.trim())inp.style.borderColor='';
    });
  });
});
}());
</script>

<script>
// Part 9.3 — Available Slot Picker (Phase 1 fix: selector + AJAX URL corrected)
(function(){
  document.addEventListener('change', function(e){
    var inp = e.target;
    if (!inp || inp.type !== 'date') return;
    var panel = inp.closest('[id^="iq-panel-"]');
    if (!panel) return;
    var slug = panel.id.replace('iq-panel-','');
    var date = inp.value;
    if (!date) return;
    // Only fetch slots for categories the vendor has marked bookable
    if (panel.dataset.acceptsBooking !== '1') return;
    var listingId = panel.dataset.listingId;
    if (!listingId || listingId === '0') return;
    var wrap = document.getElementById('iq-slots-'+slug);
    var list = document.getElementById('iq-slots-list-'+slug);
    var hidden = document.getElementById('gs_f_time_slot_'+slug);
    if (!wrap || !list) return;
    list.innerHTML = '<span style="font-size:.78rem;color:#94A3B8">Loading slots…</span>';
    wrap.style.display = 'block';
    if (hidden) hidden.value = ''; // reset selection when date changes
    var fd = new FormData();
    fd.append('action','gs_get_available_slots');
    fd.append('date', date);
    fd.append('listing_id', listingId);
    var ajUrl = (typeof AJX!=='undefined'&&AJX)?AJX:(typeof ajaxurl!=='undefined'?ajaxurl:'/wp-admin/admin-ajax.php');
    fetch(ajUrl,{method:'POST',credentials:'same-origin',body:fd})
      .then(function(r){return r.json();})
      .then(function(j){
        if(!j.success||!j.data||!j.data.slots||!j.data.slots.length){
          wrap.style.display='block';
          list.innerHTML='<span style="font-size:.78rem;color:#94A3B8">'+((j.data&&j.data.message)?j.data.message:'No slots available for this date.')+'</span>';
          return;
        }
        list.innerHTML='';
        j.data.slots.forEach(function(s){
          var b=document.createElement('button');
          b.type='button'; b.textContent=s.label;
          b.style.cssText='padding:6px 12px;border-radius:20px;font-size:.78rem;cursor:pointer;border:1.5px solid '+(s.available?'#2563EB':'#E2E8F0')+';background:'+(s.available?'#EFF6FF':'#F8FAFC')+';color:'+(s.available?'#1D4ED8':'#94A3B8');
          if(!s.available){b.disabled=true;}
          else{b.onclick=function(){list.querySelectorAll('button').forEach(function(x){x.style.background='#EFF6FF';x.style.color='#1D4ED8';x.style.fontWeight='normal';x.style.borderColor='#2563EB';});b.style.background='#2563EB';b.style.color='#fff';b.style.fontWeight='700';if(hidden)hidden.value=s.time;};};
          list.appendChild(b);
        });
        wrap.style.display='block';
      })
      .catch(function(){wrap.style.display='none';});
  });
})();
</script>
<?php if ( \GoodService\Core\Config::get( 'booking_otp_enabled', '0' ) === '1' ): ?>
<script>
// ── Phase 10: OTP gate for booking submissions ────────────────────────────────
// When booking_otp_enabled is on, intercept the "Book Now" click, show an OTP
// verification modal, and only call the real iqSubmitForm after the phone is
// confirmed. Inquiry ("Send Message") submissions are never gated by OTP.
(function(){
  var _nonce = '<?php echo esc_js( wp_create_nonce( 'gs_ajax' ) ); ?>';
  var _ajaxUrl = '<?php echo esc_js( admin_url( "admin-ajax.php" ) ); ?>';
  var _otpVerified = {}; // keyed by slug — tracks verified state per panel

  // Intercept all booking buttons after DOM ready
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('[id^="iq-book-btn-"]').forEach(function(btn) {
      var slug = btn.id.replace('iq-book-btn-','');
      btn.onclick = null;
      btn.addEventListener('click', function(e) {
        e.stopImmediatePropagation();
        if (_otpVerified[slug]) {
          // Already verified this session — proceed directly
          iqSubmitForm(slug, parseInt(btn.closest('[data-lid]')&&btn.closest('[data-lid]').dataset.lid||0), 'booking');
          return;
        }
        // Find phone field in this panel
        var panel = btn.closest('.iq-panel') || btn.closest('[id^="iq-panel-"]') || document.body;
        var phoneField = panel.querySelector('input[name="phone"], input[id*="phone"], input[type="tel"]');
        var phone = phoneField ? phoneField.value.trim() : '';
        var emailField = panel.querySelector('input[name="email"], input[id*="email"], input[type="email"]');
        var email = emailField ? emailField.value.trim() : '';

        if (!phone || phone.replace(/\D/g,'').length < 10) {
          alert('Please enter your phone number first so we can send you a verification code.');
          if(phoneField) phoneField.focus();
          return;
        }

        gsShowOtpModal(slug, phone, email, function() {
          _otpVerified[slug] = true;
          var lid = parseInt((btn.closest('[data-lid]')||{dataset:{}}).dataset.lid||0);
          iqSubmitForm(slug, lid, 'booking');
        });
      });
    });
  });

  window.gsShowOtpModal = function(slug, phone, email, onSuccess) {
    // Inject OTP modal into DOM (removed after use)
    var overlay = document.createElement('div');
    overlay.id = 'gs-otp-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99999;display:flex;align-items:center;justify-content:center;padding:16px';
    // Intro text is intentionally generic ("we'll send you a code") rather than
    // naming a specific channel, since the server decides SMS vs. email
    // fallback based on whether an SMS gateway is configured — the modal
    // can't know that in advance. The actual channel used is confirmed in
    // the status message once the send succeeds (see sendBtn handler below).
    overlay.innerHTML = '<div style="background:#fff;border-radius:16px;padding:28px;max-width:360px;width:100%;text-align:center">'
      + '<div style="font-size:1.5rem;margin-bottom:10px">🔐</div>'
      + '<div style="font-weight:800;font-size:1rem;margin-bottom:6px">Verify to continue</div>'
      + '<div style="font-size:.84rem;color:#64748B;margin-bottom:' + (email ? '16px' : '10px') + '">We\'ll send a 6-digit verification code to confirm it\\u2019s really you.</div>'
      + (email ? '' : '<div style="font-size:.78rem;color:#DC2626;margin-bottom:14px">No email on file for this booking \\u2014 please <a href="#" onclick="document.getElementById(\'gs-otp-overlay\').remove();return false;" style="color:#2563EB;text-decoration:underline">go back and add your email</a> so we have somewhere to send the code.</div>')
      + '<div id="gs-otp-msg" style="font-size:.8rem;margin-bottom:10px;min-height:20px"></div>'
      + '<input id="gs-otp-input" type="text" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" placeholder="Enter 6-digit code"'
      + ' style="width:100%;border:2px solid #E2E8F0;border-radius:10px;padding:12px;font-size:1.1rem;text-align:center;letter-spacing:.3em;outline:none;margin-bottom:12px;box-sizing:border-box" disabled>'
      + '<button id="gs-otp-send" style="width:100%;background:#2563EB;color:#fff;border:none;border-radius:10px;padding:12px;font-size:.9rem;font-weight:700;cursor:pointer;margin-bottom:8px"' + (email ? '' : ' disabled') + '>Send Code</button>'
      + '<button id="gs-otp-verify" style="width:100%;background:#059669;color:#fff;border:none;border-radius:10px;padding:12px;font-size:.9rem;font-weight:700;cursor:pointer;display:none;margin-bottom:8px">Verify & Continue →</button>'
      + '<button onclick="document.getElementById(\'gs-otp-overlay\').remove()" style="background:none;border:none;color:#94A3B8;font-size:.8rem;cursor:pointer;margin-top:4px">Cancel</button>'
      + '</div>';
    document.body.appendChild(overlay);


    var msgEl   = document.getElementById('gs-otp-msg');
    var input   = document.getElementById('gs-otp-input');
    var sendBtn = document.getElementById('gs-otp-send');
    var verBtn  = document.getElementById('gs-otp-verify');

    function postOtp(action, data, cb) {
      var fd = new FormData();
      fd.append('action', action); fd.append('nonce', _nonce);
      Object.keys(data).forEach(function(k){ fd.append(k, data[k]); });
      fetch(_ajaxUrl, {method:'POST',body:fd,credentials:'same-origin'})
        .then(function(r){return r.json();}).then(cb)
        .catch(function(){msgEl.style.color='#DC2626';msgEl.textContent='Network error. Please try again.';});
    }

    sendBtn.addEventListener('click', function() {
      sendBtn.disabled = true; sendBtn.textContent = 'Sending…';
      msgEl.style.color = '#64748B'; msgEl.textContent = '';
      postOtp('gs_send_otp', {phone: phone, email: email, purpose: 'booking'}, function(r) {
        sendBtn.disabled = false; sendBtn.textContent = 'Resend Code';
        if (r && r.success) {
          msgEl.style.color = '#059669';
          msgEl.textContent = r.data.message || 'Code sent! Check your ' + (r.data.channel==='email'?'email':'phone') + '.';
          input.disabled = false; input.focus();
          verBtn.style.display = 'block';
        } else {
          msgEl.style.color = '#DC2626';
          msgEl.textContent = (r&&r.data&&r.data.message) || 'Failed to send OTP.';
        }
      });
    });

    verBtn.addEventListener('click', function() {
      var code = input.value.trim();
      if (code.length !== 6) { msgEl.style.color='#DC2626'; msgEl.textContent='Enter the 6-digit code.'; return; }
      verBtn.disabled = true; verBtn.textContent = 'Verifying…';
      postOtp('gs_verify_otp', {phone: phone, code: code}, function(r) {
        if (r && r.success) {
          overlay.remove();
          onSuccess();
        } else {
          verBtn.disabled = false; verBtn.textContent = 'Verify & Continue →';
          msgEl.style.color = '#DC2626';
          msgEl.textContent = (r&&r.data&&r.data.message) || 'Invalid OTP.';
          input.value = ''; input.focus();
        }
      });
    });

    // Auto-submit on 6 digits
    input.addEventListener('input', function() {
      if (input.value.replace(/\D/g,'').length === 6) { verBtn.click(); }
    });
  };
})();
</script>
<?php endif; ?>

<script>
// ── Phase 9: Offline detection + booking retry notification ───────────────────
(function(){
  // Offline/online banner
  var banner = null;
  function showOfflineBanner() {
    if (banner) return;
    banner = document.createElement('div');
    banner.style.cssText = 'position:fixed;top:0;left:0;right:0;background:#1E3A5F;color:#fff;text-align:center;'
      + 'padding:10px;font-size:.82rem;font-weight:600;z-index:99999';
    banner.textContent = '📶 You are offline. Bookings will be saved and submitted when you reconnect.';
    document.body.prepend(banner);
  }
  function hideOfflineBanner() {
    if (banner) { banner.remove(); banner = null; }
  }
  window.addEventListener('offline', showOfflineBanner);
  window.addEventListener('online',  function() {
    hideOfflineBanner();
    if (typeof gsToast === 'function') gsToast('Back online! Submitting any pending bookings…', 'info');
  });
  if (!navigator.onLine) showOfflineBanner();

  // Listen for SW sync completion
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('message', function(event) {
      if (event.data && event.data.type === 'GS_BOOKING_SYNCED') {
        var n = event.data.count;
        if (typeof gsToast === 'function') {
          gsToast('✅ ' + n + ' booking' + (n > 1 ? 's' : '') + ' submitted successfully!', 'success');
        }
      }
    });
  }
})();
</script>

<script>
// ── Phase 9: Add to Home Screen (A2HS) PWA prompt ─────────────────────────────
// Capture the browser's deferred install prompt globally. The prompt can only
// be shown in response to a user gesture, so we store it and show a custom
// banner UI at the right moment (after first booking confirmation).
(function(){
  var _deferredA2HS = null;

  window.addEventListener('beforeinstallprompt', function(e) {
    e.preventDefault(); // Prevent default mini-info bar
    _deferredA2HS = e;  // Stash for later use
  });

  window.gsShowA2HS = function() {
    // Don't show if: already dismissed recently, already installed, or browser
    // doesn't support installation
    if (localStorage.getItem('gs_a2hs_dismissed')) { return; }
    if (window.matchMedia('(display-mode: standalone)').matches) { return; }

    var platform = '<?php echo esc_js(gs_setting("platform_name","GoodService")); ?>';

    // Build the prompt banner
    var banner = document.createElement('div');
    banner.id  = 'gs-a2hs-banner';
    banner.style.cssText = 'position:fixed;bottom:16px;left:16px;right:16px;background:#1E3A5F;color:#fff;'
      + 'border-radius:14px;padding:16px;z-index:99998;display:flex;align-items:center;gap:14px;'
      + 'box-shadow:0 8px 32px rgba(0,0,0,.3);max-width:420px;margin:0 auto';
    banner.innerHTML = '<div style="font-size:2rem;flex-shrink:0">📱</div>'
      + '<div style="flex:1"><div style="font-weight:800;font-size:.9rem;margin-bottom:3px">Add ' + platform + ' to your home screen</div>'
      + '<div style="font-size:.76rem;opacity:.75">Track bookings, get alerts — even offline</div></div>'
      + '<div style="display:flex;flex-direction:column;gap:6px;flex-shrink:0">'
      + '<button id="gs-a2hs-install" style="background:#2563EB;color:#fff;border:none;border-radius:7px;padding:7px 14px;font-size:.78rem;font-weight:700;cursor:pointer;white-space:nowrap">Install</button>'
      + '<button id="gs-a2hs-dismiss" style="background:rgba(255,255,255,.12);color:#fff;border:none;border-radius:7px;padding:5px 10px;font-size:.72rem;cursor:pointer">Not now</button>'
      + '</div>';

    document.body.appendChild(banner);

    document.getElementById('gs-a2hs-install').addEventListener('click', function() {
      banner.remove();
      if (_deferredA2HS) {
        // Native install prompt available (Android Chrome)
        _deferredA2HS.prompt();
        _deferredA2HS.userChoice.then(function(result) {
          if (result.outcome === 'accepted') {
            localStorage.setItem('gs_a2hs_dismissed', Date.now().toString());
          }
          _deferredA2HS = null;
        });
      } else {
        // iOS Safari — show manual instructions
        var ios = document.createElement('div');
        ios.style.cssText = 'position:fixed;bottom:0;left:0;right:0;background:#fff;border-radius:16px 16px 0 0;padding:24px;z-index:99999;box-shadow:0 -4px 32px rgba(0,0,0,.15);text-align:center';
        ios.innerHTML = '<div style="font-size:1.5rem;margin-bottom:10px">📱</div>'
          + '<div style="font-weight:800;margin-bottom:8px">Add to Home Screen</div>'
          + '<div style="font-size:.84rem;color:#64748B;margin-bottom:14px;line-height:1.6">'
          + 'Tap the <strong>Share</strong> button (⬆) in Safari, then choose <strong>"Add to Home Screen"</strong>.</div>'
          + '<button onclick="this.parentElement.remove()" style="background:#2563EB;color:#fff;border:none;border-radius:8px;padding:10px 24px;font-size:.85rem;font-weight:700;cursor:pointer">Got it</button>';
        document.body.appendChild(ios);
        localStorage.setItem('gs_a2hs_dismissed', Date.now().toString());
      }
    });

    document.getElementById('gs-a2hs-dismiss').addEventListener('click', function() {
      banner.remove();
      // Don't re-show for 30 days
      localStorage.setItem('gs_a2hs_dismissed', Date.now().toString());
    });

    // Auto-dismiss after 10s if user ignores it
    setTimeout(function() {
      var b = document.getElementById('gs-a2hs-banner');
      if (b) b.remove();
    }, 10000);
  };
})();
</script>
