<?php
/**
 * Directory Archive — GoodService Platform v4
 * IndiaOnline/JustDial reference match:
 *  · Site header (logo + search + CTA)
 *  · Results LEFT · Sidebar RIGHT
 *  · Horizontal locality pills
 *  · Dense info cards: masked phone, open/closed, tags, cities
 *  · Exact color palette: orange #FF6600, blue #0066CC
 *
 * Cache note: nocache_headers() is called in Router.php before render_page()
 * so this page is always fresh regardless of caching plugins.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
global $wpdb;
$pfx = $wpdb->prefix . 'gs_';

// ── Dynamic canonical for the archive/directory page ─────────────────
// The base canonical is /directory/ (output by render_page for archive).
// For filtered views (category, city) we override with the filtered URL
// so each combination is its own canonical, not a variation of /directory/.
add_filter( 'gs_head_inject', function( $html, $page ) use ( &$listings ) {
    if ( $page !== 'archive' ) { return $html; }
    $cat_slug = sanitize_text_field( $_GET['category'] ?? '' );
    $city_val = sanitize_text_field( $_GET['city']     ?? '' );
    // Build the canonical URL from the active clean filters only
    $params = [];
    if ( $cat_slug ) { $params['category'] = $cat_slug; }
    if ( $city_val ) { $params['city']     = $city_val; }
    $canonical = $params
        ? home_url( '/directory/?' . http_build_query( $params ) )
        : home_url( '/directory/' );
    $html .= '<link rel="canonical" href="' . esc_url( $canonical ) . '">';

    // Real feature, priority 3 (internal linking / rich results): genuine
    // ItemList schema listing the actual businesses shown on this page —
    // not just CollectionPage, which only tells Google "this is a
    // collection" without enumerating what's on it. Uses the real
    // $listings array already queried by this page, captured by
    // reference, so this can never diverge from what's actually displayed.
    if ( ! empty( $listings ) && is_array( $listings ) ) {
        $_item_list = array_values( array_filter( array_map( function( $l, $i ) {
            if ( empty( $l->slug ) ) { return null; }
            return [
                '@type'    => 'ListItem',
                'position' => $i + 1,
                'url'      => home_url( '/' . $l->slug . '/' ),
                'name'     => $l->title ?? '',
            ];
        }, $listings, array_keys( $listings ) ) ) );
        if ( $_item_list ) {
            $html .= '<script type="application/ld+json">' . wp_json_encode( [
                '@context' => 'https://schema.org',
                '@type'    => 'ItemList',
                'itemListElement' => $_item_list,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>';
        }
    }
    return $html;
}, 5, 2 );

// ── Filters ──────────────────────────────────────────────────────────
$keyword     = sanitize_text_field( $_GET['keyword']     ?? '' );
$city        = sanitize_text_field( $_GET['city']        ?? '' );
$category_id = intval( $_GET['category_id'] ?? 0 );
$cat_slug    = sanitize_text_field( $_GET['category']    ?? get_query_var('gs_category','') );
$sort        = sanitize_text_field( $_GET['sort']        ?? 'featured' );
$min_rating  = floatval( $_GET['min_rating']  ?? 0 );
$type_filter = sanitize_text_field( $_GET['type']        ?? '' );
// Phase 2: price range, verified-only, and bookable-now filters
$price_min      = ( isset($_GET['price_min']) && $_GET['price_min'] !== '' ) ? floatval($_GET['price_min']) : null;
$price_max      = ( isset($_GET['price_max']) && $_GET['price_max'] !== '' ) ? floatval($_GET['price_max']) : null;
$verified_only  = ! empty( $_GET['verified_only'] );
$bookable_only  = ! empty( $_GET['bookable'] );
$avail_today    = ! empty( $_GET['avail_today'] );
$avail_week     = ! empty( $_GET['avail_week'] ) && ! $avail_today; // mutually exclusive
$today_dow      = (int) date('w'); // 0=Sun … 6=Sat
$today_date     = date('Y-m-d');
$per_page    = max(1, intval( gs_setting('listings_per_page','20') ));

// Keyset pagination cursor params — passed via URL for next/prev navigation.
// These replace OFFSET for efficient deep-page access at any scale.
// last_id/last_score/last_rating = values of the LAST item on the previous page (for Next)
// first_id/first_score/first_rating = values of the FIRST item on the current page (for Prev)
// page is kept for the "Page N" display label only — not used in the SQL query.
$page          = max(1, intval( $_GET['page'] ?? 1 ));
$last_id       = intval( $_GET['last_id']       ?? 0 );
$last_score    = floatval( $_GET['last_score']  ?? 0 );
$last_feat     = intval( $_GET['last_feat']     ?? 0 );
$last_rating   = floatval( $_GET['last_rating'] ?? 0 );
$first_id      = intval( $_GET['first_id']      ?? 0 );
$first_score   = floatval( $_GET['first_score'] ?? 0 );
$first_feat    = intval( $_GET['first_feat']    ?? 0 );
$first_rating  = floatval( $_GET['first_rating'] ?? 0 );
$going_prev    = isset( $_GET['first_id'] ) && $first_id > 0; // true = user clicked Prev

if ($cat_slug && !$category_id) {
    $r = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$pfx}categories WHERE slug=%s",$cat_slug));
    if ($r) $category_id = (int)$r->id;
}
$cur_cat = $category_id
    ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$pfx}categories WHERE id=%d",$category_id))
    : null;

// Real fix: a listing's category_id is set to the SUBCATEGORY the vendor
// picked (create-listing.php's cl-category-sub select — see its own "main
// category with no subcategories" comment), never to the parent's own id,
// for any parent category that actually has subcategories. But every
// homepage entry point into the directory ("Browse by Service" on
// home.php, and others) links using the PARENT category's id — e.g.
// /directory/?category_id=7 for "Beauty & Salon". Filtering with a bare
// l.category_id=7 therefore matched zero rows for any parent category that
// has children, even though active listings genuinely exist "under" it
// (tagged to its Hair Salon / Spa / etc. subcategories) — confirmed by
// checking category-manager.php and create-listing.php's category-select
// pair, not assumed. When the requested category_id is itself a parent
// (parent_id=0) with subcategories, roll the filter up to match the parent
// OR any of its direct children, so a listing tagged to a subcategory is
// correctly included when its parent is the one being browsed. A
// subcategory-specific id (e.g. from a listing's own breadcrumb, which
// always links to the listing's own exact category_id) has no children of
// its own, so this is a no-op for that case — never widens an
// already-precise subcategory filter.
$category_id_filter = $category_id ? [ $category_id ] : [];
if ( $category_id && $cur_cat && (int) ( $cur_cat->parent_id ?? 0 ) === 0 ) {
    $sub_ids = $wpdb->get_col( $wpdb->prepare(
        "SELECT id FROM {$pfx}categories WHERE parent_id=%d", $category_id
    ) );
    if ( $sub_ids ) { $category_id_filter = array_merge( $category_id_filter, array_map( 'intval', $sub_ids ) ); }
}

/* ── Query ────────────────────────────────────────────────────── */
$where = ["l.status='active'"];
$vals  = [];
if ($category_id_filter) {
    $where[] = 'l.category_id IN (' . implode(',', array_fill(0, count($category_id_filter), '%d')) . ')';
    array_push($vals, ...$category_id_filter);
}
if ($city) {
    // City filter: always match l.city directly (instant, uses idx_city index).
    // Also match service_cities via join table when it exists and is populated.
    // Combining both ensures zero listings are missed even before DB Upgrade is run.
    global $wpdb;
    $lc_tbl = $wpdb->prefix . 'gs_listing_cities';
    if ( $wpdb->get_var( "SHOW TABLES LIKE '{$lc_tbl}'" ) ) {
        $where[] = "(l.city = %s OR EXISTS (SELECT 1 FROM {$lc_tbl} lc WHERE lc.listing_id = l.id AND lc.city = %s))";
        $vals[]  = $city;
        $vals[]  = $city;
    } else {
        // Pre-upgrade fallback: direct city match + LIKE on service_cities
        $where[] = '(l.city = %s OR l.service_cities LIKE %s)';
        $vals[]  = $city;
        $vals[]  = '%' . $city . '%';
    }
}
if ($type_filter) { $where[] = 'l.listing_type=%s';   $vals[] = $type_filter; }
if ($min_rating)  { $where[] = 'l.avg_rating>=%f';    $vals[] = $min_rating; }
if ($keyword) {
    // Use FULLTEXT search (title, tagline, short_desc, tags, city) when keyword >= 3 chars.
    // FULLTEXT is indexed — fast at any scale. Falls back to LIKE for short queries
    // because InnoDB FULLTEXT minimum word length is 3 characters.
    // address is not in the FULLTEXT index so we keep a single LIKE on it.
    if ( strlen($keyword) >= 3 ) {
        $where[] = '(MATCH(l.title,l.tagline,l.short_desc,l.tags,l.city) AGAINST (%s IN BOOLEAN MODE) OR l.address LIKE %s)';
        $vals[]  = $keyword . '*'; // Boolean mode prefix wildcard for partial matches
        $vals[]  = '%' . $keyword . '%';
    } else {
        // Short query: FULLTEXT won't work, use narrow LIKE (title + tags only)
        $kw = '%' . $keyword . '%';
        $where[] = '(l.title LIKE %s OR l.tags LIKE %s OR l.short_desc LIKE %s OR l.address LIKE %s)';
        $vals[] = $kw; $vals[] = $kw; $vals[] = $kw; $vals[] = $kw;
    }
}
// Phase 2: price range — overlap match. Listings without price data are
// excluded once a price filter is active (can't compare against unknowns).
if ($price_min !== null || $price_max !== null) {
    $where[] = 'l.price_min IS NOT NULL AND l.price_max IS NOT NULL';
    if ($price_min !== null) { $where[] = 'l.price_max >= %f'; $vals[] = $price_min; }
    if ($price_max !== null) { $where[] = 'l.price_min <= %f'; $vals[] = $price_max; }
}
// Phase 2: verified vendors only
if ($verified_only) {
    $where[] = "vp.verification_status='verified'";
}
// Phase 2: "accepts online bookings" — this LISTING has at least one inquiry
// module with accepts_booking=true AND has its own configured weekly
// availability schedule. Both accepts_booking and availability are
// listing-scoped, so this is now precise (not an approximation): a vendor's
// other listings having availability doesn't make THIS listing bookable.
if ($bookable_only) {
    $where[] = "l.inquiry_modules_data LIKE %s";
    $vals[]  = '%"accepts_booking":true%';
    $where[] = "EXISTS (SELECT 1 FROM {$pfx}availability av WHERE av.listing_id = l.id AND av.is_active = 1)";
}
// Phase 2: "Available today" — has an active schedule for today's
// day-of-week AND today is not a blocked date for that listing.
if ($avail_today) {
    $where[] = "EXISTS (SELECT 1 FROM {$pfx}availability av WHERE av.listing_id=l.id AND av.is_active=1 AND av.day_of_week=%d)";
    $vals[]  = $today_dow;
    $where[] = "NOT EXISTS (SELECT 1 FROM {$pfx}blocked_dates bd WHERE bd.listing_id=l.id AND bd.blocked_date=%s)";
    $vals[]  = $today_date;
}
// Phase 2: "Available this week" — has an active slot on any of the next 7 days.
if ($avail_week) {
    $week_dows     = array_unique(array_map(fn($i)=>(int)date('w',strtotime("+{$i} days")),range(0,6)));
    $week_dow_list = implode(',', $week_dows);
    $where[] = "EXISTS (SELECT 1 FROM {$pfx}availability av WHERE av.listing_id=l.id AND av.is_active=1 AND av.day_of_week IN ({$week_dow_list}))";
}
$wsql = implode(' AND ',$where);
$_gs_has_ranking_score = function_exists( 'gs_enh_table_cols' )
    ? in_array( 'ranking_score', gs_enh_table_cols( $pfx . 'listings' ), true )
    : true; // fail open if the helper itself somehow isn't loaded — assume the column exists rather than silently downgrading every page

// ── Context-aware featured priority ──────────────────────────────────────
// Real fix, the actual root cause: ranking_score bakes in a static +15%
// featured boost (see ReviewRepository::recalculate_ranking_score()) that
// applies unconditionally everywhere a listing appears — with zero
// awareness of which category or city is actually being searched. This
// computes whether a listing's featured status is genuinely relevant to
// THIS specific search, at query time: true only when featured AND (no
// category filter active, or the category matches) AND (no city filter
// active, or the listing genuinely serves that city, checked the exact
// same way the WHERE clause above already does via gs_listing_cities).
$_lc_tbl = $wpdb->prefix . 'gs_listing_cities';
$_lc_exists = (bool) $wpdb->get_var( "SHOW TABLES LIKE '{$_lc_tbl}'" );
if ( $city ) {
    $_feat_city_sql = $_lc_exists
        ? $wpdb->prepare( "(l.city = %s OR EXISTS (SELECT 1 FROM {$_lc_tbl} lc WHERE lc.listing_id = l.id AND lc.city = %s))", $city, $city )
        : $wpdb->prepare( "(l.city = %s OR l.service_cities LIKE %s)", $city, '%' . $city . '%' );
} else {
    $_feat_city_sql = '1'; // no city filter active — always satisfied
}
// Real fix: mirrors the l.category_id IN (...) rollup used for the main
// WHERE clause above — without this, a listing genuinely featured and
// genuinely matching the browsed parent category (via one of its
// subcategories) would lose its featured-priority boost purely because
// this separate relevance fragment still compared against the bare parent
// id with a plain equality check.
$_feat_cat_sql = $category_id_filter
    ? $wpdb->prepare( 'l.category_id IN (' . implode(',', array_fill(0, count($category_id_filter), '%d')) . ')', ...$category_id_filter )
    : '1';
// Safe to splice directly: both fragments above are already fully escaped
// via their own $wpdb->prepare() calls, so this adds zero new placeholders
// to the main query — avoiding any risk of misaligning parameter order in
// an already-complex WHERE/keyset-WHERE/ORDER BY structure.
$_feat_expr = "(l.is_featured = 1 AND {$_feat_cat_sql} AND {$_feat_city_sql})";
$osql = match($sort){
    'rating'  => 'l.avg_rating DESC',
    'reviews' => 'l.review_count DESC',
    'views'   => 'l.views_count DESC',
    'newest'  => 'l.created_at DESC',
    // Real fix: featured priority now only applies when genuinely relevant
    // to this specific search (see $_feat_expr above) — sorted first, with
    // the existing quality signal (ranking_score, already correctly
    // incorporating rating/freshness/verification) still governing order
    // within and beyond that group, rather than a static, precomputed
    // featured boost applying unconditionally everywhere regardless of
    // category or city context.
    default   => $_gs_has_ranking_score
        ? "{$_feat_expr} DESC, l.ranking_score DESC, l.id DESC"
        : "{$_feat_expr} DESC, l.avg_rating DESC, l.views_count DESC",
};

// ── Keyset pagination WHERE clause ──────────────────────────────────────────
// Replaces OFFSET entirely. No SQL execution needed without a cursor.
$keyset_where = '';
$keyset_order = '';
$keyset_vals  = [];

if ( $going_prev && $first_id ) {
    // User clicked Prev: fetch the page BEFORE the first item currently shown.
    // Reverse the ORDER BY direction, apply keyset, then reverse the result in PHP.
    switch ( $sort ) {
        case 'newest':
            // ORDER BY id DESC — Prev means id > first_id
            $keyset_where = 'AND l.id > %d';
            $keyset_order = 'ORDER BY l.id ASC'; // reversed — we flip in PHP
            $keyset_vals  = [ $first_id ];
            break;
        case 'rating':
            $keyset_where = 'AND (l.avg_rating > %f OR (l.avg_rating = %f AND l.id > %d))';
            $keyset_order = 'ORDER BY l.avg_rating ASC, l.id ASC';
            $keyset_vals  = [ $first_rating, $first_rating, $first_id ];
            break;
        default:
            // Default: ranking_score DESC, id DESC (id as tiebreaker for equal scores)
            // Falls back to the original featured+rating cursor if the column doesn't exist yet (see $_gs_has_ranking_score above).
            if ( $_gs_has_ranking_score ) {
                $keyset_where = 'AND (l.ranking_score > %f OR (l.ranking_score = %f AND l.id > %d))';
                $keyset_order = 'ORDER BY l.ranking_score ASC, l.id ASC';
                $keyset_vals  = [ $first_score, $first_score, $first_id ];
            } else {
                $keyset_where = 'AND (l.is_featured > %d OR (l.is_featured = %d AND l.avg_rating > %f) OR (l.is_featured = %d AND l.avg_rating = %f AND l.id > %d))';
                $keyset_order = 'ORDER BY l.is_featured ASC, l.avg_rating ASC, l.id ASC';
                $keyset_vals  = [ $first_feat, $first_feat, $first_rating, $first_feat, $first_rating, $first_id ];
            }
            break;
    }
} elseif ( $last_id ) {
    // User clicked Next: fetch items AFTER the last item on the previous page.
    switch ( $sort ) {
        case 'newest':
            $keyset_where = 'AND l.id < %d';
            $keyset_vals  = [ $last_id ];
            break;
        case 'rating':
            $keyset_where = 'AND (l.avg_rating < %f OR (l.avg_rating = %f AND l.id < %d))';
            $keyset_vals  = [ $last_rating, $last_rating, $last_id ];
            break;
        default:
            // Default: ranking_score DESC, id DESC (id as tiebreaker for equal scores)
            if ( $_gs_has_ranking_score ) {
                $keyset_where = 'AND (l.ranking_score < %f OR (l.ranking_score = %f AND l.id < %d))';
                $keyset_vals  = [ $last_score, $last_score, $last_id ];
            } else {
                $keyset_where = 'AND (l.is_featured < %d OR (l.is_featured = %d AND l.avg_rating < %f) OR (l.is_featured = %d AND l.avg_rating = %f AND l.id < %d))';
                $keyset_vals  = [ $last_feat, $last_feat, $last_rating, $last_feat, $last_rating, $last_id ];
            }
            break;
    }
}
// When $keyset_order is set it completely replaces $osql in the SELECT.
// When empty we use the original $osql (first page — no cursor).
if ( $keyset_order === '' ) {
    $keyset_order = 'ORDER BY ' . $osql;
    $osql = ''; // prevent double ORDER BY
} else {
    $osql = ''; // keyset_order takes over
}
// FIX 3: Cache total count — COUNT(*) on 50L rows is expensive.
// Cache key includes all filter params so different filters get different cached counts.
// TTL 60s: fresh enough for real-time feel, dramatically reduces DB load.
$_count_cache_key = 'gsd_count_' . md5( $wsql . serialize($vals) );
$total = wp_cache_get( $_count_cache_key, 'gs_directory' );
if ( $total === false ) {
    // FIX 3: Remove unneeded LEFT JOIN vp when verified_only filter is not active.
    // Without verified_only, vp is not needed for COUNT(*) — the WHERE has no vp columns.
    // With it, keep the JOIN. This avoids joining 50L × vp rows unnecessarily.
    if ( $verified_only ) {
        $total = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$pfx}listings l
             LEFT JOIN {$pfx}vendor_profiles vp ON l.vendor_id=vp.id
             WHERE $wsql",...$vals));
    } else {
        $total = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$pfx}listings l WHERE $wsql",...$vals));
    }
    wp_cache_set( $_count_cache_key, $total, 'gs_directory', 60 );
}

// FIX 2A: Replace SELECT l.* with only the columns the directory card actually uses.
// Drops ~20 LONGTEXT columns (full_desc, services_data, products_data, faq_data,
// hero_data, about_data, etc.) — reduces per-request data transfer from ~15KB to ~1KB per row.
$listings = $wpdb->get_results($wpdb->prepare(
    "SELECT l.id, l.vendor_id, l.title, l.slug, l.tagline, l.short_desc,
            l.city, l.state, l.pincode, l.phone, l.whatsapp, l.website,
            l.logo_url, l.banner_url, l.gallery, l.portfolio_data,
            l.tags, l.price_min, l.price_max, l.listing_type,
            l.is_featured, l.is_verified,
            l.views_count, l.leads_count, l.avg_rating, l.review_count,
            l.opening_hours, l.service_cities, l.lat, l.lng,
            l.created_at, l.established_year,
            c.name AS cat_name, c.slug AS cat_slug,
            vp.verification_status AS vp_v, vp.whatsapp AS vendor_wa,
            IFNULL(vp.response_rate, 0) AS vp_response_rate,
            IFNULL(vp.trust_score, 0) AS vp_trust_score
     FROM {$pfx}listings l
     LEFT JOIN {$pfx}categories c ON c.id=l.category_id
     LEFT JOIN {$pfx}vendor_profiles vp ON l.vendor_id=vp.id
     WHERE $wsql {$keyset_where} {$keyset_order} LIMIT $per_page",...array_merge($vals,$keyset_vals)));

// ── Keyset: reverse result for Prev navigation, extract cursor values ────────
if ( $going_prev && ! empty( $listings ) ) {
    $listings = array_reverse( $listings );
}
// Cursor values for Next/Prev links — read from first and last items in results
$ks_first = ! empty( $listings ) ? $listings[0]         : null;
$ks_last  = ! empty( $listings ) ? end( $listings )     : null;
$ks_has_next = ! empty( $listings ) && count( $listings ) === $per_page;
$ks_has_prev = $page > 1;

// Build Next/Prev URL params
function gd4_ks_url( array $base_q, array $extra ): string {
    return esc_url( add_query_arg( array_merge( $base_q, $extra ) ) );
}

// Phase 2 — My Vendors / favorites: which of these listings has the current
// user already saved? Used to render the heart button's initial state.
$saved_ids = [];
if ( is_user_logged_in() && $listings ) {
    $ids = array_map( fn($l) => (int)$l->id, $listings );
    $ph  = implode( ',', array_fill( 0, count($ids), '%d' ) );
    $saved_ids = $wpdb->get_col( $wpdb->prepare(
        "SELECT listing_id FROM {$pfx}saved_listings WHERE user_id=%d AND listing_id IN ($ph)",
        array_merge( [ get_current_user_id() ], $ids )
    ) );
    $saved_ids = array_map( 'intval', $saved_ids );
}

/* ── Sidebar data — cached aggregations ───────────────────────────
   FIX 1: These GROUP BY / COUNT queries scan the full listings table.
   At 50L+ rows each takes 3-8 seconds. Cache for 5 minutes.
   Cache is busted automatically when any listing is saved/published
   because WordPress object cache flushes on major write events,
   and the transient TTL ensures eventual consistency in any case.
   Cache group 'gs_directory' — separate from listing-level caches. */

// Top 8 cities by listing count
$city_counts = wp_cache_get( 'gsd_city_counts_top8', 'gs_directory' );
if ( $city_counts === false ) {
    $city_counts = $wpdb->get_results(
        "SELECT city, COUNT(*) AS n FROM {$pfx}listings WHERE city!='' AND status='active' GROUP BY city ORDER BY n DESC LIMIT 8");
    wp_cache_set( 'gsd_city_counts_top8', $city_counts, 'gs_directory', 300 );
}

// Total distinct cities
$total_cities = wp_cache_get( 'gsd_total_cities', 'gs_directory' );
if ( $total_cities === false ) {
    $total_cities = (int) $wpdb->get_var(
        "SELECT COUNT(DISTINCT city) FROM {$pfx}listings WHERE city!='' AND status='active'");
    wp_cache_set( 'gsd_total_cities', $total_cities, 'gs_directory', 300 );
}

// All categories with listing counts
//
// Real fix: same root cause as the main WHERE-clause rollup above — a
// listing's category_id is the subcategory the vendor picked, not the
// parent's own id, for any parent that has subcategories. The old join
// (`l.category_id=c.id`, parent categories only) counted zero for every
// parent that actually has subcategories, showing a misleading "(0)" next
// to a category the archive page's own filter (once fixed) correctly
// returns listings for. Counts every listing tagged either directly to
// the parent (parent categories with no subcategories still work exactly
// as before) or to one of its direct children.
$all_cats = wp_cache_get( 'gsd_all_cats', 'gs_directory' );
if ( $all_cats === false ) {
    $all_cats = $wpdb->get_results(
        "SELECT c.id,c.name,c.slug,c.icon_emoji,COUNT(l.id) AS n
         FROM {$pfx}categories c
         LEFT JOIN {$pfx}listings l ON l.status='active'
            AND ( l.category_id=c.id OR l.category_id IN (
                SELECT id FROM {$pfx}categories sc WHERE sc.parent_id=c.id
            ) )
         WHERE c.is_active=1 AND c.parent_id=0 GROUP BY c.id ORDER BY n DESC");
    wp_cache_set( 'gsd_all_cats', $all_cats, 'gs_directory', 300 );
}

// Total active root categories
$total_cats = wp_cache_get( 'gsd_total_cats', 'gs_directory' );
if ( $total_cats === false ) {
    $total_cats = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$pfx}categories WHERE is_active=1 AND parent_id=0");
    wp_cache_set( 'gsd_total_cats', $total_cats, 'gs_directory', 300 );
}

// All cities for typeahead (300 max — used in JS)
$all_cities_f = wp_cache_get( 'gsd_all_cities_300', 'gs_directory' );
if ( $all_cities_f === false ) {
    $all_cities_f = $wpdb->get_results(
        "SELECT city, COUNT(*) AS n FROM {$pfx}listings WHERE city!='' AND status='active' GROUP BY city ORDER BY n DESC LIMIT 300");
    wp_cache_set( 'gsd_all_cities_300', $all_cities_f, 'gs_directory', 300 );
}

/* ── Platform settings ───────────────────────────────────────── */
$pname   = function_exists('gs_setting') ? gs_setting('platform_name',get_bloginfo('name')) : get_bloginfo('name');
$plogo   = function_exists('gs_setting') ? gs_setting('logo_url','')  : '';
$dir_url = esc_url(home_url('/directory/'));
$base_q  = array_filter([
    'keyword'=>$keyword,'city'=>$city,'category_id'=>$category_id?:null,'sort'=>$sort,
    'type'=>$type_filter,'min_rating'=>$min_rating?:null,
    'price_min'=>$price_min,'price_max'=>$price_max,
    'verified_only'=>$verified_only?1:null,'bookable'=>$bookable_only?1:null,
    'avail_today'=>$avail_today?1:null,'avail_week'=>$avail_week?1:null,
], fn($v)=>$v!==null && $v!=='');

/* ── Helper functions ─────────────────────────────────────────── */
function gda_open_status(string $json): ?array {
    if (!$json) return null;
    $h = json_decode($json,true);
    if (!is_array($h)) return null;
    $key = ['sun','mon','tue','wed','thu','fri','sat'][(int)date('w')];
    $day = $h[$key] ?? null;
    if (!$day) return null;
    // Support BOTH formats:
    // Old text: "9:00 AM – 6:00 PM"
    // New structured: {open:'09:00', close:'18:00', closed:bool}
    if (is_string($day)) {
        if (strtolower($day) === 'closed') return ['t'=>'closed','s'=>'Closed Today'];
        return ['t'=>'text','s'=>$day]; // plain text — just display it
    }
    if (!empty($day['closed'])) return ['t'=>'closed','s'=>'Closed Today'];
    if (empty($day['open'])||empty($day['close'])) return null;
    $now  = date('H:i');
    $open = $now>=$day['open'] && $now<=$day['close'];
    $fmt  = fn($t)=>date('g:i A',strtotime($t));
    return $open ? ['t'=>'open','s'=>'Open Now · Closes '.$fmt($day['close'])]
                 : ['t'=>'closed','s'=>'Closed · Opens '.$fmt($day['open'])];
}
function gda_mask(string $ph): string {
    $d=preg_replace('/[^0-9]/','', $ph);
    return strlen($d)>=10 ? substr($d,0,-4).'XXXX' : $ph;
}

$page_title = $cur_cat
    ? 'Top '.esc_html($cur_cat->name).($city?' in '.esc_html($city):'')
    : ($keyword ? 'Search: "'.esc_html($keyword).'"' : 'Browse Directory');
?>
<style>
/* ═══════════════════════════════════════════════════════════════
   GOODSERVICE DIRECTORY  v4  —  IndiaOnline reference match
   All CSS inline; specific selectors beat global critical_css resets
   ═══════════════════════════════════════════════════════════════ */

/* ── CRITICAL: Override global critical_css() rules ─────────────
   critical_css() injects:
     a { color: var(--gs-primary) }          → fights ALL our link colours
     html,body { background: #F8FAFC }       → wrong page background
   We fix these with body-class-scoped !important overrides.     */
body.gs-page-archive { background: #F0F2F5 !important; }

/* ALL link colours inside our page — reset then re-apply per-element */
.gd4-page a { color: inherit; text-decoration: none; }

/* Header links — dark on white background */
.gd4-site-header a,
.gd4-site-header .gd4-header-nav a { color: #475569 !important; text-decoration: none !important; }
.gd4-site-header .gd4-header-nav a:hover { color: #1a1a1a !important; }
.gd4-site-header .gd4-header-cta { color: #fff !important; }
.gd4-site-header .gd4-header-cta:hover { color: #fff !important; }
.gd4-site-logo,
.gd4-site-logo .gd4-logo-text { color: #1a1a1a !important; }
.gd4-site-logo .gd4-logo-tagline { color: #94A3B8 !important; }

/* Breadcrumb links */
.gd4-bc a { color: #0066CC !important; }
.gd4-bc a:hover { color: #004499 !important; }

/* Locality pills */
.gd4-pill { color: #444 !important; text-decoration: none !important; }
.gd4-pill.on,
.gd4-pill:hover { color: #fff !important; }

/* Business title — highest priority */
.gd4-content .gd4-name { color: #1a1a1a !important; text-decoration: none !important; }
.gd4-content .gd4-name:hover { color: #004499 !important; text-decoration: underline !important; }

/* Service tags */
.gd4-tag { color: #0066CC !important; text-decoration: none !important; }
.gd4-tag:hover { color: #fff !important; }
.gd4-tag-x { color: #999 !important; }

/* City links */
.gd4-cities a { color: #0066CC !important; text-decoration: none !important; }
.gd4-cities a:hover { text-decoration: underline !important; }

/* Action buttons — ALL explicit colours */
.gd4-btn-num  { color: #475569 !important; text-decoration: none !important; }
.gd4-btn-num:hover { color: #475569 !important; }
.gd4-btn-book { color: #fff !important; text-decoration: none !important; }
.gd4-btn-wa   { color: #1DA851 !important; text-decoration: none !important; }
.gd4-btn-wa:hover { color: #fff !important; }

/* Pagination */
.gd4-pg { color: #555 !important; text-decoration: none !important; }
.gd4-pg:hover { color: #0066CC !important; }
.gd4-pg.cur   { color: #fff !important; }

/* Sidebar list links */
.gd4-sb-list a { color: #333 !important; text-decoration: none !important; }
.gd4-sb-list a:hover { color: #FF6600 !important; }

/* Clear filters link */
.gd4-sf-clear { color: #888 !important; text-decoration: none !important; }
.gd4-sf-clear:hover { color: #0066CC !important; text-decoration: underline !important; }

/* Distance element — ensure hidden until JS reveals it */
[class^="gd4-dist-"] { display: none !important; }
[class^="gd4-dist-"].visible { display: inline-flex !important; }

/* ── Reset scope */
.gd4-page { font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif; color: #333; background: #F0F2F5; min-height: 100vh; }

/* ── SITE HEADER ──────────────────────────────────────────────── */
.gd4-site-header {
  background: #fff;
  border-bottom: 1px solid #E8ECF2;
  padding: 0;
  box-shadow: 0 1px 3px rgba(0,0,0,.04);
  position: sticky;
  top: 0;
  z-index: 999;
  /* NO overflow:hidden here — it creates a scroll container and kills position:sticky */
}
.gd4-site-header-inner {
  max-width: 1220px; margin: 0 auto; padding: 0 16px;
  height: 60px;
  display: flex; align-items: center; gap: 12px;
  /* No overflow: header clips via parent overflow:hidden */
}
/* Logo */
.gd4-site-logo {
  display: flex; align-items: center; gap: 10px;
  text-decoration: none; flex-shrink: 0;
}
.gd4-logo-img { height: 38px; width: auto; border-radius: 4px; }
.gd4-logo-text {
  font-size: 19px; font-weight: 500; color: #1a1a1a;
  letter-spacing: -.01em; line-height: 1;
}
.gd4-logo-tagline {
  font-size: 9px; font-weight: 400; color: #94A3B8;
  letter-spacing: .05em; text-transform: uppercase;
  display: block; margin-top: 2px;
}
/* Header search */
.gd4-header-search {
  flex: 1; max-width: 480px;
  display: flex; align-items: center;
  background: #F8FAFC; border-radius: 8px;
  overflow: hidden; border: 1px solid #E2E8F0;
}
.gd4-header-search input {
  flex: 1; border: none; outline: none; padding: 0 12px;
  font-size: 13px; color: #333; height: 36px;
  font-family: inherit; background: transparent;
}
.gd4-header-search input::placeholder { color: #94A3B8; }
.gd4-header-search button {
  height: 36px; padding: 0 14px;
  background: transparent; color: #64748B; border: none; cursor: pointer;
  font-size: 14px; font-weight: 500; font-family: inherit;
  transition: color .15s;
}
.gd4-header-search button:hover { color: #FF6600; }
/* Header nav */
.gd4-header-nav {
  display: flex; align-items: center; gap: 4px; margin-left: auto;
}
.gd4-header-nav a {
  color: #475569; font-size: 13px; font-weight: 500;
  padding: 6px 12px; border-radius: 6px; text-decoration: none;
  transition: all .15s;
}
.gd4-header-nav a:hover { background: #F1F5F9; color: #1a1a1a; }
.gd4-header-cta {
  background: #FF6600; color: #fff !important;
  border-radius: 6px; padding: 7px 14px !important;
  font-weight: 500 !important; font-size: 12px !important;
  box-shadow: none;
}
.gd4-header-cta:hover { background: #E55A00 !important; }

/* ── BREADCRUMB ───────────────────────────────────────────────── */
.gd4-bc {
  background: #fff; border-bottom: 1px solid #e8e8e8;
  padding: 7px 0; font-size: 12px;
}
.gd4-bc-inner { max-width: 1220px; margin: 0 auto; padding: 0 16px; color: #888; }
.gd4-bc a     { color: #0066CC !important; text-decoration: none; }
.gd4-bc a:hover { text-decoration: underline; }
.gd4-bc .sep  { margin: 0 5px; color: #ccc; }

/* ── PAGE TITLE STRIP ─────────────────────────────────────────── */
.gd4-title-strip {
  background: #fff; border-bottom: 1px solid #e8e8e8; padding: 12px 0;
}
.gd4-title-inner { max-width: 1220px; margin: 0 auto; padding: 0 16px; }
.gd4-title-inner h1 {
  font-size: 19px; font-weight: 800; color: #1a1a1a; margin: 0 0 2px;
}
.gd4-title-sub { font-size: 12px; color: #888; margin: 0; }

/* ── LOCALITY PILLS ───────────────────────────────────────────── */
.gd4-pills-strip {
  background: #fff; border-bottom: 1px solid #e8e8e8; padding: 9px 0;
}
.gd4-pills-inner {
  max-width: 1220px; margin: 0 auto; padding: 0 16px;
  display: flex; align-items: center; gap: 6px;
  overflow-x: auto; scrollbar-width: none;
}
.gd4-pills-inner::-webkit-scrollbar { display: none; }
.gd4-pills-lbl { font-size: 10px; font-weight: 800; color: #aaa; text-transform: uppercase; letter-spacing: .1em; white-space: nowrap; flex-shrink: 0; }
.gd4-pill {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700;
  border: 1.5px solid #ddd; background: #fff; color: #444 !important;
  text-decoration: none !important; white-space: nowrap; flex-shrink: 0;
  transition: all .15s; cursor: pointer;
}
.gd4-pill:hover, .gd4-pill.on { background: #FF6600 !important; border-color: #FF6600; color: #fff !important; }
.gd4-pill-n { background: rgba(0,0,0,.08); border-radius: 10px; padding: 1px 5px; font-size: 9px; }

/* ── BODY LAYOUT ──────────────────────────────────────────────── */
.gd4-body {
  max-width: 1220px; margin: 0 auto;
  padding: 14px 16px 40px;
  display: grid;
  grid-template-columns: 1fr 300px;
  gap: 14px;
  align-items: start;
  background: #F0F2F5; /* override body background in this scope */
}

/* ── RESULTS BAR ──────────────────────────────────────────────── */
.gd4-rbar {
  display: flex; align-items: center; justify-content: space-between;
  flex-wrap: wrap; gap: 8px;
  background: #fff; border: 1px solid #E0E0E0; border-radius: 5px;
  padding: 8px 14px; margin-bottom: 10px;
}
.gd4-rbar-count { font-size: 13px; color: #555; }
.gd4-rbar-count strong { color: #111; }
.gd4-sort-row { display: flex; align-items: center; gap: 7px; }
.gd4-sort-lbl { font-size: 11px; color: #888; white-space: nowrap; }
.gd4-rbar-count em { color: #FF6600; font-style: normal; font-weight: 700; }
.gd4-sort-sel {
  border: 1px solid #ddd; border-radius: 4px; padding: 5px 24px 5px 8px;
  font-size: 12px; color: #333; font-family: inherit; outline: none;
  background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%23888'/%3E%3C/svg%3E") no-repeat right 7px center / 8px;
  -webkit-appearance: none; appearance: none; cursor: pointer;
}

/* ═══════════════════════════════════════════
   LISTING CARD — Premium v5 upgrade
   ════════════════════════════════════════════ */
.gd4-card {
  background: #fff; border: 1px solid #E8ECF2; border-radius: 16px;
  padding: 0; margin-bottom: 16px; overflow: hidden;
  display: flex; gap: 0; align-items: stretch;
  position: relative; transition: box-shadow .25s, border-color .25s, transform .2s;
  box-shadow: 0 2px 12px rgba(0,0,0,.06), 0 1px 3px rgba(0,0,0,.04);
  cursor: pointer;
}
.gd4-card:hover { box-shadow: 0 12px 36px rgba(0,0,0,.13); border-color: #C7D2E8; transform: translateY(-4px); }
.gd4-card.gd4-featured { border: 1px solid #F2C879; box-shadow: 0 2px 12px rgba(0,0,0,.06), 0 1px 3px rgba(0,0,0,.04); }
.gd4-card.gd4-featured:hover { border-color: #E5AE4A; box-shadow: 0 12px 36px rgba(0,0,0,.13); }
.gd4-featured-label { position:absolute; top:10px; left:10px; background:#FEF3C7; color:#92400E; font-size:.67rem; font-weight:500; padding:4px 10px; border-radius:6px; z-index:10; letter-spacing:.01em; box-shadow:none; }

/* Overflow fixes */
body.gs-page-archive { overflow-x: clip !important; }
.gd4-page { overflow-x: clip; }
.gd4-body > div { min-width: 0; overflow: hidden; }
.gd4-sidebar { min-width: 0; }
.gd4-card { overflow: hidden; }

/* Featured ribbon */
.gd4-ribbon { display:none; }

/* ── Thumbnail — premium with overlay ── */
.gd4-thumb {
  width: 210px; min-width: 210px;
  align-self: stretch;
  border-radius: 14px 0 0 14px; overflow: hidden;
  background: #F1F5F9; flex-shrink: 0; display: block;
  text-decoration: none !important; position: relative;
  min-height: 200px;
}
.gd4-thumb img { width:100%; height:100%; object-fit:cover; display:block; transition: transform .4s ease; position:absolute; top:0; left:0; }
.gd4-card:hover .gd4-thumb img { transform: scale(1.07); }
.gd4-thumb-ph { width:100%; height:100%; min-height:200px; display:flex; align-items:center; justify-content:center; font-size:3rem; color:#CBD5E1; background:linear-gradient(135deg,#F8FAFC,#EEF2FF); }

/* Portfolio strip — 3 mini thumbnails at bottom of image */
.gd4-thumb-strip {
  position:absolute; bottom:0; left:0; right:0;
  display:flex; gap:2px; padding:2px; background:rgba(0,0,0,.35);
  backdrop-filter:blur(2px); opacity:0; transition:opacity .2s;
}
.gd4-card:hover .gd4-thumb-strip { opacity:1; }
.gd4-thumb-mini { flex:1; height:36px; object-fit:cover; border-radius:3px; }

/* Availability dot overlay */
.gd4-avail-dot {
  position:absolute; top:10px; right:10px;
  width:10px; height:10px; border-radius:50%;
  border:2px solid rgba(255,255,255,.9);
  box-shadow:0 1px 4px rgba(0,0,0,.3);
  z-index:5;
}
.gd4-avail-dot.available { background:#22C55E; }
.gd4-avail-dot.unavailable { background:#EF4444; }

/* Quick preview trigger */
.gd4-quick-prev-btn {
  position:absolute; bottom:8px; right:8px;
  background:rgba(0,0,0,.6); color:#fff;
  border:none; border-radius:6px; padding:4px 8px;
  font-size:10px; font-weight:700; cursor:pointer;
  opacity:0; transition:opacity .2s; z-index:5;
  backdrop-filter:blur(4px); font-family:inherit;
}
.gd4-card:hover .gd4-quick-prev-btn { opacity:1; }

/* Content column */
.gd4-content { flex:1; min-width:0; padding:16px 18px 14px; display:flex; flex-direction:column; }

/* Title row */
.gd4-title-row { display:flex; align-items:flex-start; gap:6px; flex-wrap:wrap; margin-bottom:4px; }
.gd4-content .gd4-name {
  font-size:15px; font-weight:500; line-height:1.3;
  color:#1a1a1a !important; text-decoration:none !important;
  transition:color .12s;
}
.gd4-content .gd4-name:hover { color:#FF6600 !important; }

/* Tagline */
.gd4-tagline {
  font-size:12px; color:#64748B; margin:2px 0 5px;
  font-style:italic; line-height:1.4;
  overflow:hidden; text-overflow:ellipsis;
  display:-webkit-box; -webkit-line-clamp:1; -webkit-box-orient:vertical;
}

/* Badges */
.gd4-badge-v {
  display:inline-flex; align-items:center; gap:3px;
  background:linear-gradient(135deg,#ECFDF5,#D1FAE5);
  border:1px solid #6EE7B7; color:#065F46;
  font-size:9px; font-weight:800; padding:2px 7px;
  border-radius:20px; white-space:nowrap; flex-shrink:0; margin-top:1px;
}
.gd4-badge-cat {
  display:inline-block;
  background:#FFF7ED; color:#C2410C; border:1px solid #FED7AA;
  font-size:10px; font-weight:700; padding:2px 7px;
  border-radius:20px; white-space:nowrap; flex-shrink:0; margin-top:1px;
}
.gd4-badge-popular {
  display:inline-flex; align-items:center; gap:2px;
  background:linear-gradient(135deg,#FFF1F2,#FFE4E6);
  border:1px solid #FECACA; color:#BE123C;
  font-size:9px; font-weight:800; padding:2px 7px;
  border-radius:20px; white-space:nowrap; flex-shrink:0; margin-top:1px;
}
.gd4-badge-new {
  display:inline-flex; align-items:center; gap:2px;
  background:linear-gradient(135deg,#EFF6FF,#DBEAFE);
  border:1px solid #BFDBFE; color:#1D4ED8;
  font-size:9px; font-weight:800; padding:2px 7px;
  border-radius:20px; white-space:nowrap; flex-shrink:0; margin-top:1px;
}

/* Address */
.gd4-addr { display:flex; align-items:flex-start; gap:4px; font-size:12px; color:#64748B; margin:4px 0; line-height:1.4; }
.gd4-pin { color:#DC2626; flex-shrink:0; margin-top:1px; font-size:11px; }

/* Rating + meta */
.gd4-meta { display:flex; align-items:center; gap:7px; flex-wrap:wrap; margin:4px 0; font-size:12px; }
.gd4-stars { display:inline-flex; gap:1px; align-items:center; }
.gd4-star { font-size:12px; color:#E0E0E0; line-height:1; }
.gd4-star.on { color:#FBBF24; }
.gd4-score { font-weight:800; color:#1E293B; font-size:13px; }
.gd4-rcount { color:#94A3B8; font-size:11px; }
.gd4-sep { color:#E2E8F0; font-size:10px; }
.gd4-open { font-size:11px; font-weight:700; }
.gd4-open.open { color:#16A34A; }
.gd4-open.closed { color:#DC2626; }
.gd4-open-time { font-size:11px; color:#64748B; }

/* Price range */
.gd4-price-range {
  display:inline-flex; align-items:center; gap:4px;
  background:#F8FAFC; border:1px solid #E2E8F0; color:#475569;
  font-size:10px; font-weight:500; padding:2px 8px; border-radius:6px;
  white-space:nowrap;
}

/* Response time */
.gd4-resp-time {
  display:inline-flex; align-items:center; gap:3px;
  background:#EFF6FF; border:1px solid #BFDBFE; color:#1D4ED8;
  font-size:10px; font-weight:700; padding:2px 8px; border-radius:20px;
}

.gd4-info { display:flex; align-items:center; gap:8px; flex-wrap:wrap; font-size:11px; color:#94A3B8; margin:3px 0; }

/* Description */
.gd4-desc { font-size:12px; color:#475569; line-height:1.55; margin:5px 0 4px;
  display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;
  word-break:break-word; overflow-wrap:anywhere; max-width:100%; }
.gd4-content { word-break:break-word; overflow-wrap:break-word; }
.gd4-addr span { word-break:break-word; }

/* Tags */
.gd4-tags { display:flex; flex-wrap:wrap; gap:4px; margin:5px 0; }
.gd4-tag {
  font-size:10px; padding:3px 8px; border-radius:20px;
  background:#F1F5F9; color:#334155 !important;
  border:1px solid #E2E8F0; text-decoration:none !important;
  transition:all .12s; display:inline-block; font-weight:600;
}
.gd4-tag:hover { background:#0066CC; color:#fff !important; border-color:#0066CC; }
.gd4-tag-x { background:#F8FAFC; color:#94A3B8 !important; border-color:#E2E8F0; cursor:default; }

/* Cities */
.gd4-cities { font-size:11px; color:#64748B; margin:3px 0; }
.gd4-cities a { color:#0066CC !important; text-decoration:none !important; }
.gd4-cities a:hover { text-decoration:underline !important; }

/* ── Action row — premium ── */
.gd4-actions {
  display:flex; align-items:center; gap:6px; flex-wrap:wrap;
  margin-top:auto; padding-top:11px; border-top:1px solid #F1F5F9;
}
.gd4-btn {
  display:inline-flex; align-items:center; gap:5px;
  padding:7px 14px; border-radius:8px; font-size:12px; font-weight:700;
  cursor:pointer; border:none; font-family:inherit;
  text-decoration:none !important; line-height:1; white-space:nowrap;
  transition:all .15s;
}
.gd4-btn:hover { transform:translateY(-1px); box-shadow:0 3px 10px rgba(0,0,0,.15); }
.gd4-btn:active { transform:scale(.97); }

/* "Show Number" */
.gd4-btn-num { background:#fff; color:#475569 !important; border:1px solid #CBD5E1; }
.gd4-btn-num:hover { background:#F8FAFC; border-color:#94A3B8; }

/* "View Details" — primary action */
.gd4-btn-book {
  background:#FF6600; color:#fff !important;
  box-shadow:none; border:none;
}
.gd4-btn-book:hover { background:#E55A00; box-shadow:none; }

/* WhatsApp */
.gd4-btn-wa { background:#fff; color:#16A34A !important; border:1.5px solid #16A34A; }
.gd4-btn-wa:hover { background:#16A34A; color:#fff !important; }

/* Website visit */
.gd4-btn-web { background:#fff; color:#7C3AED !important; border:1.5px solid #DDD6FE; }
.gd4-btn-web:hover { background:#7C3AED; color:#fff !important; border-color:#7C3AED; }

/* Save/wishlist */
.gd4-btn-save {
  background:#fff; color:#94A3B8 !important;
  border:1.5px solid #E2E8F0; padding:7px 9px;
  transition:all .15s;
}
.gd4-btn-save:hover, .gd4-btn-save.saved { background:#FFF1F2; color:#BE123C !important; border-color:#FECACA; }

/* Share / copy link */
.gd4-btn-share {
  background:#fff; color:#94A3B8 !important;
  border:1.5px solid #E2E8F0; padding:7px 9px;
  transition:all .15s;
}
.gd4-btn-share:hover, .gd4-btn-share.copied { background:#EFF6FF; color:#2563EB !important; border-color:#BFDBFE; }

/* Stats */
.gd4-stats { margin-left:auto; display:flex; align-items:center; gap:8px; font-size:11px; color:#CBD5E1; flex-shrink:0; }
.gd4-stat-v { display:flex; align-items:center; gap:2px; }

/* Enquiry count badge */
.gd4-enquiry-cnt {
  display:inline-flex; align-items:center; gap:3px;
  font-size:10px; color:#64748B; font-weight:600;
}

/* No results */
.gd4-empty { background:#fff; border:1px solid #E2E8F0; border-radius:12px; padding:60px 24px; text-align:center; }
.gd4-empty h3 { font-size:18px; color:#1E293B; margin:12px 0 6px; }
.gd4-empty p { font-size:13px; color:#64748B; }
.gd4-empty a { color:#0066CC !important; }

/* Pagination */
.gd4-pagination { display:flex; align-items:center; justify-content:center; gap:5px; padding:18px 0; flex-wrap:wrap; }
.gd4-pg {
  display:inline-flex; align-items:center; justify-content:center;
  min-width:36px; height:36px; padding:0 10px;
  border:1.5px solid #E2E8F0; border-radius:10px;
  font-size:13px; font-weight:700; color:#334155 !important;
  text-decoration:none !important; background:#fff; transition:all .15s;
}
.gd4-pg:hover { border-color:#CBD5E1; color:#1a1a1a !important; background:#F8FAFC; }
.gd4-pg.cur { background:#FF6600; border-color:transparent; color:#fff !important; box-shadow:none; }
.gd4-pg-dots { color:#CBD5E1; padding:0 4px; font-size:14px; }

/* ─── GRID/LIST VIEW TOGGLE ─── */
.gd4-view-toggle { display:flex; gap:4px; }
.gd4-vt-btn {
  padding:5px 9px; border:1.5px solid #E2E8F0; border-radius:7px;
  background:#fff; cursor:pointer; font-size:14px; transition:all .15s;
  color:#94A3B8;
}
.gd4-vt-btn.on { background:#0066CC; border-color:#0066CC; color:#fff; }
.gd4-vt-btn:hover:not(.on) { border-color:#0066CC; color:#0066CC; }

/* Grid view */
.gd4-results-list.grid-view { display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:16px; }
.gd4-results-list.grid-view .gd4-card { flex-direction:column; min-height:360px; }
.gd4-results-list.grid-view .gd4-thumb { width:100%; min-width:unset; height:180px; min-height:180px; border-radius:14px 14px 0 0; }
.gd4-results-list.grid-view .gd4-content { padding:14px; }
.gd4-results-list.grid-view .gd4-stats { margin-left:0; }

/* ─── QUICK PREVIEW MODAL ─── */
#gd4-preview-modal {
  display:none; position:fixed; inset:0; z-index:99999;
  background:rgba(15,23,42,.65); backdrop-filter:blur(4px);
  align-items:center; justify-content:center; padding:16px;
}
#gd4-preview-modal.open { display:flex; }
#gd4-preview-panel {
  background:#fff; border-radius:20px; width:100%; max-width:680px;
  max-height:90vh; overflow-y:auto; box-shadow:0 28px 80px rgba(0,0,0,.25);
  animation:gd4-slide-up .25s cubic-bezier(.4,0,.2,1);
  scrollbar-width:thin;
}
@keyframes gd4-slide-up { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:translateY(0)} }
#gd4-preview-panel::-webkit-scrollbar { width:4px; }
#gd4-preview-panel::-webkit-scrollbar-thumb { background:#E2E8F0; border-radius:4px; }
.gd4-pv-close {
  position:absolute; top:14px; right:14px;
  width:32px; height:32px; border-radius:50%;
  background:rgba(0,0,0,.5); color:#fff;
  border:none; cursor:pointer; font-size:16px;
  display:flex; align-items:center; justify-content:center;
  z-index:10; transition:.15s;
}
.gd4-pv-close:hover { background:rgba(0,0,0,.75); }
.gd4-pv-img {
  width:100%; height:240px; object-fit:cover;
  border-radius:20px 20px 0 0; display:block;
  background:linear-gradient(135deg,#F1F5F9,#EEF2FF);
}
.gd4-pv-body { padding:22px 24px; }
.gd4-pv-title { font-size:1.15rem; font-weight:800; color:#0F172A; margin-bottom:4px; }
.gd4-pv-tagline { font-size:.83rem; color:#64748B; margin-bottom:12px; font-style:italic; }
.gd4-pv-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px; }
.gd4-pv-cell { background:#F8FAFC; border-radius:9px; padding:9px 12px; }
.gd4-pv-lbl { font-size:.65rem; font-weight:800; color:#94A3B8; text-transform:uppercase; letter-spacing:.06em; margin-bottom:3px; }
.gd4-pv-val { font-size:.83rem; font-weight:600; color:#1E293B; }
.gd4-pv-desc { font-size:.85rem; color:#475569; line-height:1.7; margin-bottom:16px; }
.gd4-pv-tags { display:flex; flex-wrap:wrap; gap:5px; margin-bottom:16px; }
.gd4-pv-actions { display:flex; gap:8px; flex-wrap:wrap; }
.gd4-pv-gallery { display:grid; grid-template-columns:repeat(4,1fr); gap:6px; margin-bottom:14px; }
.gd4-pv-gallery img { width:100%; aspect-ratio:1; object-fit:cover; border-radius:8px; }

/* ─── RESULTS HEADER ─── */
.gd4-rbar {
  display:flex; align-items:center; justify-content:space-between;
  flex-wrap:wrap; gap:8px;
  background:#fff; border:1px solid #E8ECF2; border-radius:12px;
  padding:10px 16px; margin-bottom:12px;
  box-shadow:0 1px 4px rgba(0,0,0,.04);
}
.gd4-rbar-count { font-size:13px; color:#475569; }
.gd4-rbar-count strong { color:#0F172A; }
.gd4-sort-row { display:flex; align-items:center; gap:7px; }
.gd4-sort-lbl { font-size:11px; color:#94A3B8; white-space:nowrap; }
.gd4-rbar-count em { color:#FF6600; font-style:normal; font-weight:700; }
.gd4-sort-sel {
  border:1.5px solid #E2E8F0; border-radius:8px; padding:5px 28px 5px 10px;
  font-size:12px; color:#334155; font-family:inherit; outline:none;
  background:#fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%23888'/%3E%3C/svg%3E") no-repeat right 9px center / 8px;
  -webkit-appearance:none; appearance:none; cursor:pointer;
}
.gd4-sort-sel:focus { border-color:#0066CC; box-shadow:0 0 0 3px rgba(0,102,204,.08); }

/* ─── SIDEBAR PREMIUM UPGRADE ─── */
.gd4-sb-card { background:#fff; border:1px solid #E8ECF2; border-radius:14px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,.05); }
.gd4-sb-head {
  padding:12px 16px; font-size:13px; font-weight:500; color:#1a1a1a;
  background:#F8FAFC; border-bottom: 2px solid #E2E8F0;
  display:flex; align-items:center; gap:6px;
}
.gd4-sb-head.or { border-bottom-color: #FF6600; }
.gd4-sb-head-accent { border-bottom-color: #FF6600; }
.gd4-sb-body { padding:14px 16px; }
.gd4-sf-g { margin-bottom:12px; }
.gd4-sf-l { font-size:10px; font-weight:800; color:#94A3B8; text-transform:uppercase; letter-spacing:.1em; margin-bottom:5px; }
.gd4-sf-i, .gd4-sf-s {
  width:100%; padding:8px 11px; border:1.5px solid #E2E8F0; border-radius:8px;
  font-size:12px; color:#334155; font-family:inherit; outline:none; background:#fff;
  transition:border-color .15s;
}
.gd4-sf-s { padding-right:28px; cursor:pointer; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%23888'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 9px center; background-size:8px; -webkit-appearance:none; appearance:none; }
.gd4-sf-i:focus, .gd4-sf-s:focus { border-color:#0066CC; box-shadow:0 0 0 3px rgba(0,102,204,.08); }
.gd4-sf-radio { display:flex; flex-direction:column; gap:6px; }
.gd4-sf-rl { display:flex; align-items:center; gap:7px; font-size:12px; color:#334155; cursor:pointer; }
.gd4-sf-rl input { accent-color:#FF6600; width:14px; height:14px; cursor:pointer; }
.gd4-sf-apply {
  width:100%; padding:10px; background:#FF6600; color:#fff;
  border:none; border-radius:9px; font-size:13px; font-weight:500;
  cursor:pointer; font-family:inherit; transition:all .15s; margin-top:10px;
  box-shadow:none;
}
.gd4-sf-apply:hover { background:#E55A00; }
.gd4-sf-clear { display:block; text-align:center; font-size:11px; color:#94A3B8 !important; margin-top:8px; text-decoration:none !important; transition:color .15s; }
.gd4-sf-clear:hover { color:#0066CC !important; }
.gd4-sb-list { list-style:none; margin:0; padding:0; }
.gd4-sb-list li { border-bottom:1px solid #F8FAFC; }
.gd4-sb-list li:last-child { border-bottom:none; }
.gd4-sb-list a { display:flex; align-items:center; justify-content:space-between; padding:10px 16px; font-size:12px; color:#334155 !important; text-decoration:none !important; transition:all .15s; font-weight:500; }
.gd4-sb-list a:hover { background:#FFF8F0; color:#FF6600 !important; padding-left:20px; }
.gd4-sb-cnt { background:#F1F5F9; color:#64748B; border-radius:20px; padding:2px 8px; font-size:10px; font-weight:700; }

/* Mobile filter toggle */
.gd4-mob-btn {
  display:none; width:100%; padding:11px 16px;
  background:#fff; border:1.5px solid #E2E8F0; border-radius:10px;
  font-size:13px; font-weight:700; color:#334155; cursor:pointer;
  font-family:inherit; margin-bottom:12px;
  align-items:center; justify-content:center; gap:6px;
  box-shadow:0 1px 4px rgba(0,0,0,.05);
}

/* Pills strip */
.gd4-pills-strip { background:#fff; border-bottom:1px solid #E8ECF2; padding:10px 0; }
.gd4-pills-inner { max-width:1220px; margin:0 auto; padding:0 16px; display:flex; align-items:center; gap:6px; overflow-x:auto; scrollbar-width:none; }
.gd4-pills-inner::-webkit-scrollbar { display:none; }
.gd4-pills-lbl { font-size:10px; font-weight:800; color:#94A3B8; text-transform:uppercase; letter-spacing:.1em; white-space:nowrap; flex-shrink:0; }
.gd4-pill {
  display:inline-flex; align-items:center; gap:4px;
  padding:5px 13px; border-radius:20px; font-size:11px; font-weight:700;
  border:1.5px solid #E2E8F0; background:#fff; color:#475569 !important;
  text-decoration:none !important; white-space:nowrap; flex-shrink:0;
  transition:all .15s; cursor:pointer;
}
.gd4-pill:hover, .gd4-pill.on { background:#FF6600 !important; border-color:transparent; color:#fff !important; box-shadow:none; }
.gd4-pill-n { background:rgba(0,0,0,.1); border-radius:10px; padding:1px 5px; font-size:9px; }

/* Responsive */
@media (max-width:1024px) { .gd4-body { grid-template-columns:1fr 260px; } }
@media (max-width:768px) { .gd4-header-search { max-width:200px; } .gd4-header-nav a { padding:5px 8px; font-size:12px; } .gd4-site-header-inner { gap:8px; } }
@media (max-width:900px) {
  .gd4-body { grid-template-columns:1fr; padding:10px 12px 28px; }
  .gd4-sidebar { position:static !important; display:none !important; order:-1; }
  .gd4-sidebar.open { display:flex !important; }
  .gd4-mob-btn { display:flex; }
  .gd4-thumb { width:150px; min-width:150px; min-height:170px; }
  .gd4-stats { margin-left:0; }
  .gd4-header-search { max-width:300px; }
  .gd4-results-list.grid-view { grid-template-columns:repeat(auto-fill,minmax(250px,1fr)); }
}
@media (max-width:600px) {
  .gd4-card { border-radius:12px; }
  .gd4-thumb { width:120px; min-width:120px; min-height:140px; border-radius:12px 0 0 12px; }
  .gd4-content { padding:12px; }
  .gd4-content .gd4-name { font-size:13px; }
  .gd4-desc,.gd4-tags { display:none; }
  .gd4-btn { padding:6px 10px; font-size:11px; }
  /* Mobile: hide View Details, show WhatsApp */
  .gd4-btn-book { display:none !important; }
  .gd4-btn-wa { display:inline-flex !important; order:-1; }
  .gd4-btn-web { display:none; }
  .gd4-header-search { display:none; }
  .gd4-header-nav { gap:2px; }
  .gd4-header-nav a { padding:5px 7px; font-size:11px; }
  .gd4-title-inner h1 { font-size:16px; }
  .gd4-pills-lbl { display:none; }
  .gd4-results-list.grid-view { grid-template-columns:1fr; }
  .gd4-pv-grid { grid-template-columns:1fr; }
}
.gd4-body-bg { background:#F0F2F5; }

/* FIX 2A: Sidebar sticky — top:76px clears the 60px sticky header + 16px gap.
   At top:16px the sidebar sat under the fixed header on initial paint, causing
   a visible jump as the browser repainted. */
.gd4-sidebar { display:flex; flex-direction:column; gap:12px; }
@supports (position:sticky) { .gd4-sidebar { position:sticky; top:76px; } }
html.gsab-on .gd4-sidebar { top:76px; }

/* Enquiry form */
.gd4-enq-f { width:100%; padding:8px 11px; border:1.5px solid #E2E8F0; border-radius:8px; font-size:12px; color:#334155; font-family:inherit; outline:none; margin-bottom:8px; background:#fff; transition:border-color .15s; }
.gd4-enq-f:focus { border-color:#0066CC; box-shadow:0 0 0 3px rgba(0,102,204,.08); }
.gd4-enq-f::placeholder { color:#CBD5E1; }
textarea.gd4-enq-f { resize:vertical; min-height:65px; }
.gd4-enq-btn { width:100%; padding:11px; background:#FF6600; color:#fff; border:none; border-radius:9px; font-size:13px; font-weight:500; cursor:pointer; font-family:inherit; transition:all .15s; display:flex; align-items:center; justify-content:center; gap:6px; box-shadow:none; }
.gd4-enq-btn:hover { background:#E55A00; box-shadow:none; }
.gd4-enq-status { font-size:11px; text-align:center; margin-top:6px; min-height:16px; }
───────────────────────────────────────────────────────────────*/
.gd4-footer{background:#0a1628;color:rgba(255,255,255,.6)!important;padding:52px 0 0;margin-top:32px}
.gd4-footer *{color:inherit}
.gd4-footer-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:36px;margin-bottom:40px;max-width:1220px;margin-left:auto;margin-right:auto;padding:0 16px}
.gd4-footer-brand{font-size:18px;font-weight:900;color:#fff!important;margin-bottom:12px;display:block;text-decoration:none}
.gd4-footer-brand img{height:36px;border-radius:7px;margin-bottom:10px;display:block}
.gd4-footer-about{font-size:13px;line-height:1.8;color:rgba(255,255,255,.55)!important;max-width:240px}
.gd4-footer-social{display:flex;gap:8px;margin-top:16px}
.gd4-footer-social a{width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.07);display:flex;align-items:center;justify-content:center;font-size:13px;transition:background .15s;text-decoration:none}
.gd4-footer-social a:hover{background:#FF6600}
.gd4-footer-col-title{font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#fff!important;margin-bottom:14px}
.gd4-footer-links{display:flex;flex-direction:column;gap:9px}
.gd4-footer-links a{font-size:13px;color:rgba(255,255,255,.5)!important;text-decoration:none;transition:color .15s}
.gd4-footer-links a:hover{color:#FF6600!important}
.gd4-footer-bottom{border-top:1px solid rgba(255,255,255,.07);padding:18px 16px calc(18px + env(safe-area-inset-bottom,0));display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;max-width:1220px;margin:0 auto}
.gd4-footer-copy{font-size:12px;color:rgba(255,255,255,.45)!important}
.gd4-footer-copy strong{color:rgba(255,255,255,.7)!important}
.gd4-footer-bot-links{display:flex;gap:16px}
.gd4-footer-bot-links a{font-size:12px;color:rgba(255,255,255,.45)!important;text-decoration:none;transition:color .15s}
.gd4-footer-bot-links a:hover{color:rgba(255,255,255,.8)!important}
.gd4-footer-cities{border-top:1px solid rgba(255,255,255,.06);padding:20px 16px;max-width:1220px;margin:0 auto}
.gd4-footer-cities-title{font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#fff!important;margin-bottom:10px}
.gd4-footer-city-links{display:flex;flex-wrap:wrap;gap:8px}
.gd4-footer-city-links a{font-size:12px;color:rgba(255,255,255,.45)!important;text-decoration:none;transition:color .15s}
.gd4-footer-city-links a:hover{color:#FF6600!important}

/* FIX 1: Footer text visibility
   Root cause: critical_css() injects a{color:var(--gs-primary)} globally.
   The footer is outside .gd4-page so the page-scoped link reset doesn't apply.
   Fix: use html body selector chain to achieve highest non-!important specificity,
   then !important where needed to beat the global rule.  */
html body .gd4-footer { color:rgba(255,255,255,.6) !important; }
html body .gd4-footer * { color:inherit; }
html body .gd4-footer a { color:rgba(255,255,255,.5) !important; text-decoration:none; transition:color .15s; }
html body .gd4-footer a:hover { color:#FF6600 !important; }
html body .gd4-footer-brand { color:#fff !important; font-weight:900; }
html body .gd4-footer-col-title { color:#fff !important; }
html body .gd4-footer-copy { color:rgba(255,255,255,.45) !important; }
html body .gd4-footer-copy strong { color:rgba(255,255,255,.7) !important; }
html body .gd4-footer-about { color:rgba(255,255,255,.55) !important; }
html body .gd4-footer-links a { color:rgba(255,255,255,.5) !important; }
html body .gd4-footer-links a:hover { color:#FF6600 !important; }
html body .gd4-footer-bot-links a { color:rgba(255,255,255,.45) !important; }
html body .gd4-footer-bot-links a:hover { color:rgba(255,255,255,.8) !important; }
html body .gd4-footer-city-links a { color:rgba(255,255,255,.45) !important; }
html body .gd4-footer-city-links a:hover { color:#FF6600 !important; }
html body .gd4-footer-social a { color:rgba(255,255,255,.6) !important; }
html body .gd4-footer-social a:hover { color:#fff !important; }

@media(max-width:900px){
  .gd4-footer-grid{grid-template-columns:1fr 1fr;gap:22px}
}
@media(max-width:540px){
  /* Keep 2 cols on phone — single col is too long */
  .gd4-footer-grid{grid-template-columns:1fr 1fr;gap:16px}
  .gd4-footer-about{max-width:100%}
  .gd4-footer-links a{font-size:12px}
}
@media(max-width:380px){
  .gd4-footer-grid{grid-template-columns:1fr}
}
</style>

<?php
/* Breadcrumb */
$bc = [['Home', home_url('/')]];
if ($cur_cat) { $bc[]=[ 'Directory', home_url('/directory/')]; $bc[]=[ esc_html($cur_cat->name), null]; }
elseif ($keyword) { $bc[]=[ 'Directory', home_url('/directory/')]; $bc[]=[ 'Search', null]; }
else { $bc[]=[ 'Directory', null]; }

// Real feature: BreadcrumbList schema built from the SAME $bc array that
// renders the visible breadcrumb nav just below, so schema and UI can
// never diverge. Last item has no url (schema.org convention for the
// current page). Kept separate from the ItemList schema above (different
// @type, both valid on one page per schema.org).
$_bc_items = [];
foreach ($bc as $_bc_i => $_bc_row) {
    $_bc_entry = [
        '@type'    => 'ListItem',
        'position' => $_bc_i + 1,
        'name'     => wp_strip_all_tags($_bc_row[0]),
    ];
    if (!empty($_bc_row[1])) { $_bc_entry['item'] = esc_url_raw($_bc_row[1]); }
    $_bc_items[] = $_bc_entry;
}
echo '<script type="application/ld+json">' . wp_json_encode([
    '@context'        => 'https://schema.org',
    '@type'            => 'BreadcrumbList',
    'itemListElement' => $_bc_items,
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
?>

<div class="gd4-page">

<!-- ══════════════════════════════════════════════
     SITE HEADER (missing from previous versions)
══════════════════════════════════════════════ -->
<header class="gd4-site-header">
  <div class="gd4-site-header-inner">

    <!-- Logo / Site name -->
    <a href="<?php echo esc_url(home_url('/')); ?>" class="gd4-site-logo">
      <?php if ($plogo): ?>
        <img src="<?php echo esc_url($plogo); ?>" alt="<?php echo esc_attr($pname); ?>" class="gd4-logo-img">
      <?php else: ?>
        <div>
          <span class="gd4-logo-text"><?php echo esc_html($pname); ?></span>
          <span class="gd4-logo-tagline">Find Trusted Service Providers</span>
        </div>
      <?php endif; ?>
    </a>

    <!-- Header search -->
    <form class="gd4-header-search" onsubmit="event.preventDefault();gdSearch4()">
      <input type="text" id="gd4-hsearch" placeholder="Search services, vendors…"
             value="<?php echo esc_attr($keyword); ?>">
      <button type="submit" aria-label="Search directory">🔍</button>
    </form>

    <!-- Nav links -->
    <nav class="gd4-header-nav">
      <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
      <a href="<?php echo $dir_url; ?>">Directory</a>
      <?php if (is_user_logged_in()): ?>
        <a href="<?php echo esc_url(home_url('/vendor/dashboard/')); ?>">Dashboard</a>
      <?php else: ?>
        <a href="<?php echo esc_url(home_url('/login/')); ?>">Login</a>
      <?php endif; ?>
      <a href="<?php echo esc_url(home_url('/create-listing/')); ?>" class="gd4-header-cta">+ List Business</a>
    </nav>
  </div>
</header>

<!-- ── Breadcrumb ─────────────────────────────────────────────── -->
<div class="gd4-bc">
  <div class="gd4-bc-inner">
    <?php foreach ($bc as $i => [$lbl,$href]): ?>
      <?php if($i>0): ?><span class="sep">›</span><?php endif; ?>
      <?php if($href): ?><a href="<?php echo esc_url($href); ?>"><?php echo $lbl; ?></a><?php else: ?><span><?php echo $lbl; ?></span><?php endif; ?>
    <?php endforeach; ?>
  </div>
</div>

<!-- ── Page title ─────────────────────────────────────────────── -->
<div class="gd4-title-strip">
  <div class="gd4-title-inner" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:12px">
    <div>
      <h1><?php echo $page_title; ?></h1>
      <p class="gd4-title-sub"><?php echo number_format($total); ?> listing<?php echo $total!==1?'s':''; ?> found<?php echo $city ? ' in '.esc_html($city):''; ?></p>
    </div>
    <?php if($total >= 3 && $category_id): ?>
    <button onclick="document.getElementById('gd4-multi-quote-bar').style.display=document.getElementById('gd4-multi-quote-bar').style.display==='none'?'block':'none'"
            style="background:linear-gradient(135deg,#2563EB,#7C3AED);color:#fff;border:none;border-radius:10px;padding:10px 18px;font-size:.84rem;font-weight:700;cursor:pointer;flex-shrink:0;white-space:nowrap">
      ⚡ Get quotes from multiple vendors
    </button>
    <?php endif; ?>
  </div>
</div>

<!-- Part 14.1 — Multi-quote request panel -->
<?php if($total >= 3 && $category_id): ?>
<div id="gd4-multi-quote-bar" style="display:none;background:linear-gradient(135deg,#EFF6FF,#F5F3FF);border:1.5px solid #BFDBFE;border-radius:12px;padding:20px;margin:12px 0">
  <div style="font-weight:700;font-size:.95rem;color:#1E3A5F;margin-bottom:6px">⚡ Get quotes from up to 3 vendors at once</div>
  <div style="font-size:.82rem;color:#475569;margin-bottom:14px">Fill one form — we'll send it to the top 3 verified vendors in this category. Compare their quotes and choose the best.</div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
    <div><label style="font-size:.74rem;font-weight:700;color:#64748B;display:block;margin-bottom:4px">Your Name *</label>
      <input id="mqf-name" style="width:100%;padding:8px 11px;border:1.5px solid #E2E8F0;border-radius:7px;font-size:.84rem;font-family:inherit;outline:none" placeholder="Full name"></div>
    <div><label style="font-size:.74rem;font-weight:700;color:#64748B;display:block;margin-bottom:4px">Phone *</label>
      <input id="mqf-phone" style="width:100%;padding:8px 11px;border:1.5px solid #E2E8F0;border-radius:7px;font-size:.84rem;font-family:inherit;outline:none" placeholder="+91 XXXXX XXXXX" type="tel"></div>
    <div><label style="font-size:.74rem;font-weight:700;color:#64748B;display:block;margin-bottom:4px">Email *</label>
      <input id="mqf-email" style="width:100%;padding:8px 11px;border:1.5px solid #E2E8F0;border-radius:7px;font-size:.84rem;font-family:inherit;outline:none" placeholder="you@email.com" type="email"></div>
    <div><label style="font-size:.74rem;font-weight:700;color:#64748B;display:block;margin-bottom:4px">City *</label>
      <input id="mqf-city" style="width:100%;padding:8px 11px;border:1.5px solid #E2E8F0;border-radius:7px;font-size:.84rem;font-family:inherit;outline:none" placeholder="Your city" value="<?php echo esc_attr($city); ?>"></div>
  </div>
  <div><label style="font-size:.74rem;font-weight:700;color:#64748B;display:block;margin-bottom:4px">Describe your requirement *</label>
    <textarea id="mqf-msg" style="width:100%;padding:8px 11px;border:1.5px solid #E2E8F0;border-radius:7px;font-size:.84rem;font-family:inherit;resize:vertical;min-height:70px;outline:none" placeholder="What do you need? Be as specific as possible..."></textarea>
  </div>
  <div style="display:flex;gap:10px;margin-top:12px;align-items:center">
    <button id="mqf-submit" onclick="gd4SubmitMultiQuote('<?php echo esc_js($category_slug??''); ?>')"
            style="background:#2563EB;color:#fff;border:none;border-radius:9px;padding:10px 24px;font-size:.88rem;font-weight:700;cursor:pointer;font-family:inherit">
      Submit to 3 Vendors →
    </button>
    <div id="mqf-status" style="font-size:.8rem;color:#64748B"></div>
  </div>
</div>
<script>
function gd4SubmitMultiQuote(category) {
  var name  = document.getElementById('mqf-name').value.trim();
  var phone = document.getElementById('mqf-phone').value.trim();
  var email = document.getElementById('mqf-email').value.trim();
  var city  = document.getElementById('mqf-city').value.trim();
  var msg   = document.getElementById('mqf-msg').value.trim();
  var status= document.getElementById('mqf-status');
  var btn   = document.getElementById('mqf-submit');
  if (!name||!phone||!msg) { status.textContent='Please fill all required fields.'; status.style.color='#DC2626'; return; }
  btn.disabled=true; btn.textContent='Sending…';
  var fd=new FormData();
  fd.append('action','gs_submit_multi_quote_inquiry');
  fd.append('nonce', window.GS&&GS.nonce?GS.nonce:'');
  fd.append('category',category); fd.append('name',name);
  fd.append('phone',phone); fd.append('email',email);
  fd.append('city',city); fd.append('message',msg);
  fetch(window.GS&&GS.ajax_url?GS.ajax_url:'/wp-admin/admin-ajax.php',{method:'POST',body:fd})
    .then(r=>r.json()).then(d=>{
      if(d.success){
        status.style.color='#059669';
        status.textContent='✅ Sent to 3 vendors! Check your email for comparison link.';
        btn.textContent='✅ Submitted';
      } else {
        status.style.color='#DC2626';
        status.textContent=d.data&&d.data.message?d.data.message:'Failed. Please try again.';
        btn.disabled=false; btn.textContent='Submit to 3 Vendors →';
      }
    })
    // Real fix — without this, a network error left the button stuck on
    // "Sending…" and permanently disabled with no way to retry — a dead
    // end on a public lead-generation form.
    .catch(function(){
      status.style.color='#DC2626';
      status.textContent='Network error — could not reach the server. Please try again.';
      btn.disabled=false; btn.textContent='Submit to 3 Vendors →';
    });
}
</script>
<?php endif; ?>

<!-- ── Locality pills ─────────────────────────────────────────── -->
<?php if ($city_counts): ?>
<div class="gd4-pills-strip">
  <div class="gd4-pills-inner">
    <span class="gd4-pills-lbl">Filter:</span>
    <a href="#" class="gd4-pill <?php echo (!$city&&!$category_id)?'on':''; ?>"
       data-filter-type="all"
       onclick="event.preventDefault();gd4FilterBy('clear','')">All</a>
    <?php foreach ($city_counts as $cc): ?>
    <a href="#"
       class="gd4-pill <?php echo $city===$cc->city?'on':''; ?>"
       data-city="<?php echo esc_attr($cc->city); ?>"
       onclick="event.preventDefault();gd4FilterBy('city','<?php echo esc_js($cc->city); ?>')">
      <?php echo esc_html($cc->city); ?><span class="gd4-pill-n"><?php echo $cc->n; ?></span>
    </a>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- ── Two-column body ────────────────────────────────────────── -->
<div class="gd4-body gd4-body-bg">

  <!-- ════════════════════════  LEFT: RESULTS  ═══════════════ -->
  <div>

    <!-- Mobile toggle -->
    <button class="gd4-mob-btn"
      onclick="var s=document.getElementById('gd4-sb');s.classList.toggle('open');this.textContent=s.classList.contains('open')?'✕ Close Filters':'⚙ Filters & Options'">
      ⚙ Filters &amp; Options
    </button>

    <!-- Results bar -->
    <div class="gd4-rbar">
      <div class="gd4-rbar-count">
        Showing <strong><?php echo min($offset+$per_page,$total); ?></strong> of <strong><?php echo number_format($total); ?></strong>
        <?php if($city): ?> in <strong><?php echo esc_html($city); ?></strong><?php endif; ?>
        <?php if($keyword): ?> for <em>"<?php echo esc_html($keyword); ?>"</em><?php endif; ?>
      </div>
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
        <div class="gd4-sort-row">
          <span class="gd4-sort-lbl">Sort by:</span>
          <select class="gd4-sort-sel" id="gd4-sort" onchange="gdSearch4()">
            <?php foreach(['featured'=>'Featured First','rating'=>'Highest Rated','reviews'=>'Most Reviewed','views'=>'Most Viewed','newest'=>'Newest First'] as $sv=>$sl): ?>
            <option value="<?php echo $sv; ?>" <?php echo $sort===$sv?'selected':''; ?>><?php echo $sl; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="gd4-view-toggle" role="group" aria-label="View mode">
          <button class="gd4-vt-btn on" id="gd4-list-btn" onclick="gd4SetView('list')" title="List view" aria-pressed="true">☰</button>
          <button class="gd4-vt-btn" id="gd4-grid-btn" onclick="gd4SetView('grid')" title="Grid view" aria-pressed="false">⊞</button>
        </div>
      </div>
    </div>

    <!-- ── Listing cards ─────────────────────────────────────── -->
    <div class="gd4-results-list" id="gd4-results-list">
    <?php if ($listings): foreach ($listings as $idx => $l):
      $lurl      = esc_url(home_url('/'.$l->slug.'/'));
      $thumb     = ($l->banner_url??'') ?: ($l->logo_url??'');
      $wa_num    = preg_replace('/[^0-9]/','', (string)($l->whatsapp??'') ?: (string)($l->vendor_wa??''));
      $phone     = trim($l->phone??'');
      $masked_ph = $phone ? gda_mask($phone) : '';
      $tags      = array_filter(array_map('trim', explode(',', $l->tags??'')));
      $svc_cities= [];
      if (!empty($l->service_cities)){$d=json_decode($l->service_cities,true);if(is_array($d))$svc_cities=array_filter($d);}
      $ostat     = gda_open_status((string)($l->opening_hours??''));
      $verified  = ($l->verification_status??'')==='verified' || ($l->vp_v??'')==='verified';
      $addr_parts = array_filter(array_map(function($v){ return rtrim(trim($v),', '); }, [$l->address??'',$l->city??'',$l->pincode??'']), function($v){ return $v!==''; });
      $addr       = implode(', ', $addr_parts);
      $desc      = trim($l->short_desc??$l->tagline??'');
      $tagline   = trim($l->tagline??'');
      $sf        = min(5,(int)round((float)$l->avg_rating));
      $is_popular = !empty($l->is_popular) || ($l->views_count??0) > 500 || ($l->review_count??0) > 10;
      $is_new    = !empty($l->created_at) && (time() - strtotime($l->created_at)) < 30*86400;
      $card_price_min = isset($l->price_min) && $l->price_min > 0 ? (float)$l->price_min : null;
      $card_price_max = isset($l->price_max) && $l->price_max > 0 ? (float)$l->price_max : null;
      $resp_time = 0; // response time not fetched (column may not exist in all installs)
      $avail_status = !empty($ostat) ? ($ostat['t']==='open' ? 'available' : 'unavailable') : '';
      // Portfolio images
      $portfolio_imgs = [];
      if (!empty($l->gallery)) {
          $g = json_decode($l->gallery, true);
          if (is_array($g)) $portfolio_imgs = array_filter(array_column($g,'url') ?: array_values($g));
      }
      if (empty($portfolio_imgs) && !empty($l->portfolio_data)) {
          $g = json_decode($l->portfolio_data, true);
          if (is_array($g)) foreach($g as $item) if(!empty($item['image_url'])) $portfolio_imgs[]=$item['image_url'];
      }
      // Website URL
      $website_url = trim($l->website??'');
      $vp_rr  = (float)($l->vp_response_rate ?? 0);
    ?>

    <div class="gd4-card<?php echo !empty($l->is_featured) ? ' gd4-featured' : ''; ?>"
         data-lat="<?php echo esc_attr($l->lat??''); ?>"
         data-lng="<?php echo esc_attr($l->lng??''); ?>"
         data-id="<?php echo (int)$l->id; ?>"
         data-href="<?php echo $lurl; ?>"
         onclick="gd4CardClick(event,this)"
         data-listing='<?php echo esc_attr(json_encode([
           "id"=>(int)$l->id,"title"=>$l->title,"slug"=>$l->slug,
           "tagline"=>$tagline,"desc"=>$desc,"thumb"=>$thumb,
           "rating"=>(float)$l->avg_rating,"reviews"=>(int)$l->review_count,
           "phone"=>$phone,"wa"=>$wa_num,"website"=>$website_url,
           "verified"=>$verified,"cat"=>$l->cat_name??'',
           "addr"=>$addr,"tags"=>array_slice($tags,0,8),
           "price_min"=>$card_price_min,"price_max"=>$card_price_max,
           "portfolio"=>array_values(array_slice($portfolio_imgs,0,4)),
         ])); ?>'
         style="position:relative">

      <!-- Featured / Popular / New badges -->
      <?php if (!empty($l->is_featured)): ?>
      <span class="gd4-featured-label" aria-label="Featured listing">⭐ Featured</span>
      <?php elseif ($is_popular): ?>
      <span class="gd4-featured-label" style="background:#FEE2E2;color:#991B1B" aria-label="Popular listing">🔥 Popular</span>
      <?php elseif ($is_new): ?>
      <span class="gd4-featured-label" style="background:#DBEAFE;color:#1E40AF" aria-label="Newly added">✨ New</span>
      <?php endif; ?>

      <!-- Availability dot -->
      <?php if ($avail_status): ?>
      <span class="gd4-avail-dot <?php echo $avail_status; ?>" title="<?php echo $avail_status==='available'?'Open now':'Closed'; ?>"></span>
      <?php endif; ?>

      <!-- Thumbnail -->
      <a href="<?php echo $lurl; ?>" class="gd4-thumb" aria-label="<?php echo esc_attr($l->title); ?>">
        <?php if ($thumb): ?>
          <img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr($l->title); ?>" loading="lazy">
        <?php else: ?>
          <div class="gd4-thumb-ph">🏢</div>
        <?php endif; ?>
        <!-- Portfolio strip -->
        <?php if (count($portfolio_imgs) >= 2): ?>
        <div class="gd4-thumb-strip">
          <?php foreach(array_slice($portfolio_imgs,0,3) as $pi): ?>
          <img src="<?php echo esc_url($pi); ?>" class="gd4-thumb-mini" alt="" loading="lazy">
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <!-- Quick preview button -->
        <button class="gd4-quick-prev-btn"
                onclick="event.preventDefault();event.stopPropagation();gd4QuickPreview(this.closest('.gd4-card').dataset.listing)"
                aria-label="Quick preview <?php echo esc_attr($l->title); ?>">
          👁 Quick View
        </button>
      </a>

      <!-- Content -->
      <div class="gd4-content">

        <!-- Title + badges -->
        <div class="gd4-title-row">
          <a href="<?php echo $lurl; ?>" class="gd4-name"><?php echo esc_html($l->title); ?></a>
          <?php if ($verified): ?><span class="gd4-badge-v">✓ Verified</span><?php endif; ?>
          <?php if ($is_popular && empty($l->is_featured)): ?><span class="gd4-badge-popular">🔥 Popular</span><?php endif; ?>
          <?php if ($is_new && !$is_popular && empty($l->is_featured)): ?><span class="gd4-badge-new">✨ New</span><?php endif; ?>
          <?php if (!empty($l->cat_name)): ?><span class="gd4-badge-cat"><?php echo esc_html($l->cat_name); ?></span><?php endif; ?>
        </div>

        <!-- Tagline / USP -->
        <?php if ($tagline): ?>
        <div class="gd4-tagline">"<?php echo esc_html($tagline); ?>"</div>
        <?php endif; ?>

        <!-- Address -->
        <?php if ($addr): ?>
        <div class="gd4-addr">
          <span class="gd4-pin">📍</span>
          <span><?php echo esc_html($addr); ?></span>
        </div>
        <?php endif; ?>

        <!-- Rating + open status -->
        <div class="gd4-meta">
          <?php if ($l->avg_rating > 0): ?>
            <div class="gd4-stars">
              <?php for($s=1;$s<=5;$s++): ?><span class="gd4-star <?php echo $s<=$sf?'on':''; ?>">★</span><?php endfor; ?>
            </div>
            <span class="gd4-score"><?php echo number_format($l->avg_rating,1); ?></span>
            <span class="gd4-rcount">(<?php echo intval($l->review_count); ?>)</span>
            <span class="gd4-sep">·</span>
          <?php endif; ?>
          <?php if ($ostat): ?>
            <span class="gd4-open <?php echo $ostat['t']; ?>"><?php echo $ostat['t']==='open'?'🟢 Open':'🔴 Closed'; ?></span>
            <span class="gd4-open-time"><?php echo esc_html($ostat['s']); ?></span>
          <?php endif; ?>
        </div>

        <!-- Price + response time pills (Verified label is already in title row — not duplicated here) -->
        <div style="display:flex;flex-wrap:wrap;gap:5px;margin:6px 0">
          <?php if ($vp_rr >= 90): ?>
            <span class="gd4-resp-time">⚡ Fast Reply</span>
          <?php elseif ($vp_rr >= 70): ?>
            <span class="gd4-resp-time">💬 <?php echo round($vp_rr,0); ?>% reply rate</span>
          <?php endif; ?>
          <?php if ($card_price_min || $card_price_max): ?>
            <span class="gd4-price-range">
              💰 <?php
                if ($card_price_min && $card_price_max) echo '₹'.number_format($card_price_min).' – ₹'.number_format($card_price_max);
                elseif ($card_price_min) echo 'From ₹'.number_format($card_price_min);
                else echo 'Up to ₹'.number_format($card_price_max);
              ?>
            </span>
          <?php endif; ?>
          <?php if ($resp_time > 0): ?>
            <span class="gd4-resp-time">⏱ Responds in <?php echo $resp_time < 60 ? $resp_time.'m' : round($resp_time/60,1).'h'; ?></span>
          <?php endif; ?>
        </div>

        <!-- Info row (est, type, distance, views, leads) -->
        <div class="gd4-info">
          <?php if ($l->established_year): ?><span>🗓 Est. <?php echo esc_html($l->established_year); ?></span><?php endif; ?>
          <?php if ($l->listing_type): ?><span>·</span><span><?php echo ucfirst(esc_html($l->listing_type)); ?></span><?php endif; ?>
          <?php if (($l->leads_count??0) > 0): ?>
            <span class="gd4-enquiry-cnt">·</span>
            <span class="gd4-enquiry-cnt">📞 <?php echo number_format($l->leads_count); ?> enquiries</span>
          <?php endif; ?>
          <span class="gd4-dist-<?php echo (int)$l->id; ?>" style="display:none">
            <span>·</span><span>📍 <span class="gd4-dist-val">—</span> km away</span>
          </span>
        </div>

        <!-- Description -->
        <?php if ($desc): ?><div class="gd4-desc"><?php echo esc_html($desc); ?></div><?php endif; ?>

        <!-- Service tags -->
        <?php if ($tags): ?>
        <div class="gd4-tags">
          <?php foreach (array_slice($tags,0,5) as $tag): ?>
            <a href="<?php echo esc_url(home_url('/directory/?keyword='.urlencode(trim($tag)))); ?>"
               class="gd4-tag"><?php echo esc_html(trim($tag)); ?></a>
          <?php endforeach; ?>
          <?php if (count($tags)>5): ?><span class="gd4-tag gd4-tag-x">+<?php echo count($tags)-5; ?> more</span><?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- Cities -->
        <?php if ($svc_cities): ?>
        <div class="gd4-cities">
          <strong>Serves:</strong>
          <?php $cl=[];foreach(array_slice($svc_cities,0,3) as $sc) $cl[]='<a href="'.esc_url(home_url('/directory/?city='.urlencode($sc))).'">'.esc_html($sc).'</a>'; echo implode(', ',$cl); if(count($svc_cities)>3) echo ' <span style="color:#94A3B8">+'.( count($svc_cities)-3).' more</span>'; ?>
        </div>
        <?php endif; ?>

        <!-- Actions -->
        <div class="gd4-actions">
          <?php if ($phone): ?>
          <button class="gd4-btn gd4-btn-num"
            onclick="event.stopPropagation();gdReveal4(this,'<?php echo esc_js($phone); ?>',<?php echo (int)$l->id; ?>)"
            aria-label="Call <?php echo esc_attr($l->title); ?>">
            📞 <?php echo esc_html($masked_ph); ?>
          </button>
          <?php endif; ?>

          <a href="<?php echo $lurl; ?>"
             class="gd4-btn gd4-btn-book"
             data-track="view" data-listing-id="<?php echo (int)$l->id; ?>"
             onclick="event.stopPropagation()"
             aria-label="View details for <?php echo esc_attr($l->title); ?>">
            View Details →
          </a>

          <?php if ($wa_num): ?>
          <a href="https://wa.me/<?php echo esc_attr($wa_num); ?>?text=Hi+<?php echo urlencode($l->title); ?>"
             target="_blank" rel="noopener"
             class="gd4-btn gd4-btn-wa"
             data-track="whatsapp_click" data-listing-id="<?php echo (int)$l->id; ?>"
             onclick="event.stopPropagation()"
             aria-label="WhatsApp <?php echo esc_attr($l->title); ?>">
            💬 WhatsApp
          </a>
          <?php endif; ?>

          <?php if ($website_url): ?>
          <a href="<?php echo esc_url($website_url); ?>" target="_blank" rel="noopener"
             class="gd4-btn gd4-btn-web"
             data-track="website_click" data-listing-id="<?php echo (int)$l->id; ?>"
             onclick="event.stopPropagation()"
             aria-label="Visit website of <?php echo esc_attr($l->title); ?>">
            🌐 Website
          </a>
          <?php endif; ?>

          <!-- Save to wishlist -->
          <button class="gd4-btn gd4-btn-save" data-id="<?php echo (int)$l->id; ?>"
                  onclick="event.stopPropagation();gd4ToggleSave(this,<?php echo (int)$l->id; ?>)"
                  aria-label="Save <?php echo esc_attr($l->title); ?> to wishlist"
                  title="Save to wishlist">
            🤍
          </button>

          <!-- Copy listing link -->
          <button class="gd4-btn gd4-btn-share"
                  onclick="event.stopPropagation();gd4CopyLink(this,'<?php echo esc_js($lurl); ?>')"
                  aria-label="Copy link to <?php echo esc_attr($l->title); ?>"
                  title="Copy link">
            🔗
          </button>

          <div class="gd4-stats">
            <span class="gd4-stat-v">👁 <?php echo number_format($l->views_count); ?></span>
          </div>
        </div>

      </div><!-- .gd4-content -->
    </div><!-- .gd4-card -->

    <?php endforeach; else: ?>
    <div class="gd4-empty">
      <div style="font-size:3rem">🔍</div>
      <h3>No listings found</h3>
      <p>Try different keywords, or <a href="<?php echo esc_url(home_url('/directory/')); ?>">browse all listings</a>.</p>
    </div>
    <?php endif; ?>
    </div><!-- .gd4-results-list -->

    <!-- Pagination -->
    <?php
    // Keyset pagination — Prev/Next only. No numbered pages. Fast at any scale.
    if ( $ks_has_prev || $ks_has_next ):
        // Build Prev URL: pass first item's cursor values so we can seek backward
        $prev_params = $ks_has_prev && $ks_first ? array_merge( $base_q, [
            'page'          => max(1, $page - 1),
            'first_id'      => (int)    $ks_first->id,
            'first_score'   => (float)  ($ks_first->ranking_score ?? 0),
            'first_feat'    => (int)    ($ks_first->is_featured ?? 0),
            'first_rating'  => (float)  ($ks_first->avg_rating ?? 0),
            'last_id'       => 0,
        ] ) : [];

        // Build Next URL: pass last item's cursor values so we seek forward
        $next_params = $ks_has_next && $ks_last ? array_merge( $base_q, [
            'page'         => $page + 1,
            'last_id'      => (int)    $ks_last->id,
            'last_score'   => (float)  ($ks_last->ranking_score ?? 0),
            'last_feat'    => (int)    ($ks_last->is_featured ?? 0),
            'last_rating'  => (float)  ($ks_last->avg_rating ?? 0),
            'first_id'     => 0,
        ] ) : [];
    ?>
    <div class="gd4-pagination" id="gd4-pagination">
      <?php if ( $ks_has_prev && $prev_params ): ?>
        <a href="<?php echo gd4_ks_url( [], $prev_params ); ?>" class="gd4-pg">‹ Previous</a>
      <?php endif; ?>

      <span class="gd4-pg gd4-pg-info" style="cursor:default">
        Page <?php echo $page; ?>
        <?php if($total>0): ?>&nbsp;·&nbsp;<?php echo number_format($total); ?> results<?php endif; ?>
      </span>

      <?php if ( $ks_has_next && $next_params ): ?>
        <a href="<?php echo gd4_ks_url( [], $next_params ); ?>" class="gd4-pg">Next ›</a>
      <?php endif; ?>
    </div>
    <?php
    // Real feature, item 9 from the audit: rel=next/prev — reuses the
    // exact same already-computed cursor params and URL function used by
    // the visible buttons above, rather than duplicating the keyset
    // pagination logic separately (which would risk silent divergence
    // from the real, working pagination system over time). Low priority —
    // Google deprecated this as a ranking/indexing signal in 2019 — but
    // still has minor value for Bing and accessibility tooling.
    if ( $ks_has_prev && $prev_params ) {
        echo '<link rel="prev" href="' . esc_url( gd4_ks_url( [], $prev_params ) ) . '">';
    }
    if ( $ks_has_next && $next_params ) {
        echo '<link rel="next" href="' . esc_url( gd4_ks_url( [], $next_params ) ) . '">';
    }
    ?>
    <?php endif; ?>

  </div><!-- left column -->


  <!-- ══════════════════════  RIGHT: SIDEBAR  ════════════════ -->
  <div class="gd4-sidebar" id="gd4-sb">

    <!-- Filter panel -->
    <div class="gd4-sb-card">
      <div class="gd4-sb-head gd4-sb-head-accent">⚙ Filter Results</div>
      <div class="gd4-sb-body">
        <div class="gd4-sf-g">
          <div class="gd4-sf-l">Keyword</div>
          <input type="text" id="gd4-kw" class="gd4-sf-i" placeholder="Search services…" value="<?php echo esc_attr($keyword); ?>">
        </div>
        <div class="gd4-sf-g">
          <div class="gd4-sf-l">Location</div>
          <select id="gd4-city" class="gd4-sf-s">
            <option value="">All Locations</option>
            <?php foreach ($all_cities_f as $c): ?><option value="<?php echo esc_attr($c->city); ?>" <?php echo $city===$c->city?'selected':''; ?>><?php echo esc_html($c->city); ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="gd4-sf-g">
          <div class="gd4-sf-l">Category</div>
          <select id="gd4-cat" class="gd4-sf-s">
            <option value="">All Categories</option>
            <?php foreach ($all_cats as $c): ?><option value="<?php echo $c->id; ?>" <?php echo $category_id==$c->id?'selected':''; ?>><?php echo esc_html($c->name); ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="gd4-sf-g">
          <div class="gd4-sf-l">Listing Type</div>
          <div class="gd4-sf-radio">
            <?php foreach([['','All Types'],['service','Services'],['product','Products']] as $t): ?>
            <label class="gd4-sf-rl"><input type="radio" name="gd4-type" value="<?php echo $t[0]; ?>" <?php echo $type_filter===$t[0]?'checked':''; ?>><?php echo $t[1]; ?></label>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="gd4-sf-g">
          <div class="gd4-sf-l">Minimum Rating</div>
          <div class="gd4-sf-radio">
            <?php foreach([[0,'Any Rating'],[3,'⭐⭐⭐ 3+'],[4,'⭐⭐⭐⭐ 4+'],[4.5,'⭐⭐⭐⭐⭐ 4.5+']] as $r): ?>
            <label class="gd4-sf-rl"><input type="radio" name="gd4-rating" value="<?php echo $r[0]; ?>" <?php echo $min_rating==$r[0]?'checked':''; ?>><?php echo $r[1]; ?></label>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="gd4-sf-g">
          <div class="gd4-sf-l">Price Range (&#8377;)</div>
          <div style="display:flex;gap:8px;align-items:center">
            <input type="number" id="gd4-price-min" class="gd4-sf-i" placeholder="Min" min="0" style="flex:1" value="<?php echo $price_min!==null?esc_attr($price_min):''; ?>">
            <span style="color:#94A3B8;font-size:.8rem">to</span>
            <input type="number" id="gd4-price-max" class="gd4-sf-i" placeholder="Max" min="0" style="flex:1" value="<?php echo $price_max!==null?esc_attr($price_max):''; ?>">
          </div>
        </div>
        <div class="gd4-sf-g">
          <label class="gd4-sf-rl" style="display:flex;align-items:center;gap:8px">
            <input type="checkbox" id="gd4-verified" <?php echo $verified_only?'checked':''; ?>>
            <span>&#9989; Verified vendors only</span>
          </label>
          <label class="gd4-sf-rl" style="display:flex;align-items:center;gap:8px;margin-top:6px">
            <input type="checkbox" id="gd4-bookable" <?php echo $bookable_only?'checked':''; ?>>
            <span>&#128197; Accepts online booking</span>
          </label>
          <label class="gd4-sf-rl" style="display:flex;align-items:center;gap:8px;margin-top:6px">
            <input type="checkbox" id="gd4-avail-today" <?php echo $avail_today?'checked':''; ?>>
            <span>📅 Available today</span>
          </label>
          <label class="gd4-sf-rl" style="display:flex;align-items:center;gap:8px;margin-top:6px">
            <input type="checkbox" id="gd4-avail-week" <?php echo $avail_week?'checked':''; ?>>
            <span>📆 Available this week</span>
          </label>
        </div>
        <button class="gd4-sf-apply" onclick="gdSearch4()">Apply Filters</button>
        <a href="<?php echo esc_url(home_url('/directory/')); ?>" class="gd4-sf-clear">Clear All Filters</a>
      </div>
    </div>

    <!-- Listings by location — searchable, scalable to 300+ cities -->
    <?php if ($city_counts): ?>
    <div class="gd4-sb-card" id="gd4-city-card">
      <div class="gd4-sb-head">📍 Listings by Location</div>
      <div style="padding:10px 14px 0">
        <div style="position:relative">
          <input type="text" id="gd4-city-search" placeholder="Search city…"
            style="width:100%;border:1.5px solid #E2E8F0;border-radius:8px;padding:7px 10px 7px 28px;font-size:.8rem;box-sizing:border-box;outline:none;font-family:inherit"
            oninput="gd4CitySearch(this.value)" autocomplete="off">
          <span style="position:absolute;left:8px;top:50%;transform:translateY(-50%);font-size:.8rem;color:#94A3B8">🔍</span>
          <div id="gd4-city-drop" style="display:none;position:absolute;top:calc(100% + 2px);left:0;right:0;background:#fff;border:1.5px solid #E2E8F0;border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,.1);z-index:200;max-height:200px;overflow-y:auto"></div>
        </div>
      </div>
      <ul class="gd4-sb-list" style="margin-top:8px">
        <?php foreach ($city_counts as $cc): ?>
        <li><a href="#"
               data-city="<?php echo esc_attr($cc->city); ?>"
               onclick="event.preventDefault();gd4FilterBy('city','<?php echo esc_js($cc->city); ?>')"><?php echo esc_html($cc->city); ?><span class="gd4-sb-cnt"><?php echo $cc->n; ?></span></a></li>
        <?php endforeach; ?>
      </ul>
      <?php if ($total_cities > 8): ?>
      <div style="padding:8px 14px 12px;text-align:center">
        <button onclick="gd4ShowAllCities()" style="background:none;border:none;color:#FF6600;font-size:.78rem;font-weight:700;cursor:pointer;font-family:inherit">
          + Show all <?php echo $total_cities; ?> cities
        </button>
      </div>
      <?php endif; ?>
    </div>
    <script>
    /* Highlight active city in sidebar list on page load */
    (function() {
      var activeCity = '<?php echo esc_js($city); ?>';
      if (!activeCity) return;
      document.querySelectorAll('#gd4-city-card .gd4-sb-list a').forEach(function(a) {
        if (a.getAttribute('data-city') === activeCity) {
          a.style.background  = '#FFF8F0';
          a.style.color       = '#FF6600';
          a.style.fontWeight  = '700';
          a.style.borderLeft  = '3px solid #FF6600';
          a.style.paddingLeft = '13px';
        }
      });
    })();
    </script>
    <?php endif; ?>

    <!-- FIX 3: Browse categories — searchable, scrollable, scales to 100+ categories -->
    <?php if ($all_cats): ?>
    <div class="gd4-sb-card">
      <div class="gd4-sb-head" style="display:flex;align-items:center">
        <span>🗂 Browse Categories</span>
        <span style="margin-left:auto;background:rgba(255,255,255,.2);border-radius:20px;padding:2px 8px;font-size:10px;font-weight:700"><?php echo count($all_cats); ?></span>
      </div>

      <?php if (count($all_cats) > 8): ?>
      <div style="padding:10px 12px 4px">
        <div style="position:relative">
          <input
            type="text"
            id="gd4-cat-search"
            placeholder="Search categories…"
            autocomplete="off"
            oninput="gd4FilterCats(this.value)"
            style="width:100%;border:1.5px solid #E2E8F0;border-radius:8px;padding:7px 10px 7px 28px;font-size:.78rem;box-sizing:border-box;outline:none;font-family:inherit;color:#334155">
          <span style="position:absolute;left:8px;top:50%;transform:translateY(-50%);font-size:.78rem;color:#94A3B8">🔍</span>
        </div>
      </div>
      <?php endif; ?>

      <ul class="gd4-sb-list" id="gd4-cat-list"
          style="max-height:320px;overflow-y:auto;scrollbar-width:thin;scrollbar-color:#E2E8F0 transparent">
        <?php foreach ($all_cats as $c): ?>
        <li data-cat-name="<?php echo esc_attr(strtolower($c->name)); ?>">
          <a href="#"
             data-cat-id="<?php echo (int)$c->id; ?>"
             onclick="event.preventDefault();gd4FilterBy('category',<?php echo (int)$c->id; ?>)">
            <span style="display:inline-flex;align-items:center;gap:6px;flex:1;min-width:0">
              <?php if (!empty($c->icon_emoji)): ?>
                <span style="font-size:.95rem;width:20px;text-align:center;flex-shrink:0"><?php echo esc_html($c->icon_emoji); ?></span>
              <?php endif; ?>
              <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html($c->name); ?></span>
            </span>
            <?php if ($c->n > 0): ?><span class="gd4-sb-cnt" style="flex-shrink:0"><?php echo $c->n; ?></span><?php endif; ?>
          </a>
        </li>
        <?php endforeach; ?>
      </ul>

      <div id="gd4-cat-empty" style="display:none;padding:12px 16px;font-size:.78rem;color:#94A3B8;text-align:center">
        No categories match your search.
      </div>
    </div>

    <script>
    window.gd4FilterCats = function(q) {
      q = q.trim().toLowerCase();
      var items   = document.querySelectorAll('#gd4-cat-list li');
      var empty   = document.getElementById('gd4-cat-empty');
      var visible = 0;
      items.forEach(function(li) {
        var name = li.getAttribute('data-cat-name') || '';
        var show = !q || name.indexOf(q) !== -1;
        li.style.display = show ? '' : 'none';
        if (show) visible++;
      });
      if (empty) empty.style.display = visible === 0 ? 'block' : 'none';
    };
    (function() {
      var activeCatId = '<?php echo (int)$category_id; ?>';
      if (!activeCatId || activeCatId === '0') return;
      var links = document.querySelectorAll('#gd4-cat-list a');
      links.forEach(function(a) {
        try {
          var url = new URL(a.href, window.location.origin);
          if (url.searchParams.get('category_id') === activeCatId) {
            a.style.background = '#FFF8F0';
            a.style.color      = '#FF6600';
            a.style.fontWeight = '700';
            a.style.borderLeft = '3px solid #FF6600';
            a.style.paddingLeft = '13px';
            var list = document.getElementById('gd4-cat-list');
            if (list) {
              var liTop = a.parentElement.offsetTop;
              list.scrollTop = Math.max(0, liTop - 60);
            }
          }
        } catch(e) {}
      });
    })();
    </script>
    <?php endif; ?>

  </div><!-- .gd4-sidebar -->

</div><!-- .gd4-body -->
</div><!-- .gd4-page -->

<!-- ══ QUICK PREVIEW MODAL ════════════════════════════════════ -->
<div id="gd4-preview-modal" role="dialog" aria-modal="true" aria-label="Vendor quick preview"
     onclick="if(event.target===this)gd4ClosePreview()">
  <div id="gd4-preview-panel">
    <div style="position:relative">
      <img id="gd4-pv-img" alt="" class="gd4-pv-img">
      <!-- No src attribute here, deliberately — an empty src="" causes the
           browser to request the CURRENT PAGE's own URL, confirmed by a
           captured error: "Failed to load IMG: .../directory/". JS sets
           src on demand when the preview is actually opened. -->
      <button class="gd4-pv-close" onclick="gd4ClosePreview()" aria-label="Close preview">✕</button>
    </div>
    <div class="gd4-pv-body">
      <div id="gd4-pv-title" class="gd4-pv-title"></div>
      <div id="gd4-pv-tagline" class="gd4-pv-tagline"></div>
      <div id="gd4-pv-gallery" class="gd4-pv-gallery" style="display:none"></div>
      <div id="gd4-pv-grid" class="gd4-pv-grid"></div>
      <div id="gd4-pv-desc" class="gd4-pv-desc"></div>
      <div id="gd4-pv-tags" class="gd4-pv-tags"></div>
      <div id="gd4-pv-actions" class="gd4-pv-actions"></div>
    </div>
  </div>
</div>

<script>
/* ── Card click — navigates to listing page ──────────────────────
   Ignores clicks on buttons/links (they have stopPropagation).
   Middle-click or Ctrl+click opens in new tab.              */
function gd4CardClick(event, card) {
  // Only fire on left-click without modifier keys (those are handled by native <a>)
  if (event.button !== undefined && event.button !== 0) return;
  var href = card.getAttribute('data-href');
  if (!href) return;
  if (event.ctrlKey || event.metaKey || event.shiftKey) {
    window.open(href, '_blank', 'noopener');
  } else {
    window.location.href = href;
  }
}

/* ── Search ──────────────────────────────────────────────────── */
// ── AJAX Directory Filter — no full page reload ───────────────────────────────
var _gd4Ajax = null; // in-flight request tracker
var _gd4Nonce = '<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>';
var _gd4AjaxUrl = '<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
var _gd4AllCities = <?php echo wp_json_encode(array_map(fn($c)=>['city'=>$c->city,'n'=>(int)$c->n], $all_cities_f)); ?>;
// Keyset pagination cursor — tracks the first/last item from the most
// recent response. Replaces simple page-number-to-offset jumping; the
// server no longer translates "page N" into a row position cheaply at
// scale, so Next/Prev now carry the actual cursor values forward instead,
// mirroring how this page's own non-AJAX pagination already works.
var _gd4Cursor = { firstId:0, firstScore:0, firstRating:0, lastId:0, lastScore:0, lastRating:0 };
var _gd4BaseUrl  = '<?php echo esc_js(home_url("/directory/")); ?>';

/* ── gd4FilterBy — intercept city/category/clear clicks → AJAX instead of full reload ──
   Called by all interactive sidebar links and locality pills.
   type: 'city' | 'category' | 'clear'
   value: city name string | category_id integer | '' */
window.gd4FilterBy = function(type, value) {
  var cityEl = document.getElementById('gd4-city');
  var catEl  = document.getElementById('gd4-cat');

  if (type === 'clear') {
    // Reset all filters to default
    if (cityEl) cityEl.value = '';
    if (catEl)  catEl.value  = '';
    var kwEl = document.getElementById('gd4-kw');
    if (kwEl) kwEl.value = '';
    var pmEl = document.getElementById('gd4-price-min');
    var pxEl = document.getElementById('gd4-price-max');
    if (pmEl) pmEl.value = '';
    if (pxEl) pxEl.value = '';
    var vEl = document.getElementById('gd4-verified');
    var bEl = document.getElementById('gd4-bookable');
    if (vEl) vEl.checked = false;
    if (bEl) bEl.checked = false;
    document.querySelectorAll('input[name="gd4-rating"]').forEach(function(r) {
      r.checked = r.value === '0';
    });
    document.querySelectorAll('input[name="gd4-type"]').forEach(function(r) {
      r.checked = r.value === '';
    });
  } else if (type === 'city') {
    if (cityEl) cityEl.value = value;
  } else if (type === 'category') {
    if (catEl) catEl.value = String(value);
  }

  // Update pill active states immediately (before AJAX returns)
  document.querySelectorAll('.gd4-pill').forEach(function(p) {
    p.classList.remove('on');
  });
  if (type === 'clear') {
    var allPill = document.querySelector('.gd4-pill[data-filter-type="all"]');
    if (allPill) allPill.classList.add('on');
  } else if (type === 'city') {
    var cityPill = document.querySelector('.gd4-pill[data-city="' + value + '"]');
    if (cityPill) cityPill.classList.add('on');
  }

  // Update sidebar city list active state
  document.querySelectorAll('#gd4-city-card .gd4-sb-list a').forEach(function(a) {
    a.style.background = '';
    a.style.color      = '';
    a.style.fontWeight = '';
    a.style.borderLeft = '';
    a.style.paddingLeft = '';
    if (type === 'city' && a.getAttribute('data-city') === value) {
      a.style.background  = '#FFF8F0';
      a.style.color       = '#FF6600';
      a.style.fontWeight  = '700';
      a.style.borderLeft  = '3px solid #FF6600';
      a.style.paddingLeft = '13px';
    }
  });

  // Update sidebar category list active state
  document.querySelectorAll('#gd4-cat-list a').forEach(function(a) {
    a.style.background  = '';
    a.style.color       = '';
    a.style.fontWeight  = '';
    a.style.borderLeft  = '';
    a.style.paddingLeft = '';
    if (type === 'category' && a.getAttribute('data-cat-id') === String(value)) {
      a.style.background  = '#FFF8F0';
      a.style.color       = '#FF6600';
      a.style.fontWeight  = '700';
      a.style.borderLeft  = '3px solid #FF6600';
      a.style.paddingLeft = '13px';
    }
  });

  gdSearch4(1);
};

function gd4CollectFilters(page, direction) {
  var get  = function(id){ var e=document.getElementById(id); return e?e.value.trim():''; };
  var cb   = function(id){ var e=document.getElementById(id); return e&&e.checked; };
  var params = {
    action:       'gs_directory_filter',
    nonce:        _gd4Nonce,
    keyword:      get('gd4-kw') || get('gd4-hsearch'),
    city:         get('gd4-city'),
    category_id:  get('gd4-cat'),
    sort:         get('gd4-sort'),
    min_rating:   (function(){ var r=document.querySelector('input[name="gd4-rating"]:checked'); return r?r.value:'0'; })(),
    type:         (function(){ var t=document.querySelector('input[name="gd4-type"]:checked'); return t?t.value:''; })(),
    price_min:    get('gd4-price-min'),
    price_max:    get('gd4-price-max'),
    verified_only:cb('gd4-verified')?'1':'',
    bookable:     cb('gd4-bookable')?'1':'',
    avail_today:  cb('gd4-avail-today')?'1':'',
    avail_week:   cb('gd4-avail-week')?'1':'',
    page:         page || 1,
  };
  // direction: 'next' sends the last item's cursor (continue forward),
  // 'prev' sends the first item's cursor (go back one page), anything
  // else (a filter change, not a page step) sends neither — correctly
  // starting fresh from the top of the new filtered result set.
  if (direction === 'next' && _gd4Cursor.lastId) {
    params.last_id     = _gd4Cursor.lastId;
    params.last_score  = _gd4Cursor.lastScore;
    params.last_rating = _gd4Cursor.lastRating;
  } else if (direction === 'prev' && _gd4Cursor.firstId) {
    params.first_id     = _gd4Cursor.firstId;
    params.first_score   = _gd4Cursor.firstScore;
    params.first_rating = _gd4Cursor.firstRating;
  }
  return params;
}

function gdSearch4(page, direction) {
  var params = gd4CollectFilters(page || 1, direction);
  var grid   = document.getElementById('gd4-results-list');
  var info   = document.querySelector('.gd4-title-sub');

  if (!grid) {
    // Fallback: full page reload with clean URL (no action/nonce)
    var fp = new URLSearchParams();
    ['keyword','city','category_id','sort','min_rating','type','price_min','price_max','verified_only','bookable','avail_today','avail_week','page'].forEach(function(k){
      if (params[k]) fp.set(k, params[k]);
    });
    window.location.href = _gd4BaseUrl + '?' + fp.toString();
    return;
  }

  // FIX 2B: scroll to top of results area before loading so the page
  // doesn't appear to jump when content height changes after results render.
  var gridRect = grid.getBoundingClientRect();
  if (gridRect.top < -20 || gridRect.top > 300) {
    // Only scroll if the grid isn't already naturally in view
    window.scrollTo({ top: Math.max(0, grid.offsetTop - 90), behavior: 'smooth' });
  }

  // Show loading state
  grid.style.opacity = '0.5';
  grid.style.pointerEvents = 'none';

  // Cancel in-flight request
  if (_gd4Ajax) { _gd4Ajax = null; }

  var fd = new FormData();
  Object.entries(params).forEach(function(e){ fd.append(e[0], e[1]); });

  var thisReq = {};
  _gd4Ajax = thisReq;

  fetch(_gd4AjaxUrl, { method:'POST', body:fd, credentials:'same-origin' })
    .then(function(r){ return r.json(); })
    .then(function(d) {
      if (_gd4Ajax !== thisReq) return; // superseded
      grid.style.opacity = '';
      grid.style.pointerEvents = '';

      if (!d || !d.success) {
        grid.style.opacity = '';
        grid.style.pointerEvents = '';
        if (typeof gsToast === 'function') gsToast('Filter failed. Please try again.', 'error');
        return;
      }
      var data = d.data;

      // Re-render listing cards
      if (data.listings && data.listings.length) {
        grid.innerHTML = data.listings.map(gd4BuildCard).join('');
        // Re-init save buttons state
        gd4InitSaveButtons();
      } else {
        grid.innerHTML = '<div class="gd4-empty"><div style="font-size:3rem">🔍</div><h3>No listings found</h3><p>Try different keywords or <a href="' + _gd4BaseUrl + '">browse all listings</a>.</p></div>';
      }

      // Update result count
      if (info) info.textContent = data.total.toLocaleString('en-IN') + ' listing' + (data.total !== 1 ? 's' : '') + ' found';

      // Update keyset cursor for the NEXT request — this is what replaces
      // page-number-to-offset translation now.
      _gd4Cursor.firstId     = data.first_id     || 0;
      _gd4Cursor.firstScore  = data.first_score  || 0;
      _gd4Cursor.firstRating = data.first_rating || 0;
      _gd4Cursor.lastId      = data.last_id      || 0;
      _gd4Cursor.lastScore   = data.last_score   || 0;
      _gd4Cursor.lastRating  = data.last_rating  || 0;

      // Re-render pagination
      var pgEl = document.getElementById('gd4-pagination');
      if (pgEl) pgEl.innerHTML = gd4BuildPagination(data.page, data.has_more);

      // Update browser URL without reload (preserves back button)
      if (window.history && window.history.pushState && data.qs !== undefined) {
        var newUrl = _gd4BaseUrl + (data.qs || '');
        window.history.pushState({ gdPage: data.page }, '', newUrl);
      }

      // Scroll results into view on mobile
      if (window.innerWidth < 768) {
        grid.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    })
    .catch(function() {
      if (grid) { grid.style.opacity=''; grid.style.pointerEvents=''; }
      if (typeof gsToast === 'function') gsToast('Network error. Please check your connection.', 'error');
    });
}
window.gsRunSearch = gdSearch4;

// ── Restore state on browser back/forward ─────────────────────────────────────
window.addEventListener('popstate', function(e) {
  var p = new URLSearchParams(window.location.search);
  ['gd4-kw','gd4-city','gd4-cat','gd4-sort'].forEach(function(id) {
    var el = document.getElementById(id);
    if (el) el.value = p.get({'gd4-kw':'keyword','gd4-city':'city','gd4-cat':'category_id','gd4-sort':'sort'}[id]) || '';
  });
  gdSearch4(parseInt(p.get('page')) || 1);
});

// ── Build listing card from JSON data ─────────────────────────────────────────
function gd4BuildCard(l) {
  /* Produces HTML IDENTICAL to the PHP-rendered .gd4-card template.
     Every class name matches a CSS rule in the archive.php <style> block. */

  var e = gd4esc;

  // Stars — same logic as PHP $sf = min(5, round(avg_rating))
  var sf = l.avg_rating > 0 ? Math.min(5, Math.round(l.avg_rating)) : 0;
  var starsHtml = '';
  if (sf > 0) {
    for (var s = 1; s <= 5; s++) {
      starsHtml += '<span class="gd4-star' + (s <= sf ? ' on' : '') + '">★</span>';
    }
  }

  // Price range pill — class gd4-price-range (exists in CSS)
  var priceHtml = '';
  if (l.price_min || l.price_max) {
    var pLabel = l.price_min && l.price_max
      ? '₹' + parseInt(l.price_min).toLocaleString('en-IN') + ' – ₹' + parseInt(l.price_max).toLocaleString('en-IN')
      : l.price_min ? 'From ₹' + parseInt(l.price_min).toLocaleString('en-IN')
                    : 'Up to ₹' + parseInt(l.price_max).toLocaleString('en-IN');
    priceHtml = '<span class="gd4-price-range">💰 ' + e(pLabel) + '</span>';
  }

  // Tags — class gd4-tag (exists in CSS)
  var tagsHtml = '';
  var tags = (l.tags || []).slice(0, 5);
  if (tags.length) {
    tagsHtml = '<div class="gd4-tags">'
      + tags.map(function(t) {
          return '<a href="' + _gd4BaseUrl + '?keyword=' + encodeURIComponent(t.trim())
               + '" class="gd4-tag" onclick="event.stopPropagation()">' + e(t.trim()) + '</a>';
        }).join('')
      + '</div>';
  }

  // Featured label — class gd4-featured-label (exists in CSS)
  var featLabel = l.is_featured
    ? '<span class="gd4-featured-label" aria-label="Featured listing">⭐ Featured</span>'
    : '';

  // Verified badge — class gd4-badge-v (exists in CSS)
  var verBadge = l.is_verified
    ? '<span class="gd4-badge-v">✓ Verified</span>'
    : '';

  // Category badge — class gd4-badge-cat (exists in CSS)
  var catBadge = l.cat_name
    ? '<span class="gd4-badge-cat">' + e(l.cat_name) + '</span>'
    : '';

  // Address — class gd4-addr + gd4-pin (both exist in CSS)
  var addrHtml = '';
  if (l.city || l.address) {
    var addrParts = [l.address, l.city].filter(Boolean);
    addrHtml = '<div class="gd4-addr"><span class="gd4-pin">📍</span><span>'
             + e(addrParts.join(', ')) + '</span></div>';
  }

  // Thumbnail — class gd4-thumb (exists in CSS, sets width:210px in list view)
  var thumbInner = l.thumb
    ? '<img src="' + e(l.thumb) + '" alt="' + e(l.title) + '" loading="lazy">'
    : '<div class="gd4-thumb-ph">🏢</div>';

  // Action buttons — all classes exist in CSS
  var phoneBtn = l.phone
    ? '<button class="gd4-btn gd4-btn-num"'
        + ' onclick="event.stopPropagation();gdReveal4(this,\'' + e(l.phone_raw || l.phone) + '\',' + l.id + ')"'
        + ' aria-label="Call ' + e(l.title) + '">📞 ' + e(l.phone) + '</button>'
    : '';

  var viewBtn = '<a href="' + e(l.url) + '" class="gd4-btn gd4-btn-book"'
      + ' onclick="event.stopPropagation()">View Details →</a>';

  var waBtn = l.wa
    ? '<a href="https://wa.me/' + e(l.wa) + '?text=Hi+' + encodeURIComponent(l.title) + '"'
        + ' target="_blank" rel="noopener" class="gd4-btn gd4-btn-wa"'
        + ' onclick="event.stopPropagation()">💬 WhatsApp</a>'
    : '';

  var saveBtn = '<button class="gd4-btn gd4-btn-save" data-id="' + l.id + '"'
      + ' onclick="event.stopPropagation();gd4ToggleSave(this,' + l.id + ')"'
      + ' title="Save to wishlist">' + (l.saved ? '❤' : '🤍') + '</button>';

  var shareBtn = '<button class="gd4-btn gd4-btn-share"'
      + ' onclick="event.stopPropagation();gd4CopyLink(this,\'' + e(l.url) + '\')"'
      + ' title="Copy link">🔗</button>';

  var statsHtml = '<div class="gd4-stats"><span class="gd4-stat-v">👁 '
      + (l.views_count || 0).toLocaleString('en-IN') + '</span></div>';

  // Rating+meta row — classes gd4-meta, gd4-stars, gd4-star, gd4-score, gd4-rcount, gd4-sep
  var metaHtml = '';
  if (sf > 0) {
    metaHtml = '<div class="gd4-meta">'
             + '<div class="gd4-stars">' + starsHtml + '</div>'
             + '<span class="gd4-score">' + l.avg_rating.toFixed(1) + '</span>'
             + '<span class="gd4-rcount">(' + (l.review_count || 0) + ')</span>'
             + '</div>';
  }

  // Assemble — exact same DOM structure as PHP template
  return '<div class="gd4-card' + (l.is_featured ? ' gd4-featured' : '') + '"'
       + ' data-href="' + e(l.url) + '" data-id="' + l.id + '"'
       + ' onclick="gd4CardClick(event,this)" style="position:relative">'

       + featLabel

       // Thumbnail column (flex child, width set by .gd4-thumb CSS)
       + '<a href="' + e(l.url) + '" class="gd4-thumb" onclick="event.stopPropagation()">'
       + thumbInner
       + '</a>'

       // Content column (flex:1)
       + '<div class="gd4-content">'

         + '<div class="gd4-title-row">'
         + '<a href="' + e(l.url) + '" class="gd4-name" onclick="event.stopPropagation()">' + e(l.title) + '</a>'
         + verBadge + catBadge
         + '</div>'

         + addrHtml
         + metaHtml

         + (priceHtml ? '<div style="display:flex;flex-wrap:wrap;gap:5px;margin:6px 0">' + priceHtml + '</div>' : '')

         + (l.short_desc
             ? '<div class="gd4-desc">' + e(l.short_desc.substring(0, 120))
               + (l.short_desc.length > 120 ? '…' : '') + '</div>'
             : '')

         + tagsHtml

         + '<div class="gd4-actions">'
         + phoneBtn + viewBtn + waBtn + saveBtn + shareBtn + statsHtml
         + '</div>'

       + '</div>'   // .gd4-content
       + '</div>';  // .gd4-card
}
function gd4esc(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

function gd4BuildPagination(page, hasMore) {
  if (page <= 1 && !hasMore) return ''; // single page of results — nothing to paginate
  var html = '';
  if (page > 1) html += '<a href="#" class="gd4-pg" onclick="event.preventDefault();gdSearch4(' + (page-1) + ',\'prev\')">‹ Prev</a>';
  html += '<span class="gd4-pg gd4-pg-info">Page ' + page + '</span>';
  if (hasMore) html += '<a href="#" class="gd4-pg" onclick="event.preventDefault();gdSearch4(' + (page+1) + ',\'next\')">Next ›</a>';
  return html;
}

function gd4InitSaveButtons() {
  // Re-initialise any save buttons that need server-state (logged-in users)
  // For guests: localStorage state is applied client-side only
}

// FIX 2C: prevent browser from restoring previous scroll position on full page reload.
// When a user clicks a category/city sidebar link (full GET reload), the browser
// would restore the previous scroll Y — causing the page to appear to jump.
if ('scrollRestoration' in history) { history.scrollRestoration = 'manual'; }

// ── City search typeahead ─────────────────────────────────────────────────────
window.gd4CitySearch = function(q) {
  var drop = document.getElementById('gd4-city-drop');
  if (!drop) return;
  q = q.trim().toLowerCase();
  if (!q) { drop.style.display = 'none'; return; }
  var matches = _gd4AllCities.filter(function(c){ return c.city.toLowerCase().indexOf(q) !== -1; }).slice(0, 10);
  if (!matches.length) { drop.style.display = 'none'; return; }
  drop.innerHTML = matches.map(function(c) {
    // AJAX filter — no full page reload
    return '<a href="#"'
         + ' onclick="event.preventDefault();var d=document.getElementById(\'gd4-city-drop\');if(d)d.style.display=\'none\';gd4FilterBy(\'city\',' + JSON.stringify(c.city) + ')"'
         + ' style="display:flex;justify-content:space-between;padding:8px 12px;text-decoration:none;color:#334155;font-size:.82rem;border-bottom:1px solid #F1F5F9;cursor:pointer"'
         + ' onmouseover="this.style.background=\'#FFF8F0\'" onmouseout="this.style.background=\'\'">'
         + '<span>' + gd4esc(c.city) + '</span>'
         + '<span style="color:#94A3B8;font-size:.75rem">' + c.n + '</span>'
         + '</a>';
  }).join('');
  drop.style.display = 'block';
};

window.gd4ShowAllCities = function() {
  // Load all cities via AJAX and replace the top-8 list
  var list = document.querySelector('#gd4-city-card .gd4-sb-list');
  if (!list) return;
  list.innerHTML = _gd4AllCities.slice(0, 300).map(function(c) {
    // AJAX filter — no full page reload
    return '<li><a href="#"'
         + ' data-city="' + gd4esc(c.city) + '"'
         + ' onclick="event.preventDefault();gd4FilterBy(\'city\',' + JSON.stringify(c.city) + ')">'
         + gd4esc(c.city) + '<span class="gd4-sb-cnt">' + c.n + '</span></a></li>';
  }).join('');
  var btn = document.querySelector('#gd4-city-card button');
  if (btn) btn.closest('div').remove();
};

// Close city typeahead on outside click
document.addEventListener('click', function(e) {
  var drop = document.getElementById('gd4-city-drop');
  var card = document.getElementById('gd4-city-card');
  if (drop && card && !card.contains(e.target)) drop.style.display = 'none';
});


/* Header search syncs with sidebar kw */
(function(){
  var hs=document.getElementById('gd4-hsearch');
  if(hs){hs.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();gdSearch4(1);}});}
})();

/* Debounced sidebar keyword */
(function(){
  var kw=document.getElementById('gd4-kw'); if(!kw)return;
  var t;
  kw.addEventListener('input',function(){clearTimeout(t);t=setTimeout(function(){gdSearch4(1);},420);});
  kw.addEventListener('keydown',function(e){if(e.key==='Enter'){clearTimeout(t);gdSearch4(1);}});
})();

/* Live change on selects */
['gd4-city','gd4-cat'].forEach(function(id){
  var el=document.getElementById(id); if(el)el.addEventListener('change',function(){gdSearch4(1);});
});
document.querySelectorAll('input[name="gd4-type"],input[name="gd4-rating"]').forEach(function(el){
  el.addEventListener('change',function(){gdSearch4(1);});
});

/* ── Reveal phone ─────────────────────────────────────────────── */
function gdReveal4(btn, phone, lid) {
  var a=document.createElement('a');
  a.href='tel:'+phone; a.className='gd4-btn gd4-btn-num';
  a.style.fontWeight='800'; a.textContent='📞 '+phone;
  btn.parentNode.replaceChild(a,btn);
  if(window.jQuery)jQuery.post(GS&&GS.ajax_url||'<?php echo esc_url(admin_url("admin-ajax.php")); ?>',
    {action:'gs_track_event',listing_id:lid,event_type:'call_click',nonce:GS&&GS.nonce||''});
}

/* ── Grid / List view toggle ───────────────────────────────────── */
function gd4SetView(mode) {
  var list = document.getElementById('gd4-results-list');
  var lb   = document.getElementById('gd4-list-btn');
  var gb   = document.getElementById('gd4-grid-btn');
  if (!list) return;
  if (mode === 'grid') {
    list.classList.add('grid-view');
    gb.classList.add('on'); gb.setAttribute('aria-pressed','true');
    lb.classList.remove('on'); lb.setAttribute('aria-pressed','false');
    try { localStorage.setItem('gd4-view','grid'); } catch(e){}
  } else {
    list.classList.remove('grid-view');
    lb.classList.add('on'); lb.setAttribute('aria-pressed','true');
    gb.classList.remove('on'); gb.setAttribute('aria-pressed','false');
    try { localStorage.setItem('gd4-view','list'); } catch(e){}
  }
}
// Default: list on desktop, grid on mobile. User preference (localStorage) overrides.
(function(){
  var saved = null;
  try { saved = localStorage.getItem('gd4-view'); } catch(e){}
  if (saved) {
    // User has explicitly chosen — honour it
    gd4SetView(saved);
  } else {
    // Auto-detect: mobile (<= 768px) → grid, desktop → list (default)
    var mobile = window.matchMedia && window.matchMedia('(max-width:768px)').matches;
    gd4SetView(mobile ? 'grid' : 'list');
  }
  // Also respond to orientation/resize changes (e.g. rotate phone)
  if (window.matchMedia) {
    window.matchMedia('(max-width:768px)').addEventListener('change', function(mq) {
      var cur = null;
      try { cur = localStorage.getItem('gd4-view'); } catch(e){}
      if (!cur) gd4SetView(mq.matches ? 'grid' : 'list');
    });
  }
})();

/* ── Save to wishlist (Phase 2: synced with gs_saved_listings for logged-in users) ── */
<?php $gd4_is_logged_in = is_user_logged_in(); $gd4_saved_ids_json = wp_json_encode( $saved_ids ); ?>
(function(){
  var isLoggedIn = <?php echo $gd4_is_logged_in ? 'true' : 'false'; ?>;
  if (isLoggedIn) {
    // Server is the source of truth — highlight from $saved_ids (gs_saved_listings)
    var serverSaved = <?php echo $gd4_saved_ids_json; ?>;
    serverSaved.forEach(function(id){
      var btn = document.querySelector('.gd4-btn-save[data-id="'+id+'"]');
      if (btn) { btn.classList.add('saved'); btn.textContent = '❤'; btn.title = 'Saved! Click to remove'; }
    });
  } else {
    // Guest fallback — localStorage only (not visible in customer dashboard)
    var saved = [];
    try { saved = JSON.parse(localStorage.getItem('gd4-wishlist')||'[]'); } catch(e){}
    saved.forEach(function(id){
      var btn = document.querySelector('.gd4-btn-save[data-id="'+id+'"]');
      if (btn) { btn.classList.add('saved'); btn.textContent = '❤'; btn.title = 'Saved! Click to remove'; }
    });
  }
})();

window.gd4CopyLink = function(btn, url) {
  if (!navigator.clipboard) return;
  navigator.clipboard.writeText(url).then(function(){
    var orig = btn.innerHTML;
    btn.classList.add('copied');
    btn.innerHTML = '✅';
    if (typeof gsToast === 'function') gsToast('Link copied!', 'success');
    setTimeout(function(){ btn.classList.remove('copied'); btn.innerHTML = orig; }, 2000);
  }).catch(function(){});
};

window.gd4ToggleSave = function(btn, id) {
  var isLoggedIn = <?php echo $gd4_is_logged_in ? 'true' : 'false'; ?>;
  var isSaved = btn.classList.contains('saved');

  if (isLoggedIn) {
    // Sync with server (gs_saved_listings) — same table the customer
    // dashboard's "Saved Listings" section reads from.
    btn.disabled = true;
    gsPost('gs_save_listing_bookmark', { listing_id: id }, function(d){
      btn.disabled = false;
      if (d.saved) {
        btn.classList.add('saved'); btn.textContent = '❤'; btn.title = 'Saved! Click to remove';
        btn.style.transform = 'scale(1.3)'; setTimeout(function(){ btn.style.transform = ''; }, 200);
      } else {
        btn.classList.remove('saved'); btn.textContent = '🤍'; btn.title = 'Save to wishlist';
      }
    }, function(){
      btn.disabled = false;
      gsToast('Could not update saved vendors. Please try again.', 'error');
    });
    return;
  }

  // Guest fallback — localStorage only, with a nudge to create an account
  var saved = [];
  try { saved = JSON.parse(localStorage.getItem('gd4-wishlist')||'[]'); } catch(e){}
  if (isSaved) {
    saved = saved.filter(function(v){ return v !== id; });
    btn.classList.remove('saved'); btn.textContent = '🤍'; btn.title = 'Save to wishlist';
  } else {
    if (saved.indexOf(id) === -1) saved.push(id);
    btn.classList.add('saved'); btn.textContent = '❤'; btn.title = 'Saved! Click to remove';
    btn.style.transform = 'scale(1.3)'; setTimeout(function(){ btn.style.transform = ''; }, 200);
    gsToast('Saved on this device. Log in to keep your saved vendors permanently.', 'success');
  }
  try { localStorage.setItem('gd4-wishlist', JSON.stringify(saved)); } catch(e){}
};

/* ── Quick Preview Modal ──────────────────────────────────────── */
window.gd4QuickPreview = function(dataStr) {
  var d;
  try { d = typeof dataStr === 'string' ? JSON.parse(dataStr) : dataStr; } catch(e){ return; }
  if (!d) return;
  var modal = document.getElementById('gd4-preview-modal');
  var img   = document.getElementById('gd4-pv-img');
  if (!modal) return;

  // Image
  if (d.thumb) { img.src = d.thumb; img.alt = d.title||''; img.style.display='block'; }
  else { img.style.display='none'; }

  // Title + tagline
  document.getElementById('gd4-pv-title').textContent = d.title || '';
  var tl = document.getElementById('gd4-pv-tagline');
  tl.textContent = d.tagline ? '"' + d.tagline + '"' : '';
  tl.style.display = d.tagline ? 'block' : 'none';

  // Gallery
  var gal = document.getElementById('gd4-pv-gallery');
  gal.innerHTML = '';
  if (d.portfolio && d.portfolio.length >= 2) {
    d.portfolio.slice(0,4).forEach(function(url){
      var im = document.createElement('img');
      im.src = url; im.alt = ''; im.loading = 'lazy';
      gal.appendChild(im);
    });
    gal.style.display = 'grid';
  } else { gal.style.display = 'none'; }

  // Info grid
  var grid = document.getElementById('gd4-pv-grid');
  var cells = [];
  if (d.addr)    cells.push(['📍 Location', d.addr]);
  if (d.cat)     cells.push(['🗂 Category', d.cat]);
  if (d.rating>0) cells.push(['⭐ Rating', d.rating.toFixed(1) + ' (' + d.reviews + ' reviews)']);
  if (d.price_min || d.price_max) {
    var pr = d.price_min && d.price_max ? '₹'+d.price_min.toLocaleString('en-IN')+' – ₹'+d.price_max.toLocaleString('en-IN')
           : d.price_min ? 'From ₹'+d.price_min.toLocaleString('en-IN') : 'Up to ₹'+d.price_max.toLocaleString('en-IN');
    cells.push(['💰 Pricing', pr]);
  }
  grid.innerHTML = cells.map(function(c){
    return '<div class="gd4-pv-cell"><div class="gd4-pv-lbl">'+c[0]+'</div><div class="gd4-pv-val">'+c[1]+'</div></div>';
  }).join('');

  // Description
  var desc = document.getElementById('gd4-pv-desc');
  desc.textContent = d.desc || '';
  desc.style.display = d.desc ? 'block' : 'none';

  // Tags
  var tags = document.getElementById('gd4-pv-tags');
  tags.innerHTML = (d.tags||[]).slice(0,8).map(function(t){
    return '<span style="display:inline-block;background:#F1F5F9;color:#334155;border:1px solid #E2E8F0;border-radius:20px;padding:3px 9px;font-size:11px;font-weight:600">'+t+'</span>';
  }).join('');

  // Actions
  var lurl = '<?php echo esc_url(home_url("/")); ?>' + d.slug + '/';
  var acts = document.getElementById('gd4-pv-actions');
  var btns = '<a href="'+lurl+'" class="gd4-btn gd4-btn-book" style="flex:1;justify-content:center">View Full Profile →</a>';
  if (d.wa) btns += '<a href="https://wa.me/'+d.wa+'?text=Hi+'+encodeURIComponent(d.title)+'" target="_blank" class="gd4-btn gd4-btn-wa">💬 WhatsApp</a>';
  if (d.phone) btns += '<a href="tel:'+d.phone+'" class="gd4-btn gd4-btn-num">📞 Call</a>';
  if (d.website) btns += '<a href="'+d.website+'" target="_blank" class="gd4-btn gd4-btn-web">🌐 Website</a>';
  acts.innerHTML = btns;

  // Show modal
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
};

window.gd4ClosePreview = function() {
  var modal = document.getElementById('gd4-preview-modal');
  if (modal) { modal.classList.remove('open'); document.body.style.overflow = ''; }
};

// Close on ESC
document.addEventListener('keydown', function(e){
  if (e.key === 'Escape') gd4ClosePreview();
});

/* ── Enquiry form ─────────────────────────────────────────────── */
function gdEnq4(e) {
  e.preventDefault();
  var get=function(id){var el=document.getElementById(id);return el?el.value||'':'';};
  var name=get('gd4-en'),phone=get('gd4-ep'),email=get('gd4-ee'),msg=get('gd4-em');
  var btn=document.getElementById('gd4-esbmt'),stat=document.getElementById('gd4-estat');
  if(!name||!phone){stat.textContent='Please enter name and phone.';stat.style.color='#C62828';return;}
  btn.textContent='Sending…';btn.disabled=true;
  var fd=new FormData();
  fd.append('action','gs_send_enquiry');fd.append('name',name);fd.append('phone',phone);
  fd.append('email',email);fd.append('message',msg);
  fd.append('category','<?php echo esc_js($cur_cat?$cur_cat->name:"General"); ?>');
  fd.append('page_url',window.location.href);fd.append('nonce',(GS&&GS.nonce)||'');
  fetch((GS&&GS.ajax_url)||'<?php echo esc_url(admin_url("admin-ajax.php")); ?>',{method:'POST',body:fd})
    .then(function(r){return r.json();})
    .then(function(d){
      stat.textContent=d.success?'✅ Enquiry sent! We\'ll contact you soon.':'❌ '+(d.data||'Failed.');
      stat.style.color=d.success?'#2E7D32':'#C62828';
      if(d.success)document.getElementById('gd4-enq').reset();
    })
    .catch(function(){stat.textContent='❌ Network error.';stat.style.color='#C62828';})
    .finally(function(){btn.textContent='📨 Send Enquiry';btn.disabled=false;});
}
</script>


<!-- ════ DIRECTORY PAGE FOOTER ══════════════════════════════ -->
<?php
/* Footer data for directory page */
$df_site   = function_exists('gs_setting') ? gs_setting('platform_name', get_bloginfo('name')) : get_bloginfo('name');
$df_logo   = function_exists('gs_setting') ? gs_setting('logo_url','')  : '';
$df_phone  = function_exists('gs_setting') ? gs_setting('platform_phone','') : '';
$df_email  = function_exists('gs_setting') ? gs_setting('platform_email','') : '';
$df_addr   = function_exists('gs_setting') ? gs_setting('platform_address','') : '';
$df_cats   = $all_cats ?: [];
$df_cities = $city_counts ?: [];
$df_home   = home_url('/');
$df_dir    = home_url('/directory/');
$df_reg    = home_url('/vendor/register/');
$df_login  = home_url('/vendor/login/');
?>
<footer class="gd4-footer" style="background:#0a1628;color:rgba(255,255,255,.6)">
  <div class="gd4-footer-grid">
    <!-- Brand -->
    <div>
      <?php if($df_logo): ?>
        <img src="<?php echo esc_url($df_logo); ?>" alt="<?php echo esc_attr($df_site); ?>" class="gd4-footer-brand">
      <?php else: ?>
        <a href="<?php echo esc_url($df_home); ?>" class="gd4-footer-brand"><?php echo esc_html($df_site); ?></a>
      <?php endif; ?>
      <p class="gd4-footer-about">Your trusted platform for finding verified professional service providers across India.</p>
      <div class="gd4-footer-social">
        <?php $fb_url = function_exists('gs_setting') ? gs_setting('platform_facebook','') : ''; if ($fb_url): ?><a href="<?php echo esc_url($fb_url); ?>" title="Facebook" target="_blank" rel="noopener">📘</a><?php endif; ?>
        <?php $ig_url = function_exists('gs_setting') ? gs_setting('platform_instagram','') : ''; if ($ig_url): ?><a href="<?php echo esc_url($ig_url); ?>" title="Instagram" target="_blank" rel="noopener">📸</a><?php endif; ?>
        <?php $tw_url = function_exists('gs_setting') ? gs_setting('platform_twitter','') : ''; if ($tw_url): ?><a href="<?php echo esc_url($tw_url); ?>" title="Twitter" target="_blank" rel="noopener">🐦</a><?php endif; ?>
        <?php $li_url = function_exists('gs_setting') ? gs_setting('platform_linkedin','') : ''; if ($li_url): ?><a href="<?php echo esc_url($li_url); ?>" title="LinkedIn" target="_blank" rel="noopener">💼</a><?php endif; ?>
      </div>
      <div style="margin-top:14px;display:flex;flex-direction:column;gap:6px">
        <?php if($df_phone): ?><span style="font-size:12px;color:rgba(255,255,255,.45)">📞 <?php echo esc_html($df_phone); ?></span><?php endif; ?>
        <?php if($df_email): ?><span style="font-size:12px;color:rgba(255,255,255,.45)">📧 <?php echo esc_html($df_email); ?></span><?php endif; ?>
        <?php if($df_addr):  ?><span style="font-size:12px;color:rgba(255,255,255,.45)">📍 <?php echo esc_html($df_addr);  ?></span><?php endif; ?>
      </div>
    </div>
    <!-- Quick Links -->
    <div>
      <div class="gd4-footer-col-title">Quick Links</div>
      <div class="gd4-footer-links">
        <a href="<?php echo esc_url($df_home); ?>" style="color:rgba(255,255,255,.5)">Home</a>
        <a href="<?php echo esc_url($df_dir); ?>" style="color:rgba(255,255,255,.5)">Browse Directory</a>
        <a href="<?php echo esc_url($df_reg); ?>" style="color:rgba(255,255,255,.5)">List Your Business</a>
        <a href="<?php echo esc_url($df_login); ?>" style="color:rgba(255,255,255,.5)">Vendor Login</a>
        <a href="<?php echo esc_url(home_url('/about-us/')); ?>" style="color:rgba(255,255,255,.5)">About Us</a>
        <a href="<?php echo esc_url(home_url('/contact-us/')); ?>" style="color:rgba(255,255,255,.5)">Contact Us</a>
        <a href="<?php echo esc_url(home_url('/blog/')); ?>" style="color:rgba(255,255,255,.5)">Blog</a>
      </div>
    </div>
    <!-- Categories -->
    <div>
      <div class="gd4-footer-col-title">Categories</div>
      <div class="gd4-footer-links">
        <?php foreach(array_slice((array)$df_cats,0,7) as $c): ?>
          <a href="<?php echo esc_url(add_query_arg(['category_id'=>$c->id,'page'=>null],$df_dir)); ?>" style="color:rgba(255,255,255,.5)"><?php echo esc_html($c->name); ?></a>
        <?php endforeach; ?>
        <a href="<?php echo esc_url($df_dir); ?>" style="color:rgba(255,255,255,.5)">View All →</a>
      </div>
    </div>
    <!-- Legal -->
    <div>
      <div class="gd4-footer-col-title">Legal & Info</div>
      <div class="gd4-footer-links">
        <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>" style="color:rgba(255,255,255,.5)">Privacy Policy</a>
        <a href="<?php echo esc_url(home_url('/terms-of-service/')); ?>" style="color:rgba(255,255,255,.5)">Terms of Service</a>
        <a href="<?php echo esc_url(home_url('/cookie-policy/')); ?>" style="color:rgba(255,255,255,.5)">Cookie Policy</a>
        <a href="<?php echo esc_url(home_url('/refund-policy/')); ?>" style="color:rgba(255,255,255,.5)">Refund Policy</a>
        <a href="<?php echo esc_url(home_url('/disclaimer/')); ?>" style="color:rgba(255,255,255,.5)">Disclaimer</a>
        <a href="<?php echo esc_url(home_url('/sitemap/')); ?>" style="color:rgba(255,255,255,.5)">Sitemap</a>
      </div>
    </div>
  </div>

  <!-- Cities -->
  <?php if(!empty($df_cities)): ?>
  <div class="gd4-footer-cities">
    <div class="gd4-footer-cities-title">Popular Cities</div>
    <div class="gd4-footer-city-links">
      <?php foreach($df_cities as $c): ?>
        <a href="<?php echo esc_url(add_query_arg(['city'=>$c->city,'page'=>null],$df_dir)); ?>" style="color:rgba(255,255,255,.45)"><?php echo esc_html($c->city); ?></a>
        <span style="color:rgba(255,255,255,.1)">·</span>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Bottom -->
  <div class="gd4-footer-bottom">
    <div class="gd4-footer-copy" style="color:rgba(255,255,255,.45)">
      © <?php echo date('Y'); ?> <strong style="color:rgba(255,255,255,.7)"><?php echo esc_html($df_site); ?></strong>. All Rights Reserved.
    </div>
    <div class="gd4-footer-bot-links">
      <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>" style="color:rgba(255,255,255,.45)">Privacy Policy</a>
      <a href="<?php echo esc_url(home_url('/terms-of-service/')); ?>" style="color:rgba(255,255,255,.45)">Terms of Service</a>
      <a href="<?php echo esc_url(home_url('/cookie-policy/')); ?>" style="color:rgba(255,255,255,.45)">Cookie Policy</a>
    </div>
  </div>
</footer>