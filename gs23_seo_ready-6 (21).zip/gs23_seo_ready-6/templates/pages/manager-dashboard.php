<?php
/**
 * GoodService — Manager Dashboard (Complete)
 * Accessed via /manager-panel/ → gs_page=manager_dashboard
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
use GoodService\Core\Roles;
if ( ! is_user_logged_in() ) { wp_safe_redirect( home_url( '/manager/login/' ) ); exit; }
// ENTERPRISE-AUDIT FIX (root cause, confirmed): the staff dashboard
// (other-dashboards.php, gs_page=staff_dashboard) requires this file
// directly for its "listings" and "reviews" sections, reusing this
// screen's moderation UI rather than duplicating it. But this gate below
// only ever passed for administrator/gs_manager (Roles::is_manager()) —
// NOT gs_staff or gs_moderator, the exact two roles the staff dashboard
// is for. The practical effect: every gs_staff/gs_moderator account was
// silently redirected to /manager/login/ the moment they clicked "Review
// Listings" or "Approve Reviews" from their own dashboard — those core
// features have been completely broken for staff/moderator accounts.
//
// GS_MGR_TRUSTED_INCLUDE is a same-request-only flag other-dashboards.php
// sets immediately before requiring this file, ONLY after it has already
// independently verified gs_user_can('gs_approve_listings') and scoped
// $section to 'listings'/'reviews' only — it cannot be set by anything a
// client sends. This does not touch this file's own direct URL
// (/manager-panel/): a gs_staff/gs_moderator account visiting that URL
// directly still gets redirected exactly as before — only the
// pre-authorized, capability-checked inclusion path is affected. And it
// is safe to widen even that: every action a manager-only screen can
// trigger (verify/suspend a vendor, approve a verification document) is
// independently re-checked against the real WordPress capability at the
// AJAX layer (Roles::can('gs_verify_vendors')/('gs_manage_vendors')) —
// viewing the markup was never itself the security boundary; those
// AJAX-layer checks are.
$gs_mgr_trusted_include = defined( 'GS_MGR_TRUSTED_INCLUDE' ) && GS_MGR_TRUSTED_INCLUDE === true;
if ( ! $gs_mgr_trusted_include && ! Roles::is_manager() && ! Roles::is_admin_level() ) {
    wp_safe_redirect( home_url( '/manager/login/' ) );
    exit;
}

$section = sanitize_text_field( $_GET['section'] ?? 'dashboard' );
$user    = wp_get_current_user();
global $wpdb;
$pfx   = $wpdb->prefix . 'gs_';
$nonce = wp_create_nonce( 'gs_ajax' );

// Counters
// ENTERPRISE-AUDIT FIX (Part 4, Medium-High: "No caching layer for
// manager/moderation dashboard counts — every page load re-runs 5-8
// uncached COUNT queries on every request"). These 6 run unconditionally
// on EVERY manager-dashboard.php load regardless of which section is being
// viewed (unlike the section-scoped COUNT queries further down this file,
// which only run when that section is actually open) — exactly the
// "every request" cost the finding names. Wrapped in the same
// Cache::remember() pattern admin-dashboard.php's own $dash computation
// already uses (60s TTL — short enough that a newly-approved listing or
// newly-open complaint shows up within a minute, long enough to collapse
// dozens of managers' concurrent page loads onto one real query set).
// Explicitly flushed (not just left to expire) at every write site that
// changes one of these counts, so a manager who just approved a listing
// doesn't see a stale "Pending: 1" for up to 60s after acting on it.
// Same "🔄 Refresh now" manual cache-bust convention already established by
// admin-dashboard.php's own equivalent $dash cache (?dash_refresh=1) —
// reused here rather than instrumenting every write site (approve/reject/
// suspend/verify/complaint-response/etc.) individually, consistent with
// how the existing admin dashboard cache is invalidated.
if ( isset( $_GET['dash_refresh'] ) ) { \GoodService\Core\Cache::delete( 'mgr_dash_counts' ); }
$_mgr_counts = \GoodService\Core\Cache::remember( 'mgr_dash_counts', function() use ( $wpdb, $pfx ) {
    return [
        'pend_listings' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}listings WHERE status='pending'" ),
        'pend_reviews'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}reviews WHERE status='pending'" ),
        'new_leads'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}leads WHERE status='new'" ),
        'pend_ver'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE verification_status='pending'" ),
        'open_comps'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}complaints WHERE status='open'" ),
        'total_vendors' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE is_active=1" ),
    ];
}, 60 );
$pend_listings = $_mgr_counts['pend_listings'];
$pend_reviews  = $_mgr_counts['pend_reviews'];
$new_leads     = $_mgr_counts['new_leads'];
$pend_ver      = $_mgr_counts['pend_ver'];
$open_comps    = $_mgr_counts['open_comps'];
$total_vendors = $_mgr_counts['total_vendors'];
?>
<style>
.gs-mgr{--gs-primary:#2563EB;--gs-dark:#1E3A5F;--gs-green:#059669;--gs-red:#DC2626;--gs-gold:#D97706;--gs-border:#E2E8F0;--gs-bg:#F8FAFC;--gs-txt:#1E293B;--gs-muted:#64748B;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#F8FAFC;min-height:100vh;display:flex;flex-direction:column}
.gs-mgr-nav{background:var(--gs-dark);position:sticky;top:0;z-index:999;box-shadow:0 2px 12px rgba(0,0,0,.25)}
.gs-mgr-nav-inner{display:flex;align-items:center;justify-content:space-between;height:52px;padding:0 20px}
.gs-mgr-nav-brand{display:flex;align-items:center;gap:8px;color:#fff;font-weight:700;font-size:.9rem;text-decoration:none}
.gs-mgr-nav-brand-icon{width:34px;height:34px;border-radius:8px;background:#2563EB;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.85rem}
.gs-mgr-nav-links{display:flex;flex-wrap:wrap;gap:1px;padding:3px 10px;background:#152337;border-top:1px solid rgba(255,255,255,.06);overflow-x:auto;scrollbar-width:none}
.gs-mgr-nav-links::-webkit-scrollbar{display:none}
.gs-mnl{display:inline-flex;align-items:center;gap:4px;padding:5px 9px;border-radius:5px;font-size:.75rem;font-weight:500;color:rgba(255,255,255,.6);text-decoration:none;white-space:nowrap;transition:.12s}
.gs-mnl:hover{background:rgba(255,255,255,.1);color:#fff}
.gs-mnl.on{background:rgba(255,255,255,.17);color:#fff;font-weight:700}
.gs-mnb{background:#EF4444;color:#fff;border-radius:99px;font-size:.56rem;font-weight:700;padding:1px 4px;min-width:14px;text-align:center;line-height:1.5}
.gs-mgr-body{padding:22px;max-width:1300px;margin:0 auto;flex:1}
/* reuse vendor dashboard component styles */
.gs-stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:12px;margin-bottom:22px}
.gs-sc{background:#fff;border:1px solid var(--gs-border);border-radius:12px;padding:16px;display:flex;align-items:center;gap:11px}
.gs-sc-icon{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.15rem;flex-shrink:0}
.gs-sc-val{font-size:1.4rem;font-weight:800;line-height:1;color:var(--gs-txt)}
.gs-sc-lbl{font-size:.7rem;color:var(--gs-muted);margin-top:2px}
.gs-card{background:#fff;border:1px solid var(--gs-border);border-radius:12px;padding:18px;margin-bottom:14px}
.gs-card-title{font-size:.88rem;font-weight:700;color:var(--gs-dark);margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid #F1F5F9}
.gs-ph{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:22px;flex-wrap:wrap}
.gs-ph-title{font-size:1.15rem;font-weight:800;color:var(--gs-dark)}
.gs-ph-sub{font-size:.79rem;color:var(--gs-muted);margin-top:2px}
.gs-tbl-wrap{background:#fff;border:1px solid var(--gs-border);border-radius:12px;overflow:hidden;margin-bottom:16px;overflow-x:auto}
.gs-tbl{width:100%;border-collapse:collapse;font-size:.82rem;min-width:600px}
.gs-tbl th{background:#F8FAFC;padding:9px 13px;font-weight:700;color:#475569;text-align:left;font-size:.74rem;border-bottom:1px solid var(--gs-border)}
.gs-tbl td{padding:9px 13px;border-bottom:1px solid #F1F5F9;color:#334155;vertical-align:middle}
.gs-tbl tr:last-child td{border-bottom:none}
.gs-tbl tr:hover td{background:#FAFBFC}
.gs-btn{display:inline-flex;align-items:center;gap:5px;padding:7px 14px;border-radius:7px;font-size:.8rem;font-weight:600;cursor:pointer;border:1.5px solid transparent;transition:all .13s;text-decoration:none;font-family:inherit;white-space:nowrap}
.gs-btn:disabled{opacity:.5;cursor:not-allowed}
.gs-btn-primary{background:var(--gs-primary);color:#fff;border-color:var(--gs-primary)}
.gs-btn-primary:hover:not(:disabled){background:#1D4ED8}
.gs-btn-green{background:var(--gs-green);color:#fff;border-color:var(--gs-green)}
.gs-btn-green:hover:not(:disabled){background:#047857}
.gs-btn-red{background:var(--gs-red);color:#fff;border-color:var(--gs-red)}
.gs-btn-red:hover:not(:disabled){background:#B91C1C}
.gs-btn-ghost{background:#F1F5F9;color:#334155;border-color:var(--gs-border)}
.gs-btn-ghost:hover:not(:disabled){background:#E2E8F0}
.gs-btn-sm{padding:5px 11px;font-size:.76rem}
.gs-btn-xs{padding:3px 7px;font-size:.7rem}
.gs-badge{display:inline-flex;align-items:center;padding:2px 8px;border-radius:20px;font-size:.67rem;font-weight:700;white-space:nowrap}
.gs-badge-green{background:#ECFDF5;color:var(--gs-green)}
.gs-badge-red{background:#FEF2F2;color:var(--gs-red)}
.gs-badge-gold{background:#FFFBEB;color:var(--gs-gold)}
.gs-badge-blue{background:#EFF6FF;color:var(--gs-primary)}
.gs-badge-grey{background:#F1F5F9;color:#64748B}
.gs-empty{text-align:center;padding:44px 18px;color:#94A3B8}
.gs-inp{width:100%;padding:8px 11px;border:1.5px solid var(--gs-border);border-radius:7px;font-size:.85rem;color:var(--gs-txt);outline:none;background:#fff;transition:border .15s}
.gs-inp:focus{border-color:var(--gs-primary)}
.gs-fg{margin-bottom:12px}
.gs-lbl{display:block;font-size:.75rem;font-weight:700;color:#475569;margin-bottom:4px}
.gs-imsg{padding:9px 14px;border-radius:8px;font-size:.82rem;margin-bottom:10px;display:none}
.gs-imsg.ok{background:#ECFDF5;color:#065F46;display:block}
.gs-imsg.err{background:#FEF2F2;color:#991B1B;display:block}
.gs-sel{padding:6px 10px;border:1.5px solid var(--gs-border);border-radius:7px;font-size:.82rem;color:var(--gs-txt);background:#fff;outline:none}
.gs-pagination{display:flex;gap:5px;flex-wrap:wrap;margin-top:14px}
.gs-page-btn{padding:5px 11px;border-radius:6px;background:#F1F5F9;color:#334155;text-decoration:none;font-size:.79rem;font-weight:600;border:1.5px solid var(--gs-border)}
.gs-page-btn.on,.gs-page-btn:hover{background:var(--gs-primary);color:#fff;border-color:var(--gs-primary)}
@media(max-width:768px){.gs-stat-grid{grid-template-columns:repeat(2,1fr)}.gs-mnl{font-size:.7rem;padding:4px 5px}}
</style>

<div class="gs-mgr">
<nav class="gs-mgr-nav">
  <div class="gs-mgr-nav-inner">
    <a href="?section=dashboard" class="gs-mgr-nav-brand">
      <div class="gs-mgr-nav-brand-icon">M</div>
      <div>
        <div>Manager Panel</div>
        <div style="font-size:.6rem;font-weight:400;opacity:.5"><?php echo esc_html($user->display_name); ?></div>
      </div>
    </a>
    <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" style="font-size:.72rem;color:rgba(255,255,255,.45);text-decoration:none">Logout</a>
  </div>
  <div class="gs-mgr-nav-links">
    <a href="?section=dashboard"    class="gs-mnl <?php echo $section==='dashboard'?'on':''; ?>">📊 Dashboard</a>
    <a href="?section=listings"     class="gs-mnl <?php echo $section==='listings'?'on':''; ?>">🏢 Listings <?php if($pend_listings): ?><span class="gs-mnb"><?php echo $pend_listings; ?></span><?php endif; ?></a>
    <a href="?section=leads"        class="gs-mnl <?php echo $section==='leads'?'on':''; ?>">📞 Leads <?php if($new_leads): ?><span class="gs-mnb"><?php echo $new_leads; ?></span><?php endif; ?></a>
    <a href="?section=vendors"      class="gs-mnl <?php echo $section==='vendors'?'on':''; ?>">👤 Vendors</a>
    <a href="?section=reviews"      class="gs-mnl <?php echo $section==='reviews'?'on':''; ?>">⭐ Reviews <?php if($pend_reviews): ?><span class="gs-mnb"><?php echo $pend_reviews; ?></span><?php endif; ?></a>
    <a href="?section=verification" class="gs-mnl <?php echo $section==='verification'?'on':''; ?>">✅ Verification <?php if($pend_ver): ?><span class="gs-mnb"><?php echo $pend_ver; ?></span><?php endif; ?></a>
    <a href="?section=complaints"   class="gs-mnl <?php echo $section==='complaints'?'on':''; ?>">⚠ Complaints <?php if($open_comps): ?><span class="gs-mnb"><?php echo $open_comps; ?></span><?php endif; ?></a>
    <a href="?section=analytics"    class="gs-mnl <?php echo $section==='analytics'?'on':''; ?>">📈 Analytics</a>
    <a href="?section=account"      class="gs-mnl <?php echo $section==='account'?'on':''; ?>">🔒 Account</a>
  </div>
</nav>

<div class="gs-mgr-body">
<?php switch($section):

// ══ DASHBOARD ════════════════════════════════════════════════════════
case 'dashboard': default: ?>
<div class="gs-ph"><div class="gs-ph-title">📊 Manager Overview</div><div class="gs-ph-sub">Platform health at a glance</div></div>
<div class="gs-stat-grid">
  <?php foreach([
    ['Total Vendors', $total_vendors, '👤', '#EFF6FF','#2563EB'],
    ['Pending Listings', $pend_listings, '⏳', '#FFFBEB','#D97706'],
    ['New Leads', $new_leads, '📞', '#FEF2F2','#DC2626'],
    ['Pending Reviews', $pend_reviews, '⭐', '#FFFBEB','#D97706'],
    ['Pending Verification', $pend_ver, '✅', '#F0FDF4','#059669'],
    ['Open Complaints', $open_comps, '⚠', '#FEF2F2','#DC2626'],
    ['Active Listings', (int)$wpdb->get_var("SELECT COUNT(*) FROM {$pfx}listings WHERE status='active'"), '🏢', '#EFF6FF','#2563EB'],
    ['Total Leads Today', (int)$wpdb->get_var("SELECT COUNT(*) FROM {$pfx}leads WHERE DATE(created_at)=CURDATE()"), '📊', '#F0FDF4','#059669'],
  ] as $s): ?>
  <div class="gs-sc">
    <div class="gs-sc-icon" style="background:<?php echo $s[3]; ?>"><?php echo $s[2]; ?></div>
    <div><div class="gs-sc-val" style="color:<?php echo $s[4]; ?>"><?php echo number_format($s[1]); ?></div><div class="gs-sc-lbl"><?php echo $s[0]; ?></div></div>
  </div>
  <?php endforeach; ?>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
  <div class="gs-card">
    <div class="gs-card-title">⏳ Pending Listings <a href="?section=listings" style="float:right;font-size:.73rem;font-weight:400;color:var(--gs-primary)">Review all →</a></div>
    <?php $pend=array_slice($wpdb->get_results("SELECT l.*,vp.business_name as vname FROM {$pfx}listings l LEFT JOIN {$pfx}vendor_profiles vp ON l.vendor_id=vp.id WHERE l.status='pending' ORDER BY l.created_at ASC LIMIT 8"),0,8); ?>
    <?php foreach($pend as $l): ?>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid #F1F5F9;gap:10px">
      <div style="flex:1;min-width:0">
        <div style="font-weight:600;font-size:.87rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo esc_html($l->title); ?></div>
        <div style="font-size:.73rem;color:var(--gs-muted)"><?php echo esc_html($l->vname??'—'); ?> · <?php echo gs_time_ago($l->created_at); ?></div>
      </div>
      <div style="display:flex;gap:4px;flex-shrink:0">
        <button onclick="gsMgrApprove(<?php echo $l->id; ?>,this)" class="gs-btn gs-btn-green gs-btn-xs">✓</button>
        <button onclick="gsMgrReject(<?php echo $l->id; ?>,this)" class="gs-btn gs-btn-red gs-btn-xs">✕</button>
        <?php if($l->slug): ?><a href="<?php echo home_url('/listing/'.$l->slug.'/'); ?>" target="_blank" class="gs-btn gs-btn-ghost gs-btn-xs">👁</a><?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if(!$pend): ?><div class="gs-empty" style="padding:24px"><div style="font-size:1.8rem">✅</div><div>All listings reviewed</div></div><?php endif; ?>
  </div>

  <div class="gs-card">
    <div class="gs-card-title">📞 Recent Leads <a href="?section=leads" style="float:right;font-size:.73rem;font-weight:400;color:var(--gs-primary)">All leads →</a></div>
    <?php $rl=$wpdb->get_results("SELECT l.*,li.title as lt FROM {$pfx}leads l LEFT JOIN {$pfx}listings li ON l.listing_id=li.id ORDER BY l.created_at DESC LIMIT 8"); ?>
    <?php foreach($rl as $l): ?>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid #F1F5F9;gap:10px">
      <div style="flex:1;min-width:0">
        <div style="font-weight:600;font-size:.87rem"><?php echo esc_html($l->name); ?></div>
        <div style="font-size:.73rem;color:var(--gs-muted)"><?php echo esc_html($l->phone); ?><?php if($l->product_name): ?> · <?php echo esc_html($l->product_name); ?><?php endif; ?></div>
      </div>
      <div style="display:flex;gap:4px;flex-shrink:0">
        <span class="gs-badge <?php echo $l->status==='new'?'gs-badge-blue':'gs-badge-grey'; ?>"><?php echo ucfirst($l->status); ?></span>
        <a href="tel:<?php echo esc_attr($l->phone); ?>" class="gs-btn gs-btn-green gs-btn-xs">📞</a>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if(!$rl): ?><div class="gs-empty" style="padding:24px"><div>No leads yet</div></div><?php endif; ?>
  </div>
</div>

<?php break;

// ══ LISTINGS ═════════════════════════════════════════════════════════
case 'listings':
  $lst_status = sanitize_text_field($_GET['lstat']??'pending');
  $lst_search = sanitize_text_field($_GET['q']??'');
  $lst_pg     = max(1,(int)($_GET['p']??1));
  $lst_per    = 20;
  $lst_off    = ($lst_pg-1)*$lst_per;
  $lw = '1=1';
  if($lst_status&&$lst_status!=='all') $lw.=$wpdb->prepare(' AND l.status=%s',$lst_status);
  if($lst_search){ $like='%'.$wpdb->esc_like($lst_search).'%'; $lw.=$wpdb->prepare(' AND (l.title LIKE %s OR vp.business_name LIKE %s OR l.city LIKE %s)',$like,$like,$like); }
  $lst_total=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$pfx}listings l LEFT JOIN {$pfx}vendor_profiles vp ON l.vendor_id=vp.id WHERE $lw");
  $lst_rows=$wpdb->get_results("SELECT l.*,vp.business_name,vp.verification_status,c.name as cat_name FROM {$pfx}listings l LEFT JOIN {$pfx}vendor_profiles vp ON l.vendor_id=vp.id LEFT JOIN {$pfx}categories c ON c.id=l.category_id WHERE $lw ORDER BY l.created_at DESC LIMIT $lst_per OFFSET $lst_off");
?>
<div class="gs-ph"><div><div class="gs-ph-title">🏢 Listings</div><div class="gs-ph-sub"><?php echo $lst_total; ?> total</div></div></div>
<div style="display:flex;gap:6px;margin-bottom:14px;flex-wrap:wrap;align-items:center">
  <?php foreach(['pending'=>'⏳ Pending','active'=>'✅ Active','rejected'=>'❌ Rejected','all'=>'All'] as $sv=>$sl): ?>
  <a href="?section=listings&lstat=<?php echo $sv; ?>" class="gs-btn gs-btn-sm <?php echo $lst_status===$sv?'gs-btn-primary':'gs-btn-ghost'; ?>"><?php echo $sl; ?></a>
  <?php endforeach; ?>
  <form method="get" style="display:flex;gap:6px;margin-left:auto"><input type="hidden" name="section" value="listings"><input type="hidden" name="lstat" value="<?php echo esc_attr($lst_status); ?>"><input type="text" name="q" class="gs-inp" style="width:180px" placeholder="Search…" value="<?php echo esc_attr($lst_search); ?>"><button type="submit" class="gs-btn gs-btn-primary gs-btn-sm">Search</button></form>
</div>
<?php // ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "No bulk actions
      // anywhere — manager listings/leads/vendors tables... process one row
      // at a time with individual confirm dialogs"). Reuses the same
      // gs_admin_bulk_listings/gs_admin_bulk_vendors backend actions already
      // built and used on the admin Listings/Vendors screens (require_admin()
      // already passes for gs_manager — Roles::is_admin_level() includes it
      // — so no new backend permission work was needed here, only the UI). ?>
<div id="gs-mgr-bulk-bar-listings" style="display:none;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:10px;padding:10px 14px;margin-bottom:12px;align-items:center;gap:10px;flex-wrap:wrap">
  <span id="gs-mgr-bulk-count-listings" style="font-size:.84rem;font-weight:600;color:#1D4ED8">0 selected</span>
  <select id="gs-mgr-bulk-action-listings" class="gs-sel" style="width:auto;font-size:.82rem;padding:5px 10px">
    <option value="">Choose action…</option>
    <option value="approve">✓ Approve</option>
    <option value="reject">✕ Reject</option>
    <option value="suspend">⏸ Suspend</option>
  </select>
  <button class="gs-btn gs-btn-sm gs-btn-primary" onclick="gsMgrBulkApply('listings')">Apply</button>
  <button class="gs-btn gs-btn-sm gs-btn-ghost" onclick="gsMgrBulkClear('listings')">Clear</button>
</div>
<div class="gs-tbl-wrap">
  <table class="gs-tbl">
    <thead><tr><th style="width:34px"><input type="checkbox" onchange="gsMgrBulkToggleAll('listings',this)"></th><th>Listing</th><th>Vendor</th><th>Category</th><th>Type</th><th>Status</th><th>Submitted</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach($lst_rows as $l):
      $sc=['active'=>'gs-badge-green','pending'=>'gs-badge-gold','draft'=>'gs-badge-grey','rejected'=>'gs-badge-red','suspended'=>'gs-badge-red'];
    ?>
    <tr>
      <td><input type="checkbox" class="gs-mgr-bulk-cb-listings" value="<?php echo (int)$l->id; ?>" onchange="gsMgrBulkUpdateCount('listings')"></td>
      <td>
        <div style="font-weight:700"><?php echo esc_html($l->title); ?></div>
        <?php if($l->city): ?><div style="font-size:.73rem;color:var(--gs-muted)">📍 <?php echo esc_html($l->city); ?></div><?php endif; ?>
      </td>
      <td style="font-size:.82rem"><?php echo esc_html($l->business_name??'—'); ?></td>
      <td style="font-size:.82rem"><?php echo esc_html($l->cat_name??'—'); ?></td>
      <td><span class="gs-badge gs-badge-blue"><?php echo ucfirst($l->listing_type??'service'); ?></span></td>
      <td><span class="gs-badge <?php echo $sc[$l->status]??'gs-badge-grey'; ?>"><?php echo ucfirst($l->status); ?></span></td>
      <td style="font-size:.74rem;color:#94A3B8"><?php echo gs_time_ago($l->created_at); ?></td>
      <td>
        <div style="display:flex;gap:4px">
          <?php if($l->status==='pending'): ?>
          <button onclick="gsMgrApprove(<?php echo $l->id; ?>,this)" class="gs-btn gs-btn-green gs-btn-xs">✓ Approve</button>
          <button onclick="gsMgrReject(<?php echo $l->id; ?>,this)" class="gs-btn gs-btn-red gs-btn-xs">✕ Reject</button>
          <?php endif; ?>
          <?php if($l->status==='active'): ?><a href="<?php echo home_url('/listing/'.$l->slug.'/'); ?>" target="_blank" class="gs-btn gs-btn-ghost gs-btn-xs">👁 View</a><?php endif; ?>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if(!$lst_rows): ?><tr><td colspan="8" style="text-align:center;padding:32px;color:#94A3B8">No listings found.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php if($lst_total>$lst_per): ?>
<div class="gs-pagination">
  <?php for($pg=1;$pg<=ceil($lst_total/$lst_per);$pg++): ?>
  <a href="?section=listings&lstat=<?php echo esc_attr($lst_status); ?>&q=<?php echo urlencode($lst_search); ?>&p=<?php echo $pg; ?>" class="gs-page-btn <?php echo $pg===$lst_pg?'on':''; ?>"><?php echo $pg; ?></a>
  <?php endfor; ?>
</div>
<?php endif; break;

// ══ LEADS ════════════════════════════════════════════════════════════
case 'leads':
  $l_status = sanitize_text_field($_GET['lstat']??'all');
  $l_search = sanitize_text_field($_GET['q']??'');
  $l_pg     = max(1,(int)($_GET['p']??1));
  $l_per    = 20; $l_off = ($l_pg-1)*$l_per;
  $lw2 = '1=1';
  if($l_status&&$l_status!=='all') $lw2.=$wpdb->prepare(' AND l.status=%s',$l_status);
  if($l_search){ $like='%'.$wpdb->esc_like($l_search).'%'; $lw2.=$wpdb->prepare(' AND (l.name LIKE %s OR l.phone LIKE %s OR l.email LIKE %s OR l.product_name LIKE %s OR li.title LIKE %s)',$like,$like,$like,$like,$like); }
  $l_total=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$pfx}leads l LEFT JOIN {$pfx}listings li ON l.listing_id=li.id WHERE $lw2");
  $l_rows=$wpdb->get_results("SELECT l.*,li.title as lt,vp.business_name as vendor_name FROM {$pfx}leads l LEFT JOIN {$pfx}listings li ON l.listing_id=li.id LEFT JOIN {$pfx}vendor_profiles vp ON l.vendor_id=vp.id WHERE $lw2 ORDER BY l.created_at DESC LIMIT $l_per OFFSET $l_off");
  $view_lead=(int)($_GET['view']??0);
  if($view_lead):
    $vl=$wpdb->get_row($wpdb->prepare("SELECT l.*,li.title as lt,vp.business_name as vname FROM {$pfx}leads l LEFT JOIN {$pfx}listings li ON l.listing_id=li.id LEFT JOIN {$pfx}vendor_profiles vp ON l.vendor_id=vp.id WHERE l.id=%d",$view_lead));
?>
<div class="gs-ph"><div class="gs-ph-title">Lead Detail</div><a href="?section=leads" class="gs-btn gs-btn-ghost gs-btn-sm">← Back</a></div>
<?php if($vl): ?>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
  <div class="gs-card">
    <div class="gs-card-title">Customer Information</div>
    <?php foreach(['Name'=>$vl->name,'Phone'=>$vl->phone,'Email'=>$vl->email?:'—','City'=>$vl->city?:'—','Vendor'=>$vl->vname?:'—','Listing'=>$vl->lt?:'—','Product/Service'=>$vl->product_name?:'—','Quantity'=>$vl->quantity?:'—','Purchase Date'=>$vl->purchase_date?:'—','Callback Date'=>$vl->callback_date?:'—'] as $k=>$v): if(!$v||$v==='—') continue; ?>
    <div style="display:flex;gap:10px;padding:7px 0;border-bottom:1px solid #F1F5F9;font-size:.85rem"><span style="font-weight:600;color:var(--gs-muted);width:130px;flex-shrink:0"><?php echo $k; ?></span><span><?php echo esc_html($v); ?></span></div>
    <?php endforeach; ?>
    <?php if($vl->message): ?>
    <div style="margin-top:12px;background:#F8FAFC;border-radius:8px;padding:12px;font-size:.85rem;line-height:1.65;color:#334155"><strong style="display:block;font-size:.72rem;color:var(--gs-muted);margin-bottom:5px">MESSAGE:</strong><?php echo nl2br(esc_html($vl->message)); ?></div>
    <?php endif; ?>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px">
      <a href="tel:<?php echo esc_attr($vl->phone); ?>" class="gs-btn gs-btn-green" style="justify-content:center">📞 Call</a>
      <?php if($vl->phone): ?><a href="https://wa.me/<?php echo preg_replace('/[^0-9]/','',esc_attr($vl->phone)); ?>" target="_blank" class="gs-btn" style="background:#25D366;color:#fff;border-color:#25D366;justify-content:center">💬 WhatsApp</a><?php endif; ?>
    </div>
  </div>
  <div class="gs-card">
    <div class="gs-card-title">Status Management</div>
    <div style="margin-bottom:12px">
      <label style="font-size:.75rem;font-weight:700;color:var(--gs-muted);display:block;margin-bottom:5px">Update Status</label>
      <select id="mgr-lead-status" class="gs-sel" style="width:100%">
        <?php foreach(['new','seen','contacted','qualified','converted','junk'] as $ls): ?><option value="<?php echo $ls; ?>" <?php echo $vl->status===$ls?'selected':''; ?>><?php echo ucfirst($ls); ?></option><?php endforeach; ?>
      </select>
      <button onclick="gsPost('gs_admin_update_lead_status',{nonce:'<?php echo esc_js($nonce); ?>',lead_id:<?php echo $vl->id; ?>,status:document.getElementById('mgr-lead-status').value},function(){gsToast('Status updated','success');})" class="gs-btn gs-btn-primary gs-btn-sm" style="margin-top:8px;width:100%;justify-content:center">Update Status</button>
    </div>
    <div style="margin-top:12px">
      <label style="font-size:.75rem;font-weight:700;color:var(--gs-muted);display:block;margin-bottom:5px">Add Note</label>
      <textarea id="mgr-lead-note" style="width:100%;padding:8px;border:1.5px solid var(--gs-border);border-radius:7px;font-size:.83rem;resize:none;min-height:80px" placeholder="Internal note about this lead..."></textarea>
      <button onclick="gsPost('gs_add_lead_note',{nonce:'<?php echo esc_js($nonce); ?>',lead_id:<?php echo $vl->id; ?>,note:document.getElementById('mgr-lead-note').value},function(){gsToast('Note saved','success');})" class="gs-btn gs-btn-ghost gs-btn-sm" style="margin-top:6px;width:100%;justify-content:center">Save Note</button>
    </div>
    <div style="margin-top:14px;padding:10px 12px;background:#FEF2F2;border-radius:8px;display:flex;justify-content:space-between;align-items:center">
      <span style="font-size:.8rem;color:var(--gs-red)">Danger Zone</span>
      <?php /* Real fix — this button only sets status='junk' via gs_admin_update_lead_status
               (the button itself is labelled "Mark Junk"), it does not delete the lead
               row at all — reversible from the status dropdown above at any time. The
               confirm text was claiming permanent deletion, which is both inaccurate
               and needlessly alarming. Also names the lead, matching the naming
               convention used for destructive confirms elsewhere in this codebase. */ ?>
      <button onclick="if(confirm('Mark lead &quot;<?php echo esc_js( $vl->name ); ?>&quot; as junk? You can change its status back at any time from the dropdown above.'))gsPost('gs_admin_update_lead_status',{nonce:'<?php echo esc_js($nonce); ?>',lead_id:<?php echo $vl->id; ?>,status:'junk'},function(){gsToast('Lead marked as junk','info');setTimeout(function(){history.back();},800);})" class="gs-btn gs-btn-red gs-btn-xs">Mark Junk</button>
    </div>
  </div>
</div>
<?php else: echo '<div class="gs-empty"><div class="gs-ph-title">Lead not found</div></div>'; endif;
  else: ?>
<div class="gs-ph"><div><div class="gs-ph-title">📞 All Leads</div><div class="gs-ph-sub"><?php echo $l_total; ?> total</div></div></div>
<div style="display:flex;gap:6px;margin-bottom:14px;flex-wrap:wrap;align-items:center">
  <?php foreach(['all','new','seen','contacted','converted','junk'] as $ls): ?>
  <a href="?section=leads&lstat=<?php echo $ls; ?>" class="gs-btn gs-btn-sm <?php echo $l_status===$ls?'gs-btn-primary':'gs-btn-ghost'; ?>"><?php echo ucfirst($ls); ?></a>
  <?php endforeach; ?>
  <!-- ENTERPRISE-AUDIT FIX (Part 4, Medium: "No CSV export of vendor/lead
       lists for managers"). Exports whatever the current status tab +
       search matches, mirroring this row's own filter scope. -->
  <a href="<?php echo esc_url( admin_url( 'admin-ajax.php' ) . '?action=gs_export_manager_leads_csv&nonce=' . $nonce . ( $l_status && $l_status!=='all' ? '&lstat=' . $l_status : '' ) . ( $l_search ? '&q=' . rawurlencode( $l_search ) : '' ) ); ?>" class="gs-btn gs-btn-ghost gs-btn-sm">⬇ Export CSV</a>
  <form method="get" style="display:flex;gap:6px;margin-left:auto"><input type="hidden" name="section" value="leads"><input type="hidden" name="lstat" value="<?php echo esc_attr($l_status); ?>"><input type="text" name="q" class="gs-inp" style="width:180px" placeholder="Search name, phone, product…" value="<?php echo esc_attr($l_search); ?>"><button type="submit" class="gs-btn gs-btn-primary gs-btn-sm">Search</button></form>
</div>
<?php // ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level bulk-actions finding
      // — completes the leads tab; listings/vendors were done at v7.437.0).
      // New gs_admin_bulk_leads backend (see AjaxController::adminBulkLeads()
      // — no reusable existing endpoint for leads, unlike listings/vendors). ?>
<div id="gs-mgr-bulk-bar-leads" style="display:none;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:10px;padding:10px 14px;margin-bottom:12px;align-items:center;gap:10px;flex-wrap:wrap">
  <span id="gs-mgr-bulk-count-leads" style="font-size:.84rem;font-weight:600;color:#1D4ED8">0 selected</span>
  <select id="gs-mgr-bulk-action-leads" class="gs-sel" style="width:auto;font-size:.82rem;padding:5px 10px">
    <option value="">Choose status…</option>
    <?php foreach(['new'=>'New','seen'=>'Seen','contacted'=>'Contacted','qualified'=>'Qualified','converted'=>'Converted','junk'=>'Junk'] as $sv=>$sl): ?>
    <option value="<?php echo $sv; ?>"><?php echo $sl; ?></option>
    <?php endforeach; ?>
  </select>
  <button class="gs-btn gs-btn-sm gs-btn-primary" onclick="gsMgrBulkApply('leads')">Apply</button>
  <button class="gs-btn gs-btn-sm gs-btn-ghost" onclick="gsMgrBulkClear('leads')">Clear</button>
</div>
<div class="gs-tbl-wrap">
  <table class="gs-tbl">
    <thead><tr><th style="width:34px"><input type="checkbox" onchange="gsMgrBulkToggleAll('leads',this)"></th><th>Customer</th><th>Phone</th><th>Vendor</th><th>Listing</th><th>Product/Service</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach($l_rows as $l):
      $sc=['new'=>'gs-badge-blue','seen'=>'gs-badge-grey','contacted'=>'gs-badge-gold','converted'=>'gs-badge-green','junk'=>'gs-badge-red'];
    ?>
    <tr>
      <td><input type="checkbox" class="gs-mgr-bulk-cb-leads" value="<?php echo (int)$l->id; ?>" onchange="gsMgrBulkUpdateCount('leads')"></td>
      <td style="font-weight:700"><?php echo esc_html($l->name); ?></td>
      <td><a href="tel:<?php echo esc_attr($l->phone); ?>" style="font-size:.82rem"><?php echo esc_html($l->phone); ?></a></td>
      <td style="font-size:.8rem"><?php echo esc_html($l->vendor_name??'—'); ?></td>
      <td style="font-size:.8rem;max-width:130px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo esc_html($l->lt??'—'); ?></td>
      <td style="font-size:.8rem"><?php echo esc_html($l->product_name?:'—'); ?></td>
      <td>
        <select onchange="gsPost('gs_admin_update_lead_status',{nonce:'<?php echo esc_js($nonce); ?>',lead_id:<?php echo $l->id; ?>,status:this.value},function(){gsToast('Updated','success');})" class="gs-sel" style="font-size:.74rem;padding:3px 7px;width:auto">
          <?php foreach(['new','seen','contacted','converted','junk'] as $ls): ?><option value="<?php echo $ls; ?>" <?php echo $l->status===$ls?'selected':''; ?>><?php echo ucfirst($ls); ?></option><?php endforeach; ?>
        </select>
      </td>
      <td style="font-size:.74rem;color:#94A3B8;white-space:nowrap"><?php echo gs_time_ago($l->created_at); ?></td>
      <td>
        <div style="display:flex;gap:4px">
          <?php if($l->phone): ?><a href="https://wa.me/<?php echo preg_replace('/[^0-9]/','',esc_attr($l->phone)); ?>" target="_blank" class="gs-btn gs-btn-xs" style="background:#25D366;color:#fff;border:none">💬</a><?php endif; ?>
          <a href="?section=leads&view=<?php echo $l->id; ?>" class="gs-btn gs-btn-primary gs-btn-xs">View</a>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if(!$l_rows): ?><tr><td colspan="9" style="text-align:center;padding:32px;color:#94A3B8">No leads found.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php if($l_total>$l_per): ?>
<div class="gs-pagination">
  <?php for($pg=1;$pg<=ceil($l_total/$l_per);$pg++): ?>
  <a href="?section=leads&lstat=<?php echo esc_attr($l_status); ?>&q=<?php echo urlencode($l_search); ?>&p=<?php echo $pg; ?>" class="gs-page-btn <?php echo $pg===$l_pg?'on':''; ?>"><?php echo $pg; ?></a>
  <?php endfor; ?>
</div>
<?php endif; endif; break;

// ══ VENDORS ══════════════════════════════════════════════════════════
case 'vendors':
  $v_search = sanitize_text_field($_GET['q']??'');
  $v_pg = max(1,(int)($_GET['p']??1)); $v_per=20; $v_off=($v_pg-1)*$v_per;
  $vw='1=1';
  if($v_search){ $vlike='%'.$wpdb->esc_like($v_search).'%'; $vw.=$wpdb->prepare(' AND (vp.business_name LIKE %s OR vp.email LIKE %s OR u.user_email LIKE %s)',$vlike,$vlike,$vlike); }
  $v_total=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$pfx}vendor_profiles vp LEFT JOIN {$wpdb->prefix}users u ON u.ID=vp.user_id WHERE $vw");
  $v_rows=$wpdb->get_results("SELECT vp.*,u.user_email,u.display_name,(SELECT COUNT(*) FROM {$pfx}listings l WHERE l.vendor_id=vp.id AND l.status='active') AS active_listings FROM {$pfx}vendor_profiles vp LEFT JOIN {$wpdb->prefix}users u ON u.ID=vp.user_id WHERE $vw ORDER BY vp.created_at DESC LIMIT $v_per OFFSET $v_off");
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">👤 Vendors</div><div class="gs-ph-sub"><?php echo $v_total; ?> total</div></div>
  <div style="display:flex;gap:8px;align-items:center">
    <!-- ENTERPRISE-AUDIT FIX (Part 4, Medium: "No CSV export of vendor/lead
         lists for managers"). Exports whatever the current search filter
         matches (not just the current page), same as this row's own
         Search form scope. -->
    <a href="<?php echo esc_url( admin_url( 'admin-ajax.php' ) . '?action=gs_export_manager_vendors_csv&nonce=' . $nonce . ( $v_search ? '&q=' . rawurlencode( $v_search ) : '' ) ); ?>" class="gs-btn gs-btn-ghost gs-btn-sm">⬇ Export CSV</a>
    <form method="get" style="display:flex;gap:6px"><input type="hidden" name="section" value="vendors"><input type="text" name="q" class="gs-inp" style="width:200px" placeholder="Search vendor…" value="<?php echo esc_attr($v_search); ?>"><button type="submit" class="gs-btn gs-btn-primary gs-btn-sm">Search</button></form>
  </div>
</div>
<?php // ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level bulk-actions finding —
      // see the matching comment on the Listings tab above). Reuses the
      // existing gs_admin_bulk_vendors backend action. ?>
<div id="gs-mgr-bulk-bar-vendors" style="display:none;background:#EFF6FF;border:1px solid #BFDBFE;border-radius:10px;padding:10px 14px;margin-bottom:12px;align-items:center;gap:10px;flex-wrap:wrap">
  <span id="gs-mgr-bulk-count-vendors" style="font-size:.84rem;font-weight:600;color:#1D4ED8">0 selected</span>
  <select id="gs-mgr-bulk-action-vendors" class="gs-sel" style="width:auto;font-size:.82rem;padding:5px 10px">
    <option value="">Choose action…</option>
    <option value="verify">✅ Verify</option>
    <option value="suspend">⏸ Suspend</option>
    <option value="unsuspend">▶ Unsuspend</option>
  </select>
  <button class="gs-btn gs-btn-sm gs-btn-primary" onclick="gsMgrBulkApply('vendors')">Apply</button>
  <button class="gs-btn gs-btn-sm gs-btn-ghost" onclick="gsMgrBulkClear('vendors')">Clear</button>
</div>
<div class="gs-tbl-wrap">
  <table class="gs-tbl">
    <thead><tr><th style="width:34px"><input type="checkbox" onchange="gsMgrBulkToggleAll('vendors',this)"></th><th>Business</th><th>Email</th><th>City</th><th>Listings</th><th>Verified</th><th>Active</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach($v_rows as $v): ?>
    <tr>
      <td><input type="checkbox" class="gs-mgr-bulk-cb-vendors" value="<?php echo (int)$v->id; ?>" onchange="gsMgrBulkUpdateCount('vendors')"></td>
      <td style="font-weight:700"><?php echo esc_html($v->business_name?:$v->display_name); ?></td>
      <td style="font-size:.8rem"><?php echo esc_html($v->user_email); ?></td>
      <td style="font-size:.8rem"><?php echo esc_html($v->city?:'—'); ?></td>
      <td style="font-size:.82rem"><?php echo $v->active_listings; ?> active</td>
      <td><?php $vsc=['unverified'=>['gs-badge-grey','❌ No'],'pending'=>['gs-badge-gold','⏳ Pending'],'verified'=>['gs-badge-green','✅ Yes']]; [$vc,$vl]=$vsc[$v->verification_status]??$vsc['unverified']; ?><span class="gs-badge <?php echo $vc; ?>"><?php echo $vl; ?></span></td>
      <td><?php if($v->is_active): ?><span class="gs-badge gs-badge-green">Active</span><?php else: ?><span class="gs-badge gs-badge-red">Suspended</span><?php endif; ?></td>
      <td>
        <div style="display:flex;gap:4px">
<?php
          $_m_ls = $wpdb->get_var($wpdb->prepare("SELECT slug FROM {$wpdb->prefix}gs_listings WHERE vendor_id=%d AND status IN('active','pending') ORDER BY is_featured DESC, created_at ASC LIMIT 1",(int)$v->id));
          ?>
          <?php if($_m_ls): ?><a href="<?php echo esc_url(home_url('/'.$_m_ls.'/')); ?>" target="_blank" class="gs-btn gs-btn-ghost gs-btn-xs">🌐 Page</a><?php endif; ?>
          <?php if($v->verification_status==='pending'): ?><button onclick="gsPost('gs_verify_vendor',{nonce:'<?php echo esc_js($nonce); ?>',vendor_user_id:<?php echo $v->user_id; ?>,status:'verified'},function(){gsToast('Verified!','success');location.reload();})" class="gs-btn gs-btn-green gs-btn-xs">✅ Verify</button><?php endif; ?>
          <button onclick="gsPost('gs_suspend_vendor',{nonce:'<?php echo esc_js($nonce); ?>',vendor_id:<?php echo $v->id; ?>,active:<?php echo $v->is_active?'0':'1'; ?>},function(){location.reload();})" class="gs-btn <?php echo $v->is_active?'gs-btn-red':'gs-btn-green'; ?> gs-btn-xs"><?php echo $v->is_active?'Suspend':'Activate'; ?></button>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if(!$v_rows): ?><tr><td colspan="8" style="text-align:center;padding:32px;color:#94A3B8">No vendors found.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php break;

// ══ REVIEWS ══════════════════════════════════════════════════════════
case 'reviews':
  $pend_rev=$wpdb->get_results("SELECT r.*,l.title as lt FROM {$pfx}reviews r LEFT JOIN {$pfx}listings l ON r.listing_id=l.id WHERE r.status='pending' ORDER BY r.created_at DESC");
?>
<div class="gs-ph"><div><div class="gs-ph-title">⭐ Reviews</div><div class="gs-ph-sub"><?php echo count($pend_rev); ?> pending</div></div></div>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:14px">
  <?php foreach($pend_rev as $r): ?>
  <div class="gs-card">
    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:10px">
      <div>
        <div style="font-weight:700;font-size:.87rem"><?php echo esc_html($r->reviewer_name?:'Anonymous'); ?></div>
        <div style="font-size:.73rem;color:var(--gs-muted)"><?php echo esc_html($r->lt??''); ?> · <?php echo gs_time_ago($r->created_at); ?></div>
        <div style="color:#F59E0B;letter-spacing:1px;margin-top:3px"><?php echo str_repeat('★',(int)$r->rating).str_repeat('☆',5-(int)$r->rating); ?></div>
      </div>
      <span class="gs-badge gs-badge-gold">⏳ Pending</span>
    </div>
    <?php if($r->review_text): ?><div style="font-size:.84rem;color:#475569;line-height:1.65;margin-bottom:12px"><?php echo nl2br(esc_html($r->review_text)); ?></div><?php endif; ?>
    <div style="display:flex;gap:8px">
      <button onclick="gsPost('gs_approve_review',{nonce:'<?php echo esc_js($nonce); ?>',review_id:<?php echo $r->id; ?>},function(){gsToast('Approved','success');this.closest('.gs-card').remove();}.bind(this))" class="gs-btn gs-btn-green gs-btn-sm">✓ Approve</button>
      <button onclick="gsPost('gs_reject_review',{nonce:'<?php echo esc_js($nonce); ?>',review_id:<?php echo $r->id; ?>},function(){gsToast('Rejected','info');this.closest('.gs-card').remove();}.bind(this))" class="gs-btn gs-btn-red gs-btn-sm">✕ Reject</button>
    </div>
  </div>
  <?php endforeach; ?>
  <?php if(!$pend_rev): ?><div class="gs-empty" style="grid-column:1/-1"><div style="font-size:2rem">⭐</div><div class="gs-ph-title" style="margin-top:8px">All reviews reviewed!</div></div><?php endif; ?>
</div>
<?php break;

// ══ VERIFICATION ══════════════════════════════════════════════════════
case 'verification':
  $pend_docs=$wpdb->get_results("SELECT vd.*,vp.business_name,vp.user_id as vid FROM {$pfx}verification_docs vd LEFT JOIN {$pfx}vendor_profiles vp ON vd.vendor_id=vp.id WHERE vd.status='pending' ORDER BY vd.created_at ASC");
?>
<div class="gs-ph"><div><div class="gs-ph-title">✅ Verification Requests</div><div class="gs-ph-sub"><?php echo count($pend_docs); ?> pending</div></div></div>
<?php if($pend_docs): ?>
<div class="gs-tbl-wrap">
  <table class="gs-tbl">
    <thead><tr><th>Vendor</th><th>Document Type</th><th>Submitted</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach($pend_docs as $d): ?>
    <tr>
      <td style="font-weight:700"><?php echo esc_html($d->business_name??'—'); ?></td>
      <td><span class="gs-badge gs-badge-blue"><?php echo esc_html($d->doc_type); ?></span></td>
      <td style="font-size:.76rem;color:#94A3B8"><?php echo gs_time_ago($d->created_at); ?></td>
      <td>
        <div style="display:flex;gap:5px">
          <?php if($d->doc_url): ?><a href="<?php echo esc_url($d->doc_url); ?>" target="_blank" class="gs-btn gs-btn-ghost gs-btn-xs">📄 View Doc</a><?php endif; ?>
          <button onclick="gsPost('gs_verify_vendor',{nonce:'<?php echo esc_js($nonce); ?>',vendor_user_id:<?php echo $d->vid; ?>,status:'verified'},function(){gsToast('Vendor verified!','success');location.reload();})" class="gs-btn gs-btn-green gs-btn-xs">✅ Verify Vendor</button>
          <button onclick="gsPost('gs_verify_vendor',{nonce:'<?php echo esc_js($nonce); ?>',vendor_user_id:<?php echo $d->vid; ?>,status:'unverified'},function(){gsToast('Rejected','info');location.reload();})" class="gs-btn gs-btn-red gs-btn-xs">✕ Reject</button>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php else: ?>
<div class="gs-empty"><div style="font-size:2rem">✅</div><div class="gs-ph-title" style="margin-top:8px">No pending verification requests</div></div>
<?php endif; break;

// ══ COMPLAINTS ════════════════════════════════════════════════════════
case 'complaints':
  $comps=$wpdb->get_results("SELECT c.*,u.display_name as cname FROM {$pfx}complaints c LEFT JOIN {$wpdb->prefix}users u ON u.ID=c.complainant_id ORDER BY c.created_at DESC LIMIT 50");
?>
<div class="gs-ph"><div><div class="gs-ph-title">⚠️ Complaints</div><div class="gs-ph-sub"><?php echo count($comps); ?> total</div></div></div>
<?php if($comps): ?>
<div class="gs-tbl-wrap">
  <table class="gs-tbl">
    <thead><tr><th>Subject</th><th>From</th><th>Type</th><th>Priority</th><th>Status</th><th>Date</th><th>Due</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach($comps as $cp):
      $sc=['open'=>'gs-badge-red','in_review'=>'gs-badge-gold','resolved'=>'gs-badge-green','closed'=>'gs-badge-grey'];
      // ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "No SLA/escalation
      // tracking on complaints... no due-date"). Same overdue-while-still-
      // open logic as the admin Complaints screen.
      $cp_open    = !in_array($cp->status,['resolved','closed','dismissed'],true);
      $cp_overdue = $cp_open && !empty($cp->sla_due_at) && strtotime($cp->sla_due_at) < time();
    ?>
    <tr>
      <td style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600"><?php echo esc_html($cp->subject); ?></td>
      <td style="font-size:.8rem"><?php echo esc_html($cp->cname??'—'); ?></td>
      <td><span class="gs-badge gs-badge-grey"><?php echo str_replace('_',' ',ucfirst($cp->type)); ?></span></td>
      <td><span class="gs-badge <?php echo ['critical'=>'gs-badge-red','high'=>'gs-badge-red','medium'=>'gs-badge-gold','low'=>'gs-badge-grey'][$cp->priority]??'gs-badge-grey'; ?>"><?php echo ucfirst($cp->priority); ?><?php echo !empty($cp->escalated_at)?' ⚡':''; ?></span></td>
      <td><span class="gs-badge <?php echo $sc[$cp->status]??'gs-badge-grey'; ?>"><?php echo ucfirst(str_replace('_',' ',$cp->status)); ?></span></td>
      <td style="font-size:.74rem;color:#94A3B8"><?php echo gs_time_ago($cp->created_at); ?></td>
      <td style="font-size:.74rem;<?php echo $cp_overdue?'color:#DC2626;font-weight:700':'color:#94A3B8'; ?>"><?php echo ($cp_open && $cp->sla_due_at) ? ($cp_overdue?'⏰ ':'').esc_html(\GoodService\Core\Helpers::due_in_or_overdue($cp->sla_due_at)).($cp_overdue?' overdue':'') : '—'; ?></td>
      <td>
        <select onchange="gsPost('gs_update_complaint',{nonce:'<?php echo esc_js($nonce); ?>',complaint_id:<?php echo $cp->id; ?>,status:this.value},function(){gsToast('Updated','success');})" class="gs-sel" style="font-size:.74rem;padding:3px 7px;width:auto">
          <?php foreach(['open','in_review','resolved','closed'] as $cs): ?><option value="<?php echo $cs; ?>" <?php echo $cp->status===$cs?'selected':''; ?>><?php echo ucfirst(str_replace('_',' ',$cs)); ?></option><?php endforeach; ?>
        </select>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php else: ?>
<div class="gs-empty"><div style="font-size:2rem">✅</div><div class="gs-ph-title" style="margin-top:8px">No complaints</div></div>
<?php endif; break;

// ══ ANALYTICS ════════════════════════════════════════════════════════
case 'analytics':
  $days = (int)($_GET['days']??30);
  $top_listings = $wpdb->get_results($wpdb->prepare(
    "SELECT l.title,l.slug,l.views_count,l.leads_count,l.avg_rating,vp.business_name FROM {$pfx}listings l LEFT JOIN {$pfx}vendor_profiles vp ON l.vendor_id=vp.id WHERE l.status='active' ORDER BY l.leads_count DESC LIMIT 10"
  ));
  $top_vendors = $wpdb->get_results($wpdb->prepare(
    "SELECT vp.*,(SELECT COUNT(*) FROM {$pfx}leads WHERE vendor_id=vp.id AND created_at>=DATE_SUB(NOW(),INTERVAL %d DAY)) as recent_leads,(SELECT COUNT(*) FROM {$pfx}listings WHERE vendor_id=vp.id AND status='active') as active_listings FROM {$pfx}vendor_profiles vp ORDER BY recent_leads DESC LIMIT 10",$days
  ));
?>
<div class="gs-ph">
  <div><div class="gs-ph-title">📈 Analytics</div></div>
  <select onchange="window.location='?section=analytics&days='+this.value" class="gs-sel">
    <?php foreach([7=>'Last 7 days',30=>'Last 30 days',90=>'Last 90 days'] as $d=>$dl): ?><option value="<?php echo $d; ?>" <?php echo $d===$days?'selected':''; ?>><?php echo $dl; ?></option><?php endforeach; ?>
  </select>
</div>
<div class="gs-stat-grid">
  <?php foreach([
    ['Total Leads ('.$days.'d)', (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}leads WHERE created_at>=DATE_SUB(NOW(),INTERVAL %d DAY)",$days)), '📞','#EFF6FF','#2563EB'],
    ['New Vendors ('.$days.'d)', (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE created_at>=DATE_SUB(NOW(),INTERVAL %d DAY)",$days)), '👤','#F0FDF4','#059669'],
    ['New Listings ('.$days.'d)', (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}listings WHERE created_at>=DATE_SUB(NOW(),INTERVAL %d DAY)",$days)), '🏢','#FFFBEB','#D97706'],
    ['Page Views ('.$days.'d)', (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}analytics WHERE event_type='view' AND created_at>=DATE_SUB(NOW(),INTERVAL %d DAY)",$days)), '👁','#F5F3FF','#7C3AED'],
  ] as $s): ?>
  <div class="gs-sc">
    <div class="gs-sc-icon" style="background:<?php echo $s[3]; ?>"><?php echo $s[2]; ?></div>
    <div><div class="gs-sc-val" style="color:<?php echo $s[4]; ?>"><?php echo number_format($s[1]); ?></div><div class="gs-sc-lbl"><?php echo $s[0]; ?></div></div>
  </div>
  <?php endforeach; ?>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
  <div class="gs-card">
    <div class="gs-card-title">🏆 Top Listings by Leads</div>
    <?php foreach($top_listings as $i=>$l): ?>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid #F1F5F9">
      <div style="display:flex;gap:10px;align-items:center;flex:1;min-width:0">
        <span style="font-weight:800;color:var(--gs-muted);font-size:.8rem;flex-shrink:0">#<?php echo $i+1; ?></span>
        <div style="min-width:0">
          <div style="font-weight:600;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo esc_html($l->title); ?></div>
          <div style="font-size:.73rem;color:var(--gs-muted)"><?php echo esc_html($l->business_name??''); ?></div>
        </div>
      </div>
      <div style="text-align:right;flex-shrink:0;margin-left:8px">
        <div style="font-weight:700;font-size:.87rem;color:var(--gs-primary)"><?php echo $l->leads_count; ?> leads</div>
        <div style="font-size:.7rem;color:#94A3B8"><?php echo number_format($l->views_count); ?> views</div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if(!$top_listings): ?><div class="gs-empty" style="padding:24px">No listing data yet</div><?php endif; ?>
  </div>
  <div class="gs-card">
    <div class="gs-card-title">🏅 Top Vendors by Recent Leads</div>
    <?php foreach($top_vendors as $i=>$v): ?>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid #F1F5F9">
      <div style="display:flex;gap:10px;align-items:center;flex:1;min-width:0">
        <span style="font-weight:800;color:var(--gs-muted);font-size:.8rem;flex-shrink:0">#<?php echo $i+1; ?></span>
        <div style="min-width:0">
          <div style="font-weight:600;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?php echo esc_html($v->business_name?:$v->email); ?></div>
          <div style="font-size:.73rem;color:var(--gs-muted)"><?php echo $v->active_listings; ?> active listings</div>
        </div>
      </div>
      <div style="font-weight:700;font-size:.87rem;color:var(--gs-primary);flex-shrink:0"><?php echo $v->recent_leads; ?> leads</div>
    </div>
    <?php endforeach; ?>
    <?php if(!$top_vendors): ?><div class="gs-empty" style="padding:24px">No vendor data yet</div><?php endif; ?>
  </div>
</div>
<?php break;

case 'account':
$mgr_user = wp_get_current_user();
?>
<div class="gs-ph"><div><div class="gs-ph-title">🔒 Account &amp; Security</div><div class="gs-ph-sub">Manage your password and account settings</div></div></div>
<div style="max-width:520px">
  <div class="gs-card">
    <div class="gs-card-title" style="margin-bottom:16px">Account Info</div>
    <div style="display:flex;flex-direction:column;gap:10px;font-size:.88rem;color:#475569">
      <div style="display:flex;gap:10px"><span style="font-weight:600;min-width:110px;color:#1E3A5F">Name:</span><span><?php echo esc_html($mgr_user->display_name); ?></span></div>
      <div style="display:flex;gap:10px"><span style="font-weight:600;min-width:110px;color:#1E3A5F">Email:</span><span><?php echo esc_html($mgr_user->user_email); ?></span></div>
      <div style="display:flex;gap:10px"><span style="font-weight:600;min-width:110px;color:#1E3A5F">Role:</span><span><?php echo esc_html(ucfirst(str_replace('gs_','',implode(', ',(array)$mgr_user->roles)))); ?></span></div>
    </div>
  </div>
  <div class="gs-card">
    <div class="gs-card-title" style="margin-bottom:16px">Change Password</div>
    <div id="mgr-pw-msg" class="gs-imsg"></div>
    <div class="gs-fg"><label class="gs-lbl">Current Password</label><input type="password" id="mgr-pw-cur" class="gs-inp" placeholder="Your current password" autocomplete="current-password"></div>
    <div class="gs-fg"><label class="gs-lbl">New Password</label><input type="password" id="mgr-pw-new" class="gs-inp" placeholder="Min 8 characters" autocomplete="new-password" oninput="mgrPwStr(this.value)">
      <div style="height:4px;background:#E2E8F0;border-radius:2px;margin-top:6px;overflow:hidden"><div id="mgr-pw-bar" style="height:100%;width:0%;border-radius:2px;transition:width .3s,background .3s"></div></div>
    </div>
    <div class="gs-fg"><label class="gs-lbl">Confirm New Password</label><input type="password" id="mgr-pw-cf" class="gs-inp" placeholder="Repeat new password" autocomplete="new-password"></div>
    <button id="mgr-pw-btn" class="gs-btn gs-btn-primary" style="margin-top:6px">🔒 Update Password</button>
  </div>
  <?php // ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "Manager account/
        // security only offers password change — no 2FA, no session
        // management, for a role with full moderation and suspension power
        // over the marketplace"). Session visibility + "sign out
        // everywhere else" via WordPress core's own WP_Session_Tokens —
        // the same mechanism behind wp-admin's own "Log Out Everywhere
        // Else" button — not a new parallel auth system. Full TOTP-based
        // 2FA (the other half of this finding) is a materially larger,
        // separate feature (secret enrollment, QR provisioning, backup
        // codes, a login-flow interrupt) intentionally left for a future
        // pass rather than rushed in alongside this. ?>
  <div class="gs-card">
    <div class="gs-card-title" style="margin-bottom:6px">Active Sessions</div>
    <p style="font-size:.78rem;color:#94A3B8;margin-bottom:12px">Devices and browsers currently signed in as your account. If you see one you don't recognize, sign out of everywhere else immediately and change your password above.</p>
    <div id="mgr-sessions-list" style="font-size:.83rem;color:#475569">Loading…</div>
    <button id="mgr-signout-others-btn" class="gs-btn gs-btn-ghost" style="margin-top:12px;color:#DC2626;border-color:#FCA5A5" onclick="mgrSignoutOthers()">🚪 Sign Out of All Other Sessions</button>
    <div id="mgr-sess-msg" class="gs-imsg"></div>
  </div>
</div>
<script>
(function(){
  var nonce='<?php echo esc_js($nonce); ?>';
  function mgrLoadSessions(){
    gsPost('gs_get_my_sessions',{nonce:nonce},function(resp){
      var list = (resp && resp.sessions) || [];
      var el = document.getElementById('mgr-sessions-list');
      if(!list.length){ el.textContent='No active sessions found.'; return; }
      var html = '';
      list.forEach(function(s){
        html += '<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #F1F5F9">'
          + '<div><div style="font-weight:600">'+(s.is_current?'📍 This device':'🖥 Other device')+(s.is_current?' <span style="color:#059669;font-size:.72rem">(current)</span>':'')+'</div>'
          + '<div style="font-size:.74rem;color:#94A3B8">IP: '+(s.ip||'—')+' · Signed in: '+(s.login_at||'—')+'</div></div></div>';
      });
      el.innerHTML = html;
    },function(){ document.getElementById('mgr-sessions-list').textContent='Could not load sessions.'; });
  }
  window.mgrSignoutOthers=function(){
    if(!confirm('Sign out of every other device/browser currently logged in as your account? This device stays signed in.')) return;
    var btn=document.getElementById('mgr-signout-others-btn');btn.disabled=true;
    gsPost('gs_signout_other_sessions',{nonce:nonce},function(){
      var msg=document.getElementById('mgr-sess-msg');msg.className='gs-imsg ok';msg.textContent='✅ Signed out of all other sessions.';
      btn.disabled=false; mgrLoadSessions();
    },function(e){
      var msg=document.getElementById('mgr-sess-msg');msg.className='gs-imsg err';msg.textContent='❌ '+e;
      btn.disabled=false;
    });
  };
  mgrLoadSessions();
  function mgrPwStr(val){
    var s=0;if(val.length>=8)s++;if(val.length>=12)s++;
    if(/[A-Z]/.test(val))s++;if(/[0-9]/.test(val))s++;if(/[^A-Za-z0-9]/.test(val))s++;
    var cols=['#DC2626','#F59E0B','#F59E0B','#059669','#059669'];
    var b=document.getElementById('mgr-pw-bar');b.style.width=(s/5*100)+'%';b.style.background=cols[s-1]||'#E2E8F0';
  }
  document.getElementById('mgr-pw-btn').addEventListener('click',function(){
    var cur=document.getElementById('mgr-pw-cur').value;
    var nw=document.getElementById('mgr-pw-new').value;
    var cf=document.getElementById('mgr-pw-cf').value;
    var msg=document.getElementById('mgr-pw-msg');msg.className='gs-imsg';msg.textContent='';
    if(!cur||!nw||!cf){msg.className='gs-imsg err';msg.textContent='All fields are required.';return;}
    if(nw.length<8){msg.className='gs-imsg err';msg.textContent='New password must be at least 8 characters.';return;}
    if(nw!==cf){msg.className='gs-imsg err';msg.textContent='New passwords do not match.';return;}
    var btn=this;btn.disabled=true;btn.textContent='Updating\u2026';
    gsPost('gs_change_password',{nonce:nonce,current_password:cur,new_password:nw,confirm_password:cf},
      function(){btn.disabled=false;btn.textContent='\uD83D\uDD12 Update Password';msg.className='gs-imsg ok';msg.textContent='\u2705 Password changed!';
        document.getElementById('mgr-pw-cur').value='';document.getElementById('mgr-pw-new').value='';document.getElementById('mgr-pw-cf').value='';
        document.getElementById('mgr-pw-bar').style.width='0%';setTimeout(function(){msg.className='gs-imsg';},5000);},
      function(e){btn.disabled=false;btn.textContent='\uD83D\uDD12 Update Password';msg.className='gs-imsg err';msg.textContent='\u274C '+e;}
    );
  });
})();
</script>
<?php break;

endswitch; ?>
</div><!-- .gs-mgr-body -->
</div><!-- .gs-mgr -->

<script>
(function(){
  var nonce='<?php echo esc_js($nonce); ?>';
  window.gsMgrApprove=function(id,btn){
    if(!confirm('Approve this listing?')) return;
    btn.disabled=true; btn.textContent='…';
    gsPost('gs_approve_listing',{nonce:nonce,listing_id:id},function(){
      gsToast('Listing approved!','success');
      btn.closest('tr') ? btn.closest('tr').remove() : location.reload();
    },function(e){btn.disabled=false;btn.textContent='✓';gsToast(e,'error');});
  };
  window.gsMgrReject=function(id,btn){
    var reason=prompt('Rejection reason (optional):','');
    if(reason===null) return;
    btn.disabled=true; btn.textContent='…';
    gsPost('gs_reject_listing',{nonce:nonce,listing_id:id,reason:reason},function(){
      gsToast('Listing rejected','info');
      btn.closest('tr') ? btn.closest('tr').remove() : location.reload();
    },function(e){btn.disabled=false;btn.textContent='✕';gsToast(e,'error');});
  };

  // ENTERPRISE-AUDIT FIX (Part 4, Enterprise-level: "No bulk actions
  // anywhere — manager listings/leads/vendors tables... process one row
  // at a time"). Shared, type-parameterized bulk-select helpers reused by
  // both the Listings tab (posts to gs_admin_bulk_listings) and the
  // Vendors tab (posts to gs_admin_bulk_vendors) — both AJAX actions
  // already exist and already accept gs_manager accounts via
  // require_admin() -> Roles::is_admin_level(), so no backend changes
  // were needed, only this UI.
  var BULK_ENDPOINT = { listings: 'gs_admin_bulk_listings', vendors: 'gs_admin_bulk_vendors', leads: 'gs_admin_bulk_leads' };

  function gsMgrBulkChecked(type){
    var boxes = document.querySelectorAll('.gs-mgr-bulk-cb-'+type+':checked');
    var ids = [];
    for (var i=0;i<boxes.length;i++){ ids.push(parseInt(boxes[i].value,10)); }
    return ids;
  }

  window.gsMgrBulkToggleAll=function(type,headerCb){
    var boxes = document.querySelectorAll('.gs-mgr-bulk-cb-'+type);
    for (var i=0;i<boxes.length;i++){ boxes[i].checked = headerCb.checked; }
    gsMgrBulkUpdateCount(type);
  };

  window.gsMgrBulkUpdateCount=function(type){
    var n = gsMgrBulkChecked(type).length;
    var bar = document.getElementById('gs-mgr-bulk-bar-'+type);
    var cnt = document.getElementById('gs-mgr-bulk-count-'+type);
    if (cnt) { cnt.textContent = n + ' selected'; }
    if (bar) { bar.style.display = n > 0 ? 'flex' : 'none'; }
  };

  window.gsMgrBulkClear=function(type){
    var boxes = document.querySelectorAll('.gs-mgr-bulk-cb-'+type);
    for (var i=0;i<boxes.length;i++){ boxes[i].checked = false; }
    var headerCb = document.querySelector('th input[onchange="gsMgrBulkToggleAll(\''+type+'\',this)"]');
    if (headerCb) { headerCb.checked = false; }
    gsMgrBulkUpdateCount(type);
  };

  window.gsMgrBulkApply=function(type){
    var ids = gsMgrBulkChecked(type);
    var sel = document.getElementById('gs-mgr-bulk-action-'+type);
    var action = sel ? sel.value : '';
    if (!ids.length) { gsToast('Select at least one row first.','error'); return; }
    if (!action) { gsToast('Choose an action first.','error'); return; }
    var label = type === 'vendors' ? 'vendor' : (type === 'leads' ? 'lead' : 'listing');
    if (!confirm('Apply "'+action+'" to '+ids.length+' '+label+(ids.length===1?'':'s')+'?')) return;
    var endpoint = BULK_ENDPOINT[type];
    if (!endpoint) { return; }
    gsPost(endpoint,{nonce:nonce,ids:JSON.stringify(ids),bulk_action:action},function(){
      gsToast('Bulk action applied to '+ids.length+' '+label+(ids.length===1?'':'s')+'.','success');
      location.reload();
    },function(e){ gsToast(e,'error'); });
  };
})();
</script>
