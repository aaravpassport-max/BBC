<?php
/**
 * GoodService — "Trust & Safety" page.
 * URL: /trust-safety/
 * Real feature — extends the same design system as how-it-works.php and
 * advertise-with-us.php for platform-wide consistency. Every claim on
 * this page was checked directly against real backend behavior before
 * writing it — the five badge types shown are pulled from vendor-site.php's
 * own $_badge_map, and the dispute SLA is read from DisputeService's own
 * constant, not restated from memory.
 *
 * Deliberately does NOT include its own <!DOCTYPE>/<html>/<head> —
 * render_page() already provides that wrapper, matching the same
 * documented precedent as how-it-works.php and advertise-with-us.php.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

global $wpdb;
$pfx = $wpdb->prefix . 'gs_';

// ── Real, live platform stats — no fabricated numbers ──────────────────────
$verified_count = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT vendor_id) FROM {$pfx}verification_docs WHERE status = 'approved'" );
$total_reviews   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}reviews WHERE status = 'approved'" );
$verified_reviews = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}reviews WHERE status = 'approved' AND verified = 1" );

$platform     = function_exists('gs_setting') ? gs_setting('platform_name', get_bloginfo('name')) : get_bloginfo('name');
$logo_url     = function_exists('gs_setting') ? gs_setting('logo_url', '') : '';
$search_url   = home_url('/');
$register_url = home_url('/advertise/');
$howitworks_url = home_url('/how-it-works/');
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Inter:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@500;600&display=swap');
*,*::before,*::after{box-sizing:border-box}
.ts-body{font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#14162B;background:#FBFAF7}
.ts-mono{font-family:'IBM Plex Mono',monospace}
.ts-wrap{max-width:1180px;margin:0 auto;padding:0 24px}
.ts-header{background:#FBFAF7;border-bottom:1px solid rgba(20,22,43,.08);position:sticky;top:0;z-index:50}
.ts-header-inner{display:flex;align-items:center;justify-content:space-between;padding:14px 0}
.ts-logo{display:flex;align-items:center;gap:10px;text-decoration:none;color:#14162B;font-weight:800;font-size:1.1rem;font-family:'Fraunces',serif}
.ts-logo img{height:32px;border-radius:6px}
.ts-header-links{display:flex;align-items:center;gap:28px}
.ts-header-links a{color:#14162B;text-decoration:none;font-size:.87rem;font-weight:600}
.ts-header-links a:not(.ts-header-cta):hover{color:#FF6B35}
.ts-header-cta{background:#14162B;color:#FBFAF7!important;padding:9px 20px;border-radius:8px;font-weight:700!important;transition:background .18s}
.ts-header-cta:hover{background:#FF6B35}
@media(max-width:820px){.ts-header-links a:not(.ts-header-cta){display:none}}

.ts-hero{padding:64px 0 56px;text-align:center}
.ts-eyebrow{display:inline-flex;align-items:center;gap:8px;font-family:'IBM Plex Mono',monospace;font-weight:600;font-size:.72rem;text-transform:uppercase;letter-spacing:.14em;margin-bottom:22px;padding:6px 14px 6px 10px;border:1px solid rgba(20,22,43,.14);border-radius:99px}
.ts-eyebrow-dot{width:6px;height:6px;border-radius:50%;background:#FF6B35}
.ts-hero h1{font-family:'Fraunces',serif;font-weight:600;font-size:3rem;line-height:1.08;letter-spacing:-.015em;margin-bottom:20px;color:#14162B;max-width:720px;margin-left:auto;margin-right:auto}
.ts-hero h1 em{font-style:normal;color:#FF6B35}
.ts-hero p{font-size:1.08rem;line-height:1.6;color:rgba(20,22,43,.65);max-width:560px;margin:0 auto}

/* Signature element — the platform's actual five verification badge
   types, shown as real badges rather than generic trust icons, since
   these specific badges are the concrete mechanism behind the claim. */
.ts-badges{padding:20px 0 88px}
.ts-badge-row{display:flex;justify-content:center;gap:14px;flex-wrap:wrap;max-width:900px;margin:0 auto}
.ts-badge-pill{display:inline-flex;align-items:center;gap:9px;background:#fff;border:1.5px solid rgba(20,22,43,.1);border-radius:99px;padding:11px 20px 11px 14px;font-weight:700;font-size:.9rem;box-shadow:0 4px 14px -6px rgba(20,22,43,.1)}
.ts-badge-pill .ts-badge-ico{width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.95rem;flex-shrink:0}

.ts-section{padding:88px 0;background:#fff;border-top:1px solid rgba(20,22,43,.08)}
.ts-section-head{max-width:640px;margin:0 auto 56px;text-align:center}
.ts-section-head h2{font-family:'Fraunces',serif;font-size:2.15rem;font-weight:600;color:#14162B;letter-spacing:-.01em}
.ts-section-head p{color:rgba(20,22,43,.6);margin-top:14px;font-size:1rem}

.ts-pillars{display:grid;grid-template-columns:repeat(3,1fr);gap:28px}
@media(max-width:900px){.ts-pillars{grid-template-columns:1fr}}
.ts-pillar{border:1px solid rgba(20,22,43,.08);border-radius:16px;padding:32px}
.ts-pillar-num{font-family:'IBM Plex Mono',monospace;font-size:.75rem;color:#FF6B35;font-weight:700;letter-spacing:.08em;margin-bottom:16px}
.ts-pillar h3{font-size:1.15rem;font-weight:700;margin-bottom:10px;color:#14162B}
.ts-pillar p{font-size:.9rem;line-height:1.65;color:rgba(20,22,43,.62)}

/* Dispute timeline — genuinely sequential (open → review → resolve),
   so a step device is honest here specifically. */
.ts-dispute{background:#FBFAF7}
.ts-dispute-flow{display:flex;align-items:center;justify-content:center;gap:0;max-width:820px;margin:0 auto;flex-wrap:wrap}
.ts-dispute-step{background:#fff;border:1px solid rgba(20,22,43,.1);border-radius:14px;padding:22px 26px;text-align:center;flex:1;min-width:180px}
.ts-dispute-step b{display:block;font-family:'Fraunces',serif;font-size:1.05rem;margin-bottom:6px;color:#14162B}
.ts-dispute-step span{font-size:.8rem;color:rgba(20,22,43,.55);line-height:1.5}
.ts-dispute-arrow{font-size:1.3rem;color:rgba(20,22,43,.25);padding:0 14px}
@media(max-width:760px){.ts-dispute-flow{flex-direction:column}.ts-dispute-arrow{transform:rotate(90deg);padding:6px 0}}
.ts-dispute-sla{text-align:center;margin-top:28px;font-family:'IBM Plex Mono',monospace;font-size:.82rem;color:rgba(20,22,43,.55)}
.ts-dispute-sla b{color:#14162B}

.ts-stats-strip{padding:56px 0;text-align:center;background:#14162B;color:#FBFAF7}
.ts-stats-grid{display:flex;justify-content:center;gap:56px;flex-wrap:wrap}
.ts-stat b{display:block;font-family:'Fraunces',serif;font-size:2.1rem;font-weight:600}
.ts-stat span{font-size:.76rem;font-family:'IBM Plex Mono',monospace;text-transform:uppercase;letter-spacing:.08em;color:rgba(251,250,247,.6)}

.ts-cta{padding:90px 0;text-align:center}
.ts-cta h2{font-family:'Fraunces',serif;font-size:2.1rem;font-weight:600;margin-bottom:16px;color:#14162B}
.ts-cta p{color:rgba(20,22,43,.62);margin-bottom:32px;font-size:1.02rem}
.ts-cta-ctas{display:flex;gap:14px;justify-content:center;flex-wrap:wrap}
.ts-btn-primary{background:#14162B;color:#FBFAF7;padding:14px 26px;border-radius:9px;text-decoration:none;font-weight:700;font-size:.95rem;transition:background .18s,transform .18s;display:inline-block}
.ts-btn-primary:hover{background:#FF6B35;transform:translateY(-1px)}
.ts-btn-ghost{border:1.5px solid rgba(20,22,43,.18);color:#14162B;padding:13px 24px;border-radius:9px;text-decoration:none;font-weight:700;font-size:.95rem;transition:border-color .18s}
.ts-btn-ghost:hover{border-color:#14162B}

a.ts-header-cta:focus-visible,a.ts-btn-primary:focus-visible,a.ts-btn-ghost:focus-visible{outline:2px solid #FF6B35;outline-offset:2px}
</style>

<div class="ts-body">
  <header class="ts-header">
    <div class="ts-wrap ts-header-inner">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="ts-logo">
        <?php if ($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($platform); ?>"><?php else: echo esc_html($platform); endif; ?>
      </a>
      <nav class="ts-header-links">
        <a href="<?php echo esc_url($howitworks_url); ?>">How It Works</a>
        <a href="#disputes">Disputes</a>
        <a href="<?php echo esc_url($register_url); ?>">Become a Pro</a>
        <a href="<?php echo esc_url($search_url); ?>" class="ts-header-cta">Find a Pro →</a>
      </nav>
    </div>
  </header>

  <section class="ts-hero">
    <div class="ts-wrap">
      <div class="ts-eyebrow"><span class="ts-eyebrow-dot"></span>Trust &amp; Safety</div>
      <h1>What we actually show you <em>before</em> you reach out — and what we don't claim to guarantee.</h1>
      <p>We're a platform that connects you with independent businesses — we're not their employer, and we don't supervise every job. Here's exactly what documents we collect, what reviews mean, and what happens if something goes wrong.</p>
    </div>
  </section>

  <section class="ts-badges">
    <div class="ts-wrap">
      <div class="ts-badge-row">
        <div class="ts-badge-pill"><span class="ts-badge-ico" style="background:#F0FDF4;color:#059669">🪪</span>ID Document on File</div>
        <div class="ts-badge-pill"><span class="ts-badge-ico" style="background:#EFF6FF;color:#2563EB">📋</span>GST Registration on File</div>
        <div class="ts-badge-pill"><span class="ts-badge-ico" style="background:#F5F3FF;color:#7C3AED">📜</span>Trade Licence on File</div>
        <div class="ts-badge-pill"><span class="ts-badge-ico" style="background:#FEF3C7;color:#B45309">🛡️</span>Police Verification Document Submitted</div>
        <div class="ts-badge-pill"><span class="ts-badge-ico" style="background:#ECFDF5;color:#059669">✅</span><?php echo esc_html( strtoupper( substr( $platform, 0, 2 ) ) ); ?> Reviewed Submission</div>
      </div>
    </div>
  </section>

  <section class="ts-section">
    <div class="ts-wrap">
      <div class="ts-section-head">
        <h2>What we actually do, in three parts</h2>
        <p>We're not the pro's employer, and we can't guarantee how any individual job goes — here's what we genuinely do to help you make an informed choice.</p>
      </div>
      <div class="ts-pillars">
        <div class="ts-pillar">
          <div class="ts-pillar-num">BEFORE YOU BOOK</div>
          <h3>Documents on file, not guaranteed</h3>
          <p>Pros can submit ID, GST, trade licence, and police-verification documents, which we check were genuinely uploaded before showing the badge. We don't independently confirm these with the issuing authority — treat them as a useful signal, not a guarantee.</p>
        </div>
        <div class="ts-pillar">
          <div class="ts-pillar-num">AFTER THE JOB</div>
          <h3>Reviews with a verified-booking badge</h3>
          <p>Any customer can leave a review, but reviews matched to a real completed booking on that listing carry a distinct <b>Verified Booking</b> badge — so you can weigh them accordingly.</p>
        </div>
        <div class="ts-pillar">
          <div class="ts-pillar-num">IF SOMETHING'S WRONG</div>
          <h3>A way to report it, not a guarantee we'll resolve it</h3>
          <p>You can flag an issue with a booking, and we do look at repeated or serious complaints when deciding whether a listing stays on the platform. We're not able to mediate or guarantee the outcome of every individual dispute between you and a pro.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="ts-section ts-dispute" id="disputes">
    <div class="ts-wrap">
      <div class="ts-section-head">
        <h2>If a job doesn't go well</h2>
      </div>
      <div class="ts-dispute-flow">
        <div class="ts-dispute-step"><b>1. You report it</b><span>Tell us what happened, tied to your actual booking</span></div>
        <div class="ts-dispute-arrow">→</div>
        <div class="ts-dispute-step"><b>2. We log it against that listing</b><span>Repeated or serious reports factor into whether a listing stays on the platform</span></div>
        <div class="ts-dispute-arrow">→</div>
        <div class="ts-dispute-step"><b>3. You deal with the pro directly</b><span>We're a connector, not the employer — the job itself is between you and them</span></div>
      </div>
      <div class="ts-dispute-sla">We're a listing platform, not a project manager for every booking — we can't guarantee or arbitrate the outcome of an individual job, but a pattern of genuine complaints does affect a listing's standing.</div>
    </div>
  </section>

  <?php if ( $verified_count > 0 || $total_reviews > 0 ): ?>
  <section class="ts-stats-strip">
    <div class="ts-wrap ts-stats-grid">
      <?php if ( $verified_count > 0 ): ?><div class="ts-stat"><b><?php echo esc_html( number_format($verified_count) ); ?>+</b><span>Pros With Documents on File</span></div><?php endif; ?>
      <?php if ( $total_reviews > 0 ): ?><div class="ts-stat"><b><?php echo esc_html( number_format($total_reviews) ); ?>+</b><span>Real Reviews</span></div><?php endif; ?>
      <?php if ( $verified_reviews > 0 ): ?><div class="ts-stat"><b><?php echo esc_html( number_format($verified_reviews) ); ?>+</b><span>Verified Bookings</span></div><?php endif; ?>
    </div>
  </section>
  <?php endif; ?>

  <section class="ts-cta">
    <div class="ts-wrap">
      <h2>See it for yourself</h2>
      <p>Every badge reflects a document a pro actually submitted, and every review is tied to a real account — browse a few listings and see for yourself.</p>
      <div class="ts-cta-ctas">
        <a href="<?php echo esc_url($search_url); ?>" class="ts-btn-primary">Browse Pros Near You →</a>
        <a href="<?php echo esc_url($howitworks_url); ?>" class="ts-btn-ghost">See How Booking Works</a>
      </div>
    </div>
  </section>

  <?php
  $df_site = $platform; $df_home = home_url('/');
  // Real bug fix (v7.475.7) — see matching comment in about-us.php.
  $_ftr_primary = function_exists('gs_setting') ? gs_setting('platform_color_primary', '#2563EB') : '#2563EB';
  ?>
  <footer style="background:#14162B;color:rgba(251,250,247,.6);padding:32px 0;text-align:center;font-size:.78rem;font-family:'IBM Plex Mono',monospace">
    <div class="ts-wrap">© <?php echo esc_html( gmdate('Y') ); ?> <?php echo esc_html($df_site); ?>. All rights reserved. &nbsp;·&nbsp;
      <a href="<?php echo esc_url($df_home); ?>" style="color:rgba(251,250,247,.75);transition:color .15s" onmouseover="this.style.color='<?php echo esc_js($_ftr_primary); ?>'" onmouseout="this.style.color='rgba(251,250,247,.75)'">Home</a> &nbsp;·&nbsp;
      <a href="<?php echo esc_url($howitworks_url); ?>" style="color:rgba(251,250,247,.75);transition:color .15s" onmouseover="this.style.color='<?php echo esc_js($_ftr_primary); ?>'" onmouseout="this.style.color='rgba(251,250,247,.75)'">How It Works</a>
    </div>
  </footer>
</div>
