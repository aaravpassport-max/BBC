<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( is_user_logged_in() ) {
    $dest = \GoodService\Core\Roles::is_manager() ? home_url('/manager-panel/') : home_url('/admin-panel/');
    wp_redirect( $dest ); exit;
}
$platform = gs_setting('platform_name', 'GoodService');
$color    = '#1E3A5F'; // Manager portal uses the navy brand colour
$logo_url = gs_setting('logo_url', '');
$ajax_url = admin_url('admin-ajax.php');
$nonce    = wp_create_nonce('gs_ajax');
$forgot   = home_url('/forgot-password/');
?>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:linear-gradient(135deg,#1E3A5F 0%,#2563EB 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.gsmgr-wrap{width:100%;max-width:420px}
.gsmgr-badge{text-align:center;margin-bottom:24px}
.gsmgr-badge-pill{display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:99px;padding:8px 20px;color:#fff;font-size:.82rem;font-weight:600;letter-spacing:.04em;text-transform:uppercase}
.gsmgr-badge-dot{width:8px;height:8px;border-radius:50%;background:#34D399;flex-shrink:0;animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
.gsmgr-logo{text-align:center;margin-bottom:28px}
.gsmgr-logo h1{font-size:1.5rem;font-weight:800;color:#fff;margin-bottom:4px}
.gsmgr-logo p{color:rgba(255,255,255,.65);font-size:.85rem}
.gsmgr-card{background:#fff;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,.25);padding:36px 32px}
.gsmgr-title{font-size:1.1rem;font-weight:700;color:#1E3A5F;margin-bottom:6px}
.gsmgr-sub{font-size:.83rem;color:#64748B;margin-bottom:24px}
.gsmgr-err,.gsmgr-ok{display:none;padding:12px 14px;border-radius:8px;font-size:.84rem;margin-bottom:16px;border-left:4px solid}
.gsmgr-err{background:#FEF2F2;color:#DC2626;border-color:#DC2626}
.gsmgr-ok{background:#F0FDF4;color:#059669;border-color:#059669}
.gsmgr-label{display:block;font-size:.78rem;font-weight:600;color:#475569;margin-bottom:6px;text-transform:uppercase;letter-spacing:.04em}
.gsmgr-field{position:relative;margin-bottom:16px}
.gsmgr-input{display:block;width:100%;padding:12px 14px;border:1.5px solid #E2E8F0;border-radius:9px;font-size:.92rem;color:#1E293B;background:#fff;outline:none;transition:border-color .18s,box-shadow .18s;font-family:inherit}
.gsmgr-input:focus{border-color:#1E3A5F;box-shadow:0 0 0 3px rgba(30,58,95,.12)}
.gsmgr-toggle{position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:1rem;color:#94A3B8;padding:2px}
.gsmgr-btn{display:block;width:100%;padding:13px;border:none;border-radius:10px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;transition:all .18s;text-align:center;background:#1E3A5F;color:#fff;margin-top:8px}
.gsmgr-btn:hover{background:#152337}
.gsmgr-btn:disabled{opacity:.6;cursor:not-allowed}
.gsmgr-links{display:flex;justify-content:space-between;align-items:center;margin-top:18px;font-size:.8rem}
.gsmgr-links a{color:#64748B;text-decoration:none}
.gsmgr-links a:hover{color:#1E3A5F}
.gsmgr-divider{height:1px;background:#F1F5F9;margin:20px 0}
.gsmgr-back{text-align:center;margin-top:20px;font-size:.82rem}
.gsmgr-back a{color:rgba(255,255,255,.7);text-decoration:none}
.gsmgr-back a:hover{color:#fff}
</style>

<div class="gsmgr-wrap">
  <div class="gsmgr-badge">
    <div class="gsmgr-badge-pill"><span class="gsmgr-badge-dot"></span>Manager Portal</div>
  </div>

  <div class="gsmgr-logo">
    <?php if($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($platform); ?>" style="height:44px;margin:0 auto 12px;display:block;border-radius:8px"><?php endif; ?>
    <h1><?php echo esc_html($platform); ?></h1>
    <p>Manager &amp; Admin Access</p>
  </div>

  <div class="gsmgr-card">
    <div class="gsmgr-title">Welcome back</div>
    <div class="gsmgr-sub">Sign in with your manager credentials to continue.</div>

    <div id="mgr-err" class="gsmgr-err"></div>
    <div id="mgr-ok"  class="gsmgr-ok"></div>

    <div class="gsmgr-field">
      <label class="gsmgr-label">Email or Username</label>
      <input type="text" id="mgr-id" class="gsmgr-input"
        placeholder="manager@example.com"
        autocomplete="username" autocapitalize="none" spellcheck="false">
    </div>

    <div class="gsmgr-field">
      <label class="gsmgr-label">Password</label>
      <input type="password" id="mgr-pass" class="gsmgr-input"
        placeholder="Enter your password"
        autocomplete="current-password" style="padding-right:44px">
      <button class="gsmgr-toggle" onclick="mgrTogglePw()" type="button" tabindex="-1">👁</button>
    </div>

    <button class="gsmgr-btn" id="mgr-btn" onclick="mgrLogin()">Sign In to Manager Panel</button>

    <div class="gsmgr-links">
      <a href="<?php echo esc_url($forgot); ?>">Forgot password?</a>
      <a href="<?php echo esc_url(home_url('/vendor/login/')); ?>">Vendor login →</a>
    </div>
  </div>

  <div class="gsmgr-back"><a href="<?php echo esc_url(home_url('/')); ?>">← Back to <?php echo esc_html($platform); ?></a></div>
</div>

<script>
var GS_AJAX  = '<?php echo esc_js($ajax_url); ?>';
var GS_NONCE = '<?php echo esc_js($nonce); ?>';

function mgrTogglePw() {
  var el = document.getElementById('mgr-pass');
  el.type = el.type === 'password' ? 'text' : 'password';
}
function mgrShowErr(msg) {
  var el = document.getElementById('mgr-err');
  el.textContent = msg; el.style.display = 'block';
  document.getElementById('mgr-ok').style.display = 'none';
}
function mgrShowOk(msg) {
  var el = document.getElementById('mgr-ok');
  el.textContent = msg; el.style.display = 'block';
  document.getElementById('mgr-err').style.display = 'none';
}

function mgrLogin() {
  document.getElementById('mgr-err').style.display = 'none';
  var id   = document.getElementById('mgr-id').value.trim();
  var pass = document.getElementById('mgr-pass').value;
  if (!id || !pass) { mgrShowErr('Please enter your email / username and password.'); return; }

  var btn = document.getElementById('mgr-btn');
  btn.disabled = true; btn.textContent = 'Signing in…';

  var fd = new FormData();
  fd.append('action',   'gs_vendor_login');
  fd.append('nonce',    GS_NONCE);
  fd.append('email',    id);
  fd.append('password', pass);

  fetch(GS_AJAX, { method:'POST', body:fd, credentials:'same-origin' })
    .then(function(r){ return r.json(); })
    .then(function(r){
      btn.disabled = false; btn.textContent = 'Sign In to Manager Panel';
      if (r.success) {
        mgrShowOk('✓ Login successful. Redirecting to manager panel…');
        var dest = (r.data && r.data.redirect) ? r.data.redirect : '<?php echo esc_js(home_url('/manager-panel/')); ?>';
        setTimeout(function(){ window.location.href = dest; }, 800);
      } else {
        mgrShowErr((r.data && r.data.message) ? r.data.message : 'Login failed. Please check your credentials.');
      }
    })
    .catch(function(){
      btn.disabled = false; btn.textContent = 'Sign In to Manager Panel';
      mgrShowErr('Connection error. Please try again.');
    });
}

document.getElementById('mgr-pass').addEventListener('keydown', function(e){ if(e.key==='Enter') mgrLogin(); });
document.getElementById('mgr-id').addEventListener('keydown',   function(e){ if(e.key==='Enter') document.getElementById('mgr-pass').focus(); });
</script>
