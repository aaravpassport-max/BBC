<?php
/**
 * GoodService — Client Job Tracking Page (Part 15.3)
 * URL: /track-job/{token}/
 * Fully implements: animated stepper, vendor contact, completion screen, review CTA
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

global $wpdb;
$pfx   = $wpdb->prefix . 'gs_';
$token = sanitize_text_field( get_query_var( 'gs_track_token', '' ) );

$booking = null;
$vendor  = null;
$listing = null;

if ( $token ) {
    $booking = $wpdb->get_row( $wpdb->prepare(
        "SELECT b.*, li.title AS service_title, li.phone AS listing_phone, li.whatsapp AS listing_wa,
                vp.business_name, vp.avg_reply_minutes, vp.phone AS vp_phone, vp.whatsapp AS vp_wa,
                u.display_name AS vendor_display_name
         FROM {$pfx}bookings b
         LEFT JOIN {$pfx}listings li ON li.id = b.listing_id
         LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = b.vendor_id
         LEFT JOIN {$wpdb->prefix}users u ON u.ID = (SELECT user_id FROM {$pfx}vendor_profiles WHERE id = b.vendor_id LIMIT 1)
         WHERE b.tracking_token = %s
         LIMIT 1",
        $token
    ) );
}

$job_status = $booking ? ( $booking->job_status ?? $booking->status ?? 'confirmed' ) : null;
$vendor_name = $booking ? ( $booking->business_name ?: $booking->vendor_display_name ?: 'Your professional' ) : '';
$service     = $booking ? ( $booking->service_title ?: 'Service' ) : '';
$vendor_phone = $booking ? ( $booking->listing_phone ?: $booking->vp_phone ?? '' ) : '';
$vendor_wa    = $booking ? preg_replace('/[^0-9]/', '', $booking->listing_wa ?: $booking->vp_wa ?? '') : '';
$eta          = $booking ? ( $booking->vendor_eta_minutes ?? 0 ) : 0;

$steps = [
    'confirmed'   => 0,
    'travelling'  => 1,
    'arrived'     => 2,
    'in_progress' => 3,
    'done'        => 4,
];
$current_step = $steps[ $job_status ?? 'confirmed' ] ?? 0;
$is_done = $job_status === 'done';

$site = get_bloginfo('name');

get_header(); ?>
<style>
.jt-wrap{max-width:480px;margin:0 auto;padding:24px 16px 60px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
.jt-card{background:#fff;border-radius:16px;border:1px solid #E2E8F0;overflow:hidden;margin-bottom:16px}
.jt-head{padding:20px 20px 16px;background:linear-gradient(135deg,#1E3A5F,#2563EB);color:#fff}
.jt-head-title{font-size:1.05rem;font-weight:800;margin-bottom:4px}
.jt-head-sub{font-size:.82rem;opacity:.8}
.jt-status-wrap{padding:24px 20px 16px}
.jt-stepper{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;position:relative}
.jt-step{display:flex;flex-direction:column;align-items:center;gap:6px;flex:1}
.jt-step-circle{width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;position:relative;z-index:2;transition:all .3s}
.jt-step-circle.done{background:#059669;color:#fff}
.jt-step-circle.active{background:#2563EB;color:#fff;box-shadow:0 0 0 4px rgba(37,99,235,.2);animation:jt-pulse 2s infinite}
.jt-step-circle.waiting{background:#E2E8F0;color:#94A3B8}
.jt-step-label{font-size:.65rem;color:#64748B;text-align:center;font-weight:500;line-height:1.3}
.jt-step-label.active{color:#2563EB;font-weight:700}
.jt-step-label.done{color:#059669}
.jt-connector{height:2px;flex:1;margin-top:-20px;position:relative;z-index:1;transition:background .4s}
.jt-connector.done{background:#059669}
.jt-connector.waiting{background:#E2E8F0}
@keyframes jt-pulse{0%,100%{box-shadow:0 0 0 4px rgba(37,99,235,.2)}50%{box-shadow:0 0 0 8px rgba(37,99,235,.1)}}
.jt-status-msg{text-align:center;padding:16px;background:#F0F9FF;border-radius:10px;margin-bottom:16px}
.jt-status-icon{font-size:2.4rem;display:block;margin-bottom:8px}
.jt-status-title{font-weight:800;font-size:1.05rem;color:#1E3A5F}
.jt-status-sub{font-size:.82rem;color:#64748B;margin-top:4px}
.jt-eta{background:#FFFBEB;border:1px solid #FDE68A;border-radius:9px;padding:10px 14px;font-size:.82rem;color:#92400E;display:flex;align-items:center;gap:8px;margin-bottom:14px}
.jt-contact-strip{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:14px 20px;border-top:1px solid #F1F5F9}
.jt-cta{display:flex;align-items:center;justify-content:center;gap:8px;padding:12px;border-radius:10px;font-weight:700;font-size:.88rem;text-decoration:none;border:none;cursor:pointer;font-family:inherit;transition:all .15s}
.jt-call{background:#2563EB;color:#fff}
.jt-call:hover{background:#1D4ED8}
.jt-wa{background:#25D366;color:#fff}
.jt-wa:hover{background:#1EA952}
.jt-done-card{padding:28px 20px;text-align:center}
.jt-done-icon{font-size:3rem;margin-bottom:12px;display:block}
.jt-done-title{font-weight:800;font-size:1.2rem;color:#059669;margin-bottom:6px}
.jt-done-sub{font-size:.84rem;color:#64748B;margin-bottom:20px}
.jt-review-btn{background:linear-gradient(135deg,#D97706,#F59E0B);color:#fff;padding:13px 28px;border-radius:10px;font-weight:800;font-size:.92rem;text-decoration:none;display:inline-block}
.jt-invalid{text-align:center;padding:48px 20px}
.jt-map-placeholder{background:linear-gradient(135deg,#EFF6FF,#DBEAFE);border-radius:10px;padding:32px 20px;text-align:center;margin-bottom:14px}
</style>

<div class="jt-wrap">

<?php if ( ! $booking ): ?>
<div class="jt-card">
  <div class="jt-invalid">
    <div style="font-size:3rem;margin-bottom:12px">🔗</div>
    <div style="font-weight:700;font-size:1.1rem;color:#1E293B;margin-bottom:8px">Invalid tracking link</div>
    <p style="font-size:.85rem;color:#64748B">This tracking link is invalid or has expired.</p>
    <a href="<?php echo esc_url(home_url('/')); ?>" style="display:inline-block;margin-top:16px;background:#2563EB;color:#fff;padding:10px 24px;border-radius:9px;text-decoration:none;font-weight:700">Go Home</a>
  </div>
</div>

<?php elseif ( $is_done ): ?>
<!-- ── COMPLETION SCREEN ─────────────────────────────────────── -->
<div class="jt-card">
  <div class="jt-head">
    <div class="jt-head-title"><?php echo esc_html($service); ?></div>
    <div class="jt-head-sub"><?php echo esc_html($vendor_name); ?> · <?php echo $booking->booking_date ? date('d M Y', strtotime($booking->booking_date)) : ''; ?></div>
  </div>
  <div class="jt-done-card">
    <span class="jt-done-icon">🎉</span>
    <div class="jt-done-title">Job completed!</div>
    <div class="jt-done-sub">
      <?php echo esc_html($vendor_name); ?> completed your job
      <?php if ( $booking->completed_at ): ?>
      at <?php echo date('h:i A', strtotime($booking->completed_at)); ?>
      <?php endif; ?>.
      How was the experience?
    </div>
    <?php
    $review_url = home_url('/my-account/?section=inquiries&review_booking=' . (int)$booking->id);
    ?>
    <a href="<?php echo esc_url($review_url); ?>" class="jt-review-btn">⭐ Leave a Review</a>
    <div style="margin-top:14px;font-size:.76rem;color:#94A3B8">Your review helps others find great professionals</div>
  </div>
</div>

<?php else: ?>
<!-- ── LIVE TRACKING SCREEN ──────────────────────────────────── -->
<div class="jt-card">
  <div class="jt-head">
    <div class="jt-head-title"><?php echo esc_html($service); ?></div>
    <div class="jt-head-sub">
      <?php echo esc_html($vendor_name); ?>
      <?php if ($booking->booking_date): ?>
       · <?php echo date('d M, h:i A', strtotime($booking->booking_date)); ?>
      <?php endif; ?>
    </div>
  </div>

  <div class="jt-status-wrap">
    <!-- Animated stepper -->
    <div class="jt-stepper">
      <?php
      $step_data = [
        ['✓', 'Confirmed'],
        ['🚗', 'On the way'],
        ['📍', 'Arrived'],
        ['🔧', 'In progress'],
        ['✅', 'Done'],
      ];
      foreach ($step_data as $i => [$icon, $label]):
        $cls = $i < $current_step ? 'done' : ($i == $current_step ? 'active' : 'waiting');
      ?>
      <?php if ($i > 0): ?><div class="jt-connector <?php echo $i <= $current_step ? 'done' : 'waiting'; ?>"></div><?php endif; ?>
      <div class="jt-step">
        <div class="jt-step-circle <?php echo $cls; ?>"><?php echo $i < $current_step ? '✓' : $icon; ?></div>
        <div class="jt-step-label <?php echo $cls; ?>"><?php echo $label; ?></div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Status message -->
    <?php
    $msgs = [
      'confirmed'   => ['🗓️', 'Booking confirmed', 'Your professional will arrive at the scheduled time.'],
      'travelling'  => ['🚗', $vendor_name . ' is on the way!', $eta > 0 ? "Estimated arrival: ~{$eta} minutes." : 'They are heading to your location.'],
      'arrived'     => ['📍', $vendor_name . ' has arrived!', 'They are at your location. Please welcome them in.'],
      'in_progress' => ['🔧', 'Work in progress', $vendor_name . ' has started working on your job.'],
    ];
    $msg = $msgs[$job_status] ?? $msgs['confirmed'];
    ?>
    <div class="jt-status-msg">
      <span class="jt-status-icon"><?php echo $msg[0]; ?></span>
      <div class="jt-status-title"><?php echo esc_html($msg[1]); ?></div>
      <div class="jt-status-sub"><?php echo esc_html($msg[2]); ?></div>
    </div>

    <?php if ($job_status === 'travelling' && $eta > 0): ?>
    <div class="jt-eta">
      <span>⏰</span>
      <span>ETA: ~<?php echo (int)$eta; ?> minutes from when they set out</span>
    </div>
    <?php endif; ?>

    <?php if ($job_status === 'travelling'): ?>
    <div class="jt-map-placeholder">
      <div style="font-size:1.8rem;margin-bottom:8px">🗺️</div>
      <div style="font-size:.84rem;color:#1E40AF;font-weight:600"><?php echo esc_html($vendor_name); ?> is heading to your location</div>
      <div style="font-size:.74rem;color:#3B82F6;margin-top:4px">Live tracking available in the app</div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Contact buttons -->
  <?php if ($vendor_phone || $vendor_wa): ?>
  <div class="jt-contact-strip">
    <?php if ($vendor_phone): ?>
    <a href="tel:<?php echo esc_attr($vendor_phone); ?>" class="jt-cta jt-call" aria-label="Call <?php echo esc_attr($vendor_name); ?>">
      📞 Call <?php echo esc_html(explode(' ', $vendor_name)[0]); ?>
    </a>
    <?php endif; ?>
    <?php if ($vendor_wa): ?>
    <a href="https://wa.me/<?php echo esc_attr($vendor_wa); ?>?text=Hi+<?php echo urlencode($vendor_name); ?>%2C+I%27m+tracking+my+job.+Quick+question!"
       target="_blank" rel="noopener" class="jt-cta jt-wa" aria-label="WhatsApp <?php echo esc_attr($vendor_name); ?>">
      💬 WhatsApp
    </a>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <?php
  // Reschedule button — Phase 4
  // Only visible when: booking is pending/confirmed, job hasn't started yet,
  // and fewer than the configured max reschedules have been used.
  $can_reschedule = $booking
    && in_array( $booking->status ?? '', ['pending','confirmed'], true )
    && in_array( $booking->job_status ?? 'confirmed', ['confirmed'], true )
    && ( (int)($booking->reschedule_count??0) < (int)\GoodService\Core\Config::get('booking_reschedule_max',2) );
  // FIXED — audit gap "customer dashboard: no booking cancel/reschedule".
  // Reschedule already existed on this page; cancellation had no
  // customer-facing path anywhere. Same visibility rule as reschedule
  // (booking still pending/confirmed, job not yet started) — once the
  // pro is en route or working, the customer is directed to contact them
  // directly instead (enforced server-side too, in cancelBookingCustomer()).
  $can_cancel = $booking
    && in_array( $booking->status ?? '', ['pending','confirmed'], true )
    && in_array( $booking->job_status ?? 'confirmed', ['confirmed'], true );
  if ( $can_reschedule || $can_cancel ):
    $reschedules_used = (int)($booking->reschedule_count??0);
    $reschedules_max  = (int)\GoodService\Core\Config::get('booking_reschedule_max',2);
    $reschedules_left = $reschedules_max - $reschedules_used;
  ?>
  <div style="text-align:center;margin-top:12px;padding:0 16px;display:flex;gap:8px">
    <?php if ( $can_reschedule ): ?>
    <button onclick="jtRescheduleOpen()" style="flex:1;background:#F8FAFC;border:1.5px solid #E2E8F0;border-radius:10px;padding:10px 12px;font-size:.82rem;font-weight:600;color:#475569;cursor:pointer">
      🔄 Reschedule <span style="font-size:.72rem;color:#94A3B8">(<?php echo $reschedules_left; ?> left)</span>
    </button>
    <?php endif; ?>
    <?php if ( $can_cancel ): ?>
    <button onclick="jtCancelOpen()" style="flex:1;background:#FEF2F2;border:1.5px solid #FECACA;border-radius:10px;padding:10px 12px;font-size:.82rem;font-weight:600;color:#DC2626;cursor:pointer">
      ✕ Cancel Booking
    </button>
    <?php endif; ?>
  </div>
  <?php if ( $can_cancel ): ?>
  <div id="jt-cancel-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center;padding:16px">
    <div style="background:#fff;border-radius:16px;padding:24px;max-width:360px;width:100%">
      <div style="font-weight:800;font-size:1rem;margin-bottom:14px;color:#DC2626">✕ Cancel Booking</div>
      <div style="font-size:.83rem;color:#64748B;margin-bottom:16px">
        Are you sure you want to cancel this booking with <strong><?php echo esc_html($vendor_name); ?></strong>
        on <?php echo $booking->booking_date ? esc_html(date('D, d M', strtotime($booking->booking_date))) : ''; ?>? This cannot be undone.
      </div>
      <div id="jt-cancel-msg" style="font-size:.8rem;margin-bottom:10px;min-height:18px"></div>
      <div style="display:flex;gap:8px">
        <button onclick="document.getElementById('jt-cancel-modal').style.display='none'" style="flex:1;background:#F1F5F9;border:none;border-radius:8px;padding:10px;font-size:.85rem;cursor:pointer">Keep Booking</button>
        <button onclick="jtCancelSubmit()" id="jt-cancel-btn" style="flex:2;background:#DC2626;color:#fff;border:none;border-radius:8px;padding:10px;font-size:.85rem;font-weight:700;cursor:pointer">Yes, Cancel It</button>
      </div>
    </div>
  </div>
  <script>
  function jtCancelOpen(){document.getElementById('jt-cancel-modal').style.display='flex';}
  function jtCancelSubmit(){
    var msg=document.getElementById('jt-cancel-msg');
    var btn=document.getElementById('jt-cancel-btn');
    btn.disabled=true;btn.textContent='Cancelling…';
    var fd=new FormData();
    fd.append('action','gs_cancel_booking_customer');
    fd.append('nonce','<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>');
    fd.append('tracking_token','<?php echo esc_js($booking->tracking_token??''); ?>');
    fetch('<?php echo esc_js(admin_url("admin-ajax.php")); ?>',{method:'POST',body:fd,credentials:'same-origin'})
      .then(function(r){return r.json();})
      .then(function(res){
        if(res&&res.success){
          msg.style.color='#059669';
          msg.textContent=(res.data&&res.data.message)||'Booking cancelled.';
          setTimeout(function(){location.reload();},1200);
        } else {
          btn.disabled=false;btn.textContent='Yes, Cancel It';
          msg.style.color='#DC2626';
          msg.textContent=(res&&res.data&&res.data.message)||'Failed. Please try again.';
        }
      })
      .catch(function(){btn.disabled=false;btn.textContent='Yes, Cancel It';msg.style.color='#DC2626';msg.textContent='Network error.';});
  }
  </script>
  <?php endif; ?>
  <?php if ( $can_reschedule ): ?>
  <div id="jt-reschedule-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;align-items:center;justify-content:center;padding:16px">
    <div style="background:#fff;border-radius:16px;padding:24px;max-width:360px;width:100%">
      <div style="font-weight:800;font-size:1rem;margin-bottom:14px">🔄 Request Reschedule</div>
      <div style="font-size:.83rem;color:#64748B;margin-bottom:14px">
        Choose a new date and time. You have <strong><?php echo $reschedules_left; ?></strong> reschedule<?php echo $reschedules_left!=1?'s':''; ?> remaining.<br>
        <em style="font-size:.76rem">Note: must be at least <?php echo (int)\GoodService\Core\Config::get('booking_reschedule_min_hours',4); ?> hours before your current slot.</em>
      </div>
      <label style="font-size:.82rem;font-weight:600;display:block;margin-bottom:4px">New Date</label>
      <input type="date" id="jt-rs-date" min="<?php echo date('Y-m-d'); ?>" style="width:100%;border:2px solid #E2E8F0;border-radius:8px;padding:10px;font-size:.9rem;margin-bottom:12px;box-sizing:border-box">
      <label style="font-size:.82rem;font-weight:600;display:block;margin-bottom:4px">Preferred Time</label>
      <input type="time" id="jt-rs-time" style="width:100%;border:2px solid #E2E8F0;border-radius:8px;padding:10px;font-size:.9rem;margin-bottom:12px;box-sizing:border-box">
      <div id="jt-rs-msg" style="font-size:.8rem;margin-bottom:10px;min-height:18px"></div>
      <div style="display:flex;gap:8px">
        <button onclick="document.getElementById('jt-reschedule-modal').style.display='none'" style="flex:1;background:#F1F5F9;border:none;border-radius:8px;padding:10px;font-size:.85rem;cursor:pointer">Cancel</button>
        <button onclick="jtRescheduleSubmit()" id="jt-rs-btn" style="flex:2;background:#2563EB;color:#fff;border:none;border-radius:8px;padding:10px;font-size:.85rem;font-weight:700;cursor:pointer">Submit Request</button>
      </div>
    </div>
  </div>
  <script>
  function jtRescheduleOpen(){document.getElementById('jt-reschedule-modal').style.display='flex';}
  function jtRescheduleSubmit(){
    var d=document.getElementById('jt-rs-date').value;
    var t=document.getElementById('jt-rs-time').value;
    var msg=document.getElementById('jt-rs-msg');
    var btn=document.getElementById('jt-rs-btn');
    if(!d){msg.style.color='#DC2626';msg.textContent='Please choose a date.';return;}
    if(!t){msg.style.color='#DC2626';msg.textContent='Please choose a time.';return;}
    btn.disabled=true;btn.textContent='Submitting…';
    var fd=new FormData();
    fd.append('action','gs_reschedule_booking');
    fd.append('nonce','<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>');
    fd.append('tracking_token','<?php echo esc_js($booking->tracking_token??''); ?>');
    fd.append('new_date',d);fd.append('new_time',t);
    fetch('<?php echo esc_js(admin_url("admin-ajax.php")); ?>',{method:'POST',body:fd,credentials:'same-origin'})
      .then(function(r){return r.json();})
      .then(function(res){
        if(res&&res.success){
          document.getElementById('jt-reschedule-modal').style.display='none';
          msg.style.color='#059669';
          msg.textContent=res.data.message||'Reschedule requested!';
          setTimeout(function(){location.reload();},1800);
        } else {
          btn.disabled=false;btn.textContent='Submit Request';
          msg.style.color='#DC2626';
          msg.textContent=(res&&res.data&&res.data.message)||'Failed. Please try again.';
        }
      })
      .catch(function(){btn.disabled=false;btn.textContent='Submit Request';msg.style.color='#DC2626';msg.textContent='Network error.';});
  }
  </script>
  <?php endif; // $can_reschedule ?>
  <?php endif; // $can_reschedule || $can_cancel ?>
</div>

<!-- Auto-refresh -->
<div style="text-align:center;font-size:.74rem;color:#94A3B8;margin-top:8px" id="jt-refresh-note">
  Auto-refreshes every 30 seconds
</div>

<script>
(function(){
  var refreshInterval = 30000;
  var countdown = refreshInterval / 1000;
  var note = document.getElementById('jt-refresh-note');
  var timer = setInterval(function(){
    countdown--;
    if (note) note.textContent = 'Refreshing in ' + countdown + 's…';
    if (countdown <= 0) {
      clearInterval(timer);
      location.reload();
    }
  }, 1000);
})();
</script>
<?php endif; ?>

</div><!-- .jt-wrap -->
<?php get_footer(); ?>
