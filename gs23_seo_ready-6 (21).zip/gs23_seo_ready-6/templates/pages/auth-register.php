<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
// Register page — same template as login, opens register tab by default
if ( is_user_logged_in() ) {
    $dest = function_exists('gs_login_redirect') ? gs_login_redirect() : ( gs_is_admin_level() ? home_url('/admin-panel/') : home_url('/vendor/dashboard/') );
    wp_redirect( $dest );
    exit;
}
// Override default tab to register
add_filter( 'wp_footer', function() {
    echo '<script>document.addEventListener("DOMContentLoaded",function(){if(typeof switchTab==="function")switchTab("register");});</script>';
});
require GS_DIR . 'templates/pages/auth-login.php';
