<?php
/**
 * Template: Listing Detail Page  GoodService Platform v3
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

use GoodService\Repository\ListingRepository;

global $wpdb, $gs_current_listing;
$pfx  = $wpdb->prefix . 'gs_';
$slug = sanitize_text_field( get_query_var('gs_slug','') );

if ( ! $slug ) { wp_redirect( home_url('/directory/') ); exit; }

// Use Repository (cached) then fall back to direct query for extra fields
$repo    = new ListingRepository();
$listing = $repo->get_by_slug( $slug );

if ( ! $listing ) { wp_redirect( home_url('/directory/') ); exit; }
$json_ld = null; // will be populated after vp_detail is fetched
$gs_current_listing = $listing;

// Decode JSON fields
foreach(['gallery','services_data','products_data','process_data','faq_data','why_choose_data','stats_data','service_cities','opening_hours'] as $f){
    $listing->$f = json_decode($listing->$f??'[]',true)?:[];
}
$listing->social_links = json_decode($listing->social_links??'{}',true)?:[];

// Vendor profile (for trust score, reply time, video intro)
$vp_detail = null;
try {
    $vp_detail = $wpdb->get_row($wpdb->prepare(
        "SELECT vp.*,u.user_email FROM {$pfx}vendor_profiles vp
         LEFT JOIN {$wpdb->users} u ON u.ID=vp.user_id
         WHERE vp.id=%d",
        (int)$listing->vendor_id
    ));
} catch (\Throwable $e) { $vp_detail = null; }

// Part 12.3 — Verification badges (safe when tables don't exist yet)
$listing_certs = [];
if ( $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}gs_vendor_certifications'") ) {
    $listing_certs = $wpdb->get_results($wpdb->prepare(
        "SELECT vc.cert_level, vc.cert_number, vc.issued_at, c.title AS course_title
         FROM {$wpdb->prefix}gs_vendor_certifications vc
         JOIN {$wpdb->prefix}gs_courses c ON c.id=vc.course_id
         WHERE vc.vendor_id=%d AND vc.is_active=1 AND (vc.expires_at IS NULL OR vc.expires_at>CURDATE())
         ORDER BY vc.issued_at DESC LIMIT 5",
        $listing->vendor_id
    )) ?: [];
}

$listing_vdocs = $wpdb->get_results($wpdb->prepare(
    "SELECT doc_type, badge_type, status FROM {$wpdb->prefix}gs_verification_docs
     WHERE vendor_id=%d AND status='approved'",
    $listing->vendor_id
)) ?: [];

// Part 21.4 — Social proof ticker (recent lead, last 7 days)
$social_proof_lead = null;
try {
    $social_proof_lead = $wpdb->get_row($wpdb->prepare(
        "SELECT l.name, COALESCE(l.city, 'your area') AS area, l.created_at
         FROM {$pfx}leads l
         WHERE l.listing_id=%d AND l.created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
         ORDER BY l.created_at DESC LIMIT 1",
        $listing->id
    ));
} catch (\Throwable $e) { $social_proof_lead = null; }

// Category
$cat = $listing->category_id ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$pfx}categories WHERE id=%d",$listing->category_id)) : null;

// Reviews
$reviews    = $wpdb->get_results($wpdb->prepare("SELECT r.*,u.display_name as wp_name FROM {$pfx}reviews r LEFT JOIN {$wpdb->users} u ON u.ID=r.user_id WHERE r.listing_id=%d AND r.status='approved' ORDER BY r.helpful_count DESC,r.created_at DESC LIMIT 10",$listing->id));
$review_avg = $wpdb->get_var($wpdb->prepare("SELECT AVG(rating) FROM {$pfx}reviews WHERE listing_id=%d AND status='approved'",$listing->id));


// Part 26.2 — JSON-LD LocalBusiness structured data
// Map category to specific schema type (same logic as render_listing_unified)
$_ld_cat_slug = strtolower( $cat->slug ?? '' );
$_ld_type_map = [
    'plumber'=>'Plumber','plumbing'=>'Plumber','electrician'=>'Electrician','electrical'=>'Electrician',
    'locksmith'=>'Locksmith','lawyer'=>'LegalService','legal'=>'LegalService','advocate'=>'LegalService',
    'ca'=>'AccountingService','accountant'=>'AccountingService','doctor'=>'Physician',
    'physician'=>'Physician','dentist'=>'Dentist','dental'=>'Dentist','hospital'=>'Hospital',
    'clinic'=>'MedicalClinic','salon'=>'HairSalon','hair'=>'HairSalon','beauty'=>'BeautySalon',
    'spa'=>'DaySpa','gym'=>'ExerciseGym','fitness'=>'ExerciseGym','restaurant'=>'Restaurant',
    'food'=>'FoodEstablishment','catering'=>'FoodEstablishment','travel'=>'TravelAgency',
    'school'=>'School','coaching'=>'EducationalOrganization','hotel'=>'LodgingBusiness',
    'pharmacy'=>'Pharmacy','real-estate'=>'RealEstateAgent','property'=>'RealEstateAgent',
    'interior'=>'HomeAndConstructionBusiness','construction'=>'HomeAndConstructionBusiness',
    'painter'=>'HomeAndConstructionBusiness','pest-control'=>'HomeAndConstructionBusiness',
    'cleaning'=>'HomeAndConstructionBusiness',
];
$_ld_type = 'LocalBusiness';
foreach ( $_ld_type_map as $_p => $_t ) {
    if ( str_contains( $_ld_cat_slug, $_p ) ) { $_ld_type = $_t; break; }
}

$_ld_canonical   = home_url( '/' . ltrim( $listing->slug, '/' ) . '/' );
$_ld_description = wp_strip_all_tags( $listing->short_desc ?? $listing->full_desc ?? '' );
$_ld_phone       = $vp_detail->phone ?? $listing->phone ?? '';
$_ld_address_str = $listing->address ?? '';

$json_ld = [
    '@context'    => 'https://schema.org',
    '@type'       => $_ld_type,
    '@id'         => $_ld_canonical,
    'name'        => $listing->title,
    'description' => $_ld_description,
    'url'         => $_ld_canonical,
    'image'       => $listing->banner_url ?? $listing->logo_url ?? '',
];
if ( $_ld_phone )       { $json_ld['telephone'] = $_ld_phone; }
if ( $listing->email )  { $json_ld['email']     = $listing->email; }

$_ld_postal = [
    '@type'          => 'PostalAddress',
    'addressLocality'=> $listing->city  ?? '',
    'addressRegion'  => $listing->state ?? '',
    'addressCountry' => 'IN',
];
if ( ! empty( $listing->pincode ) )  { $_ld_postal['postalCode']    = $listing->pincode; }
if ( $_ld_address_str )              { $_ld_postal['streetAddress'] = $_ld_address_str; }
$json_ld['address'] = $_ld_postal;

if ( ! empty( $listing->lat ) && ! empty( $listing->lng ) ) {
    $json_ld['geo'] = [ '@type' => 'GeoCoordinates', 'latitude' => (float)$listing->lat, 'longitude' => (float)$listing->lng ];
}

// sameAs from social links
if ( ! empty( $listing->social_links ) ) {
    $_ld_same_as = [];
    foreach ( [ 'facebook','fb','instagram','linkedin','twitter','x','youtube' ] as $_net ) {
        if ( ! empty( $listing->social_links[$_net] ) && filter_var( $listing->social_links[$_net], FILTER_VALIDATE_URL ) ) {
            $_ld_same_as[] = $listing->social_links[$_net];
        }
    }
    if ( $_ld_same_as ) { $json_ld['sameAs'] = array_values( array_unique( $_ld_same_as ) ); }
}

if ( $listing->established_year ) { $json_ld['foundingDate'] = $listing->established_year; }

if ( $review_avg > 0 && count($reviews) > 0 ) {
    // Use listing->review_count for the real total, not count() which is capped at LIMIT 10
    $_ld_total_reviews = max( (int)( $listing->review_count ?? 0 ), count( $reviews ) );
    $json_ld['aggregateRating'] = [
        '@type'       => 'AggregateRating',
        'ratingValue' => round( (float)$review_avg, 1 ),
        'reviewCount' => $_ld_total_reviews,
        'bestRating'  => 5,
        'worstRating' => 1,
    ];
}
if ( ! empty( $listing->faq_data ) ) {
    $json_ld['mainEntity'] = array_map(
        fn($f) => ['@type'=>'Question','name'=>$f['question']??'','acceptedAnswer'=>['@type'=>'Answer','text'=>wp_strip_all_tags($f['answer']??'')]],
        array_filter( $listing->faq_data, fn($f) => ! empty($f['question']) )
    );
    if ( ! empty( $json_ld['mainEntity'] ) ) { $json_ld['@type'] = [ $_ld_type, 'FAQPage' ]; }
}

// SEO meta values
$_ld_seo_title = ! empty( $listing->seo_title ) ? $listing->seo_title
    : ( $listing->title . ( $listing->city ? ' in ' . $listing->city : '' ) );
$_ld_seo_desc  = ! empty( $listing->seo_desc ) ? $listing->seo_desc
    : ( $_ld_description ? substr( $_ld_description, 0, 160 ) : $listing->title );
$_ld_og_img    = ! empty( $listing->og_image ) ? $listing->og_image
    : ( $listing->banner_url ?? $listing->logo_url ?? '' );

// Inject into <head> via wp_head — must be registered before wp_head fires,
// which is guaranteed since this template is included before get_header()
add_action( 'wp_head', function() use ( $json_ld, $_ld_canonical, $_ld_seo_title, $_ld_seo_desc, $_ld_og_img ) {
    // Meta description and robots
    echo '<meta name="description" content="' . esc_attr( $_ld_seo_desc ) . '">';
    echo '<meta name="robots" content="index,follow">';
    // Canonical
    echo '<link rel="canonical" href="' . esc_url( $_ld_canonical ) . '">';
    // Open Graph
    echo '<meta property="og:type" content="website">';
    echo '<meta property="og:locale" content="en_IN">';
    echo '<meta property="og:title" content="' . esc_attr( $_ld_seo_title ) . '">';
    echo '<meta property="og:description" content="' . esc_attr( $_ld_seo_desc ) . '">';
    echo '<meta property="og:url" content="' . esc_url( $_ld_canonical ) . '">';
    if ( $_ld_og_img ) {
        echo '<meta property="og:image" content="' . esc_url( $_ld_og_img ) . '">';
    }
    // Twitter Card
    echo '<meta name="twitter:card" content="summary_large_image">';
    echo '<meta name="twitter:title" content="' . esc_attr( $_ld_seo_title ) . '">';
    echo '<meta name="twitter:description" content="' . esc_attr( $_ld_seo_desc ) . '">';
    if ( $_ld_og_img ) {
        echo '<meta name="twitter:image" content="' . esc_url( $_ld_og_img ) . '">';
    }
    // JSON-LD
    if ( ! empty( $json_ld ) ) {
        $json_ld_clean = array_filter( $json_ld, fn($v) => $v !== '' && $v !== null && $v !== [] );
        echo '<script type="application/ld+json">' . wp_json_encode( $json_ld_clean, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>';
    }
}, 5 );

// Related listings
$related = $wpdb->get_results($wpdb->prepare("SELECT l.*,vp.verification_status FROM {$pfx}listings l LEFT JOIN {$pfx}vendor_profiles vp ON l.vendor_id=vp.id WHERE l.category_id=%d AND l.status='active' AND l.id!=%d ORDER BY l.avg_rating DESC LIMIT 4",$listing->category_id,$listing->id));

// Vendor & subscription
$has_whatsapp = gs_vendor_can('whatsapp',$listing->vendor_id);
$has_video    = gs_vendor_can('video',$listing->vendor_id);
$whatsapp = $listing->whatsapp ?: ($listing->vendor_wa ?? '');
$phone    = $listing->phone    ?: ($listing->vendor_phone ?? '');

// Real fix — confirmed dead param: the Visual Editor's live-preview iframe
// (templates/pages/visual-editor.php) requests this same public listing
// URL with ?gs_ve_preview=1&ve_token=<nonce>, but nothing here ever read
// or verified that param, so every keystroke-triggered preview refresh
// was silently counted as a real visitor view — inflating the vendor's
// own analytics every time they edited their own listing. Verified nonce
// (scoped to its own 'gs_ve_preview' action, distinct from all other
// nonces) skips the increment for genuine preview loads only; a forged
// or expired token still counts as a normal view, so this cannot be used
// to suppress real analytics.
$is_ve_preview = ! empty( $_GET['gs_ve_preview'] )
    && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['ve_token'] ?? '' ) ), 'gs_ve_preview' );
if ( ! $is_ve_preview ) {
    $repo->increment_views($listing->id);
}
?>
<div class="gs-root">

<!-- ── HERO ─────────────────────────────────────────────────── -->
<section class="gs-listing-hero">
  <div class="gs-listing-hero-bg">
    <?php if($listing->banner_url): ?><img src="<?php echo esc_url($listing->banner_url); ?>" alt="<?php echo esc_attr($listing->title); ?>"><?php endif; ?>
  </div>
  <div class="gs-listing-hero-overlay"></div>
  <div class="gs-listing-hero-content">
    <div class="gs-container">
      <!-- Breadcrumb -->
      <div class="gs-listing-breadcrumb">
        <a href="<?php echo home_url('/'); ?>">Home</a><span class="gs-listing-breadcrumb-sep">›</span>
        <a href="<?php echo home_url('/directory/'); ?>">Directory</a><span class="gs-listing-breadcrumb-sep">›</span>
        <?php if($cat): ?><a href="<?php echo home_url('/directory/?category='.$cat->slug); ?>"><?php echo esc_html($cat->name); ?></a><span class="gs-listing-breadcrumb-sep">›</span><?php endif; ?>
        <span><?php echo esc_html($listing->title); ?></span>
      </div>

      <div class="gs-listing-hero-inner">
        <!-- Logo -->
        <div class="gs-listing-hero-logo">
          <img src="<?php echo esc_url($listing->logo_url ?: ($listing->vendor_logo ?: GS_URL.'assets/images/placeholder.jpg')); ?>" alt="Logo">
        </div>
        <!-- Text -->
        <div class="gs-listing-hero-text">
          <div class="gs-listing-name">
            <?php echo esc_html($listing->title); ?>
            <?php if($listing->is_featured): ?><span class="gs-badge gs-badge-featured" style="font-size:.7rem">⭐ Featured</span><?php endif; ?>
          </div>
          <?php if($listing->tagline): ?><div class="gs-listing-tagline"><?php echo esc_html($listing->tagline); ?></div><?php endif; ?>
          <!-- Trust strip -->
          <div class="gs-listing-trust-strip">
            <?php if($review_avg>0): ?><div class="gs-listing-trust-item"><?php echo gs_stars(round($review_avg)); ?> <strong><?php echo number_format($review_avg,1); ?></strong> (<?php echo count($reviews); ?> reviews)</div><?php endif; ?>
            <?php if($listing->city): ?><div class="gs-listing-trust-item">📍 <?php echo esc_html($listing->city); ?><?php if($listing->state): ?>, <?php echo esc_html($listing->state); ?><?php endif; ?></div><?php endif; ?>
            <?php if($listing->established_year): ?><div class="gs-listing-trust-item">📅 Est. <?php echo $listing->established_year; ?></div><?php endif; ?>
            <div class="gs-listing-trust-item">👁 <?php echo number_format($listing->views_count); ?> views</div>
            <?php if($listing->leads_count): ?><div class="gs-listing-trust-item">📞 <?php echo $listing->leads_count; ?> enquiries</div><?php endif; ?>
          </div>
          <!-- CTAs removed per design requirements -->
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ── STICKY SECTION NAV ─────────────────────────────────────── -->
<div class="gs-listing-section-nav">
  <div class="gs-container">
    <div class="gs-listing-section-nav-inner">
      <?php
      $sections_nav = [];
      if($listing->full_desc||$listing->short_desc)                 $sections_nav['about']      = 'About';
      if(!empty($listing->services_data)||!empty($listing->products_data)) $sections_nav['services']   = $listing->listing_type==='product'?'Products':'Services';
      if(!empty($listing->process_data))                            $sections_nav['process']    = 'Process';
      if(!empty($listing->gallery))                                 $sections_nav['gallery']    = 'Gallery';
      if(!empty($listing->stats_data))                              $sections_nav['stats']      = 'Stats';
      if(!empty($listing->why_choose_data))                         $sections_nav['why_choose'] = 'Why Us';
      if(!empty($listing->faq_data))                                $sections_nav['faq']        = 'FAQ';
      if($phone||$listing->email||$listing->address)                $sections_nav['contact']    = 'Contact';
      $sections_nav['reviews']   = 'Reviews';
      foreach($sections_nav as $sid=>$slabel):
      ?>
      <div class="gs-section-nav-item" data-section="gs-section-<?php echo $sid; ?>"><?php echo $slabel; ?></div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- ── MAIN CONTENT ──────────────────────────────────────────── -->
<div class="gs-container" style="padding-top:0;padding-bottom:max(60px,calc(60px + env(safe-area-inset-bottom,0)))">
  <div style="display:grid;grid-template-columns:1fr 340px;gap:32px;align-items:start">

    <div>
    <!-- ABOUT -->
    <?php if($listing->full_desc||$listing->short_desc): ?>
    <section class="gs-listing-section" id="gs-section-about">
      <h2 class="gs-section-title">About Us</h2>
      <?php
      // Decode about_data for about image
      $about_data = json_decode($listing->about_data ?? '{}', true) ?: [];
      $about_image = $about_data['about_image'] ?? '';
      $has_about_img = !empty($about_image);
      ?>
      <?php if($listing->certifications||$listing->awards||$listing->team_size): ?>
      <div style="display:flex;flex-wrap:wrap;gap:12px;margin-bottom:24px">
        <?php if($listing->established_year): ?><div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:12px 18px;text-align:center"><div style="font-size:1.2rem;font-weight:800;color:#1E3A5F"><?php echo $listing->established_year; ?></div><div style="font-size:.72rem;color:#94A3B8;letter-spacing:.06em;text-transform:uppercase;margin-top:2px">Founded</div></div><?php endif; ?>
        <?php if($listing->team_size): ?><div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:12px 18px;text-align:center"><div style="font-size:1.2rem;font-weight:800;color:#1E3A5F"><?php echo esc_html($listing->team_size); ?></div><div style="font-size:.72rem;color:#94A3B8;letter-spacing:.06em;text-transform:uppercase;margin-top:2px">Team Size</div></div><?php endif; ?>
        <?php if($listing->certifications): ?><div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:12px 18px"><div style="font-size:.8rem;font-weight:700;color:#1E3A5F;margin-bottom:4px">Certified</div><div style="font-size:.75rem;color:#64748B"><?php echo esc_html($listing->certifications); ?></div></div><?php endif; ?>
      </div>
      <?php endif; ?>
      <div class="gs-about-layout <?php echo $has_about_img ? 'gs-about-with-img' : ''; ?>">
        <div class="gs-about-text-col">
          <div style="font-size:.95rem;line-height:1.9;color:#475569"><?php echo wpautop(wp_kses_post($listing->full_desc?:$listing->short_desc)); ?></div>
          <?php if($listing->highlights): ?>
          <div style="margin-top:20px;display:flex;flex-direction:column;gap:8px">
            <?php foreach(array_filter(explode("\n",$listing->highlights)) as $h): ?>
            <div style="display:flex;align-items:center;gap:10px;font-size:.9rem;color:#1E293B">
              <span style="color:#1E3A5F;flex-shrink:0;font-weight:700">—</span><?php echo esc_html(trim($h)); ?>
            </div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        </div>
        <?php if($has_about_img): ?>
        <div class="gs-about-img-col">
          <img src="<?php echo esc_url($about_image); ?>" alt="<?php echo esc_attr($listing->title); ?>" class="gs-about-img" loading="lazy">
        </div>
        <?php endif; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- SERVICES or PRODUCTS -->
    <?php if(!empty($listing->services_data)||!empty($listing->products_data)): ?>
    <section class="gs-listing-section" id="gs-section-services">
      <h2 class="gs-section-title"><?php echo $listing->listing_type==='product'?'Our Products':'Our Services'; ?></h2>
      <?php if($listing->listing_type==='product'&&!empty($listing->products_data)): ?>
      <div class="gs-products-grid">
        <?php foreach($listing->products_data as $prod): if(empty($prod['name']))continue; ?>
        <div class="gs-product-card">
          <?php if(!empty($prod['image'])): ?><div class="gs-product-img"><img src="<?php echo esc_url($prod['image']); ?>" alt="<?php echo esc_attr($prod['name']); ?>" loading="lazy"></div><?php endif; ?>
          <div class="gs-product-body">
            <div class="gs-product-name"><?php echo esc_html($prod['name']); ?></div>
            <?php if(!empty($prod['price'])&&$prod['price']>0): ?><div class="gs-product-price"><?php echo gs_setting('currency_symbol','₹'); ?><?php echo number_format($prod['price']); ?><?php if(!empty($prod['price_unit'])): ?><span style="font-size:.8rem;font-weight:400;color:#64748B"> / <?php echo esc_html($prod['price_unit']); ?></span><?php endif; ?></div><?php endif; ?>
            <?php if(!empty($prod['description'])): ?><div class="gs-product-desc"><?php echo esc_html($prod['description']); ?></div><?php endif; ?>
            <?php if(empty($prod['show_quote_btn'])||$prod['show_quote_btn']): ?><button onclick="gsShowLeadPopup(<?php echo $listing->id; ?>,'<?php echo esc_js($prod['name']); ?>')" class="gs-btn gs-btn-primary gs-btn-sm" style="margin-top:10px;width:100%">Get Quote</button><?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php else: ?>
      <div class="gs-services-grid">
        <?php foreach($listing->services_data as $svc): if(empty($svc['name']))continue; ?>
        <div class="gs-service-card">
          <?php if(!empty($svc['icon'])): ?><div class="gs-service-icon"><?php echo esc_html($svc['icon']); ?></div><?php endif; ?>
          <div class="gs-service-name"><?php echo esc_html($svc['name']); ?></div>
          <?php if(!empty($svc['description'])): ?><div class="gs-service-desc"><?php echo esc_html($svc['description']); ?></div><?php endif; ?>
          <?php if(!empty($svc['price'])&&$svc['price']>0): ?><div class="gs-service-price"><?php echo gs_setting('currency_symbol','₹'); ?><?php echo number_format($svc['price']); ?><?php if(!empty($svc['price_type'])&&$svc['price_type']==='starting'): ?> onwards<?php endif; ?></div><?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </section>
    <?php endif; ?>

    <!-- PROCESS STEPS -->
    <?php if(!empty($listing->process_data)): ?>
    <section class="gs-listing-section" id="gs-section-process">
      <h2 class="gs-section-title">How We Work</h2>
      <div class="gs-process-steps">
        <?php foreach($listing->process_data as $i=>$step): if(empty($step['title']))continue; ?>
        <div class="gs-process-step">
          <div class="gs-process-num"><?php echo $i+1; ?></div>
          <?php if(!empty($step['icon'])): ?><div style="font-size:1.5rem;margin-bottom:8px"><?php echo esc_html($step['icon']); ?></div><?php endif; ?>
          <div class="gs-process-title"><?php echo esc_html($step['title']); ?></div>
          <?php if(!empty($step['description'])): ?><div class="gs-process-desc"><?php echo esc_html($step['description']); ?></div><?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- GALLERY -->
    <?php if(!empty($listing->gallery)): ?>
    <section class="gs-listing-section" id="gs-section-gallery">
      <h2 class="gs-section-title">Gallery</h2>
      <?php if($has_video&&$listing->video_url): ?>
      <div style="margin-bottom:20px;border-radius:12px;overflow:hidden;aspect-ratio:16/9">
        <?php
        $vid_url = $listing->video_url;
        if(strpos($vid_url,'youtu')!==false){preg_match('/(?:v=|youtu\.be\/)([A-Za-z0-9_-]+)/i',$vid_url,$m);$vid_id=$m[1]??'';}
        elseif(strpos($vid_url,'vimeo')!==false){preg_match('/vimeo\.com\/(\d+)/i',$vid_url,$m);$vid_id=$m[1]??'';}
        if(!empty($vid_id)&&strpos($vid_url,'youtu')!==false):
        ?><iframe src="https://www.youtube.com/embed/<?php echo esc_attr($vid_id); ?>" style="width:100%;height:100%;border:0" allowfullscreen loading="lazy"></iframe>
        <?php endif; ?>
      </div>
      <?php endif; ?>
      <div class="gs-gallery-grid">
        <?php foreach($listing->gallery as $img): if(empty($img['url']??$img))continue; $url=is_array($img)?($img['url']??''):$img; ?>
        <div class="gs-gallery-item"><img src="<?php echo esc_url($url); ?>" alt="Gallery image" loading="lazy"></div>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- STATS -->
    <?php if(!empty($listing->stats_data)): ?>
    <section class="gs-listing-section gs-stats-grid" id="gs-section-stats">
      <?php foreach($listing->stats_data as $key=>$val): if(!$val) continue;
        $labels=['total_services'=>'Services Offered','experience_years'=>'Years Experience','happy_clients'=>'Happy Clients','projects_completed'=>'Projects Done'];
      ?>
      <div class="gs-stat-item">
        <div class="gs-stat-number" data-target="<?php echo intval($val); ?>" data-suffix="+"><?php echo number_format($val); ?>+</div>
        <div class="gs-stat-label-text"><?php echo $labels[$key]??ucwords(str_replace('_',' ',$key)); ?></div>
      </div>
      <?php endforeach; ?>
    </section>
    <?php endif; ?>

    <!-- WHY CHOOSE US -->
    <?php if(!empty($listing->why_choose_data)): ?>
    <section class="gs-listing-section" id="gs-section-why_choose">
      <h2 class="gs-section-title">Why Choose Us</h2>
      <div class="gs-why-grid">
        <?php foreach($listing->why_choose_data as $w): if(empty($w['title']))continue; ?>
        <div class="gs-why-card">
          <?php if(!empty($w['icon'])): ?><div class="gs-why-icon"><?php echo esc_html($w['icon']); ?></div><?php endif; ?>
          <div><div class="gs-why-title"><?php echo esc_html($w['title']); ?></div><?php if(!empty($w['description'])): ?><div class="gs-why-desc"><?php echo esc_html($w['description']); ?></div><?php endif; ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- FAQ -->
    <?php if(!empty($listing->faq_data)): ?>
    <section class="gs-listing-section" id="gs-section-faq">
      <h2 class="gs-section-title">Frequently Asked Questions</h2>
      <div class="gs-faq-list">
        <?php foreach($listing->faq_data as $faq): if(empty($faq['question']))continue; ?>
        <div class="gs-faq-item">
          <div class="gs-faq-question"><?php echo esc_html($faq['question']); ?><span class="gs-faq-arrow">▼</span></div>
          <div class="gs-faq-answer"><?php echo esc_html($faq['answer']??''); ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <!-- CONTACT -->
    <?php if($phone||$listing->email||$listing->address): ?>
    <section class="gs-listing-section gs-contact-section" id="gs-section-contact">
      <h2 class="gs-section-title">Contact &amp; Location</h2>
      <div class="gs-contact-two-col">

        <!-- LEFT: Contact details -->
        <div class="gs-contact-details-col">
          <div class="gs-contact-details-inner">
            <?php if($phone): ?>
            <div class="gs-cd-item">
              <div class="gs-cd-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 11.5a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.62 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 9.91a16 16 0 0 0 6.29 6.29l.91-.91a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg></div>
              <div class="gs-cd-content">
                <div class="gs-cd-label">Phone</div>
                <a href="tel:<?php echo esc_attr($phone); ?>" class="gs-cd-value"><?php echo esc_html($phone); ?></a>
              </div>
            </div>
            <?php endif; ?>

            <?php if($has_whatsapp&&$whatsapp): ?>
            <div class="gs-cd-item">
              <div class="gs-cd-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/></svg></div>
              <div class="gs-cd-content">
                <div class="gs-cd-label">WhatsApp</div>
                <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/','',esc_attr($whatsapp)); ?>" target="_blank" class="gs-cd-value"><?php echo esc_html($whatsapp); ?></a>
              </div>
            </div>
            <?php endif; ?>

            <?php if($listing->email): ?>
            <div class="gs-cd-item">
              <div class="gs-cd-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div>
              <div class="gs-cd-content">
                <div class="gs-cd-label">Email</div>
                <a href="mailto:<?php echo esc_attr($listing->email); ?>" class="gs-cd-value"><?php echo esc_html($listing->email); ?></a>
              </div>
            </div>
            <?php endif; ?>

            <?php if($listing->website): ?>
            <div class="gs-cd-item">
              <div class="gs-cd-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></div>
              <div class="gs-cd-content">
                <div class="gs-cd-label">Website</div>
                <a href="<?php echo esc_url($listing->website); ?>" target="_blank" rel="nofollow" class="gs-cd-value"><?php echo esc_html(preg_replace('#^https?://(www\.)?#','',rtrim($listing->website,'/'))); ?></a>
              </div>
            </div>
            <?php endif; ?>

            <?php if($listing->address): ?>
            <div class="gs-cd-item gs-cd-item-align-top">
              <div class="gs-cd-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div>
              <div class="gs-cd-content">
                <div class="gs-cd-label">Address</div>
                <div class="gs-cd-value"><?php echo nl2br(esc_html($listing->address)); ?></div>
              </div>
            </div>
            <?php endif; ?>

            <?php if(!empty($listing->service_cities)): ?>
            <div class="gs-cd-cities">
              <div class="gs-cd-label">Service Areas</div>
              <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px"><?php foreach($listing->service_cities as $sc): ?><span class="gs-badge gs-badge-primary" style="font-size:.75rem"><?php echo esc_html($sc); ?></span><?php endforeach; ?></div>
            </div>
            <?php endif; ?>

            <?php if(!empty($listing->opening_hours)): ?>
            <?php
            /* ── §5.6 Now Open / Closed badge ──────────────────────────────────
             * Computes whether the business is currently open based on today's
             * hours entry in $listing->opening_hours (already JSON-decoded above).
             * Format expected: {"monday":"09:00 - 18:00", "tuesday":"", ...}
             * Empty value or missing key = closed all day.
             * ───────────────────────────────────────────────────────────────── */
            $gs_now_day   = strtolower( date( 'l' ) );                // "monday" etc.
            $gs_now_hhmm  = (int) date( 'Hi' );                       // e.g. 0935 for 09:35
            $gs_today_raw = $listing->opening_hours[ $gs_now_day ] ?? null;
            $gs_is_open   = false;

            // Normalise to "HH:MM - HH:MM" string regardless of which editor saved it.
            // create-listing.php stores: {"monday":{"open":"09:00","close":"18:00","closed":false}}
            // vendor-dashboard.php stores: {"monday":"09:00 - 18:00"}
            if ( is_array( $gs_today_raw ) ) {
                // Object format from create-listing.php
                if ( ! empty( $gs_today_raw['closed'] ) ) {
                    $gs_today_hrs = ''; // explicitly closed
                } elseif ( ! empty( $gs_today_raw['open'] ) && ! empty( $gs_today_raw['close'] ) ) {
                    $gs_today_hrs = $gs_today_raw['open'] . ' - ' . $gs_today_raw['close'];
                } else {
                    $gs_today_hrs = '';
                }
            } else {
                $gs_today_hrs = trim( (string)( $gs_today_raw ?? '' ) );
            }

            if ( $gs_today_hrs && preg_match(
                '/^(\d{1,2}):(\d{2})\s*[-–]\s*(\d{1,2}):(\d{2})$/',
                $gs_today_hrs, $gs_bh_m
            ) ) {
                $gs_open_int  = (int) ( str_pad( $gs_bh_m[1], 2, '0', STR_PAD_LEFT ) . $gs_bh_m[2] );
                $gs_close_int = (int) ( str_pad( $gs_bh_m[3], 2, '0', STR_PAD_LEFT ) . $gs_bh_m[4] );
                $gs_is_open   = ( $gs_now_hhmm >= $gs_open_int && $gs_now_hhmm < $gs_close_int );
            }
            ?>
            <div class="gs-cd-hours">
              <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:6px;margin-bottom:10px">
                <div class="gs-cd-label">Opening Hours</div>
                <span style="display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:20px;font-size:.71rem;font-weight:700;
                             <?php echo $gs_is_open
                                 ? 'background:#DCFCE7;color:#166534;border:1px solid #BBF7D0'
                                 : 'background:#FEE2E2;color:#991B1B;border:1px solid #FECACA'; ?>">
                  <span style="width:7px;height:7px;border-radius:50%;background:<?php echo $gs_is_open ? '#22C55E' : '#EF4444'; ?>;display:inline-block"></span>
                  <?php echo $gs_is_open ? 'Open Now' : 'Closed Now'; ?>
                </span>
              </div>
              <?php foreach($listing->opening_hours as $day=>$hours):
                    $gs_is_today = ( strtolower( $day ) === $gs_now_day );
              ?>
              <div class="gs-cd-hour-row" <?php echo $gs_is_today ? 'style="font-weight:600"' : ''; ?>>
                <span class="gs-cd-day" <?php echo $gs_is_today ? 'style="color:#2563EB"' : ''; ?>><?php echo ucfirst($day); ?></span>
                <span class="gs-cd-time"><?php echo esc_html($hours?:'Closed'); ?></span>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if(!empty(array_filter($listing->social_links))): ?>
            <div class="gs-cd-social">
              <?php foreach($listing->social_links as $net=>$url): if(!$url)continue; ?>
              <a href="<?php echo esc_url($url); ?>" target="_blank" rel="nofollow noopener" class="gs-cd-social-link"><?php echo ucfirst($net); ?></a>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if($listing->lat&&$listing->lng&&gs_setting('google_maps_api','')): ?>
            <div style="margin-top:16px"><div id="gs-listing-map" style="height:200px;border-radius:10px;overflow:hidden;border:1px solid #E5E7EB"></div></div>
            <?php endif; ?>
          </div>
        </div>

        <!-- RIGHT: Contact Form -->
        <div class="gs-contact-form-col">
          <?php
          $fluent_id = (int)($listing->fluent_form_id ?? 0);
          if ( $fluent_id > 0 && ( class_exists('FluentForm\App\Models\Form') || defined('FLUENTFORM') ) ):
          ?>
          <div class="gs-contact-form-wrap">
            <div class="gs-contact-form-header">
              <h3 class="gs-contact-form-title">Get in Touch</h3>
              <p class="gs-contact-form-sub">Fill out the form and we'll get back to you shortly.</p>
            </div>
            <div class="gs-fluentform-wrap">
              <?php echo do_shortcode('[fluentform id="' . $fluent_id . '"]'); ?>
            </div>
          </div>
          <?php else: ?>
          <div class="gs-contact-form-wrap">
            <div class="gs-contact-form-header">
              <h3 class="gs-contact-form-title">Send Enquiry</h3>
              <p class="gs-contact-form-sub">Response within 24 hours. We'd love to hear from you.</p>
            </div>
            <form id="gs-contact-inquiry-form" class="gs-contact-form-inner">
              <input type="hidden" name="listing_id" value="<?php echo $listing->id; ?>">
              <input type="hidden" name="source" value="contact_section">
              <div class="gs-cf-row">
                <div class="gs-form-group">
                  <label class="gs-form-label">Full Name <span class="required">*</span></label>
                  <input type="text" name="name" class="gs-input" placeholder="Your full name" required>
                </div>
                <div class="gs-form-group">
                  <label class="gs-form-label">Phone <span class="required">*</span></label>
                  <input type="tel" name="phone" class="gs-input" placeholder="Your mobile number" required>
                </div>
              </div>
              <div class="gs-form-group">
                <label class="gs-form-label">Email Address</label>
                <input type="email" name="email" class="gs-input" placeholder="your@email.com">
              </div>
              <div class="gs-form-group">
                <label class="gs-form-label">Message</label>
                <textarea name="message" class="gs-textarea" rows="4" placeholder="Tell us about your requirement…"></textarea>
              </div>
              <button type="submit" class="gs-btn gs-btn-primary gs-btn-lg gs-btn-full">Send Message</button>
            </form>
            <script>
            jQuery('#gs-contact-inquiry-form').on('submit',function(e){
              e.preventDefault();
              var btn=jQuery(this).find('[type=submit]');
              btn.prop('disabled',true).text('Sending…');
              gsPost('gs_submit_lead',Object.fromEntries(new FormData(this)),function(){
                jQuery('#gs-contact-inquiry-form').html('<div style="text-align:center;padding:32px"><div style="font-size:2.5rem;margin-bottom:10px">✅<\/div><div style="font-weight:700;font-size:1rem;color:#1E3A5F">Message Sent!<\/div><div style="color:#64748B;font-size:.88rem;margin-top:6px">We'll get back to you within 24 hours.<\/div><\/div>');
              },function(m){btn.prop('disabled',false).text('Send Message');gsToast(m,'error');});
            });
            </script>
          </div>
          <?php endif; ?>
        </div>

      </div><!-- .gs-contact-two-col -->
    </section>
    <?php endif; ?>
    <!-- REVIEWS -->
    <section class="gs-listing-section" id="gs-section-reviews">
      <h2 class="gs-section-title">Customer Reviews</h2>
      <?php if($review_avg>0): ?>
      <div style="display:flex;align-items:center;gap:20px;padding:20px;background:#FFFBEB;border-radius:12px;margin-bottom:24px;flex-wrap:wrap">
        <div style="text-align:center"><div style="font-size:3rem;font-weight:900;color:#D97706;line-height:1"><?php echo number_format($review_avg,1); ?></div><div><?php echo gs_stars((float)$review_avg); ?></div><div style="font-size:.82rem;color:#64748B;margin-top:4px"><?php echo count($reviews); ?> reviews</div></div>
        <div style="flex:1;min-width:200px">
          <?php for($s=5;$s>=1;$s--): $cnt=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$pfx}reviews WHERE listing_id=%d AND rating=%d AND status='approved'",$listing->id,$s)); $pct=$cnt&&count($reviews)?round($cnt/count($reviews)*100):0; ?>
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;font-size:.82rem"><span style="width:20px;text-align:right;color:#64748B"><?php echo $s; ?>★</span><div style="flex:1;height:8px;background:#E2E8F0;border-radius:4px;overflow:hidden"><div style="height:100%;background:#F59E0B;width:<?php echo $pct; ?>%;border-radius:4px"></div></div><span style="width:30px;color:#64748B"><?php echo $cnt; ?></span></div>
          <?php endfor; ?>
        </div>
      </div>
      <?php endif; ?>

      <?php if($reviews): ?>
      <div style="display:flex;flex-direction:column;gap:16px;margin-bottom:32px">
        <?php foreach($reviews as $rev): ?>
        <div class="gs-review-card">
          <div class="gs-review-header">
            <div>
              <div class="gs-reviewer-name"><?php echo esc_html($rev->reviewer_name); ?></div>
              <div class="gs-review-date"><?php echo date('d M Y',strtotime($rev->created_at)); ?></div>
            </div>
            <div><?php echo gs_stars($rev->rating); ?></div>
          </div>
          <?php if($rev->title): ?><div style="font-weight:700;margin-bottom:6px;font-size:.9rem"><?php echo esc_html($rev->title); ?></div><?php endif; ?>
          <?php if($rev->review_text): ?><div class="gs-review-text"><?php echo nl2br(esc_html($rev->review_text)); ?></div><?php endif; ?>
          <div class="gs-review-helpful">
            <?php if($rev->verified): ?><span class="gs-verified-badge">✅ Verified</span><?php endif; ?>
            <span style="margin-left:auto;font-size:.75rem;color:#94A3B8">Helpful? </span>
            <button onclick="gsPost('gs_helpful_review',{review_id:<?php echo $rev->id; ?>},function(){this.disabled=true;this.textContent='👍 Helpful ('+parseInt(this.dataset.count)+1+')';}.bind(this))" data-count="<?php echo $rev->helpful_count; ?>" style="background:none;border:1px solid #E2E8F0;border-radius:6px;padding:3px 10px;font-size:.75rem;cursor:pointer">👍 <?php echo $rev->helpful_count; ?></button>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php else: ?>
      <div style="text-align:center;padding:32px;color:#94A3B8;background:#F8FAFC;border-radius:12px;margin-bottom:24px"><div style="font-size:2rem;margin-bottom:8px">⭐</div><div>No reviews yet. Be the first!</div></div>
      <?php endif; ?>

      <!-- Submit review form -->
      <div style="background:#F8FAFC;border:1.5px solid #E2E8F0;border-radius:12px;padding:24px">
        <h3 style="font-size:1rem;font-weight:700;color:#1E3A5F;margin:0 0 18px">Leave a Review</h3>
        <form id="gs-review-form">
          <input type="hidden" name="listing_id" value="<?php echo $listing->id; ?>">
          <div class="gs-form-group"><label class="gs-form-label">Your Rating <span class="required">*</span></label>
            <div class="gs-star-picker"><?php for($i=1;$i<=5;$i++): ?><span class="gs-star" data-value="<?php echo $i; ?>">★</span><?php endfor; ?><input type="hidden" name="rating" value="0"></div>
          </div>
          <div class="gs-grid-2">
            <div class="gs-form-group"><label class="gs-form-label">Your Name <span class="required">*</span></label><input type="text" name="reviewer_name" class="gs-input" placeholder="Your name" required></div>
            <div class="gs-form-group"><label class="gs-form-label">Email <span style="color:#94A3B8">(not shown publicly)</span></label><input type="email" name="reviewer_email" class="gs-input" placeholder="your@email.com"></div>
          </div>
          <div class="gs-form-group"><label class="gs-form-label">Review Title</label><input type="text" name="title" class="gs-input" placeholder="Summarise your experience"></div>
          <div class="gs-form-group"><label class="gs-form-label">Review <span class="required">*</span></label><textarea name="review_text" class="gs-textarea" rows="4" placeholder="Share your experience with this business..." required></textarea></div>
          <button type="submit" class="gs-btn gs-btn-primary gs-btn-md">Submit Review</button>
          <div class="gs-form-hint" style="margin-top:8px">All reviews are moderated before going live. Your email will not be published.</div>
        </form>
      </div>
    </section>
    </div><!-- end left column -->

    <!-- ── RIGHT SIDEBAR ─────────────────────────────────────── -->
    <div style="position:sticky;top:calc(var(--gs-header-h)+16px)">
      <!-- Quick contact -->
      <?php if($phone||($has_whatsapp&&$whatsapp)): ?>
      <div class="gs-card" style="margin-bottom:20px">
        <div class="gs-card-title" style="margin-bottom:14px;font-size:.95rem;font-weight:700">Quick Contact</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          <?php if($phone): ?><a href="tel:<?php echo esc_attr($phone); ?>" class="gs-btn gs-btn-success gs-btn-md gs-btn-full" data-track="call_click" data-listing-id="<?php echo $listing->id; ?>">📞 Call Now</a><?php endif; ?>
          <?php if($has_whatsapp&&$whatsapp): ?><a href="https://wa.me/<?php echo preg_replace('/[^0-9]/','',esc_attr($whatsapp)); ?>" target="_blank" class="gs-btn gs-btn-full gs-btn-md" style="background:#25D366;color:white;border:none" data-track="whatsapp_click" data-listing-id="<?php echo $listing->id; ?>">💬 WhatsApp</a><?php endif; ?>
        </div>
      </div>
      <?php endif; ?>
      <!-- Report link -->
      <div style="text-align:center;font-size:.78rem;color:#94A3B8"><a href="#" onclick="gsShowReportForm()" style="color:#94A3B8">⚑ Report this listing</a></div>
    </div>

  </div><!-- end grid -->

  <!-- RELATED LISTINGS -->
  <?php if($related): ?>
  <div style="padding-top:48px;border-top:1px solid #E2E8F0;margin-top:48px">
    <h2 class="gs-h2" style="margin-bottom:24px">Similar Businesses</h2>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px">
      <?php foreach($related as $r): ?>
      <a href="<?php echo home_url('/listing/'.esc_attr($r->slug).'/'); ?>" style="display:flex;gap:12px;padding:14px;background:white;border:1.5px solid #E2E8F0;border-radius:12px;text-decoration:none;transition:all .2s" onmouseover="this.style.borderColor='#2563EB'" onmouseout="this.style.borderColor='#E2E8F0'">
        <img src="<?php echo esc_url($r->banner_url?:($r->logo_url?:GS_URL.'assets/images/placeholder.jpg')); ?>" style="width:48px;height:48px;border-radius:8px;object-fit:cover;flex-shrink:0" loading="lazy">
        <div style="min-width:0"><div style="font-weight:700;font-size:.88rem;color:#1E3A5F" class="gs-truncate"><?php echo esc_html($r->title); ?></div><div style="font-size:.75rem;color:#94A3B8">📍 <?php echo esc_html($r->city?:'—'); ?></div><?php if($r->avg_rating>0): ?><div style="font-size:.75rem;color:#F59E0B">★ <?php echo number_format($r->avg_rating,1); ?></div><?php endif; ?></div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
</div>

<!-- ── FLOATING WHATSAPP ──────────────────────────────────────── -->
<?php if($has_whatsapp&&$whatsapp): ?>
<div class="gs-whatsapp-float">
  <div class="gs-whatsapp-tooltip">Chat on WhatsApp</div>
  <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/','',esc_attr($whatsapp)); ?>?text=Hi, I found you on <?php echo urlencode(gs_setting('platform_name')); ?>" target="_blank" class="gs-whatsapp-btn" data-track="whatsapp_click" data-listing-id="<?php echo $listing->id; ?>">💬</a>
</div>
<?php endif; ?>

<!-- ── BACK TO TOP ────────────────────────────────────────────── -->
<button class="gs-back-top" title="Back to top">↑</button>

<!-- ── MOBILE STICKY BAR ─────────────────────────────────────── -->
<div class="gs-mobile-sticky">
  <?php if($phone): ?><a href="tel:<?php echo esc_attr($phone); ?>" class="gs-btn gs-btn-success gs-btn-md">📞 Call</a><?php endif; ?>
  <?php if($has_whatsapp&&$whatsapp): ?><a href="https://wa.me/<?php echo preg_replace('/[^0-9]/','',esc_attr($whatsapp)); ?>" target="_blank" class="gs-btn gs-btn-md" style="background:#25D366;color:white">💬 WhatsApp</a><?php endif; ?>
  <button onclick="gsShowLeadPopup(<?php echo $listing->id; ?>)" class="gs-btn gs-btn-gold gs-btn-md">📋 Get Quote</button>
</div>

</div><!-- end gs-root -->

<script>
// Sidebar lead form removed (v9)

// Lead popup modal
function gsShowLeadPopup(listingId,productName){
    var html='<form id="gs-popup-lead">'
        +(productName?'<div style="background:#EFF6FF;padding:10px 14px;border-radius:8px;margin-bottom:14px;font-size:.88rem">📦 Enquiry for: <strong>'+productName+'</strong><input type="hidden" name="product_name" value="'+productName+'"></div>':'')
        +'<input type="hidden" name="listing_id" value="'+listingId+'">'
        +'<input type="hidden" name="source" value="quote_popup">'
        +'<div class="gs-form-group"><label class="gs-form-label">Name *</label><input type="text" name="name" class="gs-input" required placeholder="Your name"></div>'
        +'<div class="gs-form-group"><label class="gs-form-label">Phone *</label><input type="tel" name="phone" class="gs-input" required placeholder="10-digit mobile"></div>'
        +'<div class="gs-form-group"><label class="gs-form-label">Email</label><input type="email" name="email" class="gs-input" placeholder="your@email.com"></div>'
        +'<div class="gs-form-group"><label class="gs-form-label">Message</label><textarea name="message" class="gs-textarea" rows="3" placeholder="What do you need?"></textarea></div>'
        +'</form>';
    gsModal.show(html,{title:'📋 Get a Free Quote',size:'sm',footer:'<button class="gs-btn gs-btn-ghost" onclick="gsModal.hide()">Cancel</button><button class="gs-btn gs-btn-primary gs-btn-md" id="gs-popup-send">Send Request</button>'});
    jQuery('#gs-popup-send').on('click',function(){
        var $btn=jQuery(this);
        gsBtnLoading($btn,true,'Sending...');
        var d={};jQuery('#gs-popup-lead').serializeArray().forEach(function(f){d[f.name]=f.value;});
        gsPost('gs_submit_lead',d,function(r){gsBtnLoading($btn,false,'Send Request');gsModal.hide();gsToast(r.message||'Sent!','success');},function(m){gsBtnLoading($btn,false,'Send Request');gsToast(m,'error');});
    });
}

function gsShowReportForm(){
    gsModal.show('<form id="gs-report-form"><div class="gs-form-group"><label class="gs-form-label">Reason</label><select name="type" class="gs-select"><option value="fraud">Fraud / Scam</option><option value="incorrect_info">Incorrect Information</option><option value="spam">Spam</option><option value="other">Other</option></select></div><div class="gs-form-group"><label class="gs-form-label">Details</label><textarea name="description" class="gs-textarea" rows="3" required></textarea></div><div class="gs-form-group"><label class="gs-form-label">Your Email</label><input type="email" name="complainant_email" class="gs-input" required></div><div class="gs-form-group"><label class="gs-form-label">Your Name</label><input type="text" name="complainant_name" class="gs-input" required></div><input type="hidden" name="against_listing_id" value="<?php echo $listing->id; ?>"><input type="hidden" name="subject" value="Listing report: <?php echo esc_js($listing->title); ?>"></form>',{title:'Report This Listing',size:'sm',footer:'<button class="gs-btn gs-btn-ghost" onclick="gsModal.hide()">Cancel</button><button class="gs-btn gs-btn-danger" onclick="jQuery(\'#gs-report-form\').submit()">Submit Report</button>'});
    jQuery('#gs-report-form').on('submit',function(e){e.preventDefault();var d={};jQuery(this).serializeArray().forEach(function(f){d[f.name]=f.value;});gsPost('gs_submit_complaint',d,function(){gsModal.hide();gsToast('Report submitted. Thank you.','success');});});
}

<?php if($listing->lat&&$listing->lng&&gs_setting('google_maps_api','')): ?>
function gsInitMap(){
    var pos={lat:<?php echo $listing->lat; ?>,lng:<?php echo $listing->lng; ?>};
    var map=new google.maps.Map(document.getElementById('gs-listing-map'),{zoom:15,center:pos,styles:[{featureType:'poi',elementType:'labels',stylers:[{visibility:'off'}]}]});
    new google.maps.Marker({position:pos,map:map,title:'<?php echo esc_js($listing->title); ?>'});
}
<?php endif; ?>
</script>

<?php
// Part 12.3 — Verification badges (safe when tables don't exist yet)
$listing_certs = [];
if ( $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}gs_vendor_certifications'") ) {
    $listing_certs = $wpdb->get_results($wpdb->prepare(
        "SELECT vc.cert_level, vc.cert_number, vc.issued_at, c.title AS course_title
         FROM {$wpdb->prefix}gs_vendor_certifications vc
         JOIN {$wpdb->prefix}gs_courses c ON c.id=vc.course_id
         WHERE vc.vendor_id=%d AND vc.is_active=1 AND (vc.expires_at IS NULL OR vc.expires_at>CURDATE())
         ORDER BY vc.issued_at DESC LIMIT 5",
        $listing->vendor_id
    )) ?: [];
}

$listing_vdocs = $wpdb->get_results($wpdb->prepare(
    "SELECT doc_type, badge_type, status FROM {$wpdb->prefix}gs_verification_docs
     WHERE vendor_id=%d AND status='approved'",
    $listing->vendor_id
)) ?: [];

// Part 21.4 — Social proof ticker
if($social_proof_lead):
    $sp_first = ucfirst(strtolower(explode(' ',$social_proof_lead->name)[0]));
    $sp_hours = round((time()-strtotime($social_proof_lead->created_at))/3600);
    $sp_text = $sp_first.' from '.esc_html($social_proof_lead->area).' booked this vendor '.($sp_hours<1?'recently':$sp_hours.' hours ago');
?>
<div id="gs-social-proof-ticker" style="position:fixed;bottom:70px;left:50%;transform:translateX(-50%);background:#1E293B;color:#fff;border-radius:30px;padding:8px 18px;font-size:.78rem;white-space:nowrap;z-index:998;box-shadow:0 4px 16px rgba(0,0,0,.2);animation:gs-toast-in .3s ease" aria-live="polite">
  👥 <?php echo $sp_text; ?>
  <button onclick="this.parentElement.style.display='none'" style="background:none;border:none;color:rgba(255,255,255,.6);cursor:pointer;margin-left:8px;font-size:.9rem" aria-label="Dismiss">×</button>
</div>
<script>setTimeout(function(){var el=document.getElementById('gs-social-proof-ticker');if(el)el.style.display='none';},8000);</script>
<?php endif; ?>

<?php
// Part 21.5 — Sticky CTA (mobile)
$_vp_reply_text = '';
if(!empty($vp_detail->avg_reply_minutes) && (int)$vp_detail->avg_reply_minutes > 0){
    $_arm = (int)$vp_detail->avg_reply_minutes;
    $_vp_reply_text = $_arm < 60 ? 'Replies ~'.$_arm.'m' : 'Replies ~'.round($_arm/60,1).'h';
}
?>
<div id="gs-listing-sticky-cta" style="display:none">
  <div style="flex:1;min-width:0">
    <div style="font-size:.82rem;font-weight:700;color:#1E293B;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo esc_html($listing->title);?></div>
    <?php if($review_avg>0||$_vp_reply_text):?><div style="font-size:.72rem;color:#64748B"><?php echo $review_avg>0?'★ '.number_format((float)$review_avg,1).' · ':''; echo esc_html($_vp_reply_text);?></div><?php endif;?>
  </div>
  <a href="#vs-sec-inquiry-modules" class="gs-btn gs-btn-primary gs-btn-sm">Send Inquiry</a>
</div>
<style>
@media(max-width:768px){
  #gs-listing-sticky-cta{display:flex !important;position:fixed;bottom:0;left:0;right:0;z-index:997;background:#fff;border-top:1px solid #E2E8F0;padding:10px 16px calc(10px + env(safe-area-inset-bottom,0));gap:10px;align-items:center;box-shadow:0 -4px 20px rgba(0,0,0,.08)}
}
</style>

<?php
// Part 12.3 — Verification + Certification badges
if(!empty($listing_certs)||!empty($listing_vdocs??[])):
    $bh='';
    foreach($listing_vdocs??[] as $vdoc){
        $bl=['aadhaar'=>['🪪','ID on File','#065F46','#ECFDF5'],'gst'=>['🏛','GST on File','#1D4ED8','#EFF6FF'],'trade_licence'=>['📋','Licence on File','#7C3AED','#F5F3FF'],'platform_verified'=>['⭐','GS Reviewed','#D97706','#FFFBEB']];
        $bk=$vdoc->badge_type??$vdoc->doc_type;
        if(isset($bl[$bk])){$bh.='<span style="background:'.$bl[$bk][3].';color:'.$bl[$bk][2].';border-radius:20px;padding:3px 10px;font-size:.72rem;font-weight:700;margin:2px">'.$bl[$bk][0].' '.$bl[$bk][1].'</span>';}
    }
    foreach($listing_certs??[] as $cert){
        $lc=['basic'=>'#0EA5E9','intermediate'=>'#7C3AED','advanced'=>'#D97706'][$cert->cert_level]??'#64748B';
        $bh.='<span style="background:'.$lc.'20;color:'.$lc.';border-radius:20px;padding:3px 10px;font-size:.72rem;font-weight:700;margin:2px" title="'.esc_attr($cert->course_title).' — Certified '.date('M Y',strtotime($cert->issued_at)).'">🏅 GS '.ucfirst($cert->cert_level).'</span>';
    }
    if($bh): echo '<div style="display:flex;flex-wrap:wrap;gap:6px;margin:12px 0">'.$bh.'</div>'; endif;
endif;
?>

<?php
// Moat 1 — AI Diagnosis floating widget
$_has_diag_tbl = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}gs_diagnosis_templates'");
$_diag_cat_slug = '';
if($_has_diag_tbl && !empty($listing->category_id)){
    $_dc = $wpdb->get_row($wpdb->prepare("SELECT slug FROM {$wpdb->prefix}gs_categories WHERE id=%d",$listing->category_id));
    $_dt = $_dc ? $wpdb->get_row($wpdb->prepare("SELECT id FROM {$wpdb->prefix}gs_diagnosis_templates WHERE category_slug=%s AND is_active=1",$_dc->slug)) : null;
    if($_dt){ $_diag_cat_slug = $_dc->slug; }
}
if(!empty($_diag_cat_slug)):?>
<div style="position:fixed;bottom:80px;right:20px;z-index:990">
  <button onclick="document.getElementById('gsDiagModal').style.display='flex'" style="background:linear-gradient(135deg,#2563EB,#7C3AED);color:#fff;border:none;border-radius:50px;padding:10px 18px;font-size:.82rem;font-weight:700;cursor:pointer;box-shadow:0 4px 16px rgba(37,99,235,.35)">🔍 AI Diagnosis</button>
</div>
<div id="gsDiagModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9995;align-items:flex-end;justify-content:center">
  <div style="background:#fff;width:100%;max-width:480px;border-radius:16px 16px 0 0;padding:20px;max-height:80vh;display:flex;flex-direction:column">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-shrink:0">
      <span style="font-weight:700">🔍 AI Problem Diagnosis</span>
      <button onclick="document.getElementById('gsDiagModal').style.display='none'" style="margin-left:auto;background:none;border:none;font-size:1.2rem;cursor:pointer;color:#94A3B8">✕</button>
    </div>
    <div id="gsDiagMsgs" style="flex:1;background:#F8FAFC;border-radius:8px;padding:10px;overflow-y:auto;margin-bottom:10px;font-size:.83rem;min-height:80px"></div>
    <div style="display:flex;gap:8px;flex-shrink:0">
      <input id="gsDiagInp" type="text" placeholder="Type your answer…" style="flex:1;border:1px solid #E2E8F0;border-radius:7px;padding:8px 12px;font-size:.83rem;outline:none" onkeydown="if(event.key==='Enter')gsDM()">
      <button onclick="gsDM()" id="gsDiagSBtn" style="background:#2563EB;color:#fff;border:none;border-radius:7px;padding:8px 14px;cursor:pointer">Send</button>
    </div>
    <div id="gsDiagDone" style="display:none;margin-top:10px;background:#ECFDF5;border-radius:8px;padding:12px;flex-shrink:0">
      <strong style="color:#065F46;font-size:.85rem">✓ Diagnosis Complete</strong>
      <div id="gsDiagSum" style="font-size:.82rem;margin:5px 0;color:#1E293B"></div>
      <button onclick="gsDiagConvert()" style="background:#059669;color:#fff;border:none;border-radius:7px;padding:8px 14px;font-size:.82rem;font-weight:600;cursor:pointer;margin-top:6px">Send Inquiry with Diagnosis →</button>
    </div>
  </div>
</div>
<script>
(function(){
var _n='<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>',_c='<?php echo esc_js($_diag_cat_slug); ?>',_l=<?php echo (int)$listing->id; ?>,_a='<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
var _sid=null,_done=false,_diag=null;
// Auto-start on modal open
var _started=false;
document.getElementById('gsDiagModal').addEventListener('click',function(e){if(e.target===this&&!_started){gsDS();}});
document.querySelector('[onclick*="gsDiagModal"]').addEventListener('click',function(){if(!_started)gsDS();});
function gdm(r,t){var el=document.getElementById('gsDiagMsgs');var d=document.createElement('div');d.style.cssText='margin-bottom:6px;padding:7px 9px;border-radius:6px;'+(r==='user'?'background:#EFF6FF;text-align:right;margin-left:25%':'background:#fff;border:1px solid #E2E8F0;margin-right:25%');d.textContent=t;el.appendChild(d);el.scrollTop=el.scrollHeight;}
// Real fix — a network error here previously left the modal open with an
// empty chat and no message at all, and no way to tell the diagnosis
// never started (_started stayed true, so a retry never fired either).
function gsDS(){_started=true;var fd=new FormData();fd.append('action','gs_start_diagnosis');fd.append('nonce',_n);fd.append('category',_c);fd.append('listing_id',_l);fetch(_a,{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();}).then(function(j){if(j.success){_sid=j.data.session_id;gdm('ai',j.data.opening_question);}else{_started=false;gdm('ai','Sorry, something went wrong starting the diagnosis. Please close and reopen this window to try again.');}}).catch(function(){_started=false;gdm('ai','Network error — could not start the diagnosis. Please close and reopen this window to try again.');});}
// Real fix — a network error here previously left the Send button stuck
// disabled on "…" forever, blocking the conversation with no feedback.
window.gsDM=function(){var inp=document.getElementById('gsDiagInp');var msg=inp.value.trim();if(!msg||!_sid||_done)return;gdm('user',msg);inp.value='';var btn=document.getElementById('gsDiagSBtn');btn.disabled=true;btn.textContent='…';var fd=new FormData();fd.append('action','gs_diagnosis_message');fd.append('nonce',_n);fd.append('session_id',_sid);fd.append('message',msg);fetch(_a,{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();}).then(function(j){btn.disabled=false;btn.textContent='Send';if(!j.success){gdm('ai','Sorry, something went wrong. Please try again.');return;}if(j.data.is_diagnosis){_done=true;_diag=j.data.diagnosis;inp.disabled=true;btn.style.display='none';document.getElementById('gsDiagDone').style.display='block';document.getElementById('gsDiagSum').textContent=j.data.diagnosis.summary||'';}else{gdm('ai',j.data.message);}}).catch(function(){btn.disabled=false;btn.textContent='Send';gdm('ai','Network error — your message was not sent. Please try again.');});};
window.gsDiagConvert=function(){document.getElementById('gsDiagModal').style.display='none';var summary=_diag?(_diag.summary+(_diag.vendor_instruction?'\n\nVendor note: '+_diag.vendor_instruction:'')):'';var ta=document.querySelector('textarea[name=message]');if(ta)ta.value=summary;};
})();
</script>
<?php endif; ?>
