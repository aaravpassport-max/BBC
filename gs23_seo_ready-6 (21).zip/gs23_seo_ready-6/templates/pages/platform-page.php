<?php
/**
 * GoodService — Static Platform Page Content
 * URL: /{slug}/  e.g. /about-us/, /privacy-policy/
 * Renders inside render_page()'s real <body> — title, meta description,
 * canonical tag, and structured data are added directly in Router.php's
 * own <head> output (NOT here), since this file must never include its
 * own <!DOCTYPE>/<html>/<head> wrapper — render_page() already provides
 * one. Confirmed via the real, working precedent (rwa-dashboard.php),
 * which contains no document-wrapper tags of its own either.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

global $wpdb;
$pfx       = $wpdb->prefix . 'gs_';
$page_slug = sanitize_title( $gs_static_slug ?? get_query_var( 'gs_page_slug', '' ) );

if ( ! $page_slug ) { wp_redirect( home_url( '/' ) ); exit; }

$gs_page_row = wp_cache_get( "platform_page:{$page_slug}", 'gs_pages' );
if ( $gs_page_row === false ) {
    $gs_page_row = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$pfx}pages WHERE slug = %s AND is_active = 1 LIMIT 1", $page_slug
    ) );
    wp_cache_set( "platform_page:{$page_slug}", $gs_page_row ?: 0, 'gs_pages', 600 );
}
if ( ! $gs_page_row ) { $gs_page_row = null; }

// Genuinely missing or unpublished page — real 404, not a blank screen.
// (The dispatch in Router.php sets status_header(200) before this file
// runs; this later call correctly overrides it — standard, real PHP
// header behavior: the last call before headers are sent wins.)
if ( ! $gs_page_row ) {
    status_header( 404 );
}

$platform = function_exists('gs_setting') ? gs_setting('platform_name', get_bloginfo('name')) : get_bloginfo('name');
?>
<style>
.pp-header{background:#fff;border-bottom:1px solid #F1F5F9;box-shadow:0 1px 3px rgba(0,0,0,.04);position:sticky;top:0;z-index:999}
.pp-header-inner{max-width:1100px;margin:0 auto;padding:0 20px;height:64px;display:flex;align-items:center;gap:20px}
.pp-logo{font-size:1.2rem;font-weight:500;color:#1a1a1a;text-decoration:none;flex-shrink:0}
.pp-nav{display:flex;gap:18px;margin-left:auto}
.pp-nav a{color:#475569;text-decoration:none;font-size:.88rem}
.pp-nav a:hover{color:#1a1a1a;text-decoration:underline}
.pp-breadcrumb{background:#FAFBFC;border-bottom:1px solid #F1F5F9;padding:10px 0;font-size:.82rem}
.pp-breadcrumb-inner{max-width:780px;margin:0 auto;padding:0 20px}
.pp-breadcrumb a{color:#64748B;text-decoration:none}
.pp-breadcrumb a:hover{text-decoration:underline}
.pp-wrap{max-width:780px;margin:0 auto;padding:48px 20px 80px}
.pp-title{font-size:2rem;font-weight:700;margin:0 0 28px;color:#1a1a1a;line-height:1.25}
.pp-content{font-size:1rem;line-height:1.75;color:#334155}
.pp-content h2{font-size:1.35rem;font-weight:700;color:#1a1a1a;margin:32px 0 12px}
.pp-content h3{font-size:1.1rem;font-weight:600;color:#1a1a1a;margin:24px 0 10px}
.pp-content p{margin:0 0 16px}
.pp-content ul{margin:0 0 16px;padding-left:22px}
.pp-content li{margin-bottom:8px}
.pp-content a{color:#FF6600;text-decoration:none}
.pp-content a:hover{text-decoration:underline}
.pp-404{text-align:center;padding:60px 20px}
.pp-404 h1{font-size:1.6rem;margin-bottom:12px}
.pp-404 p{color:#64748B;margin-bottom:24px}
.pp-404-btn{display:inline-block;background:#FF6600;color:#fff;padding:10px 22px;border-radius:8px;text-decoration:none;font-weight:500}
/* Footer — copied precisely from archive.php's real, working footer CSS,
   since render_page() does not share a CSS file across templates; each
   real page template owns its own complete styles. Confirmed real,
   missing piece causing the footer to render as unstyled, raw HTML. */
.gd4-footer{background:#0a1628;color:rgba(255,255,255,.6)!important;padding:52px 0 0;margin-top:32px}
.gd4-footer *{color:inherit}
.gd4-footer-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:36px;margin-bottom:40px;max-width:1220px;margin-left:auto;margin-right:auto;padding:0 16px}
.gd4-footer-brand{font-size:18px;font-weight:900;color:#fff!important;margin-bottom:12px;display:block;text-decoration:none}
.gd4-footer-brand img{height:36px;border-radius:7px;margin-bottom:10px;display:block}
.gd4-footer-about{font-size:13px;line-height:1.8;color:rgba(255,255,255,.55)!important;max-width:240px}
.gd4-footer-social{display:flex;gap:8px;margin-top:16px}
.gd4-footer-social a{width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.07);display:flex;align-items:center;justify-content:center;font-size:13px;transition:background .15s;text-decoration:none}
.gd4-footer-social a:hover{background:#FF6600}
.gd4-footer-col-title{font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#fff!important;margin-bottom:14px}
.gd4-footer-links{display:flex;flex-direction:column;gap:9px}
.gd4-footer-links a{font-size:13px;color:rgba(255,255,255,.5)!important;text-decoration:none;transition:color .15s}
.gd4-footer-links a:hover{color:#FF6600!important}
.gd4-footer-bottom{border-top:1px solid rgba(255,255,255,.07);padding:18px 16px calc(18px + env(safe-area-inset-bottom,0));display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;max-width:1220px;margin:0 auto}
.gd4-footer-copy{font-size:12px;color:rgba(255,255,255,.45)!important}
.gd4-footer-copy strong{color:rgba(255,255,255,.7)!important}
.gd4-footer-bot-links{display:flex;gap:16px}
.gd4-footer-bot-links a{font-size:12px;color:rgba(255,255,255,.45)!important;text-decoration:none;transition:color .15s}
.gd4-footer-bot-links a:hover{color:rgba(255,255,255,.8)!important}
</style>

<header class="pp-header">
  <div class="pp-header-inner">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="pp-logo"><?php echo esc_html( $platform ); ?></a>
    <nav class="pp-nav">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
      <a href="<?php echo esc_url( home_url( '/directory/' ) ); ?>">Directory</a>
      <a href="<?php echo esc_url( home_url( '/vendor/dashboard/' ) ); ?>">Dashboard</a>
    </nav>
  </div>
</header>

<?php if ( $gs_page_row ): ?>
<nav class="pp-breadcrumb" aria-label="Breadcrumb">
  <div class="pp-breadcrumb-inner">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
    <span aria-hidden="true"> › </span>
    <span aria-current="page"><?php echo esc_html( $gs_page_row->title ); ?></span>
  </div>
</nav>

<div class="pp-wrap">
  <h1 class="pp-title"><?php echo esc_html( $gs_page_row->title ); ?></h1>
  <div class="pp-content"><?php echo wp_kses_post( $gs_page_row->content ); ?></div>
</div>
<?php else: ?>
<div class="pp-wrap">
  <div class="pp-404">
    <h1>Page not found</h1>
    <p>The page you're looking for doesn't exist or may have been moved.</p>
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="pp-404-btn">Back to homepage</a>
  </div>
</div>
<?php endif; ?>

<?php
/* Footer — exact same real markup already established across
   archive.php / vendor-site.php / create-listing.php / etc., copied
   precisely (not approximated) for genuine visual consistency. */
$df_site   = function_exists('gs_setting') ? gs_setting('platform_name', get_bloginfo('name')) : get_bloginfo('name');
$df_logo   = function_exists('gs_setting') ? gs_setting('logo_url','')  : '';
$df_phone  = function_exists('gs_setting') ? gs_setting('platform_phone','') : '';
$df_email  = function_exists('gs_setting') ? gs_setting('platform_email','') : '';
$df_addr   = function_exists('gs_setting') ? gs_setting('platform_address','') : '';
$df_home   = home_url('/');
$df_dir    = home_url('/directory/');
$df_reg    = home_url('/vendor/register/');
$df_login  = home_url('/vendor/login/');

$df_cats = wp_cache_get( 'gsd_all_cats', 'gs_directory' );
if ( $df_cats === false ) {
    $df_cats = $wpdb->get_results(
        "SELECT c.id, c.name, COUNT(l.id) AS n FROM {$pfx}categories c
         LEFT JOIN {$pfx}listings l ON l.category_id=c.id AND l.status='active'
         WHERE c.is_active=1 AND c.parent_id=0 GROUP BY c.id ORDER BY n DESC"
    ) ?: [];
    wp_cache_set( 'gsd_all_cats', $df_cats, 'gs_directory', 600 );
}
?>
<footer class="gd4-footer" style="background:#0a1628;color:rgba(255,255,255,.6)">
  <div class="gd4-footer-grid">
    <div>
      <?php if($df_logo): ?>
        <img src="<?php echo esc_url($df_logo); ?>" alt="<?php echo esc_attr($df_site); ?>" class="gd4-footer-brand">
      <?php else: ?>
        <a href="<?php echo esc_url($df_home); ?>" class="gd4-footer-brand"><?php echo esc_html($df_site); ?></a>
      <?php endif; ?>
      <p class="gd4-footer-about">Your trusted platform for finding verified professional service providers across India.</p>
      <div class="gd4-footer-social">
        <?php $fb = function_exists('gs_setting') ? gs_setting('platform_facebook','') : ''; if ($fb): ?><a href="<?php echo esc_url($fb); ?>" title="Facebook" target="_blank" rel="noopener">📘</a><?php endif; ?>
        <?php $ig = function_exists('gs_setting') ? gs_setting('platform_instagram','') : ''; if ($ig): ?><a href="<?php echo esc_url($ig); ?>" title="Instagram" target="_blank" rel="noopener">📸</a><?php endif; ?>
        <?php $tw = function_exists('gs_setting') ? gs_setting('platform_twitter','') : ''; if ($tw): ?><a href="<?php echo esc_url($tw); ?>" title="Twitter" target="_blank" rel="noopener">🐦</a><?php endif; ?>
        <?php $li = function_exists('gs_setting') ? gs_setting('platform_linkedin','') : ''; if ($li): ?><a href="<?php echo esc_url($li); ?>" title="LinkedIn" target="_blank" rel="noopener">💼</a><?php endif; ?>
      </div>
      <div style="margin-top:14px;display:flex;flex-direction:column;gap:6px">
        <?php if($df_phone): ?><span style="font-size:12px;color:rgba(255,255,255,.45)">📞 <?php echo esc_html($df_phone); ?></span><?php endif; ?>
        <?php if($df_email): ?><span style="font-size:12px;color:rgba(255,255,255,.45)">📧 <?php echo esc_html($df_email); ?></span><?php endif; ?>
        <?php if($df_addr):  ?><span style="font-size:12px;color:rgba(255,255,255,.45)">📍 <?php echo esc_html($df_addr);  ?></span><?php endif; ?>
      </div>
    </div>
    <div>
      <div class="gd4-footer-col-title">Quick Links</div>
      <div class="gd4-footer-links">
        <a href="<?php echo esc_url($df_home); ?>" style="color:rgba(255,255,255,.5)">Home</a>
        <a href="<?php echo esc_url($df_dir); ?>" style="color:rgba(255,255,255,.5)">Browse Directory</a>
        <a href="<?php echo esc_url($df_reg); ?>" style="color:rgba(255,255,255,.5)">List Your Business</a>
        <a href="<?php echo esc_url($df_login); ?>" style="color:rgba(255,255,255,.5)">Vendor Login</a>
        <a href="<?php echo esc_url(home_url('/about-us/')); ?>" style="color:rgba(255,255,255,.5)">About Us</a>
        <a href="<?php echo esc_url(home_url('/contact-us/')); ?>" style="color:rgba(255,255,255,.5)">Contact Us</a>
        <a href="<?php echo esc_url(home_url('/blog/')); ?>" style="color:rgba(255,255,255,.5)">Blog</a>
      </div>
    </div>
    <div>
      <div class="gd4-footer-col-title">Categories</div>
      <div class="gd4-footer-links">
        <?php foreach(array_slice((array)$df_cats,0,7) as $c): ?>
          <a href="<?php echo esc_url(add_query_arg(['category_id'=>$c->id],$df_dir)); ?>" style="color:rgba(255,255,255,.5)"><?php echo esc_html($c->name); ?></a>
        <?php endforeach; ?>
        <a href="<?php echo esc_url($df_dir); ?>" style="color:rgba(255,255,255,.5)">View All →</a>
      </div>
    </div>
    <div>
      <div class="gd4-footer-col-title">Legal & Info</div>
      <div class="gd4-footer-links">
        <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>" style="color:rgba(255,255,255,.5)">Privacy Policy</a>
        <a href="<?php echo esc_url(home_url('/terms-of-service/')); ?>" style="color:rgba(255,255,255,.5)">Terms of Service</a>
        <a href="<?php echo esc_url(home_url('/cookie-policy/')); ?>" style="color:rgba(255,255,255,.5)">Cookie Policy</a>
        <a href="<?php echo esc_url(home_url('/refund-policy/')); ?>" style="color:rgba(255,255,255,.5)">Refund Policy</a>
        <a href="<?php echo esc_url(home_url('/disclaimer/')); ?>" style="color:rgba(255,255,255,.5)">Disclaimer</a>
        <a href="<?php echo esc_url(home_url('/sitemap/')); ?>" style="color:rgba(255,255,255,.5)">Sitemap</a>
      </div>
    </div>
  </div>
  <div class="gd4-footer-bottom" style="border-top:1px solid rgba(255,255,255,.06);padding:16px;text-align:center;font-size:12px;color:rgba(255,255,255,.4)">
    © <?php echo esc_html( gmdate('Y') ); ?> <?php echo esc_html($df_site); ?>. All rights reserved.
  </div>
</footer>
