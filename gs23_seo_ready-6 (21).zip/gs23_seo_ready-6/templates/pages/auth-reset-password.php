<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( is_user_logged_in() ) {
    wp_redirect( function_exists('gs_login_redirect') ? gs_login_redirect() : home_url('/vendor/dashboard/') );
    exit;
}
$platform = gs_setting('platform_name', 'GoodService');
$color    = gs_setting('platform_color_primary', '#2563EB');
$logo_url = gs_setting('logo_url', '');
$ajax_url = admin_url('admin-ajax.php');
$nonce    = wp_create_nonce('gs_ajax');

// $key and $login are passed raw (sanitize_text_field only) from AuthController::reset_password()
// They are already validated there — but we validate again here as defence-in-depth.
// IMPORTANT: keep raw values for check_password_reset_key(); only esc_* when outputting.
$key_raw   = $key   ?? sanitize_text_field( $_GET['key']   ?? '' );
$login_raw = $login ?? sanitize_text_field( $_GET['login'] ?? '' );

// Validate key before rendering — redirect if invalid/expired
if ( $key_raw && $login_raw ) {
    $check = check_password_reset_key( $key_raw, $login_raw );
    if ( is_wp_error( $check ) ) {
        wp_redirect( home_url('/forgot-password/?error=invalid_link') );
        exit;
    }
}
?>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:linear-gradient(135deg,#F0F9FF,#EFF6FF);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.gsrp-wrap{width:100%;max-width:420px}
.gsrp-logo{text-align:center;margin-bottom:28px}
.gsrp-logo img{height:50px;margin:0 auto 12px;display:block;border-radius:8px}
.gsrp-logo h1{font-size:1.4rem;font-weight:800;color:#1E3A5F;margin:0}
.gsrp-logo p{color:#64748B;margin:5px 0 0;font-size:.85rem}
.gsrp-card{background:#fff;border-radius:18px;box-shadow:0 10px 40px rgba(0,0,0,.1);padding:36px 32px}
.gsrp-icon{width:64px;height:64px;border-radius:16px;background:#F0FDF4;display:flex;align-items:center;justify-content:center;font-size:1.8rem;margin:0 auto 20px}
.gsrp-title{font-size:1.2rem;font-weight:700;color:#1E3A5F;text-align:center;margin-bottom:8px}
.gsrp-sub{font-size:.85rem;color:#64748B;text-align:center;margin-bottom:24px;line-height:1.6}
.gsrp-err,.gsrp-ok{display:none;padding:12px 14px;border-radius:8px;font-size:.84rem;margin-bottom:16px;border-left:4px solid}
.gsrp-err{background:#FEF2F2;color:#DC2626;border-color:#DC2626}
.gsrp-ok{background:#F0FDF4;color:#059669;border-color:#059669}
.gsrp-label{display:block;font-size:.8rem;font-weight:600;color:#475569;margin-bottom:6px}
.gsrp-field{position:relative;margin-bottom:16px}
.gsrp-input{display:block;width:100%;padding:12px 14px;border:1.5px solid #E2E8F0;border-radius:9px;font-size:.92rem;color:#1E293B;background:#fff;outline:none;transition:border-color .18s,box-shadow .18s;font-family:inherit;padding-right:44px}
.gsrp-input:focus{border-color:<?php echo esc_attr($color); ?>;box-shadow:0 0 0 3px <?php echo esc_attr($color); ?>22}
.gsrp-toggle{position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:1rem;color:#94A3B8;padding:2px}
.gsrp-strength{height:4px;background:#E2E8F0;border-radius:2px;margin-top:7px;overflow:hidden}
.gsrp-strength-bar{height:100%;width:0%;border-radius:2px;transition:width .3s,background .3s}
.gsrp-rules{background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:12px 14px;margin-bottom:18px;font-size:.8rem;color:#475569}
.gsrp-rules ul{padding-left:16px}
.gsrp-rules li{line-height:1.7}
.gsrp-btn{display:block;width:100%;padding:13px;border:none;border-radius:10px;font-size:.95rem;font-weight:700;cursor:pointer;font-family:inherit;transition:all .18s;text-align:center;background:<?php echo esc_attr($color); ?>;color:#fff;margin-top:8px}
.gsrp-btn:hover{filter:brightness(1.08)}
.gsrp-btn:disabled{opacity:.6;cursor:not-allowed}
.gsrp-back{text-align:center;margin-top:20px;font-size:.82rem}
.gsrp-back a{color:#64748B;text-decoration:none}
.gsrp-back a:hover{color:<?php echo esc_attr($color); ?>}
</style>

<div class="gsrp-wrap">
  <div class="gsrp-logo">
    <?php if($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($platform); ?>"><?php endif; ?>
    <h1><?php echo esc_html($platform); ?></h1>
    <p>Set New Password</p>
  </div>

  <div class="gsrp-card">
    <div class="gsrp-icon">🔐</div>
    <div class="gsrp-title">Create new password</div>
    <div class="gsrp-sub">Choose a strong password. You will be logged in automatically after resetting.</div>

    <div id="rp-err" class="gsrp-err"></div>
    <div id="rp-ok"  class="gsrp-ok"></div>

    <div class="gsrp-field">
      <label class="gsrp-label" for="rp-pass">New Password</label>
      <input type="password" id="rp-pass" class="gsrp-input"
        placeholder="Min 8 characters" autocomplete="new-password"
        oninput="rpStrength(this.value)">
      <button class="gsrp-toggle" onclick="rpToggle('rp-pass')" type="button" aria-label="Show/hide password" tabindex="-1">👁</button>
      <div class="gsrp-strength"><div class="gsrp-strength-bar" id="rp-bar"></div></div>
    </div>

    <div class="gsrp-field">
      <label class="gsrp-label" for="rp-confirm">Confirm New Password</label>
      <input type="password" id="rp-confirm" class="gsrp-input"
        placeholder="Repeat your password" autocomplete="new-password">
      <button class="gsrp-toggle" onclick="rpToggle('rp-confirm')" type="button" aria-label="Show/hide password" tabindex="-1">👁</button>
    </div>

    <div class="gsrp-rules">
      <strong>Password requirements:</strong>
      <ul>
        <li>At least 8 characters long</li>
        <li>Mix of letters and numbers recommended</li>
        <li>Avoid common words or sequences</li>
      </ul>
    </div>

    <button class="gsrp-btn" id="rp-btn" onclick="rpSubmit()">Set New Password &amp; Login</button>
  </div>

  <div class="gsrp-back"><a href="<?php echo esc_url(home_url('/vendor/login/')); ?>">← Back to Login</a></div>
</div>

<script>
var GS_AJAX  = '<?php echo esc_js($ajax_url); ?>';
var GS_NONCE = '<?php echo esc_js($nonce); ?>';
// Raw key and login — never HTML-escaped so they match what WP stored
var RP_KEY   = '<?php echo esc_js($key_raw); ?>';
var RP_LOGIN = '<?php echo esc_js($login_raw); ?>';

function rpToggle(id) {
  var el = document.getElementById(id);
  el.type = el.type === 'password' ? 'text' : 'password';
}

function rpStrength(val) {
  var s = 0;
  if (val.length >= 8)          s++;
  if (val.length >= 12)         s++;
  if (/[A-Z]/.test(val))        s++;
  if (/[0-9]/.test(val))        s++;
  if (/[^A-Za-z0-9]/.test(val)) s++;
  var cols = ['#DC2626','#F59E0B','#F59E0B','#059669','#059669'];
  var bar  = document.getElementById('rp-bar');
  bar.style.width      = (s / 5 * 100) + '%';
  bar.style.background = cols[s - 1] || '#E2E8F0';
}

function rpErr(msg) {
  var el = document.getElementById('rp-err');
  el.textContent = msg; el.style.display = 'block';
  document.getElementById('rp-ok').style.display = 'none';
}

function rpSubmit() {
  document.getElementById('rp-err').style.display = 'none';
  document.getElementById('rp-ok').style.display  = 'none';

  var pass    = document.getElementById('rp-pass').value;
  var confirm = document.getElementById('rp-confirm').value;

  if (!pass)           { rpErr('Please enter a new password.'); return; }
  if (pass.length < 8) { rpErr('Password must be at least 8 characters long.'); return; }
  if (pass !== confirm) { rpErr('Passwords do not match. Please re-enter.'); return; }

  var btn = document.getElementById('rp-btn');
  btn.disabled = true; btn.textContent = 'Setting password\u2026';

  var fd = new FormData();
  fd.append('action',   'gs_reset_password');
  fd.append('nonce',    GS_NONCE);
  fd.append('key',      RP_KEY);
  fd.append('login',    RP_LOGIN);
  fd.append('password', pass);
  fd.append('confirm',  confirm);

  fetch(GS_AJAX, { method:'POST', body:fd, credentials:'same-origin' })
    .then(function(r){ return r.json(); })
    .then(function(r){
      btn.disabled = false; btn.textContent = 'Set New Password & Login';
      if (r.success) {
        var ok = document.getElementById('rp-ok');
        ok.textContent = '\u2713 ' + (r.data && r.data.message ? r.data.message : 'Password reset! Redirecting\u2026');
        ok.style.display = 'block';
        btn.style.display = 'none';
        setTimeout(function(){
          window.location.href = (r.data && r.data.redirect)
            ? r.data.redirect
            : '<?php echo esc_js(home_url('/vendor/dashboard/')); ?>';
        }, 1000);
      } else {
        rpErr((r.data && r.data.message)
          ? r.data.message
          : 'Reset failed. The link may have expired. Please request a new one.');
      }
    })
    .catch(function(){
      btn.disabled = false; btn.textContent = 'Set New Password & Login';
      rpErr('Connection error. Please try again.');
    });
}

document.getElementById('rp-confirm').addEventListener('keydown', function(e){
  if (e.key === 'Enter') rpSubmit();
});
document.getElementById('rp-pass').addEventListener('keydown', function(e){
  if (e.key === 'Enter') document.getElementById('rp-confirm').focus();
});
</script>
