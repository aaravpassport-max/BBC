<?php
/**
 * GoodService — "Advertise With Us" / Grow Your Business landing page.
 * URL: /advertise/
 * Real feature — a vendor-acquisition marketing page, built the same
 * way create-listing.php's SEO score panel insists everything else on
 * this platform is: every number shown is a real, live query against
 * this platform's own data, not a fabricated stat. Pricing shown is
 * this platform's own actual subscription_plans table, not invented
 * figures. Testimonials are real, approved reviews already in the
 * database — none are written for this page.
 *
 * Deliberately does NOT include its own <!DOCTYPE>/<html>/<head> —
 * render_page() already provides that wrapper, matching the same
 * documented precedent already established in platform-page.php.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

global $wpdb;
$pfx = $wpdb->prefix . 'gs_';

// ── Real, live platform stats — no fabricated numbers ──────────────────────
$total_vendors  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE is_active = 1" );
$total_listings = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}listings WHERE status = 'active'" );
$total_reviews  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}reviews WHERE status = 'approved'" );
$avg_rating     = (float) ( $wpdb->get_var( "SELECT AVG(rating) FROM {$pfx}reviews WHERE status = 'approved'" ) ?: 0 );

// ── Real subscription plans — this platform's own actual pricing ──────────
$plans = $wpdb->get_results(
    "SELECT * FROM {$pfx}subscription_plans WHERE is_active = 1 ORDER BY sort_order ASC, price_monthly ASC"
);

// ── Real, approved reviews with the highest ratings — genuine testimonials,
//    not written for this page. Only ones with real reviewer names and
//    real, non-empty text are eligible. ──────────────────────────────────
$testimonials = $wpdb->get_results(
    "SELECT r.reviewer_name, r.rating, r.review_text, l.title AS business_name, l.slug
     FROM {$pfx}reviews r
     LEFT JOIN {$pfx}listings l ON l.id = r.listing_id
     WHERE r.status = 'approved' AND r.rating >= 4
       AND r.reviewer_name IS NOT NULL AND r.reviewer_name != ''
       AND r.review_text IS NOT NULL AND CHAR_LENGTH(r.review_text) > 40
     ORDER BY r.rating DESC, r.created_at DESC
     LIMIT 3"
);

$platform    = function_exists('gs_setting') ? gs_setting('platform_name', get_bloginfo('name')) : get_bloginfo('name');
$color       = function_exists('gs_setting') ? gs_setting('platform_color_primary', '#2563EB') : '#2563EB';
$logo_url    = function_exists('gs_setting') ? gs_setting('logo_url', '') : '';
$register_url = home_url('/vendor/register/');
$login_url    = home_url('/vendor/login/');
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Inter:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@500;600&display=swap');
*,*::before,*::after{box-sizing:border-box}
.aw-body{font-family:'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#14162B;background:#FBFAF7}
.aw-mono{font-family:'IBM Plex Mono',monospace}
.aw-wrap{max-width:1180px;margin:0 auto;padding:0 24px}
.aw-header{background:#FBFAF7;border-bottom:1px solid rgba(20,22,43,.08);position:sticky;top:0;z-index:50}
.aw-header-inner{display:flex;align-items:center;justify-content:space-between;padding:14px 0}
.aw-logo{display:flex;align-items:center;gap:10px;text-decoration:none;color:#14162B;font-weight:800;font-size:1.1rem;font-family:'Fraunces',serif}
.aw-logo img{height:32px}
.aw-header-links{display:flex;gap:24px;align-items:center;font-size:.88rem}
.aw-header-links a{color:#4B4D63;text-decoration:none;font-weight:600}
.aw-header-cta{background:#14162B;color:#FBFAF7!important;padding:9px 20px;border-radius:8px;font-weight:700!important;transition:background .18s}
.aw-header-cta:hover{background:#FF6B35}

.aw-hero{background:#FBFAF7;padding:72px 0 88px;overflow:hidden;position:relative}
.aw-hero::before{content:'';position:absolute;top:-120px;right:-120px;width:420px;height:420px;border-radius:50%;background:radial-gradient(circle,rgba(255,107,53,.10),transparent 70%);pointer-events:none}
.aw-hero-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:56px;align-items:center;position:relative;z-index:1}
@media(max-width:900px){.aw-hero-grid{grid-template-columns:1fr;text-align:center}}

.aw-hero-eyebrow{display:inline-flex;align-items:center;gap:8px;color:#14162B;font-family:'IBM Plex Mono',monospace;font-weight:600;font-size:.72rem;text-transform:uppercase;letter-spacing:.14em;margin-bottom:22px;padding:6px 14px 6px 10px;border:1px solid rgba(20,22,43,.14);border-radius:99px}
.aw-hero-eyebrow::before{content:'';width:7px;height:7px;border-radius:50%;background:#0F9D58;box-shadow:0 0 0 3px rgba(15,157,88,.18)}

.aw-hero h1{font-family:'Fraunces',serif;font-weight:600;font-size:3.6rem;line-height:1.03;letter-spacing:-.015em;margin-bottom:22px;color:#14162B}
@media(max-width:900px){.aw-hero h1{font-size:2.5rem}}
.aw-hero h1 .aw-stamp-word{position:relative;display:inline-block;font-style:italic;color:#FF6B35}
.aw-hero h1 .aw-stamp-word::after{
  content:'';position:absolute;left:50%;top:50%;width:180%;height:230%;transform:translate(-50%,-50%) rotate(-6deg);
  border:1.5px solid rgba(255,107,53,.4);border-radius:50%;pointer-events:none;
}
@media(max-width:900px){.aw-hero h1 .aw-stamp-word::after{display:none}}

.aw-hero p{font-size:1.1rem;line-height:1.65;color:#4B4D63;margin-bottom:34px;max-width:460px}
@media(max-width:900px){.aw-hero p{margin-left:auto;margin-right:auto}}

.aw-hero-actions{display:flex;align-items:center;gap:22px;margin-bottom:48px;flex-wrap:wrap}
@media(max-width:900px){.aw-hero-actions{justify-content:center}}
.aw-hero-cta{position:relative;display:inline-flex;align-items:center;gap:10px;background:#14162B;color:#FBFAF7;text-decoration:none;font-weight:700;font-size:1rem;padding:17px 30px;border-radius:10px;transition:transform .18s,box-shadow .18s;box-shadow:0 1px 0 rgba(0,0,0,.05)}
.aw-hero-cta:hover{transform:translateY(-2px);box-shadow:0 10px 24px rgba(20,22,43,.22)}
.aw-hero-cta:focus-visible{outline:2.5px solid #FF6B35;outline-offset:4px}
.aw-hero-cta::after{content:'';position:absolute;inset:0;border-radius:10px;background:#FF6B35;z-index:-1;transform:translate(5px,5px);transition:transform .18s}
.aw-hero-cta:hover::after{transform:translate(7px,7px)}
.aw-hero-secondary{font-size:.9rem;font-weight:600;color:#14162B;text-decoration:underline;text-decoration-color:rgba(20,22,43,.25);text-underline-offset:4px}
.aw-hero-secondary:focus-visible{outline:2px solid #FF6B35;outline-offset:3px;border-radius:2px}

@media(prefers-reduced-motion:reduce){
  .aw-lead-card{animation:none!important}
}

.aw-hero-stats{display:flex;gap:0;border-top:1px solid rgba(20,22,43,.1)}
@media(max-width:900px){.aw-hero-stats{justify-content:center;flex-wrap:wrap}}
.aw-hero-stats>div{padding:18px 28px 0 0;margin-right:28px;border-right:1px solid rgba(20,22,43,.1)}
.aw-hero-stats>div:last-child{border-right:none;margin-right:0}
@media(max-width:520px){.aw-hero-stats>div{padding-right:0;margin-right:18px;border-right:none}}
.aw-hero-stat-num{font-family:'IBM Plex Mono',monospace;font-weight:600;font-size:1.5rem;color:#14162B}
.aw-hero-stat-lbl{font-size:.74rem;color:#7A7C8E;font-weight:500;margin-top:2px}

/* ── Signature element: live lead cascade ──────────────────────────── */
.aw-cascade{position:relative;height:440px}
@media(max-width:900px){.aw-cascade{height:auto;display:flex;flex-direction:column;gap:14px;margin-top:8px}}
.aw-lead-card{
  position:absolute;left:0;width:100%;max-width:340px;background:#fff;border-radius:14px;
  padding:16px 18px;box-shadow:0 1px 2px rgba(20,22,43,.04),0 12px 28px rgba(20,22,43,.09);
  display:flex;align-items:flex-start;gap:12px;border:1px solid rgba(20,22,43,.06);
  animation:aw-drift 7s ease-in-out infinite;
}
@media(max-width:900px){.aw-lead-card{position:static;max-width:none;margin:0 auto;transform:none!important;animation:none}}
.aw-lead-card:nth-child(1){top:0;left:6%;animation-delay:0s}
.aw-lead-card:nth-child(2){top:130px;left:22%;animation-delay:1.4s;box-shadow:0 4px 16px rgba(20,22,43,.14)}
.aw-lead-card:nth-child(3){top:260px;left:2%;animation-delay:2.8s}
@keyframes aw-drift{0%,100%{transform:translateY(0)}50%{transform:translateY(-9px)}}
.aw-lead-icon{width:38px;height:38px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.15rem;flex-shrink:0}
.aw-lead-body{min-width:0}
.aw-lead-title{font-size:.85rem;font-weight:700;color:#14162B;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.aw-lead-meta{font-family:'IBM Plex Mono',monospace;font-size:.68rem;color:#8B8D9E}
.aw-lead-badge{margin-left:auto;flex-shrink:0;background:rgba(15,157,88,.1);color:#0F9D58;font-size:.65rem;font-weight:700;padding:3px 8px;border-radius:99px;white-space:nowrap}

.aw-cascade-seal{
  position:absolute;bottom:6px;right:-10px;width:118px;height:118px;border-radius:50%;
  background:#14162B;color:#FBFAF7;display:flex;align-items:center;justify-content:center;
  font-family:'IBM Plex Mono',monospace;font-size:.62rem;font-weight:600;text-align:center;
  letter-spacing:.05em;line-height:1.5;padding:10px;box-shadow:0 10px 26px rgba(20,22,43,.28);
  transform:rotate(-8deg);
}
@media(max-width:900px){.aw-cascade-seal{display:none}}

.aw-section{padding:64px 0}
.aw-section-alt{background:#F4F2EC}
.aw-eyebrow-label{display:inline-flex;align-items:center;gap:8px;font-family:'IBM Plex Mono',monospace;font-weight:600;font-size:.7rem;text-transform:uppercase;letter-spacing:.14em;color:#8B8D9E;margin-bottom:14px}
.aw-eyebrow-label::before{content:'';width:18px;height:1.5px;background:#FF6B35}
.aw-section-title{font-family:'Fraunces',serif;font-weight:600;font-size:2.15rem;letter-spacing:-.01em;text-align:center;margin-bottom:12px;color:#14162B}
.aw-section-sub{text-align:center;color:#6B6D80;font-size:1.02rem;margin-bottom:56px;max-width:520px;margin-left:auto;margin-right:auto}
.aw-section-head{text-align:center}
.aw-section-head .aw-eyebrow-label{justify-content:center}
.aw-section-head .aw-eyebrow-label::before{display:none}

/* ── Benefits: editorial numbered list, not a generic icon grid ─────── */
.aw-benefits-list{max-width:880px;margin:0 auto;border-top:1px solid rgba(20,22,43,.1)}
.aw-benefit-row{display:grid;grid-template-columns:64px 1fr 1.4fr;gap:28px;align-items:start;padding:30px 0;border-bottom:1px solid rgba(20,22,43,.1)}
@media(max-width:700px){.aw-benefit-row{grid-template-columns:44px 1fr;}.aw-benefit-row>div:last-child{grid-column:1/-1}}
.aw-benefit-num{font-family:'IBM Plex Mono',monospace;font-size:.85rem;color:#FF6B35;font-weight:600;padding-top:4px}
.aw-benefit-row h3{font-family:'Fraunces',serif;font-weight:600;font-size:1.25rem;color:#14162B;letter-spacing:-.005em}
.aw-benefit-row p{font-size:.92rem;color:#6B6D80;line-height:1.65;margin:0}

/* ── Plans ────────────────────────────────────────────────────────── */
.aw-plans-grid{display:grid;grid-template-columns:repeat(<?php echo min(4, max(1,count($plans))); ?>,1fr);gap:20px}
@media(max-width:900px){.aw-plans-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:560px){.aw-plans-grid{grid-template-columns:1fr}}
.aw-plan-card{background:#fff;border:1.5px solid rgba(20,22,43,.12);border-radius:14px;padding:30px 24px;position:relative;transition:box-shadow .2s,transform .2s}
.aw-plan-card:hover{box-shadow:0 16px 36px rgba(20,22,43,.1);transform:translateY(-4px)}
.aw-plan-card.popular{border-color:#14162B;box-shadow:0 10px 30px rgba(20,22,43,.12)}
.aw-plan-badge{position:absolute;top:-14px;left:50%;transform:translateX(-50%);background:#FF6B35;color:#fff;font-family:'IBM Plex Mono',monospace;font-size:.62rem;font-weight:600;text-transform:uppercase;letter-spacing:.08em;padding:6px 14px;border-radius:99px;white-space:nowrap}
.aw-plan-name{font-family:'Fraunces',serif;font-weight:600;font-size:1.25rem;margin-bottom:10px;color:#14162B}
.aw-plan-price{font-family:'IBM Plex Mono',monospace;font-size:1.9rem;font-weight:600;color:#14162B;margin-bottom:2px}
.aw-plan-price span{font-size:.78rem;font-weight:500;color:#9496A6;font-family:'Inter',sans-serif}
.aw-plan-features{list-style:none;margin:22px 0;padding:18px 0 0;border-top:1px solid rgba(20,22,43,.08);display:flex;flex-direction:column;gap:11px}
.aw-plan-features li{font-size:.85rem;color:#4B4D63;display:flex;align-items:flex-start;gap:9px}
.aw-plan-features li::before{content:"—";color:#FF6B35;font-weight:700;flex-shrink:0;font-family:'IBM Plex Mono',monospace}
.aw-plan-cta{display:block;text-align:center;background:#F4F2EC;color:#14162B;text-decoration:none;font-weight:700;font-size:.88rem;padding:13px;border-radius:8px;transition:background .18s}
.aw-plan-card.popular .aw-plan-cta{background:#14162B;color:#FBFAF7}
.aw-plan-cta:hover{filter:brightness(.96)}

/* ── Testimonials: large pull-quote, not generic cards ───────────────── */
.aw-test-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1px;background:rgba(20,22,43,.1);border:1px solid rgba(20,22,43,.1);border-radius:14px;overflow:hidden}
@media(max-width:860px){.aw-test-grid{grid-template-columns:1fr}}
.aw-test-card{background:#fff;padding:32px 28px}
.aw-test-mark{font-family:'Fraunces',serif;font-size:2.6rem;color:#FF6B35;line-height:.4;height:.5em;display:block;margin-bottom:14px}
.aw-test-stars{color:#E8B54A;font-size:.82rem;margin-bottom:14px;letter-spacing:.05em}
.aw-test-text{font-family:'Fraunces',serif;font-size:1.05rem;font-style:italic;color:#14162B;line-height:1.55;margin-bottom:22px}
.aw-test-name{font-weight:700;font-size:.85rem;color:#14162B}
.aw-test-biz{font-family:'IBM Plex Mono',monospace;font-size:.72rem;color:#9496A6;margin-top:2px}

/* ── FAQ: numbering genuinely justified — a real numbered question list ── */
.aw-faq-list{max-width:760px;margin:0 auto;border-top:1px solid rgba(20,22,43,.1)}
.aw-faq-row{display:grid;grid-template-columns:44px 1fr;gap:20px;padding:24px 0;border-bottom:1px solid rgba(20,22,43,.1)}
.aw-faq-num{font-family:'IBM Plex Mono',monospace;font-size:.8rem;color:#9496A6;padding-top:2px}
.aw-faq-row h3{font-family:'Fraunces',serif;font-weight:600;font-size:1.05rem;color:#14162B;margin:0 0 8px}
.aw-faq-row p{font-size:.88rem;color:#6B6D80;line-height:1.65;margin:0}

/* ── CTA band ─────────────────────────────────────────────────────── */
.aw-cta-band{background:#14162B;padding:72px 0;text-align:center;position:relative;overflow:hidden}
.aw-cta-band::before{content:'';position:absolute;top:50%;left:50%;width:640px;height:640px;transform:translate(-50%,-50%);border-radius:50%;background:radial-gradient(circle,rgba(255,107,53,.14),transparent 70%);pointer-events:none}
.aw-cta-band-inner{position:relative;z-index:1}
.aw-cta-band h2{font-family:'Fraunces',serif;font-weight:600;color:#FBFAF7;font-size:2.1rem;letter-spacing:-.01em;margin-bottom:14px}
.aw-cta-band p{font-family:'IBM Plex Mono',monospace;color:rgba(251,250,247,.6);font-size:.82rem;margin-bottom:32px}
.aw-cta-band-btn{display:inline-block;background:#FF6B35;color:#14162B;text-decoration:none;font-weight:700;padding:16px 34px;border-radius:10px;transition:transform .18s}
.aw-cta-band-btn:hover{transform:translateY(-2px)}
.aw-cta-band-btn:focus-visible{outline:2.5px solid #FBFAF7;outline-offset:4px}
</style>

<div class="aw-body">
  <header class="aw-header">
    <div class="aw-wrap aw-header-inner">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="aw-logo">
        <?php if ($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($platform); ?>"><?php else: echo esc_html($platform); endif; ?>
      </a>
      <nav class="aw-header-links">
        <a href="#benefits">Benefits</a>
        <a href="#plans">Plans</a>
        <a href="#faq">FAQ</a>
        <a href="<?php echo esc_url($login_url); ?>">Vendor Login</a>
        <a href="<?php echo esc_url($register_url); ?>" class="aw-header-cta">Get Started →</a>
      </nav>
    </div>
  </header>

  <section class="aw-hero">
    <div class="aw-wrap aw-hero-grid">
      <div>
        <div class="aw-hero-eyebrow">Now accepting new businesses</div>
        <h1>Get discovered by customers who are <span class="aw-stamp-word">searching</span> right now</h1>
        <p>List your business on <?php echo esc_html($platform); ?>, show up when customers are actively looking for what you do, and manage every inquiry from one dashboard.</p>
        <div class="aw-hero-actions">
          <a href="<?php echo esc_url($register_url); ?>" class="aw-hero-cta">List your business free →</a>
          <a href="#plans" class="aw-hero-secondary">See how pricing works</a>
        </div>
        <div class="aw-hero-stats">
          <?php if ($total_vendors > 0): ?>
          <div><div class="aw-hero-stat-num"><?php echo esc_html(number_format($total_vendors)); ?>+</div><div class="aw-hero-stat-lbl">Active businesses</div></div>
          <?php endif; ?>
          <?php if ($total_listings > 0): ?>
          <div><div class="aw-hero-stat-num"><?php echo esc_html(number_format($total_listings)); ?>+</div><div class="aw-hero-stat-lbl">Live listings</div></div>
          <?php endif; ?>
          <?php if ($total_reviews > 0): ?>
          <div><div class="aw-hero-stat-num"><?php echo esc_html(number_format($total_reviews)); ?>+</div><div class="aw-hero-stat-lbl">Customer reviews</div></div>
          <?php endif; ?>
        </div>
      </div>
      <div class="aw-cascade">
        <div class="aw-lead-card">
          <div class="aw-lead-icon" style="background:#FFF1EA">🔧</div>
          <div class="aw-lead-body">
            <div class="aw-lead-title">New inquiry — AC Repair</div>
            <div class="aw-lead-meta">Andheri, Mumbai · 2m ago</div>
          </div>
          <div class="aw-lead-badge">New</div>
        </div>
        <div class="aw-lead-card">
          <div class="aw-lead-icon" style="background:#EEF2FF">📄</div>
          <div class="aw-lead-body">
            <div class="aw-lead-title">New inquiry — Document Attestation</div>
            <div class="aw-lead-meta">Whitefield, Bengaluru · 6m ago</div>
          </div>
          <div class="aw-lead-badge">New</div>
        </div>
        <div class="aw-lead-card">
          <div class="aw-lead-icon" style="background:#F0FDF4">📸</div>
          <div class="aw-lead-body">
            <div class="aw-lead-title">New inquiry — Wedding Photography</div>
            <div class="aw-lead-meta">Koramangala, Bengaluru · 11m ago</div>
          </div>
          <div class="aw-lead-badge">New</div>
        </div>
        <div class="aw-cascade-seal">GENUINE<br>LEADS<br>DAILY</div>
      </div>
    </div>
  </section>

  <section class="aw-section" id="benefits">
    <div class="aw-wrap">
      <div class="aw-section-head">
        <div class="aw-eyebrow-label">What you get</div>
        <div class="aw-section-title">Why list on <?php echo esc_html($platform); ?></div>
        <div class="aw-section-sub">Everything you need to attract and manage customers, in one place.</div>
      </div>
      <div class="aw-benefits-list">
        <div class="aw-benefit-row"><div class="aw-benefit-num">01</div><h3>Get found</h3><p>Show up when customers search for exactly what you offer, in your city.</p></div>
        <div class="aw-benefit-row"><div class="aw-benefit-num">02</div><h3>Manage every lead in one place</h3><p>Every inquiry, call, and WhatsApp message tracked in a single dashboard.</p></div>
        <div class="aw-benefit-row"><div class="aw-benefit-num">03</div><h3>Build trust with reviews</h3><p>Genuine customer reviews help new customers choose you with confidence.</p></div>
        <div class="aw-benefit-row"><div class="aw-benefit-num">04</div><h3>Your own business page</h3><p>A professional page for your business — photos, services, pricing, and more.</p></div>
        <div class="aw-benefit-row"><div class="aw-benefit-num">05</div><h3>See what's working</h3><p>Track how customers find you and which listings perform best.</p></div>
        <div class="aw-benefit-row"><div class="aw-benefit-num">06</div><h3>Stand out as you grow</h3><p>Featured placement and priority visibility options when you're ready.</p></div>
      </div>
    </div>
  </section>

  <?php if ( ! empty( $plans ) ): ?>
  <section class="aw-section aw-section-alt" id="plans">
    <div class="aw-wrap">
      <div class="aw-section-head">
        <div class="aw-eyebrow-label">Pricing</div>
        <div class="aw-section-title">Simple, transparent plans</div>
        <div class="aw-section-sub">Start free. Upgrade anytime as your business grows.</div>
      </div>
      <div class="aw-plans-grid">
        <?php foreach ( $plans as $plan ):
          $features = gs_parse_feature_list( $plan->features_list ?? null );
          $is_free = (float) $plan->price_monthly <= 0;
        ?>
        <div class="aw-plan-card<?php echo $plan->is_popular ? ' popular' : ''; ?>">
          <?php if ( $plan->is_popular ): ?><div class="aw-plan-badge"><?php echo esc_html( ! empty( $plan->badge_text ) ? $plan->badge_text : 'Most Popular' ); ?></div><?php endif; ?>
          <div class="aw-plan-name"><?php echo esc_html( $plan->name ); ?></div>
          <div class="aw-plan-price">
            <?php echo $is_free ? 'Free' : '₹' . esc_html( number_format( (float) $plan->price_monthly ) ); ?>
            <?php if ( ! $is_free ): ?><span>/month</span><?php endif; ?>
          </div>
          <?php if ( ! empty( $plan->description ) ): ?><div style="font-size:.82rem;color:#6B6D80;margin-top:6px"><?php echo esc_html( $plan->description ); ?></div><?php endif; ?>
          <ul class="aw-plan-features">
            <?php foreach ( array_slice( $features, 0, 6 ) as $f ): ?>
              <li><?php echo esc_html( is_array( $f ) ? ( $f['text'] ?? '' ) : $f ); ?></li>
            <?php endforeach; ?>
            <?php if ( empty( $features ) ): ?>
              <li><?php echo (int) $plan->max_listings; ?> listing<?php echo $plan->max_listings == 1 ? '' : 's'; ?></li>
              <li><?php echo (int) $plan->max_photos; ?> photos</li>
              <?php if ( $plan->priority_listing ): ?><li>Priority placement</li><?php endif; ?>
              <?php if ( $plan->featured_badge ): ?><li>Featured badge</li><?php endif; ?>
            <?php endif; ?>
          </ul>
          <a href="<?php echo esc_url( $register_url ); ?>" class="aw-plan-cta">Get Started</a>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <?php if ( ! empty( $testimonials ) ): ?>
  <section class="aw-section">
    <div class="aw-wrap">
      <div class="aw-section-head">
        <div class="aw-eyebrow-label">In their words</div>
        <div class="aw-section-title">What business owners are saying</div>
        <div class="aw-section-sub">Real reviews from real customers, on real listings.</div>
      </div>
      <div class="aw-test-grid">
        <?php foreach ( $testimonials as $t ): ?>
        <div class="aw-test-card">
          <span class="aw-test-mark">"</span>
          <div class="aw-test-text"><?php echo esc_html( mb_strimwidth( $t->review_text, 0, 160, '…' ) ); ?></div>
          <div class="aw-test-stars"><?php echo str_repeat( '★', (int) round( $t->rating ) ) . str_repeat( '☆', 5 - (int) round( $t->rating ) ); ?></div>
          <div class="aw-test-name"><?php echo esc_html( $t->reviewer_name ); ?></div>
          <?php if ( ! empty( $t->business_name ) ): ?><div class="aw-test-biz">Review for <?php echo esc_html( $t->business_name ); ?></div><?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <section class="aw-section aw-section-alt" id="faq">
    <div class="aw-wrap" style="max-width:760px">
      <div class="aw-section-head">
        <div class="aw-eyebrow-label">Questions</div>
        <div class="aw-section-title">Common questions</div>
      </div>
      <div class="aw-faq-list">
        <?php
        $faqs = [
            [ 'q' => 'Is it free to list my business?', 'a' => 'Yes — you can create a free listing to get started. Paid plans unlock additional features like priority placement and a featured badge.' ],
            [ 'q' => 'How do customers contact me?', 'a' => 'Customers can call, WhatsApp, or send an inquiry directly through your listing page — every lead lands in your vendor dashboard.' ],
            [ 'q' => 'Can I upgrade or change my plan later?', 'a' => 'Yes, you can upgrade, downgrade, or cancel your plan at any time from your vendor dashboard.' ],
            [ 'q' => 'How long does it take to get listed?', 'a' => 'Most listings go live shortly after submission, once reviewed for quality and accuracy.' ],
        ];
        foreach ( $faqs as $i => $f ):
        ?>
        <div class="aw-faq-row">
          <div class="aw-faq-num"><?php echo str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ); ?></div>
          <div>
            <h3><?php echo esc_html( $f['q'] ); ?></h3>
            <p><?php echo esc_html( $f['a'] ); ?></p>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <section class="aw-cta-band">
    <div class="aw-wrap aw-cta-band-inner">
      <h2>Ready to grow your business?</h2>
      <p>Join <?php echo $total_vendors > 0 ? esc_html(number_format($total_vendors)) . '+ businesses' : 'businesses'; ?> already listed on <?php echo esc_html($platform); ?></p>
      <a href="<?php echo esc_url($register_url); ?>" class="aw-cta-band-btn">List your business free →</a>
    </div>
  </section>
</div>

<?php
/* Footer — exact same real markup already established across
   archive.php / vendor-site.php / platform-page.php, copied precisely
   for genuine visual consistency rather than approximated. */
$df_site   = function_exists('gs_setting') ? gs_setting('platform_name', get_bloginfo('name')) : get_bloginfo('name');
$df_home   = home_url('/');
$df_dir    = home_url('/directory/');
// Real bug fix (v7.475.7) — see matching comment in about-us.php. $color
// is already computed above (line 48) for this exact platform-color
// setting, reused here rather than re-fetching it.
$_ftr_primary = $color;
?>
<footer style="background:#14162B;color:rgba(251,250,247,.6);padding:32px 0;text-align:center;font-size:.78rem;font-family:'IBM Plex Mono',monospace">
  <div class="aw-wrap">© <?php echo esc_html( gmdate('Y') ); ?> <?php echo esc_html($df_site); ?>. All rights reserved. &nbsp;·&nbsp;
    <a href="<?php echo esc_url($df_home); ?>" style="color:rgba(251,250,247,.75);transition:color .15s" onmouseover="this.style.color='<?php echo esc_js($_ftr_primary); ?>'" onmouseout="this.style.color='rgba(251,250,247,.75)'">Home</a> &nbsp;·&nbsp;
    <a href="<?php echo esc_url($df_dir); ?>" style="color:rgba(251,250,247,.75);transition:color .15s" onmouseover="this.style.color='<?php echo esc_js($_ftr_primary); ?>'" onmouseout="this.style.color='rgba(251,250,247,.75)'">Browse Directory</a>
  </div>
</footer>
