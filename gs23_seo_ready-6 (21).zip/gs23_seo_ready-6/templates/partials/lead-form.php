<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
// Partial: lead-form — rendered inline via shortcode
?>
<div class="gs-partial gs-partial-lead-form">
  <!-- lead-form content renders here via JS/AJAX -->
</div>
