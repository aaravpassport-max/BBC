<?php
// Full request history (not just the single latest) — shows drafts, past requests, current status
$mp_requests = $vid ? $wpdb->get_results($wpdb->prepare(
  "SELECT pr.* FROM {$pfx}plan_requests pr WHERE pr.vendor_id=%d AND pr.is_deleted=0 ORDER BY pr.created_at DESC LIMIT 10", $vid
)) : [];
$mp_status_labels = [
    'draft'=>['📝 Draft','#94A3B8'],'pending'=>['⏳ Pending Review','#F59E0B'],
    'under_review'=>['🔍 Under Review','#2563EB'],'payment_verification_pending'=>['🧾 Verifying Your Payment','#7C3AED'],
    'info_required'=>['⚠️ Action Needed','#D97706'],'on_hold'=>['⏸️ On Hold','#64748B'],
    'approved'=>['✅ Approved','#059669'],'completed'=>['✅ Activated','#059669'],
    'rejected'=>['❌ Rejected','#DC2626'],'expired'=>['⌛ Expired','#94A3B8'],'cancelled'=>['✕ Cancelled','#94A3B8'],
];
if($mp_requests): ?>
<div style="margin-top:18px">
  <div style="font-weight:700;color:#1E3A5F;margin-bottom:10px;font-size:.92rem">Your Offline Payment Requests</div>
  <?php foreach($mp_requests as $req):
    [$mp_label, $mp_color] = $mp_status_labels[$req->status] ?? [$req->status, '#64748B'];
    $mp_can_cancel = in_array($req->status, ['draft','pending','under_review','info_required','on_hold'], true);
    $mp_can_edit   = in_array($req->status, ['draft','info_required'], true);
  ?>
  <div class="gs-card" style="border-left:4px solid <?php echo $mp_color; ?>;margin-bottom:10px">
    <div style="display:flex;justify-content:space-between;align-items:start;flex-wrap:wrap;gap:8px">
      <div>
        <div style="font-weight:700"><?php echo $mp_label; ?></div>
        <div style="font-size:.85rem;color:#475569;margin-top:2px">
          <strong><?php echo esc_html($req->plan_name ?? '—'); ?></strong>
          — <?php echo gs_format_price((float)$req->final_amount); ?>
          <?php if((float)$req->balance_due > 0): ?><span style="color:#DC2626">(balance due: <?php echo gs_format_price((float)$req->balance_due); ?>)</span><?php endif; ?>
        </div>
        <?php if($req->status === 'info_required' && $req->admin_note): ?>
        <div style="font-size:.8rem;color:#92400E;background:#FFFBEB;border:1px solid #FDE68A;border-radius:6px;padding:6px 10px;margin-top:6px"><?php echo esc_html($req->admin_note); ?></div>
        <?php elseif($req->admin_note): ?>
        <div style="font-size:.8rem;color:#64748B;margin-top:4px">Note: <?php echo esc_html($req->admin_note); ?></div>
        <?php endif; ?>
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        <?php if($mp_can_edit): ?>
        <button type="button" class="gs-btn gs-btn-xs gs-btn-primary" onclick="MPV.editRequest(<?php echo (int)$req->id; ?>,<?php echo (int)$req->plan_id; ?>,'<?php echo esc_js($req->plan_name); ?>')">✏️ <?php echo $req->status==='draft'?'Continue Draft':'Resubmit'; ?></button>
        <?php endif; ?>
        <?php if($mp_can_cancel): ?>
        <button type="button" class="gs-btn gs-btn-xs gs-btn-ghost" onclick="MPV.cancelRequest(<?php echo (int)$req->id; ?>)">✕ Cancel</button>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- ══════════════════ Offline Payment Request Modal ══════════════════ -->
<div id="mpv-modal" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.6);z-index:99999;align-items:center;justify-content:center;padding:16px">
  <div style="background:#fff;border-radius:14px;max-width:560px;width:100%;max-height:88vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.25)">
    <div style="background:#1E3A5F;padding:18px 22px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0">
      <div style="font-size:1rem;font-weight:800;color:#fff">🏦 Pay Offline</div>
      <button onclick="MPV.close()" style="background:rgba(255,255,255,.15);border:none;color:#fff;border-radius:6px;width:28px;height:28px;cursor:pointer">✕</button>
    </div>
    <form id="mpv-form" style="padding:22px">
      <input type="hidden" name="plan_id" id="mpv-plan-id">
      <input type="hidden" name="draft_id" id="mpv-draft-id" value="">
      <div style="font-size:.85rem;color:#475569;margin-bottom:16px">
        Plan: <strong id="mpv-plan-name"></strong>. Submit your payment details below — admin will verify and activate your plan.
      </div>

      <div class="mpv-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div>
          <label class="gs-lbl-sm">Duration</label>
          <select name="billing_cycle" class="gs-inp">
            <option value="monthly">Monthly</option><option value="quarterly">Quarterly</option>
            <option value="half_yearly">Half-Yearly</option><option value="annual">Annual</option>
          </select>
        </div>
        <div>
          <label class="gs-lbl-sm">Payment Mode</label>
          <select name="payment_mode" class="gs-inp" required>
            <option value="">— Select —</option>
            <option>Bank Transfer</option><option>UPI</option><option>NEFT</option><option>RTGS</option>
            <option>IMPS</option><option>Cash</option><option>Cheque</option><option>Demand Draft</option><option>Other</option>
          </select>
        </div>
      </div>
      <div class="mpv-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label class="gs-lbl-sm">Transaction ID</label><input type="text" name="transaction_id" class="gs-inp"></div>
        <div><label class="gs-lbl-sm">UTR Number</label><input type="text" name="utr_number" class="gs-inp"></div>
      </div>
      <div class="mpv-grid-2" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div><label class="gs-lbl-sm">Reference Number</label><input type="text" name="reference_number" class="gs-inp"></div>
        <div><label class="gs-lbl-sm">Amount Paid</label><input type="number" step="0.01" min="0" name="amount_paid" class="gs-inp" placeholder="₹"></div>
      </div>
      <div style="margin-bottom:12px">
        <label class="gs-lbl-sm">Payment Date</label>
        <input type="date" name="payment_date" class="gs-inp" style="max-width:200px" max="<?php echo esc_attr(date('Y-m-d')); ?>">
      </div>
      <div style="margin-bottom:6px">
        <label class="gs-lbl-sm">Payment Proof <span style="color:#94A3B8;font-weight:400">(receipt / screenshot, optional)</span></label>
        <input type="file" id="mpv-proof-file" accept="image/*,.pdf" style="font-size:.82rem">
        <div id="mpv-proof-status" style="font-size:.78rem;color:#059669;margin-top:4px"></div>
        <input type="hidden" name="payment_proof_ids" id="mpv-proof-ids" value="">
      </div>
      <div style="margin-bottom:18px">
        <label class="gs-lbl-sm">Remarks <span style="color:#94A3B8;font-weight:400">(optional)</span></label>
        <textarea name="note" class="gs-inp" rows="2"></textarea>
      </div>

      <div id="mpv-error" style="display:none;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA;border-radius:8px;padding:10px 14px;font-size:.83rem;margin-bottom:14px"></div>
      <div style="display:flex;gap:10px">
        <button type="button" id="mpv-draft-btn" class="gs-btn gs-btn-ghost" style="flex:1" onclick="MPV.saveDraft()">💾 Save as Draft</button>
        <button type="submit" id="mpv-submit-btn" class="gs-btn gs-btn-primary" style="flex:2">Submit Request</button>
      </div>
    </form>
  </div>
</div>
<style>
.gs-lbl-sm{display:block;font-size:.72rem;font-weight:700;color:#64748B;margin-bottom:4px}
/* Matches vendor-dashboard.php's own .gs-g2 breakpoint (900px) — this form's
   inline grid-template-columns:1fr 1fr rows aren't covered by that class-based
   rule since they use inline styles, so without this they'd stay forced
   side-by-side on mobile while the rest of the vendor dashboard correctly
   collapses to one column at the same breakpoint. */
@media (max-width: 900px) {
  .mpv-grid-2 { grid-template-columns: 1fr !important; }
}
</style>

<script>
window.MPV = (function($){
  function openRequestForm(planId, planName) {
    $('#mpv-form')[0].reset();
    $('#mpv-plan-id').val(planId);
    $('#mpv-draft-id').val('');
    $('#mpv-plan-name').text(planName);
    $('#mpv-proof-ids').val('');
    $('#mpv-proof-status').text('');
    $('#mpv-error').hide();
    $('#mpv-modal').css('display', 'flex');
  }
  function editRequest(requestId, planId, planName) {
    openRequestForm(planId, planName);
    $('#mpv-draft-id').val(requestId);
  }
  function close() { $('#mpv-modal').hide(); }

  $(document).on('change', '#mpv-proof-file', function() {
    var file = this.files[0];
    if (!file) return;
    var fd = new FormData();
    fd.append('action', 'gs_upload_media');
    fd.append('nonce', GS.nonce);
    fd.append('file', file);
    fd.append('context', 'document');
    $('#mpv-proof-status').text('Uploading…');
    $.ajax({ url: GS.ajax_url, method: 'POST', data: fd, processData: false, contentType: false,
      success: function(r) {
        if (r.success) {
          var ids = JSON.parse($('#mpv-proof-ids').val() || '[]');
          ids.push(r.data.media_id);
          $('#mpv-proof-ids').val(JSON.stringify(ids));
          $('#mpv-proof-status').text('✅ Uploaded: ' + file.name);
        } else {
          $('#mpv-proof-status').css('color', '#DC2626').text((r.data && r.data.message) || 'Upload failed.');
        }
      },
      error: function() { $('#mpv-proof-status').css('color', '#DC2626').text('Upload failed.'); }
    });
  });

  function submitForm(isDraft) {
    var data = {};
    $('#mpv-form').serializeArray().forEach(function(f) { data[f.name] = f.value; });
    if (isDraft) { data.is_draft = 1; }
    if (!isDraft && !data.payment_mode) {
      $('#mpv-error').show().text('Please select a payment mode.');
      return;
    }
    // Disable BOTH buttons during submission — not just the one clicked — so a
    // user can't click "Save as Draft" then immediately click "Submit Request"
    // (or vice versa) while the first request is still in flight, which could
    // otherwise create two requests from one form fill.
    var $submitBtn = $('#mpv-submit-btn');
    var $draftBtn = $('#mpv-draft-btn');
    gsBtnLoading($submitBtn, true, isDraft ? 'Submit Request' : 'Submitting…');
    gsBtnLoading($draftBtn, true, isDraft ? 'Saving…' : '💾 Save as Draft');
    gsPost('gs_request_plan', data, function(d) {
      gsToast(d.message || 'Submitted!', 'success');
      close();
      setTimeout(function() { window.location.reload(); }, 1000);
    }, function(m) {
      gsBtnLoading($submitBtn, false, 'Submit Request');
      gsBtnLoading($draftBtn, false, '💾 Save as Draft');
      $('#mpv-error').show().text(m || 'Could not submit request.');
    });
  }

  $(document).on('submit', '#mpv-form', function(e) { e.preventDefault(); submitForm(false); });

  function saveDraft() { submitForm(true); }

  function cancelRequest(requestId) {
    gsModal.confirm('Cancel this request?', function() {
      gsPost('gs_vendor_cancel_plan_request', { request_id: requestId }, function(d) {
        gsToast(d.message || 'Cancelled.', 'info');
        setTimeout(function() { window.location.reload(); }, 800);
      });
    });
  }

  return { openRequestForm: openRequestForm, editRequest: editRequest, close: close, saveDraft: saveDraft, cancelRequest: cancelRequest };
})(jQuery);
</script>
