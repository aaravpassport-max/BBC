<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
// Partial: requirements — rendered inline via shortcode
?>
<div class="gs-partial gs-partial-requirements">
  <!-- requirements content renders here via JS/AJAX -->
</div>
