<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
// Partial: search-bar — rendered inline via shortcode
?>
<div class="gs-partial gs-partial-search-bar">
  <!-- search-bar content renders here via JS/AJAX -->
</div>
