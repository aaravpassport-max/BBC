<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
// Partial: featured-listings — rendered inline via shortcode
?>
<div class="gs-partial gs-partial-featured-listings">
  <!-- featured-listings content renders here via JS/AJAX -->
</div>
