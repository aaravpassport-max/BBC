<?php
/**
 * blank.php — Zero-output template returned by Router::bypass_theme_template()
 *
 * This file is returned as the WordPress template when a GoodService standalone
 * page (directory, dashboards, etc.) somehow reaches the template_include phase
 * without the earlier exit() calls in dispatch() or intercept_gs_wp_pages() having
 * fired. It outputs nothing, preventing any theme template from rendering.
 *
 * Under normal operation this file is never loaded — the router exits at
 * template_redirect before WordPress ever calls template_include.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
// Intentionally empty — the GoodService router has already output the page
// (or will output it via PHP shutdown). No theme content should be added.
