<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
// Partial: categories-grid — rendered inline via shortcode
?>
<div class="gs-partial gs-partial-categories-grid">
  <!-- categories-grid content renders here via JS/AJAX -->
</div>
