<?php
/**
 * gs23 GoodService — Section Detachment Audit
 *
 * Permanent regression check for "does hiding a section actually stop
 * it from loading its CSS/resources, not just visually hide it."
 *
 * WHY THIS FILE EXISTS: a deep audit (see MODULE_ARCHITECTURE_ROADMAP.md,
 * Section 6.18-6.20) found several real, live gaps where a section's
 * CSS shipped to every visitor regardless of visibility — About, Stats,
 * and Reviews were all found and fixed this way, on THREE separate
 * passes, because a manual review kept missing sections a fully
 * automated check would have caught immediately. This script exists so
 * the same category of gap is caught mechanically going forward,
 * whether a future section is added by a human developer or another AI
 * with no memory of this project's history.
 *
 * HOW TO USE: run this after adding any new section's CSS to
 * vendor-site.php, before considering that section complete:
 *
 *   php /mnt/skills-or-wherever/audit-section-detachment.php
 *
 * It exits non-zero and prints every section missing a gate if
 * anything is found — safe to wire into a CI/pre-commit check later if
 * this project ever adopts one.
 *
 * WHAT THIS CHECKS: every section registered in the live default
 * section-order array actually has at least one `$_sec_show('key')`
 * call inside the main <style> block region of vendor-site.php. It
 * does NOT (and cannot, safely) auto-fix anything — CSS block
 * boundaries are sometimes genuinely tangled with unrelated content
 * (see the Reviews/Mobile-View-Settings finding in Section 6.20 of the
 * roadmap doc), and blindly wrapping a mis-identified block risks a
 * real regression. This script's job is to flag, not to fix.
 */

$vendor_site_path = dirname( __DIR__ ) . '/templates/pages/vendor-site.php';
if ( ! file_exists( $vendor_site_path ) ) {
    fwrite( STDERR, "Could not find vendor-site.php at expected path: {$vendor_site_path}\n" );
    exit( 2 );
}
$content = file_get_contents( $vendor_site_path );
$lines = explode( "\n", $content );

// Pull the real, current list of sections directly from the file's own
// $_default_sec_order array, rather than a hardcoded copy here that
// could itself go stale — this script always checks against whatever
// is actually live, not a snapshot from when this script was written.
if ( ! preg_match( "/\\\$_default_sec_order\s*=\s*\[(.*?)\];/", $content, $m ) ) {
    fwrite( STDERR, "Could not find \$_default_sec_order in vendor-site.php — has its declaration changed shape?\n" );
    exit( 2 );
}
preg_match_all( "/'([a-z_]+)'/", $m[1], $sec_matches );
$all_sections = $sec_matches[1];

// Sections that deliberately do NOT use $_sec_wrap_style()/the shared
// CSS-gate pattern, because they render through a genuinely different
// mechanism (inline in Hero, a separately-included partial, etc.) —
// confirmed real and current as of the roadmap doc's own findings, not
// assumed. A section landing in this list should have its OWN
// confirmed-correct visibility mechanism, verified manually once, not
// silently ignored by this script forever.
$known_alternate_mechanism = [ 'inquiry_modules', 'related_listings', 'trust_bar' ];

// The CSS <style> block's real boundaries, found dynamically rather
// than hardcoded — a hardcoded line range inevitably goes stale as
// this file grows (confirmed directly: the very first real section
// added after this tool was written pushed the real CSS block past
// the original hardcoded upper boundary, producing a false failure on
// a section whose gate was actually correct). Finds the main <style>
// tag's own actual start and end instead, so this check remains
// correct no matter how large the file becomes in the future. Uses
// the LAST <style>...</style> pair in the file specifically, since
// vendor-site.php is confirmed to contain more than one <style> block
// and the main, large one (where every section's own CSS actually
// lives) is the later one.
$css_region_start = null;
$css_region_end = null;
foreach ( $lines as $i => $line ) {
    $trimmed = ltrim( $line );
    if ( $css_region_start === null && preg_match( '/^<style\b/', $trimmed ) ) { $css_region_start = $i; continue; }
    if ( $css_region_start !== null && $css_region_end === null && preg_match( '#^</style>#', $trimmed ) ) { $css_region_end = $i; break; }
}
if ( $css_region_start === null || $css_region_end === null || $css_region_end <= $css_region_start ) {
    fwrite( STDERR, "Could not find a valid <style>...</style> block in vendor-site.php — has its structure changed?\n" );
    exit( 2 );
}

$missing = [];
foreach ( $all_sections as $sec ) {
    if ( in_array( $sec, $known_alternate_mechanism, true ) ) { continue; }
    $found = false;
    foreach ( $lines as $i => $line ) {
        if ( $i < $css_region_start || $i > $css_region_end ) { continue; }
        if ( preg_match( "/\\\$_sec_show\(\s*'" . preg_quote( $sec, '/' ) . "'\s*\)/", $line ) ) {
            $found = true;
            break;
        }
    }
    if ( ! $found ) { $missing[] = $sec; }
}

if ( empty( $missing ) ) {
    echo "PASS — every section in \$_default_sec_order (except the " . count( $known_alternate_mechanism ) . " with a confirmed alternate visibility mechanism) has at least one CSS-level \$_sec_show() gate.\n";
    echo "Checked " . count( $all_sections ) . " sections total.\n";
    exit( 0 );
}

fwrite( STDERR, "FAIL — the following sections have NO CSS-level visibility gate found:\n" );
foreach ( $missing as $sec ) {
    fwrite( STDERR, "  - {$sec}\n" );
}
fwrite( STDERR, "\nThis means each one's CSS ships to every visitor regardless of whether the section is\n" );
fwrite( STDERR, "shown or hidden. Wrap its CSS block in <?php if ( \$_sec_show('KEY') ): ?> ... <?php endif; ?>,\n" );
fwrite( STDERR, "verify with a byte-diff against the original (see Section 5 of MODULE_ARCHITECTURE_ROADMAP.md\n" );
fwrite( STDERR, "for the exact, proven methodology), and re-run this script.\n" );
exit( 1 );
