/*!
 * GoodService Platform — Main JS v2.0 ENTERPRISE
 * Modules: Core, GSAP, Lenis, Search, Messaging,
 *          Notifications, Forms, Media, Admin, Vendor
 */
/* global GS, jQuery, gsap, ScrollTrigger, Lenis */
;(function($){
'use strict';

/* ═══ MODULE 1 — CORE ══════════════════════════════════════════ */
var GS_Core = {
  // Real fix — closes a documented, codebase-wide risk (not a hypothetical one:
  // every "Common Mistakes" tooltip warning about accidental double-clicks
  // traces back to this single chokepoint, since virtually every onclick="gsPost(...)"
  // across both dashboards routes through here with no built-in double-submit
  // guard). Rather than retrofitting hundreds of individual call sites — a large,
  // inconsistent, high-risk surface to touch — the guard lives here once: an
  // identical (action + payload) request already in flight is not re-sent, so a
  // rapid double-click on any button in the system can no longer fire the same
  // action twice while the first call is still pending. A genuinely different
  // action or different data (a different lead_id, a different value) is never
  // blocked — this only catches the exact-duplicate case a double-click produces.
  _inFlight:{},
  post:function(action,data,ok,err,timeoutMs){
    var key=action+'|'+JSON.stringify(data||{});
    var handleSuccess=function(r){
      if(r&&r.success){if(typeof ok==='function')ok(r.data||{});}
      else{var m=r&&r.data&&r.data.message?r.data.message:GS.i18n.error;if(typeof err==='function')err(m);else GS_Toast.show(m,'error');}
    };
    var handleError=function(x){
      /* Extract the real PHP error message from wp_send_json_error() response body.
         Previously only showed generic "Network error (400)" — hiding the actual cause. */
      var body={};
      try{ body=JSON.parse(x.responseText); }catch(e){}
      var m=(body.data&&body.data.message)?body.data.message:'Network error (HTTP '+x.status+'). Try again.';
      if(typeof err==='function')err(m);else GS_Toast.show(m,'error');
    };
    if(GS_Core._inFlight[key]){
      // Real fix — root cause of "Save button stuck on Saving… forever, no
      // error, roughly 1 in 3 saves": a second caller whose (action+data)
      // happened to collide with an already-in-flight request (e.g. an
      // autosave firing the same instant as a manual Save with unchanged
      // form data) got the original jqXHR handed back with NONE of its own
      // ok/err callbacks ever wired up — that caller's button was set to
      // "Saving…" and then simply never heard back, success or failure.
      // Attaching THIS caller's handlers to the shared in-flight promise via
      // .done()/.fail() means every joining caller now gets its own ok/err
      // invoked off the one real response — no request's callbacks are ever
      // silently dropped again.
      return GS_Core._inFlight[key].done(handleSuccess).fail(handleError);
    }
    var opts={url:GS.ajax_url,method:'POST',
      data:Object.assign({action:action,nonce:GS.nonce},data),
      success:handleSuccess,
      error:handleError,
      complete:function(){ delete GS_Core._inFlight[key]; }
    };
    if(timeoutMs){ opts.timeout=timeoutMs; }
    var jq=$.ajax(opts);
    GS_Core._inFlight[key]=jq;
    return jq;
  },
  btnLoading:function($b,on,t){
    if(on){$b.data('orig',$b.html()).prop('disabled',true).html('<span class="gs-loading-spin">⟳</span> '+(t||'Loading…'));}
    else{$b.prop('disabled',false).html($b.data('orig')||t||'Done');}
  },
  debounce:function(fn,d){var t;return function(){clearTimeout(t);t=setTimeout(fn.bind(this,arguments),d);};},
  throttle:function(fn,l){var last=0;return function(){var now=Date.now();if(now-last>=l){last=now;fn.apply(this,arguments);}};},
  formatNum:function(n){return Number(n).toLocaleString('en-IN');}
};
window.gsPost=GS_Core.post;
window.gsBtnLoading=GS_Core.btnLoading;

/* ═══ MODULE 2 — TOAST ═════════════════════════════════════════ */
var GS_Toast={
  container:null,
  init:function(){
    if(!this.container){
      // A11Y FIX #2: Container has role="region" — individual toasts get aria-live
      // so screen readers announce each message as it appears (not the whole region).
      this.container=$('<div class="gs-toast-container" role="region" aria-label="Notifications"></div>').appendTo('body');
    }
  },
  show:function(msg,type,dur){
    this.init();type=type||'info';dur=dur||4200;
    var icons={success:'✅',error:'❌',warning:'⚠️',info:'ℹ️'};
    // A11Y FIX #2: Each toast has aria-live="assertive" for errors, "polite" for others
    var liveness=(type==='error')?'assertive':'polite';
    var $t=$('<div class="gs-toast '+type+'" role="alert" aria-live="'+liveness+'" aria-atomic="true">'
      +'<span style="font-size:1.1rem;flex-shrink:0">'+icons[type]+'</span>'
      +'<div style="flex:1;font-size:.86rem;line-height:1.5">'+$('<div>').text(msg).html()+'</div>'
      +'<button onclick="this.closest(\'.gs-toast\').remove()" aria-label="Dismiss notification" style="background:none;border:none;font-size:1rem;cursor:pointer;color:#94A3B8;padding:0;flex-shrink:0">✕</button>'
      +'</div>');
    this.container.append($t);
    setTimeout(function(){$t.css({opacity:0,transform:'translateX(50px)',transition:'all .35s ease'});setTimeout(function(){$t.remove();},350);},dur);
  }
};
// Real fix, moved here from a page-specific location so it's genuinely
// available everywhere: alert() text often can't be selected/copied on
// mobile browsers and some webviews, which was blocking the actual point of
// several admin diagnostic tools — getting real, copyable data back out. A
// textarea is always selectable, and a real copy button removes the need to
// select manually at all.
window.gsShowCopyableModal = function(title, text) {
    var existing = document.getElementById('gs-copy-modal-overlay');
    if (existing) existing.remove();
    var overlay = document.createElement('div');
    overlay.id = 'gs-copy-modal-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px';
    overlay.innerHTML =
        '<div style="background:#fff;border-radius:12px;padding:20px;max-width:600px;width:100%;max-height:80vh;display:flex;flex-direction:column;gap:12px">'
        + '<div style="display:flex;justify-content:space-between;align-items:center">'
        + '<strong style="font-size:.95rem">' + String(title || '').replace(/</g,'&lt;') + '</strong>'
        + '<button id="gs-copy-modal-close" style="background:none;border:none;font-size:1.3rem;cursor:pointer;color:#64748B;line-height:1">✕</button>'
        + '</div>'
        + '<textarea id="gs-copy-modal-text" readonly style="width:100%;flex:1;min-height:280px;font-family:monospace;font-size:.78rem;padding:10px;border:1.5px solid #E2E8F0;border-radius:8px;resize:vertical"></textarea>'
        + '<div style="display:flex;gap:8px;justify-content:flex-end">'
        + '<button id="gs-copy-modal-copy" class="gs-btn gs-btn-primary gs-btn-sm">📋 Copy to Clipboard</button>'
        + '<button id="gs-copy-modal-close2" class="gs-btn gs-btn-sm" style="background:#F1F5F9">Close</button>'
        + '</div></div>';
    document.body.appendChild(overlay);
    var ta = document.getElementById('gs-copy-modal-text');
    ta.value = String(text || ''); // set via .value, not innerHTML — avoids any HTML-escaping concerns entirely
    ta.focus();
    ta.select();
    function closeModal(){ overlay.remove(); }
    document.getElementById('gs-copy-modal-close').onclick = closeModal;
    document.getElementById('gs-copy-modal-close2').onclick = closeModal;
    overlay.addEventListener('click', function(e){ if (e.target === overlay) closeModal(); });
    document.getElementById('gs-copy-modal-copy').onclick = function(){
        var btn = document.getElementById('gs-copy-modal-copy');
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(String(text || '')).then(function(){
                btn.textContent = '✅ Copied!';
                setTimeout(function(){ btn.textContent = '📋 Copy to Clipboard'; }, 1500);
            }).catch(function(){
                ta.select();
                btn.textContent = 'Select the text above and copy manually';
            });
        } else {
            ta.select();
            btn.textContent = 'Clipboard API unavailable — text is selected, use Ctrl/Cmd+C';
        }
    };
};
window.gsToast=GS_Toast.show.bind(GS_Toast);

/* ═══ MODULE 3 — MODAL ═════════════════════════════════════════ */
var GS_Modal={
  _trigger:null,
  show:function(content,opts){
    opts=opts||{};
    var sz=opts.size||'md',title=opts.title||'',footer=opts.footer||'';
    var titleId='gs-modal-title-'+Date.now();
    var $o=$('<div class="gs-modal-overlay" id="gs-modal-overlay" role="dialog" aria-modal="true"'+(title?' aria-labelledby="'+titleId+'"':'')+' tabindex="-1">'
      +'<div class="gs-modal gs-modal-'+sz+'">'
      +(title?'<div class="gs-modal-header"><h3 class="gs-modal-title" id="'+titleId+'">'+title+'</h3><button class="gs-modal-close" onclick="gsModal.hide()" aria-label="Close dialog">✕</button></div>':'')
      +'<div class="gs-modal-body">'+content+'</div>'
      +(footer?'<div class="gs-modal-footer">'+footer+'</div>':'')
      +'</div></div>');
    // A11Y FIX #4: Store the element that opened the modal so focus returns on close
    GS_Modal._trigger=document.activeElement;
    $('body').append($o);
    $o.on('click',function(e){if($(e.target).is('.gs-modal-overlay'))GS_Modal.hide();});
    // A11Y FIX #3: Trap Tab/Shift+Tab focus inside modal
    $o.on('keydown',function(e){
      if(e.key==='Escape'){GS_Modal.hide();return;}
      if(e.key!=='Tab')return;
      var $els=$o.find('input,textarea,select,button,a,[tabindex]').not('[tabindex="-1"],[disabled]').filter(':visible');
      if(!$els.length)return;
      var first=$els.first()[0],last=$els.last()[0];
      if(e.shiftKey){if(document.activeElement===first){e.preventDefault();last.focus();}}
      else{if(document.activeElement===last){e.preventDefault();first.focus();}}
    });
    // A11Y FIX #4: Focus first focusable element synchronously (no setTimeout race)
    var $first=$o.find('input,textarea,select,button,[tabindex]').not('[tabindex="-1"],[disabled]').filter(':visible').first();
    if($first.length)$first.focus();else $o.focus();
    $('body').css('overflow','hidden');
    return $o;
  },
  hide:function(){
    $('#gs-modal-overlay').remove();
    $('body').css('overflow','');
    // A11Y FIX #4: Return focus to the element that triggered the modal
    if(GS_Modal._trigger&&typeof GS_Modal._trigger.focus==='function'){
      try{GS_Modal._trigger.focus();}catch(e){}
    }
    GS_Modal._trigger=null;
  },
  confirm:function(msg,onOk,opts){
    opts=opts||{};
    var cls=opts.danger?'gs-btn-red':'gs-btn-primary';
    GS_Modal.show('<p style="font-size:.9rem;color:#475569;line-height:1.65">'+msg+'</p>',{
      title:opts.title||'Confirm',size:'sm',
      footer:'<button class="gs-btn gs-btn-ghost gs-btn-md" onclick="gsModal.hide()">Cancel</button>'
            +'<button class="gs-btn '+cls+' gs-btn-md" id="gs-confirm-btn">'+(opts.confirmText||'Confirm')+'</button>'
    });
    $('#gs-confirm-btn').on('click',function(){GS_Modal.hide();if(typeof onOk==='function')onOk();});
  }
};
window.gsModal=GS_Modal;

/* ═══ MODULE 4 — LENIS SMOOTH SCROLL ══════════════════════════ */
var GS_Scroll={
  lenis:null,
  init:function(){
    if(typeof Lenis==='undefined'){this._raf=true;return;}
    this.lenis=new Lenis({duration:1.2,easing:function(t){return Math.min(1,1.001-Math.pow(2,-10*t));},smooth:true,smoothTouch:false});
    if(typeof gsap!=='undefined'&&typeof ScrollTrigger!=='undefined'){
      this.lenis.on('scroll',ScrollTrigger.update);
      gsap.ticker.add(function(time){GS_Scroll.lenis.raf(time*1000);});
      gsap.ticker.lagSmoothing(0);
    } else {
      function raf(t){GS_Scroll.lenis.raf(t);requestAnimationFrame(raf);}
      requestAnimationFrame(raf);
    }
  },
  scrollTo:function(target,opts){
    if(this.lenis)this.lenis.scrollTo(target,opts||{});
    else $('html,body').animate({scrollTop:typeof target==='number'?target:$(target).offset().top-80},500);
  }
};

/* ═══ MODULE 5 — GSAP ANIMATIONS ══════════════════════════════ */
var GS_Animations={
  init:function(){
    if(typeof gsap==='undefined'){this.initFallback();return;}
    gsap.registerPlugin(ScrollTrigger);
    this.hero();this.scrollEntrances();this.counters();this.parallax();this.microInteractions();
  },
  hero:function(){
    var tl=gsap.timeline({defaults:{ease:'power3.out',duration:.8}});
    if(document.querySelector('.gs-listing-breadcrumb'))tl.from('.gs-listing-breadcrumb',{opacity:0,y:-14,duration:.5});
    if(document.querySelector('.gs-listing-hero-logo'))tl.from('.gs-listing-hero-logo',{opacity:0,x:-20,scale:.9},'-=.3');
    if(document.querySelector('.gs-listing-name'))tl.from('.gs-listing-name',{opacity:0,y:22},'-=.5');
    if(document.querySelector('.gs-listing-tagline'))tl.from('.gs-listing-tagline',{opacity:0,y:16},'-=.5');
    if(document.querySelector('.gs-listing-trust-strip'))tl.from('.gs-listing-trust-strip',{opacity:0,y:12},'-=.45');
    if(document.querySelector('.gs-listing-cta-group'))tl.from('.gs-listing-cta-group .gs-btn',{opacity:0,y:14,stagger:.09},'-=.4');
  },
  scrollEntrances:function(){
    gsap.utils.toArray('[data-gsap="fade-up"]').forEach(function(el){
      gsap.from(el,{scrollTrigger:{trigger:el,start:'top 88%',once:true},opacity:0,y:32,duration:.75,ease:'power3.out'});
    });
    gsap.utils.toArray('[data-gsap="fade-in"]').forEach(function(el){
      gsap.from(el,{scrollTrigger:{trigger:el,start:'top 90%',once:true},opacity:0,duration:.8,ease:'power2.out'});
    });
    gsap.utils.toArray('[data-gsap="fade-left"]').forEach(function(el){
      gsap.from(el,{scrollTrigger:{trigger:el,start:'top 88%',once:true},opacity:0,x:-28,duration:.7,ease:'power3.out'});
    });
    gsap.utils.toArray('[data-gsap="fade-right"]').forEach(function(el){
      gsap.from(el,{scrollTrigger:{trigger:el,start:'top 88%',once:true},opacity:0,x:28,duration:.7,ease:'power3.out'});
    });
    gsap.utils.toArray('[data-gsap-stagger]').forEach(function(p){
      gsap.from(p.children,{scrollTrigger:{trigger:p,start:'top 85%',once:true},opacity:0,y:26,duration:.7,ease:'power3.out',stagger:{amount:.45,from:'start'}});
    });
    gsap.utils.toArray('.gs-listing-card,.gs-stat-card,.gs-why-card,.gs-plan-card,.gs-review-card').forEach(function(el){
      gsap.from(el,{scrollTrigger:{trigger:el,start:'top 92%',once:true},opacity:0,y:22,scale:.97,duration:.6,ease:'power3.out'});
    });
    gsap.utils.toArray('.gs-section-title,.gs-h2').forEach(function(el){
      gsap.from(el,{scrollTrigger:{trigger:el,start:'top 90%',once:true},opacity:0,x:-18,duration:.55,ease:'power2.out'});
    });
  },
  counters:function(){
    gsap.utils.toArray('.gs-stat-number[data-target]').forEach(function(el){
      var target=parseInt(el.getAttribute('data-target'))||0;
      var suffix=el.getAttribute('data-suffix')||'';
      ScrollTrigger.create({trigger:el,start:'top 85%',once:true,onEnter:function(){
        gsap.to({val:0},{val:target,duration:2,ease:'power2.out',onUpdate:function(){el.textContent=GS_Core.formatNum(Math.floor(this.targets()[0].val))+suffix;}});
      }});
    });
  },
  parallax:function(){
    var heroBg=document.querySelector('.gs-listing-hero-bg img');
    if(heroBg)gsap.to(heroBg,{scrollTrigger:{trigger:'.gs-listing-hero',start:'top top',end:'bottom top',scrub:1.5},y:'22%',scale:1.08,ease:'none'});
  },
  microInteractions:function(){
    document.querySelectorAll('.gs-service-card').forEach(function(c){
      c.addEventListener('mouseenter',function(){gsap.to(this,{y:-4,scale:1.02,duration:.28,ease:'power2.out'});});
      c.addEventListener('mouseleave',function(){gsap.to(this,{y:0,scale:1,duration:.28,ease:'power2.inOut'});});
    });
    document.querySelectorAll('.gs-listing-cta-group .gs-btn').forEach(function(b){
      b.addEventListener('mouseenter',function(){gsap.to(this,{y:-2,scale:1.04,duration:.2,ease:'power2.out'});});
      b.addEventListener('mouseleave',function(){gsap.to(this,{y:0,scale:1,duration:.2,ease:'power2.inOut'});});
    });
  },
  initFallback:function(){
    if(!('IntersectionObserver' in window))return;
    var io=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting){e.target.classList.add('gs-animated');io.unobserve(e.target);}});},{threshold:.12});
    document.querySelectorAll('[data-gsap],[data-gsap-stagger]').forEach(function(el){io.observe(el);});
    var cio=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting){
      var el=e.target,target=parseInt(el.getAttribute('data-target')||el.textContent)||0,suffix=el.getAttribute('data-suffix')||'';
      var s=performance.now(),dur=1800;
      function step(n){var p=Math.min((n-s)/dur,1),v=1-Math.pow(1-p,3);el.textContent=GS_Core.formatNum(Math.floor(v*target))+suffix;if(p<1)requestAnimationFrame(step);}
      requestAnimationFrame(step);cio.unobserve(el);}});},{threshold:.3});
    document.querySelectorAll('.gs-stat-number[data-target]').forEach(function(el){cio.observe(el);});
  }
};

/* ═══ MODULE 6 — SIDEBAR & NAV ════════════════════════════════ */
var GS_Nav={
  init:function(){
    $(document).on('click','#gs-sidebar-toggle',function(){GS_Nav.toggle();});
    $(document).on('click','#gs-sidebar-overlay',function(){GS_Nav.close();});
    $(document).on('keydown',function(e){if(e.key==='Escape')GS_Nav.close();});
    if(window.innerWidth<=1024&&!$('#gs-sidebar-toggle').length){
      $('<button id="gs-sidebar-toggle" aria-label="Menu" style="position:fixed;top:14px;left:14px;z-index:400;background:var(--gs-navy);color:white;border:none;border-radius:10px;width:42px;height:42px;font-size:1.3rem;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:var(--gs-shadow-lg)">☰</button>').appendTo('body');
    }
    $(window).on('resize',GS_Core.debounce(function(){if(window.innerWidth>1024)GS_Nav.close();$('#gs-sidebar-toggle').toggle(window.innerWidth<=1024);},150));
  },
  toggle:function(){$('.gs-sidebar,.gs-admin-sidebar,.gs-vd-sidebar').hasClass('open')?GS_Nav.close():GS_Nav.open();},
  open:function(){
    $('.gs-sidebar,.gs-admin-sidebar,.gs-vd-sidebar').addClass('open');
    if(!$('#gs-sidebar-overlay').length)$('<div id="gs-sidebar-overlay" style="position:fixed;inset:0;background:rgba(15,23,42,.6);z-index:299;backdrop-filter:blur(3px)"></div>').appendTo('body').hide().fadeIn(200);
    else $('#gs-sidebar-overlay').fadeIn(200);
  },
  close:function(){
    $('.gs-sidebar,.gs-admin-sidebar,.gs-vd-sidebar').removeClass('open');
    $('#gs-sidebar-overlay').fadeOut(200,function(){$(this).remove();});
  }
};

/* ═══ MODULE 7 — TABS ══════════════════════════════════════════ */
$(document).on('click','.gs-tab',function(){
  var $t=$(this),target=$t.data('tab'),$wrap=$t.closest('[data-tabs],.gs-tabs-wrap');
  $wrap.find('.gs-tab').removeClass('active');$wrap.find('.gs-tab-pane').removeClass('active');
  $t.addClass('active');$wrap.find('#'+target+',[data-pane="'+target+'"]').addClass('active');
  history.replaceState(null,null,'#'+target);
});

/* ═══ MODULE 8 — FAQ ═══════════════════════════════════════════ */
$(document).on('click','.gs-faq-question',function(){
  var $i=$(this).closest('.gs-faq-item'),open=$i.hasClass('open');
  $i.closest('.gs-faq-list').find('.gs-faq-item').removeClass('open');
  if(!open)$i.addClass('open');
});

/* ═══ MODULE 9 — LIGHTBOX ══════════════════════════════════════ */
var LB={imgs:[],idx:0,_trigger:null,
  open:function(imgs,i){this._trigger=document.activeElement;this.imgs=imgs;this.idx=i;this.render();},
  render:function(){
    var s=this,img=this.imgs[this.idx];
    $('#gs-lightbox').remove();
    var $l=$('<div id="gs-lightbox" class="gs-lightbox" role="dialog" aria-modal="true" aria-label="Image '+(this.idx+1)+' of '+this.imgs.length+'">'
      +'<button class="gs-lightbox-close" aria-label="Close lightbox">✕</button>'
      +(this.imgs.length>1?'<button class="gs-lightbox-nav gs-lightbox-prev" aria-label="Previous image">←</button>':'')
      +'<img class="gs-lightbox-img" src="'+img.src+'" alt="'+(img.alt||'Gallery image '+(this.idx+1))+'">'
      +(this.imgs.length>1?'<button class="gs-lightbox-nav gs-lightbox-next" aria-label="Next image">→</button>':'')
      +'<div style="position:absolute;bottom:20px;left:50%;transform:translateX(-50%);color:rgba(255,255,255,.6);font-size:.8rem" aria-live="polite">'+(this.idx+1)+'/'+this.imgs.length+'</div>'
      +'</div>');
    $('body').append($l);
    if(typeof gsap!=='undefined')gsap.from('#gs-lightbox .gs-lightbox-img',{scale:.86,opacity:0,duration:.35,ease:'power3.out'});
    $l.on('click',function(e){if($(e.target).is('#gs-lightbox'))s.close();});
    $l.find('.gs-lightbox-close').on('click',function(){s.close();});
    $l.find('.gs-lightbox-prev').on('click',function(){s.prev();});
    $l.find('.gs-lightbox-next').on('click',function(){s.next();});
    // A11Y FIX #3: Focus first button in lightbox
    $l.find('button').first().focus();
    // A11Y FIX #3: Trap focus inside lightbox
    $l.on('keydown',function(e){
      if(e.key==='Escape'){s.close();return;}
      if(e.key!=='Tab')return;
      var $btns=$l.find('button');
      var first=$btns.first()[0],last=$btns.last()[0];
      if(e.shiftKey){if(document.activeElement===first){e.preventDefault();last.focus();}}
      else{if(document.activeElement===last){e.preventDefault();first.focus();}}
    });
  },
  close:function(){
    $('#gs-lightbox').remove();
    // A11Y FIX #3: Return focus to the gallery item that opened the lightbox
    if(LB._trigger&&typeof LB._trigger.focus==='function'){try{LB._trigger.focus();}catch(e){}}
    LB._trigger=null;
  },
  prev:function(){this.idx=(this.idx-1+this.imgs.length)%this.imgs.length;this.render();},
  next:function(){this.idx=(this.idx+1)%this.imgs.length;this.render();}
};
$(document).on('click','.gs-gallery-item',function(){
  var imgs=[];$(this).closest('.gs-gallery-grid').find('.gs-gallery-item img').each(function(){imgs.push({src:$(this).attr('src'),alt:$(this).attr('alt')||''});});
  LB.open(imgs,$(this).index());
});
$(document).on('keydown',function(e){if(!$('#gs-lightbox').length)return;if(e.key==='ArrowLeft')LB.prev();if(e.key==='ArrowRight')LB.next();if(e.key==='Escape')LB.close();});

/* ═══ MODULE 10 — SCROLL SPY ════════════════════════════════════ */
var GS_Spy={init:function(){
  var $items=$('.gs-section-nav-item');if(!$items.length)return;
  var io=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting){var id=e.target.id;$items.removeClass('active').filter('[data-section="'+id+'"]').addClass('active');}});},{rootMargin:'-30% 0px -60% 0px'});
  $items.each(function(){var s=document.getElementById($(this).data('section'));if(s)io.observe(s);});
  $items.on('click',function(){GS_Scroll.scrollTo('#'+$(this).data('section'),{offset:-80});});
}};

/* ═══ MODULE 11 — FORMS ════════════════════════════════════════ */
$(document).on('submit','#gs-lead-form,#gs-sidebar-lead-form',function(e){
  e.preventDefault();var $f=$(this),$b=$f.find('[type=submit]');GS_Core.btnLoading($b,true,'Sending…');
  var d={};$f.serializeArray().forEach(function(f){d[f.name]=f.value;});
  GS_Core.post('gs_submit_lead',d,function(r){GS_Core.btnLoading($b,false);GS_Toast.show(r.message||'Request sent!','success');$f[0].reset();},function(m){GS_Core.btnLoading($b,false);GS_Toast.show(m,'error');});
});
$(document).on('submit','#gs-review-form',function(e){
  e.preventDefault();var $f=$(this),$b=$f.find('[type=submit]');
  if(!$f.find('.gs-star-picker input').val()||$f.find('.gs-star-picker input').val()==='0'){GS_Toast.show('Please select a rating.','warning');return;}
  GS_Core.btnLoading($b,true,'Submitting…');
  var d={};$f.serializeArray().forEach(function(f){d[f.name]=f.value;});
  GS_Core.post('gs_submit_review',d,function(r){GS_Core.btnLoading($b,false);GS_Toast.show(r.message||'Review submitted!','success');$f[0].reset();},function(m){GS_Core.btnLoading($b,false);GS_Toast.show(m,'error');});
});
window.gsShowLeadPopup=function(listingId,productName){
  var html='<form id="gs-popup-lead">'+(productName?'<div style="background:#EFF6FF;padding:10px 14px;border-radius:8px;margin-bottom:14px;font-size:.86rem">📦 Enquiry for: <strong>'+productName+'</strong></div>':'')
    +'<input type="hidden" name="listing_id" value="'+listingId+'"><input type="hidden" name="source" value="quote_popup">'
    +'<div class="gs-form-group"><label class="gs-form-label">Name *</label><input name="name" class="gs-input" required placeholder="Your name"></div>'
    +'<div class="gs-form-group"><label class="gs-form-label">Phone *</label><input name="phone" class="gs-input" type="tel" required placeholder="10-digit mobile"></div>'
    +'<div class="gs-form-group"><label class="gs-form-label">Email</label><input name="email" class="gs-input" type="email" placeholder="your@email.com"></div>'
    +'<div class="gs-form-group"><label class="gs-form-label">Message</label><textarea name="message" class="gs-textarea" rows="3" placeholder="What do you need?"></textarea></div></form>';
  GS_Modal.show(html,{title:'📋 Get a Free Quote',size:'sm',
    footer:'<button class="gs-btn gs-btn-ghost gs-btn-md" onclick="gsModal.hide()">Cancel</button><button class="gs-btn gs-btn-primary gs-btn-md" id="gs-popup-send">Send Request</button>'});
  $('#gs-popup-send').on('click',function(){
    var $b=$(this);GS_Core.btnLoading($b,true,'Sending…');
    var d={};$('#gs-popup-lead').serializeArray().forEach(function(f){d[f.name]=f.value;});
    GS_Core.post('gs_submit_lead',d,function(r){GS_Core.btnLoading($b,false);GS_Modal.hide();GS_Toast.show(r.message||'Sent!','success');},function(m){GS_Core.btnLoading($b,false);GS_Toast.show(m,'error');});
  });
};

/* ═══ MODULE 12 — STAR PICKER ══════════════════════════════════ */
$(document).on('click','.gs-star-picker .gs-star',function(){
  var v=parseInt($(this).data('value')),$p=$(this).closest('.gs-star-picker');
  $p.find('.gs-star').each(function(){$(this).toggleClass('filled',parseInt($(this).data('value'))<=v).css('color','');});
  $p.find('input[type=hidden]').val(v);
});
$(document).on('mouseenter','.gs-star-picker .gs-star',function(){
  var v=parseInt($(this).data('value'));$(this).closest('.gs-star-picker').find('.gs-star').each(function(){$(this).css('color',parseInt($(this).data('value'))<=v?'var(--gs-gold)':'var(--gs-border)');});
});
$(document).on('mouseleave','.gs-star-picker',function(){
  var cur=parseInt($(this).find('input').val())||0;$(this).find('.gs-star').each(function(){$(this).css('color',parseInt($(this).data('value'))<=cur?'var(--gs-gold)':'');});
});

/* ═══ MODULE 13 — MEDIA UPLOAD ═════════════════════════════════ */
var GS_Media={
  init:function(){
    $('.gs-file-upload').each(function(){
      var $z=$(this),$i=$z.find('input[type=file]');
      $z.on('click',function(e){if(!$(e.target).is('input'))$i.trigger('click');});
      $z.on('dragover',function(e){e.preventDefault();$z.addClass('dragover');});
      $z.on('dragleave',function(){$z.removeClass('dragover');});
      $z.on('drop',function(e){e.preventDefault();$z.removeClass('dragover');var f=e.originalEvent.dataTransfer.files;if(f.length)GS_Media.upload(f[0],$z);});
    });
  },
  upload:function(file,$ctx,cb){
    var fd=new FormData();fd.append('action','gs_upload_media');fd.append('nonce',GS.nonce);fd.append('file',file);
    if($ctx)$ctx.find('.gs-file-upload-text').text('Uploading…');
    $.ajax({url:GS.ajax_url,method:'POST',data:fd,processData:false,contentType:false,
      success:function(r){
        if(r.success){GS_Toast.show('Image uploaded!','success');if(typeof cb==='function')cb(r.data);if($ctx)$ctx.find('.gs-file-upload-text').text('Click or drag to upload');}
        else{GS_Toast.show(r.data&&r.data.message?r.data.message:'Upload failed.','error');if($ctx)$ctx.find('.gs-file-upload-text').text('Click or drag image to upload');}
      },error:function(){GS_Toast.show('Upload failed.','error');}
    });
  }
};
window.gsUploadFile=GS_Media.upload.bind(GS_Media);

/* ═══ MODULE 14 — EVENT TRACKING ══════════════════════════════ */
$(document).on('click','[data-track]',function(){
  var ev=$(this).data('track'),lid=$(this).data('listing-id')||$('[data-listing-id]').first().data('listing-id');
  if(lid)GS_Core.post('gs_track_event',{listing_id:lid,event_type:ev});
});

/* ═══ MODULE 15 — SAVE BOOKMARK ════════════════════════════════ */
$(document).on('click','.gs-listing-card-save,.gs-save-btn',function(){
  var $b=$(this),id=$b.data('listing-id');
  if(!GS.is_logged_in){GS_Toast.show('Please login to save listings.','warning');return;}
  GS_Core.post('gs_save_listing_bookmark',{listing_id:id},function(d){
    $b.html(d.saved?'❤️':'🤍');
    if(d.saved&&typeof gsap!=='undefined')gsap.from($b[0],{scale:1.5,duration:.4,ease:'elastic.out(1,.5)'});
    GS_Toast.show(d.message,d.saved?'success':'info');
  });
});

/* ═══ MODULE 16 — NOTIFICATIONS ════════════════════════════════ */
var GS_Notif={loaded:false,
  init:function(){
    $(document).on('click','#gs-notif-toggle',function(e){
      e.stopPropagation();var $p=$('#gs-notif-panel');
      if($p.is(':visible')){$p.fadeOut(150);return;}$p.fadeIn(150);if(!GS_Notif.loaded)GS_Notif.load();
    });
    $(document).on('click',function(e){if(!$(e.target).closest('#gs-notif-toggle,#gs-notif-panel').length)$('#gs-notif-panel').fadeOut(150);});
    $(document).on('click','#gs-notif-mark-all',function(){GS_Core.post('gs_mark_all_notifications_read',{},function(){$('.gs-notif-item').removeClass('unread').css('background','');$('#gs-notif-badge').text('').hide();GS_Notif.loaded=false;});});
    setInterval(GS_Notif.poll,60000);
  },
  load:function(){
    GS_Notif.loaded=true;
    var $l=$('#gs-notif-panel .gs-notif-list').html('<div style="padding:20px;text-align:center"><div class="gs-skeleton" style="height:50px;border-radius:8px;margin-bottom:8px"></div><div class="gs-skeleton" style="height:50px;border-radius:8px"></div></div>');
    GS_Core.post('gs_get_notifications',{},function(d){
      $l.empty();
      if(!d.notifications||!d.notifications.length){$l.html('<p style="text-align:center;padding:24px;color:#94A3B8;font-size:.84rem">No notifications yet.</p>');return;}
      var icons={'listing.approved':'✅','listing.rejected':'❌','lead.new':'📞','review.approved':'⭐','payment.success':'💳','complaint.new':'⚠️','message.new':'💬','subscription.expiring':'⏰','vendor.verified':'🛡️'};
      d.notifications.forEach(function(n){
        var $i=$('<div class="gs-notif-item'+(n.is_read?'':' unread')+'" data-id="'+n.id+'">'
          +'<div class="gs-notif-icon" style="background:'+(n.color||'#EFF6FF')+'22">'+(icons[n.type]||'🔔')+'</div>'
          +'<div class="gs-notif-body"><div class="gs-notif-item-title">'+$('<div>').text(n.title).html()+'</div>'
          +(n.message?'<div class="gs-notif-item-msg">'+$('<div>').text(n.message).html()+'</div>':'')
          +'<div class="gs-notif-item-time">'+n.created_at+'</div></div></div>');
        $i.on('click',function(){GS_Core.post('gs_mark_notification_read',{notification_id:n.id});$(this).removeClass('unread').css('background','');if(n.action_url)window.location.href=n.action_url;});
        $l.append($i);
      });
      $('#gs-notif-badge').text(d.unread||'').toggle(d.unread>0);
    });
  },
  poll:function(){
    if(!GS.is_logged_in)return;
    GS_Core.post('gs_get_notifications',{},function(d){
      var c=d.unread||0;$('#gs-notif-badge').text(c||'').toggle(c>0);
      var t=document.title.replace(/^\(\d+\)\s*/,'');document.title=c>0?'('+c+') '+t:t;
    });
  }
};

/* ═══ MODULE 17 — MESSAGING ════════════════════════════════════ */
var GS_Msg={thread:null,pollTimer:null,
  init:function(){
    $(document).on('click','.gs-msg-thread-item',function(){GS_Msg.load($(this).data('thread'));});
    $(document).on('click','#gs-msg-send-btn',function(){GS_Msg.send();});
    $('#gs-msg-input').on('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();GS_Msg.send();}})
      .on('input',function(){this.style.height='44px';this.style.height=Math.min(this.scrollHeight,120)+'px';});
  },
  load:function(id){
    // UI FIX #5: Clear any existing poll timer before starting a new one.
    // Previously timers accumulated when switching threads, causing multiple
    // overlapping AJAX poll loops.
    if(GS_Msg.pollTimer){clearInterval(GS_Msg.pollTimer);GS_Msg.pollTimer=null;}
    GS_Msg.thread=id;
    $('.gs-msg-thread-item').removeClass('active').filter('[data-thread="'+id+'"]').addClass('active');
    var $m=$('#gs-msg-chat-messages').html('<div class="gs-skeleton" style="height:60px;border-radius:12px;margin:10px 0"></div>'.repeat(3));
    GS_Core.post('gs_get_messages',{thread_id:id},function(d){
      $m.empty();
      if(!d.messages||!d.messages.length){$m.html('<div style="text-align:center;padding:40px;color:#94A3B8;font-size:.86rem">No messages yet. Start the conversation!</div>');return;}
      d.messages.forEach(function(msg){$m.append(GS_Msg.bubble(msg));});
      $m.scrollTop($m[0].scrollHeight);
      var lastId=d.messages.slice(-1)[0].id;
      GS_Msg.pollTimer=setInterval(function(){GS_Msg.poll(id,lastId);},5000);
    });
  },
  poll:function(tid,since){
    GS_Core.post('gs_get_messages_since',{thread_id:tid,since_id:since},function(d){
      if(!d.messages||!d.messages.length)return;
      var $m=$('#gs-msg-chat-messages');
      d.messages.forEach(function(msg){$m.append(GS_Msg.bubble(msg));});
      $m.scrollTop($m[0].scrollHeight);
    });
  },
  bubble:function(m){
    var mine=parseInt(m.sender_id)===parseInt(GS.user_id);
    return $('<div class="gs-msg-bubble-wrap '+(mine?'mine':'theirs')+'"><div class="gs-msg-bubble '+(mine?'mine':'theirs')+'">'+$('<div>').text(m.message).html().replace(/\n/g,'<br>')+'</div><div class="gs-msg-time">'+(m.time||m.created_at||'')+'</div></div>');
  },
  send:function(){
    var $i=$('#gs-msg-input'),msg=$.trim($i.val());
    if(!msg||!GS_Msg.thread)return;
    var $b=$('#gs-msg-send-btn');$b.prop('disabled',true);
    GS_Core.post('gs_send_message',{thread_id:GS_Msg.thread,message:msg},function(){
      $b.prop('disabled',false);$i.val('').css('height','44px').focus();
      var $m=$('#gs-msg-chat-messages');
      $m.append(GS_Msg.bubble({sender_id:GS.user_id,message:msg,time:'Just now'}));
      $m.scrollTop($m[0].scrollHeight);
      if(typeof gsap!=='undefined')gsap.from($m.children().last()[0],{opacity:0,y:10,duration:.3,ease:'power2.out'});
    },function(m){$b.prop('disabled',false);GS_Toast.show(m,'error');});
  }
};
window.gsLoadThread=function(id){GS_Msg.load(id);};

/* ═══ MODULE 18 — SEARCH ═══════════════════════════════════════ */
var GS_Search={timer:null,
  init:function(){
    $(document).on('input','#gs-keyword-search',function(){clearTimeout(GS_Search.timer);GS_Search.timer=setTimeout(function(){GS_Search.run(1);},380);});
    $(document).on('change','#gs-city-filter,#gs-category-filter,#gs-sort-filter',function(){GS_Search.run(1);});
    $(document).on('change','input[name="gs-rating"],input[name="gs-type"]',function(){GS_Search.run(1);});
  },
  run:function(page){
    page=page||1;var p=new URLSearchParams();
    var kw=$('#gs-keyword-search').val(),ci=$('#gs-city-filter').val(),ca=$('#gs-category-filter').val(),so=$('#gs-sort-filter').val();
    var ra=$('input[name="gs-rating"]:checked').val(),ty=$('input[name="gs-type"]:checked').val();
    if(kw)p.set('keyword',kw);if(ci)p.set('city',ci);if(ca)p.set('category_id',ca);if(so)p.set('sort',so);if(ra)p.set('min_rating',ra);if(ty)p.set('type',ty);if(page>1)p.set('page',page);
    window.location.href=(GS.home_url||'/')+'directory/?'+p.toString();
  }
};
window.gsRunSearch=GS_Search.run.bind(GS_Search);

/* ═══ MODULE 19 — ADMIN ACTIONS ════════════════════════════════ */
var GS_Admin={init:function(){
  // FIXED (v7.319.0, reported directly: "approving a listing removes it from
  // the current list, I have to reload to see it again"). Two separate bugs
  // were found here, both contributing to that report:
  //
  // 1. This delegated handler and the Admin Listings screen's own inline
  //    onclick="gsDirectApprove(...)" handler (templates/pages/
  //    admin-dashboard.php) BOTH match any button with class
  //    "gs-approve-listing" — including the exact same buttons, since
  //    admin-dashboard.php's buttons carry both the class AND the inline
  //    onclick. Wherever jQuery/this script successfully loads on that page,
  //    a single click fired BOTH handlers: two confirm dialogs, and if both
  //    were accepted, gs_approve_listing was posted twice (a harmless
  //    idempotent DB write, but a real risk of a duplicate "listing
  //    approved" notification going out to the vendor), and — critically —
  //    THIS handler's own success callback still ran $b.closest(...).
  //    fadeOut().remove(), silently undoing gsDirectApprove()'s in-place
  //    status update and removing the row from the DOM regardless of what
  //    the page-specific handler had just done. Guarded with an early
  //    return when the button already carries an inline onclick, which is
  //    exactly how a page opts a button out of this shared delegated
  //    handler in favor of its own — the pattern already established
  //    elsewhere in this codebase for the same reason (see gsDirectApprove's
  //    own comments in admin-dashboard.php). Pages with no inline onclick
  //    (e.g. the staff moderation queue in other-dashboards.php) are
  //    completely unaffected — this only skips buttons a page has already
  //    claimed for itself.
  //
  // 2. Independently of (1): even on a page where this IS the only handler,
  //    fadeOut+remove permanently discards the row from the DOM, which is
  //    the literal "listing disappears from the list" behavior reported.
  //    Left as-is here deliberately — other-dashboards.php's moderation
  //    queue is a work QUEUE (its entire purpose is that handled items
  //    leave the queue), unlike the Admin Listings screen's persistent
  //    record table, which is why that screen's fix (in admin-dashboard.php)
  //    takes the different, in-place-update approach instead of just
  //    reusing this function.
  $(document).on('click','.gs-approve-listing',function(){
    if (this.getAttribute('onclick')) return; // already owned by a page-specific handler
    var $b=$(this),id=$b.data('id');
    GS_Modal.confirm('Approve this listing? It will go live immediately.',function(){
      GS_Core.btnLoading($b,true,'…');
      GS_Core.post('gs_approve_listing',{listing_id:id},function(){
        GS_Toast.show('Listing approved!','success');
        $b.closest('tr,.gs-listing-row,div').fadeOut(400,function(){$(this).remove();});
      },function(msg){
        GS_Core.btnLoading($b,false);
        GS_Toast.show(msg||'Could not approve listing. Please try again.','error');
      });
    },{confirmText:'✅ Approve',title:'Approve Listing'});
  });
  $(document).on('click','.gs-reject-listing',function(){
    var $b=$(this),id=$b.data('id');
    GS_Modal.show('<div class="gs-form-group"><label class="gs-form-label">Rejection Reason *</label><textarea id="gs-reject-reason" class="gs-textarea" rows="3" placeholder="Explain what needs to be fixed..."></textarea></div>',{title:'Reject Listing',size:'sm',footer:'<button class="gs-btn gs-btn-ghost gs-btn-md" onclick="gsModal.hide()">Cancel</button><button class="gs-btn gs-btn-red gs-btn-md" id="gs-do-reject">❌ Reject</button>'});
    $('#gs-do-reject').on('click',function(){var r=$.trim($('#gs-reject-reason').val());if(!r){GS_Toast.show('Rejection reason required.','warning');return;}GS_Core.post('gs_reject_listing',{listing_id:id,reason:r},function(){GS_Modal.hide();GS_Toast.show('Listing rejected.','info');$b.closest('tr,.gs-listing-row,div').fadeOut(400,function(){$(this).remove();});});});
  });
  $(document).on('click','.gs-approve-review',function(){
    var $b=$(this),id=$b.data('id'),$row=$b.closest('tr,.gs-review-row,.gs-card');
    GS_Core.post('gs_approve_review',{review_id:id},function(){GS_Toast.show('Review approved!','success');$row.find('.gs-badge').replaceWith('<span class="gs-badge gs-badge-green">✓ Approved</span>');$b.remove();});
  });
  $(document).on('click','.gs-reject-review',function(){
    var $b=$(this),id=$b.data('id');
    GS_Core.post('gs_reject_review',{review_id:id},function(){GS_Toast.show('Review rejected.','info');$b.closest('tr,.gs-review-row,.gs-card').fadeOut(400,function(){$(this).remove();});});
  });
  $(document).on('click','.gs-verify-vendor',function(){
    var $b=$(this),id=$b.data('id');
    GS_Modal.confirm('Verify this vendor? A Verified badge will appear on all their listings.',function(){GS_Core.post('gs_verify_vendor',{vendor_user_id:id,status:'verified'},function(){GS_Toast.show('Vendor verified!','success');setTimeout(function(){location.reload();},900);});},{confirmText:'✅ Verify',title:'Verify Vendor'});
  });
  $(document).on('click','.gs-resolve-error',function(){
    var $b=$(this),id=$b.data('id');
    GS_Core.post('gs_resolve_error',{error_id:id},function(){GS_Toast.show('Marked resolved.','success');$b.closest('tr').css('opacity','.45');$b.remove();});
  });
  $(document).on('click','#gs-save-settings',function(){
    var $b=$(this),settings={};
    $('.gs-settings-field').each(function(){var k=$(this).data('key');if(!k)return;var v=$(this).is(':checkbox')?($(this).is(':checked')?'1':'0'):$(this).val();if(v!=='●●●●●●●●')settings[k]=v;});
    GS_Core.btnLoading($b,true,'Saving…');
    GS_Core.post('gs_save_settings',{settings:settings},function(){GS_Core.btnLoading($b,false);GS_Toast.show('Settings saved!','success');},function(m){GS_Core.btnLoading($b,false);GS_Toast.show(m,'error');});
  });
}};

/* ═══ MODULE 20 — DROPDOWNS ════════════════════════════════════ */
$(document).on('click','.gs-dropdown-toggle',function(e){
  e.stopPropagation();var $m=$(this).siblings('.gs-dropdown-menu');$('.gs-dropdown-menu').not($m).hide();$m.toggle();
});
$(document).on('click',function(e){if(!$(e.target).closest('.gs-dropdown').length)$('.gs-dropdown-menu').hide();});

/* ═══ MODULE 21 — SCROLL UTILITIES ════════════════════════════ */
var GS_ScrollUtil={lastST:0,
  init:function(){
    var $bt=$('.gs-back-top'),$ms=$('.gs-mobile-sticky');
    $(window).on('scroll',GS_Core.throttle(function(){
      var st=$(this).scrollTop();$bt.toggleClass('visible',st>400);
      if($ms.length){if(st>GS_ScrollUtil.lastST+50)$ms.css({transform:'translateY(100%)'});else if(st<GS_ScrollUtil.lastST-20)$ms.css({transform:''});}
      GS_ScrollUtil.lastST=st;
    },50));
    $bt.on('click',function(){GS_Scroll.scrollTo(0,{duration:1.2});});
  }
};

/* ═══ MODULE 22 — REPEATER FIELDS ══════════════════════════════ */
$(document).on('click','.gs-repeater-add',function(){
  var tgt=$(this).data('target');
  var $rep=tgt?$('#'+tgt):$(this).closest('.gs-form-group').find('.gs-repeater');
  if(!$rep.length)return;
  var tmpl=$rep.data('template');if(!tmpl)return;
  var idx=$rep.children('.gs-repeater-item').length;
  var html=tmpl.replace(/\[0\]/g,'['+idx+']').replace(/_0_/g,'_'+idx+'_');
  var $item=$('<div class="gs-repeater-item">'+html+'<button type="button" class="gs-btn gs-btn-xs gs-btn-danger gs-repeater-remove" style="position:absolute;top:10px;right:10px">✕</button></div>');
  if(typeof gsap!=='undefined'){$item.css({opacity:0,transform:'translateY(10px)'});$rep.append($item);gsap.to($item[0],{opacity:1,y:0,duration:.3,ease:'power2.out'});}
  else $rep.append($item);
});
$(document).on('click','.gs-repeater-remove',function(){
  var $item=$(this).closest('.gs-repeater-item');
  if(typeof gsap!=='undefined')gsap.to($item[0],{opacity:0,height:0,margin:0,padding:0,duration:.3,ease:'power2.in',onComplete:function(){$item.remove();}});
  else $item.remove();
});

/* ═══ MODULE 23 — AI CONTENT GEN ══════════════════════════════ */
$(document).on('click','#gs-ai-generate,.gs-ai-generate',function(){
  if(!GS.ai_enabled){GS_Toast.show('AI assist requires Professional plan.','warning');return;}
  var $b=$(this),type=$b.data('type')||'description',$t=$($b.data('target'));
  GS_Core.btnLoading($b,true,'✨ Generating…');
  GS_Core.post('gs_ai_generate_content',{type:type,business_name:$('#gs-field-title,#gs-field-business_name').first().val(),category:$('#gs-field-category').find('option:selected').text(),city:$('#gs-field-city').val(),services:''},
    function(d){GS_Core.btnLoading($b,false);if($t.is('textarea'))$t.val(d.content).trigger('input');else if($t.length)$t.html(d.content);GS_Toast.show('Content generated!','success');},
    function(m){GS_Core.btnLoading($b,false);GS_Toast.show(m,'error');}
  );
});

/* ═══ MODULE 24 — MISC GLOBAL FUNCTIONS ════════════════════════ */
window.gsHeroSearch=function(){
  var kw=$('#gs-hero-keyword').val(),city=$('#gs-hero-city').val(),cat=$('#gs-hero-cat').val();
  var url=(GS.home_url||'/')+'directory/?';
  if(kw)url+='keyword='+encodeURIComponent(kw)+'&';if(city)url+='city='+encodeURIComponent(city)+'&';if(cat)url+='category_id='+encodeURIComponent(cat)+'&';
  window.location.href=url;
};
$(document).on('keydown','#gs-hero-keyword',function(e){if(e.key==='Enter')gsHeroSearch();});
window.gsSetView=function(v){$('#gs-list-view-btn').toggleClass('active',v==='grid');$('#gs-map-view-btn').toggleClass('active',v==='map');if(v==='map'){$('#gs-map-container').show();$('#gs-results-grid').hide();}else{$('#gs-map-container').hide();$('#gs-results-grid').show();}};
window.gsAddCityTag=function(c){$('#gs-service-cities-tags').append('<span style="background:var(--gs-primary-l);color:var(--gs-primary);padding:4px 12px;border-radius:20px;font-size:.8rem;display:inline-flex;align-items:center;gap:6px;font-weight:600">'+c+'<button type="button" onclick="this.parentElement.remove();gsUpdateServiceCities()" style="background:none;border:none;cursor:pointer;color:var(--gs-text-3)">✕</button></span>');gsUpdateServiceCities();};
window.gsUpdateServiceCities=function(){var c=[];$('#gs-service-cities-tags span').each(function(){c.push($(this).text().replace('✕','').trim());});$('#gs-field-service_cities').val(JSON.stringify(c));};
window.gsInitiatePayment=function(planId,amount){GS_Modal.show('<p style="font-size:.88rem;color:#475569;margin-bottom:14px">Configure payment gateway in Settings → Payment to accept payments.</p><input type="hidden" id="gs-plan-amount" value="'+amount+'"><div class="gs-form-group"><label class="gs-form-label">Coupon Code</label><div style="display:flex;gap:8px"><input id="gs-coupon-input" class="gs-input" placeholder="Optional"><button class="gs-btn gs-btn-ghost gs-btn-md" type="button" id="gs-apply-coupon">Apply</button></div><div id="gs-discount-row" style="display:none;margin-top:8px;font-size:.86rem;color:var(--gs-green)">Discount: <span class="gs-discount-val"></span></div></div><div style="background:var(--gs-green-l);border-radius:10px;padding:14px;text-align:center"><div id="gs-total-amount" style="font-size:1.8rem;font-weight:900;color:var(--gs-green)">'+(GS.currency_sym||'₹')+parseFloat(amount).toFixed(2)+'</div></div>',{title:'Complete Subscription',size:'sm',footer:'<button class="gs-btn gs-btn-ghost gs-btn-md" onclick="gsModal.hide()">Cancel</button><button class="gs-btn gs-btn-primary gs-btn-md" onclick="gsToast(\'Configure payment gateway in Settings.\',\'info\')">Proceed to Payment</button>'});};

/* ═══ VENDOR PROFILE SAVE ═══════════════════════════════════════ */
$(document).on('click','#gs-save-profile',function(){
  var $b=$(this);GS_Core.btnLoading($b,true,'Saving…');
  var social={};$('.gs-social-field').each(function(){if($(this).val())social[$(this).data('social')]=$(this).val();});
  GS_Core.post('gs_save_vendor_profile',{business_name:$('#gs-prof-business_name').val(),phone:$('#gs-prof-phone').val(),whatsapp:$('#gs-prof-whatsapp').val(),email:$('#gs-prof-email').val(),website:$('#gs-prof-website').val(),bio:$('#gs-prof-bio').val(),address:$('#gs-prof-address').val(),city:$('#gs-prof-city').val(),state:$('#gs-prof-state').val(),pincode:$('#gs-prof-pincode').val(),gst_number:$('#gs-prof-gst_number').val(),pan_number:$('#gs-prof-pan_number').val(),logo_url:$('#gs-prof-logo_url').val(),social_links:JSON.stringify(social)},
    function(){GS_Core.btnLoading($b,false);GS_Toast.show('Profile saved!','success');},function(m){GS_Core.btnLoading($b,false);GS_Toast.show(m,'error');});
});

/* ═══ COUPON ════════════════════════════════════════════════════ */
$(document).on('click','#gs-apply-coupon',function(){
  var code=$('#gs-coupon-input').val(),amount=parseFloat($('#gs-plan-amount').val()||0);
  if(!code){GS_Toast.show('Enter a coupon code.','warning');return;}
  GS_Core.post('gs_validate_coupon',{code:code,amount:amount},function(d){
    var sym=GS.currency_sym||'₹';$('#gs-discount-row').show().find('.gs-discount-val').text('- '+sym+d.discount);$('#gs-total-amount').text(sym+(amount-d.discount).toFixed(2));$('#gs-coupon-code-hidden').val(code);GS_Toast.show(d.message,'success');
  },function(m){GS_Toast.show(m,'error');});
});

/* ═══ DOM READY ═════════════════════════════════════════════════ */
$(function(){
  GS_Nav.init();
  GS_ScrollUtil.init();
  GS_Media.init();
  GS_Spy.init();
  GS_Scroll.init();
  GS_Animations.init();
  if(GS.is_logged_in&&$('#gs-notif-toggle').length)GS_Notif.init();
  if($('.gs-msg-layout').length)GS_Msg.init();
  if($('#gs-results-grid').length)GS_Search.init();
  if(GS.is_admin)GS_Admin.init();
  // Hash-based tab restoration
  var hash=window.location.hash.replace('#','');
  if(hash&&$('.gs-tab[data-tab="'+hash+'"]').length)$('.gs-tab[data-tab="'+hash+'"]').trigger('click');
  // First messaging thread
  var ft=$('.gs-msg-thread-item').first().data('thread');
  if(ft)GS_Msg.load(ft);
  // Short desc counter
  $(document).on('input','#gs-field-short_desc',function(){var c=$('#gs-short-desc-count');if(c.length)c.text($(this).val().length);});
  $('#gs-field-short_desc').trigger('input');
  // Service cities tag input
  $(document).on('keydown','#gs-service-cities-input',function(e){if(e.key==='Enter'||e.key===','){e.preventDefault();var v=$(this).val().trim().replace(/,/g,'');if(v){gsAddCityTag(v);$(this).val('');}}});
  // Add sidebar toggle if needed on mobile
  if(window.innerWidth<=1024&&!$('#gs-sidebar-toggle').length){
    $('<button id="gs-sidebar-toggle" aria-label="Menu" style="position:fixed;top:14px;left:14px;z-index:400;background:var(--gs-navy);color:white;border:none;border-radius:10px;width:42px;height:42px;font-size:1.3rem;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:var(--gs-shadow-lg)">☰</button>').appendTo('body');
  }
});

})(jQuery);

/* ══════════════════════════════════════════════════════════════════════════
   GoodService PWA & Push Notifications — Part 2
   ══════════════════════════════════════════════════════════════════════════ */

/**
 * v7.475.6: real fix attempt for the actual current blocker, confirmed live
 * via the DevTools Manifest panel — the user pasted the raw response for
 * both the manifest and gs-client-sw.js and it was an Anubis bot-protection
 * challenge page (TecharoHQ/anubis — "Checking your browser before
 * redirecting"), not real content. This sits in front of the origin at the
 * host/WAF layer (Nestify), so no PHP code in this plugin can intercept or
 * bypass it — the only durable fix is a Nestify-side exemption for these
 * paths. This is a best-effort client-side mitigation in the meantime: a
 * real top-level browsing context (a normal page navigation, or an iframe
 * navigation, which loads and runs Anubis's own challenge JS the same way)
 * is how Anubis's challenge is actually meant to be solved — a bare
 * fetch()/XHR from page script can't run that challenge page's script the
 * way a navigation can, so it never gets past it. A hidden 1x1 iframe
 * pointed at the same URL lets that real navigation happen invisibly:
 * Anubis's own script runs inside the iframe, solves the proof-of-work
 * challenge (the pasted payload's difficulty was 2 — "fast" — so this is
 * normally sub-second), and sets its pass cookie for the whole origin,
 * which subsequent same-origin fetches (including the browser's own
 * manifest/service-worker fetches) then carry automatically.
 * NOT guaranteed: if this Anubis deployment is configured to always
 * challenge these specific paths regardless of cookie state, or ties its
 * pass-cookie to signals an iframe navigation doesn't reproduce, this will
 * not help — the Nestify-side exemption remains the real fix. This exists
 * purely to give registration its best possible chance while that request
 * is pending, not as a replacement for it.
 */
var gsAnubisState = { promise: null, cleared: false };

function gsWaitForBody() {
    return new Promise(function (resolve) {
        if (document.body) { resolve(); return; }
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', resolve, { once: true });
            return;
        }
        var tick = setInterval(function () {
            if (document.body) { clearInterval(tick); resolve(); }
        }, 10);
    });
}

function gsIsBotChallengeResponse(text, contentType) {
    if (!text) { return true; }
    if (text.indexOf('anubis_challenge') !== -1) { return true; }
    if (text.indexOf('Checking your browser before redirecting') !== -1) { return true; }
    if (text.indexOf('within.website/x/cmd/anubis') !== -1) { return true; }
    if (text.indexOf("addEventListener('fetch'") !== -1 || text.indexOf('addEventListener("fetch"') !== -1) {
        return false;
    }
    var ct = (contentType || '').toLowerCase();
    if (ct.indexOf('javascript') !== -1) { return false; }
    if (ct.indexOf('manifest+json') !== -1 || ct.indexOf('json') !== -1) { return false; }
    return text.length < 64;
}

function gsWarmUpAnubisChallenge(url) {
    return new Promise(function (resolve) {
        var settled = false;
        var iframe = document.createElement('iframe');
        iframe.style.cssText = 'position:absolute;width:1px;height:1px;opacity:0;pointer-events:none;left:-9999px;top:-9999px;border:0';
        var finish = function () {
            if (settled) { return; }
            settled = true;
            iframe.remove();
            resolve();
        };
        iframe.onload = finish;
        setTimeout(finish, 5000);
        iframe.src = url;
        document.body.appendChild(iframe);
    });
}

async function gsEnsurePastAnubisChallenge(probeUrl) {
    if (gsAnubisState.cleared) { return true; }
    probeUrl = probeUrl || ((window.GS && GS.home_url) ? GS.home_url : '/') + 'gs-client-sw.js';

    var runProbe = async function () {
        try {
            var res = await fetch(probeUrl, { credentials: 'same-origin', cache: 'no-store' });
            var text = await res.text();
            return !gsIsBotChallengeResponse(text, res.headers.get('content-type'));
        } catch (e) {
            return false;
        }
    };

    if (!gsAnubisState.promise) {
        gsAnubisState.promise = (async function () {
            if (await runProbe()) { gsAnubisState.cleared = true; return true; }
            await gsWaitForBody();
            await gsWarmUpAnubisChallenge(probeUrl);
            var ok = await runProbe();
            if (ok) { gsAnubisState.cleared = true; }
            return ok;
        })();
    }

    try {
        return await gsAnubisState.promise;
    } catch (e) {
        gsAnubisState.promise = null;
        return false;
    }
}

function gsGetServiceWorkerUrls(type) {
    var urls = [];
    if (window.GS && GS.sw_urls && GS.sw_urls[type]) {
        urls = GS.sw_urls[type].slice();
    }
    if (urls.length) { return urls; }
    var file = type === 'vendor' ? 'gs-vendor-sw.js' : 'gs-client-sw.js';
    var home = (window.GS && GS.home_url) ? GS.home_url : '/';
    var ver = (window.GS && GS.version) ? GS.version : '';
    urls.push(home + file + '?v=' + ver);
    if (window.GS && GS.ajax_url) {
        urls.push(GS.ajax_url + '?action=gs_serve_sw&type=' + type + '&v=' + ver);
    }
    if (window.GS && GS.rest_url) {
        urls.push(GS.rest_url + 'sw?type=' + type + '&v=' + ver);
    }
    if (window.GS && GS.plugin_url) {
        urls.push(GS.plugin_url + 'assets/js/' + file + '?v=' + ver);
    }
    return urls;
}

async function gsRegisterServiceWorker(type, sessionKey, sessionThreshold, pushKey, onPushReady) {
    if (!('serviceWorker' in navigator)) { return null; }
    var urls = gsGetServiceWorkerUrls(type);
    await gsEnsurePastAnubisChallenge(urls[0]);

    var lastErr = null;
    for (var i = 0; i < urls.length; i++) {
        try {
            var reg = await navigator.serviceWorker.register(urls[i], { scope: '/' });
            setInterval(function () { reg.update(); }, 3600000);
            var sessions = parseInt(localStorage.getItem(sessionKey) || '0', 10) + 1;
            localStorage.setItem(sessionKey, String(sessions));
            if (sessions >= sessionThreshold && !localStorage.getItem(pushKey) && typeof onPushReady === 'function') {
                onPushReady(reg);
            }
            gsCheckIOSInstallPrompt(sessionKey, sessionThreshold);
            return reg;
        } catch (err) {
            lastErr = err;
            console.warn('GS SW registration failed for ' + urls[i] + ':', err);
        }
    }
    if (lastErr) { console.warn('GS SW registration failed for all URLs:', lastErr); }
    return null;
}

/**
 * Register the vendor service worker and wire up push notifications.
 * Called on vendor dashboard pages only.
 */
async function gsRegisterVendorPWA() {
    return gsRegisterServiceWorker('vendor', 'gs_sessions', 3, 'gs_push_requested', gsRequestPushPermission);
}

async function gsRegisterClientPWA() {
    return gsRegisterServiceWorker('client', 'gs_client_sessions', 2, 'gs_client_push_requested', gsRequestClientPushPermission);
}

/**
 * Part 3.2 — Request push permission for client users and save subscription.
 */
async function gsRequestClientPushPermission(reg) {
    if (!('Notification' in window) || !('PushManager' in window)) { return; }
    if (!window.GS || !GS.vapid_public_key) { return; }

    const permission = await Notification.requestPermission();
    if (permission !== 'granted') { return; }

    localStorage.setItem('gs_client_push_requested', '1');

    try {
        const swReg = reg || await navigator.serviceWorker.ready;
        const sub   = await swReg.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: gsUrlBase64ToUint8Array(GS.vapid_public_key)
        });
        // Save with client device_type flag
        gsAjaxPost('gs_save_push_subscription', {
            subscription: JSON.stringify(sub.toJSON()),
            device_type:  (/Mobi/.test(navigator.userAgent) ? 'mobile' : 'desktop') + '_client'
        }, null, null);
    } catch(err) {
        console.warn('GS client push subscription failed:', err);
    }
}

/**
 * Request push notification permission and save subscription to server.
 */
async function gsRequestPushPermission(reg) {
    if (!('Notification' in window) || !('PushManager' in window)) { return; }
    if (!window.GS || !GS.vapid_public_key) { return; }

    const permission = await Notification.requestPermission();
    if (permission !== 'granted') { return; }

    localStorage.setItem('gs_push_requested', '1');

    try {
        const swReg = reg || await navigator.serviceWorker.ready;
        const sub   = await swReg.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: gsUrlBase64ToUint8Array(GS.vapid_public_key)
        });
        gsAjaxPost('gs_save_push_subscription', {
            subscription: JSON.stringify(sub.toJSON()),
            device_type:  /Mobi/.test(navigator.userAgent) ? 'mobile' : 'desktop'
        }, null, null);
    } catch(err) {
        console.warn('GS push subscription failed:', err);
    }
}

function gsUrlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64  = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const raw     = window.atob(base64);
    return Uint8Array.from([...raw].map(c => c.charCodeAt(0)));
}

/* ── PWA Install Prompt ─────────────────────────────────────────────────── */

// Guard: goodservice.js may load twice (WP enqueue + manual echo in render_page).
// Using window property instead of `let` prevents "already declared" SyntaxError
// on the second load. The ?? null ensures it is only initialised once.
if (typeof window.gsDeferredInstallPrompt === 'undefined') {
    window.gsDeferredInstallPrompt = null;
}

// Only register this listener once — skip if already set up on a previous load.
if (!window.__gsPWAListenerRegistered) {
    window.__gsPWAListenerRegistered = true;

    window.addEventListener('beforeinstallprompt', e => {
        e.preventDefault();
        window.gsDeferredInstallPrompt = e;
        // Real bug fix: this always checked gs_sessions (the vendor-only
        // counter, incremented in gsRegisterVendorPWA()). The actual
        // customer-side registration (gsRegisterClientPWA()) increments a
        // different key, gs_client_sessions — meaning a customer's real
        // session count was never read here at all, and this banner could
        // never fire for a customer regardless of visit count.
        const isVendor = window.GS && GS.is_vendor;
        const sessionKey = isVendor ? 'gs_sessions' : 'gs_client_sessions';
        const threshold = isVendor ? 3 : 2; // matches each registration function's own threshold
        const sessions = parseInt(localStorage.getItem(sessionKey) || '0');
        if (sessions >= threshold && !localStorage.getItem('gs_pwa_dismissed')) {
            gsShowPWAInstallBanner();
        }
    });
}

/**
 * Real fix: beforeinstallprompt never fires on iOS Safari or Firefox — this
 * is standard, documented browser behavior, not a bug in those browsers.
 * Without this, the general install banner could structurally never appear
 * for those visitors, regardless of session count, since nothing else ever
 * called gsShowPWAInstallBanner() for them. Runs independently on page load.
 */
function gsIsIOS() {
    return /iPhone|iPad|iPod/.test(navigator.userAgent) && !window.MSStream;
}
function gsIsAlreadyInstalled() {
    return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
}
/**
 * Real fix: this used to be a separate DOMContentLoaded listener guessing a
 * fixed 1200ms delay for the async session-counter increment to complete —
 * a real race condition, since service worker registration timing is not
 * something a fixed number can reliably predict. Now called directly from
 * inside gsRegisterVendorPWA()/gsRegisterClientPWA()'s own callback, at the
 * exact point the increment happens, so ordering is guaranteed rather than
 * assumed.
 */
function gsCheckIOSInstallPrompt(sessionKey, threshold) {
    if (!gsIsIOS()) { return; } // Chromium browsers are handled entirely by the beforeinstallprompt listener above.
    if (gsIsAlreadyInstalled() || localStorage.getItem('gs_pwa_dismissed')) { return; }
    const sessions = parseInt(localStorage.getItem(sessionKey) || '0');
    if (sessions >= threshold) { gsShowPWAInstallBanner(); }
}

function gsShowPWAInstallBanner() {
    if (document.getElementById('gs-pwa-banner')) { return; }
    // Real bug fix: this banner was unconditionally vendor-branded regardless
    // of who was actually viewing it — every customer who visited 3+ times
    // saw "Install GoodService Vendor", which is simply wrong for them.
    // GS.is_vendor was already correctly localized (Assets.php) but never
    // used here.
    const isVendor = window.GS && GS.is_vendor;
    const iconFile = isVendor ? 'vendor-icon-192.png' : 'client-icon-192.png';
    const label    = isVendor ? 'Install GoodService Vendor' : 'Install GoodService';
    const subtext  = isVendor ? 'Get instant notifications for new inquiries' : 'Track your inquiries and bookings, even offline';
    // Real bug fix: was hardcoded to /wp-content/plugins/gs23/ — the live
    // plugin folder is gs23_seo_ready-6 (confirmed live production path,
    // v7.475.2 — a prior fix here had corrected this to the also-wrong
    // "gs23_fixed", an even earlier renamed folder). Uses the same
    // GS.plugin_url pattern already correctly established for the service
    // worker paths just above this function; this literal string is only
    // ever reached as a fallback if GS.plugin_url is somehow unavailable.
    const iconUrl = (window.GS && GS.plugin_url) ? GS.plugin_url + 'assets/pwa/' + iconFile : '/wp-content/plugins/gs23_seo_ready-6/assets/pwa/' + iconFile;
    const banner = document.createElement('div');
    banner.id = 'gs-pwa-banner';
    banner.className = 'gs-pwa-banner';
    banner.innerHTML = `<div class="gs-pwa-banner-inner">
        <img src="${iconUrl}" width="40" height="40" alt="">
        <div>
            <strong>${label}</strong>
            <span>${subtext}</span>
        </div>
        <button onclick="gsInstallPWA()" class="gs-btn gs-btn-primary gs-btn-sm">Install</button>
        <button onclick="gsDismissPWABanner()" class="gs-btn gs-btn-ghost gs-btn-sm" aria-label="Dismiss">×</button>
    </div>`;
    document.body.prepend(banner);
}

/**
 * v7.475.5: real per-browser/OS detection for the "no native prompt yet"
 * fallback message. iOS is handled by a separate branch above this
 * function's caller (Safari on iOS never sets gsDeferredInstallPrompt at
 * all), so this only needs to cover what a visitor sees once they're
 * already past that check: desktop/Android Chrome & Edge (support the
 * native prompt, just may not have fired it yet), Android Firefox/Samsung
 * Internet-family browsers (menu-based install, no beforeinstallprompt),
 * desktop Firefox (no PWA install support at all), and desktop Safari
 * (install lives in the menu bar, not the address bar).
 */
function gsGetInstallInstructions() {
    var ua = navigator.userAgent;
    var isAndroid = /Android/.test(ua);
    var isWindows = /Windows/.test(ua);
    var isMac = /Macintosh/.test(ua) && !isAndroid;
    var isEdge = /Edg\//.test(ua);
    var isFirefox = /Firefox/.test(ua);
    var isChrome = /Chrome\//.test(ua) && !isEdge && !/OPR\//.test(ua) && !/SamsungBrowser/.test(ua);
    var isSamsung = /SamsungBrowser/.test(ua);
    var isSafari = /Safari/.test(ua) && !isChrome && !isEdge && !isFirefox && !isSamsung;

    if (isAndroid && (isChrome || isEdge)) {
        return { icon: '📱', title: 'Almost there', canRetry: true,
            body: 'This browser supports installing the app, but hasn’t offered the native prompt on this visit yet. Tap <strong>Check again</strong> below, or open the ⋮ menu (top-right) and look for <strong>"Install app"</strong> / <strong>"Add to Home screen"</strong>.' };
    }
    if (isAndroid && isSamsung) {
        return { icon: '📱', title: 'Install this app', canRetry: false,
            body: 'Open the menu (≡ bottom-right), then tap <strong>"Add page to"</strong> → <strong>"Home screen"</strong>.' };
    }
    if (isAndroid && isFirefox) {
        return { icon: '📱', title: 'Install this app', canRetry: false,
            body: 'Open the ⋮ menu, then tap <strong>"Install"</strong>. If that option isn’t there, this version of Firefox doesn’t support it — Chrome or Edge on Android will work.' };
    }
    if ((isWindows || isMac) && (isChrome || isEdge)) {
        return { icon: '🖥️', title: 'Almost there', canRetry: true,
            body: 'This browser supports installing the app, but hasn’t offered the native prompt on this visit yet. Tap <strong>Check again</strong> below, or click the install icon (⊕) at the right end of the address bar.' };
    }
    if (isMac && isSafari) {
        return { icon: '🖥️', title: 'Install this app', canRetry: false,
            body: 'In the Safari menu bar, choose <strong>File → Add to Dock</strong>. (Requires Safari 17 or newer — older versions don’t support installing websites.)' };
    }
    if ((isWindows || isMac) && isFirefox) {
        return { icon: '🖥️', title: 'Not supported in Firefox', canRetry: false,
            body: 'Desktop Firefox doesn’t support installing websites as apps. Open this site in Chrome or Edge to install it.' };
    }
    // Fallback for anything not explicitly matched above.
    return { icon: '📱', title: 'Install this app', canRetry: true,
        body: 'Look for an install icon (⊕ or a small monitor/phone icon) in your browser’s address bar, or open your browser’s menu and look for <strong>"Install App"</strong> / <strong>"Add to Home Screen"</strong>.' };
}

/**
 * v7.475.5: the "Check again" button on the fallback message. Chrome only
 * decides an install is offerable after its own engagement heuristics are
 * satisfied (this can happen between page loads without any code here
 * changing) — this re-checks the live deferred prompt so a visitor doesn't
 * have to reload the page to find out whether it's become available.
 */
function gsRetryInstallPrompt(btn) {
    var panel = btn.closest('div[style*="position:fixed"]');
    if (window.gsDeferredInstallPrompt) {
        if (panel) { panel.remove(); }
        gsInstallPWA();
        return;
    }
    gsAnubisState.promise = null;
    gsAnubisState.cleared = false;
    var retry = (window.GS && GS.is_vendor) ? gsRegisterVendorPWA() : gsRegisterClientPWA();
    Promise.resolve(retry).then(function () {
        return new Promise(function (r) { setTimeout(r, 400); });
    }).then(function () {
        if (window.gsDeferredInstallPrompt) {
            if (panel) { panel.remove(); }
            gsInstallPWA();
            return;
        }
        btn.textContent = 'Still not available — try later';
        btn.disabled = true;
        btn.style.opacity = '.6';
        btn.style.cursor = 'default';
    });
}

async function gsInstallPWA() {
    // Real fix: on iOS there is no native prompt at all — gsDeferredInstallPrompt
    // is never set — so without this branch, clicking Install would silently
    // do nothing for the exact visitors the iOS trigger above was built for.
    if (typeof gsIsIOS === 'function' && gsIsIOS()) {
        document.getElementById('gs-pwa-banner')?.remove();
        const ios = document.createElement('div');
        ios.style.cssText = 'position:fixed;bottom:0;left:0;right:0;background:#fff;border-radius:16px 16px 0 0;padding:24px;z-index:99999;box-shadow:0 -4px 32px rgba(0,0,0,.15);text-align:center';
        ios.innerHTML = '<div style="font-size:1.5rem;margin-bottom:10px">📱</div>'
            + '<div style="font-weight:800;margin-bottom:8px">Add to Home Screen</div>'
            + '<div style="font-size:.84rem;color:#64748B;margin-bottom:14px;line-height:1.6">'
            + 'Tap the <strong>Share</strong> button (⬆) in Safari, then choose <strong>"Add to Home Screen"</strong>.</div>'
            + '<button onclick="this.parentElement.remove()" style="background:#2563EB;color:#fff;border:none;border-radius:8px;padding:10px 24px;font-size:.85rem;font-weight:700;cursor:pointer">Got it</button>';
        document.body.appendChild(ios);
        localStorage.setItem('gs_pwa_dismissed', '1');
        return;
    }
    if (!window.gsDeferredInstallPrompt) {
        if (!window.__gsInstallRetryDone) {
            window.__gsInstallRetryDone = true;
            gsAnubisState.promise = null;
            gsAnubisState.cleared = false;
            if (window.GS && GS.is_vendor) {
                await gsRegisterVendorPWA();
            } else {
                await gsRegisterClientPWA();
            }
            await new Promise(function (r) { setTimeout(r, 400); });
            if (window.gsDeferredInstallPrompt) {
                return gsInstallPWA();
            }
        }
        var info = gsGetInstallInstructions();
        var fallback = document.createElement('div');
        fallback.style.cssText = 'position:fixed;bottom:0;left:0;right:0;background:#fff;border-radius:16px 16px 0 0;padding:24px;z-index:99999;box-shadow:0 -4px 32px rgba(0,0,0,.15);text-align:center';
        fallback.innerHTML = '<div style="font-size:1.5rem;margin-bottom:10px">' + info.icon + '</div>'
            + '<div style="font-weight:800;margin-bottom:8px">' + info.title + '</div>'
            + '<div style="font-size:.84rem;color:#64748B;margin-bottom:14px;line-height:1.6">' + info.body + '</div>'
            + (info.canRetry ? '<button onclick="gsRetryInstallPrompt(this)" style="background:#fff;color:#2563EB;border:1.5px solid #2563EB;border-radius:8px;padding:9px 20px;font-size:.85rem;font-weight:700;cursor:pointer;margin-right:8px">Check again</button>' : '')
            + '<button onclick="this.parentElement.remove()" style="background:#2563EB;color:#fff;border:none;border-radius:8px;padding:10px 24px;font-size:.85rem;font-weight:700;cursor:pointer">Got it</button>';
        document.body.appendChild(fallback);
        return;
    }
    window.gsDeferredInstallPrompt.prompt();
    const { outcome } = await window.gsDeferredInstallPrompt.userChoice;
    if (outcome === 'accepted') {
        document.getElementById('gs-pwa-banner')?.remove();
        if (window.GS && GS.is_vendor) {
            gsRequestPushPermission();
        } else {
            gsRequestClientPushPermission();
        }
    }
    window.gsDeferredInstallPrompt = null;
}

function gsDismissPWABanner() {
    localStorage.setItem('gs_pwa_dismissed', '1');
    document.getElementById('gs-pwa-banner')?.remove();
}

function gsBootstrapPWA() {
    if (window.__gsPWABootstrapped) { return; }
    window.__gsPWABootstrapped = true;
    var path = window.location.pathname || '';
    if ((document.body && document.body.classList.contains('gs-vendor-page')) || path.indexOf('/vendor/dashboard') !== -1) {
        gsRegisterVendorPWA();
    } else if (path.indexOf('/admin') === -1) {
        gsRegisterClientPWA();
    }
}

function gsSchedulePWABootstrap() {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', gsBootstrapPWA, { once: true });
    } else {
        gsBootstrapPWA();
    }
}
gsSchedulePWABootstrap();

/* ── PWA Bottom Nav (Standalone Mode) ───────────────────────────────────── */

(function initPwaNav() {
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches
                      || window.navigator.standalone;
    if (!isStandalone) { return; }

    const nav = document.getElementById('gs-pwa-nav');
    if (!nav) { return; }

    // Set active tab based on current URL
    const section = new URLSearchParams(window.location.search).get('section') || 'home';
    nav.querySelectorAll('.gs-pwa-tab').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.section === section);
    });

    // Update badge counts
    if (window.GS_CONFIG?.ajaxUrl) {
        gsAjaxPost('gs_get_pwa_badge_counts', {}, function(data) {
            const badge = document.getElementById('pwa-lead-badge');
            if (badge) {
                badge.textContent = data.new_leads || '0';
                badge.dataset.count = data.new_leads || '0';
            }
        }, null);
    }
})();

/* ══════════════════════════════════════════════════════════════════════════
   Quotation Builder JavaScript — Part 6
   ══════════════════════════════════════════════════════════════════════════ */

/** Open the quotation builder panel for a lead. */
function gsOpenQuoteBuilder(leadId) {
    const panel = document.getElementById('gsiq-quote-panel');
    if (!panel) { return; }
    panel.dataset.leadId = leadId;
    panel.style.display = 'flex';
    // Add first row if empty
    if (!document.querySelector('.qb-item-row')) {
        qbAddRow();
    }
    qbRecalc();
    document.getElementById('qb-quote-lead-id').value = leadId;
}

/** Close the quotation builder. */
function gsiqCloseQuote() {
    const panel = document.getElementById('gsiq-quote-panel');
    if (panel) { panel.style.display = 'none'; }
}

/** Add a line item row to the quotation builder. */
function qbAddRow(desc = '', qty = 1, price = 0) {
    const items = document.getElementById('qb-items');
    if (!items) { return; }
    const div = document.createElement('div');
    div.className = 'qb-item-row';
    div.style.cssText = 'display:grid;grid-template-columns:1fr 60px 90px 80px 28px;gap:6px;align-items:center;margin-bottom:6px';
    div.innerHTML = `
      <input class="gsiq-inp qb-desc" placeholder="Service / item description" value="${gsiqEsc(desc)}" oninput="qbRecalc()" aria-label="Description">
      <input class="gsiq-inp qb-qty" type="number" value="${qty}" min="1" style="text-align:center" oninput="qbRecalc()" aria-label="Quantity">
      <input class="gsiq-inp qb-price" type="number" value="${price}" placeholder="₹" oninput="qbRecalc()" aria-label="Unit price">
      <div class="qb-line-total" style="font-size:.83rem;font-weight:600;text-align:right;color:#1E293B">₹0</div>
      <button onclick="this.closest('.qb-item-row').remove();qbRecalc()"
              style="background:none;border:none;color:#DC2626;cursor:pointer;font-size:1rem;min-height:28px"
              aria-label="Remove row">×</button>`;
    items.appendChild(div);
    qbRecalc();
}

/** Recalculate all totals in the quotation builder. */
function qbRecalc() {
    let subtotal = 0;
    document.querySelectorAll('.qb-item-row').forEach(row => {
        const qty   = parseFloat(row.querySelector('.qb-qty')?.value)   || 0;
        const price = parseFloat(row.querySelector('.qb-price')?.value) || 0;
        const line  = qty * price;
        const lt    = row.querySelector('.qb-line-total');
        if (lt) lt.textContent = '₹' + line.toLocaleString('en-IN');
        subtotal += line;
    });
    const gstOn  = document.getElementById('qb-gst-toggle')?.checked;
    const gst    = gstOn ? subtotal * 0.18 : 0;
    const total  = subtotal + gst;
    const fmt    = v => '₹' + Math.round(v).toLocaleString('en-IN');

    const el = id => document.getElementById(id);
    if (el('qb-subtotal')) el('qb-subtotal').textContent = fmt(subtotal);
    if (el('qb-gst-row'))  el('qb-gst-row').style.display = gstOn ? '' : 'none';
    if (el('qb-gst'))      el('qb-gst').textContent       = fmt(gst);
    if (el('qb-total'))    el('qb-total').textContent      = fmt(total);
}

/** Save draft and then send quote. */
function qbSendQuote() {
    const leadId = document.getElementById('gsiq-quote-panel')?.dataset.leadId;
    if (!leadId) { gsiqToast('No inquiry selected.', 'error'); return; }

    const btn = document.getElementById('qb-send-btn');
    if (btn) { btn.disabled = true; btn.textContent = 'Sending...'; }

    const items = [];
    document.querySelectorAll('.qb-item-row').forEach(row => {
        const desc  = row.querySelector('.qb-desc')?.value.trim();
        const qty   = parseFloat(row.querySelector('.qb-qty')?.value) || 1;
        const price = parseFloat(row.querySelector('.qb-price')?.value) || 0;
        if (desc) { items.push({ description: desc, qty, unit_price: price, total: qty * price }); }
    });

    if (items.length === 0) { gsiqToast('Add at least one line item.', 'error'); if (btn) { btn.disabled = false; btn.textContent = 'Send Quote to Client'; } return; }

    const gstOn = document.getElementById('qb-gst-toggle')?.checked;

    // Step 1: Create quotation
    gsiqPost('gs_create_quotation', {
        lead_id:       leadId,
        line_items:    JSON.stringify(items),
        gst_rate:      gstOn ? 18 : 0,
        validity_days: document.getElementById('qb-validity')?.value || 7,
        payment_terms: document.getElementById('qb-terms')?.value || '',
        notes:         document.getElementById('qb-notes')?.value || '',
        cover_note:    document.getElementById('qb-cover')?.value || '',
    }, function(data) {
        // Step 2: Send it
        gsiqPost('gs_send_quotation', { quote_id: data.quote_id, lead_id: leadId }, function() {
            gsiqToast('Quote sent to client!', 'success');
            gsiqCloseQuote();
            if (btn) { btn.disabled = false; btn.textContent = 'Send Quote to Client'; }
        }, function(msg) {
            gsiqToast(msg, 'error');
            if (btn) { btn.disabled = false; btn.textContent = 'Send Quote to Client'; }
        });
    }, function(msg) {
        gsiqToast(msg, 'error');
        if (btn) { btn.disabled = false; btn.textContent = 'Send Quote to Client'; }
    });
}

/** Save quotation as draft. */
function qbSaveDraft() {
    const leadId = document.getElementById('gsiq-quote-panel')?.dataset.leadId;
    const items  = [];
    document.querySelectorAll('.qb-item-row').forEach(row => {
        const desc  = row.querySelector('.qb-desc')?.value.trim();
        const qty   = parseFloat(row.querySelector('.qb-qty')?.value) || 1;
        const price = parseFloat(row.querySelector('.qb-price')?.value) || 0;
        if (desc) { items.push({ description: desc, qty, unit_price: price, total: qty * price }); }
    });
    gsiqPost('gs_save_quote_draft', {
        lead_id:    leadId,
        line_items: JSON.stringify(items),
        gst_rate:   document.getElementById('qb-gst-toggle')?.checked ? 18 : 0,
        validity_days: document.getElementById('qb-validity')?.value || 7,
        cover_note: document.getElementById('qb-cover')?.value || '',
        notes:      document.getElementById('qb-notes')?.value || '',
    }, () => gsiqToast('Draft saved.', 'success'), null);
}

/* ── Simple Ajax helper for general use (not just inquiry manager) ─────── */
function gsAjaxPost(action, data, onSuccess, onError) {
    if (typeof gsiqPost === 'function') {
        return gsiqPost(action, data, onSuccess, onError);
    }
    // Fallback if gsiqPost not loaded yet
    const payload = new FormData();
    payload.append('action', action);
    if (window.GS_CONFIG?.nonce) { payload.append('nonce', window.GS_CONFIG.nonce); }
    Object.entries(data || {}).forEach(([k,v]) => { if (v != null) payload.append(k, v); });
    fetch(window.GS_CONFIG?.ajaxUrl || '/wp-admin/admin-ajax.php', { method:'POST', credentials:'same-origin', body: payload })
        .then(r => r.json())
        .then(j => { if (j?.success && typeof onSuccess === 'function') { onSuccess(j.data); } else if (typeof onError === 'function') { onError(j?.data?.message || 'Error'); } })
        .catch(e => { if (typeof onError === 'function') { onError('Network error.'); } });
}

