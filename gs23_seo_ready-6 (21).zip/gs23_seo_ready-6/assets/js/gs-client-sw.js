/**
 * GoodService Client Service Worker — Phase 9 Enhanced
 * Adds: background sync for offline booking submissions and push notifications.
 */
const CACHE_NAME = 'gs-client-v2';
const SYNC_TAG   = 'gs-booking-retry';
const IDB_DB     = 'gs-offline-queue';
const IDB_STORE  = 'pending-bookings';

self.addEventListener('install', event => {
    event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys()
            .then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))
            .then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', event => {
    const url = new URL(event.request.url);
    if (url.pathname.includes('admin-ajax.php')) return;
    if (['style', 'script', 'image', 'font'].includes(event.request.destination)) {
        event.respondWith(
            caches.match(event.request).then(cached => cached ||
                fetch(event.request).then(res => {
                    const clone = res.clone();
                    caches.open(CACHE_NAME).then(c => c.put(event.request, clone));
                    return res;
                })
            )
        );
    }
});

// Background sync fires when connectivity returns
self.addEventListener('sync', event => {
    if (event.tag === SYNC_TAG) {
        event.waitUntil(retryPendingBookings());
    }
});

async function retryPendingBookings() {
    const db      = await openIDB();
    const pending = await getAllPending(db);
    let succeeded = 0;
    for (const entry of pending) {
        try {
            const fd = new FormData();
            for (const [k, v] of Object.entries(entry.payload || {})) fd.append(k, v);
            const res  = await fetch(entry.url, { method: 'POST', body: fd });
            const json = await res.json();
            if (json && json.success) {
                await deletePending(db, entry.id);
                succeeded++;
            }
        } catch { /* network still down — keep entry */ }
    }
    if (succeeded > 0) {
        const clients = await self.clients.matchAll({ type: 'window' });
        clients.forEach(c => c.postMessage({ type: 'GS_BOOKING_SYNCED', count: succeeded }));
    }
}

// Page sends GS_QUEUE_BOOKING to queue an offline submission
self.addEventListener('message', async event => {
    if (event.data && event.data.type === 'GS_QUEUE_BOOKING') {
        const db = await openIDB();
        await addPending(db, {
            id:       Date.now().toString(),
            url:      event.data.url,
            payload:  event.data.payload,
            queuedAt: new Date().toISOString(),
        });
        if ('sync' in self.registration) {
            await self.registration.sync.register(SYNC_TAG);
        }
        if (event.ports && event.ports[0]) event.ports[0].postMessage({ queued: true });
    }
});

self.addEventListener('push', event => {
    if (!event.data) return;
    let data;
    try { data = event.data.json(); } catch { data = { title: 'GoodService', body: event.data.text() }; }
    event.waitUntil(
        self.registration.showNotification(data.title || 'GoodService', {
            body: data.body || '',
            // Real fix (v7.475.2): hardcoded the OLD plugin folder name
            // ("gs23") — the live folder is gs23_seo_ready-6, so this
            // notification icon has been 404ing this whole time. Same
            // class of bug as the .webmanifest icon paths fixed in
            // v7.475.1. Also dropped the 'badge' key entirely — it
            // pointed at badge-72.png, a file that has never existed
            // anywhere in assets/pwa/ (confirmed via a directory listing)
            // — the Notification API's badge is optional and safely
            // omitted rather than pointed at a real icon mis-sized/
            // mis-styled as a monochrome status-bar badge.
            icon: '/wp-content/plugins/gs23_seo_ready-6/assets/pwa/client-icon-192.png',
            tag: data.tag || 'gs-notification',
            data: { url: data.url || '/' },
        })
    );
});

self.addEventListener('notificationclick', event => {
    event.notification.close();
    const url = event.notification.data && event.notification.data.url || '/';
    event.waitUntil(clients.openWindow(url));
});

// IndexedDB helpers
function openIDB() {
    return new Promise(function(resolve, reject) {
        const req = indexedDB.open(IDB_DB, 1);
        req.onupgradeneeded = function(e) { e.target.result.createObjectStore(IDB_STORE, { keyPath: 'id' }); };
        req.onsuccess = function(e) { resolve(e.target.result); };
        req.onerror   = function(e) { reject(e.target.error); };
    });
}
function getAllPending(db) {
    return new Promise(function(resolve, reject) {
        const req = db.transaction(IDB_STORE, 'readonly').objectStore(IDB_STORE).getAll();
        req.onsuccess = function(e) { resolve(e.target.result || []); };
        req.onerror   = function(e) { reject(e.target.error); };
    });
}
function addPending(db, entry) {
    return new Promise(function(resolve, reject) {
        const req = db.transaction(IDB_STORE, 'readwrite').objectStore(IDB_STORE).add(entry);
        req.onsuccess = function() { resolve(); };
        req.onerror   = function(e) { reject(e.target.error); };
    });
}
function deletePending(db, id) {
    return new Promise(function(resolve, reject) {
        const req = db.transaction(IDB_STORE, 'readwrite').objectStore(IDB_STORE).delete(id);
        req.onsuccess = function() { resolve(); };
        req.onerror   = function(e) { reject(e.target.error); };
    });
}
