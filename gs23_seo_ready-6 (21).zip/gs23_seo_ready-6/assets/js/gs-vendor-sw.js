/**
 * GoodService Vendor Service Worker
 * Provides offline support, caching, and push notification handling.
 * Part 2.2 of GoodService Complete Implementation Master Document.
 */
const CACHE_NAME = 'gs-vendor-v1';
const OFFLINE_URLS = [
    '/vendor/dashboard/',
    '/assets/pwa/offline.html'
];

// Install: cache critical assets
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => cache.addAll(OFFLINE_URLS))
            .then(() => self.skipWaiting())
            .catch(err => console.warn('GS SW install cache error:', err))
    );
});

// Activate: clean up old caches
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys()
            .then(keys => Promise.all(
                keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
            ))
            .then(() => self.clients.claim())
    );
});

// Fetch: network-first for AJAX/API, cache-first for static assets
self.addEventListener('fetch', event => {
    const url = new URL(event.request.url);

    // Always network for AJAX/API calls
    if (url.pathname.includes('admin-ajax.php') || url.searchParams.has('gs_action')) {
        return; // pass through to network
    }

    // Cache-first for static assets (CSS, JS, images)
    if (['style', 'script', 'image', 'font'].includes(event.request.destination)) {
        event.respondWith(
            caches.match(event.request)
                .then(cached => cached || fetch(event.request).then(res => {
                    const clone = res.clone();
                    caches.open(CACHE_NAME).then(c => c.put(event.request, clone));
                    return res;
                }))
        );
        return;
    }

    // Network-first for pages, fallback to cache, then offline page
    event.respondWith(
        fetch(event.request)
            .then(response => {
                if (event.request.method === 'GET') {
                    const clone = response.clone();
                    caches.open(CACHE_NAME).then(c => c.put(event.request, clone));
                }
                return response;
            })
            .catch(() =>
                caches.match(event.request)
                    .then(cached => cached || caches.match('/assets/pwa/offline.html'))
            )
    );
});

// Push notification handler
self.addEventListener('push', event => {
    if (!event.data) return;

    let data;
    try {
        data = event.data.json();
    } catch {
        data = { title: 'GoodService', body: event.data.text() };
    }

    event.waitUntil(
        self.registration.showNotification(data.title || 'GoodService', {
            body:    data.body || '',
            // Real fix (v7.475.2) — see the matching comment in
            // gs-client-sw.js: wrong old plugin folder name, and a
            // 'badge' asset that has never existed on disk.
            icon:    data.icon || '/wp-content/plugins/gs23_seo_ready-6/assets/pwa/vendor-icon-192.png',
            tag:     data.tag || 'gs-notification',
            data:    { url: data.url || '/vendor/dashboard/' },
            vibrate: [200, 100, 200],
            actions: data.actions || [
                { action: 'view',    title: 'View' },
                { action: 'dismiss', title: 'Dismiss' }
            ]
        })
    );
});

// Notification click handler
self.addEventListener('notificationclick', event => {
    event.notification.close();
    if (event.action === 'dismiss') return;

    const url = event.notification.data?.url || '/vendor/dashboard/';
    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true })
            .then(clientList => {
                // Focus existing window if possible
                for (const client of clientList) {
                    if (client.url.includes('/vendor/dashboard') && 'focus' in client) {
                        client.navigate(url);
                        return client.focus();
                    }
                }
                return clients.openWindow(url);
            })
    );
});
