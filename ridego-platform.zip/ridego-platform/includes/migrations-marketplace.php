<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   MARKETPLACE ARCHITECTURE MIGRATIONS (schema v15 – v21)
   ------------------------------------------------------------
   Implements the additive schema from the RideGo Marketplace
   Architecture Plan (sections D, F, M, N, P). Every migration:
     - is strictly additive (no column renamed, retyped or dropped)
     - is idempotent (ridego_table_exists / ridego_add_column_if_missing
       guard every step, so re-running is a no-op)
     - creates tables with a plain CREATE TABLE IF NOT EXISTS via
       $wpdb->query() and checks $wpdb->last_error, so a failure is
       reported to the migration runner instead of being swallowed
       by dbDelta's silent formatting rules.
   These are registered through ridego_get_marketplace_migrations(),
   which ridego_get_migrations() (includes/migrations.php) merges in.
   ============================================================ */

// TRACE: ridego_get_migrations() → returns the v15-v22 migration descriptors
//        → no mutation. Preconditions: none. Postconditions: array of 8 entries
//        with strictly increasing 'version' 15..22. Edge cases: none.
function ridego_get_marketplace_migrations() {
    return array(
        array( 'version' => 15, 'description' => 'Marketplace Phase 1: vendor_type + fleet vehicles/drivers/unavailability/branches + per-vehicle/driver document keys.', 'callback' => 'ridego_migration_015_fleet' ),
        array( 'version' => 16, 'description' => 'Marketplace Phase 2/3: lead interest workflow columns on ridego_leads and assignment/commission/closure columns on ridego_bookings (+ archive table sync).', 'callback' => 'ridego_migration_016_leads_and_booking_columns' ),
        array( 'version' => 17, 'description' => 'Marketplace Phase 3: ridego_booking_assignments (immutable driver/vehicle history) and ridego_booking_ledger (one row per money movement).', 'callback' => 'ridego_migration_017_assignments_and_ledger' ),
        array( 'version' => 18, 'description' => 'Marketplace Phase 4: ridego_commission_models and ridego_vendor_commission_assignments.', 'callback' => 'ridego_migration_018_commission' ),
        array( 'version' => 19, 'description' => 'Marketplace Phase 6: category-scored ratings, ridego_service_events and ridego_performance_snapshots.', 'callback' => 'ridego_migration_019_ratings_and_performance' ),
        array( 'version' => 20, 'description' => 'Marketplace Phase 7: ridego_impersonation_log and acting_as_id on the audit log.', 'callback' => 'ridego_migration_020_impersonation' ),
        array( 'version' => 21, 'description' => 'Marketplace Phase 8: ridego_matching_weight_profiles and ridego_matching_recommendations (+ seeded default weight profile).', 'callback' => 'ridego_migration_021_matching' ),
        array( 'version' => 22, 'description' => 'Marketplace alignment: subscription_hybrid commission link (subscription_plan_id), plan-named matching flags/factors, lead interest_status normalised to the plan enum.', 'callback' => 'ridego_migration_022_alignment' ),
        array( 'version' => 23, 'description' => 'Driver profile hardening: identity, address, emergency contact, licence class, police verification columns on fleet drivers and a driver_profile_snapshot on assignments.', 'callback' => 'ridego_migration_023_driver_profile' ),
        array( 'version' => 24, 'description' => 'Back-office CRM: ridego_clients, ridego_booking_payments, ridego_enquiries, ridego_booking_notes, booking source/created_by/passenger/adjustment columns, and a backfill of client profiles from existing bookings.', 'callback' => 'ridego_migration_024_crm' ),
        array( 'version' => 25, 'description' => 'Facilitator payment model: booking amount is always collected by RideGo, the ride balance is billed and collected by the vendor/driver. Adds platform_model, vendor_collected, vendor_collected_at, vendor_invoice_number to bookings, marks token bookings as platform_model, turns the booking-amount feature on.', 'callback' => 'ridego_migration_025_facilitator_model' ),
        array( 'version' => 26, 'description' => 'Booking amount is RideGo\'s lead fee: refreshes the standard wording saved by schema 25 so it says the booking amount is kept by RideGo as its fee (no separate wallet lead fee on facilitator bookings).', 'callback' => 'ridego_migration_026_lead_fee_wording' ),
        array( 'version' => 27, 'description' => 'Vendor Lead Fee engine: versioned commercial terms (ridego_lead_fee_terms), vendor terms acceptance records, lead-fee snapshot columns on bookings and leads, seeds the default rule (higher of a minimum or a percentage), refreshes the standard client/vendor wording.', 'callback' => 'ridego_migration_027_vendor_lead_fee' ),
        array( 'version' => 28, 'description' => 'Cancellation forfeit disposition: bookings.cancel_forfeit_to (platform or vendor), cancel_forfeit_reason, and the cancel_forfeit_default setting.', 'callback' => 'ridego_migration_028_forfeit_disposition' ),
        array( 'version' => 29, 'description' => 'Team access: ridego_regions, ridego_tasks and fleet_drivers.user_id (driver logins).', 'callback' => 'ridego_migration_029_team_access' ),
        array( 'version' => 30, 'description' => 'Privacy/PII self-service (RG-006): ridego_privacy_requests, tracking a user\'s export/delete request from submission through admin review to fulfilment.', 'callback' => 'ridego_migration_030_privacy_requests' ),
        array( 'version' => 31, 'description' => 'Driver-facing trip state machine (RG-012): driver_en_route_at, driver_arrived_at, no_show_at and no_show_reason columns on ridego_bookings, enabling drivers to self-report en-route/arrived/no-show instead of only an admin doing it on their behalf.', 'callback' => 'ridego_migration_031_driver_trip_state' ),
        array( 'version' => 32, 'description' => 'Driver earnings ledger (RG-013): ridego_driver_earnings, a vendor-recorded payout/bonus/deduction ledger per driver, mirroring the existing ridego_booking_payments pattern.', 'callback' => 'ridego_migration_032_driver_earnings' ),
        array( 'version' => 33, 'description' => 'Vendor staff delegation (RG-015): ridego_vendor_staff, letting a vendor owner give a team member their own login scoped to fleet management, without sharing the owner\'s own credentials.', 'callback' => 'ridego_migration_033_vendor_staff' ),
        array( 'version' => 34, 'description' => 'Optimistic concurrency control: lock_version on ridego_bookings, ridego_fleet_vehicles and ridego_fleet_drivers. Replaces an earlier updated_at-based approach abandoned after adversarial testing showed two writes landing in the same wall-clock second are indistinguishable by a 1-second-precision DATETIME — a numeric counter, claimed with a single atomic UPDATE ... WHERE lock_version=%d, has no such gap.', 'callback' => 'ridego_migration_034_optimistic_locking' ),
        array( 'version' => 35, 'description' => 'General-purpose background job queue (ridego_job_queue): generalises the retry/backoff/dead-letter mechanics already proven in the notification queue (includes/notifications.php) into a reusable primitive for any fire-and-retry background work, starting with vendor wallet-credit jobs (lead-fee refunds on cancellation), which previously ran as a single synchronous DB write with no retry if it failed.', 'callback' => 'ridego_migration_035_job_queue' ),
        array( 'version' => 36, 'description' => 'CRITICAL SCHEMA FIX: payment_order_id column on ridego_bookings. ridego_process_razorpay_success() (includes/payment.php) has always tried to write this column on every successful Razorpay payment webhook, but it was never created by any prior migration — MySQL rejects an UPDATE naming an unknown column entirely (the whole SET clause, not just that field), so this write has been silently failing on EVERY Razorpay payment success since the feature was built, discovered only now because a transactional-integrity audit added a return-value check to that previously-unchecked $wpdb->update() call. Booking rows paid via Razorpay never actually reached payment_status=verified/status=confirmed through this path.', 'callback' => 'ridego_migration_036_payment_order_id_column' ),
        array( 'version' => 37, 'description' => 'Client CRM visibility gap: a client account only ever got a wp_ridego_clients row once it completed a booking, leaving every registered-but-never-booked client invisible on the admin Clients screen. Adds ridego_client_sync_from_user() (called from registration going forward) and backfills a profile for every existing subscriber-role account that slipped through.', 'callback' => 'ridego_migration_037_client_registration_sync' ),
        array( 'version' => 38, 'description' => 'Booking notes edit/delete (RideGo-Pre-Delivery-Audit.md, Revision 7, OPEN ISSUES: "Booking notes have no edit/delete"). Adds updated_at and deleted_at to ridego_booking_notes: an edit updates the row and stamps updated_at; a delete is a soft delete (deleted_at set, row kept for the audit trail, especially for a note already shown to the client) rather than a hard DELETE.', 'callback' => 'ridego_migration_038_booking_notes_edit_delete' ),
        array( 'version' => 39, 'description' => 'Client-profile merge tool (RideGo-Pre-Delivery-Audit.md, Revision 7, OPEN ISSUES: "No client merge tool for two profiles that turn out to be the same person"). Adds merged_into/merged_at to ridego_clients.', 'callback' => 'ridego_migration_039_client_merge' ),
        array( 'version' => 40, 'description' => 'Popular-cities photos: image_url column on ridego_cities, so Settings → Cities can attach a real uploaded photo per city for the home page "Popular cities" cards. Blank by default for every existing city — the frontend shows a plain labelled card (no fabricated stock photo) until an admin actually uploads one.', 'callback' => 'ridego_migration_040_city_image' ),
        array( 'version' => 41, 'description' => 'Route Marketing Pages (automated route-based SEO): ridego_route_pages, one row per origin→destination route (ridego_routes.id) that has a generated marketing/SEO landing page. Purely additive — no existing table touched, no route page exists until an admin explicitly generates one.', 'callback' => 'ridego_migration_041_route_pages' ),
        array( 'version' => 42, 'description' => 'Route Page Hero settings: per-route hero override columns on ridego_route_pages (hero_mode, hero_heading, hero_subheading, hero_bg_color, hero_image_desktop_url, hero_image_mobile_url, hero_height_desktop, hero_height_mobile, hero_overlay_enabled). Every column blank/NULL by default, so every existing route page keeps falling back to the global default (or the hard-coded standard look) until an admin explicitly sets an override for that route.', 'callback' => 'ridego_migration_042_route_page_hero' ),
        array( 'version' => 43, 'description' => 'Route Page dedicated card image: card_image_url column on ridego_route_pages, a separate admin-uploaded image used ONLY for this route\'s small card thumbnail on the Home Page "Popular Outstation Routes" section — distinct from hero_image_desktop_url, which is styled/overlaid for full-bleed hero-banner display and looked wrong shrunk down to a thumbnail. Blank by default for every existing route page, so ridego_app_api_popular_routes() (includes/app-api.php) falls back to the destination/origin city photo, then an honest empty placeholder, until an admin explicitly uploads a card image for that route.', 'callback' => 'ridego_migration_043_route_page_card_image' ),
    );
}

// TRACE: migration runner (schema 41) → creates ridego_route_pages → true|false.
//        Preconditions: ridego_routes exists (created by install.php). Postconditions: an
//        empty table ready for ridego_create_route_page() (includes/route-pages.php) to
//        insert into — no row is created here, so nothing changes for any existing route
//        or page until an admin actually runs the generator. Edge cases: table already
//        exists (no-op via CREATE TABLE IF NOT EXISTS + dbDelta-free direct query, same
//        pattern as every other table in this file).
function ridego_migration_041_route_pages() {
    global $wpdb;
    $p  = $wpdb->prefix;
    $cs = $wpdb->get_charset_collate();
    return ridego_mkt_create_table( "{$p}ridego_route_pages", "CREATE TABLE IF NOT EXISTS {$p}ridego_route_pages (
        id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        route_id          INT UNSIGNED NOT NULL,
        slug              VARCHAR(160) NOT NULL,
        seo_title         VARCHAR(160) NOT NULL DEFAULT '',
        meta_description  VARCHAR(320) NOT NULL DEFAULT '',
        status            VARCHAR(20) NOT NULL DEFAULT 'draft',
        quality_issues    TEXT NULL,
        generated_by      BIGINT UNSIGNED NOT NULL DEFAULT 0,
        published_at      DATETIME NULL,
        created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY route_id (route_id),
        UNIQUE KEY slug (slug),
        KEY status (status)
    ) {$cs}" );
}

// TRACE: migration runner (schema 42) → adds per-route hero override columns to
//        ridego_route_pages if missing → true. Preconditions: ridego_route_pages exists
//        (migration 041). Postconditions: every existing route page row has hero_mode=''
//        and every other hero_* column blank/NULL, so ridego_route_page_effective_hero()
//        (includes/route-pages.php) falls back to the global default / hard-coded standard
//        look for every page until an admin explicitly sets an override. Edge cases: re-run
//        (no-op, each column added only if missing).
function ridego_migration_042_route_page_hero() {
    global $wpdb;
    $tbl = "{$wpdb->prefix}ridego_route_pages";
    if ( ! ridego_table_exists( $tbl ) ) { return true; }
    $ok = true;
    $ok = ridego_add_column_if_missing( $tbl, 'hero_mode',              "VARCHAR(20) NOT NULL DEFAULT ''" ) !== false && $ok;
    $ok = ridego_add_column_if_missing( $tbl, 'hero_heading',           "VARCHAR(200) NOT NULL DEFAULT ''" ) !== false && $ok;
    $ok = ridego_add_column_if_missing( $tbl, 'hero_subheading',        "VARCHAR(320) NOT NULL DEFAULT ''" ) !== false && $ok;
    $ok = ridego_add_column_if_missing( $tbl, 'hero_bg_color',          "VARCHAR(20) NOT NULL DEFAULT ''" ) !== false && $ok;
    $ok = ridego_add_column_if_missing( $tbl, 'hero_image_desktop_url', "VARCHAR(500) NOT NULL DEFAULT ''" ) !== false && $ok;
    $ok = ridego_add_column_if_missing( $tbl, 'hero_image_mobile_url',  "VARCHAR(500) NOT NULL DEFAULT ''" ) !== false && $ok;
    $ok = ridego_add_column_if_missing( $tbl, 'hero_height_desktop',    "VARCHAR(20) NOT NULL DEFAULT ''" ) !== false && $ok;
    $ok = ridego_add_column_if_missing( $tbl, 'hero_height_mobile',     "VARCHAR(20) NOT NULL DEFAULT ''" ) !== false && $ok;
    $ok = ridego_add_column_if_missing( $tbl, 'hero_overlay_enabled',   "TINYINT(1) NULL DEFAULT NULL" ) !== false && $ok;
    return $ok;
}

// TRACE: migration runner (schema 43) → adds card_image_url to
//        ridego_route_pages if missing → true. Preconditions: ridego_route_pages
//        exists (migration 041). Postconditions: every existing route page row
//        has card_image_url='', so ridego_app_api_popular_routes() keeps falling
//        back to the destination/origin city photo (never the hero image) until
//        an admin explicitly uploads a dedicated card image for that route.
//        Edge cases: re-run (no-op, column added only if missing).
function ridego_migration_043_route_page_card_image() {
    global $wpdb;
    $tbl = "{$wpdb->prefix}ridego_route_pages";
    if ( ! ridego_table_exists( $tbl ) ) { return true; }
    return ridego_add_column_if_missing( $tbl, 'card_image_url', "VARCHAR(500) NOT NULL DEFAULT ''" ) !== false;
}

// TRACE: migration runner → adds image_url to ridego_cities if missing → true.
//        Preconditions: none. Postconditions: every existing city row has image_url=''
//        (falsy/blank), so ridego_app_serialize_city() keeps returning '' for it exactly
//        as it does today, until an admin uploads a real photo through Settings → Cities.
function ridego_migration_040_city_image() {
    global $wpdb;
    $tbl = "{$wpdb->prefix}ridego_cities";
    if ( ! ridego_table_exists( $tbl ) ) { return true; }
    return ridego_add_column_if_missing( $tbl, 'image_url', "VARCHAR(255) NOT NULL DEFAULT ''" ) !== false;
}

// TRACE: migration runner → creates ridego_vendor_staff → true. Preconditions: none.
//        Postconditions: one row per staff login a vendor owner has created; status starts
//        'active', set to 'suspended' on revoke (the WP user account itself is never deleted,
//        matching how a driver login revoke would be handled — a soft, reversible state, not a
//        destructive one). Edge cases: re-run (no-op).
function ridego_migration_033_vendor_staff() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;
    return ridego_mkt_create_table( "{$p}ridego_vendor_staff", "CREATE TABLE IF NOT EXISTS {$p}ridego_vendor_staff (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        vendor_id   BIGINT UNSIGNED NOT NULL,
        user_id     BIGINT UNSIGNED NOT NULL,
        name        VARCHAR(150)    NOT NULL DEFAULT '',
        status      VARCHAR(10)     NOT NULL DEFAULT 'active',
        created_by  BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id),
        KEY vendor_id (vendor_id)
    ) $c;" );
}

// TRACE: migration runner → adds lock_version to the three tables an optimistic-lock-aware update
//        function currently exists for → true. Preconditions: none. Postconditions: every existing row
//        starts at 1 (the DEFAULT), so a client that read a row before this migration ran and sends no
//        expected_lock_version is unaffected (the check is opt-in — see ridego_claim_lock_version());
//        one that does send a version claims it with a single atomic UPDATE ... WHERE lock_version=%d,
//        never a read-then-write pair, so there is no gap for a second writer to land in between the
//        check and the claim. Edge cases: column already present from a partial prior run (no-op, via
//        ridego_add_column_if_missing()).
function ridego_migration_034_optimistic_locking() {
    global $wpdb;
    $p = $wpdb->prefix;
    $ok1 = ridego_add_column_if_missing( "{$p}ridego_bookings", 'lock_version', "INT UNSIGNED NOT NULL DEFAULT 1" );
    $ok2 = ridego_add_column_if_missing( "{$p}ridego_fleet_vehicles", 'lock_version', "INT UNSIGNED NOT NULL DEFAULT 1" );
    $ok3 = ridego_add_column_if_missing( "{$p}ridego_fleet_drivers", 'lock_version', "INT UNSIGNED NOT NULL DEFAULT 1" );
    return $ok1 && $ok2 && $ok3;
}

// TRACE: migration runner v35 → creates ridego_job_queue → true. Preconditions: none. Postconditions: an
//        empty, ready-to-use general-purpose job table with the exact same retry/backoff/dead-letter shape
//        already proven correct in ridego_notification_queue (status, attempts, next_retry_at, error_msg),
//        so ridego_process_job_queue() (includes/jobs.php) can reuse that same battle-tested processing
//        loop for any job_type, not only notifications. Edge cases: re-run (no-op, via ridego_mkt_create_table()).
function ridego_migration_035_job_queue() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;
    return ridego_mkt_create_table( "{$p}ridego_job_queue", "CREATE TABLE IF NOT EXISTS {$p}ridego_job_queue (
        id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        job_type       VARCHAR(60)     NOT NULL,
        payload        LONGTEXT        NOT NULL,
        status         VARCHAR(12)     NOT NULL DEFAULT 'pending',
        priority       VARCHAR(10)     NOT NULL DEFAULT 'normal',
        attempts       INT UNSIGNED    NOT NULL DEFAULT 0,
        max_attempts   INT UNSIGNED    NOT NULL DEFAULT 5,
        scheduled_for  DATETIME        NOT NULL,
        next_retry_at  DATETIME        DEFAULT NULL,
        error_msg      TEXT            NOT NULL DEFAULT '',
        done_at        DATETIME        DEFAULT NULL,
        created_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY status_scheduled (status, scheduled_for),
        KEY next_retry_at (next_retry_at),
        KEY job_type (job_type)
    ) $c;" );
}

// TRACE: migration runner → adds the missing payment_order_id column to ridego_bookings → true.
//        Preconditions: none (idempotent via ridego_add_column_if_missing). Postconditions: every
//        existing row gets payment_order_id='' (safe default — nothing to backfill, since no row could
//        ever have had this value written before this migration existed); ridego_process_razorpay_success()
//        can now actually persist the Razorpay order id it has always tried to write. Edge cases: table
//        missing entirely (fresh installs that never ran the marketplace migrations at all) — guarded the
//        same way every other column-add migration in this file is.
function ridego_migration_036_payment_order_id_column() {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_bookings';
    if ( ! ridego_table_exists( $tbl ) ) { return true; }
    ridego_add_column_if_missing( $tbl, 'payment_order_id', "VARCHAR(100) NOT NULL DEFAULT ''" );
    return true;
}

// TRACE: migration runner v37 → backfills a wp_ridego_clients row for every existing subscriber-role
//        account that registered before ridego_client_sync_from_user() existed and never completed a
//        booking (the only other path that ever created one) → true. Preconditions: ridego_clients table
//        exists (created by migration 24). Postconditions: idempotent — ridego_clients_backfill_from_users()
//        skips any user already linked by wp_user_id. Edge cases: table missing entirely (fresh install
//        ordering edge case) — guarded the same way migration 036 guards ridego_bookings.
function ridego_migration_037_client_registration_sync() {
    if ( ! ridego_table_exists( $GLOBALS['wpdb']->prefix . 'ridego_clients' ) ) { return true; }
    if ( function_exists( 'ridego_clients_backfill_from_users' ) ) { ridego_clients_backfill_from_users(); }
    return true;
}

// TRACE: migration runner (schema 38) → adds ridego_booking_notes.updated_at / deleted_at → true|false. Idempotent.
//        Preconditions: ridego_booking_notes exists (created by migration 24; a fresh install with no CRM tables yet is a no-op, matching the pattern used by migration 37 above).
//        Postconditions: existing notes get updated_at=NULL, deleted_at=NULL (never edited/deleted, exactly their prior state). Edge cases: column already present (no-op), ALTER failure (returns false so the runner retries).
function ridego_migration_038_booking_notes_edit_delete() {
    $t = $GLOBALS['wpdb']->prefix . 'ridego_booking_notes';
    if ( ! ridego_table_exists( $t ) ) { return true; }
    foreach ( array( 'updated_at' => 'DATETIME NULL', 'deleted_at' => 'DATETIME NULL' ) as $col => $def ) {
        if ( ridego_add_column_if_missing( $t, $col, $def ) === false ) { return false; }
    }
    return true;
}

// TRACE: migration runner (schema 39) → adds ridego_clients.merged_into / merged_at → true|false. Idempotent.
//        Preconditions: ridego_clients exists. Postconditions: existing clients get merged_into=NULL (never merged, their prior state). Edge cases: column already present (no-op), ALTER failure (returns false so the runner retries).
function ridego_migration_039_client_merge() {
    $t = $GLOBALS['wpdb']->prefix . 'ridego_clients';
    if ( ! ridego_table_exists( $t ) ) { return true; }
    foreach ( array( 'merged_into' => 'BIGINT UNSIGNED NULL', 'merged_at' => 'DATETIME NULL' ) as $col => $def ) {
        if ( ridego_add_column_if_missing( $t, $col, $def ) === false ) { return false; }
    }
    return true;
}

// TRACE: migration runner → creates ridego_driver_earnings → true. Preconditions: none.
//        Postconditions: one row per payout/bonus/deduction/adjustment a vendor records for one of
//        their own drivers; a running balance is computed by summing amount (deductions stored as
//        negative), never stored as a denormalised total, so it can never drift from its own ledger.
//        Edge cases: re-run (no-op).
function ridego_migration_032_driver_earnings() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;
    return ridego_mkt_create_table( "{$p}ridego_driver_earnings", "CREATE TABLE IF NOT EXISTS {$p}ridego_driver_earnings (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        driver_id    BIGINT UNSIGNED NOT NULL,
        vendor_id    BIGINT UNSIGNED NOT NULL,
        booking_id   BIGINT UNSIGNED DEFAULT NULL,
        entry_type   VARCHAR(20)     NOT NULL,
        amount       DECIMAL(10,2)   NOT NULL,
        note         VARCHAR(255)    NOT NULL DEFAULT '',
        recorded_by  BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY driver_id (driver_id),
        KEY vendor_id (vendor_id),
        KEY booking_id (booking_id)
    ) $c;" );
}

// TRACE: migration runner → adds four nullable columns to ridego_bookings → true. Preconditions:
//        ridego_bookings exists. Postconditions: existing rows keep all four columns NULL/empty
//        (meaning "never happened"), so this is purely additive and changes no existing row's
//        meaning. Edge cases: re-run (no-op, ridego_add_column_if_missing is itself idempotent).
function ridego_migration_031_driver_trip_state() {
    $tbl = "{$GLOBALS['wpdb']->prefix}ridego_bookings";
    if ( ! ridego_table_exists( $tbl ) ) { return true; }
    ridego_add_column_if_missing( $tbl, 'driver_en_route_at', 'DATETIME DEFAULT NULL' );
    ridego_add_column_if_missing( $tbl, 'driver_arrived_at', 'DATETIME DEFAULT NULL' );
    ridego_add_column_if_missing( $tbl, 'no_show_at', 'DATETIME DEFAULT NULL' );
    ridego_add_column_if_missing( $tbl, 'no_show_reason', "VARCHAR(255) NOT NULL DEFAULT ''" );
    return true;
}

// TRACE: migration runner → creates ridego_privacy_requests → true when the table
//        exists. Preconditions: none. Postconditions: one row per export/delete
//        request; status starts 'pending', moves to 'fulfilled'|'rejected' only via
//        the admin endpoint, which always fills reviewed_by/reviewed_at/admin_note.
//        A 'delete' request is never auto-actioned — financial/legal records (booking,
//        payment and audit rows) must be retained per retention policy, so fulfilling
//        one is a manual admin action (anonymising the user's identifying fields)
//        recorded here for accountability, not a trigger that deletes rows itself.
//        Edge cases: re-run (no-op, table already exists).
function ridego_migration_030_privacy_requests() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;

    return ridego_mkt_create_table( "{$p}ridego_privacy_requests", "CREATE TABLE IF NOT EXISTS {$p}ridego_privacy_requests (
        id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id       BIGINT UNSIGNED NOT NULL,
        request_type  VARCHAR(20)     NOT NULL,
        status        VARCHAR(20)     NOT NULL DEFAULT 'pending',
        reason        VARCHAR(500)    NOT NULL DEFAULT '',
        admin_note    VARCHAR(500)    NOT NULL DEFAULT '',
        reviewed_by   BIGINT UNSIGNED DEFAULT NULL,
        reviewed_at   DATETIME        DEFAULT NULL,
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY status (status)
    ) $c;" );
}

// TRACE: any migration needing a table → runs one CREATE TABLE IF NOT EXISTS
//        statement → returns true when the table exists afterwards, false on a
//        DB error (and logs it). Preconditions: $sql is a full CREATE TABLE.
//        Postconditions: table exists or the caller gets false so the migration
//        chain halts instead of advancing the schema version past a failure.
//        Edge cases: table already present (no-op, true); SQL error (false).
function ridego_mkt_create_table( $table, $sql ) {
    global $wpdb;
    if ( ridego_table_exists( $table ) ) { return true; }
    $wpdb->query( $sql );
    if ( ! ridego_table_exists( $table ) ) {
        ridego_log( 'MIGRATION ERROR creating ' . $table . ': ' . $wpdb->last_error );
        return false;
    }
    return true;
}

// TRACE: a migration that adds columns to ridego_bookings → copies every column
//        that exists on ridego_bookings but not on ridego_bookings_archive onto the
//        archive → returns void. Why: ridego_archive_old_bookings() does
//        $wpdb->insert(archive, (array) $row) from SELECT *, and an insert naming a
//        column the archive lacks fails outright, silently stopping archiving.
//        Preconditions: none. Postconditions: archive column set ⊇ bookings column
//        set. Edge cases: archive table absent (skipped); column already present
//        (skipped); auto-increment/primary key columns are never re-added.
function ridego_mkt_sync_archive_columns() {
    global $wpdb;
    $bookings = "{$wpdb->prefix}ridego_bookings";
    $archive  = "{$wpdb->prefix}ridego_bookings_archive";
    if ( ! ridego_table_exists( $bookings ) || ! ridego_table_exists( $archive ) ) { return; }
    $cols = $wpdb->get_results( "SHOW COLUMNS FROM {$bookings}" );
    foreach ( (array) $cols as $col ) {
        if ( ridego_column_exists( $archive, $col->Field ) ) { continue; }
        $def = $col->Type . ( $col->Null === 'YES' ? ' NULL' : ' NOT NULL' );
        if ( $col->Default !== null && stripos( (string) $col->Extra, 'auto_increment' ) === false ) {
            $def .= ( in_array( strtoupper( (string) $col->Default ), array( 'CURRENT_TIMESTAMP', 'CURRENT_TIMESTAMP()' ), true ) )
                ? ' DEFAULT CURRENT_TIMESTAMP'
                : $wpdb->prepare( ' DEFAULT %s', $col->Default );
        } elseif ( $col->Null === 'YES' ) {
            $def .= ' DEFAULT NULL';
        }
        $wpdb->query( "ALTER TABLE {$archive} ADD COLUMN {$col->Field} {$def}" );
    }
}

// TRACE: migration runner → adds vendor_type, four fleet tables, and vehicle/driver
//        keys on ridego_driver_docs → returns true. Preconditions: ridego_vendors
//        and ridego_driver_docs exist (baseline). Postconditions: every existing
//        vendor row has vendor_type='individual' (column default); no data moved.
//        Edge cases: vendors table missing on a broken install (columns skipped,
//        tables still created); re-run (all guards no-op).
function ridego_migration_015_fleet() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;

    ridego_add_column_if_missing( "{$p}ridego_vendors", 'vendor_type', "VARCHAR(20) NOT NULL DEFAULT 'individual'" );
    ridego_add_index_if_missing( "{$p}ridego_vendors", 'vendor_type', 'vendor_type' );

    $ok = true;
    $ok = ridego_mkt_create_table( "{$p}ridego_fleet_vehicles", "CREATE TABLE IF NOT EXISTS {$p}ridego_fleet_vehicles (
        id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        vendor_id           INT UNSIGNED    NOT NULL,
        branch_id           BIGINT UNSIGNED DEFAULT NULL,
        vehicle_type_id     INT UNSIGNED    NOT NULL DEFAULT 0,
        make_model          VARCHAR(120)    NOT NULL DEFAULT '',
        registration_number VARCHAR(20)     NOT NULL DEFAULT '',
        seating_capacity    TINYINT UNSIGNED NOT NULL DEFAULT 4,
        status              VARCHAR(20)     NOT NULL DEFAULT 'active',
        created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY vendor_id (vendor_id),
        KEY branch_id (branch_id),
        KEY registration_number (registration_number),
        KEY status (status)
    ) $c;" ) && $ok;

    $ok = ridego_mkt_create_table( "{$p}ridego_fleet_drivers", "CREATE TABLE IF NOT EXISTS {$p}ridego_fleet_drivers (
        id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        vendor_id        INT UNSIGNED    NOT NULL,
        branch_id        BIGINT UNSIGNED DEFAULT NULL,
        name             VARCHAR(150)    NOT NULL DEFAULT '',
        mobile           VARCHAR(20)     NOT NULL DEFAULT '',
        license_number   VARCHAR(50)     NOT NULL DEFAULT '',
        license_expiry   DATE            DEFAULT NULL,
        experience_years TINYINT UNSIGNED NOT NULL DEFAULT 0,
        service_area_note VARCHAR(255)   NOT NULL DEFAULT '',
        rating           DECIMAL(3,2)    NOT NULL DEFAULT 0.00,
        total_ratings    INT UNSIGNED    NOT NULL DEFAULT 0,
        status           VARCHAR(20)     NOT NULL DEFAULT 'active',
        created_at       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY vendor_id (vendor_id),
        KEY branch_id (branch_id),
        KEY status (status)
    ) $c;" ) && $ok;

    $ok = ridego_mkt_create_table( "{$p}ridego_fleet_unavailability", "CREATE TABLE IF NOT EXISTS {$p}ridego_fleet_unavailability (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        vendor_id   INT UNSIGNED    NOT NULL,
        entity_type VARCHAR(10)     NOT NULL,
        entity_id   BIGINT UNSIGNED NOT NULL,
        starts_at   DATETIME        NOT NULL,
        ends_at     DATETIME        NOT NULL,
        reason      VARCHAR(255)    NOT NULL DEFAULT '',
        created_by  BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY entity (entity_type, entity_id, starts_at, ends_at),
        KEY vendor_id (vendor_id)
    ) $c;" ) && $ok;

    $ok = ridego_mkt_create_table( "{$p}ridego_vendor_branches", "CREATE TABLE IF NOT EXISTS {$p}ridego_vendor_branches (
        id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        vendor_id  INT UNSIGNED    NOT NULL,
        name       VARCHAR(150)    NOT NULL DEFAULT '',
        address    TEXT            NULL,
        city_id    INT UNSIGNED    NOT NULL DEFAULT 0,
        lat        DECIMAL(10,8)   DEFAULT NULL,
        lng        DECIMAL(11,8)   DEFAULT NULL,
        is_primary TINYINT(1)      NOT NULL DEFAULT 0,
        status     VARCHAR(20)     NOT NULL DEFAULT 'active',
        created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY vendor_id (vendor_id),
        KEY city_id (city_id)
    ) $c;" ) && $ok;

    /* Per-vehicle (RC/insurance/permit) and per-driver (licence) documents
       reuse the existing document mechanism via two extra nullable keys. */
    ridego_add_column_if_missing( "{$p}ridego_driver_docs", 'vehicle_id', "BIGINT UNSIGNED DEFAULT NULL" );
    ridego_add_column_if_missing( "{$p}ridego_driver_docs", 'driver_id', "BIGINT UNSIGNED DEFAULT NULL" );
    ridego_add_index_if_missing( "{$p}ridego_driver_docs", 'vehicle_id', 'vehicle_id' );
    ridego_add_index_if_missing( "{$p}ridego_driver_docs", 'driver_id', 'driver_id' );

    return $ok;
}

// TRACE: migration runner → adds lead interest columns, backfills interest_status
//        from the legacy status column, adds booking columns, syncs the archive →
//        returns true. Preconditions: ridego_leads and ridego_bookings exist.
//        Postconditions: leads.status untouched; every legacy non-'sent' lead maps
//        to a matching interest_status (accepted→driver_confirmed, rejected→declined,
//        expired→expired, lost_to_other_vendor→not_selected). Edge cases: re-run
//        (backfill only touches rows still at the default 'sent' whose status differs).
function ridego_migration_016_leads_and_booking_columns() {
    global $wpdb;
    $p  = $wpdb->prefix;
    $lt = "{$p}ridego_leads";
    $bt = "{$p}ridego_bookings";

    ridego_add_column_if_missing( $lt, 'interest_status', "VARCHAR(20) NOT NULL DEFAULT 'sent'" );
    ridego_add_column_if_missing( $lt, 'viewed_at', "DATETIME DEFAULT NULL" );
    ridego_add_column_if_missing( $lt, 'interested_at', "DATETIME DEFAULT NULL" );
    ridego_add_column_if_missing( $lt, 'driver_confirmed_at', "DATETIME DEFAULT NULL" );
    ridego_add_column_if_missing( $lt, 'driver_name', "VARCHAR(150) NOT NULL DEFAULT ''" );
    ridego_add_column_if_missing( $lt, 'driver_phone', "VARCHAR(20) NOT NULL DEFAULT ''" );
    ridego_add_column_if_missing( $lt, 'vehicle_model', "VARCHAR(120) NOT NULL DEFAULT ''" );
    ridego_add_column_if_missing( $lt, 'vehicle_registration', "VARCHAR(20) NOT NULL DEFAULT ''" );
    ridego_add_column_if_missing( $lt, 'vehicle_notes', "VARCHAR(255) NOT NULL DEFAULT ''" );
    ridego_add_column_if_missing( $lt, 'vehicle_id', "BIGINT UNSIGNED DEFAULT NULL" );
    ridego_add_column_if_missing( $lt, 'driver_id', "BIGINT UNSIGNED DEFAULT NULL" );
    ridego_add_column_if_missing( $lt, 'reminder_sent_at', "DATETIME DEFAULT NULL" );
    ridego_add_column_if_missing( $lt, 'not_selected_reason', "VARCHAR(200) NOT NULL DEFAULT ''" );
    ridego_add_index_if_missing( $lt, 'interest_status', 'interest_status' );
    ridego_add_index_if_missing( $lt, 'vehicle_id', 'vehicle_id' );
    ridego_add_index_if_missing( $lt, 'driver_id', 'driver_id' );

    if ( ridego_column_exists( $lt, 'interest_status' ) ) {
        $wpdb->query(
            "UPDATE {$lt} SET interest_status = CASE status
                WHEN 'accepted' THEN 'driver_confirmed'
                WHEN 'rejected' THEN 'declined'
                WHEN 'expired' THEN 'expired'
                WHEN 'lost_to_other_vendor' THEN 'not_selected'
                ELSE interest_status END
             WHERE interest_status = 'sent' AND status <> 'sent'"
        );
    }

    ridego_add_column_if_missing( $bt, 'assignment_reason', "TEXT NULL" );
    ridego_add_column_if_missing( $bt, 'commission_amount', "DECIMAL(10,2) NOT NULL DEFAULT 0.00" );
    ridego_add_column_if_missing( $bt, 'commission_model_id', "INT UNSIGNED DEFAULT NULL" );
    ridego_add_column_if_missing( $bt, 'closed_at', "DATETIME DEFAULT NULL" );
    ridego_add_index_if_missing( $bt, 'closed_at', 'closed_at' );

    ridego_mkt_sync_archive_columns();
    return true;
}

// TRACE: migration runner → creates assignments + ledger tables → returns true only if
//        both exist. Preconditions: none. Postconditions: assignments has a UNIQUE
//        current_booking_id (set only while is_current=1) so the DB itself guarantees
//        at most one current assignment per booking; ledger has a UNIQUE dedupe_key so
//        a retried write can never create a second row for the same money movement.
//        Edge cases: re-run (tables exist → no-op).
function ridego_migration_017_assignments_and_ledger() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;

    $ok = ridego_mkt_create_table( "{$p}ridego_booking_assignments", "CREATE TABLE IF NOT EXISTS {$p}ridego_booking_assignments (
        id                          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_id                  BIGINT UNSIGNED NOT NULL,
        lead_id                     BIGINT UNSIGNED DEFAULT NULL,
        vendor_id                   INT UNSIGNED    NOT NULL,
        driver_id                   BIGINT UNSIGNED DEFAULT NULL,
        driver_name_snapshot        VARCHAR(150)    NOT NULL DEFAULT '',
        driver_phone_snapshot       VARCHAR(20)     NOT NULL DEFAULT '',
        vehicle_id                  BIGINT UNSIGNED DEFAULT NULL,
        vehicle_model_snapshot      VARCHAR(120)    NOT NULL DEFAULT '',
        vehicle_registration_snapshot VARCHAR(20)   NOT NULL DEFAULT '',
        is_current                  TINYINT(1)      NOT NULL DEFAULT 1,
        current_booking_id          BIGINT UNSIGNED DEFAULT NULL,
        replaces_assignment_id      BIGINT UNSIGNED DEFAULT NULL,
        replacement_reason          VARCHAR(255)    NOT NULL DEFAULT '',
        source                      VARCHAR(20)     NOT NULL DEFAULT 'admin',
        changed_by                  BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at                  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY current_booking_id (current_booking_id),
        KEY booking_id (booking_id),
        KEY vendor_id (vendor_id),
        KEY driver_current (driver_id, is_current),
        KEY vehicle_current (vehicle_id, is_current)
    ) $c;" );

    $ok = ridego_mkt_create_table( "{$p}ridego_booking_ledger", "CREATE TABLE IF NOT EXISTS {$p}ridego_booking_ledger (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_id  BIGINT UNSIGNED NOT NULL,
        vendor_id   INT UNSIGNED    DEFAULT NULL,
        entry_type  VARCHAR(30)     NOT NULL,
        amount      DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        direction   VARCHAR(6)      NOT NULL DEFAULT 'credit',
        status      VARCHAR(10)     NOT NULL DEFAULT 'pending',
        settled_at  DATETIME        DEFAULT NULL,
        dedupe_key  VARCHAR(80)     DEFAULT NULL,
        notes       VARCHAR(255)    NOT NULL DEFAULT '',
        created_by  BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY dedupe_key (dedupe_key),
        KEY booking_id (booking_id),
        KEY vendor_type_status (vendor_id, entry_type, status),
        KEY status (status)
    ) $c;" ) && $ok;

    return $ok;
}

// TRACE: migration runner → creates the two commission tables → true when both exist.
//        Preconditions: none. Postconditions: NO commission model is seeded and no
//        vendor is assigned one, so upgrading never starts charging anyone; commission
//        stays 0 until an admin creates a model and marks it default/assigns it.
//        Edge cases: re-run (no-op).
function ridego_migration_018_commission() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;

    $ok = ridego_mkt_create_table( "{$p}ridego_commission_models", "CREATE TABLE IF NOT EXISTS {$p}ridego_commission_models (
        id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        name              VARCHAR(150)    NOT NULL DEFAULT '',
        type              VARCHAR(20)     NOT NULL DEFAULT 'fixed',
        fixed_amount      DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        percentage        DECIMAL(5,2)    NOT NULL DEFAULT 0.00,
        min_amount        DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        monthly_fee       DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        refund_adjustment VARCHAR(10)     NOT NULL DEFAULT 'none',
        is_active         TINYINT(1)      NOT NULL DEFAULT 1,
        is_default        TINYINT(1)      NOT NULL DEFAULT 0,
        created_at        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY is_default (is_default),
        KEY is_active (is_active)
    ) $c;" );

    $ok = ridego_mkt_create_table( "{$p}ridego_vendor_commission_assignments", "CREATE TABLE IF NOT EXISTS {$p}ridego_vendor_commission_assignments (
        id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        vendor_id           INT UNSIGNED    NOT NULL,
        commission_model_id BIGINT UNSIGNED NOT NULL,
        effective_from      DATETIME        NOT NULL,
        assigned_by         BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at          DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY vendor_effective (vendor_id, effective_from)
    ) $c;" ) && $ok;

    return $ok;
}

// TRACE: migration runner → extends ridego_ratings, creates service_events and
//        performance_snapshots → true when both new tables exist. Preconditions:
//        ridego_ratings exists (baseline). Postconditions: existing rating rows
//        (if any) default to rating_category='overall'; snapshots have UNIQUE
//        (entity_type, entity_id, period) so the nightly job can UPSERT.
//        Edge cases: re-run (no-op).
function ridego_migration_019_ratings_and_performance() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;

    ridego_add_column_if_missing( "{$p}ridego_ratings", 'rating_category', "VARCHAR(30) NOT NULL DEFAULT 'overall'" );
    ridego_add_column_if_missing( "{$p}ridego_ratings", 'driver_name', "VARCHAR(150) NOT NULL DEFAULT ''" );
    ridego_add_column_if_missing( "{$p}ridego_ratings", 'vehicle_registration', "VARCHAR(20) NOT NULL DEFAULT ''" );
    ridego_add_index_if_missing( "{$p}ridego_ratings", 'rated_lookup', 'rated_type, rated_id, rating_category' );

    $ok = ridego_mkt_create_table( "{$p}ridego_service_events", "CREATE TABLE IF NOT EXISTS {$p}ridego_service_events (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_id  BIGINT UNSIGNED NOT NULL DEFAULT 0,
        entity_type VARCHAR(10)     NOT NULL,
        entity_id   BIGINT UNSIGNED NOT NULL,
        event_type  VARCHAR(30)     NOT NULL,
        event_value DECIMAL(10,2)   DEFAULT NULL,
        recorded_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        recorded_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
        notes       VARCHAR(255)    NOT NULL DEFAULT '',
        PRIMARY KEY (id),
        KEY entity_event (entity_type, entity_id, event_type, recorded_at),
        KEY booking_id (booking_id)
    ) $c;" );

    $ok = ridego_mkt_create_table( "{$p}ridego_performance_snapshots", "CREATE TABLE IF NOT EXISTS {$p}ridego_performance_snapshots (
        id                    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        entity_type           VARCHAR(10)     NOT NULL,
        entity_id             BIGINT UNSIGNED NOT NULL,
        period                VARCHAR(7)      NOT NULL,
        bookings_completed    INT UNSIGNED    NOT NULL DEFAULT 0,
        bookings_cancelled    INT UNSIGNED    NOT NULL DEFAULT 0,
        response_time_avg_secs INT UNSIGNED   DEFAULT NULL,
        completion_rate       DECIMAL(5,2)    DEFAULT NULL,
        cancellation_rate     DECIMAL(5,2)    DEFAULT NULL,
        avg_rating            DECIMAL(3,2)    DEFAULT NULL,
        on_time_pct           DECIMAL(5,2)    DEFAULT NULL,
        complaint_count       INT UNSIGNED    NOT NULL DEFAULT 0,
        computed_at           DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY entity_period (entity_type, entity_id, period),
        KEY period (period)
    ) $c;" ) && $ok;

    return $ok;
}

// TRACE: migration runner → creates impersonation log, adds audit_log.acting_as_id →
//        true when the log table exists. Preconditions: ridego_audit_log exists.
//        Postconditions: existing audit rows keep acting_as_id NULL (meaning "no
//        impersonation"). Edge cases: audit table missing (column skipped, log table
//        still created); re-run (no-op).
function ridego_migration_020_impersonation() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;

    $ok = ridego_mkt_create_table( "{$p}ridego_impersonation_log", "CREATE TABLE IF NOT EXISTS {$p}ridego_impersonation_log (
        id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        session_id     CHAR(32)        NOT NULL,
        admin_user_id  BIGINT UNSIGNED NOT NULL,
        target_user_id BIGINT UNSIGNED NOT NULL,
        target_role    VARCHAR(30)     NOT NULL DEFAULT '',
        started_at     DATETIME        NOT NULL,
        expires_at     DATETIME        NOT NULL,
        ended_at       DATETIME        DEFAULT NULL,
        end_reason     VARCHAR(20)     NOT NULL DEFAULT '',
        ip_address     VARCHAR(45)     NOT NULL DEFAULT '',
        PRIMARY KEY (id),
        UNIQUE KEY session_id (session_id),
        KEY admin_user_id (admin_user_id),
        KEY target_user_id (target_user_id)
    ) $c;" );

    ridego_add_column_if_missing( "{$p}ridego_audit_log", 'acting_as_id', "BIGINT UNSIGNED DEFAULT NULL" );
    return $ok;
}

// TRACE: migration runner → creates the two matching tables and seeds ONE default
//        weight profile ("Balanced v1") → true when both tables exist. Preconditions:
//        none. Postconditions: profile rows share profile_id (= first row's id); the
//        seeded profile is active but automatic assignment flags stay at their
//        default OFF, so it only ever produces recommendations. Edge cases: re-run
//        (seed skipped when any profile row exists).
function ridego_migration_021_matching() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;

    $ok = ridego_mkt_create_table( "{$p}ridego_matching_weight_profiles", "CREATE TABLE IF NOT EXISTS {$p}ridego_matching_weight_profiles (
        id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        profile_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
        name       VARCHAR(100)    NOT NULL DEFAULT '',
        factor     VARCHAR(40)     NOT NULL,
        weight     DECIMAL(6,4)    NOT NULL DEFAULT 0.0000,
        is_active  TINYINT(1)      NOT NULL DEFAULT 0,
        version    INT UNSIGNED    NOT NULL DEFAULT 1,
        created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY profile_id (profile_id),
        KEY is_active (is_active)
    ) $c;" );

    $ok = ridego_mkt_create_table( "{$p}ridego_matching_recommendations", "CREATE TABLE IF NOT EXISTS {$p}ridego_matching_recommendations (
        id                    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_id            BIGINT UNSIGNED NOT NULL,
        recommended_vendor_id INT UNSIGNED    NOT NULL,
        recommended_driver_id BIGINT UNSIGNED DEFAULT NULL,
        recommended_vehicle_id BIGINT UNSIGNED DEFAULT NULL,
        score                 DECIMAL(8,4)    NOT NULL DEFAULT 0.0000,
        factor_breakdown      LONGTEXT        NULL,
        weight_profile_id     BIGINT UNSIGNED NOT NULL DEFAULT 0,
        was_followed          TINYINT(1)      DEFAULT NULL,
        override_reason       VARCHAR(255)    NOT NULL DEFAULT '',
        created_at            DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY booking_id (booking_id),
        KEY weight_profile_id (weight_profile_id)
    ) $c;" ) && $ok;

    if ( $ok && function_exists( 'ridego_matching_seed_default_profile' ) ) {
        ridego_matching_seed_default_profile();
    }
    return $ok;
}


// TRACE: migration runner v22 → (1) adds ridego_commission_models.subscription_plan_id (nullable); (2) makes sure a weight
//        profile with the plan's factor names exists and is the active one (older-build profiles are kept, inactive);
//        (3) copies flag settings saved under the earlier names to the plan names, only when the new key was never saved;
//        (4) rewrites the interest_status value 'pending' (never part of the plan enum) to 'sent' → returns bool.
//        Preconditions: v18 and v21 applied. Postconditions: idempotent — a re-run changes nothing. Edge cases: fresh install
//        (no old settings/rows), commission table missing (fails loudly).
function ridego_migration_022_alignment() {
    global $wpdb;
    $p = $wpdb->prefix;
    $ok = ridego_add_column_if_missing( "{$p}ridego_commission_models", 'subscription_plan_id', 'INT UNSIGNED NULL DEFAULT NULL' );
    if ( function_exists( 'ridego_matching_seed_default_profile' ) ) { ridego_matching_seed_default_profile(); }
    $map = array( 'matching_auto_assign_enabled' => 'automatic_vendor_assignment', 'matching_recommendations_enabled' => 'performance_based_matching', 'matching_automatic_reassignment_enabled' => 'automatic_reassignment' );
    foreach ( $map as $old => $new ) {
        $ov = ridego_get_setting( $old, null );
        if ( $ov !== null && ridego_get_setting( $new, null ) === null ) { ridego_update_setting( $new, (int) $ov === 1 ? 1 : 0 ); }
    }
    $wpdb->query( "UPDATE {$p}ridego_leads SET interest_status='sent' WHERE interest_status='pending'" );
    return $ok !== false;
}


// TRACE: migration runner v23 → adds the driver-tracking columns to ridego_fleet_drivers (date_of_birth, alt_mobile, blood_group, address,
//        city, pincode, emergency_contact_*, id_proof_type/number, license_class, badge_number, police_verification_status/date) and
//        driver_profile_snapshot to ridego_booking_assignments → bool. Preconditions: v15 and v17 applied. Postconditions: idempotent
//        (columns added only when missing); existing rows get empty defaults, so legacy drivers simply show as "profile incomplete".
//        Edge cases: a column add failing halts the chain (returns false) instead of advancing the schema version.
function ridego_migration_023_driver_profile() {
    global $wpdb;
    $p = $wpdb->prefix; $t = "{$p}ridego_fleet_drivers";
    $cols = array(
        'date_of_birth' => 'DATE NULL DEFAULT NULL', 'alt_mobile' => "VARCHAR(20) NOT NULL DEFAULT ''", 'blood_group' => "VARCHAR(5) NOT NULL DEFAULT ''",
        'address' => "VARCHAR(255) NOT NULL DEFAULT ''", 'city' => "VARCHAR(100) NOT NULL DEFAULT ''", 'pincode' => "VARCHAR(10) NOT NULL DEFAULT ''",
        'emergency_contact_name' => "VARCHAR(150) NOT NULL DEFAULT ''", 'emergency_contact_phone' => "VARCHAR(20) NOT NULL DEFAULT ''", 'emergency_contact_relation' => "VARCHAR(40) NOT NULL DEFAULT ''",
        'id_proof_type' => "VARCHAR(20) NOT NULL DEFAULT ''", 'id_proof_number' => "VARCHAR(40) NOT NULL DEFAULT ''",
        'license_class' => "VARCHAR(30) NOT NULL DEFAULT ''", 'badge_number' => "VARCHAR(40) NOT NULL DEFAULT ''",
        'police_verification_status' => "VARCHAR(20) NOT NULL DEFAULT 'none'", 'police_verification_date' => 'DATE NULL DEFAULT NULL',
    );
    foreach ( $cols as $c => $def ) {
        if ( ridego_add_column_if_missing( $t, $c, $def ) === false ) { return false; }
    }
    return ridego_add_column_if_missing( "{$p}ridego_booking_assignments", 'driver_profile_snapshot', 'TEXT NULL' ) !== false;
}


// TRACE: migration runner v24 → creates ridego_clients (one profile per person, matched by phone_key = last 10 digits), ridego_booking_payments
//        (append-only payment/refund/adjustment entries), ridego_enquiries (leads/quotations before a booking) and ridego_booking_notes
//        (internal vs client-visible notes); adds booking columns client_profile_id, booking_source, created_by, passenger_details,
//        admin_adjustment, adjustment_reason, reschedule_count, rescheduled_from, invoice_number; syncs the archive table; then backfills a
//        client profile for every distinct phone found on existing bookings and links the bookings → bool.
//        Preconditions: bookings table exists. Postconditions: idempotent (tables IF NOT EXISTS, columns only when missing, backfill only
//        touches bookings whose client_profile_id is 0). Edge cases: bookings with a phone shorter than 10 digits are left unlinked (0);
//        a table create failing halts the chain (false) so the schema version does not advance.
function ridego_migration_024_crm() {
    global $wpdb;
    $p = $wpdb->prefix; $c = $wpdb->get_charset_collate(); $ok = true;
    $ok = ridego_mkt_create_table( "{$p}ridego_clients", "CREATE TABLE IF NOT EXISTS {$p}ridego_clients (
        id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        wp_user_id    BIGINT UNSIGNED NOT NULL DEFAULT 0,
        client_type   VARCHAR(20)     NOT NULL DEFAULT 'individual',
        name          VARCHAR(150)    NOT NULL DEFAULT '',
        phone         VARCHAR(20)     NOT NULL DEFAULT '',
        phone_key     VARCHAR(10)     NOT NULL DEFAULT '',
        alt_phone     VARCHAR(20)     NOT NULL DEFAULT '',
        email         VARCHAR(150)    NOT NULL DEFAULT '',
        address       TEXT            NULL,
        city          VARCHAR(100)    NOT NULL DEFAULT '',
        company_name  VARCHAR(150)    NOT NULL DEFAULT '',
        gst_number    VARCHAR(20)     NOT NULL DEFAULT '',
        notes         TEXT            NULL,
        tags          VARCHAR(255)    NOT NULL DEFAULT '',
        status        VARCHAR(20)     NOT NULL DEFAULT 'active',
        source        VARCHAR(30)     NOT NULL DEFAULT 'online',
        created_by    BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY phone_key (phone_key),
        KEY email (email),
        KEY wp_user_id (wp_user_id),
        KEY status (status),
        KEY client_type (client_type)
    ) $c;" ) && $ok;
    $ok = ridego_mkt_create_table( "{$p}ridego_booking_payments", "CREATE TABLE IF NOT EXISTS {$p}ridego_booking_payments (
        id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_id  BIGINT UNSIGNED NOT NULL,
        client_id   BIGINT UNSIGNED NOT NULL DEFAULT 0,
        entry_type  VARCHAR(20)     NOT NULL DEFAULT 'payment',
        amount      DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        method      VARCHAR(30)     NOT NULL DEFAULT 'cash',
        reference   VARCHAR(100)    NOT NULL DEFAULT '',
        note        VARCHAR(255)    NOT NULL DEFAULT '',
        recorded_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY booking_id (booking_id),
        KEY client_id (client_id),
        KEY entry_type (entry_type)
    ) $c;" ) && $ok;
    $ok = ridego_mkt_create_table( "{$p}ridego_enquiries", "CREATE TABLE IF NOT EXISTS {$p}ridego_enquiries (
        id                   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        client_id            BIGINT UNSIGNED NOT NULL DEFAULT 0,
        name                 VARCHAR(150)    NOT NULL DEFAULT '',
        phone                VARCHAR(20)     NOT NULL DEFAULT '',
        email                VARCHAR(150)    NOT NULL DEFAULT '',
        source               VARCHAR(30)     NOT NULL DEFAULT 'phone',
        trip_type            VARCHAR(30)     NOT NULL DEFAULT '',
        pickup_city          VARCHAR(100)    NOT NULL DEFAULT '',
        drop_city            VARCHAR(100)    NOT NULL DEFAULT '',
        journey_date         DATE            NULL DEFAULT NULL,
        passengers           SMALLINT        NOT NULL DEFAULT 1,
        vehicle_type_id      INT             NOT NULL DEFAULT 0,
        message              TEXT            NULL,
        quoted_amount        DECIMAL(10,2)   NULL DEFAULT NULL,
        status               VARCHAR(20)     NOT NULL DEFAULT 'new',
        follow_up_date       DATE            NULL DEFAULT NULL,
        lost_reason          VARCHAR(255)    NOT NULL DEFAULT '',
        converted_booking_id BIGINT UNSIGNED NULL DEFAULT NULL,
        created_by           BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at           DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at           DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY client_id (client_id),
        KEY status (status),
        KEY follow_up_date (follow_up_date)
    ) $c;" ) && $ok;
    $ok = ridego_mkt_create_table( "{$p}ridego_booking_notes", "CREATE TABLE IF NOT EXISTS {$p}ridego_booking_notes (
        id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_id BIGINT UNSIGNED NOT NULL,
        visibility VARCHAR(10)     NOT NULL DEFAULT 'internal',
        note       TEXT            NOT NULL,
        author_id  BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY booking_id (booking_id)
    ) $c;" ) && $ok;
    if ( ! $ok ) { return false; }

    $b = "{$p}ridego_bookings";
    $cols = array(
        'client_profile_id' => 'BIGINT UNSIGNED NOT NULL DEFAULT 0', 'booking_source' => "VARCHAR(30) NOT NULL DEFAULT 'online'",
        'created_by' => 'BIGINT UNSIGNED NOT NULL DEFAULT 0', 'passenger_details' => 'TEXT NULL', 'admin_adjustment' => 'DECIMAL(10,2) NOT NULL DEFAULT 0.00',
        'adjustment_reason' => "VARCHAR(255) NOT NULL DEFAULT ''", 'reschedule_count' => 'INT NOT NULL DEFAULT 0', 'rescheduled_from' => "VARCHAR(30) NOT NULL DEFAULT ''",
        'invoice_number' => "VARCHAR(30) NOT NULL DEFAULT ''",
    );
    foreach ( $cols as $col => $def ) {
        if ( ridego_add_column_if_missing( $b, $col, $def ) === false ) { return false; }
    }
    ridego_mkt_sync_archive_columns();

    // Backfill: one profile per distinct phone key on existing bookings (latest name/email wins), then link the bookings.
    if ( function_exists( 'ridego_clients_backfill_from_bookings' ) ) { ridego_clients_backfill_from_bookings(); }
    return true;
}


// TRACE: migration runner v25 → adds the facilitator-model columns to ridego_bookings (platform_model 0/1, vendor_collected total, vendor_collected_at, vendor_invoice_number),
//        keeps the archive table in step, flags every booking that already carries a booking/token amount as platform_model=1, switches the booking-amount setting on and
//        rewrites the client instruction text only when it is still the old default → true on success, false when a column cannot be added (runner retries next request).
//        Preconditions: ridego_bookings exists. Postconditions: idempotent (re-run changes nothing). Edge cases: legacy bookings without a token stay platform_model=0 so their history is untouched.
function ridego_migration_025_facilitator_model() {
    global $wpdb;
    $b = $wpdb->prefix . 'ridego_bookings';
    $cols = array( 'platform_model' => 'TINYINT(1) NOT NULL DEFAULT 0', 'vendor_collected' => 'DECIMAL(10,2) NOT NULL DEFAULT 0.00', 'vendor_collected_at' => 'DATETIME NULL', 'vendor_invoice_number' => "VARCHAR(60) NOT NULL DEFAULT ''" );
    foreach ( $cols as $col => $def ) {
        if ( ridego_add_column_if_missing( $b, $col, $def ) === false ) { return false; }
    }
    ridego_mkt_sync_archive_columns();
    $wpdb->query( "UPDATE {$b} SET platform_model=1 WHERE token_amount>0" );
    ridego_update_setting( 'token_payment_enabled', '1' );
    if ( function_exists( 'ridego_platform_default_texts' ) ) {
        $d = ridego_platform_default_texts();
        $cur = (string) ridego_get_setting( 'token_instructions', '' );
        if ( $cur === '' || strpos( $cur, 'This token amount will be adjusted against your total ride payment' ) === 0 ) { ridego_update_setting( 'token_instructions', $d['token_instructions'] ); }
        $lbl = (string) ridego_get_setting( 'token_label', '' );
        if ( $lbl === '' || $lbl === 'Booking Token / Advance Payment' ) { ridego_update_setting( 'token_label', $d['token_label'] ); }
    }
    return true;
}

// TRACE: schema 26 → for each standard-wording setting whose saved value is an older copy of the standard text (same opening as the current default, but not identical), clears it so the
//        current default shows; text an admin genuinely rewrote (different opening) is left alone → true. Edge cases: blank/unset (untouched), platform-model.php not loaded (no-op).
function ridego_migration_026_lead_fee_wording() {
    if ( ! function_exists( 'ridego_platform_default_texts' ) ) { return true; }
    foreach ( ridego_platform_default_texts() as $key => $default ) {
        $cur = trim( (string) ridego_get_setting( $key, '' ) );
        if ( $cur === '' || $cur === $default || $key === 'token_label' ) { continue; }
        if ( strncmp( $cur, $default, 40 ) === 0 ) { ridego_update_setting( $key, '' ); }
    }
    return true;
}


// TRACE: migration runner v27 → creates ridego_lead_fee_terms and ridego_vendor_terms_acceptance, adds vendor_lead_fee / vendor_lead_fee_status / vendor_lead_fee_terms_id / vendor_lead_fee_snapshot / vendor_lead_fee_locked_at to bookings
//        (+ archive sync) and lf_amount / lf_terms_id / lf_snapshot to leads, seeds ONE default global rule from ridego_lead_fee_builtin_defaults() when no global rule exists, sets the engine switches to their defaults only when unset,
//        and clears saved client/vendor wording that is still an older copy of the standard text → true on success, false when a table or column cannot be created (runner retries next request).
//        Postconditions: idempotent. Edge cases: re-run (tables/columns exist, seed skipped because a global rule exists); an admin-edited wording is left alone.
function ridego_migration_027_vendor_lead_fee() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;
    $ok = ridego_mkt_create_table( "{$p}ridego_lead_fee_terms", "CREATE TABLE IF NOT EXISTS {$p}ridego_lead_fee_terms (
        id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        root_id       BIGINT UNSIGNED NOT NULL DEFAULT 0,
        version       INT UNSIGNED    NOT NULL DEFAULT 1,
        supersedes_id BIGINT UNSIGNED NULL DEFAULT NULL,
        scope         VARCHAR(10)     NOT NULL DEFAULT 'global',
        vendor_id     INT UNSIGNED    NULL DEFAULT NULL,
        service_scope VARCHAR(255)    NOT NULL DEFAULT '',
        method        VARCHAR(30)     NOT NULL DEFAULT 'higher_of',
        percentage    DECIMAL(6,3)    NOT NULL DEFAULT 0.000,
        fixed_amount  DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        min_amount    DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        max_amount    DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        effective_from  DATETIME      NOT NULL,
        effective_until DATETIME      NULL DEFAULT NULL,
        status        VARCHAR(12)     NOT NULL DEFAULT 'active',
        notes         VARCHAR(255)    NOT NULL DEFAULT '',
        created_by    BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY scope_vendor (scope, vendor_id, status),
        KEY root_id (root_id)
    ) $c;" );
    $ok = ridego_mkt_create_table( "{$p}ridego_vendor_terms_acceptance", "CREATE TABLE IF NOT EXISTS {$p}ridego_vendor_terms_acceptance (
        id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        vendor_id      INT UNSIGNED    NOT NULL,
        terms_id       BIGINT UNSIGNED NOT NULL,
        terms_version  INT UNSIGNED    NOT NULL DEFAULT 1,
        root_id        BIGINT UNSIGNED NOT NULL DEFAULT 0,
        source         VARCHAR(20)     NOT NULL DEFAULT 'vendor',
        accepted_by    BIGINT UNSIGNED NOT NULL DEFAULT 0,
        accepted_at    DATETIME        NOT NULL,
        terms_snapshot TEXT            NULL,
        PRIMARY KEY (id),
        KEY vendor_terms (vendor_id, terms_id)
    ) $c;" ) && $ok;
    if ( ! $ok ) { return false; }
    $b = "{$p}ridego_bookings"; $l = "{$p}ridego_leads";
    $bcols = array( 'vendor_lead_fee' => 'DECIMAL(10,2) NOT NULL DEFAULT 0.00', 'vendor_lead_fee_status' => "VARCHAR(16) NOT NULL DEFAULT ''", 'vendor_lead_fee_terms_id' => 'BIGINT UNSIGNED NULL DEFAULT NULL',
        'vendor_lead_fee_snapshot' => 'TEXT NULL', 'vendor_lead_fee_locked_at' => 'DATETIME NULL DEFAULT NULL' );
    foreach ( $bcols as $col => $def ) { if ( ridego_add_column_if_missing( $b, $col, $def ) === false ) { return false; } }
    $lcols = array( 'lf_amount' => 'DECIMAL(10,2) NULL DEFAULT NULL', 'lf_terms_id' => 'BIGINT UNSIGNED NULL DEFAULT NULL', 'lf_snapshot' => 'TEXT NULL' );
    foreach ( $lcols as $col => $def ) { if ( ridego_add_column_if_missing( $l, $col, $def ) === false ) { return false; } }
    ridego_mkt_sync_archive_columns();
    $t = "{$p}ridego_lead_fee_terms";
    if ( ! (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE scope='global'" ) ) {
        $d = ridego_lead_fee_builtin_defaults();
        $ins = $wpdb->insert( $t, array( 'scope' => 'global', 'method' => $d['method'], 'percentage' => $d['percentage'], 'fixed_amount' => $d['fixed_amount'], 'min_amount' => $d['min_amount'], 'max_amount' => $d['max_amount'],
            'effective_from' => '2000-01-01 00:00:00', 'status' => 'active', 'notes' => 'Platform default', 'version' => 1 ) );
        if ( ! $ins ) { ridego_log( 'MIGRATION 27: could not seed default lead fee rule: ' . $wpdb->last_error ); return false; }
        $wpdb->update( $t, array( 'root_id' => (int) $wpdb->insert_id ), array( 'id' => (int) $wpdb->insert_id ) );
    }
    foreach ( array( 'lead_fee_enabled' => '1', 'lead_fee_offset_advance' => '1', 'lead_fee_cap_at_amount' => '1', 'lead_fee_require_acceptance' => '0', 'customer_advance_enabled' => '1' ) as $k => $v ) {
        if ( ridego_get_setting( $k, null ) === null || ridego_get_setting( $k, null ) === '' ) { ridego_update_setting( $k, $v ); }
    }
    $markers = array( 'token_instructions' => "is RideGo's fee for arranging", 'disclaimer_vendor' => 'keeps it as its lead fee' );
    foreach ( $markers as $key => $needle ) {
        $cur = (string) ridego_get_setting( $key, '' );
        if ( $cur !== '' && strpos( $cur, $needle ) !== false ) { ridego_update_setting( $key, '' ); }
    }
    return true;
}


// TRACE: migration runner (schema 28) → adds bookings.cancel_forfeit_to / cancel_forfeit_reason, mirrors them to the archive table, seeds the setting cancel_forfeit_default='platform' when unset → true|false. Idempotent.
//        Preconditions: bookings table exists. Postconditions: existing bookings get '' (undecided; their forfeited advance keeps the earlier treatment). Edge cases: column already present, ALTER failure (returns false so the runner retries).
function ridego_migration_028_forfeit_disposition() {
    $b = $GLOBALS['wpdb']->prefix . 'ridego_bookings';
    foreach ( array( 'cancel_forfeit_to' => "VARCHAR(10) NOT NULL DEFAULT ''", 'cancel_forfeit_reason' => "VARCHAR(255) NOT NULL DEFAULT ''" ) as $col => $def ) {
        if ( ridego_add_column_if_missing( $b, $col, $def ) === false ) { return false; }
    }
    ridego_mkt_sync_archive_columns();
    if ( ridego_get_setting( 'cancel_forfeit_default', null ) === null || ridego_get_setting( 'cancel_forfeit_default', null ) === '' ) { ridego_update_setting( 'cancel_forfeit_default', 'platform' ); }
    return true;
}


// TRACE: migration runner v29 → creates ridego_regions and ridego_tasks and adds fleet_drivers.user_id → true on success, false when any step fails
//        (the runner then halts instead of advancing the schema). Edge cases: re-run is a no-op.
function ridego_migration_029_team_access() {
    global $wpdb;
    $p = $wpdb->prefix; $cs = $wpdb->get_charset_collate();
    $ok = ridego_mkt_create_table( "{$p}ridego_regions", "CREATE TABLE IF NOT EXISTS {$p}ridego_regions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, region_type VARCHAR(20) NOT NULL DEFAULT 'custom',
        states TEXT NULL, cities TEXT NULL, status VARCHAR(10) NOT NULL DEFAULT 'active',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), UNIQUE KEY name (name)
    ) {$cs}" );
    if ( ! $ok ) { return false; }
    $ok = ridego_mkt_create_table( "{$p}ridego_tasks", "CREATE TABLE IF NOT EXISTS {$p}ridego_tasks (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, title VARCHAR(200) NOT NULL, description TEXT NULL,
        assigned_to BIGINT UNSIGNED NOT NULL DEFAULT 0, created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
        status VARCHAR(12) NOT NULL DEFAULT 'open', priority VARCHAR(10) NOT NULL DEFAULT 'normal',
        due_date DATE NULL, booking_id BIGINT UNSIGNED NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY assigned_to (assigned_to), KEY status (status)
    ) {$cs}" );
    if ( ! $ok ) { return false; }
    if ( ridego_add_column_if_missing( "{$p}ridego_fleet_drivers", 'user_id', 'BIGINT UNSIGNED NULL DEFAULT NULL' ) === false ) { return false; }
    return true;
}
