<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   REST API — Partner / BI surface (Wave 3 Task 1)
   ------------------------------------------------------------
   Read-only endpoints under the existing `ridego/v1` namespace
   (includes/api.php owns the namespace's one write route, the
   Razorpay webhook — unchanged, untouched here).

   Auth: WordPress Application Passwords (core since WP 5.6). A
   partner/integration authenticates over HTTPS Basic Auth using an
   application password issued to a real WP user from their profile
   screen; WP core's own `application_passwords` auth handler runs
   before REST dispatch and, on success, makes is_user_logged_in()
   true and get_current_user_id() resolve to that user for the rest
   of the request — exactly like a normal logged-in request, just
   authenticated per-request instead of via a cookie. No custom
   API-key table, header scheme or secret storage is introduced;
   this reuses WP's own credential store and revocation UI.

   Every route below therefore gates on:
     1. is_user_logged_in()                         (authenticated)
     2. ridego_current_user_can_ridego( $capability ) (authorized)
   via ridego_rest_permission_check(), never `__return_true` — the
   Razorpay webhook is the sole intentional exception to that rule,
   and it lives in includes/api.php, not here.

   Rate limiting: 300 requests/hour per authenticated API user,
   using the existing atomic ridego_check_rate_limit() (includes/
   security.php) — generous because this is an authenticated
   partner integration, not a public endpoint, but still bounded.

   Self-documentation: WordPress's built-in REST index at
   /wp-json/ridego/v1 already lists every route registered below
   together with its methods and `args` schema (type/required/
   description), because register_rest_route() is called with a
   full `args` array on every route here. No separate docs endpoint
   is built — GET /wp-json/ridego/v1 IS the docs endpoint.
   ============================================================ */

add_action( 'rest_api_init', function () {

    register_rest_route( 'ridego/v1', '/bookings', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_rest_list_bookings',
        'permission_callback' => ridego_rest_permission_check( 'ridego_view_all_bookings' ),
        'args'                => array(
            'status'     => array( 'type' => 'string', 'required' => false, 'description' => 'Booking status, or multiple statuses separated by | (e.g. "confirmed|completed").' ),
            'trip_type'  => array( 'type' => 'string', 'required' => false, 'description' => 'one_way|round_trip|local|airport_pickup|airport_drop|outstation' ),
            'date_from'  => array( 'type' => 'string', 'required' => false, 'description' => 'Journey date range start, Y-m-d.' ),
            'date_to'    => array( 'type' => 'string', 'required' => false, 'description' => 'Journey date range end, Y-m-d.' ),
            'city'       => array( 'type' => 'string', 'required' => false, 'description' => 'Matches pickup_city or drop_city.' ),
            'vendor_id'  => array( 'type' => 'integer', 'required' => false, 'description' => 'Filter to a single vendor.' ),
            'search'     => array( 'type' => 'string', 'required' => false, 'description' => 'Booking number, client name/phone, or pickup city.' ),
            'page'       => array( 'type' => 'integer', 'required' => false, 'default' => 1, 'minimum' => 1, 'description' => 'Page number (1-based).' ),
            'per_page'   => array( 'type' => 'integer', 'required' => false, 'default' => 25, 'minimum' => 1, 'maximum' => 100, 'description' => 'Results per page, max 100.' ),
        ),
    ) );

    register_rest_route( 'ridego/v1', '/bookings/(?P<id>\d+)', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_rest_get_booking',
        'permission_callback' => ridego_rest_permission_check( 'ridego_view_all_bookings' ),
        'args'                => array(
            'id' => array( 'type' => 'integer', 'required' => true, 'description' => 'Booking ID.' ),
        ),
    ) );

    register_rest_route( 'ridego/v1', '/vendors/(?P<id>\d+)/status', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_rest_get_vendor_status',
        // Either the admin capability OR the vendor viewing their own
        // record is allowed — checked inside the callback itself since
        // "own record" depends on the {id} in the URL, not just the cap.
        'permission_callback' => 'ridego_rest_vendor_status_permission',
        'args'                => array(
            'id' => array( 'type' => 'integer', 'required' => true, 'description' => 'Vendor ID.' ),
        ),
    ) );

    register_rest_route( 'ridego/v1', '/reports/summary', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_rest_get_report_summary',
        'permission_callback' => ridego_rest_permission_check( 'ridego_view_reports' ),
        'args'                => array(
            'from' => array( 'type' => 'string', 'required' => false, 'description' => 'Range start, Y-m-d. Defaults to the 1st of the current month.' ),
            'to'   => array( 'type' => 'string', 'required' => false, 'description' => 'Range end, Y-m-d. Defaults to today.' ),
        ),
    ) );

    register_rest_route( 'ridego/v1', '/reports/vendor-performance', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_rest_get_vendor_performance',
        'permission_callback' => ridego_rest_permission_check( 'ridego_view_reports' ),
        'args'                => array(
            'from'  => array( 'type' => 'string', 'required' => false, 'description' => 'Range start, Y-m-d. Defaults to the 1st of the current month.' ),
            'to'    => array( 'type' => 'string', 'required' => false, 'description' => 'Range end, Y-m-d. Defaults to today.' ),
            'limit' => array( 'type' => 'integer', 'required' => false, 'default' => 10, 'minimum' => 1, 'maximum' => 100, 'description' => 'Max vendors to return, ranked by performance score.' ),
        ),
    ) );

} );

/* ------------------------------------------------------------
   Auth / rate-limit plumbing
   ------------------------------------------------------------ */

/**
 * Build a permission_callback closure that requires both a logged-in
 * WP user (Application Passwords authenticate as one automatically)
 * and a specific RideGo capability, then applies the shared rate
 * limit. Returns a WP_Error (translated to the right HTTP status by
 * the REST framework) rather than a bare false, so callers get a
 * useful message instead of a generic 401.
 *
 * @param string $capability RideGo capability required, e.g. 'ridego_view_reports'.
 */
function ridego_rest_permission_check( $capability ) {
    return function ( WP_REST_Request $request ) use ( $capability ) {
        if ( ! is_user_logged_in() ) {
            return new WP_Error( 'ridego_rest_unauthorized', 'Authentication required (use a WordPress Application Password).', array( 'status' => 401 ) );
        }
        if ( ! ridego_current_user_can_ridego( $capability ) ) {
            return new WP_Error( 'ridego_rest_forbidden', 'You do not have the required RideGo capability for this endpoint.', array( 'status' => 403 ) );
        }
        $rl = ridego_rest_rate_limit();
        if ( ! $rl['allowed'] ) {
            return new WP_Error( 'ridego_rest_rate_limited', $rl['error'], array( 'status' => 429 ) );
        }
        return true;
    };
}

/**
 * Permission callback for GET /vendors/{id}/status: allowed for either
 * an admin-capable user (ridego_view_vendors) OR the vendor themself
 * (their WP user_id matches the vendor record's linked user_id).
 */
function ridego_rest_vendor_status_permission( WP_REST_Request $request ) {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'ridego_rest_unauthorized', 'Authentication required (use a WordPress Application Password).', array( 'status' => 401 ) );
    }

    $vendor_id = (int) $request['id'];
    $vendor    = ridego_get_vendor( $vendor_id );
    if ( ! $vendor ) {
        return new WP_Error( 'ridego_rest_not_found', 'Vendor not found.', array( 'status' => 404 ) );
    }

    $is_admin_view = ridego_current_user_can_ridego( 'ridego_view_vendors' );
    $is_self       = ( (int) $vendor->user_id === get_current_user_id() );

    if ( ! $is_admin_view && ! $is_self ) {
        return new WP_Error( 'ridego_rest_forbidden', 'You may only view your own vendor status.', array( 'status' => 403 ) );
    }

    $rl = ridego_rest_rate_limit();
    if ( ! $rl['allowed'] ) {
        return new WP_Error( 'ridego_rest_rate_limited', $rl['error'], array( 'status' => 429 ) );
    }
    return true;
}

/**
 * 300 requests/hour per authenticated API user. Uses the same atomic,
 * race-proof rate limiter as everything else in the plugin — see
 * includes/security.php: ridego_check_rate_limit().
 */
function ridego_rest_rate_limit() {
    $uid = get_current_user_id();
    return ridego_check_rate_limit( 'rest_api', 'user_' . $uid, 300, HOUR_IN_SECONDS );
}

/* ------------------------------------------------------------
   Callbacks
   ------------------------------------------------------------ */

function ridego_rest_list_bookings( WP_REST_Request $request ) {
    $page     = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
    $per_page = min( 100, max( 1, (int) $request->get_param( 'per_page' ) ?: 25 ) );

    $result = ridego_query_bookings( array(
        'status'     => (string) $request->get_param( 'status' ),
        'trip_type'  => (string) $request->get_param( 'trip_type' ),
        'date_from'  => (string) $request->get_param( 'date_from' ),
        'date_to'    => (string) $request->get_param( 'date_to' ),
        'city'       => (string) $request->get_param( 'city' ),
        'vendor_id'  => (int) $request->get_param( 'vendor_id' ),
        'search'     => (string) $request->get_param( 'search' ),
        'limit'      => $per_page,
        'offset'     => ( $page - 1 ) * $per_page,
    ) );

    $data = array_map( 'ridego_rest_booking_external_fields', $result['rows'] );

    $response = new WP_REST_Response( array(
        'bookings'  => $data,
        'total'     => $result['total'],
        'page'      => $page,
        'per_page'  => $per_page,
        'total_pages' => (int) ceil( $result['total'] / $per_page ),
    ), 200 );
    $response->header( 'X-WP-Total', (string) $result['total'] );
    $response->header( 'X-WP-TotalPages', (string) ceil( $result['total'] / $per_page ) );
    return $response;
}

function ridego_rest_get_booking( WP_REST_Request $request ) {
    $id = (int) $request['id'];
    $booking = ridego_get_booking( $id );
    if ( ! $booking ) {
        return new WP_Error( 'ridego_rest_not_found', 'Booking not found.', array( 'status' => 404 ) );
    }
    return new WP_REST_Response( ridego_rest_booking_external_fields( $booking ), 200 );
}

/**
 * External-safe field allowlist for a booking row. Deliberately excludes:
 *   - admin-only free-text notes / internal comments
 *   - payment_proof_filename / payment_proof_url (server-relative paths
 *     into RIDEGO_SECURE_UPLOADS — not meaningful or safe to hand to an
 *     external partner without the same auth/serving layer wp-admin uses)
 *   - ip_address, utm_source (internal analytics/fraud-signal fields)
 *   - otp_pickup (a live secret used to authorize pickup at the vehicle)
 * Everything else needed to represent a booking externally is included.
 */
function ridego_rest_booking_external_fields( $b ) {
    return array(
        'id'                => (int) $b->id,
        'booking_number'    => $b->booking_number,
        'status'            => $b->status,
        'trip_type'         => $b->trip_type,
        'client_name'       => $b->client_name,
        'client_phone'      => $b->client_phone,
        'pickup_city'       => $b->pickup_city,
        'pickup_address'    => $b->pickup_address,
        'drop_city'         => $b->drop_city,
        'drop_address'      => $b->drop_address,
        'journey_date'      => $b->journey_date,
        'journey_time'      => $b->journey_time,
        'return_date'       => $b->return_date,
        'return_time'       => $b->return_time,
        'passengers'        => (int) $b->passengers,
        'vehicle_type_id'   => (int) $b->vehicle_type_id,
        'vehicle_name'      => isset( $b->vehicle_name ) ? $b->vehicle_name : ( isset( $b->vname ) ? $b->vname : null ),
        'vendor_id'         => (int) $b->vendor_id,
        'vendor_name'       => isset( $b->vendor_name ) ? $b->vendor_name : null,
        'distance_km'       => (float) $b->distance_km,
        'total_fare'        => (float) $b->total_fare,
        'token_amount'      => isset( $b->token_amount ) ? (float) $b->token_amount : 0.00,
        'advance_paid'      => (float) $b->advance_paid,
        'balance_due'       => (float) $b->balance_due,
        'payment_method'    => $b->payment_method,
        'payment_status'    => $b->payment_status,
        'rating_by_client'  => isset( $b->rating_by_client ) ? $b->rating_by_client : null,
        'created_at'        => $b->created_at,
        'updated_at'        => $b->updated_at,
    ) + ridego_booking_money_fields( $b );
}

function ridego_rest_get_vendor_status( WP_REST_Request $request ) {
    $vendor_id = (int) $request['id'];
    $vendor = ridego_get_vendor( $vendor_id );
    if ( ! $vendor ) {
        return new WP_Error( 'ridego_rest_not_found', 'Vendor not found.', array( 'status' => 404 ) );
    }

    global $wpdb;
    $active_leads = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_leads WHERE vendor_id=%d AND status='sent'",
        $vendor_id
    ) );

    $subscription_active = ( $vendor->subscription_status === 'active'
        && ! empty( $vendor->subscription_expires )
        && strtotime( $vendor->subscription_expires ) >= time() );

    return new WP_REST_Response( array(
        'vendor_id'             => (int) $vendor->id,
        'business_name'         => $vendor->business_name,
        'status'                => $vendor->status,
        'kyc_status'            => $vendor->kyc_status,
        'wallet_balance'        => (float) $vendor->wallet_balance,
        'active_leads_count'    => $active_leads,
        'subscription_status'   => $vendor->subscription_status,
        'subscription_active'   => $subscription_active,
        'subscription_expires'  => $vendor->subscription_expires,
        'rating'                => (float) $vendor->rating,
    ), 200 );
}

function ridego_rest_get_report_summary( WP_REST_Request $request ) {
    $from = $request->get_param( 'from' ) ? sanitize_text_field( $request->get_param( 'from' ) ) : date( 'Y-m-01' );
    $to   = $request->get_param( 'to' )   ? sanitize_text_field( $request->get_param( 'to' ) )   : date( 'Y-m-d' );
    return new WP_REST_Response( ridego_get_booking_report_summary( $from, $to ), 200 );
}

function ridego_rest_get_vendor_performance( WP_REST_Request $request ) {
    $from  = $request->get_param( 'from' ) ? sanitize_text_field( $request->get_param( 'from' ) ) : date( 'Y-m-01' );
    $to    = $request->get_param( 'to' )   ? sanitize_text_field( $request->get_param( 'to' ) )   : date( 'Y-m-d' );
    $limit = min( 100, max( 1, (int) $request->get_param( 'limit' ) ?: 10 ) );

    $scores = ridego_get_vendor_performance_scores( $from, $to );
    $scores = array_slice( $scores, 0, $limit );

    $data = array_map( function ( $v ) {
        return array(
            'vendor_id'              => (int) $v->id,
            'business_name'          => $v->business_name,
            'phone'                  => $v->phone,
            'rating'                 => (float) $v->rating,
            'leads_total'            => (int) $v->leads_total,
            'completed_trips'        => (int) $v->completed_trips,
            'cancelled_trips'        => (int) $v->cancelled_trips,
            'bookings_total'         => (int) $v->bookings_total,
            'perf_score'             => (float) $v->perf_score,
            'completion_rate_pct'    => (int) $v->completion_rate_pct,
            'cancellation_rate_pct'  => (int) $v->cancellation_rate_pct,
            'breakdown'              => $v->breakdown,
        );
    }, $scores );

    return new WP_REST_Response( array( 'from' => $from, 'to' => $to, 'vendors' => array_values( $data ) ), 200 );
}
