<?php
/**
 * Vendor Lead Fee: admin configuration API, vendor commercial-terms API, calculation preview.
 * Every number comes from includes/lead-fee.php; this file only validates requests and shapes responses.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'rest_api_init', 'ridego_lead_fee_register_routes' );
// TRACE: rest_api_init → registers the admin lead-fee routes (read: settings or financial capability; write: settings capability) and the vendor commercial-terms routes → void.
function ridego_lead_fee_register_routes() {
    $admin = array(
        array( '/app/admin/lead-fee', 'GET', 'ridego_lead_fee_api_get', 'ridego_lead_fee_perm_read' ),
        array( '/app/admin/lead-fee/options', 'POST', 'ridego_lead_fee_api_options', 'ridego_lead_fee_perm_write' ),
        array( '/app/admin/lead-fee/terms', 'POST', 'ridego_lead_fee_api_terms_save', 'ridego_lead_fee_perm_write' ),
        array( '/app/admin/lead-fee/terms/(?P<id>\d+)/deactivate', 'POST', 'ridego_lead_fee_api_terms_deactivate', 'ridego_lead_fee_perm_write' ),
        array( '/app/admin/lead-fee/terms/(?P<id>\d+)/history', 'GET', 'ridego_lead_fee_api_terms_history', 'ridego_lead_fee_perm_read' ),
        array( '/app/admin/bookings/(?P<id>\d+)/forfeit', 'POST', 'ridego_lead_fee_api_forfeit', 'ridego_lead_fee_perm_write' ),
        array( '/app/admin/lead-fee/pending-forfeits', 'GET', 'ridego_lead_fee_api_pending_forfeits', 'ridego_lead_fee_perm_read' ),
        array( '/app/admin/lead-fee/preview', 'POST', 'ridego_lead_fee_api_preview', 'ridego_lead_fee_perm_read' ),
        array( '/app/admin/lead-fee/accept', 'POST', 'ridego_lead_fee_api_admin_accept', 'ridego_lead_fee_perm_write' ),
        array( '/app/admin/bookings/(?P<id>\d+)/lead-fee', 'POST', 'ridego_lead_fee_api_booking_adjust', 'ridego_lead_fee_perm_write' ),
    );
    foreach ( $admin as $r ) { register_rest_route( 'ridego/v1', $r[0], array( 'methods' => $r[1], 'callback' => $r[2], 'permission_callback' => $r[3] ) ); }
    register_rest_route( 'ridego/v1', '/app/vendor/commercial-terms', array( 'methods' => 'GET', 'callback' => 'ridego_lead_fee_api_vendor_terms', 'permission_callback' => 'ridego_mkt_vendor_permission' ) );
    register_rest_route( 'ridego/v1', '/app/vendor/commercial-terms/accept', array( 'methods' => 'POST', 'callback' => 'ridego_lead_fee_api_vendor_accept', 'permission_callback' => 'ridego_mkt_vendor_permission' ) );
}

// TRACE: any admin lead-fee GET → 401 when logged out, 403 without the settings or financial capability, else true.
function ridego_lead_fee_perm_read() {
    if ( ! is_user_logged_in() ) { return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) ); }
    if ( ! ridego_can( 'ridego_manage_settings' ) && ! ridego_can( 'ridego_view_financial' ) && ! ridego_can( 'manage_options' ) ) { return new WP_Error( 'forbidden', 'You do not have permission to view lead fee terms.', array( 'status' => 403 ) ); }
    return true;
}

// TRACE: any admin lead-fee write → 401 when logged out, 403 without the settings capability, else true.
function ridego_lead_fee_perm_write() {
    if ( ! is_user_logged_in() ) { return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) ); }
    if ( ! ridego_can( 'ridego_manage_settings' ) && ! ridego_can( 'manage_options' ) ) { return new WP_Error( 'forbidden', 'You do not have permission to change lead fee terms.', array( 'status' => 403 ) ); }
    return true;
}

// TRACE: terms row → the JSON shape used by every lead-fee screen (numbers as floats, plain-language description, current/scheduled/expired/inactive state, vendor name) → array. Pure apart from a vendor name lookup.
function ridego_lead_fee_shape_terms( $r, $latest_ids = array() ) {
    $now = current_time( 'mysql' );
    $state = $r->status !== 'active' ? 'inactive' : ( $r->effective_from > $now ? 'scheduled' : ( $r->effective_until && $r->effective_until <= $now ? 'expired' : 'current' ) );
    $vend = $r->vendor_id ? ridego_get_vendor( (int) $r->vendor_id ) : null;
    return array( 'id' => (int) $r->id, 'root_id' => (int) $r->root_id, 'version' => (int) $r->version, 'scope' => $r->scope, 'vendor_id' => $r->vendor_id ? (int) $r->vendor_id : null, 'vendor_name' => $vend ? $vend->business_name : '',
        'services' => array_values( array_filter( array_map( 'trim', explode( ',', (string) $r->service_scope ) ) ) ), 'method' => $r->method, 'method_label' => ridego_lead_fee_methods()[ $r->method ] ?? $r->method, 'percentage' => (float) $r->percentage,
        'fixed_amount' => (float) $r->fixed_amount, 'min_amount' => (float) $r->min_amount, 'max_amount' => (float) $r->max_amount, 'effective_from' => $r->effective_from, 'effective_until' => $r->effective_until, 'status' => $r->status,
        'state' => $state, 'notes' => $r->notes, 'description' => ridego_lead_fee_describe( $r ), 'is_latest' => in_array( (int) $r->id, $latest_ids, true ), 'created_at' => $r->created_at );
}

// TRACE: GET /app/admin/lead-fee → everything the configuration screen needs: switches, methods, services, every rule (latest version flagged), vendors to pick from, acceptance counts → response.
//        Edge cases: no rules (empty list; the engine falls back to the built-in default).
function ridego_lead_fee_api_get( WP_REST_Request $req ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_lead_fee_terms';
    $rows = $wpdb->get_results( "SELECT * FROM {$t} ORDER BY scope ASC, root_id ASC, version DESC LIMIT 500" );
    $latest = array(); foreach ( $rows as $r ) { if ( ! isset( $latest[ (int) $r->root_id ] ) || (int) $r->id > $latest[ (int) $r->root_id ] ) { $latest[ (int) $r->root_id ] = (int) $r->id; } }
    $ids = array_values( $latest );
    $vendors = $wpdb->get_results( "SELECT id, business_name FROM {$wpdb->prefix}ridego_vendors ORDER BY business_name LIMIT 500" );
    $acc = $wpdb->get_results( "SELECT vendor_id, COUNT(*) c, MAX(accepted_at) last FROM {$wpdb->prefix}ridego_vendor_terms_acceptance GROUP BY vendor_id", OBJECT_K );
    $vendor_rows = array();
    foreach ( (array) $vendors as $v ) {
        $st = ridego_lead_fee_vendor_acceptance_state( (int) $v->id );
        $vendor_rows[] = array( 'id' => (int) $v->id, 'name' => $v->business_name, 'accepted' => $st['accepted'], 'accepted_at' => $st['accepted_at'], 'terms_version' => $st['version'], 'terms_id' => $st['terms_id'] );
    }
    return rest_ensure_response( array( 'options' => ridego_lead_fee_options(), 'cancel_forfeit_default' => ridego_lead_fee_forfeit_default(), 'methods' => ridego_lead_fee_methods(), 'services' => ridego_lead_fee_services(),
        'rules' => array_map( function ( $r ) use ( $ids ) { return ridego_lead_fee_shape_terms( $r, $ids ); }, (array) $rows ), 'vendors' => $vendor_rows ) );
}

// TRACE: POST /app/admin/lead-fee/options {enabled, offset_advance, cap_at_amount, require_acceptance, customer_advance_enabled} → saves the engine switches (each optional; only keys sent are changed) → response(options)|400. Audit-logged.
function ridego_lead_fee_api_options( WP_REST_Request $req ) {
    $b = $req->get_json_params(); if ( ! is_array( $b ) ) { $b = array(); }
    $map = array( 'enabled' => 'lead_fee_enabled', 'offset_advance' => 'lead_fee_offset_advance', 'cap_at_amount' => 'lead_fee_cap_at_amount', 'require_acceptance' => 'lead_fee_require_acceptance', 'customer_advance_enabled' => 'customer_advance_enabled' );
    $before = ridego_lead_fee_options(); $changed = array();
    foreach ( $map as $k => $setting ) {
        if ( ! array_key_exists( $k, $b ) ) { continue; }
        ridego_update_setting( $setting, ! empty( $b[ $k ] ) ? '1' : '0' );
        $changed[ $k ] = ! empty( $b[ $k ] );
    }
    if ( isset( $b['cancel_forfeit_default'] ) ) {
        if ( ! in_array( $b['cancel_forfeit_default'], array( 'platform', 'vendor', 'admin' ), true ) ) { return new WP_REST_Response( array( 'code' => 'invalid_value', 'message' => 'Choose platform, vendor or admin decides.' ), 400 ); }
        ridego_update_setting( 'cancel_forfeit_default', $b['cancel_forfeit_default'] );
        $changed['cancel_forfeit_default'] = $b['cancel_forfeit_default'];
    }
    if ( ! $changed ) { return new WP_REST_Response( array( 'code' => 'nothing_to_save', 'message' => 'No settings were sent.' ), 400 ); }
    ridego_audit_log( 'lead_fee_options_changed', 'settings', null, wp_json_encode( $before ), wp_json_encode( $changed ) );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Saved.', 'options' => array_merge( $before, $changed ) ) );
}

// TRACE: POST /app/admin/lead-fee/terms {id?, scope, vendor_ids[]|vendor_id, services[], method, percentage, fixed_amount, min_amount, max_amount, effective_from, effective_until, status, notes} → creates a rule (one per selected vendor for vendor scope) or saves a NEW VERSION of id → response|400.
//        Edge cases: invalid values (400 with the reason), vendor scope with no vendor (400), a vendor that fails halfway (earlier ones stay saved; the message lists the failure).
function ridego_lead_fee_api_terms_save( WP_REST_Request $req ) {
    $b = $req->get_json_params(); if ( ! is_array( $b ) ) { $b = array(); }
    $actor = get_current_user_id(); $id = (int) ( $b['id'] ?? 0 );
    if ( $id ) {
        // A new version keeps the rule's scope and vendor (it is a revision of that same rule), whatever the client sent.
        global $wpdb;
        $cur = $wpdb->get_row( $wpdb->prepare( "SELECT scope, vendor_id FROM {$wpdb->prefix}ridego_lead_fee_terms WHERE id=%d", $id ) );
        if ( ! $cur ) { return new WP_REST_Response( array( 'code' => 'not_found', 'message' => 'Rule not found.' ), 404 ); }
        $b['scope'] = $cur->scope; $b['vendor_id'] = (int) $cur->vendor_id;
        $r = ridego_lead_fee_terms_save( $b, $id, $actor );
        return $r['success'] ? rest_ensure_response( $r ) : new WP_REST_Response( array( 'code' => 'invalid_terms', 'message' => $r['message'] ), 400 );
    }
    if ( ( $b['scope'] ?? 'global' ) === 'vendor' ) {
        $vids = isset( $b['vendor_ids'] ) && is_array( $b['vendor_ids'] ) ? array_map( 'intval', $b['vendor_ids'] ) : ( ! empty( $b['vendor_id'] ) ? array( (int) $b['vendor_id'] ) : array() );
        $vids = array_values( array_unique( array_filter( $vids ) ) );
        if ( ! $vids ) { return new WP_REST_Response( array( 'code' => 'invalid_terms', 'message' => 'Choose at least one vendor.' ), 400 ); }
        $made = array();
        foreach ( $vids as $vid ) {
            $r = ridego_lead_fee_terms_save( array_merge( $b, array( 'scope' => 'vendor', 'vendor_id' => $vid ) ), 0, $actor );
            if ( ! $r['success'] ) { return new WP_REST_Response( array( 'code' => 'invalid_terms', 'message' => $r['message'], 'created' => $made ), 400 ); }
            $made[] = $r['id'];
        }
        return rest_ensure_response( array( 'success' => true, 'ids' => $made, 'message' => 'Commercial terms created for ' . count( $made ) . ' vendor' . ( count( $made ) === 1 ? '' : 's' ) . '.' ) );
    }
    $r = ridego_lead_fee_terms_save( array_merge( $b, array( 'scope' => 'global' ) ), 0, $actor );
    return $r['success'] ? rest_ensure_response( $r ) : new WP_REST_Response( array( 'code' => 'invalid_terms', 'message' => $r['message'] ), 400 );
}

// TRACE: POST /app/admin/lead-fee/terms/{id}/deactivate → switches the rule off → response|400.
function ridego_lead_fee_api_terms_deactivate( WP_REST_Request $req ) {
    $r = ridego_lead_fee_terms_deactivate( (int) $req['id'], get_current_user_id() );
    return $r['success'] ? rest_ensure_response( $r ) : new WP_REST_Response( array( 'code' => 'cannot_deactivate', 'message' => $r['message'] ), 400 );
}

// TRACE: GET /app/admin/lead-fee/terms/{id}/history → every version of the rule (same root) newest first plus the vendor acceptance records for those versions → response|404.
function ridego_lead_fee_api_terms_history( WP_REST_Request $req ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_lead_fee_terms';
    $r = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", (int) $req['id'] ) );
    if ( ! $r ) { return new WP_Error( 'not_found', 'Rule not found.', array( 'status' => 404 ) ); }
    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE root_id=%d ORDER BY version DESC", (int) $r->root_id ) );
    $ids = array_map( function ( $x ) { return (int) $x->id; }, $rows );
    $acc = $ids ? $wpdb->get_results( "SELECT a.*, v.business_name FROM {$wpdb->prefix}ridego_vendor_terms_acceptance a LEFT JOIN {$wpdb->prefix}ridego_vendors v ON v.id=a.vendor_id WHERE a.terms_id IN (" . implode( ',', $ids ) . ') ORDER BY a.accepted_at DESC LIMIT 200' ) : array();
    return rest_ensure_response( array( 'versions' => array_map( function ( $x ) use ( $ids ) { return ridego_lead_fee_shape_terms( $x, array( max( $ids ) ) ); }, $rows ),
        'acceptances' => array_map( function ( $a ) { return array( 'id' => (int) $a->id, 'vendor_id' => (int) $a->vendor_id, 'vendor_name' => (string) $a->business_name, 'terms_id' => (int) $a->terms_id, 'terms_version' => (int) $a->terms_version, 'source' => $a->source, 'accepted_at' => $a->accepted_at ); }, (array) $acc ) ) );
}

// TRACE: POST /app/admin/lead-fee/preview {amount, method, percentage, fixed_amount, min_amount, max_amount} → the live preview (the SAME ridego_lead_fee_compute() the bookings use) → response(fee, pct_fee, min_fee, max_fee, capped, formula, description)|400.
//        Also {amount, vendor_id, service} with no method → which rule applies to that vendor and the resulting fee (ridego_lead_fee_for). Edge cases: amount missing/negative → 400; amount 0 → fee 0.
function ridego_lead_fee_api_preview( WP_REST_Request $req ) {
    $b = $req->get_json_params(); if ( ! is_array( $b ) ) { $b = array(); }
    if ( ! isset( $b['amount'] ) || ! is_numeric( $b['amount'] ) || (float) $b['amount'] < 0 ) { return new WP_REST_Response( array( 'code' => 'invalid_amount', 'message' => 'Enter an expected booking amount of zero or more.' ), 400 ); }
    $amount = (float) $b['amount'];
    if ( empty( $b['method'] ) ) {
        $calc = ridego_lead_fee_for( $amount, (int) ( $b['vendor_id'] ?? 0 ), sanitize_key( (string) ( $b['service'] ?? '' ) ) );
        return rest_ensure_response( $calc + array( 'description' => ridego_lead_fee_describe( $calc['params'] ) ) );
    }
    $params = array( 'method' => sanitize_key( (string) $b['method'] ), 'percentage' => $b['percentage'] ?? 0, 'fixed_amount' => $b['fixed_amount'] ?? 0, 'min_amount' => $b['min_amount'] ?? 0, 'max_amount' => $b['max_amount'] ?? 0 );
    if ( ! isset( ridego_lead_fee_methods()[ $params['method'] ] ) ) { return new WP_REST_Response( array( 'code' => 'invalid_method', 'message' => 'Unknown calculation method.' ), 400 ); }
    $c = ridego_lead_fee_compute( $amount, $params, ridego_lead_fee_options()['cap_at_amount'] );
    return rest_ensure_response( $c + array( 'amount' => ridego_lead_fee_round( $amount ), 'description' => ridego_lead_fee_describe( $params ) ) );
}

// TRACE: POST /app/admin/lead-fee/accept {vendor_id} → records that the vendor accepted the terms currently applying to them, on their behalf (source 'admin') → response|400|404. Idempotent.
function ridego_lead_fee_api_admin_accept( WP_REST_Request $req ) {
    global $wpdb;
    $b = $req->get_json_params(); $vid = (int) ( $b['vendor_id'] ?? 0 );
    if ( ! $vid || ! ridego_get_vendor( $vid ) ) { return new WP_Error( 'not_found', 'Vendor not found.', array( 'status' => 404 ) ); }
    $terms = ridego_lead_fee_resolve_terms( $vid, '' );
    if ( ! $terms ) { return new WP_REST_Response( array( 'code' => 'no_terms', 'message' => 'No commercial terms apply to this vendor.' ), 400 ); }
    $id = ridego_lead_fee_record_acceptance( $vid, $terms, 'admin', get_current_user_id() );
    if ( ! $id ) { return new WP_REST_Response( array( 'code' => 'save_failed', 'message' => 'Could not record the acceptance.' ), 400 ); }
    ridego_audit_log( 'lead_fee_terms_accepted_by_admin', 'vendor', $vid, '', 'terms ' . (int) $terms->id );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Recorded as accepted by the vendor (version ' . (int) $terms->version . ').' ) );
}

// TRACE: POST /app/admin/bookings/{id}/lead-fee {action: recalculate|waive, reason} → ridego_lead_fee_admin_adjust → response(lead_fee view)|400.
function ridego_lead_fee_api_booking_adjust( WP_REST_Request $req ) {
    $b = $req->get_json_params(); if ( ! is_array( $b ) ) { $b = array(); }
    $r = ridego_lead_fee_admin_adjust( (int) $req['id'], sanitize_key( (string) ( $b['action'] ?? '' ) ), (string) ( $b['reason'] ?? '' ), get_current_user_id() );
    if ( ! $r['success'] ) { return new WP_REST_Response( array( 'code' => 'cannot_adjust', 'message' => $r['message'] ), 400 ); }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'], 'lead_fee' => ridego_lead_fee_view( ridego_get_booking( (int) $req['id'] ) ) ) );
}

// TRACE: GET /app/vendor/commercial-terms → the signed-in vendor's applicable rule(s) in plain language, acceptance state, acceptance history, whether acceptance is required → response.
function ridego_lead_fee_api_vendor_terms( WP_REST_Request $req ) {
    global $wpdb;
    $v = ridego_get_current_vendor(); $o = ridego_lead_fee_options();
    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_lead_fee_terms WHERE status='active' AND effective_from<=%s AND (effective_until IS NULL OR effective_until>%s) AND (scope='global' OR (scope='vendor' AND vendor_id=%d)) ORDER BY scope DESC, id DESC", current_time( 'mysql' ), current_time( 'mysql' ), (int) $v->id ) );
    $hist = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_vendor_terms_acceptance WHERE vendor_id=%d ORDER BY accepted_at DESC LIMIT 50", (int) $v->id ) );
    $now_state = ridego_lead_fee_vendor_acceptance_state( (int) $v->id );
    return rest_ensure_response( array( 'enabled' => $o['enabled'], 'require_acceptance' => $o['require_acceptance'], 'offset_advance' => $o['offset_advance'], 'acceptance' => $now_state,
        'terms' => array_map( function ( $r ) { return ridego_lead_fee_shape_terms( $r, array() ); }, (array) $rows ),
        'history' => array_map( function ( $a ) { return array( 'terms_id' => (int) $a->terms_id, 'terms_version' => (int) $a->terms_version, 'source' => $a->source, 'accepted_at' => $a->accepted_at ); }, (array) $hist ) ) );
}

// TRACE: POST /app/vendor/commercial-terms/accept → the signed-in vendor accepts the terms that currently apply to them (records version, time, user) → response|400. Idempotent.
function ridego_lead_fee_api_vendor_accept( WP_REST_Request $req ) {
    $v = ridego_get_current_vendor();
    $terms = ridego_lead_fee_resolve_terms( (int) $v->id, '' );
    if ( ! $terms ) { return new WP_REST_Response( array( 'code' => 'no_terms', 'message' => 'There are no commercial terms to accept right now.' ), 400 ); }
    $id = ridego_lead_fee_record_acceptance( (int) $v->id, $terms, 'vendor', get_current_user_id() );
    if ( ! $id ) { return new WP_REST_Response( array( 'code' => 'save_failed', 'message' => 'Could not record your acceptance. Please try again.' ), 400 ); }
    ridego_audit_log( 'lead_fee_terms_accepted', 'vendor', (int) $v->id, '', 'terms ' . (int) $terms->id );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Thank you. Your acceptance of version ' . (int) $terms->version . ' has been recorded.', 'acceptance' => ridego_lead_fee_vendor_acceptance_state( (int) $v->id ) ) );
}


/* ROOT-CAUSE FIX (RideGo-Pre-Delivery-Audit.md, Revision 12, OPEN ISSUES:
   "an undecided forfeit stays undecided until an admin acts — there is
   no reminder or report of pending decisions yet"). ridego_lead_fee_
   forfeit_apply() already writes '' into cancel_forfeit_to whenever the
   cancel_forfeit_default setting is 'admin' (booking.php calling it with
   $default_to === 'admin' skips the call entirely, per line ~491), so
   every such booking sits at cancel_forfeit_to='' indefinitely — but no
   endpoint ever surfaced the list of bookings in that state. An admin
   who set the default to "admin decides" had no way to find out which
   bookings were waiting on them short of opening each cancelled booking
   individually. This is a pure read: it lists cancelled, vendor-
   arranged, forfeitable (advance_paid > 0) bookings whose disposition is
   still '' — the exact query mirrored from ridego_calc_cancel_penalty()
   and ridego_lead_fee_forfeit_apply()'s own preconditions, so a booking
   only appears here if POSTing /forfeit against it would actually
   succeed. */
// TRACE: GET /app/admin/lead-fee/pending-forfeits → cancelled, vendor-arranged bookings with a forfeited advance whose disposition an admin has not yet decided (cancel_forfeit_to='') → response(rows, count).
//        Preconditions: none → Postconditions: pure read, newest-cancelled first, capped at 200 → Edge cases: no vendor arranged (excluded, nothing was forfeited), advance_paid=0 (excluded, nothing to decide), already decided (excluded).
function ridego_lead_fee_api_pending_forfeits( WP_REST_Request $req ) {
    global $wpdb;
    $b = $wpdb->prefix . 'ridego_bookings';
    $rows = $wpdb->get_results(
        "SELECT id, client_name, client_phone, vendor_id, pickup_city, drop_city, advance_paid, status, created_at, cancel_forfeit_reason
         FROM {$b}
         WHERE status='cancelled' AND vendor_id IS NOT NULL AND advance_paid > 0 AND cancel_forfeit_to=''
         ORDER BY created_at DESC LIMIT 200"
    );
    $out = array();
    foreach ( (array) $rows as $r ) {
        $vend = ridego_get_vendor( (int) $r->vendor_id );
        $out[] = array(
            'booking_id'   => (int) $r->id,
            'client_name'  => $r->client_name,
            'client_phone' => $r->client_phone,
            'vendor_id'    => (int) $r->vendor_id,
            'vendor_name'  => $vend ? $vend->business_name : '',
            'pickup_city'  => $r->pickup_city,
            'drop_city'    => $r->drop_city,
            'amount'       => ridego_lead_fee_round( (float) $r->advance_paid ),
            // NOTE: bookings has no separate "cancelled_at" column, so created_at
            // (the only timestamp on the row) is what days_waiting is measured
            // from — an undercount for a booking cancelled well after creation,
            // never an overcount, so it never hides an older pending decision.
            'created_at'   => $r->created_at,
            'days_waiting' => max( 0, (int) floor( ( current_time( 'timestamp' ) - strtotime( $r->created_at ) ) / DAY_IN_SECONDS ) ),
        );
    }
    return rest_ensure_response( array( 'rows' => $out, 'count' => count( $out ) ) );
}

// TRACE: POST /app/admin/bookings/{id}/forfeit {to: platform|vendor, reason} → decides (or changes the decision) what happens to the advance the client forfeited by cancelling after a vendor was arranged → response(lead_fee view)|400.
//        Reason is required. Refused once the compensation has been paid to the vendor. Audit-logged. Edge cases: unknown booking (404), not cancelled / no vendor / nothing forfeited (400 with the reason), same decision (no change).
function ridego_lead_fee_api_forfeit( WP_REST_Request $req ) {
    $b = ridego_get_booking( (int) $req['id'] );
    if ( ! $b ) { return new WP_REST_Response( array( 'code' => 'not_found', 'message' => 'Booking not found.' ), 404 ); }
    $p = $req->get_json_params(); if ( ! is_array( $p ) ) { $p = array(); }
    $r = ridego_lead_fee_forfeit_apply( (int) $req['id'], sanitize_key( (string) ( $p['to'] ?? '' ) ), (string) ( $p['reason'] ?? '' ), get_current_user_id(), false );
    if ( empty( $r['success'] ) ) { return new WP_REST_Response( array( 'code' => 'forfeit_failed', 'message' => $r['message'] ), 400 ); }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'], 'lead_fee' => ridego_lead_fee_view( ridego_get_booking( (int) $req['id'] ) ) ) );
}
