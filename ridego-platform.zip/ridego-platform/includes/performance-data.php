<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   RATINGS, SERVICE EVENTS AND PERFORMANCE SNAPSHOTS
   (Marketplace Plan — sections F, P, incentives note)
   ------------------------------------------------------------
   ridego_service_events is the individual-occurrence layer;
   ridego_performance_snapshots is aggregated FROM it nightly.
   ridego_ratings carries category-scored, multi-directional
   ratings (client->vendor, client->driver/vehicle,
   vendor->client) through one table.
   Nothing here decides anything — incentives / preferred vendor
   are explicitly out of scope; this is data collection.
   ============================================================ */

// TRACE: any scorer/recorder → returns the fixed list of event types. Edge: none.
function ridego_service_event_types() {
    return array( 'no_show', 'late_arrival', 'driver_replaced', 'vehicle_replaced', 'complaint_filed', 'cancellation', 'on_time_completion', 'response_recorded' );
}

// TRACE: ratings code → returns the allowed category keys for one direction:
//        'vendor' (client->vendor), 'driver' (client->driver), 'client' (vendor->client),
//        'vehicle' (client->vehicle, derived). Postconditions: array of strings. Edge:
//        unknown direction → empty array.
function ridego_rating_categories( $group ) {
    $map = array(
        'vendor'  => array( 'service_quality', 'communication', 'reliability', 'vehicle_quality' ),
        'driver'  => array( 'behaviour', 'punctuality', 'driving', 'cleanliness' ),
        'client'  => array( 'communication', 'reliability', 'payment_behaviour' ),
        'vehicle' => array( 'vehicle_quality', 'cleanliness' ),
    );
    return isset( $map[ $group ] ) ? $map[ $group ] : array();
}

/* ------------------------------------------------------------
   SERVICE EVENTS
   ------------------------------------------------------------ */

// TRACE: every place that records something noteworthy → validates entity/event, INSERTs one
//        row into ridego_service_events → returns the new row id, or false when invalid or the
//        insert failed (logged). Preconditions: none. Postconditions: at most one row. Best
//        effort by design: callers are business flows (assign, complete, respond) that must not
//        fail because telemetry failed, so failure is logged via ridego_log() and returned, and
//        callers deliberately do not abort on false. Edge cases: unknown entity_type/event_type
//        (false); entity_id <= 0 (false, e.g. a booking without a driver); event_value null
//        stored as NULL.
function ridego_record_service_event( $booking_id, $entity_type, $entity_id, $event_type, $value = null, $notes = '', $recorded_by = null ) {
    global $wpdb;
    if ( ! in_array( $entity_type, array( 'vendor', 'driver', 'vehicle' ), true ) ) { return false; }
    if ( ! in_array( $event_type, ridego_service_event_types(), true ) ) { return false; }
    if ( (int) $entity_id <= 0 ) { return false; }
    $ok = $wpdb->insert( "{$wpdb->prefix}ridego_service_events", array(
        'booking_id'  => (int) $booking_id,
        'entity_type' => $entity_type,
        'entity_id'   => (int) $entity_id,
        'event_type'  => $event_type,
        'event_value' => $value === null ? null : (float) $value,
        'recorded_at' => current_time( 'mysql' ),
        'recorded_by' => $recorded_by === null ? get_current_user_id() : (int) $recorded_by,
        'notes'       => substr( sanitize_text_field( (string) $notes ), 0, 255 ),
    ) );
    if ( ! $ok ) {
        ridego_log( 'service event insert failed: ' . $wpdb->last_error );
        return false;
    }
    return (int) $wpdb->insert_id;
}

// TRACE: booking-level events (completion, lateness, complaint, cancellation, no-show) → looks
//        up the booking's vendor and current driver/vehicle and records the same event for each
//        that exists → returns the number of rows written. Preconditions: booking exists.
//        Postconditions: up to 3 rows (vendor, driver, vehicle). Edge cases: no vendor (0
//        rows); assignment with free-text driver (no driver_id → driver row skipped); booking
//        missing (0).
function ridego_record_booking_service_event( $booking_id, $event_type, $value = null, $notes = '' ) {
    $b = ridego_get_booking( (int) $booking_id );
    if ( ! $b || empty( $b->vendor_id ) ) { return 0; }
    $n = 0;
    if ( ridego_record_service_event( $booking_id, 'vendor', $b->vendor_id, $event_type, $value, $notes ) ) { $n++; }
    $a = function_exists( 'ridego_get_current_assignment' ) ? ridego_get_current_assignment( $booking_id ) : null;
    if ( $a ) {
        if ( ! empty( $a->driver_id ) && ridego_record_service_event( $booking_id, 'driver', $a->driver_id, $event_type, $value, $notes ) ) { $n++; }
        if ( ! empty( $a->vehicle_id ) && ridego_record_service_event( $booking_id, 'vehicle', $a->vehicle_id, $event_type, $value, $notes ) ) { $n++; }
    }
    return $n;
}

// TRACE: hook ridego_booking_status_changed($booking_id,$status) → on 'trip_started' compares
//        the actual pickup time with the scheduled start; more than late_grace_minutes (default
//        15) late records 'late_arrival' with event_value = minutes late (once per booking); on
//        'completed' records 'on_time_completion' when no late_arrival exists for the booking.
//        Postconditions: at most one late_arrival and one on_time_completion per booking per
//        entity (existence-checked before inserting). Edge cases: booking without a vendor
//        (nothing); trip_started_at missing (uses now); status changes that do not matter
//        (ignored); the hook firing twice (idempotent).
function ridego_service_events_on_status_change( $booking_id, $status ) {
    global $wpdb;
    if ( $status !== 'trip_started' && $status !== 'completed' ) { return; }
    $b = ridego_get_booking( (int) $booking_id );
    if ( ! $b || empty( $b->vendor_id ) ) { return; }
    $tbl = "{$wpdb->prefix}ridego_service_events";
    $has = function ( $type ) use ( $wpdb, $tbl, $booking_id ) {
        return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$tbl} WHERE booking_id=%d AND event_type=%s LIMIT 1", (int) $booking_id, $type ) );
    };
    if ( $status === 'trip_started' ) {
        if ( $has( 'late_arrival' ) ) { return; }
        list( $sched, ) = ridego_booking_window( $b );
        $actual = ! empty( $b->trip_started_at ) ? strtotime( $b->trip_started_at ) : time();
        $late_min = (int) floor( ( $actual - $sched ) / 60 );
        $grace = max( 0, (int) ridego_get_setting( 'late_grace_minutes', 15 ) );
        if ( $late_min > $grace ) {
            ridego_record_booking_service_event( $booking_id, 'late_arrival', $late_min, 'Pickup ' . $late_min . ' min after scheduled time' );
        }
        return;
    }
    if ( $has( 'on_time_completion' ) || $has( 'late_arrival' ) ) { return; }
    ridego_record_booking_service_event( $booking_id, 'on_time_completion', null, '' );
}
add_action( 'ridego_booking_status_changed', 'ridego_service_events_on_status_change', 20, 2 );

// TRACE: hook ridego_booking_cancelled($booking_id,$cancelled_by,$refund) → when the booking had a
//        vendor, records 'cancellation' for vendor/driver/vehicle with event_value 1 if the vendor
//        cancelled (their fault) else 0 (client/admin/system) → returns void. Postconditions: 0-3
//        rows. Edge cases: never-assigned booking (nothing, there is no vendor to attribute to).
function ridego_service_events_on_cancel( $booking_id, $cancelled_by = '', $refund = 0 ) {
    ridego_record_booking_service_event( $booking_id, 'cancellation', $cancelled_by === 'vendor' ? 1 : 0, 'cancelled_by=' . sanitize_key( (string) $cancelled_by ) );
}
add_action( 'ridego_booking_cancelled', 'ridego_service_events_on_cancel', 20, 3 );

// TRACE: hook ridego_complaint_filed($complaint_row_id,$data) → a complaint raised by anyone but the
//        vendor about a booking with an assigned vendor records 'complaint_filed' for vendor/driver/
//        vehicle → returns void. Edge cases: vendor-raised complaint (ignored, not against them);
//        missing booking_id (ignored).
function ridego_service_events_on_complaint( $complaint_row_id, $data ) {
    if ( ( $data['raised_by_type'] ?? 'client' ) === 'vendor' ) { return; }
    $bid = absint( $data['booking_id'] ?? 0 );
    if ( ! $bid ) { return; }
    ridego_record_booking_service_event( $bid, 'complaint_filed', null, 'complaint #' . (int) $complaint_row_id );
}
add_action( 'ridego_complaint_filed', 'ridego_service_events_on_complaint', 10, 2 );

// TRACE: admin "Report Issue → no-show" → records 'no_show' for vendor/driver/vehicle of an
//        assigned booking, audits it, and (only if the automatic_reassignment flag is ON) asks the
//        assignment system to reopen the booking → returns array(success,message,reopened bool).
//        Preconditions: caller authorised. Postconditions: 0-3 event rows; flag OFF means the booking
//        is left exactly as it was. Edge cases: unknown/unassigned booking (failure); reopen failure
//        surfaces in message but the event stays recorded.
function ridego_report_no_show( $booking_id, $notes = '' ) {
    $b = ridego_get_booking( (int) $booking_id );
    if ( ! $b ) { return array( 'success' => false, 'message' => 'Booking not found.', 'reopened' => false ); }
    if ( empty( $b->vendor_id ) ) { return array( 'success' => false, 'message' => 'No vendor is assigned to this booking.', 'reopened' => false ); }
    $n = ridego_record_booking_service_event( $booking_id, 'no_show', null, $notes );
    if ( $n < 1 ) { return array( 'success' => false, 'message' => 'Could not record the issue.', 'reopened' => false ); }
    ridego_audit_log( 'no_show_reported', 'booking', $booking_id, '', $notes, 'warning' );
    $reopened = false;
    if ( function_exists( 'ridego_matching_flag' ) && ridego_matching_flag( 'automatic_reassignment' ) && function_exists( 'ridego_reopen_booking_for_reassignment' ) ) {
        $r = ridego_reopen_booking_for_reassignment( $booking_id, 'No-show reported' );
        $reopened = ! empty( $r['success'] );
    }
    return array( 'success' => true, 'message' => $reopened ? 'No-show recorded and the booking was reopened for reassignment.' : 'No-show recorded.', 'reopened' => $reopened );
}

/* ------------------------------------------------------------
   RATINGS
   ------------------------------------------------------------ */

// TRACE: vendor rating aggregate → recomputes ridego_vendors.rating/total_ratings from the
//        bookings.rating_by_client column (the same source ridego_rate_booking() uses) → returns
//        void. Edge cases: vendor with no ratings (0.00 / 0).
function ridego_recompute_vendor_rating( $vendor_id ) {
    global $wpdb;
    $avg = $wpdb->get_var( $wpdb->prepare( "SELECT AVG(rating_by_client) FROM {$wpdb->prefix}ridego_bookings WHERE vendor_id=%d AND rating_by_client IS NOT NULL", (int) $vendor_id ) );
    $cnt = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_bookings WHERE vendor_id=%d AND rating_by_client IS NOT NULL", (int) $vendor_id ) );
    $wpdb->update( "{$wpdb->prefix}ridego_vendors", array( 'rating' => round( (float) $avg, 2 ), 'total_ratings' => (int) $cnt ), array( 'id' => (int) $vendor_id ) );
}

// TRACE: after a driver receives an 'overall' rating → recomputes fleet_drivers.rating/total_ratings
//        from ridego_ratings (rated_type='driver', category 'overall') → returns void. Edge: no rows
//        → 0.00 / 0.
function ridego_recompute_driver_rating( $driver_id ) {
    global $wpdb;
    if ( (int) $driver_id <= 0 ) { return; }
    $row = $wpdb->get_row( $wpdb->prepare(
        "SELECT AVG(score) AS a, COUNT(*) AS c FROM {$wpdb->prefix}ridego_ratings WHERE rated_type='driver' AND rated_id=%d AND rating_category='overall'", (int) $driver_id
    ) );
    $wpdb->update( "{$wpdb->prefix}ridego_fleet_drivers", array( 'rating' => round( (float) ( $row ? $row->a : 0 ), 2 ), 'total_ratings' => (int) ( $row ? $row->c : 0 ) ), array( 'id' => (int) $driver_id ) );
}

// TRACE: a rater submitting category taps for a COMPLETED booking → validates direction/ownership/
//        scores, writes one row per category into ridego_ratings inside a transaction (booking row
//        locked first so a double submit cannot double-write), maintains the legacy
//        bookings.rating_by_client/rating_by_vendor columns and the vendor/driver aggregates →
//        returns array(success,message). $direction is 'client' (client rates vendor, driver and
//        vehicle) or 'vendor' (vendor rates the client). $scores is map category=>1..5, may include
//        'overall'. Preconditions: booking status 'completed'; rater owns the booking side.
//        Postconditions: rows written once per (booking, rater, direction); each direction's
//        'overall' is the supplied value or the rounded mean of the categories given; a row is
//        written only when the score is 1..5. Edge cases: not completed (refused); wrong rater
//        (refused); already rated in this direction (refused); no valid score at all (refused);
//        unknown category keys ignored; assignment without driver_id/vehicle_id (those rows
//        skipped); any DB write failure rolls the whole submission back and reports failure.
function ridego_submit_trip_ratings( $booking_id, $rater_user_id, $direction, $scores, $review = '' ) {
    global $wpdb;
    $booking_id = (int) $booking_id;
    $direction  = $direction === 'vendor' ? 'vendor' : 'client';
    $rt = "{$wpdb->prefix}ridego_ratings";
    $bt = "{$wpdb->prefix}ridego_bookings";
    $scores = is_array( $scores ) ? $scores : array();

    $b = ridego_get_booking( $booking_id );
    if ( ! $b || $b->status !== 'completed' ) { return array( 'success' => false, 'message' => 'You can rate a trip once it is completed.' ); }

    $vendor = null;
    if ( $direction === 'client' ) {
        if ( (int) $b->client_id <= 0 || (int) $b->client_id !== (int) $rater_user_id ) {
            return array( 'success' => false, 'message' => 'You can only rate your own trips.' );
        }
        if ( empty( $b->vendor_id ) ) { return array( 'success' => false, 'message' => 'This trip had no driver-partner to rate.' ); }
    } else {
        $vendor = ridego_get_vendor_by_user( (int) $rater_user_id );
        if ( ! $vendor || (int) $vendor->id !== (int) $b->vendor_id ) {
            return array( 'success' => false, 'message' => 'You can only rate clients of your own trips.' );
        }
    }

    $clean = function ( $group ) use ( $scores ) {
        $out = array();
        foreach ( ridego_rating_categories( $group ) as $cat ) {
            if ( isset( $scores[ $cat ] ) ) {
                $s = (int) $scores[ $cat ];
                if ( $s >= 1 && $s <= 5 ) { $out[ $cat ] = $s; }
            }
        }
        return $out;
    };
    $overall_in = ( isset( $scores['overall'] ) && (int) $scores['overall'] >= 1 && (int) $scores['overall'] <= 5 ) ? (int) $scores['overall'] : 0;
    $review = substr( sanitize_textarea_field( (string) $review ), 0, 1000 );
    $now = current_time( 'mysql' );
    $asg = function_exists( 'ridego_get_current_assignment' ) ? ridego_get_current_assignment( $booking_id ) : null;
    $drv_name = $asg ? (string) $asg->driver_name_snapshot : '';
    $veh_reg  = $asg ? (string) $asg->vehicle_registration_snapshot : '';

    $rows = array();
    $mean = function ( $arr ) { return $arr ? (int) round( array_sum( $arr ) / count( $arr ) ) : 0; };
    if ( $direction === 'client' ) {
        $v = $clean( 'vendor' ); $d = $clean( 'driver' ); $h = $clean( 'vehicle' );
        // vehicle rows come from the vehicle_quality tap given in the vendor group and cleanliness from the driver group
        if ( isset( $v['vehicle_quality'] ) ) { $h['vehicle_quality'] = $v['vehicle_quality']; }
        if ( isset( $d['cleanliness'] ) ) { $h['cleanliness'] = $d['cleanliness']; }
        $vendor_overall = $overall_in ?: $mean( $v );
        if ( ! $vendor_overall ) { return array( 'success' => false, 'message' => 'Please tap at least one rating.' ); }
        foreach ( $v as $cat => $s ) { $rows[] = array( 'vendor', (int) $b->vendor_id, $cat, $s, '' ); }
        $rows[] = array( 'vendor', (int) $b->vendor_id, 'overall', $vendor_overall, $review );
        if ( $asg && ( ! empty( $asg->driver_id ) || $drv_name !== '' ) ) {
            foreach ( $d as $cat => $s ) { $rows[] = array( 'driver', (int) $asg->driver_id, $cat, $s, '' ); }
            $driver_overall = $mean( $d );
            if ( $driver_overall ) { $rows[] = array( 'driver', (int) $asg->driver_id, 'overall', $driver_overall, '' ); }
        }
        if ( $asg && ! empty( $asg->vehicle_id ) ) {
            foreach ( $h as $cat => $s ) { $rows[] = array( 'vehicle', (int) $asg->vehicle_id, $cat, $s, '' ); }
        }
        $rated_types = array( 'vendor', 'driver', 'vehicle' );
    } else {
        $c = $clean( 'client' );
        $client_overall = $overall_in ?: $mean( $c );
        if ( ! $client_overall ) { return array( 'success' => false, 'message' => 'Please tap at least one rating.' ); }
        foreach ( $c as $cat => $s ) { $rows[] = array( 'client', (int) $b->client_id, $cat, $s, '' ); }
        $rows[] = array( 'client', (int) $b->client_id, 'overall', $client_overall, $review );
        $rated_types = array( 'client' );
    }

    $wpdb->query( 'START TRANSACTION' );
    $locked = $wpdb->get_row( $wpdb->prepare( "SELECT id, rating_by_client, rating_by_vendor FROM {$bt} WHERE id=%d FOR UPDATE", $booking_id ) );
    if ( ! $locked ) { $wpdb->query( 'ROLLBACK' ); return array( 'success' => false, 'message' => 'Booking not found.' ); }
    $ph = implode( ',', array_fill( 0, count( $rated_types ), '%s' ) );
    $exists = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$rt} WHERE booking_id=%d AND rater_id=%d AND rated_type IN ({$ph})",
        array_merge( array( $booking_id, (int) $rater_user_id ), $rated_types )
    ) );
    if ( $exists > 0 ) { $wpdb->query( 'ROLLBACK' ); return array( 'success' => false, 'message' => 'You have already rated this trip.' ); }

    foreach ( $rows as $r ) {
        $ok = $wpdb->insert( $rt, array(
            'booking_id' => $booking_id, 'rater_id' => (int) $rater_user_id, 'rated_id' => $r[1], 'rated_type' => $r[0],
            'score' => $r[3], 'review' => $r[4], 'rating_category' => $r[2], 'driver_name' => $drv_name,
            'vehicle_registration' => $veh_reg, 'created_at' => $now,
        ) );
        if ( ! $ok ) {
            $wpdb->query( 'ROLLBACK' );
            ridego_log( 'rating insert failed: ' . $wpdb->last_error );
            return array( 'success' => false, 'message' => 'Could not save your rating. Please try again.' );
        }
    }

    $first_vendor_rating = false;
    if ( $direction === 'client' ) {
        if ( $locked->rating_by_client === null || (int) $locked->rating_by_client === 0 ) {
            $ok = $wpdb->update( $bt, array( 'rating_by_client' => $vendor_overall, 'review_by_client' => $review ), array( 'id' => $booking_id ) );
            if ( $ok === false ) { $wpdb->query( 'ROLLBACK' ); return array( 'success' => false, 'message' => 'Could not save your rating. Please try again.' ); }
            $first_vendor_rating = true;
        }
    } else {
        $ok = $wpdb->update( $bt, array( 'rating_by_vendor' => $client_overall ), array( 'id' => $booking_id ) );
        if ( $ok === false ) { $wpdb->query( 'ROLLBACK' ); return array( 'success' => false, 'message' => 'Could not save your rating. Please try again.' ); }
    }
    $wpdb->query( 'COMMIT' );

    if ( $direction === 'client' ) {
        ridego_recompute_vendor_rating( (int) $b->vendor_id );
        if ( $asg && ! empty( $asg->driver_id ) ) { ridego_recompute_driver_rating( (int) $asg->driver_id ); }
        if ( $first_vendor_rating ) { do_action( 'ridego_booking_rated', $booking_id, $vendor_overall, $b->vendor_id ); }
    }
    if ( function_exists( 'ridego_maybe_close_booking' ) ) { ridego_maybe_close_booking( $booking_id ); }
    return array( 'success' => true, 'message' => 'Thank you for your feedback!' );
}

// TRACE: booking detail screens → returns whether each direction has been rated for a booking →
//        array('client_rated'=>bool,'vendor_rated'=>bool). Edge: no rows → both false.
function ridego_get_booking_rating_state( $booking_id, $client_user_id = 0, $vendor_user_id = 0 ) {
    global $wpdb;
    $rt = "{$wpdb->prefix}ridego_ratings";
    $c = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$rt} WHERE booking_id=%d AND rated_type='vendor'", (int) $booking_id ) );
    $v = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$rt} WHERE booking_id=%d AND rated_type='client'", (int) $booking_id ) );
    $b = ridego_get_booking( $booking_id );
    if ( $b && ! $c && ! empty( $b->rating_by_client ) ) { $c = 1; }
    if ( $b && ! $v && ! empty( $b->rating_by_vendor ) ) { $v = 1; }
    return array( 'client_rated' => $c > 0, 'vendor_rated' => $v > 0 );
}

/* ------------------------------------------------------------
   PERFORMANCE SNAPSHOTS
   ------------------------------------------------------------ */

// TRACE: snapshot code → validates a 'YYYY-MM' period → returns array(start,end) datetime strings
//        (end exclusive) or false. Edge: malformed → false.
function ridego_period_bounds( $period ) {
    if ( ! preg_match( '/^(\d{4})-(\d{2})$/', (string) $period, $m ) || (int) $m[2] < 1 || (int) $m[2] > 12 ) { return false; }
    $start = sprintf( '%04d-%02d-01 00:00:00', $m[1], $m[2] );
    return array( $start, date( 'Y-m-01 00:00:00', strtotime( $start . ' +1 month' ) ) );
}

// TRACE: nightly job / on-demand refresh → aggregates ridego_service_events (+ overall ratings) for ONE
//        entity in ONE month and UPSERTs the ridego_performance_snapshots row → returns the row as an
//        array or false when the period/entity is invalid or the write failed. Formulas:
//        completed = distinct completed bookings with on_time_completion or late_arrival events;
//        failed = cancellations (vendor-fault, event_value=1) + no_shows;
//        completion_rate = completed / (completed + failed); cancellation_rate = cancelled /
//        (completed + failed); on_time_pct = on_time / (on_time + late); response avg from
//        response_recorded values; complaints counted; avg_rating from 'overall' ratings created in
//        the month. Rates are NULL when the denominator is 0 (never a fabricated 0/100). Edge cases:
//        entity with no events (row with zeros/NULLs); invalid entity_type/period (false).
function ridego_compute_performance_snapshot( $entity_type, $entity_id, $period ) {
    global $wpdb;
    if ( ! in_array( $entity_type, array( 'vendor', 'driver', 'vehicle' ), true ) || (int) $entity_id <= 0 ) { return false; }
    $bounds = ridego_period_bounds( $period );
    if ( ! $bounds ) { return false; }
    list( $from, $to ) = $bounds;
    $ev = "{$wpdb->prefix}ridego_service_events";
    $bk = "{$wpdb->prefix}ridego_bookings";
    $base = array( $entity_type, (int) $entity_id, $from, $to );

    $count = function ( $type, $extra = '' ) use ( $wpdb, $ev, $base ) {
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(DISTINCT booking_id) FROM {$ev} WHERE entity_type=%s AND entity_id=%d AND recorded_at>=%s AND recorded_at<%s AND event_type=%s {$extra}",
            array_merge( $base, array( $type ) )
        ) );
    };
    $completed = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(DISTINCT e.booking_id) FROM {$ev} e JOIN {$bk} b ON b.id=e.booking_id AND b.status='completed'
         WHERE e.entity_type=%s AND e.entity_id=%d AND e.recorded_at>=%s AND e.recorded_at<%s AND e.event_type IN ('on_time_completion','late_arrival')", $base
    ) );
    $cancelled = $count( 'cancellation', 'AND event_value=1' );
    $no_show   = $count( 'no_show' );
    $on_time   = $count( 'on_time_completion' );
    $late      = $count( 'late_arrival' );
    $complaints = $count( 'complaint_filed' );
    $resp = $wpdb->get_var( $wpdb->prepare(
        "SELECT AVG(event_value) FROM {$ev} WHERE entity_type=%s AND entity_id=%d AND recorded_at>=%s AND recorded_at<%s AND event_type='response_recorded' AND event_value IS NOT NULL", $base
    ) );
    $rating = $wpdb->get_var( $wpdb->prepare(
        "SELECT AVG(score) FROM {$wpdb->prefix}ridego_ratings WHERE rated_type=%s AND rated_id=%d AND created_at>=%s AND created_at<%s AND rating_category='overall'", $base
    ) );

    $failed = $cancelled + $no_show;
    $den    = $completed + $failed;
    $ot_den = $on_time + $late;
    $row = array(
        'entity_type' => $entity_type, 'entity_id' => (int) $entity_id, 'period' => $period,
        'bookings_completed' => $completed, 'bookings_cancelled' => $cancelled,
        'response_time_avg_secs' => $resp === null ? null : (int) round( (float) $resp ),
        'completion_rate'   => $den > 0 ? round( $completed * 100 / $den, 2 ) : null,
        'cancellation_rate' => $den > 0 ? round( $cancelled * 100 / $den, 2 ) : null,
        'avg_rating'  => $rating === null ? null : round( (float) $rating, 2 ),
        'on_time_pct' => $ot_den > 0 ? round( $on_time * 100 / $ot_den, 2 ) : null,
        'complaint_count' => $complaints,
        'computed_at' => current_time( 'mysql' ),
    );
    $tbl = "{$wpdb->prefix}ridego_performance_snapshots";
    $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$tbl} WHERE entity_type=%s AND entity_id=%d AND period=%s", $entity_type, (int) $entity_id, $period ) );
    $ok = false;
    if ( $existing ) {
        $ok = ( $wpdb->update( $tbl, $row, array( 'id' => (int) $existing ) ) !== false );
    } else {
        $ok = (bool) $wpdb->insert( $tbl, $row );
        if ( ! $ok ) {
            // A concurrent run inserted the same (entity, period) first: the UNIQUE key rejected ours, so update theirs.
            $ok = ( $wpdb->update( $tbl, $row, array( 'entity_type' => $entity_type, 'entity_id' => (int) $entity_id, 'period' => $period ) ) !== false );
        }
    }
    if ( ! $ok ) {
        ridego_log( 'snapshot write failed: ' . $wpdb->last_error );
        return false;
    }
    return $row;
}

// TRACE: nightly cron / admin "recompute" → for every (entity_type, entity_id) that has service events
//        in the period, computes and stores its snapshot → returns the number of snapshots written.
//        Postconditions: one row per active entity for that period. Edge cases: invalid period (0);
//        no events (0); an entity whose write fails is skipped and logged, others continue.
function ridego_recompute_snapshots_for_period( $period ) {
    global $wpdb;
    $bounds = ridego_period_bounds( $period );
    if ( ! $bounds ) { return 0; }
    $pairs = $wpdb->get_results( $wpdb->prepare(
        "SELECT DISTINCT entity_type, entity_id FROM {$wpdb->prefix}ridego_service_events WHERE recorded_at>=%s AND recorded_at<%s", $bounds[0], $bounds[1]
    ) );
    $n = 0;
    foreach ( (array) $pairs as $p ) {
        if ( ridego_compute_performance_snapshot( $p->entity_type, (int) $p->entity_id, $period ) ) { $n++; }
    }
    return $n;
}

// TRACE: daily WP-Cron event ridego_performance_nightly → recomputes the current and the previous month
//        (the previous month keeps late-arriving events correct) → returns void. Edge: none.
function ridego_run_performance_nightly() {
    ridego_recompute_snapshots_for_period( date( 'Y-m' ) );
    ridego_recompute_snapshots_for_period( date( 'Y-m', strtotime( 'first day of last month' ) ) );
}
add_action( 'ridego_performance_nightly', 'ridego_run_performance_nightly' );

// TRACE: performance screens → returns the last $n monthly snapshots (oldest first) for one entity →
//        array of row objects. Edge: none → empty array.
function ridego_get_performance_trend( $entity_type, $entity_id, $n = 6 ) {
    global $wpdb;
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_performance_snapshots WHERE entity_type=%s AND entity_id=%d ORDER BY period DESC LIMIT %d",
        $entity_type, (int) $entity_id, max( 1, (int) $n )
    ) );
    return array_reverse( (array) $rows );
}

// TRACE: performance screens → mean score per rating_category for one rated entity (last 12 months) →
//        returns array(category => array('avg'=>float,'count'=>int)). Edge: no ratings → empty array.
function ridego_get_category_breakdown( $rated_type, $rated_id ) {
    global $wpdb;
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT rating_category, AVG(score) AS a, COUNT(*) AS c FROM {$wpdb->prefix}ridego_ratings
         WHERE rated_type=%s AND rated_id=%d AND created_at >= %s GROUP BY rating_category",
        $rated_type, (int) $rated_id, date( 'Y-m-d H:i:s', strtotime( '-12 months' ) )
    ) );
    $out = array();
    foreach ( (array) $rows as $r ) { $out[ $r->rating_category ] = array( 'avg' => round( (float) $r->a, 2 ), 'count' => (int) $r->c ); }
    return $out;
}

// TRACE: vendor/admin Performance screen → assembles one vendor's performance payload: vendor-level
//        trend + category breakdown, and (fleet vendors only) the same per driver and per vehicle so
//        a fleet vendor can see which driver is dragging the aggregate down → returns an array.
//        Preconditions: vendor exists. Postconditions: read-only. Edge cases: individual vendor
//        (drivers/vehicles arrays present but with their single row); entity with no data (empty
//        trend/breakdown, never invented numbers).
function ridego_get_vendor_performance_detail( $vendor_id ) {
    $vendor = ridego_get_vendor( (int) $vendor_id );
    if ( ! $vendor ) { return array(); }
    $shape = function ( $type, $id ) {
        return array(
            'trend'      => array_map( function ( $r ) { return ridego_snapshot_to_array( $r ); }, ridego_get_performance_trend( $type, $id, 6 ) ),
            'categories' => (object) ridego_get_category_breakdown( $type, $id ),
        );
    };
    $out = array(
        'vendor_type' => ridego_get_vendor_type( $vendor ),
        'vendor'      => $shape( 'vendor', (int) $vendor->id ),
        'drivers'     => array(),
        'vehicles'    => array(),
    );
    foreach ( ridego_get_fleet_drivers( $vendor->id ) as $d ) {
        $s = $shape( 'driver', (int) $d->id );
        $s['id'] = (int) $d->id; $s['name'] = $d->name; $s['rating'] = (float) $d->rating;
        $out['drivers'][] = $s;
    }
    foreach ( ridego_get_fleet_vehicles( $vendor->id ) as $v ) {
        $s = $shape( 'vehicle', (int) $v->id );
        $s['id'] = (int) $v->id; $s['label'] = trim( $v->make_model . ' ' . $v->registration_number );
        $out['vehicles'][] = $s;
    }
    return $out;
}

// TRACE: API serialisation → converts a snapshot row object to a typed array (numbers as numbers,
//        NULL preserved) → returns array. Edge: null input → empty array.
function ridego_snapshot_to_array( $r ) {
    if ( ! $r ) { return array(); }
    $n = function ( $v ) { return $v === null ? null : (float) $v; };
    return array(
        'period' => $r->period,
        'bookings_completed' => (int) $r->bookings_completed,
        'bookings_cancelled' => (int) $r->bookings_cancelled,
        'response_time_avg_secs' => $r->response_time_avg_secs === null ? null : (int) $r->response_time_avg_secs,
        'completion_rate' => $n( $r->completion_rate ),
        'cancellation_rate' => $n( $r->cancellation_rate ),
        'avg_rating' => $n( $r->avg_rating ),
        'on_time_pct' => $n( $r->on_time_pct ),
        'complaint_count' => (int) $r->complaint_count,
    );
}
