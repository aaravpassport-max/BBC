<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Tools & Database
   ------------------------------------------------------------
   Reproduces admin/pages/tools.php for the React admin SPA:
     GET  /ridego/v1/app/admin/tools         -> read-only status data
     POST /ridego/v1/app/admin/tools/action  -> dispatch an action

   Gated on manage_options, matching tools.php's own
   current_user_can('manage_options') check (this page performs
   destructive DB operations, so unlike the granular ridego_* admin
   API routes it does not accept a lesser capability).

   Destructive actions (recreate_tables, reseed_data) are re-checked
   server-side via ridego_destructive_tools_allowed() regardless of
   what the client sent — never trust client-side button disabling.
   ================================================================ */

/**
 * Whether destructive tools (recreate DB tables, reseed demo data) are
 * allowed to run at all. Copied verbatim from
 * admin/pages/tools.php::ridego_destructive_tools_allowed() — that file is
 * only require_once'd lazily when the wp-admin Tools page is rendered
 * (see admin/admin.php's rga_page_tools()), so it is not available to a
 * REST request and the logic is replicated here rather than depended on.
 */
if ( ! function_exists( 'ridego_destructive_tools_allowed' ) ) {
    function ridego_destructive_tools_allowed() {
        return ( defined( 'WP_DEBUG' ) && WP_DEBUG ) || (int) ridego_get_setting( 'ridego_allow_destructive_tools', 0 ) === 1;
    }
}

add_action( 'rest_api_init', 'ridego_register_app_admin_tools_api_routes' );
function ridego_register_app_admin_tools_api_routes() {
    register_rest_route( 'ridego/v1', '/app/admin/tools', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_tools_status',
        'permission_callback' => 'ridego_app_admin_api_tools_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/tools/action', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_tools_action',
        'permission_callback' => 'ridego_app_admin_api_tools_permission',
    ) );
}

function ridego_app_admin_api_tools_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! current_user_can( 'manage_options' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to access tools.', array( 'status' => 403 ) );
    }
    return true;
}

/** Known plugin tables — copied verbatim from admin/pages/tools.php. */
function ridego_app_admin_tools_table_list() {
    return array(
        'ridego_bookings', 'ridego_vendors', 'ridego_vehicles', 'ridego_cities', 'ridego_leads',
        'ridego_promo_codes', 'ridego_vendor_wallets', 'ridego_complaints', 'ridego_audit_log',
        'ridego_notification_queue', 'ridego_surge_pricing', 'ridego_subscription_plans',
        'ridego_route_cache', 'ridego_otp', 'ridego_settings',
    );
}

/** Known frontend page settings — copied verbatim from admin/pages/tools.php. */
function ridego_app_admin_tools_page_settings() {
    return array(
        'booking_page_id', 'home_page_id', 'confirm_page_id', 'search_page_id',
        'vendor_register_page_id', 'vendor_dashboard_page_id', 'my_trips_page_id',
        'track_page_id', 'cities_page_id',
    );
}

function ridego_app_admin_api_tools_status( WP_REST_Request $req ) {
    global $wpdb, $wp_version;

    $destructive_allowed = ridego_destructive_tools_allowed();

    // Database tables.
    $tables = array();
    foreach ( ridego_app_admin_tools_table_list() as $t ) {
        $full   = $wpdb->prefix . $t;
        $exists = $wpdb->get_var( "SHOW TABLES LIKE '{$full}'" ) === $full;
        $count  = $exists ? intval( $wpdb->get_var( "SELECT COUNT(*) FROM {$full}" ) ) : 0;
        $tables[] = array(
            'name'   => $t,
            'table'  => $full,
            'exists' => $exists,
            'count'  => $count,
        );
    }

    // Frontend pages status.
    $pages = array();
    foreach ( ridego_app_admin_tools_page_settings() as $pg ) {
        $pid   = intval( ridego_get_setting( $pg ) );
        $post  = $pid ? get_post( $pid ) : null;
        $label = trim( ucwords( str_replace( array( '_page_id', '_id', '_' ), array( '', ' ', '  ' ), $pg ) ) );

        if ( $post && $post->post_status === 'publish' ) {
            $status = 'live';
            $url    = get_permalink( $pid );
        } elseif ( $post ) {
            $status = $post->post_status;
            $url    = null;
        } else {
            $status = 'missing';
            $url    = null;
        }

        $pages[] = array(
            'key'    => $pg,
            'label'  => $label,
            'status' => $status,
            'url'    => $url,
        );
    }

    // System information.
    $system = array(
        array( 'label' => 'Plugin Version', 'value' => RIDEGO_VER ),
        array( 'label' => 'PHP Version', 'value' => PHP_VERSION ),
        array( 'label' => 'WordPress Version', 'value' => $wp_version ),
        array( 'label' => 'MySQL Version', 'value' => $wpdb->db_version() ),
        array( 'label' => 'Plugin URL', 'value' => RIDEGO_URL ),
        array( 'label' => 'Demo Seeded', 'value' => get_option( 'ridego_demo_seeded' ) ? 'Yes' : 'No' ),
        array( 'label' => 'Memory Limit', 'value' => ini_get( 'memory_limit' ) ),
        array( 'label' => 'Max Upload', 'value' => ini_get( 'upload_max_filesize' ) ),
        array( 'label' => 'WP Debug', 'value' => ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? 'On' : 'Off' ),
        array( 'label' => 'Cron Enabled', 'value' => ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ? 'Disabled' : 'Enabled' ),
    );
    /* Notification queue health: independent of whether WP-Cron itself is
       enabled, since the queue now also flushes at the end of the request
       that queued the item (see ridego_flush_notification_queue_on_shutdown()
       in notifications.php) — this reading is what actually proves that
       fallback is keeping the backlog from growing, rather than trusting
       the "Cron Enabled" flag above as a proxy for "notifications are
       actually being delivered". */
    $notif_table = $wpdb->prefix . 'ridego_notification_queue';
    if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $notif_table ) ) === $notif_table ) {
        $pending_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$notif_table} WHERE status='pending'" );
        $oldest_pending = $wpdb->get_var( "SELECT created_at FROM {$notif_table} WHERE status='pending' ORDER BY created_at ASC LIMIT 1" );
        $system[] = array( 'label' => 'Notification Queue Pending', 'value' => (string) $pending_count );
        if ( $oldest_pending ) {
            $age_minutes = (int) round( ( time() - strtotime( $oldest_pending ) ) / 60 );
            $system[] = array( 'label' => 'Oldest Pending Notification', 'value' => $age_minutes . ' min ago' );
        }
    }
    // Filesystem paths are only useful for debugging and are otherwise free
    // reconnaissance for an attacker — only included in the response at all
    // when WP_DEBUG is on (never sent, not just hidden client-side).
    if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
        $system[] = array( 'label' => 'Plugin Path', 'value' => RIDEGO_PATH );
        $system[] = array( 'label' => 'Secure Uploads', 'value' => RIDEGO_SECURE_UPLOADS );
    }

    return array(
        'destructive_allowed' => $destructive_allowed,
        'tables'              => $tables,
        'pages'               => $pages,
        'system'              => $system,
    );
}

function ridego_app_admin_api_tools_action( WP_REST_Request $req ) {
    global $wpdb;

    $act = sanitize_key( (string) $req->get_param( 'action' ) );
    $destructive_allowed = ridego_destructive_tools_allowed();
    $destructive_acts     = array( 'reseed_data', 'recreate_tables' );

    if ( in_array( $act, $destructive_acts, true ) && ! $destructive_allowed ) {
        return new WP_Error(
            'destructive_disabled',
            'This action is disabled. Enable WP_DEBUG or "Allow Destructive Tools" in Settings > Advanced to use it.',
            array( 'status' => 403 )
        );
    }

    switch ( $act ) {
        case 'create_pages':
            delete_transient( 'ridego_pages_checked' );
            if ( ! function_exists( 'ridego_create_pages' ) ) {
                return new WP_Error( 'not_found', 'Page creation function not found.', array( 'status' => 500 ) );
            }
            ridego_create_pages();
            return array( 'success' => true, 'message' => 'All pages created.' );

        case 'seed_vehicles':
            if ( ! function_exists( 'ridego_seed_all_data' ) ) {
                return new WP_Error( 'not_found', 'Seed function not found.', array( 'status' => 500 ) );
            }
            ridego_seed_all_data();
            return array( 'success' => true, 'message' => 'Vehicles and cities seeded.' );

        case 'flush_rewrite':
            flush_rewrite_rules();
            return array( 'success' => true, 'message' => 'Rewrite rules flushed.' );

        case 'clear_cache':
            delete_transient( 'ridego_route_cache' );
            delete_transient( 'ridego_cities_cache' );
            $wpdb->query( "DELETE FROM {$wpdb->prefix}ridego_route_cache WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)" );
            return array( 'success' => true, 'message' => 'Cache cleared.' );

        case 'recreate_tables':
            if ( ! function_exists( 'ridego_install_tables' ) ) {
                return new WP_Error( 'not_found', 'Install function not found.', array( 'status' => 500 ) );
            }
            ridego_install_tables();
            ridego_audit_log( 'tools_recreate_tables', 'system', 0, '', 'DB tables recreated via Tools page' );
            return array( 'success' => true, 'message' => 'Database tables recreated/updated.' );

        case 'reseed_data':
            delete_option( 'ridego_demo_seeded' );
            if ( ! function_exists( 'ridego_seed_dummy_data' ) ) {
                return new WP_Error( 'not_found', 'Seed function not found.', array( 'status' => 500 ) );
            }
            ridego_seed_dummy_data();
            ridego_audit_log( 'tools_reseed_demo_data', 'system', 0, '', 'demo data reseeded via Tools page' );
            return array( 'success' => true, 'message' => 'Demo data seeded! Vendors, bookings, promo codes added.' );

        case 'delete_demo':
            delete_option( 'ridego_demo_seeded' );
            return array( 'success' => true, 'message' => 'Demo flag cleared. You can re-seed now.' );

        default:
            return new WP_Error( 'unknown_action', 'Unknown tool action.', array( 'status' => 400 ) );
    }
}
