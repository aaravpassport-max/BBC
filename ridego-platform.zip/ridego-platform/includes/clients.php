<?php
/**
 * RideGo back-office CRM: client profiles.
 * One row per person in ridego_clients, matched by phone_key (last 10 digits of the mobile number) so the same
 * person booking online, by phone, or via an admin never produces two profiles. Bookings keep their own snapshot of
 * name/phone at booking time and carry client_profile_id to join to the profile.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: any phone comparison → strips everything but digits and keeps the LAST 10 (so +91 98765 43210, 09876543210 and 9876543210
//        all match) → string ('' when fewer than 10 digits). Pure.
function ridego_phone_key( $phone ) {
    $d = preg_replace( '/\D/', '', (string) $phone );
    return strlen( $d ) >= 10 ? substr( $d, -10 ) : '';
}

// TRACE: create/update/upsert → list of allowed client types → array. Pure.
function ridego_client_types() { return array( 'individual', 'corporate' ); }

// TRACE: create/update/list → list of allowed booking/client sources → array. Pure. 'online' is the public booking flow; the rest are
//        back-office channels an admin can pick when entering a booking or a client.
function ridego_booking_sources() { return array( 'online', 'admin', 'phone', 'whatsapp', 'walk_in', 'email', 'corporate', 'referral', 'offline', 'manual' ); }

// TRACE: phone/email (either may be blank) → matching client rows → array of objects. Matching by phone_key OR lower-cased email.
//        $exclude_id skips one profile (used when editing). Edge cases: both blank → empty array; phone shorter than 10 digits ignored.
function ridego_client_find_matches( $phone, $email = '', $exclude_id = 0 ) {
    global $wpdb;
    $t = "{$wpdb->prefix}ridego_clients";
    $key = ridego_phone_key( $phone ); $email = strtolower( trim( (string) $email ) );
    $where = array(); $args = array();
    if ( $key !== '' ) { $where[] = 'phone_key = %s'; $args[] = $key; }
    if ( $email !== '' ) { $where[] = 'LOWER(email) = %s'; $args[] = $email; }
    if ( ! $where ) { return array(); }
    $sql = "SELECT * FROM {$t} WHERE (" . implode( ' OR ', $where ) . ')';
    if ( $exclude_id ) { $sql .= ' AND id <> %d'; $args[] = (int) $exclude_id; }
    return (array) $wpdb->get_results( $wpdb->prepare( $sql . ' ORDER BY id ASC LIMIT 5', $args ) );
}

// TRACE: id → one client row or null. Pure read.
function ridego_client_get( $id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_clients WHERE id=%d", (int) $id ) );
}

/* ROOT-CAUSE FIX (RideGo-Pre-Delivery-Audit.md, Revision 7, OPEN ISSUES:
   "No client merge tool for two profiles that turn out to be the same
   person"). Two client rows end up for one real person whenever they
   book under a second phone number/email, or register a second time —
   ridego_client_upsert_from_booking()'s own matching (phone_key, then
   email) already dedupes MOST of the time, but a genuinely different
   phone and email on both bookings gives it nothing to match on, and
   the two rows never converge on their own. Merging does NOT touch
   WordPress login identity (wp_user_id on either row is left alone,
   and neither WP user account is altered or deleted) — a client who
   registered twice keeps being able to log in with either account and
   see their own "My Trips" history exactly as before (that view reads
   by wp_user_id, never by client_profile_id). What merges is the ADMIN
   side: every booking, payment and enquiry the LOSING profile owned is
   re-pointed to the SURVIVING profile's id, so one client card shows
   the person's whole history instead of two fragments. The losing row
   is kept, not deleted (merged_into/merged_at recorded, status set to
   'merged') — it stays as the audit trail for how the two profiles
   came to be one, and referential integrity to it (nothing pointed at
   it after the merge, but a stale future reference is a no-op query
   rather than an orphaned foreign key). */
// TRACE: winner id + loser id + actor → re-points every booking/payment/enquiry row from loser to winner, fills the winner's blank contact fields from the loser, marks the loser 'merged' → array(success, message). Audit-logged with both ids.
//        Preconditions: both exist, distinct, neither already itself the loser of an earlier merge (merged_into IS NULL on both). Postconditions: loser row untouched except status/merged_into/merged_at; nothing else in the system still points to the loser's id. Edge cases: unknown id (404-shaped failure), same id twice (400-shaped failure), either already merged (400-shaped failure, names which), DB error partway (whatever succeeded stays merged — re-running the merge is safe/idempotent since a second pass finds nothing left under the loser's id).
function ridego_client_merge( $winner_id, $loser_id, $admin_id ) {
    global $wpdb;
    $winner_id = (int) $winner_id; $loser_id = (int) $loser_id;
    if ( $winner_id <= 0 || $loser_id <= 0 || $winner_id === $loser_id ) { return array( 'success' => false, 'message' => 'Choose two different clients.' ); }
    $winner = ridego_client_get( $winner_id ); $loser = ridego_client_get( $loser_id );
    if ( ! $winner || ! $loser ) { return array( 'success' => false, 'message' => 'Client not found.' ); }
    if ( ! empty( $winner->merged_into ) ) { return array( 'success' => false, 'message' => 'The profile to keep has itself been merged into another one — merge into that one instead.' ); }
    if ( ! empty( $loser->merged_into ) ) { return array( 'success' => false, 'message' => 'That profile has already been merged.' ); }
    $t = $wpdb->prefix . 'ridego_clients';
    // Fill blanks on the winner from the loser (never overwrite something the winner already has, same rule ridego_client_upsert_from_booking() uses).
    $fill = array();
    foreach ( array( 'email', 'alt_phone', 'address', 'city', 'company_name', 'gst_number' ) as $f ) {
        if ( (string) $winner->$f === '' && (string) $loser->$f !== '' ) { $fill[ $f ] = $loser->$f; }
    }
    if ( $fill ) { $fill['updated_at'] = current_time( 'mysql' ); $wpdb->update( $t, $fill, array( 'id' => $winner_id ) ); }
    $wpdb->update( "{$wpdb->prefix}ridego_bookings", array( 'client_profile_id' => $winner_id ), array( 'client_profile_id' => $loser_id ) );
    $wpdb->update( "{$wpdb->prefix}ridego_bookings_archive", array( 'client_profile_id' => $winner_id ), array( 'client_profile_id' => $loser_id ) );
    $wpdb->update( "{$wpdb->prefix}ridego_booking_payments", array( 'client_id' => $winner_id ), array( 'client_id' => $loser_id ) );
    $wpdb->update( "{$wpdb->prefix}ridego_enquiries", array( 'client_id' => $winner_id ), array( 'client_id' => $loser_id ) );
    $wpdb->update( $t, array( 'status' => 'merged', 'merged_into' => $winner_id, 'merged_at' => current_time( 'mysql' ), 'updated_at' => current_time( 'mysql' ) ), array( 'id' => $loser_id ) );
    ridego_audit_log( 'client_merged', 'client', $winner_id, (string) $loser_id, (string) $winner_id );
    return array( 'success' => true, 'message' => 'Merged. All of ' . $loser->name . '\'s bookings, payments and enquiries now show under this profile.' );
}

// TRACE: raw input array + $creating → sanitised map of the fields PRESENT + error string|null → array('data'=>,'error'=>).
//        Creating: name and a valid mobile (10-13 digits) are required. Email must parse; GST 15 chars when given; type/status/source from lists.
//        Edge cases: present-but-blank name on update is refused; unknown source falls back to 'admin'; notes capped at 2000 chars.
function ridego_client_validate( $raw, $creating ) {
    $d = array(); $fail = function ( $m ) { return array( 'data' => null, 'error' => $m ); };
    $raw = (array) $raw;
    if ( $creating || array_key_exists( 'name', $raw ) ) {
        $n = trim( sanitize_text_field( (string) ( $raw['name'] ?? '' ) ) );
        if ( $n === '' ) { return $fail( 'Client name is required.' ); }
        $d['name'] = mb_substr( $n, 0, 150 );
    }
    if ( $creating || array_key_exists( 'phone', $raw ) ) {
        $ph = ridego_sanitize_phone( (string) ( $raw['phone'] ?? '' ) ); $digits = preg_replace( '/\D/', '', $ph );
        if ( strlen( $digits ) < 10 || strlen( $digits ) > 13 ) { return $fail( 'Enter a valid mobile number (10 to 13 digits).' ); }
        $d['phone'] = $ph; $d['phone_key'] = ridego_phone_key( $ph );
    }
    if ( array_key_exists( 'alt_phone', $raw ) ) {
        $ph = ridego_sanitize_phone( (string) $raw['alt_phone'] ); $digits = preg_replace( '/\D/', '', $ph );
        if ( $digits !== '' && ( strlen( $digits ) < 10 || strlen( $digits ) > 13 ) ) { return $fail( 'Enter a valid alternate contact number or leave it blank.' ); }
        $d['alt_phone'] = $ph;
    }
    if ( array_key_exists( 'email', $raw ) ) {
        $e = trim( (string) $raw['email'] );
        if ( $e !== '' && ! is_email( $e ) ) { return $fail( 'Enter a valid email address or leave it blank.' ); }
        $d['email'] = sanitize_email( $e );
    }
    foreach ( array( 'address' => 500, 'city' => 100, 'company_name' => 150, 'tags' => 255 ) as $k => $max ) {
        if ( array_key_exists( $k, $raw ) ) { $d[ $k ] = mb_substr( $k === 'address' ? sanitize_textarea_field( (string) $raw[ $k ] ) : sanitize_text_field( (string) $raw[ $k ] ), 0, $max ); }
    }
    if ( array_key_exists( 'gst_number', $raw ) ) {
        $g = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $raw['gst_number'] ) );
        if ( $g !== '' && strlen( $g ) !== 15 ) { return $fail( 'A GST number has 15 characters. Check it or leave it blank.' ); }
        $d['gst_number'] = $g;
    }
    if ( array_key_exists( 'notes', $raw ) ) { $d['notes'] = mb_substr( sanitize_textarea_field( (string) $raw['notes'] ), 0, 2000 ); }
    if ( array_key_exists( 'client_type', $raw ) ) {
        $t = sanitize_key( (string) $raw['client_type'] );
        if ( ! in_array( $t, ridego_client_types(), true ) ) { return $fail( 'Client type must be individual or corporate.' ); }
        $d['client_type'] = $t;
    }
    if ( array_key_exists( 'source', $raw ) ) {
        $s = sanitize_key( (string) $raw['source'] );
        $d['source'] = in_array( $s, ridego_booking_sources(), true ) ? $s : 'admin';
    }
    if ( ( $d['client_type'] ?? ( $raw['client_type'] ?? '' ) ) === 'corporate' && $creating && trim( (string) ( $d['company_name'] ?? '' ) ) === '' ) {
        return $fail( 'Enter the company name for a corporate client.' );
    }
    return array( 'data' => $d, 'error' => null );
}

// TRACE: raw input + admin id + $allow_email_dup → creates a profile → array(success, id|message, duplicate?).
//        Same mobile (phone_key) as an existing profile is ALWAYS refused and the existing profile returned as `duplicate`;
//        the same email on a different mobile is refused unless $allow_email_dup is true (shared corporate mailbox).
//        Postconditions: one new row, audit-logged. Edge cases: validation error (message), DB failure (message, nothing stored).
function ridego_client_create( $raw, $admin_id, $allow_email_dup = false ) {
    global $wpdb;
    $v = ridego_client_validate( $raw, true );
    if ( $v['error'] ) { return array( 'success' => false, 'message' => $v['error'] ); }
    $d = $v['data'];
    $dups = ridego_client_find_matches( $d['phone'], $allow_email_dup ? '' : ( $d['email'] ?? '' ) );
    if ( $dups ) {
        $same_phone = ridego_phone_key( $dups[0]->phone ) === $d['phone_key'];
        return array( 'success' => false, 'duplicate' => ridego_client_summary( $dups[0] ),
            'message' => $same_phone ? 'A client with this mobile number already exists: ' . $dups[0]->name . '.' : 'A client with this email already exists: ' . $dups[0]->name . '.' );
    }
    $row = array_merge( array( 'client_type' => 'individual', 'source' => 'admin', 'status' => 'active', 'email' => '', 'alt_phone' => '', 'address' => '', 'city' => '', 'company_name' => '', 'gst_number' => '', 'notes' => '', 'tags' => '' ), $d );
    $row['created_by'] = (int) $admin_id; $row['created_at'] = current_time( 'mysql' ); $row['updated_at'] = current_time( 'mysql' );
    $u = $row['email'] !== '' ? get_user_by( 'email', $row['email'] ) : false;
    $row['wp_user_id'] = $u ? (int) $u->ID : 0;
    if ( ! $wpdb->insert( "{$wpdb->prefix}ridego_clients", $row ) ) {
        ridego_log( 'client_create failed: ' . $wpdb->last_error );
        return array( 'success' => false, 'message' => 'Could not save the client. Please try again.' );
    }
    $id = (int) $wpdb->insert_id;
    ridego_audit_log( 'client_created', 'client', $id, '', $row['name'] . ' ' . $row['phone'] );
    return array( 'success' => true, 'id' => $id, 'message' => 'Client created.' );
}

// TRACE: client id + raw partial input + admin id → validates, refuses a change that would collide with ANOTHER profile's phone/email,
//        updates only the present keys → array(success,message). Postconditions: audit row lists changed keys. Edge cases: unknown id
//        (message), no changes (success, "No changes"), blocked/active status changes go through ridego_client_set_status().
function ridego_client_update( $id, $raw, $admin_id ) {
    global $wpdb;
    $cur = ridego_client_get( $id );
    if ( ! $cur ) { return array( 'success' => false, 'message' => 'Client not found.' ); }
    unset( $raw['status'] );
    $v = ridego_client_validate( $raw, false );
    if ( $v['error'] ) { return array( 'success' => false, 'message' => $v['error'] ); }
    $d = $v['data'];
    $changed = array();
    foreach ( $d as $k => $val ) { if ( (string) $cur->$k !== (string) $val ) { $changed[ $k ] = $val; } }
    if ( ! $changed ) { return array( 'success' => true, 'message' => 'No changes to save.' ); }
    if ( isset( $changed['phone_key'] ) || isset( $changed['email'] ) ) {
        $dups = ridego_client_find_matches( $changed['phone'] ?? '', $changed['email'] ?? '', $id );
        if ( $dups ) { return array( 'success' => false, 'duplicate' => ridego_client_summary( $dups[0] ), 'message' => 'Another client already uses that mobile number or email: ' . $dups[0]->name . '.' ); }
    }
    $changed['updated_at'] = current_time( 'mysql' );
    if ( false === $wpdb->update( "{$wpdb->prefix}ridego_clients", $changed, array( 'id' => (int) $id ) ) ) {
        ridego_log( 'client_update failed: ' . $wpdb->last_error );
        return array( 'success' => false, 'message' => 'Could not save the changes. Please try again.' );
    }
    ridego_audit_log( 'client_updated', 'client', (int) $id, '', implode( ',', array_keys( $changed ) ) );
    return array( 'success' => true, 'message' => 'Client updated.' );
}

// TRACE: client id + 'active'|'blocked' + reason + admin → sets status → array(success,message). A blocked client cannot place online bookings
//        (see ridego_create_booking) and the admin booking form warns. Edge cases: unknown id / bad status (message).
function ridego_client_set_status( $id, $status, $reason, $admin_id ) {
    global $wpdb;
    if ( ! in_array( $status, array( 'active', 'blocked' ), true ) ) { return array( 'success' => false, 'message' => 'Invalid status.' ); }
    $cur = ridego_client_get( $id );
    if ( ! $cur ) { return array( 'success' => false, 'message' => 'Client not found.' ); }
    if ( $status === 'blocked' && trim( (string) $reason ) === '' ) { return array( 'success' => false, 'message' => 'Give a reason for blocking this client.' ); }
    if ( false === $wpdb->update( "{$wpdb->prefix}ridego_clients", array( 'status' => $status, 'updated_at' => current_time( 'mysql' ) ), array( 'id' => (int) $id ) ) ) {
        return array( 'success' => false, 'message' => 'Could not update the client.' );
    }
    ridego_audit_log( $status === 'blocked' ? 'client_blocked' : 'client_unblocked', 'client', (int) $id, $cur->status, sanitize_text_field( (string) $reason ) );
    return array( 'success' => true, 'message' => $status === 'blocked' ? 'Client blocked.' : 'Client unblocked.' );
}

// TRACE: client row → the small shape used in duplicate warnings and pickers → array. Pure.
function ridego_client_summary( $c ) {
    return array( 'id' => (int) $c->id, 'name' => $c->name, 'phone' => $c->phone, 'email' => $c->email, 'alt_phone' => $c->alt_phone, 'client_type' => $c->client_type,
        'company_name' => $c->company_name, 'status' => $c->status, 'merged_into' => empty( $c->merged_into ) ? null : (int) $c->merged_into, 'merged_at' => $c->merged_at ?? null );
}

// TRACE: booking-creation data (client_name, client_phone, client_email, client_alt_phone, corporate_*) + source + creator → profile id (int) or 0.
//        Finds by phone_key then email; when found, fills BLANK email/alt/company only (never overwrites what the admin curated) and returns its id;
//        when absent, creates one. Edge cases: phone < 10 digits → 0 (booking stays unlinked); DB failure → 0 (booking still proceeds).
function ridego_client_upsert_from_booking( $data, $source = 'online', $created_by = 0 ) {
    global $wpdb;
    $phone = ridego_sanitize_phone( (string) ( $data['client_phone'] ?? '' ) );
    if ( ridego_phone_key( $phone ) === '' ) { return 0; }
    $email = sanitize_email( (string) ( $data['client_email'] ?? '' ) );
    $found = ridego_client_find_matches( $phone, '' );
    if ( ! $found && $email !== '' ) { $found = ridego_client_find_matches( '', $email ); }
    if ( $found ) {
        $c = $found[0]; $upd = array();
        if ( $c->email === '' && $email !== '' ) { $upd['email'] = $email; }
        $alt = ridego_sanitize_phone( (string) ( $data['client_alt_phone'] ?? '' ) );
        if ( $c->alt_phone === '' && $alt !== '' ) { $upd['alt_phone'] = $alt; }
        if ( $c->company_name === '' && ! empty( $data['corporate_company'] ) ) { $upd['company_name'] = sanitize_text_field( (string) $data['corporate_company'] ); $upd['client_type'] = 'corporate'; }
        if ( $c->gst_number === '' && ! empty( $data['corporate_gst'] ) ) { $upd['gst_number'] = strtoupper( sanitize_text_field( (string) $data['corporate_gst'] ) ); }
        if ( $upd ) { $upd['updated_at'] = current_time( 'mysql' ); $wpdb->update( "{$wpdb->prefix}ridego_clients", $upd, array( 'id' => (int) $c->id ) ); }
        return (int) $c->id;
    }
    $corp = ! empty( $data['corporate_company'] );
    $row = array( 'name' => sanitize_text_field( (string) ( $data['client_name'] ?? '' ) ), 'phone' => $phone, 'phone_key' => ridego_phone_key( $phone ), 'email' => $email,
        'alt_phone' => ridego_sanitize_phone( (string) ( $data['client_alt_phone'] ?? '' ) ), 'client_type' => $corp ? 'corporate' : 'individual',
        'company_name' => $corp ? sanitize_text_field( (string) $data['corporate_company'] ) : '', 'gst_number' => $corp ? strtoupper( sanitize_text_field( (string) ( $data['corporate_gst'] ?? '' ) ) ) : '',
        'source' => in_array( $source, ridego_booking_sources(), true ) ? $source : 'online', 'status' => 'active', 'created_by' => (int) $created_by,
        'wp_user_id' => is_user_logged_in() && $source === 'online' ? get_current_user_id() : ( $email !== '' && ( $u = get_user_by( 'email', $email ) ) ? (int) $u->ID : 0 ),
        'created_at' => current_time( 'mysql' ), 'updated_at' => current_time( 'mysql' ) );
    if ( $row['name'] === '' ) { $row['name'] = 'Guest'; }
    return $wpdb->insert( "{$wpdb->prefix}ridego_clients", $row ) ? (int) $wpdb->insert_id : 0;
}

// TRACE: migration 24 → for every booking with client_profile_id=0 and a usable phone: creates (or reuses) a profile keyed by phone_key using the
//        newest booking's name/email/alt/company, then links all that phone's bookings → void. Idempotent. Edge cases: short phones skipped.
function ridego_clients_backfill_from_bookings() {
    global $wpdb;
    $b = "{$wpdb->prefix}ridego_bookings"; $c = "{$wpdb->prefix}ridego_clients";
    $rows = $wpdb->get_results( "SELECT id, client_id, client_name, client_phone, client_email, client_alt_phone, corporate_company, corporate_gst FROM {$b} WHERE client_profile_id = 0 ORDER BY id DESC" );
    $seen = array();
    foreach ( (array) $rows as $r ) {
        $key = ridego_phone_key( $r->client_phone );
        if ( $key === '' ) { continue; }
        if ( ! isset( $seen[ $key ] ) ) {
            $ex = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$c} WHERE phone_key=%s LIMIT 1", $key ) );
            if ( $ex ) { $seen[ $key ] = (int) $ex; }
            else {
                $corp = trim( (string) $r->corporate_company ) !== '';
                $wpdb->insert( $c, array( 'name' => $r->client_name !== '' ? $r->client_name : 'Guest', 'phone' => ridego_sanitize_phone( $r->client_phone ), 'phone_key' => $key,
                    'email' => sanitize_email( (string) $r->client_email ), 'alt_phone' => ridego_sanitize_phone( (string) $r->client_alt_phone ), 'client_type' => $corp ? 'corporate' : 'individual',
                    'company_name' => (string) $r->corporate_company, 'gst_number' => strtoupper( (string) $r->corporate_gst ), 'wp_user_id' => (int) $r->client_id, 'source' => 'online',
                    'created_at' => current_time( 'mysql' ), 'updated_at' => current_time( 'mysql' ) ) );
                $seen[ $key ] = (int) $wpdb->insert_id;
            }
        }
        if ( $seen[ $key ] ) { $wpdb->update( $b, array( 'client_profile_id' => $seen[ $key ] ), array( 'id' => (int) $r->id ) ); }
    }
}

/* ------------------------------------------------------------------
   Root-cause fix (Master Issue Register: client CRM visibility gap).
   ------------------------------------------------------------------
   ridego_client_upsert_from_booking() only ever runs from
   ridego_create_booking() — a wp_ridego_clients row has only ever come
   into existence when the PERSON completed a booking. A user who
   registered an account (ridego_app_api_auth_register(), app-api.php)
   and never booked has a real wp_users row and can sign in, but is
   completely invisible on the admin CRM's Clients screen (which reads
   only wp_ridego_clients) — support staff searching for them by name
   or phone find nothing, and any note/tag/status recorded against
   "the client" has nowhere to attach until their first booking
   happens to create it. The two functions below close that: one runs
   at registration time (going forward), the other backfills every
   existing account that slipped through before this fix existed.
   ------------------------------------------------------------------ */

// TRACE: successful registration (ridego_app_api_auth_register(), app-api.php) → the same find-or-create-by-phone-key matching
//        ridego_client_upsert_from_booking() uses, but explicitly linking wp_user_id to the account just created (that function only
//        ever links wp_user_id for an ONLINE, already-logged-in booking — at registration time the session cookie isn't set yet, so it
//        would have left wp_user_id at 0) → client profile id (int), or 0 if the phone is unusable. Postconditions: an existing profile
//        matched by phone/email gets wp_user_id filled in ONLY if it was still 0 (never reassigns a profile someone else already owns);
//        a new profile is created with source='online' and wp_user_id set immediately. Edge cases: phone too short → 0, no user row
//        found for $uid → 0 (defensive; the caller always has a fresh $uid so this should not happen in practice).
function ridego_client_sync_from_user( $uid ) {
    global $wpdb;
    $user = get_userdata( (int) $uid );
    if ( ! $user ) { return 0; }
    $phone = ridego_sanitize_phone( (string) get_user_meta( $uid, 'ridego_phone', true ) );
    if ( ridego_phone_key( $phone ) === '' ) { return 0; }
    $email = sanitize_email( (string) $user->user_email );
    $found = ridego_client_find_matches( $phone, '' );
    if ( ! $found && $email !== '' ) { $found = ridego_client_find_matches( '', $email ); }
    if ( $found ) {
        $c = $found[0];
        if ( (int) $c->wp_user_id === 0 ) {
            $wpdb->update( "{$wpdb->prefix}ridego_clients", array( 'wp_user_id' => (int) $uid, 'updated_at' => current_time( 'mysql' ) ), array( 'id' => (int) $c->id ) );
        }
        ridego_client_relink_bookings_to_user( (int) $c->id, (int) $uid );
        return (int) $c->id;
    }
    $name = trim( (string) $user->display_name ) !== '' ? $user->display_name : 'Guest';
    $row = array(
        'name' => sanitize_text_field( $name ), 'phone' => $phone, 'phone_key' => ridego_phone_key( $phone ), 'email' => $email,
        'alt_phone' => '', 'client_type' => 'individual', 'company_name' => '', 'gst_number' => '', 'source' => 'online', 'status' => 'active',
        'created_by' => 0, 'wp_user_id' => (int) $uid, 'created_at' => current_time( 'mysql' ), 'updated_at' => current_time( 'mysql' ),
    );
    $new_id = $wpdb->insert( "{$wpdb->prefix}ridego_clients", $row ) ? (int) $wpdb->insert_id : 0;
    if ( $new_id ) { ridego_client_relink_bookings_to_user( $new_id, (int) $uid ); }
    return $new_id;
}

/* ROOT-CAUSE FIX (dashboard empty after guest→account payment-proof
   flow): a guest booking is created with client_profile_id set (via
   ridego_client_upsert_from_booking(), matched by phone/email) but
   client_id LEFT AT 0 (includes/booking.php: is_user_logged_in() is
   false for a guest) — client_id is the WP user id, and the client
   dashboard (includes/app-client-dashboard-api.php) queries every
   list/count/detail STRICTLY by b.client_id = get_current_user_id(),
   never by client_profile_id. When ridego_client_sync_from_user() runs
   right after account auto-creation, it only pointed the client
   profile's wp_user_id at the new account — it never went back and
   updated the booking rows that were created before the account
   existed, so they stayed invisible to every dashboard query the
   instant after login. This retroactively points every booking that
   already carries this client_profile_id (and is not yet linked to a
   real user) at the new account, so the guest's own just-made booking
   appears immediately, without any manual data cleanup. */
// TRACE: client_profile_id + wp user id → sets client_id on every wp_ridego_bookings row with that client_profile_id and client_id=0 → int rows affected.
function ridego_client_relink_bookings_to_user( $client_profile_id, $uid ) {
    global $wpdb;
    $client_profile_id = (int) $client_profile_id; $uid = (int) $uid;
    if ( ! $client_profile_id || ! $uid ) { return 0; }
    return (int) $wpdb->update(
        "{$wpdb->prefix}ridego_bookings",
        array( 'client_id' => $uid ),
        array( 'client_profile_id' => $client_profile_id, 'client_id' => 0 )
    );
}

// TRACE: migration 037 → every subscriber-role WP user with a usable phone (ridego_phone meta) and no linked wp_ridego_clients row
//        (checked by wp_user_id first, then by phone_key so a profile created online before this fix — with wp_user_id already 0 —
//        gets linked rather than duplicated) gets one created via ridego_client_sync_from_user() → void. Idempotent: re-running finds
//        every affected user already has wp_user_id set and does nothing. Edge cases: no phone on file → skipped (nothing to key a
//        profile on); already has a profile → linked, not duplicated.
function ridego_clients_backfill_from_users() {
    global $wpdb;
    $linked = (array) $wpdb->get_col( "SELECT DISTINCT wp_user_id FROM {$wpdb->prefix}ridego_clients WHERE wp_user_id > 0" );
    $linked = array_map( 'intval', $linked );
    $users = get_users( array( 'role' => 'subscriber', 'fields' => array( 'ID' ) ) );
    foreach ( $users as $u ) {
        $uid = (int) $u->ID;
        if ( in_array( $uid, $linked, true ) ) { continue; }
        ridego_client_sync_from_user( $uid );
    }
}

// TRACE: client id → aggregate numbers used on list rows and the profile header → array. Counts every booking linked by client_profile_id.
//        total_paid = payments minus refunds from ridego_booking_payments PLUS advance_paid of bookings that have no payment rows (legacy online
//        bookings), so history stays accurate. outstanding = sum of balance_due on non-cancelled bookings. Edge cases: no bookings → zeros.
function ridego_client_stats( $id ) {
    global $wpdb;
    $b = "{$wpdb->prefix}ridego_bookings"; $p = "{$wpdb->prefix}ridego_booking_payments";
    $id = (int) $id;
    $r = $wpdb->get_row( $wpdb->prepare(
        "SELECT COUNT(*) AS total, SUM(status='completed') AS completed, SUM(status='cancelled') AS cancelled,
                SUM(status NOT IN ('completed','cancelled','expired')) AS active,
                COALESCE(SUM(CASE WHEN status='cancelled' THEN 0 ELSE total_fare END),0) AS billed,
                COALESCE(SUM(CASE WHEN status IN ('cancelled','expired') THEN 0 ELSE balance_due END),0) AS outstanding,
                MAX(journey_date) AS last_trip
         FROM {$b} WHERE client_profile_id=%d", $id ) );
    $paid = (float) $wpdb->get_var( $wpdb->prepare(
        "SELECT COALESCE(SUM(CASE WHEN entry_type='refund' THEN -amount WHEN entry_type='payment' THEN amount ELSE 0 END),0) FROM {$p} WHERE client_id=%d", $id ) );
    $legacy = (float) $wpdb->get_var( $wpdb->prepare(
        "SELECT COALESCE(SUM(advance_paid),0) FROM {$b} WHERE client_profile_id=%d AND id NOT IN (SELECT booking_id FROM {$p})", $id ) );
    return array( 'bookings' => (int) $r->total, 'completed' => (int) $r->completed, 'cancelled' => (int) $r->cancelled, 'active' => (int) $r->active,
        'billed' => round( (float) $r->billed, 2 ), 'paid' => round( $paid + $legacy, 2 ), 'outstanding' => round( (float) $r->outstanding, 2 ), 'last_trip' => $r->last_trip );
}

// TRACE: list args (q, type, status, source, sort, order, page, per_page) → array(rows,total,page,per_page). Search matches name, phone digits, email,
//        company. Sort: recent|name|bookings|billed. Rows include booking counts (one grouped query, no N+1). Edge cases: per_page clamped 1..100.
function ridego_client_list( $args ) {
    global $wpdb;
    $t = "{$wpdb->prefix}ridego_clients"; $b = "{$wpdb->prefix}ridego_bookings";
    $where = array( '1=1' ); $vals = array();
    $q = trim( (string) ( $args['q'] ?? '' ) );
    if ( $q !== '' ) {
        $like = '%' . $wpdb->esc_like( $q ) . '%'; $digits = preg_replace( '/\D/', '', $q );
        $parts = array( 'c.name LIKE %s', 'c.email LIKE %s', 'c.company_name LIKE %s', 'c.phone LIKE %s' ); $vals = array_merge( $vals, array( $like, $like, $like, $like ) );
        if ( strlen( $digits ) >= 4 ) { $parts[] = 'c.phone_key LIKE %s'; $vals[] = '%' . $wpdb->esc_like( $digits ) . '%'; $parts[] = 'c.alt_phone LIKE %s'; $vals[] = '%' . $wpdb->esc_like( $digits ) . '%'; }
        $where[] = '(' . implode( ' OR ', $parts ) . ')';
    }
    foreach ( array( 'client_type' => 'type', 'status' => 'status', 'source' => 'source' ) as $col => $key ) {
        $v = sanitize_key( (string) ( $args[ $key ] ?? '' ) );
        if ( $v !== '' ) { $where[] = "c.{$col} = %s"; $vals[] = $v; }
    }
    $per = max( 1, min( 100, (int) ( $args['per_page'] ?? 25 ) ) ); $page = max( 1, (int) ( $args['page'] ?? 1 ) );
    $sorts = array( 'recent' => 'c.id', 'name' => 'c.name', 'bookings' => 'bk.n', 'billed' => 'bk.billed' );
    $sort = $sorts[ $args['sort'] ?? 'recent' ] ?? 'c.id'; $order = strtoupper( (string) ( $args['order'] ?? 'DESC' ) ) === 'ASC' ? 'ASC' : 'DESC';
    $w = implode( ' AND ', $where );
    $join = "LEFT JOIN (SELECT client_profile_id, COUNT(*) n, SUM(status='completed') done, SUM(status='cancelled') cx, MAX(journey_date) last_trip,
                COALESCE(SUM(CASE WHEN status='cancelled' THEN 0 ELSE total_fare END),0) billed FROM {$b} WHERE client_profile_id>0 GROUP BY client_profile_id) bk ON bk.client_profile_id = c.id";
    $count_sql = "SELECT COUNT(*) FROM {$t} c WHERE {$w}";
    $total = (int) ( $vals ? $wpdb->get_var( $wpdb->prepare( $count_sql, $vals ) ) : $wpdb->get_var( $count_sql ) );
    $sql = "SELECT c.*, COALESCE(bk.n,0) AS bookings, COALESCE(bk.done,0) AS completed, COALESCE(bk.cx,0) AS cancelled, COALESCE(bk.billed,0) AS billed, bk.last_trip
            FROM {$t} c {$join} WHERE {$w} ORDER BY {$sort} {$order}, c.id DESC LIMIT %d OFFSET %d";
    $rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $vals, array( $per, ( $page - 1 ) * $per ) ) ) );
    $out = array_map( function ( $c ) {
        return array_merge( ridego_client_summary( $c ), array( 'city' => $c->city, 'source' => $c->source, 'tags' => $c->tags, 'created_at' => $c->created_at,
            'bookings' => (int) $c->bookings, 'completed' => (int) $c->completed, 'cancelled' => (int) $c->cancelled, 'billed' => round( (float) $c->billed, 2 ), 'last_trip' => $c->last_trip ) );
    }, (array) $rows );
    return array( 'rows' => $out, 'total' => $total, 'page' => $page, 'per_page' => $per );
}

// TRACE: client id → full profile bundle (profile, stats, bookings, payments, enquiries, complaints, notes) → array|null.
//        Bookings newest first (max 100). Complaints are joined through the client's bookings. Edge cases: unknown id → null.
function ridego_client_profile( $id ) {
    global $wpdb;
    $c = ridego_client_get( $id );
    if ( ! $c ) { return null; }
    $b = "{$wpdb->prefix}ridego_bookings"; $id = (int) $id;
    $bookings = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, booking_number, trip_type, pickup_city, drop_city, journey_date, journey_time, status, payment_status, total_fare, advance_paid, balance_due, booking_source, vendor_id, created_at
         FROM {$b} WHERE client_profile_id=%d ORDER BY journey_date DESC, id DESC LIMIT 100", $id ) );
    $payments = $wpdb->get_results( $wpdb->prepare(
        "SELECT p.*, b.booking_number FROM {$wpdb->prefix}ridego_booking_payments p LEFT JOIN {$b} b ON b.id=p.booking_id WHERE p.client_id=%d ORDER BY p.id DESC LIMIT 100", $id ) );
    $enq = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_enquiries WHERE client_id=%d ORDER BY id DESC LIMIT 50", $id ) );
    $cmp = $wpdb->get_results( $wpdb->prepare(
        "SELECT k.id, k.complaint_id, k.category, k.status, k.priority, k.created_at, b.booking_number FROM {$wpdb->prefix}ridego_complaints k
         JOIN {$b} b ON b.id=k.booking_id WHERE b.client_profile_id=%d ORDER BY k.id DESC LIMIT 50", $id ) );
    $profile = ridego_client_summary( $c );
    $profile += array( 'wp_user_id' => (int) $c->wp_user_id, 'city' => $c->city, 'address' => (string) $c->address, 'gst_number' => $c->gst_number, 'notes' => (string) $c->notes, 'tags' => $c->tags,
        'source' => $c->source, 'created_at' => $c->created_at, 'updated_at' => $c->updated_at );
    return array( 'client' => $profile, 'stats' => ridego_client_stats( $id ), 'bookings' => array_map( function ( $r ) { return (array) $r; }, (array) $bookings ),
        'payments' => array_map( function ( $r ) { return (array) $r; }, (array) $payments ), 'enquiries' => array_map( function ( $r ) { return (array) $r; }, (array) $enq ),
        'complaints' => array_map( function ( $r ) { return (array) $r; }, (array) $cmp ) );
}
