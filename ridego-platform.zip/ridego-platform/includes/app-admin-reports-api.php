<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Phase B, wave 7: analytics / reports
   ------------------------------------------------------------
   admin/pages/reports.php is READ-ONLY (confirmed by research — no
   save/write handler anywhere in the file) and two of its five
   data sources ALREADY have REST routes: GET /reports/summary and
   GET /reports/vendor-performance (includes/rest-api.php:82-101),
   both already gated on ridego_can('ridego_view_reports') via
   ridego_rest_permission_check(), and both already delegating to
   the same canonical functions the admin page itself uses
   (ridego_get_booking_report_summary(), ridego_get_vendor_
   performance_scores()) — so the admin UI and the partner-facing
   REST API can never compute two different numbers for the same
   period. Those two are consumed AS-IS by this wave's frontend;
   they are not re-wrapped here.

   This file adds only the THREE data sources the admin page
   computes as raw inline SQL with no existing REST route: daily
   breakdown, bookings-by-trip-type, and top routes. Every query
   below is copied verbatim (same WHERE clause, same GROUP BY, same
   LIMIT) from admin/pages/reports.php:18-19,38-45 — not
   reconstructed from memory of what a reports page "should" show.

   CSV EXPORT — DELIBERATELY NOT REBUILT HERE, FLAGGED NOT SILENTLY
   DROPPED: the legacy page's two export buttons are plain links to
   a wp_ajax_ridego_export_csv handler in admin/admin.php, gated on
   a DIFFERENT capability (ridego_export_data, not ridego_view_
   reports) and are NOT date-range scoped to this page's filters —
   they export the full bookings/vendors tables (or, from other
   pages, a POST'd list of selected IDs). Reproducing that as a REST
   JSON endpoint would be a different feature (a date-scoped export)
   than what exists, so the new frontend links out to the same
   admin-ajax.php URL rather than inventing a new export behavior,
   and this gap is documented here and in the remediation report
   rather than quietly resolved either way.

   Every route requires is_user_logged_in() AND
   ridego_can('ridego_view_reports') — the exact capability
   admin/pages/reports.php and the two existing report REST routes
   already require.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_reports_api_routes' );
function ridego_register_app_admin_reports_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/reports/daily', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_reports_daily',
        'permission_callback' => 'ridego_app_admin_api_reports_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/reports/trip-types', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_reports_trip_types',
        'permission_callback' => 'ridego_app_admin_api_reports_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/reports/top-routes', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_reports_top_routes',
        'permission_callback' => 'ridego_app_admin_api_reports_permission',
    ) );

    /* NOT gated on ridego_view_reports — this is specifically for the
       CSV export buttons, which the legacy page itself gates on the
       DIFFERENT ridego_export_data capability (admin/admin.php:219).
       Without this route the React page's export buttons would call
       admin-ajax.php with no way to obtain a valid nonce and would
       silently fail with "Unauthorized" — confirmed by reading the
       wp_verify_nonce() check in that handler before adding this.
       wp_create_nonce() here is safe to call from a REST callback: a
       WordPress nonce is derived from the current user's ID + session
       token, not from which page requested it, so a nonce minted here
       for the logged-in admin is valid when that same admin's browser
       uses it against admin-ajax.php a moment later (same site, same
       login session, via the SPA's existing cookie-based auth). */
    register_rest_route( 'ridego/v1', '/app/admin/reports/export-nonce', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_reports_export_nonce',
        'permission_callback' => 'ridego_app_admin_api_reports_export_permission',
    ) );
}

function ridego_app_admin_api_reports_export_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_export_data' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to export data.', array( 'status' => 403 ) );
    }
    return true;
}

function ridego_app_admin_api_reports_export_nonce( WP_REST_Request $req ) {
    return rest_ensure_response( array( 'nonce' => wp_create_nonce( 'ridego_admin_nonce' ) ) );
}

function ridego_app_admin_api_reports_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_view_reports' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to view reports.', array( 'status' => 403 ) );
    }
    return true;
}

/**
 * Same from/to defaults as admin/pages/reports.php:7-8 (month-to-
 * date) so a React page with no filters applied shows the same
 * default window the legacy page does.
 */
function ridego_app_admin_api_reports_date_range( WP_REST_Request $req ) {
    $from = sanitize_text_field( (string) ( $req->get_param( 'from' ) ?: gmdate( 'Y-m-01' ) ) );
    $to   = sanitize_text_field( (string) ( $req->get_param( 'to' ) ?: gmdate( 'Y-m-d' ) ) );
    return array( $from, $to );
}

/**
 * Copied verbatim from admin/pages/reports.php:32-45 — paginated via
 * the same rga_pagination()-style approach (31 per page) the legacy
 * page uses instead of a hard LIMIT 31 that silently truncated
 * longer ranges.
 */
function ridego_app_admin_api_reports_daily( WP_REST_Request $req ) {
    global $wpdb;
    $btbl = $wpdb->prefix . 'ridego_bookings';
    list( $from, $to ) = ridego_app_admin_api_reports_date_range( $req );
    $per   = 31;
    $page  = max( 1, (int) $req->get_param( 'page' ) );
    $offset = ( $page - 1 ) * $per;

    $total = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(DISTINCT DATE(created_at)) FROM {$btbl} WHERE DATE(created_at) BETWEEN %s AND %s", $from, $to
    ) );
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT DATE(created_at) as d, COUNT(*) as cnt, COALESCE(SUM(total_fare),0) as rev, COALESCE(SUM(advance_paid),0) as col, SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as done
         FROM {$btbl} WHERE DATE(created_at) BETWEEN %s AND %s GROUP BY DATE(created_at) ORDER BY d DESC LIMIT %d OFFSET %d",
        $from, $to, $per, $offset
    ) );

    $out = array_map( function ( $r ) {
        return array(
            'date'      => $r->d,
            'bookings'  => (int) $r->cnt,
            'revenue'   => (float) $r->rev,
            'collected' => (float) $r->col,
            'completed' => (int) $r->done,
        );
    }, $rows );

    return rest_ensure_response( array(
        'rows'     => $out,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $per,
        'from'     => $from,
        'to'       => $to,
    ) );
}

/** Copied verbatim from admin/pages/reports.php:18. */
function ridego_app_admin_api_reports_trip_types( WP_REST_Request $req ) {
    global $wpdb;
    $btbl = $wpdb->prefix . 'ridego_bookings';
    list( $from, $to ) = ridego_app_admin_api_reports_date_range( $req );

    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT trip_type, COUNT(*) as cnt, COALESCE(SUM(total_fare),0) as rev, COALESCE(SUM(advance_paid),0) as col
         FROM {$btbl} WHERE DATE(created_at) BETWEEN %s AND %s GROUP BY trip_type ORDER BY cnt DESC",
        $from, $to
    ) );

    $out = array_map( function ( $r ) {
        return array(
            'trip_type' => $r->trip_type,
            'bookings'  => (int) $r->cnt,
            'revenue'   => (float) $r->rev,
            'collected' => (float) $r->col,
        );
    }, $rows );

    return rest_ensure_response( array( 'rows' => $out, 'from' => $from, 'to' => $to ) );
}

/** Copied verbatim from admin/pages/reports.php:19 (completed-only, top 10 by count). */
function ridego_app_admin_api_reports_top_routes( WP_REST_Request $req ) {
    global $wpdb;
    $btbl = $wpdb->prefix . 'ridego_bookings';
    list( $from, $to ) = ridego_app_admin_api_reports_date_range( $req );

    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT pickup_city, drop_city, COUNT(*) as cnt, COALESCE(SUM(total_fare),0) as rev, COALESCE(SUM(advance_paid),0) as col
         FROM {$btbl} WHERE DATE(created_at) BETWEEN %s AND %s AND status='completed'
         GROUP BY pickup_city, drop_city ORDER BY cnt DESC LIMIT 10",
        $from, $to
    ) );

    $out = array_map( function ( $r ) {
        return array(
            'pickup_city' => $r->pickup_city,
            'drop_city'   => $r->drop_city,
            'bookings'    => (int) $r->cnt,
            'revenue'     => (float) $r->rev,
            'collected'   => (float) $r->col,
        );
    }, $rows );

    return rest_ensure_response( array( 'rows' => $out, 'from' => $from, 'to' => $to ) );
}
