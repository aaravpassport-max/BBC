<?php
/**
 * Vendor Lead Fee: the ONE central calculation and terms layer.
 *
 * Configuration (versioned commercial terms rows + a few settings) -> this file -> every screen, API, notification, report and ledger entry.
 * Nothing outside this file knows what 10%, a minimum, or a method is. Callers ask ridego_lead_fee_for() / ridego_lead_fee_for_booking() and show what comes back.
 *
 * Money vocabulary (kept apart on purpose):
 *   expected booking amount   the estimated ride fare (ridego_bookings.total_fare), the base the fee is calculated on
 *   customer advance          what the client pays RideGo up front (ridego_bookings.token_amount / advance_paid), configured separately in Settings
 *   vendor lead fee           what the vendor/driver owes RideGo for the trip (ridego_bookings.vendor_lead_fee), calculated here
 *   payable to RideGo         lead fee minus the part already covered by the customer advance (only when "apply advance to lead fee" is on)
 * Only facilitator bookings (platform_model = 1) use this. Legacy bookings keep the old wallet lead fee and commission model.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: nothing → the calculation methods an admin can pick → array key => label. Pure.
function ridego_lead_fee_methods() {
    return array(
        'fixed'                => 'Fixed amount',
        'percentage'           => 'Percentage of the expected booking amount',
        'higher_of'            => 'Minimum amount or percentage, whichever is higher',
        'percentage_min'       => 'Percentage with a minimum',
        'percentage_min_max'   => 'Percentage with a minimum and a maximum',
        'none'                 => 'No lead fee',
    );
}

// TRACE: nothing → the services a rule can be limited to (the booking trip types) → array key => label. Pure.
function ridego_lead_fee_services() {
    return array( 'one_way' => 'One way', 'round_trip' => 'Round trip', 'local' => 'Local / hourly', 'airport' => 'Airport', 'outstation' => 'Outstation' );
}

// TRACE: nothing → the factory-default global rule (the only place these numbers exist; seeded once by migration 27 and used as a safety net if every global row is deleted) → array. Pure.
function ridego_lead_fee_builtin_defaults() {
    return array( 'method' => 'higher_of', 'percentage' => 10.0, 'fixed_amount' => 0.0, 'min_amount' => 300.0, 'max_amount' => 0.0 );
}

// TRACE: nothing → the settings that shape the engine, with defaults → array( enabled, offset_advance, cap_at_amount, require_acceptance, customer_advance_enabled ) of bool. Reads settings.
function ridego_lead_fee_options() {
    $on = function ( $k, $d ) { $v = ridego_get_setting( $k, null ); return $v === null || $v === '' ? (bool) $d : (bool) (int) $v; };
    return array(
        'enabled'                  => $on( 'lead_fee_enabled', 1 ),
        'offset_advance'           => $on( 'lead_fee_offset_advance', 1 ),
        'cap_at_amount'            => $on( 'lead_fee_cap_at_amount', 1 ),
        'require_acceptance'       => $on( 'lead_fee_require_acceptance', 0 ),
        'customer_advance_enabled' => $on( 'customer_advance_enabled', 1 ),
    );
}

// TRACE: any float → rupees rounded to 2 decimals, half-up, after removing binary float noise (so 12.345 → 12.35 and 0.1+0.2 → 0.30) → float. The ONE rounding rule for lead fees. Pure.
function ridego_lead_fee_round( $x ) {
    return round( round( (float) $x, 6 ), 2, PHP_ROUND_HALF_UP );
}

// TRACE: terms row/array (method, percentage, fixed_amount, min_amount, max_amount) → sanitised numbers → array. Pure. Edge cases: missing keys → 0, negatives → 0, percentage above 100 → 100.
function ridego_lead_fee_norm_params( $t ) {
    $t = (array) $t;
    return array(
        'method'       => isset( $t['method'] ) && isset( ridego_lead_fee_methods()[ $t['method'] ] ) ? (string) $t['method'] : 'none',
        'percentage'   => max( 0.0, min( 100.0, (float) ( $t['percentage'] ?? 0 ) ) ),
        'fixed_amount' => max( 0.0, (float) ( $t['fixed_amount'] ?? 0 ) ),
        'min_amount'   => max( 0.0, (float) ( $t['min_amount'] ?? 0 ) ),
        'max_amount'   => max( 0.0, (float) ( $t['max_amount'] ?? 0 ) ),
    );
}

// TRACE: expected booking amount + terms params + cap flag → the fee and how it was reached → array(fee, pct_fee, min_fee, max_fee, capped, formula). PURE (no DB): used by the live preview, tests and by ridego_lead_fee_for().
//        fixed → fixed_amount. percentage → base × % . higher_of / percentage_min → max(min, base × %). percentage_min_max → min(max, max(min, base × %)) (max 0 = no maximum). none → 0.
//        Every percentage result is rounded half-up to 2 dp; if the cap flag is on the fee can never exceed the booking amount itself (tiny fares); base ≤ 0 → fee 0.
function ridego_lead_fee_compute( $base, $params, $cap_at_amount = true ) {
    $p = ridego_lead_fee_norm_params( $params );
    $base = max( 0.0, (float) $base );
    $pct_fee = ridego_lead_fee_round( $base * $p['percentage'] / 100 );
    $fee = 0.0; $formula = 'No lead fee';
    switch ( $p['method'] ) {
        case 'fixed':
            $fee = ridego_lead_fee_round( $p['fixed_amount'] ); $formula = 'Fixed ₹' . $fee; break;
        case 'percentage':
            $fee = $pct_fee; $formula = rtrim( rtrim( number_format( $p['percentage'], 3, '.', '' ), '0' ), '.' ) . '% of ₹' . ridego_lead_fee_round( $base ); break;
        case 'higher_of':
        case 'percentage_min':
            $fee = max( ridego_lead_fee_round( $p['min_amount'] ), $pct_fee );
            $formula = 'Higher of ₹' . ridego_lead_fee_round( $p['min_amount'] ) . ' and ' . rtrim( rtrim( number_format( $p['percentage'], 3, '.', '' ), '0' ), '.' ) . '% of ₹' . ridego_lead_fee_round( $base ); break;
        case 'percentage_min_max':
            $fee = max( ridego_lead_fee_round( $p['min_amount'] ), $pct_fee );
            if ( $p['max_amount'] > 0 ) { $fee = min( $fee, ridego_lead_fee_round( $p['max_amount'] ) ); }
            $formula = rtrim( rtrim( number_format( $p['percentage'], 3, '.', '' ), '0' ), '.' ) . '% of ₹' . ridego_lead_fee_round( $base ) . ', at least ₹' . ridego_lead_fee_round( $p['min_amount'] ) . ( $p['max_amount'] > 0 ? ', at most ₹' . ridego_lead_fee_round( $p['max_amount'] ) : '' ); break;
        default:
            $fee = 0.0;
    }
    $capped = false;
    if ( $base <= 0 ) { $fee = 0.0; }
    elseif ( $cap_at_amount && $fee > $base ) { $fee = ridego_lead_fee_round( $base ); $capped = true; }
    return array( 'fee' => ridego_lead_fee_round( $fee ), 'pct_fee' => $pct_fee, 'min_fee' => ridego_lead_fee_round( $p['min_amount'] ), 'max_fee' => ridego_lead_fee_round( $p['max_amount'] ), 'capped' => $capped, 'formula' => $formula );
}

// TRACE: vendor id (0 = none) + service key ('' = any) + MySQL datetime (null = now) → the terms row that applies → object|null.
//        Candidates are active rows in effect at that time. Priority: this vendor's rule for this exact service, this vendor's all-services rule, the global rule for this service, the global all-services rule; ties → newest effective_from, then newest id.
//        A vendor rule with method 'none' is a real rule (that vendor pays no lead fee). Edge cases: no table yet → null.
function ridego_lead_fee_resolve_terms( $vendor_id = 0, $service = '', $at = null ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_lead_fee_terms';
    $at = $at ?: current_time( 'mysql' );
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$t} WHERE status='active' AND effective_from<=%s AND (effective_until IS NULL OR effective_until>%s) AND (scope='global' OR (scope='vendor' AND vendor_id=%d)) ORDER BY effective_from DESC, id DESC", $at, $at, (int) $vendor_id ) );
    if ( ! $rows ) { return null; }
    $best = null; $best_rank = -1;
    foreach ( $rows as $r ) {
        $svcs = array_filter( array_map( 'trim', explode( ',', (string) $r->service_scope ) ) );
        if ( $svcs && ( $service === '' || ! in_array( $service, $svcs, true ) ) ) { continue; }
        $rank = ( $r->scope === 'vendor' ? 2 : 0 ) + ( $svcs ? 1 : 0 );
        if ( $rank > $best_rank ) { $best = $r; $best_rank = $rank; }
    }
    return $best;
}

// TRACE: expected booking amount + vendor id + service + time → THE lead-fee answer every caller uses → array(enabled, fee, base_amount, service, source, terms_id, terms_version, scope, params, breakdown, formula, calculated_at, cap_at_amount, offset_advance).
//        source: 'vendor' | 'global' | 'default' (built-in safety net) | 'disabled' (master switch off) | 'no_terms'. Reads terms + options; writes nothing. Edge cases: master switch off → fee 0; no rule at all → built-in default; 'none' method → fee 0.
function ridego_lead_fee_for( $base, $vendor_id = 0, $service = '', $at = null ) {
    $opt = ridego_lead_fee_options();
    $base = max( 0.0, (float) $base );
    $out = array( 'enabled' => $opt['enabled'], 'fee' => 0.0, 'base_amount' => ridego_lead_fee_round( $base ), 'service' => (string) $service, 'source' => 'disabled', 'terms_id' => null, 'terms_version' => null, 'scope' => null,
        'params' => ridego_lead_fee_norm_params( array() ), 'breakdown' => array( 'pct_fee' => 0.0, 'min_fee' => 0.0, 'max_fee' => 0.0, 'capped' => false ), 'formula' => 'Lead fee is switched off',
        'calculated_at' => $at ?: current_time( 'mysql' ), 'cap_at_amount' => $opt['cap_at_amount'], 'offset_advance' => $opt['offset_advance'] );
    if ( ! $opt['enabled'] ) { return $out; }
    $terms = ridego_lead_fee_resolve_terms( (int) $vendor_id, (string) $service, $at );
    if ( $terms ) {
        $params = ridego_lead_fee_norm_params( $terms ); $src = $terms->scope === 'vendor' ? 'vendor' : 'global';
        $out['terms_id'] = (int) $terms->id; $out['terms_version'] = (int) $terms->version; $out['scope'] = (string) $terms->scope;
    } else {
        $params = ridego_lead_fee_norm_params( ridego_lead_fee_builtin_defaults() ); $src = 'default';
    }
    $c = ridego_lead_fee_compute( $base, $params, $opt['cap_at_amount'] );
    $out['source'] = $src; $out['params'] = $params; $out['fee'] = $c['fee']; $out['formula'] = $c['formula'];
    $out['breakdown'] = array( 'pct_fee' => $c['pct_fee'], 'min_fee' => $c['min_fee'], 'max_fee' => $c['max_fee'], 'capped' => $c['capped'] );
    return $out;
}

// TRACE: booking row + optional vendor id (default the booking's own vendor) → ridego_lead_fee_for() on the booking's expected amount (total_fare) and trip type. Facilitator bookings only: legacy → fee 0, source 'legacy'.
function ridego_lead_fee_for_booking( $b, $vendor_id = null ) {
    if ( is_numeric( $b ) ) { $b = ridego_get_booking( (int) $b ); }
    if ( ! $b || empty( $b->platform_model ) ) {
        $r = ridego_lead_fee_for( 0, 0, '' ); $r['source'] = 'legacy'; $r['fee'] = 0.0; $r['formula'] = 'Legacy booking: old lead-fee rules apply'; return $r;
    }
    $vid = $vendor_id === null ? (int) $b->vendor_id : (int) $vendor_id;
    return ridego_lead_fee_for( (float) $b->total_fare, $vid, (string) $b->trip_type );
}

// TRACE: fee + customer advance received + offset flag → how the advance and the fee net out → array(applied, payable, excess). Pure.
//        Offset on: applied = min(advance, fee); payable = fee − applied (the vendor still owes RideGo); excess = advance − applied (RideGo owes the vendor). Offset off: applied 0, payable = fee, excess = the whole advance.
function ridego_lead_fee_split( $fee, $advance, $offset ) {
    $fee = max( 0.0, (float) $fee ); $adv = max( 0.0, (float) $advance );
    $applied = $offset ? min( $adv, $fee ) : 0.0;
    return array( 'applied' => ridego_lead_fee_round( $applied ), 'payable' => ridego_lead_fee_round( $fee - $applied ), 'excess' => ridego_lead_fee_round( $adv - $applied ) );
}

// TRACE: calculation result (ridego_lead_fee_for output) → compact JSON string stored on the lead / booking so history never re-calculates → string.
function ridego_lead_fee_snapshot_json( $calc ) {
    $keep = array( 'fee', 'base_amount', 'service', 'source', 'terms_id', 'terms_version', 'scope', 'params', 'breakdown', 'formula', 'calculated_at', 'cap_at_amount', 'offset_advance' );
    $o = array(); foreach ( $keep as $k ) { $o[ $k ] = $calc[ $k ] ?? null; }
    return wp_json_encode( $o );
}

// TRACE: JSON snapshot string → array (empty array when blank/invalid). Pure.
function ridego_lead_fee_snapshot_decode( $json ) {
    $a = $json ? json_decode( (string) $json, true ) : null;
    return is_array( $a ) ? $a : array();
}

// TRACE: vendor + terms row + source → records that the vendor accepted these commercial terms (terms id + version + time + who + a copy of the numbers) → int id | 0.
//        Idempotent per (vendor, terms id, source-agnostic): a second call for the same vendor and terms returns the existing id. Edge cases: unknown vendor/terms → 0.
function ridego_lead_fee_record_acceptance( $vendor_id, $terms, $source = 'vendor', $user_id = 0 ) {
    global $wpdb;
    if ( ! $terms || ! (int) $vendor_id ) { return 0; }
    $t = $wpdb->prefix . 'ridego_vendor_terms_acceptance';
    $ex = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE vendor_id=%d AND terms_id=%d LIMIT 1", (int) $vendor_id, (int) $terms->id ) );
    if ( $ex ) { return (int) $ex; }
    $ok = $wpdb->insert( $t, array( 'vendor_id' => (int) $vendor_id, 'terms_id' => (int) $terms->id, 'terms_version' => (int) $terms->version, 'root_id' => (int) $terms->root_id, 'source' => substr( sanitize_key( $source ), 0, 20 ),
        'accepted_by' => (int) $user_id, 'accepted_at' => current_time( 'mysql' ), 'terms_snapshot' => wp_json_encode( array_intersect_key( (array) $terms, array_flip( array( 'scope', 'service_scope', 'method', 'percentage', 'fixed_amount', 'min_amount', 'max_amount', 'effective_from', 'effective_until', 'version' ) ) ) ) ) );
    if ( ! $ok ) { ridego_log( 'lead fee acceptance insert failed: ' . $wpdb->last_error ); return 0; }
    return (int) $wpdb->insert_id;
}

// TRACE: vendor id + service → has the vendor accepted the terms that currently apply to them → array(applies, terms_id, version, accepted, accepted_at, source). Reads only.
function ridego_lead_fee_vendor_acceptance_state( $vendor_id, $service = '' ) {
    global $wpdb;
    $terms = ridego_lead_fee_resolve_terms( (int) $vendor_id, $service );
    if ( ! $terms ) { return array( 'applies' => false, 'terms_id' => null, 'version' => null, 'accepted' => true, 'accepted_at' => null, 'source' => null ); }
    $a = $wpdb->get_row( $wpdb->prepare( "SELECT accepted_at, source FROM {$wpdb->prefix}ridego_vendor_terms_acceptance WHERE vendor_id=%d AND terms_id=%d ORDER BY id DESC LIMIT 1", (int) $vendor_id, (int) $terms->id ) );
    return array( 'applies' => true, 'terms_id' => (int) $terms->id, 'version' => (int) $terms->version, 'accepted' => (bool) $a, 'accepted_at' => $a ? $a->accepted_at : null, 'source' => $a ? $a->source : null );
}

// TRACE: booking id + vendor id + lead row (optional) → fixes the vendor lead fee onto the booking at the moment a vendor is assigned (self-accept or admin assign) → array|null (the snapshot calc).
//        If the vendor's lead row already carries a snapshot from when the lead was generated it is copied (history keeps the terms of that moment), otherwise the fee is calculated now.
//        Idempotent: a booking already locked for the same vendor is left untouched; a different vendor gets a fresh calculation. Records the vendor's acceptance of those terms.
//        Preconditions: booking is a facilitator booking. Edge cases: legacy booking → null; write failure → logged, null.
function ridego_lead_fee_lock_for_booking( $booking_id, $vendor_id, $lead = null ) {
    global $wpdb;
    $bt = $wpdb->prefix . 'ridego_bookings';
    $b = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$bt} WHERE id=%d", (int) $booking_id ) );
    if ( ! $b || empty( $b->platform_model ) || ! (int) $vendor_id ) { return null; }
    if ( ! empty( $b->vendor_lead_fee_locked_at ) && (int) $b->vendor_id === (int) $vendor_id && $b->vendor_lead_fee_snapshot ) { return ridego_lead_fee_snapshot_decode( $b->vendor_lead_fee_snapshot ); }
    $snap = array();
    if ( $lead && ! empty( $lead->lf_snapshot ) && (int) $lead->vendor_id === (int) $vendor_id ) { $snap = ridego_lead_fee_snapshot_decode( $lead->lf_snapshot ); }
    if ( ! $snap ) { $snap = ridego_lead_fee_snapshot_decode( ridego_lead_fee_snapshot_json( ridego_lead_fee_for_booking( $b, (int) $vendor_id ) ) ); }
    $fee = ridego_lead_fee_round( (float) ( $snap['fee'] ?? 0 ) );
    $status = $fee > 0 ? 'locked' : 'none';
    $ok = $wpdb->update( $bt, array( 'vendor_lead_fee' => $fee, 'vendor_lead_fee_status' => $status, 'vendor_lead_fee_terms_id' => ! empty( $snap['terms_id'] ) ? (int) $snap['terms_id'] : null,
        'vendor_lead_fee_snapshot' => wp_json_encode( $snap ), 'vendor_lead_fee_locked_at' => current_time( 'mysql' ) ), array( 'id' => (int) $booking_id ) );
    if ( $ok === false ) { ridego_log( 'lead fee lock failed for booking ' . (int) $booking_id . ': ' . $wpdb->last_error ); return null; }
    if ( ! empty( $snap['terms_id'] ) ) {
        $terms = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_lead_fee_terms WHERE id=%d", (int) $snap['terms_id'] ) );
        $vend = ridego_get_vendor( (int) $vendor_id );
        if ( $terms ) { ridego_lead_fee_record_acceptance( (int) $vendor_id, $terms, 'lead_accept', $vend ? (int) $vend->user_id : 0 ); }
    }
    return $snap;
}

// TRACE: booking row → one consistent lead-fee view used by every API (admin, vendor, reports, receipts) → array. Reads the locked snapshot when a vendor is assigned, otherwise an estimate from the global rule.
//        Keys: applies, is_estimate, amount, status, status_label, base_amount, method, method_label, formula, terms_id, terms_version, source, customer_advance_received, applied_from_advance, payable_to_ridego, excess_advance_owed_to_vendor, locked_at.
//        Legacy booking → applies false, everything 0. Cancelled/expired → status 'cancelled', payable 0.
function ridego_lead_fee_view( $b ) {
    $labels = array( 'not_applicable' => 'Not applicable', 'estimated' => 'Estimated', 'none' => 'No lead fee', 'locked' => 'Confirmed, due after the trip', 'due' => 'Due to ' . ridego_brand_name() . '', 'settled' => 'Settled', 'waived' => 'Waived', 'cancelled' => 'Cancelled' );
    $blank = array( 'applies' => false, 'is_estimate' => false, 'amount' => 0.0, 'status' => 'not_applicable', 'status_label' => $labels['not_applicable'], 'base_amount' => 0.0, 'method' => '', 'method_label' => '', 'formula' => '', 'terms_id' => null,
        'terms_version' => null, 'source' => 'legacy', 'customer_advance_received' => 0.0, 'applied_from_advance' => 0.0, 'payable_to_ridego' => 0.0, 'excess_advance_owed_to_vendor' => 0.0, 'locked_at' => null,
        'forfeit_to' => '', 'forfeit_amount' => 0.0, 'forfeit_reason' => '', 'forfeit_paid' => false );
    if ( ! $b || empty( $b->platform_model ) ) { return $blank; }
    $locked = ! empty( $b->vendor_lead_fee_locked_at ) && $b->vendor_lead_fee_snapshot;
    $snap = $locked ? ridego_lead_fee_snapshot_decode( $b->vendor_lead_fee_snapshot ) : ridego_lead_fee_snapshot_decode( ridego_lead_fee_snapshot_json( ridego_lead_fee_for_booking( $b, 0 ) ) );
    $fee = $locked ? ridego_lead_fee_round( (float) $b->vendor_lead_fee ) : ridego_lead_fee_round( (float) ( $snap['fee'] ?? 0 ) );
    $closed = in_array( $b->status, array( 'cancelled', 'expired', 'token_refund_due' ), true );
    $status = $locked ? (string) $b->vendor_lead_fee_status : 'estimated';
    if ( $status === '' ) { $status = $locked ? ( $fee > 0 ? 'locked' : 'none' ) : 'estimated'; }
    if ( $closed && $status !== 'waived' ) { $status = 'cancelled'; }
    if ( ! $locked && $fee <= 0 ) { $status = 'none'; }
    $adv = max( 0.0, (float) $b->advance_paid );
    $offset = array_key_exists( 'offset_advance', $snap ) && $snap['offset_advance'] !== null ? (bool) $snap['offset_advance'] : ridego_lead_fee_options()['offset_advance'];
    $split = ridego_lead_fee_split( in_array( $status, array( 'cancelled', 'waived' ), true ) ? 0 : $fee, $adv, $offset );
    $payable = $split['payable'];
    if ( $status === 'settled' ) { $payable = 0.0; }
    $forfeit = array( 'forfeit_to' => '', 'forfeit_amount' => 0.0, 'forfeit_reason' => '', 'forfeit_paid' => false );
    if ( $b->status === 'cancelled' && ! empty( $b->vendor_id ) && ridego_calc_cancel_penalty( $b ) > 0 ) {
        global $wpdb;
        $paid = $b->cancel_forfeit_to === 'vendor' && (string) $wpdb->get_var( $wpdb->prepare( "SELECT status FROM {$wpdb->prefix}ridego_booking_ledger WHERE dedupe_key=%s", 'forfeit:' . (int) $b->id ) ) === 'settled';
        $forfeit = array( 'forfeit_to' => (string) $b->cancel_forfeit_to, // '' = the admin has not decided yet
             'forfeit_amount' => ridego_lead_fee_round( (float) ridego_calc_cancel_penalty( $b ) ), 'forfeit_reason' => (string) $b->cancel_forfeit_reason, 'forfeit_paid' => $paid );
    }
    $method = (string) ( $snap['params']['method'] ?? '' );
    return array( 'applies' => true, 'is_estimate' => ! $locked, 'amount' => in_array( $status, array( 'waived', 'cancelled' ), true ) ? 0.0 : $fee, 'status' => $status, 'status_label' => $labels[ $status ] ?? $status, 'base_amount' => (float) ( $snap['base_amount'] ?? $b->total_fare ),
        'method' => $method, 'method_label' => ridego_lead_fee_methods()[ $method ] ?? '', 'formula' => (string) ( $snap['formula'] ?? '' ), 'terms_id' => $snap['terms_id'] ?? null, 'terms_version' => $snap['terms_version'] ?? null,
        'source' => (string) ( $snap['source'] ?? '' ), 'customer_advance_received' => ridego_lead_fee_round( $adv ), 'applied_from_advance' => $split['applied'], 'payable_to_ridego' => $payable, 'excess_advance_owed_to_vendor' => $split['excess'], 'locked_at' => $locked ? $b->vendor_lead_fee_locked_at : null ) + $forfeit;
}

// TRACE: booking id → recomputes and stores vendor_lead_fee_status from the ledger (completed: 'due' while a pending lead_fee row exists, else 'settled'; cancelled → 'cancelled'; waived stays waived) → string status.
//        Called after lock, completion, settlement, cancellation, waive. Edge cases: not locked → '' (nothing stored); write failure logged.
function ridego_lead_fee_sync_status( $booking_id ) {
    global $wpdb;
    $bt = $wpdb->prefix . 'ridego_bookings';
    $b = $wpdb->get_row( $wpdb->prepare( "SELECT id, status, vendor_lead_fee, vendor_lead_fee_status, vendor_lead_fee_locked_at, platform_model FROM {$bt} WHERE id=%d", (int) $booking_id ) );
    if ( ! $b || empty( $b->platform_model ) || empty( $b->vendor_lead_fee_locked_at ) ) { return ''; }
    if ( $b->vendor_lead_fee_status === 'waived' ) { return 'waived'; }
    $new = (float) $b->vendor_lead_fee > 0 ? 'locked' : 'none';
    if ( in_array( $b->status, array( 'cancelled', 'expired', 'token_refund_due' ), true ) ) { $new = 'cancelled'; }
    elseif ( $b->status === 'completed' && (float) $b->vendor_lead_fee > 0 ) {
        $pending = (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount),0) FROM {$wpdb->prefix}ridego_booking_ledger WHERE booking_id=%d AND entry_type='lead_fee' AND status='pending'", (int) $booking_id ) );
        $new = $pending > 0.004 ? 'due' : 'settled';
    }
    if ( $new !== $b->vendor_lead_fee_status ) {
        $r = $wpdb->update( $bt, array( 'vendor_lead_fee_status' => $new ), array( 'id' => (int) $booking_id ) );
        if ( $r === false ) { ridego_log( 'lead fee status sync failed for booking ' . (int) $booking_id . ': ' . $wpdb->last_error ); }
    }
    return $new;
}

// TRACE: terms input (admin form) → validated, normalised row values → array('ok','error','data'). Pure apart from vendor existence lookups.
//        Rules: valid method; percentage 0-100 and > 0 for the percentage methods; fixed amount > 0 for 'fixed'; min ≥ 0; percentage_min_max needs max ≥ min when a max is set; services must be known keys; effective_from a valid date (default now); until after from; scope vendor needs an existing vendor.
function ridego_lead_fee_validate_terms( $in ) {
    $m = isset( $in['method'] ) ? sanitize_key( (string) $in['method'] ) : '';
    if ( ! isset( ridego_lead_fee_methods()[ $m ] ) ) { return array( 'ok' => false, 'error' => 'Choose a calculation method.' ); }
    foreach ( array( 'percentage', 'fixed_amount', 'min_amount', 'max_amount' ) as $k ) {
        if ( isset( $in[ $k ] ) && $in[ $k ] !== '' && ( ! is_numeric( $in[ $k ] ) || (float) $in[ $k ] < 0 ) ) { return array( 'ok' => false, 'error' => 'Amounts and percentages must be numbers of zero or more.' ); }
    }
    $pct = (float) ( $in['percentage'] ?? 0 ); $fix = (float) ( $in['fixed_amount'] ?? 0 ); $min = (float) ( $in['min_amount'] ?? 0 ); $max = (float) ( $in['max_amount'] ?? 0 );
    if ( $pct > 100 ) { return array( 'ok' => false, 'error' => 'Percentage cannot be more than 100.' ); }
    $uses_pct = in_array( $m, array( 'percentage', 'higher_of', 'percentage_min', 'percentage_min_max' ), true );
    if ( $uses_pct && $pct <= 0 ) { return array( 'ok' => false, 'error' => 'Enter a percentage greater than 0.' ); }
    if ( $m === 'fixed' && $fix <= 0 ) { return array( 'ok' => false, 'error' => 'Enter a fixed amount greater than 0.' ); }
    if ( in_array( $m, array( 'higher_of', 'percentage_min', 'percentage_min_max' ), true ) && $min <= 0 ) { return array( 'ok' => false, 'error' => 'Enter a minimum fee greater than 0 for this method.' ); }
    if ( $m === 'percentage_min_max' && $max > 0 && $max < $min ) { return array( 'ok' => false, 'error' => 'The maximum fee cannot be lower than the minimum fee.' ); }
    $svc = isset( $in['services'] ) ? ( is_array( $in['services'] ) ? $in['services'] : explode( ',', (string) $in['services'] ) ) : array();
    $svc = array_values( array_unique( array_filter( array_map( 'sanitize_key', $svc ) ) ) );
    foreach ( $svc as $s ) { if ( ! isset( ridego_lead_fee_services()[ $s ] ) ) { return array( 'ok' => false, 'error' => 'Unknown service: ' . $s . '.' ); } }
    $from = ! empty( $in['effective_from'] ) ? strtotime( (string) $in['effective_from'] ) : time();
    if ( ! $from ) { return array( 'ok' => false, 'error' => 'Effective date is not a valid date.' ); }
    $until = ! empty( $in['effective_until'] ) ? strtotime( (string) $in['effective_until'] ) : null;
    if ( ! empty( $in['effective_until'] ) && ! $until ) { return array( 'ok' => false, 'error' => 'End date is not a valid date.' ); }
    if ( $until && $until <= $from ) { return array( 'ok' => false, 'error' => 'The end date must be after the effective date.' ); }
    $scope = ( isset( $in['scope'] ) && $in['scope'] === 'vendor' ) ? 'vendor' : 'global';
    $vid = $scope === 'vendor' ? (int) ( $in['vendor_id'] ?? 0 ) : 0;
    if ( $scope === 'vendor' && ( ! $vid || ! ridego_get_vendor( $vid ) ) ) { return array( 'ok' => false, 'error' => 'Choose an existing vendor.' ); }
    $data = array( 'scope' => $scope, 'vendor_id' => $scope === 'vendor' ? $vid : null, 'service_scope' => implode( ',', $svc ), 'method' => $m,
        'percentage' => $uses_pct ? $pct : 0, 'fixed_amount' => $m === 'fixed' ? $fix : 0, 'min_amount' => in_array( $m, array( 'higher_of', 'percentage_min', 'percentage_min_max' ), true ) ? $min : 0, 'max_amount' => $m === 'percentage_min_max' ? $max : 0,
        'effective_from' => wp_date( 'Y-m-d H:i:s', $from ), 'effective_until' => $until ? wp_date( 'Y-m-d H:i:s', $until ) : null, 'status' => ( isset( $in['status'] ) && $in['status'] === 'inactive' ) ? 'inactive' : 'active', 'notes' => mb_substr( sanitize_text_field( (string) ( $in['notes'] ?? '' ) ), 0, 255 ) );
    return array( 'ok' => true, 'error' => '', 'data' => $data );
}

// TRACE: validated terms input + optional id of the row being changed + actor → saves a NEW versioned row and closes the previous version (never edits history in place) → array(success,id,message).
//        New row: version = old version + 1, same root_id, supersedes_id = old id. Old row gets effective_until = the new row's effective_from (never earlier than its own start). Runs in a transaction; audit-logged.
//        Vendor-scoped rows: a vendor may have only one active rule per service set at a time, enforced by the same close-the-previous logic when the ids match.
//        Edge cases: invalid input → message; unknown id → message; insert failure → rollback + message.
function ridego_lead_fee_terms_save( $in, $id = 0, $actor_id = 0 ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_lead_fee_terms';
    $v = ridego_lead_fee_validate_terms( $in );
    if ( ! $v['ok'] ) { return array( 'success' => false, 'message' => $v['error'] ); }
    $row = $v['data'];
    $old = null;
    if ( $id ) {
        $old = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", (int) $id ) );
        if ( ! $old ) { return array( 'success' => false, 'message' => 'That rule no longer exists.' ); }
        $row['scope'] = $old->scope; $row['vendor_id'] = $old->vendor_id;
    }
    $row['version'] = $old ? (int) $old->version + 1 : 1;
    $row['supersedes_id'] = $old ? (int) $old->id : null;
    $row['created_by'] = (int) $actor_id;
    $row['created_at'] = current_time( 'mysql' );
    $wpdb->query( 'START TRANSACTION' );
    if ( $old ) {
        $close = strtotime( $row['effective_from'] ) > strtotime( $old->effective_from ) ? $row['effective_from'] : current_time( 'mysql' );
        $r = $wpdb->update( $t, array( 'effective_until' => $close ), array( 'id' => (int) $old->id ) );
        if ( $r === false ) { $wpdb->query( 'ROLLBACK' ); return array( 'success' => false, 'message' => 'Could not close the previous version.' ); }
        if ( strtotime( $row['effective_from'] ) <= strtotime( $old->effective_from ) ) { $row['effective_from'] = $close; }
    }
    $ok = $wpdb->insert( $t, $row );
    if ( ! $ok ) { $wpdb->query( 'ROLLBACK' ); ridego_log( 'lead fee terms insert failed: ' . $wpdb->last_error ); return array( 'success' => false, 'message' => 'Could not save the commercial terms.' ); }
    $new_id = (int) $wpdb->insert_id;
    $root = $old ? (int) $old->root_id : $new_id;
    $wpdb->update( $t, array( 'root_id' => $root ), array( 'id' => $new_id ) );
    $wpdb->query( 'COMMIT' );
    ridego_audit_log( $old ? 'lead_fee_terms_changed' : 'lead_fee_terms_created', 'lead_fee_terms', $new_id, $old ? wp_json_encode( array( 'id' => (int) $old->id, 'method' => $old->method, 'percentage' => $old->percentage, 'min' => $old->min_amount, 'max' => $old->max_amount, 'fixed' => $old->fixed_amount ) ) : '', wp_json_encode( $row ) );
    return array( 'success' => true, 'id' => $new_id, 'message' => $old ? 'Saved as version ' . $row['version'] . '. Bookings and leads already created keep their earlier terms.' : 'Commercial terms created.' );
}

// TRACE: terms id + actor → turns a rule off (status inactive, effective_until now) without deleting it → array(success,message). Global rule: refused when it is the only active global rule (the platform must always have a default). Audit-logged.
function ridego_lead_fee_terms_deactivate( $id, $actor_id = 0 ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_lead_fee_terms';
    $r = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", (int) $id ) );
    if ( ! $r ) { return array( 'success' => false, 'message' => 'That rule no longer exists.' ); }
    if ( $r->status === 'inactive' ) { return array( 'success' => true, 'message' => 'Already inactive.' ); }
    if ( $r->scope === 'global' && trim( (string) $r->service_scope ) === '' ) {
        $others = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE scope='global' AND service_scope='' AND status='active' AND id<>%d AND (effective_until IS NULL OR effective_until>%s)", (int) $id, current_time( 'mysql' ) ) );
        if ( $others < 1 ) { return array( 'success' => false, 'message' => 'This is the platform default. Change its values instead, or add another default first.' ); }
    }
    $u = $wpdb->update( $t, array( 'status' => 'inactive', 'effective_until' => current_time( 'mysql' ) ), array( 'id' => (int) $id ) );
    if ( $u === false ) { return array( 'success' => false, 'message' => 'Could not switch the rule off.' ); }
    ridego_audit_log( 'lead_fee_terms_deactivated', 'lead_fee_terms', (int) $id, 'active', 'inactive' );
    return array( 'success' => true, 'message' => 'Rule switched off. Existing bookings keep their fee.' );
}

// TRACE: booking id + action ('recalculate' | 'waive') + reason + actor → admin correction of a not-yet-billed lead fee → array(success,message).
//        Only before the trip is completed (once ledger rows exist the fee is posted and cannot be changed here). Reason is required. recalculate re-runs the engine with today's terms; waive sets the fee to 0 and status 'waived'. Audit-logged.
function ridego_lead_fee_admin_adjust( $booking_id, $action, $reason, $actor_id = 0 ) {
    global $wpdb;
    $bt = $wpdb->prefix . 'ridego_bookings';
    $b = ridego_get_booking( (int) $booking_id );
    if ( ! $b || empty( $b->platform_model ) ) { return array( 'success' => false, 'message' => 'Lead fees apply to facilitator bookings only.' ); }
    if ( empty( $b->vendor_id ) ) { return array( 'success' => false, 'message' => 'No vendor is assigned yet, so no lead fee has been fixed. It will be calculated when a vendor is assigned.' ); }
    if ( in_array( $b->status, array( 'completed', 'cancelled', 'expired', 'token_refund_due' ), true ) ) { return array( 'success' => false, 'message' => 'The lead fee can no longer be changed for a completed or cancelled booking.' ); }
    $reason = trim( sanitize_text_field( (string) $reason ) );
    if ( $reason === '' ) { return array( 'success' => false, 'message' => 'Enter a reason.' ); }
    if ( $action === 'waive' ) {
        $r = $wpdb->update( $bt, array( 'vendor_lead_fee' => 0, 'vendor_lead_fee_status' => 'waived' ), array( 'id' => (int) $booking_id ) );
    } elseif ( $action === 'recalculate' ) {
        $calc = ridego_lead_fee_for_booking( $b, (int) $b->vendor_id );
        $r = $wpdb->update( $bt, array( 'vendor_lead_fee' => $calc['fee'], 'vendor_lead_fee_status' => $calc['fee'] > 0 ? 'locked' : 'none', 'vendor_lead_fee_terms_id' => $calc['terms_id'],
            'vendor_lead_fee_snapshot' => ridego_lead_fee_snapshot_json( $calc ), 'vendor_lead_fee_locked_at' => current_time( 'mysql' ) ), array( 'id' => (int) $booking_id ) );
    } else { return array( 'success' => false, 'message' => 'Unknown action.' ); }
    if ( $r === false ) { return array( 'success' => false, 'message' => 'Could not update the lead fee.' ); }
    ridego_audit_log( 'lead_fee_' . $action, 'booking', (int) $booking_id, (string) $b->vendor_lead_fee, $reason );
    return array( 'success' => true, 'message' => $action === 'waive' ? 'Lead fee waived for this booking.' : 'Lead fee recalculated with the terms in force today.' );
}

// TRACE: booking row + vendor id → the extra columns a new lead row carries so the vendor lead fee is fixed at the moment the lead is generated → array(applies, fee, columns).
//        Facilitator booking: applies true, columns = lf_amount / lf_terms_id / lf_snapshot from ridego_lead_fee_for_booking() for THAT vendor (so vendor-specific terms are honoured); legacy booking: applies false, columns empty (old wallet lead fee untouched).
function ridego_lead_fee_lead_columns( $booking, $vendor_id ) {
    if ( ! $booking || empty( $booking->platform_model ) ) { return array( 'applies' => false, 'fee' => 0.0, 'description' => '', 'columns' => array() ); }
    $lf = ridego_lead_fee_for_booking( $booking, (int) $vendor_id );
    return array( 'applies' => true, 'fee' => $lf['fee'], 'description' => ridego_lead_fee_describe( $lf['params'] ), 'columns' => array( 'lf_amount' => $lf['fee'], 'lf_terms_id' => $lf['terms_id'], 'lf_snapshot' => ridego_lead_fee_snapshot_json( $lf ) ) );
}

// TRACE: lead row (with lf_* columns; may come from a join) → what the vendor is shown for this lead → array(applies, amount, formula, method_label, terms_version, source, from_wallet).
//        Facilitator lead: the snapshot taken when the lead was generated. Legacy lead: the old wallet fee_amount (from_wallet true). Pure apart from decoding.
function ridego_lead_fee_lead_view( $lead ) {
    $snap = ! empty( $lead->lf_snapshot ) ? ridego_lead_fee_snapshot_decode( $lead->lf_snapshot ) : array();
    if ( $snap ) {
        $m = (string) ( $snap['params']['method'] ?? '' );
        return array( 'applies' => true, 'amount' => ridego_lead_fee_round( (float) ( $snap['fee'] ?? 0 ) ), 'formula' => (string) ( $snap['formula'] ?? '' ), 'method_label' => ridego_lead_fee_methods()[ $m ] ?? '',
            'terms_version' => $snap['terms_version'] ?? null, 'source' => (string) ( $snap['source'] ?? '' ), 'from_wallet' => false );
    }
    return array( 'applies' => false, 'amount' => ridego_lead_fee_round( (float) ( $lead->fee_amount ?? 0 ) ), 'formula' => '', 'method_label' => '', 'terms_version' => null, 'source' => 'legacy', 'from_wallet' => true );
}

// TRACE: terms params (row or array) → a plain-language description of the rule with no booking amount in it (shown on vendor and admin screens) → string. Pure.
function ridego_lead_fee_describe( $params ) {
    $p = ridego_lead_fee_norm_params( $params );
    $pct = rtrim( rtrim( number_format( $p['percentage'], 3, '.', '' ), '0' ), '.' ) . '%';
    switch ( $p['method'] ) {
        case 'fixed': return 'A fixed ₹' . ridego_lead_fee_round( $p['fixed_amount'] ) . ' per trip';
        case 'percentage': return $pct . ' of the expected booking amount';
        case 'higher_of':
        case 'percentage_min': return 'The higher of ₹' . ridego_lead_fee_round( $p['min_amount'] ) . ' or ' . $pct . ' of the expected booking amount';
        case 'percentage_min_max': return $pct . ' of the expected booking amount, at least ₹' . ridego_lead_fee_round( $p['min_amount'] ) . ( $p['max_amount'] > 0 ? ' and at most ₹' . ridego_lead_fee_round( $p['max_amount'] ) : '' );
        default: return 'No lead fee';
    }
}

// TRACE: vendor id → null when the vendor may take leads, or a failure array(success=false,message) when "require acceptance" is on and the vendor has not accepted the commercial terms that currently apply to them → array|null. Reads only.
function ridego_lead_fee_acceptance_gate( $vendor_id ) {
    $o = ridego_lead_fee_options();
    if ( ! $o['enabled'] || ! $o['require_acceptance'] ) { return null; }
    $st = ridego_lead_fee_vendor_acceptance_state( (int) $vendor_id );
    if ( $st['applies'] && ! $st['accepted'] ) { return array( 'success' => false, 'message' => 'Please review and accept the current commercial terms (Settlements → Commercial terms) before taking leads.' ); }
    return null;
}

// TRACE: from date + to date (Y-m-d, inclusive, on booking created_at) → the vendor lead fee totals every report uses → array(bookings, accrued, outstanding, collected, waived_count, by_status[status=>{count,amount}]). Reads bookings and the ledger; the ONE report query.
//        accrued = fees fixed on non-cancelled, non-waived facilitator bookings in the range; collected = accrued − outstanding; outstanding = pending 'lead_fee' ledger rows for those bookings. Edge cases: empty range (zeros), missing dates (all time).
function ridego_lead_fee_report( $from = '', $to = '' ) {
    global $wpdb;
    $bt = $wpdb->prefix . 'ridego_bookings'; $lt = $wpdb->prefix . 'ridego_booking_ledger';
    $w = "platform_model=1 AND vendor_lead_fee_locked_at IS NOT NULL"; $a = array();
    if ( $from ) { $w .= ' AND created_at>=%s'; $a[] = $from . ' 00:00:00'; }
    if ( $to )   { $w .= ' AND created_at<=%s'; $a[] = $to . ' 23:59:59'; }
    $sql = "SELECT vendor_lead_fee_status AS st, COUNT(*) c, COALESCE(SUM(vendor_lead_fee),0) amt FROM {$bt} WHERE {$w} GROUP BY vendor_lead_fee_status";
    $rows = $wpdb->get_results( $a ? $wpdb->prepare( $sql, $a ) : $sql );
    $by = array(); $accrued = 0.0; $n = 0;
    foreach ( (array) $rows as $r ) {
        $by[ $r->st !== '' ? $r->st : 'locked' ] = array( 'count' => (int) $r->c, 'amount' => ridego_lead_fee_round( (float) $r->amt ) );
        if ( ! in_array( $r->st, array( 'cancelled', 'waived' ), true ) ) { $accrued += (float) $r->amt; $n += (int) $r->c; }
    }
    $sql2 = "SELECT COALESCE(SUM(l.amount),0) FROM {$lt} l JOIN {$bt} b ON b.id=l.booking_id WHERE l.entry_type='lead_fee' AND l.status='pending' AND b." . str_replace( ' AND created_at', ' AND b.created_at', $w );
    $out = (float) $wpdb->get_var( $a ? $wpdb->prepare( $sql2, $a ) : $sql2 );
    return array( 'bookings' => $n, 'accrued' => ridego_lead_fee_round( $accrued ), 'outstanding' => ridego_lead_fee_round( $out ), 'collected' => ridego_lead_fee_round( max( 0, $accrued - $out ) ),
        'waived_count' => (int) ( $by['waived']['count'] ?? 0 ), 'by_status' => $by );
}


// TRACE: nothing → how an advance forfeited on a late cancellation is handled at the moment of cancelling → 'platform' (kept as the lead fee), 'vendor' (paid to the vendor as compensation) or 'admin' (nothing is recorded until an admin decides on the booking). Reads the setting cancel_forfeit_default; anything else → 'platform'.
function ridego_lead_fee_forfeit_default() {
    $v = ridego_get_setting( 'cancel_forfeit_default', 'platform' );
    return in_array( $v, array( 'vendor', 'admin' ), true ) ? $v : 'platform';
}

// TRACE: booking id + disposition ('platform'|'vendor') + reason + actor + $initial (true on the automatic decision at cancellation) → writes the ONE ledger row for the forfeited advance and records the decision on the booking → array(success, to, amount, message).
//        platform: settled 'lead_fee_retained' debit (RideGo keeps it as its lead fee). vendor: pending 'cancellation_compensation' credit (RideGo owes the vendor; paid to the vendor wallet when the ledger is settled).
//        Changing the decision later (admin, reason required) replaces the row (audit-logged); refused once the compensation has been paid out. Preconditions: facilitator booking, cancelled, vendor had been arranged, advance paid.
//        Edge cases: unknown disposition, not cancelled, no vendor, nothing forfeited, same decision again (no-op), missing reason on a change, ledger write failure (nothing changed, message).
function ridego_lead_fee_forfeit_apply( $booking_id, $to, $reason = '', $actor_id = 0, $initial = false ) {
    global $wpdb;
    $bt = $wpdb->prefix . 'ridego_bookings'; $lt = $wpdb->prefix . 'ridego_booking_ledger';
    if ( ! in_array( $to, array( 'platform', 'vendor' ), true ) ) { return array( 'success' => false, 'message' => 'Choose whether the platform keeps the advance or the vendor is compensated.' ); }
    $b = ridego_get_booking( (int) $booking_id );
    if ( ! $b || empty( $b->platform_model ) ) { return array( 'success' => false, 'message' => 'This applies to facilitator bookings only.' ); }
    if ( $b->status !== 'cancelled' ) { return array( 'success' => false, 'message' => 'The booking is not cancelled.' ); }
    if ( empty( $b->vendor_id ) ) { return array( 'success' => false, 'message' => 'No vendor had been arranged, so the advance is refunded, not forfeited.' ); }
    $amount = ridego_lead_fee_round( (float) ridego_calc_cancel_penalty( $b ) );
    if ( $amount <= 0 ) { return array( 'success' => false, 'message' => 'No advance was forfeited on this booking.' ); }
    $reason = trim( sanitize_text_field( (string) $reason ) );
    if ( ! $initial && $reason === '' ) { return array( 'success' => false, 'message' => 'Enter a reason for the change.' ); }
    $key = 'forfeit:' . (int) $booking_id;
    $old = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$lt} WHERE dedupe_key=%s", $key ), ARRAY_A );
    if ( $old ) {
        $old_to = $old['entry_type'] === 'cancellation_compensation' ? 'vendor' : 'platform';
        if ( $old_to === $to ) { return array( 'success' => true, 'to' => $to, 'amount' => $amount, 'message' => 'No change: this is already the decision.' ); }
        if ( $old_to === 'vendor' && $old['status'] === 'settled' ) { return array( 'success' => false, 'message' => 'The compensation has already been paid to the vendor, so it cannot be changed.' ); }
        if ( $wpdb->delete( $lt, array( 'id' => (int) $old['id'] ) ) === false ) { return array( 'success' => false, 'message' => 'Could not change the earlier entry.' ); }
    }
    $brand = ridego_brand_name();
    if ( $to === 'platform' ) {
        $r = ridego_ledger_add( (int) $booking_id, (int) $b->vendor_id, 'lead_fee_retained', $amount, 'debit', $key, 'Advance forfeited on cancellation, kept by ' . $brand . ' as the lead fee', 'settled' );
        if ( $r === 'inserted' ) { $wpdb->query( $wpdb->prepare( "UPDATE {$lt} SET settled_at=%s WHERE dedupe_key=%s AND settled_at IS NULL", current_time( 'mysql' ), $key ) ); }
    } else {
        $r = ridego_ledger_add( (int) $booking_id, (int) $b->vendor_id, 'cancellation_compensation', $amount, 'credit', $key, 'Advance forfeited on cancellation, paid to the vendor as compensation', 'pending' );
    }
    if ( $r !== 'inserted' ) {
        if ( $old ) { ridego_ledger_add( (int) $booking_id, (int) $b->vendor_id, $old['entry_type'], (float) $old['amount'], $old['direction'], $key, (string) $old['notes'], $old['status'] ); }
        return array( 'success' => false, 'message' => 'Could not record the decision. Please try again.' );
    }
    $u = $wpdb->update( $bt, array( 'cancel_forfeit_to' => $to, 'cancel_forfeit_reason' => substr( $reason, 0, 255 ) ), array( 'id' => (int) $booking_id ) );
    if ( $u === false ) { ridego_log( 'forfeit disposition column update failed for booking ' . (int) $booking_id . ': ' . $wpdb->last_error ); }
    ridego_lead_fee_sync_status( (int) $booking_id );
    ridego_audit_log( 'cancel_forfeit_decided', 'booking', (int) $booking_id, $old ? ( $old['entry_type'] === 'cancellation_compensation' ? 'vendor' : 'platform' ) : '', $to . ( $reason !== '' ? ': ' . $reason : '' ) );
    return array( 'success' => true, 'to' => $to, 'amount' => $amount, 'message' => $to === 'vendor' ? 'The forfeited advance will be paid to the vendor as compensation.' : 'The forfeited advance is kept by ' . $brand . ' as the lead fee.' );
}
