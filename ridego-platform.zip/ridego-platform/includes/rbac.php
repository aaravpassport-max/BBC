<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   RBAC — granular capability checking (Wave 2A)
   ------------------------------------------------------------
   Root-cause fix for ridego_can() collapsing every permission
   check to "is this manage_options?" via its `|| current_user_can
   ('manage_options')` OR-bypass. That meant a ridego_manager role
   with only e.g. ridego_manage_promo_codes could never actually be
   distinguished from a full WP administrator anywhere ridego_can()
   was used defensively — and conversely, any WP admin automatically
   passed every RideGo-specific capability check regardless of what
   the granular role definitions in includes/roles.php actually say.

   ridego_current_user_can_ridego() below checks the SPECIFIC
   capability with no bypass. The only bypass that exists is the
   explicit, auditable 'ridego_super_admin' WP capability (granted
   only to the 'administrator' role — see ridego_register_roles() in
   includes/roles.php), and every time that bypass is actually used
   to grant access a manager/vendor-scoped check would otherwise have
   refused, it is logged via ridego_audit_log() with severity
   'warning' so overrides are visible rather than invisible.
   ============================================================ */

/**
 * Check whether the current user has a specific RideGo capability,
 * without the manage_options OR-bypass. Falls back to the explicit,
 * audited 'ridego_super_admin' escape hatch only if the granular
 * check fails.
 *
 * @param string $capability The RideGo capability to check, e.g.
 *                            'ridego_manage_pricing'.
 * @return bool
 */
function ridego_current_user_can_ridego( $capability ) {
    // Granular check first — this is the real check, no shortcuts.
    if ( current_user_can( $capability ) ) {
        return true;
    }

    // Explicit, audited super-admin override. Only WP administrators get
    // this capability (see ridego_register_roles()), and every time it is
    // the ONLY reason access was granted, that is logged as a warning —
    // a properly-scoped role should not need this, so seeing it in the
    // audit log is a signal worth an admin's attention.
    if ( current_user_can( 'ridego_super_admin' ) ) {
        if ( function_exists( 'ridego_audit_log' ) ) {
            ridego_audit_log(
                'super_admin_override',
                'capability',
                0,
                $capability,
                'granted via ridego_super_admin bypass (user lacks the specific capability)',
                'warning'
            );
        }
        return true;
    }

    return false;
}
