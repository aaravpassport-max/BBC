<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — marketplace: Command Centre, lead comparison and
   assignment, fleet view, commission, ledger, performance, matching,
   impersonation and marketplace reports. Every route re-checks its own
   capability (see ridego_mkt_admin_perm) — there is no shared "is admin" gate.
   ================================================================ */

// TRACE: capability name (or several joined by |, any one suffices) → returns a permission callback closure that requires login + that capability →
//        callable returning true | WP_Error 401/403. Edge cases: impersonating user (not an admin → 403).
function ridego_mkt_admin_perm( $cap ) {
    return function () use ( $cap ) {
        if ( ! is_user_logged_in() ) { return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) ); }
        foreach ( explode( '|', $cap ) as $one ) { if ( ridego_can( $one ) ) { return true; } }
        return new WP_Error( 'forbidden', 'You do not have permission for this action.', array( 'status' => 403 ) );
    };
}

add_action( 'rest_api_init', 'ridego_register_app_admin_marketplace_routes' );
// TRACE: rest_api_init → registers all admin marketplace routes from one table [route, methods, callback, cap] → void.
function ridego_register_app_admin_marketplace_routes() {
    $B = '/app/admin/';
    $routes = array(
        array( 'command-centre', 'GET', 'ridego_mkt_a_command_centre', 'ridego_view_command_centre' ),
        array( 'bookings/(?P<id>\d+)/comparison', 'GET', 'ridego_mkt_a_comparison', 'ridego_compare_vendor_responses' ),
        array( 'bookings/(?P<id>\d+)/assign', 'POST', 'ridego_mkt_a_assign', 'ridego_assign_lead' ),
        array( 'bookings/(?P<id>\d+)/replace-assignment', 'POST', 'ridego_mkt_a_replace', 'ridego_reassign_lead' ),
        array( 'bookings/(?P<id>\d+)/reopen', 'POST', 'ridego_mkt_a_reopen', 'ridego_reassign_lead' ),
        array( 'bookings/(?P<id>\d+)/report-issue', 'POST', 'ridego_mkt_a_report_issue', 'ridego_manage_bookings' ),
        array( 'bookings/(?P<id>\d+)/remind-vendors', 'POST', 'ridego_mkt_a_remind_vendors', 'ridego_reassign_lead' ),
        array( 'bookings/(?P<id>\d+)/resend-leads', 'POST', 'ridego_mkt_a_resend_leads', 'ridego_reassign_lead' ),
        array( 'bookings/(?P<id>\d+)/remind-client', 'POST', 'ridego_mkt_a_remind_client', 'ridego_manage_bookings' ),
        array( 'bookings/bulk', 'POST', 'ridego_mkt_a_bulk', 'ridego_bulk_booking_actions' ),
        array( 'leads/(?P<id>\d+)/request-driver-details', 'POST', 'ridego_mkt_a_lead_request', 'ridego_compare_vendor_responses' ),
        array( 'leads/(?P<id>\d+)/reject', 'POST', 'ridego_mkt_a_lead_reject', 'ridego_assign_lead' ),
        array( 'vendors/(?P<id>\d+)/fleet', 'GET', 'ridego_mkt_a_vendor_fleet', 'ridego_view_fleets' ),
        array( 'vendors/(?P<id>\d+)/fleet/vehicles', 'POST', 'ridego_mkt_a_fleet_vehicle_create', 'ridego_manage_fleet_vehicles' ),
        array( 'vendors/(?P<id>\d+)/fleet/vehicles/(?P<eid>\d+)', 'PUT,PATCH', 'ridego_mkt_a_fleet_vehicle_update', 'ridego_manage_fleet_vehicles' ),
        array( 'vendors/(?P<id>\d+)/fleet/vehicles/(?P<eid>\d+)', 'DELETE', 'ridego_mkt_a_fleet_vehicle_delete', 'ridego_manage_fleet_vehicles' ),
        array( 'vendors/(?P<id>\d+)/fleet/drivers', 'POST', 'ridego_mkt_a_fleet_driver_create', 'ridego_manage_fleet_vehicles' ),
        array( 'vendors/(?P<id>\d+)/fleet/drivers/(?P<eid>\d+)', 'PUT,PATCH', 'ridego_mkt_a_fleet_driver_update', 'ridego_manage_fleet_vehicles' ),
        array( 'vendors/(?P<id>\d+)/fleet/drivers/(?P<eid>\d+)', 'DELETE', 'ridego_mkt_a_fleet_driver_delete', 'ridego_manage_fleet_vehicles' ),
        array( 'vendors/(?P<id>\d+)/fleet/docs', 'POST', 'ridego_mkt_a_fleet_doc_upload', 'ridego_manage_fleet_vehicles' ),
        array( 'vendors/(?P<id>\d+)/type', 'POST', 'ridego_mkt_a_vendor_type', 'ridego_manage_vendors' ),
        array( 'commission/models', 'GET', 'ridego_mkt_a_models_list', 'ridego_manage_commission_models' ),
        array( 'commission/models', 'POST', 'ridego_mkt_a_model_create', 'ridego_manage_commission_models' ),
        array( 'commission/models/(?P<id>\d+)', 'PUT,PATCH', 'ridego_mkt_a_model_update', 'ridego_manage_commission_models' ),
        array( 'commission/assign', 'POST', 'ridego_mkt_a_model_assign', 'ridego_manage_commission_models' ),
        array( 'ledger', 'GET', 'ridego_mkt_a_ledger', 'ridego_view_ledger' ),
        array( 'ledger/settle', 'POST', 'ridego_mkt_a_settle', 'ridego_settle_ledger' ),
        array( 'performance', 'GET', 'ridego_mkt_a_performance', 'ridego_view_performance_data' ),
        array( 'matching', 'GET', 'ridego_mkt_a_matching_get', 'ridego_manage_automatic_assignment' ),
        array( 'matching/flags', 'POST', 'ridego_mkt_a_matching_flags', 'ridego_manage_automatic_assignment' ),
        array( 'matching/profile', 'POST', 'ridego_mkt_a_matching_profile', 'ridego_manage_automatic_assignment' ),
        array( 'matching/profile/(?P<id>\d+)/activate', 'POST', 'ridego_mkt_a_matching_activate', 'ridego_manage_automatic_assignment' ),
        array( 'matching/backtest', 'POST', 'ridego_mkt_a_matching_backtest', 'ridego_manage_automatic_assignment' ),
        array( 'impersonate', 'POST', 'ridego_mkt_a_impersonate', 'ridego_impersonate_vendor|ridego_impersonate_client|ridego_impersonate_regional_manager|ridego_impersonate_staff|ridego_impersonate_driver' ),
        array( 'reports/marketplace', 'GET', 'ridego_mkt_a_report', 'ridego_view_reports' ),
        array( 'fleet/document-expiry', 'GET', 'ridego_mkt_a_document_expiry', 'ridego_view_fleets' ),
    );
    foreach ( $routes as $r ) {
        register_rest_route( 'ridego/v1', $B . $r[0], array( 'methods' => $r[1], 'callback' => $r[2], 'permission_callback' => ridego_mkt_admin_perm( $r[3] ) ) );
    }
    // Stop must work while impersonating (the effective user is the target, not an admin): guarded by the session itself.
    register_rest_route( 'ridego/v1', '/app/impersonate/stop', array( 'methods' => 'POST', 'callback' => 'ridego_mkt_a_impersonate_stop',
        'permission_callback' => function () { return ridego_is_impersonating() ? true : new WP_Error( 'no_session', 'No view-as session is active.', array( 'status' => 400 ) ); } ) );
}

// TRACE: rows of bookings → adds client_phone, vendor response summary (total/viewed/interested/driver_confirmed) and
//        a vendors[] list (name, phone, interest_status) per booking → array. Read-only; one query per call for leads.
//        Edge cases: empty input returns empty; bookings without leads get zero counts.
function ridego_mkt_cc_enrich( array $rows ) {
    global $wpdb;
    if ( ! $rows ) { return $rows; }
    $ids = array_map( 'intval', wp_list_pluck( $rows, 'id' ) );
    $in = implode( ',', $ids );
    $bt = $wpdb->prefix . 'ridego_bookings'; $lt = $wpdb->prefix . 'ridego_leads'; $vt = $wpdb->prefix . 'ridego_vendors';
    $phones = $wpdb->get_results( "SELECT id, client_phone FROM {$bt} WHERE id IN ({$in})", OBJECT_K );
    $leads = $wpdb->get_results( "SELECT l.booking_id, l.vendor_id, l.interest_status, v.business_name, v.phone FROM {$lt} l LEFT JOIN {$vt} v ON v.id=l.vendor_id WHERE l.booking_id IN ({$in}) AND l.status IN ('sent','accepted') ORDER BY l.id ASC", ARRAY_A );
    $by = array();
    foreach ( $leads as $l ) { $by[ (int) $l['booking_id'] ][] = $l; }
    foreach ( $rows as &$r ) {
        $bid = (int) $r['id']; $r['id'] = $bid; $r['vendor_id'] = $r['vendor_id'] ? (int) $r['vendor_id'] : null; $r['total_fare'] = (float) $r['total_fare']; $vs = $by[ $bid ] ?? array();
        $sum = array( 'total' => count( $vs ), 'viewed' => 0, 'interested' => 0, 'driver_confirmed' => 0 );
        $list = array();
        foreach ( $vs as $l ) {
            $st = $l['interest_status'];
            if ( in_array( $st, array( 'viewed', 'interested', 'driver_confirmed' ), true ) ) { $sum['viewed']++; }
            if ( in_array( $st, array( 'interested', 'driver_confirmed' ), true ) ) { $sum['interested']++; }
            if ( $st === 'driver_confirmed' ) { $sum['driver_confirmed']++; }
            $list[] = array( 'vendor_id' => (int) $l['vendor_id'], 'name' => (string) $l['business_name'], 'phone' => (string) $l['phone'], 'interest_status' => $st );
        }
        $r['client_phone'] = isset( $phones[ $bid ] ) ? (string) $phones[ $bid ]->client_phone : '';
        $r['response_summary'] = $sum; $r['vendors'] = $list;
    }
    unset( $r );
    return $rows;
}

// TRACE: GET command centre → six plan sections (new_leads, awaiting_vendor_response, driver_pending, ready_for_assignment,
//        today_trips, payments_pending — each unassigned booking sits in exactly one of the first four) plus
//        needs_driver_details, ongoing, complaints_open, kpis, lead_mode and an activity feed (last 15 audit rows) → response.
//        Read-only. Edge cases: empty queues, each capped at 50.
function ridego_mkt_a_command_centre( WP_REST_Request $req ) {
    global $wpdb;
    $bt = $wpdb->prefix . 'ridego_bookings'; $lt = $wpdb->prefix . 'ridego_leads'; $at = $wpdb->prefix . 'ridego_booking_assignments';
    $cols = 'b.id, b.booking_number, b.status, b.pickup_city, b.drop_city, b.journey_date, b.journey_time, b.total_fare, b.client_name, b.vendor_id';
    $q = function ( $where, $order = 'b.journey_date ASC, b.journey_time ASC', $extra_join = '' ) use ( $wpdb, $bt, $cols ) {
        return ridego_mkt_cc_enrich( (array) $wpdb->get_results( "SELECT {$cols} FROM {$bt} b {$extra_join} WHERE {$where} ORDER BY {$order} LIMIT 50", ARRAY_A ) );
    };
    $open = "b.vendor_id IS NULL AND b.status IN ('confirmed','no_vendor')";
    $has = function ( $states ) use ( $lt ) { return "EXISTS (SELECT 1 FROM {$lt} l WHERE l.booking_id=b.id AND l.status='sent' AND l.interest_status IN ({$states}))"; };
    $any_lead = "EXISTS (SELECT 1 FROM {$lt} l WHERE l.booking_id=b.id AND l.status='sent')";
    $ready = $q( "{$open} AND " . $has( "'driver_confirmed'" ) );
    $driver_pending = $q( "{$open} AND NOT " . $has( "'driver_confirmed'" ) . ' AND ' . $has( "'interested'" ) );
    $awaiting_resp = $q( "{$open} AND NOT " . $has( "'driver_confirmed','interested'" ) . " AND {$any_lead}" );
    $new_leads = $q( "{$open} AND NOT {$any_lead}" );
    $needs_driver = $q( "b.status IN ('vendor_assigned','driver_en_route') AND (a.driver_name_snapshot='' OR a.vehicle_registration_snapshot='')", 'b.journey_date ASC, b.journey_time ASC', "JOIN {$at} a ON a.booking_id=b.id AND a.is_current=1" );
    $today = current_time( 'Y-m-d' );
    $today_trips = $q( $wpdb->prepare( "b.journey_date=%s AND b.status IN ('vendor_assigned','driver_en_route','trip_started')", $today ) );
    $soon_to = date( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) + 6 * 3600 );
    $starting_soon = $q( $wpdb->prepare( "b.status='vendor_assigned' AND CONCAT(b.journey_date,' ',b.journey_time)<=%s AND CONCAT(b.journey_date,' ',b.journey_time)>=%s", $soon_to, current_time( 'mysql' ) ) );
    $payments = $q( "b.payment_status IN ('proof_submitted','pending','unpaid') AND b.status NOT IN ('cancelled','completed','token_refund_due')", 'b.created_at ASC' );
    $ongoing = $q( "b.status IN ('driver_en_route','trip_started')" );
    $complaints = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_complaints WHERE status IN ('open','in_progress')" );
    $kpi = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) c, COALESCE(SUM(total_fare),0) g, COALESCE(SUM(advance_paid),0) k FROM {$bt} WHERE DATE(created_at)=%s AND status<>'cancelled'", $today ), ARRAY_A );
    $activity = $wpdb->get_results( "SELECT id, action, entity, entity_id, created_at FROM {$wpdb->prefix}ridego_audit_log ORDER BY id DESC LIMIT 15", ARRAY_A );
    return rest_ensure_response( array(
        'new_leads' => $new_leads, 'awaiting_vendor_response' => $awaiting_resp, 'driver_pending' => $driver_pending,
        'ready_for_assignment' => $ready, 'today_trips' => $today_trips, 'payments_pending' => $payments,
        'needs_vendor' => array_merge( $new_leads, $awaiting_resp ), 'awaiting_selection' => array_merge( $driver_pending, $ready ),
        'needs_driver_details' => $needs_driver, 'starting_soon' => $starting_soon, 'ongoing' => $ongoing, 'complaints_open' => $complaints,
        'kpis' => array( 'bookings_today' => (int) $kpi['c'], 'gmv_today' => (float) $kpi['g'], 'collected_today' => (float) $kpi['k'], 'ledger_pending_net' => ridego_ledger_summary()['pending_net'],
            'active_vendors' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_vendors WHERE status='active'" ) ),
        'activity' => $activity, 'lead_mode' => ridego_lead_mode(),
    ) );
}

// TRACE: POST remind-vendors {kind: response|driver} → re-notifies vendors who have not answered (response: sent/viewed leads;
//        driver: interested leads) for the booking through ridego_queue_notification('lead_reminder') → {success, reminded}|404|400.
//        Edge cases: no eligible vendor (400), bookings with a vendor already (400), unknown kind (400).
function ridego_mkt_a_remind_vendors( WP_REST_Request $req ) {
    global $wpdb;
    $j = ridego_mkt_body( $req ); $kind = ( $j['kind'] ?? 'response' ) === 'driver' ? 'driver' : 'response';
    $b = ridego_get_booking( (int) $req['id'] );
    if ( ! $b ) { return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) ); }
    if ( $b->vendor_id ) { return new WP_Error( 'already_assigned', 'This booking already has a vendor.', array( 'status' => 400 ) ); }
    $states = $kind === 'driver' ? "'interested'" : "'sent','viewed'";
    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT l.id, v.user_id, v.whatsapp_number, v.phone, v.email FROM {$wpdb->prefix}ridego_leads l JOIN {$wpdb->prefix}ridego_vendors v ON v.id=l.vendor_id WHERE l.booking_id=%d AND l.status='sent' AND l.interest_status IN ({$states})", $b->id ) );
    if ( ! $rows ) { return new WP_Error( 'no_vendors', 'No vendors are waiting to be reminded.', array( 'status' => 400 ) ); }
    foreach ( $rows as $r ) {
        ridego_queue_notification( array( 'recipient_id' => (int) $r->user_id, 'recipient_type' => 'vendor', 'recipient_phone' => $r->whatsapp_number ?: $r->phone, 'recipient_email' => $r->email,
            'event' => 'lead_reminder', 'payload' => array( 'booking_id' => (int) $b->id, 'booking_number' => $b->booking_number, 'kind' => $kind ), 'scheduled_for' => current_time( 'mysql' ) ) );
    }
    ridego_audit_log( 'remind_vendors_' . $kind, 'booking', (int) $b->id, '', (string) count( $rows ) );
    return rest_ensure_response( array( 'success' => true, 'reminded' => count( $rows ), 'message' => sprintf( 'Reminder sent to %d vendor(s).', count( $rows ) ) ) );
}

// TRACE: POST resend-leads → runs the lead cascade again for an unassigned booking → {success, message}|404|400.
//        Edge cases: booking has vendor (400), no eligible vendors (400 with reason).
function ridego_mkt_a_resend_leads( WP_REST_Request $req ) {
    $b = ridego_get_booking( (int) $req['id'] );
    if ( ! $b ) { return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) ); }
    if ( $b->vendor_id ) { return new WP_Error( 'already_assigned', 'This booking already has a vendor.', array( 'status' => 400 ) ); }
    if ( ! ridego_cascade_lead( (int) $b->id, true ) ) { return new WP_Error( 'no_eligible_vendors', 'No eligible vendors were found to send the lead to.', array( 'status' => 400 ) ); }
    if ( $b->status === 'no_vendor' ) { ridego_update_booking_status( (int) $b->id, 'confirmed' ); }
    ridego_audit_log( 'resend_leads', 'booking', (int) $b->id );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Lead sent again to eligible vendors.' ) );
}

// TRACE: POST remind-client → queues a payment_reminder notification to the booking's client → {success, message}|404|400.
//        Edge cases: booking paid/cancelled (400), client has no account (400).
function ridego_mkt_a_remind_client( WP_REST_Request $req ) {
    $b = ridego_get_booking( (int) $req['id'] );
    if ( ! $b ) { return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) ); }
    if ( in_array( $b->status, array( 'cancelled', 'completed' ), true ) || in_array( $b->payment_status, array( 'paid', 'verified', 'confirmed' ), true ) ) { return new WP_Error( 'not_payable', 'This booking has no payment pending.', array( 'status' => 400 ) ); }
    if ( (int) $b->client_id <= 0 && $b->client_phone === '' && $b->client_email === '' ) { return new WP_Error( 'no_client', 'This booking has no client contact details to notify.', array( 'status' => 400 ) ); }
    ridego_queue_notification( array( 'recipient_id' => (int) $b->client_id, 'recipient_type' => 'client', 'recipient_phone' => $b->client_phone, 'recipient_email' => $b->client_email,
        'event' => 'payment_reminder', 'payload' => array( 'booking_id' => (int) $b->id, 'booking_number' => $b->booking_number, 'amount' => (float) $b->total_fare ), 'scheduled_for' => current_time( 'mysql' ) ) );
    ridego_audit_log( 'remind_client_payment', 'booking', (int) $b->id );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Payment reminder sent to the client.' ) );
}

// TRACE: admin fleet override → runs the vendor-side create/update/delete function for the given vendor id on the vendor's behalf,
//        audit-logged with the acting admin → response|404|400. Preconditions: cap ridego_manage_fleet_vehicles; vendor exists.
//        Edge cases: unknown vendor (404); the same validation the vendor sees (duplicate plate, individual vendor limits) is returned as 400.
function ridego_mkt_a_fleet_guard( WP_REST_Request $req ) {
    return ridego_get_vendor( (int) $req['id'] ) ? true : new WP_Error( 'not_found', 'Vendor not found.', array( 'status' => 404 ) );
}
// TRACE: POST vendor vehicle create → ridego_create_fleet_vehicle(vendor) + audit → response|404|400.
function ridego_mkt_a_fleet_vehicle_create( WP_REST_Request $req ) {
    $g = ridego_mkt_a_fleet_guard( $req ); if ( is_wp_error( $g ) ) { return $g; }
    $r = ridego_create_fleet_vehicle( (int) $req['id'], ridego_mkt_body( $req ) ); $r0 = $r['message'] ?? '';
    if ( ! empty( $r['success'] ) ) { ridego_audit_log( 'admin_fleet_vehicle_create', 'vendor', (int) $req['id'], '', (string) ( $r['id'] ?? '' ) ); }
    if ( empty( $r['success'] ) && ! empty( $r['message'] ) ) { $r['message'] = 'This is an individual vendor (one vehicle, one driver). Change the vendor type to Fleet first to add more.'; if ( ridego_get_vendor_type( ridego_get_vendor( (int) $req['id'] ) ) === 'fleet' ) { $r['message'] = $r0; } }
    return ridego_mkt_result( $r );
}
// TRACE: PUT vendor vehicle update → ridego_update_fleet_vehicle(id, vendor) + audit → response|404|400.
function ridego_mkt_a_fleet_vehicle_update( WP_REST_Request $req ) {
    $g = ridego_mkt_a_fleet_guard( $req ); if ( is_wp_error( $g ) ) { return $g; }
    $r = ridego_update_fleet_vehicle( (int) $req['eid'], (int) $req['id'], ridego_mkt_body( $req ), $req->get_param( 'expected_lock_version' ) );
    if ( ! empty( $r['success'] ) ) { ridego_audit_log( 'admin_fleet_vehicle_update', 'vendor', (int) $req['id'], '', (string) (int) $req['eid'] ); }
    return ridego_mkt_result( $r );
}
// TRACE: DELETE vendor vehicle → ridego_delete_fleet_entity('vehicle') + audit → response|404|400.
function ridego_mkt_a_fleet_vehicle_delete( WP_REST_Request $req ) {
    $g = ridego_mkt_a_fleet_guard( $req ); if ( is_wp_error( $g ) ) { return $g; }
    $r = ridego_delete_fleet_entity( 'vehicle', (int) $req['eid'], (int) $req['id'] );
    if ( ! empty( $r['success'] ) ) { ridego_audit_log( 'admin_fleet_vehicle_delete', 'vendor', (int) $req['id'], (string) (int) $req['eid'], '' ); }
    return ridego_mkt_result( $r );
}
// TRACE: POST vendor driver create → ridego_create_fleet_driver(vendor) + audit → response|404|400.
function ridego_mkt_a_fleet_driver_create( WP_REST_Request $req ) {
    $g = ridego_mkt_a_fleet_guard( $req ); if ( is_wp_error( $g ) ) { return $g; }
    $r = ridego_create_fleet_driver( (int) $req['id'], ridego_mkt_body( $req ) );
    if ( ! empty( $r['success'] ) ) { ridego_audit_log( 'admin_fleet_driver_create', 'vendor', (int) $req['id'], '', (string) ( $r['id'] ?? '' ) ); }
    return ridego_mkt_result( $r );
}
// TRACE: PUT vendor driver update → ridego_update_fleet_driver(id, vendor) + audit → response|404|400.
function ridego_mkt_a_fleet_driver_update( WP_REST_Request $req ) {
    $g = ridego_mkt_a_fleet_guard( $req ); if ( is_wp_error( $g ) ) { return $g; }
    $r = ridego_update_fleet_driver( (int) $req['eid'], (int) $req['id'], ridego_mkt_body( $req ), $req->get_param( 'expected_lock_version' ) );
    if ( ! empty( $r['success'] ) ) { ridego_audit_log( 'admin_fleet_driver_update', 'vendor', (int) $req['id'], '', (string) (int) $req['eid'] ); }
    return ridego_mkt_result( $r );
}
// TRACE: DELETE vendor driver → ridego_delete_fleet_entity('driver') + audit → response|404|400.
function ridego_mkt_a_fleet_driver_delete( WP_REST_Request $req ) {
    $g = ridego_mkt_a_fleet_guard( $req ); if ( is_wp_error( $g ) ) { return $g; }
    $r = ridego_delete_fleet_entity( 'driver', (int) $req['eid'], (int) $req['id'] );
    if ( ! empty( $r['success'] ) ) { ridego_audit_log( 'admin_fleet_driver_delete', 'vendor', (int) $req['id'], (string) (int) $req['eid'], '' ); }
    return ridego_mkt_result( $r );
}

// TRACE: POST vendor fleet doc upload {doc_type, vehicle_id?, driver_id?, expiry_date?, file} → admin uploads a
//        vehicle/driver/KYC document on the vendor's behalf via the same ridego_upload_vendor_doc() the vendor's
//        own /app/vendor/docs endpoint uses, audit-logged with the acting admin → response|404|400.
//        Preconditions: cap ridego_manage_fleet_vehicles; vendor exists; vehicle_id/driver_id (at most one) belongs
//        to this vendor. Edge cases: both ids given (400), foreign entity (404 — same IDOR guard as the vendor's own
//        endpoint), unknown doc type for the scope (400), no file (400).
//
// Root-cause fix (RideGo-Pre-Delivery-Audit.md, Revision 13, OPEN ISSUES): "Administrators cannot upload driver
// documents from the admin vendor screen except through View As." An admin previously had to impersonate the
// vendor just to add a document — every other fleet action (vehicle/driver create, update, delete) already had
// a direct admin-side override (see ridego_mkt_a_fleet_guard above); only document upload was missing one.
function ridego_mkt_a_fleet_doc_upload( WP_REST_Request $req ) {
    $g = ridego_mkt_a_fleet_guard( $req ); if ( is_wp_error( $g ) ) { return $g; }
    $vendor_id = (int) $req['id'];

    $doc_type      = sanitize_key( (string) $req->get_param( 'doc_type' ) );
    $scope_vehicle = (int) $req->get_param( 'vehicle_id' );
    $scope_driver  = (int) $req->get_param( 'driver_id' );
    if ( $scope_vehicle && $scope_driver ) {
        return new WP_Error( 'invalid_input', 'A document belongs to a vehicle or a driver, not both.', array( 'status' => 400 ) );
    }
    if ( $scope_vehicle || $scope_driver ) {
        $ent = $scope_vehicle ? ridego_get_fleet_vehicle( $scope_vehicle ) : ridego_get_fleet_driver( $scope_driver );
        if ( ! $ent || (int) $ent->vendor_id !== $vendor_id ) {
            return new WP_Error( 'not_found', 'Vehicle or driver not found.', array( 'status' => 404 ) );
        }
        if ( ! in_array( $doc_type, ridego_fleet_doc_types( $scope_vehicle ? 'vehicle' : 'driver' ), true ) ) {
            return new WP_Error( 'invalid_input', 'Unknown document type.', array( 'status' => 400 ) );
        }
    } elseif ( ! in_array( $doc_type, ridego_app_api_kyc_required_doc_types(), true ) ) {
        return new WP_Error( 'invalid_input', 'Unknown document type.', array( 'status' => 400 ) );
    }
    $files = $req->get_file_params();
    if ( empty( $files['file']['tmp_name'] ) ) {
        return new WP_Error( 'invalid_input', 'A file is required.', array( 'status' => 400 ) );
    }
    $expiry = sanitize_text_field( (string) $req->get_param( 'expiry_date' ) );

    $r = ridego_upload_vendor_doc( $vendor_id, $doc_type, $files['file'], $expiry, $scope_vehicle ?: null, $scope_driver ?: null );
    if ( ! empty( $r['success'] ) ) {
        ridego_audit_log( 'admin_fleet_doc_upload', 'vendor', $vendor_id, '', $doc_type . ( $scope_driver ? ':driver:' . $scope_driver : ( $scope_vehicle ? ':vehicle:' . $scope_vehicle : '' ) ) );
    }
    if ( empty( $r['success'] ) ) { return new WP_Error( 'upload_failed', $r['message'] ?? 'Could not upload document.', array( 'status' => 400 ) ); }
    return rest_ensure_response( $r );
}

// TRACE: assignment row → array for the admin API with the stored driver trace snapshot decoded into `driver_profile` (or null for older rows)
//        and the raw JSON column dropped → array. Pure. Edge cases: invalid/empty JSON → null.
function ridego_assignment_for_admin( $a ) {
    $arr = (array) $a;
    $snap = ! empty( $arr['driver_profile_snapshot'] ) ? json_decode( (string) $arr['driver_profile_snapshot'], true ) : null;
    unset( $arr['driver_profile_snapshot'] );
    $arr['driver_profile'] = is_array( $snap ) ? $snap : null;
    return $arr;
}

// TRACE: GET comparison → booking summary + every lead candidate (interest/driver/vehicle/score) + current assignment +
//        ranking & recommendation (only when the matching flag is ON) → response|404.
function ridego_mkt_a_comparison( WP_REST_Request $req ) {
    $b = ridego_get_booking( (int) $req['id'] );
    if ( ! $b ) { return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) ); }
    $a = ridego_get_current_assignment( $b->id );
    $on = ridego_matching_flag( 'performance_based_matching' );
    $ranking = $on ? ridego_score_candidates( $b->id ) : array();
    $rec = ridego_matching_get_recommendation( $b->id ); // the stored reasoning stays visible after the fact, even if the flag is later switched off
    return rest_ensure_response( array(
        'booking' => array( 'id' => (int) $b->id, 'booking_number' => $b->booking_number, 'status' => $b->status, 'pickup_city' => $b->pickup_city, 'drop_city' => $b->drop_city,
            'journey_date' => $b->journey_date, 'journey_time' => $b->journey_time, 'total_fare' => (float) $b->total_fare, 'vendor_id' => $b->vendor_id ? (int) $b->vendor_id : null, 'passengers' => (int) $b->passengers,
            'passenger_male' => isset( $b->passenger_male ) && $b->passenger_male !== null ? (int) $b->passenger_male : null,
            'passenger_female' => isset( $b->passenger_female ) && $b->passenger_female !== null ? (int) $b->passenger_female : null,
            'passenger_children' => isset( $b->passenger_children ) && $b->passenger_children !== null ? (int) $b->passenger_children : null,
            'is_safety_sensitive' => ridego_booking_is_safety_sensitive( $b ) ),
        'candidates' => ridego_get_lead_comparison( $b->id ), 'assignment' => $a ? ridego_assignment_for_admin( $a ) : null,
        'ranking' => $ranking, 'recommendation' => $rec, 'recommendations_enabled' => $on, 'lead_mode' => ridego_lead_mode(),
    ) );
}

// TRACE: POST assign {vendor_id, reason, lead_id?} → transactional admin assignment (reason required when the
//        vendor differs from the engine's top recommendation) → response|400.
function ridego_mkt_a_assign( WP_REST_Request $req ) {
    $j = ridego_mkt_body( $req );
    $vid = (int) ( $j['vendor_id'] ?? 0 );
    if ( $vid <= 0 ) { return new WP_Error( 'invalid_input', 'Choose a vendor.', array( 'status' => 400 ) ); }
    $reason = sanitize_text_field( $j['reason'] ?? '' );
    if ( ridego_matching_flag( 'performance_based_matching' ) ) {
        $rank = ridego_score_candidates( (int) $req['id'] );
        if ( $rank && (int) $rank[0]['vendor_id'] !== $vid && $reason === '' ) {
            return new WP_Error( 'reason_required', 'Please give a reason for choosing a different vendor than the recommendation.', array( 'status' => 400 ) );
        }
    }
    return ridego_mkt_result( ridego_admin_assign_vendor( (int) $req['id'], $vid, get_current_user_id(), $reason, (int) ( $j['lead_id'] ?? 0 ) ), 'assign_failed' );
}

// TRACE: POST replace-assignment → admin changes driver/vehicle on an assigned trip → response|400.
function ridego_mkt_a_replace( WP_REST_Request $req ) { $j = ridego_mkt_body( $req ); return ridego_mkt_result( ridego_replace_assignment( (int) $req['id'], $j, get_current_user_id(), 'admin', sanitize_text_field( $j['reason'] ?? '' ) ) ); }
// TRACE: POST reopen {reason} → clears the vendor and redistributes → response|400.
function ridego_mkt_a_reopen( WP_REST_Request $req ) { $j = ridego_mkt_body( $req ); return ridego_mkt_result( ridego_reopen_booking_for_reassignment( (int) $req['id'], get_current_user_id(), sanitize_text_field( $j['reason'] ?? '' ) ) ); }
// TRACE: POST report-issue {type:'no_show'} → records the issue (and reopens only when the automatic_reassignment flag is on) → response|400.
function ridego_mkt_a_report_issue( WP_REST_Request $req ) {
    $j = ridego_mkt_body( $req );
    if ( ( $j['type'] ?? '' ) !== 'no_show' ) { return new WP_Error( 'invalid_input', 'Unknown issue type.', array( 'status' => 400 ) ); }
    return ridego_mkt_result( ridego_report_no_show( (int) $req['id'], sanitize_text_field( $j['notes'] ?? '' ) ) );
}

// TRACE: POST bulk {action: cancel|reopen, ids[], reason} → applies the canonical single-booking function to each id
//        (max 50) and returns per-id results; never a partial-success lie → response {results:[{id,success,message}], ok, failed}.
//        Edge cases: empty/oversized ids (400), unknown action (400), one failure does not stop the rest.
function ridego_mkt_a_bulk( WP_REST_Request $req ) {
    $j = ridego_mkt_body( $req );
    $ids = array_values( array_unique( array_filter( array_map( 'intval', (array) ( $j['ids'] ?? array() ) ) ) ) );
    $action = sanitize_key( $j['action'] ?? '' ); $reason = sanitize_text_field( $j['reason'] ?? '' );
    if ( ! $ids || count( $ids ) > 50 ) { return new WP_Error( 'invalid_input', 'Select between 1 and 50 bookings.', array( 'status' => 400 ) ); }
    if ( ! in_array( $action, array( 'cancel', 'reopen' ), true ) ) { return new WP_Error( 'invalid_input', 'Unknown bulk action.', array( 'status' => 400 ) ); }
    if ( $reason === '' ) { return new WP_Error( 'invalid_input', 'A reason is required for bulk actions.', array( 'status' => 400 ) ); }
    $results = array(); $ok = 0;
    foreach ( $ids as $id ) {
        $r = $action === 'cancel' ? ridego_cancel_booking( $id, $reason, 'admin' ) : ridego_reopen_booking_for_reassignment( $id, get_current_user_id(), $reason );
        $s = ! empty( $r['success'] );
        if ( $s ) { $ok++; }
        $results[] = array( 'id' => $id, 'success' => $s, 'message' => isset( $r['message'] ) ? $r['message'] : ( $s ? 'Done.' : 'Failed.' ) );
    }
    ridego_audit_log( 'bulk_' . $action, 'booking', 0, null, array( 'ids' => $ids, 'reason' => $reason, 'ok' => $ok ), 'warning' );
    return rest_ensure_response( array( 'results' => $results, 'ok' => $ok, 'failed' => count( $ids ) - $ok ) );
}

// TRACE: POST lead request-driver-details → notify vendor → response|400.
function ridego_mkt_a_lead_request( WP_REST_Request $req ) { return ridego_mkt_result( ridego_lead_request_driver_details( (int) $req['id'], get_current_user_id() ) ); }
// TRACE: POST lead reject {reason} → mark not selected → response|400.
function ridego_mkt_a_lead_reject( WP_REST_Request $req ) { $j = ridego_mkt_body( $req ); return ridego_mkt_result( ridego_lead_admin_reject( (int) $req['id'], $j['reason'] ?? '', get_current_user_id() ) ); }

// TRACE: GET vendor fleet → type, vehicles, drivers, branches and docs of one vendor (read-only) → response|404.
function ridego_mkt_a_vendor_fleet( WP_REST_Request $req ) {
    $v = ridego_get_vendor( (int) $req['id'] );
    if ( ! $v ) { return new WP_Error( 'not_found', 'Vendor not found.', array( 'status' => 404 ) ); }
    return rest_ensure_response( array( 'vendor_type' => ridego_get_vendor_type( $v ), 'vehicles' => ridego_get_fleet_vehicles( $v->id ), 'drivers' => array_map( function ( $x ) { $a = (array) $x; $a['profile_missing'] = ridego_driver_missing_fields( $x ); $a['profile_complete'] = ! $a['profile_missing']; return $a; }, ridego_get_fleet_drivers( $v->id ) ),
        'branches' => ridego_get_vendor_branches( $v->id ), 'docs' => ridego_get_fleet_docs( $v->id ) ) );
}
// TRACE: POST vendor type {type} → admin changes vendor type via the guarded domain function → response|400.
function ridego_mkt_a_vendor_type( WP_REST_Request $req ) { $j = ridego_mkt_body( $req ); return ridego_mkt_result( ridego_set_vendor_type( (int) $req['id'], sanitize_key( $j['type'] ?? '' ) ) ); }

// TRACE: commission model list → models + types + refund modes → response.
function ridego_mkt_a_models_list( WP_REST_Request $req ) { return rest_ensure_response( array( 'rows' => ridego_list_commission_models(), 'types' => ridego_commission_types(), 'plans' => ridego_mkt_subscription_plans(), 'refund_modes' => ridego_commission_refund_modes() ) ); }
// TRACE: commission model create → domain validate+insert → response|400.
function ridego_mkt_a_model_create( WP_REST_Request $req ) { return ridego_mkt_result( ridego_create_commission_model( ridego_mkt_body( $req ), get_current_user_id() ) ); }
// TRACE: commission model update → domain → response|400.
function ridego_mkt_a_model_update( WP_REST_Request $req ) { return ridego_mkt_result( ridego_update_commission_model( (int) $req['id'], ridego_mkt_body( $req ), get_current_user_id() ) ); }
// TRACE: commission assign {vendor_id, model_id} → domain → response|400.
function ridego_mkt_a_model_assign( WP_REST_Request $req ) { $j = ridego_mkt_body( $req ); return ridego_mkt_result( ridego_assign_commission_model( (int) ( $j['vendor_id'] ?? 0 ), (int) ( $j['model_id'] ?? 0 ), get_current_user_id(), ! empty( $j['subscribe'] ) ) ); }

// TRACE: GET ledger?vendor_id&status&page → paginated ledger rows with booking number + vendor name, summary and platform
//        net → response. Edge cases: no rows.
function ridego_mkt_a_ledger( WP_REST_Request $req ) {
    global $wpdb;
    $lt = $wpdb->prefix . 'ridego_booking_ledger';
    $w = array( '1=1' ); $a = array();
    if ( (int) $req->get_param( 'vendor_id' ) ) { $w[] = 'l.vendor_id=%d'; $a[] = (int) $req->get_param( 'vendor_id' ); }
    $st = sanitize_key( (string) $req->get_param( 'status' ) );
    if ( in_array( $st, array( 'pending', 'settled' ), true ) ) { $w[] = 'l.status=%s'; $a[] = $st; }
    $from = sanitize_text_field( (string) $req->get_param( 'from' ) ); $to = sanitize_text_field( (string) $req->get_param( 'to' ) );
    if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) { $w[] = 'l.created_at>=%s'; $a[] = $from . ' 00:00:00'; } else { $from = ''; }
    if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) ) { $w[] = 'l.created_at<=%s'; $a[] = $to . ' 23:59:59'; } else { $to = ''; }
    $page = max( 1, (int) $req->get_param( 'page' ) ); $per = 30;
    $where = implode( ' AND ', $w );
    $total = (int) ( $a ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$lt} l WHERE {$where}", $a ) ) : $wpdb->get_var( "SELECT COUNT(*) FROM {$lt} l WHERE {$where}" ) );
    $sql = "SELECT l.*, b.booking_number, v.business_name FROM {$lt} l LEFT JOIN {$wpdb->prefix}ridego_bookings b ON b.id=l.booking_id LEFT JOIN {$wpdb->prefix}ridego_vendors v ON v.id=l.vendor_id WHERE {$where} ORDER BY l.id DESC LIMIT %d OFFSET %d";
    $rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $a, array( $per, ( $page - 1 ) * $per ) ) ), ARRAY_A );
    return rest_ensure_response( array( 'rows' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $per, 'summary' => ridego_ledger_summary( (int) $req->get_param( 'vendor_id' ), $st, $from, $to ),
        'platform' => ridego_ledger_platform_net( $from, $to ) ) );
}
// TRACE: POST settle {booking_id} → domain settle → response|400.
function ridego_mkt_a_settle( WP_REST_Request $req ) { $j = ridego_mkt_body( $req ); return ridego_mkt_result( ridego_ledger_settle_booking( (int) ( $j['booking_id'] ?? 0 ), get_current_user_id() ) ); }

// TRACE: GET performance?vendor_id → with vendor_id: full detail; without: latest-month snapshot per vendor, ranked by
//        score → response. Edge cases: no snapshots (empty list).
function ridego_mkt_a_performance( WP_REST_Request $req ) {
    global $wpdb;
    $vid = (int) $req->get_param( 'vendor_id' );
    if ( $vid ) {
        if ( ! ridego_get_vendor( $vid ) ) { return new WP_Error( 'not_found', 'Vendor not found.', array( 'status' => 404 ) ); }
        return rest_ensure_response( ridego_get_vendor_performance_detail( $vid ) );
    }
    $rows = $wpdb->get_results( "SELECT s.*, v.business_name, v.vendor_type FROM {$wpdb->prefix}ridego_performance_snapshots s JOIN {$wpdb->prefix}ridego_vendors v ON v.id=s.entity_id
        WHERE s.entity_type='vendor' AND s.period=(SELECT MAX(period) FROM {$wpdb->prefix}ridego_performance_snapshots WHERE entity_type='vendor') ORDER BY s.avg_rating DESC, s.bookings_completed DESC, s.id DESC LIMIT 200", ARRAY_A );
    return rest_ensure_response( array( 'rows' => $rows ) );
}

// TRACE: GET matching → the four flags, active profile, every stored profile version, factor list, threshold and recent
//        recommendation outcomes (with vendor names) → response. Read-only.
function ridego_mkt_a_matching_get( WP_REST_Request $req ) {
    global $wpdb;
    $flags = array(); foreach ( ridego_matching_flag_names() as $f ) { $flags[ $f ] = ridego_matching_flag( $f ); }
    $recent = $wpdb->get_results( "SELECT r.*, b.booking_number, v.business_name AS vendor_name FROM {$wpdb->prefix}ridego_matching_recommendations r LEFT JOIN {$wpdb->prefix}ridego_bookings b ON b.id=r.booking_id LEFT JOIN {$wpdb->prefix}ridego_vendors v ON v.id=r.recommended_vendor_id ORDER BY r.id DESC LIMIT 30", ARRAY_A );
    return rest_ensure_response( array( 'flags' => $flags, 'profile' => ridego_matching_get_active_profile(), 'profiles' => ridego_matching_list_profiles(), 'factors' => ridego_matching_factors(), 'recent' => $recent,
        'auto_assign_min_score' => (float) ridego_get_setting( 'matching_auto_assign_min_score', 70 ) ) );
}
// TRACE: POST flags {automatic_vendor_assignment?, automatic_driver_selection?, performance_based_matching?, automatic_reassignment?,
//        auto_assign_min_score?} → writes each supplied flag as 0/1 → audits → response. Edge cases: unknown keys ignored;
//        min score clamped 0..100.
function ridego_mkt_a_matching_flags( WP_REST_Request $req ) {
    $j = ridego_mkt_body( $req ); $changed = array();
    foreach ( ridego_matching_flag_names() as $f ) {
        if ( array_key_exists( $f, $j ) ) { ridego_update_setting( $f, empty( $j[ $f ] ) ? 0 : 1 ); $changed[ $f ] = empty( $j[ $f ] ) ? 0 : 1; }
    }
    if ( isset( $j['auto_assign_min_score'] ) ) { $s = max( 0, min( 100, (float) $j['auto_assign_min_score'] ) ); ridego_update_setting( 'matching_auto_assign_min_score', $s ); $changed['auto_assign_min_score'] = $s; }
    ridego_audit_log( 'matching_flags_changed', 'matching', 0, null, $changed, 'warning' );
    return ridego_mkt_a_matching_get( $req );
}
// TRACE: POST profile {name, weights{factor:number}} → saves a NEW normalised INACTIVE version → response|400.
function ridego_mkt_a_matching_profile( WP_REST_Request $req ) { $j = ridego_mkt_body( $req ); return ridego_mkt_result( ridego_matching_save_profile( $j['name'] ?? 'Custom', (array) ( $j['weights'] ?? array() ) ) ); }
// TRACE: POST profile/:id/activate → makes that stored version the active one → response|400.
function ridego_mkt_a_matching_activate( WP_REST_Request $req ) { return ridego_mkt_result( ridego_matching_activate_profile( (int) $req['id'] ) ); }
// TRACE: POST backtest {weights} or {profile_id} → replays those weights against completed bookings (read-only) → response|400.
function ridego_mkt_a_matching_backtest( WP_REST_Request $req ) {
    $j = ridego_mkt_body( $req );
    if ( ! empty( $j['profile_id'] ) ) {
        $p = ridego_matching_get_profile( (int) $j['profile_id'] );
        if ( ! $p ) { return new WP_Error( 'not_found', 'Weight profile not found.', array( 'status' => 404 ) ); }
        return rest_ensure_response( ridego_matching_backtest( $p['weights'] ) );
    }
    return rest_ensure_response( ridego_matching_backtest( (array) ( $j['weights'] ?? ridego_matching_default_weights() ) ) );
}

// TRACE: POST impersonate {user_id} → start view-as session → response|400. The SPA must reload afterwards to pick up
//        a nonce for the effective user.
function ridego_mkt_a_impersonate( WP_REST_Request $req ) { $j = ridego_mkt_body( $req ); return ridego_mkt_result( ridego_impersonation_start( get_current_user_id(), (int) ( $j['user_id'] ?? 0 ) ) ); }
// TRACE: POST impersonate/stop → end the session (real admin restored on next request) → response.
function ridego_mkt_a_impersonate_stop( WP_REST_Request $req ) { return rest_ensure_response( ridego_impersonation_stop( 'stopped' ) ); }

// TRACE: GET reports/marketplace?from&to → funnel (bookings→leads→interest→assigned→completed), avg minutes to first
//        interest and to assignment, cancellations by cancelled_by, commission by vendor, fleet vs individual
//        volume → response. Read-only. Edge cases: empty range (zeros).
function ridego_mkt_a_report( WP_REST_Request $req ) {
    global $wpdb;
    $from = sanitize_text_field( (string) $req->get_param( 'from' ) ) ?: date( 'Y-m-d', strtotime( '-30 days' ) );
    $to   = sanitize_text_field( (string) $req->get_param( 'to' ) ) ?: current_time( 'Y-m-d' );
    $bt = $wpdb->prefix . 'ridego_bookings'; $lt = $wpdb->prefix . 'ridego_leads'; $vt = $wpdb->prefix . 'ridego_vendors'; $ll = $wpdb->prefix . 'ridego_booking_ledger';
    $rng = array( $from . ' 00:00:00', $to . ' 23:59:59' );
    $c = function ( $sql, $args ) use ( $wpdb ) { return (int) $wpdb->get_var( $wpdb->prepare( $sql, $args ) ); };
    $funnel = array(
        'bookings'  => $c( "SELECT COUNT(*) FROM {$bt} WHERE created_at BETWEEN %s AND %s", $rng ),
        'with_leads' => $c( "SELECT COUNT(DISTINCT l.booking_id) FROM {$lt} l JOIN {$bt} b ON b.id=l.booking_id WHERE b.created_at BETWEEN %s AND %s", $rng ),
        'with_interest' => $c( "SELECT COUNT(DISTINCT l.booking_id) FROM {$lt} l JOIN {$bt} b ON b.id=l.booking_id WHERE l.interested_at IS NOT NULL AND b.created_at BETWEEN %s AND %s", $rng ),
        'assigned'  => $c( "SELECT COUNT(*) FROM {$bt} WHERE vendor_id IS NOT NULL AND created_at BETWEEN %s AND %s", $rng ),
        'completed' => $c( "SELECT COUNT(*) FROM {$bt} WHERE status='completed' AND created_at BETWEEN %s AND %s", $rng ),
    );
    $resp = $wpdb->get_var( $wpdb->prepare( "SELECT ROUND(AVG(TIMESTAMPDIFF(MINUTE,l.sent_at,l.interested_at)),1) FROM {$lt} l WHERE l.interested_at IS NOT NULL AND l.sent_at BETWEEN %s AND %s", $rng ) );
    $cancel = $wpdb->get_results( $wpdb->prepare( "SELECT COALESCE(NULLIF(cancelled_by,''),'unknown') who, COUNT(*) n FROM {$bt} WHERE status IN ('cancelled','token_refund_due') AND created_at BETWEEN %s AND %s GROUP BY who", $rng ), ARRAY_A );
    $comm = $wpdb->get_results( $wpdb->prepare( "SELECT v.id vendor_id, v.business_name, SUM(CASE WHEN l.entry_type IN ('commission','lead_fee','lead_fee_retained') THEN l.amount ELSE 0 END) commission, COUNT(DISTINCT l.booking_id) bookings FROM {$ll} l JOIN {$vt} v ON v.id=l.vendor_id WHERE l.created_at BETWEEN %s AND %s GROUP BY v.id ORDER BY commission DESC LIMIT 25", $rng ), ARRAY_A );
    $types = $wpdb->get_results( $wpdb->prepare( "SELECT COALESCE(NULLIF(v.vendor_type,''),'fleet') vendor_type, COUNT(*) bookings FROM {$bt} b JOIN {$vt} v ON v.id=b.vendor_id WHERE b.created_at BETWEEN %s AND %s GROUP BY vendor_type", $rng ), ARRAY_A );
    return rest_ensure_response( array( 'from' => $from, 'to' => $to, 'funnel' => $funnel, 'avg_minutes_to_interest' => $resp !== null ? (float) $resp : null, 'cancellations' => $cancel, 'commission_by_vendor' => $comm, 'volume_by_vendor_type' => $types ) );
}

// TRACE: commission model form → active subscription plans (id, name, price, cycle) for the subscription_hybrid selector → array.
//        Edge cases: none defined (empty array).
function ridego_mkt_subscription_plans() {
    global $wpdb;
    $rows = $wpdb->get_results( "SELECT id, name, price, billing_cycle FROM {$wpdb->prefix}ridego_subscription_plans WHERE is_active=1 ORDER BY sort_order ASC, id ASC", ARRAY_A );
    return $rows ? $rows : array();
}

/* ================================================================
   Fleet-wide document-expiry dashboard (P1 next-target from 17.29/17.30).
   Cross-vendor view for Operations/Regional Manager: every fleet document
   currently expired or expiring within the configurable window, across
   every vendor, sorted most-urgent first — so nobody has to open each
   vendor's fleet tab one at a time to catch a lapsed permit or license.
   ================================================================ */

// TRACE: GET admin/fleet/document-expiry (?days=30&vendor_id=&status=expired|expiring_soon) → every
//        row in ridego_driver_docs whose validity (ridego_doc_validity, same single source of truth
//        the per-vendor fleet tab already uses) is 'expired' or 'expiring_soon' within the requested
//        window, joined to its vehicle/driver and vendor for display, sorted expiry_date ASC (most
//        urgent first; NULL/rejected docs are excluded, not just filtered by validity, since a
//        rejected upload isn't "on file" in any actionable sense) → { rows:[...], summary:{expired,
//        expiring_soon}, days }. Preconditions: caller holds ridego_view_fleets (same admin cap the
//        per-vendor fleet view already requires — no new capability introduced). Postconditions:
//        read-only; touches no data. Edge cases: ?days beyond 30 still only flags docs the DB query
//        itself considers due (expiry_date <= today+days AND expiry_date IS NOT NULL), 'valid'/
//        'no_expiry' docs are never returned regardless of ?days; ?vendor_id narrows to one vendor
//        without changing the cross-vendor default; a doc with both vehicle_id and driver_id NULL
//        (shouldn't exist per the upload endpoints, but not database-enforced) is excluded via the
//        same WHERE the per-vendor ridego_get_fleet_docs() already applies.
function ridego_mkt_a_document_expiry( WP_REST_Request $req ) {
    global $wpdb;
    $days = (int) $req->get_param( 'days' );
    if ( $days <= 0 ) { $days = 30; }
    $days = min( $days, 365 );
    $vendor_id = (int) $req->get_param( 'vendor_id' );
    $status_filter = sanitize_key( (string) $req->get_param( 'status' ) );
    $cutoff = date( 'Y-m-d', strtotime( "+{$days} days" ) );
    $today = date( 'Y-m-d' );

    $dt = $wpdb->prefix . 'ridego_driver_docs';
    $vt = $wpdb->prefix . 'ridego_vendors';
    $veht = $wpdb->prefix . 'ridego_fleet_vehicles';
    $drt = $wpdb->prefix . 'ridego_fleet_drivers';

    $sql = "SELECT d.id, d.vendor_id, d.doc_type, d.expiry_date, d.status, d.vehicle_id, d.driver_id,
                   v.business_name AS vendor_name,
                   veh.registration_number, veh.make_model,
                   drv.name AS driver_name, drv.mobile AS driver_mobile
            FROM {$dt} d
            LEFT JOIN {$vt} v ON v.id = d.vendor_id
            LEFT JOIN {$veht} veh ON veh.id = d.vehicle_id
            LEFT JOIN {$drt} drv ON drv.id = d.driver_id
            WHERE d.expiry_date IS NOT NULL
              AND d.expiry_date <= %s
              AND d.status <> 'rejected'
              AND ( d.vehicle_id IS NOT NULL OR d.driver_id IS NOT NULL )";
    $args = array( $cutoff );
    if ( $vendor_id ) { $sql .= ' AND d.vendor_id = %d'; $args[] = $vendor_id; }
    $sql .= ' ORDER BY d.expiry_date ASC';

    $rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
    $out = array(); $expired = 0; $expiring_soon = 0;
    foreach ( (array) $rows as $r ) {
        $validity = ridego_doc_validity( $r['expiry_date'] );
        if ( $validity === 'expired' ) { $expired++; } elseif ( $validity === 'expiring_soon' ) { $expiring_soon++; } else { continue; }
        if ( $status_filter && $status_filter !== $validity ) { continue; }
        $entity_type = $r['vehicle_id'] ? 'vehicle' : 'driver';
        $entity_label = $entity_type === 'vehicle'
            ? trim( ( $r['registration_number'] ?? '' ) . ( $r['make_model'] ? ' (' . $r['make_model'] . ')' : '' ) )
            : trim( ( $r['driver_name'] ?? '' ) . ( $r['driver_mobile'] ? ' (' . $r['driver_mobile'] . ')' : '' ) );
        $out[] = array(
            'doc_id' => (int) $r['id'],
            'vendor_id' => (int) $r['vendor_id'],
            'vendor_name' => $r['vendor_name'],
            'doc_type' => $r['doc_type'],
            'expiry_date' => $r['expiry_date'],
            'validity' => $validity,
            'days_until_expiry' => (int) floor( ( strtotime( $r['expiry_date'] ) - strtotime( $today ) ) / DAY_IN_SECONDS ),
            'entity_type' => $entity_type,
            'entity_id' => (int) ( $r['vehicle_id'] ?: $r['driver_id'] ),
            'entity_label' => $entity_label !== '' ? $entity_label : '(unnamed)',
        );
    }
    return rest_ensure_response( array( 'rows' => $out, 'summary' => array( 'expired' => $expired, 'expiring_soon' => $expiring_soon ), 'days' => $days ) );
}
