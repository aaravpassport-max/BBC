<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Notifications Center
   ------------------------------------------------------------
   Covers admin/pages/notifications.php in full: the 4 KPI tiles
   (sent / pending / retrying / dead_letter), the per-channel
   delivery success-rate breakdown, the broadcast-send form (all
   vendors / active vendors only / specific booking), the filtered
   + paginated recent-queue view, and the dead-letter review view
   with retry/discard actions.

   This is a completely separate feature from the customer/vendor-
   facing notification inbox in includes/app-api.php
   (/ridego/v1/app/notifications) — do not confuse the two. This
   file only registers routes under /ridego/v1/app/admin/notifications/*.

   Every query and every piece of business logic below is copied
   verbatim from admin/pages/notifications.php, including:
     - the exact KPI SQL (status='sent', status='pending', status=
       'pending' AND attempts>0, status='dead_letter')
     - the per-channel GROUP BY channel,status breakdown and success
       rate formula (sent / total * 100, rounded to 1 decimal)
     - broadcast enqueue logic: all_vendors/active_vendors targets
       queue one notification per matching vendor's user_id via the
       existing ridego_queue_notification() helper (includes/lead.php)
       used exactly as-is; booking_id target looks up the booking via
       ridego_get_booking() and queues to its client_id, erroring
       clearly when the booking has no client
     - the audit-log calls, using the exact same action names as the
       legacy page: 'notification_broadcast_queued',
       'notification_dlq_retry', 'notification_dlq_discard'
     - the dead-letter retry field reset: status=pending, attempts=0,
       next_retry_at=null, scheduled_for=now, and the exact same
       error_msg note ('Manually requeued from dead-letter review')
     - the dead-letter discard: status=discarded only

   Every route requires is_user_logged_in() AND
   ridego_can('ridego_send_bulk_message') — the exact capability
   admin/pages/notifications.php already requires (see its render
   function's own defense-in-depth check).
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_notifications_api_routes' );
function ridego_register_app_admin_notifications_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/notifications/stats', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_notifications_stats',
        'permission_callback' => 'ridego_app_admin_api_notifications_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/notifications/queue', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_notifications_queue',
        'permission_callback' => 'ridego_app_admin_api_notifications_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/notifications/dead-letter', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_notifications_dead_letter',
        'permission_callback' => 'ridego_app_admin_api_notifications_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/notifications/broadcast', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_notifications_broadcast',
        'permission_callback' => 'ridego_app_admin_api_notifications_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/notifications/(?P<id>\d+)/retry', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_notifications_retry',
        'permission_callback' => 'ridego_app_admin_api_notifications_permission',
        'args'                => array( 'id' => array( 'validate_callback' => function ( $v ) { return is_numeric( $v ); } ) ),
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/notifications/(?P<id>\d+)/discard', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_notifications_discard',
        'permission_callback' => 'ridego_app_admin_api_notifications_permission',
        'args'                => array( 'id' => array( 'validate_callback' => function ( $v ) { return is_numeric( $v ); } ) ),
    ) );
}

function ridego_app_admin_api_notifications_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_send_bulk_message' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to send notifications.', array( 'status' => 403 ) );
    }
    return true;
}

/** KPI tiles + per-channel success-rate breakdown — copied verbatim from admin/pages/notifications.php:62-82. */
function ridego_app_admin_api_notifications_stats( WP_REST_Request $req ) {
    global $wpdb;
    $qtbl = $wpdb->prefix . 'ridego_notification_queue';

    $stats = array(
        'sent'        => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $qtbl WHERE status='sent'" ),
        'retrying'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $qtbl WHERE status='pending' AND attempts>0" ),
        'pending'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $qtbl WHERE status='pending'" ),
        'dead_letter' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $qtbl WHERE status='dead_letter'" ),
    );

    $channel_rows = $wpdb->get_results(
        "SELECT channel, status, COUNT(*) AS cnt FROM {$qtbl} GROUP BY channel, status"
    );
    $channel_stats = array();
    foreach ( $channel_rows as $r ) {
        $ch = $r->channel ?: 'unknown';
        if ( ! isset( $channel_stats[ $ch ] ) ) {
            $channel_stats[ $ch ] = array( 'channel' => $ch, 'sent' => 0, 'pending' => 0, 'dead_letter' => 0, 'other' => 0, 'total' => 0 );
        }
        $key = in_array( $r->status, array( 'sent', 'pending', 'dead_letter' ), true ) ? $r->status : 'other';
        $channel_stats[ $ch ][ $key ]  += (int) $r->cnt;
        $channel_stats[ $ch ]['total'] += (int) $r->cnt;
    }

    $channels = array();
    foreach ( $channel_stats as $ch => $s ) {
        $rate = $s['total'] > 0 ? round( ( $s['sent'] / $s['total'] ) * 100, 1 ) : 0;
        $channels[] = array(
            'channel'          => $ch,
            'sent'             => $s['sent'],
            'pending_retrying' => $s['pending'],
            'dead_letter'      => $s['dead_letter'],
            'total'            => $s['total'],
            'success_rate'     => $rate,
        );
    }

    return rest_ensure_response( array(
        'kpis'     => $stats,
        'channels' => $channels,
    ) );
}

function ridego_app_admin_api_notification_format( $q ) {
    return array(
        'id'           => (int) $q->id,
        'event'        => $q->event ?: 'notification',
        'status'       => $q->status ?: 'pending',
        'recipient'    => isset( $q->user_login ) && $q->user_login ? $q->user_login : ( '#' . (int) $q->recipient_id ),
        'recipient_id' => (int) $q->recipient_id,
        'channel'      => $q->channel,
        'attempts'     => (int) $q->attempts,
        'error_msg'    => $q->error_msg,
        'created_at'   => $q->created_at,
    );
}

/** Recent Queue tab — copied verbatim from admin/pages/notifications.php's ridego_render_queue_tab(). */
function ridego_app_admin_api_notifications_queue( WP_REST_Request $req ) {
    global $wpdb;
    $qtbl = $wpdb->prefix . 'ridego_notification_queue';
    $per  = 40;

    $paged     = max( 1, (int) $req->get_param( 'page' ) );
    $status_f  = sanitize_key( (string) $req->get_param( 'status' ) );
    $channel_f = sanitize_key( (string) $req->get_param( 'channel' ) );
    $event_f   = sanitize_text_field( (string) $req->get_param( 'event' ) );

    $where = array( '1=1' );
    $vals  = array();
    if ( $status_f )  { $where[] = 'status=%s'; $vals[] = $status_f; }
    if ( $channel_f ) { $where[] = 'channel=%s'; $vals[] = $channel_f; }
    if ( $event_f !== '' ) { $where[] = 'event LIKE %s'; $vals[] = '%' . $wpdb->esc_like( $event_f ) . '%'; }
    $where_sql = implode( ' AND ', $where );

    $total = $vals
        ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$qtbl} WHERE {$where_sql}", $vals ) )
        : (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$qtbl} WHERE {$where_sql}" );

    $offset = ( $paged - 1 ) * $per;
    $sql    = "SELECT q.*,u.user_login FROM {$qtbl} q LEFT JOIN {$wpdb->users} u ON u.ID=q.recipient_id WHERE {$where_sql} ORDER BY q.created_at DESC LIMIT %d OFFSET %d";
    $qvals  = array_merge( $vals, array( $per, $offset ) );
    $rows   = $wpdb->get_results( $wpdb->prepare( $sql, $qvals ) );

    return rest_ensure_response( array(
        'rows'     => array_map( 'ridego_app_admin_api_notification_format', $rows ),
        'total'    => $total,
        'page'     => $paged,
        'per_page' => $per,
    ) );
}

/** Dead Letter tab — copied verbatim from admin/pages/notifications.php's ridego_render_dlq_tab() (100-row cap, full error). */
function ridego_app_admin_api_notifications_dead_letter( WP_REST_Request $req ) {
    global $wpdb;
    $qtbl = $wpdb->prefix . 'ridego_notification_queue';

    $rows = $wpdb->get_results( "SELECT q.*,u.user_login FROM {$qtbl} q LEFT JOIN {$wpdb->users} u ON u.ID=q.recipient_id WHERE q.status='dead_letter' ORDER BY q.created_at DESC LIMIT 100" );

    return rest_ensure_response( array(
        'rows' => array_map( 'ridego_app_admin_api_notification_format', $rows ),
    ) );
}

/**
 * Send Broadcast Notification — copied verbatim from admin/pages/
 * notifications.php's broadcast handler. Enqueue-only, never sends
 * synchronously; delivery happens via ridego_process_notification_queue()
 * on the every_5_minutes cron.
 */
function ridego_app_admin_api_notifications_broadcast( WP_REST_Request $req ) {
    global $wpdb;

    $target = sanitize_key( (string) $req->get_param( 'target' ) );
    $title  = sanitize_text_field( (string) $req->get_param( 'title' ) );
    $body   = sanitize_textarea_field( (string) $req->get_param( 'message' ) );

    if ( $title === '' || $body === '' ) {
        return new WP_Error( 'missing_fields', 'Title and message are required.', array( 'status' => 400 ) );
    }

    if ( $target === 'all_vendors' || $target === 'active_vendors' ) {
        $status_filter = $target === 'active_vendors' ? "WHERE status='active'" : "WHERE status IN ('active','pending')";
        $vids = $wpdb->get_col( "SELECT user_id FROM {$wpdb->prefix}ridego_vendors {$status_filter}" );
        $queued = 0;
        foreach ( $vids as $uid ) {
            if ( ! $uid ) { continue; }
            if ( ridego_queue_notification( $uid, 'admin_broadcast', array( 'title' => $title, 'body' => $body ) ) ) {
                $queued++;
            }
        }
        ridego_audit_log( 'notification_broadcast_queued', 'vendor', 0, '', 'target=' . $target . ' count=' . $queued );

        return rest_ensure_response( array(
            'success' => true,
            'message' => 'Queued ' . $queued . ' notifications for delivery.',
            'queued'  => $queued,
        ) );
    } elseif ( $target === 'booking_id' ) {
        $bid = absint( $req->get_param( 'booking_id' ) );
        $b   = ridego_get_booking( $bid );
        if ( $b && ! empty( $b->client_id ) ) {
            ridego_queue_notification( $b->client_id, 'admin_note', array( 'title' => $title, 'body' => $body, 'booking_id' => $bid ) );
            ridego_audit_log( 'notification_broadcast_queued', 'booking', $bid, '', 'admin_note' );

            return rest_ensure_response( array(
                'success' => true,
                'message' => 'Notification queued for booking ' . $b->booking_number . '.',
                'queued'  => 1,
            ) );
        }

        return new WP_Error( 'booking_not_found', 'Booking not found or has no client.', array( 'status' => 404 ) );
    }

    return new WP_Error( 'invalid_target', 'Invalid target audience.', array( 'status' => 400 ) );
}

/**
 * Dead-letter Retry Now — copied verbatim from admin/pages/
 * notifications.php's rga_dlq_action='retry' branch: exact same
 * field resets and audit-log action name.
 */
function ridego_app_admin_api_notifications_retry( WP_REST_Request $req ) {
    global $wpdb;
    $qtbl = $wpdb->prefix . 'ridego_notification_queue';
    $qid  = (int) $req->get_param( 'id' );

    $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$qtbl} WHERE id=%d AND status='dead_letter'", $qid ) );
    if ( ! $row ) {
        return new WP_Error( 'not_found', 'Dead-letter notification not found.', array( 'status' => 404 ) );
    }

    $wpdb->update( $qtbl, array(
        'status'        => 'pending',
        'attempts'      => 0,
        'next_retry_at' => null,
        'scheduled_for' => current_time( 'mysql' ),
        'error_msg'     => 'Manually requeued from dead-letter review',
    ), array( 'id' => $qid ) );

    ridego_audit_log( 'notification_dlq_retry', 'notification_queue', $qid, 'dead_letter', 'pending' );

    return rest_ensure_response( array( 'success' => true, 'message' => 'Notification #' . $qid . ' requeued.' ) );
}

/**
 * Dead-letter Discard — copied verbatim from admin/pages/
 * notifications.php's rga_dlq_action='discard' branch.
 */
function ridego_app_admin_api_notifications_discard( WP_REST_Request $req ) {
    global $wpdb;
    $qtbl = $wpdb->prefix . 'ridego_notification_queue';
    $qid  = (int) $req->get_param( 'id' );

    $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$qtbl} WHERE id=%d AND status='dead_letter'", $qid ) );
    if ( ! $row ) {
        return new WP_Error( 'not_found', 'Dead-letter notification not found.', array( 'status' => 404 ) );
    }

    $wpdb->update( $qtbl, array( 'status' => 'discarded' ), array( 'id' => $qid ) );

    ridego_audit_log( 'notification_dlq_discard', 'notification_queue', $qid, 'dead_letter', 'discarded' );

    return rest_ensure_response( array( 'success' => true, 'message' => 'Notification #' . $qid . ' discarded.' ) );
}
