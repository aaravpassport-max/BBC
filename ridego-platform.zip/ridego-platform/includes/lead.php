<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   LEAD DISTRIBUTION ENGINE
   ============================================================ */

/*  Triggered when booking is confirmed  */
add_action('ridego_booking_confirmed', 'ridego_distribute_leads');
// TRACE: hook ridego_booking_confirmed → skips already-assigned bookings, picks eligible vendors, inserts one lead row per vendor with the mode-aware response window, queues vendor_new_lead notifications and schedules the expiry check → void.
//        Preconditions: booking exists → Postconditions: >=1 lead rows in status 'sent' or booking status 'no_vendor' → Edge cases: booking has vendor, no eligible vendors (admin alerted), per-vendor lead fee.
function ridego_distribute_leads( $booking_id ) {
    global $wpdb;
    $booking = ridego_get_booking($booking_id);
    if (!$booking) return;

    /* Root-cause fix: this used to run unconditionally on every
       'ridego_booking_confirmed' (i.e. every payment verification),
       even for a booking that already has a vendor manually assigned
       (e.g. via the admin's "Assign Driver Manually" flow before the
       payment proof is verified). Finding zero *additional* eligible
       vendors in that case would fall into the "no vendors found"
       branch below and overwrite the booking's status to 'no_vendor',
       clobbering the correct 'vendor_assigned' status and silently
       discarding the assignment from the customer/vendor's point of
       view. A vendor already committed to the booking means lead
       distribution has nothing to do here. */
    if ( ! empty( $booking->vendor_id ) ) {
        return;
    }

    /* Get eligible vendors (scored and filtered) */
    $eligible  = ridego_get_eligible_vendors($booking_id);
    $max_send  = (int)ridego_get_setting('lead_max_vendors', 5);
    $to_notify = array_slice($eligible, 0, $max_send);

    if (empty($to_notify)) {
        /* No vendors found  alert admin immediately */
        ridego_alert_no_vendor($booking_id);
        $wpdb->update($wpdb->prefix.'ridego_bookings', array('status'=>'no_vendor'), array('id'=>$booking_id));
        return;
    }

    $accept_mins = ridego_lead_window_minutes();
    $expires_at  = date('Y-m-d H:i:s', strtotime("+{$accept_mins} minutes"));

    foreach ($to_notify as $vendor) {
        // Per-vendor lead fee: an active subscription's lead_discount
        // applies per-vendor, so this is computed inside the loop rather
        // than once for the whole batch.
        $lead_fee = ridego_calculate_lead_fee_for_booking($booking_id, $vendor->id);
        $lf_row = ridego_lead_fee_lead_columns( $booking, (int) $vendor->id );
        $lead_row = array(
            'booking_id' => $booking_id,
            'vendor_id'  => $vendor->id,
            'sent_at'    => current_time('mysql'),
            'expires_at' => $expires_at,
            'status'     => 'sent',
            'fee_amount' => $lead_fee,
        ) + $lf_row['columns'];
        if ( $lf_row['applies'] ) { $lead_fee = $lf_row['fee']; }
        $wpdb->insert($wpdb->prefix.'ridego_leads', $lead_row);
        /* Root-cause fix: total_leads_received must count every lead SENT
           to a vendor (it is the denominator of accept_rate in
           ridego_score_vendor()), not just the ones the vendor actively
           rejected. Previously this was only incremented in
           ridego_reject_lead(), so an accepted-on-first-try vendor never
           had it incremented at all, letting accept_rate =
           total_leads_accepted / total_leads_received exceed 1.0 and blow
           past its intended 20-point cap. Incrementing once here, at
           send time, makes it the true "how many leads has this vendor
           ever been offered" counter regardless of how they respond. */
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}ridego_vendors SET total_leads_received=total_leads_received+1 WHERE id=%d", $vendor->id
        ));
        /* Queue notification (via cron queue  non-blocking) */
        ridego_queue_notification(array(
            'recipient_id'    => $vendor->user_id,
            'recipient_type'  => 'vendor',
            'recipient_phone' => $vendor->whatsapp_number ?: $vendor->phone,
            'recipient_email' => $vendor->email,
            'event'           => 'vendor_new_lead',
            'payload'         => array(
                'booking_id'      => $booking_id,
                'booking_number'  => $booking->booking_number,
                'pickup_city'     => $booking->pickup_city,
                'drop_city'       => $booking->drop_city,
                'journey_date'    => ridego_format_date($booking->journey_date),
                'journey_time'    => $booking->journey_time,
                'vehicle_name'    => $booking->vehicle_name,
                'passengers'      => $booking->passengers,
                'total_fare'      => ridego_money($booking->total_fare),
                'token_amount'    => ridego_money(ridego_booking_platform_amount($booking)),
                'remaining_amount'=> ridego_money(max(0, (float)$booking->total_fare - ridego_booking_platform_amount($booking))),
                'lead_fee'        => ridego_money($lead_fee),
                'lead_fee_note'   => $lf_row['applies'] ? $lf_row['description'] : '',
                'accept_minutes'  => $accept_mins,
                // ROOT-CAUSE FIX: this used to point at
                // '/vendor-dashboard/?action=accept_lead&lead_id=...' —
                // a URL-based accept action that no PHP code anywhere
                // ever actually handled (confirmed by grep: no
                // $_GET['action']==='accept_lead' handler exists or
                // ever existed). A lead is accepted by tapping
                // "Accept lead" inside the vendor dashboard (a REST
                // call, not a URL param), so this link now takes the
                // vendor straight to the live dashboard where the
                // real lead — and a working Accept button — is.
                'accept_url'      => home_url( '/vendor/dashboard/' ),
            ),
            'scheduled_for'   => current_time('mysql'),
        ));
    }

    /* Schedule expiry check */
    wp_schedule_single_event(
        strtotime("+{$accept_mins} minutes"),
        'ridego_lead_expiry_check',
        array($booking_id)
    );

    ridego_telegram_alert(
        "<b>NEW BOOKING</b> #{$booking->booking_number}\n".
        "{$booking->pickup_city} -> {$booking->drop_city}\n".
        date('d M', strtotime($booking->journey_date)).' at '.$booking->journey_time."\n".
        "Est. fare: ".ridego_money($booking->total_fare)." | Customer advance: ".ridego_money(ridego_booking_platform_amount($booking))." | Lead Fee: ".ridego_money($lead_fee)."\n".
        "Sent to ".count($to_notify)." vendors"
    );
}

/*  Vendor accepts lead  -----------------------------------------------
    Root-cause fix for the highest-value race condition in the codebase:
    the old implementation read lead status / booking vendor_id / wallet
    balance with no locking, then wrote unconditionally — so two vendors
    racing to accept leads for the same booking (or a self-serve accept
    racing an admin manual assignment) could BOTH succeed, double-assign
    the booking, and/or double-deduct wallet fees with no way to unwind.

    Fix: a single transaction that
      1. SELECT ... FOR UPDATE locks the LEAD row first, then the
         BOOKING row (always lead-then-booking, a consistent lock
         order across all callers, to avoid deadlocking two concurrent
         accept attempts against different leads for the same booking).
      2. Re-checks status/expiry/assignment AFTER acquiring the locks
         (the earlier read, if any, is not trustworthy).
      3. Applies the lead UPDATE conditioned on status='sent' and the
         booking UPDATE conditioned on vendor_id IS NULL, checking
         rows_affected on each — a 0 means someone else already won the
         race, so we ROLLBACK and return a clean "no longer available"
         failure instead of silently doing nothing while returning
         success.
      4. Only deducts the wallet fee, via the canonical wallet function,
         AFTER both conditioned updates have succeeded — and if the
         wallet deduction itself fails (insufficient balance), the
         WHOLE transaction is rolled back so the lead/booking revert to
         their pre-accept state. No partial state is ever left behind.

   NOTE on nesting: ridego_vendor_deduct_wallet() is itself a full,
   self-contained transaction (see includes/helpers.php doc comment).
   MySQL/WordPress has no true nested transactions, so this function
   does NOT call it inside the lead/booking transaction — instead the
   lead/booking transaction is committed first (with the wallet fee not
   yet deducted, but atomically assigned), and the wallet debit runs
   immediately after as the outermost boundary for its own operation.
   If the wallet debit fails, this function explicitly reverses the
   lead/booking assignment in a small follow-up transaction, so the net
   externally-visible effect is identical to "the whole thing rolled
   back" — no vendor ever ends up assigned without a fee being held. */
// TRACE: legacy/instant-mode vendor accept → locks lead then booking, re-checks status/expiry/vendor/wallet, conditioned UPDATEs, inserts the immutable assignment row in the same transaction, then deducts the lead fee → array(success,message,...).
//        Preconditions: lead belongs to vendor → Postconditions: booking vendor_id set with exactly one current assignment row, or everything reverted → Edge cases: lost race, expired, inactive vendor, low wallet, assignment insert failure (ROLLBACK), wallet failure after commit (assignment closed, booking reopened).
function ridego_accept_lead( $lead_id, $vendor_id ) {
    global $wpdb;
    $lead_id   = (int) $lead_id;
    $vendor_id = (int) $vendor_id;
    $leads_tbl    = $wpdb->prefix.'ridego_leads';
    $bookings_tbl = $wpdb->prefix.'ridego_bookings';

    $wpdb->query('START TRANSACTION');

    /* Lock the lead first (consistent lock order: lead, then booking). */
    $lead = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$leads_tbl} WHERE id=%d AND vendor_id=%d FOR UPDATE", $lead_id, $vendor_id
    ));
    if (!$lead) {
        $wpdb->query('ROLLBACK');
        return array('success'=>false,'message'=>'Lead not found.');
    }
    if ($lead->status !== 'sent') {
        $wpdb->query('ROLLBACK');
        return array('success'=>false,'message'=>'This lead is no longer available.');
    }
    if (strtotime($lead->expires_at) < time()) {
        $wpdb->query('ROLLBACK');
        return array('success'=>false,'message'=>'This lead has expired.');
    }

    /* Now lock the booking row. */
    $booking = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$bookings_tbl} WHERE id=%d FOR UPDATE", $lead->booking_id
    ));
    if (!$booking || $booking->vendor_id) {
        $wpdb->query('ROLLBACK');
        return array('success'=>false,'message'=>'This booking has already been assigned.');
    }

    $vendor = ridego_get_vendor($vendor_id);
    if (!$vendor) {
        $wpdb->query('ROLLBACK');
        return array('success'=>false,'message'=>'Vendor not found.');
    }
    /* Re-check vendor status under the lock — a lead can still be sitting
       in 'sent' state up to lead_accept_minutes after it was sent, and the
       vendor may have been suspended/blacklisted by an admin in that
       window. Eligibility is enforced at distribution time
       (ridego_get_eligible_vendors), but that's not enough on its own:
       this is the actual accept-time gate. */
    if ($vendor->status !== 'active') {
        $wpdb->query('ROLLBACK');
        return array('success'=>false,'message'=>'Your account is not currently active. Please contact support.');
    }

    /* Fast-path balance check under the lock (final authoritative check
       happens inside the wallet function itself, after commit below). */
    if ($vendor->wallet_balance < $lead->fee_amount) {
        $wpdb->query('ROLLBACK');
        return array('success'=>false,'message'=>'Insufficient wallet balance. Please top up at least '.ridego_money($lead->fee_amount).' to accept this lead.');
    }

    /* Conditioned lead UPDATE — only succeeds if still 'sent'. */
    $wpdb->query($wpdb->prepare(
        "UPDATE {$leads_tbl} SET status='accepted', responded_at=%s WHERE id=%d AND status='sent'",
        current_time('mysql'), $lead_id
    ));
    if ((int)$wpdb->rows_affected === 0) {
        $wpdb->query('ROLLBACK');
        return array('success'=>false,'message'=>'This lead is no longer available.');
    }

    /* Conditioned booking UPDATE — only succeeds if still unassigned. */
    $otp = str_pad(random_int(0,999999),6,'0',STR_PAD_LEFT);
    $wpdb->query($wpdb->prepare(
        "UPDATE {$bookings_tbl} SET vendor_id=%d, status='vendor_assigned', otp_pickup=%s, lead_fee_charged=%f, updated_at=%s
         WHERE id=%d AND vendor_id IS NULL",
        $vendor_id, $otp, $lead->fee_amount, current_time('mysql'), $lead->booking_id
    ));
    if ((int)$wpdb->rows_affected === 0) {
        /* Someone else (another vendor, or an admin) won the booking in the
           gap between our lock and here — revert the lead instead of
           leaving it falsely marked 'accepted', and do NOT touch wallet. */
        $wpdb->update($leads_tbl, array('status'=>'lost_to_other_vendor'), array('id'=>$lead_id));
        $wpdb->query('COMMIT');
        return array('success'=>false,'message'=>'This booking has already been assigned to another vendor.');
    }

    /* Record the immutable assignment row in the same transaction. */
    $details = ridego_default_assignment_details_for_vendor( $vendor_id );
    $assignment_id = ridego_insert_assignment_row( $lead->booking_id, $vendor_id, $lead_id, $details, 'accept', $vendor->user_id );
    if ( ! $assignment_id ) {
        $wpdb->query('ROLLBACK');
        ridego_log( 'accept_lead: assignment insert failed: ' . $wpdb->last_error );
        return array('success'=>false,'message'=>'Could not record the assignment. Please try again.');
    }
    $wpdb->update( $leads_tbl, array( 'interest_status' => 'driver_confirmed' ), array( 'id' => $lead_id ) );
    ridego_lead_fee_lock_for_booking( (int) $lead->booking_id, $vendor_id, $lead );

    /* Mark all other pending leads for this booking as expired. */
    $wpdb->update($leads_tbl,
        array('status'=>'expired','interest_status'=>'expired'),
        array('booking_id'=>$lead->booking_id,'status'=>'sent')
    );

    /* Update vendor stats. */
    $wpdb->query($wpdb->prepare(
        "UPDATE {$wpdb->prefix}ridego_vendors SET total_leads_accepted=total_leads_accepted+1 WHERE id=%d", $vendor_id
    ));

    $wpdb->query('COMMIT');

    /* Wallet deduction happens as its own outermost transaction, AFTER the
       lead/booking transaction has committed (see function doc comment on
       why these can't be nested). If it fails, explicitly unwind the
       assignment so no vendor is ever left assigned without a fee held. */
    $deduct = ridego_vendor_deduct_wallet($vendor_id, $lead->fee_amount, $lead->booking_id, 'Lead fee for booking '.$booking->booking_number);
    if (empty($deduct['success'])) {
        $wpdb->query('START TRANSACTION');
        $wpdb->query($wpdb->prepare(
            "UPDATE {$bookings_tbl} SET vendor_id=NULL, status='confirmed', otp_pickup='', lead_fee_charged=0, updated_at=%s WHERE id=%d AND vendor_id=%d",
            current_time('mysql'), $lead->booking_id, $vendor_id
        ));
        $wpdb->update($leads_tbl, array('status'=>'lost_to_other_vendor'), array('id'=>$lead_id));
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}ridego_booking_assignments SET is_current=0, current_booking_id=NULL WHERE booking_id=%d AND is_current=1", $lead->booking_id
        ));
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}ridego_vendors SET total_leads_accepted=GREATEST(0,total_leads_accepted-1) WHERE id=%d", $vendor_id
        ));
        $wpdb->query('COMMIT');
        ridego_audit_log('lead_accept_wallet_failed','lead',$lead_id,'accepted','reverted', 'warning');
        return array('success'=>false,'message'=>$deduct['message'] ?: 'Insufficient wallet balance. Please top up and try again.');
    }
    $wpdb->update($leads_tbl,array('fee_deducted'=>1),array('id'=>$lead_id));

    ridego_audit_log('lead_accepted','lead',$lead_id,'sent','accepted');
    do_action('ridego_lead_accepted',$lead_id,$lead->booking_id,$vendor_id);

    return array('success'=>true,'message'=>'Lead accepted! Client details sent to you.','booking_id'=>$lead->booking_id,'booking_number'=>$booking->booking_number,'client_phone'=>$booking->client_phone,'otp'=>$otp);
}

/*  Vendor rejects lead  */
function ridego_reject_lead( $lead_id, $vendor_id, $reason = '' ) {
    global $wpdb;
    $lead = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_leads WHERE id=%d AND vendor_id=%d", $lead_id, $vendor_id
    ));
    if (!$lead || $lead->status !== 'sent') return array('success'=>false,'message'=>'Lead not found or already processed.');
    $wpdb->update($wpdb->prefix.'ridego_leads',array(
        'status'        => 'rejected',
        'responded_at'  => current_time('mysql'),
        'reject_reason' => sanitize_text_field($reason),
    ),array('id'=>$lead_id));
    /* total_leads_received is now incremented once, at send time, in
       ridego_distribute_leads()/ridego_cascade_lead() — incrementing it
       again here on reject would double-count every rejected lead. */
    /* Try next available vendor */
    ridego_cascade_lead($lead->booking_id);
    return array('success'=>true,'message'=>'Lead rejected.');
}

/* ============================================================
   VENDOR TRIP STATUS TRANSITIONS  (root-cause fix, vendor-app audit)
   ------------------------------------------------------------
   Prior to this, ridego_get_booking_status_label()/_color() already
   knew about 'driver_en_route' and 'trip_started' as concepts (and
   'active_trips' KPIs already counted them), but nothing anywhere ever
   actually WROTE those statuses — there was no function, REST route, or
   UI path that could move a booking through them, and otp_pickup /
   trip_started_at were written once at assignment and never read again.
   A vendor's assigned trip could therefore never progress past
   'vendor_assigned' except by an admin manually flipping it to
   'completed'. This is the single canonical entry point for the vendor
   app (and, if ever needed, an admin override) to advance a trip's
   status, enforcing a strict allowed-transition map and, for the
   pickup step, the same OTP the client sees at booking time.
   ============================================================ */
function ridego_vendor_advance_trip( $booking_id, $vendor_id, $new_status, $otp = '' ) {
    global $wpdb;
    $booking_id = (int) $booking_id;
    $vendor_id  = (int) $vendor_id;
    $new_status = sanitize_key( $new_status );

    $allowed_transitions = array(
        'vendor_assigned'  => 'driver_en_route',
        'driver_en_route'  => 'trip_started',
        'trip_started'     => 'completed',
    );

    $booking = ridego_get_booking( $booking_id );
    if ( ! $booking ) {
        return array( 'success' => false, 'message' => 'Booking not found.' );
    }
    /* IDOR guard: only the vendor this booking is actually assigned to
       may move it (mirrors the ownership check every other vendor
       endpoint in this file already enforces). */
    if ( (int) $booking->vendor_id !== $vendor_id ) {
        return array( 'success' => false, 'message' => 'This booking is not assigned to you.' );
    }

    if ( ! isset( $allowed_transitions[ $booking->status ] ) || $allowed_transitions[ $booking->status ] !== $new_status ) {
        return array( 'success' => false, 'message' => "Cannot move a trip from '{$booking->status}' to '{$new_status}'." );
    }

    /* Pickup step requires the same OTP shown to the client — this is
       the one place trip_started actually gets gated on it; otp_pickup
       was previously generated and stored but never verified anywhere. */
    if ( 'trip_started' === $new_status ) {
        $otp = preg_replace( '/\D/', '', (string) $otp );
        if ( '' === $otp || ! hash_equals( (string) $booking->otp_pickup, $otp ) ) {
            return array( 'success' => false, 'message' => 'Incorrect pickup OTP.' );
        }
    }

    $extra = array();
    if ( 'trip_started' === $new_status ) {
        $extra['trip_started_at'] = current_time( 'mysql' );
    }

    ridego_update_booking_status( $booking_id, $new_status, $extra );
    ridego_audit_log( 'vendor_trip_status_update', 'booking', $booking_id, $booking->status, $new_status );

    if ( 'completed' === $new_status ) {
        do_action( 'ridego_trip_completed', $booking_id, $vendor_id );
    }

    return array( 'success' => true, 'message' => 'Trip status updated.', 'status' => $new_status );
}

/*  Lead expiry check (called by cron)  */
add_action('ridego_lead_expiry_check','ridego_handle_lead_expiry');
// TRACE: cron ridego_lead_expiry_check → in compare mode with interested vendors leaves the shortlist for admin and only expires unanswered leads, otherwise expires all open leads and cascades or flags no_vendor → void.
//        Preconditions: booking unassigned and not completed/cancelled → Postconditions: no lead left 'sent' unless awaiting admin selection; compare mode with nobody responding only re-sends when lead_auto_redistribute=1, else staff are notified → Edge cases: booking assigned/cancelled (no-op), no more vendors (no_vendor + alert).
function ridego_handle_lead_expiry( $booking_id ) {
    global $wpdb;
    $booking = ridego_get_booking($booking_id);
    if (!$booking || $booking->vendor_id) return;
    if (in_array($booking->status,array('completed','cancelled'))) return;

    /* Compare mode: if any vendor showed interest, the window closing must NOT
       cascade or flag no_vendor — the shortlist waits for an admin decision. */
    if ( ridego_lead_mode() === 'compare' ) {
        $interested = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_leads WHERE booking_id=%d AND status='sent' AND interest_status IN ('interested','driver_confirmed')", $booking_id ) );
        if ( $interested > 0 ) {
            $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}ridego_leads SET status='expired', interest_status='expired' WHERE booking_id=%d AND status='sent' AND interest_status IN ('sent','viewed')", $booking_id ) );
            ridego_notify_staff( 'vendor_interest_received', array( 'booking_number' => $booking->booking_number, 'booking_id' => (int) $booking_id, 'vendor_name' => $interested . ' vendor(s) awaiting your selection' ) );
            ridego_maybe_auto_assign( $booking_id ); // automatic_vendor_assignment (default OFF) may pick now that the window has closed
            return;
        }
    }

    /* Expire all pending leads */
    $wpdb->update($wpdb->prefix.'ridego_leads',array('status'=>'expired','interest_status'=>'expired'),array('booking_id'=>$booking_id,'status'=>'sent'));

    /* Compare mode: nobody responded. Only re-send automatically when lead_auto_redistribute is ON (default OFF);
       otherwise leave it for a human in the Command Centre's "Awaiting vendor response" list. */
    if ( ridego_lead_mode() === 'compare' && (int) ridego_get_setting( 'lead_auto_redistribute', 0 ) !== 1 ) {
        ridego_notify_staff( 'vendor_interest_received', array( 'booking_number' => $booking->booking_number, 'booking_id' => (int) $booking_id, 'vendor_name' => 'No vendor responded in time - decide whether to re-send or assign directly' ) );
        return;
    }

    /* Cascade to next batch */
    $cascaded = ridego_cascade_lead($booking_id);
    if (!$cascaded) {
        /* No more vendors  alert admin */
        $wpdb->update($wpdb->prefix.'ridego_bookings',array('status'=>'no_vendor'),array('id'=>$booking_id));
        ridego_alert_no_vendor($booking_id);
    }
}

/*  When a vendor is suspended/blacklisted/deactivated, pull them out of any
    leads still awaiting THEIR response, so a vendor who just lost active
    status can't still accept a lead already in flight (ridego_accept_lead's
    own status re-check is the hard backstop for that), and so the booking
    doesn't sit stuck waiting on a vendor who will never respond — cascade
    it to the next eligible batch immediately instead of waiting out the
    full lead_accept_minutes window. Only reactions to a transition AWAY
    from 'active' matter here; reactivating a vendor doesn't need to do
    anything (they simply become eligible for the next NEW lead). */
add_action('ridego_vendor_status_changed','ridego_handle_vendor_status_changed_leads',10,2);
function ridego_handle_vendor_status_changed_leads( $vendor_id, $status ) {
    if ($status === 'active') return;
    global $wpdb;
    $leads_tbl = $wpdb->prefix.'ridego_leads';
    $pending = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$leads_tbl} WHERE vendor_id=%d AND status='sent'", $vendor_id
    ));
    if (!$pending) return;
    foreach ($pending as $lead) {
        $wpdb->update($leads_tbl, array('status'=>'expired'), array('id'=>$lead->id,'status'=>'sent'));
        $booking = ridego_get_booking($lead->booking_id);
        if (!$booking || $booking->vendor_id) continue; // already assigned elsewhere, nothing to do
        $cascaded = ridego_cascade_lead($lead->booking_id);
        if (!$cascaded) {
            $wpdb->update($wpdb->prefix.'ridego_bookings',array('status'=>'no_vendor'),array('id'=>$lead->booking_id));
            ridego_alert_no_vendor($lead->booking_id);
        }
    }
}

/*  Send lead to next batch of vendors  */
// TRACE: reject/expiry → sends the lead to the next batch of eligible vendors using the mode-aware window and schedules a new expiry check → bool sent.
//        Preconditions: booking exists and is unassigned → Postconditions: new lead rows inserted → Edge cases: no eligible vendors (false), booking already assigned (false).
function ridego_cascade_lead( $booking_id, $reoffer = false ) {
    global $wpdb;
    $booking = ridego_get_booking($booking_id);
    if (!$booking || $booking->vendor_id) return false;

    $eligible  = ridego_get_eligible_vendors($booking_id, $reoffer);
    $max_send  = (int)ridego_get_setting('lead_max_vendors',5);
    $to_notify = array_slice($eligible,0,$max_send);
    if (empty($to_notify)) return false;

    $accept_mins = ridego_lead_window_minutes();
    $expires_at  = date('Y-m-d H:i:s',strtotime("+{$accept_mins} minutes"));

    foreach ($to_notify as $vendor) {
        $lead_fee = ridego_calculate_lead_fee_for_booking($booking_id, $vendor->id);
        $lf_row = ridego_lead_fee_lead_columns( $booking, (int) $vendor->id );
        $wpdb->insert($wpdb->prefix.'ridego_leads',array(
            'booking_id' => $booking_id,
            'vendor_id'  => $vendor->id,
            'sent_at'    => current_time('mysql'),
            'expires_at' => $expires_at,
            'status'     => 'sent',
            'fee_amount' => $lead_fee,
        ) + $lf_row['columns']);
        if ( $lf_row['applies'] ) { $lead_fee = $lf_row['fee']; }
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}ridego_vendors SET total_leads_received=total_leads_received+1 WHERE id=%d", $vendor->id
        ));
        ridego_queue_notification(array(
            'recipient_id'    => $vendor->user_id,
            'recipient_type'  => 'vendor',
            'recipient_phone' => $vendor->whatsapp_number ?: $vendor->phone,
            'recipient_email' => $vendor->email,
            'event'           => 'vendor_new_lead',
            'payload'         => array(
                'booking_id'     => $booking_id,
                'booking_number' => $booking->booking_number,
                'pickup_city'    => $booking->pickup_city,
                'drop_city'      => $booking->drop_city,
                'journey_date'   => ridego_format_date($booking->journey_date),
                'journey_time'   => $booking->journey_time,
                'total_fare'     => ridego_money($booking->total_fare),
                'token_amount'   => ridego_money(ridego_booking_platform_amount($booking)),
                'remaining_amount'=> ridego_money(max(0, (float)$booking->total_fare - ridego_booking_platform_amount($booking))),
                'lead_fee'       => ridego_money($lead_fee),
                'lead_fee_note'  => $lf_row['applies'] ? $lf_row['description'] : '',
                'accept_minutes' => $accept_mins,
            ),
            'scheduled_for'   => current_time('mysql'),
        ));
    }
    wp_schedule_single_event(strtotime("+{$accept_mins} minutes"),'ridego_lead_expiry_check',array($booking_id));
    return true;
}

/*  Admin assign vendor manually  ---------------------------------------
    Same class of race as ridego_accept_lead(): lock the booking row and
    apply a conditioned UPDATE ... WHERE vendor_id IS NULL so a manual
    admin assignment can never silently clobber a vendor who already
    self-served accepted the lead a moment earlier (and vice versa —
    ridego_accept_lead()'s own conditioned UPDATE protects it from this
    function racing it the other way). */
// TRACE: admin/auto assignment → in one transaction locks the booking, conditioned UPDATE where vendor_id IS NULL, reuses or inserts the vendor's lead row, inserts the assignment snapshot (confirmed driver/vehicle or defaults), marks other open leads not_selected, commits, then deducts the lead fee and notifies losers → array(success,message,assignment_id).
//        Preconditions: vendor active, booking not cancelled/completed → Postconditions: exactly one current assignment row → Edge cases: already assigned (ROLLBACK), unknown vendor/booking, inactive vendor, assignment insert failure (ROLLBACK), fee uncollectable (assignment kept, audited).
function ridego_admin_assign_vendor( $booking_id, $vendor_id, $admin_id, $reason = '', $lead_id = 0 ) {
    global $wpdb;
    $booking_id = (int) $booking_id;
    $vendor_id  = (int) $vendor_id;
    $bookings_tbl = $wpdb->prefix.'ridego_bookings';
    $leads_tbl    = $wpdb->prefix.'ridego_leads';

    $vendor  = ridego_get_vendor($vendor_id);
    if (!$vendor) return array('success'=>false,'message'=>'Booking or vendor not found.');
    if ($vendor->status !== 'active') return array('success'=>false,'message'=>'That vendor is not active and cannot be assigned.');

    $wpdb->query('START TRANSACTION');

    $booking = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$bookings_tbl} WHERE id=%d FOR UPDATE", $booking_id));
    if (!$booking) {
        $wpdb->query('ROLLBACK');
        return array('success'=>false,'message'=>'Booking or vendor not found.');
    }
    if (in_array($booking->status, array('cancelled','completed'), true)) {
        $wpdb->query('ROLLBACK');
        return array('success'=>false,'message'=>'A cancelled or completed booking cannot be assigned.');
    }

    /* Re-use the vendor's existing lead row (if any) so history is one row per vendor per booking. */
    $lead = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$leads_tbl} WHERE booking_id=%d AND vendor_id=%d ORDER BY id DESC LIMIT 1 FOR UPDATE", $booking_id, $vendor_id));

    $lead_fee = $lead ? (float) $lead->fee_amount : (float) ridego_calculate_lead_fee_for_booking($booking_id, $vendor_id);
    $otp      = str_pad(random_int(0,999999),6,'0',STR_PAD_LEFT);
    $reason   = substr(sanitize_text_field($reason), 0, 255);

    $wpdb->query($wpdb->prepare(
        "UPDATE {$bookings_tbl} SET vendor_id=%d, status='vendor_assigned', otp_pickup=%s, lead_fee_charged=%f, assignment_reason=%s, updated_at=%s
         WHERE id=%d AND vendor_id IS NULL",
        $vendor_id, $otp, $lead_fee, $reason, current_time('mysql'), $booking_id
    ));
    if ((int)$wpdb->rows_affected === 0) {
        $wpdb->query('ROLLBACK');
        return array('success'=>false,'message'=>'This booking has already been assigned to a vendor (possibly self-accepted by a vendor moments ago).');
    }

    /* Driver/vehicle: use what the vendor confirmed on the lead, else their defaults (blank for a fleet
       vendor that has not confirmed — the vendor is then asked to fill it in). */
    if ($lead && $lead->driver_name !== '' && $lead->vehicle_registration !== '') {
        $details = array('ok'=>true,'error'=>'','driver_id'=>$lead->driver_id ? (int)$lead->driver_id : null,'driver_name'=>$lead->driver_name,'driver_phone'=>$lead->driver_phone,
            'vehicle_id'=>$lead->vehicle_id ? (int)$lead->vehicle_id : null,'vehicle_model'=>$lead->vehicle_model,'vehicle_registration'=>$lead->vehicle_registration);
    } else {
        $details = ridego_default_assignment_details_for_vendor($vendor_id);
    }
    $assignment_id = ridego_insert_assignment_row($booking_id, $vendor_id, $lead ? (int)$lead->id : null, $details, 'admin', $admin_id, null, $reason);
    if (!$assignment_id) {
        $wpdb->query('ROLLBACK');
        ridego_log('admin_assign: assignment insert failed: ' . $wpdb->last_error);
        return array('success'=>false,'message'=>'Could not record the assignment. Please try again.');
    }

    $now = current_time('mysql');
    ridego_lead_fee_lock_for_booking( $booking_id, $vendor_id, $lead );
    if ($lead) {
        $wpdb->update($leads_tbl, array('status'=>'accepted','responded_at'=>$now,'interest_status'=>($details['driver_name']!==''?'driver_confirmed':'interested')), array('id'=>(int)$lead->id));
        $lead_row_id = (int) $lead->id;
    } else {
        $wpdb->insert($leads_tbl,array(
            'booking_id'=>$booking_id,'vendor_id'=>$vendor_id,'sent_at'=>$now,'expires_at'=>date('Y-m-d H:i:s',strtotime('+30 minutes')),
            'status'=>'accepted','interest_status'=>($details['driver_name']!==''?'driver_confirmed':'interested'),'fee_amount'=>$lead_fee,'responded_at'=>$now,
        ));
        $lead_row_id = (int) $wpdb->insert_id;
    }

    /* Everyone else still in the running is told they were not selected. */
    $losers = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$leads_tbl} WHERE booking_id=%d AND vendor_id<>%d AND status='sent' FOR UPDATE", $booking_id, $vendor_id));
    $wpdb->query($wpdb->prepare(
        "UPDATE {$leads_tbl} SET status='lost_to_other_vendor', interest_status='not_selected', not_selected_reason=%s WHERE booking_id=%d AND vendor_id<>%d AND status='sent'",
        'Another vendor was selected', $booking_id, $vendor_id));

    $wpdb->query('COMMIT');

    $fee_deducted = 0;
    if ($lead_fee > 0) {
        $deduct = ridego_vendor_deduct_wallet($vendor_id,$lead_fee,$booking_id,'Lead fee (admin assigned) for '.$booking->booking_number);
        $fee_deducted = !empty($deduct['success']) ? 1 : 0;
        // Insufficient balance on admin-assign is not fatal to the assignment
        // (the admin made an explicit override decision) but is recorded so
        // Finance can see the fee was never actually collected.
        if (!$fee_deducted) {
            ridego_audit_log('admin_assign_fee_uncollected','booking',$booking_id,'',$deduct['message'] ?? 'unknown', 'warning');
        }
    }
    if ($lead_row_id) { $wpdb->update($leads_tbl, array('fee_deducted'=>$fee_deducted), array('id'=>$lead_row_id)); }
    $wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}ridego_vendors SET total_leads_accepted=total_leads_accepted+1 WHERE id=%d", $vendor_id));

    foreach ((array)$losers as $l) { ridego_notify_lead_lost($l, 'Another vendor was selected'); }
    ridego_audit_log('admin_assigned_vendor','booking',$booking_id,'',array('vendor_id'=>$vendor_id,'reason'=>$reason));
    do_action('ridego_lead_accepted',$lead_row_id,$booking_id,$vendor_id);
    do_action('ridego_admin_assigned_vendor',$booking_id,$vendor_id,$admin_id,$reason);
    return array('success'=>true,'message'=>'Vendor assigned successfully.','assignment_id'=>$assignment_id);
}

/*  Alert admin when no vendor found  */
function ridego_alert_no_vendor( $booking_id ) {
    $booking = ridego_get_booking($booking_id);
    if (!$booking) return;
    ridego_telegram_alert(
        "<b>NO VENDOR ALERT</b>\nBooking #{$booking->booking_number}\n".
        "{$booking->pickup_city} -> {$booking->drop_city}\n".
        date('d M',strtotime($booking->journey_date)).' at '.$booking->journey_time."\n".
        "No driver accepted. MANUAL ASSIGNMENT NEEDED.\n".
        admin_url('admin.php?page=ridego-bookings&action=assign&id='.$booking_id)
    );
    $to = ridego_get_setting('admin_email', get_option('admin_email'));
    wp_mail($to,
        '[URGENT] No Driver Found  Booking '.$booking->booking_number,
        "No driver accepted booking {$booking->booking_number}.\n".
        "Route: {$booking->pickup_city} to {$booking->drop_city}\n".
        "Date: {$booking->journey_date} {$booking->journey_time}\n".
        "Assign manually: ".admin_url('admin.php?page=ridego-bookings')
    );
}

/*  Queue notification (non-blocking).
    Canonical definition — matches the ridego_notification_queue DB schema.

    Two supported calling conventions:

    1. Array form (used by lead.php, vendor.php, etc.):
       ridego_queue_notification( array(
           'recipient_id'    => 42,
           'recipient_type'  => 'vendor',
           'recipient_phone' => '9876543210',
           'recipient_email' => 'v@example.com',
           'event'           => 'vendor_new_lead',
           'payload'         => array(...),
           'channel'         => 'whatsapp',   // optional
           'scheduled_for'   => '2025-01-01 10:00:00', // optional
       ) );

    2. Four-argument form (used internally by notifications.php delayed-send):
       ridego_queue_notification( $user_id, $event, $data_array, $delay_seconds );
*/
function ridego_queue_notification( $args, $event = null, $data = null, $delay = 0 ) {
    global $wpdb;

    /* Detect 4-argument form and convert to array form */
    if ( ! is_array($args) ) {
        $user_id = absint($args);
        $args = array(
            'recipient_id'  => $user_id,
            'event'         => sanitize_key((string)$event),
            'payload'       => is_array($data) ? $data : array(),
            'scheduled_for' => date('Y-m-d H:i:s', time() + max(0, (int)$delay)),
        );
    }

    $inserted = $wpdb->insert(
        $wpdb->prefix . 'ridego_notification_queue',
        array(
            'recipient_id'    => intval( isset($args['recipient_id'])    ? $args['recipient_id']    : 0 ),
            'recipient_type'  => sanitize_key( isset($args['recipient_type'])  ? $args['recipient_type']  : 'client' ),
            'recipient_phone' => sanitize_text_field( isset($args['recipient_phone']) ? $args['recipient_phone'] : '' ),
            'recipient_email' => sanitize_email( isset($args['recipient_email']) ? $args['recipient_email'] : '' ),
            'event'           => sanitize_key( isset($args['event'])  ? $args['event']  : '' ),
            'channel'         => sanitize_key( isset($args['channel']) ? $args['channel'] : 'whatsapp' ),
            'payload'         => wp_json_encode( isset($args['payload']) ? $args['payload'] : array() ),
            'scheduled_for'   => sanitize_text_field( isset($args['scheduled_for']) ? $args['scheduled_for'] : current_time('mysql') ),
            'status'          => 'pending',
            'created_at'      => current_time('mysql'),
        )
    );

    /* Flag this request so the shutdown-time flush (see notifications.php)
       processes the queue before the request ends, instead of waiting on
       WP-Cron's next 5-minute mark or a system crontab. Only immediately-due
       items need this — a genuinely delayed item (scheduled_for in the
       future) still relies on the periodic sweep, correctly, since flushing
       now wouldn't send it anyway (ridego_process_notification_queue()
       filters on scheduled_for <= NOW()). */
    if ( $inserted !== false ) {
        $scheduled_for = isset( $args['scheduled_for'] ) ? $args['scheduled_for'] : current_time( 'mysql' );
        if ( strtotime( $scheduled_for ) <= time() ) {
            $GLOBALS['ridego_notification_queued_this_request'] = true;
        }
    }

    /* Return the inserted queue row ID on success (truthy), false on failure,
       so callers (e.g. the admin broadcast handler) can correctly count
       successes instead of always seeing a falsy NULL. */
    return $inserted !== false ? $wpdb->insert_id : false;
}

/*  Get vendor active leads  */
function ridego_get_vendor_leads( $vendor_id, $status = 'sent', $limit = 20 ) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare(
        "SELECT l.*,b.booking_number,b.pickup_city,b.drop_city,b.journey_date,b.journey_time,
                b.vehicle_type_id,b.passengers,b.total_fare,b.trip_type,
                v.name AS vehicle_name
         FROM {$wpdb->prefix}ridego_leads l
         JOIN {$wpdb->prefix}ridego_bookings b ON b.id=l.booking_id
         LEFT JOIN {$wpdb->prefix}ridego_vehicles v ON v.id=b.vehicle_type_id
         WHERE l.vendor_id=%d AND l.status=%s
         ORDER BY l.sent_at DESC LIMIT %d",
        $vendor_id, $status, $limit
    ));
}
