<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * RideGo diagnostic REST endpoint.
 * ---------------------------------------------------------------
 * Superseded a raw standalone PHP file (ridego-diagnostic.php) that
 * was dropped into the plugin folder for the same purpose: that
 * approach got a 403 from the host's edge (openresty) because
 * directly executing a bare .php file at a fresh, non-standard path
 * under wp-content/plugins/ is exactly the pattern hosting-level
 * WAFs block by design, to stop malicious file uploads/webshells —
 * a legitimate security rule, not a bug, and not something to try to
 * route around. This endpoint instead goes through the exact same
 * WordPress REST API mechanism every other route in this plugin
 * already uses (rest_api_init → register_rest_route), which is the
 * expected, legitimate way to reach PHP logic on a WordPress site,
 * so it isn't shaped like the thing that rule exists to catch.
 *
 * Read-only, reports configuration facts only — never secrets (no
 * DB password, auth keys/salts, API keys, or nonces are printed).
 * Public (no login required) specifically because /wp-admin/ was
 * reported as redirect-looping, so a login-gated check would be
 * unreachable in exactly the situation it needs to diagnose.
 * ---------------------------------------------------------------
 */

add_action( 'rest_api_init', 'ridego_register_diagnostic_route' );
function ridego_register_diagnostic_route() {
    register_rest_route( 'ridego/v1', '/diagnostic', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_diagnostic_report',
        'permission_callback' => '__return_true',
    ) );
}

function ridego_diagnostic_report( $request ) {
    $report = array();

    $report['generated_at_utc'] = gmdate( 'Y-m-d H:i:s' );

    /* ---------------- WordPress core ---------------- */
    $siteurl = get_option( 'siteurl' );
    $homeopt = get_option( 'home' );
    $host    = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : null;
    $https_server_var = isset( $_SERVER['HTTPS'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTPS'] ) ) : null;
    $actual_scheme = ( $https_server_var && $https_server_var !== 'off' ) ? 'https' : 'http';
    $xfp  = isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) ) : null;
    $xfh  = isset( $_SERVER['HTTP_X_FORWARDED_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_HOST'] ) ) : null;

    $report['wordpress'] = array(
        'version'              => get_bloginfo( 'version' ),
        'php_version'          => PHP_VERSION,
        'siteurl_option'       => $siteurl,
        'home_option'          => $homeopt,
        'home_url'             => home_url( '/' ),
        'permalink_structure'  => get_option( 'permalink_structure' ) ?: '(plain -- pretty permalinks OFF)',
        'is_ssl'                => is_ssl(),
    );

    $report['this_request'] = array(
        'http_host'               => $host,
        'request_uri'             => isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : null,
        'server_https_var'        => $https_server_var ?: '(not set)',
        'detected_scheme'         => $actual_scheme,
        'x_forwarded_proto'       => $xfp ?: '(not sent)',
        'x_forwarded_host'        => $xfh ?: '(not sent)',
        'server_software'         => isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : null,
    );

    $scheme_mismatch = $siteurl && $host && ( stripos( $siteurl, $host ) === false );
    $proto_mismatch  = $xfp && $actual_scheme !== $xfp;

    /* ---------------- RideGo plugin ---------------- */
    $dist_index = defined( 'RIDEGO_APP_DIR' ) ? RIDEGO_APP_DIR . 'index.html' : null;
    $rules = get_option( 'rewrite_rules' );
    $has_app_rule = false;
    if ( is_array( $rules ) ) {
        foreach ( $rules as $pattern => $rewrite ) {
            if ( strpos( $rewrite, 'ridego_app' ) !== false ) { $has_app_rule = true; break; }
        }
    }
    $report['ridego_plugin'] = array(
        'version'                    => defined( 'RIDEGO_VER' ) ? RIDEGO_VER : '(constant not defined)',
        'dist_index_html_exists'     => $dist_index ? file_exists( $dist_index ) : null,
        'dist_index_html_path'       => $dist_index,
        'app_rewrite_rule_registered'=> $has_app_rule,
    );

    /* ---------------- Caching / security plugins ---------------- */
    $active_plugins = (array) get_option( 'active_plugins', array() );
    if ( is_multisite() ) {
        $active_plugins = array_merge( $active_plugins, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
    }
    $known_caching = array(
        'wp-rocket' => 'WP Rocket', 'w3-total-cache' => 'W3 Total Cache', 'wp-super-cache' => 'WP Super Cache',
        'litespeed-cache' => 'LiteSpeed Cache', 'wp-fastest-cache' => 'WP Fastest Cache', 'sg-cachepress' => 'SiteGround Optimizer',
        'breeze' => 'Breeze', 'autoptimize' => 'Autoptimize', 'wp-optimize' => 'WP-Optimize', 'cache-enabler' => 'Cache Enabler',
        'nginx-helper' => 'Nginx Helper',
    );
    $known_security = array(
        'wordfence' => 'Wordfence', 'better-wp-security' => 'iThemes/Solid Security', 'sucuri-scanner' => 'Sucuri',
        'all-in-one-wp-security-and-firewall' => 'All In One WP Security', 'wp-cerber' => 'WP Cerber',
    );
    $found_caching  = array();
    $found_security = array();
    foreach ( $active_plugins as $p ) {
        foreach ( $known_caching as $slug => $name ) {
            if ( strpos( $p, $slug ) === 0 ) { $found_caching[] = $name; }
        }
        foreach ( $known_security as $slug => $name ) {
            if ( strpos( $p, $slug ) === 0 ) { $found_security[] = $name; }
        }
    }
    $report['caching_and_security'] = array(
        'caching_plugins_detected'  => $found_caching ?: array( '(none detected)' ),
        'security_plugins_detected' => $found_security ?: array( '(none detected)' ),
        'wp_cache_constant'         => defined( 'WP_CACHE' ) && WP_CACHE,
        'total_active_plugins'      => count( $active_plugins ),
        'active_plugin_slugs'       => array_map( function ( $p ) { return dirname( $p ); }, $active_plugins ),
    );

    /* ---------------- Live self-request tests ---------------- */
    $base = $host ? ( $actual_scheme . '://' . $host ) : null;
    $targets = array();
    if ( $base ) {
        $targets['wp_json_root']       = $base . '/wp-json/';
        $targets['wp_json_ridego_home']= $base . '/wp-json/ridego/v1/app/home';
        $targets['wp_admin']           = $base . '/wp-admin/';
        $targets['app_shell']          = $base . '/app/';
    }
    $self_tests = array();
    foreach ( $targets as $label => $url ) {
        $self_tests[ $label ] = ridego_diagnostic_self_request( $url );
    }
    $report['self_request_tests'] = $self_tests;

    /* ---------------- Verdict ---------------- */
    $findings = array();
    if ( $scheme_mismatch ) {
        $findings[] = 'siteurl option (' . $siteurl . ') does not contain the Host header this request actually arrived with (' . $host . ').';
    }
    if ( $proto_mismatch ) {
        $findings[] = 'This request\'s detected scheme (' . $actual_scheme . ') does not match the X-Forwarded-Proto header (' . $xfp . ') -- WordPress may not trust the proxy\'s HTTPS signal, a classic cause of admin redirect loops.';
    }
    if ( defined( 'WP_CACHE' ) && WP_CACHE && empty( $found_caching ) ) {
        $findings[] = 'WP_CACHE is true but no known caching plugin slug is in active_plugins -- likely a host-level cache drop-in (advanced-cache.php / object-cache.php) installed outside the visible plugins list.';
    }
    $report['findings'] = $findings ?: array( 'No scheme/URL mismatch detected from this request alone -- see self_request_tests for what /wp-json/ and /wp-admin/ actually returned.' );

    return rest_ensure_response( $report );
}

/**
 * Real outbound HTTP request from this server to itself, using
 * WordPress's own HTTP API (wp_remote_get) so it respects the same
 * SSL/proxy environment as the rest of the site -- redirects are
 * NOT followed, so a redirect loop shows up as a single 30x response
 * with a Location header rather than a timeout.
 */
function ridego_diagnostic_self_request( $url ) {
    $response = wp_remote_get( $url, array(
        'timeout'     => 15,
        'redirection' => 0,
        'sslverify'   => false, // diagnostic only; a staging host's cert shouldn't block the test itself
        'headers'     => array( 'User-Agent' => 'RideGo-Diagnostic/1.0' ),
    ) );

    if ( is_wp_error( $response ) ) {
        return array( 'error' => $response->get_error_message() );
    }

    $status  = wp_remote_retrieve_response_code( $response );
    $headers = wp_remote_retrieve_headers( $response );
    $body    = wp_remote_retrieve_body( $response );

    $interesting_headers = array();
    if ( is_object( $headers ) && method_exists( $headers, 'getAll' ) ) {
        $all = $headers->getAll();
    } elseif ( is_array( $headers ) ) {
        $all = $headers;
    } else {
        $all = array();
    }
    foreach ( $all as $k => $v ) {
        if ( preg_match( '/^(location|content-type|server|cache-control|x-cache|cf-|x-proxy|x-powered-by|age)/i', $k ) ) {
            $interesting_headers[ $k ] = is_array( $v ) ? implode( ', ', $v ) : $v;
        }
    }

    $trimmed = ltrim( $body );
    $looks_like_json = isset( $trimmed[0] ) && ( $trimmed[0] === '{' || $trimmed[0] === '[' );

    return array(
        'status'           => $status,
        'headers'          => $interesting_headers,
        'looks_like_json'  => $looks_like_json,
        'body_preview'     => function_exists( 'mb_substr' ) ? mb_substr( $body, 0, 500 ) : substr( $body, 0, 500 ),
    );
}
