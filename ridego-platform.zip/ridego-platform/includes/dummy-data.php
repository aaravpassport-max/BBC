<?php
if ( ! defined('ABSPATH') ) { exit; }

/* ================================================================
   RIDEGO DUMMY DATA SEEDER v3.0
   Seeds: vendors, bookings, leads, wallet transactions, promo codes, reviews
   Called from: RideGo → Tools → "Seed Demo Data"
   ================================================================ */

function ridego_seed_dummy_data() {
    global $wpdb;

    /* Prevent double-seeding */
    if ( get_option('ridego_demo_seeded') ) { return; }

    $prefix = $wpdb->prefix;

    /* ── Promo codes ── */
    $promos = array(
        array('FIRST10','percentage',10,0,0,0,'2025-01-01','2026-12-31','Flat 10% off your first booking',1),
        array('AIRPORT20','fixed',200,600,200,0,'2025-01-01','2026-12-31','₹200 off airport transfers',1),
        array('ROUND15','percentage',15,0,300,100,'2025-01-01','2026-12-31','15% off round trips (max ₹300)',1),
        array('SUMMER25','percentage',25,0,500,50,'2025-06-01','2025-08-31','Summer special — 25% off (used up)',0),
        array('EARLYBIRD','percentage',12,0,250,0,'2025-01-01','2026-12-31','Book 7 days early, save 12%',1),
        array('GROUP5','fixed',500,2000,500,0,'2025-01-01','2026-12-31','₹500 off group bookings 6+ pax',1),
        array('CORPORATE15','percentage',15,0,0,0,'2025-01-01','2026-12-31','Corporate accounts — 15% off',1),
        array('WELCOME50','fixed',50,300,50,0,'2025-01-01','2026-12-31','₹50 welcome bonus — new users',1),
    );
    foreach($promos as $p) {
        $ex = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$prefix}ridego_promo_codes WHERE code=%s",$p[0]));
        if(!$ex) {
            $wpdb->insert("{$prefix}ridego_promo_codes", array(
                'code'=>$p[0],'discount_type'=>$p[1],'discount_value'=>$p[2],
                'type'=>$p[1],'value'=>$p[2],'max_discount'=>$p[4],'min_booking_amount'=>$p[3],'min_booking'=>$p[3],
                'usage_limit'=>($p[5]?$p[5]:100),'valid_from'=>$p[6],'valid_to'=>$p[7],'start_date'=>$p[6],'expiry_date'=>$p[7],'description'=>$p[8],
                'is_active'=>$p[9],'used_count'=>rand(0,40),'created_at'=>current_time('mysql'),
            ));
        }
    }

    /* ── Demo vendor users ── */
    $vendor_data = array(
        array('ramesh_sharma_vendor','ramesh.sharma@ridego.demo','Ramesh Sharma Travels','Ramesh Sharma','9876543210','9876543210','Delhi','Delhi, Agra, Jaipur, Chandigarh','sedan,suv,innova_crysta',5,12,'fleet_owner','active','verified',8500.00),
        array('priya_cabs_vendor','priya.cabs@ridego.demo','Priya City Cabs','Priya Mehta','9123456780','9123456780','Mumbai','Mumbai, Pune, Nasik, Goa','sedan,hatchback',3,7,'individual','active','verified',3200.00),
        array('rajesh_travels_vendor','rajesh.travels@ridego.demo','Rajesh Tours & Travels','Rajesh Kumar','9988776655','9988776655','Bangalore','Bangalore, Mysore, Coorg, Chennai','suv,innova_crysta,tempo_traveller',8,15,'agency','active','verified',12000.00),
        array('sunita_cabs_vendor','sunita@ridego.demo','Sunita Cab Service','Sunita Patel','9845123456','9845123456','Ahmedabad','Ahmedabad, Surat, Vadodara','sedan,hatchback',2,4,'individual','active','verified',1800.00),
        array('krishna_tours_vendor','krishna@ridego.demo','Krishna Tours','Krishna Rao','9711223344','9711223344','Hyderabad','Hyderabad, Secunderabad, Vijayawada','suv,sedan',4,9,'fleet_owner','active','complete',5500.00),
        array('amit_driver_vendor','amit.driver@ridego.demo','Amit Driver Service','Amit Singh','9654321098','9654321098','Jaipur','Jaipur, Ajmer, Jodhpur, Udaipur','sedan,suv',2,6,'individual','pending','pending',500.00),
    );

    /* A default commission model so completed demo trips produce commission ledger entries. */
    if ( ! (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$prefix}ridego_commission_models" ) ) {
        $wpdb->insert( "{$prefix}ridego_commission_models", array( 'name' => 'Standard 10% commission', 'type' => 'percentage', 'percentage' => 10, 'min_amount' => 50, 'is_active' => 1, 'is_default' => 1 ) );
    }
    $vendor_ids = array();
    foreach($vendor_data as $vd) {
        $uid = username_exists($vd[0]);
        if(!$uid) {
            $uid = wp_create_user($vd[0], wp_generate_password(12,false), $vd[1]);
            if(is_wp_error($uid)) continue;
            wp_update_user(array('ID'=>$uid,'display_name'=>$vd[3],'role'=>'ridego_vendor'));
        }
        $ex = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$prefix}ridego_vendors WHERE user_id=%d",$uid));
        if($ex) { $vendor_ids[] = $ex; continue; }
        $wpdb->insert("{$prefix}ridego_vendors", array(
            'user_id'=>$uid,'business_name'=>$vd[2],'owner_name'=>$vd[3],
            'phone'=>$vd[4],'whatsapp_number'=>$vd[5],'email'=>$vd[1],
            'city'=>$vd[6],'operating_cities'=>wp_json_encode(explode(', ',$vd[7])),'vehicle_types'=>wp_json_encode(array_values(array_filter(array_map(function($slug) use ($wpdb,$prefix){ $slug=str_replace('_','-',trim($slug)); return (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$prefix}ridego_vehicles WHERE slug=%s OR slug LIKE %s ORDER BY id LIMIT 1",$slug,$slug.'%')); },explode(',',$vd[8]))))),
            'total_vehicles'=>$vd[9],'years_experience'=>$vd[10],
            'business_type'=>$vd[11],'vendor_type'=>( in_array( $vd[11], array( 'fleet_owner', 'agency', 'company' ), true ) ? 'fleet' : 'individual' ),'status'=>$vd[12],'kyc_status'=>$vd[13],
            'wallet_balance'=>$vd[14],'documents_verified'=>($vd[13]==='verified'?1:0),
            'joined_at'=>date('Y-m-d H:i:s',strtotime('-'.rand(30,180).' days')),
        ));
        $vid = $wpdb->insert_id;
        $vendor_ids[] = $vid;
        /* Fleet: individual vendors get one vehicle + one driver record, fleet vendors several, so lead confirmation and assignment can be exercised. */
        $is_fleet = in_array( $vd[11], array( 'fleet_owner', 'agency', 'company' ), true );
        $type_ids = json_decode( $wpdb->get_var( $wpdb->prepare( "SELECT vehicle_types FROM {$prefix}ridego_vendors WHERE id=%d", $vid ) ), true );
        $type_ids = is_array( $type_ids ) && $type_ids ? array_values( $type_ids ) : array( 2 );
        $wpdb->delete( "{$prefix}ridego_fleet_vehicles", array( 'vendor_id' => $vid ) );
        $wpdb->delete( "{$prefix}ridego_fleet_drivers", array( 'vendor_id' => $vid ) );
        $n_veh = $is_fleet ? 3 : 1;
        for ( $i = 0; $i < $n_veh; $i++ ) {
            $wpdb->insert( "{$prefix}ridego_fleet_vehicles", array( 'vendor_id' => $vid, 'vehicle_type_id' => (int) $type_ids[ $i % count( $type_ids ) ],
                'make_model' => ( $i % 2 ? 'Maruti Ertiga' : 'Maruti Dzire' ), 'registration_number' => sprintf( 'DL%02dRG%04d', $vid, 1000 + $i ), 'seating_capacity' => ( $i % 2 ? 6 : 4 ), 'status' => 'active' ) );
        }
        $n_drv = $is_fleet ? 2 : 1;
        for ( $i = 0; $i < $n_drv; $i++ ) {
            $wpdb->insert( "{$prefix}ridego_fleet_drivers", array( 'vendor_id' => $vid, 'name' => ( $i === 0 ? $vd[3] : $vd[3] . ' Driver ' . ( $i + 1 ) ), 'mobile' => $vd[4],
                'license_number' => sprintf( 'DL-%d-%04d', $vid, 2000 + $i ), 'license_expiry' => date( 'Y-m-d', strtotime( '+2 years' ) ), 'experience_years' => (int) $vd[10], 'status' => 'active',
                'date_of_birth' => date( 'Y-m-d', strtotime( '-' . ( 30 + $i * 4 ) . ' years' ) ), 'alt_mobile' => '', 'blood_group' => ( $i % 2 ? 'B+' : 'O+' ),
                'address' => 'House ' . ( 10 + $i ) . ', Main Road', 'city' => $vd[6], 'pincode' => '110001',
                'emergency_contact_name' => 'Family of ' . $vd[3], 'emergency_contact_phone' => '98' . sprintf( '%08d', 1000000 + $vid * 10 + $i ), 'emergency_contact_relation' => 'Spouse',
                'id_proof_type' => 'aadhaar', 'id_proof_number' => sprintf( '5555%08d', $vid * 10 + $i ), 'license_class' => 'LMV-TR', 'badge_number' => sprintf( 'BDG%04d', $vid * 10 + $i ),
                'police_verification_status' => 'verified', 'police_verification_date' => date( 'Y-m-d', strtotime( '-1 year' ) ) ) );
        }
        /* Wallet history */
        for($i=0;$i<rand(4,8);$i++) {
            $amt = (rand(0,1)?1:-1)*rand(100,2000);
            $wpdb->insert("{$prefix}ridego_vendor_wallets", array(
                'vendor_id'=>$vid,'amount'=>$amt,'type'=>$amt>0?'credit':'debit',
                'booking_id'=>null,'notes'=>$amt>0?'Admin top-up':'Lead fee deducted',
                'balance_after'=>$vd[14]+$amt,'created_at'=>date('Y-m-d H:i:s',strtotime('-'.rand(1,90).' days')),
            ));
        }
    }

    /* ── Demo bookings ── */
    $routes = array(
        array('Delhi','Agra','one_way',225,4),
        array('Mumbai','Pune','one_way',148,3),
        array('Bangalore','Mysore','one_way',143,2.5),
        array('Jaipur','Jodhpur','one_way',330,5),
        array('Delhi','Jaipur','round_trip',275,4.5),
        array('Chennai','Pondicherry','one_way',162,3),
        array('Hyderabad','Vijayawada','one_way',275,4.5),
        array('Kolkata','Digha','one_way',182,4),
        array('Mumbai','Goa','outstation',587,10),
        array('Delhi','Chandigarh','one_way',248,4),
        array('Bangalore','Coorg','outstation',248,5),
        array('Pune','Nashik','one_way',210,3.5),
        array('Delhi','Haridwar','one_way',212,4),
        array('Mumbai','Mumbai','local',40,2),
        array('Bangalore','Bangalore','local',0,2),
        array('Delhi','Delhi','airport_pickup',35,1),
        array('Mumbai','Mumbai','airport_drop',28,1),
        array('Jaipur','Agra','one_way',238,4),
        array('Agra','Delhi','one_way',205,4),
        array('Hyderabad','Hyderabad','local',0,2),
    );
    $names = array('Rahul Sharma','Priya Mehta','Amit Kumar','Sunita Singh','Rajesh Patel','Anita Verma','Sanjay Gupta','Pooja Reddy','Vikas Nair','Deepa Pillai','Mohit Arora','Kavita Joshi','Suresh Yadav','Meena Krishnan','Rohit Bhatia','Sneha Desai','Arun Mishra','Rekha Agarwal','Naveen Kumar','Anjali Pandey');
    $phones = array('9876543210','9123456780','9988776655','9845123456','9711223344','9654321098','9800123456','9999888777','9876001234','9451234567','9321456789','9012345678','9876123450','9443216543','9550987654','9677234561','9789012345','9823456789','9012876543','9456789012');
    $statuses = array('pending','payment_pending','confirmed','vendor_assigned','completed','completed','completed','completed','cancelled');
    $pay_statuses = array('pending','pending','verified','verified','verified','verified','verified','verified','pending');
    $payment_methods = array('bank_transfer','bank_transfer','upi','bank_transfer','cash','upi','bank_transfer','cash','upi');
    $vehicle_types = $wpdb->get_results("SELECT id,base_price_per_km,base_price_outstation,local_4hr_40km,local_8hr_80km,airport_base_charge FROM {$prefix}ridego_vehicles WHERE is_active=1");
    if(empty($vehicle_types)) { update_option('ridego_demo_seeded',1); return; }

    $booking_ids = array();
    $count = 0;
    for($i=0;$i<40;$i++) {
        $route = $routes[$i % count($routes)];
        $vt    = $vehicle_types[$i % count($vehicle_types)];
        $ni    = $i % count($names);
        $days_ago = rand(1,120);
        $journey_days_from_now = rand(-60,30);
        $status = $statuses[$i % count($statuses)];
        if($journey_days_from_now > 0 && in_array($status,['completed'])) $status='confirmed';
        if($journey_days_from_now < -2 && $status==='pending') $status='completed';
        $ps = $pay_statuses[$i % count($pay_statuses)];
        if($status==='completed') $ps='verified';
        if($status==='cancelled') $ps='pending';
        /* Calculate fare */
        $dist = $route[3];
        $trip_type = $route[2];
        $base = 0;
        if($trip_type==='local') $base = $vt->local_4hr_40km;
        elseif(in_array($trip_type,['airport_pickup','airport_drop'])) $base = $vt->airport_base_charge;
        else $base = max($dist * $vt->base_price_per_km, 500);
        $gst = round($base*0.05);
        $total = $base + $gst;
        $promo = (rand(0,3)===0)?round($total*0.1):0;
        $total_final = $total - $promo;
        $bn = 'RG-'.date('Y',strtotime('-'.$days_ago.' days')).str_pad(1000+$count,4,'0',STR_PAD_LEFT);
        $vendor_id = !empty($vendor_ids)?$vendor_ids[$i%count($vendor_ids)]:null;
        $wpdb->insert("{$prefix}ridego_bookings", array(
            'booking_number'=>$bn,'client_id'=>0,
            'client_name'=>$names[$ni],'client_phone'=>$phones[$ni],
            'client_email'=>str_replace(' ','.',strtolower($names[$ni])).'@example.com',
            'trip_type'=>$trip_type,'pickup_city'=>$route[0],'drop_city'=>$route[1],
            'pickup_address'=>'','drop_address'=>'',
            'journey_date'=>date('Y-m-d',strtotime('+'.$journey_days_from_now.' days')),
            'journey_time'=>sprintf('%02d:00:00',rand(5,21)),
            'passengers'=>rand(1,4),'vehicle_type_id'=>$vt->id,
            'vendor_id'=>($status!=='pending'&&$status!=='payment_pending')?$vendor_id:null,
            'distance_km'=>$dist,'duration_minutes'=>round($route[4]*60),
            'base_fare'=>$base,'gst_amount'=>$gst,'discount_amount'=>$promo,
            'promo_code'=>$promo?'FIRST10':'','total_fare'=>$total_final,
            'payment_method'=>$payment_methods[$i%count($payment_methods)],
            'payment_status'=>$ps,'status'=>$status,
            'lead_fee_charged'=>round($vt->base_price_per_km*0.8*3),
            'lead_fee_paid'=>($ps==='verified'?1:0),
            'special_requests'=>(rand(0,3)===0?'AC required, window seat':''),
            'created_at'=>date('Y-m-d H:i:s',strtotime('-'.$days_ago.' days')),
        ));
        $bid = $wpdb->insert_id;
        if($bid) { $booking_ids[] = array('id'=>$bid,'vendor_id'=>$vendor_id,'fee'=>round($vt->base_price_per_km*0.8*3),'status'=>$status); }
        $count++;
    }

    /* ── Leads for those bookings ── */
    foreach($booking_ids as $bk) {
        if(!$bk['vendor_id']) continue;
        $lead_status = in_array($bk['status'],['vendor_assigned','driver_en_route','trip_started','completed'],true)?'accepted':($bk['status']==='cancelled'?'rejected':'sent');
        $interest = $lead_status==='accepted'?'driver_confirmed':($lead_status==='rejected'?'cancelled':'sent');
        $wpdb->insert("{$prefix}ridego_leads", array(
            'booking_id'=>$bk['id'],'vendor_id'=>$bk['vendor_id'],
            'status'=>$lead_status,'interest_status'=>$interest,'fee_amount'=>$bk['fee'],
            'sent_at'=>date('Y-m-d H:i:s',strtotime('-'.rand(1,10).' days')),
            'expires_at'=>date('Y-m-d H:i:s',strtotime('+'.rand(5,20).' minutes')),
            'responded_at'=>($lead_status==='accepted'?date('Y-m-d H:i:s',strtotime('-'.rand(0,5).' hours')):null),
        ));
    }

    /* ── Current assignment rows for bookings that already have a vendor working the trip ── */
    foreach($booking_ids as $bk) {
        if(!$bk['vendor_id'] || !in_array($bk['status'],['vendor_assigned','driver_en_route','trip_started','completed'],true)) continue;
        $drv = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$prefix}ridego_fleet_drivers WHERE vendor_id=%d AND status='active' ORDER BY id LIMIT 1",$bk['vendor_id']));
        $veh = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$prefix}ridego_fleet_vehicles WHERE vendor_id=%d AND status='active' ORDER BY id LIMIT 1",$bk['vendor_id']));
        $det = ridego_resolve_assignment_details($bk['vendor_id'],array('driver_id'=>$drv?(int)$drv:null,'vehicle_id'=>$veh?(int)$veh:null));
        if(empty($det['ok'])) continue;
        $lead_id = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$prefix}ridego_leads WHERE booking_id=%d AND vendor_id=%d LIMIT 1",$bk['id'],$bk['vendor_id']));
        ridego_insert_assignment_row($bk['id'],$bk['vendor_id'],$lead_id,$det,'seed',0);
    }

    /* ── Ratings/Reviews ── */
    $review_texts = array(
        'Excellent service! Driver was very professional and punctual. Car was clean and comfortable.',
        'Good experience overall. Driver knew the route well and avoided traffic perfectly.',
        'Very comfortable journey. Driver Mr. Ramesh was courteous and helpful throughout.',
        'Smooth booking process and the cab arrived on time. Will definitely book again!',
        'Great value for money. The Innova was spacious and the driver was friendly.',
        'Superb experience! Better than Ola and Uber for intercity travel. Highly recommend.',
        'Driver was on time, car was clean, no extra charges. Exactly as promised.',
        'Comfortable trip from Delhi to Agra. The stops at Sikandra were a nice touch.',
        'Professional driver, AC was perfect. A bit pricey but totally worth it.',
        'Average service. Car was ok but driver could improve on communication.',
    );
    foreach(array_slice($booking_ids,0,15) as $idx=>$bk) {
        if($bk['status']!=='completed') continue;
        if(empty($bk['vendor_id'])) continue;
        $wpdb->insert("{$prefix}ridego_ratings", array(
            'booking_id'=>$bk['id'],'rater_id'=>0,'rated_id'=>$bk['vendor_id'],'rated_type'=>'vendor',
            'score'=>rand(4,5),'review'=>$review_texts[$idx%count($review_texts)],
            'rating_category'=>'overall','created_at'=>date('Y-m-d H:i:s',strtotime('-'.rand(1,30).' days')),
        ));
    }

    update_option('ridego_demo_seeded', 1);
}

/* Action handler for admin seed button */
add_action('admin_init','ridego_handle_seed_dummy');
function ridego_handle_seed_dummy(){
    if(!isset($_GET['ridego_action'])||$_GET['ridego_action']!=='seed_dummy') return;
    if(!current_user_can('manage_options')) return;
    if(!wp_verify_nonce(isset($_GET['_nonce'])?$_GET['_nonce']:'','ridego_seed_dummy')) return;
    delete_option('ridego_demo_seeded');
    ridego_seed_dummy_data();
    wp_redirect(admin_url('admin.php?page=ridego-tools&ridego_notice=demo_seeded'));exit;
}
