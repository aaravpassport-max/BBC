<?php
/**
 * WP_Sitemaps_Provider implementation for RideGo's route marketing pages —
 * see includes/route-pages-sitemap.php for how this gets registered.
 * Every URL comes straight from a real, published wp_ridego_route_pages
 * row (see includes/route-pages.php for that table's shape); nothing here
 * is invented or paginated beyond what actually exists.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class RideGo_Route_Pages_Sitemap_Provider extends WP_Sitemaps_Provider {

    const PER_PAGE = 2000; // Same order of magnitude as core's own post-type provider default; the pilot has 13 rows total, so this is always a single page in practice.

    public function __construct() {
        // NOTE: core's own sitemap rewrite rule for a no-subtype provider is
        // `wp-sitemap-([a-z]+?)-(\d+?)\.xml$` — the name group only allows
        // [a-z], no hyphens/digits/underscores — so this must be a single
        // lowercase word or the pretty /wp-sitemap-*.xml URL silently never
        // matches (falls through to the theme's normal 404 instead).
        $this->name        = 'ridegoroutes';
        $this->object_type = 'ridego_route_page';
    }

    // TRACE: how many PUBLISHED route pages really exist → number of sitemap
    //        pages needed at self::PER_PAGE per page → int (min 1, matching
    //        core's own providers' convention of always reporting at least
    //        one page even when the count is currently zero).
    public function get_max_num_pages( $object_subtype = '' ) {
        global $wpdb;
        $ptbl  = $wpdb->prefix . 'ridego_route_pages';
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$ptbl} WHERE status = 'published'" );
        return max( 1, (int) ceil( $count / self::PER_PAGE ) );
    }

    // TRACE: a 1-based sitemap page number → the real published route pages
    //        for that page, each as a core-shaped sitemap URL entry (loc +
    //        lastmod) → array. lastmod is the row's own real published_at,
    //        falling back to its updated_at (ON UPDATE CURRENT_TIMESTAMP) for
    //        the rare case published_at is null on an older row — never
    //        "now" and never a fabricated date.
    public function get_url_list( $page_num, $object_subtype = '' ) {
        global $wpdb;
        $ptbl = $wpdb->prefix . 'ridego_route_pages';
        $per_page = self::PER_PAGE;
        $offset   = ( max( 1, (int) $page_num ) - 1 ) * $per_page;

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT slug, published_at, updated_at FROM {$ptbl}
             WHERE status = 'published'
             ORDER BY id ASC
             LIMIT %d OFFSET %d",
            $per_page, $offset
        ) );

        $urls = array();
        foreach ( $rows as $r ) {
            $lastmod = $r->published_at ? $r->published_at : $r->updated_at;
            $urls[]  = array(
                'loc'     => home_url( '/routes/' . $r->slug . '/' ),
                'lastmod' => $lastmod ? mysql2date( DATE_W3C, $lastmod, false ) : '',
            );
        }
        return $urls;
    }
}
