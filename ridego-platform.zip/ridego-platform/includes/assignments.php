<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   BOOKING ASSIGNMENTS  (Marketplace Plan — sections E, F, J)
   ------------------------------------------------------------
   ridego_booking_assignments is the immutable historical record
   of which driver/vehicle was actually used for a booking. The
   _snapshot columns mean a vendor editing or deleting a driver
   profile later never changes what a historical booking shows.
   A driver/vehicle REPLACEMENT is a new row (replaces_assignment_id
   pointing at the old one) — never a new booking status.
   The DB guarantees "exactly one current row per booking" through
   the UNIQUE current_booking_id column (set only while is_current=1).
   ============================================================ */

// TRACE: any read of "who is doing this trip" → SELECT the is_current=1 row for a booking →
//        returns the row object or null. Postconditions: at most one row (DB-enforced).
//        Edge cases: booking never assigned / reopened → null.
function ridego_get_current_assignment( $booking_id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_booking_assignments WHERE booking_id=%d AND is_current=1 LIMIT 1", (int) $booking_id
    ) );
}

// TRACE: booking detail / admin history → SELECT every assignment row for a booking oldest first →
//        array of row objects (the full replacement history in one ORDER BY created_at query).
//        Edge: none → empty array.
function ridego_get_assignment_history( $booking_id ) {
    global $wpdb;
    return $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_booking_assignments WHERE booking_id=%d ORDER BY created_at ASC, id ASC", (int) $booking_id
    ) );
}

// TRACE: assignment creation/replacement → turns caller input into a validated snapshot of
//        driver/vehicle: when driver_id/vehicle_id is given the row must belong to $vendor_id and
//        its name/mobile/model/registration are COPIED; otherwise the free-text fields are used →
//        returns array('ok'=>bool,'error'=>string,'driver_id','driver_name','driver_phone',
//        'vehicle_id','vehicle_model','vehicle_registration'). Preconditions: $input keys optional.
//        Postconditions: read-only; never writes. Edge cases: driver/vehicle of another vendor
//        (error); id given but row missing (error); nothing supplied (ok with all blanks — the
//        instant-accept path for a fleet vendor whose driver is not chosen yet).
function ridego_resolve_assignment_details( $vendor_id, $input ) {
    $out = array( 'ok' => true, 'error' => '', 'driver_id' => null, 'driver_name' => '', 'driver_phone' => '', 'vehicle_id' => null, 'vehicle_model' => '', 'vehicle_registration' => '' );
    $did = ! empty( $input['driver_id'] ) ? (int) $input['driver_id'] : 0;
    $vid = ! empty( $input['vehicle_id'] ) ? (int) $input['vehicle_id'] : 0;
    if ( $did ) {
        $d = ridego_get_fleet_driver( $did );
        if ( ! $d || (int) $d->vendor_id !== (int) $vendor_id ) { $out['ok'] = false; $out['error'] = 'That driver does not belong to this vendor.'; return $out; }
        if ( (int) ridego_get_setting( 'require_complete_driver_profile', 1 ) === 1 ) {
            $missing = ridego_driver_missing_fields( $d );
            if ( $missing ) { $out['ok'] = false; $out['error'] = 'Complete the driver profile for ' . $d->name . ' before using them on a trip. Missing: ' . implode( ', ', $missing ) . '.'; return $out; }
        }
        $out['driver_id'] = $did; $out['driver_name'] = (string) $d->name; $out['driver_phone'] = (string) $d->mobile; $out['driver_profile'] = ridego_driver_profile_snapshot( $d );
    } else {
        $out['driver_name']  = sanitize_text_field( (string) ( $input['driver_name'] ?? '' ) );
        $out['driver_phone'] = preg_replace( '/\D/', '', (string) ( $input['driver_phone'] ?? '' ) );
    }
    if ( $vid ) {
        $v = ridego_get_fleet_vehicle( $vid );
        if ( ! $v || (int) $v->vendor_id !== (int) $vendor_id ) { $out['ok'] = false; $out['error'] = 'That vehicle does not belong to this vendor.'; return $out; }
        $out['vehicle_id'] = $vid; $out['vehicle_model'] = trim( (string) $v->make_model ); $out['vehicle_registration'] = (string) $v->registration_number;
    } else {
        $out['vehicle_model']        = sanitize_text_field( (string) ( $input['vehicle_model'] ?? '' ) );
        $out['vehicle_registration'] = ridego_normalize_registration( $input['vehicle_registration'] ?? '' );
    }
    return $out;
}

// TRACE: transactional callers (admin assign, instant accept, auto assign) → INSERTs one is_current=1
//        assignment row (current_booking_id = booking_id) → returns the new id or false. Must be
//        called INSIDE the caller's transaction so a failure rolls the booking assignment back with it.
//        Preconditions: booking has no current row (else the UNIQUE key rejects the insert and false
//        is returned). Postconditions: exactly one new current row with snapshot columns filled.
//        Edge cases: unique-key clash (false, $wpdb->last_error holds why); blank details (row with
//        blank snapshots, fillable later by ridego_replace_assignment()).
function ridego_insert_assignment_row( $booking_id, $vendor_id, $lead_id, $details, $source, $changed_by, $replaces_id = null, $reason = '' ) {
    global $wpdb;
    /* Central guarantee: any row that names a fleet driver carries that driver's trace snapshot, even when
       the caller (admin assign of a lead-confirmed driver) only passed id/name/phone. */
    if ( empty( $details['driver_profile'] ) && ! empty( $details['driver_id'] ) ) {
        $drv_row = ridego_get_fleet_driver( (int) $details['driver_id'] );
        if ( $drv_row && (int) $drv_row->vendor_id === (int) $vendor_id ) { $details['driver_profile'] = ridego_driver_profile_snapshot( $drv_row ); }
    }
    $ok = $wpdb->insert( "{$wpdb->prefix}ridego_booking_assignments", array(
        'booking_id' => (int) $booking_id,
        'lead_id'    => $lead_id ? (int) $lead_id : null,
        'vendor_id'  => (int) $vendor_id,
        'driver_id'  => $details['driver_id'],
        'driver_name_snapshot'  => $details['driver_name'],
        'driver_phone_snapshot' => $details['driver_phone'],
        'vehicle_id' => $details['vehicle_id'],
        'vehicle_model_snapshot' => $details['vehicle_model'],
        'vehicle_registration_snapshot' => $details['vehicle_registration'],
        'is_current' => 1,
        'current_booking_id' => (int) $booking_id,
        'replaces_assignment_id' => $replaces_id ? (int) $replaces_id : null,
        'replacement_reason' => substr( sanitize_text_field( (string) $reason ), 0, 255 ),
        'source'     => substr( sanitize_key( (string) $source ), 0, 20 ),
        'changed_by' => (int) $changed_by,
        'driver_profile_snapshot' => ! empty( $details['driver_profile'] ) ? wp_json_encode( $details['driver_profile'] ) : null,
        'created_at' => current_time( 'mysql' ),
    ) );
    return $ok ? (int) $wpdb->insert_id : false;
}

// TRACE: instant-accept path → derives the assignment details an INDIVIDUAL vendor implicitly offers
//        (their single saved vehicle + driver) or blanks for a fleet vendor → returns the details
//        array shape of ridego_resolve_assignment_details(). Postconditions: may lazily provision the
//        individual rows. Edge cases: individual vendor whose vehicle has no plate yet (details carry
//        the driver only and the vehicle stays blank so the client is never shown a fake plate).
function ridego_default_assignment_details_for_vendor( $vendor_id ) {
    $vendor = ridego_get_vendor( (int) $vendor_id );
    $blank = array( 'ok' => true, 'error' => '', 'driver_id' => null, 'driver_name' => '', 'driver_phone' => '', 'vehicle_id' => null, 'vehicle_model' => '', 'vehicle_registration' => '' );
    if ( ! $vendor || ridego_get_vendor_type( $vendor ) !== 'individual' ) { return $blank; }
    $rows = ridego_ensure_individual_provisioned( $vendor->id );
    if ( ! $rows ) { return $blank; }
    $in = array();
    if ( ! empty( $rows['driver'] ) && $rows['driver']->status === 'active' ) { $in['driver_id'] = (int) $rows['driver']->id; }
    if ( ! empty( $rows['vehicle'] ) && $rows['vehicle']->status === 'active' && $rows['vehicle']->registration_number !== '' ) { $in['vehicle_id'] = (int) $rows['vehicle']->id; }
    return ridego_resolve_assignment_details( $vendor->id, $in );
}

// TRACE: vendor "set details" (instant-accept fleet) or admin/vendor mid-trip change → either FILLS the
//        blank current assignment in place (first confirmation, no history row) or REPLACES it with a
//        new row (old flips to is_current=0, new points back via replaces_assignment_id) →
//        returns array(success,message,assignment_id,mode 'filled'|'replaced'). $actor_type is
//        'vendor'|'admin'. Preconditions: booking has a vendor and status vendor_assigned,
//        driver_en_route or trip_started; details belong to the booking's vendor; a changed driver/
//        vehicle passes ridego_check_fleet_availability() (own booking excluded). Postconditions:
//        exactly one current row; replacement events recorded; client + admins notified;
//        audit-logged. Edge cases: no vendor / wrong status / vendor is not the booking's vendor
//        (refused); nothing actually changed (refused); driver or vehicle unavailable (refused with
//        the reason); details of another vendor (refused); any DB failure inside the transaction
//        rolls everything back and reports failure (no half-replacement).
function ridego_replace_assignment( $booking_id, $input, $actor_id, $actor_type = 'admin', $reason = '' ) {
    global $wpdb;
    $booking_id = (int) $booking_id;
    $b = ridego_get_booking( $booking_id );
    if ( ! $b ) { return array( 'success' => false, 'message' => 'Booking not found.' ); }
    if ( empty( $b->vendor_id ) ) { return array( 'success' => false, 'message' => 'No vendor is assigned to this booking yet.' ); }
    if ( ! in_array( $b->status, ridego_fleet_committed_statuses(), true ) ) {
        return array( 'success' => false, 'message' => 'Driver and vehicle can only be changed on an assigned, active trip.' );
    }
    if ( $actor_type === 'vendor' ) {
        $v = ridego_get_vendor_by_user( (int) $actor_id );
        if ( ! $v || (int) $v->id !== (int) $b->vendor_id ) { return array( 'success' => false, 'message' => 'This booking is not assigned to you.' ); }
    }

    $new = ridego_resolve_assignment_details( $b->vendor_id, (array) $input );
    if ( ! $new['ok'] ) { return array( 'success' => false, 'message' => $new['error'] ); }
    if ( $new['driver_name'] === '' && $new['vehicle_registration'] === '' ) {
        return array( 'success' => false, 'message' => 'Choose a driver and/or vehicle.' );
    }

    $time = ! empty( $b->journey_time ) ? $b->journey_time : '00:00';
    $dur  = ridego_booking_duration_minutes( $b );
    if ( $new['driver_id'] ) {
        $av = ridego_check_fleet_availability( 'driver', $new['driver_id'], $b->journey_date, $time, $dur, $booking_id );
        if ( ! $av['available'] ) { return array( 'success' => false, 'message' => 'That driver is not available: ' . $av['reason'] ); }
    }
    if ( $new['vehicle_id'] ) {
        $av = ridego_check_fleet_availability( 'vehicle', $new['vehicle_id'], $b->journey_date, $time, $dur, $booking_id );
        if ( ! $av['available'] ) { return array( 'success' => false, 'message' => 'That vehicle is not available: ' . $av['reason'] ); }
    }

    $wpdb->query( 'START TRANSACTION' );
    $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}ridego_bookings WHERE id=%d FOR UPDATE", $booking_id ) );
    $cur = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_booking_assignments WHERE booking_id=%d AND is_current=1 FOR UPDATE", $booking_id
    ) );

    $blank_current = $cur && empty( $cur->driver_id ) && empty( $cur->vehicle_id ) && $cur->driver_name_snapshot === '' && $cur->vehicle_registration_snapshot === '';
    $mode = 'replaced';
    $new_id = false;
    if ( $blank_current ) {
        $mode = 'filled';
        $res = $wpdb->update( "{$wpdb->prefix}ridego_booking_assignments", array(
            'driver_id' => $new['driver_id'], 'driver_name_snapshot' => $new['driver_name'], 'driver_phone_snapshot' => $new['driver_phone'],
            'vehicle_id' => $new['vehicle_id'], 'vehicle_model_snapshot' => $new['vehicle_model'], 'vehicle_registration_snapshot' => $new['vehicle_registration'],
            'driver_profile_snapshot' => ! empty( $new['driver_profile'] ) ? wp_json_encode( $new['driver_profile'] ) : null,
            'changed_by' => (int) $actor_id,
        ), array( 'id' => (int) $cur->id ) );
        $new_id = ( $res === false ) ? false : (int) $cur->id;
    } else {
        $driver_changed  = ! $cur || (int) $cur->driver_id !== (int) $new['driver_id'] || $cur->driver_name_snapshot !== $new['driver_name'];
        $vehicle_changed = ! $cur || (int) $cur->vehicle_id !== (int) $new['vehicle_id'] || $cur->vehicle_registration_snapshot !== $new['vehicle_registration'];
        if ( $cur && ! $driver_changed && ! $vehicle_changed ) {
            $wpdb->query( 'ROLLBACK' );
            return array( 'success' => false, 'message' => 'Nothing changed — that driver and vehicle are already assigned.' );
        }
        $flip_ok = true;
        if ( $cur ) {
            $flip_ok = ( $wpdb->update( "{$wpdb->prefix}ridego_booking_assignments", array( 'is_current' => 0, 'current_booking_id' => null ), array( 'id' => (int) $cur->id ) ) !== false );
        }
        if ( $flip_ok ) {
            $new_id = ridego_insert_assignment_row( $booking_id, $b->vendor_id, $cur ? $cur->lead_id : null, $new, $actor_type === 'vendor' ? 'vendor_replace' : 'admin_replace', $actor_id, $cur ? $cur->id : null, $reason );
        }
    }
    if ( ! $new_id ) {
        $wpdb->query( 'ROLLBACK' );
        ridego_log( 'replace_assignment failed: ' . $wpdb->last_error );
        return array( 'success' => false, 'message' => 'Could not change the driver/vehicle. Please try again.' );
    }
    $wpdb->query( 'COMMIT' );

    if ( $mode === 'replaced' && $cur ) {
        $note = substr( 'Replaced on booking ' . $b->booking_number . ( $reason ? ': ' . $reason : '' ), 0, 255 );
        if ( (int) $cur->driver_id !== (int) $new['driver_id'] || $cur->driver_name_snapshot !== $new['driver_name'] ) {
            ridego_record_service_event( $booking_id, 'vendor', $b->vendor_id, 'driver_replaced', null, $note, $actor_id );
            if ( $cur->driver_id ) { ridego_record_service_event( $booking_id, 'driver', $cur->driver_id, 'driver_replaced', null, $note, $actor_id ); }
        }
        if ( (int) $cur->vehicle_id !== (int) $new['vehicle_id'] || $cur->vehicle_registration_snapshot !== $new['vehicle_registration'] ) {
            ridego_record_service_event( $booking_id, 'vendor', $b->vendor_id, 'vehicle_replaced', null, $note, $actor_id );
            if ( $cur->vehicle_id ) { ridego_record_service_event( $booking_id, 'vehicle', $cur->vehicle_id, 'vehicle_replaced', null, $note, $actor_id ); }
        }
        ridego_notify_assignment_change( $b, $new, 'driver_vehicle_replaced' );
    } else {
        ridego_notify_assignment_change( $b, $new, 'driver_assigned' );
    }
    ridego_audit_log( 'assignment_' . $mode, 'booking', $booking_id, $cur ? ( $cur->driver_name_snapshot . ' / ' . $cur->vehicle_registration_snapshot ) : '', $new['driver_name'] . ' / ' . $new['vehicle_registration'] );
    return array( 'success' => true, 'message' => $mode === 'filled' ? 'Driver and vehicle confirmed.' : 'Driver/vehicle changed. The client has been notified.', 'assignment_id' => $new_id, 'mode' => $mode );
}

// TRACE: after an assignment row is written (initial or replacement) → queues the client notification
//        (driver_assigned or driver_vehicle_replaced) and in-app notices for staff who can compare
//        vendor responses → returns void. Postconditions: driver contact NUMBER is deliberately NOT sent
//        to the client (plan section K: tap-to-call only after the trip starts) — the payload carries
//        a placeholder sentence instead. Edge cases: guest booking (client_id 0 → client skipped);
//        no staff users (nothing extra).
function ridego_notify_assignment_change( $b, $details, $event ) {
    $payload = array(
        'booking_id'     => (int) $b->id,
        'booking_number' => $b->booking_number,
        'client_name'    => $b->client_name,
        'driver_name'    => $details['driver_name'] !== '' ? $details['driver_name'] : 'Your driver',
        'driver_phone'   => 'shared once your trip starts',
        'vehicle_model'  => $details['vehicle_model'] !== '' ? $details['vehicle_model'] : 'Vehicle',
        'vehicle_number' => $details['vehicle_registration'] !== '' ? $details['vehicle_registration'] : 'to be confirmed',
        'otp'            => (string) $b->otp_pickup,
        'tracking_link'  => home_url( '/my-trips' ),
    );
    if ( (int) $b->client_id > 0 ) { ridego_queue_notification( (int) $b->client_id, $event, $payload ); }
    if ( $event === 'driver_vehicle_replaced' ) { ridego_notify_staff( 'driver_vehicle_replaced', $payload, 'ridego_manage_bookings' ); }
}

// TRACE: any staff-facing event → writes an in-app notification row for up to 25 users holding the given
//        capability and one Telegram alert (the existing admin channel) → returns the number of in-app
//        rows written. Best effort: it never throws and never blocks the business action. Preconditions:
//        $cap is a RideGo capability. Edge cases: no matching users (Telegram only); ridego_log_
//        notification missing (skipped).
function ridego_notify_staff( $event, $payload, $cap = 'ridego_manage_bookings' ) {
    $msg = function_exists( 'ridego_notification_human_message' ) ? ridego_notification_human_message( $event, $payload ) : $event;
    $n = 0;
    $users = get_users( array( 'capability' => $cap, 'fields' => 'ID', 'number' => 25 ) );
    foreach ( (array) $users as $uid ) {
        if ( function_exists( 'ridego_log_notification' ) ) { ridego_log_notification( (int) $uid, $event, 'in_app', $msg, true ); $n++; }
    }
    ridego_telegram_alert( '<b>' . strtoupper( str_replace( '_', ' ', $event ) ) . '</b>' . "\n" . $msg );
    return $n;
}
