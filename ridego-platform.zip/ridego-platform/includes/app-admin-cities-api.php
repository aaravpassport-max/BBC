<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Phase B, wave 3: cities management
   ------------------------------------------------------------
   Same discipline as the vendor and booking admin API waves: read
   the real schema and real admin page before writing a line of
   code (confirmed via a dedicated research pass), then build a
   thin REST layer.

   Scope for THIS wave: the Cities tab only (add/edit/toggle-active/
   deactivate, list with usage counts). admin/pages/cities.php also
   has Routes and Zones tabs — those are a genuinely separate slice
   of work (different tables, different admin workflow) and are
   deliberately left for a follow-up wave rather than padded in
   here just to look complete.

   UPDATE: cities add/edit/toggle previously had no canonical write
   function — both this file and admin/pages/cities.php did their
   own raw $wpdb calls, and only this REST layer invalidated the
   ridego_cities_* transient cache on write (a real staleness bug
   the legacy page still had). Both gaps are now closed: add/edit/
   toggle are consolidated into ridego_create_city()/
   ridego_update_city()/ridego_toggle_city_active()
   (includes/helpers.php), which both this file and the legacy admin
   page now call — cache invalidation and lat/lng validation happen
   in one place for both callers. See that section's doc comment.

   Every route requires is_user_logged_in() AND
   ridego_can('ridego_manage_pricing') — the exact capability
   admin/pages/cities.php itself gates on.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_cities_api_routes' );
function ridego_register_app_admin_cities_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/cities', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_cities_list',
        'permission_callback' => 'ridego_app_admin_api_cities_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/cities', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_city_create',
        'permission_callback' => 'ridego_app_admin_api_cities_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/cities/(?P<id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_city_update',
        'permission_callback' => 'ridego_app_admin_api_cities_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/cities/(?P<id>\d+)/toggle', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_city_toggle',
        'permission_callback' => 'ridego_app_admin_api_cities_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/cities/upload-image', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_city_upload_image',
        'permission_callback' => 'ridego_app_admin_api_cities_permission',
    ) );
}

/**
 * Uploads a "Popular cities" photo (same discipline as
 * ridego_branding_api_upload() in includes/branding.php: real file-type
 * check from contents, size cap, WordPress's own upload handler — never a
 * URL typed/pasted in, so nothing here can reference an off-site image).
 * Returns the URL only; the admin UI then sends it back as image_url on a
 * city create/update, exactly like the branding hero-image flow.
 */
function ridego_app_admin_api_city_upload_image( WP_REST_Request $req ) {
    $files = $req->get_file_params();
    if ( empty( $files['file'] ) || ! empty( $files['file']['error'] ) || empty( $files['file']['tmp_name'] ) ) {
        return new WP_Error( 'no_file', 'Choose an image to upload.', array( 'status' => 400 ) );
    }
    $f = $files['file'];
    $max_bytes = 2 * 1024 * 1024;
    if ( (int) $f['size'] > $max_bytes ) {
        return new WP_Error( 'too_big', 'The image must be 2 MB or smaller.', array( 'status' => 400 ) );
    }
    $check = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], array( 'png' => 'image/png', 'jpg|jpeg' => 'image/jpeg', 'webp' => 'image/webp' ) );
    if ( empty( $check['ext'] ) || empty( $check['type'] ) ) {
        return new WP_Error( 'bad_type', 'Upload a png, jpg or webp image.', array( 'status' => 400 ) );
    }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    $up = wp_handle_upload( $f, array( 'test_form' => false, 'mimes' => array( 'png' => 'image/png', 'jpg|jpeg' => 'image/jpeg', 'webp' => 'image/webp' ) ) );
    if ( ! empty( $up['error'] ) || empty( $up['url'] ) ) {
        return new WP_Error( 'upload_failed', 'The image could not be saved. Please try again.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'url' => esc_url_raw( $up['url'] ) ) );
}

function ridego_app_admin_api_cities_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_pricing' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage cities.', array( 'status' => 403 ) );
    }
    return true;
}

/**
 * Full city list for the admin screen (all cities, active + inactive,
 * with lat/lng/airport/popular/sort_order — a richer shape than the
 * public /app/cities endpoint, which only returns {id,name,state}
 * for active cities). Also reports how many routes/zones reference
 * each city, since the legacy admin page gives no warning that
 * deactivating a city leaves its routes/zones referencing it as if
 * nothing changed (confirmed by research: no cascade exists).
 */
function ridego_app_admin_api_cities_list( WP_REST_Request $req ) {
    global $wpdb;
    $ctbl = $wpdb->prefix . 'ridego_cities';
    $rtbl = $wpdb->prefix . 'ridego_routes';
    $ztbl = $wpdb->prefix . 'ridego_zones';

    $rows = $wpdb->get_results( "SELECT * FROM {$ctbl} ORDER BY is_popular DESC, sort_order ASC, state ASC, name ASC" );

    $route_counts = $wpdb->get_results(
        "SELECT from_city_id AS city_id, COUNT(*) AS c FROM {$rtbl} GROUP BY from_city_id
         UNION ALL
         SELECT to_city_id AS city_id, COUNT(*) AS c FROM {$rtbl} GROUP BY to_city_id",
        ARRAY_A
    );
    $route_usage = array();
    foreach ( (array) $route_counts as $rc ) {
        $cid = (int) $rc['city_id'];
        $route_usage[ $cid ] = ( isset( $route_usage[ $cid ] ) ? $route_usage[ $cid ] : 0 ) + (int) $rc['c'];
    }

    $zone_usage = array();
    if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $ztbl ) ) === $ztbl ) {
        $zc = $wpdb->get_results( "SELECT city_id, COUNT(*) AS c FROM {$ztbl} GROUP BY city_id", ARRAY_A );
        foreach ( (array) $zc as $row ) {
            $zone_usage[ (int) $row['city_id'] ] = (int) $row['c'];
        }
    }

    $out = array_map( function ( $c ) use ( $route_usage, $zone_usage ) {
        $id = (int) $c->id;
        return array(
            'id'           => $id,
            'name'         => $c->name,
            'slug'         => $c->slug,
            'state'        => $c->state,
            'country'      => $c->country,
            'lat'          => $c->lat !== null ? (float) $c->lat : null,
            'lng'          => $c->lng !== null ? (float) $c->lng : null,
            'airport_name' => $c->airport_name,
            'airport_code' => $c->airport_code,
            'is_popular'   => (bool) $c->is_popular,
            'is_active'    => (bool) $c->is_active,
            'sort_order'   => (int) $c->sort_order,
            'image_url'    => isset( $c->image_url ) ? $c->image_url : '',
            'is_origin_enabled'      => isset( $c->is_origin_enabled ) ? (bool) $c->is_origin_enabled : true,
            'is_destination_enabled' => isset( $c->is_destination_enabled ) ? (bool) $c->is_destination_enabled : true,
            'route_count'  => isset( $route_usage[ $id ] ) ? $route_usage[ $id ] : 0,
            'zone_count'   => isset( $zone_usage[ $id ] ) ? $zone_usage[ $id ] : 0,
        );
    }, $rows );

    return rest_ensure_response( array( 'rows' => $out, 'total' => count( $out ) ) );
}

/**
 * Builds the raw input array ridego_validate_city_input() expects, from
 * a REST request. is_origin_enabled/is_destination_enabled are only
 * included when the request actually sent them — ridego_validate_city_input()
 * uses array_key_exists() to tell "not sent" (default both roles on,
 * so a request that's never heard of these two flags behaves exactly
 * as it did before this feature existed) apart from "sent as false"
 * (React admin form's checkboxes explicitly unchecked).
 */
function ridego_app_admin_api_city_raw_input( WP_REST_Request $req ) {
    $raw = array(
        'name'         => $req->get_param( 'name' ),
        'slug'         => $req->get_param( 'slug' ),
        'state'        => $req->get_param( 'state' ),
        'country'      => $req->get_param( 'country' ),
        'lat'          => $req->get_param( 'lat' ),
        'lng'          => $req->get_param( 'lng' ),
        'airport_name' => $req->get_param( 'airport_name' ),
        'airport_code' => $req->get_param( 'airport_code' ),
        'is_popular'   => $req->get_param( 'is_popular' ),
        'sort_order'   => $req->get_param( 'sort_order' ),
    );
    if ( $req->get_param( 'is_origin_enabled' ) !== null ) {
        $raw['is_origin_enabled'] = $req->get_param( 'is_origin_enabled' );
    }
    if ( $req->get_param( 'is_destination_enabled' ) !== null ) {
        $raw['is_destination_enabled'] = $req->get_param( 'is_destination_enabled' );
    }
    // Only included when the request actually sent it (even as ''), matching the
    // is_origin_enabled/is_destination_enabled pattern above — see
    // ridego_validate_city_input()/ridego_update_city() for why that matters.
    if ( $req->get_param( 'image_url' ) !== null ) {
        $raw['image_url'] = $req->get_param( 'image_url' );
    }
    return $raw;
}

/** Delegates to the canonical ridego_create_city() (includes/helpers.php). */
function ridego_app_admin_api_city_create( WP_REST_Request $req ) {
    $is_active = $req->get_param( 'is_active' );
    $r = ridego_create_city( ridego_app_admin_api_city_raw_input( $req ), $is_active === null ? true : (bool) $is_active );
    if ( empty( $r['success'] ) ) {
        return new WP_Error( 'create_failed', $r['message'], array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'id' => $r['id'], 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_update_city() (includes/helpers.php). */
function ridego_app_admin_api_city_update( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    $is_active = $req->get_param( 'is_active' );
    $r = ridego_update_city( $id, ridego_app_admin_api_city_raw_input( $req ), $is_active === null ? null : (bool) $is_active );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'City not found.' ? 404 : 400;
        return new WP_Error( 'update_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'] ) );
}

/**
 * Toggle is_active — delegates to the canonical
 * ridego_toggle_city_active() (includes/helpers.php). The legacy
 * admin page's "delete" action is really this same toggle (sets
 * is_active=0, no hard delete) — named honestly here as "toggle"
 * rather than "delete" since that's what it actually does.
 */
function ridego_app_admin_api_city_toggle( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    $r = ridego_toggle_city_active( $id );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'City not found.' ? 404 : 500;
        return new WP_Error( 'toggle_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array(
        'success'   => true,
        'is_active' => $r['is_active'],
        'message'   => $r['message'],
    ) );
}
