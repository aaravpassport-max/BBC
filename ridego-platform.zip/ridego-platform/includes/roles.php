<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   USER ROLES & CAPABILITIES
   ============================================================ */
function ridego_register_roles() {

    /*  1. CLIENT  */
    if ( ! get_role('ridego_client') ) {
        add_role( 'ridego_client', 'RideGo Client', array(
            'read'                   => true,
            'ridego_book_ride'       => true,
            'ridego_view_own_bookings'=> true,
            'ridego_cancel_own_booking'=> true,
            'ridego_rate_trip'       => true,
            'ridego_file_complaint'  => true,
            'ridego_edit_profile'    => true,
        ));
    }

    /*  2. VENDOR / DRIVER  */
    if ( ! get_role('ridego_vendor') ) {
        add_role( 'ridego_vendor', 'RideGo Vendor', array(
            'read'                      => true,
            'ridego_view_leads'         => true,
            'ridego_accept_lead'        => true,
            'ridego_reject_lead'        => true,
            'ridego_view_own_bookings'  => true,
            'ridego_update_trip_status' => true,
            'ridego_manage_fleet'       => true,
            'ridego_view_own_wallet'    => true,
            'ridego_topup_wallet'       => true,
            'ridego_view_own_earnings'  => true,
            'ridego_upload_documents'   => true,
            'ridego_file_complaint'     => true,
            'ridego_edit_profile'       => true,
            'ridego_respond_complaint'  => true,
        ));
    }

    /*  3. MANAGER  */
    if ( ! get_role('ridego_manager') ) {
        add_role( 'ridego_manager', 'RideGo Manager', array(
            'read'                       => true,
            'ridego_view_all_bookings'   => true,
            'ridego_manage_bookings'     => true,
            'ridego_assign_vendor'       => true,
            'ridego_view_vendors'        => true,
            'ridego_manage_complaints'   => true,
            'ridego_manage_promo_codes'  => true,
            'ridego_view_reports'        => true,
            'ridego_manage_content'      => true,
            'ridego_export_data'         => true,
        ));
    }

    /*  4. ADMIN  */
    if ( ! get_role('ridego_admin') ) {
        add_role( 'ridego_admin', 'RideGo Admin', array(
            'read'                       => true,
            'ridego_view_all_bookings'   => true,
            'ridego_manage_bookings'     => true,
            'ridego_assign_vendor'       => true,
            'ridego_cancel_any_booking'  => true,
            'ridego_view_vendors'        => true,
            'ridego_manage_vendors'      => true,
            'ridego_approve_kyc'         => true,
            'ridego_suspend_vendor'      => true,
            'ridego_manage_wallet'       => true,
            'ridego_view_financial'      => true,
            'ridego_manage_promo_codes'  => true,
            'ridego_manage_complaints'   => true,
            'ridego_view_reports'        => true,
            'ridego_manage_content'      => true,
            'ridego_export_data'         => true,
            'ridego_manage_pricing'      => true,
            'ridego_process_refunds'     => true,
        ));
    }

    /*  5. SUPER ADMIN - add all caps to WP administrator  */
    $super_caps = array(
        'ridego_view_all_bookings', 'ridego_manage_bookings', 'ridego_assign_vendor',
        'ridego_cancel_any_booking', 'ridego_view_vendors', 'ridego_manage_vendors',
        'ridego_approve_kyc', 'ridego_suspend_vendor', 'ridego_blacklist_vendor',
        'ridego_manage_wallet', 'ridego_credit_wallet', 'ridego_debit_wallet',
        'ridego_view_financial', 'ridego_manage_promo_codes', 'ridego_manage_complaints',
        'ridego_view_reports', 'ridego_manage_content', 'ridego_export_data',
        'ridego_manage_pricing', 'ridego_manage_lead_fees', 'ridego_process_refunds',
        'ridego_manage_settings', 'ridego_view_audit_log', 'ridego_create_admin_users',
        'ridego_manage_subscriptions', 'ridego_send_bulk_message', 'ridego_delete_data',
        'ridego_book_ride', 'ridego_view_own_bookings',
    );
    $admin_role = get_role('administrator');
    if ( $admin_role ) {
        foreach ( $super_caps as $cap ) {
            $admin_role->add_cap($cap);
        }
        // Explicit, auditable super-admin bypass capability (Wave 2A RBAC
        // fix). Only administrators get this — it is the sole thing that
        // can override a granular RideGo capability check, and every such
        // override is logged (see ridego_current_user_can_ridego() in
        // includes/rbac.php), unlike the old blanket
        // `current_user_can('manage_options')` OR-bypass in ridego_can()
        // which silently collapsed every permission check to "is this a
        // WP admin" with no visibility at all.
        $admin_role->add_cap( 'ridego_super_admin' );
    }
}

/*  Capability check helpers  */
/**
 * Delegates to ridego_current_user_can_ridego() (includes/rbac.php),
 * which fixed the OR-bypass this function used to have. Kept as the
 * public name for backward compatibility with existing call sites.
 */
function ridego_can( $cap ) {
    return ridego_current_user_can_ridego( $cap );
}
function ridego_require_login() {
    if ( ! is_user_logged_in() ) {
        wp_redirect( wp_login_url( get_permalink() ) );
        exit;
    }
}
function ridego_require_vendor() {
    ridego_require_login();
    if ( ! ridego_is_vendor() ) {
        wp_redirect( ridego_page_url('vendor_register_page_id') );
        exit;
    }
}
function ridego_require_admin() {
    if ( ! ridego_can('manage_options') && ! ridego_can('ridego_manage_bookings') ) {
        wp_redirect( home_url('/') );
        exit;
    }
}
