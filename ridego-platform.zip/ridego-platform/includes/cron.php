<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
/* ============================================================
   SCHEDULED JOBS
   ============================================================ */

/*  Register schedules / events on activation  */
function ridego_schedule_cron() {
    if ( ! wp_next_scheduled( 'ridego_document_expiry_check' ) ) {
        wp_schedule_event( time() + 300, 'daily', 'ridego_document_expiry_check' );
    }
    if ( ! wp_next_scheduled( 'ridego_subscription_renewal_check' ) ) {
        wp_schedule_event( time() + 600, 'daily', 'ridego_subscription_renewal_check' );
    }
    // General-purpose background job queue (includes/jobs.php): every 5 minutes, same interval and
    // 'every_5_minutes' custom schedule the notification queue already registers (see notifications.php,
    // which defines that schedule — this hook just adds a second consumer of it rather than defining a
    // duplicate schedule of its own).
    if ( ! wp_next_scheduled( 'ridego_process_job_queue' ) ) {
        wp_schedule_event( time() + 120, 'every_5_minutes', 'ridego_process_job_queue' );
    }
}
add_action( 'ridego_document_expiry_check', 'ridego_run_document_expiry_check' );
add_action( 'ridego_process_job_queue', 'ridego_process_job_queue' );
/* ridego_subscription_renewal_check is hooked to ridego_run_subscription_renewal_check()
   in includes/subscriptions.php (Wave 2D), following this same daily-cron pattern. */

/*  Daily: find vendors/docs expiring soon, notify, and flag expired  */
// TRACE: daily cron ridego_document_expiry_check → notifies about and flags expired vendor-LEVEL documents only (fleet vehicle/driver docs excluded so a lapsed fleet document never suspends the whole vendor) → void.
//        Preconditions: none → Postconditions: vendor status 'expired_docs' only for vendor-level expiry → Edge cases: no expiring docs (no-op).
function ridego_run_document_expiry_check() {
    global $wpdb;
    $vtbl = $wpdb->prefix . 'ridego_vendors';
    $dtbl = $wpdb->prefix . 'ridego_driver_docs';
    $today = date('Y-m-d');
    $windows = array(30, 7, 1);

    /* --- Upcoming expiries: driver_docs.expiry_date --- */
    foreach ( $windows as $days ) {
        $target = date('Y-m-d', strtotime("+{$days} days"));
        $docs = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$dtbl} WHERE expiry_date = %s AND status != 'rejected'", $target
        ) );
        foreach ( $docs as $doc ) {
            $vendor = ridego_get_vendor( $doc->vendor_id );
            if ( ! $vendor ) continue;
            ridego_queue_notification( $vendor->user_id, 'document_expiring', array(
                'doc_type'   => $doc->doc_type,
                'expiry_date'=> $doc->expiry_date,
                'days_left'  => $days,
                'vendor_id'  => $vendor->id,
            ) );
        }
    }

    /* --- Upcoming expiries: vendors.license_expiry / insurance_expiry --- */
    foreach ( array('license_expiry' => 'license', 'insurance_expiry' => 'insurance') as $col => $label ) {
        foreach ( $windows as $days ) {
            $target = date('Y-m-d', strtotime("+{$days} days"));
            $vendors = $wpdb->get_results( $wpdb->prepare(
                "SELECT * FROM {$vtbl} WHERE {$col} = %s AND status != 'blacklisted'", $target
            ) );
            foreach ( $vendors as $vendor ) {
                ridego_queue_notification( $vendor->user_id, 'document_expiring', array(
                    'doc_type'   => $label,
                    'expiry_date'=> $vendor->$col,
                    'days_left'  => $days,
                    'vendor_id'  => $vendor->id,
                ) );
            }
        }
    }

    /* --- Already expired: driver_docs --- */
    $expired_docs = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$dtbl} WHERE expiry_date IS NOT NULL AND expiry_date < %s AND status != 'rejected' AND vehicle_id IS NULL AND driver_id IS NULL", $today
    ) );
    $expired_vendor_ids = array();
    foreach ( $expired_docs as $doc ) {
        $expired_vendor_ids[ $doc->vendor_id ] = true;
    }

    /* --- Already expired: vendor license/insurance columns --- */
    $expired_vendors_col = $wpdb->get_results( $wpdb->prepare(
        "SELECT id FROM {$vtbl} WHERE (license_expiry IS NOT NULL AND license_expiry < %s) OR (insurance_expiry IS NOT NULL AND insurance_expiry < %s)",
        $today, $today
    ) );
    foreach ( $expired_vendors_col as $row ) {
        $expired_vendor_ids[ $row->id ] = true;
    }

    foreach ( array_keys( $expired_vendor_ids ) as $vendor_id ) {
        $vendor = ridego_get_vendor( $vendor_id );
        if ( ! $vendor ) continue;
        if ( $vendor->kyc_status !== 'expired_docs' ) {
            $wpdb->update( $vtbl, array( 'kyc_status' => 'expired_docs' ), array( 'id' => $vendor_id ) );
            ridego_audit_log( 'vendor_docs_expired', 'vendor', $vendor_id, $vendor->kyc_status, 'expired_docs' );
            do_action( 'ridego_vendor_docs_expired', $vendor_id );
        }
        ridego_queue_notification( $vendor->user_id, 'document_expired', array( 'vendor_id' => $vendor_id ) );

        /* Alert admins */
        $admins = get_users( array( 'role' => 'ridego_admin', 'fields' => 'ID' ) );
        foreach ( $admins as $admin_id ) {
            ridego_queue_notification( $admin_id, 'vendor_docs_expired_admin_alert', array(
                'vendor_id'   => $vendor_id,
                'vendor_name' => $vendor->business_name,
            ) );
        }
    }
}
