<?php
/**
 * RideGo Marketplace — capabilities and admin role presets (Phase 9 / plan sections O and Z.2).
 * Existing roles are only created when missing, so new caps are granted by a version-gated upgrade routine
 * that runs once per version bump on init. Plan capability names are used verbatim.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! defined( 'RIDEGO_MKT_CAPS_VERSION' ) ) { define( 'RIDEGO_MKT_CAPS_VERSION', 4 ); }

// TRACE: any grant/list code → returns the marketplace admin capability groups → array of arrays. Pure.
function ridego_marketplace_cap_groups() {
    return array(
        'ops'   => array( 'ridego_view_command_centre', 'ridego_view_performance_data', 'ridego_view_ledger', 'ridego_compare_vendor_responses', 'ridego_assign_lead', 'ridego_reassign_lead', 'ridego_view_fleets', 'ridego_bulk_booking_actions' ),
        'fleet' => array( 'ridego_manage_fleet_vehicles' ),
        'fin'   => array( 'ridego_manage_commission_models', 'ridego_settle_ledger' ),
        'auto'  => array( 'ridego_manage_automatic_assignment' ),
        'imp'   => array( 'ridego_impersonate_vendor', 'ridego_impersonate_client', 'ridego_impersonate_regional_manager', 'ridego_impersonate_staff', 'ridego_impersonate_driver' ),
        'crm'   => array( 'ridego_manage_clients', 'ridego_create_admin_booking', 'ridego_edit_booking_details', 'ridego_record_payments', 'ridego_manage_enquiries' ),
    );
}

// TRACE: any grant code → role => caps map for the marketplace → array. Pure. Only administrator gets the
//        impersonation caps (plus the audited ridego_super_admin bypass). Also defines the four named admin
//        presets from plan question Z.2 as real roles built from capability bundles.
function ridego_marketplace_caps_map() {
    $g = ridego_marketplace_cap_groups();
    return array(
        'administrator'  => array_merge( $g['ops'], $g['fleet'], $g['fin'], $g['auto'], $g['imp'], $g['crm'] ),
        'ridego_admin'   => array_merge( $g['ops'], $g['fleet'], $g['fin'], $g['auto'], $g['crm'] ),
        'ridego_manager' => array_merge( $g['ops'], $g['fleet'], $g['crm'] ),
        'ridego_ops_manager' => $g['crm'],
        'ridego_support' => array( 'ridego_manage_clients', 'ridego_manage_enquiries' ),
        'ridego_finance' => array( 'ridego_record_payments' ),
        'ridego_client'  => array( 'ridego_view_own_dashboard' ),
        'ridego_vendor'  => array( 'ridego_view_own_settlements', 'ridego_view_own_performance', 'ridego_rate_client' ),
    );
}

// TRACE: role setup → the named presets (Operations Manager, Vendor Manager, Finance, Support) as
//        slug => array( label, caps ) → array. Pure. These are capability bundles, so an admin can also
//        simply give the same caps to an existing role; nothing else in the code checks role names.
function ridego_marketplace_role_presets() {
    $g = ridego_marketplace_cap_groups();
    return array(
        'ridego_ops_manager' => array( 'RideGo Operations Manager', array_merge( array( 'read', 'ridego_view_all_bookings', 'ridego_manage_bookings', 'ridego_assign_vendor', 'ridego_view_vendors', 'ridego_manage_complaints', 'ridego_view_reports' ), $g['ops'], $g['fleet'], $g['crm'] ) ),
        'ridego_vendor_manager' => array( 'RideGo Vendor Manager', array_merge( array( 'read', 'ridego_view_vendors', 'ridego_manage_vendors', 'ridego_approve_kyc', 'ridego_suspend_vendor', 'ridego_view_all_bookings', 'ridego_view_reports' ), array( 'ridego_view_command_centre', 'ridego_view_performance_data', 'ridego_view_fleets', 'ridego_compare_vendor_responses' ), $g['fleet'] ) ),
        'ridego_finance' => array( 'RideGo Finance', array_merge( array( 'read', 'ridego_view_financial', 'ridego_view_reports', 'ridego_process_refunds', 'ridego_manage_wallet', 'ridego_view_all_bookings', 'ridego_view_vendors' ), array( 'ridego_view_command_centre', 'ridego_view_ledger', 'ridego_record_payments' ), $g['fin'] ) ),
        'ridego_support' => array( 'RideGo Support', array( 'read', 'ridego_view_all_bookings', 'ridego_manage_complaints', 'ridego_view_vendors', 'ridego_send_bulk_message', 'ridego_view_command_centre', 'ridego_manage_clients', 'ridego_manage_enquiries' ) ),
    );
}

// TRACE: init → when stored caps version < current, creates any missing preset role, adds the caps to each existing
//        role and stores the version → void. Edge cases: role missing (skipped), already current (no-op, no writes),
//        stale caps from earlier builds (ridego_impersonate, ridego_manage_commission, ridego_manage_matching,
//        ridego_view_performance) are removed from every role so nothing keeps a dead grant.
function ridego_upgrade_marketplace_caps() {
    if ( (int) get_option( 'ridego_mkt_caps_version', 0 ) >= RIDEGO_MKT_CAPS_VERSION ) { return; }
    foreach ( ridego_marketplace_role_presets() as $slug => $def ) {
        if ( ! get_role( $slug ) ) {
            $caps = array(); foreach ( $def[1] as $c ) { $caps[ $c ] = true; }
            add_role( $slug, $def[0], $caps );
        }
    }
    $stale = array( 'ridego_impersonate', 'ridego_manage_commission', 'ridego_manage_matching', 'ridego_view_performance' );
    foreach ( ridego_marketplace_caps_map() as $role => $caps ) {
        $r = get_role( $role );
        if ( ! $r ) { continue; }
        foreach ( $caps as $cap ) { $r->add_cap( $cap ); }
    }
    foreach ( wp_roles()->role_objects as $r ) { foreach ( $stale as $cap ) { if ( $r->has_cap( $cap ) ) { $r->remove_cap( $cap ); } } }
    update_option( 'ridego_mkt_caps_version', RIDEGO_MKT_CAPS_VERSION );
}
add_action( 'init', 'ridego_upgrade_marketplace_caps', 20 );

// TRACE: auth/me → the marketplace admin caps the SPA nav should know → array of cap names. Pure.
function ridego_marketplace_admin_cap_names() {
    $out = array();
    foreach ( ridego_marketplace_cap_groups() as $caps ) { $out = array_merge( $out, $caps ); }
    return $out;
}
