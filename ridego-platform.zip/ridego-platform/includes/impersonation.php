<?php
/**
 * RideGo Marketplace — admin "view as user" impersonation (Phase 7).
 * A signed httpOnly cookie carries a session id; a DB row (ridego_impersonation_log) is the source of
 * truth. determine_current_user swaps the effective user only while the session row is open, unexpired
 * and belongs to the real logged-in admin. Every audit row written meanwhile records both identities.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! defined( 'RIDEGO_IMPERSONATION_COOKIE' ) ) { define( 'RIDEGO_IMPERSONATION_COOKIE', 'ridego_imp' ); }

// TRACE: any caller → session lifetime in minutes from setting impersonation_minutes (default 30, clamp 5..120) → int.
function ridego_impersonation_minutes() {
    $m = (int) ridego_get_setting( 'impersonation_minutes', 30 );
    return max( 5, min( 120, $m ?: 30 ) );
}

// TRACE: session id → HMAC signature → hex string. Uses wp_salt('auth'). Pure for a given salt.
function ridego_impersonation_sign( $session_id ) {
    return hash_hmac( 'sha256', (string) $session_id, wp_salt( 'auth' ) );
}

// TRACE: raw cookie value 'id.sig' → verifies signature in constant time → session id string or ''.
//        Edge cases: missing dot, wrong length, bad signature (all ''), non-hex id.
function ridego_impersonation_parse_cookie( $raw ) {
    if ( ! is_string( $raw ) || strpos( $raw, '.' ) === false ) { return ''; }
    list( $id, $sig ) = explode( '.', $raw, 2 );
    if ( ! preg_match( '/^[a-f0-9]{32}$/', $id ) ) { return ''; }
    return hash_equals( ridego_impersonation_sign( $id ), (string) $sig ) ? $id : '';
}

// TRACE: request → returns the open, unexpired session row (object) for the cookie or null.
//        Result is cached per request; pass $reset=true after start/stop to drop the cache. Edge cases: no cookie, bad signature, ended/expired session row.
function ridego_impersonation_session( $reset = false ) {
    global $wpdb;
    static $cache = false;
    if ( $reset ) { $cache = false; }
    if ( $cache !== false ) { return $cache; }
    $cache = null;
    $raw = isset( $_COOKIE[ RIDEGO_IMPERSONATION_COOKIE ] ) ? wp_unslash( $_COOKIE[ RIDEGO_IMPERSONATION_COOKIE ] ) : '';
    $id = ridego_impersonation_parse_cookie( $raw );
    if ( $id === '' ) { return null; }
    $row = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_impersonation_log WHERE session_id=%s AND ended_at IS NULL AND expires_at>%s", $id, current_time( 'mysql' ) ) );
    $cache = $row ? $row : null;
    return $cache;
}

// TRACE: filter determine_current_user($user_id) → if a valid session exists AND the WordPress-authenticated
//        user equals the session's admin → returns the target user id; otherwise unchanged.
//        Postconditions: a stolen/forged cookie without the admin's own login cookie changes nothing.
function ridego_impersonation_determine_user( $user_id ) {
    if ( ! $user_id ) { return $user_id; }
    $s = ridego_impersonation_session();
    if ( $s && (int) $s->admin_user_id === (int) $user_id ) { return (int) $s->target_user_id; }
    return $user_id;
}
add_filter( 'determine_current_user', 'ridego_impersonation_determine_user', 99 );

// TRACE: any guard → true while the request runs as an impersonated user.
function ridego_is_impersonating() { return ridego_impersonation_session() !== null; }

// TRACE: audit / UI → real admin user id behind the request (impersonated or not) → int.
function ridego_real_user_id() {
    $s = ridego_impersonation_session();
    return $s ? (int) $s->admin_user_id : (int) get_current_user_id();
}

// TRACE: sensitive endpoint guard → returns array(success=false,message) while impersonating, else null.
//        Callers `if ($g = ridego_impersonation_block()) return $g;`. Used for password, profile, payouts.
function ridego_impersonation_block() {
    return ridego_is_impersonating() ? array( 'success' => false, 'message' => 'This action is not allowed while viewing as another user.' ) : null;
}

// TRACE: admin starts a session → validates real admin capability + target (exists, not an admin/superadmin,
//        not self), closes any prior open session of that admin, inserts a row, sets the signed cookie →
//        array( success, expires_at, target ). Edge cases: no capability, self, target is admin, unknown
//        target, DB failure. Postconditions: exactly one open session per admin.
function ridego_impersonation_start( $admin_id, $target_user_id ) {
    global $wpdb;
    $admin_id = (int) $admin_id; $target_user_id = (int) $target_user_id;
    if ( ridego_is_impersonating() ) { return array( 'success' => false, 'message' => 'Stop the current view-as session first.' ); }
    if ( $target_user_id === $admin_id ) { return array( 'success' => false, 'message' => 'You cannot view as yourself.' ); }
    $target = get_userdata( $target_user_id );
    if ( ! $target ) { return array( 'success' => false, 'message' => 'User not found.' ); }
    $role_map = array( 'ridego_vendor' => 'vendor', 'ridego_client' => 'client', 'ridego_regional_manager' => 'regional_manager', 'ridego_staff' => 'staff', 'ridego_driver' => 'driver' );
    $role = '';
    foreach ( $role_map as $wp_role => $key ) { if ( in_array( $wp_role, (array) $target->roles, true ) ) { $role = $key; break; } }
    if ( $role === '' || user_can( $target_user_id, 'manage_options' ) || user_can( $target_user_id, 'ridego_super_admin' ) || user_can( $target_user_id, 'ridego_impersonate_vendor' ) || user_can( $target_user_id, 'ridego_impersonate_client' ) ) {
        return array( 'success' => false, 'message' => 'This account cannot be viewed as.' );
    }
    if ( ! user_can( $admin_id, 'ridego_impersonate_' . $role ) ) { return array( 'success' => false, 'message' => 'You do not have permission to view as a ' . $role . '.' ); }
    $t = $wpdb->prefix . 'ridego_impersonation_log';
    $wpdb->query( $wpdb->prepare( "UPDATE {$t} SET ended_at=%s, end_reason='replaced' WHERE admin_user_id=%d AND ended_at IS NULL", current_time( 'mysql' ), $admin_id ) );
    $sid = bin2hex( random_bytes( 16 ) );
    $mins = ridego_impersonation_minutes();
    $exp = date( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) + $mins * 60 );
    $ok = $wpdb->insert( $t, array( 'session_id' => $sid, 'admin_user_id' => $admin_id, 'target_user_id' => $target_user_id, 'target_role' => $role,
        'started_at' => current_time( 'mysql' ), 'expires_at' => $exp, 'ip_address' => substr( sanitize_text_field( isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '' ), 0, 45 ) ) );
    if ( ! $ok ) { return array( 'success' => false, 'message' => 'Could not start the session.' ); }
    ridego_impersonation_set_cookie( $sid . '.' . ridego_impersonation_sign( $sid ), time() + $mins * 60 );
    ridego_impersonation_session( true );
    ridego_audit_log( 'impersonation_started', 'user', $target_user_id, '', array( 'role' => $role, 'expires' => $exp ), 'warning' );
    if ( function_exists( 'ridego_notify_staff' ) ) { ridego_notify_staff( 'impersonation_started', array( 'target_user_id' => $target_user_id, 'admin_user_id' => $admin_id ), 'ridego_impersonate_' . $role ); }
    if ( function_exists( 'ridego_telegram_alert' ) ) { ridego_telegram_alert( '<b>VIEW-AS STARTED</b> admin #' . $admin_id . ' → ' . $role . ' user #' . $target_user_id ); }
    return array( 'success' => true, 'expires_at' => $exp, 'target' => array( 'user_id' => $target_user_id, 'role' => $role, 'name' => $target->display_name ) );
}

// TRACE: stop (button or expiry) → marks the open session ended with a reason and clears the cookie →
//        array( success ). Edge cases: no open session (success, nothing to do).
function ridego_impersonation_stop( $reason = 'stopped' ) {
    global $wpdb;
    $s = ridego_impersonation_session();
    if ( ! $s ) { return array( 'success' => true ); }
    $wpdb->update( $wpdb->prefix . 'ridego_impersonation_log', array( 'ended_at' => current_time( 'mysql' ), 'end_reason' => substr( sanitize_key( $reason ), 0, 20 ) ), array( 'id' => (int) $s->id ) );
    ridego_audit_log( 'impersonation_ended', 'user', (int) $s->target_user_id, '', $reason, 'warning' );
    ridego_impersonation_set_cookie( '', time() - 3600 );
    ridego_impersonation_session( true );
    if ( function_exists( 'ridego_notify_staff' ) ) { ridego_notify_staff( 'impersonation_ended', array( 'target_user_id' => (int) $s->target_user_id, 'admin_user_id' => (int) $s->admin_user_id ), 'ridego_impersonate_' . $s->target_role ); }
    return array( 'success' => true );
}

// TRACE: cookie writer → sets/clears the httpOnly SameSite=Lax cookie unless headers already sent →
//        void. Edge cases: CLI/headers sent (skipped; DB row still authoritative).
function ridego_impersonation_set_cookie( $value, $expires ) {
    if ( headers_sent() ) { return; }
    setcookie( RIDEGO_IMPERSONATION_COOKIE, $value, array( 'expires' => $expires, 'path' => COOKIEPATH ?: '/', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) );
    if ( $value === '' ) { unset( $_COOKIE[ RIDEGO_IMPERSONATION_COOKIE ] ); } else { $_COOKIE[ RIDEGO_IMPERSONATION_COOKIE ] = $value; }
}

// TRACE: auth/me payload builder → returns array for the SPA banner or null when not impersonating:
//        target user/role, real admin name, seconds remaining. Edge cases: expired (null).
function ridego_impersonation_payload() {
    $s = ridego_impersonation_session();
    if ( ! $s ) { return null; }
    $admin = get_userdata( (int) $s->admin_user_id );
    return array( 'active' => true, 'target_role' => $s->target_role, 'admin_name' => $admin ? $admin->display_name : '',
        'expires_at' => $s->expires_at, 'seconds_left' => max( 0, strtotime( $s->expires_at ) - strtotime( current_time( 'mysql' ) ) ) );
}

// TRACE: cron sweep → closes sessions past expires_at with end_reason 'expired' → void. Edge cases: none.
function ridego_impersonation_expire_sweep() {
    global $wpdb;
    $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}ridego_impersonation_log SET ended_at=%s, end_reason='expired' WHERE ended_at IS NULL AND expires_at<=%s", current_time( 'mysql' ), current_time( 'mysql' ) ) );
}
add_action( 'ridego_closure_sweep', 'ridego_impersonation_expire_sweep' );
