<?php
/**
 * RideGo Marketplace — matching engine (plan section N). Ships with every flag OFF.
 *
 * Four independent flags, plain settings (ridego_get_setting / ridego_update_setting), all default 0:
 *   automatic_vendor_assignment  - assign the top-ranked vendor without an admin click
 *   automatic_driver_selection   - pick the best available driver+vehicle for a fleet vendor that showed
 *                                  interest but has not confirmed one yet
 *   performance_based_matching   - score responding vendors and store a recommendation (recommend-only)
 *   automatic_reassignment       - when an assigned vendor drops out, assign the next-best responder
 * While a flag is OFF the code behind it is never entered and writes nothing; the performance data
 * (service events, snapshots) keeps populating regardless.
 *
 * The scorer is pure and driven by a versioned weight profile so any profile can be back-tested against
 * completed history before it is activated. Every recommendation is persisted with its full breakdown.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: any matching code → returns the four flag names → array of strings. Pure.
function ridego_matching_flag_names() {
    return array( 'automatic_vendor_assignment', 'automatic_driver_selection', 'performance_based_matching', 'automatic_reassignment' );
}

// TRACE: any matching code → returns the factor names the scorer understands → array of strings. Pure.
function ridego_matching_factors() {
    return array( 'vendor_rating', 'response_time', 'completion_rate', 'route_fit', 'driver_rating', 'vehicle_suitability' );
}

// TRACE: caller → default weights (sum 1.0) → array factor=>weight. Pure.
function ridego_matching_default_weights() {
    return array( 'vendor_rating' => 0.25, 'response_time' => 0.15, 'completion_rate' => 0.20, 'route_fit' => 0.10, 'driver_rating' => 0.15, 'vehicle_suitability' => 0.15 );
}

// TRACE: flag name → reads setting of the same name → bool. Unknown flag (false), unset (false, i.e. OFF).
function ridego_matching_flag( $flag ) {
    if ( ! in_array( $flag, ridego_matching_flag_names(), true ) ) { return false; }
    return (int) ridego_get_setting( $flag, 0 ) === 1;
}

// TRACE: migration 21/22 / lazy reader → makes sure a profile that uses the CURRENT factor names exists; when none does,
//        deactivates every older profile and inserts the default one (new profile_id and version, active) → bool present.
//        Edge cases: already seeded (true, no duplicate), earlier-build profile with other factor names (kept, inactive).
function ridego_matching_seed_default_profile() {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_matching_weight_profiles';
    $factors = ridego_matching_factors();
    $ph = implode( ',', array_fill( 0, count( $factors ), '%s' ) );
    if ( (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE factor IN ({$ph})", $factors ) ) > 0 ) { return true; }
    $pid = (int) $wpdb->get_var( "SELECT COALESCE(MAX(profile_id),0)+1 FROM {$t}" );
    $ver = (int) $wpdb->get_var( "SELECT COALESCE(MAX(version),0)+1 FROM {$t}" );
    $wpdb->query( "UPDATE {$t} SET is_active=0" );
    foreach ( ridego_matching_default_weights() as $f => $w ) {
        $wpdb->insert( $t, array( 'profile_id' => $pid, 'name' => 'Default', 'factor' => $f, 'weight' => $w, 'is_active' => 1, 'version' => $ver, 'created_at' => current_time( 'mysql' ) ) );
    }
    return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE factor IN ({$ph})", $factors ) ) > 0;
}

// TRACE: reader → the profile rows for one profile id (or the active one when null) → array( 'id','name','version',
//        'is_active','weights' ) or null. Falls back to the built-in defaults (id 0) when the id is null and nothing is stored.
//        Edge cases: unknown id (null), table empty/absent, legacy factor names ignored.
function ridego_matching_get_profile( $profile_id = null ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_matching_weight_profiles';
    if ( ridego_table_exists( $t ) ) {
        if ( $profile_id === null ) {
            $rows = $wpdb->get_results( "SELECT * FROM {$t} WHERE is_active=1 ORDER BY profile_id DESC, id ASC", ARRAY_A );
            if ( $rows ) { $profile_id = (int) $rows[0]['profile_id']; $rows = array_filter( $rows, function ( $r ) use ( $profile_id ) { return (int) $r['profile_id'] === $profile_id; } ); }
        } else {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE profile_id=%d ORDER BY id ASC", (int) $profile_id ), ARRAY_A );
        }
        if ( ! empty( $rows ) ) {
            $rows = array_values( $rows ); $w = array();
            foreach ( $rows as $r ) { if ( in_array( $r['factor'], ridego_matching_factors(), true ) ) { $w[ $r['factor'] ] = (float) $r['weight']; } }
            if ( $w ) { return array( 'id' => (int) $rows[0]['profile_id'], 'name' => $rows[0]['name'], 'version' => (int) $rows[0]['version'], 'is_active' => (int) $rows[0]['is_active'] === 1, 'weights' => $w, 'created_at' => $rows[0]['created_at'] ); }
        }
    }
    if ( $profile_id === null ) { return array( 'id' => 0, 'name' => 'Built-in default', 'version' => 0, 'is_active' => true, 'weights' => ridego_matching_default_weights(), 'created_at' => '' ); }
    return null;
}

// TRACE: reader → active profile → same shape as ridego_matching_get_profile(); never null (built-in default fallback).
function ridego_matching_get_active_profile() {
    $p = ridego_matching_get_profile( null );
    return $p ? $p : array( 'id' => 0, 'name' => 'Built-in default', 'version' => 0, 'is_active' => true, 'weights' => ridego_matching_default_weights(), 'created_at' => '' );
}

// TRACE: admin screen → every stored profile version, newest first → array of profile arrays (weights included). Read-only.
//        Edge cases: none stored (empty).
function ridego_matching_list_profiles() {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_matching_weight_profiles';
    if ( ! ridego_table_exists( $t ) ) { return array(); }
    $ids = $wpdb->get_col( "SELECT DISTINCT profile_id FROM {$t} ORDER BY profile_id DESC LIMIT 50" );
    $out = array();
    foreach ( (array) $ids as $id ) { $p = ridego_matching_get_profile( (int) $id ); if ( $p ) { $out[] = $p; } }
    return $out;
}

// TRACE: admin saves new weights → normalises to sum 1 and inserts a NEW profile version that is INACTIVE (old versions are
//        never edited or deleted, so rollback is an activation away) → array( success, profile_id, message ).
//        Edge cases: unknown factor ignored, negative weight, all-zero weights (error), insert failure (rolled back).
function ridego_matching_save_profile( $name, $weights ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_matching_weight_profiles';
    $clean = array(); $sum = 0.0;
    foreach ( ridego_matching_factors() as $f ) {
        $w = isset( $weights[ $f ] ) ? (float) $weights[ $f ] : 0.0;
        if ( $w < 0 ) { return array( 'success' => false, 'message' => 'Weights cannot be negative.' ); }
        $clean[ $f ] = $w; $sum += $w;
    }
    if ( $sum <= 0 ) { return array( 'success' => false, 'message' => 'At least one weight must be above zero.' ); }
    $wpdb->query( 'START TRANSACTION' );
    $pid = (int) $wpdb->get_var( "SELECT COALESCE(MAX(profile_id),0)+1 FROM {$t} FOR UPDATE" );
    $ver = (int) $wpdb->get_var( "SELECT COALESCE(MAX(version),0)+1 FROM {$t}" );
    foreach ( $clean as $f => $w ) {
        $ok = $wpdb->insert( $t, array( 'profile_id' => $pid, 'name' => sanitize_text_field( $name ) ?: 'Custom', 'factor' => $f, 'weight' => round( $w / $sum, 4 ), 'is_active' => 0, 'version' => $ver, 'created_at' => current_time( 'mysql' ) ) );
        if ( ! $ok ) { $wpdb->query( 'ROLLBACK' ); return array( 'success' => false, 'message' => 'Could not save the weight profile.' ); }
    }
    $wpdb->query( 'COMMIT' );
    ridego_audit_log( 'matching_profile_saved', 'matching', $pid, null, $clean );
    return array( 'success' => true, 'profile_id' => $pid, 'message' => 'Saved as an inactive profile. Back-test it, then activate it.' );
}

// TRACE: admin activates a stored profile → deactivates every other profile and activates this one in one transaction →
//        array( success, message ). Edge cases: unknown id, already active (success), DB failure (rolled back).
function ridego_matching_activate_profile( $profile_id ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_matching_weight_profiles';
    $p = ridego_matching_get_profile( (int) $profile_id );
    if ( ! $p || $p['id'] === 0 ) { return array( 'success' => false, 'message' => 'Weight profile not found.' ); }
    $wpdb->query( 'START TRANSACTION' );
    $a = $wpdb->query( "UPDATE {$t} SET is_active=0" );
    $b = $wpdb->query( $wpdb->prepare( "UPDATE {$t} SET is_active=1 WHERE profile_id=%d", (int) $profile_id ) );
    if ( $a === false || $b === false ) { $wpdb->query( 'ROLLBACK' ); return array( 'success' => false, 'message' => 'Could not activate the profile.' ); }
    $wpdb->query( 'COMMIT' );
    ridego_audit_log( 'matching_profile_activated', 'matching', (int) $profile_id, null, array( 'version' => $p['version'] ), 'warning' );
    return array( 'success' => true, 'message' => 'Profile "' . $p['name'] . '" (v' . $p['version'] . ') is now active.' );
}

// TRACE: pure scorer → factor values (each 0..1) and weights → array( score 0..100, breakdown factor=>points ).
//        Missing factor counts 0. Deterministic for identical inputs (back-testable). Weights are used as given.
function ridego_matching_score_candidate( $factors, $weights ) {
    $total = 0.0; $bd = array();
    foreach ( $weights as $f => $w ) {
        $v = isset( $factors[ $f ] ) ? max( 0.0, min( 1.0, (float) $factors[ $f ] ) ) : 0.0;
        $bd[ $f ] = round( $v * $w * 100, 2 );
        $total += $v * $w;
    }
    return array( 'score' => round( $total * 100, 2 ), 'breakdown' => $bd );
}

// TRACE: vendor id + booking → 0..1 route fit from the vendor's operating cities and active branches: both booking
//        cities 1.0, pickup only 0.7, drop only 0.4, neither 0.1; a branch in the pickup city counts as pickup match;
//        no cities recorded → neutral 0.5. Edge cases: malformed JSON (neutral).
function ridego_matching_route_fit( $vendor, $booking ) {
    $cities = array();
    $raw = json_decode( (string) $vendor->operating_cities, true );
    if ( is_array( $raw ) ) { foreach ( $raw as $c ) { $cities[] = strtolower( trim( (string) $c ) ); } }
    if ( ! empty( $vendor->city ) ) { $cities[] = strtolower( trim( (string) $vendor->city ) ); }
    foreach ( ridego_get_vendor_branches( (int) $vendor->id ) as $br ) { if ( $br->status === 'active' && ! empty( $br->city_name ) ) { $cities[] = strtolower( trim( $br->city_name ) ); } }
    $cities = array_filter( array_unique( $cities ) );
    if ( ! $cities ) { return 0.5; }
    $p = in_array( strtolower( trim( (string) $booking->pickup_city ) ), $cities, true );
    $d = in_array( strtolower( trim( (string) $booking->drop_city ) ), $cities, true );
    return $p && $d ? 1.0 : ( $p ? 0.7 : ( $d ? 0.4 : 0.1 ) );
}

// TRACE: vendor id + booking → picks the best available driver+vehicle pair for a fleet vendor from
//        ridego_fleet_selection_options() (availability for the booking window already applied; branches in the pickup
//        city preferred): vehicles must be available, drivers must be available; vehicle score = type match (1 vs 0.4) x seats
//        fit (1 vs 0.3) + 0.05 branch bonus; driver score = rating/5 (0.5 when unrated) + 0.05 branch bonus →
//        array( driver_id, vehicle_id, driver_factor, vehicle_factor ) or null when either side has no available candidate.
//        Read-only. Edge cases: no drivers/vehicles, all unavailable (null), tie (lowest id).
function ridego_matching_pick_fleet_combo( $vendor_id, $booking ) {
    $opt = ridego_fleet_selection_options( (int) $vendor_id, $booking );
    $bestv = null; $bestd = null;
    foreach ( $opt['vehicles'] as $v ) {
        if ( empty( $v['available'] ) ) { continue; }
        $suit = ( ( (int) $booking->vehicle_type_id > 0 && (int) $v['vehicle_type_id'] > 0 && (int) $v['vehicle_type_id'] !== (int) $booking->vehicle_type_id ) ? 0.4 : 1.0 )
              * ( ( (int) $booking->passengers > 0 && (int) $v['seating_capacity'] > 0 && (int) $v['seating_capacity'] < (int) $booking->passengers ) ? 0.3 : 1.0 );
        $suit = min( 1.0, $suit + ( ! empty( $v['preferred'] ) ? 0.05 : 0.0 ) );
        if ( $bestv === null || $suit > $bestv['f'] ) { $bestv = array( 'id' => (int) $v['id'], 'f' => $suit ); }
    }
    foreach ( $opt['drivers'] as $d ) {
        if ( empty( $d['available'] ) ) { continue; }
        $f = ( (float) $d['rating'] > 0 ? (float) $d['rating'] / 5 : 0.5 );
        $f = min( 1.0, $f + ( ! empty( $d['preferred'] ) ? 0.05 : 0.0 ) );
        if ( $bestd === null || $f > $bestd['f'] ) { $bestd = array( 'id' => (int) $d['id'], 'f' => $f ); }
    }
    if ( ! $bestv || ! $bestd ) { return null; }
    return array( 'driver_id' => $bestd['id'], 'vehicle_id' => $bestv['id'], 'driver_factor' => $bestd['f'], 'vehicle_factor' => $bestv['f'] );
}

// TRACE: vendor + booking + optional lead row → derives the six factor values (0..1) from stored history: vendor rating
//        (neutral 0.5 when never rated), response time (this lead's own response, else the vendor's 90-day average, scored
//        against the response window; neutral 0.5 with no data), completion rate (completed vs cancellations/no-shows from
//        service events; neutral 0.5 with no data), route fit, and driver/vehicle factors from the lead's confirmed
//        driver/vehicle (or, for a fleet vendor who has not confirmed, the best available combo; for an individual vendor
//        their single provisioned pair) → array factor=>0..1 plus 'driver_id'/'vehicle_id' keys under '_combo' is NOT
//        included (see ridego_score_candidates). Read-only. Edge cases: vendor missing (all zero), no fleet rows (0.5/0).
function ridego_matching_candidate_factors( $vendor_id, $booking, $lead = null ) {
    global $wpdb;
    $vendor = ridego_get_vendor( (int) $vendor_id );
    if ( ! $vendor ) { return array_fill_keys( ridego_matching_factors(), 0.0 ); }
    $ev = $wpdb->prefix . 'ridego_service_events';
    $window = max( 60, ridego_lead_window_minutes() * 60 );
    $resp = null;
    if ( $lead && ! empty( $lead['interested_at'] ) && ! empty( $lead['sent_at'] ) ) { $resp = max( 0, strtotime( $lead['interested_at'] ) - strtotime( $lead['sent_at'] ) ); }
    if ( $resp === null ) {
        $avg = $wpdb->get_var( $wpdb->prepare( "SELECT AVG(event_value) FROM {$ev} WHERE entity_type='vendor' AND entity_id=%d AND event_type='response_recorded' AND recorded_at>=%s", (int) $vendor_id, date( 'Y-m-d H:i:s', strtotime( '-90 days', strtotime( current_time( 'mysql' ) ) ) ) ) );
        $resp = $avg === null ? null : (float) $avg;
    }
    $done = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT booking_id) FROM {$ev} WHERE entity_type='vendor' AND entity_id=%d AND event_type IN ('on_time_completion','late_arrival')", (int) $vendor_id ) );
    $bad  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT booking_id) FROM {$ev} WHERE entity_type='vendor' AND entity_id=%d AND event_type IN ('cancellation','no_show')", (int) $vendor_id ) );
    $f = array(
        'vendor_rating'   => (int) $vendor->total_ratings > 0 ? min( 1.0, (float) $vendor->rating / 5 ) : 0.5,
        'response_time'   => $resp === null ? 0.5 : max( 0.0, 1 - min( (float) $resp, $window ) / $window ),
        'completion_rate' => ( $done + $bad ) > 0 ? $done / ( $done + $bad ) : 0.5,
        'route_fit'       => ridego_matching_route_fit( $vendor, $booking ),
        'driver_rating'   => 0.5,
        'vehicle_suitability' => 0.0,
    );
    $drv = $lead && ! empty( $lead['driver_id'] ) ? ridego_get_fleet_driver( (int) $lead['driver_id'] ) : null;
    $veh = $lead && ! empty( $lead['vehicle_id'] ) ? ridego_get_fleet_vehicle( (int) $lead['vehicle_id'] ) : null;
    if ( $drv || $veh ) {
        if ( $drv ) { $f['driver_rating'] = (float) $drv->rating > 0 ? min( 1.0, (float) $drv->rating / 5 ) : 0.5; }
        if ( $veh ) {
            $f['vehicle_suitability'] = ( ( (int) $booking->vehicle_type_id > 0 && (int) $veh->vehicle_type_id > 0 && (int) $veh->vehicle_type_id !== (int) $booking->vehicle_type_id ) ? 0.4 : 1.0 )
                * ( ( (int) $booking->passengers > 0 && (int) $veh->seating_capacity > 0 && (int) $veh->seating_capacity < (int) $booking->passengers ) ? 0.3 : 1.0 );
        }
    } else {
        $combo = ridego_matching_pick_fleet_combo( (int) $vendor_id, $booking );
        if ( $combo ) { $f['driver_rating'] = $combo['driver_factor']; $f['vehicle_suitability'] = $combo['vehicle_factor']; }
    }
    return $f;
}

// TRACE: booking id (+ optional weight profile id, default the active one) → scores every selectable responding vendor →
//        array of array( vendor_id, lead_id, vendor_name, vendor_type, score, breakdown, driver_id, vehicle_id ) sorted by
//        score descending (ties: earlier response first). PURE: reads only, writes nothing, ignores every flag, so a profile can
//        be evaluated before it is ever active. For a fleet vendor that has not confirmed a driver the best available combo's
//        ids are returned as the suggestion. Edge cases: unknown booking/profile (empty), no selectable candidates (empty).
function ridego_score_candidates( $booking_id, $weight_profile_id = null ) {
    $booking = ridego_get_booking( (int) $booking_id );
    if ( ! $booking ) { return array(); }
    $profile = $weight_profile_id === null ? ridego_matching_get_active_profile() : ridego_matching_get_profile( (int) $weight_profile_id );
    if ( ! $profile ) { return array(); }
    $out = array();
    foreach ( ridego_get_lead_comparison( (int) $booking_id ) as $c ) {
        if ( ! $c['can_select'] ) { continue; }
        $lead = array( 'driver_id' => $c['driver_id'] ?? null, 'vehicle_id' => $c['vehicle_id'] ?? null, 'sent_at' => $c['sent_at'], 'interested_at' => $c['interested_at'] );
        $factors = ridego_matching_candidate_factors( $c['vendor_id'], $booking, $lead );
        $s = ridego_matching_score_candidate( $factors, $profile['weights'] );
        $did = $lead['driver_id']; $vid = $lead['vehicle_id'];
        if ( ! $did && ! $vid && $c['interest_status'] === 'interested' ) {
            $combo = ridego_matching_pick_fleet_combo( $c['vendor_id'], $booking );
            if ( $combo ) { $did = $combo['driver_id']; $vid = $combo['vehicle_id']; }
        }
        $out[] = array( 'vendor_id' => $c['vendor_id'], 'lead_id' => $c['lead_id'], 'vendor_name' => $c['vendor_name'], 'vendor_type' => $c['vendor_type'],
            'interest_status' => $c['interest_status'], 'score' => $s['score'], 'breakdown' => $s['breakdown'], 'driver_id' => $did ? (int) $did : null, 'vehicle_id' => $vid ? (int) $vid : null,
            'interested_at' => $c['interested_at'] );
    }
    usort( $out, function ( $a, $b ) {
        if ( $a['score'] !== $b['score'] ) { return $b['score'] <=> $a['score']; }
        return strcmp( (string) $a['interested_at'], (string) $b['interested_at'] );
    } );
    return $out;
}

// TRACE: booking (+ optional profile) → thin wrapper kept for existing callers → same result as ridego_score_candidates().
function ridego_matching_rank_booking( $booking_id, $profile = null ) {
    return ridego_score_candidates( $booking_id, is_array( $profile ) && isset( $profile['id'] ) ? (int) $profile['id'] : null );
}

// TRACE: booking → when performance_based_matching is ON scores the responders and stores/refreshes ONE open recommendation
//        (top vendor, suggested driver/vehicle, full factor breakdown, profile id) → recommendation row id | false.
//        Flag OFF → returns false and writes nothing. Edge cases: no candidates (false, stale open recommendation removed).
function ridego_matching_recommend( $booking_id ) {
    global $wpdb;
    if ( ! ridego_matching_flag( 'performance_based_matching' ) ) { return false; }
    $t = $wpdb->prefix . 'ridego_matching_recommendations';
    $wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE booking_id=%d AND was_followed IS NULL", (int) $booking_id ) );
    $profile = ridego_matching_get_active_profile();
    $ranked = ridego_score_candidates( $booking_id, $profile['id'] > 0 ? $profile['id'] : null );
    if ( ! $ranked ) { return false; }
    $top = $ranked[0];
    $ok = $wpdb->insert( $t, array( 'booking_id' => (int) $booking_id, 'recommended_vendor_id' => (int) $top['vendor_id'], 'recommended_driver_id' => $top['driver_id'], 'recommended_vehicle_id' => $top['vehicle_id'],
        'score' => $top['score'], 'factor_breakdown' => wp_json_encode( array( 'breakdown' => $top['breakdown'], 'ranking' => array_map( function ( $r ) { return array( 'vendor_id' => $r['vendor_id'], 'score' => $r['score'] ); }, $ranked ) ) ),
        'weight_profile_id' => (int) $profile['id'], 'created_at' => current_time( 'mysql' ) ) );
    return $ok ? (int) $wpdb->insert_id : false;
}

// TRACE: booking → the open (not yet acted on) recommendation row with decoded breakdown → array|null. Read-only.
function ridego_matching_get_recommendation( $booking_id ) {
    global $wpdb;
    $r = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_matching_recommendations WHERE booking_id=%d ORDER BY id DESC LIMIT 1", (int) $booking_id ), ARRAY_A );
    if ( ! $r ) { return null; }
    $r['factor_breakdown'] = json_decode( (string) $r['factor_breakdown'], true );
    return $r;
}

// TRACE: hook ridego_admin_assigned_vendor (admin click or automatic) → marks the booking's open recommendation as followed
//        (admin picked the recommended vendor) or overridden (with the reason) → void. Runs whenever a recommendation exists
//        (recommend-only mode included); no recommendation → nothing.
function ridego_matching_record_outcome( $booking_id, $vendor_id, $admin_id, $reason ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_matching_recommendations';
    $rec = $wpdb->get_row( $wpdb->prepare( "SELECT id, recommended_vendor_id FROM {$t} WHERE booking_id=%d AND was_followed IS NULL ORDER BY id DESC LIMIT 1", (int) $booking_id ) );
    if ( ! $rec ) { return; }
    $followed = (int) $rec->recommended_vendor_id === (int) $vendor_id ? 1 : 0;
    $wpdb->update( $t, array( 'was_followed' => $followed, 'override_reason' => $followed ? '' : substr( sanitize_text_field( (string) $reason ), 0, 255 ) ), array( 'id' => (int) $rec->id ) );
}
add_action( 'ridego_admin_assigned_vendor', 'ridego_matching_record_outcome', 10, 4 );

// TRACE: hooks ridego_lead_interest_shown / ridego_lead_driver_confirmed → reacts to a vendor response, each step behind
//        its own flag: (1) automatic_driver_selection: an interested fleet vendor with no driver yet gets the best
//        available combo confirmed for them; (2) performance_based_matching: refresh the recommendation; (3) once every
//        open lead has responded, automatic_vendor_assignment may assign → void. All flags OFF → returns immediately,
//        nothing read or written.
function ridego_matching_on_lead_activity( $lead_id, $booking_id, $vendor_id, $interest_status = '' ) {
    global $wpdb;
    if ( ! ridego_matching_flag( 'automatic_driver_selection' ) && ! ridego_matching_flag( 'performance_based_matching' ) && ! ridego_matching_flag( 'automatic_vendor_assignment' ) ) { return; }
    static $busy = false;
    if ( $busy ) { return; }
    $busy = true;
    try {
        if ( ridego_matching_flag( 'automatic_driver_selection' ) ) {
            $lead = $wpdb->get_row( $wpdb->prepare( "SELECT interest_status, driver_id FROM {$wpdb->prefix}ridego_leads WHERE id=%d", (int) $lead_id ) );
            $booking = ridego_get_booking( (int) $booking_id );
            if ( $lead && $booking && $lead->interest_status === 'interested' && ! $lead->driver_id ) {
                $combo = ridego_matching_pick_fleet_combo( (int) $vendor_id, $booking );
                if ( $combo ) { ridego_lead_confirm_driver( (int) $lead_id, (int) $vendor_id, array( 'driver_id' => $combo['driver_id'], 'vehicle_id' => $combo['vehicle_id'] ) ); }
            }
        }
        ridego_matching_recommend( (int) $booking_id );
        $open = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_leads WHERE booking_id=%d AND status='sent' AND interest_status IN ('sent','viewed')", (int) $booking_id ) );
        if ( $open === 0 ) { ridego_maybe_auto_assign( (int) $booking_id ); }
    } finally {
        $busy = false;
    }
}
add_action( 'ridego_lead_interest_shown', 'ridego_matching_on_lead_activity', 20, 4 );
add_action( 'ridego_lead_driver_confirmed', 'ridego_matching_on_lead_activity', 20, 3 );

// TRACE: booking → automatic_vendor_assignment ON and the top recommendation has a confirmed (or auto-selected) driver/vehicle
//        and a score >= matching_auto_assign_min_score (default 70) → assigns through the same transactional admin function with
//        the source recorded as the reason → array|false. Flag OFF → false, no side effects. Edge cases: booking already
//        assigned/closed, no candidates, below threshold, top candidate not selectable.
function ridego_maybe_auto_assign( $booking_id ) {
    if ( ! ridego_matching_flag( 'automatic_vendor_assignment' ) ) { return false; }
    $b = ridego_get_booking( (int) $booking_id );
    if ( ! $b || $b->vendor_id || in_array( $b->status, array( 'cancelled', 'completed' ), true ) ) { return false; }
    // Passenger & Safety Information: a female-only or child-inclusive
    // booking is never fully automatic — it always waits for an admin to
    // pick the vendor from the comparison screen (where the flag and the
    // passenger breakdown are shown), same as this function already
    // requires for a below-threshold score. ridego_matching_recommend()
    // still runs so the recommendation/ranking is ready for that admin.
    if ( function_exists( 'ridego_booking_is_safety_sensitive' ) && ridego_booking_is_safety_sensitive( $b ) ) {
        ridego_matching_recommend( (int) $booking_id );
        return false;
    }
    ridego_matching_recommend( (int) $booking_id );
    $ranked = ridego_score_candidates( (int) $booking_id );
    $min = (float) ridego_get_setting( 'matching_auto_assign_min_score', 70 );
    if ( ! $ranked || $ranked[0]['score'] < $min ) { return false; }
    $top = $ranked[0];
    return ridego_admin_assign_vendor( (int) $booking_id, (int) $top['vendor_id'], 0, 'Auto-assigned by matching engine (score ' . $top['score'] . ')', (int) $top['lead_id'] );
}

// TRACE: reopen path → automatic_reassignment ON: among the vendors who previously responded on this booking (not the one that
//        dropped out) whose confirmed driver/vehicle is still available, assigns the best-scoring one → array( success,
//        message ) | false when the flag is OFF or nobody qualifies (the caller then falls back to re-sending leads).
//        Edge cases: no previous responders, all unavailable, assignment race lost (false).
function ridego_matching_auto_reassign( $booking_id, $old_vendor_id ) {
    global $wpdb;
    if ( ! ridego_matching_flag( 'automatic_reassignment' ) ) { return false; }
    $b = ridego_get_booking( (int) $booking_id );
    if ( ! $b || $b->vendor_id ) { return false; }
    // Passenger & Safety Information: same manual-review requirement as
    // ridego_maybe_auto_assign() above — a flagged booking is never
    // reassigned automatically either.
    if ( function_exists( 'ridego_booking_is_safety_sensitive' ) && ridego_booking_is_safety_sensitive( $b ) ) { return false; }
    $t = $wpdb->prefix . 'ridego_leads';
    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE booking_id=%d AND vendor_id<>%d AND interest_status IN ('not_selected','driver_confirmed','interested') AND driver_confirmed_at IS NOT NULL ORDER BY id ASC", (int) $booking_id, (int) $old_vendor_id ), ARRAY_A );
    $profile = ridego_matching_get_active_profile();
    $best = null;
    foreach ( (array) $rows as $l ) {
        $v = ridego_get_vendor( (int) $l['vendor_id'] );
        if ( ! $v || $v->status !== 'active' ) { continue; }
        $time = ! empty( $b->journey_time ) ? $b->journey_time : '00:00'; $dur = ridego_booking_duration_minutes( $b );
        $ok = true;
        foreach ( array( 'driver' => $l['driver_id'], 'vehicle' => $l['vehicle_id'] ) as $kind => $id ) {
            if ( $id ) { $av = ridego_check_fleet_availability( $kind, (int) $id, $b->journey_date, $time, $dur, (int) $b->id ); if ( ! $av['available'] ) { $ok = false; } }
        }
        if ( ! $ok ) { continue; }
        $s = ridego_matching_score_candidate( ridego_matching_candidate_factors( (int) $l['vendor_id'], $b, $l ), $profile['weights'] );
        if ( $best === null || $s['score'] > $best['score'] ) { $best = array( 'score' => $s['score'], 'lead' => $l ); }
    }
    if ( ! $best ) { return false; }
    $r = ridego_admin_assign_vendor( (int) $booking_id, (int) $best['lead']['vendor_id'], 0, 'Automatic reassignment after vendor dropped out (score ' . $best['score'] . ')', (int) $best['lead']['id'] );
    return ! empty( $r['success'] ) ? $r : false;
}

// TRACE: back-test → for every COMPLETED booking that had two or more responding vendors, re-scores those vendors with the
//        given weights (using today's stored history) and reports how often the top pick equals the vendor actually used, and how
//        the actually used vendor performed (no no_show/late_arrival/complaint event and no rating below 4 for that booking)
//        → array( samples, agreement_pct, agreed_good_pct, disagreements, disagreements_actual_bad_pct ). Read-only; writes
//        nothing and ignores all flags. Edge cases: no qualifying bookings (samples 0), missing vendor rows (candidate skipped).
function ridego_matching_backtest( $weights, $limit = 500 ) {
    global $wpdb;
    $bt = $wpdb->prefix . 'ridego_bookings'; $lt = $wpdb->prefix . 'ridego_leads'; $ev = $wpdb->prefix . 'ridego_service_events'; $rt = $wpdb->prefix . 'ridego_ratings';
    $ids = $wpdb->get_col( $wpdb->prepare( "SELECT b.id FROM {$bt} b WHERE b.status='completed' AND b.vendor_id IS NOT NULL ORDER BY b.id DESC LIMIT %d", (int) $limit ) );
    $n = 0; $agree = 0; $agree_good = 0; $dis = 0; $dis_bad = 0;
    foreach ( (array) $ids as $bid ) {
        $b = ridego_get_booking( (int) $bid );
        if ( ! $b ) { continue; }
        $leads = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$lt} WHERE booking_id=%d AND (interested_at IS NOT NULL OR driver_confirmed_at IS NOT NULL)", (int) $bid ), ARRAY_A );
        $best = null; $bs = -1.0; $cand = 0;
        foreach ( (array) $leads as $l ) {
            if ( ! ridego_get_vendor( (int) $l['vendor_id'] ) ) { continue; }
            $cand++;
            $s = ridego_matching_score_candidate( ridego_matching_candidate_factors( (int) $l['vendor_id'], $b, $l ), $weights );
            if ( $s['score'] > $bs ) { $bs = $s['score']; $best = (int) $l['vendor_id']; }
        }
        if ( $cand < 2 || $best === null ) { continue; }
        $bad_events = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$ev} WHERE booking_id=%d AND event_type IN ('no_show','late_arrival','complaint_filed')", (int) $bid ) );
        $low = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$rt} WHERE booking_id=%d AND rated_type='vendor' AND rating_category='overall' AND score<4", (int) $bid ) );
        $good = ( $bad_events === 0 && $low === 0 );
        $n++;
        if ( $best === (int) $b->vendor_id ) { $agree++; if ( $good ) { $agree_good++; } } else { $dis++; if ( ! $good ) { $dis_bad++; } }
    }
    return array( 'samples' => $n, 'agreement_pct' => $n ? round( $agree * 100 / $n, 1 ) : 0.0, 'agreed_good_pct' => $agree ? round( $agree_good * 100 / $agree, 1 ) : 0.0,
        'disagreements' => $dis, 'disagreements_actual_bad_pct' => $dis ? round( $dis_bad * 100 / $dis, 1 ) : 0.0 );
}
