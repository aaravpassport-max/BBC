<?php
/**
 * RideGo Marketplace — commission models and calculation (Phase 4).
 * No model is seeded: commission is 0 until an admin creates a model and
 * marks it default or assigns it to a vendor.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: any caller needing the model types → returns the fixed list → array of type => label.
//        Preconditions: none. Postconditions: pure. Edge cases: none.
function ridego_commission_types() {
    return array(
        'fixed'               => 'Fixed amount per successful booking',
        'percentage'          => 'Percentage of fare (with minimum)',
        'subscription_hybrid' => 'Monthly subscription plan plus a reduced per-booking fee',
    );
}

// TRACE: model create/update → returns allowed refund adjustment values → array of strings.
//        Preconditions: none. Postconditions: pure. Edge cases: none.
function ridego_commission_refund_modes() {
    return array( 'none', 'reverse' );
}

// TRACE: raw input array → validates and normalises → array( 'ok'=>bool, 'data'=>array, 'error'=>string ).
//        Preconditions: none. Postconditions: data holds only known columns with clamped values.
//        Edge cases: empty name, unknown type, negative amounts, percentage >100, unknown refund mode.
function ridego_validate_commission_model_input( $in ) {
    $name = sanitize_text_field( isset( $in['name'] ) ? $in['name'] : '' );
    $type = isset( $in['type'] ) ? sanitize_key( $in['type'] ) : '';
    if ( $name === '' ) { return array( 'ok' => false, 'error' => 'Model name is required.' ); }
    if ( ! isset( ridego_commission_types()[ $type ] ) ) { return array( 'ok' => false, 'error' => 'Unknown commission type.' ); }
    $fixed = isset( $in['fixed_amount'] ) ? (float) $in['fixed_amount'] : 0;
    $pct   = isset( $in['percentage'] ) ? (float) $in['percentage'] : 0;
    $min   = isset( $in['min_amount'] ) ? (float) $in['min_amount'] : 0;
    $month = isset( $in['monthly_fee'] ) ? (float) $in['monthly_fee'] : 0;
    if ( $fixed < 0 || $pct < 0 || $min < 0 || $month < 0 ) { return array( 'ok' => false, 'error' => 'Amounts cannot be negative.' ); }
    if ( $pct > 100 ) { return array( 'ok' => false, 'error' => 'Percentage cannot exceed 100.' ); }
    $refund = isset( $in['refund_adjustment'] ) ? sanitize_key( $in['refund_adjustment'] ) : 'none';
    if ( ! in_array( $refund, ridego_commission_refund_modes(), true ) ) { return array( 'ok' => false, 'error' => 'Unknown refund adjustment.' ); }
    $plan_id = 0;
    if ( $type === 'fixed' && $fixed <= 0 ) { return array( 'ok' => false, 'error' => 'Fixed amount must be greater than zero.' ); }
    if ( $type === 'percentage' && $pct <= 0 ) { return array( 'ok' => false, 'error' => 'Percentage must be greater than zero.' ); }
    if ( $type === 'subscription_hybrid' ) {
        if ( $fixed <= 0 && $pct <= 0 ) { return array( 'ok' => false, 'error' => 'Set a fixed amount and/or a percentage for the reduced per-booking fee.' ); }
        $plan_id = isset( $in['subscription_plan_id'] ) ? (int) $in['subscription_plan_id'] : 0;
        $plan = $plan_id > 0 && function_exists( 'ridego_get_subscription_plan' ) ? ridego_get_subscription_plan( $plan_id ) : null;
        if ( ! $plan || (int) $plan->is_active !== 1 ) { return array( 'ok' => false, 'error' => 'Choose an active subscription plan for the monthly fee.' ); }
        $month = (float) $plan->price; // the monthly fee always mirrors the plan it is billed through
    } else {
        $month = 0.0;
    }
    return array( 'ok' => true, 'error' => '', 'data' => array(
        'name' => $name, 'type' => $type, 'fixed_amount' => $fixed, 'percentage' => $pct,
        'min_amount' => $min, 'monthly_fee' => $month, 'subscription_plan_id' => $plan_id > 0 ? $plan_id : null, 'refund_adjustment' => $refund,
        'is_active' => ! empty( $in['is_active'] ) || ! isset( $in['is_active'] ) ? 1 : 0,
    ) );
}

// TRACE: admin create → validates, inserts, optionally makes default (clears other defaults in a
//        transaction) → array( success, id|message ). Preconditions: capability checked by caller.
//        Postconditions: exactly one default row when is_default requested. Edge cases: invalid
//        input, insert failure (rolled back, error returned).
function ridego_create_commission_model( $in, $actor_id = 0 ) {
    global $wpdb;
    $v = ridego_validate_commission_model_input( $in );
    if ( ! $v['ok'] ) { return array( 'success' => false, 'message' => $v['error'] ); }
    $tbl = $wpdb->prefix . 'ridego_commission_models';
    $wpdb->query( 'START TRANSACTION' );
    $make_default = ! empty( $in['is_default'] );
    if ( $make_default ) { $wpdb->query( "UPDATE {$tbl} SET is_default=0" ); }
    $row = $v['data'];
    $row['is_default'] = $make_default ? 1 : 0;
    $ok = $wpdb->insert( $tbl, $row );
    if ( ! $ok ) { $wpdb->query( 'ROLLBACK' ); return array( 'success' => false, 'message' => 'Could not save the commission model.' ); }
    $id = (int) $wpdb->insert_id;
    $wpdb->query( 'COMMIT' );
    ridego_audit_log( 'commission_model_created', 'commission_model', $id, null, $row );
    return array( 'success' => true, 'id' => $id );
}

// TRACE: admin edit → validates, updates one model (default flag handled transactionally) →
//        array( success, message ). Edge cases: unknown id, invalid input, no-change update (still success).
//        Bookings already completed keep their snapshot (commission_model_id/commission_amount).
function ridego_update_commission_model( $id, $in, $actor_id = 0 ) {
    global $wpdb;
    $id  = (int) $id;
    $tbl = $wpdb->prefix . 'ridego_commission_models';
    $old = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id=%d", $id ), ARRAY_A );
    if ( ! $old ) { return array( 'success' => false, 'message' => 'Commission model not found.' ); }
    $v = ridego_validate_commission_model_input( $in );
    if ( ! $v['ok'] ) { return array( 'success' => false, 'message' => $v['error'] ); }
    $wpdb->query( 'START TRANSACTION' );
    $row = $v['data'];
    if ( isset( $in['is_default'] ) ) {
        if ( ! empty( $in['is_default'] ) ) { $wpdb->query( $wpdb->prepare( "UPDATE {$tbl} SET is_default=0 WHERE id<>%d", $id ) ); }
        $row['is_default'] = ! empty( $in['is_default'] ) ? 1 : 0;
    }
    $res = $wpdb->update( $tbl, $row, array( 'id' => $id ) );
    if ( $res === false ) { $wpdb->query( 'ROLLBACK' ); return array( 'success' => false, 'message' => 'Could not update the commission model.' ); }
    $wpdb->query( 'COMMIT' );
    ridego_audit_log( 'commission_model_updated', 'commission_model', $id, $old, $row );
    return array( 'success' => true, 'message' => 'Commission model updated.' );
}

// TRACE: admin list → reads all models with the count of vendors currently on each → array of rows.
//        Edge cases: no models (empty array).
function ridego_list_commission_models() {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_commission_models';
    $rows = $wpdb->get_results( "SELECT * FROM {$tbl} ORDER BY is_default DESC, id ASC", ARRAY_A );
    return $rows ? $rows : array();
}

// TRACE: admin assigns a model to a vendor → inserts an assignment row effective now (history is kept,
//        latest effective_from wins) → array( success, message ). Preconditions: vendor and model exist
//        and model is active. Postconditions: future completions use the model; past ones keep their
//        snapshot. For subscription_hybrid models the linked plan's subscription status is reported and, when $subscribe is
//        true, the vendor is subscribed through the existing ridego_subscribe_vendor() (wallet). Edge cases: unknown vendor,
//        unknown/inactive model, insert failure, subscription failure (assignment stays, message says why).
function ridego_assign_commission_model( $vendor_id, $model_id, $actor_id = 0, $subscribe = false ) {
    global $wpdb;
    $vendor_id = (int) $vendor_id; $model_id = (int) $model_id;
    $vt = $wpdb->prefix . 'ridego_vendors';
    $mt = $wpdb->prefix . 'ridego_commission_models';
    $at = $wpdb->prefix . 'ridego_vendor_commission_assignments';
    if ( ! $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$vt} WHERE id=%d", $vendor_id ) ) ) { return array( 'success' => false, 'message' => 'Vendor not found.' ); }
    if ( ! $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$mt} WHERE id=%d AND is_active=1", $model_id ) ) ) { return array( 'success' => false, 'message' => 'Commission model not found or inactive.' ); }
    $ok = $wpdb->insert( $at, array(
        'vendor_id' => $vendor_id, 'commission_model_id' => $model_id,
        'effective_from' => current_time( 'mysql' ), 'assigned_by' => (int) $actor_id,
    ) );
    if ( ! $ok ) { return array( 'success' => false, 'message' => 'Could not assign the commission model.' ); }
    ridego_audit_log( 'commission_model_assigned', 'vendor', $vendor_id, null, array( 'model_id' => $model_id ) );
    $msg = 'Commission model assigned.';
    $m = $wpdb->get_row( $wpdb->prepare( "SELECT type, subscription_plan_id FROM {$mt} WHERE id=%d", $model_id ) );
    if ( $m && $m->type === 'subscription_hybrid' && (int) $m->subscription_plan_id > 0 && function_exists( 'ridego_subscribe_vendor' ) ) {
        $plan_id = (int) $m->subscription_plan_id;
        $v = $wpdb->get_row( $wpdb->prepare( "SELECT subscription_plan_id, subscription_status, subscription_expires FROM {$vt} WHERE id=%d", $vendor_id ) );
        $active = $v && $v->subscription_status === 'active' && (int) $v->subscription_plan_id === $plan_id && ( empty( $v->subscription_expires ) || strtotime( $v->subscription_expires ) >= time() );
        if ( $active ) {
            $msg .= ' The vendor is already subscribed to the linked plan.';
        } elseif ( $subscribe ) {
            $r = ridego_subscribe_vendor( $vendor_id, $plan_id, 'wallet' );
            $msg .= ' Subscription: ' . ( is_array( $r ) && ! empty( $r['message'] ) ? $r['message'] : ( ! empty( $r['success'] ) ? 'started.' : 'could not be started.' ) );
        } else {
            $msg .= ' The vendor is not subscribed to the linked plan yet; the monthly fee is billed only through that subscription.';
        }
    }
    return array( 'success' => true, 'message' => $msg );
}

// TRACE: commission calculation → finds the vendor's latest assignment effective at $at (default now),
//        else the default active model, else null → returns model row array or null.
//        Edge cases: vendor with none and no default (null → 0 commission); assigned model inactive
//        (falls through to default).
function ridego_get_vendor_commission_model( $vendor_id, $at = null ) {
    global $wpdb;
    $mt = $wpdb->prefix . 'ridego_commission_models';
    $at_tbl = $wpdb->prefix . 'ridego_vendor_commission_assignments';
    $at = $at ? $at : current_time( 'mysql' );
    $m = $wpdb->get_row( $wpdb->prepare(
        "SELECT m.* FROM {$at_tbl} a JOIN {$mt} m ON m.id=a.commission_model_id
         WHERE a.vendor_id=%d AND a.effective_from<=%s AND m.is_active=1
         ORDER BY a.effective_from DESC, a.id DESC LIMIT 1", (int) $vendor_id, $at ), ARRAY_A );
    if ( $m ) { return $m; }
    $d = $wpdb->get_row( "SELECT * FROM {$mt} WHERE is_default=1 AND is_active=1 ORDER BY id ASC LIMIT 1", ARRAY_A );
    return $d ? $d : null;
}

// TRACE: model row + fare → pure computation → float commission rounded to 2dp.
//        fixed: max(fixed_amount, min_amount); percentage: max(min_amount, fare*pct/100); subscription_hybrid: the reduced
//        per-booking fee max(min_amount, fixed_amount + fare*pct/100) (the monthly fee is billed separately through the vendor's
//        subscription plan); legacy 'hybrid' rows keep their old formula; legacy 'monthly' rows charge nothing per booking. Result is capped at the fare. Edge cases: null model → 0,
//        fare<=0 → 0, cap at fare.
function ridego_calculate_commission( $model, $fare ) {
    $fare = (float) $fare;
    if ( ! $model || $fare <= 0 ) { return 0.0; }
    $fixed = (float) $model['fixed_amount']; $pct = (float) $model['percentage']; $min = (float) $model['min_amount'];
    switch ( $model['type'] ) {
        case 'fixed':               $c = max( $fixed, $min ); break;
        case 'percentage':          $c = max( $min, $fare * $pct / 100 ); break;
        case 'subscription_hybrid': $c = max( $min, $fixed + $fare * $pct / 100 ); break;
        case 'hybrid':              $c = $fixed + max( $min, $fare * $pct / 100 ); break; // rows created by an earlier build
        default:           $c = 0.0;
    }
    return round( min( $c, $fare ), 2 );
}
