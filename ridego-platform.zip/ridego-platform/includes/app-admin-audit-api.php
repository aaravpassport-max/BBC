<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Phase B, wave 27: audit log
   ------------------------------------------------------------
   Covers admin/pages/audit.php in full: the paginated, filterable
   (entity, action substring) audit log list — read-only, matching
   the legacy page exactly (it has no write actions at all).

   Query copied verbatim from admin/pages/audit.php:13-17, including
   the LEFT JOIN against wp_users for the admin's user_login. Schema
   confirmed directly against includes/install.php's CREATE TABLE for
   ridego_audit_log — every column referenced (admin_id, action,
   entity, entity_id, old_value, new_value, severity, ip_address,
   created_at) genuinely exists.

   Every route requires is_user_logged_in() AND
   ridego_can('ridego_view_audit_log') — the exact capability
   admin/pages/audit.php already requires.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_audit_api_routes' );
function ridego_register_app_admin_audit_api_routes() {
    register_rest_route( 'ridego/v1', '/app/admin/audit-log', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_audit_log_list',
        'permission_callback' => 'ridego_app_admin_api_audit_log_permission',
    ) );
}

function ridego_app_admin_api_audit_log_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_view_audit_log' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to view the audit log.', array( 'status' => 403 ) );
    }
    return true;
}

/** Copied verbatim from admin/pages/audit.php:10-17. */
function ridego_app_admin_api_audit_log_list( WP_REST_Request $req ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_audit_log';

    $ef   = sanitize_key( (string) $req->get_param( 'entity' ) );
    $af   = sanitize_text_field( (string) $req->get_param( 'action_filter' ) );
    $page = max( 1, (int) $req->get_param( 'page' ) );
    $per  = 40;
    $off  = ( $page - 1 ) * $per;

    $w = 'WHERE 1=1';
    $v = array();
    if ( $ef ) { $w .= ' AND entity=%s'; $v[] = $ef; }
    if ( $af ) { $w .= ' AND action LIKE %s'; $v[] = '%' . $wpdb->esc_like( $af ) . '%'; }

    $total = $v
        ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $tbl $w", $v ) )
        : (int) $wpdb->get_var( "SELECT COUNT(*) FROM $tbl $w" );

    $sql = "SELECT l.*,u.user_login FROM $tbl l LEFT JOIN {$wpdb->users} u ON u.ID=l.admin_id $w ORDER BY l.created_at DESC LIMIT %d OFFSET %d";
    $rows = $v
        ? $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $v, array( $per, $off ) ) ) )
        : $wpdb->get_results( $wpdb->prepare( $sql, $per, $off ) );

    return rest_ensure_response( array(
        'rows' => array_map( function ( $r ) {
            return array(
                'id'         => (int) $r->id,
                'admin_id'   => (int) $r->admin_id,
                'user_login' => $r->user_login ?: 'System',
                'action'     => $r->action,
                'entity'     => $r->entity,
                'entity_id'  => $r->entity_id,
                'old_value'  => $r->old_value,
                'new_value'  => $r->new_value,
                'severity'   => $r->severity,
                'ip_address' => $r->ip_address,
                'created_at' => $r->created_at,
            );
        }, $rows ),
        'total'    => $total,
        'page'     => $page,
        'per_page' => $per,
    ) );
}
