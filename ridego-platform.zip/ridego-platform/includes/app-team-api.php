<?php
/**
 * REST API for team access: team members, regions, tasks, the team dashboard, driver logins and the "view as" user search.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: rest_api_init → registers every team route with its permission callback → void.
function ridego_team_register_routes() {
    $r = array(
        array( '/app/admin/team', 'GET', 'ridego_team_api_list', 'ridego_team_perm_admin' ),
        array( '/app/admin/team', 'POST', 'ridego_team_api_create', 'ridego_team_perm_admin' ),
        array( '/app/admin/team/(?P<id>\d+)', 'PUT', 'ridego_team_api_update', 'ridego_team_perm_admin' ),
        array( '/app/admin/team/(?P<id>\d+)/reset-password', 'POST', 'ridego_team_api_reset', 'ridego_team_perm_admin' ),
        array( '/app/admin/regions', 'GET', 'ridego_team_api_regions', 'ridego_team_perm_admin' ),
        array( '/app/admin/regions', 'POST', 'ridego_team_api_region_save', 'ridego_team_perm_admin' ),
        array( '/app/admin/regions/(?P<id>\d+)', 'PUT', 'ridego_team_api_region_save', 'ridego_team_perm_admin' ),
        array( '/app/admin/regions/(?P<id>\d+)/delete', 'POST', 'ridego_team_api_region_delete', 'ridego_team_perm_admin' ),
        array( '/app/admin/users', 'GET', 'ridego_team_api_users', 'ridego_team_perm_view_as' ),
        array( '/app/admin/tasks', 'GET', 'ridego_team_api_tasks_admin', 'ridego_team_perm_tasks' ),
        array( '/app/admin/tasks', 'POST', 'ridego_team_api_task_create', 'ridego_team_perm_tasks' ),
        array( '/app/admin/tasks/(?P<id>\d+)', 'PUT', 'ridego_team_api_task_update', 'ridego_team_perm_tasks' ),
        array( '/app/team/dashboard', 'GET', 'ridego_team_api_dashboard', 'ridego_team_perm_member' ),
        array( '/app/team/tasks', 'GET', 'ridego_team_api_tasks_mine', 'ridego_team_perm_member' ),
        array( '/app/team/tasks/(?P<id>\d+)/status', 'POST', 'ridego_team_api_task_status', 'ridego_team_perm_member' ),
        array( '/app/vendor/drivers/(?P<id>\d+)/login', 'POST', 'ridego_driver_api_create_login', 'ridego_driver_perm_vendor' ),
        array( '/app/driver/me', 'GET', 'ridego_driver_api_me', 'ridego_driver_perm_self' ),
        array( '/app/driver/docs', 'POST', 'ridego_driver_api_upload', 'ridego_driver_perm_self' ),
        array( '/app/driver/docs/(?P<id>\d+)/file', 'GET', 'ridego_driver_api_doc_file', 'ridego_driver_perm_self' ),
        array( '/app/driver/trips/(?P<id>\d+)/en-route', 'POST', 'ridego_driver_api_trip_en_route', 'ridego_driver_perm_self' ),
        array( '/app/driver/trips/(?P<id>\d+)/arrived', 'POST', 'ridego_driver_api_trip_arrived', 'ridego_driver_perm_self' ),
        array( '/app/driver/trips/(?P<id>\d+)/start', 'POST', 'ridego_driver_api_trip_start', 'ridego_driver_perm_self' ),
        array( '/app/driver/trips/(?P<id>\d+)/no-show', 'POST', 'ridego_driver_api_trip_no_show', 'ridego_driver_perm_self' ),
        array( '/app/driver/trips/(?P<id>\d+)', 'GET', 'ridego_driver_api_trip_detail', 'ridego_driver_perm_self' ),
        array( '/app/driver/trips/history', 'GET', 'ridego_driver_api_trip_history', 'ridego_driver_perm_self' ),
        array( '/app/driver/earnings', 'GET', 'ridego_driver_api_earnings', 'ridego_driver_perm_self' ),
        array( '/app/vendor/drivers/(?P<id>\d+)/earnings', 'GET', 'ridego_vendor_api_driver_earnings_list', 'ridego_driver_perm_vendor' ),
        array( '/app/vendor/drivers/(?P<id>\d+)/earnings', 'POST', 'ridego_vendor_api_driver_earnings_create', 'ridego_driver_perm_vendor' ),
    );
    foreach ( $r as $x ) {
        register_rest_route( 'ridego/v1', $x[0], array( 'methods' => $x[1], 'callback' => $x[2], 'permission_callback' => $x[3] ) );
    }
}
add_action( 'rest_api_init', 'ridego_team_register_routes' );

// TRACE: permission callbacks → WP_Error 401/403 or true. Team management is administrator-only (manage_options).
function ridego_team_perm_admin() {
    if ( ! is_user_logged_in() ) { return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) ); }
    return current_user_can( 'manage_options' ) ? true : new WP_Error( 'forbidden', 'Only administrators can manage the team.', array( 'status' => 403 ) );
}
function ridego_team_perm_view_as() {
    if ( ! is_user_logged_in() ) { return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) ); }
    foreach ( array( 'vendor', 'client', 'regional_manager', 'staff', 'driver' ) as $r ) { if ( current_user_can( 'ridego_impersonate_' . $r ) ) { return true; } }
    return new WP_Error( 'forbidden', 'You cannot view as other users.', array( 'status' => 403 ) );
}
function ridego_team_perm_tasks() {
    if ( ! is_user_logged_in() ) { return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) ); }
    return ( current_user_can( 'ridego_manage_tasks' ) || current_user_can( 'manage_options' ) ) ? true : new WP_Error( 'forbidden', 'You do not have access to task management.', array( 'status' => 403 ) );
}
function ridego_team_perm_member() {
    if ( ! is_user_logged_in() ) { return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) ); }
    $u = wp_get_current_user();
    return array_intersect( array_keys( ridego_team_roles() ), (array) $u->roles ) ? true : new WP_Error( 'forbidden', 'This area is for team members.', array( 'status' => 403 ) );
}

// TRACE: user object → the JSON shape used by the team list → array. Pure aside from meta reads.
function ridego_team_user_view( $u ) {
    $role = in_array( 'ridego_regional_manager', (array) $u->roles, true ) ? 'ridego_regional_manager' : 'ridego_staff';
    return array(
        'id' => (int) $u->ID, 'name' => $u->display_name, 'email' => $u->user_email, 'phone' => (string) get_user_meta( $u->ID, 'ridego_phone', true ),
        'role' => $role, 'active' => ! get_user_meta( $u->ID, 'ridego_team_disabled', true ),
        'modules' => array_values( (array) get_user_meta( $u->ID, 'ridego_team_modules', true ) ),
        'region_ids' => ridego_user_region_ids( $u->ID ),
        'region_scope' => get_user_meta( $u->ID, 'ridego_region_scope', true ) === 'all' ? 'all' : 'assigned',
    );
}

// TRACE: GET team → lists staff and regional managers plus the module catalogue → { members, modules, regions }.
function ridego_team_api_list() {
    $users = get_users( array( 'role__in' => array_keys( ridego_team_roles() ), 'orderby' => 'display_name', 'number' => 500 ) );
    $mods = array(); foreach ( ridego_team_modules() as $k => $m ) { $mods[] = array( 'key' => $k, 'label' => $m[0], 'description' => $m[1] ); }
    return rest_ensure_response( array( 'members' => array_map( 'ridego_team_user_view', $users ), 'modules' => $mods, 'regions' => ridego_team_regions_rows() ) );
}

// TRACE: POST/PUT body → validated team-member fields or WP_Error → array.
//        Edge cases: bad role, bad email, weak password, unknown region ids dropped.
function ridego_team_validate_member( $req, $creating ) {
    global $wpdb;
    $role = sanitize_key( (string) $req->get_param( 'role' ) );
    if ( $creating && ! isset( ridego_team_roles()[ $role ] ) ) { return new WP_Error( 'invalid_input', 'Choose Staff or Regional Manager.', array( 'status' => 400 ) ); }
    $name = sanitize_text_field( (string) $req->get_param( 'name' ) );
    if ( $name === '' ) { return new WP_Error( 'invalid_input', 'Name is required.', array( 'status' => 400 ) ); }
    $email = sanitize_email( (string) $req->get_param( 'email' ) );
    if ( $creating && ! is_email( $email ) ) { return new WP_Error( 'invalid_input', 'Enter a valid email address.', array( 'status' => 400 ) ); }
    $pw = (string) $req->get_param( 'password' );
    if ( $creating && $pw !== '' && strlen( $pw ) < 10 ) { return new WP_Error( 'invalid_input', 'Password must be at least 10 characters.', array( 'status' => 400 ) ); }
    $rids = array_map( 'intval', (array) $req->get_param( 'region_ids' ) );
    if ( $rids ) {
        $ph = implode( ',', array_fill( 0, count( $rids ), '%d' ) );
        $rids = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}ridego_regions WHERE id IN ({$ph})", $rids ) ) );
    }
    return array( 'role' => $role, 'name' => $name, 'email' => $email, 'phone' => sanitize_text_field( (string) $req->get_param( 'phone' ) ), 'password' => $pw,
        'modules' => (array) $req->get_param( 'modules' ), 'region_ids' => $rids, 'scope' => $req->get_param( 'region_scope' ) === 'all' ? 'all' : 'assigned',
        'active' => $req->get_param( 'active' ) === false ? false : true );
}

// TRACE: sets modules/regions/scope/phone on a user → void. Preconditions: user exists and is a team member.
function ridego_team_save_member_meta( $uid, $d ) {
    ridego_team_apply_modules( $uid, $d['modules'] );
    update_user_meta( $uid, 'ridego_phone', $d['phone'] );
    update_user_meta( $uid, 'ridego_region_ids', $d['region_ids'] );
    update_user_meta( $uid, 'ridego_region_scope', $d['scope'] );
}

// TRACE: POST team → creates the WP user with the chosen role, modules, regions → 201 { member }.
//        Preconditions: administrator. Postconditions: user row + meta persisted; a generated password is never returned:
//        when none is supplied a password-set email is sent. Edge cases: duplicate email (409); wp_insert_user failure (400).
function ridego_team_api_create( WP_REST_Request $req ) {
    $d = ridego_team_validate_member( $req, true );
    if ( is_wp_error( $d ) ) { return $d; }
    if ( email_exists( $d['email'] ) ) { return new WP_Error( 'exists', 'A user with this email already exists.', array( 'status' => 409 ) ); }
    $login = sanitize_user( strstr( $d['email'], '@', true ), true );
    $login = $login !== '' ? $login : 'team';
    $base = $login; $i = 1; while ( username_exists( $login ) ) { $login = $base . ( ++$i ); }
    $uid = wp_insert_user( array( 'user_login' => $login, 'user_email' => $d['email'], 'display_name' => $d['name'], 'first_name' => $d['name'],
        'user_pass' => $d['password'] !== '' ? $d['password'] : wp_generate_password( 24 ), 'role' => $d['role'] ) );
    if ( is_wp_error( $uid ) ) { return new WP_Error( 'create_failed', $uid->get_error_message(), array( 'status' => 400 ) ); }
    ridego_team_save_member_meta( $uid, $d );
    if ( $d['password'] === '' ) { retrieve_password( $login ); }
    ridego_audit_log( 'team_member_created', 'user', $uid, '', array( 'role' => $d['role'], 'modules' => $d['modules'] ) );
    $res = rest_ensure_response( array( 'member' => ridego_team_user_view( get_userdata( $uid ) ) ) );
    $res->set_status( 201 );
    return $res;
}

// TRACE: PUT team/{id} → updates name, phone, modules, regions, scope and enabled state → { member }.
//        Edge cases: target not a team member (404); administrators can never be edited here; disabled flag blocks login.
function ridego_team_api_update( WP_REST_Request $req ) {
    $uid = (int) $req['id'];
    $u = get_userdata( $uid );
    if ( ! $u || ! array_intersect( array_keys( ridego_team_roles() ), (array) $u->roles ) || user_can( $uid, 'manage_options' ) ) { return new WP_Error( 'not_found', 'Team member not found.', array( 'status' => 404 ) ); }
    $d = ridego_team_validate_member( $req, false );
    if ( is_wp_error( $d ) ) { return $d; }
    $r = wp_update_user( array( 'ID' => $uid, 'display_name' => $d['name'], 'first_name' => $d['name'] ) );
    if ( is_wp_error( $r ) ) { return new WP_Error( 'update_failed', $r->get_error_message(), array( 'status' => 400 ) ); }
    ridego_team_save_member_meta( $uid, $d );
    if ( $d['active'] ) { delete_user_meta( $uid, 'ridego_team_disabled' ); } else { update_user_meta( $uid, 'ridego_team_disabled', 1 ); }
    ridego_audit_log( 'team_member_updated', 'user', $uid, '', array( 'modules' => $d['modules'], 'regions' => $d['region_ids'], 'active' => $d['active'] ) );
    return rest_ensure_response( array( 'member' => ridego_team_user_view( get_userdata( $uid ) ) ) );
}

// TRACE: disabled users cannot authenticate → wp_authenticate_user filter returns WP_Error for them. Edge: others untouched.
function ridego_team_block_disabled( $user ) {
    if ( $user instanceof WP_User && get_user_meta( $user->ID, 'ridego_team_disabled', true ) ) {
        return new WP_Error( 'account_disabled', 'This account has been disabled. Contact your administrator.' );
    }
    return $user;
}
add_filter( 'wp_authenticate_user', 'ridego_team_block_disabled', 30 );

// TRACE: POST team/{id}/reset-password → emails the user a WordPress password-reset link → { ok }. No password is ever shown.
function ridego_team_api_reset( WP_REST_Request $req ) {
    $u = get_userdata( (int) $req['id'] );
    if ( ! $u || ! array_intersect( array_keys( ridego_team_roles() ), (array) $u->roles ) ) { return new WP_Error( 'not_found', 'Team member not found.', array( 'status' => 404 ) ); }
    $r = retrieve_password( $u->user_login );
    if ( is_wp_error( $r ) ) { return new WP_Error( 'mail_failed', 'Could not send the reset email. Check the site email settings.', array( 'status' => 500 ) ); }
    ridego_audit_log( 'team_password_reset_sent', 'user', $u->ID );
    return rest_ensure_response( array( 'ok' => true ) );
}

/* ------------------------------------------------------------------ regions */

// TRACE: any → all regions with their resolved city list and assigned-user count → array.
function ridego_team_regions_rows() {
    global $wpdb;
    $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}ridego_regions ORDER BY name ASC" );
    $out = array();
    foreach ( (array) $rows as $r ) {
        $out[] = array( 'id' => (int) $r->id, 'name' => $r->name, 'region_type' => $r->region_type, 'states' => (array) json_decode( (string) $r->states, true ),
            'cities' => (array) json_decode( (string) $r->cities, true ), 'status' => $r->status, 'resolved_cities' => ridego_region_cities( $r ) );
    }
    return $out;
}

// TRACE: GET regions → { regions, states, cities } where states/cities feed the picker → array.
function ridego_team_api_regions() {
    global $wpdb;
    return rest_ensure_response( array( 'regions' => ridego_team_regions_rows(),
        'states' => array_values( array_filter( $wpdb->get_col( "SELECT DISTINCT state FROM {$wpdb->prefix}ridego_cities ORDER BY state" ) ) ),
        'cities' => $wpdb->get_results( "SELECT name, state FROM {$wpdb->prefix}ridego_cities ORDER BY name", ARRAY_A ) ) );
}

// TRACE: POST/PUT region → validates name/type/coverage and saves → { region }.
//        Edge cases: empty name, no states and no cities (400), duplicate name (409), $wpdb write failure (500).
function ridego_team_api_region_save( WP_REST_Request $req ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_regions';
    $id = (int) $req['id'];
    $name = sanitize_text_field( (string) $req->get_param( 'name' ) );
    if ( $name === '' ) { return new WP_Error( 'invalid_input', 'Region name is required.', array( 'status' => 400 ) ); }
    $type = sanitize_key( (string) $req->get_param( 'region_type' ) );
    if ( ! in_array( $type, array( 'state', 'city', 'group', 'custom' ), true ) ) { $type = 'custom'; }
    $states = array_values( array_filter( array_map( 'sanitize_text_field', (array) $req->get_param( 'states' ) ) ) );
    $cities = array_values( array_filter( array_map( 'sanitize_text_field', (array) $req->get_param( 'cities' ) ) ) );
    if ( ! $states && ! $cities ) { return new WP_Error( 'invalid_input', 'Choose at least one state or city.', array( 'status' => 400 ) ); }
    $status = $req->get_param( 'status' ) === 'inactive' ? 'inactive' : 'active';
    $dupe = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE name=%s AND id<>%d", $name, $id ) );
    if ( $dupe ) { return new WP_Error( 'exists', 'A region with this name already exists.', array( 'status' => 409 ) ); }
    $row = array( 'name' => $name, 'region_type' => $type, 'states' => wp_json_encode( $states ), 'cities' => wp_json_encode( $cities ), 'status' => $status );
    if ( $id ) { $ok = $wpdb->update( $t, $row, array( 'id' => $id ) ); } else { $ok = $wpdb->insert( $t, $row ); $id = (int) $wpdb->insert_id; }
    if ( $ok === false ) { return new WP_Error( 'save_failed', 'Could not save the region.', array( 'status' => 500 ) ); }
    ridego_audit_log( 'region_saved', 'region', $id, '', array( 'name' => $name ) );
    foreach ( ridego_team_regions_rows() as $r ) { if ( $r['id'] === $id ) { return rest_ensure_response( array( 'region' => $r ) ); } }
    return new WP_Error( 'save_failed', 'Region not found after saving.', array( 'status' => 500 ) );
}

// TRACE: POST regions/{id}/delete → deletes a region and unassigns it from every user → { ok }. Edge: unknown id (404).
function ridego_team_api_region_delete( WP_REST_Request $req ) {
    global $wpdb;
    $id = (int) $req['id'];
    $ok = $wpdb->delete( $wpdb->prefix . 'ridego_regions', array( 'id' => $id ) );
    if ( ! $ok ) { return new WP_Error( 'not_found', 'Region not found.', array( 'status' => 404 ) ); }
    foreach ( get_users( array( 'role' => 'ridego_regional_manager', 'fields' => 'ID' ) ) as $uid ) {
        $ids = ridego_user_region_ids( $uid );
        if ( in_array( $id, $ids, true ) ) { update_user_meta( $uid, 'ridego_region_ids', array_values( array_diff( $ids, array( $id ) ) ) ); }
    }
    ridego_audit_log( 'region_deleted', 'region', $id );
    return rest_ensure_response( array( 'ok' => true ) );
}

/* ------------------------------------------------------------------ view-as directory */

// TRACE: GET users?role=&q= → searchable directory of accounts the admin may view as (vendors with fleet/individual type,
//        drivers with logins, clients, regional managers, staff) → { users }. Never returns credentials.
//        Edge cases: role filter unknown → all; only roles the admin holds an impersonation cap for are listed; max 50.
function ridego_team_api_users( WP_REST_Request $req ) {
    global $wpdb;
    $map = array( 'vendor' => 'ridego_vendor', 'client' => 'ridego_client', 'regional_manager' => 'ridego_regional_manager', 'staff' => 'ridego_staff', 'driver' => 'ridego_driver' );
    $want = sanitize_key( (string) $req->get_param( 'role' ) );
    $roles = array();
    foreach ( $map as $key => $wp ) { if ( ( $want === '' || $want === $key ) && current_user_can( 'ridego_impersonate_' . $key ) ) { $roles[] = $wp; } }
    if ( ! $roles ) { return rest_ensure_response( array( 'users' => array() ) ); }
    $q = sanitize_text_field( (string) $req->get_param( 'q' ) );
    $args = array( 'role__in' => $roles, 'number' => 50, 'orderby' => 'display_name', 'fields' => 'all' );
    if ( $q !== '' ) { $args['search'] = '*' . $q . '*'; $args['search_columns'] = array( 'user_login', 'user_email', 'display_name' ); }
    $out = array();
    foreach ( get_users( $args ) as $u ) {
        $role = 'client'; foreach ( $map as $key => $wp ) { if ( in_array( $wp, (array) $u->roles, true ) ) { $role = $key; break; } }
        $label = $role;
        if ( $role === 'vendor' ) { $v = ridego_get_vendor_by_user( $u->ID ); $label = $v ? ( ridego_get_vendor_type( $v ) === 'fleet' ? 'fleet_vendor' : 'individual_vendor' ) : 'vendor'; }
        $out[] = array( 'id' => (int) $u->ID, 'name' => $u->display_name, 'email' => $u->user_email, 'role' => $role, 'label' => $label );
    }
    return rest_ensure_response( array( 'users' => $out ) );
}

/* ------------------------------------------------------------------ tasks */

// TRACE: task row → JSON view → array. Pure aside from a user lookup.
function ridego_team_task_view( $t ) {
    $a = $t->assigned_to ? get_userdata( (int) $t->assigned_to ) : null;
    return array( 'id' => (int) $t->id, 'title' => $t->title, 'description' => $t->description, 'assigned_to' => (int) $t->assigned_to, 'assigned_name' => $a ? $a->display_name : '',
        'status' => $t->status, 'priority' => $t->priority, 'due_date' => $t->due_date, 'booking_id' => $t->booking_id ? (int) $t->booking_id : null, 'created_at' => $t->created_at );
}

// TRACE: GET admin/tasks → all tasks, newest first, optional status filter → { tasks }.
function ridego_team_api_tasks_admin( WP_REST_Request $req ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_tasks';
    $status = sanitize_key( (string) $req->get_param( 'status' ) );
    $rows = $status ? $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE status=%s ORDER BY id DESC LIMIT 200", $status ) ) : $wpdb->get_results( "SELECT * FROM {$t} ORDER BY id DESC LIMIT 200" );
    return rest_ensure_response( array( 'tasks' => array_map( 'ridego_team_task_view', (array) $rows ) ) );
}

// TRACE: validated task fields from a request → array or WP_Error. Edge: no title, assignee not a team member, bad date.
function ridego_team_task_fields( $req ) {
    $title = sanitize_text_field( (string) $req->get_param( 'title' ) );
    if ( $title === '' ) { return new WP_Error( 'invalid_input', 'Task title is required.', array( 'status' => 400 ) ); }
    $to = (int) $req->get_param( 'assigned_to' );
    $u = $to ? get_userdata( $to ) : null;
    if ( ! $u || ! array_intersect( array_keys( ridego_team_roles() ), (array) $u->roles ) ) { return new WP_Error( 'invalid_input', 'Assign the task to a staff member or regional manager.', array( 'status' => 400 ) ); }
    $due = sanitize_text_field( (string) $req->get_param( 'due_date' ) );
    if ( $due !== '' && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $due ) ) { return new WP_Error( 'invalid_input', 'Due date must be a valid date.', array( 'status' => 400 ) ); }
    $pr = sanitize_key( (string) $req->get_param( 'priority' ) );
    return array( 'title' => $title, 'description' => sanitize_textarea_field( (string) $req->get_param( 'description' ) ), 'assigned_to' => $to,
        'priority' => in_array( $pr, array( 'low', 'normal', 'high' ), true ) ? $pr : 'normal', 'due_date' => $due !== '' ? $due : null,
        'booking_id' => (int) $req->get_param( 'booking_id' ) ?: null );
}

// TRACE: POST admin/tasks → creates a task and notifies nobody by email (visible on the assignee dashboard) → 201 { task }.
function ridego_team_api_task_create( WP_REST_Request $req ) {
    global $wpdb;
    $f = ridego_team_task_fields( $req );
    if ( is_wp_error( $f ) ) { return $f; }
    $f['status'] = 'open'; $f['created_by'] = get_current_user_id(); $f['created_at'] = current_time( 'mysql' );
    if ( ! $wpdb->insert( $wpdb->prefix . 'ridego_tasks', $f ) ) { return new WP_Error( 'save_failed', 'Could not save the task.', array( 'status' => 500 ) ); }
    $id = (int) $wpdb->insert_id;
    $res = rest_ensure_response( array( 'task' => ridego_team_task_view( $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_tasks WHERE id=%d", $id ) ) ) ) );
    $res->set_status( 201 );
    return $res;
}

// TRACE: PUT admin/tasks/{id} → edits fields and status → { task }. Edge: unknown id (404), bad status (400).
function ridego_team_api_task_update( WP_REST_Request $req ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_tasks';
    $id = (int) $req['id'];
    if ( ! $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t} WHERE id=%d", $id ) ) ) { return new WP_Error( 'not_found', 'Task not found.', array( 'status' => 404 ) ); }
    $f = ridego_team_task_fields( $req );
    if ( is_wp_error( $f ) ) { return $f; }
    $st = sanitize_key( (string) $req->get_param( 'status' ) );
    if ( $st !== '' ) {
        if ( ! in_array( $st, array( 'open', 'in_progress', 'done' ), true ) ) { return new WP_Error( 'invalid_input', 'Unknown status.', array( 'status' => 400 ) ); }
        $f['status'] = $st;
    }
    if ( $wpdb->update( $t, $f, array( 'id' => $id ) ) === false ) { return new WP_Error( 'save_failed', 'Could not save the task.', array( 'status' => 500 ) ); }
    return rest_ensure_response( array( 'task' => ridego_team_task_view( $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ) ) ) ) );
}

// TRACE: GET team/tasks → the signed-in member's own tasks → { tasks }.
function ridego_team_api_tasks_mine() {
    global $wpdb;
    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_tasks WHERE assigned_to=%d ORDER BY status='done', id DESC LIMIT 200", get_current_user_id() ) );
    return rest_ensure_response( array( 'tasks' => array_map( 'ridego_team_task_view', (array) $rows ) ) );
}

// TRACE: POST team/tasks/{id}/status { status } → the assignee (only) moves their own task → { task }.
//        Edge cases: task belongs to someone else (404, not revealed), bad status (400).
function ridego_team_api_task_status( WP_REST_Request $req ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_tasks';
    $st = sanitize_key( (string) $req->get_param( 'status' ) );
    if ( ! in_array( $st, array( 'open', 'in_progress', 'done' ), true ) ) { return new WP_Error( 'invalid_input', 'Unknown status.', array( 'status' => 400 ) ); }
    $id = (int) $req['id'];
    $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d AND assigned_to=%d", $id, get_current_user_id() ) );
    if ( ! $row ) { return new WP_Error( 'not_found', 'Task not found.', array( 'status' => 404 ) ); }
    if ( $wpdb->update( $t, array( 'status' => $st ), array( 'id' => $id ) ) === false ) { return new WP_Error( 'save_failed', 'Could not update the task.', array( 'status' => 500 ) ); }
    return rest_ensure_response( array( 'task' => ridego_team_task_view( $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", $id ) ) ) ) );
}

// TRACE: GET team/dashboard → role, modules, regions, own task counts and (for a regional manager) region-scoped booking
//        counts and the newest bookings needing attention → array. Edge cases: no region assigned → zero counts and a notice flag.
function ridego_team_api_dashboard() {
    global $wpdb;
    $uid = get_current_user_id();
    $u = wp_get_current_user();
    $btbl = $wpdb->prefix . 'ridego_bookings';
    $is_rm = in_array( 'ridego_regional_manager', (array) $u->roles, true );
    $mods = array_values( (array) get_user_meta( $uid, 'ridego_team_modules', true ) );
    $out = array( 'role' => $is_rm ? 'ridego_regional_manager' : 'ridego_staff', 'name' => $u->display_name, 'modules' => $mods, 'is_regional_manager' => $is_rm );
    $out['tasks'] = array( 'open' => 0, 'in_progress' => 0, 'done' => 0 );
    foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT status, COUNT(*) c FROM {$wpdb->prefix}ridego_tasks WHERE assigned_to=%d GROUP BY status", $uid ) ) as $r ) { $out['tasks'][ $r->status ] = (int) $r->c; }
    if ( $is_rm ) {
        $rs = ridego_region_sql( 'pickup_city' );
        $sc = ridego_region_scope_cities();
        $out['regions'] = array_map( function ( $r ) { return $r['name']; }, array_values( array_filter( ridego_team_regions_rows(), function ( $r ) use ( $uid ) { return in_array( $r['id'], ridego_user_region_ids( $uid ), true ); } ) ) );
        $out['region_scope'] = $sc === null ? 'all' : 'assigned';
        $out['no_region'] = ( $sc !== null && ! $sc );
    }
    /* Root-cause fix: these stat cards and the recent-bookings list used to be
       built ONLY inside the `if ($is_rm)` branch above, so a Staff member —
       who has the same "manage bookings" capability as a Regional Manager,
       just without a region assignment — opened their workspace to an empty
       space where the Regional Manager's dashboard shows five KPI cards and
       a recent-bookings list. Staff isn't region-scoped (TeamDashboardPage's
       `!user.region_limited` check already treats Staff as seeing all
       bookings), so the parity fix is the platform-wide equivalent of the
       exact same query set, gated on the bookings module the way the rest
       of Staff's dashboard already gates by module/capability — not a
       second, divergent implementation for the same numbers.
       Both roles now get the same shape of response; only the underlying
       SQL scope (region-filtered vs platform-wide) differs. */
    if ( $is_rm || in_array( 'bookings', $mods, true ) ) {
        $rs = $is_rm ? ridego_region_sql( 'pickup_city' ) : '';
        $out['counts'] = array(
            'total' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE 1=1{$rs}" ),
            'awaiting_payment' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE status IN ('pending_payment','payment_proof_submitted'){$rs}" ),
            'needs_vendor' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE vendor_id IS NULL AND status='confirmed'{$rs}" ),
            'active_trips' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE status IN ('vendor_assigned','driver_en_route','trip_started'){$rs}" ),
            'today' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$btbl} WHERE journey_date=%s{$rs}", current_time( 'Y-m-d' ) ) ),
        );
        $out['recent'] = array_map( function ( $b ) { return array( 'id' => (int) $b->id, 'booking_number' => $b->booking_number, 'pickup_city' => $b->pickup_city, 'drop_city' => $b->drop_city, 'journey_date' => $b->journey_date, 'status' => $b->status ); },
            (array) $wpdb->get_results( "SELECT id, booking_number, pickup_city, drop_city, journey_date, status FROM {$btbl} WHERE 1=1{$rs} ORDER BY id DESC LIMIT 8" ) );
    }
    return rest_ensure_response( $out );
}

/* ------------------------------------------------------------------ driver logins */

// TRACE: driver-scoped routes → vendor owner check → true|WP_Error.
function ridego_driver_perm_vendor() {
    if ( ! is_user_logged_in() ) { return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) ); }
    return ridego_get_vendor_by_user( get_current_user_id() ) ? true : new WP_Error( 'forbidden', 'Vendor access only.', array( 'status' => 403 ) );
}

// TRACE: signed-in driver check → true|WP_Error. A driver is a user with role ridego_driver linked to a fleet driver row.
// TRACE: any driver route → logged in AND has a linked, currently-active fleet_drivers row → true|WP_Error 401/403.
//        Postconditions: a driver whose row was set to inactive/suspended (by their vendor or by admin) is rejected
//        on every request from this point on, re-checked fresh per call rather than only at login — this is what
//        stops a suspended driver from continuing to accept rides on a still-live session/cookie.
function ridego_driver_perm_self() {
    if ( ! is_user_logged_in() ) { return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) ); }
    $d = ridego_driver_current();
    if ( ! $d ) { return new WP_Error( 'forbidden', 'This area is for drivers.', array( 'status' => 403 ) ); }
    if ( isset( $d->status ) && $d->status !== 'active' ) {
        return new WP_Error( 'account_suspended', 'Your driver account is not active. Contact your operator or support.', array( 'status' => 403 ) );
    }
    return true;
}

// TRACE: any → the fleet-driver row linked to the current user or null. Preconditions: none. Edge: unlinked → null.
function ridego_driver_current() {
    global $wpdb;
    $uid = get_current_user_id();
    if ( ! $uid ) { return null; }
    return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_fleet_drivers WHERE user_id=%d LIMIT 1", $uid ) );
}

// TRACE: POST vendor/drivers/{id}/login { email, password? } → the owning vendor gives a driver a login →
//        { ok, user_id } and a reset email when no password. Preconditions: driver belongs to the vendor, no login yet.
//        Postconditions: fleet_drivers.user_id set and verified by re-read. Edge cases: duplicate email (409), foreign driver (404).
function ridego_driver_api_create_login( WP_REST_Request $req ) {
    global $wpdb;
    $vendor = ridego_get_vendor_by_user( get_current_user_id() );
    $drv = ridego_get_fleet_driver( (int) $req['id'] );
    if ( ! $drv || (int) $drv->vendor_id !== (int) $vendor->id ) { return new WP_Error( 'not_found', 'Driver not found.', array( 'status' => 404 ) ); }
    if ( ! empty( $drv->user_id ) ) { return new WP_Error( 'exists', 'This driver already has a login.', array( 'status' => 409 ) ); }
    $email = sanitize_email( (string) $req->get_param( 'email' ) );
    if ( ! is_email( $email ) ) { return new WP_Error( 'invalid_input', 'Enter a valid email address.', array( 'status' => 400 ) ); }
    if ( email_exists( $email ) ) { return new WP_Error( 'exists', 'A user with this email already exists.', array( 'status' => 409 ) ); }
    $pw = (string) $req->get_param( 'password' );
    if ( $pw !== '' && strlen( $pw ) < 10 ) { return new WP_Error( 'invalid_input', 'Password must be at least 10 characters.', array( 'status' => 400 ) ); }
    $login = 'drv' . (int) $drv->id . '_' . substr( md5( $email ), 0, 5 );
    $uid = wp_insert_user( array( 'user_login' => $login, 'user_email' => $email, 'display_name' => $drv->name, 'first_name' => $drv->name, 'user_pass' => $pw !== '' ? $pw : wp_generate_password( 24 ), 'role' => 'ridego_driver' ) );
    if ( is_wp_error( $uid ) ) { return new WP_Error( 'create_failed', $uid->get_error_message(), array( 'status' => 400 ) ); }
    $ok = $wpdb->update( $wpdb->prefix . 'ridego_fleet_drivers', array( 'user_id' => $uid ), array( 'id' => (int) $drv->id ) );
    if ( $ok === false ) { wp_delete_user( $uid ); return new WP_Error( 'save_failed', 'Could not link the login to the driver.', array( 'status' => 500 ) ); }
    if ( $pw === '' ) { retrieve_password( $login ); }
    ridego_audit_log( 'driver_login_created', 'driver', (int) $drv->id, '', array( 'user_id' => $uid ) );
    return rest_ensure_response( array( 'ok' => true, 'user_id' => $uid ) );
}

// TRACE: GET driver/me → the driver's own profile, documents (with validity) and upcoming assigned trips → array.
//        Edge cases: no docs (empty list), no trips (empty list). Never exposes the vendor's other drivers.
function ridego_driver_api_me() {
    global $wpdb;
    $d = ridego_driver_current();
    $docs = array();
    foreach ( ridego_get_fleet_docs( (int) $d->vendor_id, 'driver', (int) $d->id ) as $r ) {
        $docs[] = array( 'id' => (int) $r->id, 'doc_type' => $r->doc_type, 'status' => $r->status, 'expiry_date' => $r->expiry_date, 'validity' => $r->validity, 'uploaded_at' => $r->uploaded_at );
    }
    // Root-cause note: this used to select only the fields a plain list row
    // needed (city/date/status). The driver-facing trip execution UI
    // (DriverTripDetailPage) needs the full state-machine timestamps —
    // driver_en_route_at/driver_arrived_at/trip_started_at — to know which
    // of en-route/arrived/start/no-show is currently valid for a given
    // trip without a second round-trip per card.
    $trips = $wpdb->get_results( $wpdb->prepare(
        "SELECT b.id, b.booking_number, b.trip_type, b.pickup_city, b.drop_city, b.pickup_address, b.drop_address,
                b.journey_date, b.journey_time, b.status, b.passengers, b.driver_en_route_at, b.driver_arrived_at,
                b.trip_started_at, b.client_name, b.client_phone
         FROM {$wpdb->prefix}ridego_booking_assignments a
         JOIN {$wpdb->prefix}ridego_bookings b ON b.id=a.booking_id WHERE a.driver_id=%d AND a.is_current=1 AND b.status NOT IN ('cancelled','completed','no_show') ORDER BY b.journey_date ASC LIMIT 50", (int) $d->id ) );
    return rest_ensure_response( array(
        'profile' => array( 'id' => (int) $d->id, 'name' => $d->name, 'mobile' => $d->mobile, 'license_number' => $d->license_number, 'license_expiry' => $d->license_expiry, 'status' => $d->status ),
        'doc_types' => ridego_fleet_doc_types( 'driver' ), 'docs' => $docs, 'trips' => (array) $trips,
        'max_upload_mb' => function_exists( 'ridego_max_upload_bytes' ) ? round( ridego_max_upload_bytes() / ( 1024 * 1024 ), 1 ) : 5 ) );
}

// TRACE: GET driver/trips/{id} → full detail for ONE trip currently or
//        previously assigned to the calling driver (any status, so a
//        driver can still open a completed/cancelled/no-show trip from
//        history) → array|WP_Error. Preconditions: an assignment row for
//        (driver, booking) exists at all — not restricted to is_current=1,
//        since a reassigned-away or finished trip should still be
//        viewable by the driver who worked it, just not actionable
//        (ridego_driver_trip_owned_booking() is what gates the ACTION
//        endpoints to the CURRENT assignment; this read-only endpoint
//        uses the wider check on purpose). Edge cases: booking not found,
//        or never assigned to this driver at all (404 either way — same
//        information-hiding rationale as the vendor earnings lookup).
function ridego_driver_api_trip_detail( WP_REST_Request $req ) {
    global $wpdb;
    $d = ridego_driver_current();
    $bid = (int) $req['id'];
    $owned = (bool) $wpdb->get_var( $wpdb->prepare(
        "SELECT 1 FROM {$wpdb->prefix}ridego_booking_assignments WHERE booking_id=%d AND driver_id=%d LIMIT 1", $bid, (int) $d->id
    ) );
    if ( ! $owned ) { return new WP_Error( 'not_found', 'Trip not found.', array( 'status' => 404 ) ); }
    $b = ridego_get_booking( $bid );
    if ( ! $b ) { return new WP_Error( 'not_found', 'Trip not found.', array( 'status' => 404 ) ); }
    $is_current = (bool) $wpdb->get_var( $wpdb->prepare(
        "SELECT 1 FROM {$wpdb->prefix}ridego_booking_assignments WHERE booking_id=%d AND driver_id=%d AND is_current=1 LIMIT 1", $bid, (int) $d->id
    ) );
    return rest_ensure_response( array(
        'id' => (int) $b->id, 'booking_number' => $b->booking_number, 'trip_type' => $b->trip_type,
        'status' => $b->status, 'pickup_city' => $b->pickup_city, 'drop_city' => $b->drop_city,
        'pickup_address' => $b->pickup_address, 'drop_address' => $b->drop_address,
        'journey_date' => $b->journey_date, 'journey_time' => $b->journey_time,
        'passengers' => (int) $b->passengers, 'luggage_count' => isset( $b->luggage_count ) ? (int) $b->luggage_count : 0,
        'client_name' => $b->client_name, 'client_phone' => $is_current ? $b->client_phone : null,
        'special_requests' => $b->special_requests,
        'driver_en_route_at' => $b->driver_en_route_at, 'driver_arrived_at' => $b->driver_arrived_at,
        'trip_started_at' => $b->trip_started_at, 'trip_ended_at' => $b->trip_ended_at,
        'no_show_reason' => $b->no_show_reason,
        'is_current_assignment' => $is_current,
    ) );
}

// TRACE: GET driver/trips/history → the calling driver's past trips
//        (completed, cancelled, no_show, expired — anything no longer
//        upcoming), newest first, capped at 50 → {rows}. Root-cause fix:
//        ridego_driver_api_me()'s trips list has always excluded exactly
//        these statuses (by design — it's an "upcoming" list), so a
//        driver had no way to see a trip once it left that list, even
//        though the earnings ledger (driver/earnings) already assumes
//        the driver can identify which trip a ledger entry's booking_id
//        refers to.
function ridego_driver_api_trip_history( WP_REST_Request $req ) {
    global $wpdb;
    $d = ridego_driver_current();
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT b.id, b.booking_number, b.trip_type, b.pickup_city, b.drop_city, b.journey_date, b.journey_time, b.status, b.trip_ended_at
         FROM {$wpdb->prefix}ridego_booking_assignments a
         JOIN {$wpdb->prefix}ridego_bookings b ON b.id=a.booking_id
         WHERE a.driver_id=%d AND b.status IN ('completed','cancelled','no_show','expired')
         ORDER BY b.journey_date DESC, b.id DESC LIMIT 50", (int) $d->id
    ) );
    return rest_ensure_response( array( 'rows' => (array) $rows ) );
}

// TRACE: POST driver/docs (multipart doc_type, file, expiry_date?) → the driver uploads their own document → { success }.
//        Preconditions: signed-in driver. Postconditions: row upserted for (vendor, driver, doc_type). Edge: bad type (400), no file (400).
function ridego_driver_api_upload( WP_REST_Request $req ) {
    $d = ridego_driver_current();
    $type = sanitize_key( (string) $req->get_param( 'doc_type' ) );
    if ( ! in_array( $type, ridego_fleet_doc_types( 'driver' ), true ) ) { return new WP_Error( 'invalid_input', 'Unknown document type.', array( 'status' => 400 ) ); }
    $files = $req->get_file_params();
    if ( empty( $files['file']['tmp_name'] ) ) { return new WP_Error( 'invalid_input', 'A file is required.', array( 'status' => 400 ) ); }
    $r = ridego_upload_vendor_doc( (int) $d->vendor_id, $type, $files['file'], sanitize_text_field( (string) $req->get_param( 'expiry_date' ) ), null, (int) $d->id );
    if ( empty( $r['success'] ) ) { return new WP_Error( 'upload_failed', $r['message'] ?? 'Could not upload document.', array( 'status' => 400 ) ); }
    return rest_ensure_response( $r );
}

// TRACE: GET driver/docs/{id}/file → streams the driver's OWN document → file bytes. Edge: someone else's doc (404).
function ridego_driver_api_doc_file( WP_REST_Request $req ) {
    global $wpdb;
    $d = ridego_driver_current();
    $doc = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_driver_docs WHERE id=%d AND driver_id=%d", (int) $req['id'], (int) $d->id ) );
    if ( ! $doc ) { return new WP_Error( 'not_found', 'Document not found.', array( 'status' => 404 ) ); }
    $full = RIDEGO_SECURE_UPLOADS . $doc->file_path;
    $real = realpath( $full ); $base = realpath( RIDEGO_SECURE_UPLOADS );
    if ( ! $real || ! $base || strpos( $real, $base ) !== 0 ) { return new WP_Error( 'not_found', 'File not found.', array( 'status' => 404 ) ); }
    $ext = strtolower( pathinfo( $real, PATHINFO_EXTENSION ) );
    $mime = array( 'jpg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'pdf' => 'application/pdf' );
    header( 'Content-Type: ' . ( $mime[ $ext ] ?? 'application/octet-stream' ) );
    header( 'X-Content-Type-Options: nosniff' );
    header( 'Content-Length: ' . filesize( $real ) );
    readfile( $real );
    exit;
}

/* ================================================================
   Driver-facing trip state machine (RG-012, Master Issue Register P1).
   ------------------------------------------------------------
   Before this, only an admin could move a booking through
   driver_en_route/trip_started (via the generic booking /status
   endpoint) or record a no-show — a driver had no way to report their
   own progress. These four endpoints let the driver ASSIGNED to a
   booking (via ridego_get_current_assignment(), the same immutable
   assignment record ridego_driver_api_me() already reads trips from)
   self-report en-route → arrived → trip start (OTP-gated, same
   otp_pickup the client sees) or a no-show, each guarded by the
   correct preceding state so a driver cannot skip steps (e.g. cannot
   "start" a trip they never marked en-route/arrived for) and cannot
   act on a booking that isn't currently assigned to them.
   ================================================================ */

// TRACE: any of the four actions below → the current (is_current=1) assignment for the booking,
//        but ONLY when it belongs to the calling driver → array(booking,assignment)|WP_Error.
//        Edge cases: booking not found (404); assigned to a different driver, or never assigned
//        (403 — this IS the IDOR guard, not just a convenience lookup).
function ridego_driver_trip_owned_booking( $booking_id ) {
    $b = ridego_get_booking( (int) $booking_id );
    if ( ! $b ) { return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) ); }
    $d = ridego_driver_current();
    $a = ridego_get_current_assignment( (int) $booking_id );
    if ( ! $d || ! $a || (int) $a->driver_id !== (int) $d->id ) {
        return new WP_Error( 'forbidden', 'This trip is not assigned to you.', array( 'status' => 403 ) );
    }
    return array( $b, $a );
}

// TRACE: POST driver/trips/{id}/en-route → booking assigned to caller AND status is
//        confirmed|vendor_assigned → status=driver_en_route, driver_en_route_at=now → {success}.
//        Postconditions: audited (status_change, actor recorded via ridego_audit_log's own
//        real-user resolution). Edge cases: wrong starting status (409, names the actual status
//        so the driver's app can show why); already en_route (idempotent-safe 409 with a clear
//        message rather than silently re-timestamping).
function ridego_driver_api_trip_en_route( WP_REST_Request $req ) {
    global $wpdb;
    $owned = ridego_driver_trip_owned_booking( (int) $req['id'] );
    if ( is_wp_error( $owned ) ) { return $owned; }
    list( $b, $a ) = $owned;
    if ( ! in_array( $b->status, array( 'confirmed', 'vendor_assigned' ), true ) ) {
        return new WP_Error( 'invalid_state', 'Cannot mark en route from status "' . $b->status . '".', array( 'status' => 409 ) );
    }
    $wpdb->update( $wpdb->prefix . 'ridego_bookings', array( 'status' => 'driver_en_route', 'driver_en_route_at' => current_time( 'mysql' ) ), array( 'id' => (int) $b->id ) );
    ridego_audit_log( 'driver_marked_en_route', 'booking', (int) $b->id, $b->status, 'driver_en_route' );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Marked en route to pickup.' ) );
}

// TRACE: POST driver/trips/{id}/arrived → booking assigned to caller AND status=driver_en_route
//        AND not already marked arrived → driver_arrived_at=now (status unchanged; "arrived" is a
//        sub-state within driver_en_route, not a separate booking status) → {success}. Edge cases:
//        wrong status (409); already arrived (409, does not silently re-timestamp).
function ridego_driver_api_trip_arrived( WP_REST_Request $req ) {
    global $wpdb;
    $owned = ridego_driver_trip_owned_booking( (int) $req['id'] );
    if ( is_wp_error( $owned ) ) { return $owned; }
    list( $b, $a ) = $owned;
    if ( $b->status !== 'driver_en_route' ) {
        return new WP_Error( 'invalid_state', 'Cannot mark arrived from status "' . $b->status . '".', array( 'status' => 409 ) );
    }
    if ( ! empty( $b->driver_arrived_at ) ) {
        return new WP_Error( 'already_arrived', 'Already marked arrived for this trip.', array( 'status' => 409 ) );
    }
    $wpdb->update( $wpdb->prefix . 'ridego_bookings', array( 'driver_arrived_at' => current_time( 'mysql' ) ), array( 'id' => (int) $b->id ) );
    ridego_audit_log( 'driver_marked_arrived', 'booking', (int) $b->id, '', current_time( 'mysql' ) );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Marked arrived at pickup.' ) );
}

// TRACE: POST driver/trips/{id}/start {otp} → booking assigned to caller AND status=driver_en_route
//        AND driver_arrived_at set (must have arrived first) AND supplied otp matches
//        booking.otp_pickup exactly → status=trip_started, trip_started_at=now → {success}.
//        Preconditions enforce the real-world order (en route → arrived → OTP-verified start), the
//        same OTP the client already sees (ridego_client_dash_trip()). Edge cases: not yet arrived
//        (409, distinct message from wrong-status so the driver's app can prompt "mark arrived
//        first" rather than a generic error); wrong/missing OTP (400, does not reveal the correct one).
function ridego_driver_api_trip_start( WP_REST_Request $req ) {
    global $wpdb;
    $owned = ridego_driver_trip_owned_booking( (int) $req['id'] );
    if ( is_wp_error( $owned ) ) { return $owned; }
    list( $b, $a ) = $owned;
    if ( $b->status !== 'driver_en_route' ) {
        return new WP_Error( 'invalid_state', 'Cannot start trip from status "' . $b->status . '".', array( 'status' => 409 ) );
    }
    if ( empty( $b->driver_arrived_at ) ) {
        return new WP_Error( 'not_arrived', 'Mark arrived at pickup before starting the trip.', array( 'status' => 409 ) );
    }
    $otp = sanitize_text_field( (string) $req->get_param( 'otp' ) );
    if ( $otp === '' || ! empty( $b->otp_pickup ) && ! hash_equals( (string) $b->otp_pickup, $otp ) ) {
        return new WP_Error( 'invalid_otp', 'The pickup OTP does not match.', array( 'status' => 400 ) );
    }
    $wpdb->update( $wpdb->prefix . 'ridego_bookings', array( 'status' => 'trip_started', 'trip_started_at' => current_time( 'mysql' ) ), array( 'id' => (int) $b->id ) );
    ridego_audit_log( 'driver_started_trip', 'booking', (int) $b->id, $b->status, 'trip_started' );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Trip started.' ) );
}

// TRACE: POST driver/trips/{id}/no-show {reason} → booking assigned to caller AND status=
//        driver_en_route AND driver_arrived_at set (must have actually arrived to report a
//        no-show — cannot no-show a client the driver never reached) AND a non-blank reason →
//        status=no_show, no_show_at=now, no_show_reason set → {success}. Postconditions: audited
//        with severity='warning' (matches other client-impacting terminal events like cancellation).
//        Known limitation, stated rather than hidden: this does not touch refund/forfeit
//        disposition — a no-show may need the same booking-amount refund/forfeit review a
//        cancellation gets (ridego_cancel_booking()'s cancel_forfeit_to logic), which is NOT yet
//        wired to this new status and is flagged as explicit follow-up work, not silently assumed.
function ridego_driver_api_trip_no_show( WP_REST_Request $req ) {
    global $wpdb;
    $owned = ridego_driver_trip_owned_booking( (int) $req['id'] );
    if ( is_wp_error( $owned ) ) { return $owned; }
    list( $b, $a ) = $owned;
    if ( $b->status !== 'driver_en_route' ) {
        return new WP_Error( 'invalid_state', 'Cannot report a no-show from status "' . $b->status . '".', array( 'status' => 409 ) );
    }
    if ( empty( $b->driver_arrived_at ) ) {
        return new WP_Error( 'not_arrived', 'Mark arrived at pickup before reporting a no-show.', array( 'status' => 409 ) );
    }
    $reason = trim( sanitize_textarea_field( (string) $req->get_param( 'reason' ) ) );
    if ( $reason === '' ) {
        return new WP_Error( 'invalid_input', 'Please give a reason for the no-show.', array( 'status' => 400 ) );
    }
    $wpdb->update( $wpdb->prefix . 'ridego_bookings', array(
        'status' => 'no_show', 'no_show_at' => current_time( 'mysql' ), 'no_show_reason' => mb_substr( $reason, 0, 255 ),
    ), array( 'id' => (int) $b->id ) );
    ridego_audit_log( 'driver_reported_no_show', 'booking', (int) $b->id, $b->status, $reason, 'warning' );
    return rest_ensure_response( array( 'success' => true, 'message' => 'No-show recorded.' ) );
}

/* ================================================================
   Driver earnings ledger (RG-013, Master Issue Register P1).
   ------------------------------------------------------------
   The RideGo facilitator model has the VENDOR collect the ride
   balance from the client, not RideGo (see ridego_booking_financials()
   in platform-model.php) — what a vendor then pays their own driver is
   an internal arrangement between vendor and driver that this codebase
   never modeled at all. Rather than fabricate an automatic commission
   split with no real basis (which would silently misstate money), this
   is a ledger the VENDOR records into explicitly — mirroring the exact
   pattern ridego_booking_payment_row()/ridego_booking_get_payments()
   already use for booking payments — so a running balance is always
   derived by summing real recorded entries, never a denormalised
   number that can drift from its own history.
   ================================================================ */

// TRACE: booking id or 0 + type trip_payout|bonus|deduction|adjustment + amount + note + vendor id →
//        inserts one ridego_driver_earnings row → id|false. Deductions are stored as a NEGATIVE
//        amount so a running balance is a plain SUM(amount), matching how ridego_booking_payments'
//        refund rows are handled by ridego_booking_recalculate_payment(). Pure insert (no totals).
function ridego_driver_earnings_row( $driver_id, $vendor_id, $booking_id, $type, $amount, $note, $by ) {
    global $wpdb;
    $ok = $wpdb->insert( $wpdb->prefix . 'ridego_driver_earnings', array(
        'driver_id' => (int) $driver_id, 'vendor_id' => (int) $vendor_id, 'booking_id' => $booking_id ? (int) $booking_id : null,
        'entry_type' => sanitize_key( $type ), 'amount' => round( (float) $amount, 2 ),
        'note' => mb_substr( sanitize_text_field( (string) $note ), 0, 255 ), 'recorded_by' => (int) $by, 'created_at' => current_time( 'mysql' ),
    ) );
    return $ok ? (int) $wpdb->insert_id : false;
}

// TRACE: driver id → ledger rows newest first + running balance (SUM(amount)) → array. Pure read.
function ridego_driver_earnings_ledger( $driver_id ) {
    global $wpdb;
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT e.*, u.display_name AS recorded_by_name FROM {$wpdb->prefix}ridego_driver_earnings e
         LEFT JOIN {$wpdb->users} u ON u.ID = e.recorded_by WHERE e.driver_id=%d ORDER BY e.id DESC", (int) $driver_id
    ) );
    $balance = (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount),0) FROM {$wpdb->prefix}ridego_driver_earnings WHERE driver_id=%d", (int) $driver_id ) );
    return array(
        'balance' => round( $balance, 2 ),
        'rows' => array_map( function ( $r ) {
            return array(
                'id' => (int) $r->id, 'booking_id' => $r->booking_id ? (int) $r->booking_id : null, 'entry_type' => $r->entry_type,
                'amount' => (float) $r->amount, 'note' => $r->note, 'recorded_by' => $r->recorded_by_name ?: 'System', 'created_at' => $r->created_at,
            );
        }, $rows ),
    );
}

// TRACE: GET driver/earnings → the CURRENT driver's own ledger + balance → response. Preconditions:
//        ridego_driver_perm_self() already ran (active driver). Postconditions: read-only.
function ridego_driver_api_earnings( WP_REST_Request $req ) {
    $d = ridego_driver_current();
    return rest_ensure_response( ridego_driver_earnings_ledger( (int) $d->id ) );
}

// TRACE: GET vendor/drivers/{id}/earnings → the vendor's OWN driver's ledger + balance → response|404.
//        Preconditions: ridego_driver_perm_vendor() already ran. Postconditions: read-only. Edge cases:
//        a driver id belonging to a different vendor (404, not 403 — does not confirm the id exists
//        at all to a vendor who does not own it, the same information-hiding as
//        ridego_driver_api_create_login()'s existing not_found response for the identical situation).
function ridego_vendor_api_driver_earnings_list( WP_REST_Request $req ) {
    $vendor = ridego_get_vendor_by_user( get_current_user_id() );
    $drv = ridego_get_fleet_driver( (int) $req['id'] );
    if ( ! $drv || (int) $drv->vendor_id !== (int) $vendor->id ) { return new WP_Error( 'not_found', 'Driver not found.', array( 'status' => 404 ) ); }
    return rest_ensure_response( ridego_driver_earnings_ledger( (int) $drv->id ) );
}

// TRACE: POST vendor/drivers/{id}/earnings {entry_type, amount, note?, booking_id?} → vendor records
//        a payout/bonus/deduction/adjustment for their OWN driver → {success,id,balance}. Preconditions:
//        driver belongs to the calling vendor; entry_type is one of the four allowed values; amount is
//        a positive number (deductions are expressed as entry_type='deduction' with a positive amount
//        the endpoint itself negates — never a negative amount typed by the caller, which would be easy
//        to get backwards). Postconditions: audited; balance in the response reflects the new entry
//        immediately (re-read from the ledger, not computed ad hoc, so it can never disagree with a
//        subsequent GET). Edge cases: foreign driver (404, matches the list endpoint's information-
//        hiding); unknown entry_type (400); non-positive amount (400); an optional booking_id that
//        does not belong to this driver's vendor is still recorded (a vendor could mistype a booking
//        id) but is NOT validated against the assignment table — flagged as a known limitation rather
//        than silently assumed correct.
function ridego_vendor_api_driver_earnings_create( WP_REST_Request $req ) {
    $vendor = ridego_get_vendor_by_user( get_current_user_id() );
    $drv = ridego_get_fleet_driver( (int) $req['id'] );
    if ( ! $drv || (int) $drv->vendor_id !== (int) $vendor->id ) { return new WP_Error( 'not_found', 'Driver not found.', array( 'status' => 404 ) ); }

    $type = sanitize_key( (string) $req->get_param( 'entry_type' ) );
    $allowed = array( 'trip_payout', 'bonus', 'deduction', 'adjustment' );
    if ( ! in_array( $type, $allowed, true ) ) {
        return new WP_Error( 'invalid_input', 'entry_type must be one of: ' . implode( ', ', $allowed ) . '.', array( 'status' => 400 ) );
    }
    $amount = (float) $req->get_param( 'amount' );
    if ( $amount <= 0 ) {
        return new WP_Error( 'invalid_input', 'Amount must be a positive number.', array( 'status' => 400 ) );
    }
    $signed_amount = $type === 'deduction' ? -$amount : $amount;
    $booking_id = (int) $req->get_param( 'booking_id' );
    $note = (string) $req->get_param( 'note' );

    $id = ridego_driver_earnings_row( (int) $drv->id, (int) $vendor->id, $booking_id ?: null, $type, $signed_amount, $note, get_current_user_id() );
    if ( ! $id ) {
        return new WP_Error( 'save_failed', 'Could not record the entry.', array( 'status' => 500 ) );
    }
    ridego_audit_log( 'driver_earnings_recorded', 'driver', (int) $drv->id, '', array( 'type' => $type, 'amount' => $signed_amount ) );
    $ledger = ridego_driver_earnings_ledger( (int) $drv->id );
    return rest_ensure_response( array( 'success' => true, 'id' => $id, 'balance' => $ledger['balance'] ) );
}
