<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — financial reconciliation report.
   ------------------------------------------------------------
   Added by the platform audit (Section 10 / RG-005): per-booking
   money math is already enforced at write time by
   ridego_booking_recalculate_payment() and the canonical
   ridego_booking_financials() (includes/platform-model.php) — those
   guards are correct and this file does not duplicate or replace
   them. What was missing is a cross-booking VIEW that can catch
   drift despite those guards: a row edited directly in the DB, a
   booking created before a guard existed, or a bug in a future
   change to the money-flow code. This is a read-only report, never
   a write path — it flags, it does not correct (correcting a flagged
   row still goes through the existing guarded functions, e.g.
   ridego_booking_record_refund(), never a raw update from here).
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_reconciliation_api_routes' );
function ridego_register_app_admin_reconciliation_api_routes() {
    register_rest_route( 'ridego/v1', '/app/admin/reports/reconciliation', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_reconciliation_report',
        'permission_callback' => 'ridego_app_admin_api_reconciliation_permission',
    ) );
}

function ridego_app_admin_api_reconciliation_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_view_ledger' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to view financial reports.', array( 'status' => 403 ) );
    }
    return true;
}

// TRACE: GET reports/reconciliation?date_from&date_to → every booking created in range with its
//        ridego_booking_financials() summary, flagged where the summary is internally inconsistent →
//        {summary:{...totals...}, flagged:[{booking_id,booking_number,status,reasons:[...],...}], total_checked}.
//        Preconditions: caller has ridego_view_ledger. Postconditions: read-only, no row is changed.
//        Edge cases: no bookings in range (empty flagged list, zero totals, not an error); a closed
//        (cancelled/expired/token_refund_due) booking is checked against different, looser rules since it owes
//        nothing further by design.
function ridego_app_admin_api_reconciliation_report( WP_REST_Request $req ) {
    global $wpdb;
    $btbl = $wpdb->prefix . 'ridego_bookings';

    $date_from = sanitize_text_field( (string) $req->get_param( 'date_from' ) ) ?: date( 'Y-m-d', strtotime( '-30 days' ) );
    $date_to   = sanitize_text_field( (string) $req->get_param( 'date_to' ) ) ?: date( 'Y-m-d' );

    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$btbl} WHERE DATE(created_at) BETWEEN %s AND %s ORDER BY created_at DESC",
        $date_from, $date_to
    ) );

    $tolerance = 0.02; // 2 paise/cents — float rounding slack, not a real discrepancy
    $flagged   = array();
    $totals    = array(
        'total_fare_sum' => 0.0, 'booking_amount_paid_sum' => 0.0, 'vendor_collected_sum' => 0.0,
        'vendor_outstanding_sum' => 0.0, 'checked' => 0, 'flagged' => 0,
    );

    foreach ( $rows as $b ) {
        $totals['checked']++;
        $fin = ridego_booking_financials( $b );
        if ( empty( $fin ) ) { continue; }

        $totals['total_fare_sum']         += $fin['estimated_ride_fare'];
        $totals['booking_amount_paid_sum'] += $fin['booking_amount_paid'];
        $totals['vendor_collected_sum']    += $fin['vendor_collected'];
        $totals['vendor_outstanding_sum']  += $fin['vendor_outstanding'];

        $reasons = array();
        $closed  = in_array( $b->status, array( 'cancelled', 'expired', 'token_refund_due' ), true );

        // 1. RideGo's own collected amount can never exceed what the booking actually owes RideGo.
        if ( $fin['booking_amount_paid'] > $fin['booking_amount'] + $tolerance ) {
            $reasons[] = 'Booking amount paid (' . $fin['booking_amount_paid'] . ') exceeds booking amount due (' . $fin['booking_amount'] . ')';
        }
        // 2. total_fare should reconstruct from its own stored line items (base + toll + parking + driver
        //    allowance + extra-km + GST − discount). This deliberately does NOT use ridego_booking_financials()
        //    at all — it cross-checks total_fare against a genuinely independent set of raw columns, which is
        //    what actually catches drift (a bug in a future fare-calc change, or a directly-edited row). An
        //    earlier version of this check compared two values both derived from the SAME formula inside
        //    ridego_booking_financials() (paid+pending vs amount due) — arithmetically guaranteed to always
        //    match by construction, so it could never have caught anything; found and corrected before this
        //    endpoint was considered verified, by deliberately trying to make it fail against a corrupted row.
        $components_sum = round(
            (float) $b->base_fare + (float) $b->toll_charges + (float) $b->parking_charges
            + (float) $b->driver_allowance + (float) $b->extra_km_charges + (float) $b->gst_amount
            - (float) $b->discount_amount, 2
        );
        if ( abs( $components_sum - round( (float) $b->total_fare, 2 ) ) > $tolerance ) {
            $reasons[] = 'total_fare (' . round( (float) $b->total_fare, 2 ) . ') does not match its own fare components summed (' . $components_sum . ')';
        }
        // 3. Raw vendor_collected (what was actually recorded as collected) should never exceed what the
        //    booking's own fare/platform-amount fields say is payable to the vendor — checked against those raw
        //    columns directly, not against ridego_booking_financials()'s clamped 'vendor_collected' output (which
        //    caps at the payable amount by construction and so could never itself show an over-collection).
        $raw_payable = $closed ? 0.0 : max( 0.0, round( (float) $b->total_fare - $fin['booking_amount'], 2 ) );
        $raw_collected = round( (float) ( $b->vendor_collected ?? 0 ), 2 );
        if ( ! $closed && $raw_collected > $raw_payable + $tolerance ) {
            $reasons[] = 'vendor_collected (' . $raw_collected . ') exceeds the actual payable-to-vendor amount (' . $raw_payable . ')';
        }
        // 4. A closed (cancelled/expired/token_refund_due) booking should have vendor_collected still at 0 if
        //    nothing was ever actually collected before it closed. ridego_booking_financials() intentionally
        //    zeroes 'payable_to_vendor' for any closed booking BY DESIGN (see its own doc comment) — checking
        //    that already-zeroed field here would always pass and catch nothing, so this checks the raw stored
        //    column instead: a non-zero vendor_collected on a cancelled/expired/token_refund_due booking means
        //    money was recorded as collected for a ride that, per its own status, didn't owe the vendor anything.
        if ( $closed && round( (float) ( $b->vendor_collected ?? 0 ), 2 ) > $tolerance ) {
            $reasons[] = 'Booking is ' . $b->status . ' but vendor_collected is still ' . round( (float) $b->vendor_collected, 2 ) . ' — should be 0 or explained by a pre-cancellation collection';
        }
        // 5. total_fare should never be negative, and never zero on a non-cancelled, fully-formed booking.
        if ( $fin['estimated_ride_fare'] < 0 ) {
            $reasons[] = 'Total fare is negative (' . $fin['estimated_ride_fare'] . ')';
        }

        if ( ! empty( $reasons ) ) {
            $totals['flagged']++;
            $flagged[] = array(
                'booking_id'     => (int) $b->id,
                'booking_number' => $b->booking_number,
                'status'         => $b->status,
                'created_at'     => $b->created_at,
                'financials'     => $fin,
                'reasons'        => $reasons,
            );
        }
    }

    foreach ( array( 'total_fare_sum', 'booking_amount_paid_sum', 'vendor_collected_sum', 'vendor_outstanding_sum' ) as $k ) {
        $totals[ $k ] = round( $totals[ $k ], 2 );
    }

    return rest_ensure_response( array(
        'date_from' => $date_from,
        'date_to'   => $date_to,
        'summary'   => $totals,
        'flagged'   => $flagged,
    ) );
}
