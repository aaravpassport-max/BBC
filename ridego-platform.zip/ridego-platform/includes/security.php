<?php
/**
 * RideGo Platform - Security Layer
 * Session 6: Production security hardening
 * 
 * Implements:
 * - Input sanitization & validation
 * - SQL injection prevention
 * - XSS protection
 * - CSRF protection via nonces
 * - Rate limiting
 * - File upload validation
 * - SQL escaping
 * - Capability checks
 */

if (!defined('ABSPATH')) exit;

/**
 * Sanitize all booking form inputs.
 * NOTE: a more comprehensive version is defined in includes/helpers.php (loaded before
 * security.php). That version handles more fields (return_date, UTM, corporate fields,
 * etc.). This copy is guarded as a fallback only.
 *
 * @param array $data Raw POST data
 * @return array Sanitized data
 */
if ( ! function_exists('ridego_sanitize_booking_input') ) :
function ridego_sanitize_booking_input($data) {
    
    $sanitized = array();
    
    // Text fields
    $text_fields = array('client_name', 'pickup_city', 'pickup_address', 'drop_city', 'drop_address');
    foreach ($text_fields as $field) {
        $sanitized[$field] = isset($data[$field]) ? sanitize_text_field($data[$field]) : '';
    }
    
    // Email
    $sanitized['client_email'] = isset($data['client_email']) ? sanitize_email($data['client_email']) : '';
    
    // Phone (numeric only)
    $sanitized['client_phone'] = isset($data['client_phone']) ? preg_replace('/[^0-9+]/', '', $data['client_phone']) : '';
    
    // Integers
    $int_fields = array('vehicle_type_id', 'passengers', 'luggage_count');
    foreach ($int_fields as $field) {
        $sanitized[$field] = isset($data[$field]) ? absint($data[$field]) : 0;
    }
    
    // Floats
    $float_fields = array('pickup_lat', 'pickup_lng', 'drop_lat', 'drop_lng', 'distance_km');
    foreach ($float_fields as $field) {
        $sanitized[$field] = isset($data[$field]) ? floatval($data[$field]) : 0;
    }
    
    // Dates
    if (isset($data['journey_date']) && ridego_validate_date($data['journey_date'])) {
        $sanitized['journey_date'] = sanitize_text_field($data['journey_date']);
    } else {
        $sanitized['journey_date'] = '';
    }
    
    // Time
    $sanitized['journey_time'] = isset($data['journey_time']) ? sanitize_text_field($data['journey_time']) : '';
    
    // Trip type (whitelist)
    $allowed_trip_types = array('one_way', 'round_trip', 'local', 'airport_pickup', 'airport_drop', 'outstation');
    $sanitized['trip_type'] = isset($data['trip_type']) && in_array($data['trip_type'], $allowed_trip_types) 
        ? $data['trip_type'] : 'one_way';
    
    return $sanitized;
}
endif; // function_exists ridego_sanitize_booking_input

/**
 * Validate uploaded file (payment proof, KYC docs)
 * 
 * @param array $file $_FILES array element
 * @param array $allowed_types Allowed MIME types
 * @param int   $max_size Max size in bytes
 * @return array Result with success/error
 */
function ridego_validate_file_upload($file, $allowed_types = array(), $max_size = 5242880) {
    
    // Default allowed types
    if (empty($allowed_types)) {
        $allowed_types = array('image/jpeg', 'image/png', 'image/jpg', 'application/pdf');
    }
    
    // Check if file exists
    if (!isset($file['tmp_name']) || empty($file['tmp_name'])) {
        return array('success' => false, 'error' => 'No file uploaded');
    }
    
    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return array('success' => false, 'error' => 'File upload failed');
    }
    
    // Check file size
    if ($file['size'] > $max_size) {
        return array('success' => false, 'error' => 'File too large. Max: ' . ($max_size / 1024 / 1024) . 'MB');
    }
    
    // Check MIME type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mime_type, $allowed_types)) {
        return array('success' => false, 'error' => 'Invalid file type');
    }
    
    // Additional image validation
    if (strpos($mime_type, 'image/') === 0) {
        $image_info = getimagesize($file['tmp_name']);
        if ($image_info === false) {
            return array('success' => false, 'error' => 'Invalid image file');
        }
    }
    
    return array('success' => true, 'mime_type' => $mime_type);
}

/**
 * Rate limiting for critical actions
 * 
 * @param string $action Action identifier
 * @param string $identifier User identifier (IP, user_id, phone)
 * @param int    $max_attempts Max attempts allowed
 * @param int    $time_window Time window in seconds
 * @return array Result with allowed/blocked status
 */
function ridego_check_rate_limit($action, $identifier, $max_attempts = 5, $time_window = 3600) {

    global $wpdb;
    $table = $wpdb->prefix . 'ridego_rate_limits';
    $key   = md5($action . '|' . $identifier);
    $now   = current_time('mysql');

    // Atomic UPSERT-and-increment: the previous implementation did a
    // transient GET then a separate SET, which is a classic TOCTOU race —
    // two concurrent requests can both read "not yet at the limit" before
    // either writes back, letting an attacker exceed max_attempts by
    // racing requests. A single atomic INSERT ... ON DUPLICATE KEY UPDATE
    // closes that window: MySQL serializes concurrent writes to the same
    // unique key, so exactly one of two racing requests sees the
    // incremented count.
    //
    // window_started_at < (now - time_window) means the previous window
    // has expired: reset count to 1 and start a new window. Otherwise,
    // increment the existing window's count.
    $window_expiry = date( 'Y-m-d H:i:s', strtotime( $now ) - $time_window );
    $wpdb->query( $wpdb->prepare(
        "INSERT INTO {$table} (limit_key, count, window_started_at) VALUES (%s, 1, %s)
         ON DUPLICATE KEY UPDATE
            count = IF(window_started_at < %s, 1, count + 1),
            window_started_at = IF(window_started_at < %s, %s, window_started_at)",
        $key, $now, $window_expiry, $window_expiry, $now
    ) );

    $attempts = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT count FROM {$table} WHERE limit_key = %s", $key
    ) );

    if ($attempts > $max_attempts) {
        return array(
            'allowed' => false,
            'error' => 'Too many attempts. Please try again later.',
            'retry_after' => $time_window
        );
    }

    return array('allowed' => true, 'attempts' => $attempts);
}

/**
 * Read-only counterpart to ridego_check_rate_limit(): reports whether a
 * bucket is currently locked out WITHOUT recording a new attempt.
 *
 * ROOT CAUSE this pair of functions fixes: ridego_check_rate_limit()
 * increments its counter on every call, which is exactly the right
 * semantics for "don't let this endpoint be hit more than N times"
 * (OTP sends, fare lookups, promo validation, booking submits — all
 * still use it unchanged, below). It is the WRONG semantics for a login
 * lockout, where the thing that should count toward a lockout is wrong
 * PASSWORDS, not login attempts in general — a real user who logs in
 * successfully five times in fifteen minutes must never be one
 * successful login away from being locked out of their own account.
 * ridego_check_login_attempts() and ridego_app_api_auth_login() (the
 * WordPress-native and REST/SPA login paths respectively) both used to
 * call ridego_check_rate_limit() directly on every attempt, success
 * included — confirmed live during the RideGo platform audit: repeated
 * valid logins during automated testing tripped the same 429 a brute-
 * force attacker would hit.
 *
 * The fix: callers now (1) peek here to decide whether to allow the
 * attempt at all, (2) attempt the real authentication, then (3) call
 * ridego_record_rate_limit_failure() ONLY if it failed, or
 * ridego_reset_rate_limit() if it succeeded. Only failures ever advance
 * the counter, so legitimate use never self-inflicts a lockout.
 */
function ridego_peek_rate_limit($action, $identifier, $max_attempts = 5, $time_window = 3600) {
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_rate_limits';
    $key   = md5($action . '|' . $identifier);
    $now   = current_time('mysql');
    $window_expiry = date( 'Y-m-d H:i:s', strtotime( $now ) - $time_window );

    $row = $wpdb->get_row( $wpdb->prepare(
        "SELECT count, window_started_at FROM {$table} WHERE limit_key = %s", $key
    ) );

    // No row yet, or the previous window has already expired: not locked out.
    if ( ! $row || $row->window_started_at < $window_expiry ) {
        return array('allowed' => true, 'attempts' => 0);
    }

    if ( (int) $row->count >= $max_attempts ) {
        return array(
            'allowed' => false,
            'error' => 'Too many attempts. Please try again later.',
            'retry_after' => $time_window,
        );
    }

    return array('allowed' => true, 'attempts' => (int) $row->count);
}

/**
 * Records one failed attempt against a rate-limit bucket. Same atomic
 * UPSERT-and-increment as ridego_check_rate_limit() (same TOCTOU-safety
 * rationale), but called explicitly only after a caller has confirmed
 * the attempt it's gating actually failed — see ridego_peek_rate_limit().
 */
function ridego_record_rate_limit_failure($action, $identifier, $time_window = 3600) {
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_rate_limits';
    $key   = md5($action . '|' . $identifier);
    $now   = current_time('mysql');
    $window_expiry = date( 'Y-m-d H:i:s', strtotime( $now ) - $time_window );

    $wpdb->query( $wpdb->prepare(
        "INSERT INTO {$table} (limit_key, count, window_started_at) VALUES (%s, 1, %s)
         ON DUPLICATE KEY UPDATE
            count = IF(window_started_at < %s, 1, count + 1),
            window_started_at = IF(window_started_at < %s, %s, window_started_at)",
        $key, $now, $window_expiry, $window_expiry, $now
    ) );
}

/**
 * Clears a rate-limit bucket entirely. Used to reset the login-lockout
 * counter for an identifier after a successful login, so earlier
 * mistyped-password attempts don't carry forward and count against the
 * user's next login.
 */
function ridego_reset_rate_limit($action, $identifier) {
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_rate_limits';
    $key   = md5($action . '|' . $identifier);
    $wpdb->delete( $table, array('limit_key' => $key) );
}

/**
 * Verify nonce for AJAX requests
 * Dies if nonce is invalid
 * 
 * @param string $nonce_name Nonce field name
 * @param string $action Nonce action
 */
function ridego_verify_ajax_nonce($nonce_name = 'nonce', $action = 'ridego_nonce') {
    
    if (!isset($_POST[$nonce_name]) || !wp_verify_nonce($_POST[$nonce_name], $action)) {
        wp_send_json_error(array('message' => 'Security check failed'));
        wp_die();
    }
}

/**
 * Check user capability
 * 
 * @param string $capability Required capability
 * @return bool Has capability
 */
function ridego_check_capability($capability = 'manage_options') {
    
    if (!current_user_can($capability)) {
        return false;
    }
    
    return true;
}

/**
 * Secure database query with prepared statements
 * 
 * @param string $query SQL query with placeholders
 * @param array  $values Values to bind
 * @return mixed Query result
 */
function ridego_secure_query($query, $values = array()) {
    global $wpdb;
    
    if (empty($values)) {
        return $wpdb->get_results($query);
    }
    
    // Use prepared statement
    $prepared = $wpdb->prepare($query, $values);
    return $wpdb->get_results($prepared);
}

/**
 * Sanitize output for display
 * 
 * @param string $text Text to sanitize
 * @param string $context Context: html, attribute, url
 * @return string Sanitized text
 */
function ridego_safe_output($text, $context = 'html') {
    
    switch ($context) {
        case 'html':
            return wp_kses_post($text);
        
        case 'attribute':
            return esc_attr($text);
        
        case 'url':
            return esc_url($text);
        
        case 'js':
            return esc_js($text);
        
        default:
            return esc_html($text);
    }
}

/**
 * Generate secure random token
 * 
 * @param int $length Token length
 * @return string Random token
 */
function ridego_generate_secure_token($length = 32) {
    
    if (function_exists('random_bytes')) {
        return bin2hex(random_bytes($length / 2));
    }
    
    return wp_generate_password($length, false);
}

/**
 * Log a security event into the real ridego_security_log table (created by
 * migration 002 in includes/migrations.php — columns: event_type,
 * identifier, ip_address, user_id, details, severity, created_at).
 *
 * This is the ONE canonical definition (includes/otp.php used to define a
 * second, divergent copy — removed; see the comment there). Both previous
 * copies wrote to columns that don't exist on the real table ('event',
 * 'data', 'user_agent'), so every call was a silent no-op. Fixed here to
 * match the actual schema, so security logging genuinely persists now.
 *
 * @param string $event Event type, e.g. 'otp_abuse', 'request_blocked'.
 * @param array  $data  Free-form context. 'severity' and 'identifier' keys
 *                       are pulled out into their own columns if present;
 *                       everything else is stored as JSON in `details`.
 */
function ridego_log_security_event($event, $data = array()) {

    global $wpdb;

    $table = $wpdb->prefix . 'ridego_security_log';

    $identifier = isset($data['identifier']) ? (string) $data['identifier'] : '';
    $severity   = isset($data['severity']) ? sanitize_text_field($data['severity']) : 'info';
    $user_id    = isset($data['user_id']) ? intval($data['user_id']) : ( is_user_logged_in() ? get_current_user_id() : null );

    $wpdb->insert($table, array(
        'event_type' => sanitize_text_field($event),
        'identifier' => sanitize_text_field($identifier),
        'ip_address' => ridego_get_client_ip(),
        'user_id'    => $user_id,
        'details'    => wp_json_encode($data),
        'severity'   => $severity,
        'created_at' => current_time('mysql'),
    ));
}

/**
 * Block suspicious activity
 * 
 * @param string $reason Reason for blocking
 */
function ridego_block_request($reason = 'Suspicious activity detected') {
    
    ridego_log_security_event('request_blocked', array(
        'reason' => $reason,
        'severity' => 'warning'
    ));
    
    wp_die(
        esc_html__('Access Denied', 'ridego'),
        esc_html__('Security Error', 'ridego'),
        array('response' => 403)
    );
}

/**
 * Validate Indian phone number
 * 
 * @param string $phone Phone number
 * @return bool Valid or not
 */
function ridego_validate_phone($phone) {
    
    $clean = preg_replace('/[^0-9]/', '', $phone);
    
    // Should be 10 digits
    if (strlen($clean) === 10 && preg_match('/^[6-9][0-9]{9}$/', $clean)) {
        return true;
    }
    
    // Or 12 digits with 91 prefix
    if (strlen($clean) === 12 && substr($clean, 0, 2) === '91' && preg_match('/^91[6-9][0-9]{9}$/', $clean)) {
        return true;
    }
    
    return false;
}

/**
 * Prevent SQL injection in LIKE queries
 * 
 * @param string $search Search term
 * @return string Escaped search term
 */
function ridego_escape_like($search) {
    global $wpdb;
    return '%' . $wpdb->esc_like(sanitize_text_field($search)) . '%';
}

/**
 * Security headers, including a real Content-Security-Policy.
 *
 * The CSP is applied only on the frontend (never wp-admin — WP core and
 * other admin-side plugins routinely rely on inline/eval'd JS that a
 * restrictive script-src would break, and this plugin's admin pages are
 * gated by their own capability checks rather than the CSP anyway).
 * Restricted to what the booking pages actually load: the site's own
 * scripts plus Google Maps JS/Places. style-src keeps 'unsafe-inline'
 * because WP themes and this plugin's own templates commonly rely on
 * inline style attributes — a pragmatic default, not a hardening gap
 * this task is meant to close (script-src is the injection-relevant one).
 *
 * ROOT-CAUSE FIX: this header predates the architectural pivot to the
 * standalone React/Vite SPA and was never updated for it — script-src
 * had no 'unsafe-inline' and no nonce, so the browser silently refused
 * to execute includes/app-shell.php's own injected
 * `<script>window.__RIDEGO__ = {...}</script>` bootstrap tag on every
 * single /app/... and site-root request. That's not a cosmetic bug: it
 * is the actual mechanism the app uses to learn its real API URL and
 * the current visitor's login state, so with it silently blocked,
 * bootstrap.ts fell back to its hardcoded local-dev defaults
 * (apiUrl: 'http://localhost/wp-json/...', logged_in: false) on every
 * real request — which a browser's console shows as a CSP violation,
 * not a PHP error or a failed network request, so it produced no
 * signal in any of this engagement's server-side verification (php -l,
 * the collision scan, tsc, npm run build) and was only caught by
 * driving a real browser against a real WordPress instance. This
 * fully explains the "shows logged out / asks to log in" symptom
 * independently of any hosting/proxy configuration — it would happen
 * on a perfectly configured server too.
 *
 * Fixed properly with a per-request nonce (see ridego_csp_script_nonce())
 * rather than the blunter fix of adding 'unsafe-inline' — a nonce lets
 * this plugin's own injected script run while still blocking an
 * attacker's injected <script> tag, which is the entire point of CSP
 * script-src in the first place.
 */
function ridego_add_security_headers() {

    if (!is_admin()) {
        header("X-Content-Type-Options: nosniff");
        header("X-Frame-Options: SAMEORIGIN");
        header("X-XSS-Protection: 1; mode=block");
        header("Referrer-Policy: strict-origin-when-cross-origin");

        $site_origin = parse_url( site_url(), PHP_URL_SCHEME ) . '://' . parse_url( site_url(), PHP_URL_HOST );
        $nonce = ridego_csp_script_nonce();
        $csp = "default-src 'self'; "
             . "script-src 'self' 'nonce-{$nonce}' {$site_origin} https://maps.googleapis.com https://maps.gstatic.com; "
             . "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
             . "img-src 'self' data: https://maps.gstatic.com https://maps.googleapis.com https://*.googleapis.com; "
             . "font-src 'self' data: https://fonts.gstatic.com; "
             . "connect-src 'self' https://maps.googleapis.com; "
             . "frame-ancestors 'self'; "
             . "base-uri 'self';";
        header( "Content-Security-Policy: {$csp}" );
    }
}
add_action('send_headers', 'ridego_add_security_headers');

/**
 * One random nonce per request, memoized so the exact same value is used
 * both in the Content-Security-Policy header above (fired on send_headers,
 * which runs before template_redirect) and in the nonce="..." attribute
 * includes/app-shell.php adds to its injected bootstrap <script> tag (see
 * ridego_app_render_shell(), which runs later, on template_redirect) —
 * they MUST match exactly or the browser still blocks the script. Not
 * related to WordPress's own wp_create_nonce()/REST nonce system despite
 * the similar name; this is purely a CSP script-execution token.
 */
function ridego_csp_script_nonce() {
    static $nonce = null;
    if ( $nonce === null ) {
        $nonce = bin2hex( random_bytes( 16 ) );
    }
    return $nonce;
}

/**
 * Disable XML-RPC if not needed
 */
add_filter('xmlrpc_enabled', '__return_false');

/**
 * Remove WordPress version from head
 */
remove_action('wp_head', 'wp_generator');

/**
 * Limit login attempts (additional layer)
 */
/**
 * ROOT-CAUSE FIX: WordPress's 'authenticate' filter passes THREE
 * arguments — ($user, $username, $password), where $user is whatever
 * an earlier-priority authenticate callback already produced (WP core's
 * own username/password check runs at priority 20, so by the time this
 * runs at priority 30, $user is normally already a WP_User on success
 * or a WP_Error on failure — see wp-includes/user.php's wp_authenticate()
 * for the exact chain). This was previously registered with `, 30, 1`
 * (only 1 accepted arg) and declared as `function (...$username)`, so
 * it was actually receiving $user — a WP_Error or WP_User OBJECT, never
 * a string — as its "$username" parameter, then handing that object
 * straight into ridego_check_rate_limit()'s string concatenation
 * (`$action . '|' . $identifier`). PHP 8's stricter object-to-string
 * rules turn that into an uncaught fatal error, so this crashed on
 * EVERY login attempt through wp-login.php, successful or not, the
 * moment this plugin was active — found by testing an actual login
 * against a real local WordPress instance; every prior verification
 * pass (php -l, tsc, the collision scan) is static analysis and cannot
 * catch a runtime type error like this one, since the code is entirely
 * valid PHP syntax.
 *
 * Fixed to accept all 3 arguments (`, 30, 3`), use $username (the real
 * submitted username string, the 2nd argument) for rate-limiting, and
 * — a second latent bug this surfaced — return $user unchanged in the
 * pass-through case instead of null: an 'authenticate' filter that
 * returns null unconditionally silently discards whatever a
 * higher-priority callback already authenticated, which would have
 * broken every successful login even once the crash itself was fixed.
 *
 * ROOT-CAUSE FIX (production audit): this only PEEKS at the lockout
 * state now — it no longer increments the counter itself. The previous
 * version called ridego_check_rate_limit() here directly, which counts
 * every authenticate pass including successful ones (this filter fires
 * on every login attempt regardless of outcome), so a legitimate user
 * logging in repeatedly in a short window could lock themselves out of
 * their own account exactly like a brute-force attacker would. Actually
 * recording an attempt now happens only once the real outcome is known:
 * ridego_record_failed_login() below (on 'wp_login_failed') advances the
 * counter, and ridego_reset_login_attempts() (on 'wp_login') clears it
 * on success. See ridego_peek_rate_limit()'s doc comment for the full
 * rationale.
 */
function ridego_check_login_attempts($user, $username, $password) {

    if (empty($username)) {
        return $user;
    }

    $rate_limit = ridego_peek_rate_limit('login', $username, 5, 900); // 5 FAILED attempts per 15 min

    if (!$rate_limit['allowed']) {
        return new WP_Error('too_many_attempts', __('Too many login attempts. Please try again in 15 minutes.'));
    }

    return $user;
}
add_filter('authenticate', 'ridego_check_login_attempts', 30, 3);

/**
 * Records one failed login attempt toward the per-username lockout.
 * Hooked to 'wp_login_failed', which WordPress fires with the exact
 * submitted username after an authentication attempt did not resolve to
 * a valid user (wrong password, unknown user, etc.) — the only point at
 * which a "failure" is unambiguous, which is why the increment lives
 * here and not in the 'authenticate' filter above (that fires on every
 * attempt, successful ones included).
 */
function ridego_record_failed_login($username) {
    if (empty($username)) {
        return;
    }
    ridego_record_rate_limit_failure('login', $username, 900);
}
add_action('wp_login_failed', 'ridego_record_failed_login', 10, 1);

/**
 * Clears the login-lockout counter for a username after they
 * successfully authenticate, so earlier mistyped-password attempts
 * don't carry forward and count against their next login.
 */
function ridego_reset_login_attempts($user_login, $user = null) {
    ridego_reset_rate_limit('login', $user_login);
}
add_action('wp_login', 'ridego_reset_login_attempts', 10, 2);
