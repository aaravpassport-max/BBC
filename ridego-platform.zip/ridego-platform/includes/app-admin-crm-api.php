<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — back-office CRM and booking desk.
   Routes: /app/admin/clients*, /app/admin/enquiries*, and the booking-desk additions under /app/admin/bookings
   (form-options, quote, create, edit, payments, refund, notes, invoice) plus /app/admin/vendors/:id/assign-options.
   Every route needs a login AND the specific capability named on the route; thin wrappers over clients.php,
   enquiries.php and booking-admin.php so REST, tests and any future screen share one implementation.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_crm_routes' );

// TRACE: rest_api_init → registers every CRM route with its capability gate → void. Preconditions: none. Postconditions: 22 routes on ridego/v1.
//        Edge cases: none (route regexes constrain ids to digits).
function ridego_register_app_admin_crm_routes() {
    $routes = array(
        array( '/app/admin/clients', 'GET', 'ridego_crm_clients_list', 'ridego_manage_clients' ),
        array( '/app/admin/clients', 'POST', 'ridego_crm_clients_create', 'ridego_manage_clients' ),
        array( '/app/admin/clients/lookup', 'GET', 'ridego_crm_clients_lookup', 'ridego_manage_clients' ),
        array( '/app/admin/clients/check-duplicate', 'POST', 'ridego_crm_clients_check_duplicate', 'ridego_manage_clients' ),
        array( '/app/admin/clients/(?P<id>\d+)', 'GET', 'ridego_crm_clients_get', 'ridego_manage_clients' ),
        array( '/app/admin/clients/(?P<id>\d+)', 'PUT,PATCH', 'ridego_crm_clients_update', 'ridego_manage_clients' ),
        array( '/app/admin/clients/(?P<id>\d+)/status', 'POST', 'ridego_crm_clients_status', 'ridego_manage_clients' ),
        array( '/app/admin/clients/(?P<id>\d+)/merge', 'POST', 'ridego_crm_clients_merge', 'ridego_manage_clients' ),
        array( '/app/admin/enquiries', 'GET', 'ridego_crm_enquiries_list', 'ridego_manage_enquiries' ),
        array( '/app/admin/enquiries', 'POST', 'ridego_crm_enquiries_create', 'ridego_manage_enquiries' ),
        array( '/app/admin/enquiries/(?P<id>\d+)', 'PUT,PATCH', 'ridego_crm_enquiries_update', 'ridego_manage_enquiries' ),
        array( '/app/admin/enquiries/(?P<id>\d+)/prefill', 'GET', 'ridego_crm_enquiries_prefill', 'ridego_manage_enquiries' ),
        array( '/app/admin/bookings/form-options', 'GET', 'ridego_crm_booking_form_options', 'ridego_create_admin_booking' ),
        array( '/app/admin/bookings/quote', 'POST', 'ridego_crm_booking_quote', 'ridego_create_admin_booking' ),
        array( '/app/admin/bookings/create', 'POST', 'ridego_crm_booking_create', 'ridego_create_admin_booking' ),
        array( '/app/admin/bookings/(?P<id>\d+)/edit', 'POST,PUT', 'ridego_crm_booking_edit', 'ridego_edit_booking_details' ),
        array( '/app/admin/bookings/(?P<id>\d+)/payments', 'POST', 'ridego_crm_booking_record_payment', 'ridego_record_payments' ),
        array( '/app/admin/bookings/(?P<id>\d+)/vendor-collection', 'POST', 'ridego_crm_booking_vendor_collection', 'ridego_record_payments' ),
        array( '/app/admin/bookings/(?P<id>\d+)/refund', 'POST', 'ridego_crm_booking_refund', array( 'ridego_record_payments', 'ridego_process_refunds' ) ),
        array( '/app/admin/bookings/(?P<id>\d+)/notes', 'GET', 'ridego_crm_booking_notes_get', 'ridego_manage_bookings' ),
        array( '/app/admin/bookings/(?P<id>\d+)/notes', 'POST', 'ridego_crm_booking_notes_add', 'ridego_manage_bookings' ),
        array( '/app/admin/bookings/(?P<id>\d+)/notes/(?P<note_id>\d+)', 'POST,PUT', 'ridego_crm_booking_notes_edit', 'ridego_manage_bookings' ),
        array( '/app/admin/bookings/(?P<id>\d+)/notes/(?P<note_id>\d+)', 'DELETE', 'ridego_crm_booking_notes_delete', 'ridego_manage_bookings' ),
        array( '/app/admin/bookings/(?P<id>\d+)/invoice', 'GET', 'ridego_crm_booking_invoice', 'ridego_manage_bookings' ),
        array( '/app/admin/vendors/(?P<id>\d+)/assign-options', 'GET', 'ridego_crm_vendor_assign_options', 'ridego_assign_vendor' ),
    );
    foreach ( $routes as $r ) {
        register_rest_route( 'ridego/v1', $r[0], array( 'methods' => $r[1], 'callback' => $r[2], 'permission_callback' => ridego_crm_permission( $r[3] ) ) );
    }
}

// TRACE: capability name (or list: any one suffices) → permission callback closure → 401 when logged out, 403 when the user holds none of the caps, true otherwise.
function ridego_crm_permission( $caps ) {
    $caps = (array) $caps;
    return function () use ( $caps ) {
        if ( ! is_user_logged_in() ) { return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) ); }
        foreach ( $caps as $c ) { if ( ridego_can( $c ) ) { return true; } }
        return new WP_Error( 'forbidden', 'You do not have permission to do that.', array( 'status' => 403 ) );
    };
}

// TRACE: request → JSON body as array ({} → array()). Pure.
function ridego_crm_body( WP_REST_Request $req ) { $j = $req->get_json_params(); return is_array( $j ) ? $j : array(); }

// TRACE: domain result → REST response (success) or WP_Error with the domain message; duplicates and other coded failures use 409/400 and carry `duplicate` in data → mixed.
function ridego_crm_result( $r ) {
    if ( is_array( $r ) && ! empty( $r['success'] ) ) { return rest_ensure_response( $r ); }
    $status = ( is_array( $r ) && ( ( $r['code'] ?? '' ) === 'duplicate_client' || ( $r['code'] ?? '' ) === 'duplicate_booking' || ! empty( $r['duplicate'] ) ) ) ? 409 : 400;
    return new WP_Error( is_array( $r ) && ! empty( $r['code'] ) ? $r['code'] : 'request_failed', is_array( $r ) && ! empty( $r['message'] ) ? $r['message'] : 'The request could not be completed.',
        array( 'status' => $status, 'duplicate' => is_array( $r ) ? ( $r['duplicate'] ?? null ) : null ) );
}

// TRACE: GET clients {q,type,status,source,sort,order,page,per_page} → ridego_client_list() → {rows,total,page,per_page}.
function ridego_crm_clients_list( WP_REST_Request $req ) {
    return rest_ensure_response( ridego_client_list( array( 'q' => $req['q'], 'type' => $req['type'], 'status' => $req['status'], 'source' => $req['source'], 'sort' => $req['sort'], 'order' => $req['order'], 'page' => $req['page'], 'per_page' => $req['per_page'] ) ) );
}

// TRACE: GET clients/lookup?q= → up to 10 matching clients for a picker (needs ≥2 characters) → {rows}. Edge cases: short query → empty rows.
function ridego_crm_clients_lookup( WP_REST_Request $req ) {
    $q = trim( (string) $req['q'] );
    if ( mb_strlen( $q ) < 2 ) { return rest_ensure_response( array( 'rows' => array() ) ); }
    $r = ridego_client_list( array( 'q' => $q, 'per_page' => 10, 'status' => '' ) );
    return rest_ensure_response( array( 'rows' => $r['rows'] ) );
}

// TRACE: POST clients/check-duplicate {phone,email,exclude_id} → {matches:[summary]} so forms can warn before saving. Pure read.
function ridego_crm_clients_check_duplicate( WP_REST_Request $req ) {
    $b = ridego_crm_body( $req );
    $m = ridego_client_find_matches( (string) ( $b['phone'] ?? '' ), (string) ( $b['email'] ?? '' ), (int) ( $b['exclude_id'] ?? 0 ) );
    return rest_ensure_response( array( 'matches' => array_map( 'ridego_client_summary', $m ) ) );
}

// TRACE: POST clients {name,phone,...} → ridego_client_create() → {success,id,message} | 409 with `duplicate` | 400.
function ridego_crm_clients_create( WP_REST_Request $req ) {
    $b = ridego_crm_body( $req );
    return ridego_crm_result( ridego_client_create( $b, get_current_user_id(), ! empty( $b['allow_email_duplicate'] ) ) );
}

// TRACE: GET clients/:id → full profile bundle (profile, stats, bookings, payments, enquiries, complaints) | 404.
function ridego_crm_clients_get( WP_REST_Request $req ) {
    $p = ridego_client_profile( (int) $req['id'] );
    return $p ? rest_ensure_response( $p ) : new WP_Error( 'not_found', 'Client not found.', array( 'status' => 404 ) );
}

// TRACE: PUT clients/:id → ridego_client_update() → {success,message} | 409 duplicate | 400 | 404.
function ridego_crm_clients_update( WP_REST_Request $req ) {
    if ( ! ridego_client_get( (int) $req['id'] ) ) { return new WP_Error( 'not_found', 'Client not found.', array( 'status' => 404 ) ); }
    return ridego_crm_result( ridego_client_update( (int) $req['id'], ridego_crm_body( $req ), get_current_user_id() ) );
}

// TRACE: POST clients/:id/status {status: active|blocked, reason} → ridego_client_set_status() → response | 400 | 404.
function ridego_crm_clients_status( WP_REST_Request $req ) {
    if ( ! ridego_client_get( (int) $req['id'] ) ) { return new WP_Error( 'not_found', 'Client not found.', array( 'status' => 404 ) ); }
    $b = ridego_crm_body( $req );
    return ridego_crm_result( ridego_client_set_status( (int) $req['id'], sanitize_key( (string) ( $b['status'] ?? '' ) ), (string) ( $b['reason'] ?? '' ), get_current_user_id() ) );
}

// TRACE: POST clients/:id/merge {into} → ridego_client_merge(into, id) — :id in the URL is the profile being retired (the LOSER), 'into' is the profile to keep (the WINNER) → response | 400 | 404.
//        Chosen this way round (rather than {from}) so the merge action lives on the duplicate/junk profile's own page: "merge this into that one", matching how an admin actually discovers the duplicate.
function ridego_crm_clients_merge( WP_REST_Request $req ) {
    if ( ! ridego_client_get( (int) $req['id'] ) ) { return new WP_Error( 'not_found', 'Client not found.', array( 'status' => 404 ) ); }
    $b = ridego_crm_body( $req );
    return ridego_crm_result( ridego_client_merge( (int) ( $b['into'] ?? 0 ), (int) $req['id'], get_current_user_id() ) );
}

// TRACE: GET enquiries {status,q,overdue,page,per_page} → {rows,total,counts}.
function ridego_crm_enquiries_list( WP_REST_Request $req ) {
    return rest_ensure_response( ridego_enquiry_list( array( 'status' => $req['status'], 'q' => $req['q'], 'overdue' => $req['overdue'], 'page' => $req['page'], 'per_page' => $req['per_page'] ) ) );
}
// TRACE: POST enquiries → ridego_enquiry_create() → {success,id} | 400.
function ridego_crm_enquiries_create( WP_REST_Request $req ) { return ridego_crm_result( ridego_enquiry_create( ridego_crm_body( $req ), get_current_user_id() ) ); }
// TRACE: PUT enquiries/:id → ridego_enquiry_update() → response | 400.
function ridego_crm_enquiries_update( WP_REST_Request $req ) { return ridego_crm_result( ridego_enquiry_update( (int) $req['id'], ridego_crm_body( $req ), get_current_user_id() ) ); }
// TRACE: GET enquiries/:id/prefill → booking-form prefill payload | 404.
function ridego_crm_enquiries_prefill( WP_REST_Request $req ) {
    $p = ridego_enquiry_prefill( (int) $req['id'] );
    return $p ? rest_ensure_response( $p ) : new WP_Error( 'not_found', 'Enquiry not found.', array( 'status' => 404 ) );
}

// TRACE: GET bookings/form-options → everything the booking desk needs to render its selects: active vehicle types, active cities, trip types, sources, payment methods,
//        vendors (active) with their type, and the advance-notice setting → object. Pure read.
function ridego_crm_booking_form_options( WP_REST_Request $req ) {
    global $wpdb;
    $veh = $wpdb->get_results( "SELECT id, name, seating_capacity FROM {$wpdb->prefix}ridego_vehicles WHERE is_active=1 ORDER BY name" );
    $cities = $wpdb->get_col( "SELECT name FROM {$wpdb->prefix}ridego_cities WHERE is_active=1 ORDER BY name" );
    $vendors = $wpdb->get_results( "SELECT id, business_name, phone, city, vendor_type FROM {$wpdb->prefix}ridego_vendors WHERE status='active' ORDER BY business_name LIMIT 300" );
    return rest_ensure_response( array(
        'vehicle_types' => array_map( function ( $v ) { return array( 'id' => (int) $v->id, 'name' => $v->name, 'seats' => (int) $v->seating_capacity ); }, (array) $veh ),
        'cities' => array_values( (array) $cities ),
        'trip_types' => ridego_admin_trip_types(), 'sources' => array_values( array_diff( ridego_booking_sources(), array( 'online' ) ) ), 'payment_methods' => ridego_payment_methods(),
        'vendors' => array_map( function ( $v ) { return array( 'id' => (int) $v->id, 'name' => $v->business_name, 'phone' => $v->phone, 'city' => $v->city, 'vendor_type' => $v->vendor_type ?: 'individual' ); }, (array) $vendors ),
        'advance_hours' => (int) ridego_get_setting( 'booking_advance_hours', 2 ),
    ) );
}

// TRACE: POST bookings/quote → ridego_admin_booking_quote() → {trip,fare,warnings} | 400. Never writes.
function ridego_crm_booking_quote( WP_REST_Request $req ) { return ridego_crm_result( ridego_admin_booking_quote( ridego_crm_body( $req ) ) ); }

// TRACE: POST bookings/create → ridego_admin_create_booking() → {booking_id,booking_number,...} | 409 duplicate client/booking | 400.
function ridego_crm_booking_create( WP_REST_Request $req ) { return ridego_crm_result( ridego_admin_create_booking( ridego_crm_body( $req ), get_current_user_id() ) ); }

// TRACE: POST bookings/:id/edit → ridego_admin_update_booking() → {changes,rescheduled} | 400. 404 when the booking does not exist.
function ridego_crm_booking_edit( WP_REST_Request $req ) {
    if ( ! ridego_get_booking( (int) $req['id'] ) ) { return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) ); }
    return ridego_crm_result( ridego_admin_update_booking( (int) $req['id'], ridego_crm_body( $req ), get_current_user_id() ) );
}

// TRACE: POST bookings/:id/payments {amount,method,reference,note} → ridego_booking_record_payment() → response | 400.
function ridego_crm_booking_record_payment( WP_REST_Request $req ) {
    $b = ridego_crm_body( $req );
    return ridego_crm_result( ridego_booking_record_payment( (int) $req['id'], $b['amount'] ?? 0, (string) ( $b['method'] ?? '' ), (string) ( $b['reference'] ?? '' ), (string) ( $b['note'] ?? '' ), get_current_user_id() ) );
}

// TRACE: POST bookings/:id/vendor-collection {amount,method,reference,note,vendor_invoice} → records, on the vendor's behalf, ride money the vendor/driver reports collecting directly from the client
//        via ridego_booking_record_vendor_collection() (informational ledger row, never counted as RideGo money) → response | 400 (over-collection, cancelled, no vendor).
function ridego_crm_booking_vendor_collection( WP_REST_Request $req ) {
    $b = ridego_crm_body( $req );
    return ridego_crm_result( ridego_booking_record_vendor_collection( (int) $req['id'], $b['amount'] ?? 0, (string) ( $b['method'] ?? '' ), (string) ( $b['reference'] ?? '' ), (string) ( $b['note'] ?? '' ), 'admin', get_current_user_id(), (string) ( $b['vendor_invoice'] ?? '' ) ) );
}

// TRACE: POST bookings/:id/refund {amount,method,reference,note} → ridego_booking_record_refund() → response | 400.
function ridego_crm_booking_refund( WP_REST_Request $req ) {
    $b = ridego_crm_body( $req );
    return ridego_crm_result( ridego_booking_record_refund( (int) $req['id'], $b['amount'] ?? 0, (string) ( $b['method'] ?? '' ), (string) ( $b['reference'] ?? '' ), (string) ( $b['note'] ?? '' ), get_current_user_id() ) );
}

// TRACE: GET bookings/:id/notes → {rows} (internal + client-visible) | 404.
function ridego_crm_booking_notes_get( WP_REST_Request $req ) {
    if ( ! ridego_get_booking( (int) $req['id'] ) ) { return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) ); }
    return rest_ensure_response( array( 'rows' => ridego_booking_get_notes( (int) $req['id'] ) ) );
}

// TRACE: POST bookings/:id/notes {note,visibility} → ridego_booking_add_note() → response | 400.
function ridego_crm_booking_notes_add( WP_REST_Request $req ) {
    $b = ridego_crm_body( $req );
    return ridego_crm_result( ridego_booking_add_note( (int) $req['id'], (string) ( $b['note'] ?? '' ), (string) ( $b['visibility'] ?? 'internal' ), get_current_user_id() ) );
}

// TRACE: POST/PUT bookings/:id/notes/:note_id {note} → ridego_booking_edit_note() → response | 400|404.
function ridego_crm_booking_notes_edit( WP_REST_Request $req ) {
    $b = ridego_crm_body( $req );
    return ridego_crm_result( ridego_booking_edit_note( (int) $req['note_id'], (string) ( $b['note'] ?? '' ), get_current_user_id() ) );
}

// TRACE: DELETE bookings/:id/notes/:note_id → ridego_booking_delete_note() (soft delete) → response | 404.
function ridego_crm_booking_notes_delete( WP_REST_Request $req ) {
    return ridego_crm_result( ridego_booking_delete_note( (int) $req['note_id'], get_current_user_id() ) );
}

// TRACE: GET bookings/:id/invoice → ridego_booking_invoice_data() → invoice object | 404.
function ridego_crm_booking_invoice( WP_REST_Request $req ) {
    $d = ridego_booking_invoice_data( (int) $req['id'] );
    return $d ? rest_ensure_response( $d ) : new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
}

// TRACE: GET vendors/:id/assign-options → active drivers (with profile_complete + missing) and active vehicles of that vendor for the booking desk → {vendor_type,drivers,vehicles} | 404.
//        Individual vendors are lazily provisioned so their single driver/vehicle can be picked. Edge cases: unknown vendor (404).
function ridego_crm_vendor_assign_options( WP_REST_Request $req ) {
    $v = ridego_get_vendor( (int) $req['id'] );
    if ( ! $v ) { return new WP_Error( 'not_found', 'Vendor not found.', array( 'status' => 404 ) ); }
    if ( ridego_get_vendor_type( $v ) === 'individual' ) { ridego_ensure_individual_provisioned( $v->id ); }
    $drivers = array_map( function ( $d ) { $m = ridego_driver_missing_fields( $d ); return array( 'id' => (int) $d->id, 'name' => $d->name, 'mobile' => $d->mobile, 'profile_complete' => ! $m, 'profile_missing' => $m ); }, ridego_get_fleet_drivers( $v->id, 'active' ) );
    $veh = array_map( function ( $x ) { return array( 'id' => (int) $x->id, 'label' => trim( $x->make_model . ' ' . $x->registration_number ), 'registration_number' => $x->registration_number, 'vehicle_type_id' => (int) $x->vehicle_type_id ); }, ridego_get_fleet_vehicles( $v->id, 'active' ) );
    return rest_ensure_response( array( 'vendor_type' => ridego_get_vendor_type( $v ), 'drivers' => $drivers, 'vehicles' => $veh ) );
}
