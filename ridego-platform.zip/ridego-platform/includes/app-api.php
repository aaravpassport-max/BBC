<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App API — the API surface for the standalone React/TS/Vite
   frontend (see includes/app-shell.php for how that frontend is
   served). This is a SEPARATE namespace concern from includes/
   rest-api.php (that file is the authenticated partner/BI surface,
   Application-Password-gated). This one is the plugin's own
   first-party frontend talking to its own backend.

   Auth model: WordPress cookie authentication (the visitor's normal
   wp-login session), the same session the user gets from any other
   part of WordPress. State-changing requests must carry an
   `X-WP-Nonce` header with a nonce created via `wp_create_nonce(
   'wp_rest' )` — WP core's own `rest_cookie_check_errors()` verifies
   this automatically for every cookie-authenticated REST request,
   so no custom nonce-check code is needed here; the app shell
   (includes/app-shell.php) is what hands the nonce to the JS app on
   page load. No JWT, no separate token store — reusing WP's own
   session exactly like every other logged-in WP page.

   Every route lives under the existing `ridego/v1` namespace, at
   the `/app/...` sub-path, to keep it clearly separated from both
   the partner REST API and the Razorpay webhook route.
   ================================================================ */

/* ----------------------------------------------------------------
   Same-request nonce/session sync.

   wp_create_nonce('wp_rest') binds the nonce to wp_get_session_token(),
   which is read from $_COOKIE (wp_get_session_token() ->
   wp_parse_auth_cookie('', 'logged_in') parses $_COOKIE directly, not
   the Set-Cookie header this response is about to send). Right after
   login/registration, wp_set_auth_cookie() sends that cookie to the
   BROWSER via a response header, but $_COOKIE in this still-running
   PHP process is unchanged — it still reflects the pre-login request
   (empty, for a first-time visitor). So a nonce minted in the same
   response as ridego_app_api_auth_login()/_register() was bound to an
   empty session token, while every later request from the browser
   (which now actually sends the cookie) resolves a real, non-empty
   token — the hash never matches and every subsequent authenticated
   GET fails with `rest_cookie_invalid_nonce`, forever, until the user
   reloads the page (which mints a fresh, correctly-bound nonce via a
   normal page load). That reload workaround masked this for a page
   load, but a same-page-app login never got a workable nonce.

   Fix: mirror the cookie value WordPress just generated into $_COOKIE
   for the rest of this request, via the 'set_logged_in_cookie' action
   that wp_set_auth_cookie() already fires with the exact string it
   sent. Once $_COOKIE reflects the real session, any nonce created
   later in the same request is bound to the same token every later
   request will see, and rest_cookie_check_errors() accepts it.
   ---------------------------------------------------------------- */
add_action( 'set_logged_in_cookie', function ( $logged_in_cookie ) {
    $_COOKIE[ LOGGED_IN_COOKIE ] = $logged_in_cookie;
}, 10, 1 );

add_action( 'rest_api_init', 'ridego_register_app_api_routes' );
function ridego_register_app_api_routes() {

    /* ---------------------------------------------------------
       AUTH
       --------------------------------------------------------- */
    register_rest_route( 'ridego/v1', '/app/auth/me', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_auth_me',
        'permission_callback' => '__return_true', // public: returns guest shape when logged out
    ) );

    register_rest_route( 'ridego/v1', '/app/auth/login', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_auth_login',
        'permission_callback' => '__return_true',
        'args'                => array(
            'login'    => array( 'required' => true, 'type' => 'string' ),
            'password' => array( 'required' => true, 'type' => 'string' ),
        ),
    ) );

    register_rest_route( 'ridego/v1', '/app/auth/register', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_auth_register',
        'permission_callback' => '__return_true',
        'args'                => array(
            'name'     => array( 'required' => true, 'type' => 'string' ),
            'email'    => array( 'required' => true, 'type' => 'string' ),
            'phone'    => array( 'required' => true, 'type' => 'string' ),
            'password' => array( 'required' => true, 'type' => 'string' ),
            'as_vendor'=> array( 'required' => false, 'type' => 'boolean', 'default' => false ),
        ),
    ) );

    register_rest_route( 'ridego/v1', '/app/auth/logout', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_auth_logout',
        'permission_callback' => 'is_user_logged_in',
    ) );

    /* ---------------------------------------------------------
       PUBLIC CONTENT / DATA — reuse the exact same canonical
       helpers the WordPress-shortcode frontend uses, so the React
       app and the (legacy, being phased out) shortcode pages can
       never drift apart on what counts as "the real data."
       --------------------------------------------------------- */
    register_rest_route( 'ridego/v1', '/app/home', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_home',
        'permission_callback' => '__return_true',
    ) );

    register_rest_route( 'ridego/v1', '/app/cities', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_cities',
        'permission_callback' => '__return_true',
    ) );

    register_rest_route( 'ridego/v1', '/app/maps-config', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_maps_config',
        'permission_callback' => '__return_true',
    ) );

    register_rest_route( 'ridego/v1', '/app/vehicles', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_vehicles',
        'permission_callback' => '__return_true',
    ) );

    register_rest_route( 'ridego/v1', '/routes/(?P<slug>[a-z0-9-]+)', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_route_page_by_slug',
        'permission_callback' => '__return_true',
    ) );

    // /routes/ index page — real listing of every PUBLISHED route page, used
    // by the SPA's RoutesIndexPage. Registered AFTER the single-slug route
    // above only for readability; WP_REST_Server matches the more specific
    // '(?P<slug>...)' pattern for an actual slug and this one only matches
    // when no slug segment follows, so there's no route collision either way.
    register_rest_route( 'ridego/v1', '/routes', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_route_pages_index',
        'permission_callback' => '__return_true',
    ) );

    // Home page "Popular outstation routes" — real origin→destination pairs, only
    // from PUBLISHED route marketing pages (see ridego_app_api_route_page_by_slug's
    // docblock for why: draft/needs_review pages are never surfaced publicly), with
    // real distance-based starting fares from ridego_get_route_fixed_price(). Never
    // fabricated example routes/prices.
    register_rest_route( 'ridego/v1', '/app/popular-routes', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_popular_routes',
        'permission_callback' => '__return_true',
    ) );

    // Home page "Meet the partners" — real active + KYC-verified vendor records
    // only. Rating/journey-count are included only when the vendor genuinely has
    // them (total_ratings > 0 / total_rides_completed > 0) — never a fabricated
    // "New" rating dressed up as a real one.
    register_rest_route( 'ridego/v1', '/app/partners', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_partners',
        'permission_callback' => '__return_true',
    ) );

    register_rest_route( 'ridego/v1', '/app/fare', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_fare',
        'permission_callback' => '__return_true', // rate-limited below, not auth-gated: matches booking-ajax's live fare preview
    ) );

    /* ---------------------------------------------------------
       OTP — phone verification, shared by the booking flow and any
       other guest-identity-proving action. Delegates entirely to
       the canonical includes/otp.php functions, so the app and the
       legacy AJAX flow share one rate limit, one attempt counter,
       and (after the Wave 9 fix) one trusted-device cookie scheme.
       --------------------------------------------------------- */
    register_rest_route( 'ridego/v1', '/app/otp/send', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_otp_send',
        'permission_callback' => '__return_true',
    ) );

    register_rest_route( 'ridego/v1', '/app/otp/verify', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_otp_verify',
        'permission_callback' => '__return_true',
    ) );

    /* ---------------------------------------------------------
       BOOKINGS (customer)
       --------------------------------------------------------- */
    register_rest_route( 'ridego/v1', '/app/bookings', array(
        'methods'             => array( 'GET', 'POST' ),
        'callback'            => 'ridego_app_api_bookings_collection',
        'permission_callback' => 'ridego_app_api_bookings_collection_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/bookings/(?P<id>\d+)/cancel', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_cancel_booking',
        'permission_callback' => 'is_user_logged_in',
    ) );

    // Public-ish lookup by booking_number, used by the confirmation/
    // payment page — but never returns anything unless the requester
    // is verified as the booking's owner (see ridego_get_booking_
    // payment_context()'s own doc comment). A guest reaches this
    // right after booking, while their OTP-verified session/trust
    // cookie from includes/otp.php is still fresh.
    register_rest_route( 'ridego/v1', '/app/bookings/lookup', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_booking_lookup',
        'permission_callback' => '__return_true',
    ) );

    register_rest_route( 'ridego/v1', '/app/bookings/(?P<id>\d+)/payment-proof', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_submit_payment_proof',
        'permission_callback' => '__return_true', // ownership verified inside, same as the legacy AJAX handler
    ) );

    // Rate a completed trip. Ownership is verified inside
    // ridego_rate_booking() itself (client_id match or admin), the same
    // canonical function the legacy dashboard uses — no divergent copy.
    register_rest_route( 'ridego/v1', '/app/bookings/(?P<id>\d+)/rate', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_rate_booking',
        'permission_callback' => 'is_user_logged_in',
    ) );

    /* ---------------------------------------------------------
       VENDOR
       --------------------------------------------------------- */
    register_rest_route( 'ridego/v1', '/app/vendor/me', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_vendor_me',
        'permission_callback' => 'is_user_logged_in',
    ) );

    register_rest_route( 'ridego/v1', '/app/vendor/leads', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_vendor_leads',
        'permission_callback' => 'is_user_logged_in',
    ) );

    register_rest_route( 'ridego/v1', '/app/vendor/leads/(?P<id>\d+)/accept', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_vendor_accept_lead',
        'permission_callback' => 'is_user_logged_in',
    ) );

    register_rest_route( 'ridego/v1', '/app/vendor/leads/(?P<id>\d+)/reject', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_vendor_reject_lead',
        'permission_callback' => 'is_user_logged_in',
    ) );

    register_rest_route( 'ridego/v1', '/app/vendor/bookings/(?P<id>\d+)/advance', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_vendor_advance_trip',
        'permission_callback' => 'is_user_logged_in',
    ) );

    // Fills the gap surfaced in Wave 9: an already-logged-in customer
    // account had no way to add a vendor profile — only brand-new
    // registration supported the as_vendor flag.
    register_rest_route( 'ridego/v1', '/app/vendor/onboard', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_vendor_onboard',
        'permission_callback' => 'is_user_logged_in',
    ) );

    register_rest_route( 'ridego/v1', '/app/vendor/docs', array(
        'methods'             => array( 'GET', 'POST' ),
        'callback'            => 'ridego_app_api_vendor_docs_collection',
        'permission_callback' => 'is_user_logged_in',
    ) );

    register_rest_route( 'ridego/v1', '/app/vendor/docs/(?P<id>\d+)/file', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_vendor_doc_file',
        'permission_callback' => 'is_user_logged_in',
    ) );

    // Full paginated/filterable trip history for the logged-in vendor,
    // beyond the "sent leads" list on the dashboard — built on the same
    // canonical ridego_query_bookings() the admin bookings list already
    // uses, just scoped to this vendor's own vendor_id.
    register_rest_route( 'ridego/v1', '/app/vendor/bookings', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_vendor_bookings',
        'permission_callback' => 'is_user_logged_in',
    ) );

    /* ---------------------------------------------------------
       PROFILE / ACCOUNT — any logged-in user (client or vendor).
       --------------------------------------------------------- */
    register_rest_route( 'ridego/v1', '/app/profile', array(
        'methods'             => array( 'GET', 'POST' ),
        'callback'            => 'ridego_app_api_profile_collection',
        'permission_callback' => 'is_user_logged_in',
    ) );

    register_rest_route( 'ridego/v1', '/app/profile/password', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_change_password',
        'permission_callback' => 'is_user_logged_in',
    ) );

    /* ---------------------------------------------------------
       NOTIFICATIONS — the in-app inbox, backed by
       ridego_notifications (see migration 008 and the
       ridego_log_notification() fix in includes/notifications.php).
       --------------------------------------------------------- */
    register_rest_route( 'ridego/v1', '/app/notifications', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_notifications',
        'permission_callback' => 'is_user_logged_in',
    ) );

    register_rest_route( 'ridego/v1', '/app/notifications/(?P<id>\d+)/read', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_notification_read',
        'permission_callback' => 'is_user_logged_in',
    ) );

    register_rest_route( 'ridego/v1', '/app/notifications/read-all', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_api_notifications_read_all',
        'permission_callback' => 'is_user_logged_in',
    ) );

    /* ---------------------------------------------------------
       TRANSACTIONS — the logged-in customer's own payment/refund
       history, backed by ridego_transactions (joined through
       ridego_bookings for ownership scoping — the transactions
       table itself has no client_id column, only booking_id).
       --------------------------------------------------------- */
    register_rest_route( 'ridego/v1', '/app/transactions', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_transactions',
        'permission_callback' => 'is_user_logged_in',
    ) );

    /* ---------------------------------------------------------
       REVIEWS — a public feed of genuine customer reviews (the
       same rating_by_client/review_by_client columns MyTripsPage's
       rating flow writes to), for social proof on a browsable
       reviews page. Public/no-login, same as /app/home.
       --------------------------------------------------------- */
    register_rest_route( 'ridego/v1', '/app/reviews', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_api_reviews',
        'permission_callback' => '__return_true',
    ) );
}

/* ============================================================
   AUTH HANDLERS
   ============================================================ */

// TRACE: auth/me and login → builds the SPA auth payload including vendor_type and the impersonation banner state → array.
//        Preconditions: none → Postconditions: pure reads → Edge cases: logged out (nonce only), not impersonating (impersonation null).
function ridego_app_api_current_user_payload() {
    if ( ! is_user_logged_in() ) {
        return array(
            'logged_in' => false,
            'nonce'     => wp_create_nonce( 'wp_rest' ),
        );
    }
    $uid    = get_current_user_id();
    $user   = wp_get_current_user();
    $vendor = ridego_get_vendor_by_user( $uid );

    return array(
        'logged_in' => true,
        'nonce'     => wp_create_nonce( 'wp_rest' ),
        'user'      => array(
            'id'         => $uid,
            'name'       => $user->display_name,
            'email'      => $user->user_email,
            'phone'      => get_user_meta( $uid, 'ridego_phone', true ),
            'roles'      => array_values( $user->roles ),
            'is_admin'   => current_user_can( 'manage_options' ),
            'admin_caps' => ridego_app_api_admin_caps_list(),
            'is_vendor'  => (bool) $vendor,
            'vendor_id'  => $vendor ? (int) $vendor->id : null,
            'vendor_status' => $vendor ? $vendor->status : null,
            'vendor_type'   => $vendor && function_exists( 'ridego_get_vendor_type' ) ? ridego_get_vendor_type( $vendor ) : null,
            'region_limited' => function_exists( 'ridego_region_scope_cities' ) && ridego_region_scope_cities() !== null,
            'team_modules'  => array_values( (array) get_user_meta( $uid, 'ridego_team_modules', true ) ),
        ),
        'impersonation' => function_exists( 'ridego_impersonation_payload' ) ? ridego_impersonation_payload() : null,
    );
}

/**
 * Root-cause fix for the caveat flagged since Waves 17-21: the
 * client-side admin nav/route guard used to check only WordPress's
 * coarse manage_options-derived is_admin flag, which is false for
 * the granular ridego_manager/ridego_admin roles (includes/roles.php)
 * — meaning a manager or admin assigned one of those roles instead
 * of full WP "administrator" could hit every REST endpoint the
 * server-side ridego_can() checks already allow, but the React app
 * itself showed them zero admin nav links and bounced them off
 * RequireAdmin's "Not authorized" screen. This list is the plain,
 * unaudited current_user_can() check for each RideGo capability that
 * gates an admin screen — no ridego_super_admin bypass here, since a
 * WP administrator already holds every one of these caps directly
 * (see the $super_caps grant in ridego_register_roles()), so no
 * audit-log noise is generated just from loading this list on every
 * page.
 */
// TRACE: auth/me → lists the admin capabilities the current user holds, including the marketplace capabilities → array of strings.
//        Preconditions: none → Postconditions: pure → Edge cases: no caps (empty).
function ridego_app_api_admin_caps_list() {
    $caps = array(
        'ridego_manage_vendors', 'ridego_manage_bookings', 'ridego_manage_pricing',
        'ridego_manage_promo_codes', 'ridego_view_reports', 'ridego_view_financial',
        'ridego_manage_complaints', 'ridego_manage_subscriptions', 'ridego_view_audit_log',
        // Added alongside the new Settings and Notifications-broadcast admin
        // screens (app-admin-settings-api.php / app-admin-notifications-api.php)
        // so a ridego_manager/ridego_admin role — not just a full WP
        // administrator — sees those nav links too, consistent with every
        // other admin capability already tracked here.
        'ridego_manage_settings', 'ridego_send_bulk_message',
    );
    if ( function_exists( 'ridego_marketplace_admin_cap_names' ) ) {
        $caps = array_merge( $caps, ridego_marketplace_admin_cap_names() );
    }
    $granted = array();
    foreach ( $caps as $cap ) {
        if ( current_user_can( $cap ) ) {
            $granted[] = $cap;
        }
    }
    return $granted;
}

function ridego_app_api_auth_me( WP_REST_Request $req ) {
    return rest_ensure_response( ridego_app_api_current_user_payload() );
}

function ridego_app_api_auth_login( WP_REST_Request $req ) {
    $login = sanitize_text_field( $req->get_param( 'login' ) );
    $pass  = (string) $req->get_param( 'password' );

    // Same brute-force protection already used for the OTP/booking
    // endpoints — keyed by IP since a not-yet-authenticated login
    // attempt has no user id to key on.
    //
    // ROOT-CAUSE FIX (production audit): this used to call
    // ridego_check_rate_limit() directly, which increments on every
    // call including successful logins — the SPA's own login screen is
    // this endpoint, so any user (or this audit's own repeated test
    // logins) hitting it 10+ times in 10 minutes with the CORRECT
    // password would still get locked out. Peek here (no increment),
    // then only record a failure below if wp_signon() actually fails,
    // or reset the bucket on success — mirroring the same fix applied
    // to the WordPress-native login path in includes/security.php.
    $login_ip = isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
    $rl = ridego_peek_rate_limit( 'app_login', $login_ip, 10, 600 );
    if ( empty( $rl['allowed'] ) ) {
        return new WP_Error( 'rate_limited', 'Too many login attempts. Please try again in a few minutes.', array( 'status' => 429 ) );
    }

    $user = wp_signon( array( 'user_login' => $login, 'user_password' => $pass, 'remember' => true ), is_ssl() );
    if ( is_wp_error( $user ) ) {
        ridego_record_rate_limit_failure( 'app_login', $login_ip, 600 );
        return new WP_Error( 'login_failed', 'Incorrect email/phone or password.', array( 'status' => 401 ) );
    }
    ridego_reset_rate_limit( 'app_login', $login_ip );
    wp_set_current_user( $user->ID );
    ridego_audit_log( 'app_login', 'user', $user->ID, '', '', 'info' );
    return rest_ensure_response( ridego_app_api_current_user_payload() );
}

function ridego_app_api_auth_register( WP_REST_Request $req ) {
    $name      = sanitize_text_field( $req->get_param( 'name' ) );
    $email     = sanitize_email( $req->get_param( 'email' ) );
    $phone     = ridego_sanitize_phone( $req->get_param( 'phone' ) );
    $password  = (string) $req->get_param( 'password' );
    $as_vendor = (bool) $req->get_param( 'as_vendor' );
    // ridego_create_vendor() (includes/vendor.php) requires a city — it's
    // used for lead-matching from day one, not something that can be
    // filled in later — so a vendor signup must supply one.
    $city      = sanitize_text_field( $req->get_param( 'city' ) );

    if ( ! $name || ! is_email( $email ) || ! $phone || strlen( $password ) < 8 ) {
        return new WP_Error( 'invalid_input', 'Please provide a valid name, email, phone and a password of at least 8 characters.', array( 'status' => 400 ) );
    }
    if ( $as_vendor && ! $city ) {
        return new WP_Error( 'invalid_input', 'Please tell us which city you operate in.', array( 'status' => 400 ) );
    }
    if ( email_exists( $email ) ) {
        return new WP_Error( 'email_exists', 'An account with this email already exists. Please log in instead.', array( 'status' => 409 ) );
    }

    $rl = ridego_check_rate_limit( 'app_register', isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : 'unknown', 5, 600 );
    if ( empty( $rl['allowed'] ) ) {
        return new WP_Error( 'rate_limited', 'Too many registration attempts. Please try again shortly.', array( 'status' => 429 ) );
    }

    $username = sanitize_user( strtolower( str_replace( ' ', '.', $name ) ) . '.' . substr( $phone, -4 ), true );
    $base_username = $username;
    $i = 1;
    while ( username_exists( $username ) ) { $username = $base_username . $i; $i++; }

    $uid = wp_create_user( $username, $password, $email );
    if ( is_wp_error( $uid ) ) {
        return new WP_Error( 'register_failed', 'Could not create your account. Please try again.', array( 'status' => 500 ) );
    }
    wp_update_user( array( 'ID' => $uid, 'display_name' => $name, 'first_name' => $name ) );
    update_user_meta( $uid, 'ridego_phone', $phone );
    $user = get_user_by( 'id', $uid );
    $user->set_role( 'subscriber' );

    $vendor_error = null;
    if ( $as_vendor ) {
        // owner_name is the field ridego_create_vendor() actually
        // requires (business_name is optional and falls back to it) —
        // passing business_name alone here previously failed this call
        // silently every time (the return value was discarded), so an
        // app "register as a vendor" signup created a normal user account
        // with NO vendor profile at all, while telling the customer it
        // had worked. Now the result is checked and, on failure, surfaced
        // to the caller rather than swallowed — the WP user account still
        // exists either way, so this doesn't roll back the whole signup,
        // but the response is honest about what did and didn't happen.
        $vendor_result = ridego_create_vendor( array(
            'user_id'    => $uid,
            'owner_name' => $name,
            'phone'      => $phone,
            'email'      => $email,
            'city'       => $city,
        ) );
        if ( empty( $vendor_result['success'] ) ) {
            $vendor_error = $vendor_result['message'] ?? 'Could not create your vendor profile.';
        }
    } elseif ( function_exists( 'ridego_client_sync_from_user' ) ) {
        // Root-cause fix (client CRM visibility gap): a client-role signup
        // used to only get a wp_ridego_clients row once they completed a
        // booking (ridego_client_upsert_from_booking(), called only from
        // ridego_create_booking()). Anyone who registered and never
        // booked was invisible on the admin CRM's Clients screen even
        // though their account was fully real and could sign in. See
        // ridego_client_sync_from_user()'s doc comment in includes/clients.php.
        ridego_client_sync_from_user( $uid );
    }

    wp_set_current_user( $uid );
    wp_set_auth_cookie( $uid, true );
    ridego_audit_log( 'app_register', 'user', $uid, '', $as_vendor ? 'vendor' : 'client', 'info' );

    $payload = ridego_app_api_current_user_payload();
    if ( $vendor_error ) {
        $payload['vendor_error'] = $vendor_error;
    }
    return rest_ensure_response( $payload );
}

function ridego_app_api_auth_logout( WP_REST_Request $req ) {
    wp_logout();
    return rest_ensure_response( array( 'logged_in' => false, 'nonce' => wp_create_nonce( 'wp_rest' ) ) );
}

/* ============================================================
   CONTENT / DATA HANDLERS — thin wrappers around the SAME
   canonical helpers the legacy shortcode frontend calls, so
   there is exactly one source of truth for "what the homepage
   shows" regardless of which frontend renders it.
   ============================================================ */

// TRACE: GET /app/home → public payload with popular cities plus origin_cities and destination_cities (the lists the booking form must use) → response.
//        Preconditions: none → Postconditions: read-only → Edge cases: no enabled cities (empty arrays).
function ridego_app_api_home( WP_REST_Request $req ) {
    $cities   = ridego_get_popular_cities();
    $vehicles = ridego_get_vehicles( true );
    // Each popular-city card gets an honest "From ₹X" computed from real route/vehicle
    // pricing (ridego_city_starting_fare()) — null (no price shown) rather than a
    // fabricated number when the city has no priced route yet.
    $popular_cities = array_map( function ( $c ) {
        $row = ridego_app_serialize_city( $c );
        $row['starting_fare'] = ridego_city_starting_fare( $c->id );
        return $row;
    }, $cities );
    return rest_ensure_response( array(
        'platform_name'    => ridego_brand_name(),
        'platform_tagline' => ridego_get_setting( 'platform_tagline', '' ),
        'currency_symbol'  => ridego_currency_symbol(),
        'popular_cities'   => $popular_cities,
        // Phase 0 fix: the home form must offer exactly the cities enabled for each role, not the
        // "popular" subset — otherwise an enabled origin/destination city can be missing here.
        'origin_cities'      => array_map( 'ridego_app_serialize_city', ridego_get_cities( true, 'origin' ) ),
        'destination_cities' => array_map( 'ridego_app_serialize_city', ridego_get_cities( true, 'destination' ) ),
        'vehicles'         => array_map( 'ridego_app_serialize_vehicle', $vehicles ),
        'support_phone'    => ridego_get_setting( 'support_phone' ),
        'support_whatsapp' => ridego_get_setting( 'support_whatsapp' ),
        // Real hero-stat numbers, not decorative round figures — the marketing page must never
        // claim a number the platform can't back. avg_rating is null (not 0 or a fake 4.7) until
        // at least one client has actually rated a trip.
        'stats'            => ridego_app_home_stats(),
    ) );
}

// TRACE: GET /app/home stats block → three cheap COUNT/AVG queries for the hero trust row →
//        array. Preconditions: none → Postconditions: read-only → Edge cases: no ratings yet
//        (avg_rating null, not a fabricated placeholder like 4.7).
function ridego_app_home_stats() {
    global $wpdb;
    $cities_covered = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_cities WHERE is_active=1" );
    $verified_partners = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_vendors WHERE status='active'" );
    $avg_rating = $wpdb->get_var( "SELECT AVG(rating_by_client) FROM {$wpdb->prefix}ridego_bookings WHERE rating_by_client IS NOT NULL" );
    return array(
        'cities_covered'    => $cities_covered,
        'verified_partners' => $verified_partners,
        'avg_rating'        => $avg_rating !== null ? round( (float) $avg_rating, 1 ) : null,
    );
}

/**
 * ?role=origin|destination filters to cities enabled for that role
 * (pickup / drop respectively). Any other value, or no param, returns
 * every active city — the exact pre-existing behavior — so this stays
 * backward compatible with any caller that doesn't send ?role at all.
 */
/**
 * Exposes the Google Maps key for the client-side Maps JavaScript API
 * loader (Places autocomplete + the pickup/drop pin map). This is the
 * ONE deliberate exception to "secrets never leave the server" in this
 * codebase: a Maps JS API key is *designed* to run in the browser —
 * Google's own security model for it is an HTTP-referrer restriction
 * configured in Cloud Console (Credentials -> this key -> Application
 * restrictions -> HTTP referrers), not secrecy, and every production
 * app using Google Maps client-side (this is exactly how Uber, Ola,
 * etc. do it) ships the key in its page source. It is still stored
 * encrypted at rest via ridego_get_secret_setting_keys() like the
 * platform's real secrets (Razorpay, Twilio, ...) because the same
 * settings-table storage is shared — encryption at rest costs
 * nothing extra and is still correct even though this key's actual
 * protection is the referrer restriction, configured in Google Cloud
 * Console, not this endpoint. No route/geocoding calls are made
 * server-side with this key.
 */
function ridego_app_api_maps_config( WP_REST_Request $req ) {
    $key = ridego_get_setting( 'google_maps_key', '' );
    return rest_ensure_response( array(
        'google_maps_key' => $key ? $key : null,
        'enabled'         => (bool) $key,
    ) );
}

function ridego_app_api_cities( WP_REST_Request $req ) {
    $role = $req->get_param( 'role' );
    $role = in_array( $role, array( 'origin', 'destination' ), true ) ? $role : null;
    return rest_ensure_response( array_map( 'ridego_app_serialize_city', ridego_get_cities( true, $role ) ) );
}

function ridego_app_api_vehicles( WP_REST_Request $req ) {
    return rest_ensure_response( array_map( 'ridego_app_serialize_vehicle', ridego_get_vehicles( true ) ) );
}

// TRACE: home page "Popular outstation routes" section → up to 6 real, published
//        route-marketing-page routes, most-popular first → array of
//        {slug, from_city, to_city, image_url, starting_fare}. image_url prefers
//        the route page's own admin-uploaded hero photo (Route Marketing Pages
//        hero-image upload), then falls back to the destination/origin city's
//        photo. Preconditions: none.
//        Postconditions: read-only. Edge cases: no route has fixed pricing yet
//        (starting_fare null, never a guessed number); no route hero and neither
//        city has a photo (image_url '', frontend shows the same honest gradient
//        placeholder used for Popular Cities); no published route pages at all
//        (empty array — the frontend must render an honest "coming soon" state,
//        not fake routes).
function ridego_app_api_popular_routes( WP_REST_Request $req ) {
    global $wpdb;
    $ptbl = ridego_route_pages_table();
    $rtbl = $wpdb->prefix . 'ridego_routes';
    $ctbl = $wpdb->prefix . 'ridego_cities';

    $rows = $wpdb->get_results(
        "SELECT p.slug, p.card_image_url, r.id AS route_id, r.from_city, r.to_city,
                fc.image_url AS from_image, tc.image_url AS to_image
         FROM {$ptbl} p
         INNER JOIN {$rtbl} r ON r.id = p.route_id
         LEFT JOIN {$ctbl} fc ON fc.name = r.from_city
         LEFT JOIN {$ctbl} tc ON tc.name = r.to_city
         WHERE p.status = 'published' AND r.is_active = 1
         ORDER BY r.is_popular DESC, p.published_at DESC
         LIMIT 6"
    );

    $vehicles = ridego_get_vehicles( true );
    $out = array();
    foreach ( (array) $rows as $r ) {
        $fare = null;
        foreach ( $vehicles as $v ) {
            $p = ridego_get_route_fixed_price( $r->from_city, $r->to_city, (int) $v->id );
            if ( $p !== false && $p !== null ) {
                $fare = ( $fare === null ) ? $p : min( $fare, $p );
            }
        }
        $out[] = array(
            'slug'          => $r->slug,
            'from_city'     => $r->from_city,
            'to_city'       => $r->to_city,
            // Prefer the route page's own dedicated card_image_url — a real
            // photo uploaded specifically for this small Home Page card
            // thumbnail (Route Pages admin editor). This is intentionally NOT
            // hero_image_desktop_url: that image is styled/overlaid for
            // full-bleed hero-banner display and looks wrong shrunk down to a
            // card. Falls back to the destination/origin city's real photo,
            // then '' (frontend shows an honest gradient icon — never a
            // fabricated stock photo).
            'image_url'     => (string) ( $r->card_image_url ?: $r->to_image ?: $r->from_image ?: '' ),
            'starting_fare' => $fare,
        );
    }
    return rest_ensure_response( $out );
}

// TRACE: home page "Meet the partners behind your ride" section → up to 3 real,
//        active + KYC-verified vendor records → array of {name, city,
//        vehicle_types, rating, total_ratings, total_rides_completed}.
//        Preconditions: none. Postconditions: read-only, no PII beyond the
//        vendor's own public business name/city/vehicle types is exposed (no
//        phone, email, bank details, documents). Edge cases: vendor has 0
//        ratings/rides yet (rating/total_ratings/total_rides_completed all null
//        rather than a fabricated "4.8★" or "120+ trips"); no qualifying vendor
//        at all (empty array — frontend must show an honest simpler section,
//        never invented partner names).
function ridego_app_api_partners( WP_REST_Request $req ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_vendors';
    $rows = $wpdb->get_results(
        "SELECT business_name, owner_name, city, vehicle_types, rating, total_ratings, total_rides_completed
         FROM {$tbl}
         WHERE status = 'active' AND kyc_status = 'verified'
         ORDER BY total_rides_completed DESC, rating DESC
         LIMIT 3"
    );
    $out = array();
    foreach ( (array) $rows as $r ) {
        $types = array_filter( array_map( 'trim', explode( ',', (string) $r->vehicle_types ) ) );
        $out[] = array(
            'name'                  => $r->business_name !== '' ? $r->business_name : $r->owner_name,
            'city'                  => (string) $r->city,
            'vehicle_types'         => array_values( $types ),
            'rating'                => ( (float) $r->total_ratings > 0 ) ? round( (float) $r->rating, 1 ) : null,
            'total_ratings'         => ( (int) $r->total_ratings > 0 ) ? (int) $r->total_ratings : null,
            'total_rides_completed' => ( (int) $r->total_rides_completed > 0 ) ? (int) $r->total_rides_completed : null,
        );
    }
    return rest_ensure_response( $out );
}

/**
 * Public route-marketing-page content. Returns the full, live-computed
 * ridego_generate_route_page_content() payload ONLY when the stored
 * ridego_route_pages row for this slug has status='published' — a
 * draft or needs_review page is never exposed here, so unreviewed
 * (and potentially quality-gate-failing) content can't leak publicly.
 * seo_title/meta_description come from the stored row (admin overrides
 * win over the generator's defaults — see ridego_update_route_page()).
 */
function ridego_app_api_route_page_by_slug( WP_REST_Request $req ) {
    $found = ridego_get_route_page_by_slug( (string) $req->get_param( 'slug' ) );
    if ( ! $found || $found['page']->status !== 'published' ) {
        return new WP_Error( 'not_found', 'Route page not found.', array( 'status' => 404 ) );
    }
    $content = ridego_generate_route_page_content( (int) $found['page']->route_id );
    if ( ! $content ) {
        return new WP_Error( 'not_found', 'Route page not found.', array( 'status' => 404 ) );
    }
    $content['slug']             = $found['page']->slug;
    $content['seo_title']        = $found['page']->seo_title;
    $content['meta_description'] = $found['page']->meta_description;
    $content['published_at']     = $found['page']->published_at;
    $content['hero']             = ridego_route_page_effective_hero( $found['page'] );
    return rest_ensure_response( $content );
}

/**
 * GET /ridego/v1/routes — the real /routes/ index page's data source. Every
 * PUBLISHED route page, via the same ridego_route_pages_list_published()
 * helper the server-rendered /routes/ shell snapshot uses (see
 * app-shell.php's ridego_routes_index_inject_ssr_body()), so the two can
 * never disagree on which routes exist or what they cost.
 */
function ridego_app_api_route_pages_index( WP_REST_Request $req ) {
    return rest_ensure_response( array(
        'routes' => function_exists( 'ridego_route_pages_list_published' ) ? ridego_route_pages_list_published() : array(),
    ) );
}

function ridego_app_serialize_city( $c ) {
    return array(
        'id'   => (int) $c->id,
        'name' => $c->name,
        'state'=> isset( $c->state ) ? $c->state : '',
        /* lat/lng are not sensitive (a city's coordinates are public
           knowledge) — exposed so the pickup/drop exact-location map
           (LocationPicker) can center on the chosen city instead of
           defaulting to a country-wide view every time. */
        'lat'  => ( isset( $c->lat ) && $c->lat !== null ) ? (float) $c->lat : null,
        'lng'  => ( isset( $c->lng ) && $c->lng !== null ) ? (float) $c->lng : null,
        // Admin-uploaded city photo (Settings → Cities). '' when the admin
        // hasn't uploaded one for this city — the frontend shows a plain
        // gradient/label card in that case rather than a fabricated photo.
        'image_url' => isset( $c->image_url ) ? (string) $c->image_url : '',
    );
}

// TRACE: home page "Popular cities" cards → an honest "From ₹X" per city, computed the same way
//        ridego_vehicle_starting_fare() computes a vehicle's floor price (cheapest vehicle's
//        per-km rate × the shortest active route out of this city, at that route's own distance,
//        plus driver allowance and GST) → float or null.
//        Preconditions: none → Postconditions: read-only, no data written → Edge cases: city has no
//        active outbound/inbound route (null — caller must not show a price rather than a fabricated
//        one), no active vehicle types configured (null).
function ridego_city_starting_fare( $city_id ) {
    global $wpdb;
    $city_id = (int) $city_id;
    if ( ! $city_id ) { return null; }

    $rt = $wpdb->prefix . 'ridego_routes';
    // Routes are stored one-directional; a city can be the "from" or "to" side of its
    // cheapest connection, so both directions are considered.
    $distance = $wpdb->get_var( $wpdb->prepare(
        "SELECT MIN(distance_km) FROM {$rt} WHERE is_active=1 AND (from_city_id=%d OR to_city_id=%d) AND distance_km > 0",
        $city_id, $city_id
    ) );
    if ( ! $distance ) { return null; }

    $vehicles = ridego_get_vehicles( true );
    if ( empty( $vehicles ) ) { return null; }

    $cheapest = null;
    foreach ( $vehicles as $v ) {
        if ( ! isset( $v->base_price_per_km ) || (float) $v->base_price_per_km <= 0 ) { continue; }
        $billable = max( (float) $distance, isset( $v->minimum_km ) ? (float) $v->minimum_km : 0 );
        $fare = $billable * (float) $v->base_price_per_km;
        $fare += isset( $v->driver_allowance_day ) ? (float) $v->driver_allowance_day : 0;
        // Root-cause fix: hardcoded 5% regardless of the real gst_enabled/gst_percent
        // settings — this "starting from" estimate could show GST-inflated prices even
        // with GST turned off in Settings. Mirrors ridego_calculate_fare()'s real logic.
        if ( (bool) ridego_get_setting( 'gst_enabled', 1 ) ) {
            $fare += $fare * ( (float) ridego_get_setting( 'gst_percent', 5 ) / 100 );
        }
        if ( $cheapest === null || $fare < $cheapest ) { $cheapest = $fare; }
    }
    return $cheapest !== null ? round( $cheapest, 2 ) : null;
}

function ridego_app_serialize_vehicle( $v ) {
    return array(
        'id'               => (int) $v->id,
        'name'             => $v->name,
        'slug'             => isset( $v->slug ) ? $v->slug : '',
        'seating_capacity' => (int) $v->seating_capacity,
        /* Root-cause fix: same class of bug as base_fare below — the
           ridego_vehicles table's column is icon_url (see includes/install.php),
           not image_url, so this always read a nonexistent property and every
           vehicle everywhere in the app (home page, search results, vehicle
           detail, the booking wizard's vehicle picker) permanently fell back
           to the generic car-outline placeholder icon regardless of the real
           per-vehicle-type artwork seeded in data/seed-vehicles.php. */
        'image_url'        => isset( $v->icon_url ) ? $v->icon_url : '',
        // Root-cause fix: this used to read $v->base_fare, a property that
        // never exists on the row object ridego_get_vehicles()'s `SELECT *`
        // returns (the vehicles table has no base_fare column at all) — so
        // isset() was always false and every vehicle, everywhere this
        // serializer is used (the home page vehicle list and the vehicle
        // detail page's "Starting at ₹X" line), permanently showed
        // "Fare on request" regardless of real pricing data. Compute a real
        // representative floor price instead, using the same per-km formula
        // ridego_calculate_oneway_fare() applies at the vehicle's own
        // minimum_km (its cheapest possible one-way fare), plus the driver
        // allowance and 5% GST every other fare in this engine already
        // includes — so this number is an honest "starting at", not an
        // invented one.
        'base_fare'        => ridego_vehicle_starting_fare( $v ),
        // Real columns already on this row (ridego_get_vehicles() selects the
        // full ridego_vehicles table) that nothing in the app surfaced before —
        // added for the vehicle detail page's specifications/pricing sections.
        // Never fabricated: every value here is read straight from the row
        // seeded/edited via Admin → Pricing, with an honest null/[] when unset.
        'luggage_capacity' => isset( $v->luggage_capacity ) ? (int) $v->luggage_capacity : null,
        'ac_available'     => isset( $v->ac_available ) ? (bool) $v->ac_available : null,
        'features'         => ridego_vehicle_features( $v ),
        'pricing'          => array(
            'per_km'              => isset( $v->base_price_per_km ) ? (float) $v->base_price_per_km : null,
            'per_km_outstation'   => isset( $v->base_price_outstation ) ? (float) $v->base_price_outstation : null,
            'minimum_km'          => isset( $v->minimum_km ) ? (float) $v->minimum_km : null,
            'local_4hr_40km'      => isset( $v->local_4hr_40km ) ? (float) $v->local_4hr_40km : null,
            'local_8hr_80km'      => isset( $v->local_8hr_80km ) ? (float) $v->local_8hr_80km : null,
            'airport_base_charge' => isset( $v->airport_base_charge ) ? (float) $v->airport_base_charge : null,
        ),
    );
}

// TRACE: a vehicle row → its `features` column (a JSON array of short strings, e.g. seeded by
//        data/seed-vehicles.php or typed into Admin → Pricing) decoded into a plain string array →
//        string[]. Never invents a feature: malformed/blank JSON or a missing column → [].
function ridego_vehicle_features( $v ) {
    if ( empty( $v->features ) ) { return array(); }
    $decoded = json_decode( (string) $v->features, true );
    if ( ! is_array( $decoded ) ) { return array(); }
    return array_values( array_filter( array_map( 'sanitize_text_field', $decoded ), 'strlen' ) );
}

/**
 * Cheapest realistic one-way fare for a vehicle: minimum_km at its own
 * per-km rate, plus driver allowance, plus GST — mirrors
 * ridego_calculate_oneway_fare()'s per-km branch at the floor distance.
 */
function ridego_vehicle_starting_fare( $v ) {
    if ( ! isset( $v->minimum_km ) || ! isset( $v->base_price_per_km ) ) {
        return null;
    }
    $base = (float) $v->minimum_km * (float) $v->base_price_per_km;
    $base += isset( $v->driver_allowance_day ) ? (float) $v->driver_allowance_day : 0;
    // Root-cause fix: was a hardcoded 5% regardless of gst_enabled/gst_percent.
    $gst = (bool) ridego_get_setting( 'gst_enabled', 1 ) ? $base * ( (float) ridego_get_setting( 'gst_percent', 5 ) / 100 ) : 0.0;
    return round( $base + $gst, 2 );
}

/**
 * Live fare calculation for the React booking flow — delegates to the
 * exact same ridego_calculate_fare()/ridego_validate_promo_code() the
 * legacy AJAX endpoint (ridego_ajax_calc_fare, in public/ajax/
 * booking-ajax.php) uses, so the two frontends can never quote a
 * different price for the same trip.
 */
function ridego_app_api_fare( WP_REST_Request $req ) {
    $rl_id = is_user_logged_in() ? ( 'u' . get_current_user_id() ) : ( isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : 'unknown' );
    $rl = ridego_check_rate_limit( 'app_fare', $rl_id, 60, 60 );
    if ( empty( $rl['allowed'] ) ) {
        return new WP_Error( 'rate_limited', 'Too many fare requests. Please slow down.', array( 'status' => 429 ) );
    }

    $body = $req->get_json_params();
    if ( ! is_array( $body ) ) { $body = array(); }

    $data = array(
        'trip_type'        => sanitize_key( $body['trip_type'] ?? 'one_way' ),
        'pickup_city'      => sanitize_text_field( $body['pickup_city'] ?? '' ),
        'drop_city'        => sanitize_text_field( $body['drop_city'] ?? '' ),
        'vehicle_type_id'  => intval( $body['vehicle_type_id'] ?? 0 ),
        'journey_date'     => sanitize_text_field( $body['journey_date'] ?? date( 'Y-m-d' ) ),
        'journey_time'     => sanitize_text_field( $body['journey_time'] ?? '08:00' ),
        'distance_km'      => (float) ( $body['distance_km'] ?? 0 ),
        'duration_minutes' => (int) ( $body['duration_minutes'] ?? 0 ),
        'hours_required'   => (int) ( $body['hours_required'] ?? 4 ),
        'return_date'      => sanitize_text_field( $body['return_date'] ?? '' ),
        'passengers'       => (int) ( $body['passengers'] ?? 1 ),
        'promo_code'       => strtoupper( sanitize_text_field( $body['promo_code'] ?? '' ) ),
    );

    if ( ! $data['vehicle_type_id'] ) {
        return new WP_Error( 'invalid_input', 'Select a vehicle first.', array( 'status' => 400 ) );
    }

    $fare = ridego_calculate_fare( $data );
    if ( isset( $fare['error'] ) ) {
        return new WP_Error( 'fare_error', $fare['error'], array( 'status' => 400 ) );
    }

    $discount = 0;
    $promo_error = null;
    if ( $data['promo_code'] ) {
        $pr = ridego_validate_promo_code( $data['promo_code'], $fare['base_fare'], $data, is_user_logged_in() ? get_current_user_id() : 0 );
        if ( ! empty( $pr['valid'] ) ) {
            $discount = (float) $pr['discount_amount'];
            $fare['total_fare'] -= $discount;
            $fare['discount'] = $discount;
            // Token amount is a flat snapshot, not a percentage of the
            // fare (see pricing.php) — a promo discount changes the total
            // it's netted against, so remaining_amount must be
            // recalculated here too, same as the equivalent correction in
            // ridego_create_booking() (includes/booking.php).
            $fare['token_amount']        = ridego_booking_amount_for( max( 0, (float) $fare['total_fare'] ) );
            $fare['remaining_amount']    = max( 0, (float) $fare['total_fare'] - (float) $fare['token_amount'] );
            $fare['booking_amount']      = $fare['token_amount'];
            $fare['payable_to_vendor']   = $fare['remaining_amount'];
            $fare['estimated_ride_fare'] = (float) $fare['total_fare'];
        } else {
            $promo_error = $pr['error'] ?? 'Invalid promo code';
        }
    }

    return rest_ensure_response( array(
        'fare'         => $fare,
        'sym'          => ridego_currency_symbol(),
        'promo_error'  => $promo_error,
    ) );
}

/* ============================================================
   BOOKINGS (customer) — thin REST wrappers around the exact same
   canonical booking functions the WP-page/shortcode/AJAX frontend
   uses (ridego_get_client_bookings, ridego_cancel_booking).
   ============================================================ */

/**
 * GET /app/bookings requires a logged-in user (it lists THEIR bookings);
 * POST /app/bookings is how both logged-in users and guests create a
 * booking (guest checkout is a core requirement of the existing booking
 * flow — see ridego_ajax_submit_booking() in public/ajax/booking-ajax.php,
 * which this endpoint mirrors), so it can't be gated behind
 * is_user_logged_in(). WP_REST_Server dispatches by exact method match on
 * the registered route, so both methods being registered against one
 * route means this one permission callback has to make that GET/POST
 * distinction itself.
 */
function ridego_app_api_bookings_collection_permission( WP_REST_Request $req ) {
    if ( $req->get_method() === 'GET' ) {
        return is_user_logged_in();
    }
    return true;
}

function ridego_app_api_bookings_collection( WP_REST_Request $req ) {
    if ( $req->get_method() === 'POST' ) {
        return ridego_app_api_create_booking( $req );
    }
    return ridego_app_api_my_bookings( $req );
}

function ridego_app_api_my_bookings( WP_REST_Request $req ) {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'rest_forbidden', 'Log in to see your bookings.', array( 'status' => 401 ) );
    }
    $uid    = get_current_user_id();
    $status = sanitize_key( (string) $req->get_param( 'status' ) );
    $page   = max( 1, (int) $req->get_param( 'page' ) );
    $per    = 10;
    $rows   = ridego_get_client_bookings( $uid, $status, $per, ( $page - 1 ) * $per );
    return rest_ensure_response( array_map( 'ridego_app_serialize_booking', $rows ) );
}

/**
 * Creates a booking exactly like ridego_ajax_submit_booking() does —
 * same rate limits, same OTP-or-trusted-phone requirement, same
 * sanitizer, same canonical ridego_create_booking() — so a booking made
 * from the React app is indistinguishable, in every rule and guard it
 * passes through, from one made through the legacy form.
 */
function ridego_app_api_create_booking( WP_REST_Request $req ) {
    $body = $req->get_json_params();
    if ( ! is_array( $body ) ) { $body = array(); }

    $phone = ridego_sanitize_phone( $body['client_phone'] ?? '' );
    $email = sanitize_email( $body['client_email'] ?? '' );
    $ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : 'unknown';

    $rl_phone = $phone ? ridego_check_rate_limit( 'booking_submit_phone', $phone, 5, 600 ) : array( 'allowed' => true );
    $rl_ip    = ridego_check_rate_limit( 'booking_submit_ip', $ip, 5, 600 );
    if ( empty( $rl_phone['allowed'] ) || empty( $rl_ip['allowed'] ) ) {
        return new WP_Error( 'rate_limited', 'Too many booking attempts. Please wait a few minutes and try again.', array( 'status' => 429 ) );
    }

    // Phone OTP and Email OTP are checked independently — each gate reads
    // its own admin setting (otp_enabled / email_otp_enabled) and its own
    // trust state, so any combination (both off, either alone, or both on)
    // is enforced exactly as configured, with neither channel hardcoded.
    if ( ridego_booking_requires_otp( $phone ) ) {
        $otp_val = sanitize_text_field( $body['otp_value'] ?? '' );
        if ( ! $otp_val ) {
            return new WP_Error( 'need_otp', 'Phone verification required. Please verify your number.', array( 'status' => 400, 'need_otp' => true ) );
        }
        $otp_check = ridego_verify_otp( $phone, $otp_val, 'booking' );
        if ( empty( $otp_check['success'] ) ) {
            return new WP_Error( 'otp_invalid', $otp_check['error'] ?? 'Invalid OTP.', array( 'status' => 400, 'need_otp' => true ) );
        }
    }
    if ( ridego_booking_requires_email_otp( $email ) ) {
        $email_otp_val = sanitize_text_field( $body['email_otp_value'] ?? '' );
        if ( ! $email_otp_val ) {
            return new WP_Error( 'need_email_otp', 'Email verification required. Please verify your email address.', array( 'status' => 400, 'need_email_otp' => true ) );
        }
        $email_otp_check = ridego_verify_email_otp( $email, $email_otp_val, 'booking' );
        if ( empty( $email_otp_check['success'] ) ) {
            return new WP_Error( 'email_otp_invalid', $email_otp_check['error'] ?? 'Invalid OTP.', array( 'status' => 400, 'need_email_otp' => true ) );
        }
    }

    $data = ridego_sanitize_booking_input( $body );
    $data['distance_km']      = (float) ( $body['distance_km'] ?? 0 );
    $data['duration_minutes'] = (int) ( $body['duration_minutes'] ?? 0 );

    $result = ridego_create_booking( $data );
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'booking_failed', $result['message'] ?? 'Could not create booking.', array( 'status' => 400 ) );
    }

    // ROOT-CAUSE FIX ("Booking not found" on the post-booking confirm
    // redirect): the guest is sent straight to /confirm?booking=...&phone=...
    // right after this call succeeds, and that page's lookup
    // (ridego_app_api_booking_lookup() -> ridego_get_booking_payment_context()
    // -> ridego_requester_verified_for_booking()) only accepts a requester
    // whose phone has EITHER a recent verified-OTP session
    // (ridego_validate_otp_session()) OR the trusted-phone cookie
    // (ridego_is_trusted_phone(), set by ridego_trust_phone() after a
    // successful OTP verify). When phone OTP wasn't required for this
    // booking at all — the admin's "Require OTP to confirm booking"
    // toggle (otp_enabled) is off, or this phone was already trusted from
    // an earlier verification whose OTP row has since aged out of the
    // 30-minute ridego_validate_otp_session() window — NEITHER of those
    // is guaranteed to be true, so the ownership check fails and the
    // brand-new booking this same guest just created is reported as "not
    // found" even though it exists with all correct data. The guest just
    // proved ownership of $phone by successfully completing this exact
    // booking submission, so it's safe to trust it now, exactly as a
    // completed OTP verify would (ridego_otp.php's ridego_verify_otp()),
    // so the very next request — the confirm redirect — recognizes them.
    if ( $phone ) {
        ridego_trust_phone( $phone );
    }

    return rest_ensure_response( $result );
}

function ridego_app_serialize_booking( $b ) {
    return array(
        'id'             => (int) $b->id,
        'booking_number' => $b->booking_number,
        'status'         => $b->status,
        'status_label'   => ridego_get_booking_status_label( $b->status ),
        'pickup_city'    => $b->pickup_city,
        'drop_city'      => $b->drop_city,
        'journey_date'   => $b->journey_date,
        'journey_time'   => $b->journey_time,
        'trip_type'      => $b->trip_type,
        'total_fare'     => (float) $b->total_fare,
        'token_amount'   => isset( $b->token_amount ) ? (float) $b->token_amount : 0.00,
        'balance_due'    => isset( $b->balance_due ) ? (float) $b->balance_due : (float) $b->total_fare,
        'vehicle_name'   => isset( $b->vehicle_name ) ? $b->vehicle_name : '',
        'payment_method' => $b->payment_method,
        'payment_status' => $b->payment_status,
        'created_at'     => $b->created_at,
        'rating'         => isset( $b->rating_by_client ) && $b->rating_by_client !== null ? (int) $b->rating_by_client : null,
        'review'         => isset( $b->review_by_client ) ? $b->review_by_client : '',
    ) + ridego_booking_money_fields( $b );
}

/**
 * Booking-confirmation/payment page lookup by booking_number — the React
 * equivalent of ridego_get_booking_payment_context() (includes/helpers.php),
 * reusing that exact function so the ownership/IDOR protection built into
 * it (Wave 5/6) applies identically here: a mismatched or unverifiable
 * phone gets the same generic "not found" response a nonexistent booking
 * number would, never leaking whether the number exists.
 */
function ridego_app_api_booking_lookup( WP_REST_Request $req ) {
    $bn    = sanitize_text_field( (string) $req->get_param( 'booking' ) );
    $phone = ridego_sanitize_phone( (string) $req->get_param( 'phone' ) );
    if ( ! $bn ) {
        return new WP_Error( 'invalid_input', 'Booking number is required.', array( 'status' => 400 ) );
    }

    // ridego_requester_verified_for_booking() (called inside
    // ridego_get_booking_payment_context()) checks $_POST['client_phone']
    // first, then falls back to the booking's own phone against this
    // browser's trust cookie / recent OTP session. A GET request has no
    // $_POST, so an explicitly supplied ?phone= is bridged in the same
    // way here — never trusted on its own, just handed to the same
    // verification function that already checks it against the real
    // booking's phone on file before accepting it as proof of ownership.
    if ( $phone ) {
        $_POST['client_phone'] = $phone; // phpcs:ignore -- intentional bridge into the shared $_POST-based verifier, see comment above.
    }

    $ctx = ridego_get_booking_payment_context( $bn );
    if ( ! $ctx ) {
        return new WP_Error( 'not_found', 'Booking not found. Please double-check the booking number and phone number.', array( 'status' => 404 ) );
    }

    $b = $ctx['booking'];
    return rest_ensure_response( array(
        'booking' => array_merge( ridego_app_serialize_booking( $b ), array(
            'pickup_address'     => $b->pickup_address,
            'drop_address'       => $b->drop_address,
            'passengers'         => (int) $b->passengers,
            'distance_km'        => (float) $b->distance_km,
            'base_fare'          => (float) $b->base_fare,
            'toll_charges'       => (float) $b->toll_charges,
            'parking_charges'    => (float) $b->parking_charges,
            'driver_allowance'   => (float) $b->driver_allowance,
            'gst_amount'         => (float) $b->gst_amount,
            'discount_amount'    => (float) $b->discount_amount,
            'promo_code'         => $b->promo_code,
            'payment_deadline'   => $b->payment_deadline,
            'payment_utr'        => $b->payment_utr,
            'payment_amount_claimed' => (float) $b->payment_amount_claimed,
            'payment_rejection_reason' => $b->payment_rejection_reason,
            'otp_pickup'         => $b->otp_pickup, // only ever reaches here after ownership is verified above
            'vendor_name'        => isset( $b->vendor_name ) ? $b->vendor_name : null,
            'vendor_phone'       => isset( $b->vendor_phone ) ? $b->vendor_phone : null,
            'vendor_whatsapp'    => isset( $b->vendor_whatsapp ) ? $b->vendor_whatsapp : null,
        ) ),
        'payment_details' => $ctx['payment_details'],
        'needs_payment'   => $ctx['needs_payment'],
        'is_confirmed'    => $ctx['is_confirmed'],
        'is_expired'      => $ctx['is_expired'],
        'seconds_left'    => $ctx['seconds_left'],
    ) );
}

/**
 * Payment-proof upload — mirrors ridego_ajax_submit_proof() exactly,
 * including its ownership gate (ridego_requester_verified_for_booking())
 * and the canonical, content-based file-type validation inside
 * ridego_submit_payment_proof() itself. WP_REST_Request::get_file_params()
 * returns the same $_FILES-shaped array the legacy handler already
 * expects, so no adaptation is needed there.
 */
function ridego_app_api_submit_payment_proof( WP_REST_Request $req ) {
    $bid = (int) $req->get_param( 'id' );
    $files = $req->get_file_params();
    if ( ! $bid || empty( $files['proof_file']['tmp_name'] ) ) {
        return new WP_Error( 'invalid_input', 'Booking ID and payment proof file are required.', array( 'status' => 400 ) );
    }
    $booking = ridego_get_booking( $bid );
    if ( ! $booking ) {
        return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
    }

    $phone = ridego_sanitize_phone( (string) $req->get_param( 'client_phone' ) );
    if ( $phone ) {
        $_POST['client_phone'] = $phone; // see ridego_app_api_booking_lookup()'s comment on this bridge
    }
    if ( ! ridego_requester_verified_for_booking( $booking ) ) {
        return new WP_Error( 'forbidden', 'We could not verify this is your booking. Please verify your phone number first.', array( 'status' => 403, 'need_phone' => true ) );
    }

    $proof = $req->get_body_params();
    $result = ridego_submit_payment_proof( $bid, $files['proof_file'], $proof );
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'upload_failed', $result['message'] ?? 'Could not submit payment proof.', array( 'status' => 400 ) );
    }

    /*
     * Guest account auto-creation, on first successful payment-proof
     * submission. No such mechanism existed before this change — a
     * guest booking never got a WP account, so there was never
     * anything to log into after this step. Built here by reusing the
     * EXACT patterns ridego_app_api_auth_register() already uses
     * (wp_create_user + subscriber role + ridego_client_sync_from_user
     * for the CRM row, wp_set_current_user + wp_set_auth_cookie for a
     * real logged-in session), rather than inventing a parallel
     * mechanism — see that function's neighboring comments for why
     * each call is there.
     */
    $result['account_created'] = false;
    if ( ! is_user_logged_in() && $booking->client_email && is_email( $booking->client_email ) && ! email_exists( $booking->client_email ) ) {
        $name     = $booking->client_name ?: 'Guest';
        $email    = $booking->client_email;
        $username = sanitize_user( strtolower( str_replace( ' ', '.', $name ) ) . '.' . substr( $phone ?: $booking->client_phone, -4 ), true );
        $base_username = $username ?: ( 'client' . $bid );
        $username = $base_username;
        $i = 1;
        while ( username_exists( $username ) ) { $username = $base_username . $i; $i++; }
        $password = wp_generate_password( 20, true, true );

        $uid = wp_create_user( $username, $password, $email );
        if ( ! is_wp_error( $uid ) ) {
            wp_update_user( array( 'ID' => $uid, 'display_name' => $name, 'first_name' => $name ) );
            update_user_meta( $uid, 'ridego_phone', $booking->client_phone );
            $user = get_user_by( 'id', $uid );
            $user->set_role( 'subscriber' );
            if ( function_exists( 'ridego_client_sync_from_user' ) ) {
                ridego_client_sync_from_user( $uid );
            }
            wp_set_current_user( $uid );
            wp_set_auth_cookie( $uid, true );
            ridego_audit_log( 'app_auto_register', 'user', $uid, '', 'client (post-payment-proof)', 'info' );

            $result['account_created'] = true;
            $result['auth'] = ridego_app_api_current_user_payload();
        }
    }

    return rest_ensure_response( $result );
}

/**
 * OTP handlers — thin wrappers around includes/otp.php's canonical
 * ridego_generate_otp()/ridego_verify_otp(), identical in behavior to
 * ridego_ajax_send_otp()/ridego_ajax_verify_otp() in the legacy AJAX
 * flow (public/ajax/booking-ajax.php), sharing the same rate limits,
 * attempt counters, and — after the Wave 9 trusted-device fix — the
 * same working trust cookie.
 *
 * Both endpoints accept an optional `channel` param ('phone', the
 * default, or 'email') so the same /app/otp/send and /app/otp/verify
 * routes serve the independent Email OTP Verification feature too —
 * routing to ridego_generate_email_otp()/ridego_verify_email_otp()
 * (keyed by `email` instead of `phone` in the request body) without
 * duplicating a whole second pair of REST routes.
 */
function ridego_app_api_otp_send( WP_REST_Request $req ) {
    $body    = $req->get_json_params();
    $channel = sanitize_key( $body['channel'] ?? 'phone' );
    $purpose = sanitize_key( $body['purpose'] ?? 'booking' );

    if ( $channel === 'email' ) {
        $email = sanitize_email( $body['email'] ?? '' );
        if ( ! $email || ! is_email( $email ) ) {
            return new WP_Error( 'invalid_input', 'A valid email address is required.', array( 'status' => 400 ) );
        }
        if ( ridego_is_trusted_email( $email ) ) {
            return rest_ensure_response( array( 'success' => true, 'trusted' => true, 'message' => 'Email already verified on this device.' ) );
        }
        $result = ridego_generate_email_otp( $email, $purpose );
        if ( empty( $result['success'] ) ) {
            return new WP_Error( 'otp_send_failed', $result['error'] ?? 'Could not send OTP.', array( 'status' => 400, 'retry_after' => $result['retry_after'] ?? null ) );
        }
        return rest_ensure_response( $result );
    }

    $phone = ridego_sanitize_phone( $body['phone'] ?? '' );
    if ( ! $phone ) {
        return new WP_Error( 'invalid_input', 'Phone number required.', array( 'status' => 400 ) );
    }
    if ( ridego_is_trusted_phone( $phone ) ) {
        return rest_ensure_response( array( 'success' => true, 'trusted' => true, 'message' => 'Phone already verified on this device.' ) );
    }
    $result = ridego_generate_otp( $phone, $purpose );
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'otp_send_failed', $result['error'] ?? 'Could not send OTP.', array( 'status' => 400, 'retry_after' => $result['retry_after'] ?? null ) );
    }
    return rest_ensure_response( $result );
}

function ridego_app_api_otp_verify( WP_REST_Request $req ) {
    $body    = $req->get_json_params();
    $channel = sanitize_key( $body['channel'] ?? 'phone' );
    $otp     = sanitize_text_field( $body['otp'] ?? '' );
    $purpose = sanitize_key( $body['purpose'] ?? 'booking' );

    if ( $channel === 'email' ) {
        $email  = sanitize_email( $body['email'] ?? '' );
        $result = ridego_verify_email_otp( $email, $otp, $purpose );
        if ( empty( $result['success'] ) ) {
            return new WP_Error( 'otp_invalid', $result['error'] ?? 'Invalid OTP.', array( 'status' => 400, 'remaining_attempts' => $result['remaining_attempts'] ?? null ) );
        }
        return rest_ensure_response( $result );
    }

    $phone   = ridego_sanitize_phone( $body['phone'] ?? '' );
    $result  = ridego_verify_otp( $phone, $otp, $purpose );
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'otp_invalid', $result['error'] ?? 'Invalid OTP.', array( 'status' => 400, 'remaining_attempts' => $result['remaining_attempts'] ?? null ) );
    }
    return rest_ensure_response( $result );
}

function ridego_app_api_cancel_booking( WP_REST_Request $req ) {
    $bid    = (int) $req->get_param( 'id' );
    $reason = sanitize_textarea_field( $req->get_param( 'reason' ) ?: 'Cancelled from app' );
    $uid    = get_current_user_id();

    $booking = ridego_get_booking( $bid );
    if ( ! $booking ) {
        return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
    }
    $is_admin = current_user_can( 'manage_options' );
    if ( ! $is_admin && (int) $booking->client_id !== $uid ) {
        return new WP_Error( 'forbidden', 'You are not authorized to cancel this booking.', array( 'status' => 403 ) );
    }
    $by = $is_admin ? 'admin' : 'client';
    $result = ridego_cancel_booking( $bid, $reason, $by, $by === 'client' ? $uid : null );
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'cancel_failed', $result['message'] ?? 'Could not cancel booking.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( $result );
}

// Rate + review a completed trip. ridego_rate_booking() itself already
// enforces every rule that matters (must be the booking's own client or
// an admin, must be 'completed', can't rate the same trip twice), so
// this handler is a thin wrapper — no divergent ownership logic here.
function ridego_app_api_rate_booking( WP_REST_Request $req ) {
    $bid    = (int) $req->get_param( 'id' );
    $score  = (int) $req->get_param( 'score' );
    $review = (string) $req->get_param( 'review' );
    $uid    = get_current_user_id();

    if ( $score < 1 || $score > 5 ) {
        return new WP_Error( 'invalid_input', 'Please choose a rating between 1 and 5.', array( 'status' => 400 ) );
    }

    // Optional category scores (service_quality, communication, reliability, vehicle_quality, behaviour, punctuality, driving, cleanliness)
    // go through the category-aware canonical function, with the overall star as the 'overall' value; without them the legacy path is used.
    $scores = $req->get_param( 'scores' );
    if ( is_array( $scores ) && $scores ) {
        $clean = array( 'overall' => $score );
        foreach ( $scores as $k => $v ) { $clean[ sanitize_key( $k ) ] = (int) $v; }
        $b = ridego_get_booking( $bid );
        if ( ! $b || (int) $b->client_id !== (int) $uid ) { return new WP_Error( 'rate_failed', 'You can only rate your own bookings.', array( 'status' => 400 ) ); }
        $result = ridego_submit_trip_ratings( $bid, $uid, 'client', $clean, sanitize_textarea_field( $review ) );
    } else {
        $result = ridego_rate_booking( $bid, $score, $review, $uid );
    }
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'rate_failed', $result['message'] ?? 'Could not submit your rating.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( $result );
}

/* ============================================================
   VENDOR — thin REST wrappers around the exact same canonical
   vendor/lead functions the shortcode vendor dashboard uses
   (ridego_get_vendor_leads, ridego_accept_lead), preserving every
   ownership/concurrency guard already built into them.
   ============================================================ */

function ridego_app_api_require_vendor() {
    $vendor = ridego_get_current_vendor();
    if ( ! $vendor ) {
        return new WP_Error( 'not_a_vendor', 'No vendor account found for this user.', array( 'status' => 403 ) );
    }
    return $vendor;
}

function ridego_app_api_vendor_me( WP_REST_Request $req ) {
    $vendor = ridego_app_api_require_vendor();
    if ( is_wp_error( $vendor ) ) { return $vendor; }
    return rest_ensure_response( array(
        'id'             => (int) $vendor->id,
        'business_name'  => $vendor->business_name,
        'status'         => $vendor->status,
        'wallet_balance' => (float) $vendor->wallet_balance,
        'rating'         => (float) $vendor->rating,
        'total_ratings'  => (int) $vendor->total_ratings,
        'total_leads_accepted' => (int) $vendor->total_leads_accepted,
        'low_wallet'     => (float) $vendor->wallet_balance < (float) ridego_get_setting( 'min_wallet_balance', 200 ),
    ) );
}

// TRACE: GET vendor leads → lists open leads with interest_status, lead_mode and confirmed driver/vehicle → response array.
//        Preconditions: vendor logged in → Postconditions: read-only → Edge cases: not a vendor (403), none (empty).
function ridego_app_api_vendor_leads( WP_REST_Request $req ) {
    $vendor = ridego_app_api_require_vendor();
    if ( is_wp_error( $vendor ) ) { return $vendor; }
    $status = sanitize_key( (string) ( $req->get_param( 'status' ) ?: 'sent' ) );
    $leads  = ridego_get_vendor_leads( $vendor->id, $status );
    return rest_ensure_response( array_map( function ( $l ) {
        return array(
            'id'             => (int) $l->id,
            'booking_id'     => (int) $l->booking_id,
            'booking_number' => $l->booking_number,
            'pickup_city'    => $l->pickup_city,
            'drop_city'      => $l->drop_city,
            'journey_date'   => $l->journey_date,
            'journey_time'   => $l->journey_time,
            'total_fare'     => (float) $l->total_fare,
            'fee_amount'     => (float) ridego_lead_fee_lead_view( $l )['amount'],
            'lead_fee'       => ridego_lead_fee_lead_view( $l ),
            'expires_at'     => $l->expires_at,
            'interest_status' => isset( $l->interest_status ) && $l->interest_status ? $l->interest_status : 'sent',
            'lead_mode'      => ridego_lead_mode(),
            'driver_name'    => isset( $l->driver_name ) ? $l->driver_name : '',
            'vehicle_registration' => isset( $l->vehicle_registration ) ? $l->vehicle_registration : '',
        );
    }, $leads ) );
}

// TRACE: POST accept → instant mode: legacy accept; compare mode: records interest → response or 400.
//        Preconditions: vendor owns the lead → Postconditions: see ridego_accept_lead / ridego_lead_show_interest → Edge cases: closed/expired lead (400).
function ridego_app_api_vendor_accept_lead( WP_REST_Request $req ) {
    $vendor = ridego_app_api_require_vendor();
    if ( is_wp_error( $vendor ) ) { return $vendor; }
    $lead_id = (int) $req->get_param( 'id' );
    $result  = ridego_lead_mode() === 'instant' ? ridego_accept_lead( $lead_id, $vendor->id ) : ridego_lead_show_interest( $lead_id, $vendor->id );
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'accept_failed', $result['message'] ?? 'Could not accept lead.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( $result );
}

/* ROOT-CAUSE FIX (vendor-app audit): ridego_reject_lead() has always
   existed server-side (with cascade-to-next-vendor) but was never wired
   to a REST route or a client call — the vendor app only offered
   "Accept", so a vendor with no interest in a lead had no way to
   actively decline it (letting it silently expire was the only option,
   delaying the cascade to the next vendor by the full lead_accept_minutes
   window instead of immediately). This thin wrapper mirrors the accept
   endpoint exactly, delegating to the same canonical, ownership-checked
   function the legacy shortcode dashboard uses. */
function ridego_app_api_vendor_reject_lead( WP_REST_Request $req ) {
    $vendor = ridego_app_api_require_vendor();
    if ( is_wp_error( $vendor ) ) { return $vendor; }
    $lead_id = (int) $req->get_param( 'id' );
    $reason  = sanitize_text_field( (string) ( $req->get_param( 'reason' ) ?: '' ) );
    $result  = ridego_reject_lead( $lead_id, $vendor->id, $reason );
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'reject_failed', $result['message'] ?? 'Could not reject lead.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( $result );
}

/* ROOT-CAUSE FIX (vendor-app audit): thin wrapper around the new
   canonical ridego_vendor_advance_trip() — lets a vendor move their own
   assigned trip forward (en route → trip started, with pickup-OTP check
   → completed) from the vendor app, closing a gap where the dashboard
   was entirely read-only after assignment. */
function ridego_app_api_vendor_advance_trip( WP_REST_Request $req ) {
    $vendor = ridego_app_api_require_vendor();
    if ( is_wp_error( $vendor ) ) { return $vendor; }
    $booking_id = (int) $req->get_param( 'id' );
    $body   = $req->get_json_params();
    $status = sanitize_key( (string) ( is_array( $body ) ? ( $body['status'] ?? '' ) : '' ) );
    $otp    = (string) ( is_array( $body ) ? ( $body['otp'] ?? '' ) : '' );
    $result = ridego_vendor_advance_trip( $booking_id, $vendor->id, $status, $otp );
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'advance_failed', $result['message'] ?? 'Could not update trip status.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( $result );
}

// Full trip history for the logged-in vendor, beyond the "sent leads"
// list — built on ridego_query_bookings(), the single canonical booking
// filter/search function the admin bookings list already uses, scoped
// to this vendor's own vendor_id so there's no way to page into another
// vendor's trips by manipulating the request.
function ridego_app_api_vendor_bookings( WP_REST_Request $req ) {
    $vendor = ridego_app_api_require_vendor();
    if ( is_wp_error( $vendor ) ) { return $vendor; }

    /* Root-cause fix: ridego_query_bookings() (includes/booking.php) supports
       a pipe-delimited multi-status filter ("vendor_assigned|driver_en_route|
       trip_started") for exactly this kind of "any of these active states"
       query — but sanitize_key() strips every character outside [a-z0-9_-],
       which silently swallows the '|' delimiter and turns a multi-status
       filter into one unmatchable concatenated string, returning zero rows
       with no error. Sanitize each status segment individually and rejoin
       with the delimiter the query layer actually expects. */
    $status_raw = (string) ( $req->get_param( 'status' ) ?: '' );
    $status     = implode( '|', array_filter( array_map( 'sanitize_key', explode( '|', $status_raw ) ) ) );
    $page   = max( 1, (int) $req->get_param( 'page' ) );
    $limit  = 20;

    $result = ridego_query_bookings( array(
        'vendor_id' => $vendor->id,
        'status'    => $status,
        'limit'     => $limit,
        'offset'    => ( $page - 1 ) * $limit,
        'orderby'   => 'created_at',
        'order'     => 'DESC',
    ) );

    $rows = array_map( function ( $b ) {
        return array(
            'id'             => (int) $b->id,
            'booking_number' => $b->booking_number,
            'status'         => $b->status,
            'status_label'   => ridego_get_booking_status_label( $b->status ),
            'pickup_city'    => $b->pickup_city,
            'drop_city'      => $b->drop_city,
            'journey_date'   => $b->journey_date,
            'journey_time'   => $b->journey_time,
            'trip_type'      => $b->trip_type,
            'total_fare'     => (float) $b->total_fare,
            /* ROOT-CAUSE FIX (vendor-app audit): the vendor had no
               visibility into the client's remaining balance-to-collect
               (the Token Amount / Advance Payment feature only shows the
               token amount already paid online; the rest is collected by
               the vendor/driver in cash/UPI at drop-off per that
               feature's spec). Without this, the vendor app simply never
               told vendors how much to collect. */
            'token_amount'    => isset( $b->token_amount ) ? (float) $b->token_amount : 0.00,
            'advance_paid'    => isset( $b->advance_paid ) ? (float) $b->advance_paid : 0.00,
            'balance_due'     => isset( $b->total_fare ) ? round( (float) $b->total_fare - (float) ( $b->advance_paid ?? 0 ), 2 ) : 0.00,
            'vehicle_name'   => isset( $b->vehicle_name ) ? $b->vehicle_name : '',
            'payment_status' => $b->payment_status,
            'rating'         => isset( $b->rating_by_client ) && $b->rating_by_client !== null ? (int) $b->rating_by_client : null,
            'created_at'     => $b->created_at,
        ) + ridego_booking_money_fields( $b ) + array( 'lead_fee' => ridego_lead_fee_view( $b ) );
    }, $result['rows'] );

    return rest_ensure_response( array(
        'rows'     => $rows,
        'total'    => (int) $result['total'],
        'page'     => $page,
        'per_page' => $limit,
    ) );
}

/**
 * Adds a vendor profile to the CURRENTLY LOGGED-IN user's existing
 * account — the gap flagged (and explicitly not faked) in Wave 9, where
 * only brand-new account registration supported becoming a vendor.
 * Delegates entirely to the same ridego_create_vendor() the registration
 * flow uses, so a vendor created this way is indistinguishable from one
 * created at signup — same required fields, same pending/KYC-pending
 * initial state, same admin approval workflow.
 */
function ridego_app_api_vendor_onboard( WP_REST_Request $req ) {
    $uid = get_current_user_id();
    if ( ridego_get_vendor_by_user( $uid ) ) {
        return new WP_Error( 'already_vendor', 'You already have a vendor profile on this account.', array( 'status' => 409 ) );
    }
    $body = $req->get_json_params();
    if ( ! is_array( $body ) ) { $body = array(); }

    $user  = wp_get_current_user();
    $owner_name = sanitize_text_field( $body['owner_name'] ?? $user->display_name );
    $city       = sanitize_text_field( $body['city'] ?? '' );
    $phone      = ridego_sanitize_phone( $body['phone'] ?? get_user_meta( $uid, 'ridego_phone', true ) );

    if ( ! $owner_name || ! $city || ! $phone ) {
        return new WP_Error( 'invalid_input', 'Owner name, city and phone are required.', array( 'status' => 400 ) );
    }

    $result = ridego_create_vendor( array(
        'user_id'        => $uid,
        'owner_name'     => $owner_name,
        'business_name'  => sanitize_text_field( $body['business_name'] ?? $owner_name ),
        'phone'          => $phone,
        'email'          => $user->user_email,
        'city'           => $city,
        'business_type'  => sanitize_key( $body['business_type'] ?? 'individual' ),
        'total_vehicles' => intval( $body['total_vehicles'] ?? 1 ),
    ) );

    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'onboard_failed', $result['message'] ?? 'Could not create vendor profile.', array( 'status' => 400 ) );
    }
    ridego_audit_log( 'app_vendor_onboard', 'user', $uid, '', 'vendor', 'info' );
    return rest_ensure_response( $result );
}

/**
 * The fixed set of KYC document types the platform requires — kept in
 * sync with ridego_check_kyc_completeness()'s $required_docs list in
 * includes/vendor.php by literally being the same array; if that list
 * ever changes, update it there and mirror the change here (there's no
 * shared constant to import from a plain array-in-a-function, so this is
 * the one place outside that function this list needs to be kept
 * intentionally in sync — documented in both places).
 */
function ridego_app_api_kyc_required_doc_types() {
    return array( 'driving_license', 'vehicle_rc', 'vehicle_insurance', 'pan_card', 'profile_photo' );
}

function ridego_app_api_vendor_docs_collection( WP_REST_Request $req ) {
    if ( $req->get_method() === 'POST' ) {
        return ridego_app_api_vendor_upload_doc( $req );
    }
    $vendor = ridego_app_api_require_vendor();
    if ( is_wp_error( $vendor ) ) { return $vendor; }
    $docs = ridego_get_vendor_docs( $vendor->id );
    return rest_ensure_response( array(
        'required_types' => ridego_app_api_kyc_required_doc_types(),
        'kyc_status'      => $vendor->kyc_status,
        'max_upload_mb'   => function_exists( 'ridego_max_upload_bytes' ) ? round( ridego_max_upload_bytes() / ( 1024 * 1024 ), 1 ) : 5,
        'docs'            => array_map( function ( $d ) {
            return array(
                'id'          => (int) $d->id,
                'doc_type'    => $d->doc_type,
                'status'      => $d->status,
                'expiry_date' => $d->expiry_date,
                'uploaded_at' => $d->uploaded_at,
            );
        }, $docs ),
    ) );
}

// TRACE: POST vendor doc → validates doc type, and when vehicle_id/driver_id given verifies they belong to the vendor and the type is a fleet type → upload → response or error.
//        Preconditions: vendor logged in → Postconditions: one document row → Edge cases: both ids (400), foreign entity (404), missing file (400).
function ridego_app_api_vendor_upload_doc( WP_REST_Request $req ) {
    $vendor = ridego_app_api_require_vendor();
    if ( is_wp_error( $vendor ) ) { return $vendor; }

    $doc_type = sanitize_key( (string) $req->get_param( 'doc_type' ) );
    /* Marketplace: a document may be scoped to one of this vendor's fleet vehicles or drivers. */
    $scope_vehicle = (int) $req->get_param( 'vehicle_id' );
    $scope_driver  = (int) $req->get_param( 'driver_id' );
    if ( $scope_vehicle && $scope_driver ) {
        return new WP_Error( 'invalid_input', 'A document belongs to a vehicle or a driver, not both.', array( 'status' => 400 ) );
    }
    if ( $scope_vehicle || $scope_driver ) {
        $ent = $scope_vehicle ? ridego_get_fleet_vehicle( $scope_vehicle ) : ridego_get_fleet_driver( $scope_driver );
        if ( ! $ent || (int) $ent->vendor_id !== (int) $vendor->id ) {
            return new WP_Error( 'not_found', 'Vehicle or driver not found.', array( 'status' => 404 ) );
        }
        if ( ! in_array( $doc_type, ridego_fleet_doc_types( $scope_vehicle ? 'vehicle' : 'driver' ), true ) ) {
            return new WP_Error( 'invalid_input', 'Unknown document type.', array( 'status' => 400 ) );
        }
    } elseif ( ! in_array( $doc_type, ridego_app_api_kyc_required_doc_types(), true ) ) {
        return new WP_Error( 'invalid_input', 'Unknown document type.', array( 'status' => 400 ) );
    }
    $files = $req->get_file_params();
    if ( empty( $files['file']['tmp_name'] ) ) {
        return new WP_Error( 'invalid_input', 'A file is required.', array( 'status' => 400 ) );
    }
    $expiry = sanitize_text_field( (string) $req->get_param( 'expiry_date' ) );

    $result = ridego_upload_vendor_doc( $vendor->id, $doc_type, $files['file'], $expiry, $scope_vehicle ?: null, $scope_driver ?: null );
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'upload_failed', $result['message'] ?? 'Could not upload document.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( $result );
}

/**
 * Serves an uploaded KYC document back to ITS OWN vendor (or an admin) —
 * ridego_serve_secure_file() in ridego-platform.php is admin-only by
 * design, so a vendor could never preview their own uploaded documents
 * through it. This is a separate, ownership-scoped serving path rather
 * than loosening that admin-only function's access rule.
 */
function ridego_app_api_vendor_doc_file( WP_REST_Request $req ) {
    global $wpdb;
    $doc_id = (int) $req->get_param( 'id' );
    $doc = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_driver_docs WHERE id=%d", $doc_id ) );
    if ( ! $doc ) {
        return new WP_Error( 'not_found', 'Document not found.', array( 'status' => 404 ) );
    }
    $vendor = ridego_get_vendor( $doc->vendor_id );
    $is_owner = $vendor && (int) $vendor->user_id === get_current_user_id();
    if ( ! $is_owner && ! current_user_can( 'manage_options' ) ) {
        return new WP_Error( 'forbidden', 'You are not authorized to view this document.', array( 'status' => 403 ) );
    }

    $full = RIDEGO_SECURE_UPLOADS . $doc->file_path;
    if ( ! file_exists( $full ) ) {
        return new WP_Error( 'not_found', 'File not found.', array( 'status' => 404 ) );
    }
    $real = realpath( $full );
    $base = realpath( RIDEGO_SECURE_UPLOADS );
    if ( ! $real || strpos( $real, $base ) !== 0 ) {
        return new WP_Error( 'invalid_path', 'Invalid path.', array( 'status' => 400 ) );
    }
    $mime = mime_content_type( $full );
    header( 'Content-Type: ' . $mime );
    header( 'Content-Disposition: inline; filename="' . basename( $full ) . '"' );
    header( 'X-Content-Type-Options: nosniff' );
    readfile( $full ); // phpcs:ignore -- ownership-checked, path-traversal-checked file read, not user-controlled output.
    exit;
}

/* ============================================================
   PROFILE / ACCOUNT
   ============================================================ */

function ridego_app_api_profile_collection( WP_REST_Request $req ) {
    if ( $req->get_method() === 'POST' ) {
        return ridego_app_api_update_profile( $req );
    }
    $uid  = get_current_user_id();
    $user = wp_get_current_user();
    return rest_ensure_response( array(
        'name'  => $user->display_name,
        'email' => $user->user_email,
        'phone' => get_user_meta( $uid, 'ridego_phone', true ),
    ) );
}

// TRACE: POST profile → refuses while an admin is viewing as this user, else updates name/email/phone → response or error.
//        Preconditions: logged in → Postconditions: profile updated or 403 → Edge cases: impersonating (403), duplicate email (409).
function ridego_app_api_update_profile( WP_REST_Request $req ) {
    if ( function_exists( 'ridego_impersonation_block' ) && ridego_impersonation_block() ) {
        return new WP_Error( 'impersonation_blocked', 'This action is not allowed while viewing as another user.', array( 'status' => 403 ) );
    }
    $uid  = get_current_user_id();
    $body = $req->get_json_params();
    if ( ! is_array( $body ) ) { $body = array(); }

    $name  = sanitize_text_field( $body['name'] ?? '' );
    $email = sanitize_email( $body['email'] ?? '' );
    $phone = ridego_sanitize_phone( $body['phone'] ?? '' );

    if ( ! $name || ! is_email( $email ) || ! $phone ) {
        return new WP_Error( 'invalid_input', 'Please provide a valid name, email and phone.', array( 'status' => 400 ) );
    }
    $existing = email_exists( $email );
    if ( $existing && (int) $existing !== $uid ) {
        return new WP_Error( 'email_exists', 'That email is already in use by another account.', array( 'status' => 409 ) );
    }

    wp_update_user( array( 'ID' => $uid, 'display_name' => $name, 'first_name' => $name, 'user_email' => $email ) );
    update_user_meta( $uid, 'ridego_phone', $phone );
    ridego_audit_log( 'app_profile_update', 'user', $uid, '', '', 'info' );

    return rest_ensure_response( array( 'success' => true, 'name' => $name, 'email' => $email, 'phone' => $phone ) );
}

// TRACE: POST password → refuses while impersonating, else verifies current password and sets the new one → response or error.
//        Preconditions: logged in → Postconditions: password changed or 403 → Edge cases: impersonating (403), wrong current password (401), too short (400).
function ridego_app_api_change_password( WP_REST_Request $req ) {
    if ( function_exists( 'ridego_impersonation_block' ) && ridego_impersonation_block() ) {
        return new WP_Error( 'impersonation_blocked', 'This action is not allowed while viewing as another user.', array( 'status' => 403 ) );
    }
    $uid  = get_current_user_id();
    $body = $req->get_json_params();
    if ( ! is_array( $body ) ) { $body = array(); }

    $current = (string) ( $body['current_password'] ?? '' );
    $new     = (string) ( $body['new_password'] ?? '' );

    $user = get_user_by( 'id', $uid );
    if ( ! $user || ! wp_check_password( $current, $user->user_pass, $uid ) ) {
        return new WP_Error( 'invalid_password', 'Your current password is incorrect.', array( 'status' => 401 ) );
    }
    if ( strlen( $new ) < 8 ) {
        return new WP_Error( 'invalid_input', 'New password must be at least 8 characters.', array( 'status' => 400 ) );
    }

    wp_set_password( $new, $uid );
    // wp_set_password() invalidates this user's existing session tokens
    // (including the one this very request authenticated with) — without
    // re-establishing the auth cookie, the visitor would be silently
    // logged out mid-request and the app's next call would 401.
    wp_set_current_user( $uid );
    wp_set_auth_cookie( $uid, true );
    ridego_audit_log( 'app_password_change', 'user', $uid, '', '', 'warning' );

    return rest_ensure_response( array( 'success' => true, 'nonce' => wp_create_nonce( 'wp_rest' ) ) );
}

/* ============================================================
   NOTIFICATIONS — thin REST wrappers around the read functions in
   includes/notifications.php (ridego_get_user_notifications(),
   ridego_mark_notification_read(), ridego_mark_all_notifications_read()).
   Every row is already scoped to get_current_user_id() server-side,
   so there's no separate ownership check needed for the list/unread-
   count endpoints; the single-notification "mark read" endpoint
   delegates its ownership check to ridego_mark_notification_read()
   itself, the same pattern used for ridego_rate_booking() above.
   ============================================================ */

function ridego_app_api_notifications( WP_REST_Request $req ) {
    $uid         = get_current_user_id();
    $unread_only = $req->get_param( 'unread_only' ) === '1' || $req->get_param( 'unread_only' ) === 'true';
    $page        = max( 1, (int) $req->get_param( 'page' ) );
    $limit       = 20;

    $result = ridego_get_user_notifications( $uid, $unread_only, $limit, ( $page - 1 ) * $limit );

    $rows = array_map( function ( $n ) {
        return array(
            'id'       => (int) $n->id,
            'event'    => $n->event,
            'channel'  => $n->channel,
            'message'  => $n->message,
            'status'   => $n->status,
            'is_read'  => (bool) $n->is_read,
            'sent_at'  => $n->sent_at,
        );
    }, $result['rows'] );

    return rest_ensure_response( array(
        'rows'          => $rows,
        'total'         => (int) $result['total'],
        'unread_count'  => ridego_count_unread_notifications( $uid ),
        'page'          => $page,
        'per_page'      => $limit,
    ) );
}

function ridego_app_api_notification_read( WP_REST_Request $req ) {
    $id  = (int) $req->get_param( 'id' );
    $uid = get_current_user_id();
    $result = ridego_mark_notification_read( $id, $uid );
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'mark_read_failed', $result['message'] ?? 'Could not update this notification.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'unread_count' => ridego_count_unread_notifications( $uid ) ) );
}

function ridego_app_api_notifications_read_all( WP_REST_Request $req ) {
    $uid = get_current_user_id();
    ridego_mark_all_notifications_read( $uid );
    return rest_ensure_response( array( 'success' => true, 'unread_count' => 0 ) );
}

/* ============================================================
   TRANSACTIONS
   ============================================================ */

/**
 * The logged-in customer's own transaction history. ridego_transactions
 * has no client_id column (only booking_id/vendor_id — it logs both
 * customer payments and vendor wallet-adjacent entries), so ownership
 * is scoped by joining through ridego_bookings, the same pattern
 * ridego_query_bookings() and every other ownership-scoped query in
 * this codebase already uses rather than trusting a client-supplied id.
 */
function ridego_app_api_transactions( WP_REST_Request $req ) {
    global $wpdb;
    $uid   = get_current_user_id();
    $page  = max( 1, (int) $req->get_param( 'page' ) );
    $limit = 20;
    $offset = ( $page - 1 ) * $limit;

    $ttbl = $wpdb->prefix . 'ridego_transactions';
    $btbl = $wpdb->prefix . 'ridego_bookings';

    $total = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$ttbl} t INNER JOIN {$btbl} b ON b.id = t.booking_id WHERE b.client_id = %d",
        $uid
    ) );

    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT t.id, t.type, t.amount, t.gateway, t.status, t.created_at,
                b.booking_number, b.pickup_city, b.drop_city
         FROM {$ttbl} t
         INNER JOIN {$btbl} b ON b.id = t.booking_id
         WHERE b.client_id = %d
         ORDER BY t.created_at DESC
         LIMIT %d OFFSET %d",
        $uid, $limit, $offset
    ) );

    $out = array_map( function ( $t ) {
        return array(
            'id'             => (int) $t->id,
            'type'           => $t->type,
            'amount'         => (float) $t->amount,
            'gateway'        => $t->gateway,
            'status'         => $t->status,
            'created_at'     => $t->created_at,
            'booking_number' => $t->booking_number,
            'pickup_city'    => $t->pickup_city,
            'drop_city'      => $t->drop_city,
        );
    }, $rows );

    return rest_ensure_response( array(
        'rows'     => $out,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $limit,
    ) );
}

/* ============================================================
   REVIEWS
   ============================================================ */

/**
 * A public feed of genuine customer reviews for social proof — reads
 * the same rating_by_client/review_by_client columns MyTripsPage's
 * "rate this trip" flow (see ridego_app_api_rate_booking()) writes
 * to. Only bookings with BOTH a rating and non-empty review text are
 * shown (a bare star rating with no text isn't worth surfacing as a
 * "review"), and the client's full name is reduced to a first name +
 * last-initial for a small measure of privacy on a public page —
 * this is display-only; nothing about how ratings are stored changes.
 */
// TRACE: GET /app/reviews[?vehicle_type_id=N] → real completed-trip reviews (never fabricated), each
//        joined to the actual booking's real vehicle_type_id so a vehicle's own detail page can show
//        genuine reviews from trips taken in that vehicle type, not the whole platform's → response.
//        Also returns avg_rating (over ALL matching bookings, not just this page, and over ALL rated
//        bookings even the ones with no free-text review) so the summary number is honest even when
//        few people left written reviews. Edge cases: no vehicle_type_id → unfiltered (home page
//        behaviour, unchanged); no matching rows → avg_rating null, rows [] (caller shows an empty state,
//        never a placeholder review).
function ridego_app_api_reviews( WP_REST_Request $req ) {
    global $wpdb;
    $page      = max( 1, (int) $req->get_param( 'page' ) );
    $limit     = 12;
    $offset    = ( $page - 1 ) * $limit;
    $btbl      = $wpdb->prefix . 'ridego_bookings';
    $vtbl      = $wpdb->prefix . 'ridego_vendors';
    $vehicle_id = (int) $req->get_param( 'vehicle_type_id' );

    $rated_where = 'b.rating_by_client IS NOT NULL AND b.rating_by_client > 0';
    $where       = $rated_where . " AND b.review_by_client != ''";
    $vehicle_sql = $vehicle_id > 0 ? $wpdb->prepare( ' AND b.vehicle_type_id = %d', $vehicle_id ) : '';

    $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} b WHERE {$where}{$vehicle_sql}" );
    $avg_row = $wpdb->get_row( "SELECT AVG(b.rating_by_client) AS avg_rating, COUNT(*) AS n FROM {$btbl} b WHERE {$rated_where}{$vehicle_sql}" );
    $avg_rating = ( $avg_row && (int) $avg_row->n > 0 ) ? round( (float) $avg_row->avg_rating, 1 ) : null;
    $rating_count = $avg_row ? (int) $avg_row->n : 0;

    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT b.id, b.client_name, b.rating_by_client, b.review_by_client, b.pickup_city, b.drop_city,
                b.journey_date, b.created_at, v.business_name
         FROM {$btbl} b
         LEFT JOIN {$vtbl} v ON v.id = b.vendor_id
         WHERE {$where}{$vehicle_sql}
         ORDER BY b.updated_at DESC
         LIMIT %d OFFSET %d",
        $limit, $offset
    ) );

    $out = array_map( function ( $r ) {
        $name  = trim( (string) $r->client_name );
        $parts = $name !== '' ? preg_split( '/\s+/', $name ) : array();
        $short = $parts ? ( $parts[0] . ( count( $parts ) > 1 ? ' ' . mb_substr( end( $parts ), 0, 1 ) . '.' : '' ) ) : '' . ridego_brand_name() . ' customer';
        return array(
            'id'            => (int) $r->id,
            'client_name'   => $short,
            'rating'        => (int) $r->rating_by_client,
            'review'        => $r->review_by_client,
            'pickup_city'   => $r->pickup_city,
            'drop_city'     => $r->drop_city,
            'vendor_name'   => $r->business_name ?: '',
            'journey_date'  => $r->journey_date,
        );
    }, $rows );

    return rest_ensure_response( array(
        'rows'          => $out,
        'total'         => $total,
        'page'          => $page,
        'per_page'      => $limit,
        'avg_rating'    => $avg_rating,
        'rating_count'  => $rating_count,
    ) );
}
