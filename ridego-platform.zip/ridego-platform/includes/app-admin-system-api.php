<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — system health + audit-log integrity check
   (RG-009, Master Issue Register P1: "tested backup/restore strategy").
   ------------------------------------------------------------
   Honest scope note: a WordPress PLUGIN cannot itself take or verify a
   database backup — that is the hosting layer's job (mysqldump / managed
   host snapshots), and claiming otherwise here would be exactly the kind
   of fabricated PASS this audit's own protocol forbids. What a plugin
   CAN do, and what was actually missing, is give an admin a real,
   automated way to tell whether the data currently in the database is
   internally sound — which is also precisely what you need to check
   immediately after restoring a backup, to know the restore actually
   worked and didn't leave anything half-applied or corrupted.
   That is what this file adds:
     - GET /app/admin/system/health — row counts for the core tables,
       the current schema version vs. RIDEGO_SCHEMA_VERSION (a mismatch
       means migrations haven't finished running — exactly the state a
       fresh restore is often left in), PHP/WP/MySQL versions.
     - GET /app/admin/system/audit-integrity-check — recomputes the
       SHA-256 checksum ridego_audit_log() (helpers.php:951) already
       stores on every row, using the EXACT same formula, and reports
       any row whose stored checksum no longer matches. The checksum
       has existed since early in this codebase but nothing before this
       endpoint ever actually verified it — a silently broken tamper-
       evidence chain would never have been noticed. This also happens
       to be a genuine restore-verification tool: an incomplete or
       corrupted restore of the audit table would show up here as
       checksum mismatches.
   Both are read-only; neither writes or repairs anything.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_system_api_routes' );
function ridego_register_app_admin_system_api_routes() {
    register_rest_route( 'ridego/v1', '/app/admin/system/health', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_system_health',
        'permission_callback' => 'ridego_app_admin_api_system_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/system/audit-integrity-check', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_audit_integrity_check',
        'permission_callback' => 'ridego_app_admin_api_system_permission',
    ) );
}

function ridego_app_admin_api_system_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_settings' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to view system health.', array( 'status' => 403 ) );
    }
    return true;
}

// TRACE: GET system/health → row counts for the core tables, schema-version match against
//        RIDEGO_SCHEMA_VERSION, and platform versions → {schema:{stored,expected,in_sync},
//        table_counts:{...}, php_version, wp_version, mysql_version, checked_at}. Pure reads.
//        Preconditions: caller has ridego_manage_settings. Postconditions: none, read-only.
//        Edge cases: a core table missing entirely (count reported as null with 'missing' flag
//        rather than a fatal COUNT(*) error) — this is exactly the signal an incomplete restore
//        would produce, so it is surfaced rather than swallowed.
function ridego_app_admin_api_system_health( WP_REST_Request $req ) {
    global $wpdb;
    $p = $wpdb->prefix;

    $core_tables = array(
        'bookings' => "{$p}ridego_bookings",
        'vendors' => "{$p}ridego_vendors",
        'fleet_drivers' => "{$p}ridego_fleet_drivers",
        'audit_log' => "{$p}ridego_audit_log",
        'booking_payments' => "{$p}ridego_booking_payments",
        'privacy_requests' => "{$p}ridego_privacy_requests",
    );
    $counts = array();
    foreach ( $core_tables as $key => $tbl ) {
        $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $tbl ) );
        $counts[ $key ] = $exists ? array( 'table' => $tbl, 'rows' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tbl}" ), 'missing' => false )
                                   : array( 'table' => $tbl, 'rows' => null, 'missing' => true );
    }

    $stored_schema = (int) get_option( 'ridego_schema_version', 0 );
    $expected_schema = defined( 'RIDEGO_SCHEMA_VERSION' ) ? RIDEGO_SCHEMA_VERSION : 0;

    return rest_ensure_response( array(
        'schema' => array( 'stored' => $stored_schema, 'expected' => $expected_schema, 'in_sync' => $stored_schema === $expected_schema ),
        'table_counts' => $counts,
        'php_version' => PHP_VERSION,
        'wp_version' => get_bloginfo( 'version' ),
        'mysql_version' => $wpdb->db_version(),
        'checked_at' => current_time( 'mysql' ),
    ) );
}

// TRACE: GET system/audit-integrity-check?limit=&offset= → recomputes each sampled audit_log
//        row's checksum with the identical formula ridego_audit_log() used to store it
//        (admin_id.action.entity.entity_id.old_value.new_value.created_at.wp_salt('auth')) and
//        compares → {checked, mismatches:[{id,action,entity,entity_id,created_at}], sample_size,
//        offset, has_more}. Preconditions: caller has ridego_manage_settings. Postconditions:
//        read-only — a mismatch is reported, never auto-corrected (correcting a checksum here
//        would defeat the entire point of tamper-evidence). Edge cases: an old row with a NULL/
//        empty checksum column, predating this column's own migration (0020) — treated as
//        unverifiable, not corrupted, and reported separately so it is never confused with a
//        real integrity failure; a wp_salt('auth') rotation would ALSO make every legitimate old
//        row fail this check, so a mismatch here is a lead to investigate, not by itself proof of
//        tampering — documented explicitly rather than presented as a definitive verdict.
//
// ROOT-CAUSE FIX (found via the regression suite's own idempotency re-run, not requested by
// name): this used to sample the OLDEST rows first (ORDER BY id ASC, offset 0 by default). On a
// log that has grown past the 500-row default window — which any real production system does
// quickly — every call an admin makes without an explicit offset checks ancient history and can
// NEVER see a recently tampered row, silently defeating the one thing a tamper-*detection*
// endpoint exists for. Default browsing now starts from the newest rows (id DESC) so an admin who
// just hits the endpoint is actually looking at recent activity; offset still pages further back
// through history for a full audit, it just walks backward in time instead of forward.
function ridego_app_admin_api_audit_integrity_check( WP_REST_Request $req ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_audit_log';
    $limit = max( 1, min( 2000, (int) $req->get_param( 'limit' ) ?: 500 ) );
    $offset = max( 0, (int) $req->get_param( 'offset' ) );

    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, admin_id, action, entity, entity_id, old_value, new_value, created_at, checksum FROM {$tbl} ORDER BY id DESC LIMIT %d OFFSET %d",
        $limit, $offset
    ) );
    $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tbl}" );

    $mismatches = array();
    $unverifiable = 0;
    foreach ( $rows as $r ) {
        if ( empty( $r->checksum ) ) { $unverifiable++; continue; }
        $expected = hash( 'sha256', $r->admin_id . $r->action . $r->entity . ( $r->entity_id ?? 0 ) . $r->old_value . $r->new_value . $r->created_at . wp_salt( 'auth' ) );
        if ( ! hash_equals( $expected, (string) $r->checksum ) ) {
            $mismatches[] = array( 'id' => (int) $r->id, 'action' => $r->action, 'entity' => $r->entity, 'entity_id' => $r->entity_id, 'created_at' => $r->created_at );
        }
    }

    return rest_ensure_response( array(
        'sample_size'   => count( $rows ),
        'offset'        => $offset,
        'total_rows'    => $total,
        'has_more'      => ( $offset + count( $rows ) ) < $total,
        'unverifiable'  => $unverifiable,
        'mismatches'    => $mismatches,
        'verified_ok'   => count( $rows ) - $unverifiable - count( $mismatches ),
        'note'          => 'A mismatch can also result from a wp_salt(\'auth\') rotation, not only tampering — investigate before concluding tampering.',
    ) );
}
