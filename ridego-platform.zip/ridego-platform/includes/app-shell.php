<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Shell
   ------------------------------------------------------------
   Serves the standalone React/TypeScript/Vite single-page app at
   /app and every sub-path under it (/app/search, /app/my-trips,
   /app/vendor/dashboard, whatever routes the app's own client-side
   router defines) — WITHOUT depending on a manually created
   WordPress Page, a theme, or a page builder. WordPress's only two
   jobs here are: (1) match the URL via a rewrite rule and hand off
   to this file instead of theme template resolution, and (2) print
   the built index.html with a small bootstrap object injected so
   the React app knows its API base URL, REST nonce, and current
   login state on first paint — everything after that is the
   client-side router's job, not WordPress's.

   This intentionally does NOT call get_header()/get_footer() or
   load the active theme at all: the response is the SPA's own
   HTML, CSS and JS, output directly and then `exit` — WordPress is
   acting purely as the "vehicle/runtime" that got the request to
   this code, per the architecture this implements.

   Build output: `app/dist/` (created by `npm run build` inside the
   `app/` directory — see app/README.md). That directory is not
   committed as source; the plugin ships the app/src/ TypeScript
   source AND a prebuilt app/dist/ so the plugin works immediately
   on activation without requiring a Node build step on the
   customer's server (matches the "genuinely plug-and-play" and
   "complete source code included for future maintenance" requirements
   at once: the source is there to modify and rebuild, the dist is
   there so nothing has to be built just to activate the plugin).
   ================================================================ */

define( 'RIDEGO_APP_DIR', RIDEGO_PATH . 'app/dist/' );
define( 'RIDEGO_APP_URL', RIDEGO_URL . 'app/dist/' );

/* ---------------------------------------------------------------
   Rewrite: the SPA now owns the domain root — every path is routed
   to index.php?ridego_app=1 EXCEPT the reserved WordPress path
   prefixes below (wp-admin, wp-login.php, wp-json, wp-content,
   wp-includes, xmlrpc.php, wp-cron.php, robots.txt, feeds), which
   must keep resolving to WordPress's own handlers untouched.
   The captured sub-path itself is deliberately NOT parsed into a
   query var — the whole point of a client-side router is that
   the SAME index.html is served for every sub-path, and React
   Router (browser history mode) decides what to render from
   window.location itself once the JS boots.

   A legacy '/app' or '/app/...' URL (the app's old mount point) is
   matched separately and 301-redirected to its unprefixed
   equivalent, so bookmarked/shared links don't just 404.
   --------------------------------------------------------------- */
add_action( 'init', 'ridego_app_register_rewrite' );
function ridego_app_register_rewrite() {
    add_rewrite_tag( '%ridego_app%', '1' );
    add_rewrite_tag( '%ridego_legacy_app%', '1' );
    add_rewrite_tag( '%ridego_legacy_app_path%', '(.*)' );

    // Reserved WordPress path prefixes this catch-all must never swallow.
    // (Most of these already resolve to a real file/directory before the
    // rewrite engine even runs, but wp-json's pretty-permalink form is
    // itself a rewrite rule, not a file, so it must be excluded explicitly
    // here and also win by being registered with normal, not 'top', priority.)
    $reserved = 'wp-admin|wp-includes|wp-content|wp-json|wp-login\.php|wp-cron\.php|xmlrpc\.php|robots\.txt|feed';

    // Legacy '/app' and '/app/...' → redirect to the unprefixed URL.
    // Registered 'top' so it wins over the generic catch-all below.
    add_rewrite_rule( '^app/?$', 'index.php?ridego_legacy_app=1&ridego_legacy_app_path=', 'top' );
    add_rewrite_rule( '^app/(.*)$', 'index.php?ridego_legacy_app=1&ridego_legacy_app_path=$matches[1]', 'top' );

    // Route-marketing pages live at a top-level /routes/{slug} URL (matching
    // the public REST endpoint GET /ridego/v1/routes/{slug} and the SPA's
    // own top-level '/routes/:slug' route). The slug is captured into its
    // own query var (ridego_route_slug) so PHP can look up the real
    // route-page row during template_redirect, BEFORE the shell HTML is
    // built — that's what lets ridego_app_render_shell() inject real
    // server-side SEO/meta/JSON-LD for this one request instead of the
    // generic branding-only title used everywhere else. Registered 'top'
    // so it is matched (and its slug captured) before the generic
    // catch-all below would otherwise just serve the branding-only shell.
    add_rewrite_tag( '%ridego_route_slug%', '([^/]+)' );
    add_rewrite_rule( '^routes/([^/]+)/?$', 'index.php?ridego_app=1&ridego_route_slug=$matches[1]', 'top' );

    // /routes/ index page — the real, browsable listing of every published
    // route page (matches the SPA's own top-level '/routes' route and the
    // public REST endpoint GET /ridego/v1/routes). Its own query var so
    // ridego_app_render_shell() can inject real SEO/SSR content for this one
    // request too, same as the per-slug rule above. Registered 'top', and
    // BEFORE the slug rule would otherwise be tried, so a bare /routes/
    // request can never be mistaken for a (nonexistent) slug named "".
    add_rewrite_tag( '%ridego_routes_index%', '1' );
    add_rewrite_rule( '^routes/?$', 'index.php?ridego_app=1&ridego_routes_index=1', 'top' );

    // Generic catch-all: every other path becomes the SPA shell, unless it
    // starts with a reserved WordPress prefix. Registered at normal
    // ('bottom') priority so it never outranks WordPress's own rewrite
    // rules for wp-json/etc — those, plus the two rules above, always win.
    add_rewrite_rule( '^(?!(?:' . $reserved . ')(?:/|$)).*$', 'index.php?ridego_app=1', 'bottom' );
}

add_filter( 'query_vars', function ( $vars ) {
    $vars[] = 'ridego_app';
    $vars[] = 'ridego_route_slug';
    $vars[] = 'ridego_routes_index';
    $vars[] = 'ridego_legacy_app';
    $vars[] = 'ridego_legacy_app_path';
    return $vars;
} );

/**
 * ROOT-CAUSE FIX (direct-navigation 404 regression): the rewrite rule
 * registered above is matched using WordPress's normal rewrite-rule
 * ORDER — first matching regex wins — and 'top' vs 'bottom' only
 * controls where a rule lands relative to OTHER rules added the same
 * way; it never lets a plugin's 'bottom' rule outrank WordPress core's
 * OWN 'bottom' page/post-name catch-alls (`(.?.+?)(?:/([0-9]+))?/?$`
 * => pagename=..., `([^/]+)(?:/([0-9]+))?/?$` => name=...), which core
 * always registers before any plugin's extra rules are merged in. So a
 * direct hit on e.g. /book or /confirm was matching core's generic
 * pagename rule FIRST (there is no WP page/post with that slug), never
 * reaching this plugin's catch-all at all — WP_Query then legitimately
 * 404s (or redirect_canonical's slug-guessing 302s it elsewhere), and
 * only a client-side link click (which never re-parses the URL through
 * WordPress) ever worked. Confirmed live: `SELECT option_value FROM
 * wp_options WHERE option_name='rewrite_rules'` showed the plugin's
 * catch-all as the LAST of 97 rules, after core's pagename/name rules;
 * curl of a fresh /book, /confirm, /dashboard, /admin, /login request
 * came back 404/302, not the SPA shell — reproduced BEFORE this fix and
 * confirmed fixed by it below.
 *
 * Fighting rewrite-rule order further (yet another priority workaround,
 * or moving core's rules) is not viable — that order is core's own and
 * not something a plugin can reliably out-prioritize forever. The
 * correct, standard fix for "this framework owns every non-WordPress
 * route" is to stop relying on WordPress ever resolving the URL to a
 * post/page at all: 'do_parse_request' fires in WP::main() BEFORE that
 * resolution happens, and returning false from it skips WP's own
 * request parsing entirely, so this plugin decides the outcome for
 * every non-reserved path directly, with the exact same reserved-prefix
 * exclusion list the rewrite rule already used. The rewrite rules above
 * are kept (a fresh install's .htaccess still needs *some* permalink
 * structure recognised so every request even reaches index.php; the
 * legacy '/app' and '/routes/{slug}' query vars they define are also
 * still read by ridego_app_maybe_serve_shell()), but they no longer
 * have to win a race against core's rules for the outcome to be correct.
 *
 * This hooks the 'parse_request' ACTION (fired at the end of
 * WP::parse_request(), once core has already matched — or failed to
 * match — the request against its own rewrite rules) rather than the
 * 'do_parse_request' FILTER: returning false from that filter makes
 * WP::parse_request() itself return false, which short-circuits
 * WP::main() entirely — query_posts(), handle_404() and
 * register_globals() never run at all, leaving $wp_query completely
 * empty (confirmed live: get_query_var('ridego_app') came back '' and
 * $wp_query->query_vars was a bare empty array even though $wp->query_vars
 * held the right value, because query_posts() — the very call that
 * copies $wp->query_vars into $wp_query — was one of the skipped
 * steps). Overwriting $wp->query_vars from the 'parse_request' action
 * instead lets the normal WP::main() flow continue untouched — core's
 * own (possibly wrong) match is simply replaced before query_posts()
 * reads it, which is the standard, supported way to override what a
 * request resolves to.
 */
add_action( 'parse_request', 'ridego_app_override_parsed_request' );
function ridego_app_override_parsed_request( $wp ) {
    if ( is_admin() ) {
        return;
    }

    $request_path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ) : '/';
    $path         = trim( (string) $request_path, '/' );

    // Same reserved-prefix list as the rewrite rule above, PLUS
    // wp-sitemap*.xml/.xsl: the rewrite-rule version never needed this
    // listed explicitly because core's sitemap rules happen to be
    // merged ahead of a plugin's 'bottom' rule, but do_parse_request
    // runs before any rewrite matching at all, so it must be excluded
    // here explicitly or a fresh wp-sitemap.xml request would be
    // swallowed as an SPA route instead of reaching WP_Sitemaps.
    $reserved = '#^(?:wp-admin|wp-includes|wp-content|wp-json|wp-login\.php|wp-cron\.php|xmlrpc\.php|robots\.txt|feed|wp-sitemap)(?:/|$|[.-])#';
    if ( '' !== $path && preg_match( $reserved, $path ) ) {
        return;
    }

    // Legacy '/app' or '/app/...' → the 301-redirect handled in
    // ridego_app_maybe_serve_shell() via these same query vars.
    if ( 'app' === $path || 0 === strpos( $path, 'app/' ) ) {
        $wp->query_vars = array(
            'ridego_legacy_app'      => '1',
            'ridego_legacy_app_path' => 'app' === $path ? '' : substr( $path, 4 ),
        );
        return;
    }

    // /routes/ index page: matched BEFORE the per-slug rule below so a bare
    // /routes/ request is never treated as a slug lookup for slug "".
    if ( preg_match( '#^routes/?$#', $path ) ) {
        $wp->query_vars = array(
            'ridego_app'          => '1',
            'ridego_routes_index' => '1',
        );
        return;
    }

    // Route-marketing pages: capture the slug exactly as the rewrite
    // rule above did, so ridego_app_render_shell() can still inject
    // real per-route SEO/meta.
    if ( preg_match( '#^routes/([^/]+)/?$#', $path, $m ) ) {
        $wp->query_vars = array(
            'ridego_app'        => '1',
            'ridego_route_slug' => $m[1],
        );
        return;
    }

    // Everything else (including the bare root) is the SPA shell —
    // decided here, overriding whatever core's own rewrite matching
    // (right or wrong) produced, before query_posts() reads it.
    $wp->query_vars = array( 'ridego_app' => '1' );
}

/**
 * One-time (per version) rewrite-rule flush, so a plugin update that
 * changes the rewrite rule doesn't require the admin to manually visit
 * Settings → Permalinks. Cheap: a single option compare on admin_init.
 */
add_action( 'admin_init', 'ridego_app_maybe_flush_rewrites' );
function ridego_app_maybe_flush_rewrites() {
    $flushed_for = get_option( 'ridego_app_rewrite_flushed_for' );
    if ( $flushed_for === RIDEGO_VER ) { return; }
    ridego_app_register_rewrite();
    flush_rewrite_rules();
    update_option( 'ridego_app_rewrite_flushed_for', RIDEGO_VER );
}

// Priority 5, not the default 10: WordPress core's own redirect_canonical()
// is hooked onto 'template_redirect' at priority 10, and for a request like
// /app/manifest.webmanifest — which matches no WP object (post, page, term)
// — it 301-redirects to add a trailing slash before this ever got a chance
// to run. Running earlier serves the real static file (or the SPA shell)
// first, so that redirect never fires for anything under /app/ at all.
add_action( 'template_redirect', 'ridego_app_maybe_serve_shell', 5 );
function ridego_app_maybe_serve_shell() {
    // Backward compatibility: the app used to be mounted at /app/... — a
    // bookmarked or shared link in that form is 301-redirected to its new,
    // unprefixed URL rather than left to 404.
    if ( get_query_var( 'ridego_legacy_app' ) ) {
        $path = trim( (string) get_query_var( 'ridego_legacy_app_path' ), '/' );
        $qs   = isset( $_SERVER['QUERY_STRING'] ) ? (string) $_SERVER['QUERY_STRING'] : '';
        $dest = home_url( '/' . $path );
        if ( $qs !== '' ) {
            $dest .= '?' . $qs;
        }
        wp_safe_redirect( esc_url_raw( $dest ), 301 );
        exit;
    }

    if ( get_query_var( 'ridego_app' ) ) {
        if ( ridego_app_maybe_serve_static_pwa_file() ) {
            exit;
        }
        $route_slug = get_query_var( 'ridego_route_slug' );
        if ( $route_slug !== '' && ! ridego_route_page_public_data( (string) $route_slug ) ) {
            // No such route page, or it exists but isn't published yet — a
            // draft/needs_review page must never be reachable at its public
            // URL (same rule the REST endpoint already enforces), so this
            // falls through to WordPress's own real 404 rather than serving
            // the generic SPA shell as if the page existed.
            global $wp_query;
            $wp_query->set_404();
            status_header( 404 );
            nocache_headers();
            ridego_app_no_page_cache();
            header( 'Content-Type: text/html; charset=utf-8' );
            echo '<!doctype html><html><head><meta charset="utf-8"><title>' . esc_html__( 'Page not found', 'ridego' ) . '</title></head><body style="font-family:system-ui;padding:60px;text-align:center;color:#334155;"><h1>404 &mdash; Page not found</h1><p>The route page you requested does not exist or is not published.</p></body></html>';
            exit;
        }
        ridego_app_no_page_cache();
        $is_routes_index = (bool) get_query_var( 'ridego_routes_index' );
        ridego_app_render_shell(
            $route_slug !== '' ? (string) $route_slug : null,
            $is_routes_index,
            // Only the per-route marketing page and the /routes/ index are
            // meant to be crawled/indexed. Every other SPA path reached via
            // the generic catch-all (booking flow, confirmation, client/
            // vendor/admin dashboards, auth, tracking, search results, etc.)
            // is a private/app-state screen, not marketing content, and must
            // never be indexable — see ridego_app_render_shell()'s noindex
            // handling below.
            // NOTE: is_front_page()/is_home() can't be used to detect the
            // homepage here — the 'parse_request' override above sets no
            // recognisable query var for the root path, so core's WP_Query
            // defaults an unmatched query to "home", making is_front_page()
            // true for EVERY generic catch-all path (booking flow, vendor
            // dashboard, etc.), not just the real root. Checking the actual
            // request path directly is what the root-detection above
            // (ridego_app_maybe_serve_shell()'s own root branch) already
            // does, so this branch only ever runs for a non-root path —
            // detect the true root the same explicit way.
            ( $route_slug !== '' || $is_routes_index || '' === trim( (string) wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '/' ), PHP_URL_PATH ), '/' ) )
        );
        exit;
    }

    // ROOT-CAUSE FIX: "genuinely plug-and-play, zero manual setup"
    // requires that visiting the bare site domain — not just
    // /app/ — puts the visitor straight into the platform. Before
    // this, only /app/... was rewritten to the SPA shell; a fresh
    // visitor typing the domain root got whatever WordPress's
    // default front-page resolution produced (the active theme's
    // home template, or a legacy shortcode page if one happened to
    // be set as the WP front page) — not the React app at all,
    // which is the single most important violation of "activating
    // the plugin alone makes the complete platform available."
    // is_front_page() is true for exactly the site root under
    // WordPress's normal front-page resolution (whether show_on_front
    // is 'posts' or 'page'), so this doesn't need its own rewrite
    // rule or a redirect round-trip — it serves the same SPA shell
    // directly for the root request, no WP Page assignment required.
    //
    // ROOT-CAUSE FIX: core's XML sitemaps (wp-sitemap.xml and friends,
    // registered in wp-includes/sitemaps.php) render on 'template_redirect'
    // at the DEFAULT priority (10) — one tick after this function's own
    // priority-5 hook. Before this check, a sitemap request (which sets no
    // is_page()/is_single()/etc-recognised query var of its own) was
    // indistinguishable from a bare front-page request to is_front_page(),
    // so it was getting the SPA shell instead of ever reaching core's
    // sitemap renderer. Bailing out here for a real 'sitemap' or
    // 'sitemap-stylesheet' query var lets that run as WordPress intends.
    if ( get_query_var( 'sitemap' ) || get_query_var( 'sitemap-stylesheet' ) ) {
        return;
    }

    if ( is_front_page() && ! is_admin() ) {
        ridego_app_no_page_cache();
        ridego_app_render_shell( null, false, true );
        exit;
    }
}

/**
 * ROOT-CAUSE FIX: the SPA shell's HTML is personalized per-request —
 * window.__RIDEGO__.auth carries the *current visitor's* login state,
 * name and admin capabilities (see ridego_app_bootstrap_payload()) —
 * so it must never be served from a full-page cache. nocache_headers()
 * inside ridego_app_render_shell() only sets HTTP response headers,
 * which is too late for the page-cache plugins WordPress sites
 * commonly run (WP Rocket, WP Super Cache, W3 Total Cache, LiteSpeed
 * Cache, WP Fastest Cache): those buffer the page output starting at
 * `init` — before template_redirect ever runs — and decide whether to
 * persist that buffer to disk at shutdown by checking constants like
 * DONOTCACHEPAGE, not by inspecting outgoing headers. Without this, a
 * logged-out visitor's first request gets cached and is then replayed
 * to every subsequent visitor, including logged-in admins, who would
 * see that cached anonymous page and appear "logged out" no matter
 * what their real WordPress session says — exactly the symptom this
 * fixes. Defining the constant here, before any output is produced,
 * reaches those plugins in time; the LiteSpeed-specific action covers
 * the one major plugin that does not honor the constant convention.
 */
function ridego_app_no_page_cache() {
    if ( ! defined( 'DONOTCACHEPAGE' ) ) {
        define( 'DONOTCACHEPAGE', true );
    }
    if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
        define( 'DONOTCACHEOBJECT', true );
    }
    if ( ! defined( 'DONOTCACHEDB' ) ) {
        define( 'DONOTCACHEDB', true );
    }
    if ( function_exists( 'do_action' ) ) {
        do_action( 'litespeed_control_set_nocache', 'ridego-app-personalized-shell' );
    }
}

/**
 * ROOT-CAUSE FIX (mobile-first transformation, Phase 4 — PWA): the
 * `^app(/.*)?$` rewrite rule above is a catch-all for the client-side
 * router, so every request under /app/ used to fall straight through to
 * ridego_app_render_shell() and get back the SPA's index.html — even
 * for the PWA's own static files (manifest.webmanifest, sw.js,
 * registerSW.js, the workbox runtime chunk, and the icon PNGs), all of
 * which Vite/vite-plugin-pwa emit as root-relative URLs. JS/CSS bundle
 * chunks never had this problem because ridego_app_render_shell()
 * already rewrites THOSE specific tags to the plugin's real dist URL
 * (outside /app/'s rewrite scope) before printing the shell — but a
 * service worker's default registration scope is the directory it's
 * served FROM, so sw.js has to be reachable at a URL under /app/
 * itself (not the plugin's /wp-content/... URL) for `scope: '/app/'` in
 * the manifest to be achievable at all. This intercepts exactly that
 * short, explicit whitelist of filenames and streams the real built
 * file from app/dist/ with the right Content-Type, instead of letting
 * them fall through to the SPA shell.
 */
function ridego_app_maybe_serve_static_pwa_file() {
    $path = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ) : '';
    $sub  = trim( (string) $path, '/' );

    $known = array(
        'manifest.webmanifest' => 'application/manifest+json',
        'sw.js'                => 'text/javascript',
        'registerSW.js'        => 'text/javascript',
        'favicon.svg'          => 'image/svg+xml',
    );

    $content_type = isset( $known[ $sub ] ) ? $known[ $sub ] : null;
    if ( ! $content_type && preg_match( '#^workbox-[A-Za-z0-9]+\.js$#', $sub ) ) {
        $content_type = 'text/javascript';
    }
    if ( ! $content_type && preg_match( '#^icons/[A-Za-z0-9._-]+\.png$#', $sub ) ) {
        $content_type = 'image/png';
    }
    if ( ! $content_type ) {
        return false;
    }

    // Belt-and-braces: $sub only ever matched one of the fixed/whitelisted
    // patterns above (none of which can contain "../"), but resolving
    // realpath() and re-confirming it's still inside RIDEGO_APP_DIR costs
    // nothing and closes the loop completely against any future pattern
    // change that might accidentally allow traversal.
    $real_dir  = realpath( RIDEGO_APP_DIR );
    $real_file = realpath( RIDEGO_APP_DIR . $sub );
    if ( ! $real_dir || ! $real_file || strpos( $real_file, $real_dir ) !== 0 || ! is_file( $real_file ) ) {
        return false;
    }

    nocache_headers();
    header( 'Content-Type: ' . $content_type );
    if ( 'manifest.webmanifest' === $sub && function_exists( 'ridego_branding_public' ) ) {
        // The web-app manifest carries the brand name, so it is generated from the central branding config on every request.
        $m = json_decode( (string) file_get_contents( $real_file ), true );
        if ( is_array( $m ) ) {
            $b = ridego_branding_public();
            $m['name'] = $b['name'] . ( $b['tagline'] !== '' ? ' - ' . $b['tagline'] : '' );
            $m['short_name'] = mb_substr( $b['name'], 0, 12 );
            if ( $b['tagline'] !== '' ) { $m['description'] = $b['tagline']; }
            echo wp_json_encode( $m ); // phpcs:ignore -- JSON built from the built manifest plus sanitised settings.
            return true;
        }
    }
    if ( 'sw.js' === $sub || 'registerSW.js' === $sub ) {
        // Opts the service worker into a scope wider than the directory
        // it's physically served from — required because sw.js's real
        // file lives under the plugin's app/dist/ path but must control
        // everything under /app/.
        header( 'Service-Worker-Allowed: ' . esc_url_raw( home_url( '/' ) ) );
    }
    readfile( $real_file ); // phpcs:ignore -- static build output, not user input.
    return true;
}

function ridego_app_render_shell( $route_slug = null, $is_routes_index = false, $is_indexable = false ) {
    $index_path = RIDEGO_APP_DIR . 'index.html';

    if ( ! file_exists( $index_path ) ) {
        status_header( 503 );
        nocache_headers();
        echo '<!doctype html><html><head><meta charset="utf-8"><title>' . esc_html( ridego_brand_name() ) . '</title></head><body style="font-family:system-ui;padding:60px;text-align:center;color:#334155;">'
            . '<h1 style="margin-bottom:8px;">' . esc_html( ridego_brand_name() ) . ' app is not built yet</h1>'
            . '<p>Run <code>npm install &amp;&amp; npm run build</code> inside the plugin\'s <code>app/</code> directory, or contact your developer.</p>'
            . '</body></html>';
        return;
    }

    $html = file_get_contents( $index_path );

    // Rewrite Vite's root-relative asset paths (/assets/...) to the
    // plugin's actual served URL, since the app is not mounted at the
    // WordPress site's domain root.
    // Matches both a root-absolute ("/assets/...") and the current
    // relative ("./assets/...") build output — see vite.config.ts's
    // `base` setting for why the build uses a relative base and why
    // this can't just assume one form. preg_replace_callback (not
    // preg_replace) because the replacement URL can itself legitimately
    // contain "$"-prefixed-looking sequences that preg_replace's plain
    // string replacement would otherwise try to interpret as backreferences.
    $app_assets_url = esc_url( RIDEGO_APP_URL ) . 'assets/';
    $html = preg_replace_callback(
        '#(src|href)="\.?/assets/#',
        function ( $m ) use ( $app_assets_url ) {
            return $m[1] . '="' . $app_assets_url;
        },
        $html
    );
    $html = str_replace( 'href="/vite.svg"', 'href="' . esc_url( RIDEGO_APP_URL ) . 'vite.svg"', $html );

    // PWA files (Phase 4): unlike the JS/CSS bundle above, these must
    // stay reachable at a URL under the domain root — not the plugin's own
    // /wp-content/... dist URL — so ridego_app_maybe_serve_static_pwa_file()
    // (the handler just above) is what actually answers these requests;
    // this only has to make sure the HTML points at the right place.
    $app_root = esc_url( home_url( '/' ) );
    $html     = str_replace( array( 'href="/favicon.svg"', 'href="./favicon.svg"' ), 'href="' . $app_root . 'favicon.svg"', $html );
    $html     = str_replace(
        array( 'href="/icons/apple-touch-icon.png"', 'href="./icons/apple-touch-icon.png"' ),
        'href="' . $app_root . 'icons/apple-touch-icon.png"',
        $html
    );
    $html     = str_replace( 'href="/manifest.webmanifest"', 'href="' . $app_root . 'manifest.webmanifest"', $html );
    $html     = str_replace( 'src="/registerSW.js"', 'src="' . $app_root . 'registerSW.js"', $html );

    // Branding (central config): page title, favicon and description come from Settings → Branding & business, never from the built HTML.
    $brand   = ridego_branding_public();
    $title   = $brand['name'] . ( $brand['tagline'] !== '' ? ' - ' . $brand['tagline'] : '' );
    $html    = preg_replace( '#<title>.*?</title>#s', '<title>' . esc_html( $title ) . '</title>', $html, 1 );
    if ( $brand['favicon_url'] !== '' ) {
        $html = preg_replace( '#<link rel="icon"[^>]*>#', '<link rel="icon" href="' . esc_url( $brand['favicon_url'] ) . '" />', $html, 1 );
    }
    $desc_tag = '<meta name="description" content="' . esc_attr( $brand['tagline'] !== '' ? $brand['tagline'] : $brand['name'] ) . '" />';
    $html    = str_replace( '</head>', $desc_tag . "\n</head>", $html );

    // Route marketing pages (/routes/{slug}): override the generic
    // branding-only title/description above with the real, published
    // page's own SEO fields, plus canonical/OG/JSON-LD — all built from the
    // exact same ridego_route_page_public_data() the caller already used to
    // decide this request should render at all (never a second, possibly
    // different, lookup), so the server-injected meta can never drift from
    // what GET /ridego/v1/routes/{slug} and the React page itself render.
    if ( $route_slug ) {
        $data = function_exists( 'ridego_route_page_public_data' ) ? ridego_route_page_public_data( $route_slug ) : null;
        if ( $data ) {
            $html = ridego_route_page_inject_seo( $html, $data );
            $html = ridego_route_page_inject_ssr_body( $html, $data );
        }
    } elseif ( $is_routes_index ) {
        // /routes/ index page: real title/description/H1/list, server-rendered
        // for crawlability, following the exact same pattern as the per-route
        // shell above — see ridego_routes_index_inject_seo()/_ssr_body().
        $routes = function_exists( 'ridego_route_pages_list_published' ) ? ridego_route_pages_list_published() : array();
        $html   = ridego_routes_index_inject_seo( $html, $routes );
        $html   = ridego_routes_index_inject_ssr_body( $html, $routes );
    }

    $bootstrap = ridego_app_bootstrap_payload();

    // ROOT-CAUSE FIX: this inline script needs a nonce="..." attribute
    // matching the 'nonce-...' value includes/security.php's CSP header
    // sent for this same request (ridego_csp_script_nonce() memoizes the
    // one value so both places use it) — an inline <script> with no
    // nonce/hash is blocked outright by any script-src that lacks
    // 'unsafe-inline', which is exactly what was silently happening here
    // before this fix (see security.php's doc comment for the full story).
    $csp_nonce   = function_exists( 'ridego_csp_script_nonce' ) ? ' nonce="' . esc_attr( ridego_csp_script_nonce() ) . '"' : '';
    $inject = '<script' . $csp_nonce . '>window.__RIDEGO__ = ' . wp_json_encode( $bootstrap ) . ';</script>' . "\n</head>";
    $html   = str_replace( '</head>', $inject, $html );

    // ROOT-CAUSE FIX: the generic SPA catch-all serves the exact same
    // index.html shell (200 OK, no distinguishing query var) for the
    // booking flow, its confirmation step, the client/vendor/admin
    // dashboards, auth screens, trip tracking and search-results pages —
    // none of which are marketing content, all of which are per-visitor
    // app state that must never end up in a search index. Only the real
    // marketing surfaces (the per-route pages, the /routes/ index, and the
    // homepage) are indexable; everything else gets both an
    // X-Robots-Tag response header (belt) and a <meta name="robots"> tag
    // (braces — some crawlers/CDNs only honour one or the other, and the
    // meta tag also protects a "view source"/browser-cache copy of the
    // response that a header wouldn't travel with).
    if ( ! $is_indexable ) {
        header( 'X-Robots-Tag: noindex, nofollow' );
        $html = str_replace( '</head>', '<meta name="robots" content="noindex, nofollow" />' . "\n</head>", $html );
    }

    nocache_headers();
    header( 'Content-Type: text/html; charset=utf-8' );
    echo $html; // phpcs:ignore -- pre-built static HTML plus a JSON-encoded bootstrap object, not raw user input.
}

/**
 * Builds the real, server-side SEO/meta/structured-data for one published
 * route marketing page and splices it into the already-branded shell HTML,
 * replacing the generic <title>/description ridego_app_render_shell() just
 * set. Every value comes straight from $data['page']/$data['content'] —
 * the same row and the same ridego_generate_route_page_content() payload
 * the public REST endpoint and the React page itself use — so there is no
 * separate source of truth to drift out of sync, and nothing here is
 * invented: a FAQ/JSON-LD block is only emitted when the real content
 * actually has FAQ data.
 */
function ridego_route_page_inject_seo( $html, $data ) {
    $page    = $data['page'];
    $content = $data['content'];
    $from    = $content['from_city'];
    $to      = $content['to_city'];

    $title = $page->seo_title !== '' ? $page->seo_title : ridego_route_page_default_seo_title( $from, $to );
    $desc  = $page->meta_description !== '' ? $page->meta_description : ridego_route_page_default_meta_description( $from, $to, (float) $content['distance_km'] );
    $url   = home_url( '/routes/' . $page->slug . '/' );

    // Replace the generic <title> the branding block above just injected.
    $html = preg_replace( '#<title>.*?</title>#s', '<title>' . esc_html( $title ) . '</title>', $html, 1 );
    // Replace the generic <meta name="description"> the branding block above just injected.
    $html = preg_replace( '#<meta name="description"[^>]*/?>#', '<meta name="description" content="' . esc_attr( $desc ) . '" />', $html, 1 );

    $tags   = array();
    $tags[] = '<link rel="canonical" href="' . esc_url( $url ) . '" />';
    $tags[] = '<meta property="og:type" content="website" />';
    $tags[] = '<meta property="og:title" content="' . esc_attr( $title ) . '" />';
    $tags[] = '<meta property="og:description" content="' . esc_attr( $desc ) . '" />';
    $tags[] = '<meta property="og:url" content="' . esc_url( $url ) . '" />';

    // BreadcrumbList — Home → Routes → this route. A real, browsable /routes/
    // index page now exists (see ridego_routes_index_inject_seo() below), so
    // the intermediate "Routes" node points at that real, distinct URL —
    // never self-referencing or identical to the final node's URL, so this
    // stays schema-valid. The visual breadcrumb in RoutePage.tsx links
    // "Routes" to that same /routes/ URL, so the JSON-LD matches the UI.
    $routes_index_url = home_url( '/routes/' );
    $breadcrumb = array(
        '@context' => 'https://schema.org',
        '@type'    => 'BreadcrumbList',
        'itemListElement' => array(
            array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => home_url( '/' ) ),
            array( '@type' => 'ListItem', 'position' => 2, 'name' => 'Routes', 'item' => $routes_index_url ),
            array( '@type' => 'ListItem', 'position' => 3, 'name' => $from . ' to ' . $to, 'item' => $url ),
        ),
    );
    $tags[] = '<script type="application/ld+json">' . wp_json_encode( $breadcrumb, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ) . '</script>';

    // TouristTrip — built only from real fields the content payload actually
    // has (name/description/distance); no aggregateRating or other field
    // this data doesn't carry is invented.
    $trip = array(
        '@context'    => 'https://schema.org',
        '@type'       => 'TouristTrip',
        'name'        => $from . ' to ' . $to . ' Cab & Taxi Service',
        'description' => $desc,
        'url'         => $url,
    );
    if ( ! empty( $content['distance_km'] ) ) {
        $trip['itinerary'] = array(
            '@type' => 'ItemList',
            'itemListElement' => array(
                array( '@type' => 'City', 'name' => $from ),
                array( '@type' => 'City', 'name' => $to ),
            ),
        );
    }
    $tags[] = '<script type="application/ld+json">' . wp_json_encode( $trip, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ) . '</script>';

    // FAQPage — only when the real content actually has FAQ Q&A pairs.
    if ( ! empty( $content['faqs'] ) && is_array( $content['faqs'] ) ) {
        $faq_items = array();
        foreach ( $content['faqs'] as $f ) {
            if ( empty( $f['q'] ) || empty( $f['a'] ) ) { continue; }
            $faq_items[] = array(
                '@type'          => 'Question',
                'name'           => $f['q'],
                'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f['a'] ),
            );
        }
        if ( $faq_items ) {
            $faq_schema = array(
                '@context'   => 'https://schema.org',
                '@type'      => 'FAQPage',
                'mainEntity' => $faq_items,
            );
            $tags[] = '<script type="application/ld+json">' . wp_json_encode( $faq_schema, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ) . '</script>';
        }
    }

    // Service/Offer — one Offer per real, currently-available vehicle type
    // on this route, priced from the exact same $content['vehicles'] payload
    // (ridego_route_page_vehicle_options()) the vehicle cards and the SSR
    // snapshot above render from. A vehicle with neither a one-way nor a
    // round-trip fare (inactive/unpriced) is simply excluded — never
    // included with a stale or zero price. "estimated" fares still get a
    // real numeric Offer.price (schema.org has no estimate flag), but never
    // an `availability` claim: this platform doesn't guarantee stock/seat
    // availability, so asserting InStock/OutOfStock would be invented, not
    // real data — same "never invent" discipline as route-pages.php.
    if ( ! empty( $content['vehicles'] ) && is_array( $content['vehicles'] ) ) {
        $offers = array();
        foreach ( $content['vehicles'] as $v ) {
            foreach ( array(
                'one_way'    => 'One-way',
                'round_trip' => 'Round trip',
            ) as $fare_key => $fare_label ) {
                $fare = isset( $v[ $fare_key ] ) ? $v[ $fare_key ] : null;
                if ( empty( $fare ) || empty( $fare['amount'] ) ) { continue; }
                $offers[] = array(
                    '@type'         => 'Offer',
                    'name'          => $v['name'] . ' — ' . $fare_label,
                    'itemOffered'   => array(
                        '@type' => 'Product',
                        'name'  => $v['name'],
                    ),
                    'price'         => (float) $fare['amount'],
                    'priceCurrency' => 'INR',
                );
            }
        }
        if ( $offers ) {
            $service = array(
                '@context'    => 'https://schema.org',
                '@type'       => 'Service',
                'serviceType' => 'Cab & Taxi Service',
                'name'        => $from . ' to ' . $to . ' Cab & Taxi Service',
                'areaServed'  => array(
                    array( '@type' => 'City', 'name' => $from ),
                    array( '@type' => 'City', 'name' => $to ),
                ),
                'provider'    => array(
                    '@type' => 'Organization',
                    'name'  => ridego_brand_name(),
                ),
                'offers'      => $offers,
            );
            $tags[] = '<script type="application/ld+json">' . wp_json_encode( $service, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ) . '</script>';
        }
    }

    return str_replace( '</head>', implode( "\n", $tags ) . "\n</head>", $html );
}

/**
 * ROOT-CAUSE FIX (route pages not crawlable without JS): before this, only
 * the <head> (title/meta/canonical/JSON-LD, via ridego_route_page_inject_seo()
 * above) was server-rendered for a /routes/{slug} request — the actual
 * visible body (H1, overview, facts, FAQs, "why book" points) lived only in
 * <div id="root"></div>, filled in by React AFTER a client-side REST fetch.
 * A plain `curl` (or any crawler that doesn't execute JS) of the URL saw an
 * empty root div and none of the real page text. This renders a genuine
 * HTML snapshot of that same content — built from the exact same $data
 * (ridego_route_page_public_data(), the same call ridego_route_page_inject_seo()
 * already used, so there's no second, possibly-drifting source of truth) —
 * directly into <div id="root">...</div> in the initial response.
 *
 * This does not attempt to be pixel-identical to the React page (no
 * Tailwind classes, no icons, no interactive booking widget) — it only has
 * to contain the real text a crawler or no-JS visitor would otherwise
 * never see. React's own createRoot(...).render() (app/src/main.tsx) does
 * a full, unconditional replace of the root element's children on mount —
 * it is not hydrateRoot() — so this server-rendered markup is simply
 * overwritten the instant the bundle boots, with no hydration-mismatch
 * warning and no double-render: the snapshot is visible only in the
 * pre-JS/no-JS HTML, never alongside the live React tree.
 */
function ridego_route_page_inject_ssr_body( $html, $data ) {
    $content = $data['content'];
    $from    = $content['from_city'];
    $to      = $content['to_city'];

    $parts = array();
    $parts[] = '<div id="ridego-ssr-snapshot" aria-hidden="false">';

    // Breadcrumb — "Routes" is now a real link to the real /routes/ index
    // page, matching both the 3-node BreadcrumbList JSON-LD above and the
    // clickable "Routes" link RoutePage.tsx itself renders.
    $parts[] = '<nav aria-label="Breadcrumb"><p>' . esc_html( ridego_brand_name() ) . ' &rsaquo; <a href="' . esc_url( home_url( '/routes/' ) ) . '">Routes</a> &rsaquo; ' . esc_html( $from . ' to ' . $to ) . '</p></nav>';

    // The one, real H1 — same text React's own default (no custom hero
    // heading) heading renders as, so there's no mismatch in substance
    // between this snapshot and what mounts a moment later.
    $h1 = $content['hero']['heading'] !== '' ? $content['hero']['heading'] : ( $from . ' to ' . $to . ' Cab & Taxi' );
    $parts[] = '<h1>' . esc_html( $h1 ) . '</h1>';
    $sub = $content['hero']['subheading'] !== '' ? $content['hero']['subheading'] : ( 'A comfortable journey from ' . $from . ' to ' . $to );
    $parts[] = '<p>' . esc_html( $sub ) . '</p>';

    // Real key facts (distance/duration/vehicle count) — same figures the
    // hero stat row shows.
    $parts[] = '<ul>'
        . '<li>Distance: ' . esc_html( $content['distance_km'] ) . ' km</li>'
        . '<li>Typical travel time: ' . esc_html( $content['journey']['typical_minutes_low'] . '-' . $content['journey']['typical_minutes_high'] ) . ' minutes</li>'
        . '<li>Vehicle options: ' . esc_html( (string) count( $content['vehicles'] ) ) . '</li>'
        . '</ul>';

    // Overview — the real, route-specific paragraph.
    $parts[] = '<h2>Route overview</h2><p>' . esc_html( $content['overview'] ) . '</p>';
    if ( ! empty( $content['travel_guide'] ) ) {
        $parts[] = '<p>' . esc_html( $content['travel_guide'] ) . '</p>';
    }

    // Available services — real, platform-supported trip types only.
    if ( ! empty( $content['services'] ) ) {
        $parts[] = '<h2>Available services on this route</h2><ul>';
        foreach ( $content['services'] as $s ) {
            $parts[] = '<li><strong>' . esc_html( $s['label'] ) . ':</strong> ' . esc_html( $s['description'] ) . '</li>';
        }
        $parts[] = '</ul>';
    }

    // Vehicle options — real names/specs/fares, same as the vehicle cards.
    if ( ! empty( $content['vehicles'] ) ) {
        $parts[] = '<h2>Choose your vehicle</h2><ul>';
        foreach ( $content['vehicles'] as $v ) {
            $fare = $v['one_way'] ?: $v['round_trip'];
            $fare_text = $fare ? ( ridego_currency_symbol() . round( $fare['amount'] ) . ( $fare['source'] === 'estimated' ? ' (estimated)' : '' ) . ( $v['one_way'] ? ', one-way' : ', round trip' ) ) : 'Fare unavailable';
            $parts[] = '<li>' . esc_html( $v['name'] ) . ' &mdash; seats ' . esc_html( (string) $v['seating_capacity'] ) . ', ' . esc_html( (string) $v['luggage_capacity'] ) . ' bags' . ( $v['ac_available'] ? ', AC' : '' ) . ' &mdash; ' . esc_html( $fare_text ) . '</li>';
        }
        $parts[] = '</ul>';
    }

    // "Why book with RideGo" trust points — real, platform-wide reasons.
    if ( ! empty( $content['why_ridego'] ) ) {
        $parts[] = '<h2>Why travel this route with ' . esc_html( ridego_brand_name() ) . '</h2><ul>';
        foreach ( $content['why_ridego'] as $w ) {
            $parts[] = '<li>' . esc_html( $w ) . '</li>';
        }
        $parts[] = '</ul>';
    }

    // FAQs — real Q&A text, matching the FAQPage JSON-LD already injected.
    if ( ! empty( $content['faqs'] ) ) {
        $parts[] = '<h2>Frequently asked questions</h2>';
        foreach ( $content['faqs'] as $f ) {
            if ( empty( $f['q'] ) || empty( $f['a'] ) ) { continue; }
            $parts[] = '<h3>' . esc_html( $f['q'] ) . '</h3><p>' . esc_html( $f['a'] ) . '</p>';
        }
    }

    $parts[] = '</div>';

    $snapshot = implode( "\n", $parts );

    // Splice into the empty root div specifically (never any other
    // "<div ...></div>" in the built HTML) so this can't accidentally
    // match and corrupt an unrelated empty element.
    $replaced = preg_replace( '#(<div id="root"[^>]*)></div>#', '$1>' . str_replace( '$', '$$', $snapshot ) . '</div>', $html, 1 );
    return $replaced !== null ? $replaced : $html;
}

/**
 * Real SEO/meta for the /routes/ index page — same splice pattern as
 * ridego_route_page_inject_seo() above, but a plain "list of routes" title
 * instead of per-route content. $routes is the same
 * ridego_route_pages_list_published() array the REST endpoint and the SSR
 * body below both use, so nothing here is a second, possibly-drifting count.
 */
function ridego_routes_index_inject_seo( $html, array $routes ) {
    $brand = ridego_brand_name();
    $title = 'All Routes' . ( $brand !== '' ? ' | ' . $brand : '' );
    $desc  = count( $routes ) > 0
        ? 'Browse all ' . count( $routes ) . ' outstation cab routes available on ' . $brand . ', with distance and starting fares.'
        : 'Browse outstation cab routes available on ' . $brand . '.';
    $url   = home_url( '/routes/' );

    $html = preg_replace( '#<title>.*?</title>#s', '<title>' . esc_html( $title ) . '</title>', $html, 1 );
    $html = preg_replace( '#<meta name="description"[^>]*/?>#', '<meta name="description" content="' . esc_attr( $desc ) . '" />', $html, 1 );

    $tags   = array();
    $tags[] = '<link rel="canonical" href="' . esc_url( $url ) . '" />';
    $tags[] = '<meta property="og:type" content="website" />';
    $tags[] = '<meta property="og:title" content="' . esc_attr( $title ) . '" />';
    $tags[] = '<meta property="og:description" content="' . esc_attr( $desc ) . '" />';
    $tags[] = '<meta property="og:url" content="' . esc_url( $url ) . '" />';

    // Home → Routes (2-node: this IS the "Routes" page itself, so there is no
    // third node — matches the 3-node breadcrumb a route detail page emits,
    // whose middle node points at this exact URL).
    $breadcrumb = array(
        '@context' => 'https://schema.org',
        '@type'    => 'BreadcrumbList',
        'itemListElement' => array(
            array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => home_url( '/' ) ),
            array( '@type' => 'ListItem', 'position' => 2, 'name' => 'Routes', 'item' => $url ),
        ),
    );
    $tags[] = '<script type="application/ld+json">' . wp_json_encode( $breadcrumb, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ) . '</script>';

    return str_replace( '</head>', implode( "\n", $tags ) . "\n</head>", $html );
}

/**
 * Server-rendered snapshot of the /routes/ index page's real content — same
 * root-div splice pattern as ridego_route_page_inject_ssr_body() above, so a
 * plain curl/crawler sees the real H1 and real route links even before the
 * SPA bundle boots and React replaces this snapshot.
 */
function ridego_routes_index_inject_ssr_body( $html, array $routes ) {
    $parts   = array();
    $parts[] = '<div id="ridego-ssr-snapshot" aria-hidden="false">';
    $parts[] = '<nav aria-label="Breadcrumb"><p>' . esc_html( ridego_brand_name() ) . ' &rsaquo; Routes</p></nav>';
    $parts[] = '<h1>Explore All Routes</h1>';
    $parts[] = '<p>Real outstation cab routes available on ' . esc_html( ridego_brand_name() ) . ', with distance and starting fares.</p>';

    if ( empty( $routes ) ) {
        $parts[] = '<p>No routes are published yet.</p>';
    } else {
        // Grouped by origin city so a long list stays scannable — the same
        // grouping a visitor would expect from an outstation route directory.
        $by_origin = array();
        foreach ( $routes as $r ) {
            $by_origin[ $r['from_city'] ][] = $r;
        }
        ksort( $by_origin );
        foreach ( $by_origin as $origin => $group ) {
            $parts[] = '<h2>From ' . esc_html( $origin ) . '</h2><ul>';
            foreach ( $group as $r ) {
                $href = home_url( '/routes/' . $r['slug'] . '/' );
                $fare_text = $r['starting_fare'] ? ( ' &mdash; from ' . ridego_currency_symbol() . round( $r['starting_fare'] ) ) : '';
                $parts[] = '<li><a href="' . esc_url( $href ) . '">' . esc_html( $r['from_city'] . ' to ' . $r['to_city'] ) . '</a>'
                    . ' &mdash; ' . esc_html( (string) round( $r['distance_km'] ) ) . ' km' . $fare_text . '</li>';
            }
            $parts[] = '</ul>';
        }
    }

    $parts[] = '</div>';
    $snapshot = implode( "\n", $parts );

    $replaced = preg_replace( '#(<div id="root"[^>]*)></div>#', '$1>' . str_replace( '$', '$$', $snapshot ) . '</div>', $html, 1 );
    return $replaced !== null ? $replaced : $html;
}

/**
 * Everything the React app needs to boot without an extra round-trip:
 * its own API base URL, a fresh REST nonce (for cookie-authenticated
 * state-changing requests — see includes/app-api.php's doc comment),
 * and the current visitor's login/user state (the same payload
 * GET /app/auth/me would return, so the app doesn't have to wait on
 * a network request just to know whether to show "Log in" or a name).
 */
function ridego_app_bootstrap_payload() {
    return array(
        'apiUrl'        => ridego_app_rest_base_url( 'ridego/v1/app' ),
        'siteUrl'       => esc_url_raw( home_url( '/' ) ),
        'appUrl'        => esc_url_raw( home_url( '/' ) ),
        'currencySymbol'=> function_exists( 'ridego_currency_symbol' ) ? ridego_currency_symbol() : '₹',
        'branding'      => function_exists( 'ridego_branding_public' ) ? ridego_branding_public() : array(),
        'auth'          => function_exists( 'ridego_app_api_current_user_payload' ) ? ridego_app_api_current_user_payload() : array( 'logged_in' => false ),
    );
}

/**
 * ROOT-CAUSE FIX: builds the REST API base URL in the query-string form
 * ("https://site/?rest_route=/ridego/v1/app") instead of the pretty-
 * permalink form rest_url() normally produces ("https://site/wp-json/
 * ridego/v1/app"). WordPress has always supported both forms as
 * first-class, equally official ways to reach the REST API — the
 * query-string form is what WordPress itself automatically falls back
 * to when pretty permalinks are off. This plugin now uses it as the
 * *default*, always, regardless of permalink settings, because of a
 * concrete real-world finding: on at least one production deployment,
 * a hosting/proxy layer in front of WordPress (an nginx/openresty
 * SPA-fallback rule scoped too broadly) was intercepting every
 * pretty-permalink URL that didn't correspond to a literal file on
 * disk — including /wp-json/... — and serving this app's own static
 * index.html instead, without the request ever reaching WordPress's
 * PHP at all. A request to the bare site root with a query string
 * (?rest_route=...) was proven, on that same deployment, to reach
 * WordPress correctly every time, because "/" always resolves to the
 * real index.php file rather than depending on rewrite-rule handling
 * of an arbitrary path. Using this form everywhere sidesteps that
 * entire class of hosting/proxy misconfiguration for every future
 * deployment, at zero functional cost — it is not a workaround
 * specific to one site, it is simply the more resilient of two
 * equally-valid, WordPress-core-supported URL forms.
 *
 * See app/src/lib/api.ts's joinApiUrl() for the client-side half of
 * this fix — every call site there builds its own "?param=value"
 * query suffix assuming it's the first "?" in the URL, so joinApiUrl()
 * is what correctly joins that onto a base URL that already has its
 * own "?rest_route=..." query string, using "&" instead of "?".
 */
function ridego_app_rest_base_url( $namespace_path ) {
    return esc_url_raw( add_query_arg( 'rest_route', '/' . ltrim( $namespace_path, '/' ), home_url( '/' ) ) );
}

/**
 * Every legacy shortcode page (ridego_create_pages(), in includes/
 * install.php) still exists so a site that hasn't rebuilt its menus
 * yet doesn't break — but the canonical, plug-and-play entry point
 * going forward is /app/, which needs no WordPress Page at all. This
 * filter makes ridego_page_url() (used throughout the legacy PHP
 * frontend and in notification templates/links) point at the new
 * app routes instead of a WP Page ID, so links sent to customers
 * already go to the real, final destination during the migration
 * rather than needing to be updated twice.
 */
/**
 * Defense-in-depth alongside the noindex meta/header emitted by
 * ridego_app_render_shell(): explicitly disallow the non-public SPA
 * sections in robots.txt too, so a crawler that ignores per-page
 * robots directives (or only ever fetches robots.txt) still doesn't
 * queue up the booking flow, confirmation step, or any dashboard for
 * indexing. The real marketing paths (/, /routes/, /routes/{slug})
 * are deliberately left crawlable.
 */
add_filter( 'robots_txt', 'ridego_app_robots_txt_disallow_private_routes', 10, 1 );
function ridego_app_robots_txt_disallow_private_routes( $output ) {
    $disallow = array(
        '/book/',
        '/confirm/',
        '/my-trips/',
        '/track/',
        '/vendor/',
        '/dashboard/',
        '/admin/',
        '/client/',
        '/login/',
        '/register/',
        '/account/',
    );
    $lines = array( '', '# RideGo: booking flow / dashboards are app state, not marketing content.' );
    foreach ( $disallow as $path ) {
        $lines[] = 'Disallow: ' . $path;
    }
    return rtrim( (string) $output ) . "\n" . implode( "\n", $lines ) . "\n";
}

add_filter( 'ridego_page_url', 'ridego_app_route_for_legacy_page_key', 10, 2 );
function ridego_app_route_for_legacy_page_key( $url, $key ) {
    $routes = array(
        'home_page_id'     => '/',
        'booking_page_id'  => '/book/',
        'confirm_page_id'  => '/confirm/', // ?booking=RG-... appended by the caller, same as before
        'my_trips_page_id' => '/my-trips/',
        'vendor_dashboard_page_id' => '/vendor/dashboard/',
        'vendor_register_page_id'  => '/vendor/register/',
        'track_page_id'    => '/track/',
        // Added after an audit found these three real, still-live
        // ridego_page_url() call sites (public/shortcodes.php) were
        // NOT covered by this filter and were still resolving to
        // legacy WP-page permalinks even after the React equivalents
        // shipped.
        'about_page_id'    => '/about/',
        'cities_page_id'   => '/search/',
        'search_page_id'   => '/search/',
    );
    if ( isset( $routes[ $key ] ) ) {
        return home_url( $routes[ $key ] );
    }
    return $url;
}
