<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   REST API — Payment gateway webhooks (Wave 2B Task 5)
   ------------------------------------------------------------
   POST /wp-json/ridego/v1/webhooks/razorpay

   Webhooks come from Razorpay's servers, never a logged-in WP
   user, so permission_callback is __return_true — authentication
   is via HMAC signature verification against the raw request
   body (ridego_verify_razorpay_webhook_signature() in
   includes/payment.php), not WP auth/nonces. Never remove the
   signature check without replacing it with an equivalent.

   Idempotency (critical — Razorpay retries webhook delivery on
   anything short of a prompt 2xx, so the SAME event can and will
   arrive more than once):
     1. Fast pre-check: if a ridego_transactions row already
        exists for this (gateway, gateway_ref) with status=
        'success', return 200 immediately without reprocessing.
     2. Structural backstop: the UNIQUE (gateway, gateway_ref)
        index added by migration 004 means that even if two
        deliveries of the same event are both in-flight at once
        and both pass step 1 before either commits, the second
        ridego_log_transaction() insert fails on the duplicate
        key — caught here and treated as "already processed",
        not as an error.
   ============================================================ */

add_action( 'rest_api_init', function () {
    register_rest_route( 'ridego/v1', '/webhooks/razorpay', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_handle_razorpay_webhook',
        'permission_callback' => '__return_true',
    ) );
} );

function ridego_handle_razorpay_webhook( WP_REST_Request $request ) {
    $raw_body  = $request->get_body();
    $signature = $request->get_header( 'x-razorpay-signature' );

    if ( ! ridego_verify_razorpay_webhook_signature( $raw_body, $signature ) ) {
        ridego_log_security_event( 'webhook_signature_invalid', array(
            'identifier' => 'razorpay_webhook',
            'severity'   => 'critical',
            'ip'         => ridego_get_client_ip(),
        ) );
        return new WP_REST_Response( array( 'error' => 'Invalid signature' ), 400 );
    }

    $payload = json_decode( $raw_body, true );
    if ( ! is_array( $payload ) || empty( $payload['event'] ) ) {
        return new WP_REST_Response( array( 'error' => 'Malformed payload' ), 400 );
    }

    $event = sanitize_text_field( $payload['event'] );

    switch ( $event ) {

        case 'payment.captured': {
            $entity = $payload['payload']['payment']['entity'] ?? array();
            $payment_id = $entity['id'] ?? '';
            $order_id   = $entity['order_id'] ?? '';

            // Subscription charges (Wave 2D) are tagged via order notes
            // rather than a separate REST route, reusing this handler's
            // signature verification + idempotency pattern.
            if ( ( $entity['notes']['type'] ?? '' ) === 'subscription_charge' ) {
                $billing_id = (int) ( $entity['notes']['billing_id'] ?? 0 );
                if ( ! $payment_id || ! $billing_id ) {
                    return new WP_REST_Response( array( 'error' => 'Missing payment_id/billing_id' ), 400 );
                }
                if ( ridego_transaction_already_processed( 'razorpay', $payment_id ) ) {
                    return new WP_REST_Response( array( 'status' => 'already_processed' ), 200 );
                }
                $ok = ridego_process_subscription_webhook_payment( $billing_id, $payment_id );
                return new WP_REST_Response( array( 'status' => $ok ? 'processed' : 'error' ), $ok ? 200 : 500 );
            }

            $booking_id = (int) ( $entity['notes']['booking_id'] ?? 0 );

            if ( ! $payment_id || ! $booking_id ) {
                return new WP_REST_Response( array( 'error' => 'Missing payment_id/booking_id' ), 400 );
            }

            if ( ridego_transaction_already_processed( 'razorpay', $payment_id ) ) {
                return new WP_REST_Response( array( 'status' => 'already_processed' ), 200 );
            }

            $ok = ridego_process_razorpay_success( $booking_id, $payment_id, $order_id, $entity );
            // ridego_process_razorpay_success() -> ridego_log_transaction() with
            // gateway_ref=$payment_id; the UNIQUE index catches a same-instant
            // concurrent duplicate delivery even though the pre-check above
            // already covers the overwhelmingly common case.
            return new WP_REST_Response( array( 'status' => $ok ? 'processed' : 'error' ), $ok ? 200 : 500 );
        }

        case 'payment.failed': {
            $entity = $payload['payload']['payment']['entity'] ?? array();
            $payment_id = $entity['id'] ?? '';
            $booking_id = (int) ( $entity['notes']['booking_id'] ?? 0 );

            if ( ! $payment_id || ! $booking_id ) {
                return new WP_REST_Response( array( 'error' => 'Missing payment_id/booking_id' ), 400 );
            }
            // Failed events are not 'success' rows, so the idempotency
            // pre-check intentionally does not short-circuit them — a
            // duplicate failed-event delivery just logs a second (harmless)
            // failure row rather than risking masking a real failure.
            ridego_process_razorpay_failure( $booking_id, $payment_id, $entity );
            return new WP_REST_Response( array( 'status' => 'processed' ), 200 );
        }

        case 'refund.processed': {
            $entity = $payload['payload']['refund']['entity'] ?? array();
            $refund_id  = $entity['id'] ?? '';
            $booking_id = (int) ( $entity['notes']['booking_id'] ?? 0 );

            if ( ! $refund_id ) {
                return new WP_REST_Response( array( 'error' => 'Missing refund_id' ), 400 );
            }
            if ( ! $booking_id && ! empty( $entity['payment_id'] ) ) {
                // Fall back to resolving the booking via the original payment id.
                global $wpdb;
                $booking_id = (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}ridego_bookings WHERE payment_gateway_id=%s LIMIT 1",
                    $entity['payment_id']
                ) );
            }
            if ( ! $booking_id ) {
                return new WP_REST_Response( array( 'error' => 'Could not resolve booking for refund' ), 400 );
            }

            if ( ridego_transaction_already_processed( 'razorpay', $refund_id ) ) {
                return new WP_REST_Response( array( 'status' => 'already_processed' ), 200 );
            }

            ridego_process_razorpay_refund( $booking_id, $refund_id, $entity );
            return new WP_REST_Response( array( 'status' => 'processed' ), 200 );
        }

        default:
            // Unhandled event types are acknowledged (2xx) so Razorpay stops
            // retrying them, but nothing is processed.
            return new WP_REST_Response( array( 'status' => 'ignored', 'event' => $event ), 200 );
    }
}
