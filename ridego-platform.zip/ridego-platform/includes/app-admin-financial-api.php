<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Phase B, wave 24: financial / wallet
   ------------------------------------------------------------
   Covers three legacy admin surfaces: admin/pages/financial.php
   (Financial Overview), admin/pages/wallet-reconciliation.php
   (full per-vendor drill-down + manual reconcile action), and the
   wallet_credit/wallet_deduct form handler inside
   admin/pages/vendors.php (manual top-up/deduction).

   Every KPI query below is copied verbatim (same WHERE clause,
   same tables, same period logic) from admin/pages/financial.php —
   not reconstructed from memory. All money-moving actions delegate
   to the existing canonical functions in includes/helpers.php
   (ridego_vendor_credit_wallet, ridego_vendor_deduct_wallet,
   ridego_reconcile_vendor_wallet) rather than re-implementing
   wallet math here — those functions already do row-level locking
   (SELECT ... FOR UPDATE inside a transaction) and this file must
   never bypass that.

   CAPABILITY GATING — a deliberate choice, documented here because
   the legacy code was inconsistent: the three legacy surfaces use
   THREE different capabilities for what is largely the same
   underlying data/action (ridego_view_financial for the overview
   page, ridego_manage_wallet for the reconciliation page + its
   reconcile action, ridego_manage_vendors for the vendor-detail
   manual credit/deduct form). Rather than silently collapsing these
   to one capability (which could grant a role more access than it
   had before) or inventing a new one, this file preserves the exact
   same three-way split so no admin role's effective permissions
   change as a side effect of this rebuild:
     - GET  /app/admin/financial/overview   → ridego_view_financial
     - GET  /app/admin/wallet/ledger        → ridego_view_financial
       (same page, same data source as the overview's wallet-ledger
       panel — admin/pages/financial.php:139-156)
     - GET  /app/admin/wallet/reconciliation → ridego_manage_wallet
     - POST /app/admin/wallet/reconcile/{vendor_id} → ridego_manage_wallet
     - POST /app/admin/wallet/credit/{vendor_id}    → ridego_manage_vendors
     - POST /app/admin/wallet/debit/{vendor_id}     → ridego_manage_vendors

   LIVE SCHEMA BUG — confirmed by direct read, fixed at the root:
   ridego_vendor_credit_wallet()/ridego_vendor_deduct_wallet()/
   ridego_reconcile_vendor_wallet() all write 'transaction_type',
   'balance_before', and 'reference_id' (also 'created_by') keys
   into a $wpdb->insert() targeting ridego_vendor_wallets, but that
   table's CREATE TABLE statement (includes/install.php) never
   defined those columns — $wpdb->insert() silently drops unknown
   keys, so this data has been discarded on every wallet transaction
   since these functions were introduced. Fixed via a new idempotent
   migration (includes/migrations.php, migration 009) that adds the
   missing columns, rather than stripping the keys and permanently
   discarding this data — see that migration's doc comment for the
   full analysis. This REST layer does not need any special handling
   for the bug itself; it simply calls the (now-fixed) canonical
   functions.

   PAYOUT/WITHDRAWAL WORKFLOW — confirmed absent from the codebase
   (no table, no admin page, no REST route anywhere) — genuinely out
   of scope for this wave; not invented here. A vendor's wallet
   balance is currently informational/lead-fee-offsetting only; there
   is no "vendor requests a payout, admin approves and pays out"
   flow. Documented in the remediation report as a real feature gap.

   Every route requires is_user_logged_in(); each individually checks
   the specific capability documented above (not a single shared
   permission_callback) since the capability differs per route.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_financial_api_routes' );
function ridego_register_app_admin_financial_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/financial/overview', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_financial_overview',
        'permission_callback' => 'ridego_app_admin_api_financial_view_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/wallet/ledger', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_wallet_ledger',
        'permission_callback' => 'ridego_app_admin_api_financial_view_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/wallet/reconciliation', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_wallet_reconciliation_report',
        'permission_callback' => 'ridego_app_admin_api_wallet_manage_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/wallet/reconcile/(?P<vendor_id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_wallet_reconcile',
        'permission_callback' => 'ridego_app_admin_api_wallet_manage_permission',
        'args'                => array( 'vendor_id' => array( 'validate_callback' => function ( $v ) { return is_numeric( $v ); } ) ),
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/wallet/credit/(?P<vendor_id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_wallet_credit',
        'permission_callback' => 'ridego_app_admin_api_wallet_vendor_permission',
        'args'                => array( 'vendor_id' => array( 'validate_callback' => function ( $v ) { return is_numeric( $v ); } ) ),
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/wallet/debit/(?P<vendor_id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_wallet_debit',
        'permission_callback' => 'ridego_app_admin_api_wallet_vendor_permission',
        'args'                => array( 'vendor_id' => array( 'validate_callback' => function ( $v ) { return is_numeric( $v ); } ) ),
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/wallet/history/(?P<vendor_id>\d+)', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_wallet_history',
        'permission_callback' => 'ridego_app_admin_api_wallet_vendor_permission',
        'args'                => array( 'vendor_id' => array( 'validate_callback' => function ( $v ) { return is_numeric( $v ); } ) ),
    ) );
}

function ridego_app_admin_api_financial_view_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_view_financial' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to view financial data.', array( 'status' => 403 ) );
    }
    return true;
}

function ridego_app_admin_api_wallet_manage_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_wallet' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage vendor wallets.', array( 'status' => 403 ) );
    }
    return true;
}

function ridego_app_admin_api_wallet_vendor_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_vendors' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage vendors.', array( 'status' => 403 ) );
    }
    return true;
}

/**
 * Same period/date-range resolution as admin/pages/financial.php:7-30 —
 * a genuine Y-m-d date pair overrides the period preset; otherwise
 * falls back to today/week/month/year presets, default 'month'. The
 * SQL-injection fix already present in the legacy page (reject
 * anything that isn't a real Y-m-d date rather than splicing raw GET
 * params into SQL) is preserved here.
 */
function ridego_app_admin_api_financial_where( WP_REST_Request $req, $date_col ) {
    global $wpdb;
    $period = sanitize_key( (string) ( $req->get_param( 'period' ) ?: 'month' ) );
    $cf_raw = sanitize_text_field( (string) $req->get_param( 'from' ) );
    $ct_raw = sanitize_text_field( (string) $req->get_param( 'to' ) );
    $cf = ''; $ct = '';
    $d1 = $cf_raw ? DateTime::createFromFormat( 'Y-m-d', $cf_raw ) : false;
    $d2 = $ct_raw ? DateTime::createFromFormat( 'Y-m-d', $ct_raw ) : false;
    if ( $d1 && $d1->format( 'Y-m-d' ) === $cf_raw ) { $cf = $cf_raw; }
    if ( $d2 && $d2->format( 'Y-m-d' ) === $ct_raw ) { $ct = $ct_raw; }

    if ( $cf && $ct ) {
        return array( $wpdb->prepare( "WHERE DATE({$date_col}) BETWEEN %s AND %s", $cf, $ct ), $period, $cf, $ct );
    }
    if ( $period === 'today' ) { return array( "WHERE DATE({$date_col})=CURDATE()", $period, $cf, $ct ); }
    if ( $period === 'week' )  { return array( "WHERE {$date_col}>=DATE_SUB(NOW(),INTERVAL 7 DAY)", $period, $cf, $ct ); }
    if ( $period === 'year' )  { return array( "WHERE YEAR({$date_col})=YEAR(NOW())", $period, $cf, $ct ); }
    return array( "WHERE MONTH({$date_col})=MONTH(NOW()) AND YEAR({$date_col})=YEAR(NOW())", 'month', $cf, $ct );
}

/** Copied verbatim from admin/pages/financial.php:32-62. */
function ridego_app_admin_api_financial_overview( WP_REST_Request $req ) {
    global $wpdb;
    $btbl = $wpdb->prefix . 'ridego_bookings';
    $vtbl = $wpdb->prefix . 'ridego_vendors';
    $ltbl = $wpdb->prefix . 'ridego_leads';
    $ttbl = $wpdb->prefix . 'ridego_transactions';

    list( $w, $period, $cf, $ct ) = ridego_app_admin_api_financial_where( $req, 'created_at' );
    $w_tx   = str_replace( 'created_at', 't.created_at', $w );
    $w_lead = str_replace( 'created_at', 'l.sent_at', $w );

    $rev    = (float) $wpdb->get_var( "SELECT COALESCE(SUM(t.amount),0) FROM $ttbl t $w_tx AND t.type='booking_payment' AND t.status='success'" );
    $bk_cnt = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT t.booking_id) FROM $ttbl t $w_tx AND t.type='booking_payment' AND t.status='success'" );
    $avg    = $bk_cnt > 0 ? $rev / $bk_cnt : 0;
    $cash   = (float) $wpdb->get_var( "SELECT COALESCE(SUM(t.amount),0) FROM $ttbl t $w_tx AND t.type='booking_payment' AND t.status='success' AND t.gateway='manual'" );
    $upi    = (float) $wpdb->get_var( "SELECT COALESCE(SUM(t.amount),0) FROM $ttbl t $w_tx AND t.type='booking_payment' AND t.status='success' AND t.gateway='razorpay'" );
    $lead_fees    = (float) $wpdb->get_var( "SELECT COALESCE(SUM(l.fee_amount),0) FROM $ltbl l $w_lead AND l.status='accepted'" );
    $wallet_float = (float) $wpdb->get_var( "SELECT COALESCE(SUM(wallet_balance),0) FROM $vtbl WHERE status='active'" );
    $gst          = (float) $wpdb->get_var( "SELECT COALESCE(SUM(gst_amount),0) FROM $btbl $w AND payment_status='verified'" );

    $payments = $wpdb->get_results(
        "SELECT t.amount,t.gateway,t.created_at as paid_at,b.booking_number,b.client_name,b.trip_type,b.pickup_city,b.drop_city
         FROM $ttbl t LEFT JOIN $btbl b ON b.id=t.booking_id $w_tx AND t.type='booking_payment' AND t.status='success'
         ORDER BY t.created_at DESC LIMIT 20"
    );

    // The vendor lead fee report needs real dates: turn the period preset into the same range the other tiles use.
    $today = current_time( 'Y-m-d' ); $lf_from = $cf; $lf_to = $ct;
    if ( ! ( $cf && $ct ) ) {
        if ( $period === 'today' ) { $lf_from = $today; }
        elseif ( $period === 'week' ) { $lf_from = wp_date( 'Y-m-d', strtotime( '-7 days', current_time( 'timestamp' ) ) ); }
        elseif ( $period === 'year' ) { $lf_from = substr( $today, 0, 4 ) . '-01-01'; }
        else { $lf_from = substr( $today, 0, 7 ) . '-01'; }
        $lf_to = $today;
    }
    $wallet_recon = ridego_get_wallet_reconciliation_report();

    $monthly = $wpdb->get_results(
        "SELECT DATE_FORMAT(created_at,'%Y-%m') as m,COUNT(*) as cnt,COALESCE(SUM(amount),0) as rev
         FROM $ttbl WHERE type='booking_payment' AND status='success' AND created_at>=DATE_SUB(NOW(),INTERVAL 12 MONTH)
         GROUP BY DATE_FORMAT(created_at,'%Y-%m') ORDER BY m ASC"
    );

    return rest_ensure_response( array(
        'period'          => $period,
        'from'            => $cf,
        'to'              => $ct,
        'total_revenue'   => $rev,
        'avg_booking'     => $avg,
        'upi_revenue'     => $upi,
        'cash_revenue'    => $cash,
        'lead_fees'       => $lead_fees,
        'vendor_lead_fee' => ridego_lead_fee_report( $lf_from, $lf_to ),
        'wallet_float'    => $wallet_float,
        'gst_collected'   => $gst,
        'recent_payments' => array_map( function ( $p ) {
            return array(
                'booking_number' => $p->booking_number,
                'client_name'    => $p->client_name,
                'pickup_city'    => $p->pickup_city,
                'drop_city'      => $p->drop_city,
                'gateway'        => $p->gateway,
                'amount'         => (float) $p->amount,
                'paid_at'        => $p->paid_at,
            );
        }, $payments ),
        'wallet_reconciliation' => $wallet_recon,
        'monthly_trend' => array_map( function ( $m ) {
            return array( 'month' => $m->m, 'count' => (int) $m->cnt, 'revenue' => (float) $m->rev );
        }, $monthly ),
    ) );
}

/** Copied verbatim from admin/pages/financial.php:55-56 (wallet ledger panel). */
function ridego_app_admin_api_wallet_ledger( WP_REST_Request $req ) {
    global $wpdb;
    $vtbl = $wpdb->prefix . 'ridego_vendors';
    $wtbl = $wpdb->prefix . 'ridego_vendor_wallets';

    list( $w ) = ridego_app_admin_api_financial_where( $req, 'created_at' );
    $w_wallet = str_replace( 'created_at', 'wt.created_at', $w );

    $rows = $wpdb->get_results(
        "SELECT wt.*,v.business_name FROM {$wtbl} wt LEFT JOIN $vtbl v ON v.id=wt.vendor_id $w_wallet ORDER BY wt.created_at DESC LIMIT 20"
    );

    return rest_ensure_response( array(
        'rows' => array_map( 'ridego_app_admin_api_wallet_row_format', $rows ),
    ) );
}

/**
 * Shared row formatter for wallet ledger rows — used by both the
 * dashboard-wide ledger panel and the per-vendor history endpoint so
 * the two never drift into different shapes.
 */
function ridego_app_admin_api_wallet_row_format( $w ) {
    return array(
        'id'                => (int) $w->id,
        'vendor_id'         => (int) $w->vendor_id,
        'business_name'     => isset( $w->business_name ) ? $w->business_name : null,
        'type'              => $w->type,
        'transaction_type'  => isset( $w->transaction_type ) ? $w->transaction_type : '',
        'amount'            => (float) $w->amount,
        'balance_before'    => isset( $w->balance_before ) ? ( $w->balance_before === null ? null : (float) $w->balance_before ) : null,
        'balance_after'     => (float) $w->balance_after,
        'booking_id'        => $w->booking_id,
        'reference_id'      => isset( $w->reference_id ) ? $w->reference_id : null,
        'notes'             => $w->notes,
        'created_at'        => $w->created_at,
    );
}

/**
 * Full per-vendor drill-down report — built from the same lower-level
 * primitive (ridego_verify_wallet_integrity) as
 * admin/pages/wallet-reconciliation.php:34-60, so every vendor is
 * covered, not just the discrepant ones
 * ridego_get_wallet_reconciliation_report() filters to.
 */
function ridego_app_admin_api_wallet_reconciliation_report( WP_REST_Request $req ) {
    global $wpdb;
    $vtbl = $wpdb->prefix . 'ridego_vendors';
    $ltbl = $wpdb->prefix . 'ridego_vendor_wallets';

    $vendors = $wpdb->get_results( "SELECT id, business_name FROM {$vtbl} ORDER BY business_name ASC" );
    $last_ledger_rows = $wpdb->get_results( "SELECT vendor_id, MAX(created_at) as last_at FROM {$ltbl} GROUP BY vendor_id", OBJECT_K );

    $report = array();
    $discrepancy_count = 0;
    $total_discrepancy_abs = 0.0;
    foreach ( $vendors as $v ) {
        $r = ridego_verify_wallet_integrity( (int) $v->id );
        $last_at = isset( $last_ledger_rows[ $v->id ] ) ? $last_ledger_rows[ $v->id ]->last_at : null;
        $report[] = array(
            'vendor_id'      => (int) $v->id,
            'vendor_name'    => $v->business_name,
            'stored_balance' => $r['stored_balance'],
            'ledger_balance' => $r['ledger_balance'],
            'discrepancy'    => $r['discrepancy'],
            'ok'             => $r['ok'],
            'last_ledger_at' => $last_at,
        );
        if ( ! $r['ok'] ) {
            $discrepancy_count++;
            $total_discrepancy_abs += abs( $r['discrepancy'] );
        }
    }

    usort( $report, function ( $a, $b ) {
        if ( $a['ok'] !== $b['ok'] ) { return $a['ok'] ? 1 : -1; }
        if ( ! $a['ok'] ) { return abs( $b['discrepancy'] ) <=> abs( $a['discrepancy'] ); }
        return strcasecmp( $a['vendor_name'], $b['vendor_name'] );
    } );

    // Same "record + surface previous run" behavior as the legacy page.
    $prev_run = get_option( 'ridego_wallet_recon_last_run', '' );
    update_option( 'ridego_wallet_recon_last_run', current_time( 'mysql' ) );

    return rest_ensure_response( array(
        'rows'              => $report,
        'checked'           => count( $report ),
        'discrepancy_count' => $discrepancy_count,
        'total_discrepancy_abs' => $total_discrepancy_abs,
        'previous_run_at'   => $prev_run ?: null,
    ) );
}

/**
 * Reconcile a single vendor's wallet — delegates entirely to
 * ridego_reconcile_vendor_wallet(), which does the row-lock + ledger
 * recompute + corrective ledger entry + audit log. This endpoint does
 * no wallet math of its own.
 */
function ridego_app_admin_api_wallet_reconcile( WP_REST_Request $req ) {
    $vendor_id = (int) $req->get_param( 'vendor_id' );
    $reason    = trim( sanitize_textarea_field( (string) $req->get_param( 'reason' ) ) );
    if ( $reason === '' ) {
        return new WP_Error( 'missing_reason', 'A reason is required to reconcile a wallet discrepancy.', array( 'status' => 400 ) );
    }
    $r = ridego_reconcile_vendor_wallet( $vendor_id, $reason );
    if ( empty( $r['success'] ) ) {
        return new WP_Error( 'reconcile_failed', isset( $r['message'] ) ? $r['message'] : 'Reconciliation failed.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( $r );
}

/**
 * Manual wallet top-up — delegates to ridego_vendor_credit_wallet(),
 * exactly matching admin/pages/vendors.php's wallet_credit handler
 * (same default notes text, same audit_log call, same amount
 * validation: must be a positive number).
 */
function ridego_app_admin_api_wallet_credit( WP_REST_Request $req ) {
    $vendor_id = (int) $req->get_param( 'vendor_id' );
    $amount    = (float) $req->get_param( 'amount' );
    $notes     = sanitize_text_field( (string) ( $req->get_param( 'notes' ) ?: 'Admin top-up' ) );
    if ( $amount <= 0 ) {
        return new WP_Error( 'invalid_amount', 'Amount must be greater than zero.', array( 'status' => 400 ) );
    }
    $r = ridego_vendor_credit_wallet( $vendor_id, $amount, null, $notes );
    if ( empty( $r['success'] ) ) {
        return new WP_Error( 'credit_failed', isset( $r['message'] ) ? $r['message'] : 'Credit failed.', array( 'status' => 400 ) );
    }
    ridego_audit_log( 'wallet_topup', 'vendor', $vendor_id, '0', $amount );
    return rest_ensure_response( $r );
}

/**
 * Manual wallet deduction — delegates to ridego_vendor_deduct_wallet(),
 * matching admin/pages/vendors.php's wallet_deduct handler.
 */
function ridego_app_admin_api_wallet_debit( WP_REST_Request $req ) {
    $vendor_id = (int) $req->get_param( 'vendor_id' );
    $amount    = (float) $req->get_param( 'amount' );
    $notes     = sanitize_text_field( (string) ( $req->get_param( 'notes' ) ?: 'Admin deduction' ) );
    if ( $amount <= 0 ) {
        return new WP_Error( 'invalid_amount', 'Amount must be greater than zero.', array( 'status' => 400 ) );
    }
    $r = ridego_vendor_deduct_wallet( $vendor_id, $amount, null, $notes );
    if ( empty( $r['success'] ) ) {
        return new WP_Error( 'debit_failed', isset( $r['message'] ) ? $r['message'] : 'Deduction failed.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( $r );
}

/**
 * Per-vendor wallet ledger history — delegates to the existing
 * ridego_get_vendor_wallet_history() (includes/vendor.php:393),
 * paginated the same way that function already supports
 * (limit/offset), reusing the shared row formatter above.
 */
function ridego_app_admin_api_wallet_history( WP_REST_Request $req ) {
    $vendor_id = (int) $req->get_param( 'vendor_id' );
    $limit     = max( 1, min( 100, (int) ( $req->get_param( 'limit' ) ?: 30 ) ) );
    $page      = max( 1, (int) $req->get_param( 'page' ) );
    $offset    = ( $page - 1 ) * $limit;

    $rows = ridego_get_vendor_wallet_history( $vendor_id, $limit, $offset );

    return rest_ensure_response( array(
        'rows'  => array_map( 'ridego_app_admin_api_wallet_row_format', $rows ),
        'page'  => $page,
        'limit' => $limit,
    ) );
}
