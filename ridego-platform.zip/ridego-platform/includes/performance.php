<?php
/**
 * RideGo Platform - Performance Optimization
 * Session 6: Production performance enhancements
 */

if (!defined('ABSPATH')) exit;

/**
 * Cache frequently accessed data
 */
class RideGo_Cache {
    
    private static $cache = array();
    
    /**
     * Get cached data
     */
    public static function get($key) {
        
        // Check runtime cache first
        if (isset(self::$cache[$key])) {
            return self::$cache[$key];
        }
        
        // Check WordPress transient
        $cached = get_transient('ridego_' . $key);
        
        if ($cached !== false) {
            self::$cache[$key] = $cached;
            return $cached;
        }
        
        return false;
    }
    
    /**
     * Set cached data
     */
    public static function set($key, $value, $expiration = 3600) {
        
        // Set in runtime cache
        self::$cache[$key] = $value;
        
        // Set in WordPress transient
        set_transient('ridego_' . $key, $value, $expiration);
    }
    
    /**
     * Delete cached data
     */
    public static function delete($key) {
        
        unset(self::$cache[$key]);
        delete_transient('ridego_' . $key);
    }
    
    /**
     * Clear all RideGo cache
     */
    public static function clear_all() {
        
        global $wpdb;
        
        self::$cache = array();
        
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_ridego_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_ridego_%'");
    }
}

/**
 * Optimize database queries
 */
function ridego_optimize_queries() {
    
    global $wpdb;
    
    // Add indexes if not exist
    $tables = array(
        $wpdb->prefix . 'ridego_bookings' => array(
            'idx_journey_date' => 'journey_date',
            'idx_status' => 'status',
            'idx_created' => 'created_at'
        ),
        $wpdb->prefix . 'ridego_vendors' => array(
            'idx_status' => 'status',
            'idx_city' => 'city'
        )
    );
    
    foreach ($tables as $table => $indexes) {
        foreach ($indexes as $index_name => $column) {
            $wpdb->query("CREATE INDEX IF NOT EXISTS {$index_name} ON {$table}({$column})");
        }
    }
}

/**
 * Lazy load images
 */
function ridego_lazy_load_images($content) {
    
    if (is_admin()) {
        return $content;
    }
    
    // Add loading="lazy" to images
    $content = preg_replace('/<img((?![^>]*loading=)[^>]*)>/i', '<img$1 loading="lazy">', $content);
    
    return $content;
}
add_filter('the_content', 'ridego_lazy_load_images');

/**
 * Minify HTML output
 */
function ridego_minify_html($html) {
    
    if (is_admin()) {
        return $html;
    }
    
    // Remove comments
    $html = preg_replace('/<!--(?!<!)[^\[>].*?-->/s', '', $html);
    
    // Remove whitespace
    $html = preg_replace('/\s+/', ' ', $html);
    
    return $html;
}

// Uncomment to enable HTML minification
// add_action('template_redirect', function() {
//     ob_start('ridego_minify_html');
// });

/**
 * Defer non-critical JavaScript
 */
function ridego_defer_scripts($tag, $handle) {
    
    $defer_scripts = array('ridego-public', 'ridego-booking', 'ridego-maps');
    
    if (in_array($handle, $defer_scripts)) {
        return str_replace(' src', ' defer src', $tag);
    }
    
    return $tag;
}
add_filter('script_loader_tag', 'ridego_defer_scripts', 10, 2);

/**
 * Cache vehicle types
 */
function ridego_get_cached_vehicles() {
    
    $vehicles = RideGo_Cache::get('vehicles');
    
    if ($vehicles === false) {
        global $wpdb;
        $vehicles = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ridego_vehicles WHERE is_active = 1 ORDER BY sort_order ASC");
        RideGo_Cache::set('vehicles', $vehicles, DAY_IN_SECONDS);
    }
    
    return $vehicles;
}

/**
 * Cache cities
 */
function ridego_get_cached_cities() {
    
    $cities = RideGo_Cache::get('cities');
    
    if ($cities === false) {
        global $wpdb;
        $cities = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ridego_cities WHERE is_active = 1 ORDER BY name ASC");
        RideGo_Cache::set('cities', $cities, DAY_IN_SECONDS);
    }
    
    return $cities;
}

/**
 * Clear cache on data updates
 */
function ridego_clear_cache_on_update($post_id, $post) {
    
    if ($post->post_type === 'ridego_vehicle' || $post->post_type === 'ridego_city') {
        RideGo_Cache::delete('vehicles');
        RideGo_Cache::delete('cities');
    }
}
add_action('save_post', 'ridego_clear_cache_on_update', 10, 2);

/**
 * Optimize assets loading
 */
function ridego_optimize_assets() {
    
    // Only load on RideGo pages
    if (!ridego_is_ridego_page()) {
        return;
    }
    
    // Dequeue unnecessary scripts
    wp_dequeue_script('wp-embed');
    
    // Remove emoji scripts
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
}
add_action('wp_enqueue_scripts', 'ridego_optimize_assets', 100);

/**
 * Check if current page is RideGo page
 */
function ridego_is_ridego_page() {
    
    global $post;
    
    if (!$post) {
        return false;
    }
    
    $ridego_pages = array(
        get_option('ridego_booking_page_id'),
        get_option('ridego_search_page_id'),
        get_option('ridego_vendor_dashboard_page_id')
    );
    
    return in_array($post->ID, $ridego_pages) || has_shortcode($post->post_content, 'ridego_');
}

/**
 * Database cleanup - Remove old data
 */
function ridego_cleanup_old_data() {
    
    global $wpdb;
    
    // Delete OTPs older than 7 days
    $wpdb->query("DELETE FROM {$wpdb->prefix}ridego_otp WHERE created_at < DATE_SUB(NOW(), INTERVAL 7 DAY)");
    
    // Delete notification queue entries older than 30 days
    $wpdb->query("DELETE FROM {$wpdb->prefix}ridego_notification_queue WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");

    // NOTE: this function intentionally does NOT purge ridego_audit_log or
    // ridego_security_log. It used to delete audit_log rows after only 90
    // days, which is far too short for a financial/security audit trail —
    // compliance and incident-investigation needs (chargebacks, disputes,
    // "who approved this KYC / issued this refund six months ago") routinely
    // span well beyond 90 days, and a 90-day purge would have silently
    // destroyed evidence needed for exactly the kind of investigation an
    // audit log exists for. Audit/security log retention is governed
    // separately by the `ridego_audit_log_retention_days` setting (default
    // 730 days / 2 years, configurable in Settings > Advanced) via
    // ridego_cleanup_audit_logs() below, which is operational-data cleanup's
    // opposite: something an admin has to opt into shortening, not a
    // default that quietly runs weekly.
    ridego_cleanup_audit_logs();
}

/**
 * Purge audit_log / security_log rows older than the configured retention
 * period (default 730 days = 2 years — see the comment in
 * ridego_cleanup_old_data() above for why this is intentionally much
 * longer than the 30/7-day windows used for operational data above).
 */
function ridego_cleanup_audit_logs() {
    global $wpdb;
    $retention_days = (int) ridego_get_setting( 'ridego_audit_log_retention_days', 730 );
    if ( $retention_days < 90 ) { $retention_days = 90; } // floor: never allow accidental near-zero retention
    $cutoff = $wpdb->prepare( 'DATE_SUB(NOW(), INTERVAL %d DAY)', $retention_days );
    $wpdb->query( "DELETE FROM {$wpdb->prefix}ridego_audit_log WHERE created_at < {$cutoff}" );
    $wpdb->query( "DELETE FROM {$wpdb->prefix}ridego_security_log WHERE created_at < {$cutoff}" );
}

// Schedule weekly cleanup
if (!wp_next_scheduled('ridego_weekly_cleanup')) {
    wp_schedule_event(time(), 'weekly', 'ridego_weekly_cleanup');
}
add_action('ridego_weekly_cleanup', 'ridego_cleanup_old_data');
