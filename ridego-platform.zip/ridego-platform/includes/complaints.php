<?php
/**
 * RideGo - Complaints Management (Session 5 - Complete)
 */
if (!defined('ABSPATH')) exit;

/**
 * File a new complaint.
 *
 * Expected $data keys:
 *   booking_id      (required)
 *   raised_by_id    numeric ID of whoever is filing (required)
 *   raised_by_type  'client'|'vendor'|'admin' (default 'client')
 *   category        (required)
 *   sub_category    (optional)
 *   description     (required)
 *   evidence_urls   (optional)
 *   priority        (optional — auto-derived from category if not passed)
 */
// TRACE: client/vendor/admin files a complaint → validates fields, inserts, audits and fires ridego_complaint_filed(id,data) so service events can be recorded → array(success,id,complaint_id).
//        Preconditions: booking_id, category, description present → Postconditions: one row, one hook fired → Edge cases: missing filer, missing fields, insert failure (no hook).
function ridego_file_complaint($data) {
    global $wpdb;

    $raised_by_type = sanitize_text_field($data['raised_by_type'] ?? 'client');
    if (!in_array($raised_by_type, array('client', 'vendor', 'admin'), true)) {
        $raised_by_type = 'client';
    }

    $raised_by_id = isset($data['raised_by_id']) ? absint($data['raised_by_id']) : 0;
    if (!$raised_by_id && is_user_logged_in()) {
        $raised_by_id = get_current_user_id();
    }
    if (!$raised_by_id) {
        return array('success' => false, 'message' => 'Unable to determine who is filing this complaint.');
    }

    $category = sanitize_text_field($data['category'] ?? '');
    if ($category === '') {
        return array('success' => false, 'message' => 'Category is required.');
    }

    $priority = isset($data['priority']) ? sanitize_text_field($data['priority']) : ridego_derive_complaint_priority($category);
    if (!in_array($priority, array('urgent', 'high', 'normal', 'low'), true)) {
        $priority = 'normal';
    }

    $complaint_id = ridego_generate_complaint_id();
    $sla_deadline = ridego_calculate_complaint_sla_deadline($priority);

    $inserted = $wpdb->insert($wpdb->prefix . 'ridego_complaints', array(
        'complaint_id'   => $complaint_id,
        'booking_id'     => absint($data['booking_id']),
        'raised_by_id'   => $raised_by_id,
        'raised_by_type' => $raised_by_type,
        'category'       => $category,
        'sub_category'   => sanitize_text_field($data['sub_category'] ?? ''),
        'description'    => sanitize_textarea_field($data['description'] ?? ''),
        'evidence_urls'  => sanitize_textarea_field($data['evidence_urls'] ?? ''),
        'status'         => 'open',
        'priority'       => $priority,
        'sla_deadline'   => $sla_deadline,
        'created_at'     => current_time('mysql'),
        'updated_at'     => current_time('mysql'),
    ));

    if (!$inserted) {
        return array('success' => false, 'message' => 'Could not save complaint: ' . $wpdb->last_error);
    }

    $id = $wpdb->insert_id;

    if (function_exists('ridego_audit_log')) {
        ridego_audit_log('complaint_filed', 'complaint', $id, null, array(
            'complaint_id'   => $complaint_id,
            'booking_id'     => absint($data['booking_id']),
            'category'       => $category,
            'priority'       => $priority,
            'raised_by_type' => $raised_by_type,
        ));
    }

    do_action( 'ridego_complaint_filed', (int) $id, array( 'booking_id' => absint( $data['booking_id'] ), 'category' => $category, 'raised_by_type' => $raised_by_type ) );

    return array('success' => true, 'id' => $id, 'complaint_id' => $complaint_id);
}

/**
 * Derive an initial priority from complaint category.
 * Categories that indicate safety/financial risk get escalated priority by default;
 * the assigned agent can still change it later.
 */
function ridego_derive_complaint_priority($category) {
    $category = strtolower(trim($category));

    $urgent_categories = array('safety', 'accident', 'harassment', 'assault', 'emergency');
    $high_categories    = array('payment_dispute', 'overcharge', 'fraud', 'no_show', 'driver_misconduct', 'vehicle_condition');
    $low_categories     = array('feedback', 'suggestion', 'general_query');

    foreach ($urgent_categories as $needle) {
        if (strpos($category, $needle) !== false) return 'urgent';
    }
    foreach ($high_categories as $needle) {
        if (strpos($category, $needle) !== false) return 'high';
    }
    foreach ($low_categories as $needle) {
        if (strpos($category, $needle) !== false) return 'low';
    }

    return 'normal';
}

/**
 * SLA hours per priority — configurable via Settings (falls back to sane defaults).
 */
function ridego_get_complaint_sla_hours($priority) {
    $defaults = array(
        'urgent' => 4,
        'high'   => 24,
        'normal' => 72,
        'low'    => 168, // 1 week
    );
    $default = $defaults[$priority] ?? $defaults['normal'];
    return (float) ridego_get_setting('complaint_sla_hours_' . $priority, $default);
}

/**
 * Compute the SLA deadline datetime (MySQL format, site timezone) for a given priority.
 */
function ridego_calculate_complaint_sla_deadline($priority) {
    $hours = ridego_get_complaint_sla_hours($priority);
    $ts = current_time('timestamp') + ($hours * HOUR_IN_SECONDS);
    return date('Y-m-d H:i:s', $ts);
}
