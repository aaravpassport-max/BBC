<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
/* SEO pages - built in Session 8 */
