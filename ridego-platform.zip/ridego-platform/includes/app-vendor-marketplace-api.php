<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Vendor API — marketplace additions (fleet, lead interest,
   assignment changes, settlements, performance, client rating).
   Every route requires a logged-in user who owns a vendor account; every
   entity id in a path is re-verified against that vendor inside the domain
   function (fleet.php / lead-response.php / assignments.php), never trusted.
   ================================================================ */

// TRACE: any vendor marketplace route → returns merged JSON+query params as array. Pure.
function ridego_mkt_body( WP_REST_Request $req ) {
    $j = $req->get_json_params();
    return is_array( $j ) ? $j : array();
}

// TRACE: domain result array → converts to REST response or WP_Error(400/409) → mixed. Success arrays
//        pass through; a result flagged ['conflict' => true] (ridego_claim_lock_version() mismatch)
//        becomes a 409 carrying 'current_lock_version' in its error data so the client can refetch and
//        retry; every other failure becomes {code,message,status 400}. Edge cases: missing message
//        (generic).
function ridego_mkt_result( $r, $code = 'request_failed' ) {
    if ( is_array( $r ) && ! empty( $r['success'] ) ) { return rest_ensure_response( $r ); }
    $m = is_array( $r ) && ! empty( $r['message'] ) ? $r['message'] : 'The request could not be completed.';
    if ( is_array( $r ) && ! empty( $r['conflict'] ) ) {
        return new WP_Error( 'conflict', $m, array( 'status' => 409, 'current_lock_version' => $r['current_lock_version'] ?? null ) );
    }
    return new WP_Error( $code, $m, array( 'status' => 400 ) );
}

// TRACE: permission callback → logged in AND owns a vendor account whose status is currently 'active' → true|WP_Error
//        401/403. Preconditions: none. Postconditions: a suspended/blacklisted/pending vendor's own session is
//        rejected on every request from here on, even if the session/cookie was issued while still active — status
//        is re-checked fresh on every call, not just at login. Edge cases: an admin viewing this vendor via
//        impersonation ('View As') is exempt from this specific block, since that is a review action, not the
//        vendor acting on their own account — ridego_is_impersonating() distinguishes the two.
function ridego_mkt_vendor_permission() {
    if ( ! is_user_logged_in() ) { return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) ); }
    $vendor = ridego_get_current_vendor();
    if ( ! $vendor ) { return new WP_Error( 'not_a_vendor', 'No vendor account found for this user.', array( 'status' => 403 ) ); }
    $is_impersonating = function_exists( 'ridego_is_impersonating' ) && ridego_is_impersonating();
    if ( ! $is_impersonating && isset( $vendor->status ) && $vendor->status !== 'active' ) {
        return new WP_Error(
            'account_suspended',
            $vendor->status === 'pending'
                ? 'Your account is still pending approval.'
                : 'Your account has been suspended. Contact support for details.',
            array( 'status' => 403 )
        );
    }
    return true;
}

// TRACE: user_id → the active ridego_vendor_staff row for that user, if any → object|null. Preconditions: none.
//        Postconditions: a 'suspended' staff row is never returned (treated as if it did not exist). Edge cases:
//        no row at all (null), row exists but status not 'active' (null).
function ridego_get_vendor_staff_by_user( $user_id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_vendor_staff WHERE user_id=%d AND status='active' LIMIT 1", $user_id
    ) );
}

// TRACE: logged-in user → the vendor account they act on, whether as the owner (ridego_get_current_vendor) or as
//        an active staff delegate (ridego_get_vendor_staff_by_user → ridego_get_vendor by that row's vendor_id) →
//        vendor row|null. Used ONLY by the deliberately narrow fleet-management routes (RG-015) — every other
//        vendor route still calls ridego_get_current_vendor() directly and stays owner-only. Preconditions: none.
//        Postconditions: an owner always resolves via the original path unchanged; a staff member resolves to
//        their assigned vendor's row, never their own (staff have no ridego_vendors row of their own).
//        Edge cases: user is neither owner nor staff (null), staff row's vendor_id points at a deleted vendor
//        (null, since ridego_get_vendor() returns null for a missing id).
function ridego_mkt_current_vendor_for_staff() {
    $owner = ridego_get_current_vendor();
    if ( $owner ) { return $owner; }
    $staff = ridego_get_vendor_staff_by_user( get_current_user_id() );
    if ( ! $staff ) { return null; }
    return ridego_get_vendor( (int) $staff->vendor_id );
}

// TRACE: permission callback for the narrow fleet-management route subset only (GET /app/vendor/fleet,
//        vehicle/driver CRUD, unavailability, fleet docs, bulk import) → logged in AND (owns a vendor account OR
//        is an active staff delegate for one) whose vendor's status is currently 'active' → true|WP_Error 401/403.
//        Deliberately scoped: settlements, branches, leads, bookings, performance, and vendor-type-change remain
//        owner-only via ridego_mkt_vendor_permission() and are NOT reachable by staff. Preconditions: none.
//        Postconditions: a revoked ('suspended') staff row is rejected on every request from here on, re-checked
//        fresh each call, not cached from login. Edge cases: impersonation exemption mirrors the owner path.
function ridego_mkt_staff_or_owner_permission() {
    if ( ! is_user_logged_in() ) { return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) ); }
    $vendor = ridego_mkt_current_vendor_for_staff();
    if ( ! $vendor ) { return new WP_Error( 'not_a_vendor', 'No vendor account or staff access found for this user.', array( 'status' => 403 ) ); }
    $is_impersonating = function_exists( 'ridego_is_impersonating' ) && ridego_is_impersonating();
    if ( ! $is_impersonating && isset( $vendor->status ) && $vendor->status !== 'active' ) {
        return new WP_Error(
            'account_suspended',
            $vendor->status === 'pending'
                ? 'Your account is still pending approval.'
                : 'Your account has been suspended. Contact support for details.',
            array( 'status' => 403 )
        );
    }
    return true;
}

add_action( 'rest_api_init', 'ridego_register_app_vendor_marketplace_routes' );
// TRACE: rest_api_init → registers every vendor marketplace route from one table → void.
function ridego_register_app_vendor_marketplace_routes() {
    // RG-015: this subset accepts an active staff delegate as well as the vendor owner — see
    // ridego_mkt_staff_or_owner_permission(). Every other route below stays owner-only.
    $fleet_routes = array(
        array( '/app/vendor/fleet', 'GET', 'ridego_mkt_v_fleet' ),
        array( '/app/vendor/fleet/vehicles', 'POST', 'ridego_mkt_v_vehicle_create' ),
        array( '/app/vendor/fleet/vehicles/(?P<id>\d+)', 'PUT,PATCH', 'ridego_mkt_v_vehicle_update' ),
        array( '/app/vendor/fleet/vehicles/(?P<id>\d+)', 'DELETE', 'ridego_mkt_v_vehicle_delete' ),
        array( '/app/vendor/fleet/drivers', 'POST', 'ridego_mkt_v_driver_create' ),
        array( '/app/vendor/fleet/drivers/(?P<id>\d+)', 'PUT,PATCH', 'ridego_mkt_v_driver_update' ),
        array( '/app/vendor/fleet/drivers/(?P<id>\d+)', 'DELETE', 'ridego_mkt_v_driver_delete' ),
        array( '/app/vendor/fleet/unavailability', 'GET', 'ridego_mkt_v_unavail_list' ),
        array( '/app/vendor/fleet/unavailability', 'POST', 'ridego_mkt_v_unavail_create' ),
        array( '/app/vendor/fleet/unavailability/(?P<id>\d+)', 'DELETE', 'ridego_mkt_v_unavail_delete' ),
        array( '/app/vendor/fleet/docs', 'GET', 'ridego_mkt_v_fleet_docs' ),
        array( '/app/vendor/fleet/vehicles/import', 'POST', 'ridego_mkt_v_vehicles_import' ),
        array( '/app/vendor/fleet/drivers/import', 'POST', 'ridego_mkt_v_drivers_import' ),
    );
    $owner_only_routes = array(
        array( '/app/vendor/branches', 'GET', 'ridego_mkt_v_branches' ),
        array( '/app/vendor/branches', 'POST', 'ridego_mkt_v_branch_create' ),
        array( '/app/vendor/branches/(?P<id>\d+)', 'PUT,PATCH', 'ridego_mkt_v_branch_update' ),
        array( '/app/vendor/branches/(?P<id>\d+)', 'DELETE', 'ridego_mkt_v_branch_delete' ),
        array( '/app/vendor/type', 'POST', 'ridego_mkt_v_set_type' ),
        array( '/app/vendor/leads/(?P<id>\d+)/viewed', 'POST', 'ridego_mkt_v_lead_viewed' ),
        array( '/app/vendor/leads/(?P<id>\d+)/interest', 'POST', 'ridego_mkt_v_lead_interest' ),
        array( '/app/vendor/leads/(?P<id>\d+)/confirm', 'POST', 'ridego_mkt_v_lead_confirm' ),
        array( '/app/vendor/leads/(?P<id>\d+)/decline', 'POST', 'ridego_mkt_v_lead_decline' ),
        array( '/app/vendor/leads/(?P<id>\d+)/options', 'GET', 'ridego_mkt_v_lead_options' ),
        array( '/app/vendor/bookings/(?P<id>\d+)', 'GET', 'ridego_mkt_v_booking_detail' ),
        array( '/app/vendor/bookings/(?P<id>\d+)/replace-assignment', 'POST', 'ridego_mkt_v_replace_assignment' ),
        array( '/app/vendor/bookings/(?P<id>\d+)/collect', 'POST', 'ridego_mkt_v_collect' ),
        array( '/app/vendor/bookings/(?P<id>\d+)/options', 'GET', 'ridego_mkt_v_booking_options' ),
        array( '/app/vendor/bookings/(?P<id>\d+)/rate-client', 'POST', 'ridego_mkt_v_rate_client' ),
        array( '/app/vendor/settlements', 'GET', 'ridego_mkt_v_settlements' ),
        array( '/app/vendor/performance', 'GET', 'ridego_mkt_v_performance' ),
        array( '/app/vendor/staff', 'GET', 'ridego_mkt_v_staff_list' ),
        array( '/app/vendor/staff', 'POST', 'ridego_mkt_v_staff_create' ),
        array( '/app/vendor/staff/(?P<id>\d+)', 'DELETE', 'ridego_mkt_v_staff_revoke' ),
    );
    foreach ( $fleet_routes as $r ) {
        register_rest_route( 'ridego/v1', $r[0], array( 'methods' => $r[1], 'callback' => $r[2], 'permission_callback' => 'ridego_mkt_staff_or_owner_permission' ) );
    }
    foreach ( $owner_only_routes as $r ) {
        register_rest_route( 'ridego/v1', $r[0], array( 'methods' => $r[1], 'callback' => $r[2], 'permission_callback' => 'ridego_mkt_vendor_permission' ) );
    }
}

// TRACE: GET fleet → vendor type + vehicles + drivers + branches + live status per entity → response.
//        Edge cases: individual vendor (their single provisioned rows), no rows (empty arrays).
function ridego_mkt_v_fleet( WP_REST_Request $req ) {
    $v = ridego_mkt_current_vendor_for_staff();
    $type = ridego_get_vendor_type( $v );
    if ( $type === 'individual' ) { ridego_ensure_individual_provisioned( $v->id ); }
    $veh = array_map( function ( $x ) { $a = (array) $x; $a['live_status'] = ridego_fleet_live_status( 'vehicle', $x ); return $a; }, ridego_get_fleet_vehicles( $v->id ) );
    $drv = array_map( function ( $x ) { $a = (array) $x; $a['live_status'] = ridego_fleet_live_status( 'driver', $x ); $a['profile_missing'] = ridego_driver_missing_fields( $x ); $a['profile_complete'] = ! $a['profile_missing']; return $a; }, ridego_get_fleet_drivers( $v->id ) );
    return rest_ensure_response( array( 'vendor_type' => $type, 'vehicles' => $veh, 'drivers' => $drv, 'branches' => ridego_get_vendor_branches( $v->id ) ) );
}

// TRACE: POST vehicle → ridego_create_fleet_vehicle (fleet only) → response|400.
function ridego_mkt_v_vehicle_create( WP_REST_Request $req ) { return ridego_mkt_result( ridego_create_fleet_vehicle( ridego_mkt_current_vendor_for_staff()->id, ridego_mkt_body( $req ) ) ); }
// TRACE: PUT vehicle → ridego_update_fleet_vehicle (ownership checked inside) → response|400.
function ridego_mkt_v_vehicle_update( WP_REST_Request $req ) { return ridego_mkt_result( ridego_update_fleet_vehicle( (int) $req['id'], ridego_mkt_current_vendor_for_staff()->id, ridego_mkt_body( $req ), $req->get_param( 'expected_lock_version' ) ) ); }
// TRACE: DELETE vehicle → deactivates when referenced, deletes otherwise → response|400.
function ridego_mkt_v_vehicle_delete( WP_REST_Request $req ) { return ridego_mkt_result( ridego_delete_fleet_entity( 'vehicle', (int) $req['id'], ridego_mkt_current_vendor_for_staff()->id ) ); }
// TRACE: POST driver → ridego_create_fleet_driver → response|400.
function ridego_mkt_v_driver_create( WP_REST_Request $req ) { return ridego_mkt_result( ridego_create_fleet_driver( ridego_mkt_current_vendor_for_staff()->id, ridego_mkt_body( $req ) ) ); }
// TRACE: PUT driver → ridego_update_fleet_driver → response|400.
function ridego_mkt_v_driver_update( WP_REST_Request $req ) { return ridego_mkt_result( ridego_update_fleet_driver( (int) $req['id'], ridego_mkt_current_vendor_for_staff()->id, ridego_mkt_body( $req ), $req->get_param( 'expected_lock_version' ) ) ); }
// TRACE: DELETE driver → ridego_delete_fleet_entity → response|400.
function ridego_mkt_v_driver_delete( WP_REST_Request $req ) { return ridego_mkt_result( ridego_delete_fleet_entity( 'driver', (int) $req['id'], ridego_mkt_current_vendor_for_staff()->id ) ); }

// TRACE: GET unavailability → vendor's blocks (optional ?from=YYYY-MM-DD) → response array.
function ridego_mkt_v_unavail_list( WP_REST_Request $req ) {
    return rest_ensure_response( array( 'rows' => ridego_get_fleet_unavailability( ridego_mkt_current_vendor_for_staff()->id, sanitize_text_field( (string) $req->get_param( 'from' ) ) ) ) );
}
// TRACE: POST unavailability {entity_type,entity_id,starts_at,ends_at,reason} → domain create → response (with conflicts)|400.
function ridego_mkt_v_unavail_create( WP_REST_Request $req ) {
    $b = ridego_mkt_body( $req );
    return ridego_mkt_result( ridego_create_fleet_unavailability( ridego_mkt_current_vendor_for_staff()->id, sanitize_key( $b['entity_type'] ?? '' ), (int) ( $b['entity_id'] ?? 0 ), $b['starts_at'] ?? '', $b['ends_at'] ?? '', sanitize_text_field( $b['reason'] ?? '' ), get_current_user_id() ) );
}
// TRACE: DELETE unavailability → ownership-checked delete → response|400.
function ridego_mkt_v_unavail_delete( WP_REST_Request $req ) { return ridego_mkt_result( ridego_delete_fleet_unavailability( ridego_mkt_current_vendor_for_staff()->id, (int) $req['id'] ) ); }

// TRACE: GET fleet docs (?entity_type=vehicle|driver&entity_id) → docs with validity + required types → response.
function ridego_mkt_v_fleet_docs( WP_REST_Request $req ) {
    $et = sanitize_key( (string) $req->get_param( 'entity_type' ) );
    return rest_ensure_response( array(
        'docs'          => ridego_get_fleet_docs( ridego_mkt_current_vendor_for_staff()->id, $et, (int) $req->get_param( 'entity_id' ) ),
        'doc_types'     => ridego_fleet_doc_types( $et ),
        'max_upload_mb' => function_exists( 'ridego_max_upload_bytes' ) ? round( ridego_max_upload_bytes() / ( 1024 * 1024 ), 1 ) : 5,
    ) );
}

// TRACE: GET branches → vendor branches → response.
function ridego_mkt_v_branches( WP_REST_Request $req ) { return rest_ensure_response( array( 'rows' => ridego_get_vendor_branches( ridego_get_current_vendor()->id ) ) ); }
// TRACE: POST branch → save with id 0 → response|400.
function ridego_mkt_v_branch_create( WP_REST_Request $req ) { return ridego_mkt_result( ridego_save_vendor_branch( ridego_get_current_vendor()->id, 0, ridego_mkt_body( $req ) ) ); }
// TRACE: PUT branch → save with id → response|400.
function ridego_mkt_v_branch_update( WP_REST_Request $req ) { return ridego_mkt_result( ridego_save_vendor_branch( ridego_get_current_vendor()->id, (int) $req['id'], ridego_mkt_body( $req ) ) ); }
// TRACE: DELETE branch → detach + delete → response|400.
function ridego_mkt_v_branch_delete( WP_REST_Request $req ) { return ridego_mkt_result( ridego_delete_vendor_branch( ridego_get_current_vendor()->id, (int) $req['id'] ) ); }

// TRACE: POST type {type} → a vendor may upgrade itself individual→fleet; fleet→individual goes through the same
//        domain guard (refused while >1 active vehicle/driver) → response|400. Impersonation blocked.
function ridego_mkt_v_set_type( WP_REST_Request $req ) {
    if ( $g = ridego_impersonation_block() ) { return ridego_mkt_result( $g ); }
    $b = ridego_mkt_body( $req );
    return ridego_mkt_result( ridego_set_vendor_type( ridego_get_current_vendor()->id, sanitize_key( $b['type'] ?? '' ) ) );
}

// TRACE: POST lead viewed → marks viewed_at once → response|400.
function ridego_mkt_v_lead_viewed( WP_REST_Request $req ) { return ridego_mkt_result( ridego_lead_mark_viewed( (int) $req['id'], ridego_get_current_vendor()->id ) ); }
// TRACE: POST lead interest → compare mode: show interest; instant mode: legacy accept → response|400.
function ridego_mkt_v_lead_interest( WP_REST_Request $req ) {
    $vid = ridego_get_current_vendor()->id;
    $gate = ridego_lead_fee_acceptance_gate( $vid );
    if ( $gate ) { return ridego_mkt_result( $gate ); }
    if ( ridego_lead_mode() === 'instant' ) { return ridego_mkt_result( ridego_accept_lead( (int) $req['id'], $vid ) ); }
    return ridego_mkt_result( ridego_lead_show_interest( (int) $req['id'], $vid ) );
}
// TRACE: POST lead confirm {driver_id|driver_name, vehicle_id|...} → confirm driver/vehicle for the lead → response|400.
function ridego_mkt_v_lead_confirm( WP_REST_Request $req ) { return ridego_mkt_result( ridego_lead_confirm_driver( (int) $req['id'], ridego_get_current_vendor()->id, ridego_mkt_body( $req ) ) ); }
// TRACE: POST lead decline {reason} → decline → response|400.
function ridego_mkt_v_lead_decline( WP_REST_Request $req ) { $b = ridego_mkt_body( $req ); return ridego_mkt_result( ridego_lead_decline( (int) $req['id'], ridego_get_current_vendor()->id, $b['reason'] ?? '' ) ); }

// TRACE: GET lead options → vehicles/drivers with availability for that lead's booking window → response|404.
//        Edge cases: lead not the vendor's (404), booking missing (404).
function ridego_mkt_v_lead_options( WP_REST_Request $req ) {
    global $wpdb;
    $vid = ridego_get_current_vendor()->id;
    $l = $wpdb->get_row( $wpdb->prepare( "SELECT booking_id FROM {$wpdb->prefix}ridego_leads WHERE id=%d AND vendor_id=%d", (int) $req['id'], $vid ) );
    $b = $l ? ridego_get_booking( $l->booking_id ) : null;
    if ( ! $b ) { return new WP_Error( 'not_found', 'Lead not found.', array( 'status' => 404 ) ); }
    return rest_ensure_response( ridego_fleet_selection_options( $vid, $b ) );
}

// TRACE: GET booking detail → only the assigned vendor sees it; customer name/phone/addresses are exposed only when
//        the booking is in a committed status; includes current assignment, rating state, balance to collect →
//        response|404. Edge cases: not this vendor's booking (404), cancelled (customer contact withheld).
function ridego_mkt_v_booking_detail( WP_REST_Request $req ) {
    $v = ridego_get_current_vendor();
    $b = ridego_get_booking( (int) $req['id'] );
    if ( ! $b || (int) $b->vendor_id !== (int) $v->id ) { return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) ); }
    $committed = in_array( $b->status, ridego_fleet_committed_statuses(), true ) || $b->status === 'completed';
    $a = ridego_get_current_assignment( $b->id );
    $out = array(
        'id' => (int) $b->id, 'booking_number' => $b->booking_number, 'status' => $b->status, 'status_label' => ridego_get_booking_status_label( $b->status ),
        'pickup_city' => $b->pickup_city, 'drop_city' => $b->drop_city, 'journey_date' => $b->journey_date, 'journey_time' => $b->journey_time,
        'trip_type' => $b->trip_type, 'passengers' => (int) $b->passengers, 'special_requests' => $b->special_requests,
        'passenger_male' => isset( $b->passenger_male ) && $b->passenger_male !== null ? (int) $b->passenger_male : null,
        'passenger_female' => isset( $b->passenger_female ) && $b->passenger_female !== null ? (int) $b->passenger_female : null,
        'passenger_children' => isset( $b->passenger_children ) && $b->passenger_children !== null ? (int) $b->passenger_children : null,
        'passenger_notes' => isset( $b->passenger_notes ) ? (string) $b->passenger_notes : '',
        'is_safety_sensitive' => ridego_booking_is_safety_sensitive( $b ),
        'assignment' => $a ? array( 'driver_name' => $a->driver_name_snapshot, 'driver_phone' => $a->driver_phone_snapshot, 'vehicle_model' => $a->vehicle_model_snapshot, 'vehicle_registration' => $a->vehicle_registration_snapshot, 'needs_details' => $a->driver_name_snapshot === '' || $a->vehicle_registration_snapshot === '' ) : null,
        'rating' => ridego_get_booking_rating_state( $b->id ),
        'timeline' => ridego_booking_timeline( $b, $a ),
        'customer' => null,
        'vendor_notice' => ridego_platform_text( 'disclaimer_vendor' ), 'collection_methods' => ridego_vendor_collection_methods(),
        'collection_history' => array_values( array_filter( ridego_booking_get_payments( $b->id ), function ( $r ) { return $r['entry_type'] === 'vendor_collection'; } ) ),
    ) + ridego_booking_money_fields( $b ) + array( 'lead_fee' => ridego_lead_fee_view( $b ) );
    if ( $committed ) {
        $out['customer'] = array( 'name' => $b->client_name, 'phone' => $b->client_phone, 'pickup_address' => $b->pickup_address, 'drop_address' => $b->drop_address );
    }
    return rest_ensure_response( $out );
}

// TRACE: GET booking options → vehicles/drivers with availability computed for this booking, excluding its own
//        current assignment from conflicts → response|404.
function ridego_mkt_v_booking_options( WP_REST_Request $req ) {
    $v = ridego_get_current_vendor();
    $b = ridego_get_booking( (int) $req['id'] );
    if ( ! $b || (int) $b->vendor_id !== (int) $v->id ) { return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) ); }
    return rest_ensure_response( ridego_fleet_selection_options( $v->id, $b ) );
}

// TRACE: POST replace-assignment {driver_id|driver_name..., vehicle_id|..., reason} → ridego_replace_assignment as
//        actor vendor (ownership verified inside) → response|400. Fills a blank assignment or replaces a set one.
function ridego_mkt_v_replace_assignment( WP_REST_Request $req ) {
    $b = ridego_mkt_body( $req );
    return ridego_mkt_result( ridego_replace_assignment( (int) $req['id'], $b, get_current_user_id(), 'vendor', sanitize_text_field( $b['reason'] ?? '' ) ) );
}

// TRACE: POST rate-client {scores:{category:1..5}, review} → vendor rates the client once per trip → response|400.
function ridego_mkt_v_rate_client( WP_REST_Request $req ) {
    $v = ridego_get_current_vendor();
    $b = ridego_mkt_body( $req );
    $bk = ridego_get_booking( (int) $req['id'] );
    if ( ! $bk || (int) $bk->vendor_id !== (int) $v->id ) { return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) ); }
    return ridego_mkt_result( ridego_submit_trip_ratings( $bk->id, get_current_user_id(), 'vendor', is_array( $b['scores'] ?? null ) ? $b['scores'] : array(), sanitize_textarea_field( $b['review'] ?? '' ) ) );
}

// TRACE: GET settlements → per-booking ledger lines for this vendor with settled/pending status + summary totals →
//        response {summary, rows, page}. Edge cases: none (empty rows, zero summary).
function ridego_mkt_v_settlements( WP_REST_Request $req ) {
    global $wpdb;
    $v = ridego_get_current_vendor();
    $page = max( 1, (int) $req->get_param( 'page' ) ); $per = 30;
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT l.id, l.booking_id, b.booking_number, l.entry_type, l.amount, l.direction, l.status, l.settled_at, l.created_at
         FROM {$wpdb->prefix}ridego_booking_ledger l LEFT JOIN {$wpdb->prefix}ridego_bookings b ON b.id=l.booking_id
         WHERE l.vendor_id=%d ORDER BY l.id DESC LIMIT %d OFFSET %d", $v->id, $per, ( $page - 1 ) * $per ), ARRAY_A );
    $total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_booking_ledger WHERE vendor_id=%d", $v->id ) );
    return rest_ensure_response( array( 'summary' => ridego_ledger_summary( $v->id ), 'rows' => $rows, 'total' => $total, 'page' => $page, 'per_page' => $per ) );
}

// TRACE: GET performance → vendor's own performance payload (trend, categories, per driver/vehicle) → response.
function ridego_mkt_v_performance( WP_REST_Request $req ) { return rest_ensure_response( ridego_get_vendor_performance_detail( ridego_get_current_vendor()->id ) ); }

// TRACE: POST collect {amount, method, reference?, note?, invoice_number?} → the assigned vendor/driver reports the ride balance they COLLECTED from the client (RideGo does not handle this money)
//        → ridego_booking_record_vendor_collection as actor vendor → response|400|404. Preconditions: booking belongs to the current vendor and the trip is confirmed onward.
//        Postconditions: ledger row + vendor_collected + balance_due updated, client notified. Edge cases: not this vendor's booking (404), over-collection / nothing payable / cancelled (400),
//        booking not yet confirmed (400).
function ridego_mkt_v_collect( WP_REST_Request $req ) {
    $v = ridego_get_current_vendor();
    $bk = ridego_get_booking( (int) $req['id'] );
    if ( ! $bk || (int) $bk->vendor_id !== (int) $v->id ) { return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) ); }
    if ( ! in_array( $bk->status, array( 'vendor_assigned', 'driver_en_route', 'trip_started', 'completed' ), true ) ) { return new WP_Error( 'request_failed', 'You can record a collection once the trip is confirmed with you.', array( 'status' => 400 ) ); }
    $b = ridego_mkt_body( $req );
    return ridego_mkt_result( ridego_booking_record_vendor_collection( (int) $bk->id, $b['amount'] ?? 0, (string) ( $b['method'] ?? '' ), (string) ( $b['reference'] ?? '' ), (string) ( $b['note'] ?? '' ), 'vendor', get_current_user_id(), (string) ( $b['invoice_number'] ?? '' ) ) );
}

/* ================================================================
   Fleet bulk CSV import (RG-014, Master Issue Register P1).
   ------------------------------------------------------------
   A fleet vendor onboarding 30+ vehicles or drivers previously had to
   add them one at a time through the create-vehicle/create-driver
   forms. These two endpoints parse an uploaded CSV and call the exact
   SAME canonical per-row functions (ridego_create_fleet_vehicle() /
   ridego_create_fleet_driver()) the single-row create endpoints
   already use — so every validation rule (plate format/uniqueness,
   fleet-vs-individual account type, required driver fields, licence
   age bounds, etc.) applies identically whether a row came from the
   form or from a CSV, with zero duplicated logic and zero risk of the
   two paths drifting apart. A row that fails is reported with its row
   number and the exact same message the single-row endpoint would
   have returned; earlier successful rows are NOT rolled back if a
   later row fails (each row is an independent create, matching how a
   human re-typing 30 rows one at a time would behave, and letting the
   vendor fix and re-upload just the failed rows rather than start over).
   ================================================================ */

// TRACE: any of the two import endpoints → reads $_FILES['file'], parses as CSV with a header
//        row, caps at RIDEGO_BULK_IMPORT_MAX_ROWS data rows → array of associative row arrays
//        keyed by the lower-cased header, or a WP_Error. Edge cases: no file (400); empty file /
//        header only (400, "no data rows"); more data rows than the cap (400, names the cap
//        rather than silently truncating and importing a partial file without telling anyone);
//        a row with a different column count than the header (skipped from the returned array
//        and reported separately in row_count_mismatches, never silently misaligned into the
//        wrong columns).
define( 'RIDEGO_BULK_IMPORT_MAX_ROWS', 500 );
function ridego_mkt_parse_csv_upload( WP_REST_Request $req ) {
    $files = $req->get_file_params();
    if ( empty( $files['file']['tmp_name'] ) || ! is_uploaded_file( $files['file']['tmp_name'] ) ) {
        return new WP_Error( 'invalid_input', 'A CSV file is required.', array( 'status' => 400 ) );
    }
    $handle = fopen( $files['file']['tmp_name'], 'r' );
    if ( ! $handle ) {
        return new WP_Error( 'invalid_input', 'Could not read the uploaded file.', array( 'status' => 400 ) );
    }
    $header = fgetcsv( $handle );
    if ( ! $header ) {
        fclose( $handle );
        return new WP_Error( 'invalid_input', 'The CSV file has no header row.', array( 'status' => 400 ) );
    }
    $header = array_map( function ( $h ) { return sanitize_key( trim( (string) $h ) ); }, $header );
    $rows = array();
    $mismatches = 0;
    while ( ( $line = fgetcsv( $handle ) ) !== false ) {
        if ( count( $line ) === 1 && trim( (string) $line[0] ) === '' ) { continue; } // blank line
        if ( count( $line ) !== count( $header ) ) { $mismatches++; continue; }
        $rows[] = array_combine( $header, $line );
        if ( count( $rows ) > RIDEGO_BULK_IMPORT_MAX_ROWS ) {
            fclose( $handle );
            return new WP_Error( 'too_many_rows', 'This file has more than ' . RIDEGO_BULK_IMPORT_MAX_ROWS . ' rows. Split it into smaller files.', array( 'status' => 400 ) );
        }
    }
    fclose( $handle );
    if ( empty( $rows ) ) {
        return new WP_Error( 'invalid_input', 'The CSV file has no data rows.', array( 'status' => 400 ) );
    }
    return array( 'rows' => $rows, 'row_count_mismatches' => $mismatches );
}

// TRACE: POST fleet/vehicles/import (multipart, field 'file') → parses CSV (expected columns:
//        registration_number, make_model, vehicle_type_id, seating_capacity, status, branch_id —
//        any subset; missing optional columns just aren't set), calls
//        ridego_create_fleet_vehicle() per row → {imported, failed, errors:[{row,message}],
//        row_count_mismatches}. Preconditions: caller is an active vendor (permission callback).
//        Postconditions: each successfully-parsed row is independently created or independently
//        rejected by the SAME rules ridego_create_fleet_vehicle() already enforces (plate
//        uniqueness, fleet-account requirement, etc.) — this function adds no new validation of
//        its own. Edge cases: all rows fail (imported=0, every row's real reason listed, not a
//        generic "import failed"); duplicate plates WITHIN the same file (the second occurrence
//        fails with the same "already registered" message the single-row endpoint gives, since
//        ridego_fleet_plate_in_use() sees the first row's own just-inserted plate).
function ridego_mkt_v_vehicles_import( WP_REST_Request $req ) {
    $parsed = ridego_mkt_parse_csv_upload( $req );
    if ( is_wp_error( $parsed ) ) { return $parsed; }
    $vendor = ridego_mkt_current_vendor_for_staff();
    $result = ridego_mkt_bulk_import_rows( $parsed['rows'], $vendor->id, 'ridego_create_fleet_vehicle' );
    ridego_audit_log( 'fleet_vehicles_bulk_imported', 'vendor', (int) $vendor->id, '', array( 'imported' => $result['imported'], 'failed' => count( $result['errors'] ) ) );
    return rest_ensure_response( array_merge( $result, array( 'row_count_mismatches' => $parsed['row_count_mismatches'] ) ) );
}

// TRACE: array of associative CSV-derived rows + vendor id + the canonical per-row create function
//        name (ridego_create_fleet_vehicle or ridego_create_fleet_driver — both share the exact
//        signature ($vendor_id, $raw) => array(success, message, ...)) → calls it once per row,
//        never stopping on a failure → {imported, errors:[{row,message}]}. Pure with respect to
//        rows already outside it, and delegates ALL validation to $create_fn — this function adds
//        none of its own, so vehicle/driver business rules can never drift between the single-row
//        and bulk-import paths. Extracted separately from the file-upload wrapper specifically so
//        it can be exercised directly (with a plain PHP array of rows) without needing a real
//        multipart HTTP upload to satisfy is_uploaded_file() — see tests/regression/run-all.php's
//        RG-014 suite, which calls this function directly for exactly that reason.
function ridego_mkt_bulk_import_rows( $rows, $vendor_id, $create_fn ) {
    $imported = 0; $errors = array();
    foreach ( $rows as $i => $row ) {
        $res = call_user_func( $create_fn, $vendor_id, $row );
        if ( ! empty( $res['success'] ) ) { $imported++; }
        else { $errors[] = array( 'row' => $i + 2, 'message' => $res['message'] ?? 'Unknown error.' ); }
    }
    return array( 'imported' => $imported, 'errors' => $errors, 'failed' => count( $errors ) );
}

// TRACE: POST fleet/drivers/import (multipart, field 'file') → parses CSV (expected columns match
//        ridego_driver_required_fields() plus optional ones), calls ridego_create_fleet_driver()
//        per row → {imported, failed, errors:[{row,message}], row_count_mismatches}. Same
//        independent-per-row, no-duplicated-validation contract as the vehicle importer above.
function ridego_mkt_v_drivers_import( WP_REST_Request $req ) {
    $parsed = ridego_mkt_parse_csv_upload( $req );
    if ( is_wp_error( $parsed ) ) { return $parsed; }
    $vendor = ridego_mkt_current_vendor_for_staff();
    $result = ridego_mkt_bulk_import_rows( $parsed['rows'], $vendor->id, 'ridego_create_fleet_driver' );
    ridego_audit_log( 'fleet_drivers_bulk_imported', 'vendor', (int) $vendor->id, '', array( 'imported' => $result['imported'], 'failed' => count( $result['errors'] ) ) );
    return rest_ensure_response( array_merge( $result, array( 'row_count_mismatches' => $parsed['row_count_mismatches'] ) ) );
}

/* ================================================================
   RG-015: Vendor staff delegation — owner-only management of staff
   logins scoped (via ridego_mkt_staff_or_owner_permission()) to the
   fleet-management routes above only. Staff can never create/revoke
   other staff, and can never reach settlements/branches/leads/
   bookings/performance/vendor-type — those stay owner-only.
   ================================================================ */

// TRACE: GET vendor/staff → owner's own staff roster (all statuses, newest first) → {rows:[...]}.
//        Preconditions: caller is the vendor owner (ridego_mkt_vendor_permission — staff cannot reach this route).
function ridego_mkt_v_staff_list( WP_REST_Request $req ) {
    global $wpdb;
    $vendor = ridego_get_current_vendor();
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT s.id, s.user_id, s.name, s.status, s.created_at, u.user_email FROM {$wpdb->prefix}ridego_vendor_staff s
         LEFT JOIN {$wpdb->users} u ON u.ID = s.user_id WHERE s.vendor_id=%d ORDER BY s.created_at DESC", (int) $vendor->id ) );
    return rest_ensure_response( array( 'rows' => (array) $rows ) );
}

// TRACE: POST vendor/staff { name, email, password? } → owner creates a new WP user (role
//        ridego_vendor_staff) + a linked, active ridego_vendor_staff row → { ok, user_id }.
//        Preconditions: caller is the vendor owner; email not already in use. Postconditions: the
//        new user can immediately authenticate against the scoped fleet routes via
//        ridego_mkt_staff_or_owner_permission(); a password-reset email is sent when no password
//        supplied (mirrors ridego_driver_api_create_login()). Edge cases: duplicate email (409),
//        blank name (400), wp_insert_user failure (400, no orphan staff row created), the DB insert
//        failing after a successful wp_insert_user (500, and the just-created WP user is deleted so
//        no orphan login is left behind — mirrors the driver-login rollback pattern).
function ridego_mkt_v_staff_create( WP_REST_Request $req ) {
    global $wpdb;
    $vendor = ridego_get_current_vendor();
    $b = ridego_mkt_body( $req );
    $name = sanitize_text_field( $b['name'] ?? '' );
    if ( $name === '' ) { return new WP_Error( 'invalid_input', 'Enter the staff member\'s name.', array( 'status' => 400 ) ); }
    $email = sanitize_email( $b['email'] ?? '' );
    if ( ! is_email( $email ) ) { return new WP_Error( 'invalid_input', 'Enter a valid email address.', array( 'status' => 400 ) ); }
    if ( email_exists( $email ) ) { return new WP_Error( 'exists', 'A user with this email already exists.', array( 'status' => 409 ) ); }
    $pw = (string) ( $b['password'] ?? '' );
    if ( $pw !== '' && strlen( $pw ) < 10 ) { return new WP_Error( 'invalid_input', 'Password must be at least 10 characters.', array( 'status' => 400 ) ); }
    $login = 'vstaff' . (int) $vendor->id . '_' . substr( md5( $email ), 0, 5 );
    $uid = wp_insert_user( array( 'user_login' => $login, 'user_email' => $email, 'display_name' => $name, 'first_name' => $name, 'user_pass' => $pw !== '' ? $pw : wp_generate_password( 24 ), 'role' => 'ridego_vendor_staff' ) );
    if ( is_wp_error( $uid ) ) { return new WP_Error( 'create_failed', $uid->get_error_message(), array( 'status' => 400 ) ); }
    $ok = $wpdb->insert( $wpdb->prefix . 'ridego_vendor_staff', array( 'vendor_id' => $vendor->id, 'user_id' => $uid, 'name' => $name, 'status' => 'active', 'created_by' => get_current_user_id(), 'created_at' => current_time( 'mysql' ) ) );
    if ( ! $ok ) { wp_delete_user( $uid ); return new WP_Error( 'save_failed', 'Could not create the staff record.', array( 'status' => 500 ) ); }
    if ( $pw === '' ) { retrieve_password( $login ); }
    ridego_audit_log( 'vendor_staff_created', 'vendor', (int) $vendor->id, '', array( 'user_id' => $uid, 'name' => $name ) );
    return rest_ensure_response( array( 'ok' => true, 'user_id' => $uid ) );
}

// TRACE: DELETE vendor/staff/{id} → owner revokes a staff member's access by setting status to
//        'suspended' (never deletes the WP user or the row, so audit history and the user's own
//        other data stay intact) → { ok }. Preconditions: the staff row belongs to the calling
//        vendor (re-verified here, not trusted from the path). Postconditions: the very next call
//        that staff member makes to any fleet route is rejected by
//        ridego_mkt_staff_or_owner_permission(), re-checked fresh, not cached from an existing
//        session. Edge cases: staff id belongs to a different vendor (404, cross-vendor isolation),
//        already-suspended row (200, idempotent no-op — not an error).
function ridego_mkt_v_staff_revoke( WP_REST_Request $req ) {
    global $wpdb;
    $vendor = ridego_get_current_vendor();
    $id = (int) $req['id'];
    $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_vendor_staff WHERE id=%d", $id ) );
    if ( ! $row || (int) $row->vendor_id !== (int) $vendor->id ) { return new WP_Error( 'not_found', 'Staff member not found.', array( 'status' => 404 ) ); }
    $wpdb->update( $wpdb->prefix . 'ridego_vendor_staff', array( 'status' => 'suspended' ), array( 'id' => $id ) );
    ridego_audit_log( 'vendor_staff_revoked', 'vendor', (int) $vendor->id, $row->status, 'suspended' );
    return rest_ensure_response( array( 'ok' => true ) );
}
