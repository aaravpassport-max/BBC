<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   VENDOR SYSTEM  Registration, KYC, Wallet, Profile
   ============================================================ */

/*  Create vendor profile  */
function ridego_create_vendor( $data ) {
    global $wpdb;

    $required = array('owner_name','phone','email','city');
    foreach ( $required as $f ) {
        if ( empty($data[$f]) ) {
            return array('success'=>false,'message'=>'Missing required field: '.$f);
        }
    }

    $phone = ridego_sanitize_phone($data['phone']);
    if ( strlen(preg_replace('/[^0-9]/','', $phone)) < 10 ) {
        return array('success'=>false,'message'=>'Invalid phone number.');
    }

    /* Check if vendor already exists for this user */
    $user_id = intval(isset($data['user_id']) ? $data['user_id'] : get_current_user_id());
    if ( $user_id ) {
        $existing = ridego_get_vendor_by_user($user_id);
        if ($existing) return array('success'=>false,'message'=>'Vendor profile already exists for this account.');
    }

    /* Check phone not already registered */
    $phone_exists = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}ridego_vendors WHERE phone=%s LIMIT 1", $phone
    ));
    if ($phone_exists) return array('success'=>false,'message'=>'This phone number is already registered as a vendor.');

    /* Create WP user account if not logged in.
       $created_new_user tracks whether THIS call is the one that created
       the account, so a later failure (the vendor-row insert below) can
       clean up the orphaned user rather than leaving a WP account with the
       ridego_vendor role and no vendor profile — that combination previously
       left the applicant unable to log in usefully and unable to re-register
       with the same phone/email either. */
    $created_new_user = false;
    if ( ! $user_id ) {
        $username = sanitize_user(strtolower(preg_replace('/[^a-zA-Z0-9]/','',$data['owner_name'])).'_'.rand(100,999));
        $password = wp_generate_password(12,true);
        $user_id  = wp_create_user($username, $password, sanitize_email($data['email']));
        if ( is_wp_error($user_id) ) {
            return array('success'=>false,'message'=>$user_id->get_error_message());
        }
        $created_new_user = true;
        $user = new WP_User($user_id);
        $user->set_role('ridego_vendor');
        /* Send welcome email with credentials */
        wp_mail(
            sanitize_email($data['email']),
            'Your ' . ridego_brand_name() . ' Vendor Account',
            "Welcome! Your account has been created.\nUsername: {$username}\nPassword: {$password}\nLogin: ".wp_login_url()
        );
    } else {
        $user = new WP_User($user_id);
        $user->add_role('ridego_vendor');
    }

    $operating_cities = array(sanitize_text_field($data['city']));
    if (!empty($data['other_cities']) && is_array($data['other_cities'])) {
        $operating_cities = array_merge($operating_cities, array_map('sanitize_text_field', $data['other_cities']));
    }

    $vehicle_types = array();
    if (!empty($data['vehicle_types']) && is_array($data['vehicle_types'])) {
        $vehicle_types = array_map('intval', $data['vehicle_types']);
    }

    $row = array(
        'user_id'         => $user_id,
        'business_name'   => sanitize_text_field(isset($data['business_name']) ? $data['business_name'] : $data['owner_name']),
        'owner_name'      => sanitize_text_field($data['owner_name']),
        'phone'           => $phone,
        'alt_phone'       => ridego_sanitize_phone((isset($data['alt_phone']) ? $data['alt_phone'] : '')),
        'email'           => sanitize_email($data['email']),
        'whatsapp_number' => ridego_sanitize_phone(isset($data['whatsapp_number']) ? $data['whatsapp_number'] : $phone),
        'business_type'   => sanitize_key((isset($data['business_type']) ? $data['business_type'] : 'individual')),
        'gst_number'      => sanitize_text_field((isset($data['gst_number']) ? $data['gst_number'] : '')),
        'pan_number'      => strtoupper(sanitize_text_field((isset($data['pan_number']) ? $data['pan_number'] : ''))),
        'address'         => sanitize_textarea_field((isset($data['address']) ? $data['address'] : '')),
        'city'            => sanitize_text_field($data['city']),
        'operating_cities'=> wp_json_encode($operating_cities),
        'vehicle_types'   => wp_json_encode($vehicle_types),
        'total_vehicles'  => max(1, intval((isset($data['total_vehicles']) ? $data['total_vehicles'] : 1))),
        'years_experience'=> max(0, intval((isset($data['years_experience']) ? $data['years_experience'] : 0))),
        'bank_account'    => sanitize_text_field((isset($data['bank_account']) ? $data['bank_account'] : '')),
        'bank_name'       => sanitize_text_field((isset($data['bank_name']) ? $data['bank_name'] : '')),
        'bank_ifsc'       => strtoupper(sanitize_text_field((isset($data['bank_ifsc']) ? $data['bank_ifsc'] : ''))),
        'bank_holder'     => sanitize_text_field((isset($data['bank_holder']) ? $data['bank_holder'] : '')),
        'upi_id'          => sanitize_text_field((isset($data['upi_id']) ? $data['upi_id'] : '')),
        'status'          => 'pending',
        'kyc_status'      => 'pending',
        'wallet_balance'  => 0.00,
        'joined_at'       => current_time('mysql'),
    );

    $wpdb->insert($wpdb->prefix.'ridego_vendors', $row);
    $vendor_id = $wpdb->insert_id;

    if (!$vendor_id) {
        // Compensating cleanup: if this call just created the WP user above
        // and the vendor-row insert then failed, delete that user rather
        // than leaving an orphaned ridego_vendor-role account with no
        // profile — without this, the applicant's email/phone were "used up"
        // by an account they could never actually use, and retrying
        // registration with the same email would fail at wp_create_user()
        // for an account that serves no purpose.
        if ( $created_new_user && $user_id && ! is_wp_error( $user_id ) ) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
            wp_delete_user( $user_id );
        }
        return array('success'=>false,'message'=>'Failed to create vendor profile. Please try again.');
    }

    do_action('ridego_vendor_registered', $vendor_id);
    return array('success'=>true,'vendor_id'=>$vendor_id,'message'=>'Registration submitted. We will review your application within 24 hours.');
}

/*  Update vendor profile  */
function ridego_update_vendor( $vendor_id, $data ) {
    global $wpdb;
    $allowed = array(
        'business_name','owner_name','alt_phone','email','whatsapp_number',
        'business_type','gst_number','pan_number','address','city',
        'operating_cities','vehicle_types','total_vehicles','years_experience',
        'bank_account','bank_name','bank_ifsc','bank_holder','upi_id',
    );
    $row = array();
    foreach ($allowed as $f) {
        if (!isset($data[$f])) continue;
        if (in_array($f,array('operating_cities','vehicle_types'))) {
            $row[$f] = is_array($data[$f]) ? wp_json_encode($data[$f]) : $data[$f];
        } else {
            $row[$f] = sanitize_text_field($data[$f]);
        }
    }
    if (empty($row)) return false;
    $wpdb->update($wpdb->prefix.'ridego_vendors', $row, array('id'=>intval($vendor_id)));
    ridego_audit_log('vendor_updated','vendor',$vendor_id);
    return true;
}

/*  Get all vendors (admin)  */
function ridego_get_all_vendors( $args = array() ) {
    global $wpdb;
    $d = array('status'=>'','kyc_status'=>'','city'=>'','search'=>'','low_wallet'=>false,'limit'=>25,'offset'=>0,'orderby'=>'joined_at','order'=>'DESC');
    $a = array_merge($d,$args);
    $w = array('1=1'); $v = array();
    if ($a['status'])     { $w[]='status=%s';     $v[]=$a['status']; }
    if ($a['kyc_status']) { $w[]='kyc_status=%s'; $v[]=$a['kyc_status']; }
    if ($a['city'])       { $w[]='city=%s';        $v[]=$a['city']; }
    if ($a['low_wallet']) {
        $min = (float)ridego_get_setting('min_wallet_balance',200);
        $w[] = 'wallet_balance < %f';
        $v[] = $min;
    }
    if ($a['search']) {
        $lk = '%'.$wpdb->esc_like($a['search']).'%';
        $w[] = '(owner_name LIKE %s OR business_name LIKE %s OR phone LIKE %s OR email LIKE %s)';
        $v[] = $lk; $v[] = $lk; $v[] = $lk; $v[] = $lk;
    }
    $ord = in_array(strtoupper($a['order']),array('ASC','DESC')) ? strtoupper($a['order']) : 'DESC';
    $obm = array('joined_at'=>'joined_at','rating'=>'rating','wallet_balance'=>'wallet_balance','total_rides_completed'=>'total_rides_completed');
    $ob  = isset($obm[$a['orderby']]) ? $obm[$a['orderby']] : 'joined_at';
    $v[] = $a['limit']; $v[] = $a['offset'];
    $sql = "SELECT * FROM {$wpdb->prefix}ridego_vendors WHERE ".implode(' AND ',$w)." ORDER BY {$ob} {$ord} LIMIT %d OFFSET %d";
    return $wpdb->get_results($wpdb->prepare($sql,...$v));
}

function ridego_count_vendors( $args = array() ) {
    global $wpdb;
    $w=array('1=1');$v=array();
    if (!empty($args['status']))     { $w[]='status=%s';     $v[]=$args['status']; }
    if (!empty($args['kyc_status'])) { $w[]='kyc_status=%s'; $v[]=$args['kyc_status']; }
    $sql="SELECT COUNT(*) FROM {$wpdb->prefix}ridego_vendors WHERE ".implode(' AND ',$w);
    return (int)($v ? $wpdb->get_var($wpdb->prepare($sql,...$v)) : $wpdb->get_var($sql));
}

/*  KYC document upload
    File-type validation is content-based (finfo/getimagesize/PDF magic
    bytes), never $file['type'] — that header is client-supplied and
    trivially spoofable (a renamed .php could claim to be image/jpeg).
    This mirrors the exact same root-cause fix already applied to
    ridego_submit_payment_proof() in includes/booking.php; before this fix,
    the KYC upload path — which handles a vendor's ID/license/insurance
    documents, arguably more sensitive than a payment screenshot — was the
    one upload surface in the plugin still trusting the browser's claim. */
/**
 * Single source of truth for the document-upload size ceiling. The plugin's
 * own policy is 5MB, but PHP will silently truncate/reject anything over
 * upload_max_filesize or post_max_size before our code ever sees a usable
 * $_FILES entry — a file between the server's real ceiling and our stated
 * 5MB used to fail with a generic "File upload failed" message that
 * contradicted the "up to 5MB" hint shown in the UI. Capping our own limit
 * at whichever is smaller means the number we validate against, the number
 * we tell the user, and the number PHP will actually allow are always the
 * same value — no more hardcoding 5MB independently in three places.
 */
// TRACE: called by ridego_upload_vendor_doc() and the frontend-facing limits endpoint → min(plugin policy, server's real ceiling) → byte count.
//        Preconditions: none → Postconditions: pure function, no side effects → Edge cases: none.
function ridego_max_upload_bytes() {
    $policy_cap = 5 * 1024 * 1024; // plugin policy: 5MB
    $server_cap = function_exists( 'wp_max_upload_size' ) ? (int) wp_max_upload_size() : $policy_cap;
    if ( $server_cap <= 0 ) { $server_cap = $policy_cap; }
    return min( $policy_cap, $server_cap );
}

/* Marketplace Phase 1: $vehicle_id / $driver_id (both optional) scope a document to a
   fleet vehicle or fleet driver instead of the vendor's own KYC set. A scoped document
   never touches the vendor-level KYC completeness/expiry mirror. */
// TRACE: KYC or fleet document upload → validates size/type, upserts the row for its scope (vendor-level, vehicle or driver), stores the file, mirrors expiry and re-checks KYC completeness only for vendor-level docs → array(success,message).
//        Preconditions: $vehicle_id/$driver_id, when set, belong to the vendor (checked by the REST caller) → Postconditions: one row per (vendor, doc_type, scope) → Edge cases: oversize (including PHP ini rejection before upload completes), bad upload, scoped doc never touches vendor KYC status.
function ridego_upload_vendor_doc( $vendor_id, $doc_type, $file, $expiry_date = '', $vehicle_id = null, $driver_id = null ) {
    global $wpdb;
    $max_bytes = ridego_max_upload_bytes();
    $max_mb    = round( $max_bytes / ( 1024 * 1024 ), 1 );

    /* A file larger than upload_max_filesize/post_max_size never reaches
       PHP intact: $_FILES carries UPLOAD_ERR_INI_SIZE/FORM_SIZE, size=0 and
       an empty tmp_name. Catch that case FIRST and report the real limit,
       rather than falling through to the generic "upload failed" message
       the empty-tmp_name check below used to produce for this exact case. */
    if ( isset( $file['error'] ) && in_array( (int) $file['error'], array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) ) {
        return array( 'success' => false, 'message' => "File must be under {$max_mb}MB." );
    }
    if ($file['size'] > $max_bytes) {
        return array('success'=>false,'message'=>"File must be under {$max_mb}MB.");
    }
    if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return array('success'=>false,'message'=>'File upload failed.');
    }

    $real_mime = false;
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $real_mime = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
        }
    }
    if (!$real_mime && function_exists('mime_content_type')) {
        $real_mime = mime_content_type($file['tmp_name']);
    }

    $is_image = in_array($real_mime, array('image/jpeg','image/png','image/webp'), true);
    $is_pdf   = ($real_mime === 'application/pdf');
    if ($is_image) {
        $is_image = (bool) @getimagesize($file['tmp_name']);
    } elseif ($is_pdf) {
        $head = @file_get_contents($file['tmp_name'], false, null, 0, 5);
        $is_pdf = ($head !== false && strpos($head, '%PDF-') === 0);
    }
    if (!$is_image && !$is_pdf) {
        return array('success'=>false,'message'=>'Only genuine JPG, PNG, WebP or PDF files are allowed.');
    }

    $ext_map = array('image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','application/pdf'=>'pdf');
    $ext     = isset($ext_map[$real_mime]) ? $ext_map[$real_mime] : 'bin';

    $dir  = RIDEGO_SECURE_UPLOADS.'vendor-docs/'.$vendor_id.'/';
    wp_mkdir_p($dir);
    $fname= sanitize_key($doc_type).($vehicle_id ? '_v'.(int)$vehicle_id : '').($driver_id ? '_d'.(int)$driver_id : '').'_'.time().'.'.$ext;
    $dest = $dir.$fname;
    if (!move_uploaded_file($file['tmp_name'],$dest)) {
        return array('success'=>false,'message'=>'File upload failed. Check server write permissions.');
    }
    if (in_array($ext,array('jpg','jpeg','png','webp'))) {
        $comp  = ridego_compress_image($dest, 1500, 82);
        $fname = basename($comp);
    }
    $rel_path = 'vendor-docs/'.$vendor_id.'/'.$fname;

    /* Expiring doc types capture and validate an expiry date */
    $expiry_val = null;
    if ( ridego_doc_type_needs_expiry($doc_type) ) {
        if ( $expiry_date && preg_match('/^\d{4}-\d{2}-\d{2}$/', $expiry_date) ) {
            $expiry_val = $expiry_date;
        }
    }

    /* Upsert document record */
    $scope_sql = ( $vehicle_id ? $wpdb->prepare(' AND vehicle_id=%d', (int) $vehicle_id) : ' AND vehicle_id IS NULL' )
               . ( $driver_id  ? $wpdb->prepare(' AND driver_id=%d',  (int) $driver_id)  : ' AND driver_id IS NULL' );
    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}ridego_driver_docs WHERE vendor_id=%d AND doc_type=%s{$scope_sql} LIMIT 1",
        $vendor_id, $doc_type
    ));
    $doc_row = array('file_path'=>$rel_path,'status'=>'pending','uploaded_at'=>current_time('mysql'));
    if ( $expiry_val !== null ) { $doc_row['expiry_date'] = $expiry_val; }
    if ($existing) {
        $wpdb->update($wpdb->prefix.'ridego_driver_docs', $doc_row, array('id'=>$existing));
        $doc_id = (int) $existing;
    } else {
        $doc_row['vendor_id'] = intval($vendor_id);
        $doc_row['doc_type']  = sanitize_key($doc_type);
        if ( $vehicle_id ) { $doc_row['vehicle_id'] = (int) $vehicle_id; }
        if ( $driver_id )  { $doc_row['driver_id']  = (int) $driver_id; }
        $wpdb->insert($wpdb->prefix.'ridego_driver_docs', $doc_row);
        $doc_id = (int) $wpdb->insert_id;
    }

    /* Mirror license/insurance expiry onto the vendor record */
    $is_fleet_scoped = ( $vehicle_id || $driver_id );
    if ( $expiry_val !== null && ! $is_fleet_scoped ) {
        if ( $doc_type === 'driving_license' ) {
            $wpdb->update($wpdb->prefix.'ridego_vendors', array('license_expiry'=>$expiry_val), array('id'=>intval($vendor_id)));
        } elseif ( $doc_type === 'vehicle_insurance' ) {
            $wpdb->update($wpdb->prefix.'ridego_vendors', array('insurance_expiry'=>$expiry_val), array('id'=>intval($vendor_id)));
        }
    }

    /* Update vendor KYC status to submitted if all required docs uploaded
       (fleet-scoped documents never count towards the vendor's own KYC set). */
    if ( ! $is_fleet_scoped ) { ridego_check_kyc_completeness($vendor_id); }
    /* A driver's licence document also refreshes that fleet driver's own expiry. */
    if ( $driver_id && $doc_type === 'driving_license' && $expiry_val !== null ) {
        $wpdb->update($wpdb->prefix.'ridego_fleet_drivers', array('license_expiry'=>$expiry_val), array('id'=>(int)$driver_id,'vendor_id'=>intval($vendor_id)));
    }
    // doc_id is required by the app's optimistic UI update (see
    // includes/app-api.php's ridego_app_api_vendor_upload_doc(), which
    // returns this array verbatim as the REST response, and
    // app/src/pages/VendorKycPage.tsx's handleSubmit(), which reads
    // res.doc_id to build the just-uploaded row without waiting for a
    // full reload). Without it, doc_id was undefined, so the "View"
    // button rendered immediately after upload but pointed at
    // /vendor/docs/undefined/file, a guaranteed 404 until the vendor
    // refreshed the page.
    return array('success'=>true,'doc_id'=>$doc_id,'message'=>ucwords(str_replace('_',' ',$doc_type)).' uploaded successfully.');
}

// TRACE: any vendor-level doc-completeness check → the fixed list of vendor-level (not fleet-scoped) document
//        types KYC requires → array. Pure. Single source of truth shared by ridego_check_kyc_completeness()
//        (used to auto-advance kyc_status to 'submitted') and ridego_vendor_kyc_missing_docs() (used to gate/flag
//        approval) so the two can never silently drift apart and disagree about what "complete" means.
function ridego_vendor_kyc_required_docs() {
    return array( 'driving_license', 'vehicle_rc', 'vehicle_insurance', 'pan_card', 'profile_photo' );
}

// TRACE: vendor id → the required doc types with no vendor-level row on file (uploaded OR not — see below) → array
//        of doc_type strings (empty = nothing missing). Root-cause fix (Master Issue Register: KYC approved without
//        documents): ridego_approve_kyc() used to unconditionally flip kyc_status to 'verified' with no check at
//        all — an admin (or a stray API call) could approve a vendor who had uploaded zero documents, and nothing
//        anywhere would ever surface that the "verified" vendor's compliance file is empty. This is the shared
//        check both the approval gate and the retroactive admin-UI warning badge (for vendors already approved
//        before this fix existed) read from. A doc counts as present only when file_path is non-empty — a doc_type
//        row can exist with an empty file_path from an aborted/failed upload, which is not "on file" in any
//        meaningful sense.
function ridego_vendor_kyc_missing_docs( $vendor_id ) {
    global $wpdb;
    $required = ridego_vendor_kyc_required_docs();
    $submitted = $wpdb->get_col( $wpdb->prepare(
        "SELECT doc_type FROM {$wpdb->prefix}ridego_driver_docs WHERE vendor_id=%d AND file_path!='' AND vehicle_id IS NULL AND driver_id IS NULL",
        $vendor_id
    ) );
    return array_values( array_diff( $required, $submitted ) );
}

// TRACE: after a vendor-level doc upload → checks all required vendor-level doc types exist (fleet-scoped docs ignored) and advances the vendor status → void/bool.
//        Preconditions: vendor exists → Postconditions: status advanced only when complete → Edge cases: fleet docs present (ignored).
function ridego_check_kyc_completeness( $vendor_id ) {
    global $wpdb;
    $all_submitted = empty( ridego_vendor_kyc_missing_docs( $vendor_id ) );
    if ($all_submitted) {
        $vendor = ridego_get_vendor($vendor_id);
        if ($vendor && $vendor->kyc_status === 'pending') {
            global $wpdb;
            $wpdb->update($wpdb->prefix.'ridego_vendors',array('kyc_status'=>'submitted'),array('id'=>$vendor_id));
            do_action('ridego_kyc_submitted',$vendor_id);
        }
    }
}

/*  Admin: Approve KYC  */
// TRACE: admin "Approve KYC" → verifies the vendor's required documents are actually on file before flipping
//        kyc_status → array(success, missing_docs?, message). Root-cause fix (Master Issue Register): this
//        used to unconditionally approve with no check at all. Now a vendor missing any required doc is refused
//        UNLESS $force is true, in which case it proceeds anyway but is audit-logged with the missing list
//        attached — the override exists because a real business may have verified documents through an offline
//        channel (email, in person) that this system has no upload record of, so this is a gate with an
//        explicit, logged escape hatch, not an absolute block. Preconditions: vendor exists. Postconditions on
//        success: kyc_status=verified, documents_verified=1, status=active, pending docs marked verified,
//        audited (with 'forced'=>true in the log when the override was used). Edge cases: unknown vendor id
//        (success=false); missing docs and no force (success=false, missing_docs populated, nothing changed).
function ridego_approve_kyc( $vendor_id, $admin_id, $force = false ) {
    global $wpdb;
    $vendor = ridego_get_vendor($vendor_id);
    if (!$vendor) return array( 'success' => false, 'message' => 'Vendor not found.' );
    $missing = ridego_vendor_kyc_missing_docs( $vendor_id );
    if ( $missing && ! $force ) {
        return array(
            'success' => false, 'missing_docs' => $missing,
            'message' => 'This vendor is missing required documents: ' . implode( ', ', array_map( 'ucwords', array_map( function ( $d ) { return str_replace( '_', ' ', $d ); }, $missing ) ) ) . '. Approve anyway only if you have verified these through another channel.',
        );
    }
    $wpdb->update($wpdb->prefix.'ridego_vendors',array(
        'kyc_status'         => 'verified',
        'documents_verified' => 1,
        'status'             => 'active',
    ),array('id'=>$vendor_id));
    /* Verify all pending docs */
    $wpdb->update($wpdb->prefix.'ridego_driver_docs',
        array('status'=>'verified','verified_by'=>$admin_id,'verified_at'=>current_time('mysql')),
        array('vendor_id'=>$vendor_id,'status'=>'pending')
    );
    ridego_audit_log('kyc_approved','vendor',$vendor_id,'', $missing ? ( 'forced — missing: ' . implode( ',', $missing ) ) : '' );
    do_action('ridego_kyc_approved',$vendor_id);
    return array( 'success' => true, 'message' => 'KYC approved. Vendor activated.', 'forced' => (bool) $missing );
}

/*  Admin: Reject KYC  */
// TRACE: admin rejects KYC → marks the vendor-level doc(s) rejected with reason and notifies → array.
//        Preconditions: admin authorised → Postconditions: only vendor-level docs affected → Edge cases: unknown doc type, fleet-scoped docs untouched.
function ridego_reject_kyc( $vendor_id, $reason, $doc_type = '' ) {
    global $wpdb;
    $wpdb->update($wpdb->prefix.'ridego_vendors',array('kyc_status'=>'rejected'),array('id'=>$vendor_id));
    if ($doc_type) {
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}ridego_driver_docs SET status='rejected', notes=%s WHERE vendor_id=%d AND doc_type=%s AND vehicle_id IS NULL AND driver_id IS NULL",
            sanitize_textarea_field($reason), (int)$vendor_id, $doc_type
        ));
    }
    ridego_audit_log('kyc_rejected','vendor',$vendor_id,'',$reason);
    do_action('ridego_kyc_rejected',$vendor_id,$reason,$doc_type);
    return true;
}

/*  Suspend / Activate vendor  */
/**
 * Vendor account status state machine.
 *
 * The original implementation accepted any target status with no check
 * against the vendor's CURRENT status, meaning a single unconditional
 * write could silently reactivate a blacklisted vendor (a real fraud/
 * trust-and-safety exposure for a marketplace) or move a vendor through
 * a nonsensical transition. This enforces a real, explicit transition
 * table, requires a reason for every transition that removes or restores
 * a vendor's ability to operate, and logs a `warning`-severity audit
 * entry specifically when a blacklisted vendor is reactivated so that
 * override is always conspicuous rather than an ordinary status change.
 */
function ridego_get_vendor_status_transitions() {
    return array(
        'pending'     => array('active', 'suspended', 'blacklisted'),
        'active'      => array('suspended', 'blacklisted'),
        'suspended'   => array('active', 'blacklisted'),
        'blacklisted' => array('active'), // reinstatement — allowed, but treated as a flagged override below
    );
}

function ridego_set_vendor_status( $vendor_id, $status, $reason = '' ) {
    global $wpdb;
    $allowed = array('active','suspended','blacklisted','pending');
    if (!in_array($status,$allowed,true)) {
        return array('success'=>false,'message'=>'Invalid target status.');
    }
    $vendor = ridego_get_vendor($vendor_id);
    if (!$vendor) {
        return array('success'=>false,'message'=>'Vendor not found.');
    }
    $current = $vendor->status;
    if ($current === $status) {
        return array('success'=>false,'message'=>'Vendor is already '.$status.'.');
    }

    $transitions = ridego_get_vendor_status_transitions();
    $legal = isset($transitions[$current]) ? $transitions[$current] : array();
    if (!in_array($status, $legal, true)) {
        return array('success'=>false,'message'=>"Cannot move a vendor from '{$current}' to '{$status}' directly.");
    }

    $requires_reason = in_array($status, array('suspended','blacklisted'), true)
        || ($current === 'blacklisted' && $status === 'active');
    if ($requires_reason && trim((string)$reason) === '') {
        return array('success'=>false,'message'=>'A reason is required for this status change.');
    }

    $wpdb->update($wpdb->prefix.'ridego_vendors',array('status'=>$status),array('id'=>$vendor_id));
    if ($reason) {
        $wpdb->update($wpdb->prefix.'ridego_vendors',array('notes_admin'=>$vendor->notes_admin."\n[".date('d M Y')."] Status: {$status}. Reason: {$reason}"),array('id'=>$vendor_id));
    }

    $is_blacklist_override = ($current === 'blacklisted' && $status === 'active');
    ridego_audit_log(
        'vendor_status_change', 'vendor', $vendor_id, $current, $status,
        $is_blacklist_override ? 'warning' : 'info'
    );
    do_action('ridego_vendor_status_changed',$vendor_id,$status,$reason);
    return array('success'=>true,'message'=>'Vendor status updated to '.$status.'.');
}

/*  Get vendor documents  */
// TRACE: vendor KYC screen → returns only vendor-level documents (vehicle_id and driver_id NULL) → array of rows.
//        Preconditions: none → Postconditions: read-only → Edge cases: none (empty array).
function ridego_get_vendor_docs( $vendor_id ) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_driver_docs WHERE vendor_id=%d AND vehicle_id IS NULL AND driver_id IS NULL ORDER BY doc_type ASC",
        $vendor_id
    ));
}

/*  Get vendor wallet transactions  */
function ridego_get_vendor_wallet_history( $vendor_id, $limit = 30, $offset = 0 ) {
    global $wpdb;
    return $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_vendor_wallets WHERE vendor_id=%d ORDER BY created_at DESC LIMIT %d OFFSET %d",
        $vendor_id, $limit, $offset
    ));
}

/*  Get vendor earnings summary  */
function ridego_get_vendor_earnings( $vendor_id, $period = 'month' ) {
    global $wpdb;
    $date_from = '';
    switch ($period) {
        case 'today': $date_from = date('Y-m-d'); break;
        case 'week':  $date_from = date('Y-m-d', strtotime('-7 days')); break;
        case 'month': $date_from = date('Y-m-01'); break;
        case 'year':  $date_from = date('Y-01-01'); break;
    }
    $where = $date_from ? $wpdb->prepare("AND created_at >= %s", $date_from) : '';
    $leads     = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}ridego_leads WHERE vendor_id=%d AND status='completed' {$where}",$vendor_id));
    $fees_paid = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(fee_amount),0) FROM {$wpdb->prefix}ridego_leads WHERE vendor_id=%d AND status='completed' AND fee_deducted=1 {$where}",$vendor_id));
    $rides     = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}ridego_bookings WHERE vendor_id=%d AND status='completed' {$where}",$vendor_id));
    $gross     = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total_fare),0) FROM {$wpdb->prefix}ridego_bookings WHERE vendor_id=%d AND status='completed' {$where}",$vendor_id));
    $col_by_vendor = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(vendor_collected),0) FROM {$wpdb->prefix}ridego_bookings WHERE vendor_id=%d AND status='completed' {$where}",$vendor_id));
    $held_by_ridego = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(advance_paid),0) FROM {$wpdb->prefix}ridego_bookings WHERE vendor_id=%d AND status='completed' {$where}",$vendor_id));
    // Facilitator bookings: the lead fee the central engine fixed for each completed trip (waived fees are 0), on top of any legacy wallet lead fees.
    $lf_total  = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(vendor_lead_fee),0) FROM {$wpdb->prefix}ridego_bookings WHERE vendor_id=%d AND status='completed' AND platform_model=1 AND vendor_lead_fee_status<>'waived' {$where}",$vendor_id));
    $fees_paid += $lf_total;
    return array(
        'vendor_lead_fee_total' => $lf_total,
        'collected_by_vendor' => $col_by_vendor,
        'booking_amount_held_by_ridego' => $held_by_ridego,
        'leads_accepted'   => $leads,
        'lead_fees_paid'   => $fees_paid,
        'rides_completed'  => $rides,
        'gross_fare_earned'=> $gross,
        'net_earnings'     => $gross - $fees_paid,
        'period'           => $period,
    );
}

/*  Weighted vendor "Performance Score" for a date range.
    Single source of truth for the scoring formula, extracted from
    admin/pages/reports.php (Top Performing Vendors table) so the REST API
    (includes/rest-api.php: GET /ridego/v1/reports/vendor-performance) and
    the admin UI can never drift apart.

    Formula (unchanged from the original admin-page implementation):
      40% completed-trip count (normalised against the best performer)
      25% completion rate (completed / total bookings in range)
      25% average client rating (0-5 scaled to 0-100)
      10% inverse cancellation rate (100 - cancellation%)

    Args: $from, $to (Y-m-d date strings, inclusive, matched against
    ridego_leads.sent_at / ridego_bookings.created_at).
    Returns an array of vendor row objects (id, business_name, phone,
    rating, leads_total, completed_trips, cancelled_trips, bookings_total,
    perf_score, completion_rate_pct, cancellation_rate_pct, breakdown),
    sorted by perf_score descending. */
function ridego_get_vendor_performance_scores( $from, $to ) {
    global $wpdb;
    $btbl = $wpdb->prefix.'ridego_bookings';
    $vtbl = $wpdb->prefix.'ridego_vendors';

    $vendor_perf = $wpdb->get_results($wpdb->prepare(
        "SELECT v.id, v.business_name, v.phone, v.rating,
                COUNT(DISTINCT l.id) AS leads_total,
                SUM(CASE WHEN b.status='completed' THEN 1 ELSE 0 END) AS completed_trips,
                SUM(CASE WHEN b.status='cancelled' THEN 1 ELSE 0 END) AS cancelled_trips,
                COUNT(DISTINCT b.id) AS bookings_total
         FROM $vtbl v
         LEFT JOIN {$wpdb->prefix}ridego_leads l ON l.vendor_id=v.id AND DATE(l.sent_at) BETWEEN %s AND %s
         LEFT JOIN $btbl b ON b.vendor_id=v.id AND DATE(b.created_at) BETWEEN %s AND %s
         WHERE v.status='active'
         GROUP BY v.id
         HAVING bookings_total > 0 OR leads_total > 0
         ", $from, $to, $from, $to
    ));

    $max_completed = 1;
    foreach ( $vendor_perf as $vp ) { $max_completed = max( $max_completed, (int) $vp->completed_trips ); }

    foreach ( $vendor_perf as $vp ) {
        $completed = (int) $vp->completed_trips;
        $bookings  = max( 0, (int) $vp->bookings_total );
        $cancelled = (int) $vp->cancelled_trips;
        $completion_rate   = $bookings > 0 ? ( $completed / $bookings ) : 0;
        $cancellation_rate = $bookings > 0 ? ( $cancelled / $bookings ) : 0;
        $volume_score       = ( $completed / $max_completed ) * 40;
        $completion_score   = $completion_rate * 25;
        $rating_score       = ( min( 5, max( 0, (float) $vp->rating ) ) / 5 ) * 25;
        /* Root-cause fix: cancellation_score is an INVERSE metric — (1 - rate) * 10 —
           so a vendor with zero bookings had its 0/0 cancellation_rate guard to 0,
           which this formula then read as "0% cancellations, flawless record" and
           handed the full 10/10. That silently rewarded having done no work at all
           the same as having completed every single trip with zero cancellations,
           letting an inactive vendor (0 volume, 0 completion, but a perfect
           cancellation sub-score) rank above a vendor who actually worked and had
           one or two cancellations along the way. A rate computed from zero
           opportunities to fail isn't evidence of reliability, so it earns no
           credit here — only a vendor who actually had bookings to potentially
           cancel can earn (or lose) cancellation score. */
        $cancellation_score = $bookings > 0 ? ( 1 - min( 1, $cancellation_rate ) ) * 10 : 0;
        $vp->perf_score            = round( $volume_score + $completion_score + $rating_score + $cancellation_score, 1 );
        $vp->completion_rate_pct   = round( $completion_rate * 100 );
        $vp->cancellation_rate_pct = round( $cancellation_rate * 100 );
        $vp->breakdown = array(
            'volume'       => round( $volume_score, 1 ),
            'completion'   => round( $completion_score, 1 ),
            'rating'       => round( $rating_score, 1 ),
            'cancellation' => round( $cancellation_score, 1 ),
        );
    }

    usort( $vendor_perf, function( $a, $b ) { return $b->perf_score <=> $a->perf_score; } );

    return $vendor_perf;
}

/*  Get vendors eligible for a booking  */
// TRACE: lead distribution → filters and scores active, non-blacklisted vendors for a booking, applying the subscription lead cap over the period counted by leads.sent_at → array of vendor objects.
//        Preconditions: booking exists → Postconditions: read-only → Edge cases: plan cap reached (vendor skipped), no vendors (empty).
function ridego_get_eligible_vendors( $booking_id, $reoffer = false ) {
    global $wpdb;
    $booking = ridego_get_booking($booking_id);
    if (!$booking) return array();
    $min_wallet = (float)ridego_get_setting('min_wallet_balance',200);
    $lead_fee   = ridego_calculate_lead_fee_for_booking($booking_id);

    /* Get vendors matching: active + verified + serves city + has vehicle type + wallet ok */
    $all = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_vendors
         WHERE status='active'
         AND kyc_status='verified'
         AND documents_verified=1
         AND wallet_balance >= %f
         AND (license_expiry IS NULL OR license_expiry >= CURDATE())
         AND (insurance_expiry IS NULL OR insurance_expiry >= CURDATE())
         ORDER BY rating DESC, total_rides_completed DESC",
        max($min_wallet, $lead_fee)
    ));

    $eligible = array();
    foreach ($all as $v) {
        /* Check city */
        $cities = json_decode($v->operating_cities, true);
        if (!is_array($cities)) $cities = array($v->city);
        $serves_city = false;
        foreach ($cities as $c) {
            if (stripos($c, $booking->pickup_city) !== false || stripos($booking->pickup_city, $c) !== false) {
                $serves_city = true; break;
            }
        }
        if (!$serves_city) continue;

        /* Check vehicle type */
        $vtypes = json_decode($v->vehicle_types, true);
        if (is_array($vtypes) && count($vtypes) > 0 && !in_array($booking->vehicle_type_id,$vtypes)) continue;

        /* Check not already received this lead */
        $already = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ridego_leads WHERE booking_id=%d AND vendor_id=%d" . ( $reoffer ? " AND status<>'expired'" : '' ) . " LIMIT 1",
            $booking_id, $v->id
        ));
        if ($already) continue;

        /* Enforce the active plan's monthly lead cap (max_leads=0 means
           unlimited, per the convention set in admin/pages/subscriptions.php).
           Leads received this billing period are counted from ridego_leads
           joined to the vendor's current subscription_expires window rather
           than a separate counter column, so no extra state can drift out
           of sync with the leads table itself. Only counted when the plan
           is genuinely active and not stale/expired. */
        if ( ! empty( $v->subscription_plan_id ) && $v->subscription_status === 'active'
             && ! empty( $v->subscription_expires ) && strtotime( $v->subscription_expires ) >= time() ) {
            $plan = ridego_get_subscription_plan( $v->subscription_plan_id );
            if ( $plan && (int) $plan->max_leads > 0 ) {
                $period_start = date( 'Y-m-d H:i:s', strtotime( $v->subscription_expires . ' -1 ' . ( $plan->billing_cycle === 'yearly' ? 'year' : ( $plan->billing_cycle === 'quarterly' ? '3 months' : 'month' ) ) ) );
                $leads_this_period = (int) $wpdb->get_var( $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_leads WHERE vendor_id=%d AND sent_at >= %s",
                    $v->id, $period_start
                ) );
                if ( $leads_this_period >= (int) $plan->max_leads ) { continue; }
            }
        }

        $eligible[] = $v;
    }

    /* Score vendors. Formula:
       score = (rating/5 * 40)                                   [0-40]
             + (accept_rate * 20)                                [0-20]
             + min(10, years_experience * 2)                     [0-10]
             + subscription plan's priority_boost, added as a direct
               weighted addition (capped at 20 so no plan can fully
               override quality/experience signals) — only applied
               while the plan is genuinely active and unexpired,
               never off a stale subscription_plan_id.            [0-20]
       Max possible score: 90. */
    foreach ($eligible as &$v) {
        $score  = 0;
        $score += ($v->rating / 5) * 40;
        $total  = max(1, $v->total_leads_received);
        $score += ($v->total_leads_accepted / $total) * 20;
        $score += min(10, $v->years_experience * 2);

        $priority_boost = 0;
        if ( ! empty( $v->subscription_plan_id ) && $v->subscription_status === 'active'
             && ! empty( $v->subscription_expires ) && strtotime( $v->subscription_expires ) >= time() ) {
            $plan = ridego_get_subscription_plan( $v->subscription_plan_id );
            if ( $plan ) {
                $priority_boost = min( 20, (float) $plan->priority_boost );
            }
        }
        $score += $priority_boost;

        $v->lead_score = round($score, 2);
    }
    unset($v);

    usort($eligible, function($a,$b){ return $b->lead_score <=> $a->lead_score; });
    return $eligible;
}
