<?php
/**
 * RideGo back-office booking operations: quote, create, edit/reschedule, payments and refunds, notes, invoice.
 * Every function here is UI-agnostic (returns arrays) so the REST layer, wp-admin and tests share one implementation.
 * Pricing reuses ridego_calculate_fare(); assignment reuses ridego_admin_assign_vendor() / ridego_replace_assignment();
 * notifications reuse the existing hooks and the notification queue, so an admin booking behaves like an online one.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: create/edit validation → allowed trip types → array. Pure. multi-stop journeys are one_way/outstation/round_trip with via stops.
function ridego_admin_trip_types() { return array( 'one_way', 'round_trip', 'local', 'airport_pickup', 'airport_drop', 'outstation' ); }

// TRACE: record payment → allowed payment methods → array. Pure.
function ridego_payment_methods() { return array( 'cash', 'upi', 'bank_transfer', 'card', 'cheque', 'razorpay', 'other' ); }

// TRACE: any edit path → statuses in which a booking is still editable → array. Pure.
function ridego_booking_editable_statuses() {
    return array( 'pending', 'pending_payment', 'payment_pending', 'payment_proof_submitted', 'payment_rejected', 'confirmed', 'no_vendor', 'vendor_assigned', 'driver_en_route', 'trip_started' );
}

// TRACE: raw trip input (create or edit) → normalised trip array + error → array('trip'=>|null,'error'=>|null).
//        $partial=true (edit) validates only the keys present. Times accept HH:MM or HH:MM:SS and are stored HH:MM:SS.
//        Rules: pickup city required (drop city unless local); round_trip needs return date/time not before the outward leg; local needs hours 1-24;
//        journey must be in the future unless allow_past; passengers 1-50; stops (array or comma text) stored as via_cities (max 10).
//        Edge cases: malformed dates/times (message naming the field), vehicle inactive/unknown (message), passenger list longer than 20 (message).
function ridego_admin_normalise_trip( $in, $partial = false, $allow_past = false ) {
    $t = array(); $fail = function ( $m ) { return array( 'trip' => null, 'error' => $m ); };
    $has = function ( $k ) use ( $in, $partial ) { return ! $partial || array_key_exists( $k, $in ); };
    if ( $has( 'trip_type' ) ) {
        $tt = sanitize_key( (string) ( $in['trip_type'] ?? '' ) ); if ( $tt === 'hourly' ) { $tt = 'local'; }
        if ( ! in_array( $tt, ridego_admin_trip_types(), true ) ) { return $fail( 'Choose a trip type.' ); }
        $t['trip_type'] = $tt;
    }
    foreach ( array( 'pickup_city' => 100, 'drop_city' => 100, 'flight_number' => 20, 'corporate_company' => 150, 'corporate_cost_centre' => 50, 'corporate_emp_id' => 50 ) as $k => $max ) {
        if ( $has( $k ) ) { $t[ $k ] = mb_substr( sanitize_text_field( (string) ( $in[ $k ] ?? '' ) ), 0, $max ); }
    }
    if ( array_key_exists( 'corporate_gst', $in ) ) { $t['corporate_gst'] = strtoupper( mb_substr( sanitize_text_field( (string) $in['corporate_gst'] ), 0, 20 ) ); }
    foreach ( array( 'pickup_address', 'drop_address', 'special_requests' ) as $k ) {
        if ( $has( $k ) ) { $t[ $k ] = mb_substr( sanitize_textarea_field( (string) ( $in[ $k ] ?? '' ) ), 0, 1000 ); }
    }
    foreach ( array( 'pickup_lat', 'pickup_lng', 'drop_lat', 'drop_lng' ) as $k ) { if ( isset( $in[ $k ] ) && $in[ $k ] !== '' ) { $t[ $k ] = (float) $in[ $k ]; } }
    if ( array_key_exists( 'stops', $in ) || array_key_exists( 'via_cities', $in ) ) {
        $s = $in['stops'] ?? $in['via_cities']; $s = is_array( $s ) ? $s : explode( ',', (string) $s );
        $s = array_values( array_filter( array_map( function ( $x ) { return trim( sanitize_text_field( (string) $x ) ); }, $s ), 'strlen' ) );
        if ( count( $s ) > 10 ) { return $fail( 'A trip can have at most 10 stops.' ); }
        $t['via_cities'] = implode( ', ', $s );
    }
    if ( $has( 'journey_date' ) ) {
        $d = (string) ( $in['journey_date'] ?? '' );
        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) || ! checkdate( (int) substr( $d, 5, 2 ), (int) substr( $d, 8, 2 ), (int) substr( $d, 0, 4 ) ) ) { return $fail( 'Enter the journey date.' ); }
        $t['journey_date'] = $d;
    }
    if ( $has( 'journey_time' ) ) {
        $tm = (string) ( $in['journey_time'] ?? '' );
        if ( ! preg_match( '/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/', $tm ) ) { return $fail( 'Enter the pickup time (HH:MM).' ); }
        $t['journey_time'] = strlen( $tm ) === 5 ? $tm . ':00' : $tm;
    }
    foreach ( array( 'return_date' ) as $k ) {
        if ( array_key_exists( $k, $in ) ) {
            $d = (string) $in[ $k ];
            if ( $d !== '' && ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) || ! checkdate( (int) substr( $d, 5, 2 ), (int) substr( $d, 8, 2 ), (int) substr( $d, 0, 4 ) ) ) ) { return $fail( 'Enter a valid return date.' ); }
            $t[ $k ] = $d === '' ? null : $d;
        }
    }
    if ( array_key_exists( 'return_time', $in ) ) {
        $tm = (string) $in['return_time'];
        if ( $tm !== '' && ! preg_match( '/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/', $tm ) ) { return $fail( 'Enter a valid return time (HH:MM).' ); }
        $t['return_time'] = $tm === '' ? null : ( strlen( $tm ) === 5 ? $tm . ':00' : $tm );
    }
    if ( array_key_exists( 'hours_required', $in ) ) { $t['hours_required'] = max( 0, min( 24, (int) $in['hours_required'] ) ); }
    if ( $has( 'vehicle_type_id' ) ) {
        $veh = ridego_get_vehicle( (int) ( $in['vehicle_type_id'] ?? 0 ) );
        if ( ! $veh || ! $veh->is_active ) { return $fail( 'Choose an active vehicle type.' ); }
        $t['vehicle_type_id'] = (int) $veh->id;
    }
    if ( $has( 'passengers' ) || array_key_exists( 'passenger_details', $in ) ) {
        $list = array();
        foreach ( (array) ( $in['passenger_details'] ?? array() ) as $p ) {
            $p = (array) $p; $name = trim( sanitize_text_field( (string) ( $p['name'] ?? '' ) ) );
            if ( $name === '' ) { continue; }
            $ph = ridego_sanitize_phone( (string) ( $p['phone'] ?? '' ) );
            $list[] = array( 'name' => mb_substr( $name, 0, 100 ), 'phone' => $ph, 'age' => isset( $p['age'] ) && $p['age'] !== '' ? max( 0, min( 120, (int) $p['age'] ) ) : null );
        }
        if ( count( $list ) > 20 ) { return $fail( 'At most 20 passenger names can be stored.' ); }
        $n = isset( $in['passengers'] ) ? (int) $in['passengers'] : max( 1, count( $list ) );
        if ( $n < 1 || $n > 50 ) { return $fail( 'Passengers must be between 1 and 50.' ); }
        if ( count( $list ) > $n ) { return $fail( 'There are more passenger names than the passenger count.' ); }
        $t['passengers'] = $n;
        if ( array_key_exists( 'passenger_details', $in ) ) { $t['passenger_details'] = $list ? wp_json_encode( $list ) : ''; }
    }
    if ( array_key_exists( 'luggage_count', $in ) ) { $t['luggage_count'] = max( 0, min( 100, (int) $in['luggage_count'] ) ); }
    if ( ! $partial ) {
        if ( empty( $t['pickup_city'] ) ) { return $fail( 'Enter the pickup city or location.' ); }
        if ( $t['trip_type'] !== 'local' && empty( $t['drop_city'] ) ) { return $fail( 'Enter the drop city or location.' ); }
        if ( $t['trip_type'] === 'local' && empty( $t['hours_required'] ) ) { return $fail( 'Enter the hours required for a local/hourly booking.' ); }
        if ( $t['trip_type'] === 'round_trip' && empty( $t['return_date'] ) ) { return $fail( 'Enter the return date for a round trip.' ); }
        if ( $t['trip_type'] === 'local' ) { $t['drop_city'] = $t['drop_city'] ?? ''; }
    }
    if ( isset( $t['journey_date'], $t['journey_time'] ) ) {
        if ( ! $allow_past && $t['journey_date'] . ' ' . $t['journey_time'] < current_time( 'Y-m-d H:i:s' ) ) { return $fail( 'The pickup date and time is in the past. Tick "back-entry" to record a trip that has already happened.' ); }
        if ( ! empty( $t['return_date'] ) && $t['return_date'] . ' ' . ( $t['return_time'] ?? '00:00:00' ) < $t['journey_date'] . ' ' . $t['journey_time'] ) { return $fail( 'The return cannot be before the outward journey.' ); }
    }
    return array( 'trip' => $t, 'error' => null );
}

// TRACE: normalised trip + optional fare overrides → complete fare breakdown → array('fare'=>|null,'error'=>|null).
//        Auto fare comes from ridego_calculate_fare(); night/surge/extra-hour/extra-km fold into `extras` so the stored components add up to the
//        subtotal exactly. Overrides (all optional, ≥0): base_fare, toll_charges, parking_charges, driver_allowance, extras, discount_amount|discount_percent,
//        gst_mode auto|none|custom (+gst_amount), adjustment (may be negative). discount ≤ subtotal; total ≥ 0; a reason is required for any discount/adjustment.
//        Edge cases: unpriceable route (error from the pricing engine), 'overridden' true when any component differs from the auto value.
function ridego_admin_compute_fare( $trip, $ov = array() ) {
    $ov = (array) $ov;
    $auto = ridego_calculate_fare( $trip );
    if ( isset( $auto['error'] ) ) { return array( 'fare' => null, 'error' => $auto['error'] ); }
    $a = array(
        'base_fare' => (float) $auto['base_fare'], 'toll_charges' => (float) $auto['toll_charges'], 'parking_charges' => (float) $auto['parking_charges'],
        'driver_allowance' => (float) $auto['driver_allowance'],
        'extras' => round( (float) $auto['night_charge'] + (float) $auto['surge_amount'] + (float) $auto['extra_km_charges'] + (float) $auto['extra_hour_charge'], 2 ),
    );
    $c = $a; $overridden = false;
    foreach ( $a as $k => $v ) {
        if ( isset( $ov[ $k ] ) && $ov[ $k ] !== '' && $ov[ $k ] !== null ) {
            if ( ! is_numeric( $ov[ $k ] ) || (float) $ov[ $k ] < 0 ) { return array( 'fare' => null, 'error' => 'Fare amounts cannot be negative or non-numeric (' . str_replace( '_', ' ', $k ) . ').' ); }
            $c[ $k ] = round( (float) $ov[ $k ], 2 ); if ( abs( $c[ $k ] - $v ) > 0.004 ) { $overridden = true; }
        }
    }
    $subtotal = round( array_sum( $c ), 2 );
    $discount = 0.0;
    if ( isset( $ov['discount_percent'] ) && (float) $ov['discount_percent'] > 0 ) {
        if ( (float) $ov['discount_percent'] > 100 ) { return array( 'fare' => null, 'error' => 'A discount cannot be more than 100%.' ); }
        $discount = round( $subtotal * (float) $ov['discount_percent'] / 100, 2 );
    }
    if ( isset( $ov['discount_amount'] ) && $ov['discount_amount'] !== '' ) {
        if ( ! is_numeric( $ov['discount_amount'] ) || (float) $ov['discount_amount'] < 0 ) { return array( 'fare' => null, 'error' => 'The discount cannot be negative.' ); }
        $discount = round( (float) $ov['discount_amount'], 2 );
    }
    if ( $discount > $subtotal + 0.004 ) { return array( 'fare' => null, 'error' => 'The discount cannot be more than the fare.' ); }
    $taxable = round( $subtotal - $discount, 2 );
    $mode = sanitize_key( (string) ( $ov['gst_mode'] ?? 'auto' ) );
    if ( $mode === 'none' ) { $gst = 0.0; }
    elseif ( $mode === 'custom' ) {
        if ( ! isset( $ov['gst_amount'] ) || ! is_numeric( $ov['gst_amount'] ) || (float) $ov['gst_amount'] < 0 ) { return array( 'fare' => null, 'error' => 'Enter a valid GST amount.' ); }
        $gst = round( (float) $ov['gst_amount'], 2 );
    } else {
        // Root-cause fix: this used to recompute taxable * gst_percent directly,
        // ignoring the gst_enabled toggle entirely — an admin-created/edited
        // booking would get GST added even with GST turned off globally, a
        // second, parallel path missed by gating only ridego_calculate_fare().
        // $auto['gst_amount'] already correctly comes out to 0 when disabled
        // (see ridego_calculate_fare()), so reuse it, scaled for any override
        // to base/toll/parking/etc that changed the taxable amount from auto's.
        $mode = 'auto';
        $auto_gst_percent = (float) ( $auto['gst_percent'] ?? 5 );
        $gst_enabled = ! empty( $auto['gst_enabled'] );
        $gst = $gst_enabled ? round( $taxable * ( $auto_gst_percent / 100 ), 2 ) : 0.0;
    }
    $adj = ( isset( $ov['adjustment'] ) && $ov['adjustment'] !== '' ) ? round( (float) $ov['adjustment'], 2 ) : 0.0;
    $reason = trim( sanitize_text_field( (string) ( $ov['adjustment_reason'] ?? $ov['discount_reason'] ?? '' ) ) );
    if ( ( $discount > 0 || abs( $adj ) > 0.004 ) && $reason === '' ) { return array( 'fare' => null, 'error' => 'Give a reason for the discount or adjustment.' ); }
    $total = round( $taxable + $gst + $adj, 2 );
    if ( $total < 0 ) { return array( 'fare' => null, 'error' => 'The total fare cannot be negative.' ); }
    if ( $gst > 0.004 && $mode !== 'auto' ) { $overridden = true; } elseif ( $mode === 'none' ) { $overridden = true; }
    // booking amount: the only part RideGo collects. Default from Settings; an admin may set a different amount (0 = waive it) but must say why when it differs.
    $ba_default = ridego_booking_amount_for( $total ); $ba = $ba_default; $ba_reason = '';
    if ( isset( $ov['booking_amount'] ) && $ov['booking_amount'] !== '' && $ov['booking_amount'] !== null ) {
        if ( ! is_numeric( $ov['booking_amount'] ) || (float) $ov['booking_amount'] < 0 ) { return array( 'fare' => null, 'error' => 'The booking amount cannot be negative.' ); }
        $ba = round( (float) $ov['booking_amount'], 2 );
        if ( $ba > $total + 0.004 ) { return array( 'fare' => null, 'error' => 'The booking amount cannot be more than the estimated ride fare.' ); }
        $ba_reason = trim( sanitize_text_field( (string) ( $ov['booking_amount_reason'] ?? '' ) ) );
        if ( abs( $ba - $ba_default ) > 0.004 && $ba_reason === '' ) { return array( 'fare' => null, 'error' => 'Give a reason for changing the booking amount from the standard ₹' . number_format( $ba_default, 2 ) . '.' ); }
    }
    return array( 'error' => null, 'fare' => array(
        'booking_amount' => $ba, 'booking_amount_default' => $ba_default, 'booking_amount_reason' => $ba_reason, 'payable_to_vendor' => max( 0, round( $total - $ba, 2 ) ),
        'base_fare' => $c['base_fare'], 'toll_charges' => $c['toll_charges'], 'parking_charges' => $c['parking_charges'], 'driver_allowance' => $c['driver_allowance'], 'extras' => $c['extras'],
        'subtotal' => $subtotal, 'discount_amount' => $discount, 'gst_mode' => $mode, 'gst_percent' => (float) ( $auto['gst_percent'] ?? 5 ), 'gst_amount' => $gst, 'adjustment' => $adj, 'adjustment_reason' => $reason,
        'total_fare' => $total, 'auto_total' => round( (float) $auto['total_fare'], 2 ), 'overridden' => $overridden || $discount > 0 || abs( $adj ) > 0.004,
        'distance_km' => (float) $auto['distance_km'], 'duration_minutes' => (int) $auto['duration_minutes'], 'auto' => $a,
        'inclusions' => (array) ( $auto['inclusions'] ?? array() ), 'exclusions' => (array) ( $auto['exclusions'] ?? array() ),
    ) );
}

// TRACE: payload {client_id|new_client, ...trip..., fare{...}} → priced preview without saving → array(success, trip, fare, client?, warnings[]).
//        Warnings (not errors): blocked client, possible duplicate booking, short notice, no vendor of that vehicle type. Edge cases: any validation error → success=false + message.
function ridego_admin_booking_quote( $in ) {
    $n = ridego_admin_normalise_trip( (array) $in, false, ! empty( $in['allow_past'] ) );
    if ( $n['error'] ) { return array( 'success' => false, 'message' => $n['error'] ); }
    $f = ridego_admin_compute_fare( $n['trip'], (array) ( $in['fare'] ?? array() ) );
    if ( $f['error'] ) { return array( 'success' => false, 'message' => $f['error'] ); }
    $warnings = array();
    if ( ! empty( $in['client_id'] ) ) {
        $c = ridego_client_get( (int) $in['client_id'] );
        if ( $c && $c->status === 'blocked' ) { $warnings[] = 'This client is blocked.'; }
        if ( $c ) { $dup = ridego_admin_find_duplicate_booking( (int) $c->id, $n['trip'] ); if ( $dup ) { $warnings[] = 'This client already has booking ' . $dup->booking_number . ' for the same trip.'; } }
    }
    $hrs = ( strtotime( $n['trip']['journey_date'] . ' ' . $n['trip']['journey_time'] ) - strtotime( current_time( 'Y-m-d H:i:s' ) ) ) / 3600;
    if ( $hrs >= 0 && $hrs < (int) ridego_get_setting( 'booking_advance_hours', 2 ) ) { $warnings[] = 'Short notice: the pickup is less than ' . (int) ridego_get_setting( 'booking_advance_hours', 2 ) . ' hours away.'; }
    $lf = ridego_lead_fee_for( (float) ( $f['fare']['total_fare'] ?? 0 ), (int) ( $in['vendor_id'] ?? 0 ), (string) ( $n['trip']['trip_type'] ?? '' ) );
    return array( 'success' => true, 'trip' => $n['trip'], 'fare' => $f['fare'], 'warnings' => $warnings, 'lead_fee_estimate' => array( 'amount' => $lf['fee'], 'formula' => $lf['formula'], 'source' => $lf['source'], 'enabled' => $lf['enabled'] ) );
}

// TRACE: client profile id + normalised trip → an existing live booking for the same client, date, time, route and vehicle, or null. Pure read.
function ridego_admin_find_duplicate_booking( $client_profile_id, $trip, $exclude_id = 0 ) {
    global $wpdb;
    if ( empty( $trip['journey_date'] ) || empty( $trip['journey_time'] ) ) { return null; }
    return $wpdb->get_row( $wpdb->prepare(
        "SELECT id, booking_number FROM {$wpdb->prefix}ridego_bookings WHERE client_profile_id=%d AND journey_date=%s AND journey_time=%s AND pickup_city=%s AND drop_city=%s
         AND vehicle_type_id=%d AND status NOT IN ('cancelled','expired','completed','token_refund_due') AND id<>%d LIMIT 1",
        (int) $client_profile_id, $trip['journey_date'], $trip['journey_time'], $trip['pickup_city'] ?? '', $trip['drop_city'] ?? '', (int) ( $trip['vehicle_type_id'] ?? 0 ), (int) $exclude_id ) );
}

// TRACE: booking id + type payment|refund + amount + method + reference + note + admin id → inserts one ridego_booking_payments row → id|false. Pure insert (no totals).
function ridego_booking_payment_row( $booking_id, $type, $amount, $method, $reference, $note, $by ) {
    global $wpdb;
    $b = ridego_get_booking( (int) $booking_id );
    $ok = $wpdb->insert( "{$wpdb->prefix}ridego_booking_payments", array( 'booking_id' => (int) $booking_id, 'client_id' => $b ? (int) ( $b->client_profile_id ?? 0 ) : 0,
        'entry_type' => $type, 'amount' => round( (float) $amount, 2 ), 'method' => sanitize_key( $method ), 'reference' => mb_substr( sanitize_text_field( (string) $reference ), 0, 100 ),
        'note' => mb_substr( sanitize_text_field( (string) $note ), 0, 255 ), 'recorded_by' => (int) $by, 'created_at' => current_time( 'mysql' ) ) );
    return $ok ? (int) $wpdb->insert_id : false;
}

// TRACE: booking id → recomputes advance_paid (RideGo's booking-amount payments − refunds), balance_due and payment_status from the ledger → array(paid,balance,status).
//        Only 'payment' and 'refund' rows count; 'vendor_collection' rows (ride balance collected by the vendor/driver) never enter RideGo's received total.
//        Facilitator bookings (platform_model=1): due = booking amount; balance_due = fare − booking amount − vendor_collected (ride balance still to be collected by the vendor/driver);
//        payment_status: net ≥ due → 'verified'; 0 < net < due → 'partial'; net 0 keeps the status unless it was partial/verified (→ 'pending'); due 0 (waived) keeps 'cash_on_pickup'.
//        Legacy bookings: due = whole fare, balance = fare − net paid (unchanged behaviour). Cancelled/token_refund_due bookings keep advance_paid as history and balance 0.
//        Legacy rows without payment entries fall back to the stored advance_paid so nothing regresses.
function ridego_booking_recalculate_payment( $booking_id ) {
    global $wpdb;
    $b = ridego_get_booking( (int) $booking_id ); if ( ! $b ) { return null; }
    $p = "{$wpdb->prefix}ridego_booking_payments";
    $rows = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p} WHERE booking_id=%d AND entry_type IN ('payment','refund')", (int) $booking_id ) );
    $net = $rows ? (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(CASE WHEN entry_type='refund' THEN -amount ELSE amount END),0) FROM {$p} WHERE booking_id=%d AND entry_type IN ('payment','refund')", (int) $booking_id ) ) : (float) $b->advance_paid;
    $net = max( 0, round( $net, 2 ) ); $total = (float) $b->total_fare;
    $due = ridego_booking_platform_amount( $b ); $model = ! empty( $b->platform_model );
    $closed = in_array( $b->status, array( 'cancelled', 'token_refund_due' ), true );
    $upd = array( 'updated_at' => current_time( 'mysql' ) );
    if ( ! $closed ) {
        $upd['advance_paid'] = $net;
        $upd['balance_due'] = $model ? max( 0, round( $total - $due - (float) $b->vendor_collected, 2 ) ) : max( 0, round( $total - $net, 2 ) );
        if ( ! in_array( $b->payment_status, array( 'refund_pending', 'refunded' ), true ) ) {
            if ( $due > 0 && $net >= $due - 0.004 ) { $upd['payment_status'] = 'verified'; }
            elseif ( $net > 0 ) { $upd['payment_status'] = 'partial'; }
            elseif ( $due > 0 && in_array( $b->payment_status, array( 'partial', 'verified' ), true ) ) { $upd['payment_status'] = 'pending'; }
        }
    }
    $wpdb->update( "{$wpdb->prefix}ridego_bookings", $upd, array( 'id' => (int) $booking_id ) );
    return array( 'paid' => $upd['advance_paid'] ?? (float) $b->advance_paid, 'balance' => $upd['balance_due'] ?? (float) $b->balance_due, 'status' => $upd['payment_status'] ?? $b->payment_status,
        'pending_booking_amount' => max( 0, round( $due - $net, 2 ) ) );
}

// TRACE: booking id + amount + method + reference + note + admin id → records BOOKING AMOUNT received by RideGo against a booking → array(success,message,paid,balance).
//        RideGo collects only the booking amount, so this is capped at what is still pending of it (facilitator bookings) or of the whole fare (legacy bookings).
//        The ride balance is collected by the vendor/driver and is recorded with ridego_booking_record_vendor_collection() instead; trying to enter it here is refused with that hint.
//        Preconditions: amount > 0 and ≤ pending booking amount, booking not cancelled/expired, method valid, UTR/cheque number for traceable methods.
//        Postconditions: one payment row, advance_paid/balance_due/payment_status recomputed, a transaction logged, a receipt notification queued to the client;
//        a booking still awaiting payment becomes 'confirmed' and fires ridego_booking_confirmed (lead distribution + confirmation). Audit-logged.
//        Edge cases: unknown booking, bad amount, cancelled booking, more than the pending booking amount, DB failure (totals recomputed from rows).
function ridego_booking_record_payment( $booking_id, $amount, $method, $reference, $note, $admin_id ) {
    global $wpdb;
    $b = ridego_get_booking( (int) $booking_id );
    if ( ! $b ) { return array( 'success' => false, 'message' => 'Booking not found.' ); }
    if ( in_array( $b->status, array( 'cancelled', 'expired', 'token_refund_due' ), true ) ) { return array( 'success' => false, 'message' => 'Payments cannot be recorded on a cancelled booking.' ); }
    $amount = round( (float) $amount, 2 );
    if ( $amount <= 0 ) { return array( 'success' => false, 'message' => 'Enter an amount greater than zero.' ); }
    $method = sanitize_key( $method ); if ( ! in_array( $method, ridego_payment_methods(), true ) ) { return array( 'success' => false, 'message' => 'Choose how the payment was received.' ); }
    if ( in_array( $method, array( 'upi', 'bank_transfer', 'cheque' ), true ) && trim( (string) $reference ) === '' ) { return array( 'success' => false, 'message' => 'Enter the UTR / transaction or cheque number for this payment.' ); }
    $cur = ridego_booking_recalculate_payment( (int) $booking_id );
    $pending = (float) $cur['pending_booking_amount'];
    if ( $pending <= 0.004 ) { return array( 'success' => false, 'message' => 'The booking amount has already been received in full. The remaining ride balance is collected by the vendor/driver; record it as "collected by vendor/driver" if needed.' ); }
    if ( $amount > $pending + 0.004 ) { return array( 'success' => false, 'message' => '' . ridego_brand_name() . ' collects only the booking amount. The most that can be recorded here is ₹' . number_format( $pending, 2 ) . '.' ); }
    if ( ! ridego_booking_payment_row( $booking_id, 'payment', $amount, $method, $reference, $note, $admin_id ) ) {
        ridego_log( 'record_payment failed: ' . $wpdb->last_error );
        return array( 'success' => false, 'message' => 'Could not record the payment. Please try again.' );
    }
    $was_waiting = in_array( $b->status, array( 'pending_payment', 'payment_pending', 'payment_proof_submitted', 'payment_rejected', 'pending' ), true );
    if ( $was_waiting ) {
        $wpdb->update( "{$wpdb->prefix}ridego_bookings", array( 'status' => 'confirmed', 'payment_verified_by' => (int) $admin_id, 'payment_verified_at' => current_time( 'mysql' ), 'payment_method' => $method ), array( 'id' => (int) $booking_id ) );
    }
    $res = ridego_booking_recalculate_payment( (int) $booking_id );
    if ( function_exists( 'ridego_log_transaction' ) ) {
        ridego_log_transaction( array( 'type' => 'booking_payment', 'amount' => $amount, 'booking_id' => (int) $booking_id, 'gateway' => 'manual', 'status' => 'success', 'notes' => 'Recorded by admin #' . (int) $admin_id . ' (' . $method . ')' ) );
    }
    ridego_audit_log( 'payment_recorded', 'booking', (int) $booking_id, '', $amount . ' ' . $method . ' ' . $reference );
    ridego_admin_notify_client( $b, 'payment_receipt', array( 'amount' => $amount, 'balance' => $res['balance'], 'method' => $method ) );
    if ( $was_waiting ) { do_action( 'ridego_booking_confirmed', (int) $booking_id ); }
    return array( 'success' => true, 'message' => 'Booking amount of ₹' . number_format( $amount, 2 ) . ' recorded.', 'paid' => $res['paid'], 'balance' => $res['balance'], 'payment_status' => $res['status'] );
}

// TRACE: booking id + amount + method + reference + note + admin id → records money RETURNED to the client → array(success,message).
//        Two cases: (1) payment_status = refund_pending (created by a cancellation) → the refund must equal the pending amount; ridego_mark_refund_processed()
//        closes it (commission reversal + booking close) and the row is written by that function; (2) goodwill/partial refund on an active booking → cannot exceed net paid,
//        advance_paid and balance are recomputed. Edge cases: nothing paid, amount > net paid, unknown method, cancelled booking without a pending refund (refused: nothing owed).
function ridego_booking_record_refund( $booking_id, $amount, $method, $reference, $note, $admin_id ) {
    $b = ridego_get_booking( (int) $booking_id );
    if ( ! $b ) { return array( 'success' => false, 'message' => 'Booking not found.' ); }
    $method = sanitize_key( $method ); if ( ! in_array( $method, ridego_payment_methods(), true ) ) { return array( 'success' => false, 'message' => 'Choose how the refund was paid.' ); }
    if ( $b->payment_status === 'refunded' ) { return array( 'success' => false, 'message' => 'This booking has already been refunded.' ); }
    if ( $b->payment_status === 'refund_pending' ) {
        $owed = (float) $b->refund_amount;
        $amount = round( (float) $amount, 2 );
        if ( abs( $amount - $owed ) > 0.004 ) { return array( 'success' => false, 'message' => 'The pending refund is ₹' . number_format( $owed, 2 ) . '. Enter exactly that amount.' ); }
        if ( ! ridego_mark_refund_processed( (int) $booking_id, (string) $reference, $method, $note, (int) $admin_id ) ) { return array( 'success' => false, 'message' => 'Could not close the refund.' ); }
        ridego_audit_log( 'refund_processed', 'booking', (int) $booking_id, '', $amount . ' ' . $method . ' ' . $reference );
        ridego_admin_notify_client( $b, 'refund_processed', array( 'amount' => $amount ) );
        return array( 'success' => true, 'message' => 'Refund of ₹' . number_format( $amount, 2 ) . ' recorded and closed.' );
    }
    if ( in_array( $b->status, array( 'cancelled', 'expired', 'token_refund_due' ), true ) ) { return array( 'success' => false, 'message' => 'No refund is pending on this cancelled booking.' ); }
    $cur = ridego_booking_recalculate_payment( (int) $booking_id );
    $amount = round( (float) $amount, 2 );
    if ( $amount <= 0 ) { return array( 'success' => false, 'message' => 'Enter an amount greater than zero.' ); }
    if ( $amount > (float) $cur['paid'] + 0.004 ) { return array( 'success' => false, 'message' => 'The client has only paid ₹' . number_format( (float) $cur['paid'], 2 ) . ' on this booking.' ); }
    if ( trim( (string) $note ) === '' ) { return array( 'success' => false, 'message' => 'Give a reason for the refund.' ); }
    if ( ! ridego_booking_payment_row( $booking_id, 'refund', $amount, $method, $reference, $note, $admin_id ) ) { return array( 'success' => false, 'message' => 'Could not record the refund.' ); }
    $res = ridego_booking_recalculate_payment( (int) $booking_id );
    if ( function_exists( 'ridego_log_transaction' ) ) { ridego_log_transaction( array( 'type' => 'refund', 'amount' => $amount, 'booking_id' => (int) $booking_id, 'gateway' => 'manual', 'status' => 'success', 'notes' => sanitize_text_field( $note ) ) ); }
    ridego_audit_log( 'refund_recorded', 'booking', (int) $booking_id, '', $amount . ' ' . $method . ' ' . $note );
    ridego_admin_notify_client( $b, 'refund_processed', array( 'amount' => $amount ) );
    return array( 'success' => true, 'message' => 'Refund of ₹' . number_format( $amount, 2 ) . ' recorded.', 'paid' => $res['paid'], 'balance' => $res['balance'] );
}

// TRACE: booking row + event + extra payload → queues one notification to the booking's client contact (guest-safe: phone/email from the booking) → void.
//        Edge cases: booking has neither phone nor email (skipped).
function ridego_admin_notify_client( $b, $event, $extra = array() ) {
    if ( ! $b || ( $b->client_phone === '' && $b->client_email === '' && (int) $b->client_id <= 0 ) ) { return; }
    ridego_queue_notification( array( 'recipient_id' => (int) $b->client_id, 'recipient_type' => 'client', 'recipient_phone' => $b->client_phone, 'recipient_email' => $b->client_email,
        'event' => $event, 'payload' => array_merge( array( 'booking_id' => (int) $b->id, 'booking_number' => $b->booking_number ), $extra ), 'scheduled_for' => current_time( 'mysql' ) ) );
}

// TRACE: booking row + event + extra → queues a notification to the ASSIGNED vendor (phone/email from the vendor record) → void. Edge cases: no vendor (skipped).
function ridego_admin_notify_vendor( $b, $event, $extra = array() ) {
    if ( ! $b || empty( $b->vendor_id ) ) { return; }
    $v = ridego_get_vendor( (int) $b->vendor_id ); if ( ! $v ) { return; }
    ridego_queue_notification( array( 'recipient_id' => (int) ( $v->user_id ?? 0 ), 'recipient_type' => 'vendor', 'recipient_phone' => (string) ( $v->whatsapp_number ?: $v->phone ), 'recipient_email' => (string) ( $v->email ?? '' ),
        'event' => $event, 'payload' => array_merge( array( 'booking_id' => (int) $b->id, 'booking_number' => $b->booking_number ), $extra ), 'scheduled_for' => current_time( 'mysql' ) ) );
}

// TRACE: booking id + text + visibility internal|client + author → stores a timeline note → id|WP-style array error. Client-visible notes are returned to the client's trip page.
//        Edge cases: blank text (refused), unknown booking (refused), text capped at 1000.
function ridego_booking_add_note( $booking_id, $text, $visibility, $author ) {
    global $wpdb;
    $text = trim( sanitize_textarea_field( (string) $text ) );
    if ( $text === '' ) { return array( 'success' => false, 'message' => 'Write the note first.' ); }
    if ( ! ridego_get_booking( (int) $booking_id ) ) { return array( 'success' => false, 'message' => 'Booking not found.' ); }
    $vis = $visibility === 'client' ? 'client' : 'internal';
    if ( ! $wpdb->insert( "{$wpdb->prefix}ridego_booking_notes", array( 'booking_id' => (int) $booking_id, 'visibility' => $vis, 'note' => mb_substr( $text, 0, 1000 ), 'author_id' => (int) $author, 'created_at' => current_time( 'mysql' ) ) ) ) {
        return array( 'success' => false, 'message' => 'Could not save the note.' );
    }
    // ROOT-CAUSE FIX: $wpdb->insert_id must be read BEFORE ridego_audit_log() runs its own
    // INSERT — that call overwrites $wpdb->insert_id with the audit-log row's id, so the id this
    // function returned was never the note's own id (a caller keying off it, such as the edit/delete
    // endpoints added alongside this comment, would silently target the wrong row).
    $note_id = (int) $wpdb->insert_id;
    ridego_audit_log( 'booking_note_added', 'booking', (int) $booking_id, '', $vis );
    return array( 'success' => true, 'message' => $vis === 'client' ? 'Note saved and shown to the client.' : 'Internal note saved.', 'id' => $note_id );
}

// TRACE: booking id + $client_visible_only → notes newest first as arrays (author name resolved), soft-deleted notes excluded → array.
function ridego_booking_get_notes( $booking_id, $client_visible_only = false ) {
    global $wpdb;
    $sql = "SELECT * FROM {$wpdb->prefix}ridego_booking_notes WHERE booking_id=%d AND deleted_at IS NULL" . ( $client_visible_only ? " AND visibility='client'" : '' ) . ' ORDER BY id DESC LIMIT 100';
    return array_map( function ( $n ) {
        $u = $n->author_id ? get_user_by( 'id', $n->author_id ) : false;
        return array( 'id' => (int) $n->id, 'visibility' => $n->visibility, 'note' => $n->note, 'author' => $u ? $u->display_name : 'System', 'created_at' => $n->created_at, 'updated_at' => $n->updated_at, 'edited' => ! empty( $n->updated_at ) );
    }, (array) $wpdb->get_results( $wpdb->prepare( $sql, (int) $booking_id ) ) );
}

/* ROOT-CAUSE FIX (RideGo-Pre-Delivery-Audit.md, Revision 7, OPEN ISSUES:
   "Booking notes have no edit/delete"). ridego_booking_add_note() above
   was always add-only — once a note was saved there was no way to fix a
   typo or retract it short of a raw DB query. Edit updates the row in
   place and stamps updated_at (the note keeps its id/author/created_at,
   so the timeline still shows who originally wrote it and when); delete
   is a SOFT delete (deleted_at set, row kept) rather than a hard DELETE,
   because a note can carry visibility='client' — a note already shown
   to the client — and silently destroying that record would remove the
   only evidence of what the client was told, not just the note itself. */
// TRACE: note id + new text + actor → updates note+updated_at (soft-deleted or unknown note → not-found) → array(success, message). Audit-logged with the old text so an edit's history is recoverable from the audit log.
//        Preconditions: note exists, not already deleted, text non-empty. Postconditions: id/author_id/created_at/visibility unchanged; note+updated_at replaced. Edge cases: unknown/deleted id (404-shaped failure), empty text (validation failure), DB error (failure, nothing changed).
function ridego_booking_edit_note( $note_id, $text, $actor ) {
    global $wpdb;
    $text = trim( sanitize_textarea_field( (string) $text ) );
    if ( $text === '' ) { return array( 'success' => false, 'message' => 'Write the note first.' ); }
    $t = $wpdb->prefix . 'ridego_booking_notes';
    $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d AND deleted_at IS NULL", (int) $note_id ) );
    if ( ! $row ) { return array( 'success' => false, 'message' => 'Note not found.' ); }
    $text = mb_substr( $text, 0, 1000 );
    if ( $text === $row->note ) { return array( 'success' => true, 'message' => 'No change.' ); }
    $ok = $wpdb->update( $t, array( 'note' => $text, 'updated_at' => current_time( 'mysql' ) ), array( 'id' => (int) $note_id ) );
    if ( false === $ok ) { return array( 'success' => false, 'message' => 'Could not save the note.' ); }
    ridego_audit_log( 'booking_note_edited', 'booking', (int) $row->booking_id, $row->note, $text );
    return array( 'success' => true, 'message' => 'Note updated.' );
}

// TRACE: note id + actor → soft-deletes the note (deleted_at set; row kept for the audit trail) → array(success, message). Audit-logged with the note text so what was removed stays visible in the audit log.
//        Preconditions: note exists, not already deleted. Postconditions: excluded from ridego_booking_get_notes() from now on; the row itself, and the DB history it carries, is never destroyed. Edge cases: unknown/already-deleted id (not-found-shaped failure), DB error (failure, nothing changed).
function ridego_booking_delete_note( $note_id, $actor ) {
    global $wpdb;
    $t = $wpdb->prefix . 'ridego_booking_notes';
    $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d AND deleted_at IS NULL", (int) $note_id ) );
    if ( ! $row ) { return array( 'success' => false, 'message' => 'Note not found.' ); }
    $ok = $wpdb->update( $t, array( 'deleted_at' => current_time( 'mysql' ) ), array( 'id' => (int) $note_id ) );
    if ( false === $ok ) { return array( 'success' => false, 'message' => 'Could not delete the note.' ); }
    ridego_audit_log( 'booking_note_deleted', 'booking', (int) $row->booking_id, $row->note, '' );
    return array( 'success' => true, 'message' => 'Note deleted.' );
}

// TRACE: booking id → the booking's payment ledger rows newest first (with recorder name) → array.
function ridego_booking_get_payments( $booking_id ) {
    global $wpdb;
    return array_map( function ( $r ) {
        $u = $r->recorded_by ? get_user_by( 'id', $r->recorded_by ) : false;
        return array( 'id' => (int) $r->id, 'entry_type' => $r->entry_type, 'amount' => (float) $r->amount, 'method' => $r->method, 'reference' => $r->reference, 'note' => $r->note,
            'recorded_by' => $u ? $u->display_name : 'System', 'created_at' => $r->created_at );
    }, (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_booking_payments WHERE booking_id=%d ORDER BY id DESC", (int) $booking_id ) ) );
}

// TRACE: payload → creates a complete booking from the back office → array(success, booking_id, booking_number, status, total_fare, balance_due, client_id, warnings, message).
//        Steps: (1) resolve client: existing client_id, or new_client (duplicate mobile/email → error 'duplicate_client' with the existing profile so the UI can switch to it);
//        blocked clients refused; (2) validate + price the trip (fare overrides audited); (3) refuse an identical live booking for the client unless confirm_duplicate;
//        (4) payment mode: 'pay_later' (confirmed, collect on pickup), 'awaiting_payment' (pending_payment with the usual deadline), 'received' (amount + method + reference recorded now);
//        (5) insert with booking_source/created_by/notes; (6) optional vendor (+driver/vehicle) assigned directly, otherwise the normal lead cascade runs on confirmation;
//        (7) client + vendor notifications through the existing hooks. Postconditions: one booking, one client link, payment rows match advance_paid, everything audit-logged.
//        Edge cases: any failure after the insert of the client is harmless (client kept); booking insert failure returns a clean message; assignment failure keeps the booking confirmed
//        and reports a warning so the dispatcher can retry from the booking page.
function ridego_admin_create_booking( $in, $admin_id ) {
    global $wpdb;
    $in = (array) $in;
    $source = sanitize_key( (string) ( $in['booking_source'] ?? 'admin' ) );
    if ( ! in_array( $source, ridego_booking_sources(), true ) || $source === 'online' ) { $source = 'admin'; }

    // 1. client
    $client = null; $created_client = false;
    if ( ! empty( $in['client_id'] ) ) {
        $client = ridego_client_get( (int) $in['client_id'] );
        if ( ! $client ) { return array( 'success' => false, 'message' => 'The selected client no longer exists.' ); }
    } elseif ( ! empty( $in['new_client'] ) ) {
        $nc = (array) $in['new_client']; $nc['source'] = $source;
        $r = ridego_client_create( $nc, $admin_id, ! empty( $in['allow_email_duplicate'] ) );
        if ( empty( $r['success'] ) ) { return array( 'success' => false, 'code' => ! empty( $r['duplicate'] ) ? 'duplicate_client' : 'invalid_client', 'message' => $r['message'], 'duplicate' => $r['duplicate'] ?? null ); }
        $client = ridego_client_get( (int) $r['id'] ); $created_client = true;
    } else { return array( 'success' => false, 'message' => 'Select an existing client or enter a new one.' ); }
    if ( $client->status === 'blocked' ) { return array( 'success' => false, 'message' => $client->name . ' is blocked. Unblock the client before creating a booking.' ); }

    // 2. trip + fare
    $n = ridego_admin_normalise_trip( $in, false, ! empty( $in['allow_past'] ) );
    if ( $n['error'] ) { return array( 'success' => false, 'message' => $n['error'] ); }
    $trip = $n['trip'];
    $f = ridego_admin_compute_fare( $trip, (array) ( $in['fare'] ?? array() ) );
    if ( $f['error'] ) { return array( 'success' => false, 'message' => $f['error'] ); }
    $fare = $f['fare'];

    // 3. duplicate guard
    if ( empty( $in['confirm_duplicate'] ) ) {
        $dup = ridego_admin_find_duplicate_booking( (int) $client->id, $trip );
        if ( $dup ) { return array( 'success' => false, 'code' => 'duplicate_booking', 'message' => 'This client already has booking ' . $dup->booking_number . ' for the same trip. Confirm to create another.', 'duplicate' => array( 'id' => (int) $dup->id, 'booking_number' => $dup->booking_number ) ); }
    }

    // 4. booking amount handling. RideGo collects ONLY the booking amount; the ride balance is billed and collected by the vendor/driver.
    //    received = booking amount received in full now; awaiting_payment = client still has to pay it (booking waits); collect_later = confirm now, RideGo collects it later;
    //    waived = confirm with no booking amount at all (needs a reason). 'pay_later' is accepted as an alias of collect_later.
    $ba = round( (float) $fare['booking_amount'], 2);
    $pay = (array) ( $in['payment'] ?? array() ); $mode = sanitize_key( (string) ( $pay['mode'] ?? 'collect_later' ) );
    if ( $mode === 'pay_later' ) { $mode = 'collect_later'; }
    if ( ! in_array( $mode, array( 'received', 'awaiting_payment', 'collect_later', 'waived' ), true ) ) { return array( 'success' => false, 'message' => 'Choose how the booking amount is handled.' ); }
    if ( $ba <= 0.004 ) { $mode = 'waived'; }
    elseif ( $mode === 'waived' && trim( (string) ( $pay['reason'] ?? '' ) ) === '' ) { return array( 'success' => false, 'message' => 'Give a reason for confirming without a booking amount.' ); }
    $received = 0.0; $method = 'upi';
    if ( $mode === 'received' ) {
        $received = round( (float) ( $pay['amount'] ?? $ba ), 2 ); $method = sanitize_key( (string) ( $pay['method'] ?? 'upi' ) );
        if ( abs( $received - $ba ) > 0.004 ) { return array( 'success' => false, 'message' => 'The booking amount is ₹' . number_format( $ba, 2 ) . '. Enter exactly that, or choose to collect it later.' ); }
        if ( ! in_array( $method, ridego_payment_methods(), true ) ) { return array( 'success' => false, 'message' => 'Choose how the booking amount was received.' ); }
        if ( in_array( $method, array( 'upi', 'bank_transfer', 'cheque' ), true ) && trim( (string) ( $pay['reference'] ?? '' ) ) === '' ) { return array( 'success' => false, 'message' => 'Enter the UTR / transaction or cheque number.' ); }
    } elseif ( $mode === 'awaiting_payment' ) { $method = sanitize_key( (string) ( $pay['method'] ?? 'upi' ) ); if ( ! in_array( $method, ridego_payment_methods(), true ) ) { $method = 'upi'; } }
    $token_amount = $mode === 'waived' ? 0.0 : $ba;

    // vendor selection (validated before any write so a bad vendor never leaves a half-created booking)
    $vendor_id = (int) ( $in['vendor_id'] ?? 0 );
    if ( $vendor_id ) {
        $vendor = ridego_get_vendor( $vendor_id );
        if ( ! $vendor || $vendor->status !== 'active' ) { return array( 'success' => false, 'message' => 'The selected vendor is not active.' ); }
        if ( $mode === 'awaiting_payment' ) { return array( 'success' => false, 'message' => 'Assign a vendor after the booking amount is received, or choose "received" / "collect later".' ); }
        // driver / vehicle: must belong to this vendor, be active, the driver's profile must be complete, and both must be free for the trip window (checked before any write)
        $dur = ridego_booking_duration_minutes( (object) $trip );
        if ( ! empty( $in['driver_id'] ) ) {
            $drv = ridego_get_fleet_driver( (int) $in['driver_id'] );
            if ( ! $drv || (int) $drv->vendor_id !== $vendor_id || $drv->status !== 'active' ) { return array( 'success' => false, 'message' => 'The selected driver does not belong to this vendor or is not active.' ); }
            $miss = ridego_driver_missing_fields( $drv );
            if ( $miss ) { return array( 'success' => false, 'message' => 'The driver profile is incomplete (' . implode( ', ', $miss ) . '). Complete it before assigning this driver.' ); }
            $av = ridego_check_fleet_availability( 'driver', (int) $drv->id, $trip['journey_date'], $trip['journey_time'], $dur, 0 );
            if ( ! $av['available'] ) { return array( 'success' => false, 'message' => 'The selected driver is not available: ' . $av['reason'] ); }
        }
        if ( ! empty( $in['vehicle_id'] ) ) {
            $veh = ridego_get_fleet_vehicle( (int) $in['vehicle_id'] );
            if ( ! $veh || (int) $veh->vendor_id !== $vendor_id || $veh->status !== 'active' ) { return array( 'success' => false, 'message' => 'The selected vehicle does not belong to this vendor or is not active.' ); }
            $av = ridego_check_fleet_availability( 'vehicle', (int) $veh->id, $trip['journey_date'], $trip['journey_time'], $dur, 0 );
            if ( ! $av['available'] ) { return array( 'success' => false, 'message' => 'The selected vehicle is not available: ' . $av['reason'] ); }
        }
    } elseif ( ! empty( $in['driver_id'] ) || ! empty( $in['vehicle_id'] ) ) {
        return array( 'success' => false, 'message' => 'Choose a vendor before choosing a driver or vehicle.' );
    }

    // 5. insert
    $now = current_time( 'mysql' );
    $client_email = $client->email;
    $row = array_merge( array( 'pickup_address' => '', 'drop_address' => '', 'drop_city' => '', 'via_cities' => '', 'special_requests' => '', 'flight_number' => '', 'passenger_details' => '', 'luggage_count' => 0, 'hours_required' => 0,
        'corporate_company' => $client->client_type === 'corporate' ? $client->company_name : '', 'corporate_gst' => $client->client_type === 'corporate' ? $client->gst_number : '' ), $trip );
    $row += array( 'return_date' => null, 'return_time' => null );
    $adv = 0.0;
    $row = array_merge( $row, array(
        'booking_number' => ridego_generate_booking_number(),
        'client_id' => (int) $client->wp_user_id, 'client_profile_id' => (int) $client->id, 'client_name' => $client->name, 'client_phone' => $client->phone, 'client_email' => $client_email, 'client_alt_phone' => $client->alt_phone,
        'distance_km' => $fare['distance_km'], 'duration_minutes' => $fare['duration_minutes'],
        'base_fare' => $fare['base_fare'], 'toll_charges' => $fare['toll_charges'], 'parking_charges' => $fare['parking_charges'], 'driver_allowance' => $fare['driver_allowance'], 'extra_km_charges' => $fare['extras'],
        'gst_amount' => $fare['gst_amount'], 'discount_amount' => $fare['discount_amount'], 'admin_adjustment' => $fare['adjustment'], 'adjustment_reason' => $fare['adjustment_reason'], 'total_fare' => $fare['total_fare'],
        'token_amount' => $token_amount, 'platform_model' => 1, 'advance_paid' => $adv, 'balance_due' => max( 0, round( (float) $fare['total_fare'] - $token_amount, 2 ) ),
        'payment_method' => $method, 'payment_status' => in_array( $mode, array( 'awaiting_payment', 'collect_later' ), true ) ? 'pending' : 'cash_on_pickup',
        'payment_deadline' => $mode === 'awaiting_payment' ? date( 'Y-m-d H:i:s', strtotime( '+' . (int) ridego_get_setting( 'payment_deadline_hours', 5 ) . ' hours', strtotime( current_time( 'mysql' ) ) ) ) : null,
        'status' => $mode === 'awaiting_payment' ? 'pending_payment' : 'confirmed', 'booking_source' => $source, 'created_by' => (int) $admin_id,
        'otp_pickup' => str_pad( (string) random_int( 0, 999999 ), 6, '0', STR_PAD_LEFT ), 'notes_admin' => '', 'utm_source' => 'admin', 'created_at' => $now, 'updated_at' => $now,
    ) );
    $booking_id = 0;
    for ( $i = 0; $i < 3 && ! $booking_id; $i++ ) {
        if ( $wpdb->insert( "{$wpdb->prefix}ridego_bookings", $row ) ) { $booking_id = (int) $wpdb->insert_id; break; }
        if ( stripos( (string) $wpdb->last_error, 'booking_number' ) !== false ) { $row['booking_number'] = ridego_generate_booking_number(); continue; }
        break;
    }
    if ( ! $booking_id ) { ridego_log( 'admin_create_booking insert failed: ' . $wpdb->last_error ); return array( 'success' => false, 'message' => 'Could not create the booking. Please try again.' ); }
    $warnings = array();
    if ( $created_client ) { ridego_audit_log( 'client_created_via_booking', 'booking', $booking_id, '', (string) $client->id ); }

    // notes
    foreach ( array( 'internal_note' => 'internal', 'client_note' => 'client' ) as $k => $vis ) {
        if ( ! empty( $in[ $k ] ) ) { ridego_booking_add_note( $booking_id, $in[ $k ], $vis, $admin_id ); }
    }
    if ( $mode === 'waived' ) { ridego_audit_log( 'booking_amount_waived', 'booking', $booking_id, (string) $fare['booking_amount_default'], '0', 'warning' ); }
    if ( abs( (float) $fare['booking_amount'] - (float) $fare['booking_amount_default'] ) > 0.004 ) { ridego_audit_log( 'booking_amount_changed', 'booking', $booking_id, (string) $fare['booking_amount_default'], (string) $fare['booking_amount'] . ' ' . $fare['booking_amount_reason'], 'warning' ); }
    if ( $fare['overridden'] ) { ridego_audit_log( 'admin_fare_override', 'booking', $booking_id, (string) $fare['auto_total'], (string) $fare['total_fare'], 'warning' ); }
    if ( $mode === 'received' ) {
        $pr = ridego_booking_record_payment_on_create( $booking_id, $received, $method, (string) ( $pay['reference'] ?? '' ), (string) ( $pay['note'] ?? '' ), $admin_id );
        if ( ! $pr ) { $warnings[] = 'The payment could not be recorded. Record it from the booking page.'; }
    }
    ridego_audit_log( 'admin_booking_created', 'booking', $booking_id, '', $row['booking_number'] . ' source=' . $source );
    if ( ! empty( $in['enquiry_id'] ) ) { ridego_enquiry_mark_converted( (int) $in['enquiry_id'], $booking_id ); }

    // 6. deadline for awaiting payment / confirmation + vendor
    if ( $mode === 'awaiting_payment' && ! empty( $row['payment_deadline'] ) ) { wp_schedule_single_event( strtotime( $row['payment_deadline'] ), 'ridego_check_payment_deadline', array( $booking_id ) ); }
    do_action( 'ridego_booking_created', $booking_id, $row['status'] );
    if ( $row['status'] === 'confirmed' ) {
        if ( $vendor_id ) {
            // assign first so ridego_distribute_leads (which skips assigned bookings) does not fan the lead out to other vendors
            $as = ridego_admin_assign_vendor( $booking_id, $vendor_id, $admin_id, 'Assigned at booking creation' );
            if ( empty( $as['success'] ) ) { $warnings[] = 'The booking was created but the vendor could not be assigned: ' . ( $as['message'] ?? 'unknown error' ); }
            elseif ( ! empty( $in['driver_id'] ) || ! empty( $in['vehicle_id'] ) ) {
                $ra = ridego_replace_assignment( $booking_id, array( 'driver_id' => (int) ( $in['driver_id'] ?? 0 ) ?: null, 'vehicle_id' => (int) ( $in['vehicle_id'] ?? 0 ) ?: null ), $admin_id, 'admin', 'Assigned at booking creation' );
                if ( empty( $ra['success'] ) ) { $warnings[] = 'Vendor assigned, but the driver/vehicle was not set: ' . ( $ra['message'] ?? '' ); }
            }
        }
        do_action( 'ridego_booking_confirmed', $booking_id );
    }
    $fresh = ridego_get_booking( $booking_id );
    // customer / vendor notifications (guest clients are not reached by the registered-user confirmation hook, so they are queued explicitly)
    $when = ridego_format_date( $fresh->journey_date ) . ' ' . substr( (string) $fresh->journey_time, 0, 5 );
    $route = $fresh->pickup_city . ( $fresh->drop_city !== '' ? ' to ' . $fresh->drop_city : '' );
    $fin = ridego_booking_financials( $fresh );
    $money = function ( $n ) { return '₹' . number_format( (float) $n, 2 ); };
    $split = ' Estimated ride fare ' . $money( $fin['estimated_ride_fare'] ) . '; ' . ( $fin['payable_to_vendor'] > 0 ? 'the remaining ' . $money( $fin['payable_to_vendor'] ) . ' is payable directly to your vendor/driver, who will bill you.' : 'nothing more is payable to the vendor/driver.' );
    if ( $fresh->status === 'pending_payment' ) {
        ridego_admin_notify_client( $fresh, 'booking_updated', array( 'message' => 'Your booking ' . $fresh->booking_number . ' (' . $route . ', ' . $when . ') has been created. Please pay the booking amount of ' . $money( $fin['booking_amount'] ) . ' to ' . ridego_brand_name() . ' to confirm it.' . $split ) );
    } elseif ( (int) $fresh->client_id <= 0 ) {
        $ba_txt = $fin['booking_amount'] <= 0 ? 'No booking amount is due.' : ( $fin['booking_amount_pending'] > 0.004 ? 'The booking amount of ' . $money( $fin['booking_amount'] ) . ' is to be paid to ' . ridego_brand_name() . '.' : 'Booking amount received by ' . ridego_brand_name() . ': ' . $money( $fin['booking_amount_paid'] ) . '.' );
        ridego_admin_notify_client( $fresh, 'booking_updated', array( 'message' => 'Your booking ' . $fresh->booking_number . ' (' . $route . ', ' . $when . ') is confirmed. ' . $ba_txt . $split ) );
    }
    if ( $vendor_id && ! empty( $fresh->vendor_id ) ) {
        ridego_admin_notify_vendor( $fresh, 'booking_updated', array( 'message' => 'New booking ' . $fresh->booking_number . ' assigned to you: ' . $route . ', ' . $when . '. Estimated ride fare ' . $money( $fin['estimated_ride_fare'] ) . '. ' . ridego_brand_name() . ' collects only the booking amount (' . $money( $fin['booking_amount'] ) . '); you bill the client and collect the remaining ' . $money( $fin['payable_to_vendor'] ) . ' directly, and issue the ride invoice.' ) );
    }
    return array( 'success' => true, 'message' => 'Booking ' . $row['booking_number'] . ' created.', 'booking_id' => $booking_id, 'booking_number' => $row['booking_number'], 'status' => $fresh->status,
        'total_fare' => (float) $fresh->total_fare, 'advance_paid' => (float) $fresh->advance_paid, 'balance_due' => (float) $fresh->balance_due, 'booking_amount' => $fin['booking_amount'], 'payable_to_vendor' => $fin['payable_to_vendor'], 'client_id' => (int) $client->id, 'client_created' => $created_client, 'warnings' => $warnings );
}

// TRACE: fresh booking id + amount + method + ref + note + admin → writes the first payment row and recomputes totals WITHOUT the "was waiting" confirmation logic
//        (the booking is already confirmed) and without the overpayment re-check (validated by the caller) → bool. Queues the receipt notification.
function ridego_booking_record_payment_on_create( $booking_id, $amount, $method, $reference, $note, $admin_id ) {
    if ( ! ridego_booking_payment_row( $booking_id, 'payment', $amount, $method, $reference, $note, $admin_id ) ) { return false; }
    $res = ridego_booking_recalculate_payment( $booking_id );
    if ( function_exists( 'ridego_log_transaction' ) ) { ridego_log_transaction( array( 'type' => 'booking_payment', 'amount' => $amount, 'booking_id' => (int) $booking_id, 'gateway' => 'manual', 'status' => 'success', 'notes' => 'Recorded at booking creation by admin #' . (int) $admin_id ) ); }
    ridego_audit_log( 'payment_recorded', 'booking', (int) $booking_id, '', $amount . ' ' . $method . ' ' . $reference );
    ridego_admin_notify_client( ridego_get_booking( $booking_id ), 'payment_receipt', array( 'amount' => (float) $amount, 'balance' => $res['balance'], 'method' => $method ) );
    return true;
}

// TRACE: booking id + partial payload + admin id → edits a live booking → array(success,message,changes[],rescheduled).
//        Permission rules: only ridego_booking_editable_statuses(); once the trip has started (driver_en_route/trip_started) route, date, time, vehicle type and price are locked
//        (notes, passengers and contact details still editable). Editable: contact snapshot (client_id switch re-links the profile), trip fields, passengers, notes, source, and the fare
//        (a `fare` object recalculates the whole breakdown; balance follows the payments already recorded and a total below the amount already paid is refused).
//        Rescheduling (date/time change) increments reschedule_count, remembers the previous slot, re-checks the assigned driver/vehicle availability (refused on a clash) and notifies
//        the client AND the assigned vendor. Edge cases: unknown/closed booking, nothing changed, validation error, DB failure.
function ridego_admin_update_booking( $booking_id, $in, $admin_id ) {
    global $wpdb;
    $b = ridego_get_booking( (int) $booking_id );
    if ( ! $b ) { return array( 'success' => false, 'message' => 'Booking not found.' ); }
    if ( ! in_array( $b->status, ridego_booking_editable_statuses(), true ) ) { return array( 'success' => false, 'message' => 'A ' . str_replace( '_', ' ', $b->status ) . ' booking can no longer be edited.' ); }
    $in = (array) $in; $started = in_array( $b->status, array( 'driver_en_route', 'trip_started' ), true );
    $locked = array( 'trip_type', 'pickup_city', 'drop_city', 'journey_date', 'journey_time', 'return_date', 'return_time', 'vehicle_type_id', 'hours_required', 'stops', 'via_cities', 'fare' );
    if ( $started ) { foreach ( $locked as $k ) { if ( array_key_exists( $k, $in ) ) { return array( 'success' => false, 'message' => 'The trip has already started, so the route, time, vehicle type and price can no longer be changed.' ); } } }
    $upd = array();

    if ( array_key_exists( 'client_id', $in ) && (int) $in['client_id'] !== (int) $b->client_profile_id ) {
        $c = ridego_client_get( (int) $in['client_id'] );
        if ( ! $c ) { return array( 'success' => false, 'message' => 'The selected client does not exist.' ); }
        if ( $c->status === 'blocked' ) { return array( 'success' => false, 'message' => 'That client is blocked.' ); }
        $upd += array( 'client_profile_id' => (int) $c->id, 'client_id' => (int) $c->wp_user_id, 'client_name' => $c->name, 'client_phone' => $c->phone, 'client_email' => $c->email, 'client_alt_phone' => $c->alt_phone );
    }
    $cv = array();
    foreach ( array( 'client_name' => 'name', 'client_phone' => 'phone', 'client_email' => 'email', 'client_alt_phone' => 'alt_phone' ) as $bk => $ck ) { if ( array_key_exists( $bk, $in ) && ! isset( $upd[ $bk ] ) ) { $cv[ $ck ] = $in[ $bk ]; } }
    if ( $cv ) {
        $v = ridego_client_validate( array_merge( array( 'name' => $b->client_name, 'phone' => $b->client_phone ), $cv ), true );
        if ( $v['error'] ) { return array( 'success' => false, 'message' => $v['error'] ); }
        foreach ( array( 'client_name' => 'name', 'client_phone' => 'phone', 'client_email' => 'email', 'client_alt_phone' => 'alt_phone' ) as $bk => $ck ) { if ( isset( $cv[ $ck ] ) && isset( $v['data'][ $ck ] ) ) { $upd[ $bk ] = $v['data'][ $ck ]; } }
    }
    $trip_in = array_intersect_key( $in, array_flip( array_merge( $locked, array( 'pickup_address', 'drop_address', 'special_requests', 'flight_number', 'passengers', 'passenger_details', 'luggage_count', 'corporate_company', 'corporate_gst', 'corporate_emp_id', 'corporate_cost_centre', 'pickup_lat', 'pickup_lng', 'drop_lat', 'drop_lng' ) ) ) );
    unset( $trip_in['fare'] );
    $trip = array();
    if ( $trip_in ) {
        $n = ridego_admin_normalise_trip( $trip_in, true, true );
        if ( $n['error'] ) { return array( 'success' => false, 'message' => $n['error'] ); }
        $trip = $n['trip'];
        $ndate = $trip['journey_date'] ?? $b->journey_date; $ntime = $trip['journey_time'] ?? $b->journey_time;
        if ( ( isset( $trip['journey_date'] ) || isset( $trip['journey_time'] ) ) && $ndate . ' ' . $ntime < current_time( 'Y-m-d H:i:s' ) && empty( $in['allow_past'] ) ) { return array( 'success' => false, 'message' => 'The new pickup time is in the past.' ); }
        $ntype = $trip['trip_type'] ?? $b->trip_type;
        if ( $ntype !== 'local' && array_key_exists( 'drop_city', $trip_in ) && $trip['drop_city'] === '' ) { return array( 'success' => false, 'message' => 'Enter the drop city or location.' ); }
        if ( array_key_exists( 'pickup_city', $trip_in ) && $trip['pickup_city'] === '' ) { return array( 'success' => false, 'message' => 'Enter the pickup city or location.' ); }
        if ( ( $trip['trip_type'] ?? $b->trip_type ) === 'round_trip' && empty( array_key_exists( 'return_date', $trip ) ? $trip['return_date'] : $b->return_date ) ) { return array( 'success' => false, 'message' => 'A round trip needs a return date.' ); }
        $upd += $trip;
    }
    $rescheduled = ( isset( $upd['journey_date'] ) && $upd['journey_date'] !== $b->journey_date ) || ( isset( $upd['journey_time'] ) && $upd['journey_time'] !== $b->journey_time );
    if ( $rescheduled && ! empty( $b->vendor_id ) ) {
        $nd = $upd['journey_date'] ?? $b->journey_date; $nt = $upd['journey_time'] ?? $b->journey_time;
        $cur = $wpdb->get_row( $wpdb->prepare( "SELECT driver_id, vehicle_id FROM {$wpdb->prefix}ridego_booking_assignments WHERE booking_id=%d AND is_current=1", (int) $booking_id ) );
        $dur = ridego_booking_duration_minutes( $b );
        foreach ( array( 'driver' => $cur->driver_id ?? 0, 'vehicle' => $cur->vehicle_id ?? 0 ) as $kind => $eid ) {
            if ( $eid ) { $av = ridego_check_fleet_availability( $kind, (int) $eid, $nd, $nt, $dur, (int) $booking_id ); if ( ! $av['available'] ) { return array( 'success' => false, 'message' => 'The assigned ' . $kind . ' is not available at the new time: ' . $av['reason'] . ' Reassign first, then reschedule.' ); } }
        }
    }
    // fare: an explicit `fare` block replaces the whole breakdown (keys left out revert to the auto price); without one the fare is only re-priced when the
    // route, trip type, vehicle type or hours changed (or reprice=1), keeping the existing discount and adjustment. A date/time-only reschedule never touches a manual price.
    $route_changed = false;
    foreach ( array( 'trip_type', 'pickup_city', 'drop_city', 'vehicle_type_id', 'hours_required' ) as $rk ) { if ( array_key_exists( $rk, $trip ) && (string) $trip[ $rk ] !== (string) $b->$rk ) { $route_changed = true; } }
    if ( ! $started && ( array_key_exists( 'fare', $in ) || $route_changed || ! empty( $in['reprice'] ) ) ) {
        $merged = array_merge( (array) $b, $trip );
        if ( $route_changed ) { $merged['distance_km'] = 0; $merged['duration_minutes'] = 0; }
        $ov = (array) ( $in['fare'] ?? array() );
        $fin = $ov;
        $adj_changed = array_key_exists( 'adjustment', $fin ) && abs( (float) $fin['adjustment'] - (float) $b->admin_adjustment ) > 0.004;
        $disc_changed = ( array_key_exists( 'discount_amount', $fin ) && abs( (float) $fin['discount_amount'] - (float) $b->discount_amount ) > 0.004 ) || ( array_key_exists( 'discount_percent', $fin ) && (float) $fin['discount_percent'] > 0 );
        if ( ( $adj_changed || $disc_changed ) && trim( (string) ( $fin['adjustment_reason'] ?? $fin['discount_reason'] ?? '' ) ) === '' ) { return array( 'success' => false, 'message' => 'Give a reason for the discount or price adjustment.' ); }
        if ( ! array_key_exists( 'discount_amount', $ov ) && ! array_key_exists( 'discount_percent', $ov ) ) { $ov['discount_amount'] = (float) $b->discount_amount; }
        if ( ! array_key_exists( 'adjustment', $ov ) ) { $ov['adjustment'] = (float) $b->admin_adjustment; }
        if ( ! array_key_exists( 'adjustment_reason', $ov ) && ! array_key_exists( 'discount_reason', $ov ) ) { $ov['adjustment_reason'] = (string) $b->adjustment_reason ?: 'Carried over from the original booking'; }
        $f = ridego_admin_compute_fare( $merged, $ov );
        if ( $f['error'] ) { return array( 'success' => false, 'message' => $f['error'] ); }
        $fare = $f['fare'];
        $paid = (float) $b->advance_paid;
        if ( empty( $b->platform_model ) && $fare['total_fare'] < $paid - 0.004 ) { return array( 'success' => false, 'message' => 'The new total (₹' . number_format( $fare['total_fare'], 2 ) . ') is below the ₹' . number_format( $paid, 2 ) . ' already paid. Record a refund first.' ); }
        // facilitator bookings: the booking amount stays as it was (capped at the new fare) unless the admin sets a new one with a reason; the vendor's balance is what is left of the
        // fare and can never drop below what the vendor has already collected. Legacy bookings keep the old whole-fare arithmetic.
        $new_token = (float) $b->token_amount;
        if ( ! empty( $b->platform_model ) ) {
            $new_token = array_key_exists( 'booking_amount', (array) ( $in['fare'] ?? array() ) ) ? (float) $fare['booking_amount'] : min( (float) $b->token_amount, (float) $fare['total_fare'] );
            if ( $new_token < $paid - 0.004 ) { return array( 'success' => false, 'message' => 'The booking amount already received (₹' . number_format( $paid, 2 ) . ') is more than the new booking amount. Record a refund first.' ); }
            if ( (float) $fare['total_fare'] - $new_token < (float) $b->vendor_collected - 0.004 ) { return array( 'success' => false, 'message' => 'The vendor/driver has already collected ₹' . number_format( (float) $b->vendor_collected, 2 ) . ' of the ride balance, which is more than the new fare leaves payable to them.' ); }
        }
        $upd += array( 'base_fare' => $fare['base_fare'], 'toll_charges' => $fare['toll_charges'], 'parking_charges' => $fare['parking_charges'], 'driver_allowance' => $fare['driver_allowance'], 'extra_km_charges' => $fare['extras'],
            'gst_amount' => $fare['gst_amount'], 'discount_amount' => $fare['discount_amount'], 'admin_adjustment' => $fare['adjustment'], 'adjustment_reason' => $fare['adjustment_reason'], 'total_fare' => $fare['total_fare'],
            'balance_due' => ! empty( $b->platform_model ) ? max( 0, round( $fare['total_fare'] - $new_token - (float) $b->vendor_collected, 2 ) ) : max( 0, round( $fare['total_fare'] - $paid, 2 ) ),
            'distance_km' => $fare['distance_km'], 'duration_minutes' => $fare['duration_minutes'] );
        if ( ! empty( $b->platform_model ) ) { $upd['token_amount'] = round( $new_token, 2 ); }
    }
    if ( array_key_exists( 'booking_source', $in ) ) {
        $s = sanitize_key( (string) $in['booking_source'] );
        if ( ! in_array( $s, ridego_booking_sources(), true ) ) { return array( 'success' => false, 'message' => 'Unknown booking source.' ); }
        $upd['booking_source'] = $s;
    }
    // diff
    $changes = array();
    foreach ( $upd as $k => $v ) { if ( (string) $b->$k !== (string) $v ) { $changes[ $k ] = array( (string) $b->$k, (string) $v ); } }
    $upd = array_intersect_key( $upd, $changes );
    if ( ! $upd ) { return array( 'success' => true, 'message' => 'No changes to save.', 'changes' => array(), 'rescheduled' => false ); }
    if ( $rescheduled ) { $upd['reschedule_count'] = (int) $b->reschedule_count + 1; $upd['rescheduled_from'] = mb_substr( $b->journey_date . ' ' . substr( (string) $b->journey_time, 0, 5 ), 0, 30 ); }
    $upd['updated_at'] = current_time( 'mysql' );
    if ( false === $wpdb->update( "{$wpdb->prefix}ridego_bookings", $upd, array( 'id' => (int) $booking_id ) ) ) {
        ridego_log( 'admin_update_booking failed: ' . $wpdb->last_error );
        return array( 'success' => false, 'message' => 'Could not save the changes. Please try again.' );
    }
    if ( isset( $upd['total_fare'] ) || isset( $upd['token_amount'] ) ) { ridego_booking_recalculate_payment( (int) $booking_id ); }
    $summary = implode( ', ', array_map( function ( $k, $v ) { return $k . ': ' . mb_substr( $v[0], 0, 40 ) . ' → ' . mb_substr( $v[1], 0, 40 ); }, array_keys( $changes ), $changes ) );
    ridego_audit_log( $rescheduled ? 'booking_rescheduled' : 'booking_edited', 'booking', (int) $booking_id, '', mb_substr( $summary, 0, 500 ) );
    $after = ridego_get_booking( (int) $booking_id );
    $touches_trip = (bool) array_intersect( array_keys( $changes ), array( 'journey_date', 'journey_time', 'pickup_city', 'pickup_address', 'drop_city', 'drop_address', 'vehicle_type_id', 'return_date', 'return_time', 'total_fare' ) );
    if ( $touches_trip ) {
        $msg = $rescheduled ? 'Your trip ' . $b->booking_number . ' has been rescheduled to ' . $after->journey_date . ' ' . substr( (string) $after->journey_time, 0, 5 ) . '.' : 'Your trip ' . $b->booking_number . ' has been updated. Please check the new details.';
        ridego_admin_notify_client( $after, 'booking_updated', array( 'message' => $msg ) );
        ridego_admin_notify_vendor( $after, 'booking_updated', array( 'message' => ( $rescheduled ? 'Trip ' . $b->booking_number . ' was rescheduled to ' . $after->journey_date . ' ' . substr( (string) $after->journey_time, 0, 5 ) . '.' : 'Trip ' . $b->booking_number . ' details were updated by ' . ridego_brand_name() . '.' ) ) );
    }
    return array( 'success' => true, 'message' => $rescheduled ? 'Booking rescheduled and the client' . ( $after->vendor_id ? ' and vendor were' : ' was' ) . ' notified.' : 'Booking updated.', 'changes' => array_keys( $changes ), 'rescheduled' => $rescheduled );
}

// TRACE: booking id → BOOKING RECEIPT data for admin AND client views → array|null. RideGo is a facilitator: this document covers ONLY the booking amount RideGo collected
//        (less any refund of it). It is not the invoice for the ride; the vendor/driver bills the client for the ride. Assigns a stable receipt number (RCP-YYYY-#####) on first use;
//        numbers already issued as INV-… stay as they are.
//        lines/total/paid = booking amount received (refund shown as a negative line); estimate_lines = the estimated ride fare breakdown, informational only;
//        ride = who collects the balance (vendor name/phone, payable_to_vendor, vendor_collected, vendor_outstanding, collection_status, vendor's own invoice number).
//        Legacy bookings that were paid in full online show the whole amount collected. Edge cases: unknown booking → null; nothing collected yet → total 0 and status text says so;
//        company block falls back to the site name when the invoice settings are empty.
function ridego_booking_invoice_data( $booking_id ) {
    global $wpdb;
    $b = ridego_get_booking( (int) $booking_id ); if ( ! $b ) { return null; }
    $inv = (string) $b->invoice_number;
    if ( $inv === '' ) {
        $seq = (int) get_option( 'ridego_invoice_seq_' . date( 'Y' ), 0 );
        do { $seq++; $inv = sprintf( 'RCP-%s-%05d', date( 'Y' ), $seq ); } while ( (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_bookings WHERE invoice_number=%s", $inv ) ) > 0 );
        update_option( 'ridego_invoice_seq_' . date( 'Y' ), $seq, false );
        $wpdb->update( "{$wpdb->prefix}ridego_bookings", array( 'invoice_number' => $inv ), array( 'id' => (int) $booking_id ) );
    }
    $fin = ridego_booking_financials( $b );
    $pay = ridego_booking_get_payments( $booking_id );
    $received = 0.0; $refunded = 0.0;
    foreach ( $pay as $p ) { if ( $p['entry_type'] === 'payment' ) { $received += (float) $p['amount']; } elseif ( $p['entry_type'] === 'refund' ) { $refunded += (float) $p['amount']; } }
    if ( ! array_filter( $pay, function ( $p ) { return in_array( $p['entry_type'], array( 'payment', 'refund' ), true ); } ) ) { $received = (float) $b->advance_paid; }
    $lines = array();
    if ( $received > 0.004 ) { $lines[] = array( 'label' => 'Booking amount received by ' . ridego_brand_name() . '', 'amount' => round( $received, 2 ) ); }
    if ( $refunded > 0.004 ) { $lines[] = array( 'label' => 'Refund of booking amount', 'amount' => -1 * round( $refunded, 2 ) ); }
    if ( ! $lines ) { $lines[] = array( 'label' => 'Booking amount received by ' . ridego_brand_name() . '', 'amount' => 0.0 ); }
    $net = max( 0, round( $received - $refunded, 2 ) );
    $est = array( array( 'label' => 'Base fare', 'amount' => (float) $b->base_fare ), array( 'label' => 'Toll', 'amount' => (float) $b->toll_charges ), array( 'label' => 'Parking', 'amount' => (float) $b->parking_charges ),
        array( 'label' => 'Driver allowance', 'amount' => (float) $b->driver_allowance ), array( 'label' => 'Extras and surcharges', 'amount' => (float) $b->extra_km_charges ) );
    if ( (float) $b->discount_amount > 0 ) { $est[] = array( 'label' => 'Discount', 'amount' => -1 * (float) $b->discount_amount ); }
    $est[] = array( 'label' => 'Taxes as applicable (charged by the vendor/driver)', 'amount' => (float) $b->gst_amount );
    if ( abs( (float) $b->admin_adjustment ) > 0.004 ) { $est[] = array( 'label' => 'Adjustment' . ( $b->adjustment_reason ? ' (' . $b->adjustment_reason . ')' : '' ), 'amount' => (float) $b->admin_adjustment ); }
    $est = array_values( array_filter( $est, function ( $l ) { return abs( $l['amount'] ) > 0.004 || $l['label'] === 'Base fare'; } ) );
    $vendor = ! empty( $b->vendor_id ) ? ridego_get_vendor( (int) $b->vendor_id ) : null;
    $company = array( 'name' => ridego_brand( 'legal_name' ), 'address' => ridego_brand( 'address' ), 'gstin' => ridego_brand( 'gstin' ), 'footer' => (string) ridego_get_setting( 'invoice_footer_note', '' ),
        'phone' => ridego_brand( 'support_phone' ), 'email' => ridego_brand( 'support_email' ), 'website' => ridego_brand( 'website_url' ), 'hours' => ridego_brand( 'business_hours' ), 'logo_url' => ridego_brand( 'logo_url' ), 'legal_info' => ridego_brand( 'legal_info' ) );
    return array( 'document_type' => 'booking_receipt', 'invoice_number' => $inv, 'receipt_number' => $inv, 'booking_number' => $b->booking_number, 'issued_on' => $b->created_at,
        'client_name' => $b->client_name, 'client_phone' => $b->client_phone, 'client_email' => $b->client_email, 'client_company' => $b->corporate_company, 'client_gst' => $b->corporate_gst,
        'route' => trim( $b->pickup_city . ( $b->drop_city !== '' ? ' → ' . $b->drop_city : '' ) ), 'journey_date' => $b->journey_date, 'journey_time' => substr( (string) $b->journey_time, 0, 5 ),
        'trip_type' => $b->trip_type, 'lines' => $lines, 'total' => $net, 'paid_online' => $net, 'paid' => $net, 'balance_due' => 0.0,
        'estimate_lines' => $est, 'estimated_ride_fare' => $fin['estimated_ride_fare'], 'booking_amount' => $fin['booking_amount'], 'booking_amount_pending' => $fin['booking_amount_pending'],
        'ride' => array( 'vendor_name' => $vendor ? (string) $vendor->business_name : '', 'vendor_phone' => $vendor ? (string) ( $vendor->whatsapp_number ?: $vendor->phone ) : '', 'payable_to_vendor' => $fin['payable_to_vendor'],
            'vendor_collected' => $fin['vendor_collected'], 'vendor_outstanding' => $fin['vendor_outstanding'], 'collection_status' => $fin['collection_status'], 'vendor_invoice_number' => $fin['vendor_invoice_number'] ),
        'disclaimer' => ridego_platform_text( 'disclaimer_receipt' ),
        'status' => $b->status, 'payment_status' => $b->payment_status, 'payments' => array_values( array_filter( $pay, function ( $p ) { return in_array( $p['entry_type'], array( 'payment', 'refund' ), true ); } ) ), 'company' => $company );
}
