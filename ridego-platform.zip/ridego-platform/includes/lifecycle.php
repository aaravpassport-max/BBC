<?php
/**
 * RideGo Marketplace — booking lifecycle helpers shared by the client dashboard, Command Centre and
 * vendor views: status grouping, a client-safe timeline and the "needs attention" rules.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: any list/tab → maps a booking status string to one of upcoming|ongoing|completed|cancelled →
//        string. Pure. Unknown statuses map to 'upcoming' (never hidden from the client).
//        cancelled/token_refund_due→cancelled; completed→completed; driver_en_route/trip_started→ongoing.
function ridego_booking_status_group( $status ) {
    switch ( (string) $status ) {
        case 'cancelled':
        case 'token_refund_due':
        case 'no_show':
            return 'cancelled';
        case 'completed':
            return 'completed';
        case 'driver_en_route':
        case 'trip_started':
            return 'ongoing';
        default:
            return 'upcoming';
    }
}

// TRACE: tab name → returns the raw statuses belonging to that group as a pipe-joined string usable by
//        ridego_query_bookings( 'status' ) → string ('' for an unknown tab). Pure.
function ridego_booking_group_statuses( $group ) {
    $map = array(
        /* ROOT-CAUSE FIX (dashboard "Next trip" empty despite Upcoming
           counter > 0): this list and ridego_booking_status_group()
           just above are two independently maintained sources of truth
           for "which statuses count as upcoming" — the counts query
           uses the switch (which defaults every unlisted status to
           'upcoming'), while the "next trip" lookup and the My Trips
           "upcoming" tab both filter by this explicit array. It was
           missing 'payment_proof_submitted' and 'payment_rejected'
           (see includes/booking-admin.php's canonical active-status
           list, which already includes both), so a booking sitting in
           either status was counted as upcoming but never shown as the
           next trip or listed under the upcoming tab — exactly the gap
           a real payment-proof-submitted booking exposed on the client
           dashboard. */
        'upcoming'  => array( 'pending', 'pending_payment', 'payment_pending', 'payment_proof_submitted', 'payment_rejected', 'confirmed', 'no_vendor', 'vendor_assigned', 'disputed' ),
        'ongoing'   => array( 'driver_en_route', 'trip_started' ),
        'completed' => array( 'completed' ),
        'cancelled' => array( 'cancelled', 'token_refund_due', 'no_show' ),
    );
    return isset( $map[ $group ] ) ? implode( '|', $map[ $group ] ) : '';
}

// TRACE: booking object (+ optional pre-fetched assignment row, so callers that already queried
//        ridego_get_current_assignment() don't pay for it twice) → ordered client-safe timeline array
//        of { key,label,done(bool),at(datetime|null) }. booked always done; payment done when
//        payment_verified_at set or status past pending; vendor_assigned done when a vendor is set
//        (label corrected — see ROOT-CAUSE FIX below); driver_assigned done once the vendor has put a
//        named driver/vehicle against the booking; en_route/started/completed follow status; cancelled
//        replaces the tail. Edge cases: null timestamps (done true, at null), cancelled before assignment.
function ridego_booking_timeline( $b, $assignment = null ) {
    $s = (string) $b->status;
    $past_payment = ! in_array( $s, array( 'pending', 'pending_payment', 'payment_pending' ), true );
    // ROOT-CAUSE FIX: this step's label used to say "Driver assigned" while its done-condition was
    // "a vendor has taken the lead" ($b->vendor_id set) — two genuinely different events. A vendor
    // taking a booking (status -> vendor_assigned) does not mean a specific driver/vehicle has been
    // put against it yet; that is a separate step recorded in ridego_booking_assignments (see
    // ridego_get_current_assignment()). The mislabeled step told clients "a driver is assigned" before
    // one necessarily was. Relabeled to match what it actually checks, and a real "driver_assigned"
    // step is added below, sourced from the assignment row that already exists for this purpose.
    $steps = array(
        array( 'key' => 'booked', 'label' => 'Booking placed', 'done' => true, 'at' => $b->created_at ),
        array( 'key' => 'payment', 'label' => 'Payment confirmed', 'done' => $past_payment && $s !== 'cancelled' || ! empty( $b->payment_verified_at ), 'at' => ! empty( $b->payment_verified_at ) ? $b->payment_verified_at : null ),
        array( 'key' => 'assigned', 'label' => 'Vendor assigned', 'done' => ! empty( $b->vendor_id ), 'at' => null ),
    );
    if ( $assignment === null && ! empty( $b->vendor_id ) && function_exists( 'ridego_get_current_assignment' ) ) {
        $assignment = ridego_get_current_assignment( $b->id );
    }
    $driver_named = $assignment && (string) $assignment->driver_name_snapshot !== '';
    $steps[] = array( 'key' => 'driver_assigned', 'label' => 'Driver assigned', 'done' => (bool) $driver_named, 'at' => $driver_named ? $assignment->created_at : null );
    if ( $s === 'cancelled' || $s === 'token_refund_due' ) {
        // ROOT-CAUSE FIX: this previously read $b->cancelled_at, a column that does not exist on
        // ridego_bookings (confirmed against includes/install.php's CREATE TABLE and every writer —
        // ridego_cancel_booking() in booking.php and the mark-not-arranged handler in
        // app-admin-bookings-api.php both write cancellation_time, never cancelled_at). The undefined
        // property silently evaluated to null, so the "Cancelled" timeline step never showed a
        // timestamp to the client even though the real one was sitting in the database the whole time.
        $steps[] = array( 'key' => 'cancelled', 'label' => $s === 'cancelled' ? 'Cancelled' : 'Not arranged — booking amount refund due', 'done' => true, 'at' => ! empty( $b->cancellation_time ) ? $b->cancellation_time : null );
        return $steps;
    }
    $steps[] = array( 'key' => 'en_route', 'label' => 'Driver on the way', 'done' => in_array( $s, array( 'driver_en_route', 'trip_started', 'completed' ), true ), 'at' => null );
    $steps[] = array( 'key' => 'started', 'label' => 'Trip started', 'done' => in_array( $s, array( 'trip_started', 'completed' ), true ), 'at' => ! empty( $b->trip_started_at ) ? $b->trip_started_at : null );
    $steps[] = array( 'key' => 'completed', 'label' => 'Trip completed', 'done' => $s === 'completed', 'at' => ! empty( $b->trip_ended_at ) ? $b->trip_ended_at : null );
    return $steps;
}

// TRACE: booking object → list of reasons the client should act (payment pending/rejected, refund due, rating due,
//        no vendor yet) → array of { code, message }. Pure. Empty array when nothing needs attention.
function ridego_client_needs_attention( $b ) {
    $out = array();
    $s = (string) $b->status;
    if ( in_array( $s, array( 'pending', 'pending_payment', 'payment_pending' ), true ) ) { $out[] = array( 'code' => 'payment_pending', 'message' => 'The booking amount is pending for this booking.' ); }
    if ( isset( $b->payment_status ) && $b->payment_status === 'rejected' ) { $out[] = array( 'code' => 'payment_rejected', 'message' => 'Your payment proof was rejected. Please resubmit it.' ); }
    if ( $s === 'token_refund_due' ) { $out[] = array( 'code' => 'refund_due', 'message' => 'We could not arrange this trip. Your booking amount will be refunded.' ); }
    if ( $s === 'completed' && empty( $b->rating_by_client ) ) { $out[] = array( 'code' => 'rating_due', 'message' => 'Rate your trip.' ); }
    return $out;
}
