<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Phase B, wave 5: pricing + surge pricing
   ------------------------------------------------------------
   Two distinct legacy admin pages, both gated on the same
   ridego_manage_pricing capability, rebuilt here as one file since
   they're a natural pair (base fare rates vs. time/zone surge
   multipliers) that a pricing admin will move between together:

   - admin/pages/pricing.php: per-vehicle-type base fare rates,
     stored on wp_ridego_vehicles. Read directly (pricing.php:14-41)
     before writing this file — every field name and default below
     is copied from its real save handler.
   - admin/pages/surge.php: time/date/city/zone/vehicle-scoped
     surge multiplier rules on wp_ridego_surge_pricing. Same
     discipline — the 0.5-5.0 multiplier clamp is a real server-
     side safety rail in the legacy page (its own comment notes the
     HTML min/max alone is client-side only and bypassable), so
     it's replicated exactly here too, not relaxed.

   IMPORTANT, flagged rather than silently left implicit: both of
   these tables feed LIVE customer-facing fare quotes through
   ridego_calculate_fare() (includes/pricing.php:36), via
   ridego_get_vehicle_type() and ridego_get_surge_multiplier(). A
   mistake here has immediate, real-money impact on every quote —
   which is exactly why the legacy page's own validation (the surge
   multiplier clamp, non-negative fare fields) is preserved exactly,
   not simplified or skipped.

   UPDATE (Cleanup pass 4): the gap noted above is closed. Both
   tables' add/edit/delete now go through canonical functions in
   includes/helpers.php — ridego_create_vehicle_type()/
   ridego_update_vehicle_type()/ridego_toggle_vehicle_active() and
   ridego_create_surge_rule()/ridego_update_surge_rule()/
   ridego_delete_surge_rule() — which both this file and the legacy
   admin pages now call, so the 0.5-5.0 surge clamp and pricing
   validation happen in one place for both callers.

   Every route requires is_user_logged_in() AND
   ridego_can('ridego_manage_pricing').
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_pricing_api_routes' );
function ridego_register_app_admin_pricing_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/pricing/vehicles', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_pricing_vehicles_list',
        'permission_callback' => 'ridego_app_admin_api_pricing_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/pricing/vehicles', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_pricing_vehicle_create',
        'permission_callback' => 'ridego_app_admin_api_pricing_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/pricing/vehicles/(?P<id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_pricing_vehicle_update',
        'permission_callback' => 'ridego_app_admin_api_pricing_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/pricing/vehicles/(?P<id>\d+)/toggle', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_pricing_vehicle_toggle',
        'permission_callback' => 'ridego_app_admin_api_pricing_permission',
    ) );
    // "Choose your ride" card image (home page + vehicle picker) — a real per-vehicle-type
    // photo/illustration, replacing the seeded placeholder icon_url. Same upload discipline
    // as ridego_branding_api_upload(): real file-type sniffing, size cap, SVG refused.
    register_rest_route( 'ridego/v1', '/app/admin/pricing/vehicles/(?P<id>\d+)/image', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_pricing_vehicle_image_upload',
        'permission_callback' => 'ridego_app_admin_api_pricing_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/surge', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_surge_list',
        'permission_callback' => 'ridego_app_admin_api_pricing_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/surge', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_surge_create',
        'permission_callback' => 'ridego_app_admin_api_pricing_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/surge/(?P<id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_surge_update',
        'permission_callback' => 'ridego_app_admin_api_pricing_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/surge/(?P<id>\d+)/delete', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_surge_delete',
        'permission_callback' => 'ridego_app_admin_api_pricing_permission',
    ) );
}

function ridego_app_admin_api_pricing_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_pricing' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage pricing.', array( 'status' => 403 ) );
    }
    return true;
}

/* ----------------------------------------------------------------
   Vehicle base pricing (wp_ridego_vehicles)
   ---------------------------------------------------------------- */

function ridego_app_admin_api_pricing_vehicles_list( WP_REST_Request $req ) {
    global $wpdb;
    $vtbl = $wpdb->prefix . 'ridego_vehicles';
    $rows = $wpdb->get_results( "SELECT * FROM {$vtbl} ORDER BY sort_order ASC, id ASC" );

    $out = array_map( function ( $v ) {
        return array(
            'id'                    => (int) $v->id,
            'name'                  => $v->name,
            'slug'                  => $v->slug,
            'seating_capacity'      => (int) $v->seating_capacity,
            'luggage_capacity'      => (int) $v->luggage_capacity,
            'ac_available'          => (bool) $v->ac_available,
            'icon_url'              => isset( $v->icon_url ) ? $v->icon_url : '',
            'base_price_per_km'     => (float) $v->base_price_per_km,
            'base_price_outstation' => (float) $v->base_price_outstation,
            'minimum_km'            => (float) $v->minimum_km,
            'night_charge_pct'      => (float) $v->night_charge_pct,
            'driver_allowance_day'  => (float) $v->driver_allowance_day,
            'extra_hour_charge'     => (float) $v->extra_hour_charge,
            'airport_base_charge'   => (float) $v->airport_base_charge,
            'local_4hr_40km'        => (float) $v->local_4hr_40km,
            'local_8hr_80km'        => (float) $v->local_8hr_80km,
            'local_extra_km'        => (float) $v->local_extra_km,
            'local_extra_hr'        => (float) $v->local_extra_hr,
            'lead_fee_mode'         => $v->lead_fee_mode,
            'lead_fee_fixed'        => (float) $v->lead_fee_fixed,
            'lead_fee_pct'          => (float) $v->lead_fee_pct,
            'is_active'             => (bool) $v->is_active,
            'sort_order'            => (int) $v->sort_order,
        );
    }, $rows );

    return rest_ensure_response( array( 'rows' => $out, 'total' => count( $out ) ) );
}

/** Builds the raw input array ridego_validate_vehicle_pricing_input() expects, from a REST request. */
function ridego_app_admin_api_pricing_vehicle_raw_input( WP_REST_Request $req ) {
    $rate_fields = array(
        'base_price_per_km', 'base_price_outstation', 'minimum_km', 'night_charge_pct',
        'driver_allowance_day', 'extra_hour_charge', 'airport_base_charge',
        'local_4hr_40km', 'local_8hr_80km', 'local_extra_km', 'local_extra_hr',
        'lead_fee_fixed', 'lead_fee_pct',
    );
    $raw = array();
    foreach ( $rate_fields as $f ) {
        $raw[ $f ] = $req->get_param( $f );
    }
    $raw['name']             = $req->get_param( 'name' );
    $raw['seating_capacity'] = $req->get_param( 'seating_capacity' );
    $raw['luggage_capacity'] = $req->get_param( 'luggage_capacity' );
    $raw['ac_available']     = $req->get_param( 'ac_available' );
    $raw['lead_fee_mode']    = $req->get_param( 'lead_fee_mode' );
    return $raw;
}

/** Delegates to the canonical ridego_create_vehicle_type() (includes/helpers.php). */
function ridego_app_admin_api_pricing_vehicle_create( WP_REST_Request $req ) {
    $is_active = $req->get_param( 'is_active' );
    $r = ridego_create_vehicle_type( ridego_app_admin_api_pricing_vehicle_raw_input( $req ), $is_active === null ? null : (bool) $is_active );
    if ( empty( $r['success'] ) ) {
        return new WP_Error( 'create_failed', $r['message'], array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'id' => $r['id'], 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_update_vehicle_type() (includes/helpers.php). */
function ridego_app_admin_api_pricing_vehicle_update( WP_REST_Request $req ) {
    $id        = (int) $req->get_param( 'id' );
    $is_active = $req->get_param( 'is_active' );
    $r = ridego_update_vehicle_type( $id, ridego_app_admin_api_pricing_vehicle_raw_input( $req ), $is_active === null ? null : (bool) $is_active );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'Vehicle type not found.' ? 404 : 400;
        return new WP_Error( 'update_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_toggle_vehicle_active() (includes/helpers.php). */
function ridego_app_admin_api_pricing_vehicle_toggle( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    $r  = ridego_toggle_vehicle_active( $id );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'Vehicle type not found.' ? 404 : 500;
        return new WP_Error( 'toggle_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array(
        'success'   => true,
        'is_active' => $r['is_active'],
        'message'   => $r['message'],
    ) );
}

// TRACE: POST /app/admin/pricing/vehicles/:id/image (multipart: file) → stores the image in the
//        WordPress uploads folder and saves its URL onto that vehicle type's icon_url column →
//        response(url)|400|404. Same discipline as ridego_branding_api_upload(): real file-type
//        sniffing (not the browser-supplied mime), 2 MB cap (a vehicle photo, not an icon — bigger
//        than a favicon but smaller than a full hero banner), SVG refused. Edge cases: unknown
//        vehicle id, no file, wrong type, too big, move failure.
function ridego_app_admin_api_pricing_vehicle_image_upload( WP_REST_Request $req ) {
    global $wpdb;
    $id = (int) $req->get_param( 'id' );
    $vtbl = $wpdb->prefix . 'ridego_vehicles';
    $vehicle = $wpdb->get_row( $wpdb->prepare( "SELECT id, name FROM {$vtbl} WHERE id=%d", $id ) );
    if ( ! $vehicle ) { return new WP_Error( 'not_found', 'Vehicle type not found.', array( 'status' => 404 ) ); }

    $files = $req->get_file_params();
    if ( empty( $files['file'] ) || ! empty( $files['file']['error'] ) || empty( $files['file']['tmp_name'] ) ) {
        return new WP_REST_Response( array( 'code' => 'no_file', 'message' => 'Choose an image to upload.' ), 400 );
    }
    $f = $files['file'];
    if ( (int) $f['size'] > 2 * 1024 * 1024 ) {
        return new WP_REST_Response( array( 'code' => 'too_big', 'message' => 'The image must be 2 MB or smaller.' ), 400 );
    }
    $check = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], array( 'png' => 'image/png', 'jpg|jpeg' => 'image/jpeg', 'webp' => 'image/webp' ) );
    if ( empty( $check['ext'] ) || empty( $check['type'] ) ) {
        return new WP_REST_Response( array( 'code' => 'bad_type', 'message' => 'Upload a png, jpg or webp image.' ), 400 );
    }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    $up = wp_handle_upload( $f, array( 'test_form' => false, 'mimes' => array( 'png' => 'image/png', 'jpg|jpeg' => 'image/jpeg', 'webp' => 'image/webp' ) ) );
    if ( ! empty( $up['error'] ) || empty( $up['url'] ) ) {
        return new WP_REST_Response( array( 'code' => 'upload_failed', 'message' => 'The image could not be saved. Please try again.' ), 400 );
    }
    $url = esc_url_raw( $up['url'] );
    $wpdb->update( $vtbl, array( 'icon_url' => $url ), array( 'id' => $id ) );
    ridego_audit_log( 'vehicle_image_updated', 'vehicle', $id, '', $vehicle->name . ' image' );
    return rest_ensure_response( array( 'success' => true, 'url' => $url, 'message' => 'Image uploaded.' ) );
}

/* ----------------------------------------------------------------
   Surge pricing (wp_ridego_surge_pricing)
   ---------------------------------------------------------------- */

function ridego_app_admin_api_surge_list( WP_REST_Request $req ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_surge_pricing';
    $vtbl = $wpdb->prefix . 'ridego_vehicles';
    $ztbl = $wpdb->prefix . 'ridego_zones';

    $rows = $wpdb->get_results(
        "SELECT s.*, v.name AS vehicle_name, z.name AS zone_name
         FROM {$tbl} s
         LEFT JOIN {$vtbl} v ON v.id = s.vehicle_id
         LEFT JOIN {$ztbl} z ON z.id = s.zone_id
         ORDER BY s.from_date DESC"
    );

    $out = array_map( function ( $s ) {
        return array(
            'id'          => (int) $s->id,
            'vehicle_id'  => (int) $s->vehicle_id,
            'vehicle_name' => isset( $s->vehicle_name ) ? $s->vehicle_name : '',
            'city'        => $s->city,
            'zone'        => $s->zone,
            'zone_id'     => $s->zone_id !== null ? (int) $s->zone_id : null,
            'zone_name'   => isset( $s->zone_name ) ? $s->zone_name : '',
            'from_date'   => $s->from_date,
            'to_date'     => $s->to_date,
            'time_from'   => $s->time_from,
            'time_to'     => $s->time_to,
            'multiplier'  => (float) $s->multiplier,
            'reason'      => $s->reason,
            'is_active'   => (bool) $s->is_active,
        );
    }, $rows );

    return rest_ensure_response( array( 'rows' => $out, 'total' => count( $out ) ) );
}

/** Builds the raw input array ridego_validate_surge_input() expects, from a REST request. */
function ridego_app_admin_api_surge_raw_input( WP_REST_Request $req ) {
    return array(
        'vehicle_id' => $req->get_param( 'vehicle_id' ),
        'city'       => $req->get_param( 'city' ),
        'zone'       => $req->get_param( 'zone' ),
        'zone_id'    => $req->get_param( 'zone_id' ),
        'from_date'  => $req->get_param( 'from_date' ),
        'to_date'    => $req->get_param( 'to_date' ),
        'time_from'  => $req->get_param( 'time_from' ),
        'time_to'    => $req->get_param( 'time_to' ),
        'multiplier' => $req->get_param( 'multiplier' ),
        'reason'     => $req->get_param( 'reason' ),
    );
}

/** Delegates to the canonical ridego_create_surge_rule() (includes/helpers.php). */
function ridego_app_admin_api_surge_create( WP_REST_Request $req ) {
    $is_active = $req->get_param( 'is_active' );
    $r = ridego_create_surge_rule( ridego_app_admin_api_surge_raw_input( $req ), $is_active === null ? null : (bool) $is_active );
    if ( empty( $r['success'] ) ) {
        return new WP_Error( 'create_failed', $r['message'], array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'id' => $r['id'], 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_update_surge_rule() (includes/helpers.php). */
function ridego_app_admin_api_surge_update( WP_REST_Request $req ) {
    $id        = (int) $req->get_param( 'id' );
    $is_active = $req->get_param( 'is_active' );
    $r = ridego_update_surge_rule( $id, ridego_app_admin_api_surge_raw_input( $req ), $is_active === null ? null : (bool) $is_active );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'Surge rule not found.' ? 404 : 400;
        return new WP_Error( 'update_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_delete_surge_rule() (includes/helpers.php). */
function ridego_app_admin_api_surge_delete( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    $r  = ridego_delete_surge_rule( $id );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'Surge rule not found.' ? 404 : 500;
        return new WP_Error( 'delete_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'] ) );
}
