<?php
/**
 * RideGo Route Marketing Pages — engine.
 * ================================================================
 * Automated route-based SEO/marketing landing pages, built entirely on
 * top of REAL data already in the platform:
 *   - ridego_routes: admin-curated origin→destination pairs with real
 *     distance_km/duration_mins (never a blind city×city combination —
 *     see ridego_route_page_eligible_routes()).
 *   - ridego_route_vehicle_pricing: real per-route fixed prices, when an
 *     admin has set one.
 *   - ridego_calculate_fare(): the SAME fare engine that prices a real
 *     booking, used here to compute an honest "estimated" fare when no
 *     fixed price exists — never an invented number.
 *   - ridego_vehicles / ridego_cities: real fleet and city data.
 *
 * A route page's CONTENT is never stored as frozen text. ridego_generate_route_page_content()
 * recomputes every section live, on every request, straight from the tables above — so a
 * page can never drift out of sync with real inventory, pricing or city data. What IS stored
 * (ridego_route_pages) is only the page's *workflow* state: which routes have a page at all,
 * its slug, any admin SEO-title/meta-description override, its publish status and the last
 * quality-check result. This is also why editing a vehicle's price or a route's distance
 * updates every route page that uses it immediately, with no separate "regenerate" step.
 *
 * "Unique, human-written" content (section 7 of the spec) is approximated honestly: every
 * sentence is built from the route's OWN real facts (real city names, real distance, real
 * duration, real vehicle list) dropped into one of several phrasing templates, with the
 * template variant chosen deterministically from the route's id — so the same route always
 * reads the same way, but two different routes very rarely read identically. Nothing is
 * invented: a fact that isn't in the database is simply left out of the page (e.g. no
 * "places along the route" section exists, because RideGo has no waypoint/landmark data).
 * ================================================================
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ---------------------------------------------------------------
   Small helpers
   --------------------------------------------------------------- */

function ridego_route_pages_table() {
    global $wpdb;
    return $wpdb->prefix . 'ridego_route_pages';
}

/* ---------------------------------------------------------------
   Hero settings (Tasks 3-6) — per-route override columns on
   ridego_route_pages, falling back to a global-default set stored via
   the generic ridego_get_setting/ridego_update_setting key-value store
   (prefixed route_page_hero_default_), falling back finally to a
   sane hard-coded look. A field counts as "set" (overriding) when it
   is non-empty ('' / null means "use the default"), except
   hero_overlay_enabled, whose unset state is genuinely NULL (false is
   a real, distinct override value from "unset").
   --------------------------------------------------------------- */

// Real px values for the three height presets, both breakpoints. A
// 'custom' height instead stores a literal px integer as the string value.
function ridego_route_page_hero_height_presets() {
    return array( 'compact' => 280, 'standard' => 360, 'large' => 460 );
}

// Resolves a stored height value ('compact'|'standard'|'large'|'<int>') to a px int.
function ridego_route_page_hero_height_px( $value, $fallback_px ) {
    $presets = ridego_route_page_hero_height_presets();
    if ( isset( $presets[ $value ] ) ) { return $presets[ $value ]; }
    if ( is_numeric( $value ) && (int) $value > 0 ) { return (int) $value; }
    return $fallback_px;
}

// Field name => sanitizer spec, shared by the per-route override columns and
// the route_page_hero_default_* global settings (same key suffix on both).
function ridego_route_page_hero_fields() {
    return array(
        'hero_mode'               => array( 'type' => 'enum', 'options' => array( '', 'standard', 'image' ) ),
        'hero_heading'            => array( 'type' => 'text', 'max' => 200 ),
        'hero_subheading'         => array( 'type' => 'text', 'max' => 320 ),
        'hero_bg_color'           => array( 'type' => 'color' ),
        'hero_image_desktop_url'  => array( 'type' => 'url' ),
        'hero_image_mobile_url'   => array( 'type' => 'url' ),
        'hero_height_desktop'     => array( 'type' => 'height' ),
        'hero_height_mobile'      => array( 'type' => 'height' ),
        'hero_overlay_enabled'    => array( 'type' => 'nullable_bool' ),
        // Separate from every hero_* field above: this is NOT part of the
        // hero banner, and is never read by ridego_route_page_effective_hero().
        // It's the dedicated Home Page "Popular Outstation Routes" card
        // thumbnail image, consumed only by ridego_app_api_popular_routes()
        // (includes/app-api.php). Blank = fall back to the city photo.
        'card_image_url'          => array( 'type' => 'url' ),
    );
}

function ridego_route_page_sanitize_hero_field( $key, $spec, $value ) {
    switch ( $spec['type'] ) {
        case 'enum':
            $value = sanitize_key( (string) $value );
            return in_array( $value, $spec['options'], true ) ? $value : '';
        case 'text':
            return mb_substr( sanitize_text_field( (string) $value ), 0, $spec['max'] );
        case 'color':
            $value = sanitize_text_field( (string) $value );
            return preg_match( '/^#[0-9a-fA-F]{3,8}$/', $value ) ? $value : '';
        case 'url':
            return $value ? esc_url_raw( (string) $value ) : '';
        case 'height':
            $value = sanitize_text_field( (string) $value );
            $presets = ridego_route_page_hero_height_presets();
            if ( isset( $presets[ $value ] ) ) { return $value; }
            if ( is_numeric( $value ) && (int) $value > 0 ) { return (string) (int) $value; }
            return '';
        case 'nullable_bool':
            if ( $value === null || $value === '' ) { return null; }
            return filter_var( $value, FILTER_VALIDATE_BOOLEAN ) ? 1 : 0;
    }
    return '';
}

// Global-default settings key for a hero field, in the shared key-value store.
function ridego_route_page_hero_default_setting_key( $field ) {
    return 'route_page_hero_default_' . $field;
}

// TRACE: reads the whole route_page_hero_default_* setting set → assoc array,
//        one entry per hero field, each already resolved to its real value
//        (never a placeholder) — '' / null where no default has ever been set.
function ridego_get_route_page_hero_defaults() {
    $out = array();
    foreach ( array_keys( ridego_route_page_hero_fields() ) as $field ) {
        $stored = ridego_get_setting( ridego_route_page_hero_default_setting_key( $field ), null );
        if ( $field === 'hero_overlay_enabled' ) {
            $out[ $field ] = ( $stored === null || $stored === '' ) ? null : (bool) (int) $stored;
        } else {
            $out[ $field ] = $stored === null ? '' : $stored;
        }
    }
    return $out;
}

// TRACE: {field => value} (only real admin-submitted fields) → writes each
//        through the shared settings store → array of the fields actually
//        saved. Unknown fields are ignored rather than silently coerced.
function ridego_update_route_page_hero_defaults( $fields ) {
    $saved = array();
    $specs = ridego_route_page_hero_fields();
    foreach ( $specs as $field => $spec ) {
        if ( ! array_key_exists( $field, $fields ) ) { continue; }
        $clean = ridego_route_page_sanitize_hero_field( $field, $spec, $fields[ $field ] );
        ridego_update_setting( ridego_route_page_hero_default_setting_key( $field ), $clean === null ? '' : $clean );
        $saved[ $field ] = $clean;
    }
    return $saved;
}

// TRACE: a ridego_route_pages row → the fully-resolved hero config the public
//        page renders (override → global default → hard-coded fallback),
//        with heights already converted to real px ints → array. Pure/
//        read-only; safe on every page view, same as the rest of this file.
function ridego_route_page_effective_hero( $page_row ) {
    $defaults = ridego_get_route_page_hero_defaults();

    $pick_str = function ( $field ) use ( $page_row, $defaults ) {
        $override = isset( $page_row->{$field} ) ? (string) $page_row->{$field} : '';
        if ( $override !== '' ) { return $override; }
        return $defaults[ $field ] !== '' ? $defaults[ $field ] : '';
    };

    $mode = $pick_str( 'hero_mode' );
    if ( $mode !== 'image' && $mode !== 'standard' ) { $mode = 'standard'; }

    $overlay_override = isset( $page_row->hero_overlay_enabled ) ? $page_row->hero_overlay_enabled : null;
    if ( $overlay_override !== null && $overlay_override !== '' ) {
        $overlay = (bool) (int) $overlay_override;
    } elseif ( $defaults['hero_overlay_enabled'] !== null ) {
        $overlay = (bool) $defaults['hero_overlay_enabled'];
    } else {
        $overlay = false; // spec: default OFF
    }

    $height_desktop_raw = $pick_str( 'hero_height_desktop' );
    $height_mobile_raw  = $pick_str( 'hero_height_mobile' );

    return array(
        'mode'                => $mode,
        'heading'             => $pick_str( 'hero_heading' ),
        'subheading'          => $pick_str( 'hero_subheading' ),
        'bg_color'            => $pick_str( 'hero_bg_color' ),
        'image_desktop_url'   => $pick_str( 'hero_image_desktop_url' ),
        'image_mobile_url'    => $pick_str( 'hero_image_mobile_url' ),
        'height_desktop_px'   => ridego_route_page_hero_height_px( $height_desktop_raw, 360 ),
        'height_mobile_px'    => ridego_route_page_hero_height_px( $height_mobile_raw, 360 ),
        'overlay_enabled'     => $overlay,
    );
}

// TRACE: two real city names → a URL-safe, unique-per-direction slug → string.
//        "Delhi","Jaipur" → "delhi-to-jaipur". Direction matters: this is never
//        the same string as ridego_route_page_slug("Jaipur","Delhi").
function ridego_route_page_slug( $from_city, $to_city ) {
    return sanitize_title( $from_city . '-to-' . $to_city );
}

// TRACE: an index and a list of template strings → one template, chosen
//        deterministically by (seed + salt) → string. Same seed+salt always
//        picks the same variant (a route reads the same way on every load);
//        different salts let the SAME route pick different variants for
//        different sections, so one route's page doesn't repeat one sentence
//        shape throughout.
function ridego_route_page_pick( $seed, $salt, array $variants ) {
    if ( ! $variants ) { return ''; }
    $i = ( (int) $seed + ridego_route_page_str_hash( $salt ) ) % count( $variants );
    return $variants[ $i ];
}
function ridego_route_page_str_hash( $s ) {
    $h = 0;
    foreach ( str_split( (string) $s ) as $c ) { $h = ( $h * 31 + ord( $c ) ) % 100000; }
    return $h;
}

/* ---------------------------------------------------------------
   Eligibility — section 3: never a blind combination. Eligible routes
   are EXACTLY the routes RideGo's own team has already curated into
   ridego_routes (real distance, real duration, is_active=1) — this
   table is already the "meaningful and commercially relevant" filter
   the spec asks for, since every row in it was added deliberately
   (or seeded from real fare/route data), never generated by crossing
   every city with every other city.
   --------------------------------------------------------------- */

// TRACE: nothing → every active route from ridego_routes, each annotated with
//        whether a route page already exists for it, its status, and how many
//        vehicle options it can honestly show → array of rows. Preconditions:
//        none. Postconditions: read-only. Edge cases: a route with zero
//        vehicles anywhere in the system still appears (so the admin can see
//        it), but ridego_route_page_quality_check() will flag it.
function ridego_route_page_eligible_routes() {
    global $wpdb;
    $rtbl = $wpdb->prefix . 'ridego_routes';
    $ptbl = ridego_route_pages_table();
    $rows = $wpdb->get_results(
        "SELECT r.*, p.id AS page_id, p.slug AS page_slug, p.status AS page_status
         FROM {$rtbl} r
         LEFT JOIN {$ptbl} p ON p.route_id = r.id
         WHERE r.is_active = 1
         ORDER BY r.is_popular DESC, r.from_city ASC, r.to_city ASC"
    );
    $vehicle_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_vehicles WHERE is_active=1" );
    return array_map( function ( $r ) use ( $vehicle_count ) {
        return array(
            'route_id'      => (int) $r->id,
            'from_city'     => $r->from_city,
            'to_city'       => $r->to_city,
            'distance_km'   => (float) $r->distance_km,
            'duration_mins' => (int) $r->duration_mins,
            'is_popular'    => (bool) $r->is_popular,
            'has_page'      => $r->page_id !== null,
            'page_id'       => $r->page_id !== null ? (int) $r->page_id : null,
            'page_slug'     => $r->page_slug,
            'page_status'   => $r->page_status,
            'vehicle_count' => $vehicle_count, // platform-wide fleet; per-route pricing narrows this at render time, not eligibility time
            'eligible'      => $r->distance_km > 0 && $vehicle_count > 0,
        );
    }, $rows );
}

/* ---------------------------------------------------------------
   Quality gate — section 12.
   --------------------------------------------------------------- */

// TRACE: a route row + the seo_title/meta_description this page would use +
//        its own row id (null if not yet created) → a list of human-readable
//        quality problems → array (empty = passes). Never mutates anything.
function ridego_route_page_quality_check( $route_row, $seo_title, $meta_description, $existing_id = null ) {
    global $wpdb;
    $issues = array();

    if ( ! $route_row ) {
        return array( 'Route not found.' );
    }
    if ( (float) $route_row->distance_km <= 0 ) {
        $issues[] = 'This route has no real distance data yet — add it on the Routes tab first.';
    }
    if ( strcasecmp( $route_row->from_city, $route_row->to_city ) === 0 ) {
        $issues[] = 'Origin and destination are the same city.';
    }
    if ( empty( $route_row->is_active ) ) {
        $issues[] = 'The underlying route is deactivated (Routes tab) — activate it there first, or this page will never appear in Popular Outstation Routes on the Home Page.';
    }
    $vehicle_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_vehicles WHERE is_active=1" );
    if ( $vehicle_count < 1 ) {
        $issues[] = 'No active vehicle types exist on the platform, so this page would have nothing real to offer.';
    }
    if ( trim( (string) $seo_title ) === '' ) {
        $issues[] = 'SEO title is empty.';
    } else {
        $ptbl = ridego_route_pages_table();
        $dupe = $existing_id
            ? $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$ptbl} WHERE seo_title=%s AND id<>%d", $seo_title, $existing_id ) )
            : $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$ptbl} WHERE seo_title=%s", $seo_title ) );
        if ( $dupe ) {
            $issues[] = 'SEO title is not unique — another route page already uses it.';
        }
    }
    if ( trim( (string) $meta_description ) === '' ) {
        $issues[] = 'Meta description is empty.';
    } else {
        $ptbl = ridego_route_pages_table();
        $dupe_desc = $existing_id
            ? $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$ptbl} WHERE meta_description=%s AND id<>%d", $meta_description, $existing_id ) )
            : $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$ptbl} WHERE meta_description=%s", $meta_description ) );
        if ( $dupe_desc ) {
            $issues[] = 'Meta description is not unique — another route page already uses it.';
        }
    }
    return $issues;
}

/* ---------------------------------------------------------------
   SEO title / meta description auto-generation (section 6/10).
   Admin-entered values (ridego_route_pages.seo_title/meta_description)
   always win when present; these are only the fallback so a page is
   never published with a blank title.
   --------------------------------------------------------------- */

function ridego_route_page_default_seo_title( $from_city, $to_city ) {
    return "{$from_city} to {$to_city} Cab & Taxi Service | RideGo";
}
function ridego_route_page_default_meta_description( $from_city, $to_city, $distance_km ) {
    $d = $distance_km > 0 ? ' (' . round( $distance_km ) . ' km)' : '';
    return "Book a one-way or round-trip cab from {$from_city} to {$to_city}{$d} with RideGo. Compare real vehicle options, get a fare estimate and book online.";
}

/* ---------------------------------------------------------------
   Vehicle options for a route (section 5/9) — always real: a fixed
   admin-set price when one exists for THIS route+vehicle, otherwise a
   live estimate from the exact same fare engine a real booking uses.
   --------------------------------------------------------------- */

// TRACE: a route row → every active vehicle type with a real fare figure for
//        one_way and round_trip on this route → array. 'pricing_source' tells
//        the frontend/admin whether the number is an admin-set fixed price
//        ('fixed') or a live computed estimate ('estimated') — the frontend
//        must label 'estimated' figures as such (section 9's "must clearly
//        communicate pricing may vary" requirement), never present either as
//        a guaranteed quote.
function ridego_route_page_vehicle_options( $route_row ) {
    global $wpdb;
    $vehicles = ridego_get_vehicles( true );
    if ( ! $vehicles ) { return array(); }

    $fixed_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT vehicle_id, fixed_price FROM {$wpdb->prefix}ridego_route_vehicle_pricing WHERE route_id=%d",
        $route_row->id
    ), OBJECT_K );

    $out = array();
    foreach ( $vehicles as $v ) {
        $fixed = isset( $fixed_rows[ $v->id ] ) ? (float) $fixed_rows[ $v->id ]->fixed_price : null;

        $one_way = null;
        $round_trip = null;
        if ( $fixed !== null && $fixed > 0 ) {
            $one_way = array( 'amount' => $fixed, 'source' => 'fixed' );
        } elseif ( function_exists( 'ridego_calculate_fare' ) ) {
            $r = ridego_calculate_fare( array(
                'trip_type' => 'one_way', 'vehicle_type_id' => $v->id, 'distance_km' => (float) $route_row->distance_km,
                'pickup_city' => $route_row->from_city, 'drop_city' => $route_row->to_city,
            ) );
            if ( empty( $r['error'] ) && ! empty( $r['total_fare'] ) ) {
                $one_way = array( 'amount' => round( (float) $r['total_fare'] ), 'source' => 'estimated' );
            }
        }
        if ( function_exists( 'ridego_calculate_fare' ) ) {
            $rr = ridego_calculate_fare( array(
                'trip_type' => 'round_trip', 'vehicle_type_id' => $v->id, 'distance_km' => (float) $route_row->distance_km,
                'pickup_city' => $route_row->from_city, 'drop_city' => $route_row->to_city,
            ) );
            if ( empty( $rr['error'] ) && ! empty( $rr['total_fare'] ) ) {
                $round_trip = array( 'amount' => round( (float) $rr['total_fare'] ), 'source' => 'estimated' );
            }
        }
        if ( $one_way === null && $round_trip === null ) { continue; }

        $out[] = array(
            'id'                => (int) $v->id,
            'slug'              => $v->slug,
            'name'              => $v->name,
            'seating_capacity'  => (int) $v->seating_capacity,
            'luggage_capacity'  => (int) $v->luggage_capacity,
            'ac_available'      => (bool) $v->ac_available,
            // Same source of truth as the Home Page's vehicle cards (wp_ridego_vehicles.icon_url,
            // uploaded via Admin → Pricing → vehicle photo upload). Never a route-page-only field.
            'image_url'         => isset( $v->icon_url ) ? (string) $v->icon_url : '',
            'one_way'           => $one_way,
            'round_trip'        => $round_trip,
        );
    }
    return $out;
}

/* ---------------------------------------------------------------
   Content cache (perf fix) — ridego_generate_route_page_content() runs
   several live DB queries plus 2 ridego_calculate_fare() calls PER
   VEHICLE, on every single request; a busy route page has no reason to
   redo all of that within the same short window. A WordPress transient
   caches the generated content per route_id for RIDEGO_ROUTE_CONTENT_TTL
   seconds. Staleness beyond that window is bounded and acceptable (the
   spec's own tolerance), but an admin edit must still show up
   IMMEDIATELY, not after the TTL — so every write path that can change a
   route page's content (the route's own fields, its vehicle-price
   overrides, and vehicle-type pricing/activation, which the fare-estimate
   figures and vehicle list both depend on) busts the cache for the
   affected route(s) right when it happens, via
   ridego_route_page_bust_content_cache(). A single monotonically
   increasing "cache version" option is embedded in every transient's key
   instead of trying to delete every existing transient by name: bumping
   one option instantly invalidates every route's currently-cached content
   in one write, with no risk of missing a route_id, and old transients
   simply expire off naturally (their key can never be looked up again).
   --------------------------------------------------------------- */

define( 'RIDEGO_ROUTE_CONTENT_TTL', 15 * MINUTE_IN_SECONDS );

// TRACE: nothing → the current cache "generation" number → int. Every
//        transient key for route content includes this, so bumping it
//        (ridego_route_page_bust_content_cache()) makes every previously
//        cached route's content unreachable at once, without deleting
//        each transient individually.
function ridego_route_page_content_cache_version() {
    $v = (int) get_option( 'ridego_route_content_cache_ver', 1 );
    return $v > 0 ? $v : 1;
}

// TRACE: nothing → bumps the shared cache generation number → void. Called
//        from every admin write path that can change what a route page's
//        content would show (route data, per-route vehicle pricing,
//        vehicle-type pricing/activation). Cheap: one autoloaded option
//        write, regardless of how many route pages exist.
function ridego_route_page_bust_content_cache() {
    $v = ridego_route_page_content_cache_version();
    update_option( 'ridego_route_content_cache_ver', $v + 1, false );
}

function ridego_route_page_content_cache_key( $route_id ) {
    return 'ridego_route_content_' . (int) $route_id . '_v' . ridego_route_page_content_cache_version();
}

/* ---------------------------------------------------------------
   Content generation (sections 2, 7, 9) — the big one. Everything
   here reads real tables; nothing is invented. See file header.
   --------------------------------------------------------------- */

// TRACE: a route id → the full set of dynamic sections a route page needs,
//        or null if the route doesn't exist → array|null. Cached in a
//        transient (see block above) for RIDEGO_ROUTE_CONTENT_TTL seconds
//        so a busy page doesn't redo several live queries + 2 fare-engine
//        calls per vehicle on every single request; an admin edit that
//        bumps the cache version makes a fresh copy appear immediately
//        regardless of the TTL. ridego_generate_route_page_content_uncached()
//        holds the actual generation logic and is what recomputes on a
//        cache miss.
function ridego_generate_route_page_content( $route_id ) {
    $route_id = (int) $route_id;
    $key      = ridego_route_page_content_cache_key( $route_id );
    $cached   = get_transient( $key );
    if ( is_array( $cached ) ) {
        return $cached;
    }
    $content = ridego_generate_route_page_content_uncached( $route_id );
    if ( $content !== null ) {
        set_transient( $key, $content, RIDEGO_ROUTE_CONTENT_TTL );
    }
    return $content;
}

function ridego_generate_route_page_content_uncached( $route_id ) {
    global $wpdb;
    $route = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_routes WHERE id=%d", $route_id ) );
    if ( ! $route ) { return null; }

    $from = $route->from_city;
    $to   = $route->to_city;
    $seed = (int) $route->id;
    $km   = (float) $route->distance_km;
    $mins = (int) $route->duration_mins;

    $from_row = ridego_get_city_by_name( $from );
    $to_row   = ridego_get_city_by_name( $to );
    $has_airport = ( $from_row && $from_row->airport_name ) || ( $to_row && $to_row->airport_name );

    $vehicles = ridego_route_page_vehicle_options( $route );
    $vehicle_names = array_map( function ( $v ) { return $v['name']; }, $vehicles );
    $has_innova = (bool) array_filter( $vehicles, function ( $v ) { return stripos( $v['name'], 'innova' ) !== false; } );
    $has_tempo  = (bool) array_filter( $vehicles, function ( $v ) { return stripos( $v['name'], 'tempo' ) !== false; } );

    // ---- Overview (section 2) — varied phrasing, real facts only. A pool
    // of 8 distinct phrasings (was 3) so hundreds of routes don't collapse
    // into only 3 repeated sentence shapes site-wide; each still uses only
    // this route's own real distance/duration/vehicle-count facts, never
    // an invented one, and the route_id-based selection stays deterministic.
    $vehicle_count_word = count( $vehicles );
    $overview = ridego_route_page_pick( $seed, 'overview', array(
        "Travelling from {$from} to {$to} is one of the routes RideGo's driver-partners cover regularly, spanning an approximate distance of " . round( $km ) . " km. Whether it's a one-way trip, a round trip, or an airport transfer, you can compare vehicle options and request a ride online.",
        "{$from} to {$to} is a route RideGo supports end to end — from a single one-way drop to a full round trip with the same driver waiting for your return. The journey covers roughly " . round( $km ) . " km, and RideGo lets you pick the vehicle that suits your group size and luggage before you book.",
        "Need to get from {$from} to {$to}? RideGo connects you with verified driver-partners for this route, covering an approximate " . round( $km ) . " km journey. You can choose a one-way cab, a round trip, or, where applicable, an airport pickup or drop.",
        "Booking a cab for {$from} to {$to} with RideGo takes a few minutes online. The route runs about " . round( $km ) . " km, and typically takes around " . round( $mins / 60, 1 ) . " hours, with " . $vehicle_count_word . " vehicle option" . ( $vehicle_count_word === 1 ? '' : 's' ) . " to compare before you confirm.",
        "For a {$from} to {$to} trip, RideGo lines up a verified driver-partner and a real vehicle for a journey of roughly " . round( $km ) . " km. One-way and round-trip both work for this route, and every fare is shown before you book — not after.",
        "{$from} and {$to} are connected by one of RideGo's regularly served routes, about " . round( $km ) . " km apart. Pick a vehicle, choose one-way or round trip, and get an honest fare estimate straight away.",
        "Planning a trip between {$from} and {$to}? RideGo's driver-partners cover this roughly " . round( $km ) . " km route for both one-way and round-trip bookings, with real vehicle options shown up front so there's nothing to negotiate at pickup.",
        "The {$from} to {$to} route is one RideGo handles routinely — an approximate " . round( $km ) . " km drive with a choice of vehicles, transparent fares, and online booking from start to finish.",
    ) );

    // ---- Distance & journey (section 3) — a range framed as "typically", never a guarantee.
    $low  = max( 0, (int) round( $mins * 0.9 ) );
    $high = (int) round( $mins * 1.15 );
    $journey_info = array(
        'distance_km'        => round( $km, 1 ),
        'typical_minutes_low'  => $low,
        'typical_minutes_high' => $high,
        'note' => 'Actual travel time varies with traffic, weather, chosen route and stops — this is a typical range, not a guarantee.',
    );

    // ---- Available services (section 4) — only real, platform-supported trip types.
    $services = array(
        array( 'key' => 'one_way', 'label' => 'One-Way Cab', 'description' => "A single {$from} to {$to} drop, no return leg." ),
        array( 'key' => 'round_trip', 'label' => 'Round-Trip Cab', 'description' => "Same driver and vehicle for the {$to} to {$from} return leg too." ),
    );
    if ( $has_airport ) {
        $services[] = array( 'key' => 'airport_transfer', 'label' => 'Airport Transfer', 'description' => 'Pickup or drop timed to a flight, where an airport serves this route.' );
    }
    $services[] = array( 'key' => 'local', 'label' => 'Hourly / Local Rental', 'description' => 'RideGo also offers hourly local rentals platform-wide, useful for multi-stop plans around either city.' );

    // ---- Choose the right vehicle (section 6) — generic, real-spec-grounded guidance.
    $guidance = array();
    foreach ( $vehicles as $v ) {
        $guidance[] = array(
            'vehicle' => $v['name'],
            'note'    => $v['seating_capacity'] >= 6
                ? "Seats up to {$v['seating_capacity']}, {$v['luggage_capacity']} bags — a fit for group or family travel with more luggage."
                : "Seats up to {$v['seating_capacity']}, {$v['luggage_capacity']} bags — a fit for a smaller group travelling light.",
        );
    }

    // ---- Popular pickup & drop locations (section 7) — real fields only, nothing invented.
    $pickup_points = array( array( 'label' => "{$from} (city)" ) );
    if ( $from_row && $from_row->airport_name ) {
        $pickup_points[] = array( 'label' => $from_row->airport_name . ( $from_row->airport_code ? ' (' . $from_row->airport_code . ')' : '' ) );
    }
    $drop_points = array( array( 'label' => "{$to} (city)" ) );
    if ( $to_row && $to_row->airport_name ) {
        $drop_points[] = array( 'label' => $to_row->airport_name . ( $to_row->airport_code ? ' (' . $to_row->airport_code . ')' : '' ) );
    }

    // ---- Why this route with RideGo (section 8) — real, platform-wide capabilities.
    $why = array(
        'Multiple real vehicle options to compare, not just one default car',
        'One-way and round-trip both available for this route',
        'A fare estimate before you book — no need to call for a quote',
        'Online enquiry and booking, no back-and-forth required',
    );
    if ( $has_airport ) { $why[] = 'Airport-aware pickup/drop where this route touches an airport'; }

    // ---- Travel guide (section 10) — generic, honest, not fabricated
    // statistics. Expanded to 6 distinct phrasings (was 2), still built only
    // from real per-route facts (has_airport / has_tempo / distance), never
    // an invented claim, and still deterministic by route_id.
    $travel_guide = ridego_route_page_pick( $seed, 'guide', array(
        "People travel this route for a mix of reasons — family visits, business trips and, where relevant, tourism. If you're on a schedule, a one-way cab is usually the simpler choice; if you're returning within a few days, a round trip keeps the same vehicle available for you.",
        "This route sees a mix of business and personal travel. Planning ahead helps if you need a specific vehicle type — checking real-time vehicle availability before your travel date is worthwhile for larger vehicles like a Tempo Traveller.",
        "A one-way cab suits a single leg of the trip, while a round trip keeps the same driver and vehicle on standby for your return — useful if your schedule on the other end isn't fixed yet.",
        "Distance on this route is roughly " . round( $km ) . " km, so it's worth booking a little ahead during peak travel periods to have your preferred vehicle confirmed rather than choosing from whatever's left.",
        $has_airport
            ? "Since this route touches an airport, it's worth requesting the airport transfer option and sharing your flight timing when you book, so the driver can plan the pickup or drop around it."
            : "There's no airport directly on this route, so most bookings here are city-to-city — a one-way or round trip covers most travel needs.",
        "Group size and luggage are usually the deciding factor on this route: a Sedan works well for lighter, smaller-group travel, while an Innova Crysta or Tempo Traveller (where available) suits families or larger groups with more bags.",
    ) );

    // ---- FAQs (section 13) — only ask what the page can honestly answer.
    // Question phrasing for each recurring FAQ is now chosen from a pool of
    // 4-5 variants per question (was a single byte-identical phrasing for
    // every route), selected the same deterministic route_id+salt way as
    // the overview/travel_guide variants above — the ANSWER always stays
    // grounded in this route's real data; only the wording of the question
    // varies between routes.
    $faqs = array();
    $faqs[] = array(
        'q' => ridego_route_page_pick( $seed, 'faq_book', array(
            "How can I book a cab from {$from} to {$to}?",
            "What's the easiest way to book a {$from} to {$to} cab online?",
            "How do I book a taxi from {$from} to {$to}?",
            "Where can I book a {$from} to {$to} ride?",
        ) ),
        'a' => "Choose your vehicle and trip type on this page, or use RideGo's fare search, then request your ride online — no phone call needed.",
    );
    $faqs[] = array(
        'q' => ridego_route_page_pick( $seed, 'faq_oneway', array(
            "Can I book a one-way cab from {$from} to {$to}?",
            "Is a one-way trip from {$from} to {$to} available?",
            "Do you offer one-way drops from {$from} to {$to}?",
        ) ),
        'a' => 'Yes, one-way is available for this route.',
    );
    $faqs[] = array(
        'q' => ridego_route_page_pick( $seed, 'faq_roundtrip', array(
            "Can I book a round trip from {$from} to {$to}?",
            "Is a round-trip option available for {$from} to {$to}?",
            "Can the same cab wait for my return from {$to} to {$from}?",
        ) ),
        'a' => 'Yes — the same vehicle and driver can wait for your return leg.',
    );
    if ( $vehicle_names ) {
        $faqs[] = array(
            'q' => ridego_route_page_pick( $seed, 'faq_vehicles', array(
                "What vehicles are available for {$from} to {$to}?",
                "Which cars can I choose for a {$from} to {$to} trip?",
                "What vehicle options does RideGo offer on this route?",
            ) ),
            'a' => 'Currently: ' . implode( ', ', $vehicle_names ) . '.',
        );
    }
    if ( $has_innova ) {
        $faqs[] = array( 'q' => "Can I book an Innova Crysta from {$from} to {$to}?", 'a' => 'Yes, an Innova Crysta is available for this route — see the vehicle options above for its estimated fare.' );
    }
    if ( $has_tempo ) {
        $faqs[] = array( 'q' => 'Can I hire a Tempo Traveller for a group?', 'a' => 'Yes, a Tempo Traveller is available for larger groups on this route.' );
    }
    if ( $has_airport ) {
        $faqs[] = array( 'q' => 'Can I get airport pickup or drop on this route?', 'a' => 'Yes, this route touches an airport — request an airport transfer when booking.' );
    }
    $faqs[] = array(
        'q' => ridego_route_page_pick( $seed, 'faq_family', array(
            'Which vehicle is suitable for a family?',
            'What\'s the best vehicle choice for a family trip?',
            'Which car should I pick for a family with luggage?',
        ) ),
        'a' => 'A Sedan or SUV comfortably fits a small family with luggage; for larger families or groups, an Innova Crysta or Tempo Traveller (where available) gives more room.',
    );
    $faqs[] = array(
        'q' => ridego_route_page_pick( $seed, 'faq_distance', array(
            "How far is {$from} from {$to}, and how long does it take?",
            "What's the distance and travel time between {$from} and {$to}?",
            "How long does the {$from} to {$to} journey take?",
        ) ),
        'a' => 'The route is approximately ' . round( $km ) . ' km, typically taking ' . $low . '–' . $high . ' minutes depending on traffic and conditions.',
    );

    // ---- Related routes (section 11) — real, published sibling routes only.
    $ptbl = ridego_route_pages_table();
    $related = $wpdb->get_results( $wpdb->prepare(
        "SELECT r.id, r.from_city, r.to_city, p.slug
         FROM {$wpdb->prefix}ridego_routes r
         INNER JOIN {$ptbl} p ON p.route_id = r.id AND p.status = 'published'
         WHERE r.id <> %d AND (r.from_city = %s OR r.to_city = %s OR r.from_city = %s)
         ORDER BY r.is_popular DESC LIMIT 8",
        $route->id, $from, $to, $to
    ) );
    $related_out = array_map( function ( $r ) {
        return array( 'from_city' => $r->from_city, 'to_city' => $r->to_city, 'slug' => $r->slug );
    }, $related );

    // ---- Nearby origin/destination routes (section 12) — same idea, split by direction, real+published only.
    $from_origin = array_values( array_filter( $related_out, function ( $r ) use ( $from ) { return $r['from_city'] === $from; } ) );
    $from_destination = array_values( array_filter( $related_out, function ( $r ) use ( $to ) { return $r['from_city'] === $to; } ) );

    return array(
        'route_id'      => (int) $route->id,
        'from_city'     => $from,
        'to_city'       => $to,
        // Real admin-uploaded city photos only (Settings → Cities) — '' when
        // none has been uploaded, never a stock/placeholder fallback. See
        // ridego_get_city_by_name()/wp_ridego_cities.image_url.
        'from_city_image_url' => ( $from_row && $from_row->image_url ) ? $from_row->image_url : '',
        'to_city_image_url'   => ( $to_row && $to_row->image_url ) ? $to_row->image_url : '',
        'distance_km'   => round( $km, 1 ),
        'duration_mins' => $mins,
        'overview'      => $overview,
        'journey'       => $journey_info,
        'services'      => $services,
        'vehicles'      => $vehicles,
        'vehicle_guidance' => $guidance,
        'pickup_points' => $pickup_points,
        'drop_points'   => $drop_points,
        'why_ridego'    => $why,
        'travel_guide'  => $travel_guide,
        'faqs'          => $faqs,
        'related_routes'      => $related_out,
        'from_origin_routes'  => $from_origin,
        'from_destination_routes' => $from_destination,
    );
}

// NOTE: ridego_get_city_by_name() is already defined in includes/helpers.php
// (identical query) — reused here rather than redeclared.

/* ---------------------------------------------------------------
   CRUD
   --------------------------------------------------------------- */

// TRACE: a route id → a new draft/needs_review row in ridego_route_pages →
//        {success, id|message}. Refuses a route that already has a page
//        (one page per route — regenerate by editing, not duplicating) or
//        that doesn't exist. Quality is checked at creation time purely to
//        decide the STARTING status (needs_review vs draft); it is
//        re-checked again, and enforced, at publish time regardless.
function ridego_create_route_page( $route_id, $user_id = 0 ) {
    global $wpdb;
    $route_id = (int) $route_id;
    $route = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_routes WHERE id=%d", $route_id ) );
    if ( ! $route ) { return array( 'success' => false, 'message' => 'Route not found.' ); }

    $ptbl = ridego_route_pages_table();
    $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$ptbl} WHERE route_id=%d", $route_id ) );
    if ( $exists ) { return array( 'success' => false, 'message' => 'A page already exists for this route.', 'id' => (int) $exists ); }

    $slug = ridego_route_page_slug( $route->from_city, $route->to_city );
    // Slugs are unique; a from/to pair can't repeat since route_id itself is unique per pair,
    // but guard anyway in case two differently-cased city name variants collide.
    $suffix = 1;
    $base_slug = $slug;
    while ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$ptbl} WHERE slug=%s", $slug ) ) ) {
        $suffix++;
        $slug = $base_slug . '-' . $suffix;
    }

    $seo_title = ridego_route_page_default_seo_title( $route->from_city, $route->to_city );
    $meta_desc = ridego_route_page_default_meta_description( $route->from_city, $route->to_city, (float) $route->distance_km );
    $issues = ridego_route_page_quality_check( $route, $seo_title, $meta_desc );

    $wpdb->insert( $ptbl, array(
        'route_id'         => $route_id,
        'slug'             => $slug,
        'seo_title'        => $seo_title,
        'meta_description' => $meta_desc,
        'status'           => $issues ? 'needs_review' : 'draft',
        'quality_issues'   => wp_json_encode( $issues ),
        'generated_by'     => (int) $user_id,
    ) );
    $id = (int) $wpdb->insert_id;
    if ( ! $id ) { return array( 'success' => false, 'message' => 'Could not create route page: ' . ( $wpdb->last_error ?: 'database error.' ) ); }
    ridego_audit_log( 'route_page_created', 'route_page', $id, '', array( 'route_id' => $route_id, 'slug' => $slug ) );
    return array( 'success' => true, 'id' => $id, 'slug' => $slug, 'status' => $issues ? 'needs_review' : 'draft', 'quality_issues' => $issues );
}

// TRACE: a list of route ids → ridego_create_route_page() for each → per-route
//        result summary. One failure (e.g. a route that already has a page)
//        never blocks the rest — this is exactly "Generate Selected" from the
//        spec's bulk-generation UI.
function ridego_bulk_generate_route_pages( array $route_ids, $user_id = 0 ) {
    $results = array();
    foreach ( $route_ids as $rid ) {
        $r = ridego_create_route_page( (int) $rid, $user_id );
        $results[] = array_merge( array( 'route_id' => (int) $rid ), $r );
    }
    return $results;
}

// TRACE: a route page id + {seo_title?, meta_description?} → updates only the
//        fields provided, refreshes the stored quality snapshot → {success,message}.
function ridego_update_route_page( $id, $fields ) {
    global $wpdb;
    $id = (int) $id;
    $ptbl = ridego_route_pages_table();
    $page = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$ptbl} WHERE id=%d", $id ) );
    if ( ! $page ) { return array( 'success' => false, 'message' => 'Route page not found.' ); }
    $route = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_routes WHERE id=%d", $page->route_id ) );

    $data = array();
    if ( array_key_exists( 'seo_title', $fields ) ) { $data['seo_title'] = mb_substr( sanitize_text_field( (string) $fields['seo_title'] ), 0, 160 ); }
    if ( array_key_exists( 'meta_description', $fields ) ) { $data['meta_description'] = mb_substr( sanitize_textarea_field( (string) $fields['meta_description'] ), 0, 320 ); }
    foreach ( ridego_route_page_hero_fields() as $key => $spec ) {
        if ( ! array_key_exists( $key, $fields ) ) { continue; }
        $data[ $key ] = ridego_route_page_sanitize_hero_field( $key, $spec, $fields[ $key ] );
    }
    if ( ! $data ) { return array( 'success' => false, 'message' => 'Nothing to update.' ); }

    $seo_title = $data['seo_title'] ?? $page->seo_title;
    $meta_desc = $data['meta_description'] ?? $page->meta_description;
    $issues = ridego_route_page_quality_check( $route, $seo_title, $meta_desc, $id );
    $data['quality_issues'] = wp_json_encode( $issues );
    // Editing content never silently un-publishes a live page or silently
    // publishes one that now fails — only an explicit status change does that
    // (ridego_set_route_page_status()); this just keeps the stored snapshot honest.

    $wpdb->update( $ptbl, $data, array( 'id' => $id ) );
    ridego_audit_log( 'route_page_updated', 'route_page', $id, (array) $page, $data );
    return array( 'success' => true, 'message' => 'Route page updated.', 'quality_issues' => $issues );
}

// TRACE: a route page id + target status ('draft'|'needs_review'|'published') →
//        transitions it, ENFORCING the quality gate on the way into 'published'
//        (never bypassable from this function) → {success,message}. Leaving
//        'published' clears published_at; entering it (re)stamps it.
function ridego_set_route_page_status( $id, $status ) {
    global $wpdb;
    $id = (int) $id;
    $allowed = array( 'draft', 'needs_review', 'published' );
    if ( ! in_array( $status, $allowed, true ) ) { return array( 'success' => false, 'message' => 'Invalid status.' ); }

    $ptbl = ridego_route_pages_table();
    $page = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$ptbl} WHERE id=%d", $id ) );
    if ( ! $page ) { return array( 'success' => false, 'message' => 'Route page not found.' ); }
    $route = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_routes WHERE id=%d", $page->route_id ) );

    if ( $status === 'published' ) {
        $issues = ridego_route_page_quality_check( $route, $page->seo_title, $page->meta_description, $id );
        if ( $issues ) {
            $wpdb->update( $ptbl, array( 'quality_issues' => wp_json_encode( $issues ) ), array( 'id' => $id ) );
            return array( 'success' => false, 'message' => 'Cannot publish — quality checks failed.', 'quality_issues' => $issues );
        }
        $wpdb->update( $ptbl, array( 'status' => 'published', 'published_at' => current_time( 'mysql' ), 'quality_issues' => wp_json_encode( array() ) ), array( 'id' => $id ) );
    } else {
        $wpdb->update( $ptbl, array( 'status' => $status, 'published_at' => null ), array( 'id' => $id ) );
    }
    ridego_audit_log( 'route_page_status_changed', 'route_page', $id, array( 'status' => $page->status ), array( 'status' => $status ) );
    return array( 'success' => true, 'message' => 'Status updated to ' . $status . '.' );
}

// TRACE: a route page id → hard-deletes the workflow row (the underlying
//        route in ridego_routes is never touched) → {success,message}.
function ridego_delete_route_page( $id ) {
    global $wpdb;
    $id = (int) $id;
    $ptbl = ridego_route_pages_table();
    $page = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$ptbl} WHERE id=%d", $id ) );
    if ( ! $page ) { return array( 'success' => false, 'message' => 'Route page not found.' ); }
    $wpdb->delete( $ptbl, array( 'id' => $id ) );
    ridego_audit_log( 'route_page_deleted', 'route_page', $id, (array) $page, '' );
    return array( 'success' => true, 'message' => 'Route page deleted.' );
}

// TRACE: a slug → its route_page row + the route row it belongs to, or null → object|null.
function ridego_get_route_page_by_slug( $slug ) {
    global $wpdb;
    $ptbl = ridego_route_pages_table();
    $page = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$ptbl} WHERE slug=%s", sanitize_title( $slug ) ) );
    if ( ! $page ) { return null; }
    $route = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_routes WHERE id=%d", $page->route_id ) );
    if ( ! $route ) { return null; }
    return array( 'page' => $page, 'route' => $route );
}

// TRACE: a public /routes/{slug} URL's slug → {page, route, content} for the
//        real, PUBLISHED route page it maps to, or null when no such page
//        exists or it exists but isn't published — the exact same gate
//        GET /ridego/v1/routes/{slug} already enforces (see app-api.php's
//        ridego_app_api_route_page_by_slug()), reused here so the
//        server-side shell/SEO injection can never expose a draft/
//        needs_review page that the REST API itself would 404 on.
function ridego_route_page_public_data( $slug ) {
    $found = ridego_get_route_page_by_slug( $slug );
    if ( ! $found || $found['page']->status !== 'published' ) {
        return null;
    }
    $content = ridego_generate_route_page_content( (int) $found['page']->route_id );
    if ( ! $content ) {
        return null;
    }
    $content['slug']             = $found['page']->slug;
    $content['seo_title']        = $found['page']->seo_title;
    $content['meta_description'] = $found['page']->meta_description;
    $content['published_at']     = $found['page']->published_at;
    $content['hero']             = ridego_route_page_effective_hero( $found['page'] );
    return array( 'page' => $found['page'], 'route' => $found['route'], 'content' => $content );
}

// TRACE: every PUBLISHED route page → its public listing row (slug, from/to
//        city, distance, cheapest starting fare across active vehicles), for
//        the /routes/ index page — real REST endpoint (GET /ridego/v1/routes,
//        see app-api.php's ridego_app_api_route_pages_index()) and the
//        server-rendered SSR snapshot in app-shell.php both call this SAME
//        helper, so the two can never list a different set of routes or
//        disagree on a fare. Same status='published' gate as
//        ridego_route_page_public_data()/the sitemap provider/the REST
//        single-route endpoint. Ordered alphabetically by origin city so a
//        long list groups naturally by origin without any extra UI work.
function ridego_route_pages_list_published() {
    global $wpdb;
    $ptbl = ridego_route_pages_table();
    $rtbl = $wpdb->prefix . 'ridego_routes';

    $rows = $wpdb->get_results(
        "SELECT p.slug, p.published_at, r.id AS route_id, r.from_city, r.to_city, r.distance_km
         FROM {$ptbl} p
         INNER JOIN {$rtbl} r ON r.id = p.route_id
         WHERE p.status = 'published'
         ORDER BY r.from_city ASC, r.to_city ASC"
    );

    $vehicles = function_exists( 'ridego_get_vehicles' ) ? ridego_get_vehicles( true ) : array();
    $out = array();
    foreach ( (array) $rows as $r ) {
        $fare = null;
        if ( function_exists( 'ridego_get_route_fixed_price' ) ) {
            foreach ( $vehicles as $v ) {
                $p = ridego_get_route_fixed_price( $r->from_city, $r->to_city, (int) $v->id );
                if ( $p !== false && $p !== null ) {
                    $fare = ( $fare === null ) ? $p : min( $fare, $p );
                }
            }
        }
        $out[] = array(
            'slug'          => $r->slug,
            'from_city'     => $r->from_city,
            'to_city'       => $r->to_city,
            'distance_km'   => (float) $r->distance_km,
            'starting_fare' => $fare,
        );
    }
    return $out;
}
