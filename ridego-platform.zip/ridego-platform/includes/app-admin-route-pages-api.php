<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Route-Based SEO/Marketing Pages
   ------------------------------------------------------------
   Thin REST layer over includes/route-pages.php. Same discipline as
   the cities/routes admin API waves: every mutating call delegates
   to the canonical business-logic functions there (ridego_create_route_page(),
   ridego_update_route_page(), ridego_set_route_page_status(),
   ridego_delete_route_page(), ridego_bulk_generate_route_pages()) —
   nothing here re-implements validation, quality gating, or slug
   generation.

   Every route requires is_user_logged_in() AND
   ridego_can('ridego_manage_pricing') — the same capability the
   Routes/Cities admin API waves gate on, since route pages are a
   view built directly on top of the routes table.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_route_pages_api_routes' );
function ridego_register_app_admin_route_pages_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/route-pages', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_route_pages_list',
        'permission_callback' => 'ridego_app_admin_api_route_pages_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/route-pages/eligible', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_route_pages_eligible',
        'permission_callback' => 'ridego_app_admin_api_route_pages_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/route-pages/generate', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_route_pages_generate',
        'permission_callback' => 'ridego_app_admin_api_route_pages_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/route-pages/(?P<id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_route_page_update',
        'permission_callback' => 'ridego_app_admin_api_route_pages_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/route-pages/(?P<id>\d+)/status', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_route_page_status',
        'permission_callback' => 'ridego_app_admin_api_route_pages_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/route-pages/(?P<id>\d+)/delete', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_route_page_delete',
        'permission_callback' => 'ridego_app_admin_api_route_pages_permission',
    ) );

    // Global-default Hero settings (Task 3-6) — the fallback every route page's
    // hero uses when it has no per-route override for a given field.
    register_rest_route( 'ridego/v1', '/app/admin/route-page-hero-defaults', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_route_page_hero_defaults_get',
        'permission_callback' => 'ridego_app_admin_api_route_pages_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/route-page-hero-defaults', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_route_page_hero_defaults_update',
        'permission_callback' => 'ridego_app_admin_api_route_pages_permission',
    ) );

    // Hero image upload (desktop/mobile) — mirrors
    // ridego_app_admin_api_city_upload_image() exactly (real file-type check
    // from contents, size cap, WordPress's own upload handler).
    register_rest_route( 'ridego/v1', '/app/admin/route-pages/upload-hero-image', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_route_page_upload_hero_image',
        'permission_callback' => 'ridego_app_admin_api_route_pages_permission',
    ) );
}

function ridego_app_admin_api_route_page_hero_defaults_get( WP_REST_Request $req ) {
    return rest_ensure_response( ridego_get_route_page_hero_defaults() );
}

function ridego_app_admin_api_route_page_hero_defaults_update( WP_REST_Request $req ) {
    $fields = array();
    foreach ( array_keys( ridego_route_page_hero_fields() ) as $key ) {
        if ( $req->has_param( $key ) ) {
            $fields[ $key ] = $req->get_param( $key );
        }
    }
    $saved = ridego_update_route_page_hero_defaults( $fields );
    return rest_ensure_response( array( 'success' => true, 'saved' => $saved ) );
}

/** Same discipline as ridego_app_admin_api_city_upload_image(): real
 *  file-type check, 4MB cap (hero images are full-bleed, larger than a
 *  city thumbnail), WordPress's own upload handler. `variant` (desktop|
 *  mobile|card) is only echoed back — it doesn't change how the file is
 *  stored, just which field the caller applies the returned url to.
 *  'card' is the dedicated Home Page route-card thumbnail image — a
 *  separate upload from the hero desktop/mobile images. */
function ridego_app_admin_api_route_page_upload_hero_image( WP_REST_Request $req ) {
    $variant = sanitize_key( (string) $req->get_param( 'variant' ) );
    if ( ! in_array( $variant, array( 'desktop', 'mobile', 'card' ), true ) ) {
        return new WP_Error( 'invalid_input', "variant must be 'desktop', 'mobile' or 'card'.", array( 'status' => 400 ) );
    }
    $files = $req->get_file_params();
    if ( empty( $files['file'] ) || ! empty( $files['file']['error'] ) || empty( $files['file']['tmp_name'] ) ) {
        return new WP_Error( 'no_file', 'Choose an image to upload.', array( 'status' => 400 ) );
    }
    $f = $files['file'];
    $max_bytes = 4 * 1024 * 1024;
    if ( (int) $f['size'] > $max_bytes ) {
        return new WP_Error( 'too_big', 'The image must be 4 MB or smaller.', array( 'status' => 400 ) );
    }
    $mimes = array( 'png' => 'image/png', 'jpg|jpeg' => 'image/jpeg', 'webp' => 'image/webp' );
    $check = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], $mimes );
    if ( empty( $check['ext'] ) || empty( $check['type'] ) ) {
        return new WP_Error( 'bad_type', 'Upload a png, jpg or webp image.', array( 'status' => 400 ) );
    }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    $up = wp_handle_upload( $f, array( 'test_form' => false, 'mimes' => $mimes ) );
    if ( ! empty( $up['error'] ) || empty( $up['url'] ) ) {
        return new WP_Error( 'upload_failed', 'The image could not be saved. Please try again.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'variant' => $variant, 'url' => esc_url_raw( $up['url'] ) ) );
}

function ridego_app_admin_api_route_pages_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_pricing' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage route pages.', array( 'status' => 403 ) );
    }
    return true;
}

/**
 * Dashboard list — joins ridego_route_pages against ridego_routes for
 * origin/destination/state display data, with filters. quality_issues
 * is stored JSON (see ridego_create_route_page()/ridego_update_route_page())
 * so "has_quality_issues" is derived from it rather than re-running the
 * check here — the stored snapshot is always refreshed on every write.
 */
function ridego_app_admin_api_route_pages_list( WP_REST_Request $req ) {
    global $wpdb;
    $ptbl = ridego_route_pages_table();
    $rtbl = $wpdb->prefix . 'ridego_routes';
    $ctbl = $wpdb->prefix . 'ridego_cities';

    $where  = array( '1=1' );
    $params = array();

    $status = $req->get_param( 'status' );
    if ( $status !== null && $status !== '' ) {
        $where[]  = 'p.status = %s';
        $params[] = sanitize_text_field( $status );
    }
    $origin = $req->get_param( 'origin' );
    if ( $origin !== null && $origin !== '' ) {
        $where[]  = 'r.from_city LIKE %s';
        $params[] = '%' . $wpdb->esc_like( sanitize_text_field( $origin ) ) . '%';
    }
    $destination = $req->get_param( 'destination' );
    if ( $destination !== null && $destination !== '' ) {
        $where[]  = 'r.to_city LIKE %s';
        $params[] = '%' . $wpdb->esc_like( sanitize_text_field( $destination ) ) . '%';
    }
    $state = $req->get_param( 'state' );
    if ( $state !== null && $state !== '' ) {
        $where[]  = '(fc.state = %s OR tc.state = %s)';
        $params[] = sanitize_text_field( $state );
        $params[] = sanitize_text_field( $state );
    }

    $sql = "SELECT p.*, r.from_city, r.to_city, r.distance_km, r.duration_mins, r.is_popular, r.is_active AS route_is_active,
                   fc.state AS from_state, tc.state AS to_state
            FROM {$ptbl} p
            INNER JOIN {$rtbl} r ON r.id = p.route_id
            LEFT JOIN {$ctbl} fc ON fc.name = r.from_city
            LEFT JOIN {$ctbl} tc ON tc.name = r.to_city
            WHERE " . implode( ' AND ', $where ) . '
            ORDER BY r.is_popular DESC, p.created_at DESC';

    $rows = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );

    $has_quality_flag = $req->get_param( 'has_quality_issues' );

    $out = array();
    foreach ( (array) $rows as $r ) {
        $issues = json_decode( (string) $r->quality_issues, true );
        if ( ! is_array( $issues ) ) { $issues = array(); }
        if ( $has_quality_flag !== null && $has_quality_flag !== '' ) {
            $want = filter_var( $has_quality_flag, FILTER_VALIDATE_BOOLEAN );
            if ( $want !== ( count( $issues ) > 0 ) ) { continue; }
        }
        $out[] = array(
            'id'                => (int) $r->id,
            'route_id'          => (int) $r->route_id,
            'slug'              => $r->slug,
            'from_city'         => $r->from_city,
            'to_city'           => $r->to_city,
            'from_state'        => $r->from_state,
            'to_state'          => $r->to_state,
            'distance_km'       => (float) $r->distance_km,
            'duration_mins'     => (int) $r->duration_mins,
            'is_popular'        => (bool) $r->is_popular,
            // The underlying wp_ridego_routes row's own active/inactive toggle
            // (set on the separate "Routes" tab) — completely independent from
            // this page's publish status. A published page whose route is
            // inactive is hidden from Home Page "Popular Outstation Routes"
            // (see ridego_app_api_popular_routes()'s `r.is_active = 1`), so the
            // admin UI must surface it here rather than leaving a "Published"
            // page silently invisible with no explanation.
            'route_active'      => (bool) $r->route_is_active,
            'seo_title'         => $r->seo_title,
            'meta_description'  => $r->meta_description,
            'status'            => $r->status,
            'quality_issues'    => $issues,
            'has_quality_issues' => count( $issues ) > 0,
            'generated_by'      => (int) $r->generated_by,
            'published_at'      => $r->published_at,
            'created_at'        => $r->created_at,
            'updated_at'        => $r->updated_at,
            // Raw per-route hero override values (blank/null = "use global
            // default") for the edit UI's override section, plus the fully
            // resolved config actually used by the public page.
            'hero_mode'               => (string) $r->hero_mode,
            'hero_heading'            => (string) $r->hero_heading,
            'hero_subheading'         => (string) $r->hero_subheading,
            'hero_bg_color'           => (string) $r->hero_bg_color,
            'hero_image_desktop_url'  => (string) $r->hero_image_desktop_url,
            'hero_image_mobile_url'   => (string) $r->hero_image_mobile_url,
            'hero_height_desktop'     => (string) $r->hero_height_desktop,
            'hero_height_mobile'      => (string) $r->hero_height_mobile,
            'hero_overlay_enabled'    => ( $r->hero_overlay_enabled === null || $r->hero_overlay_enabled === '' ) ? null : (bool) (int) $r->hero_overlay_enabled,
            'hero_effective'          => ridego_route_page_effective_hero( $r ),
            // Separate from the hero_* fields above — this is the dedicated
            // Home Page route-card thumbnail image, not part of the hero banner.
            'card_image_url'          => (string) $r->card_image_url,
        );
    }

    return rest_ensure_response( array( 'rows' => $out, 'total' => count( $out ) ) );
}

/**
 * Eligible routes for the "Generate All Eligible" review UI — every
 * active route from ridego_route_page_eligible_routes(), excluding
 * routes that already have a page (has_page=true), so this endpoint
 * shows purely what CAN still be generated.
 */
function ridego_app_admin_api_route_pages_eligible( WP_REST_Request $req ) {
    $rows = ridego_route_page_eligible_routes();
    $rows = array_values( array_filter( $rows, function ( $r ) {
        return empty( $r['has_page'] );
    } ) );
    return rest_ensure_response( array( 'rows' => $rows, 'total' => count( $rows ) ) );
}

/**
 * Bulk generate — accepts route_ids (array of ints), delegates to
 * ridego_bulk_generate_route_pages( array $route_ids, $user_id ). One
 * failing route_id (e.g. already has a page) never blocks the rest.
 */
function ridego_app_admin_api_route_pages_generate( WP_REST_Request $req ) {
    $route_ids = $req->get_param( 'route_ids' );
    if ( ! is_array( $route_ids ) || ! $route_ids ) {
        return new WP_Error( 'invalid_input', 'route_ids must be a non-empty array.', array( 'status' => 400 ) );
    }
    $route_ids = array_values( array_unique( array_map( 'intval', $route_ids ) ) );
    $user_id   = get_current_user_id();
    $results   = ridego_bulk_generate_route_pages( $route_ids, $user_id );
    $created   = count( array_filter( $results, function ( $r ) { return ! empty( $r['success'] ); } ) );
    return rest_ensure_response( array(
        'success' => true,
        'created' => $created,
        'total'   => count( $results ),
        'results' => $results,
    ) );
}

/** Delegates to the canonical ridego_update_route_page( $id, $fields ). */
function ridego_app_admin_api_route_page_update( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    $fields = array();
    if ( $req->get_param( 'seo_title' ) !== null ) {
        $fields['seo_title'] = $req->get_param( 'seo_title' );
    }
    if ( $req->get_param( 'meta_description' ) !== null ) {
        $fields['meta_description'] = $req->get_param( 'meta_description' );
    }
    // "Clear override back to use global default" sends '' (or, for the
    // hero_overlay_enabled checkbox, an empty string too — never JSON null,
    // since a missing/null param here just means "don't touch this field").
    foreach ( array_keys( ridego_route_page_hero_fields() ) as $key ) {
        if ( $req->has_param( $key ) ) {
            $fields[ $key ] = $req->get_param( $key );
        }
    }
    $r = ridego_update_route_page( $id, $fields );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'Route page not found.' ? 404 : 400;
        return new WP_Error( 'update_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array(
        'success'        => true,
        'message'        => $r['message'],
        'quality_issues' => $r['quality_issues'],
    ) );
}

/**
 * Transitions status via ridego_set_route_page_status(). A rejected
 * publish attempt (quality gate failed) comes back as a 422 carrying
 * the real quality_issues list — never a generic 400 that hides why.
 */
function ridego_app_admin_api_route_page_status( WP_REST_Request $req ) {
    $id     = (int) $req->get_param( 'id' );
    $status = sanitize_text_field( (string) $req->get_param( 'status' ) );
    $r = ridego_set_route_page_status( $id, $status );
    if ( empty( $r['success'] ) ) {
        if ( $r['message'] === 'Route page not found.' ) {
            return new WP_Error( 'not_found', $r['message'], array( 'status' => 404 ) );
        }
        if ( ! empty( $r['quality_issues'] ) ) {
            return new WP_Error( 'quality_check_failed', $r['message'], array(
                'status'         => 422,
                'quality_issues' => $r['quality_issues'],
            ) );
        }
        return new WP_Error( 'invalid_input', $r['message'], array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_delete_route_page(). */
function ridego_app_admin_api_route_page_delete( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    $r  = ridego_delete_route_page( $id );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'Route page not found.' ? 404 : 500;
        return new WP_Error( 'delete_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'] ) );
}
