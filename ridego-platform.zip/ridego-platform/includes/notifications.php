<?php
/**
 * RideGo Platform - Notifications System
 * 
 * Handles all notification dispatching via multiple channels:
 * - WhatsApp (CallMeBot + Fonnte free tiers)
 * - Email (WordPress wp_mail + Brevo SMTP)
 * - Telegram (Bot API for admin alerts)
 * - SMS (Firebase Auth for OTP only - minimal usage)
 * 
 * Economy-First Design: Zero per-message cost in Phase 1
 * All notifications are queued and processed via WP Cron to avoid RAM spikes
 * 
 * @package RideGo
 * @subpackage Notifications
 * @version 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Fires whenever a booking reaches 'confirmed' status — either
 * immediately on creation (cash bookings) or after payment verification
 * (online/manual bookings). The fully-built 'booking_confirmed' email and
 * WhatsApp templates existed but nothing ever actually dispatched them;
 * ridego_distribute_leads() (includes/lead.php) is hooked to this same
 * action but only handles vendor lead distribution, not customer
 * notification. This is the missing customer-facing half.
 *
 * Matches the existing convention used throughout this file (see e.g.
 * ridego_submit_payment_proof() in includes/payment.php): passing a
 * guest booking's client_id=0 here is a known, pre-existing limitation of
 * the whole user-id-keyed notification system, not something new to this
 * fix — a guest simply doesn't get an account-based notification today,
 * consistent with every other client-notification call site in this
 * codebase.
 */
// TRACE: payload amount that may be a float, a numeric string or an already-formatted money string ("₹3,612.00") → float. Pure.
//        Edge cases: null/empty → 0.0; currency symbol, thousands separators and spaces are stripped; a leading minus is kept.
function ridego_notif_amount( $v ) {
    if ( is_int( $v ) || is_float( $v ) ) { return (float) $v; }
    $clean = preg_replace( '/[^0-9.\-]/', '', (string) $v );
    return is_numeric( $clean ) ? (float) $clean : 0.0;
}

add_action('ridego_booking_confirmed', 'ridego_notify_booking_confirmed');
function ridego_notify_booking_confirmed( $booking_id ) {
    $booking = ridego_get_booking( $booking_id );
    if ( ! $booking ) return;

    if ( (int) $booking->client_id > 0 ) {
        ridego_send_notification( $booking->client_id, 'booking_confirmed', array(
            'booking_number' => $booking->booking_number,
            'pickup_city'    => $booking->pickup_city,
            'drop_city'      => $booking->drop_city,
            'journey_date'   => ridego_format_date( $booking->journey_date ),
            'journey_time'   => $booking->journey_time,
            'vehicle_type'   => isset( $booking->vehicle_name ) ? $booking->vehicle_name : '',
            'total_fare'     => (float) $booking->total_fare, // ridego_email_booking_confirmed() applies its own number_format()
            'payment_method' => $booking->payment_method,
            // ROOT-CAUSE FIX: this used to hardcode '/booking-confirm/',
            // the legacy shortcode page's URL, bypassing both
            // ridego_page_url() and the ridego_app_route_for_legacy_
            // page_key filter entirely — every booking-confirmed
            // notification (email/WhatsApp/SMS) sent a link to the
            // old page even after the React app fully replaced it.
            // Now points at the real, current confirmation screen.
            'booking_link'   => home_url( '/confirm/?booking=' . $booking->booking_number ),
        ) );
    }

    // Admin "new booking" alert — the Telegram message content already
    // exists in ridego_build_telegram_message()'s 'new_booking' case but
    // was likewise never actually triggered for a plain confirmed
    // booking (only the lead-distribution and no-vendor paths alert
    // admin today).
    ridego_send_notification( 0, 'new_booking', array(
        'recipient_type' => 'admin',
        'booking_number' => $booking->booking_number,
        'trip_type'      => $booking->trip_type,
        'pickup_city'    => $booking->pickup_city,
        'drop_city'      => $booking->drop_city,
        'journey_date'   => ridego_format_date( $booking->journey_date ),
        'journey_time'   => $booking->journey_time,
        'vehicle_type'   => isset( $booking->vehicle_name ) ? $booking->vehicle_name : '',
        'passengers'     => (int) $booking->passengers,
        'total_fare'     => (float) $booking->total_fare,
        'payment_method' => $booking->payment_method,
        'priority'       => 'normal',
    ) );
}

/**
 * Main notification dispatcher - routes to appropriate channel
 * Implements free-first strategy: WhatsApp → Email → SMS (OTP only)
 * 
 * @param int    $user_id     User ID (client, vendor, or admin)
 * @param string $event       Notification event type
 * @param array  $data        Event data payload
 * @param int    $delay       Delay in seconds before sending (for scheduling)
 * @return bool Success status
 */
function ridego_send_notification($user_id, $event, $data = array(), $delay = 0) {

    // Validate inputs
    if (empty($user_id) || empty($event)) {
        ridego_log_notification(0, $event, 'unknown', 'Notification could not be sent: invalid user or event.', false);
        return false;
    }

    // If delay specified, queue for later processing
    // Pass numeric $user_id as first arg; the canonical dual-signature function in lead.php
    // detects the non-array first argument and converts automatically.
    if ($delay > 0) {
        return ridego_queue_notification($user_id, $event, $data, $delay);
    }

    // Get user details
    $user_data = ridego_get_user_notification_details($user_id);
    if (!$user_data) {
        ridego_log_notification($user_id, $event, 'unknown', 'Notification could not be sent: user not found.', false);
        return false;
    }

    $channels_tried = array();
    $success = false;

    // Route 1: ADMIN EVENTS → Telegram Bot (free, instant, reliable)
    if (isset($data['recipient_type']) && $data['recipient_type'] === 'admin') {
        $message = ridego_build_telegram_message($event, $data);
        $priority = isset($data['priority']) ? $data['priority'] : 'normal';
        ridego_telegram_alert($message, $priority);
        ridego_log_notification($user_id, $event, 'telegram', ridego_notification_human_message($event, $data), true);
        return true;
    }
    
    // Route 2: CLIENT & VENDOR → WhatsApp (free via CallMeBot/Fonnte)
    $whatsapp_number = $user_data['whatsapp'] ?? $user_data['phone'] ?? null;
    if ($whatsapp_number && ridego_event_needs_whatsapp($event)) {
        
        $message = ridego_build_whatsapp_message($event, $data, $user_data);
        
        // Try Fonnte first (own number, more professional, 1000/month free)
        if (get_option('ridego_fonnte_enabled') && get_option('ridego_fonnte_token')) {
            $success = ridego_whatsapp_fonnte($whatsapp_number, $message);
            $channels_tried[] = 'fonnte';
        }
        
        // Fallback to CallMeBot if Fonnte fails (unlimited but from their number)
        if (!$success && get_option('ridego_callmebot_enabled') && get_option('ridego_callmebot_key')) {
            $success = ridego_whatsapp_callmebot($whatsapp_number, $message);
            $channels_tried[] = 'callmebot';
        }
    }
    
    // Route 3: EMAIL (always send for important events - free via wp_mail)
    if ($user_data['email'] && ridego_event_needs_email($event)) {
        $email_sent = ridego_send_email_notification($user_data['email'], $event, $data, $user_data);
        $channels_tried[] = 'email';
        $success = $success || $email_sent;
    }
    
    // Route 4: SMS - ONLY for OTP (Firebase free 10K/month)
    if ($event === 'otp_request' && isset($data['otp']) && isset($data['phone'])) {
        $sms_sent = ridego_send_otp_sms($data['phone'], $data['otp']);
        $channels_tried[] = 'sms_otp';
        $success = $success || $sms_sent;
    }
    
    // Log the notification attempt
    ridego_log_notification(
        $user_id,
        $event,
        $channels_tried ? implode(',', $channels_tried) : 'none',
        ridego_notification_human_message($event, $data),
        $success
    );

    return $success;
}

/**
 * Queue notification for delayed sending via WP Cron.
 * NOTE: canonical definition (dual-signature) is in includes/lead.php, loaded earlier.
 * This guard prevents "Cannot redeclare" fatal error.
 */
if ( ! function_exists('ridego_queue_notification') ) :
function ridego_queue_notification($user_id, $event, $data, $delay = 0) {
    global $wpdb;

    $table = $wpdb->prefix . 'ridego_notification_queue';

    $inserted = $wpdb->insert($table, array(
        'recipient_id'   => absint($user_id),
        'event'          => sanitize_text_field($event),
        'payload'        => wp_json_encode($data),
        'scheduled_for'  => date('Y-m-d H:i:s', time() + absint($delay)),
        'status'         => 'pending',
        'created_at'     => current_time('mysql'),
    ), array('%d', '%s', '%s', '%s', '%s', '%s'));

    // See the matching comment on the canonical ridego_queue_notification()
    // in includes/lead.php: flag immediately-due items so the shutdown hook
    // flushes them this request instead of waiting on WP-Cron.
    if ( $inserted !== false && absint( $delay ) === 0 ) {
        $GLOBALS['ridego_notification_queued_this_request'] = true;
    }

    return $inserted !== false;
}
endif; // function_exists ridego_queue_notification

/**
 * Process queued notifications - called by WP Cron every 5 minutes
 * Processes max 20 notifications per run to avoid RAM spikes
 */
/**
 * Exponential backoff schedule (minutes) keyed by attempt number
 * (1-indexed: the delay applied AFTER that attempt fails).
 * attempt 1 -> retry in 5 min, 2 -> 20 min, 3 -> 60 min,
 * 4/5+ -> 60 min again (capped) before hitting RIDEGO_NOTIF_MAX_ATTEMPTS
 * and going to dead_letter.
 */
function ridego_notification_backoff_minutes( $attempt ) {
    $schedule = array( 1 => 5, 2 => 20, 3 => 60 );
    if ( isset( $schedule[ $attempt ] ) ) {
        return $schedule[ $attempt ];
    }
    return 60;
}

define( 'RIDEGO_NOTIF_MAX_ATTEMPTS', 5 );

function ridego_process_notification_queue() {
    global $wpdb;

    $table = $wpdb->prefix . 'ridego_notification_queue';

    // Fetch pending notifications ready to send (max 20 per run).
    // Only rows whose retry backoff has elapsed (or which have never
    // failed) are picked up.
    $items = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table}
         WHERE status = %s
         AND scheduled_for <= NOW()
         AND (next_retry_at IS NULL OR next_retry_at <= NOW())
         ORDER BY priority DESC, created_at ASC
         LIMIT 20",
        'pending'
    ));

    if (empty($items)) {
        return;
    }

    foreach ($items as $item) {

        $data = json_decode($item->payload, true);
        if (!is_array($data)) {
            $data = array();
        }

        // Send the notification. recipient_id is the real column
        // (the queue table has no user_id column at all).
        $sent = ridego_send_notification($item->recipient_id, $item->event, $data);

        $attempts = (int) $item->attempts + 1;

        if ( $sent ) {
            $wpdb->update($table,
                array(
                    'status'   => 'sent',
                    'sent_at'  => current_time('mysql'),
                    'attempts' => $attempts,
                    'next_retry_at' => null,
                ),
                array('id' => $item->id),
                array('%s', '%s', '%d', '%s'),
                array('%d')
            );
        } elseif ( $attempts >= RIDEGO_NOTIF_MAX_ATTEMPTS ) {
            // Exhausted retries — park it for manual review instead of
            // silently deleting it.
            $wpdb->update($table,
                array(
                    'status'   => 'dead_letter',
                    'attempts' => $attempts,
                    'error_msg'=> 'Max retry attempts exceeded',
                ),
                array('id' => $item->id),
                array('%s', '%d', '%s'),
                array('%d')
            );
        } else {
            $delay_min = ridego_notification_backoff_minutes( $attempts );
            $next_retry = date('Y-m-d H:i:s', time() + ($delay_min * 60));
            $wpdb->update($table,
                array(
                    'status'        => 'pending',
                    'attempts'      => $attempts,
                    'next_retry_at' => $next_retry,
                    'error_msg'     => 'Send failed, retry #' . $attempts . ' scheduled',
                ),
                array('id' => $item->id),
                array('%s', '%d', '%s', '%s'),
                array('%d')
            );
        }

        // Small delay between messages to avoid API hammering
        usleep(200000); // 200ms
    }

    // Cleanup: Delete successfully sent notifications older than 7 days
    $wpdb->query($wpdb->prepare(
        "DELETE FROM {$table}
         WHERE status = %s
         AND sent_at < DATE_SUB(NOW(), INTERVAL 7 DAY)",
        'sent'
    ));

    // dead_letter rows are NOT auto-deleted — they need a human decision
    // (Retry now / Discard) from the admin Notifications page.
}

// ============================================================================
// WHATSAPP - CALLMEBOT API (FREE - UNLIMITED)
// ============================================================================

/**
 * Send WhatsApp message via CallMeBot free API
 * Messages appear from CallMeBot's number (limitation of free tier)
 * 
 * @param string $phone   Phone number with country code
 * @param string $message Message text
 * @return bool Success
 */
function ridego_whatsapp_callmebot($phone, $message) {
    
    $api_key = get_option('ridego_callmebot_key');
    
    if (empty($api_key)) {
        ridego_log('CallMeBot: API key not configured');
        return false;
    }
    
    // Clean phone number (remove spaces, dashes)
    $phone = preg_replace('/[^0-9+]/', '', $phone);
    
    // Ensure country code prefix
    if (substr($phone, 0, 1) !== '+') {
        $phone = '+91' . $phone; // Default India
    }
    
    // Build API URL
    $url = add_query_arg(array(
        'phone'  => urlencode($phone),
        'text'   => urlencode($message),
        'apikey' => $api_key
    ), 'https://api.callmebot.com/whatsapp.php');
    
    // Send request (10 second timeout)
    $response = wp_remote_get($url, array(
        'timeout' => 10,
        'headers' => array(
            'User-Agent' => 'RideGo/1.0'
        )
    ));
    
    // Check for errors
    if (is_wp_error($response)) {
        ridego_log('CallMeBot error: ' . $response->get_error_message());
        return false;
    }
    
    $body = wp_remote_retrieve_body($response);
    $code = wp_remote_retrieve_response_code($response);
    
    // CallMeBot returns 200 on success
    if ($code === 200) {
        ridego_log("CallMeBot success: {$phone}");
        return true;
    }
    
    ridego_log("CallMeBot failed: HTTP {$code} - {$body}");
    return false;
}

// ============================================================================
// WHATSAPP - FONNTE API (1000 FREE/MONTH)
// ============================================================================

/**
 * Send WhatsApp via Fonnte API (messages from your own business number)
 * Free tier: 1000 messages/month
 * 
 * @param string $phone   Phone number
 * @param string $message Message text
 * @return bool Success
 */
function ridego_whatsapp_fonnte($phone, $message) {
    
    $token = get_option('ridego_fonnte_token');
    
    if (empty($token)) {
        ridego_log('Fonnte: Token not configured');
        return false;
    }
    
    // Clean phone number
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // Fonnte expects phone without + prefix
    if (strlen($phone) === 10) {
        $phone = '91' . $phone; // Add country code for India
    }
    
    // Build request payload
    $payload = array(
        'target'  => $phone,
        'message' => $message,
        'countryCode' => '91' // India
    );
    
    // Send POST request
    $response = wp_remote_post('https://api.fonnte.com/send', array(
        'headers' => array(
            'Authorization' => $token,
            'Content-Type'  => 'application/json',
        ),
        'body'    => wp_json_encode($payload),
        'timeout' => 15,
    ));
    
    if (is_wp_error($response)) {
        ridego_log('Fonnte error: ' . $response->get_error_message());
        return false;
    }
    
    $body = json_decode(wp_remote_retrieve_body($response), true);
    $code = wp_remote_retrieve_response_code($response);
    
    // Fonnte returns 200 with status in body
    if ($code === 200 && isset($body['status']) && $body['status'] === true) {
        ridego_log("Fonnte success: {$phone}");
        return true;
    }
    
    ridego_log("Fonnte failed: " . wp_json_encode($body));
    return false;
}

// ============================================================================
// TELEGRAM BOT - ADMIN ALERTS (FREE - UNLIMITED)
// ============================================================================

/**
 * Send alert to admin Telegram group
 * Completely free with no limits - perfect for internal admin notifications
 * 
 * @param string $message  Message text (supports HTML formatting)
 * @param string $priority Priority level: normal, high, urgent
 * @return bool Success
 */
function ridego_telegram_alert($message, $priority = 'normal') {
    
    $bot_token = get_option('ridego_telegram_bot_token');
    $chat_id   = get_option('ridego_telegram_chat_id');
    
    if (empty($bot_token) || empty($chat_id)) {
        // Silently skip if Telegram not configured (optional feature)
        return false;
    }
    
    // Add priority prefix with emoji
    $prefix = '';
    switch ($priority) {
        case 'urgent':
            $prefix = "🚨 <b>URGENT ALERT</b>\n";
            break;
        case 'high':
            $prefix = "⚠️ <b>HIGH PRIORITY</b>\n";
            break;
        default:
            $prefix = '';
    }
    
    $full_message = $prefix . $message;
    
    // Send via Telegram Bot API
    $response = wp_remote_post(
        "https://api.telegram.org/bot{$bot_token}/sendMessage",
        array(
            'body' => array(
                'chat_id'    => $chat_id,
                'text'       => $full_message,
                'parse_mode' => 'HTML',
            ),
            'timeout' => 10,
        )
    );
    
    if (is_wp_error($response)) {
        ridego_log('Telegram error: ' . $response->get_error_message());
        return false;
    }
    
    $body = json_decode(wp_remote_retrieve_body($response), true);
    
    if (isset($body['ok']) && $body['ok'] === true) {
        return true;
    }
    
    ridego_log('Telegram failed: ' . wp_json_encode($body));
    return false;
}

// ============================================================================
// EMAIL - WORDPRESS WP_MAIL + HTML TEMPLATES
// ============================================================================

/**
 * Send email notification using WordPress wp_mail with HTML templates
 * Uses wp_mail (free) with optional Brevo SMTP for better deliverability
 * 
 * @param string $to_email   Recipient email
 * @param string $event      Event type
 * @param array  $data       Event data
 * @param array  $user_data  User details
 * @return bool Success
 */
function ridego_send_email_notification($to_email, $event, $data, $user_data) {
    
    if (!is_email($to_email)) {
        return false;
    }
    
    // Get email template
    $template = ridego_get_email_template($event, $data, $user_data);
    
    if (!$template) {
        ridego_log("Email template not found for event: {$event}");
        return false;
    }
    
    // Email headers (HTML format)
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . ridego_brand( 'email_from_name' ) . ' <' . ridego_brand( 'email_from_address' ) . '>'
    );
    
    // Add CC for admin on certain events
    if (in_array($event, array('payment_proof_submitted', 'booking_created'))) {
        $admin_email = get_option('ridego_admin_notification_email');
        if ($admin_email && is_email($admin_email)) {
            $headers[] = 'Cc: ' . $admin_email;
        }
    }
    
    // Send email
    $sent = wp_mail($to_email, $template['subject'], $template['body'], $headers);
    
    if ($sent) {
        ridego_log("Email sent to {$to_email} for event {$event}");
    } else {
        ridego_log("Email failed to {$to_email} for event {$event}");
    }
    
    return $sent;
}

/**
 * Get HTML email template for event
 * 
 * @param string $event Event type
 * @param array  $data  Event data
 * @param array  $user  User data
 * @return array|bool Array with 'subject' and 'body' or false
 */
function ridego_get_email_template($event, $data, $user) {
    
    // Load base template wrapper
    $header = ridego_get_email_header();
    $footer = ridego_get_email_footer();
    
    $subject = '';
    $content = '';
    
    // Generate content based on event type
    switch ($event) {
        
        case 'booking_confirmed':
            $subject = 'Booking Confirmed - ' . $data['booking_number'];
            $content = ridego_email_booking_confirmed($data, $user);
            break;
            
        case 'payment_proof_submitted':
            $subject = 'Payment Proof Received - ' . $data['booking_number'];
            $content = ridego_email_payment_proof_received($data, $user);
            break;
            
        case 'payment_verified':
            $subject = 'Booking Amount Received - Booking Confirmed!';
            $content = ridego_email_payment_verified($data, $user);
            break;
            
        case 'payment_reminder':
            $subject = 'Booking Amount Reminder - ' . $data['booking_number'];
            $content = ridego_email_simple_notice( $user, 'Booking amount reminder', 'Your booking ' . $data['booking_number'] . ' is waiting for the booking amount of ₹' . number_format( (float) ( $data['amount'] ?? 0 ), 2 ) . ' payable to ' . ridego_brand_name() . '. Please pay it to confirm your ride. The remaining ride fare is paid directly to your vendor/driver.' );
            break;

        case 'booking_updated':
            $subject = 'Trip Updated - ' . $data['booking_number'];
            $content = ridego_email_simple_notice( $user, 'Your trip was updated', (string) ( $data['message'] ?? 'Your trip details were updated.' ) );
            break;

        case 'payment_receipt':
            $subject = 'Booking Amount Received - ' . $data['booking_number'];
            $content = ridego_email_simple_notice( $user, 'Booking amount received', ridego_brand_name() . ' received your booking amount of ₹' . number_format( (float) ( $data['amount'] ?? 0 ), 2 ) . ' for booking ' . $data['booking_number'] . '. The remaining ride amount of ₹' . number_format( (float) ( $data['balance'] ?? 0 ), 2 ) . ' is payable directly to your vendor/driver, who will bill you for the ride.' );
            break;

        case 'vendor_collection_recorded':
            $subject = 'Ride Payment Recorded - ' . $data['booking_number'];
            $content = ridego_email_simple_notice( $user, 'Ride payment recorded', 'Your vendor/driver recorded ₹' . number_format( (float) ( $data['amount'] ?? 0 ), 2 ) . ' collected directly from you for booking ' . $data['booking_number'] . '. Remaining payable to the vendor/driver: ₹' . number_format( (float) ( $data['balance'] ?? 0 ), 2 ) . '. If this is wrong, please contact support.' );
            break;

        case 'refund_processed':
            $subject = 'Booking Amount Refund Processed - ' . $data['booking_number'];
            $content = ridego_email_simple_notice( $user, 'Refund processed', 'A refund of ₹' . number_format( (float) ( $data['amount'] ?? 0 ), 2 ) . ' of your booking amount for ' . $data['booking_number'] . ' has been processed.' );
            break;

        case 'lead_reminder':
            $subject = 'Reminder - ' . $data['booking_number'];
            $content = ridego_email_simple_notice( $user, 'Lead reminder', ( ( $data['kind'] ?? '' ) === 'driver' ? 'Please confirm driver and vehicle details for booking ' : 'Please respond to the ride request for booking ' ) . $data['booking_number'] . '.' );
            break;

        case 'driver_assigned':
            $subject = 'Driver Assigned - ' . $data['booking_number'];
            $content = ridego_email_driver_assigned($data, $user);
            break;
            
        case 'trip_completed':
            $subject = 'Trip Completed - Thank You!';
            $content = ridego_email_trip_completed($data, $user);
            break;
            
        case 'booking_cancelled':
            $subject = 'Booking Cancelled - ' . $data['booking_number'];
            $content = ridego_email_booking_cancelled($data, $user);
            break;
            
        case 'otp_request':
            $subject = 'Your ' . ridego_brand_name() . ' OTP Verification Code';
            $content = ridego_email_otp($data, $user);
            break;
            
        case 'vendor_kyc_approved':
            $subject = 'KYC Approved - Welcome to ' . ridego_brand_name() . '!';
            $content = ridego_email_vendor_kyc_approved($data, $user);
            break;
            
        case 'vendor_new_lead':
            $subject = 'New Booking Lead Available!';
            $content = ridego_email_vendor_new_lead($data, $user);
            break;
            
        case 'vendor_wallet_low':
            $subject = 'Wallet Balance Low - Top Up Required';
            $content = ridego_email_vendor_wallet_low($data, $user);
            break;

        case 'payment_proof_rejected':
            $subject = 'Payment Proof Rejected - ' . ( $data['booking_number'] ?? '' );
            $content = '<h1 style="color:#DC3545;">⚠️ Payment Proof Rejected</h1>'
                . '<p>Hi ' . esc_html($user['name']) . ', the payment proof you submitted for booking <strong>' . esc_html($data['booking_number'] ?? '') . '</strong> could not be verified.</p>'
                . '<p><strong>Reason:</strong> ' . nl2br(esc_html($data['reason'] ?? 'Not specified')) . '</p>'
                . '<p>Please resubmit a clear payment screenshot or receipt to confirm your booking: <a href="' . esc_url($data['resubmit_link'] ?? '#') . '">Resubmit payment proof</a></p>';
            break;

        case 'payment_failed':
            $subject = 'Payment Failed - ' . ( $data['booking_number'] ?? '' );
            $content = '<h1 style="color:#DC3545;">❌ Payment Failed</h1>'
                . '<p>Hi ' . esc_html($user['name']) . ', your online payment for booking <strong>' . esc_html($data['booking_number'] ?? '') . '</strong> did not go through.</p>'
                . '<p>Your booking is still held — please retry payment to confirm it: <a href="' . esc_url($data['retry_link'] ?? '#') . '">Retry payment</a></p>';
            break;

        case 'refund_processed':
            $subject = 'Refund Processed - ' . ( $data['booking_number'] ?? '' );
            $amount_line = isset($data['refund_amount']) ? ('<p><strong>Amount:</strong> ' . ridego_currency_symbol() . number_format((float) $data['refund_amount'], 2) . '</p>') : '';
            $content = '<h1 style="color:#28A745;">✅ Refund Processed</h1>'
                . '<p>Hi ' . esc_html($user['name']) . ', your refund for booking <strong>' . esc_html($data['booking_number'] ?? '') . '</strong> has been processed.</p>'
                . $amount_line
                . '<p>It should reflect in your original payment method within 5-7 business days.</p>';
            break;

        case 'refund_initiated':
            $subject = 'Refund Initiated - ' . ( $data['booking_number'] ?? '' );
            $amount_line = isset($data['refund_amount']) ? ('<p><strong>Amount:</strong> ' . ridego_currency_symbol() . number_format((float) $data['refund_amount'], 2) . '</p>') : '';
            $content = '<h1 style="color:#2E75B6;">Refund Initiated</h1>'
                . '<p>Hi ' . esc_html($user['name']) . ', a refund has been initiated for booking <strong>' . esc_html($data['booking_number'] ?? '') . '</strong>.</p>'
                . $amount_line
                . '<p>Expected in ' . esc_html($data['refund_days'] ?? '5-7') . ' business days.</p>'
                . ( !empty($data['reason']) ? '<p><strong>Reason:</strong> ' . esc_html($data['reason']) . '</p>' : '' );
            break;

        case 'vendor_wallet_credited':
            $subject = 'Wallet Credited - ' . ridego_currency_symbol() . number_format((float) ($data['amount'] ?? 0), 2);
            $content = '<h1 style="color:#28A745;">Wallet Credited</h1>'
                . '<p>Hi ' . esc_html($user['name']) . ', your ' . esc_html( ridego_brand_name() ) . ' wallet has been credited <strong>' . ridego_currency_symbol() . number_format((float) ($data['amount'] ?? 0), 2) . '</strong>.</p>'
                . '<p>New balance: <strong>' . ridego_currency_symbol() . number_format((float) ($data['new_balance'] ?? 0), 2) . '</strong></p>';
            break;

        case 'admin_broadcast':
        case 'admin_note':
            $subject = isset($data['title']) ? $data['title'] : ridego_brand_name() . ' Notification';
            $content = '<h1 style="color:#2E75B6;">'.esc_html($subject).'</h1><p style="font-size:16px;color:#333;">Hi '.esc_html($user['name']).',</p><p>'.nl2br(esc_html(isset($data['body']) ? $data['body'] : '')).'</p>';
            break;

        case 'subscription_activated':
            $subject = 'Subscription Activated - ' . ( $data['plan_name'] ?? '' );
            $content = '<h1 style="color:#28A745;">✅ Subscription Activated</h1><p>Hi '.esc_html($user['name']).', your <strong>'.esc_html($data['plan_name'] ?? '').'</strong> subscription is now active until '.esc_html($data['expires'] ?? '').'.</p>';
            break;

        case 'subscription_payment_required':
            $subject = 'Action Needed: Subscription Payment Failed';
            $content = '<h1 style="color:#DC3545;">⚠️ Payment Required</h1><p>Hi '.esc_html($user['name']).', we could not auto-renew your subscription (attempt '.esc_html($data['attempt'] ?? '').' of 3). Please top up your wallet or pay manually before the grace period ends.</p>';
            break;

        case 'subscription_expired':
            $subject = 'Subscription Expired';
            $content = '<h1 style="color:#DC3545;">❌ Subscription Expired</h1><p>Hi '.esc_html($user['name']).', your subscription has expired and perks have been removed. Resubscribe any time from your dashboard.</p>';
            break;

        case 'vendor_interest_received':
        case 'driver_vehicle_confirmed':
        case 'driver_vehicle_replaced':
        case 'lead_lost_to_other_vendor':
        case 'lead_response_reminder':
        case 'driver_details_requested':
        case 'commission_charged':
        case 'impersonation_started':
        case 'impersonation_ended':
            $subject = ridego_brand_name() . ': ' . ucwords( str_replace( '_', ' ', $event ) ) . ( ! empty( $data['booking_number'] ) ? ' - ' . $data['booking_number'] : '' );
            $content = '<h1 style="color:#2E75B6;">' . esc_html( $subject ) . '</h1><p>Hi ' . esc_html( $user['name'] ) . ',</p><p>' . esc_html( ridego_notification_human_message( $event, $data ) ) . '</p>';
            break;

        default:
            return false;
    }
    
    // Wrap content in template
    $body = $header . $content . $footer;
    
    return array(
        'subject' => $subject,
        'body'    => $body
    );
}

/**
 * Email template: Booking Confirmed
 */
function ridego_email_booking_confirmed($data, $user) {
    ob_start();
    ?>
    <h1 style="color: #2E75B6; margin-bottom: 10px;">✅ Booking Confirmed!</h1>
    <p style="font-size: 16px; color: #333;">Hi <?php echo esc_html($user['name']); ?>,</p>
    <p>Your cab booking has been confirmed. Here are your trip details:</p>
    
    <table style="width: 100%; border-collapse: collapse; margin: 20px 0; background: #f9f9f9; border-radius: 8px;">
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><strong>Booking Number:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #ddd; color: #2E75B6; font-weight: bold;"><?php echo esc_html($data['booking_number']); ?></td>
        </tr>
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><strong>Journey Date:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><?php echo esc_html($data['journey_date']); ?> at <?php echo esc_html($data['journey_time']); ?></td>
        </tr>
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><strong>Route:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><?php echo esc_html($data['pickup_city']); ?> → <?php echo esc_html($data['drop_city']); ?></td>
        </tr>
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><strong>Vehicle Type:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><?php echo esc_html($data['vehicle_type']); ?></td>
        </tr>
        <tr>
            <td style="padding: 15px;"><strong>Estimated ride fare (payable to your vendor/driver):</strong></td>
            <td style="padding: 15px; font-size: 20px; color: #2E75B6; font-weight: bold;">₹<?php echo number_format(ridego_notif_amount($data['total_fare']), 2); ?></td>
        </tr>
    </table>
    
    <?php if (isset($data['payment_status']) && $data['payment_status'] === 'pending'): ?>
    <div style="background: #FFF3CD; border-left: 4px solid #FFC107; padding: 15px; margin: 20px 0;">
        <strong>⚠️ Booking amount pending</strong><br>
        Please pay the booking amount to confirm the booking. <a href="<?php echo esc_url($data['payment_link']); ?>" style="color: #2E75B6;">Pay Now →</a>
    </div>
    <?php endif; ?>
    
    <p style="margin-top: 30px;">
        <a href="<?php echo esc_url($data['booking_link']); ?>" style="display: inline-block; background: #2E75B6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold;">View Booking Details</a>
    </p>
    
    <p style="color: #666; font-size: 14px; margin-top: 30px;">
        You will receive driver details 24 hours before your journey.<br>
        For any assistance, contact us at <?php echo esc_html( ridego_brand( 'support_phone' ) ); ?>
    </p>
    <?php
    return ob_get_clean();
}

/**
 * Email template: Payment Proof Received
 */
function ridego_email_payment_proof_received($data, $user) {
    ob_start();
    ?>
    <h1 style="color: #2E75B6;">💳 Payment Proof Received</h1>
    <p style="font-size: 16px; color: #333;">Hi <?php echo esc_html($user['name']); ?>,</p>
    <p>We have received your payment proof for booking <strong><?php echo esc_html($data['booking_number']); ?></strong>.</p>
    
    <div style="background: #E7F3FF; border-left: 4px solid #2E75B6; padding: 15px; margin: 20px 0;">
        <strong>📋 Payment Details Submitted:</strong><br>
        Amount: ₹<?php echo number_format($data['amount'], 2); ?><br>
        UTR/Reference: <?php echo esc_html($data['utr'] ?? 'N/A'); ?><br>
        Payment Method: <?php echo esc_html($data['payment_app'] ?? 'Bank Transfer'); ?>
    </div>
    
    <p>Our team will verify your payment within <strong>30 minutes</strong> during business hours.</p>
    <p>Once verified, your booking will be confirmed and you will receive driver details 24 hours before your journey.</p>
    
    <p style="color: #666; font-size: 14px; margin-top: 30px;">
        <strong>Need urgent help?</strong><br>
        Call: <?php echo esc_html( ridego_brand( 'support_phone' ) ); ?><br>
        WhatsApp: <?php echo esc_html(get_option('ridego_support_whatsapp', '+91-XXXXXXXXXX')); ?>
    </p>
    <?php
    return ob_get_clean();
}

// TRACE: reminder events → simple HTML body with heading and message → string. Pure. Edge: user name missing → empty.
function ridego_email_simple_notice( $user, $heading, $message ) {
    return '<h1 style="color:#0F172A;">' . esc_html( $heading ) . '</h1><p style="font-size:16px;color:#333;">Hi ' . esc_html( $user['name'] ?? '' ) . ',</p><p>' . esc_html( $message ) . '</p>';
}

/**
 * Email template: Payment Verified
 */
function ridego_email_payment_verified($data, $user) {
    ob_start();
    ?>
    <h1 style="color: #28A745;">✅ Booking Amount Received - Booking Confirmed!</h1>
    <p style="font-size: 16px; color: #333;">Hi <?php echo esc_html($user['name']); ?>,</p>
    <p>Great news! Your booking amount has been verified and your booking is now <strong style="color: #28A745;">CONFIRMED</strong>.</p>
    
    <div style="background: #D4EDDA; border-left: 4px solid #28A745; padding: 15px; margin: 20px 0;">
        <strong>✅ Booking amount received</strong><br>
        Booking: <?php echo esc_html($data['booking_number']); ?><br>
        Booking amount paid to <?php echo esc_html( ridego_brand_name() ); ?>: ₹<?php echo number_format($data['amount'], 2); ?><br>
        Status: <strong style="color: #28A745;">CONFIRMED</strong>
    </div>
    
    <p><strong>What happens next?</strong></p>
    <ul style="line-height: 1.8;">
        <li>The remaining ride fare is paid directly to your vendor/driver, who bills you for the ride</li>
        <li>You will receive driver details 24 hours before your journey</li>
        <li>Driver will contact you 2 hours before pickup</li>
        <li>Track your cab live on the day of travel</li>
    </ul>
    
    <p style="margin-top: 30px;">
        <a href="<?php echo esc_url($data['booking_link']); ?>" style="display: inline-block; background: #28A745; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold;">View Trip Details</a>
    </p>
    <?php
    return ob_get_clean();
}

/**
 * Email template: Driver Assigned
 */
// TRACE: driver_assigned email → renders driver, vehicle and OTP; phone is a tel: link only when it looks like a number, otherwise plain text ('shared once your trip starts') → HTML string.
//        Preconditions: data keys present → Postconditions: pure render → Edge cases: non-numeric phone.
function ridego_email_driver_assigned($data, $user) {
    ob_start();
    ?>
    <h1 style="color: #2E75B6;">🚖 Driver Assigned!</h1>
    <p style="font-size: 16px; color: #333;">Hi <?php echo esc_html($user['name']); ?>,</p>
    <p>Your driver has been assigned for booking <strong><?php echo esc_html($data['booking_number']); ?></strong>.</p>
    
    <table style="width: 100%; border-collapse: collapse; margin: 20px 0; background: #f9f9f9; border-radius: 8px;">
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><strong>Driver Name:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><?php echo esc_html($data['driver_name']); ?></td>
        </tr>
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><strong>Contact Number:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><?php if ( preg_match( '/^[+0-9 ]{7,}$/', (string) $data['driver_phone'] ) ) : ?><a href="tel:<?php echo esc_attr($data['driver_phone']); ?>" style="color: #2E75B6; font-weight: bold;"><?php echo esc_html($data['driver_phone']); ?></a><?php else : echo esc_html($data['driver_phone']); endif; ?></td>
        </tr>
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><strong>Vehicle:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><?php echo esc_html($data['vehicle_model']); ?> (<?php echo esc_html($data['vehicle_number']); ?>)</td>
        </tr>
        <tr>
            <td style="padding: 15px;"><strong>Pickup OTP:</strong></td>
            <td style="padding: 15px; font-size: 24px; color: #2E75B6; font-weight: bold; letter-spacing: 3px;"><?php echo esc_html($data['otp']); ?></td>
        </tr>
    </table>
    
    <div style="background: #FFF3CD; border-left: 4px solid #FFC107; padding: 15px; margin: 20px 0;">
        <strong>🔐 Security Note:</strong><br>
        Share the OTP with the driver ONLY when you board the vehicle. This ensures you get into the right cab.
    </div>
    
    <p style="margin-top: 30px;">
        <a href="<?php echo esc_url($data['tracking_link']); ?>" style="display: inline-block; background: #2E75B6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold;">Track Your Cab Live</a>
    </p>
    <?php
    return ob_get_clean();
}

/**
 * Email template: Trip Completed
 */
function ridego_email_trip_completed($data, $user) {
    ob_start();
    ?>
    <h1 style="color: #28A745;">✅ Trip Completed - Thank You!</h1>
    <p style="font-size: 16px; color: #333;">Hi <?php echo esc_html($user['name']); ?>,</p>
    <p>Your trip has been completed successfully. We hope you had a pleasant journey!</p>
    
    <table style="width: 100%; border-collapse: collapse; margin: 20px 0; background: #f9f9f9; border-radius: 8px;">
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><strong>Booking:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><?php echo esc_html($data['booking_number']); ?></td>
        </tr>
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #ddd;"><strong>Estimated ride fare:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #ddd; font-weight: bold;">₹<?php echo number_format(ridego_notif_amount($data['total_fare']), 2); ?></td>
        </tr>
        <tr>
            <td style="padding: 15px;"><strong>Distance:</strong></td>
            <td style="padding: 15px;"><?php echo esc_html($data['distance_km']); ?> km</td>
        </tr>
    </table>
    
    <div style="background: #E7F3FF; padding: 20px; text-align: center; margin: 20px 0; border-radius: 8px;">
        <p style="font-size: 18px; margin-bottom: 15px;">How was your experience?</p>
        <a href="<?php echo esc_url($data['rate_link']); ?>" style="display: inline-block; background: #FFC107; color: #333; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold;">⭐ Rate Your Trip</a>
    </div>
    
    <p style="margin-top: 20px;">
        <a href="<?php echo esc_url($data['receipt_link']); ?>" style="color: #2E75B6; text-decoration: underline;">Booking amount receipt</a>
    </p>
    <p style="color:#666;font-size:13px;">The ride fare is billed and collected directly by your vendor/driver, who is responsible for the ride invoice.</p>
    
    <p style="color: #666; font-size: 14px; margin-top: 30px;">
        Thank you for choosing <?php echo esc_html( ridego_brand_name() ); ?>. We look forward to serving you again!
    </p>
    <?php
    return ob_get_clean();
}

/**
 * Email template: Booking Cancelled
 */
function ridego_email_booking_cancelled($data, $user) {
    ob_start();
    ?>
    <h1 style="color: #DC3545;">❌ Booking Cancelled</h1>
    <p style="font-size: 16px; color: #333;">Hi <?php echo esc_html($user['name']); ?>,</p>
    <p>Your booking <strong><?php echo esc_html($data['booking_number']); ?></strong> has been cancelled.</p>
    
    <?php if (isset($data['cancel_reason'])): ?>
    <div style="background: #F8D7DA; border-left: 4px solid #DC3545; padding: 15px; margin: 20px 0;">
        <strong>Cancellation Reason:</strong><br>
        <?php echo esc_html($data['cancel_reason']); ?>
    </div>
    <?php endif; ?>
    
    <?php if (isset($data['refund_amount']) && $data['refund_amount'] > 0): ?>
    <div style="background: #D4EDDA; border-left: 4px solid #28A745; padding: 15px; margin: 20px 0;">
        <strong>💰 Refund Information:</strong><br>
        Refund Amount: ₹<?php echo number_format($data['refund_amount'], 2); ?><br>
        Processing Time: <?php echo esc_html($data['refund_days'] ?? '5-7'); ?> business days<br>
        Refund Method: Original payment method
    </div>
    <?php endif; ?>
    
    <p style="margin-top: 30px;">
        Need to book another trip?<br>
        <a href="<?php echo esc_url(home_url( '/book' )); ?>" style="display: inline-block; background: #2E75B6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; margin-top: 10px;">Book a New Cab</a>
    </p>
    <?php
    return ob_get_clean();
}

/**
 * Email template: OTP Verification
 */
function ridego_email_otp($data, $user) {
    ob_start();
    ?>
    <h1 style="color: #2E75B6;">🔐 Your OTP Verification Code</h1>
    <p style="font-size: 16px; color: #333;">Hi,</p>
    <p>Your OTP for <?php echo esc_html( ridego_brand_name() ); ?> verification is:</p>
    
    <div style="background: #E7F3FF; padding: 30px; text-align: center; margin: 20px 0; border-radius: 8px;">
        <div style="font-size: 48px; font-weight: bold; color: #2E75B6; letter-spacing: 10px; font-family: monospace;">
            <?php echo esc_html($data['otp']); ?>
        </div>
    </div>
    
    <div style="background: #FFF3CD; border-left: 4px solid #FFC107; padding: 15px; margin: 20px 0;">
        <strong>⚠️ Security Warning:</strong><br>
        This OTP is valid for <strong>10 minutes</strong> only.<br>
        Never share this OTP with anyone. <?php echo esc_html( ridego_brand_name() ); ?> staff will never ask for your OTP.
    </div>
    
    <p style="color: #666; font-size: 14px; margin-top: 30px;">
        If you didn't request this OTP, please ignore this email.
    </p>
    <?php
    return ob_get_clean();
}

/**
 * Email template: Vendor KYC Approved
 */
function ridego_email_vendor_kyc_approved($data, $user) {
    ob_start();
    ?>
    <h1 style="color: #28A745;">✅ KYC Approved - Welcome to <?php echo esc_html( ridego_brand_name() ); ?>!</h1>
    <p style="font-size: 16px; color: #333;">Hi <?php echo esc_html($user['name']); ?>,</p>
    <p>Congratulations! Your KYC verification has been approved. Your vendor account is now <strong style="color: #28A745;">ACTIVE</strong>.</p>
    
    <div style="background: #D4EDDA; border-left: 4px solid #28A745; padding: 15px; margin: 20px 0;">
        <strong>✅ Account Status: ACTIVE</strong><br>
        Business Name: <?php echo esc_html($data['business_name']); ?><br>
        Operating Cities: <?php echo esc_html($data['cities']); ?><br>
        Vehicle Types: <?php echo esc_html($data['vehicles']); ?>
    </div>
    
    <p><strong>What's Next?</strong></p>
    <ul style="line-height: 1.8;">
        <li><strong>Add wallet balance</strong> to start receiving booking leads (minimum ₹500)</li>
        <li>You will receive WhatsApp alerts for new booking opportunities</li>
        <li>Accept leads within 10 minutes to win the booking</li>
        <li>Complete trips and earn - we only charge per successful lead</li>
    </ul>
    
    <p style="margin-top: 30px;">
        <a href="<?php echo esc_url($data['dashboard_link']); ?>" style="display: inline-block; background: #28A745; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold;">Go to Vendor Dashboard</a>
    </p>
    
    <p style="margin-top: 20px;">
        <a href="<?php echo esc_url($data['wallet_topup_link']); ?>" style="display: inline-block; background: #2E75B6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold;">Top Up Wallet Now</a>
    </p>
    <?php
    return ob_get_clean();
}

/**
 * Email template: Vendor New Lead
 */
function ridego_email_vendor_new_lead($data, $user) {
    ob_start();
    ?>
    <h1 style="color: #FFC107;">🚖 New Booking Lead Available!</h1>
    <p style="font-size: 16px; color: #333;">Hi <?php echo esc_html($user['name']); ?>,</p>
    <p>A new booking lead matching your profile is available. <strong style="color: #DC3545;">Accept within 10 minutes!</strong></p>
    
    <table style="width: 100%; border-collapse: collapse; margin: 20px 0; background: #FFF9E6; border-radius: 8px; border: 2px solid #FFC107;">
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><strong>Booking ID:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><?php echo esc_html($data['booking_number']); ?></td>
        </tr>
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><strong>Route:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><?php echo esc_html($data['pickup_city']); ?> → <?php echo esc_html($data['drop_city']); ?></td>
        </tr>
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><strong>Date & Time:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><?php echo esc_html($data['journey_date']); ?> at <?php echo esc_html($data['journey_time']); ?></td>
        </tr>
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><strong>Vehicle Type:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><?php echo esc_html($data['vehicle_type']); ?></td>
        </tr>
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><strong>Passengers:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><?php echo esc_html($data['passengers']); ?> pax</td>
        </tr>
        <tr style="background: #FFE69C;">
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><strong>Estimated ride fare:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C; font-size: 18px; font-weight: bold;">₹<?php echo number_format(ridego_notif_amount($data['total_fare']), 2); ?></td>
        </tr>
        <?php if (isset($data['token_amount'])): ?>
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><strong>Customer advance paid to <?php echo esc_html( ridego_brand_name() ); ?>:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;">₹<?php echo number_format(ridego_notif_amount($data['token_amount']), 2); ?></td>
        </tr>
        <tr>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C;"><strong>You collect from the client:</strong></td>
            <td style="padding: 15px; border-bottom: 1px solid #FFE69C; font-weight: bold;">₹<?php echo number_format(ridego_notif_amount($data['remaining_amount'] ?? 0), 2); ?></td>
        </tr>
        <?php endif; ?>
        <tr style="background: #DC3545; color: white;">
            <td style="padding: 15px;"><strong>Lead Fee:</strong></td>
            <td style="padding: 15px; font-size: 18px; font-weight: bold;">₹<?php echo number_format(ridego_notif_amount($data['lead_fee']), 2); ?><?php if (!empty($data['lead_fee_note'])): ?><br><span style="font-size: 12px; font-weight: normal;"><?php echo esc_html($data['lead_fee_note']); ?>. Payable to <?php echo esc_html( ridego_brand_name() ); ?> under your commercial terms; any advance <?php echo esc_html( ridego_brand_name() ); ?> holds for this booking is adjusted against it.</span><?php endif; ?></td>
        </tr>
    </table>
    
    <div style="background: #F8D7DA; border-left: 4px solid #DC3545; padding: 15px; margin: 20px 0;">
        <strong>⏰ TIME SENSITIVE:</strong><br>
        You have <strong>10 minutes</strong> to accept or reject this lead.<br>
        First vendor to accept wins the booking!
    </div>
    
    <p style="text-align: center; margin: 30px 0;">
        <a href="<?php echo esc_url($data['accept_link']); ?>" style="display: inline-block; background: #28A745; color: white; padding: 15px 40px; text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 18px; margin-right: 10px;">✅ ACCEPT LEAD</a>
        <a href="<?php echo esc_url($data['reject_link']); ?>" style="display: inline-block; background: #6C757D; color: white; padding: 15px 40px; text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 18px;">❌ REJECT</a>
    </p>
    
    <p style="color: #666; font-size: 14px;">
        Current Wallet Balance: ₹<?php echo number_format($data['wallet_balance'], 2); ?>
    </p>
    <?php
    return ob_get_clean();
}

/**
 * Email template: Vendor Wallet Low
 */
function ridego_email_vendor_wallet_low($data, $user) {
    ob_start();
    ?>
    <h1 style="color: #DC3545;">⚠️ Wallet Balance Low</h1>
    <p style="font-size: 16px; color: #333;">Hi <?php echo esc_html($user['name']); ?>,</p>
    <p>Your wallet balance is running low. You need to top up to continue receiving booking leads.</p>
    
    <div style="background: #F8D7DA; border-left: 4px solid #DC3545; padding: 20px; margin: 20px 0; text-align: center;">
        <div style="font-size: 14px; color: #666; margin-bottom: 5px;">Current Balance</div>
        <div style="font-size: 36px; font-weight: bold; color: #DC3545;">₹<?php echo number_format($data['wallet_balance'], 2); ?></div>
        <div style="font-size: 14px; color: #666; margin-top: 10px;">Minimum Required: ₹<?php echo number_format($data['min_required'], 2); ?></div>
    </div>
    
    <p><strong>Why Top Up Now?</strong></p>
    <ul style="line-height: 1.8;">
        <li>You will not receive new leads until balance is above ₹<?php echo number_format($data['min_required'], 2); ?></li>
        <li>Missing leads = lost business opportunities</li>
        <li>Top up now to stay ahead of competitors</li>
    </ul>
    
    <p style="text-align: center; margin: 30px 0;">
        <a href="<?php echo esc_url($data['topup_link']); ?>" style="display: inline-block; background: #28A745; color: white; padding: 15px 40px; text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 18px;">💰 Top Up Wallet Now</a>
    </p>
    
    <p style="color: #666; font-size: 14px;">
        Need help? Contact us:<br>
        Phone: <?php echo esc_html( ridego_brand( 'support_phone' ) ); ?><br>
        WhatsApp: <?php echo esc_html(get_option('ridego_support_whatsapp', '+91-XXXXXXXXXX')); ?>
    </p>
    <?php
    return ob_get_clean();
}

/**
 * Email header template
 */
function ridego_get_email_header() {
    $logo_url = ridego_brand( 'logo_url' );
    $site_name = ridego_brand_name();
    
    ob_start();
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo esc_html($site_name); ?></title>
    </head>
    <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
        <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f4f4f4; padding: 20px 0;">
            <tr>
                <td align="center">
                    <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                        <!-- Header -->
                        <tr>
                            <td style="background: linear-gradient(135deg, #2E75B6 0%, #1E4D7B 100%); padding: 30px; text-align: center;">
                                <?php if ( $logo_url !== '' ) : ?>
                                <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($site_name); ?>" style="max-width: 200px; height: auto;">
                                <?php else : ?>
                                <span style="color: #ffffff; font-size: 26px; font-weight: bold;"><?php echo esc_html($site_name); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <!-- Content -->
                        <tr>
                            <td style="padding: 40px 30px;">
    <?php
    return ob_get_clean();
}

/**
 * Email footer template
 */
function ridego_get_email_footer() {
    $site_name = ridego_brand_name();
    $site_url = ridego_brand( 'website_url' );
    $support_email = ridego_brand( 'support_email' );
    $support_phone = ridego_brand( 'support_phone' );
    $whatsapp = preg_replace( '/[^0-9]/', '', ridego_brand( 'support_whatsapp' ) );
    $tagline = ridego_brand( 'tagline' );
    $address = ridego_brand( 'address' );
    $hours = ridego_brand( 'business_hours' );
    $signature = ridego_brand( 'email_signature' );
    $legal = ridego_brand( 'legal_info' );
    $footer_note = ridego_brand( 'footer_note' );
    $copyright = ridego_brand( 'copyright' );
    $socials = array_filter( ridego_branding_public()['social'] );
    
    ob_start();
    ?>
                            </td>
                        </tr>
                        <!-- Footer -->
                        <tr>
                            <td style="background-color: #f9f9f9; padding: 30px; text-align: center; border-top: 1px solid #e0e0e0;">
                                <?php if ( $signature !== '' ) : ?>
                                <p style="margin: 0 0 12px 0; color: #444; font-size: 14px;"><?php echo nl2br( esc_html( $signature ) ); ?></p>
                                <?php endif; ?>
                                <p style="margin: 0 0 10px 0; color: #666; font-size: 14px;">
                                    <strong><?php echo esc_html($site_name); ?></strong><?php if ( $tagline !== '' ) : ?><br><?php echo esc_html( $tagline ); ?><?php endif; ?>
                                </p>
                                <p style="margin: 10px 0; color: #666; font-size: 13px;">
                                    <?php if ( $support_phone !== '' ) : ?>📞 <?php echo esc_html($support_phone); ?><?php endif; ?>
                                    <?php if ( $whatsapp !== '' ) : ?> | 💬 <a href="https://wa.me/<?php echo esc_attr( $whatsapp ); ?>" style="color: #2E75B6; text-decoration: none;">WhatsApp</a><?php endif; ?>
                                    <?php if ( $support_email !== '' ) : ?> | 📧 <a href="mailto:<?php echo esc_attr($support_email); ?>" style="color: #2E75B6; text-decoration: none;"><?php echo esc_html($support_email); ?></a><?php endif; ?>
                                </p>
                                <?php if ( $address !== '' ) : ?><p style="margin: 6px 0; color: #777; font-size: 12px;"><?php echo nl2br( esc_html( $address ) ); ?></p><?php endif; ?>
                                <?php if ( $hours !== '' ) : ?><p style="margin: 6px 0; color: #777; font-size: 12px;"><?php echo nl2br( esc_html( $hours ) ); ?></p><?php endif; ?>
                                <?php if ( $socials ) : ?><p style="margin: 8px 0; font-size: 12px;"><?php foreach ( $socials as $net => $url ) : ?><a href="<?php echo esc_url( $url ); ?>" style="color: #2E75B6; text-decoration: none; margin: 0 6px;"><?php echo esc_html( ucfirst( $net ) ); ?></a><?php endforeach; ?></p><?php endif; ?>
                                <p style="margin: 10px 0; font-size: 11px; color: #999;"><?php echo esc_html( $site_name ); ?> is a booking platform. It collects only the booking amount; the vendor/driver bills and collects the ride fare directly.</p>
                                <?php if ( $footer_note !== '' ) : ?><p style="margin: 6px 0; font-size: 11px; color: #999;"><?php echo nl2br( esc_html( $footer_note ) ); ?></p><?php endif; ?>
                                <?php if ( $legal !== '' ) : ?><p style="margin: 6px 0; font-size: 11px; color: #999;"><?php echo nl2br( esc_html( $legal ) ); ?></p><?php endif; ?>
                                <p style="margin: 15px 0 0 0; font-size: 12px; color: #999;">
                                    <?php echo esc_html( $copyright ); ?><br>
                                    <a href="<?php echo esc_url(home_url( '/terms/' )); ?>" style="color: #999; text-decoration: none;">Terms & Conditions</a>
                                </p>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </body>
    </html>
    <?php
    return ob_get_clean();
}

// ============================================================================
// SMS - FIREBASE AUTH (OTP ONLY - 10K FREE/MONTH)
// ============================================================================

/**
 * Send OTP via SMS using Firebase Authentication
 * Free tier: 10,000 SMS/month
 * Only used for critical OTP verification - never for bulk messaging
 * 
 * @param string $phone Phone number with country code
 * @param string $otp   6-digit OTP
 * @return bool Success
 */
function ridego_send_otp_sms($phone, $otp) {
    
    // Firebase is handled client-side via JavaScript SDK
    // This function is a placeholder for server-side SMS fallback
    // Using Fast2SMS as backup for when Firebase quota exceeded
    
    $fast2sms_key = get_option('ridego_fast2sms_key');
    
    if (empty($fast2sms_key)) {
        ridego_log('SMS OTP: Fast2SMS key not configured. Skipping SMS.');
        return false;
    }
    
    // Clean phone number (remove country code for Indian SMS APIs)
    $phone = preg_replace('/[^0-9]/', '', $phone);
    if (strlen($phone) > 10) {
        $phone = substr($phone, -10); // Last 10 digits
    }
    
    // Build SMS message
    $message = "Your " . ridego_brand_name() . " OTP is: {$otp}. Valid for 10 minutes. Do not share with anyone.";
    
    // Send via Fast2SMS
    $response = wp_remote_post('https://www.fast2sms.com/dev/bulkV2', array(
        'headers' => array(
            'authorization' => $fast2sms_key,
            'Content-Type'  => 'application/json',
        ),
        'body' => wp_json_encode(array(
            'route'    => 'v3',
            'sender_id' => get_option('ridego_sms_sender_id', 'RIDEGO'),
            'message'  => $message,
            'language' => 'english',
            'flash'    => 0,
            'numbers'  => $phone,
        )),
        'timeout' => 15,
    ));
    
    if (is_wp_error($response)) {
        ridego_log('Fast2SMS error: ' . $response->get_error_message());
        return false;
    }
    
    $body = json_decode(wp_remote_retrieve_body($response), true);
    
    if (isset($body['return']) && $body['return'] === true) {
        ridego_log("OTP SMS sent to {$phone}");
        return true;
    }
    
    ridego_log("Fast2SMS failed: " . wp_json_encode($body));
    return false;
}

// ============================================================================
// MESSAGE BUILDERS - WHATSAPP & TELEGRAM
// ============================================================================

/**
 * Build WhatsApp message from template
 * 
 * @param string $event Event type
 * @param array  $data  Event data
 * @param array  $user  User data
 * @return string Formatted message
 */
function ridego_build_whatsapp_message($event, $data, $user) {
    
    // Get template from database (editable via admin panel)
    $template = ridego_get_message_template('whatsapp', $event);
    
    if (!$template) {
        return ridego_brand_name() . " Notification: {$event}";
    }
    
    // Replace variables in template
    $message = $template;
    
    // User variables
    $message = str_replace('{client_name}', $user['name'] ?? 'Customer', $message);
    $message = str_replace('{vendor_name}', $user['name'] ?? 'Vendor', $message);
    
    // Data variables
    foreach ($data as $key => $value) {
        if (is_scalar($value)) {
            $message = str_replace('{' . $key . '}', $value, $message);
        }
    }
    
    return $message;
}

/**
 * Build Telegram alert message with HTML formatting
 * 
 * @param string $event Event type
 * @param array  $data  Event data
 * @return string HTML formatted message
 */
function ridego_build_telegram_message($event, $data) {
    
    $message = '';
    
    switch ($event) {
        
        case 'new_booking':
            $message = sprintf(
                "🚖 <b>NEW BOOKING</b>\n" .
                "ID: %s | %s\n" .
                "%s → %s\n" .
                "%s %s | %s | %d pax\n" .
                "Fare: ₹%s | Method: %s",
                $data['booking_number'],
                $data['trip_type'],
                $data['pickup_city'],
                $data['drop_city'],
                $data['journey_date'],
                $data['journey_time'],
                $data['vehicle_type'],
                $data['passengers'],
                number_format(ridego_notif_amount($data['total_fare']), 2),
                $data['payment_method']
            );
            break;
            
        case 'payment_proof_submitted':
            $message = sprintf(
                "💳 <b>PAYMENT PROOF SUBMITTED</b>\n" .
                "Booking: %s\n" .
                "Amount: ₹%s | UTR: %s\n" .
                "App: %s\n" .
                "<a href='%s'>VERIFY NOW →</a>",
                $data['booking_number'],
                number_format($data['amount'], 2),
                $data['utr'] ?? 'N/A',
                $data['payment_app'] ?? 'Bank Transfer',
                $data['verify_link']
            );
            break;
            
        case 'no_vendor_alert':
            $message = sprintf(
                "⚠️ <b>NO VENDOR ALERT</b>\n" .
                "Booking %s has no vendor for %d minutes!\n" .
                "%s → %s | %s\n" .
                "<a href='%s'>ASSIGN MANUALLY →</a>",
                $data['booking_number'],
                $data['minutes'],
                $data['pickup_city'],
                $data['drop_city'],
                $data['vehicle_type'],
                $data['assign_link']
            );
            break;
            
        case 'daily_summary':
            $message = sprintf(
                "📊 <b>DAILY SUMMARY — %s</b>\n" .
                "Bookings: %d (%d confirmed)\n" .
                "Revenue: ₹%s\n" .
                "Lead Fees: ₹%s\n" .
                "New Vendors: %d\n" .
                "Complaints: %d\n" .
                "Open Issues: %d",
                $data['date'],
                $data['total_bookings'],
                $data['confirmed'],
                number_format($data['revenue'], 2),
                number_format($data['lead_fees'], 2),
                $data['new_vendors'],
                $data['complaints'],
                $data['open_issues']
            );
            break;
            
        case 'new_complaint':
            $message = sprintf(
                "🚨 <b>COMPLAINT FILED</b>\n" .
                "Complaint ID: %s\n" .
                "Booking: %s\n" .
                "Category: %s\n" .
                "Filed by: %s\n" .
                "<a href='%s'>REVIEW →</a>",
                $data['complaint_id'],
                $data['booking_id'],
                $data['category'],
                $data['filed_by'],
                $data['complaint_link']
            );
            break;
            
        default:
            $message = "<b>" . ridego_brand_name() . " Alert:</b> {$event}";
    }
    
    return $message;
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get user notification details (phone, email, WhatsApp, name)
 * 
 * @param int $user_id User ID
 * @return array|bool User data or false
 */
function ridego_get_user_notification_details($user_id) {
    
    $user = get_userdata($user_id);
    
    if (!$user) {
        return false;
    }
    
    return array(
        'name'     => $user->display_name,
        'email'    => $user->user_email,
        'phone'    => get_user_meta($user_id, 'ridego_phone', true),
        'whatsapp' => get_user_meta($user_id, 'ridego_whatsapp', true),
    );
}

/**
 * Check if event needs WhatsApp notification
 * 
 * @param string $event Event type
 * @return bool
 */
// TRACE: queue processor → says whether an event goes over WhatsApp (marketplace events added) → bool.
//        Preconditions: none → Postconditions: pure → Edge cases: unknown event (false).
function ridego_event_needs_whatsapp($event) {
    
    $whatsapp_events = array(
        'booking_confirmed',
        'payment_proof_submitted',
        'payment_verified',
        'payment_reminder',
        'booking_updated',
        'payment_receipt',
        'vendor_collection_recorded',
        'refund_processed',
        'lead_reminder',
        'driver_assigned',
        'driver_arriving',
        'trip_started',
        'trip_completed',
        'booking_cancelled',
        'vendor_new_lead',
        'vendor_wallet_low',
        'vendor_kyc_approved',
        'payment_proof_rejected',
        'payment_failed',
        'refund_processed',
        'refund_initiated',
        'driver_vehicle_replaced',
        'lead_response_reminder',
        'driver_details_requested',
        'lead_lost_to_other_vendor',
    );
    
    return in_array($event, $whatsapp_events);
}

/**
 * Check if event needs email notification
 * 
 * @param string $event Event type
 * @return bool
 */
function ridego_event_needs_email($event) {
    
    // Email is sent for almost all events (it's free)
    $no_email_events = array(
        'driver_arriving', // Too frequent, WhatsApp only
        'otp_request',     // OTP goes via SMS primarily
    );
    
    return !in_array($event, $no_email_events);
}

/**
 * Get message template from database
 * Templates are editable via Admin Panel → Settings → Message Templates
 * 
 * @param string $channel Channel: whatsapp, email, sms, telegram
 * @param string $event   Event type
 * @return string|bool Template or false
 */
function ridego_get_message_template($channel, $event) {
    
    $option_name = "ridego_template_{$channel}_{$event}";
    $template = get_option($option_name);
    
    if (empty($template)) {
        // Return default templates if custom not set
        return ridego_get_default_template($channel, $event);
    }
    
    return $template;
}

/**
 * Get default message template (fallback)
 * 
 * @param string $channel Channel type
 * @param string $event   Event type
 * @return string Default template
 */
// TRACE: template lookup → default WhatsApp text per event (marketplace defaults added), generic fallback otherwise → string.
//        Preconditions: none → Postconditions: pure → Edge cases: unknown key (generic text).
function ridego_get_default_template($channel, $event) {
    
    // Default WhatsApp templates from spec
    $defaults = array(
        'whatsapp_booking_confirmed' => "✅ CONFIRMED! Booking {booking_number}\n📍 {pickup_city} → {drop_city}\n📅 {journey_date} at {journey_time}\n🚗 {vehicle_type}\n💰 Est. ride fare: ₹{total_fare} (payable to your vendor/driver)\nView: {booking_link}",
        
        'whatsapp_payment_proof_submitted' => "Hi {client_name}! We received your payment proof for {booking_number}. Our team will verify within 30 minutes. You will be notified once confirmed.",
        
        'whatsapp_driver_assigned' => "🚖 Driver Assigned for {booking_number}!\nDriver: {driver_name}\nPhone: {driver_phone}\nVehicle: {vehicle_model} | {vehicle_number}\nOTP for pickup: {otp}\nTrack: {tracking_link}",
        
        'whatsapp_driver_vehicle_replaced' => "🔁 Update for booking {booking_number}: your driver/vehicle changed.\nDriver: {driver_name}\nVehicle: {vehicle_model} | {vehicle_number}\nPickup OTP: {otp}\nTrack: {tracking_link}",
        'whatsapp_lead_response_reminder' => "⏰ Reminder: booking {booking_number} is still waiting for your response. Open the app to show interest or decline.",
        'whatsapp_driver_details_requested' => "Please confirm the driver and vehicle for booking {booking_number} in the app so we can consider you for this trip.",
        'whatsapp_lead_lost_to_other_vendor' => "Booking {booking_number} was assigned to another vendor this time. More leads are on the way.",
        'whatsapp_vendor_new_lead' => "🚖 NEW LEAD! Booking {booking_id}\n📍 {pickup_city} → {drop_city}\n📅 {journey_date} {journey_time}\n🚗 {vehicle_type} | 👤 {passengers} pax\n💰 Est. ride fare: {total_fare} | Customer advance paid to " . ridego_brand_name() . ": {token_amount} | Collect from client: {remaining_amount} | Your lead fee: {lead_fee}\n⏰ Accept in 10 mins!\nAccept: {accept_link}",
    );
    
    $key = "{$channel}_{$event}";
    
    return $defaults[$key] ?? ridego_brand_name() . " notification: {$event}";
}

/**
 * Builds a short, human-readable in-app message for a notification
 * event — this is what actually gets stored in ridego_notifications.
 * message (a real column) and, later, surfaced in the React app's
 * notifications inbox. Falls back to a generic-but-readable string
 * for any event not explicitly covered, so a new event type added
 * later never produces a blank/broken inbox row.
 */
// TRACE: in-app inbox/staff alert → one-line human message per event, including the marketplace events → string.
//        Preconditions: none → Postconditions: pure → Edge cases: missing booking number, unknown event (generic).
function ridego_notification_human_message( $event, $data = array() ) {
    $bn = isset( $data['booking_number'] ) ? $data['booking_number'] : '';
    switch ( $event ) {
        case 'booking_confirmed':
            return $bn ? "Your booking {$bn} is confirmed." : 'Your booking is confirmed.';
        case 'payment_proof_submitted':
            return $bn ? "We received your payment proof for {$bn}. We'll verify it shortly." : 'We received your payment proof and will verify it shortly.';
        case 'payment_reminder':
            return $bn ? "Reminder: booking amount is pending for booking {$bn}." : 'Reminder: your booking amount is pending.';
        case 'booking_updated':
            return isset( $data['message'] ) && $data['message'] !== '' ? (string) $data['message'] : ( $bn ? "Trip {$bn} was updated." : 'Your trip was updated.' );
        case 'payment_receipt':
            return 'Booking amount of ₹' . number_format( (float) ( $data['amount'] ?? 0 ), 2 ) . ( $bn ? " received for {$bn}" : ' received' ) . '. Remaining ₹' . number_format( (float) ( $data['balance'] ?? 0 ), 2 ) . ' is payable directly to your vendor/driver.';
        case 'vendor_collection_recorded':
            return 'Your vendor/driver recorded ₹' . number_format( (float) ( $data['amount'] ?? 0 ), 2 ) . ( $bn ? " collected for {$bn}" : ' collected' ) . '. Remaining: ₹' . number_format( (float) ( $data['balance'] ?? 0 ), 2 ) . '.';
        case 'refund_processed':
            return 'Booking amount refund of ₹' . number_format( (float) ( $data['amount'] ?? 0 ), 2 ) . ( $bn ? " processed for {$bn}." : ' processed.' );
        case 'lead_reminder':
            return $bn ? "Reminder: please respond to the ride request {$bn}." : 'Reminder: a ride request is waiting for you.';
        case 'payment_verified':
            return $bn ? "Booking amount received for {$bn}. The remaining ride fare is payable to your vendor/driver." : 'Your booking amount has been received.';
        case 'driver_assigned':
            $driver = isset( $data['driver_name'] ) ? $data['driver_name'] : '';
            return $bn ? trim( "A driver-partner" . ( $driver ? " ({$driver})" : '' ) . " has been assigned to booking {$bn}." ) : 'A driver-partner has been assigned to your trip.';
        case 'trip_completed':
            return $bn ? "Your trip {$bn} is complete. We'd love your rating!" : 'Your trip is complete.';
        case 'booking_cancelled':
            return $bn ? "Booking {$bn} was cancelled." : 'Your booking was cancelled.';
        case 'otp_request':
            return 'A one-time verification code was sent to you.';
        case 'vendor_kyc_approved':
            return 'Your KYC documents were approved. You can now receive ride leads.';
        case 'vendor_new_lead':
            $pc = isset( $data['pickup_city'] ) ? $data['pickup_city'] : '';
            $dc = isset( $data['drop_city'] ) ? $data['drop_city'] : '';
            return ( $pc && $dc ) ? "New ride lead: {$pc} → {$dc}." : 'A new ride lead is available.';
        case 'vendor_wallet_low':
            return 'Your wallet balance is low. Top up to keep receiving leads.';
        case 'vendor_interest_received':
            $vn = isset( $data['vendor_name'] ) ? $data['vendor_name'] : 'A vendor';
            return $bn ? "{$vn} responded on booking {$bn}." : "{$vn} responded to a lead.";
        case 'driver_vehicle_confirmed':
            return $bn ? "A vendor confirmed a driver and vehicle for booking {$bn}." : 'A vendor confirmed a driver and vehicle.';
        case 'driver_vehicle_replaced':
            return $bn ? "The driver or vehicle for booking {$bn} was changed." : 'The driver or vehicle for your trip was changed.';
        case 'lead_lost_to_other_vendor':
            return $bn ? "Booking {$bn} was assigned to another vendor." : 'This booking was assigned to another vendor.';
        case 'lead_response_reminder':
            return $bn ? "Booking {$bn} is still waiting for your response." : 'A lead is still waiting for your response.';
        case 'driver_details_requested':
            return $bn ? "Please confirm the driver and vehicle for booking {$bn}." : 'Please confirm the driver and vehicle.';
        case 'commission_charged':
            $amt = ! empty( $data['amount'] ) ? ' of ' . $data['amount'] : '';
            return $bn ? "A lead fee{$amt} payable to " . ridego_brand_name() . " was recorded for booking {$bn}. It is settled through your settlements." : 'A lead fee payable to ' . ridego_brand_name() . ' was recorded for a completed booking.';
        case 'impersonation_started':
            return 'An administrator started a view-as session.';
        case 'impersonation_ended':
            return 'A view-as session ended.';
        default:
            return ridego_brand_name() . ' update: ' . ucwords( str_replace( '_', ' ', (string) $event ) );
    }
}

/**
 * Log a notification attempt to the database — this is the single
 * record of what was communicated to a user, across every channel,
 * and (via the is_read/read_at columns added in migration 8) the
 * backing store for the in-app notifications inbox.
 *
 * ROOT-CAUSE FIX: this function previously tried to insert into
 * 'recipient' and 'details' columns that do not exist anywhere in
 * ridego_notifications' actual schema (see includes/install.php —
 * the table only ever had id/user_id/event/channel/message/status/
 * sent_at), and never populated the real 'message' column at all,
 * which is NOT NULL with no default. Every single call to this
 * function has therefore been failing at the database level since
 * this table was introduced ($wpdb->insert() returns false on an
 * unknown-column error, and that return value was never checked) —
 * the notification log has been silently empty this whole time, a
 * live instance of the exact "code references a column schema
 * doesn't have" pattern already fixed elsewhere in this engagement.
 * Fixed by inserting only into columns that actually exist, and by
 * building a real, human-readable message via
 * ridego_notification_human_message() instead of json-dumping
 * internal debug data into a column that was never being written.
 *
 * @param int    $user_id  User ID
 * @param string $event    Event type
 * @param string $channel  Which channel(s) were attempted (e.g. 'email,whatsapp', 'telegram', 'unknown')
 * @param string $message  Human-readable message for this notification
 * @param bool   $success  Whether the underlying dispatch succeeded
 */
function ridego_log_notification($user_id, $event, $channel, $message, $success) {
    global $wpdb;

    $table = $wpdb->prefix . 'ridego_notifications';

    $wpdb->insert($table, array(
        'user_id'    => absint($user_id),
        'event'      => sanitize_text_field($event),
        'channel'    => sanitize_text_field((string) $channel),
        'message'    => sanitize_text_field((string) $message),
        'status'     => $success ? 'sent' : 'failed',
        'is_read'    => 0,
        'sent_at'    => current_time('mysql'),
    ), array('%d', '%s', '%s', '%s', '%s', '%d', '%s'));
}

/**
 * Paginated in-app notification feed for one user — the read side of
 * the inbox this table now backs (see migration 008 and the
 * ridego_log_notification() fix above it depends on).
 *
 * @param int  $user_id
 * @param bool $unread_only  If true, only return unread rows.
 * @param int  $limit
 * @param int  $offset
 * @return array{rows: object[], total: int}
 */
function ridego_get_user_notifications( $user_id, $unread_only = false, $limit = 20, $offset = 0 ) {
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_notifications';
    $where = $wpdb->prepare( 'user_id = %d', $user_id );
    if ( $unread_only ) {
        $where .= ' AND is_read = 0';
    }
    $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE {$where}" );
    $rows  = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$table} WHERE {$where} ORDER BY sent_at DESC LIMIT %d OFFSET %d",
        max( 1, intval( $limit ) ), max( 0, intval( $offset ) )
    ) );
    return array( 'rows' => $rows, 'total' => $total );
}

/**
 * Count of unread notifications for a user — used for the inbox badge.
 */
function ridego_count_unread_notifications( $user_id ) {
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_notifications';
    return (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND is_read = 0", $user_id
    ) );
}

/**
 * Marks one notification as read. Ownership-checked: a user can only
 * mark their own notifications, admins can mark any (matches the
 * ownership-check convention used throughout the rest of the app API,
 * e.g. ridego_app_api_cancel_booking()).
 */
function ridego_mark_notification_read( $id, $user_id ) {
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_notifications';
    $row   = $wpdb->get_row( $wpdb->prepare( "SELECT id, user_id FROM {$table} WHERE id = %d", intval( $id ) ) );
    if ( ! $row ) {
        return array( 'success' => false, 'message' => 'Notification not found.' );
    }
    if ( (int) $row->user_id !== (int) $user_id && ! current_user_can( 'manage_options' ) ) {
        return array( 'success' => false, 'message' => 'You are not authorized to update this notification.' );
    }
    $wpdb->update( $table, array( 'is_read' => 1, 'read_at' => current_time( 'mysql' ) ), array( 'id' => intval( $id ) ) );
    return array( 'success' => true );
}

/**
 * Marks every unread notification for a user as read (a single UPDATE,
 * not a loop over ridego_mark_notification_read() — no reason to pay
 * N queries for what one WHERE clause already does correctly).
 */
function ridego_mark_all_notifications_read( $user_id ) {
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_notifications';
    $wpdb->update(
        $table,
        array( 'is_read' => 1, 'read_at' => current_time( 'mysql' ) ),
        array( 'user_id' => intval( $user_id ), 'is_read' => 0 )
    );
    return array( 'success' => true );
}

/**
 * Simple logging function
 * Logs to WordPress debug.log if WP_DEBUG is enabled
 * 
 * @param string $message Log message
 */
/* NOTE: ridego_log() is defined in ridego-platform.php (loaded before all includes).
   This copy is a fallback that routes to error_log when WP_DEBUG is on. */
if ( ! function_exists('ridego_log') ) :
function ridego_log($message) {
    if (defined('WP_DEBUG') && WP_DEBUG === true) {
        error_log('[RideGo Notifications] ' . $message);
    }
}
endif; // function_exists ridego_log

// ============================================================================
// WP CRON SETUP
// ============================================================================

/**
 * Schedule notification queue processing
 * Called on plugin activation
 */
function ridego_schedule_notification_cron() {

    if (!wp_next_scheduled('ridego_process_notification_queue')) {
        wp_schedule_event(time(), 'every_5_minutes', 'ridego_process_notification_queue');
    }
}
add_action('wp', 'ridego_schedule_notification_cron');

/**
 * Root-cause fix: WP-Cron is pseudo-cron — 'ridego_process_notification_queue'
 * above only actually fires when SOME visitor loads a page after its 5-minute
 * mark has passed. On a low-traffic admin action (e.g. an admin approves a
 * vendor at 11pm and nobody else hits the site until morning), every queued
 * notification — the exact thing this queue exists to deliver — would sit
 * unsent for hours. Real WordPress sites also very commonly define
 * DISABLE_WP_CRON and rely on a system crontab hitting wp-cron.php on a
 * schedule the site owner may not have set up correctly (or at all) for this
 * plugin's custom hook, which the previous implementation had no fallback
 * for whatsoever.
 *
 * Rather than depend on the NEXT request to carry the 5-minute schedule
 * forward, ridego_queue_notification() below flags the current request as
 * having queued at least one immediately-due item, and this shutdown hook
 * flushes the queue at the end of THAT SAME request — the request that
 * created the work is also the one that (usually) delivers it, with zero
 * dependency on WP-Cron ever firing again. The 5-minute wp_schedule_event
 * is kept as a second line of defense for delayed items and anything this
 * flush's own send attempt fails to deliver (retried via the existing
 * backoff/attempts columns), not removed — this is a fallback added on top,
 * not a replacement that could itself be the only path.
 */
function ridego_flush_notification_queue_on_shutdown() {
    $queued_this_request = ! empty( $GLOBALS['ridego_notification_queued_this_request'] );
    $do_backlog_sweep    = false;

    if ( ! $queued_this_request ) {
        /*
         * Root-cause gap found during the #56 regression pass: the flush above
         * only runs on the SAME request that queued an immediately-due item, so
         * any pre-existing backlog (rows queued before this fallback existed,
         * or rows whose queuing request crashed before shutdown ran) sits
         * forever on a site where WP-Cron is disabled and nothing happens to
         * queue a brand-new notification. Confirmed live: 23 pending rows from
         * 2026-09-22 still unsent days later with WP-Cron disabled and no new
         * activity to trigger the same-request flush.
         *
         * Fix: opportunistically sweep for due backlog on ordinary traffic too,
         * throttled to at most once per 60 seconds site-wide via a transient
         * lock so this adds negligible overhead per request.
         */
        if ( false === get_transient( 'ridego_notif_backlog_sweep_lock' ) ) {
            set_transient( 'ridego_notif_backlog_sweep_lock', 1, 60 );
            $do_backlog_sweep = true;
        }
    }

    if ( ! $queued_this_request && ! $do_backlog_sweep ) {
        return;
    }
    if ( function_exists( 'ridego_process_notification_queue' ) ) {
        ridego_process_notification_queue();
    }
}
add_action( 'shutdown', 'ridego_flush_notification_queue_on_shutdown' );

/**
 * Add custom cron interval: every 5 minutes
 */
function ridego_add_cron_interval($schedules) {
    
    $schedules['every_5_minutes'] = array(
        'interval' => 300,
        'display'  => __('Every 5 Minutes', 'ridego')
    );
    
    return $schedules;
}
add_filter('cron_schedules', 'ridego_add_cron_interval');

/**
 * Hook the queue processor to WP Cron
 */
add_action('ridego_process_notification_queue', 'ridego_process_notification_queue');

/**
 * Cleanup on plugin deactivation
 */
function ridego_unschedule_notification_cron() {
    $timestamp = wp_next_scheduled('ridego_process_notification_queue');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'ridego_process_notification_queue');
    }
}
register_deactivation_hook(RIDEGO_PATH . 'ridego-platform.php', 'ridego_unschedule_notification_cron');
