<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Settings
   ------------------------------------------------------------
   React equivalent of admin/pages/settings.php's tabbed settings
   form. Reuses the exact same canonical helpers that page uses —
   ridego_get_setting()/ridego_update_setting() for storage,
   ridego_get_secret_setting_keys() plus the encrypt/decrypt-at-rest
   layer in includes/helpers.php for secrets, and ridego_audit_log()
   for change logging — rather than reimplementing any of it here.

   SECRET MASKING CONVENTION (mirrors settings.php's rga_secret_field()
   / POST handler exactly):
     - GET never returns a secret's plaintext value. Each secret key
       is instead reported as an `is_set` boolean under `secrets` in
       the response.
     - POST treats an empty/absent submitted value for a secret field
       as "leave the stored value alone" — it is never used to clear
       an existing secret. Only a non-empty submitted value overwrites
       it (and ridego_update_setting() encrypts it at rest, same as
       every other write path).

   PERMISSION — copied from ridego_app_admin_api_vendors_permission()
   in includes/app-admin-api.php (is_user_logged_in() + a capability
   check), extended to accept either of the two capabilities
   settings.php itself checks (ridego_manage_settings OR
   manage_options) so this route is exactly as protected as the
   wp-admin page it's an alternative front end for.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_settings_api_routes' );
function ridego_register_app_admin_settings_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/settings', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_settings_get',
        'permission_callback' => 'ridego_app_admin_api_settings_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/settings', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_settings_save',
        'permission_callback' => 'ridego_app_admin_api_settings_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/settings/upload-qr', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_settings_upload_qr',
        'permission_callback' => 'ridego_app_admin_api_settings_permission',
    ) );
}

/**
 * Uploads the UPI/bank-transfer QR code image shown to customers on the
 * Payment Details step. Same discipline, same real file-type/size checks
 * and the same WordPress upload handler as
 * ridego_app_admin_api_city_upload_image() (includes/app-admin-cities-api.php)
 * — reused rather than reinvented. Returns the URL only; the admin UI then
 * saves it as the upi_qr_url setting via the normal settings POST, exactly
 * like the cities flow saves image_url onto the city record. "Remove" on
 * the frontend simply POSTs upi_qr_url='' back to /app/admin/settings.
 */
function ridego_app_admin_api_settings_upload_qr( WP_REST_Request $req ) {
    $files = $req->get_file_params();
    if ( empty( $files['file'] ) || ! empty( $files['file']['error'] ) || empty( $files['file']['tmp_name'] ) ) {
        return new WP_Error( 'no_file', 'Choose a QR code image to upload.', array( 'status' => 400 ) );
    }
    $f = $files['file'];
    $max_bytes = 2 * 1024 * 1024;
    if ( (int) $f['size'] > $max_bytes ) {
        return new WP_Error( 'too_big', 'The image must be 2 MB or smaller.', array( 'status' => 400 ) );
    }
    $allowed = array( 'png' => 'image/png', 'jpg|jpeg' => 'image/jpeg', 'webp' => 'image/webp' );
    $check = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], $allowed );
    if ( empty( $check['ext'] ) || empty( $check['type'] ) ) {
        return new WP_Error( 'bad_type', 'Upload a png, jpg or webp image.', array( 'status' => 400 ) );
    }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    $up = wp_handle_upload( $f, array( 'test_form' => false, 'mimes' => $allowed ) );
    if ( ! empty( $up['error'] ) || empty( $up['url'] ) ) {
        return new WP_Error( 'upload_failed', 'The image could not be saved. Please try again.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'url' => esc_url_raw( $up['url'] ) ) );
}

function ridego_app_admin_api_settings_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_settings' ) && ! ridego_can( 'manage_options' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage settings.', array( 'status' => 403 ) );
    }
    return true;
}

/**
 * Non-secret setting keys, with their defaults, grouped by tab exactly
 * as admin/pages/settings.php lays them out. Kept as one flat map here
 * (rather than per-tab arrays) since GET/POST both just need
 * key => default; the React page owns the tab grouping for display.
 */
// TRACE: settings GET/POST → returns the whitelist of non-secret text settings with defaults, now including lead_assignment_mode, lead_response_window, lead_accept_minutes, lead_max_vendors, impersonation_minutes → array.
//        Preconditions: none → Postconditions: pure → Edge cases: none.
function ridego_app_admin_settings_text_fields() {
    return array(
        // General
        'platform_name'      => get_bloginfo( 'name' ),
        'platform_tagline'   => 'Safe, Reliable & Affordable Cab Booking',
        'admin_email'        => get_option( 'admin_email' ),
        'support_phone'      => '',
        'invoice_company_name'    => '',
        'invoice_company_address' => '',
        'invoice_gstin'           => '',
        'invoice_footer_note'     => '',
        'support_whatsapp'   => '',
        'currency'           => 'INR',
        'meta_title'         => '',
        'meta_description'   => '',
        // Payment (non-secret)
        'bank_name'          => '',
        'bank_account'       => '',
        'bank_ifsc'          => '',
        'bank_holder'        => '',
        'upi_id'             => '',
        'upi_qr_url'         => '',
        'gst_percent'        => 5,
        // SMS/OTP (non-secret)
        'otp_expiry_minutes' => 10,
        'sms_provider'       => 'textlocal',
        'sms_sender_id'      => 'RIDEGO',
        'twilio_from'        => '',
        // Booking rules
        'booking_advance_hours'   => 2,
        'booking_max_days'        => 90,
        'payment_deadline_hours'  => 5,
        'cancellation_free_hours' => 24,
        'min_wallet_balance'      => 200,
        // Hours after a trip completes before its booking is eligible to close (ridego_maybe_close_booking(),
        // includes/ledger.php). 0 = close as soon as otherwise eligible (no waiting window) — the exact
        // pre-existing behavior, unchanged unless an admin sets a window here.
        'booking_closure_dispute_hours' => 0,
        // Marketplace: 'compare' = vendors show interest and an admin selects; 'instant' = first vendor to accept wins.
        'lead_assignment_mode'          => 'compare',
        'lead_response_window'          => 15,   // minutes vendors have to respond in compare mode (reminder fires at 50%)
        'lead_accept_minutes'           => 10,   // minutes for first-to-accept in instant mode
        'lead_max_vendors'              => 5,    // vendors each booking is offered to
        'impersonation_minutes'         => 30,
        'night_hours_start'       => '22:00',
        'night_hours_end'         => '06:00',
        'complaint_sla_hours_urgent' => 4,
        'complaint_sla_hours_high'   => 24,
        'complaint_sla_hours_normal' => 72,
        'complaint_sla_hours_low'    => 168,
        // Advanced
        'ridego_audit_log_retention_days' => 730,
        // Booking amount (the only amount RideGo collects; the ride balance is billed and collected by the vendor/driver)
        'booking_amount_mode'    => 'fixed',   // 'fixed' = token_amount rupees, 'percent' = booking_amount_percent of the estimated fare
        'token_amount'           => 500,
        'booking_amount_percent' => 10,
        'booking_amount_min'     => 0,
        'booking_amount_max'     => 0,
        'token_label'            => 'Booking amount',
        'token_instructions'     => '',
        'disclaimer_client'      => '',
        'disclaimer_vendor'      => '',
        'disclaimer_receipt'     => '',
    );
}

function ridego_app_admin_settings_toggle_fields() {
    return array(
        'require_payment_proof'    => 1,
        'razorpay_enabled'         => 0,
        'gst_enabled'              => 1,
        'otp_enabled'              => 1, // "Enable Phone OTP Verification" in the admin UI (option key kept as otp_enabled for backward compatibility).
        'email_otp_enabled'        => 0, // "Enable Email OTP Verification" — independent of otp_enabled; see ridego_booking_requires_email_otp().
        'otp_trust_device_enabled' => 1,
        'whatsapp_enabled'         => 0,
        'auto_assign_vendor'       => 1,
        // Compare mode: when nobody responds before the window closes, re-send to the next eligible vendors
        // automatically (ON) or leave it in the Command Centre for a human decision (OFF, default).
        'lead_auto_redistribute'   => 0,
        // Drivers must have a complete profile (identity, licence, address, emergency contact) before they can be put on a trip.
        'require_complete_driver_profile' => 1,
        'fraud_detection_enabled'  => 1,
        'delete_data_on_uninstall' => 0,
        'ridego_allow_destructive_tools' => 0,
        // When on, a booking collects only the token/advance amount at
        // booking time (balance payable directly to the assigned
        // driver/vendor). When off, the system reverts to the pre-existing
        // behavior of collecting the full ride total at booking time.
    );
}

/** Only the secret keys this settings page actually exposes fields for. */
function ridego_app_admin_settings_secret_fields() {
    return array(
        'razorpay_key_id',
        'razorpay_key_secret',
        'razorpay_webhook_secret',
        'sms_api_key',
        'twilio_sid',
        'twilio_token',
        'fonnte_token',
        'google_maps_key',
    );
}

function ridego_app_admin_api_settings_get( WP_REST_Request $req ) {
    $values = array();
    foreach ( ridego_app_admin_settings_text_fields() as $key => $default ) {
        $values[ $key ] = ridego_get_setting( $key, $default );
    }
    // wording fields show the text that is actually in use (the default when nothing was saved) so an admin edits real copy rather than a blank box
    foreach ( array( 'token_label', 'token_instructions', 'disclaimer_client', 'disclaimer_vendor', 'disclaimer_receipt' ) as $tk ) { $values[ $tk ] = ridego_platform_text( $tk ); }

    $toggles = array();
    foreach ( ridego_app_admin_settings_toggle_fields() as $key => $default ) {
        $toggles[ $key ] = (int) ridego_get_setting( $key, $default ) === 1;
    }

    $secrets = array();
    foreach ( ridego_app_admin_settings_secret_fields() as $key ) {
        $secrets[ $key ] = array(
            'is_set' => (string) ridego_get_setting( $key, '' ) !== '',
        );
    }

    return rest_ensure_response( array(
        'values'  => $values,
        'toggles' => $toggles,
        'secrets' => $secrets,
    ) );
}

function ridego_app_admin_api_settings_save( WP_REST_Request $req ) {
    $body = $req->get_json_params();
    if ( ! is_array( $body ) ) { $body = array(); }

    $values  = isset( $body['values'] ) && is_array( $body['values'] ) ? $body['values'] : array();
    $toggles = isset( $body['toggles'] ) && is_array( $body['toggles'] ) ? $body['toggles'] : array();
    $secrets = isset( $body['secrets'] ) && is_array( $body['secrets'] ) ? $body['secrets'] : array();

    $changed = array();

    // Non-secret text/number/select fields.
    foreach ( ridego_app_admin_settings_text_fields() as $key => $default ) {
        if ( ! array_key_exists( $key, $values ) ) { continue; }
        $new_val = sanitize_text_field( (string) $values[ $key ] );
        // token_amount specifically: sanitize_text_field() alone accepts
        // negative numbers, non-numeric garbage, or unbounded values, all
        // of which flow straight into ridego_calculate_fare()'s breakdown
        // (pricing.php) and can otherwise make remaining_amount exceed
        // total_fare, or ask the client to pay more than the ride costs.
        // The React settings form's <input min={0}> is client-side only
        // and trivially bypassed by posting directly to this endpoint.
        if ( 'token_amount' === $key ) {
            $numeric = is_numeric( $new_val ) ? (float) $new_val : (float) $default;
            $new_val = (string) max( 0, round( $numeric, 2 ) );
        }
        // Booking amount rules: what is saved is exactly what runs.
        if ( 'booking_amount_mode' === $key && ! in_array( $new_val, array( 'fixed', 'percent' ), true ) ) {
            return new WP_REST_Response( array( 'code' => 'invalid_setting', 'message' => 'Booking amount type must be "fixed" or "percent".' ), 400 );
        }
        if ( 'booking_amount_percent' === $key && ( ! is_numeric( $new_val ) || (float) $new_val <= 0 || (float) $new_val > 100 ) ) {
            return new WP_REST_Response( array( 'code' => 'invalid_setting', 'message' => 'Booking amount percentage must be more than 0 and at most 100.' ), 400 );
        }
        if ( in_array( $key, array( 'booking_amount_min', 'booking_amount_max' ), true ) ) {
            if ( ! is_numeric( $new_val ) || (float) $new_val < 0 ) {
                return new WP_REST_Response( array( 'code' => 'invalid_setting', 'message' => 'Minimum and maximum booking amounts must be zero or more (0 means no limit).' ), 400 );
            }
            $new_val = (string) round( (float) $new_val, 2 );
        }
        // Marketplace settings: reject values the readers would silently normalise, so what an admin
        // saves is exactly what runs.
        if ( 'lead_assignment_mode' === $key && ! in_array( $new_val, array( 'compare', 'instant' ), true ) ) {
            return new WP_REST_Response( array( 'code' => 'invalid_setting', 'message' => 'Lead assignment mode must be "compare" or "instant".' ), 400 );
        }
        $ranges = array( 'lead_response_window' => array( 1, 1440 ), 'lead_accept_minutes' => array( 1, 1440 ), 'lead_max_vendors' => array( 1, 50 ), 'impersonation_minutes' => array( 5, 120 ), 'booking_closure_dispute_hours' => array( 0, 720 ) );
        if ( isset( $ranges[ $key ] ) ) {
            if ( ! is_numeric( $new_val ) || (int) $new_val < $ranges[ $key ][0] || (int) $new_val > $ranges[ $key ][1] ) {
                return new WP_REST_Response( array( 'code' => 'invalid_setting', 'message' => sprintf( '%s must be a whole number between %d and %d.', $key, $ranges[ $key ][0], $ranges[ $key ][1] ) ), 400 );
            }
            $new_val = (string) (int) $new_val;
        }
        $old_val = ridego_get_setting( $key );
        if ( (string) $old_val !== $new_val ) {
            $changed[ $key ] = $new_val;
        }
        ridego_update_setting( $key, $new_val );
    }

    // Toggles.
    foreach ( ridego_app_admin_settings_toggle_fields() as $key => $default ) {
        if ( ! array_key_exists( $key, $toggles ) ) { continue; }
        $v = ! empty( $toggles[ $key ] ) ? 1 : 0;
        if ( (int) ridego_get_setting( $key, $default ) !== $v ) {
            $changed[ $key ] = $v;
        }
        ridego_update_setting( $key, $v );
    }

    // Secrets — an empty/absent submitted value is a no-op, never a clear.
    $secret_keys = ridego_app_admin_settings_secret_fields();
    foreach ( $secret_keys as $key ) {
        if ( ! array_key_exists( $key, $secrets ) ) { continue; }
        $new_val = sanitize_text_field( (string) $secrets[ $key ] );
        if ( $new_val === '' ) { continue; }
        $changed[ $key ] = '***changed***';
        ridego_update_setting( $key, $new_val );
    }

    if ( ! empty( $changed ) ) {
        ridego_audit_log( 'settings_updated', 'settings', 0, '', $changed );
    }

    return rest_ensure_response( array(
        'success' => true,
        'message' => 'Settings saved successfully.',
    ) );
}
