<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Phase B, wave 25: complaints management
   ------------------------------------------------------------
   Covers admin/pages/complaints.php in full: the filtered/paginated
   list (status, priority, free-text search across complaint#,
   booking#, client name/phone, vendor name), the KPI tiles (open /
   urgent-open / resolved counts), the per-row status-update action
   (with the exact same "only stamp resolved_at on a genuine
   terminal-state transition, clear it on reopen" logic as the
   legacy handler), and the bulk status-change action.

   Every query and every piece of business logic below is copied
   verbatim from admin/pages/complaints.php — including the SLA
   breach/due-soon computation (sla_deadline vs now, 2-hour "due
   soon" window) and the priority sort order
   (urgent > high > normal > low via FIELD()).

   Schema confirmed directly against includes/install.php's
   CREATE TABLE for ridego_complaints — every column referenced
   below (complaint_id, booking_id, raised_by_id, raised_by_type,
   category, sub_category, description, evidence_urls, status,
   priority, assigned_to, resolution, resolved_at, sla_deadline,
   created_at, updated_at) genuinely exists; no schema mismatch
   found in this wave (unlike several earlier Phase B waves).

   No canonical "update complaint" helper function exists anywhere
   in the codebase — the legacy page does its own $wpdb->update()
   inline, so this REST layer does the same rather than inventing a
   shared function this wave didn't ask for. Flagged here, not
   silently papered over.

   Every route requires is_user_logged_in() AND
   ridego_can('ridego_manage_complaints') — the exact capability
   admin/pages/complaints.php already requires.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_complaints_api_routes' );
function ridego_register_app_admin_complaints_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/complaints', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_complaints_list',
        'permission_callback' => 'ridego_app_admin_api_complaints_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/complaints/(?P<id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_complaints_update',
        'permission_callback' => 'ridego_app_admin_api_complaints_permission',
        'args'                => array( 'id' => array( 'validate_callback' => function ( $v ) { return is_numeric( $v ); } ) ),
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/complaints/bulk-status', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_complaints_bulk_status',
        'permission_callback' => 'ridego_app_admin_api_complaints_permission',
    ) );
}

function ridego_app_admin_api_complaints_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_complaints' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage complaints.', array( 'status' => 403 ) );
    }
    return true;
}

/**
 * Same SLA-state computation as admin/pages/complaints.php:111-118 —
 * null (ok), 'breach' (deadline passed, non-terminal status), or
 * 'warn' (within 2 hours of deadline, non-terminal status).
 */
function ridego_app_admin_api_complaint_sla_state( $sla_deadline, $status ) {
    if ( ! $sla_deadline ) { return null; }
    $is_terminal = in_array( $status, array( 'resolved', 'closed' ), true );
    if ( $is_terminal ) { return null; }
    $sla_ts = strtotime( $sla_deadline );
    $now_ts = current_time( 'timestamp' );
    if ( ! $sla_ts ) { return null; }
    if ( $sla_ts < $now_ts ) { return 'breach'; }
    if ( ( $sla_ts - $now_ts ) <= 2 * HOUR_IN_SECONDS ) { return 'warn'; }
    return null;
}

function ridego_app_admin_api_complaint_format( $c ) {
    return array(
        'id'              => (int) $c->id,
        'complaint_id'    => $c->complaint_id ?: ( '#' . $c->id ),
        'booking_id'      => (int) $c->booking_id,
        'booking_number'  => isset( $c->booking_number ) ? $c->booking_number : null,
        'client_name'     => isset( $c->client_name ) ? $c->client_name : null,
        'vendor_name'     => isset( $c->vendor_name ) ? $c->vendor_name : null,
        'category'        => $c->category,
        'sub_category'    => $c->sub_category,
        'description'     => $c->description,
        'evidence_urls'   => $c->evidence_urls,
        'status'          => $c->status,
        'priority'        => $c->priority,
        'assigned_to'     => $c->assigned_to,
        'resolution'      => $c->resolution,
        'resolved_at'     => $c->resolved_at,
        'sla_deadline'    => $c->sla_deadline,
        'sla_state'       => ridego_app_admin_api_complaint_sla_state( $c->sla_deadline, $c->status ),
        'created_at'      => $c->created_at,
        'updated_at'      => $c->updated_at,
    );
}

/** Copied verbatim from admin/pages/complaints.php:59-77 (filters, search, pagination, KPIs). */
function ridego_app_admin_api_complaints_list( WP_REST_Request $req ) {
    global $wpdb;
    $ctbl = $wpdb->prefix . 'ridego_complaints';
    $btbl = $wpdb->prefix . 'ridego_bookings';
    $vtbl = $wpdb->prefix . 'ridego_vendors';

    $sf = sanitize_key( (string) $req->get_param( 'status' ) );
    $pf = sanitize_key( (string) $req->get_param( 'priority' ) );
    $q  = sanitize_text_field( (string) $req->get_param( 's' ) );
    $page = max( 1, (int) $req->get_param( 'page' ) );
    $per  = 25;
    $off  = ( $page - 1 ) * $per;

    $w = 'WHERE 1=1';
    $v = array();
    if ( $sf ) { $w .= ' AND c.status=%s'; $v[] = $sf; }
    if ( $pf ) { $w .= ' AND c.priority=%s'; $v[] = $pf; }
    if ( $q !== '' ) {
        $w .= ' AND (c.complaint_id LIKE %s OR b.booking_number LIKE %s OR b.client_name LIKE %s OR b.client_phone LIKE %s OR vend.business_name LIKE %s)';
        $like = '%' . $wpdb->esc_like( $q ) . '%';
        $v[] = $like; $v[] = $like; $v[] = $like; $v[] = $like; $v[] = $like;
    }

    $joins = "LEFT JOIN $btbl b ON b.id=c.booking_id LEFT JOIN $vtbl vend ON vend.id=b.vendor_id";
    $total = $v
        ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ctbl c $joins $w", $v ) )
        : (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ctbl c $joins $w" );

    $sql = "SELECT c.*,b.booking_number,b.client_name,vend.business_name AS vendor_name FROM $ctbl c $joins $w ORDER BY FIELD(c.priority,'urgent','high','normal','low'),c.created_at DESC LIMIT %d OFFSET %d";
    $rows = $v
        ? $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $v, array( $per, $off ) ) ) )
        : $wpdb->get_results( $wpdb->prepare( $sql, $per, $off ) );

    $open_count     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ctbl WHERE status='open'" );
    $resolved_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ctbl WHERE status='resolved'" );
    $urgent_count   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ctbl WHERE priority='urgent' AND status='open'" );

    return rest_ensure_response( array(
        'rows'     => array_map( 'ridego_app_admin_api_complaint_format', $rows ),
        'total'    => $total,
        'page'     => $page,
        'per_page' => $per,
        'kpis'     => array(
            'open'     => $open_count,
            'urgent'   => $urgent_count,
            'resolved' => $resolved_count,
        ),
    ) );
}

/**
 * Update a single complaint's status/note — same resolved_at
 * stamping logic as admin/pages/complaints.php:16-25:
 *   - status is resolved/closed  -> stamp resolved_at = now
 *   - was non-open, now reopened to 'open' -> clear resolved_at
 *   - otherwise (e.g. open -> in_progress) -> leave resolved_at alone
 */
function ridego_app_admin_api_complaints_update( WP_REST_Request $req ) {
    global $wpdb;
    $ctbl = $wpdb->prefix . 'ridego_complaints';

    $id     = (int) $req->get_param( 'id' );
    $note   = sanitize_textarea_field( (string) $req->get_param( 'admin_note' ) );
    $status = sanitize_key( (string) ( $req->get_param( 'new_status' ) ?: 'open' ) );

    $valid_statuses = array( 'open', 'in_progress', 'resolved', 'closed', 'disputed' );
    if ( ! in_array( $status, $valid_statuses, true ) ) {
        return new WP_Error( 'invalid_status', 'Invalid status.', array( 'status' => 400 ) );
    }

    $old = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ctbl WHERE id=%d", $id ), ARRAY_A );
    if ( ! $old ) {
        return new WP_Error( 'not_found', 'Complaint not found.', array( 'status' => 404 ) );
    }

    $upd = array( 'status' => $status, 'updated_at' => current_time( 'mysql' ) );
    if ( $note !== '' ) { $upd['resolution'] = $note; }
    if ( in_array( $status, array( 'resolved', 'closed' ), true ) ) {
        $upd['resolved_at'] = current_time( 'mysql' );
    } elseif ( ( $old['status'] ?? '' ) !== 'open' && $status === 'open' ) {
        $upd['resolved_at'] = null;
    }

    $ok = $wpdb->update( $ctbl, $upd, array( 'id' => $id ) );
    if ( $ok === false ) {
        return new WP_Error( 'update_failed', 'Could not update complaint: ' . $wpdb->last_error, array( 'status' => 500 ) );
    }

    ridego_audit_log( 'complaint_updated', 'complaint', $id, $old, $upd );

    return rest_ensure_response( array( 'success' => true, 'message' => 'Complaint updated.' ) );
}

/** Copied verbatim from admin/pages/complaints.php:34-58 (bulk status change). */
function ridego_app_admin_api_complaints_bulk_status( WP_REST_Request $req ) {
    global $wpdb;
    $ctbl = $wpdb->prefix . 'ridego_complaints';

    $bulk_status = sanitize_key( (string) $req->get_param( 'status' ) );
    $ids_raw     = $req->get_param( 'ids' );
    $ids         = is_array( $ids_raw ) ? array_map( 'absint', $ids_raw ) : array();
    $ids         = array_values( array_filter( array_unique( $ids ) ) );

    $valid_statuses = array( 'open', 'in_progress', 'resolved', 'closed' );
    if ( empty( $ids ) ) {
        return new WP_Error( 'no_ids', 'No complaints selected.', array( 'status' => 400 ) );
    }
    if ( ! in_array( $bulk_status, $valid_statuses, true ) ) {
        return new WP_Error( 'invalid_status', 'Invalid bulk status.', array( 'status' => 400 ) );
    }

    $updated = 0;
    $skipped = array();
    foreach ( $ids as $cid ) {
        $old = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $ctbl WHERE id=%d", $cid ), ARRAY_A );
        if ( ! $old ) { $skipped[] = "#{$cid} (not found)"; continue; }
        if ( $old['status'] === $bulk_status ) {
            $skipped[] = ( $old['complaint_id'] ?: "#{$cid}" ) . ' (already ' . $bulk_status . ')';
            continue;
        }
        $upd = array( 'status' => $bulk_status, 'updated_at' => current_time( 'mysql' ) );
        if ( in_array( $bulk_status, array( 'resolved', 'closed' ), true ) ) {
            $upd['resolved_at'] = current_time( 'mysql' );
        }
        $r = $wpdb->update( $ctbl, $upd, array( 'id' => $cid ) );
        if ( $r === false ) {
            $skipped[] = ( $old['complaint_id'] ?: "#{$cid}" ) . ' (db error)';
            continue;
        }
        ridego_audit_log( 'bulk_complaint_status', 'complaint', $cid, $old, $upd );
        $updated++;
    }

    return rest_ensure_response( array(
        'success' => true,
        'updated' => $updated,
        'skipped' => $skipped,
    ) );
}
