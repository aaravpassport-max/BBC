<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   RIDEGO SCHEMA MIGRATION FRAMEWORK
   ------------------------------------------------------------
   Root-cause fix for the "schema vs. code drift" pattern found
   throughout the original codebase (promo codes, surge pricing,
   routes, OTP, notification queue, complaints, security log all
   had application code referencing columns that did not exist).

   Every schema change from this point forward MUST be expressed
   as a numbered, idempotent migration here — never as an ad hoc
   CREATE TABLE/ALTER TABLE bolted into a hook elsewhere in the
   plugin (the old `wallet_transactions` table created on every
   `init` in ridego-platform.php was exactly that anti-pattern
   and has been removed).

   Each migration:
     - has a strictly increasing integer version
     - is idempotent (safe to run repeatedly; checks before acting)
     - is wrapped in a try/catch so one failing migration does not
       block the others, and failures are recorded for the admin
       Tools page to surface
     - is run inside a single DB transaction where the storage
       engine supports it (InnoDB DDL is not transactional in
       MySQL, but we still wrap data-fixups that accompany a
       migration)
   ============================================================ */

// ROOT-CAUSE FIX (recurring class of bug): this constant has repeatedly been
// left behind the actual highest migration version defined below — it was
// stuck at 36 while migrations up to 39 existed (client CRM registration
// sync, booking-notes edit/delete, client-profile merge never ran), bumped to
// 42, and then migration 43 (route-page card_image_url, used by the Home
// Page "Popular Outstation Routes" cards) was added to includes/migrations-
// marketplace.php without this constant being bumped again — so 43 silently
// never ran on any site, meaning ridego_app_api_popular_routes() could query
// a column that doesn't exist on that install and return nothing.
//
// To stop this class of bug from recurring, RIDEGO_SCHEMA_VERSION is no
// longer a hand-maintained number: it's computed from the actual migration
// list below (the true source of truth) the first time this file loads.
// ridego_get_migrations() is defined further down in this same file, so we
// require it up front and compute the max version from it directly.
require_once __DIR__ . '/migrations-marketplace.php';
if ( ! function_exists( 'ridego_compute_schema_version' ) ) {
	function ridego_compute_schema_version() {
		$migrations = function_exists( 'ridego_get_migrations' ) ? ridego_get_migrations() : array();
		$max        = 0;
		foreach ( $migrations as $migration ) {
			if ( isset( $migration['version'] ) && (int) $migration['version'] > $max ) {
				$max = (int) $migration['version'];
			}
		}
		return $max;
	}
}
define( 'RIDEGO_SCHEMA_VERSION', max( 42, ridego_compute_schema_version() ) );

/**
 * Returns the ordered list of migrations. Each entry:
 *   'version'     => int, strictly increasing
 *   'description' => human readable
 *   'callback'    => callable that performs the migration and
 *                     returns true on success, or throws/returns
 *                     a WP_Error-like array ['error' => msg] on
 *                     failure.
 */
function ridego_get_migrations() {
    $base = array(
        array(
            'version'     => 1,
            'description' => 'Baseline: tables created by ridego_install_tables() as of v1.0.0',
            'callback'    => '__return_true', // baseline marker only, no-op
        ),
        array(
            'version'     => 2,
            'description' => 'Schema reconciliation: fix all confirmed code/schema mismatches (promo codes, surge pricing, routes, OTP, notification queue, security log, wallet ledger dedup, vendor document expiry).',
            'callback'    => 'ridego_migration_002_schema_reconciliation',
        ),
        array(
            'version'     => 3,
            'description' => 'Wave 2A security hardening: atomic rate-limit table (replaces transient-based TOCTOU-prone rate limiting) and tamper-evidence checksum column on the audit log.',
            'callback'    => 'ridego_migration_003_security_hardening',
        ),
        array(
            'version'     => 4,
            'description' => 'Wave 2B payments: UNIQUE (gateway, gateway_ref) index on ridego_transactions — the structural idempotency backstop for the Razorpay webhook handler.',
            'callback'    => 'ridego_migration_004_transaction_idempotency',
        ),
        array(
            'version'     => 5,
            'description' => 'Wave 2D: notification queue dead-letter support + subscription billing indexes.',
            'callback'    => 'ridego_migration_005_notifications_and_subscriptions',
        ),
        array(
            'version'     => 6,
            'description' => 'Wave 3: sub-city zones (ridego_zones, center-point + radius model) and zone_id scoping on ridego_surge_pricing.',
            'callback'    => 'ridego_migration_006_zones',
        ),
        array(
            'version'     => 7,
            'description' => 'Atomic booking-number counter table (ridego_counters) — replaces the racy COUNT(*)+1 booking-number generator that could hand out duplicate numbers under concurrent bookings.',
            'callback'    => 'ridego_migration_007_booking_number_counter',
        ),
        array(
            'version'     => 8,
            'description' => 'is_read/read_at columns on ridego_notifications — turns the notification dispatch log into a real in-app notifications inbox for the React app.',
            'callback'    => 'ridego_migration_008_notifications_inbox',
        ),
        array(
            'version'     => 9,
            'description' => 'Wave 24 (financial/wallet): add transaction_type, balance_before, reference_id, created_by columns to ridego_vendor_wallets — the canonical wallet functions (ridego_vendor_credit_wallet, ridego_vendor_deduct_wallet, ridego_reconcile_vendor_wallet in includes/helpers.php) have been writing these keys into $wpdb->insert() since introduction, but the table never had the matching columns, so WordPress silently dropped them on every single wallet transaction. Root-cause fix: add the missing columns rather than strip the keys from the insert calls.',
            'callback'    => 'ridego_migration_009_wallet_ledger_columns',
        ),
        array(
            'version'     => 10,
            'description' => 'ridego_otp columns/width fix — ridego_generate_otp() (includes/otp.php) writes user_id and ip_address into $wpdb->insert() and stores wp_hash($otp) (32+ chars) into the otp column, but the CREATE TABLE for ridego_otp (includes/install.php) never defined user_id/ip_address and sized otp as VARCHAR(6). Every OTP-send insert was failing outright, so phone verification during booking always returned "Failed to generate OTP. Please try again."',
            'callback'    => 'ridego_migration_010_otp_columns',
        ),
        array(
            'version'     => 11,
            'description' => 'Create the missing ridego_otp_log table — ridego_log_otp_event() and ridego_cleanup_expired_otps() (includes/otp.php) have always written to and read from wp_ridego_otp_log, but install.php never had a CREATE TABLE for it (only ridego_otp itself). Every OTP send/verify event was throwing a "table doesn\'t exist" DB error the moment it tried to log the event, which ridego_generate_otp() treated as a fatal failure and reported to the caller as "Failed to send OTP" — even after migration 010 fixed the ridego_otp table itself.',
            'callback'    => 'ridego_migration_011_otp_log_table',
        ),
        array(
            'version'     => 12,
            'description' => 'Token Amount / Advance Payment feature: token_amount snapshot column on ridego_bookings, plus the refund-tracking columns (refund_amount, refund_reason, refund_initiated_at, refund_transaction_id, refund_processed_at, payment_gateway_id) that ridego_process_refund()/ridego_mark_refund_processed() (includes/payment.php) have always referenced but which never existed in the schema — that code has been dead/unreachable until now. The existing status column (VARCHAR(40)) already comfortably fits the new "token_refund_due" status value, so no width change is needed.',
            'callback'    => 'ridego_migration_012_token_amount_and_refunds',
        ),
        array(
            'version'     => 13,
            'description' => 'Add discount_amount + ip_address columns to ridego_promo_usage — ridego_record_promo_usage() (includes/promo.php) has always $wpdb->insert()-ed a `discount` and an `ip_address` key into this table, but the CREATE TABLE (includes/install.php) never defined either column, so every single promo-code redemption insert has been failing outright since this table was introduced. ridego_create_booking() treats that failure as "lost the race" and silently strips the discount from the booking — meaning promo codes have never actually applied to a real booking, only to the live fare preview shown before submit.',
            'callback'    => 'ridego_migration_013_promo_usage_columns',
        ),
        array(
            'version'     => 14,
            'description' => 'Origin/destination city roles: adds is_origin_enabled and is_destination_enabled to ridego_cities (both default 1, so every existing city keeps working as both a pickup and a drop city with no behavior change). Lets the admin mark a city as pickup-only, drop-only, or both — e.g. a small hill-station destination that is never itself a pickup point — without touching the existing city list, CRUD, or fare/route-distance logic, which is entirely unaffected by this column.',
            'callback'    => 'ridego_migration_014_city_origin_destination_roles',
        ),
    );
    $base[] = array(
        'version'     => 44,
        'description' => 'Independent Email OTP Verification: adds an `email` column (nullable, keyed) to ridego_otp so a code can be generated/verified against an email address the same way ridego_generate_otp()/ridego_verify_otp() already do for `phone` — see ridego_generate_email_otp()/ridego_verify_email_otp() in includes/otp.php. Purely additive: `phone` stays NOT NULL (email-only OTP rows store phone as an empty string), so every existing phone-OTP row and query is unaffected.',
        'callback'    => 'ridego_migration_044_email_otp_column',
    );
    $base[] = array(
        'version'     => 45,
        'description' => 'Passenger & Safety Information: adds passenger_total, passenger_male, passenger_female, passenger_children (all nullable ints, default NULL so an existing booking with none of this data is visibly "not collected" rather than silently 0) and passenger_notes (nullable text) to ridego_bookings. Captured by the new dedicated booking-flow step and read by ridego_booking_is_safety_sensitive() (includes/helpers.php) to flag a booking as safety-sensitive (female-only, or includes children) for the vendor-matching/assignment screens — see includes/matching.php.',
        'callback'    => 'ridego_migration_045_passenger_safety_info',
    );
    /* v15-v21: marketplace architecture (includes/migrations-marketplace.php). */
    if ( function_exists( 'ridego_get_marketplace_migrations' ) ) {
        $base = array_merge( $base, ridego_get_marketplace_migrations() );
    }
    return $base;
}

/**
 * v14: origin/destination role flags on ridego_cities. See the
 * description above — both columns default to 1 so this is purely
 * additive for every existing row; nothing that already reads
 * ridego_cities changes behavior until the admin UI/API start writing
 * non-default values for specific cities.
 */
function ridego_migration_014_city_origin_destination_roles() {
    global $wpdb;
    $tbl = "{$wpdb->prefix}ridego_cities";

    if ( ! ridego_table_exists( $tbl ) ) { return true; }

    ridego_add_column_if_missing( $tbl, 'is_origin_enabled', "TINYINT(1) NOT NULL DEFAULT 1" );
    ridego_add_column_if_missing( $tbl, 'is_destination_enabled', "TINYINT(1) NOT NULL DEFAULT 1" );

    return true;
}

/**
 * v44: email column on ridego_otp — see the migration-list description
 * above. Lets ridego_generate_email_otp()/ridego_verify_email_otp()
 * (includes/otp.php) look up/store an OTP row keyed by email+purpose
 * exactly the way the existing phone functions do by phone+purpose,
 * reusing the same table, attempt counter, expiry, and hashing logic
 * rather than a parallel table.
 */
function ridego_migration_044_email_otp_column() {
    global $wpdb;
    $tbl = "{$wpdb->prefix}ridego_otp";

    if ( ! ridego_table_exists( $tbl ) ) { return true; }

    ridego_add_column_if_missing( $tbl, 'email', "VARCHAR(190) NOT NULL DEFAULT ''" );
    ridego_add_index_if_missing( $tbl, 'email', 'email' );

    return true;
}

/**
 * v45: Passenger & Safety Information — see this migration's description
 * in ridego_get_migrations() above. All columns nullable/default NULL so
 * every booking placed before this feature simply has no passenger
 * breakdown recorded (never a fabricated 0), and ridego_create_booking()
 * writes real values into these columns from this point on.
 */
function ridego_migration_045_passenger_safety_info() {
    global $wpdb;
    $tbl = "{$wpdb->prefix}ridego_bookings";

    if ( ! ridego_table_exists( $tbl ) ) { return true; }

    ridego_add_column_if_missing( $tbl, 'passenger_total', "SMALLINT UNSIGNED DEFAULT NULL" );
    ridego_add_column_if_missing( $tbl, 'passenger_male', "SMALLINT UNSIGNED DEFAULT NULL" );
    ridego_add_column_if_missing( $tbl, 'passenger_female', "SMALLINT UNSIGNED DEFAULT NULL" );
    ridego_add_column_if_missing( $tbl, 'passenger_children', "SMALLINT UNSIGNED DEFAULT NULL" );
    ridego_add_column_if_missing( $tbl, 'passenger_notes', "TEXT NULL" );

    return true;
}

/**
 * Run any migrations newer than the currently recorded schema version.
 * Safe to call on every admin_init (it no-ops instantly once caught up)
 * and is also explicitly triggered on plugin activation/update.
 */
function ridego_run_migrations() {
    $current = (int) get_option( 'ridego_schema_version', 0 );
    // Back-compat: a site that never had a schema_version option but
    // does have tables from the old flat install is treated as v1.
    if ( $current === 0 ) {
        global $wpdb;
        $exists = $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}ridego_bookings'" );
        $current = $exists ? 1 : 0;
    }

    $migrations = ridego_get_migrations();
    usort( $migrations, function( $a, $b ) { return $a['version'] <=> $b['version']; } );

    $log = get_option( 'ridego_migration_log', array() );
    $ran_any = false;

    foreach ( $migrations as $m ) {
        if ( $m['version'] <= $current ) { continue; }
        if ( ! is_callable( $m['callback'] ) ) {
            $log[] = array(
                'version' => $m['version'], 'status' => 'error',
                'message' => 'Callback not callable: ' . $m['description'],
                'at'      => current_time( 'mysql' ),
            );
            continue; // do not advance version past a broken migration
        }
        try {
            $result = call_user_func( $m['callback'] );
            if ( $result === false || ( is_array( $result ) && ! empty( $result['error'] ) ) ) {
                $log[] = array(
                    'version' => $m['version'], 'status' => 'error',
                    'message' => is_array( $result ) ? $result['error'] : ( 'Migration ' . $m['version'] . ' returned false' ),
                    'at'      => current_time( 'mysql' ),
                );
                break; // stop the chain — later migrations may assume this one succeeded
            }
            $current = $m['version'];
            update_option( 'ridego_schema_version', $current );
            $log[] = array(
                'version' => $m['version'], 'status' => 'success',
                'message' => $m['description'],
                'at'      => current_time( 'mysql' ),
            );
            $ran_any = true;
        } catch ( \Throwable $e ) {
            $log[] = array(
                'version' => $m['version'], 'status' => 'exception',
                'message' => $e->getMessage(),
                'at'      => current_time( 'mysql' ),
            );
            break;
        }
    }

    // Keep the log bounded.
    if ( count( $log ) > 200 ) {
        $log = array_slice( $log, -200 );
    }
    update_option( 'ridego_migration_log', $log );

    if ( $ran_any && function_exists( 'ridego_audit_log' ) ) {
        ridego_audit_log( 'schema_migrated', 'system', 0, '', 'schema_version=' . $current );
    }

    return $current;
}

/* ------------------------------------------------------------
   Column/index helpers — dbDelta cannot reliably add columns to
   an existing table, so real ALTER statements are used, each
   guarded by an information_schema check for idempotency.
   ------------------------------------------------------------ */
function ridego_column_exists( $table, $column ) {
    global $wpdb;
    $found = $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
        DB_NAME, $table, $column
    ) );
    return ( (int) $found ) > 0;
}

function ridego_table_exists( $table ) {
    global $wpdb;
    return $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) === $table;
}

function ridego_add_column_if_missing( $table, $column, $definition ) {
    global $wpdb;
    if ( ! ridego_table_exists( $table ) ) { return false; }
    if ( ridego_column_exists( $table, $column ) ) { return true; }
    $sql = "ALTER TABLE {$table} ADD COLUMN {$column} {$definition}";
    $ok = $wpdb->query( $sql );
    if ( $ok === false ) {
        ridego_log( 'MIGRATION ERROR adding column ' . $column . ' to ' . $table . ': ' . $wpdb->last_error );
        return false;
    }
    return true;
}

function ridego_add_index_if_missing( $table, $index_name, $columns_sql ) {
    global $wpdb;
    if ( ! ridego_table_exists( $table ) ) { return false; }
    $found = $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND INDEX_NAME = %s",
        DB_NAME, $table, $index_name
    ) );
    if ( (int) $found > 0 ) { return true; }
    $ok = $wpdb->query( "ALTER TABLE {$table} ADD INDEX {$index_name} ({$columns_sql})" );
    return $ok !== false;
}

/**
 * Same idempotency check as ridego_add_index_if_missing() but adds a
 * UNIQUE index. Used for the (gateway, gateway_ref) constraint on
 * ridego_transactions — the structural idempotency backstop for the
 * Razorpay webhook handler (Wave 2B Task 5): even if the webhook's
 * pre-check race loses (two deliveries of the same event processed
 * concurrently), the second INSERT fails on this constraint instead of
 * creating a duplicate transaction / double-crediting a wallet.
 *
 * NOTE: if pre-existing duplicate (gateway, gateway_ref) rows already
 * exist in the table (e.g. blank gateway_ref values from pre-webhook
 * manual/cash transactions), adding a UNIQUE index across the whole
 * table would fail. We scope the uniqueness to rows with a non-empty
 * gateway_ref by using a filtered check first; if dupes exist among
 * non-empty gateway_ref rows the index creation is skipped and logged
 * rather than fatally erroring the whole migration chain.
 */
function ridego_add_unique_index_if_missing( $table, $index_name, $columns_sql ) {
    global $wpdb;
    if ( ! ridego_table_exists( $table ) ) { return false; }
    $found = $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND INDEX_NAME = %s",
        DB_NAME, $table, $index_name
    ) );
    if ( (int) $found > 0 ) { return true; }

    // MySQL UNIQUE indexes treat multiple rows with '' in every column as
    // distinct only if at least one column differs; gateway_ref='' rows
    // (manual/cash transactions) would collide with each other under a
    // strict unique index on (gateway, gateway_ref). Guard against that by
    // checking for real duplicates among non-empty gateway_ref rows only.
    $dupe_count = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM (
            SELECT gateway, gateway_ref FROM {$table}
            WHERE gateway_ref IS NOT NULL AND gateway_ref != ''
            GROUP BY gateway, gateway_ref HAVING COUNT(*) > 1
        ) dupes"
    );
    if ( $dupe_count > 0 ) {
        ridego_log( "MIGRATION: skipping unique index {$index_name} on {$table} — {$dupe_count} pre-existing duplicate (gateway,gateway_ref) groups found; needs manual cleanup." );
        return false;
    }

    $ok = $wpdb->query( "ALTER TABLE {$table} ADD UNIQUE INDEX {$index_name} ({$columns_sql})" );
    if ( $ok === false ) {
        ridego_log( 'MIGRATION ERROR adding unique index ' . $index_name . ' to ' . $table . ': ' . $wpdb->last_error );
        return false;
    }
    return true;
}

/* ------------------------------------------------------------
   MIGRATION 002 — schema reconciliation
   ------------------------------------------------------------ */
function ridego_migration_002_schema_reconciliation() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;

    /* ---- 1. PROMO CODES: adopt the richer rule-surface schema
       that includes/promo.php already implements in full, and
       retire the divergent set of columns admin/pages/promo.php
       and includes/pricing.php previously assumed. ---- */
    $promo_tbl = "{$p}ridego_promo_codes";
    $promo_columns = array(
        'description'         => "VARCHAR(255) NOT NULL DEFAULT ''",
        'discount_type'       => "VARCHAR(20) NOT NULL DEFAULT 'percentage'", // canonical going forward; 'type' kept for back-compat read
        'discount_value'      => "DECIMAL(8,2) NOT NULL DEFAULT 0.00",
        'min_booking_amount'  => "DECIMAL(8,2) NOT NULL DEFAULT 0.00",
        'first_booking_only'  => "TINYINT(1) NOT NULL DEFAULT 0",
        'vehicle_type_id'     => "INT UNSIGNED DEFAULT NULL",
        'route_specific'      => "TINYINT(1) NOT NULL DEFAULT 0",
        'from_city'           => "VARCHAR(100) NOT NULL DEFAULT ''",
        'to_city'             => "VARCHAR(100) NOT NULL DEFAULT ''",
        'user_type'           => "VARCHAR(20) NOT NULL DEFAULT 'all'",
        'days_of_week'        => "TEXT DEFAULT NULL",
        'start_date'          => "DATE DEFAULT NULL",
        'expiry_date'         => "DATE DEFAULT NULL",
        'is_public'           => "TINYINT(1) NOT NULL DEFAULT 1",
        'created_by'          => "BIGINT UNSIGNED NOT NULL DEFAULT 0",
        'updated_at'          => "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP",
        'total_discount_given'=> "DECIMAL(12,2) NOT NULL DEFAULT 0.00", // real-time budget tracking
        'budget_cap'          => "DECIMAL(12,2) DEFAULT NULL", // NULL = uncapped
    );
    foreach ( $promo_columns as $col => $def ) {
        ridego_add_column_if_missing( $promo_tbl, $col, $def );
    }
    // Backfill new canonical columns from the legacy ones so existing rows keep working.
    if ( ridego_column_exists( $promo_tbl, 'type' ) && ridego_column_exists( $promo_tbl, 'discount_type' ) ) {
        $wpdb->query( "UPDATE {$promo_tbl} SET discount_type = type WHERE (discount_type IS NULL OR discount_type = '') AND type IS NOT NULL AND type != ''" );
    }
    if ( ridego_column_exists( $promo_tbl, 'value' ) && ridego_column_exists( $promo_tbl, 'discount_value' ) ) {
        $wpdb->query( "UPDATE {$promo_tbl} SET discount_value = value WHERE discount_value = 0 AND value IS NOT NULL AND value != 0" );
    }
    if ( ridego_column_exists( $promo_tbl, 'min_booking' ) && ridego_column_exists( $promo_tbl, 'min_booking_amount' ) ) {
        $wpdb->query( "UPDATE {$promo_tbl} SET min_booking_amount = min_booking WHERE min_booking_amount = 0 AND min_booking IS NOT NULL AND min_booking != 0" );
    }
    if ( ridego_column_exists( $promo_tbl, 'valid_to' ) && ridego_column_exists( $promo_tbl, 'expiry_date' ) ) {
        $wpdb->query( "UPDATE {$promo_tbl} SET expiry_date = valid_to WHERE expiry_date IS NULL AND valid_to IS NOT NULL" );
    }
    if ( ridego_column_exists( $promo_tbl, 'valid_from' ) && ridego_column_exists( $promo_tbl, 'start_date' ) ) {
        $wpdb->query( "UPDATE {$promo_tbl} SET start_date = valid_from WHERE start_date IS NULL AND valid_from IS NOT NULL" );
    }
    // Fast lookup index for the per-user usage-limit COUNT() check in
    // ridego_record_promo_usage() (includes/promo.php) — NOT a unique
    // constraint (ridego_add_index_if_missing() adds a plain index; see
    // ridego_add_unique_index_if_missing() below for the helper that adds
    // a real one, deliberately not used here since guest redemptions all
    // share user_id=0 and a unique index on (promo_id, user_id) would cap
    // every promo at one guest redemption ever). The actual single-use
    // guarantee comes from that COUNT() check running inside the same
    // row-locked transaction as the atomic usage-count increment.
    ridego_add_index_if_missing( "{$p}ridego_promo_usage", 'promo_user', 'promo_id, user_id' );

    /* ---- 2. SURGE PRICING: add city scoping; the multiplier lookup
       code is corrected separately in includes/pricing.php to query
       the real from_date/to_date range columns instead of nonexistent
       `date`/`city` columns — this migration adds the city column that
       genuinely was missing so that correction is actually possible. ---- */
    $surge_tbl = "{$p}ridego_surge_pricing";
    ridego_add_column_if_missing( $surge_tbl, 'city', "VARCHAR(100) DEFAULT NULL" );
    ridego_add_column_if_missing( $surge_tbl, 'zone', "VARCHAR(100) DEFAULT NULL" );
    ridego_add_column_if_missing( $surge_tbl, 'updated_at', "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP" );
    ridego_add_index_if_missing( $surge_tbl, 'city_dates', 'city, from_date, to_date' );

    /* ---- 3. ROUTES: add the fixed-price/toll fields the pricing
       engine already expected, plus a per-vehicle override table
       (proper normalized design rather than one flat column pair,
       since a route's toll/fixed price legitimately differs by
       vehicle class). ---- */
    $routes_tbl = "{$p}ridego_routes";
    ridego_add_column_if_missing( $routes_tbl, 'toll_estimate', "DECIMAL(8,2) DEFAULT NULL" );
    ridego_add_column_if_missing( $routes_tbl, 'default_fixed_price', "DECIMAL(10,2) DEFAULT NULL" );

    $route_vp_tbl = "{$p}ridego_route_vehicle_pricing";
    if ( ! ridego_table_exists( $route_vp_tbl ) ) {
        dbDelta( "CREATE TABLE IF NOT EXISTS {$route_vp_tbl} (
            id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
            route_id      INT UNSIGNED NOT NULL,
            vehicle_id    INT UNSIGNED NOT NULL,
            fixed_price   DECIMAL(10,2) DEFAULT NULL,
            toll_estimate DECIMAL(8,2) DEFAULT NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY route_vehicle (route_id, vehicle_id),
            KEY route_id (route_id)
        ) $c;" );
    }

    /* ---- 4. OTP TABLE: add the columns the verification code
       actually writes (verified_at/verified_ip for audit purposes).
       otp_plain is intentionally NOT restored as a persistent
       plaintext column — the original code already nulls it out
       immediately after use (otp.php) and hashed `otp` is the
       column used for comparison; we add otp_plain as a short-lived
       nullable field purely to preserve that existing send-time
       behaviour without storing plaintext OTPs long-term. ---- */
    $otp_tbl = "{$p}ridego_otp";
    ridego_add_column_if_missing( $otp_tbl, 'otp_plain', "VARCHAR(10) DEFAULT NULL" );
    ridego_add_column_if_missing( $otp_tbl, 'verified_at', "DATETIME DEFAULT NULL" );
    ridego_add_column_if_missing( $otp_tbl, 'verified_ip', "VARCHAR(45) NOT NULL DEFAULT ''" );

    /* ---- 5. NOTIFICATION QUEUE: add priority column the cron
       processor sorts by; recipient_id already exists and is now
       the single canonical field (the processor code is fixed to
       stop referencing a nonexistent user_id). ---- */
    $nq_tbl = "{$p}ridego_notification_queue";
    ridego_add_column_if_missing( $nq_tbl, 'priority', "VARCHAR(10) NOT NULL DEFAULT 'normal'" );
    ridego_add_column_if_missing( $nq_tbl, 'next_retry_at', "DATETIME DEFAULT NULL" );
    ridego_add_index_if_missing( $nq_tbl, 'priority_created', 'priority, created_at' );
    ridego_add_index_if_missing( $nq_tbl, 'next_retry_at', 'next_retry_at' );

    /* ---- 6. SECURITY LOG: table referenced throughout security.php
       and otp.php but never created anywhere — this was a silent,
       total logging failure. ---- */
    $seclog_tbl = "{$p}ridego_security_log";
    if ( ! ridego_table_exists( $seclog_tbl ) ) {
        dbDelta( "CREATE TABLE IF NOT EXISTS {$seclog_tbl} (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_type VARCHAR(50)     NOT NULL,
            identifier VARCHAR(150)    NOT NULL DEFAULT '',
            ip_address VARCHAR(45)     NOT NULL DEFAULT '',
            user_id    BIGINT UNSIGNED DEFAULT NULL,
            details    TEXT            NOT NULL DEFAULT '',
            severity   VARCHAR(20)     NOT NULL DEFAULT 'info',
            created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY event_type (event_type),
            KEY identifier (identifier),
            KEY created_at (created_at)
        ) $c;" );
    }

    /* ---- 7. WALLET LEDGER: the old codebase created a *second*,
       parallel `ridego_wallet_transactions` table on every `init`
       hook as a patch for a naming mismatch in dummy-data seeding.
       That hook has been removed (see ridego-platform.php); if the
       stray table exists from a previous install we migrate any
       rows into the canonical `ridego_vendor_wallets` ledger and
       drop it, so there is exactly one wallet ledger going forward. ---- */
    $stray_tbl = "{$p}ridego_wallet_transactions";
    $canon_tbl = "{$p}ridego_vendor_wallets";
    if ( ridego_table_exists( $stray_tbl ) && ridego_table_exists( $canon_tbl ) ) {
        $rows = $wpdb->get_results( "SELECT * FROM {$stray_tbl}" );
        foreach ( $rows as $r ) {
            // Avoid duplicating rows already migrated on a prior partial run.
            $dupe = $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$canon_tbl} WHERE vendor_id=%d AND amount=%f AND created_at=%s",
                $r->vendor_id, $r->amount, $r->created_at
            ) );
            if ( (int) $dupe > 0 ) { continue; }
            $wpdb->insert( $canon_tbl, array(
                'vendor_id'     => (int) $r->vendor_id,
                'type'          => isset( $r->type ) ? $r->type : 'credit',
                'amount'        => (float) $r->amount,
                'balance_after' => isset( $r->balance_after ) ? (float) $r->balance_after : 0.00,
                'booking_id'    => isset( $r->booking_id ) ? $r->booking_id : null,
                'notes'         => isset( $r->notes ) ? ( $r->notes . ' [migrated from legacy wallet_transactions table]' ) : '[migrated from legacy wallet_transactions table]',
                'created_at'    => $r->created_at,
            ) );
        }
        $wpdb->query( "DROP TABLE {$stray_tbl}" );
    }

    /* ---- 8. COMPLAINTS: schema columns were already correct
       (raised_by_id/raised_by_type/complaint_id/assigned_to/
       sla_deadline all exist); the bug was in the INSERT code in
       includes/complaints.php writing to a nonexistent `raised_by`
       key, which is fixed in that file, not here. No DDL needed,
       but we add a helpful index for SLA-breach queries. ---- */
    ridego_add_index_if_missing( "{$p}ridego_complaints", 'sla_deadline', 'sla_deadline' );

    /* ---- 9. AUDIT LOG: add severity + category so the unified
       logging pipeline (audit_log becomes the single source of
       truth, replacing the old split of audit_log/activity-log/
       security-log for administrative — as opposed to security —
       events) can filter/alert meaningfully. ---- */
    ridego_add_column_if_missing( "{$p}ridego_audit_log", 'severity', "VARCHAR(20) NOT NULL DEFAULT 'info'" );

    /* ---- 10. VENDOR DOCUMENT EXPIRY tracking support: add a
       computed-friendly `next_expiry_check` column to vendors so
       the expiry cron (built in Wave 2C) has a cheap index to scan
       instead of computing expiry status across three separate date
       columns on every run. ---- */
    ridego_add_column_if_missing( "{$p}ridego_vendors", 'expiry_alert_sent_at', "DATETIME DEFAULT NULL" );
    ridego_add_index_if_missing( "{$p}ridego_vendors", 'license_expiry', 'license_expiry' );
    ridego_add_index_if_missing( "{$p}ridego_vendors", 'insurance_expiry', 'insurance_expiry' );
    ridego_add_index_if_missing( "{$p}ridego_driver_docs", 'expiry_date_status', 'expiry_date, status' );

    /* ---- 11. SUBSCRIPTIONS: support columns for a real billing
       lifecycle (built out in Wave 2D). ---- */
    ridego_add_column_if_missing( "{$p}ridego_vendors", 'subscription_status', "VARCHAR(20) NOT NULL DEFAULT 'none'" );
    $sub_billing_tbl = "{$p}ridego_subscription_billing";
    if ( ! ridego_table_exists( $sub_billing_tbl ) ) {
        dbDelta( "CREATE TABLE IF NOT EXISTS {$sub_billing_tbl} (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            vendor_id    INT UNSIGNED    NOT NULL,
            plan_id      INT UNSIGNED    NOT NULL,
            amount       DECIMAL(8,2)    NOT NULL DEFAULT 0.00,
            status       VARCHAR(20)     NOT NULL DEFAULT 'pending',
            gateway_ref  VARCHAR(100)    NOT NULL DEFAULT '',
            period_start DATE            DEFAULT NULL,
            period_end   DATE            DEFAULT NULL,
            attempts     TINYINT         NOT NULL DEFAULT 0,
            created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY vendor_id (vendor_id),
            KEY status (status),
            KEY period_end (period_end)
        ) $c;" );
    }

    return true;
}

/* ------------------------------------------------------------
   MIGRATION 003 — security hardening (Wave 2A)
   ------------------------------------------------------------ */
/* ------------------------------------------------------------
   MIGRATION 004 — transaction idempotency (Wave 2B)
   ------------------------------------------------------------ */
function ridego_migration_004_transaction_idempotency() {
    global $wpdb;
    $p = $wpdb->prefix;
    $tx_tbl = "{$p}ridego_transactions";

    if ( ! ridego_table_exists( $tx_tbl ) ) { return true; }

    // A UNIQUE index on (gateway, gateway_ref) with gateway_ref as a plain
    // NOT NULL VARCHAR would collide every manual/cash transaction (which
    // has gateway_ref='') against every other one. MySQL unique indexes
    // treat NULL as distinct-from-every-other-NULL, so gateway_ref is
    // switched to nullable and existing '' values backfilled to NULL —
    // only real gateway references (Razorpay payment/refund IDs) then
    // participate in the uniqueness constraint, which is exactly the set
    // of rows the webhook idempotency guarantee needs to cover.
    $wpdb->query( "ALTER TABLE {$tx_tbl} MODIFY gateway_ref VARCHAR(100) DEFAULT NULL" );
    $wpdb->query( "UPDATE {$tx_tbl} SET gateway_ref = NULL WHERE gateway_ref = ''" );

    ridego_add_unique_index_if_missing( $tx_tbl, 'gateway_ref_unique', 'gateway, gateway_ref' );

    return true;
}

/* ------------------------------------------------------------
   MIGRATION 005 — Wave 2D notifications + subscriptions
   ------------------------------------------------------------ */
function ridego_migration_005_notifications_and_subscriptions() {
    global $wpdb;
    $p = $wpdb->prefix;

    /* ---- NOTIFICATION QUEUE: priority/next_retry_at already added in
       migration 002 — verify idempotently rather than assume. The
       'status' column is VARCHAR(20) which comfortably holds the new
       'dead_letter' status (11 chars); widen defensively anyway in case
       a prior install has a narrower column from an even older schema. ---- */
    $nq_tbl = "{$p}ridego_notification_queue";
    ridego_add_column_if_missing( $nq_tbl, 'priority', "VARCHAR(10) NOT NULL DEFAULT 'normal'" );
    ridego_add_column_if_missing( $nq_tbl, 'next_retry_at', "DATETIME DEFAULT NULL" );
    ridego_add_index_if_missing( $nq_tbl, 'priority_created', 'priority, created_at' );
    ridego_add_index_if_missing( $nq_tbl, 'next_retry_at', 'next_retry_at' );
    ridego_add_index_if_missing( $nq_tbl, 'status_retry', 'status, next_retry_at' );
    if ( ridego_table_exists( $nq_tbl ) ) {
        $wpdb->query( "ALTER TABLE {$nq_tbl} MODIFY status VARCHAR(20) NOT NULL DEFAULT 'pending'" );
    }

    /* ---- VENDORS: subscription lifecycle columns. subscription_status
       already exists (migration 002); add the plan pointer + expiry that
       ridego_get_eligible_vendors()/ridego_calculate_lead_fee() now join
       against, plus a dunning attempt counter used by the renewal cron. ---- */
    $v_tbl = "{$p}ridego_vendors";
    ridego_add_column_if_missing( $v_tbl, 'subscription_plan_id', "INT UNSIGNED DEFAULT NULL" );
    ridego_add_column_if_missing( $v_tbl, 'subscription_expires', "DATETIME DEFAULT NULL" );
    ridego_add_column_if_missing( $v_tbl, 'subscription_renewal_attempts', "TINYINT NOT NULL DEFAULT 0" );
    ridego_add_index_if_missing( $v_tbl, 'subscription_plan_id', 'subscription_plan_id' );
    ridego_add_index_if_missing( $v_tbl, 'subscription_expires', 'subscription_expires' );

    /* ---- SUBSCRIPTION BILLING: table already created in migration 002;
       verify the columns/indexes this wave's renewal + dunning logic
       relies on. ---- */
    $sb_tbl = "{$p}ridego_subscription_billing";
    ridego_add_index_if_missing( $sb_tbl, 'vendor_status', 'vendor_id, status' );

    return true;
}

/**
 * Wave 3: sub-city zones for scoping surge pricing.
 *
 * Data model decision — center-point + radius, not a full GeoJSON
 * polygon: grep across the codebase found no existing ridego_zones
 * table and no code anywhere actually consuming a polygon (the only
 * prior mention was the README noting "zones" as a schema concept in
 * passing). A polygon needs a map-drawing UI and a real point-in-
 * polygon test to be worth anything; a center-point + radius model is
 * trivial to author from a plain admin form (lat/lng + a radius
 * number field) and the containment check is a single haversine-
 * distance comparison (see ridego_get_zone_for_point() in
 * includes/helpers.php) — simpler, and sufficient for "is this pickup
 * near the airport / near downtown" style surge scoping.
 *
 * ridego_surge_pricing.zone (VARCHAR) already existed as a free-text
 * display label entered by the admin (see admin/pages/surge.php) with
 * no relational meaning at all — ridego_get_surge_multiplier() never
 * actually read it. Rather than migrate/repurpose that column (which
 * would risk breaking existing rules that only ever used it as a
 * label), it is kept exactly as-is for display, and the new zone_id
 * column is the real relational scoping field a rule can optionally
 * be pinned to. This is the less disruptive of the two options.
 */
function ridego_migration_006_zones() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;

    $zones_tbl = "{$p}ridego_zones";
    if ( ! ridego_table_exists( $zones_tbl ) ) {
        dbDelta( "CREATE TABLE IF NOT EXISTS {$zones_tbl} (
            id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
            city_id     INT UNSIGNED NOT NULL,
            name        VARCHAR(100) NOT NULL,
            center_lat  DECIMAL(10,8) NOT NULL,
            center_lng  DECIMAL(11,8) NOT NULL,
            radius_km   DECIMAL(6,2) NOT NULL DEFAULT 3.00,
            is_active   TINYINT(1)   NOT NULL DEFAULT 1,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY city_id (city_id),
            KEY is_active (is_active)
        ) $c;" );
    }

    /* zone_id on surge_pricing: nullable (a rule with no zone_id still
       applies city/plugin-wide, same as before), FK-by-convention to
       ridego_zones.id like every other relation in this schema. */
    ridego_add_column_if_missing( "{$p}ridego_surge_pricing", 'zone_id', "INT UNSIGNED DEFAULT NULL" );
    ridego_add_index_if_missing( "{$p}ridego_surge_pricing", 'zone_id', 'zone_id' );

    return true;
}

function ridego_migration_003_security_hardening() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;

    /* ---- 1. RATE LIMITS: dedicated table so ridego_check_rate_limit()
       can use a single atomic INSERT ... ON DUPLICATE KEY UPDATE instead
       of a transient read-then-write, which had a TOCTOU race allowing
       an attacker to exceed the configured attempt limit by firing
       concurrent requests. ---- */
    $rl_tbl = "{$p}ridego_rate_limits";
    if ( ! ridego_table_exists( $rl_tbl ) ) {
        dbDelta( "CREATE TABLE IF NOT EXISTS {$rl_tbl} (
            id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
            limit_key         VARCHAR(191) NOT NULL,
            count             INT UNSIGNED NOT NULL DEFAULT 1,
            window_started_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY limit_key (limit_key)
        ) $c;" );
    }

    /* ---- 2. AUDIT LOG tamper-evidence: a checksum column computed at
       write time from the row's own fields + wp_salt('auth'). See the
       doc comment on ridego_audit_log() in includes/helpers.php for the
       verification formula. ---- */
    ridego_add_column_if_missing( "{$p}ridego_audit_log", 'checksum', "VARCHAR(64) NOT NULL DEFAULT ''" );

    return true;
}

/**
 * v7: dedicated single-row-per-counter table so booking numbers (and any
 * future sequence-style ids) can be generated with a single atomic
 * INSERT ... ON DUPLICATE KEY UPDATE instead of the old
 * "SELECT COUNT(*)+1" pattern, which is a classic TOCTOU race: two
 * concurrent bookings can both read the same count, both compute the same
 * next number, and one of the two INSERTs then fails against the UNIQUE
 * KEY on booking_number — surfacing a raw DB error to a customer who may
 * have already paid. See ridego_generate_booking_number().
 */
function ridego_migration_007_booking_number_counter() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $p = $wpdb->prefix;

    $tbl = "{$p}ridego_counters";
    if ( ! ridego_table_exists( $tbl ) ) {
        dbDelta( "CREATE TABLE IF NOT EXISTS {$tbl} (
            id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
            counter_name  VARCHAR(50) NOT NULL,
            current_value BIGINT UNSIGNED NOT NULL DEFAULT 0,
            updated_at    DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY counter_name (counter_name)
        ) $c;" );
    }

    return true;
}

/**
 * ridego_notifications was, until this wave, a write-only dispatch log
 * that nothing ever read back (and — see the accompanying fix in
 * includes/notifications.php — one whose inserts had actually been
 * failing outright due to a separate schema mismatch). Adding a
 * read/unread flag is what turns it into something a real in-app
 * notifications inbox can be built on, without disturbing any existing
 * column or data.
 */
function ridego_migration_008_notifications_inbox() {
    global $wpdb;
    $p = $wpdb->prefix;

    $tbl = "{$p}ridego_notifications";
    if ( ridego_table_exists( $tbl ) ) {
        ridego_add_column_if_missing( $tbl, 'is_read', "TINYINT(1) NOT NULL DEFAULT 0" );
        ridego_add_column_if_missing( $tbl, 'read_at', "DATETIME DEFAULT NULL" );
        ridego_add_index_if_missing( $tbl, 'user_read_sent', 'user_id, is_read, sent_at' );
    }

    return true;
}

/**
 * v9 (Wave 24, financial/wallet): confirmed-live data-loss bug fix.
 *
 * ridego_vendor_credit_wallet(), ridego_vendor_deduct_wallet(), and
 * ridego_reconcile_vendor_wallet() (includes/helpers.php) all build a
 * $wpdb->insert() array literal containing 'transaction_type',
 * 'balance_before', and 'reference_id' keys targeting
 * ridego_vendor_wallets — but the CREATE TABLE for that table
 * (includes/install.php) only ever defined id/vendor_id/type/amount/
 * balance_after/booking_id/notes/created_at. $wpdb->insert() silently
 * drops array keys that do not match a real column, so every single
 * wallet credit/debit/reconciliation since these functions were
 * introduced has been discarding this data with no error surfaced
 * anywhere — confirmed by direct read of both the function bodies and
 * the CREATE TABLE statement, not assumed.
 *
 * Per this project's root-cause-only remediation standard, the fix is
 * to add the missing columns (idempotent, additive, no data at risk)
 * rather than to strip the keys out of the insert calls and continue
 * discarding this data forever. 'created_by' is also added: the same
 * three functions write it too, and it has the identical silent-drop
 * problem.
 *
 * Nothing can be backfilled for rows already written before this
 * migration runs — that data was never stored anywhere, not even in
 * a log, so it is simply gone for past transactions. Going forward,
 * every new wallet ledger row will retain transaction_type,
 * balance_before, reference_id, and created_by correctly.
 */
function ridego_migration_009_wallet_ledger_columns() {
    global $wpdb;
    $p   = $wpdb->prefix;
    $tbl = "{$p}ridego_vendor_wallets";

    if ( ! ridego_table_exists( $tbl ) ) { return true; }

    ridego_add_column_if_missing( $tbl, 'transaction_type', "VARCHAR(30) NOT NULL DEFAULT ''" );
    ridego_add_column_if_missing( $tbl, 'balance_before', "DECIMAL(10,2) DEFAULT NULL" );
    ridego_add_column_if_missing( $tbl, 'reference_id', "BIGINT UNSIGNED DEFAULT NULL" );
    ridego_add_column_if_missing( $tbl, 'created_by', "BIGINT UNSIGNED DEFAULT NULL" );
    ridego_add_index_if_missing( $tbl, 'transaction_type', 'transaction_type' );

    return true;
}

/**
 * Migration 10: fix ridego_otp so ridego_generate_otp() can actually
 * insert a row. The function (includes/otp.php) writes:
 *   'otp' => wp_hash($otp)   — a 32+ character hash
 *   'user_id' => ...
 *   'ip_address' => ...
 * but the original CREATE TABLE (includes/install.php) sized 'otp' as
 * VARCHAR(6) (room for the plaintext code only) and never defined
 * user_id/ip_address at all. The resulting $wpdb->insert() fails
 * every time (unknown column, and/or data too long for column), so
 * ridego_generate_otp() always falls into its "Failed to generate
 * OTP. Please try again." branch — phone verification is completely
 * broken for every caller (booking flow, login, etc). Root-cause fix:
 * add the missing columns and widen 'otp' to fit the hash.
 */
function ridego_migration_010_otp_columns() {
    global $wpdb;
    $tbl = "{$wpdb->prefix}ridego_otp";

    if ( ! ridego_table_exists( $tbl ) ) { return true; }

    ridego_add_column_if_missing( $tbl, 'user_id', "BIGINT UNSIGNED NOT NULL DEFAULT 0" );
    ridego_add_column_if_missing( $tbl, 'ip_address', "VARCHAR(45) NOT NULL DEFAULT ''" );

    if ( ridego_column_exists( $tbl, 'otp' ) ) {
        $otp_col_type = $wpdb->get_var( $wpdb->prepare(
            "SELECT COLUMN_TYPE FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = 'otp'",
            DB_NAME, $tbl
        ) );
        if ( $otp_col_type && stripos( $otp_col_type, 'varchar(6)' ) !== false ) {
            $ok = $wpdb->query( "ALTER TABLE {$tbl} MODIFY COLUMN otp VARCHAR(64) NOT NULL" );
            if ( $ok === false ) {
                ridego_log( 'MIGRATION ERROR widening otp column on ' . $tbl . ': ' . $wpdb->last_error );
                return array( 'error' => 'Could not widen otp column: ' . $wpdb->last_error );
            }
        }
    }

    return true;
}

/**
 * v11: create ridego_otp_log — see the migration-list description above.
 * Columns match exactly what ridego_log_otp_event() ($wpdb->insert) and
 * ridego_cleanup_expired_otps() (30-day DELETE ... WHERE created_at < ...)
 * in includes/otp.php already read and write.
 */
function ridego_migration_011_otp_log_table() {
    global $wpdb;
    $c   = $wpdb->get_charset_collate();
    $tbl = "{$wpdb->prefix}ridego_otp_log";

    if ( ridego_table_exists( $tbl ) ) { return true; }

    dbDelta( "CREATE TABLE IF NOT EXISTS {$tbl} (
        id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        otp_id     BIGINT UNSIGNED NOT NULL DEFAULT 0,
        event      VARCHAR(50) NOT NULL DEFAULT '',
        data       LONGTEXT NULL,
        ip_address VARCHAR(45) NOT NULL DEFAULT '',
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY otp_id (otp_id),
        KEY created_at (created_at)
    ) $c;" );

    if ( ! ridego_table_exists( $tbl ) ) {
        return array( 'error' => 'Could not create ' . $tbl . ': ' . $wpdb->last_error );
    }

    return true;
}

/**
 * v12: Token Amount / Advance Payment feature (backend schema).
 *
 * 'token_amount' is a per-booking SNAPSHOT of the admin-configured
 * token/advance setting at the moment the booking was created — not a
 * live read of the setting — so that a later admin change to the token
 * amount only ever affects new bookings, never retroactively alters an
 * already-placed booking (see ridego_create_booking() in booking.php).
 *
 * The refund_* / payment_gateway_id columns already have real, live
 * code reading and writing them — ridego_process_refund() and
 * ridego_mark_refund_processed() (includes/payment.php) — but that
 * code has been unreachable dead code because these columns were never
 * created (confirmed by grep against includes/install.php: zero
 * matches). This migration makes that existing code path real, and is
 * a precondition for actually executing (not just calculating) the
 * client token refund from ridego_cancel_booking().
 */
function ridego_migration_012_token_amount_and_refunds() {
    global $wpdb;
    $p   = $wpdb->prefix;
    $tbl = "{$p}ridego_bookings";

    if ( ! ridego_table_exists( $tbl ) ) { return true; }

    ridego_add_column_if_missing( $tbl, 'token_amount', "DECIMAL(10,2) NOT NULL DEFAULT 0.00" );
    ridego_add_column_if_missing( $tbl, 'refund_amount', "DECIMAL(10,2) DEFAULT NULL" );
    ridego_add_column_if_missing( $tbl, 'refund_reason', "VARCHAR(255) NOT NULL DEFAULT ''" );
    ridego_add_column_if_missing( $tbl, 'refund_initiated_at', "DATETIME DEFAULT NULL" );
    ridego_add_column_if_missing( $tbl, 'refund_transaction_id', "VARCHAR(100) NOT NULL DEFAULT ''" );
    ridego_add_column_if_missing( $tbl, 'refund_processed_at', "DATETIME DEFAULT NULL" );
    ridego_add_column_if_missing( $tbl, 'payment_gateway_id', "VARCHAR(100) NOT NULL DEFAULT ''" );
    ridego_add_index_if_missing( $tbl, 'status', 'status' );

    return true;
}

/**
 * v13: fixes a confirmed-live promo-code redemption bug. See this
 * migration's description in ridego_get_migrations() above for the full
 * explanation — in short, ridego_record_promo_usage() (includes/promo.php)
 * writes 'discount' and 'ip_address' into $wpdb->insert() against
 * ridego_promo_usage, but the CREATE TABLE never defined either column, so
 * the insert has always failed and every promo-code booking has always had
 * its discount silently stripped back out. Column name kept as `discount`
 * (not `discount_amount`) to match exactly what the existing, otherwise-
 * correct application code already writes — the minimal, root-cause fix is
 * adding the missing columns, not touching the working insert call.
 */
function ridego_migration_013_promo_usage_columns() {
    global $wpdb;
    $tbl = "{$wpdb->prefix}ridego_promo_usage";

    if ( ! ridego_table_exists( $tbl ) ) { return true; }

    ridego_add_column_if_missing( $tbl, 'discount', "DECIMAL(8,2) NOT NULL DEFAULT 0.00" );
    ridego_add_column_if_missing( $tbl, 'ip_address', "VARCHAR(45) NOT NULL DEFAULT ''" );

    return true;
}
