<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Admin Dashboard (overview) endpoint
   ------------------------------------------------------------
   New React SPA "Admin Dashboard" landing page. Reproduces
   admin/pages/dashboard.php as a single JSON payload so the React
   page can render every KPI/chart/panel from one call (no N+1).

   Reuses the exact same canonical helpers the wp-admin page already
   calls — ridego_get_dashboard_stats() (cached via transient,
   includes every KPI figure + its trend, computed the same way for
   both front ends), ridego_get_setting() (system health checks) and
   ridego_get_no_vendor_staleness_minutes() — rather than
   reimplementing any of that query/business logic here.

   Capability: ridego_view_reports, the same capability
   includes/app-admin-reports-api.php gates its (closely related,
   overview-style) endpoints on — the dashboard is an overview
   surface, not a data-mutating one, so it gets the "view reports"
   grant rather than a narrower manage_* capability.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_dashboard_api_routes' );
function ridego_register_app_admin_dashboard_api_routes() {
    register_rest_route( 'ridego/v1', '/app/admin/dashboard', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_dashboard',
        'permission_callback' => 'ridego_app_admin_api_dashboard_permission',
    ) );
}

function ridego_app_admin_api_dashboard_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_view_reports' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to view the admin dashboard.', array( 'status' => 403 ) );
    }
    return true;
}

function ridego_app_admin_api_dashboard( WP_REST_Request $req ) {
    global $wpdb;
    $btbl = $wpdb->prefix . 'ridego_bookings';
    $vtbl = $wpdb->prefix . 'ridego_vendors';

    // Same canonical stats object the wp-admin dashboard uses (cached
    // 15 minutes via transient) — every KPI value + trend comes from here.
    $s = ridego_get_dashboard_stats();

    /* 7-day revenue chart — same query as admin/pages/dashboard.php */
    $week = $wpdb->get_results(
        "SELECT DATE(created_at) as d, COALESCE(SUM(total_fare),0) as rev, COALESCE(SUM(advance_paid),0) as col, COUNT(*) as cnt
         FROM {$btbl} WHERE created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY) GROUP BY DATE(created_at) ORDER BY d ASC"
    );
    $revenue_7d = array_map( function ( $w ) {
        return array(
            'date'    => $w->d,
            'revenue' => (float) $w->rev,
            'collected' => (float) $w->col,
            'count'   => (int) $w->cnt,
        );
    }, $week );

    /* Recent bookings (activity table) */
    $activity = $wpdb->get_results(
        "SELECT id, booking_number, client_name, status, created_at, journey_date, pickup_city, drop_city, total_fare
         FROM {$btbl} ORDER BY created_at DESC LIMIT 8"
    );
    $recent_bookings = array_map( function ( $b ) {
        return array(
            'id'             => (int) $b->id,
            'booking_number' => $b->booking_number,
            'client_name'    => $b->client_name,
            'pickup_city'    => $b->pickup_city,
            'drop_city'      => $b->drop_city,
            'journey_date'   => $b->journey_date,
            'total_fare'     => (float) $b->total_fare,
            'status'         => $b->status,
            'created_at'     => $b->created_at,
        );
    }, $activity );

    /* Payment proofs pending review */
    $proofs = $wpdb->get_results(
        "SELECT booking_number, client_name, total_fare, payment_method, created_at
         FROM {$btbl} WHERE payment_status='proof_submitted' ORDER BY created_at DESC LIMIT 6"
    );
    $proofs_pending = array_map( function ( $p ) {
        return array(
            'booking_number' => $p->booking_number,
            'client_name'    => $p->client_name,
            'total_fare'     => (float) $p->total_fare,
            'payment_method' => $p->payment_method,
            'created_at'     => $p->created_at,
        );
    }, $proofs );

    /* Trip type distribution, last 30 days */
    $by_type = $wpdb->get_results(
        "SELECT trip_type, COUNT(*) as cnt, COALESCE(SUM(total_fare),0) as rev, COALESCE(SUM(advance_paid),0) as col
         FROM {$btbl} WHERE created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY) GROUP BY trip_type ORDER BY cnt DESC"
    );
    $trips_by_type = array_map( function ( $t ) {
        return array(
            'trip_type' => $t->trip_type,
            'count'     => (int) $t->cnt,
            'revenue'   => (float) $t->rev,
            'collected' => (float) $t->col,
        );
    }, $by_type );

    /* System health checks — same 8 checks/order as admin/pages/dashboard.php */
    $checks = array(
        array( 'key' => 'bank_account',   'label' => 'Bank Account',        'ok' => ! empty( ridego_get_setting( 'bank_account' ) ) ),
        array( 'key' => 'upi_qr',         'label' => 'UPI / QR Set',        'ok' => ! empty( ridego_get_setting( 'upi_id' ) ) ),
        array( 'key' => 'google_maps',    'label' => 'Google Maps Key',     'ok' => ! empty( ridego_get_setting( 'google_maps_key' ) ) ),
        array( 'key' => 'admin_email',    'label' => 'Admin Email',         'ok' => ! empty( ridego_get_setting( 'admin_email' ) ) ),
        array( 'key' => 'support_phone',  'label' => 'Support Phone',       'ok' => ! empty( ridego_get_setting( 'support_phone' ) ) ),
        array( 'key' => 'sms_otp',        'label' => 'SMS / OTP Gateway',   'ok' => ! empty( ridego_get_setting( 'sms_api_key' ) ) || ! empty( ridego_get_setting( 'twilio_sid' ) ) ),
        array( 'key' => 'whatsapp',       'label' => 'WhatsApp / Fonnte',   'ok' => ! empty( ridego_get_setting( 'fonnte_token' ) ) ),
        array( 'key' => 'platform_name',  'label' => 'Platform Name',       'ok' => ! empty( ridego_get_setting( 'platform_name' ) ) ),
    );
    $setup_complete = ! in_array( false, array_column( $checks, 'ok' ), true );

    global $wp_version;

    return rest_ensure_response( array(
        'kpis' => array(
            'bookings_today'          => $s['bookings_today'],
            'bookings_today_trend'    => $s['bookings_today_trend'],
            'bookings_month'          => $s['bookings_month'],
            'bookings_month_trend'    => $s['bookings_month_trend'],
            'revenue_today'           => $s['revenue_today'],
            'revenue_today_trend'     => $s['revenue_today_trend'],
            'revenue_month'           => $s['revenue_month'],
            'revenue_month_trend'     => $s['revenue_month_trend'],
            'lead_fee_month'          => ridego_lead_fee_report( substr( current_time( 'Y-m-d' ), 0, 7 ) . '-01', current_time( 'Y-m-d' ) ),
            'commission_today'        => $s['commission_today'],
            'commission_today_trend'  => $s['commission_today_trend'],
            'commission_month'        => $s['commission_month'],
            'commission_month_trend'  => $s['commission_month_trend'],
            'proof_submitted'         => $s['proof_submitted'],
            'no_vendor_bookings'      => $s['no_vendor_bookings'],
            'no_vendor_stale_minutes' => $s['no_vendor_stale_minutes'],
            'active_trips'            => $s['active_trips'],
            'vendors_pending_kyc'     => $s['vendors_pending_kyc'],
            'low_wallet_vendors'      => $s['low_wallet_vendors'],
            'open_complaints'         => $s['open_complaints'],
            'vendors_active'          => $s['vendors_active'],
            'total_wallet_float'      => $s['total_wallet_float'],
        ),
        'setup_complete'   => $setup_complete,
        'revenue_7d'       => $revenue_7d,
        'trips_by_type_30d'=> $trips_by_type,
        'proofs_pending'   => $proofs_pending,
        'system_health'    => array(
            'checks'      => $checks,
            'plugin_version' => defined( 'RIDEGO_VER' ) ? RIDEGO_VER : '',
            'php_version'    => PHP_VERSION,
            'wp_version'     => isset( $wp_version ) ? $wp_version : '',
        ),
        'recent_bookings'  => $recent_bookings,
    ) );
}
