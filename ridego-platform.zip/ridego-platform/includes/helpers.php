<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   SECRETS AT REST — encryption for API keys/tokens stored in
   wp_ridego_settings.setting_value.
   ------------------------------------------------------------
   Uses AES-256-GCM with a key derived from WordPress's own
   `auth` salt (wp_salt('auth')) via SHA-256, so there is no new
   secret for the site operator to manage or lose. Ciphertext is
   stored as `enc:v1:` + base64(iv . tag . ciphertext) so legacy
   plaintext rows already in the DB (pre-Wave-2A) are trivially
   distinguishable from encrypted ones and can be migrated on the
   next read/write without breaking anything in between.
   ============================================================ */
define( 'RIDEGO_SECRET_PREFIX', 'enc:v1:' );

/**
 * The setting keys that must never be stored in plaintext.
 */
function ridego_get_secret_setting_keys() {
    return array(
        'google_maps_key',
        'sms_api_key',
        'twilio_sid',
        'twilio_token',
        'razorpay_key_id',
        'razorpay_key_secret',
        'razorpay_webhook_secret',
        'fonnte_token',
        'callmebot_key',
        'firebase_api_key',
        'telegram_bot_token',
    );
}

/**
 * Derive the 32-byte AES-256 key from WordPress's own auth salt.
 * Not cached in a variable beyond function scope — cheap to recompute
 * and avoids the key lingering in memory longer than needed.
 */
function ridego_get_secret_encryption_key() {
    return hash( 'sha256', wp_salt( 'auth' ), true );
}

/**
 * Encrypt a secret value for storage. Returns the `enc:v1:` prefixed
 * base64 blob (iv . tag . ciphertext), or the empty string unchanged
 * (nothing to encrypt / nothing to leak).
 */
function ridego_encrypt_secret( $value ) {
    $value = (string) $value;
    if ( $value === '' ) { return ''; }
    $key    = ridego_get_secret_encryption_key();
    $iv_len = openssl_cipher_iv_length( 'aes-256-gcm' );
    $iv     = random_bytes( $iv_len );
    $tag    = '';
    $ciphertext = openssl_encrypt( $value, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
    if ( $ciphertext === false ) {
        // Encryption failure must never silently fall back to plaintext storage.
        ridego_log( 'ridego_encrypt_secret: openssl_encrypt failed' );
        return '';
    }
    return RIDEGO_SECRET_PREFIX . base64_encode( $iv . $tag . $ciphertext );
}

/**
 * Decrypt a value previously produced by ridego_encrypt_secret().
 * Returns the plaintext value that was stored as-is if it does NOT
 * carry the `enc:v1:` marker (legacy plaintext, back-compat), or ''
 * if decryption fails (tampered/corrupt ciphertext, wrong key).
 */
function ridego_decrypt_secret( $value ) {
    $value = (string) $value;
    if ( $value === '' ) { return ''; }
    if ( strpos( $value, RIDEGO_SECRET_PREFIX ) !== 0 ) {
        // Legacy plaintext — not yet encrypted. Caller is responsible for
        // re-saving it (ridego_get_setting() logs this for visibility).
        return $value;
    }
    $raw = base64_decode( substr( $value, strlen( RIDEGO_SECRET_PREFIX ) ), true );
    if ( $raw === false ) { return ''; }
    $iv_len = openssl_cipher_iv_length( 'aes-256-gcm' );
    $tag_len = 16; // GCM auth tag is always 16 bytes.
    if ( strlen( $raw ) < $iv_len + $tag_len ) { return ''; }
    $iv         = substr( $raw, 0, $iv_len );
    $tag        = substr( $raw, $iv_len, $tag_len );
    $ciphertext = substr( $raw, $iv_len + $tag_len );
    $key        = ridego_get_secret_encryption_key();
    $plaintext  = openssl_decrypt( $ciphertext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
    if ( $plaintext === false ) {
        ridego_log( 'ridego_decrypt_secret: decryption failed (tampered ciphertext or wrong key)' );
        return '';
    }
    return $plaintext;
}

/* ============================================================
   SETTINGS - CRUD via wp_ridego_settings table
   ============================================================ */
// ROOT-CAUSE FIX: ridego_get_setting() and ridego_update_setting() each used
// to declare their OWN `static $cache` — a PHP function-local static is
// scoped to that function only, so those were two entirely separate arrays
// that merely shared a variable name. update_setting()'s "clear cache" line
// was unsetting a key on its own private, permanently-empty array — it never
// touched the array get_setting() actually reads from, so the read-path
// cache was never invalidated by a save. On any host that keeps a PHP worker
// alive across requests (persistent/long-running workers), a value saved via
// the admin API would write to the DB correctly but every subsequent read in
// that same worker kept returning the old cached value — indistinguishable
// from "my save didn't stick" / "it reverted back". This single shared cache
// (by reference) is read and invalidated by both functions, so a save is
// visible to the very next read everywhere, regardless of hosting model.
// TRACE: nothing → a reference to the one process-lifetime settings cache, shared by every caller → array (by reference).
function &ridego_settings_cache_store() {
    static $cache = array();
    return $cache;
}

// TRACE: a setting key + a default → the saved value (decrypted if secret) or the default when unset → string|mixed. Reads the shared cache first; only queries the DB on a miss.
function ridego_get_setting( $key, $default = null ) {
    global $wpdb;
    $cache = &ridego_settings_cache_store();
    if ( array_key_exists( $key, $cache ) ) { return $cache[$key]; }
    $val = $wpdb->get_var( $wpdb->prepare(
        "SELECT setting_value FROM {$wpdb->prefix}ridego_settings WHERE setting_key=%s LIMIT 1", $key
    ));
    if ( $val === null ) { return $default; }

    if ( in_array( $key, ridego_get_secret_setting_keys(), true ) ) {
        if ( strpos( (string) $val, RIDEGO_SECRET_PREFIX ) === 0 ) {
            $val = ridego_decrypt_secret( $val );
        } elseif ( $val !== '' ) {
            // Legacy plaintext still sitting in the DB — surface this so an
            // operator/engineer knows it needs a re-save to be encrypted.
            ridego_log( "ridego_get_setting: setting '{$key}' is stored as legacy plaintext and needs re-saving to be encrypted." );
        }
    }

    $cache[$key] = $val;
    return $val;
}

// TRACE: a setting key + new value → saved (encrypted if secret) via upsert, then the shared read cache entry for this key is dropped → void. Postcondition: the very next ridego_get_setting() call for this key — in this request or a later one on the same worker — re-reads the DB instead of returning a stale cached value.
function ridego_update_setting( $key, $value ) {
    global $wpdb;
    $key = sanitize_key( $key );
    $store_value = (string) $value;
    if ( in_array( $key, ridego_get_secret_setting_keys(), true ) ) {
        $store_value = ridego_encrypt_secret( $store_value );
    }
    $wpdb->query( $wpdb->prepare(
        "INSERT INTO {$wpdb->prefix}ridego_settings (setting_key,setting_value) VALUES(%s,%s)
         ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=NOW()",
        $key, $store_value
    ));
    /* Clear cache — same shared store ridego_get_setting() reads from. */
    $cache = &ridego_settings_cache_store();
    unset( $cache[$key] );
}

/**
 * Root-cause fix: the admin "Require OTP to confirm booking" toggle
 * (setting key 'otp_enabled', see includes/app-admin-settings-api.php)
 * saved and read back correctly, but NOTHING in the booking-creation
 * path ever called ridego_get_setting('otp_enabled') — both
 * ridego_ajax_submit_booking() (legacy form) and
 * ridego_app_api_create_booking() (React app) gated OTP purely on
 * ridego_is_trusted_phone(), so disabling the setting in admin had zero
 * effect on booking submission. This is the single place both booking
 * entry points now ask "does THIS phone need an OTP right now?", so the
 * setting is actually wired to the enforcement point, and any future
 * booking path calls the same function.
 *
 * ridego_get_setting() returns everything as a string read from the DB
 * ("0"/"1") — cast through (int) before the boolean check so a stored
 * "0" isn't mistaken for "not yet set" (=== false/null) or otherwise
 * treated as truthy.
 *
 * @param string $phone Phone number (raw or already-sanitized).
 * @return bool True if this booking attempt must present a valid OTP.
 */
function ridego_booking_requires_otp( $phone ) {
    $otp_enabled = (int) ridego_get_setting( 'otp_enabled', 1 ) === 1;
    if ( ! $otp_enabled ) { return false; }
    return ! ridego_is_trusted_phone( $phone );
}

/**
 * Independent Email OTP Verification gate — parallel to
 * ridego_booking_requires_otp() above but reads its OWN setting
 * ('email_otp_enabled') and its OWN trust state (ridego_is_trusted_email()).
 * The two gates are checked independently by every booking-creation entry
 * point (public/ajax/booking-ajax.php, includes/app-api.php) so any
 * combination of the two toggles — both off, either alone, or both on —
 * is enforced with no hardcoded requirement for either channel.
 *
 * @param string $email Email address.
 * @return bool True if this booking attempt must present a valid email OTP.
 */
function ridego_booking_requires_email_otp( $email ) {
    $email_otp_enabled = (int) ridego_get_setting( 'email_otp_enabled', 0 ) === 1;
    if ( ! $email_otp_enabled ) { return false; }
    if ( ! $email ) { return true; } // enabled but no email supplied yet — still required.
    return ! ridego_is_trusted_email( $email );
}

function ridego_get_all_settings() {
    global $wpdb;
    $rows = $wpdb->get_results("SELECT setting_key,setting_value FROM {$wpdb->prefix}ridego_settings");
    $out  = array();
    foreach ( $rows as $r ) { $out[$r->setting_key] = $r->setting_value; }
    return $out;
}

/* ============================================================
   VEHICLE HELPERS
   ============================================================ */
function ridego_get_vehicles( $active_only = true ) {
    global $wpdb;
    $where = $active_only ? 'WHERE is_active=1' : '';
    return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ridego_vehicles {$where} ORDER BY sort_order ASC");
}

function ridego_get_vehicle( $id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$wpdb->prefix}ridego_vehicles WHERE id=%d", $id) );
}

function ridego_get_vehicle_by_slug( $slug ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$wpdb->prefix}ridego_vehicles WHERE slug=%s", $slug) );
}

/* ============================================================
   CITY HELPERS
   ============================================================ */
/**
 * $role: null (no filter, default — every existing caller keeps its
 * current behavior), 'origin' (is_origin_enabled=1), or 'destination'
 * (is_destination_enabled=1). Cached per (active_only, role) combo so
 * the three call shapes don't collide in the transient cache.
 */
function ridego_get_cities( $active_only = true, $role = null ) {
    global $wpdb;
    $where = $active_only ? 'WHERE is_active=1' : '';
    if ( $role === 'origin' ) {
        $where .= $where ? ' AND is_origin_enabled=1' : 'WHERE is_origin_enabled=1';
    } elseif ( $role === 'destination' ) {
        $where .= $where ? ' AND is_destination_enabled=1' : 'WHERE is_destination_enabled=1';
    }
    /* Cache city list for 1 hour */
    $cache_key = 'ridego_cities_' . ($active_only ? '1' : '0') . '_' . ( $role ?: 'all' );
    $cached    = get_transient($cache_key);
    if ( $cached !== false ) { return $cached; }
    $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ridego_cities {$where} ORDER BY name ASC");
    set_transient($cache_key, $rows, HOUR_IN_SECONDS);
    return $rows;
}

function ridego_get_city( $id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$wpdb->prefix}ridego_cities WHERE id=%d", $id) );
}

function ridego_get_city_by_name( $name ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$wpdb->prefix}ridego_cities WHERE name=%s", $name) );
}

function ridego_get_popular_cities() {
    global $wpdb;
    return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ridego_cities WHERE is_popular=1 AND is_active=1 ORDER BY name ASC");
}

/* ============================================================
   ROUTE CACHE - Save Google Maps API calls
   ============================================================ */
function ridego_get_cached_route( $from_city, $to_city ) {
    global $wpdb;
    $key  = md5( strtolower(trim($from_city)) . '|' . strtolower(trim($to_city)) );
    $row  = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_route_cache WHERE cache_key=%s AND expires_at>NOW()", $key
    ));
    if ( $row ) {
        return array(
            'distance_km'  => (float) $row->distance_km,
            'duration_min' => (int)   $row->duration_min,
        );
    }
    return null;
}

function ridego_save_route_cache( $from_city, $to_city, $distance_km, $duration_min ) {
    global $wpdb;
    $key     = md5( strtolower(trim($from_city)) . '|' . strtolower(trim($to_city)) );
    $expires = date('Y-m-d H:i:s', strtotime('+7 days'));
    $wpdb->query( $wpdb->prepare(
        "INSERT INTO {$wpdb->prefix}ridego_route_cache (cache_key,distance_km,duration_min,expires_at)
         VALUES(%s,%f,%d,%s) ON DUPLICATE KEY UPDATE distance_km=VALUES(distance_km),
         duration_min=VALUES(duration_min),expires_at=VALUES(expires_at),cached_at=NOW()",
        $key, $distance_km, $duration_min, $expires
    ));
}

/* ============================================================
   VENDOR HELPERS
   ============================================================ */
function ridego_get_vendor_by_user( $user_id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_vendors WHERE user_id=%d LIMIT 1", $user_id
    ));
}

function ridego_get_vendor( $vendor_id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_vendors WHERE id=%d", $vendor_id
    ));
}

function ridego_get_current_vendor() {
    if ( ! is_user_logged_in() ) { return null; }
    return ridego_get_vendor_by_user( get_current_user_id() );
}

/* ============================================================
   ZONES — sub-city surge-pricing geofences (Wave 3)
   ------------------------------------------------------------
   Center-point + radius model (see the doc comment on
   ridego_migration_006_zones() in includes/migrations.php for why
   a full GeoJSON polygon was not used). Containment is a simple
   haversine great-circle distance check against each active zone's
   radius_km — no external geo library needed.
   ============================================================ */

/**
 * Great-circle distance between two lat/lng points, in kilometres.
 *
 * Root-cause fix: $dlat/$dlng used to be computed from $lat1/$lat2
 * AFTER those variables had already been overwritten with their
 * deg2rad() radian values a few lines above — so this was silently
 * running deg2rad() a second time on values already in radians
 * (treating radians as if they were degrees), corrupting every
 * distance this function has ever returned. All degree-space
 * differences are now computed first, from the original degree
 * inputs, before any conversion to radians.
 */
function ridego_haversine_km( $lat1, $lng1, $lat2, $lng2 ) {
    $earth_radius_km = 6371.0;
    $lat1_deg = (float) $lat1;
    $lat2_deg = (float) $lat2;
    $dlat = deg2rad( $lat2_deg - $lat1_deg );
    $dlng = deg2rad( (float) $lng2 - (float) $lng1 );
    $lat1_rad = deg2rad( $lat1_deg );
    $lat2_rad = deg2rad( $lat2_deg );

    $a = sin( $dlat / 2 ) ** 2 + cos( $lat1_rad ) * cos( $lat2_rad ) * sin( $dlng / 2 ) ** 2;
    $c = 2 * atan2( sqrt( $a ), sqrt( 1 - $a ) );
    return $earth_radius_km * $c;
}

/**
 * Find the active zone (optionally restricted to one city) whose
 * center-point + radius contains the given lat/lng, if any. When a
 * point falls inside more than one zone's radius (overlapping zones),
 * the smallest-radius zone wins, on the theory that a more specific
 * (tighter) zone is the more deliberate match — e.g. an "Airport"
 * zone nested inside a broader "North Zone".
 *
 * @param float $lat
 * @param float $lng
 * @param int   $city_id Optional — restrict the search to this city's zones.
 * @return object|null The matching ridego_zones row, or null.
 */
function ridego_get_zone_for_point( $lat, $lng, $city_id = 0 ) {
    if ( ! is_numeric( $lat ) || ! is_numeric( $lng ) || ( (float) $lat === 0.0 && (float) $lng === 0.0 ) ) {
        return null;
    }

    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_zones';
    if ( $city_id ) {
        $zones = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$tbl} WHERE is_active=1 AND city_id=%d ORDER BY radius_km ASC", intval( $city_id )
        ) );
    } else {
        $zones = $wpdb->get_results( "SELECT * FROM {$tbl} WHERE is_active=1 ORDER BY radius_km ASC" );
    }

    foreach ( $zones as $zone ) {
        $dist = ridego_haversine_km( $lat, $lng, $zone->center_lat, $zone->center_lng );
        if ( $dist <= (float) $zone->radius_km ) {
            return $zone;
        }
    }
    return null;
}

/* ============================================================
   VENDOR WALLET — CANONICAL ATOMIC IMPLEMENTATION
   ------------------------------------------------------------
   This is the ONE canonical wallet credit/debit implementation
   for the whole plugin. includes/payment.php previously had a
   second, divergent read-then-write implementation
   (ridego_credit_vendor_wallet / ridego_debit_vendor_wallet) with
   the same classic race as the old versions of these functions:
   read balance in PHP, compute, then UPDATE, with no lock — two
   concurrent debits (e.g. two vendors' lead-accept requests, or a
   lead-accept racing an admin wallet adjustment) could both read
   the same starting balance and the loser's decrement would be
   silently lost, or a debit could push the balance negative.
   payment.php's functions are now thin wrappers around these.

   IMPORTANT — transaction boundary: these functions issue their
   own START TRANSACTION / COMMIT / ROLLBACK and use SELECT ... FOR
   UPDATE to row-lock the vendor. WordPress/MySQL via $wpdb has no
   true nested-transaction support, so these functions MUST be the
   OUTERMOST transaction boundary of any call. Callers that need to
   combine a wallet operation with other conditioned writes (see
   includes/lead.php ridego_accept_lead()) must perform those other
   writes inside their OWN transaction and call the wallet function
   only after that transaction has committed — or, if the wallet
   operation must be atomic with those writes, inline the locked
   read/update logic there instead of calling these functions (that
   is exactly what ridego_accept_lead() does — see its comments).
   Do NOT wrap a call to ridego_vendor_deduct_wallet()/
   ridego_vendor_credit_wallet() inside another START TRANSACTION.
   ============================================================ */

function ridego_vendor_deduct_wallet( $vendor_id, $amount, $booking_id = null, $notes = '', $type = 'lead_fee' ) {
    global $wpdb;
    $vendor_id = (int) $vendor_id;
    $amount    = (float) $amount;
    if ( $amount <= 0 ) {
        return array( 'success' => false, 'message' => 'Invalid amount.' );
    }

    $vendors_tbl = $wpdb->prefix . 'ridego_vendors';
    $ledger_tbl  = $wpdb->prefix . 'ridego_vendor_wallets';

    $wpdb->query( 'START TRANSACTION' );

    // Row-lock the vendor so no concurrent debit/credit can read a stale balance.
    $locked_balance = $wpdb->get_var( $wpdb->prepare(
        "SELECT wallet_balance FROM {$vendors_tbl} WHERE id=%d FOR UPDATE", $vendor_id
    ) );

    if ( $locked_balance === null ) {
        $wpdb->query( 'ROLLBACK' );
        return array( 'success' => false, 'message' => 'Vendor not found.' );
    }

    $locked_balance = (float) $locked_balance;

    if ( $locked_balance < $amount ) {
        $wpdb->query( 'ROLLBACK' );
        return array( 'success' => false, 'message' => 'Insufficient wallet balance' );
    }

    $new_balance = $locked_balance - $amount;

    $updated = $wpdb->update( $vendors_tbl,
        array( 'wallet_balance' => $new_balance ),
        array( 'id' => $vendor_id ),
        array( '%f' ), array( '%d' )
    );
    if ( $updated === false ) {
        $wpdb->query( 'ROLLBACK' );
        return array( 'success' => false, 'message' => 'Failed to update wallet balance.' );
    }

    $inserted = $wpdb->insert( $ledger_tbl, array(
        'vendor_id'         => $vendor_id,
        'type'              => 'debit',
        'transaction_type'  => sanitize_text_field( $type ),
        'amount'            => $amount,
        'balance_before'    => $locked_balance,
        'balance_after'     => $new_balance,
        'booking_id'        => $booking_id,
        'reference_id'      => $booking_id ? (int) $booking_id : 0,
        'notes'             => $notes ?: ( 'Lead fee for booking #' . $booking_id ),
        'created_by'        => get_current_user_id(),
        'created_at'        => current_time('mysql'),
    ) );
    if ( ! $inserted ) {
        $wpdb->query( 'ROLLBACK' );
        return array( 'success' => false, 'message' => 'Failed to write wallet ledger entry.' );
    }

    $wpdb->query( 'COMMIT' );

    // Best-effort structured transaction record for the Financial ledger (Task 7).
    if ( function_exists( 'ridego_log_transaction' ) ) {
        ridego_log_transaction( array(
            'type'       => $type,
            'amount'     => -$amount,
            'vendor_id'  => $vendor_id,
            'booking_id' => $booking_id,
            'gateway'    => 'wallet',
            'status'     => 'success',
            'notes'      => $notes,
        ) );
    }

    return array( 'success' => true, 'balance_after' => $new_balance );
}

function ridego_vendor_credit_wallet( $vendor_id, $amount, $booking_id = null, $notes = '', $type = 'credit' ) {
    global $wpdb;
    $vendor_id = (int) $vendor_id;
    $amount    = (float) $amount;
    if ( $amount <= 0 ) {
        return array( 'success' => false, 'message' => 'Invalid amount.' );
    }

    $vendors_tbl = $wpdb->prefix . 'ridego_vendors';
    $ledger_tbl  = $wpdb->prefix . 'ridego_vendor_wallets';

    $wpdb->query( 'START TRANSACTION' );

    $locked_balance = $wpdb->get_var( $wpdb->prepare(
        "SELECT wallet_balance FROM {$vendors_tbl} WHERE id=%d FOR UPDATE", $vendor_id
    ) );

    if ( $locked_balance === null ) {
        $wpdb->query( 'ROLLBACK' );
        return array( 'success' => false, 'message' => 'Vendor not found.' );
    }

    $locked_balance = (float) $locked_balance;
    $new_balance    = $locked_balance + $amount;

    $updated = $wpdb->update( $vendors_tbl,
        array( 'wallet_balance' => $new_balance ),
        array( 'id' => $vendor_id ),
        array( '%f' ), array( '%d' )
    );
    if ( $updated === false ) {
        $wpdb->query( 'ROLLBACK' );
        return array( 'success' => false, 'message' => 'Failed to update wallet balance.' );
    }

    $inserted = $wpdb->insert( $ledger_tbl, array(
        'vendor_id'         => $vendor_id,
        'type'              => 'credit',
        'transaction_type'  => sanitize_text_field( $type ),
        'amount'            => $amount,
        'balance_before'    => $locked_balance,
        'balance_after'     => $new_balance,
        'booking_id'        => $booking_id,
        'reference_id'      => $booking_id ? (int) $booking_id : 0,
        'notes'             => $notes ?: 'Wallet credit',
        'created_by'        => get_current_user_id(),
        'created_at'        => current_time('mysql'),
    ) );
    if ( ! $inserted ) {
        $wpdb->query( 'ROLLBACK' );
        return array( 'success' => false, 'message' => 'Failed to write wallet ledger entry.' );
    }

    $wpdb->query( 'COMMIT' );

    if ( function_exists( 'ridego_log_transaction' ) ) {
        ridego_log_transaction( array(
            'type'       => $type,
            'amount'     => $amount,
            'vendor_id'  => $vendor_id,
            'booking_id' => $booking_id,
            'gateway'    => 'wallet',
            'status'     => 'success',
            'notes'      => $notes,
        ) );
    }

    $vendor = ridego_get_vendor( $vendor_id );
    if ( $vendor && function_exists( 'ridego_send_notification' ) ) {
        ridego_send_notification( $vendor->user_id, 'vendor_wallet_credited', array(
            'amount'      => $amount,
            'new_balance' => $new_balance,
            'type'        => $type,
        ) );
    }

    return array( 'success' => true, 'balance_after' => $new_balance );
}

/**
 * Wallet-ledger reconciliation.
 *
 * Sums the vendor's signed ledger entries (debit rows are stored as a
 * positive `amount` with type='debit', credit rows as a positive `amount`
 * with type='credit' — this sums them as +/- to get the ledger's implied
 * balance) and compares that to the vendor's stored wallet_balance. Any
 * non-zero discrepancy means either a bug or an out-of-band DB edit.
 *
 * @param int $vendor_id
 * @return array{vendor_id:int, stored_balance:float, ledger_balance:float, discrepancy:float, ok:bool}
 */
function ridego_verify_wallet_integrity( $vendor_id ) {
    global $wpdb;
    $vendor_id = (int) $vendor_id;
    $vendor    = ridego_get_vendor( $vendor_id );
    $ledger_tbl = $wpdb->prefix . 'ridego_vendor_wallets';

    $ledger_balance = $wpdb->get_var( $wpdb->prepare(
        "SELECT COALESCE(SUM(CASE WHEN type='credit' THEN amount WHEN type='debit' THEN -amount ELSE 0 END),0)
         FROM {$ledger_tbl} WHERE vendor_id=%d", $vendor_id
    ) );
    $ledger_balance = (float) $ledger_balance;
    $stored_balance = $vendor ? (float) $vendor->wallet_balance : 0.0;
    $discrepancy    = round( $stored_balance - $ledger_balance, 2 );

    return array(
        'vendor_id'      => $vendor_id,
        'stored_balance' => $stored_balance,
        'ledger_balance' => $ledger_balance,
        'discrepancy'    => $discrepancy,
        'ok'             => abs( $discrepancy ) < 0.01,
    );
}

/**
 * Reconciliation report across all vendors — backs the "Wallet Reconciliation"
 * summary. Returns only vendors with a non-zero discrepancy plus a count.
 *
 * @return array{checked:int, discrepancy_count:int, discrepancies:array}
 */
function ridego_get_wallet_reconciliation_report() {
    global $wpdb;
    $vendor_ids = $wpdb->get_col( "SELECT id FROM {$wpdb->prefix}ridego_vendors" );
    $discrepancies = array();
    foreach ( $vendor_ids as $vid ) {
        $r = ridego_verify_wallet_integrity( (int) $vid );
        if ( ! $r['ok'] ) { $discrepancies[] = $r; }
    }
    return array(
        'checked'           => count( $vendor_ids ),
        'discrepancy_count' => count( $discrepancies ),
        'discrepancies'     => $discrepancies,
    );
}

/**
 * Manual wallet reconciliation correction (admin "Reconcile" action).
 *
 * IMPORTANT — why this is its own function rather than a call to
 * ridego_vendor_credit_wallet()/ridego_vendor_deduct_wallet(): those two
 * canonical functions always move `wallet_balance` and the ledger SUM by
 * the exact same signed amount (that symmetry is precisely what keeps
 * them safe/atomic for every *normal* wallet mutation). But that also
 * means a discrepancy between stored_balance and SUM(ledger) — which by
 * definition can only arise from some earlier out-of-band edit — is
 * mathematically invariant under any symmetric credit/debit: crediting
 * or debiting both sides by the same X leaves (stored - ledger)
 * unchanged. So no call to the canonical functions can ever close a
 * pre-existing gap; only an asymmetric correction can.
 *
 * This function performs that asymmetric correction using the SAME
 * locking/transaction discipline as the canonical functions (own
 * START TRANSACTION, SELECT ... FOR UPDATE to row-lock the vendor,
 * COMMIT/ROLLBACK) so it is not a bypass of that safety model, just a
 * distinct operation:
 *   1. Treats the ledger SUM as the source of truth (it is the
 *      append-only trail of every real transaction) and sets
 *      wallet_balance to match it.
 *   2. Writes a ridego_vendor_wallets row with type='adjustment' — a
 *      value NOT matched by ridego_verify_wallet_integrity()'s SUM
 *      CASE (which only recognizes 'credit'/'debit'), so this row is a
 *      pure, permanent audit annotation of the correction and does not
 *      itself get counted in future reconciliation sums or re-introduce
 *      a gap. amount/notes/created_by record what changed and why.
 *   3. Audit-logs the correction (old balance, new balance, reason).
 *
 * @param int    $vendor_id
 * @param string $reason Required — a blank reason is refused.
 * @return array{success:bool, message?:string, old_balance?:float, new_balance?:float, corrected?:float}
 */
function ridego_reconcile_vendor_wallet( $vendor_id, $reason ) {
    global $wpdb;
    $vendor_id = (int) $vendor_id;
    $reason    = trim( sanitize_textarea_field( (string) $reason ) );
    if ( $reason === '' ) {
        return array( 'success' => false, 'message' => 'A reason is required to reconcile a wallet discrepancy.' );
    }

    $vendors_tbl = $wpdb->prefix . 'ridego_vendors';
    $ledger_tbl  = $wpdb->prefix . 'ridego_vendor_wallets';

    $wpdb->query( 'START TRANSACTION' );

    // Row-lock the vendor, same as the canonical credit/debit functions,
    // so this can never race a concurrent wallet mutation.
    $locked_balance = $wpdb->get_var( $wpdb->prepare(
        "SELECT wallet_balance FROM {$vendors_tbl} WHERE id=%d FOR UPDATE", $vendor_id
    ) );
    if ( $locked_balance === null ) {
        $wpdb->query( 'ROLLBACK' );
        return array( 'success' => false, 'message' => 'Vendor not found.' );
    }
    $locked_balance = (float) $locked_balance;

    $ledger_balance = (float) $wpdb->get_var( $wpdb->prepare(
        "SELECT COALESCE(SUM(CASE WHEN type='credit' THEN amount WHEN type='debit' THEN -amount ELSE 0 END),0)
         FROM {$ledger_tbl} WHERE vendor_id=%d", $vendor_id
    ) );

    $discrepancy = round( $locked_balance - $ledger_balance, 2 );
    if ( abs( $discrepancy ) < 0.01 ) {
        $wpdb->query( 'ROLLBACK' );
        return array( 'success' => false, 'message' => 'No discrepancy found — wallet already reconciles against its ledger.' );
    }

    $updated = $wpdb->update( $vendors_tbl,
        array( 'wallet_balance' => $ledger_balance ),
        array( 'id' => $vendor_id ),
        array( '%f' ), array( '%d' )
    );
    if ( $updated === false ) {
        $wpdb->query( 'ROLLBACK' );
        return array( 'success' => false, 'message' => 'Failed to update wallet balance.' );
    }

    $inserted = $wpdb->insert( $ledger_tbl, array(
        'vendor_id'         => $vendor_id,
        'type'              => 'adjustment',
        'transaction_type'  => 'reconciliation',
        'amount'            => abs( $discrepancy ),
        'balance_before'    => $locked_balance,
        'balance_after'     => $ledger_balance,
        'booking_id'        => null,
        'reference_id'      => 0,
        'notes'             => $reason,
        'created_by'        => get_current_user_id(),
        'created_at'        => current_time('mysql'),
    ) );
    if ( ! $inserted ) {
        $wpdb->query( 'ROLLBACK' );
        return array( 'success' => false, 'message' => 'Failed to write reconciliation ledger entry.' );
    }

    $wpdb->query( 'COMMIT' );

    ridego_audit_log(
        'wallet_reconciliation',
        'vendor',
        $vendor_id,
        array( 'wallet_balance' => $locked_balance, 'ledger_balance' => $ledger_balance, 'discrepancy' => $discrepancy ),
        array( 'wallet_balance' => $ledger_balance, 'reason' => $reason ),
        'warning'
    );

    return array(
        'success'     => true,
        'old_balance' => $locked_balance,
        'new_balance' => $ledger_balance,
        'corrected'   => $discrepancy,
    );
}

/* ============================================================
   BOOKING HELPERS
   ============================================================ */
function ridego_get_booking( $id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare(
        "SELECT b.*,
                v.name AS vehicle_name, v.seating_capacity,
                vd.business_name AS vendor_name, vd.phone AS vendor_phone,
                vd.whatsapp_number AS vendor_whatsapp
         FROM {$wpdb->prefix}ridego_bookings b
         LEFT JOIN {$wpdb->prefix}ridego_vehicles v ON v.id=b.vehicle_type_id
         LEFT JOIN {$wpdb->prefix}ridego_vendors vd ON vd.id=b.vendor_id
         WHERE b.id=%d", $id
    ));
}

/**
 * Can the current request be trusted as the actual client for $booking?
 *
 * Used to gate anything that exposes sensitive booking data (client
 * phone/email/addresses, the pickup OTP) or that lets someone act on a
 * booking (submit payment proof, cancel), where the only thing an
 * attacker needs to guess or copy-paste is a booking_number/booking_id.
 *
 * Two ways to pass:
 *   - Logged in as the booking's actual owner (client_id > 0 and equal
 *     to the current user — a guest booking's client_id=0 can NEVER
 *     satisfy this: get_current_user_id() is also 0 for an anonymous
 *     visitor, and 0 !== 0 must never be treated as a match here), or an
 *     admin (manage_options).
 *   - A POSTed client_phone that matches the booking's phone on file,
 *     AND that phone has a recent successful OTP verification for this
 *     session (the same mechanism the booking form itself uses — see
 *     ridego_validate_otp_session() in includes/otp.php) or is already a
 *     device-trusted phone (ridego_is_trusted_phone(), set right after a
 *     successful OTP verify). This is what lets the confirmation page
 *     work seamlessly immediately after a booking is submitted (the
 *     phone was just OTP-verified moments earlier) while still refusing
 *     a cold/unrelated-session lookup that only knows the booking number.
 */
function ridego_requester_verified_for_booking( $booking ) {
    if ( ! $booking ) return false;
    if ( current_user_can('manage_options') ) return true;
    if ( (int) $booking->client_id > 0 && (int) $booking->client_id === get_current_user_id() ) return true;

    // A phone the requester actively supplied (e.g. a "look up my booking"
    // form field) is checked against the booking's phone on file first.
    $posted_phone = ridego_sanitize_phone( isset($_POST['client_phone']) ? $_POST['client_phone'] : '' );
    if ( $posted_phone && ridego_clean_phone_number($posted_phone) === ridego_clean_phone_number($booking->client_phone) ) {
        if ( ridego_validate_otp_session($posted_phone, 'booking', 30) ) return true;
        if ( ridego_is_trusted_phone($posted_phone) ) return true;
    }

    // No phone was posted (e.g. a plain GET load of the confirmation page
    // right after submitting a guest booking). In that case check the
    // booking's OWN phone — never an attacker-suppliable value — against
    // this browser's trust cookie / this phone's recent OTP verification.
    // This is safe against IDOR: knowing/guessing the booking_number alone
    // does not let an attacker forge the trust cookie (it's a keyed hash
    // scoped to that exact phone) or a recent OTP verification for it.
    if ( ! $posted_phone && $booking->client_phone ) {
        if ( ridego_validate_otp_session($booking->client_phone, 'booking', 30) ) return true;
        if ( ridego_is_trusted_phone($booking->client_phone) ) return true;
    }

    return false;
}

/**
 * Build the full rendering context for the booking-confirmation page
 * ([ridego_confirm] shortcode): the booking row, payment instructions,
 * and derived display flags.
 *
 * Returns false (never partial data) when the booking doesn't exist OR
 * the requester can't be verified as its owner — this is a page reached
 * by nothing but a booking_number in the URL, so it is exactly the kind
 * of IDOR surface ridego_requester_verified_for_booking() exists to gate;
 * a raw "booking not found" is shown either way so existence isn't leaked.
 *
 * @param string $booking_number
 * @return array|false
 */
function ridego_get_booking_payment_context( $booking_number ) {
    $booking_number = sanitize_text_field( $booking_number );
    if ( ! $booking_number ) return false;

    $booking = ridego_get_booking_by_number( $booking_number );
    if ( ! $booking ) return false;
    if ( ! ridego_requester_verified_for_booking( $booking ) ) return false;

    // Re-fetch via the vendor-joined canonical getter so the template has
    // vehicle_name / vendor_name / vendor_phone / vendor_whatsapp available.
    $booking = ridego_get_booking( $booking->id );
    if ( ! $booking ) return false;

    // Token Amount / Advance Payment: the amount actually requested from
    // the client at this payment step is the booking's own snapshot
    // token_amount (set at creation time — see ridego_create_booking())
    // when the feature was on for this booking, never the full
    // total_fare — the remaining balance is payable directly to the
    // assigned driver/vendor, not collected by RideGo (spec item 5). A
    // booking created while the feature was off has token_amount=0 and
    // falls through to the pre-existing full-total behaviour unchanged.
    $token_active   = (float) $booking->token_amount > 0 || ! empty( $booking->platform_model );
    $amount_due_now = $token_active ? (float) $booking->token_amount : (float) $booking->total_fare;

    $payment_details = array(
        'bank_name'    => ridego_get_setting('bank_name'),
        'bank_account' => ridego_get_setting('bank_account'),
        'bank_ifsc'    => ridego_get_setting('bank_ifsc'),
        'bank_holder'  => ridego_get_setting('bank_holder'),
        'upi_id'       => ridego_get_setting('upi_id'),
        'upi_qr_url'   => ridego_get_setting('upi_qr_url'),
        // Deliberately NOT labelled/exposed as a "platform fee" or
        // "service fee" anywhere — this is the amount to pay right now,
        // which is either the full ride cost (token feature off) or just
        // the token/advance (token feature on, balance to the driver/
        // vendor later). The React ConfirmPage is responsible for the
        // client-facing wording (spec item 2).
        'amount'              => round( $amount_due_now, 2 ),
        'is_token_payment'    => $token_active,
        'token_amount'        => round( (float) $booking->token_amount, 2 ),
        'total_fare'          => round( (float) $booking->total_fare, 2 ),
        'remaining_amount'    => round( max( 0, (float) $booking->total_fare - (float) $booking->token_amount ), 2 ),
        'token_label'         => ridego_platform_text('token_label'),
        'token_instructions'  => ridego_platform_text('token_instructions'),
        'estimated_ride_fare' => round( (float) $booking->total_fare, 2 ),
        'payable_to_vendor'   => round( max( 0, (float) $booking->total_fare - (float) $booking->token_amount ), 2 ),
        'disclaimer'          => ridego_platform_text('disclaimer_client'),
    );

    $needs_payment = in_array( $booking->status, array('pending_payment', 'payment_rejected'), true );
    $is_confirmed  = in_array( $booking->status, array('confirmed', 'completed'), true );
    $is_expired    = ( $booking->status === 'expired' );

    $seconds_left = 0;
    if ( $needs_payment && $booking->payment_deadline ) {
        $seconds_left = max( 0, strtotime( $booking->payment_deadline ) - current_time('timestamp') );
    }

    return array(
        'booking'         => $booking,
        'payment_details' => $payment_details,
        'needs_payment'   => $needs_payment,
        'is_confirmed'    => $is_confirmed,
        'is_expired'      => $is_expired,
        'seconds_left'    => $seconds_left,
    );
}

function ridego_get_booking_by_number( $number ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_bookings WHERE booking_number=%s", $number
    ));
}

function ridego_get_client_bookings( $client_id, $status = '', $limit = 20, $offset = 0 ) {
    global $wpdb;
    $where = $wpdb->prepare("client_id=%d", $client_id);
    if ( $status ) { $where .= $wpdb->prepare(" AND status=%s", $status); }
    return $wpdb->get_results( $wpdb->prepare(
        "SELECT b.*,v.name AS vehicle_name FROM {$wpdb->prefix}ridego_bookings b
         LEFT JOIN {$wpdb->prefix}ridego_vehicles v ON v.id=b.vehicle_type_id
         WHERE {$where} ORDER BY b.created_at DESC LIMIT %d OFFSET %d",
        $limit, $offset
    ));
}

// TRACE: any caller wanting a booking's status changed → $wpdb->update() → audit log entry → the
//        'ridego_booking_status_changed' action → bool. ROOT-CAUSE FIX: this is the canonical,
//        widely-reused status-change helper (dozens of call sites across the codebase), and it previously
//        discarded $wpdb->update()'s return value entirely with no way for ANY caller to ever learn a
//        write failed — worse than the single-call-site ghost-success bugs found elsewhere this session,
//        since this one is systemic. Now returns false on a genuine DB error (=== false, not merely 0 rows
//        changed) and audit-logs it distinctly so a failure here is visible even to the many pre-existing
//        callers that never check the return value (a void call to a now-bool function is unaffected).
function ridego_update_booking_status( $booking_id, $status, $extra = array() ) {
    global $wpdb;
    $data = array_merge( array(
        'status'     => sanitize_text_field($status),
        'updated_at' => current_time('mysql'),
    ), $extra );
    $result = $wpdb->update( $wpdb->prefix.'ridego_bookings', $data, array('id' => intval($booking_id)) );
    if ( $result === false ) {
        ridego_audit_log( 'booking_status_update_failed', 'booking', $booking_id, '', "Failed to set status={$status}: {$wpdb->last_error}", 'critical' );
        return false;
    }
    ridego_audit_log( 'booking_status_update', 'booking', $booking_id, '', $status );
    do_action( 'ridego_booking_status_changed', $booking_id, $status );
    return true;
}

/**
 * Canonical "assign vendor to booking" — extracted from the raw,
 * un-encapsulated $wpdb->update() that admin/pages/bookings.php's
 * 'assign_vendor' action used to do inline (and that
 * includes/app-admin-bookings-api.php's REST wrapper duplicated to
 * stay a "thin wrapper" until this function existed). This is now
 * the single place that logic lives; both the legacy admin page and
 * the REST API call it, so they can never drift apart.
 *
 * Behavior is unchanged from the original inline code: sets
 * vendor_id + status='vendor_assigned' + updated_at, and writes the
 * same 'manual_vendor_assign' audit log entry. Adds basic existence
 * validation (booking/vendor found) that the REST wrapper already
 * had but the legacy admin page's inline version did not — this is
 * strictly additive safety, not a behavior change for valid input.
 */
function ridego_assign_vendor_to_booking( $booking_id, $vendor_id ) {
    $booking_id = (int) $booking_id;
    $vendor_id  = (int) $vendor_id;

    if ( ! $vendor_id ) {
        return array( 'success' => false, 'message' => 'Please choose a vendor.' );
    }
    if ( ! ridego_get_booking( $booking_id ) ) {
        return array( 'success' => false, 'message' => 'Booking not found.' );
    }
    if ( ! ridego_get_vendor( $vendor_id ) ) {
        return array( 'success' => false, 'message' => 'Vendor not found.' );
    }

    /* ROOT-CAUSE FIX: this used to do its own plain, unconditioned
       $wpdb->update() — no row lock, no "WHERE vendor_id IS NULL" guard,
       and no lead-fee deduction at all. Two callers exist for the exact
       same operation: this function (admin bookings page + the
       /assign-vendor REST endpoint) and ridego_admin_assign_vendor()
       (includes/lead.php), which does it correctly — a locking
       transaction with a conditional UPDATE that fails cleanly if a
       vendor self-accepted the lead moments earlier via
       ridego_accept_lead(), plus charging the lead fee. Rather than keep
       two divergent implementations of "assign a vendor" (this one could
       silently clobber a vendor's self-accept with no error and no fee
       ever charged), this is now a thin wrapper over the canonical one. */
    $admin_id = function_exists( 'get_current_user_id' ) ? get_current_user_id() : 0;
    return ridego_admin_assign_vendor( $booking_id, $vendor_id, $admin_id );
}

/* ============================================================
   AUDIT LOG — the single canonical function for administrative /
   business-event audit logging (ridego_log_activity() below is a
   thin back-compat alias to this).
   ------------------------------------------------------------
   Tamper-evidence: every row gets a `checksum` computed from its
   own fields plus wp_salt('auth'), a secret an attacker with only
   DB access (no code execution) does not have. To verify a row has
   not been altered, recompute:
     hash('sha256', $admin_id.$action.$entity.$entity_id.$old_value.$new_value.$created_at.wp_salt('auth'))
   and compare to the stored `checksum` — a mismatch means the row
   (or the salt) changed since it was written. This is detection,
   not prevention: a row edited by someone with DB write access AND
   the ability to recompute a matching checksum (i.e. also has code
   execution on the site) can still fake it, but that already implies
   full compromise. It stops "just edit the row in phpMyAdmin".
   ============================================================ */
// TRACE: any auditable action → writes a checksummed row with the REAL admin id and acting_as_id (the impersonated user) when a view-as session is active → void.
//        Preconditions: none → Postconditions: one audit row → Edge cases: not impersonating (acting_as_id NULL).
function ridego_audit_log( $action, $entity, $entity_id = null, $old = '', $new = '', $severity = 'info' ) {
    global $wpdb;
    $admin_id   = function_exists( 'ridego_real_user_id' ) ? ridego_real_user_id() : get_current_user_id();
    $acting_as  = ( function_exists( 'ridego_is_impersonating' ) && ridego_is_impersonating() ) ? (int) get_current_user_id() : null;
    $action_v   = sanitize_text_field($action);
    $entity_v   = sanitize_text_field($entity);
    $entity_id_v= $entity_id ? intval($entity_id) : 0;
    $old_v      = is_array($old) ? wp_json_encode($old) : (string)$old;
    $new_v      = is_array($new) ? wp_json_encode($new) : (string)$new;
    $created_at = current_time('mysql');
    $checksum   = hash( 'sha256', $admin_id . $action_v . $entity_v . $entity_id_v . $old_v . $new_v . $created_at . wp_salt('auth') );

    $wpdb->insert( $wpdb->prefix.'ridego_audit_log', array(
        'admin_id'   => $admin_id,
        'action'     => $action_v,
        'entity'     => $entity_v,
        'entity_id'  => $entity_id ? $entity_id_v : null,
        'old_value'  => $old_v,
        'new_value'  => $new_v,
        'severity'   => sanitize_text_field( $severity ?: 'info' ),
        'acting_as_id' => $acting_as,
        'checksum'   => $checksum,
        'ip_address' => sanitize_text_field((isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '')),
        'created_at' => $created_at,
    ));
}

/* ============================================================
   DASHBOARD STATS - Cached every 15 minutes
   ============================================================ */
/**
 * Canonical "stuck without a driver" staleness threshold, in minutes.
 * Derived from the lead cascade settings so it tracks whatever the lead
 * engine is actually configured to attempt (max vendors x cascade minutes),
 * rather than a hardcoded guess.
 */
function ridego_get_no_vendor_staleness_minutes() {
    $max_vendors     = (int) ridego_get_setting('lead_max_vendors', 5);
    $cascade_minutes = (int) ridego_get_setting('lead_cascade_minutes', 10);
    if ($max_vendors < 1) { $max_vendors = 1; }
    if ($cascade_minutes < 1) { $cascade_minutes = 10; }
    return $max_vendors * $cascade_minutes;
}

/**
 * Canonical KYC-pending definition used everywhere (dashboard KPI,
 * ridego_get_dashboard_stats(), and the admin menu badge). A vendor is
 * "KYC pending" when they've submitted documents for review but their
 * account status is still pending (i.e. not yet approved/active).
 */
function ridego_count_kyc_pending() {
    global $wpdb;
    return (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_vendors WHERE kyc_status='submitted' AND status='pending'"
    );
}

function ridego_get_dashboard_stats() {
    $cached = get_transient('ridego_dashboard_stats');
    if ( $cached !== false ) { return $cached; }

    global $wpdb;
    $today = date('Y-m-d');
    $month_start = date('Y-m-01');

    // Prior-period comparison windows (for trend deltas): "yesterday" for the
    // daily figures, and the same number of days in the previous month for
    // the monthly figures.
    $yesterday          = date('Y-m-d', strtotime('-1 day'));
    $day_before_yesterday = date('Y-m-d', strtotime('-2 days'));
    $prev_month_start   = date('Y-m-01', strtotime('-1 month'));
    $day_of_month       = (int) date('j');
    $prev_month_equiv_end = date('Y-m-d', strtotime($prev_month_start . ' +' . ($day_of_month - 1) . ' days'));

    $btbl = $wpdb->prefix . 'ridego_bookings';
    $ttbl = $wpdb->prefix . 'ridego_transactions';

    // Gross revenue: what the client actually paid. Matches financial.php's
    // definition — successful 'booking_payment' transactions — rather than
    // the commission-only figure that used to be mislabeled as "revenue".
    $revenue_today = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount),0) FROM {$ttbl} WHERE type='booking_payment' AND status='success' AND DATE(created_at)=%s", $today
    ));
    $revenue_yesterday = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount),0) FROM {$ttbl} WHERE type='booking_payment' AND status='success' AND DATE(created_at)=%s", $yesterday
    ));
    $revenue_month = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount),0) FROM {$ttbl} WHERE type='booking_payment' AND status='success' AND created_at>=%s", $month_start
    ));
    $revenue_month_prior_equiv = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount),0) FROM {$ttbl} WHERE type='booking_payment' AND status='success' AND created_at>=%s AND created_at<=%s",
        $prev_month_start, $prev_month_equiv_end . ' 23:59:59'
    ));
    $revenue_total = (float) $wpdb->get_var(
        "SELECT COALESCE(SUM(amount),0) FROM {$ttbl} WHERE type='booking_payment' AND status='success'"
    );

    // Commission earned: RideGo's own cut (the lead fee charged to vendors) —
    // a distinct figure from gross revenue, now labeled accordingly.
    $commission_today = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(lead_fee_charged),0) FROM {$btbl} WHERE DATE(created_at)=%s AND lead_fee_paid=1", $today
    ));
    $commission_yesterday = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(lead_fee_charged),0) FROM {$btbl} WHERE DATE(created_at)=%s AND lead_fee_paid=1", $yesterday
    ));
    $commission_month = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(lead_fee_charged),0) FROM {$btbl} WHERE created_at>=%s AND lead_fee_paid=1", $month_start
    ));
    $commission_month_prior_equiv = (float) $wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(lead_fee_charged),0) FROM {$btbl} WHERE created_at>=%s AND created_at<=%s AND lead_fee_paid=1",
        $prev_month_start, $prev_month_equiv_end . ' 23:59:59'
    ));
    $commission_total = (float) $wpdb->get_var(
        "SELECT COALESCE(SUM(lead_fee_charged),0) FROM {$btbl} WHERE lead_fee_paid=1"
    );

    $bookings_today     = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$btbl} WHERE DATE(created_at)=%s", $today));
    $bookings_yesterday = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$btbl} WHERE DATE(created_at)=%s", $yesterday));
    $bookings_month     = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$btbl} WHERE created_at>=%s", $month_start));
    $bookings_month_prior_equiv = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$btbl} WHERE created_at>=%s AND created_at<=%s", $prev_month_start, $prev_month_equiv_end . ' 23:59:59'
    ));

    // "Stuck without a driver": a booking that has been confirmed but never
    // got a vendor assigned, and has sat that way long enough that the lead
    // cascade should have exhausted itself (genuinely stuck, not just new).
    $stale_minutes = ridego_get_no_vendor_staleness_minutes();
    $stale_cutoff  = date('Y-m-d H:i:s', strtotime("-{$stale_minutes} minutes"));
    $no_vendor_bookings = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$btbl} WHERE vendor_id IS NULL AND status='confirmed' AND created_at<=%s", $stale_cutoff
    ));

    $kyc_pending      = ridego_count_kyc_pending();
    $kyc_pending_yday = null; // point-in-time count has no meaningful "yesterday" snapshot without history; omitted from trend.

    $stats = array(
        'bookings_today'        => $bookings_today,
        'bookings_today_trend'  => ridego_pct_delta($bookings_today, $bookings_yesterday),
        'bookings_month'        => $bookings_month,
        'bookings_month_trend'  => ridego_pct_delta($bookings_month, $bookings_month_prior_equiv),
        'bookings_total'        => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$btbl}"),

        // Gross revenue = what clients paid (SUM of successful booking_payment transactions)
        'revenue_today'         => $revenue_today,
        'revenue_today_trend'   => ridego_pct_delta($revenue_today, $revenue_yesterday),
        'revenue_month'         => $revenue_month,
        'revenue_month_trend'   => ridego_pct_delta($revenue_month, $revenue_month_prior_equiv),
        'revenue_total'         => $revenue_total,

        // Commission earned = RideGo's own cut (lead fees charged to vendors)
        'commission_today'       => $commission_today,
        'commission_today_trend' => ridego_pct_delta($commission_today, $commission_yesterday),
        'commission_month'       => $commission_month,
        'commission_month_trend' => ridego_pct_delta($commission_month, $commission_month_prior_equiv),
        'commission_total'       => $commission_total,

        'pending_payment'       => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$btbl} WHERE status='pending_payment'"),
        'proof_submitted'       => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$btbl} WHERE status='payment_proof_submitted'"),
        'no_vendor_bookings'    => $no_vendor_bookings,
        'no_vendor_stale_minutes' => $stale_minutes,
        'active_trips'          => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$btbl} WHERE status IN ('vendor_assigned','driver_en_route','trip_started')"),
        'vendors_total'         => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ridego_vendors"),
        'vendors_active'        => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ridego_vendors WHERE status='active'"),
        'vendors_pending_kyc'   => $kyc_pending,
        'low_wallet_vendors'    => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}ridego_vendors WHERE wallet_balance<%f AND status='active'",200)),
        'open_complaints'       => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ridego_complaints WHERE status='open'"),
        'expiring_docs_7days'   => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}ridego_driver_docs WHERE expiry_date BETWEEN %s AND %s AND status='verified'",$today,date('Y-m-d',strtotime('+7 days')))),
        'pending_queue'         => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ridego_notification_queue WHERE status='pending'"),
        'total_wallet_float'    => (float)$wpdb->get_var("SELECT COALESCE(SUM(wallet_balance),0) FROM {$wpdb->prefix}ridego_vendors WHERE status='active'"),
    );

    set_transient('ridego_dashboard_stats', $stats, 15 * MINUTE_IN_SECONDS);
    return $stats;
}

/**
 * Percentage delta helper for KPI trend tiles. Returns null when there is no
 * meaningful baseline (avoids a division-by-zero / misleading "+inf%").
 */
function ridego_pct_delta($current, $previous) {
    $current  = (float) $current;
    $previous = (float) $previous;
    if ($previous == 0.0) {
        return ($current > 0) ? null : 0.0;
    }
    return round((($current - $previous) / abs($previous)) * 100, 1);
}

/* Clear stats cache when data changes */
add_action('ridego_booking_status_changed', function(){ delete_transient('ridego_dashboard_stats'); });

/* ============================================================
   DATE/TIME HELPERS
   ============================================================ */
function ridego_is_night_time( $time_str ) {
    $t          = strtotime($time_str);
    $night_from = strtotime(ridego_get_setting('night_hours_start','22:00'));
    $night_to   = strtotime(ridego_get_setting('night_hours_end','06:00'));
    /* Handle overnight range */
    if ( $night_from > $night_to ) {
        return ( $t >= $night_from || $t < $night_to );
    }
    return ( $t >= $night_from && $t < $night_to );
}

function ridego_days_between( $date1, $date2 ) {
    $d1 = new DateTime($date1);
    $d2 = new DateTime($date2);
    return (int) $d1->diff($d2)->days;
}

function ridego_format_date( $date ) {
    if ( ! $date ) { return ''; }
    return date('d M Y', strtotime($date));
}

function ridego_format_datetime( $dt ) {
    if ( ! $dt ) { return ''; }
    return date('d M Y, h:i A', strtotime($dt));
}

/* ============================================================
   INPUT SANITIZATION HELPERS
   ============================================================ */
function ridego_sanitize_booking_input( $data ) {
    return array(
        'client_name'        => sanitize_text_field((isset($data['client_name']) ? $data['client_name'] : '')),
        'client_phone'       => ridego_sanitize_phone((isset($data['client_phone']) ? $data['client_phone'] : '')),
        'client_email'       => sanitize_email((isset($data['client_email']) ? $data['client_email'] : '')),
        'client_alt_phone'   => ridego_sanitize_phone((isset($data['client_alt_phone']) ? $data['client_alt_phone'] : '')),
        'trip_type'          => sanitize_key((isset($data['trip_type']) ? $data['trip_type'] : 'one_way')),
        'pickup_city'        => sanitize_text_field((isset($data['pickup_city']) ? $data['pickup_city'] : '')),
        'pickup_address'     => sanitize_textarea_field((isset($data['pickup_address']) ? $data['pickup_address'] : '')),
        'pickup_lat'         => (float)((isset($data['pickup_lat']) ? $data['pickup_lat'] : 0)),
        'pickup_lng'         => (float)((isset($data['pickup_lng']) ? $data['pickup_lng'] : 0)),
        'drop_city'          => sanitize_text_field((isset($data['drop_city']) ? $data['drop_city'] : '')),
        'drop_address'       => sanitize_textarea_field((isset($data['drop_address']) ? $data['drop_address'] : '')),
        'drop_lat'           => (float)((isset($data['drop_lat']) ? $data['drop_lat'] : 0)),
        'drop_lng'           => (float)((isset($data['drop_lng']) ? $data['drop_lng'] : 0)),
        'journey_date'       => sanitize_text_field((isset($data['journey_date']) ? $data['journey_date'] : '')),
        'journey_time'       => sanitize_text_field((isset($data['journey_time']) ? $data['journey_time'] : '')),
        'return_date'        => sanitize_text_field((isset($data['return_date']) ? $data['return_date'] : '')),
        'return_time'        => sanitize_text_field((isset($data['return_time']) ? $data['return_time'] : '')),
        'hours_required'     => intval((isset($data['hours_required']) ? $data['hours_required'] : 0)),
        'passengers'         => min(50, max(1, intval((isset($data['passengers']) ? $data['passengers'] : 1)))),
        'luggage_count'      => max(0, intval((isset($data['luggage_count']) ? $data['luggage_count'] : 0))),
        'vehicle_type_id'    => intval((isset($data['vehicle_type_id']) ? $data['vehicle_type_id'] : 0)),
        'special_requests'   => sanitize_textarea_field((isset($data['special_requests']) ? $data['special_requests'] : '')),
        'flight_number'      => sanitize_text_field((isset($data['flight_number']) ? $data['flight_number'] : '')),
        'corporate_company'  => sanitize_text_field((isset($data['corporate_company']) ? $data['corporate_company'] : '')),
        'corporate_gst'      => sanitize_text_field((isset($data['corporate_gst']) ? $data['corporate_gst'] : '')),
        'corporate_emp_id'   => sanitize_text_field((isset($data['corporate_emp_id']) ? $data['corporate_emp_id'] : '')),
        'promo_code'         => strtoupper(sanitize_text_field((isset($data['promo_code']) ? $data['promo_code'] : ''))),
        'payment_method'     => sanitize_key((isset($data['payment_method']) ? $data['payment_method'] : 'cash')),
        'ip_address'         => sanitize_text_field((isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '')),
        'utm_source'         => sanitize_text_field((isset($data['utm_source']) ? $data['utm_source'] : '')),
        'passenger_total'    => isset($data['passenger_total']) && $data['passenger_total'] !== '' ? max(0, intval($data['passenger_total'])) : null,
        'passenger_male'     => isset($data['passenger_male']) && $data['passenger_male'] !== '' ? max(0, intval($data['passenger_male'])) : null,
        'passenger_female'   => isset($data['passenger_female']) && $data['passenger_female'] !== '' ? max(0, intval($data['passenger_female'])) : null,
        'passenger_children' => isset($data['passenger_children']) && $data['passenger_children'] !== '' ? max(0, intval($data['passenger_children'])) : null,
        'passenger_notes'    => sanitize_textarea_field((isset($data['passenger_notes']) ? $data['passenger_notes'] : '')),
    );
}

/**
 * Passenger & Safety Information: whether a booking's captured passenger
 * composition should be treated as safety-sensitive in vendor/driver
 * assignment views — female-only (at least one female passenger, zero
 * male) or including any children. Booking rows created before this
 * feature (or where the client left the step's counts at zero/blank)
 * have NULL passenger_male/passenger_female and are never flagged — there
 * is no data to flag against, and this deliberately never guesses.
 */
function ridego_booking_is_safety_sensitive( $booking ) {
    if ( ! $booking ) { return false; }
    $male     = isset( $booking->passenger_male ) ? $booking->passenger_male : null;
    $female   = isset( $booking->passenger_female ) ? $booking->passenger_female : null;
    $children = isset( $booking->passenger_children ) ? $booking->passenger_children : null;
    if ( $male === null && $female === null && $children === null ) { return false; }
    $male     = (int) $male;
    $female   = (int) $female;
    $children = (int) $children;
    $female_only = $female > 0 && $male === 0;
    $has_children = $children > 0;
    return $female_only || $has_children;
}

/* ============================================================
   PAGINATION HELPER
   ============================================================ */
function ridego_paginate( $total, $per_page, $current_page, $base_url ) {
    $total_pages = max(1, ceil($total / $per_page));
    if ( $total_pages <= 1 ) { return ''; }
    $html = '<div class="ridego-pagination">';
    for ( $i = 1; $i <= $total_pages; $i++ ) {
        $active = ( $i === $current_page ) ? 'active' : '';
        $url    = add_query_arg('paged', $i, $base_url);
        $html  .= '<a href="' . esc_url($url) . '" class="ridego-page-btn ' . $active . '">' . $i . '</a>';
    }
    $html .= '</div>';
    return $html;
}

/* ============================================================
   BOOKING STATUS LABEL / COLOR HELPERS
   Used by admin pages (bookings, dashboard) to render status badges.
   ============================================================ */
if ( ! function_exists('ridego_get_booking_status_label') ) {
    function ridego_get_booking_status_label( $status ) {
        $labels = array(
            'pending'         => 'Pending',
            'payment_pending' => 'Booking Amount Pending',
            'pending_payment' => 'Booking Amount Pending',
            'payment_rejected'=> 'Payment Rejected',
            'no_vendor'       => 'Finding a Vendor',
            'confirmed'       => 'Confirmed',
            'vendor_assigned' => 'Vendor Assigned',
            'driver_en_route' => 'Driver En Route',
            'trip_started'    => 'Trip Started',
            'completed'       => 'Completed',
            'cancelled'       => 'Cancelled',
            'disputed'        => 'Disputed',
            'token_refund_due'=> 'Booking Not Arranged — Booking Amount Refund Due',
        );
        return isset($labels[$status]) ? $labels[$status] : ucfirst( str_replace('_', ' ', (string)$status) );
    }
}

if ( ! function_exists('ridego_get_booking_status_color') ) {
    function ridego_get_booking_status_color( $status ) {
        $colors = array(
            'pending'         => '#FFC107',
            'payment_pending' => '#FF9800',
            'pending_payment' => '#FF9800',
            'payment_rejected'=> '#F44336',
            'no_vendor'       => '#FF9800',
            'confirmed'       => '#4CAF50',
            'vendor_assigned' => '#2196F3',
            'driver_en_route' => '#2196F3',
            'trip_started'    => '#9C27B0',
            'completed'       => '#4CAF50',
            'cancelled'       => '#F44336',
            'disputed'        => '#F44336',
            'token_refund_due'=> '#FF9800',
        );
        return isset($colors[$status]) ? $colors[$status] : '#9E9E9E';
    }
}

/* ============================================================
   ACTIVITY LOG SHIM
   Backward-compat wrapper. Older code paths (payment.php, etc.)
   call ridego_log_activity($action, $entity, $entity_id, $data_array);
   We forward to ridego_audit_log() which writes to the current
   ridego_audit_log table schema (admin_id, old_value, new_value, ...).
   ============================================================ */
if ( ! function_exists('ridego_log_activity') ) {
    function ridego_log_activity( $action, $entity, $entity_id = null, $data = array() ) {
        ridego_audit_log( $action, $entity, $entity_id, '', $data );
    }
}

/* ============================================================
   CITIES — canonical write functions
   ------------------------------------------------------------
   Consolidation cleanup (follow-up to Wave 19's documented gap):
   admin/pages/cities.php's Cities tab and includes/app-admin-
   cities-api.php previously each did their own raw $wpdb add/edit/
   toggle, with two real divergences between them:
     1. The legacy page validated lat/-90..90 and lng/-180..180;
        the REST layer did not (a real, if minor, validation gap).
     2. The REST layer cleared the ridego_cities_* transient cache
        on every write (fixing a real staleness bug); the legacy
        page never did, so an edit made in wp-admin could still
        leave the customer-facing city list stale for up to an hour.
   Both are now fixed for both callers by consolidating into these
   three functions, which both admin/pages/cities.php and
   includes/app-admin-cities-api.php call instead of touching
   $wpdb directly. This is a real behavior change for the LEGACY
   PAGE specifically (it now also gets lat/lng validation and cache
   invalidation it didn't have before) — flagged here, not silent.
   ============================================================ */

/**
 * Validates + normalizes raw city input into the exact column set
 * ridego_cities holds. Returns array('error' => string) on invalid
 * input, or the clean data array (without is_active) on success.
 */
function ridego_validate_city_input( $raw ) {
    $name = sanitize_text_field( (string) ( $raw['name'] ?? '' ) );
    if ( ! $name ) {
        return array( 'error' => 'Please provide a city name.' );
    }
    $lat = ( isset( $raw['lat'] ) && $raw['lat'] !== '' && $raw['lat'] !== null ) ? (float) $raw['lat'] : null;
    $lng = ( isset( $raw['lng'] ) && $raw['lng'] !== '' && $raw['lng'] !== null ) ? (float) $raw['lng'] : null;
    if ( $lat !== null && ( $lat < -90 || $lat > 90 ) ) {
        return array( 'error' => 'Latitude must be between -90 and 90.' );
    }
    if ( $lng !== null && ( $lng < -180 || $lng > 180 ) ) {
        return array( 'error' => 'Longitude must be between -180 and 180.' );
    }
    return array(
        'name'         => $name,
        'slug'         => sanitize_title( (string) ( $raw['slug'] ?? '' ) ?: $name ),
        'state'        => sanitize_text_field( (string) ( $raw['state'] ?? '' ) ),
        'country'      => sanitize_text_field( (string) ( $raw['country'] ?? '' ) ?: 'India' ),
        'lat'          => $lat,
        'lng'          => $lng,
        'airport_name' => sanitize_text_field( (string) ( $raw['airport_name'] ?? '' ) ),
        'airport_code' => strtoupper( sanitize_text_field( (string) ( $raw['airport_code'] ?? '' ) ) ),
        'sort_order'   => absint( $raw['sort_order'] ?? 0 ),
        'is_popular'   => ! empty( $raw['is_popular'] ) ? 1 : 0,
        // Only overwritten when the caller actually sent image_url (present in $raw at
        // all, even as ''), so a legacy caller that's never heard of this field — or a
        // plain city-details edit that didn't touch the photo — leaves the existing
        // uploaded image alone instead of silently wiping it back to blank.
        'image_url'    => array_key_exists( 'image_url', $raw ) ? esc_url_raw( (string) $raw['image_url'] ) : null,
        /* Default true/true (both roles enabled) when the field is absent, so a
           create/update call that doesn't mention these flags at all — e.g. any
           older client, or a form that hasn't been updated — keeps behaving
           exactly like before this feature existed: every city works as both a
           pickup and a drop city unless someone explicitly narrows it. */
        'is_origin_enabled'      => array_key_exists( 'is_origin_enabled', $raw ) ? ( ! empty( $raw['is_origin_enabled'] ) ? 1 : 0 ) : 1,
        'is_destination_enabled' => array_key_exists( 'is_destination_enabled', $raw ) ? ( ! empty( $raw['is_destination_enabled'] ) ? 1 : 0 ) : 1,
    );
}

/** Clears the 1-hour city-list transient cache (ridego_get_cities()/ridego_get_city()). */
function ridego_clear_cities_cache() {
    foreach ( array( '1', '0' ) as $active ) {
        foreach ( array( 'all', 'origin', 'destination' ) as $role ) {
            delete_transient( "ridego_cities_{$active}_{$role}" );
        }
    }
}

/**
 * Create a city. $is_active defaults to true (matches both the
 * legacy "Add City" form's default-checked checkbox and the REST
 * API's create behavior).
 */
function ridego_create_city( $raw, $is_active = true ) {
    global $wpdb;
    $data = ridego_validate_city_input( $raw );
    if ( isset( $data['error'] ) ) {
        return array( 'success' => false, 'message' => $data['error'] );
    }
    $data['is_active'] = $is_active ? 1 : 0;
    // A brand-new city with no photo uploaded yet gets the column's own default ('') —
    // never null (the column is NOT NULL).
    if ( $data['image_url'] === null ) { $data['image_url'] = ''; }

    $ctbl = $wpdb->prefix . 'ridego_cities';
    $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$ctbl} WHERE slug=%s", $data['slug'] ) );
    if ( $exists ) {
        return array( 'success' => false, 'message' => 'A city with this name/slug already exists.' );
    }
    $result = $wpdb->insert( $ctbl, $data );
    if ( ! $result ) {
        return array( 'success' => false, 'message' => 'Could not add city: ' . ( $wpdb->last_error ?: 'database error.' ) );
    }
    $id = (int) $wpdb->insert_id;
    ridego_audit_log( 'city_created', 'city', $id, '', $data );
    ridego_clear_cities_cache();
    return array( 'success' => true, 'id' => $id, 'message' => 'City added.' );
}

/**
 * Update a city. $is_active, when passed non-null, is written too
 * (both callers always send it explicitly today — the legacy
 * checkbox and the React form's toggle both submit a real boolean).
 */
function ridego_update_city( $id, $raw, $is_active = null ) {
    global $wpdb;
    $id   = (int) $id;
    $ctbl = $wpdb->prefix . 'ridego_cities';
    $old  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$ctbl} WHERE id=%d", $id ), ARRAY_A );
    if ( ! $old ) {
        return array( 'success' => false, 'message' => 'City not found.' );
    }
    $data = ridego_validate_city_input( $raw );
    if ( isset( $data['error'] ) ) {
        return array( 'success' => false, 'message' => $data['error'] );
    }
    if ( $is_active !== null ) {
        $data['is_active'] = $is_active ? 1 : 0;
    }
    /* On UPDATE (unlike create), a caller that never mentions these two
       flags — the legacy admin/pages/cities.php page, or any older/
       third-party caller that predates this feature — must leave the
       city's existing role flags exactly as they were, not silently
       reset them to "both enabled". ridego_validate_city_input()
       defaults an absent flag to 1 because that's the right behavior
       for CREATE (a brand new city with no role restriction yet); here
       we override that default back to whatever's already on the row
       whenever the raw input didn't actually specify the flag, so
       editing e.g. just a city's state never re-enables a role an
       admin had deliberately turned off. */
    if ( ! array_key_exists( 'is_origin_enabled', $raw ) ) {
        $data['is_origin_enabled'] = (int) $old['is_origin_enabled'];
    }
    if ( ! array_key_exists( 'is_destination_enabled', $raw ) ) {
        $data['is_destination_enabled'] = (int) $old['is_destination_enabled'];
    }
    // Same rule as the two role flags above: a plain details edit that never mentions
    // the photo must not wipe out an image an admin already uploaded.
    if ( $data['image_url'] === null ) {
        unset( $data['image_url'] );
    }
    $result = $wpdb->update( $ctbl, $data, array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not update city: ' . ( $wpdb->last_error ?: 'duplicate slug or database error.' ) );
    }
    ridego_audit_log( 'city_updated', 'city', $id, $old, $data );
    ridego_clear_cities_cache();
    return array( 'success' => true, 'message' => 'City updated.' );
}

/* ============================================================
   ROUTES — canonical write functions
   ------------------------------------------------------------
   Consolidation cleanup (follow-up to Wave 20's documented gap):
   admin/pages/cities.php's Routes tab and includes/app-admin-
   routes-api.php previously each did their own raw $wpdb add/edit/
   delete, with the same validation rules copy-pasted in two places
   (from/to city exist, not the same city, no negative distance/
   duration/toll/price, no duplicate route pair). Consolidated here
   so both callers can never drift on these rules again.
   ============================================================ */

/**
 * Validates + normalizes raw route input. $is_active: pass an
 * explicit bool (legacy page's checkbox-presence semantics), or
 * null to default to active (REST API's create-time default).
 * Returns array('error' => string) on invalid input.
 */
function ridego_validate_route_input( $raw, $is_active = null ) {
    global $wpdb;
    $ctbl = $wpdb->prefix . 'ridego_cities';

    $from_id = (int) ( $raw['from_city_id'] ?? 0 );
    $to_id   = (int) ( $raw['to_city_id'] ?? 0 );
    $from_c  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$ctbl} WHERE id=%d", $from_id ) );
    $to_c    = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$ctbl} WHERE id=%d", $to_id ) );

    $distance = (float) ( $raw['distance_km'] ?? 0 );
    $duration = (int) ( $raw['duration_mins'] ?? 0 );
    $toll_raw  = $raw['toll_estimate'] ?? null;
    $price_raw = $raw['default_fixed_price'] ?? null;
    $toll  = ( $toll_raw !== null && $toll_raw !== '' ) ? (float) $toll_raw : null;
    $price = ( $price_raw !== null && $price_raw !== '' ) ? (float) $price_raw : null;

    if ( ! $from_c || ! $to_c ) { return array( 'error' => 'Select valid from/to cities.' ); }
    if ( $from_id === $to_id ) { return array( 'error' => 'From and To city cannot be the same.' ); }
    if ( $distance < 0 ) { return array( 'error' => 'Distance cannot be negative.' ); }
    if ( $duration < 0 ) { return array( 'error' => 'Duration cannot be negative.' ); }
    if ( $toll !== null && $toll < 0 ) { return array( 'error' => 'Toll estimate cannot be negative.' ); }
    if ( $price !== null && $price < 0 ) { return array( 'error' => 'Fixed price cannot be negative.' ); }

    return array(
        'from_city_id' => $from_id,
        'to_city_id'   => $to_id,
        'from_city'    => $from_c->name,
        'to_city'      => $to_c->name,
        'distance_km'  => $distance,
        'duration_mins' => $duration,
        'toll_estimate' => $toll,
        'default_fixed_price' => $price,
        'is_popular'   => ! empty( $raw['is_popular'] ) ? 1 : 0,
        'is_active'    => $is_active === null ? 1 : ( $is_active ? 1 : 0 ),
    );
}

function ridego_create_route( $raw, $is_active = null ) {
    global $wpdb;
    $data = ridego_validate_route_input( $raw, $is_active );
    if ( isset( $data['error'] ) ) { return array( 'success' => false, 'message' => $data['error'] ); }

    $rtbl = $wpdb->prefix . 'ridego_routes';
    $dup  = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$rtbl} WHERE from_city_id=%d AND to_city_id=%d", $data['from_city_id'], $data['to_city_id']
    ) );
    if ( $dup ) { return array( 'success' => false, 'message' => 'A route between these two cities already exists.' ); }

    $result = $wpdb->insert( $rtbl, $data );
    if ( ! $result ) {
        return array( 'success' => false, 'message' => 'Could not add route: ' . ( $wpdb->last_error ?: 'database error.' ) );
    }
    $id = (int) $wpdb->insert_id;
    ridego_audit_log( 'route_created', 'route', $id, '', $data );
    return array( 'success' => true, 'id' => $id, 'message' => 'Route added.' );
}

function ridego_update_route( $id, $raw, $is_active = null ) {
    global $wpdb;
    $id   = (int) $id;
    $rtbl = $wpdb->prefix . 'ridego_routes';
    $old  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$rtbl} WHERE id=%d", $id ), ARRAY_A );
    if ( ! $old ) { return array( 'success' => false, 'message' => 'Route not found.' ); }

    $data = ridego_validate_route_input( $raw, $is_active );
    if ( isset( $data['error'] ) ) { return array( 'success' => false, 'message' => $data['error'] ); }

    $result = $wpdb->update( $rtbl, $data, array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not update route: ' . ( $wpdb->last_error ?: 'a route between these cities may already exist.' ) );
    }
    ridego_audit_log( 'route_updated', 'route', $id, $old, $data );
    // Route-page cache fix: a route's own distance/duration/city/active
    // fields feed straight into ridego_generate_route_page_content() —
    // bust the cache so an edit here is visible on the public page right
    // away, not after the transient's TTL.
    if ( function_exists( 'ridego_route_page_bust_content_cache' ) ) { ridego_route_page_bust_content_cache(); }
    return array( 'success' => true, 'message' => 'Route updated.' );
}

/** Hard delete, cascading the dependent vehicle-pricing overrides — matches the legacy page's own cleanup. */
function ridego_delete_route( $id ) {
    global $wpdb;
    $id    = (int) $id;
    $rtbl  = $wpdb->prefix . 'ridego_routes';
    $rvtbl = $wpdb->prefix . 'ridego_route_vehicle_pricing';
    $old   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$rtbl} WHERE id=%d", $id ), ARRAY_A );
    if ( ! $old ) { return array( 'success' => false, 'message' => 'Route not found.' ); }

    $result = $wpdb->delete( $rtbl, array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not delete route: ' . ( $wpdb->last_error ?: 'database error.' ) );
    }
    $wpdb->delete( $rvtbl, array( 'route_id' => $id ) );
    ridego_audit_log( 'route_deleted', 'route', $id, $old, '' );
    if ( function_exists( 'ridego_route_page_bust_content_cache' ) ) { ridego_route_page_bust_content_cache(); }
    return array( 'success' => true, 'message' => 'Route deleted.' );
}

/** Per-vehicle route pricing override — upserts by (route_id, vehicle_id). */
function ridego_save_route_vehicle_pricing( $route_id, $vehicle_id, $fixed_price_raw, $toll_estimate_raw ) {
    global $wpdb;
    $route_id   = (int) $route_id;
    $vehicle_id = (int) $vehicle_id;
    $fixed = ( $fixed_price_raw !== null && $fixed_price_raw !== '' ) ? (float) $fixed_price_raw : null;
    $toll  = ( $toll_estimate_raw !== null && $toll_estimate_raw !== '' ) ? (float) $toll_estimate_raw : null;

    if ( ! $route_id || ! $vehicle_id ) { return array( 'success' => false, 'message' => 'Select a vehicle to override.' ); }
    if ( $fixed !== null && $fixed < 0 ) { return array( 'success' => false, 'message' => 'Fixed price cannot be negative.' ); }
    if ( $toll !== null && $toll < 0 ) { return array( 'success' => false, 'message' => 'Toll estimate cannot be negative.' ); }

    $rvtbl = $wpdb->prefix . 'ridego_route_vehicle_pricing';
    $existing = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$rvtbl} WHERE route_id=%d AND vehicle_id=%d", $route_id, $vehicle_id
    ) );
    $data = array( 'fixed_price' => $fixed, 'toll_estimate' => $toll, 'updated_at' => current_time( 'mysql' ) );

    if ( $existing ) {
        $result = $wpdb->update( $rvtbl, $data, array( 'id' => $existing ) );
        $id = (int) $existing;
        $action = 'route_vehicle_pricing_updated';
    } else {
        $data['route_id'] = $route_id;
        $data['vehicle_id'] = $vehicle_id;
        $result = $wpdb->insert( $rvtbl, $data );
        $id = (int) $wpdb->insert_id;
        $action = 'route_vehicle_pricing_created';
    }
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not save vehicle price override: ' . ( $wpdb->last_error ?: 'database error.' ) );
    }
    ridego_audit_log( $action, 'route_vehicle_pricing', $id, '', $data );
    if ( function_exists( 'ridego_route_page_bust_content_cache' ) ) { ridego_route_page_bust_content_cache(); }
    return array( 'success' => true, 'id' => $id, 'message' => 'Vehicle price override saved.' );
}

function ridego_delete_route_vehicle_pricing( $id ) {
    global $wpdb;
    $id    = (int) $id;
    $rvtbl = $wpdb->prefix . 'ridego_route_vehicle_pricing';
    $old   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$rvtbl} WHERE id=%d", $id ), ARRAY_A );
    $result = $wpdb->delete( $rvtbl, array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not remove override.' );
    }
    ridego_audit_log( 'route_vehicle_pricing_deleted', 'route_vehicle_pricing', $id, $old ?: '', '' );
    if ( function_exists( 'ridego_route_page_bust_content_cache' ) ) { ridego_route_page_bust_content_cache(); }
    return array( 'success' => true, 'message' => 'Vehicle price override removed.' );
}

/* ============================================================
   ZONES — canonical write functions (same consolidation as
   cities/routes above; see ridego_migration_006_zones() for the
   center-point + radius data-model rationale).
   ============================================================ */

function ridego_validate_zone_input( $raw, $is_active = null ) {
    $city_id = (int) ( $raw['city_id'] ?? 0 );
    $lat     = (float) ( $raw['center_lat'] ?? 0 );
    $lng     = (float) ( $raw['center_lng'] ?? 0 );
    $radius  = (float) ( $raw['radius_km'] ?? 0 );

    if ( ! $city_id ) { return array( 'error' => 'Select a city for this zone.' ); }
    if ( $lat < -90 || $lat > 90 ) { return array( 'error' => 'Latitude must be between -90 and 90.' ); }
    if ( $lng < -180 || $lng > 180 ) { return array( 'error' => 'Longitude must be between -180 and 180.' ); }
    if ( $radius <= 0 ) { return array( 'error' => 'Radius must be greater than 0.' ); }

    return array(
        'city_id'    => $city_id,
        'name'       => sanitize_text_field( (string) ( $raw['name'] ?? '' ) ),
        'center_lat' => $lat,
        'center_lng' => $lng,
        'radius_km'  => $radius,
        'is_active'  => $is_active === null ? 1 : ( $is_active ? 1 : 0 ),
    );
}

function ridego_create_zone( $raw, $is_active = null ) {
    global $wpdb;
    $data = ridego_validate_zone_input( $raw, $is_active );
    if ( isset( $data['error'] ) ) { return array( 'success' => false, 'message' => $data['error'] ); }

    $ztbl   = $wpdb->prefix . 'ridego_zones';
    $result = $wpdb->insert( $ztbl, $data );
    if ( ! $result ) {
        return array( 'success' => false, 'message' => 'Could not add zone: ' . ( $wpdb->last_error ?: 'database error.' ) );
    }
    $id = (int) $wpdb->insert_id;
    ridego_audit_log( 'zone_created', 'zone', $id, '', $data );
    return array( 'success' => true, 'id' => $id, 'message' => 'Zone added.' );
}

function ridego_update_zone( $id, $raw, $is_active = null ) {
    global $wpdb;
    $id   = (int) $id;
    $ztbl = $wpdb->prefix . 'ridego_zones';
    $old  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$ztbl} WHERE id=%d", $id ), ARRAY_A );
    if ( ! $old ) { return array( 'success' => false, 'message' => 'Zone not found.' ); }

    $data = ridego_validate_zone_input( $raw, $is_active );
    if ( isset( $data['error'] ) ) { return array( 'success' => false, 'message' => $data['error'] ); }

    $result = $wpdb->update( $ztbl, $data, array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not update zone: ' . ( $wpdb->last_error ?: 'database error.' ) );
    }
    ridego_audit_log( 'zone_updated', 'zone', $id, $old, $data );
    return array( 'success' => true, 'message' => 'Zone updated.' );
}

/**
 * Hard delete. A zone with surge rules pinned to it (ridego_surge_
 * pricing.zone_id) has no cascade — those rules fall back to
 * city-wide matching, not deleted or orphaned incorrectly. Both
 * callers surface that warning to the admin before calling this.
 */
function ridego_delete_zone( $id ) {
    global $wpdb;
    $id   = (int) $id;
    $ztbl = $wpdb->prefix . 'ridego_zones';
    $old  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$ztbl} WHERE id=%d", $id ), ARRAY_A );
    if ( ! $old ) { return array( 'success' => false, 'message' => 'Zone not found.' ); }

    $result = $wpdb->delete( $ztbl, array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not delete zone: ' . ( $wpdb->last_error ?: 'database error.' ) );
    }
    ridego_audit_log( 'zone_deleted', 'zone', $id, $old, '' );
    return array( 'success' => true, 'message' => 'Zone deleted.' );
}

/**
 * Toggle (or explicitly set) a city's is_active flag. With no
 * $force argument, flips the current value (matches both the legacy
 * page's "toggle" action and its "delete" action, which is really
 * the same soft-deactivate — see the REST API's own doc comment on
 * why it's honestly named "toggle" there too).
 */
function ridego_toggle_city_active( $id, $force = null ) {
    global $wpdb;
    $id   = (int) $id;
    $ctbl = $wpdb->prefix . 'ridego_cities';
    $existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$ctbl} WHERE id=%d", $id ) );
    if ( ! $existing ) {
        return array( 'success' => false, 'message' => 'City not found.' );
    }
    $new_active = $force !== null ? ( $force ? 1 : 0 ) : ( $existing->is_active ? 0 : 1 );
    $result = $wpdb->update( $ctbl, array( 'is_active' => $new_active ), array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not change city status.' );
    }
    ridego_audit_log( 'city_toggled', 'city', $id, 'is_active=' . (int) $existing->is_active, 'is_active=' . $new_active );
    ridego_clear_cities_cache();
    return array(
        'success'   => true,
        'is_active' => (bool) $new_active,
        'message'   => $new_active ? 'City activated.' : 'City deactivated.',
    );
}

/* ================================================================
   VEHICLE PRICING + SURGE PRICING — canonical write functions
   ------------------------------------------------------------
   Cleanup pass 4: admin/pages/pricing.php + admin/pages/surge.php
   and includes/app-admin-pricing-api.php previously each ran their
   own raw $wpdb inserts/updates for the same two tables
   (wp_ridego_vehicles rate fields, wp_ridego_surge_pricing rules).
   Consolidated here, following the same pattern as cities/routes/
   zones. Both tables feed LIVE customer-facing fare quotes via
   ridego_calculate_fare() (includes/pricing.php) — the surge
   0.5-5.0 multiplier clamp is a real safety rail from the legacy
   page (client-side HTML min/max alone is bypassable) and is
   preserved here exactly, not relaxed.
   ================================================================ */

/**
 * Field set and defaults copied exactly from admin/pages/pricing.php's
 * save handler — all rate fields floatval(), name sanitized,
 * capacities absint() with the legacy defaults (4 seats, 2 luggage)
 * when omitted.
 */
function ridego_validate_vehicle_pricing_input( $raw, $is_active = null ) {
    $rate_fields = array(
        'base_price_per_km', 'base_price_outstation', 'minimum_km', 'night_charge_pct',
        'driver_allowance_day', 'extra_hour_charge', 'airport_base_charge',
        'local_4hr_40km', 'local_8hr_80km', 'local_extra_km', 'local_extra_hr',
        'lead_fee_fixed', 'lead_fee_pct',
    );
    $name = sanitize_text_field( (string) ( isset( $raw['name'] ) ? $raw['name'] : '' ) );
    if ( ! $name ) {
        return array( 'error' => 'Please provide a vehicle name.' );
    }
    $data = array();
    foreach ( $rate_fields as $f ) {
        $val = isset( $raw[ $f ] ) ? (float) $raw[ $f ] : 0.0;
        if ( $val < 0 ) {
            return array( 'error' => 'Pricing fields cannot be negative.' );
        }
        $data[ $f ] = $val;
    }
    $data['name']             = $name;
    $data['seating_capacity'] = isset( $raw['seating_capacity'] ) && $raw['seating_capacity'] !== '' ? absint( $raw['seating_capacity'] ) : 4;
    $data['luggage_capacity'] = isset( $raw['luggage_capacity'] ) && $raw['luggage_capacity'] !== '' ? absint( $raw['luggage_capacity'] ) : 2;
    $data['ac_available']     = ! empty( $raw['ac_available'] ) ? 1 : 0;
    $data['lead_fee_mode']    = sanitize_key( (string) ( ! empty( $raw['lead_fee_mode'] ) ? $raw['lead_fee_mode'] : 'fixed' ) );
    $data['is_active']        = $is_active === null ? 1 : ( $is_active ? 1 : 0 );
    return $data;
}

function ridego_create_vehicle_type( $raw, $is_active = null ) {
    global $wpdb;
    $data = ridego_validate_vehicle_pricing_input( $raw, $is_active );
    if ( isset( $data['error'] ) ) { return array( 'success' => false, 'message' => $data['error'] ); }

    $data['slug'] = sanitize_title( $data['name'] );
    $vtbl   = $wpdb->prefix . 'ridego_vehicles';
    $result = $wpdb->insert( $vtbl, $data );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not add vehicle type. The slug may already be in use.' );
    }
    $id = (int) $wpdb->insert_id;
    ridego_audit_log( 'vehicle_created', 'vehicle', $id, '', $data['name'] );
    // A new/changed vehicle type affects EVERY route page's vehicle list
    // and fare figures, not just one route, so this busts the whole cache
    // generation rather than a single route_id.
    if ( function_exists( 'ridego_route_page_bust_content_cache' ) ) { ridego_route_page_bust_content_cache(); }
    return array( 'success' => true, 'id' => $id, 'message' => 'New vehicle type added.' );
}

function ridego_update_vehicle_type( $id, $raw, $is_active = null ) {
    global $wpdb;
    $id   = (int) $id;
    $vtbl = $wpdb->prefix . 'ridego_vehicles';
    $old  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$vtbl} WHERE id=%d", $id ), ARRAY_A );
    if ( ! $old ) { return array( 'success' => false, 'message' => 'Vehicle type not found.' ); }

    $data = ridego_validate_vehicle_pricing_input( $raw, $is_active );
    if ( isset( $data['error'] ) ) { return array( 'success' => false, 'message' => $data['error'] ); }

    $result = $wpdb->update( $vtbl, $data, array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not save pricing.' );
    }
    ridego_audit_log( 'vehicle_pricing_updated', 'vehicle', $id, $old, $data );
    if ( function_exists( 'ridego_route_page_bust_content_cache' ) ) { ridego_route_page_bust_content_cache(); }
    return array( 'success' => true, 'message' => 'Pricing saved for ' . $data['name'] . '.' );
}

/**
 * Toggle (or explicitly set) a vehicle type's is_active flag. With
 * no $force argument, flips the current value — a superset of the
 * legacy page's own action, which only ever deactivates (its
 * "Deactivate" button has no reactivate counterpart in the UI, but
 * the underlying operation is the same is_active flip this performs).
 */
function ridego_toggle_vehicle_active( $id, $force = null ) {
    global $wpdb;
    $id   = (int) $id;
    $vtbl = $wpdb->prefix . 'ridego_vehicles';
    $existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$vtbl} WHERE id=%d", $id ) );
    if ( ! $existing ) {
        return array( 'success' => false, 'message' => 'Vehicle type not found.' );
    }
    $new_active = $force !== null ? ( $force ? 1 : 0 ) : ( $existing->is_active ? 0 : 1 );
    $result = $wpdb->update( $vtbl, array( 'is_active' => $new_active ), array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not change vehicle status.' );
    }
    ridego_audit_log( 'vehicle_toggled', 'vehicle', $id, 'is_active=' . (int) $existing->is_active, 'is_active=' . $new_active );
    if ( function_exists( 'ridego_route_page_bust_content_cache' ) ) { ridego_route_page_bust_content_cache(); }
    return array(
        'success'   => true,
        'is_active' => (bool) $new_active,
        'message'   => $new_active ? 'Vehicle activated.' : 'Vehicle deactivated.',
    );
}

/**
 * Field set and the 0.5-5.0 multiplier clamp copied exactly from
 * admin/pages/surge.php's save handler — that clamp is a real
 * safety rail (its own comment: client-side HTML min/max alone is
 * bypassable), preserved here, not relaxed.
 */
function ridego_validate_surge_input( $raw, $is_active = null ) {
    $multiplier = isset( $raw['multiplier'] ) ? (float) $raw['multiplier'] : 0.0;
    if ( $multiplier < 0.5 ) { $multiplier = 0.5; }
    if ( $multiplier > 5.0 ) { $multiplier = 5.0; }

    $from_date = sanitize_text_field( (string) ( isset( $raw['from_date'] ) ? $raw['from_date'] : '' ) );
    $to_date   = sanitize_text_field( (string) ( isset( $raw['to_date'] ) ? $raw['to_date'] : '' ) );
    if ( ! $from_date || ! $to_date ) {
        return array( 'error' => 'Please provide a start and end date.' );
    }

    $zone_id_raw = isset( $raw['zone_id'] ) ? (int) $raw['zone_id'] : 0;
    /* Root-cause fix (found during the #63 pricing-config audit, reproduced live): a surge rule left
       without a specific vehicle is meant to apply to every vehicle type — ridego_get_surge_multiplier()
       matches that with "vehicle_id IS NULL". This used to store 0 instead of NULL for that case (the
       exact same 0-vs-NULL gap zone_id below already guards against), so a genuine "applies to all
       vehicles" surge rule NEVER matched any query, however correctly it was configured (right dates,
       right city, is_active=1) — confirmed live: a freshly created citywide rule with multiplier 1.5
       returned a multiplier of 1.0 for every vehicle. */
    $vehicle_id_raw = isset( $raw['vehicle_id'] ) ? (int) $raw['vehicle_id'] : 0;

    return array(
        'vehicle_id' => $vehicle_id_raw ?: null,
        'city'       => sanitize_text_field( (string) ( isset( $raw['city'] ) ? $raw['city'] : '' ) ),
        'zone'       => sanitize_text_field( (string) ( isset( $raw['zone'] ) ? $raw['zone'] : '' ) ),
        'zone_id'    => $zone_id_raw ?: null,
        'from_date'  => $from_date,
        'to_date'    => $to_date,
        'time_from'  => sanitize_text_field( (string) ( ! empty( $raw['time_from'] ) ? $raw['time_from'] : '00:00' ) ),
        'time_to'    => sanitize_text_field( (string) ( ! empty( $raw['time_to'] ) ? $raw['time_to'] : '23:59' ) ),
        'multiplier' => $multiplier,
        'reason'     => sanitize_text_field( (string) ( isset( $raw['reason'] ) ? $raw['reason'] : '' ) ),
        'is_active'  => $is_active === null ? 1 : ( $is_active ? 1 : 0 ),
    );
}

function ridego_create_surge_rule( $raw, $is_active = null ) {
    global $wpdb;
    $data = ridego_validate_surge_input( $raw, $is_active );
    if ( isset( $data['error'] ) ) { return array( 'success' => false, 'message' => $data['error'] ); }

    $tbl    = $wpdb->prefix . 'ridego_surge_pricing';
    $result = $wpdb->insert( $tbl, $data );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not create surge rule.' );
    }
    $id = (int) $wpdb->insert_id;
    ridego_audit_log( 'surge_rule_created', 'surge_pricing', $id, '', $data );
    return array( 'success' => true, 'id' => $id, 'message' => 'Surge rule created.' );
}

function ridego_update_surge_rule( $id, $raw, $is_active = null ) {
    global $wpdb;
    $id  = (int) $id;
    $tbl = $wpdb->prefix . 'ridego_surge_pricing';
    $old = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id=%d", $id ), ARRAY_A );
    if ( ! $old ) { return array( 'success' => false, 'message' => 'Surge rule not found.' ); }

    $data = ridego_validate_surge_input( $raw, $is_active );
    if ( isset( $data['error'] ) ) { return array( 'success' => false, 'message' => $data['error'] ); }

    $result = $wpdb->update( $tbl, $data, array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not update surge rule.' );
    }
    ridego_audit_log( 'surge_rule_updated', 'surge_pricing', $id, $old, $data );
    return array( 'success' => true, 'message' => 'Surge rule updated.' );
}

function ridego_delete_surge_rule( $id ) {
    global $wpdb;
    $id  = (int) $id;
    $tbl = $wpdb->prefix . 'ridego_surge_pricing';
    $old = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id=%d", $id ), ARRAY_A );
    if ( ! $old ) { return array( 'success' => false, 'message' => 'Surge rule not found.' ); }

    $result = $wpdb->delete( $tbl, array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not delete surge rule: ' . ( $wpdb->last_error ?: 'database error.' ) );
    }
    ridego_audit_log( 'surge_rule_deleted', 'surge_pricing', $id, $old, '' );
    return array( 'success' => true, 'message' => 'Surge rule deleted.' );
}

/* ================================================================
   PROMO CODES — canonical write functions
   ------------------------------------------------------------
   Cleanup pass 5 (the last "no canonical function" item flagged in
   the Waves 17-21 caveats): admin/pages/promo.php and
   includes/app-admin-promo-api.php previously each ran their own
   raw $wpdb calls for add/edit/toggle on wp_ridego_promo_codes.
   Consolidated here, following the same pattern as every prior
   cleanup pass.

   Note: admin/pages/promo.php's own inline comment documents an
   earlier root-cause fix already made to this page (real column
   names — min_booking_amount/expiry_date/start_date/trip_type, not
   the nonexistent min_fare/valid_until/trip_types the form used to
   write to — plus the 'percentage' value matching what
   includes/promo.php's redemption calculation actually checks for
   instead of the 'percent' it used to send). That fix is preserved
   here exactly; this consolidation is structural, not a re-fix of
   already-fixed logic.

   Create is an upsert-by-code (matches both callers' existing
   behavior): if a promo with the submitted code already exists, the
   "create" action updates that row instead of failing on a unique-
   key violation — surfaced honestly in the returned message.
   ================================================================ */

function ridego_validate_promo_input( $raw, $is_active = null ) {
    $code = strtoupper( sanitize_text_field( (string) ( isset( $raw['code'] ) ? $raw['code'] : '' ) ) );
    if ( ! $code ) {
        return array( 'error' => 'Please provide a promo code.' );
    }
    $discount_type_raw = sanitize_key( (string) ( isset( $raw['discount_type'] ) ? $raw['discount_type'] : '' ) );
    $trip_types_raw = isset( $raw['trip_type'] ) ? (array) $raw['trip_type'] : array();
    $trip_types = array_map( 'sanitize_key', $trip_types_raw );

    return array(
        'code'               => $code,
        'description'        => sanitize_text_field( (string) ( isset( $raw['description'] ) ? $raw['description'] : '' ) ),
        'discount_type'      => ( $discount_type_raw === 'percent' || $discount_type_raw === 'percentage' ) ? 'percentage' : 'fixed',
        'discount_value'     => isset( $raw['discount_value'] ) ? (float) $raw['discount_value'] : 0.0,
        'min_booking_amount' => isset( $raw['min_booking_amount'] ) ? (float) $raw['min_booking_amount'] : 0.0,
        'max_discount'       => isset( $raw['max_discount'] ) ? (float) $raw['max_discount'] : 0.0,
        'usage_limit'        => isset( $raw['usage_limit'] ) ? (int) $raw['usage_limit'] : 0,
        'start_date'         => sanitize_text_field( (string) ( ! empty( $raw['start_date'] ) ? $raw['start_date'] : gmdate( 'Y-m-d' ) ) ),
        'expiry_date'        => sanitize_text_field( (string) ( ! empty( $raw['expiry_date'] ) ? $raw['expiry_date'] : gmdate( 'Y-m-d', strtotime( '+30 days' ) ) ) ),
        'trip_type'          => empty( $trip_types ) ? null : maybe_serialize( $trip_types ),
        'is_active'          => $is_active === null ? 1 : ( $is_active ? 1 : 0 ),
        'updated_at'         => current_time( 'mysql' ),
    );
}

/**
 * Upsert-by-code: if the submitted code already exists, updates
 * that row instead of failing on the unique-key violation a plain
 * insert would hit — matches both legacy callers' existing
 * behavior, surfaced honestly via the returned message.
 */
function ridego_create_promo( $raw, $is_active = null ) {
    global $wpdb;
    $data = ridego_validate_promo_input( $raw, $is_active );
    if ( isset( $data['error'] ) ) { return array( 'success' => false, 'message' => $data['error'] ); }

    $tbl = $wpdb->prefix . 'ridego_promo_codes';
    $existing_id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$tbl} WHERE code=%s", $data['code'] ) );
    if ( $existing_id ) {
        $old    = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id=%d", $existing_id ), ARRAY_A );
        $result = $wpdb->update( $tbl, $data, array( 'code' => $data['code'] ) );
        if ( false === $result ) {
            return array( 'success' => false, 'message' => 'Could not save this promo code: ' . ( $wpdb->last_error ?: 'database error.' ) );
        }
        ridego_audit_log( 'promo_updated', 'promo_code', (int) $existing_id, $old, $data );
        return array( 'success' => true, 'id' => (int) $existing_id, 'message' => 'Promo updated (code already existed).' );
    }

    $data['created_at'] = current_time( 'mysql' );
    $data['used_count'] = 0;
    $result = $wpdb->insert( $tbl, $data );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not create this promo code: ' . ( $wpdb->last_error ?: 'database error.' ) );
    }
    $id = (int) $wpdb->insert_id;
    ridego_audit_log( 'promo_created', 'promo_code', $id, '', $data );
    return array( 'success' => true, 'id' => $id, 'message' => 'New promo code created!' );
}

function ridego_update_promo( $id, $raw, $is_active = null ) {
    global $wpdb;
    $id  = (int) $id;
    $tbl = $wpdb->prefix . 'ridego_promo_codes';
    $old = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id=%d", $id ), ARRAY_A );
    if ( ! $old ) { return array( 'success' => false, 'message' => 'Promo code not found.' ); }

    $data = ridego_validate_promo_input( $raw, $is_active );
    if ( isset( $data['error'] ) ) { return array( 'success' => false, 'message' => $data['error'] ); }

    $result = $wpdb->update( $tbl, $data, array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not save this promo code: ' . ( $wpdb->last_error ?: 'database error.' ) );
    }
    ridego_audit_log( 'promo_updated', 'promo_code', $id, $old, $data );
    return array( 'success' => true, 'message' => 'Promo code updated.' );
}

function ridego_toggle_promo_active( $id, $force = null ) {
    global $wpdb;
    $id  = (int) $id;
    $tbl = $wpdb->prefix . 'ridego_promo_codes';
    $existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id=%d", $id ) );
    if ( ! $existing ) {
        return array( 'success' => false, 'message' => 'Promo code not found.' );
    }
    $new_active = $force !== null ? ( $force ? 1 : 0 ) : ( $existing->is_active ? 0 : 1 );
    $result = $wpdb->update( $tbl, array( 'is_active' => $new_active ), array( 'id' => $id ) );
    if ( false === $result ) {
        return array( 'success' => false, 'message' => 'Could not change promo code status.' );
    }
    ridego_audit_log( 'promo_toggled', 'promo_code', $id, 'is_active=' . (int) $existing->is_active, 'is_active=' . $new_active );
    return array(
        'success'   => true,
        'is_active' => (bool) $new_active,
        'message'   => $new_active ? 'Promo activated.' : 'Promo paused.',
    );
}
