<?php
/**
 * RideGo Platform - Pricing Engine
 * 
 * Handles all fare calculations and pricing logic:
 * - Base fare calculation (distance × per-km rate)
 * - Dynamic pricing (demand-based surge)
 * - Route-specific fixed pricing
 * - Service type pricing (one-way, round-trip, local packages, airport)
 * - Surcharges (night, toll, parking, driver allowance)
 * - Promo code application
 * - GST calculation
 * - Lead fee calculation for vendors
 * 
 * Pricing Formula (from spec):
 * BASE_FARE = Max(minimum_km, actual_distance_km) × per_km_rate 
 *           + driver_allowance + toll_estimate + parking + surcharges 
 *           - discounts + 5% GST
 * 
 * @package RideGo
 * @subpackage Pricing
 * @version 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main fare calculator - calculates complete trip fare
 * 
 * @param array $params Booking parameters
 * @return array Fare breakdown with all components
 */
function ridego_calculate_fare($params) {

    // Extract parameters
    $trip_type      = $params['trip_type'] ?? 'one_way';
    $vehicle_id     = $params['vehicle_type_id'] ?? 0;
    $distance_km    = $params['distance_km'] ?? 0;
    $pickup_city    = $params['pickup_city'] ?? '';
    $drop_city      = $params['drop_city'] ?? '';
    $journey_date   = $params['journey_date'] ?? date('Y-m-d');
    $journey_time   = $params['journey_time'] ?? date('H:i:s');

    // Root-cause fix: 'hourly' has never been a real trip_type this
    // function (or the DB schema) recognizes — only 'local' is. The
    // React frontend's "Hourly rental" option was sending the literal
    // string 'hourly', which fell through every case below to the
    // one_way default, silently pricing hours-based rentals as
    // point-to-point per-km trips. Normalizing here protects every
    // caller (REST /app/fare, booking creation, any future client),
    // not just the frontends that have since been fixed to send 'local'
    // directly.
    if ( $trip_type === 'hourly' ) {
        $trip_type = 'local';
    }

    // Root-cause fix: every caller of this function (the live fare
    // preview AND actual booking creation — ridego_create_booking()
    // calls this same function to compute the fare that's actually
    // charged) has always relied on the CLIENT to supply an accurate
    // distance_km. The React frontend never computed one and always
    // sent 0, so every one_way/round_trip/airport/outstation fare was
    // silently priced at the vehicle's bare minimum_km floor, ignoring
    // the real trip length entirely. Resolving a real distance
    // server-side here — from admin-curated route data first, a
    // geographic estimate second — fixes the fare everywhere this
    // function is used, not just in whichever frontend screen happens
    // to be patched, and cannot be bypassed by a client that forgets
    // to send a distance.
    $duration_minutes = (int) ( $params['duration_minutes'] ?? 0 );
    if ( $distance_km <= 0 && $pickup_city && $drop_city && $pickup_city !== $drop_city ) {
        $resolved = ridego_resolve_route_distance( $pickup_city, $drop_city );
        if ( $resolved && $resolved['distance_km'] > 0 ) {
            $distance_km = $resolved['distance_km'];
            if ( $duration_minutes <= 0 ) {
                $duration_minutes = (int) $resolved['duration_minutes'];
            }
        }
    }
    $hours_required = $params['hours_required'] ?? 0;
    $promo_code     = $params['promo_code'] ?? '';

    // Root-cause fix: this function's returned breakdown never included a
    // 'duration_minutes' key at all (only ridego_resolve_route_distance()'s
    // own private return array had one, and it was never copied out here).
    // ridego_create_booking() (includes/booking.php) reads
    // $fare_result['duration_minutes'] straight into the INSERT for the
    // NOT NULL wp_ridego_bookings.duration_minutes column — so every real
    // booking, through every trip type and payment method, has always
    // failed at the database with "Column 'duration_minutes' cannot be
    // null" the moment OTP verification (fixed separately, see otp.php)
    // let a request reach this far. Estimate a real value whenever the
    // client didn't supply one and the route resolver above didn't either
    // (e.g. a 'local' rental, which has no pickup/drop pair to resolve):
    // 45 km/h average for distance-based trips, or the requested hours for
    // an hours-based rental.
    if ( $duration_minutes <= 0 ) {
        if ( $trip_type === 'local' && $hours_required > 0 ) {
            $duration_minutes = (int) $hours_required * 60;
        } elseif ( $distance_km > 0 ) {
            $duration_minutes = (int) round( ( $distance_km / 45 ) * 60 );
        }
    }
    
    // Get vehicle pricing data
    $vehicle = ridego_get_vehicle_type($vehicle_id);
    if (!$vehicle) {
        return array('error' => 'Invalid vehicle type');
    }
    
    // Initialize fare breakdown
    $breakdown = array(
        'base_fare'          => 0,
        'distance_km'        => $distance_km,
        'duration_minutes'   => $duration_minutes,
        'minimum_km'         => $vehicle->minimum_km,
        'per_km_rate'        => 0,
        'toll_charges'       => 0,
        'parking_charges'    => 0,
        'driver_allowance'   => 0,
        'night_charge'       => 0,
        'surge_multiplier'   => 1.0,
        'surge_amount'       => 0,
        'extra_km_charges'   => 0,
        'extra_hour_charge'  => 0,
        'subtotal'           => 0,
        'discount_amount'    => 0,
        'promo_code'         => '',
        'gst_percent'        => 5,
        'gst_amount'         => 0,
        'total_fare'         => 0,
        'inclusions'         => array(),
        'exclusions'         => array()
    );
    
    // Calculate based on trip type
    switch ($trip_type) {
        
        case 'one_way':
            $breakdown = ridego_calculate_oneway_fare($vehicle, $distance_km, $pickup_city, $drop_city, $breakdown);
            break;
            
        case 'round_trip':
            $breakdown = ridego_calculate_roundtrip_fare($vehicle, $distance_km, $pickup_city, $drop_city, $breakdown);
            break;
            
        case 'local':
            $breakdown = ridego_calculate_local_fare($vehicle, $hours_required, $distance_km, $breakdown);
            break;
            
        case 'airport_pickup':
        case 'airport_drop':
            $breakdown = ridego_calculate_airport_fare($vehicle, $distance_km, $trip_type, $pickup_city, $drop_city, $breakdown);
            break;
            
        case 'outstation':
            $breakdown = ridego_calculate_outstation_fare($vehicle, $distance_km, $params, $breakdown);
            break;
            
        default:
            $breakdown = ridego_calculate_oneway_fare($vehicle, $distance_km, $pickup_city, $drop_city, $breakdown);
    }
    
    // Apply time-based surcharges
    $breakdown = ridego_apply_time_surcharges($breakdown, $journey_date, $journey_time);
    
    // Apply demand-based surge pricing (zone-aware when a pickup lat/lng was supplied)
    $pickup_lat = isset($params['pickup_lat']) ? (float) $params['pickup_lat'] : null;
    $pickup_lng = isset($params['pickup_lng']) ? (float) $params['pickup_lng'] : null;
    $breakdown = ridego_apply_surge_pricing($breakdown, $vehicle_id, $pickup_city, $drop_city, $journey_date, $journey_time, $pickup_lat, $pickup_lng);
    
    // Calculate subtotal before discount
    $breakdown['subtotal'] = $breakdown['base_fare'] 
                           + $breakdown['toll_charges']
                           + $breakdown['parking_charges']
                           + $breakdown['driver_allowance']
                           + $breakdown['night_charge']
                           + $breakdown['surge_amount']
                           + $breakdown['extra_km_charges']
                           + $breakdown['extra_hour_charge'];
    
    // Apply promo code discount
    if (!empty($promo_code)) {
        $discount = ridego_apply_promo_code($promo_code, $breakdown['subtotal'], $params);
        if ($discount['valid']) {
            $breakdown['discount_amount'] = $discount['discount_amount'];
            $breakdown['promo_code'] = $promo_code;
        }
    }
    
    // Calculate GST — real admin toggle (gst_enabled) and rate (gst_percent),
    // not a hardcoded 5%. Root-cause fix: this used to always apply 0.05
    // regardless of the Settings → Payment "Include GST in fare calculations"
    // toggle, so disabling GST in the admin UI never actually removed it from
    // any real booking's fare — the toggle existed but nothing read it.
    $taxable_amount = $breakdown['subtotal'] - $breakdown['discount_amount'];
    $gst_enabled = (bool) ridego_get_setting( 'gst_enabled', 1 );
    $gst_percent = (float) ridego_get_setting( 'gst_percent', 5 );
    $breakdown['gst_percent'] = $gst_percent;
    $breakdown['gst_enabled'] = $gst_enabled;
    $breakdown['gst_amount'] = $gst_enabled ? round( $taxable_amount * ( $gst_percent / 100 ), 2 ) : 0.0;
    
    // Calculate total fare
    $breakdown['total_fare'] = $taxable_amount + $breakdown['gst_amount'];

    /* Token Amount / Advance Payment: the token is part of the total ride
       price, never an additional fee stacked on top (e.g. Ride Cost ₹2,000
       + GST etc. = Total ₹2,500; Token ₹500 is carved OUT of that ₹2,500,
       leaving Remaining ₹2,000 — never ₹2,500 + ₹500 on top). Read live
       from settings here so the fare-preview endpoint and booking creation
       (which both call this one function) always agree; the amount is
       snapshotted onto the booking row at creation time in
       ridego_create_booking() so a later admin change never retroactively
       alters an existing booking. */
    /* Facilitator model: RideGo ALWAYS collects only the booking amount (fixed or a percentage of the estimated fare, see ridego_booking_amount_for()).
       The rest of the fare is billed and collected by the vendor/driver. token_enabled stays in the payload (always true) so older clients keep working.
       booking_amount / payable_to_vendor are the clearer names; token_amount / remaining_amount are kept as aliases. */
    $token_amount = ridego_booking_amount_for($breakdown['total_fare']);
    $breakdown['token_enabled']       = true;
    $breakdown['token_amount']        = round($token_amount, 2);
    $breakdown['remaining_amount']    = round($breakdown['total_fare'] - $token_amount, 2);
    $breakdown['booking_amount']      = $breakdown['token_amount'];
    $breakdown['payable_to_vendor']   = $breakdown['remaining_amount'];
    $breakdown['estimated_ride_fare'] = round($breakdown['total_fare'], 2);
    $breakdown['token_label']         = ridego_platform_text('token_label');
    $breakdown['token_instructions']  = ridego_platform_text('token_instructions');
    $breakdown['disclaimer']          = ridego_platform_text('disclaimer_client');

    // Add inclusions and exclusions
    $breakdown['inclusions'] = ridego_get_fare_inclusions($trip_type, $vehicle);
    $breakdown['exclusions'] = ridego_get_fare_exclusions($trip_type);

    /* Root-cause fix: floating-point currency values (e.g. 1946.3999999999999
       instead of 1946.40) were reaching every consumer of this function's
       return value. Only 4 of the ~15 monetary breakdown keys were ever
       rounded (night_charge, surge_amount, gst_amount, token_amount,
       remaining_amount, estimated_ride_fare) — base_fare, toll_charges,
       parking_charges, driver_allowance, extra_km_charges,
       extra_hour_charge, roundtrip_discount, discount_amount, subtotal and
       total_fare were left as raw PHP float arithmetic (billable_km ×
       per_km_rate, percentage discounts, running sums of the above), which
       is inherently imprecise in binary floating point. Every consumer —
       the fare-preview REST endpoint, ridego_create_booking() (so the
       amount actually stored on the booking row), and every frontend
       screen that reads these fields (Admin New Booking, Vendor Booking
       Detail, RideMoneyCard, ConfirmPage, Admin Invoice) — inherited
       whichever precision this function happened to produce.
       Rounding centrally, once, here — rather than patching each of the
       five trip-type sub-functions or each frontend display site
       individually — guarantees every caller, current and future, always
       receives clean 2-decimal currency values regardless of which code
       path produced them. */
    $money_keys = array(
        'base_fare', 'per_km_rate', 'toll_charges', 'parking_charges',
        'driver_allowance', 'night_charge', 'surge_amount',
        'extra_km_charges', 'extra_hour_charge', 'subtotal',
        'roundtrip_discount', 'discount_amount', 'gst_amount',
        'total_fare', 'token_amount', 'remaining_amount',
        'booking_amount', 'payable_to_vendor', 'estimated_ride_fare',
    );
    foreach ( $money_keys as $key ) {
        if ( isset( $breakdown[ $key ] ) && is_numeric( $breakdown[ $key ] ) ) {
            $breakdown[ $key ] = round( (float) $breakdown[ $key ], 2 );
        }
    }

    return $breakdown;
}

/**
 * Calculate one-way trip fare
 * Formula: distance × per_km_rate + toll + parking
 */
function ridego_calculate_oneway_fare($vehicle, $distance_km, $pickup_city, $drop_city, $breakdown) {
    
    // Check for fixed route pricing first
    $route_price = ridego_get_route_fixed_price($pickup_city, $drop_city, $vehicle->id);
    
    if ($route_price !== false) {
        // Use fixed route pricing
        $breakdown['base_fare'] = $route_price;
        $breakdown['per_km_rate'] = 0; // Fixed pricing
        $breakdown['pricing_type'] = 'fixed';
    } else {
        // Calculate per-km pricing
        $billable_km = max($distance_km, $vehicle->minimum_km);
        $breakdown['distance_km'] = $distance_km;
        $breakdown['billable_km'] = $billable_km;
        $breakdown['per_km_rate'] = $vehicle->base_price_per_km;
        $breakdown['base_fare'] = $billable_km * $vehicle->base_price_per_km;
        $breakdown['pricing_type'] = 'per_km';
    }
    
    // Add estimated toll charges
    $breakdown['toll_charges'] = ridego_estimate_toll_charges($pickup_city, $drop_city);
    
    // Add parking charges if applicable
    $breakdown['parking_charges'] = ridego_estimate_parking_charges($pickup_city, $drop_city);
    
    return $breakdown;
}

/**
 * Calculate round-trip fare
 * Formula: (distance × 2) × per_km_rate - 10% discount
 */
function ridego_calculate_roundtrip_fare($vehicle, $distance_km, $pickup_city, $drop_city, $breakdown) {
    
    // Calculate as two one-way trips
    $one_way_distance = $distance_km;
    $total_distance = $one_way_distance * 2;
    
    $billable_km = max($total_distance, $vehicle->minimum_km);
    $breakdown['distance_km'] = $total_distance;
    $breakdown['billable_km'] = $billable_km;
    $breakdown['per_km_rate'] = $vehicle->base_price_per_km;
    
    // Base fare
    $base = $billable_km * $vehicle->base_price_per_km;
    
    // Apply 10% round-trip discount
    $discount_percent = get_option('ridego_roundtrip_discount', 10);
    $discount = $base * ($discount_percent / 100);
    
    $breakdown['base_fare'] = $base - $discount;
    $breakdown['roundtrip_discount'] = $discount;
    
    // Toll charges (both ways)
    $breakdown['toll_charges'] = ridego_estimate_toll_charges($pickup_city, $drop_city) * 2;
    
    // Parking
    $breakdown['parking_charges'] = ridego_estimate_parking_charges($pickup_city, $drop_city);
    
    return $breakdown;
}

/**
 * Calculate local package fare
 * Fixed package pricing: 4hr/40km, 8hr/80km, 12hr/120km
 */
function ridego_calculate_local_fare($vehicle, $hours_required, $distance_km, $breakdown) {
    
    // Get package pricing
    $packages = ridego_get_local_packages($vehicle->id);
    
    // Find matching package
    $package = null;
    foreach ($packages as $pkg) {
        if ($pkg['hours'] == $hours_required) {
            $package = $pkg;
            break;
        }
    }
    
    if (!$package) {
        // Root-cause fix: hours_required is a free numeric input on the
        // frontend (not limited to 4/8), so any value that doesn't exactly
        // match a package (5, 6, 10, 12...) used to fall through to
        // $vehicle->extra_hour_charge (the OUTSTATION extra-hour rate) and
        // base_price_per_km (the OUTSTATION per-km rate) — the wrong rates
        // for a local rental, which has its own dedicated local_extra_hr /
        // local_extra_km columns. Price it as the largest package the
        // requested hours cover, plus the extra hours/km beyond it at the
        // real local rates; only fall back to a bare hourly rate if the
        // requested hours are below even the smallest package.
        $packages_desc = $packages;
        usort( $packages_desc, function( $a, $b ) { return $b['hours'] <=> $a['hours']; } );
        $base_package = null;
        foreach ( $packages_desc as $pkg ) {
            if ( $hours_required >= $pkg['hours'] ) {
                $base_package = $pkg;
                break;
            }
        }
        if ( $base_package ) {
            $extra_hours = $hours_required - $base_package['hours'];
            $breakdown['base_fare'] = $base_package['price'] + ( $extra_hours * $vehicle->local_extra_hr );
            $breakdown['package_hours'] = $base_package['hours'];
            $breakdown['package_km'] = $base_package['km'];
            $breakdown['extra_hour_charge'] = $extra_hours * $vehicle->local_extra_hr;
            if ( $distance_km > $base_package['km'] ) {
                $extra_km = $distance_km - $base_package['km'];
                $breakdown['extra_km_charges'] = $extra_km * $vehicle->local_extra_km;
            }
        } else {
            $breakdown['base_fare'] = $hours_required * $vehicle->local_extra_hr;
            $breakdown['extra_km_charges'] = max(0, $distance_km - 40) * $vehicle->local_extra_km;
        }
    } else {
        // Package pricing
        $breakdown['base_fare'] = $package['price'];
        $breakdown['package_hours'] = $package['hours'];
        $breakdown['package_km'] = $package['km'];

        // Extra charges beyond package
        if ($distance_km > $package['km']) {
            $extra_km = $distance_km - $package['km'];
            $breakdown['extra_km_charges'] = $extra_km * $vehicle->local_extra_km;
        }
    }
    
    // No toll/parking for local
    $breakdown['toll_charges'] = 0;
    $breakdown['parking_charges'] = 0;
    
    return $breakdown;
}

/**
 * Calculate airport transfer fare
 * Base charge + distance-based pricing
 */
function ridego_calculate_airport_fare($vehicle, $distance_km, $trip_type, $pickup_city, $drop_city, $breakdown) {
    
    // Airport base charge
    $breakdown['base_fare'] = $vehicle->airport_base_charge;
    
    // Add per-km charges if distance exceeds threshold
    $free_km = get_option('ridego_airport_free_km', 5); // First 5km free
    
    if ($distance_km > $free_km) {
        $extra_km = $distance_km - $free_km;
        $breakdown['base_fare'] += $extra_km * $vehicle->base_price_per_km;
    }
    
    // Airport parking
    $breakdown['parking_charges'] = ridego_get_airport_parking_charge($pickup_city, $drop_city);
    
    // No toll estimate for airport (included in base)
    $breakdown['toll_charges'] = 0;
    
    // Free 1-hour wait for airport pickup
    if ($trip_type === 'airport_pickup') {
        $breakdown['inclusions'][] = 'Free 1-hour wait for flight delays';
    }
    
    return $breakdown;
}

/**
 * Calculate outstation fare
 * Multi-day trips with driver allowance
 */
function ridego_calculate_outstation_fare($vehicle, $distance_km, $params, $breakdown) {
    
    // Use outstation per-km rate (usually higher)
    $per_km = $vehicle->base_price_outstation ?? $vehicle->base_price_per_km;
    
    $billable_km = max($distance_km, $vehicle->minimum_km);
    $breakdown['distance_km'] = $distance_km;
    $breakdown['billable_km'] = $billable_km;
    $breakdown['per_km_rate'] = $per_km;
    $breakdown['base_fare'] = $billable_km * $per_km;
    
    // Calculate number of days
    $journey_date = $params['journey_date'] ?? date('Y-m-d');
    $return_date = $params['return_date'] ?? $journey_date;
    
    $days = max(1, ridego_calculate_trip_days($journey_date, $return_date));
    
    // Driver allowance per day
    if ($days > 0) {
        $allowance_per_day = $vehicle->driver_allowance_day ?? 250;
        $breakdown['driver_allowance'] = $days * $allowance_per_day;
        $breakdown['trip_days'] = $days;
    }
    
    // Toll charges
    $breakdown['toll_charges'] = ridego_estimate_toll_charges($params['pickup_city'], $params['drop_city']);
    
    // Parking
    $breakdown['parking_charges'] = ridego_estimate_parking_charges($params['pickup_city'], $params['drop_city']);
    
    return $breakdown;
}

/**
 * Apply time-based surcharges
 * Night charge: 11 PM - 6 AM
 */
function ridego_apply_time_surcharges($breakdown, $journey_date, $journey_time) {
    
    $hour = (int) date('H', strtotime($journey_time));
    
    // Night charge (11 PM - 6 AM)
    if ($hour >= 23 || $hour < 6) {
        $night_percent = get_option('ridego_night_charge_percent', 15);
        $breakdown['night_charge'] = round($breakdown['base_fare'] * ($night_percent / 100), 2);
        $breakdown['night_charge_applied'] = true;
    }
    
    return $breakdown;
}

/**
 * Apply demand-based surge pricing
 * Multiplier: 1.0x to 2.5x
 */
function ridego_apply_surge_pricing($breakdown, $vehicle_id, $pickup_city, $drop_city, $journey_date, $journey_time, $pickup_lat = null, $pickup_lng = null) {

    // Get surge multiplier for this time/route
    // Contract: ridego_get_surge_multiplier() ALWAYS returns array('multiplier'=>float,'reason'=>string|null)
    $surge = ridego_get_surge_multiplier($vehicle_id, $pickup_city, $drop_city, $journey_date, $journey_time, $pickup_lat, $pickup_lng);
    $surge_multiplier = isset($surge['multiplier']) ? (float) $surge['multiplier'] : 1.0;

    if ($surge_multiplier > 1.0) {
        $breakdown['surge_multiplier'] = $surge_multiplier;

        // Apply surge to base fare only (not toll/parking)
        $surgeable_amount = $breakdown['base_fare'] + $breakdown['night_charge'];
        $breakdown['surge_amount'] = round($surgeable_amount * ($surge_multiplier - 1), 2);
        $breakdown['surge_reason'] = !empty($surge['reason']) ? $surge['reason'] : 'High demand';
    }

    return $breakdown;
}

/**
 * Get surge pricing multiplier
 * Based on: demand, time, date, events, weather, city/zone
 *
 * Return contract (ALWAYS): array('multiplier' => float, 'reason' => string|null)
 * Never a bare float — callers must destructure via $result['multiplier'].
 */
function ridego_get_surge_multiplier($vehicle_id, $pickup_city, $drop_city, $journey_date, $journey_time, $pickup_lat = null, $pickup_lng = null) {
    global $wpdb;

    $table = $wpdb->prefix . 'ridego_surge_pricing';

    // Zone-aware matching (Wave 3): when a pickup lat/lng is available,
    // resolve which zone (if any) the point falls inside via
    // ridego_get_zone_for_point() (includes/helpers.php), and prefer a
    // surge rule pinned to that specific zone_id over a city-wide rule —
    // a zone rule is strictly more specific than a plain city match.
    $zone_id = null;
    if ( $pickup_lat !== null && $pickup_lng !== null && function_exists( 'ridego_get_zone_for_point' ) ) {
        $zone = ridego_get_zone_for_point( $pickup_lat, $pickup_lng );
        if ( $zone ) { $zone_id = (int) $zone->id; }
    }

    if ( $zone_id ) {
        $zone_surge = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table}
             WHERE is_active = 1
             AND zone_id = %d
             AND (vehicle_id = %d OR vehicle_id IS NULL)
             AND (from_date IS NULL OR from_date <= %s)
             AND (to_date IS NULL OR to_date >= %s)
             AND (time_from IS NULL OR time_from <= %s)
             AND (time_to IS NULL OR time_to >= %s)
             ORDER BY multiplier DESC
             LIMIT 1",
            $zone_id, $vehicle_id, $journey_date, $journey_date, $journey_time, $journey_time
        ));
        if ( $zone_surge ) {
            return array( 'multiplier' => (float) $zone_surge->multiplier, 'reason' => $zone_surge->reason );
        }
    }

    // Check for active surge rules against the real schema columns:
    // from_date/to_date (date range), time_from/time_to (time-of-day window),
    // city (nullable = applies to all cities), vehicle_id (nullable = applies to all vehicles).
    // Restricted to rules with no zone_id so a zone-specific rule (handled
    // above) never gets matched twice as a "city-wide" rule too.
    $surge = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table}
         WHERE is_active = 1
         AND zone_id IS NULL
         AND (vehicle_id = %d OR vehicle_id IS NULL)
         AND (city = %s OR city IS NULL OR city = '')
         AND (from_date IS NULL OR from_date <= %s)
         AND (to_date IS NULL OR to_date >= %s)
         AND (time_from IS NULL OR time_from <= %s)
         AND (time_to IS NULL OR time_to >= %s)
         ORDER BY multiplier DESC
         LIMIT 1",
        $vehicle_id,
        $pickup_city,
        $journey_date,
        $journey_date,
        $journey_time,
        $journey_time
    ));

    if ($surge) {
        return array(
            'multiplier' => (float) $surge->multiplier,
            'reason'     => $surge->reason
        );
    }

    // Default: no surge
    return array(
        'multiplier' => 1.0,
        'reason'     => null,
    );
}

/**
 * Resolve a real one-way road distance (and duration) between two
 * cities, for fare calculation when the caller didn't supply one.
 *
 * Two-tier resolution, in order of trust:
 *  1. wp_ridego_routes — the admin-curated distance_km/duration_mins
 *     for this exact city pair (Cities & Routes management already
 *     collects this per route, either direction), if an active route
 *     row exists.
 *  2. A geographic estimate from the two cities' stored lat/lng
 *     (wp_ridego_cities), using ridego_haversine_km() — the same
 *     great-circle helper already used for surge-zone matching — times
 *     a fixed road-distance correction factor (great-circle distance
 *     under-counts real road distance; 1.35x is a standard rule-of-
 *     thumb approximation for indirect road routing), at an assumed
 *     45 km/h average for the duration estimate.
 *
 * Returns null if neither source has usable data (e.g. a city missing
 * lat/lng and no route row) — callers should treat that as "unknown"
 * rather than silently falling back to 0.
 */
function ridego_resolve_route_distance( $from_city, $to_city ) {
    global $wpdb;

    $rtbl = $wpdb->prefix . 'ridego_routes';
    $row = $wpdb->get_row( $wpdb->prepare(
        "SELECT distance_km, duration_mins FROM {$rtbl}
         WHERE ( ( from_city = %s AND to_city = %s ) OR ( from_city = %s AND to_city = %s ) )
         AND is_active = 1 AND distance_km > 0
         LIMIT 1",
        $from_city, $to_city, $to_city, $from_city
    ) );
    if ( $row ) {
        return array(
            'distance_km'      => (float) $row->distance_km,
            'duration_minutes' => (int) $row->duration_mins,
            'source'           => 'route',
        );
    }

    $ctbl = $wpdb->prefix . 'ridego_cities';
    $from = $wpdb->get_row( $wpdb->prepare( "SELECT lat, lng FROM {$ctbl} WHERE name = %s LIMIT 1", $from_city ) );
    $to   = $wpdb->get_row( $wpdb->prepare( "SELECT lat, lng FROM {$ctbl} WHERE name = %s LIMIT 1", $to_city ) );
    if ( $from && $to && $from->lat !== null && $from->lng !== null && $to->lat !== null && $to->lng !== null ) {
        $straight_line = ridego_haversine_km( $from->lat, $from->lng, $to->lat, $to->lng );
        $road_factor    = 1.35;
        $distance_km    = round( $straight_line * $road_factor, 1 );
        $avg_speed_kmph = 45;
        return array(
            'distance_km'      => $distance_km,
            'duration_minutes' => (int) round( ( $distance_km / $avg_speed_kmph ) * 60 ),
            'source'           => 'estimated',
        );
    }

    return null;
}

/**
 * Get fixed pricing for popular routes
 * Returns false if no fixed pricing exists
 */
function ridego_get_route_fixed_price($from_city, $to_city, $vehicle_id) {
    global $wpdb;

    $routes_table  = $wpdb->prefix . 'ridego_routes';
    $pricing_table = $wpdb->prefix . 'ridego_route_vehicle_pricing';

    // Per-vehicle override takes precedence over the route's default fixed price.
    $price = $wpdb->get_var($wpdb->prepare(
        "SELECT rvp.fixed_price
         FROM {$pricing_table} rvp
         INNER JOIN {$routes_table} r ON r.id = rvp.route_id
         WHERE r.from_city = %s
         AND r.to_city = %s
         AND rvp.vehicle_id = %d
         AND rvp.fixed_price IS NOT NULL
         AND r.is_active = 1
         LIMIT 1",
        $from_city,
        $to_city,
        $vehicle_id
    ));

    if ($price !== null) {
        return (float) $price;
    }

    // Fall back to the route's default fixed price (applies to all vehicle types).
    $price = $wpdb->get_var($wpdb->prepare(
        "SELECT default_fixed_price FROM {$routes_table}
         WHERE from_city = %s
         AND to_city = %s
         AND default_fixed_price IS NOT NULL
         AND is_active = 1
         LIMIT 1",
        $from_city,
        $to_city
    ));

    return $price !== null ? (float) $price : false;
}

/**
 * Estimate toll charges for route
 */
function ridego_estimate_toll_charges($from_city, $to_city, $vehicle_id = null) {
    global $wpdb;

    $routes_table  = $wpdb->prefix . 'ridego_routes';
    $pricing_table = $wpdb->prefix . 'ridego_route_vehicle_pricing';

    // Per-vehicle toll override, if one exists.
    if ($vehicle_id) {
        $toll = $wpdb->get_var($wpdb->prepare(
            "SELECT rvp.toll_estimate
             FROM {$pricing_table} rvp
             INNER JOIN {$routes_table} r ON r.id = rvp.route_id
             WHERE r.from_city = %s AND r.to_city = %s
             AND rvp.vehicle_id = %d
             AND rvp.toll_estimate IS NOT NULL
             LIMIT 1",
            $from_city,
            $to_city,
            $vehicle_id
        ));
        if ($toll !== null) {
            return (float) $toll;
        }
    }

    // Get toll estimate from routes table
    $toll = $wpdb->get_var($wpdb->prepare(
        "SELECT toll_estimate FROM {$routes_table}
         WHERE from_city = %s
         AND to_city = %s
         AND toll_estimate IS NOT NULL
         LIMIT 1",
        $from_city,
        $to_city
    ));

    if ($toll !== null) {
        return (float) $toll;
    }
    
    // Default toll estimate based on city type
    $metro_cities = array('Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Hyderabad', 'Pune', 'Kolkata');
    
    if (in_array($from_city, $metro_cities) || in_array($to_city, $metro_cities)) {
        return 200; // Default metro toll
    }
    
    return 100; // Default non-metro toll
}

/**
 * Estimate parking charges
 */
function ridego_estimate_parking_charges($from_city, $to_city) {
    
    // Check if either location is an airport
    if (ridego_is_airport_location($from_city) || ridego_is_airport_location($to_city)) {
        return get_option('ridego_airport_parking_charge', 100);
    }
    
    // Check if mall/hotel (would need more context)
    return 0;
}

/**
 * Get airport parking charge for city
 */
function ridego_get_airport_parking_charge($pickup_city, $drop_city) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_cities';
    
    // Check if pickup or drop is airport
    $city = ridego_is_airport_location($pickup_city) ? $pickup_city : $drop_city;
    
    $charge = $wpdb->get_var($wpdb->prepare(
        "SELECT airport_parking_charge FROM {$table}
         WHERE name = %s
         LIMIT 1",
        $city
    ));
    
    return $charge ? (float) $charge : 100;
}

/**
 * Check if location is airport
 */
function ridego_is_airport_location($location) {
    
    $airport_keywords = array('airport', 'international', 'domestic', 'terminal');
    
    $location_lower = strtolower($location);
    
    foreach ($airport_keywords as $keyword) {
        if (strpos($location_lower, $keyword) !== false) {
            return true;
        }
    }
    
    return false;
}

/**
 * Get local package pricing
 */
function ridego_get_local_packages($vehicle_id) {

    $vehicle = ridego_get_vehicle_type($vehicle_id);
    if (!$vehicle) {
        return array();
    }

    // Root-cause fix: this used to read get_option("ridego_local_4hr_{id}", 800)
    // and similar keys that nothing in the codebase (admin UI, REST API,
    // install.php) ever writes to — every vehicle silently fell back to the
    // same hardcoded 800/1400/2000 defaults regardless of its actual class,
    // so admin-configured local pricing (wp_ridego_vehicles.local_4hr_40km /
    // local_8hr_80km, editable from both the old wp-admin Pricing page and
    // the new AdminPricingPage.tsx, and returned by app-admin-pricing-api.php)
    // never reached the customer-facing fare at all. Use the real per-vehicle
    // columns instead. There is no dedicated 12-hour package column in the
    // schema (install.php only defines 4hr/8hr packages), so a 12-hour local
    // rental is priced as the 8-hour package plus 4 extra hours at the
    // vehicle's real local_extra_hr rate, via the "no exact match" fallback
    // in ridego_calculate_local_fare() below, rather than inventing a value.
    return array(
        array(
            'hours' => 4,
            'km'    => 40,
            'price' => (float) $vehicle->local_4hr_40km,
        ),
        array(
            'hours' => 8,
            'km'    => 80,
            'price' => (float) $vehicle->local_8hr_80km,
        ),
    );
}

/**
 * Calculate trip days
 */
function ridego_calculate_trip_days($start_date, $end_date) {
    
    $start = strtotime($start_date);
    $end = strtotime($end_date);
    
    $diff_seconds = $end - $start;
    $days = ceil($diff_seconds / (60 * 60 * 24));
    
    return max(1, $days);
}

/**
 * Get fare inclusions based on trip type
 */
function ridego_get_fare_inclusions($trip_type, $vehicle) {
    
    $inclusions = array(
        'Driver allowance',
        'AC (if available)',
        'GST included',
    );
    
    switch ($trip_type) {
        case 'one_way':
        case 'round_trip':
            $inclusions[] = 'Toll charges (estimated)';
            $inclusions[] = 'Parking charges (estimated)';
            break;
            
        case 'airport_pickup':
            $inclusions[] = 'Free 1-hour wait for flight delays';
            $inclusions[] = 'Airport parking';
            break;
            
        case 'local':
            $inclusions[] = $vehicle->minimum_km . ' km included';
            $inclusions[] = 'Extra km: ₹' . $vehicle->base_price_per_km . '/km';
            break;
            
        case 'outstation':
            $inclusions[] = 'Driver night allowance';
            $inclusions[] = 'Toll charges';
            break;
    }
    
    return $inclusions;
}

/**
 * Get fare exclusions
 */
function ridego_get_fare_exclusions($trip_type) {
    
    $exclusions = array(
        'State border tax',
        'Entry/exit charges (if applicable)',
    );
    
    if ($trip_type !== 'local') {
        $exclusions[] = 'Additional stops beyond included';
    }
    
    return $exclusions;
}

/**
 * Get vehicle type data
 */
function ridego_get_vehicle_type($vehicle_id) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_vehicles';
    
    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE id = %d AND is_active = 1",
        $vehicle_id
    ));
}

/**
 * Convenience wrapper: every real call site only has a $booking_id in
 * scope (not the vehicle/trip_type/fare/city args individually), so this
 * loads the booking record and forwards its fields to the real 5-arg
 * ridego_calculate_lead_fee(). Root-cause fix for the arity mismatch
 * where ridego_calculate_lead_fee($booking_id) was being called directly
 * against a function that requires 5 params (Wave 2B Task 3).
 *
 * @param int $booking_id
 * @return float Lead fee amount (0 if the booking cannot be found).
 */
function ridego_calculate_lead_fee_for_booking($booking_id, $vendor_id = null) {
    $booking = ridego_get_booking($booking_id);
    if (!$booking) {
        return 0;
    }
    // Facilitator model: the vendor lead fee is calculated by the central engine (includes/lead-fee.php) and billed through the ledger after the trip, never taken from the wallet at accept time, so the old wallet fee is 0.
    if ( ! empty( $booking->platform_model ) ) {
        return 0;
    }
    return ridego_calculate_lead_fee(
        $booking->vehicle_type_id,
        $booking->trip_type,
        $booking->total_fare,
        $booking->pickup_city,
        $booking->drop_city,
        $vendor_id
    );
}

/**
 * Calculate lead fee for vendor
 * Based on: fixed, percentage, or dynamic mode.
 *
 * @param int|null $vendor_id Optional — when given, and the vendor has a
 *                             genuinely active, unexpired subscription plan
 *                             (subscription_status='active' AND
 *                             subscription_expires >= NOW(); a stale/expired
 *                             plan_id is never trusted), the plan's
 *                             lead_discount percentage is applied to the
 *                             fee AFTER the min/max caps, so a discounted
 *                             fee can legitimately fall below the platform
 *                             minimum (that's the point of the perk).
 */
function ridego_calculate_lead_fee($vehicle_id, $trip_type, $total_fare, $pickup_city, $drop_city, $vendor_id = null) {

    $vehicle = ridego_get_vehicle_type($vehicle_id);
    if (!$vehicle) {
        return 0;
    }

    $lead_fee = 0;

    switch ($vehicle->lead_fee_mode) {

        case 'fixed':
            // Use fixed fee from vehicle table
            $lead_fee = (float) $vehicle->lead_fee_fixed;
            break;

        case 'percentage':
            // Percentage of total fare
            $percent = (float) $vehicle->lead_fee_pct;
            $lead_fee = round($total_fare * ($percent / 100), 2);
            break;

        case 'dynamic':
            // Dynamic based on demand/route/time
            $base_fee = (float) $vehicle->lead_fee_fixed;
            $surge = ridego_get_lead_fee_surge($pickup_city, $drop_city, $trip_type);
            $lead_fee = round($base_fee * $surge, 2);
            break;

        default:
            $lead_fee = (float) $vehicle->lead_fee_fixed;
    }

    // Apply minimum and maximum caps
    $min_fee = get_option('ridego_lead_fee_minimum', 30);
    $max_fee = get_option('ridego_lead_fee_maximum', 500);

    $lead_fee = max($min_fee, min($max_fee, $lead_fee));

    // Apply the vendor's active subscription plan's lead_discount, if any.
    if ( $vendor_id && function_exists( 'ridego_get_vendor' ) ) {
        $vendor = ridego_get_vendor( $vendor_id );
        if ( $vendor && ! empty( $vendor->subscription_plan_id )
             && $vendor->subscription_status === 'active'
             && ! empty( $vendor->subscription_expires )
             && strtotime( $vendor->subscription_expires ) >= time() ) {
            $plan = function_exists( 'ridego_get_subscription_plan' ) ? ridego_get_subscription_plan( $vendor->subscription_plan_id ) : null;
            if ( $plan && (float) $plan->lead_discount > 0 ) {
                $discount_pct = min( 100, (float) $plan->lead_discount );
                $lead_fee = round( $lead_fee * ( 1 - ( $discount_pct / 100 ) ), 2 );
            }
        }
    }

    return $lead_fee;
}

/**
 * Get lead fee surge multiplier
 * Higher demand routes = higher lead fees
 */
function ridego_get_lead_fee_surge($pickup_city, $drop_city, $trip_type) {
    global $wpdb;
    
    // Count pending bookings for this route
    $bookings_table = $wpdb->prefix . 'ridego_bookings';
    
    $pending_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$bookings_table}
         WHERE pickup_city = %s
         AND drop_city = %s
         AND status IN ('pending', 'confirmed')
         AND journey_date = CURDATE()",
        $pickup_city,
        $drop_city
    ));
    
    // Calculate surge based on demand
    if ($pending_count >= 10) {
        return 2.0; // 2x surge for high demand
    } elseif ($pending_count >= 5) {
        return 1.5; // 1.5x surge for medium demand
    } elseif ($pending_count >= 3) {
        return 1.2; // 1.2x surge for low demand
    }
    
    return 1.0; // No surge
}

/**
 * Apply promo code discount.
 *
 * Thin wrapper around the canonical includes/promo.php implementation
 * (ridego_validate_promo_code() + ridego_calculate_promo_discount()).
 * This used to be a second, divergent implementation with its own copy
 * of the discount-calculation logic and a narrower set of validation
 * rules (no per-user limit, no first-booking-only, no trip-type/day-of-
 * week/user-type checks) — consolidated per Wave 2B Task 4 so there is
 * exactly one promo validation/discount code path.
 */
function ridego_apply_promo_code($code, $subtotal, $booking_params) {
    $user_id = is_user_logged_in() ? get_current_user_id() : 0;
    $result  = ridego_validate_promo_code($code, $subtotal, $booking_params, $user_id);

    if (empty($result['valid'])) {
        return array(
            'valid' => false,
            'error' => isset($result['error']) ? $result['error'] : 'Invalid or expired promo code',
        );
    }

    return array(
        'valid'           => true,
        'discount_amount' => $result['discount_amount'],
        'promo_id'        => $result['promo_id'],
        'discount_type'   => $result['discount_type'],
        'discount_value'  => $result['discount_value'],
    );
}

/**
 * Cache fare calculation result
 * Caches for 1 hour to reduce DB load
 */
function ridego_cache_fare($cache_key, $breakdown) {
    set_transient('ridego_fare_' . md5($cache_key), $breakdown, HOUR_IN_SECONDS);
}

/**
 * Get cached fare calculation
 */
function ridego_get_cached_fare($cache_key) {
    return get_transient('ridego_fare_' . md5($cache_key));
}

/**
 * AJAX: Calculate fare (real-time)
 * Endpoint: wp-ajax-ridego_calculate_fare
 */
function ridego_ajax_calculate_fare() {
    
    // Verify nonce
    check_ajax_referer('ridego_booking_nonce', 'nonce');
    
    // Build parameters from POST data
    $params = array(
        'trip_type'        => isset($_POST['trip_type']) ? sanitize_text_field($_POST['trip_type']) : 'one_way',
        'vehicle_type_id'  => isset($_POST['vehicle_type_id']) ? absint($_POST['vehicle_type_id']) : 0,
        'distance_km'      => isset($_POST['distance_km']) ? floatval($_POST['distance_km']) : 0,
        'pickup_city'      => isset($_POST['pickup_city']) ? sanitize_text_field($_POST['pickup_city']) : '',
        'drop_city'        => isset($_POST['drop_city']) ? sanitize_text_field($_POST['drop_city']) : '',
        'journey_date'     => isset($_POST['journey_date']) ? sanitize_text_field($_POST['journey_date']) : date('Y-m-d'),
        'journey_time'     => isset($_POST['journey_time']) ? sanitize_text_field($_POST['journey_time']) : date('H:i:s'),
        'hours_required'   => isset($_POST['hours_required']) ? absint($_POST['hours_required']) : 0,
        'promo_code'       => isset($_POST['promo_code']) ? sanitize_text_field($_POST['promo_code']) : '',
        'return_date'      => isset($_POST['return_date']) ? sanitize_text_field($_POST['return_date']) : '',
    );
    
    // Validate required fields
    if ($params['vehicle_type_id'] === 0) {
        wp_send_json_error(array('message' => 'Vehicle type is required'));
    }
    
    // Check cache first
    $cache_key = wp_json_encode($params);
    $cached = ridego_get_cached_fare($cache_key);
    
    if ($cached !== false) {
        wp_send_json_success(array(
            'breakdown' => $cached,
            'cached'    => true
        ));
    }
    
    // Calculate fare
    $breakdown = ridego_calculate_fare($params);
    
    if (isset($breakdown['error'])) {
        wp_send_json_error(array('message' => $breakdown['error']));
    }
    
    // Cache result
    ridego_cache_fare($cache_key, $breakdown);
    
    wp_send_json_success(array(
        'breakdown' => $breakdown,
        'cached'    => false
    ));
}
add_action('wp_ajax_ridego_calculate_fare', 'ridego_ajax_calculate_fare');
add_action('wp_ajax_nopriv_ridego_calculate_fare', 'ridego_ajax_calculate_fare');

/**
 * AJAX: Validate promo code
 * Endpoint: wp-ajax-ridego_validate_promo
 */
function ridego_ajax_validate_promo() {

    check_ajax_referer('ridego_booking_nonce', 'nonce');

    // Guest-accessible (nopriv) endpoint — rate limit by IP to stop promo
    // code brute-forcing (Wave 2B Task 4). 20 attempts / 10 minutes.
    $rl = ridego_check_rate_limit('validate_promo', ridego_get_client_ip(), 20, 600);
    if (empty($rl['allowed'])) {
        wp_send_json_error(array('message' => $rl['error']));
    }

    $code = isset($_POST['promo_code']) ? sanitize_text_field($_POST['promo_code']) : '';
    $subtotal = isset($_POST['subtotal']) ? floatval($_POST['subtotal']) : 0;
    
    $params = array(
        'vehicle_type_id' => isset($_POST['vehicle_type_id']) ? absint($_POST['vehicle_type_id']) : 0,
        'pickup_city'     => isset($_POST['pickup_city']) ? sanitize_text_field($_POST['pickup_city']) : '',
        'drop_city'       => isset($_POST['drop_city']) ? sanitize_text_field($_POST['drop_city']) : '',
    );
    
    $result = ridego_apply_promo_code($code, $subtotal, $params);
    
    if ($result['valid']) {
        wp_send_json_success($result);
    } else {
        wp_send_json_error($result);
    }
}
add_action('wp_ajax_ridego_validate_promo', 'ridego_ajax_validate_promo');
add_action('wp_ajax_nopriv_ridego_validate_promo', 'ridego_ajax_validate_promo');
