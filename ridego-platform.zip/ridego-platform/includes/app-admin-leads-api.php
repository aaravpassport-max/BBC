<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Phase B, wave 28: lead monitor
   ------------------------------------------------------------
   Covers admin/pages/leads.php in full: the filtered (status,
   free-text search), paginated lead list, the 5 KPI tiles, and the
   status pill row. Read-only — the legacy page has no write actions
   at all (leads are created/accepted/rejected elsewhere in
   includes/lead.php, not from this admin page).

   Every query and every KPI is copied verbatim from
   admin/pages/leads.php, INCLUDING an already-fixed root-cause bug
   the legacy page itself documents in its own comments: the
   "Assigned"/"Fees Collected" KPIs filter on status='accepted', not
   the never-actually-used status='assigned' value — every write site
   in includes/lead.php (accept-lead, admin-assign-vendor) writes
   'accepted'. This wave's PHP preserves that already-correct filter
   rather than reintroducing the bug.

   No canonical "list leads" helper exists — the legacy page queries
   inline, so this REST layer does the same rather than inventing a
   shared function this wave didn't ask for.

   Every route requires is_user_logged_in() AND
   ridego_can('ridego_manage_bookings') — the exact capability
   admin/pages/leads.php already requires (the Lead Monitor page is
   gated on the bookings capability in the legacy admin menu, not a
   separate leads capability — confirmed by reading the page's own
   permission check before wiring this).
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_leads_api_routes' );
function ridego_register_app_admin_leads_api_routes() {
    register_rest_route( 'ridego/v1', '/app/admin/leads', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_leads_list',
        'permission_callback' => 'ridego_app_admin_api_leads_permission',
    ) );
}

function ridego_app_admin_api_leads_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_bookings' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to view leads.', array( 'status' => 403 ) );
    }
    return true;
}

/** Copied verbatim from admin/pages/leads.php:10-31 (filters, search, pagination, KPIs). */
function ridego_app_admin_api_leads_list( WP_REST_Request $req ) {
    global $wpdb;
    $ltbl = $wpdb->prefix . 'ridego_leads';
    $btbl = $wpdb->prefix . 'ridego_bookings';
    $vtbl = $wpdb->prefix . 'ridego_vendors';

    $sf = sanitize_key( (string) $req->get_param( 'status' ) );
    $sr = sanitize_text_field( (string) $req->get_param( 's' ) );
    $page = max( 1, (int) $req->get_param( 'page' ) );
    $per  = 30;
    $off  = ( $page - 1 ) * $per;

    $w = 'WHERE 1=1';
    $v = array();
    if ( $sf ) { $w .= ' AND l.status=%s'; $v[] = $sf; }
    if ( $sr ) {
        $lk = '%' . $wpdb->esc_like( $sr ) . '%';
        $w .= ' AND (b.booking_number LIKE %s OR b.client_name LIKE %s OR v.business_name LIKE %s)';
        $v[] = $lk; $v[] = $lk; $v[] = $lk;
    }

    $joins = "LEFT JOIN $btbl b ON b.id=l.booking_id LEFT JOIN $vtbl v ON v.id=l.vendor_id";
    $total = $v
        ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $ltbl l $joins $w", $v ) )
        : (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ltbl l $joins $w" );

    $sql = "SELECT l.*,b.booking_number,b.pickup_city,b.drop_city,b.journey_date,b.trip_type,b.total_fare,b.client_name,v.business_name,v.phone as vphone FROM $ltbl l $joins $w ORDER BY l.sent_at DESC LIMIT %d OFFSET %d";
    $leads = $v
        ? $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $v, array( $per, $off ) ) ) )
        : $wpdb->get_results( $wpdb->prepare( $sql, $per, $off ) );

    $total_leads    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ltbl" );
    $sent_count     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ltbl WHERE status='sent'" );
    // Same root-cause fix the legacy page's own comments document:
    // status='accepted' (never 'assigned') is the value every write
    // site in includes/lead.php actually uses.
    $accepted_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ltbl WHERE status='accepted'" );
    $rejected_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ltbl WHERE status='rejected'" );
    $fees_collected = (float) $wpdb->get_var( "SELECT COALESCE(SUM(COALESCE(lf_amount,fee_amount)),0) FROM $ltbl WHERE status='accepted'" );

    return rest_ensure_response( array(
        'rows' => array_map( function ( $l ) {
            $expires_seconds_left = null;
            if ( $l->expires_at ) {
                $diff = strtotime( $l->expires_at ) - time();
                if ( $diff > 0 ) { $expires_seconds_left = $diff; }
            }
            return array(
                'id'              => (int) $l->id,
                'booking_id'      => $l->booking_id,
                'booking_number'  => $l->booking_number,
                'pickup_city'     => $l->pickup_city,
                'drop_city'       => $l->drop_city,
                'journey_date'    => $l->journey_date,
                'trip_type'       => $l->trip_type,
                'client_name'     => $l->client_name,
                'business_name'   => $l->business_name,
                'vendor_phone'    => $l->vphone,
                'fee_amount'      => (float) ridego_lead_fee_lead_view( $l )['amount'],
                'lead_fee'        => ridego_lead_fee_lead_view( $l ),
                'status'          => $l->status,
                'sent_at'         => $l->sent_at,
                'expires_at'      => $l->expires_at,
                'expires_seconds_left' => $expires_seconds_left,
            );
        }, $leads ),
        'total'    => $total,
        'page'     => $page,
        'per_page' => $per,
        'kpis'     => array(
            'total_leads'     => $total_leads,
            'pending'         => $sent_count,
            'accepted'        => $accepted_count,
            'rejected'        => $rejected_count,
            'fees_collected'  => $fees_collected,
        ),
    ) );
}
