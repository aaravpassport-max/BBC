<?php
/**
 * RideGo Marketplace — booking ledger, settlement and closure (Phase 4).
 * One row per money movement; UNIQUE dedupe_key makes every write idempotent.
 * Entry types: lead_fee_retained (facilitator model: the customer advance set off against the vendor lead fee, already settled), lead_fee (the balance the vendor still owes), commission (debit, vendor owes platform), advance_held (credit, platform owes vendor
 * the advance it collected), commission_reversal (credit), cancellation_fee (credit to platform, info).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: any ledger writer → inserts one row guarded by a unique dedupe_key → returns
//        'inserted' | 'duplicate' | 'error'. Preconditions: booking_id>0, amount>=0, direction in
//        credit|debit. Postconditions: at most one row per dedupe_key exists. Edge cases: duplicate key
//        (returns 'duplicate', no second row), DB error (returns 'error', logged), invalid args ('error').
function ridego_ledger_add( $booking_id, $vendor_id, $entry_type, $amount, $direction, $dedupe_key, $notes = '', $status = 'pending' ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_booking_ledger';
    if ( (int) $booking_id <= 0 || (float) $amount < 0 || ! in_array( $direction, array( 'credit', 'debit' ), true ) ) { return 'error'; }
    if ( $dedupe_key !== '' && $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$tbl} WHERE dedupe_key=%s", $dedupe_key ) ) ) { return 'duplicate'; }
    $ok = $wpdb->insert( $tbl, array(
        'booking_id' => (int) $booking_id, 'vendor_id' => $vendor_id ? (int) $vendor_id : null,
        'entry_type' => sanitize_key( $entry_type ), 'amount' => round( (float) $amount, 2 ),
        'direction' => $direction, 'status' => $status, 'dedupe_key' => $dedupe_key !== '' ? $dedupe_key : null,
        'notes' => substr( sanitize_text_field( $notes ), 0, 255 ), 'created_by' => (int) get_current_user_id(),
        'created_at' => current_time( 'mysql' ),
    ) );
    if ( ! $ok ) {
        if ( $dedupe_key !== '' && $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$tbl} WHERE dedupe_key=%s", $dedupe_key ) ) ) { return 'duplicate'; }
        ridego_log( 'LEDGER INSERT FAILED booking ' . (int) $booking_id . ': ' . $wpdb->last_error );
        return 'error';
    }
    return 'inserted';
}

// TRACE: hook ridego_booking_status_changed($booking_id,$status) → on 'completed' with a vendor:
//        stamps trip_ended_at once and increments vendor total_rides_completed exactly once, snapshots commission on the booking, writes the
//        commission debit and advance_held credit (idempotent by key) → returns void.
//        Preconditions: booking has vendor_id. Postconditions: at most one commission + one advance_held
//        row per booking however often the hook fires. Edge cases: no vendor, no model (commission 0
//        → no commission row), advance 0 (no advance row), repeat firing (duplicate → no-op).
function ridego_ledger_record_completion( $booking_id, $status ) {
    global $wpdb;
    if ( $status !== 'completed' ) { return; }
    $bt = $wpdb->prefix . 'ridego_bookings';
    $b  = $wpdb->get_row( $wpdb->prepare( "SELECT id, vendor_id, total_fare, advance_paid, platform_model, commission_model_id, trip_ended_at FROM {$bt} WHERE id=%d", (int) $booking_id ), ARRAY_A );
    if ( ! $b || empty( $b['vendor_id'] ) ) { return; }
    $vendor_id = (int) $b['vendor_id'];
    if ( empty( $b['trip_ended_at'] ) ) {
        $st = $wpdb->update( $bt, array( 'trip_ended_at' => current_time( 'mysql' ) ), array( 'id' => (int) $booking_id ) );
        if ( $st ) {
            $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}ridego_vendors SET total_rides_completed = total_rides_completed + 1 WHERE id=%d", $vendor_id ) );
        }
    }
    // Facilitator model: the vendor lead fee was fixed by the central engine when the vendor was assigned (ridego_lead_fee_lock_for_booking). Here it is posted to the ledger.
    // The part already covered by the customer advance RideGo holds is one settled 'lead_fee_retained' row; whatever the vendor still owes is a pending 'lead_fee' debit; an advance larger than the fee leaves
    // a pending 'advance_held' credit (RideGo owes the vendor the excess). Every row is idempotent by dedupe key.
    if ( ! empty( $b['platform_model'] ) ) {
        ridego_lead_fee_lock_for_booking( (int) $booking_id, $vendor_id );
        $fb = $wpdb->get_row( $wpdb->prepare( "SELECT vendor_lead_fee, vendor_lead_fee_status, vendor_lead_fee_snapshot, advance_paid FROM {$bt} WHERE id=%d", (int) $booking_id ), ARRAY_A );
        if ( ! $fb ) { ridego_log( 'LEDGER: booking vanished during completion ' . (int) $booking_id ); return; }
        $fee = $fb['vendor_lead_fee_status'] === 'waived' ? 0.0 : ridego_lead_fee_round( (float) $fb['vendor_lead_fee'] );
        $snap = ridego_lead_fee_snapshot_decode( $fb['vendor_lead_fee_snapshot'] );
        $offset = array_key_exists( 'offset_advance', $snap ) && $snap['offset_advance'] !== null ? (bool) $snap['offset_advance'] : ridego_lead_fee_options()['offset_advance'];
        $split = ridego_lead_fee_split( $fee, (float) $fb['advance_paid'], $offset );
        $upd = $wpdb->update( $bt, array( 'commission_amount' => $fee, 'commission_model_id' => null ), array( 'id' => (int) $booking_id ) );
        if ( $upd === false ) { ridego_log( 'LEDGER: lead fee snapshot failed for booking ' . (int) $booking_id ); return; }
        if ( $split['applied'] > 0 ) {
            ridego_ledger_add( $booking_id, $vendor_id, 'lead_fee_retained', $split['applied'], 'debit', 'lead_fee:' . (int) $booking_id, 'Lead fee covered by the customer advance ' . ridego_brand_name() . ' holds', 'settled' );
            $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}ridego_booking_ledger SET settled_at=%s WHERE dedupe_key=%s AND settled_at IS NULL", current_time( 'mysql' ), 'lead_fee:' . (int) $booking_id ) );
        }
        if ( $split['payable'] > 0 ) {
            ridego_ledger_add( $booking_id, $vendor_id, 'lead_fee', $split['payable'], 'debit', 'lead_fee_due:' . (int) $booking_id, 'Vendor lead fee payable to ' . ridego_brand_name() . '' );
        }
        if ( $split['excess'] > 0 ) {
            ridego_ledger_add( $booking_id, $vendor_id, 'advance_held', $split['excess'], 'credit', 'advance:' . (int) $booking_id, 'Customer advance held by ' . ridego_brand_name() . ' beyond the lead fee' );
        }
        ridego_lead_fee_sync_status( (int) $booking_id );
        if ( $split['payable'] > 0 ) { do_action( 'ridego_commission_charged', (int) $booking_id, $vendor_id, $split['payable'] ); }
        return;
    }
    $model = ridego_get_vendor_commission_model( $vendor_id );
    $commission = ridego_calculate_commission( $model, $b['total_fare'] );
    $upd = $wpdb->update( $bt, array(
        'commission_amount' => $commission, 'commission_model_id' => $model ? (int) $model['id'] : null,
    ), array( 'id' => (int) $booking_id ) );
    if ( $upd === false ) { ridego_log( 'LEDGER: commission snapshot failed for booking ' . (int) $booking_id ); return; }
    if ( $commission > 0 ) {
        ridego_ledger_add( $booking_id, $vendor_id, 'commission', $commission, 'debit', 'commission:' . (int) $booking_id, 'Commission on completed booking' );
    }
    if ( (float) $b['advance_paid'] > 0 ) {
        ridego_ledger_add( $booking_id, $vendor_id, 'advance_held', (float) $b['advance_paid'], 'credit', 'advance:' . (int) $booking_id, 'Advance collected by platform' );
    }
    if ( $commission > 0 && function_exists( 'ridego_queue_notification' ) ) {
        do_action( 'ridego_commission_charged', (int) $booking_id, $vendor_id, $commission );
    }
}
add_action( 'ridego_booking_status_changed', 'ridego_ledger_record_completion', 15, 2 );

// TRACE: hook ridego_refund_processed($booking_id,$amount) → when the vendor's model says 'reverse' and
//        a commission row exists, adds a commission_reversal credit (idempotent) → returns void.
//        Edge cases: no commission row, model 'none', repeat firing.
function ridego_ledger_on_refund( $booking_id, $amount = 0 ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_booking_ledger';
    $bt  = $wpdb->prefix . 'ridego_bookings';
    $mt  = $wpdb->prefix . 'ridego_commission_models';
    $c = $wpdb->get_row( $wpdb->prepare( "SELECT vendor_id, amount FROM {$tbl} WHERE booking_id=%d AND entry_type='commission'", (int) $booking_id ), ARRAY_A );
    if ( ! $c ) { return; }
    $mode = $wpdb->get_var( $wpdb->prepare( "SELECT m.refund_adjustment FROM {$bt} b JOIN {$mt} m ON m.id=b.commission_model_id WHERE b.id=%d", (int) $booking_id ) );
    if ( $mode !== 'reverse' ) { return; }
    ridego_ledger_add( $booking_id, (int) $c['vendor_id'], 'commission_reversal', (float) $c['amount'], 'credit', 'commission_rev:' . (int) $booking_id, 'Commission reversed after refund' );
}
add_action( 'ridego_refund_processed', 'ridego_ledger_on_refund', 10, 2 );

// TRACE: admin settle → atomically claims the booking's pending rows (status: pending→settling, an
//        UPDATE that only one concurrent caller can win), computes net (credits - debits) from the
//        claimed rows; if net<0 deducts the shortfall from the vendor wallet, then marks the claimed
//        rows settled → array( success, net, message ). Preconditions: booking has pending rows.
//        Postconditions: all rows settled with settled_at, or nothing changed (claim failed / wallet
//        op failed, in which case the claim is released back to pending for retry). Edge cases: nothing
//        pending (no rows claimed), wallet insufficient (claim released, error), two concurrent settle
//        calls for the same booking (only one claims the rows; the other gets 'Nothing pending to
//        settle.' immediately, with zero risk of double-deducting the vendor wallet).
//
// Root-cause fix (found during the #59 ledger/commission audit, reproduced live with two truly
// concurrent PHP processes): the previous implementation opened a transaction, read the pending rows
// with SELECT ... FOR UPDATE, then COMMITted immediately — releasing the row lock — before doing the
// actual wallet deduction and the status update. That left a window in which two concurrent settle
// calls for the same booking both read the same 'pending' rows and both deducted the vendor's wallet,
// confirmed to double the deduction (100 → 200 for a single 100 commission row). Holding a long-lived
// explicit transaction across the wallet-write calls was avoided here (those functions run their own
// queries and nesting is unsafe with $wpdb), so instead the claim itself is the atomic step: an UPDATE
// with an affected-row count is the only thing that decides who "owns" these rows, and MySQL guarantees
// at most one concurrent UPDATE can match a given row at a time.
function ridego_ledger_settle_booking( $booking_id, $actor_id = 0 ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_booking_ledger';
    $booking_id = (int) $booking_id;

    $claimed = $wpdb->query( $wpdb->prepare( "UPDATE {$tbl} SET status='settling' WHERE booking_id=%d AND status='pending'", $booking_id ) );
    if ( ! $claimed ) { return array( 'success' => false, 'message' => 'Nothing pending to settle.' ); }

    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE booking_id=%d AND status='settling'", $booking_id ), ARRAY_A );
    $net = 0.0; $vendor_id = 0; $comp = 0.0;
    foreach ( $rows as $r ) {
        if ( $r['entry_type'] === 'cancellation_compensation' ) { $comp += (float) $r['amount']; }
        $net += $r['direction'] === 'credit' ? (float) $r['amount'] : -(float) $r['amount'];
        if ( ! empty( $r['vendor_id'] ) ) { $vendor_id = (int) $r['vendor_id']; }
    }
    $net = round( $net, 2 );

    if ( $net < 0 && $vendor_id ) {
        $d = ridego_vendor_deduct_wallet( $vendor_id, abs( $net ), $booking_id, 'Lead fee / commission shortfall for booking #' . $booking_id, 'commission' );
        if ( empty( $d['success'] ) ) {
            $wpdb->query( $wpdb->prepare( "UPDATE {$tbl} SET status='pending' WHERE booking_id=%d AND status='settling'", $booking_id ) );
            return array( 'success' => false, 'message' => 'Wallet deduction failed: ' . $d['message'] );
        }
    }
    if ( $comp > 0 && $vendor_id ) {
        // Compensation for a late cancellation is paid into the vendor wallet at settlement.
        $cr = ridego_vendor_credit_wallet( $vendor_id, $comp, $booking_id, 'Compensation for booking #' . $booking_id . ' cancelled by the client after you were arranged', 'credit' );
        if ( empty( $cr['success'] ) ) {
            $wpdb->query( $wpdb->prepare( "UPDATE {$tbl} SET status='pending' WHERE booking_id=%d AND status='settling'", $booking_id ) );
            return array( 'success' => false, 'message' => 'Wallet credit failed: ' . ( $cr['message'] ?? 'unknown error' ) );
        }
    }
    $res = $wpdb->query( $wpdb->prepare( "UPDATE {$tbl} SET status='settled', settled_at=%s WHERE booking_id=%d AND status='settling'", current_time( 'mysql' ), $booking_id ) );
    if ( $res === false ) { return array( 'success' => false, 'message' => 'Could not mark ledger rows settled.' ); }
    ridego_audit_log( 'ledger_settled', 'booking', $booking_id, null, array( 'net' => $net ) );
    if ( function_exists( 'ridego_lead_fee_sync_status' ) ) { ridego_lead_fee_sync_status( $booking_id ); }
    ridego_maybe_close_booking( $booking_id );
    return array( 'success' => true, 'net' => $net, 'message' => 'Booking settled.' );
}

// TRACE: reporting → aggregates ledger rows for an optional vendor, status and created_at date range →
//        array( commission, advance_held, reversals, pending_net, settled_net ). Edge cases: no rows (zeros),
//        status other than pending|settled ignored, blank dates ignored.
function ridego_ledger_summary( $vendor_id = 0, $status = '', $from = '', $to = '' ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_booking_ledger';
    $w = array( '1=1' ); $a = array();
    if ( $vendor_id ) { $w[] = 'vendor_id=%d'; $a[] = (int) $vendor_id; }
    if ( in_array( $status, array( 'pending', 'settled' ), true ) ) { $w[] = 'status=%s'; $a[] = $status; }
    if ( $from ) { $w[] = 'created_at>=%s'; $a[] = $from . ' 00:00:00'; }
    if ( $to )   { $w[] = 'created_at<=%s'; $a[] = $to . ' 23:59:59'; }
    $sql = "SELECT entry_type, direction, status, SUM(amount) AS total FROM {$tbl} WHERE " . implode( ' AND ', $w ) . ' GROUP BY entry_type, direction, status';
    $rows = $wpdb->get_results( $a ? $wpdb->prepare( $sql, $a ) : $sql, ARRAY_A );
    $out = array( 'commission' => 0.0, 'advance_held' => 0.0, 'fee_retained' => 0.0, 'fee_outstanding' => 0.0, 'fee_total' => 0.0, 'compensation' => 0.0, 'reversals' => 0.0, 'pending_net' => 0.0, 'settled_net' => 0.0 );
    foreach ( (array) $rows as $r ) {
        $t = (float) $r['total'];
        if ( $r['entry_type'] === 'commission' ) { $out['commission'] += $t; }
        if ( $r['entry_type'] === 'advance_held' ) { $out['advance_held'] += $t; }
        if ( $r['entry_type'] === 'lead_fee_retained' ) { $out['fee_retained'] += $t; $out['fee_total'] += $t; }
        if ( $r['entry_type'] === 'lead_fee' ) { $out['fee_total'] += $t; if ( $r['status'] === 'pending' || $r['status'] === 'settling' ) { $out['fee_outstanding'] += $t; } }
        if ( $r['entry_type'] === 'cancellation_compensation' ) { $out['compensation'] += $t; }
        if ( $r['entry_type'] === 'commission_reversal' ) { $out['reversals'] += $t; }
        $signed = $r['direction'] === 'credit' ? $t : -$t;
        // 'settling' is the brief in-flight state a row holds while ridego_ledger_settle_booking() has
        // claimed it but not yet finished the wallet write — it is not yet settled, so it counts as
        // pending here too (otherwise a summary read during that narrow window would misreport it).
        if ( $r['status'] === 'pending' || $r['status'] === 'settling' ) { $out['pending_net'] += $signed; } else { $out['settled_net'] += $signed; }
    }
    return array_map( function ( $v ) { return round( $v, 2 ); }, $out );
}

// TRACE: platform income view → sums settled+pending commission minus reversals in a date range →
//        array( gross_commission, reversals, net ). Edge cases: empty range (zeros).
function ridego_ledger_platform_net( $from = '', $to = '' ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_booking_ledger';
    $sql = "SELECT entry_type, SUM(amount) AS total FROM {$tbl} WHERE entry_type IN ('commission','commission_reversal')";
    $args = array();
    if ( $from ) { $sql .= ' AND created_at>=%s'; $args[] = $from . ' 00:00:00'; }
    if ( $to )   { $sql .= ' AND created_at<=%s'; $args[] = $to . ' 23:59:59'; }
    $sql .= ' GROUP BY entry_type';
    $rows = $wpdb->get_results( $args ? $wpdb->prepare( $sql, $args ) : $sql, ARRAY_A );
    $g = 0.0; $r = 0.0;
    foreach ( (array) $rows as $x ) { if ( $x['entry_type'] === 'commission' ) { $g = (float) $x['total']; } else { $r = (float) $x['total']; } }
    return array( 'gross_commission' => round( $g, 2 ), 'reversals' => round( $r, 2 ), 'net' => round( $g - $r, 2 ) );
}

// TRACE: closure check → a completed booking with no pending ledger rows and no unprocessed refund gets
//        closed_at stamped (once) → returns bool closed. Edge cases: not completed, pending rows remain,
//        refund initiated but not processed, already closed (true, no rewrite).
/* ROOT-CAUSE FIX (RideGo-Pre-Delivery-Audit.md, Revisions 1/6/7, OPEN
   ISSUES, recurring across three revisions): "the 'successful booking
   refund/dispute window' item could not be re-read [the original plan
   file that specified it was lost]... closure currently happens when
   the booking is completed and no ledger line is pending, with no
   configurable waiting window."

   The plan's exact number was never recoverable (confirmed unreadable
   again on the third re-check), so this does not invent one. What it
   does: makes the waiting window a real, admin-configurable setting —
   booking_closure_dispute_hours — anchored on trip_ended_at (the one
   timestamp already stamped, exactly once, at completion; see
   ridego_ledger_record_completion() above). The default is 0 hours,
   which reproduces today's exact behavior bit-for-bit (closes as soon
   as completed + no pending ledger lines, same as before this change)
   so no existing deployment's behavior changes until an admin
   deliberately sets a window in Settings. If the lost plan specified a
   particular number of hours, an admin can now enter it and the gap
   is closed for real; until then, RideGo ships with the same
   immediate-closure behavior it always had, honestly represented as
   "no window configured" rather than a guessed default. */
// TRACE: setting read → configured dispute/refund window in hours before a completed booking is eligible to close → int, clamped to 0..720 (30 days). Default 0 = close immediately once otherwise eligible (today's pre-existing behavior, unchanged).
function ridego_booking_closure_dispute_hours() {
    return max( 0, min( 720, (int) ridego_get_setting( 'booking_closure_dispute_hours', 0 ) ) );
}

function ridego_maybe_close_booking( $booking_id ) {
    global $wpdb;
    $bt = $wpdb->prefix . 'ridego_bookings';
    $lt = $wpdb->prefix . 'ridego_booking_ledger';
    $b = $wpdb->get_row( $wpdb->prepare( "SELECT status, closed_at, refund_initiated_at, refund_processed_at, trip_ended_at FROM {$bt} WHERE id=%d", (int) $booking_id ), ARRAY_A );
    if ( ! $b || $b['status'] !== 'completed' ) { return false; }
    if ( ! empty( $b['closed_at'] ) ) { return true; }
    if ( ! empty( $b['refund_initiated_at'] ) && empty( $b['refund_processed_at'] ) ) { return false; }
    $hours = ridego_booking_closure_dispute_hours();
    if ( $hours > 0 ) {
        // trip_ended_at is stamped once, at completion (ridego_ledger_record_completion()); a
        // booking that somehow reached 'completed' without it (should not happen, belt-and-
        // braces) is treated as not yet eligible rather than closing early.
        if ( empty( $b['trip_ended_at'] ) ) { return false; }
        $eligible_at = strtotime( $b['trip_ended_at'] ) + ( $hours * HOUR_IN_SECONDS );
        if ( current_time( 'timestamp' ) < $eligible_at ) { return false; }
    }
    if ( (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$lt} WHERE booking_id=%d AND status IN ('pending','settling')", (int) $booking_id ) ) > 0 ) { return false; }
    return $wpdb->update( $bt, array( 'closed_at' => current_time( 'mysql' ) ), array( 'id' => (int) $booking_id ) ) !== false;
}

// TRACE: hourly cron → closes every completed, unclosed booking that qualifies (max 200 per run) → void.
//        Edge cases: none pending (no-op).
function ridego_run_closure_sweep() {
    global $wpdb;
    $bt = $wpdb->prefix . 'ridego_bookings';
    $ids = $wpdb->get_col( "SELECT id FROM {$bt} WHERE status='completed' AND closed_at IS NULL ORDER BY id ASC LIMIT 200" );
    foreach ( (array) $ids as $id ) { ridego_maybe_close_booking( (int) $id ); }
}
add_action( 'ridego_closure_sweep', 'ridego_run_closure_sweep' );

// TRACE: hook ridego_commission_charged($booking_id,$vendor_id,$amount) → queues an informational notification to
//        the vendor → void. Edge cases: vendor/booking missing (skipped).
function ridego_notify_commission_charged( $booking_id, $vendor_id, $amount ) {
    $v = ridego_get_vendor( (int) $vendor_id ); $b = ridego_get_booking( (int) $booking_id );
    if ( ! $v || ! $b ) { return; }
    ridego_queue_notification( array( 'recipient_id' => $v->user_id, 'recipient_type' => 'vendor', 'recipient_phone' => $v->whatsapp_number ?: $v->phone, 'recipient_email' => $v->email,
        'event' => 'commission_charged', 'channel' => 'email', 'payload' => array( 'booking_id' => (int) $b->id, 'booking_number' => $b->booking_number, 'amount' => ridego_money( $amount ) ), 'scheduled_for' => current_time( 'mysql' ) ) );
}
add_action( 'ridego_commission_charged', 'ridego_notify_commission_charged', 10, 3 );
