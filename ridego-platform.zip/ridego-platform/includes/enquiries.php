<?php
/**
 * RideGo enquiries / leads / quotations: a phone or WhatsApp enquiry is captured before it becomes a booking, can be quoted,
 * followed up, marked lost with a reason, or converted (the booking form is pre-filled and the enquiry is linked to the booking).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: validation/list filters → allowed enquiry statuses in lifecycle order → array. Pure.
function ridego_enquiry_statuses() { return array( 'new', 'contacted', 'quoted', 'converted', 'lost' ); }

// TRACE: raw input + $creating → sanitised map of present fields + error → array('data'=>,'error'=>).
//        Creating needs a name and mobile; the mobile links/creates the client profile at conversion (not here) so an enquiry never pollutes the client list.
//        Rules: quoted_amount ≥ 0; follow_up_date valid Y-m-d (may be past: overdue follow-ups are surfaced); status from the list; lost needs a reason.
function ridego_enquiry_validate( $raw, $creating ) {
    $d = array(); $fail = function ( $m ) { return array( 'data' => null, 'error' => $m ); }; $raw = (array) $raw;
    if ( $creating || array_key_exists( 'name', $raw ) ) { $n = trim( sanitize_text_field( (string) ( $raw['name'] ?? '' ) ) ); if ( $n === '' ) { return $fail( 'Enter the name of the person enquiring.' ); } $d['name'] = mb_substr( $n, 0, 150 ); }
    if ( $creating || array_key_exists( 'phone', $raw ) ) {
        $ph = ridego_sanitize_phone( (string) ( $raw['phone'] ?? '' ) ); $dg = preg_replace( '/\D/', '', $ph );
        if ( strlen( $dg ) < 10 || strlen( $dg ) > 13 ) { return $fail( 'Enter a valid mobile number.' ); }
        $d['phone'] = $ph;
    }
    if ( array_key_exists( 'email', $raw ) ) { $e = trim( (string) $raw['email'] ); if ( $e !== '' && ! is_email( $e ) ) { return $fail( 'Enter a valid email or leave it blank.' ); } $d['email'] = sanitize_email( $e ); }
    if ( array_key_exists( 'source', $raw ) ) { $s = sanitize_key( (string) $raw['source'] ); $d['source'] = in_array( $s, ridego_booking_sources(), true ) ? $s : 'phone'; }
    if ( array_key_exists( 'trip_type', $raw ) ) { $t = sanitize_key( (string) $raw['trip_type'] ); $d['trip_type'] = $t === 'hourly' ? 'local' : ( in_array( $t, ridego_admin_trip_types(), true ) ? $t : '' ); }
    foreach ( array( 'pickup_city', 'drop_city' ) as $k ) { if ( array_key_exists( $k, $raw ) ) { $d[ $k ] = mb_substr( sanitize_text_field( (string) $raw[ $k ] ), 0, 100 ); } }
    foreach ( array( 'journey_date', 'follow_up_date' ) as $k ) {
        if ( array_key_exists( $k, $raw ) ) {
            $v = (string) $raw[ $k ];
            if ( $v !== '' && ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) || ! checkdate( (int) substr( $v, 5, 2 ), (int) substr( $v, 8, 2 ), (int) substr( $v, 0, 4 ) ) ) ) { return $fail( 'Enter a valid date.' ); }
            $d[ $k ] = $v === '' ? null : $v;
        }
    }
    if ( array_key_exists( 'passengers', $raw ) ) { $p = (int) $raw['passengers']; if ( $p < 1 || $p > 50 ) { return $fail( 'Passengers must be between 1 and 50.' ); } $d['passengers'] = $p; }
    if ( array_key_exists( 'vehicle_type_id', $raw ) ) { $d['vehicle_type_id'] = max( 0, (int) $raw['vehicle_type_id'] ); }
    if ( array_key_exists( 'message', $raw ) ) { $d['message'] = mb_substr( sanitize_textarea_field( (string) $raw['message'] ), 0, 2000 ); }
    if ( array_key_exists( 'quoted_amount', $raw ) ) {
        $q = $raw['quoted_amount'];
        if ( $q === '' || $q === null ) { $d['quoted_amount'] = null; } elseif ( ! is_numeric( $q ) || (float) $q < 0 ) { return $fail( 'The quoted amount cannot be negative.' ); } else { $d['quoted_amount'] = round( (float) $q, 2 ); }
    }
    if ( array_key_exists( 'status', $raw ) ) {
        $st = sanitize_key( (string) $raw['status'] );
        if ( ! in_array( $st, ridego_enquiry_statuses(), true ) || $st === 'converted' ) { return $fail( 'Choose a valid status. An enquiry becomes "converted" when a booking is created from it.' ); }
        $d['status'] = $st;
        if ( $st === 'lost' && trim( (string) ( $raw['lost_reason'] ?? '' ) ) === '' ) { return $fail( 'Give the reason this enquiry was lost.' ); }
    }
    if ( array_key_exists( 'lost_reason', $raw ) ) { $d['lost_reason'] = mb_substr( sanitize_text_field( (string) $raw['lost_reason'] ), 0, 255 ); }
    return array( 'data' => $d, 'error' => null );
}

// TRACE: raw input + admin id → stores an enquiry, linking an existing client profile by mobile when there is one → array(success,id,message).
//        Edge cases: validation error; DB failure. A blocked client's enquiry is still stored (support may need the record).
function ridego_enquiry_create( $raw, $admin_id ) {
    global $wpdb;
    $v = ridego_enquiry_validate( $raw, true );
    if ( $v['error'] ) { return array( 'success' => false, 'message' => $v['error'] ); }
    $d = $v['data'];
    $m = ridego_client_find_matches( $d['phone'], '' );
    $row = array_merge( array( 'source' => 'phone', 'status' => 'new', 'passengers' => 1, 'email' => '', 'message' => '', 'trip_type' => '', 'pickup_city' => '', 'drop_city' => '', 'lost_reason' => '' ), $d,
        array( 'client_id' => $m ? (int) $m[0]->id : 0, 'created_by' => (int) $admin_id, 'created_at' => current_time( 'mysql' ), 'updated_at' => current_time( 'mysql' ) ) );
    if ( ! $wpdb->insert( "{$wpdb->prefix}ridego_enquiries", $row ) ) { ridego_log( 'enquiry_create failed: ' . $wpdb->last_error ); return array( 'success' => false, 'message' => 'Could not save the enquiry.' ); }
    $id = (int) $wpdb->insert_id; ridego_audit_log( 'enquiry_created', 'enquiry', $id, '', $row['name'] );
    return array( 'success' => true, 'id' => $id, 'message' => 'Enquiry saved.', 'client_id' => $row['client_id'] );
}

// TRACE: enquiry id + partial input + admin → updates (status moves, quote, follow-up) → array(success,message). Converted enquiries are frozen. Edge cases: unknown id, validation.
function ridego_enquiry_update( $id, $raw, $admin_id ) {
    global $wpdb;
    $cur = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_enquiries WHERE id=%d", (int) $id ) );
    if ( ! $cur ) { return array( 'success' => false, 'message' => 'Enquiry not found.' ); }
    if ( $cur->status === 'converted' ) { return array( 'success' => false, 'message' => 'This enquiry has already been converted to a booking.' ); }
    $v = ridego_enquiry_validate( $raw, false );
    if ( $v['error'] ) { return array( 'success' => false, 'message' => $v['error'] ); }
    $d = $v['data'];
    if ( isset( $d['quoted_amount'] ) && $d['quoted_amount'] !== null && ! isset( $d['status'] ) && $cur->status === 'new' ) { $d['status'] = 'quoted'; }
    if ( ! $d ) { return array( 'success' => true, 'message' => 'No changes to save.' ); }
    $d['updated_at'] = current_time( 'mysql' );
    if ( false === $wpdb->update( "{$wpdb->prefix}ridego_enquiries", $d, array( 'id' => (int) $id ) ) ) { return array( 'success' => false, 'message' => 'Could not save the enquiry.' ); }
    ridego_audit_log( 'enquiry_updated', 'enquiry', (int) $id, $cur->status, $d['status'] ?? $cur->status );
    return array( 'success' => true, 'message' => 'Enquiry updated.' );
}

// TRACE: enquiry id + booking id → marks the enquiry converted and linked to the booking (called by booking creation) → bool. Edge cases: unknown id (false).
function ridego_enquiry_mark_converted( $id, $booking_id ) {
    global $wpdb;
    $ok = $wpdb->update( "{$wpdb->prefix}ridego_enquiries", array( 'status' => 'converted', 'converted_booking_id' => (int) $booking_id, 'updated_at' => current_time( 'mysql' ) ), array( 'id' => (int) $id ) );
    if ( $ok !== false ) { ridego_audit_log( 'enquiry_converted', 'enquiry', (int) $id, '', (string) $booking_id ); }
    return $ok !== false;
}

// TRACE: list args (status, q, overdue, page, per_page) → array(rows,total,counts). Counts are per status for the tab badges; overdue = follow-up date before today on an open enquiry.
function ridego_enquiry_list( $args ) {
    global $wpdb;
    $t = "{$wpdb->prefix}ridego_enquiries"; $w = array( '1=1' ); $v = array();
    $st = sanitize_key( (string) ( $args['status'] ?? '' ) ); if ( $st !== '' ) { $w[] = 'status=%s'; $v[] = $st; }
    $q = trim( (string) ( $args['q'] ?? '' ) );
    if ( $q !== '' ) { $l = '%' . $wpdb->esc_like( $q ) . '%'; $w[] = '(name LIKE %s OR phone LIKE %s OR email LIKE %s OR pickup_city LIKE %s OR drop_city LIKE %s)'; array_push( $v, $l, $l, $l, $l, $l ); }
    if ( ! empty( $args['overdue'] ) ) { $w[] = "follow_up_date IS NOT NULL AND follow_up_date < %s AND status IN ('new','contacted','quoted')"; $v[] = current_time( 'Y-m-d' ); }
    $per = max( 1, min( 100, (int) ( $args['per_page'] ?? 25 ) ) ); $page = max( 1, (int) ( $args['page'] ?? 1 ) ); $ws = implode( ' AND ', $w );
    $total = (int) ( $v ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE {$ws}", $v ) ) : $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" ) );
    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE {$ws} ORDER BY (follow_up_date IS NULL), follow_up_date ASC, id DESC LIMIT %d OFFSET %d", array_merge( $v, array( $per, ( $page - 1 ) * $per ) ) ) );
    $counts = array(); foreach ( (array) $wpdb->get_results( "SELECT status, COUNT(*) n FROM {$t} GROUP BY status" ) as $r ) { $counts[ $r->status ] = (int) $r->n; }
    $today = current_time( 'Y-m-d' );
    return array( 'rows' => array_map( function ( $e ) use ( $today ) { $a = (array) $e; foreach ( array( 'id', 'client_id', 'passengers', 'vehicle_type_id' ) as $ik ) { if ( isset( $a[ $ik ] ) ) { $a[ $ik ] = (int) $a[ $ik ]; } } $a['converted_booking_id'] = empty( $a['converted_booking_id'] ) ? null : (int) $a['converted_booking_id']; $a['overdue'] = ! empty( $e->follow_up_date ) && $e->follow_up_date < $today && in_array( $e->status, array( 'new', 'contacted', 'quoted' ), true ); return $a; }, (array) $rows ),
        'total' => $total, 'page' => $page, 'per_page' => $per, 'counts' => $counts );
}

// TRACE: enquiry id → prefill payload for the booking form (client existing→id, else new_client fields) + trip fields → array|null. Pure read.
function ridego_enquiry_prefill( $id ) {
    global $wpdb;
    $e = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_enquiries WHERE id=%d", (int) $id ) );
    if ( ! $e ) { return null; }
    $m = ridego_client_find_matches( $e->phone, $e->email );
    return array( 'enquiry_id' => (int) $e->id, 'client' => $m ? ridego_client_summary( $m[0] ) : null, 'new_client' => array( 'name' => $e->name, 'phone' => $e->phone, 'email' => $e->email ),
        'trip' => array( 'trip_type' => $e->trip_type ?: 'one_way', 'pickup_city' => $e->pickup_city, 'drop_city' => $e->drop_city, 'journey_date' => (string) $e->journey_date, 'passengers' => (int) $e->passengers,
            'vehicle_type_id' => (int) $e->vehicle_type_id, 'special_requests' => (string) $e->message ), 'source' => $e->source, 'quoted_amount' => $e->quoted_amount !== null ? (float) $e->quoted_amount : null, 'status' => $e->status );
}
