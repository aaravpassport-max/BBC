<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Phase B, wave 1
   ------------------------------------------------------------
   The first slice of "rebuild wp-admin's day-to-day operational
   dashboards as React screens" (see the phased plan in the Wave 15
   remediation report section): vendor management and KYC approval.
   Every business rule enforced here is the SAME canonical function
   the existing wp-admin page (admin/pages/vendors.php) already
   calls — ridego_approve_kyc(), ridego_reject_kyc(),
   ridego_set_vendor_status() — so this is a new UI on the existing,
   already-audited business logic, not a second, divergent
   implementation of vendor/KYC rules. wp-admin's vendor page is
   left fully intact and working; this is an additive React
   equivalent under /app/admin/..., not a replacement in this wave.

   Every route here requires BOTH is_user_logged_in() (WordPress's
   job, per the "WP = auth only" architecture) AND
   ridego_can('ridego_manage_vendors') (RideGo's own granular RBAC,
   the same capability admin/admin.php's menu registration and
   admin/pages/vendors.php's own render function both gate on) —
   never just an is_admin flag, so this stays exactly as protected
   as the wp-admin page it's an alternative front end for.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_api_routes' );
function ridego_register_app_admin_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/vendors', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_vendors_list',
        'permission_callback' => 'ridego_app_admin_api_vendors_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/vendors/(?P<id>\d+)', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_vendor_detail',
        'permission_callback' => 'ridego_app_admin_api_vendors_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/vendors/(?P<id>\d+)/kyc/approve', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_kyc_approve',
        'permission_callback' => 'ridego_app_admin_api_vendors_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/vendors/(?P<id>\d+)/kyc/reject', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_kyc_reject',
        'permission_callback' => 'ridego_app_admin_api_vendors_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/vendors/(?P<id>\d+)/status', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_vendor_status',
        'permission_callback' => 'ridego_app_admin_api_vendors_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/vendors/(?P<id>\d+)/notes', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_vendor_notes',
        'permission_callback' => 'ridego_app_admin_api_vendors_permission',
    ) );

    /* Add Vendor — previously had no REST route at all; the old
       wp-admin form posts straight to ridego_create_vendor(), so this
       is a thin wrapper over that same canonical function. */
    register_rest_route( 'ridego/v1', '/app/admin/vendors', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_vendor_create',
        'permission_callback' => 'ridego_app_admin_api_vendors_permission',
    ) );

    /* Bulk approve-KYC / suspend — mirrors admin/pages/vendors.php's
       rga_bulk_act handler exactly (same per-row eligibility checks,
       same ridego_approve_kyc()/ridego_set_vendor_status() calls). Had
       no React equivalent before this pass. */
    register_rest_route( 'ridego/v1', '/app/admin/vendors/bulk', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_vendors_bulk',
        'permission_callback' => 'ridego_app_admin_api_vendors_permission',
    ) );
}

function ridego_app_admin_api_vendors_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_vendors' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage vendors.', array( 'status' => 403 ) );
    }
    return true;
}

/**
 * Paginated/filterable vendor list, plus the same KPI counts
 * admin/pages/vendors.php shows — the WHERE-clause logic here is
 * intentionally the same shape as that page's inline query (status/
 * kyc/city/search filters), just returned as JSON instead of
 * rendered HTML.
 */
function ridego_app_admin_api_vendors_list( WP_REST_Request $req ) {
    global $wpdb;
    $vtbl = $wpdb->prefix . 'ridego_vendors';

    $status   = sanitize_key( (string) $req->get_param( 'status' ) );
    $kyc      = sanitize_key( (string) $req->get_param( 'kyc' ) );
    $city     = sanitize_text_field( (string) $req->get_param( 'city' ) );
    $vtype    = sanitize_key( (string) $req->get_param( 'vendor_type' ) );
    $expiring = absint( $req->get_param( 'expiring' ) );
    $search   = sanitize_text_field( (string) $req->get_param( 'search' ) );
    $page     = max( 1, (int) $req->get_param( 'page' ) );
    $limit    = 25;
    $offset   = ( $page - 1 ) * $limit;

    $where = array( '1=1' );
    $vals  = array();
    if ( $status ) { $where[] = 'status = %s'; $vals[] = $status; }
    if ( $kyc )    { $where[] = 'kyc_status = %s'; $vals[] = $kyc; }
    if ( $city )   { $where[] = 'city = %s'; $vals[] = $city; }
    if ( in_array( $vtype, array( 'individual', 'fleet' ), true ) ) { $where[] = 'vendor_type = %s'; $vals[] = $vtype; }
    if ( $expiring ) {
        $lim = date( 'Y-m-d', strtotime( '+' . $expiring . ' days' ) );
        $where[] = "(status!='blacklisted') AND ((license_expiry IS NOT NULL AND license_expiry BETWEEN CURDATE() AND %s) OR (insurance_expiry IS NOT NULL AND insurance_expiry BETWEEN CURDATE() AND %s) OR id IN (SELECT vendor_id FROM {$wpdb->prefix}ridego_driver_docs WHERE expiry_date IS NOT NULL AND expiry_date BETWEEN CURDATE() AND %s))";
        array_push( $vals, $lim, $lim, $lim );
    }
    if ( $search ) {
        $lk = '%' . $wpdb->esc_like( $search ) . '%';
        $where[] = '(business_name LIKE %s OR owner_name LIKE %s OR phone LIKE %s OR email LIKE %s)';
        array_push( $vals, $lk, $lk, $lk, $lk );
    }
    $where_sql = implode( ' AND ', $where );

    $total = $vals
        ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$vtbl} WHERE {$where_sql}", $vals ) )
        : (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$vtbl} WHERE {$where_sql}" );

    $rows_vals = array_merge( $vals, array( $limit, $offset ) );
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, business_name, owner_name, phone, email, city, business_type, vendor_type, status, kyc_status, wallet_balance, rating, total_ratings, joined_at
         FROM {$vtbl} WHERE {$where_sql} ORDER BY joined_at DESC LIMIT %d OFFSET %d",
        $rows_vals
    ) );

    $out = array_map( function ( $v ) {
        /* Retroactive integrity flag: a vendor can be sitting at
           kyc_status='verified' with required documents missing —
           either approved via the "Approve anyway" force override,
           or approved before ridego_vendor_kyc_missing_docs() existed.
           Surfaced here so the list view can badge it without a
           second round trip per row. */
        $kyc_missing_docs = ( $v->kyc_status === 'verified' && function_exists( 'ridego_vendor_kyc_missing_docs' ) )
            ? ridego_vendor_kyc_missing_docs( (int) $v->id )
            : array();
        return array(
            'id'                => (int) $v->id,
            'business_name'     => $v->business_name,
            'owner_name'        => $v->owner_name,
            'phone'             => $v->phone,
            'email'             => $v->email,
            'city'              => $v->city,
            'business_type'     => isset( $v->business_type ) ? $v->business_type : '',
            'vendor_type'       => $v->vendor_type === 'fleet' ? 'fleet' : 'individual',
            'status'            => $v->status,
            'kyc_status'        => $v->kyc_status,
            'kyc_docs_incomplete' => ! empty( $kyc_missing_docs ),
            'kyc_missing_docs'  => array_values( $kyc_missing_docs ),
            'wallet_balance'    => (float) $v->wallet_balance,
            'rating'            => (float) $v->rating,
            'total_ratings'     => (int) $v->total_ratings,
            'joined_at'         => $v->joined_at,
        );
    }, $rows );

    $exp30_days = date( 'Y-m-d', strtotime( '+30 days' ) );
    $kpis = array(
        'total'             => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$vtbl}" ),
        'active'            => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$vtbl} WHERE status='active'" ),
        'kyc_pending'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$vtbl} WHERE kyc_status IN('submitted','complete') AND status='pending'" ),
        'low_wallet'        => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$vtbl} WHERE wallet_balance<200 AND status='active'" ),
        'wallet_float'      => (float) $wpdb->get_var( "SELECT COALESCE(SUM(wallet_balance),0) FROM {$vtbl} WHERE status='active'" ),
        'docs_expiring_30d' => (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(DISTINCT id) FROM {$vtbl} WHERE status!='blacklisted' AND ((license_expiry IS NOT NULL AND license_expiry BETWEEN CURDATE() AND %s) OR (insurance_expiry IS NOT NULL AND insurance_expiry BETWEEN CURDATE() AND %s) OR id IN (SELECT vendor_id FROM {$wpdb->prefix}ridego_driver_docs WHERE expiry_date IS NOT NULL AND expiry_date BETWEEN CURDATE() AND %s))",
            $exp30_days, $exp30_days, $exp30_days
        ) ),
        'expired_docs'      => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$vtbl} WHERE kyc_status='expired_docs'" ),
    );

    return rest_ensure_response( array(
        'rows'     => $out,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $limit,
        'kpis'     => $kpis,
    ) );
}

/**
 * Vendor detail + KYC documents together — everything the admin
 * needs to make an approve/reject decision in one call, reusing
 * ridego_get_vendor() and ridego_get_vendor_docs(), the same
 * functions the vendor's own /app/vendor/docs endpoint (Wave 10)
 * and the wp-admin detail view already use.
 */
// TRACE: GET admin vendor detail → vendor payload now including user_id and vendor_type → response|404.
//        Preconditions: admin capability → Postconditions: read-only → Edge cases: unknown vendor (404).
function ridego_app_admin_api_vendor_detail( WP_REST_Request $req ) {
    global $wpdb;
    $id     = (int) $req->get_param( 'id' );
    $vendor = ridego_get_vendor( $id );
    if ( ! $vendor ) {
        return new WP_Error( 'not_found', 'Vendor not found.', array( 'status' => 404 ) );
    }
    $docs = function_exists( 'ridego_get_vendor_docs' ) ? ridego_get_vendor_docs( $id ) : array();
    $wallet_history = function_exists( 'ridego_get_vendor_wallet_history' ) ? ridego_get_vendor_wallet_history( $id, 25 ) : array();

    /* Leads/rides/fees KPI strip — same query as
       ridego_render_vendor_detail_v5() in admin/pages/vendors.php. */
    $leads_stats = $wpdb->get_row( $wpdb->prepare(
        "SELECT COUNT(*) as total, SUM(CASE WHEN status='assigned' THEN 1 ELSE 0 END) as done,
                COALESCE(SUM(CASE WHEN status='assigned' THEN fee_amount ELSE 0 END),0) as fees
         FROM {$wpdb->prefix}ridego_leads WHERE vendor_id=%d",
        $id
    ) );
    $completed_rides = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_bookings WHERE vendor_id=%d AND status='completed'",
        $id
    ) );

    // RideGo-Pre-Delivery-Audit.md, Revision 6, OPEN ISSUES (#12): operating_cities and
    // vehicle_types are stored as JSON in the DB (wp_json_encode in vendor.php); this endpoint
    // previously called a non-existent rga_decode() helper, which silently fell back to the raw
    // JSON string being shown to the admin (e.g. ["Delhi","Agra"] and [2,3,4] in the UI).
    // Root-cause fix: decode the JSON directly, and resolve vehicle type IDs to their names.
    $op_cities_raw = isset( $vendor->operating_cities ) ? json_decode( (string) $vendor->operating_cities, true ) : null;
    $op_cities = is_array( $op_cities_raw ) ? $op_cities_raw : null;

    $veh_type_ids_raw = isset( $vendor->vehicle_types ) ? json_decode( (string) $vendor->vehicle_types, true ) : null;
    $veh_types = null;
    if ( is_array( $veh_type_ids_raw ) ) {
        $veh_types = array();
        foreach ( $veh_type_ids_raw as $vtid ) {
            $vt = ridego_get_vehicle( (int) $vtid );
            $veh_types[] = $vt ? $vt->name : sprintf( '#%d', (int) $vtid );
        }
    }

    return rest_ensure_response( array(
        'id'                 => (int) $vendor->id,
        'user_id'            => (int) $vendor->user_id,
        'vendor_type'        => function_exists( 'ridego_get_vendor_type' ) ? ridego_get_vendor_type( $vendor ) : 'individual',
        'business_name'      => $vendor->business_name,
        'owner_name'         => $vendor->owner_name,
        'phone'              => $vendor->phone,
        'alt_phone'          => isset( $vendor->alt_phone ) ? $vendor->alt_phone : '',
        'whatsapp_number'    => isset( $vendor->whatsapp_number ) ? $vendor->whatsapp_number : '',
        'email'              => $vendor->email,
        'city'               => $vendor->city,
        'operating_cities'   => is_array( $op_cities ) ? implode( ', ', $op_cities ) : ( isset( $vendor->operating_cities ) ? $vendor->operating_cities : '' ),
        'vehicle_types'      => is_array( $veh_types ) ? implode( ', ', $veh_types ) : ( isset( $vendor->vehicle_types ) ? $vendor->vehicle_types : '' ),
        'business_type'      => isset( $vendor->business_type ) ? $vendor->business_type : '',
        'gst_number'         => isset( $vendor->gst_number ) ? $vendor->gst_number : '',
        'pan_number'         => isset( $vendor->pan_number ) ? $vendor->pan_number : '',
        'license_number'     => isset( $vendor->license_number ) ? $vendor->license_number : '',
        'insurance_policy'   => isset( $vendor->insurance_policy ) ? $vendor->insurance_policy : '',
        'address'            => isset( $vendor->address ) ? $vendor->address : '',
        'total_vehicles'     => isset( $vendor->total_vehicles ) ? (int) $vendor->total_vehicles : 0,
        'years_experience'   => isset( $vendor->years_experience ) ? (int) $vendor->years_experience : 0,
        'background_check'   => ! empty( $vendor->background_check ),
        'total_rides_completed' => isset( $vendor->total_rides_completed ) ? (int) $vendor->total_rides_completed : 0,
        'commission_pct'     => isset( $vendor->commission_pct ) ? (float) $vendor->commission_pct : 0,
        'bank_name'          => isset( $vendor->bank_name ) ? $vendor->bank_name : '',
        'bank_account'       => isset( $vendor->bank_account ) ? $vendor->bank_account : '',
        'bank_ifsc'          => isset( $vendor->bank_ifsc ) ? $vendor->bank_ifsc : '',
        'bank_holder'        => isset( $vendor->bank_holder ) ? $vendor->bank_holder : '',
        'upi_id'             => isset( $vendor->upi_id ) ? $vendor->upi_id : '',
        'notes_admin'        => isset( $vendor->notes_admin ) ? $vendor->notes_admin : '',
        'status'             => $vendor->status,
        'kyc_status'         => $vendor->kyc_status,
        'kyc_missing_docs'   => function_exists( 'ridego_vendor_kyc_missing_docs' ) ? array_values( ridego_vendor_kyc_missing_docs( $id ) ) : array(),
        'documents_verified' => ! empty( $vendor->documents_verified ),
        'wallet_balance'     => (float) $vendor->wallet_balance,
        'rating'             => (float) $vendor->rating,
        'total_ratings'      => (int) $vendor->total_ratings,
        'joined_at'          => isset( $vendor->joined_at ) ? $vendor->joined_at : '',
        'kpis'               => array(
            'total_leads'      => (int) ( $leads_stats->total ?? 0 ),
            'accepted_leads'   => (int) ( $leads_stats->done ?? 0 ),
            'completed_rides'  => $completed_rides,
            'fees_paid'        => (float) ( $leads_stats->fees ?? 0 ),
        ),
        'wallet_history'     => array_map( function ( $tx ) {
            return array(
                'id'         => isset( $tx->id ) ? (int) $tx->id : 0,
                'created_at' => isset( $tx->created_at ) ? $tx->created_at : '',
                'type'       => isset( $tx->type ) ? $tx->type : '',
                'amount'     => isset( $tx->amount ) ? (float) $tx->amount : 0,
                'notes'      => isset( $tx->notes ) ? $tx->notes : '',
            );
        }, $wallet_history ),
        'docs'               => array_map( function ( $d ) {
            return array(
                'id'          => (int) $d->id,
                'doc_type'    => $d->doc_type,
                'status'      => $d->status,
                'file_path'   => isset( $d->file_path ) ? $d->file_path : '',
                'expiry_date' => isset( $d->expiry_date ) ? $d->expiry_date : null,
                'uploaded_at' => isset( $d->uploaded_at ) ? $d->uploaded_at : '',
            );
        }, $docs ),
    ) );
}

/**
 * Wallet credit/debit for the vendor detail page reuse the existing
 * POST /app/admin/wallet/credit/{id} and /debit/{id} routes already
 * registered by includes/app-admin-financial-api.php (built for the
 * Wallet Reconciliation report's drill-down) — both are thin wrappers
 * over the same canonical ridego_vendor_credit_wallet()/
 * ridego_vendor_deduct_wallet() admin/pages/vendors.php's "Adjust
 * Wallet" form calls, so there is no need for a second, duplicate
 * pair of routes here; the vendor detail page's API client just
 * calls those existing functions directly (see app/src/lib/api.ts).
 */
// TRACE: POST vendors/{id}/notes {notes_admin} → overwrites the vendor's internal admin note → {success}|404/500.
//        Postconditions: the change is now audited with old/new text, matching every sibling vendor-mutation
//        endpoint in this file (KYC approve/reject, status change all call ridego_audit_log()) — this was the
//        one write path in this file that did a raw $wpdb->update with no audit entry at all, found during the
//        platform audit's coverage check of ridego_audit_log() call sites.
function ridego_app_admin_api_vendor_notes( WP_REST_Request $req ) {
    global $wpdb;
    $id    = (int) $req->get_param( 'id' );
    $notes = sanitize_textarea_field( (string) $req->get_param( 'notes_admin' ) );
    $vendor = ridego_get_vendor( $id );
    if ( ! $vendor ) {
        return new WP_Error( 'not_found', 'Vendor not found.', array( 'status' => 404 ) );
    }
    $old_notes = isset( $vendor->notes_admin ) ? $vendor->notes_admin : '';
    $result = $wpdb->update( $wpdb->prefix . 'ridego_vendors', array( 'notes_admin' => $notes ), array( 'id' => $id ) );
    if ( false === $result ) {
        return new WP_Error( 'save_failed', 'Could not save notes.', array( 'status' => 500 ) );
    }
    ridego_audit_log( 'vendor_notes_updated', 'vendor', $id, $old_notes, $notes );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Notes saved.' ) );
}

/**
 * Add Vendor — thin wrapper over the same canonical ridego_create_vendor()
 * (includes/vendor.php) the old wp-admin "Add New Vendor" form posts to.
 */
function ridego_app_admin_api_vendor_create( WP_REST_Request $req ) {
    $data = array(
        'business_name'    => sanitize_text_field( (string) $req->get_param( 'business_name' ) ),
        'owner_name'       => sanitize_text_field( (string) $req->get_param( 'owner_name' ) ),
        'phone'            => sanitize_text_field( (string) $req->get_param( 'phone' ) ),
        'email'            => sanitize_email( (string) $req->get_param( 'email' ) ),
        'city'             => sanitize_text_field( (string) $req->get_param( 'city' ) ),
        'business_type'    => sanitize_key( (string) ( $req->get_param( 'business_type' ) ?: 'individual' ) ),
        'total_vehicles'   => absint( $req->get_param( 'total_vehicles' ) ),
        'years_experience' => absint( $req->get_param( 'years_experience' ) ),
    );
    $r = ridego_create_vendor( $data );
    if ( is_array( $r ) && ! empty( $r['success'] ) ) {
        $vid = isset( $r['vendor_id'] ) ? (int) $r['vendor_id'] : ( isset( $r[0] ) ? (int) $r[0] : 0 );
        return rest_ensure_response( array( 'success' => true, 'vendor_id' => $vid, 'message' => 'Vendor created.' ) );
    }
    if ( is_numeric( $r ) && $r > 0 ) {
        return rest_ensure_response( array( 'success' => true, 'vendor_id' => (int) $r, 'message' => 'Vendor created.' ) );
    }
    $message = is_array( $r ) && isset( $r['message'] ) ? $r['message'] : 'Could not create vendor.';
    return new WP_Error( 'create_failed', $message, array( 'status' => 400 ) );
}

/**
 * Bulk approve-KYC / suspend over a set of vendor IDs. Mirrors
 * admin/pages/vendors.php's rga_bulk_act handler exactly: 'approve_kyc'
 * skips vendors not in kyc_status submitted/complete, 'suspend' skips
 * vendors already suspended, both delegate to the same canonical
 * ridego_approve_kyc()/ridego_set_vendor_status() functions.
 */
function ridego_app_admin_api_vendors_bulk( WP_REST_Request $req ) {
    $action = sanitize_key( (string) $req->get_param( 'action' ) );
    $ids    = $req->get_param( 'ids' );
    $ids    = is_array( $ids ) ? array_filter( array_unique( array_map( 'absint', $ids ) ) ) : array();

    if ( ! in_array( $action, array( 'approve_kyc', 'suspend' ), true ) ) {
        return new WP_Error( 'invalid_action', 'Unknown bulk action.', array( 'status' => 400 ) );
    }
    if ( empty( $ids ) ) {
        return new WP_Error( 'invalid_input', 'No vendors selected.', array( 'status' => 400 ) );
    }

    $ok = 0;
    $skipped = array();
    foreach ( $ids as $vid ) {
        $v = ridego_get_vendor( $vid );
        if ( ! $v ) { $skipped[] = "#{$vid} (not found)"; continue; }

        if ( 'approve_kyc' === $action ) {
            if ( ! in_array( $v->kyc_status, array( 'submitted', 'complete' ), true ) ) {
                $skipped[] = $v->business_name . ' (not awaiting KYC review)';
                continue;
            }
            $r = ridego_approve_kyc( $vid, get_current_user_id() );
            if ( empty( $r['success'] ) ) {
                // Root-cause fix: a vendor missing required documents is skipped here rather than
                // silently approved, matching the single-approve gate in ridego_approve_kyc() — bulk
                // approval has no per-vendor confirmation step to offer a force override through, so
                // it never forces; the admin reviews and approves that one vendor individually instead.
                $skipped[] = $v->business_name . ' (missing documents — approve individually to override)';
                continue;
            }
            $ok++;
        } else {
            if ( 'suspended' === $v->status ) {
                $skipped[] = $v->business_name . ' (already suspended)';
                continue;
            }
            $r = ridego_set_vendor_status( $vid, 'suspended', 'Bulk admin suspension' );
            if ( empty( $r['success'] ) ) {
                $skipped[] = $v->business_name . ' (' . $r['message'] . ')';
                continue;
            }
            $ok++;
        }
    }

    $message = $ok . ' succeeded' . ( count( $skipped ) ? ', ' . count( $skipped ) . ' skipped: ' . implode( '; ', array_slice( $skipped, 0, 5 ) ) . ( count( $skipped ) > 5 ? ' …' : '' ) : '.' );

    return rest_ensure_response( array(
        'success'   => $ok > 0,
        'message'   => $message,
        'succeeded' => $ok,
        'skipped'   => $skipped,
    ) );
}

function ridego_app_admin_api_kyc_approve( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    if ( ! ridego_get_vendor( $id ) ) {
        return new WP_Error( 'not_found', 'Vendor not found.', array( 'status' => 404 ) );
    }
    $force = (bool) $req->get_param( 'force' );
    $r = ridego_approve_kyc( $id, get_current_user_id(), $force );
    if ( empty( $r['success'] ) ) {
        // 409 (not a generic 400): this is specifically "blocked pending an explicit decision" —
        // the admin UI reads missing_docs to offer an "Approve anyway" confirmation that re-submits
        // with force=1, rather than treating this the same as an ordinary failure.
        return new WP_Error( 'missing_documents', $r['message'] ?? "Could not approve this vendor's KYC.", array( 'status' => 409, 'missing_docs' => $r['missing_docs'] ?? array() ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'], 'forced' => $r['forced'] ?? false ) );
}

function ridego_app_admin_api_kyc_reject( WP_REST_Request $req ) {
    $id     = (int) $req->get_param( 'id' );
    $reason = sanitize_textarea_field( (string) $req->get_param( 'reason' ) );
    $doc_type = sanitize_key( (string) $req->get_param( 'doc_type' ) );
    if ( ! $reason ) {
        return new WP_Error( 'invalid_input', 'Please provide a rejection reason.', array( 'status' => 400 ) );
    }
    if ( ! ridego_get_vendor( $id ) ) {
        return new WP_Error( 'not_found', 'Vendor not found.', array( 'status' => 404 ) );
    }
    ridego_reject_kyc( $id, $reason, $doc_type );
    return rest_ensure_response( array( 'success' => true, 'message' => 'KYC rejected.' ) );
}

/**
 * Activate/suspend a vendor. Delegates entirely to
 * ridego_set_vendor_status(), which already enforces the real
 * state-machine transition table and requires a reason for any
 * transition that removes/restores a vendor's ability to operate —
 * this handler adds no logic of its own beyond passing the request
 * through and surfacing whatever that function decides.
 */
function ridego_app_admin_api_vendor_status( WP_REST_Request $req ) {
    $id     = (int) $req->get_param( 'id' );
    $status = sanitize_key( (string) $req->get_param( 'status' ) );
    $reason = sanitize_textarea_field( (string) $req->get_param( 'reason' ) );
    if ( ! $status ) {
        return new WP_Error( 'invalid_input', 'Please specify a target status.', array( 'status' => 400 ) );
    }
    if ( ! function_exists( 'ridego_set_vendor_status' ) ) {
        return new WP_Error( 'unavailable', 'Vendor status changes are not available.', array( 'status' => 500 ) );
    }
    $result = ridego_set_vendor_status( $id, $status, $reason );
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'status_change_failed', $result['message'] ?? 'Could not change vendor status.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( $result );
}
