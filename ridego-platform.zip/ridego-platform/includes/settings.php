<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
/* Settings module - built in Session 5 */
