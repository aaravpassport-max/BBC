<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   VENDOR SUBSCRIPTION SYSTEM (Wave 2D)
   ------------------------------------------------------------
   Turns the plan CRUD in admin/pages/subscriptions.php into a real
   billing pipeline: purchase (wallet or Razorpay), renewal
   automation with dunning, cancellation, and perk consumption
   (priority_boost in lead scoring, lead_discount in fee
   calculation, max_leads as a monthly cap) — see includes/vendor.php
   and includes/pricing.php for where perks are actually applied.

   Depends on includes/vendor.php (wallet functions live in
   helpers.php but ridego_get_vendor() etc. are vendor.php's domain)
   and includes/payment.php (Razorpay order creation, transaction
   logging) — loaded after both in ridego-platform.php.
   ============================================================ */

/**
 * Fetch a subscription plan row, or null.
 */
function ridego_get_subscription_plan( $plan_id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_subscription_plans WHERE id=%d", (int) $plan_id
    ) );
}

/**
 * Compute period_end from a billing_cycle + start date.
 */
function ridego_subscription_period_end( $billing_cycle, $from = null ) {
    $from = $from ? strtotime( $from ) : time();
    switch ( $billing_cycle ) {
        case 'quarterly': return date( 'Y-m-d H:i:s', strtotime( '+3 months', $from ) );
        case 'yearly':    return date( 'Y-m-d H:i:s', strtotime( '+1 year', $from ) );
        case 'monthly':
        default:          return date( 'Y-m-d H:i:s', strtotime( '+1 month', $from ) );
    }
}

/**
 * Subscribe a vendor to a plan.
 *
 * $payment_method:
 *   'wallet'   — deduct the plan price from the vendor's wallet atomically
 *                (ridego_vendor_deduct_wallet()). Activates immediately on
 *                success; fails cleanly (no partial state) if balance is
 *                insufficient.
 *   'razorpay' — creates a subscription_billing row with status='pending'
 *                and a Razorpay order. Perks are NOT applied here — only
 *                once the Razorpay webhook confirms payment (see
 *                ridego_process_subscription_webhook_payment() below and
 *                the extended handler in includes/api.php). Never trust
 *                the client-side checkout redirect alone.
 *
 * @return array ['success'=>bool,'message'=>string, optional 'order'=>..., 'billing_id'=>...]
 */
function ridego_subscribe_vendor( $vendor_id, $plan_id, $payment_method = 'wallet' ) {
    global $wpdb;
    $vendor_id = (int) $vendor_id;
    $plan_id   = (int) $plan_id;

    $vendor = ridego_get_vendor( $vendor_id );
    if ( ! $vendor ) {
        return array( 'success' => false, 'message' => 'Vendor not found.' );
    }
    $plan = ridego_get_subscription_plan( $plan_id );
    if ( ! $plan || ! $plan->is_active ) {
        return array( 'success' => false, 'message' => 'Subscription plan not found or inactive.' );
    }

    $period_start = current_time( 'mysql' );
    $period_end   = ridego_subscription_period_end( $plan->billing_cycle, $period_start );

    if ( $payment_method === 'wallet' ) {
        if ( (float) $plan->price > 0 ) {
            $deduct = ridego_vendor_deduct_wallet(
                $vendor_id, (float) $plan->price, null,
                'Subscription: ' . $plan->name, 'subscription_charge'
            );
            if ( ! $deduct['success'] ) {
                return array( 'success' => false, 'message' => 'Wallet payment failed: ' . $deduct['message'] );
            }
        }

        $billing_id = $wpdb->insert( $wpdb->prefix . 'ridego_subscription_billing', array(
            'vendor_id'    => $vendor_id,
            'plan_id'      => $plan_id,
            'amount'       => (float) $plan->price,
            'status'       => 'success',
            'gateway_ref'  => 'wallet',
            'period_start' => date( 'Y-m-d', strtotime( $period_start ) ),
            'period_end'   => date( 'Y-m-d', strtotime( $period_end ) ),
            'attempts'     => 1,
            'created_at'   => current_time( 'mysql' ),
        ) ) ? $wpdb->insert_id : 0;

        ridego_activate_vendor_subscription( $vendor_id, $plan, $period_end );

        ridego_audit_log( 'subscription_purchased', 'vendor', $vendor_id, '', $plan->name . ' via wallet' );

        return array( 'success' => true, 'message' => 'Subscribed to ' . $plan->name . ' via wallet.', 'billing_id' => $billing_id );
    }

    if ( $payment_method === 'razorpay' ) {
        $billing_id = $wpdb->insert( $wpdb->prefix . 'ridego_subscription_billing', array(
            'vendor_id'    => $vendor_id,
            'plan_id'      => $plan_id,
            'amount'       => (float) $plan->price,
            'status'       => 'pending',
            'gateway_ref'  => '',
            'period_start' => date( 'Y-m-d', strtotime( $period_start ) ),
            'period_end'   => date( 'Y-m-d', strtotime( $period_end ) ),
            'attempts'     => 0,
            'created_at'   => current_time( 'mysql' ),
        ) ) ? $wpdb->insert_id : 0;

        if ( ! $billing_id ) {
            return array( 'success' => false, 'message' => 'Could not create billing record.' );
        }

        $order = ridego_create_subscription_razorpay_order( $vendor_id, $plan, $billing_id );
        if ( isset( $order['error'] ) ) {
            $wpdb->update( $wpdb->prefix . 'ridego_subscription_billing', array( 'status' => 'failed' ), array( 'id' => $billing_id ) );
            return array( 'success' => false, 'message' => 'Could not create payment order: ' . $order['error'] );
        }

        // Store the Razorpay order id so the webhook can be matched back to
        // this billing row even before a payment id exists.
        $wpdb->update( $wpdb->prefix . 'ridego_subscription_billing', array( 'gateway_ref' => $order['id'] ?? '' ), array( 'id' => $billing_id ) );

        return array( 'success' => true, 'message' => 'Payment order created — awaiting confirmation.', 'billing_id' => $billing_id, 'order' => $order );
    }

    return array( 'success' => false, 'message' => 'Unsupported payment method.' );
}

/**
 * Create a Razorpay order for a subscription charge, tagging notes so the
 * webhook handler (includes/api.php) can route it to the subscription
 * activation path instead of the booking-payment path.
 */
function ridego_create_subscription_razorpay_order( $vendor_id, $plan, $billing_id ) {
    $key_id     = get_option( 'ridego_razorpay_key_id' );
    $key_secret = get_option( 'ridego_razorpay_key_secret' );
    if ( empty( $key_id ) || empty( $key_secret ) ) {
        return array( 'error' => 'Razorpay not configured' );
    }

    $data = array(
        'amount'   => (float) $plan->price * 100, // paise
        'currency' => 'INR',
        'receipt'  => 'sub_' . $billing_id,
        'notes'    => array(
            'type'       => 'subscription_charge',
            'billing_id' => $billing_id,
            'vendor_id'  => $vendor_id,
            'plan_id'    => $plan->id,
        ),
    );

    $response = wp_remote_post( 'https://api.razorpay.com/v1/orders', array(
        'headers' => array(
            'Authorization' => 'Basic ' . base64_encode( $key_id . ':' . $key_secret ),
            'Content-Type'  => 'application/json',
        ),
        'body'    => wp_json_encode( $data ),
        'timeout' => 30,
    ) );

    if ( is_wp_error( $response ) ) {
        return array( 'error' => $response->get_error_message() );
    }
    $body = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( isset( $body['error'] ) ) {
        return array( 'error' => $body['error']['description'] ?? 'Unknown Razorpay error' );
    }
    return $body;
}

/**
 * Apply a plan's perks to a vendor record: plan_id, expiry, status=active,
 * and credit any wallet_credits the plan grants. Called both from the
 * immediate wallet-purchase path and from the webhook confirmation path —
 * never from the client-side redirect alone.
 */
function ridego_activate_vendor_subscription( $vendor_id, $plan, $period_end ) {
    global $wpdb;
    $wpdb->update( $wpdb->prefix . 'ridego_vendors', array(
        'subscription_plan_id'          => (int) $plan->id,
        'subscription_expires'          => $period_end,
        'subscription_status'           => 'active',
        'subscription_renewal_attempts' => 0,
    ), array( 'id' => (int) $vendor_id ) );

    if ( (float) $plan->wallet_credits > 0 ) {
        // ROOT-CAUSE FIX: this used to ignore the return value entirely — the exact same "ghost success"
        // pattern found and fixed in ridego_cancel_booking() (includes/booking.php): if the credit failed,
        // the subscription still activated successfully while the vendor's bonus silently vanished, with
        // nothing to retry it and nothing surfacing the failure. Now falls back to the same durable job
        // queue (includes/jobs.php) on failure, exactly like the cancellation path does.
        $bonus_reason = 'Subscription bonus: ' . $plan->name;
        $credit = ridego_vendor_credit_wallet( $vendor_id, (float) $plan->wallet_credits, null, $bonus_reason, 'subscription_credit' );
        if ( function_exists( 'ridego_ensure_wallet_credit' ) ) {
            ridego_ensure_wallet_credit( $credit, $vendor_id, (float) $plan->wallet_credits, null, $bonus_reason );
        }
    }

    ridego_queue_notification( ridego_vendor_user_id( $vendor_id ), 'subscription_activated', array(
        'plan_name' => $plan->name,
        'expires'   => $period_end,
    ) );

    do_action( 'ridego_subscription_activated', $vendor_id, $plan->id );
}

function ridego_vendor_user_id( $vendor_id ) {
    $v = ridego_get_vendor( $vendor_id );
    return $v ? (int) $v->user_id : 0;
}

/**
 * Called from the Razorpay webhook (payment.captured, notes.type ===
 * 'subscription_charge') once payment is confirmed server-side. Marks the
 * billing row 'success' and activates the plan. Idempotent: if the billing
 * row is already 'success' this is a no-op (mirrors the webhook idempotency
 * pattern from Wave 2B).
 */
function ridego_process_subscription_webhook_payment( $billing_id, $payment_id ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_subscription_billing';
    $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id=%d", (int) $billing_id ) );
    if ( ! $row ) { return false; }
    if ( $row->status === 'success' ) { return true; } // already processed

    $plan = ridego_get_subscription_plan( $row->plan_id );
    if ( ! $plan ) { return false; }

    $wpdb->update( $tbl, array(
        'status'      => 'success',
        'gateway_ref' => $payment_id,
        'attempts'    => (int) $row->attempts + 1,
    ), array( 'id' => $row->id ) );

    $period_end = date( 'Y-m-d H:i:s', strtotime( $row->period_end . ' 23:59:59' ) );
    ridego_activate_vendor_subscription( $row->vendor_id, $plan, $period_end );

    ridego_log_transaction( array(
        'type'       => 'subscription_charge',
        'amount'     => (float) $row->amount,
        'vendor_id'  => $row->vendor_id,
        'gateway'    => 'razorpay',
        'gateway_ref'=> $payment_id,
        'status'     => 'success',
        'notes'      => 'Subscription payment for plan #' . $row->plan_id,
    ) );

    ridego_audit_log( 'subscription_purchased', 'vendor', $row->vendor_id, '', $plan->name . ' via razorpay' );

    return true;
}

/**
 * Cancel a vendor's subscription. No proration/refund in this pass — just
 * stops perks and future renewal attempts, and records why.
 */
function ridego_cancel_vendor_subscription( $vendor_id, $reason = '' ) {
    global $wpdb;
    $vendor = ridego_get_vendor( $vendor_id );
    if ( ! $vendor ) { return array( 'success' => false, 'message' => 'Vendor not found.' ); }

    $wpdb->update( $wpdb->prefix . 'ridego_vendors', array(
        'subscription_status' => 'cancelled',
    ), array( 'id' => (int) $vendor_id ) );

    ridego_audit_log( 'subscription_cancelled', 'vendor', $vendor_id, $vendor->subscription_status, 'cancelled', 'info' );
    if ( $reason ) {
        ridego_audit_log( 'subscription_cancel_reason', 'vendor', $vendor_id, '', sanitize_textarea_field( $reason ) );
    }
    do_action( 'ridego_subscription_cancelled', $vendor_id, $reason );

    return array( 'success' => true, 'message' => 'Subscription cancelled.' );
}

/* ============================================================
   RENEWAL AUTOMATION + DUNNING
   ------------------------------------------------------------
   Registered as a daily cron hook from includes/cron.php
   ('ridego_subscription_renewal_check'), following the same
   pattern as Wave 2C's document-expiry cron.
   ============================================================ */
define( 'RIDEGO_SUBSCRIPTION_MAX_DUNNING_ATTEMPTS', 3 );

function ridego_run_subscription_renewal_check() {
    global $wpdb;
    $vtbl = $wpdb->prefix . 'ridego_vendors';

    /* ---- 1. Vendors expiring within the next 3 days: attempt renewal. ---- */
    $soon = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$vtbl}
         WHERE subscription_status='active'
         AND subscription_plan_id IS NOT NULL
         AND subscription_expires IS NOT NULL
         AND subscription_expires <= DATE_ADD(NOW(), INTERVAL 3 DAY)
         AND subscription_expires >= NOW()"
    ) );

    foreach ( $soon as $vendor ) {
        ridego_attempt_subscription_renewal( $vendor );
    }

    /* ---- 2. Vendors already past expiry with no successful renewal:
       expire the subscription (status='expired', plan_id=NULL) so perks
       stop applying, unless they are still within their dunning attempt
       budget (handled by attempt_renewal above bumping the counter — once
       attempts exceed the max AND we're past expiry, we expire here). ---- */
    $expired = $wpdb->get_results(
        "SELECT * FROM {$vtbl}
         WHERE subscription_status IN ('active','past_due')
         AND subscription_expires IS NOT NULL
         AND subscription_expires < NOW()"
    );

    foreach ( $expired as $vendor ) {
        // One last renewal attempt if dunning budget remains.
        if ( (int) $vendor->subscription_renewal_attempts < RIDEGO_SUBSCRIPTION_MAX_DUNNING_ATTEMPTS ) {
            $renewed = ridego_attempt_subscription_renewal( $vendor );
            if ( $renewed ) { continue; }
        }

        $wpdb->update( $vtbl, array(
            'subscription_status'  => 'expired',
            'subscription_plan_id' => null,
        ), array( 'id' => $vendor->id ) );

        ridego_audit_log( 'subscription_expired', 'vendor', $vendor->id, $vendor->subscription_status, 'expired' );
        ridego_queue_notification( (int) $vendor->user_id, 'subscription_expired', array(
            'vendor_id' => $vendor->id,
        ) );
        do_action( 'ridego_subscription_expired', $vendor->id );
    }
}
add_action( 'ridego_subscription_renewal_check', 'ridego_run_subscription_renewal_check' );

/**
 * Attempt to auto-renew one vendor's subscription: wallet-first, falling
 * back to a "payment required" notification (dunning) if the wallet
 * balance is insufficient. Tracks attempts on both the vendor row
 * (subscription_renewal_attempts, used by the expiry decision above) and
 * on a fresh ridego_subscription_billing row per attempt.
 *
 * @return bool true if the subscription was actually renewed.
 */
function ridego_attempt_subscription_renewal( $vendor ) {
    global $wpdb;
    $plan = ridego_get_subscription_plan( $vendor->subscription_plan_id );
    if ( ! $plan || ! $plan->is_active ) {
        return false;
    }

    $attempt = (int) $vendor->subscription_renewal_attempts + 1;
    $period_start = current_time( 'mysql' );
    $period_end   = ridego_subscription_period_end( $plan->billing_cycle, $vendor->subscription_expires );

    $deduct = (float) $plan->price <= 0
        ? array( 'success' => true )
        : ridego_vendor_deduct_wallet( $vendor->id, (float) $plan->price, null, 'Subscription renewal: ' . $plan->name, 'subscription_renewal' );

    $wpdb->insert( $wpdb->prefix . 'ridego_subscription_billing', array(
        'vendor_id'    => $vendor->id,
        'plan_id'      => $plan->id,
        'amount'       => (float) $plan->price,
        'status'       => $deduct['success'] ? 'success' : 'failed',
        'gateway_ref'  => 'wallet',
        'period_start' => date( 'Y-m-d', strtotime( $period_start ) ),
        'period_end'   => date( 'Y-m-d', strtotime( $period_end ) ),
        'attempts'     => $attempt,
        'created_at'   => current_time( 'mysql' ),
    ) );

    if ( $deduct['success'] ) {
        $wpdb->update( $wpdb->prefix . 'ridego_vendors', array(
            'subscription_plan_id'          => $plan->id,
            'subscription_expires'          => $period_end,
            'subscription_status'           => 'active',
            'subscription_renewal_attempts' => 0,
        ), array( 'id' => $vendor->id ) );

        ridego_audit_log( 'subscription_renewed', 'vendor', $vendor->id, '', $plan->name . ' (attempt ' . $attempt . ')' );
        do_action( 'ridego_subscription_renewed', $vendor->id, $plan->id );
        return true;
    }

    // Dunning: mark past_due, bump attempt counter, notify. Only expires
    // once the caller's loop finds it past subscription_expires AND out
    // of attempts (see ridego_run_subscription_renewal_check()).
    $wpdb->update( $wpdb->prefix . 'ridego_vendors', array(
        'subscription_status'           => 'past_due',
        'subscription_renewal_attempts' => $attempt,
    ), array( 'id' => $vendor->id ) );

    ridego_audit_log( 'subscription_renewal_failed', 'vendor', $vendor->id, '', 'attempt ' . $attempt . ': ' . ( $deduct['message'] ?? 'insufficient wallet balance' ), 'warning' );
    ridego_queue_notification( (int) $vendor->user_id, 'subscription_payment_required', array(
        'vendor_id' => $vendor->id,
        'attempt'   => $attempt,
    ) );

    return false;
}
