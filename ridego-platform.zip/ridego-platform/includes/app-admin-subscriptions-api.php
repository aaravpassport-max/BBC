<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Phase B, wave 26: subscription plans
   ------------------------------------------------------------
   Covers admin/pages/subscriptions.php in full: plan list with
   real usage data (active subscriber count + MRR per plan, copied
   verbatim from the legacy page's own per-plan query loop), create/
   update plan, the dashboard KPIs (active subscribers, MRR, 30-day
   churn rate, 30-day cancelled/expired count), the list of currently
   active subscriptions, and the admin-initiated cancel action
   (delegating entirely to the existing ridego_cancel_vendor_
   subscription() — no cancellation logic reimplemented here).

   Every query is copied verbatim from admin/pages/subscriptions.php,
   including the MRR normalization (yearly /12, quarterly /3) and the
   30-day churn-rate formula. Schema confirmed directly against
   includes/install.php's CREATE TABLE for ridego_subscription_plans
   — every column referenced (name, price, billing_cycle,
   wallet_credits, lead_discount, priority_boost, max_leads,
   features, is_active) genuinely exists.

   No canonical "create/update plan" helper exists — the legacy page
   does its own $wpdb->update()/$wpdb->insert() inline, so this REST
   layer does the same rather than inventing a shared function this
   wave didn't ask for.

   Every route requires is_user_logged_in() AND
   ridego_can('ridego_manage_subscriptions') — the exact capability
   admin/pages/subscriptions.php already requires.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_subscriptions_api_routes' );
function ridego_register_app_admin_subscriptions_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/subscriptions/plans', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_subscriptions_plans_list',
        'permission_callback' => 'ridego_app_admin_api_subscriptions_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/subscriptions/plans', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_subscriptions_plan_create',
        'permission_callback' => 'ridego_app_admin_api_subscriptions_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/subscriptions/plans/(?P<id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_subscriptions_plan_update',
        'permission_callback' => 'ridego_app_admin_api_subscriptions_permission',
        'args'                => array( 'id' => array( 'validate_callback' => function ( $v ) { return is_numeric( $v ); } ) ),
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/subscriptions/active', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_subscriptions_active',
        'permission_callback' => 'ridego_app_admin_api_subscriptions_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/subscriptions/cancel/(?P<vendor_id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_subscriptions_cancel',
        'permission_callback' => 'ridego_app_admin_api_subscriptions_permission',
        'args'                => array( 'vendor_id' => array( 'validate_callback' => function ( $v ) { return is_numeric( $v ); } ) ),
    ) );
}

function ridego_app_admin_api_subscriptions_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_subscriptions' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage subscriptions.', array( 'status' => 403 ) );
    }
    return true;
}

/**
 * Per-plan active-subscriber count + MRR, copied verbatim from
 * admin/pages/subscriptions.php:31-41 (including the yearly/12,
 * quarterly/3 MRR normalization).
 */
function ridego_app_admin_api_subscriptions_plan_usage( $plan ) {
    global $wpdb;
    $vtbl = $wpdb->prefix . 'ridego_vendors';

    $active_count = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$vtbl} WHERE subscription_plan_id=%d AND subscription_status='active' AND (subscription_expires IS NULL OR subscription_expires>=NOW())",
        $plan->id
    ) );
    $mrr = $active_count * (float) $plan->price;
    if ( $plan->billing_cycle === 'yearly' ) { $mrr = $mrr / 12; }
    elseif ( $plan->billing_cycle === 'quarterly' ) { $mrr = $mrr / 3; }

    return array( 'active' => $active_count, 'mrr' => $mrr );
}

function ridego_app_admin_api_subscriptions_plan_format( $p, $usage ) {
    return array(
        'id'             => (int) $p->id,
        'name'           => $p->name,
        'price'          => (float) $p->price,
        'billing_cycle'  => $p->billing_cycle,
        'wallet_credits' => (float) $p->wallet_credits,
        'lead_discount'  => (float) $p->lead_discount,
        'priority_boost' => (int) $p->priority_boost,
        'max_leads'      => (int) $p->max_leads,
        'features'       => $p->features,
        'is_active'      => (bool) $p->is_active,
        'active_subscribers' => $usage['active'],
        'mrr'                => $usage['mrr'],
    );
}

/** Copied verbatim from admin/pages/subscriptions.php:26-53 (plans + dashboard KPIs). */
function ridego_app_admin_api_subscriptions_plans_list( WP_REST_Request $req ) {
    global $wpdb;
    $tbl  = $wpdb->prefix . 'ridego_subscription_plans';
    $vtbl = $wpdb->prefix . 'ridego_vendors';
    $atbl = $wpdb->prefix . 'ridego_audit_log';

    $plans = $wpdb->get_results( "SELECT * FROM $tbl ORDER BY price ASC" );

    $plan_usage = array();
    $total_mrr  = 0.0;
    $out_plans  = array();
    foreach ( $plans as $p ) {
        $usage = ridego_app_admin_api_subscriptions_plan_usage( $p );
        $plan_usage[ $p->id ] = $usage;
        $total_mrr += $usage['mrr'];
        $out_plans[] = ridego_app_admin_api_subscriptions_plan_format( $p, $usage );
    }

    $churned_30d = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$atbl} WHERE action IN ('subscription_cancelled','subscription_expired') AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)"
    );
    $active_subscribers_total = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$vtbl} WHERE subscription_status='active' AND subscription_plan_id IS NOT NULL"
    );
    $churn_rate = $active_subscribers_total > 0
        ? round( ( $churned_30d / max( 1, $active_subscribers_total + $churned_30d ) ) * 100, 1 )
        : 0;

    return rest_ensure_response( array(
        'plans' => $out_plans,
        'kpis'  => array(
            'active_subscribers' => $active_subscribers_total,
            'mrr'                => $total_mrr,
            'churn_rate_pct'     => $churn_rate,
            'churned_30d'        => $churned_30d,
        ),
    ) );
}

/**
 * Shared field-building for create/update — same field set and
 * sanitization as admin/pages/subscriptions.php:13.
 */
function ridego_app_admin_api_subscriptions_plan_fields( WP_REST_Request $req ) {
    return array(
        'name'           => sanitize_text_field( (string) $req->get_param( 'name' ) ),
        'price'          => (float) $req->get_param( 'price' ),
        'billing_cycle'  => sanitize_key( (string) ( $req->get_param( 'billing_cycle' ) ?: 'monthly' ) ),
        'wallet_credits' => (float) ( $req->get_param( 'wallet_credits' ) ?: 0 ),
        'lead_discount'  => (float) ( $req->get_param( 'lead_discount' ) ?: 0 ),
        'priority_boost' => absint( $req->get_param( 'priority_boost' ) ?: 0 ),
        'max_leads'      => absint( $req->get_param( 'max_leads' ) ?: 0 ),
        'features'       => sanitize_textarea_field( (string) $req->get_param( 'features' ) ),
        'is_active'      => $req->get_param( 'is_active' ) ? 1 : 0,
    );
}

function ridego_app_admin_api_subscriptions_plan_create( WP_REST_Request $req ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_subscription_plans';
    $data = ridego_app_admin_api_subscriptions_plan_fields( $req );
    if ( $data['name'] === '' ) {
        return new WP_Error( 'missing_name', 'Plan name is required.', array( 'status' => 400 ) );
    }
    $ok = $wpdb->insert( $tbl, $data );
    if ( $ok === false ) {
        return new WP_Error( 'create_failed', 'Could not create plan: ' . $wpdb->last_error, array( 'status' => 500 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'id' => (int) $wpdb->insert_id, 'message' => 'Plan created!' ) );
}

function ridego_app_admin_api_subscriptions_plan_update( WP_REST_Request $req ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_subscription_plans';
    $id  = (int) $req->get_param( 'id' );
    $data = ridego_app_admin_api_subscriptions_plan_fields( $req );
    if ( $data['name'] === '' ) {
        return new WP_Error( 'missing_name', 'Plan name is required.', array( 'status' => 400 ) );
    }
    $ok = $wpdb->update( $tbl, $data, array( 'id' => $id ) );
    if ( $ok === false ) {
        return new WP_Error( 'update_failed', 'Could not update plan: ' . $wpdb->last_error, array( 'status' => 500 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => 'Plan updated.' ) );
}

/** Copied verbatim from admin/pages/subscriptions.php:56-61 (currently active subscriptions). */
function ridego_app_admin_api_subscriptions_active( WP_REST_Request $req ) {
    global $wpdb;
    $vtbl = $wpdb->prefix . 'ridego_vendors';
    $tbl  = $wpdb->prefix . 'ridego_subscription_plans';

    $rows = $wpdb->get_results(
        "SELECT v.id,v.business_name,v.subscription_plan_id,v.subscription_expires,sp.name AS plan_name
         FROM {$vtbl} v LEFT JOIN {$tbl} sp ON sp.id=v.subscription_plan_id
         WHERE v.subscription_status='active' AND v.subscription_plan_id IS NOT NULL
         ORDER BY v.subscription_expires ASC LIMIT 50"
    );

    return rest_ensure_response( array(
        'rows' => array_map( function ( $r ) {
            return array(
                'vendor_id'             => (int) $r->id,
                'business_name'         => $r->business_name,
                'subscription_plan_id'  => $r->subscription_plan_id,
                'subscription_expires'  => $r->subscription_expires,
                'plan_name'             => $r->plan_name,
            );
        }, $rows ),
    ) );
}

/**
 * Admin-initiated cancellation — delegates entirely to the existing
 * ridego_cancel_vendor_subscription() (includes/subscriptions.php),
 * matching the legacy form's default reason text exactly. No refund
 * is issued, matching the legacy page's own confirm-dialog wording
 * ("No refund is issued") — this endpoint does not touch the wallet.
 */
function ridego_app_admin_api_subscriptions_cancel( WP_REST_Request $req ) {
    $vendor_id = (int) $req->get_param( 'vendor_id' );
    $reason    = sanitize_textarea_field( (string) ( $req->get_param( 'reason' ) ?: 'Admin cancellation via Subscriptions page' ) );

    if ( ! function_exists( 'ridego_cancel_vendor_subscription' ) ) {
        return new WP_Error( 'unavailable', 'Subscription cancellation is not available.', array( 'status' => 500 ) );
    }

    $r = ridego_cancel_vendor_subscription( $vendor_id, $reason );
    if ( empty( $r['success'] ) ) {
        return new WP_Error( 'cancel_failed', isset( $r['message'] ) ? $r['message'] : 'Cancellation failed.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( $r );
}
