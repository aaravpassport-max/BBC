<?php
/**
 * RideGo Platform - Promo Code System
 * 
 * Handles promo code creation, validation, and usage tracking:
 * - Percentage discounts
 * - Flat amount discounts
 * - First booking offers
 * - Referral codes
 * - Vehicle-specific promos
 * - Route-specific promos
 * - Usage limits and expiry
 * - User-specific restrictions
 * 
 * @package RideGo
 * @subpackage Promo
 * @version 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Validate and apply promo code
 * Called during booking to check if code is valid
 * 
 * @param string $code           Promo code
 * @param float  $subtotal       Booking subtotal
 * @param array  $booking_params Booking parameters
 * @param int    $user_id        User ID (0 for guest)
 * @return array Result with valid status and discount amount
 */
function ridego_validate_promo_code($code, $subtotal, $booking_params = array(), $user_id = 0) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_promo_codes';
    
    // Sanitize code
    $code = strtoupper(trim($code));
    
    if (empty($code)) {
        return array(
            'valid' => false,
            'error' => 'Promo code is required'
        );
    }
    
    // Get promo code from database
    $promo = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE code = %s LIMIT 1",
        $code
    ));
    
    if (!$promo) {
        return array(
            'valid' => false,
            'error' => 'Invalid promo code'
        );
    }
    
    // Check if active
    if (!$promo->is_active) {
        return array(
            'valid' => false,
            'error' => 'This promo code is no longer active'
        );
    }
    
    // Check expiry date
    if ($promo->expiry_date && strtotime($promo->expiry_date) < time()) {
        return array(
            'valid' => false,
            'error' => 'This promo code has expired'
        );
    }
    
    // Check start date
    if ($promo->start_date && strtotime($promo->start_date) > time()) {
        $start = date('M d, Y', strtotime($promo->start_date));
        return array(
            'valid' => false,
            'error' => "This promo code is valid from {$start}"
        );
    }
    
    // Check usage limit
    if ($promo->usage_limit > 0 && $promo->used_count >= $promo->usage_limit) {
        return array(
            'valid' => false,
            'error' => 'This promo code has reached its usage limit'
        );
    }
    
    // Check per-user usage limit
    if ($user_id > 0 && $promo->per_user_limit > 0) {
        $user_usage = ridego_get_user_promo_usage($user_id, $promo->id);
        if ($user_usage >= $promo->per_user_limit) {
            return array(
                'valid' => false,
                'error' => 'You have already used this promo code the maximum number of times'
            );
        }
    }
    
    // Check minimum booking amount
    if ($promo->min_booking_amount > 0 && $subtotal < $promo->min_booking_amount) {
        return array(
            'valid' => false,
            'error' => sprintf('Minimum booking amount: ₹%s', number_format($promo->min_booking_amount, 2))
        );
    }
    
    // Check first booking only restriction
    if ($promo->first_booking_only && $user_id > 0) {
        $booking_count = ridego_get_user_booking_count($user_id);
        if ($booking_count > 0) {
            return array(
                'valid' => false,
                'error' => 'This promo code is valid for first bookings only'
            );
        }
    }
    
    // Check vehicle type restriction
    if ($promo->vehicle_type_id && isset($booking_params['vehicle_type_id'])) {
        if ($promo->vehicle_type_id != $booking_params['vehicle_type_id']) {
            $vehicle = ridego_get_vehicle_type($promo->vehicle_type_id);
            return array(
                'valid' => false,
                'error' => "This promo code is valid for {$vehicle->name} only"
            );
        }
    }
    
    // Check route restriction
    if ($promo->route_specific) {
        $from_match = (!$promo->from_city || $promo->from_city === $booking_params['pickup_city']);
        $to_match = (!$promo->to_city || $promo->to_city === $booking_params['drop_city']);
        
        if (!$from_match || !$to_match) {
            return array(
                'valid' => false,
                'error' => 'This promo code is not valid for this route'
            );
        }
    }
    
    // Check trip type restriction
    if ($promo->trip_type && isset($booking_params['trip_type'])) {
        $allowed_types = maybe_unserialize($promo->trip_type);
        if (is_array($allowed_types) && !in_array($booking_params['trip_type'], $allowed_types)) {
            return array(
                'valid' => false,
                'error' => 'This promo code is not valid for this trip type'
            );
        }
    }
    
    // Check user type restriction (new vs returning)
    if ($promo->user_type && $user_id > 0) {
        $user_type = ridego_get_user_booking_count($user_id) > 0 ? 'returning' : 'new';
        if ($promo->user_type !== $user_type && $promo->user_type !== 'all') {
            return array(
                'valid' => false,
                'error' => "This promo code is valid for {$promo->user_type} users only"
            );
        }
    }
    
    // Check day of week restriction
    if ($promo->days_of_week) {
        $allowed_days = maybe_unserialize($promo->days_of_week);
        $journey_date = $booking_params['journey_date'] ?? date('Y-m-d');
        $day_of_week = strtolower(date('l', strtotime($journey_date)));
        
        if (is_array($allowed_days) && !in_array($day_of_week, $allowed_days)) {
            return array(
                'valid' => false,
                'error' => 'This promo code is not valid for the selected travel date'
            );
        }
    }
    
    // All validations passed - calculate discount
    $discount = ridego_calculate_promo_discount($promo, $subtotal);
    
    return array(
        'valid'           => true,
        'promo_id'        => $promo->id,
        'code'            => $promo->code,
        'discount_type'   => $promo->discount_type,
        'discount_value'  => $promo->discount_value,
        'discount_amount' => $discount,
        'description'     => $promo->description,
        'message'         => sprintf('Promo code applied! You saved ₹%s', number_format($discount, 2))
    );
}

/**
 * Calculate discount amount from promo
 * 
 * @param object $promo    Promo code object
 * @param float  $subtotal Booking subtotal
 * @return float Discount amount
 */
function ridego_calculate_promo_discount($promo, $subtotal) {
    
    $discount = 0;
    
    if ($promo->discount_type === 'percentage') {
        // Percentage discount
        $discount = round($subtotal * ($promo->discount_value / 100), 2);
        
        // Apply max discount cap
        if ($promo->max_discount > 0) {
            $discount = min($discount, $promo->max_discount);
        }
    } else {
        // Flat amount discount
        $discount = min($promo->discount_value, $subtotal);
    }
    
    return $discount;
}

/**
 * Record promo code usage
 * Called when booking is confirmed
 * 
 * @param int    $booking_id Booking ID
 * @param int    $promo_id   Promo code ID
 * @param int    $user_id    User ID
 * @param float  $discount   Discount amount applied
 * @return bool Success
 */
/**
 * Atomically redeem a promo code: combines the usage-limit / budget-cap
 * check and the used_count/total_discount_given increment into ONE
 * conditional UPDATE, so a validate-then-record race (two concurrent
 * bookings both pass ridego_validate_promo_code() while the promo has
 * exactly one redemption left) cannot both succeed. Root-cause fix for
 * Wave 2B Task 4.
 *
 * The whole thing (conditional UPDATE + usage INSERT) runs in one
 * transaction: if the usage INSERT fails (per-user single-use promo hit
 * concurrently — see the UNIQUE KEY (promo_id, user_id) added by
 * migration 002), the used_count increment is rolled back so the promo's
 * counters never drift from its actual redemptions.
 *
 * @param int    $booking_id
 * @param int    $promo_id
 * @param int    $user_id
 * @param float  $discount
 * @return array{success:bool, message?:string}
 */
function ridego_record_promo_usage($booking_id, $promo_id, $user_id, $discount) {
    global $wpdb;

    $promo_table = $wpdb->prefix . 'ridego_promo_codes';
    $usage_table = $wpdb->prefix . 'ridego_promo_usage';
    $promo_id    = absint($promo_id);
    $user_id     = absint($user_id);
    $discount    = floatval($discount);

    $wpdb->query('START TRANSACTION');

    // Lock the promo row and re-check per_user_limit / usage_limit / budget
    // under the lock so a concurrent redemption can't slip through between
    // ridego_validate_promo_code()'s earlier read and this write.
    $promo = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$promo_table} WHERE id=%d FOR UPDATE", $promo_id
    ));
    if (!$promo) {
        $wpdb->query('ROLLBACK');
        return array('success' => false, 'message' => 'Promo code no longer available.');
    }

    // ROOT-CAUSE FIX: this comment used to say the per_user_limit==1 case
    // (the common one — most promos are single-use-per-user) relied on "the
    // UNIQUE KEY (promo_id, user_id) added by migration 002" as a DB-level
    // backstop and only did this COUNT() check for per_user_limit > 1.
    // migration 002 actually adds that index via ridego_add_index_if_missing(),
    // which creates a plain, non-unique index (see its implementation below
    // — ridego_add_unique_index_if_missing() is the separate, differently-
    // named helper that adds a real UNIQUE constraint, and it was never
    // called for this table). So for the default per_user_limit=1 case,
    // NOTHING was structurally preventing reuse — a logged-in user could
    // redeem a "single use per user" promo repeatedly, up to the promo's
    // global usage cap. A real UNIQUE index isn't a safe fix here either:
    // guest redemptions all carry user_id=0, so a unique (promo_id, user_id)
    // constraint would let a promo be used by only one guest ever. The COUNT()
    // check below, run under the same row lock as the atomic increment,
    // closes the gap for every per_user_limit value without that guest-
    // breaking side effect.
    if ($user_id > 0) {
        $limit = max(1, (int) $promo->per_user_limit);
        $existing = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$usage_table} WHERE promo_id=%d AND user_id=%d", $promo_id, $user_id
        ));
        if ($existing >= $limit) {
            $wpdb->query('ROLLBACK');
            return array('success' => false, 'message' => 'You have already used this promo code the maximum number of times.');
        }
    }

    // Atomic conditional increment: only succeeds if the promo is still
    // active, under its usage limit, and (if a budget cap is set) the new
    // total_discount_given would not exceed it.
    $sql = "UPDATE {$promo_table}
            SET used_count = used_count + 1, total_discount_given = total_discount_given + %f
            WHERE id=%d AND is_active=1
              AND (usage_limit = 0 OR used_count < usage_limit)
              AND (budget_cap IS NULL OR total_discount_given + %f <= budget_cap)";
    $wpdb->query($wpdb->prepare($sql, $discount, $promo_id, $discount));

    if ((int) $wpdb->rows_affected === 0) {
        $wpdb->query('ROLLBACK');
        return array('success' => false, 'message' => 'This promo code is no longer available (limit reached).');
    }

    // Insert the usage row (this is the row the COUNT() check above reads
    // back on the next redemption attempt — see the correction to that
    // check's comment above for why there is no DB-level unique
    // constraint doing this instead). A failed insert here (e.g. a
    // genuinely concurrent request for the same user racing past the
    // COUNT() check between its read and this write) rolls back the
    // usage-count increment above so counters stay consistent.
    $inserted = $wpdb->insert($usage_table, array(
        'promo_id'   => $promo_id,
        'booking_id' => absint($booking_id),
        'user_id'    => $user_id,
        'discount'   => $discount,
        'used_at'    => current_time('mysql'),
        'ip_address' => ridego_get_client_ip()
    ), array('%d', '%d', '%d', '%f', '%s', '%s'));

    if (!$inserted) {
        $wpdb->query('ROLLBACK');
        return array('success' => false, 'message' => 'You have already used this promo code.');
    }

    $wpdb->query('COMMIT');
    return array('success' => true);
}

/**
 * Get user's promo code usage count
 * 
 * @param int $user_id  User ID
 * @param int $promo_id Promo code ID
 * @return int Usage count
 */
function ridego_get_user_promo_usage($user_id, $promo_id) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_promo_usage';
    
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND promo_id = %d",
        $user_id,
        $promo_id
    ));
    
    return (int) $count;
}

/**
 * Get user's total booking count
 * 
 * @param int $user_id User ID
 * @return int Booking count
 */
function ridego_get_user_booking_count($user_id) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_bookings';
    
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} 
         WHERE client_id = %d 
         AND status IN ('confirmed', 'completed')",
        $user_id
    ));
    
    return (int) $count;
}

/**
 * Create new promo code
 * 
 * @param array $data Promo code data
 * @return int|bool Promo ID or false
 */
function ridego_create_promo_code($data) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_promo_codes';
    
    // Generate code if not provided
    if (empty($data['code'])) {
        $data['code'] = ridego_generate_promo_code();
    }
    
    // Sanitize code
    $data['code'] = strtoupper(trim($data['code']));
    
    // Check if code already exists
    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE code = %s",
        $data['code']
    ));
    
    if ($exists) {
        return false; // Code already exists
    }
    
    // Insert promo code
    $inserted = $wpdb->insert($table, array(
        'code'                => $data['code'],
        'description'         => sanitize_text_field($data['description'] ?? ''),
        'discount_type'       => sanitize_text_field($data['discount_type'] ?? 'percentage'),
        'discount_value'      => floatval($data['discount_value'] ?? 0),
        'max_discount'        => floatval($data['max_discount'] ?? 0),
        'min_booking_amount'  => floatval($data['min_booking_amount'] ?? 0),
        'usage_limit'         => absint($data['usage_limit'] ?? 0),
        'per_user_limit'      => absint($data['per_user_limit'] ?? 1),
        'first_booking_only'  => isset($data['first_booking_only']) ? 1 : 0,
        'vehicle_type_id'     => absint($data['vehicle_type_id'] ?? 0),
        'route_specific'      => isset($data['route_specific']) ? 1 : 0,
        'from_city'           => sanitize_text_field($data['from_city'] ?? ''),
        'to_city'             => sanitize_text_field($data['to_city'] ?? ''),
        'trip_type'           => isset($data['trip_type']) ? maybe_serialize($data['trip_type']) : null,
        'user_type'           => sanitize_text_field($data['user_type'] ?? 'all'),
        'days_of_week'        => isset($data['days_of_week']) ? maybe_serialize($data['days_of_week']) : null,
        'start_date'          => !empty($data['start_date']) ? sanitize_text_field($data['start_date']) : null,
        'expiry_date'         => !empty($data['expiry_date']) ? sanitize_text_field($data['expiry_date']) : null,
        'is_active'           => isset($data['is_active']) ? 1 : 1,
        'created_by'          => absint($data['created_by'] ?? get_current_user_id()),
        'created_at'          => current_time('mysql')
    ), array(
        '%s', '%s', '%s', '%f', '%f', '%f', '%d', '%d', '%d', '%d', '%d',
        '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s'
    ));
    
    if ($inserted) {
        return $wpdb->insert_id;
    }
    
    return false;
}

/**
 * Update promo code
 * 
 * @param int   $promo_id Promo code ID
 * @param array $data     Updated data
 * @return bool Success
 */
function ridego_update_promo_code($promo_id, $data) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_promo_codes';
    
    $update_data = array();
    $format = array();
    
    // Only update provided fields
    $allowed_fields = array(
        'description', 'discount_type', 'discount_value', 'max_discount',
        'min_booking_amount', 'usage_limit', 'per_user_limit',
        'first_booking_only', 'vehicle_type_id', 'route_specific',
        'from_city', 'to_city', 'trip_type', 'user_type', 'days_of_week',
        'start_date', 'expiry_date', 'is_active'
    );
    
    foreach ($allowed_fields as $field) {
        if (isset($data[$field])) {
            switch ($field) {
                case 'discount_value':
                case 'max_discount':
                case 'min_booking_amount':
                    $update_data[$field] = floatval($data[$field]);
                    $format[] = '%f';
                    break;
                    
                case 'usage_limit':
                case 'per_user_limit':
                case 'vehicle_type_id':
                case 'first_booking_only':
                case 'route_specific':
                case 'is_active':
                    $update_data[$field] = absint($data[$field]);
                    $format[] = '%d';
                    break;
                    
                case 'trip_type':
                case 'days_of_week':
                    $update_data[$field] = maybe_serialize($data[$field]);
                    $format[] = '%s';
                    break;
                    
                default:
                    $update_data[$field] = sanitize_text_field($data[$field]);
                    $format[] = '%s';
            }
        }
    }
    
    if (empty($update_data)) {
        return false;
    }
    
    $updated = $wpdb->update($table,
        $update_data,
        array('id' => $promo_id),
        $format,
        array('%d')
    );
    
    return $updated !== false;
}

/**
 * Delete promo code (soft delete - set inactive)
 * 
 * @param int $promo_id Promo code ID
 * @return bool Success
 */
function ridego_delete_promo_code($promo_id) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_promo_codes';
    
    $updated = $wpdb->update($table,
        array('is_active' => 0),
        array('id' => $promo_id),
        array('%d'),
        array('%d')
    );
    
    return $updated !== false;
}

/**
 * Get promo code by ID
 * 
 * @param int $promo_id Promo code ID
 * @return object|null Promo code object
 */
function ridego_get_promo_code($promo_id) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_promo_codes';
    
    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE id = %d",
        $promo_id
    ));
}

/**
 * Get all promo codes with filters
 * 
 * @param array $args Query arguments
 * @return array Promo codes
 */
function ridego_get_promo_codes($args = array()) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_promo_codes';
    
    $defaults = array(
        'status'     => 'all', // all, active, inactive, expired
        'orderby'    => 'created_at',
        'order'      => 'DESC',
        'limit'      => 50,
        'offset'     => 0,
        'search'     => ''
    );
    
    $args = wp_parse_args($args, $defaults);
    
    $where = array('1=1');
    
    // Filter by status
    if ($args['status'] === 'active') {
        $where[] = "is_active = 1";
        $where[] = "(expiry_date IS NULL OR expiry_date >= CURDATE())";
    } elseif ($args['status'] === 'inactive') {
        $where[] = "is_active = 0";
    } elseif ($args['status'] === 'expired') {
        $where[] = "expiry_date < CURDATE()";
    }
    
    // Search
    if (!empty($args['search'])) {
        $search = '%' . $wpdb->esc_like($args['search']) . '%';
        $where[] = $wpdb->prepare("(code LIKE %s OR description LIKE %s)", $search, $search);
    }
    
    $where_sql = implode(' AND ', $where);
    
    $query = "SELECT * FROM {$table} 
              WHERE {$where_sql} 
              ORDER BY {$args['orderby']} {$args['order']} 
              LIMIT {$args['limit']} OFFSET {$args['offset']}";
    
    return $wpdb->get_results($query);
}

/**
 * Get promo code usage statistics
 * 
 * @param int $promo_id Promo code ID
 * @return array Statistics
 */
function ridego_get_promo_stats($promo_id) {
    global $wpdb;
    
    $usage_table = $wpdb->prefix . 'ridego_promo_usage';
    
    // Total usage
    $total_uses = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$usage_table} WHERE promo_id = %d",
        $promo_id
    ));
    
    // Total discount given
    $total_discount = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(discount) FROM {$usage_table} WHERE promo_id = %d",
        $promo_id
    ));
    
    // Unique users
    $unique_users = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT user_id) FROM {$usage_table} WHERE promo_id = %d",
        $promo_id
    ));
    
    // Usage by date (last 30 days)
    $usage_by_date = $wpdb->get_results($wpdb->prepare(
        "SELECT DATE(used_at) as date, COUNT(*) as count, SUM(discount) as total_discount
         FROM {$usage_table}
         WHERE promo_id = %d
         AND used_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
         GROUP BY DATE(used_at)
         ORDER BY date DESC",
        $promo_id
    ), ARRAY_A);
    
    return array(
        'total_uses'      => (int) $total_uses,
        'total_discount'  => (float) $total_discount,
        'unique_users'    => (int) $unique_users,
        'usage_by_date'   => $usage_by_date
    );
}

/**
 * Generate random promo code
 * Format: RIDE-XXXX (4 random uppercase letters/numbers)
 * 
 * @return string Generated code
 */
function ridego_generate_promo_code() {
    
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Exclude confusing chars (I, O, 0, 1)
    $code = 'RIDE-';
    
    for ($i = 0; $i < 4; $i++) {
        $code .= $chars[random_int(0, strlen($chars) - 1)];
    }
    
    return $code;
}

/**
 * Generate referral code for user
 * Format: REF-USERNAME-XXX
 * 
 * @param int $user_id User ID
 * @return string Referral code
 */
function ridego_generate_referral_code($user_id) {
    
    $user = get_userdata($user_id);
    if (!$user) {
        return false;
    }
    
    $username = strtoupper(substr($user->user_login, 0, 6));
    $random = strtoupper(substr(md5($user_id . time()), 0, 3));
    
    return "REF-{$username}-{$random}";
}

/**
 * Get active promo codes for display (public)
 * Returns codes that are currently valid and public
 * 
 * @return array Active promo codes
 */
function ridego_get_public_promo_codes() {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_promo_codes';
    
    return $wpdb->get_results(
        "SELECT code, description, discount_type, discount_value, max_discount, 
                min_booking_amount, expiry_date
         FROM {$table}
         WHERE is_active = 1
         AND is_public = 1
         AND (expiry_date IS NULL OR expiry_date >= CURDATE())
         AND (usage_limit = 0 OR used_count < usage_limit)
         ORDER BY created_at DESC
         LIMIT 10"
    );
}

/**
 * Check if promo code is about to expire
 * Returns true if expires within 7 days
 * 
 * @param int $promo_id Promo code ID
 * @return bool Expiring soon
 */
function ridego_is_promo_expiring_soon($promo_id) {
    
    $promo = ridego_get_promo_code($promo_id);
    
    if (!$promo || !$promo->expiry_date) {
        return false;
    }
    
    $expiry = strtotime($promo->expiry_date);
    $days_remaining = ($expiry - time()) / (60 * 60 * 24);
    
    return $days_remaining <= 7 && $days_remaining > 0;
}

/**
 * AJAX: Validate promo code
 * Endpoint: wp-ajax-ridego_validate_promo
 */
function ridego_ajax_validate_promo_code() {

    check_ajax_referer('ridego_booking_nonce', 'nonce');

    // Guest-accessible (nopriv) endpoint — rate limit by IP to stop promo
    // code brute-forcing (Wave 2B Task 4). 20 attempts / 10 minutes.
    $rl = ridego_check_rate_limit('validate_promo', ridego_get_client_ip(), 20, 600);
    if (empty($rl['allowed'])) {
        wp_send_json_error(array('message' => $rl['error']));
    }

    $code = isset($_POST['promo_code']) ? sanitize_text_field($_POST['promo_code']) : '';
    $subtotal = isset($_POST['subtotal']) ? floatval($_POST['subtotal']) : 0;
    $user_id = get_current_user_id();
    
    $params = array(
        'vehicle_type_id' => isset($_POST['vehicle_type_id']) ? absint($_POST['vehicle_type_id']) : 0,
        'pickup_city'     => isset($_POST['pickup_city']) ? sanitize_text_field($_POST['pickup_city']) : '',
        'drop_city'       => isset($_POST['drop_city']) ? sanitize_text_field($_POST['drop_city']) : '',
        'trip_type'       => isset($_POST['trip_type']) ? sanitize_text_field($_POST['trip_type']) : 'one_way',
        'journey_date'    => isset($_POST['journey_date']) ? sanitize_text_field($_POST['journey_date']) : date('Y-m-d'),
    );
    
    $result = ridego_validate_promo_code($code, $subtotal, $params, $user_id);
    
    if ($result['valid']) {
        wp_send_json_success($result);
    } else {
        wp_send_json_error($result);
    }
}
add_action('wp_ajax_ridego_validate_promo_code', 'ridego_ajax_validate_promo_code');
add_action('wp_ajax_nopriv_ridego_validate_promo_code', 'ridego_ajax_validate_promo_code');

/**
 * AJAX: Get public promo codes
 * Endpoint: wp-ajax-ridego_get_public_promos
 */
function ridego_ajax_get_public_promos() {
    
    check_ajax_referer('ridego_booking_nonce', 'nonce');
    
    $promos = ridego_get_public_promo_codes();
    
    wp_send_json_success(array('promos' => $promos));
}
add_action('wp_ajax_ridego_get_public_promos', 'ridego_ajax_get_public_promos');
add_action('wp_ajax_nopriv_ridego_get_public_promos', 'ridego_ajax_get_public_promos');
