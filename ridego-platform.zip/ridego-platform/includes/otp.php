<?php
/**
 * RideGo Platform - OTP System
 * 
 * Handles OTP generation, verification, and rate limiting for:
 * - Phone number verification (booking, registration)
 * - Login/authentication
 * - Sensitive actions (wallet transactions, profile updates)
 * 
 * Economy-First Design:
 * - Minimizes SMS OTP usage (uses email/WhatsApp when possible)
 * - Session-based OTP for same-session re-requests (no repeat SMS)
 * - Cookie-based trusted device (90-day skip)
 * - Firebase Auth integration (10K free SMS/month)
 * 
 * Security Features:
 * - Rate limiting (max 3 OTPs per phone per hour)
 * - IP-based fraud detection
 * - 10-minute expiry
 * - Max 3 verification attempts
 * - Auto-cleanup of expired OTPs
 * 
 * @package RideGo
 * @subpackage OTP
 * @version 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate and send OTP to phone number
 * Routes to cheapest available channel (email → WhatsApp → SMS)
 * 
 * @param string $phone      Phone number with country code
 * @param string $purpose    OTP purpose: booking, login, verification, wallet
 * @param int    $user_id    User ID (0 for guest)
 * @param array  $options    Additional options (email, send_via, etc.)
 * @return array Success status and OTP ID or error message
 */
function ridego_generate_otp($phone, $purpose = 'verification', $user_id = 0, $options = array()) {
    
    // Validate phone number
    $phone = ridego_clean_phone_number($phone);
    if (!ridego_validate_phone_number($phone)) {
        return array(
            'success' => false,
            'error'   => 'Invalid phone number format'
        );
    }
    
    // Check rate limiting
    $rate_limit = ridego_check_otp_rate_limit($phone);
    if (!$rate_limit['allowed']) {
        return array(
            'success' => false,
            'error'   => $rate_limit['message'],
            'retry_after' => $rate_limit['retry_after']
        );
    }
    
    // Check if phone is in trusted device list (skip OTP)
    if (ridego_is_trusted_device($phone) && !isset($options['force'])) {
        return array(
            'success' => true,
            'trusted' => true,
            'message' => 'Trusted device - OTP skipped'
        );
    }
    
    // Generate 6-digit OTP
    $otp = ridego_generate_otp_code();
    
    // Calculate expiry (10 minutes from now)
    $expires_at = date('Y-m-d H:i:s', time() + 600);
    
    // Get client IP for fraud detection
    $ip_address = ridego_get_client_ip();
    
    // Store OTP in database
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_otp';
    
    // Root-cause fix: this used to store wp_hash($otp) — an HMAC meant for
    // nonces/cookies — while ridego_verify_otp() below checks the entered
    // code with wp_check_password(), which expects a password hash from
    // wp_hash_password(). The two are incompatible formats: wp_check_password()
    // can never successfully verify a wp_hash() value, so EVERY correct OTP
    // entry was silently rejected, burning an attempt each time, until the
    // user hit "Maximum verification attempts exceeded" after 3 tries —
    // meaning phone verification (and therefore booking creation, for any
    // phone not already trusted) has never actually worked. Hash with the
    // function wp_check_password() actually verifies against.
    $inserted = $wpdb->insert($table, array(
        'phone'        => $phone,
        'otp'          => wp_hash_password($otp), // Store hashed for security
        'otp_plain'    => $otp, // Temporary for sending (deleted after verification)
        'purpose'      => sanitize_text_field($purpose),
        'user_id'      => absint($user_id),
        'expires_at'   => $expires_at,
        'attempts'     => 0,
        'verified'     => 0,
        'ip_address'   => sanitize_text_field($ip_address),
        'created_at'   => current_time('mysql'),
    ), array('%s', '%s', '%s', '%s', '%d', '%s', '%d', '%d', '%s', '%s'));
    
    if (!$inserted) {
        return array(
            'success' => false,
            'error'   => 'Failed to generate OTP. Please try again.'
        );
    }
    
    $otp_id = $wpdb->insert_id;
    
    // Determine sending channel based on cost optimization
    $send_channel = isset($options['send_via']) ? $options['send_via'] : 'auto';
    $sent = false;
    $channel_used = '';
    
    if ($send_channel === 'auto') {
        
        // Strategy: Try cheapest channels first
        
        // 1. EMAIL (if email provided and allowed) - FREE
        if (isset($options['email']) && is_email($options['email']) && get_option('ridego_otp_allow_email', true)) {
            $sent = ridego_send_otp_email($options['email'], $otp, $purpose);
            if ($sent) {
                $channel_used = 'email';
            }
        }
        
        // 2. WHATSAPP (if enabled) - FREE via CallMeBot/Fonnte
        if (!$sent && get_option('ridego_otp_allow_whatsapp', false)) {
            $message = ridego_build_otp_whatsapp_message($otp, $purpose);
            
            // Try Fonnte first
            if (get_option('ridego_fonnte_enabled')) {
                $sent = ridego_whatsapp_fonnte($phone, $message);
                if ($sent) {
                    $channel_used = 'whatsapp_fonnte';
                }
            }
            
            // Fallback to CallMeBot
            if (!$sent && get_option('ridego_callmebot_enabled')) {
                $sent = ridego_whatsapp_callmebot($phone, $message);
                if ($sent) {
                    $channel_used = 'whatsapp_callmebot';
                }
            }
        }
        
        // 3. SMS (last resort - costs money) - Firebase Auth or Fast2SMS
        if (!$sent) {
            $sent = ridego_send_otp_sms($phone, $otp);
            if ($sent) {
                $channel_used = 'sms';
            }
        }
        
    } else {
        // Specific channel requested
        switch ($send_channel) {
            case 'email':
                if (isset($options['email']) && is_email($options['email'])) {
                    $sent = ridego_send_otp_email($options['email'], $otp, $purpose);
                    $channel_used = 'email';
                }
                break;
                
            case 'whatsapp':
                $message = ridego_build_otp_whatsapp_message($otp, $purpose);
                $sent = ridego_whatsapp_fonnte($phone, $message) || ridego_whatsapp_callmebot($phone, $message);
                $channel_used = 'whatsapp';
                break;
                
            case 'sms':
                $sent = ridego_send_otp_sms($phone, $otp);
                $channel_used = 'sms';
                break;
        }
    }
    
    // Log the OTP generation
    ridego_log_otp_event($otp_id, 'generated', array(
        'channel' => $channel_used,
        'sent'    => $sent,
        'purpose' => $purpose,
        'ip'      => $ip_address
    ));
    
    if (!$sent) {
        /* Root-cause fix: this used to tell the user to "use a different
           verification method" — but the channel (email → WhatsApp → SMS)
           is chosen automatically above with no user-facing picker anywhere
           in the app; there is no alternate method for the user to switch
           to. When every configured channel fails the honest, actionable
           message is to retry the same phone number, not to point at a
           feature that doesn't exist. */
        return array(
            'success' => false,
            'error'   => 'Could not send the OTP right now. Please check the phone number and try again in a few minutes.'
        );
    }
    
    return array(
        'success'    => true,
        'otp_id'     => $otp_id,
        'expires_in' => 600, // seconds
        'channel'    => $channel_used,
        'message'    => "OTP sent successfully via {$channel_used}"
    );
}

/**
 * Generate and send an OTP to an EMAIL address — the independent Email
 * OTP Verification channel, parallel to ridego_generate_otp() above but
 * keyed by email instead of phone (migration 044 adds the `email`
 * column to wp_ridego_otp for exactly this). Kept as a separate
 * function rather than folding into ridego_generate_otp() because the
 * two channels have different validation (is_email vs phone format),
 * different rate-limit keys, and — per the admin settings — are
 * switched on/off completely independently; sharing the table and the
 * hashing/attempt/expiry mechanics is enough to avoid real duplication.
 *
 * @param string $email   Email address.
 * @param string $purpose OTP purpose: booking, login, verification, wallet.
 * @param int    $user_id User ID (0 for guest).
 * @return array Success status and OTP ID or error message.
 */
function ridego_generate_email_otp( $email, $purpose = 'verification', $user_id = 0 ) {

    $email = sanitize_email( $email );
    if ( ! is_email( $email ) ) {
        return array(
            'success' => false,
            'error'   => 'Invalid email address.',
        );
    }

    $rate_limit = ridego_check_email_otp_rate_limit( $email );
    if ( ! $rate_limit['allowed'] ) {
        return array(
            'success'     => false,
            'error'       => $rate_limit['message'],
            'retry_after' => $rate_limit['retry_after'],
        );
    }

    if ( ridego_is_trusted_email( $email ) ) {
        return array(
            'success' => true,
            'trusted' => true,
            'message' => 'Trusted device - OTP skipped',
        );
    }

    $otp        = ridego_generate_otp_code();
    $expires_at = date( 'Y-m-d H:i:s', time() + 600 );
    $ip_address = ridego_get_client_ip();

    global $wpdb;
    $table = $wpdb->prefix . 'ridego_otp';

    $inserted = $wpdb->insert( $table, array(
        'phone'      => '',
        'email'      => $email,
        'otp'        => wp_hash_password( $otp ),
        'otp_plain'  => $otp,
        'purpose'    => sanitize_text_field( $purpose ),
        'user_id'    => absint( $user_id ),
        'expires_at' => $expires_at,
        'attempts'   => 0,
        'verified'   => 0,
        'ip_address' => sanitize_text_field( $ip_address ),
        'created_at' => current_time( 'mysql' ),
    ), array( '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%d', '%s', '%s' ) );

    if ( ! $inserted ) {
        return array(
            'success' => false,
            'error'   => 'Failed to generate OTP. Please try again.',
        );
    }

    $otp_id = $wpdb->insert_id;

    // Reuses the exact same email-sending path phone OTP already relies
    // on for its email channel (ridego_send_otp_email() ->
    // ridego_send_email_notification($email, 'otp_request', ...)) — no
    // new delivery mechanism.
    $sent = ridego_send_otp_email( $email, $otp, $purpose );

    ridego_log_otp_event( $otp_id, 'generated', array(
        'channel' => 'email',
        'sent'    => $sent,
        'purpose' => $purpose,
        'ip'      => $ip_address,
    ) );

    if ( ! $sent ) {
        return array(
            'success' => false,
            'error'   => 'Could not send the OTP right now. Please check the email address and try again in a few minutes.',
        );
    }

    return array(
        'success'    => true,
        'otp_id'     => $otp_id,
        'expires_in' => 600,
        'channel'    => 'email',
        'message'    => 'OTP sent successfully via email',
    );
}

/**
 * Verify an email OTP code. Parallel to ridego_verify_otp() above but
 * looks the row up by email instead of phone.
 *
 * @param string $email    Email address.
 * @param string $otp_code OTP code entered by user.
 * @param string $purpose  OTP purpose (must match).
 * @return array Success status and message.
 */
function ridego_verify_email_otp( $email, $otp_code, $purpose = 'verification' ) {

    global $wpdb;
    $table = $wpdb->prefix . 'ridego_otp';

    $email    = sanitize_email( $email );
    $otp_code = preg_replace( '/[^0-9]/', '', $otp_code );

    if ( strlen( $otp_code ) !== 6 ) {
        return array(
            'success' => false,
            'error'   => 'Invalid OTP format. Please enter 6 digits.',
        );
    }

    $otp_record = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$table}
         WHERE email = %s
         AND purpose = %s
         AND verified = 0
         AND expires_at > NOW()
         ORDER BY created_at DESC
         LIMIT 1",
        $email,
        $purpose
    ) );

    if ( ! $otp_record ) {
        return array(
            'success' => false,
            'error'   => 'OTP expired or not found. Please request a new OTP.',
        );
    }

    if ( $otp_record->attempts >= 3 ) {
        ridego_log_otp_event( $otp_record->id, 'max_attempts', array(
            'attempts' => $otp_record->attempts,
        ) );

        $wpdb->update( $table,
            array( 'verified' => -1 ),
            array( 'id' => $otp_record->id ),
            array( '%d' ),
            array( '%d' )
        );

        return array(
            'success' => false,
            'error'   => 'Maximum verification attempts exceeded. Please request a new OTP.',
        );
    }

    $wpdb->update( $table,
        array( 'attempts' => $otp_record->attempts + 1 ),
        array( 'id' => $otp_record->id ),
        array( '%d' ),
        array( '%d' )
    );

    if ( ! wp_check_password( $otp_code, $otp_record->otp ) ) {

        ridego_log_otp_event( $otp_record->id, 'failed_attempt', array(
            'attempt' => $otp_record->attempts + 1,
        ) );

        $remaining = 3 - ( $otp_record->attempts + 1 );

        return array(
            'success'            => false,
            'error'              => "Incorrect OTP. {$remaining} attempts remaining.",
            'remaining_attempts' => $remaining,
        );
    }

    $wpdb->update( $table,
        array(
            'verified'    => 1,
            'verified_at' => current_time( 'mysql' ),
            'verified_ip' => ridego_get_client_ip(),
        ),
        array( 'id' => $otp_record->id ),
        array( '%d', '%s', '%s' ),
        array( '%d' )
    );

    $wpdb->update( $table,
        array( 'otp_plain' => null ),
        array( 'id' => $otp_record->id ),
        array( '%s' ),
        array( '%d' )
    );

    ridego_log_otp_event( $otp_record->id, 'verified', array(
        'attempts_taken' => $otp_record->attempts + 1,
    ) );

    if ( get_option( 'ridego_otp_trust_device_enabled', true ) ) {
        ridego_trust_email( $email );
    }

    return array(
        'success' => true,
        'message' => 'Email verified successfully',
        'otp_id'  => $otp_record->id,
    );
}

/**
 * Email-OTP rate limiting — same shape as ridego_check_otp_rate_limit()
 * (3 per email per hour) but keyed by email instead of phone, so
 * exhausting phone-OTP requests never blocks an email-OTP attempt or
 * vice versa.
 *
 * @param string $email Email address.
 * @return array Allowed status and message.
 */
function ridego_check_email_otp_rate_limit( $email ) {

    global $wpdb;
    $table = $wpdb->prefix . 'ridego_otp';

    $email_count = $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$table}
         WHERE email = %s
         AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)",
        $email
    ) );

    if ( $email_count >= 3 ) {
        return array(
            'allowed'     => false,
            'message'     => 'Too many OTP requests for this email. Please try again after 1 hour.',
            'retry_after' => 3600,
        );
    }

    return array( 'allowed' => true );
}

/**
 * Root-cause fix: every "no valid OTP"/"max attempts exceeded" failure used
 * to unconditionally tell the user to "request a new OTP" — but a new send
 * shares the exact same phone-based rate limiter (ridego_check_otp_rate_limit(),
 * 3 requests/hour) as the OTP the user just exhausted their 3 verify attempts
 * on. A user who had already resent once or twice would hit "Please request
 * a new OTP", try to do exactly that, and immediately get "Too many OTP
 * requests... try again after 1 hour" — a verification failure promising a
 * fix that the system itself was about to refuse. This checks the real
 * rate-limit state first and only ever promises a next step the user can
 * actually take.
 *
 * @param string $phone   Phone number.
 * @param string $prefix  Optional sentence to prepend (e.g. the specific failure reason).
 * @return string A message whose suggested next step is guaranteed accurate.
 */
function ridego_otp_next_step_message( $phone, $prefix = '' ) {
    $rate = ridego_check_otp_rate_limit( $phone );
    $lead = $prefix ? $prefix . ' ' : '';
    if ( empty( $rate['allowed'] ) ) {
        $wait_minutes = ! empty( $rate['retry_after'] ) ? max( 1, (int) ceil( $rate['retry_after'] / 60 ) ) : 60;
        return $lead . "You've also reached the limit of OTP requests for this number. Please try again in about {$wait_minutes} minutes.";
    }
    return $lead . 'Please request a new OTP.';
}

/**
 * Verify OTP code
 *
 * @param string $phone     Phone number
 * @param string $otp_code  OTP code entered by user
 * @param string $purpose   OTP purpose (must match)
 * @return array Success status and message
 */
function ridego_verify_otp($phone, $otp_code, $purpose = 'verification') {
    
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_otp';
    
    // Clean inputs
    $phone = ridego_clean_phone_number($phone);
    $otp_code = preg_replace('/[^0-9]/', '', $otp_code);
    
    // Validate OTP format
    if (strlen($otp_code) !== 6) {
        return array(
            'success' => false,
            'error'   => 'Invalid OTP format. Please enter 6 digits.'
        );
    }
    
    // Find the most recent non-verified OTP for this phone and purpose
    $otp_record = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} 
         WHERE phone = %s 
         AND purpose = %s 
         AND verified = 0 
         AND expires_at > NOW()
         ORDER BY created_at DESC 
         LIMIT 1",
        $phone,
        $purpose
    ));
    
    if (!$otp_record) {
        return array(
            'success' => false,
            'error'   => ridego_otp_next_step_message( $phone )
        );
    }

    // Check if max attempts exceeded
    if ($otp_record->attempts >= 3) {
        ridego_log_otp_event($otp_record->id, 'max_attempts', array(
            'attempts' => $otp_record->attempts
        ));

        // Invalidate this OTP
        $wpdb->update($table,
            array('verified' => -1), // -1 = locked
            array('id' => $otp_record->id),
            array('%d'),
            array('%d')
        );

        return array(
            'success' => false,
            'error'   => ridego_otp_next_step_message( $phone, 'Maximum verification attempts exceeded.' )
        );
    }
    
    // Increment attempt counter
    $wpdb->update($table,
        array('attempts' => $otp_record->attempts + 1),
        array('id' => $otp_record->id),
        array('%d'),
        array('%d')
    );
    
    // Verify OTP (compare hashed)
    if (!wp_check_password($otp_code, $otp_record->otp)) {
        
        ridego_log_otp_event($otp_record->id, 'failed_attempt', array(
            'attempt' => $otp_record->attempts + 1
        ));
        
        $remaining = 3 - ($otp_record->attempts + 1);
        
        return array(
            'success' => false,
            'error'   => "Incorrect OTP. {$remaining} attempts remaining.",
            'remaining_attempts' => $remaining
        );
    }
    
    // OTP is correct - mark as verified
    $wpdb->update($table,
        array(
            'verified'     => 1,
            'verified_at'  => current_time('mysql'),
            'verified_ip'  => ridego_get_client_ip()
        ),
        array('id' => $otp_record->id),
        array('%d', '%s', '%s'),
        array('%d')
    );
    
    // Delete plain OTP for security (keep only hash)
    $wpdb->update($table,
        array('otp_plain' => null),
        array('id' => $otp_record->id),
        array('%s'),
        array('%d')
    );
    
    ridego_log_otp_event($otp_record->id, 'verified', array(
        'attempts_taken' => $otp_record->attempts + 1
    ));
    
    // Add to trusted devices if checkbox was checked
    if (get_option('ridego_otp_trust_device_enabled', true)) {
        ridego_add_trusted_device($phone);
    }
    
    return array(
        'success' => true,
        'message' => 'Phone number verified successfully',
        'otp_id'  => $otp_record->id
    );
}

/**
 * Resend OTP (same code, new expiry)
 * Rate limited to prevent abuse
 * 
 * @param string $phone   Phone number
 * @param string $purpose OTP purpose
 * @param array  $options Additional options
 * @return array Success status
 */
function ridego_resend_otp($phone, $purpose = 'verification', $options = array()) {
    
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_otp';
    
    $phone = ridego_clean_phone_number($phone);
    
    // Check resend rate limit (max 1 resend per 60 seconds)
    $recent_otp = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table}
         WHERE phone = %s
         AND created_at > DATE_SUB(NOW(), INTERVAL 60 SECOND)",
        $phone
    ));
    
    if ($recent_otp > 0) {
        return array(
            'success' => false,
            'error'   => 'Please wait 60 seconds before requesting a new OTP',
            'retry_after' => 60
        );
    }
    
    // Get the most recent OTP
    $otp_record = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table}
         WHERE phone = %s
         AND purpose = %s
         AND verified = 0
         ORDER BY created_at DESC
         LIMIT 1",
        $phone,
        $purpose
    ));
    
    if (!$otp_record || !$otp_record->otp_plain) {
        // No existing OTP or already used - generate new
        return ridego_generate_otp($phone, $purpose, 0, $options);
    }
    
    // Extend expiry of existing OTP
    $new_expiry = date('Y-m-d H:i:s', time() + 600);
    $wpdb->update($table,
        array('expires_at' => $new_expiry, 'attempts' => 0),
        array('id' => $otp_record->id),
        array('%s', '%d'),
        array('%d')
    );
    
    // Resend the same OTP
    $sent = false;
    $channel = isset($options['send_via']) ? $options['send_via'] : 'sms';
    
    if ($channel === 'email' && isset($options['email'])) {
        $sent = ridego_send_otp_email($options['email'], $otp_record->otp_plain, $purpose);
    } elseif ($channel === 'whatsapp') {
        $message = ridego_build_otp_whatsapp_message($otp_record->otp_plain, $purpose);
        $sent = ridego_whatsapp_fonnte($phone, $message) || ridego_whatsapp_callmebot($phone, $message);
    } else {
        $sent = ridego_send_otp_sms($phone, $otp_record->otp_plain);
    }
    
    ridego_log_otp_event($otp_record->id, 'resent', array('channel' => $channel));
    
    return array(
        'success' => $sent,
        'message' => $sent ? 'OTP resent successfully' : 'Failed to resend OTP',
        'otp_id'  => $otp_record->id,
        'expires_in' => 600
    );
}

/**
 * Check OTP rate limiting
 * Max 3 OTPs per phone per hour
 * Max 10 OTPs per IP per hour
 * 
 * @param string $phone Phone number
 * @return array Allowed status and message
 */
function ridego_check_otp_rate_limit($phone) {
    
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_otp';
    
    $phone = ridego_clean_phone_number($phone);
    $ip = ridego_get_client_ip();
    
    // Check phone-based limit (3 per hour)
    $phone_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table}
         WHERE phone = %s
         AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)",
        $phone
    ));
    
    if ($phone_count >= 3) {
        return array(
            'allowed'     => false,
            'message'     => 'Too many OTP requests for this number. Please try again after 1 hour.',
            'retry_after' => 3600
        );
    }
    
    // Check IP-based limit (10 per hour - prevents automated abuse)
    $ip_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table}
         WHERE ip_address = %s
         AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)",
        $ip
    ));
    
    if ($ip_count >= 10) {
        
        // Log potential abuse
        ridego_log_security_event('otp_abuse', array(
            'ip'    => $ip,
            'count' => $ip_count
        ));
        
        return array(
            'allowed'     => false,
            'message'     => 'Too many requests from this device. Please try again later.',
            'retry_after' => 3600
        );
    }
    
    return array(
        'allowed' => true
    );
}

/**
 * Generate 6-digit OTP code
 * Uses cryptographically secure random number generator
 * 
 * @return string 6-digit OTP
 */
function ridego_generate_otp_code() {
    
    // Use random_int for cryptographically secure random number
    $otp = random_int(100000, 999999);
    
    return (string) $otp;
}

/**
 * Validate phone number format
 * Accepts: +919876543210 or 9876543210
 * 
 * @param string $phone Phone number
 * @return bool Valid or not
 */
function ridego_validate_phone_number($phone) {
    
    // Remove all non-numeric characters except +
    $clean = preg_replace('/[^0-9+]/', '', $phone);
    
    // Should be 10-15 digits (with or without country code)
    $length = strlen(str_replace('+', '', $clean));
    
    if ($length < 10 || $length > 15) {
        return false;
    }
    
    return true;
}

/**
 * Clean phone number (standardize format)
 * Converts all formats to: +919876543210
 * 
 * @param string $phone Phone number
 * @return string Cleaned phone
 */
function ridego_clean_phone_number($phone) {
    
    // Remove all non-numeric except +
    $clean = preg_replace('/[^0-9+]/', '', $phone);
    
    // If doesn't start with +, add country code
    if (substr($clean, 0, 1) !== '+') {
        // Check if starts with 91 (India)
        if (substr($clean, 0, 2) === '91' && strlen($clean) === 12) {
            $clean = '+' . $clean;
        } else {
            // Add default country code (India)
            $clean = '+91' . $clean;
        }
    }
    
    return $clean;
}

/**
 * Check if device is trusted (skip OTP)
 *
 * ROOT-CAUSE FIX: this used to hash $phone directly (as passed in, already
 * normalized by ridego_clean_phone_number() to a leading-"+" form like
 * "+919876543210"), while ridego_is_trusted_phone() — the function every
 * security-relevant read site actually calls (the booking-submission
 * trust-skip check in public/ajax/booking-ajax.php, and
 * ridego_requester_verified_for_booking() in includes/helpers.php, which
 * gates booking cancellation/details/payment-proof-upload for a guest) —
 * strips to digits-only ("919876543210") before hashing. Two different
 * normalizations of the same real phone number produce two different
 * cookie names, so a cookie written by one was never found by the other:
 * "remember this device, skip OTP next time" never actually worked, and
 * a guest's freshly-verified phone was never recognized as trusted by
 * the ownership checks that matter. Fixed by delegating to the single
 * canonical implementation (ridego_is_trusted_phone() /
 * ridego_trust_phone(), in ridego-platform.php) instead of maintaining a
 * second, divergent cookie scheme here.
 *
 * @param string $phone Phone number
 * @return bool Is trusted
 */
function ridego_is_trusted_device($phone) {
    return ridego_is_trusted_phone($phone);
}

/**
 * Add device to trusted list. See ridego_is_trusted_device()'s doc
 * comment above for why this delegates to the canonical
 * ridego_trust_phone() rather than writing its own, incompatible cookie.
 *
 * @param string $phone Phone number
 * @return bool Success
 */
function ridego_add_trusted_device($phone) {
    if (!get_option('ridego_otp_trust_device_enabled', true)) {
        return false;
    }
    ridego_trust_phone($phone);
    return true;
}

/* Legacy body (unreachable, kept only so a diff of this fix is easy to
   review against the original — dead code below this line was removed):
function ridego_add_trusted_device_OLD($phone) {
    $cookie_name = 'ridego_trusted_' . md5($phone);
    $cookie_value = wp_hash($phone . NONCE_SALT);

    // Set cookie for 90 days
    $expiry = time() + (90 * 24 * 60 * 60);

    setcookie(
        $cookie_name,
        $cookie_value,
        $expiry,
        COOKIEPATH,
        COOKIE_DOMAIN,
        is_ssl(),
        true // HTTP only
    );

    return true;
}
*/

/**
 * Remove device from trusted list
 * 
 * @param string $phone Phone number
 * @return bool Success
 */
function ridego_remove_trusted_device($phone) {
    // Same cookie-naming fix as ridego_is_trusted_device() above: must use
    // the same digits-only normalization ridego_trust_phone() writes with,
    // or this clears a cookie that was never actually set.
    $clean = preg_replace('/[^0-9]/', '', $phone);
    $cookie_name = 'ridego_trusted_' . md5($clean);

    if (isset($_COOKIE[$cookie_name])) {
        setcookie($cookie_name, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
        unset($_COOKIE[$cookie_name]);
        return true;
    }

    return false;
}

/**
 * Send OTP via email
 * Free alternative to SMS
 * 
 * @param string $email   Email address
 * @param string $otp     OTP code
 * @param string $purpose Purpose
 * @return bool Success
 */
function ridego_send_otp_email($email, $otp, $purpose) {
    
    if (!is_email($email)) {
        return false;
    }
    
    $user_data = array(
        'name'  => 'User',
        'email' => $email
    );
    
    $data = array(
        'otp'     => $otp,
        'purpose' => $purpose
    );
    
    // Use notification system's email sender
    return ridego_send_email_notification($email, 'otp_request', $data, $user_data);
}

/**
 * Build WhatsApp OTP message
 * 
 * @param string $otp     OTP code
 * @param string $purpose Purpose
 * @return string Message text
 */
function ridego_build_otp_whatsapp_message($otp, $purpose) {
    
    $purpose_text = array(
        'booking'      => 'complete your booking',
        'login'        => 'login to your account',
        'verification' => 'verify your phone number',
        'wallet'       => 'confirm wallet transaction'
    );
    
    $text = isset($purpose_text[$purpose]) ? $purpose_text[$purpose] : 'verify your action';
    
    return "Your " . ridego_brand_name() . " OTP is: {$otp}\n\n" .
           "Use this code to {$text}.\n\n" .
           "Valid for 10 minutes. Do not share with anyone.\n\n" .
           "- " . ridego_brand( 'email_signature' );
}

/**
 * Get client IP address
 * Handles proxies and load balancers
 * 
 * @return string IP address
 */
function ridego_get_client_ip() {
    
    $ip = '';
    
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED'];
    } elseif (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_FORWARDED_FOR'];
    } elseif (isset($_SERVER['HTTP_FORWARDED'])) {
        $ip = $_SERVER['HTTP_FORWARDED'];
    } elseif (isset($_SERVER['REMOTE_ADDR'])) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    
    // Handle multiple IPs (take first)
    if (strpos($ip, ',') !== false) {
        $ips = explode(',', $ip);
        $ip = trim($ips[0]);
    }
    
    return sanitize_text_field($ip);
}

/**
 * Log OTP event to database
 * 
 * @param int    $otp_id OTP record ID
 * @param string $event  Event type
 * @param array  $data   Additional data
 */
function ridego_log_otp_event($otp_id, $event, $data = array()) {
    
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_otp_log';
    
    $wpdb->insert($table, array(
        'otp_id'     => absint($otp_id),
        'event'      => sanitize_text_field($event),
        'data'       => wp_json_encode($data),
        'ip_address' => ridego_get_client_ip(),
        'created_at' => current_time('mysql')
    ), array('%d', '%s', '%s', '%s', '%s'));
}

/**
 * Log security event (fraud detection).
 *
 * The canonical definition lives in includes/security.php (loaded after
 * this file). This used to be a second, divergent definition here — both
 * copies also wrote to columns ('event', 'data', 'user_agent') that don't
 * exist on the real ridego_security_log table (event_type, identifier,
 * details — see includes/migrations.php migration 002), so every call was
 * a silent no-op (wpdb->insert() just returns false on an unknown column,
 * it doesn't throw). Since PHP has no forward-declared functions, and this
 * file loads before security.php, calls to ridego_log_security_event()
 * from otp.php resolve correctly once security.php's require_once has run
 * (both happen during the single 'includes load' pass in
 * ridego-platform.php, before any hook fires that could call this).
 */

/**
 * Cleanup expired OTPs
 * Called by WP Cron daily
 * Deletes OTPs older than 24 hours
 */
function ridego_cleanup_expired_otps() {
    
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_otp';
    
    // Delete expired OTPs older than 24 hours
    $deleted = $wpdb->query(
        "DELETE FROM {$table}
         WHERE created_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)"
    );
    
    if ($deleted) {
        ridego_log("OTP Cleanup: Deleted {$deleted} expired OTP records");
    }
    
    // Delete old OTP logs (keep 30 days)
    $log_table = $wpdb->prefix . 'ridego_otp_log';
    $wpdb->query(
        "DELETE FROM {$log_table}
         WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)"
    );
}

/**
 * Get OTP statistics for admin dashboard
 * 
 * @param string $period Period: today, week, month
 * @return array Statistics
 */
function ridego_get_otp_stats($period = 'today') {
    
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_otp';
    
    $date_filter = '';
    switch ($period) {
        case 'today':
            $date_filter = "DATE(created_at) = CURDATE()";
            break;
        case 'week':
            $date_filter = "created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
            break;
        case 'month':
            $date_filter = "created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            break;
        default:
            $date_filter = "1=1";
    }
    
    // Total OTPs generated
    $total = $wpdb->get_var(
        "SELECT COUNT(*) FROM {$table} WHERE {$date_filter}"
    );
    
    // Verified OTPs
    $verified = $wpdb->get_var(
        "SELECT COUNT(*) FROM {$table} WHERE {$date_filter} AND verified = 1"
    );
    
    // Failed verifications (max attempts)
    $failed = $wpdb->get_var(
        "SELECT COUNT(*) FROM {$table} WHERE {$date_filter} AND verified = -1"
    );
    
    // Expired OTPs
    $expired = $wpdb->get_var(
        "SELECT COUNT(*) FROM {$table} WHERE {$date_filter} AND verified = 0 AND expires_at < NOW()"
    );
    
    // By purpose
    $by_purpose = $wpdb->get_results(
        "SELECT purpose, COUNT(*) as count 
         FROM {$table} 
         WHERE {$date_filter}
         GROUP BY purpose",
        ARRAY_A
    );
    
    // Success rate
    $success_rate = $total > 0 ? round(($verified / $total) * 100, 2) : 0;
    
    return array(
        'total'        => (int) $total,
        'verified'     => (int) $verified,
        'failed'       => (int) $failed,
        'expired'      => (int) $expired,
        'pending'      => (int) ($total - $verified - $failed - $expired),
        'success_rate' => $success_rate,
        'by_purpose'   => $by_purpose
    );
}

/**
 * Validate OTP session (check if recently verified)
 * Used to allow actions within X minutes of OTP verification
 * 
 * @param string $phone   Phone number
 * @param string $purpose Purpose
 * @param int    $minutes Valid for how many minutes
 * @return bool Valid session
 */
function ridego_validate_otp_session($phone, $purpose, $minutes = 30) {
    
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_otp';
    
    $phone = ridego_clean_phone_number($phone);
    
    $recent_verification = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table}
         WHERE phone = %s
         AND purpose = %s
         AND verified = 1
         AND verified_at > DATE_SUB(NOW(), INTERVAL %d MINUTE)",
        $phone,
        $purpose,
        $minutes
    ));
    
    return $recent_verification > 0;
}

/**
 * Invalidate all OTPs for a phone number
 * Used when phone number is changed or account is compromised
 * 
 * @param string $phone Phone number
 * @return int Number of OTPs invalidated
 */
function ridego_invalidate_phone_otps($phone) {
    
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_otp';
    
    $phone = ridego_clean_phone_number($phone);
    
    $updated = $wpdb->update($table,
        array('verified' => -1), // -1 = invalidated
        array('phone' => $phone, 'verified' => 0),
        array('%d'),
        array('%s', '%d')
    );
    
    // Also remove from trusted devices
    ridego_remove_trusted_device($phone);
    
    return (int) $updated;
}

/**
 * AJAX handler: Generate OTP
 * Endpoint: wp-ajax-ridego_generate_otp
 */
function ridego_ajax_generate_otp() {
    
    // Verify nonce for security
    check_ajax_referer('ridego_otp_nonce', 'nonce');
    
    $phone   = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    $purpose = isset($_POST['purpose']) ? sanitize_text_field($_POST['purpose']) : 'verification';
    $email   = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    
    if (empty($phone)) {
        wp_send_json_error(array('message' => 'Phone number is required'));
    }
    
    $options = array();
    if (!empty($email)) {
        $options['email'] = $email;
    }
    
    $result = ridego_generate_otp($phone, $purpose, 0, $options);
    
    if ($result['success']) {
        wp_send_json_success($result);
    } else {
        wp_send_json_error($result);
    }
}
add_action('wp_ajax_ridego_generate_otp', 'ridego_ajax_generate_otp');
add_action('wp_ajax_nopriv_ridego_generate_otp', 'ridego_ajax_generate_otp');

/**
 * AJAX handler: Verify OTP
 * Endpoint: wp-ajax-ridego_verify_otp
 */
function ridego_ajax_verify_otp() {
    
    // Verify nonce
    check_ajax_referer('ridego_otp_nonce', 'nonce');
    
    $phone   = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    $otp     = isset($_POST['otp']) ? sanitize_text_field($_POST['otp']) : '';
    $purpose = isset($_POST['purpose']) ? sanitize_text_field($_POST['purpose']) : 'verification';
    
    if (empty($phone) || empty($otp)) {
        wp_send_json_error(array('message' => 'Phone number and OTP are required'));
    }
    
    $result = ridego_verify_otp($phone, $otp, $purpose);
    
    if ($result['success']) {
        wp_send_json_success($result);
    } else {
        wp_send_json_error($result);
    }
}
add_action('wp_ajax_ridego_verify_otp', 'ridego_ajax_verify_otp');
add_action('wp_ajax_nopriv_ridego_verify_otp', 'ridego_ajax_verify_otp');

/**
 * AJAX handler: Resend OTP
 * Endpoint: wp-ajax-ridego_resend_otp
 */
function ridego_ajax_resend_otp() {
    
    // Verify nonce
    check_ajax_referer('ridego_otp_nonce', 'nonce');
    
    $phone   = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    $purpose = isset($_POST['purpose']) ? sanitize_text_field($_POST['purpose']) : 'verification';
    $email   = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    
    if (empty($phone)) {
        wp_send_json_error(array('message' => 'Phone number is required'));
    }
    
    $options = array();
    if (!empty($email)) {
        $options['email'] = $email;
    }
    
    $result = ridego_resend_otp($phone, $purpose, $options);
    
    if ($result['success']) {
        wp_send_json_success($result);
    } else {
        wp_send_json_error($result);
    }
}
add_action('wp_ajax_ridego_resend_otp', 'ridego_ajax_resend_otp');
add_action('wp_ajax_nopriv_ridego_resend_otp', 'ridego_ajax_resend_otp');

/**
 * Schedule OTP cleanup cron job
 * Runs daily
 */
function ridego_schedule_otp_cleanup() {
    
    if (!wp_next_scheduled('ridego_cleanup_expired_otps')) {
        wp_schedule_event(time(), 'daily', 'ridego_cleanup_expired_otps');
    }
}
add_action('wp', 'ridego_schedule_otp_cleanup');

/**
 * Hook cleanup function to cron
 */
add_action('ridego_cleanup_expired_otps', 'ridego_cleanup_expired_otps');

/**
 * Unschedule cleanup on plugin deactivation
 */
function ridego_unschedule_otp_cleanup() {
    $timestamp = wp_next_scheduled('ridego_cleanup_expired_otps');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'ridego_cleanup_expired_otps');
    }
}
register_deactivation_hook(RIDEGO_PATH . 'ridego-platform.php', 'ridego_unschedule_otp_cleanup');
