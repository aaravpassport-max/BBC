<?php
/**
 * Facilitator payment model.
 *
 * RideGo is a booking facilitator. It collects ONLY the booking amount (a fixed amount or a percentage of the estimated ride fare, set in Settings).
 * The vendor/driver fulfils the ride, bills the client, collects the remaining amount and any other applicable charges, and issues the ride invoice/receipt.
 *
 * Column meaning on ridego_bookings (platform_model = 1):
 *   total_fare        estimated ride fare (what the vendor/driver is expected to bill)
 *   token_amount      booking amount RideGo collects (snapshot at creation)
 *   advance_paid      booking amount actually received by RideGo, net of refunds
 *   vendor_collected  ride balance the vendor/driver reports having collected from the client
 *   balance_due       ride balance still to be collected by the vendor/driver = total_fare − token_amount − vendor_collected
 * Legacy bookings (platform_model = 0, no token) keep their old meaning: RideGo collected the whole fare online.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: nothing → the default client/vendor/receipt wording used until an admin overrides it in Settings → array of strings. Pure.
function ridego_platform_default_texts() {
    return array(
        'token_label'        => 'Booking amount',
        'token_instructions' => '{brand} collects only this booking amount to confirm your ride. It is part of your ride fare, not an extra charge. The remaining fare, the final bill and any other applicable charges (for example tolls, parking, waiting time, extra distance or taxes) are settled directly with your vendor/driver, who issues your ride invoice or receipt. It is refundable if {brand} cannot arrange your ride; once a vendor/driver has been arranged it is non-refundable if you cancel or do not travel.',
        'disclaimer_client'  => '{brand} is a booking platform that connects you with independent vendors and drivers. {brand} does not sell, bill or collect the full ride fare and only collects the booking amount shown. The vendor/driver is responsible for providing the ride, billing you, and collecting the remaining amount and any other applicable charges directly from you. The fare shown before the trip is an estimate; the final amount is confirmed by the vendor/driver.',
        'disclaimer_vendor'  => 'You are responsible for fulfilling the ride, billing the client, collecting the remaining amount and any other applicable charges directly from the client, and issuing the ride invoice or receipt (including any applicable taxes). {brand} charges you a vendor lead fee for the trip under the commercial terms you have accepted; it is calculated centrally and shown on the lead and the booking. If the client paid a booking amount to {brand}, that amount is adjusted against your lead fee. {brand} does not collect or remit the ride balance.',
        'disclaimer_receipt' => 'This is a receipt for the booking amount collected by {brand} only. It is not the invoice for the ride. The ride invoice or receipt is issued by the vendor/driver, who collects the remaining amount directly from you.',
    );
}

// TRACE: setting key (one of the default-text keys) → the admin-edited text, or the default when blank → string. Edge cases: unknown key → ''.
function ridego_platform_text( $key ) {
    $d = ridego_platform_default_texts();
    if ( ! isset( $d[ $key ] ) ) { return ''; }
    $v = trim( (string) ridego_get_setting( $key, '' ) );
    return ridego_brand_expand( $v !== '' ? $v : $d[ $key ] );
}

// TRACE: nothing → the wording the SPA shows on booking, confirmation, receipt, tracking, vendor and terms screens → array(booking_amount_label, booking_amount_note, client, vendor, receipt).
function ridego_platform_notices() {
    return array( 'booking_amount_label' => ridego_platform_text( 'token_label' ), 'booking_amount_note' => ridego_platform_text( 'token_instructions' ),
        'client' => ridego_platform_text( 'disclaimer_client' ), 'vendor' => ridego_platform_text( 'disclaimer_vendor' ), 'receipt' => ridego_platform_text( 'disclaimer_receipt' ) );
}

// TRACE: estimated ride fare → the booking amount RideGo collects → float rounded to 2 dp.
//        Mode 'percent' = booking_amount_percent % of the fare, otherwise the fixed token_amount. Then booking_amount_min / booking_amount_max (0 = no limit) apply, and the result
//        is capped at the fare itself. This is the CUSTOMER advance only; the vendor lead fee is separate (lead-fee.php). Switch customer_advance_enabled off → 0. Preconditions: none. Edge cases: fare ≤ 0 → 0; percent outside 0-100 is clamped; min above max → max wins.
function ridego_booking_amount_for( $total ) {
    $total = max( 0.0, (float) $total );
    if ( $total <= 0 ) { return 0.0; }
    // The customer advance is its own switch (Settings → Booking amount). Off → clients pay RideGo nothing up front; the vendor lead fee is unaffected (it is calculated in lead-fee.php).
    if ( function_exists( 'ridego_lead_fee_options' ) && ! ridego_lead_fee_options()['customer_advance_enabled'] ) { return 0.0; }
    if ( (string) ridego_get_setting( 'booking_amount_mode', 'fixed' ) === 'percent' ) {
        $pct = max( 0.0, min( 100.0, (float) ridego_get_setting( 'booking_amount_percent', 10 ) ) );
        $amt = $total * $pct / 100;
    } else {
        $amt = max( 0.0, (float) ridego_get_setting( 'token_amount', 500 ) );
    }
    $min = max( 0.0, (float) ridego_get_setting( 'booking_amount_min', 0 ) );
    $max = max( 0.0, (float) ridego_get_setting( 'booking_amount_max', 0 ) );
    if ( $min > 0 ) { $amt = max( $amt, $min ); }
    if ( $max > 0 ) { $amt = min( $amt, $max ); }
    return round( min( $amt, $total ), 2 );
}

// TRACE: booking row → the amount RideGo is due to collect for it → float. platform_model bookings: the snapshot token_amount (may be 0 when waived);
//        legacy bookings: token_amount when > 0, otherwise the whole fare (the pre-facilitator behaviour). Pure.
function ridego_booking_platform_amount( $b ) {
    if ( ! $b ) { return 0.0; }
    if ( ! empty( $b->platform_model ) ) { return round( (float) $b->token_amount, 2 ); }
    return (float) $b->token_amount > 0 ? round( (float) $b->token_amount, 2 ) : round( (float) $b->total_fare, 2 );
}

// TRACE: booking row → one consistent money summary used by every API (client, vendor, admin, receipt) → array. Pure.
//        estimated_ride_fare = total_fare; booking_amount = what RideGo collects; booking_amount_paid = advance_paid (net of refunds); booking_amount_pending = still to collect;
//        payable_to_vendor = fare − booking amount; vendor_collected = reported by the vendor/driver; vendor_outstanding = the rest; collection_status = none|pending|partly_collected|settled.
//        Cancelled/expired bookings owe nothing to the vendor. Edge cases: paid more than due (never negative pending), fare 0.
function ridego_booking_financials( $b ) {
    if ( ! $b ) { return array(); }
    $fare = round( (float) $b->total_fare, 2 );
    $due = ridego_booking_platform_amount( $b );
    $paid = max( 0.0, round( (float) $b->advance_paid, 2 ) );
    $closed = in_array( $b->status, array( 'cancelled', 'expired', 'token_refund_due' ), true );
    $payable = $closed ? 0.0 : max( 0.0, round( $fare - $due, 2 ) );
    $collected = min( $payable, max( 0.0, round( (float) ( $b->vendor_collected ?? 0 ), 2 ) ) );
    $outstanding = max( 0.0, round( $payable - $collected, 2 ) );
    $status = $payable <= 0.004 ? 'none' : ( $outstanding <= 0.004 ? 'settled' : ( $collected > 0 ? 'partly_collected' : 'pending' ) );
    return array( 'platform_model' => ! empty( $b->platform_model ), 'estimated_ride_fare' => $fare, 'booking_amount' => $due, 'booking_amount_paid' => $paid,
        'booking_amount_pending' => $closed ? 0.0 : max( 0.0, round( $due - $paid, 2 ) ), 'payable_to_vendor' => $payable, 'vendor_collected' => $collected, 'vendor_outstanding' => $outstanding,
        'collection_status' => $status,  'vendor_invoice_number' => (string) ( $b->vendor_invoice_number ?? '' ), 'vendor_collected_at' => $b->vendor_collected_at ?? null );
}

// TRACE: nothing → the methods a vendor/driver or admin can report the ride balance was collected by → array of keys. Pure.
function ridego_vendor_collection_methods() { return array( 'cash', 'upi', 'bank_transfer', 'card', 'cheque', 'other' ); }

// TRACE: booking id + amount + method + reference + note + actor type (vendor|admin) + actor user id + vendor's own invoice number → records that the vendor/driver COLLECTED part or all
//        of the ride balance from the client → array(success,message,vendor_collected,vendor_outstanding).
//        This is informational bookkeeping about money that never passes through RideGo: it writes a 'vendor_collection' ledger row (excluded from RideGo's received total), bumps
//        vendor_collected, recomputes balance_due, queues a client notification and is audit-logged.
//        Preconditions: booking exists, has a vendor, is not cancelled/expired/refund-due, amount > 0 and ≤ vendor_outstanding, method valid. Postconditions: nothing changes on refusal.
//        Edge cases: legacy booking that was paid in full online (nothing payable), unknown booking, no vendor, over-collection, repeat click (second call is refused once settled).
function ridego_booking_record_vendor_collection( $booking_id, $amount, $method, $reference, $note, $actor_type, $actor_id, $vendor_invoice = '' ) {
    global $wpdb;
    $b = ridego_get_booking( (int) $booking_id );
    if ( ! $b ) { return array( 'success' => false, 'message' => 'Booking not found.' ); }
    if ( empty( $b->vendor_id ) ) { return array( 'success' => false, 'message' => 'No vendor is assigned to this booking yet.' ); }
    if ( in_array( $b->status, array( 'cancelled', 'expired', 'token_refund_due' ), true ) ) { return array( 'success' => false, 'message' => 'This booking is cancelled.' ); }
    $method = sanitize_key( (string) $method );
    if ( ! in_array( $method, ridego_vendor_collection_methods(), true ) ) { return array( 'success' => false, 'message' => 'Choose how the amount was collected.' ); }
    $amount = round( (float) $amount, 2 );
    if ( $amount <= 0 ) { return array( 'success' => false, 'message' => 'Enter an amount greater than zero.' ); }
    $fin = ridego_booking_financials( $b );
    if ( $fin['payable_to_vendor'] <= 0.004 ) { return array( 'success' => false, 'message' => 'Nothing is payable to the vendor on this booking: the full fare was paid through ' . ridego_brand_name() . '.' ); }
    if ( $amount > $fin['vendor_outstanding'] + 0.004 ) { return array( 'success' => false, 'message' => 'That is more than the remaining ride balance (₹' . number_format( $fin['vendor_outstanding'], 2 ) . '). If the client paid extra charges such as tolls or waiting time, note them in the trip notes instead.' ); }
    $by = $actor_type === 'admin' ? 'Recorded by ' . ridego_brand_name() . ' admin on the vendor\'s behalf' : 'Recorded by vendor/driver';
    $ok = ridego_booking_payment_row( (int) $booking_id, 'vendor_collection', $amount, $method, $reference, trim( $by . '. ' . (string) $note ), (int) $actor_id );
    if ( ! $ok ) { ridego_log( 'vendor_collection insert failed: ' . $wpdb->last_error ); return array( 'success' => false, 'message' => 'Could not record the collection. Please try again.' ); }
    $upd = array( 'vendor_collected' => round( (float) $b->vendor_collected + $amount, 2 ), 'vendor_collected_at' => current_time( 'mysql' ), 'updated_at' => current_time( 'mysql' ) );
    $inv = mb_substr( sanitize_text_field( (string) $vendor_invoice ), 0, 60 );
    if ( $inv !== '' ) { $upd['vendor_invoice_number'] = $inv; }
    $wpdb->update( "{$wpdb->prefix}ridego_bookings", $upd, array( 'id' => (int) $booking_id ) );
    ridego_booking_recalculate_payment( (int) $booking_id );
    $after = ridego_get_booking( (int) $booking_id );
    $fa = ridego_booking_financials( $after );
    ridego_audit_log( 'vendor_collection_recorded', 'booking', (int) $booking_id, '', $actor_type . ' ' . $amount . ' ' . $method );
    ridego_admin_notify_client( $after, 'vendor_collection_recorded', array( 'amount' => $amount, 'balance' => $fa['vendor_outstanding'], 'method' => $method ) );
    return array( 'success' => true, 'message' => 'Recorded ₹' . number_format( $amount, 2 ) . ' collected from the client.', 'vendor_collected' => $fa['vendor_collected'], 'vendor_outstanding' => $fa['vendor_outstanding'], 'collection_status' => $fa['collection_status'] );
}

// TRACE: booking row → the money fields every API response carries under the facilitator model → array. Pure.
//        Existing keys keep their names so older screens do not break: total_fare (estimated ride fare), advance_paid (booking amount received by RideGo), balance_due (ride balance still to be
//        collected by the vendor/driver; for legacy whole-fare bookings, fare − paid). New keys: booking_amount, booking_amount_paid, booking_amount_pending, estimated_ride_fare, payable_to_vendor,
//        vendor_collected, vendor_outstanding, collection_status, vendor_invoice_number, platform_model.
function ridego_booking_money_fields( $b ) {
    $f = ridego_booking_financials( $b );
    if ( ! $f ) { return array(); }
    $balance = ! empty( $b->platform_model ) ? $f['vendor_outstanding'] : max( 0.0, round( (float) $b->total_fare - (float) $b->advance_paid, 2 ) );
    if ( in_array( $b->status, array( 'cancelled', 'expired', 'token_refund_due' ), true ) ) { $balance = 0.0; }
    return array( 'total_fare' => (float) $b->total_fare, 'advance_paid' => (float) $b->advance_paid, 'balance_due' => $balance ) + $f;
}

add_action( 'rest_api_init', 'ridego_platform_register_public_routes' );
// TRACE: rest_api_init → registers public GET /ridego/v1/app/platform-notices → 200 {booking_amount_label, booking_amount_note, client, vendor, receipt} (wording only, no personal data).
function ridego_platform_register_public_routes() {
    register_rest_route( 'ridego/v1', '/app/platform-notices', array( 'methods' => 'GET', 'callback' => 'ridego_platform_notices_endpoint', 'permission_callback' => '__return_true' ) );
}

// TRACE: GET platform-notices → ridego_platform_notices() wrapped in a REST response. Pure read.
function ridego_platform_notices_endpoint() {
    return rest_ensure_response( ridego_platform_notices() );
}
