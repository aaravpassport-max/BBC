<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Client Dashboard API (Phase 5). Every route requires a
   logged-in user and scopes every query by b.client_id = current user, so a
   client can never read or act on another client's booking. The driver's
   phone number is exposed only once the driver is en route or the trip has
   started.
   ================================================================ */

// TRACE: permission callback → logged in → true | WP_Error 401.
function ridego_client_dash_permission() {
    return is_user_logged_in() ? true : new WP_Error( 'not_logged_in', 'Please log in.', array( 'status' => 401 ) );
}

add_action( 'rest_api_init', 'ridego_register_app_client_dashboard_routes' );
// TRACE: rest_api_init → registers dashboard routes → void.
function ridego_register_app_client_dashboard_routes() {
    $routes = array(
        array( '/app/client/home', 'GET', 'ridego_client_dash_home' ),
        array( '/app/client/trips', 'GET', 'ridego_client_dash_trips' ),
        array( '/app/client/trips/(?P<id>\d+)', 'GET', 'ridego_client_dash_trip' ),
        array( '/app/client/trips/(?P<id>\d+)/invoice', 'GET', 'ridego_client_dash_invoice' ),
        array( '/app/client/trips/(?P<id>\d+)/rate', 'POST', 'ridego_client_dash_rate' ),
        array( '/app/client/support', 'GET', 'ridego_client_dash_support_list' ),
        array( '/app/client/support', 'POST', 'ridego_client_dash_support_create' ),
        array( '/app/client/addresses', 'GET', 'ridego_client_dash_addresses' ),
        array( '/app/client/addresses', 'POST', 'ridego_client_dash_address_save' ),
        array( '/app/client/addresses/(?P<id>[a-f0-9]{8})', 'DELETE', 'ridego_client_dash_address_delete' ),
    );
    foreach ( $routes as $r ) {
        register_rest_route( 'ridego/v1', $r[0], array( 'methods' => $r[1], 'callback' => $r[2], 'permission_callback' => 'ridego_client_dash_permission' ) );
    }
}

// TRACE: booking row + viewer → compact client-safe array for lists (no vendor internals) → array.
function ridego_client_dash_serialize( $b ) {
    return array(
        'id' => (int) $b->id, 'booking_number' => $b->booking_number, 'status' => $b->status, 'status_label' => ridego_get_booking_status_label( $b->status ),
        'group' => ridego_booking_status_group( $b->status ), 'pickup_city' => $b->pickup_city, 'drop_city' => $b->drop_city, 'journey_date' => $b->journey_date,
        'journey_time' => $b->journey_time, 'trip_type' => $b->trip_type, 'payment_status' => $b->payment_status,
        'rating' => isset( $b->rating_by_client ) && $b->rating_by_client !== null ? (int) $b->rating_by_client : null,
        'attention' => ridego_client_needs_attention( $b ), 'created_at' => $b->created_at,
    ) + ridego_booking_money_fields( $b );
}

// TRACE: GET home → tab counts, next upcoming trip, attention items, 5 recent trips, open complaints count →
//        response. Scoped to the current user. Edge cases: no bookings (zero counts, null next trip).
function ridego_client_dash_home( WP_REST_Request $req ) {
    global $wpdb;
    $uid = get_current_user_id(); $bt = $wpdb->prefix . 'ridego_bookings';
    $counts = array( 'upcoming' => 0, 'ongoing' => 0, 'completed' => 0, 'cancelled' => 0 );
    foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT status, COUNT(*) c FROM {$bt} WHERE client_id=%d GROUP BY status", $uid ), ARRAY_A ) as $r ) {
        $counts[ ridego_booking_status_group( $r['status'] ) ] += (int) $r['c'];
    }
    $up = ridego_booking_group_statuses( 'upcoming' ) . '|' . ridego_booking_group_statuses( 'ongoing' );
    $ph = implode( ',', array_fill( 0, count( explode( '|', $up ) ), '%s' ) );
    $next = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$bt} WHERE client_id=%d AND status IN ({$ph}) AND status<>'no_vendor' ORDER BY journey_date ASC, journey_time ASC LIMIT 1", array_merge( array( $uid ), explode( '|', $up ) ) ) );
    $recent = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$bt} WHERE client_id=%d ORDER BY created_at DESC LIMIT 5", $uid ) );
    $attention = array();
    foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$bt} WHERE client_id=%d AND (status IN ('pending','pending_payment','payment_pending','token_refund_due') OR (status='completed' AND rating_by_client IS NULL)) ORDER BY created_at DESC LIMIT 10", $uid ) ) as $b ) {
        foreach ( ridego_client_needs_attention( $b ) as $a ) { $attention[] = array_merge( $a, array( 'booking_id' => (int) $b->id, 'booking_number' => $b->booking_number ) ); }
    }
    $open = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_complaints WHERE raised_by_id=%d AND raised_by_type='client' AND status IN ('open','in_progress')", $uid ) );
    return rest_ensure_response( array( 'counts' => $counts, 'next_trip' => $next ? ridego_client_dash_serialize( $next ) : null, 'attention' => $attention,
        'recent' => array_map( 'ridego_client_dash_serialize', $recent ), 'open_complaints' => $open ) );
}

// TRACE: GET trips?tab=upcoming|ongoing|completed|cancelled&page → paginated, tab-filtered, scoped list → response.
//        Edge cases: unknown tab (falls back to upcoming), page<1 (1).
function ridego_client_dash_trips( WP_REST_Request $req ) {
    global $wpdb;
    $uid = get_current_user_id(); $bt = $wpdb->prefix . 'ridego_bookings';
    $tab = sanitize_key( (string) $req->get_param( 'tab' ) );
    if ( ! in_array( $tab, array( 'upcoming', 'ongoing', 'completed', 'cancelled' ), true ) ) { $tab = 'upcoming'; }
    $sts = explode( '|', ridego_booking_group_statuses( $tab ) );
    $ph = implode( ',', array_fill( 0, count( $sts ), '%s' ) );
    $page = max( 1, (int) $req->get_param( 'page' ) ); $per = 10;
    $total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$bt} WHERE client_id=%d AND status IN ({$ph})", array_merge( array( $uid ), $sts ) ) );
    $order = $tab === 'upcoming' || $tab === 'ongoing' ? 'journey_date ASC, journey_time ASC' : 'journey_date DESC, journey_time DESC';
    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$bt} WHERE client_id=%d AND status IN ({$ph}) ORDER BY {$order} LIMIT %d OFFSET %d", array_merge( array( $uid ), $sts, array( $per, ( $page - 1 ) * $per ) ) ) );
    return rest_ensure_response( array( 'tab' => $tab, 'rows' => array_map( 'ridego_client_dash_serialize', $rows ), 'total' => $total, 'page' => $page, 'per_page' => $per ) );
}

// TRACE: booking id + current user → returns the booking row only when client_id matches, else null. IDOR guard.
function ridego_client_dash_own_booking( $id ) {
    $b = ridego_get_booking( (int) $id );
    return ( $b && (int) $b->client_id === (int) get_current_user_id() ) ? $b : null;
}

// TRACE: GET trip detail → booking + timeline + assignment (driver phone only when en route/started) + vendor name +
//        rating state + this booking's complaints + attention + can_cancel → response|404.
//        Edge cases: not own booking (404), no assignment yet (null), blank driver details ('to be confirmed').
function ridego_client_dash_trip( WP_REST_Request $req ) {
    global $wpdb;
    $b = ridego_client_dash_own_booking( $req['id'] );
    if ( ! $b ) { return new WP_Error( 'not_found', 'Trip not found.', array( 'status' => 404 ) ); }
    $a = ridego_get_current_assignment( $b->id );
    $live = in_array( $b->status, array( 'driver_en_route', 'trip_started' ), true );
    $assignment = null;
    if ( $a ) {
        $assignment = array( 'driver_name' => $a->driver_name_snapshot !== '' ? $a->driver_name_snapshot : 'To be confirmed', 'driver_phone' => $live ? $a->driver_phone_snapshot : null,
            'vehicle_model' => $a->vehicle_model_snapshot, 'vehicle_registration' => $a->vehicle_registration_snapshot !== '' ? $a->vehicle_registration_snapshot : 'To be confirmed' );
    }
    $vendor = ! empty( $b->vendor_id ) ? ridego_get_vendor( (int) $b->vendor_id ) : null;
    $complaints = $wpdb->get_results( $wpdb->prepare( "SELECT complaint_id, category, status, created_at FROM {$wpdb->prefix}ridego_complaints WHERE booking_id=%d AND raised_by_id=%d AND raised_by_type='client' ORDER BY id DESC", (int) $b->id, get_current_user_id() ), ARRAY_A );
    $out = ridego_client_dash_serialize( $b );
    $out += array(
        'pickup_address' => $b->pickup_address, 'drop_address' => $b->drop_address, 'passengers' => (int) $b->passengers, 'special_requests' => $b->special_requests, 'client_notes' => array_map( function ( $n ) { return array( 'note' => $n['note'], 'created_at' => $n['created_at'] ); }, ridego_booking_get_notes( $b->id, true ) ), 'rescheduled_from' => (string) $b->rescheduled_from,
        'vendor_name' => $vendor ? $vendor->business_name : null, 'assignment' => $assignment, 'otp' => $live || $b->status === 'vendor_assigned' ? (string) $b->otp_pickup : null,
        'timeline' => ridego_booking_timeline( $b, $a ), 'rating_state' => ridego_get_booking_rating_state( $b->id ),
        'rating_categories' => array( 'vendor' => ridego_rating_categories( 'vendor' ), 'driver' => ridego_rating_categories( 'driver' ) ),
        'platform_notice' => ridego_platform_text( 'disclaimer_client' ), 'vendor_phone' => $vendor && in_array( $b->status, array( 'vendor_assigned', 'driver_en_route', 'trip_started', 'completed' ), true ) ? (string) ( $vendor->whatsapp_number ?: $vendor->phone ) : null,
        'complaints' => $complaints, 'can_cancel' => in_array( $b->status, array( 'pending', 'pending_payment', 'payment_pending', 'confirmed', 'no_vendor', 'vendor_assigned' ), true ),
    );
    return rest_ensure_response( $out );
}

// TRACE: GET invoice → BOOKING RECEIPT (booking amount collected by RideGo only, never the ride invoice) for a confirmed own booking → response|404|400. Edge cases: not own (404),
//        not yet payable (pending payment → 400).
function ridego_client_dash_invoice( WP_REST_Request $req ) {
    $b = ridego_client_dash_own_booking( $req['id'] );
    if ( ! $b ) { return new WP_Error( 'not_found', 'Trip not found.', array( 'status' => 404 ) ); }
    if ( in_array( $b->status, array( 'pending', 'pending_payment', 'payment_pending' ), true ) ) { return new WP_Error( 'not_available', 'Your booking receipt is available once the booking amount is confirmed.', array( 'status' => 400 ) ); }
    $d = ridego_booking_invoice_data( (int) $b->id );
    return $d ? rest_ensure_response( $d ) : new WP_Error( 'not_found', 'Trip not found.', array( 'status' => 404 ) );
}

// TRACE: POST rate {vendor:{cat:1-5}, driver:{cat:1-5}, overall, review} → flattens to category scores and calls
//        ridego_submit_trip_ratings(direction client) → response|400. Edge cases: not own/not completed/duplicate
//        (domain refuses), out-of-range scores ignored by the domain.
function ridego_client_dash_rate( WP_REST_Request $req ) {
    $b = ridego_client_dash_own_booking( $req['id'] );
    if ( ! $b ) { return new WP_Error( 'not_found', 'Trip not found.', array( 'status' => 404 ) ); }
    $j = $req->get_json_params(); $j = is_array( $j ) ? $j : array();
    $scores = array();
    foreach ( array( 'vendor', 'driver' ) as $g ) {
        foreach ( ridego_rating_categories( $g ) as $c ) {
            if ( isset( $j[ $g ][ $c ] ) ) { $scores[ $c ] = (int) $j[ $g ][ $c ]; }
        }
    }
    if ( isset( $j['overall'] ) ) { $scores['overall'] = (int) $j['overall']; }
    $r = ridego_submit_trip_ratings( $b->id, get_current_user_id(), 'client', $scores, sanitize_textarea_field( (string) ( $j['review'] ?? '' ) ) );
    return ridego_mkt_result( $r, 'rate_failed' );
}

// TRACE: GET support → the client's complaints (newest first, max 50) → response.
function ridego_client_dash_support_list( WP_REST_Request $req ) {
    global $wpdb;
    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT c.complaint_id, c.booking_id, b.booking_number, c.category, c.description, c.status, c.resolution, c.created_at FROM {$wpdb->prefix}ridego_complaints c LEFT JOIN {$wpdb->prefix}ridego_bookings b ON b.id=c.booking_id WHERE c.raised_by_id=%d AND c.raised_by_type='client' ORDER BY c.id DESC LIMIT 50", get_current_user_id() ), ARRAY_A );
    return rest_ensure_response( array( 'rows' => $rows ) );
}

// TRACE: POST support {booking_id,category,description} → ownership-checked → ridego_file_complaint as client →
//        response|400|404. Edge cases: not own booking (404), missing fields (domain error), impersonation allowed.
function ridego_client_dash_support_create( WP_REST_Request $req ) {
    $j = $req->get_json_params(); $j = is_array( $j ) ? $j : array();
    $b = ridego_client_dash_own_booking( $j['booking_id'] ?? 0 );
    if ( ! $b ) { return new WP_Error( 'not_found', 'Trip not found.', array( 'status' => 404 ) ); }
    $r = ridego_file_complaint( array( 'booking_id' => $b->id, 'raised_by_id' => get_current_user_id(), 'raised_by_type' => 'client',
        'category' => sanitize_text_field( $j['category'] ?? '' ), 'description' => sanitize_textarea_field( $j['description'] ?? '' ) ) );
    return ridego_mkt_result( $r, 'complaint_failed' );
}

// TRACE: user id → saved addresses from user meta 'ridego_saved_addresses' → array of {id,label,address,city}. Edge: none → [].
function ridego_client_dash_read_addresses( $uid ) {
    $raw = get_user_meta( $uid, 'ridego_saved_addresses', true );
    return is_array( $raw ) ? array_values( $raw ) : array();
}
// TRACE: GET addresses → list → response.
function ridego_client_dash_addresses( WP_REST_Request $req ) { return rest_ensure_response( array( 'rows' => ridego_client_dash_read_addresses( get_current_user_id() ) ) ); }
// TRACE: POST address {label,address,city} → validates, max 10, appends with an 8-hex id → response|400.
function ridego_client_dash_address_save( WP_REST_Request $req ) {
    $j = $req->get_json_params(); $j = is_array( $j ) ? $j : array();
    $label = sanitize_text_field( $j['label'] ?? '' ); $addr = sanitize_text_field( $j['address'] ?? '' ); $city = sanitize_text_field( $j['city'] ?? '' );
    if ( $label === '' || $addr === '' ) { return new WP_Error( 'invalid_input', 'Give the address a name and the address itself.', array( 'status' => 400 ) ); }
    $uid = get_current_user_id(); $list = ridego_client_dash_read_addresses( $uid );
    if ( count( $list ) >= 10 ) { return new WP_Error( 'limit', 'You can save up to 10 addresses. Delete one first.', array( 'status' => 400 ) ); }
    $list[] = array( 'id' => bin2hex( random_bytes( 4 ) ), 'label' => $label, 'address' => $addr, 'city' => $city );
    update_user_meta( $uid, 'ridego_saved_addresses', $list );
    return rest_ensure_response( array( 'success' => true, 'rows' => $list ) );
}
// TRACE: DELETE address/{id} → removes by id → response|404. Edge: unknown id (404).
function ridego_client_dash_address_delete( WP_REST_Request $req ) {
    $uid = get_current_user_id(); $list = ridego_client_dash_read_addresses( $uid ); $id = (string) $req['id'];
    $new = array_values( array_filter( $list, function ( $a ) use ( $id ) { return $a['id'] !== $id; } ) );
    if ( count( $new ) === count( $list ) ) { return new WP_Error( 'not_found', 'Address not found.', array( 'status' => 404 ) ); }
    update_user_meta( $uid, 'ridego_saved_addresses', $new );
    return rest_ensure_response( array( 'success' => true, 'rows' => $new ) );
}
