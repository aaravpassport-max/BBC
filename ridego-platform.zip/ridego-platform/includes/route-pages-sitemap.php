<?php
/**
 * RideGo Route Marketing Pages — XML sitemap integration.
 * ================================================================
 * Registers a WP_Sitemaps_Provider with WordPress core's own sitemaps
 * system (wp-sitemap.xml) so PUBLISHED route pages get real, crawlable
 * sitemap entries — using core's API rather than hand-rolled XML, so this
 * automatically inherits core's sitemap index, XSL styling, robots.txt
 * discovery line, and caching behaviour. Registering a provider on the
 * 'wp_sitemaps_init' action is what makes it pass through core's own
 * 'wp_sitemaps_add_provider' filter (applied inside
 * WP_Sitemaps_Registry::add_provider()) — this is the documented,
 * idiomatic way to add a provider; there is no separate step needed to
 * "use" that filter beyond registering through the real registry.
 *
 * Only rows with status='published' in wp_ridego_route_pages are ever
 * listed — the exact same gate the public REST endpoint and the shell's
 * SEO injection already enforce, queried directly from the real table so
 * a draft/needs_review page can never appear here. Each URL's lastmod is
 * the row's own real published_at (falling back to updated_at, which is
 * ON UPDATE CURRENT_TIMESTAMP — see migration 041 in
 * includes/migrations-marketplace.php) — never a fabricated or "now" date.
 * ================================================================
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'wp_sitemaps_init', 'ridego_route_pages_register_sitemap_provider' );
function ridego_route_pages_register_sitemap_provider() {
    if ( ! class_exists( 'WP_Sitemaps_Provider' ) ) { return; } // WP < 5.5: no core sitemaps system to register into.
    require_once __DIR__ . '/class-ridego-route-pages-sitemap-provider.php';
    wp_register_sitemap_provider( 'ridegoroutes', new RideGo_Route_Pages_Sitemap_Provider() );
}
