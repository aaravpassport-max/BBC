<?php
/**
 * RideGo — Team access: Regional Managers, Staff, Drivers (logins), regions, tasks and "view as" user search.
 * Permissions reuse the existing capability model: a staff member is a WordPress user with a bare role and PER-USER
 * capabilities chosen by an administrator from the module list below, so every existing admin REST route keeps
 * enforcing its own capability. Nothing is granted by default.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: any permission UI/grant code → returns module key => array( label, description, caps ) → array. Pure.
//        Postconditions: the caps here are the ONLY caps team management ever grants or removes.
function ridego_team_modules() {
    return array(
        'bookings'      => array( 'Bookings', 'View, edit, assign and cancel bookings', array( 'ridego_view_all_bookings', 'ridego_manage_bookings', 'ridego_edit_booking_details', 'ridego_assign_vendor' ) ),
        'new_booking'   => array( 'Create bookings', 'Create bookings on behalf of clients', array( 'ridego_create_admin_booking' ) ),
        'clients'       => array( 'Clients', 'Client profiles and history', array( 'ridego_manage_clients' ) ),
        'vendors'       => array( 'Vendors', 'Vendor directory and vendor status', array( 'ridego_view_vendors', 'ridego_manage_vendors' ) ),
        'drivers'       => array( 'Drivers & fleets', 'Fleet vehicles, drivers and their profiles', array( 'ridego_view_fleets', 'ridego_manage_fleet_vehicles' ) ),
        'documents'     => array( 'Documents / KYC', 'Review and approve vendor and driver documents', array( 'ridego_approve_kyc' ) ),
        'inquiries'     => array( 'Inquiries & complaints', 'Enquiries and complaints', array( 'ridego_manage_enquiries', 'ridego_manage_complaints' ) ),
        'tasks'         => array( 'Tasks', 'Create and assign tasks to the team', array( 'ridego_manage_tasks' ) ),
        'payments'      => array( 'Payments', 'Record payments and view financials', array( 'ridego_record_payments', 'ridego_view_financial' ) ),
        'reports'       => array( 'Reports', 'Reports and dashboards', array( 'ridego_view_reports' ) ),
        'communication' => array( 'Communication', 'Send notifications and messages', array( 'ridego_send_bulk_message' ) ),
    );
}

// TRACE: any module code → all caps managed by the module map → array of unique strings. Pure.
function ridego_team_all_module_caps() {
    $out = array();
    foreach ( ridego_team_modules() as $m ) { $out = array_merge( $out, $m[2] ); }
    return array_values( array_unique( $out ) );
}

// TRACE: any code → the team role slugs => label → array. Pure.
function ridego_team_roles() {
    return array( 'ridego_regional_manager' => 'Regional Manager', 'ridego_staff' => 'Staff' );
}

// TRACE: init → creates the three bare roles when missing (read only, nothing else) → void.
//        Postconditions: staff/regional manager/driver hold zero RideGo caps until a module is granted. Edge: role exists → no-op.
function ridego_team_register_roles() {
    foreach ( array( 'ridego_regional_manager' => 'RideGo Regional Manager', 'ridego_staff' => 'RideGo Staff', 'ridego_driver' => 'RideGo Driver' ) as $slug => $label ) {
        if ( ! get_role( $slug ) ) { add_role( $slug, $label, array( 'read' => true ) ); }
    }
}
add_action( 'init', 'ridego_team_register_roles', 15 );

// TRACE: user id + module keys → removes every managed cap from the user then adds the caps of the chosen modules,
//        stores the module list in user meta → array of module keys actually saved.
//        Preconditions: user exists. Postconditions: get_user_meta ridego_team_modules equals the return value and
//        user_can() matches exactly the union of those modules. Edge cases: unknown module keys dropped; empty list → no caps.
function ridego_team_apply_modules( $user_id, $modules ) {
    $known = ridego_team_modules();
    $keep  = array();
    foreach ( (array) $modules as $m ) { $m = sanitize_key( $m ); if ( isset( $known[ $m ] ) ) { $keep[ $m ] = true; } }
    $u = new WP_User( (int) $user_id );
    foreach ( ridego_team_all_module_caps() as $cap ) { $u->remove_cap( $cap ); }
    foreach ( array_keys( $keep ) as $m ) { foreach ( $known[ $m ][2] as $cap ) { $u->add_cap( $cap ); } }
    update_user_meta( (int) $user_id, 'ridego_team_modules', array_keys( $keep ) );
    return array_keys( $keep );
}

/* ------------------------------------------------------------------ regions */

// TRACE: region row → the pickup city names the region covers (listed cities plus every configured city inside its
//        states) → array of strings. Edge cases: empty region → empty array; inactive region → empty array.
function ridego_region_cities( $region ) {
    global $wpdb;
    if ( ! $region || $region->status !== 'active' ) { return array(); }
    $cities = (array) json_decode( (string) $region->cities, true );
    $states = array_filter( (array) json_decode( (string) $region->states, true ) );
    if ( $states ) {
        $ph  = implode( ',', array_fill( 0, count( $states ), '%s' ) );
        $more = $wpdb->get_col( $wpdb->prepare( "SELECT name FROM {$wpdb->prefix}ridego_cities WHERE state IN ({$ph})", array_values( $states ) ) );
        $cities = array_merge( $cities, (array) $more );
    }
    return array_values( array_unique( array_filter( array_map( 'trim', $cities ) ) ) );
}

// TRACE: user id → region ids assigned to the user → array of ints. Edge: none assigned → empty array.
function ridego_user_region_ids( $user_id ) {
    return array_values( array_filter( array_map( 'intval', (array) get_user_meta( (int) $user_id, 'ridego_region_ids', true ) ) ) );
}

// TRACE: user id (default current) → the pickup cities the user is limited to, or null when unrestricted → array|null.
//        Preconditions: none. Postconditions: only a Regional Manager whose scope is 'assigned' is limited; the empty
//        array means "restricted to nothing" (no region assigned) so it can never widen access. Edge: not logged in → null.
function ridego_region_scope_cities( $user_id = 0 ) {
    global $wpdb;
    $user_id = $user_id ? (int) $user_id : get_current_user_id();
    if ( ! $user_id ) { return null; }
    $u = get_userdata( $user_id );
    if ( ! $u || ! in_array( 'ridego_regional_manager', (array) $u->roles, true ) ) { return null; }
    if ( get_user_meta( $user_id, 'ridego_region_scope', true ) === 'all' ) { return null; }
    $ids = ridego_user_region_ids( $user_id );
    if ( ! $ids ) { return array(); }
    $ph   = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
    $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_regions WHERE id IN ({$ph})", $ids ) );
    $out  = array();
    foreach ( (array) $rows as $r ) { $out = array_merge( $out, ridego_region_cities( $r ) ); }
    return array_values( array_unique( $out ) );
}

// TRACE: booking city column + the current user → an " AND col IN (...)" SQL suffix or '' when unrestricted → string.
//        Edge cases: empty scope → " AND 1=0" (nothing visible).
function ridego_region_sql( $column = 'pickup_city' ) {
    global $wpdb;
    $sc = ridego_region_scope_cities();
    if ( $sc === null ) { return ''; }
    if ( ! $sc ) { return ' AND 1=0'; }
    $ph = implode( ',', array_fill( 0, count( $sc ), '%s' ) );
    return ' AND ' . preg_replace( '/[^a-z_.]/i', '', $column ) . ' IN (' . $wpdb->prepare( $ph, $sc ) . ')';
}

// TRACE: booking id (or object) → whether the current user may act on it → bool. Unrestricted → true;
//        scoped → true only when pickup_city is inside the region. Edge: unknown booking → false for scoped users.
function ridego_region_allows_booking( $booking ) {
    $sc = ridego_region_scope_cities();
    if ( $sc === null ) { return true; }
    if ( is_numeric( $booking ) ) { $booking = ridego_get_booking( (int) $booking ); }
    if ( ! $booking ) { return false; }
    foreach ( $sc as $c ) { if ( strcasecmp( $c, (string) $booking->pickup_city ) === 0 ) { return true; } }
    return false;
}

// TRACE: every REST call → for a region-limited Regional Manager: blocks any /app/admin/* route that is not the bookings
//        family, blocks a booking id outside the region, and filters ids in bulk actions → null (continue) or WP_Error.
//        Preconditions: filter runs before the route callback. Postconditions: no booking outside the region can be read
//        or changed through the admin API. Edge cases: unrestricted users and other roles → untouched.
function ridego_region_rest_guard( $response, $handler, $request ) {
    if ( ! is_user_logged_in() || ridego_region_scope_cities() === null ) { return $response; }
    $route = $request->get_route();
    if ( strpos( $route, '/ridego/v1/app/admin/' ) !== 0 ) { return $response; }
    if ( ! preg_match( '#^/ridego/v1/app/admin/bookings(/|$)#', $route ) ) {
        return new WP_Error( 'region_forbidden', 'This section is outside your regional access.', array( 'status' => 403 ) );
    }
    if ( preg_match( '#^/ridego/v1/app/admin/bookings/(\d+)#', $route, $m ) && ! ridego_region_allows_booking( (int) $m[1] ) ) {
        return new WP_Error( 'region_forbidden', 'This booking is outside your region.', array( 'status' => 403 ) );
    }
    if ( substr( $route, -5 ) === '/bulk' ) {
        $ids = $request->get_param( 'ids' );
        foreach ( (array) $ids as $bid ) {
            if ( ! ridego_region_allows_booking( (int) $bid ) ) { return new WP_Error( 'region_forbidden', 'A selected booking is outside your region.', array( 'status' => 403 ) ); }
        }
    }
    if ( $route === '/ridego/v1/app/admin/bookings/new' || ( $request->get_method() === 'POST' && $route === '/ridego/v1/app/admin/bookings' ) ) {
        $city = (string) $request->get_param( 'pickup_city' );
        $sc = ridego_region_scope_cities();
        $in = false; foreach ( $sc as $c ) { if ( strcasecmp( $c, $city ) === 0 ) { $in = true; } }
        if ( ! $in ) { return new WP_Error( 'region_forbidden', 'Pickup city is outside your region.', array( 'status' => 403 ) ); }
    }
    return $response;
}
add_filter( 'rest_request_before_callbacks', 'ridego_region_rest_guard', 10, 3 );
