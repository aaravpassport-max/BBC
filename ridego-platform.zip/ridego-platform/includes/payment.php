<?php
/**
 * RideGo Platform - Payment System
 * 
 * Handles all payment processing:
 * - Manual bank transfer (free - economy-first Phase 1)
 * - Payment proof upload and verification
 * - Razorpay integration (Phase 2 upgrade)
 * - Vendor wallet management
 * - Lead fee deduction
 * - Refund processing
 * - Transaction logging
 * 
 * Economy-First Design (Phase 1):
 * - Manual bank/UPI payment with proof upload (FREE)
 * - Admin verification workflow (no gateway fees)
 * - Phase 2: Enable Razorpay for instant confirmation
 * 
 * @package RideGo
 * @subpackage Payment
 * @version 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// ============================================================================
// CLIENT PAYMENT - MANUAL BANK TRANSFER (PHASE 1)
// ============================================================================

/**
 * Get payment instructions for manual bank transfer
 * Shows bank account details, UPI ID, QR code
 * 
 * @param int   $booking_id Booking ID
 * @param float $amount     Amount to pay
 * @return array Payment instructions
 */
function ridego_get_manual_payment_instructions($booking_id, $amount) {
    
    return array(
        'booking_id'      => $booking_id,
        'amount'          => $amount,
        'account_name'    => ridego_get_setting( 'bank_holder', '' ) ?: ridego_brand( 'legal_name' ),
        'bank_name'       => ridego_get_setting( 'bank_name', '' ),
        'account_number'  => ridego_get_setting( 'bank_account', '' ),
        'ifsc_code'       => ridego_get_setting( 'bank_ifsc', '' ),
        'branch'          => '',
        'upi_id'          => ridego_get_setting( 'upi_id', '' ),
        'upi_qr_code'     => ridego_get_setting( 'upi_qr_url', '' ),
        'payment_deadline' => date('Y-m-d H:i:s', time() + 7200), // 2 hours
        'reference'       => ridego_get_booking_number($booking_id),
        'instructions'    => array(
            'Transfer the exact amount shown above',
            'Use booking number as payment reference/remarks',
            'Upload payment screenshot or receipt after payment',
            'Your booking will be confirmed within 30 minutes of verification'
        )
    );
}

/**
 * Save payment proof uploaded by client
 * 
 * @param int    $booking_id    Booking ID
 * @param string $file_path     Uploaded file path
 * @param array  $payment_data  Payment details (UTR, amount, app, time)
 * @return array Result
 */
function ridego_save_payment_proof($booking_id, $file_path, $payment_data) {
    global $wpdb;
    
    $bookings_table = $wpdb->prefix . 'ridego_bookings';
    
    // Validate file
    $file_info = pathinfo($file_path);
    $allowed_ext = array('jpg', 'jpeg', 'png', 'pdf');
    
    if (!in_array(strtolower($file_info['extension']), $allowed_ext)) {
        return array(
            'success' => false,
            'error'   => 'Invalid file format. Please upload JPG, PNG or PDF'
        );
    }
    
    // Move file to secure location
    $upload_dir = WP_CONTENT_DIR . '/ridego-secure-uploads/payment-proofs/' . $booking_id . '/';
    
    if (!file_exists($upload_dir)) {
        wp_mkdir_p($upload_dir);
    }
    
    $filename = 'proof_' . time() . '.' . $file_info['extension'];
    $destination = $upload_dir . $filename;
    
    // Compress image if it's too large
    if (in_array($file_info['extension'], array('jpg', 'jpeg', 'png'))) {
        ridego_compress_payment_proof($file_path, $destination);
        @unlink($file_path); // Remove original
    } else {
        rename($file_path, $destination);
    }
    
    // Update booking record
    $updated = $wpdb->update($bookings_table, array(
        'payment_method'         => 'manual_bank',
        'payment_status'         => 'proof_submitted',
        'payment_proof_url'      => $destination,
        'payment_utr'            => sanitize_text_field($payment_data['utr'] ?? ''),
        'payment_app'            => sanitize_text_field($payment_data['app'] ?? ''),
        'payment_time_claimed'   => sanitize_text_field($payment_data['payment_time'] ?? current_time('mysql')),
        'payment_amount_claimed' => floatval($payment_data['amount'] ?? 0),
        'payment_deadline'       => date('Y-m-d H:i:s', time() + 7200), // 2 hours to verify
        'updated_at'             => current_time('mysql')
    ), array('id' => $booking_id), 
    array('%s', '%s', '%s', '%s', '%s', '%s', '%f', '%s', '%s'),
    array('%d'));
    
    if (!$updated) {
        return array(
            'success' => false,
            'error'   => 'Failed to save payment proof. Please try again.'
        );
    }
    
    // Log activity
    ridego_log_activity('payment_proof_submitted', 'booking', $booking_id, array(
        'utr'    => $payment_data['utr'] ?? '',
        'amount' => $payment_data['amount'] ?? 0
    ));
    
    // Send notifications
    $booking = ridego_get_booking($booking_id);
    
    // Notify client
    ridego_send_notification($booking->client_id, 'payment_proof_submitted', array(
        'booking_number' => $booking->booking_number,
        'amount'         => $payment_data['amount'],
        'utr'            => $payment_data['utr'] ?? '',
        'payment_app'    => $payment_data['app'] ?? ''
    ));
    
    // Alert admin via Telegram
    ridego_send_notification(0, 'payment_proof_submitted', array(
        'recipient_type' => 'admin',
        'booking_number' => $booking->booking_number,
        'amount'         => $payment_data['amount'],
        'utr'            => $payment_data['utr'] ?? '',
        'verify_link'    => admin_url('admin.php?page=ridego-bookings&action=verify_payment&id=' . $booking_id),
        'priority'       => 'high'
    ));
    
    return array(
        'success' => true,
        'message' => 'Payment proof submitted successfully. Your booking will be confirmed within 30 minutes.'
    );
}

/**
 * Compress payment proof image
 * Max 500KB, 1200px width
 */
function ridego_compress_payment_proof($source, $destination, $quality = 75) {
    
    $info = getimagesize($source);
    if (!$info) {
        copy($source, $destination);
        return;
    }
    
    $mime = $info['mime'];
    
    // Create image resource
    switch ($mime) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $image = imagecreatefrompng($source);
            break;
        default:
            copy($source, $destination);
            return;
    }
    
    // Resize if needed
    $max_width = 1200;
    $width = imagesx($image);
    $height = imagesy($image);
    
    if ($width > $max_width) {
        $ratio = $max_width / $width;
        $new_width = $max_width;
        $new_height = intval($height * $ratio);
        
        $resized = imagecreatetruecolor($new_width, $new_height);
        imagecopyresampled($resized, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
        $image = $resized;
    }
    
    // Save as JPEG
    imagejpeg($image, $destination, $quality);
    imagedestroy($image);
}

/**
 * Admin verifies payment proof.
 *
 * ROOT-CAUSE FIX: this used to be a second, divergent implementation of
 * payment verification/rejection from the canonical
 * ridego_verify_payment()/ridego_reject_payment() in includes/booking.php
 * — the ones actually wired to the REST API, wp-admin, and bulk actions.
 * This copy was never updated when the Token Amount / Advance Payment
 * feature was added: it left advance_paid at 0.00 forever (never wrote
 * it at all) and logged the full total_fare as collected revenue even
 * when only the token amount was actually due, and its reject branch
 * used a different payment_status ('proof_rejected') than the canonical
 * one ('rejected'). Confirmed via grep that nothing calls this function
 * — but keeping a second, silently-diverging implementation around is
 * exactly the kind of drift this codebase's audits keep finding, so it
 * is now a thin wrapper over the canonical functions instead of its own
 * copy of the business logic. Two implementations can never disagree
 * again because there is only one.
 *
 * @param int  $booking_id Booking ID
 * @param bool $approved   Approved or rejected
 * @param string $reason   Rejection reason (if rejected)
 * @return array Result
 */
function ridego_verify_payment_proof($booking_id, $approved = true, $reason = '') {
    if (!ridego_get_booking($booking_id)) {
        return array('success' => false, 'error' => 'Booking not found');
    }

    if ($approved) {
        $ok = ridego_verify_payment($booking_id, get_current_user_id());
        return $ok
            ? array('success' => true, 'message' => 'Payment verified and booking confirmed')
            : array('success' => false, 'error' => 'Could not verify payment for this booking.');
    }

    $ok = ridego_reject_payment($booking_id, $reason, get_current_user_id());
    return $ok
        ? array('success' => true, 'message' => 'Payment proof rejected. Client notified to resubmit.')
        : array('success' => false, 'error' => 'Could not reject payment for this booking.');
}

// ============================================================================
// RAZORPAY INTEGRATION (PHASE 2)
// ============================================================================

/**
 * Create Razorpay order
 * Phase 2: Enable instant payment confirmation
 * 
 * @param int   $booking_id Booking ID
 * @param float $amount     Amount in rupees
 * @return array Order data or error
 */
function ridego_create_razorpay_order($booking_id, $amount) {
    
    $key_id = get_option('ridego_razorpay_key_id');
    $key_secret = get_option('ridego_razorpay_key_secret');
    
    if (empty($key_id) || empty($key_secret)) {
        return array('error' => 'Razorpay not configured');
    }
    
    $booking = ridego_get_booking($booking_id);
    
    // Razorpay API endpoint
    $url = 'https://api.razorpay.com/v1/orders';
    
    // Order data
    $data = array(
        'amount'   => $amount * 100, // Convert to paise
        'currency' => 'INR',
        'receipt'  => $booking->booking_number,
        'notes'    => array(
            'booking_id' => $booking_id,
            'client_name' => $booking->client_name
        )
    );
    
    // Make API request
    $response = wp_remote_post($url, array(
        'headers' => array(
            'Authorization' => 'Basic ' . base64_encode($key_id . ':' . $key_secret),
            'Content-Type'  => 'application/json'
        ),
        'body'    => wp_json_encode($data),
        'timeout' => 30
    ));
    
    if (is_wp_error($response)) {
        return array('error' => $response->get_error_message());
    }
    
    $body = json_decode(wp_remote_retrieve_body($response), true);
    
    if (isset($body['error'])) {
        return array('error' => $body['error']['description']);
    }
    
    return $body;
}

/**
 * Verify Razorpay CHECKOUT signature (order_id|payment_id HMAC), used for
 * the client-side "payment success" callback, not the server-to-server
 * webhook (see ridego_verify_razorpay_webhook_signature() below for that).
 *
 * @param array $data Payment data from Razorpay
 * @return bool Valid signature
 */
function ridego_verify_razorpay_signature($data) {

    $key_secret = ridego_get_setting('razorpay_key_secret', get_option('ridego_razorpay_key_secret'));

    if (empty($key_secret) || empty($data['razorpay_order_id']) || empty($data['razorpay_payment_id']) || empty($data['razorpay_signature'])) {
        return false;
    }

    $expected = hash_hmac('sha256',
        $data['razorpay_order_id'] . '|' . $data['razorpay_payment_id'],
        $key_secret
    );

    return hash_equals($expected, $data['razorpay_signature']);
}

/**
 * Verify a Razorpay WEBHOOK signature: HMAC-SHA256 of the raw request body
 * using the webhook secret configured in Razorpay Dashboard → Webhooks
 * (deliberately a DIFFERENT secret than the API key secret — Razorpay's
 * own recommended model, and why 'razorpay_webhook_secret' is a distinct
 * encrypted setting from 'razorpay_key_secret').
 *
 * @param string $raw_body        Raw HTTP request body, exactly as received.
 * @param string $signature_header Value of the X-Razorpay-Signature header.
 * @return bool
 */
function ridego_verify_razorpay_webhook_signature($raw_body, $signature_header) {
    $webhook_secret = ridego_get_setting('razorpay_webhook_secret');
    if (empty($webhook_secret) || empty($signature_header) || $raw_body === '' || $raw_body === null) {
        return false;
    }
    $expected = hash_hmac('sha256', $raw_body, $webhook_secret);
    return hash_equals($expected, $signature_header);
}

/**
 * Process successful Razorpay payment
 * 
 * @param int    $booking_id  Booking ID
 * @param string $payment_id  Razorpay payment ID
 * @param string $order_id    Razorpay order ID
 * @param array  $data        Payment data
 * @return bool Success
 */
function ridego_process_razorpay_success($booking_id, $payment_id, $order_id, $data = array()) {
    global $wpdb;

    $bookings_table = $wpdb->prefix . 'ridego_bookings';

    // Token Amount / Advance Payment: what was actually collected via
    // Razorpay for this booking is the snapshot token_amount when the
    // feature was on at booking time, else the full total_fare — same
    // rule as the manual-payment verification path in
    // ridego_verify_payment() (includes/booking.php), so advance_paid is
    // consistent across both payment methods.
    $booking_for_amount = ridego_get_booking($booking_id);
    $paid_amount = $booking_for_amount
        ? ( $booking_for_amount->token_amount > 0 ? (float) $booking_for_amount->token_amount : (float) $booking_for_amount->total_fare )
        : 0.00;

    // Update booking.
    // ROOT-CAUSE FIX: this write was previously fire-and-forget — its
    // return value was discarded. $wpdb->update() returns false on a
    // genuine DB error (not merely 0 rows, which can be legitimate), and
    // this is a live payment-gateway webhook: Razorpay has ALREADY
    // captured the client's money by the time this function runs, so a
    // silent failure here means real cash collected with the booking
    // never reflecting "verified"/"confirmed" — the same ghost-success
    // class of bug as the wallet-credit sites in booking.php and
    // subscriptions.php. On failure we audit-log immediately and enqueue
    // a durable retry via includes/jobs.php rather than losing it.
    $update_ok = $wpdb->update($bookings_table, array(
        'payment_method'    => 'razorpay',
        'payment_status'    => 'verified',
        'payment_gateway_id' => $payment_id,
        'payment_order_id'  => $order_id,
        'advance_paid'      => $paid_amount,
        'payment_verified_at' => current_time('mysql'),
        'status'            => 'confirmed',
        'updated_at'        => current_time('mysql')
    ), array('id' => $booking_id),
    array('%s', '%s', '%s', '%s', '%f', '%s', '%s', '%s'),
    array('%d'));

    if ( $update_ok === false && function_exists( 'ridego_audit_log' ) ) {
        ridego_audit_log( 'booking_payment_verify_failed_queued', 'booking', $booking_id, '',
            "Razorpay payment {$payment_id} captured but booking row update failed ({$wpdb->last_error}) — queued for automatic retry.",
            'critical' );
        if ( function_exists( 'ridego_enqueue_job' ) ) {
            ridego_enqueue_job( 'booking_payment_verify_retry', array(
                'booking_id'   => $booking_id,
                'payment_id'   => $payment_id,
                'order_id'     => $order_id,
                'paid_amount'  => $paid_amount,
            ), 60, 'high' );
        }
    }

    // Log transaction. Uses the token-aware $paid_amount computed above
    // (what RideGo actually collected), not the raw $data['amount'] the
    // gateway callback passed in — the latter is client/webhook-supplied
    // and, even when trustworthy, is the gateway's own order amount which
    // should already equal $paid_amount; deriving it from the booking row
    // instead keeps the Gross Revenue KPI's definition of "collected"
    // consistent with the manual-payment path (ridego_verify_payment()).
    ridego_log_transaction(array(
        'type'       => 'booking_payment',
        'amount'     => $paid_amount,
        'booking_id' => $booking_id,
        'gateway'    => 'razorpay',
        'gateway_id' => $payment_id,
        'status'     => 'success',
        'data'       => wp_json_encode($data)
    ));
    
    if ( $paid_amount > 0 && function_exists('ridego_booking_payment_row') ) { ridego_booking_payment_row($booking_id,'payment',$paid_amount,'razorpay',(string) $payment_id,'Razorpay payment captured',0); }
    // Send confirmation
    $booking = ridego_get_booking($booking_id);
    ridego_send_notification($booking->client_id, 'payment_verified', array(
        'booking_number' => $booking->booking_number,
        'amount'         => $paid_amount,
        'booking_link'   => home_url('/my-trips/?booking=' . $booking->booking_number)
    ));
    
    // Distribute to vendors, and run everything else the platform does
    // when a booking becomes confirmed. This used to call
    // ridego_distribute_booking_to_vendors() — an empty stub (see its
    // own doc comment below) that has never done anything, meaning
    // every Razorpay-paid booking confirmed through this webhook was
    // marked paid/confirmed but never actually sent to any vendor as a
    // lead. The manual/cash confirmation paths (ridego_verify_payment()
    // in includes/booking.php, admin/pages/bookings.php's "resend
    // confirmation" action) already fire this same action and work
    // correctly — this now does the same, instead of calling a
    // function that was never wired up to anything.
    do_action( 'ridego_booking_confirmed', $booking_id );

    return true;
}

/**
 * Idempotency pre-check for the webhook handler (Wave 2B Task 5): has this
 * gateway reference already been recorded as a successful transaction?
 * This is a fast pre-check only — the real, race-proof guarantee is the
 * UNIQUE (gateway, gateway_ref) index added by migration 004, which the
 * webhook handler's INSERT relies on as the structural backstop even if
 * two deliveries of the same event are processed concurrently and both
 * pass this pre-check before either has committed.
 *
 * @param string $gateway     e.g. 'razorpay'
 * @param string $gateway_ref Razorpay payment_id or refund id
 * @return bool
 */
function ridego_transaction_already_processed($gateway, $gateway_ref) {
    global $wpdb;
    if (empty($gateway_ref)) { return false; }
    $table = $wpdb->prefix . 'ridego_transactions';
    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$table} WHERE gateway=%s AND gateway_ref=%s AND status='success' LIMIT 1",
        $gateway, $gateway_ref
    ));
    return (bool) $existing;
}

/**
 * Process a Razorpay `payment.failed` webhook event: marks the booking's
 * payment as failed so the client can retry, and logs the failure as a
 * transaction row (status='failed' — NOT eligible for the idempotency
 * short-circuit above, which only matches status='success').
 *
 * @param int    $booking_id
 * @param string $payment_id
 * @param array  $data
 * @return bool
 */
function ridego_process_razorpay_failure($booking_id, $payment_id, $data = array()) {
    global $wpdb;

    $failure_update_ok = $wpdb->update($wpdb->prefix . 'ridego_bookings', array(
        'payment_status' => 'failed',
        'updated_at'     => current_time('mysql'),
    ), array('id' => $booking_id), array('%s', '%s'), array('%d'));
    // 2.6-D return-value check: unlike the success path, a failed booking update here has no money at
    // stake to lose (the payment already failed at the gateway, nothing to reconcile), so a retry job
    // would be overkill — but it must still be visible to an admin rather than silently swallowed.
    if ( $failure_update_ok === false && function_exists( 'ridego_audit_log' ) ) {
        ridego_audit_log( 'booking_payment_failed_update_error', 'booking', $booking_id, '',
            "Failed to record payment_status=failed for booking after Razorpay payment {$payment_id} failed ({$wpdb->last_error}).", 'warning' );
    }

    ridego_log_transaction(array(
        'type'       => 'booking_payment',
        'amount'     => isset($data['amount']) ? $data['amount'] / 100 : 0,
        'booking_id' => $booking_id,
        'gateway'    => 'razorpay',
        'gateway_ref'=> $payment_id,
        'status'     => 'failed',
        'notes'      => isset($data['error_description']) ? $data['error_description'] : 'Payment failed',
    ));

    $booking = ridego_get_booking($booking_id);
    if ($booking) {
        ridego_send_notification($booking->client_id, 'payment_failed', array(
            'booking_number' => $booking->booking_number,
            'retry_link'     => home_url('/confirm/?booking=' . $booking->booking_number),
        ));
    }

    return true;
}

/**
 * Process a Razorpay `refund.processed` webhook event: marks the booking's
 * refund as completed (mirrors ridego_mark_refund_processed()) and logs a
 * 'refund' transaction row keyed by the refund's own gateway_ref so it
 * idempotency-checks independently of the original payment.
 *
 * @param int    $booking_id
 * @param string $refund_id
 * @param array  $data
 * @return bool
 */
function ridego_process_razorpay_refund($booking_id, $refund_id, $data = array()) {
    ridego_mark_refund_processed($booking_id, $refund_id);

    ridego_log_transaction(array(
        'type'       => 'refund',
        'amount'     => isset($data['amount']) ? $data['amount'] / 100 : 0,
        'booking_id' => $booking_id,
        'gateway'    => 'razorpay',
        'gateway_ref'=> $refund_id,
        'status'     => 'success',
        'notes'      => 'Refund confirmed via Razorpay webhook',
    ));

    $booking = ridego_get_booking($booking_id);
    if ($booking) {
        ridego_send_notification($booking->client_id, 'refund_processed', array(
            'booking_number' => $booking->booking_number,
            'refund_id'      => $refund_id,
        ));
    }

    return true;
}

// ============================================================================
// VENDOR WALLET MANAGEMENT
// ============================================================================

/**
 * Get vendor wallet balance
 * 
 * @param int $vendor_id Vendor ID
 * @return float Wallet balance
 */
function ridego_get_vendor_wallet_balance($vendor_id) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_vendors';
    
    $balance = $wpdb->get_var($wpdb->prepare(
        "SELECT wallet_balance FROM {$table} WHERE id = %d",
        $vendor_id
    ));
    
    return $balance ? floatval($balance) : 0;
}

/**
 * Credit vendor wallet
 * 
 * @param int    $vendor_id Vendor ID
 * @param float  $amount    Amount to credit
 * @param string $type      Transaction type
 * @param string $notes     Transaction notes
 * @param int    $ref_id    Reference ID (booking, etc.)
 * @return bool Success
 */
/**
 * Thin wrapper around the canonical, atomic ridego_vendor_credit_wallet()
 * in includes/helpers.php. This used to be a second, divergent
 * read-then-write implementation with the same race condition as the old
 * helpers.php version — consolidated per Wave 2B Task 1. Keeps its own
 * (ref_id-first) argument order for existing call sites and returns a
 * plain bool for backward compatibility with those call sites.
 *
 * @return bool
 */
function ridego_credit_vendor_wallet($vendor_id, $amount, $type = 'topup', $notes = '', $ref_id = 0) {
    $result = ridego_vendor_credit_wallet($vendor_id, $amount, $ref_id ?: null, $notes, $type);
    return ! empty($result['success']);
}

/**
 * Debit vendor wallet
 * 
 * @param int    $vendor_id Vendor ID
 * @param float  $amount    Amount to debit
 * @param string $type      Transaction type
 * @param string $notes     Transaction notes
 * @param int    $ref_id    Reference ID
 * @return bool Success
 */
/**
 * Thin wrapper around the canonical, atomic ridego_vendor_deduct_wallet()
 * in includes/helpers.php. See ridego_credit_vendor_wallet() above for
 * why this consolidation happened. Returns a plain bool for backward
 * compatibility with existing call sites.
 *
 * @return bool
 */
function ridego_debit_vendor_wallet($vendor_id, $amount, $type = 'lead_fee', $notes = '', $ref_id = 0) {
    $result = ridego_vendor_deduct_wallet($vendor_id, $amount, $ref_id ?: null, $notes, $type);
    $ok = ! empty($result['success']);

    if ($ok) {
        $min_balance = get_option('ridego_vendor_min_wallet_balance', 200);
        if ($result['balance_after'] < $min_balance) {
            $vendor = ridego_get_vendor($vendor_id);
            if ($vendor) {
                ridego_send_notification($vendor->user_id, 'vendor_wallet_low', array(
                    'wallet_balance' => $result['balance_after'],
                    'min_required'   => $min_balance,
                    'topup_link'     => home_url( '/vendor/dashboard/' )
                ));
            }
        }
    }

    return $ok;
}

/**
 * Get vendor wallet transactions
 * 
 * @param int   $vendor_id Vendor ID
 * @param array $args      Query args
 * @return array Transactions
 */
function ridego_get_vendor_wallet_transactions($vendor_id, $args = array()) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_vendor_wallets';
    
    $defaults = array(
        'limit'  => 50,
        'offset' => 0,
        'type'   => '', // credit, debit, or empty for all
        'orderby' => 'created_at',
        'order'  => 'DESC'
    );
    
    $args = wp_parse_args($args, $defaults);
    
    $where = array("vendor_id = " . absint($vendor_id));
    
    if (!empty($args['type'])) {
        $where[] = "type = '" . esc_sql($args['type']) . "'";
    }
    
    $where_sql = implode(' AND ', $where);
    
    $query = "SELECT * FROM {$table} 
              WHERE {$where_sql} 
              ORDER BY {$args['orderby']} {$args['order']} 
              LIMIT {$args['limit']} OFFSET {$args['offset']}";
    
    return $wpdb->get_results($query);
}

// ============================================================================
// LEAD FEE MANAGEMENT
// ============================================================================

/**
 * Hold lead fee (reserve from wallet when vendor accepts lead)
 * 
 * @param int   $vendor_id  Vendor ID
 * @param int   $booking_id Booking ID
 * @param float $lead_fee   Lead fee amount
 * @return bool Success
 */
function ridego_hold_lead_fee($vendor_id, $booking_id, $lead_fee) {
    
    // Check if sufficient balance
    $balance = ridego_get_vendor_wallet_balance($vendor_id);
    
    if ($balance < $lead_fee) {
        return false;
    }
    
    // For now, immediately deduct (simple implementation)
    // Advanced: Implement "hold" status that deducts on trip completion
    return ridego_debit_vendor_wallet(
        $vendor_id,
        $lead_fee,
        'lead_fee',
        "Lead fee for booking #{$booking_id}",
        $booking_id
    );
}

/**
 * Refund lead fee (if booking cancelled by client)
 * 
 * @param int $vendor_id  Vendor ID
 * @param int $booking_id Booking ID
 * @return bool Success
 */
function ridego_refund_lead_fee($vendor_id, $booking_id) {
    
    // Get original lead fee amount from booking
    $booking = ridego_get_booking($booking_id);
    
    if (!$booking || $booking->lead_fee_charged <= 0) {
        return false;
    }
    
    return ridego_credit_vendor_wallet(
        $vendor_id,
        $booking->lead_fee_charged,
        'lead_fee_refund',
        "Refund for booking #{$booking_id} cancellation",
        $booking_id
    );
}

// ============================================================================
// REFUND PROCESSING
// ============================================================================

/**
 * Process refund for cancelled booking
 * 
 * @param int    $booking_id Booking ID
 * @param float  $amount     Refund amount
 * @param string $reason     Refund reason
 * @return array Result
 */
// TRACE: cancellation/not-arranged → marks the booking refund_pending, logs the transaction, fires ridego_refund_initiated, optionally calls Razorpay → array(success,...).
//        Preconditions: booking exists → Postconditions: refund columns set → Edge cases: unknown booking, gateway failure handled by existing code.
function ridego_process_refund($booking_id, $amount, $reason = '') {
    global $wpdb;

    $booking = ridego_get_booking($booking_id);

    if (!$booking) {
        return array('success' => false, 'error' => 'Booking not found');
    }

    $bookings_table = $wpdb->prefix . 'ridego_bookings';

    // Update booking
    $refund_update_ok = $wpdb->update($bookings_table, array(
        'payment_status'  => 'refund_pending',
        'refund_amount'   => $amount,
        'refund_reason'   => sanitize_text_field($reason),
        'refund_initiated_at' => current_time('mysql'),
        'updated_at'      => current_time('mysql')
    ), array('id' => $booking_id),
    array('%s', '%f', '%s', '%s', '%s'),
    array('%d'));
    // 2.6-D: this one DOES have money at stake — if refund_amount never lands, the automated
    // Razorpay-refund-API call a few lines below still fires (it reads $amount from this function's own
    // parameter, not from the row), so the money is still returned to the client; what would be lost is
    // the local bookkeeping record of it, which an admin needs to reconcile against the gateway. Audit-log
    // rather than a retry job, since re-running this whole function would also re-trigger the gateway call.
    if ( $refund_update_ok === false && function_exists( 'ridego_audit_log' ) ) {
        ridego_audit_log( 'refund_initiate_update_failed', 'booking', $booking_id, '',
            "Refund of {$amount} initiated for booking but the booking row failed to update ({$wpdb->last_error}) — verify refund_pending/refund_amount manually.", 'critical' );
    }

    do_action( 'ridego_refund_initiated', (int) $booking_id, (float) $amount );

    // Log transaction
    ridego_log_transaction(array(
        'type'       => 'refund',
        'amount'     => $amount,
        'booking_id' => $booking_id,
        'gateway'    => $booking->payment_method === 'razorpay' ? 'razorpay' : 'manual',
        'status'     => 'pending',
        'notes'      => $reason
    ));

    // Automated gateway-side refund path: if the original payment went
    // through Razorpay, actually call Razorpay's refund API (Wave 2B
    // Task 6) rather than only updating local status and leaving the
    // money never actually returned. Cash/bank-transfer payments have no
    // gateway to call and fall through to the existing manual-refund-
    // tracking flow (an admin marks it processed once they've done the
    // bank transfer, via ridego_mark_refund_processed()).
    if ($booking->payment_method === 'razorpay' && !empty($booking->payment_gateway_id)) {
        $gw = ridego_execute_razorpay_refund($booking_id, $amount, $reason);
        if (!empty($gw['success'])) {
            // Gateway confirmed the refund — mark it processed immediately
            // rather than waiting on a separate manual step. The webhook
            // (refund.processed) is still the authoritative confirmation
            // for reconciliation and will simply be a no-op here (already
            // marked) thanks to the idempotency check.
            ridego_mark_refund_processed($booking_id, $gw['refund_id']);
            ridego_send_notification($booking->client_id, 'refund_processed', array(
                'booking_number' => $booking->booking_number,
                'refund_amount'  => $amount,
            ));
            return array(
                'success' => true,
                'message' => 'Refund processed automatically via Razorpay. Amount will reflect in 5-7 business days.',
                'gateway_refund_id' => $gw['refund_id'],
            );
        }
        // Gateway call failed — do NOT pretend it succeeded. Booking stays
        // 'refund_pending' and the gateway's own error message is surfaced
        // for admin visibility so they know to investigate/retry manually.
        ridego_audit_log('razorpay_refund_failed', 'booking', $booking_id, '', $gw['error'] ?? 'unknown error', 'error');
        ridego_send_notification($booking->client_id, 'refund_initiated', array(
            'booking_number' => $booking->booking_number,
            'refund_amount'  => $amount,
            'refund_days'    => get_option('ridego_refund_days', '5-7'),
            'reason'         => $reason
        ));
        return array(
            'success' => true, // the refund request itself was recorded/queued successfully
            'message' => 'Refund initiated but automatic gateway processing failed (' . ($gw['error'] ?? 'unknown error') . '). An admin will process this manually.',
            'gateway_error' => $gw['error'] ?? 'unknown error',
        );
    }

    // Manual-refund-tracking flow (cash / bank transfer / no gateway ref).
    ridego_send_notification($booking->client_id, 'refund_initiated', array(
        'booking_number' => $booking->booking_number,
        'refund_amount'  => $amount,
        'refund_days'    => get_option('ridego_refund_days', '5-7'),
        'reason'         => $reason
    ));

    return array(
        'success' => true,
        'message' => 'Refund initiated. Amount will be credited in 5-7 business days.'
    );
}

/**
 * Call Razorpay's refund API for a booking's original payment.
 * https://razorpay.com/docs/api/refunds/create/
 *
 * @param int    $booking_id
 * @param float  $amount  Amount in rupees.
 * @param string $reason
 * @return array{success:bool, refund_id?:string, error?:string}
 */
function ridego_execute_razorpay_refund($booking_id, $amount, $reason = '') {
    $booking = ridego_get_booking($booking_id);
    if (!$booking || empty($booking->payment_gateway_id)) {
        return array('success' => false, 'error' => 'No Razorpay payment ID on this booking.');
    }

    $key_id     = ridego_get_setting('razorpay_key_id');
    $key_secret = ridego_get_setting('razorpay_key_secret');
    if (empty($key_id) || empty($key_secret)) {
        return array('success' => false, 'error' => 'Razorpay is not configured.');
    }

    $payment_id = $booking->payment_gateway_id;
    $url = "https://api.razorpay.com/v1/payments/{$payment_id}/refund";

    // A unique idempotency key per (booking, reason-of-call) so a network
    // timeout that triggers our own retry doesn't create a second refund
    // at Razorpay's end — Razorpay's Idempotency-Key header handles that
    // at the gateway level.
    $idempotency_key = 'ridego_refund_' . $booking_id . '_' . md5($amount . $reason);

    $response = wp_remote_post($url, array(
        'headers' => array(
            'Authorization'    => 'Basic ' . base64_encode($key_id . ':' . $key_secret),
            'Content-Type'     => 'application/json',
            'X-Idempotency-Key'=> $idempotency_key,
        ),
        'body'    => wp_json_encode(array(
            'amount' => (int) round($amount * 100), // paise
            'speed'  => 'normal',
            'notes'  => array(
                'booking_id' => $booking_id,
                'reason'     => $reason,
            ),
        )),
        'timeout' => 30,
    ));

    if (is_wp_error($response)) {
        return array('success' => false, 'error' => $response->get_error_message());
    }

    $code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ($code >= 200 && $code < 300 && isset($body['id'])) {
        return array('success' => true, 'refund_id' => $body['id']);
    }

    $error = isset($body['error']['description']) ? $body['error']['description'] : ('Razorpay refund API returned HTTP ' . $code);
    return array('success' => false, 'error' => $error);
}

/**
 * Mark refund as processed
 * 
 * @param int    $booking_id    Booking ID
 * @param string $transaction_id Bank transaction ID
 * @return bool Success
 */
// TRACE: admin/gateway confirms refund → sets refunded + processed timestamp, fires ridego_refund_processed (commission reversal), tries to close the booking → true.
//        Preconditions: refund initiated → Postconditions: refund_processed_at set → Edge cases: repeat calls (ledger reversal is idempotent).
function ridego_mark_refund_processed($booking_id, $transaction_id = '', $method = 'manual', $note = '', $by = 0) {
    global $wpdb;
    
    $bookings_table = $wpdb->prefix . 'ridego_bookings';
    $pre = $wpdb->get_row( $wpdb->prepare( "SELECT refund_amount, payment_status FROM {$bookings_table} WHERE id=%d", (int) $booking_id ) );
    
    $mark_refunded_ok = $wpdb->update($bookings_table, array(
        'payment_status'       => 'refunded',
        'refund_transaction_id' => sanitize_text_field($transaction_id),
        'refund_processed_at'  => current_time('mysql'),
        'updated_at'           => current_time('mysql')
    ), array('id' => $booking_id),
    array('%s', '%s', '%s', '%s'),
    array('%d'));
    // 2.6-D: an admin/gateway has just confirmed money physically left the business for this refund — if
    // the local row update fails, the ledger row below and ridego_refund_processed action still fire
    // (unconditionally, matching this function's pre-existing behaviour), so financial records stay
    // correct; only the booking row's own status field would be stale, which is audit-logged for a human
    // to reconcile rather than silently accepted.
    if ( $mark_refunded_ok === false && function_exists( 'ridego_audit_log' ) ) {
        ridego_audit_log( 'refund_processed_update_failed', 'booking', $booking_id, '',
            "Refund marked processed (txn {$transaction_id}) but the booking row failed to update ({$wpdb->last_error}) — payment_status may still show refund_pending.", 'critical' );
    }

    // Ledger row for the refund (once per booking) so client history and payment reports show money returned.
    if ( $pre && (float) $pre->refund_amount > 0 && function_exists( 'ridego_booking_payment_row' ) && ! (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_booking_payments WHERE booking_id=%d AND entry_type='refund'", (int) $booking_id ) ) ) {
        ridego_booking_payment_row( (int) $booking_id, 'refund', (float) $pre->refund_amount, $method ?: 'manual', $transaction_id, $note ?: 'Refund processed', (int) $by );
    }
    do_action( 'ridego_refund_processed', (int) $booking_id, 0 );
    if ( function_exists( 'ridego_maybe_close_booking' ) ) { ridego_maybe_close_booking( (int) $booking_id ); }

    return true;
}

// ============================================================================
// TRANSACTION LOGGING
// ============================================================================

/**
 * Log transaction to database.
 *
 * ROOT-CAUSE FIX (Wave 2B Task 5/7): this previously inserted into columns
 * 'gateway_id' and 'data', neither of which exist on ridego_transactions
 * (the real schema — see includes/install.php — has 'gateway_ref' and no
 * free-form data column). $wpdb->insert() against unknown columns fails
 * outright, so EVERY call to this function was silently a no-op and the
 * ridego_transactions ledger sat permanently empty — exactly why the
 * Financial dashboard (Task 7) never sourced from it. Fixed to match the
 * real schema; 'gateway_id' is still accepted as a back-compat input key
 * and any extra 'data' payload is folded into notes as JSON so nothing
 * callers already pass is silently dropped.
 *
 * @param array $data Transaction data
 * @return int Transaction ID (0 on failure)
 */
function ridego_log_transaction($data) {
    global $wpdb;

    $table = $wpdb->prefix . 'ridego_transactions';

    $gateway_ref = '';
    if ( ! empty($data['gateway_ref']) ) { $gateway_ref = (string) $data['gateway_ref']; }
    elseif ( ! empty($data['gateway_id']) ) { $gateway_ref = (string) $data['gateway_id']; }

    $notes = isset($data['notes']) ? (string) $data['notes'] : '';
    if ( ! empty($data['data']) ) {
        $extra = is_array($data['data']) ? wp_json_encode($data['data']) : (string) $data['data'];
        $notes = trim($notes . ' ' . $extra);
    }

    $inserted = $wpdb->insert($table, array(
        'type'        => sanitize_text_field($data['type'] ?? ''),
        'amount'      => floatval($data['amount'] ?? 0),
        'vendor_id'   => isset($data['vendor_id']) ? absint($data['vendor_id']) : null,
        'booking_id'  => isset($data['booking_id']) ? absint($data['booking_id']) : null,
        'gateway'     => sanitize_text_field($data['gateway'] ?? 'manual'),
        'gateway_ref' => $gateway_ref !== '' ? sanitize_text_field($gateway_ref) : null,
        'status'      => sanitize_text_field($data['status'] ?? 'pending'),
        'notes'       => sanitize_textarea_field($notes),
        'created_by'  => get_current_user_id(),
        'created_at'  => current_time('mysql')
    ), array('%s', '%f', '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s'));

    if ( $inserted === false ) {
        ridego_log( 'ridego_log_transaction insert failed: ' . $wpdb->last_error );
        return 0;
    }

    return $wpdb->insert_id;
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get booking details
 * 
 * @param int $booking_id Booking ID
 * @return object|null Booking object
 */
/* Canonical ridego_get_booking() lives in includes/helpers.php (loaded
   before payment.php) — it returns the fuller field set (joined vehicle
   and vendor columns) that the rest of the codebase relies on. The
   divergent bare-SELECT* copy that used to live here was removed: two
   function_exists()-guarded implementations with different field sets is
   exactly the kind of drift that causes "works in admin, breaks in
   payment flow" bugs, so there is now exactly one implementation. */

/**
 * Get booking number from ID
 * 
 * @param int $booking_id Booking ID
 * @return string Booking number
 */
function ridego_get_booking_number($booking_id) {
    
    $booking = ridego_get_booking($booking_id);
    
    return $booking ? $booking->booking_number : '';
}

/**
 * Get vendor details
 * 
 * @param int $vendor_id Vendor ID
 * @return object|null Vendor object
 */
/* NOTE: ridego_get_vendor() is defined in includes/helpers.php. This copy is a fallback. */
if ( ! function_exists('ridego_get_vendor') ) :
function ridego_get_vendor($vendor_id) {
    global $wpdb;
    
    $table = $wpdb->prefix . 'ridego_vendors';
    
    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE id = %d",
        $vendor_id
    ));
}
endif; // function_exists ridego_get_vendor

/* NOTE: ridego_distribute_booking_to_vendors() used to live here as an
   always-empty stub ("actual implementation in lead.php" — no such
   implementation ever existed) that both call sites above called
   directly, silently skipping vendor lead distribution on every
   Razorpay-confirmed booking. Removed: both call sites now fire
   do_action('ridego_booking_confirmed', $booking_id) instead, the same
   action every other confirmation path in this codebase already uses,
   which includes/lead.php's ridego_distribute_leads() is actually
   hooked to. */
