<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * RideGo → Diagnostics — a classic wp-admin PHP page (NOT the React SPA,
 * NOT a REST endpoint) so it keeps working even when the REST API itself
 * (/wp-json/) is completely unreachable — which is exactly the failure
 * mode it exists to diagnose. Everything here reads WordPress options,
 * the DB, and the filesystem directly; the one place it makes an HTTP
 * request is a server-to-itself wp_remote_get() loopback check, which is
 * deliberately a *test subject*, not something the page's own rendering
 * depends on.
 *
 * This plugin has no pre-existing classic wp-admin menu (its admin UI is
 * the React SPA served by includes/app-shell.php); this file registers
 * the first one, as a standalone top-level "RideGo" menu whose only page
 * is Diagnostics, deliberately independent of the SPA/REST stack.
 */

add_action( 'admin_menu', 'ridego_register_diagnostics_page' );
function ridego_register_diagnostics_page() {
    add_menu_page(
        'RideGo Diagnostics',
        'RideGo',
        'manage_options',
        'ridego-diagnostics',
        'ridego_render_diagnostics_page',
        'dashicons-admin-tools',
        58
    );
    add_submenu_page(
        'ridego-diagnostics',
        'RideGo Diagnostics',
        'Diagnostics',
        'manage_options',
        'ridego-diagnostics',
        'ridego_render_diagnostics_page'
    );
}

/* ------------------------------------------------------------------ *
 * Small result value object: every check below returns one of these.
 * ------------------------------------------------------------------ */
function ridego_diag_result( $status, $title, $explanation, $detail_lines = array() ) {
    return array(
        'status'      => $status, // 'pass' | 'fail' | 'info'
        'title'       => $title,
        'explanation' => $explanation,
        'details'     => $detail_lines, // array of plain strings
    );
}

/* ------------------------------------------------------------------ *
 * Check 1: Permalink structure
 * ------------------------------------------------------------------ */
function ridego_diag_check_permalinks() {
    $structure = get_option( 'permalink_structure' );
    if ( empty( $structure ) ) {
        return ridego_diag_result(
            'fail',
            'Permalink structure',
            'Permalinks are set to "Plain". The WordPress REST API (/wp-json/) and this plugin\'s own /routes/{slug} pages both require pretty permalinks to work — with Plain permalinks, those URLs 404. Fix: go to Settings → Permalinks in wp-admin, choose any option other than "Plain" (e.g. "Post name"), and click Save Changes (this also flushes the rewrite rules).',
            array( 'Current permalink_structure option: (empty / Plain)' )
        );
    }
    return ridego_diag_result(
        'pass',
        'Permalink structure',
        'Pretty permalinks are enabled, which the REST API and this plugin\'s route pages need.',
        array( 'Current permalink_structure option: ' . $structure )
    );
}

/* ------------------------------------------------------------------ *
 * Check 2: REST API reachability via a real server-to-itself HTTP
 * request (wp_remote_get). This is the core check for "REST 404s on
 * the live site" — it bypasses the browser entirely.
 * ------------------------------------------------------------------ */
function ridego_diag_self_request( $url ) {
    $response = wp_remote_get( $url, array(
        'timeout'     => 8,
        'redirection' => 3,
        'sslverify'   => false,
        'headers'     => array( 'User-Agent' => 'RideGo-Diagnostics/1.0' ),
    ) );

    if ( is_wp_error( $response ) ) {
        return array(
            'ok'    => false,
            'error' => $response->get_error_message(),
        );
    }

    $status = wp_remote_retrieve_response_code( $response );
    $body   = wp_remote_retrieve_body( $response );
    $trimmed = ltrim( (string) $body );
    $looks_like_json = isset( $trimmed[0] ) && ( $trimmed[0] === '{' || $trimmed[0] === '[' );

    return array(
        'ok'              => true,
        'status'          => $status,
        'looks_like_json' => $looks_like_json,
        'body_preview'    => function_exists( 'mb_substr' ) ? mb_substr( (string) $body, 0, 300 ) : substr( (string) $body, 0, 300 ),
    );
}

function ridego_diag_check_rest_reachability() {
    $wp_json_url    = rest_url();
    $ridego_url     = rest_url( 'ridego/v1/app/popular-routes' );

    $wp_json_result = ridego_diag_self_request( $wp_json_url );
    $ridego_result  = ridego_diag_self_request( $ridego_url );

    $details = array();
    $details[] = 'GET ' . $wp_json_url;
    if ( ! $wp_json_result['ok'] ) {
        $details[] = '  -> Request failed: ' . $wp_json_result['error'];
    } else {
        $details[] = '  -> HTTP ' . $wp_json_result['status'] . ( $wp_json_result['looks_like_json'] ? ' (looks like JSON)' : ' (NOT JSON)' );
        $details[] = '  -> Body preview: ' . str_replace( array( "\r", "\n" ), ' ', $wp_json_result['body_preview'] );
    }
    $details[] = '';
    $details[] = 'GET ' . $ridego_url;
    if ( ! $ridego_result['ok'] ) {
        $details[] = '  -> Request failed: ' . $ridego_result['error'];
    } else {
        $details[] = '  -> HTTP ' . $ridego_result['status'] . ( $ridego_result['looks_like_json'] ? ' (looks like JSON)' : ' (NOT JSON)' );
        $details[] = '  -> Body preview: ' . str_replace( array( "\r", "\n" ), ' ', $ridego_result['body_preview'] );
    }

    $wp_json_ok = $wp_json_result['ok'] && (int) $wp_json_result['status'] === 200 && $wp_json_result['looks_like_json'];
    $ridego_ok  = $ridego_result['ok'] && (int) $ridego_result['status'] === 200 && $ridego_result['looks_like_json'];

    if ( $wp_json_ok && $ridego_ok ) {
        return ridego_diag_result( 'pass', 'REST API reachability (server-side)', 'This server can reach its own /wp-json/ base and this plugin\'s own REST route, and both return real JSON.', $details );
    }

    if ( ! $wp_json_ok ) {
        $why = ! $wp_json_result['ok']
            ? 'The request itself failed (network/SSL/DNS-level problem on this server) — see the error above.'
            : ( (int) $wp_json_result['status'] === 404
                ? 'The base REST API returned 404. This is almost always: (a) pretty permalinks are off (see the Permalink check above), (b) the site\'s rewrite rules are stale (try re-saving Settings → Permalinks), or (c) a web-server rule (Nginx location block or .htaccess) is intercepting /wp-json/ before WordPress ever sees the request.'
                : 'The base REST API returned HTTP ' . $wp_json_result['status'] . ' instead of 200 — see the response body preview above for the likely cause (a security plugin block page, a maintenance-mode page, or a server error page all show up here).' );
        return ridego_diag_result( 'fail', 'REST API reachability (server-side)', 'The WordPress REST API base (/wp-json/) is NOT reachable from the server itself. ' . $why, $details );
    }

    // wp_json_ok but ridego route not ok
    $why = ! $ridego_result['ok']
        ? 'The request itself failed — see the error above.'
        : ( (int) $ridego_result['status'] === 404
            ? 'The base REST API works, but this specific RideGo route 404s. This points to the plugin\'s own rest_api_init hook not registering its routes on this request — check the "Plugin REST routes registered" and "PHP error log" checks below for a fatal error during plugin load.'
            : 'The base REST API works, but this RideGo route returned HTTP ' . $ridego_result['status'] . ' instead of 200 — see the body preview above.' );
    return ridego_diag_result( 'fail', 'REST API reachability (server-side)', 'The base WordPress REST API works, but this plugin\'s own REST route does not. ' . $why, $details );
}

/* ------------------------------------------------------------------ *
 * Check 3: Rewrite rules contain REST API rules
 * ------------------------------------------------------------------ */
function ridego_diag_check_rewrite_rules() {
    $rules = get_option( 'rewrite_rules' );
    if ( ! is_array( $rules ) || empty( $rules ) ) {
        return ridego_diag_result(
            'fail',
            'Rewrite rules (wp-json)',
            'The rewrite_rules option is empty or missing entirely. WordPress has not generated its rewrite rules yet (or they were wiped), so /wp-json/ and every other pretty-permalink URL on this site will 404. Fix: go to Settings → Permalinks in wp-admin and click Save Changes (no need to change the structure) to force WordPress to regenerate them.',
            array()
        );
    }
    $has_rest_rule = false;
    $sample = array();
    foreach ( $rules as $pattern => $rewrite ) {
        if ( strpos( $pattern, 'wp-json' ) !== false || strpos( $rewrite, 'rest_route' ) !== false ) {
            $has_rest_rule = true;
            if ( count( $sample ) < 3 ) {
                $sample[] = $pattern . '  =>  ' . $rewrite;
            }
        }
    }
    if ( ! $has_rest_rule ) {
        return ridego_diag_result(
            'fail',
            'Rewrite rules (wp-json)',
            'The site has ' . count( $rules ) . ' rewrite rule(s) saved, but none of them are for the REST API (wp-json). WordPress\'s own REST rewrite rule is missing, which will make /wp-json/... URLs 404. Fix: go to Settings → Permalinks and click Save Changes to regenerate the full rule set.',
            array( 'Total rewrite rules found: ' . count( $rules ) )
        );
    }
    return ridego_diag_result(
        'pass',
        'Rewrite rules (wp-json)',
        'The REST API\'s rewrite rule is present in the saved rewrite rules.',
        array_merge( array( 'Total rewrite rules found: ' . count( $rules ), 'Example wp-json rule(s):' ), $sample )
    );
}

/* ------------------------------------------------------------------ *
 * Check 4: .htaccess / web server
 * ------------------------------------------------------------------ */
function ridego_diag_check_htaccess() {
    $path = defined( 'ABSPATH' ) ? ABSPATH . '.htaccess' : '';
    $is_apache = isset( $_SERVER['SERVER_SOFTWARE'] ) && stripos( $_SERVER['SERVER_SOFTWARE'], 'apache' ) !== false;

    if ( ! $path || ! file_exists( $path ) || ! is_readable( $path ) ) {
        return ridego_diag_result(
            'info',
            '.htaccess / web server rules',
            $is_apache
                ? 'No readable .htaccess file was found at the site root, or the PHP process does not have permission to read it, so this check could not inspect it directly.'
                : 'No .htaccess file was found (this server does not look like Apache — likely Nginx). Nginx configuration lives outside anything PHP can read. Please check your nginx site config for a "location" block matching /wp-json/, /wp-json/*, or a regex covering it, that returns 404/403 or otherwise does not proxy through to WordPress\'s index.php — that is a common way a working WordPress install still 404s on the REST API.',
            array()
        );
    }

    $contents = file_get_contents( $path );
    if ( $contents === false ) {
        return ridego_diag_result( 'info', '.htaccess / web server rules', 'A .htaccess file exists but could not be read.', array() );
    }

    $flags = array();
    $lines = preg_split( '/\r\n|\r|\n/', $contents );
    foreach ( $lines as $i => $line ) {
        $trimmed = trim( $line );
        if ( $trimmed === '' || $trimmed[0] === '#' ) { continue; }
        if ( stripos( $trimmed, 'wp-json' ) !== false ) {
            $flags[] = 'Line ' . ( $i + 1 ) . ' mentions wp-json: ' . $trimmed;
        } elseif ( stripos( $trimmed, 'xmlrpc' ) !== false ) {
            $flags[] = 'Line ' . ( $i + 1 ) . ' mentions xmlrpc (unrelated to REST, but worth reviewing for over-broad blocking): ' . $trimmed;
        } elseif ( preg_match( '/RewriteRule.*\b(403|404)\b/i', $trimmed ) ) {
            $flags[] = 'Line ' . ( $i + 1 ) . ' is a blanket 403/404 RewriteRule that could match more than intended: ' . $trimmed;
        }
    }

    if ( ! empty( $flags ) ) {
        return ridego_diag_result(
            'fail',
            '.htaccess / web server rules',
            'The site\'s .htaccess contains rule(s) that reference wp-json or look like a blanket block/redirect. One of these may be blocking the REST API before WordPress ever handles the request. Review and, if not intentional, remove or narrow the rule(s) listed below, then re-test.',
            $flags
        );
    }

    return ridego_diag_result(
        'pass',
        '.htaccess / web server rules',
        'The site\'s .htaccess was readable and contains no rules that obviously block or redirect wp-json.',
        array()
    );
}

/* ------------------------------------------------------------------ *
 * Check 5: Known REST-blocking security plugins active
 * ------------------------------------------------------------------ */
function ridego_diag_check_known_blocking_plugins() {
    $known = array(
        'wordfence'                            => 'Wordfence',
        'better-wp-security'                   => 'iThemes Security / Solid Security',
        'it-l10n-ithemes-security-pro'         => 'iThemes Security Pro / Solid Security Pro',
        'all-in-one-wp-security-and-firewall'  => 'All In One WP Security',
        'sucuri-scanner'                       => 'Sucuri Security',
        'disable-rest-api'                     => 'Disable REST API',
        'rest-api-toggle'                      => 'REST API Toggle',
        'wps-hide-login'                       => 'WP Hide & Security Enhancer (login-hiding variant)',
        'wp-hide-security-enhancer'            => 'WP Hide & Security Enhancer',
        'wp-hide'                              => 'WP Hide & Security Enhancer',
        'wp-cerber'                            => 'WP Cerber Security',
        'shield-security'                      => 'Shield Security',
        'wp-simple-firewall'                   => 'Shield Security (legacy slug)',
    );

    $active_plugins = (array) get_option( 'active_plugins', array() );
    if ( is_multisite() ) {
        $active_plugins = array_merge( $active_plugins, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
    }

    $found = array();
    foreach ( $active_plugins as $p ) {
        $slug = strtolower( dirname( $p ) );
        foreach ( $known as $needle => $name ) {
            if ( $slug === $needle || strpos( $slug, $needle ) === 0 ) {
                $found[ $name ] = true;
            }
        }
    }

    if ( ! empty( $found ) ) {
        $names = array_keys( $found );
        return ridego_diag_result(
            'fail',
            'Known REST-blocking plugins',
            implode( ', ', $names ) . ' — active, and commonly ships a "disable/restrict REST API" or firewall setting. Open its settings and look for a REST API / firewall / hardening section, and check whether it is blocking or rate-limiting /wp-json/ requests (especially unauthenticated ones, which this plugin\'s public routes need).',
            array( 'Detected: ' . implode( ', ', $names ) )
        );
    }

    return ridego_diag_result(
        'pass',
        'Known REST-blocking plugins',
        'None of the commonly REST-blocking security/firewall plugins were found active.',
        array( 'Active plugin count: ' . count( $active_plugins ) )
    );
}

/* ------------------------------------------------------------------ *
 * Check 6: REST disabled via filter (best-effort, honest about limits)
 * ------------------------------------------------------------------ */
function ridego_diag_check_rest_filters() {
    global $wp_filter;

    $details = array();
    $suspicious = array();

    $watched = array( 'rest_authentication_errors', 'rest_enabled', 'rest_jsonp_enabled' );
    foreach ( $watched as $hook ) {
        $count = 0;
        if ( isset( $wp_filter[ $hook ] ) && is_object( $wp_filter[ $hook ] ) && method_exists( $wp_filter[ $hook ], 'callbacks' ) ) {
            foreach ( $wp_filter[ $hook ]->callbacks as $priority => $cbs ) { $count += count( $cbs ); }
        } elseif ( isset( $wp_filter[ $hook ] ) && is_array( $wp_filter[ $hook ] ) ) {
            foreach ( $wp_filter[ $hook ] as $priority => $cbs ) { $count += count( $cbs ); }
        }
        $details[] = $hook . ': ' . $count . ' callback(s) attached';
        if ( $count > 0 ) { $suspicious[] = $hook; }
    }

    $details[] = 'Note: WordPress core only fires rest_api_init the first time something (this plugin, core, or another plugin) actually asks for the REST server, not on every request — so it deliberately has NOT fired yet at this point on a normal wp-admin page, and that is not itself a fault. The "Plugin REST routes registered" check below is the reliable way to confirm rest_api_init runs and does its job; it forces that by asking the REST server for its route table.';
    $details[] = 'This check can only see whether something has hooked the filters below, not what each callback actually does — a callback could be a harmless no-op, or it could be the thing blocking REST. Treat "callbacks attached" as a lead to investigate (check other active plugins/theme functions.php for these hook names), not a confirmed cause.';

    if ( ! empty( $suspicious ) ) {
        return ridego_diag_result(
            'info',
            'REST disabled via filter',
            'Something on this site has hooked ' . implode( ', ', $suspicious ) . '. This is not necessarily a problem (some plugins hook these for legitimate reasons), but if REST is broken, this is worth checking directly by temporarily deactivating other plugins one at a time.',
            $details
        );
    }

    return ridego_diag_result(
        'pass',
        'REST disabled via filter',
        'Nothing on this site has hooked the filters most commonly used to force-disable the REST API.',
        $details
    );
}

/* ------------------------------------------------------------------ *
 * Check 7: Plugin's own REST routes registered
 * ------------------------------------------------------------------ */
function ridego_diag_check_own_routes_registered() {
    if ( ! function_exists( 'rest_get_server' ) ) {
        return ridego_diag_result( 'fail', 'Plugin REST routes registered', 'The WordPress REST API server class is not available on this request.', array() );
    }

    $server = rest_get_server();
    $routes = $server->get_routes();

    $expected = array(
        '/ridego/v1/app/popular-routes',
        '/ridego/v1/app/home',
        '/ridego/v1/diagnostic',
    );

    $found = array();
    $missing = array();
    foreach ( $expected as $route ) {
        if ( isset( $routes[ $route ] ) ) {
            $found[] = $route;
        } else {
            $missing[] = $route;
        }
    }

    $ridego_route_count = 0;
    foreach ( $routes as $route => $handlers ) {
        if ( strpos( $route, '/ridego/' ) === 0 ) { $ridego_route_count++; }
    }

    $details = array(
        'Total routes registered on this request: ' . count( $routes ),
        'Total /ridego/... routes registered: ' . $ridego_route_count,
        'Found: ' . ( $found ? implode( ', ', $found ) : '(none)' ),
        'Missing: ' . ( $missing ? implode( ', ', $missing ) : '(none)' ),
    );

    if ( $ridego_route_count === 0 ) {
        return ridego_diag_result(
            'fail',
            'Plugin REST routes registered',
            'Zero /ridego/... routes are registered at all, meaning this plugin\'s rest_api_init hook never ran or registered nothing on this request. The most common cause is a PHP fatal error earlier in plugin load (check the PHP error log check below), or the plugin being inactive. Since this diagnostics page itself is part of the plugin and is running, the plugin IS active — so look for a fatal error thrown partway through loading one of its includes/*.php files.',
            $details
        );
    }

    if ( ! empty( $missing ) ) {
        return ridego_diag_result(
            'fail',
            'Plugin REST routes registered',
            'Some but not all of this plugin\'s core routes are registered (' . $ridego_route_count . ' /ridego/ routes total). This points to a PHP error partway through registering routes in one specific file rather than a total REST failure — check the PHP error log check below.',
            $details
        );
    }

    return ridego_diag_result(
        'pass',
        'Plugin REST routes registered',
        'This plugin\'s core REST routes are registered and present in the WordPress REST server\'s route table.',
        $details
    );
}

/* ------------------------------------------------------------------ *
 * Check 8: Migration / schema state
 * ------------------------------------------------------------------ */
function ridego_diag_check_schema_state() {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_route_pages';

    $details = array();

    $table_exists = function_exists( 'ridego_table_exists' ) ? ridego_table_exists( $tbl ) : ( $wpdb->get_var( "SHOW TABLES LIKE '{$tbl}'" ) === $tbl );
    $details[] = 'Table ' . $tbl . ' exists: ' . ( $table_exists ? 'yes' : 'NO' );

    $has_card_image_col = false;
    if ( $table_exists ) {
        $col = $wpdb->get_results( "SHOW COLUMNS FROM {$tbl} LIKE 'card_image_url'" );
        $has_card_image_col = ! empty( $col );
        $details[] = 'Column card_image_url present: ' . ( $has_card_image_col ? 'yes' : 'NO' );
    }

    $stored_version = (int) get_option( 'ridego_schema_version', 0 );

    $latest_in_code = defined( 'RIDEGO_SCHEMA_VERSION' ) ? (int) RIDEGO_SCHEMA_VERSION : 0;
    if ( function_exists( 'ridego_get_migrations' ) ) {
        foreach ( ridego_get_migrations() as $m ) {
            if ( isset( $m['version'] ) && (int) $m['version'] > $latest_in_code ) {
                $latest_in_code = (int) $m['version'];
            }
        }
    }

    $details[] = 'Stored ridego_schema_version option: ' . $stored_version;
    $details[] = 'Highest migration version found in code (max of RIDEGO_SCHEMA_VERSION and the migrations list): ' . $latest_in_code;

    $behind = $stored_version < $latest_in_code;

    if ( ! $table_exists ) {
        return ridego_diag_result(
            'fail',
            'Migration / schema state',
            'The ' . $tbl . ' table does not exist at all. Route Pages (and this plugin\'s Popular Routes feature) cannot work. This means migrations never ran on this install — likely the plugin\'s activation hook did not fire (e.g. the plugin was uploaded via FTP and only later "activated" in a way that skipped the hook, or migrations are silently failing). Fix: deactivate and reactivate the plugin from the Plugins screen, or trigger a migration run (e.g. by bumping ridego_schema_version down via wp-cli/DB and reloading any admin page).',
            $details
        );
    }

    if ( $behind ) {
        return ridego_diag_result(
            'fail',
            'Migration / schema state',
            'The stored schema version (' . $stored_version . ') is behind the highest migration defined in the plugin\'s code (' . $latest_in_code . '). Migrations have not fully run on this install, so newer columns/tables (e.g. card_image_url from migration 43) may be missing, which can cause errors or missing data in admin screens and the API. Fix: deactivate and reactivate the plugin, or open any wp-admin page (migrations run automatically on admin_init/init once the stored version is behind) and confirm the version updates.',
            $details
        );
    }

    if ( ! $has_card_image_col ) {
        return ridego_diag_result(
            'fail',
            'Migration / schema state',
            'The schema version looks current (' . $stored_version . '), but the card_image_url column from migration 43 is still missing on ' . $tbl . '. This is an inconsistent state — the migration runner may have partially failed. Check the PHP error log for a migration error, then try deactivating/reactivating the plugin.',
            $details
        );
    }

    return ridego_diag_result(
        'pass',
        'Migration / schema state',
        'The route pages table exists with all expected columns, and the stored schema version (' . $stored_version . ') matches the latest migration in code.',
        $details
    );
}

/* ------------------------------------------------------------------ *
 * Check 9: Route data sanity — published-but-hidden routes
 * ------------------------------------------------------------------ */
function ridego_diag_check_route_data_sanity() {
    global $wpdb;
    $ptbl = $wpdb->prefix . 'ridego_route_pages';
    $rtbl = $wpdb->prefix . 'ridego_routes';

    if ( ! function_exists( 'ridego_table_exists' ) || ! ridego_table_exists( $ptbl ) || ! ridego_table_exists( $rtbl ) ) {
        return ridego_diag_result( 'info', 'Route data sanity', 'Route pages and/or routes table do not exist yet, so there is no route data to check.', array() );
    }

    $total_pages = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$ptbl}" );
    $published   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$ptbl} WHERE status = %s", 'published' ) );

    $hidden_rows = $wpdb->get_results(
        "SELECT p.slug, r.from_city, r.to_city
         FROM {$ptbl} p
         INNER JOIN {$rtbl} r ON r.id = p.route_id
         WHERE p.status = 'published' AND r.is_active = 0"
    );

    $details = array(
        'Total route pages: ' . $total_pages,
        'Published route pages: ' . $published,
        'Published-but-route-inactive (hidden from Home Page): ' . count( $hidden_rows ),
    );

    if ( ! empty( $hidden_rows ) ) {
        $names = array();
        foreach ( $hidden_rows as $r ) {
            $names[] = $r->from_city . ' → ' . $r->to_city . ' (/' . $r->slug . ')';
        }
        return ridego_diag_result(
            'fail',
            'Route data sanity',
            count( $hidden_rows ) . ' route page(s) are published but their underlying route is deactivated, so they will not appear in Popular Routes even though the page itself is live. Reactivate the route (Settings → Routes) or unpublish the page if it should stay hidden.',
            array_merge( $details, array( 'Affected routes:' ), $names )
        );
    }

    return ridego_diag_result(
        'pass',
        'Route data sanity',
        'No published route pages are hidden by a deactivated route.',
        $details
    );
}

/* ------------------------------------------------------------------ *
 * Check 10: PHP error log tail
 * ------------------------------------------------------------------ */
function ridego_diag_check_error_log() {
    if ( ! defined( 'WP_DEBUG_LOG' ) || ! WP_DEBUG_LOG ) {
        return ridego_diag_result(
            'info',
            'PHP error log (debug.log)',
            'WP_DEBUG_LOG is not enabled, so there is no wp-content/debug.log to inspect. If you suspect a fatal PHP error, add define(\'WP_DEBUG\', true); and define(\'WP_DEBUG_LOG\', true); to wp-config.php temporarily, reproduce the issue, then check this page again.',
            array()
        );
    }

    $log_path = WP_CONTENT_DIR . '/debug.log';
    if ( ! file_exists( $log_path ) || ! is_readable( $log_path ) ) {
        return ridego_diag_result( 'info', 'PHP error log (debug.log)', 'WP_DEBUG_LOG is enabled, but wp-content/debug.log does not exist yet or is not readable.', array() );
    }

    $size = filesize( $log_path );
    $chunk = 65536; // read the last 64KB, which is plenty for ~20 lines
    $handle = fopen( $log_path, 'r' );
    $lines = array();
    if ( $handle ) {
        $seek = max( 0, $size - $chunk );
        fseek( $handle, $seek );
        $data = fread( $handle, $chunk );
        fclose( $handle );
        $all_lines = preg_split( '/\r\n|\r|\n/', $data );
        $relevant = array();
        foreach ( $all_lines as $line ) {
            if ( $line === '' ) { continue; }
            if ( stripos( $line, 'ridego' ) !== false || stripos( $line, 'fatal' ) !== false ) {
                $relevant[] = $line;
            }
        }
        $lines = array_slice( $relevant, -20 );
    }

    if ( empty( $lines ) ) {
        return ridego_diag_result(
            'pass',
            'PHP error log (debug.log)',
            'debug.log is readable and contains no recent lines mentioning "ridego" or "fatal".',
            array( 'Log file size: ' . size_format( $size ) )
        );
    }

    return ridego_diag_result(
        'info',
        'PHP error log (debug.log)',
        'Found recent log lines mentioning "ridego" or "fatal" — review these for a root cause (a fatal error here, occurring during plugin load, would explain REST routes never registering).',
        $lines
    );
}

/* ------------------------------------------------------------------ *
 * Run every check
 * ------------------------------------------------------------------ */
function ridego_run_all_diagnostics() {
    return array(
        ridego_diag_check_permalinks(),
        ridego_diag_check_rest_reachability(),
        ridego_diag_check_rewrite_rules(),
        ridego_diag_check_htaccess(),
        ridego_diag_check_known_blocking_plugins(),
        ridego_diag_check_rest_filters(),
        ridego_diag_check_own_routes_registered(),
        ridego_diag_check_schema_state(),
        ridego_diag_check_route_data_sanity(),
        ridego_diag_check_error_log(),
    );
}

/* ------------------------------------------------------------------ *
 * Render
 * ------------------------------------------------------------------ */
function ridego_render_diagnostics_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'You do not have permission to view this page.' );
    }

    $results = ridego_run_all_diagnostics();

    $pass_count = count( array_filter( $results, function ( $r ) { return $r['status'] === 'pass'; } ) );
    $fail_count = count( array_filter( $results, function ( $r ) { return $r['status'] === 'fail'; } ) );
    $info_count = count( array_filter( $results, function ( $r ) { return $r['status'] === 'info'; } ) );

    $plain_text_lines = array();
    $plain_text_lines[] = 'RideGo Diagnostics Report';
    $plain_text_lines[] = 'Generated: ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC';
    $plain_text_lines[] = 'Site: ' . home_url( '/' );
    $plain_text_lines[] = 'Summary: ' . $pass_count . ' pass, ' . $fail_count . ' fail, ' . $info_count . ' info';
    $plain_text_lines[] = str_repeat( '=', 60 );
    foreach ( $results as $r ) {
        $plain_text_lines[] = '';
        $plain_text_lines[] = '[' . strtoupper( $r['status'] ) . '] ' . $r['title'];
        $plain_text_lines[] = $r['explanation'];
        foreach ( $r['details'] as $d ) {
            $plain_text_lines[] = '    ' . $d;
        }
    }
    $plain_text_report = implode( "\n", $plain_text_lines );
    ?>
    <div class="wrap">
        <h1><span class="dashicons dashicons-admin-tools" style="font-size:28px;width:28px;height:28px;margin-right:6px;"></span>RideGo Diagnostics</h1>
        <p>This page runs entirely on the server (no REST API call is required to load it), so it works even when <code>/wp-json/</code> itself is broken.</p>

        <div class="notice <?php echo $fail_count > 0 ? 'notice-error' : 'notice-success'; ?>" style="padding:12px 16px;">
            <p style="font-size:15px;margin:0;">
                <strong><?php echo esc_html( $pass_count ); ?> passed</strong>
                &nbsp;&middot;&nbsp;
                <strong style="color:<?php echo $fail_count > 0 ? '#b32d2e' : 'inherit'; ?>;"><?php echo esc_html( $fail_count ); ?> failed</strong>
                &nbsp;&middot;&nbsp;
                <strong><?php echo esc_html( $info_count ); ?> info</strong>
                &nbsp;&mdash;&nbsp;generated <?php echo esc_html( gmdate( 'Y-m-d H:i:s' ) ); ?> UTC
            </p>
        </div>

        <p>
            <button type="button" class="button button-primary" id="ridego-copy-report">Copy diagnostic report</button>
            <span id="ridego-copy-status" style="margin-left:10px;color:#2271b1;"></span>
        </p>

        <div id="ridego-diagnostics-results">
        <?php foreach ( $results as $r ) :
            $notice_class = 'notice-info';
            $badge_bg = '#787c82';
            $badge_label = 'INFO';
            if ( $r['status'] === 'pass' ) { $notice_class = 'notice-success'; $badge_bg = '#00a32a'; $badge_label = 'PASS'; }
            if ( $r['status'] === 'fail' ) { $notice_class = 'notice-error'; $badge_bg = '#d63638'; $badge_label = 'FAIL'; }
            ?>
            <div class="notice <?php echo esc_attr( $notice_class ); ?>" style="padding:14px 16px;margin:0 0 14px 0;">
                <p style="margin-top:0;">
                    <span style="display:inline-block;min-width:44px;text-align:center;padding:2px 8px;border-radius:3px;color:#fff;font-weight:600;font-size:11px;letter-spacing:.5px;background:<?php echo esc_attr( $badge_bg ); ?>;"><?php echo esc_html( $badge_label ); ?></span>
                    <strong style="font-size:14px;margin-left:8px;"><?php echo esc_html( $r['title'] ); ?></strong>
                </p>
                <p><?php echo esc_html( $r['explanation'] ); ?></p>
                <?php if ( ! empty( $r['details'] ) ) : ?>
                    <details>
                        <summary style="cursor:pointer;color:#2271b1;">Technical detail</summary>
                        <pre style="white-space:pre-wrap;background:#f6f7f7;padding:10px;border-radius:3px;margin-top:8px;font-size:12px;"><?php echo esc_html( implode( "\n", $r['details'] ) ); ?></pre>
                    </details>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        </div>

        <textarea id="ridego-report-text" style="position:absolute;left:-9999px;top:-9999px;" readonly><?php echo esc_textarea( $plain_text_report ); ?></textarea>
    </div>
    <script>
    (function () {
        var btn = document.getElementById('ridego-copy-report');
        var status = document.getElementById('ridego-copy-status');
        var textarea = document.getElementById('ridego-report-text');
        if (!btn) { return; }
        btn.addEventListener('click', function () {
            var done = function (ok) {
                status.textContent = ok ? 'Copied to clipboard.' : 'Could not copy automatically — please select and copy manually.';
                if (ok) { setTimeout(function () { status.textContent = ''; }, 4000); }
            };
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(textarea.value).then(function () { done(true); }, function () { legacyCopy(); });
            } else {
                legacyCopy();
            }
            function legacyCopy() {
                try {
                    textarea.style.position = 'fixed';
                    textarea.style.left = '0';
                    textarea.style.top = '0';
                    textarea.focus();
                    textarea.select();
                    var ok = document.execCommand('copy');
                    textarea.style.position = 'absolute';
                    textarea.style.left = '-9999px';
                    textarea.style.top = '-9999px';
                    done(ok);
                } catch (e) {
                    done(false);
                }
            }
        });
    })();
    </script>
    <?php
}
