<?php
/**
 * Branding & Business Information: the ONE place company-specific details live.
 *
 * Configuration (Settings → Branding & business) → ridego_brand() → every screen, email, SMS/WhatsApp text, receipt, footer, PWA manifest and page title.
 * Nothing else in the plugin or the React app should contain the brand name, contact details, address, hours, links or copyright line as literal text.
 * Placeholders inside stored values: {brand} {year} {support_phone} {support_email} {website}.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: nothing → the branding fields: field key => array(setting key, kind, label, group, help) → array. Pure. `kind` is text|textarea|url|email|phone. Several fields reuse settings that already existed (platform_name, support_phone, ...), so old data keeps working.
function ridego_branding_fields() {
    return array(
        'name'             => array( 'setting' => 'platform_name',            'kind' => 'text',     'group' => 'Brand',    'label' => 'Brand name',                 'help' => 'Shown in the header, page title, emails, SMS and receipts.' ),
        'tagline'          => array( 'setting' => 'platform_tagline',         'kind' => 'text',     'group' => 'Brand',    'label' => 'Tagline',                    'help' => '' ),
        'legal_name'       => array( 'setting' => 'invoice_company_name',     'kind' => 'text',     'group' => 'Brand',    'label' => 'Legal / company name',       'help' => 'Used on receipts and legal pages. Falls back to the brand name.' ),
        'logo_url'         => array( 'setting' => 'brand_logo_url',           'kind' => 'url',      'group' => 'Brand',    'label' => 'Logo',                       'help' => 'Header logo. Leave blank to show the brand name as text.' ),
        'favicon_url'      => array( 'setting' => 'brand_favicon_url',        'kind' => 'url',      'group' => 'Brand',    'label' => 'Favicon',                    'help' => 'Browser tab icon (png, jpg, ico or webp).' ),
        'hero_image_url'   => array( 'setting' => 'brand_hero_image_url',     'kind' => 'url',      'group' => 'Home page', 'label' => 'Hero background image',    'help' => 'Shown behind the main headline on the home page. Leave blank for the plain brand-color gradient.' ),
        'hero_headline'    => array( 'setting' => 'brand_hero_headline',      'kind' => 'text',     'group' => 'Home page', 'label' => 'Hero headline',             'help' => 'The big heading on the home page hero. Leave blank to use the default.' ),
        'hero_subtext'     => array( 'setting' => 'brand_hero_subtext',       'kind' => 'textarea', 'group' => 'Home page', 'label' => 'Hero subtext',              'help' => 'The line under the headline. Leave blank to use the default, or clear it and save an empty value to hide it.' ),
        'hero_show_text'   => array( 'setting' => 'brand_hero_show_text',     'kind' => 'select',   'group' => 'Home page', 'label' => 'Hero text',                 'help' => 'Show or hide the headline, subtext, trust badges and stats row on the hero.', 'options' => array( 'show' => 'Show', 'hide' => 'Hide (image only)' ) ),
        'hero_overlay'     => array( 'setting' => 'brand_hero_overlay',       'kind' => 'select',   'group' => 'Home page', 'label' => 'Hero overlay darkening',    'help' => 'A dark tint over the hero image so white text stays readable.', 'options' => array( 'none' => 'None (no overlay)', 'light' => 'Light', 'medium' => 'Medium (default)', 'strong' => 'Strong' ) ),
        'hero_secondary_image_url' => array( 'setting' => 'brand_hero_secondary_image_url', 'kind' => 'url', 'group' => 'Home page', 'label' => 'Second hero image', 'help' => 'A wide banner image for the "Outstation trips" section midway down the home page. Leave blank to hide that section.' ),
        'hero_secondary_height' => array( 'setting' => 'brand_hero_secondary_height', 'kind' => 'number', 'group' => 'Home page', 'label' => 'Second hero height (px)', 'help' => 'The exact height of the second hero banner, in pixels. Leave blank for the default (320px).', 'min' => 80, 'max' => 900 ),
        'hero_secondary_fit' => array( 'setting' => 'brand_hero_secondary_fit', 'kind' => 'select', 'group' => 'Home page', 'label' => 'Second hero image fit', 'help' => 'How the image fills the banner: Cover crops to fill, Contain shows the whole image, Fill stretches it.', 'options' => array( 'cover' => 'Cover (default)', 'contain' => 'Contain', 'fill' => 'Fill' ) ),
        'vehicle_card_height' => array( 'setting' => 'brand_vehicle_card_height', 'kind' => 'number', 'group' => 'Vehicle images', 'label' => 'Vehicle card image height (px)', 'help' => 'The exact image box height on the "Choose your ride" cards (home page) and search results, in pixels. Leave blank for the default (144px).', 'min' => 60, 'max' => 600 ),
        'vehicle_card_fit'    => array( 'setting' => 'brand_vehicle_card_fit',    'kind' => 'select', 'group' => 'Vehicle images', 'label' => 'Vehicle card image fit',    'help' => 'How the vehicle photo fills its card: Contain shows the whole vehicle (default, best for car photos with white space), Cover crops to fill, Fill stretches it.', 'options' => array( 'contain' => 'Contain (default)', 'cover' => 'Cover', 'fill' => 'Fill' ) ),
        'vehicle_detail_height' => array( 'setting' => 'brand_vehicle_detail_height', 'kind' => 'number', 'group' => 'Vehicle images', 'label' => 'Vehicle detail page image height (px)', 'help' => 'The exact image box height on an individual vehicle type\'s page, in pixels. Leave blank for the default (440px).', 'min' => 100, 'max' => 900 ),
        'vehicle_detail_fit'    => array( 'setting' => 'brand_vehicle_detail_fit',    'kind' => 'select', 'group' => 'Vehicle images', 'label' => 'Vehicle detail page image fit', 'help' => 'How the vehicle photo fills the banner on its own page: Cover crops to fill with no distortion (default), Contain shows the whole image, Fill stretches it edge to edge (can distort the photo since the box\'s width changes by screen size but its height does not).', 'options' => array( 'cover' => 'Cover (default)', 'contain' => 'Contain', 'fill' => 'Fill' ) ),
        'support_phone'    => array( 'setting' => 'support_phone',            'kind' => 'phone',    'group' => 'Contact',  'label' => 'Contact number',             'help' => '' ),
        'support_whatsapp' => array( 'setting' => 'support_whatsapp',         'kind' => 'phone',    'group' => 'Contact',  'label' => 'WhatsApp number',            'help' => 'With country code, e.g. 919876543210.' ),
        'support_email'    => array( 'setting' => 'brand_support_email',      'kind' => 'email',    'group' => 'Contact',  'label' => 'Support email',              'help' => 'Shown to customers and vendors. Falls back to the site admin email.' ),
        'address'          => array( 'setting' => 'invoice_company_address',  'kind' => 'textarea', 'group' => 'Contact',  'label' => 'Business address',           'help' => '' ),
        'website_url'      => array( 'setting' => 'brand_website_url',        'kind' => 'url',      'group' => 'Contact',  'label' => 'Website URL',                'help' => 'Falls back to this site\'s address.' ),
        'business_hours'   => array( 'setting' => 'brand_business_hours',     'kind' => 'textarea', 'group' => 'Contact',  'label' => 'Business hours',             'help' => 'e.g. Mon-Sat 9:00 AM to 8:00 PM.' ),
        'social_facebook'  => array( 'setting' => 'brand_social_facebook',    'kind' => 'url',      'group' => 'Social',   'label' => 'Facebook',                   'help' => '' ),
        'social_instagram' => array( 'setting' => 'brand_social_instagram',   'kind' => 'url',      'group' => 'Social',   'label' => 'Instagram',                  'help' => '' ),
        'social_twitter'   => array( 'setting' => 'brand_social_twitter',     'kind' => 'url',      'group' => 'Social',   'label' => 'X (Twitter)',                'help' => '' ),
        'social_youtube'   => array( 'setting' => 'brand_social_youtube',     'kind' => 'url',      'group' => 'Social',   'label' => 'YouTube',                    'help' => '' ),
        'social_linkedin'  => array( 'setting' => 'brand_social_linkedin',    'kind' => 'url',      'group' => 'Social',   'label' => 'LinkedIn',                   'help' => '' ),
        'copyright'        => array( 'setting' => 'brand_copyright',          'kind' => 'text',     'group' => 'Legal',    'label' => 'Copyright line',             'help' => 'Placeholders: {year}, {brand}.' ),
        'legal_info'       => array( 'setting' => 'brand_legal_info',         'kind' => 'textarea', 'group' => 'Legal',    'label' => 'Legal / company information','help' => 'Registration numbers, licences and similar, shown in the footer.' ),
        'gstin'            => array( 'setting' => 'invoice_gstin',            'kind' => 'text',     'group' => 'Legal',    'label' => 'GSTIN',                      'help' => '' ),
        'footer_note'      => array( 'setting' => 'brand_footer_note',        'kind' => 'textarea', 'group' => 'Legal',    'label' => 'Footer note',                'help' => '' ),
        'email_from_name'  => array( 'setting' => 'brand_email_from_name',    'kind' => 'text',     'group' => 'Messages', 'label' => 'Email sender name',          'help' => 'Falls back to the brand name.' ),
        'email_from_address' => array( 'setting' => 'brand_email_from_address', 'kind' => 'email',  'group' => 'Messages', 'label' => 'Email sender address',       'help' => 'Falls back to the site admin email.' ),
        'email_signature'  => array( 'setting' => 'brand_email_signature',    'kind' => 'textarea', 'group' => 'Messages', 'label' => 'Email / message signature',  'help' => 'Placeholder: {brand}.' ),
    );
}

// TRACE: nothing → the built-in fallback for a branding field when nothing is saved (some depend on other fields) → string. Pure apart from reading other settings. Unknown key → ''.
function ridego_branding_default( $field ) {
    switch ( $field ) {
        case 'name':               return 'RideGo';
        case 'legal_name':         return (string) ridego_brand( 'name' );
        case 'support_email':      return (string) ( ridego_get_setting( 'admin_email', '' ) ?: get_option( 'admin_email' ) );
        case 'website_url':        return esc_url_raw( home_url( '/' ) );
        case 'copyright':          return '© {year} {brand}. All rights reserved.';
        case 'email_from_name':    return (string) ridego_brand( 'name' );
        case 'email_from_address': return (string) get_option( 'admin_email' );
        case 'email_signature':    return 'Team {brand}';
        case 'hero_headline':      return 'Travel anywhere, with confidence.';
        case 'hero_show_text':     return 'show';
        case 'hero_overlay':       return 'medium';
        case 'hero_secondary_height': return '320';
        case 'hero_secondary_fit':    return 'cover';
        case 'vehicle_card_height':   return '144';
        case 'vehicle_card_fit':      return 'contain';
        case 'vehicle_detail_height': return '440';
        case 'vehicle_detail_fit':    return 'cover';
        default:                   return '';
    }
}

// TRACE: text with {brand} {year} {support_phone} {support_email} {website} placeholders → the text with the current values filled in → string. Pure apart from reading settings. Edge cases: unknown placeholder left as is; empty text → ''.
function ridego_brand_expand( $text ) {
    $text = (string) $text;
    if ( $text === '' || strpos( $text, '{' ) === false ) { return $text; }
    return strtr( $text, array( '{brand}' => (string) ridego_brand( 'name' ), '{year}' => wp_date( 'Y' ), '{support_phone}' => (string) ridego_brand( 'support_phone' ),
        '{support_email}' => (string) ridego_brand( 'support_email' ), '{website}' => (string) ridego_brand( 'website_url' ) ) );
}

// TRACE: field key (see ridego_branding_fields) → the saved value, or the fallback when blank, with placeholders expanded → string. The ONE reader for branding. Unknown field → ''.
//        Recursion guard: the fallback of a field may read another field, never itself.
function ridego_brand( $field ) {
    static $busy = array();
    $f = ridego_branding_fields();
    if ( ! isset( $f[ $field ] ) || isset( $busy[ $field ] ) ) { return ''; }
    $busy[ $field ] = true;
    $v = trim( (string) ridego_get_setting( $f[ $field ]['setting'], '' ) );
    if ( $v === '' ) { $v = (string) ridego_branding_default( $field ); }
    unset( $busy[ $field ] );
    return in_array( $field, array( 'name', 'legal_name' ), true ) ? $v : ridego_brand_expand( $v );
}

// TRACE: nothing → the brand name (shortcut used inside sentences) → string. Never empty (falls back to the built-in name).
function ridego_brand_name() {
    $n = ridego_brand( 'name' );
    return $n !== '' ? $n : ridego_branding_default( 'name' );
}

// TRACE: nothing → what the React app and public pages may show → array of strings (no secrets). Keys: name, tagline, legal_name, logo_url, favicon_url, support_phone, support_whatsapp, support_email, address, website_url, business_hours, social{...}, copyright, legal_info, gstin, footer_note, email_signature.
function ridego_branding_public() {
    $g = function ( $k ) { return (string) ridego_brand( $k ); };
    return array(
        // Root-cause fix: the frontend booking flow had no way to know the
        // admin "Require OTP to confirm booking" setting even existed — it
        // always rendered/required the OTP step unconditionally, regardless
        // of ridego_get_setting('otp_enabled'). This is the one payload the
        // WordPress shell already injects into every app page load
        // (window.__RIDEGO__.branding) and that GET /app/branding also
        // serves, so exposing it here is the single place the booking flow
        // (and any other screen) can read the real, current setting value.
        'otp_enabled' => (int) ridego_get_setting( 'otp_enabled', 1 ) === 1, // Phone OTP toggle (option key kept for backward compatibility).
        // Independent Email OTP Verification toggle — read separately so the
        // frontend can require phone OTP, email OTP, both, or neither.
        'email_otp_enabled' => (int) ridego_get_setting( 'email_otp_enabled', 0 ) === 1,
        'name' => ridego_brand_name(), 'tagline' => $g( 'tagline' ), 'legal_name' => $g( 'legal_name' ), 'logo_url' => $g( 'logo_url' ), 'favicon_url' => $g( 'favicon_url' ),
        'hero_image_url' => $g( 'hero_image_url' ), 'hero_headline' => $g( 'hero_headline' ), 'hero_subtext' => $g( 'hero_subtext' ), 'hero_show_text' => $g( 'hero_show_text' ),
        'hero_overlay' => $g( 'hero_overlay' ), 'hero_secondary_image_url' => $g( 'hero_secondary_image_url' ), 'hero_secondary_height' => $g( 'hero_secondary_height' ),
        'hero_secondary_fit' => $g( 'hero_secondary_fit' ), 'vehicle_card_height' => $g( 'vehicle_card_height' ), 'vehicle_card_fit' => $g( 'vehicle_card_fit' ),
        'vehicle_detail_height' => $g( 'vehicle_detail_height' ), 'vehicle_detail_fit' => $g( 'vehicle_detail_fit' ), 'support_phone' => $g( 'support_phone' ),
        'support_whatsapp' => $g( 'support_whatsapp' ), 'support_email' => $g( 'support_email' ), 'address' => $g( 'address' ), 'website_url' => $g( 'website_url' ), 'business_hours' => $g( 'business_hours' ),
        'social' => array( 'facebook' => $g( 'social_facebook' ), 'instagram' => $g( 'social_instagram' ), 'twitter' => $g( 'social_twitter' ), 'youtube' => $g( 'social_youtube' ), 'linkedin' => $g( 'social_linkedin' ) ),
        'copyright' => $g( 'copyright' ), 'legal_info' => $g( 'legal_info' ), 'gstin' => $g( 'gstin' ), 'footer_note' => $g( 'footer_note' ), 'email_signature' => $g( 'email_signature' ) );
}

// TRACE: field key + raw input → the value that may be stored, or a WP_Error when the value is not acceptable → string|WP_Error. Rules per kind: url → http(s) URL or empty; email → valid address or empty; phone → digits, spaces, + - ( ); textarea → plain text with line breaks; text → single-line text.
function ridego_branding_sanitize( $field, $raw ) {
    $f = ridego_branding_fields();
    if ( ! isset( $f[ $field ] ) ) { return new WP_Error( 'unknown_field', 'Unknown branding field.' ); }
    $raw = is_scalar( $raw ) ? trim( (string) $raw ) : '';
    $label = $f[ $field ]['label'];
    switch ( $f[ $field ]['kind'] ) {
        case 'url':
            if ( $raw === '' ) { return ''; }
            $u = esc_url_raw( $raw, array( 'http', 'https' ) );
            return $u !== '' ? $u : new WP_Error( 'invalid_url', $label . ' must be a full web address starting with http:// or https://.' );
        case 'email':
            if ( $raw === '' ) { return ''; }
            $e = sanitize_email( $raw );
            return $e !== '' && is_email( $e ) ? $e : new WP_Error( 'invalid_email', $label . ' is not a valid email address.' );
        case 'phone':
            if ( $raw === '' ) { return ''; }
            return preg_match( '/^[0-9+()\-\s]{5,20}$/', $raw ) ? $raw : new WP_Error( 'invalid_phone', $label . ' can only contain digits, spaces, + - ( ).' );
        case 'textarea':
            return mb_substr( sanitize_textarea_field( $raw ), 0, 1000 );
        case 'select':
            $opts = isset( $f[ $field ]['options'] ) ? array_keys( $f[ $field ]['options'] ) : array();
            if ( $raw === '' ) { return ''; }
            return in_array( $raw, $opts, true ) ? $raw : new WP_Error( 'invalid_option', $label . ' is not a recognised option.' );
        case 'number':
            if ( $raw === '' ) { return ''; }
            if ( ! is_numeric( $raw ) ) { return new WP_Error( 'invalid_number', $label . ' must be a number.' ); }
            $min = isset( $f[ $field ]['min'] ) ? (int) $f[ $field ]['min'] : 0;
            $max = isset( $f[ $field ]['max'] ) ? (int) $f[ $field ]['max'] : PHP_INT_MAX;
            $n = (int) round( (float) $raw );
            if ( $n < $min || $n > $max ) { return new WP_Error( 'out_of_range', $label . " must be between {$min} and {$max}." ); }
            return (string) $n;
        default:
            return mb_substr( sanitize_text_field( $raw ), 0, 200 );
    }
}

add_action( 'rest_api_init', 'ridego_branding_register_routes' );
// TRACE: rest_api_init → registers public GET /app/branding, admin GET/POST /app/admin/branding and admin POST /app/admin/branding/upload → void.
function ridego_branding_register_routes() {
    register_rest_route( 'ridego/v1', '/app/branding', array( 'methods' => 'GET', 'callback' => 'ridego_branding_api_public', 'permission_callback' => '__return_true' ) );
    register_rest_route( 'ridego/v1', '/app/admin/branding', array( 'methods' => 'GET', 'callback' => 'ridego_branding_api_admin_get', 'permission_callback' => 'ridego_lead_fee_perm_read' ) );
    register_rest_route( 'ridego/v1', '/app/admin/branding', array( 'methods' => 'POST', 'callback' => 'ridego_branding_api_admin_save', 'permission_callback' => 'ridego_lead_fee_perm_write' ) );
    register_rest_route( 'ridego/v1', '/app/admin/branding/upload', array( 'methods' => 'POST', 'callback' => 'ridego_branding_api_upload', 'permission_callback' => 'ridego_lead_fee_perm_write' ) );
}

// TRACE: GET /app/branding → ridego_branding_public() (safe fields only) → response.
function ridego_branding_api_public() { return rest_ensure_response( ridego_branding_public() ); }

// TRACE: GET /app/admin/branding → every field with its label, kind, group, help, the saved value (raw, placeholders unexpanded) and the value currently in effect → response.
function ridego_branding_api_admin_get() {
    $out = array();
    foreach ( ridego_branding_fields() as $k => $f ) {
        $out[] = array( 'key' => $k, 'kind' => $f['kind'], 'group' => $f['group'], 'label' => $f['label'], 'help' => $f['help'], 'value' => (string) ridego_get_setting( $f['setting'], '' ), 'effective' => (string) ridego_brand( $k ), 'options' => isset( $f['options'] ) ? $f['options'] : null, 'min' => isset( $f['min'] ) ? (int) $f['min'] : null, 'max' => isset( $f['max'] ) ? (int) $f['max'] : null );
    }
    return rest_ensure_response( array( 'fields' => $out ) );
}

// TRACE: POST /app/admin/branding {values:{field:value}} → validates every sent field, then saves all of them (nothing is saved if any field is invalid) → response|400. Audit-logged with the field names changed. Unknown fields are ignored.
function ridego_branding_api_admin_save( WP_REST_Request $req ) {
    $b = $req->get_json_params(); $vals = is_array( $b ) && isset( $b['values'] ) && is_array( $b['values'] ) ? $b['values'] : array();
    $fields = ridego_branding_fields(); $clean = array();
    foreach ( $vals as $k => $raw ) {
        if ( ! isset( $fields[ $k ] ) ) { continue; }
        $v = ridego_branding_sanitize( $k, $raw );
        if ( is_wp_error( $v ) ) { return new WP_REST_Response( array( 'code' => $v->get_error_code(), 'message' => $v->get_error_message(), 'field' => $k ), 400 ); }
        $clean[ $k ] = $v;
    }
    if ( ! $clean ) { return new WP_REST_Response( array( 'code' => 'nothing_to_save', 'message' => 'No branding values were sent.' ), 400 ); }
    foreach ( $clean as $k => $v ) { ridego_update_setting( $fields[ $k ]['setting'], $v ); }
    ridego_audit_log( 'branding_changed', 'settings', null, '', implode( ',', array_keys( $clean ) ) );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Branding saved. Open pages update on their next load.', 'saved' => array_keys( $clean ) ) );
}

// TRACE: POST /app/admin/branding/upload (multipart: file, field = logo_url|favicon_url|hero_image_url|hero_secondary_image_url)
//        → stores the image in the WordPress uploads folder and saves its URL into that field → response(url)|400.
//        Only png, jpg, gif or webp (plus ico for favicon_url) up to the field's size cap (1 MB for
//        logo/favicon, 4 MB for the two full-width hero photos — a hero background is necessarily a much
//        larger image than an icon); the real file type is checked from its contents (not the
//        browser-supplied type). SVG is refused (scriptable). Edge cases: no file, wrong field, too big,
//        wrong type, move failure.
function ridego_branding_api_upload( WP_REST_Request $req ) {
    $field = sanitize_key( (string) $req->get_param( 'field' ) );
    $upload_fields = array( 'logo_url', 'favicon_url', 'hero_image_url', 'hero_secondary_image_url' );
    if ( ! in_array( $field, $upload_fields, true ) ) { return new WP_REST_Response( array( 'code' => 'invalid_field', 'message' => 'Choose logo, favicon or a hero image.' ), 400 ); }
    $files = $req->get_file_params();
    if ( empty( $files['file'] ) || ! empty( $files['file']['error'] ) || empty( $files['file']['tmp_name'] ) ) { return new WP_REST_Response( array( 'code' => 'no_file', 'message' => 'Choose an image to upload.' ), 400 ); }
    $f = $files['file'];
    $max_bytes = in_array( $field, array( 'hero_image_url', 'hero_secondary_image_url' ), true ) ? 4 * 1024 * 1024 : 1024 * 1024;
    if ( (int) $f['size'] > $max_bytes ) {
        return new WP_REST_Response( array( 'code' => 'too_big', 'message' => 'The image must be ' . ( $max_bytes / ( 1024 * 1024 ) ) . ' MB or smaller.' ), 400 );
    }
    $check = wp_check_filetype_and_ext( $f['tmp_name'], $f['name'], array( 'png' => 'image/png', 'jpg|jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp', 'ico' => 'image/x-icon|image/vnd.microsoft.icon' ) );
    if ( empty( $check['ext'] ) || empty( $check['type'] ) ) { return new WP_REST_Response( array( 'code' => 'bad_type', 'message' => 'Upload a png, jpg, gif, webp or ico image.' ), 400 ); }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    $up = wp_handle_upload( $f, array( 'test_form' => false, 'mimes' => array( 'png' => 'image/png', 'jpg|jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp', 'ico' => 'image/x-icon' ) ) );
    if ( ! empty( $up['error'] ) || empty( $up['url'] ) ) { return new WP_REST_Response( array( 'code' => 'upload_failed', 'message' => 'The image could not be saved. Please try again.' ), 400 ); }
    ridego_update_setting( ridego_branding_fields()[ $field ]['setting'], esc_url_raw( $up['url'] ) );
    ridego_audit_log( 'branding_changed', 'settings', null, '', $field . ' (upload)' );
    return rest_ensure_response( array( 'success' => true, 'url' => esc_url_raw( $up['url'] ), 'message' => 'Image uploaded.' ) );
}
