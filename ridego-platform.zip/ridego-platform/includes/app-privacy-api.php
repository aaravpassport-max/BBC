<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Privacy API (RG-006, Master Issue Register P0).
   ------------------------------------------------------------
   Two client-facing self-service actions:
     - GET  /app/client/privacy/export        — everything RideGo holds
       about the logged-in user, as one JSON document they can download.
     - POST /app/client/privacy/delete-request — records a request to
       delete/anonymise their account for admin review.
   And the admin side to act on delete requests:
     - GET  /app/admin/privacy/requests        — list, newest first.
     - POST /app/admin/privacy/requests/{id}/fulfill  — anonymises the
       user's identifying fields on their own bookings/notes/support
       tickets and marks the request fulfilled.
     - POST /app/admin/privacy/requests/{id}/reject   — marks rejected
       with a reason (e.g. an active/unsettled booking blocks it).

   Why a delete REQUEST and not an immediate hard delete: booking,
   payment and audit rows are financial and legal records RideGo must
   retain for a retention period regardless of a deletion ask (tax/audit
   requirements, and ridego_audit_log()'s own tamper-evidence design
   would be defeated by deleting the rows it references). So "delete"
   here means: stop marketing/contact use, anonymise directly-identifying
   fields (name/phone/email/addresses) on the user's own records, and
   disable login — never silently drop rows a refund/dispute may still
   need. That is what ridego_privacy_fulfill_delete() actually does, and
   it is invoked only after an admin reviews and approves the request —
   never automatically from the client-facing POST.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_privacy_api_routes' );
function ridego_register_app_privacy_api_routes() {
    register_rest_route( 'ridego/v1', '/app/client/privacy/export', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_privacy_export',
        'permission_callback' => 'ridego_app_privacy_client_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/client/privacy/delete-request', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_privacy_delete_request_create',
        'permission_callback' => 'ridego_app_privacy_client_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/privacy/requests', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_privacy_admin_list',
        'permission_callback' => 'ridego_app_privacy_admin_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/privacy/requests/(?P<id>\d+)/fulfill', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_privacy_admin_fulfill',
        'permission_callback' => 'ridego_app_privacy_admin_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/privacy/requests/(?P<id>\d+)/reject', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_privacy_admin_reject',
        'permission_callback' => 'ridego_app_privacy_admin_permission',
    ) );
}

function ridego_app_privacy_client_permission() {
    return is_user_logged_in() ? true : new WP_Error( 'not_logged_in', 'Please log in.', array( 'status' => 401 ) );
}

function ridego_app_privacy_admin_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_settings' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage privacy requests.', array( 'status' => 403 ) );
    }
    return true;
}

// TRACE: GET privacy/export → every row across bookings, booking payments/notes visible to the client,
//        support tickets, saved addresses, and (for a vendor/driver account) their own profile row, all
//        scoped strictly to the current user id → one JSON object. Pure reads only, nothing written.
//        Preconditions: logged in. Postconditions: response contains no other user's data — every query
//        filters by client_id/user_id/author_id = current user, matching the same scoping every other
//        client-facing endpoint in this codebase already uses (ridego_client_dash_*). Edge cases: a user
//        with zero bookings (empty arrays, not an error); a vendor/driver account additionally gets their
//        vendor/driver profile row in the export.
function ridego_app_privacy_export( WP_REST_Request $req ) {
    global $wpdb;
    $uid = get_current_user_id();
    $u   = get_userdata( $uid );
    $bt  = $wpdb->prefix . 'ridego_bookings';

    $bookings = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$bt} WHERE client_id=%d ORDER BY id DESC", $uid ), ARRAY_A );
    $booking_ids = array_map( function ( $b ) { return (int) $b['id']; }, $bookings );

    $notes = array();
    $payments = array();
    if ( ! empty( $booking_ids ) ) {
        $ph = implode( ',', array_fill( 0, count( $booking_ids ), '%d' ) );
        $notes = $wpdb->get_results( $wpdb->prepare(
            "SELECT booking_id, visibility, note, created_at FROM {$wpdb->prefix}ridego_booking_notes WHERE booking_id IN ({$ph}) AND visibility='client' ORDER BY id DESC",
            $booking_ids
        ), ARRAY_A );
        $payments = $wpdb->get_results( $wpdb->prepare(
            "SELECT booking_id, entry_type, amount, method, reference, created_at FROM {$wpdb->prefix}ridego_booking_payments WHERE booking_id IN ({$ph}) ORDER BY id DESC",
            $booking_ids
        ), ARRAY_A );
    }

    $addresses = ridego_client_dash_read_addresses( $uid );

    $support = $wpdb->get_results( $wpdb->prepare(
        "SELECT id, subject, message, status, created_at FROM {$wpdb->prefix}ridego_complaints WHERE raised_by_id=%d AND raised_by_type='client' ORDER BY id DESC",
        $uid
    ), ARRAY_A );

    $vendor_profile = null;
    if ( function_exists( 'ridego_get_vendor_by_user' ) ) {
        $v = ridego_get_vendor_by_user( $uid );
        if ( $v ) { $vendor_profile = (array) $v; }
    }
    $driver_profile = null;
    if ( function_exists( 'ridego_driver_current' ) ) {
        $d = ridego_driver_current();
        if ( $d ) { $driver_profile = (array) $d; }
    }

    ridego_audit_log( 'privacy_export_downloaded', 'user', $uid, '', '', 'info' );

    return rest_ensure_response( array(
        'generated_at' => current_time( 'mysql' ),
        'account'      => array(
            'user_id'      => $uid,
            'username'     => $u ? $u->user_login : '',
            'display_name' => $u ? $u->display_name : '',
            'email'        => $u ? $u->user_email : '',
            'registered'   => $u ? $u->user_registered : '',
            'roles'        => $u ? array_values( (array) $u->roles ) : array(),
        ),
        'bookings'         => $bookings,
        'booking_notes'    => $notes,
        'booking_payments' => $payments,
        'saved_addresses'  => $addresses,
        'support_tickets'  => $support,
        'vendor_profile'   => $vendor_profile,
        'driver_profile'   => $driver_profile,
    ) );
}

// TRACE: POST privacy/delete-request {reason?} → refuses a second open request → inserts a pending
//        ridego_privacy_requests row and audits it, notifies staff for review → {success,message,id}.
//        Preconditions: logged in. Postconditions: exactly one open (pending) delete request per user at
//        a time. Edge cases: an already-open request (refused with a clear message, not a duplicate row).
function ridego_app_privacy_delete_request_create( WP_REST_Request $req ) {
    global $wpdb;
    $uid = get_current_user_id();
    $tbl = $wpdb->prefix . 'ridego_privacy_requests';

    $existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$tbl} WHERE user_id=%d AND request_type='delete' AND status='pending'", $uid ) );
    if ( $existing > 0 ) {
        return new WP_Error( 'already_pending', 'You already have a pending deletion request awaiting review.', array( 'status' => 409 ) );
    }

    $reason = mb_substr( sanitize_textarea_field( (string) $req->get_param( 'reason' ) ), 0, 500 );
    $ok = $wpdb->insert( $tbl, array(
        'user_id' => $uid, 'request_type' => 'delete', 'status' => 'pending', 'reason' => $reason, 'created_at' => current_time( 'mysql' ),
    ) );
    if ( ! $ok ) {
        return new WP_Error( 'save_failed', 'Could not submit the request. Please try again.', array( 'status' => 500 ) );
    }
    $id = (int) $wpdb->insert_id;
    ridego_audit_log( 'privacy_delete_requested', 'user', $uid, '', $reason, 'warning' );
    if ( function_exists( 'ridego_notify_staff' ) ) {
        ridego_notify_staff( 'privacy_delete_requested', array( 'user_id' => $uid, 'request_id' => $id ), 'ridego_manage_settings' );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => 'Your request has been submitted and will be reviewed.', 'id' => $id ) );
}

// TRACE: GET admin/privacy/requests?status= → all requests, optionally filtered by status, newest first,
//        with the requester's username resolved → {rows}. Read-only.
function ridego_app_privacy_admin_list( WP_REST_Request $req ) {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_privacy_requests';
    $status = sanitize_key( (string) $req->get_param( 'status' ) );
    $sql = "SELECT r.*, u.user_login, u.user_email FROM {$tbl} r LEFT JOIN {$wpdb->users} u ON u.ID=r.user_id";
    $rows = $status
        ? $wpdb->get_results( $wpdb->prepare( "{$sql} WHERE r.status=%s ORDER BY r.id DESC", $status ) )
        : $wpdb->get_results( "{$sql} ORDER BY r.id DESC" );
    return rest_ensure_response( array( 'rows' => array_map( function ( $r ) {
        return array(
            'id' => (int) $r->id, 'user_id' => (int) $r->user_id, 'user_login' => $r->user_login ?: '(deleted user)', 'user_email' => $r->user_email ?: '',
            'request_type' => $r->request_type, 'status' => $r->status, 'reason' => $r->reason, 'admin_note' => $r->admin_note,
            'reviewed_by' => $r->reviewed_by ? (int) $r->reviewed_by : null, 'reviewed_at' => $r->reviewed_at, 'created_at' => $r->created_at,
        );
    }, $rows ) ) );
}

// TRACE: POST admin/privacy/requests/{id}/fulfill {note?} → only a pending request → anonymises the
//        user's directly-identifying fields on their OWN bookings (name/phone/email/alt-phone,
//        never financial fields), scrambles their WP account email/login and clears profile display
//        fields, deactivates login, and marks the request fulfilled with the acting admin recorded →
//        {success,message}. Preconditions: request exists and is 'pending'. Postconditions: booking,
//        payment and audit rows for this user still exist (retention requirement, see file header) but
//        no longer carry directly-identifying contact details for the anonymised user's own bookings;
//        the WP user row can no longer log in (a random password is set and reset via wp_set_password
//        to an unknowable value, and the account is not otherwise deleted, so financial-record foreign
//        keys such as client_id keep resolving). Edge cases: unknown request id (404); a request already
//        fulfilled/rejected (409, cannot be re-fulfilled — avoids double-anonymising a row that may have
//        since gained new legitimate identifying data if the account were somehow reused).
function ridego_app_privacy_admin_fulfill( WP_REST_Request $req ) {
    global $wpdb;
    $id  = (int) $req->get_param( 'id' );
    $tbl = $wpdb->prefix . 'ridego_privacy_requests';
    $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id=%d", $id ) );
    if ( ! $row ) {
        return new WP_Error( 'not_found', 'Request not found.', array( 'status' => 404 ) );
    }
    if ( $row->status !== 'pending' ) {
        return new WP_Error( 'not_pending', 'This request has already been ' . $row->status . '.', array( 'status' => 409 ) );
    }
    $uid = (int) $row->user_id;
    $note = mb_substr( sanitize_textarea_field( (string) $req->get_param( 'note' ) ), 0, 500 );

    $anon_tag = 'deleted-user-' . $uid;
    $bt = $wpdb->prefix . 'ridego_bookings';
    $wpdb->update( $bt, array(
        'client_name' => 'Deleted User', 'client_phone' => '', 'client_email' => '', 'client_alt_phone' => '',
    ), array( 'client_id' => $uid ) );

    $u = get_userdata( $uid );
    if ( $u ) {
        require_once ABSPATH . 'wp-admin/includes/user.php';
        wp_update_user( array(
            'ID' => $uid, 'display_name' => 'Deleted User',
            'user_email' => $anon_tag . '@deleted.invalid',
        ) );
        wp_set_password( wp_generate_password( 32, true, true ), $uid );
        // Every existing session (if any) is invalidated by the password change above;
        // WordPress ties session tokens to the password hash.
    }

    $wpdb->update( $tbl, array(
        'status' => 'fulfilled', 'admin_note' => $note, 'reviewed_by' => get_current_user_id(), 'reviewed_at' => current_time( 'mysql' ),
    ), array( 'id' => $id ) );

    ridego_audit_log( 'privacy_delete_fulfilled', 'user', $uid, 'pending', 'fulfilled: ' . $note, 'warning' );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Account anonymised and request marked fulfilled.' ) );
}

// TRACE: POST admin/privacy/requests/{id}/reject {reason} → only a pending request, reason required →
//        marks rejected, records the acting admin → {success,message}. Preconditions: request exists and
//        is 'pending'. Postconditions: no data is touched — a reject is purely a status change with an
//        explanation the user can be shown (e.g. "you have an active booking with an unresolved balance").
function ridego_app_privacy_admin_reject( WP_REST_Request $req ) {
    global $wpdb;
    $id  = (int) $req->get_param( 'id' );
    $tbl = $wpdb->prefix . 'ridego_privacy_requests';
    $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id=%d", $id ) );
    if ( ! $row ) {
        return new WP_Error( 'not_found', 'Request not found.', array( 'status' => 404 ) );
    }
    if ( $row->status !== 'pending' ) {
        return new WP_Error( 'not_pending', 'This request has already been ' . $row->status . '.', array( 'status' => 409 ) );
    }
    $reason = trim( sanitize_textarea_field( (string) $req->get_param( 'reason' ) ) );
    if ( $reason === '' ) {
        return new WP_Error( 'invalid_input', 'Please give a reason for rejecting this request.', array( 'status' => 400 ) );
    }
    $wpdb->update( $tbl, array(
        'status' => 'rejected', 'admin_note' => mb_substr( $reason, 0, 500 ), 'reviewed_by' => get_current_user_id(), 'reviewed_at' => current_time( 'mysql' ),
    ), array( 'id' => $id ) );
    ridego_audit_log( 'privacy_delete_rejected', 'user', (int) $row->user_id, 'pending', 'rejected: ' . $reason, 'info' );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Request rejected.' ) );
}
