<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
/* ============================================================
   GENERAL-PURPOSE BACKGROUND JOB QUEUE
   ------------------------------------------------------------
   Generalises the retry/backoff/dead-letter mechanics already
   proven correct in includes/notifications.php's notification
   queue (same shape: status, attempts, next_retry_at, error_msg,
   a dead_letter terminal state a human must clear) into a reusable
   primitive for ANY fire-and-retry background work, not only
   notifications.

   Why this exists (Master Issue Register P0 item 6 / Priority
   Roadmap item 6): several money-movement call sites run a single
   synchronous DB write and never check its return value — for
   example ridego_cancel_booking() (includes/booking.php) calling
   ridego_vendor_credit_wallet() for a lead-fee refund on
   cancellation. If that write fails (vendor row locked by a
   concurrent transaction, a transient DB error), the booking still
   reports "cancelled successfully" to the client while the vendor's
   refund is silently lost forever, with nothing to retry it and
   nothing surfacing the failure anywhere an admin would see it. This
   file gives call sites like that a way to fall back to a durable,
   automatically-retried job instead of losing the write outright.

   Usage: ridego_enqueue_job( 'vendor_wallet_credit', array(...) )
   to enqueue; ridego_process_job_queue() is called every 5 minutes
   by the same cron pattern includes/cron.php already uses. New job
   types register a handler via the 'ridego_job_handlers' filter
   (job_type => callable(payload): bool) rather than editing the
   dispatcher, so this file never has to grow per job type.
   ============================================================ */

// TRACE: any call site with a background-safe unit of work → INSERT into ridego_job_queue with
//        status='pending' → bool (insert succeeded). Preconditions: $job_type has (or will have, by the
//        time this job is due) a registered handler — an unregistered type is not rejected here (the
//        table doesn't know about handlers), it will simply dead-letter with a clear error message the
//        first time ridego_process_job_queue() tries and fails to find one. Postconditions: exactly one
//        new row, attempts=0, scheduled_for = now + $delay. Edge cases: $delay=0 (due immediately, picked
//        up by the very next cron tick, not synchronously).
function ridego_enqueue_job( $job_type, $payload, $delay = 0, $priority = 'normal', $max_attempts = 5 ) {
    global $wpdb;
    $inserted = $wpdb->insert( $wpdb->prefix . 'ridego_job_queue', array(
        'job_type'      => sanitize_key( $job_type ),
        'payload'       => wp_json_encode( (array) $payload ),
        'status'        => 'pending',
        'priority'      => in_array( $priority, array( 'high', 'normal', 'low' ), true ) ? $priority : 'normal',
        'attempts'      => 0,
        'max_attempts'  => max( 1, (int) $max_attempts ),
        'scheduled_for' => date( 'Y-m-d H:i:s', time() + max( 0, (int) $delay ) ),
        'created_at'    => current_time( 'mysql' ),
    ) );
    return $inserted !== false;
}

// TRACE: same exponential backoff shape as ridego_notification_backoff_minutes() (attempt 1 -> 5min,
//        2 -> 20min, 3 -> 60min, 4+ -> 60min capped) — kept as an intentionally separate copy rather than
//        a shared call across the two files, so a future change to notification timing (a product
//        decision about how pushy re-sends should be) can never accidentally also change how aggressively
//        money-movement jobs retry, and vice versa. Pure.
function ridego_job_backoff_minutes( $attempt ) {
    $schedule = array( 1 => 5, 2 => 20, 3 => 60 );
    return isset( $schedule[ $attempt ] ) ? $schedule[ $attempt ] : 60;
}

// TRACE: job_type string → the registered handler callable, or null if none is registered → callable|null.
//        Built-in handlers are registered here; a plugin/extension (or a future job type added without
//        touching this file) adds its own via add_filter('ridego_job_handlers', ...). Pure w.r.t. globals
//        aside from the filter registry itself.
function ridego_job_handlers() {
    $handlers = array(
        'vendor_wallet_credit'         => 'ridego_job_handle_vendor_wallet_credit',
        'booking_payment_verify_retry' => 'ridego_job_handle_booking_payment_verify_retry',
    );
    return apply_filters( 'ridego_job_handlers', $handlers );
}

// TRACE: {booking_id, payment_id, order_id, paid_amount} → re-attempts the exact booking-row update that a
//        Razorpay success webhook already tried and that failed (includes/payment.php,
//        ridego_process_razorpay_success()) → bool (true = row now reflects verified/confirmed, safe to
//        mark done; false = still failing, queue backs off and eventually dead-letters for a human).
//        Preconditions: payload has booking_id, payment_id. Postconditions: on true, the booking row's
//        payment_status='verified', status='confirmed', payment_gateway_id/payment_order_id/advance_paid
//        set — identical postcondition to the synchronous update it retries. Edge cases: booking deleted
//        between enqueue and retry (update affects 0 rows but returns !== false, so this reports success —
//        correct, since there is nothing left to mark verified and retrying forever cannot fix a missing row).
function ridego_job_handle_booking_payment_verify_retry( $payload ) {
    global $wpdb;
    $booking_id = isset( $payload['booking_id'] ) ? (int) $payload['booking_id'] : 0;
    if ( ! $booking_id ) { return false; }
    $bookings_table = $wpdb->prefix . 'ridego_bookings';
    $result = $wpdb->update( $bookings_table, array(
        'payment_method'      => 'razorpay',
        'payment_status'      => 'verified',
        'payment_gateway_id'  => isset( $payload['payment_id'] ) ? (string) $payload['payment_id'] : '',
        'payment_order_id'    => isset( $payload['order_id'] ) ? (string) $payload['order_id'] : '',
        'advance_paid'        => isset( $payload['paid_amount'] ) ? (float) $payload['paid_amount'] : 0.0,
        'payment_verified_at' => current_time( 'mysql' ),
        'status'              => 'confirmed',
        'updated_at'          => current_time( 'mysql' ),
    ), array( 'id' => $booking_id ) );
    return $result !== false;
}

// TRACE: {vendor_id, amount, booking_id, notes} → retries the exact same
//        ridego_vendor_credit_wallet() call a synchronous call site already attempted and that failed →
//        bool (true = credited, safe to mark the job done; false = still failing, the queue will back off
//        and retry, eventually dead-lettering for a human). Preconditions: payload has vendor_id and
//        amount. Postconditions: on true, the vendor's wallet balance and ledger row reflect the credit —
//        identical postcondition to the synchronous function it wraps, since it IS that function.
//        Edge cases: vendor deleted between enqueue and retry (permanently fails every attempt ->
//        dead_letter, which is correct: no amount of retrying fixes a vendor that no longer exists, and a
//        human needs to see it and decide what to do with the money).
function ridego_job_handle_vendor_wallet_credit( $payload ) {
    $vendor_id  = isset( $payload['vendor_id'] ) ? (int) $payload['vendor_id'] : 0;
    $amount     = isset( $payload['amount'] ) ? (float) $payload['amount'] : 0.0;
    $booking_id = isset( $payload['booking_id'] ) ? (int) $payload['booking_id'] : null;
    $notes      = isset( $payload['notes'] ) ? (string) $payload['notes'] : '';
    if ( ! $vendor_id || $amount <= 0 ) { return false; }
    $r = ridego_vendor_credit_wallet( $vendor_id, $amount, $booking_id, $notes );
    return ! empty( $r['success'] );
}

// TRACE: the result array from an already-attempted ridego_vendor_credit_wallet() call (a call site
//        already made the synchronous attempt; this only handles what happens if it failed) → void.
//        Preconditions: $credit_result is that function's return shape ({success,message,...}).
//        Postconditions: on success, does nothing (the fast path needs no queue at all — this exists
//        purely for the failure case); on failure, audit-logs it immediately (visible in the admin audit
//        log right away, not just eventually in a dead-letter queue) AND enqueues a 'vendor_wallet_credit'
//        job so the credit is retried automatically instead of being silently lost. Edge cases: none —
//        this function cannot itself fail in a way that loses money, since the worst case (the enqueue
//        insert fails too) still leaves the audit log entry as a paper trail an admin can act on.
function ridego_ensure_wallet_credit( $credit_result, $vendor_id, $amount, $booking_id, $reason ) {
    if ( ! empty( $credit_result['success'] ) ) { return; }
    $message = is_array( $credit_result ) && ! empty( $credit_result['message'] ) ? $credit_result['message'] : 'Unknown failure';
    ridego_audit_log( 'wallet_credit_failed_queued', 'booking', $booking_id, '', "Vendor {$vendor_id}, amount {$amount}: {$message} — queued for automatic retry.", 'warning' );
    ridego_enqueue_job( 'vendor_wallet_credit', array(
        'vendor_id'   => $vendor_id,
        'amount'      => $amount,
        'booking_id'  => $booking_id,
        'notes'       => $reason . ' (retried via job queue after an initial synchronous failure: ' . $message . ')',
    ), 60 ); // first retry attempt in 1 minute — a lock contention or transient error usually clears fast
}

// TRACE: cron ridego_process_job_queue (every 5 min, registered in includes/cron.php) → dispatches up to
//        20 due jobs (status=pending, scheduled_for<=now, next_retry_at unset or elapsed), oldest
//        high-priority first → void. Preconditions: none. Postconditions: each job ends this run as
//        done|pending (rescheduled with backoff)|dead_letter — never silently vanishes and never stays
//        'processing' forever (no separate processing state exists; a job either finishes this pass or
//        goes back to pending for the next one, so a crash mid-run just means it retries, not that it's
//        lost). Edge cases: no registered handler for job_type -> treated as a failed attempt with an
//        explicit "no handler registered" error, so it dead-letters visibly instead of retrying forever
//        for a reason retrying can never fix; a handler that throws is caught so one bad job can never
//        block the other 19 in the same batch.
function ridego_process_job_queue() {
    global $wpdb;
    $table = $wpdb->prefix . 'ridego_job_queue';
    $jobs = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$table}
         WHERE status = %s
         AND scheduled_for <= NOW()
         AND (next_retry_at IS NULL OR next_retry_at <= NOW())
         ORDER BY FIELD(priority,'high','normal','low'), created_at ASC
         LIMIT 20",
        'pending'
    ) );
    if ( empty( $jobs ) ) { return; }

    $handlers = ridego_job_handlers();

    foreach ( $jobs as $job ) {
        $payload = json_decode( $job->payload, true );
        if ( ! is_array( $payload ) ) { $payload = array(); }

        $ok = false;
        $error = '';
        if ( ! isset( $handlers[ $job->job_type ] ) || ! is_callable( $handlers[ $job->job_type ] ) ) {
            $error = "No handler registered for job_type '{$job->job_type}'.";
        } else {
            try {
                $ok = (bool) call_user_func( $handlers[ $job->job_type ], $payload );
                if ( ! $ok ) { $error = 'Handler returned failure.'; }
            } catch ( \Throwable $e ) {
                $ok = false;
                $error = 'Handler threw: ' . $e->getMessage();
            }
        }

        $attempts = (int) $job->attempts + 1;

        if ( $ok ) {
            $wpdb->update( $table,
                array( 'status' => 'done', 'attempts' => $attempts, 'done_at' => current_time( 'mysql' ), 'next_retry_at' => null, 'error_msg' => '' ),
                array( 'id' => $job->id )
            );
        } elseif ( $attempts >= (int) $job->max_attempts ) {
            $wpdb->update( $table,
                array( 'status' => 'dead_letter', 'attempts' => $attempts, 'error_msg' => $error ?: 'Max retry attempts exceeded' ),
                array( 'id' => $job->id )
            );
            ridego_audit_log( 'job_dead_letter', 'job_queue', $job->id, $job->job_type, $error ?: 'Max retry attempts exceeded', 'warning' );
        } else {
            $delay_min = ridego_job_backoff_minutes( $attempts );
            $wpdb->update( $table,
                array(
                    'status'        => 'pending',
                    'attempts'      => $attempts,
                    'next_retry_at' => date( 'Y-m-d H:i:s', time() + $delay_min * 60 ),
                    'error_msg'     => $error,
                ),
                array( 'id' => $job->id )
            );
        }
    }

    // Sent/done jobs older than 7 days are cleaned up the same way the notification queue already does —
    // dead_letter rows are NEVER auto-deleted, since they need a human decision (retry now / discard).
    $wpdb->query( $wpdb->prepare(
        "DELETE FROM {$table} WHERE status = %s AND done_at < DATE_SUB(NOW(), INTERVAL 7 DAY)", 'done'
    ) );
}
