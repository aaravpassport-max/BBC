<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Phase B, wave 4: routes + zones
   ------------------------------------------------------------
   Completes the rebuild of admin/pages/cities.php's remaining two
   tabs (Routes, Zones — Cities itself was Wave 19). Read the real
   render functions and the real ridego_routes / ridego_route_
   vehicle_pricing / ridego_zones schemas directly out of
   admin/pages/cities.php and includes/install.php before writing
   a line of this file — every field name and validation rule below
   is copied from there, not guessed.

   UPDATE: routes/zones/vehicle-pricing add/edit/delete previously
   had no canonical business-logic layer — both this file and
   admin/pages/cities.php did their own raw $wpdb calls, each with
   the same validation rules (lat/lng range checks, radius > 0, no
   self-referencing route, duplicate route-pair rejection) copy-
   pasted in two places. Consolidated into ridego_create_route()/
   ridego_update_route()/ridego_delete_route()/
   ridego_save_route_vehicle_pricing()/
   ridego_delete_route_vehicle_pricing()/ridego_create_zone()/
   ridego_update_zone()/ridego_delete_zone() (includes/helpers.php),
   which both this file and the legacy admin page now call.

   Every route requires is_user_logged_in() AND
   ridego_can('ridego_manage_pricing') — the exact capability
   admin/pages/cities.php itself gates on for all three tabs.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_routes_api_routes' );
function ridego_register_app_admin_routes_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/routes', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_routes_list',
        'permission_callback' => 'ridego_app_admin_api_routes_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/routes', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_route_create',
        'permission_callback' => 'ridego_app_admin_api_routes_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/routes/(?P<id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_route_update',
        'permission_callback' => 'ridego_app_admin_api_routes_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/routes/(?P<id>\d+)/delete', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_route_delete',
        'permission_callback' => 'ridego_app_admin_api_routes_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/routes/(?P<id>\d+)/vehicle-pricing', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_route_vehicle_pricing_save',
        'permission_callback' => 'ridego_app_admin_api_routes_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/route-vehicle-pricing/(?P<id>\d+)/delete', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_route_vehicle_pricing_delete',
        'permission_callback' => 'ridego_app_admin_api_routes_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/zones', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_zones_list',
        'permission_callback' => 'ridego_app_admin_api_routes_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/zones', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_zone_create',
        'permission_callback' => 'ridego_app_admin_api_routes_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/zones/(?P<id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_zone_update',
        'permission_callback' => 'ridego_app_admin_api_routes_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/zones/(?P<id>\d+)/delete', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_zone_delete',
        'permission_callback' => 'ridego_app_admin_api_routes_permission',
    ) );
}

function ridego_app_admin_api_routes_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_pricing' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage routes and zones.', array( 'status' => 403 ) );
    }
    return true;
}

/* ----------------------------------------------------------------
   Routes
   ---------------------------------------------------------------- */

function ridego_app_admin_api_routes_list( WP_REST_Request $req ) {
    global $wpdb;
    $rtbl  = $wpdb->prefix . 'ridego_routes';
    $rvtbl = $wpdb->prefix . 'ridego_route_vehicle_pricing';

    $rows = $wpdb->get_results( "SELECT * FROM {$rtbl} ORDER BY is_popular DESC, from_city ASC, to_city ASC" );
    $overrides = $wpdb->get_results( "SELECT * FROM {$rvtbl} ORDER BY route_id ASC" );

    $by_route = array();
    foreach ( (array) $overrides as $o ) {
        $rid = (int) $o->route_id;
        if ( ! isset( $by_route[ $rid ] ) ) { $by_route[ $rid ] = array(); }
        $by_route[ $rid ][] = array(
            'id'            => (int) $o->id,
            'vehicle_id'    => (int) $o->vehicle_id,
            'fixed_price'   => $o->fixed_price !== null ? (float) $o->fixed_price : null,
            'toll_estimate' => $o->toll_estimate !== null ? (float) $o->toll_estimate : null,
        );
    }

    $out = array_map( function ( $r ) use ( $by_route ) {
        $id = (int) $r->id;
        return array(
            'id'                   => $id,
            'from_city_id'         => (int) $r->from_city_id,
            'to_city_id'           => (int) $r->to_city_id,
            'from_city'            => $r->from_city,
            'to_city'              => $r->to_city,
            'distance_km'          => (float) $r->distance_km,
            'duration_mins'        => (int) $r->duration_mins,
            'toll_estimate'        => $r->toll_estimate !== null ? (float) $r->toll_estimate : null,
            'default_fixed_price'  => $r->default_fixed_price !== null ? (float) $r->default_fixed_price : null,
            'is_popular'           => (bool) $r->is_popular,
            'is_active'            => (bool) $r->is_active,
            'vehicle_pricing'      => isset( $by_route[ $id ] ) ? $by_route[ $id ] : array(),
        );
    }, $rows );

    return rest_ensure_response( array( 'rows' => $out, 'total' => count( $out ) ) );
}

/** Builds the raw input array ridego_validate_route_input() expects, from a REST request. */
function ridego_app_admin_api_route_raw_input( WP_REST_Request $req ) {
    return array(
        'from_city_id' => $req->get_param( 'from_city_id' ),
        'to_city_id'   => $req->get_param( 'to_city_id' ),
        'distance_km'  => $req->get_param( 'distance_km' ),
        'duration_mins' => $req->get_param( 'duration_mins' ),
        'toll_estimate' => $req->get_param( 'toll_estimate' ),
        'default_fixed_price' => $req->get_param( 'default_fixed_price' ),
        'is_popular'   => $req->get_param( 'is_popular' ),
    );
}

/** Delegates to the canonical ridego_create_route() (includes/helpers.php). */
function ridego_app_admin_api_route_create( WP_REST_Request $req ) {
    $is_active = $req->get_param( 'is_active' );
    $r = ridego_create_route( ridego_app_admin_api_route_raw_input( $req ), $is_active === null ? null : (bool) $is_active );
    if ( empty( $r['success'] ) ) {
        return new WP_Error( 'invalid_input', $r['message'], array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'id' => $r['id'], 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_update_route() (includes/helpers.php). */
function ridego_app_admin_api_route_update( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    $is_active = $req->get_param( 'is_active' );
    $r = ridego_update_route( $id, ridego_app_admin_api_route_raw_input( $req ), $is_active === null ? null : (bool) $is_active );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'Route not found.' ? 404 : 400;
        return new WP_Error( 'update_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_delete_route() (includes/helpers.php), which cascades the vehicle-pricing overrides too. */
function ridego_app_admin_api_route_delete( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    $r = ridego_delete_route( $id );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'Route not found.' ? 404 : 500;
        return new WP_Error( 'delete_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_save_route_vehicle_pricing() (includes/helpers.php). */
function ridego_app_admin_api_route_vehicle_pricing_save( WP_REST_Request $req ) {
    $r = ridego_save_route_vehicle_pricing(
        (int) $req->get_param( 'id' ),
        (int) $req->get_param( 'vehicle_id' ),
        $req->get_param( 'fixed_price' ),
        $req->get_param( 'toll_estimate' )
    );
    if ( empty( $r['success'] ) ) {
        return new WP_Error( 'invalid_input', $r['message'], array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'id' => $r['id'], 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_delete_route_vehicle_pricing() (includes/helpers.php). */
function ridego_app_admin_api_route_vehicle_pricing_delete( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    $r = ridego_delete_route_vehicle_pricing( $id );
    if ( empty( $r['success'] ) ) {
        return new WP_Error( 'delete_failed', $r['message'], array( 'status' => 500 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'] ) );
}

/* ----------------------------------------------------------------
   Zones — center-point + radius model (no polygons; see
   ridego_migration_006_zones() in includes/migrations.php for why).
   ---------------------------------------------------------------- */

function ridego_app_admin_api_zones_list( WP_REST_Request $req ) {
    global $wpdb;
    $ztbl = $wpdb->prefix . 'ridego_zones';
    $ctbl = $wpdb->prefix . 'ridego_cities';

    if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $ztbl ) ) !== $ztbl ) {
        return rest_ensure_response( array( 'rows' => array(), 'total' => 0 ) );
    }

    $rows = $wpdb->get_results(
        "SELECT z.*, c.name AS city_name FROM {$ztbl} z LEFT JOIN {$ctbl} c ON c.id = z.city_id ORDER BY c.name ASC, z.name ASC"
    );
    $out = array_map( function ( $z ) {
        return array(
            'id'         => (int) $z->id,
            'city_id'    => (int) $z->city_id,
            'city_name'  => isset( $z->city_name ) ? $z->city_name : '',
            'name'       => $z->name,
            'center_lat' => (float) $z->center_lat,
            'center_lng' => (float) $z->center_lng,
            'radius_km'  => (float) $z->radius_km,
            'is_active'  => (bool) $z->is_active,
        );
    }, $rows );

    return rest_ensure_response( array( 'rows' => $out, 'total' => count( $out ) ) );
}

/** Builds the raw input array ridego_validate_zone_input() expects, from a REST request. */
function ridego_app_admin_api_zone_raw_input( WP_REST_Request $req ) {
    return array(
        'city_id'    => $req->get_param( 'city_id' ),
        'name'       => $req->get_param( 'name' ),
        'center_lat' => $req->get_param( 'center_lat' ),
        'center_lng' => $req->get_param( 'center_lng' ),
        'radius_km'  => $req->get_param( 'radius_km' ),
    );
}

/** Delegates to the canonical ridego_create_zone() (includes/helpers.php). */
function ridego_app_admin_api_zone_create( WP_REST_Request $req ) {
    $is_active = $req->get_param( 'is_active' );
    $r = ridego_create_zone( ridego_app_admin_api_zone_raw_input( $req ), $is_active === null ? null : (bool) $is_active );
    if ( empty( $r['success'] ) ) {
        return new WP_Error( 'create_failed', $r['message'], array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'id' => $r['id'], 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_update_zone() (includes/helpers.php). */
function ridego_app_admin_api_zone_update( WP_REST_Request $req ) {
    $id        = (int) $req->get_param( 'id' );
    $is_active = $req->get_param( 'is_active' );
    $r = ridego_update_zone( $id, ridego_app_admin_api_zone_raw_input( $req ), $is_active === null ? null : (bool) $is_active );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'Zone not found.' ? 404 : 400;
        return new WP_Error( 'update_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'] ) );
}

/**
 * Hard delete. admin/pages/cities.php's own zone-delete confirm
 * dialog warns that surge rules pinned to this zone fall back to
 * city-wide matching (ridego_surge_pricing.zone_id has no cascade)
 * — same warning is surfaced client-side here, not silently
 * omitted. Delegates to the canonical ridego_delete_zone()
 * (includes/helpers.php).
 */
function ridego_app_admin_api_zone_delete( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    $r  = ridego_delete_zone( $id );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'Zone not found.' ? 404 : 500;
        return new WP_Error( 'delete_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'] ) );
}
