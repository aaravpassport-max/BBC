<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Phase B, wave 6: promo codes
   ------------------------------------------------------------
   admin/pages/promo.php was already root-cause-fixed earlier in
   this engagement (see its own inline comment, lines 15-33): the
   legacy form used to write to nonexistent columns (min_fare,
   valid_until, trip_types) and submit discount_type as 'percent'
   when includes/promo.php's actual calculation checks for
   'percentage' — meaning every save silently failed or every
   percentage promo silently became a flat discount. That fix is
   already live in admin/pages/promo.php; this file's field
   mapping is copied from the CORRECTED version, not the original
   broken one, and was cross-checked directly against
   includes/promo.php's read side (which validates/redeems promo
   codes) to confirm the column names and the 'percentage'/'fixed'
   values used here are exactly what that code expects.

   UPDATE (Cleanup pass 5 — the last item from the Waves 17-21
   caveats): the gap noted above is closed. Add/edit/toggle now go
   through ridego_create_promo()/ridego_update_promo()/
   ridego_toggle_promo_active() (includes/helpers.php), which both
   this file and the legacy admin page now call — the upsert-by-code
   create behavior and the real-column-name/'percentage' root-cause
   fix both live in one place for both callers now.

   Every route requires is_user_logged_in() AND
   ridego_can('ridego_manage_promo_codes') — the exact capability
   admin/pages/promo.php itself gates on.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_promo_api_routes' );
function ridego_register_app_admin_promo_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/promo', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_promo_list',
        'permission_callback' => 'ridego_app_admin_api_promo_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/promo', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_promo_create',
        'permission_callback' => 'ridego_app_admin_api_promo_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/promo/(?P<id>\d+)', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_promo_update',
        'permission_callback' => 'ridego_app_admin_api_promo_permission',
    ) );
    register_rest_route( 'ridego/v1', '/app/admin/promo/(?P<id>\d+)/toggle', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_promo_toggle',
        'permission_callback' => 'ridego_app_admin_api_promo_permission',
    ) );
}

function ridego_app_admin_api_promo_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_promo_codes' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage promo codes.', array( 'status' => 403 ) );
    }
    return true;
}

function ridego_app_admin_api_promo_list( WP_REST_Request $req ) {
    global $wpdb;
    $tbl  = $wpdb->prefix . 'ridego_promo_codes';
    $rows = $wpdb->get_results( "SELECT * FROM {$tbl} ORDER BY created_at DESC" );

    $out = array_map( function ( $p ) {
        $trip_types = $p->trip_type ? (array) maybe_unserialize( $p->trip_type ) : array();
        return array(
            'id'                 => (int) $p->id,
            'code'               => $p->code,
            'description'        => $p->description,
            'discount_type'      => $p->discount_type,
            'discount_value'     => (float) $p->discount_value,
            'min_booking_amount' => (float) $p->min_booking_amount,
            'max_discount'       => (float) $p->max_discount,
            'usage_limit'        => (int) $p->usage_limit,
            'used_count'         => (int) $p->used_count,
            'start_date'         => $p->start_date,
            'expiry_date'        => $p->expiry_date,
            'trip_type'          => array_values( $trip_types ),
            'is_active'          => (bool) $p->is_active,
        );
    }, $rows );

    return rest_ensure_response( array( 'rows' => $out, 'total' => count( $out ) ) );
}

/** Builds the raw input array ridego_validate_promo_input() expects, from a REST request. */
function ridego_app_admin_api_promo_raw_input( WP_REST_Request $req ) {
    return array(
        'code'               => $req->get_param( 'code' ),
        'description'        => $req->get_param( 'description' ),
        'discount_type'      => $req->get_param( 'discount_type' ),
        'discount_value'     => $req->get_param( 'discount_value' ),
        'min_booking_amount' => $req->get_param( 'min_booking_amount' ),
        'max_discount'       => $req->get_param( 'max_discount' ),
        'usage_limit'        => $req->get_param( 'usage_limit' ),
        'start_date'         => $req->get_param( 'start_date' ),
        'expiry_date'        => $req->get_param( 'expiry_date' ),
        'trip_type'          => (array) $req->get_param( 'trip_type' ),
    );
}

/** Delegates to the canonical ridego_create_promo() (includes/helpers.php) — upsert-by-code. */
function ridego_app_admin_api_promo_create( WP_REST_Request $req ) {
    $is_active = $req->get_param( 'is_active' );
    $r = ridego_create_promo( ridego_app_admin_api_promo_raw_input( $req ), $is_active === null ? null : (bool) $is_active );
    if ( empty( $r['success'] ) ) {
        return new WP_Error( 'create_failed', $r['message'], array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'id' => $r['id'], 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_update_promo() (includes/helpers.php). */
function ridego_app_admin_api_promo_update( WP_REST_Request $req ) {
    $id        = (int) $req->get_param( 'id' );
    $is_active = $req->get_param( 'is_active' );
    $r = ridego_update_promo( $id, ridego_app_admin_api_promo_raw_input( $req ), $is_active === null ? null : (bool) $is_active );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'Promo code not found.' ? 404 : 400;
        return new WP_Error( 'update_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => $r['message'] ) );
}

/** Delegates to the canonical ridego_toggle_promo_active() (includes/helpers.php). */
function ridego_app_admin_api_promo_toggle( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    $r  = ridego_toggle_promo_active( $id );
    if ( empty( $r['success'] ) ) {
        $status = $r['message'] === 'Promo code not found.' ? 404 : 500;
        return new WP_Error( 'toggle_failed', $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array(
        'success'   => true,
        'is_active' => $r['is_active'],
        'message'   => $r['message'],
    ) );
}
