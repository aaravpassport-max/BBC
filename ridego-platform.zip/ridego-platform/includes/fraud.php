<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
/* Fraud detection - built in Session 9 */
