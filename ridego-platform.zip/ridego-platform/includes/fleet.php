<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   FLEET DATA MODEL  (Marketplace Plan — sections D, F, G, K)
   ------------------------------------------------------------
   Individual and Fleet vendors are NOT two schemas. They share
   ridego_fleet_vehicles / ridego_fleet_drivers /
   ridego_booking_assignments at different cardinality:
     individual => exactly 1 vehicle row + 1 driver row, auto-created
     fleet      => N of each, managed by the vendor
   vendor_type only gates navigation and defaults, never a fork in
   the database. Availability is COMPUTED (ridego_check_fleet_
   availability) — never a manually-maintained calendar.
   ============================================================ */

/* Booking statuses during which an assigned driver/vehicle is committed. */
// TRACE: called by availability + live-status code → returns the list of booking
//        statuses that hold a driver/vehicle → no mutation. Preconditions: none.
//        Postconditions: array of 3 status strings. Edge cases: none.
function ridego_fleet_committed_statuses() {
    return array( 'vendor_assigned', 'driver_en_route', 'trip_started' );
}

// TRACE: any caller normalising a plate → strips everything except A-Z/0-9 and
//        upper-cases → returns 'MH12AB1234' for ' mh-12 ab 1234 '. Preconditions:
//        none. Postconditions: string with no spaces/punctuation. Edge cases:
//        empty/null input → '' ; non-scalar → ''.
function ridego_normalize_registration( $value ) {
    if ( ! is_scalar( $value ) ) { return ''; }
    return strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $value ) );
}

// TRACE: any caller asking "is this a fleet vendor" → reads vendor->vendor_type →
//        returns 'fleet' or 'individual' → no mutation. Preconditions: $vendor is a
//        ridego_vendors row object or null. Postconditions: always one of the two
//        strings. Edge cases: null vendor → 'individual'; unknown/empty stored value
//        → 'individual' (safe default that matches the column default).
function ridego_get_vendor_type( $vendor ) {
    if ( $vendor && isset( $vendor->vendor_type ) && $vendor->vendor_type === 'fleet' ) { return 'fleet'; }
    return 'individual';
}

/* ------------------------------------------------------------
   READ HELPERS
   ------------------------------------------------------------ */

// TRACE: fleet screens/lead-confirm → SELECT vehicles for one vendor (optionally only
//        a status) ordered by id → returns array of row objects. Preconditions:
//        $vendor_id int. Postconditions: only that vendor's rows. Edge cases:
//        vendor with none → empty array.
function ridego_get_fleet_vehicles( $vendor_id, $status = null ) {
    global $wpdb;
    $sql = "SELECT * FROM {$wpdb->prefix}ridego_fleet_vehicles WHERE vendor_id=%d";
    $args = array( (int) $vendor_id );
    if ( $status ) { $sql .= ' AND status=%s'; $args[] = $status; }
    return $wpdb->get_results( $wpdb->prepare( $sql . ' ORDER BY id ASC', $args ) );
}

// TRACE: same as ridego_get_fleet_vehicles() for drivers.
function ridego_get_fleet_drivers( $vendor_id, $status = null ) {
    global $wpdb;
    $sql = "SELECT * FROM {$wpdb->prefix}ridego_fleet_drivers WHERE vendor_id=%d";
    $args = array( (int) $vendor_id );
    if ( $status ) { $sql .= ' AND status=%s'; $args[] = $status; }
    return $wpdb->get_results( $wpdb->prepare( $sql . ' ORDER BY id ASC', $args ) );
}

// TRACE: table + row id + the lock_version the client last read (or '' / null when the caller didn't
//        send one) → true when safe to proceed with the write, or a conflict array → bool|array.
//        Optimistic concurrency primitive shared by every canonical update function that accepts an
//        optional $expected_lock_version — see ridego_update_fleet_vehicle()/ridego_update_fleet_driver()
//        below, and ridego_app_admin_api_booking_status()'s own inline use of this same function.
//        Preconditions: the table has a lock_version INT column (migration v34). Postconditions: when
//        an expected version IS given, the claim is a SINGLE atomic "UPDATE ... SET lock_version =
//        lock_version + 1 WHERE id = %d AND lock_version = %d" — there is no separate read-then-write
//        step for a second writer to land inside, unlike a naive updated_at-timestamp comparison (which
//        this replaces: adversarial testing during RG-016 found that two writes landing in the same
//        wall-clock second are indistinguishable by a 1-second-precision DATETIME, silently defeating
//        the lock it was supposed to provide — a real, disclosed bug, not a hypothetical). The caller's
//        own subsequent $wpdb->update() for the actual field changes proceeds unconditionally once this
//        claim has succeeded, exactly as it did before locking existed — this function only decides
//        whether that write is allowed to happen. Edge cases: an omitted/empty expected value never
//        blocks the write (opt-in — old API callers and internal/system callers keep working
//        unchanged); a claim that affects 0 rows because the id doesn't exist at all (not just a
//        version mismatch) still reports 'conflict' with current_lock_version null, which callers that
//        already 404 on a missing id will never actually reach.
function ridego_claim_lock_version( $table, $id, $expected_lock_version ) {
    global $wpdb;
    if ( $expected_lock_version === null || $expected_lock_version === '' ) { return true; }
    $claimed = $wpdb->query( $wpdb->prepare(
        "UPDATE {$table} SET lock_version = lock_version + 1 WHERE id = %d AND lock_version = %d",
        (int) $id, (int) $expected_lock_version
    ) );
    if ( (int) $claimed === 1 ) { return true; }
    $current = $wpdb->get_var( $wpdb->prepare( "SELECT lock_version FROM {$table} WHERE id = %d", (int) $id ) );
    return array(
        'success' => false,
        'conflict' => true,
        'message' => 'This record was changed by someone else since you loaded it. Refresh and try again.',
        'current_lock_version' => $current !== null ? (int) $current : null,
    );
}

// TRACE: any single-vehicle lookup → SELECT by id → row object or null. Postconditions:
//        no ownership check (callers compare vendor_id themselves). Edge: unknown id → null.
function ridego_get_fleet_vehicle( $id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_fleet_vehicles WHERE id=%d", (int) $id ) );
}

// TRACE: single-driver lookup, mirrors ridego_get_fleet_vehicle().
function ridego_get_fleet_driver( $id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}ridego_fleet_drivers WHERE id=%d", (int) $id ) );
}

/* ------------------------------------------------------------
   INDIVIDUAL-VENDOR AUTO-PROVISIONING
   ------------------------------------------------------------ */

// TRACE: vendor registration hook / lazy fleet screens / lead confirm → for an
//        INDIVIDUAL vendor with no fleet rows, inserts exactly one driver (from the
//        vendor's own registration name/mobile/licence) and one vehicle (type from
//        the vendor's first registered vehicle type) → returns array('vehicle'=>row,
//        'driver'=>row) or false when the vendor is missing. Preconditions: vendor
//        row exists. Postconditions: individual vendor has >=1 vehicle and >=1 driver;
//        a fleet vendor is never auto-populated (returns their first rows untouched).
//        Edge cases: two concurrent calls (a MySQL named lock serialises them so only
//        one set of rows is created); vendor already provisioned (no inserts); vendor
//        has no vehicle_types JSON (vehicle_type_id 0); GET_LOCK timeout (proceeds
//        without inserting, returns whatever exists).
function ridego_ensure_individual_provisioned( $vendor_id ) {
    global $wpdb;
    $vendor = ridego_get_vendor( (int) $vendor_id );
    if ( ! $vendor ) { return false; }

    if ( ridego_get_vendor_type( $vendor ) === 'individual' ) {
        $lock = 'ridego_prov_' . (int) $vendor->id;
        $got  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 3)', $lock ) );
        if ( $got === 1 ) {
            $drivers  = ridego_get_fleet_drivers( $vendor->id );
            $vehicles = ridego_get_fleet_vehicles( $vendor->id );
            if ( empty( $drivers ) ) {
                $wpdb->insert( "{$wpdb->prefix}ridego_fleet_drivers", array(
                    'vendor_id'        => (int) $vendor->id,
                    'name'             => (string) $vendor->owner_name,
                    'mobile'           => (string) $vendor->phone,
                    'license_number'   => (string) $vendor->license_number,
                    'license_expiry'   => $vendor->license_expiry ?: null,
                    'experience_years' => max( 0, (int) $vendor->years_experience ),
                    'status'           => 'active',
                ) );
            }
            if ( empty( $vehicles ) ) {
                $types   = json_decode( (string) $vendor->vehicle_types, true );
                $type_id = ( is_array( $types ) && ! empty( $types ) ) ? (int) $types[0] : 0;
                $seats   = 4;
                if ( $type_id ) {
                    $vt = ridego_get_vehicle( $type_id );
                    if ( $vt && ! empty( $vt->seating_capacity ) ) { $seats = (int) $vt->seating_capacity; }
                }
                $wpdb->insert( "{$wpdb->prefix}ridego_fleet_vehicles", array(
                    'vendor_id'        => (int) $vendor->id,
                    'vehicle_type_id'  => $type_id,
                    'make_model'       => '',
                    'registration_number' => '',
                    'seating_capacity' => $seats,
                    'status'           => 'active',
                ) );
            }
            $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
        }
    }

    $vehicles = ridego_get_fleet_vehicles( $vendor->id );
    $drivers  = ridego_get_fleet_drivers( $vendor->id );
    return array(
        'vehicle' => $vehicles ? $vehicles[0] : null,
        'driver'  => $drivers ? $drivers[0] : null,
    );
}
add_action( 'ridego_vendor_registered', 'ridego_ensure_individual_provisioned', 10, 1 );

/* ------------------------------------------------------------
   INPUT VALIDATION + CRUD — vehicles
   ------------------------------------------------------------ */

// TRACE: create/update vehicle endpoints → sanitises raw request array into a column
//        map and validates it → returns array('data'=>map,'error'=>null) or
//        array('data'=>null,'error'=>'message'). Preconditions: $raw is an array.
//        Postconditions: registration_number normalised (upper-case alnum, 5-15 chars);
//        seating 1-60; status in active|inactive|maintenance. Only keys present in
//        $raw are returned (so a PATCH-style partial update works). Edge cases:
//        $require_registration true and empty plate (error); malformed plate (error);
//        vehicle_type_id not in the catalog (error); branch_id 0/blank → NULL.
function ridego_validate_fleet_vehicle_input( $raw, $require_registration = true ) {
    $data = array();
    if ( array_key_exists( 'make_model', $raw ) ) { $data['make_model'] = sanitize_text_field( (string) $raw['make_model'] ); }
    if ( array_key_exists( 'registration_number', $raw ) ) {
        $reg = ridego_normalize_registration( $raw['registration_number'] );
        if ( $reg === '' && $require_registration ) { return array( 'data' => null, 'error' => 'Registration number is required.' ); }
        if ( $reg !== '' && ( strlen( $reg ) < 5 || strlen( $reg ) > 15 ) ) { return array( 'data' => null, 'error' => 'Enter a valid registration number (for example MH12AB1234).' ); }
        $data['registration_number'] = $reg;
    } elseif ( $require_registration ) {
        return array( 'data' => null, 'error' => 'Registration number is required.' );
    }
    if ( array_key_exists( 'vehicle_type_id', $raw ) ) {
        $tid = (int) $raw['vehicle_type_id'];
        if ( $tid && ! ridego_get_vehicle( $tid ) ) { return array( 'data' => null, 'error' => 'Unknown vehicle type.' ); }
        $data['vehicle_type_id'] = $tid;
    }
    if ( array_key_exists( 'seating_capacity', $raw ) ) {
        $seats = (int) $raw['seating_capacity'];
        if ( $seats < 1 || $seats > 60 ) { return array( 'data' => null, 'error' => 'Seating capacity must be between 1 and 60.' ); }
        $data['seating_capacity'] = $seats;
    }
    if ( array_key_exists( 'status', $raw ) ) {
        $st = sanitize_key( (string) $raw['status'] );
        if ( ! in_array( $st, array( 'active', 'inactive', 'maintenance' ), true ) ) { return array( 'data' => null, 'error' => 'Invalid status.' ); }
        $data['status'] = $st;
    }
    if ( array_key_exists( 'branch_id', $raw ) ) {
        $bid = (int) $raw['branch_id'];
        $data['branch_id'] = $bid > 0 ? $bid : null;
    }
    return array( 'data' => $data, 'error' => null );
}

// TRACE: create-vehicle endpoint → verifies the vendor is FLEET, the plate is not used by
//        any other vehicle, and a branch (if given) belongs to the vendor → INSERT →
//        returns array('success'=>bool,'message'=>string,'id'=>int). Preconditions:
//        $vendor_id is the authenticated vendor. Postconditions: exactly one new row with
//        status 'active' unless given. Edge cases: individual vendor (refused with an
//        upgrade message); duplicate plate anywhere in the fleet table (refused); DB
//        insert failure (success=false with a generic message, never a false success).
function ridego_create_fleet_vehicle( $vendor_id, $raw ) {
    global $wpdb;
    $vendor = ridego_get_vendor( (int) $vendor_id );
    if ( ! $vendor ) { return array( 'success' => false, 'message' => 'Vendor not found.' ); }
    if ( ridego_get_vendor_type( $vendor ) !== 'fleet' ) {
        return array( 'success' => false, 'message' => 'Your account is an individual vendor account with one vehicle. Contact support to upgrade to a fleet account to add more vehicles.' );
    }
    $v = ridego_validate_fleet_vehicle_input( (array) $raw, true );
    if ( $v['error'] ) { return array( 'success' => false, 'message' => $v['error'] ); }
    $data = $v['data'];
    if ( ridego_fleet_plate_in_use( $data['registration_number'], 0 ) ) {
        return array( 'success' => false, 'message' => 'A vehicle with this registration number is already registered.' );
    }
    if ( ! empty( $data['branch_id'] ) && ! ridego_vendor_owns_branch( $vendor->id, $data['branch_id'] ) ) {
        return array( 'success' => false, 'message' => 'That branch does not belong to your account.' );
    }
    $row = array_merge( array( 'make_model' => '', 'vehicle_type_id' => 0, 'seating_capacity' => 4, 'status' => 'active', 'branch_id' => null ), $data );
    $row['vendor_id'] = (int) $vendor->id;
    $ok = $wpdb->insert( "{$wpdb->prefix}ridego_fleet_vehicles", $row );
    if ( ! $ok ) { return array( 'success' => false, 'message' => 'Could not save the vehicle. Please try again.' ); }
    $id = (int) $wpdb->insert_id;
    ridego_audit_log( 'fleet_vehicle_created', 'fleet_vehicle', $id, '', $row['registration_number'] );
    return array( 'success' => true, 'message' => 'Vehicle added.', 'id' => $id );
}

// TRACE: update-vehicle endpoint → checks ownership, plate uniqueness (excluding itself),
//        branch ownership → UPDATE → returns array(success,message). Preconditions:
//        vehicle exists. Postconditions: only supplied columns changed; historical
//        assignments are untouched (they hold snapshots). Edge cases: not owner (refused);
//        individual vendor clearing the plate (allowed to be blank only via not sending
//        it — an explicit blank is refused because a client-visible vehicle needs a plate);
//        setting the vehicle inactive while it is on a live trip (allowed — warning is
//        returned in 'warning', never a hard block, per plan section J); no supplied fields.
function ridego_update_fleet_vehicle( $id, $vendor_id, $raw, $expected_lock_version = null ) {
    global $wpdb;
    $veh = ridego_get_fleet_vehicle( $id );
    if ( ! $veh || (int) $veh->vendor_id !== (int) $vendor_id ) { return array( 'success' => false, 'message' => 'Vehicle not found.' ); }
    $lock = ridego_claim_lock_version( "{$wpdb->prefix}ridego_fleet_vehicles", $veh->id, $expected_lock_version );
    if ( $lock !== true ) { return $lock; }
    $v = ridego_validate_fleet_vehicle_input( (array) $raw, false );
    if ( $v['error'] ) { return array( 'success' => false, 'message' => $v['error'] ); }
    $data = $v['data'];
    if ( isset( $data['registration_number'] ) && $data['registration_number'] === '' ) {
        return array( 'success' => false, 'message' => 'Registration number cannot be blank.' );
    }
    if ( isset( $data['registration_number'] ) && ridego_fleet_plate_in_use( $data['registration_number'], (int) $veh->id ) ) {
        return array( 'success' => false, 'message' => 'A vehicle with this registration number is already registered.' );
    }
    if ( ! empty( $data['branch_id'] ) && ! ridego_vendor_owns_branch( $vendor_id, $data['branch_id'] ) ) {
        return array( 'success' => false, 'message' => 'That branch does not belong to your account.' );
    }
    if ( empty( $data ) ) { return array( 'success' => false, 'message' => 'Nothing to update.' ); }
    $res = $wpdb->update( "{$wpdb->prefix}ridego_fleet_vehicles", $data, array( 'id' => (int) $veh->id ) );
    if ( $res === false ) { return array( 'success' => false, 'message' => 'Could not save the vehicle. Please try again.' ); }
    ridego_audit_log( 'fleet_vehicle_updated', 'fleet_vehicle', $veh->id, wp_json_encode( array( 'status' => $veh->status, 'reg' => $veh->registration_number ) ), wp_json_encode( $data ) );
    $out = array( 'success' => true, 'message' => 'Vehicle updated.' );
    if ( isset( $data['status'] ) && $data['status'] !== 'active' && ridego_fleet_entity_on_live_trip( 'vehicle', $veh->id ) ) {
        $out['warning'] = 'This vehicle is on an active trip. The trip continues with it, but it will not be offered for new leads.';
    }
    return $out;
}

// TRACE: any plate-duplication check → SELECT id where normalised plate matches and id
//        differs → returns bool. Preconditions: $plate already normalised. Edge cases:
//        empty plate → false (auto-provisioned vehicles start blank and must not collide).
function ridego_fleet_plate_in_use( $plate, $except_id = 0 ) {
    global $wpdb;
    if ( $plate === '' ) { return false; }
    return (bool) $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}ridego_fleet_vehicles WHERE registration_number=%s AND id<>%d LIMIT 1", $plate, (int) $except_id
    ) );
}

/* ------------------------------------------------------------
   INPUT VALIDATION + CRUD — drivers
   ------------------------------------------------------------ */

// TRACE: any driver profile screen/validator → the fields a driver profile MUST have so the driver can be identified and traced in an
//        incident → map field => human label. Pure. Optional extras (alt_mobile, blood_group, badge_number, police verification) are not listed.
function ridego_driver_required_fields() {
    return array(
        'name' => 'full name', 'mobile' => 'mobile number', 'date_of_birth' => 'date of birth', 'license_number' => 'licence number',
        'license_expiry' => 'licence expiry', 'license_class' => 'licence class', 'address' => 'home address', 'city' => 'city',
        'emergency_contact_name' => 'emergency contact name', 'emergency_contact_phone' => 'emergency contact phone',
        'emergency_contact_relation' => 'emergency contact relation', 'id_proof_type' => 'ID proof type', 'id_proof_number' => 'ID proof number',
    );
}

// TRACE: driver row (object|array) → labels of required profile fields that are blank → array of strings (empty = complete). Pure.
//        Edge cases: null row → all labels; a licence already expired counts as missing ("valid licence expiry").
function ridego_driver_missing_fields( $d ) {
    $d = (array) $d; $missing = array();
    foreach ( ridego_driver_required_fields() as $k => $label ) {
        $v = isset( $d[ $k ] ) ? trim( (string) $d[ $k ] ) : '';
        if ( $v === '' || $v === '0000-00-00' ) { $missing[] = $label; }
    }
    if ( ! empty( $d['license_expiry'] ) && strtotime( (string) $d['license_expiry'] ) !== false && strtotime( (string) $d['license_expiry'] ) < strtotime( current_time( 'Y-m-d' ) ) && ! in_array( 'licence expiry', $missing, true ) ) {
        $missing[] = 'valid (unexpired) licence expiry';
    }
    return $missing;
}

// TRACE: id proof number → masked form keeping only the last 4 characters ("XXXXXX1234") → string. Pure. Edge: <=4 chars returned as-is masked fully.
function ridego_mask_id_number( $n ) {
    $n = (string) $n; $len = strlen( $n );
    return $len <= 4 ? str_repeat( 'X', $len ) : str_repeat( 'X', $len - 4 ) . substr( $n, -4 );
}

// TRACE: driver row → the trace snapshot stored on an assignment (identity, contact, licence, address, emergency contact, masked ID) → array. Pure.
//        Postconditions: the full ID number is never copied into the snapshot, only its last four characters.
function ridego_driver_profile_snapshot( $d ) {
    $d = (array) $d;
    $keys = array( 'name', 'mobile', 'alt_mobile', 'date_of_birth', 'blood_group', 'address', 'city', 'pincode', 'license_number', 'license_expiry', 'license_class', 'badge_number',
        'emergency_contact_name', 'emergency_contact_phone', 'emergency_contact_relation', 'id_proof_type', 'police_verification_status', 'police_verification_date' );
    $out = array();
    foreach ( $keys as $k ) { $out[ $k ] = isset( $d[ $k ] ) ? (string) $d[ $k ] : ''; }
    $out['id_proof_number_masked'] = ridego_mask_id_number( $d['id_proof_number'] ?? '' );
    return $out;
}

// TRACE: create/update driver endpoints → sanitises + validates a raw array → returns
//        array('data'=>map|null,'error'=>string|null). Postconditions: mobile reduced to 10-13 digits; dates valid Y-m-d;
//        DOB puts the driver between 18 and 75; licence expiry not in the past; licence class, ID type, blood group, police status
//        from fixed lists; ID number 4-30 letters/digits; pincode 6 digits; experience 0-70; status active|inactive.
//        Edge cases: $require_core true (create) → EVERY field in ridego_driver_required_fields() must be present and non-blank;
//        partial update (only present keys returned, but a present required key may not be blank); malformed date (error).
function ridego_validate_fleet_driver_input( $raw, $require_core = true ) {
    $data = array();
    $req = ridego_driver_required_fields();
    $fail = function ( $m ) { return array( 'data' => null, 'error' => $m ); };
    $text = function ( $k, $max ) use ( $raw ) { return substr( sanitize_text_field( (string) $raw[ $k ] ), 0, $max ); };
    $phone = function ( $v ) { return preg_replace( '/\D/', '', (string) $v ); };
    $date = function ( $v ) { $v = trim( (string) $v ); return ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) && strtotime( $v ) !== false ) ? $v : false; };

    if ( $require_core ) {
        foreach ( $req as $k => $label ) {
            if ( ! array_key_exists( $k, $raw ) || trim( (string) $raw[ $k ] ) === '' ) { return $fail( 'Driver ' . $label . ' is required.' ); }
        }
    }
    foreach ( $req as $k => $label ) {
        if ( array_key_exists( $k, $raw ) && trim( (string) $raw[ $k ] ) === '' ) { return $fail( 'Driver ' . $label . ' cannot be blank.' ); }
    }
    if ( array_key_exists( 'name', $raw ) ) { $data['name'] = $text( 'name', 150 ); }
    if ( array_key_exists( 'mobile', $raw ) ) {
        $d = $phone( $raw['mobile'] );
        if ( strlen( $d ) < 10 || strlen( $d ) > 13 ) { return $fail( 'Enter a valid driver mobile number.' ); }
        $data['mobile'] = $d;
    }
    if ( array_key_exists( 'alt_mobile', $raw ) ) {
        $d = $phone( $raw['alt_mobile'] );
        if ( $d !== '' && ( strlen( $d ) < 10 || strlen( $d ) > 13 ) ) { return $fail( 'Enter a valid alternate mobile number or leave it blank.' ); }
        $data['alt_mobile'] = $d;
    }
    if ( array_key_exists( 'date_of_birth', $raw ) ) {
        $v = $date( $raw['date_of_birth'] );
        if ( $v === false ) { return $fail( 'Date of birth must be a date (YYYY-MM-DD).' ); }
        $age = ( strtotime( current_time( 'Y-m-d' ) ) - strtotime( $v ) ) / ( 365.25 * 86400 );
        if ( $age < 18 || $age > 75 ) { return $fail( 'The driver must be between 18 and 75 years old.' ); }
        $data['date_of_birth'] = $v;
    }
    if ( array_key_exists( 'blood_group', $raw ) ) {
        $bg = strtoupper( trim( (string) $raw['blood_group'] ) );
        if ( $bg !== '' && ! in_array( $bg, array( 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-' ), true ) ) { return $fail( 'Choose a valid blood group.' ); }
        $data['blood_group'] = $bg;
    }
    if ( array_key_exists( 'address', $raw ) ) { $data['address'] = $text( 'address', 255 ); }
    if ( array_key_exists( 'city', $raw ) ) { $data['city'] = $text( 'city', 100 ); }
    if ( array_key_exists( 'pincode', $raw ) ) {
        $pc = preg_replace( '/\D/', '', (string) $raw['pincode'] );
        if ( $pc !== '' && strlen( $pc ) !== 6 ) { return $fail( 'Pincode must be 6 digits.' ); }
        $data['pincode'] = $pc;
    }
    if ( array_key_exists( 'emergency_contact_name', $raw ) ) { $data['emergency_contact_name'] = $text( 'emergency_contact_name', 150 ); }
    if ( array_key_exists( 'emergency_contact_phone', $raw ) ) {
        $d = $phone( $raw['emergency_contact_phone'] );
        if ( strlen( $d ) < 10 || strlen( $d ) > 13 ) { return $fail( 'Enter a valid emergency contact phone number.' ); }
        if ( isset( $data['mobile'] ) && $d === $data['mobile'] ) { return $fail( 'The emergency contact must be someone other than the driver.' ); }
        $data['emergency_contact_phone'] = $d;
    }
    if ( array_key_exists( 'emergency_contact_relation', $raw ) ) { $data['emergency_contact_relation'] = $text( 'emergency_contact_relation', 40 ); }
    if ( array_key_exists( 'id_proof_type', $raw ) ) {
        $t = sanitize_key( (string) $raw['id_proof_type'] );
        if ( ! in_array( $t, array( 'aadhaar', 'voter_id', 'passport', 'pan' ), true ) ) { return $fail( 'Choose a valid ID proof type.' ); }
        $data['id_proof_type'] = $t;
    }
    if ( array_key_exists( 'id_proof_number', $raw ) ) {
        $n = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $raw['id_proof_number'] ) );
        if ( strlen( $n ) < 4 || strlen( $n ) > 30 ) { return $fail( 'Enter a valid ID proof number.' ); }
        $data['id_proof_number'] = $n;
    }
    if ( array_key_exists( 'license_number', $raw ) ) { $data['license_number'] = strtoupper( $text( 'license_number', 50 ) ); }
    if ( array_key_exists( 'license_expiry', $raw ) ) {
        $v = $date( $raw['license_expiry'] );
        if ( $v === false ) { return $fail( 'Licence expiry must be a date (YYYY-MM-DD).' ); }
        if ( strtotime( $v ) < strtotime( current_time( 'Y-m-d' ) ) ) { return $fail( 'This licence has already expired. Enter a valid licence.' ); }
        $data['license_expiry'] = $v;
    }
    if ( array_key_exists( 'license_class', $raw ) ) {
        $lc = strtoupper( sanitize_text_field( (string) $raw['license_class'] ) );
        if ( ! in_array( $lc, array( 'LMV', 'LMV-TR', 'HMV', 'HPMV', 'MCWG' ), true ) ) { return $fail( 'Choose a valid licence class.' ); }
        $data['license_class'] = $lc;
    }
    if ( array_key_exists( 'badge_number', $raw ) ) { $data['badge_number'] = strtoupper( $text( 'badge_number', 40 ) ); }
    if ( array_key_exists( 'police_verification_status', $raw ) ) {
        $ps = sanitize_key( (string) $raw['police_verification_status'] );
        if ( ! in_array( $ps, array( 'none', 'pending', 'verified' ), true ) ) { return $fail( 'Invalid police verification status.' ); }
        $data['police_verification_status'] = $ps;
    }
    if ( array_key_exists( 'police_verification_date', $raw ) ) {
        $v = trim( (string) $raw['police_verification_date'] );
        if ( $v === '' ) { $data['police_verification_date'] = null; }
        elseif ( $date( $v ) === false ) { return $fail( 'Police verification date must be a date (YYYY-MM-DD).' ); }
        else { $data['police_verification_date'] = $v; }
    }
    if ( array_key_exists( 'experience_years', $raw ) ) { $data['experience_years'] = max( 0, min( 70, (int) $raw['experience_years'] ) ); }
    if ( array_key_exists( 'service_area_note', $raw ) ) { $data['service_area_note'] = $text( 'service_area_note', 255 ); }
    if ( array_key_exists( 'status', $raw ) ) {
        $st = sanitize_key( (string) $raw['status'] );
        if ( ! in_array( $st, array( 'active', 'inactive' ), true ) ) { return $fail( 'Invalid status.' ); }
        $data['status'] = $st;
    }
    if ( array_key_exists( 'branch_id', $raw ) ) {
        $bid = (int) $raw['branch_id'];
        $data['branch_id'] = $bid > 0 ? $bid : null;
    }
    return array( 'data' => $data, 'error' => null );
}

// TRACE: create-driver endpoint → fleet-only guard, validation, branch ownership →
//        INSERT → array(success,message,id). Edge cases mirror ridego_create_fleet_vehicle().
function ridego_create_fleet_driver( $vendor_id, $raw ) {
    global $wpdb;
    $vendor = ridego_get_vendor( (int) $vendor_id );
    if ( ! $vendor ) { return array( 'success' => false, 'message' => 'Vendor not found.' ); }
    if ( ridego_get_vendor_type( $vendor ) !== 'fleet' ) {
        return array( 'success' => false, 'message' => 'Your account is an individual vendor account with one driver profile. Contact support to upgrade to a fleet account to add more drivers.' );
    }
    $v = ridego_validate_fleet_driver_input( (array) $raw, true );
    if ( $v['error'] ) { return array( 'success' => false, 'message' => $v['error'] ); }
    $data = $v['data'];
    if ( ! empty( $data['branch_id'] ) && ! ridego_vendor_owns_branch( $vendor->id, $data['branch_id'] ) ) {
        return array( 'success' => false, 'message' => 'That branch does not belong to your account.' );
    }
    $row = array_merge( array( 'status' => 'active', 'branch_id' => null ), $data );
    $row['vendor_id'] = (int) $vendor->id;
    $ok = $wpdb->insert( "{$wpdb->prefix}ridego_fleet_drivers", $row );
    if ( ! $ok ) { return array( 'success' => false, 'message' => 'Could not save the driver. Please try again.' ); }
    $id = (int) $wpdb->insert_id;
    ridego_audit_log( 'fleet_driver_created', 'fleet_driver', $id, '', $row['name'] );
    return array( 'success' => true, 'message' => 'Driver added.', 'id' => $id );
}

// TRACE: update-driver endpoint → ownership + validation → UPDATE → array(success,message
//        [,warning]). Postconditions: when licence_expiry/name/mobile of an INDIVIDUAL
//        vendor's own driver row changes, the vendor's own record is kept in step
//        (license_expiry mirrored) so KYC expiry checks and the driver row never disagree.
//        Edge cases: not owner; empty payload; deactivating a driver on a live trip (warning).
function ridego_update_fleet_driver( $id, $vendor_id, $raw, $expected_lock_version = null ) {
    global $wpdb;
    $drv = ridego_get_fleet_driver( $id );
    if ( ! $drv || (int) $drv->vendor_id !== (int) $vendor_id ) { return array( 'success' => false, 'message' => 'Driver not found.' ); }
    $lock = ridego_claim_lock_version( "{$wpdb->prefix}ridego_fleet_drivers", $drv->id, $expected_lock_version );
    if ( $lock !== true ) { return $lock; }
    $raw = (array) $raw;
    // A form re-sending the stored (possibly now expired) licence expiry unchanged must not block unrelated edits such as deactivating the driver.
    if ( isset( $raw['license_expiry'] ) && (string) $raw['license_expiry'] === (string) $drv->license_expiry ) { unset( $raw['license_expiry'] ); }
    $v = ridego_validate_fleet_driver_input( $raw, false );
    if ( $v['error'] ) { return array( 'success' => false, 'message' => $v['error'] ); }
    $data = $v['data'];
    if ( empty( $data ) ) { return array( 'success' => false, 'message' => 'Nothing to update.' ); }
    if ( ! empty( $data['branch_id'] ) && ! ridego_vendor_owns_branch( $vendor_id, $data['branch_id'] ) ) {
        return array( 'success' => false, 'message' => 'That branch does not belong to your account.' );
    }
    $res = $wpdb->update( "{$wpdb->prefix}ridego_fleet_drivers", $data, array( 'id' => (int) $drv->id ) );
    if ( $res === false ) { return array( 'success' => false, 'message' => 'Could not save the driver. Please try again.' ); }
    ridego_audit_log( 'fleet_driver_updated', 'fleet_driver', $drv->id, wp_json_encode( array( 'status' => $drv->status ) ), wp_json_encode( $data ) );
    $out = array( 'success' => true, 'message' => 'Driver updated.' );
    $missing = ridego_driver_missing_fields( ridego_get_fleet_driver( $drv->id ) );
    if ( $missing ) { $out['message'] = 'Driver updated, but the profile is still incomplete: ' . implode( ', ', $missing ) . '. An incomplete driver cannot be assigned to trips.'; $out['missing'] = $missing; }
    if ( isset( $data['status'] ) && $data['status'] !== 'active' && ridego_fleet_entity_on_live_trip( 'driver', $drv->id ) ) {
        $out['warning'] = 'This driver is on an active trip. The trip continues with them, but they will not be offered for new leads.';
    }
    return $out;
}

// TRACE: delete endpoint → refuses for individual vendors; if the entity is referenced by
//        any assignment/lead it is DEACTIVATED (history preserved) else hard-deleted along
//        with its own document rows → returns array(success,message,mode 'deleted'|
//        'deactivated'). Preconditions: $type in vehicle|driver. Edge cases: not owner;
//        individual vendor (refused — their single record can only be edited); referenced
//        entity (deactivated, mode says so); DB failure (success=false).
function ridego_delete_fleet_entity( $type, $id, $vendor_id ) {
    global $wpdb;
    $type = $type === 'driver' ? 'driver' : 'vehicle';
    $row  = $type === 'driver' ? ridego_get_fleet_driver( $id ) : ridego_get_fleet_vehicle( $id );
    if ( ! $row || (int) $row->vendor_id !== (int) $vendor_id ) { return array( 'success' => false, 'message' => 'Not found.' ); }
    $vendor = ridego_get_vendor( (int) $vendor_id );
    if ( ridego_get_vendor_type( $vendor ) !== 'fleet' ) {
        return array( 'success' => false, 'message' => 'Individual vendor accounts keep one vehicle and one driver profile. Edit it instead of removing it.' );
    }
    $col   = $type === 'driver' ? 'driver_id' : 'vehicle_id';
    $table = $type === 'driver' ? "{$wpdb->prefix}ridego_fleet_drivers" : "{$wpdb->prefix}ridego_fleet_vehicles";
    $refs  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_booking_assignments WHERE {$col}=%d", (int) $id ) )
           + (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_leads WHERE {$col}=%d", (int) $id ) );
    if ( $refs > 0 ) {
        $wpdb->update( $table, array( 'status' => 'inactive' ), array( 'id' => (int) $id ) );
        ridego_audit_log( 'fleet_' . $type . '_deactivated', 'fleet_' . $type, $id, '', 'has history' );
        return array( 'success' => true, 'mode' => 'deactivated', 'message' => 'It has trip history, so it was deactivated instead of deleted.' );
    }
    $wpdb->delete( "{$wpdb->prefix}ridego_driver_docs", array( $col => (int) $id ) );
    $res = $wpdb->delete( $table, array( 'id' => (int) $id ) );
    if ( ! $res ) { return array( 'success' => false, 'message' => 'Could not delete. Please try again.' ); }
    ridego_audit_log( 'fleet_' . $type . '_deleted', 'fleet_' . $type, $id );
    return array( 'success' => true, 'mode' => 'deleted', 'message' => 'Deleted.' );
}

/* ------------------------------------------------------------
   VENDOR TYPE (admin-changeable)
   ------------------------------------------------------------ */

// TRACE: admin "change vendor type" endpoint → validates target, blocks fleet→individual
//        while >1 active vehicle/driver exists, UPDATEs vendor_type, provisions the
//        single vehicle/driver rows for a new individual → returns array(success,message).
//        Preconditions: caller already authorised. Postconditions: vendors.vendor_type is
//        the new value; no fleet row is ever deleted. Edge cases: unknown vendor; invalid
//        type; already that type (success, no-op); fleet→individual with extra active rows
//        (refused, tells the admin what to deactivate); DB failure.
function ridego_set_vendor_type( $vendor_id, $type ) {
    global $wpdb;
    $type   = $type === 'fleet' ? 'fleet' : ( $type === 'individual' ? 'individual' : '' );
    $vendor = ridego_get_vendor( (int) $vendor_id );
    if ( ! $vendor ) { return array( 'success' => false, 'message' => 'Vendor not found.' ); }
    if ( $type === '' ) { return array( 'success' => false, 'message' => 'Vendor type must be individual or fleet.' ); }
    $current = ridego_get_vendor_type( $vendor );
    if ( $current === $type ) { return array( 'success' => true, 'message' => 'Vendor type unchanged.' ); }
    if ( $type === 'individual' ) {
        $av = count( ridego_get_fleet_vehicles( $vendor->id, 'active' ) );
        $ad = count( ridego_get_fleet_drivers( $vendor->id, 'active' ) );
        if ( $av > 1 || $ad > 1 ) {
            return array( 'success' => false, 'message' => "This vendor has {$av} active vehicles and {$ad} active drivers. Deactivate all but one of each before switching to an individual account." );
        }
    }
    $res = $wpdb->update( "{$wpdb->prefix}ridego_vendors", array( 'vendor_type' => $type ), array( 'id' => (int) $vendor->id ) );
    if ( $res === false ) { return array( 'success' => false, 'message' => 'Could not change vendor type. Please try again.' ); }
    ridego_audit_log( 'vendor_type_changed', 'vendor', $vendor->id, $current, $type );
    if ( $type === 'individual' ) { ridego_ensure_individual_provisioned( $vendor->id ); }
    return array( 'success' => true, 'message' => 'Vendor type changed to ' . $type . '.' );
}

/* ------------------------------------------------------------
   BRANCHES
   ------------------------------------------------------------ */

// TRACE: fleet validation code → SELECT branch by id+vendor → returns bool. Edge: 0 id → false.
function ridego_vendor_owns_branch( $vendor_id, $branch_id ) {
    global $wpdb;
    if ( (int) $branch_id <= 0 ) { return false; }
    return (bool) $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}ridego_vendor_branches WHERE id=%d AND vendor_id=%d", (int) $branch_id, (int) $vendor_id
    ) );
}

// TRACE: branches list endpoint → SELECT branches joined to city name for one vendor →
//        array of row objects (with city_name). Edge: none → empty array.
function ridego_get_vendor_branches( $vendor_id ) {
    global $wpdb;
    return $wpdb->get_results( $wpdb->prepare(
        "SELECT br.*, c.name AS city_name FROM {$wpdb->prefix}ridego_vendor_branches br
         LEFT JOIN {$wpdb->prefix}ridego_cities c ON c.id = br.city_id
         WHERE br.vendor_id=%d ORDER BY br.is_primary DESC, br.id ASC", (int) $vendor_id
    ) );
}

// TRACE: create/update branch endpoints → fleet-only, validates name + city, applies
//        is_primary exclusivity in a transaction → returns array(success,message,id).
//        $id 0 creates. Preconditions: caller is the vendor. Postconditions: at most one
//        primary branch per vendor. Edge cases: individual vendor (refused); blank name;
//        unknown city; updating another vendor's branch (not found); DB failure.
function ridego_save_vendor_branch( $vendor_id, $id, $raw ) {
    global $wpdb;
    $vendor = ridego_get_vendor( (int) $vendor_id );
    if ( ! $vendor ) { return array( 'success' => false, 'message' => 'Vendor not found.' ); }
    if ( ridego_get_vendor_type( $vendor ) !== 'fleet' ) {
        return array( 'success' => false, 'message' => 'Branches are available on fleet accounts only.' );
    }
    $tbl = "{$wpdb->prefix}ridego_vendor_branches";
    $name = sanitize_text_field( (string) ( $raw['name'] ?? '' ) );
    if ( $name === '' ) { return array( 'success' => false, 'message' => 'Branch name is required.' ); }
    $city_id = (int) ( $raw['city_id'] ?? 0 );
    if ( $city_id <= 0 || ! ridego_get_city( $city_id ) ) { return array( 'success' => false, 'message' => 'Choose a valid city for the branch.' ); }
    $row = array(
        'name'    => $name,
        'address' => sanitize_textarea_field( (string) ( $raw['address'] ?? '' ) ),
        'city_id' => $city_id,
        'lat'     => ( isset( $raw['lat'] ) && $raw['lat'] !== '' ) ? (float) $raw['lat'] : null,
        'lng'     => ( isset( $raw['lng'] ) && $raw['lng'] !== '' ) ? (float) $raw['lng'] : null,
        'is_primary' => ! empty( $raw['is_primary'] ) ? 1 : 0,
        'status'  => ( isset( $raw['status'] ) && $raw['status'] === 'inactive' ) ? 'inactive' : 'active',
    );
    $wpdb->query( 'START TRANSACTION' );
    if ( $id > 0 ) {
        $existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id=%d AND vendor_id=%d FOR UPDATE", (int) $id, (int) $vendor->id ) );
        if ( ! $existing ) { $wpdb->query( 'ROLLBACK' ); return array( 'success' => false, 'message' => 'Branch not found.' ); }
        $res = $wpdb->update( $tbl, $row, array( 'id' => (int) $id ) );
        $new_id = (int) $id;
    } else {
        $row['vendor_id'] = (int) $vendor->id;
        $res = $wpdb->insert( $tbl, $row );
        $new_id = (int) $wpdb->insert_id;
    }
    if ( $res === false || ! $new_id ) { $wpdb->query( 'ROLLBACK' ); return array( 'success' => false, 'message' => 'Could not save the branch. Please try again.' ); }
    if ( $row['is_primary'] ) {
        $wpdb->query( $wpdb->prepare( "UPDATE {$tbl} SET is_primary=0 WHERE vendor_id=%d AND id<>%d", (int) $vendor->id, $new_id ) );
    }
    $wpdb->query( 'COMMIT' );
    ridego_audit_log( $id > 0 ? 'vendor_branch_updated' : 'vendor_branch_created', 'vendor_branch', $new_id, '', $name );
    return array( 'success' => true, 'message' => 'Branch saved.', 'id' => $new_id );
}

// TRACE: delete-branch endpoint → detaches vehicles/drivers (branch_id → NULL) then deletes
//        the branch → array(success,message). Edge: not owner → not found; DB failure.
function ridego_delete_vendor_branch( $vendor_id, $id ) {
    global $wpdb;
    if ( ! ridego_vendor_owns_branch( $vendor_id, $id ) ) { return array( 'success' => false, 'message' => 'Branch not found.' ); }
    $wpdb->update( "{$wpdb->prefix}ridego_fleet_vehicles", array( 'branch_id' => null ), array( 'branch_id' => (int) $id ) );
    $wpdb->update( "{$wpdb->prefix}ridego_fleet_drivers", array( 'branch_id' => null ), array( 'branch_id' => (int) $id ) );
    $res = $wpdb->delete( "{$wpdb->prefix}ridego_vendor_branches", array( 'id' => (int) $id ) );
    if ( ! $res ) { return array( 'success' => false, 'message' => 'Could not delete the branch.' ); }
    ridego_audit_log( 'vendor_branch_deleted', 'vendor_branch', $id );
    return array( 'success' => true, 'message' => 'Branch deleted.' );
}

/* ------------------------------------------------------------
   AVAILABILITY  (plan section G)
   ------------------------------------------------------------ */

// TRACE: availability + assignment code → derives [start_ts, end_ts] for a booking from
//        journey_date/time, return_date/time, duration_minutes, hours_required, else the
//        default_trip_hours setting (6h) → returns array(int,int). Preconditions: $b has
//        the booking columns. Postconditions: end > start always. Edge cases: return leg
//        earlier than the outbound (ignored, falls back to duration); missing time
//        (00:00); no duration info (default hours).
function ridego_booking_window( $b ) {
    $time  = ! empty( $b->journey_time ) ? $b->journey_time : '00:00:00';
    $start = strtotime( $b->journey_date . ' ' . $time );
    $end   = 0;
    if ( ! empty( $b->return_date ) ) {
        $rt  = ! empty( $b->return_time ) ? $b->return_time : '23:59:00';
        $end = strtotime( $b->return_date . ' ' . $rt );
    }
    if ( ! $end || $end <= $start ) {
        if ( ! empty( $b->duration_minutes ) && (int) $b->duration_minutes > 0 ) {
            $end = $start + (int) $b->duration_minutes * 60;
        } elseif ( ! empty( $b->hours_required ) && (int) $b->hours_required > 0 ) {
            $end = $start + (int) $b->hours_required * 3600;
        } else {
            $hours = (float) ridego_get_setting( 'default_trip_hours', 6 );
            $end   = $start + (int) round( max( 1, $hours ) * 3600 );
        }
    }
    return array( (int) $start, (int) $end );
}

// TRACE: lead-confirm / selection list / replacement → minutes a booking occupies →
//        int minutes >= 1 derived from ridego_booking_window(). Edge: none.
function ridego_booking_duration_minutes( $b ) {
    list( $s, $e ) = ridego_booking_window( $b );
    return max( 1, (int) round( ( $e - $s ) / 60 ) );
}

// TRACE: the ONE availability function (three callers must never disagree: selection
//        screen, server-side confirm validation, future auto-assignment) →
//        rules: entity exists; entity.status='active'; driver licence / vehicle
//        insurance-permit-fitness documents not expired on the trip date; no current
//        assignment on a committed booking whose window (± turnaround buffer) overlaps;
//        no fleet_unavailability window overlapping → returns array('available'=>bool,
//        'reason'=>string,'conflict'=>null|array). Preconditions: $entity_type in
//        vehicle|driver; $date 'Y-m-d'; $time 'H:i[:s]'; $duration minutes > 0.
//        Postconditions: read-only (no writes). Edge cases: unknown entity (unavailable);
//        malformed date/time or non-positive duration (unavailable 'Invalid trip window');
//        $exclude_booking_id ignores that booking's own assignment (replacement flow);
//        a cancelled/completed booking's leftover current assignment never blocks.
function ridego_check_fleet_availability( $entity_type, $entity_id, $date, $time, $duration, $exclude_booking_id = 0 ) {
    global $wpdb;
    $entity_type = $entity_type === 'driver' ? 'driver' : 'vehicle';
    $row = $entity_type === 'driver' ? ridego_get_fleet_driver( $entity_id ) : ridego_get_fleet_vehicle( $entity_id );
    if ( ! $row ) { return array( 'available' => false, 'reason' => 'Not found.', 'conflict' => null ); }
    if ( $row->status !== 'active' ) {
        return array( 'available' => false, 'reason' => $row->status === 'maintenance' ? 'Under maintenance.' : 'Marked inactive.', 'conflict' => null );
    }

    $start = strtotime( trim( $date . ' ' . ( $time !== '' ? $time : '00:00' ) ) );
    $dur   = (int) $duration;
    if ( ! $start || $dur <= 0 ) { return array( 'available' => false, 'reason' => 'Invalid trip window.', 'conflict' => null ); }
    $end = $start + $dur * 60;
    $trip_day = date( 'Y-m-d', $start );

    if ( $entity_type === 'driver' && ! empty( $row->license_expiry ) && $row->license_expiry < $trip_day ) {
        return array( 'available' => false, 'reason' => 'Driver licence expires before this trip.', 'conflict' => null );
    }
    if ( $entity_type === 'vehicle' ) {
        $expired = $wpdb->get_var( $wpdb->prepare(
            "SELECT doc_type FROM {$wpdb->prefix}ridego_driver_docs
             WHERE vehicle_id=%d AND doc_type IN ('vehicle_insurance','permit','fitness')
               AND expiry_date IS NOT NULL AND expiry_date < %s AND status <> 'rejected' LIMIT 1",
            (int) $entity_id, $trip_day
        ) );
        if ( $expired ) {
            return array( 'available' => false, 'reason' => ucfirst( str_replace( '_', ' ', preg_replace( '/^vehicle_/', '', $expired ) ) ) . ' document expires before this trip.', 'conflict' => null );
        }
    }

    $buffer = max( 0, (int) ridego_get_setting( 'fleet_turnaround_minutes', 30 ) ) * 60;
    $col    = $entity_type === 'driver' ? 'a.driver_id' : 'a.vehicle_id';
    $statuses = "'" . implode( "','", ridego_fleet_committed_statuses() ) . "'";
    $lo = date( 'Y-m-d', $start - 45 * DAY_IN_SECONDS );
    $hi = date( 'Y-m-d', $end + DAY_IN_SECONDS );
    $cands = $wpdb->get_results( $wpdb->prepare(
        "SELECT b.id, b.booking_number, b.journey_date, b.journey_time, b.return_date, b.return_time, b.duration_minutes, b.hours_required
         FROM {$wpdb->prefix}ridego_booking_assignments a
         JOIN {$wpdb->prefix}ridego_bookings b ON b.id = a.booking_id
         WHERE {$col}=%d AND a.is_current=1 AND b.id<>%d AND b.status IN ({$statuses})
           AND b.journey_date BETWEEN %s AND %s",
        (int) $entity_id, (int) $exclude_booking_id, $lo, $hi
    ) );
    foreach ( (array) $cands as $c ) {
        list( $bs, $be ) = ridego_booking_window( $c );
        if ( ( $bs - $buffer ) < $end && ( $be + $buffer ) > $start ) {
            return array(
                'available' => false,
                'reason'    => 'Already assigned to booking ' . $c->booking_number . ' at that time.',
                'conflict'  => array( 'booking_id' => (int) $c->id, 'booking_number' => $c->booking_number ),
            );
        }
    }

    $blk = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_fleet_unavailability
         WHERE entity_type=%s AND entity_id=%d AND starts_at < %s AND ends_at > %s ORDER BY starts_at ASC LIMIT 1",
        $entity_type, (int) $entity_id, date( 'Y-m-d H:i:s', $end ), date( 'Y-m-d H:i:s', $start )
    ) );
    if ( $blk ) {
        return array(
            'available' => false,
            'reason'    => 'Unavailable' . ( $blk->reason ? ': ' . $blk->reason : '' ) . '.',
            'conflict'  => array( 'unavailability_id' => (int) $blk->id ),
        );
    }
    return array( 'available' => true, 'reason' => '', 'conflict' => null );
}

// TRACE: fleet list screens → classifies a vehicle/driver right now as 'available' |
//        'on_trip' | 'unavailable' from live data (never a stored flag) → returns
//        string. Preconditions: $row is a fleet row object. Postconditions: read-only.
//        Edge cases: status inactive/maintenance → unavailable; a planned block covering
//        now → unavailable; a committed booking whose window contains now, or whose
//        status is driver_en_route/trip_started → on_trip.
function ridego_fleet_live_status( $entity_type, $row ) {
    global $wpdb;
    if ( ! $row ) { return 'unavailable'; }
    if ( $row->status !== 'active' ) { return 'unavailable'; }
    $entity_type = $entity_type === 'driver' ? 'driver' : 'vehicle';
    $now = current_time( 'mysql' );
    $blk = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}ridego_fleet_unavailability WHERE entity_type=%s AND entity_id=%d AND starts_at<=%s AND ends_at>%s LIMIT 1",
        $entity_type, (int) $row->id, $now, $now
    ) );
    if ( $blk ) { return 'unavailable'; }
    return ridego_fleet_entity_on_live_trip( $entity_type, $row->id ) ? 'on_trip' : 'available';
}

// TRACE: live-status + update warnings → SELECT current assignments on committed
//        bookings for the entity and tests whether now falls inside a booking window or
//        the trip has physically begun → returns bool. Edge cases: no assignment → false.
function ridego_fleet_entity_on_live_trip( $entity_type, $entity_id ) {
    global $wpdb;
    $col = $entity_type === 'driver' ? 'a.driver_id' : 'a.vehicle_id';
    $statuses = "'" . implode( "','", ridego_fleet_committed_statuses() ) . "'";
    $rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT b.status, b.journey_date, b.journey_time, b.return_date, b.return_time, b.duration_minutes, b.hours_required
         FROM {$wpdb->prefix}ridego_booking_assignments a JOIN {$wpdb->prefix}ridego_bookings b ON b.id=a.booking_id
         WHERE {$col}=%d AND a.is_current=1 AND b.status IN ({$statuses})", (int) $entity_id
    ) );
    $now = time();
    foreach ( (array) $rows as $r ) {
        if ( in_array( $r->status, array( 'driver_en_route', 'trip_started' ), true ) ) { return true; }
        list( $s, $e ) = ridego_booking_window( $r );
        if ( $now >= $s && $now <= $e ) { return true; }
    }
    return false;
}

/* ------------------------------------------------------------
   UNAVAILABILITY BLOCKS
   ------------------------------------------------------------ */

// TRACE: parse helper for datetime inputs → accepts 'Y-m-d H:i[:s]' or 'Y-m-dTH:i[:s]' →
//        returns 'Y-m-d H:i:s' or '' if unparseable. Edge: empty → ''.
function ridego_fleet_parse_datetime( $value ) {
    $value = trim( str_replace( 'T', ' ', (string) $value ) );
    if ( $value === '' || ! preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?$/', $value ) ) { return ''; }
    $ts = strtotime( $value );
    return $ts ? date( 'Y-m-d H:i:s', $ts ) : '';
}

// TRACE: add-block endpoint → verifies the entity belongs to the vendor, window is valid
//        and ends after it starts → INSERT → returns array(success,message,id,conflicts[]).
//        Postconditions: one row; 'conflicts' lists committed bookings it overlaps (a
//        warning, not a block — a real reason such as breakdown cannot be prevented, only
//        flagged, per plan section J). Edge cases: bad datetime; ends<=starts; entity of
//        another vendor; DB failure.
function ridego_create_fleet_unavailability( $vendor_id, $entity_type, $entity_id, $starts, $ends, $reason, $user_id ) {
    global $wpdb;
    $entity_type = $entity_type === 'driver' ? 'driver' : ( $entity_type === 'vehicle' ? 'vehicle' : '' );
    if ( $entity_type === '' ) { return array( 'success' => false, 'message' => 'Choose a vehicle or driver.' ); }
    $row = $entity_type === 'driver' ? ridego_get_fleet_driver( $entity_id ) : ridego_get_fleet_vehicle( $entity_id );
    if ( ! $row || (int) $row->vendor_id !== (int) $vendor_id ) { return array( 'success' => false, 'message' => 'Not found.' ); }
    $s = ridego_fleet_parse_datetime( $starts );
    $e = ridego_fleet_parse_datetime( $ends );
    if ( $s === '' || $e === '' ) { return array( 'success' => false, 'message' => 'Enter valid start and end date/times.' ); }
    if ( strtotime( $e ) <= strtotime( $s ) ) { return array( 'success' => false, 'message' => 'The end must be after the start.' ); }
    $ok = $wpdb->insert( "{$wpdb->prefix}ridego_fleet_unavailability", array(
        'vendor_id'   => (int) $vendor_id,
        'entity_type' => $entity_type,
        'entity_id'   => (int) $entity_id,
        'starts_at'   => $s,
        'ends_at'     => $e,
        'reason'      => substr( sanitize_text_field( (string) $reason ), 0, 255 ),
        'created_by'  => (int) $user_id,
    ) );
    if ( ! $ok ) { return array( 'success' => false, 'message' => 'Could not save. Please try again.' ); }
    $id = (int) $wpdb->insert_id;

    $conflicts = array();
    $col = $entity_type === 'driver' ? 'a.driver_id' : 'a.vehicle_id';
    $statuses = "'" . implode( "','", ridego_fleet_committed_statuses() ) . "'";
    $cands = $wpdb->get_results( $wpdb->prepare(
        "SELECT b.id, b.booking_number, b.journey_date, b.journey_time, b.return_date, b.return_time, b.duration_minutes, b.hours_required
         FROM {$wpdb->prefix}ridego_booking_assignments a JOIN {$wpdb->prefix}ridego_bookings b ON b.id=a.booking_id
         WHERE {$col}=%d AND a.is_current=1 AND b.status IN ({$statuses})", (int) $entity_id
    ) );
    foreach ( (array) $cands as $c ) {
        list( $bs, $be ) = ridego_booking_window( $c );
        if ( $bs < strtotime( $e ) && $be > strtotime( $s ) ) { $conflicts[] = $c->booking_number; }
    }
    return array( 'success' => true, 'message' => 'Unavailability saved.', 'id' => $id, 'conflicts' => $conflicts );
}

// TRACE: delete-block endpoint → deletes a block owned by the vendor → array(success,message).
//        Edge: not owner / unknown → not found.
function ridego_delete_fleet_unavailability( $vendor_id, $id ) {
    global $wpdb;
    $res = $wpdb->delete( "{$wpdb->prefix}ridego_fleet_unavailability", array( 'id' => (int) $id, 'vendor_id' => (int) $vendor_id ) );
    if ( ! $res ) { return array( 'success' => false, 'message' => 'Not found.' ); }
    return array( 'success' => true, 'message' => 'Removed.' );
}

// TRACE: availability calendar → SELECT one vendor's blocks (optionally from a date) ordered
//        by start → array of row objects. Edge: none.
function ridego_get_fleet_unavailability( $vendor_id, $from = '' ) {
    global $wpdb;
    $sql = "SELECT * FROM {$wpdb->prefix}ridego_fleet_unavailability WHERE vendor_id=%d";
    $args = array( (int) $vendor_id );
    if ( $from ) { $sql .= ' AND ends_at >= %s'; $args[] = $from; }
    return $wpdb->get_results( $wpdb->prepare( $sql . ' ORDER BY starts_at ASC', $args ) );
}

/* ------------------------------------------------------------
   SELECTION LIST FOR A LEAD ("Confirm Vehicle & Driver")
   ------------------------------------------------------------ */

// TRACE: fleet vendor's confirm screen → for one lead's booking, lists every ACTIVE vehicle and
//        driver of the vendor with availability computed for that booking's window; branches in
//        the pickup city sort first (preferred, not exclusive), then available before
//        unavailable → returns array('vehicles'=>[...],'drivers'=>[...],'window'=>[...]).
//        Preconditions: $booking is a ridego_get_booking() row. Postconditions: read-only.
//        Edge cases: vendor with no branches (no preference); vehicle type differing from the
//        booking's type is flagged 'type_mismatch' (still listed so the vendor sees why).
function ridego_fleet_selection_options( $vendor_id, $booking ) {
    $branches = ridego_get_vendor_branches( $vendor_id );
    $pref_ids = array();
    foreach ( $branches as $br ) {
        if ( $br->status === 'active' && ! empty( $br->city_name ) && strcasecmp( $br->city_name, (string) $booking->pickup_city ) === 0 ) {
            $pref_ids[ (int) $br->id ] = true;
        }
    }
    $duration = ridego_booking_duration_minutes( $booking );
    $time = ! empty( $booking->journey_time ) ? $booking->journey_time : '00:00';

    $vehicles = array();
    foreach ( ridego_get_fleet_vehicles( $vendor_id, 'active' ) as $v ) {
        $av = ridego_check_fleet_availability( 'vehicle', $v->id, $booking->journey_date, $time, $duration, $booking->id );
        $mismatch = ( (int) $booking->vehicle_type_id > 0 && (int) $v->vehicle_type_id > 0 && (int) $v->vehicle_type_id !== (int) $booking->vehicle_type_id );
        $vehicles[] = array(
            'id' => (int) $v->id, 'make_model' => $v->make_model, 'registration_number' => $v->registration_number,
            'vehicle_type_id' => (int) $v->vehicle_type_id, 'seating_capacity' => (int) $v->seating_capacity,
            'branch_id' => $v->branch_id ? (int) $v->branch_id : null,
            'preferred' => $v->branch_id && isset( $pref_ids[ (int) $v->branch_id ] ),
            'available' => $av['available'] && ! $mismatch,
            'reason'    => $mismatch ? 'Different vehicle type from the one booked.' : $av['reason'],
            'type_mismatch' => $mismatch,
        );
    }
    $drivers = array();
    foreach ( ridego_get_fleet_drivers( $vendor_id, 'active' ) as $d ) {
        $av = ridego_check_fleet_availability( 'driver', $d->id, $booking->journey_date, $time, $duration, $booking->id );
        $drivers[] = array(
            'id' => (int) $d->id, 'name' => $d->name, 'mobile' => $d->mobile, 'rating' => (float) $d->rating,
            'branch_id' => $d->branch_id ? (int) $d->branch_id : null,
            'preferred' => $d->branch_id && isset( $pref_ids[ (int) $d->branch_id ] ),
            'available' => $av['available'], 'reason' => $av['reason'],
            'profile_missing' => ridego_driver_missing_fields( $d ), 'profile_complete' => ! ridego_driver_missing_fields( $d ),
        );
    }
    $sorter = function ( $a, $b ) {
        if ( $a['available'] !== $b['available'] ) { return $a['available'] ? -1 : 1; }
        if ( $a['preferred'] !== $b['preferred'] ) { return $a['preferred'] ? -1 : 1; }
        return $a['id'] <=> $b['id'];
    };
    usort( $vehicles, $sorter );
    usort( $drivers, $sorter );
    return array( 'vehicles' => $vehicles, 'drivers' => $drivers, 'window' => array( 'date' => $booking->journey_date, 'time' => $time, 'duration_minutes' => $duration ) );
}

/* ------------------------------------------------------------
   DOCUMENT VALIDITY CHIP + FLEET DOCUMENTS
   ------------------------------------------------------------ */

// TRACE: any document list → maps an expiry date to 'valid' | 'expiring_soon' (<=30 days) |
//        'expired' | 'no_expiry' → returns string. Edge: empty/invalid date → 'no_expiry'.
function ridego_doc_validity( $expiry_date ) {
    if ( empty( $expiry_date ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}/', (string) $expiry_date ) ) { return 'no_expiry'; }
    $today = date( 'Y-m-d' );
    if ( substr( $expiry_date, 0, 10 ) < $today ) { return 'expired'; }
    if ( substr( $expiry_date, 0, 10 ) <= date( 'Y-m-d', strtotime( '+30 days' ) ) ) { return 'expiring_soon'; }
    return 'valid';
}

// TRACE: fleet document endpoints → allowed doc types for vehicle vs driver → returns array
//        of doc_type strings. Edge: unknown entity_type → driver types.
function ridego_fleet_doc_types( $entity_type ) {
    return $entity_type === 'vehicle'
        ? array( 'vehicle_rc', 'vehicle_insurance', 'permit', 'fitness' )
        : array( 'driver_photo', 'driving_license', 'id_proof', 'address_proof', 'police_verification' );
}

// TRACE: any doc upload → doc_type → whether the document carries an expiry date → bool.
//        Preconditions: none. Postconditions: single source of truth for the server; mirrored by app/src/lib/doc-types.ts.
//        Edge cases: unknown type → false (no expiry ever stored for photos, PAN, ID and address proofs).
function ridego_doc_type_needs_expiry( $doc_type ) {
    return in_array( $doc_type, array( 'driving_license', 'vehicle_insurance', 'permit', 'fitness', 'vehicle_rc', 'police_verification' ), true );
}

// TRACE: fleet document list → SELECT documents of one vendor scoped to vehicles/drivers
//        (vehicle_id or driver_id NOT NULL) optionally for one entity → array of row objects
//        each with ->validity. Edge: none → empty array.
function ridego_get_fleet_docs( $vendor_id, $entity_type = '', $entity_id = 0 ) {
    global $wpdb;
    $sql  = "SELECT * FROM {$wpdb->prefix}ridego_driver_docs WHERE vendor_id=%d";
    $args = array( (int) $vendor_id );
    if ( $entity_type === 'vehicle' ) {
        $sql .= $entity_id ? ' AND vehicle_id=%d' : ' AND vehicle_id IS NOT NULL';
        if ( $entity_id ) { $args[] = (int) $entity_id; }
    } elseif ( $entity_type === 'driver' ) {
        $sql .= $entity_id ? ' AND driver_id=%d' : ' AND driver_id IS NOT NULL';
        if ( $entity_id ) { $args[] = (int) $entity_id; }
    } else {
        $sql .= ' AND (vehicle_id IS NOT NULL OR driver_id IS NOT NULL)';
    }
    $rows = $wpdb->get_results( $wpdb->prepare( $sql . ' ORDER BY doc_type ASC', $args ) );
    foreach ( (array) $rows as $r ) { $r->validity = ridego_doc_validity( $r->expiry_date ); }
    return $rows;
}
