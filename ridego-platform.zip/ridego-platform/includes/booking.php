<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   BOOKING ENGINE
   ============================================================ */

function ridego_create_booking( $data ) {
    global $wpdb;

    $required = array('client_name','client_phone','trip_type','pickup_city','journey_date','journey_time','vehicle_type_id');
    foreach ( $required as $f ) {
        if ( empty($data[$f]) ) {
            return array('success'=>false,'message'=>'Missing required field: '.$f);
        }
    }
    if ( $data['trip_type'] !== 'local' && empty($data['drop_city']) ) {
        return array('success'=>false,'message'=>'Drop city is required.');
    }

    /* Passenger & Safety Information: server-side mirror of the booking
       flow's own validation (never trust the client alone). Any of the
       four counts is optional (a booking made before this feature, or
       via a caller that never sends them, still books fine — every field
       here is nullable), but once a total is provided the male+female+
       children breakdown must not exceed it. */
    if ( isset($data['passenger_total']) && $data['passenger_total'] !== '' && $data['passenger_total'] !== null ) {
        $p_total = intval($data['passenger_total']);
        if ( $p_total < 1 ) {
            return array('success'=>false,'message'=>'Total passengers must be at least 1.');
        }
        $p_male     = max(0, intval((isset($data['passenger_male']) ? $data['passenger_male'] : 0)));
        $p_female   = max(0, intval((isset($data['passenger_female']) ? $data['passenger_female'] : 0)));
        $p_children = max(0, intval((isset($data['passenger_children']) ? $data['passenger_children'] : 0)));
        if ( ($p_male + $p_female + $p_children) > $p_total ) {
            return array('success'=>false,'message'=>'Male, female and children counts cannot add up to more than the total passengers.');
        }
    }

    $phone = ridego_sanitize_phone($data['client_phone']);
    if ( strlen(preg_replace('/[^0-9]/','', $phone)) < 10 ) {
        return array('success'=>false,'message'=>'Invalid phone number. Must be at least 10 digits.');
    }

    $adv    = (int) ridego_get_setting('booking_advance_hours',2);
    $maxd   = (int) ridego_get_setting('booking_max_days',90);
    $jts    = strtotime($data['journey_date'].' '.$data['journey_time']);
    if ( $jts < strtotime("+{$adv} hours") ) {
        return array('success'=>false,'message'=>'Booking must be at least '.$adv.' hours in advance.');
    }
    if ( $jts > strtotime("+{$maxd} days") ) {
        return array('success'=>false,'message'=>'Cannot book more than '.$maxd.' days ahead.');
    }

    /* Back-office CRM link: the same person booking again (any channel) reuses one client profile, and a blocked client cannot book online. */
    $blocked = function_exists('ridego_client_find_matches') ? ridego_client_find_matches($phone, '') : array();
    if ( $blocked && $blocked[0]->status === 'blocked' ) {
        return array('success'=>false,'message'=>'We are unable to accept online bookings from this number right now. Please contact support.');
    }
    $vehicle = ridego_get_vehicle(intval($data['vehicle_type_id']));
    if ( !$vehicle || !$vehicle->is_active ) {
        return array('success'=>false,'message'=>'Invalid vehicle type.');
    }

    /* Double-submission guard: a slow network / double-click / retried
       AJAX call can fire ridego_create_booking() twice for the exact same
       trip within seconds of each other. Rather than blindly inserting a
       second row (and charging/confusing the customer with two
       bookings), treat an identical booking created in the last 2 minutes
       as the same request and hand back its existing confirmation. */
    $dedupe_pickup = sanitize_text_field($data['pickup_city']);
    $dedupe_drop   = sanitize_text_field((isset($data['drop_city']) ? $data['drop_city'] : ''));
    $existing = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ridego_bookings
         WHERE client_phone = %s AND journey_date = %s AND journey_time = %s
           AND pickup_city = %s AND drop_city = %s AND vehicle_type_id = %d
           AND status NOT IN ('cancelled','expired')
           AND created_at >= %s
         ORDER BY created_at DESC LIMIT 1",
        $phone, $data['journey_date'], $data['journey_time'],
        $dedupe_pickup, $dedupe_drop, intval($data['vehicle_type_id']),
        date('Y-m-d H:i:s', strtotime('-2 minutes'))
    ) );
    if ( $existing ) {
        return array(
            'success'        => true,
            'booking_id'     => (int) $existing->id,
            'booking_number' => $existing->booking_number,
            'status'         => $existing->status,
            'total_fare'     => (float) $existing->total_fare,
            'payment_method' => $existing->payment_method,
            'confirm_url'    => ridego_page_url('confirm_page_id').'?booking='.$existing->booking_number,
            'deduped'        => true,
        );
    }

    $fare_result = ridego_calculate_fare($data);
    if ( isset($fare_result['error']) ) {
        return array('success'=>false,'message'=>$fare_result['error']);
    }

    $discount   = 0;
    $promo_id   = 0;
    $promo_code = strtoupper(sanitize_text_field((isset($data['promo_code']) ? $data['promo_code'] : '')));
    if ( $promo_code ) {
        // NOTE: this is only a pre-check (was previously calling the undefined
        // ridego_validate_promo() — a bug that crashed every booking that used
        // a promo code; now correctly calls the canonical validator in
        // includes/promo.php). The actual atomic consumption of the promo
        // (used_count/budget increment + usage row) happens AFTER the booking
        // row exists, via ridego_record_promo_usage() — see below — because
        // that is what makes the redemption race-proof (Wave 2B Task 4). If
        // that atomic step loses the race (promo exhausted by a concurrent
        // booking between this check and the insert below), the booking is
        // corrected to drop the discount rather than silently keeping an
        // uncollected discount.
        $pr = ridego_validate_promo_code($promo_code, $fare_result['base_fare'], $data, is_user_logged_in() ? get_current_user_id() : 0);
        if ( ! empty($pr['valid']) ) {
            $discount = (float) $pr['discount_amount'];
            $promo_id = (int) $pr['promo_id'];
        }
    }

    /* Facilitator model: the client always pays the BOOKING AMOUNT to RideGo (UPI / bank transfer / gateway). "Cash to the driver" is not a way to skip it — the balance is
       what is paid to the vendor/driver. An unrecognised or legacy 'cash' method is therefore treated as UPI. If the booking amount works out to 0 (100% discount) the
       booking confirms immediately with nothing to pay online. */
    $payment_method  = sanitize_key((isset($data['payment_method']) ? $data['payment_method'] : 'upi'));
    if ( ! in_array( $payment_method, array( 'upi', 'bank_transfer', 'razorpay' ), true ) ) { $payment_method = 'upi'; }
    $discount_total  = max(0, $fare_result['total_fare'] - $discount);
    $token_amount    = ridego_booking_amount_for($discount_total);
    $needs_online    = $token_amount > 0;
    $status          = $needs_online ? 'pending_payment' : 'confirmed';
    $payment_status  = $needs_online ? 'pending' : 'cash_on_pickup';
    $dlh             = (int) ridego_get_setting('payment_deadline_hours',5);
    $pay_deadline    = $needs_online ? date('Y-m-d H:i:s',strtotime("+{$dlh} hours")) : null;
    $total_fare      = $discount_total;
    $booking_number  = ridego_generate_booking_number();
    $otp_pickup      = str_pad(random_int(0,999999),6,'0',STR_PAD_LEFT);
    $balance_due     = max(0, $total_fare - $token_amount);

    $row = array(
        'booking_number'       => $booking_number,
        'client_id'            => is_user_logged_in() ? get_current_user_id() : 0,
        'client_profile_id'    => function_exists('ridego_client_upsert_from_booking') ? ridego_client_upsert_from_booking( array_merge( $data, array( 'client_phone' => $phone ) ), 'online', 0 ) : 0,
        'booking_source'       => 'online',
        'client_name'          => sanitize_text_field($data['client_name']),
        'client_phone'         => $phone,
        'client_email'         => sanitize_email((isset($data['client_email']) ? $data['client_email'] : '')),
        'client_alt_phone'     => ridego_sanitize_phone((isset($data['client_alt_phone']) ? $data['client_alt_phone'] : '')),
        'trip_type'            => sanitize_key($data['trip_type']),
        'pickup_city'          => sanitize_text_field($data['pickup_city']),
        'pickup_address'       => sanitize_textarea_field((isset($data['pickup_address']) ? $data['pickup_address'] : '')),
        'pickup_lat'           => (float)((isset($data['pickup_lat']) ? $data['pickup_lat'] : 0)),
        'pickup_lng'           => (float)((isset($data['pickup_lng']) ? $data['pickup_lng'] : 0)),
        'drop_city'            => sanitize_text_field((isset($data['drop_city']) ? $data['drop_city'] : '')),
        'drop_address'         => sanitize_textarea_field((isset($data['drop_address']) ? $data['drop_address'] : '')),
        'drop_lat'             => (float)((isset($data['drop_lat']) ? $data['drop_lat'] : 0)),
        'drop_lng'             => (float)((isset($data['drop_lng']) ? $data['drop_lng'] : 0)),
        'via_cities'           => sanitize_text_field((isset($data['via_cities']) ? $data['via_cities'] : '')),
        'journey_date'         => sanitize_text_field($data['journey_date']),
        'journey_time'         => sanitize_text_field($data['journey_time']),
        'return_date'          => sanitize_text_field((isset($data['return_date']) ? $data['return_date'] : '')),
        'return_time'          => sanitize_text_field((isset($data['return_time']) ? $data['return_time'] : '')),
        'hours_required'       => intval((isset($data['hours_required']) ? $data['hours_required'] : 0)),
        'passengers'           => min(50,max(1,intval((isset($data['passengers']) ? $data['passengers'] : 1)))),
        'luggage_count'        => max(0,intval((isset($data['luggage_count']) ? $data['luggage_count'] : 0))),
        'vehicle_type_id'      => intval($data['vehicle_type_id']),
        'distance_km'          => $fare_result['distance_km'],
        'duration_minutes'     => $fare_result['duration_minutes'],
        'base_fare'            => $fare_result['base_fare'],
        'toll_charges'         => $fare_result['toll_charges'],
        'parking_charges'      => $fare_result['parking_charges'],
        'driver_allowance'     => $fare_result['driver_allowance'],
        'extra_km_charges'     => $fare_result['extra_km_charges'],
        'gst_amount'           => $fare_result['gst_amount'],
        'discount_amount'      => $discount,
        'promo_code'           => $promo_code,
        'total_fare'           => $total_fare,
        'token_amount'         => $token_amount,
        'platform_model'       => 1,
        'advance_paid'         => 0.00,
        'balance_due'          => $balance_due,
        'payment_method'       => $payment_method,
        'payment_status'       => $payment_status,
        'payment_deadline'     => $pay_deadline,
        'special_requests'     => sanitize_textarea_field((isset($data['special_requests']) ? $data['special_requests'] : '')),
        'flight_number'        => sanitize_text_field((isset($data['flight_number']) ? $data['flight_number'] : '')),
        'corporate_company'    => sanitize_text_field((isset($data['corporate_company']) ? $data['corporate_company'] : '')),
        'corporate_gst'        => sanitize_text_field((isset($data['corporate_gst']) ? $data['corporate_gst'] : '')),
        'corporate_emp_id'     => sanitize_text_field((isset($data['corporate_emp_id']) ? $data['corporate_emp_id'] : '')),
        'passenger_total'      => isset($data['passenger_total']) && $data['passenger_total'] !== '' && $data['passenger_total'] !== null ? max(0, intval($data['passenger_total'])) : null,
        'passenger_male'       => isset($data['passenger_male']) && $data['passenger_male'] !== '' && $data['passenger_male'] !== null ? max(0, intval($data['passenger_male'])) : null,
        'passenger_female'     => isset($data['passenger_female']) && $data['passenger_female'] !== '' && $data['passenger_female'] !== null ? max(0, intval($data['passenger_female'])) : null,
        'passenger_children'   => isset($data['passenger_children']) && $data['passenger_children'] !== '' && $data['passenger_children'] !== null ? max(0, intval($data['passenger_children'])) : null,
        'passenger_notes'      => sanitize_textarea_field((isset($data['passenger_notes']) ? $data['passenger_notes'] : '')),
        'status'               => $status,
        'otp_pickup'           => $otp_pickup,
        'ip_address'           => sanitize_text_field((isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '')),
        'utm_source'           => sanitize_text_field((isset($data['utm_source']) ? $data['utm_source'] : '')),
        'created_at'           => current_time('mysql'),
        'updated_at'           => current_time('mysql'),
    );

    /* Insert with a retry-on-duplicate-key backstop: the atomic counter
       above makes a collision on booking_number vanishingly unlikely, but
       this is defense-in-depth for edge cases (e.g. manually imported
       data, a counter row reset by a restore) — regenerate the number and
       retry a couple of times rather than surfacing a raw DB error to a
       customer who may already have paid. */
    $booking_id    = 0;
    $max_attempts  = 3;
    for ( $attempt = 1; $attempt <= $max_attempts; $attempt++ ) {
        $inserted = $wpdb->insert( $wpdb->prefix.'ridego_bookings', $row );
        if ( $inserted ) {
            $booking_id = $wpdb->insert_id;
            break;
        }
        $is_dupe_number = ( stripos( (string) $wpdb->last_error, 'Duplicate entry' ) !== false )
            && ( stripos( (string) $wpdb->last_error, 'booking_number' ) !== false );
        if ( $is_dupe_number && $attempt < $max_attempts ) {
            $booking_number   = ridego_generate_booking_number();
            $row['booking_number'] = $booking_number;
            continue;
        }
        return array('success'=>false,'message'=>'Database error. Please try again.');
    }
    if ( ! $booking_id ) {
        return array('success'=>false,'message'=>'Database error. Please try again.');
    }

    $promo_adjusted        = false;
    $promo_adjusted_reason = '';
    if ( $promo_code && $discount > 0 && $promo_id > 0 ) {
        $usage = ridego_record_promo_usage($booking_id, $promo_id, is_user_logged_in() ? get_current_user_id() : 0, $discount);
        if ( empty($usage['success']) ) {
            // Lost the race: promo got exhausted between the pre-check above
            // and this atomic redemption attempt. Correct the booking so the
            // client isn't given a discount that was never actually consumed
            // from the promo's budget/usage limit.
            $corrected_total = $total_fare + $discount;
            // Token amount itself doesn't change (it's a flat snapshot, not
            // a percentage of the fare) — only the balance owed does, since
            // the total the token is being netted against just went up.
            $corrected_token   = ridego_booking_amount_for($corrected_total);
            $corrected_balance = max(0, $corrected_total - $corrected_token);
            $wpdb->update( $wpdb->prefix.'ridego_bookings', array(
                'discount_amount' => 0,
                'promo_code'      => '',
                'total_fare'      => $corrected_total,
                'token_amount'    => $corrected_token,
                'balance_due'     => $corrected_balance,
                'updated_at'      => current_time('mysql'),
            ), array('id' => $booking_id) );
            ridego_audit_log('promo_redemption_failed_post_booking','booking',$booking_id,$promo_code,$usage['message'] ?? 'unknown', 'warning');
            $promo_adjusted        = true;
            $promo_adjusted_reason = 'Your promo code was no longer available at the moment of booking, so it could not be applied.';
            $total_fare            = $corrected_total;
            $token_amount          = $corrected_token;
            $balance_due           = $corrected_balance;
        }
    }

    do_action('ridego_booking_created', $booking_id, $status);
    if ( $status === 'confirmed' ) {
        do_action('ridego_booking_confirmed', $booking_id);
    }
    if ( $pay_deadline ) {
        wp_schedule_single_event(strtotime($pay_deadline), 'ridego_check_payment_deadline', array($booking_id));
    }

    return array(
        'success'              => true,
        'booking_id'           => $booking_id,
        'booking_number'       => $booking_number,
        'status'               => $status,
        'total_fare'           => $total_fare,
        'token_amount'         => $token_amount,
        'balance_due'          => $balance_due,
        'payment_method'       => $payment_method,
        'confirm_url'          => ridego_page_url('confirm_page_id').'?booking='.$booking_number,
        'promo_adjusted'       => $promo_adjusted,
        'promo_adjusted_reason'=> $promo_adjusted_reason,
    );
}

/*  Payment deadline cron  */
add_action('ridego_check_payment_deadline','ridego_handle_payment_deadline');
function ridego_handle_payment_deadline($bid){
    $b = ridego_get_booking($bid);
    if (!$b || $b->status !== 'pending_payment') return;
    ridego_update_booking_status($bid,'expired',array('payment_status'=>'expired'));
    do_action('ridego_booking_expired',$bid);
}

/*  Submit payment proof  */
function ridego_submit_payment_proof($booking_id, $file, $proof) {
    global $wpdb;
    $b = ridego_get_booking($booking_id);
    if (!$b) return array('success'=>false,'message'=>'Booking not found.');
    if (!in_array($b->status,array('pending_payment','payment_rejected'))) {
        return array('success'=>false,'message'=>'Cannot submit proof at this stage.');
    }
    if ($file['size'] > 2*1024*1024) return array('success'=>false,'message'=>'File must be under 2MB.');
    if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return array('success'=>false,'message'=>'File upload failed.');
    }

    /* Never trust $file['type'] — it is the Content-Type header the
       browser chose to send and is trivially spoofable. Detect the real
       MIME type from the file's own bytes instead. */
    $real_mime = false;
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $real_mime = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
        }
    }
    if (!$real_mime && function_exists('mime_content_type')) {
        $real_mime = mime_content_type($file['tmp_name']);
    }

    $is_image = in_array($real_mime, array('image/jpeg','image/png','image/webp'), true);
    $is_pdf   = ($real_mime === 'application/pdf');

    if ($is_image) {
        // getimagesize() actually decodes the image header — a renamed
        // .php or .html file with a spoofed Content-Type will fail this
        // even if finfo was fooled by a crafted magic byte prefix.
        $is_image = (bool) @getimagesize($file['tmp_name']);
    } elseif ($is_pdf) {
        $head = @file_get_contents($file['tmp_name'], false, null, 0, 5);
        $is_pdf = ($head !== false && strpos($head, '%PDF-') === 0);
    }

    if (!$is_image && !$is_pdf) {
        return array('success'=>false,'message'=>'Only genuine JPG, PNG, WEBP or PDF files are allowed.');
    }

    $ext_map = array('image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','application/pdf'=>'pdf');
    $ext     = isset($ext_map[$real_mime]) ? $ext_map[$real_mime] : 'bin';

    $dir = RIDEGO_SECURE_UPLOADS.'payment-proofs/'.$booking_id.'/';
    wp_mkdir_p($dir);
    $fname= 'proof_'.time().'.'.$ext;
    $dest = $dir.$fname;
    if (!move_uploaded_file($file['tmp_name'],$dest)) return array('success'=>false,'message'=>'File upload failed.');
    if ($is_image) {
        $comp = ridego_compress_image($dest,1200,80);
        $fname = basename($comp);
    }
    $utr = sanitize_text_field((isset($proof['utr']) ? $proof['utr'] : ''));
    if (strlen($utr) < 6) return array('success'=>false,'message'=>'Enter a valid UTR/Transaction ID (min 6 characters).');

    $wpdb->update($wpdb->prefix.'ridego_bookings',array(
        'status'                 => 'payment_proof_submitted',
        'payment_status'         => 'proof_submitted',
        'payment_proof_filename' => $fname,
        'payment_proof_url'      => 'payment-proofs/'.$booking_id.'/'.$fname,
        'payment_utr'            => $utr,
        'payment_app'            => sanitize_text_field((isset($proof['payment_app']) ? $proof['payment_app'] : '')),
        'payment_time_claimed'   => sanitize_text_field(isset($proof['payment_time']) ? $proof['payment_time'] : current_time('mysql')),
        // Default to the amount actually due right now — the token
        // amount when the token feature was on for this booking, else
        // the full total — not always total_fare, which would be wrong
        // whenever only a token/advance was ever asked for.
        'payment_amount_claimed' => (float)(isset($proof['amount']) ? $proof['amount'] : ( $b->token_amount > 0 ? $b->token_amount : $b->total_fare )),
        'updated_at'             => current_time('mysql'),
    ),array('id'=>$booking_id));

    do_action('ridego_payment_proof_submitted',$booking_id);
    return array('success'=>true,'message'=>'Proof submitted. We will verify within 30 minutes.');
}

/*  Admin verify payment  */
function ridego_verify_payment($booking_id,$admin_id){
    global $wpdb;
    $b = ridego_get_booking($booking_id);
    // What the client actually paid at booking time: the snapshot
    // token_amount when the token feature was on for this booking, or the
    // full total_fare when it was off — never a live re-read of the
    // token_payment_enabled setting, since that could have changed since
    // this particular booking was placed (see ridego_create_booking()).
    $paid_amount = $b ? ( $b->token_amount > 0 ? (float) $b->token_amount : (float) $b->total_fare ) : 0.00;
    $wpdb->update($wpdb->prefix.'ridego_bookings',array(
        'status'=>'confirmed','payment_status'=>'verified',
        'advance_paid'=>$paid_amount,
        'payment_verified_by'=>intval($admin_id),'payment_verified_at'=>current_time('mysql'),'updated_at'=>current_time('mysql'),
    ),array('id'=>$booking_id));
    ridego_audit_log('payment_verified','booking',$booking_id);
    if ( $paid_amount > 0 && function_exists('ridego_booking_payment_row') && $b ) { ridego_booking_payment_row($booking_id,'payment',$paid_amount,$b->payment_method ?: 'upi',$b->payment_utr,'Payment proof verified',intval($admin_id)); }
    // ROOT-CAUSE FIX: this manual-payment verification path — the one
    // actually used by the REST API, wp-admin, and bulk actions (see
    // includes/payment.php's ridego_process_razorpay_success() doc comment
    // for the equivalent Razorpay-side fix) — never logged a row to
    // ridego_transactions, so ridego_get_dashboard_stats()'s "Gross
    // Revenue" KPI (which sums type='booking_payment' transactions) was
    // silently always 0 for every manual/cash-verified booking. Logging
    // $paid_amount here (the token-aware amount actually collected, not
    // total_fare) both fixes that gap and keeps the token feature's
    // "balance goes to the driver/vendor, not RideGo" rule reflected in
    // revenue reporting.
    if ( function_exists('ridego_log_transaction') && $paid_amount > 0 ) {
        ridego_log_transaction(array(
            'type'       => 'booking_payment',
            'amount'     => $paid_amount,
            'booking_id' => $booking_id,
            'gateway'    => ( $b && $b->payment_method === 'razorpay' ) ? 'razorpay' : 'manual',
            'status'     => 'success',
            'notes'      => 'Manual payment verified by admin #' . intval($admin_id),
        ));
    }
    do_action('ridego_booking_confirmed',$booking_id);
    return true;
}

/*  Admin reject payment  */
function ridego_reject_payment($booking_id,$reason,$admin_id){
    global $wpdb;
    $wpdb->update($wpdb->prefix.'ridego_bookings',array(
        'status'=>'payment_rejected','payment_status'=>'rejected',
        'payment_rejection_reason'=>sanitize_textarea_field($reason),
        'payment_verified_by'=>intval($admin_id),'updated_at'=>current_time('mysql'),
    ),array('id'=>$booking_id));
    ridego_audit_log('payment_rejected','booking',$booking_id,'',$reason);
    do_action('ridego_payment_rejected',$booking_id,$reason);
    return true;
}

/*  Cancel booking
    $verified_client_id: REQUIRED whenever $cancelled_by === 'client' — the
    client_id the caller has already established, by some trustworthy
    means, actually owns this booking (a logged-in user's own ID, or the
    booking's own client_id after an OTP-verified guest cancellation).
    Passing null here for a client-initiated cancel is refused outright —
    this is the root-cause fix for an IDOR where the [ridego_my_trips]
    shortcode called this function directly with a bare, un-verified
    booking_id from POST, letting any logged-in user cancel ANY other
    user's booking. Admin cancellations ($cancelled_by='admin') are
    unaffected — no client ownership applies to those. */
function ridego_cancel_booking($booking_id,$reason,$cancelled_by='client',$verified_client_id=null){
    global $wpdb;
    $b = ridego_get_booking($booking_id);
    if (!$b) return array('success'=>false,'message'=>'Booking not found.');
    if ($cancelled_by === 'client') {
        if ($verified_client_id === null || (int)$verified_client_id !== (int)$b->client_id) {
            return array('success'=>false,'message'=>'You are not authorized to cancel this booking.');
        }
    }
    // 'token_refund_due' is excluded too: that status means the client's
    // token has already been refunded via the "mark not arranged" action
    // (includes/app-admin-bookings-api.php) — cancelling from there would
    // recompute and re-execute a second refund of the same money (the
    // advance_paid column is never zeroed after a refund is recorded, so
    // ridego_calc_cancel_penalty()/ridego_process_refund() would otherwise
    // fire again for the full amount).
    if (in_array($b->status,array('completed','cancelled','trip_started','token_refund_due'))) {
        return array('success'=>false,'message'=>'Cannot cancel this booking.');
    }
    // Second, independent guard: even if a future status value slips past
    // the list above, never compute/execute a refund on a booking whose
    // payment has already been refunded or has a refund in flight.
    if (in_array($b->payment_status,array('refund_pending','refunded'),true)) {
        return array('success'=>false,'message'=>'A refund has already been initiated for this booking.');
    }
    $penalty = ridego_calc_cancel_penalty($b);
    $refund  = max(0,$b->advance_paid - $penalty);
    $wpdb->update($wpdb->prefix.'ridego_bookings',array(
        'status'=>'cancelled','cancellation_reason'=>sanitize_textarea_field($reason),
        'cancelled_by'=>sanitize_key($cancelled_by),'cancellation_time'=>current_time('mysql'),'updated_at'=>current_time('mysql'),
    ),array('id'=>$booking_id));
    /* Unified cancellation cutoff (per business decision): "has a vendor
       been assigned" — not hours-until-journey — is now the single line
       that governs BOTH the vendor's lead-fee refund below AND the
       client's token refund above (via ridego_calc_cancel_penalty()).
       This replaces the old cancellation_free_hours-based policy
       entirely; that setting is no longer read here. */
    $vendor_arranged = ! empty($b->vendor_id);
    // ROOT-CAUSE FIX: both calls below used to fire ridego_vendor_credit_wallet() and completely ignore
    // its return value. That function IS transactional and safe (row-locked, checked internally) — the
    // bug was here, at the call site: if it failed for any reason (vendor row missing, a DB deadlock, a
    // transient error), ridego_cancel_booking() still reported the cancellation as a full success while
    // the vendor's lead-fee refund silently vanished, with no retry and nothing surfacing the failure
    // anywhere an admin would ever see it — a real "ghost success" on a money-movement path. Fixed by
    // checking the result and, on failure, both audit-logging it immediately (visible in the admin audit
    // log right away) and enqueuing a durable, auto-retried job (includes/jobs.php) so a transient failure
    // recovers on its own instead of requiring someone to notice and fix it by hand.
    if ($b->vendor_id && $b->lead_fee_charged > 0) {
        if ($cancelled_by === 'client') {
            if ( ! $vendor_arranged ) {
                $reason = 'Lead fee refund - client cancelled before a vendor was arranged';
                $credit = ridego_vendor_credit_wallet($b->vendor_id,$b->lead_fee_charged,$booking_id,$reason);
                ridego_ensure_wallet_credit($credit, $b->vendor_id, $b->lead_fee_charged, $booking_id, $reason);
            }
            // Once a vendor has been arranged, the lead fee stands — the
            // vendor had already committed to and prepared for the trip,
            // regardless of how much notice the client gave.
        } else {
            // Admin/system-initiated cancellation (duplicate booking,
            // fraud, data-entry error, etc.) is never the vendor's fault —
            // they did nothing wrong and should never be left out of
            // pocket for a trip that was never going to run regardless of
            // vendor-assignment status.
            $reason = 'Lead fee refund - booking cancelled by '.$cancelled_by.', not vendor fault';
            $credit = ridego_vendor_credit_wallet($b->vendor_id,$b->lead_fee_charged,$booking_id,$reason);
            ridego_ensure_wallet_credit($credit, $b->vendor_id, $b->lead_fee_charged, $booking_id, $reason);
        }
    }
    // Facilitator model: an advance forfeited because the client cancelled after a vendor was arranged is recorded once (kept by the platform or paid to the vendor);
    // and move the vendor lead fee status to 'cancelled' (no trip, so no lead fee is billed to the vendor).
    if ( ! empty( $b->platform_model ) ) {
        if ( $vendor_arranged && $penalty > 0 ) {
            // The forfeited advance is either kept by the platform as the lead fee or paid to the vendor as compensation; the default comes from Settings and an admin can change it per booking afterwards.
            $default_to = ridego_lead_fee_forfeit_default();
            if ( $default_to !== 'admin' ) { ridego_lead_fee_forfeit_apply( (int) $booking_id, $default_to, '', 0, true ); } // 'admin' = left for an admin to decide on the booking
        }
        ridego_lead_fee_sync_status( (int) $booking_id );
    }
    // Execute the client's token refund for real (Razorpay refund API call
    // for gateway payments, or a tracked manual-refund entry + notification
    // for cash/manual bookings) rather than only calculating and returning
    // it — see ridego_process_refund() in includes/payment.php, which this
    // was the last missing wiring for (that function already existed but
    // was never called from anywhere in the codebase).
    if ( $refund > 0 && function_exists('ridego_process_refund') ) {
        $refund_reason = ( ! $vendor_arranged )
            ? 'Booking cancelled before a vendor was arranged'
            : 'Booking cancellation refund';
        ridego_process_refund($booking_id, $refund, $refund_reason);
    }
    ridego_audit_log('booking_cancelled','booking',$booking_id,$b->status,'cancelled');
    do_action('ridego_booking_cancelled',$booking_id,$cancelled_by,$refund);
    return array('success'=>true,'refund_amount'=>$refund,'penalty'=>$penalty);
}

/* Token Amount / Advance Payment — unified cancellation-penalty rule
   (per business decision: "unify on vendor-assignment"). Whether a
   vendor/driver has actually been arranged for this booking is now the
   single cutoff for whether the client's token is refundable, replacing
   the previous hours-until-journey schedule entirely:
     - No vendor arranged yet ("Booking Not Arranged"): full refund —
       penalty is 0, the whole advance_paid amount comes back.
     - Vendor already arranged: RideGo successfully did its job: the
       token is forfeited (penalty = the full advance_paid) if the client
       then cancels/refuses, per spec item 4 — "subject to cancellation
       terms," stated to the client before payment (see the token_label /
       token_instructions settings surfaced on the booking/payment
       screens). */
function ridego_calc_cancel_penalty($booking){
    $vendor_arranged = ! empty($booking->vendor_id);
    if ( ! $vendor_arranged ) {
        return 0;
    }
    return (float) $booking->advance_paid;
}

/*  Reporting KPI summary for a date range (created_at BETWEEN from/to).
    Single source of truth for the admin Reports dashboard's top KPI row
    (admin/pages/reports.php) and the REST API's GET /ridego/v1/reports/
    summary (includes/rest-api.php), so both read the exact same figures.
    Args: $from, $to (Y-m-d date strings, inclusive).
    Returns array(total, completed, cancelled, revenue, avg_booking,
    completion_rate_pct). */
function ridego_get_booking_report_summary( $from, $to ) {
    global $wpdb;
    $btbl = $wpdb->prefix.'ridego_bookings';
    $wd   = $wpdb->prepare( 'WHERE DATE(created_at) BETWEEN %s AND %s', $from, $to );

    $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $btbl $wd" );
    $comp  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $btbl $wd AND status='completed'" );
    $canc  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $btbl $wd AND status='cancelled'" );
    // Root-cause fix: this must be what RideGo actually collected
    // (advance_paid — the token amount when the token feature was on for
    // a given booking, else the full total_fare), not total_fare, which
    // would overstate collected revenue by the driver/vendor's balance
    // whenever the token feature is on (that balance is paid directly to
    // the driver/vendor, never collected by RideGo — spec item 5).
    $rev   = (float) $wpdb->get_var( "SELECT COALESCE(SUM(advance_paid),0) FROM $btbl $wd AND payment_status IN ('verified','partial')" );
    $ride_value = (float) $wpdb->get_var( "SELECT COALESCE(SUM(total_fare),0) FROM $btbl $wd AND status NOT IN ('cancelled','expired','token_refund_due')" );
    $avg   = $total > 0 ? $rev / $total : 0;
    $conv  = $total > 0 ? round( $comp / $total * 100 ) : 0;

    return array(
        'from'                => $from,
        'to'                  => $to,
        'total_bookings'      => $total,
        'completed'           => $comp,
        'cancelled'           => $canc,
        'revenue'             => round( $rev, 2 ),
        'ride_value'          => round( $ride_value, 2 ),
        'avg_booking'         => round( $avg, 2 ),
        'completion_rate_pct' => $conv,
    );
}

/*  Shared booking query builder (admin list + any other consumer)
    Single source of truth for booking filter/search SQL - replaces the
    old ridego_get_all_bookings()/ridego_count_bookings() pair (different
    filter semantics, never actually used) and admin/pages/bookings.php's
    inline duplicate query.
    Args: status (string, or '|'-joined list of statuses), trip_type,
          date_from, date_to (journey_date range), city, vendor_id,
          search, limit, offset, orderby, order.
    Returns array('rows'=>[...], 'total'=>int).  */
function ridego_query_bookings( $args = array() ) {
    global $wpdb;
    $btbl = $wpdb->prefix.'ridego_bookings';
    $d = array(
        'status'=>'', 'trip_type'=>'', 'date_from'=>'', 'date_to'=>'',
        'city'=>'', 'vendor_id'=>0, 'search'=>'', 'source'=>'', 'client_profile_id'=>0, 'payment_status'=>'',
        'limit'=>25, 'offset'=>0, 'orderby'=>'created_at', 'order'=>'DESC',
    );
    $a = array_merge($d,$args);
    $w = array('1=1'); $v = array();

    if ($a['status']) {
        $ss = explode('|',$a['status']);
        $ph = implode(',',array_fill(0,count($ss),'%s'));
        $w[] = "b.status IN ({$ph})";
        $v   = array_merge($v,$ss);
    }
    if ($a['trip_type']) { $w[]='b.trip_type=%s'; $v[]=$a['trip_type']; }
    if ($a['date_from']) { $w[]='b.journey_date>=%s'; $v[]=$a['date_from']; }
    if ($a['date_to'])   { $w[]='b.journey_date<=%s'; $v[]=$a['date_to']; }
    if ($a['city'])      { $w[]='(b.pickup_city=%s OR b.drop_city=%s)'; $v[]=$a['city']; $v[]=$a['city']; }
    if ($a['vendor_id']) { $w[]='b.vendor_id=%d'; $v[]=intval($a['vendor_id']); }
    if ($a['source'])    { $w[]='b.booking_source=%s'; $v[]=sanitize_key($a['source']); }
    if ($a['client_profile_id']) { $w[]='b.client_profile_id=%d'; $v[]=intval($a['client_profile_id']); }
    if ($a['payment_status']) { $w[]='b.payment_status=%s'; $v[]=sanitize_key($a['payment_status']); }

    if ($a['search']) {
        $search = trim($a['search']);
        if ( preg_match('/^RG-\d{4}-\d+$/i', $search) ) {
            /* Exact/prefix match on the unique booking_number index -
               far cheaper than a leading-wildcard LIKE scan. */
            $w[]='b.booking_number=%s';
            $v[]=strtoupper($search);
        } else {
            $lk='%'.$wpdb->esc_like($search).'%';
            $w[]='(b.booking_number LIKE %s OR b.client_name LIKE %s OR b.client_phone LIKE %s OR b.pickup_city LIKE %s OR b.drop_city LIKE %s OR b.client_email LIKE %s)';
            $v[]=$lk;$v[]=$lk;$v[]=$lk;$v[]=$lk;$v[]=$lk;$v[]=$lk;
        }
    }

    /* Regional Manager: a region-limited user only ever sees bookings picked up inside the region. */
    if ( function_exists( 'ridego_region_scope_cities' ) ) {
        $rsc = ridego_region_scope_cities();
        if ( $rsc !== null ) {
            if ( ! $rsc ) { $w[] = '1=0'; }
            else { $w[] = 'b.pickup_city IN (' . implode( ',', array_fill( 0, count( $rsc ), '%s' ) ) . ')'; $v = array_merge( $v, $rsc ); }
        }
    }

    $where_sql = implode(' AND ',$w);

    /* Total count */
    $count_sql = "SELECT COUNT(*) FROM {$btbl} b WHERE {$where_sql}";
    $total = (int) ( $v ? $wpdb->get_var($wpdb->prepare($count_sql,$v)) : $wpdb->get_var($count_sql) );

    /* Rows */
    $ord = in_array(strtoupper($a['order']),array('ASC','DESC'))?strtoupper($a['order']):'DESC';
    $obm = array('created_at'=>'b.created_at','journey_date'=>'b.journey_date','total_fare'=>'b.total_fare','status'=>'b.status');
    $ob  = isset($obm[$a['orderby']])?$obm[$a['orderby']]:'b.created_at';
    $rv  = $v; $rv[] = max(1,intval($a['limit'])); $rv[] = max(0,intval($a['offset']));
    $sql = "SELECT b.*, veh.name AS vname, veh.name AS vehicle_name, vd.business_name AS vendor_name
            FROM {$btbl} b
            LEFT JOIN {$wpdb->prefix}ridego_vehicles veh ON veh.id=b.vehicle_type_id
            LEFT JOIN {$wpdb->prefix}ridego_vendors vd ON vd.id=b.vendor_id
            WHERE {$where_sql} ORDER BY {$ob} {$ord} LIMIT %d OFFSET %d";
    $rows = $wpdb->get_results($wpdb->prepare($sql,$rv));

    return array('rows'=>$rows,'total'=>$total);
}

/*  Rate a trip  */
function ridego_rate_booking($booking_id,$score,$review,$rater_id){
    global $wpdb;
    $b = ridego_get_booking($booking_id);
    if (!$b||$b->status!=='completed') return array('success'=>false,'message'=>'Can only rate completed trips.');
    // Ownership check: only the booking's own client (or an admin) may rate
    // it. Without this, any logged-in user could pass an arbitrary
    // booking_id and leave a rating/review on a stranger's trip, corrupting
    // the vendor's aggregate rating computed just below.
    if ( ! current_user_can('manage_options') && ( (int) $b->client_id <= 0 || (int) $b->client_id !== (int) $rater_id ) ) {
        return array('success'=>false,'message'=>'You can only rate your own bookings.');
    }
    if ( (int) $b->rating_by_client > 0 ) {
        return array('success'=>false,'message'=>'This trip has already been rated.');
    }
    $score = max(1,min(5,intval($score)));
    $wpdb->update($wpdb->prefix.'ridego_bookings',array('rating_by_client'=>$score,'review_by_client'=>sanitize_textarea_field($review)),array('id'=>$booking_id));
    if ($b->vendor_id) {
        $avg=$wpdb->get_var($wpdb->prepare("SELECT AVG(rating_by_client) FROM {$wpdb->prefix}ridego_bookings WHERE vendor_id=%d AND rating_by_client IS NOT NULL",$b->vendor_id));
        $cnt=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}ridego_bookings WHERE vendor_id=%d AND rating_by_client IS NOT NULL",$b->vendor_id));
        $wpdb->update($wpdb->prefix.'ridego_vendors',array('rating'=>round((float)$avg,2),'total_ratings'=>(int)$cnt),array('id'=>$b->vendor_id));
    }
    do_action('ridego_booking_rated',$booking_id,$score,$b->vendor_id);
    return array('success'=>true,'message'=>'Thank you for your feedback!');
}

/*  Archive old bookings (cron)  */
function ridego_archive_old_bookings(){
    global $wpdb;
    $cutoff = date('Y-m-d',strtotime('-180 days'));
    $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ridego_bookings WHERE journey_date<%s AND status IN ('completed','cancelled','expired') LIMIT 100",$cutoff));
    foreach ($rows as $r) {
        $wpdb->insert($wpdb->prefix.'ridego_bookings_archive',(array)$r);
        $wpdb->delete($wpdb->prefix.'ridego_bookings',array('id'=>$r->id));
    }
    return count($rows);
}
