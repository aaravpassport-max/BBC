<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ================================================================
   RideGo App Admin API — Phase B, wave 2: booking management
   ------------------------------------------------------------
   Same discipline as includes/app-admin-api.php (vendor management):
   every write action here is a thin wrapper around the SAME
   canonical business-logic functions admin/pages/bookings.php
   already calls (ridego_verify_payment(), ridego_reject_payment(),
   ridego_cancel_booking(), ridego_update_booking_status()) — never
   a new, divergent implementation of booking rules. wp-admin's
   bookings page is left fully intact; this is an additive React
   equivalent under /app/admin/bookings, not a replacement yet.

   UPDATE: "assign vendor" previously had no canonical function —
   both this file and admin/pages/bookings.php's 'assign_vendor'
   action did their own raw $wpdb->update(). This has since been
   consolidated into ridego_assign_vendor_to_booking()
   (includes/helpers.php); both callers now delegate to it, so they
   can never drift apart. See that function's doc comment.

   Every route requires is_user_logged_in() AND
   ridego_can('ridego_manage_bookings') — the exact same capability
   admin/pages/bookings.php itself gates on.
   ================================================================ */

add_action( 'rest_api_init', 'ridego_register_app_admin_bookings_api_routes' );
function ridego_register_app_admin_bookings_api_routes() {

    register_rest_route( 'ridego/v1', '/app/admin/bookings', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_bookings_list',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/bookings/(?P<id>\d+)', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_booking_detail',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/bookings/(?P<id>\d+)/verify-payment', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_booking_verify_payment',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/bookings/(?P<id>\d+)/reject-payment', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_booking_reject_payment',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/bookings/(?P<id>\d+)/cancel', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_booking_cancel',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    /* Token Amount / Advance Payment, spec item 3: "Booking Not Arranged
       -> Token Refund Due". Manual admin action only, per business
       decision — never automatic/timeout-based. Marks the booking with a
       new 'token_refund_due' status and, distinct from
       ridego_cancel_booking(), refunds the client's token specifically
       because RideGo itself could not arrange the vehicle — not because
       the client cancelled — so it is intentionally its own endpoint
       rather than a variant cancellation reason. */
    register_rest_route( 'ridego/v1', '/app/admin/bookings/(?P<id>\d+)/mark-not-arranged', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_booking_mark_not_arranged',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/bookings/(?P<id>\d+)/complete', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_booking_complete',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/bookings/(?P<id>\d+)/assign-vendor', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_booking_assign_vendor',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/bookings/(?P<id>\d+)/status', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_booking_status',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    register_rest_route( 'ridego/v1', '/app/admin/bookings/(?P<id>\d+)/note', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_booking_note',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    /* RG-003 (Master Issue Register, P0): a single unified timeline for a booking.
       Before this, an admin reconstructing "what happened to this booking" had to
       open three separate tabs (notes, payments, and the global /audit-log page
       filtered by hand to entity=booking) with no combined chronological view.
       This merges all three plus the client-facing status steps into one ordered
       feed, read-only, sourced entirely from existing tables/getters. */
    register_rest_route( 'ridego/v1', '/app/admin/bookings/(?P<id>\d+)/timeline', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_booking_timeline',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    /* "Resend confirmation" — mirrors admin/pages/bookings.php's
       'send_confirmation' action exactly: re-fires the same
       ridego_booking_confirmed hook the original confirmation email/SMS
       is sent from, so this triggers the same downstream notifications,
       not a second parallel implementation of them. Had no React
       equivalent before this pass. */
    register_rest_route( 'ridego/v1', '/app/admin/bookings/(?P<id>\d+)/resend-confirmation', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_booking_resend_confirmation',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    /* Cross-reason "needs attention" list (RG next-target from 17.29/17.31/17.32) —
       deliberately registered under /app/admin/bookings/ so it passes through
       ridego_region_rest_guard() unchanged: a region-limited Regional Manager
       gets the SAME endpoint, automatically scoped to their own cities, with
       no separate region-aware branch to keep in sync. */
    register_rest_route( 'ridego/v1', '/app/admin/bookings/needs-attention', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_bookings_needs_attention',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    /* Picker list for the "Assign vendor" control — same
       active + KYC-verified filter admin/pages/bookings.php uses for
       its <select>, so the new admin's picker shows the same choices. */
    register_rest_route( 'ridego/v1', '/app/admin/bookings/vendor-picker', array(
        'methods'             => 'GET',
        'callback'            => 'ridego_app_admin_api_booking_vendor_picker',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );

    /* Bulk verify/cancel — mirrors admin/pages/bookings.php's
       "rga_bulk_act" handler exactly (same per-row eligibility checks,
       same skip messages, same ridego_verify_payment()/ridego_cancel_booking()
       calls), so bulk actions behave identically in both admins. Did not
       exist before this pass — wp-admin's bulk bar had no React
       equivalent at all. */
    register_rest_route( 'ridego/v1', '/app/admin/bookings/bulk', array(
        'methods'             => 'POST',
        'callback'            => 'ridego_app_admin_api_bookings_bulk',
        'permission_callback' => 'ridego_app_admin_api_bookings_permission',
    ) );
}

function ridego_app_admin_api_bookings_permission() {
    if ( ! is_user_logged_in() ) {
        return new WP_Error( 'not_logged_in', 'You must be logged in.', array( 'status' => 401 ) );
    }
    if ( ! ridego_can( 'ridego_manage_bookings' ) ) {
        return new WP_Error( 'forbidden', 'You do not have permission to manage bookings.', array( 'status' => 403 ) );
    }
    return true;
}

// TRACE: reason code + booking row → the small display shape a needs-attention list item shares across
//        every reason → array. Pure. Never includes payment/fare figures — the list is a triage queue,
//        not a financial report; opening the booking (booking_number links to the existing detail page)
//        shows the full picture.
function ridego_needs_attention_row( $reason_code, $reason_label, $urgency, $b ) {
    return array(
        'id' => (int) $b->id,
        'booking_number' => $b->booking_number,
        'client_name' => $b->client_name,
        'pickup_city' => $b->pickup_city,
        'drop_city' => $b->drop_city,
        'journey_date' => $b->journey_date,
        'status' => $b->status,
        'reason_code' => $reason_code,
        'reason_label' => $reason_label,
        'urgency' => $urgency,
    );
}

// TRACE: GET admin/bookings/needs-attention (?limit=25 per reason) → every booking currently requiring
//        human action, grouped by reason, region-scoped automatically because it is registered under
//        /app/admin/bookings/ (ridego_region_rest_guard() lets that family through, and each reason's
//        query applies ridego_region_sql() itself — same double-scoping pattern the KPI tiles in
//        ridego_app_admin_api_bookings_list() already use) → { groups:[{code,label,urgency,rows:[...]}],
//        total }. Preconditions: caller holds ridego_manage_bookings (same cap the whole /bookings
//        family already requires — the Regional Manager "bookings" module grants exactly this).
//        Postconditions: read-only, no writes; a Regional Manager with no region assigned yet sees every
//        group empty (ridego_region_sql() returns "AND 1=0"), never another region's bookings. Edge
//        cases: five independent reasons, each capped at ?limit (default 25, max 100) rows, ordered
//        most-urgent-first within its own reason (soonest journey_date / oldest created_at) —
//        'payment_proof_submitted' and 'token_refund_due' are money-blocking so rank 'high'; a stale
//        pending-payment booking (created over 4 hours ago, still unpaid) and an unassigned booking
//        whose journey is within 24 hours both rank 'urgent'; an unresolved no_show from the last 14
//        days ranks 'medium'. A booking that matches more than one reason (rare — e.g. unassigned AND
//        somehow also token_refund_due) appears once per matching reason, since each is queried
//        independently and a different admin action resolves each one.
function ridego_app_admin_api_bookings_needs_attention( WP_REST_Request $req ) {
    global $wpdb;
    $btbl = $wpdb->prefix . 'ridego_bookings';
    $limit = (int) $req->get_param( 'limit' );
    if ( $limit <= 0 ) { $limit = 25; }
    $limit = min( $limit, 100 );
    $rs = function_exists( 'ridego_region_sql' ) ? ridego_region_sql( 'pickup_city' ) : '';
    $now = current_time( 'mysql' );
    $today = current_time( 'Y-m-d' );
    $tomorrow_plus1 = date( 'Y-m-d', strtotime( $today . ' +1 day' ) );
    $stale_cutoff = date( 'Y-m-d H:i:s', strtotime( $now . ' -4 hours' ) );
    $no_show_cutoff = date( 'Y-m-d H:i:s', strtotime( $now . ' -14 days' ) );

    $defs = array(
        array(
            'code' => 'payment_proof_pending', 'label' => 'Payment proof awaiting verification', 'urgency' => 'high',
            'sql' => "SELECT * FROM {$btbl} WHERE status='payment_proof_submitted'{$rs} ORDER BY created_at ASC LIMIT %d",
            'args' => array( $limit ),
        ),
        array(
            'code' => 'refund_due', 'label' => 'Refund owed to client', 'urgency' => 'high',
            'sql' => "SELECT * FROM {$btbl} WHERE status='token_refund_due'{$rs} ORDER BY created_at ASC LIMIT %d",
            'args' => array( $limit ),
        ),
        array(
            'code' => 'unassigned_urgent', 'label' => 'Confirmed but no vendor, journey within 24 hours', 'urgency' => 'urgent',
            'sql' => "SELECT * FROM {$btbl} WHERE status='confirmed' AND vendor_id IS NULL AND journey_date<=%s{$rs} ORDER BY journey_date ASC LIMIT %d",
            'args' => array( $tomorrow_plus1, $limit ),
        ),
        array(
            'code' => 'payment_stale', 'label' => 'Booking amount pending for over 4 hours', 'urgency' => 'urgent',
            'sql' => "SELECT * FROM {$btbl} WHERE status IN ('pending_payment','payment_pending') AND created_at<=%s{$rs} ORDER BY created_at ASC LIMIT %d",
            'args' => array( $stale_cutoff, $limit ),
        ),
        array(
            'code' => 'no_show_unresolved', 'label' => 'No-show in the last 14 days', 'urgency' => 'medium',
            'sql' => "SELECT * FROM {$btbl} WHERE status='no_show' AND created_at>=%s{$rs} ORDER BY created_at DESC LIMIT %d",
            'args' => array( $no_show_cutoff, $limit ),
        ),
    );

    $groups = array(); $total = 0;
    foreach ( $defs as $d ) {
        $rows = $wpdb->get_results( $wpdb->prepare( $d['sql'], $d['args'] ) );
        $view = array_map( function ( $b ) use ( $d ) { return ridego_needs_attention_row( $d['code'], $d['label'], $d['urgency'], $b ); }, (array) $rows );
        $groups[] = array( 'code' => $d['code'], 'label' => $d['label'], 'urgency' => $d['urgency'], 'rows' => $view, 'count' => count( $view ) );
        $total += count( $view );
    }
    return rest_ensure_response( array( 'groups' => $groups, 'total' => $total ) );
}

/**
 * Paginated/filterable booking list, thin wrapper over
 * ridego_query_bookings() — the same function admin/pages/bookings.php
 * itself uses for its list view — plus the same status/KPI tiles.
 */
function ridego_app_admin_api_bookings_list( WP_REST_Request $req ) {
    global $wpdb;
    $btbl = $wpdb->prefix . 'ridego_bookings';

    $status    = sanitize_text_field( (string) $req->get_param( 'status' ) );
    $trip_type = sanitize_key( (string) $req->get_param( 'trip_type' ) );
    $vendor_id = (int) $req->get_param( 'vendor_id' );
    $date_from = sanitize_text_field( (string) $req->get_param( 'date_from' ) );
    $date_to   = sanitize_text_field( (string) $req->get_param( 'date_to' ) );
    $search    = sanitize_text_field( (string) $req->get_param( 'search' ) );
    $source    = sanitize_key( (string) $req->get_param( 'source' ) );
    $pay_status = sanitize_key( (string) $req->get_param( 'payment_status' ) );
    $client_pid = (int) $req->get_param( 'client_id' );
    $page      = max( 1, (int) $req->get_param( 'page' ) );
    $limit     = 25;

    $args = array(
        'limit'   => $limit,
        'offset'  => ( $page - 1 ) * $limit,
        'orderby' => 'created_at',
        'order'   => 'DESC',
    );
    if ( $status )    { $args['status'] = $status; }
    if ( $trip_type ) { $args['trip_type'] = $trip_type; }
    if ( $vendor_id ) { $args['vendor_id'] = $vendor_id; }
    if ( $date_from ) { $args['date_from'] = $date_from; }
    if ( $date_to )   { $args['date_to'] = $date_to; }
    if ( $search )    { $args['search'] = $search; }
    if ( $source )    { $args['source'] = $source; }
    if ( $pay_status ) { $args['payment_status'] = $pay_status; }
    if ( $client_pid ) { $args['client_profile_id'] = $client_pid; }

    $result = ridego_query_bookings( $args );
    $rows   = isset( $result['rows'] ) ? $result['rows'] : array();
    $total  = isset( $result['total'] ) ? (int) $result['total'] : 0;

    $out = array_map( function ( $b ) {
        return array(
            'id'              => (int) $b->id,
            'booking_number'  => $b->booking_number,
            'client_name'     => $b->client_name,
            'client_phone'    => $b->client_phone,
            'trip_type'       => $b->trip_type,
            'pickup_city'     => $b->pickup_city,
            'drop_city'       => $b->drop_city,
            'journey_date'    => $b->journey_date,
            'vendor_id'       => isset( $b->vendor_id ) ? (int) $b->vendor_id : 0,
            'vendor_name'     => isset( $b->vendor_name ) ? $b->vendor_name : '',
            'total_fare'      => (float) $b->total_fare,
            'token_amount'    => isset( $b->token_amount ) ? (float) $b->token_amount : 0.00,
            'payment_status'  => $b->payment_status,
            'balance_due'     => (float) $b->balance_due,
            'booking_source'  => isset( $b->booking_source ) ? $b->booking_source : 'online',
            'client_profile_id' => isset( $b->client_profile_id ) ? (int) $b->client_profile_id : 0,
            'status'          => $b->status,
            'created_at'      => $b->created_at,
        ) + ridego_booking_money_fields( $b ) + array( 'lead_fee' => ridego_lead_fee_view( $b ) );
    }, $rows );

    $rs = function_exists( 'ridego_region_sql' ) ? ridego_region_sql( 'pickup_city' ) : '';
    $kpis = array(
        'total'           => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE 1=1{$rs}" ),
        'pending_payment' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE 1=1{$rs} AND status='pending_payment'" ),
        'proof_submitted' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE 1=1{$rs} AND status='payment_proof_submitted'" ),
        'token_refund_due'=> (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE 1=1{$rs} AND status='token_refund_due'" ),
        'confirmed_today' => (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$btbl} WHERE 1=1{$rs} AND status='confirmed' AND DATE(created_at)=%s",
            current_time( 'Y-m-d' )
        ) ),
        'completed'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE 1=1{$rs} AND status='completed'" ),
        'cancelled'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE 1=1{$rs} AND status='cancelled'" ),
        /* Mirrors the 5 KPI tiles at the top of admin/pages/bookings.php's
           ridego_render_bookings() (today's bookings / proof pending /
           active trips / no vendor / month revenue) so the new admin
           doesn't drop any of them. */
        'today_bookings'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE 1=1{$rs} AND DATE(created_at)=CURDATE()" ),
        'active_trips'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE 1=1{$rs} AND status IN ('vendor_assigned','driver_en_route','trip_started')" ),
        'no_vendor'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$btbl} WHERE 1=1{$rs} AND vendor_id IS NULL AND status='confirmed'" ),
        // advance_paid, not total_fare: what RideGo actually collected —
        // see the identical fix in ridego_get_booking_report_summary()
        // (includes/booking.php).
        'month_revenue'   => (float) $wpdb->get_var( "SELECT COALESCE(SUM(advance_paid),0) FROM {$btbl} WHERE 1=1{$rs} AND MONTH(created_at)=MONTH(NOW()) AND payment_status IN ('verified','partial')" ),
    );

    return rest_ensure_response( array(
        'rows'     => $out,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $limit,
        'kpis'     => $kpis,
    ) );
}

/**
 * Full booking detail — thin wrapper over ridego_get_booking(), the
 * same helper the admin detail view, the customer's My Trips page,
 * and the vendor dashboard all already use.
 */
function ridego_app_admin_api_booking_detail( WP_REST_Request $req ) {
    global $wpdb;
    $id = (int) $req->get_param( 'id' );
    $b  = ridego_get_booking( $id );
    if ( ! $b ) {
        return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
    }

    /* Extended vendor profile, mirroring the "Driver/Vendor" tab in
       admin/pages/bookings.php's ridego_render_booking_detail_v5(). */
    $vendor = null;
    if ( ! empty( $b->vendor_id ) ) {
        $v = ridego_get_vendor( (int) $b->vendor_id );
        if ( $v ) {
            $vendor = array(
                'id'                     => (int) $v->id,
                'business_name'          => $v->business_name,
                'owner_name'             => isset( $v->owner_name ) ? $v->owner_name : '',
                'phone'                  => $v->phone,
                'whatsapp_number'        => isset( $v->whatsapp_number ) ? $v->whatsapp_number : '',
                'email'                  => isset( $v->email ) ? $v->email : '',
                'city'                   => isset( $v->city ) ? $v->city : '',
                'status'                 => $v->status,
                'kyc_status'             => $v->kyc_status,
                'rating'                 => isset( $v->rating ) ? (float) $v->rating : null,
                'total_rides_completed'  => isset( $v->total_rides_completed ) ? (int) $v->total_rides_completed : 0,
                'wallet_balance'         => isset( $v->wallet_balance ) ? (float) $v->wallet_balance : 0,
            );
        }
    }

    /* Lead History tab — every lead sent to a vendor for this booking. */
    $leads = $wpdb->get_results( $wpdb->prepare(
        "SELECT l.*, v.business_name, v.phone AS vphone
         FROM {$wpdb->prefix}ridego_leads l
         LEFT JOIN {$wpdb->prefix}ridego_vendors v ON v.id = l.vendor_id
         WHERE l.booking_id = %d ORDER BY l.sent_at DESC",
        $id
    ) );
    $lead_rows = array_map( function ( $l ) {
        return array(
            'id'          => isset( $l->id ) ? (int) $l->id : 0,
            'vendor_name' => isset( $l->business_name ) ? $l->business_name : 'N/A',
            'vendor_phone' => isset( $l->vphone ) ? $l->vphone : '',
            'fee_amount'  => (float) ridego_lead_fee_lead_view( $l )['amount'],
            'lead_fee'    => ridego_lead_fee_lead_view( $l ),
            'status'      => isset( $l->status ) ? $l->status : 'sent',
            'sent_at'     => isset( $l->sent_at ) ? $l->sent_at : '',
            'expires_at'  => isset( $l->expires_at ) ? $l->expires_at : '',
        );
    }, $leads );

    return rest_ensure_response( array(
        'id'                     => (int) $b->id,
        'booking_number'         => $b->booking_number,
        'client_user_id'         => (int) $b->client_id,
        'client_name'            => $b->client_name,
        'client_phone'           => $b->client_phone,
        'client_alt_phone'       => isset( $b->client_alt_phone ) ? $b->client_alt_phone : '',
        'client_email'           => $b->client_email,
        'passengers'             => (int) $b->passengers,
        'luggage_count'          => isset( $b->luggage_count ) ? (int) $b->luggage_count : 0,
        'passenger_total'        => isset( $b->passenger_total ) && $b->passenger_total !== null ? (int) $b->passenger_total : null,
        'passenger_male'         => isset( $b->passenger_male ) && $b->passenger_male !== null ? (int) $b->passenger_male : null,
        'passenger_female'       => isset( $b->passenger_female ) && $b->passenger_female !== null ? (int) $b->passenger_female : null,
        'passenger_children'     => isset( $b->passenger_children ) && $b->passenger_children !== null ? (int) $b->passenger_children : null,
        'passenger_notes'        => isset( $b->passenger_notes ) ? (string) $b->passenger_notes : '',
        'is_safety_sensitive'    => ridego_booking_is_safety_sensitive( $b ),
        'corporate_company'      => isset( $b->corporate_company ) ? $b->corporate_company : '',
        'corporate_gst'          => isset( $b->corporate_gst ) ? $b->corporate_gst : '',
        'flight_number'          => isset( $b->flight_number ) ? $b->flight_number : '',
        'special_requests'       => isset( $b->special_requests ) ? $b->special_requests : '',
        'trip_type'              => $b->trip_type,
        'pickup_city'            => $b->pickup_city,
        'pickup_address'         => $b->pickup_address,
        'drop_city'              => $b->drop_city,
        'drop_address'           => $b->drop_address,
        'via_cities'             => isset( $b->via_cities ) ? $b->via_cities : '',
        'journey_date'           => $b->journey_date,
        'journey_time'           => $b->journey_time,
        'return_date'            => $b->return_date,
        'return_time'            => isset( $b->return_time ) ? $b->return_time : '',
        'hours_required'         => isset( $b->hours_required ) ? (float) $b->hours_required : 0,
        'distance_km'            => isset( $b->distance_km ) ? (float) $b->distance_km : null,
        'duration_minutes'       => isset( $b->duration_minutes ) ? (int) $b->duration_minutes : null,
        'otp_pickup'             => isset( $b->otp_pickup ) ? $b->otp_pickup : '',
        'vehicle_name'           => isset( $b->vehicle_name ) ? $b->vehicle_name : '',
        'vendor_id'              => isset( $b->vendor_id ) ? (int) $b->vendor_id : 0,
        'vendor_name'            => isset( $b->vendor_name ) ? $b->vendor_name : '',
        'vendor_phone'           => isset( $b->vendor_phone ) ? $b->vendor_phone : '',
        'vendor'                 => $vendor,
        'base_fare'              => (float) $b->base_fare,
        'toll_charges'           => (float) $b->toll_charges,
        'parking_charges'        => isset( $b->parking_charges ) ? (float) $b->parking_charges : 0,
        'driver_allowance'       => isset( $b->driver_allowance ) ? (float) $b->driver_allowance : 0,
        'night_surcharge'        => isset( $b->extra_km_charges ) ? (float) $b->extra_km_charges : 0,
        'gst_amount'             => (float) $b->gst_amount,
        'discount_amount'        => (float) $b->discount_amount,
        'promo_code'             => isset( $b->promo_code ) ? $b->promo_code : '',
        'total_fare'             => (float) $b->total_fare,
        'token_amount'           => isset( $b->token_amount ) ? (float) $b->token_amount : 0.00,
        'advance_paid'           => (float) $b->advance_paid,
        'balance_due'            => (float) $b->balance_due,
        'refund_amount'          => isset( $b->refund_amount ) ? (float) $b->refund_amount : null,
        'refund_reason'          => isset( $b->refund_reason ) ? $b->refund_reason : '',
        'refund_processed_at'    => isset( $b->refund_processed_at ) ? $b->refund_processed_at : '',
        'payment_method'         => $b->payment_method,
        'payment_status'         => $b->payment_status,
        'payment_proof_url'      => $b->payment_proof_url,
        'payment_utr'            => $b->payment_utr,
        'payment_app'            => isset( $b->payment_app ) ? $b->payment_app : '',
        'payment_amount_claimed' => isset( $b->payment_amount_claimed ) ? (float) $b->payment_amount_claimed : null,
        'payment_time_claimed'   => isset( $b->payment_time_claimed ) ? $b->payment_time_claimed : '',
        'payment_verified_by'    => ( isset( $b->payment_verified_by ) && $b->payment_verified_by )
            ? ( ( $u = get_user_by( 'id', $b->payment_verified_by ) ) ? $u->display_name : 'Admin' )
            : '',
        'ip_address'             => isset( $b->ip_address ) ? $b->ip_address : '',
        'utm_source'             => isset( $b->utm_source ) ? $b->utm_source : '',
        'payment_rejection_reason' => $b->payment_rejection_reason,
        'status'                 => $b->status,
        'cancellation_reason'    => $b->cancellation_reason,
        'notes_admin'            => $b->notes_admin,
        'rating_by_client'       => isset( $b->rating_by_client ) ? (float) $b->rating_by_client : null,
        'review_by_client'       => isset( $b->review_by_client ) ? $b->review_by_client : '',
        'leads'                  => $lead_rows,
        'client_profile_id'      => (int) $b->client_profile_id,
        'booking_source'         => $b->booking_source ?: 'online',
        'created_by_name'        => ( (int) $b->created_by && ( $cu = get_user_by( 'id', (int) $b->created_by ) ) ) ? $cu->display_name : '',
        'passenger_details'      => $b->passenger_details ? ( json_decode( (string) $b->passenger_details, true ) ?: array() ) : array(),
        'admin_adjustment'       => (float) $b->admin_adjustment,
        'adjustment_reason'      => (string) $b->adjustment_reason,
        'reschedule_count'       => (int) $b->reschedule_count,
        'rescheduled_from'       => (string) $b->rescheduled_from,
        'invoice_number'         => (string) $b->invoice_number,
        'vehicle_type_id'        => (int) $b->vehicle_type_id,
        'payments'               => ridego_booking_get_payments( $id ),
        'notes'                  => ridego_booking_get_notes( $id ),
        'editable'               => in_array( $b->status, ridego_booking_editable_statuses(), true ),
        'trip_locked'            => in_array( $b->status, array( 'driver_en_route', 'trip_started' ), true ),
        'corporate_emp_id'       => (string) $b->corporate_emp_id,
        'corporate_cost_centre'  => (string) $b->corporate_cost_centre,
        'created_at'             => $b->created_at,
        'updated_at'             => $b->updated_at,
        'lock_version'           => (int) $b->lock_version,
    ) + ridego_booking_money_fields( $b ) + array( 'lead_fee' => ridego_lead_fee_view( $b ), 'vendor_invoice_number_by_vendor' => (string) $b->vendor_invoice_number, 'vendor_collection_methods' => ridego_vendor_collection_methods() ) );
}

/**
 * Vendor picker for the "Assign vendor" control — active + KYC-verified
 * vendors only, matching admin/pages/bookings.php's $all_vendors query.
 */
function ridego_app_admin_api_booking_vendor_picker( WP_REST_Request $req ) {
    global $wpdb;
    $rows = $wpdb->get_results(
        "SELECT id, business_name, phone, wallet_balance
         FROM {$wpdb->prefix}ridego_vendors
         WHERE status='active' AND kyc_status='verified'
         ORDER BY business_name LIMIT 200"
    );
    $out = array_map( function ( $v ) {
        return array(
            'id'             => (int) $v->id,
            'business_name'  => $v->business_name,
            'phone'          => $v->phone,
            'wallet_balance' => (float) $v->wallet_balance,
        );
    }, $rows );
    return rest_ensure_response( array( 'rows' => $out ) );
}

function ridego_app_admin_api_booking_verify_payment( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    if ( ! ridego_get_booking( $id ) ) {
        return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
    }
    $ok = ridego_verify_payment( $id, get_current_user_id() );
    if ( ! $ok ) {
        return new WP_Error( 'verify_failed', 'Could not verify payment for this booking.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => 'Payment verified. Booking confirmed.' ) );
}

function ridego_app_admin_api_booking_reject_payment( WP_REST_Request $req ) {
    $id     = (int) $req->get_param( 'id' );
    $reason = sanitize_textarea_field( (string) $req->get_param( 'reason' ) );
    if ( ! $reason ) {
        return new WP_Error( 'invalid_input', 'Please provide a rejection reason.', array( 'status' => 400 ) );
    }
    if ( ! ridego_get_booking( $id ) ) {
        return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
    }
    $ok = ridego_reject_payment( $id, $reason, get_current_user_id() );
    if ( ! $ok ) {
        return new WP_Error( 'reject_failed', 'Could not reject payment for this booking.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => 'Payment rejected.' ) );
}

/**
 * Delegates entirely to ridego_cancel_booking(), the single
 * canonical cancel/refund function (also used by the client's own
 * cancel action and the wp-admin page's single + bulk cancel).
 * $cancelled_by is forced to 'admin' — matching what
 * admin/pages/bookings.php itself passes — so the ownership check
 * inside ridego_cancel_booking() (which only applies to 'client')
 * is correctly bypassed here, not silently worked around.
 */
function ridego_app_admin_api_booking_cancel( WP_REST_Request $req ) {
    $id     = (int) $req->get_param( 'id' );
    $reason = sanitize_textarea_field( (string) $req->get_param( 'reason' ) );
    if ( ! ridego_get_booking( $id ) ) {
        return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
    }
    $result = ridego_cancel_booking( $id, $reason, 'admin' );
    if ( empty( $result['success'] ) ) {
        return new WP_Error( 'cancel_failed', isset( $result['message'] ) ? $result['message'] : 'Could not cancel this booking.', array( 'status' => 400 ) );
    }
    return rest_ensure_response( $result );
}

/**
 * Token Amount / Advance Payment, spec items 3 & 9: RideGo was unable to
 * arrange the requested vehicle/booking, so the client's token is due
 * back to them — 100% refundable, since RideGo did not deliver on the
 * booking. Only valid BEFORE a vendor has been arranged: once a vendor
 * is assigned the booking has moved past "not arranged" by definition,
 * and any refund from that point on goes through the normal
 * cancellation flow (ridego_cancel_booking()), which is the point where
 * the token becomes non-refundable per spec item 4. Also refused once
 * the booking is already cancelled/completed, same as the cancel action.
 */
function ridego_app_admin_api_booking_mark_not_arranged( WP_REST_Request $req ) {
    global $wpdb;
    $id     = (int) $req->get_param( 'id' );
    $reason = sanitize_textarea_field( (string) $req->get_param( 'reason' ) );

    $b = ridego_get_booking( $id );
    if ( ! $b ) {
        return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
    }
    if ( ! empty( $b->vendor_id ) ) {
        return new WP_Error( 'already_arranged', 'A vendor has already been arranged for this booking — use Cancel instead.', array( 'status' => 400 ) );
    }
    if ( in_array( $b->status, array( 'completed', 'cancelled', 'trip_started', 'token_refund_due' ), true ) ) {
        return new WP_Error( 'invalid_state', 'This booking cannot be marked as not arranged.', array( 'status' => 400 ) );
    }

    $btbl = $wpdb->prefix . 'ridego_bookings';
    $wpdb->update( $btbl, array(
        'status'              => 'token_refund_due',
        'cancellation_reason' => $reason ? $reason : '' . ridego_brand_name() . ' could not arrange the requested vehicle/booking.',
        'cancelled_by'        => 'admin',
        'cancellation_time'   => current_time( 'mysql' ),
        'updated_at'          => current_time( 'mysql' ),
    ), array( 'id' => $id ) );

    $refund_amount = (float) $b->advance_paid;
    if ( $refund_amount > 0 && function_exists( 'ridego_process_refund' ) ) {
        ridego_process_refund( $id, $refund_amount, $reason ? $reason : 'Booking not arranged - booking amount refund' );
    }

    ridego_audit_log( 'booking_not_arranged', 'booking', $id, $b->status, 'token_refund_due' );
    do_action( 'ridego_booking_cancelled', $id, 'admin', $refund_amount );

    return rest_ensure_response( array(
        'success'       => true,
        'message'       => $refund_amount > 0
            ? 'Booking marked as not arranged. Booking amount refund of ₹' . number_format( $refund_amount, 2 ) . ' initiated.'
            : 'Booking marked as not arranged.',
        'refund_amount' => $refund_amount,
    ) );
}

/**
 * Bulk verify-payment / cancel over a set of booking IDs. Mirrors
 * admin/pages/bookings.php's rga_bulk_act handler line for line: same
 * per-row eligibility rules (verify only if payment_status is
 * 'proof_submitted'; cancel skipped for completed/cancelled/trip_started),
 * same canonical ridego_verify_payment()/ridego_cancel_booking() calls,
 * same audit log entries, same "N succeeded, M skipped" summary shape.
 */
function ridego_app_admin_api_bookings_bulk( WP_REST_Request $req ) {
    $action = sanitize_key( (string) $req->get_param( 'action' ) );
    $ids    = $req->get_param( 'ids' );
    $ids    = is_array( $ids ) ? array_filter( array_unique( array_map( 'absint', $ids ) ) ) : array();

    if ( ! in_array( $action, array( 'verify_payment', 'cancel' ), true ) ) {
        return new WP_Error( 'invalid_action', 'Unknown bulk action.', array( 'status' => 400 ) );
    }
    if ( empty( $ids ) ) {
        return new WP_Error( 'invalid_input', 'No bookings selected.', array( 'status' => 400 ) );
    }

    $ok = 0;
    $skipped = array();
    foreach ( $ids as $bid ) {
        $b = ridego_get_booking( $bid );
        if ( ! $b ) { $skipped[] = "#{$bid} (not found)"; continue; }

        if ( 'verify_payment' === $action ) {
            if ( 'proof_submitted' !== $b->payment_status ) {
                $skipped[] = $b->booking_number . ' (not awaiting verification)';
                continue;
            }
            ridego_verify_payment( $bid, get_current_user_id() );
            $ok++;
        } else {
            if ( in_array( $b->status, array( 'completed', 'cancelled', 'trip_started', 'token_refund_due' ), true ) ) {
                $skipped[] = $b->booking_number . ' (cannot cancel)';
                continue;
            }
            $r = ridego_cancel_booking( $bid, 'Bulk admin cancellation', 'admin' );
            if ( is_array( $r ) && empty( $r['success'] ) ) {
                $skipped[] = $b->booking_number . ' (' . ( $r['message'] ?? 'failed' ) . ')';
                continue;
            }
            $ok++;
        }
        ridego_audit_log( 'bulk_' . $action, 'booking', $bid );
    }

    $message = $ok . ' succeeded' . ( count( $skipped ) ? ', ' . count( $skipped ) . ' skipped: ' . implode( '; ', array_slice( $skipped, 0, 5 ) ) . ( count( $skipped ) > 5 ? ' …' : '' ) : '.' );

    return rest_ensure_response( array(
        'success'   => $ok > 0,
        'message'   => $message,
        'succeeded' => $ok,
        'skipped'   => $skipped,
    ) );
}

function ridego_app_admin_api_booking_complete( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    if ( ! ridego_get_booking( $id ) ) {
        return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
    }
    ridego_update_booking_status( $id, 'completed' );
    ridego_audit_log( 'mark_completed', 'booking', $id, '', 'completed' );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Booking marked completed.' ) );
}

/**
 * Delegates to the canonical ridego_assign_vendor_to_booking()
 * (includes/helpers.php) — previously this duplicated
 * admin/pages/bookings.php's raw inline $wpdb->update(); both now
 * share one implementation so they can never drift apart. See that
 * function's doc comment for the extraction history.
 */
function ridego_app_admin_api_booking_assign_vendor( WP_REST_Request $req ) {
    $id        = (int) $req->get_param( 'id' );
    $vendor_id = (int) $req->get_param( 'vendor_id' );

    $r = ridego_assign_vendor_to_booking( $id, $vendor_id );
    if ( empty( $r['success'] ) ) {
        $code = 'assign_failed';
        $status = 500;
        if ( $r['message'] === 'Please choose a vendor.' ) { $code = 'invalid_input'; $status = 400; }
        elseif ( $r['message'] === 'Booking not found.' ) { $code = 'not_found'; $status = 404; }
        elseif ( $r['message'] === 'Vendor not found.' ) { $code = 'vendor_not_found'; $status = 404; }
        return new WP_Error( $code, $r['message'], array( 'status' => $status ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => 'Vendor assigned.' ) );
}

// TRACE: POST bookings/{id}/status {status} → validates the target is a real, non-terminal status and applies
//        it via the generic setter → {success}|400/404. Preconditions: booking exists. Postconditions: status
//        changed AND audited with the previous value recorded, never blind. Edge cases: unknown status string
//        (400, named); target is 'cancelled'/'token_refund_due' — rejected, since those carry refund/eligibility
//        logic (ridego_cancel_booking(), the vendor/state checks in mark-not-arranged) that this generic route
//        does not run, and skipping it would produce exactly the "cancelled with no refund record" contradiction
//        flagged in the platform audit. 'completed' is intentionally left allowed here: the dedicated /complete
//        endpoint does nothing beyond this same status write today, so blocking it here would only break the
//        existing admin UI (AdminBookingDetailPage's status dropdown) for zero safety benefit.
//
// ROOT-CAUSE FIX: this previously accepted ANY string and wrote it straight through
// ridego_update_booking_status() with no validation at all — an admin/staff typo, or a
// UI bug sending a stale/wrong value, could silently set a booking to a status that does
// not exist, or to 'cancelled'/'token_refund_due' without ever running the refund/eligibility
// logic those dedicated endpoints (/cancel, /mark-not-arranged) perform.
function ridego_app_admin_api_booking_status( WP_REST_Request $req ) {
    $id     = (int) $req->get_param( 'id' );
    $status = sanitize_key( (string) $req->get_param( 'status' ) );
    if ( ! $status ) {
        return new WP_Error( 'invalid_input', 'Please specify a target status.', array( 'status' => 400 ) );
    }
    $known_statuses = array(
        'pending', 'pending_payment', 'payment_pending', 'payment_rejected',
        'confirmed', 'no_vendor', 'vendor_assigned', 'disputed',
        'driver_en_route', 'trip_started', 'completed', 'expired',
    );
    $refund_gated_statuses = array( 'cancelled', 'token_refund_due', 'no_show' );
    if ( in_array( $status, $refund_gated_statuses, true ) ) {
        return new WP_Error(
            'use_dedicated_endpoint',
            'This status change involves a refund/forfeit decision and cannot be set from the generic status field — cancel or mark-not-arranged for cancelled/token_refund_due, or the driver no-show flow for no_show.',
            array( 'status' => 400 )
        );
    }
    if ( ! in_array( $status, $known_statuses, true ) ) {
        return new WP_Error( 'invalid_input', 'Unknown status: ' . $status, array( 'status' => 400 ) );
    }
    $b = ridego_get_booking( $id );
    if ( ! $b ) {
        return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
    }
    // Optimistic lock (opt-in): a client that read the booking and sends back the lock_version it saw is
    // protected against overwriting a change another admin made in between — the classic two-tabs-open
    // lost-update race this whole family of endpoints was previously exposed to. A client that doesn't
    // send it (older UI, or an internal/system caller) behaves exactly as before. See
    // ridego_claim_lock_version()'s own doc comment: this used to compare a DATETIME updated_at, which
    // adversarial testing showed was broken (1-second granularity lets same-second writes collide
    // silently) — replaced with an atomic integer counter claim.
    global $wpdb;
    $lock = ridego_claim_lock_version( "{$wpdb->prefix}ridego_bookings", $id, $req->get_param( 'expected_lock_version' ) );
    if ( $lock !== true ) {
        return new WP_Error( 'conflict', $lock['message'], array( 'status' => 409, 'current_lock_version' => $lock['current_lock_version'] ) );
    }
    $previous = $b->status;
    ridego_update_booking_status( $id, $status );
    ridego_audit_log( 'status_change', 'booking', $id, $previous, $status );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Status updated.' ) );
}

function ridego_app_admin_api_booking_note( WP_REST_Request $req ) {
    global $wpdb;
    $id   = (int) $req->get_param( 'id' );
    $note = sanitize_textarea_field( (string) $req->get_param( 'note' ) );
    if ( ! ridego_get_booking( $id ) ) {
        return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
    }
    $btbl   = $wpdb->prefix . 'ridego_bookings';
    $result = $wpdb->update( $btbl, array( 'notes_admin' => $note, 'updated_at' => current_time( 'mysql' ) ), array( 'id' => $id ) );
    if ( false === $result ) {
        return new WP_Error( 'save_failed', 'Could not save note.', array( 'status' => 500 ) );
    }
    return rest_ensure_response( array( 'success' => true, 'message' => 'Note saved.' ) );
}

/**
 * Re-fires the ridego_booking_confirmed hook — the exact same hook the
 * confirmation email/SMS/WhatsApp is originally sent from — mirroring
 * admin/pages/bookings.php's 'send_confirmation' action.
 */
function ridego_app_admin_api_booking_resend_confirmation( WP_REST_Request $req ) {
    $id = (int) $req->get_param( 'id' );
    if ( ! ridego_get_booking( $id ) ) {
        return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
    }
    do_action( 'ridego_booking_confirmed', $id );
    ridego_audit_log( 'send_confirmation', 'booking', $id );
    return rest_ensure_response( array( 'success' => true, 'message' => 'Confirmation re-sent.' ) );
}

// TRACE: GET bookings/{id}/timeline → merges (a) every wp_ridego_audit_log row for entity='booking',
//        entity_id={id} — status changes, vendor assignment, cancellation, refunds, note additions, resent
//        confirmations, everything already written via ridego_audit_log() throughout the booking's life —
//        (b) internal + client notes via ridego_booking_get_notes() and (c) the payment/refund ledger via
//        ridego_booking_get_payments(), into one array sorted newest-first by a common 'at' timestamp, each
//        entry tagged with a 'source' so the UI can render a distinct icon/color per kind → {booking_id,
//        booking_number, entries:[{source,at,label,detail,by,severity}], count}. Read-only; no table is written.
//        Preconditions: booking exists. Postconditions: entries is a strict superset of what any single one of
//        the three source views showed before — nothing already visible elsewhere is duplicated-away, and
//        nothing new is fabricated: every entry traces back to an existing row in one of the three tables.
//        Edge cases: booking with zero audit/notes/payments rows (empty entries, not an error); audit rows
//        with a null/blank admin_id (rendered as 'System', matching the existing /audit-log endpoint's own
//        fallback); duplicate timestamps (stable secondary sort by source then id so output order is
//        deterministic across repeated calls, not resorted differently every request).
function ridego_app_admin_api_booking_timeline( WP_REST_Request $req ) {
    global $wpdb;
    $id = (int) $req->get_param( 'id' );
    $b  = ridego_get_booking( $id );
    if ( ! $b ) {
        return new WP_Error( 'not_found', 'Booking not found.', array( 'status' => 404 ) );
    }

    $entries = array();

    $audit_rows = $wpdb->get_results( $wpdb->prepare(
        "SELECT l.*, u.user_login FROM {$wpdb->prefix}ridego_audit_log l
         LEFT JOIN {$wpdb->users} u ON u.ID = l.admin_id
         WHERE l.entity='booking' AND l.entity_id=%d ORDER BY l.id DESC",
        $id
    ) );
    foreach ( $audit_rows as $r ) {
        $entries[] = array(
            'source'   => 'audit',
            'sort_id'  => (int) $r->id,
            'at'       => $r->created_at,
            'label'    => $r->action,
            'detail'   => trim( ( $r->old_value !== '' && $r->old_value !== null ? ( (string) $r->old_value . ' -> ' ) : '' ) . (string) $r->new_value ),
            'by'       => $r->user_login ?: 'System',
            'severity' => $r->severity ?: 'info',
        );
    }

    foreach ( ridego_booking_get_notes( $id ) as $n ) {
        $entries[] = array(
            'source'   => 'note',
            'sort_id'  => (int) $n['id'],
            'at'       => $n['created_at'],
            'label'    => $n['visibility'] === 'client' ? 'Client-visible note' : 'Internal note',
            'detail'   => $n['note'],
            'by'       => $n['author'],
            'severity' => 'info',
        );
    }

    foreach ( ridego_booking_get_payments( $id ) as $p ) {
        $entries[] = array(
            'source'   => 'payment',
            'sort_id'  => (int) $p['id'],
            'at'       => $p['created_at'],
            'label'    => ucfirst( str_replace( '_', ' ', $p['entry_type'] ) ) . ' recorded',
            'detail'   => 'Rs. ' . number_format( (float) $p['amount'], 2 ) . ( $p['method'] ? ' via ' . $p['method'] : '' ) . ( $p['reference'] ? ' (ref: ' . $p['reference'] . ')' : '' ) . ( $p['note'] ? ' — ' . $p['note'] : '' ),
            'by'       => $p['recorded_by'],
            'severity' => $p['entry_type'] === 'refund' ? 'warning' : 'info',
        );
    }

    usort( $entries, function ( $a, $c ) {
        $t = strcmp( (string) $c['at'], (string) $a['at'] );
        if ( $t !== 0 ) { return $t; }
        $s = strcmp( (string) $a['source'], (string) $c['source'] );
        if ( $s !== 0 ) { return $s; }
        return $c['sort_id'] - $a['sort_id'];
    } );

    foreach ( $entries as &$e ) { unset( $e['sort_id'] ); }
    unset( $e );

    return rest_ensure_response( array(
        'booking_id'     => (int) $b->id,
        'booking_number' => $b->booking_number,
        'entries'        => $entries,
        'count'          => count( $entries ),
    ) );
}
