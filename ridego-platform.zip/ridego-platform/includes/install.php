<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   DB INSTALLATION - ALL TABLES
   ============================================================ */
function ridego_install_tables() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    /*  BOOKINGS  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_bookings (
        id                       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_number           VARCHAR(20)     NOT NULL DEFAULT '',
        client_id                BIGINT UNSIGNED NOT NULL DEFAULT 0,
        client_name              VARCHAR(150)    NOT NULL DEFAULT '',
        client_phone             VARCHAR(20)     NOT NULL DEFAULT '',
        client_email             VARCHAR(150)    NOT NULL DEFAULT '',
        client_alt_phone         VARCHAR(20)     NOT NULL DEFAULT '',
        trip_type                VARCHAR(30)     NOT NULL DEFAULT 'one_way',
        pickup_city              VARCHAR(100)    NOT NULL DEFAULT '',
        pickup_address           TEXT            NOT NULL,
        pickup_lat               DECIMAL(10,8)   DEFAULT NULL,
        pickup_lng               DECIMAL(11,8)   DEFAULT NULL,
        drop_city                VARCHAR(100)    NOT NULL DEFAULT '',
        drop_address             TEXT            NOT NULL,
        drop_lat                 DECIMAL(10,8)   DEFAULT NULL,
        drop_lng                 DECIMAL(11,8)   DEFAULT NULL,
        via_cities               TEXT            NOT NULL DEFAULT '',
        journey_date             DATE            NOT NULL,
        journey_time             TIME            NOT NULL,
        return_date              DATE            DEFAULT NULL,
        return_time              TIME            DEFAULT NULL,
        hours_required           INT             DEFAULT NULL,
        passengers               TINYINT         NOT NULL DEFAULT 1,
        luggage_count            TINYINT         NOT NULL DEFAULT 0,
        vehicle_type_id          INT             NOT NULL DEFAULT 0,
        vehicle_id               INT             DEFAULT NULL,
        vendor_id                INT             DEFAULT NULL,
        distance_km              DECIMAL(8,2)    NOT NULL DEFAULT 0.00,
        duration_minutes         INT             NOT NULL DEFAULT 0,
        base_fare                DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        toll_charges             DECIMAL(8,2)    NOT NULL DEFAULT 0.00,
        parking_charges          DECIMAL(8,2)    NOT NULL DEFAULT 0.00,
        driver_allowance         DECIMAL(8,2)    NOT NULL DEFAULT 0.00,
        extra_km_charges         DECIMAL(8,2)    NOT NULL DEFAULT 0.00,
        gst_amount               DECIMAL(8,2)    NOT NULL DEFAULT 0.00,
        discount_amount          DECIMAL(8,2)    NOT NULL DEFAULT 0.00,
        promo_code               VARCHAR(30)     NOT NULL DEFAULT '',
        total_fare               DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        advance_paid             DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        balance_due              DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
        lead_fee_charged         DECIMAL(8,2)    NOT NULL DEFAULT 0.00,
        lead_fee_paid            TINYINT(1)      NOT NULL DEFAULT 0,
        payment_method           VARCHAR(30)     NOT NULL DEFAULT 'cash',
        payment_status           VARCHAR(30)     NOT NULL DEFAULT 'pending',
        payment_proof_url        VARCHAR(500)    NOT NULL DEFAULT '',
        payment_proof_filename   VARCHAR(200)    NOT NULL DEFAULT '',
        payment_utr              VARCHAR(50)     NOT NULL DEFAULT '',
        payment_app              VARCHAR(50)     NOT NULL DEFAULT '',
        payment_time_claimed     DATETIME        DEFAULT NULL,
        payment_amount_claimed   DECIMAL(10,2)   DEFAULT NULL,
        payment_verified_by      BIGINT UNSIGNED DEFAULT NULL,
        payment_verified_at      DATETIME        DEFAULT NULL,
        payment_rejection_reason TEXT            NOT NULL DEFAULT '',
        payment_deadline         DATETIME        DEFAULT NULL,
        special_requests         TEXT            NOT NULL DEFAULT '',
        flight_number            VARCHAR(20)     NOT NULL DEFAULT '',
        flight_arrival_time      DATETIME        DEFAULT NULL,
        corporate_company        VARCHAR(150)    NOT NULL DEFAULT '',
        corporate_gst            VARCHAR(20)     NOT NULL DEFAULT '',
        corporate_emp_id         VARCHAR(50)     NOT NULL DEFAULT '',
        corporate_cost_centre    VARCHAR(50)     NOT NULL DEFAULT '',
        status                   VARCHAR(40)     NOT NULL DEFAULT 'pending_payment',
        cancellation_reason      TEXT            NOT NULL DEFAULT '',
        cancelled_by             VARCHAR(20)     NOT NULL DEFAULT '',
        cancellation_time        DATETIME        DEFAULT NULL,
        otp_pickup               VARCHAR(6)      NOT NULL DEFAULT '',
        trip_started_at          DATETIME        DEFAULT NULL,
        trip_ended_at            DATETIME        DEFAULT NULL,
        actual_distance_km       DECIMAL(8,2)    DEFAULT NULL,
        rating_by_client         TINYINT         DEFAULT NULL,
        review_by_client         TEXT            NOT NULL DEFAULT '',
        rating_by_vendor         TINYINT         DEFAULT NULL,
        notes_admin              TEXT            NOT NULL DEFAULT '',
        ip_address               VARCHAR(45)     NOT NULL DEFAULT '',
        utm_source               VARCHAR(100)    NOT NULL DEFAULT '',
        created_at               DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at               DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY booking_number (booking_number),
        KEY status (status),
        KEY journey_date (journey_date),
        KEY pickup_city (pickup_city),
        KEY vendor_id (vendor_id),
        KEY client_id (client_id),
        KEY payment_status (payment_status),
        KEY created_at (created_at)
    ) $c;");

    /*  BOOKINGS ARCHIVE  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_bookings_archive LIKE {$wpdb->prefix}ridego_bookings;");

    /*  VEHICLE TYPES  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_vehicles (
        id                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
        name                 VARCHAR(100) NOT NULL,
        slug                 VARCHAR(50)  NOT NULL,
        icon_url             VARCHAR(500) NOT NULL DEFAULT '',
        seating_capacity     TINYINT      NOT NULL DEFAULT 4,
        luggage_capacity     TINYINT      NOT NULL DEFAULT 2,
        ac_available         TINYINT(1)   NOT NULL DEFAULT 1,
        features             TEXT         NOT NULL DEFAULT '',
        base_price_per_km    DECIMAL(6,2) NOT NULL DEFAULT 12.00,
        base_price_outstation DECIMAL(6,2) NOT NULL DEFAULT 13.00,
        minimum_km           DECIMAL(6,2) NOT NULL DEFAULT 50.00,
        night_charge_pct     DECIMAL(4,2) NOT NULL DEFAULT 15.00,
        driver_allowance_day DECIMAL(6,2) NOT NULL DEFAULT 250.00,
        extra_hour_charge    DECIMAL(6,2) NOT NULL DEFAULT 150.00,
        airport_base_charge  DECIMAL(8,2) NOT NULL DEFAULT 900.00,
        local_4hr_40km       DECIMAL(8,2) NOT NULL DEFAULT 1000.00,
        local_8hr_80km       DECIMAL(8,2) NOT NULL DEFAULT 1800.00,
        local_extra_km       DECIMAL(6,2) NOT NULL DEFAULT 12.00,
        local_extra_hr       DECIMAL(6,2) NOT NULL DEFAULT 150.00,
        lead_fee_fixed       DECIMAL(6,2) NOT NULL DEFAULT 50.00,
        lead_fee_pct         DECIMAL(4,2) NOT NULL DEFAULT 8.00,
        lead_fee_mode        VARCHAR(20)  NOT NULL DEFAULT 'fixed',
        is_active            TINYINT(1)   NOT NULL DEFAULT 1,
        sort_order           INT          NOT NULL DEFAULT 0,
        created_at           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY slug (slug)
    ) $c;");

    /*  VENDORS  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_vendors (
        id                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id              BIGINT UNSIGNED NOT NULL,
        business_name        VARCHAR(200) NOT NULL DEFAULT '',
        owner_name           VARCHAR(150) NOT NULL DEFAULT '',
        phone                VARCHAR(20)  NOT NULL DEFAULT '',
        alt_phone            VARCHAR(20)  NOT NULL DEFAULT '',
        email                VARCHAR(150) NOT NULL DEFAULT '',
        whatsapp_number      VARCHAR(20)  NOT NULL DEFAULT '',
        profile_photo        VARCHAR(500) NOT NULL DEFAULT '',
        business_type        VARCHAR(30)  NOT NULL DEFAULT 'individual',
        gst_number           VARCHAR(20)  NOT NULL DEFAULT '',
        pan_number           VARCHAR(20)  NOT NULL DEFAULT '',
        address              TEXT         NOT NULL DEFAULT '',
        city                 VARCHAR(100) NOT NULL DEFAULT '',
        operating_cities     TEXT         NOT NULL DEFAULT '',
        vehicle_types        TEXT         NOT NULL DEFAULT '',
        total_vehicles       INT          NOT NULL DEFAULT 1,
        years_experience     TINYINT      NOT NULL DEFAULT 0,
        license_number       VARCHAR(50)  NOT NULL DEFAULT '',
        license_expiry       DATE         DEFAULT NULL,
        insurance_policy     VARCHAR(50)  NOT NULL DEFAULT '',
        insurance_expiry     DATE         DEFAULT NULL,
        documents_verified   TINYINT(1)   NOT NULL DEFAULT 0,
        background_check     TINYINT(1)   NOT NULL DEFAULT 0,
        kyc_status           VARCHAR(20)  NOT NULL DEFAULT 'pending',
        wallet_balance       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        wallet_hold          DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        total_leads_received INT          NOT NULL DEFAULT 0,
        total_leads_accepted INT          NOT NULL DEFAULT 0,
        total_rides_completed INT         NOT NULL DEFAULT 0,
        rating               DECIMAL(3,2) NOT NULL DEFAULT 0.00,
        total_ratings        INT          NOT NULL DEFAULT 0,
        commission_pct       DECIMAL(4,2) NOT NULL DEFAULT 0.00,
        status               VARCHAR(20)  NOT NULL DEFAULT 'pending',
        subscription_plan_id INT          DEFAULT NULL,
        subscription_expires DATE         DEFAULT NULL,
        subscription_status VARCHAR(20)  NOT NULL DEFAULT 'none',
        expiry_alert_sent_at DATETIME    DEFAULT NULL,
        bank_account         VARCHAR(50)  NOT NULL DEFAULT '',
        bank_name            VARCHAR(100) NOT NULL DEFAULT '',
        bank_ifsc            VARCHAR(20)  NOT NULL DEFAULT '',
        bank_holder          VARCHAR(150) NOT NULL DEFAULT '',
        upi_id               VARCHAR(100) NOT NULL DEFAULT '',
        joined_at            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_login           DATETIME     DEFAULT NULL,
        notes_admin          TEXT         NOT NULL DEFAULT '',
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY status (status),
        KEY city (city),
        KEY kyc_status (kyc_status),
        KEY wallet_balance (wallet_balance),
        KEY license_expiry (license_expiry),
        KEY insurance_expiry (insurance_expiry)
    ) $c;");

    /*  CITIES  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_cities (
        id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
        name         VARCHAR(100) NOT NULL,
        slug         VARCHAR(100) NOT NULL,
        state        VARCHAR(100) NOT NULL DEFAULT '',
        country      VARCHAR(50)  NOT NULL DEFAULT 'India',
        lat          DECIMAL(10,8) DEFAULT NULL,
        lng          DECIMAL(11,8) DEFAULT NULL,
        airport_name VARCHAR(200) NOT NULL DEFAULT '',
        airport_code VARCHAR(10)  NOT NULL DEFAULT '',
        is_popular   TINYINT(1)   NOT NULL DEFAULT 0,
        is_active    TINYINT(1)   NOT NULL DEFAULT 1,
        sort_order   INT          NOT NULL DEFAULT 0,
        is_origin_enabled      TINYINT(1) NOT NULL DEFAULT 1,
        is_destination_enabled TINYINT(1) NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        UNIQUE KEY slug (slug),
        KEY is_active (is_active),
        KEY is_popular (is_popular)
    ) $c;");

    /*  ROUTES  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_routes (
        id                   INT UNSIGNED NOT NULL AUTO_INCREMENT,
        from_city_id         INT UNSIGNED NOT NULL,
        to_city_id           INT UNSIGNED NOT NULL,
        from_city            VARCHAR(100) NOT NULL,
        to_city              VARCHAR(100) NOT NULL,
        distance_km          DECIMAL(8,2) NOT NULL DEFAULT 0.00,
        duration_mins        INT          NOT NULL DEFAULT 0,
        toll_estimate        DECIMAL(8,2) DEFAULT NULL,
        default_fixed_price  DECIMAL(10,2) DEFAULT NULL,
        is_popular           TINYINT(1)   NOT NULL DEFAULT 0,
        is_active            TINYINT(1)   NOT NULL DEFAULT 1,
        created_at           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY route_pair (from_city_id, to_city_id),
        KEY from_city_id (from_city_id),
        KEY to_city_id (to_city_id),
        KEY is_popular (is_popular)
    ) $c;");

    /*  PER-VEHICLE ROUTE PRICING (fixed price / toll overrides by vehicle class)  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_route_vehicle_pricing (
        id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
        route_id      INT UNSIGNED NOT NULL,
        vehicle_id    INT UNSIGNED NOT NULL,
        fixed_price   DECIMAL(10,2) DEFAULT NULL,
        toll_estimate DECIMAL(8,2) DEFAULT NULL,
        created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY route_vehicle (route_id, vehicle_id),
        KEY route_id (route_id)
    ) $c;");

    /*  ROUTE PRICE CACHE  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_route_cache (
        id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
        cache_key    VARCHAR(64)  NOT NULL,
        distance_km  DECIMAL(8,2) NOT NULL,
        duration_min INT          NOT NULL,
        cached_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        expires_at   DATETIME     NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY cache_key (cache_key)
    ) $c;");

    /*  LEADS  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_leads (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_id   BIGINT UNSIGNED NOT NULL,
        vendor_id    INT UNSIGNED    NOT NULL,
        sent_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        expires_at   DATETIME        NOT NULL,
        status       VARCHAR(20)     NOT NULL DEFAULT 'sent',
        fee_amount   DECIMAL(8,2)    NOT NULL DEFAULT 0.00,
        fee_deducted TINYINT(1)      NOT NULL DEFAULT 0,
        responded_at DATETIME        DEFAULT NULL,
        response     VARCHAR(20)     NOT NULL DEFAULT '',
        reject_reason VARCHAR(200)   NOT NULL DEFAULT '',
        PRIMARY KEY (id),
        KEY booking_id (booking_id),
        KEY vendor_id (vendor_id),
        KEY status (status),
        KEY expires_at (expires_at)
    ) $c;");

    /*  TRANSACTIONS  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_transactions (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        type         VARCHAR(30)     NOT NULL,
        amount       DECIMAL(10,2)   NOT NULL,
        vendor_id    INT UNSIGNED    DEFAULT NULL,
        booking_id   BIGINT UNSIGNED DEFAULT NULL,
        gateway      VARCHAR(30)     NOT NULL DEFAULT 'manual',
        gateway_ref  VARCHAR(100)    NOT NULL DEFAULT '',
        status       VARCHAR(20)     NOT NULL DEFAULT 'success',
        notes        TEXT            NOT NULL DEFAULT '',
        created_by   BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY vendor_id (vendor_id),
        KEY booking_id (booking_id),
        KEY type (type),
        KEY created_at (created_at)
    ) $c;");

    /*  VENDOR WALLET LOG  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_vendor_wallets (
        id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        vendor_id     INT UNSIGNED    NOT NULL,
        type          VARCHAR(20)     NOT NULL,
        amount        DECIMAL(10,2)   NOT NULL,
        balance_after DECIMAL(10,2)   NOT NULL,
        booking_id    BIGINT UNSIGNED DEFAULT NULL,
        notes         TEXT            NOT NULL DEFAULT '',
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY vendor_id (vendor_id),
        KEY created_at (created_at)
    ) $c;");

    /*  COMPLAINTS  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_complaints (
        id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        complaint_id   VARCHAR(20)     NOT NULL DEFAULT '',
        booking_id     BIGINT UNSIGNED NOT NULL,
        raised_by_id   BIGINT UNSIGNED NOT NULL,
        raised_by_type VARCHAR(20)     NOT NULL DEFAULT 'client',
        category       VARCHAR(50)     NOT NULL DEFAULT '',
        sub_category   VARCHAR(100)    NOT NULL DEFAULT '',
        description    TEXT            NOT NULL,
        evidence_urls  TEXT            NOT NULL DEFAULT '',
        status         VARCHAR(20)     NOT NULL DEFAULT 'open',
        priority       VARCHAR(10)     NOT NULL DEFAULT 'normal',
        assigned_to    BIGINT UNSIGNED DEFAULT NULL,
        resolution     TEXT            NOT NULL DEFAULT '',
        resolved_at    DATETIME        DEFAULT NULL,
        sla_deadline   DATETIME        DEFAULT NULL,
        created_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY complaint_id (complaint_id),
        KEY booking_id (booking_id),
        KEY status (status),
        KEY created_at (created_at),
        KEY sla_deadline (sla_deadline)
    ) $c;");

    /*  NOTIFICATIONS QUEUE  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_notification_queue (
        id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        recipient_id   BIGINT UNSIGNED NOT NULL DEFAULT 0,
        recipient_type VARCHAR(20)     NOT NULL DEFAULT 'client',
        recipient_phone VARCHAR(20)    NOT NULL DEFAULT '',
        recipient_email VARCHAR(150)   NOT NULL DEFAULT '',
        event          VARCHAR(50)     NOT NULL,
        channel        VARCHAR(20)     NOT NULL DEFAULT 'whatsapp',
        priority       VARCHAR(10)     NOT NULL DEFAULT 'normal',
        payload        LONGTEXT        NOT NULL,
        scheduled_for  DATETIME        NOT NULL,
        status         VARCHAR(20)     NOT NULL DEFAULT 'pending',
        attempts       TINYINT         NOT NULL DEFAULT 0,
        next_retry_at  DATETIME        DEFAULT NULL,
        sent_at        DATETIME        DEFAULT NULL,
        error_msg      TEXT            NOT NULL DEFAULT '',
        created_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY status (status),
        KEY scheduled_for (scheduled_for),
        KEY priority_created (priority, created_at),
        KEY next_retry_at (next_retry_at)
    ) $c;");

    /*  NOTIFICATION LOG  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_notifications (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id      BIGINT UNSIGNED NOT NULL DEFAULT 0,
        event        VARCHAR(50)     NOT NULL,
        channel      VARCHAR(20)     NOT NULL,
        message      TEXT            NOT NULL,
        status       VARCHAR(20)     NOT NULL DEFAULT 'sent',
        sent_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY sent_at (sent_at)
    ) $c;");

    /*  PROMO CODES
        NOTE: `type`/`value`/`min_booking`/`valid_from`/`valid_to` are kept
        as legacy-compatible columns; `discount_type`/`discount_value`/
        `min_booking_amount`/`start_date`/`expiry_date` are the canonical
        columns used by includes/promo.php's full rule engine going
        forward (see includes/migrations.php migration 002 for the
        reconciliation of pre-existing installs). New installs get both
        sets so no migration step is required for a fresh site.  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_promo_codes (
        id                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
        code                  VARCHAR(30)  NOT NULL,
        description           VARCHAR(255) NOT NULL DEFAULT '',
        type                  VARCHAR(20)  NOT NULL DEFAULT 'percentage',
        value                 DECIMAL(8,2) NOT NULL DEFAULT 0.00,
        discount_type         VARCHAR(20)  NOT NULL DEFAULT 'percentage',
        discount_value        DECIMAL(8,2) NOT NULL DEFAULT 0.00,
        max_discount          DECIMAL(8,2) DEFAULT NULL,
        min_booking           DECIMAL(8,2) NOT NULL DEFAULT 0.00,
        min_booking_amount    DECIMAL(8,2) NOT NULL DEFAULT 0.00,
        trip_type             VARCHAR(30)  NOT NULL DEFAULT '',
        vehicle_id            INT UNSIGNED DEFAULT NULL,
        vehicle_type_id       INT UNSIGNED DEFAULT NULL,
        first_booking_only    TINYINT(1)   NOT NULL DEFAULT 0,
        route_specific        TINYINT(1)   NOT NULL DEFAULT 0,
        from_city             VARCHAR(100) NOT NULL DEFAULT '',
        to_city               VARCHAR(100) NOT NULL DEFAULT '',
        user_type             VARCHAR(20)  NOT NULL DEFAULT 'all',
        days_of_week          TEXT         DEFAULT NULL,
        usage_limit           INT          NOT NULL DEFAULT 100,
        per_user_limit        TINYINT      NOT NULL DEFAULT 1,
        used_count            INT          NOT NULL DEFAULT 0,
        total_discount_given  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
        budget_cap            DECIMAL(12,2) DEFAULT NULL,
        valid_from            DATE         DEFAULT NULL,
        valid_to              DATE         DEFAULT NULL,
        start_date            DATE         DEFAULT NULL,
        expiry_date           DATE         DEFAULT NULL,
        is_public             TINYINT(1)   NOT NULL DEFAULT 1,
        is_active             TINYINT(1)   NOT NULL DEFAULT 1,
        created_by            BIGINT UNSIGNED NOT NULL DEFAULT 0,
        created_at            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY code (code)
    ) $c;");

    /*  PROMO USAGE  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_promo_usage (
        id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        promo_id   INT UNSIGNED    NOT NULL,
        user_id    BIGINT UNSIGNED NOT NULL,
        booking_id BIGINT UNSIGNED NOT NULL,
        used_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY promo_id (promo_id),
        KEY user_id (user_id)
    ) $c;");

    /*  RATINGS  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_ratings (
        id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        booking_id BIGINT UNSIGNED NOT NULL,
        rater_id   BIGINT UNSIGNED NOT NULL,
        rated_id   BIGINT UNSIGNED NOT NULL,
        rated_type VARCHAR(20)     NOT NULL DEFAULT 'vendor',
        score      TINYINT         NOT NULL,
        review     TEXT            NOT NULL DEFAULT '',
        created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY booking_id (booking_id),
        KEY rated_id (rated_id)
    ) $c;");

    /*  DRIVER DOCUMENTS  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_driver_docs (
        id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
        vendor_id   INT UNSIGNED NOT NULL,
        doc_type    VARCHAR(50)  NOT NULL,
        file_path   VARCHAR(500) NOT NULL DEFAULT '',
        status      VARCHAR(20)  NOT NULL DEFAULT 'pending',
        expiry_date DATE         DEFAULT NULL,
        notes       TEXT         NOT NULL DEFAULT '',
        verified_by BIGINT UNSIGNED DEFAULT NULL,
        verified_at DATETIME     DEFAULT NULL,
        uploaded_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY vendor_id (vendor_id),
        KEY status (status),
        KEY expiry_date (expiry_date),
        KEY expiry_date_status (expiry_date, status)
    ) $c;");

    /*  SURGE PRICING  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_surge_pricing (
        id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
        vehicle_id  INT UNSIGNED DEFAULT NULL,
        city        VARCHAR(100) DEFAULT NULL,
        zone        VARCHAR(100) DEFAULT NULL,
        from_date   DATE         DEFAULT NULL,
        to_date     DATE         DEFAULT NULL,
        time_from   TIME         DEFAULT NULL,
        time_to     TIME         DEFAULT NULL,
        multiplier  DECIMAL(4,2) NOT NULL DEFAULT 1.00,
        reason      VARCHAR(200) NOT NULL DEFAULT '',
        is_active   TINYINT(1)   NOT NULL DEFAULT 1,
        created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY city_dates (city, from_date, to_date)
    ) $c;");

    /*  OTP TABLE  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_otp (
        id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
        phone       VARCHAR(20)  NOT NULL,
        otp         VARCHAR(6)   NOT NULL,
        otp_plain   VARCHAR(10)  DEFAULT NULL,
        purpose     VARCHAR(30)  NOT NULL DEFAULT 'booking',
        attempts    TINYINT      NOT NULL DEFAULT 0,
        verified    TINYINT(1)   NOT NULL DEFAULT 0,
        verified_at DATETIME     DEFAULT NULL,
        verified_ip VARCHAR(45)  NOT NULL DEFAULT '',
        expires_at  DATETIME     NOT NULL,
        created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY phone (phone),
        KEY expires_at (expires_at)
    ) $c;");

    /*  AUDIT LOG (unified: admin actions, activity, and — via severity —
        elevated/security-relevant events all flow through this single
        table; ridego_security_log below is reserved for high-volume
        raw security telemetry such as every login attempt.)  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_audit_log (
        id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        admin_id   BIGINT UNSIGNED NOT NULL,
        action     VARCHAR(100)    NOT NULL,
        entity     VARCHAR(50)     NOT NULL,
        entity_id  BIGINT UNSIGNED DEFAULT NULL,
        old_value  TEXT            NOT NULL DEFAULT '',
        new_value  TEXT            NOT NULL DEFAULT '',
        severity   VARCHAR(20)     NOT NULL DEFAULT 'info',
        ip_address VARCHAR(45)     NOT NULL DEFAULT '',
        created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY admin_id (admin_id),
        KEY created_at (created_at),
        KEY severity (severity)
    ) $c;");

    /*  SECURITY LOG — raw security telemetry (login attempts, OTP abuse,
        rate-limit trips). Referenced throughout includes/security.php and
        includes/otp.php in the original codebase but never created —
        every security event was silently lost. Fixed here.  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_security_log (
        id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        event_type VARCHAR(50)     NOT NULL,
        identifier VARCHAR(150)    NOT NULL DEFAULT '',
        ip_address VARCHAR(45)     NOT NULL DEFAULT '',
        user_id    BIGINT UNSIGNED DEFAULT NULL,
        details    TEXT            NOT NULL DEFAULT '',
        severity   VARCHAR(20)     NOT NULL DEFAULT 'info',
        created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY event_type (event_type),
        KEY identifier (identifier),
        KEY created_at (created_at)
    ) $c;");

    /*  SETTINGS  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_settings (
        id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
        setting_key   VARCHAR(100) NOT NULL,
        setting_value LONGTEXT     NOT NULL DEFAULT '',
        updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY setting_key (setting_key)
    ) $c;");

    /*  SUBSCRIPTION PLANS  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_subscription_plans (
        id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
        name           VARCHAR(100) NOT NULL,
        price          DECIMAL(8,2) NOT NULL DEFAULT 0.00,
        billing_cycle  VARCHAR(20)  NOT NULL DEFAULT 'monthly',
        wallet_credits DECIMAL(8,2) NOT NULL DEFAULT 0.00,
        lead_discount  DECIMAL(4,2) NOT NULL DEFAULT 0.00,
        priority_boost TINYINT      NOT NULL DEFAULT 0,
        max_leads      INT          NOT NULL DEFAULT 0,
        features       TEXT         NOT NULL DEFAULT '',
        is_active      TINYINT(1)   NOT NULL DEFAULT 1,
        sort_order     INT          NOT NULL DEFAULT 0,
        PRIMARY KEY (id)
    ) $c;");

    /*  VENDOR SUBSCRIPTION BILLING (recurring-billing ledger; see
        includes/subscriptions.php for the purchase/renewal pipeline)  */
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ridego_subscription_billing (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        vendor_id    INT UNSIGNED    NOT NULL,
        plan_id      INT UNSIGNED    NOT NULL,
        amount       DECIMAL(8,2)    NOT NULL DEFAULT 0.00,
        status       VARCHAR(20)     NOT NULL DEFAULT 'pending',
        gateway_ref  VARCHAR(100)    NOT NULL DEFAULT '',
        period_start DATE            DEFAULT NULL,
        period_end   DATE            DEFAULT NULL,
        attempts     TINYINT         NOT NULL DEFAULT 0,
        created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY vendor_id (vendor_id),
        KEY status (status),
        KEY period_end (period_end)
    ) $c;");

    update_option( 'ridego_db_version', RIDEGO_DB_VER );

    /* Run the migration framework immediately after a fresh install so
       ridego_schema_version is recorded even though a brand-new install
       already has the latest columns from the CREATE TABLE statements
       above (every migration step is idempotent and will simply verify
       and skip). This keeps "current schema version" meaningful for
       both fresh installs and upgrades. */
    if ( function_exists( 'ridego_run_migrations' ) ) {
        ridego_run_migrations();
    }
}

/* ============================================================
   CREATE ALL 16 FRONT-END PAGES
   ============================================================ */
function ridego_create_pages() {
    $pages = array(
        array(
            'setting_key' => 'home_page_id',
            'title'       => 'Book Your Cab',
            'slug'        => 'book-cab',
            'content'     => '[ridego_home]',
            'description' => 'Homepage booking widget',
        ),
        array(
            'setting_key' => 'booking_page_id',
            'title'       => 'Book a Cab',
            'slug'        => 'booking',
            'content'     => '[ridego_booking]',
            'description' => 'Full booking form',
        ),
        array(
            'setting_key' => 'search_page_id',
            'title'       => 'Available Cabs',
            'slug'        => 'search-results',
            'content'     => '[ridego_search]',
            'description' => 'Cab search results',
        ),
        array(
            'setting_key' => 'confirm_page_id',
            'title'       => 'Booking Confirmed',
            'slug'        => 'booking-confirm',
            'content'     => '[ridego_confirm]',
            'description' => 'Booking confirmation + payment',
        ),
        array(
            'setting_key' => 'my_trips_page_id',
            'title'       => 'My Bookings',
            'slug'        => 'my-trips',
            'content'     => '[ridego_my_trips]',
            'description' => 'Client dashboard',
        ),
        array(
            'setting_key' => 'track_page_id',
            'title'       => 'Track Your Cab',
            'slug'        => 'track-cab',
            'content'     => '[ridego_track]',
            'description' => 'Live tracking page',
        ),
        array(
            'setting_key' => 'vendor_register_page_id',
            'title'       => 'Join as Driver / Vendor',
            'slug'        => 'become-vendor',
            'content'     => '[ridego_vendor_register]',
            'description' => 'Vendor registration',
        ),
        array(
            'setting_key' => 'vendor_dashboard_page_id',
            'title'       => 'Vendor Dashboard',
            'slug'        => 'vendor-dashboard',
            'content'     => '[ridego_vendor_dashboard]',
            'description' => 'Vendor portal',
        ),
        array(
            'setting_key' => 'contact_page_id',
            'title'       => 'Contact Us',
            'slug'        => 'contact',
            'content'     => '[ridego_contact]',
            'description' => 'Contact page',
        ),
        array(
            'setting_key' => 'about_page_id',
            'title'       => 'About Us',
            'slug'        => 'about',
            'content'     => '[ridego_about]',
            'description' => 'About company',
        ),
        array(
            'setting_key' => 'faq_page_id',
            'title'       => 'FAQs',
            'slug'        => 'faq',
            'content'     => '[ridego_faq]',
            'description' => 'Frequently asked questions',
        ),
        array(
            'setting_key' => 'terms_page_id',
            'title'       => 'Terms and Conditions',
            'slug'        => 'terms',
            'content'     => '[ridego_terms]',
            'description' => 'Terms and conditions',
        ),
        array(
            'setting_key' => 'privacy_page_id',
            'title'       => 'Privacy Policy',
            'slug'        => 'privacy-policy',
            'content'     => '[ridego_privacy]',
            'description' => 'Privacy policy',
        ),
        array(
            'setting_key' => 'cancel_policy_page_id',
            'title'       => 'Cancellation Policy',
            'slug'        => 'cancellation-policy',
            'content'     => '[ridego_cancel_policy]',
            'description' => 'Cancellation policy',
        ),
        array(
            'setting_key' => 'cities_page_id',
            'title'       => 'Cities We Serve',
            'slug'        => 'cities',
            'content'     => '[ridego_cities]',
            'description' => 'City listing',
        ),
        array(
            'setting_key' => 'blog_page_id',
            'title'       => 'Travel Tips and News',
            'slug'        => 'travel-blog',
            'content'     => '[ridego_blog]',
            'description' => 'Blog page',
        ),
    );

    foreach ( $pages as $page ) {
        /* Skip if already exists */
        $existing = ridego_get_setting( $page['setting_key'] );
        if ( $existing && get_post($existing) ) { continue; }

        $existing_by_slug = get_page_by_path( $page['slug'] );
        if ( $existing_by_slug ) {
            ridego_update_setting( $page['setting_key'], $existing_by_slug->ID );
            continue;
        }

        $page_id = wp_insert_post( array(
            'post_title'   => $page['title'],
            'post_name'    => $page['slug'],
            'post_content' => $page['content'],
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_excerpt' => $page['description'],
        ));

        if ( $page_id && ! is_wp_error($page_id) ) {
            ridego_update_setting( $page['setting_key'], $page_id );
        }
    }
}

/* ============================================================
   DEFAULT SETTINGS
   ============================================================ */
function ridego_set_defaults() {
    $defaults = array(
        'platform_name'       => 'RideGo',
        'platform_tagline'    => 'Book Outstation Cabs at Best Prices',
        'currency'            => 'INR',
        'gst_rate'            => '5',
        'booking_advance_hours'=> '2',
        'booking_max_days'    => '90',
        'lead_accept_minutes' => '10',
        'lead_max_vendors'    => '5',
        'lead_cascade_minutes'=> '10',
        'payment_deadline_hours' => '5', // was 2 — customer feedback said the payment window felt too short
        'min_wallet_balance'  => '200',
        'night_hours_start'   => '22:00',
        'night_hours_end'     => '06:00',
        'driver_allowance_night' => '250',
        'cancellation_free_hours'=> '24',
        'admin_email'         => get_option('admin_email'),
        'support_phone'       => '',
        'support_whatsapp'    => '',
        'bank_name'           => '',
        'bank_account'        => '',
        'bank_ifsc'           => '',
        'bank_holder'         => '',
        'upi_id'              => '',
        'upi_qr_url'          => '',
        'telegram_bot_token'  => '',
        'telegram_chat_id'    => '',
        'callmebot_key'       => '',
        'callmebot_phone'     => '',
        'fonnte_token'        => '',
        'google_maps_key'     => '',
        'firebase_api_key'    => '',
        'firebase_project_id' => '',
    );
    foreach ( $defaults as $key => $value ) {
        if ( ridego_get_setting($key) === null ) {
            ridego_update_setting( $key, $value );
        }
    }
}

/* ============================================================
   SEED ALL DATA (calls individual seed files)
   ============================================================ */
function ridego_seed_all_data() {
    $seed_files = array(
        'data/seed-vehicles.php',
        'data/seed-cities.php',
        'data/seed-routes.php',
        'data/seed-content.php',
        'data/seed-promos.php',
        'data/seed-subscription-plans.php',
    );
    foreach ( $seed_files as $file ) {
        $path = RIDEGO_PATH . $file;
        if ( file_exists($path) ) {
            require_once $path;
            $fn = 'ridego_seed_' . str_replace( array('data/seed-','.php','-'), array('','','_'), $file );
            if ( function_exists($fn) ) {
                call_user_func($fn);
            }
        }
    }
}
