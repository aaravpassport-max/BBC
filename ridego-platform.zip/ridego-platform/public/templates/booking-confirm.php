<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   BOOKING CONFIRMATION PAGE TEMPLATE
   Shortcode: [ridego_confirm]
   ============================================================ */

add_shortcode( 'ridego_confirm', 'ridego_shortcode_confirm' );
function ridego_shortcode_confirm( $atts ) {
    ob_start();

    $booking_number = sanitize_text_field( (isset($_GET['booking']) ? $_GET['booking'] : '') );
    if ( ! $booking_number ) {
        echo '<div class="rg-alert rg-alert-error">No booking reference found. <a href="' . esc_url(ridego_page_url('booking_page_id')) . '">Make a new booking</a>.</div>';
        return ob_get_clean();
    }

    $ctx = ridego_get_booking_payment_context( $booking_number );
    if ( ! $ctx ) {
        echo '<div class="rg-alert rg-alert-error">Booking not found. Please check your booking reference.</div>';
        return ob_get_clean();
    }

    $b   = $ctx['booking'];
    $pd  = $ctx['payment_details'];
    $sym = ridego_currency_symbol();

    /*  Determine which view to show  */
    $show_payment_instructions = $ctx['needs_payment'] && $b->payment_method !== 'cash';
    $show_proof_upload         = in_array( $b->status, array('pending_payment','payment_rejected') );
    $show_confirmed            = $ctx['is_confirmed'];
    $show_proof_submitted      = ( $b->status === 'payment_proof_submitted' );
    ?>
    <div class="rg-confirm-wrap" id="rg-confirm-wrap">

        <!-- Shown only if the booking that was just submitted had its promo
             silently corrected server-side (promo exhausted by a
             concurrent booking between the fare preview and the final
             insert) — see ridego_create_booking()'s promo_adjusted flag. -->
        <div id="rg-promo-adjusted-msg" class="rg-alert" style="display:none;background:#fffbeb;border:1px solid #fcd34d;color:#92400e;"></div>
        <script>
        (function(){
            try {
                var reason = sessionStorage.getItem('ridego_promo_adjusted_reason');
                if (reason) {
                    var el = document.getElementById('rg-promo-adjusted-msg');
                    if (el) { el.textContent = reason; el.style.display = 'block'; }
                    sessionStorage.removeItem('ridego_promo_adjusted_reason');
                }
            } catch (e) {}
        })();
        </script>

        <!-- BOOKING NUMBER HEADER -->
        <div class="rg-confirm-header">
            <div class="rg-confirm-icon <?php echo $show_confirmed ? 'rg-icon-success' : ($show_proof_submitted ? 'rg-icon-pending' : 'rg-icon-waiting'); ?>">
                <?php if ($show_confirmed): ?>
                    <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                <?php elseif ($show_proof_submitted): ?>
                    <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                <?php else: ?>
                    <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                <?php endif; ?>
            </div>
            <div class="rg-confirm-heading">
                <?php if ($show_confirmed): ?>
                    <h1>Booking Confirmed!</h1>
                    <p>Your ride has been booked successfully.</p>
                <?php elseif ($show_proof_submitted): ?>
                    <h1>Proof Submitted</h1>
                    <p>We received your payment proof. Verification in progress.</p>
                <?php elseif ($ctx['is_expired']): ?>
                    <h1>Booking Expired</h1>
                    <p>Payment was not received within the deadline. Please rebook.</p>
                <?php else: ?>
                    <h1>Complete Your Payment</h1>
                    <p>Transfer the amount below to confirm your booking.</p>
                <?php endif; ?>
            </div>
            <div class="rg-booking-number-badge">
                <span>Booking Reference</span>
                <strong><?php echo esc_html($b->booking_number); ?></strong>
                <button class="rg-copy-btn" data-copy="<?php echo esc_attr($b->booking_number); ?>">Copy</button>
            </div>
        </div>

        <!-- TRIP SUMMARY CARD -->
        <div class="rg-confirm-grid">
            <div class="rg-confirm-col-main">

                <div class="rg-card">
                    <h3 class="rg-card-title">Trip Details</h3>
                    <div class="rg-trip-summary">
                        <div class="rg-trip-route">
                            <div class="rg-trip-from">
                                <span class="rg-route-dot rg-dot-green"></span>
                                <div>
                                    <div class="rg-route-city"><?php echo esc_html($b->pickup_city); ?></div>
                                    <?php if ($b->pickup_address): ?><div class="rg-route-address"><?php echo esc_html($b->pickup_address); ?></div><?php endif; ?>
                                </div>
                            </div>
                            <div class="rg-route-line"></div>
                            <div class="rg-trip-to">
                                <span class="rg-route-dot rg-dot-red"></span>
                                <div>
                                    <div class="rg-route-city"><?php echo esc_html($b->drop_city ?: 'Local Package'); ?></div>
                                    <?php if ($b->drop_address): ?><div class="rg-route-address"><?php echo esc_html($b->drop_address); ?></div><?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="rg-trip-meta">
                            <div class="rg-meta-item">
                                <span class="rg-meta-label">Trip Type</span>
                                <span class="rg-meta-val"><?php echo esc_html(ridego_trip_type_label($b->trip_type)); ?></span>
                            </div>
                            <div class="rg-meta-item">
                                <span class="rg-meta-label">Date</span>
                                <span class="rg-meta-val"><?php echo esc_html(ridego_format_date($b->journey_date)); ?></span>
                            </div>
                            <div class="rg-meta-item">
                                <span class="rg-meta-label">Time</span>
                                <?php
                                    // DateTime::createFromFormat('H:i', ...) is used instead of
                                    // strtotime()/date() because strtotime() parses a bare "HH:MM"
                                    // string ambiguously across PHP/locale versions (it can be
                                    // read as a relative time expression rather than a clock time);
                                    // createFromFormat pins the exact expected format.
                                    $rg_jt = DateTime::createFromFormat('H:i', $b->journey_time);
                                    echo esc_html($rg_jt ? $rg_jt->format('h:i A') : $b->journey_time);
                                ?>
                            </div>
                            <div class="rg-meta-item">
                                <span class="rg-meta-label">Vehicle</span>
                                <span class="rg-meta-val"><?php echo esc_html($b->vehicle_name ?: 'N/A'); ?></span>
                            </div>
                            <div class="rg-meta-item">
                                <span class="rg-meta-label">Passengers</span>
                                <span class="rg-meta-val"><?php echo esc_html($b->passengers); ?></span>
                            </div>
                            <?php if ($b->distance_km > 0): ?>
                            <div class="rg-meta-item">
                                <span class="rg-meta-label">Distance</span>
                                <span class="rg-meta-val"><?php echo esc_html($b->distance_km); ?> km</span>
                            </div>
                            <?php endif; ?>
                            <?php if ($b->flight_number): ?>
                            <div class="rg-meta-item">
                                <span class="rg-meta-label">Flight No.</span>
                                <span class="rg-meta-val"><?php echo esc_html($b->flight_number); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- FARE BREAKDOWN -->
                <div class="rg-card">
                    <h3 class="rg-card-title">Fare Breakdown</h3>
                    <table class="rg-fare-table">
                        <?php if ($b->base_fare > 0): ?><tr><td>Base Fare</td><td><?php echo $sym.number_format($b->base_fare,2); ?></td></tr><?php endif; ?>
                        <?php if ($b->toll_charges > 0): ?><tr><td>Toll Charges (Est.)</td><td><?php echo $sym.number_format($b->toll_charges,2); ?></td></tr><?php endif; ?>
                        <?php if ($b->parking_charges > 0): ?><tr><td>Parking</td><td><?php echo $sym.number_format($b->parking_charges,2); ?></td></tr><?php endif; ?>
                        <?php if ($b->driver_allowance > 0): ?><tr><td>Driver Allowance</td><td><?php echo $sym.number_format($b->driver_allowance,2); ?></td></tr><?php endif; ?>
                        <?php if ($b->gst_amount > 0): ?><tr><td>GST (5%)</td><td><?php echo $sym.number_format($b->gst_amount,2); ?></td></tr><?php endif; ?>
                        <?php if ($b->discount_amount > 0): ?><tr class="rg-discount-row"><td>Discount (<?php echo esc_html($b->promo_code); ?>)</td><td>- <?php echo $sym.number_format($b->discount_amount,2); ?></td></tr><?php endif; ?>
                        <tr class="rg-total-row"><td><strong>Total Payable</strong></td><td><strong><?php echo $sym.number_format($b->total_fare,2); ?></strong></td></tr>
                        <tr><td>Payment Method</td><td><?php
                            $pm = array('cash'=>'Cash to Driver','manual_bank'=>'Bank Transfer','manual_upi'=>'UPI Transfer','online'=>'Online (Paid)');
                            echo esc_html(isset($pm[$b->payment_method]) ? $pm[$b->payment_method] : ucwords($b->payment_method));
                        ?></td></tr>
                    </table>
                </div>

                <!-- DRIVER INFO (if assigned) -->
                <?php if ($b->vendor_id && $show_confirmed): ?>
                <div class="rg-card rg-driver-card">
                    <h3 class="rg-card-title">Your Driver</h3>
                    <div class="rg-driver-info">
                        <div class="rg-driver-avatar">&#128100;</div>
                        <div class="rg-driver-details">
                            <div class="rg-driver-name"><?php echo esc_html($b->vendor_name ?: 'Driver assigned'); ?></div>
                            <div class="rg-driver-phone">
                                <a href="tel:<?php echo esc_attr($b->vendor_phone); ?>" class="rg-btn rg-btn-sm rg-btn-green">
                                    &#128222; Call Driver
                                </a>
                                <?php if ($b->vendor_whatsapp): ?>
                                <a href="https://wa.me/<?php echo esc_attr(preg_replace('/[^0-9]/','',((isset($b->vendor_whatsapp) ? $b->vendor_whatsapp : '')))); ?>" target="_blank" class="rg-btn rg-btn-sm rg-btn-whatsapp">
                                    WhatsApp
                                </a>
                                <?php endif; ?>
                            </div>
                            <?php if ($b->otp_pickup): ?>
                            <div class="rg-otp-box">
                                <span class="rg-otp-label">Pickup OTP</span>
                                <span class="rg-otp-code"><?php echo esc_html($b->otp_pickup); ?></span>
                                <span class="rg-otp-note">Share with driver at pickup to start trip</span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- PROOF SUBMITTED STATUS -->
                <?php if ($show_proof_submitted): ?>
                <div class="rg-card rg-status-card">
                    <div class="rg-status-pending">
                        <div class="rg-status-icon">&#128338;</div>
                        <h3>Payment Under Verification</h3>
                        <p>We received your payment proof. Our team verifies within 30 minutes during business hours.</p>
                        <p>UTR/Reference: <strong><?php echo esc_html($b->payment_utr); ?></strong></p>
                        <p>Amount Claimed: <strong><?php echo $sym.number_format($b->payment_amount_claimed,2); ?></strong></p>
                    </div>
                </div>
                <?php endif; ?>

                <!-- REJECTION NOTICE -->
                <?php if ($b->status === 'payment_rejected' && $b->payment_rejection_reason): ?>
                <div class="rg-alert rg-alert-error">
                    <strong>Payment Proof Rejected</strong><br>
                    Reason: <?php echo esc_html($b->payment_rejection_reason); ?><br>
                    Please resubmit a clear payment screenshot below.
                </div>
                <?php endif; ?>

            </div><!-- end main col -->

            <!-- RIGHT COLUMN -->
            <div class="rg-confirm-col-side">

                <!-- COUNTDOWN TIMER -->
                <?php if ($show_payment_instructions && $ctx['seconds_left'] > 0): ?>
                <div class="rg-card rg-timer-card">
                    <h3 class="rg-card-title">Pay Within</h3>
                    <div class="rg-countdown" id="rg-countdown" data-seconds="<?php echo esc_attr($ctx['seconds_left']); ?>">
                        <div class="rg-count-unit"><span class="rg-count-num" id="rg-count-h">00</span><span class="rg-count-lbl">HRS</span></div>
                        <div class="rg-count-sep">:</div>
                        <div class="rg-count-unit"><span class="rg-count-num" id="rg-count-m">00</span><span class="rg-count-lbl">MIN</span></div>
                        <div class="rg-count-sep">:</div>
                        <div class="rg-count-unit"><span class="rg-count-num" id="rg-count-s">00</span><span class="rg-count-lbl">SEC</span></div>
                    </div>
                    <p class="rg-timer-note">Booking expires if payment not received by <?php echo date('h:i A, d M',strtotime($b->payment_deadline)); ?></p>
                </div>
                <?php endif; ?>

                <!-- PAYMENT INSTRUCTIONS -->
                <?php if ($show_payment_instructions): ?>
                <div class="rg-card rg-payment-card">
                    <h3 class="rg-card-title">Pay <?php echo $sym.number_format($b->total_fare,2); ?></h3>
                    <div class="rg-pay-important">
                        <strong>Reference/Remarks:</strong>
                        <span class="rg-pay-ref" id="rg-pay-ref"><?php echo esc_html($b->booking_number); ?></span>
                        <button class="rg-copy-btn" data-copy="<?php echo esc_attr($b->booking_number); ?>">Copy</button>
                        <p class="rg-ref-note">You MUST include this in payment remarks</p>
                    </div>

                    <?php if ($pd['upi_id']): ?>
                    <div class="rg-pay-section">
                        <div class="rg-pay-label">UPI / GPay / PhonePe / Paytm</div>
                        <div class="rg-upi-id-box">
                            <span id="rg-upi-id"><?php echo esc_html($pd['upi_id']); ?></span>
                            <button class="rg-copy-btn" data-copy="<?php echo esc_attr($pd['upi_id']); ?>">Copy</button>
                        </div>
                        <?php if ($pd['upi_qr_url']): ?>
                        <div class="rg-qr-wrap">
                            <img src="<?php echo esc_url($pd['upi_qr_url']); ?>" alt="UPI QR Code" class="rg-qr-img">
                            <p class="rg-qr-note">Scan with any UPI app</p>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <?php if ($pd['bank_account']): ?>
                    <div class="rg-pay-section">
                        <div class="rg-pay-label">Bank Transfer (NEFT / IMPS / RTGS)</div>
                        <table class="rg-bank-table">
                            <tr><td>Bank</td><td><strong><?php echo esc_html($pd['bank_name']); ?></strong></td></tr>
                            <tr><td>Account No.</td><td>
                                <span id="rg-acc"><?php echo esc_html($pd['bank_account']); ?></span>
                                <button class="rg-copy-btn" data-copy="<?php echo esc_attr($pd['bank_account']); ?>">Copy</button>
                            </td></tr>
                            <tr><td>IFSC</td><td>
                                <span id="rg-ifsc"><?php echo esc_html($pd['bank_ifsc']); ?></span>
                                <button class="rg-copy-btn" data-copy="<?php echo esc_attr($pd['bank_ifsc']); ?>">Copy</button>
                            </td></tr>
                            <tr><td>Account Holder</td><td><?php echo esc_html($pd['bank_holder']); ?></td></tr>
                            <tr><td>Amount</td><td><strong><?php echo $sym.number_format($b->total_fare,2); ?></strong></td></tr>
                        </table>
                    </div>
                    <?php endif; ?>

                    <!-- CASH OPTION -->
                    <div class="rg-pay-section rg-pay-cash">
                        <div class="rg-pay-label">Pay Cash to Driver</div>
                        <p style="font-size:13px;color:#64748b;margin:4px 0 0;">You can also pay the full amount in cash directly to your driver at the time of pickup.</p>
                    </div>
                </div>
                <?php endif; ?>

                <!-- PROOF UPLOAD -->
                <?php if ($show_proof_upload): ?>
                <div class="rg-card" id="rg-proof-card">
                    <h3 class="rg-card-title">Upload Payment Proof</h3>
                    <p style="font-size:13px;color:#64748b;margin-bottom:14px;">After paying, upload your payment screenshot or receipt here.</p>
                    <form id="rg-proof-form" enctype="multipart/form-data">
                        <input type="hidden" name="booking_id" value="<?php echo esc_attr($b->id); ?>">
                        <div class="rg-field-wrap">
                            <label>Payment Screenshot / Receipt *</label>
                            <div class="rg-upload-area" id="rg-upload-area">
                                <input type="file" name="proof_file" id="rg-proof-file" accept="image/*,.pdf" class="rg-file-hidden">
                                <div class="rg-upload-placeholder" id="rg-upload-placeholder">
                                    <div class="rg-upload-icon">&#128247;</div>
                                    <div>Drag &amp; drop or <span class="rg-upload-link">click to browse</span></div>
                                    <div class="rg-upload-hint">JPG, PNG, PDF  max 2MB</div>
                                </div>
                                <div class="rg-upload-preview" id="rg-upload-preview" style="display:none;">
                                    <img id="rg-preview-img" src="" alt="">
                                    <span id="rg-preview-name"></span>
                                    <button type="button" id="rg-remove-file">&#10005; Remove</button>
                                </div>
                            </div>
                        </div>
                        <div class="rg-field-wrap">
                            <label>Transaction ID / UTR Number *</label>
                            <input type="text" name="utr" id="rg-utr" placeholder="e.g. 423481234567" class="rg-input">
                            <p class="rg-hint">Found in your payment app under transaction details</p>
                        </div>
                        <div class="rg-field-wrap">
                            <label>Payment App Used *</label>
                            <select name="payment_app" id="rg-payment-app" class="rg-input">
                                <option value="">Select App</option>
                                <option value="GPay">Google Pay (GPay)</option>
                                <option value="PhonePe">PhonePe</option>
                                <option value="Paytm">Paytm</option>
                                <option value="BHIM">BHIM UPI</option>
                                <option value="NEFT">NEFT</option>
                                <option value="IMPS">IMPS</option>
                                <option value="RTGS">RTGS</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="rg-field-wrap">
                            <label>Amount Paid *</label>
                            <input type="number" name="amount" value="<?php echo esc_attr($b->total_fare); ?>" step="0.01" class="rg-input" readonly>
                        </div>
                        <div class="rg-field-wrap">
                            <label>Time of Payment</label>
                            <input type="datetime-local" name="payment_time" class="rg-input">
                        </div>
                        <div id="rg-proof-msg" class="rg-msg" style="display:none;"></div>
                        <button type="submit" class="rg-btn rg-btn-primary rg-btn-full" id="rg-proof-submit">
                            Submit Payment Proof
                        </button>
                    </form>
                </div>
                <?php endif; ?>

                <!-- SUPPORT -->
                <div class="rg-card rg-support-card">
                    <h3 class="rg-card-title">Need Help?</h3>
                    <?php $wa = ridego_get_setting('support_whatsapp'); $ph = ridego_get_setting('support_phone'); ?>
                    <?php if ($wa): ?>
                    <a href="https://wa.me/<?php echo esc_attr(preg_replace('/[^0-9]/','',((isset($wa) ? $wa : '')))); ?>?text=<?php echo urlencode('Hi, I need help with booking '.$b->booking_number); ?>" target="_blank" class="rg-btn rg-btn-whatsapp rg-btn-full">
                        WhatsApp Support
                    </a>
                    <?php endif; ?>
                    <?php if ($ph): ?>
                    <a href="tel:<?php echo esc_attr($ph); ?>" class="rg-btn rg-btn-outline rg-btn-full" style="margin-top:8px;">
                        &#128222; Call <?php echo esc_html($ph); ?>
                    </a>
                    <?php endif; ?>
                    <a href="<?php echo esc_url(ridego_page_url('my_trips_page_id')); ?>" class="rg-btn rg-btn-ghost rg-btn-full" style="margin-top:8px;">
                        View My Bookings
                    </a>
                </div>

            </div><!-- end side col -->
        </div><!-- end grid -->
    </div><!-- end confirm wrap -->

    <!-- CONFIRMATION PAGE CSS -->
    <style>
    .rg-confirm-wrap{max-width:1100px;margin:0 auto;padding:24px 16px 48px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;}
    .rg-confirm-header{display:flex;align-items:center;gap:20px;margin-bottom:28px;flex-wrap:wrap;}
    .rg-confirm-icon{width:72px;height:72px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    .rg-icon-success{background:#d1fae5;color:#059669;}
    .rg-icon-pending{background:#fef3c7;color:#d97706;}
    .rg-icon-waiting{background:#eff6ff;color:#3b82f6;}
    .rg-confirm-heading{flex:1;}
    .rg-confirm-heading h1{margin:0 0 4px;font-size:26px;font-weight:800;color:#0f172a;}
    .rg-confirm-heading p{margin:0;color:#64748b;font-size:14px;}
    .rg-booking-number-badge{background:#f8fafc;border:2px solid #e2e8f0;border-radius:12px;padding:12px 20px;text-align:center;}
    .rg-booking-number-badge span{display:block;font-size:11px;color:#94a3b8;font-weight:600;text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px;}
    .rg-booking-number-badge strong{display:block;font-size:22px;font-weight:800;color:#6366f1;letter-spacing:1px;}
    .rg-confirm-grid{display:grid;grid-template-columns:1fr 380px;gap:20px;align-items:start;}
    @media(max-width:900px){.rg-confirm-grid{grid-template-columns:1fr;}}
    .rg-card{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:20px;margin-bottom:16px;box-shadow:0 1px 4px rgba(0,0,0,.06);}
    .rg-card-title{font-size:15px;font-weight:700;color:#0f172a;margin:0 0 14px;padding-bottom:10px;border-bottom:1px solid #f1f5f9;}
    .rg-trip-route{display:flex;flex-direction:column;gap:0;margin-bottom:16px;}
    .rg-trip-from,.rg-trip-to{display:flex;align-items:flex-start;gap:12px;padding:8px 0;}
    .rg-route-line{width:2px;height:28px;background:#e2e8f0;margin-left:7px;}
    .rg-route-dot{width:16px;height:16px;border-radius:50%;flex-shrink:0;margin-top:2px;}
    .rg-dot-green{background:#10b981;} .rg-dot-red{background:#ef4444;}
    .rg-route-city{font-weight:700;font-size:15px;color:#0f172a;}
    .rg-route-address{font-size:12px;color:#64748b;margin-top:2px;}
    .rg-trip-meta{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
    .rg-meta-item{background:#f8fafc;border-radius:8px;padding:10px 12px;}
    .rg-meta-label{display:block;font-size:11px;color:#94a3b8;font-weight:600;text-transform:uppercase;letter-spacing:.05em;margin-bottom:3px;}
    .rg-meta-val{font-size:14px;font-weight:600;color:#0f172a;}
    .rg-fare-table{width:100%;border-collapse:collapse;font-size:14px;}
    .rg-fare-table tr td{padding:8px 0;border-bottom:1px solid #f1f5f9;color:#374151;}
    .rg-fare-table tr td:last-child{text-align:right;font-weight:600;}
    .rg-fare-table tr:last-child td{border-bottom:none;}
    .rg-total-row td{font-size:16px!important;font-weight:800!important;color:#0f172a!important;padding-top:12px!important;border-top:2px solid #e2e8f0!important;}
    .rg-discount-row td{color:#059669!important;}
    .rg-driver-card{background:linear-gradient(135deg,#f0fdf4,#fff);}
    .rg-driver-info{display:flex;gap:16px;align-items:flex-start;}
    .rg-driver-avatar{width:56px;height:56px;background:#d1fae5;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:26px;flex-shrink:0;}
    .rg-driver-name{font-size:16px;font-weight:700;margin-bottom:8px;}
    .rg-driver-phone{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;}
    .rg-otp-box{background:#fef3c7;border:1px solid #fde68a;border-radius:8px;padding:10px 14px;}
    .rg-otp-label{display:block;font-size:11px;font-weight:700;color:#92400e;text-transform:uppercase;margin-bottom:4px;}
    .rg-otp-code{display:block;font-size:28px;font-weight:900;color:#92400e;letter-spacing:6px;margin-bottom:4px;}
    .rg-otp-note{font-size:12px;color:#a16207;}
    .rg-timer-card{background:linear-gradient(135deg,#fef3c7,#fffbeb);}
    .rg-countdown{display:flex;align-items:center;justify-content:center;gap:8px;margin:16px 0;}
    .rg-count-unit{text-align:center;}
    .rg-count-num{display:block;font-size:40px;font-weight:900;color:#d97706;line-height:1;background:#fff;border-radius:8px;padding:8px 16px;min-width:60px;}
    .rg-count-lbl{display:block;font-size:10px;font-weight:700;color:#92400e;margin-top:4px;text-transform:uppercase;}
    .rg-count-sep{font-size:36px;font-weight:900;color:#d97706;margin-top:-16px;}
    .rg-timer-note{text-align:center;font-size:12px;color:#92400e;margin:0;}
    .rg-payment-card{}
    .rg-pay-important{background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;padding:12px 14px;margin-bottom:16px;}
    .rg-pay-important strong{display:block;font-size:12px;font-weight:700;color:#dc2626;margin-bottom:4px;}
    .rg-pay-ref{font-size:18px;font-weight:900;color:#dc2626;letter-spacing:2px;display:block;margin:4px 0;}
    .rg-ref-note{font-size:11px;color:#dc2626;margin:6px 0 0;}
    .rg-pay-section{margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid #f1f5f9;}
    .rg-pay-section:last-child{border-bottom:none;margin-bottom:0;}
    .rg-pay-label{font-size:12px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px;}
    .rg-upi-id-box{display:flex;align-items:center;gap:8px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 14px;font-size:16px;font-weight:700;color:#6366f1;}
    .rg-qr-wrap{text-align:center;margin-top:12px;}
    .rg-qr-img{width:140px;height:140px;border:1px solid #e2e8f0;border-radius:8px;padding:4px;}
    .rg-qr-note{font-size:12px;color:#94a3b8;margin-top:6px;}
    .rg-bank-table{width:100%;font-size:13px;border-collapse:collapse;}
    .rg-bank-table td{padding:6px 0;border-bottom:1px solid #f1f5f9;}
    .rg-bank-table td:first-child{color:#64748b;width:120px;}
    .rg-pay-cash p{font-size:13px;}
    .rg-field-wrap{margin-bottom:14px;}
    .rg-field-wrap label{display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:5px;}
    .rg-input{width:100%;border:1px solid #d1d5db;border-radius:8px;padding:9px 12px;font-size:14px;color:#0f172a;background:#fff;box-sizing:border-box;}
    .rg-input:focus{border-color:#6366f1;box-shadow:0 0 0 3px rgba(99,102,241,.12);outline:none;}
    .rg-hint{font-size:11px;color:#94a3b8;margin:4px 0 0;}
    .rg-upload-area{border:2px dashed #d1d5db;border-radius:10px;position:relative;cursor:pointer;transition:border-color .15s;}
    .rg-upload-area:hover{border-color:#6366f1;}
    .rg-file-hidden{position:absolute;inset:0;width:100%;height:100%;opacity:0;cursor:pointer;}
    .rg-upload-placeholder{padding:24px;text-align:center;color:#64748b;font-size:13px;}
    .rg-upload-icon{font-size:32px;margin-bottom:8px;}
    .rg-upload-link{color:#6366f1;font-weight:600;cursor:pointer;}
    .rg-upload-hint{font-size:11px;color:#94a3b8;margin-top:4px;}
    .rg-upload-preview{padding:12px;display:flex;align-items:center;gap:10px;}
    .rg-upload-preview img{width:48px;height:48px;object-fit:cover;border-radius:6px;border:1px solid #e2e8f0;}
    .rg-copy-btn{background:none;border:1px solid #e2e8f0;border-radius:5px;padding:3px 8px;font-size:11px;cursor:pointer;color:#6366f1;font-weight:600;}
    .rg-copy-btn:hover{background:#eff6ff;}
    .rg-btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:10px 20px;border-radius:8px;font-size:14px;font-weight:600;text-decoration:none;cursor:pointer;border:none;transition:all .15s;font-family:inherit;}
    .rg-btn-primary{background:#6366f1;color:#fff;}
    .rg-btn-primary:hover{background:#4f46e5;}
    .rg-btn-green{background:#10b981;color:#fff;padding:8px 14px;font-size:13px;}
    .rg-btn-whatsapp{background:#25d366;color:#fff;}
    .rg-btn-outline{background:#fff;color:#6366f1;border:1.5px solid #6366f1;}
    .rg-btn-ghost{background:#f8fafc;color:#64748b;border:1px solid #e2e8f0;}
    .rg-btn-sm{padding:6px 12px;font-size:12px;}
    .rg-btn-full{width:100%;margin-top:4px;}
    .rg-alert{padding:14px 16px;border-radius:10px;font-size:13px;margin-bottom:16px;line-height:1.55;}
    .rg-alert-error{background:#fef2f2;border:1px solid #fca5a5;color:#dc2626;}
    .rg-msg{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:10px;}
    .rg-msg-success{background:#f0fdf4;border:1px solid #86efac;color:#166534;}
    .rg-msg-error{background:#fef2f2;border:1px solid #fca5a5;color:#dc2626;}
    .rg-msg-loading{background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;}
    .rg-status-pending{text-align:center;padding:20px;}
    .rg-status-icon{font-size:48px;margin-bottom:12px;}
    .rg-status-pending h3{font-size:18px;font-weight:700;margin:0 0 8px;}
    .rg-status-pending p{color:#64748b;font-size:13px;margin:4px 0;}
    .rg-support-card{}
    </style>

    <script>
    /* Booking number / data for JS */
    var RG_CONFIRM = {
        booking_id    : <?php echo intval($b->id); ?>,
        booking_number: '<?php echo esc_js($b->booking_number); ?>',
        ajax_url      : '<?php echo esc_js(admin_url('admin-ajax.php')); ?>',
        nonce         : '<?php echo esc_js(wp_create_nonce('ridego_nonce')); ?>',
        seconds_left  : <?php echo intval($ctx['seconds_left']); ?>,
    };
    </script>
    <?php
    return ob_get_clean();
}

/*  Register shortcode file  */
add_action('init', function(){
    $templates_dir = RIDEGO_PATH . 'public/templates/';
    $files = array('booking-confirm.php','home.php','booking.php','search-results.php',
                   'my-trips.php','vendor-dashboard.php','become-vendor.php',
                   'static-pages.php','cities.php','track-cab.php');
    foreach ($files as $f) {
        $path = $templates_dir . $f;
        if (file_exists($path) && $path !== __FILE__) {
            require_once $path;
        }
    }
});
