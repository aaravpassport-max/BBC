<?php
if ( ! defined('ABSPATH') ) { exit; }

/* ================================================================
   RIDEGO PREMIUM SHORTCODES v3.0 – MakeMyTrip Level
   ================================================================ */

/* ── Helper: render stars ── */
function ridego_stars_html( $rating, $show_num = true ) {
    $rating = round( floatval($rating) * 2 ) / 2;
    $html = '<span class="rg-stars">';
    for ( $i = 1; $i <= 5; $i++ ) {
        if ( $i <= $rating ) $html .= '<span class="rg-star">★</span>';
        elseif ( $i - 0.5 <= $rating ) $html .= '<span class="rg-star">½</span>';
        else $html .= '<span class="rg-star rg-star-empty">☆</span>';
    }
    $html .= '</span>';
    if ( $show_num ) $html .= '<span class="rg-rating-num">' . number_format($rating,1) . '</span>';
    return $html;
}

/* ── Helper: city emoji ── */
function ridego_city_emoji( $city_name ) {
    $map = [ 'Mumbai'=>'🌊','Delhi'=>'🏛️','Bangalore'=>'🌳','Chennai'=>'🌴','Hyderabad'=>'🕌',
        'Pune'=>'🏔️','Kolkata'=>'🌉','Ahmedabad'=>'🏺','Jaipur'=>'🏯','Goa'=>'🏖️',
        'Agra'=>'🕌','Kochi'=>'⛵','Mysore'=>'🏰','Udaipur'=>'🏰','Manali'=>'⛷️',
        'Rishikesh'=>'🙏','Varanasi'=>'🪔','Amritsar'=>'✨','Shimla'=>'🏔️','Ooty'=>'🌿',
    ];
    return $map[$city_name] ?? '🏙️';
}

/* ================================================================
   HOME PAGE  [ridego_home]
   ================================================================ */
add_shortcode('ridego_home', 'ridego_shortcode_home');
function ridego_shortcode_home($atts) {
    $name        = ridego_get_setting('platform_name', get_bloginfo('name'));
    $tagline     = ridego_get_setting('platform_tagline', 'Safe, Reliable & Affordable Cab Booking Across India');
    $booking_url = ridego_page_url('booking_page_id');
    $vendor_url  = ridego_page_url('vendor_register_page_id');
    $cities      = ridego_get_popular_cities();
    $vehicles    = ridego_get_vehicles();
    $cities_all  = ridego_get_cities();

    /* Dummy reviews for display */
    $reviews = [
        ['Rahul S.','Mumbai → Pune','Delhi','5','Excellent service! Driver was on time and very professional. AC was perfect. Will book again.','+91 98***'],
        ['Priya M.','Jaipur','Rajasthan','5','Best cab service I\'ve used. Transparent pricing, no hidden charges. Driver Mr. Ramesh was great!',''],
        ['Amit K.','Bangalore → Mysore','Karnataka','4','Very comfortable journey. Driver took the best route, avoided traffic. Highly recommended!',''],
    ];
    ob_start(); ?>
<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">

<!-- ====== OFFERS STRIP ====== -->
<div class="rg-offers-strip">
    <div class="rg-wrap">
        <div class="rg-offers-scroll">
            <?php $offers=[
                ['🎉','FIRST10','10% off your first booking'],
                ['✈️','AIRPORT20','₹200 off airport transfers'],
                ['🔄','ROUND15','15% off round trips'],
                ['📅','EARLYBIRD','Book 7 days early — save 12%'],
                ['👥','GROUP5','₹500 off group bookings (6+ pax)'],
                ['🎉','FIRST10','10% off your first booking'],
                ['✈️','AIRPORT20','₹200 off airport transfers'],
                ['🔄','ROUND15','15% off round trips'],
            ]; foreach($offers as $o): ?>
            <div class="rg-offer-item"><span><?php echo $o[0]; ?></span><span class="rg-offer-badge"><?php echo $o[1]; ?></span><span><?php echo $o[2]; ?></span></div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ====== HERO ====== -->
<div class="rg-hero" style="padding:80px 20px 100px;">
    <div class="rg-hero-bg-dots"></div>
    <div class="rg-wrap" style="position:relative;z-index:2;">
        <div style="text-align:center;margin-bottom:48px;">
            <div style="display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:30px;padding:7px 18px;font-size:13px;font-weight:700;color:rgba(255,255,255,.9);margin-bottom:22px;backdrop-filter:blur(4px);">
                <span style="width:8px;height:8px;background:#4ADE80;border-radius:50%;animation:rg-pulse 2s infinite;display:inline-block;"></span>
                Serving <?php echo count($cities_all); ?>+ cities · 10,000+ trips completed
            </div>
            <h1 style="font-size:clamp(34px,5.5vw,62px);font-weight:900;color:#fff;line-height:1.05;letter-spacing:-2px;margin-bottom:18px;">
                <?php echo esc_html($name); ?><br>
                <span style="background:linear-gradient(90deg,#F59E0B,#F97316);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">Book Smarter. Ride Better.</span>
            </h1>
            <p style="font-size:clamp(15px,2vw,19px);color:rgba(255,255,255,.8);max-width:580px;margin:0 auto 36px;line-height:1.65;"><?php echo esc_html($tagline); ?></p>
        </div>

        <!-- SEARCH BOX -->
        <div class="rg-search-box" style="max-width:900px;margin:0 auto;">
            <div class="rg-search-tabs" id="rg-home-tabs">
                <?php $ttypes = ['one_way'=>'🚗 One Way','round_trip'=>'🔄 Round Trip','local'=>'🏙️ Local','airport_pickup'=>'✈️ Airport Pickup','airport_drop'=>'🛫 Airport Drop','outstation'=>'🌄 Outstation']; foreach($ttypes as $v=>$l): ?>
                <div class="rg-search-tab <?php echo $v==='one_way'?'active':''; ?>" data-trip="<?php echo $v; ?>"><?php echo $l; ?></div>
                <?php endforeach; ?>
            </div>

            <form action="<?php echo esc_url($booking_url); ?>" method="GET" id="rg-home-search">
                <input type="hidden" name="trip_type" id="rg-hs-trip" value="one_way">
                <div class="rg-search-row" id="rg-search-row">
                    <div class="rg-search-field">
                        <div class="rg-search-field-label">📍 From</div>
                        <div style="position:relative;">
                            <span class="rg-search-icon">📍</span>
                            <select name="pickup" id="rg-hs-pickup" class="rg-search-input" style="appearance:none;background-image:none;">
                                <option value="">Select Pickup City</option>
                                <?php foreach($cities_all as $c): ?><option value="<?php echo esc_attr($c->name); ?>"><?php echo esc_html($c->name); ?><?php echo !empty($c->state)?', '.esc_html($c->state):''; ?></option><?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="rg-search-field rg-hide-local">
                        <div class="rg-search-field-label">📍 To</div>
                        <div style="position:relative;">
                            <span class="rg-search-icon">🏁</span>
                            <select name="drop" id="rg-hs-drop" class="rg-search-input" style="appearance:none;background-image:none;">
                                <option value="">Select Drop City</option>
                                <?php foreach($cities_all as $c): ?><option value="<?php echo esc_attr($c->name); ?>"><?php echo esc_html($c->name); ?><?php echo !empty($c->state)?', '.esc_html($c->state):''; ?></option><?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="rg-search-field">
                        <div class="rg-search-field-label">📅 Journey Date</div>
                        <div style="position:relative;">
                            <span class="rg-search-icon">📅</span>
                            <input type="date" name="date" id="rg-hs-date" class="rg-search-input" min="<?php echo date('Y-m-d'); ?>" style="padding-left:42px;">
                        </div>
                    </div>
                    <div>
                        <div style="height:28px;"></div>
                        <button type="submit" class="rg-btn rg-btn-accent" style="width:100%;padding:13px 24px;font-size:16px;border-radius:10px;">Search →</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ====== TRUST BAR ====== -->
<div style="background:#fff;border-bottom:1px solid #E5E7EB;padding:0;">
    <div class="rg-wrap">
        <div class="rg-stats-row">
            <?php foreach([['50K+','Happy Travellers'],['500+','Verified Drivers'],['100+','Cities'],['4.8★','Avg Rating'],['₹0','Hidden Charges']] as $s): ?>
            <div class="rg-stat-item">
                <div class="rg-stat-val"><?php echo $s[0]; ?></div>
                <div class="rg-stat-lbl"><?php echo $s[1]; ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ====== TRIP TYPES ====== -->
<div class="rg-section" style="background:#F9FAFB;">
    <div class="rg-wrap">
        <div class="rg-text-center" style="margin-bottom:44px;">
            <span class="rg-overline">Book Your Ride</span>
            <h2 class="rg-h2">Every Kind of Journey, Covered</h2>
            <p class="rg-lead" style="max-width:520px;margin:14px auto 0;">From quick airport transfers to multi-day outstation adventures — we have the right cab for every trip.</p>
        </div>
        <div class="rg-trip-types">
            <?php $types = [
                ['✈️','Airport Transfer','Punctual pickups & drops at all major airports. Flight tracking included.',['background:#DBEAFE'],'/airports/'],
                ['🔄','Round Trip','Same driver for your onward & return journey. Best value for outstation.',['background:#D1FAE5'],'/round-trip/'],
                ['🚗','One Way Cab','Intercity cab at flat per-km rates. Driver returns independently.',['background:#EDE9FE'],'/one-way/'],
                ['🏙️','Local/Hourly','By-the-hour city cab for meetings, shopping, errands.',['background:#FEF3C7'],'/local/'],
                ['🌄','Outstation','Multi-day trips with overnight halt. Driver allowance included.',['background:#FEE2E2'],'/outstation/'],
                ['🏢','Corporate','GST invoice. Monthly packages. Dedicated fleet manager.',['background:#F0FDF4'],'/corporate/'],
            ]; foreach($types as $t): ?>
            <a href="<?php echo esc_url(add_query_arg('trip_type',sanitize_key(strtolower(str_replace(' ','_',$t[1]))),$booking_url)); ?>" class="rg-trip-type-card" style="text-decoration:none;">
                <div class="rg-trip-type-icon" style="<?php echo $t[3][0]; ?>"><?php echo $t[0]; ?></div>
                <div class="rg-trip-type-name"><?php echo $t[1]; ?></div>
                <div class="rg-trip-type-desc"><?php echo $t[2]; ?></div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ====== FLEET SHOWCASE ====== -->
<?php if ($vehicles): ?>
<div class="rg-section">
    <div class="rg-wrap">
        <div class="rg-text-center" style="margin-bottom:44px;">
            <span class="rg-overline">Our Fleet</span>
            <h2 class="rg-h2">Choose the Right Car for Your Trip</h2>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:20px;">
            <?php $car_icons=['hatchback'=>'🚗','sedan'=>'🚙','suv'=>'🚙','innova_crysta'=>'🛻','luxury'=>'🏎️','tempo_traveller'=>'🚌','crysta'=>'🛻'];
            foreach($vehicles as $v): $ic=$car_icons[$v->slug]??'🚕'; $feats=is_string($v->features)?json_decode($v->features,true):($v->features??[]); ?>
            <div class="rg-card rg-card-hover" style="text-align:center;padding:28px 20px;">
                <div style="font-size:52px;margin-bottom:14px;"><?php echo $ic; ?></div>
                <h3 style="font-size:17px;font-weight:800;margin-bottom:6px;"><?php echo esc_html($v->name); ?></h3>
                <div style="display:flex;justify-content:center;gap:12px;font-size:13px;color:#6B7280;margin-bottom:14px;">
                    <span>👥 <?php echo $v->seating_capacity; ?> seats</span>
                    <span>🧳 <?php echo $v->luggage_capacity; ?> bags</span>
                    <?php if($v->ac_available): ?><span>❄️ AC</span><?php endif; ?>
                </div>
                <?php if($feats && is_array($feats)): ?>
                <div class="rg-vehicle-features" style="margin-bottom:14px;">
                    <?php foreach(array_slice($feats,0,3) as $f): ?><span class="rg-vehicle-feature"><?php echo esc_html($f); ?></span><?php endforeach; ?>
                </div>
                <?php endif; ?>
                <div style="font-size:22px;font-weight:900;color:#1A56DB;margin-bottom:4px;">₹<?php echo number_format($v->base_price_per_km,0); ?>/km</div>
                <div style="font-size:12px;color:#9CA3AF;margin-bottom:16px;">Starting price · One-way local</div>
                <a href="<?php echo esc_url(add_query_arg('vehicle',$v->id,$booking_url)); ?>" class="rg-btn rg-btn-outline rg-btn-sm" style="width:100%;justify-content:center;">Book <?php echo esc_html($v->name); ?></a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ====== WHY CHOOSE US ====== -->
<div class="rg-section" style="background:#F9FAFB;">
    <div class="rg-wrap">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:64px;align-items:center;" class="rg-grid-responsive">
            <div>
                <span class="rg-overline">Why <?php echo esc_html( ridego_brand_name() ); ?>?</span>
                <h2 class="rg-h2" style="margin-bottom:20px;">The Smarter Way to Book a Cab in India</h2>
                <?php $feats=[['✅','100% Verified Drivers','Every driver undergoes background checks, KYC verification & document validation before onboarding.'],['💰','Transparent Fixed Pricing','See the complete fare breakdown before you book — base fare, GST, tolls & allowances. No surprises.'],['⚡','Instant Confirmation','Your booking is confirmed in seconds with OTP verification. Driver assigned within 2 hours.'],['📱','Real-time Updates','Get WhatsApp & SMS updates at every step — confirmation, driver assignment, pickup reminder.'],['🆓','Free Cancellation','Cancel up to 24 hours before pickup at absolutely no charge. Full flexibility.'],['📄','GST Invoice','Corporate-ready invoicing for every booking. Hassle-free expense reporting.']]; foreach($feats as $f): ?>
                <div style="display:flex;gap:14px;align-items:flex-start;margin-bottom:18px;">
                    <div style="width:40px;height:40px;background:linear-gradient(135deg,#EBF0FF,#EDE9FE);border:1px solid #C7D2FE;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;"><?php echo $f[0]; ?></div>
                    <div><div style="font-size:14.5px;font-weight:800;color:#111827;margin-bottom:3px;"><?php echo $f[1]; ?></div><div style="font-size:13px;color:#6B7280;line-height:1.55;"><?php echo $f[2]; ?></div></div>
                </div>
                <?php endforeach; ?>
                <div style="margin-top:28px;"><a href="<?php echo esc_url($booking_url); ?>" class="rg-btn rg-btn-primary rg-btn-lg">Book Now — It's Free →</a></div>
            </div>
            <div>
                <div style="background:linear-gradient(135deg,#EBF0FF,#EDE9FE);border-radius:24px;padding:40px;text-align:center;box-shadow:var(--sh2);">
                    <div style="font-size:80px;margin-bottom:20px;">🚗</div>
                    <div style="font-size:36px;font-weight:900;color:#1A56DB;margin-bottom:6px;">4.8 ⭐</div>
                    <div style="font-size:16px;font-weight:700;margin-bottom:4px;">Average Driver Rating</div>
                    <div style="font-size:13px;color:#6B7280;margin-bottom:28px;">Based on 12,400+ verified reviews</div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                        <?php foreach([['98%','On-time Arrivals'],['24/7','Support Available'],['₹0','Hidden Fees'],['2 hr','Avg Driver Assign']] as $m): ?>
                        <div style="background:#fff;border-radius:12px;padding:14px 10px;">
                            <div style="font-size:20px;font-weight:900;color:#1A56DB;"><?php echo $m[0]; ?></div>
                            <div style="font-size:11px;font-weight:700;color:#6B7280;margin-top:3px;"><?php echo $m[1]; ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ====== POPULAR CITIES ====== -->
<?php if ($cities): ?>
<div class="rg-section">
    <div class="rg-wrap">
        <div class="rg-text-center" style="margin-bottom:40px;">
            <span class="rg-overline">Popular Destinations</span>
            <h2 class="rg-h2">Popular Cities We Serve</h2>
            <p class="rg-lead" style="max-width:480px;margin:12px auto 0;">Cab service available in <?php echo count($cities_all); ?>+ cities. Fixed fares, no negotiation.</p>
        </div>
        <div class="rg-city-grid">
            <?php foreach(array_slice($cities,0,12) as $c): $em=ridego_city_emoji($c->name); ?>
            <a href="<?php echo esc_url(add_query_arg('pickup',$c->name,$booking_url)); ?>" class="rg-city-card">
                <span class="rg-city-emoji"><?php echo $em; ?></span>
                <div class="rg-city-name"><?php echo esc_html($c->name); ?></div>
                <?php if(!empty($c->state)): ?><div class="rg-city-state"><?php echo esc_html($c->state); ?></div><?php endif; ?>
                <div class="rg-city-cta">Book Cab →</div>
            </a>
            <?php endforeach; ?>
        </div>
        <div style="text-align:center;margin-top:28px;"><a href="<?php echo esc_url(ridego_page_url('cities_page_id')); ?>" class="rg-btn rg-btn-outline">View All <?php echo count($cities_all); ?> Cities →</a></div>
    </div>
</div>
<?php endif; ?>

<!-- ====== CUSTOMER REVIEWS ====== -->
<div class="rg-section" style="background:#F9FAFB;">
    <div class="rg-wrap">
        <div class="rg-text-center" style="margin-bottom:40px;">
            <span class="rg-overline">Customer Love</span>
            <h2 class="rg-h2">What Our Travellers Say</h2>
        </div>
        <div class="rg-grid-3">
            <?php foreach($reviews as $r): ?>
            <div class="rg-testimonial">
                <div class="rg-reviewer">
                    <div class="rg-reviewer-avatar"><?php echo strtoupper(substr($r[0],0,1)); ?></div>
                    <div>
                        <div class="rg-reviewer-name"><?php echo esc_html($r[0]); ?></div>
                        <div><?php echo ridego_stars_html($r[3]); ?></div>
                    </div>
                </div>
                <p class="rg-review-text"><?php echo esc_html($r[4]); ?></p>
                <div class="rg-review-route">✈️ <?php echo esc_html($r[1]); ?> · <?php echo esc_html($r[2]); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ====== HOW IT WORKS ====== -->
<div class="rg-section">
    <div class="rg-wrap">
        <div class="rg-text-center" style="margin-bottom:44px;">
            <span class="rg-overline">Simple Process</span>
            <h2 class="rg-h2">Book in 3 Easy Steps</h2>
        </div>
        <div class="rg-grid-3">
            <?php foreach([['1','🔍','Enter Your Route','Select pickup/drop cities, trip type, date & time. See instant fare estimate.'],['2','✅','Choose & Confirm','Pick your vehicle, enter contact details, verify OTP. Booking confirmed instantly.'],['3','🚗','Ride in Comfort','Driver assigned within 2 hours. Get WhatsApp updates. Pay at pickup or online.']] as $s): ?>
            <div style="text-align:center;padding:32px 24px;">
                <div style="width:64px;height:64px;background:var(--p-g);border-radius:20px;display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 18px;box-shadow:0 8px 24px rgba(26,86,219,.3);"><?php echo $s[1]; ?></div>
                <div style="display:inline-block;background:#EBF0FF;color:#1A56DB;font-size:12px;font-weight:900;padding:2px 10px;border-radius:20px;margin-bottom:10px;">STEP <?php echo $s[0]; ?></div>
                <h3 style="font-size:18px;font-weight:800;margin-bottom:8px;"><?php echo $s[2]; ?></h3>
                <p style="color:#6B7280;font-size:14px;line-height:1.6;"><?php echo $s[3]; ?></p>
            </div>
            <?php endforeach; ?>
        </div>
        <div style="text-align:center;margin-top:12px;"><a href="<?php echo esc_url($booking_url); ?>" class="rg-btn rg-btn-primary rg-btn-xl">Start Booking Now →</a></div>
    </div>
</div>

<!-- ====== PARTNER CTA ====== -->
<div style="background:linear-gradient(135deg,#0C1445,#1A3A8A,#4F46E5);padding:72px 20px;text-align:center;position:relative;overflow:hidden;">
    <div class="rg-hero-bg-dots"></div>
    <div class="rg-wrap" style="position:relative;z-index:1;">
        <span style="display:inline-block;background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.25);border-radius:30px;padding:6px 18px;font-size:13px;font-weight:700;color:#fff;margin-bottom:18px;">For Drivers & Fleet Owners</span>
        <h2 style="font-size:clamp(26px,4vw,44px);font-weight:900;color:#fff;margin-bottom:14px;letter-spacing:-1px;">Earn ₹1,50,000+ Monthly</h2>
        <p style="font-size:17px;color:rgba(255,255,255,.75);max-width:540px;margin:0 auto 36px;line-height:1.65;">Join our network of verified vendors. Get quality leads, accept on your terms, and grow your cab business.</p>
        <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap;">
            <a href="<?php echo esc_url($vendor_url); ?>" class="rg-btn rg-btn-accent rg-btn-lg">🚗 Register as Vendor</a>
            <a href="<?php echo esc_url(ridego_page_url('about_page_id')); ?>" class="rg-btn rg-btn-ghost rg-btn-lg">Learn More</a>
        </div>
    </div>
</div>

<!-- ====== APP DOWNLOAD TEASER ====== -->
<div class="rg-section-sm">
    <div class="rg-wrap">
        <div style="background:linear-gradient(135deg,#EBF0FF,#EDE9FE);border-radius:20px;padding:40px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:24px;">
            <div>
                <h3 style="font-size:24px;font-weight:900;color:#111827;margin-bottom:8px;">Need Help? Call Us Anytime</h3>
                <p style="color:#6B7280;font-size:15px;margin-bottom:16px;">Our support team is available 24/7 for booking assistance, queries & complaints.</p>
                <div style="display:flex;gap:12px;flex-wrap:wrap;">
                    <?php $phone=ridego_get_setting('support_phone',''); $wa=ridego_get_setting('support_whatsapp',''); ?>
                    <?php if($phone): ?><a href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$phone)); ?>" class="rg-btn rg-btn-primary">📞 <?php echo esc_html($phone); ?></a><?php endif; ?>
                    <?php if($wa): ?><a href="https://wa.me/<?php echo esc_attr(preg_replace('/[^0-9]/','',$wa)); ?>" class="rg-btn rg-btn-white" target="_blank">💬 WhatsApp Us</a><?php endif; ?>
                </div>
            </div>
            <div style="font-size:100px;line-height:1;">📞</div>
        </div>
    </div>
</div>

<style>
@keyframes rg-pulse{0%,100%{opacity:1;transform:scale(1);}50%{opacity:.7;transform:scale(1.3);}}
@media(max-width:768px){
  .rg-grid-responsive{grid-template-columns:1fr !important;}
  .rg-search-row{grid-template-columns:1fr !important;}
}
</style>
<script<?php echo function_exists( 'ridego_csp_script_nonce' ) ? ' nonce="' . esc_attr( ridego_csp_script_nonce() ) . '"' : ''; ?>>
(function($){
    $(document).on('click','.rg-search-tab',function(){
        $('.rg-search-tab').removeClass('active');$(this).addClass('active');
        var t=$(this).data('trip'); $('#rg-hs-trip').val(t);
        $('.rg-hide-local').toggle(t!=='local');
    });
})(jQuery);
</script>
</div>
<?php return ob_get_clean(); }

/* ================================================================
   CITIES PAGE  [ridego_cities]
   ================================================================ */
add_shortcode('ridego_cities', 'ridego_shortcode_cities');
function ridego_shortcode_cities($atts) {
    $cities = ridego_get_cities();
    $booking_url = ridego_page_url('booking_page_id');
    if (!$cities) return '<div class="rg-alert rg-alert-info">Cities are being loaded. Please refresh.</div>';

    /* Group by state */
    $by_state = [];
    foreach($cities as $c) { $state = !empty($c->state)?$c->state:'Other'; $by_state[$state][] = $c; }
    ksort($by_state);

    ob_start(); ?>
<div class="rg-wrap" style="padding:32px 20px 64px;">
    <div class="rg-breadcrumb"><a href="<?php echo home_url(); ?>">Home</a><span class="rg-breadcrumb-sep">›</span><span class="rg-breadcrumb-current">Cities We Serve</span></div>
    <div style="text-align:center;padding:28px 0 44px;">
        <span class="rg-overline">Our Network</span>
        <h1 class="rg-h1" style="margin-bottom:14px;">Cab Service in <?php echo count($cities); ?>+ Cities</h1>
        <p class="rg-lead" style="max-width:520px;margin:0 auto;">Intercity, local & airport cabs at fixed fares. Verified drivers. Instant confirmation.</p>
    </div>

    <!-- Quick search -->
    <div style="max-width:480px;margin:0 auto 44px;position:relative;">
        <span style="position:absolute;left:14px;top:50%;transform:translateY(-50%);font-size:18px;">🔍</span>
        <input type="text" id="rg-city-search" class="rg-input" placeholder="Search city..." style="padding-left:46px;font-size:16px;border-radius:12px;">
    </div>

    <?php foreach($by_state as $state=>$state_cities): ?>
    <div class="rg-state-section" data-state="<?php echo esc_attr($state); ?>" style="margin-bottom:40px;">
        <h2 style="font-size:18px;font-weight:800;color:#111827;margin-bottom:16px;padding-bottom:10px;border-bottom:2px solid #E5E7EB;display:flex;align-items:center;gap:8px;">
            <span style="width:4px;height:20px;background:linear-gradient(180deg,#1A56DB,#7C3AED);border-radius:2px;display:inline-block;"></span>
            <?php echo esc_html($state); ?> <span style="font-size:13px;font-weight:500;color:#9CA3AF;">(<?php echo count($state_cities); ?> cities)</span>
        </h2>
        <div class="rg-city-grid">
            <?php foreach($state_cities as $c): $em=ridego_city_emoji($c->name); ?>
            <a href="<?php echo esc_url(add_query_arg('pickup',$c->name,$booking_url)); ?>" class="rg-city-card rg-city-item" data-city="<?php echo esc_attr(strtolower($c->name)); ?>">
                <span class="rg-city-emoji"><?php echo $em; ?></span>
                <div class="rg-city-name"><?php echo esc_html($c->name); ?></div>
                <div class="rg-city-state"><?php echo esc_html($state); ?></div>
                <div class="rg-city-cta">Book Cab →</div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<script<?php echo function_exists( 'ridego_csp_script_nonce' ) ? ' nonce="' . esc_attr( ridego_csp_script_nonce() ) . '"' : ''; ?>>
(function(){
    var inp=document.getElementById('rg-city-search');
    if(!inp)return;
    inp.addEventListener('input',function(){
        var q=this.value.toLowerCase().trim();
        document.querySelectorAll('.rg-city-item').forEach(function(el){
            el.style.display=(!q||el.dataset.city.includes(q))?'':'none';
        });
        document.querySelectorAll('.rg-state-section').forEach(function(sec){
            var visible=sec.querySelectorAll('.rg-city-item:not([style*="none"])').length;
            sec.style.display=visible?'':'none';
        });
    });
})();
</script>
<?php return ob_get_clean(); }

/* ================================================================
   BOOKING FORM  [ridego_booking]
   ================================================================ */
add_shortcode('ridego_booking', 'ridego_shortcode_booking');
function ridego_shortcode_booking($atts) {
    $vehicles    = ridego_get_vehicles();
    $cities      = ridego_get_cities();
    $sym         = ridego_currency_symbol();
    $prefill_pu  = isset($_GET['pickup']) ? sanitize_text_field($_GET['pickup']) : '';
    $prefill_dr  = isset($_GET['drop'])   ? sanitize_text_field($_GET['drop'])   : '';
    $prefill_tt  = isset($_GET['trip_type']) ? sanitize_key($_GET['trip_type'])   : 'one_way';
    $prefill_dt  = isset($_GET['date'])   ? sanitize_text_field($_GET['date'])   : '';
    ob_start(); ?>
<div class="rg-booking-page">
    <div class="rg-breadcrumb"><a href="<?php echo home_url(); ?>">Home</a><span class="rg-breadcrumb-sep">›</span><span class="rg-breadcrumb-current">Book a Cab</span></div>

    <!-- Step indicator -->
    <div class="rg-stepper" style="margin-bottom:28px;">
        <div class="rg-step active"><div class="rg-step-dot">1</div></div>
        <div class="rg-step-line"></div>
        <div class="rg-step"><div class="rg-step-dot">2</div></div>
        <div class="rg-step-line"></div>
        <div class="rg-step"><div class="rg-step-dot">3</div></div>
        <div class="rg-step-line"></div>
        <div class="rg-step"><div class="rg-step-dot">4</div></div>
    </div>

    <!-- Trip tabs -->
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:24px;" id="rg-trip-tabs">
        <?php $tt=['one_way'=>'🚗 One Way','round_trip'=>'🔄 Round Trip','local'=>'🏙️ Local','airport_pickup'=>'✈️ Airport Pickup','airport_drop'=>'🛫 Airport Drop','outstation'=>'🌄 Outstation'];
        foreach($tt as $v=>$l): ?>
        <div class="rg-search-tab <?php echo $v===$prefill_tt?'active':''; ?>" data-trip="<?php echo $v; ?>"><?php echo $l; ?></div>
        <?php endforeach; ?>
    </div>
    <input type="hidden" id="rg_trip_type" value="<?php echo esc_attr($prefill_tt); ?>">

    <form id="rg-booking-form">
        <?php wp_nonce_field('ridego_booking_nonce','rg_nonce'); ?>
        <div class="rg-booking-layout">
        <div>

        <!-- SECTION 1: Route -->
        <div class="rg-form-section">
            <div class="rg-form-section-hd"><div class="rg-form-section-num">1</div><div class="rg-form-section-title">Route & Schedule</div></div>
            <div class="rg-form-grid-2">
                <div class="rg-field">
                    <label class="rg-label">Pickup City <span class="req">*</span></label>
                    <div class="rg-input-icon-wrap">
                        <span class="rg-input-icon">📍</span>
                        <select name="pickup_city" id="rg_pickup_city" class="rg-input rg-select" required>
                            <option value="">Select pickup city</option>
                            <?php foreach($cities as $c): ?><option value="<?php echo esc_attr($c->name); ?>" <?php selected($prefill_pu,$c->name); ?>><?php echo esc_html($c->name); ?><?php echo !empty($c->state)?', '.$c->state:''; ?></option><?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="rg-field rg-hide-local">
                    <label class="rg-label">Drop City <span class="req">*</span></label>
                    <div class="rg-input-icon-wrap">
                        <span class="rg-input-icon">🏁</span>
                        <select name="drop_city" id="rg_drop_city" class="rg-input rg-select">
                            <option value="">Select drop city</option>
                            <?php foreach($cities as $c): ?><option value="<?php echo esc_attr($c->name); ?>" <?php selected($prefill_dr,$c->name); ?>><?php echo esc_html($c->name); ?><?php echo !empty($c->state)?', '.$c->state:''; ?></option><?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="rg-field rg-show-airport" style="display:none;">
                    <label class="rg-label">Terminal / Hotel Address</label>
                    <input type="text" name="pickup_address" class="rg-input" placeholder="Terminal 2 / Taj Hotel, Connaught Place...">
                </div>
                <div class="rg-field">
                    <label class="rg-label">Journey Date <span class="req">*</span></label>
                    <div class="rg-input-icon-wrap">
                        <span class="rg-input-icon">📅</span>
                        <input type="date" name="journey_date" id="rg_journey_date" class="rg-input" required min="<?php echo date('Y-m-d'); ?>" value="<?php echo esc_attr($prefill_dt); ?>" style="padding-left:42px;">
                    </div>
                </div>
                <div class="rg-field">
                    <label class="rg-label">Pickup Time <span class="req">*</span></label>
                    <div class="rg-input-icon-wrap">
                        <span class="rg-input-icon">🕐</span>
                        <input type="time" name="journey_time" id="rg_journey_time" class="rg-input" value="08:00" required style="padding-left:42px;">
                    </div>
                </div>
                <div class="rg-field rg-show-roundtrip" style="display:none;">
                    <label class="rg-label">Return Date</label>
                    <div class="rg-input-icon-wrap">
                        <span class="rg-input-icon">🔄</span>
                        <input type="date" name="return_date" class="rg-input" style="padding-left:42px;">
                    </div>
                </div>
                <div class="rg-field rg-show-local" style="display:none;">
                    <label class="rg-label">Hours Required</label>
                    <select name="hours_required" class="rg-input rg-select">
                        <option value="4">4 Hours / 40 km (Standard)</option>
                        <option value="8">8 Hours / 80 km (Full Day)</option>
                        <option value="12">12 Hours / 120 km (Extended)</option>
                        <option value="24">24 Hours / 200 km (Day & Night)</option>
                    </select>
                </div>
                <div class="rg-field">
                    <label class="rg-label">Passengers</label>
                    <select name="passengers" id="rg_passengers" class="rg-input rg-select">
                        <?php for($i=1;$i<=8;$i++): ?><option value="<?php echo $i; ?>"><?php echo $i; ?> Passenger<?php echo $i>1?'s':''; ?></option><?php endfor; ?>
                    </select>
                </div>
                <div class="rg-field rg-show-airport" style="display:none;">
                    <label class="rg-label">Flight Number</label>
                    <input type="text" name="flight_number" class="rg-input" placeholder="6E 202 / AI 101">
                </div>
            </div>
        </div>

        <!-- SECTION 2: Vehicle -->
        <div class="rg-form-section">
            <div class="rg-form-section-hd"><div class="rg-form-section-num">2</div><div class="rg-form-section-title">Select Your Vehicle</div></div>
            <?php if($vehicles): ?>
            <div class="rg-vehicles-grid" id="rg-vehicles">
                <?php $car_icons=['hatchback'=>'🚗','sedan'=>'🚙','suv'=>'🚙','innova_crysta'=>'🛻','luxury'=>'🏎️','tempo_traveller'=>'🚌','crysta'=>'🛻'];
                foreach($vehicles as $v):
                    $ic=$car_icons[$v->slug]??'🚕';
                    $feats=is_string($v->features)?json_decode($v->features,true):[];
                ?>
                <label class="rg-vehicle" data-vid="<?php echo $v->id; ?>">
                    <input type="radio" name="vehicle_type_id" value="<?php echo $v->id; ?>">
                    <span class="rg-vehicle-icon"><?php echo $ic; ?></span>
                    <div class="rg-vehicle-name"><?php echo esc_html($v->name); ?></div>
                    <div class="rg-vehicle-seats">👥 <?php echo $v->seating_capacity; ?> &bull; 🧳 <?php echo $v->luggage_capacity; ?><?php echo $v->ac_available?' &bull; ❄️ AC':''; ?></div>
                    <div class="rg-vehicle-rate" id="rg-vp-<?php echo $v->id; ?>">₹<?php echo number_format($v->base_price_per_km,0); ?>/km</div>
                    <?php if($feats): ?><div class="rg-vehicle-features"><?php foreach(array_slice($feats,0,2) as $f): ?><span class="rg-vehicle-feature"><?php echo esc_html($f); ?></span><?php endforeach; ?></div><?php endif; ?>
                </label>
                <?php endforeach; ?>
            </div>
            <!-- Fare box -->
            <div class="rg-fare-box" id="rg-fare-box">
                <div class="rg-fare-total" id="rg-fare-total">₹0</div>
                <div class="rg-fare-sub">Estimated total fare · All inclusive</div>
                <div id="rg-fare-breakdown"></div>
                <div id="rg-promo-discount-row" style="display:none;" class="rg-fare-row"><span>🎉 Promo Discount</span><span class="rg-fare-discount" id="rg-promo-disc-amt"></span></div>
            </div>
            <?php else: ?>
            <div class="rg-alert rg-alert-warning">⚠️ No vehicles found. Go to <strong>RideGo → Tools → Re-Seed Data</strong>.</div>
            <?php endif; ?>
        </div>

        <!-- SECTION 3: Contact -->
        <div class="rg-form-section">
            <div class="rg-form-section-hd"><div class="rg-form-section-num">3</div><div class="rg-form-section-title">Your Details</div></div>
            <div class="rg-form-grid-2">
                <div class="rg-field">
                    <label class="rg-label">Full Name <span class="req">*</span></label>
                    <input type="text" name="client_name" class="rg-input" placeholder="As per ID card" required>
                </div>
                <div class="rg-field">
                    <label class="rg-label">Mobile Number <span class="req">*</span></label>
                    <input type="tel" name="client_phone" id="rg_client_phone" class="rg-input" placeholder="+91 98765 43210" required>
                </div>
                <div class="rg-field rg-span-2">
                    <label class="rg-label">Email Address</label>
                    <input type="email" name="client_email" class="rg-input" placeholder="you@email.com (for booking confirmation)">
                </div>
                <div class="rg-field rg-span-2">
                    <label class="rg-label">Special Requests</label>
                    <input type="text" name="special_requests" class="rg-input" placeholder="Child seat, AC preference, extra luggage, meeting time...">
                </div>
            </div>
        </div>

        <!-- SECTION 4: Promo & Payment -->
        <div class="rg-form-section">
            <div class="rg-form-section-hd"><div class="rg-form-section-num">4</div><div class="rg-form-section-title">Promo Code & Payment</div></div>
            <div class="rg-field" style="max-width:420px;">
                <label class="rg-label">Have a Promo Code?</label>
                <div class="rg-promo-wrap">
                    <input type="text" name="promo_code" id="rg_promo_code" class="rg-input" placeholder="ENTER CODE" style="text-transform:uppercase;letter-spacing:1.5px;font-weight:700;">
                    <button type="button" id="rg-apply-promo" class="rg-btn rg-btn-outline" style="flex-shrink:0;padding:13px 20px;">Apply</button>
                </div>
                <div id="rg-promo-msg"></div>
            </div>
            <div class="rg-field">
                <label class="rg-label">Payment Method</label>
                <div class="rg-pay-methods">
                    <div class="rg-pay-method active" data-method="bank_transfer"><span class="rg-pay-icon">🏦</span><div class="rg-pay-name">Bank Transfer / UPI</div></div>
                    <?php if(ridego_get_setting('razorpay_key_id')): ?><div class="rg-pay-method" data-method="razorpay"><span class="rg-pay-icon">💳</span><div class="rg-pay-name">Pay Online</div></div><?php endif; ?>
                    <div class="rg-pay-method" data-method="cash"><span class="rg-pay-icon">💵</span><div class="rg-pay-name">Cash at Pickup</div></div>
                </div>
                <input type="hidden" name="payment_method" id="rg_payment_method" value="bank_transfer">
            </div>
        </div>

        <div id="rg-booking-error" class="rg-alert rg-alert-error" style="display:none;"></div>
        <button type="submit" id="rg-submit-btn" class="rg-btn rg-btn-primary rg-btn-xl rg-btn-full">🔒 Confirm Booking</button>
        <p style="text-align:center;font-size:12.5px;color:#9CA3AF;margin-top:12px;">OTP verification required to confirm · Cancel free 24h before pickup</p>

        </div><!-- /left -->

        <!-- SIDEBAR -->
        <div class="rg-booking-sidebar">
            <div class="rg-summary-card">
                <h3>Booking Summary</h3>
                <div id="rg-sidebar-summary" style="font-size:13px;opacity:.7;font-style:italic;">Select route & vehicle to preview.</div>
            </div>
            <div class="rg-trust-box">
                <div style="font-size:13px;font-weight:800;color:#065F46;margin-bottom:10px;">✅ Why Book With Us?</div>
                <?php foreach(['Free cancellation up to 24h before','Driver assigned within 2 hours','WhatsApp & SMS updates','Verified KYC-approved drivers','GST invoice on request','No hidden charges'] as $p): ?>
                <div class="rg-trust-item">✓ <?php echo $p; ?></div>
                <?php endforeach; ?>
            </div>
            <!-- Active offers -->
            <?php global $wpdb; $active_promos=$wpdb->get_results("SELECT * FROM {$wpdb->prefix}ridego_promo_codes WHERE is_active=1 AND valid_until>=CURDATE() LIMIT 3"); if($active_promos): ?>
            <div style="background:#fff;border:1.5px solid #E5E7EB;border-radius:14px;padding:18px;margin-top:14px;box-shadow:var(--sh1);">
                <div style="font-size:13px;font-weight:800;color:#111827;margin-bottom:12px;">🎉 Available Offers</div>
                <?php foreach($active_promos as $pr): ?>
                <div style="background:linear-gradient(135deg,#FFF7ED,#FFFBEB);border:1px solid #FED7AA;border-radius:10px;padding:12px;margin-bottom:8px;cursor:pointer;" onclick="document.getElementById('rg_promo_code').value='<?php echo esc_js($pr->code); ?>';">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <code style="font-size:14px;font-weight:900;color:#92400E;background:#FEF3C7;padding:3px 10px;border-radius:6px;"><?php echo esc_html($pr->code); ?></code>
                        <span style="font-size:12px;color:#059669;font-weight:700;"><?php echo $pr->discount_type==='percent'?$pr->discount_value.'% OFF':'₹'.number_format($pr->discount_value,0).' OFF'; ?></span>
                    </div>
                    <?php if($pr->description): ?><div style="font-size:12px;color:#6B7280;margin-top:5px;"><?php echo esc_html($pr->description); ?></div><?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        </div><!-- /layout -->
    </form>
</div>

<!-- OTP Modal -->
<div class="rg-modal-overlay" id="rg-otp-overlay">
    <div class="rg-modal">
        <div class="rg-otp-icon">📱</div>
        <h3 style="font-size:22px;font-weight:900;margin-bottom:8px;">Verify Your Number</h3>
        <p style="font-size:14px;color:#6B7280;margin-bottom:4px;">6-digit OTP sent to <strong id="rg-otp-phone" style="color:#111827;"></strong></p>
        <div class="rg-otp-digits">
            <input type="text" maxlength="1" class="rg-otp-digit" inputmode="numeric" autocomplete="one-time-code">
            <input type="text" maxlength="1" class="rg-otp-digit" inputmode="numeric">
            <input type="text" maxlength="1" class="rg-otp-digit" inputmode="numeric">
            <input type="text" maxlength="1" class="rg-otp-digit" inputmode="numeric">
            <input type="text" maxlength="1" class="rg-otp-digit" inputmode="numeric">
            <input type="text" maxlength="1" class="rg-otp-digit" inputmode="numeric">
        </div>
        <button id="rg-verify-otp" class="rg-btn rg-btn-primary rg-btn-full" style="padding:16px;font-size:16px;border-radius:12px;">Verify &amp; Confirm Booking</button>
        <div id="rg-otp-err" class="rg-alert rg-alert-error" style="display:none;margin-top:12px;"></div>
        <p style="font-size:13px;color:#9CA3AF;margin-top:14px;">Didn't receive it? <a href="#" id="rg-resend-otp" style="color:var(--p);font-weight:700;">Resend OTP</a></p>
    </div>
</div>

<script<?php echo function_exists( 'ridego_csp_script_nonce' ) ? ' nonce="' . esc_attr( ridego_csp_script_nonce() ) . '"' : ''; ?>>
(function($){
var tripType='<?php echo esc_js($prefill_tt); ?>',selVehicle=0,fareData={},promoDisc=0;
var ajaxUrl='<?php echo admin_url('admin-ajax.php'); ?>',sym='<?php echo esc_js($sym); ?>';
var confirmUrl='<?php echo esc_js(ridego_page_url('confirm_page_id')); ?>';
/* Root-cause fix: this legacy shortcode form is a completely separate
 * booking entry point from the React app (submits to the
 * 'ridego_submit_booking'/'ridego_send_otp' AJAX actions in
 * public/ajax/booking-ajax.php, not the /app/bookings REST route). Its
 * submit handler used to unconditionally send an OTP and pop the OTP
 * modal before ever calling submitBooking(), regardless of the admin's
 * "Require OTP to confirm booking" toggle — so disabling otp_enabled in
 * Settings had no effect on this form even though the PHP backend
 * (ridego_ajax_submit_booking() -> ridego_booking_requires_otp()) already
 * respected the setting correctly. otpEnabled below mirrors the exact
 * same setting the backend checks, read server-side at render time, so
 * this form now skips the OTP step entirely when it's off and goes
 * straight to submitBooking() — matching the React app's behavior.
 */
var otpEnabled=<?php echo ( (int) ridego_get_setting('otp_enabled', 1) === 1 ) ? 'true' : 'false'; ?>;

/* Trip tabs */
$(document).on('click','.rg-search-tab[data-trip]',function(){
    $('.rg-search-tab[data-trip]').removeClass('active');$(this).addClass('active');
    tripType=$(this).data('trip');$('#rg_trip_type').val(tripType);
    var isAir=tripType==='airport_pickup'||tripType==='airport_drop';
    var isLoc=tripType==='local';
    $('.rg-show-roundtrip').toggle(tripType==='round_trip');
    $('.rg-show-local').toggle(isLoc);
    $('.rg-show-airport').toggle(isAir);
    $('.rg-hide-local').toggle(!isLoc);
    recalc();
});

/* Vehicle select */
$(document).on('click','.rg-vehicle',function(){
    $('.rg-vehicle').removeClass('selected');$(this).addClass('selected');
    $(this).find('input[type=radio]').prop('checked',true);
    selVehicle=parseInt($(this).data('vid'));recalc();
});

/* Payment method */
$(document).on('click','.rg-pay-method',function(){
    $('.rg-pay-method').removeClass('active');$(this).addClass('active');
    $('#rg_payment_method').val($(this).data('method'));
});

/* Auto recalc */
$(document).on('change','#rg_pickup_city,#rg_drop_city,#rg_journey_date,#rg_journey_time,#rg_passengers,[name=hours_required]',recalc);

function fmt(n){return sym+parseFloat(n).toLocaleString('en-IN',{minimumFractionDigits:0,maximumFractionDigits:0});}

function recalc(){
    if(!selVehicle)return;
    $.post(ajaxUrl,{action:'ridego_calc_fare',rg_nonce:$('#rg_nonce').val(),
        trip_type:tripType,pickup_city:$('#rg_pickup_city').val(),drop_city:$('#rg_drop_city').val(),
        vehicle_type_id:selVehicle,journey_date:$('#rg_journey_date').val(),
        journey_time:$('#rg_journey_time').val(),passengers:$('#rg_passengers').val(),
        hours_required:$('[name=hours_required]').val()||4,return_date:$('[name=return_date]').val()||''},
    function(r){
        if(!r.success)return;
        fareData=r.data;
        var total=fareData.total_fare||0;
        var discounted=promoDisc>0?Math.max(0,total-promoDisc):total;
        $('#rg-fare-total').text(fmt(discounted));
        var bk='';
        if(fareData.breakdown)$.each(fareData.breakdown,function(k,v){bk+='<div class="rg-fare-row"><span>'+k+'</span><span>'+fmt(v)+'</span></div>';});
        bk+='<div class="rg-fare-row"><span>Total Fare</span><span>'+fmt(discounted)+'</span></div>';
        $('#rg-fare-breakdown').html(bk);$('#rg-fare-box').addClass('show');
        if(promoDisc>0){$('#rg-promo-discount-row').show();$('#rg-promo-disc-amt').text('-'+fmt(promoDisc));}
        // Update sidebar
        var pu=$('#rg_pickup_city').val(),dr=$('#rg_drop_city').val();
        var s='<div class="rg-summary-row"><span class="rg-summary-label">Route</span><span class="rg-summary-val">'+pu+(dr?' → '+dr:'')+'</span></div>';
        s+='<div class="rg-summary-row"><span class="rg-summary-label">Type</span><span class="rg-summary-val">'+$('.rg-search-tab[data-trip].active').text().trim()+'</span></div>';
        s+='<div class="rg-summary-row"><span class="rg-summary-label">Date</span><span class="rg-summary-val">'+$('#rg_journey_date').val()+'</span></div>';
        s+='<div class="rg-summary-row"><span class="rg-summary-label">Time</span><span class="rg-summary-val">'+$('#rg_journey_time').val()+'</span></div>';
        s+='<div class="rg-summary-row"><span class="rg-summary-label">Fare</span><span class="rg-summary-val">'+fmt(discounted)+'</span></div>';
        $('#rg-sidebar-summary').html(s);
    });
}

/* Promo */
$('#rg-apply-promo').on('click',function(){
    var code=$('#rg_promo_code').val().trim();if(!code)return;
    $.post(ajaxUrl,{action:'ridego_validate_promo',code:code,amount:fareData.total_fare||0,trip_type:tripType,nonce:$('#rg_nonce').val()},function(r){
        if(r.success){
            promoDisc=r.data.discount||0;
            $('#rg-promo-msg').html('<div class="rg-promo-applied">🎉 '+r.data.message+' <span class="rg-promo-save">Save '+fmt(promoDisc)+'!</span></div>');
            recalc();
        }else{$('#rg-promo-msg').html('<div class="rg-alert rg-alert-error" style="padding:8px 12px;font-size:13px;margin-top:6px;">❌ '+(r.data?r.data.message:'Invalid code.')+'</div>');}
    });
});

/* Submit → OTP */
$('#rg-booking-form').on('submit',function(e){
    e.preventDefault();
    if(!selVehicle){showErr('Please select a vehicle to continue.');return;}
    var ph=$('#rg_client_phone').val().trim();
    if(!ph){showErr('Mobile number is required.');return;}
    $('#rg-booking-error').hide();
    if(!otpEnabled){submitBooking();return;}
    $('#rg-submit-btn').prop('disabled',true).html('<span class="rg-spinner"></span> Sending OTP...');
    $.post(ajaxUrl,{action:'ridego_send_otp',phone:ph,purpose:'booking',nonce:$('#rg_nonce').val()},function(r){
        if(r.success){
            if(r.data&&r.data.trusted){submitBooking();return;}
            $('#rg-otp-phone').text(ph);$('#rg-otp-overlay').addClass('show');$('.rg-otp-digit').first().focus();
        }
        else{showErr('Could not send OTP: '+(r.data&&r.data.message?r.data.message:'Please try again.'));}
        $('#rg-submit-btn').prop('disabled',false).html('🔒 Confirm Booking');
    });
});

/* OTP digits */
$(document).on('keyup','.rg-otp-digit',function(e){
    var $a=$('.rg-otp-digit'),i=$a.index(this);
    if($(this).val()&&i<$a.length-1)$a.eq(i+1).focus();
    if(e.key==='Backspace'&&!$(this).val()&&i>0)$a.eq(i-1).focus();
});

/* OTP verify */
$('#rg-verify-otp').on('click',function(){
    var otp='';$('.rg-otp-digit').each(function(){otp+=$(this).val();});
    if(otp.length<6){$('#rg-otp-err').text('Please enter all 6 digits.').show();return;}
    $(this).prop('disabled',true).html('<span class="rg-spinner"></span> Verifying...');
    $.post(ajaxUrl,{action:'ridego_verify_otp',phone:$('#rg_client_phone').val(),otp:otp,purpose:'booking',nonce:$('#rg_nonce').val()},function(r){
        if(r.success){$('#rg-otp-overlay').removeClass('show');submitBooking();}
        else{$('#rg-otp-err').text(r.data&&r.data.message?r.data.message:'Incorrect OTP. Try again.').show();$('#rg-verify-otp').prop('disabled',false).html('Verify &amp; Confirm Booking');}
    });
});

function submitBooking(){
    $('#rg-submit-btn').prop('disabled',true).html('<span class="rg-spinner"></span> Confirming...');
    var d=$('#rg-booking-form').serializeArray();d.push({name:'action',value:'ridego_submit_booking'});
    $.post(ajaxUrl,d,function(r){
        if(r.success&&r.data&&r.data.booking_number){window.location.href=confirmUrl+'?booking='+r.data.booking_number;}
        else{showErr(r.data&&r.data.message?r.data.message:'Booking failed. Please try again.');$('#rg-submit-btn').prop('disabled',false).html('🔒 Confirm Booking');}
    }).fail(function(){showErr('Server error. Please refresh and try again.');$('#rg-submit-btn').prop('disabled',false).html('🔒 Confirm Booking');});
}

function showErr(msg){$('#rg-booking-error').html('❌ '+msg).show();$('html,body').animate({scrollTop:$('#rg-booking-error').offset().top-80},300);}

$('#rg-resend-otp').on('click',function(e){e.preventDefault();var $t=$(this).text('Sending...');$.post(ajaxUrl,{action:'ridego_send_otp',phone:$('#rg_client_phone').val(),purpose:'booking',nonce:$('#rg_nonce').val()},function(){$t.text('Sent ✓');setTimeout(function(){$t.text('Resend OTP');},30000);});});
})(jQuery);
</script>
<?php return ob_get_clean(); }

/* ================================================================
   MY TRIPS  [ridego_my_trips]
   ================================================================ */
add_shortcode('ridego_my_trips', 'ridego_shortcode_my_trips');
function ridego_shortcode_my_trips($atts) {
    if(!is_user_logged_in()) return '<div class="rg-alert rg-alert-info" style="max-width:600px;margin:40px auto;">Please <a href="'.wp_login_url(get_permalink()).'" style="font-weight:700;">log in</a> to view your trips.</div>';
    global $wpdb; $uid=get_current_user_id();
    /* Handle cancel */
    if(isset($_POST['cancel_booking_id'])&&wp_verify_nonce(isset($_POST['_wpnonce'])?$_POST['_wpnonce']:'','ridego_cancel_booking')){
        // $uid (the logged-in owner, established above) is passed as the
        // verified client id — ridego_cancel_booking() refuses a
        // client-initiated cancel without it, so an arbitrary
        // cancel_booking_id belonging to someone else is rejected rather
        // than silently cancelled.
        ridego_cancel_booking(absint($_POST['cancel_booking_id']),'Client cancelled','client',$uid);
    }
    $status=isset($_GET['status'])?sanitize_key($_GET['status']):'';
    $paged=max(1,intval(isset($_GET['pg'])?$_GET['pg']:1));$per=10;
    $tbl=$wpdb->prefix.'ridego_bookings';
    $w=$wpdb->prepare('WHERE client_id=%d',$uid);
    if($status) $w.=$wpdb->prepare(' AND status=%s',$status);
    $total=$wpdb->get_var("SELECT COUNT(*) FROM $tbl $w");
    $trips=$wpdb->get_results("SELECT * FROM $tbl $w ORDER BY created_at DESC LIMIT $per OFFSET ".(($paged-1)*$per));
    $confirm_url=ridego_page_url('confirm_page_id');
    $booking_url=ridego_page_url('booking_page_id');
    ob_start(); ?>
<div class="rg-wrap" style="padding:32px 20px 64px;max-width:960px;">
    <div class="rg-breadcrumb"><a href="<?php echo home_url(); ?>">Home</a><span class="rg-breadcrumb-sep">›</span><span class="rg-breadcrumb-current">My Trips</span></div>
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:24px;">
        <div><h1 style="font-size:26px;font-weight:900;margin:0 0 4px;">My Trips</h1><p style="margin:0;color:#6B7280;font-size:14px;"><?php echo intval($total); ?> booking<?php echo $total!=1?'s':''; ?></p></div>
        <a href="<?php echo esc_url($booking_url); ?>" class="rg-btn rg-btn-primary rg-btn-sm">+ New Booking</a>
    </div>
    <!-- Filters -->
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:24px;">
        <?php foreach([''=> 'All',  'pending'=>'Pending','confirmed'=>'Confirmed','completed'=>'Completed','cancelled'=>'Cancelled'] as $s=>$l): ?>
        <a href="<?php echo esc_url(add_query_arg(['status'=>$s,'pg'=>1])); ?>" style="padding:8px 18px;border-radius:20px;font-size:13.5px;font-weight:700;text-decoration:none;border:1.5px solid <?php echo $status===$s?'var(--p)':'var(--bd)';?>;background:<?php echo $status===$s?'var(--p)':'#fff';?>;color:<?php echo $status===$s?'#fff':'var(--t2)';?>;"><?php echo $l; ?></a>
        <?php endforeach; ?>
    </div>
    <?php if($trips): foreach($trips as $b): ?>
    <div class="rg-trip-card">
        <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:14px;">
            <div style="flex:1;min-width:220px;">
                <div class="rg-trip-route"><?php echo esc_html($b->pickup_city); ?><span class="rg-trip-route-arrow">→</span><?php echo esc_html($b->drop_city); ?></div>
                <div class="rg-trip-meta">
                    <span class="rg-trip-meta-item">📅 <?php echo date('D, d M Y',strtotime($b->journey_date)); ?></span>
                    <span class="rg-trip-meta-item">🕐 <?php echo substr($b->journey_time,0,5); ?></span>
                    <span class="rg-trip-meta-item">🚗 <?php echo ucwords(str_replace('_',' ',$b->trip_type)); ?></span>
                    <span class="rg-trip-meta-item">👥 <?php echo $b->passengers; ?> pax</span>
                </div>
                <div style="margin-top:8px;font-size:12px;color:#9CA3AF;font-family:monospace;font-weight:700;"><?php echo esc_html($b->booking_number); ?></div>
            </div>
            <div style="text-align:right;">
                <span class="rg-status rg-status-<?php echo esc_attr($b->status); ?>"><?php echo ridego_get_booking_status_label($b->status); ?></span>
                <div style="font-size:26px;font-weight:900;color:#1A56DB;margin-top:8px;"><?php echo ridego_currency_symbol().number_format($b->total_fare,0); ?></div>
                <div style="font-size:12px;color:#9CA3AF;"><?php echo ucwords(str_replace('_',' ',$b->payment_status)); ?></div>
            </div>
        </div>
        <div class="rg-trip-actions">
            <a href="<?php echo esc_url($confirm_url.'?booking='.$b->booking_number); ?>" class="rg-btn rg-btn-outline rg-btn-sm">View Details</a>
            <?php if(in_array($b->status,['pending','payment_pending','confirmed'])): ?>
            <form method="post" style="display:inline;"><?php wp_nonce_field('ridego_cancel_booking'); ?>
                <input type="hidden" name="cancel_booking_id" value="<?php echo $b->id; ?>">
                <button type="submit" class="rg-btn rg-btn-sm" style="background:#FEE2E2;color:#DC2626;border:1.5px solid #FCA5A5;" onclick="return confirm('Cancel this booking?')">Cancel</button>
            </form>
            <?php endif; ?>
            <?php if($b->status==='completed'): ?>
            <a href="<?php echo esc_url(add_query_arg(['booking'=>$b->booking_number],ridego_page_url('booking_page_id'))); ?>" class="rg-btn rg-btn-sm" style="background:#EBF0FF;color:#1A56DB;border:1.5px solid #C7D2FE;">Rebook</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; else: ?>
    <div class="rg-empty"><span class="rg-empty-icon">🚗</span><h3>No trips yet!</h3><p>Your travel history will appear here.</p><a href="<?php echo esc_url($booking_url); ?>" class="rg-btn rg-btn-primary rg-btn-lg">Book Your First Cab →</a></div>
    <?php endif; ?>
    <?php if($total>$per): $pages=ceil($total/$per); ?>
    <div class="rg-pagination">
        <?php if($paged>1):?><a class="rg-page-btn" href="<?php echo add_query_arg('pg',$paged-1);?>">‹</a><?php endif;?>
        <?php for($i=1;$i<=$pages;$i++):?><a class="rg-page-btn <?php echo $i===$paged?'active':'';?>" href="<?php echo add_query_arg('pg',$i);?>"><?php echo $i;?></a><?php endfor;?>
        <?php if($paged<$pages):?><a class="rg-page-btn" href="<?php echo add_query_arg('pg',$paged+1);?>">›</a><?php endif;?>
    </div>
    <?php endif; ?>
</div>
<?php return ob_get_clean(); }

/* ================================================================
   VENDOR REGISTER  [ridego_vendor_register]
   ================================================================ */
add_shortcode('ridego_vendor_register','ridego_shortcode_vendor_register');
function ridego_shortcode_vendor_register($atts){
    if(!is_user_logged_in()) return '<div class="rg-alert rg-alert-info" style="max-width:700px;margin:40px auto;">Please <a href="'.wp_login_url(get_permalink()).'" style="font-weight:700;">log in</a> to register as a vendor.</div>';
    $uid=get_current_user_id();$ex=ridego_get_vendor_by_user($uid);
    if($ex) return '<div class="rg-alert rg-alert-success" style="max-width:700px;margin:40px auto;">✅ You are already registered. <a href="'.esc_url(ridego_page_url('vendor_dashboard_page_id')).'" style="font-weight:700;">Go to Dashboard →</a></div>';
    $msg='';$err='';
    if(isset($_POST['rg_vendor_register'])&&wp_verify_nonce(isset($_POST['rg_v_nonce'])?$_POST['rg_v_nonce']:'','ridego_vendor_register')){
        $d=array('user_id'=>$uid,'business_name'=>sanitize_text_field($_POST['business_name']),'owner_name'=>sanitize_text_field($_POST['owner_name']),'phone'=>sanitize_text_field($_POST['phone']),'email'=>sanitize_email($_POST['email']),'whatsapp_number'=>sanitize_text_field($_POST['whatsapp_number']),'city'=>sanitize_text_field($_POST['city']),'operating_cities'=>sanitize_text_field($_POST['operating_cities']),'vehicle_types'=>isset($_POST['vehicle_types'])?implode(',',array_map('sanitize_text_field',$_POST['vehicle_types'])):'','total_vehicles'=>absint($_POST['total_vehicles']),'years_experience'=>absint($_POST['years_experience']),'business_type'=>sanitize_key($_POST['business_type']),'gst_number'=>sanitize_text_field(isset($_POST['gst_number'])?$_POST['gst_number']:''),'pan_number'=>sanitize_text_field(isset($_POST['pan_number'])?$_POST['pan_number']:''));
        if(empty($d['business_name'])||empty($d['phone'])){$err='Business name and phone are required.';}
        else{$r=ridego_create_vendor($d);if($r){$msg='🎉 Registration submitted! We will review your KYC within 24 hours and activate your account.';}else{$err='Registration failed. Please try again.';}}
    }
    $vehicles=ridego_get_vehicles();$user=wp_get_current_user();
    ob_start(); ?>
<div class="rg-wrap" style="max-width:800px;padding:32px 20px 64px;">
    <!-- Hero banner -->
    <div style="background:linear-gradient(135deg,#0C1445,#1A3A8A,#4F46E5);color:#fff;border-radius:20px;padding:44px;margin-bottom:28px;text-align:center;position:relative;overflow:hidden;">
        <div class="rg-hero-bg-dots"></div>
        <div style="position:relative;z-index:1;">
            <div style="font-size:52px;margin-bottom:14px;">🚗</div>
            <h1 style="font-size:28px;font-weight:900;margin-bottom:10px;">Partner With Us. Earn More.</h1>
            <p style="opacity:.8;font-size:15px;max-width:480px;margin:0 auto 24px;">Join 500+ verified drivers earning from quality cab bookings across India.</p>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;max-width:420px;margin:0 auto;">
                <?php foreach([['₹1.5L+','Monthly Earnings'],['500+','Active Vendors'],['24h','KYC Turnaround']] as $s): ?>
                <div style="background:rgba(255,255,255,.12);border-radius:12px;padding:14px 10px;text-align:center;backdrop-filter:blur(4px);">
                    <div style="font-size:20px;font-weight:900;"><?php echo $s[0]; ?></div>
                    <div style="font-size:11px;opacity:.75;margin-top:3px;"><?php echo $s[1]; ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php if($msg) echo '<div class="rg-alert rg-alert-success" style="font-size:15px;font-weight:600;">'.esc_html($msg).'</div>'; ?>
    <?php if($err) echo '<div class="rg-alert rg-alert-error">'.esc_html($err).'</div>'; ?>
    <?php if(!$msg): ?>
    <div class="rg-card">
        <h2 style="font-size:20px;font-weight:800;margin-bottom:24px;">Registration Form</h2>
        <form method="post">
            <?php wp_nonce_field('ridego_vendor_register','rg_v_nonce'); ?><input type="hidden" name="rg_vendor_register" value="1">
            <div class="rg-form-grid-2">
                <?php $flds=[['business_name','text','Business / Trade Name *',$user->display_name,'Your registered business'],['owner_name','text','Owner Full Name *',$user->display_name,'As per Aadhaar/PAN'],['phone','tel','Mobile Number *','','+91 98765 43210'],['whatsapp_number','tel','WhatsApp Number','','For booking alerts'],['email','email','Email Address *',$user->user_email,'Booking notifications'],['city','text','Base City *','','Your home city'],['operating_cities','text','Operating Cities','','Delhi, Agra, Jaipur...'],['total_vehicles','number','Total Vehicles','1',''],['years_experience','number','Years of Experience','0',''],['gst_number','text','GST Number (if any)','','22ABCDE1234F1Z5'],['pan_number','text','PAN Number','','ABCDE1234F']];
                foreach($flds as $f): $req=strpos($f[2],'*')!==false; ?>
                <div class="rg-field <?php echo in_array($f[0],['operating_cities','gst_number','pan_number'])?'rg-span-2':''; ?>">
                    <label class="rg-label"><?php echo str_replace(' *','',$f[2]); ?><?php if($req): ?><span class="req"> *</span><?php endif; ?></label>
                    <input type="<?php echo $f[1]; ?>" name="<?php echo $f[0]; ?>" class="rg-input" value="<?php echo esc_attr(isset($_POST[$f[0]])?$_POST[$f[0]]:$f[3]); ?>" placeholder="<?php echo esc_attr($f[4]); ?>" <?php echo $req?'required':''; ?>>
                </div>
                <?php endforeach; ?>
                <div class="rg-field rg-span-2">
                    <label class="rg-label">Business Type</label>
                    <select name="business_type" class="rg-input rg-select"><option value="individual">Individual Driver / Owner-Driver</option><option value="fleet_owner">Fleet Owner (2+ vehicles)</option><option value="agency">Travel Agency</option><option value="rental">Car Rental Operator</option></select>
                </div>
                <?php if($vehicles): ?>
                <div class="rg-field rg-span-2">
                    <label class="rg-label">Vehicle Types You Operate</label>
                    <div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:6px;">
                        <?php foreach($vehicles as $v): ?>
                        <label style="display:flex;align-items:center;gap:7px;padding:9px 16px;background:#F9FAFB;border:1.5px solid var(--bd);border-radius:9px;cursor:pointer;font-size:13.5px;font-weight:600;transition:var(--trans);"><input type="checkbox" name="vehicle_types[]" value="<?php echo esc_attr($v->slug); ?>" style="accent-color:var(--p);"> <?php echo esc_html($v->name); ?></label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div style="margin-top:24px;"><button type="submit" class="rg-btn rg-btn-primary rg-btn-xl rg-btn-full">Submit Registration →</button></div>
            <p style="text-align:center;font-size:12.5px;color:#9CA3AF;margin-top:12px;">Your data is secure · KYC reviewed in 24h · Activation upon document verification</p>
        </form>
    </div>
    <?php endif; ?>
</div>
<?php return ob_get_clean(); }

/* ================================================================
   VENDOR DASHBOARD  [ridego_vendor_dashboard]
   ================================================================ */
add_shortcode('ridego_vendor_dashboard','ridego_shortcode_vendor_dashboard');
function ridego_shortcode_vendor_dashboard($atts){
    if(!is_user_logged_in()) return '<div class="rg-alert rg-alert-info" style="max-width:700px;margin:40px auto;">Please <a href="'.wp_login_url(get_permalink()).'" style="font-weight:700;">log in</a>.</div>';
    $vendor=ridego_get_current_vendor();
    if(!$vendor) return '<div class="rg-alert rg-alert-info" style="max-width:700px;margin:40px auto;">No vendor account. <a href="'.esc_url(ridego_page_url('vendor_register_page_id')).'" style="font-weight:700;">Register →</a></div>';
    global $wpdb; $ltbl=$wpdb->prefix.'ridego_leads'; $btbl=$wpdb->prefix.'ridego_bookings';
    $msg='';
    if(isset($_POST['rg_lead_action'])&&wp_verify_nonce(isset($_POST['rg_lead_nonce'])?$_POST['rg_lead_nonce']:'','ridego_lead_action')){
        $lid=absint($_POST['lead_id']);$act=sanitize_key($_POST['rg_lead_action']);
        if($act==='accept'){$wpdb->update($ltbl,array('status'=>'accepted'),array('id'=>$lid,'vendor_id'=>$vendor->id,'status'=>'sent'));$msg='✅ Lead accepted! Contact client to confirm trip.';}
        elseif($act==='decline'){$wpdb->update($ltbl,array('status'=>'rejected'),array('id'=>$lid,'vendor_id'=>$vendor->id));}
        $vendor=ridego_get_current_vendor();
    }
    $tab=isset($_GET['vtab'])?sanitize_key($_GET['vtab']):'leads';
    $new_leads=$wpdb->get_results($wpdb->prepare("SELECT l.*,b.booking_number,b.pickup_city,b.drop_city,b.journey_date,b.journey_time,b.trip_type,b.total_fare,b.passengers,b.client_name,b.client_phone,b.special_requests FROM $ltbl l LEFT JOIN $btbl b ON b.id=l.booking_id WHERE l.vendor_id=%d AND l.status IN('sent','accepted') ORDER BY l.sent_at DESC LIMIT 20",$vendor->id));
    $history=$wpdb->get_results($wpdb->prepare("SELECT l.*,b.booking_number,b.pickup_city,b.drop_city,b.journey_date FROM $ltbl l LEFT JOIN $btbl b ON b.id=l.booking_id WHERE l.vendor_id=%d AND l.status NOT IN('sent','accepted') ORDER BY l.sent_at DESC LIMIT 30",$vendor->id));
    $wallet_hist=ridego_get_vendor_wallet_history($vendor->id,25);
    $low=floatval($vendor->wallet_balance)<floatval(ridego_get_setting('min_wallet_balance',200));
    $sym=ridego_currency_symbol();
    /* Stats */
    $total_leads=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $ltbl WHERE vendor_id=%d",$vendor->id));
    $accepted_leads=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $ltbl WHERE vendor_id=%d AND status='accepted'",$vendor->id));
    $total_earned=$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(fee_amount),0) FROM $ltbl WHERE vendor_id=%d AND status='assigned'",$vendor->id));
    ob_start(); ?>
<div class="rg-vendor-wrap">
    <?php if($msg) echo '<div class="rg-alert rg-alert-success">'.$msg.'</div>'; ?>

    <!-- Hero Header -->
    <div class="rg-vendor-hero">
        <div class="rg-vendor-av"><?php echo mb_strtoupper(mb_substr($vendor->business_name,0,2)); ?></div>
        <div class="rg-vendor-info">
            <div class="rg-vendor-bname"><?php echo esc_html($vendor->business_name); ?></div>
            <div class="rg-vendor-phone">📱 <?php echo esc_html($vendor->phone); ?></div>
            <div class="rg-vendor-pills">
                <span class="rg-vendor-pill"><?php echo ucfirst($vendor->status); ?></span>
                <span class="rg-vendor-pill">KYC: <?php echo ucfirst($vendor->kyc_status); ?></span>
                <span class="rg-vendor-pill">⭐ <?php echo esc_html($vendor->business_type??'Driver'); ?></span>
            </div>
        </div>
        <div class="rg-vendor-wallet">
            <div class="rg-wallet-label">Wallet Balance</div>
            <div class="rg-wallet-bal <?php echo $low?'low':''; ?>"><?php echo $sym.number_format($vendor->wallet_balance,2); ?></div>
            <?php if($low): ?><div class="rg-wallet-warn">⚠️ Below minimum — top up to get leads</div><?php endif; ?>
        </div>
    </div>

    <!-- Quick stats -->
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:24px;">
        <?php foreach([['📋',intval($total_leads),'Total Leads'],['✅',intval($accepted_leads),'Accepted'],['💰',$sym.number_format(floatval($total_earned),0),'Earned (Fees)'],['⭐','4.8','Rating (Demo)']] as $s): ?>
        <div style="background:#fff;border:1.5px solid #E5E7EB;border-radius:14px;padding:18px;text-align:center;box-shadow:var(--sh1);">
            <div style="font-size:24px;margin-bottom:6px;"><?php echo $s[0]; ?></div>
            <div style="font-size:22px;font-weight:900;color:#1A56DB;"><?php echo $s[1]; ?></div>
            <div style="font-size:11.5px;font-weight:600;color:#6B7280;margin-top:3px;text-transform:uppercase;letter-spacing:.5px;"><?php echo $s[2]; ?></div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php if($vendor->status==='pending'): echo '<div class="rg-alert rg-alert-warning">⏳ <strong>Application Under Review.</strong> Your account will be activated after KYC verification (within 24h).</div>'; endif; ?>

    <!-- Tabs -->
    <div class="rg-tabs">
        <?php foreach(['leads'=>'📋 New Leads','history'=>'📂 History','wallet'=>'💰 Wallet','profile'=>'👤 Profile'] as $t=>$l): ?>
        <a href="<?php echo esc_url(add_query_arg('vtab',$t)); ?>" class="rg-tab <?php echo $tab===$t?'active':''; ?>"><?php echo $l; ?></a>
        <?php endforeach; ?>
    </div>

    <?php if($tab==='leads'):
        if($new_leads): foreach($new_leads as $l):
            $acc=$l->status==='accepted';$exp_in=$l->expires_at?max(0,strtotime($l->expires_at)-time()):0; ?>
        <div class="rg-lead-card <?php echo $exp_in<300&&!$acc?'urgent':''; ?>">
            <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:14px;">
                <div class="rg-lead-route"><?php echo esc_html($l->pickup_city.' → '.$l->drop_city); ?></div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                    <?php if(!$acc&&$exp_in>0): ?><span class="rg-lead-timer">⏱ <?php echo gmdate($exp_in>=3600?'H:i:s':'i:s',$exp_in); ?> left</span><?php endif; ?>
                    <span class="rg-lead-fee">Lead Fee: <?php echo $sym.number_format($l->fee_amount,2); ?></span>
                    <?php if($acc): ?><span class="rg-tag rg-tag-green">✅ Accepted</span><?php endif; ?>
                </div>
            </div>
            <div class="rg-lead-pills">
                <span class="rg-lead-pill">📅 <?php echo date('d M Y',strtotime($l->journey_date)); ?></span>
                <span class="rg-lead-pill">🕐 <?php echo substr($l->journey_time,0,5); ?></span>
                <span class="rg-lead-pill">👥 <?php echo $l->passengers; ?> pax</span>
                <span class="rg-lead-pill"><?php echo ucwords(str_replace('_',' ',$l->trip_type)); ?></span>
                <span class="rg-lead-pill">💰 ₹<?php echo number_format($l->total_fare,0); ?> booking</span>
            </div>
            <?php if($acc): ?>
            <div class="rg-alert rg-alert-success" style="margin:12px 0 0;">
                📞 <strong><?php echo esc_html($l->client_name); ?></strong> — <strong><?php echo esc_html($l->client_phone); ?></strong>
                <?php if($l->special_requests): ?> | Note: <?php echo esc_html($l->special_requests); ?><?php endif; ?>
            </div>
            <?php else: ?>
            <form method="post" style="display:flex;gap:10px;margin-top:12px;flex-wrap:wrap;">
                <?php wp_nonce_field('ridego_lead_action','rg_lead_nonce'); ?>
                <input type="hidden" name="lead_id" value="<?php echo $l->id; ?>">
                <?php if(!$low): ?><button type="submit" name="rg_lead_action" value="accept" class="rg-btn rg-btn-primary">✅ Accept Lead</button><?php else: ?>
                <div class="rg-alert rg-alert-warning" style="margin:0;padding:10px 14px;font-size:13px;">⚠️ Top up wallet to accept leads.</div><?php endif; ?>
                <button type="submit" name="rg_lead_action" value="decline" class="rg-btn rg-btn-sm" style="background:#FEE2E2;color:#DC2626;border:1.5px solid #FCA5A5;" onclick="return confirm('Decline this lead?')">Decline</button>
            </form>
            <?php endif; ?>
        </div>
        <?php endforeach; else: ?>
        <div class="rg-empty"><span class="rg-empty-icon">📭</span><h3>No new leads right now</h3><p>Leads are sent when clients book in your operating area.</p></div>
        <?php endif;

    elseif($tab==='history'):
        if($history): ?>
        <div style="overflow-x:auto;background:#fff;border:1.5px solid #E5E7EB;border-radius:var(--r);box-shadow:var(--sh1);">
        <table style="width:100%;border-collapse:collapse;font-size:13.5px;">
            <thead style="background:#F9FAFB;"><tr><?php foreach(['Booking #','Route','Date','Fee','Status'] as $h): ?><th style="padding:12px 16px;text-align:left;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.7px;color:#6B7280;border-bottom:1px solid #E5E7EB;"><?php echo $h; ?></th><?php endforeach; ?></tr></thead>
            <tbody><?php foreach($history as $l): ?>
            <tr style="border-bottom:1px solid #F9FAFB;"><td style="padding:11px 16px;font-weight:700;font-family:monospace;font-size:12px;"><?php echo esc_html($l->booking_number); ?></td><td style="padding:11px 16px;font-weight:600;"><?php echo esc_html($l->pickup_city.' → '.$l->drop_city); ?></td><td style="padding:11px 16px;color:#6B7280;"><?php echo date('d M Y',strtotime($l->journey_date)); ?></td><td style="padding:11px 16px;font-weight:800;color:#059669;"><?php echo $sym.number_format($l->fee_amount,2); ?></td><td style="padding:11px 16px;"><span class="rg-tag rg-tag-<?php echo $l->status==='assigned'?'green':($l->status==='rejected'?'red':'gray'); ?>"><?php echo ucfirst($l->status); ?></span></td></tr>
            <?php endforeach; ?></tbody>
        </table></div>
        <?php else: echo '<div class="rg-empty"><span class="rg-empty-icon">📂</span><h3>No history yet</h3><p>Lead history appears here once you start accepting.</p></div>'; endif;

    elseif($tab==='wallet'): ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:20px;">
        <div style="background:linear-gradient(135deg,<?php echo $low?'#7F1D1D,#DC2626':'#014737,#059669'; ?>);color:#fff;border-radius:18px;padding:30px;box-shadow:0 8px 28px rgba(0,0,0,.18);">
            <div style="font-size:13px;text-transform:uppercase;letter-spacing:1.5px;font-weight:700;opacity:.8;margin-bottom:10px;">Current Balance</div>
            <div style="font-size:52px;font-weight:900;letter-spacing:-2px;"><?php echo $sym.number_format($vendor->wallet_balance,2); ?></div>
            <div style="margin-top:12px;font-size:13px;opacity:.75;">Min balance required: <?php echo $sym.ridego_get_setting('min_wallet_balance',200); ?></div>
            <?php if($low): ?><div style="margin-top:12px;background:rgba(255,255,255,.15);border-radius:10px;padding:10px 14px;font-size:13px;font-weight:600;">⚠️ Balance below minimum. Contact admin to top up via bank transfer.</div><?php endif; ?>
        </div>
        <div style="background:#fff;border:1.5px solid #E5E7EB;border-radius:18px;padding:24px;box-shadow:var(--sh1);">
            <div style="font-size:15px;font-weight:800;color:#111827;margin-bottom:18px;">Transaction History</div>
            <?php if($wallet_hist): foreach($wallet_hist as $tx): $pl=floatval($tx->amount)>=0; ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid #F9FAFB;font-size:13.5px;">
                <div><div style="font-weight:700;"><?php echo esc_html(ucfirst($tx->type)); ?></div><div style="font-size:11.5px;color:#9CA3AF;"><?php echo date('d M Y H:i',strtotime($tx->created_at)); ?></div></div>
                <div style="font-weight:800;font-size:17px;color:<?php echo $pl?'#059669':'#DC2626'; ?>"><?php echo ($pl?'+':'-').$sym.number_format(abs($tx->amount),2); ?></div>
            </div>
            <?php endforeach; else: echo '<p style="color:#9CA3AF;">No transactions yet.</p>'; endif; ?>
        </div>
    </div>
    <?php elseif($tab==='profile'): ?>
    <div style="background:#fff;border:1.5px solid #E5E7EB;border-radius:18px;padding:28px;box-shadow:var(--sh1);max-width:640px;">
        <h3 style="font-size:18px;font-weight:800;margin-bottom:20px;">Profile Information</h3>
        <?php foreach([['Business Name',$vendor->business_name],['Owner Name',$vendor->owner_name],['Phone',$vendor->phone],['WhatsApp',$vendor->whatsapp_number??''],['Email',$vendor->email],['Base City',$vendor->city],['Operating Cities',$vendor->operating_cities],['Vehicle Types',$vendor->vehicle_types],['Total Vehicles',$vendor->total_vehicles],['Business Type',ucfirst($vendor->business_type??'')],['KYC Status',ucfirst($vendor->kyc_status)],['Account Status',ucfirst($vendor->status)],['Member Since',date('d M Y',strtotime($vendor->created_at))]] as $r): ?>
        <div style="display:flex;gap:12px;padding:10px 0;border-bottom:1px solid #F9FAFB;font-size:14px;">
            <span style="min-width:170px;font-weight:700;color:#6B7280;font-size:12.5px;text-transform:uppercase;letter-spacing:.3px;"><?php echo $r[0]; ?></span>
            <span style="color:#111827;font-weight:500;"><?php echo esc_html($r[1]); ?></span>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?php return ob_get_clean(); }

/* ================================================================
   TRACK BOOKING  [ridego_track]
   ================================================================ */
add_shortcode('ridego_track','ridego_shortcode_track');
function ridego_shortcode_track($atts){
    $bn=isset($_GET['booking'])?sanitize_text_field($_GET['booking']):'';
    $phone=isset($_GET['phone'])?ridego_sanitize_phone($_GET['phone']):'';
    $booking=$bn?ridego_get_booking_by_number($bn):null;

    // Booking numbers are sequential (RG-2026-00001, -00002, ...), not a
    // secret — showing full trip/fare/payment details off the number
    // alone would let anyone enumerate every booking in the system. The
    // phone number used for the booking is the second, non-enumerable
    // factor required here (the same "PNR + contact" pattern airlines use
    // for anonymous status lookup) — an admin bypasses it since they're
    // already authorized to see any booking.
    $verified = false;
    if ($booking) {
        if (current_user_can('manage_options')) {
            $verified = true;
        } elseif ($phone && ridego_clean_phone_number($phone) === ridego_clean_phone_number($booking->client_phone)) {
            $verified = true;
        }
    }
    $not_found = $bn && (!$booking || !$verified);
    if (!$verified) { $booking = null; }

    ob_start(); ?>
<div class="rg-wrap" style="max-width:680px;padding:40px 20px;">
    <div class="rg-breadcrumb"><a href="<?php echo home_url(); ?>">Home</a><span class="rg-breadcrumb-sep">›</span><span class="rg-breadcrumb-current">Track Booking</span></div>
    <div class="rg-card" style="margin-top:16px;">
        <h1 style="font-size:24px;font-weight:900;margin-bottom:8px;">Track Your Booking</h1>
        <p style="color:#6B7280;font-size:14px;margin-bottom:24px;">Enter your booking reference and the phone number used for the booking to see real-time status.</p>
        <form method="get" style="display:flex;gap:10px;margin-bottom:24px;flex-wrap:wrap;">
            <div class="rg-input-icon-wrap" style="flex:1;min-width:200px;"><span class="rg-input-icon">🔍</span><input type="text" name="booking" class="rg-input" placeholder="e.g. RG-2026-00001" value="<?php echo esc_attr($bn); ?>" style="padding-left:44px;font-size:16px;"></div>
            <div class="rg-input-icon-wrap" style="flex:1;min-width:200px;"><span class="rg-input-icon">📱</span><input type="text" name="phone" class="rg-input" placeholder="Phone used for booking" value="<?php echo esc_attr($phone); ?>" style="padding-left:44px;font-size:16px;"></div>
            <button type="submit" class="rg-btn rg-btn-primary">Track →</button>
        </form>
        <?php if($not_found): echo '<div class="rg-alert rg-alert-error">❌ Booking not found. Please double-check the booking number and phone number.</div>';
        elseif($booking): ?>
        <div style="background:linear-gradient(135deg,#0C1445,#1A3A8A);color:#fff;border-radius:16px;padding:24px;margin-bottom:0;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.15);margin-bottom:18px;">
                <div>
                    <div style="font-size:12px;text-transform:uppercase;letter-spacing:1px;opacity:.7;margin-bottom:5px;">Booking Reference</div>
                    <div style="font-size:24px;font-weight:900;font-family:monospace;letter-spacing:1px;"><?php echo esc_html($booking->booking_number); ?></div>
                </div>
                <span class="rg-status rg-status-<?php echo esc_attr($booking->status); ?>" style="font-size:13px;padding:7px 18px;"><?php echo ridego_get_booking_status_label($booking->status); ?></span>
            </div>
            <?php foreach([['🗺️ Route',$booking->pickup_city.' → '.$booking->drop_city],['📅 Date',date('D, d M Y',strtotime($booking->journey_date)).' at '.substr($booking->journey_time,0,5)],['🚗 Trip Type',ucwords(str_replace('_',' ',$booking->trip_type))],['👥 Passengers',$booking->passengers.' passenger'.($booking->passengers>1?'s':'')],['💰 Total Fare',ridego_currency_symbol().number_format($booking->total_fare,2)],['💳 Payment',ucwords(str_replace('_',' ',$booking->payment_status))]] as $r): ?>
            <div style="display:flex;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.1);font-size:14px;">
                <span style="min-width:140px;opacity:.7;"><?php echo $r[0]; ?></span>
                <span style="font-weight:700;"><?php echo esc_html($r[1]); ?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php return ob_get_clean(); }

/* ================================================================
   STATIC PAGES
   ================================================================ */
add_shortcode('ridego_about','ridego_sc_about');
function ridego_sc_about($a){
    $name=ridego_get_setting('platform_name',get_bloginfo('name'));
    $phone=ridego_get_setting('support_phone','');$email=ridego_get_setting('admin_email','');
    return '<div class="rg-wrap" style="max-width:880px;padding:40px 20px;">
    <div style="background:linear-gradient(135deg,#0C1445,#1A3A8A,#4F46E5);color:#fff;border-radius:20px;padding:60px 40px;text-align:center;margin-bottom:32px;position:relative;overflow:hidden;">
        <div class="rg-hero-bg-dots"></div>
        <div style="position:relative;z-index:1;"><div style="font-size:64px;margin-bottom:18px;">🚗</div>
        <h1 style="font-size:clamp(28px,4vw,44px);font-weight:900;margin-bottom:12px;">About '.esc_html($name).'</h1>
        <p style="font-size:16px;opacity:.8;max-width:540px;margin:0 auto;">India\'s most trusted cab booking platform. Connecting passengers with verified professional drivers across 100+ cities.</p></div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px;margin-bottom:32px;">
        '.implode('',array_map(function($f){return '<div class="rg-feature-card"><div class="rg-feature-icon" style="'.$f[2].'">'.$f[0].'</div><div class="rg-feature-title">'.$f[1].'</div><div class="rg-feature-desc">'.$f[3].'</div></div>';},[['🛡️','100% Verified Drivers','background:#DBEAFE','All drivers undergo KYC, background checks and document verification.'],['💰','Transparent Pricing','background:#D1FAE5','Fixed fares shown upfront. No surge, no hidden charges.'],['⚡','Technology-Driven','background:#EDE9FE','Real-time booking, OTP verification & WhatsApp updates.'],['📞','24/7 Support','background:#FEF3C7','Round-the-clock customer support via phone and WhatsApp.']])).'
    </div>
    '.($phone||$email?'<div style="background:#F9FAFB;border-radius:16px;padding:28px;">
        <h2 style="font-size:20px;font-weight:800;margin-bottom:16px;">Contact Us</h2>
        '.($phone?'<p style="font-size:15px;margin-bottom:8px;">📞 <strong>Phone:</strong> '.esc_html($phone).'</p>':'').
        ($email?'<p style="font-size:15px;"><strong>📧 Email:</strong> <a href="mailto:'.esc_attr($email).'">'.esc_html($email).'</a></p>':'').'
    </div>':'').'
    </div>';
}

add_shortcode('ridego_contact','ridego_sc_contact');
function ridego_sc_contact($a){
    $phone=ridego_get_setting('support_phone','');$wa=ridego_get_setting('support_whatsapp','');$email=ridego_get_setting('admin_email','');
    return '<div class="rg-wrap" style="max-width:680px;padding:40px 20px;">
    <div class="rg-card">
        <h1 style="font-size:28px;font-weight:900;margin-bottom:8px;">Contact Us</h1>
        <p style="color:#6B7280;margin-bottom:28px;">We\'re here to help. Reach us through any channel below.</p>
        '.($phone?'<a href="tel:'.esc_attr(preg_replace('/\s+/','',$phone)).'" style="display:flex;gap:16px;align-items:center;padding:18px;background:#EFF6FF;border-radius:14px;margin-bottom:12px;text-decoration:none;transition:var(--trans);" onmouseover="this.style.background=\'#DBEAFE\'" onmouseout="this.style.background=\'#EFF6FF\'"><div style="font-size:36px;">📞</div><div><div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#6B7280;margin-bottom:4px;">Phone Support</div><div style="font-size:20px;font-weight:900;color:#1A56DB;">'.esc_html($phone).'</div><div style="font-size:12px;color:#6B7280;margin-top:2px;">Available 24/7</div></div></a>':'').
        ($wa?'<a href="https://wa.me/'.esc_attr(preg_replace('/[^0-9]/','',$wa)).'" target="_blank" style="display:flex;gap:16px;align-items:center;padding:18px;background:#F0FDF4;border-radius:14px;margin-bottom:12px;text-decoration:none;"><div style="font-size:36px;">💬</div><div><div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#6B7280;margin-bottom:4px;">WhatsApp</div><div style="font-size:20px;font-weight:900;color:#059669;">'.esc_html($wa).'</div></div></a>':'').
        ($email?'<a href="mailto:'.esc_attr($email).'" style="display:flex;gap:16px;align-items:center;padding:18px;background:#FFFBEB;border-radius:14px;text-decoration:none;"><div style="font-size:36px;">📧</div><div><div style="font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#6B7280;margin-bottom:4px;">Email</div><div style="font-size:20px;font-weight:900;color:#D97706;">'.esc_html($email).'</div></div></a>':'').'
    </div></div>';
}

add_shortcode('ridego_faq','ridego_sc_faq');
function ridego_sc_faq($a){
    $name=ridego_get_setting('platform_name',get_bloginfo('name'));
    $phone=ridego_get_setting('support_phone','');$email=ridego_get_setting('admin_email','');
    $faqs=[
        ['How do I book a ride?','Choose your pickup and drop cities, pick a date and vehicle type on the booking page, and confirm with an OTP sent to your mobile number. You\'ll get a confirmation with your driver and vehicle details once assigned.'],
        ['How is the fare calculated?','Fares are shown upfront before you confirm a booking, based on the distance, vehicle type and any applicable taxes or tolls. There are no hidden charges or surge pricing added after booking.'],
        ['Can I cancel or reschedule a booking?','Yes. Open "My Trips" from your account to cancel or request a reschedule. Cancellation terms are described on our Cancellation Policy page, and any applicable refund is processed back to your original payment method.'],
        ['Are drivers verified?','All drivers on '.esc_html($name).' complete KYC document verification, including licence and identity checks, before they are allowed to accept trips.'],
        ['How do I track my driver?','Once a driver is assigned, you can track their live location and contact details from the "My Trips" section of your account.'],
        ['What if I need help during my trip?','Our support team is available through the Contact Us page. '.($phone?'You can also call us directly at '.esc_html($phone).'.':'').''],
        ['How do I get a refund?','Refunds for eligible cancellations are processed to your original payment method. Processing times depend on your bank or payment provider, typically within a few business days.'],
    ];
    $out='<div class="rg-wrap" style="max-width:820px;padding:40px 20px;">
    <h1 style="font-size:32px;font-weight:900;margin-bottom:8px;">Frequently Asked Questions</h1>
    <p style="color:#6B7280;margin-bottom:28px;">Answers to common questions about booking, fares, cancellations and support.</p>
    <div style="display:flex;flex-direction:column;gap:14px;">';
    foreach($faqs as $f){
        $out.='<div class="rg-card" style="padding:20px 24px;"><h2 style="font-size:17px;font-weight:800;margin-bottom:8px;">'.esc_html($f[0]).'</h2><p style="color:#4B5563;font-size:14px;line-height:1.6;margin:0;">'.esc_html($f[1]).'</p></div>';
    }
    $out.='</div>'.($email?'<p style="margin-top:28px;color:#6B7280;font-size:14px;">Still have questions? <a href="mailto:'.esc_attr($email).'" style="font-weight:700;">Email our support team</a>.</p>':'').'</div>';
    return $out;
}

add_shortcode('ridego_terms','ridego_sc_terms');
function ridego_sc_terms($a){
    $name=ridego_get_setting('platform_name',get_bloginfo('name'));
    $email=ridego_get_setting('admin_email','');
    $updated=get_option('ridego_terms_updated', date_i18n('F j, Y'));
    $sections=[
        ['1. Acceptance of Terms','By creating an account or booking a ride through '.esc_html($name).', you agree to be bound by these Terms of Service. If you do not agree, please do not use the platform.'],
        ['2. The Service','We connect passengers with independent, verified vendors and drivers who provide vehicle transportation. '.esc_html($name).' facilitates bookings, payments and communication, but rides are performed by third-party vendors and drivers.'],
        ['3. Booking and Payment','Fares are shown before you confirm a booking. Payment may be collected in advance, on completion of the trip, or via a combination, as displayed at the time of booking.'],
        ['4. User Responsibilities','You agree to provide accurate contact and pickup information, to behave respectfully towards drivers and staff, and to comply with applicable laws during your trip.'],
        ['5. Vendor and Driver Conduct','Vendors and drivers are independently verified but operate as separate businesses. '.esc_html($name).' will investigate reported issues and may suspend accounts that violate platform policies.'],
        ['6. Cancellations and Refunds','Cancellation terms and any applicable fees are described on our Cancellation Policy page. Refunds, where applicable, are issued to the original payment method.'],
        ['7. Limitation of Liability','To the maximum extent permitted by law, '.esc_html($name).' is not liable for indirect or consequential damages arising from use of the platform, beyond the value of the affected booking.'],
        ['8. Changes to These Terms','We may update these terms from time to time. Continued use of the platform after changes are posted constitutes acceptance of the revised terms.'],
    ];
    $out='<div class="rg-wrap" style="max-width:820px;padding:40px 20px;">
    <h1 style="font-size:32px;font-weight:900;margin-bottom:4px;">Terms of Service</h1>
    <p style="color:#9CA3AF;font-size:13px;margin-bottom:28px;">Last updated: '.esc_html($updated).'</p>';
    foreach($sections as $s){
        $out.='<div style="margin-bottom:22px;"><h2 style="font-size:18px;font-weight:800;margin-bottom:8px;">'.esc_html($s[0]).'</h2><p style="color:#4B5563;font-size:14px;line-height:1.7;margin:0;">'.esc_html($s[1]).'</p></div>';
    }
    $out.=($email?'<p style="margin-top:24px;color:#6B7280;font-size:14px;">Questions about these terms? <a href="mailto:'.esc_attr($email).'" style="font-weight:700;">Contact us</a>.</p>':'').'</div>';
    return $out;
}

add_shortcode('ridego_privacy','ridego_sc_privacy');
function ridego_sc_privacy($a){
    $name=ridego_get_setting('platform_name',get_bloginfo('name'));
    $email=ridego_get_setting('admin_email','');
    $updated=get_option('ridego_privacy_updated', date_i18n('F j, Y'));
    $sections=[
        ['Information We Collect','We collect information you provide directly, such as your name, phone number, pickup and drop locations, and payment details, along with information generated when you use the platform, such as booking history and location data during an active trip.'],
        ['How We Use Your Information','We use your information to process bookings, verify your identity via OTP, communicate trip updates, provide customer support, and improve our services. We do not sell your personal information to third parties.'],
        ['Sharing With Vendors and Drivers','To fulfil a booking, we share the necessary trip details, such as your name, phone number and pickup/drop locations, with the assigned vendor and driver.'],
        ['Data Security','We use reasonable technical and organisational measures, including OTP-based verification and access controls, to protect your information from unauthorised access.'],
        ['Data Retention','We retain booking and account information for as long as your account is active and as needed to comply with legal and accounting obligations.'],
        ['Your Choices','You can review and update your profile information from your account settings at any time, and can contact us to request deletion of your account.'],
        ['Cookies','Our website and app may use cookies or local storage to keep you signed in and to remember your preferences.'],
        ['Changes to This Policy','We may update this privacy policy periodically. Material changes will be reflected by an updated "last updated" date above.'],
    ];
    $out='<div class="rg-wrap" style="max-width:820px;padding:40px 20px;">
    <h1 style="font-size:32px;font-weight:900;margin-bottom:4px;">Privacy Policy</h1>
    <p style="color:#9CA3AF;font-size:13px;margin-bottom:28px;">Last updated: '.esc_html($updated).'</p>
    <p style="color:#4B5563;font-size:14px;line-height:1.7;margin-bottom:22px;">This policy explains how '.esc_html($name).' collects, uses and protects your personal information when you use our platform.</p>';
    foreach($sections as $s){
        $out.='<div style="margin-bottom:22px;"><h2 style="font-size:18px;font-weight:800;margin-bottom:8px;">'.esc_html($s[0]).'</h2><p style="color:#4B5563;font-size:14px;line-height:1.7;margin:0;">'.esc_html($s[1]).'</p></div>';
    }
    $out.=($email?'<p style="margin-top:24px;color:#6B7280;font-size:14px;">Privacy questions? <a href="mailto:'.esc_attr($email).'" style="font-weight:700;">Contact us</a>.</p>':'').'</div>';
    return $out;
}

add_shortcode('ridego_cancel_policy','ridego_sc_cancel_policy');
function ridego_sc_cancel_policy($a){
    $name=ridego_get_setting('platform_name',get_bloginfo('name'));
    $email=ridego_get_setting('admin_email','');
    $sections=[
        ['Cancelling a Booking','You can cancel an upcoming trip from the "My Trips" section of your account at any time before the driver arrives. Once cancelled, the booking slot is released and the assigned vendor is notified immediately.'],
        ['Refunds','If you paid in advance and cancel before a driver has been dispatched, the amount is eligible for a refund to your original payment method. If a driver has already been assigned or has started travelling to your pickup location, a cancellation charge may apply to cover the vendor\'s costs; any such charge is deducted from the refund and the remainder returned to you.'],
        ['Driver or Vendor Cancellations','If a vendor or driver cancels a confirmed booking, you will be notified immediately and any amount already paid will be fully refunded. We will also try to help you rebook with another available vendor where possible.'],
        ['No-Shows','If you are not available at the pickup location within a reasonable waiting period after the scheduled time, the trip may be marked as a no-show, and the cancellation terms above apply.'],
        ['Rescheduling','Rescheduling a trip to a different date or time is treated as cancelling the original booking and creating a new one, so the cancellation terms above apply to the original slot.'],
    ];
    $out='<div class="rg-wrap" style="max-width:820px;padding:40px 20px;">
    <h1 style="font-size:32px;font-weight:900;margin-bottom:8px;">Cancellation Policy</h1>
    <p style="color:#6B7280;margin-bottom:28px;">How cancellations, refunds and no-shows are handled on '.esc_html($name).'.</p>';
    foreach($sections as $s){
        $out.='<div style="margin-bottom:22px;"><h2 style="font-size:18px;font-weight:800;margin-bottom:8px;">'.esc_html($s[0]).'</h2><p style="color:#4B5563;font-size:14px;line-height:1.7;margin:0;">'.esc_html($s[1]).'</p></div>';
    }
    $out.=($email?'<p style="margin-top:24px;color:#6B7280;font-size:14px;">Questions about a specific booking? <a href="mailto:'.esc_attr($email).'" style="font-weight:700;">Contact support</a>.</p>':'').'</div>';
    return $out;
}

add_shortcode('ridego_blog','ridego_sc_blog');
function ridego_sc_blog($a){
    $posts=get_posts(['post_type'=>'post','post_status'=>'publish','numberposts'=>12]);
    $out='<div class="rg-wrap" style="max-width:1000px;padding:40px 20px;">
    <h1 style="font-size:32px;font-weight:900;margin-bottom:8px;">Blog</h1>
    <p style="color:#6B7280;margin-bottom:28px;">News, travel tips and updates.</p>';
    if(empty($posts)){
        $out.='<div class="rg-alert rg-alert-info">No blog posts have been published yet. Check back soon, or <a href="'.esc_url(home_url()).'" style="font-weight:700;">return to the home page</a>.</div>';
    } else {
        $out.='<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px;">';
        foreach($posts as $p){
            $excerpt=wp_trim_words(wp_strip_all_tags($p->post_content),28);
            $thumb=get_the_post_thumbnail_url($p->ID,'medium');
            $out.='<a href="'.esc_url(get_permalink($p)).'" class="rg-card" style="text-decoration:none;color:inherit;display:block;overflow:hidden;padding:0;">'
                .($thumb?'<img src="'.esc_url($thumb).'" alt="'.esc_attr(get_the_title($p)).'" style="width:100%;height:160px;object-fit:cover;display:block;">':'')
                .'<div style="padding:18px;"><h2 style="font-size:16px;font-weight:800;margin-bottom:8px;">'.esc_html(get_the_title($p)).'</h2><p style="color:#6B7280;font-size:13px;line-height:1.6;margin:0;">'.esc_html($excerpt).'</p></div></a>';
        }
        $out.='</div>';
    }
    $out.='</div>';
    return $out;
}

add_shortcode('ridego_search','ridego_sc_search');
function ridego_sc_search($a){
    global $wpdb;
    $q=isset($_GET['q'])?sanitize_text_field(wp_unslash($_GET['q'])):'';
    $out='<div class="rg-wrap" style="max-width:820px;padding:40px 20px;">
    <h1 style="font-size:32px;font-weight:900;margin-bottom:8px;">Search</h1>
    <form method="get" style="display:flex;gap:10px;margin-bottom:28px;">
        <input type="text" name="q" value="'.esc_attr($q).'" placeholder="Search a city, e.g. Mumbai" style="flex:1;padding:14px 16px;border:1px solid #E5E7EB;border-radius:12px;font-size:15px;">
        <button type="submit" class="rg-btn rg-btn-primary" style="padding:14px 24px;">Search</button>
    </form>';
    if($q!==''){
        $like='%'.$wpdb->esc_like($q).'%';
        $cities=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT name FROM {$wpdb->prefix}ridego_cities WHERE is_active=1 AND name LIKE %s ORDER BY name ASC LIMIT 20",$like));
        if(!empty($cities)){
            $out.='<h2 style="font-size:16px;font-weight:800;margin-bottom:12px;">Cities matching "'.esc_html($q).'"</h2><div style="display:flex;flex-wrap:wrap;gap:10px;">';
            foreach($cities as $c){
                $out.='<a href="'.esc_url(add_query_arg('city',rawurlencode($c),home_url('/book/'))).'" style="text-decoration:none;padding:10px 16px;background:#EFF6FF;color:#1A56DB;border-radius:999px;font-size:14px;font-weight:700;">'.esc_html($c).'</a>';
            }
            $out.='</div>';
        } else {
            $out.='<div class="rg-alert rg-alert-info">No cities found matching "'.esc_html($q).'". Try a different search term, or <a href="'.esc_url(home_url('/book/')).'" style="font-weight:700;">browse all available cities</a>.</div>';
        }
    }
    $out.='</div>';
    return $out;
}

