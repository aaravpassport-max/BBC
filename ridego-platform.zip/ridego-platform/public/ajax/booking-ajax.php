<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   BOOKING AJAX HANDLERS
   ============================================================ */

/*  Calculate fare (live price calc)  */
add_action('wp_ajax_ridego_calc_fare',        'ridego_ajax_calc_fare');
add_action('wp_ajax_nopriv_ridego_calc_fare', 'ridego_ajax_calc_fare');
function ridego_ajax_calc_fare() {
    ridego_verify_nonce();
    $data = array(
        'trip_type'       => sanitize_key((isset($_POST['trip_type']) ? $_POST['trip_type'] : 'one_way')),
        'pickup_city'     => sanitize_text_field((isset($_POST['pickup_city']) ? $_POST['pickup_city'] : '')),
        'drop_city'       => sanitize_text_field((isset($_POST['drop_city']) ? $_POST['drop_city'] : '')),
        'vehicle_type_id' => intval((isset($_POST['vehicle_type_id']) ? $_POST['vehicle_type_id'] : 0)),
        'journey_date'    => sanitize_text_field(isset($_POST['journey_date']) ? $_POST['journey_date'] : date('Y-m-d')),
        'journey_time'    => sanitize_text_field((isset($_POST['journey_time']) ? $_POST['journey_time'] : '08:00')),
        'distance_km'     => (float)((isset($_POST['distance_km']) ? $_POST['distance_km'] : 0)),
        'duration_minutes'=> (int)((isset($_POST['duration_minutes']) ? $_POST['duration_minutes'] : 0)),
        'hours_required'  => (int)((isset($_POST['hours_required']) ? $_POST['hours_required'] : 4)),
        'return_date'     => sanitize_text_field((isset($_POST['return_date']) ? $_POST['return_date'] : '')),
        'passengers'      => (int)((isset($_POST['passengers']) ? $_POST['passengers'] : 1)),
        'promo_code'      => strtoupper(sanitize_text_field((isset($_POST['promo_code']) ? $_POST['promo_code'] : ''))),
    );
    if (!$data['vehicle_type_id']) { wp_send_json_error(array('message'=>'Select a vehicle first.')); }

    $fare = ridego_calculate_fare($data);
    if (isset($fare['error'])) { wp_send_json_error(array('message'=>$fare['error'])); }

    $discount = 0;
    if ($data['promo_code']) {
        // Live fare preview only — no promo_id is reserved/consumed here.
        // The actual redemption (ridego_record_promo_usage) happens
        // atomically inside ridego_create_booking() at submit time, which
        // is also why the discount shown here can still be silently
        // corrected on submit if the promo gets exhausted in between
        // (see the promo_adjusted flag surfaced on the confirmation page).
        $pr = ridego_validate_promo_code($data['promo_code'], $fare['base_fare'], $data, is_user_logged_in() ? get_current_user_id() : 0);
        if (!empty($pr['valid'])) {
            $discount = (float) $pr['discount_amount'];
            $fare['total_fare'] -= $discount;
            $fare['discount'] = $discount;
            // Same correction as includes/app-api.php's ridego_app_api_fare():
            // token_amount is a flat snapshot, not a percentage of the fare,
            // so a promo discount changes the total it's netted against.
            if (!empty($fare['token_enabled'])) {
                $fare['token_amount']     = min((float) $fare['token_amount'], max(0, (float) $fare['total_fare']));
                $fare['remaining_amount'] = max(0, (float) $fare['total_fare'] - (float) $fare['token_amount']);
            }
        } else {
            $fare['promo_error'] = isset($pr['error']) ? $pr['error'] : 'Invalid promo code';
        }
    }

    $sym = ridego_currency_symbol();
    $breakdown_html = '';
    foreach ($fare['breakdown'] as $label => $amount) {
        if ($amount <= 0) continue;
        $breakdown_html .= '<div class="ridego-fare-row"><span>'.$label.'</span><span>'.$sym.number_format($amount,2).'</span></div>';
    }
    if ($discount > 0) {
        $breakdown_html .= '<div class="ridego-fare-row ridego-fare-discount"><span>Promo Discount</span><span>- '.$sym.number_format($discount,2).'</span></div>';
    }
    $breakdown_html .= '<div class="ridego-fare-row ridego-fare-grand-total"><span>TOTAL RIDE AMOUNT</span><span>'.$sym.number_format($fare['total_fare'],2).'</span></div>';
    // Token Amount / Advance Payment: this legacy shortcode/jQuery booking
    // form previously always quoted the full total as "amount payable",
    // even when the token feature is on and only the token/advance is due
    // now — inconsistent with the React app's ConfirmPage for the exact
    // same booking/setting. Same non-fee wording, same numbers.
    if (!empty($fare['token_enabled'])) {
        $token_label = ridego_get_setting('token_label', 'Booking Token / Advance Payment');
        $breakdown_html .= '<div class="ridego-fare-row ridego-fare-token"><span>'.esc_html($token_label).' (to confirm booking)</span><span>'.$sym.number_format($fare['token_amount'],2).'</span></div>';
        $breakdown_html .= '<div class="ridego-fare-row ridego-fare-remaining"><span>Remaining (payable to driver/vendor)</span><span>'.$sym.number_format($fare['remaining_amount'],2).'</span></div>';
    }

    wp_send_json_success(array(
        'fare'           => $fare,
        'formatted'      => $sym . number_format($fare['total_fare'],2),
        'breakdown_html' => $breakdown_html,
        'sym'            => $sym,
    ));
}

/*  Get vehicles for passengers count  */
add_action('wp_ajax_ridego_get_vehicles',        'ridego_ajax_get_vehicles');
add_action('wp_ajax_nopriv_ridego_get_vehicles', 'ridego_ajax_get_vehicles');
function ridego_ajax_get_vehicles() {
    ridego_verify_nonce();
    $passengers = max(1,intval((isset($_POST['passengers']) ? $_POST['passengers'] : 1)));
    $vehicles   = ridego_get_vehicles(true);
    $result     = array();
    foreach ($vehicles as $v) {
        if ($v->seating_capacity < $passengers) continue;
        $feats = json_decode($v->features, true);
        $result[] = array(
            'id'            => $v->id,
            'name'          => $v->name,
            'slug'          => $v->slug,
            'icon_url'      => $v->icon_url,
            'capacity'      => $v->seating_capacity,
            'luggage'       => $v->luggage_capacity,
            'ac'            => (bool)$v->ac_available,
            'features'      => is_array($feats) ? $feats : array(),
            'price_from'    => ridego_currency_symbol() . number_format($v->base_price_per_km * 50,0) . '+',
        );
    }
    wp_send_json_success($result);
}

/*  Get cities for autocomplete  */
add_action('wp_ajax_ridego_get_cities',        'ridego_ajax_get_cities');
add_action('wp_ajax_nopriv_ridego_get_cities', 'ridego_ajax_get_cities');
function ridego_ajax_get_cities() {
    ridego_verify_nonce();
    $cities = ridego_get_cities(true);
    $result = array();
    foreach ($cities as $c) {
        $result[] = array('id'=>$c->id,'name'=>$c->name,'state'=>$c->state,'slug'=>$c->slug);
    }
    wp_send_json_success($result);
}

/*  Submit booking  */
add_action('wp_ajax_ridego_submit_booking',        'ridego_ajax_submit_booking');
add_action('wp_ajax_nopriv_ridego_submit_booking', 'ridego_ajax_submit_booking');
function ridego_ajax_submit_booking() {
    // The main booking form (public/shortcodes.php) mints its nonce under
    // the 'ridego_booking_nonce' action via the rg_nonce field, while the
    // multi-step booking-confirm.php flow mints under 'ridego_nonce'. Both
    // genuinely submit to this same endpoint, so this call site explicitly
    // opts into accepting either — unlike the old blanket fallback, this is
    // scoped to just this one handler rather than silently applying to every
    // ridego_verify_nonce() call in the plugin.
    ridego_verify_nonce( 'ridego_nonce', array( 'ridego_booking_nonce' ) );

    /* Rate limit: bound how many booking submissions a single phone or IP
       can make in a short window, independent of OTP/trust state — an
       already-trusted/verified phone should still not be able to fire
       unlimited booking submissions. */
    $phone_for_rl = ridego_sanitize_phone((isset($_POST['client_phone']) ? $_POST['client_phone'] : ''));
    $ip_for_rl    = ridego_get_client_ip();
    $rl_phone = $phone_for_rl ? ridego_check_rate_limit('booking_submit_phone', $phone_for_rl, 5, 600) : array('allowed'=>true);
    $rl_ip    = ridego_check_rate_limit('booking_submit_ip', $ip_for_rl, 5, 600);
    if ( empty($rl_phone['allowed']) || empty($rl_ip['allowed']) ) {
        wp_send_json_error(array('message'=>'Too many booking attempts. Please wait a few minutes and try again.'));
    }

    /* OTP verification check — phone and email gates are checked
       independently (see ridego_booking_requires_otp() /
       ridego_booking_requires_email_otp()) so any combination of the two
       admin toggles (both off, either alone, or both on) is enforced with
       no hardcoded requirement for either channel. */
    $phone = ridego_sanitize_phone((isset($_POST['client_phone']) ? $_POST['client_phone'] : ''));
    $email = sanitize_email((isset($_POST['client_email']) ? $_POST['client_email'] : ''));
    if (ridego_booking_requires_otp($phone)) {
        $otp_val = sanitize_text_field((isset($_POST['otp_value']) ? $_POST['otp_value'] : ''));
        if (!$otp_val) {
            wp_send_json_error(array('message'=>'Phone verification required. Please verify your number.','need_otp'=>true));
        }
        $otp_check = ridego_verify_otp($phone, $otp_val, 'booking');
        if (!$otp_check['success']) {
            wp_send_json_error(array('message'=>$otp_check['message'],'need_otp'=>true));
        }
    }
    if (ridego_booking_requires_email_otp($email)) {
        $email_otp_val = sanitize_text_field((isset($_POST['email_otp_value']) ? $_POST['email_otp_value'] : ''));
        if (!$email_otp_val) {
            wp_send_json_error(array('message'=>'Email verification required. Please verify your email address.','need_email_otp'=>true));
        }
        $email_otp_check = ridego_verify_email_otp($email, $email_otp_val, 'booking');
        if (!$email_otp_check['success']) {
            wp_send_json_error(array('message'=>$email_otp_check['error'],'need_email_otp'=>true));
        }
    }

    $data = ridego_sanitize_booking_input($_POST);
    /* Distance from POST (calculated by Maps JS) */
    $data['distance_km']      = (float)((isset($_POST['distance_km']) ? $_POST['distance_km'] : 0));
    $data['duration_minutes'] = (int)((isset($_POST['duration_minutes']) ? $_POST['duration_minutes'] : 0));

    $result = ridego_create_booking($data);
    wp_send_json($result['success'] ? array('success'=>true,'data'=>$result) : array('success'=>false,'data'=>array('message'=>$result['message'])));
}

/*  Send OTP  */
add_action('wp_ajax_ridego_send_otp',        'ridego_ajax_send_otp');
add_action('wp_ajax_nopriv_ridego_send_otp', 'ridego_ajax_send_otp');
function ridego_ajax_send_otp() {
    ridego_verify_nonce();
    $phone   = ridego_sanitize_phone((isset($_POST['phone']) ? $_POST['phone'] : ''));
    $purpose = sanitize_key((isset($_POST['purpose']) ? $_POST['purpose'] : 'booking'));
    if (!$phone) { wp_send_json_error(array('message'=>'Phone number required.')); }
    if (ridego_is_trusted_phone($phone)) {
        wp_send_json_success(array('message'=>'Phone already verified on this device.','trusted'=>true));
    }
    $result = ridego_generate_otp($phone, $purpose);
    if ($result['success']) wp_send_json_success($result);
    else wp_send_json_error($result);
}

/*  Verify OTP  */
/* NOTE: canonical definition is in includes/otp.php (loaded earlier). */
add_action('wp_ajax_ridego_verify_otp',        'ridego_ajax_verify_otp');
add_action('wp_ajax_nopriv_ridego_verify_otp', 'ridego_ajax_verify_otp');
if ( ! function_exists('ridego_ajax_verify_otp') ) :
function ridego_ajax_verify_otp() {
    ridego_verify_nonce();
    $phone   = ridego_sanitize_phone((isset($_POST['phone']) ? $_POST['phone'] : ''));
    $otp     = sanitize_text_field((isset($_POST['otp']) ? $_POST['otp'] : ''));
    $purpose = sanitize_key((isset($_POST['purpose']) ? $_POST['purpose'] : 'booking'));
    $result  = ridego_verify_otp($phone, $otp, $purpose);
    if ($result['success']) wp_send_json_success($result);
    else wp_send_json_error($result);
}
endif; // function_exists ridego_ajax_verify_otp

/*  Validate promo code  */
/* NOTE: canonical validator is ridego_validate_promo_code() in
   includes/promo.php — this endpoint previously called a
   ridego_validate_promo() that was never defined anywhere, crashing every
   request to it (the AJAX-registered action was reachable and live, even
   though the fare-preview flow uses ridego_ajax_calc_fare() instead — see
   its matching fix). */
add_action('wp_ajax_ridego_validate_promo',        'ridego_ajax_validate_promo');
add_action('wp_ajax_nopriv_ridego_validate_promo', 'ridego_ajax_validate_promo');
if ( ! function_exists('ridego_ajax_validate_promo') ) :
function ridego_ajax_validate_promo() {
    ridego_verify_nonce();
    $code      = strtoupper(sanitize_text_field((isset($_POST['code']) ? $_POST['code'] : '')));
    $amount    = (float)((isset($_POST['amount']) ? $_POST['amount'] : 0));
    $trip_type = sanitize_key((isset($_POST['trip_type']) ? $_POST['trip_type'] : ''));
    $params    = array('trip_type' => $trip_type);
    $result    = ridego_validate_promo_code($code, $amount, $params, is_user_logged_in() ? get_current_user_id() : 0);
    if (!empty($result['valid'])) {
        $discount = (float) $result['discount_amount'];
        wp_send_json_success(array('discount'=>$discount,'message'=>'Promo code applied! You save '.ridego_currency_symbol().number_format($discount,2)));
    } else {
        wp_send_json_error(array('message'=> isset($result['error']) ? $result['error'] : 'Invalid promo code'));
    }
}
endif; // function_exists ridego_ajax_validate_promo

/*  Get booking details (for confirm page)  */
add_action('wp_ajax_ridego_get_booking',        'ridego_ajax_get_booking');
add_action('wp_ajax_nopriv_ridego_get_booking', 'ridego_ajax_get_booking');
function ridego_ajax_get_booking() {
    ridego_verify_nonce();
    $number = sanitize_text_field((isset($_POST['booking_number']) ? $_POST['booking_number'] : ''));
    if (!$number) { wp_send_json_error(array('message'=>'Booking number required.')); }
    $booking = ridego_get_booking_by_number($number);
    if (!$booking) { wp_send_json_error(array('message'=>'Booking not found.')); }

    /* A booking_number is not a secret (it's shown/shared for tracking),
       so anyone who has it — not just the actual client — can hit this
       endpoint. Only hand back the full record (client phone/email,
       addresses, and critically the pickup OTP) once the requester has
       proven they are the client: logged in as the owner, or just OTP-
       verified/trusted for the booking's phone number (which is exactly
       the state right after that same visitor submitted this booking).
       Everyone else gets a safe public status projection. */
    if ( ! ridego_requester_verified_for_booking( $booking ) ) {
        $vehicle = ridego_get_vehicle( (int) $booking->vehicle_type_id );
        wp_send_json_success(array(
            'booking' => array(
                'booking_number'  => $booking->booking_number,
                'status'          => $booking->status,
                'trip_type'       => $booking->trip_type,
                'pickup_city'     => $booking->pickup_city,
                'drop_city'       => $booking->drop_city,
                'journey_date'    => $booking->journey_date,
                'journey_time'    => $booking->journey_time,
                'vehicle_name'    => $vehicle ? $vehicle->name : '',
                'total_fare'      => $booking->total_fare,
                'token_amount'    => $booking->token_amount,
                'payment_status'  => $booking->payment_status,
            ),
            'limited' => true,
        ));
    }

    // Token Amount / Advance Payment: same amount-due-now projection as
    // ridego_get_booking_payment_context() (includes/helpers.php), which
    // feeds the React ConfirmPage — kept consistent here so this legacy
    // shortcode-based confirm template shows the same numbers/wording for
    // the same booking rather than quoting the full total_fare.
    $token_active   = (float) $booking->token_amount > 0;
    $amount_due_now = $token_active ? (float) $booking->token_amount : (float) $booking->total_fare;
    wp_send_json_success(array(
        'booking'            => $booking,
        'bank_name'          => ridego_get_setting('bank_name'),
        'bank_account'       => ridego_get_setting('bank_account'),
        'bank_ifsc'          => ridego_get_setting('bank_ifsc'),
        'bank_holder'        => ridego_get_setting('bank_holder'),
        'upi_id'             => ridego_get_setting('upi_id'),
        'upi_qr_url'         => ridego_get_setting('upi_qr_url'),
        'amount'             => round($amount_due_now, 2),
        'is_token_payment'   => $token_active,
        'token_amount'       => round((float) $booking->token_amount, 2),
        'remaining_amount'   => round(max(0, (float) $booking->total_fare - (float) $booking->token_amount), 2),
        'token_label'        => ridego_get_setting('token_label', 'Booking Token / Advance Payment'),
        'token_instructions' => ridego_get_setting('token_instructions', ''),
    ));
}

/*  Submit payment proof  */
add_action('wp_ajax_ridego_submit_proof',        'ridego_ajax_submit_proof');
add_action('wp_ajax_nopriv_ridego_submit_proof', 'ridego_ajax_submit_proof');
function ridego_ajax_submit_proof() {
    ridego_verify_nonce();
    $bid = intval((isset($_POST['booking_id']) ? $_POST['booking_id'] : 0));
    if (!$bid || empty($_FILES['proof_file']['tmp_name'])) {
        wp_send_json_error(array('message'=>'Booking ID and payment proof file are required.'));
    }
    $booking = ridego_get_booking($bid);
    if (!$booking) { wp_send_json_error(array('message'=>'Booking not found.')); }

    /* Ownership binding: without this, anyone who knows/guesses a
       booking_id can submit fabricated payment proof against a
       stranger's booking. Same check used to gate full booking details. */
    if ( ! ridego_requester_verified_for_booking( $booking ) ) {
        wp_send_json_error(array('message'=>'We could not verify this is your booking. Please verify your phone number first.','need_phone'=>true));
    }

    $result = ridego_submit_payment_proof($bid, $_FILES['proof_file'], $_POST);
    if ($result['success']) wp_send_json_success($result);
    else wp_send_json_error($result);
}

/*  Admin: verify / reject payment  */
add_action('wp_ajax_ridego_admin_verify_payment', 'ridego_ajax_admin_verify_payment');
function ridego_ajax_admin_verify_payment() {
    ridego_verify_admin_nonce();
    $bid    = intval((isset($_POST['booking_id']) ? $_POST['booking_id'] : 0));
    $action = sanitize_key((isset($_POST['payment_action']) ? $_POST['payment_action'] : ''));
    $reason = sanitize_textarea_field((isset($_POST['reason']) ? $_POST['reason'] : ''));
    if ($action === 'verify') {
        ridego_verify_payment($bid, get_current_user_id());
        wp_send_json_success(array('message'=>'Payment verified. Booking confirmed. Lead distribution started.'));
    } elseif ($action === 'reject') {
        ridego_reject_payment($bid, $reason, get_current_user_id());
        wp_send_json_success(array('message'=>'Payment proof rejected. Client notified.'));
    } else {
        wp_send_json_error(array('message'=>'Invalid action.'));
    }
}

/*  Cancel booking  */
add_action('wp_ajax_ridego_cancel_booking',        'ridego_ajax_cancel_booking');
add_action('wp_ajax_nopriv_ridego_cancel_booking', 'ridego_ajax_cancel_booking');
function ridego_ajax_cancel_booking() {
    ridego_verify_nonce();
    $bid    = intval((isset($_POST['booking_id']) ? $_POST['booking_id'] : 0));
    $reason = sanitize_textarea_field((isset($_POST['reason']) ? $_POST['reason'] : 'Client requested cancellation'));
    $booking= ridego_get_booking($bid);
    if (!$booking) { wp_send_json_error(array('message'=>'Booking not found.')); }

    $is_admin = current_user_can('manage_options');
    /* client_id > 0 is required explicitly here — never let a bare
       (int)$booking->client_id === get_current_user_id() comparison
       decide ownership. A guest booking has client_id=0, and an
       anonymous visitor's get_current_user_id() is also 0, so that
       comparison alone would silently pass ("0 === 0") and let anyone
       cancel any guest booking just by knowing its booking_id. */
    $is_owner = ( (int) $booking->client_id > 0 ) && ( (int) $booking->client_id === get_current_user_id() );

    if ( ! $is_admin && ! $is_owner ) {
        if ( (int) $booking->client_id === 0 ) {
            /* Guest booking: prove ownership by re-verifying the phone
               number on file for this booking, via the same OTP
               mechanism used everywhere else in the booking flow. */
            $phone = ridego_sanitize_phone((isset($_POST['client_phone']) ? $_POST['client_phone'] : ''));
            if ( ! $phone || ridego_clean_phone_number($phone) !== ridego_clean_phone_number($booking->client_phone) ) {
                wp_send_json_error(array('message'=>'Enter the phone number used for this booking to cancel it.','need_phone'=>true));
            }
            if ( ! ridego_validate_otp_session($phone, 'booking_cancel', 10) ) {
                $otp_val = sanitize_text_field((isset($_POST['otp_value']) ? $_POST['otp_value'] : ''));
                if ( ! $otp_val ) {
                    wp_send_json_error(array('message'=>'OTP verification required to cancel this booking.','need_otp'=>true));
                }
                $otp_check = ridego_verify_otp($phone, $otp_val, 'booking_cancel');
                if ( empty($otp_check['success']) ) {
                    wp_send_json_error(array('message'=> isset($otp_check['error']) ? $otp_check['error'] : 'Invalid OTP.', 'need_otp'=>true));
                }
            }
        } else {
            wp_send_json_error(array('message'=>'Permission denied.'));
        }
    }
    $by = $is_admin ? 'admin' : 'client';
    // Ownership was already fully established above (logged-in owner match,
    // or guest phone+OTP re-verification) before reaching this line — every
    // path that could NOT prove ownership already exited via
    // wp_send_json_error(). Passing the booking's own client_id here is
    // therefore safe by construction, not a bypass: it's just handing
    // ridego_cancel_booking() the id this request already proved it owns.
    $result = ridego_cancel_booking($bid, $reason, $by, $by === 'client' ? (int) $booking->client_id : null);
    if ($result['success']) wp_send_json_success($result);
    else wp_send_json_error($result);
}

/*  Rate booking  */
add_action('wp_ajax_ridego_rate_booking', 'ridego_ajax_rate_booking');
function ridego_ajax_rate_booking() {
    ridego_verify_nonce();
    if (!is_user_logged_in()) { wp_send_json_error(array('message'=>'Login required.')); }
    $bid    = intval((isset($_POST['booking_id']) ? $_POST['booking_id'] : 0));
    $score  = intval((isset($_POST['score']) ? $_POST['score'] : 5));
    $review = sanitize_textarea_field((isset($_POST['review']) ? $_POST['review'] : ''));
    $result = ridego_rate_booking($bid, $score, $review, get_current_user_id());
    if ($result['success']) wp_send_json_success($result);
    else wp_send_json_error($result);
}

/* Load AJAX file */
add_action('init', function(){
    $ajax_file = RIDEGO_PATH . 'public/ajax/booking-ajax.php';
    if (file_exists($ajax_file) && !did_action('ridego_booking_ajax_loaded')) {
        do_action('ridego_booking_ajax_loaded');
    }
});

/*  Save route cache (called by Maps JS)  */
add_action('wp_ajax_ridego_save_route_cache_ajax',        'ridego_ajax_save_route_cache');
add_action('wp_ajax_nopriv_ridego_save_route_cache_ajax', 'ridego_ajax_save_route_cache');
function ridego_ajax_save_route_cache() {
    ridego_verify_nonce();
    $from = sanitize_text_field((isset($_POST['from_city']) ? $_POST['from_city'] : ''));
    $to   = sanitize_text_field((isset($_POST['to_city']) ? $_POST['to_city'] : ''));
    $dist = (float)((isset($_POST['distance_km']) ? $_POST['distance_km'] : 0));
    $dur  = (int)((isset($_POST['duration_min']) ? $_POST['duration_min'] : 0));
    if ($from && $to && $dist > 0) {
        ridego_save_route_cache($from, $to, $dist, $dur);
    }
    wp_send_json_success();
}
