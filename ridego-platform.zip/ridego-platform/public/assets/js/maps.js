/**
 * RideGo Maps JS — Google Places Autocomplete + Distance Matrix
 * Loaded only on booking pages. Requires Google Maps JS API.
 */
var ridego_maps_init;

(function($){
'use strict';

var MAPS = {
    autocompletes : {},
    distService   : null,
    geocoder      : null,

    init: function(){
        if(typeof google === 'undefined' || typeof google.maps === 'undefined') return;
        this.distService = new google.maps.DistanceMatrixService();
        this.geocoder    = new google.maps.Geocoder();
        this.attachAutocomplete('ridego-pickup-address', 'pickup');
        this.attachAutocomplete('ridego-drop-address',   'drop');
        this.attachAutocomplete('ridego-pickup-city',    'pickup_city');
        this.attachAutocomplete('ridego-drop-city',      'drop_city');
    },

    attachAutocomplete: function(inputId, type){
        var el = document.getElementById(inputId);
        if(!el) return;
        var options = {
            componentRestrictions : { country: 'in' },
            fields                : ['geometry','name','formatted_address'],
        };
        /* For city inputs, restrict to cities */
        if(type === 'pickup_city' || type === 'drop_city'){
            options.types = ['(cities)'];
        }
        var ac = new google.maps.places.Autocomplete(el, options);
        this.autocompletes[type] = ac;

        var self = this;
        ac.addListener('place_changed', function(){
            var place = ac.getPlace();
            if(!place.geometry) return;
            var lat = place.geometry.location.lat();
            var lng = place.geometry.location.lng();
            var name= place.name || el.value;

            if(type === 'pickup_city'){
                $('#ridego-pickup-lat').val(lat);
                $('#ridego-pickup-lng').val(lng);
                $('#ridego-pickup-city').val(name);
            } else if(type === 'drop_city'){
                $('#ridego-drop-lat').val(lat);
                $('#ridego-drop-lng').val(lng);
                $('#ridego-drop-city').val(name);
                self.calcDistance();
            } else if(type === 'pickup'){
                $('#ridego-pickup-lat').val(lat);
                $('#ridego-pickup-lng').val(lng);
            } else if(type === 'drop'){
                $('#ridego-drop-lat').val(lat);
                $('#ridego-drop-lng').val(lng);
                self.calcDistance();
            }
        });
    },

    calcDistance: function(){
        var self   = this;
        var pickup = this.getPickupLocation();
        var drop   = this.getDropLocation();
        if(!pickup || !drop) return;

        $('#ridego-distance-display').text('Calculating...').show();

        this.distService.getDistanceMatrix({
            origins      : [pickup],
            destinations : [drop],
            travelMode   : google.maps.TravelMode.DRIVING,
            unitSystem   : google.maps.UnitSystem.METRIC,
        }, function(response, status){
            if(status !== 'OK') return;
            var element = response.rows[0].elements[0];
            if(element.status !== 'OK') return;

            var distance_m   = element.distance.value;
            var duration_s   = element.duration.value;
            var distance_km  = Math.round(distance_m / 1000 * 10) / 10;
            var duration_min = Math.round(duration_s / 60);

            $('#ridego-hidden-distance').val(distance_km);
            $('#ridego-hidden-duration').val(duration_min);
            $('#ridego-distance-display').text(distance_km + ' km | ~' + self.formatDuration(duration_min));

            /* Save to route cache (AJAX) */
            var from = $('#ridego-pickup-city').val();
            var to   = $('#ridego-drop-city').val();
            if(from && to){
                $.post(RIDEGO.ajax_url,{
                    action      : 'ridego_save_route_cache',
                    nonce       : RIDEGO.nonce,
                    from_city   : from,
                    to_city     : to,
                    distance_km : distance_km,
                    duration_min: duration_min,
                });
            }

            /* Trigger fare recalculation */
            $(document).trigger('ridego:distance_calculated', [distance_km, duration_min]);
            if(typeof BOOKING !== 'undefined') BOOKING.scheduleFareCalc();
        });
    },

    getPickupLocation: function(){
        var lat = parseFloat($('#ridego-pickup-lat').val());
        var lng = parseFloat($('#ridego-pickup-lng').val());
        var addr= $('#ridego-pickup-address').val() || $('#ridego-pickup-city').val();
        if(lat && lng) return new google.maps.LatLng(lat, lng);
        if(addr)       return addr;
        return null;
    },

    getDropLocation: function(){
        var lat = parseFloat($('#ridego-drop-lat').val());
        var lng = parseFloat($('#ridego-drop-lng').val());
        var addr= $('#ridego-drop-address').val() || $('#ridego-drop-city').val();
        if(lat && lng) return new google.maps.LatLng(lat, lng);
        if(addr)       return addr;
        return null;
    },

    formatDuration: function(minutes){
        if(minutes < 60)  return minutes + ' min';
        var hrs = Math.floor(minutes/60);
        var min = minutes % 60;
        return hrs + 'h ' + (min > 0 ? min + 'm' : '');
    },

    /* Draw route on map (for tracking/confirmation pages) */
    drawRoute: function(mapEl, pickup_lat, pickup_lng, drop_lat, drop_lng){
        if(!mapEl || typeof google === 'undefined') return;
        var map = new google.maps.Map(mapEl, { zoom:10, mapTypeId:'roadmap' });
        var directionsService  = new google.maps.DirectionsService();
        var directionsRenderer = new google.maps.DirectionsRenderer();
        directionsRenderer.setMap(map);
        directionsService.route({
            origin     : new google.maps.LatLng(pickup_lat, pickup_lng),
            destination: new google.maps.LatLng(drop_lat,   drop_lng),
            travelMode : google.maps.TravelMode.DRIVING,
        }, function(result, status){
            if(status === 'OK') directionsRenderer.setDirections(result);
        });
        return map;
    },
};

/* Called by Google Maps API callback */
ridego_maps_init = function(){
    MAPS.init();
    /* Make available globally for other scripts */
    window.RIDEGO_MAPS = MAPS;
};

/* Route cache AJAX handler */
$(document).ready(function(){
    if(typeof RIDEGO !== 'undefined'){
        /* Register route cache save handler */
        $(document).on('ridego:save_route_cache', function(e, data){
            $.post(RIDEGO.ajax_url,{
                action      : 'ridego_save_route_cache_ajax',
                nonce       : RIDEGO.nonce,
                from_city   : data.from,
                to_city     : data.to,
                distance_km : data.distance,
                duration_min: data.duration,
            });
        });
    }
});

})(jQuery);
