/**
 * RideGo Payment JS
 * Countdown timer, drag-drop proof upload, copy buttons
 */
(function($){
'use strict';

/* ── Copy to clipboard ─────────────────────────── */
$(document).on('click','.rg-copy-btn',function(){
    var text=$(this).data('copy'); if(!text)return;
    var $btn=$(this);
    if(navigator.clipboard&&navigator.clipboard.writeText){
        navigator.clipboard.writeText(text).then(function(){$btn.text('Copied!').css('color','#10b981');setTimeout(function(){$btn.text('Copy').css('color','');},2000);});
    } else {
        var $ta=$('<textarea style="position:fixed;top:-999px;">').val(text).appendTo('body');
        $ta[0].select();document.execCommand('copy');$ta.remove();
        $btn.text('Copied!').css('color','#10b981');setTimeout(function(){$btn.text('Copy').css('color','');},2000);
    }
});

/* ── Countdown Timer ───────────────────────────── */
function initCountdown(){
    var $timer=$('#rg-countdown'); if(!$timer.length)return;
    var secs=parseInt($timer.data('seconds'))||0;
    if(secs<=0){$timer.closest('.rg-card').html('<p style="text-align:center;color:#ef4444;font-weight:700;padding:20px;">Payment window expired.</p>');return;}
    function tick(){
        if(secs<=0){$timer.closest('.rg-card').html('<div style="text-align:center;padding:20px;"><p style="color:#ef4444;font-weight:700;">Payment deadline passed.</p><p style="font-size:13px;color:#64748b;">Please contact support or rebook.</p></div>');return;}
        var h=Math.floor(secs/3600),m=Math.floor((secs%3600)/60),s=secs%60;
        $('#rg-count-h').text(('0'+h).slice(-2));
        $('#rg-count-m').text(('0'+m).slice(-2));
        $('#rg-count-s').text(('0'+s).slice(-2));
        if(secs<1800){$('.rg-count-num').css('color','#ef4444');$('.rg-count-sep,.rg-count-lbl').css('color','#ef4444');}
        secs--;setTimeout(tick,1000);
    }
    tick();
}

/* ── File Upload Preview ───────────────────────── */
function initFileUpload(){
    var $area=$('#rg-upload-area'),$input=$('#rg-proof-file');
    var $preview=$('#rg-upload-preview'),$ph=$('#rg-upload-placeholder');
    if(!$area.length)return;

    $area.on('dragover dragenter',function(e){e.preventDefault();e.stopPropagation();$area.addClass('rg-upload-drag');});
    $area.on('dragleave dragend',function(){$area.removeClass('rg-upload-drag');});
    $area.on('drop',function(e){
        e.preventDefault();e.stopPropagation();$area.removeClass('rg-upload-drag');
        var files=e.originalEvent.dataTransfer.files;
        if(files.length)showPreview(files[0],$input,files);
    });
    $input.on('change',function(){if(this.files.length)showPreview(this.files[0]);});
    $(document).on('click','#rg-remove-file',function(){$input.val('');$preview.hide();$ph.show();});

    function showPreview(file,$inp,files){
        if(file.size>2*1024*1024){showMsg('error','File too large. Maximum 2MB allowed.');return;}
        $ph.hide();$preview.show();
        $('#rg-preview-name').text(file.name+' ('+Math.round(file.size/1024)+'KB)');
        if(file.type.startsWith('image/')){
            var r=new FileReader();
            r.onload=function(e){$('#rg-preview-img').attr('src',e.target.result).show();};
            r.readAsDataURL(file);
        } else {
            $('#rg-preview-img').hide();
        }
    }
}

/* ── Submit Proof Form ─────────────────────────── */
function initProofSubmit(){
    $(document).on('submit','#rg-proof-form',function(e){
        e.preventDefault();
        var file=document.getElementById('rg-proof-file');
        var utr=$('#rg-utr').val().trim();
        var app=$('#rg-payment-app').val();
        if(!file||!file.files.length){showMsg('error','Please upload your payment screenshot.');return;}
        if(!utr||utr.length<6){showMsg('error','Enter a valid UTR / Transaction ID (min 6 characters).');return;}
        if(!app){showMsg('error','Please select the payment app you used.');return;}
        var fd=new FormData(this);
        fd.append('action','ridego_submit_proof');
        fd.append('nonce',RG_CONFIRM.nonce);
        showMsg('loading','Uploading proof...');
        $('#rg-proof-submit').prop('disabled',true).text('Uploading...');
        $.ajax({
            url:RG_CONFIRM.ajax_url,type:'POST',data:fd,processData:false,contentType:false,
            success:function(r){
                $('#rg-proof-submit').prop('disabled',false).text('Submit Payment Proof');
                if(r.success){
                    showMsg('success',r.data.message||'Proof submitted! Verification within 30 minutes.');
                    setTimeout(function(){
                        $('#rg-proof-card').html('<div class="rg-card-title" style="font-size:15px;font-weight:700;margin-bottom:12px;">Proof Submitted</div><div style="text-align:center;padding:20px;"><div style="font-size:48px;margin-bottom:12px;">&#128338;</div><h3 style="margin:0 0 8px;">Verification in Progress</h3><p style="color:#64748b;font-size:13px;">We will verify within 30 minutes and confirm your booking.</p><p style="font-size:13px;">UTR: <strong>'+$('#rg-utr').val()+'</strong></p></div>');
                    },2000);
                } else {
                    showMsg('error',r.data&&r.data.message?r.data.message:'Upload failed. Please try again.');
                }
            },
            error:function(){$('#rg-proof-submit').prop('disabled',false).text('Submit Payment Proof');showMsg('error','Connection error. Please try again.');}
        });
    });
}

function showMsg(type,text){
    var $m=$('#rg-proof-msg');
    var cls={success:'rg-msg-success',error:'rg-msg-error',loading:'rg-msg-loading'};
    $m.attr('class','rg-msg '+(cls[type]||'')).text(text).show();
    if(type!=='loading')setTimeout(function(){$m.fadeOut();},5000);
}

$(document).ready(function(){
    initCountdown();
    initFileUpload();
    initProofSubmit();
});
$('<style>.rg-upload-drag{border-color:#6366f1!important;background:#eff6ff!important;}</style>').appendTo('head');
})(jQuery);
