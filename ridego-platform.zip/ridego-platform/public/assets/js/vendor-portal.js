/* RideGo Vendor Portal JS v1.0.0 */
(function($){
'use strict';
$(document).ready(function(){
    /* Countdown timers on lead cards */
    $('.rg-lead-timer').each(function(){
        var $el=$(this);
        var secs=parseInt($el.data('seconds')||0);
        if(!secs) return;
        var iv=setInterval(function(){
            secs--;
            if(secs<=0){clearInterval(iv);$el.text('Expired');$el.closest('.rg-lead-card').css('opacity',.5);return;}
            var h=Math.floor(secs/3600),m=Math.floor((secs%3600)/60),s=secs%60;
            var t=secs>=3600?(pad(h)+':'+pad(m)+':'+pad(s)):(pad(m)+':'+pad(s));
            $el.text('⏱ '+t+' left');
            if(secs<300) $el.css('color','#dc2626');
        },1000);
    });
    function pad(n){return n<10?'0'+n:n;}
});
})(jQuery);
