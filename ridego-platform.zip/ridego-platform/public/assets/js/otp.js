/**
 * RideGo OTP JS
 * 6-digit input widget, auto-advance, resend countdown, verify
 */
(function($){
'use strict';

var OTP = {
    phone      : '',
    purpose    : 'booking',
    verified   : false,
    resendTimer: null,

    init: function(){
        this.render();
        this.bindEvents();
    },

    render: function(){
        /* If a container exists for the OTP widget, build it */
        var $wrap = $('#ridego-otp-widget');
        if (!$wrap.length) return;

        $wrap.html(
            '<div class="rg-otp-widget">' +
            '<div class="rg-otp-phone-row">' +
            '  <input type="tel" id="rg-otp-phone-input" class="rg-otp-phone-field" placeholder="+91 XXXXX XXXXX" maxlength="15">' +
            '  <button type="button" id="rg-otp-send-btn" class="rg-otp-send-btn">Send OTP</button>' +
            '</div>' +
            '<div id="rg-otp-boxes-row" class="rg-otp-boxes-row" style="display:none;">' +
            '  <div class="rg-otp-boxes">' +
            '    <input type="number" class="rg-otp-box" maxlength="1" min="0" max="9" data-index="0">' +
            '    <input type="number" class="rg-otp-box" maxlength="1" min="0" max="9" data-index="1">' +
            '    <input type="number" class="rg-otp-box" maxlength="1" min="0" max="9" data-index="2">' +
            '    <input type="number" class="rg-otp-box" maxlength="1" min="0" max="9" data-index="3">' +
            '    <input type="number" class="rg-otp-box" maxlength="1" min="0" max="9" data-index="4">' +
            '    <input type="number" class="rg-otp-box" maxlength="1" min="0" max="9" data-index="5">' +
            '  </div>' +
            '  <button type="button" id="rg-otp-verify-btn" class="rg-otp-verify-btn">Verify OTP</button>' +
            '</div>' +
            '<div id="rg-otp-resend-row" class="rg-otp-resend-row" style="display:none;">' +
            '  Resend OTP in <span id="rg-otp-countdown">30</span>s &nbsp;|&nbsp; ' +
            '  <button type="button" id="rg-otp-resend-btn" class="rg-otp-resend-link" disabled>Resend</button>' +
            '</div>' +
            '<div id="rg-otp-msg" class="rg-otp-msg" style="display:none;"></div>' +
            '<input type="hidden" id="ridego-otp-value" name="otp_value">' +
            '<input type="hidden" id="ridego-otp-verified" name="otp_verified" value="0">' +
            '</div>'
        );

        /* Add OTP styles */
        if (!$('#rg-otp-style').length) {
            $('<style id="rg-otp-style">'+
            '.rg-otp-widget{margin:16px 0;}'+
            '.rg-otp-phone-row{display:flex;gap:8px;margin-bottom:10px;}'+
            '.rg-otp-phone-field{flex:1;border:1px solid #d1d5db;border-radius:8px;padding:10px 14px;font-size:14px;color:#0f172a;}'+
            '.rg-otp-phone-field:focus{border-color:#6366f1;box-shadow:0 0 0 3px rgba(99,102,241,.12);outline:none;}'+
            '.rg-otp-send-btn{background:#6366f1;color:#fff;border:none;border-radius:8px;padding:10px 20px;font-size:14px;font-weight:600;cursor:pointer;white-space:nowrap;}'+
            '.rg-otp-send-btn:hover{background:#4f46e5;}'+
            '.rg-otp-send-btn:disabled{opacity:.5;cursor:default;}'+
            '.rg-otp-boxes-row{display:flex;gap:10px;align-items:center;margin-bottom:10px;flex-wrap:wrap;}'+
            '.rg-otp-boxes{display:flex;gap:8px;}'+
            '.rg-otp-box{width:44px;height:52px;border:2px solid #d1d5db;border-radius:10px;text-align:center;font-size:22px;font-weight:700;color:#0f172a;-moz-appearance:textfield;}'+
            '.rg-otp-box::-webkit-outer-spin-button,.rg-otp-box::-webkit-inner-spin-button{-webkit-appearance:none;}'+
            '.rg-otp-box:focus{border-color:#6366f1;box-shadow:0 0 0 3px rgba(99,102,241,.15);outline:none;}'+
            '.rg-otp-box.rg-otp-filled{border-color:#6366f1;background:#eff6ff;}'+
            '.rg-otp-verify-btn{background:#059669;color:#fff;border:none;border-radius:8px;padding:10px 18px;font-size:14px;font-weight:600;cursor:pointer;}'+
            '.rg-otp-verify-btn:hover{background:#047857;}'+
            '.rg-otp-verify-btn:disabled{opacity:.5;cursor:default;}'+
            '.rg-otp-resend-row{font-size:13px;color:#64748b;margin-bottom:8px;}'+
            '.rg-otp-resend-link{background:none;border:none;color:#6366f1;font-weight:600;cursor:pointer;font-size:13px;padding:0;}'+
            '.rg-otp-resend-link:disabled{color:#94a3b8;cursor:default;}'+
            '.rg-otp-msg{padding:8px 12px;border-radius:7px;font-size:13px;}'+
            '.rg-otp-success{background:#f0fdf4;border:1px solid #86efac;color:#166534;}'+
            '.rg-otp-error{background:#fef2f2;border:1px solid #fca5a5;color:#dc2626;}'+
            '.rg-otp-info{background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;}'+
            '</style>').appendTo('head');
        }
    },

    bindEvents: function(){
        var self = this;

        /* Send OTP */
        $(document).on('click','#rg-otp-send-btn',function(){
            var phone = $('#rg-otp-phone-input').val().trim() || $('#ridego-client-phone').val().trim();
            if (!phone || phone.replace(/[^0-9]/g,'').length < 10) {
                self.showMsg('error','Please enter a valid 10-digit phone number.');
                return;
            }
            self.phone = phone;
            self.sendOtp(phone);
        });

        /* OTP box input — auto advance */
        $(document).on('keyup','.rg-otp-box',function(e){
            var $box = $(this);
            var idx  = parseInt($box.data('index'));
            var val  = $box.val().replace(/[^0-9]/g,'');

            /* Keep only last digit */
            if (val.length > 1) val = val.slice(-1);
            $box.val(val);

            if (val) {
                $box.addClass('rg-otp-filled');
                if (idx < 5) { $('.rg-otp-box[data-index="'+(idx+1)+'"]').focus(); }
            } else {
                $box.removeClass('rg-otp-filled');
            }

            /* Auto-verify when all 6 filled */
            var all = '';
            $('.rg-otp-box').each(function(){ all += $(this).val(); });
            if (all.length === 6) {
                $('#ridego-otp-value').val(all);
                setTimeout(function(){ self.verifyOtp(self.phone, all); }, 200);
            }
        });

        /* Backspace — go to previous box */
        $(document).on('keydown','.rg-otp-box',function(e){
            if (e.key === 'Backspace' && !$(this).val()) {
                var idx = parseInt($(this).data('index'));
                if (idx > 0) { $('.rg-otp-box[data-index="'+(idx-1)+'"]').focus().val('').removeClass('rg-otp-filled'); }
            }
        });

        /* Paste OTP — fills all boxes */
        $(document).on('paste','.rg-otp-box',function(e){
            var pasted = (e.originalEvent.clipboardData || window.clipboardData).getData('text');
            var digits = pasted.replace(/[^0-9]/g,'').slice(0,6);
            if (digits.length === 6) {
                $('.rg-otp-box').each(function(i){
                    $(this).val(digits[i]||'').toggleClass('rg-otp-filled',!!digits[i]);
                });
                $('#ridego-otp-value').val(digits);
                setTimeout(function(){ self.verifyOtp(self.phone,digits); },200);
                e.preventDefault();
            }
        });

        /* Manual verify button */
        $(document).on('click','#rg-otp-verify-btn',function(){
            var otp = '';
            $('.rg-otp-box').each(function(){ otp += $(this).val(); });
            if (otp.length < 6) { self.showMsg('error','Please enter the complete 6-digit OTP.'); return; }
            self.verifyOtp(self.phone, otp);
        });

        /* Resend */
        $(document).on('click','#rg-otp-resend-btn',function(){
            if (!$(this).prop('disabled')) self.sendOtp(self.phone);
        });
    },

    sendOtp: function(phone){
        var self = this;
        var $btn = $('#rg-otp-send-btn');
        $btn.prop('disabled',true).text('Sending...');
        self.showMsg('info','Sending OTP to '+phone+'...');

        $.post(
            (typeof RIDEGO !== 'undefined' ? RIDEGO.ajax_url : '/wp-admin/admin-ajax.php'),
            {
                action  : 'ridego_send_otp',
                nonce   : (typeof RIDEGO !== 'undefined' ? RIDEGO.nonce : ''),
                phone   : phone,
                purpose : self.purpose,
            },
            function(r){
                $btn.prop('disabled',false).text('Resend OTP');
                if (r.success) {
                    if (r.data.trusted) {
                        self.markVerified();
                        return;
                    }
                    $('#rg-otp-boxes-row').show();
                    $('#rg-otp-resend-row').show();
                    $('.rg-otp-box').first().focus();
                    self.startResendCountdown();
                    self.showMsg('info','OTP sent! Check your WhatsApp or email.');
                } else {
                    self.showMsg('error', r.data&&r.data.message ? r.data.message : 'Failed to send OTP. Please try again.');
                }
            }
        );
    },

    verifyOtp: function(phone, otp){
        var self = this;
        $('#rg-otp-verify-btn').prop('disabled',true).text('Verifying...');
        $.post(
            (typeof RIDEGO !== 'undefined' ? RIDEGO.ajax_url : '/wp-admin/admin-ajax.php'),
            {
                action  : 'ridego_verify_otp',
                nonce   : (typeof RIDEGO !== 'undefined' ? RIDEGO.nonce : ''),
                phone   : phone,
                otp     : otp,
                purpose : self.purpose,
            },
            function(r){
                $('#rg-otp-verify-btn').prop('disabled',false).text('Verify OTP');
                if (r.success) {
                    self.markVerified();
                } else {
                    self.showMsg('error', r.data&&r.data.message ? r.data.message : 'Incorrect OTP. Please try again.');
                    /* Shake animation */
                    $('.rg-otp-boxes').addClass('rg-otp-shake');
                    setTimeout(function(){ $('.rg-otp-boxes').removeClass('rg-otp-shake'); },500);
                }
            }
        );
    },

    markVerified: function(){
        this.verified = true;
        $('#ridego-otp-verified').val('1');
        $('#rg-otp-boxes-row, #rg-otp-resend-row').hide();
        this.showMsg('success','Phone verified successfully!');
        /* Trigger event so booking form knows */
        $(document).trigger('ridego:otp_verified', [this.phone]);
        /* Also update the hidden fields in booking form */
        $('#ridego-client-phone').val(this.phone);
        /* Show a verified badge */
        $('#rg-otp-send-btn').text('Verified').css({background:'#059669',cursor:'default'}).prop('disabled',true);
    },

    startResendCountdown: function(){
        var self = this;
        var secs = 30;
        var $cd  = $('#rg-otp-countdown');
        var $rb  = $('#rg-otp-resend-btn');
        $rb.prop('disabled',true);
        clearInterval(self.resendTimer);
        self.resendTimer = setInterval(function(){
            secs--;
            $cd.text(secs);
            if (secs <= 0) {
                clearInterval(self.resendTimer);
                $rb.prop('disabled',false);
                $('#rg-otp-resend-row').html('Didn\'t receive OTP? <button type="button" id="rg-otp-resend-btn" class="rg-otp-resend-link">Resend OTP</button>');
            }
        },1000);
    },

    showMsg: function(type, text){
        var $m = $('#rg-otp-msg');
        $m.attr('class','rg-otp-msg rg-otp-'+type).text(text).show();
        if (type !== 'info') setTimeout(function(){ $m.fadeOut(); },5000);
    }
};

/* Shake keyframe */
$('<style>.rg-otp-shake{animation:rg-shake .4s ease;} @keyframes rg-shake{0%,100%{transform:translateX(0)} 20%{transform:translateX(-8px)} 40%{transform:translateX(8px)} 60%{transform:translateX(-5px)} 80%{transform:translateX(5px)}}</style>').appendTo('head');

$(document).ready(function(){
    if ($('#ridego-otp-widget').length || $('.rg-otp-box').length) {
        OTP.init();
    }
    /* Expose globally for booking.js to call */
    window.RIDEGO_OTP = OTP;
});

})(jQuery);
