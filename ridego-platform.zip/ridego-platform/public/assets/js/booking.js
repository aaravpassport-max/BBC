/**
 * RideGo Booking JS — Live price calculator, form validation,
 * city autocomplete, vehicle selection, OTP flow
 */
(function($){
'use strict';
if(typeof RIDEGO==='undefined') return;

var BOOKING = {
    cities        : [],
    vehicles      : [],
    selectedVehicle: null,
    fareData      : null,
    otpSent       : false,
    otpVerified   : false,
    calcTimer     : null,
    currentStep   : 1,

    init: function(){
        this.loadCities();
        this.bindEvents();
        this.initStepUI();
        this.initTripTypeTabs();
        this.setMinDate();
    },

    /* ── Load cities for autocomplete ── */
    loadCities: function(){
        var self = this;
        $.post(RIDEGO.ajax_url,{action:'ridego_get_cities',nonce:RIDEGO.nonce},function(r){
            if(r.success) self.cities = r.data;
            self.initAutocomplete('#ridego-pickup-city','pickup');
            self.initAutocomplete('#ridego-drop-city','drop');
        });
    },

    initAutocomplete: function(selector, type){
        var self = this;
        var $inp = $(selector);
        if(!$inp.length) return;
        var $wrap = $('<div class="ridego-autocomplete-wrap"></div>');
        $inp.wrap($wrap);
        var $dropdown = $('<ul class="ridego-city-dropdown"></ul>').insertAfter($inp);

        $inp.on('input',function(){
            var val = $(this).val().toLowerCase().trim();
            $dropdown.empty().hide();
            if(val.length < 2) return;
            var matches = self.cities.filter(function(c){ return c.name.toLowerCase().indexOf(val)===0||c.state.toLowerCase().indexOf(val)===0; }).slice(0,8);
            if(!matches.length) return;
            $.each(matches,function(i,c){
                var $li = $('<li>').html('<strong>'+c.name+'</strong><span>'+c.state+'</span>').data('city',c);
                $li.on('click',function(){
                    $inp.val(c.name).data('city-id',c.id).trigger('ridego:city_selected');
                    $dropdown.hide();
                    if(type==='pickup') self.onPickupSelected(c);
                    else                self.onDropSelected(c);
                });
                $dropdown.append($li);
            });
            $dropdown.show();
        });
        $(document).on('click',function(e){ if(!$(e.target).closest('.ridego-autocomplete-wrap').length) $dropdown.hide(); });
    },

    onPickupSelected: function(city){
        $('#ridego-pickup-lat').val(city.lat||'');
        $('#ridego-pickup-lng').val(city.lng||'');
        this.tryCalcFare();
        this.loadVehicles();
    },

    onDropSelected: function(city){
        $('#ridego-drop-lat').val(city.lat||'');
        $('#ridego-drop-lng').val(city.lng||'');
        this.tryCalcFare();
    },

    /* ── Trip type tabs ── */
    initTripTypeTabs: function(){
        var self = this;
        $(document).on('click','.ridego-trip-tab',function(){
            var type = $(this).data('type');
            $('.ridego-trip-tab').removeClass('active');
            $(this).addClass('active');
            $('#ridego-trip-type').val(type);
            self.showFieldsForType(type);
            self.tryCalcFare();
        });
    },

    showFieldsForType: function(type){
        $('.ridego-field-group').hide();
        $('.ridego-field-always').show();
        switch(type){
            case 'one_way':    $('.ridego-field-drop,.ridego-field-date,.ridego-field-time').show(); break;
            case 'round_trip': $('.ridego-field-drop,.ridego-field-date,.ridego-field-time,.ridego-field-return').show(); break;
            case 'local':      $('.ridego-field-date,.ridego-field-time,.ridego-field-hours').show(); $('#ridego-drop-city').closest('.ridego-field-group').hide(); break;
            case 'airport_pickup':
            case 'airport_drop':  $('.ridego-field-drop,.ridego-field-date,.ridego-field-time,.ridego-field-flight').show(); break;
            case 'outstation': $('.ridego-field-drop,.ridego-field-date,.ridego-field-time,.ridego-field-days').show(); break;
            case 'corporate':  $('.ridego-field-drop,.ridego-field-date,.ridego-field-time,.ridego-field-corporate').show(); break;
            default:           $('.ridego-field-drop,.ridego-field-date,.ridego-field-time').show(); break;
        }
    },

    /* ── Min date = today + advance hours ── */
    setMinDate: function(){
        var adv    = 2;
        var minTs  = new Date(Date.now() + adv*3600*1000);
        var minStr = minTs.toISOString().split('T')[0];
        $('#ridego-journey-date').attr('min',minStr);
        if(!$('#ridego-journey-date').val()) $('#ridego-journey-date').val(minStr);
    },

    /* ── Load vehicles filtered by passenger count ── */
    loadVehicles: function(){
        var self = this;
        var pax  = parseInt($('#ridego-passengers').val())||1;
        $.post(RIDEGO.ajax_url,{action:'ridego_get_vehicles',nonce:RIDEGO.nonce,passengers:pax},function(r){
            if(!r.success) return;
            self.vehicles = r.data;
            self.renderVehicles();
        });
    },

    renderVehicles: function(){
        var self  = this;
        var $wrap = $('#ridego-vehicle-grid');
        if(!$wrap.length) return;
        $wrap.empty();
        if(!this.vehicles.length){ $wrap.html('<p class="ridego-no-vehicles">No vehicles available for '+$('#ridego-passengers').val()+' passengers. Try a different count.</p>'); return; }
        $.each(this.vehicles,function(i,v){
            var icon = v.icon_url ? '<img src="'+v.icon_url+'" alt="'+v.name+'" class="ridego-veh-icon">' : '<div class="ridego-veh-icon-placeholder">&#128663;</div>';
            var feats= v.features.slice(0,3).map(function(f){ return '<span>'+f+'</span>'; }).join('');
            var $card = $('<div class="ridego-vehicle-card" data-vehicle-id="'+v.id+'">'+
                '<div class="ridego-veh-image">'+icon+'</div>'+
                '<div class="ridego-veh-details">'+
                    '<div class="ridego-veh-name">'+v.name+'</div>'+
                    '<div class="ridego-veh-meta">'+
                        '<span class="ridego-veh-cap">&#128100; '+v.capacity+' pax</span>'+
                        '<span class="ridego-veh-bag">&#129524; '+v.luggage+' bags</span>'+
                        (v.ac?'<span class="ridego-veh-ac">&#10052; AC</span>':'')+
                    '</div>'+
                    '<div class="ridego-veh-features">'+feats+'</div>'+
                '</div>'+
                '<div class="ridego-veh-price">'+
                    '<div class="ridego-veh-from">From</div>'+
                    '<div class="ridego-veh-price-val" id="ridego-veh-price-'+v.id+'">'+v.price_from+'</div>'+
                    '<button class="ridego-btn-select-vehicle" type="button">Select</button>'+
                '</div>'+
            '</div>');
            $card.on('click',function(){ self.selectVehicle(v,$(this)); });
            $wrap.append($card);
        });
    },

    selectVehicle: function(vehicle,$card){
        this.selectedVehicle = vehicle;
        $('#ridego-vehicle-type-id').val(vehicle.id);
        $('.ridego-vehicle-card').removeClass('ridego-vehicle-selected');
        $card.addClass('ridego-vehicle-selected');
        this.scheduleFareCalc();
    },

    /* ── Fare calculation with debounce ── */
    scheduleFareCalc: function(){
        var self = this;
        clearTimeout(this.calcTimer);
        this.calcTimer = setTimeout(function(){ self.calcFare(); }, 500);
    },

    tryCalcFare: function(){
        if(this.selectedVehicle) this.scheduleFareCalc();
        else this.loadVehicles();
    },

    calcFare: function(){
        var self = this;
        if(!this.selectedVehicle) return;
        var data = this.collectFormData();
        data.action = 'ridego_calc_fare';
        data.nonce  = RIDEGO.nonce;
        $('#ridego-price-panel').addClass('ridego-loading');
        $.post(RIDEGO.ajax_url, data, function(r){
            $('#ridego-price-panel').removeClass('ridego-loading');
            if(!r.success){ $('#ridego-fare-breakdown').html('<div class="ridego-fare-error">'+r.data.message+'</div>'); return; }
            self.fareData = r.data.fare;
            self.renderFare(r.data);
            /* Update per-vehicle prices in grid */
            $('#ridego-veh-price-'+self.selectedVehicle.id).text(r.data.formatted);
        });
    },

    renderFare: function(data){
        var $panel = $('#ridego-fare-breakdown');
        if(!$panel.length) return;
        $panel.html(data.breakdown_html);
        $('#ridego-total-display').text(data.formatted);
        $('#ridego-fare-panel-price').text(data.formatted);
        $('#ridego-hidden-fare').val(data.fare.total_fare);
        $('#ridego-hidden-distance').val(data.fare.distance_km);
        $('#ridego-hidden-duration').val(data.fare.duration_minutes);
    },

    /* ── Collect all form data ── */
    collectFormData: function(){
        return {
            trip_type       : $('#ridego-trip-type').val()||'one_way',
            pickup_city     : $('#ridego-pickup-city').val(),
            pickup_address  : $('#ridego-pickup-address').val(),
            pickup_lat      : $('#ridego-pickup-lat').val(),
            pickup_lng      : $('#ridego-pickup-lng').val(),
            drop_city       : $('#ridego-drop-city').val(),
            drop_address    : $('#ridego-drop-address').val(),
            drop_lat        : $('#ridego-drop-lat').val(),
            drop_lng        : $('#ridego-drop-lng').val(),
            journey_date    : $('#ridego-journey-date').val(),
            journey_time    : $('#ridego-journey-time').val(),
            return_date     : $('#ridego-return-date').val(),
            return_time     : $('#ridego-return-time').val(),
            hours_required  : $('#ridego-hours').val()||4,
            passengers      : $('#ridego-passengers').val()||1,
            luggage_count   : $('#ridego-luggage').val()||0,
            vehicle_type_id : $('#ridego-vehicle-type-id').val()||0,
            distance_km     : $('#ridego-hidden-distance').val()||0,
            duration_minutes: $('#ridego-hidden-duration').val()||0,
            promo_code      : $('#ridego-promo-code').val(),
            client_name     : $('#ridego-client-name').val(),
            client_phone    : $('#ridego-client-phone').val(),
            client_email    : $('#ridego-client-email').val(),
            special_requests: $('#ridego-special').val(),
            flight_number   : $('#ridego-flight-no').val(),
            payment_method  : $('input[name="ridego_payment_method"]:checked').val()||'cash',
            otp_value       : $('#ridego-otp-value').val(),
        };
    },

    /* ── Bind all events ── */
    bindEvents: function(){
        var self = this;

        /* Re-calc on relevant field changes */
        $(document).on('change','#ridego-journey-date,#ridego-journey-time,#ridego-return-date,#ridego-hours,#ridego-trip-type',function(){
            self.tryCalcFare();
        });
        $(document).on('change','#ridego-passengers',function(){
            self.loadVehicles();
        });

        /* Promo code apply */
        $(document).on('click','#ridego-apply-promo',function(){
            var code = $('#ridego-promo-code').val().trim();
            if(!code){ self.showPromoMsg('Enter a promo code.','error'); return; }
            $.post(RIDEGO.ajax_url,{action:'ridego_validate_promo',nonce:RIDEGO.nonce,code:code,amount:$('#ridego-hidden-fare').val(),trip_type:$('#ridego-trip-type').val()},function(r){
                if(r.success){ self.showPromoMsg(r.data.message,'success'); self.calcFare(); }
                else self.showPromoMsg(r.data.message,'error');
            });
        });

        /* OTP flow */
        $(document).on('click','#ridego-send-otp-btn',function(){
            var phone = $('#ridego-client-phone').val().trim();
            if(!phone){ self.showMsg('#ridego-otp-msg','Enter your phone number first.','error'); return; }
            $(this).prop('disabled',true).text('Sending...');
            var btn = this;
            $.post(RIDEGO.ajax_url,{action:'ridego_send_otp',nonce:RIDEGO.nonce,phone:phone,purpose:'booking'},function(r){
                $(btn).prop('disabled',false).text('Resend OTP');
                if(r.success){
                    if(r.data.trusted){ self.otpVerified=true; self.showMsg('#ridego-otp-msg','Phone verified!','success'); $('#ridego-otp-input-wrap').hide(); return; }
                    $('#ridego-otp-input-wrap').show();
                    self.startOtpCountdown(btn);
                    self.showMsg('#ridego-otp-msg','OTP sent to '+phone,'success');
                } else {
                    self.showMsg('#ridego-otp-msg',r.data.message,'error');
                }
            });
        });

        $(document).on('click','#ridego-verify-otp-btn',function(){
            var phone = $('#ridego-client-phone').val();
            var otp   = $('#ridego-otp-value').val();
            $.post(RIDEGO.ajax_url,{action:'ridego_verify_otp',nonce:RIDEGO.nonce,phone:phone,otp:otp,purpose:'booking'},function(r){
                if(r.success){ self.otpVerified=true; $('#ridego-otp-input-wrap').hide(); self.showMsg('#ridego-otp-msg','Phone verified!','success'); }
                else self.showMsg('#ridego-otp-msg',r.data.message,'error');
            });
        });

        /* Final booking submit */
        $(document).on('submit','#ridego-booking-form',function(e){
            e.preventDefault();
            self.submitBooking();
        });
    },

    startOtpCountdown: function(btn){
        var secs = 30;
        var timer = setInterval(function(){
            secs--;
            $(btn).text('Resend in '+secs+'s').prop('disabled',true);
            if(secs<=0){ clearInterval(timer); $(btn).text('Resend OTP').prop('disabled',false); }
        },1000);
    },

    /* ── Multi-step form ── */
    initStepUI: function(){
        var self = this;
        $(document).on('click','.ridego-step-next',function(){
            if(self.validateStep(self.currentStep)){
                self.currentStep++;
                self.goToStep(self.currentStep);
            }
        });
        $(document).on('click','.ridego-step-back',function(){
            self.currentStep--;
            self.goToStep(self.currentStep);
        });
    },

    goToStep: function(step){
        $('.ridego-step-panel').hide();
        $('#ridego-step-'+step).show();
        $('.ridego-step-indicator').removeClass('active completed');
        for(var i=1;i<step;i++) $('[data-step="'+i+'"]').addClass('completed');
        $('[data-step="'+step+'"]').addClass('active');
        $('html,body').animate({scrollTop:$('#ridego-booking-form').offset().top - 80},300);
    },

    validateStep: function(step){
        var valid = true;
        switch(step){
            case 1:
                if(!$('#ridego-pickup-city').val()){ this.showFieldError('#ridego-pickup-city','Select pickup city'); valid=false; }
                var tt = $('#ridego-trip-type').val();
                if(tt!=='local' && !$('#ridego-drop-city').val()){ this.showFieldError('#ridego-drop-city','Select drop city'); valid=false; }
                if(!$('#ridego-journey-date').val()){ this.showFieldError('#ridego-journey-date','Select journey date'); valid=false; }
                break;
            case 2:
                if(!$('#ridego-vehicle-type-id').val()){ this.showMsg('#ridego-vehicle-msg','Please select a vehicle.','error'); valid=false; }
                break;
            case 3:
                if(!$('#ridego-client-name').val()){ this.showFieldError('#ridego-client-name','Enter your name'); valid=false; }
                if(!$('#ridego-client-phone').val()){ this.showFieldError('#ridego-client-phone','Enter phone number'); valid=false; }
                break;
        }
        return valid;
    },

    /* ── Submit booking ── */
    submitBooking: function(){
        var self = this;
        var data = this.collectFormData();
        data.action = 'ridego_submit_booking';
        data.nonce  = RIDEGO.nonce;

        if(!data.client_name||!data.client_phone||!data.vehicle_type_id){
            this.showMsg('#ridego-submit-msg','Please fill all required fields.','error');
            return;
        }

        $('#ridego-submit-btn').prop('disabled',true).html('<span class="ridego-spinner"></span> Booking...');

        $.post(RIDEGO.ajax_url,data,function(r){
            $('#ridego-submit-btn').prop('disabled',false).text('Book Now');
            if(r.success){
                var d = r.data;
                if(d.need_otp){
                    self.showMsg('#ridego-submit-msg',d.message,'warning');
                    $('#ridego-otp-section').show();
                    return;
                }
                /* If a promo got silently dropped by the atomic redemption
                   race (exhausted between the fare preview and the final
                   booking insert), stash why so the confirm page can show
                   a clear one-line notice instead of the total just
                   looking wrong with no explanation. */
                if(d.promo_adjusted){
                    try{ sessionStorage.setItem('ridego_promo_adjusted_reason', d.promo_adjusted_reason || 'Your promo code could not be applied to this booking.'); }catch(e){}
                }
                /* Redirect to confirm page */
                window.location.href = d.confirm_url;
            } else {
                self.showMsg('#ridego-submit-msg',r.data.message||'Booking failed. Please try again.','error');
            }
        }).fail(function(){
            $('#ridego-submit-btn').prop('disabled',false).text('Book Now');
            self.showMsg('#ridego-submit-msg','Connection error. Please try again.','error');
        });
    },

    showPromoMsg: function(msg,type){
        this.showMsg('#ridego-promo-msg',msg,type);
    },

    showFieldError: function(selector,msg){
        $(selector).addClass('ridego-field-error').after('<span class="ridego-error-msg">'+msg+'</span>');
        setTimeout(function(){ $(selector).removeClass('ridego-field-error').next('.ridego-error-msg').remove(); },3000);
    },

    showMsg: function(selector,msg,type){
        var cls = 'ridego-msg ridego-msg-'+type;
        $(selector).attr('class',cls).text(msg).show();
        if(type!=='loading') setTimeout(function(){ $(selector).fadeOut(); },4000);
    }
};

$(document).ready(function(){
    if($('#ridego-booking-form').length || $('#ridego-booking-widget').length){
        BOOKING.init();
    }
});

})(jQuery);
