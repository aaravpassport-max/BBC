<?php
/**
 * Plugin Name: RideGo Platform
 * Plugin URI:  https://yoursite.com
 * Description: Complete cab and taxi booking marketplace. Lead-charge model. Vendor management. Admin dashboard. Free messaging stack. Plug and play.
 * Version:     1.2.0
 * Author:      RideGo
 * License:     GPL2
 * Text Domain: ridego
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/*  Constants  */
define( 'RIDEGO_VER',          '1.2.1' );
define( 'RIDEGO_PATH',         plugin_dir_path( __FILE__ ) );
define( 'RIDEGO_URL',          plugin_dir_url( __FILE__ ) );
define( 'RIDEGO_SLUG',         'ridego-platform' );
define( 'RIDEGO_DB_VER',       '1.0.0' );
define( 'RIDEGO_SECURE_UPLOADS', WP_CONTENT_DIR . '/ridego-secure-uploads/' );
define( 'RIDEGO_SECURE_URL',   WP_CONTENT_URL . '/ridego-secure-uploads/' );
define( 'RIDEGO_MIN_PHP',      '8.0' );
define( 'RIDEGO_MIN_WP',       '6.0' );

/*  Check requirements before loading  */
if ( version_compare( PHP_VERSION, RIDEGO_MIN_PHP, '<' ) ) {
    add_action( 'admin_notices', function() {
        echo '<div class="notice notice-error"><p><strong>RideGo Platform</strong> requires PHP ' . RIDEGO_MIN_PHP . ' or higher. You are running PHP ' . PHP_VERSION . '.</p></div>';
    });
    return;
}

/*  Debug log — defined here, before any module is required, so it is
    unconditionally the single canonical definition and no included file
    needs (or should ever add) its own guarded fallback copy. Writes to a
    dedicated debug log file when RIDEGO_DEBUG is on, and mirrors to the
    PHP/WordPress error log when WP_DEBUG is on so ops can rely on either
    log pipeline finding these messages. */
if ( ! function_exists( 'ridego_log' ) ) {
    function ridego_log( $message ) {
        if ( defined( 'RIDEGO_DEBUG' ) && RIDEGO_DEBUG ) {
            $log  = RIDEGO_PATH . 'ridego-debug.log';
            $line = '[' . date( 'Y-m-d H:i:s' ) . '] ' . $message . "\n";
            file_put_contents( $log, $line, FILE_APPEND );
        }
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG === true ) {
            error_log( '[RideGo] ' . $message );
        }
    }
}

/*  Load all modules  */
$ridego_includes = array(
    'includes/helpers.php',
    'includes/roles.php',
    'includes/rbac.php',
    'includes/install.php',
    'includes/migrations.php',
    'includes/migrations-marketplace.php',
    'includes/settings.php',
    'includes/booking.php',
    'includes/pricing.php',
    'includes/payment.php',
    'includes/vendor.php',
    'includes/subscriptions.php',
    'includes/lead.php',
    'includes/fleet.php',
    'includes/performance-data.php',
    'includes/assignments.php',
    'includes/commission.php',
    'includes/lead-fee.php',
    'includes/branding.php',
    'includes/ledger.php',
    'includes/lead-response.php',
    'includes/matching.php',
    'includes/impersonation.php',
    'includes/team.php',
    'includes/marketplace-caps.php',
    'includes/lifecycle.php',
    'includes/otp.php',
    'includes/notifications.php',
    'includes/complaints.php',
    'includes/promo.php',
    'includes/seo.php',
    'includes/fraud.php',
    'includes/jobs.php',
    'includes/cron.php',
    'includes/api.php',
    'includes/rest-api.php',
    'includes/app-api.php',
    'includes/app-admin-api.php',
    'includes/app-admin-bookings-api.php',
    'includes/app-admin-cities-api.php',
    'includes/app-admin-routes-api.php',
    'includes/route-pages.php',
    'includes/route-pages-sitemap.php',
    'includes/app-admin-route-pages-api.php',
    'includes/app-admin-pricing-api.php',
    'includes/app-admin-promo-api.php',
    'includes/app-admin-reports-api.php',
    'includes/app-admin-financial-api.php',
    'includes/app-admin-complaints-api.php',
    'includes/app-admin-subscriptions-api.php',
    'includes/app-admin-audit-api.php',
    'includes/app-admin-leads-api.php',
    'includes/app-admin-tools-api.php',
    'includes/app-admin-settings-api.php',
    'includes/app-admin-dashboard-api.php',
    'includes/app-admin-notifications-api.php',
    'includes/app-vendor-marketplace-api.php',
    'includes/app-admin-marketplace-api.php',
    'includes/app-admin-lead-fee-api.php',
    'includes/app-team-api.php',
    'includes/clients.php',
    'includes/enquiries.php',
    'includes/booking-admin.php',
    'includes/platform-model.php',
    'includes/app-admin-crm-api.php',
    'includes/app-admin-reconciliation-api.php',
    'includes/app-privacy-api.php',
    'includes/app-admin-system-api.php',
    'includes/app-client-dashboard-api.php',
    'includes/diagnostic-api.php',
    'includes/admin-diagnostics.php',
    'includes/app-shell.php',
    'includes/security.php',
    'includes/performance.php',
    'public/ajax/booking-ajax.php',
    'public/shortcodes.php',
    'public/templates/booking-confirm.php',
    'includes/dummy-data.php',
);
foreach ( $ridego_includes as $file ) {
    $path = RIDEGO_PATH . $file;
    if ( file_exists( $path ) ) {
        require_once $path;
    }
}

/* ============================================================
   AUTO-SEED APPLICATION DATA ON EVERY admin_init IF MISSING
   This fires even when activation hook was missed (e.g. FTP upload).

   ROOT-CAUSE FIX: this used to also auto-create ~12 legacy
   WordPress Pages with shortcode content on every site (via
   ridego_create_pages()) — exactly the "WordPress page-building"
   dependency the standalone architecture is supposed to eliminate,
   happening automatically and unconditionally, not because any
   admin asked for it. The platform's real, canonical entry point
   is now the React SPA served directly at the site root and at
   /app/... by includes/app-shell.php, which needs no WordPress
   Page at all. Legacy shortcode pages are no longer auto-created;
   ridego_create_pages() still exists and remains available as an
   explicit, opt-in action from the admin Tools page for anyone who
   specifically wants the old shortcode-based pages for some other
   purpose, but it is never run automatically again. Vehicle/city
   reference data seeding (real application data, not WordPress
   page-building) is unaffected.
   ============================================================ */
add_action( 'admin_init', 'ridego_maybe_seed_data' );
function ridego_maybe_seed_data() {
    /* Only run once per day maximum */
    if ( get_transient('ridego_data_checked') ) { return; }
    set_transient( 'ridego_data_checked', 1, DAY_IN_SECONDS );

    /* Seed vehicles/cities if tables empty */
    if ( function_exists('ridego_seed_all_data') ) {
        global $wpdb;
        $vehicle_count = intval( $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}ridego_vehicles" ) );
        if ( $vehicle_count === 0 ) {
            ridego_seed_all_data();
        }
    }
}

/**
 * Run any pending schema migrations, at most once per admin_init request
 * (guarded by version comparison inside ridego_run_migrations() itself,
 * so this is cheap once the site is caught up — a single get_option()
 * read and an early return). This replaces every ad hoc "CREATE TABLE
 * IF NOT EXISTS" that used to be scattered across hooks in this file.
 */
add_action( 'admin_init', 'ridego_maybe_run_migrations', 5 );
add_action( 'init', 'ridego_maybe_run_migrations', 5 );
// TRACE: admin_init or init (so a front-end-only site upgraded by file replacement still migrates before the marketplace
//        REST routes touch new columns) → when the stored schema version is below RIDEGO_SCHEMA_VERSION and no other
//        request holds the 60s migration lock, runs the idempotent migrations → void.
//        Preconditions: plugin files loaded → Postconditions: schema at target or the lock held by another request →
//        Edge cases: already current (one get_option, early return), concurrent requests (transient lock), migration failure (chain halts, logged by ridego_run_migrations).
function ridego_maybe_run_migrations() {
    if ( ! function_exists( 'ridego_run_migrations' ) ) { return; }
    $current = (int) get_option( 'ridego_schema_version', 0 );
    $target  = defined( 'RIDEGO_SCHEMA_VERSION' ) ? RIDEGO_SCHEMA_VERSION : 0;
    if ( $current >= $target ) { return; }
    if ( get_transient( 'ridego_migrating' ) ) { return; }
    set_transient( 'ridego_migrating', 1, 60 );
    if ( ! function_exists( 'dbDelta' ) && defined( 'ABSPATH' ) ) { require_once ABSPATH . 'wp-admin/includes/upgrade.php'; }
    ridego_run_migrations();
    delete_transient( 'ridego_migrating' );
}

/* Manual "Recreate Pages" action from admin notice */
add_action( 'admin_init', 'ridego_handle_manual_recreate' );
function ridego_handle_manual_recreate() {
    if ( ! isset($_GET['ridego_action']) ) { return; }
    if ( ! current_user_can('manage_options') ) { return; }

    $action = sanitize_key($_GET['ridego_action']);

    if ( $action === 'recreate_pages' ) {
        if ( ! wp_verify_nonce( isset($_GET['_nonce'])?$_GET['_nonce']:'', 'ridego_recreate_pages' ) ) { return; }
        delete_transient('ridego_pages_checked');
        if ( function_exists('ridego_create_pages') ) { ridego_create_pages(); }
        flush_rewrite_rules();
        wp_redirect( admin_url('admin.php?page=ridego-tools&ridego_notice=pages_created') );
        exit;
    }

    if ( $action === 'reseed_data' ) {
        if ( ! wp_verify_nonce( isset($_GET['_nonce'])?$_GET['_nonce']:'', 'ridego_reseed_data' ) ) { return; }
        if ( function_exists('ridego_seed_all_data') ) { ridego_seed_all_data(); }
        wp_redirect( admin_url('admin.php?page=ridego-tools&ridego_notice=reseeded') );
        exit;
    }

    if ( $action === 'flush_rules' ) {
        if ( ! wp_verify_nonce( isset($_GET['_nonce'])?$_GET['_nonce']:'', 'ridego_flush' ) ) { return; }
        flush_rewrite_rules();
        wp_redirect( admin_url('admin.php?page=ridego-tools&ridego_notice=flushed') );
        exit;
    }
}

/* Show admin success notices for manual Tools-page actions.
 *
 * ROOT-CAUSE FIX: this used to ALSO show a persistent, impossible-
 * to-miss red error notice on every single wp-admin screen telling
 * the site owner their "booking form, home page, and vendor portal
 * are not live" unless a legacy WordPress Page had been created —
 * actively training the site owner to believe legacy page creation
 * was required setup, which directly contradicted "the complete
 * platform is available immediately after activation, no manual
 * page/menu/shortcode setup." The real platform (the React SPA
 * served at the site root and at /app/... by includes/app-shell.php)
 * needs no WordPress Page at all and is live the moment the plugin
 * is activated, so this nag was actively working against the
 * architecture rather than describing a real missing step. Removed;
 * legacy-page creation remains available as a fully optional, purely
 * opt-in action from the Tools page (ridego_action=recreate_pages)
 * for anyone who specifically still wants the old shortcode pages.
 */
add_action( 'admin_notices', 'ridego_admin_action_notices' );
function ridego_admin_action_notices() {
    if ( ! current_user_can('manage_options') ) { return; }
    if ( ! isset($_GET['ridego_notice']) ) { return; }

    $msgs = array(
        'pages_created' => '✅ Legacy shortcode pages created. (Optional — the platform itself runs from / and /app/, no page assignment needed.)',
        'reseeded'      => '✅ Vehicles and cities seeded successfully.',
        'flushed'       => '✅ Rewrite rules flushed.',
        'demo_seeded'   => '🎭 Demo data seeded! Vendors, bookings, leads, reviews & promo codes added.',
    );
    $notice = sanitize_key($_GET['ridego_notice']);
    if ( isset($msgs[$notice]) ) {
        echo '<div class="notice notice-success is-dismissible"><p><strong>RideGo:</strong> ' . $msgs[$notice] . '</p></div>';
    }
}


register_activation_hook( __FILE__, 'ridego_activate' );
function ridego_activate() {
    /* Requirements check */
    if ( version_compare( PHP_VERSION, RIDEGO_MIN_PHP, '<' ) ) {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        wp_die( 'RideGo Platform requires PHP ' . RIDEGO_MIN_PHP . ' or higher.' );
    }
    if ( version_compare( get_bloginfo('version'), RIDEGO_MIN_WP, '<' ) ) {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        wp_die( 'RideGo Platform requires WordPress ' . RIDEGO_MIN_WP . ' or higher.' );
    }

    /* Run installation */
    if ( function_exists('ridego_install_tables') )  { ridego_install_tables(); }
    if ( function_exists('ridego_run_migrations') )  { ridego_run_migrations(); }
    if ( function_exists('ridego_register_roles') )  { ridego_register_roles(); }
    if ( function_exists('ridego_seed_all_data') )   { ridego_seed_all_data(); }
    // ridego_create_pages() intentionally NOT called here — see the
    // doc comment on ridego_maybe_seed_data() above. The platform is
    // fully live at the site root / /app/ the moment this hook runs
    // (flush_rewrite_rules() below is what makes that URL work
    // immediately), with no legacy WordPress Pages required.
    if ( function_exists('ridego_schedule_cron') )   { ridego_schedule_cron(); }
    if ( function_exists('ridego_set_defaults') )    { ridego_set_defaults(); }
    if ( function_exists('ridego_seed_dummy_data') )  { ridego_seed_dummy_data(); }

    /* Create secure upload directories */
    ridego_create_secure_dirs();

    update_option( 'ridego_version', RIDEGO_VER );
    update_option( 'ridego_activated_at', current_time('mysql') );

    // init has already fired in this request, so register the /app rule explicitly before flushing.
    if ( function_exists('ridego_app_register_rewrite') ) { ridego_app_register_rewrite(); }
    flush_rewrite_rules();
    update_option( 'ridego_app_rewrite_flushed_for', RIDEGO_VER );
}

/*  Deactivation  */
register_deactivation_hook( __FILE__, 'ridego_deactivate' );
function ridego_deactivate() {
    // NOTE: ridego_process_notification_queue (notifications.php) and
    // ridego_cleanup_expired_otps (otp.php) unschedule themselves via
    // their own register_deactivation_hook() calls — not repeated here.
    wp_clear_scheduled_hook( 'ridego_document_expiry_check' );
    wp_clear_scheduled_hook( 'ridego_subscription_renewal_check' );
    wp_clear_scheduled_hook( 'ridego_weekly_cleanup' );
    flush_rewrite_rules();
}

/*  Uninstall hook  */
register_uninstall_hook( __FILE__, 'ridego_uninstall' );
function ridego_uninstall() {
    if ( ! defined('WP_UNINSTALL_PLUGIN') ) { exit; }
    /* Full cleanup only if admin opted in */
    if ( get_option('ridego_delete_data_on_uninstall') === '1' ) {
        global $wpdb;
        $tables = array(
            'ridego_bookings','ridego_bookings_archive','ridego_vendors',
            'ridego_vehicles','ridego_cities','ridego_routes',
            'ridego_leads','ridego_transactions','ridego_vendor_wallets',
            'ridego_complaints','ridego_notifications','ridego_notification_queue',
            'ridego_promo_codes','ridego_ratings','ridego_driver_docs',
            'ridego_subscription_plans','ridego_zones','ridego_surge_pricing',
            'ridego_cancellation_log','ridego_route_cache','ridego_settings',
            'ridego_audit_log','ridego_otp',
        );
        foreach ( $tables as $t ) {
            $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$t}" );
        }
        /* Remove all options */
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'ridego_%'");
    }
}

/*  Create secure upload directories  */
function ridego_create_secure_dirs() {
    $dirs = array(
        RIDEGO_SECURE_UPLOADS,
        RIDEGO_SECURE_UPLOADS . 'payment-proofs/',
        RIDEGO_SECURE_UPLOADS . 'vendor-docs/',
        RIDEGO_SECURE_UPLOADS . 'vehicle-photos/',
        RIDEGO_SECURE_UPLOADS . 'complaint-evidence/',
    );
    foreach ( $dirs as $dir ) {
        if ( ! file_exists($dir) ) {
            wp_mkdir_p( $dir );
        }
    }
    /* Block direct access */
    $htaccess = RIDEGO_SECURE_UPLOADS . '.htaccess';
    if ( ! file_exists($htaccess) ) {
        file_put_contents( $htaccess, "Options -Indexes\nDeny from all\n" );
    }
    /* index.php in each dir */
    foreach ( $dirs as $dir ) {
        $idx = $dir . 'index.php';
        if ( ! file_exists($idx) ) {
            file_put_contents( $idx, '<?php // Silence is golden.' );
        }
    }
}

/*  Enqueue front-end assets  */
add_action( 'wp_enqueue_scripts', 'ridego_enqueue_frontend' );
function ridego_enqueue_frontend() {
    global $post;
    $booking_pages = array(
        (int) ridego_get_setting('booking_page_id'),
        (int) ridego_get_setting('search_page_id'),
        (int) ridego_get_setting('confirm_page_id'),
        (int) ridego_get_setting('home_page_id'),
    );
    $vendor_pages = array(
        (int) ridego_get_setting('vendor_register_page_id'),
        (int) ridego_get_setting('vendor_dashboard_page_id'),
    );
    $client_pages = array(
        (int) ridego_get_setting('my_trips_page_id'),
    );

    /* Always load base styles */
    wp_enqueue_style( 'ridego-public', RIDEGO_URL . 'public/assets/css/public.css', array(), RIDEGO_VER );
    wp_enqueue_style( 'ridego-premium', RIDEGO_URL . 'public/assets/css/premium.css', array(), RIDEGO_VER );

    /* Booking pages */
    $is_booking = ( isset($post) && (
        is_page($booking_pages) ||
        has_shortcode($post->post_content, 'ridego_booking') ||
        has_shortcode($post->post_content, 'ridego_search') ||
        has_shortcode($post->post_content, 'ridego_home')
    ));

    if ( $is_booking ) {
        wp_enqueue_style(  'ridego-booking-css', RIDEGO_URL . 'public/assets/css/booking.css', array(), RIDEGO_VER );
        wp_enqueue_script( 'ridego-booking',     RIDEGO_URL . 'public/assets/js/booking.js', array('jquery'), RIDEGO_VER, true );
        wp_enqueue_script( 'ridego-otp',         RIDEGO_URL . 'public/assets/js/otp.js', array('jquery'), RIDEGO_VER, true );

        $gmaps_key = ridego_get_setting('google_maps_key');
        if ( $gmaps_key ) {
            wp_enqueue_script( 'ridego-maps', RIDEGO_URL . 'public/assets/js/maps.js', array(), RIDEGO_VER, true );
            wp_enqueue_script( 'google-maps',
                'https://maps.googleapis.com/maps/api/js?key=' . urlencode($gmaps_key) . '&libraries=places&callback=ridego_maps_init',
                array('ridego-maps'), null, true
            );
        }
    }

    /* Payment confirmation page */
    if ( isset($post) && is_page( (int) ridego_get_setting('confirm_page_id') ) ) {
        wp_enqueue_style(  'ridego-payment-css', RIDEGO_URL . 'public/assets/css/payment.css', array(), RIDEGO_VER );
        wp_enqueue_script( 'ridego-payment',     RIDEGO_URL . 'public/assets/js/payment.js', array('jquery'), RIDEGO_VER, true );
    }

    /* Vendor pages */
    $is_vendor = ( isset($post) && is_page($vendor_pages) && ridego_is_vendor() );
    if ( $is_vendor ) {
        wp_enqueue_style(  'ridego-vendor-css', RIDEGO_URL . 'public/assets/css/vendor-portal.css', array(), RIDEGO_VER );
        wp_enqueue_script( 'ridego-vendor',     RIDEGO_URL . 'public/assets/js/vendor-portal.js', array('jquery'), RIDEGO_VER, true );
    }

    /* Tracking page */
    if ( isset($post) && is_page( (int) ridego_get_setting('track_page_id') ) ) {
        wp_enqueue_script( 'ridego-tracking', RIDEGO_URL . 'public/assets/js/tracking.js', array('jquery'), RIDEGO_VER, true );
    }

    /* Localize script for all front-end JS */
    $localize = array(
        'ajax_url'     => admin_url('admin-ajax.php'),
        'nonce'        => wp_create_nonce('ridego_nonce'),
        'currency'     => ridego_get_setting('currency', 'INR'),
        'currency_sym' => ridego_currency_symbol(),
        'is_logged_in' => is_user_logged_in() ? 1 : 0,
        'is_vendor'    => ridego_is_vendor() ? 1 : 0,
        'user_id'      => get_current_user_id(),
        'home_url'     => home_url('/'),
        'booking_url'  => ridego_page_url('booking_page_id'),
        'search_url'   => ridego_page_url('search_page_id'),
        'my_trips_url' => ridego_page_url('my_trips_page_id'),
        'vendor_url'   => ridego_page_url('vendor_dashboard_page_id'),
        'platform_name'=> function_exists( 'ridego_brand_name' ) ? ridego_brand_name() : ridego_get_setting( 'platform_name', '' ),
    );
    wp_localize_script( 'ridego-public', 'RIDEGO', $localize );
}

/*  Custom cron intervals  */
add_filter( 'cron_schedules', 'ridego_cron_schedules' );
function ridego_cron_schedules( $schedules ) {
    $schedules['every_5_minutes'] = array(
        'interval' => 300,
        'display'  => 'Every 5 Minutes',
    );
    $schedules['every_15_minutes'] = array(
        'interval' => 900,
        'display'  => 'Every 15 Minutes',
    );
    return $schedules;
}

/*  Plugin row links  */
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'ridego_plugin_links' );
function ridego_plugin_links( $links ) {
    $settings = '<a href="' . admin_url('admin.php?page=ridego-settings') . '">Settings</a>';
    $dashboard = '<a href="' . admin_url('admin.php?page=ridego') . '">Dashboard</a>';
    array_unshift( $links, $settings, $dashboard );
    return $links;
}

/*  Helper: page URL from setting key
    Filterable via 'ridego_page_url' (see includes/app-shell.php) so the
    new standalone React app's own routes can take over from the legacy
    WordPress-Page-per-screen model without every caller needing to
    change: the callers keep asking "where's the booking page?" and the
    filter is what decides whether the answer is a WP Page permalink or
    an /app/... route. */
function ridego_page_url( $setting_key ) {
    $page_id = (int) ridego_get_setting($setting_key);
    $url     = $page_id ? get_permalink($page_id) : home_url('/');
    return apply_filters( 'ridego_page_url', $url, $setting_key );
}

/*  Helper: currency symbol  */
function ridego_currency_symbol() {
    $map = array(
        'INR' => '₹',
        'USD' => '$',
        'GBP' => '£',
        'EUR' => '€',
        'AED' => 'AED',
        'SGD' => 'SGD',
        'AUD' => 'A$',
        'CAD' => 'C$',
    );
    $cur = ridego_get_setting('currency','INR');
    return isset($map[$cur]) ? $map[$cur] : $cur;
}

/*  Helper: check if current user is vendor  */
function ridego_is_vendor() {
    return current_user_can('ridego_vendor');
}

/*  Helper: check if current user is admin/manager  */
function ridego_is_admin_user() {
    return current_user_can('manage_options') || current_user_can('ridego_manager');
}

/**
 * Nonce verification helper.
 *
 * Root-cause fix (Wave 2A): the previous version ORed together 3 field
 * names AND 2 hardcoded action names, so a nonce minted for
 * 'ridego_booking_nonce' would satisfy a check the caller declared as
 * 'ridego_nonce' (or vice versa) — this defeats action-scoped CSRF
 * protection, since a nonce is only meaningful together with the action
 * it was issued for.
 *
 * Field-name flexibility is still supported (different forms on the site
 * genuinely use different field names for the same conceptual nonce), but
 * the action the nonce is checked against is exactly what the caller
 * passes — no silent alternate-action fallback. A caller that genuinely
 * needs to accept more than one action (e.g. an AJAX endpoint shared by
 * two different forms that each mint their own nonce) opts in explicitly
 * via $alt_actions, rather than this function guessing on its behalf.
 *
 * @param string $action      The exact nonce action this call site expects.
 * @param array  $alt_actions Additional action names to accept, only for
 *                             call sites that explicitly need multi-action
 *                             acceptance (e.g. a handler shared by two forms
 *                             that mint nonces under different actions).
 */
function ridego_verify_nonce( $action = 'ridego_nonce', $alt_actions = array() ) {
    // Accept different field names (different forms use 'nonce' vs 'rg_nonce'),
    // but always verify against the caller-specified action(s) — never a
    // hardcoded alternate baked into this function.
    $nonce = '';
    if ( ! empty($_POST['nonce']) )         $nonce = sanitize_text_field($_POST['nonce']);
    elseif ( ! empty($_POST['rg_nonce']) )  $nonce = sanitize_text_field($_POST['rg_nonce']);
    elseif ( ! empty($_GET['nonce']) )      $nonce = sanitize_text_field($_GET['nonce']);

    if ( $nonce ) {
        $actions_to_check = array_merge( array( $action ), $alt_actions );
        foreach ( $actions_to_check as $a ) {
            if ( wp_verify_nonce( $nonce, $a ) ) { return; }
        }
    }
    wp_send_json_error( array('message' => 'Security check failed. Please refresh the page.'), 403 );
    exit;
}

/**
 * Verify the admin-ajax nonce and a capability.
 *
 * @param string $capability The specific RideGo (or WP) capability required
 *                            for this action, checked via ridego_can()
 *                            (includes/roles.php — delegates to the
 *                            granular RBAC check in includes/rbac.php, with
 *                            no manage_options bypass other than the
 *                            explicit, audited ridego_super_admin escape
 *                            hatch). Defaults to 'manage_options' for
 *                            handlers that are genuinely admin-only.
 */
function ridego_verify_admin_nonce( $capability = 'manage_options' ) {
    if ( ! check_ajax_referer('ridego_admin_nonce', 'nonce', false) ) {
        wp_send_json_error( array('message' => 'Security check failed.'), 403 );
        exit;
    }
    if ( ! ridego_can( $capability ) ) {
        wp_send_json_error( array('message' => 'Permission denied.'), 403 );
        exit;
    }
}

/*  Format money  */
function ridego_money( $amount, $with_symbol = true ) {
    $formatted = number_format( (float) $amount, 2 );
    if ( $with_symbol ) {
        return ridego_currency_symbol() . $formatted;
    }
    return $formatted;
}

/*  Sanitize phone number  */
function ridego_sanitize_phone( $phone ) {
    $phone = preg_replace('/[^0-9+]/', '', $phone);
    return sanitize_text_field($phone);
}

/*  Generate unique booking number  */
/**
 * Generate the next booking number for the current year, atomically.
 *
 * The old implementation did SELECT COUNT(*)+1, which is a classic
 * TOCTOU race: two concurrent bookings can read the same count, compute
 * the same "next" number, and one INSERT then fails against the UNIQUE
 * KEY on booking_number, surfacing a raw DB error to a customer who may
 * already have paid. This version uses a dedicated single-row-per-counter
 * table (ridego_counters, migration v7) and the standard MySQL atomic
 * counter idiom: INSERT ... ON DUPLICATE KEY UPDATE current_value =
 * LAST_INSERT_ID(current_value + 1), then SELECT LAST_INSERT_ID(). This is
 * safe under concurrency because LAST_INSERT_ID() is per-connection state
 * set by that same statement's row lock/update, not a separate read that
 * can race with another connection's increment (unlike
 * "UPDATE ...; SELECT current_value" done as two separate statements,
 * which would still be racy).
 */
function ridego_generate_booking_number() {
    global $wpdb;
    $year         = date('Y');
    $counter_name = 'booking_number_' . $year;
    $ctbl         = $wpdb->prefix . 'ridego_counters';

    // Seed the counter for this year on first use, from the existing
    // booking count, so numbering continues rather than restarting at 1.
    // INSERT IGNORE makes the seed itself race-safe: if two requests both
    // try to seed concurrently, only one row is created and the other's
    // INSERT IGNORE is a silent no-op.
    $seeded = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$ctbl} WHERE counter_name = %s", $counter_name
    ) );
    if ( ! $seeded ) {
        $btbl = $wpdb->prefix . 'ridego_bookings';
        $seed = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$btbl} WHERE booking_number LIKE %s",
            'RG-' . $year . '-%'
        ) );
        $wpdb->query( $wpdb->prepare(
            "INSERT IGNORE INTO {$ctbl} (counter_name, current_value, updated_at) VALUES (%s, %d, %s)",
            $counter_name, $seed, current_time('mysql')
        ) );
    }

    $wpdb->query( $wpdb->prepare(
        "INSERT INTO {$ctbl} (counter_name, current_value, updated_at) VALUES (%s, 1, %s)
         ON DUPLICATE KEY UPDATE current_value = LAST_INSERT_ID(current_value + 1), updated_at = VALUES(updated_at)",
        $counter_name, current_time('mysql')
    ) );
    $next = (int) $wpdb->get_var( 'SELECT LAST_INSERT_ID()' );
    if ( $next < 1 ) {
        // Fresh row from the INSERT branch (no prior DUPLICATE KEY UPDATE
        // to trigger LAST_INSERT_ID()'s custom expression) — current_value
        // is already 1 in that case.
        $next = 1;
    }

    return 'RG-' . $year . '-' . str_pad( $next, 5, '0', STR_PAD_LEFT );
}

/*  Generate complaint ID  */
function ridego_generate_complaint_id() {
    global $wpdb;
    $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ridego_complaints") + 1;
    return 'CMP-' . date('Y') . '-' . str_pad($count, 5, '0', STR_PAD_LEFT);
}

/*  Time ago helper  */
function ridego_time_ago( $datetime ) {
    $diff = time() - strtotime($datetime);
    if ( $diff < 60 )     return 'just now';
    if ( $diff < 3600 )   return floor($diff/60) . ' min ago';
    if ( $diff < 86400 )  return floor($diff/3600) . ' hr ago';
    if ( $diff < 604800 ) return floor($diff/86400) . ' days ago';
    return date('d M Y', strtotime($datetime));
}

/*  Booking status label
 *  NOTE: this function is only ever called from the guarded
 *  ridego_get_booking_status_label() fallback below (FIX 4), and
 *  includes/helpers.php — loaded earlier, at line 53 of the
 *  `$ridego_includes` require loop (line 128), well before this file
 *  reaches this point — already defines the real
 *  ridego_get_booking_status_label(), so that fallback's
 *  function_exists() guard is always true and this function is never
 *  actually invoked in production. It is kept in sync with the
 *  canonical labels anyway (rather than left to drift, which is how
 *  the 'vendor_assigned' => 'Driver Assigned' bug found in the
 *  canonical copy went unnoticed) so that if the require order ever
 *  changes, this fallback does not reintroduce a stale, wrong label. */
function ridego_booking_status_label( $status ) {
    $labels = array(
        'pending_payment'         => 'Booking Amount Pending',
        'payment_proof_submitted' => 'Proof Submitted',
        'payment_verified'        => 'Payment Verified',
        'payment_rejected'        => 'Payment Rejected',
        'confirmed'               => 'Confirmed',
        'vendor_assigned'         => 'Vendor Assigned',
        'driver_en_route'         => 'Driver En Route',
        'trip_started'            => 'Trip Started',
        'completed'               => 'Completed',
        'cancelled'               => 'Cancelled',
        'disputed'                => 'Disputed',
        'expired'                 => 'Expired',
        'no_vendor'               => 'Finding a Vendor',
    );
    return isset($labels[$status]) ? $labels[$status] : ucwords(str_replace('_',' ',$status));
}

/*  Booking status color  */
function ridego_booking_status_color( $status ) {
    $colors = array(
        'pending_payment'         => '#f59e0b',
        'payment_proof_submitted' => '#3b82f6',
        'confirmed'               => '#10b981',
        'vendor_assigned'         => '#6366f1',
        'driver_en_route'         => '#8b5cf6',
        'trip_started'            => '#06b6d4',
        'completed'               => '#059669',
        'cancelled'               => '#ef4444',
        'disputed'                => '#dc2626',
        'expired'                 => '#94a3b8',
        'no_vendor'               => '#f97316',
    );
    return isset($colors[$status]) ? $colors[$status] : '#64748b';
}

/*  Trip type label  */
function ridego_trip_type_label( $type ) {
    $labels = array(
        'one_way'      => 'One Way',
        'round_trip'   => 'Round Trip',
        'local'        => 'Local Package',
        'airport_pickup' => 'Airport Pickup',
        'airport_drop'   => 'Airport Drop',
        'outstation'   => 'Outstation',
        'corporate'    => 'Corporate',
        'charter'      => 'Bus Charter',
    );
    return isset($labels[$type]) ? $labels[$type] : ucwords(str_replace('_',' ',$type));
}

/*  Compress uploaded image  */
function ridego_compress_image( $file_path, $max_width = 800, $quality = 75 ) {
    if ( ! file_exists($file_path) ) { return $file_path; }
    $info = getimagesize($file_path);
    if ( ! $info ) { return $file_path; }
    $mime = $info['mime'];
    $img  = null;
    if ( $mime === 'image/jpeg' )      { $img = imagecreatefromjpeg($file_path); }
    elseif ( $mime === 'image/png' )   { $img = imagecreatefrompng($file_path); }
    elseif ( $mime === 'image/webp' )  { $img = imagecreatefromwebp($file_path); }
    if ( ! $img ) { return $file_path; }
    $orig_w = imagesx($img);
    $orig_h = imagesy($img);
    if ( $orig_w > $max_width ) {
        $ratio   = $max_width / $orig_w;
        $new_w   = $max_width;
        $new_h   = intval($orig_h * $ratio);
        $resized = imagecreatetruecolor($new_w, $new_h);
        imagecopyresampled($resized, $img, 0, 0, 0, 0, $new_w, $new_h, $orig_w, $orig_h);
        imagedestroy($img);
        $img = $resized;
    }
    $out = preg_replace('/\.(png|jpg|jpeg|webp)$/i', '.jpg', $file_path);
    imagejpeg($img, $out, $quality);
    imagedestroy($img);
    if ( $out !== $file_path && file_exists($file_path) ) {
        unlink($file_path);
    }
    return $out;
}

/*  Serve secure file (for admin to view vendor docs)  */
function ridego_serve_secure_file( $relative_path ) {
    if ( ! ridego_is_admin_user() ) { wp_die('Access denied.'); }
    $full = RIDEGO_SECURE_UPLOADS . $relative_path;
    if ( ! file_exists($full) ) { wp_die('File not found.'); }
    /* Prevent path traversal */
    $real = realpath($full);
    $base = realpath(RIDEGO_SECURE_UPLOADS);
    if ( strpos($real, $base) !== 0 ) { wp_die('Invalid path.'); }
    $mime = mime_content_type($full);
    header('Content-Type: ' . $mime);
    header('Content-Disposition: inline; filename="' . basename($full) . '"');
    header('X-Content-Type-Options: nosniff');
    readfile($full);
    exit;
}
add_action('wp_ajax_ridego_serve_file', function() {
    ridego_verify_admin_nonce();
    $path = sanitize_text_field((isset($_GET['path']) ? $_GET['path'] : ''));
    ridego_serve_secure_file($path);
});

/* ================================================================
   CRITICAL MISSING FUNCTIONS — Production Bug Fixes v4.0
   All functions that were called but never defined
   ================================================================ */

/**
 * FIX 2: ridego_is_trusted_phone() — called in booking-ajax.php but MISSING
 * This caused ALL booking submissions to fail with fatal error
 */
if ( ! function_exists('ridego_is_trusted_phone') ) {
    function ridego_is_trusted_phone( $phone ) {
        if ( ! get_option('ridego_otp_trust_device_enabled', 1) ) return false;
        // ROOT-CAUSE FIX (guest booking "Booking not found" bug): normalize
        // through the same ridego_clean_phone_number() (includes/otp.php)
        // that ridego_verify_otp() applies to $phone BEFORE it calls
        // ridego_add_trusted_device() on success. Without this, a raw
        // 10-digit phone ("9876500099", as typed by the guest and passed
        // straight through by ridego_booking_requires_otp() /
        // ridego_requester_verified_for_booking()) hashed to a different
        // cookie key than the +91-prefixed form ("+919876500099") that
        // ridego_verify_otp() actually trusted the device under — so the
        // trust cookie set right after a guest verifies their OTP was
        // never recognized again, silently forcing OTP re-verification
        // (and consuming the already-verified OTP row) on the very next
        // request, which is what broke the guest booking → confirmation
        // flow.
        $clean = preg_replace('/[^0-9]/', '', function_exists('ridego_clean_phone_number') ? ridego_clean_phone_number($phone) : $phone);
        $cookie_name = 'ridego_trusted_' . md5($clean);
        if ( isset($_COOKIE[$cookie_name]) ) {
            $expected = wp_hash($clean . NONCE_SALT);
            if ( sanitize_text_field($_COOKIE[$cookie_name]) === $expected ) return true;
        }
        return false;
    }
    function ridego_trust_phone( $phone ) {
        $clean = preg_replace('/[^0-9]/', '', function_exists('ridego_clean_phone_number') ? ridego_clean_phone_number($phone) : $phone);
        $val = wp_hash($clean . NONCE_SALT);
        setcookie('ridego_trusted_' . md5($clean), $val, time() + (30 * DAY_IN_SECONDS), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
    }
}

/**
 * Independent Email OTP Verification: trusted-device cookie for the
 * email channel, parallel to ridego_is_trusted_phone()/ridego_trust_phone()
 * above but keyed by email (own cookie namespace, 'ridego_trusted_email_'),
 * so a phone trust cookie never satisfies the email gate or vice versa.
 */
if ( ! function_exists('ridego_is_trusted_email') ) {
    function ridego_is_trusted_email( $email ) {
        if ( ! get_option('ridego_otp_trust_device_enabled', 1) ) return false;
        $clean = strtolower( sanitize_email( $email ) );
        if ( ! $clean ) return false;
        $cookie_name = 'ridego_trusted_email_' . md5($clean);
        if ( isset($_COOKIE[$cookie_name]) ) {
            $expected = wp_hash($clean . NONCE_SALT);
            if ( sanitize_text_field($_COOKIE[$cookie_name]) === $expected ) return true;
        }
        return false;
    }
    function ridego_trust_email( $email ) {
        $clean = strtolower( sanitize_email( $email ) );
        if ( ! $clean ) return;
        $val = wp_hash($clean . NONCE_SALT);
        setcookie('ridego_trusted_email_' . md5($clean), $val, time() + (30 * DAY_IN_SECONDS), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
    }
}

/**
 * FIX 3: ridego_use_promo() — called in booking.php after promo applied but MISSING
 * This crashed booking creation whenever a promo code was used
 */
if ( ! function_exists('ridego_use_promo') ) {
    function ridego_use_promo( $code, $booking_id, $user_id = 0 ) {
        global $wpdb;
        $code = strtoupper(sanitize_text_field($code));
        if ( ! $code ) return false;
        // Increment usage counter
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}ridego_promo_codes SET used_count = used_count + 1, updated_at = %s WHERE code = %s",
            current_time('mysql'), $code
        ));
        // Log usage in promo_usage table if it exists
        $usage_tbl = $wpdb->prefix . 'ridego_promo_usage';
        if ( $wpdb->get_var("SHOW TABLES LIKE '$usage_tbl'") === $usage_tbl ) {
            $promo_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}ridego_promo_codes WHERE code=%s", $code));
            if ( $promo_id ) {
                $wpdb->insert($usage_tbl, array(
                    'promo_id'   => $promo_id,
                    'booking_id' => $booking_id,
                    'user_id'    => $user_id ?: get_current_user_id(),
                    'used_at'    => current_time('mysql'),
                ));
            }
        }
        return true;
    }
}

/**
 * FIX 4: ridego_get_booking_status_label() — used in shortcodes but wrong name used
 */
if ( ! function_exists('ridego_get_booking_status_label') ) {
    function ridego_get_booking_status_label( $status ) {
        return ridego_booking_status_label($status);
    }
}

/**
 * FIX 5: ridego_cancel_booking() — the canonical implementation now lives
 * in includes/booking.php (loaded earlier in the require order, so this
 * guarded fallback never actually executes). That version additionally
 * handles vendor lead-fee refund logic and the client-ownership check
 * this one never had, so it's kept as the single source of truth rather
 * than left as a second, divergent copy that could silently drift out of
 * sync with it.
 */

/**
 * FIX 6: ridego_create_vendor() return type — should always return vendor_id or array
 */
add_filter('ridego_after_create_vendor', function($result, $data) {
    return $result;
}, 10, 2);

/**
 * FIX 7 (superseded): the old code created a second, parallel
 * `ridego_wallet_transactions` table on EVERY `init` request as a
 * patch for a table-naming mismatch in dummy-data seeding. That is
 * exactly the ad hoc schema-patching anti-pattern responsible for
 * most of the schema/code drift bugs found in the production audit.
 * The real fix is: (1) dummy-data.php now inserts into the correct,
 * canonical `ridego_vendor_wallets` table directly (see
 * includes/dummy-data.php), and (2) migration 002
 * (includes/migrations.php) migrates any rows a prior install left
 * in the stray table into the canonical ledger and drops it, once,
 * via the real migration runner — not on every page load.
 */

/**
 * FIX 8: ridego_verify_admin_nonce accepts both nonce field names
 */
if ( ! function_exists('ridego_verify_admin_nonce_v2') ) {
    // Patch the existing function by adding a hook
    add_action('ridego_before_admin_action', function() {
        // Compatibility layer already handled in ridego_verify_nonce fix above
    });
}

