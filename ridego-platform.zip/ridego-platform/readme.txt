=== RideGo Platform ===
Contributors: ridego
Tags: cab booking, taxi, ride sharing, marketplace, lead generation
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 8.0
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Complete enterprise cab & taxi booking platform with vendor lead-charge marketplace model.

== Description ==

RideGo is a full-stack cab and taxi aggregator platform for WordPress. It auto-creates
all required pages, database tables, and seed data on activation - no manual setup
required.

Features:

* End-to-end booking flow (6 booking types, 8 vehicle types)
* Manual bank/UPI payment + Razorpay gateway
* Vendor registration, KYC and approval workflow
* Lead distribution and vendor wallet
* Multi-channel notifications (WhatsApp, Email, SMS, Telegram)
* OTP verification system
* Dynamic pricing and promo codes
* Admin analytics dashboard, payment verification UI, settings panel
* Security hardening (CSRF, XSS, SQL-injection, rate limiting, audit log)
* Performance: caching, indexes, deferred scripts

== Installation ==

1. Upload the `ridego-platform` folder to `/wp-content/plugins/` (or upload the ZIP via Plugins -> Add New -> Upload Plugin).
2. Activate the plugin through the Plugins menu in WordPress.
3. Go to RideGo -> Settings and configure:
   - Google Maps API key
   - Bank / UPI details (for manual payments)
   - Razorpay keys (optional, for gateway)
   - Notification channel keys (WhatsApp / Email / SMS / Telegram)
4. All public pages (Home, Booking, FAQ, Terms, Vendor, etc.) are auto-created on activation.

== Frequently Asked Questions ==

= Do I need to create the database tables manually? =
No. All 20+ tables are created on activation, with cities/vehicles/routes pre-seeded.

= Can I use it without a payment gateway? =
Yes. Manual bank/UPI transfer with admin verification is supported out of the box.

== Changelog ==

= 1.1.0 =
* Marketplace release: individual and fleet vendors, compare-and-select leads, assignments, ledger and commission models, matching flags (off by default), impersonation, Command Centre.
* Upgrades in place: migrations, capabilities and rewrite rules update automatically on the first request after replacing the plugin files.

= 1.0.0 =
* Initial production release.
* Sessions 1-6 complete: foundation, booking engine, vendor & payment, notifications,
  admin panel, security & performance.

== Upgrade Notice ==

= 1.1.0 =
Replace the existing ridego-platform folder (keep the plugin active); database migrations run automatically.

= 1.0.0 =
First stable release.
