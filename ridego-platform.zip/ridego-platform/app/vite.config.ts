import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'
import { VitePWA } from 'vite-plugin-pwa'

// https://vite.dev/config/
export default defineConfig(({ command }) => ({
  plugins: [
    react(),
    /**
     * Mobile-first transformation, Phase 4: installable PWA shell.
     *
     * Deliberately scoped narrow — this is a WordPress-hosted plugin app,
     * not a fully offline app, and the fare/booking/OTP data it shows must
     * never come from a stale cache:
     * - `registerType: 'autoUpdate'` — a new deploy takes effect on the
     *   very next navigation, not "whenever the user happens to close
     *   every tab", which matters for a live fare/pricing engine.
     * - `navigateFallbackDenylist` keeps the SPA-shell fallback (used for
     *   deep links / refreshes on client-side routes) from ever
     *   intercepting a `/wp-json/` or `/wp-admin/` request — those must
     *   always reach WordPress.
     * - `runtimeCaching` has exactly one rule for `/wp-json/ridego/`
     *   (every REST call this app makes — auth, OTP, fares, bookings,
     *   payments, admin data, all of it) and it is NetworkOnly: nothing
     *   under that path is ever written to a cache, so there is no way
     *   for a booking, an OTP code, or account/session data to be served
     *   stale or read back later from disk.
     * - Static build assets (JS/CSS chunks, fonts, the app's own icons)
     *   use StaleWhileRevalidate so a repeat visit is instant but still
     *   self-heals within one background fetch.
     */
    VitePWA({
      // The SPA now owns the domain root itself (see includes/app-shell.php)
      // — `base` is what makes vite-plugin-pwa register the service worker
      // at /sw.js with scope / instead of some sub-path.
      base: '/',
      registerType: 'autoUpdate',
      includeAssets: ['favicon.svg', 'icons/apple-touch-icon.png'],
      manifest: {
        name: 'RideGo — Outstation & Local Cabs',
        short_name: 'RideGo',
        description: 'Book outstation, round trip and local cabs with verified driver-partners.',
        theme_color: '#1a6ef5',
        background_color: '#ffffff',
        display: 'standalone',
        start_url: '/',
        scope: '/',
        // Relative (not root-absolute) on purpose: per the Web App
        // Manifest spec, an icon `src` resolves against the manifest
        // file's OWN url, not the page's — and this plugin serves the
        // manifest at `/manifest.webmanifest` (see app-shell.php's
        // ridego_app_maybe_serve_static_pwa_file()), not at some other
        // sub-path.
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        // The SPA shell is personalised per request by PHP (window.__RIDEGO__ carries the
        // visitor's auth state + nonce), so a precached index.html served as a navigation
        // fallback makes logged-in users look logged out on reload. Navigations must always
        // reach WordPress; index.html is not precached either.
        navigateFallback: null,
        globPatterns: ['**/*.{js,css,svg,png,woff2}'],
        navigateFallbackDenylist: [/^\/wp-json\//, /^\/wp-admin\//, /\?rest_route=/],
        runtimeCaching: [
          {
            // Every REST call this app makes lives under this one prefix
            // (see lib/api.ts's apiBase()) — NetworkOnly means the service
            // worker never touches it, so no auth/OTP/fare/booking/payment
            // response is ever cached or served stale.
            urlPattern: /\/wp-json\/ridego\//,
            handler: 'NetworkOnly',
          },
          {
            urlPattern: ({ request }) =>
              request.destination === 'script' || request.destination === 'style' || request.destination === 'font',
            handler: 'StaleWhileRevalidate',
            options: { cacheName: 'ridego-static-assets' },
          },
        ],
      },
    }),
  ],
  // ROOT-CAUSE FIX (Phase 5 regression sweep): a root-absolute base
  // ('/') is correct for `npm run dev` (served at the dev server's own
  // root), but wrong for the production build — this plugin mounts the
  // built app under a WordPress plugin path
  // (/wp-content/plugins/ridego-platform/app/dist/), not the domain
  // root. The entry index.html's own <script src="/assets/...">/
  // <link href="/assets/...">  tags were already being string-replaced
  // to the real plugin URL at request time (see
  // includes/app-shell.php's ridego_app_render_shell()) — but Vite also
  // bakes that SAME absolute '/assets/...' base into every
  // dynamically-lazy-loaded route chunk's modulepreload <link>, which
  // the client runtime injects into <head> at navigation time, entirely
  // outside that one-time PHP string-replace pass. Found live during
  // this phase's full route sweep: every route whose page component is
  // React.lazy()-loaded (all of them, per Phase 1) was firing a real
  // 404 for a wrongly-based `/assets/ThatPage-xxxx.js` modulepreload
  // hint on every navigation — invisible in normal use only because the
  // *actual* dynamic import() call separately resolves against
  // import.meta.url (the entry script's real, correctly-rewritten URL)
  // and succeeds regardless, but still 43 wasted, console-cluttering,
  // network-cluttering 404s across the app. A relative build base makes
  // Vite compute every chunk reference (both the real import() and the
  // modulepreload hint) relative to import.meta.url instead of an
  // absolute root, so both agree and both resolve correctly no matter
  // what path the SPA is actually mounted under.
  base: command === 'build' ? './' : '/',
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
  },
}))
