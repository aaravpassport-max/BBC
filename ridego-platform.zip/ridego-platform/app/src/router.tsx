import { lazy } from 'react';
import { createBrowserRouter, Navigate, useLocation, useParams } from 'react-router-dom';
import { AppLayout } from './components/layout/AppLayout';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { RequireAuth } from './components/RequireAuth';
import { RequireAdmin } from './components/RequireAdmin';

/**
 * Mobile-first transformation, Phase 1: route-based code splitting.
 *
 * Every page used to be a static top-level import, so all 43 screens —
 * including all 22 admin-only pages — shipped in one ~750KB JS chunk to
 * every visitor, even an anonymous customer who only ever opens the home
 * page (confirmed in the architecture audit: zero React.lazy/dynamic
 * import() usage anywhere in the codebase before this change). Converting
 * every page to React.lazy() means each route's code only downloads when
 * that route is actually visited, and the entire admin/* tree (the
 * largest, least-visited slice of the app for a typical customer session)
 * splits into its own chunks. AppLayout wraps the <Outlet/> in a single
 * <Suspense> boundary, so a route change shows the app shell's existing
 * skeleton-style loading affordance instead of a blank screen while its
 * chunk downloads — the same pattern already used for in-page data
 * loading elsewhere in this app, just applied at the route level.
 */
const HomePage = lazy(() => import('./pages/HomePage').then((m) => ({ default: m.HomePage })));
const LoginPage = lazy(() => import('./pages/LoginPage').then((m) => ({ default: m.LoginPage })));
const RegisterPage = lazy(() => import('./pages/RegisterPage').then((m) => ({ default: m.RegisterPage })));
const MyTripsPage = lazy(() => import('./pages/MyTripsPage').then((m) => ({ default: m.MyTripsPage })));
const VendorDashboardPage = lazy(() =>
  import('./pages/VendorDashboardPage').then((m) => ({ default: m.VendorDashboardPage }))
);
const VendorTripsPage = lazy(() => import('./pages/VendorTripsPage').then((m) => ({ default: m.VendorTripsPage })));
const HelpPage = lazy(() => import('./pages/HelpPage').then((m) => ({ default: m.HelpPage })));
const TermsPage = lazy(() => import('./pages/TermsPage').then((m) => ({ default: m.TermsPage })));
const AboutPage = lazy(() => import('./pages/AboutPage').then((m) => ({ default: m.AboutPage })));
const NotFoundPage = lazy(() => import('./pages/NotFoundPage').then((m) => ({ default: m.NotFoundPage })));
const AdminVendorsPage = lazy(() =>
  import('./pages/admin/AdminVendorsPage').then((m) => ({ default: m.AdminVendorsPage }))
);
const AdminVendorCreatePage = lazy(() =>
  import('./pages/admin/AdminVendorCreatePage').then((m) => ({ default: m.AdminVendorCreatePage }))
);
const AdminVendorDetailPage = lazy(() =>
  import('./pages/admin/AdminVendorDetailPage').then((m) => ({ default: m.AdminVendorDetailPage }))
);
const AdminBookingsPage = lazy(() =>
  import('./pages/admin/AdminBookingsPage').then((m) => ({ default: m.AdminBookingsPage }))
);
const AdminNeedsAttentionPage = lazy(() =>
  import('./pages/admin/AdminNeedsAttentionPage').then((m) => ({ default: m.AdminNeedsAttentionPage }))
);
const AdminClientsPage = lazy(() => import('./pages/admin/AdminClientsPage').then((m) => ({ default: m.AdminClientsPage })));
const AdminClientDetailPage = lazy(() =>
  import('./pages/admin/AdminClientDetailPage').then((m) => ({ default: m.AdminClientDetailPage }))
);
const AdminBookingCreatePage = lazy(() =>
  import('./pages/admin/AdminBookingCreatePage').then((m) => ({ default: m.AdminBookingCreatePage }))
);
const AdminEnquiriesPage = lazy(() =>
  import('./pages/admin/AdminEnquiriesPage').then((m) => ({ default: m.AdminEnquiriesPage }))
);
const AdminInvoicePage = lazy(() => import('./pages/admin/AdminInvoicePage').then((m) => ({ default: m.AdminInvoicePage })));
const AdminBookingDetailPage = lazy(() =>
  import('./pages/admin/AdminBookingDetailPage').then((m) => ({ default: m.AdminBookingDetailPage }))
);
const AdminCitiesPage = lazy(() =>
  import('./pages/admin/AdminCitiesPage').then((m) => ({ default: m.AdminCitiesPage }))
);
const AdminRoutesPage = lazy(() =>
  import('./pages/admin/AdminRoutesPage').then((m) => ({ default: m.AdminRoutesPage }))
);
const AdminRoutePagesPage = lazy(() =>
  import('./pages/admin/AdminRoutePagesPage').then((m) => ({ default: m.AdminRoutePagesPage }))
);
const RoutePage = lazy(() => import('./pages/RoutePage').then((m) => ({ default: m.RoutePage })));
const RoutesIndexPage = lazy(() => import('./pages/RoutesIndexPage').then((m) => ({ default: m.RoutesIndexPage })));
const AdminZonesPage = lazy(() => import('./pages/admin/AdminZonesPage').then((m) => ({ default: m.AdminZonesPage })));
const AdminRoutePageSettingsPage = lazy(() =>
  import('./pages/admin/AdminRoutePageSettingsPage').then((m) => ({ default: m.AdminRoutePageSettingsPage }))
);
const AdminPricingPage = lazy(() =>
  import('./pages/admin/AdminPricingPage').then((m) => ({ default: m.AdminPricingPage }))
);
const AdminSurgePage = lazy(() => import('./pages/admin/AdminSurgePage').then((m) => ({ default: m.AdminSurgePage })));
const AdminPromoPage = lazy(() => import('./pages/admin/AdminPromoPage').then((m) => ({ default: m.AdminPromoPage })));
const AdminReportsPage = lazy(() =>
  import('./pages/admin/AdminReportsPage').then((m) => ({ default: m.AdminReportsPage }))
);
const AdminFinancialPage = lazy(() =>
  import('./pages/admin/AdminFinancialPage').then((m) => ({ default: m.AdminFinancialPage }))
);
const AdminComplaintsPage = lazy(() =>
  import('./pages/admin/AdminComplaintsPage').then((m) => ({ default: m.AdminComplaintsPage }))
);
const AdminSubscriptionsPage = lazy(() =>
  import('./pages/admin/AdminSubscriptionsPage').then((m) => ({ default: m.AdminSubscriptionsPage }))
);
const AdminAuditLogPage = lazy(() =>
  import('./pages/admin/AdminAuditLogPage').then((m) => ({ default: m.AdminAuditLogPage }))
);
const AdminLeadsPage = lazy(() => import('./pages/admin/AdminLeadsPage').then((m) => ({ default: m.AdminLeadsPage })));
const AdminDashboardPage = lazy(() =>
  import('./pages/admin/AdminDashboardPage').then((m) => ({ default: m.AdminDashboardPage }))
);
const AdminSettingsPage = lazy(() =>
  import('./pages/admin/AdminSettingsPage').then((m) => ({ default: m.AdminSettingsPage }))
);
const AdminToolsPage = lazy(() => import('./pages/admin/AdminToolsPage').then((m) => ({ default: m.AdminToolsPage })));
const AdminNotificationsPage = lazy(() =>
  import('./pages/admin/AdminNotificationsPage').then((m) => ({ default: m.AdminNotificationsPage }))
);
const BookingPage = lazy(() => import('./pages/BookingPage').then((m) => ({ default: m.BookingPage })));
const ConfirmPage = lazy(() => import('./pages/ConfirmPage').then((m) => ({ default: m.ConfirmPage })));
const VendorRegisterPage = lazy(() =>
  import('./pages/VendorRegisterPage').then((m) => ({ default: m.VendorRegisterPage }))
);
const TrackPage = lazy(() => import('./pages/TrackPage').then((m) => ({ default: m.TrackPage })));
const VendorKycPage = lazy(() => import('./pages/VendorKycPage').then((m) => ({ default: m.VendorKycPage })));
const ProfilePage = lazy(() => import('./pages/ProfilePage').then((m) => ({ default: m.ProfilePage })));
const SearchResultsPage = lazy(() =>
  import('./pages/SearchResultsPage').then((m) => ({ default: m.SearchResultsPage }))
);
const VehicleDetailPage = lazy(() =>
  import('./pages/VehicleDetailPage').then((m) => ({ default: m.VehicleDetailPage }))
);
const NotificationsPage = lazy(() =>
  import('./pages/NotificationsPage').then((m) => ({ default: m.NotificationsPage }))
);
const TransactionsPage = lazy(() =>
  import('./pages/TransactionsPage').then((m) => ({ default: m.TransactionsPage }))
);
const ReviewsPage = lazy(() => import('./pages/ReviewsPage').then((m) => ({ default: m.ReviewsPage })));
const VendorOnboardPage = lazy(() =>
  import('./pages/VendorOnboardPage').then((m) => ({ default: m.VendorOnboardPage }))
);
const ServicesPage = lazy(() => import('./pages/ServicesPage').then((m) => ({ default: m.ServicesPage })));

const ClientDashboardPage = lazy(() =>
  import('./pages/client/ClientDashboardPage').then((m) => ({ default: m.ClientDashboardPage }))
);
const ClientTripsPage = lazy(() => import('./pages/client/ClientTripsPage').then((m) => ({ default: m.ClientTripsPage })));
const ClientTripDetailPage = lazy(() =>
  import('./pages/client/ClientTripDetailPage').then((m) => ({ default: m.ClientTripDetailPage }))
);
const ClientSupportPage = lazy(() =>
  import('./pages/client/ClientSupportPage').then((m) => ({ default: m.ClientSupportPage }))
);
const ClientAddressesPage = lazy(() =>
  import('./pages/client/ClientAddressesPage').then((m) => ({ default: m.ClientAddressesPage }))
);
const VendorFleetPage = lazy(() => import('./pages/vendor-mkt/VendorFleetPage').then((m) => ({ default: m.VendorFleetPage })));
const VendorBookingDetailPage = lazy(() =>
  import('./pages/vendor-mkt/VendorBookingDetailPage').then((m) => ({ default: m.VendorBookingDetailPage }))
);
const VendorSettlementsPage = lazy(() =>
  import('./pages/vendor-mkt/VendorSettlementsPage').then((m) => ({ default: m.VendorSettlementsPage }))
);
const VendorPerformancePage = lazy(() =>
  import('./pages/vendor-mkt/VendorPerformancePage').then((m) => ({ default: m.VendorPerformancePage }))
);
const AdminCommandCentrePage = lazy(() =>
  import('./pages/admin/AdminCommandCentrePage').then((m) => ({ default: m.AdminCommandCentrePage }))
);
const AdminBookingComparePage = lazy(() =>
  import('./pages/admin/AdminBookingComparePage').then((m) => ({ default: m.AdminBookingComparePage }))
);
const AdminCommissionPage = lazy(() =>
  import('./pages/admin/AdminCommissionPage').then((m) => ({ default: m.AdminCommissionPage }))
);
const AdminDocumentExpiryPage = lazy(() =>
  import('./pages/admin/AdminDocumentExpiryPage').then((m) => ({ default: m.AdminDocumentExpiryPage }))
);
const AdminTeamPage = lazy(() => import('./pages/admin/AdminTeamPage').then((m) => ({ default: m.AdminTeamPage })));
const TeamDashboardPage = lazy(() => import('./pages/TeamDashboardPage').then((m) => ({ default: m.TeamDashboardPage })));
const DriverDashboardPage = lazy(() => import('./pages/DriverDashboardPage').then((m) => ({ default: m.DriverDashboardPage })));
const DriverTripDetailPage = lazy(() => import('./pages/DriverTripDetailPage').then((m) => ({ default: m.DriverTripDetailPage })));
const AdminLeadFeePage = lazy(() => import('./pages/admin/AdminLeadFeePage').then((m) => ({ default: m.AdminLeadFeePage })));
const VendorTermsPage = lazy(() => import('./pages/vendor-mkt/VendorTermsPage').then((m) => ({ default: m.VendorTermsPage })));
const AdminLedgerPage = lazy(() => import('./pages/admin/AdminLedgerPage').then((m) => ({ default: m.AdminLedgerPage })));
const AdminPerformancePage = lazy(() =>
  import('./pages/admin/AdminPerformancePage').then((m) => ({ default: m.AdminPerformancePage }))
);
const AdminMatchingPage = lazy(() => import('./pages/admin/AdminMatchingPage').then((m) => ({ default: m.AdminMatchingPage })));
const AdminMarketplaceReportsPage = lazy(() =>
  import('./pages/admin/AdminMarketplaceReportsPage').then((m) => ({ default: m.AdminMarketplaceReportsPage }))
);

/**
 * Backward compatibility: the app used to be mounted under '/app/...';
 * a bookmarked or shared '/app/some/path' link now lands here and is
 * sent to its unprefixed equivalent, preserving any query string/hash.
 */
function LegacyAppPrefixRedirect() {
  const { '*': rest } = useParams();
  const { search, hash } = useLocation();
  return <Navigate to={`/${rest ?? ''}${search}${hash}`} replace />;
}

export const router = createBrowserRouter([
  // The SPA is now mounted at the domain root itself — every in-app
  // route lives unprefixed (e.g. '/login', '/admin/...') instead of
  // under the old '/app/...' prefix. A bookmarked '/app/*' URL is
  // redirected client-side to its unprefixed equivalent (belt-and-
  // braces alongside includes/app-shell.php's server-side 301, which
  // handles the common case of a fresh, uncached navigation).
  { path: '/app/*', element: <LegacyAppPrefixRedirect /> },
  { path: '/routes/:slug', element: <RoutePage /> },
  {
    path: '/',
    element: <AppLayout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'login', element: <LoginPage /> },
      { path: 'register', element: <RegisterPage /> },
      { path: 'book', element: <BookingPage /> },
      { path: 'search', element: <SearchResultsPage /> },
      { path: 'vehicles/:slug', element: <VehicleDetailPage /> },
      { path: 'confirm', element: <ConfirmPage /> },
      { path: 'track', element: <TrackPage /> },
      { path: 'vendor/register', element: <VendorRegisterPage /> },
      {
        path: 'my-trips',
        element: (
          <RequireAuth>
            <MyTripsPage />
          </RequireAuth>
        ),
      },
      {
        path: 'vendor/dashboard',
        element: (
          <RequireAuth>
            <VendorDashboardPage />
          </RequireAuth>
        ),
      },
      {
        path: 'vendor/kyc',
        element: (
          <RequireAuth>
            <VendorKycPage />
          </RequireAuth>
        ),
      },
      {
        path: 'vendor/trips',
        element: (
          <RequireAuth>
            <VendorTripsPage />
          </RequireAuth>
        ),
      },
      {
        path: 'notifications',
        element: (
          <RequireAuth>
            <NotificationsPage />
          </RequireAuth>
        ),
      },
      {
        path: 'dashboard',
        element: (
          <RequireAuth>
            <ClientDashboardPage />
          </RequireAuth>
        ),
      },
      {
        path: 'dashboard/trips',
        element: (
          <RequireAuth>
            <ClientTripsPage />
          </RequireAuth>
        ),
      },
      {
        path: 'dashboard/trips/:id',
        element: (
          <RequireAuth>
            <ClientTripDetailPage />
          </RequireAuth>
        ),
      },
      {
        path: 'dashboard/support',
        element: (
          <RequireAuth>
            <ClientSupportPage />
          </RequireAuth>
        ),
      },
      {
        path: 'dashboard/addresses',
        element: (
          <RequireAuth>
            <ClientAddressesPage />
          </RequireAuth>
        ),
      },
      {
        path: 'vendor/fleet',
        element: (
          <RequireAuth>
            <VendorFleetPage />
          </RequireAuth>
        ),
      },
      {
        path: 'vendor/bookings/:id',
        element: (
          <RequireAuth>
            <VendorBookingDetailPage />
          </RequireAuth>
        ),
      },
      {
        path: 'vendor/commercial-terms',
        element: (
          <RequireAuth>
            <VendorTermsPage />
          </RequireAuth>
        ),
      },
      {
        path: 'vendor/settlements',
        element: (
          <RequireAuth>
            <VendorSettlementsPage />
          </RequireAuth>
        ),
      },
      {
        path: 'vendor/performance',
        element: (
          <RequireAuth>
            <VendorPerformancePage />
          </RequireAuth>
        ),
      },
      {
        path: 'admin/command-centre',
        element: (
          <RequireAdmin capability="ridego_view_command_centre">
            <AdminCommandCentrePage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/bookings/:id/compare',
        element: (
          <RequireAdmin capability="ridego_assign_vendor">
            <AdminBookingComparePage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/commission',
        element: (
          <RequireAdmin capability="ridego_manage_commission_models">
            <AdminCommissionPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/team',
        element: (
          <RequireAdmin>
            <AdminTeamPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'team',
        element: (
          <RequireAuth>
            <TeamDashboardPage />
          </RequireAuth>
        ),
      },
      {
        path: 'driver',
        element: (
          <RequireAuth>
            <DriverDashboardPage />
          </RequireAuth>
        ),
      },
      {
        path: 'driver/trips/:id',
        element: (
          <RequireAuth>
            <DriverTripDetailPage />
          </RequireAuth>
        ),
      },
      {
        path: 'admin/lead-fee',
        element: (
          <RequireAdmin capability="ridego_manage_settings">
            <AdminLeadFeePage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/ledger',
        element: (
          <RequireAdmin capability="ridego_view_ledger">
            <AdminLedgerPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/performance',
        element: (
          <RequireAdmin capability="ridego_view_performance_data">
            <AdminPerformancePage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/matching',
        element: (
          <RequireAdmin capability="ridego_manage_automatic_assignment">
            <AdminMatchingPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/reports/marketplace',
        element: (
          <RequireAdmin capability="ridego_view_reports">
            <AdminMarketplaceReportsPage />
          </RequireAdmin>
        ),
      },
      { path: 'help', element: <HelpPage /> },
      { path: 'about', element: <AboutPage /> },
      { path: 'terms', element: <TermsPage /> },
      { path: 'services', element: <ServicesPage /> },
      { path: 'routes', element: <RoutesIndexPage /> },
      { path: 'reviews', element: <ReviewsPage /> },
      {
        path: 'profile',
        element: (
          <RequireAuth>
            <ProfilePage />
          </RequireAuth>
        ),
      },
      {
        path: 'transactions',
        element: (
          <RequireAuth>
            <TransactionsPage />
          </RequireAuth>
        ),
      },
      {
        path: 'vendor/onboard',
        element: (
          <RequireAuth>
            <VendorOnboardPage />
          </RequireAuth>
        ),
      },
      {
        path: 'admin/vendors',
        element: (
          <RequireAdmin capability="ridego_manage_vendors">
            <AdminVendorsPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/fleet/document-expiry',
        element: (
          <RequireAdmin capability="ridego_view_fleets">
            <AdminDocumentExpiryPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/vendors/new',
        element: (
          <RequireAdmin capability="ridego_manage_vendors">
            <AdminVendorCreatePage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/vendors/:id',
        element: (
          <RequireAdmin capability="ridego_manage_vendors">
            <AdminVendorDetailPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/clients',
        element: (
          <RequireAdmin capability="ridego_manage_clients">
            <AdminClientsPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/clients/:id',
        element: (
          <RequireAdmin capability="ridego_manage_clients">
            <AdminClientDetailPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/bookings/new',
        element: (
          <RequireAdmin capability="ridego_create_admin_booking">
            <AdminBookingCreatePage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/enquiries',
        element: (
          <RequireAdmin capability="ridego_manage_enquiries">
            <AdminEnquiriesPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/bookings/:id/invoice',
        element: (
          <RequireAdmin capability="ridego_manage_bookings">
            <AdminInvoicePage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/bookings',
        element: (
          <RequireAdmin capability="ridego_manage_bookings">
            <AdminBookingsPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/bookings/needs-attention',
        element: (
          <RequireAdmin capability="ridego_manage_bookings">
            <AdminNeedsAttentionPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/bookings/:id',
        element: (
          <RequireAdmin capability="ridego_manage_bookings">
            <AdminBookingDetailPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/cities',
        element: (
          <RequireAdmin capability="ridego_manage_pricing">
            <AdminCitiesPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/routes',
        element: (
          <RequireAdmin capability="ridego_manage_pricing">
            <AdminRoutesPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/route-pages',
        element: (
          <RequireAdmin capability="ridego_manage_pricing">
            <AdminRoutePagesPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/route-page-settings',
        element: (
          <RequireAdmin capability="ridego_manage_pricing">
            <AdminRoutePageSettingsPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/zones',
        element: (
          <RequireAdmin capability="ridego_manage_pricing">
            <AdminZonesPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/pricing',
        element: (
          <RequireAdmin capability="ridego_manage_pricing">
            <AdminPricingPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/surge',
        element: (
          <RequireAdmin capability="ridego_manage_pricing">
            <AdminSurgePage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/promo',
        element: (
          <RequireAdmin capability="ridego_manage_promo_codes">
            <AdminPromoPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/reports',
        element: (
          <RequireAdmin capability="ridego_view_reports">
            <AdminReportsPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/financial',
        element: (
          <RequireAdmin capability="ridego_view_financial">
            <AdminFinancialPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/complaints',
        element: (
          <RequireAdmin capability="ridego_manage_complaints">
            <AdminComplaintsPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/subscriptions',
        element: (
          <RequireAdmin capability="ridego_manage_subscriptions">
            <AdminSubscriptionsPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/audit-log',
        element: (
          <RequireAdmin capability="ridego_view_audit_log">
            <AdminAuditLogPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/leads',
        element: (
          <RequireAdmin capability="ridego_manage_bookings">
            <AdminLeadsPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin',
        element: (
          <RequireAdmin>
            <AdminDashboardPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/settings',
        element: (
          <RequireAdmin capability="ridego_manage_settings">
            <AdminSettingsPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/tools',
        element: (
          <RequireAdmin>
            <AdminToolsPage />
          </RequireAdmin>
        ),
      },
      {
        path: 'admin/notifications',
        element: (
          <RequireAdmin capability="ridego_send_bulk_message">
            <AdminNotificationsPage />
          </RequireAdmin>
        ),
      },
      { path: '*', element: <NotFoundPage /> },
    ],
  },
  {
    path: '*',
    element: (
      <>
        <Header />
        <NotFoundPage />
        <Footer />
      </>
    ),
  },
]);
