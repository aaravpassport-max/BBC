import { useEffect, useState } from 'react';

/**
 * Loads the Google Maps JavaScript API (with the `places` library) exactly
 * once per page, however many LocationPicker instances mount — a second
 * call with the same key while one is already loading/loaded is a no-op,
 * and a script tag is never injected twice. Any component can call this
 * hook; only the first caller actually creates the <script> tag.
 *
 * Deliberately does NOT use React's <script> hoisting or a bare useEffect
 * `document.createElement('script')` per-component, because either of
 * those would race: two LocationPickers (pickup + drop) mounting in the
 * same render would both see "not loaded yet" and both inject a script
 * tag, and Google's loader throws/warns loudly ("You have included the
 * Google Maps JavaScript API multiple times") when that happens.
 */
type LoaderState = 'idle' | 'loading' | 'loaded' | 'error';

let singleton: { key: string; state: LoaderState; listeners: Set<(state: LoaderState) => void> } | null = null;

function notify() {
  if (!singleton) return;
  singleton.listeners.forEach((fn) => fn(singleton!.state));
}

function ensureLoading(apiKey: string) {
  if (singleton && singleton.key === apiKey) {
    return;
  }
  singleton = { key: apiKey, state: 'loading', listeners: singleton?.listeners ?? new Set() };

  // Already present from a previous mount/unmount cycle in this session.
  if (typeof window !== 'undefined' && (window as unknown as { google?: { maps?: { places?: unknown } } }).google?.maps?.places) {
    singleton.state = 'loaded';
    notify();
    return;
  }

  const existing = document.querySelector<HTMLScriptElement>('script[data-ridego-google-maps]');
  if (existing) {
    // A previous instance (e.g. hot-reload) already added it — just wait for it.
    existing.addEventListener('load', () => {
      if (singleton) { singleton.state = 'loaded'; notify(); }
    });
    existing.addEventListener('error', () => {
      if (singleton) { singleton.state = 'error'; notify(); }
    });
    return;
  }

  const script = document.createElement('script');
  script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(apiKey)}&libraries=places&loading=async`;
  script.async = true;
  script.defer = true;
  script.setAttribute('data-ridego-google-maps', '1');
  script.onload = () => {
    if (singleton) { singleton.state = 'loaded'; notify(); }
  };
  script.onerror = () => {
    if (singleton) { singleton.state = 'error'; notify(); }
  };
  document.head.appendChild(script);
}

/**
 * @param apiKey The Maps JS API key from GET /app/maps-config, or null/undefined
 *   while that's still loading or unset. Pass null to keep the hook idle
 *   (e.g. while the maps-config request hasn't resolved yet).
 */
export function useGoogleMapsLoader(apiKey: string | null | undefined): { status: LoaderState } {
  const [status, setStatus] = useState<LoaderState>(() => (singleton?.state ?? 'idle'));

  useEffect(() => {
    if (!apiKey) return;
    if (!singleton) {
      singleton = { key: apiKey, state: 'idle', listeners: new Set() };
    }
    const listener = (state: LoaderState) => setStatus(state);
    singleton.listeners.add(listener);
    setStatus(singleton.state);
    ensureLoading(apiKey);
    return () => {
      singleton?.listeners.delete(listener);
    };
  }, [apiKey]);

  return { status: apiKey ? status : 'idle' };
}
