import { useEffect, useState } from 'react';

/**
 * Tracks whether a CSS media query currently matches, updating live on
 * viewport/orientation changes (e.g. rotating a phone, or resizing a
 * desktop window past the breakpoint). Used to drive JS-level rendering
 * decisions that plain Tailwind responsive classes can't express on
 * their own — e.g. mounting the mobile booking flow inside an actual
 * full-screen modal (a distinct DOM subtree with its own focus trap and
 * scroll lock) instead of just hiding/showing content with CSS.
 */
export function useMediaQuery(query: string): boolean {
  const getMatch = () => (typeof window !== 'undefined' ? window.matchMedia(query).matches : false);
  const [matches, setMatches] = useState(getMatch);

  useEffect(() => {
    const mql = window.matchMedia(query);
    const onChange = () => setMatches(mql.matches);
    onChange();
    if (mql.addEventListener) {
      mql.addEventListener('change', onChange);
      return () => mql.removeEventListener('change', onChange);
    }
    // Safari < 14 fallback
    mql.addListener(onChange);
    return () => mql.removeListener(onChange);
  }, [query]);

  return matches;
}

/** Matches the app's `lg` Tailwind breakpoint (1024px) — the same cutover
 *  point Header.tsx and MobileBottomNav.tsx already use for their own
 *  mobile/desktop split. */
export function useIsMobileViewport(): boolean {
  return useMediaQuery('(max-width: 1023.98px)');
}
