import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { authLogin, authLogout, authMe, authRegister, setNonce } from '../lib/api';
import { getBootstrap } from '../lib/bootstrap';
import type { AppUser, AuthState, ImpersonationState, LoginRequest, RegisterRequest } from '../types/api';

interface AuthContextValue {
  user: AppUser | null;
  impersonation: ImpersonationState | null;
  isLoggedIn: boolean;
  isVendor: boolean;
  loading: boolean;
  login: (body: LoginRequest) => Promise<AppUser | undefined>;
  register: (body: RegisterRequest) => Promise<void>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
  /**
   * Applies an AuthState the caller already has in hand (same shape
   * /auth/login, /auth/register and /auth/me return) without making a
   * new request — used for the guest-booking auto-login after payment
   * proof submission, whose response embeds this same shape rather
   * than requiring a second round trip. Reuses the exact login/register
   * mechanism (applyAuth) so the resulting session is indistinguishable
   * from one created by the normal login flow.
   */
  applyAuthState: (next: AuthState) => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const initial = getBootstrap().auth;
  const [auth, setAuth] = useState<AuthState>(initial);
  const [loading, setLoading] = useState(false);

  const applyAuth = useCallback((next: AuthState) => {
    setAuth(next);
    setNonce(next.nonce);
  }, []);

  const login = useCallback(
    async (body: LoginRequest) => {
      setLoading(true);
      try {
        const next = await authLogin(body);
        applyAuth(next);
        return next.user;
      } finally {
        setLoading(false);
      }
    },
    [applyAuth]
  );

  const register = useCallback(
    async (body: RegisterRequest) => {
      setLoading(true);
      try {
        const next = await authRegister(body);
        applyAuth(next);
      } finally {
        setLoading(false);
      }
    },
    [applyAuth]
  );

  const logout = useCallback(async () => {
    setLoading(true);
    try {
      const next = await authLogout();
      applyAuth(next);
    } finally {
      setLoading(false);
    }
  }, [applyAuth]);

  const refresh = useCallback(async () => {
    const next = await authMe();
    applyAuth(next);
  }, [applyAuth]);

  // ROOT-CAUSE FIX: this provider used to seed auth state ONLY from
  // getBootstrap().auth (injected server-side into the page's initial
  // HTML by ridego_app_render_shell()) and never verified or refreshed
  // it — a real deployment showed why that's not safe to rely on
  // exclusively: the request that delivers the page's own HTML and the
  // request a live REST call makes are not guaranteed to take the same
  // path through every hosting/proxy setup a customer might use (e.g. a
  // caching or edge layer serving a stale/anonymous copy of the page
  // shell while direct REST API calls still reach WordPress correctly).
  // When that happens, a genuinely logged-in visitor gets permanently
  // stuck looking logged-out, because nothing ever re-checks. The
  // bootstrap value is still used for the very first paint (so there's
  // no loading flash for the common case where it's accurate), but this
  // fires one authoritative /auth/me call right after mount to
  // reconcile with the server's live, REST-verified state — self-
  // healing regardless of whether the initial HTML injection was
  // accurate on any given hosting setup. Silently ignores a failure
  // here (e.g. the visitor is genuinely offline) and keeps whatever the
  // bootstrap already provided rather than breaking the app over it.
  useEffect(() => {
    authMe()
      .then(applyAuth)
      .catch(() => {
        // Keep the bootstrap-seeded state; a transient network/API
        // failure here shouldn't downgrade a user who *did* get a
        // correct server-rendered login state.
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user: auth.logged_in ? auth.user ?? null : null,
      impersonation: auth.logged_in ? auth.impersonation ?? null : null,
      isLoggedIn: auth.logged_in,
      isVendor: !!(auth.logged_in && auth.user?.is_vendor),
      loading,
      login,
      register,
      logout,
      refresh,
      applyAuthState: applyAuth,
    }),
    [auth, loading, login, register, logout, refresh, applyAuth]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
