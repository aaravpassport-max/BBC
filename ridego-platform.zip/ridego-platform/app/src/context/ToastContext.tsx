import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from 'react';

/**
 * Mobile-first transformation, Phase 2: a real app-wide toast system.
 *
 * The transformation brief (item 30) asks that the app avoid browser
 * alert() and give every success/error a proper toast/banner instead.
 * Before this, feedback was 100% per-page (some pages show an inline
 * `<div role="alert">` banner, none share a component) — there was no
 * shared, app-level way to surface a fleeting confirmation. This context
 * is mounted once in AppLayout (see ToastViewport) so any page or any
 * future mobile primitive (bottom sheet actions, pull-to-refresh, etc.)
 * can call useToast().show(...) without re-inventing its own banner.
 */

export type ToastVariant = 'success' | 'error' | 'info';

export interface ToastItem {
  id: number;
  message: string;
  variant: ToastVariant;
}

interface ToastContextValue {
  toasts: ToastItem[];
  show: (message: string, variant?: ToastVariant) => void;
  dismiss: (id: number) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const nextId = useRef(1);

  const dismiss = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const show = useCallback(
    (message: string, variant: ToastVariant = 'info') => {
      const id = nextId.current++;
      setToasts((prev) => [...prev, { id, message, variant }]);
      // Auto-dismiss — 4s is long enough to read a short confirmation
      // without stacking up if several actions fire in quick succession.
      window.setTimeout(() => dismiss(id), 4000);
    },
    [dismiss]
  );

  return <ToastContext.Provider value={{ toasts, show, dismiss }}>{children}</ToastContext.Provider>;
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return ctx;
}
