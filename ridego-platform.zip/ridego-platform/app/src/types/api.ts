// Typed shapes mirroring includes/app-api.php exactly.

export interface City {
  id: number;
  name: string;
  state: string;
  lat: number | null;
  lng: number | null;
  // Admin-uploaded photo (Settings → Cities). '' when none has been uploaded —
  // never a placeholder/stock URL, so the UI must handle the empty case itself.
  image_url: string;
}

// Home page "Popular cities" cards only — starting_fare is a real, computed floor
// price (see ridego_city_starting_fare()), null when the city has no priced route yet.
export interface PopularCity extends City {
  starting_fare: number | null;
}

export interface HomeStats {
  cities_covered: number;
  verified_partners: number;
  avg_rating: number | null;
}

export interface MapsConfig {
  google_maps_key: string | null;
  enabled: boolean;
}

export interface VehiclePricing {
  per_km: number | null;
  per_km_outstation: number | null;
  minimum_km: number | null;
  local_4hr_40km: number | null;
  local_8hr_80km: number | null;
  airport_base_charge: number | null;
}

export interface Vehicle {
  id: number;
  name: string;
  slug: string;
  seating_capacity: number;
  image_url: string;
  base_fare: number | null;
  luggage_capacity: number | null;
  ac_available: boolean | null;
  features: string[];
  pricing: VehiclePricing;
}

export interface AppUser {
  id: number;
  name: string;
  email: string;
  phone: string;
  roles: string[];
  is_admin: boolean;
  /**
   * Granular RideGo admin capabilities the user actually holds
   * (from includes/roles.php), independent of the WP-wide is_admin
   * flag — a ridego_manager/ridego_admin role has some of these
   * without being a full WP administrator. See hasAdminCap() in
   * lib/permissions.ts and RequireAdmin's `capability` prop.
   */
  admin_caps: string[];
  is_vendor: boolean;
  vendor_id: number | null;
  vendor_status: string | null;
  /** 'individual' (one driver/vehicle, auto-confirmed) or 'fleet'. Null for non-vendors. */
  vendor_type?: 'individual' | 'fleet' | null;
  /** True for a Regional Manager restricted to assigned regions. */
  region_limited?: boolean;
  team_modules?: string[];
}

/** Present only while an admin is viewing the app as a client or vendor. */
export interface ImpersonationState {
  active: boolean;
  target_role: string;
  admin_name: string;
  expires_at: string;
  seconds_left: number;
}

export interface AuthState {
  logged_in: boolean;
  nonce: string;
  user?: AppUser;
  impersonation?: ImpersonationState | null;
}

export interface LoginRequest {
  login: string;
  password: string;
}

export interface RegisterRequest {
  name: string;
  email: string;
  phone: string;
  password: string;
  as_vendor?: boolean;
  city?: string;
}

export interface HomeResponse {
  platform_name: string;
  platform_tagline: string;
  currency_symbol: string;
  popular_cities: PopularCity[];
  origin_cities?: City[];
  destination_cities?: City[];
  vehicles: Vehicle[];
  support_phone: string;
  support_whatsapp: string;
  stats: HomeStats;
}

// 'hourly' was never a real backend trip_type (only 'local' is — see
// includes/pricing.php's ridego_calculate_fare()); removed to stop new
// code from reintroducing the mispriced-fare bug it caused.
export type TripType = 'one_way' | 'round_trip' | 'local' | string;

export interface FareRequest {
  trip_type: TripType;
  pickup_city: string;
  drop_city: string;
  vehicle_type_id: number;
  journey_date: string;
  journey_time: string;
  distance_km: number;
  duration_minutes: number;
  hours_required: number;
  return_date: string;
  passengers: number;
  promo_code: string;
}

/** Facilitator model money split. RideGo collects only the booking amount;
 *  the vendor/driver bills and collects the rest of the ride directly. */
export type CollectionStatus = 'none' | 'pending' | 'partly_collected' | 'settled';
/** Vendor lead-fee view (admin and vendor screens only; never present on client APIs). Mirrors ridego_lead_fee_view() in includes/lead-fee.php. */
export interface LeadFeeView {
  applies: boolean;
  is_estimate: boolean;
  amount: number;
  status: string;
  status_label: string;
  base_amount: number;
  method: string;
  method_label: string;
  formula: string;
  terms_id: number | null;
  terms_version: number | null;
  source: string;
  customer_advance_received: number;
  applied_from_advance: number;
  payable_to_ridego: number;
  excess_advance_owed_to_vendor: number;
  locked_at: string | null;
  /** Late-cancellation decision: who gets the advance the client forfeited ('' = nothing forfeited or not decided). */
  forfeit_to: '' | 'platform' | 'vendor';
  forfeit_amount: number;
  forfeit_reason: string;
  forfeit_paid: boolean;
}

/** Vendor lead fee totals for a period (ridego_lead_fee_report). */
export interface LeadFeeReport {
  bookings: number;
  accrued: number;
  outstanding: number;
  collected: number;
  waived_count: number;
  by_status: Record<string, { count: number; amount: number }>;
}

export interface RideMoney {
  platform_model?: boolean;
  /** Estimated ride fare — billed and collected by the vendor/driver, not by RideGo. */
  estimated_ride_fare?: number;
  /** Booking amount RideGo collects (snapshot at booking). */
  booking_amount?: number;
  booking_amount_paid?: number;
  booking_amount_pending?: number;
  /** Ride balance payable directly to the vendor/driver. */
  payable_to_vendor?: number;
  /** Ride balance the vendor/driver reports collecting. */
  vendor_collected?: number;
  vendor_outstanding?: number;
  /** Customer advance set off against the vendor lead fee once a vendor is arranged (facilitator model). */
  lead_fee_retained?: number;
  collection_status?: CollectionStatus;
  vendor_invoice_number?: string;
  vendor_collected_at?: string | null;
}

export interface FareBreakdown {
  base_fare: number;
  total_fare: number;
  discount?: number;
  token_enabled?: boolean;
  token_amount?: number;
  remaining_amount?: number;
  /** Admin-configurable, read live from Settings → Payment on every fare
   *  calculation — never hardcode this copy in a component. */
  token_label?: string;
  token_instructions?: string;
  booking_amount?: number;
  payable_to_vendor?: number;
  estimated_ride_fare?: number;
  disclaimer?: string;
  [key: string]: number | boolean | string | undefined;
}

export interface FareResponse {
  fare: FareBreakdown;
  sym: string;
  promo_error: string | null;
}

export type BookingStatus =
  | 'pending'
  | 'pending_payment'
  | 'payment_pending'
  | 'payment_rejected'
  | 'confirmed'
  | 'no_vendor'
  | 'vendor_assigned'
  | 'driver_en_route'
  | 'trip_started'
  | 'completed'
  | 'cancelled'
  | 'disputed'
  | 'token_refund_due'
  | (string & {});

export interface Booking extends RideMoney {
  id: number;
  booking_number: string;
  status: BookingStatus;
  status_label: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  journey_time: string;
  trip_type: TripType;
  total_fare: number;
  /** Token/advance snapshot at booking time — 0 if the token feature was
   *  off when this booking was placed. */
  token_amount: number;
  vehicle_name: string;
  payment_method: string;
  payment_status: string;
  created_at: string;
  rating: number | null;
  review: string;
}

export interface CancelBookingResponse {
  success: boolean;
  message: string;
}

export interface RateBookingResponse {
  success: boolean;
  message: string;
}

export interface VendorMe {
  id: number;
  business_name: string;
  status: string;
  wallet_balance: number;
  rating: number;
  total_ratings: number;
  total_leads_accepted: number;
  low_wallet: boolean;
}

export interface VendorLead {
  id: number;
  booking_id: number;
  booking_number: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  journey_time: string;
  total_fare: number;
  fee_amount: number;
  lead_fee?: { applies: boolean; amount: number; formula: string; method_label: string; terms_version: number | null; source: string; from_wallet: boolean };
  expires_at: string;
}

export interface AcceptLeadResponse {
  success: boolean;
  message: string;
}

export interface VendorBooking extends RideMoney {
  id: number;
  booking_number: string;
  status: BookingStatus;
  status_label: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  journey_time: string;
  trip_type: TripType;
  total_fare: number;
  /** Advance/token amount already paid online by the client (Token Amount / Advance Payment feature). */
  token_amount: number;
  /** Total amount actually received against this booking so far. */
  advance_paid: number;
  /** Remaining amount the vendor/driver needs to collect from the client (cash/UPI) at drop-off. */
  balance_due: number;
  vehicle_name: string;
  payment_status: string;
  rating: number | null;
  created_at: string;
}

export interface VendorBookingsResponse {
  rows: VendorBooking[];
  total: number;
  page: number;
  per_page: number;
}

export interface WpRestError {
  code: string;
  message: string;
  data?: {
    status: number;
    need_otp?: boolean;
    need_email_otp?: boolean;
    need_phone?: boolean;
    retry_after?: number | null;
    remaining_attempts?: number | null;
    quality_issues?: string[];
  };
}

// ---------------------------------------------------------------------------
// OTP
// ---------------------------------------------------------------------------

export type OtpPurpose = 'booking' | string;

export type OtpChannel = 'phone' | 'email';

export interface OtpSendRequest {
  /** Defaults to 'phone' server-side when omitted, so existing phone-OTP callers are unaffected. */
  channel?: OtpChannel;
  phone?: string;
  email?: string;
  purpose: OtpPurpose;
}

export interface OtpSendResponse {
  success: boolean;
  trusted?: boolean;
  message: string;
}

export interface OtpVerifyRequest {
  channel?: OtpChannel;
  phone?: string;
  email?: string;
  otp: string;
  purpose: OtpPurpose;
}

export interface OtpVerifyResponse {
  success: boolean;
  message: string;
  otp_id?: number;
}

// ---------------------------------------------------------------------------
// Booking creation
// ---------------------------------------------------------------------------

export interface CreateBookingRequest {
  client_name: string;
  client_phone: string;
  client_email: string;
  client_alt_phone: string;
  trip_type: TripType;
  pickup_city: string;
  pickup_address: string;
  pickup_lat: number;
  pickup_lng: number;
  drop_city: string;
  drop_address: string;
  drop_lat: number;
  drop_lng: number;
  journey_date: string;
  journey_time: string;
  return_date: string;
  return_time: string;
  hours_required: number;
  passengers: number;
  luggage_count: number;
  vehicle_type_id: number;
  special_requests: string;
  flight_number: string;
  corporate_company: string;
  corporate_gst: string;
  corporate_emp_id: string;
  promo_code: string;
  payment_method: string;
  distance_km: number;
  duration_minutes: number;
  /** Passenger & Safety Information step — all optional; omitted entirely
   *  by any caller that predates this feature. */
  passenger_total?: number;
  passenger_male?: number;
  passenger_female?: number;
  passenger_children?: number;
  passenger_notes?: string;
  otp_value?: string;
  email_otp_value?: string;
}

export interface CreateBookingResponse {
  success: boolean;
  booking_id: number;
  booking_number: string;
  status: BookingStatus;
  total_fare: number;
  payment_method: string;
  confirm_url: string;
  promo_adjusted?: boolean;
  promo_adjusted_reason?: string;
  deduped?: boolean;
}

// ---------------------------------------------------------------------------
// Booking lookup / payment
// ---------------------------------------------------------------------------

export interface BookingDetail extends Booking {
  pickup_address: string;
  drop_address: string;
  passengers: number;
  distance_km: number;
  base_fare: number;
  toll_charges: number;
  parking_charges: number;
  driver_allowance: number;
  gst_amount: number;
  discount_amount: number;
  promo_code: string | null;
  payment_deadline: string | null;
  payment_utr: string | null;
  payment_amount_claimed: number;
  payment_rejection_reason: string | null;
  otp_pickup: string | null;
  vendor_name: string | null;
  vendor_phone: string | null;
  vendor_whatsapp: string | null;
  balance_due: number;
  refund_amount: number | null;
  refund_reason: string;
  refund_processed_at: string;
}

export interface PaymentDetails {
  bank_name: string | null;
  bank_account: string | null;
  bank_ifsc: string | null;
  bank_holder: string | null;
  upi_id: string | null;
  upi_qr_url: string | null;
  /** Amount actually due right now — the token/advance when the token
   *  feature is on for this booking, otherwise the full ride total. */
  amount: number;
  is_token_payment: boolean;
  token_amount: number;
  total_fare: number;
  remaining_amount: number;
  token_label: string;
  token_instructions: string;
  estimated_ride_fare?: number;
  payable_to_vendor?: number;
  disclaimer?: string;
}

export interface BookingLookupResponse {
  booking: BookingDetail;
  payment_details: PaymentDetails;
  needs_payment: boolean;
  is_confirmed: boolean;
  is_expired: boolean;
  seconds_left: number;
}

export interface PaymentProofRequest {
  proof_file: File;
  utr: string;
  payment_app: string;
  amount: string;
  payment_time: string;
  client_phone: string;
}

export interface PaymentProofResponse {
  success: boolean;
  message: string;
  /** True when this submission triggered guest account auto-creation (see ridego_app_api_submit_payment_proof()). */
  account_created?: boolean;
  /** Present only when account_created is true — the same shape /auth/login and /auth/register return. */
  auth?: AuthState;
}

// ---------------------------------------------------------------------------
// Vendor KYC docs
// ---------------------------------------------------------------------------

export interface VendorDoc {
  id: number;
  doc_type: string;
  status: string;
  expiry_date: string | null;
  uploaded_at: string;
}

export interface VendorDocsResponse {
  required_types: string[];
  kyc_status: string;
  /** The server's real enforced ceiling (min of plugin policy and PHP's upload_max_filesize/post_max_size),
   *  in whole/fractional MB — always use this over any hardcoded client-side limit. */
  max_upload_mb: number;
  docs: VendorDoc[];
}

export interface UploadVendorDocResponse {
  success: boolean;
  doc_id: number;
}

// ---------------------------------------------------------------------------
// Profile / account settings
// ---------------------------------------------------------------------------

export interface ProfileResponse {
  name: string;
  email: string;
  phone: string;
}

export interface UpdateProfileRequest {
  name: string;
  email: string;
  phone: string;
}

export interface UpdateProfileResponse {
  success?: boolean;
  message?: string;
  [key: string]: unknown;
}

export interface ChangePasswordRequest {
  current_password: string;
  new_password: string;
}

export interface ChangePasswordResponse {
  success?: boolean;
  message?: string;
  nonce?: string;
}

// ---------------------------------------------------------------------------
// Notifications
// ---------------------------------------------------------------------------

export interface AppNotification {
  id: number;
  event: string;
  channel: string;
  message: string;
  status: string;
  is_read: boolean;
  sent_at: string;
}

export interface NotificationsResponse {
  rows: AppNotification[];
  total: number;
  unread_count: number;
  page: number;
  per_page: number;
}

export interface MarkNotificationReadResponse {
  success: boolean;
  unread_count: number;
}

// ---------------------------------------------------------------------------
// Transactions
// ---------------------------------------------------------------------------

export interface AppTransaction {
  id: number;
  type: string;
  amount: number;
  gateway: string;
  status: string;
  created_at: string;
  booking_number: string;
  pickup_city: string;
  drop_city: string;
}

export interface TransactionsResponse {
  rows: AppTransaction[];
  total: number;
  page: number;
  per_page: number;
}

// ---------------------------------------------------------------------------
// Reviews
// ---------------------------------------------------------------------------

export interface AppReview {
  id: number;
  client_name: string;
  rating: number;
  review: string;
  pickup_city: string;
  drop_city: string;
  vendor_name: string;
  journey_date: string;
}

export interface PopularRoute {
  slug: string;
  from_city: string;
  to_city: string;
  image_url: string;
  starting_fare: number | null;
}

export interface Partner {
  name: string;
  city: string;
  vehicle_types: string[];
  rating: number | null;
  total_ratings: number | null;
  total_rides_completed: number | null;
}

export interface ReviewsResponse {
  rows: AppReview[];
  total: number;
  page: number;
  per_page: number;
  avg_rating: number | null;
  rating_count: number;
}

// ---------------------------------------------------------------------------
// Vendor onboarding (existing customer becoming a vendor)
// ---------------------------------------------------------------------------

export interface VendorOnboardRequest {
  owner_name: string;
  city: string;
  phone: string;
  business_name?: string;
  business_type?: string;
  total_vehicles?: number;
}

export interface VendorOnboardResponse {
  success: boolean;
  vendor_id: number;
}

// ---------------------------------------------------------------------------
// Admin: vendor management + KYC
// ---------------------------------------------------------------------------

export type VendorStatus = 'pending' | 'active' | 'suspended' | 'blacklisted' | string;

export type VendorKycStatus =
  | 'pending'
  | 'submitted'
  | 'complete'
  | 'verified'
  | 'rejected'
  | 'expired_docs'
  | string;

export interface AdminVendorRow {
  id: number;
  business_name: string;
  owner_name: string;
  phone: string;
  email: string;
  city: string;
  business_type: string;
  vendor_type: 'individual' | 'fleet';
  status: VendorStatus;
  kyc_status: VendorKycStatus;
  kyc_docs_incomplete: boolean;
  kyc_missing_docs: string[];
  wallet_balance: number;
  rating: number;
  total_ratings: number;
  joined_at: string;
}

export interface AdminVendorsResponse {
  rows: AdminVendorRow[];
  total: number;
  page: number;
  per_page: number;
  kpis: {
    total: number;
    active: number;
    kyc_pending: number;
    low_wallet: number;
    wallet_float: number;
    docs_expiring_30d: number;
    expired_docs: number;
  };
}

export interface AdminVendorDoc {
  id: number;
  doc_type: string;
  status: string;
  file_path: string;
  expiry_date: string | null;
  uploaded_at: string;
}

export interface AdminVendorKpis {
  total_leads: number;
  accepted_leads: number;
  completed_rides: number;
  fees_paid: number;
}

export interface AdminVendorWalletTx {
  id: number;
  created_at: string;
  type: string;
  amount: number;
  notes: string;
}

export interface AdminVendorDetail {
  id: number;
  business_name: string;
  owner_name: string;
  phone: string;
  alt_phone: string;
  whatsapp_number: string;
  email: string;
  city: string;
  operating_cities: string;
  vehicle_types: string;
  business_type: string;
  gst_number: string;
  pan_number: string;
  license_number: string;
  insurance_policy: string;
  address: string;
  total_vehicles: number;
  years_experience: number;
  background_check: boolean;
  total_rides_completed: number;
  commission_pct: number;
  bank_name: string;
  bank_account: string;
  bank_ifsc: string;
  bank_holder: string;
  upi_id: string;
  notes_admin: string;
  status: VendorStatus;
  kyc_status: VendorKycStatus;
  kyc_missing_docs: string[];
  documents_verified: boolean;
  wallet_balance: number;
  rating: number;
  total_ratings: number;
  joined_at: string;
  kpis: AdminVendorKpis;
  wallet_history: AdminVendorWalletTx[];
  docs: AdminVendorDoc[];
}

export interface AdminVendorWalletRequest {
  amount: number;
  notes?: string;
}

export interface AdminVendorCreateRequest {
  business_name: string;
  owner_name: string;
  phone: string;
  email: string;
  city: string;
  business_type?: string;
  total_vehicles?: number;
  years_experience?: number;
}

export interface AdminVendorCreateResponse {
  success: boolean;
  vendor_id: number;
  message: string;
}

export interface AdminKycRejectRequest {
  reason: string;
  doc_type?: string;
}

export interface AdminVendorStatusRequest {
  status: VendorStatus;
  reason?: string;
}

export interface AdminActionResponse {
  success: boolean;
  message: string;
}

// ---------------------------------------------------------------------------
// Admin: booking management
// ---------------------------------------------------------------------------

export interface AdminBookingRow extends RideMoney {
  lead_fee?: LeadFeeView;
  id: number;
  balance_due?: number;
  booking_source?: string;
  client_profile_id?: number;
  booking_number: string;
  client_name: string;
  client_phone: string;
  trip_type: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  vendor_id: number;
  vendor_name: string;
  total_fare: number;
  token_amount: number;
  payment_status: string;
  status: string;
  created_at: string;
}

export interface AdminBookingsResponse {
  rows: AdminBookingRow[];
  total: number;
  page: number;
  per_page: number;
  kpis: {
    total: number;
    pending_payment: number;
    proof_submitted: number;
    token_refund_due: number;
    confirmed_today: number;
    completed: number;
    cancelled: number;
    today_bookings: number;
    active_trips: number;
    no_vendor: number;
    month_revenue: number;
  };
}

export interface AdminBookingDetailVendor {
  id: number;
  business_name: string;
  owner_name: string;
  phone: string;
  whatsapp_number: string;
  email: string;
  city: string;
  status: string;
  kyc_status: string;
  rating: number | null;
  total_rides_completed: number;
  wallet_balance: number;
}

export interface AdminBookingLeadRow {
  id: number;
  vendor_name: string;
  vendor_phone: string;
  fee_amount: number;
  lead_fee?: { applies: boolean; amount: number; formula: string; method_label: string; terms_version: number | null; source: string; from_wallet: boolean };
  status: string;
  sent_at: string;
  expires_at: string;
}

export interface AdminBookingVendorPickerRow {
  id: number;
  business_name: string;
  phone: string;
  wallet_balance: number;
}

export interface AdminBookingVendorPickerResponse {
  rows: AdminBookingVendorPickerRow[];
}

export interface AdminBookingDetail extends RideMoney {
  lead_fee?: LeadFeeView;
  id: number;
  booking_number: string;
  /** WP user id of the client account that made the booking; 0 for guest bookings. */
  client_user_id: number;
  client_name: string;
  client_phone: string;
  client_alt_phone: string;
  client_email: string;
  passengers: number;
  luggage_count: number;
  /** Passenger & Safety Information — null when the booking predates this feature or the client left the step blank. */
  passenger_total: number | null;
  passenger_male: number | null;
  passenger_female: number | null;
  passenger_children: number | null;
  passenger_notes: string;
  /** Female-only (female > 0, male = 0) or includes children — see ridego_booking_is_safety_sensitive(). */
  is_safety_sensitive: boolean;
  corporate_company: string;
  corporate_gst: string;
  flight_number: string;
  special_requests: string;
  trip_type: string;
  pickup_city: string;
  pickup_address: string;
  drop_city: string;
  drop_address: string;
  via_cities: string;
  journey_date: string;
  journey_time: string;
  return_date: string | null;
  return_time: string;
  hours_required: number;
  distance_km: number | null;
  duration_minutes: number | null;
  otp_pickup: string;
  vehicle_name: string;
  vendor_id: number;
  vendor_name: string;
  vendor_phone: string;
  vendor: AdminBookingDetailVendor | null;
  base_fare: number;
  toll_charges: number;
  parking_charges: number;
  driver_allowance: number;
  night_surcharge: number;
  gst_amount: number;
  discount_amount: number;
  promo_code: string;
  total_fare: number;
  token_amount: number;
  advance_paid: number;
  balance_due: number;
  refund_amount: number | null;
  refund_reason: string;
  refund_processed_at: string;
  payment_method: string;
  payment_status: string;
  payment_proof_url: string;
  payment_utr: string;
  payment_app: string;
  payment_amount_claimed: number | null;
  payment_time_claimed: string;
  payment_verified_by: string;
  ip_address: string;
  utm_source: string;
  payment_rejection_reason: string;
  status: string;
  cancellation_reason: string;
  notes_admin: string;
  rating_by_client: number | null;
  review_by_client: string;
  leads: AdminBookingLeadRow[];
  created_at: string;
  updated_at: string;
  lock_version: number;
  client_profile_id?: number;
  booking_source?: string;
  created_by_name?: string;
  passenger_details?: { name: string; phone?: string; age?: number | null }[];
  admin_adjustment?: number;
  adjustment_reason?: string;
  reschedule_count?: number;
  rescheduled_from?: string;
  invoice_number?: string;
  vehicle_type_id?: number;
  payments?: import('../lib/api-admin-crm').LedgerRow[];
  notes?: import('../lib/api-admin-crm').BookingNote[];
  editable?: boolean;
  trip_locked?: boolean;
}

export interface AdminBookingCancelResponse {
  success: boolean;
  refund_amount?: number;
  penalty?: number;
  message?: string;
}

// ---------------------------------------------------------------------------
// Admin: cities management
// ---------------------------------------------------------------------------

export interface AdminCityRow {
  id: number;
  name: string;
  slug: string;
  state: string;
  country: string;
  lat: number | null;
  lng: number | null;
  airport_name: string;
  airport_code: string;
  is_popular: boolean;
  is_active: boolean;
  sort_order: number;
  route_count: number;
  zone_count: number;
  is_origin_enabled: boolean;
  is_destination_enabled: boolean;
  image_url: string;
}

export interface AdminCitiesResponse {
  rows: AdminCityRow[];
  total: number;
}

export interface AdminCityInput {
  name: string;
  slug?: string;
  state?: string;
  country?: string;
  lat?: number | string;
  lng?: number | string;
  airport_name?: string;
  airport_code?: string;
  is_popular?: boolean;
  sort_order?: number;
  is_active?: boolean;
  is_origin_enabled?: boolean;
  is_destination_enabled?: boolean;
  image_url?: string;
}

export interface AdminCityCreateResponse {
  success: boolean;
  id: number;
  message: string;
}

export type AdminCreateResponse = AdminCityCreateResponse;

export interface AdminCityToggleResponse {
  success: boolean;
  is_active: boolean;
  message: string;
}

// ---------------------------------------------------------------------------
// Admin: routes + zones
// ---------------------------------------------------------------------------

export interface AdminRouteVehiclePricing {
  id: number;
  vehicle_id: number;
  fixed_price: number | null;
  toll_estimate: number | null;
}

export interface AdminRouteRow {
  id: number;
  from_city_id: number;
  to_city_id: number;
  from_city: string;
  to_city: string;
  distance_km: number;
  duration_mins: number;
  toll_estimate: number | null;
  default_fixed_price: number | null;
  is_popular: boolean;
  is_active: boolean;
  vehicle_pricing: AdminRouteVehiclePricing[];
}

export interface AdminRoutesResponse {
  rows: AdminRouteRow[];
  total: number;
}

export interface AdminRouteInput {
  from_city_id: number;
  to_city_id: number;
  distance_km: number | string;
  duration_mins: number | string;
  toll_estimate?: number | string;
  default_fixed_price?: number | string;
  is_popular?: boolean;
  is_active?: boolean;
}

export interface AdminRouteVehiclePricingInput {
  vehicle_id: number;
  fixed_price?: number | string;
  toll_estimate?: number | string;
}

export interface AdminZoneRow {
  id: number;
  city_id: number;
  city_name: string;
  name: string;
  center_lat: number;
  center_lng: number;
  radius_km: number;
  is_active: boolean;
}

export interface AdminZonesResponse {
  rows: AdminZoneRow[];
  total: number;
}

export interface AdminZoneInput {
  city_id: number;
  name: string;
  center_lat: number | string;
  center_lng: number | string;
  radius_km: number | string;
  is_active?: boolean;
}

// ---------------------------------------------------------------------------
// Admin: vehicle pricing + surge pricing
// ---------------------------------------------------------------------------

export interface AdminPricingVehicleRow {
  id: number;
  name: string;
  slug: string;
  icon_url: string;
  seating_capacity: number;
  luggage_capacity: number;
  ac_available: boolean;
  base_price_per_km: number;
  base_price_outstation: number;
  minimum_km: number;
  night_charge_pct: number;
  driver_allowance_day: number;
  extra_hour_charge: number;
  airport_base_charge: number;
  local_4hr_40km: number;
  local_8hr_80km: number;
  local_extra_km: number;
  local_extra_hr: number;
  lead_fee_mode: string;
  lead_fee_fixed: number;
  lead_fee_pct: number;
  is_active: boolean;
  sort_order: number;
}

export interface AdminPricingVehiclesResponse {
  rows: AdminPricingVehicleRow[];
  total: number;
}

export interface AdminPricingVehicleInput {
  name: string;
  seating_capacity?: number | string;
  luggage_capacity?: number | string;
  ac_available?: boolean;
  base_price_per_km?: number | string;
  base_price_outstation?: number | string;
  minimum_km?: number | string;
  night_charge_pct?: number | string;
  driver_allowance_day?: number | string;
  extra_hour_charge?: number | string;
  airport_base_charge?: number | string;
  local_4hr_40km?: number | string;
  local_8hr_80km?: number | string;
  local_extra_km?: number | string;
  local_extra_hr?: number | string;
  lead_fee_mode?: string;
  lead_fee_fixed?: number | string;
  lead_fee_pct?: number | string;
  is_active?: boolean;
}

export interface AdminPricingVehicleToggleResponse {
  success: boolean;
  is_active: boolean;
  message: string;
}

export interface AdminSurgeRuleRow {
  id: number;
  vehicle_id: number;
  vehicle_name: string;
  city: string;
  zone: string;
  zone_id: number | null;
  zone_name: string;
  from_date: string;
  to_date: string;
  time_from: string;
  time_to: string;
  multiplier: number;
  reason: string;
  is_active: boolean;
}

export interface AdminSurgeResponse {
  rows: AdminSurgeRuleRow[];
  total: number;
}

export interface AdminSurgeInput {
  vehicle_id?: number;
  city?: string;
  zone?: string;
  zone_id?: number;
  from_date: string;
  to_date: string;
  time_from?: string;
  time_to?: string;
  multiplier: number | string;
  reason?: string;
  is_active?: boolean;
}

// ---------------------------------------------------------------------------
// Admin: promo codes
// ---------------------------------------------------------------------------

export interface AdminPromoRow {
  id: number;
  code: string;
  description: string;
  discount_type: 'percentage' | 'fixed';
  discount_value: number;
  min_booking_amount: number;
  max_discount: number;
  usage_limit: number;
  used_count: number;
  start_date: string;
  expiry_date: string;
  trip_type: string[];
  is_active: boolean;
}

export interface AdminPromoResponse {
  rows: AdminPromoRow[];
  total: number;
}

export interface AdminPromoInput {
  code: string;
  description?: string;
  discount_type: 'percentage' | 'fixed';
  discount_value: number | string;
  min_booking_amount?: number | string;
  max_discount?: number | string;
  usage_limit?: number | string;
  start_date?: string;
  expiry_date?: string;
  trip_type?: string[];
  is_active?: boolean;
}

export interface AdminPromoToggleResponse {
  success: boolean;
  is_active: boolean;
  message: string;
}

// ---------------------------------------------------------------------------
// Admin: reports / analytics
// ---------------------------------------------------------------------------

export interface AdminReportSummary {
  from: string;
  to: string;
  total_bookings: number;
  completed: number;
  cancelled: number;
  revenue: number;
  /** Estimated ride value of live/completed bookings (billed by vendors/drivers, not RideGo revenue). */
  ride_value?: number;
  avg_booking: number;
  completion_rate_pct: number;
}

export interface AdminVendorPerformanceBreakdown {
  volume: number;
  completion: number;
  rating: number;
  cancellation: number;
}

export interface AdminVendorPerformanceRow {
  vendor_id: number;
  business_name: string;
  phone: string;
  rating: number;
  leads_total: number;
  completed_trips: number;
  cancelled_trips: number;
  bookings_total: number;
  perf_score: number;
  completion_rate_pct: number;
  cancellation_rate_pct: number;
  breakdown: AdminVendorPerformanceBreakdown;
}

export interface AdminVendorPerformanceResponse {
  from: string;
  to: string;
  vendors: AdminVendorPerformanceRow[];
}

export interface AdminReportsDailyRow {
  date: string;
  bookings: number;
  /** Estimated ride value (billed by vendors/drivers). */
  revenue: number;
  /** Booking amounts collected by RideGo. */
  collected?: number;
  completed: number;
}

export interface AdminReportsDailyResponse {
  rows: AdminReportsDailyRow[];
  total: number;
  page: number;
  per_page: number;
  from: string;
  to: string;
}

export interface AdminReportsTripTypeRow {
  trip_type: string;
  bookings: number;
  revenue: number;
}

export interface AdminReportsTripTypesResponse {
  rows: AdminReportsTripTypeRow[];
  from: string;
  to: string;
}

export interface AdminReportsTopRouteRow {
  pickup_city: string;
  drop_city: string;
  bookings: number;
  revenue: number;
}

export interface AdminReportsTopRoutesResponse {
  rows: AdminReportsTopRouteRow[];
  from: string;
  to: string;
}

// ---------------------------------------------------------------------------
// Admin: financial / wallet
// ---------------------------------------------------------------------------

export interface AdminFinancialPayment {
  booking_number: string | null;
  client_name: string | null;
  pickup_city: string | null;
  drop_city: string | null;
  gateway: string;
  amount: number;
  paid_at: string;
}

export interface AdminWalletReconSummary {
  checked: number;
  discrepancy_count: number;
}

export interface AdminFinancialMonthlyTrend {
  month: string;
  count: number;
  revenue: number;
}

export interface AdminFinancialOverview {
  period: string;
  from: string;
  to: string;
  total_revenue: number;
  avg_booking: number;
  upi_revenue: number;
  cash_revenue: number;
  lead_fees: number;
  vendor_lead_fee?: LeadFeeReport;
  wallet_float: number;
  gst_collected: number;
  recent_payments: AdminFinancialPayment[];
  wallet_reconciliation: AdminWalletReconSummary;
  monthly_trend: AdminFinancialMonthlyTrend[];
}

export interface AdminWalletLedgerRow {
  id: number;
  vendor_id: number;
  business_name: string | null;
  type: string;
  transaction_type: string;
  amount: number;
  balance_before: number | null;
  balance_after: number;
  booking_id: number | null;
  reference_id: number | string | null;
  notes: string;
  created_at: string;
}

export interface AdminWalletLedgerResponse {
  rows: AdminWalletLedgerRow[];
}

export interface AdminWalletReconciliationRow {
  vendor_id: number;
  vendor_name: string;
  stored_balance: number;
  ledger_balance: number;
  discrepancy: number;
  ok: boolean;
  last_ledger_at: string | null;
}

export interface AdminWalletReconciliationResponse {
  rows: AdminWalletReconciliationRow[];
  checked: number;
  discrepancy_count: number;
  total_discrepancy_abs: number;
  previous_run_at: string | null;
}

export interface AdminWalletReconcileResponse {
  success: boolean;
  old_balance: number;
  new_balance: number;
  corrected: number;
}

export interface AdminWalletMutationResponse {
  success: boolean;
  message?: string;
  balance_after?: number;
}

export interface AdminWalletHistoryResponse {
  rows: AdminWalletLedgerRow[];
  page: number;
  limit: number;
}

// ---------------------------------------------------------------------------
// Admin: complaints
// ---------------------------------------------------------------------------

export interface AdminComplaintRow {
  id: number;
  complaint_id: string;
  booking_id: number;
  booking_number: string | null;
  client_name: string | null;
  vendor_name: string | null;
  category: string;
  sub_category: string;
  description: string;
  evidence_urls: string;
  status: string;
  priority: string;
  assigned_to: number | null;
  resolution: string;
  resolved_at: string | null;
  sla_deadline: string | null;
  sla_state: 'breach' | 'warn' | null;
  created_at: string;
  updated_at: string;
}

export interface AdminComplaintsResponse {
  rows: AdminComplaintRow[];
  total: number;
  page: number;
  per_page: number;
  kpis: { open: number; urgent: number; resolved: number };
}

export interface AdminComplaintUpdateResponse {
  success: boolean;
  message: string;
}

export interface AdminComplaintBulkStatusResponse {
  success: boolean;
  updated: number;
  skipped: string[];
}

// ---------------------------------------------------------------------------
// Admin: subscriptions
// ---------------------------------------------------------------------------

export interface AdminSubscriptionPlan {
  id: number;
  name: string;
  price: number;
  billing_cycle: string;
  wallet_credits: number;
  lead_discount: number;
  priority_boost: number;
  max_leads: number;
  features: string;
  is_active: boolean;
  active_subscribers: number;
  mrr: number;
}

export interface AdminSubscriptionsKpis {
  active_subscribers: number;
  mrr: number;
  churn_rate_pct: number;
  churned_30d: number;
}

export interface AdminSubscriptionPlansResponse {
  plans: AdminSubscriptionPlan[];
  kpis: AdminSubscriptionsKpis;
}

export interface AdminSubscriptionPlanInput {
  name: string;
  price: number;
  billing_cycle: string;
  wallet_credits?: number;
  lead_discount?: number;
  priority_boost?: number;
  max_leads?: number;
  features?: string;
  is_active?: boolean;
}

export interface AdminSubscriptionPlanCreateResponse {
  success: boolean;
  id: number;
  message: string;
}

export interface AdminActiveSubscriptionRow {
  vendor_id: number;
  business_name: string;
  subscription_plan_id: number | null;
  subscription_expires: string | null;
  plan_name: string | null;
}

export interface AdminActiveSubscriptionsResponse {
  rows: AdminActiveSubscriptionRow[];
}

export interface AdminSubscriptionCancelResponse {
  success: boolean;
  message: string;
}

// ---------------------------------------------------------------------------
// Admin: audit log
// ---------------------------------------------------------------------------

export interface AdminAuditLogRow {
  id: number;
  admin_id: number;
  user_login: string;
  action: string;
  entity: string;
  entity_id: number | string | null;
  old_value: string;
  new_value: string;
  severity: string;
  ip_address: string;
  created_at: string;
}

export interface AdminAuditLogResponse {
  rows: AdminAuditLogRow[];
  total: number;
  page: number;
  per_page: number;
}

// ---------------------------------------------------------------------------
// Admin: lead monitor
// ---------------------------------------------------------------------------

export interface AdminLeadRow {
  id: number;
  booking_id: number | null;
  booking_number: string | null;
  pickup_city: string | null;
  drop_city: string | null;
  journey_date: string | null;
  trip_type: string | null;
  client_name: string | null;
  business_name: string | null;
  vendor_phone: string | null;
  fee_amount: number;
  lead_fee?: { applies: boolean; amount: number; formula: string; method_label: string; terms_version: number | null; source: string; from_wallet: boolean };
  status: string;
  sent_at: string | null;
  expires_at: string | null;
  expires_seconds_left: number | null;
}

export interface AdminLeadsKpis {
  total_leads: number;
  pending: number;
  accepted: number;
  rejected: number;
  fees_collected: number;
}

export interface AdminLeadsResponse {
  rows: AdminLeadRow[];
  total: number;
  page: number;
  per_page: number;
  kpis: AdminLeadsKpis;
}

// ---------------------------------------------------------------------------
// Admin: dashboard
// ---------------------------------------------------------------------------

export interface AdminDashboardKpis {
  bookings_today: number;
  bookings_today_trend: number | null;
  bookings_month: number;
  bookings_month_trend: number | null;
  revenue_today: number;
  revenue_today_trend: number | null;
  revenue_month: number;
  revenue_month_trend: number | null;
  commission_today: number;
  commission_today_trend: number | null;
  commission_month: number;
  commission_month_trend: number | null;
  lead_fee_month?: LeadFeeReport;
  proof_submitted: number;
  no_vendor_bookings: number;
  no_vendor_stale_minutes: number;
  active_trips: number;
  vendors_pending_kyc: number;
  low_wallet_vendors: number;
  open_complaints: number;
  vendors_active: number;
  total_wallet_float: number;
}

export interface AdminDashboardRevenueDay {
  date: string;
  /** Estimated ride value (billed by vendors/drivers). */
  revenue: number;
  /** Booking amounts collected by RideGo. */
  collected?: number;
  count: number;
}

export interface AdminDashboardTripType {
  trip_type: string;
  count: number;
  revenue: number;
}

export interface AdminDashboardProofPending {
  booking_number: string;
  client_name: string;
  total_fare: number;
  payment_method: string;
  created_at: string;
}

export interface AdminDashboardHealthCheck {
  key: string;
  label: string;
  ok: boolean;
}

export interface AdminDashboardSystemHealth {
  checks: AdminDashboardHealthCheck[];
  plugin_version: string;
  php_version: string;
  wp_version: string;
}

export interface AdminDashboardBookingRow {
  id: number;
  booking_number: string;
  client_name: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  total_fare: number;
  status: string;
  created_at: string;
}

export interface AdminDashboardOverview {
  kpis: AdminDashboardKpis;
  setup_complete: boolean;
  revenue_7d: AdminDashboardRevenueDay[];
  trips_by_type_30d: AdminDashboardTripType[];
  proofs_pending: AdminDashboardProofPending[];
  system_health: AdminDashboardSystemHealth;
  recent_bookings: AdminDashboardBookingRow[];
}

// ---------------------------------------------------------------------------
// Admin: settings
// ---------------------------------------------------------------------------

export type AdminSettingsValueKey =
  | 'platform_name' | 'platform_tagline' | 'admin_email' | 'support_phone' | 'support_whatsapp'
  | 'currency' | 'meta_title' | 'meta_description'
  | 'bank_name' | 'bank_account' | 'bank_ifsc' | 'bank_holder' | 'upi_id' | 'upi_qr_url' | 'gst_percent'
  | 'otp_expiry_minutes' | 'sms_provider' | 'sms_sender_id' | 'twilio_from'
  | 'booking_advance_hours' | 'booking_max_days' | 'payment_deadline_hours' | 'cancellation_free_hours'
  | 'min_wallet_balance' | 'booking_closure_dispute_hours' | 'night_hours_start' | 'night_hours_end'
  | 'complaint_sla_hours_urgent' | 'complaint_sla_hours_high' | 'complaint_sla_hours_normal' | 'complaint_sla_hours_low'
  | 'ridego_audit_log_retention_days'
  | 'invoice_company_name' | 'invoice_company_address' | 'invoice_gstin' | 'invoice_footer_note'
  | 'booking_amount_mode' | 'token_amount' | 'booking_amount_percent' | 'booking_amount_min' | 'booking_amount_max'
  | 'token_label' | 'token_instructions' | 'disclaimer_client' | 'disclaimer_vendor' | 'disclaimer_receipt';

export type AdminSettingsToggleKey =
  | 'require_payment_proof' | 'razorpay_enabled' | 'gst_enabled'
  | 'otp_enabled' | 'email_otp_enabled' | 'otp_trust_device_enabled' | 'whatsapp_enabled'
  | 'auto_assign_vendor' | 'lead_auto_redistribute' | 'require_complete_driver_profile' | 'fraud_detection_enabled'
  | 'delete_data_on_uninstall' | 'ridego_allow_destructive_tools';

export type AdminSettingsSecretKey =
  | 'razorpay_key_id' | 'razorpay_key_secret' | 'razorpay_webhook_secret'
  | 'sms_api_key' | 'twilio_sid' | 'twilio_token' | 'fonnte_token' | 'google_maps_key';

export interface AdminSettingsResponse {
  values: Record<AdminSettingsValueKey, string | number>;
  toggles: Record<AdminSettingsToggleKey, boolean>;
  secrets: Record<AdminSettingsSecretKey, { is_set: boolean }>;
}

export interface AdminSettingsSaveRequest {
  values: Partial<Record<AdminSettingsValueKey, string | number>>;
  toggles: Partial<Record<AdminSettingsToggleKey, boolean>>;
  /** Only include a key here when the operator typed a new value; omit to leave the stored secret untouched. */
  secrets: Partial<Record<AdminSettingsSecretKey, string>>;
}

export interface AdminSettingsSaveResponse {
  success: boolean;
  message: string;
}

// ---------------------------------------------------------------------------
// Admin: tools & database
// ---------------------------------------------------------------------------

export interface AdminToolsTableStatus {
  name: string;
  table: string;
  exists: boolean;
  count: number;
}

export interface AdminToolsPageStatus {
  key: string;
  label: string;
  status: 'live' | 'missing' | string;
  url: string | null;
}

export interface AdminToolsSystemInfo {
  label: string;
  value: string;
}

export interface AdminToolsResponse {
  destructive_allowed: boolean;
  tables: AdminToolsTableStatus[];
  pages: AdminToolsPageStatus[];
  system: AdminToolsSystemInfo[];
}

export interface AdminToolActionResponse {
  success: boolean;
  message: string;
}

// ---------------------------------------------------------------------------
// Admin: notifications broadcast/queue
// ---------------------------------------------------------------------------

export interface AdminNotificationKpis {
  sent: number;
  pending: number;
  retrying: number;
  dead_letter: number;
}

export interface AdminNotificationChannelStat {
  channel: string;
  sent: number;
  pending_retrying: number;
  dead_letter: number;
  total: number;
  success_rate: number;
}

export interface AdminNotificationStatsResponse {
  kpis: AdminNotificationKpis;
  channels: AdminNotificationChannelStat[];
}

export interface AdminNotificationQueueRow {
  id: number;
  event: string;
  status: string;
  recipient: string;
  recipient_id: number;
  channel: string;
  attempts: number;
  error_msg: string | null;
  created_at: string;
}

export interface AdminNotificationQueueResponse {
  rows: AdminNotificationQueueRow[];
  total: number;
  page: number;
  per_page: number;
}

export interface AdminNotificationDeadLetterResponse {
  rows: AdminNotificationQueueRow[];
}

export interface AdminNotificationBroadcastResponse {
  success: boolean;
  message: string;
  queued: number;
}

export interface AdminNotificationActionResponse {
  success: boolean;
  message: string;
}

// ---------------------------------------------------------------------------
// Admin: route-based SEO/marketing pages
// ---------------------------------------------------------------------------

export type RoutePageStatus = 'draft' | 'needs_review' | 'published';

// Per-route hero override values, as stored (blank/null = "use global default").
export interface RoutePageHeroFields {
  hero_mode: '' | 'standard' | 'image';
  hero_heading: string;
  hero_subheading: string;
  hero_bg_color: string;
  hero_image_desktop_url: string;
  hero_image_mobile_url: string;
  hero_height_desktop: string; // '' | 'compact' | 'standard' | 'large' | '<custom px>'
  hero_height_mobile: string;
  hero_overlay_enabled: boolean | null;
  // Separate from every hero_* field above — the dedicated Home Page
  // "Popular Outstation Routes" card thumbnail image, not part of the
  // hero banner. Blank = fall back to the destination/origin city photo.
  card_image_url: string;
}

// The fully-resolved hero config the public page actually renders
// (override -> global default -> hard-coded fallback), heights pre-resolved to px.
export interface RoutePageHeroEffective {
  mode: 'standard' | 'image';
  heading: string;
  subheading: string;
  bg_color: string;
  image_desktop_url: string;
  image_mobile_url: string;
  height_desktop_px: number;
  height_mobile_px: number;
  overlay_enabled: boolean;
}

export interface RoutePage extends RoutePageHeroFields {
  id: number;
  route_id: number;
  slug: string;
  from_city: string;
  to_city: string;
  from_state: string | null;
  to_state: string | null;
  distance_km: number;
  duration_mins: number;
  is_popular: boolean;
  /** Underlying route's own active toggle (Routes tab) — independent of this
   * page's publish status. A published page with route_active=false is
   * hidden from Home Page "Popular Outstation Routes". */
  route_active: boolean;
  seo_title: string;
  meta_description: string;
  status: RoutePageStatus;
  quality_issues: string[];
  has_quality_issues: boolean;
  generated_by: number;
  published_at: string | null;
  created_at: string;
  updated_at: string;
  hero_effective: RoutePageHeroEffective;
}

export interface RoutePagesResponse {
  rows: RoutePage[];
  total: number;
}

export interface EligibleRoute {
  route_id: number;
  from_city: string;
  to_city: string;
  distance_km: number;
  duration_mins: number;
  is_popular: boolean;
  has_page: boolean;
  page_id: number | null;
  page_slug: string | null;
  page_status: string | null;
  vehicle_count: number;
  eligible: boolean;
}

export interface EligibleRoutesResponse {
  rows: EligibleRoute[];
  total: number;
}

export interface RoutePageGenerateResult {
  route_id: number;
  success: boolean;
  id?: number;
  slug?: string;
  status?: RoutePageStatus;
  quality_issues?: string[];
  message?: string;
}

export interface RoutePageGenerateResponse {
  success: boolean;
  created: number;
  total: number;
  results: RoutePageGenerateResult[];
}

export interface RoutePageUpdateInput extends Partial<RoutePageHeroFields> {
  seo_title?: string;
  meta_description?: string;
}

export interface RoutePageUpdateResponse {
  success: boolean;
  message: string;
  quality_issues: string[];
}

export interface RoutePageStatusResponse {
  success: boolean;
  message: string;
}

export interface RoutePageDeleteResponse {
  success: boolean;
  message: string;
}

// ---- Public route page content (ridego_generate_route_page_content()) -----

export interface RoutePageJourney {
  distance_km: number;
  typical_minutes_low: number;
  typical_minutes_high: number;
  note: string;
}

export interface RoutePageService {
  key: string;
  label: string;
  description: string;
}

export interface RoutePagePrice {
  amount: number;
  source: 'fixed' | 'estimated';
}

export interface RoutePageVehicle {
  id: number;
  slug: string;
  name: string;
  seating_capacity: number;
  luggage_capacity: number;
  ac_available: boolean;
  // Same source of truth as the Home Page's vehicle cards (wp_ridego_vehicles.icon_url);
  // '' when the admin hasn't uploaded a photo for this vehicle type yet.
  image_url: string;
  one_way: RoutePagePrice | null;
  round_trip: RoutePagePrice | null;
}

export interface RoutePageVehicleGuidance {
  vehicle: string;
  note: string;
}

export interface RoutePagePoint {
  label: string;
}

export interface RoutePageFaq {
  q: string;
  a: string;
}

export interface RoutePageRelatedRoute {
  from_city: string;
  to_city: string;
  slug: string;
}

// One row of the public /routes/ index listing — GET /ridego/v1/routes.
// Deliberately a small subset of RoutePageContent (no full generated
// content) since the index only ever shows a name, a link, distance and a
// starting fare.
export interface RoutePagesIndexRoute {
  slug: string;
  from_city: string;
  to_city: string;
  distance_km: number;
  starting_fare: number | null;
}

export interface RoutePagesIndexResponse {
  routes: RoutePagesIndexRoute[];
}

export interface RoutePageContent {
  route_id: number;
  from_city: string;
  to_city: string;
  // Real admin-uploaded city photo (Settings → Cities); '' when none exists — never a stock fallback.
  from_city_image_url: string;
  to_city_image_url: string;
  distance_km: number;
  duration_mins: number;
  overview: string;
  journey: RoutePageJourney;
  services: RoutePageService[];
  vehicles: RoutePageVehicle[];
  vehicle_guidance: RoutePageVehicleGuidance[];
  pickup_points: RoutePagePoint[];
  drop_points: RoutePagePoint[];
  why_ridego: string[];
  travel_guide: string;
  faqs: RoutePageFaq[];
  related_routes: RoutePageRelatedRoute[];
  from_origin_routes: RoutePageRelatedRoute[];
  from_destination_routes: RoutePageRelatedRoute[];
  slug: string;
  seo_title: string;
  meta_description: string;
  hero: RoutePageHeroEffective;
  published_at: string | null;
}

export class ApiError extends Error {
  code: string;
  status: number;
  data: WpRestError['data'];
  constructor(err: WpRestError) {
    super(err.message);
    this.code = err.code;
    this.status = err.data?.status ?? 500;
    this.data = err.data;
  }
}
