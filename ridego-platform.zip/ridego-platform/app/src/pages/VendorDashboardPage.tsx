import { useCallback, useEffect, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { acceptLead, rejectLead, getVendorMe, getVendorBookings, ApiError } from '../lib/api';
import {
  confirmLeadDriver,
  declineLead,
  getLeadOptions,
  getMarketplaceLeads,
  markLeadViewed,
  showLeadInterest,
  type InterestStatus,
  type MarketplaceLead,
  type SelectionOptions,
} from '../lib/api-vendor-marketplace';
import type { VendorBooking, VendorMe } from '../types/api';
import { Skeleton } from '../components/ui/Skeleton';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { EmptyState } from '../components/ui/EmptyState';
import { Button } from '../components/ui/Button';
import { BottomSheet } from '../components/ui/BottomSheet';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { CountdownBadge } from '../components/CountdownBadge';
import { FormField, INPUT_CLASS, OptionRow, ToneBadge, useRequestGuard, useSheet, type Tone } from './vendor-mkt/vendor-mkt-shared';
import { brand } from '../lib/brand';

const STAT_SKELETONS = ['wallet', 'rating', 'accepted'];
const LEAD_SKELETONS = ['lead-a', 'lead-b'];

const INTEREST_LABEL: Record<InterestStatus, string> = {
  pending: 'Pending',
  viewed: 'Viewed',
  interested: 'Interested',
  driver_confirmed: 'Confirmed',
  declined: 'Declined',
  expired: 'Expired',
  not_selected: 'Not selected',
  cancelled: 'Booking cancelled',
};

const INTEREST_TONE: Record<InterestStatus, Tone> = {
  pending: 'neutral',
  viewed: 'neutral',
  interested: 'brand',
  driver_confirmed: 'success',
  declined: 'neutral',
  expired: 'neutral',
  not_selected: 'neutral',
  cancelled: 'neutral',
};

// TRACE: any money display on this page → formats a rupee amount with Indian grouping → string.
//        Preconditions: n is a number. Postconditions: whole rupees. Edge cases: none beyond NaN rendering "₹NaN" (inputs
//        come from the API as numbers).
function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

// TRACE: any thrown value in this page → chooses the text to show → string. Preconditions: none.
//        Postconditions: ApiError.message preserved verbatim. Edge cases: non-ApiError → fallback text.
function errorText(err: unknown, fallback: string): string {
  return err instanceof ApiError ? err.message : fallback;
}

// TRACE: route /app/vendor/dashboard → non-vendors see the registration prompt, vendors see the dashboard content.
//        Preconditions: AuthProvider mounted. Postconditions: exactly one of the two views renders.
//        Edge cases: logged-out visitor (login prompt copy), logged-in non-vendor (register prompt).
export function VendorDashboardPage() {
  const { isVendor, user } = useAuth();

  if (!isVendor) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <div className="rounded-2xl border border-ink-100 bg-ink-50/60 p-10">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-brand-100 text-brand-700">
            <svg className="h-7 w-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" d="M8 17l4-11 4 11M9.5 13h5M3 21h18" />
            </svg>
          </div>
          <h1 className="mt-5 text-2xl font-bold text-ink-900">Become a {brand().name} vendor</h1>
          <p className="mt-2 text-ink-500">
            {user
              ? "You're logged in, but this account isn't registered as a driver-partner yet. Register your vendor profile to start receiving ride leads."
              : 'Log in and register as a driver-partner to access your vendor dashboard.'}
          </p>
          <div className="mt-6 flex justify-center gap-3">
            <Link to="/register">
              <Button>Register as a vendor</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return <VendorDashboardContent />;
}

// TRACE: vendor dashboard → loads vendor summary + open leads, polls both every 20s, renders wallet/rating tiles and the
//        lead list with the compare-mode flow (interested → confirm driver & vehicle) or the instant accept flow →
//        every lead action re-fetches server state. Preconditions: vendor session. Postconditions: stale responses are
//        dropped, the poll timer is cleared on unmount, only one lead action runs at a time. Edge cases: load failure
//        (retry), no leads (empty state), action failure (banner + toast with the server message, lead stays),
//        viewed-tracking failure (silent, retried on the next poll), leads gone after refetch (removed).
function VendorDashboardContent() {
  const toast = useToast();
  const guard = useRequestGuard();
  const refreshGuard = useRequestGuard();
  const loadingRef = useRef(true);
  const [vendor, setVendor] = useState<VendorMe | null>(null);
  const [leads, setLeads] = useState<MarketplaceLead[] | null>(null);
  const [activeTrips, setActiveTrips] = useState<VendorBooking[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<{ id: number; action: 'interest' | 'accept' } | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [declineTarget, setDeclineTarget] = useState<MarketplaceLead | null>(null);
  const [declineReason, setDeclineReason] = useState('');
  const [declining, setDeclining] = useState(false);
  const decliningRef = useRef(false);
  const [declineError, setDeclineError] = useState<string | null>(null);
  const confirmSheet = useSheet<MarketplaceLead>();
  const viewedIds = useRef<Set<number>>(new Set());

  // TRACE: mount / retry → fetches vendor summary and leads together → stores them, spinner while loading.
  //        Preconditions: none. Postconditions: only the newest request writes state. Edge cases: failure (error text +
  //        retry), unmounted/stale (ignored).
  const load = useCallback(async () => {
    const id = guard.begin();
    loadingRef.current = true;
    setLoading(true);
    setError(null);
    try {
      const [v, l, t] = await Promise.all([
        getVendorMe(),
        getMarketplaceLeads(),
        getVendorBookings({ status: 'vendor_assigned|driver_en_route|trip_started' }),
      ]);
      if (!guard.isCurrent(id)) return;
      setVendor(v);
      setLeads(l);
      setActiveTrips(t.rows);
    } catch (err) {
      if (guard.isCurrent(id)) setError(errorText(err, 'Could not load your dashboard. Please try again.'));
    } finally {
      if (guard.isCurrent(id)) {
        loadingRef.current = false;
        setLoading(false);
      }
    }
  }, [guard]);

  // TRACE: after any lead action and on every poll → refetches leads (and the vendor summary) without the spinner →
  //        replaces state. Preconditions: none. Postconditions: newest request wins. Edge cases: failure (ignored on a
  //        background poll; the next poll recovers), initial load still running (skipped), unmounted (ignored).
  const refresh = useCallback(async () => {
    if (loadingRef.current) return;
    const id = refreshGuard.begin();
    try {
      const [v, l, t] = await Promise.all([
        getVendorMe(),
        getMarketplaceLeads(),
        getVendorBookings({ status: 'vendor_assigned|driver_en_route|trip_started' }),
      ]);
      if (!refreshGuard.isCurrent(id)) return;
      setVendor(v);
      setLeads(l);
      setActiveTrips(t.rows);
    } catch {
      // A failed background refresh keeps the last good data on screen; the next poll retries.
    }
  }, [refreshGuard]);

  // TRACE: mount → runs the first load → void.
  useEffect(() => {
    void load();
  }, [load]);

  // TRACE: mount → starts a 20s poll of leads and wallet (a wallet change from another tab/admin top-up must show up)
  //        → interval cleared on unmount. Edge cases: unmount mid-request (ignored by the guard).
  useEffect(() => {
    const id = window.setInterval(() => {
      void refresh();
    }, 20000);
    return () => window.clearInterval(id);
  }, [refresh]);

  // TRACE: retry button → reloads with the spinner → void.
  const retry = useCallback(() => {
    void load();
  }, [load]);

  // TRACE: a lead card becomes visible while Pending → POST viewed once per lead id → marks it Viewed locally.
  //        Preconditions: lead id not yet reported. Postconditions: at most one request per lead per page visit.
  //        Edge cases: request failure (id released so the next visibility/poll retries; no user-facing error because
  //        this is bookkeeping), lead removed meanwhile (update is a no-op).
  const reportViewed = useCallback(async (leadId: number) => {
    if (viewedIds.current.has(leadId)) return;
    viewedIds.current.add(leadId);
    try {
      await markLeadViewed(leadId);
      setLeads((prev) => (prev ? prev.map((l) => (l.id === leadId && l.interest_status === 'pending' ? { ...l, interest_status: 'viewed' } : l)) : prev));
    } catch {
      viewedIds.current.delete(leadId);
    }
  }, []);

  // TRACE: "I'm interested" / "Accept lead" click → compare: POST interest (opens the confirm sheet when a driver and
  //        vehicle still must be chosen); instant: legacy accept → toast, refetch. Preconditions: no other action in
  //        flight. Postconditions: button shows a spinner until the request ends. Edge cases: expired/closed lead or
  //        taken booking (server message in banner + toast), needs_driver false (auto-confirmed individual vendor).
  const handleInterest = useCallback(
    async (lead: MarketplaceLead) => {
      if (busy) return;
      const action = lead.lead_mode === 'instant' ? 'accept' : 'interest';
      setBusy({ id: lead.id, action });
      setActionError(null);
      try {
        if (action === 'accept') {
          const res = await acceptLead(lead.id);
          toast.show(res.message || 'Lead accepted.', 'success');
        } else {
          const res = await showLeadInterest(lead.id);
          toast.show(res.message, 'success');
          if (res.needs_driver) confirmSheet.show(lead);
        }
        await refresh();
      } catch (err) {
        const msg = errorText(err, action === 'accept' ? 'Could not accept this lead.' : 'Could not record your interest.');
        setActionError(msg);
        toast.show(msg, 'error');
      } finally {
        setBusy(null);
      }
    },
    [busy, toast, refresh, confirmSheet]
  );

  // TRACE: "Decline" click → stores the lead and clears the reason/error → opens the decline dialog → void.
  const askDecline = useCallback((lead: MarketplaceLead) => {
    setDeclineReason('');
    setDeclineError(null);
    setDeclineTarget(lead);
  }, []);

  // TRACE: decline dialog Cancel/Escape → closes it unless a request is running → void.
  const cancelDecline = useCallback(() => {
    if (!decliningRef.current) setDeclineTarget(null);
  }, []);

  // TRACE: reason input change → stores text → void.
  const changeReason = (e: ChangeEvent<HTMLInputElement>) => setDeclineReason(e.target.value);

  // TRACE: decline dialog Confirm → compare: POST decline with the optional reason; instant: legacy reject → toast,
  //        refetch, close. Preconditions: declineTarget set, not already declining. Postconditions: button disabled
  //        while pending. Edge cases: server refusal (inline error, dialog stays, reason kept), lead already closed.
  const confirmDecline = useCallback(async () => {
    if (!declineTarget || decliningRef.current) return;
    decliningRef.current = true;
    setDeclining(true);
    setDeclineError(null);
    try {
      const reason = declineReason.trim();
      const res = declineTarget.lead_mode === 'instant' ? await rejectLead(declineTarget.id, reason) : await declineLead(declineTarget.id, reason);
      toast.show(res.message || 'Lead declined.', 'success');
      setDeclineTarget(null);
      setDeclineReason('');
      await refresh();
    } catch (err) {
      setDeclineError(errorText(err, 'Could not decline this lead.'));
    } finally {
      decliningRef.current = false;
      setDeclining(false);
    }
  }, [declineTarget, declineReason, toast, refresh]);

  // TRACE: confirm sheet success → closes the sheet and refetches leads → void. Edge cases: none.
  const confirmed = useCallback(() => {
    confirmSheet.hide();
    void refresh();
  }, [confirmSheet, refresh]);

  return (
    <div className="min-h-full bg-ink-50">
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Vendor dashboard</h1>
          <p className="text-sm text-ink-500">Track your wallet, rating and incoming ride leads.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link to="/vendor/trips">
            <Button variant="secondary" size="sm">
              View trip history
            </Button>
          </Link>
          <Link to="/vendor/fleet">
            <Button variant="secondary" size="sm">
              My fleet
            </Button>
          </Link>
          <Link to="/vendor/settlements">
            <Button variant="secondary" size="sm">
              Settlements
            </Button>
          </Link>
          <Link to="/vendor/commercial-terms">
            <Button variant="secondary" size="sm">
              Commercial terms
            </Button>
          </Link>
          <Link to="/vendor/performance">
            <Button variant="secondary" size="sm">
              Performance
            </Button>
          </Link>
          <Link to="/vendor/kyc">
            <Button variant="secondary" size="sm">
              Manage KYC documents
            </Button>
          </Link>
        </div>
      </div>

      {loading && (
        <div className="mt-6 space-y-6" aria-busy="true" aria-label="Loading dashboard">
          <div className="grid gap-4 sm:grid-cols-3">
            {STAT_SKELETONS.map((k) => (
              <div key={k} className="rounded-lg bg-white p-5 shadow-xs ring-1 ring-inset ring-ink-100">
                <Skeleton className="h-3 w-20" />
                <Skeleton className="mt-3 h-7 w-28" />
              </div>
            ))}
          </div>
          <Skeleton className="h-4 w-32" />
          {LEAD_SKELETONS.map((k) => (
            <Skeleton key={k} className="h-24 w-full rounded-xl" />
          ))}
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={retry} />
        </div>
      )}

      {!loading && !error && vendor && (
        <>
          {vendor.low_wallet && (
            <div
              role="alert"
              className="mt-6 flex items-center gap-2 rounded-lg border border-warning-500/30 bg-warning-50 px-4 py-3 text-sm text-warning-600"
            >
              <svg className="h-5 w-5 shrink-0" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path
                  fillRule="evenodd"
                  d="M8.257 3.099c.765-1.36 2.72-1.36 3.486 0l6.28 11.18c.75 1.334-.213 2.98-1.743 2.98H3.72c-1.53 0-2.493-1.646-1.743-2.98l6.28-11.18zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-7a1 1 0 00-1 1v3a1 1 0 002 0V7a1 1 0 00-1-1z"
                  clipRule="evenodd"
                />
              </svg>
              Your wallet balance is low. Top up soon to keep receiving leads.
            </div>
          )}

          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            <div className="rounded-lg bg-white p-5 shadow-xs ring-1 ring-inset ring-ink-100">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-500">Wallet balance</p>
              <p className={`mt-2 text-2xl font-bold ${vendor.low_wallet ? 'text-warning-600' : 'text-ink-900'}`}>
                {currency(vendor.wallet_balance)}
              </p>
            </div>
            <div className="rounded-lg bg-white p-5 shadow-xs ring-1 ring-inset ring-ink-100">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-500">Rating</p>
              <p className="mt-2 flex items-center gap-1 text-2xl font-bold text-ink-900">
                {vendor.rating.toFixed(1)}
                <svg className="h-5 w-5 text-warning-500" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.957a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.367 2.447a1 1 0 00-.364 1.118l1.287 3.957c.3.922-.755 1.688-1.538 1.118l-3.367-2.447a1 1 0 00-1.176 0l-3.367 2.447c-.783.57-1.838-.196-1.538-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.063 9.384c-.783-.57-.38-1.81.588-1.81h4.163a1 1 0 00.95-.69l1.286-3.957z" />
                </svg>
              </p>
              <p className="text-xs text-ink-500">{vendor.total_ratings} ratings</p>
            </div>
            <div className="rounded-lg bg-white p-5 shadow-xs ring-1 ring-inset ring-ink-100">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-500">Leads accepted</p>
              <p className="mt-2 text-2xl font-bold text-ink-900">{vendor.total_leads_accepted}</p>
            </div>
          </div>

          <div className="mt-10">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-ink-900">Active trips</h2>
              <Link to="/vendor/trips" className="text-sm font-medium text-brand-700 hover:text-brand-800">
                View all trips
              </Link>
            </div>
            {activeTrips && activeTrips.length === 0 && (
              <div className="mt-3">
                <EmptyState title="No active trips" description="Trips you're currently assigned to, on the way to pickup, or in progress will appear here." />
              </div>
            )}
            {activeTrips && activeTrips.length > 0 && (
              <ul className="mt-3 space-y-2">
                {activeTrips.map((t) => (
                  <li key={t.id}>
                    <Link
                      to="/vendor/trips"
                      className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-white p-4 shadow-xs ring-1 ring-inset ring-ink-100 hover:ring-brand-200"
                    >
                      <div>
                        <p className="font-semibold text-ink-900">{t.booking_number}</p>
                        <p className="text-sm text-ink-600">
                          {t.pickup_city} → {t.drop_city} · {t.journey_date} {t.journey_time}
                        </p>
                      </div>
                      <span className="rounded-full bg-brand-50 px-2.5 py-1 text-xs font-semibold text-brand-700">{t.status_label}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="mt-10">
            <h2 className="text-lg font-semibold text-ink-900">Live leads</h2>

            {actionError && (
              <div className="mt-3">
                <ErrorBanner message={actionError} />
              </div>
            )}

            <div className="mt-4">
              {leads && leads.length === 0 && (
                <EmptyState
                  title="No leads right now"
                  description="New ride leads matching your vehicle and coverage area will appear here as they come in."
                />
              )}

              {leads && leads.length > 0 && (
                <ul className="space-y-3">
                  {leads.map((lead) => (
                    <LeadCard
                      key={lead.id}
                      lead={lead}
                      busyAction={busy && busy.id === lead.id ? busy.action : null}
                      anyBusy={busy !== null}
                      onInterest={handleInterest}
                      onDecline={askDecline}
                      onConfirm={confirmSheet.show}
                      onSeen={reportViewed}
                    />
                  ))}
                </ul>
              )}
            </div>
          </div>
        </>
      )}

      <BottomSheet
        open={confirmSheet.open}
        title={confirmSheet.target ? `Confirm driver & vehicle: #${confirmSheet.target.booking_number}` : 'Confirm driver & vehicle'}
        onClose={confirmSheet.hide}
      >
        {confirmSheet.target && (
          <ConfirmDriverForm key={confirmSheet.nonce} lead={confirmSheet.target} onDone={confirmed} onCancel={confirmSheet.hide} onSeen={reportViewed} />
        )}
      </BottomSheet>

      <ConfirmDialog
        open={declineTarget !== null}
        title={declineTarget ? `Decline lead #${declineTarget.booking_number}?` : 'Decline lead?'}
        description="You will not be considered for this trip. You can add a reason if you like."
        confirmLabel="Decline lead"
        confirmVariant="danger"
        loading={declining}
        onConfirm={confirmDecline}
        onCancel={cancelDecline}
      >
        <div className="mt-3">
          <FormField label="Reason (optional)" htmlFor="decline-reason">
            <input id="decline-reason" type="text" maxLength={200} value={declineReason} onChange={changeReason} disabled={declining} className={INPUT_CLASS} />
          </FormField>
          {declineError && (
            <p role="alert" className="mt-2 text-sm font-medium text-danger-600">
              {declineError}
            </p>
          )}
        </div>
      </ConfirmDialog>
    </div>
    </div>
  );
}

// TRACE: dashboard lead list → renders one lead card with route, time, fare, fee, countdown, state badge and the actions
//        that fit its state (compare: Pending/Viewed → I'm interested + Decline; Interested → Confirm driver & vehicle
//        + Decline; Confirmed → Change driver & vehicle + Decline; instant: Accept lead + Decline) → callbacks.
//        Preconditions: lead row. Postconditions: reports itself as seen once when scrolled into view while Pending;
//        buttons disabled while any lead action runs, spinner on the one that is running. Edge cases: no
//        IntersectionObserver (reports immediately), confirmed lead shows the chosen driver/vehicle, customer contact is
//        never shown (the API does not return it here).
function LeadCard({
  lead,
  busyAction,
  anyBusy,
  onInterest,
  onDecline,
  onConfirm,
  onSeen,
}: {
  lead: MarketplaceLead;
  busyAction: 'interest' | 'accept' | null;
  anyBusy: boolean;
  onInterest: (l: MarketplaceLead) => void;
  onDecline: (l: MarketplaceLead) => void;
  onConfirm: (l: MarketplaceLead) => void;
  onSeen: (id: number) => void;
}) {
  const ref = useRef<HTMLLIElement>(null);
  const instant = lead.lead_mode === 'instant';
  const pendingState = lead.interest_status === 'pending';

  // TRACE: card mounted while Pending → waits until the card is on screen, then reports it seen once → observer
  //        disconnected on cleanup. Edge cases: no IntersectionObserver (reports at once), status no longer Pending (skip).
  useEffect(() => {
    if (instant || !pendingState) return undefined;
    const node = ref.current;
    if (!node || typeof IntersectionObserver === 'undefined') {
      onSeen(lead.id);
      return undefined;
    }
    const observer = new IntersectionObserver((entries) => {
      if (entries.some((e) => e.isIntersecting)) {
        onSeen(lead.id);
        observer.disconnect();
      }
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, [instant, pendingState, lead.id, onSeen]);

  // TRACE: primary button → asks the dashboard to record interest (or accept) for this lead → void.
  const interest = () => onInterest(lead);
  // TRACE: Decline button → asks the dashboard to open the decline dialog → void.
  const decline = () => onDecline(lead);
  // TRACE: Confirm/Change button → opens the confirm driver & vehicle sheet for this lead → void.
  const confirm = () => onConfirm(lead);

  const state = lead.interest_status;
  const showInterest = instant || state === 'pending' || state === 'viewed';
  const showConfirm = !instant && (state === 'interested' || state === 'driver_confirmed');

  return (
    <li ref={ref} className="rounded-lg bg-white p-4 shadow-xs ring-1 ring-inset ring-ink-100">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <p className="font-semibold text-ink-900">
              {lead.pickup_city} → {lead.drop_city}
            </p>
            <CountdownBadge expiresAt={lead.expires_at} />
            {!instant && <ToneBadge tone={INTEREST_TONE[state]}>{INTEREST_LABEL[state]}</ToneBadge>}
          </div>
          <p className="mt-1 text-sm text-ink-600">
            {lead.journey_date} at {lead.journey_time} &middot; #{lead.booking_number}
          </p>
          <p className="mt-1 text-sm text-ink-600">
            Fare <span className="font-semibold">{currency(lead.total_fare)}</span> &middot; Lead fee{' '}
            <span className="font-semibold">{currency(lead.fee_amount)}</span>
          </p>
          {lead.lead_fee_formula && <p className="mt-0.5 text-xs text-ink-500">{lead.lead_fee_formula}</p>}
          {!instant && state === 'interested' && (
            <p className="mt-1 text-sm text-warning-600">Confirm the driver and vehicle so your offer can be considered.</p>
          )}
          {!instant && state === 'driver_confirmed' && (
            <p className="mt-1 text-sm text-ink-600">
              {[lead.driver_name && `Driver ${lead.driver_name}`, lead.vehicle_registration && `Vehicle ${lead.vehicle_registration}`].filter(Boolean).join(' · ')}
              {' '}&middot; Waiting for the selection.
            </p>
          )}
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={decline} disabled={anyBusy} aria-label={`Decline lead ${lead.booking_number}`}>
            Decline
          </Button>
          {showInterest && (
            <Button onClick={interest} loading={busyAction !== null} disabled={anyBusy}>
              {instant ? 'Accept lead' : "I'm interested"}
            </Button>
          )}
          {showConfirm && (
            <Button variant={state === 'driver_confirmed' ? 'secondary' : 'primary'} onClick={confirm} disabled={anyBusy}>
              {state === 'driver_confirmed' ? 'Change driver & vehicle' : 'Confirm driver & vehicle'}
            </Button>
          )}
        </div>
      </div>
    </li>
  );
}

// TRACE: confirm sheet → loads the lead's driver/vehicle options (availability + reasons + type mismatch), lets the vendor
//        pick one of each, POSTs confirm → onDone(). Preconditions: lead is Interested/Confirmed. Postconditions: options
//        load once per open (stale ignored); unavailable entries are disabled with the reason visible; submit disabled
//        until both are chosen and while pending; the choice is kept if the server refuses. Edge cases: options load
//        failure (retry), no vehicles/drivers (empty state with link to My fleet), vehicle without a registration
//        (disabled, prompts to add it), a single available choice (preselected), server refusal (inline + toast).
function ConfirmDriverForm({ lead, onDone, onCancel, onSeen }: { lead: MarketplaceLead; onDone: () => void; onCancel: () => void; onSeen: (id: number) => void }) {
  const toast = useToast();
  const guard = useRequestGuard();
  const [options, setOptions] = useState<SelectionOptions | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [driverId, setDriverId] = useState(0);
  const [vehicleId, setVehicleId] = useState(0);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // TRACE: mount / retry → GET options for this lead → stores them and preselects a lone available choice.
  //        Preconditions: none. Postconditions: newest response wins. Edge cases: failure (error + retry), stale (ignored).
  const load = useCallback(async () => {
    const id = guard.begin();
    setLoading(true);
    setLoadError(null);
    try {
      const res = await getLeadOptions(lead.id);
      if (!guard.isCurrent(id)) return;
      setOptions(res);
      const okDrivers = res.drivers.filter((d) => d.available);
      const okVehicles = res.vehicles.filter((v) => v.available && v.registration_number !== '');
      setDriverId(okDrivers.length === 1 ? okDrivers[0].id : 0);
      setVehicleId(okVehicles.length === 1 ? okVehicles[0].id : 0);
    } catch (err) {
      if (guard.isCurrent(id)) setLoadError(errorText(err, 'Could not load your drivers and vehicles.'));
    } finally {
      if (guard.isCurrent(id)) setLoading(false);
    }
  }, [guard, lead.id]);

  // TRACE: mount → loads options and reports the lead as seen → void.
  useEffect(() => {
    void load();
    onSeen(lead.id);
  }, [load, onSeen, lead.id]);

  // TRACE: retry button → reloads options → void.
  const retry = () => {
    void load();
  };
  // TRACE: driver radio change → stores the id → void.
  const pickDriver = (id: number) => setDriverId(id);
  // TRACE: vehicle radio change → stores the id → void.
  const pickVehicle = (id: number) => setVehicleId(id);

  // TRACE: form submit → requires a driver and a vehicle → POST confirm → toast + onDone. Preconditions: not saving.
  //        Postconditions: selection kept on failure. Edge cases: nothing chosen (inline message), server refusal
  //        (unavailable entity, closed lead) shown inline and as a toast.
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    if (!driverId || !vehicleId) {
      setFormError('Choose both a driver and a vehicle.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      const res = await confirmLeadDriver(lead.id, { driver_id: driverId, vehicle_id: vehicleId });
      toast.show(res.message, 'success');
      onDone();
    } catch (err) {
      const msg = errorText(err, 'Could not confirm the driver and vehicle.');
      setFormError(msg);
      toast.show(msg, 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-3" aria-busy="true" aria-label="Loading drivers and vehicles">
        <Skeleton className="h-16 w-full rounded-xl" />
        <Skeleton className="h-16 w-full rounded-xl" />
        <Skeleton className="h-16 w-full rounded-xl" />
      </div>
    );
  }
  if (loadError) return <ErrorBanner message={loadError} onRetry={retry} />;
  if (!options || (options.drivers.length === 0 && options.vehicles.length === 0)) {
    return (
      <EmptyState
        title="No active drivers or vehicles"
        description="Add or reactivate a driver and a vehicle in My fleet, then come back to confirm."
        action={
          <Link to="/vendor/fleet">
            <Button variant="secondary">Open My fleet</Button>
          </Link>
        }
      />
    );
  }

  return (
    <form onSubmit={submit} className="space-y-5" noValidate>
      <p className="text-sm text-ink-600">
        Trip on {options.window.date} at {options.window.time.slice(0, 5)}. Choose who will drive and which vehicle you will send.
      </p>

      <fieldset disabled={saving} className="min-w-0">
        <legend className="text-sm font-semibold text-ink-900">Driver</legend>
        {options.drivers.length === 0 ? (
          <p className="mt-2 text-sm text-ink-600">You have no active drivers. Add one in My fleet.</p>
        ) : (
          <ul className="mt-2 space-y-2">
            {options.drivers.map((d) => (
              <OptionRow
                key={d.id}
                group="lead-driver"
                id={d.id}
                title={d.name}
                detail={[d.mobile, d.rating > 0 ? `Rating ${d.rating.toFixed(1)}` : ''].filter(Boolean).join(' · ')}
                preferred={d.preferred}
                available={d.available}
                reason={d.reason}
                selected={driverId === d.id}
                onPick={pickDriver}
              />
            ))}
          </ul>
        )}
      </fieldset>

      <fieldset disabled={saving} className="min-w-0">
        <legend className="text-sm font-semibold text-ink-900">Vehicle</legend>
        {options.vehicles.length === 0 ? (
          <p className="mt-2 text-sm text-ink-600">You have no active vehicles. Add one in My fleet.</p>
        ) : (
          <ul className="mt-2 space-y-2">
            {options.vehicles.map((v) => (
              <OptionRow
                key={v.id}
                group="lead-vehicle"
                id={v.id}
                title={v.registration_number || 'Registration number missing'}
                detail={[v.make_model, `${v.seating_capacity} seats`].filter(Boolean).join(' · ')}
                preferred={v.preferred}
                available={v.available && v.registration_number !== ''}
                reason={v.registration_number === '' ? 'Add the registration number in My fleet first.' : v.reason}
                mismatch={v.type_mismatch}
                selected={vehicleId === v.id}
                onPick={pickVehicle}
              />
            ))}
          </ul>
        )}
      </fieldset>

      {formError && (
        <p role="alert" className="text-sm font-medium text-danger-600">
          {formError}
        </p>
      )}
      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Button type="button" variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" loading={saving} disabled={!driverId || !vehicleId}>
          Confirm driver & vehicle
        </Button>
      </div>
    </form>
  );
}
