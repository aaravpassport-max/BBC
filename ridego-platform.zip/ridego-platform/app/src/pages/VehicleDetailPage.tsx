import { useCallback, useEffect, useState, type ReactElement } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { ApiError, getHome, getReviews, getVehicles } from '../lib/api';
import type { AppReview, HomeResponse, Vehicle } from '../types/api';
import { Button } from '../components/ui/Button';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { EmptyState } from '../components/ui/EmptyState';
import { Skeleton, SkeletonCard } from '../components/ui/Skeleton';
import { FareSearchWidget } from '../components/home/FareSearchWidget';
import { brand, heightStyle, fitClass } from '../lib/brand';

interface SearchPrefillState {
  tripType: string;
  pickup: string;
  drop: string;
  date: string;
}

// Platform-wide claims already made honest elsewhere in the app (HomePage's
// VALUE_PROPS / INCLUDED_FEATURES) — repeated here rather than re-invented,
// since they describe RideGo itself, not this specific vehicle.
const INCLUDED_FEATURES = [
  { title: 'Verified driver-partner', description: `Every driver-partner on ${brand().name} is vetted before they can accept trips on the platform.`, color: 'bg-brand-50 text-brand-700' },
  { title: 'Upfront pricing', description: 'The fare you see is the fare you pay — no last-minute surprises or hidden charges.', color: 'bg-warning-50 text-warning-600' },
  { title: 'GPS-tracked trip', description: 'Your journey is tracked end to end, so you and anyone you share it with always know where you are.', color: 'bg-brand-50 text-brand-700' },
  { title: '24/7 support', description: 'Call or WhatsApp our team any time before, during or after your trip.', color: 'bg-success-50 text-success-600' },
];

const WHY_RIDEGO = [
  { title: 'Trusted & verified', description: 'Only verified vehicles and drivers.', icon: 'shield' as const },
  { title: 'Best prices', description: 'Competitive and transparent pricing.', icon: 'rupee' as const },
  { title: 'Wide coverage', description: 'Available in multiple cities across India.', icon: 'star' as const },
  { title: 'Safe & reliable', description: 'Your safety is our top priority.', icon: 'heart' as const },
];

// Real business rules already enforced elsewhere in the codebase
// (includes/booking.php's cancellation flow) — restated here in plain
// language rather than inventing a generic "24 hour" policy that isn't
// actually how this platform's cancellation/refund logic works.
// Grouped under small category labels for scannability — same six real
// questions/answers as before, just organized; no new questions invented.
function faqFor(vehicleName: string): { group: string; q: string; a: string }[] {
  return [
    { group: 'Booking', q: 'Is a driver included in the fare?', a: `Yes. Every ${vehicleName} booking on ${brand().name} comes with a verified driver-partner — this is a driver-included ride, not a self-drive rental.` },
    { group: 'Booking', q: 'What documents are required for booking?', a: 'Just a valid pickup address and contact details — the driver-partner handles the trip itself, so no driving license or ID is needed from you.' },
    { group: 'Pricing', q: 'Are fuel charges included?', a: `${brand().name} collects a booking amount online; your driver-partner collects the balance directly at the end of the trip, and any extra-km or fuel terms for your specific route are shown in the fare breakdown before you confirm.` },
    { group: 'Pricing', q: 'What is the cancellation policy?', a: 'You can cancel free of charge any time before a driver-partner has been assigned to your trip. Once a driver-partner is arranged, a portion of the booking amount may be retained to cover their commitment.' },
    { group: 'Trips', q: 'Can I take the vehicle for outstation trips?', a: 'Yes, outstation, local and hourly-rental trips are all supported for this vehicle type where pricing is configured — see "Pricing & options" above.' },
    { group: 'Trips', q: 'How do I modify or cancel my booking?', a: 'Open the booking from "My Trips" — modification and cancellation options are shown there for as long as they remain available for that trip.' },
  ];
}

function StarRow({ rating, size = 'h-4 w-4' }: { rating: number; size?: string }) {
  return (
    <div className="flex gap-0.5 text-warning-500" aria-label={`${rating} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <svg key={i} viewBox="0 0 20 20" fill={i < Math.round(rating) ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.2" className={size} aria-hidden="true">
          <path d="M10 1.6l2.6 5.3 5.8.8-4.2 4.1 1 5.8L10 14.8l-5.2 2.8 1-5.8-4.2-4.1 5.8-.8L10 1.6z" strokeLinejoin="round" />
        </svg>
      ))}
    </div>
  );
}

function CarIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M5 11l1.5-4.5A2 2 0 0 1 8.4 5h7.2a2 2 0 0 1 1.9 1.5L19 11m-14 0h14m-14 0a1.5 1.5 0 0 0-1.5 1.5V16a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-1h11v1a1 1 0 0 0 1 1h1a1 1 0 0 0 1-1v-3.5A1.5 1.5 0 0 0 19 11" />
      <circle cx="7.5" cy="14.5" r="0.75" fill="currentColor" stroke="none" />
      <circle cx="16.5" cy="14.5" r="0.75" fill="currentColor" stroke="none" />
    </svg>
  );
}

function DriverIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
      <circle cx="12" cy="7.5" r="3" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M5 20a7 7 0 0 1 14 0" />
      <path strokeLinecap="round" strokeLinejoin="round" d="m9.5 15.5 2 2 3.5-4" />
    </svg>
  );
}
function SeatIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 4v9a3 3 0 003 3h6M6 4H4M6 4h2M9 16v4M15 16v4M4 20h16" />
    </svg>
  );
}
function LuggageIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <rect x="5" y="8" width="14" height="12" rx="1.5" />
      <path strokeLinecap="round" d="M9 8V6a3 3 0 016 0v2" />
    </svg>
  );
}
function SnowflakeIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" d="M12 2v20M4.5 6.5l15 11M19.5 6.5l-15 11" />
    </svg>
  );
}
function ShieldIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M9.5 12l1.8 1.8L15 10" />
    </svg>
  );
}
function ClockIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <circle cx="12" cy="12" r="9" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 7v5l3.5 2" />
    </svg>
  );
}
function PhoneIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 5c0 8.284 6.716 15 15 15l3-3-5-4-2 2c-2.5-1.2-4.3-3-5.5-5.5l2-2-4-5-3 2.5z" />
    </svg>
  );
}
function WhatsAppIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M12 2a10 10 0 00-8.5 15.2L2 22l4.9-1.5A10 10 0 1012 2zm5.6 14.3c-.2.6-1.3 1.2-1.9 1.3-.5.1-1.1.1-1.7-.1-.4-.1-1-.3-1.6-.6-2.9-1.2-4.7-4.1-4.9-4.3-.1-.2-1.2-1.6-1.2-3 0-1.4.7-2.1 1-2.4.3-.3.6-.4.8-.4h.6c.2 0 .4 0 .6.5.2.5.7 1.8.8 1.9.1.2.1.3 0 .5-.1.2-.2.3-.3.5-.2.2-.3.3-.1.6.7 1.2 1.4 1.9 2.5 2.5.2.1.3.1.5-.1.2-.2.7-.8.9-1.1.2-.3.4-.2.6-.1.2.1 1.5.7 1.8.8.3.1.4.2.5.3.1.2.1.7-.1 1.2z" />
    </svg>
  );
}
function ShareIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <circle cx="18" cy="5" r="2.5" />
      <circle cx="6" cy="12" r="2.5" />
      <circle cx="18" cy="19" r="2.5" />
      <path strokeLinecap="round" d="M8.2 10.8l7.6-4.1M8.2 13.2l7.6 4.1" />
    </svg>
  );
}
function ChevronIcon({ className, open }: { className?: string; open: boolean }) {
  return (
    <svg className={`${className ?? ''} transition-transform ${open ? 'rotate-180' : ''}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 9l6 6 6-6" />
    </svg>
  );
}
function RupeeIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 4h12M6 9h12M6 4c4 0 6.5 1.6 6.5 4.5S16 13 12 13H6l8 7" />
    </svg>
  );
}
function HeartIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 20s-7-4.4-9.5-8.8C.8 8 2 4.5 5.5 4c2-.3 3.7.7 6.5 3.5C14.8 4.7 16.5 3.7 18.5 4c3.5.5 4.7 4 3 7.2C19 15.6 12 20 12 20z" />
    </svg>
  );
}
function HeadsetIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 13v-1a8 8 0 0116 0v1M4 13v4a2 2 0 002 2h1v-6H5a1 1 0 00-1 1zm16 0v4a2 2 0 01-2 2h-1v-6h1a1 1 0 011 1zM9 19h4" />
    </svg>
  );
}

const WHY_ICONS: Record<string, (p: { className?: string }) => ReactElement> = {
  shield: ShieldIcon, rupee: RupeeIcon, star: () => (
    <svg viewBox="0 0 20 20" fill="currentColor" className="h-6 w-6" aria-hidden="true">
      <path d="M10 1.6l2.6 5.3 5.8.8-4.2 4.1 1 5.8L10 14.8l-5.2 2.8 1-5.8-4.2-4.1 5.8-.8L10 1.6z" />
    </svg>
  ), heart: HeartIcon,
};

function toWhatsAppLink(number: string): string {
  const digits = number.replace(/[^0-9]/g, '');
  return digits ? `https://wa.me/${digits}` : '';
}

function money(n: number | null): string {
  return n != null ? `₹${n.toLocaleString('en-IN')}` : '';
}

// Real reviews for THIS vehicle type only — GET /app/reviews?vehicle_type_id=N
// joins the actual booking row, so a "5-seat Sedan" page can never show a
// review that was actually left for a different vehicle type. An honest
// empty state (never a placeholder testimonial) when this vehicle type has
// no completed, rated trips yet. Fetched once here and shared by the hero
// rating line and the full reviews section below, rather than duplicating
// the request.
function useVehicleReviews(vehicleId: number) {
  const [rows, setRows] = useState<AppReview[] | null>(null);
  const [avg, setAvg] = useState<number | null>(null);
  const [count, setCount] = useState(0);

  useEffect(() => {
    let live = true;
    setRows(null);
    getReviews({ page: 1, vehicle_type_id: vehicleId })
      .then((r) => {
        if (!live) return;
        setRows(r.rows);
        setAvg(r.avg_rating);
        setCount(r.rating_count);
      })
      .catch(() => {
        if (live) {
          setRows([]);
          setAvg(null);
          setCount(0);
        }
      });
    return () => {
      live = false;
    };
  }, [vehicleId]);

  return { rows, avg, count };
}

function VehicleReviews({ vehicleName, rows, avg, count }: { vehicleName: string; rows: AppReview[] | null; avg: number | null; count: number }) {
  if (rows === null) {
    return (
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-4">
        <Skeleton className="h-32 rounded-xl" />
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-3 lg:col-span-3">
          {Array.from({ length: 3 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      </div>
    );
  }

  if (rows.length === 0) {
    return (
      <div className="flex min-h-[130px] flex-col items-center justify-center gap-1.5 rounded-2xl border border-dashed border-ink-200 bg-ink-50/60 px-6 py-6 text-center">
        <StarRow rating={0} />
        <p className="text-sm font-semibold text-ink-800">Be among the first to review this {vehicleName}</p>
        <p className="max-w-md text-xs text-ink-500">Your verified {brand().name} journey can help future travellers make their choice.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
      <div className="flex flex-col items-start justify-center rounded-xl border border-ink-100 bg-ink-50/60 p-6 lg:col-span-1">
        <span className="text-4xl font-bold text-ink-900">{avg}</span>
        <div className="mt-1"><StarRow rating={avg ?? 0} /></div>
        <p className="mt-1.5 text-sm text-ink-500">Based on {count} {count === 1 ? 'review' : 'reviews'}</p>
      </div>
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-3 lg:col-span-3">
        {rows.slice(0, 3).map((r) => (
          <div
            key={r.id}
            className="flex flex-col rounded-xl border border-ink-100 bg-white p-5 shadow-xs transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-[0_6px_18px_rgba(0,0,0,0.06)]"
          >
            <div className="flex items-center gap-3">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-100 text-sm font-bold text-brand-700">
                {r.client_name.slice(0, 2).toUpperCase()}
              </span>
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-ink-900">{r.client_name}</p>
                <StarRow rating={r.rating} size="h-3.5 w-3.5" />
              </div>
            </div>
            <p className="mt-3 flex-1 text-sm text-ink-600">&ldquo;{r.review}&rdquo;</p>
            <p className="mt-3 text-xs text-ink-400">{r.pickup_city}{r.drop_city ? ` → ${r.drop_city}` : ''}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function FaqAccordion({ items }: { items: { group: string; q: string; a: string }[] }) {
  const [open, setOpen] = useState<number | null>(null);
  const groups: string[] = [];
  items.forEach((it) => { if (!groups.includes(it.group)) groups.push(it.group); });
  return (
    <div className="grid grid-cols-1 gap-x-8 gap-y-6 md:grid-cols-2">
      {groups.map((group) => (
        <div key={group} className="flex flex-col gap-3">
          <p className="text-[11px] font-bold uppercase tracking-wide text-ink-400">{group}</p>
          {items.map((item, i) => item.group !== group ? null : (
            <div
              key={item.q}
              className="rounded-xl border border-ink-100 bg-white transition-transform duration-200 hover:-translate-y-0.5 hover:shadow-[0_6px_18px_rgba(0,0,0,0.06)]"
            >
              <button
                type="button"
                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                aria-expanded={open === i}
                onClick={() => setOpen((cur) => (cur === i ? null : i))}
              >
                <span className="text-sm font-medium text-ink-900">{item.q}</span>
                <ChevronIcon className="h-5 w-5 shrink-0 text-ink-400" open={open === i} />
              </button>
              {open === i && <p className="border-t border-ink-50 px-5 py-3 text-sm text-ink-600">{item.a}</p>}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

export function VehicleDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const prefill = (location.state as SearchPrefillState | null) ?? null;
  const hasPrefill = Boolean(prefill?.pickup && prefill?.drop && prefill?.date);

  const [vehicles, setVehicles] = useState<Vehicle[] | null>(null);
  const [home, setHome] = useState<HomeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [shareMsg, setShareMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const v = await getVehicles();
      setVehicles(v);
      // Same city lists the home page's booking widget uses — fetched
      // separately (and tolerant of failure) so a hiccup here never blocks
      // the vehicle itself from loading; the widget just renders with
      // whatever city lists it gets, same as it does on slow connections
      // on the home page.
      getHome().then(setHome).catch(() => setHome(null));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load this vehicle. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const vehicle = vehicles?.find((v) => v.slug === slug) ?? null;
  const reviews = useVehicleReviews(vehicle?.id ?? 0);

  function handleCheckFare() {
    if (!vehicle) return;
    if (hasPrefill && prefill) {
      navigate('/book', { state: { tripType: prefill.tripType, pickup: prefill.pickup, drop: prefill.drop, vehicleId: vehicle.id, date: prefill.date } });
    } else {
      navigate('/book', { state: { vehicleId: vehicle.id } });
    }
  }

  // Real functional share (native share sheet, falling back to copying the
  // URL) — not a decorative button. No wishlist button: RideGo has no
  // wishlist/saved-vehicles feature anywhere in the backend, and inventing
  // one client-side (e.g. in localStorage) would fabricate a feature that
  // does nothing for the account elsewhere, so it's left out entirely
  // rather than shipped as a fake control.
  async function handleShare() {
    if (!vehicle) return;
    const shareData = { title: `${vehicle.name} — ${brand().name}`, url: window.location.href };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
        return;
      }
    } catch {
      // user cancelled or share failed — fall through to clipboard
    }
    try {
      await navigator.clipboard.writeText(window.location.href);
      setShareMsg('Link copied to clipboard.');
      setTimeout(() => setShareMsg(null), 2500);
    } catch {
      setShareMsg(window.location.href);
    }
  }

  if (loading) {
    return (
      <div className="bg-canvas py-6 sm:py-10">
        <div className="mx-auto max-w-[1200px] px-4 py-4 sm:px-6 lg:px-8" aria-busy="true" aria-label="Loading vehicle">
          <Skeleton className="h-4 w-64" />
          <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-[62%_1fr]">
            <div>
              <Skeleton className="h-[400px] rounded-[20px]" />
              <Skeleton className="mt-4 h-8 w-1/2" />
              <Skeleton className="mt-2 h-4 w-1/3" />
            </div>
            <Skeleton className="h-[480px] rounded-[18px]" />
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
        <ErrorBanner message={error} onRetry={load} />
      </div>
    );
  }

  if (!vehicle) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        <EmptyState
          title="Vehicle not found"
          description="We couldn't find a vehicle type matching this link. It may no longer be available."
          action={
            <Link to="/">
              <Button>Browse vehicles</Button>
            </Link>
          }
        />
      </div>
    );
  }

  const p = vehicle.pricing;
  const hasAnyPricing = p.local_8hr_80km != null || p.local_4hr_40km != null || p.per_km != null || p.airport_base_charge != null;

  // Spec table rows — every row comes from a real field on this vehicle.
  // No transmission type, fuel type, mileage or dimensions are invented:
  // the API's Vehicle shape simply doesn't carry them, so those reference
  // rows are honestly omitted rather than faked (see visual-parity-report.md).
  const specRows: { icon: (p: { className?: string }) => ReactElement; label: string; value: string }[] = [
    { icon: SeatIcon, label: 'Seating capacity', value: `${vehicle.seating_capacity}` },
  ];
  if (vehicle.ac_available != null) specRows.push({ icon: SnowflakeIcon, label: 'Air conditioning', value: vehicle.ac_available ? 'Yes' : 'No' });
  if (vehicle.luggage_capacity != null) specRows.push({ icon: LuggageIcon, label: 'Luggage capacity', value: `${vehicle.luggage_capacity} bag${vehicle.luggage_capacity === 1 ? '' : 's'}` });
  if (p.minimum_km != null) specRows.push({ icon: ClockIcon, label: 'Minimum billed distance', value: `${p.minimum_km} km` });
  vehicle.features.forEach((f) => specRows.push({ icon: ShieldIcon, label: f, value: 'Included' }));

  // Icon strip below the hero — same honesty rule as the spec table above.
  const quickSpecs: { icon: (p: { className?: string }) => ReactElement; title: string; desc: string }[] = [
    { icon: SeatIcon, title: `${vehicle.seating_capacity} Seats`, desc: 'Spacious & comfortable' },
  ];
  if (vehicle.ac_available) quickSpecs.push({ icon: SnowflakeIcon, title: 'AC', desc: 'Climate control' });
  if (vehicle.luggage_capacity != null) quickSpecs.push({ icon: LuggageIcon, title: `${vehicle.luggage_capacity} bags`, desc: 'Luggage capacity' });
  quickSpecs.push({ icon: CarIcon, title: vehicle.name, desc: 'Vehicle type' });

  const whatsappLink = toWhatsAppLink(brand().support_whatsapp);
  const aboutSentence = [
    `Experience a comfortable, well-maintained ${vehicle.name} — ideal for family trips, outstation travel, corporate travel and airport transfers.`,
    ` The ${vehicle.name} seats up to ${vehicle.seating_capacity} passengers`,
    vehicle.luggage_capacity != null ? ` with room for ${vehicle.luggage_capacity} bag${vehicle.luggage_capacity === 1 ? '' : 's'} of luggage` : '',
    vehicle.ac_available ? ', air-conditioned throughout' : '',
    '. Every trip comes with a verified driver-partner — this is a driver-included ride, not a self-drive rental.',
  ].join('');

  // The same use-case tags shown as pills in the reference design — real
  // trip types RideGo actually supports (booking.php's trip_type enum),
  // not vehicle-specific claims.
  const useCases = ['Family Trips', 'Outstation Travel', 'Airport Transfers', 'Corporate Travel', 'Group Travel'];

  const pricingCards: { title: string; price: string; unit: string; bullets: string[] }[] = [];
  if (p.local_8hr_80km != null) pricingCards.push({ title: 'Local (within city)', price: money(p.local_8hr_80km), unit: '8 hours / 80 km', bullets: ['Driver included', 'Fuel charges extra', 'Extra km charges apply'] });
  if (p.local_4hr_40km != null) pricingCards.push({ title: 'Local (short trip)', price: money(p.local_4hr_40km), unit: '4 hours / 40 km', bullets: ['Driver included', 'Fuel charges extra', 'Extra km charges apply'] });
  if (p.per_km != null) pricingCards.push({ title: 'Outstation', price: `₹${p.per_km}${p.per_km_outstation != null && p.per_km_outstation !== p.per_km ? `–${p.per_km_outstation}` : ''}/km`, unit: p.minimum_km != null ? `Minimum ${p.minimum_km} km/day` : 'Per day', bullets: ['Driver included', 'Fuel charges extra', 'Extra km charges apply'] });
  if (p.airport_base_charge != null) pricingCards.push({ title: 'Airport transfer', price: money(p.airport_base_charge), unit: 'One way (city ↔ airport)', bullets: ['Driver included', 'Fuel charges extra', 'Extra km charges apply'] });

  // Section heading — one master style so every section (§40) reads as
  // part of one system rather than ad-hoc per-section sizes.
  const H2 = 'text-[22px] font-bold leading-[28px] tracking-tight text-ink-900';

  return (
    <div className="bg-canvas py-6 sm:py-10">
      <div className="mx-auto w-[calc(100%-48px)] max-w-[1200px] 2xl:max-w-[1240px]">
        {/* Breadcrumb / top row — shares the page's one master content column,
            no wrapping outer card (§40, §42: eliminate the giant white
            outer-card wrapper). */}
        <div className="flex h-10 flex-wrap items-center justify-between gap-3">
          <Link to="/services" className="inline-flex items-center gap-1.5 text-sm font-medium text-ink-700 hover:text-brand-700">
            <span aria-hidden="true">←</span> Back to vehicle types
          </Link>
          <div className="relative flex items-center gap-2">
            <button type="button" onClick={handleShare} className="inline-flex items-center gap-1.5 rounded-[10px] border border-ink-200 px-3 py-1.5 text-sm font-medium text-ink-700 transition-colors hover:bg-ink-50 active:bg-ink-100">
              <ShareIcon className="h-4 w-4" /> Share
            </button>
            {shareMsg && <span role="status" className="absolute right-0 top-full mt-1 whitespace-nowrap rounded-lg bg-ink-900 px-2.5 py-1 text-xs text-white">{shareMsg}</span>}
          </div>
        </div>
        <nav aria-label="Breadcrumb" className="mt-1 flex items-center gap-1.5 text-xs text-[#667085]">
          <Link to="/" className="hover:text-brand-700 hover:underline">Home</Link>
          <span aria-hidden="true">/</span>
          <Link to="/services" className="hover:text-brand-700 hover:underline">Vehicles</Link>
          <span aria-hidden="true">/</span>
          <span className="font-semibold text-[#344054]">{vehicle.name}</span>
        </nav>

        {/* ================= HERO: gallery (~1.65fr) + booking engine (~0.9fr) =================
            Gallery is architecturally a list — `vehicle.image_url` is mapped into a
            one-element array today (RideGo has exactly one real photo per vehicle
            type), so a future multi-photo DB only needs this array to grow; no
            filmstrip is rendered for a single image since there is nothing real to
            navigate between, and no additional photos are ever fabricated. */}
        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1.65fr)_minmax(360px,0.9fr)] lg:items-start">
          {/* HERO LEFT — gallery */}
          <div>
            <div className="relative overflow-hidden rounded-[20px] bg-ink-100" style={heightStyle(brand().vehicle_detail_height, 440)}>
              {vehicle.base_fare != null && (
                <span className="absolute left-4 top-4 z-10 inline-flex h-7 items-center gap-1 rounded-full bg-ink-900/90 px-3 text-[11px] font-semibold text-white">
                  ★ Most popular
                </span>
              )}
              {[vehicle.image_url].filter((url): url is string => Boolean(url)).map((url) => (
                <div key={url} className="absolute inset-0">
                  <img src={url} alt={vehicle.name} className={'h-full w-full ' + fitClass(brand().vehicle_detail_fit)} loading="lazy" />
                </div>
              ))}
              {!vehicle.image_url && (
                <div className="flex h-full items-center justify-center">
                  <CarIcon className="h-20 w-20 text-ink-300" />
                </div>
              )}
            </div>

            <h1 className="mt-4 text-[28px] font-bold leading-[34px] tracking-tight text-ink-900">{vehicle.name}</h1>
            <p className="mt-1 text-sm text-[#667085]">
              {[
                `${vehicle.seating_capacity} seats`,
                vehicle.luggage_capacity != null ? `${vehicle.luggage_capacity} bag${vehicle.luggage_capacity === 1 ? '' : 's'}` : null,
                vehicle.ac_available ? 'AC' : null,
                'Driver included',
              ].filter(Boolean).join(' · ')}
            </p>

            {/* Quick facts — bold metric tiles (§20), only the fields this
                vehicle actually has. */}
            <div className="mt-5 flex flex-wrap gap-3">
              {quickSpecs.map((s) => (
                <div key={s.title} className="min-w-[120px] flex-1 rounded-xl bg-[#F8FAFC] p-4">
                  <s.icon className="h-5 w-5 text-brand-600" />
                  <p className="mt-2 text-lg font-bold text-[#101828]">{s.title}</p>
                  <p className="text-xs font-medium text-[#667085]">{s.desc}</p>
                </div>
              ))}
            </div>

            {/* Use-case tags */}
            <div className="mt-4 flex flex-wrap gap-2">
              {useCases.map((f) => (
                <span key={f} className="inline-flex h-[28px] items-center rounded-full border border-ink-200 bg-white px-2.5 text-[11px] font-medium text-ink-700">{f}</span>
              ))}
            </div>
          </div>

          {/* HERO RIGHT — booking engine, the strongest component on the page */}
          <div className="rounded-[18px] border border-[#E4E7EC] bg-white p-5 shadow-l3">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                {vehicle.base_fare != null ? (
                  <>
                    <p className="text-xs text-[#667085]">Starting from</p>
                    <p className="text-[30px] font-extrabold leading-[36px] text-ink-900">
                      {money(vehicle.base_fare)} <span className="text-[13px] font-medium text-[#667085]">/day</span>
                    </p>
                  </>
                ) : (
                  <p className="text-sm font-semibold text-ink-800">Fare on request</p>
                )}
              </div>
              {reviews.avg != null && (
                <a href="#reviews" className="flex flex-col items-end text-sm hover:opacity-80">
                  <span className="flex items-center gap-1 font-semibold text-warning-600">
                    <StarRow rating={reviews.avg} size="h-3.5 w-3.5" />
                    {reviews.avg}
                  </span>
                  <span className="text-xs text-ink-400">({reviews.count}+ trips)</span>
                </a>
              )}
            </div>
            <p className="mt-1 text-[11px] text-[#667085]">Taxes and charges may vary based on location, duration and trip type.</p>

            {/* Trust strip — 3 equal columns */}
            <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl bg-[#F5F9FF] p-3 text-center">
              <div className="flex h-16 flex-col items-center justify-center gap-1">
                <DriverIcon className="h-5 w-5 text-brand-600" />
                <span className="text-[11px] font-semibold text-ink-800">Verified driver</span>
                <span className="text-[10px] leading-tight text-ink-400">Trained &amp; background-checked</span>
              </div>
              <div className="flex h-16 flex-col items-center justify-center gap-1">
                <ShieldIcon className="h-5 w-5 text-brand-600" />
                <span className="text-[11px] font-semibold text-ink-800">Free cancellation</span>
                <span className="text-[10px] leading-tight text-ink-400">Up to 24 hours</span>
              </div>
              <div className="flex h-16 flex-col items-center justify-center gap-1">
                <ClockIcon className="h-5 w-5 text-brand-600" />
                <span className="text-[11px] font-semibold text-ink-800">24/7 support</span>
                <span className="text-[10px] leading-tight text-ink-400">Call &amp; WhatsApp</span>
              </div>
            </div>

            {hasPrefill && prefill && (
              <div className="mt-4 rounded-xl border border-brand-100 bg-brand-50 p-3">
                <p className="text-xs font-medium text-brand-800">Checking fares for {prefill.pickup} → {prefill.drop} on {prefill.date}</p>
              </div>
            )}

            {/* Same booking/fare-search form as the home page — same trip-type
                tabs, city selects, vehicle select and fare-estimate flow —
                just preselected to this vehicle type, rendered "embedded" so
                this card owns the outer chrome instead of double-nesting. */}
            <div className="mt-4">
              <FareSearchWidget
                cities={home?.popular_cities ?? []}
                originCities={home?.origin_cities}
                destinationCities={home?.destination_cities}
                vehicles={vehicles ?? []}
                initialVehicleId={vehicle.id}
                embedded
              />
            </div>
            <div className="mt-3 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-[11px] text-[#667085]">
              <span>✓ No hidden charges</span>
              <span>✓ Instant confirmation</span>
              <span>✓ Secure booking</span>
            </div>

            {/* Assistance card — integrated into the booking column, not a
                detached weak block elsewhere on the page. */}
            <div className="mt-4 rounded-2xl bg-[#F8FAFC] p-[18px]">
              <HeadsetIcon className="h-6 w-6 text-brand-600" />
              <h3 className="mt-2 text-sm font-semibold text-ink-900">Need assistance?</h3>
              <p className="mt-1 text-xs text-ink-500">Our travel experts are here to help you 24/7.</p>
              <div className="mt-3 space-y-2">
                {brand().support_phone && (
                  <a href={`tel:${brand().support_phone}`} className="flex h-11 items-center justify-center gap-2 rounded-[10px] bg-brand-700 px-4 text-sm font-semibold text-white transition-colors hover:bg-brand-800 active:bg-brand-900">
                    <PhoneIcon className="h-4 w-4" /> Call now
                  </a>
                )}
                {whatsappLink && (
                  <a href={whatsappLink} target="_blank" rel="noreferrer" className="flex h-11 items-center justify-center gap-2 rounded-[10px] border border-success-300 bg-white px-4 text-sm font-semibold text-success-700 transition-colors hover:bg-success-50">
                    <WhatsAppIcon className="h-4 w-4" /> WhatsApp us
                  </a>
                )}
                {!brand().support_phone && !whatsappLink && <p className="text-xs text-ink-500">Contact details will appear here once configured in Settings.</p>}
              </div>
            </div>
          </div>
        </div>

        {/* ================= ABOUT =================
            Sits closer to the hero than the other major-section gaps (32px vs
            48px) — the hero grid's own row height is set by the taller booking
            column, so pairing that with the default 48px would compound into
            an oversized gap under the shorter gallery column. */}
        <div className="mt-8">
          <h2 className={H2}>About this vehicle</h2>
          <p className="mt-3 max-w-[780px] text-sm leading-[1.65] text-ink-600">{aboutSentence}</p>
        </div>

        {/* ================= SPECIFICATIONS ================= */}
        {specRows.length > 1 && (
          <div className="mt-12">
            <h2 className={H2}>Vehicle specifications</h2>
            <div className="mt-5 grid grid-cols-1 gap-8 lg:grid-cols-[42%_1fr] lg:items-start">
              <div className="hidden overflow-hidden rounded-2xl bg-[#EEF0F3] lg:block" style={{ height: 280 }}>
                {vehicle.image_url ? (
                  <img src={vehicle.image_url} alt={vehicle.name} className="h-full w-full object-cover" loading="lazy" />
                ) : (
                  <div className="flex h-full items-center justify-center"><CarIcon className="h-24 w-24 text-ink-200" /></div>
                )}
              </div>
              <div className="overflow-hidden rounded-2xl border border-[#E4E7EC]">
                {specRows.map((r, i) => (
                  <div key={r.label} className={`flex min-h-[44px] items-center justify-between gap-4 px-4 py-2 text-sm ${i % 2 === 1 ? 'bg-[#F8FAFC]' : 'bg-white'}`}>
                    <span className="flex items-center gap-2.5 font-medium text-[#667085]">
                      <r.icon className="h-4 w-4 text-ink-400" /> {r.label}
                    </span>
                    <span className="text-right font-semibold text-[#101828]">{r.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ================= PRICING & OPTIONS ================= */}
        {hasAnyPricing && (
          <div className="mt-12">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h2 className={H2}>Pricing &amp; options</h2>
              <p className="text-xs text-ink-500">Prices may vary based on location, duration and season.</p>
            </div>
            <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {pricingCards.map((c, i) => (
                <div
                  key={c.title}
                  className={`rounded-2xl p-[18px] transition-transform duration-200 hover:-translate-y-0.5 ${i === 0 ? 'border-2 border-brand-600 bg-[#F5F9FF]' : 'border border-[#E4E7EC] bg-white shadow-l1'}`}
                  style={{ minHeight: 176 }}
                >
                  <p className="text-[13px] font-semibold text-ink-900">{c.title}</p>
                  <p className="mt-1 text-[22px] font-extrabold text-ink-900">{c.price}</p>
                  <p className="text-xs text-ink-500">{c.unit}</p>
                  <ul className="mt-3 space-y-1 text-[11px] text-ink-500">
                    {c.bullets.map((b) => (
                      <li key={b} className="flex items-center gap-1.5"><span className="text-success-600">✓</span> {b}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= WHAT'S INCLUDED ================= */}
        <div className="mt-12">
          <h2 className={H2}>What&rsquo;s included</h2>
          <div className="mt-5 grid grid-cols-1 gap-x-8 gap-y-5 sm:grid-cols-2">
            {INCLUDED_FEATURES.map((f) => (
              <div key={f.title} className="flex gap-3 rounded-2xl bg-[#F8FAFC] p-[18px]" style={{ minHeight: 90 }}>
                <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px] ${f.color}`}>
                  <span className="h-2.5 w-2.5 rounded-sm bg-current" />
                </span>
                <div>
                  <h3 className="text-[13px] font-bold text-ink-900">{f.title}</h3>
                  <p className="mt-1 text-xs leading-[1.5] text-ink-500">{f.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ================= WHY CHOOSE RIDEGO — one subtle tinted section ================= */}
        <div className="mt-12 rounded-2xl bg-[#F7FAFF] p-8 sm:p-10">
          <h2 className={H2}>Why choose {brand().name}?</h2>
          <div className="mt-8 grid grid-cols-1 gap-y-10 gap-x-8 text-center sm:grid-cols-2 lg:grid-cols-4">
            {WHY_RIDEGO.map((w) => {
              const Icon = WHY_ICONS[w.icon];
              return (
                <div key={w.title} className="flex flex-col items-center">
                  <span className="flex h-12 w-12 items-center justify-center rounded-full bg-white text-brand-600 shadow-l1">
                    <Icon className="h-6 w-6" />
                  </span>
                  <h3 className="mt-4 text-sm font-bold text-ink-900">{w.title}</h3>
                  <p className="mt-1.5 text-xs text-ink-500">{w.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* ================= REVIEWS ================= */}
        <div id="reviews" className="mt-12 scroll-mt-20">
          <h2 className={H2}>Customer reviews</h2>
          <div className="mt-5">
            <VehicleReviews vehicleName={vehicle.name} rows={reviews.rows} avg={reviews.avg} count={reviews.count} />
          </div>
        </div>

        {/* ================= FAQ ================= */}
        <div className="mt-12">
          <h2 className={H2}>Frequently asked questions</h2>
          <div className="mt-5">
            <FaqAccordion items={faqFor(vehicle.name)} />
          </div>
        </div>

        {/* ================= FINAL CTA — major visual event ================= */}
        <div className="relative mt-12 overflow-hidden rounded-[20px] text-white" style={{ minHeight: 220 }}>
          {vehicle.image_url && (
            <img src={vehicle.image_url} alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover" />
          )}
          <div className="absolute inset-0 bg-gradient-to-r from-ink-950/95 via-ink-950/75 to-ink-950/40" />
          <div className="relative flex h-full flex-col justify-center gap-3 p-8 sm:p-10" style={{ minHeight: 220 }}>
            <h2 className="text-[28px] font-extrabold leading-tight">Ready for your next journey?</h2>
            <p className="max-w-lg text-sm text-ink-200">Book this {vehicle.name} now and travel with comfort, safety and peace of mind.</p>
            <div>
              <Button
                className="h-12 rounded-[10px] px-[22px] text-sm font-bold transition-transform hover:-translate-y-0.5"
                onClick={handleCheckFare}
              >
                Check fare &amp; book now &rarr;
              </Button>
            </div>
            <p className="text-xs text-ink-300">✓ Verified drivers &nbsp; ✓ Transparent pricing &nbsp; ✓ 24/7 support</p>
          </div>
        </div>
      </div>
    </div>
  );
}
