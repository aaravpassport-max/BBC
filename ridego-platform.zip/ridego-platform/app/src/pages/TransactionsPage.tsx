import { useCallback, useEffect, useState } from 'react';
import { getTransactions, ApiError } from '../lib/api';
import type { AppTransaction } from '../types/api';
import { Skeleton } from '../components/ui/Skeleton';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { EmptyState } from '../components/ui/EmptyState';
import { Button } from '../components/ui/Button';
import { brand } from '../lib/brand';
import { DATA_CARD_CLASS } from '../components/ui/Zone';

function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

const gatewayLabels: Record<string, string> = {
  razorpay: 'Razorpay',
  cash: 'Cash',
  manual: 'Bank transfer/Cash',
  upi: 'UPI',
  bank_transfer: 'Bank transfer',
};

function humanizeGateway(gateway: string): string {
  if (!gateway) return 'Unknown';
  return gatewayLabels[gateway] ?? gateway.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return dateStr;
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function TransactionsPage() {
  const [page, setPage] = useState(1);
  const [rows, setRows] = useState<AppTransaction[] | null>(null);
  const [total, setTotal] = useState(0);
  const [perPage, setPerPage] = useState(20);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (p: number) => {
    setLoading(true);
    setError(null);
    try {
      const res = await getTransactions({ page: p });
      setRows(res.rows);
      setTotal(res.total);
      setPerPage(res.per_page);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load your transaction history. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(page);
  }, [page, load]);

  const canPrev = page > 1;
  const canNext = page * perPage < total;

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Transaction history</h1>
          <p className="text-sm text-ink-500">Booking amount payments and refunds made to {brand().name} across your bookings. Ride fares paid to vendors/drivers are not listed here.</p>
        </div>
      </div>

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading transaction history">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
                <div className="flex items-center justify-between">
                  <Skeleton className="h-4 w-40" />
                  <Skeleton className="h-5 w-20 rounded-full" />
                </div>
                <Skeleton className="mt-3 h-3 w-64" />
                <Skeleton className="mt-2 h-3 w-32" />
              </div>
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={() => load(page)} />}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState
            title="No transactions yet"
            description="Booking amount payments and refunds will show up here."
          />
        )}

        {!loading && !error && rows && rows.length > 0 && (
          <>
            <ul className="space-y-3">
              {rows.map((t) => {
                const isRefund = t.type === 'refund';
                return (
                  <li key={t.id} className={`${DATA_CARD_CLASS} p-4 transition hover:shadow-sm sm:p-5`}>
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <p className="font-semibold text-ink-900">
                          {t.pickup_city} → {t.drop_city}
                        </p>
                        <p className="mt-0.5 text-sm text-ink-500">
                          #{t.booking_number} &middot; {humanizeGateway(t.gateway)}
                        </p>
                      </div>
                      <span
                        className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${
                          isRefund ? 'bg-warning-50 text-warning-600' : 'bg-success-50 text-success-600'
                        }`}
                      >
                        {isRefund ? 'Refund' : 'Booking amount'}
                      </span>
                    </div>

                    <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-ink-100 pt-3">
                      <p
                        className={`text-sm font-semibold ${
                          isRefund ? 'text-warning-600' : 'text-ink-800'
                        }`}
                      >
                        {isRefund ? '- ' : ''}
                        {currency(t.amount)}
                        {!isRefund && <span className="ml-2 font-normal capitalize text-ink-500">{t.status}</span>}
                      </p>
                      <p className="text-xs text-ink-500">{formatDate(t.created_at)}</p>
                    </div>
                  </li>
                );
              })}
            </ul>

            <div className="mt-6 flex items-center justify-between">
              <p className="text-sm text-ink-500">
                Page {page} of {Math.max(1, Math.ceil(total / perPage))} &middot; {total} transaction{total === 1 ? '' : 's'}
              </p>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" disabled={!canPrev} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                  Previous
                </Button>
                <Button variant="secondary" size="sm" disabled={!canNext} onClick={() => setPage((p) => p + 1)}>
                  Next
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
