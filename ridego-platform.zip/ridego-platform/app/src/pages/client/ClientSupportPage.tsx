import { useCallback, useEffect, useId, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import {
  COMPLAINT_CATEGORIES,
  createClientComplaint,
  errorMessage,
  formatDate,
  getClientSupport,
  getClientTrips,
  humanize,
  type ClientComplaint,
  type ClientTrip,
} from '../../lib/api-client-dashboard';
import { useToast } from '../../context/ToastContext';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { DataCard, DATA_CARD_CLASS } from '../../components/ui/Zone';

const FOCUS = 'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600';
const FIELD = `mt-1 block w-full rounded-lg border border-ink-300 bg-white px-3 py-2 text-sm text-ink-900 ${FOCUS}`;
const SKELETON_IDS = ['sk-a', 'sk-b', 'sk-c'];

// TRACE: complaint status → badge classes.
//        status string → AA-contrast classes → unknown statuses get the neutral style.
function complaintStatusClasses(status: string): string {
  if (status === 'resolved' || status === 'closed') return 'bg-success-50 text-success-600';
  if (status === 'open') return 'bg-warning-50 text-warning-600';
  if (status === 'in_progress') return 'bg-brand-50 text-brand-700';
  return 'bg-ink-100 text-ink-700';
}

interface ComplaintFormProps {
  fixedBookingId?: number;
  trips?: ClientTrip[];
  tripsLoading?: boolean;
  tripsError?: string | null;
  onRetryTrips?: () => void;
  onSubmitted: () => void;
}

// TRACE: form submit → validates trip/category/description → POST /client/support → toast + parent refetch.
//        fixedBookingId (trip page) or a picked trip → complaint filed and form reset → blocks double submit,
//        shows inline validation, shows server message on failure, empty trip list explains itself,
//        ignores a response arriving after unmount.
export function ComplaintForm({ fixedBookingId, trips = [], tripsLoading = false, tripsError = null, onRetryTrips, onSubmitted }: ComplaintFormProps) {
  const toast = useToast();
  const uid = useId();
  const [tripId, setTripId] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const mounted = useRef(true);

  // TRACE: mount → marks mounted; unmount → clears flag.
  //        none → guards post-await state writes → prevents updates after unmount.
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  // TRACE: trip select change → stores chosen booking id.
  //        option value → state updated → clears any stale form error.
  const handleTrip = (e: ChangeEvent<HTMLSelectElement>) => {
    setTripId(e.target.value);
    setFormError(null);
  };
  // TRACE: category select change → stores category.
  //        option value → state updated → clears any stale form error.
  const handleCategory = (e: ChangeEvent<HTMLSelectElement>) => {
    setCategory(e.target.value);
    setFormError(null);
  };
  // TRACE: description input → stores text.
  //        textarea value → state updated → clears any stale form error.
  const handleDescription = (e: ChangeEvent<HTMLTextAreaElement>) => {
    setDescription(e.target.value);
    setFormError(null);
  };

  // TRACE: submit event → validates then files the complaint.
  //        not already submitting → success toast, form reset, onSubmitted() → missing trip/category/description
  //        rejected inline; ApiError message shown inline and as a toast.
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    const bookingId = fixedBookingId ?? Number(tripId);
    if (!bookingId) {
      setFormError('Choose the trip this issue is about.');
      return;
    }
    if (!category) {
      setFormError('Choose a category.');
      return;
    }
    if (description.trim() === '') {
      setFormError('Describe what went wrong.');
      return;
    }
    setSubmitting(true);
    setFormError(null);
    try {
      await createClientComplaint({ booking_id: bookingId, category, description: description.trim() });
      toast.show('Your issue has been raised. We will get back to you soon.', 'success');
      if (mounted.current) {
        setTripId('');
        setCategory('');
        setDescription('');
      }
      onSubmitted();
    } catch (err) {
      const msg = errorMessage(err, 'Could not raise your issue. Please try again.');
      toast.show(msg, 'error');
      if (mounted.current) setFormError(msg);
    } finally {
      if (mounted.current) setSubmitting(false);
    }
  };

  const noTrips = fixedBookingId === undefined && !tripsLoading && !tripsError && trips.length === 0;

  return (
    <form onSubmit={handleSubmit} className="space-y-4" noValidate>
      {fixedBookingId === undefined && (
        <div>
          <label htmlFor={`${uid}-trip`} className="text-sm font-medium text-ink-800">
            Trip
          </label>
          {tripsLoading && <Skeleton className="mt-1 h-10 w-full" />}
          {!tripsLoading && tripsError && (
            <div className="mt-1">
              <ErrorBanner message={tripsError} onRetry={onRetryTrips} />
            </div>
          )}
          {noTrips && <p className="mt-1 text-sm text-ink-600">You have no upcoming or completed trips to raise an issue about yet.</p>}
          {!tripsLoading && !tripsError && trips.length > 0 && (
            <select id={`${uid}-trip`} value={tripId} onChange={handleTrip} className={FIELD} disabled={submitting}>
              <option value="">Select a trip</option>
              {trips.map((t) => (
                <option key={t.id} value={String(t.id)}>
                  {t.booking_number} · {t.pickup_city} → {t.drop_city} · {formatDate(t.journey_date)}
                </option>
              ))}
            </select>
          )}
        </div>
      )}
      <div>
        <label htmlFor={`${uid}-category`} className="text-sm font-medium text-ink-800">
          Category
        </label>
        <select id={`${uid}-category`} value={category} onChange={handleCategory} className={FIELD} disabled={submitting}>
          <option value="">Select a category</option>
          {COMPLAINT_CATEGORIES.map((c) => (
            <option key={c.value} value={c.value}>
              {c.label}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor={`${uid}-desc`} className="text-sm font-medium text-ink-800">
          What happened?
        </label>
        <textarea
          id={`${uid}-desc`}
          value={description}
          onChange={handleDescription}
          rows={4}
          maxLength={1000}
          className={FIELD}
          disabled={submitting}
        />
      </div>
      {formError && (
        <p role="alert" className="text-sm text-danger-600">
          {formError}
        </p>
      )}
      <Button type="submit" loading={submitting} disabled={noTrips}>
        {submitting ? 'Sending…' : 'Raise issue'}
      </Button>
    </form>
  );
}

// TRACE: complaint row → card with trip number, category, status, description, resolution.
//        complaint → readable card → missing booking number and resolution are omitted.
function ComplaintCard({ c }: { c: ClientComplaint }) {
  return (
    <li>
    <DataCard className="p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <p className="text-sm font-semibold text-ink-900">
          {humanize(c.category)}
          {c.booking_number ? ` · Trip ${c.booking_number}` : ''}
        </p>
        <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${complaintStatusClasses(c.status)}`}>{humanize(c.status)}</span>
      </div>
      <p className="mt-1 text-xs text-ink-600">
        {c.complaint_id} · {formatDate(c.created_at)}
      </p>
      <p className="mt-2 whitespace-pre-line text-sm text-ink-700">{c.description}</p>
      {c.resolution && (
        <p className="mt-2 rounded-lg bg-ink-50 p-2 text-sm text-ink-700">
          <strong className="text-ink-900">Resolution:</strong> {c.resolution}
        </p>
      )}
    </DataCard>
    </li>
  );
}

// TRACE: route /app/dashboard/support → loads complaints and pickable trips independently → list + raise form.
//        logged-in client → both regions render → each has loading/empty/error, stale responses ignored via request
//        ids, form submit triggers a fresh server fetch of the list.
export function ClientSupportPage() {
  const [complaints, setComplaints] = useState<ClientComplaint[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const listReq = useRef(0);

  const [trips, setTrips] = useState<ClientTrip[]>([]);
  const [tripsLoading, setTripsLoading] = useState(true);
  const [tripsError, setTripsError] = useState<string | null>(null);
  const [tripsKey, setTripsKey] = useState(0);
  const tripsReq = useRef(0);

  // TRACE: mount/reload → fetches complaints → list or error.
  //        latest request wins → state committed → stale/unmounted responses ignored.
  useEffect(() => {
    const id = ++listReq.current;
    // TRACE: effect start → awaits API → commits if current.
    //        id matches → loading cleared → failure becomes readable message.
    async function run() {
      setLoading(true);
      setError(null);
      try {
        const res = await getClientSupport();
        if (id !== listReq.current) return;
        setComplaints(res.rows);
      } catch (err) {
        if (id !== listReq.current) return;
        setError(errorMessage(err, 'Could not load your complaints. Please try again.'));
      } finally {
        if (id === listReq.current) setLoading(false);
      }
    }
    void run();
    return () => {
      listReq.current += 1;
    };
  }, [reloadKey]);

  // TRACE: mount/retry → fetches completed + upcoming trips for the picker.
  //        latest request wins → merged, de-duplicated list → failure of either shows one readable error.
  useEffect(() => {
    const id = ++tripsReq.current;
    // TRACE: effect start → parallel fetch → commits if current.
    //        id matches → picker state updated → error message on any failure.
    async function run() {
      setTripsLoading(true);
      setTripsError(null);
      try {
        const [done, coming] = await Promise.all([getClientTrips('completed', 1), getClientTrips('upcoming', 1)]);
        if (id !== tripsReq.current) return;
        const seen = new Set<number>();
        const merged = [...done.rows, ...coming.rows].filter((t) => {
          if (seen.has(t.id)) return false;
          seen.add(t.id);
          return true;
        });
        setTrips(merged);
      } catch (err) {
        if (id !== tripsReq.current) return;
        setTripsError(errorMessage(err, 'Could not load your trips. Please try again.'));
      } finally {
        if (id === tripsReq.current) setTripsLoading(false);
      }
    }
    void run();
    return () => {
      tripsReq.current += 1;
    };
  }, [tripsKey]);

  // TRACE: retry click on the list → bumps reloadKey.
  //        error banner visible → refetch → error cleared.
  const retryList = useCallback(() => setReloadKey((k) => k + 1), []);
  // TRACE: retry click on the picker → bumps tripsKey.
  //        picker error visible → refetch → error cleared.
  const retryTrips = useCallback(() => setTripsKey((k) => k + 1), []);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <Link to="/dashboard" className={`text-sm font-medium text-brand-700 hover:underline ${FOCUS}`}>
        ← Dashboard
      </Link>
      <h1 className="mt-2 text-2xl font-bold text-ink-900 sm:text-3xl">Support</h1>

      <div className="mt-6 grid gap-8 lg:grid-cols-2">
        <section aria-labelledby="raise-heading" className={`${DATA_CARD_CLASS} p-5`}>
          <h2 id="raise-heading" className="mb-4 text-lg font-semibold text-ink-900">
            Raise an issue
          </h2>
          <ComplaintForm
            trips={trips}
            tripsLoading={tripsLoading}
            tripsError={tripsError}
            onRetryTrips={retryTrips}
            onSubmitted={retryList}
          />
        </section>

        <section aria-labelledby="complaints-heading">
          <h2 id="complaints-heading" className="mb-4 text-lg font-semibold text-ink-900">
            Your complaints
          </h2>
          {loading && (
            <div className="space-y-3" aria-busy="true" aria-label="Loading your complaints">
              {SKELETON_IDS.map((sid) => (
                <Skeleton key={sid} className="h-24 w-full rounded-xl" />
              ))}
            </div>
          )}
          {!loading && error && <ErrorBanner message={error} onRetry={retryList} />}
          {!loading && !error && complaints && complaints.length === 0 && (
            <EmptyState title="No complaints" description="Anything you raise will be tracked here until it is resolved." />
          )}
          {!loading && !error && complaints && complaints.length > 0 && (
            <ul className="space-y-3">
              {complaints.map((c) => (
                <ComplaintCard key={c.complaint_id} c={c} />
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
