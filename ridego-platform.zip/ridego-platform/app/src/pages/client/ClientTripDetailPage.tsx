import RideMoneyCard from '../../components/RideMoneyCard';
import { useCallback, useEffect, useId, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  attentionLabel,
  cancelClientTrip,
  errorMessage,
  formatDate,
  formatMoney,
  formatTime,
  getClientInvoice,
  getClientTrip,
  humanize,
  rateClientTrip,
  statusClasses,
  type ClientInvoice,
  type ClientTripDetail,
  type TimelineStep,
  type TripComplaintSummary,
} from '../../lib/api-client-dashboard';
import { useToast } from '../../context/ToastContext';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { ComplaintForm } from './ClientSupportPage';
import { brand } from '../../lib/brand';

const FOCUS = 'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600';
const FIELD = `mt-1 block w-full rounded-lg border border-ink-300 bg-white px-3 py-2 text-sm text-ink-900 ${FOCUS}`;
const CARD = 'rounded-lg bg-white p-5 shadow-xs ring-1 ring-inset ring-ink-100 print:hidden print:ring-0 print:shadow-none';
const SKELETON_IDS = ['sk-a', 'sk-b', 'sk-c'];
const STARS = [1, 2, 3, 4, 5];

// TRACE: mount → creates a ref that is true while the component is mounted.
//        none → ref flips false on unmount → lets async handlers skip state writes after unmount.
function useMounted() {
  const mounted = useRef(true);
  // TRACE: mount/unmount → sets/clears the flag.
  //        none → flag accurate at all times → cleanup runs once on unmount.
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  return mounted;
}

// TRACE: star number + selection state → one star button.
//        n/selected/onPick → calls onPick(n) on click → exposes pressed state and a spoken label.
function StarButton({ n, selected, disabled, onPick }: { n: number; selected: boolean; disabled: boolean; onPick: (n: number) => void }) {
  // TRACE: click → onPick(n).
  //        not disabled → parent stores the score → none.
  const handleClick = () => onPick(n);
  return (
    <button
      type="button"
      aria-label={`${n} ${n === 1 ? 'star' : 'stars'}`}
      aria-pressed={selected}
      disabled={disabled}
      onClick={handleClick}
      className={`rounded p-0.5 ${FOCUS}`}
    >
      <svg className={`h-7 w-7 ${selected ? 'text-warning-500' : 'text-ink-300'}`} viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.957a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.367 2.447a1 1 0 00-.364 1.118l1.287 3.957c.3.922-.755 1.688-1.538 1.118l-3.367-2.447a1 1 0 00-1.176 0l-3.367 2.447c-.783.57-1.838-.196-1.538-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.063 9.384c-.783-.57-.38-1.81.588-1.81h4.163a1 1 0 00.95-.69l1.286-3.957z" />
      </svg>
    </button>
  );
}

// TRACE: category + value → labelled five-star input.
//        category/value/onChange → calls onChange(category, score) → shows filled stars up to the value.
function StarInput({ category, value, disabled, onChange }: { category: string; value: number; disabled: boolean; onChange: (category: string, score: number) => void }) {
  // TRACE: star pick → onChange(category, n).
  //        score 1-5 → parent state updated → none.
  const handlePick = (n: number) => onChange(category, n);
  return (
    <div className="flex flex-wrap items-center justify-between gap-2">
      <span id={`rate-${category}`} className="text-sm text-ink-800">
        {humanize(category)}
      </span>
      <div role="group" aria-labelledby={`rate-${category}`} className="flex items-center">
        {STARS.map((n) => (
          <StarButton key={n} n={n} selected={n <= value} disabled={disabled} onPick={handlePick} />
        ))}
      </div>
    </div>
  );
}

// TRACE: timeline steps → vertical stepper.
//        steps array → done steps marked with a check, pending steps hollow → cancelled step in danger colour,
//        missing timestamp omitted.
function Timeline({ steps }: { steps: TimelineStep[] }) {
  return (
    <ol className="space-y-4" aria-label="Trip progress">
      {steps.map((s) => (
        <li key={s.key} className="flex items-start gap-3">
          <span
            aria-hidden="true"
            className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 text-xs font-bold ${
              s.done ? (s.key === 'cancelled' ? 'border-danger-600 bg-danger-600 text-white' : 'border-brand-600 bg-brand-600 text-white') : 'border-ink-300 bg-white text-transparent'
            }`}
          >
            ✓
          </span>
          <div>
            <p className={`text-sm font-medium ${s.done ? 'text-ink-900' : 'text-ink-600'}`}>
              {s.label}
              <span className="sr-only">{s.done ? ' (done)' : ' (not yet)'}</span>
            </p>
            {s.at && <p className="text-xs text-ink-600">{formatDate(s.at)}</p>}
          </div>
        </li>
      ))}
    </ol>
  );
}

// TRACE: trip detail + callbacks → rating form for a completed, unrated trip.
//        vendor/driver categories from the API → POST rate → toast 'Thanks for rating' and parent refetch →
//        requires at least one star, blocks double submit, shows server error inline and as toast.
function RatingForm({ trip, onRated }: { trip: ClientTripDetail; onRated: () => void }) {
  const toast = useToast();
  const uid = useId();
  const mounted = useMounted();
  const [vendor, setVendor] = useState<Record<string, number>>({});
  const [driver, setDriver] = useState<Record<string, number>>({});
  const [review, setReview] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // TRACE: vendor star change → stores the score for that category.
  //        category + score → state merged → clears stale error.
  const handleVendor = (category: string, score: number) => {
    setVendor((prev) => ({ ...prev, [category]: score }));
    setFormError(null);
  };
  // TRACE: driver star change → stores the score for that category.
  //        category + score → state merged → clears stale error.
  const handleDriver = (category: string, score: number) => {
    setDriver((prev) => ({ ...prev, [category]: score }));
    setFormError(null);
  };
  // TRACE: review textarea change → stores the text.
  //        text → state updated → none.
  const handleReview = (e: ChangeEvent<HTMLTextAreaElement>) => setReview(e.target.value);

  // TRACE: submit → validates then POSTs the rating.
  //        not already submitting → success toast + onRated() → no stars chosen rejected inline, server error
  //        shown inline and as toast, no writes after unmount.
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    if (Object.keys(vendor).length + Object.keys(driver).length === 0) {
      setFormError('Choose at least one star rating.');
      return;
    }
    setSubmitting(true);
    setFormError(null);
    try {
      await rateClientTrip(trip.id, { vendor, driver, review: review.trim() });
      toast.show('Thanks for rating', 'success');
      onRated();
    } catch (err) {
      const msg = errorMessage(err, 'Could not submit your rating. Please try again.');
      toast.show(msg, 'error');
      if (mounted.current) setFormError(msg);
    } finally {
      if (mounted.current) setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5" noValidate>
      <fieldset className="space-y-2">
        <legend className="text-sm font-semibold text-ink-900">Rate the service</legend>
        {trip.rating_categories.vendor.map((c) => (
          <StarInput key={c} category={c} value={vendor[c] ?? 0} disabled={submitting} onChange={handleVendor} />
        ))}
      </fieldset>
      <fieldset className="space-y-2">
        <legend className="text-sm font-semibold text-ink-900">Rate the driver</legend>
        {trip.rating_categories.driver.map((c) => (
          <StarInput key={c} category={c} value={driver[c] ?? 0} disabled={submitting} onChange={handleDriver} />
        ))}
      </fieldset>
      <div>
        <label htmlFor={`${uid}-review`} className="text-sm font-medium text-ink-800">
          Review (optional)
        </label>
        <textarea id={`${uid}-review`} value={review} onChange={handleReview} rows={3} maxLength={1000} className={FIELD} disabled={submitting} />
      </div>
      {formError && (
        <p role="alert" className="text-sm text-danger-600">
          {formError}
        </p>
      )}
      <Button type="submit" loading={submitting}>
        {submitting ? 'Submitting…' : 'Submit rating'}
      </Button>
    </form>
  );
}

// TRACE: complaint summary → list row.
//        complaint → id, category, status, date → none.
function ComplaintRow({ c }: { c: TripComplaintSummary }) {
  return (
    <li className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-ink-50 p-3 text-sm">
      <span className="font-medium text-ink-900">
        {humanize(c.category)} · {c.complaint_id}
      </span>
      <span className="text-ink-700">
        {humanize(c.status)} · {formatDate(c.created_at)}
      </span>
    </li>
  );
}

// TRACE: receipt JSON (booking_receipt from the server) → printable BOOKING RECEIPT layout: booking amount received by RideGo only, then a separate
//        "ride fare" block clearly marked as estimated and billed by the vendor/driver, then the disclaimer.
//        Preconditions: ClientInvoice from GET invoice → Postconditions: pure render, zero-value lines hidden, refunds shown negative
//        → Edge cases: no vendor yet (ride block omits phone), no disclaimer (not rendered), legacy booking without ride block (ride section omitted).
function InvoiceView({ invoice }: { invoice: ClientInvoice }) {
  const lines = invoice.lines.filter((l) => l.amount !== 0);
  const est = (invoice.estimate_lines ?? []).filter((l) => l.amount !== 0);
  const ride = invoice.ride;
  return (
    <div className="rounded-lg border border-ink-200 bg-white p-5 text-sm text-ink-800 print:border-0 print:p-0">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="text-lg font-bold text-ink-900">Booking receipt {invoice.receipt_number ?? invoice.invoice_number}</p>
          <p className="text-ink-600">Issued {formatDate(invoice.issued_on)}</p>
        </div>
        <div className="text-right">
          <p>Booking {invoice.booking_number}</p>
          <p>{invoice.client_name}</p>
        </div>
      </div>
      <p className="mt-4">
        {invoice.route} · {formatDate(invoice.journey_date)}
      </p>
      <table className="mt-4 w-full text-left">
        <caption className="sr-only">Booking amount received by {brand().name}</caption>
        <thead>
          <tr className="border-b border-ink-200 text-ink-600">
            <th scope="col" className="py-2 font-medium">
              Collected by {brand().name}
            </th>
            <th scope="col" className="py-2 text-right font-medium">
              Amount
            </th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l) => (
            <tr key={l.label} className="border-b border-ink-100">
              <td className="py-2">{l.label}</td>
              <td className="py-2 text-right">{l.amount < 0 ? `-${formatMoney(Math.abs(l.amount))}` : formatMoney(l.amount)}</td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <th scope="row" className="pt-3 font-semibold">
              Net booking amount received
            </th>
            <td className="pt-3 text-right font-semibold">{formatMoney(invoice.total)}</td>
          </tr>
        </tfoot>
      </table>
      {ride && (
        <div className="mt-5 rounded-lg bg-ink-50 p-4">
          <p className="font-semibold text-ink-900">Ride fare — billed and collected by your vendor/driver</p>
          {est.length > 0 && (
            <ul className="mt-2 space-y-1 text-ink-700">
              {est.map((l) => (
                <li key={l.label} className="flex justify-between gap-3">
                  <span>{l.label}</span>
                  <span>{l.amount < 0 ? `-${formatMoney(Math.abs(l.amount))}` : formatMoney(l.amount)}</span>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-2 flex justify-between font-semibold text-ink-900">
            <span>Estimated ride fare</span>
            <span>{formatMoney(invoice.estimated_ride_fare ?? 0)}</span>
          </p>
          <p className="mt-1 flex justify-between text-ink-700">
            <span>Payable directly to {ride.vendor_name || 'your vendor/driver'}</span>
            <span>{formatMoney(ride.payable_to_vendor)}</span>
          </p>
          {ride.vendor_invoice_number && <p className="mt-1 text-xs text-ink-600">Vendor invoice {ride.vendor_invoice_number}</p>}
        </div>
      )}
      {invoice.disclaimer && <p className="mt-4 text-xs leading-relaxed text-ink-600">{invoice.disclaimer}</p>}
    </div>
  );
}

// TRACE: route /app/dashboard/trips/:id → loads trip detail → stepper, route, assignment, fare, cancel, rating,
//        issues, invoice.
//        own trip id → full detail → invalid id or 404 shows an error with retry, loading skeleton, stale
//        responses ignored, every mutation re-fetches server state, invoice loads on demand and prints via
//        window.print(), cancel/rating/issue/invoice each block double submit and report errors.
export function ClientTripDetailPage() {
  const params = useParams();
  const id = Number(params.id);
  const validId = Number.isInteger(id) && id > 0;
  const toast = useToast();
  const mounted = useMounted();

  const [data, setData] = useState<ClientTripDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const requestId = useRef(0);

  const [cancelOpen, setCancelOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelling, setCancelling] = useState(false);

  const [invoice, setInvoice] = useState<ClientInvoice | null>(null);
  const [invoiceLoading, setInvoiceLoading] = useState(false);
  const [invoiceError, setInvoiceError] = useState<string | null>(null);
  const invoiceReq = useRef(0);

  // TRACE: id/reloadKey change → fetches the trip → data or error.
  //        valid id, latest request → state committed → invalid id short-circuits with a message, stale and
  //        unmounted responses ignored.
  useEffect(() => {
    const rid = ++requestId.current;
    if (!validId) {
      setLoading(false);
      setError('Trip not found.');
      return;
    }
    // TRACE: effect start → awaits API → commits if current.
    //        rid matches → loading cleared → failure becomes readable message.
    async function run() {
      setLoading(true);
      setError(null);
      try {
        const res = await getClientTrip(id);
        if (rid !== requestId.current) return;
        setData(res);
      } catch (err) {
        if (rid !== requestId.current) return;
        setError(errorMessage(err, 'Could not load this trip. Please try again.'));
      } finally {
        if (rid === requestId.current) setLoading(false);
      }
    }
    void run();
    return () => {
      requestId.current += 1;
    };
  }, [id, validId, reloadKey]);

  // TRACE: id change → clears any invoice from the previous trip and invalidates its request.
  //        new id → invoice state reset → in-flight invoice response ignored.
  useEffect(() => {
    invoiceReq.current += 1;
    setInvoice(null);
    setInvoiceError(null);
    setInvoiceLoading(false);
  }, [id]);

  // TRACE: retry or post-mutation refresh → bumps reloadKey.
  //        any state → fresh server fetch → used by the banner, rating and issue forms.
  const reload = useCallback(() => setReloadKey((k) => k + 1), []);

  // TRACE: cancel button click → opens the confirm dialog.
  //        can_cancel true → dialog open → nothing is sent yet.
  const openCancel = useCallback(() => setCancelOpen(true), []);
  // TRACE: dialog dismiss → closes it and clears the reason.
  //        not cancelling → dialog closed → ignored while the request is in flight.
  const closeCancel = useCallback(() => {
    if (cancelling) return;
    setCancelOpen(false);
    setCancelReason('');
  }, [cancelling]);
  // TRACE: reason textarea change → stores the reason.
  //        text → state updated → none.
  const handleReason = (e: ChangeEvent<HTMLTextAreaElement>) => setCancelReason(e.target.value);

  // TRACE: dialog confirm → POST /bookings/:id/cancel → toast + refetch.
  //        trip loaded, not already cancelling → cancelled and dialog closed → server refusal shown as toast and
  //        dialog kept open, detail re-fetched only on success.
  const confirmCancel = async () => {
    if (!data || cancelling) return;
    setCancelling(true);
    try {
      await cancelClientTrip(data.id, cancelReason.trim() || 'Cancelled by client');
      toast.show(`Booking ${data.booking_number} cancelled.`, 'success');
      if (mounted.current) {
        setCancelOpen(false);
        setCancelReason('');
      }
      reload();
    } catch (err) {
      toast.show(errorMessage(err, 'Could not cancel this booking. Please try again.'), 'error');
    } finally {
      if (mounted.current) setCancelling(false);
    }
  };

  // TRACE: 'View invoice' click → GET invoice → renders it.
  //        valid id, not already loading → invoice stored → 400 (payment pending) and other errors shown inline
  //        and as toast, stale response for a previous trip ignored.
  const loadInvoice = async () => {
    if (!validId || invoiceLoading) return;
    const rid = ++invoiceReq.current;
    setInvoiceLoading(true);
    setInvoiceError(null);
    try {
      const res = await getClientInvoice(id);
      if (rid !== invoiceReq.current) return;
      setInvoice(res);
    } catch (err) {
      if (rid !== invoiceReq.current) return;
      const msg = errorMessage(err, 'Could not load the receipt. Please try again.');
      setInvoiceError(msg);
      toast.show(msg, 'error');
    } finally {
      if (rid === invoiceReq.current) setInvoiceLoading(false);
    }
  };

  // TRACE: 'Print invoice' click → opens the browser print dialog.
  //        invoice shown → printable layout printed (other cards are print:hidden) → none.
  const printInvoice = () => window.print();

  const trip = data && data.id === id ? data : null;
  const time = trip ? formatTime(trip.journey_time) : '';
  const showRating = trip !== null && trip.status === 'completed' && !trip.rating_state.client_rated && trip.rating === null;
  const rated = trip !== null && trip.status === 'completed' && (trip.rating_state.client_rated || trip.rating !== null);

  return (
    <div className="min-h-full bg-ink-50 print:bg-white">
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <Link to="/dashboard/trips" className={`text-sm font-medium text-brand-700 hover:underline print:hidden ${FOCUS}`}>
        ← My trips
      </Link>

      {loading && !trip && (
        <div className="mt-6 space-y-4" aria-busy="true" aria-label="Loading trip">
          {SKELETON_IDS.map((sid) => (
            <Skeleton key={sid} className="h-32 w-full rounded-xl" />
          ))}
        </div>
      )}

      {error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={validId ? reload : undefined} />
        </div>
      )}

      {trip && (
        <div className="mt-4 space-y-5">
          <header className="print:hidden">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">
                {trip.pickup_city} → {trip.drop_city}
              </h1>
              <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${statusClasses(trip.group)}`}>{trip.status_label}</span>
            </div>
            <p className="mt-1 text-sm text-ink-600">
              {trip.booking_number} · {formatDate(trip.journey_date)}
              {time ? ` at ${time}` : ''}
            </p>
            {trip.attention.length > 0 && (
              <ul className="mt-3 space-y-1" aria-label="Needs your attention">
                {trip.attention.map((a) => (
                  <li key={a.code} className="rounded-lg bg-warning-50 px-3 py-2 text-sm text-warning-600">
                    <strong>{attentionLabel(a.code)}:</strong> {a.message}
                  </li>
                ))}
              </ul>
            )}
          </header>

          <section className={CARD} aria-labelledby="progress-heading">
            <h2 id="progress-heading" className="mb-4 text-lg font-semibold text-ink-900">
              Progress
            </h2>
            <Timeline steps={trip.timeline} />
          </section>

          <section className={CARD} aria-labelledby="route-heading">
            <h2 id="route-heading" className="mb-3 text-lg font-semibold text-ink-900">
              Route
            </h2>
            <dl className="grid gap-3 text-sm sm:grid-cols-2">
              <div>
                <dt className="text-ink-600">Pickup</dt>
                <dd className="font-medium text-ink-900">{trip.pickup_address || trip.pickup_city}</dd>
              </div>
              <div>
                <dt className="text-ink-600">Drop</dt>
                <dd className="font-medium text-ink-900">{trip.drop_address || trip.drop_city}</dd>
              </div>
              <div>
                <dt className="text-ink-600">Passengers</dt>
                <dd className="font-medium text-ink-900">{trip.passengers}</dd>
              </div>
              <div>
                <dt className="text-ink-600">Trip type</dt>
                <dd className="font-medium text-ink-900">{humanize(trip.trip_type)}</dd>
              </div>
              {trip.special_requests && (
                <div className="sm:col-span-2">
                  <dt className="text-ink-600">Special requests</dt>
                  <dd className="font-medium text-ink-900">{trip.special_requests}</dd>
                </div>
              )}
            </dl>
          </section>

          <section className={CARD} aria-labelledby="driver-heading">
            <h2 id="driver-heading" className="mb-3 text-lg font-semibold text-ink-900">
              Driver and vehicle
            </h2>
            {trip.assignment ? (
              <dl className="grid gap-3 text-sm sm:grid-cols-2">
                <div>
                  <dt className="text-ink-600">Driver</dt>
                  <dd className="font-medium text-ink-900">{trip.assignment.driver_name}</dd>
                </div>
                {trip.assignment.driver_phone && (
                  <div>
                    <dt className="text-ink-600">Driver phone</dt>
                    <dd className="font-medium">
                      <a href={`tel:${trip.assignment.driver_phone}`} className={`text-brand-700 underline ${FOCUS}`}>
                        {trip.assignment.driver_phone}
                      </a>
                    </dd>
                  </div>
                )}
                <div>
                  <dt className="text-ink-600">Vehicle</dt>
                  <dd className="font-medium text-ink-900">{trip.assignment.vehicle_model || 'To be confirmed'}</dd>
                </div>
                <div>
                  <dt className="text-ink-600">Registration</dt>
                  <dd className="font-medium text-ink-900">{trip.assignment.vehicle_registration}</dd>
                </div>
              </dl>
            ) : (
              <p className="text-sm text-ink-600">A driver has not been assigned yet. You will see the details here once they are.</p>
            )}
            {trip.vendor_name && (
              <p className="mt-3 text-sm text-ink-700">
                Operator: <strong className="text-ink-900">{trip.vendor_name}</strong>
              </p>
            )}
            {trip.otp && (
              <p className="mt-4 rounded-lg bg-brand-50 p-3 text-sm text-ink-800">
                Pickup OTP: <strong className="text-lg tracking-widest text-brand-700">{trip.otp}</strong>
                <span className="block text-ink-600">Share this with your driver when they arrive.</span>
              </p>
            )}
          </section>

          <section className={CARD} aria-labelledby="fare-heading">
            <h2 id="fare-heading" className="mb-3 text-lg font-semibold text-ink-900">
              Payment summary
            </h2>
            <RideMoneyCard money={trip} audience="client" notice={trip.platform_notice}>
              {trip.vendor_phone && (
                <p className="mt-3 text-sm text-ink-700">
                  Pay the remaining amount directly to your vendor/driver. Contact: <a className="font-medium text-brand-700 underline" href={`tel:${trip.vendor_phone}`}>{trip.vendor_phone}</a>
                </p>
              )}
            </RideMoneyCard>
            {trip.can_cancel && (
              <div className="mt-5">
                <Button variant="danger" onClick={openCancel} loading={cancelling}>
                  Cancel booking
                </Button>
              </div>
            )}
          </section>

          {showRating && (
            <section className={CARD} aria-labelledby="rate-heading">
              <h2 id="rate-heading" className="mb-4 text-lg font-semibold text-ink-900">
                How was your trip?
              </h2>
              <RatingForm trip={trip} onRated={reload} />
            </section>
          )}
          {rated && (
            <section className="rounded-2xl bg-brand-50 p-5 ring-1 ring-brand-100 print:hidden" aria-labelledby="rated-heading">
              <h2 id="rated-heading" className="text-lg font-semibold text-ink-900">
                Thanks for rating
              </h2>
              <p className="mt-1 text-sm text-ink-600">Your feedback helps us keep trips safe and reliable.</p>
            </section>
          )}

          <section className={CARD} aria-labelledby="issue-heading">
            <h2 id="issue-heading" className="mb-4 text-lg font-semibold text-ink-900">
              Raise an issue
            </h2>
            <ComplaintForm fixedBookingId={trip.id} onSubmitted={reload} />
            <h3 className="mb-2 mt-6 text-sm font-semibold text-ink-900">Issues raised for this trip</h3>
            {trip.complaints.length === 0 ? (
              <p className="text-sm text-ink-600">No issues raised for this trip.</p>
            ) : (
              <ul className="space-y-2">
                {trip.complaints.map((c) => (
                  <ComplaintRow key={c.complaint_id} c={c} />
                ))}
              </ul>
            )}
          </section>

          <section className="rounded-lg bg-white p-5 shadow-xs ring-1 ring-inset ring-ink-100 print:ring-0 print:shadow-none" aria-labelledby="invoice-heading">
            <div className="flex flex-wrap items-center justify-between gap-2 print:hidden">
              <h2 id="invoice-heading" className="text-lg font-semibold text-ink-900">
                Booking receipt
              </h2>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" onClick={loadInvoice} loading={invoiceLoading}>
                  {invoice ? 'Refresh receipt' : 'View receipt'}
                </Button>
                {invoice && (
                  <Button size="sm" onClick={printInvoice}>
                    Print receipt
                  </Button>
                )}
              </div>
            </div>
            {invoiceLoading && !invoice && <Skeleton className="mt-4 h-40 w-full" />}
            {invoiceError && (
              <div className="mt-4 print:hidden">
                <ErrorBanner message={invoiceError} onRetry={loadInvoice} />
              </div>
            )}
            {invoice && (
              <div className="mt-4">
                <InvoiceView invoice={invoice} />
              </div>
            )}
            {!invoice && !invoiceLoading && !invoiceError && (
              <p className="mt-3 text-sm text-ink-600 print:hidden">Open your booking receipt for the booking amount you paid {brand().name}. The ride invoice is issued by your vendor/driver.</p>
            )}
          </section>
        </div>
      )}

      <ConfirmDialog
        open={cancelOpen}
        title={trip ? `Cancel booking ${trip.booking_number}?` : 'Cancel booking?'}
        description={`This cannot be undone. Only the booking amount you paid ${brand().name} can be refunded, as per the cancellation policy. Anything you agreed to pay your vendor/driver directly is settled with them.`}
        confirmLabel="Cancel booking"
        cancelLabel="Keep booking"
        confirmVariant="danger"
        loading={cancelling}
        onConfirm={confirmCancel}
        onCancel={closeCancel}
      >
        <label htmlFor="cancel-reason" className="text-sm font-medium text-ink-800">
          Reason (optional)
        </label>
        <textarea id="cancel-reason" value={cancelReason} onChange={handleReason} rows={3} maxLength={300} className={FIELD} disabled={cancelling} />
      </ConfirmDialog>
    </div>
    </div>
  );
}
