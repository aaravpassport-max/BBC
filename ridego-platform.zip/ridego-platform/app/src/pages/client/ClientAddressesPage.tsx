import { useCallback, useEffect, useId, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import {
  deleteClientAddress,
  errorMessage,
  getClientAddresses,
  saveClientAddress,
  type ClientAddress,
} from '../../lib/api-client-dashboard';
import { useToast } from '../../context/ToastContext';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { DataCard, DATA_CARD_CLASS } from '../../components/ui/Zone';

const FOCUS = 'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600';
const FIELD = `mt-1 block w-full rounded-lg border border-ink-300 bg-white px-3 py-2 text-sm text-ink-900 ${FOCUS}`;
const SKELETON_IDS = ['sk-a', 'sk-b', 'sk-c'];

// TRACE: route /app/dashboard/addresses → loads saved addresses → list, add form, delete confirm.
//        logged-in client → list rendered → loading/empty/error states, stale responses ignored, double submit and
//        double delete blocked, server errors (limit of 10, blank input) shown as toasts, list re-fetched after
//        every mutation.
export function ClientAddressesPage() {
  const toast = useToast();
  const uid = useId();
  const [rows, setRows] = useState<ClientAddress[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const requestId = useRef(0);
  const mounted = useRef(true);

  const [label, setLabel] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [toDelete, setToDelete] = useState<ClientAddress | null>(null);
  const [deleting, setDeleting] = useState(false);

  // TRACE: mount → sets mounted flag; unmount → clears it.
  //        none → guards post-await state writes → avoids updates after unmount.
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  // TRACE: mount/reload → fetches addresses → rows or error.
  //        latest request wins → state committed → stale/unmounted responses ignored.
  useEffect(() => {
    const id = ++requestId.current;
    // TRACE: effect start → awaits API → commits if current.
    //        id matches → loading cleared → failure becomes readable message.
    async function run() {
      setLoading(true);
      setError(null);
      try {
        const res = await getClientAddresses();
        if (id !== requestId.current) return;
        setRows(res.rows);
      } catch (err) {
        if (id !== requestId.current) return;
        setError(errorMessage(err, 'Could not load your saved addresses. Please try again.'));
      } finally {
        if (id === requestId.current) setLoading(false);
      }
    }
    void run();
    return () => {
      requestId.current += 1;
    };
  }, [reloadKey]);

  // TRACE: retry/refresh → bumps reloadKey.
  //        any state → fresh server fetch → used after every mutation and by the error banner.
  const reload = useCallback(() => setReloadKey((k) => k + 1), []);

  // TRACE: label input change → stores label.
  //        text → state → clears stale form error.
  const handleLabel = (e: ChangeEvent<HTMLInputElement>) => {
    setLabel(e.target.value);
    setFormError(null);
  };
  // TRACE: address input change → stores address.
  //        text → state → clears stale form error.
  const handleAddress = (e: ChangeEvent<HTMLInputElement>) => {
    setAddress(e.target.value);
    setFormError(null);
  };
  // TRACE: city input change → stores city.
  //        text → state → clears stale form error.
  const handleCity = (e: ChangeEvent<HTMLInputElement>) => {
    setCity(e.target.value);
    setFormError(null);
  };

  // TRACE: add-form submit → validates → POST /client/addresses → toast + refetch.
  //        not already saving → address saved and form cleared → blank label/address rejected inline, server
  //        errors (10-address limit) shown as toast and inline, no state writes after unmount.
  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    if (label.trim() === '' || address.trim() === '') {
      setFormError('Give the address a name and enter the address itself.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      await saveClientAddress({ label: label.trim(), address: address.trim(), city: city.trim() });
      toast.show('Address saved.', 'success');
      if (mounted.current) {
        setLabel('');
        setAddress('');
        setCity('');
      }
      reload();
    } catch (err) {
      const msg = errorMessage(err, 'Could not save the address. Please try again.');
      toast.show(msg, 'error');
      if (mounted.current) setFormError(msg);
    } finally {
      if (mounted.current) setSaving(false);
    }
  };

  // TRACE: dialog cancel → closes the delete dialog.
  //        not deleting → dialog closed → ignored while a delete is in flight.
  const cancelDelete = useCallback(() => {
    if (!deleting) setToDelete(null);
  }, [deleting]);

  // TRACE: dialog confirm → DELETE /client/addresses/:id → toast + refetch.
  //        address selected and not already deleting → removed → server errors (404) toast, dialog closes either way.
  const confirmDelete = async () => {
    if (!toDelete || deleting) return;
    setDeleting(true);
    try {
      await deleteClientAddress(toDelete.id);
      toast.show(`"${toDelete.label}" deleted.`, 'success');
    } catch (err) {
      toast.show(errorMessage(err, 'Could not delete the address. Please try again.'), 'error');
    } finally {
      if (mounted.current) {
        setDeleting(false);
        setToDelete(null);
      }
      reload();
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <Link to="/dashboard" className={`text-sm font-medium text-brand-700 hover:underline ${FOCUS}`}>
        ← Dashboard
      </Link>
      <h1 className="mt-2 text-2xl font-bold text-ink-900 sm:text-3xl">Saved addresses</h1>
      <p className="mt-1 text-sm text-ink-600">Save up to 10 places you travel from or to often.</p>

      <div className="mt-6 grid gap-8 lg:grid-cols-2">
        <section aria-labelledby="add-heading" className={`${DATA_CARD_CLASS} p-5`}>
          <h2 id="add-heading" className="mb-4 text-lg font-semibold text-ink-900">
            Add an address
          </h2>
          <form onSubmit={handleSave} className="space-y-4" noValidate>
            <div>
              <label htmlFor={`${uid}-label`} className="text-sm font-medium text-ink-800">
                Label
              </label>
              <input id={`${uid}-label`} type="text" value={label} onChange={handleLabel} maxLength={60} placeholder="Home" className={FIELD} disabled={saving} />
            </div>
            <div>
              <label htmlFor={`${uid}-address`} className="text-sm font-medium text-ink-800">
                Address
              </label>
              <input id={`${uid}-address`} type="text" value={address} onChange={handleAddress} maxLength={200} className={FIELD} disabled={saving} />
            </div>
            <div>
              <label htmlFor={`${uid}-city`} className="text-sm font-medium text-ink-800">
                City
              </label>
              <input id={`${uid}-city`} type="text" value={city} onChange={handleCity} maxLength={80} className={FIELD} disabled={saving} />
            </div>
            {formError && (
              <p role="alert" className="text-sm text-danger-600">
                {formError}
              </p>
            )}
            <Button type="submit" loading={saving}>
              {saving ? 'Saving…' : 'Save address'}
            </Button>
          </form>
        </section>

        <section aria-labelledby="list-heading">
          <h2 id="list-heading" className="mb-4 text-lg font-semibold text-ink-900">
            Your addresses
          </h2>
          {loading && (
            <div className="space-y-3" aria-busy="true" aria-label="Loading saved addresses">
              {SKELETON_IDS.map((sid) => (
                <Skeleton key={sid} className="h-20 w-full rounded-xl" />
              ))}
            </div>
          )}
          {!loading && error && <ErrorBanner message={error} onRetry={reload} />}
          {!loading && !error && rows && rows.length === 0 && (
            <EmptyState title="No saved addresses" description="Add one using the form and it will be listed here." />
          )}
          {!loading && !error && rows && rows.length > 0 && (
            <ul className="space-y-3">
              {rows.map((a) => (
                <AddressCard key={a.id} address={a} onDelete={setToDelete} />
              ))}
            </ul>
          )}
        </section>
      </div>

      <ConfirmDialog
        open={toDelete !== null}
        title="Delete this address?"
        description={toDelete ? `"${toDelete.label}" will be removed from your saved addresses.` : undefined}
        confirmLabel="Delete"
        confirmVariant="danger"
        loading={deleting}
        onConfirm={confirmDelete}
        onCancel={cancelDelete}
      />
    </div>
  );
}

// TRACE: address → card with a delete button.
//        address + onDelete → shows label/address/city → delete click passes the address up for confirmation.
function AddressCard({ address, onDelete }: { address: ClientAddress; onDelete: (a: ClientAddress) => void }) {
  // TRACE: delete click → onDelete(address).
  //        none → parent opens the confirm dialog → no request is made here.
  const handleDelete = () => onDelete(address);
  return (
    <li>
      <DataCard className="flex items-start justify-between gap-3 p-4">
        <div className="min-w-0">
          <p className="text-sm font-semibold text-ink-900">{address.label}</p>
          <p className="mt-0.5 break-words text-sm text-ink-700">{address.address}</p>
          {address.city && <p className="text-sm text-ink-600">{address.city}</p>}
        </div>
        <Button variant="secondary" size="sm" onClick={handleDelete} aria-label={`Delete address ${address.label}`}>
          Delete
        </Button>
      </DataCard>
    </li>
  );
}
