import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  TRIP_TABS,
  attentionLabel,
  errorMessage,
  formatDate,
  formatMoney,
  formatTime,
  getClientTrips,
  statusClasses,
  type AttentionItem,
  type ClientTrip,
  type ClientTripsResponse,
  type TripTab,
} from '../../lib/api-client-dashboard';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { DATA_CARD_CLASS } from '../../components/ui/Zone';

const SKELETON_IDS = ['sk-a', 'sk-b', 'sk-c', 'sk-d'];

const EMPTY_COPY: Record<TripTab, { title: string; description: string }> = {
  upcoming: { title: 'No upcoming trips', description: 'Trips you have booked and that have not started yet appear here.' },
  ongoing: { title: 'No trip in progress', description: 'When your driver is on the way or your trip has started, it shows up here.' },
  completed: { title: 'No completed trips yet', description: 'Once you finish a trip, you can rate it and see your booking receipt here.' },
  cancelled: { title: 'No cancelled trips', description: 'Cancelled bookings and refunds due appear here.' },
};

// TRACE: raw ?tab= value → narrows to a known tab key.
//        any string or null → valid TripTab → unknown or missing value falls back to 'upcoming'.
function parseTab(raw: string | null): TripTab {
  return TRIP_TABS.some((t) => t.key === raw) ? (raw as TripTab) : 'upcoming';
}

// TRACE: attention items → row of small badges (one per item).
//        items array → badges keyed by code → renders nothing when empty.
export function AttentionBadges({ items }: { items: AttentionItem[] }) {
  if (items.length === 0) return null;
  return (
    <ul className="mt-3 flex flex-wrap gap-2" aria-label="Needs your attention">
      {items.map((a) => (
        <li key={a.code} className="rounded-full bg-warning-50 px-2.5 py-0.5 text-xs font-medium text-warning-600">
          {attentionLabel(a.code)}
        </li>
      ))}
    </ul>
  );
}

// TRACE: trip summary → clickable card linking to the trip detail.
//        trip row → route/date/status/fare/balance/badges → zero balance hides the balance line, missing time is omitted.
export function TripCard({ trip }: { trip: ClientTrip }) {
  const time = formatTime(trip.journey_time);
  return (
    <li>
      <Link
        to={`/app/dashboard/trips/${trip.id}`}
        className={`block ${DATA_CARD_CLASS} p-4 transition hover:border-brand-300 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 sm:p-5`}
      >
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="min-w-0">
            <p className="text-base font-semibold text-ink-900">
              {trip.pickup_city} → {trip.drop_city}
            </p>
            <p className="mt-0.5 text-sm text-ink-600">
              {formatDate(trip.journey_date)}
              {time ? ` at ${time}` : ''} · {trip.booking_number}
            </p>
          </div>
          <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${statusClasses(trip.group)}`}>{trip.status_label}</span>
        </div>
        <div className="mt-3 flex flex-wrap gap-x-6 gap-y-1 text-sm text-ink-700">
          <span>
            Est. fare <strong className="text-ink-900">{formatMoney(trip.total_fare)}</strong>
          </span>
          {trip.balance_due > 0 && (
            <span>
              Pay vendor/driver <strong className="text-ink-900">{formatMoney(trip.balance_due)}</strong>
            </span>
          )}
        </div>
        <AttentionBadges items={trip.attention} />
      </Link>
    </li>
  );
}

// TRACE: route /app/dashboard/trips?tab= → loads the tab's page of trips → tabs, list, pager.
//        logged-in client → list rendered → loading skeleton, empty state per tab, error banner with retry,
//        stale/overlapping responses ignored, page reset on tab change, unmount invalidates in-flight request.
export function ClientTripsPage() {
  const [params, setParams] = useSearchParams();
  const tab = parseTab(params.get('tab'));
  const [page, setPage] = useState(1);
  const [data, setData] = useState<ClientTripsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const requestId = useRef(0);

  // TRACE: tab/page/reloadKey change → fetches that page → sets data or error.
  //        latest request only → state updated → older responses and post-unmount responses are ignored.
  useEffect(() => {
    const id = ++requestId.current;
    // TRACE: effect start → awaits the API → commits result if still current.
    //        id matches ref → loading false → failure stored as human message.
    async function run() {
      setLoading(true);
      setError(null);
      try {
        const res = await getClientTrips(tab, page);
        if (id !== requestId.current) return;
        setData(res);
      } catch (err) {
        if (id !== requestId.current) return;
        setError(errorMessage(err, 'Could not load your trips. Please try again.'));
      } finally {
        if (id === requestId.current) setLoading(false);
      }
    }
    void run();
    return () => {
      requestId.current += 1;
    };
  }, [tab, page, reloadKey]);

  // TRACE: tab button click → writes ?tab= and resets to page 1.
  //        tab key → URL updated (history replaced) → same tab click is a harmless no-op reload of state.
  const selectTab = useCallback(
    (key: TripTab) => {
      setPage(1);
      setData(null);
      setParams({ tab: key }, { replace: true });
    },
    [setParams]
  );

  // TRACE: retry click → bumps reloadKey → refetch.
  //        error state → new request → previous error cleared by the effect.
  const retry = useCallback(() => setReloadKey((k) => k + 1), []);

  // TRACE: previous click → page - 1.
  //        page > 1 → earlier page fetched → disabled at page 1.
  const goPrev = useCallback(() => setPage((p) => Math.max(1, p - 1)), []);

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.per_page)) : 1;

  // TRACE: next click → page + 1 bounded by total pages.
  //        more pages exist → later page fetched → disabled on the last page.
  const goNext = useCallback(() => setPage((p) => Math.min(totalPages, p + 1)), [totalPages]);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <Link to="/dashboard" className="text-sm font-medium text-brand-700 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600">
        ← Dashboard
      </Link>
      <h1 className="mt-2 text-2xl font-bold text-ink-900 sm:text-3xl">My trips</h1>

      <div className="mt-6 flex gap-1 overflow-x-auto border-b border-ink-100" role="tablist" aria-label="Trip status">
        {TRIP_TABS.map((t) => (
          <TabButton key={t.key} tabKey={t.key} label={t.label} active={tab === t.key} onSelect={selectTab} />
        ))}
      </div>

      <div className="mt-6" role="tabpanel" aria-busy={loading}>
        {loading && (
          <div className="space-y-3" aria-label="Loading your trips">
            {SKELETON_IDS.map((sid) => (
              <div key={sid} className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
                <Skeleton className="h-4 w-48" />
                <Skeleton className="mt-3 h-3 w-64 max-w-full" />
                <Skeleton className="mt-2 h-3 w-32" />
              </div>
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={retry} />}

        {!loading && !error && data && data.rows.length === 0 && (
          <EmptyState
            title={EMPTY_COPY[tab].title}
            description={EMPTY_COPY[tab].description}
            action={
              <Link
                to="/"
                className="inline-flex rounded-lg bg-brand-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-brand-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
              >
                Book a ride
              </Link>
            }
          />
        )}

        {!loading && !error && data && data.rows.length > 0 && (
          <>
            <ul className="space-y-3">
              {data.rows.map((trip) => (
                <TripCard key={trip.id} trip={trip} />
              ))}
            </ul>
            <nav className="mt-6 flex items-center justify-between gap-3" aria-label="Pagination">
              <Button variant="secondary" size="sm" onClick={goPrev} disabled={page <= 1}>
                Previous
              </Button>
              <p className="text-sm text-ink-600">
                Page {data.page} of {totalPages} · {data.total} trips
              </p>
              <Button variant="secondary" size="sm" onClick={goNext} disabled={page >= totalPages}>
                Next
              </Button>
            </nav>
          </>
        )}
      </div>
    </div>
  );
}

// TRACE: tab definition → one tab button.
//        key/label/active → calls onSelect(key) on click → active tab is marked aria-selected with a brand underline.
function TabButton({
  tabKey,
  label,
  active,
  onSelect,
}: {
  tabKey: TripTab;
  label: string;
  active: boolean;
  onSelect: (key: TripTab) => void;
}) {
  // TRACE: click → onSelect(tabKey).
  //        none → parent updates URL → repeated click on active tab is harmless.
  const handleClick = () => onSelect(tabKey);
  return (
    <button
      type="button"
      role="tab"
      aria-selected={active}
      onClick={handleClick}
      className={`shrink-0 whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 ${
        active ? 'border-brand-600 text-brand-700' : 'border-transparent text-ink-600 hover:text-ink-900'
      }`}
    >
      {label}
    </button>
  );
}
