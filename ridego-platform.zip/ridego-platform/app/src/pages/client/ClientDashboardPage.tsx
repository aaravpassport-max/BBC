import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  TRIP_TABS,
  attentionLabel,
  errorMessage,
  formatDate,
  formatMoney,
  formatTime,
  getClientHome,
  statusClasses,
  type ClientHomeResponse,
  type HomeAttentionItem,
} from '../../lib/api-client-dashboard';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { TripCard } from './ClientTripsPage';

const FOCUS = 'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600';
const TILE_SKELETON_IDS = ['tile-upcoming', 'tile-ongoing', 'tile-completed', 'tile-cancelled'];

// TRACE: attention item → one row linking to its trip.
//        item with booking id/number/message → link with badge + message → unknown codes are humanized by attentionLabel.
function AttentionRow({ item }: { item: HomeAttentionItem }) {
  return (
    <li>
      <Link
        to={`/app/dashboard/trips/${item.booking_id}`}
        className={`flex flex-col gap-1 rounded-lg border border-warning-500/30 bg-warning-50 p-3 text-sm hover:bg-warning-50/70 sm:flex-row sm:items-center sm:justify-between ${FOCUS}`}
      >
        <span className="font-semibold text-warning-600">
          {attentionLabel(item.code)} · {item.booking_number}
        </span>
        <span className="text-ink-700">{item.message}</span>
      </Link>
    </li>
  );
}

// TRACE: route /app/dashboard → loads /client/home → welcome, tiles, next trip, attention, recent, complaints, quick links.
//        logged-in client → summary rendered → loading skeleton, error banner with retry, empty states for no trips /
//        nothing needing attention, stale response ignored, unmount invalidates in-flight request.
export function ClientDashboardPage() {
  const [data, setData] = useState<ClientHomeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const requestId = useRef(0);

  // TRACE: mount/retry → fetches the home summary → data or error.
  //        latest request wins → state committed → older or post-unmount responses ignored.
  useEffect(() => {
    const id = ++requestId.current;
    // TRACE: effect start → awaits API → commits if current.
    //        id matches → loading cleared → failures become readable messages.
    async function run() {
      setLoading(true);
      setError(null);
      try {
        const res = await getClientHome();
        if (id !== requestId.current) return;
        setData(res);
      } catch (err) {
        if (id !== requestId.current) return;
        setError(errorMessage(err, 'Could not load your dashboard. Please try again.'));
      } finally {
        if (id === requestId.current) setLoading(false);
      }
    }
    void run();
    return () => {
      requestId.current += 1;
    };
  }, [reloadKey]);

  // TRACE: retry click → bumps reloadKey → refetch.
  //        error banner visible → new request → error cleared by the effect.
  const retry = useCallback(() => setReloadKey((k) => k + 1), []);

  const next = data?.next_trip ?? null;
  const nextTime = next ? formatTime(next.journey_time) : '';
  const totalTrips = data ? TRIP_TABS.reduce((sum, t) => sum + (data.counts[t.key] ?? 0), 0) : 0;

  return (
    <div className="min-h-full bg-ink-50">
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Welcome back</h1>
      <p className="mt-1 text-sm text-ink-600">Your trips, payments and support in one place.</p>

      {loading && (
        <div className="mt-6 space-y-6" aria-busy="true" aria-label="Loading your dashboard">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {TILE_SKELETON_IDS.map((sid) => (
              <Skeleton key={sid} className="h-20 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-32 w-full rounded-xl" />
          <Skeleton className="h-40 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={retry} />
        </div>
      )}

      {!loading && !error && data && (
        <div className="mt-6 space-y-8">
          <section aria-label="Trip counts">
            <ul className="grid grid-cols-2 gap-3 md:grid-cols-4">
              {TRIP_TABS.map((t) => (
                <li key={t.key}>
                  <Link
                    to={`/app/dashboard/trips?tab=${t.key}`}
                    className={`block rounded-lg bg-white p-4 shadow-xs ring-1 ring-inset ring-ink-100 transition hover:ring-brand-300 ${FOCUS}`}
                  >
                    <span className="block text-2xl font-bold text-ink-900">{data.counts[t.key] ?? 0}</span>
                    <span className="block text-sm text-ink-600">{t.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </section>

          <section aria-labelledby="next-trip-heading">
            <h2 id="next-trip-heading" className="text-lg font-semibold text-ink-900">
              Next trip
            </h2>
            {next ? (
              <Link
                to={`/app/dashboard/trips/${next.id}`}
                className={`mt-3 block rounded-xl border border-brand-300 bg-brand-50 p-5 hover:bg-brand-50/70 ${FOCUS}`}
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <p className="text-lg font-semibold text-ink-900">
                    {next.pickup_city} → {next.drop_city}
                  </p>
                  <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${statusClasses(next.group)}`}>{next.status_label}</span>
                </div>
                <p className="mt-1 text-sm text-ink-700">
                  {formatDate(next.journey_date)}
                  {nextTime ? ` at ${nextTime}` : ''} · {next.booking_number}
                </p>
                <p className="mt-2 text-sm text-ink-700">
                  Est. fare {formatMoney(next.total_fare)}
                  {next.balance_due > 0 ? ` · Pay vendor/driver ${formatMoney(next.balance_due)}` : ''}
                </p>
              </Link>
            ) : (
              <div className="mt-3">
                <EmptyState
                  title="No trip coming up"
                  description="Book a ride and your next trip will be shown here."
                  action={
                    <Link
                      to="/"
                      className={`inline-flex rounded-lg bg-brand-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-brand-700 ${FOCUS}`}
                    >
                      Book a ride
                    </Link>
                  }
                />
              </div>
            )}
          </section>

          <section aria-labelledby="attention-heading">
            <h2 id="attention-heading" className="text-lg font-semibold text-ink-900">
              Needs your attention
            </h2>
            {data.attention.length === 0 ? (
              <p className="mt-3 rounded-lg bg-white p-4 text-sm text-ink-600 shadow-xs ring-1 ring-inset ring-ink-100">
                You are all caught up. Nothing needs your attention right now.
              </p>
            ) : (
              <ul className="mt-3 space-y-2">
                {data.attention.map((item) => (
                  <AttentionRow key={`${item.booking_id}-${item.code}`} item={item} />
                ))}
              </ul>
            )}
          </section>

          <section aria-labelledby="recent-heading">
            <div className="flex items-center justify-between gap-2">
              <h2 id="recent-heading" className="text-lg font-semibold text-ink-900">
                Recent trips
              </h2>
              {totalTrips > 0 && (
                <Link to="/dashboard/trips" className={`text-sm font-medium text-brand-700 hover:underline ${FOCUS}`}>
                  View all
                </Link>
              )}
            </div>
            {data.recent.length === 0 ? (
              <div className="mt-3">
                <EmptyState title="No trips yet" description="Trips you book will appear here." />
              </div>
            ) : (
              <ul className="mt-3 space-y-3">
                {data.recent.map((trip) => (
                  <TripCard key={trip.id} trip={trip} />
                ))}
              </ul>
            )}
          </section>

          <section aria-label="Support and saved addresses" className="grid gap-3 sm:grid-cols-2">
            <Link
              to="/dashboard/support"
              className={`rounded-lg bg-white p-4 shadow-xs ring-1 ring-inset ring-ink-100 hover:ring-brand-300 ${FOCUS}`}
            >
              <span className="block text-base font-semibold text-ink-900">Support</span>
              <span className="mt-1 block text-sm text-ink-600">
                {data.open_complaints === 0
                  ? 'No open complaints. Raise an issue any time.'
                  : `${data.open_complaints} open ${data.open_complaints === 1 ? 'complaint' : 'complaints'}`}
              </span>
            </Link>
            <Link
              to="/dashboard/addresses"
              className={`rounded-lg bg-white p-4 shadow-xs ring-1 ring-inset ring-ink-100 hover:ring-brand-300 ${FOCUS}`}
            >
              <span className="block text-base font-semibold text-ink-900">Saved addresses</span>
              <span className="mt-1 block text-sm text-ink-600">Keep home, work and other places ready for booking.</span>
            </Link>
          </section>
        </div>
      )}
    </div>
    </div>
  );
}
