import { useCallback, useEffect, useState } from 'react';
import { cancelBooking, getMyBookings, rateBooking, ApiError } from '../lib/api';
import type { Booking } from '../types/api';
import { Skeleton } from '../components/ui/Skeleton';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { EmptyState } from '../components/ui/EmptyState';
import { Button } from '../components/ui/Button';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { DATA_CARD_CLASS } from '../components/ui/Zone';

const TABS: { key: string; label: string }[] = [
  { key: '', label: 'All' },
  { key: 'pending', label: 'Pending' },
  { key: 'confirmed', label: 'Confirmed' },
  { key: 'completed', label: 'Completed' },
  { key: 'cancelled', label: 'Cancelled' },
];

const statusStyles: Record<string, string> = {
  pending: 'bg-warning-50 text-warning-600',
  confirmed: 'bg-brand-50 text-brand-700',
  assigned: 'bg-brand-50 text-brand-700',
  completed: 'bg-success-50 text-success-600',
  cancelled: 'bg-danger-50 text-danger-600',
};

function currency(sym: string, n: number) {
  return `${sym}${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

function StarDisplay({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-0.5" aria-label={`Rated ${value} out of 5`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <svg
          key={n}
          className={`h-4 w-4 ${n <= value ? 'text-warning-500' : 'text-ink-200'}`}
          viewBox="0 0 20 20"
          fill="currentColor"
          aria-hidden="true"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.957a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.367 2.447a1 1 0 00-.364 1.118l1.287 3.957c.3.922-.755 1.688-1.538 1.118l-3.367-2.447a1 1 0 00-1.176 0l-3.367 2.447c-.783.57-1.838-.196-1.538-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.063 9.384c-.783-.57-.38-1.81.588-1.81h4.163a1 1 0 00.95-.69l1.286-3.957z" />
        </svg>
      ))}
    </div>
  );
}

const RATING_CATEGORIES: { key: string; label: string }[] = [
  { key: 'service_quality', label: 'Vendor service' },
  { key: 'communication', label: 'Communication' },
  { key: 'reliability', label: 'Reliability' },
  { key: 'vehicle_quality', label: 'Vehicle condition' },
  { key: 'behaviour', label: 'Driver behaviour' },
  { key: 'punctuality', label: 'Punctuality' },
  { key: 'driving', label: 'Driving' },
  { key: 'cleanliness', label: 'Cleanliness' },
];

function StarPicker({ value, onChange, label = 'Rate' }: { value: number; onChange: (n: number) => void; label?: string }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          aria-label={`${label} ${n} out of 5`}
          onClick={() => onChange(n)}
          className="rounded p-0.5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
        >
          <svg
            className={`h-7 w-7 ${n <= value ? 'text-warning-500' : 'text-ink-200'}`}
            viewBox="0 0 20 20"
            fill="currentColor"
            aria-hidden="true"
          >
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.957a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.367 2.447a1 1 0 00-.364 1.118l1.287 3.957c.3.922-.755 1.688-1.538 1.118l-3.367-2.447a1 1 0 00-1.176 0l-3.367 2.447c-.783.57-1.838-.196-1.538-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.063 9.384c-.783-.57-.38-1.81.588-1.81h4.163a1 1 0 00.95-.69l1.286-3.957z" />
          </svg>
        </button>
      ))}
    </div>
  );
}

export function MyTripsPage() {
  const [status, setStatus] = useState('');
  const [bookings, setBookings] = useState<Booking[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Cancel-booking dialog state.
  const [toCancel, setToCancel] = useState<Booking | null>(null);
  const [reason, setReason] = useState('');
  const [cancelling, setCancelling] = useState(false);
  const [cancelError, setCancelError] = useState<string | null>(null);

  // Rate-trip dialog state (kept separate from the cancel dialog's state).
  const [toRate, setToRate] = useState<Booking | null>(null);
  const [ratingScore, setRatingScore] = useState(0);
  const [ratingReview, setRatingReview] = useState('');
  const [categoryScores, setCategoryScores] = useState<Record<string, number>>({});
  const [rating, setRating] = useState(false);
  const [ratingError, setRatingError] = useState<string | null>(null);

  const load = useCallback(async (s: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await getMyBookings({ status: s || undefined });
      setBookings(res);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load your trips. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(status);
  }, [status, load]);

  async function confirmCancel() {
    if (!toCancel) return;
    setCancelling(true);
    setCancelError(null);
    try {
      await cancelBooking(toCancel.id, reason || 'Cancelled from app');
      setToCancel(null);
      setReason('');
      await load(status);
    } catch (err) {
      setCancelError(err instanceof ApiError ? err.message : 'Could not cancel this booking.');
    } finally {
      setCancelling(false);
    }
  }

  async function confirmRate() {
    if (!toRate || ratingScore < 1 || ratingScore > 5) return;
    setRating(true);
    setRatingError(null);
    try {
      await rateBooking(toRate.id, ratingScore, ratingReview, categoryScores);
      setToRate(null);
      setRatingScore(0);
      setRatingReview('');
      setCategoryScores({});
      await load(status);
    } catch (err) {
      setRatingError(err instanceof ApiError ? err.message : 'Could not submit your rating.');
    } finally {
      setRating(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">My trips</h1>
        <p className="text-sm text-ink-500">View, track and manage your bookings.</p>
      </div>

      <div className="mt-6 flex gap-1 overflow-x-auto border-b border-ink-100" role="tablist" aria-label="Booking status filter">
        {TABS.map((tab) => (
          <button
            key={tab.key}
            role="tab"
            aria-selected={status === tab.key}
            onClick={() => setStatus(tab.key)}
            className={`shrink-0 whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 ${
              status === tab.key
                ? 'border-brand-600 text-brand-700'
                : 'border-transparent text-ink-500 hover:text-ink-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading your trips">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
                <div className="flex items-center justify-between">
                  <Skeleton className="h-4 w-40" />
                  <Skeleton className="h-5 w-20 rounded-full" />
                </div>
                <Skeleton className="mt-3 h-3 w-64" />
                <Skeleton className="mt-2 h-3 w-32" />
              </div>
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={() => load(status)} />}

        {!loading && !error && bookings && bookings.length === 0 && (
          <EmptyState
            title="No trips yet"
            description="When you book a ride, it'll show up here so you can track and manage it."
            action={
              <a href="/">
                <Button>Book a ride</Button>
              </a>
            }
          />
        )}

        {!loading && !error && bookings && bookings.length > 0 && (
          <ul className="space-y-3">
            {bookings.map((b) => {
              const canCancel = !['completed', 'cancelled'].includes(b.status);
              const canRate = b.status === 'completed';
              return (
                <li key={b.id} className={`${DATA_CARD_CLASS} p-4 transition hover:shadow-sm sm:p-5`}>
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <p className="font-semibold text-ink-900">{b.pickup_city} → {b.drop_city}</p>
                      <p className="mt-0.5 text-sm text-ink-500">
                        {b.journey_date} at {b.journey_time} &middot; {b.vehicle_name || 'Vehicle TBD'}
                      </p>
                    </div>
                    <span
                      className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${
                        statusStyles[b.status] ?? 'bg-ink-100 text-ink-600'
                      }`}
                    >
                      {b.status_label}
                    </span>
                  </div>

                  <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-ink-100 pt-3">
                    <div className="text-sm text-ink-500">
                      #{b.booking_number} &middot; <span className="font-semibold text-ink-800">{currency('₹', b.total_fare)}</span> <span className="text-xs">est. fare</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {canCancel && (
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => {
                            setToCancel(b);
                            setReason('');
                            setCancelError(null);
                          }}
                        >
                          Cancel booking
                        </Button>
                      )}
                      {canRate && b.rating == null && (
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => {
                            setToRate(b);
                            setRatingScore(0);
                            setRatingReview('');
                            setRatingError(null);
                          }}
                        >
                          Rate this trip
                        </Button>
                      )}
                    </div>
                  </div>

                  {canRate && b.rating != null && (
                    <div className="mt-3 border-t border-ink-100 pt-3">
                      <div className="flex items-center gap-2">
                        <StarDisplay value={b.rating} />
                        <span className="text-xs text-ink-500">Your rating</span>
                      </div>
                      {b.review && <p className="mt-1.5 text-sm text-ink-600">&ldquo;{b.review}&rdquo;</p>}
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <ConfirmDialog
        open={!!toCancel}
        title={`Cancel booking #${toCancel?.booking_number ?? ''}?`}
        description="This can't be undone. Let us know why you're cancelling so we can improve."
        confirmLabel="Cancel booking"
        confirmVariant="danger"
        cancelLabel="Keep booking"
        loading={cancelling}
        onConfirm={confirmCancel}
        onCancel={() => {
          if (cancelling) return;
          setToCancel(null);
          setReason('');
          setCancelError(null);
        }}
      >
        {cancelError && (
          <div role="alert" className="mb-3 rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {cancelError}
          </div>
        )}
        <label htmlFor="cancel-reason" className="block text-sm font-medium text-ink-700">
          Reason (optional)
        </label>
        <textarea
          id="cancel-reason"
          rows={3}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="e.g. Plans changed"
          className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        />
      </ConfirmDialog>

      <ConfirmDialog
        open={!!toRate}
        title={`Rate trip #${toRate?.booking_number ?? ''}`}
        description="How was your ride? Your feedback helps other riders and our driver-partners."
        confirmLabel="Submit rating"
        confirmVariant="primary"
        cancelLabel="Cancel"
        loading={rating}
        confirmDisabled={ratingScore < 1 || ratingScore > 5}
        onConfirm={confirmRate}
        onCancel={() => {
          if (rating) return;
          setToRate(null);
          setRatingScore(0);
          setRatingReview('');
          setCategoryScores({});
          setRatingError(null);
        }}
      >
        {ratingError && (
          <div role="alert" className="mb-3 rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {ratingError}
          </div>
        )}
        <div>
          <span className="block text-sm font-medium text-ink-700">Your rating</span>
          <div className="mt-1.5">
            <StarPicker value={ratingScore} onChange={setRatingScore} />
          </div>
        </div>
        <fieldset className="mt-4">
          <legend className="text-sm font-medium text-ink-700">Rate in detail (optional)</legend>
          {RATING_CATEGORIES.map((c) => (
            <div key={c.key} className="mt-2 flex items-center justify-between gap-3">
              <span className="text-sm text-ink-600">{c.label}</span>
              <StarPicker
                label={c.label}
                value={categoryScores[c.key] ?? 0}
                onChange={(n) => setCategoryScores((prev) => ({ ...prev, [c.key]: n }))}
              />
            </div>
          ))}
        </fieldset>
        <label htmlFor="rating-review" className="mt-4 block text-sm font-medium text-ink-700">
          Review (optional)
        </label>
        <textarea
          id="rating-review"
          rows={3}
          value={ratingReview}
          onChange={(e) => setRatingReview(e.target.value)}
          placeholder="Tell us about your ride"
          className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        />
      </ConfirmDialog>
    </div>
  );
}
