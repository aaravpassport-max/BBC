import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ApiError, getFleetDocumentExpiry, type DocumentExpiryResponse, type DocumentExpiryRow } from '../../lib/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';

const DAY_OPTIONS: { key: number; label: string }[] = [
  { key: 7, label: '7 days' },
  { key: 30, label: '30 days' },
  { key: 60, label: '60 days' },
  { key: 90, label: '90 days' },
];

const STATUS_OPTIONS: { key: '' | 'expired' | 'expiring_soon'; label: string }[] = [
  { key: '', label: 'All' },
  { key: 'expired', label: 'Expired' },
  { key: 'expiring_soon', label: 'Expiring soon' },
];

// TRACE: doc_type string (e.g. "vehicle_insurance") → "Vehicle Insurance" → string. Pure.
function humanizeDocType(value: string): string {
  return value
    .split('_')
    .map((part) => (part ? part[0].toUpperCase() + part.slice(1) : part))
    .join(' ');
}

// TRACE: DocumentExpiryRow → a colored badge reflecting validity → element. Pure.
function ValidityBadge({ row }: { row: DocumentExpiryRow }) {
  const isExpired = row.validity === 'expired';
  const cls = isExpired ? 'bg-danger-50 text-danger-600' : 'bg-warning-50 text-warning-600';
  const label = isExpired ? `Expired ${Math.abs(row.days_until_expiry)}d ago` : `Expires in ${row.days_until_expiry}d`;
  return <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${cls}`}>{label}</span>;
}

// TRACE: page mount / filter change → GET /app/admin/fleet/document-expiry(?days&status) → renders a
//        sorted, filterable table of every fleet document across every vendor that is expired or due
//        soon → element. Preconditions: caller holds ridego_view_fleets (route-gated by RequireAdmin,
//        mirrored server-side). Postconditions: no writes — this page is read-only; acting on a row
//        (renewing/uploading a replacement doc) happens in that vendor's own fleet tab, linked from
//        each row. Edge cases: zero rows (EmptyState, not a blank table); a request error shows
//        ErrorBanner with retry, never a silent empty table indistinguishable from "nothing expiring."
export function AdminDocumentExpiryPage() {
  const [days, setDays] = useState(30);
  const [status, setStatus] = useState<'' | 'expired' | 'expiring_soon'>('');
  const [data, setData] = useState<DocumentExpiryResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    getFleetDocumentExpiry({ days, status: status || undefined })
      .then((res) => setData(res))
      .catch((e) => setError(e instanceof ApiError ? e.message : 'Could not load the document-expiry list.'))
      .finally(() => setLoading(false));
  }, [days, status]);

  useEffect(() => {
    load();
  }, [load]);

  const rows = data?.rows ?? [];

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-ink-900">Fleet document expiry</h1>
          <p className="mt-1 text-sm text-ink-600">
            Every vehicle and driver document across every vendor that is expired or due for renewal.
          </p>
        </div>
        <Button variant="secondary" onClick={load} disabled={loading}>
          Refresh
        </Button>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="rounded-xl border border-danger-100 bg-danger-50 p-4">
          <p className="text-xs font-medium uppercase tracking-wide text-danger-600">Expired</p>
          {loading ? <Skeleton className="mt-2 h-6 w-12" /> : <p className="mt-2 text-xl font-bold text-danger-700">{data?.summary.expired ?? 0}</p>}
        </div>
        <div className="rounded-xl border border-warning-100 bg-warning-50 p-4">
          <p className="text-xs font-medium uppercase tracking-wide text-warning-600">Expiring soon</p>
          {loading ? <Skeleton className="mt-2 h-6 w-12" /> : <p className="mt-2 text-xl font-bold text-warning-700">{data?.summary.expiring_soon ?? 0}</p>}
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-2">
        <span className="text-xs font-medium text-ink-500">Window:</span>
        {DAY_OPTIONS.map((opt) => (
          <button
            key={opt.key}
            type="button"
            onClick={() => setDays(opt.key)}
            className={`rounded-full px-3 py-1 text-xs font-semibold transition ${
              days === opt.key ? 'bg-brand-600 text-white' : 'bg-ink-100 text-ink-700 hover:bg-ink-200'
            }`}
          >
            {opt.label}
          </button>
        ))}
        <span className="ml-3 text-xs font-medium text-ink-500">Status:</span>
        {STATUS_OPTIONS.map((opt) => (
          <button
            key={opt.key || 'all'}
            type="button"
            onClick={() => setStatus(opt.key)}
            className={`rounded-full px-3 py-1 text-xs font-semibold transition ${
              status === opt.key ? 'bg-brand-600 text-white' : 'bg-ink-100 text-ink-700 hover:bg-ink-200'
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>

      {error && (
        <div className="mt-4">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {!error && loading && (
        <div className="mt-4 space-y-2">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-16 w-full" />
        </div>
      )}

      {!error && !loading && rows.length === 0 && (
        <div className="mt-4">
          <EmptyState
            title="Nothing due"
            description={`No fleet documents are expired or expiring within ${days} days${status ? ` (filtered to ${status.replace('_', ' ')})` : ''}.`}
          />
        </div>
      )}

      {!error && !loading && rows.length > 0 && (
        <ul className="mt-4 divide-y divide-ink-100 rounded-xl border border-ink-100 bg-white shadow-xs">
          {rows.map((r) => (
            <li key={r.doc_id} className="flex flex-wrap items-center justify-between gap-3 p-4">
              <div className="min-w-0">
                <p className="font-semibold text-ink-900">
                  {humanizeDocType(r.doc_type)} <span className="text-ink-400">·</span>{' '}
                  <span className="capitalize text-ink-600">{r.entity_type}</span> {r.entity_label}
                </p>
                <p className="truncate text-sm text-ink-600">
                  <Link to={`/admin/vendors/${r.vendor_id}`} className="text-brand-700 hover:underline">
                    {r.vendor_name || `Vendor #${r.vendor_id}`}
                  </Link>{' '}
                  · Expires {r.expiry_date}
                </p>
              </div>
              <ValidityBadge row={r} />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
