import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  getAdminFinancialOverview,
  getAdminWalletLedger,
  getAdminWalletReconciliation,
  reconcileAdminWallet,
  creditAdminVendorWallet,
  debitAdminVendorWallet,
  ApiError,
} from '../../lib/api';
import type {
  AdminFinancialOverview,
  AdminWalletLedgerRow,
  AdminWalletReconciliationRow,
} from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { brand } from '../../lib/brand';

function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

function fmtDate(s: string) {
  if (!s) return '—';
  const d = new Date(s.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}

type Tab = 'overview' | 'reconciliation';

/**
 * Combines admin/pages/financial.php (Financial Overview + wallet
 * ledger panel) and admin/pages/wallet-reconciliation.php (full
 * per-vendor drill-down + manual reconcile action) into one page with
 * two tabs — the same UX consolidation used in Wave 20 for
 * routes/zones (two legacy pages sharing one dashboard). Manual
 * credit/debit (from admin/pages/vendors.php's wallet form) is
 * exposed here too via a small "Adjust wallet" action per
 * reconciliation row, since a vendor id is already in view there —
 * the alternative (AdminVendorDetailPage) would require navigating
 * away first.
 */
export function AdminFinancialPage() {
  const [tab, setTab] = useState<Tab>('overview');
  const [period, setPeriod] = useState('month');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');

  const [overview, setOverview] = useState<AdminFinancialOverview | null>(null);
  const [ledger, setLedger] = useState<AdminWalletLedgerRow[] | null>(null);
  const [reconRows, setReconRows] = useState<AdminWalletReconciliationRow[] | null>(null);
  const [reconMeta, setReconMeta] = useState<{ checked: number; discrepancy_count: number; total_discrepancy_abs: number; previous_run_at: string | null } | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [reconcileTarget, setReconcileTarget] = useState<AdminWalletReconciliationRow | null>(null);
  const [reconcileReason, setReconcileReason] = useState('');
  const [reconcileSaving, setReconcileSaving] = useState(false);
  const [reconcileError, setReconcileError] = useState<string | null>(null);

  const [adjustTarget, setAdjustTarget] = useState<AdminWalletReconciliationRow | null>(null);
  const [adjustMode, setAdjustMode] = useState<'credit' | 'debit'>('credit');
  const [adjustAmount, setAdjustAmount] = useState('');
  const [adjustNotes, setAdjustNotes] = useState('');
  const [adjustSaving, setAdjustSaving] = useState(false);
  const [adjustError, setAdjustError] = useState<string | null>(null);

  const loadOverview = useCallback(async (p: string, from?: string, to?: string) => {
    setLoading(true);
    setError(null);
    try {
      const rangeParams = from && to ? { from, to } : { period: p };
      const [ov, led] = await Promise.all([
        getAdminFinancialOverview(rangeParams),
        getAdminWalletLedger(rangeParams),
      ]);
      setOverview(ov);
      setLedger(led.rows);
    } catch (err) {
      setError(
        err instanceof ApiError && err.code === 'forbidden'
          ? "You don't have permission to view financial data."
          : err instanceof ApiError
          ? err.message
          : 'Could not load financial data. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  const loadReconciliation = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminWalletReconciliation();
      setReconRows(res.rows);
      setReconMeta({
        checked: res.checked,
        discrepancy_count: res.discrepancy_count,
        total_discrepancy_abs: res.total_discrepancy_abs,
        previous_run_at: res.previous_run_at,
      });
    } catch (err) {
      setError(
        err instanceof ApiError && err.code === 'forbidden'
          ? "You don't have permission to manage vendor wallets."
          : err instanceof ApiError
          ? err.message
          : 'Could not load the reconciliation report. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (tab === 'overview') loadOverview(period);
    else loadReconciliation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, period]);

  function applyCustomRange() {
    if (!customFrom || !customTo) return;
    loadOverview(period, customFrom, customTo);
  }

  async function submitReconcile() {
    if (!reconcileTarget || !reconcileReason.trim()) return;
    setReconcileSaving(true);
    setReconcileError(null);
    try {
      await reconcileAdminWallet(reconcileTarget.vendor_id, reconcileReason.trim());
      setReconcileTarget(null);
      setReconcileReason('');
      await loadReconciliation();
    } catch (err) {
      setReconcileError(err instanceof ApiError ? err.message : 'Reconciliation failed.');
    } finally {
      setReconcileSaving(false);
    }
  }

  async function submitAdjust() {
    if (!adjustTarget) return;
    const amt = parseFloat(adjustAmount);
    if (!(amt > 0)) {
      setAdjustError('Enter an amount greater than zero.');
      return;
    }
    setAdjustSaving(true);
    setAdjustError(null);
    try {
      if (adjustMode === 'credit') {
        await creditAdminVendorWallet(adjustTarget.vendor_id, amt, adjustNotes || undefined);
      } else {
        await debitAdminVendorWallet(adjustTarget.vendor_id, amt, adjustNotes || undefined);
      }
      setAdjustTarget(null);
      setAdjustAmount('');
      setAdjustNotes('');
      await loadReconciliation();
    } catch (err) {
      setAdjustError(err instanceof ApiError ? err.message : 'Wallet adjustment failed.');
    } finally {
      setAdjustSaving(false);
    }
  }

  const mmax = overview?.monthly_trend.length ? Math.max(...overview.monthly_trend.map((m) => m.revenue), 1) : 1;

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div>
        <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Financial &amp; wallets</h1>
        <p className="text-sm text-ink-500">Booking amounts collected by {brand().name}, vendor wallet float, and ledger reconciliation. Ride fares are billed and collected by vendors/drivers and are not {brand().name} revenue.</p>
      </div>

      <div className="mt-6 flex gap-1 border-b border-ink-100">
        {(['overview', 'reconciliation'] as Tab[]).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTab(t)}
            className={`-mb-px border-b-2 px-4 py-2.5 text-sm font-medium capitalize ${
              tab === t ? 'border-brand-600 text-brand-700' : 'border-transparent text-ink-500 hover:text-ink-800'
            }`}
          >
            {t === 'overview' ? 'Overview' : 'Wallet reconciliation'}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <div className="mt-6 flex flex-wrap items-center gap-2">
          <span className="text-sm font-medium text-ink-600">Period:</span>
          {[
            ['today', 'Today'],
            ['week', '7 Days'],
            ['month', 'This Month'],
            ['year', 'This Year'],
          ].map(([pv, pl]) => (
            <Button
              key={pv}
              variant={!customFrom && !customTo && period === pv ? 'primary' : 'secondary'}
              size="sm"
              onClick={() => {
                setCustomFrom('');
                setCustomTo('');
                setPeriod(pv);
              }}
            >
              {pl}
            </Button>
          ))}
          <span className="mx-1 h-5 w-px bg-ink-200" />
          <label htmlFor="fin-from" className="text-sm font-medium text-ink-600">
            From
          </label>
          <input
            id="fin-from"
            type="date"
            value={customFrom}
            onChange={(e) => setCustomFrom(e.target.value)}
            className="rounded-lg border border-ink-200 px-2.5 py-1.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
          <label htmlFor="fin-to" className="text-sm font-medium text-ink-600">
            To
          </label>
          <input
            id="fin-to"
            type="date"
            value={customTo}
            onChange={(e) => setCustomTo(e.target.value)}
            className="rounded-lg border border-ink-200 px-2.5 py-1.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
          <Button
            variant={customFrom && customTo ? 'primary' : 'secondary'}
            size="sm"
            disabled={!customFrom || !customTo}
            onClick={applyCustomRange}
          >
            Apply
          </Button>
        </div>
      )}

      {loading && (
        <div className="mt-6 space-y-6" aria-busy="true" aria-label="Loading financial data">
          <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-64 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner
            message={error}
            onRetry={() =>
              tab === 'overview'
                ? loadOverview(period, customFrom && customTo ? customFrom : undefined, customFrom && customTo ? customTo : undefined)
                : loadReconciliation()
            }
          />
        </div>
      )}

      {!loading && !error && tab === 'overview' && overview && (
        <>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Booking amounts collected</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{currency(overview.total_revenue)}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Avg booking value</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{currency(overview.avg_booking)}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Online (gateway)</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{currency(overview.upi_revenue)}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Manual / bank / UPI proofs</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{currency(overview.cash_revenue)}</p>
            </div>
          </div>

          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Lead fees collected</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{currency(overview.lead_fees)}</p>
            </div>
            {overview.vendor_lead_fee && (
              <>
                <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
                  <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Vendor lead fees accrued</p>
                  <p className="mt-2 text-xl font-bold text-ink-900">{currency(overview.vendor_lead_fee.accrued)}</p>
                  <p className="text-xs text-ink-500">{overview.vendor_lead_fee.bookings} bookings</p>
                </div>
                <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
                  <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Vendor lead fees outstanding</p>
                  <p className="mt-2 text-xl font-bold text-ink-900">{currency(overview.vendor_lead_fee.outstanding)}</p>
                  <p className="text-xs text-ink-500">Settled or set off: {currency(overview.vendor_lead_fee.collected)}</p>
                </div>
              </>
            )}
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Vendor wallet float</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{currency(overview.wallet_float)}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">GST collected</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{currency(overview.gst_collected)}</p>
            </div>
          </div>

          <div className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold text-ink-900">🧮 Wallet reconciliation</h3>
              <Button variant="secondary" size="sm" onClick={() => setTab('reconciliation')}>
                Full report →
              </Button>
            </div>
            <p className="mt-2 text-sm text-ink-600">
              {overview.wallet_reconciliation.discrepancy_count === 0
                ? `✅ All ${overview.wallet_reconciliation.checked} vendor wallets reconcile cleanly against their ledger.`
                : `⚠️ ${overview.wallet_reconciliation.discrepancy_count} of ${overview.wallet_reconciliation.checked} vendor wallets have a stored balance that does not match their ledger sum.`}
            </p>
          </div>

          {overview.monthly_trend.length > 0 && (
            <div className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs">
              <h3 className="text-base font-semibold text-ink-900">📈 Booking amounts collected — last 12 months</h3>
              <div className="mt-4 flex h-48 items-end gap-2">
                {overview.monthly_trend.map((m) => (
                  // h-full on this column is required: its parent row uses
                  // items-end (not stretch), so without an explicit height
                  // here the bar's percentage `height` below has no sized
                  // ancestor to resolve against and silently renders at
                  // 0px — found during this session's visual QA pass.
                  <div key={m.month} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
                    <div
                      className="w-full rounded-t bg-success-500"
                      style={{ height: `${Math.max(6, (m.revenue / mmax) * 100)}%` }}
                      title={currency(m.revenue)}
                    />
                    <span className="text-[10px] text-ink-400">{m.month.slice(5)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <div className="rounded-xl border border-ink-100 p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-semibold text-ink-900">💳 Recent verified payments</h3>
                <Link to="/admin/bookings?status=confirmed" className="text-sm font-medium text-brand-700 hover:text-brand-800">
                  All →
                </Link>
              </div>
              {overview.recent_payments.length > 0 ? (
                <ul className="mt-3 space-y-2 text-sm">
                  {overview.recent_payments.map((p, i) => (
                    <li key={i} className="flex items-center justify-between border-b border-ink-100 pb-2 last:border-b-0">
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-ink-900">{p.booking_number ?? '—'}</p>
                          <span className="rounded-full bg-ink-100 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-ink-600">
                            {p.gateway || 'manual'}
                          </span>
                        </div>
                        <p className="text-xs text-ink-400">
                          {p.client_name} &middot; {p.pickup_city} → {p.drop_city}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-success-600">{currency(p.amount)}</p>
                        <p className="text-xs text-ink-400">{fmtDate(p.paid_at)}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="mt-3 text-sm text-ink-500">No verified payments in this period.</p>
              )}
            </div>

            <div className="rounded-xl border border-ink-100 p-5 shadow-xs">
              <h3 className="text-base font-semibold text-ink-900">🏦 Vendor wallet ledger</h3>
              {ledger && ledger.length > 0 ? (
                <ul className="mt-3 space-y-2 text-sm">
                  {ledger.map((w) => (
                    <li key={w.id} className="flex items-center justify-between border-b border-ink-100 pb-2 last:border-b-0">
                      <div>
                        <p className="font-medium text-ink-900">{w.business_name ?? '—'}</p>
                        <p className="text-xs capitalize text-ink-400">{w.type}</p>
                      </div>
                      <div className="text-right">
                        <p className={`font-semibold ${w.amount >= 0 ? 'text-success-600' : 'text-danger-600'}`}>
                          {currency(Math.abs(w.amount))}
                        </p>
                        <p className="text-xs text-ink-400">{fmtDate(w.created_at)}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="mt-3 text-sm text-ink-500">No wallet transactions in this period.</p>
              )}
            </div>
          </div>
        </>
      )}

      {!loading && !error && tab === 'reconciliation' && reconMeta && (
        <>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Vendors checked</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{reconMeta.checked}</p>
            </div>
            <div className={`rounded-xl border p-4 shadow-xs ${reconMeta.discrepancy_count ? 'border-danger-200 bg-danger-50' : 'border-ink-100'}`}>
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">With discrepancies</p>
              <p className={`mt-2 text-xl font-bold ${reconMeta.discrepancy_count ? 'text-danger-600' : 'text-success-600'}`}>
                {reconMeta.discrepancy_count ? `⚠️ ${reconMeta.discrepancy_count}` : '✅ 0'}
              </p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Total discrepancy (abs)</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{currency(reconMeta.total_discrepancy_abs)}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Previous run</p>
              <p className="mt-2 text-sm font-semibold text-ink-900">
                {reconMeta.previous_run_at ? fmtDate(reconMeta.previous_run_at) : 'Never (first run)'}
              </p>
            </div>
          </div>

          <p className="mt-4 text-xs text-ink-500">
            ℹ️ Sign convention: <strong>discrepancy = stored wallet balance − ledger-computed balance</strong>. A positive
            value means the stored balance is higher than the ledger accounts for; negative means it is lower.
          </p>

          <div className="mt-6 hidden overflow-hidden rounded-xl border border-ink-100 lg:block">
            <table className="w-full text-sm">
              <thead className="bg-ink-50 text-left text-xs font-medium uppercase tracking-wide text-ink-500">
                <tr>
                  <th className="px-4 py-3">Vendor</th>
                  <th className="px-4 py-3">Stored balance</th>
                  <th className="px-4 py-3">Ledger balance</th>
                  <th className="px-4 py-3">Discrepancy</th>
                  <th className="px-4 py-3">Last ledger entry</th>
                  <th className="px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {reconRows && reconRows.length > 0 ? (
                  reconRows.map((row) => (
                    <tr key={row.vendor_id}>
                      <td className="px-4 py-3 font-medium text-ink-900">{row.vendor_name}</td>
                      <td className="px-4 py-3 text-ink-700">{currency(row.stored_balance)}</td>
                      <td className="px-4 py-3 text-ink-700">{currency(row.ledger_balance)}</td>
                      <td className="px-4 py-3">
                        {row.ok ? (
                          <span className="font-semibold text-success-600">✅ ₹0.00</span>
                        ) : (
                          <span className="font-semibold text-danger-600">
                            {row.discrepancy >= 0 ? '+' : ''}
                            {currency(row.discrepancy)}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-ink-500">{row.last_ledger_at ? fmtDate(row.last_ledger_at) : '—'}</td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-2">
                          <Link
                            to={`/app/admin/vendors/${row.vendor_id}?tab=wallet`}
                            className="inline-flex items-center rounded-lg border border-ink-200 px-3 py-1.5 text-sm font-medium text-ink-700 hover:bg-ink-50"
                          >
                            📜 View Ledger
                          </Link>
                          <Button
                            variant="secondary"
                            size="sm"
                            onClick={() => {
                              setAdjustTarget(row);
                              setAdjustMode('credit');
                              setAdjustError(null);
                            }}
                          >
                            Adjust
                          </Button>
                          {!row.ok && (
                            <Button
                              variant="danger"
                              size="sm"
                              onClick={() => {
                                setReconcileTarget(row);
                                setReconcileReason('');
                                setReconcileError(null);
                              }}
                            >
                              🛠️ Reconcile
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6}>
                      <EmptyState title="No vendors found" description="There are no vendors to reconcile yet." />
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {reconRows && reconRows.length > 0 ? (
            <div className="mt-6 space-y-3 lg:hidden">
              {reconRows.map((row) => (
                <div key={row.vendor_id} className="rounded-xl border border-ink-100 bg-white p-4">
                  <div className="flex items-start justify-between gap-3">
                    <p className="text-sm font-medium text-ink-900">{row.vendor_name}</p>
                    {row.ok ? (
                      <span className="shrink-0 text-sm font-semibold text-success-600">✅ ₹0.00</span>
                    ) : (
                      <span className="shrink-0 text-sm font-semibold text-danger-600">
                        {row.discrepancy >= 0 ? '+' : ''}
                        {currency(row.discrepancy)}
                      </span>
                    )}
                  </div>
                  <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
                    <span className="text-ink-400">Stored balance</span>
                    <span className="text-right text-ink-700">{currency(row.stored_balance)}</span>
                    <span className="text-ink-400">Ledger balance</span>
                    <span className="text-right text-ink-700">{currency(row.ledger_balance)}</span>
                    <span className="text-ink-400">Last ledger entry</span>
                    <span className="text-right text-ink-500">{row.last_ledger_at ? fmtDate(row.last_ledger_at) : '—'}</span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Link
                      to={`/app/admin/vendors/${row.vendor_id}?tab=wallet`}
                      className="inline-flex items-center rounded-lg border border-ink-200 px-3 py-1.5 text-sm font-medium text-ink-700 hover:bg-ink-50"
                    >
                      📜 View Ledger
                    </Link>
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => {
                        setAdjustTarget(row);
                        setAdjustMode('credit');
                        setAdjustError(null);
                      }}
                    >
                      Adjust
                    </Button>
                    {!row.ok && (
                      <Button
                        variant="danger"
                        size="sm"
                        onClick={() => {
                          setReconcileTarget(row);
                          setReconcileReason('');
                          setReconcileError(null);
                        }}
                      >
                        🛠️ Reconcile
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-6 lg:hidden">
              <EmptyState title="No vendors found" description="There are no vendors to reconcile yet." />
            </div>
          )}
        </>
      )}

      <ConfirmDialog
        open={!!reconcileTarget}
        title={`Reconcile ${reconcileTarget?.vendor_name ?? ''}'s wallet?`}
        description="This inserts a corrective ledger entry and updates the vendor's stored wallet balance to match the ledger. This cannot be undone."
        confirmLabel="Reconcile"
        confirmVariant="danger"
        loading={reconcileSaving}
        confirmDisabled={!reconcileReason.trim()}
        onConfirm={submitReconcile}
        onCancel={() => setReconcileTarget(null)}
      >
        <div>
          <label htmlFor="reconcile-reason" className="block text-sm font-medium text-ink-700">
            Reason for correction
          </label>
          <input
            id="reconcile-reason"
            type="text"
            required
            value={reconcileReason}
            onChange={(e) => setReconcileReason(e.target.value)}
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            placeholder="e.g. matched against gateway statement"
          />
          {reconcileError && <p className="mt-2 text-sm text-danger-600">{reconcileError}</p>}
        </div>
      </ConfirmDialog>

      <ConfirmDialog
        open={!!adjustTarget}
        title={`Adjust ${adjustTarget?.vendor_name ?? ''}'s wallet`}
        description="Manually credit or deduct this vendor's wallet balance. This writes a ledger entry and is logged to the audit trail."
        confirmLabel={adjustMode === 'credit' ? 'Credit wallet' : 'Deduct from wallet'}
        confirmVariant={adjustMode === 'credit' ? 'primary' : 'danger'}
        loading={adjustSaving}
        confirmDisabled={!(parseFloat(adjustAmount) > 0)}
        onConfirm={submitAdjust}
        onCancel={() => setAdjustTarget(null)}
      >
        <div className="space-y-3">
          <div className="flex gap-2">
            <Button
              type="button"
              variant={adjustMode === 'credit' ? 'primary' : 'secondary'}
              size="sm"
              onClick={() => setAdjustMode('credit')}
            >
              + Credit
            </Button>
            <Button
              type="button"
              variant={adjustMode === 'debit' ? 'danger' : 'secondary'}
              size="sm"
              onClick={() => setAdjustMode('debit')}
            >
              − Deduct
            </Button>
          </div>
          <div>
            <label htmlFor="adjust-amount" className="block text-sm font-medium text-ink-700">
              Amount (₹)
            </label>
            <input
              id="adjust-amount"
              type="number"
              min="0.01"
              step="0.01"
              value={adjustAmount}
              onChange={(e) => setAdjustAmount(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div>
            <label htmlFor="adjust-notes" className="block text-sm font-medium text-ink-700">
              Notes (optional)
            </label>
            <input
              id="adjust-notes"
              type="text"
              value={adjustNotes}
              onChange={(e) => setAdjustNotes(e.target.value)}
              placeholder={adjustMode === 'credit' ? 'Admin top-up' : 'Admin deduction'}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          {adjustError && <p className="text-sm text-danger-600">{adjustError}</p>}
        </div>
      </ConfirmDialog>
    </div>
  );
}
