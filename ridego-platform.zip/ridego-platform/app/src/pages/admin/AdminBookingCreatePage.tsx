import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  createAdminBooking,
  duplicateOf,
  errMessage,
  getAssignOptions,
  getClientDetail,
  getEnquiryPrefill,
  getFormOptions,
  inr,
  lookupClients,
  METHOD_LABELS,
  quoteBooking,
  SOURCE_LABELS,
  TRIP_TYPE_LABELS,
  type AssignOptions,
  type ClientRow,
  type ClientSummary,
  type CreateBookingInput,
  type FareBreakdown,
  type FareOverrides,
  type FormOptions,
} from '../../lib/api-admin-crm';
import { ApiError } from '../../types/api';
import { ClientFields, EMPTY_CLIENT, validateClientForm, type ClientFormErrors, type ClientFormValues } from '../../components/admin/ClientFields';
import { Button } from '../../components/ui/Button';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { SearchableSelect } from '../../components/ui/SearchableSelect';
import { useToast } from '../../context/ToastContext';
import { FormField, INPUT_CLASS, ToneBadge } from '../vendor-mkt/vendor-mkt-shared';
import { brand } from '../../lib/brand';

const STEPS = ['Client', 'Trip', 'Pricing', 'Dispatch and payment', 'Review'] as const;

/**
 * Root-cause fix (same defect and same fix shape as the guest BookingPage
 * wizard's BOOKING_DRAFT_KEY — see its doc comment): this five-step desk
 * form held everything (client selection, trip, dispatch/payment, notes)
 * only in React state, so a refresh mid-entry — not rare at a busy phone
 * desk juggling multiple calls/tabs — silently discarded a staff
 * member's work with no warning. Persisted to sessionStorage per-tab,
 * rehydrated via lazy initializers on mount, and cleared once the
 * booking is actually created (or the desk is explicitly reset for a
 * new booking). Deliberately excludes the server-quoted fare
 * (`fare`/`fareForm`), lead-fee estimate, assignment options and
 * duplicate-warning state — those are time-sensitive server truth
 * (rates, vendor availability, dedupe checks) that must always be
 * re-fetched live rather than resumed stale; the Pricing step already
 * re-quotes automatically once trip details are restored.
 */
const ADMIN_BOOKING_DRAFT_KEY = 'ridego_admin_booking_draft_v1';
const ADMIN_BOOKING_DRAFT_TTL_MS = 4 * 60 * 60 * 1000; // 4 hours — a staff shift

interface AdminBookingDraft {
  savedAt: number;
  step?: number;
  clientMode?: 'existing' | 'new';
  picked?: ClientSummary | null;
  newClient?: ClientFormValues;
  trip?: TripForm;
  stops?: StopRow[];
  pax?: PassengerRow[];
  source?: string;
  vendorId?: string;
  driverId?: string;
  vehicleId?: string;
  payMode?: 'collect_later' | 'awaiting_payment' | 'received' | 'waived';
  waiveReason?: string;
  payMethod?: string;
  payRef?: string;
  internalNote?: string;
  clientNote?: string;
  enquiryId?: number | null;
}

function loadAdminBookingDraft(): AdminBookingDraft | null {
  try {
    const raw = sessionStorage.getItem(ADMIN_BOOKING_DRAFT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AdminBookingDraft;
    if (!parsed || typeof parsed.savedAt !== 'number') return null;
    if (Date.now() - parsed.savedAt > ADMIN_BOOKING_DRAFT_TTL_MS) {
      sessionStorage.removeItem(ADMIN_BOOKING_DRAFT_KEY);
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function saveAdminBookingDraft(draft: Omit<AdminBookingDraft, 'savedAt'>) {
  try {
    sessionStorage.setItem(ADMIN_BOOKING_DRAFT_KEY, JSON.stringify({ ...draft, savedAt: Date.now() }));
  } catch {
    // Best-effort — a full/blocked sessionStorage should never break the desk.
  }
}

function clearAdminBookingDraft() {
  try {
    sessionStorage.removeItem(ADMIN_BOOKING_DRAFT_KEY);
  } catch {
    // ignore
  }
}

interface PassengerRow {
  id: number;
  name: string;
  phone: string;
  age: string;
}
interface StopRow {
  id: number;
  text: string;
}
interface TripForm {
  trip_type: string;
  pickup_city: string;
  pickup_address: string;
  drop_city: string;
  drop_address: string;
  journey_date: string;
  journey_time: string;
  return_date: string;
  return_time: string;
  hours_required: string;
  vehicle_type_id: string;
  passengers: string;
  luggage_count: string;
  special_requests: string;
  flight_number: string;
  allow_past: boolean;
}
interface FareForm {
  base_fare: string;
  toll_charges: string;
  parking_charges: string;
  driver_allowance: string;
  extras: string;
  discount_amount: string;
  gst_mode: 'auto' | 'none' | 'custom';
  gst_amount: string;
  adjustment: string;
  adjustment_reason: string;
  /** Blank = use the standard booking amount from Settings. */
  booking_amount: string;
  booking_amount_reason: string;
}

const EMPTY_TRIP: TripForm = {
  trip_type: 'one_way', pickup_city: '', pickup_address: '', drop_city: '', drop_address: '', journey_date: '', journey_time: '', return_date: '', return_time: '',
  hours_required: '', vehicle_type_id: '', passengers: '1', luggage_count: '0', special_requests: '', flight_number: '', allow_past: false,
};

// TRACE: number-like text → finite number or 0 → number. Pure. Used to show live totals without trusting empty strings.
const n = (v: string): number => (v.trim() !== '' && Number.isFinite(Number(v)) ? Number(v) : 0);

// TRACE: route /app/admin/bookings/new[?client=ID|?enquiry=ID] → five-step back-office booking desk → creates a complete booking through POST /admin/bookings/create.
//        Step 1 client: search an existing client (name/mobile/email) or enter a new one (duplicate mobile/email is caught on blur AND by the server, which returns the
//        existing profile so the desk can switch to it). Step 2 trip: type-aware fields (round trip → return leg, local → hours, airport → flight), stops, passengers, dates.
//        Step 3 pricing: server quote (POST /admin/bookings/quote) filled into editable components, discount / GST / adjustment with a mandatory reason, live recalculation.
//        Step 4 dispatch and payment: booking source, optional vendor + driver + vehicle (incomplete driver profiles flagged), payment (pay later / awaiting / received now),
//        internal and client-visible notes. Step 5 review: everything in one place with warnings; Create sends once (button locked), 409 duplicate booking asks for an explicit
//        "create anyway", success navigates to the new booking. Edge cases: blocked client (banner, cannot proceed), past date (needs the back-entry tick), quote failure
//        (message, cannot proceed), stale quote after edits (recalculated before leaving the step), API errors (inline, form kept).
export function AdminBookingCreatePage() {
  const toast = useToast();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [opts, setOpts] = useState<FormOptions | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Draft resumption is skipped entirely when the URL explicitly names a
  // client or enquiry to prefill from — that's a fresh, deliberate
  // navigation (e.g. "New booking" from a client's profile) and should
  // win over an unrelated stale draft from an earlier, different booking.
  const [draft] = useState<AdminBookingDraft | null>(() =>
    params.get('client') || params.get('enquiry') ? null : loadAdminBookingDraft()
  );

  const [step, setStep] = useState(draft?.step ?? 0);

  // client
  const [clientMode, setClientMode] = useState<'existing' | 'new'>(draft?.clientMode ?? 'existing');
  const [picked, setPicked] = useState<ClientSummary | null>(draft?.picked ?? null);
  const [search, setSearch] = useState('');
  const [results, setResults] = useState<ClientRow[]>([]);
  const [searching, setSearching] = useState(false);
  const [newClient, setNewClient] = useState<ClientFormValues>(draft?.newClient ?? { ...EMPTY_CLIENT });
  const [newErrors, setNewErrors] = useState<ClientFormErrors>({});
  // trip
  const [trip, setTrip] = useState<TripForm>(draft?.trip ?? EMPTY_TRIP);
  const [stops, setStops] = useState<StopRow[]>(draft?.stops ?? []);
  const [pax, setPax] = useState<PassengerRow[]>(draft?.pax ?? []);
  const [tripErrors, setTripErrors] = useState<Record<string, string>>({});
  const idSeq = useRef(1);
  // pricing — never restored from the draft; always re-quoted live (see doc comment above).
  const [fare, setFare] = useState<FareBreakdown | null>(null);
  const [fareForm, setFareForm] = useState<FareForm | null>(null);
  const [quoteWarnings, setQuoteWarnings] = useState<string[]>([]);
  const [leadFeeEstimate, setLeadFeeEstimate] = useState<{ amount: number; formula: string; enabled: boolean } | null>(null);
  const [quoting, setQuoting] = useState(false);
  const [quoteError, setQuoteError] = useState<string | null>(null);
  const [fareDirty, setFareDirty] = useState(false);
  // dispatch + payment
  const [source, setSource] = useState(draft?.source ?? 'phone');
  const [vendorId, setVendorId] = useState(draft?.vendorId ?? '');
  const [assign, setAssign] = useState<AssignOptions | null>(null);
  const [driverId, setDriverId] = useState(draft?.driverId ?? '');
  const [vehicleId, setVehicleId] = useState(draft?.vehicleId ?? '');
  const [payMode, setPayMode] = useState<'collect_later' | 'awaiting_payment' | 'received' | 'waived'>(draft?.payMode ?? 'collect_later');
  const [waiveReason, setWaiveReason] = useState(draft?.waiveReason ?? '');
  const [payMethod, setPayMethod] = useState(draft?.payMethod ?? 'upi');
  const [payRef, setPayRef] = useState(draft?.payRef ?? '');
  const [internalNote, setInternalNote] = useState(draft?.internalNote ?? '');
  const [clientNote, setClientNote] = useState(draft?.clientNote ?? '');
  const [stepError, setStepError] = useState<string | null>(null);
  // submit
  const [creating, setCreating] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [dupBooking, setDupBooking] = useState<{ id: number; booking_number: string } | null>(null);
  const [dupClient, setDupClient] = useState<{ id: number; name?: string; phone?: string } | null>(null);
  const [enquiryId, setEnquiryId] = useState<number | null>(draft?.enquiryId ?? null);
  const bookingCreatedRef = useRef(false);

  // Whether there's anything worth persisting/warning about losing —
  // mirrors the guest wizard's hasProgress.
  const hasDeskProgress = Boolean(
    picked || search || trip.pickup_city || trip.drop_city || newClient.name || newClient.phone || vendorId || internalNote || clientNote
  );

  // Keep the persisted draft in sync with the live form (see the
  // ADMIN_BOOKING_DRAFT_KEY doc comment for what's excluded and why).
  useEffect(() => {
    if (bookingCreatedRef.current) return;
    if (!hasDeskProgress) {
      clearAdminBookingDraft();
      return;
    }
    saveAdminBookingDraft({
      step, clientMode, picked, newClient, trip, stops, pax, source, vendorId, driverId, vehicleId,
      payMode, waiveReason, payMethod, payRef, internalNote, clientNote, enquiryId,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    step, clientMode, picked, newClient, trip, stops, pax, source, vendorId, driverId, vehicleId,
    payMode, waiveReason, payMethod, payRef, internalNote, clientNote, enquiryId, hasDeskProgress,
  ]);

  // TRACE: mount → loads select data; ?client=ID preselects that client (profile fetched); ?enquiry=ID prefills client + trip from the enquiry. Failures show a banner and leave the form usable.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const o = await getFormOptions();
        if (cancelled) return;
        setOpts(o);
        const cid = Number(params.get('client'));
        const eid = Number(params.get('enquiry'));
        if (cid > 0) {
          const d = await getClientDetail(cid);
          if (!cancelled) {
            setPicked(d.client);
            setStep(1);
          }
        } else if (eid > 0) {
          const p = await getEnquiryPrefill(eid);
          if (cancelled) return;
          setEnquiryId(p.enquiry_id);
          setSource(p.source || 'phone');
          if (p.client) {
            setPicked(p.client);
          } else {
            setClientMode('new');
            setNewClient({ ...EMPTY_CLIENT, name: p.new_client.name, phone: p.new_client.phone, email: p.new_client.email, source: p.source || 'phone' });
          }
          setTrip((t) => ({
            ...t, trip_type: p.trip.trip_type || 'one_way', pickup_city: p.trip.pickup_city, drop_city: p.trip.drop_city, journey_date: p.trip.journey_date,
            passengers: String(p.trip.passengers || 1), vehicle_type_id: p.trip.vehicle_type_id ? String(p.trip.vehicle_type_id) : '', special_requests: p.trip.special_requests,
          }));
        }
      } catch (err) {
        if (!cancelled) setLoadError(errMessage(err, 'Could not load the booking desk. Please try again.'));
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [params]);

  // TRACE: client search box → debounced lookup (needs 2+ characters) → result list. Edge cases: lookup failure clears results silently; typing again supersedes the timer.
  useEffect(() => {
    if (clientMode !== 'existing' || search.trim().length < 2) {
      setResults([]);
      return;
    }
    const t = window.setTimeout(async () => {
      setSearching(true);
      try {
        setResults((await lookupClients(search.trim())).rows);
      } catch {
        setResults([]);
      } finally {
        setSearching(false);
      }
    }, 300);
    return () => window.clearTimeout(t);
  }, [search, clientMode]);

  // TRACE: vendor select change → loads that vendor's drivers/vehicles; clearing the vendor clears both. Edge cases: load failure → empty lists + inline note.
  useEffect(() => {
    setDriverId('');
    setVehicleId('');
    setAssign(null);
    if (!vendorId) return;
    let cancelled = false;
    getAssignOptions(Number(vendorId))
      .then((a) => {
        if (!cancelled) setAssign(a);
      })
      .catch(() => {
        if (!cancelled) setAssign({ vendor_type: '', drivers: [], vehicles: [] });
      });
    return () => {
      cancelled = true;
    };
  }, [vendorId]);

  // TRACE: form state → the trip fields exactly as the API expects them (numbers as numbers, blanks omitted, stops/passengers as lists) → object. Pure.
  const tripPayload = useCallback(() => {
    const p: Record<string, unknown> = {
      trip_type: trip.trip_type, pickup_city: trip.pickup_city.trim(), pickup_address: trip.pickup_address.trim(), drop_city: trip.trip_type === 'local' ? '' : trip.drop_city.trim(),
      drop_address: trip.drop_address.trim(), journey_date: trip.journey_date, journey_time: trip.journey_time, vehicle_type_id: Number(trip.vehicle_type_id) || 0,
      passengers: Number(trip.passengers) || 1, luggage_count: Number(trip.luggage_count) || 0, special_requests: trip.special_requests.trim(), flight_number: trip.flight_number.trim(),
      stops: stops.map((s) => s.text.trim()).filter(Boolean), allow_past: trip.allow_past,
      passenger_details: pax.filter((r) => r.name.trim() !== '').map((r) => ({ name: r.name.trim(), phone: r.phone.trim(), age: r.age.trim() === '' ? null : Number(r.age) })),
    };
    if (trip.trip_type === 'round_trip') {
      p.return_date = trip.return_date;
      p.return_time = trip.return_time;
    }
    if (trip.trip_type === 'local') p.hours_required = Number(trip.hours_required) || 0;
    return p;
  }, [trip, stops, pax]);

  // TRACE: fare form → the override object the API accepts (only filled fields) → FareOverrides. Pure. Edge cases: blank strings omitted so the auto price shows through.
  const overridesPayload = useCallback((f: FareForm): FareOverrides => ({
    base_fare: f.base_fare, toll_charges: f.toll_charges, parking_charges: f.parking_charges, driver_allowance: f.driver_allowance, extras: f.extras,
    discount_amount: f.discount_amount === '' ? 0 : f.discount_amount, gst_mode: f.gst_mode, gst_amount: f.gst_mode === 'custom' ? f.gst_amount : undefined,
    adjustment: f.adjustment === '' ? 0 : f.adjustment, adjustment_reason: f.adjustment_reason,
    booking_amount: f.booking_amount === '' ? undefined : f.booking_amount, booking_amount_reason: f.booking_amount === '' ? undefined : f.booking_amount_reason,
  }), []);

  // TRACE: "Recalculate" / entering step 3 / debounced edits → POST quote with the trip and (when `withOverrides`) the current fare form → fare + warnings stored; on the FIRST quote
  //        (or a reset) the form is filled from the server's numbers. Edge cases: server validation message shown inline (e.g. discount without a reason), stale responses dropped.
  const quoteSeq = useRef(0);
  const runQuote = useCallback(async (withOverrides: boolean, ff: FareForm | null) => {
    const my = ++quoteSeq.current;
    setQuoting(true);
    setQuoteError(null);
    try {
      const body: Record<string, unknown> = { ...tripPayload(), client_id: picked?.id };
      if (withOverrides && ff) body.fare = overridesPayload(ff);
      const r = await quoteBooking(body);
      if (my !== quoteSeq.current) return;
      setFare(r.fare);
      setQuoteWarnings(r.warnings);
      setLeadFeeEstimate(r.lead_fee_estimate ?? null);
      if (!withOverrides || !ff) {
        setFareForm({
          base_fare: String(r.fare.base_fare), toll_charges: String(r.fare.toll_charges), parking_charges: String(r.fare.parking_charges), driver_allowance: String(r.fare.driver_allowance),
          extras: String(r.fare.extras), discount_amount: r.fare.discount_amount ? String(r.fare.discount_amount) : '', gst_mode: 'auto', gst_amount: String(r.fare.gst_amount),
          adjustment: r.fare.adjustment ? String(r.fare.adjustment) : '', adjustment_reason: r.fare.adjustment_reason,
          booking_amount: '', booking_amount_reason: '',
        });
      }
      setFareDirty(false);
    } catch (err) {
      if (my === quoteSeq.current) {
        setQuoteError(errMessage(err, 'Could not price this trip. Check the route and vehicle.'));
        setFare(null);
      }
    } finally {
      if (my === quoteSeq.current) setQuoting(false);
    }
  }, [tripPayload, picked, overridesPayload]);

  const setT = (k: keyof TripForm, v: string | boolean) => setTrip((t) => ({ ...t, [k]: v }));
  const setF = (k: keyof FareForm, v: string) => {
    setFareForm((f) => (f ? { ...f, [k]: v } : f));
    setFareDirty(true);
  };

  // TRACE: step 1 "Next" → requires a chosen (non-blocked) client or a valid new-client form → step 2. Edge cases: blocked client refused with a message; new-client validation errors shown under each field.
  const validateClientStep = (): boolean => {
    if (clientMode === 'existing') {
      if (!picked) {
        setStepError('Search for a client and select them, or switch to "New client".');
        return false;
      }
      if (picked.status === 'blocked') {
        setStepError(`${picked.name} is blocked. Unblock the client from their profile first.`);
        return false;
      }
      return true;
    }
    const v = validateClientForm(newClient);
    setNewErrors(v);
    if (Object.keys(v).length > 0) {
      setStepError('Fix the highlighted client details.');
      return false;
    }
    return true;
  };

  // TRACE: step 2 "Next" → validates the trip locally (same rules as the server: route, date/time, vehicle, passengers, round-trip return, local hours, stops) → step 3. Edge cases: past date without back-entry.
  const validateTripStep = (): boolean => {
    const e: Record<string, string> = {};
    if (trip.pickup_city.trim() === '') e.pickup_city = 'Enter the pickup city or location.';
    if (trip.trip_type !== 'local' && trip.drop_city.trim() === '') e.drop_city = 'Enter the drop city or location.';
    if (trip.journey_date === '') e.journey_date = 'Choose the journey date.';
    if (trip.journey_time === '') e.journey_time = 'Choose the pickup time.';
    if (trip.journey_date && trip.journey_time && !trip.allow_past && new Date(`${trip.journey_date}T${trip.journey_time}`).getTime() < Date.now()) e.journey_date = 'That pickup time is in the past. Tick "back-entry" to record a trip that already happened.';
    if (trip.trip_type === 'round_trip') {
      if (trip.return_date === '') e.return_date = 'Choose the return date.';
      else if (trip.journey_date && `${trip.return_date}T${trip.return_time || '00:00'}` < `${trip.journey_date}T${trip.journey_time || '00:00'}`) e.return_date = 'The return cannot be before the outward journey.';
    }
    if (trip.trip_type === 'local' && !(n(trip.hours_required) >= 1 && n(trip.hours_required) <= 24)) e.hours_required = 'Enter the hours required (1 to 24).';
    if (!trip.vehicle_type_id) e.vehicle_type_id = 'Choose a vehicle type.';
    const p = Number(trip.passengers);
    if (!Number.isInteger(p) || p < 1 || p > 50) e.passengers = 'Passengers must be between 1 and 50.';
    else if (pax.filter((r) => r.name.trim() !== '').length > p) e.passengers = 'There are more passenger names than passengers.';
    setTripErrors(e);
    if (Object.keys(e).length > 0) {
      setStepError('Fix the highlighted trip details.');
      return false;
    }
    return true;
  };

  // TRACE: step 3 "Next" → recalculates with the current overrides so the review can never show a stale total, blocks on any server validation error → step 4.
  const validatePricingStep = async (): Promise<boolean> => {
    if (!fareForm) return false;
    await runQuote(true, fareForm);
    return quoteSeq.current > 0 && !quoteErrorRef.current;
  };
  const quoteErrorRef = useRef<string | null>(null);
  quoteErrorRef.current = quoteError;

  // TRACE: step 4 "Next" → validates payment details (amount 0 < x ≤ total, UTR for UPI/bank/cheque, no vendor with "awaiting payment", complete-driver warning is advisory) → step 5.
  const validateDispatchStep = (): boolean => {
        const ba = fare?.booking_amount ?? 0;
    if (payMode === 'received') {
      if (!(ba > 0)) return setStepError('No booking amount is due for this ride, so there is nothing to record as received. Choose "Waive" instead.'), false;
      if (['upi', 'bank_transfer', 'cheque'].includes(payMethod) && payRef.trim() === '') return setStepError('Enter the UTR, transaction or cheque number.'), false;
    }
    if (payMode === 'waived' && ba > 0 && waiveReason.trim() === '') return setStepError('Give a reason for confirming without a booking amount.'), false;
    if (payMode === 'awaiting_payment' && vendorId) return setStepError('Assign a vendor after the booking amount is received. Choose "Collect later", "Received now" or "Waive" to assign now.'), false;
    if (driverId && assign?.drivers.find((d) => String(d.id) === driverId && !d.profile_complete)) {
      return setStepError('That driver\'s profile is incomplete and cannot be assigned. Pick another driver or complete the profile first.'), false;
    }
    return true;
  };

  // TRACE: Next click → runs the current step's validation (step 3 awaits a fresh quote) → advances and scrolls to top; step 2→3 triggers the first quote. Preconditions: not already busy.
  const next = async () => {
    setStepError(null);
    if (step === 0 && !validateClientStep()) return;
    if (step === 1) {
      if (!validateTripStep()) return;
      setStep(2);
      window.scrollTo({ top: 0 });
      await runQuote(false, null);
      return;
    }
    if (step === 2) {
      if (quoting) return;
      if (!(await validatePricingStep())) {
        setStepError((prev) => prev ?? 'Fix the pricing details before continuing.');
        return;
      }
    }
    if (step === 3 && !validateDispatchStep()) return;
    setStep((s) => Math.min(STEPS.length - 1, s + 1));
    window.scrollTo({ top: 0 });
  };

  const back = () => {
    setStepError(null);
    setStep((s) => Math.max(0, s - 1));
    window.scrollTo({ top: 0 });
  };

  // TRACE: Review → Create click → POST create once (locked while pending) → success: toast (+warnings) and navigate to the booking; 409 duplicate booking: shows an explicit
  //        "create anyway"; 409 duplicate client: offers to switch to that profile; other errors inline. Inputs are kept on every failure.
  const create = async (confirmDuplicate: boolean) => {
    if (creating || !fare || !fareForm) return;
    setCreating(true);
    setSubmitError(null);
    setDupBooking(null);
    setDupClient(null);
    const body = {
      ...(tripPayload() as unknown as CreateBookingInput),
      ...(clientMode === 'existing' && picked ? { client_id: picked.id } : { new_client: { ...newClient, source } }),
      booking_source: source,
      fare: overridesPayload(fareForm),
      payment: { mode: payMode, amount: payMode === 'received' ? fare.booking_amount : undefined, method: payMode === 'collect_later' || payMode === 'waived' ? 'upi' : payMethod, reference: payRef.trim(), reason: payMode === 'waived' ? waiveReason.trim() : undefined },
      vendor_id: vendorId ? Number(vendorId) : undefined,
      driver_id: driverId ? Number(driverId) : undefined,
      vehicle_id: vehicleId ? Number(vehicleId) : undefined,
      internal_note: internalNote.trim() || undefined,
      client_note: clientNote.trim() || undefined,
      enquiry_id: enquiryId ?? undefined,
      confirm_duplicate: confirmDuplicate,
    } as CreateBookingInput;
    try {
      const res = await createAdminBooking(body);
      toast.show(res.message, 'success');
      res.warnings.forEach((w) => toast.show(w, 'info'));
      bookingCreatedRef.current = true;
      clearAdminBookingDraft();
      navigate(`/app/admin/bookings/${res.booking_id}`);
    } catch (err) {
      setSubmitError(errMessage(err, 'Could not create the booking. Please try again.'));
      if (err instanceof ApiError && err.code === 'duplicate_booking') setDupBooking(duplicateOf(err) as { id: number; booking_number: string } | null);
      if (err instanceof ApiError && err.code === 'duplicate_client') setDupClient(duplicateOf(err));
    } finally {
      setCreating(false);
    }
  };

  const vehicleName = useMemo(() => opts?.vehicle_types.find((v) => String(v.id) === trip.vehicle_type_id)?.name ?? '', [opts, trip.vehicle_type_id]);
  const vendorName = useMemo(() => opts?.vendors.find((v) => String(v.id) === vendorId)?.name ?? '', [opts, vendorId]);
  const liveTotal = useMemo(() => {
    if (!fareForm || !fare) return fare?.total_fare ?? 0;
    const sub = n(fareForm.base_fare) + n(fareForm.toll_charges) + n(fareForm.parking_charges) + n(fareForm.driver_allowance) + n(fareForm.extras);
    const disc = n(fareForm.discount_amount);
    const gst = fareForm.gst_mode === 'none' ? 0 : fareForm.gst_mode === 'custom' ? n(fareForm.gst_amount) : Math.round((sub - disc) * fare.gst_percent) / 100;
    return Math.round((sub - disc + gst + n(fareForm.adjustment)) * 100) / 100;
  }, [fareForm, fare]);

  if (loadError) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-6">
        <ErrorBanner message={loadError} onRetry={() => window.location.reload()} />
      </div>
    );
  }
  if (!opts) {
    return (
      <div className="mx-auto max-w-3xl space-y-3 px-4 py-6" aria-busy="true" aria-label="Loading booking desk">
        <Skeleton className="h-10 w-1/2" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  const fld = (k: keyof TripForm) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setT(k, e.target.value);
  const num = (k: keyof FareForm, label: string) => (
    <FormField label={label} htmlFor={`f-${k}`}>
      <input id={`f-${k}`} type="number" inputMode="decimal" min={k === 'adjustment' ? undefined : 0} step="0.01" value={fareForm?.[k] ?? ''} onChange={(e) => setF(k, e.target.value)} className={INPUT_CLASS} disabled={quoting} />
    </FormField>
  );

  return (
    <div className="mx-auto max-w-4xl px-4 py-6 sm:px-6">
      <Link to="/admin/bookings" className="text-sm font-medium text-brand-700 hover:underline">
        ← All bookings
      </Link>
      <h1 className="mt-2 text-2xl font-bold text-ink-900 sm:text-3xl">New booking</h1>
      <p className="mt-1 text-sm text-ink-600">Create a complete booking for a client who called, messaged or walked in.</p>

      <ol className="mt-5 flex gap-1 overflow-x-auto pb-1" aria-label="Booking steps">
        {STEPS.map((s, i) => (
          <li key={s} className="flex-1" aria-current={i === step ? 'step' : undefined}>
            <div className={`rounded-lg px-2 py-2 text-center text-xs font-medium sm:text-sm ${i === step ? 'bg-brand-600 text-white' : i < step ? 'bg-brand-50 text-brand-700' : 'bg-ink-100 text-ink-600'}`}>
              {i + 1}. {s}
            </div>
          </li>
        ))}
      </ol>

      <div className="mt-5 space-y-5 rounded-xl border border-ink-100 bg-white p-4 shadow-xs sm:p-6">
        {/* STEP 1: client */}
        {step === 0 && (
          <div className="space-y-4">
            <div className="flex gap-2" role="tablist" aria-label="Client choice">
              {(['existing', 'new'] as const).map((m) => (
                <button key={m} type="button" role="tab" aria-selected={clientMode === m} onClick={() => { setClientMode(m); setStepError(null); }}
                  className={`rounded-lg border px-4 py-2 text-sm font-medium ${clientMode === m ? 'border-brand-600 bg-brand-50 text-brand-700' : 'border-ink-200 text-ink-700 hover:bg-ink-50'}`}>
                  {m === 'existing' ? 'Existing client' : 'New client'}
                </button>
              ))}
            </div>
            {clientMode === 'existing' ? (
              <div className="space-y-3">
                {picked ? (
                  <div className="flex flex-wrap items-start justify-between gap-3 rounded-xl border border-brand-200 bg-brand-50 p-4">
                    <div>
                      <p className="font-semibold text-ink-900">{picked.name}</p>
                      <p className="text-sm text-ink-700">{[picked.phone, picked.email, picked.company_name].filter(Boolean).join(' · ')}</p>
                      {picked.status === 'blocked' && <p className="mt-1 text-sm font-medium text-danger-600">This client is blocked.</p>}
                    </div>
                    <Button variant="secondary" size="sm" onClick={() => { setPicked(null); setSearch(''); }}>
                      Change client
                    </Button>
                  </div>
                ) : (
                  <>
                    <FormField label="Find a client by name, mobile or email" htmlFor="client-search">
                      <input id="client-search" type="search" value={search} onChange={(e) => setSearch(e.target.value)} className={INPUT_CLASS} autoComplete="off" />
                    </FormField>
                    {searching && <p className="text-sm text-ink-500">Searching…</p>}
                    {!searching && search.trim().length >= 2 && results.length === 0 && (
                      <p className="text-sm text-ink-600">
                        No client found. <button type="button" className="font-medium text-brand-700 underline" onClick={() => { setClientMode('new'); setNewClient((c) => ({ ...c, phone: /\d{5,}/.test(search) ? search : c.phone, name: /\d{5,}/.test(search) ? c.name : search })); }}>Create a new client</button>
                      </p>
                    )}
                    <ul className="space-y-2">
                      {results.map((r) => (
                        <li key={r.id}>
                          <button type="button" onClick={() => { setPicked(r); setStepError(null); }} className="w-full rounded-xl border border-ink-100 p-3 text-left hover:border-brand-300 hover:bg-brand-50/40">
                            <span className="font-medium text-ink-900">{r.name}</span>{' '}
                            {r.status === 'blocked' && <ToneBadge tone="danger">Blocked</ToneBadge>}
                            <span className="block text-sm text-ink-600">{[r.phone, r.email, r.client_type === 'corporate' ? r.company_name : ''].filter(Boolean).join(' · ')} · {r.bookings} booking{r.bookings === 1 ? '' : 's'}</span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  </>
                )}
              </div>
            ) : (
              <ClientFields values={newClient} errors={newErrors} onChange={(p) => setNewClient((c) => ({ ...c, ...p }))} idPrefix="bk-cl"
                onUseExisting={(m) => { setPicked(m); setClientMode('existing'); setStepError(null); }} showSource={false} />
            )}
          </div>
        )}

        {/* STEP 2: trip */}
        {step === 1 && (
          <div className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField label="Trip type" htmlFor="t-type">
                <select id="t-type" value={trip.trip_type} onChange={fld('trip_type')} className={INPUT_CLASS}>
                  {opts.trip_types.map((t) => (
                    <option key={t} value={t}>{TRIP_TYPE_LABELS[t] ?? t}</option>
                  ))}
                </select>
              </FormField>
              <FormField label="Vehicle type" htmlFor="t-veh" error={tripErrors.vehicle_type_id}>
                <select id="t-veh" value={trip.vehicle_type_id} onChange={fld('vehicle_type_id')} className={INPUT_CLASS}>
                  <option value="">Select vehicle</option>
                  {opts.vehicle_types.map((v) => (
                    <option key={v.id} value={v.id}>{v.name} ({v.seats} seats)</option>
                  ))}
                </select>
              </FormField>
            </div>
            <datalist id="city-list">{opts.cities.map((c) => <option key={c} value={c} />)}</datalist>
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField label="Pickup city / location" htmlFor="t-pc" error={tripErrors.pickup_city}>
                <input id="t-pc" list="city-list" value={trip.pickup_city} onChange={fld('pickup_city')} className={INPUT_CLASS} autoComplete="off" />
              </FormField>
              {trip.trip_type !== 'local' && (
                <FormField label="Drop city / location" htmlFor="t-dc" error={tripErrors.drop_city}>
                  <input id="t-dc" list="city-list" value={trip.drop_city} onChange={fld('drop_city')} className={INPUT_CLASS} autoComplete="off" />
                </FormField>
              )}
              <FormField label="Pickup address (optional)" htmlFor="t-pa">
                <input id="t-pa" value={trip.pickup_address} onChange={fld('pickup_address')} className={INPUT_CLASS} />
              </FormField>
              {trip.trip_type !== 'local' && (
                <FormField label="Drop address (optional)" htmlFor="t-da">
                  <input id="t-da" value={trip.drop_address} onChange={fld('drop_address')} className={INPUT_CLASS} />
                </FormField>
              )}
            </div>
            {trip.trip_type !== 'local' && (
              <fieldset className="rounded-xl border border-ink-100 p-3">
                <legend className="px-1 text-sm font-medium text-ink-800">Stops on the way (optional)</legend>
                {stops.map((s, i) => (
                  <div key={s.id} className="mb-2 flex gap-2">
                    <input aria-label={`Stop ${i + 1}`} list="city-list" value={s.text} onChange={(e) => setStops((prev) => prev.map((x) => (x.id === s.id ? { ...x, text: e.target.value } : x)))} className={INPUT_CLASS} />
                    <Button type="button" variant="ghost" size="sm" aria-label={`Remove stop ${i + 1}`} onClick={() => setStops((prev) => prev.filter((x) => x.id !== s.id))}>Remove</Button>
                  </div>
                ))}
                <Button type="button" variant="secondary" size="sm" disabled={stops.length >= 10} onClick={() => setStops((p) => [...p, { id: idSeq.current++, text: '' }])}>Add a stop</Button>
              </fieldset>
            )}
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField label="Journey date" htmlFor="t-jd" error={tripErrors.journey_date}>
                <input id="t-jd" type="date" value={trip.journey_date} onChange={fld('journey_date')} className={INPUT_CLASS} />
              </FormField>
              <FormField label="Pickup time" htmlFor="t-jt" error={tripErrors.journey_time}>
                <input id="t-jt" type="time" value={trip.journey_time} onChange={fld('journey_time')} className={INPUT_CLASS} />
              </FormField>
              {trip.trip_type === 'round_trip' && (
                <>
                  <FormField label="Return date" htmlFor="t-rd" error={tripErrors.return_date}>
                    <input id="t-rd" type="date" value={trip.return_date} onChange={fld('return_date')} className={INPUT_CLASS} />
                  </FormField>
                  <FormField label="Return pickup time (optional)" htmlFor="t-rt">
                    <input id="t-rt" type="time" value={trip.return_time} onChange={fld('return_time')} className={INPUT_CLASS} />
                  </FormField>
                </>
              )}
              {trip.trip_type === 'local' && (
                <FormField label="Hours required" htmlFor="t-h" error={tripErrors.hours_required}>
                  <input id="t-h" type="number" min={1} max={24} value={trip.hours_required} onChange={fld('hours_required')} className={INPUT_CLASS} />
                </FormField>
              )}
              {(trip.trip_type === 'airport_pickup' || trip.trip_type === 'airport_drop') && (
                <FormField label="Flight number (optional)" htmlFor="t-fl">
                  <input id="t-fl" value={trip.flight_number} onChange={fld('flight_number')} className={INPUT_CLASS} />
                </FormField>
              )}
            </div>
            <label className="flex items-center gap-2 text-sm text-ink-700">
              <input type="checkbox" checked={trip.allow_past} onChange={(e) => setT('allow_past', e.target.checked)} />
              Back-entry: record a trip whose pickup time has already passed
            </label>
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField label="Passengers" htmlFor="t-px" error={tripErrors.passengers}>
                <input id="t-px" type="number" min={1} max={50} value={trip.passengers} onChange={fld('passengers')} className={INPUT_CLASS} />
              </FormField>
              <FormField label="Luggage pieces" htmlFor="t-lg">
                <input id="t-lg" type="number" min={0} value={trip.luggage_count} onChange={fld('luggage_count')} className={INPUT_CLASS} />
              </FormField>
            </div>
            <fieldset className="rounded-xl border border-ink-100 p-3">
              <legend className="px-1 text-sm font-medium text-ink-800">Passenger details (optional)</legend>
              {pax.map((r, i) => (
                <div key={r.id} className="mb-2 grid gap-2 sm:grid-cols-[1fr_1fr_5rem_auto]">
                  <input aria-label={`Passenger ${i + 1} name`} placeholder="Name" value={r.name} onChange={(e) => setPax((p) => p.map((x) => (x.id === r.id ? { ...x, name: e.target.value } : x)))} className={INPUT_CLASS} />
                  <input aria-label={`Passenger ${i + 1} phone`} placeholder="Phone" type="tel" value={r.phone} onChange={(e) => setPax((p) => p.map((x) => (x.id === r.id ? { ...x, phone: e.target.value } : x)))} className={INPUT_CLASS} />
                  <input aria-label={`Passenger ${i + 1} age`} placeholder="Age" type="number" min={0} max={120} value={r.age} onChange={(e) => setPax((p) => p.map((x) => (x.id === r.id ? { ...x, age: e.target.value } : x)))} className={INPUT_CLASS} />
                  <Button type="button" variant="ghost" size="sm" aria-label={`Remove passenger ${i + 1}`} onClick={() => setPax((p) => p.filter((x) => x.id !== r.id))}>Remove</Button>
                </div>
              ))}
              <Button type="button" variant="secondary" size="sm" disabled={pax.length >= 20} onClick={() => setPax((p) => [...p, { id: idSeq.current++, name: '', phone: '', age: '' }])}>Add a passenger</Button>
            </fieldset>
            <FormField label="Special requirements or instructions (shown to the driver)" htmlFor="t-sr">
              <textarea id="t-sr" rows={3} value={trip.special_requests} onChange={fld('special_requests')} className={INPUT_CLASS} />
            </FormField>
          </div>
        )}

        {/* STEP 3: pricing */}
        {step === 2 && (
          <div className="space-y-4">
            {quoteError && <ErrorBanner message={quoteError} onRetry={() => void runQuote(false, null)} />}
            {quoting && !fareForm && <Skeleton className="h-40 w-full" />}
            {fareForm && fare && (
              <>
                <p className="text-sm text-ink-600">
                  Priced by the standard fare engine ({fare.distance_km > 0 ? `${fare.distance_km} km` : 'distance from the route'}). Change any component below to negotiate; every change is recorded in the audit log.
                </p>
                <div className="grid gap-4 sm:grid-cols-2">
                  {num('base_fare', 'Base fare (₹)')}
                  {num('toll_charges', 'Toll (₹)')}
                  {num('parking_charges', 'Parking (₹)')}
                  {num('driver_allowance', 'Driver allowance (₹)')}
                  {num('extras', 'Night, surge and extra charges (₹)')}
                  {num('discount_amount', 'Discount (₹)')}
                  <FormField label="GST" htmlFor="f-gst">
                    <select id="f-gst" value={fareForm.gst_mode} onChange={(e) => setF('gst_mode', e.target.value)} className={INPUT_CLASS}>
                      <option value="auto">Automatic ({fare.gst_percent}%)</option>
                      <option value="none">No GST</option>
                      <option value="custom">Custom amount</option>
                    </select>
                  </FormField>
                  {fareForm.gst_mode === 'custom' && num('gst_amount', 'GST amount (₹)')}
                  {num('adjustment', 'Adjustment (₹, may be negative)')}
                  <FormField label="Reason for discount or adjustment" htmlFor="f-reason" hint="Required when a discount or adjustment is entered.">
                    <input id="f-reason" type="text" value={fareForm.adjustment_reason} onChange={(e) => setF('adjustment_reason', e.target.value)} className={INPUT_CLASS} />
                  </FormField>
                </div>
                <div className="grid gap-4 rounded-xl border border-ink-100 p-3 sm:grid-cols-2">
                  <FormField label={`Booking amount collected by ${brand().name} (₹)`} htmlFor="f-ba" hint={`Standard ${inr(fare.booking_amount_default)}. Leave blank to use the standard amount; 0 waives it. The vendor/driver collects the rest.`}>
                    <input id="f-ba" type="number" inputMode="decimal" min={0} step="0.01" value={fareForm.booking_amount} placeholder={String(fare.booking_amount_default)} onChange={(e) => setF('booking_amount', e.target.value)} className={INPUT_CLASS} />
                  </FormField>
                  <FormField label="Reason for changing the booking amount" htmlFor="f-ba-reason" hint="Required when it differs from the standard amount.">
                    <input id="f-ba-reason" type="text" value={fareForm.booking_amount_reason} onChange={(e) => setF('booking_amount_reason', e.target.value)} className={INPUT_CLASS} />
                  </FormField>
                </div>
                <div className="rounded-xl bg-ink-50 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-sm text-ink-600">Estimated ride fare {fareDirty ? '(preview, recalculate to confirm)' : ''}</p>
                      <p className="text-2xl font-bold text-ink-900" aria-live="polite">{inr(fareDirty ? liveTotal : fare.total_fare)}</p>
                      <p className="text-xs text-ink-500">Standard price {inr(fare.auto_total)}{fare.overridden ? ' · manually adjusted' : ''}</p>
                      <p className="text-xs text-ink-500">Booking amount to {brand().name} {inr(fare.booking_amount)} · payable to vendor/driver {inr(fare.payable_to_vendor)}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button type="button" variant="secondary" size="sm" loading={quoting} onClick={() => void runQuote(true, fareForm)}>Recalculate</Button>
                      <Button type="button" variant="ghost" size="sm" disabled={quoting} onClick={() => void runQuote(false, null)}>Reset to standard price</Button>
                    </div>
                  </div>
                  {fare.exclusions.length > 0 && <p className="mt-3 text-xs text-ink-500">Not included: {fare.exclusions.join(', ')}</p>}
                </div>
                {quoteWarnings.map((w) => (
                  <p key={w} role="status" className="rounded-lg border border-warning-500/30 bg-warning-50 p-3 text-sm text-warning-700">{w}</p>
                ))}
              </>
            )}
          </div>
        )}

        {/* STEP 4: dispatch + payment */}
        {step === 3 && (
          <div className="space-y-5">
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField label="Booking source" htmlFor="d-src">
                <select id="d-src" value={source} onChange={(e) => setSource(e.target.value)} className={INPUT_CLASS}>
                  {opts.sources.map((s) => (
                    <option key={s} value={s}>{SOURCE_LABELS[s] ?? s}</option>
                  ))}
                </select>
              </FormField>
            </div>
            <fieldset className="space-y-3 rounded-xl border border-ink-100 p-3">
              <legend className="px-1 text-sm font-medium text-ink-800">Vendor, driver and vehicle (optional)</legend>
              <p className="text-sm text-ink-600">Leave empty to send the trip to matching vendors as usual. Choose a vendor to assign it directly.</p>
              <div className="grid gap-4 sm:grid-cols-3">
                <FormField label="Vendor" htmlFor="d-vendor">
                  <SearchableSelect
                    id="d-vendor"
                    aria-label="Vendor"
                    value={vendorId}
                    onChange={setVendorId}
                    placeholder="Search vendors by name, phone or city"
                    emptyOptionLabel="Send to vendors"
                    options={opts.vendors.map((v) => ({
                      value: String(v.id),
                      label: `${v.name} (${v.vendor_type})`,
                      searchText: `${v.phone} ${v.city}`,
                      description: `${v.city}${v.phone ? ` · ${v.phone}` : ''}`,
                    }))}
                  />
                </FormField>
                <FormField label="Driver" htmlFor="d-driver">
                  <select id="d-driver" value={driverId} onChange={(e) => setDriverId(e.target.value)} className={INPUT_CLASS} disabled={!vendorId || !assign}>
                    <option value="">Vendor decides</option>
                    {assign?.drivers.map((d) => (
                      <option key={d.id} value={d.id} disabled={!d.profile_complete}>{d.name}{d.profile_complete ? '' : ' (profile incomplete)'}</option>
                    ))}
                  </select>
                </FormField>
                <FormField label="Vehicle" htmlFor="d-vehicle">
                  <select id="d-vehicle" value={vehicleId} onChange={(e) => setVehicleId(e.target.value)} className={INPUT_CLASS} disabled={!vendorId || !assign}>
                    <option value="">Vendor decides</option>
                    {assign?.vehicles.map((v) => (
                      <option key={v.id} value={v.id}>{v.label || v.registration_number}</option>
                    ))}
                  </select>
                </FormField>
              </div>
            </fieldset>
            <fieldset className="space-y-3 rounded-xl border border-ink-100 p-3">
              <legend className="px-1 text-sm font-medium text-ink-800">Booking amount ({brand().name} collects only this)</legend>
              <p className="text-sm text-ink-600">
                Booking amount {inr(fare?.booking_amount)} of the estimated ride fare {inr(fare?.total_fare)}. The vendor/driver bills the client for the rest ({inr(fare?.payable_to_vendor)}) and collects it directly.
              </p>
              {([
                ['collect_later', 'Collect later', 'Booking is confirmed now; ' + brand().name + ' collects the booking amount later.'],
                ['received', 'Received now', 'The client has already paid the booking amount to ' + brand().name + '.'],
                ['awaiting_payment', 'Awaiting payment', 'Hold the booking until the client pays the booking amount (uses the normal payment deadline).'],
                ['waived', 'Waive the booking amount', 'Confirm with no booking amount. A reason is recorded in the audit log.'],
              ] as const).map(([k, label, hint]) => (
                <label key={k} className="flex cursor-pointer items-start gap-2 text-sm">
                  <input type="radio" name="paymode" checked={payMode === k} onChange={() => setPayMode(k)} className="mt-1" />
                  <span><span className="font-medium text-ink-900">{label}</span><span className="block text-ink-600">{hint}</span></span>
                </label>
              ))}
              {payMode === 'waived' && (
                <FormField label="Reason for waiving" htmlFor="p-waive">
                  <input id="p-waive" value={waiveReason} onChange={(e) => setWaiveReason(e.target.value)} className={INPUT_CLASS} />
                </FormField>
              )}
              {(payMode === 'received' || payMode === 'awaiting_payment') && (
                <div className="grid gap-4 sm:grid-cols-2">
                  <FormField label="Method" htmlFor="p-method">
                    <select id="p-method" value={payMethod} onChange={(e) => setPayMethod(e.target.value)} className={INPUT_CLASS}>
                      {opts.payment_methods.filter((m) => m !== 'razorpay').map((m) => (
                        <option key={m} value={m}>{METHOD_LABELS[m] ?? m}</option>
                      ))}
                    </select>
                  </FormField>
                  {payMode === 'received' && (
                    <FormField label="UTR / reference" htmlFor="p-ref">
                      <input id="p-ref" value={payRef} onChange={(e) => setPayRef(e.target.value)} className={INPUT_CLASS} />
                    </FormField>
                  )}
                </div>
              )}
            </fieldset>
            <FormField label="Internal note (never visible to the client)" htmlFor="n-int">
              <textarea id="n-int" rows={2} value={internalNote} onChange={(e) => setInternalNote(e.target.value)} className={INPUT_CLASS} />
            </FormField>
            <FormField label="Note visible to the client (optional)" htmlFor="n-cli">
              <textarea id="n-cli" rows={2} value={clientNote} onChange={(e) => setClientNote(e.target.value)} className={INPUT_CLASS} />
            </FormField>
          </div>
        )}

        {/* STEP 5: review */}
        {step === 4 && fare && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-ink-900">Review before creating</h2>
            <dl className="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
              <div><dt className="text-ink-500">Client</dt><dd className="font-medium text-ink-900">{clientMode === 'existing' ? picked?.name : `${newClient.name} (new client)`}<span className="block font-normal text-ink-600">{clientMode === 'existing' ? picked?.phone : newClient.phone}</span></dd></div>
              <div><dt className="text-ink-500">Source</dt><dd className="font-medium text-ink-900">{SOURCE_LABELS[source] ?? source}</dd></div>
              <div><dt className="text-ink-500">Trip</dt><dd className="font-medium text-ink-900">{TRIP_TYPE_LABELS[trip.trip_type]} · {trip.pickup_city}{trip.trip_type !== 'local' ? ` → ${trip.drop_city}` : ` · ${trip.hours_required} hours`}{stops.filter((s) => s.text.trim()).length > 0 ? ` via ${stops.map((s) => s.text.trim()).filter(Boolean).join(', ')}` : ''}</dd></div>
              <div><dt className="text-ink-500">When</dt><dd className="font-medium text-ink-900">{trip.journey_date} at {trip.journey_time}{trip.trip_type === 'round_trip' ? ` · returns ${trip.return_date}${trip.return_time ? ` ${trip.return_time}` : ''}` : ''}</dd></div>
              <div><dt className="text-ink-500">Vehicle and passengers</dt><dd className="font-medium text-ink-900">{vehicleName} · {trip.passengers} passenger{trip.passengers === '1' ? '' : 's'}</dd></div>
              <div><dt className="text-ink-500">Dispatch</dt><dd className="font-medium text-ink-900">{vendorName ? `Assign to ${vendorName}` : 'Send to matching vendors'}</dd></div>
              <div><dt className="text-ink-500">Estimated ride fare</dt><dd className="text-lg font-bold text-ink-900">{inr(fare.total_fare)}{fare.overridden && <span className="ml-2 text-xs font-normal text-warning-600">manually adjusted (standard {inr(fare.auto_total)})</span>}</dd></div>
              <div><dt className="text-ink-500">Booking amount ({brand().name})</dt><dd className="font-medium text-ink-900">{payMode === 'collect_later' ? `${inr(fare.booking_amount)} — collect later` : payMode === 'awaiting_payment' ? `${inr(fare.booking_amount)} — awaiting payment by ${METHOD_LABELS[payMethod] ?? payMethod}` : payMode === 'waived' ? `Waived (${waiveReason || 'no reason'})` : `${inr(fare.booking_amount)} received by ${METHOD_LABELS[payMethod] ?? payMethod}`}<span className="block font-normal text-ink-600">Payable to vendor/driver: {inr(fare.payable_to_vendor)}</span></dd></div>
            </dl>
            {(internalNote || clientNote) && (
              <div className="text-sm text-ink-700">
                {internalNote && <p><span className="font-medium">Internal note:</span> {internalNote}</p>}
                {clientNote && <p><span className="font-medium">Client-visible note:</span> {clientNote}</p>}
              </div>
            )}
            {leadFeeEstimate?.enabled && (
              <p className="rounded-lg bg-ink-50 p-3 text-sm text-ink-700">
                Estimated vendor lead fee: <span className="font-semibold">₹{leadFeeEstimate.amount.toLocaleString('en-IN')}</span>. {leadFeeEstimate.formula} This is shown to staff and vendors only; it is confirmed when a vendor is assigned.
              </p>
            )}
            <p className="text-sm text-ink-600">Creating this booking sends the client a confirmation and, unless a vendor was chosen, sends the trip to matching vendors.</p>
            {quoteWarnings.map((w) => (
              <p key={w} role="status" className="rounded-lg border border-warning-500/30 bg-warning-50 p-3 text-sm text-warning-700">{w}</p>
            ))}
            {submitError && (
              <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 p-3 text-sm text-danger-600">
                <p>{submitError}</p>
                {dupBooking && (
                  <p className="mt-2 flex flex-wrap gap-3">
                    <Link to={`/app/admin/bookings/${dupBooking.id}`} className="font-medium underline" target="_blank" rel="noreferrer">Open {dupBooking.booking_number}</Link>
                    <button type="button" className="font-medium underline" onClick={() => void create(true)}>Create another booking anyway</button>
                  </p>
                )}
                {dupClient && (
                  <p className="mt-2">
                    <button type="button" className="font-medium underline" onClick={() => { setPicked({ id: dupClient.id, name: dupClient.name ?? 'Existing client', phone: dupClient.phone ?? '', email: '', alt_phone: '', client_type: 'individual', company_name: '', status: 'active', merged_into: null, merged_at: null }); setClientMode('existing'); setStep(0); setSubmitError(null); }}>Use the existing client instead</button>
                  </p>
                )}
              </div>
            )}
          </div>
        )}

        {stepError && (
          <p role="alert" className="text-sm font-medium text-danger-600">{stepError}</p>
        )}

        <div className="flex flex-wrap justify-between gap-3 border-t border-ink-100 pt-4">
          <Button type="button" variant="secondary" onClick={back} disabled={step === 0 || creating}>Back</Button>
          {step < STEPS.length - 1 ? (
            <Button type="button" onClick={() => void next()} loading={quoting && step === 2}>Next</Button>
          ) : (
            <Button type="button" onClick={() => void create(false)} loading={creating}>Create booking</Button>
          )}
        </div>
      </div>
    </div>
  );
}
