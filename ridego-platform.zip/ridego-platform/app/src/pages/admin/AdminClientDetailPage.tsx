import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  errMessage,
  getClientDetail,
  inr,
  lookupClients,
  mergeClient,
  METHOD_LABELS,
  setClientStatus,
  SOURCE_LABELS,
  TRIP_TYPE_LABELS,
  updateClient,
  duplicateOf,
  type ClientDetailResponse,
  type ClientRow,
} from '../../lib/api-admin-crm';
import { ClientFields, validateClientForm, type ClientFormErrors, type ClientFormValues } from '../../components/admin/ClientFields';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';
import { hasAdminCap } from '../../lib/permissions';
import { FormField, INPUT_CLASS, ToneBadge, formatDateTime } from '../vendor-mkt/vendor-mkt-shared';
import { brand } from '../../lib/brand';

type Tab = 'bookings' | 'payments' | 'enquiries' | 'complaints';

// TRACE: route /app/admin/clients/:id → complete client profile: contact details, internal notes, lifetime numbers (bookings, billed, paid, outstanding),
//        booking history, payment/refund ledger, enquiries and complaints, plus Edit, Block/Unblock and "New booking" actions → GET, then PUT / POST status.
//        Edit validates like the create form, sends only the form's fields, keeps the sheet open with the server's message on failure (duplicate mobile/email
//        names the other profile). Block needs a reason (dialog) and shows a banner; unblock is one click. Everything refetches after a write so the page never
//        shows stale values. Edge cases: unknown id (not-found banner), no history (per-tab empty states), double clicks (loading flags), non-admin (403 banner).
export function AdminClientDetailPage() {
  const { id } = useParams();
  const clientId = Number(id);
  const toast = useToast();
  const { user } = useAuth();
  const canBook = hasAdminCap(user, 'ridego_create_admin_booking');
  const [data, setData] = useState<ClientDetailResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('bookings');
  const [editOpen, setEditOpen] = useState(false);
  const [form, setForm] = useState<ClientFormValues | null>(null);
  const [errors, setErrors] = useState<ClientFormErrors>({});
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [dupId, setDupId] = useState<number | null>(null);
  const [blockOpen, setBlockOpen] = useState(false);
  const [blockReason, setBlockReason] = useState('');
  const [statusBusy, setStatusBusy] = useState(false);
  const [mergeOpen, setMergeOpen] = useState(false);
  const [mergeQuery, setMergeQuery] = useState('');
  const [mergeResults, setMergeResults] = useState<ClientRow[]>([]);
  const [mergeTarget, setMergeTarget] = useState<ClientRow | null>(null);
  const [mergeConfirmOpen, setMergeConfirmOpen] = useState(false);
  const [mergeBusy, setMergeBusy] = useState(false);
  const [mergeError, setMergeError] = useState<string | null>(null);

  // TRACE: mount / after any write → GET profile → data set or error banner. Edge cases: invalid id → banner without a request.
  const load = useCallback(async () => {
    if (!Number.isInteger(clientId) || clientId <= 0) {
      setError('That client link is not valid.');
      return;
    }
    setError(null);
    try {
      setData(await getClientDetail(clientId));
    } catch (err) {
      setError(errMessage(err, 'Could not load this client. Please try again.'));
    }
  }, [clientId]);

  useEffect(() => {
    void load();
  }, [load]);

  // TRACE: Edit click → copies the CURRENT profile into the form (fresh every open, never the previous unsaved edit) → sheet opens.
  const openEdit = () => {
    if (!data) return;
    const c = data.client;
    setForm({
      name: c.name, phone: c.phone, alt_phone: c.alt_phone, email: c.email, address: c.address, city: c.city, company_name: c.company_name,
      gst_number: c.gst_number, notes: c.notes, tags: c.tags, client_type: c.client_type, source: c.source === 'online' ? 'phone' : c.source,
    });
    setErrors({});
    setFormError(null);
    setDupId(null);
    setEditOpen(true);
  };

  // TRACE: Edit submit → validate → PUT → toast, close, refetch. Failure keeps the sheet and values; a duplicate names the other profile with a link.
  const submitEdit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving || !form) return;
    const v = validateClientForm(form);
    setErrors(v);
    if (Object.keys(v).length > 0) return;
    setSaving(true);
    setFormError(null);
    setDupId(null);
    try {
      // source is only meaningful when a client is created; editing never rewrites how the client first arrived.
      const { source: _ignored, ...rest } = form;
      void _ignored;
      const res = await updateClient(clientId, rest);
      toast.show(res.message, 'success');
      setEditOpen(false);
      await load();
    } catch (err) {
      setFormError(errMessage(err, 'Could not save the changes. Please try again.'));
      setDupId(duplicateOf(err)?.id ?? null);
    } finally {
      setSaving(false);
    }
  };

  // TRACE: Block/Unblock confirm → POST status → toast, close, refetch. Blocking requires a reason (button disabled until typed).
  const changeStatus = async (next: 'active' | 'blocked') => {
    if (statusBusy) return;
    setStatusBusy(true);
    try {
      const res = await setClientStatus(clientId, next, blockReason.trim());
      toast.show(res.message, 'success');
      setBlockOpen(false);
      setBlockReason('');
      await load();
    } catch (err) {
      toast.show(errMessage(err, 'Could not update the client.'), 'error');
    } finally {
      setStatusBusy(false);
    }
  };

  // TRACE: merge-target search box, debounced → GET clients/lookup?q= → results, excluding this client itself. Edge cases: short query clears results rather than searching (matches lookupClients' own ≥2-char floor).
  useEffect(() => {
    if (mergeQuery.trim().length < 2) {
      setMergeResults([]);
      return;
    }
    let cancelled = false;
    const t = window.setTimeout(async () => {
      try {
        const r = await lookupClients(mergeQuery.trim());
        if (!cancelled) setMergeResults(r.rows.filter((row) => row.id !== clientId));
      } catch {
        if (!cancelled) setMergeResults([]);
      }
    }, 300);
    return () => {
      cancelled = true;
      window.clearTimeout(t);
    };
  }, [mergeQuery, clientId]);

  // TRACE: confirmed merge → POST /admin/clients/:id/merge {into} → toast, close both dialogs, refetch (this profile now shows status 'merged'). Errors inline in the confirm dialog so the admin can retry without re-searching.
  const confirmMerge = async () => {
    if (mergeBusy || !mergeTarget) return;
    setMergeBusy(true);
    setMergeError(null);
    try {
      const res = await mergeClient(clientId, mergeTarget.id);
      toast.show(res.message || 'Merged.', 'success');
      setMergeConfirmOpen(false);
      setMergeOpen(false);
      setMergeQuery('');
      setMergeResults([]);
      setMergeTarget(null);
      await load();
    } catch (err) {
      setMergeError(errMessage(err, 'Could not merge. Please try again.'));
    } finally {
      setMergeBusy(false);
    }
  };

  if (error) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-6">
        <ErrorBanner message={error} onRetry={() => void load()} />
        <Link to="/admin/clients" className="mt-4 inline-block text-sm font-medium text-brand-700 underline">
          Back to clients
        </Link>
      </div>
    );
  }
  if (!data) {
    return (
      <div className="mx-auto max-w-4xl space-y-3 px-4 py-6" aria-busy="true" aria-label="Loading client">
        <Skeleton className="h-10 w-1/2" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }
  const { client: c, stats } = data;
  const tabs: { key: Tab; label: string; count: number }[] = [
    { key: 'bookings', label: 'Bookings', count: data.bookings.length },
    { key: 'payments', label: 'Payments', count: data.payments.length },
    { key: 'enquiries', label: 'Enquiries', count: data.enquiries.length },
    { key: 'complaints', label: 'Complaints', count: data.complaints.length },
  ];

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6">
      <Link to="/admin/clients" className="text-sm font-medium text-brand-700 hover:underline">
        ← All clients
      </Link>
      <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h1 className="break-words text-2xl font-bold text-ink-900 sm:text-3xl">{c.name}</h1>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {c.client_type === 'corporate' && <ToneBadge tone="brand">Corporate</ToneBadge>}
            {c.status === 'merged' ? (
              <ToneBadge tone="neutral">Merged</ToneBadge>
            ) : c.status === 'blocked' ? (
              <ToneBadge tone="danger">Blocked</ToneBadge>
            ) : (
              <ToneBadge tone="success">Active</ToneBadge>
            )}
            <ToneBadge tone="neutral">{SOURCE_LABELS[c.source] ?? c.source}</ToneBadge>
            {c.wp_user_id > 0 && <ToneBadge tone="neutral">Has an online account</ToneBadge>}
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {canBook && c.status === 'active' && (
            <Link to={`/app/admin/bookings/new?client=${c.id}`} className="inline-flex items-center rounded-lg bg-brand-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-brand-700">
              New booking
            </Link>
          )}
          <Button variant="secondary" onClick={openEdit}>
            Edit client
          </Button>
          {c.status !== 'merged' && (
            <Button variant="secondary" onClick={() => setMergeOpen(true)}>
              Merge into another client
            </Button>
          )}
          {c.status === 'merged' ? null : c.status === 'blocked' ? (
            <Button variant="secondary" loading={statusBusy} onClick={() => void changeStatus('active')}>
              Unblock
            </Button>
          ) : (
            <Button variant="danger" onClick={() => setBlockOpen(true)}>
              Block
            </Button>
          )}
        </div>
      </div>

      {c.status === 'blocked' && (
        <div role="alert" className="mt-4 rounded-xl border border-danger-500/30 bg-danger-50 p-3 text-sm text-danger-600">
          This client is blocked. They cannot book online and new bookings cannot be created for them until you unblock them.
        </div>
      )}
      {c.status === 'merged' && c.merged_into && (
        <div role="status" className="mt-4 rounded-xl border border-ink-200 bg-ink-50 p-3 text-sm text-ink-700">
          This profile was merged{c.merged_at ? ` on ${formatDateTime(c.merged_at)}` : ''}. Its bookings, payments and enquiries now show on{' '}
          <Link to={`/app/admin/clients/${c.merged_into}`} className="font-medium text-brand-700 hover:underline">
            the surviving profile
          </Link>
          .
        </div>
      )}

      <section aria-label="Contact details" className="mt-5 grid gap-4 rounded-xl border border-ink-100 bg-white p-5 shadow-xs sm:grid-cols-2">
        <dl className="space-y-2 text-sm">
          <div>
            <dt className="text-ink-500">Mobile</dt>
            <dd className="font-medium text-ink-900">
              <a href={`tel:${c.phone}`} className="text-brand-700 hover:underline">
                {c.phone}
              </a>
            </dd>
          </div>
          <div>
            <dt className="text-ink-500">Alternate contact</dt>
            <dd className="font-medium text-ink-900">{c.alt_phone || '—'}</dd>
          </div>
          <div>
            <dt className="text-ink-500">Email</dt>
            <dd className="break-all font-medium text-ink-900">{c.email || '—'}</dd>
          </div>
          {c.client_type === 'corporate' && (
            <div>
              <dt className="text-ink-500">Company</dt>
              <dd className="font-medium text-ink-900">
                {c.company_name}
                {c.gst_number ? ` · GST ${c.gst_number}` : ''}
              </dd>
            </div>
          )}
        </dl>
        <dl className="space-y-2 text-sm">
          <div>
            <dt className="text-ink-500">City and address</dt>
            <dd className="font-medium text-ink-900">{[c.city, c.address].filter(Boolean).join(', ') || '—'}</dd>
          </div>
          <div>
            <dt className="text-ink-500">Tags</dt>
            <dd className="font-medium text-ink-900">{c.tags || '—'}</dd>
          </div>
          <div>
            <dt className="text-ink-500">Internal notes</dt>
            <dd className="whitespace-pre-wrap font-medium text-ink-900">{c.notes || '—'}</dd>
          </div>
          <div>
            <dt className="text-ink-500">Client since</dt>
            <dd className="font-medium text-ink-900">{formatDateTime(c.created_at)}</dd>
          </div>
        </dl>
      </section>

      <section aria-label="Lifetime summary" className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: 'Bookings', value: `${stats.bookings}`, hint: `${stats.completed} completed · ${stats.cancelled} cancelled · ${stats.active} active` },
          { label: 'Ride value (est.)', value: inr(stats.billed), hint: 'Billed by vendors/drivers, excl. cancelled' },
          { label: 'Paid to ' + brand().name, value: inr(stats.paid), hint: 'Booking amounts minus refunds' },
          { label: 'Payable to vendors', value: inr(stats.outstanding), hint: 'Ride balance on live bookings' },
        ].map((t) => (
          <div key={t.label} className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs">
            <p className="text-sm text-ink-500">{t.label}</p>
            <p className="mt-1 text-xl font-bold text-ink-900">{t.value}</p>
            <p className="mt-1 text-xs text-ink-500">{t.hint}</p>
          </div>
        ))}
      </section>

      <div className="mt-6 flex gap-1 overflow-x-auto border-b border-ink-100" role="tablist" aria-label="Client history">
        {tabs.map((t) => (
          <button
            key={t.key}
            type="button"
            role="tab"
            aria-selected={tab === t.key}
            onClick={() => setTab(t.key)}
            className={`whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium ${tab === t.key ? 'border-brand-600 text-brand-700' : 'border-transparent text-ink-600 hover:text-ink-900'}`}
          >
            {t.label} ({t.count})
          </button>
        ))}
      </div>

      <div className="mt-4" role="tabpanel">
        {tab === 'bookings' &&
          (data.bookings.length === 0 ? (
            <EmptyState title="No bookings yet" description="Bookings made online or by your team for this client appear here." />
          ) : (
            <ul className="space-y-3">
              {data.bookings.map((b) => (
                <li key={b.id} className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <Link to={`/app/admin/bookings/${b.id}`} className="font-semibold text-brand-700 hover:underline">
                        {b.booking_number}
                      </Link>
                      <p className="text-sm text-ink-600">
                        {TRIP_TYPE_LABELS[b.trip_type] ?? b.trip_type} · {b.pickup_city}
                        {b.drop_city ? ` → ${b.drop_city}` : ''} · {formatDateTime(`${b.journey_date} ${String(b.journey_time).slice(0, 5)}`)}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      <ToneBadge tone={b.status === 'cancelled' ? 'danger' : b.status === 'completed' ? 'success' : 'brand'}>{b.status.replace(/_/g, ' ')}</ToneBadge>
                      <ToneBadge tone="neutral">{SOURCE_LABELS[b.booking_source] ?? b.booking_source}</ToneBadge>
                    </div>
                  </div>
                  <p className="mt-2 text-sm text-ink-700">
                    Est. fare {inr(b.total_fare)} · Booking amount paid {inr(b.advance_paid)} · Vendor to collect {inr(b.balance_due)}
                  </p>
                </li>
              ))}
            </ul>
          ))}
        {tab === 'payments' &&
          (data.payments.length === 0 ? (
            <EmptyState title="No payments recorded" description="Payments and refunds recorded against this client's bookings appear here." />
          ) : (
            <ul className="space-y-2">
              {data.payments.map((p) => (
                <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-ink-100 bg-white p-3 text-sm shadow-xs">
                  <span>
                    <span className="font-medium text-ink-900">{p.entry_type === 'refund' ? 'Refund' : 'Payment'}</span> · {METHOD_LABELS[p.method] ?? p.method}
                    {p.reference ? ` · ${p.reference}` : ''} · {p.booking_number} · {formatDateTime(p.created_at)}
                  </span>
                  <span className={`font-semibold ${p.entry_type === 'refund' ? 'text-danger-600' : 'text-success-600'}`}>
                    {p.entry_type === 'refund' ? '−' : '+'}
                    {inr(p.amount)}
                  </span>
                </li>
              ))}
            </ul>
          ))}
        {tab === 'enquiries' &&
          (data.enquiries.length === 0 ? (
            <EmptyState title="No enquiries" description="Phone and WhatsApp enquiries from this client appear here." />
          ) : (
            <ul className="space-y-2">
              {data.enquiries.map((e) => (
                <li key={e.id} className="rounded-xl border border-ink-100 bg-white p-3 text-sm shadow-xs">
                  <div className="flex flex-wrap justify-between gap-2">
                    <span className="font-medium text-ink-900">
                      {[e.pickup_city, e.drop_city].filter(Boolean).join(' → ') || 'Enquiry'} · {formatDateTime(e.created_at)}
                    </span>
                    <ToneBadge tone={e.status === 'converted' ? 'success' : e.status === 'lost' ? 'danger' : 'brand'}>{e.status}</ToneBadge>
                  </div>
                  {e.message && <p className="mt-1 text-ink-600">{e.message}</p>}
                </li>
              ))}
            </ul>
          ))}
        {tab === 'complaints' &&
          (data.complaints.length === 0 ? (
            <EmptyState title="No complaints" description="Complaints raised on this client's bookings appear here." />
          ) : (
            <ul className="space-y-2">
              {data.complaints.map((k) => (
                <li key={k.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-ink-100 bg-white p-3 text-sm shadow-xs">
                  <span>
                    <span className="font-medium text-ink-900">{k.complaint_id}</span> · {k.category} · {k.booking_number} · {formatDateTime(k.created_at)}
                  </span>
                  <ToneBadge tone={k.status === 'resolved' || k.status === 'closed' ? 'success' : 'warning'}>{k.status}</ToneBadge>
                </li>
              ))}
            </ul>
          ))}
      </div>

      <BottomSheet open={editOpen} title="Edit client" onClose={() => (saving ? undefined : setEditOpen(false))}>
        {form && (
          <form onSubmit={submitEdit} className="space-y-4" noValidate>
            <ClientFields values={form} errors={errors} onChange={(p) => setForm((f) => (f ? { ...f, ...p } : f))} excludeId={c.id} disabled={saving} idPrefix="editcl" showSource={false} />
            {formError && (
              <div role="alert" className="text-sm font-medium text-danger-600">
                {formError}{' '}
                {dupId && (
                  <Link to={`/app/admin/clients/${dupId}`} className="underline">
                    Open the other profile
                  </Link>
                )}
              </div>
            )}
            <div className="flex gap-3">
              <Button type="submit" loading={saving} fullWidth>
                Save changes
              </Button>
              <Button type="button" variant="secondary" onClick={() => setEditOpen(false)} disabled={saving} fullWidth>
                Cancel
              </Button>
            </div>
          </form>
        )}
      </BottomSheet>

      <ConfirmDialog
        open={blockOpen}
        title={`Block ${c.name}?`}
        description="A blocked client cannot book online and you cannot create bookings for them. Existing bookings are not cancelled."
        confirmLabel="Block client"
        confirmVariant="danger"
        loading={statusBusy}
        confirmDisabled={blockReason.trim() === ''}
        onConfirm={() => void changeStatus('blocked')}
        onCancel={() => (statusBusy ? undefined : setBlockOpen(false))}
      >
        <div className="mt-3">
          <FormField label="Reason (kept in the audit log)" htmlFor="block-reason">
            <input id="block-reason" type="text" value={blockReason} onChange={(e) => setBlockReason(e.target.value)} className={INPUT_CLASS} />
          </FormField>
        </div>
      </ConfirmDialog>

      <BottomSheet open={mergeOpen} title={`Merge ${c.name} into another client`} onClose={() => (mergeBusy ? undefined : setMergeOpen(false))}>
        <p className="text-sm text-ink-600">
          Search for the profile to keep. Every booking, payment and enquiry currently on <strong>{c.name}</strong> will move there, and this profile will be marked merged (not deleted).
        </p>
        <div className="mt-3">
          <FormField label="Search by name, phone or email" htmlFor="merge-search">
            <input id="merge-search" type="text" className={INPUT_CLASS} value={mergeQuery} onChange={(e) => setMergeQuery(e.target.value)} placeholder="Start typing…" autoFocus />
          </FormField>
        </div>
        {mergeQuery.trim().length >= 2 && (
          <ul className="mt-3 max-h-72 divide-y divide-ink-100 overflow-y-auto rounded-lg border border-ink-100">
            {mergeResults.length === 0 ? (
              <li className="p-3 text-sm text-ink-500">No matching clients.</li>
            ) : (
              mergeResults.map((r) => (
                <li key={r.id}>
                  <button
                    type="button"
                    className="flex w-full items-center justify-between gap-2 p-3 text-left text-sm hover:bg-ink-50"
                    onClick={() => {
                      setMergeTarget(r);
                      setMergeError(null);
                      setMergeConfirmOpen(true);
                    }}
                  >
                    <span>
                      <span className="font-medium text-ink-900">{r.name}</span>{' '}
                      <span className="text-ink-500">
                        {r.phone}
                        {r.email ? ` · ${r.email}` : ''}
                      </span>
                    </span>
                    {r.status === 'merged' && <ToneBadge tone="neutral">Already merged</ToneBadge>}
                  </button>
                </li>
              ))
            )}
          </ul>
        )}
      </BottomSheet>

      <ConfirmDialog
        open={mergeConfirmOpen}
        title={`Merge ${c.name} into ${mergeTarget?.name ?? 'this client'}?`}
        description={`${c.name}'s bookings, payments and enquiries will show under ${mergeTarget?.name ?? 'the other profile'} from now on. ${c.name} stays on record as merged and can't be undone from here.`}
        confirmLabel="Merge"
        confirmVariant="danger"
        loading={mergeBusy}
        confirmDisabled={mergeTarget?.status === 'merged'}
        onConfirm={() => void confirmMerge()}
        onCancel={() => (mergeBusy ? undefined : setMergeConfirmOpen(false))}
      >
        {mergeError && <div role="alert" className="mt-3 text-sm font-medium text-danger-600">{mergeError}</div>}
      </ConfirmDialog>
    </div>
  );
}
