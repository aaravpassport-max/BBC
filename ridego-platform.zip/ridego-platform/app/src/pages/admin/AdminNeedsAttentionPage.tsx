import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ApiError, getBookingsNeedingAttention, type NeedsAttentionGroup, type NeedsAttentionUrgency, type NeedsAttentionResponse } from '../../lib/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';

const URGENCY_STYLES: Record<NeedsAttentionUrgency, string> = {
  urgent: 'bg-danger-50 text-danger-600',
  high: 'bg-warning-50 text-warning-600',
  medium: 'bg-ink-100 text-ink-600',
};

// TRACE: one needs-attention group → renders its label, count badge and rows (or an all-clear note) →
//        element. Pure display; every row links to the existing booking detail page rather than
//        offering an inline action, since the right fix differs per reason (verify payment, assign a
//        vendor, follow up with the client...) and that page already has all those actions.
function GroupSection({ group }: { group: NeedsAttentionGroup }) {
  return (
    <section className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs sm:p-5">
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-base font-semibold text-ink-900">{group.label}</h2>
        <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${URGENCY_STYLES[group.urgency]}`}>{group.count}</span>
      </div>
      {group.rows.length === 0 ? (
        <p className="mt-3 rounded-lg bg-success-50 px-3 py-2.5 text-sm text-success-700">
          <span aria-hidden="true">✓ </span>Nothing here right now.
        </p>
      ) : (
        <ul className="mt-3 divide-y divide-ink-100">
          {group.rows.map((r) => (
            <li key={`${group.code}-${r.id}`} className="py-3">
              <Link to={`/app/admin/bookings/${r.id}`} className="block hover:opacity-80">
                <p className="font-semibold text-ink-900">{r.booking_number}</p>
                <p className="truncate text-sm text-ink-600">
                  {r.pickup_city} → {r.drop_city} · {r.client_name}
                </p>
                <p className="text-xs text-ink-500">{r.journey_date}</p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

// TRACE: page mount → GET /app/admin/bookings/needs-attention → renders every reason a booking
//        currently requires human action, grouped and ranked by urgency → element. Reachable by both
//        a full admin and a region-scoped Regional Manager (same route, same component — the server
//        does the region scoping, so there is no separate RM branch here to drift out of sync).
//        Preconditions: RequireAdmin gates the route on ridego_manage_bookings, mirroring the server.
//        Postconditions: read-only; each row's fix happens on that booking's own detail page. Edge
//        cases: an RM with no region assigned yet sees every group's "Nothing here" state, not an
//        error and not every booking; a request error shows ErrorBanner with retry.
export function AdminNeedsAttentionPage() {
  const [data, setData] = useState<NeedsAttentionResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    getBookingsNeedingAttention()
      .then((res) => setData(res))
      .catch((e) => setError(e instanceof ApiError ? e.message : 'Could not load the needs-attention list.'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const groups = data?.groups ?? [];

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-ink-900">Needs attention</h1>
          <p className="mt-1 text-sm text-ink-600">Every booking that currently requires a human decision, ranked by urgency.</p>
        </div>
        <Button variant="secondary" onClick={load} disabled={loading}>
          Refresh
        </Button>
      </div>

      {error && (
        <div className="mt-4">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {!error && loading && (
        <div className="mt-4 space-y-3">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-32 w-full" />
        </div>
      )}

      {!error && !loading && data && data.total === 0 && (
        <div className="mt-4">
          <EmptyState title="All clear" description="No booking currently needs attention." />
        </div>
      )}

      {!error && !loading && data && data.total > 0 && (
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
          {groups.map((g) => (
            <GroupSection key={g.code} group={g} />
          ))}
        </div>
      )}
    </div>
  );
}
