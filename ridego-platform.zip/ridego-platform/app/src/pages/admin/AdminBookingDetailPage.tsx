import { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  assignBookingVendor,
  cancelBookingAsAdmin,
  completeBookingAsAdmin,
  getAdminBookingDetail,
  getAdminBookingVendorPicker,
  getBookingProofFileUrl,
  getBookingTimeline,
  type AdminBookingTimelineEntry,
  markBookingNotArranged,
  rejectBookingPayment,
  resendBookingConfirmation,
  saveBookingNote,
  setBookingStatus,
  verifyBookingPayment,
  ApiError,
} from '../../lib/api';
import { getBookingComparison, type ComparisonAssignment } from '../../lib/api-admin-command';
import { startImpersonation } from '../../lib/api-admin-finance';
import { useAuth } from '../../context/AuthContext';
import { hasAdminCap } from '../../lib/permissions';
import type { AdminBookingDetail, AdminBookingVendorPickerRow } from '../../types/api';
import { BookingDeskPanels } from '../../components/admin/BookingDeskPanels';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { SearchableSelect } from '../../components/ui/SearchableSelect';
import { brand } from '../../lib/brand';
import { LeadFeeCard } from '../../components/LeadFeeCard';

const statusBadgeStyles: Record<string, string> = {
  pending_payment: 'bg-warning-50 text-warning-600',
  payment_proof_submitted: 'bg-warning-50 text-warning-600',
  payment_rejected: 'bg-danger-50 text-danger-600',
  confirmed: 'bg-success-50 text-success-600',
  vendor_assigned: 'bg-brand-50 text-brand-700',
  driver_en_route: 'bg-brand-50 text-brand-700',
  trip_started: 'bg-brand-50 text-brand-700',
  completed: 'bg-success-50 text-success-600',
  cancelled: 'bg-danger-50 text-danger-600',
  expired: 'bg-ink-100 text-ink-600',
};

function badgeClass(value: string): string {
  return statusBadgeStyles[value] ?? 'bg-ink-100 text-ink-600';
}

function humanize(value: string): string {
  return value
    .split('_')
    .map((part) => (part ? part[0].toUpperCase() + part.slice(1) : part))
    .join(' ');
}

function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

const STATUS_OPTIONS = [
  { value: 'pending', label: 'Pending' },
  { value: 'confirmed', label: 'Confirmed' },
  { value: 'vendor_assigned', label: 'Vendor Assigned' },
  { value: 'driver_en_route', label: 'Driver En Route' },
  { value: 'trip_started', label: 'Trip Started' },
  { value: 'completed', label: 'Completed' },
];

const TABS = [
  { id: 'details', label: '📋 Details' },
  { id: 'fare', label: '💰 Fare Breakdown' },
  { id: 'driver', label: '🚗 Driver/Vendor' },
  { id: 'leads', label: '📤 Lead History' },
  { id: 'timeline', label: '🕒 Timeline' },
  { id: 'actions', label: '⚡ Actions' },
] as const;

type TabId = (typeof TABS)[number]['id'];

function DetailRow({ label, value }: { label: string; value: string | number | null | undefined }) {
  if (value === null || value === undefined || value === '' || value === 0) return null;
  return (
    <div className="flex justify-between gap-4 border-b border-ink-50 py-1.5 text-sm last:border-b-0">
      <span className="text-ink-500">{label}</span>
      <span className="font-medium text-ink-800">{value}</span>
    </div>
  );
}

export function AdminBookingDetailPage() {
  const { id } = useParams<{ id: string }>();
  const bookingId = Number(id);

  const [booking, setBooking] = useState<AdminBookingDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [tab, setTab] = useState<TabId>('details');
  const [timelineEntries, setTimelineEntries] = useState<AdminBookingTimelineEntry[] | null>(null);
  const [timelineLoading, setTimelineLoading] = useState(false);
  const [timelineError, setTimelineError] = useState<string | null>(null);

  const { user: authUser } = useAuth();
  const canViewAsClient = hasAdminCap(authUser, 'ridego_impersonate_client');
  const [viewAsOpen, setViewAsOpen] = useState(false);
  const [viewAsBusy, setViewAsBusy] = useState(false);
  const [viewAsError, setViewAsError] = useState<string | null>(null);

  // TRACE: "View as this client" confirm → POST /admin/impersonate {user_id: booking.client_user_id} → full page load of
  //        the client dashboard so the nonce and cookies switch to the client session.
  //        Preconditions: cap ridego_impersonate_client and a client account on the booking → postconditions: session cookie
  //        set, page navigates → edge cases: guest booking (button not shown), API refusal shown verbatim in the dialog,
  //        busy state stays after success so the request cannot be sent twice before the reload.
  async function confirmViewAsClient() {
    if (viewAsBusy || !booking || !booking.client_user_id) return;
    setViewAsBusy(true);
    setViewAsError(null);
    try {
      await startImpersonation(booking.client_user_id);
      window.location.assign('/dashboard');
    } catch (err) {
      setViewAsError(err instanceof ApiError ? err.message : 'Could not start the view-as session.');
      setViewAsBusy(false);
    }
  }

  const [vendorOptions, setVendorOptions] = useState<AdminBookingVendorPickerRow[]>([]);
  const [proofLoading, setProofLoading] = useState(false);

  // Verify payment.
  const [showVerify, setShowVerify] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [verifyError, setVerifyError] = useState<string | null>(null);

  // Reject payment.
  const [showRejectPayment, setShowRejectPayment] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [rejectingPayment, setRejectingPayment] = useState(false);
  const [rejectPaymentError, setRejectPaymentError] = useState<string | null>(null);

  // Cancel booking.
  const [showCancel, setShowCancel] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelling, setCancelling] = useState(false);
  const [cancelError, setCancelError] = useState<string | null>(null);

  // Mark not arranged -> token refund due.
  const [showNotArranged, setShowNotArranged] = useState(false);
  const [notArrangedReason, setNotArrangedReason] = useState('');
  const [markingNotArranged, setMarkingNotArranged] = useState(false);
  const [notArrangedError, setNotArrangedError] = useState<string | null>(null);

  // Mark completed.
  const [showComplete, setShowComplete] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [resendingConfirmation, setResendingConfirmation] = useState(false);
  const [completeError, setCompleteError] = useState<string | null>(null);

  // Assign vendor.
  const [showAssign, setShowAssign] = useState(false);
  const [assignVendorId, setAssignVendorId] = useState('');
  const [assigning, setAssigning] = useState(false);
  const [assignError, setAssignError] = useState<string | null>(null);

  // Change status.
  const [newStatus, setNewStatus] = useState('');
  const [changingStatus, setChangingStatus] = useState(false);
  const [statusError, setStatusError] = useState<string | null>(null);

  // Admin note.
  const [note, setNote] = useState('');
  const [savingNote, setSavingNote] = useState(false);
  const [noteError, setNoteError] = useState<string | null>(null);
  const [noteSaved, setNoteSaved] = useState(false);
  const [assignment, setAssignment] = useState<ComparisonAssignment | null>(null);

  const load = useCallback(async () => {
    if (!bookingId || Number.isNaN(bookingId)) {
      setNotFound(true);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    setNotFound(false);
    try {
      const res = await getAdminBookingDetail(bookingId);
      setBooking(res);
      setNote(res.notes_admin || '');
      setNewStatus(res.status);
    } catch (err) {
      if (err instanceof ApiError && (err.status === 404 || err.code === 'not_found')) {
        setNotFound(true);
      } else if (err instanceof ApiError && err.code === 'forbidden') {
        setError("You don't have permission to manage bookings.");
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not load this booking. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  }, [bookingId]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    // TRACE: tab switched to 'timeline' AND a valid bookingId → GET the merged timeline once →
    //        entries set on success, an inline error banner shown on failure (e.g. lacking
    //        ridego_view_audit_log-equivalent access — the endpoint reuses the same bookings
    //        permission, so this only truly fails on network/500). Postconditions: re-fetches
    //        every time the tab is (re)selected, so a note/payment/status change made in another
    //        tab is reflected the next time Timeline is opened, without a manual refresh button.
    if (tab !== 'timeline' || !bookingId || Number.isNaN(bookingId)) return;
    let cancelled = false;
    setTimelineLoading(true);
    setTimelineError(null);
    getBookingTimeline(bookingId)
      .then((res) => {
        if (!cancelled) setTimelineEntries(res.entries);
      })
      .catch((err) => {
        if (!cancelled) setTimelineError(err instanceof ApiError ? err.message : 'Could not load the timeline.');
      })
      .finally(() => {
        if (!cancelled) setTimelineLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [tab, bookingId]);

  useEffect(() => {
    getAdminBookingVendorPicker()
      .then((res) => setVendorOptions(res.rows))
      .catch(() => {
        /* Non-fatal — the assign-vendor dialog just shows an empty list. */
      });
  }, []);

  useEffect(() => {
    // TRACE: booking id known → GET comparison to read the current driver/vehicle snapshot → assignment state set.
    //        valid bookingId → snapshot shown in the Driver/Vendor tab → failure (no permission, 404) leaves it hidden;
    //        response ignored after unmount or id change.
    if (!bookingId || Number.isNaN(bookingId)) return;
    let cancelled = false;
    getBookingComparison(bookingId)
      .then((res) => {
        if (!cancelled) setAssignment(res.assignment);
      })
      .catch(() => {
        if (!cancelled) setAssignment(null);
      });
    return () => {
      cancelled = true;
    };
  }, [bookingId, booking?.vendor_id]);

  async function refetch() {
    setRefreshing(true);
    try {
      const res = await getAdminBookingDetail(bookingId);
      setBooking(res);
      setNote(res.notes_admin || '');
      setNewStatus(res.status);
    } catch {
      // Keep showing stale data rather than replacing a success with an error.
    } finally {
      setRefreshing(false);
    }
  }

  async function viewProof() {
    if (!booking?.payment_proof_url) return;
    setProofLoading(true);
    try {
      const url = await getBookingProofFileUrl(booking.payment_proof_url);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch {
      setActionMessage(null);
    } finally {
      setProofLoading(false);
    }
  }

  async function confirmVerify() {
    setVerifying(true);
    setVerifyError(null);
    try {
      await verifyBookingPayment(bookingId);
      setShowVerify(false);
      setActionMessage('Payment verified. Booking confirmed.');
      await refetch();
    } catch (err) {
      setVerifyError(err instanceof ApiError ? err.message : 'Could not verify payment.');
    } finally {
      setVerifying(false);
    }
  }

  async function confirmRejectPayment() {
    if (!rejectReason.trim()) return;
    setRejectingPayment(true);
    setRejectPaymentError(null);
    try {
      await rejectBookingPayment(bookingId, rejectReason.trim());
      setShowRejectPayment(false);
      setRejectReason('');
      setActionMessage('Payment rejected.');
      await refetch();
    } catch (err) {
      setRejectPaymentError(err instanceof ApiError ? err.message : 'Could not reject payment.');
    } finally {
      setRejectingPayment(false);
    }
  }

  async function confirmCancel() {
    setCancelling(true);
    setCancelError(null);
    try {
      const res = await cancelBookingAsAdmin(bookingId, cancelReason.trim());
      setShowCancel(false);
      setCancelReason('');
      setActionMessage(
        typeof res.refund_amount === 'number'
          ? `Booking cancelled. Refund: ${currency(res.refund_amount)}${
              res.penalty ? ` (penalty ${currency(res.penalty)})` : ''
            }.`
          : 'Booking cancelled.'
      );
      await refetch();
    } catch (err) {
      setCancelError(err instanceof ApiError ? err.message : 'Could not cancel this booking.');
    } finally {
      setCancelling(false);
    }
  }

  async function confirmNotArranged() {
    setMarkingNotArranged(true);
    setNotArrangedError(null);
    try {
      const res = await markBookingNotArranged(bookingId, notArrangedReason.trim());
      setShowNotArranged(false);
      setNotArrangedReason('');
      setActionMessage(
        res.refund_amount > 0
          ? `Booking marked not arranged. Booking amount refund of ${currency(res.refund_amount)} initiated.`
          : 'Booking marked not arranged.'
      );
      await refetch();
    } catch (err) {
      setNotArrangedError(err instanceof ApiError ? err.message : 'Could not mark this booking as not arranged.');
    } finally {
      setMarkingNotArranged(false);
    }
  }

  async function confirmComplete() {
    setCompleting(true);
    setCompleteError(null);
    try {
      await completeBookingAsAdmin(bookingId);
      setShowComplete(false);
      setActionMessage('Booking marked completed.');
      await refetch();
    } catch (err) {
      setCompleteError(err instanceof ApiError ? err.message : 'Could not mark this booking completed.');
    } finally {
      setCompleting(false);
    }
  }

  async function resendConfirmation() {
    setResendingConfirmation(true);
    try {
      await resendBookingConfirmation(bookingId);
      setActionMessage('Confirmation re-sent.');
    } catch (err) {
      setActionMessage(err instanceof ApiError ? err.message : 'Could not resend the confirmation.');
    } finally {
      setResendingConfirmation(false);
    }
  }

  async function confirmAssign() {
    const vid = Number(assignVendorId);
    if (!vid) return;
    setAssigning(true);
    setAssignError(null);
    try {
      await assignBookingVendor(bookingId, vid);
      setShowAssign(false);
      setAssignVendorId('');
      setActionMessage('Vendor assigned.');
      await refetch();
    } catch (err) {
      setAssignError(err instanceof ApiError ? err.message : 'Could not assign vendor.');
    } finally {
      setAssigning(false);
    }
  }

  async function submitStatusChange() {
    if (!newStatus || !booking || newStatus === booking.status) return;
    setChangingStatus(true);
    setStatusError(null);
    try {
      await setBookingStatus(bookingId, newStatus, booking.lock_version);
      setActionMessage('Status updated.');
      await refetch();
    } catch (err) {
      // A 409 here means another admin (or the same admin in a second tab) changed this booking
      // after this page loaded it — refetch so the visible status/fields reflect what actually
      // happened, instead of leaving the stale pre-change view up alongside a rejected retry.
      if (err instanceof ApiError && err.status === 409) await refetch();
      setStatusError(err instanceof ApiError ? err.message : 'Could not update status.');
    } finally {
      setChangingStatus(false);
    }
  }

  async function submitNote() {
    setSavingNote(true);
    setNoteError(null);
    setNoteSaved(false);
    try {
      await saveBookingNote(bookingId, note);
      setNoteSaved(true);
    } catch (err) {
      setNoteError(err instanceof ApiError ? err.message : 'Could not save note.');
    } finally {
      setSavingNote(false);
    }
  }

  if (notFound) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <div className="rounded-2xl border border-ink-100 bg-ink-50/60 p-10">
          <h1 className="text-xl font-bold text-ink-900">Booking not found</h1>
          <p className="mt-2 text-ink-500">This booking doesn't exist or may have been removed.</p>
          <div className="mt-6">
            <Link to="/admin/bookings">
              <Button variant="secondary">Back to bookings</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const canVerifyPayment = booking && booking.payment_status === 'proof_submitted';
  const canCancel = booking && !['completed', 'cancelled', 'trip_started', 'token_refund_due'].includes(booking.status);
  const canMarkNotArranged =
    booking && !booking.vendor_id && !['completed', 'cancelled', 'trip_started', 'token_refund_due'].includes(booking.status);
  const canComplete = booking && !['completed', 'cancelled'].includes(booking.status);
  const canResendConfirmation = booking && !['cancelled', 'expired'].includes(booking.status);

  const fareLines: Array<[string, number]> = booking
    ? [
        ['Base Fare (estimate)', booking.base_fare],
        ['Toll Charges', booking.toll_charges],
        ['Parking', booking.parking_charges],
        ['Driver Allowance', booking.driver_allowance],
        ['Night Surcharge', booking.night_surcharge],
        ['Taxes (estimate, charged by vendor)', booking.gst_amount],
      ]
    : [];

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Link to="/admin/bookings" className="text-sm font-medium text-brand-700 hover:text-brand-800">
            ← Back to bookings
          </Link>
          <h1 className="mt-1 text-2xl font-bold text-ink-900 sm:text-3xl">Booking details</h1>
        </div>
        <div className="flex items-center gap-3">
          {refreshing && <span className="text-sm text-ink-400">Refreshing…</span>}
          {booking && (
            <Link
              to={`/app/admin/bookings/${booking.id}/compare`}
              className="inline-flex items-center justify-center rounded-lg bg-brand-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-brand-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
            >
              {booking.vendor_id ? 'Change / view assignment' : 'Compare & assign'}
            </Link>
          )}
        </div>
      </div>

      {actionMessage && !loading && (
        <div role="status" className="mt-4 rounded-lg border border-success-500/30 bg-success-50 px-3.5 py-2.5 text-sm text-success-700">
          {actionMessage}
        </div>
      )}

      {loading && (
        <div className="mt-6 space-y-6" aria-busy="true" aria-label="Loading booking">
          <Skeleton className="h-32 w-full rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {!loading && !error && booking && (
        <>
          <div className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs sm:p-6">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-ink-900">{booking.booking_number}</h2>
                <p className="mt-1 text-sm text-ink-500">
                  {booking.client_name} &middot; {booking.client_phone} &middot; {booking.client_email}
                </p>
                <p className="mt-1 text-sm text-ink-500">
                  {booking.pickup_city} → {booking.drop_city} &middot; {humanize(booking.trip_type)}
                </p>
                <p className="mt-1 text-xs text-ink-400">
                  {booking.journey_date} {booking.journey_time}
                  {booking.return_date ? ` · Return ${booking.return_date}` : ''}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {!booking.vendor_id && !['cancelled', 'completed', 'expired'].includes(booking.status) && (
                  <span className="rounded-full bg-danger-50 px-2.5 py-1 text-xs font-semibold text-danger-600">
                    ⚠ No driver assigned
                  </span>
                )}
                {booking.is_safety_sensitive && (
                  <span className="rounded-full bg-warning-50 px-2.5 py-1 text-xs font-semibold text-warning-700" title="Female-only or includes children — requires manual vendor review, never automatic assignment.">
                    🛡 Safety-sensitive
                  </span>
                )}
                <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${badgeClass(booking.status)}`}>
                  {humanize(booking.status)}
                </span>
              </div>
            </div>

            <div className="mt-5 grid gap-4 border-t border-ink-100 pt-4 sm:grid-cols-4">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Estimated ride fare</p>
                <p className="mt-1 text-lg font-bold text-ink-900">{currency(booking.total_fare)}</p>
                <p className="text-xs text-ink-500">Billed by the vendor/driver</p>
              </div>
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Customer advance ({brand().name})</p>
                <p className="mt-1 text-lg font-bold text-brand-700">{currency(booking.booking_amount ?? booking.token_amount)}</p>
                <p className="text-xs text-ink-500">
                  Received {currency(booking.booking_amount_paid ?? booking.advance_paid)}
                  {booking.booking_amount_pending ? ` · pending ${currency(booking.booking_amount_pending)}` : ''}
                </p>
              </div>
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Payable to vendor/driver</p>
                <p className="mt-1 text-lg font-bold text-ink-900">{currency(booking.payable_to_vendor ?? booking.balance_due)}</p>
                <p className="text-xs text-ink-500">Collected by vendor/driver directly</p>
              </div>
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Reported collected</p>
                <p className="mt-1 text-lg font-bold text-ink-900">{currency(booking.vendor_collected ?? 0)}</p>
                <p className="text-xs text-ink-500">
                  Remaining {currency(booking.vendor_outstanding ?? booking.balance_due)}
                  {booking.vendor_invoice_number ? ` · Vendor invoice ${booking.vendor_invoice_number}` : ''}
                </p>
              </div>
            </div>
            {booking.status === 'token_refund_due' && (
              <div className="mt-4 rounded-lg border border-warning-200 bg-warning-50 p-3 text-sm text-warning-800">
                Booking not arranged — booking amount refund due{booking.refund_amount ? `: ${currency(booking.refund_amount)}` : ''}.
                {booking.refund_processed_at ? ' Refund processed.' : ' Refund initiated.'}
              </div>
            )}
          </div>

          <div className="mt-4">
            <LeadFeeCard fee={booking.lead_fee} audience="admin" bookingId={booking.id} canAdjust={hasAdminCap(authUser, 'ridego_manage_settings')} onChanged={() => void load()} />
          </div>
          <BookingDeskPanels booking={booking} user={authUser} onChanged={() => void load()} />

          {/* Tabs */}
          <div className="mt-6 flex flex-wrap gap-1 border-b border-ink-100">
            {TABS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={`rounded-t-lg px-3.5 py-2 text-sm font-semibold transition-colors ${
                  tab === t.id
                    ? 'border-b-2 border-brand-600 text-brand-700'
                    : 'text-ink-500 hover:text-ink-800'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Details tab */}
          {tab === 'details' && (
            <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
                <h3 className="text-sm font-bold text-ink-900">👤 Client Information</h3>
                <div className="mt-2">
                  <DetailRow label="Name" value={booking.client_name} />
                  <DetailRow label="Phone" value={booking.client_phone} />
                  <DetailRow label="Alt Phone" value={booking.client_alt_phone} />
                  <DetailRow label="Email" value={booking.client_email} />
                  <DetailRow label="Passengers" value={`${booking.passengers} pax`} />
                  <DetailRow label="Luggage" value={booking.luggage_count ? `${booking.luggage_count} bag(s)` : ''} />
                  {(booking.passenger_male !== null || booking.passenger_female !== null || booking.passenger_children !== null) && (
                    <DetailRow
                      label="Passenger composition"
                      value={[
                        booking.passenger_female != null && booking.passenger_female > 0 ? `${booking.passenger_female} female` : null,
                        booking.passenger_male != null && booking.passenger_male > 0 ? `${booking.passenger_male} male` : null,
                        booking.passenger_children != null && booking.passenger_children > 0 ? `${booking.passenger_children} child${booking.passenger_children === 1 ? '' : 'ren'}` : null,
                      ]
                        .filter(Boolean)
                        .join(', ') || 'Not provided'}
                    />
                  )}
                  {booking.passenger_notes && <DetailRow label="Passenger/safety notes" value={booking.passenger_notes} />}
                  <DetailRow label="Corporate" value={booking.corporate_company} />
                  <DetailRow label="Corp GST" value={booking.corporate_gst} />
                  <DetailRow label="Flight #" value={booking.flight_number} />
                  <DetailRow label="Special Req" value={booking.special_requests} />
                </div>
                {canViewAsClient && booking.client_user_id > 0 && (
                  <div className="mt-3">
                    <Button variant="secondary" onClick={() => { setViewAsError(null); setViewAsOpen(true); }}>
                      View as this client
                    </Button>
                  </div>
                )}
              </div>
              <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
                <h3 className="text-sm font-bold text-ink-900">🗺️ Trip Information</h3>
                <div className="mt-2">
                  <DetailRow label="Trip Type" value={humanize(booking.trip_type)} />
                  <DetailRow label="Pickup City" value={booking.pickup_city} />
                  <DetailRow label="Pickup Address" value={booking.pickup_address} />
                  <DetailRow label="Drop City" value={booking.drop_city} />
                  <DetailRow label="Drop Address" value={booking.drop_address} />
                  <DetailRow label="Via Cities" value={booking.via_cities} />
                  <DetailRow label="Return Date" value={booking.return_date} />
                  <DetailRow label="Return Time" value={booking.return_time} />
                  <DetailRow label="Hours Booked" value={booking.hours_required ? `${booking.hours_required} hrs` : ''} />
                  <DetailRow label="Distance" value={booking.distance_km ? `${booking.distance_km} km` : ''} />
                  <DetailRow
                    label="Duration"
                    value={booking.duration_minutes ? `${(booking.duration_minutes / 60).toFixed(1)} hrs` : ''}
                  />
                  <DetailRow label="Vehicle" value={booking.vehicle_name} />
                  <DetailRow label="Pickup OTP" value={booking.otp_pickup} />
                </div>
              </div>
              <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
                <h3 className="text-sm font-bold text-ink-900">💳 Payment Info</h3>
                <div className="mt-2">
                  <DetailRow label="Method" value={humanize(booking.payment_method || 'unknown')} />
                  <DetailRow label="Payment Status" value={humanize(booking.payment_status)} />
                  <DetailRow label="UTR / Ref" value={booking.payment_utr} />
                  <DetailRow label="Paid Via" value={booking.payment_app} />
                  <DetailRow
                    label="Amount Claimed"
                    value={booking.payment_amount_claimed ? currency(booking.payment_amount_claimed) : ''}
                  />
                  <DetailRow label="Verified By" value={booking.payment_verified_by || 'Pending'} />
                  <DetailRow label="Payment Time" value={booking.payment_time_claimed} />
                  <DetailRow label="IP Address" value={booking.ip_address} />
                  <DetailRow label="UTM Source" value={booking.utm_source} />
                  {booking.payment_proof_url && (
                    <div className="flex justify-between gap-4 border-b border-ink-50 py-1.5 text-sm last:border-b-0">
                      <span className="text-ink-500">Proof File</span>
                      <Button size="sm" variant="secondary" loading={proofLoading} onClick={viewProof}>
                        📷 View Proof
                      </Button>
                    </div>
                  )}
                  {booking.payment_rejection_reason && (
                    <p className="mt-2 text-xs text-danger-600">Rejected: {booking.payment_rejection_reason}</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Fare Breakdown tab */}
          {tab === 'fare' && (
            <div className="mt-5 max-w-md rounded-xl border border-ink-100 p-5 shadow-xs">
              <h3 className="text-sm font-bold text-ink-900">💰 Estimated ride fare</h3>
              <p className="mt-1 text-xs text-ink-500">Estimate only — the vendor/driver bills the final ride amount.</p>
              <div className="mt-3">
                {fareLines
                  .filter(([, v]) => v > 0)
                  .map(([label, v]) => (
                    <DetailRow key={label} label={label} value={currency(v)} />
                  ))}
                {booking.discount_amount > 0 && (
                  <div className="flex justify-between gap-4 border-b border-ink-50 py-1.5 text-sm">
                    <span className="text-ink-500">Promo ({booking.promo_code || '—'})</span>
                    <span className="font-medium text-success-600">– {currency(booking.discount_amount)}</span>
                  </div>
                )}
                <div className="mt-2 flex justify-between border-t-2 border-ink-200 pt-3">
                  <span className="text-base font-extrabold text-ink-900">ESTIMATED FARE</span>
                  <span className="text-xl font-extrabold text-brand-700">{currency(booking.total_fare)}</span>
                </div>
                <DetailRow label={`Customer advance received by ${brand().name}`} value={currency(booking.booking_amount_paid ?? booking.advance_paid)} />
                <div className="flex justify-between gap-4 py-1.5 text-sm">
                  <span className="text-ink-500">Payable to vendor/driver</span>
                  <span className="font-bold text-warning-600">{currency(booking.payable_to_vendor ?? Math.max(0, booking.total_fare - booking.advance_paid))}</span>
                </div>
              </div>
            </div>
          )}

          {/* Driver/Vendor tab */}
          {tab === 'driver' && (
            <div className="mt-5">
              {booking.vendor ? (
                <div className="rounded-xl border border-ink-100 p-5 shadow-xs">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-ink-900">🚗 Assigned Vendor</h3>
                    <Link
                      to={`/app/admin/vendors/${booking.vendor.id}`}
                      className="text-xs font-semibold text-brand-700 hover:text-brand-800"
                    >
                      Full profile →
                    </Link>
                  </div>
                  <div className="mt-3 grid gap-4 sm:grid-cols-2">
                    <div>
                      <DetailRow label="Business" value={booking.vendor.business_name} />
                      <DetailRow label="Owner" value={booking.vendor.owner_name} />
                      <DetailRow label="Phone" value={booking.vendor.phone} />
                      <DetailRow label="WhatsApp" value={booking.vendor.whatsapp_number} />
                      <DetailRow label="Email" value={booking.vendor.email} />
                      <DetailRow label="City" value={booking.vendor.city} />
                    </div>
                    <div>
                      <DetailRow label="Status" value={humanize(booking.vendor.status)} />
                      <DetailRow label="KYC" value={humanize(booking.vendor.kyc_status)} />
                      <DetailRow label="Rating" value={booking.vendor.rating ? `${booking.vendor.rating} ⭐` : ''} />
                      <DetailRow label="Completed Trips" value={booking.vendor.total_rides_completed} />
                      <DetailRow label="Wallet Balance" value={currency(booking.vendor.wallet_balance)} />
                    </div>
                  </div>
                  {assignment && (
                    <div className="mt-4 border-t border-ink-100 pt-4" aria-label="Driver and vehicle snapshot">
                      <h4 className="text-sm font-bold text-ink-900">Driver and vehicle</h4>
                      <DetailRow label="Driver" value={assignment.driver_name_snapshot || 'Not provided yet'} />
                      <DetailRow label="Driver phone" value={assignment.driver_phone_snapshot} />
                      <DetailRow label="Vehicle" value={assignment.vehicle_model_snapshot} />
                      <DetailRow label="Registration" value={assignment.vehicle_registration_snapshot || 'Not provided yet'} />
                    </div>
                  )}
                </div>
              ) : (
                <>
                  <div className="rounded-lg border border-warning-500/30 bg-warning-50 px-3.5 py-2.5 text-sm text-warning-700">
                    ⚠️ No driver assigned yet for this booking.
                  </div>
                  {!['cancelled', 'completed', 'expired'].includes(booking.status) && (
                    <div className="mt-4 max-w-lg rounded-xl border border-ink-100 p-5 shadow-xs">
                      <h3 className="text-sm font-bold text-ink-900">Assign Driver Manually</h3>
                      <div className="mt-3">
                        <SearchableSelect
                          value={assignVendorId}
                          onChange={setAssignVendorId}
                          aria-label="Vendor to assign to this booking"
                          placeholder="Search vendors by name or phone"
                          emptyOptionLabel="— Choose a vendor —"
                          options={vendorOptions.map((v) => ({
                            value: String(v.id),
                            label: v.business_name,
                            searchText: v.phone,
                            description: `${v.phone} · Wallet: ${currency(v.wallet_balance)}`,
                          }))}
                        />
                      </div>
                      <p className="mt-1.5 text-xs text-ink-400">Only active, KYC-verified vendors shown.</p>
                      <div className="mt-3">
                        <Button
                          size="sm"
                          disabled={!assignVendorId}
                          loading={assigning}
                          onClick={() => {
                            setShowAssign(true);
                            setAssignError(null);
                          }}
                        >
                          Assign Vendor
                        </Button>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {/* Lead History tab */}
          {tab === 'leads' && (
            <div className="mt-5">
              {booking.leads.length > 0 ? (
                <>
                  <div className="hidden overflow-x-auto rounded-xl border border-ink-100 lg:block">
                    <table className="min-w-full divide-y divide-ink-100 text-sm">
                      <thead className="bg-ink-50">
                        <tr>
                          <th className="px-3 py-2 text-left font-semibold text-ink-500">Vendor</th>
                          <th className="px-3 py-2 text-left font-semibold text-ink-500">Phone</th>
                          <th className="px-3 py-2 text-left font-semibold text-ink-500">Lead Fee</th>
                          <th className="px-3 py-2 text-left font-semibold text-ink-500">Status</th>
                          <th className="px-3 py-2 text-left font-semibold text-ink-500">Sent</th>
                          <th className="px-3 py-2 text-left font-semibold text-ink-500">Expires</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-ink-50">
                        {booking.leads.map((l) => (
                          <tr key={l.id}>
                            <td className="px-3 py-2 font-medium text-ink-800">{l.vendor_name}</td>
                            <td className="px-3 py-2 text-ink-600">{l.vendor_phone}</td>
                            <td className="px-3 py-2 font-semibold text-ink-800">{currency(l.fee_amount)}</td>
                            <td className="px-3 py-2">
                              <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${badgeClass(l.status)}`}>
                                {humanize(l.status)}
                              </span>
                            </td>
                            <td className="px-3 py-2 text-xs text-ink-500">{l.sent_at || '—'}</td>
                            <td className="px-3 py-2 text-xs text-ink-500">{l.expires_at || '—'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="space-y-3 lg:hidden">
                    {booking.leads.map((l) => (
                      <div key={l.id} className="rounded-xl border border-ink-100 bg-white p-4">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="text-sm font-medium text-ink-900">{l.vendor_name}</p>
                            <p className="text-xs text-ink-500">{l.vendor_phone}</p>
                          </div>
                          <span className={`shrink-0 rounded-full px-2 py-0.5 text-xs font-semibold ${badgeClass(l.status)}`}>
                            {humanize(l.status)}
                          </span>
                        </div>
                        <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
                          <span className="text-ink-400">Lead fee</span>
                          <span className="text-right font-semibold text-ink-800">{currency(l.fee_amount)}</span>
                          <span className="text-ink-400">Sent</span>
                          <span className="text-right text-ink-500">{l.sent_at || '—'}</span>
                          <span className="text-ink-400">Expires</span>
                          <span className="text-right text-ink-500">{l.expires_at || '—'}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="rounded-xl border border-ink-100 p-8 text-center text-sm text-ink-500">
                  <p className="text-2xl">📤</p>
                  <p className="mt-2 font-semibold text-ink-700">No leads sent yet</p>
                  <p className="mt-1">Leads are sent to vendors automatically after payment verification.</p>
                </div>
              )}
            </div>
          )}

          {tab === 'timeline' && (
            <div className="mt-5">
              {timelineLoading && <Skeleton className="h-40" />}
              {!timelineLoading && timelineError && <ErrorBanner message={timelineError} />}
              {!timelineLoading && !timelineError && timelineEntries && timelineEntries.length === 0 && (
                <div className="rounded-xl border border-ink-100 p-8 text-center text-sm text-ink-500">
                  <p className="text-2xl">🕒</p>
                  <p className="mt-2 font-semibold text-ink-700">Nothing recorded yet</p>
                  <p className="mt-1">Status changes, notes, and payments for this booking will show up here.</p>
                </div>
              )}
              {!timelineLoading && !timelineError && timelineEntries && timelineEntries.length > 0 && (
                <ol className="space-y-3">
                  {timelineEntries.map((e, i) => (
                    <li
                      key={`${e.source}-${e.at}-${i}`}
                      className={`rounded-xl border p-3 text-sm ${
                        e.severity === 'warning'
                          ? 'border-warning-200 bg-warning-50'
                          : e.severity === 'error' || e.severity === 'critical'
                            ? 'border-danger-200 bg-danger-50'
                            : 'border-ink-100 bg-white'
                      }`}
                    >
                      <div className="flex flex-wrap items-baseline justify-between gap-2">
                        <span className="font-semibold text-ink-800">
                          {e.source === 'audit' ? '📝' : e.source === 'note' ? '💬' : '💳'} {humanize(e.label)}
                        </span>
                        <span className="text-xs text-ink-400">{e.at}</span>
                      </div>
                      {e.detail && <p className="mt-1 text-ink-600">{e.detail}</p>}
                      <p className="mt-1 text-xs text-ink-400">by {e.by}</p>
                    </li>
                  ))}
                </ol>
              )}
            </div>
          )}

          {/* Actions tab */}
          {tab === 'actions' && (
            <div className="mt-5 flex flex-wrap gap-4">
              {canVerifyPayment && (
                <div className="min-w-[280px] flex-1 rounded-xl border border-warning-500/30 bg-warning-50 p-5">
                  <h3 className="text-sm font-bold text-warning-700">🔍 Verify Payment Proof</h3>
                  <p className="mt-2 text-xs text-ink-600">
                    UTR: <strong>{booking.payment_utr || 'Not provided'}</strong> · Amount claimed:{' '}
                    {currency(booking.payment_amount_claimed || booking.booking_amount || booking.token_amount || booking.total_fare)}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      onClick={() => {
                        setShowVerify(true);
                        setVerifyError(null);
                      }}
                    >
                      ✅ Verify & Confirm
                    </Button>
                    <Button
                      size="sm"
                      variant="danger"
                      onClick={() => {
                        setShowRejectPayment(true);
                        setRejectReason('');
                        setRejectPaymentError(null);
                      }}
                    >
                      ❌ Reject
                    </Button>
                  </div>
                </div>
              )}

              {canComplete && ['vendor_assigned', 'trip_started'].includes(booking.status) && (
                <div className="min-w-[220px] rounded-xl border border-success-500/30 bg-success-50 p-5">
                  <h3 className="text-sm font-bold text-success-700">🏁 Complete Trip</h3>
                  <div className="mt-3">
                    <Button
                      size="sm"
                      onClick={() => {
                        setShowComplete(true);
                        setCompleteError(null);
                      }}
                    >
                      Mark Completed
                    </Button>
                  </div>
                </div>
              )}

              {canResendConfirmation && (
                <div className="min-w-[220px] rounded-xl border border-ink-100 p-5">
                  <h3 className="text-sm font-bold text-ink-900">📧 Resend Confirmation</h3>
                  <p className="mt-1 text-xs text-ink-500">Re-sends the confirmation email/SMS/WhatsApp to the client.</p>
                  <div className="mt-3">
                    <Button size="sm" variant="secondary" loading={resendingConfirmation} onClick={resendConfirmation}>
                      Resend
                    </Button>
                  </div>
                </div>
              )}

              {canMarkNotArranged && (
                <div className="min-w-[260px] rounded-xl border border-warning-500/30 bg-warning-50 p-5">
                  <h3 className="text-sm font-bold text-warning-700">🚗 Booking Not Arranged</h3>
                  <p className="mt-1 text-xs text-warning-700">
                    {brand().name} could not arrange a vehicle for this booking. Marks it as "Booking Amount Refund Due" and refunds the
                    client's booking amount in full.
                  </p>
                  <div className="mt-3">
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => {
                        setShowNotArranged(true);
                        setNotArrangedReason('');
                        setNotArrangedError(null);
                      }}
                      aria-label={`Mark booking ${booking.booking_number} as not arranged`}
                    >
                      Mark Not Arranged
                    </Button>
                  </div>
                </div>
              )}

              {canCancel && (
                <>
                  <div className="min-w-[260px] rounded-xl border border-danger-500/30 bg-danger-50 p-5">
                    <h3 className="text-sm font-bold text-danger-700">🚫 Cancel Booking</h3>
                    <div className="mt-3">
                      <Button
                        size="sm"
                        variant="danger"
                        onClick={() => {
                          setShowCancel(true);
                          setCancelReason('');
                          setCancelError(null);
                        }}
                        aria-label={`Cancel booking ${booking.booking_number}`}
                      >
                        Cancel Booking
                      </Button>
                    </div>
                  </div>

                  <div className="min-w-[220px] rounded-xl border border-ink-100 p-5">
                    <h3 className="text-sm font-bold text-ink-900">🔄 Change Status</h3>
                    <select
                      value={newStatus}
                      onChange={(e) => setNewStatus(e.target.value)}
                      className="mt-3 w-full rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                      aria-label="New booking status"
                    >
                      {STATUS_OPTIONS.map((s) => (
                        <option key={s.value} value={s.value}>
                          {s.label}
                        </option>
                      ))}
                    </select>
                    {statusError && <p className="mt-1.5 text-xs text-danger-600">{statusError}</p>}
                    <div className="mt-3">
                      <Button
                        size="sm"
                        variant="secondary"
                        loading={changingStatus}
                        disabled={newStatus === booking.status}
                        onClick={submitStatusChange}
                      >
                        Update Status
                      </Button>
                    </div>
                  </div>
                </>
              )}

              <div className="min-w-[300px] flex-1 rounded-xl border border-ink-100 p-5">
                <h3 className="text-sm font-bold text-ink-900">📝 Admin Notes</h3>
                <textarea
                  rows={3}
                  value={note}
                  onChange={(e) => {
                    setNote(e.target.value);
                    setNoteSaved(false);
                  }}
                  placeholder="Internal notes about this booking..."
                  className="mt-3 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                  aria-label="Admin notes about this booking"
                />
                {noteError && (
                  <p role="alert" className="mt-2 text-sm text-danger-600">
                    {noteError}
                  </p>
                )}
                {noteSaved && !noteError && <p className="mt-2 text-sm text-success-600">Note saved.</p>}
                <div className="mt-3">
                  <Button variant="secondary" size="sm" onClick={submitNote} loading={savingNote}>
                    Save note
                  </Button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      <ConfirmDialog
        open={showVerify}
        title="Verify payment?"
        description="This confirms the booking and notifies the customer and vendor."
        confirmLabel="Verify payment"
        confirmVariant="primary"
        loading={verifying}
        onConfirm={confirmVerify}
        onCancel={() => {
          if (verifying) return;
          setShowVerify(false);
          setVerifyError(null);
        }}
      >
        {verifyError && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {verifyError}
          </div>
        )}
      </ConfirmDialog>

      <ConfirmDialog
        open={showRejectPayment}
        title="Reject payment"
        description="Let the customer know why their payment proof was rejected."
        confirmLabel="Reject payment"
        confirmVariant="danger"
        loading={rejectingPayment}
        confirmDisabled={!rejectReason.trim()}
        onConfirm={confirmRejectPayment}
        onCancel={() => {
          if (rejectingPayment) return;
          setShowRejectPayment(false);
          setRejectReason('');
          setRejectPaymentError(null);
        }}
      >
        {rejectPaymentError && (
          <div role="alert" className="mb-3 rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {rejectPaymentError}
          </div>
        )}
        <label htmlFor="reject-payment-reason" className="block text-sm font-medium text-ink-700">
          Reason (required)
        </label>
        <textarea
          id="reject-payment-reason"
          rows={3}
          value={rejectReason}
          onChange={(e) => setRejectReason(e.target.value)}
          placeholder="e.g. Payment amount doesn't match the booking total"
          className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        />
      </ConfirmDialog>

      <ConfirmDialog
        open={showNotArranged}
        title="Mark booking as not arranged?"
        description={`${brand().name} could not arrange the requested vehicle. This refunds the client's booking amount in full and notifies them. This cannot be undone.`}
        confirmLabel="Mark not arranged"
        confirmVariant="danger"
        loading={markingNotArranged}
        onConfirm={confirmNotArranged}
        onCancel={() => {
          if (markingNotArranged) return;
          setShowNotArranged(false);
          setNotArrangedReason('');
          setNotArrangedError(null);
        }}
      >
        {notArrangedError && (
          <div role="alert" className="mb-3 rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {notArrangedError}
          </div>
        )}
        <label htmlFor="not-arranged-reason" className="block text-sm font-medium text-ink-700">
          Reason (optional)
        </label>
        <input
          id="not-arranged-reason"
          type="text"
          value={notArrangedReason}
          onChange={(e) => setNotArrangedReason(e.target.value)}
          placeholder="e.g. No vendor available for this route/date"
          className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        />
      </ConfirmDialog>

      <ConfirmDialog
        open={showCancel}
        title="Cancel booking?"
        description="This refunds the customer per the cancellation policy and notifies both parties. This cannot be undone."
        confirmLabel="Cancel booking"
        confirmVariant="danger"
        loading={cancelling}
        onConfirm={confirmCancel}
        onCancel={() => {
          if (cancelling) return;
          setShowCancel(false);
          setCancelReason('');
          setCancelError(null);
        }}
      >
        {cancelError && (
          <div role="alert" className="mb-3 rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {cancelError}
          </div>
        )}
        <label htmlFor="cancel-reason" className="block text-sm font-medium text-ink-700">
          Reason (required)
        </label>
        <input
          id="cancel-reason"
          type="text"
          value={cancelReason}
          onChange={(e) => setCancelReason(e.target.value)}
          placeholder="e.g. Vendor unable to fulfil the trip"
          className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        />
      </ConfirmDialog>

      <ConfirmDialog
        open={showComplete}
        title="Mark booking completed?"
        description="This marks the trip as finished."
        confirmLabel="Mark completed"
        confirmVariant="primary"
        loading={completing}
        onConfirm={confirmComplete}
        onCancel={() => {
          if (completing) return;
          setShowComplete(false);
          setCompleteError(null);
        }}
      >
        {completeError && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {completeError}
          </div>
        )}
      </ConfirmDialog>

      <ConfirmDialog
        open={viewAsOpen}
        title={`View as ${booking ? booking.client_name : 'this client'}?`}
        description="You will see the client app exactly as this client sees it. The session is time-limited, every start and stop is written to the audit log, and passwords and profile details cannot be changed while viewing as this client."
        confirmLabel="Start view-as session"
        loading={viewAsBusy}
        onConfirm={confirmViewAsClient}
        onCancel={() => { if (!viewAsBusy) setViewAsOpen(false); }}
      >
        {viewAsError && (
          <p role="alert" className="text-sm text-danger-600">
            {viewAsError}
          </p>
        )}
      </ConfirmDialog>

      <ConfirmDialog
        open={showAssign}
        title="Assign vendor"
        description={
          booking
            ? `Assign ${vendorOptions.find((v) => String(v.id) === assignVendorId)?.business_name || 'this vendor'} to booking ${
                booking.booking_number
              }?`
            : 'Assign this vendor to the booking?'
        }
        confirmLabel="Assign"
        confirmVariant="primary"
        loading={assigning}
        confirmDisabled={!assignVendorId.trim()}
        onConfirm={confirmAssign}
        onCancel={() => {
          if (assigning) return;
          setShowAssign(false);
          setAssignError(null);
        }}
      >
        {assignError && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {assignError}
          </div>
        )}
      </ConfirmDialog>
    </div>
  );
}
