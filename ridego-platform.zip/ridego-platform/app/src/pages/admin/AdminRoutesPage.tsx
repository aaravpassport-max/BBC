import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  createAdminRoute,
  deleteAdminRoute,
  deleteRouteVehiclePricing,
  getAdminCities,
  getAdminRoutes,
  getVehicles,
  saveRouteVehiclePricing,
  updateAdminRoute,
  ApiError,
} from '../../lib/api';
import type { AdminRouteInput, AdminRouteRow, City, Vehicle } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';

const EMPTY_FORM: AdminRouteInput = {
  from_city_id: 0,
  to_city_id: 0,
  distance_km: '',
  duration_mins: '',
  toll_estimate: '',
  default_fixed_price: '',
  is_popular: false,
  is_active: true,
};

function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

export function AdminRoutesPage() {
  const [rows, setRows] = useState<AdminRouteRow[] | null>(null);
  const [cities, setCities] = useState<City[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<AdminRouteRow | null>(null);
  const [form, setForm] = useState<AdminRouteInput>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [deleteTarget, setDeleteTarget] = useState<AdminRouteRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [pricingVehicleId, setPricingVehicleId] = useState('');
  const [pricingFixed, setPricingFixed] = useState('');
  const [pricingToll, setPricingToll] = useState('');
  const [savingPricing, setSavingPricing] = useState(false);
  const [pricingError, setPricingError] = useState<string | null>(null);
  const [removeOverrideTarget, setRemoveOverrideTarget] = useState<{ id: number; label: string } | null>(null);
  const [removingOverride, setRemovingOverride] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [routesRes, citiesRes, vehiclesRes] = await Promise.all([
        getAdminRoutes(),
        getAdminCities(),
        getVehicles(),
      ]);
      setRows(routesRes.rows);
      setCities(citiesRes.rows);
      setVehicles(vehiclesRes);
    } catch (err) {
      if (err instanceof ApiError && err.code === 'forbidden') {
        setError("You don't have permission to manage routes.");
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not load routes. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function openAdd() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setFormError(null);
    setShowForm(true);
  }

  function openEdit(route: AdminRouteRow) {
    setEditing(route);
    setForm({
      from_city_id: route.from_city_id,
      to_city_id: route.to_city_id,
      distance_km: route.distance_km,
      duration_mins: route.duration_mins,
      toll_estimate: route.toll_estimate ?? '',
      default_fixed_price: route.default_fixed_price ?? '',
      is_popular: route.is_popular,
      is_active: route.is_active,
    });
    setFormError(null);
    setShowForm(true);
  }

  async function submitForm() {
    if (!form.from_city_id || !form.to_city_id) {
      setFormError('Select both cities.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      if (editing) {
        await updateAdminRoute(editing.id, form);
        setActionMessage('Route updated.');
      } else {
        await createAdminRoute(form);
        setActionMessage('Route added.');
      }
      setShowForm(false);
      await load();
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : 'Could not save this route.');
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    setDeleteError(null);
    try {
      await deleteAdminRoute(deleteTarget.id);
      setActionMessage('Route deleted.');
      setDeleteTarget(null);
      await load();
    } catch (err) {
      setDeleteError(err instanceof ApiError ? err.message : 'Could not delete this route.');
    } finally {
      setDeleting(false);
    }
  }

  function toggleExpand(route: AdminRouteRow) {
    setExpandedId((cur) => (cur === route.id ? null : route.id));
    setPricingVehicleId('');
    setPricingFixed('');
    setPricingToll('');
    setPricingError(null);
  }

  async function submitPricingOverride(routeId: number) {
    if (!pricingVehicleId) {
      setPricingError('Select a vehicle.');
      return;
    }
    setSavingPricing(true);
    setPricingError(null);
    try {
      await saveRouteVehiclePricing(routeId, {
        vehicle_id: Number(pricingVehicleId),
        fixed_price: pricingFixed,
        toll_estimate: pricingToll,
      });
      setPricingVehicleId('');
      setPricingFixed('');
      setPricingToll('');
      await load();
    } catch (err) {
      setPricingError(err instanceof ApiError ? err.message : 'Could not save override.');
    } finally {
      setSavingPricing(false);
    }
  }

  async function confirmRemoveOverride() {
    if (!removeOverrideTarget) return;
    setRemovingOverride(true);
    try {
      await deleteRouteVehiclePricing(removeOverrideTarget.id);
      setRemoveOverrideTarget(null);
      await load();
    } catch {
      // The list simply won't reflect the removal; the user can retry.
    } finally {
      setRemovingOverride(false);
    }
  }

  function vehicleName(id: number): string {
    return vehicles.find((v) => v.id === id)?.name ?? `Vehicle #${id}`;
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Link to="/admin/cities" className="text-sm font-medium text-brand-700 hover:text-brand-800">
            ← Cities
          </Link>
          <h1 className="mt-1 text-2xl font-bold text-ink-900 sm:text-3xl">Routes</h1>
          <p className="text-sm text-ink-500">Fixed-price city-pair routes and per-vehicle overrides.</p>
        </div>
        <Button onClick={openAdd} disabled={cities.length < 2}>
          Add route
        </Button>
      </div>

      {actionMessage && !loading && (
        <div role="status" className="mt-4 rounded-lg border border-success-500/30 bg-success-50 px-3.5 py-2.5 text-sm text-success-700">
          {actionMessage}
        </div>
      )}

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading routes">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full rounded-xl" />
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={load} />}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState title="No routes yet" description="Add a fixed-price route between two cities." />
        )}

        {!loading && !error && rows && rows.length > 0 && (
          <ul className="space-y-3">
            {rows.map((r) => (
              <li key={r.id} className="rounded-xl border border-ink-100 shadow-xs">
                <div className="flex flex-wrap items-start justify-between gap-3 p-4 sm:p-5">
                  <div>
                    <p className="font-semibold text-ink-900">
                      {r.from_city} → {r.to_city}
                      {r.is_popular && (
                        <span className="ml-2 rounded-full bg-brand-50 px-2 py-0.5 text-xs font-semibold text-brand-700">
                          Popular
                        </span>
                      )}
                      {!r.is_active && (
                        <span className="ml-2 rounded-full bg-ink-100 px-2 py-0.5 text-xs font-semibold text-ink-500">
                          Inactive
                        </span>
                      )}
                    </p>
                    <p className="mt-0.5 text-sm text-ink-500">
                      {r.distance_km} km &middot; {r.duration_mins} mins
                      {r.default_fixed_price !== null ? ` · ${currency(r.default_fixed_price)}` : ''}
                      {r.toll_estimate !== null ? ` · toll ${currency(r.toll_estimate)}` : ''}
                    </p>
                    <p className="mt-1 text-xs text-ink-400">
                      {r.vehicle_pricing.length} vehicle price override{r.vehicle_pricing.length === 1 ? '' : 's'}
                    </p>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <Button variant="secondary" size="sm" onClick={() => toggleExpand(r)}>
                      {expandedId === r.id ? 'Hide overrides' : 'Vehicle pricing'}
                    </Button>
                    <Button variant="secondary" size="sm" onClick={() => openEdit(r)}>
                      Edit
                    </Button>
                    <Button
                      variant="danger"
                      size="sm"
                      onClick={() => {
                        setDeleteTarget(r);
                        setDeleteError(null);
                      }}
                      aria-label={`Delete route ${r.from_city} to ${r.to_city}`}
                    >
                      Delete
                    </Button>
                  </div>
                </div>

                {expandedId === r.id && (
                  <div className="border-t border-ink-100 bg-ink-50/40 p-4 sm:p-5">
                    {r.vehicle_pricing.length > 0 && (
                      <ul className="space-y-2">
                        {r.vehicle_pricing.map((o) => (
                          <li
                            key={o.id}
                            className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-ink-100 bg-white px-3 py-2 text-sm"
                          >
                            <span>
                              {vehicleName(o.vehicle_id)}
                              {o.fixed_price !== null ? ` · ${currency(o.fixed_price)}` : ''}
                              {o.toll_estimate !== null ? ` · toll ${currency(o.toll_estimate)}` : ''}
                            </span>
                            <Button
                              variant="danger"
                              size="sm"
                              onClick={() => setRemoveOverrideTarget({ id: o.id, label: vehicleName(o.vehicle_id) })}
                              aria-label={`Remove ${vehicleName(o.vehicle_id)} price override`}
                            >
                              Remove
                            </Button>
                          </li>
                        ))}
                      </ul>
                    )}
                    <div className="mt-3 flex flex-wrap items-end gap-2">
                      {pricingError && <p className="w-full text-sm text-danger-600">{pricingError}</p>}
                      <select
                        value={pricingVehicleId}
                        onChange={(e) => setPricingVehicleId(e.target.value)}
                        className="rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                        aria-label="Vehicle to override"
                      >
                        <option value="">Choose vehicle…</option>
                        {vehicles.map((v) => (
                          <option key={v.id} value={v.id}>
                            {v.name}
                          </option>
                        ))}
                      </select>
                      <input
                        type="text"
                        inputMode="decimal"
                        placeholder="Fixed price"
                        value={pricingFixed}
                        onChange={(e) => setPricingFixed(e.target.value)}
                        className="w-28 rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                        aria-label="Fixed price override"
                      />
                      <input
                        type="text"
                        inputMode="decimal"
                        placeholder="Toll estimate"
                        value={pricingToll}
                        onChange={(e) => setPricingToll(e.target.value)}
                        aria-label="Toll estimate override"
                        className="w-28 rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                      />
                      <Button size="sm" loading={savingPricing} onClick={() => submitPricingOverride(r.id)}>
                        Save override
                      </Button>
                    </div>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>

      <ConfirmDialog
        open={showForm}
        title={editing ? 'Edit route' : 'Add route'}
        confirmLabel={editing ? 'Save changes' : 'Create route'}
        confirmVariant="primary"
        loading={saving}
        onConfirm={submitForm}
        onCancel={() => {
          if (saving) return;
          setShowForm(false);
        }}
      >
        <div className="space-y-3">
          {formError && (
            <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
              {formError}
            </div>
          )}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="route-from" className="block text-sm font-medium text-ink-700">
                From city
              </label>
              <select
                id="route-from"
                value={form.from_city_id || ''}
                onChange={(e) => setForm((f) => ({ ...f, from_city_id: Number(e.target.value) }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              >
                <option value="">Choose…</option>
                {cities.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="route-to" className="block text-sm font-medium text-ink-700">
                To city
              </label>
              <select
                id="route-to"
                value={form.to_city_id || ''}
                onChange={(e) => setForm((f) => ({ ...f, to_city_id: Number(e.target.value) }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              >
                <option value="">Choose…</option>
                {cities.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="route-distance" className="block text-sm font-medium text-ink-700">
                Distance (km)
              </label>
              <input
                id="route-distance"
                type="text"
                inputMode="decimal"
                value={form.distance_km}
                onChange={(e) => setForm((f) => ({ ...f, distance_km: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="route-duration" className="block text-sm font-medium text-ink-700">
                Duration (mins)
              </label>
              <input
                id="route-duration"
                type="text"
                inputMode="numeric"
                value={form.duration_mins}
                onChange={(e) => setForm((f) => ({ ...f, duration_mins: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="route-toll" className="block text-sm font-medium text-ink-700">
                Toll estimate
              </label>
              <input
                id="route-toll"
                type="text"
                inputMode="decimal"
                value={form.toll_estimate}
                onChange={(e) => setForm((f) => ({ ...f, toll_estimate: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="route-price" className="block text-sm font-medium text-ink-700">
                Fixed price
              </label>
              <input
                id="route-price"
                type="text"
                inputMode="decimal"
                value={form.default_fixed_price}
                onChange={(e) => setForm((f) => ({ ...f, default_fixed_price: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
              <p className="mt-1 text-xs text-ink-400">Leave blank to fall back to standard per-km fare calculation.</p>
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={!!form.is_popular}
              onChange={(e) => setForm((f) => ({ ...f, is_popular: e.target.checked }))}
              className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
            />
            Popular route
          </label>
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={form.is_active !== false}
              onChange={(e) => setForm((f) => ({ ...f, is_active: e.target.checked }))}
              className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
            />
            Active
          </label>
        </div>
      </ConfirmDialog>

      <ConfirmDialog
        open={!!deleteTarget}
        title={`Delete ${deleteTarget?.from_city ?? ''} → ${deleteTarget?.to_city ?? ''}?`}
        description="This also removes any per-vehicle price overrides for this route. This cannot be undone."
        confirmLabel="Delete route"
        confirmVariant="danger"
        loading={deleting}
        onConfirm={confirmDelete}
        onCancel={() => {
          if (deleting) return;
          setDeleteTarget(null);
          setDeleteError(null);
        }}
      >
        {deleteError && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {deleteError}
          </div>
        )}
      </ConfirmDialog>

      <ConfirmDialog
        open={!!removeOverrideTarget}
        title={`Remove ${removeOverrideTarget?.label ?? ''} price override?`}
        description="This route falls back to its default fixed price (or standard per-km fare) for this vehicle. This cannot be undone."
        confirmLabel="Remove override"
        confirmVariant="danger"
        loading={removingOverride}
        onConfirm={confirmRemoveOverride}
        onCancel={() => {
          if (removingOverride) return;
          setRemoveOverrideTarget(null);
        }}
      />
    </div>
  );
}
