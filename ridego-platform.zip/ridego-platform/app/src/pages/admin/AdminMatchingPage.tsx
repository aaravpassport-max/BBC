import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { ApiError } from '../../lib/api';
import {
  activateMatchingProfile,
  backtestMatching,
  getMatching,
  saveMatchingFlags,
  saveMatchingProfile,
  type MatchingBacktestResponse,
  type MatchingFlagKey,
  type MatchingResponse,
} from '../../lib/api-admin-finance';
import { useToast } from '../../context/ToastContext';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';

const inputCls =
  'mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500/40';

interface FlagInfo {
  key: MatchingFlagKey;
  label: string;
  summary: string;
  whenOn: string;
  whenOff: string;
}

const FLAGS: FlagInfo[] = [
  {
    key: 'performance_based_matching',
    label: 'Performance-based matching',
    summary: 'Scores the vendors who responded and stores a recommendation (recommend only, nothing is assigned).',
    whenOn:
      'Every time a vendor responds, the responders are scored with the active weights and the top match, with the full factor breakdown, is stored and shown on the comparison screen. Choosing a different vendor then requires a written reason.',
    whenOff: 'No scores or new recommendations are produced, and admins no longer need to give a reason when choosing a vendor. Earlier recommendations stay visible.',
  },
  {
    key: 'automatic_driver_selection',
    label: 'Automatic driver selection',
    summary: 'For a fleet vendor who showed interest but has not chosen a driver, picks the best available driver and vehicle.',
    whenOn:
      'When a fleet vendor shows interest without confirming a driver and vehicle, the best available pair for that trip (rating, vehicle fit, availability, branch in the pickup city) is confirmed for them straight away.',
    whenOff: 'Fleet vendors must choose and confirm their own driver and vehicle.',
  },
  {
    key: 'automatic_vendor_assignment',
    label: 'Automatic vendor assignment',
    summary: 'Assigns a booking to the top-ranked vendor without an admin choosing.',
    whenOn:
      'Once every offered vendor has responded (or the response window closes), the top-ranked vendor is assigned automatically if their score is at or above the minimum score below and their driver and vehicle are confirmed. The assignment is recorded as automatic and an admin can still change it.',
    whenOff: 'Every booking waits for an admin to select the vendor.',
  },
  {
    key: 'automatic_reassignment',
    label: 'Automatic reassignment',
    summary: 'When an assigned vendor drops out, moves the booking to the next-best vendor who already responded.',
    whenOn:
      'When a booking is reopened (for example after a reported no-show), the best-scoring earlier responder whose driver and vehicle are still free is assigned automatically. If nobody qualifies the booking is offered to other vendors again.',
    whenOff: 'A reported no-show is only recorded; an admin must reopen and reassign the booking manually.',
  },
];

interface PendingFlag {
  info: FlagInfo;
  next: boolean;
}

// TRACE: snake_case key → readable label → string. Preconditions: none → postconditions: pure → edge cases: empty string.
function prettyKey(k: string): string {
  const s = k.replace(/_/g, ' ');
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// TRACE: MySQL datetime → short local date-time → string. Preconditions: none → postconditions: pure →
//        edge cases: empty gives an em dash, unparseable is returned unchanged.
function fmtDate(s: string | null | undefined): string {
  if (!s) return '—';
  const d = new Date(s.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}

// TRACE: was_followed column (null, 0, 1 or '0'/'1') → outcome label → "Followed" | "Overridden" | "Not decided yet".
//        Preconditions: none → postconditions: pure → edge cases: null means the admin has not assigned yet.
function outcomeLabel(v: number | string | null): string {
  if (v === null || v === undefined) return 'Not decided yet';
  return Number(v) === 1 ? 'Followed' : 'Overridden';
}

// TRACE: back-test result → plain-language summary → JSX. Preconditions: result from the API → postconditions: pure →
//        edge cases: zero samples explains why there is nothing to compare.
function BacktestSummary({ result }: { result: MatchingBacktestResponse }) {
  if (result.samples === 0) {
    return <p>No completed bookings with two or more responding vendors yet, so there is nothing to replay.</p>;
  }
  return (
    <p>
      Replayed against <strong>{result.samples}</strong> completed {result.samples === 1 ? 'booking' : 'bookings'} that had two or more responding
      vendors: these weights would have picked the vendor that was actually used in <strong>{result.agreement_pct}%</strong> of them
      {result.agreement_pct > 0 ? `, and ${result.agreed_good_pct}% of those trips went well (no no-show, late arrival, complaint or low rating)` : ''}.
      {result.disagreements > 0
        ? ` In the ${result.disagreements} other ${result.disagreements === 1 ? 'booking' : 'bookings'} it would have chosen someone else; the vendor actually used had a problem in ${result.disagreements_actual_bad_pct}% of them.`
        : ''}
    </p>
  );
}

// TRACE: route /app/admin/matching → loads flags, active weight profile and recent outcomes; flag flips go through a
//        ConfirmDialog; weights can be back-tested and saved as a new version.
//        Preconditions: cap ridego_manage_automatic_assignment → postconditions: each mutation refreshes state from the server →
//        edge cases: loading skeleton, error banner with retry, all flags off by default, no outcomes yet (empty state),
//        stale responses dropped, weights all zero or negative blocked, drafts kept on failure and reset on success,
//        editing weights clears a stale back-test result, double submit blocked.
export function AdminMatchingPage() {
  const toast = useToast();
  const [data, setData] = useState<MatchingResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const seq = useRef(0);
  const profileKey = useRef('');

  const [pending, setPending] = useState<PendingFlag | null>(null);
  const [flagSaving, setFlagSaving] = useState(false);
  const [flagError, setFlagError] = useState<string | null>(null);
  const [minScore, setMinScore] = useState('70');
  const [scoreSaving, setScoreSaving] = useState(false);

  const [weights, setWeights] = useState<Record<string, string>>({});
  const [profileName, setProfileName] = useState('');
  const [profileSaving, setProfileSaving] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);
  const [backtest, setBacktest] = useState<MatchingBacktestResponse | null>(null);
  const [testing, setTesting] = useState(false);
  const [testError, setTestError] = useState<string | null>(null);
  const [versionBusy, setVersionBusy] = useState<number | null>(null);
  const [versionTest, setVersionTest] = useState<{ id: number; result: MatchingBacktestResponse } | null>(null);

  // TRACE: server payload → copies the active profile into the editable drafts when it is a different profile version.
  //        Preconditions: payload → postconditions: drafts replaced only when the profile id/version changed →
  //        edge cases: flag-only refreshes keep the operator's in-progress weight edits.
  const syncDrafts = useCallback((res: MatchingResponse) => {
    setMinScore(String(res.auto_assign_min_score));
    const key = `${res.profile.id}:${res.profile.version}`;
    if (key === profileKey.current) return;
    profileKey.current = key;
    const next: Record<string, string> = {};
    for (const f of res.factors) next[f] = String(Math.round((res.profile.weights[f] ?? 0) * 10000) / 100);
    setWeights(next);
    setProfileName(res.profile.name);
    setBacktest(null);
  }, []);

  // TRACE: mount / retry → GET matching → stores payload and drafts. Preconditions: none →
  //        postconditions: latest request wins → edge cases: ApiError message shown, stale response dropped.
  const load = useCallback(async () => {
    const id = ++seq.current;
    setLoading(true);
    setError(null);
    try {
      const res = await getMatching();
      if (id !== seq.current) return;
      setData(res);
      syncDrafts(res);
    } catch (err) {
      if (id !== seq.current) return;
      setError(err instanceof ApiError ? err.message : 'Could not load matching settings. Please try again.');
    } finally {
      if (id === seq.current) setLoading(false);
    }
  }, [syncDrafts]);

  // TRACE: mount → runs load; unmount → invalidates in-flight request. Preconditions: none →
  //        postconditions: no state writes after unmount → edge cases: none.
  useEffect(() => {
    void load();
    return () => {
      seq.current += 1;
    };
  }, [load]);

  // TRACE: flag switch click → opens the confirm dialog for turning that flag on or off.
  //        Preconditions: data loaded → postconditions: nothing changes until confirmed → edge cases: previous error cleared.
  function askFlag(info: FlagInfo, next: boolean) {
    setFlagError(null);
    setPending({ info, next });
  }

  // TRACE: dialog cancel/Escape → closes the flag dialog unless a save is in flight.
  //        Preconditions: none → postconditions: pending cleared → edge cases: ignored while saving.
  const closeFlag = useCallback(() => {
    if (!flagSaving) setPending(null);
  }, [flagSaving]);

  // TRACE: dialog confirm → POST flag (and min score when enabling auto-assign) → toast, close, adopt refreshed payload.
  //        Preconditions: pending flag, min score within 0..100 when enabling auto-assign → postconditions: setting stored and audited →
  //        edge cases: invalid score blocked with message, ApiError shown in dialog and toast, double submit blocked.
  async function confirmFlag() {
    if (!pending || flagSaving) return;
    const body: { auto_assign_min_score?: number } & Partial<Record<MatchingFlagKey, boolean>> = { [pending.info.key]: pending.next };
    if (pending.info.key === 'automatic_vendor_assignment' && pending.next) {
      const s = Number(minScore);
      if (minScore.trim() === '' || !Number.isFinite(s) || s < 0 || s > 100) {
        setFlagError('Enter a minimum score between 0 and 100.');
        return;
      }
      body.auto_assign_min_score = s;
    }
    setFlagSaving(true);
    setFlagError(null);
    try {
      const res = await saveMatchingFlags(body);
      setData(res);
      syncDrafts(res);
      toast.show(`${pending.info.label} turned ${pending.next ? 'on' : 'off'}.`, 'success');
      setPending(null);
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Could not change this setting.';
      setFlagError(msg);
      toast.show(msg, 'error');
    } finally {
      setFlagSaving(false);
    }
  }

  // TRACE: "Save minimum score" click → POST only auto_assign_min_score → toast and adopt refreshed payload.
  //        Preconditions: score within 0..100 → postconditions: threshold stored →
  //        edge cases: invalid score toasts an error, ApiError shown, double submit blocked.
  async function saveScore() {
    if (scoreSaving) return;
    const s = Number(minScore);
    if (minScore.trim() === '' || !Number.isFinite(s) || s < 0 || s > 100) {
      toast.show('Enter a minimum score between 0 and 100.', 'error');
      return;
    }
    setScoreSaving(true);
    try {
      const res = await saveMatchingFlags({ auto_assign_min_score: s });
      setData(res);
      syncDrafts(res);
      toast.show(`Automatic assignment minimum score set to ${s}.`, 'success');
    } catch (err) {
      toast.show(err instanceof ApiError ? err.message : 'Could not save the minimum score.', 'error');
    } finally {
      setScoreSaving(false);
    }
  }

  // TRACE: any weight input/slider change → updates that factor's draft and clears the old back-test result.
  //        Preconditions: input name is a factor key → postconditions: other factors untouched →
  //        edge cases: blank text allowed while typing.
  function handleWeight(e: ChangeEvent<HTMLInputElement>) {
    const { name, value } = e.target;
    setWeights((prev) => ({ ...prev, [name]: value }));
    setBacktest(null);
    setTestError(null);
  }

  const parsed = useMemo(() => {
    const out: Record<string, number> = {};
    let invalid = false;
    for (const [k, v] of Object.entries(weights)) {
      const n = v.trim() === '' ? 0 : Number(v);
      if (!Number.isFinite(n) || n < 0) invalid = true;
      out[k] = Number.isFinite(n) ? n : 0;
    }
    const sum = Object.values(out).reduce((a, b) => a + b, 0);
    return { values: out, sum, invalid, ok: !invalid && sum > 0 };
  }, [weights]);

  // TRACE: "Back-test these weights" click → POST backtest with the draft weights → shows samples and agreement %.
  //        Preconditions: valid draft weights → postconditions: read-only replay →
  //        edge cases: invalid weights blocked, zero samples explained, ApiError shown, double submit blocked.
  async function runBacktest() {
    if (testing || !parsed.ok) return;
    setTesting(true);
    setTestError(null);
    try {
      setBacktest(await backtestMatching({ weights: parsed.values }));
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Could not run the back-test.';
      setTestError(msg);
      toast.show(msg, 'error');
    } finally {
      setTesting(false);
    }
  }

  // TRACE: "Back-test" on a stored version → POST backtest {profile_id} → shows its summary under that row.
  //        Preconditions: no other version action in flight → postconditions: read-only replay →
  //        edge cases: ApiError toasted, busy state blocks double clicks.
  async function testVersion(id: number) {
    if (versionBusy !== null) return;
    setVersionBusy(id);
    try {
      setVersionTest({ id, result: await backtestMatching({ profile_id: id }) });
    } catch (err) {
      toast.show(err instanceof ApiError ? err.message : 'Could not run the back-test.', 'error');
    } finally {
      setVersionBusy(null);
    }
  }

  // TRACE: "Activate" on a stored version → POST activate → toast and re-fetch so the active marker and weight drafts move.
  //        Preconditions: no other version action in flight → postconditions: exactly one active version, old ones kept →
  //        edge cases: ApiError toasted, busy state blocks double clicks.
  async function activateVersion(id: number) {
    if (versionBusy !== null) return;
    setVersionBusy(id);
    try {
      const res = await activateMatchingProfile(id);
      toast.show(res.message || 'Profile activated.', 'success');
      profileKey.current = '';
      setVersionTest(null);
      await load();
    } catch (err) {
      toast.show(err instanceof ApiError ? err.message : 'Could not activate the profile.', 'error');
    } finally {
      setVersionBusy(null);
    }
  }

  // TRACE: profile form submit → POST a NEW weight profile version → toast, re-fetch matching state (drafts reset to the saved version).
  //        Preconditions: valid weights (non-negative, sum above zero) → postconditions: new active version, old versions kept →
  //        edge cases: invalid weights blocked, ApiError shown with drafts kept, double submit blocked.
  async function submitProfile(e: FormEvent) {
    e.preventDefault();
    if (profileSaving) return;
    if (!parsed.ok) {
      setProfileError(parsed.invalid ? 'Weights must be numbers of zero or more.' : 'At least one weight must be above zero.');
      return;
    }
    setProfileSaving(true);
    setProfileError(null);
    try {
      await saveMatchingProfile(profileName.trim() || 'Custom', parsed.values);
      toast.show('Saved as a new inactive version. Back-test it, then activate it from the list below.', 'success');
      profileKey.current = '';
      await load();
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Could not save the weights.';
      setProfileError(msg);
      toast.show(msg, 'error');
    } finally {
      setProfileSaving(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Vendor matching</h1>
      <p className="text-sm text-ink-500">Every automation below is off until you turn it on. Nothing is switched on for you.</p>

      {loading && !data && (
        <div className="mt-6 space-y-3" aria-busy="true" aria-label="Loading matching settings">
          <Skeleton className="h-24 w-full rounded-xl" />
          <Skeleton className="h-24 w-full rounded-xl" />
          <Skeleton className="h-48 w-full rounded-xl" />
        </div>
      )}
      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {data && (
        <>
          <section className="mt-6" aria-labelledby="flags-heading">
            <h2 id="flags-heading" className="text-base font-semibold text-ink-900">
              Automation switches
            </h2>
            <ul className="mt-3 space-y-3">
              {FLAGS.map((f) => {
                const on = !!data.flags[f.key];
                return (
                  <li key={f.key} className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs">
                    <div className="flex items-start justify-between gap-4">
                      <div className="min-w-0">
                        <p id={`flag-${f.key}`} className="font-semibold text-ink-900">
                          {f.label}
                        </p>
                        <p className="mt-0.5 text-sm text-ink-600">{f.summary}</p>
                      </div>
                      <div className="flex shrink-0 items-center gap-2">
                        <span className="text-sm font-medium text-ink-700">{on ? 'On' : 'Off'}</span>
                        <button
                          type="button"
                          role="switch"
                          aria-checked={on}
                          aria-labelledby={`flag-${f.key}`}
                          onClick={() => askFlag(f, !on)}
                          className={`relative h-6 w-11 rounded-full transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 ${on ? 'bg-brand-600' : 'bg-ink-300'}`}
                        >
                          <span className={`absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${on ? 'translate-x-5' : ''}`} />
                        </button>
                      </div>
                    </div>
                    {f.key === 'automatic_vendor_assignment' && (
                      <div className="mt-3 flex flex-wrap items-end gap-2 border-t border-ink-100 pt-3">
                        <div>
                          <label htmlFor="min-score" className="block text-sm font-medium text-ink-700">
                            Minimum score to auto-assign (0 to 100)
                          </label>
                          <input
                            id="min-score"
                            type="number"
                            min={0}
                            max={100}
                            step="1"
                            value={minScore}
                            onChange={(e) => setMinScore(e.target.value)}
                            className={`${inputCls} w-32`}
                          />
                        </div>
                        <Button variant="secondary" size="sm" onClick={saveScore} loading={scoreSaving}>
                          Save minimum score
                        </Button>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          </section>

          <section className="mt-8 rounded-xl border border-ink-100 p-5 shadow-xs" aria-labelledby="weights-heading">
            <h2 id="weights-heading" className="text-base font-semibold text-ink-900">
              Scoring weights
            </h2>
            <p className="mt-1 text-sm text-ink-500">
              Active profile: {data.profile.name}
              {data.profile.version ? ` (version ${data.profile.version})` : ' (built-in default, not yet saved)'}. Weights are
              normalised so they add up to 100%.
            </p>
            <form onSubmit={submitProfile} className="mt-4 space-y-4" noValidate>
              <ul className="space-y-4">
                {data.factors.map((f) => {
                  const w = parsed.values[f] ?? 0;
                  const pct = parsed.sum > 0 ? (w / parsed.sum) * 100 : 0;
                  return (
                    <li key={f} className="grid gap-2 sm:grid-cols-[9rem_1fr_6rem_5rem] sm:items-center">
                      <label htmlFor={`w-num-${f}`} className="text-sm font-medium text-ink-800">
                        {prettyKey(f)}
                      </label>
                      <input
                        type="range"
                        name={f}
                        min={0}
                        max={100}
                        step={1}
                        value={Math.min(100, w)}
                        onChange={handleWeight}
                        aria-label={`${prettyKey(f)} weight slider`}
                        className="w-full accent-brand-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600"
                      />
                      <input
                        id={`w-num-${f}`}
                        type="number"
                        name={f}
                        min={0}
                        step="1"
                        value={weights[f] ?? ''}
                        onChange={handleWeight}
                        className={`${inputCls} mt-0`}
                      />
                      <span className="text-sm font-semibold text-ink-900" aria-label={`${prettyKey(f)} share after normalising`}>
                        {pct.toFixed(1)}%
                      </span>
                    </li>
                  );
                })}
              </ul>
              <p className="text-xs text-ink-500">Total of raw weights: {parsed.sum}. Shares shown are what the engine will actually use.</p>
              <div>
                <label htmlFor="profile-name" className="block text-sm font-medium text-ink-700">
                  Version name
                </label>
                <input id="profile-name" type="text" value={profileName} onChange={(e) => setProfileName(e.target.value)} className={`${inputCls} sm:max-w-xs`} />
              </div>
              {profileError && (
                <p role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
                  {profileError}
                </p>
              )}
              <div className="flex flex-wrap gap-2">
                <Button type="button" variant="secondary" onClick={runBacktest} loading={testing} disabled={!parsed.ok}>
                  Back-test these weights
                </Button>
                <Button type="submit" loading={profileSaving} disabled={!parsed.ok}>
                  Save as new version
                </Button>
              </div>
            </form>
            {testError && (
              <p role="alert" className="mt-3 text-sm text-danger-600">
                {testError}
              </p>
            )}
            {backtest && (
              <div role="status" className="mt-4 rounded-lg border border-brand-200 bg-brand-50 px-4 py-3 text-sm text-brand-900">
                <BacktestSummary result={backtest} />
              </div>
            )}
          </section>

          <section className="mt-8" aria-labelledby="versions-heading">
            <h2 id="versions-heading" className="text-base font-semibold text-ink-900">
              Stored weight versions
            </h2>
            <p className="mt-1 text-sm text-ink-500">Versions are never edited or deleted, so switching back is one click.</p>
            {data.profiles.length === 0 ? (
              <div className="mt-3">
                <EmptyState title="No versions saved yet" description="The built-in defaults are in use. Save the weights above to create the first version." />
              </div>
            ) : (
              <ul className="mt-3 space-y-3">
                {data.profiles.map((p) => (
                  <li key={p.id} className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="font-semibold text-ink-900">
                          {p.name} <span className="font-normal text-ink-500">(version {p.version})</span>{' '}
                          {p.is_active && <span className="ml-1 rounded-full bg-success-50 px-2 py-0.5 text-xs font-medium text-success-700">Active</span>}
                        </p>
                        <p className="mt-1 text-xs text-ink-600">
                          {Object.entries(p.weights)
                            .map(([k, v]) => `${prettyKey(k)} ${Math.round(v * 1000) / 10}%`)
                            .join(' · ')}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="secondary" onClick={() => testVersion(p.id)} loading={versionBusy === p.id} disabled={versionBusy !== null && versionBusy !== p.id}>
                          Back-test
                        </Button>
                        {!p.is_active && (
                          <Button size="sm" onClick={() => activateVersion(p.id)} loading={versionBusy === p.id} disabled={versionBusy !== null && versionBusy !== p.id}>
                            Activate
                          </Button>
                        )}
                      </div>
                    </div>
                    {versionTest && versionTest.id === p.id && (
                      <div role="status" className="mt-3 rounded-lg border border-brand-200 bg-brand-50 px-4 py-3 text-sm text-brand-900">
                        <BacktestSummary result={versionTest.result} />
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="mt-8" aria-labelledby="outcomes-heading">
            <h2 id="outcomes-heading" className="text-base font-semibold text-ink-900">
              Recent recommendation outcomes
            </h2>
            {data.recent.length === 0 ? (
              <div className="mt-3">
                <EmptyState title="No recommendations yet" description="Recommendations appear here once Performance-based matching is on and bookings receive interest." />
              </div>
            ) : (
              <div className="mt-3 overflow-x-auto rounded-xl border border-ink-100">
                <table className="w-full min-w-[640px] text-sm">
                  <thead className="bg-ink-50 text-left text-xs font-medium uppercase tracking-wide text-ink-500">
                    <tr>
                      <th className="px-4 py-3">Booking</th>
                      <th className="px-4 py-3 text-right">Score</th>
                      <th className="px-4 py-3">Outcome</th>
                      <th className="px-4 py-3">Override reason</th>
                      <th className="px-4 py-3">When</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {data.recent.map((r) => (
                      <tr key={String(r.id)}>
                        <td className="px-4 py-3 font-medium">
                          <Link to={`/app/admin/bookings/${r.booking_id}`} className="text-brand-700 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600">
                            {r.booking_number ?? `#${r.booking_id}`}
                          </Link>
                        </td>
                        <td className="px-4 py-3 text-right">{Number(r.score).toFixed(1)}</td>
                        <td className="px-4 py-3 text-ink-800">{outcomeLabel(r.was_followed)}</td>
                        <td className="px-4 py-3 text-ink-700">{r.override_reason || '—'}</td>
                        <td className="px-4 py-3 text-xs text-ink-500">{fmtDate(r.created_at)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </>
      )}

      <ConfirmDialog
        open={!!pending}
        title={pending ? `Turn ${pending.info.label} ${pending.next ? 'on' : 'off'}?` : ''}
        description={pending ? (pending.next ? pending.info.whenOn : pending.info.whenOff) : undefined}
        confirmLabel={pending?.next ? 'Turn on' : 'Turn off'}
        confirmVariant={pending?.next ? 'primary' : 'danger'}
        loading={flagSaving}
        onConfirm={confirmFlag}
        onCancel={closeFlag}
      >
        {pending?.info.key === 'automatic_vendor_assignment' && pending.next && (
          <div>
            <label htmlFor="confirm-min-score" className="block text-sm font-medium text-ink-700">
              Minimum score to auto-assign (0 to 100)
            </label>
            <input id="confirm-min-score" type="number" min={0} max={100} value={minScore} onChange={(e) => setMinScore(e.target.value)} className={inputCls} />
          </div>
        )}
        {flagError && (
          <p role="alert" className="mt-2 text-sm text-danger-600">
            {flagError}
          </p>
        )}
      </ConfirmDialog>
    </div>
  );
}
