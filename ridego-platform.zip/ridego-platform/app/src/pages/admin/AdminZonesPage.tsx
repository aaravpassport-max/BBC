import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  createAdminZone,
  deleteAdminZone,
  getAdminCities,
  getAdminZones,
  updateAdminZone,
  ApiError,
} from '../../lib/api';
import type { AdminZoneInput, AdminZoneRow, City } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';

const EMPTY_FORM: AdminZoneInput = {
  city_id: 0,
  name: '',
  center_lat: '',
  center_lng: '',
  radius_km: '3',
  is_active: true,
};

export function AdminZonesPage() {
  const [rows, setRows] = useState<AdminZoneRow[] | null>(null);
  const [cities, setCities] = useState<City[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<AdminZoneRow | null>(null);
  const [form, setForm] = useState<AdminZoneInput>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [deleteTarget, setDeleteTarget] = useState<AdminZoneRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [zonesRes, citiesRes] = await Promise.all([getAdminZones(), getAdminCities()]);
      setRows(zonesRes.rows);
      setCities(citiesRes.rows);
    } catch (err) {
      if (err instanceof ApiError && err.code === 'forbidden') {
        setError("You don't have permission to manage zones.");
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not load zones. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function openAdd() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setFormError(null);
    setShowForm(true);
  }

  function openEdit(zone: AdminZoneRow) {
    setEditing(zone);
    setForm({
      city_id: zone.city_id,
      name: zone.name,
      center_lat: zone.center_lat,
      center_lng: zone.center_lng,
      radius_km: zone.radius_km,
      is_active: zone.is_active,
    });
    setFormError(null);
    setShowForm(true);
  }

  async function submitForm() {
    if (!form.city_id) {
      setFormError('Select a city.');
      return;
    }
    if (!form.name?.trim()) {
      setFormError('Please provide a zone name.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      if (editing) {
        await updateAdminZone(editing.id, form);
        setActionMessage('Zone updated.');
      } else {
        await createAdminZone(form);
        setActionMessage('Zone added.');
      }
      setShowForm(false);
      await load();
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : 'Could not save this zone.');
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    setDeleteError(null);
    try {
      await deleteAdminZone(deleteTarget.id);
      setActionMessage('Zone deleted.');
      setDeleteTarget(null);
      await load();
    } catch (err) {
      setDeleteError(err instanceof ApiError ? err.message : 'Could not delete this zone.');
    } finally {
      setDeleting(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Link to="/admin/cities" className="text-sm font-medium text-brand-700 hover:text-brand-800">
            ← Cities
          </Link>
          <h1 className="mt-1 text-2xl font-bold text-ink-900 sm:text-3xl">Zones</h1>
          <p className="text-sm text-ink-500">
            Center-point + radius service zones within a city, used for surge pricing and coverage.
          </p>
        </div>
        <Button onClick={openAdd} disabled={cities.length === 0}>
          Add zone
        </Button>
      </div>

      {actionMessage && !loading && (
        <div role="status" className="mt-4 rounded-lg border border-success-500/30 bg-success-50 px-3.5 py-2.5 text-sm text-success-700">
          {actionMessage}
        </div>
      )}

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading zones">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full rounded-xl" />
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={load} />}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState title="No zones yet" description="Add a service zone to enable zone-based surge pricing." />
        )}

        {!loading && !error && rows && rows.length > 0 && (
          <ul className="space-y-3">
            {rows.map((z) => (
              <li key={z.id} className="flex flex-wrap items-start justify-between gap-3 rounded-xl border border-ink-100 p-4 shadow-xs sm:p-5">
                <div>
                  <p className="font-semibold text-ink-900">
                    {z.name}
                    {!z.is_active && (
                      <span className="ml-2 rounded-full bg-ink-100 px-2 py-0.5 text-xs font-semibold text-ink-500">
                        Inactive
                      </span>
                    )}
                  </p>
                  <p className="mt-0.5 text-sm text-ink-500">{z.city_name}</p>
                  <p className="mt-1 text-xs text-ink-400">
                    Center {z.center_lat.toFixed(5)}, {z.center_lng.toFixed(5)} &middot; radius {z.radius_km} km
                  </p>
                </div>
                <div className="flex shrink-0 gap-2">
                  <Button variant="secondary" size="sm" onClick={() => openEdit(z)}>
                    Edit
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => {
                      setDeleteTarget(z);
                      setDeleteError(null);
                    }}
                    aria-label={`Delete zone ${z.name}`}
                  >
                    Delete
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <ConfirmDialog
        open={showForm}
        title={editing ? `Edit ${editing.name}` : 'Add zone'}
        confirmLabel={editing ? 'Save changes' : 'Create zone'}
        confirmVariant="primary"
        loading={saving}
        onConfirm={submitForm}
        onCancel={() => {
          if (saving) return;
          setShowForm(false);
        }}
      >
        <div className="space-y-3">
          {formError && (
            <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
              {formError}
            </div>
          )}
          <div>
            <label htmlFor="zone-city" className="block text-sm font-medium text-ink-700">
              City
            </label>
            <select
              id="zone-city"
              value={form.city_id || ''}
              onChange={(e) => setForm((f) => ({ ...f, city_id: Number(e.target.value) }))}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            >
              <option value="">Choose…</option>
              {cities.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="zone-name" className="block text-sm font-medium text-ink-700">
              Zone name
            </label>
            <input
              id="zone-name"
              type="text"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <label htmlFor="zone-lat" className="block text-sm font-medium text-ink-700">
                Center lat
              </label>
              <input
                id="zone-lat"
                type="text"
                inputMode="decimal"
                value={form.center_lat}
                onChange={(e) => setForm((f) => ({ ...f, center_lat: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="zone-lng" className="block text-sm font-medium text-ink-700">
                Center lng
              </label>
              <input
                id="zone-lng"
                type="text"
                inputMode="decimal"
                value={form.center_lng}
                onChange={(e) => setForm((f) => ({ ...f, center_lng: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="zone-radius" className="block text-sm font-medium text-ink-700">
                Radius (km)
              </label>
              <input
                id="zone-radius"
                type="text"
                inputMode="decimal"
                value={form.radius_km}
                onChange={(e) => setForm((f) => ({ ...f, radius_km: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={form.is_active !== false}
              onChange={(e) => setForm((f) => ({ ...f, is_active: e.target.checked }))}
              className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
            />
            Active
          </label>
        </div>
      </ConfirmDialog>

      <ConfirmDialog
        open={!!deleteTarget}
        title={`Delete ${deleteTarget?.name ?? ''}?`}
        description="Any surge-pricing rules pinned to this zone will fall back to city-wide matching. This cannot be undone."
        confirmLabel="Delete zone"
        confirmVariant="danger"
        loading={deleting}
        onConfirm={confirmDelete}
        onCancel={() => {
          if (deleting) return;
          setDeleteTarget(null);
          setDeleteError(null);
        }}
      >
        {deleteError && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {deleteError}
          </div>
        )}
      </ConfirmDialog>
    </div>
  );
}
