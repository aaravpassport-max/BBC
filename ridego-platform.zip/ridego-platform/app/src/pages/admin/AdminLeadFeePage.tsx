import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ApiError } from '../../lib/api';
import {
  adminRecordAcceptance,
  deactivateLeadFeeRule,
  getLeadFeeConfig,
  getLeadFeeHistory,
  getPendingForfeits,
  previewLeadFee,
  saveLeadFeeOptions,
  saveLeadFeeRule,
  type LeadFeeConfig,
  type LeadFeeHistory,
  type LeadFeeMethod,
  type LeadFeeOptions,
  type LeadFeePreview,
  type LeadFeeRule,
  type LeadFeeRuleInput,
  type PendingForfeitRow,
} from '../../lib/api-leadfee';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { brand } from '../../lib/brand';

const inputCls = 'mt-1 w-full rounded-lg border border-ink-200 px-3 py-2 text-sm text-ink-900 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600';
const money = (n: number | undefined | null) => {
  const v = n ?? 0;
  return `₹${v.toLocaleString('en-IN', { minimumFractionDigits: Number.isInteger(v) ? 0 : 2, maximumFractionDigits: 2 })}`;
};

// Which inputs each calculation method needs. The server validates the same rules; this only decides what to show.
const METHOD_FIELDS: Record<LeadFeeMethod, { percentage: boolean; fixed: boolean; min: boolean; max: boolean }> = {
  fixed: { percentage: false, fixed: true, min: false, max: false },
  percentage: { percentage: true, fixed: false, min: false, max: false },
  higher_of: { percentage: true, fixed: false, min: true, max: false },
  percentage_min: { percentage: true, fixed: false, min: true, max: false },
  percentage_min_max: { percentage: true, fixed: false, min: true, max: true },
  none: { percentage: false, fixed: false, min: false, max: false },
};

const SAMPLE_AMOUNTS = [1000, 2000, 3000, 5000, 10000];

const OPTION_LABELS: { key: keyof LeadFeeOptions; label: string; hint: string }[] = [
  { key: 'enabled', label: 'Charge a vendor lead fee', hint: 'Off means no lead fee is calculated for new bookings.' },
  { key: 'offset_advance', label: 'Set the customer advance against the lead fee', hint: 'The advance the client paid is applied first; the vendor pays only the balance.' },
  { key: 'cap_at_amount', label: 'Never charge more than the expected booking amount', hint: 'Caps the fee at the booking amount on very small trips.' },
  { key: 'require_acceptance', label: 'Vendor must accept the commercial terms before taking leads', hint: 'Vendors are asked to accept once; changes ask again.' },
  { key: 'customer_advance_enabled', label: 'Collect a customer advance at booking', hint: 'A customer payment, kept separate from the vendor lead fee.' },
];

function emptyForm(): LeadFeeRuleInput {
  return { scope: 'global', vendor_ids: [], services: [], method: 'higher_of', percentage: '', fixed_amount: '', min_amount: '', max_amount: '', effective_from: '', effective_until: '', status: 'active', notes: '' };
}

// Server date 'YYYY-MM-DD HH:MM:SS' → value for a datetime-local input.
function toLocalInput(v: string | null | undefined): string {
  return v ? v.replace(' ', 'T').slice(0, 16) : '';
}

// TRACE: admin opens Vendor lead fee → GET /app/admin/lead-fee → renders (1) switches that save on change, (2) the rule form with method-specific fields and a live preview from the server's own engine (POST /preview, debounced),
//        (3) the list of rules with edit (saves a NEW version), deactivate and history, (4) vendor acceptance status with "record acceptance".
//        Preconditions: settings or financial capability to view, settings capability to change (server enforces both). Postconditions: every change is reloaded from the server so the screen shows stored values; historical bookings are never altered by rule changes (server snapshots).
//        Edge cases: load failure (retry), validation errors (server message shown, form kept), empty rule list (message), only global default cannot be deactivated (server message), rapid clicks (buttons disabled while busy), preview failure (message instead of numbers).
export function AdminLeadFeePage() {
  const [cfg, setCfg] = useState<LeadFeeConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState<LeadFeeRuleInput>(emptyForm());
  const [editing, setEditing] = useState<LeadFeeRule | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [previewAmount, setPreviewAmount] = useState('4000');
  const [preview, setPreview] = useState<LeadFeePreview | null>(null);
  const [previewErr, setPreviewErr] = useState<string | null>(null);
  const [samples, setSamples] = useState<Record<number, number | null>>({});
  const [history, setHistory] = useState<{ rule: LeadFeeRule; data: LeadFeeHistory } | null>(null);
  const [confirmOff, setConfirmOff] = useState<LeadFeeRule | null>(null);
  const [showAll, setShowAll] = useState(false);
  const [pending, setPending] = useState<PendingForfeitRow[] | null>(null);
  const [pendingErr, setPendingErr] = useState<string | null>(null);
  const seq = useRef(0);
  const lastFocus = useRef<HTMLElement | null>(null);
  const dialogRef = useRef<HTMLDivElement | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setCfg(await getLeadFeeConfig());
    } catch (e) {
      setError(e instanceof ApiError ? (e.code === 'forbidden' ? "You don't have permission to view lead-fee settings." : e.message) : 'Could not load lead-fee settings. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // TRACE: page mount → GET /app/admin/lead-fee/pending-forfeits → the list of cancelled, vendor-arranged bookings whose forfeit disposition is still undecided.
  //        Loaded independently of the main config call so a failure here (e.g. a capability edge case) never blocks the rest of the page. Edge cases: empty list (panel shows "none waiting" rather than being hidden, so an admin can confirm there is nothing pending).
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const r = await getPendingForfeits();
        if (!cancelled) setPending(r.rows);
      } catch (e) {
        if (!cancelled) setPendingErr(e instanceof ApiError ? e.message : 'Could not load pending forfeit decisions.');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const fields = METHOD_FIELDS[form.method];

  // TRACE: any form value or the amount changes → after 300 ms asks the server to calculate (a later request supersedes an earlier one via seq, so a slow answer never overwrites a newer one) → sets preview and the sample table, or an error message.
  //        Incomplete input (e.g. percentage blank for a percentage method) shows the server's validation-free result of that input; a non-numeric amount clears the preview.
  useEffect(() => {
    const amt = Number(previewAmount);
    if (previewAmount === '' || Number.isNaN(amt) || amt < 0) {
      setPreview(null);
      setPreviewErr('Enter an expected booking amount to preview.');
      return;
    }
    const mine = ++seq.current;
    const t = window.setTimeout(async () => {
      const base = { method: form.method, percentage: form.percentage || 0, fixed_amount: form.fixed_amount || 0, min_amount: form.min_amount || 0, max_amount: form.max_amount || 0 };
      try {
        const [main, ...rest] = await Promise.all([previewLeadFee({ amount: amt, ...base }), ...SAMPLE_AMOUNTS.map((a) => previewLeadFee({ amount: a, ...base }))]);
        if (mine !== seq.current) return;
        setPreview(main);
        setPreviewErr(null);
        setSamples(Object.fromEntries(SAMPLE_AMOUNTS.map((a, i) => [a, rest[i].fee])));
      } catch (e) {
        if (mine !== seq.current) return;
        setPreview(null);
        setPreviewErr(e instanceof ApiError ? e.message : 'Could not calculate the preview.');
      }
    }, 300);
    return () => window.clearTimeout(t);
  }, [previewAmount, form.method, form.percentage, form.fixed_amount, form.min_amount, form.max_amount]);

  // TRACE: switch toggled → shows the new position at once, POSTs only that key → success: local options replaced by the server's copy; failure: the switch goes back to its previous position and the message is shown.
  async function toggle(key: keyof LeadFeeOptions, value: boolean) {
    setBusy(true);
    setMsg(null);
    const previous = cfg?.options[key];
    setCfg((c) => (c ? { ...c, options: { ...c.options, [key]: value } } : c));
    try {
      const r = await saveLeadFeeOptions({ [key]: value });
      setCfg((c) => (c ? { ...c, options: r.options ?? { ...c.options, [key]: value } } : c));
      setMsg({ ok: true, text: 'Saved. New bookings use this setting; existing bookings keep their terms.' });
    } catch (e) {
      if (previous !== undefined) setCfg((c) => (c ? { ...c, options: { ...c.options, [key]: previous } } : c));
      setMsg({ ok: false, text: e instanceof ApiError ? e.message : 'Could not save. Please try again.' });
    } finally {
      setBusy(false);
    }
  }

  // TRACE: Save rule → POST terms (with id when editing = new version) → success: form reset, list reloaded, message from server; failure: server reason shown, form values kept.
  async function submit() {
    setBusy(true);
    setMsg(null);
    try {
      const body: LeadFeeRuleInput = { ...form, id: editing?.id, vendor_ids: form.scope === 'vendor' ? form.vendor_ids : [] };
      const r = await saveLeadFeeRule(body);
      setMsg({ ok: true, text: r.message ?? 'Rule saved.' });
      setForm(emptyForm());
      setEditing(null);
      await load();
    } catch (e) {
      setMsg({ ok: false, text: e instanceof ApiError ? e.message : 'Could not save the rule. Please try again.' });
    } finally {
      setBusy(false);
    }
  }

  // TRACE: Edit clicked on a rule → copies that rule into the form (saving creates version+1; the old version is closed and kept) → scrolls the form into view.
  function startEdit(r: LeadFeeRule) {
    setEditing(r);
    setForm({ id: r.id, scope: r.scope, vendor_ids: r.vendor_id ? [r.vendor_id] : [], services: r.services, method: r.method, percentage: r.percentage || '', fixed_amount: r.fixed_amount || '', min_amount: r.min_amount || '', max_amount: r.max_amount || '', effective_from: '', effective_until: toLocalInput(r.effective_until), status: r.status, notes: r.notes });
    document.getElementById('lf-form')?.scrollIntoView({ behavior: 'smooth' });
  }

  // TRACE: deactivate confirmed → POST deactivate → reload; the only global default is refused by the server with a message.
  async function deactivate(r: LeadFeeRule) {
    setBusy(true);
    setMsg(null);
    try {
      const res = await deactivateLeadFeeRule(r.id);
      setMsg({ ok: true, text: res.message ?? 'Rule deactivated.' });
      await load();
    } catch (e) {
      setMsg({ ok: false, text: e instanceof ApiError ? e.message : 'Could not deactivate the rule.' });
    } finally {
      setBusy(false);
      setConfirmOff(null);
    }
  }

  // TRACE: History clicked → GET history for the rule's root → shows every version and vendor acceptances.
  async function openHistory(r: LeadFeeRule) {
    setMsg(null);
    lastFocus.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    try {
      setHistory({ rule: r, data: await getLeadFeeHistory(r.id) });
    } catch (e) {
      setMsg({ ok: false, text: e instanceof ApiError ? e.message : 'Could not load the history.' });
    }
  }

  // TRACE: Record acceptance → POST accept for the vendor (source 'admin') → reload so the vendor row shows the new version and time.
  async function record(vendorId: number) {
    setBusy(true);
    setMsg(null);
    try {
      const r = await adminRecordAcceptance(vendorId);
      setMsg({ ok: true, text: r.message ?? 'Acceptance recorded.' });
      await load();
    } catch (e) {
      setMsg({ ok: false, text: e instanceof ApiError ? e.message : 'Could not record the acceptance.' });
    } finally {
      setBusy(false);
    }
  }

  // TRACE: history dialog closed (button, Escape) → hides it and returns focus to the button that opened it.
  function closeHistory() {
    setHistory(null);
    window.setTimeout(() => lastFocus.current?.focus(), 0);
  }

  // TRACE: key pressed inside the history dialog → Escape closes; Tab/Shift+Tab wrap between the first and last focusable element so focus stays inside.
  function trapKeys(e: React.KeyboardEvent<HTMLDivElement>) {
    if (e.key === 'Escape') {
      closeHistory();
      return;
    }
    if (e.key !== 'Tab' || !dialogRef.current) return;
    const items = Array.from(dialogRef.current.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], input, select, textarea, [tabindex]:not([tabindex="-1"])'));
    if (items.length === 0) return;
    const first = items[0];
    const last = items[items.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }

  const rules = useMemo(() => (cfg?.rules ?? []).filter((r) => showAll || r.is_latest), [cfg, showAll]);

  // TRACE: default-for-late-cancellation select changed → POST cancel_forfeit_default → cfg updated from the choice; failure restores the previous value and shows the message.
  async function setForfeitDefault(v: 'platform' | 'vendor' | 'admin') {
    const prev = cfg?.cancel_forfeit_default;
    setBusy(true);
    setMsg(null);
    setCfg((c) => (c ? { ...c, cancel_forfeit_default: v } : c));
    try {
      await saveLeadFeeOptions({ cancel_forfeit_default: v });
      setMsg({ ok: true, text: 'Saved. It applies to cancellations from now on; you can still decide each booking individually.' });
    } catch (e) {
      if (prev) setCfg((c) => (c ? { ...c, cancel_forfeit_default: prev } : c));
      setMsg({ ok: false, text: e instanceof ApiError ? e.message : 'Could not save. Please try again.' });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-10 lg:px-8">
      <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Vendor lead fee</h1>
      <p className="mt-1 text-sm text-ink-600">
        The lead fee is what a vendor pays {brand().name} for a booking arranged through the platform, under the commercial terms they accept. It is calculated from the expected booking amount and is separate from the customer advance.
        One rule set drives every screen, message, report and settlement; nothing is hard-coded.
      </p>

      {loading && (
        <div className="mt-6 space-y-3" aria-busy="true" aria-label="Loading lead-fee settings">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-16 w-full rounded-xl" />
          ))}
        </div>
      )}
      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {msg && (
        <div role={msg.ok ? 'status' : 'alert'} className={`mt-4 rounded-lg border px-3.5 py-2.5 text-sm ${msg.ok ? 'border-success-200 bg-success-50 text-success-800' : 'border-danger-500/30 bg-danger-50 text-danger-600'}`}>
          {msg.text}
        </div>
      )}

      {!loading && !error && cfg && (
        <div className="mt-6 space-y-6">
          {pendingErr && (
            <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3.5 py-2.5 text-sm text-danger-600">{pendingErr}</div>
          )}
          {pending !== null && (
            <section className="rounded-xl border border-ink-100 p-5 shadow-xs" aria-label="Pending forfeit decisions">
              <h2 className="text-sm font-semibold uppercase tracking-wide text-ink-500">Pending forfeit decisions</h2>
              <p className="mt-1 text-xs text-ink-500">
                A cancelled booking where a vendor was already arranged forfeits the client's advance. With "left for an admin to decide" above, nothing happens to that amount until someone chooses platform or vendor here.
              </p>
              {pending.length === 0 ? (
                <p className="mt-3 text-sm text-ink-600">No bookings are waiting on a forfeit decision.</p>
              ) : (
                <ul className="mt-3 divide-y divide-ink-100">
                  {pending.map((r) => (
                    <li key={r.booking_id} className="flex items-center justify-between gap-4 py-3">
                      <div>
                        <Link to={`/admin/bookings/${r.booking_id}`} className="text-sm font-medium text-brand-700 hover:underline">
                          #{r.booking_id} — {r.client_name}
                        </Link>
                        <p className="text-xs text-ink-500">
                          {r.pickup_city} → {r.drop_city} · vendor {r.vendor_name || `#${r.vendor_id}`} · {money(r.amount)} forfeited
                          {r.days_waiting > 0 ? ` · waiting ${r.days_waiting} day${r.days_waiting === 1 ? '' : 's'}` : ''}
                        </p>
                      </div>
                      <Link to={`/admin/bookings/${r.booking_id}`}>
                        <Button size="sm" variant="secondary">Decide</Button>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          )}

          <section className="rounded-xl border border-ink-100 p-5 shadow-xs" aria-label="Switches">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-ink-500">Switches</h2>
            <ul className="mt-3 divide-y divide-ink-100">
              {OPTION_LABELS.map((o) => (
                <li key={o.key} className="flex items-start justify-between gap-4 py-3">
                  <div>
                    <label htmlFor={`opt-${o.key}`} className="text-sm font-medium text-ink-900">{o.label}</label>
                    <p className="text-xs text-ink-500">{o.hint}</p>
                  </div>
                  <input id={`opt-${o.key}`} type="checkbox" className="mt-1 h-5 w-5 shrink-0 accent-brand-600" checked={cfg.options[o.key]} disabled={busy} onChange={(e) => void toggle(o.key, e.target.checked)} />
                </li>
              ))}
            </ul>
            <div className="mt-2 border-t border-ink-100 pt-3">
              <label htmlFor="opt-forfeit-default" className="text-sm font-medium text-ink-900">When a client cancels after a vendor is arranged, the forfeited advance goes to</label>
              <select id="opt-forfeit-default" className={inputCls} value={cfg.cancel_forfeit_default} disabled={busy} onChange={(e) => void setForfeitDefault(e.target.value as 'platform' | 'vendor' | 'admin')}>
                <option value="admin">Left for an admin to decide on each booking</option>
                <option value="platform">The platform, as the lead fee</option>
                <option value="vendor">The vendor, as compensation</option>
              </select>
              <p className="mt-1 text-xs text-ink-500">Whichever you choose, on each cancelled booking an admin can keep the amount with the platform or compensate the vendor, with a reason (until compensation has been paid). With \"left for an admin\" nothing is recorded until they do.</p>
            </div>
          </section>

          <section id="lf-form" className="rounded-xl border border-ink-100 p-5 shadow-xs" aria-label="Rule form">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-ink-500">
              {editing ? `Edit rule (saves version ${editing.version + 1})` : 'Add a rule'}
            </h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="lf-method" className="text-sm font-medium text-ink-800">Calculation method</label>
                <select id="lf-method" className={inputCls} value={form.method} onChange={(e) => setForm({ ...form, method: e.target.value as LeadFeeMethod })}>
                  {Object.entries(cfg.methods).map(([k, label]) => (
                    <option key={k} value={k}>{label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="lf-scope" className="text-sm font-medium text-ink-800">Applies to</label>
                <select id="lf-scope" className={inputCls} value={form.scope} disabled={!!editing} onChange={(e) => setForm({ ...form, scope: e.target.value as 'global' | 'vendor' })}>
                  <option value="global">All vendors (global rule)</option>
                  <option value="vendor">Selected vendors only</option>
                </select>
              </div>
              {fields.percentage && (
                <div>
                  <label htmlFor="lf-pct" className="text-sm font-medium text-ink-800">Percentage (%)</label>
                  <input id="lf-pct" type="number" min={0} max={100} step="0.01" className={inputCls} value={form.percentage} onChange={(e) => setForm({ ...form, percentage: e.target.value })} />
                </div>
              )}
              {fields.fixed && (
                <div>
                  <label htmlFor="lf-fixed" className="text-sm font-medium text-ink-800">Fixed amount (₹)</label>
                  <input id="lf-fixed" type="number" min={0} step="0.01" className={inputCls} value={form.fixed_amount} onChange={(e) => setForm({ ...form, fixed_amount: e.target.value })} />
                </div>
              )}
              {fields.min && (
                <div>
                  <label htmlFor="lf-min" className="text-sm font-medium text-ink-800">Minimum fee (₹)</label>
                  <input id="lf-min" type="number" min={0} step="0.01" className={inputCls} value={form.min_amount} onChange={(e) => setForm({ ...form, min_amount: e.target.value })} />
                </div>
              )}
              {fields.max && (
                <div>
                  <label htmlFor="lf-max" className="text-sm font-medium text-ink-800">Maximum fee (₹, blank = none)</label>
                  <input id="lf-max" type="number" min={0} step="0.01" className={inputCls} value={form.max_amount} onChange={(e) => setForm({ ...form, max_amount: e.target.value })} />
                </div>
              )}
              <div>
                <label htmlFor="lf-from" className="text-sm font-medium text-ink-800">Effective from (blank = now)</label>
                <input id="lf-from" type="datetime-local" className={inputCls} value={form.effective_from} onChange={(e) => setForm({ ...form, effective_from: e.target.value })} />
              </div>
              <div>
                <label htmlFor="lf-until" className="text-sm font-medium text-ink-800">Effective until (blank = no end)</label>
                <input id="lf-until" type="datetime-local" className={inputCls} value={form.effective_until} onChange={(e) => setForm({ ...form, effective_until: e.target.value })} />
              </div>
              <div>
                <label htmlFor="lf-status" className="text-sm font-medium text-ink-800">Status</label>
                <select id="lf-status" className={inputCls} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as 'active' | 'inactive' })}>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
              <div>
                <label htmlFor="lf-notes" className="text-sm font-medium text-ink-800">Notes</label>
                <input id="lf-notes" type="text" className={inputCls} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
              </div>
            </div>

            <fieldset className="mt-4">
              <legend className="text-sm font-medium text-ink-800">Services (none ticked = all services)</legend>
              <div className="mt-2 flex flex-wrap gap-x-4 gap-y-2">
                {Object.entries(cfg.services).map(([k, label]) => (
                  <label key={k} className="flex items-center gap-2 text-sm text-ink-700">
                    <input type="checkbox" className="h-4 w-4 accent-brand-600" checked={form.services.includes(k)} onChange={(e) => setForm({ ...form, services: e.target.checked ? [...form.services, k] : form.services.filter((s) => s !== k) })} />
                    {label}
                  </label>
                ))}
              </div>
            </fieldset>

            {form.scope === 'vendor' && (
              <fieldset className="mt-4">
                <legend className="text-sm font-medium text-ink-800">{editing ? 'Vendor' : 'Vendors (tick one or more)'}</legend>
                <div className="mt-2 grid max-h-48 gap-2 overflow-y-auto sm:grid-cols-2">
                  {cfg.vendors.map((v) => (
                    <label key={v.id} className="flex items-center gap-2 text-sm text-ink-700">
                      <input
                        type="checkbox"
                        className="h-4 w-4 accent-brand-600"
                        disabled={!!editing}
                        checked={(form.vendor_ids ?? []).includes(v.id)}
                        onChange={(e) => setForm({ ...form, vendor_ids: e.target.checked ? [...(form.vendor_ids ?? []), v.id] : (form.vendor_ids ?? []).filter((x) => x !== v.id) })}
                      />
                      {v.name}
                    </label>
                  ))}
                  {cfg.vendors.length === 0 && <p className="text-sm text-ink-500">No vendors yet.</p>}
                </div>
              </fieldset>
            )}

            <div className="mt-5 rounded-lg bg-ink-50 p-4" aria-live="polite">
              <div className="flex flex-wrap items-end gap-3">
                <div>
                  <label htmlFor="lf-prev" className="text-sm font-medium text-ink-800">Preview: expected booking amount (₹)</label>
                  <input id="lf-prev" type="number" min={0} className={`${inputCls} w-44`} value={previewAmount} onChange={(e) => setPreviewAmount(e.target.value)} />
                </div>
                <p className="pb-2 text-lg font-bold text-ink-900" data-testid="lf-preview-fee">
                  {preview ? `Lead fee ${money(preview.fee)}` : '—'}
                </p>
              </div>
              {preview && <p className="mt-1 text-sm text-ink-600">{preview.formula}</p>}
              {previewErr && <p className="mt-1 text-sm text-danger-600">{previewErr}</p>}
              <div className="mt-3 overflow-x-auto">
                <table className="w-full min-w-[20rem] text-sm">
                  <caption className="sr-only">Lead fee for sample booking amounts</caption>
                  <thead>
                    <tr className="text-left text-ink-500">
                      <th className="py-1 pr-4 font-medium">Expected booking amount</th>
                      <th className="py-1 font-medium">Lead fee</th>
                    </tr>
                  </thead>
                  <tbody>
                    {SAMPLE_AMOUNTS.map((a) => (
                      <tr key={a} className="border-t border-ink-100">
                        <td className="py-1 pr-4">{money(a)}</td>
                        <td className="py-1 font-semibold">{samples[a] == null ? '—' : money(samples[a] as number)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mt-5 flex flex-wrap gap-2">
              <Button onClick={() => void submit()} loading={busy} disabled={busy}>
                {editing ? 'Save as new version' : 'Save rule'}
              </Button>
              {editing && (
                <Button variant="secondary" disabled={busy} onClick={() => { setEditing(null); setForm(emptyForm()); }}>
                  Cancel editing
                </Button>
              )}
            </div>
          </section>

          <section className="rounded-xl border border-ink-100 p-5 shadow-xs" aria-label="Rules">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-sm font-semibold uppercase tracking-wide text-ink-500">Rules</h2>
              <label className="flex items-center gap-2 text-sm text-ink-700">
                <input type="checkbox" className="h-4 w-4 accent-brand-600" checked={showAll} onChange={(e) => setShowAll(e.target.checked)} />
                Show earlier versions
              </label>
            </div>
            {rules.length === 0 && <p className="mt-3 text-sm text-ink-500">No rules yet. The built-in default (higher of the minimum or the percentage) is used until you add one.</p>}
            <ul className="mt-3 space-y-3">
              {rules.map((r) => (
                <li key={r.id} className="rounded-lg border border-ink-100 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-sm font-semibold text-ink-900">
                      {r.scope === 'global' ? 'All vendors' : r.vendor_name || `Vendor #${r.vendor_id}`}
                      <span className="ml-2 text-xs font-normal text-ink-500">v{r.version}</span>
                    </p>
                    <span className="rounded-full bg-ink-100 px-2.5 py-0.5 text-xs font-semibold text-ink-700">{r.state}</span>
                  </div>
                  <p className="mt-1 text-sm text-ink-700">{r.description}</p>
                  <p className="mt-1 text-xs text-ink-500">
                    Services: {r.services.length ? r.services.map((s) => cfg.services[s] ?? s).join(', ') : 'all'} · From {r.effective_from}
                    {r.effective_until ? ` until ${r.effective_until}` : ''}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {r.is_latest && (
                      <Button size="sm" variant="secondary" disabled={busy} onClick={() => startEdit(r)} aria-label={`Edit rule ${r.id} for ${r.scope === 'global' ? 'all vendors' : r.vendor_name}`}>Edit</Button>
                    )}
                    {r.is_latest && r.status === 'active' && (
                      <Button size="sm" variant="ghost" disabled={busy} onClick={() => setConfirmOff(r)} aria-label={`Deactivate rule ${r.id}`}>Deactivate</Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => void openHistory(r)} aria-label={`Version history of rule ${r.id}`}>History</Button>
                  </div>
                </li>
              ))}
            </ul>
          </section>

          <section className="rounded-xl border border-ink-100 p-5 shadow-xs" aria-label="Vendor acceptance">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-ink-500">Vendor acceptance of commercial terms</h2>
            <ul className="mt-3 divide-y divide-ink-100">
              {cfg.vendors.map((v) => (
                <li key={v.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5 text-sm">
                  <span className="font-medium text-ink-900">{v.name}</span>
                  <span className="text-ink-600">{v.accepted ? `Accepted v${v.terms_version} on ${v.accepted_at}` : 'Not accepted yet'}</span>
                  {!v.accepted && (
                    <Button size="sm" variant="secondary" disabled={busy} onClick={() => void record(v.id)} aria-label={`Record acceptance for ${v.name}`}>
                      Record acceptance
                    </Button>
                  )}
                </li>
              ))}
              {cfg.vendors.length === 0 && <li className="py-2 text-sm text-ink-500">No vendors yet.</li>}
            </ul>
          </section>
        </div>
      )}

      {history && (
        <div role="dialog" aria-modal="true" aria-label="Rule history" className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-0 sm:items-center sm:p-4" onKeyDown={trapKeys}>
          <div ref={dialogRef} className="max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-t-2xl bg-white p-5 shadow-xl sm:rounded-2xl">
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-lg font-bold text-ink-900">Version history</h2>
              <Button size="sm" variant="secondary" autoFocus onClick={closeHistory}>Close</Button>
            </div>
            <ul className="mt-3 space-y-2">
              {history.data.versions.map((v) => (
                <li key={v.id} className="rounded-lg border border-ink-100 p-3 text-sm">
                  <p className="font-semibold text-ink-900">Version {v.version} <span className="font-normal text-ink-500">({v.state})</span></p>
                  <p className="text-ink-700">{v.description}</p>
                  <p className="text-xs text-ink-500">From {v.effective_from}{v.effective_until ? ` until ${v.effective_until}` : ''}</p>
                </li>
              ))}
            </ul>
            <h3 className="mt-4 text-sm font-semibold text-ink-900">Acceptances</h3>
            {history.data.acceptances.length === 0 && <p className="mt-1 text-sm text-ink-500">Nobody has accepted this rule yet.</p>}
            <ul className="mt-1 space-y-1 text-sm text-ink-700">
              {history.data.acceptances.map((a) => (
                <li key={a.id}>{a.vendor_name || `Vendor #${a.vendor_id}`}: v{a.terms_version} on {a.accepted_at} ({a.source})</li>
              ))}
            </ul>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={!!confirmOff}
        title="Deactivate this rule?"
        description={confirmOff ? `Deactivate the rule for ${confirmOff.scope === 'global' ? 'all vendors' : confirmOff.vendor_name}? New bookings will use the next matching rule. Existing bookings keep their terms.` : ''}
        confirmLabel="Deactivate"
        confirmVariant="danger"
        loading={busy}
        onConfirm={() => confirmOff && void deactivate(confirmOff)}
        onCancel={() => setConfirmOff(null)}
      />
    </div>
  );
}
