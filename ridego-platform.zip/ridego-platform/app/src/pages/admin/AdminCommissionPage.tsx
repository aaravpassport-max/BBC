import { useCallback, useEffect, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { ApiError, getAdminVendors } from '../../lib/api';
import {
  assignCommissionModel,
  createCommissionModel,
  getCommissionModels,
  updateCommissionModel,
  type CommissionModel,
  type CommissionModelInput,
  type CommissionModelsResponse,
  type CommissionRefundMode,
  type CommissionType,
} from '../../lib/api-admin-finance';
import type { AdminVendorRow } from '../../types/api';
import { useToast } from '../../context/ToastContext';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';

const inputCls =
  'mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500/40';

interface ModelForm {
  name: string;
  type: CommissionType;
  fixed_amount: string;
  percentage: string;
  min_amount: string;
  monthly_fee: string;
  refund_adjustment: CommissionRefundMode;
  is_default: boolean;
  is_active: boolean;
}

const EMPTY_FORM: ModelForm = {
  name: '',
  type: 'fixed',
  fixed_amount: '',
  percentage: '',
  min_amount: '',
  monthly_fee: '',
  refund_adjustment: 'none',
  is_default: false,
  is_active: true,
};

const TYPE_FALLBACK: Record<CommissionType, string> = {
  fixed: 'Fixed amount per successful booking',
  percentage: 'Percentage of fare (with minimum)',
  hybrid: 'Fixed amount plus percentage',
  monthly: 'Monthly subscription fee (no per-booking charge)',
};

// TRACE: any numeric display → formats rupees with Indian grouping → "₹1,234.5".
//        Preconditions: value is a number or numeric string → postconditions: pure →
//        edge cases: null/undefined/NaN render as ₹0.
function money(v: number | string | null | undefined): string {
  const n = Number(v);
  return `₹${(Number.isFinite(n) ? n : 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

// TRACE: API flag value (0/1/'1'/true) → boolean → true when the flag is set.
//        Preconditions: none → postconditions: pure → edge cases: '0' string is false.
function flag(v: number | string | boolean | null | undefined): boolean {
  return v === true || v === 1 || v === '1';
}

// TRACE: form text → number → parsed value, 0 for blank.
//        Preconditions: none → postconditions: pure → edge cases: blank or non-numeric text gives NaN-safe 0.
function num(s: string): number {
  const n = parseFloat(s);
  return Number.isFinite(n) ? n : 0;
}

// TRACE: form state → client-side check mirroring ridego_validate_commission_model_input → error message or null.
//        Preconditions: none → postconditions: pure → edge cases: blank name, negative amounts, percentage over 100,
//        type-specific amount at or below zero, default model that is inactive (would never be used).
function validateForm(f: ModelForm): string | null {
  if (f.name.trim() === '') return 'Model name is required.';
  const fixed = num(f.fixed_amount);
  const pct = num(f.percentage);
  const min = num(f.min_amount);
  const month = num(f.monthly_fee);
  if (fixed < 0 || pct < 0 || min < 0 || month < 0) return 'Amounts cannot be negative.';
  if (pct > 100) return 'Percentage cannot exceed 100.';
  if ((f.type === 'fixed' || f.type === 'hybrid') && fixed <= 0) return 'Fixed amount must be greater than zero.';
  if ((f.type === 'percentage' || f.type === 'hybrid') && pct <= 0) return 'Percentage must be greater than zero.';
  if (f.type === 'monthly' && month <= 0) return 'Monthly fee must be greater than zero.';
  if (f.is_default && !f.is_active) return 'A default model must be active, otherwise it is never applied.';
  return null;
}

// TRACE: validated form → API payload → input with only the fields relevant to the type (others zeroed so stale values never persist).
//        Preconditions: validateForm returned null → postconditions: pure → edge cases: hidden fields sent as 0.
function toInput(f: ModelForm): CommissionModelInput {
  const usesFixed = f.type === 'fixed' || f.type === 'hybrid';
  const usesPct = f.type === 'percentage' || f.type === 'hybrid';
  return {
    name: f.name.trim(),
    type: f.type,
    fixed_amount: usesFixed ? num(f.fixed_amount) : 0,
    percentage: usesPct ? num(f.percentage) : 0,
    min_amount: usesPct ? num(f.min_amount) : 0,
    monthly_fee: f.type === 'monthly' ? num(f.monthly_fee) : 0,
    refund_adjustment: f.refund_adjustment,
    is_default: f.is_default,
    is_active: f.is_active,
  };
}

// TRACE: stored model → editable form strings → ModelForm. Preconditions: model row from the API →
//        postconditions: pure → edge cases: numeric strings from MySQL, zero amounts shown blank.
function toForm(m: CommissionModel): ModelForm {
  const s = (v: number | string): string => (Number(v) ? String(Number(v)) : '');
  return {
    name: m.name,
    type: m.type,
    fixed_amount: s(m.fixed_amount),
    percentage: s(m.percentage),
    min_amount: s(m.min_amount),
    monthly_fee: s(m.monthly_fee),
    refund_adjustment: m.refund_adjustment === 'reverse' ? 'reverse' : 'none',
    is_default: flag(m.is_default),
    is_active: flag(m.is_active),
  };
}

// TRACE: stored model → one-line human summary of what it charges.
//        Preconditions: model row → postconditions: pure → edge cases: unknown type falls back to its raw key.
function amountSummary(m: CommissionModel): string {
  switch (m.type) {
    case 'fixed':
      return `${money(m.fixed_amount)} per completed booking`;
    case 'percentage':
      return `${Number(m.percentage)}% of fare, minimum ${money(m.min_amount)}`;
    case 'hybrid':
      return `${money(m.fixed_amount)} + ${Number(m.percentage)}% of fare (minimum ${money(m.min_amount)} on the percentage part)`;
    case 'monthly':
      return `${money(m.monthly_fee)} per month, no per-booking charge`;
    default:
      return String(m.type);
  }
}

// TRACE: route /app/admin/commission → loads commission models, lets an admin create/edit them in a BottomSheet and
//        assign one to a vendor → renders the list, form and assign panel.
//        Preconditions: cap ridego_manage_commission_models → postconditions: every mutation re-fetches the list and toasts the result →
//        edge cases: loading skeleton, error banner with retry, empty list, stale responses ignored, double submit blocked,
//        form input kept on failure and reset on success, vendor search failure shown with retry.
export function AdminCommissionPage() {
  const toast = useToast();
  const [data, setData] = useState<CommissionModelsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const loadSeq = useRef(0);

  const [sheetOpen, setSheetOpen] = useState(false);
  const [editing, setEditing] = useState<CommissionModel | null>(null);
  const [form, setForm] = useState<ModelForm>(EMPTY_FORM);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [vendorQuery, setVendorQuery] = useState('');
  const [vendors, setVendors] = useState<AdminVendorRow[] | null>(null);
  const [vendorsLoading, setVendorsLoading] = useState(false);
  const [vendorsError, setVendorsError] = useState<string | null>(null);
  const [vendorId, setVendorId] = useState('');
  const [modelId, setModelId] = useState('');
  const [assigning, setAssigning] = useState(false);
  const [assignError, setAssignError] = useState<string | null>(null);
  const vendorSeq = useRef(0);

  // TRACE: mount / retry / after mutation → GET commission models → stores list or error.
  //        Preconditions: none → postconditions: only the latest request may write state →
  //        edge cases: stale response dropped, ApiError message shown, loading cleared in finally.
  const load = useCallback(async () => {
    const seq = ++loadSeq.current;
    setLoading(true);
    setError(null);
    try {
      const res = await getCommissionModels();
      if (seq !== loadSeq.current) return;
      setData(res);
    } catch (err) {
      if (seq !== loadSeq.current) return;
      setError(err instanceof ApiError ? err.message : 'Could not load commission models. Please try again.');
    } finally {
      if (seq === loadSeq.current) setLoading(false);
    }
  }, []);

  // TRACE: vendor search submit / initial mount → GET admin vendors filtered by the search text → stores the picker list.
  //        Preconditions: none → postconditions: latest request wins → edge cases: no matches (empty list), failure keeps retry.
  const searchVendors = useCallback(async (query: string) => {
    const seq = ++vendorSeq.current;
    setVendorsLoading(true);
    setVendorsError(null);
    try {
      const res = await getAdminVendors({ search: query.trim() || undefined });
      if (seq !== vendorSeq.current) return;
      setVendors(res.rows);
    } catch (err) {
      if (seq !== vendorSeq.current) return;
      setVendorsError(err instanceof ApiError ? err.message : 'Could not load vendors. Please try again.');
    } finally {
      if (seq === vendorSeq.current) setVendorsLoading(false);
    }
  }, []);

  // TRACE: mount → loads models and the first page of vendors; unmount → invalidates in-flight requests.
  //        Preconditions: none → postconditions: no state writes after unmount → edge cases: none.
  useEffect(() => {
    void load();
    void searchVendors('');
    return () => {
      loadSeq.current += 1;
      vendorSeq.current += 1;
    };
  }, [load, searchVendors]);

  // TRACE: "New model" click → resets the form and opens the sheet in create mode.
  //        Preconditions: none → postconditions: editing null, form blank → edge cases: previous error cleared.
  function openCreate() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setFormError(null);
    setSheetOpen(true);
  }

  // TRACE: "Edit" click → loads the model into the form and opens the sheet in edit mode.
  //        Preconditions: model row → postconditions: form mirrors the row → edge cases: previous error cleared.
  function openEdit(m: CommissionModel) {
    setEditing(m);
    setForm(toForm(m));
    setFormError(null);
    setSheetOpen(true);
  }

  // TRACE: sheet close (backdrop, Escape, close button) → hides the sheet unless a save is in flight.
  //        Preconditions: none → postconditions: form kept until the next open → edge cases: ignored while saving.
  const closeSheet = useCallback(() => {
    if (!saving) setSheetOpen(false);
  }, [saving]);

  // TRACE: any text/select input change in the model form → updates the matching field by its name.
  //        Preconditions: input has a name that is a ModelForm key → postconditions: other fields untouched →
  //        edge cases: checkbox uses checked, everything else uses value.
  function handleField(e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) {
    const { name, value, type } = e.target;
    const next = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setForm((prev) => ({ ...prev, [name]: next }));
  }

  // TRACE: model form submit → validate → POST (create) or PUT (edit) → toast, close sheet, re-fetch list.
  //        Preconditions: not already saving → postconditions: on success form reset and list refreshed →
  //        edge cases: client validation error shown inline, server ApiError shown inline and toasted with input kept.
  async function submitModel(e: FormEvent) {
    e.preventDefault();
    if (saving) return;
    const problem = validateForm(form);
    if (problem) {
      setFormError(problem);
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      const payload = toInput(form);
      if (editing) {
        await updateCommissionModel(Number(editing.id), payload);
      } else {
        await createCommissionModel(payload);
      }
      toast.show(editing ? `Updated "${payload.name}".` : `Created "${payload.name}".`, 'success');
      setSheetOpen(false);
      setForm(EMPTY_FORM);
      setEditing(null);
      await load();
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Could not save the commission model.';
      setFormError(msg);
      toast.show(msg, 'error');
    } finally {
      setSaving(false);
    }
  }

  // TRACE: vendor search form submit → runs the vendor search with the typed text.
  //        Preconditions: none → postconditions: picker list replaced → edge cases: selection cleared when the chosen vendor drops out.
  function handleVendorSearch(e: FormEvent) {
    e.preventDefault();
    setVendorId('');
    void searchVendors(vendorQuery);
  }

  // TRACE: assign form submit → POST commission assign → toast, reset selection, re-fetch models.
  //        Preconditions: vendor and model chosen → postconditions: future completions of that vendor use the model →
  //        edge cases: missing selection blocked, inactive model rejected by the API and shown, double submit blocked.
  async function submitAssign(e: FormEvent) {
    e.preventDefault();
    if (assigning) return;
    if (!vendorId || !modelId) {
      setAssignError('Choose both a vendor and a commission model.');
      return;
    }
    const vendor = vendors?.find((v) => String(v.id) === vendorId);
    const model = data?.rows.find((m) => String(m.id) === modelId);
    setAssigning(true);
    setAssignError(null);
    try {
      await assignCommissionModel(Number(vendorId), Number(modelId));
      toast.show(`Assigned "${model?.name ?? 'model'}" to ${vendor?.business_name ?? 'vendor'}.`, 'success');
      setVendorId('');
      setModelId('');
      await load();
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Could not assign the commission model.';
      setAssignError(msg);
      toast.show(msg, 'error');
    } finally {
      setAssigning(false);
    }
  }

  const rows = data?.rows ?? [];
  const activeModels = rows.filter((m) => flag(m.is_active));
  const hasActiveDefault = rows.some((m) => flag(m.is_default) && flag(m.is_active));
  const usesFixed = form.type === 'fixed' || form.type === 'hybrid';
  const usesPct = form.type === 'percentage' || form.type === 'hybrid';

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Commission models</h1>
          <p className="text-sm text-ink-500">What the platform charges vendors when a booking completes.</p>
        </div>
        <Button onClick={openCreate} disabled={loading && !data}>
          New model
        </Button>
      </div>

      <div
        role="note"
        className={`mt-5 rounded-lg border px-4 py-3 text-sm ${
          hasActiveDefault ? 'border-brand-200 bg-brand-50 text-brand-800' : 'border-amber-300 bg-amber-50 text-amber-900'
        }`}
      >
        <p className="font-semibold">{hasActiveDefault ? 'A default model is active.' : 'No commission is charged yet.'}</p>
        <p className="mt-1">
          No model is active by default, so commission is ₹0 until a model is marked <strong>default</strong> or{' '}
          <strong>assigned to a vendor</strong>. Bookings that are already completed keep the commission they were charged.
        </p>
      </div>

      {loading && !data && (
        <div className="mt-6 space-y-3" aria-busy="true" aria-label="Loading commission models">
          <Skeleton className="h-24 w-full rounded-xl" />
          <Skeleton className="h-24 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {data && (
        <section className="mt-6" aria-labelledby="models-heading">
          <h2 id="models-heading" className="text-base font-semibold text-ink-900">
            Models
          </h2>
          {rows.length === 0 ? (
            <div className="mt-3">
              <EmptyState
                title="No commission models yet"
                description="Create a model, then mark it default or assign it to a vendor. Until then commission is ₹0."
                action={<Button onClick={openCreate}>Create the first model</Button>}
              />
            </div>
          ) : (
            <ul className="mt-3 grid gap-3 md:grid-cols-2">
              {rows.map((m) => (
                <li key={String(m.id)} className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="break-words font-semibold text-ink-900">{m.name}</p>
                      <p className="text-xs text-ink-500">{data.types[m.type] ?? TYPE_FALLBACK[m.type] ?? m.type}</p>
                    </div>
                    <Button variant="secondary" size="sm" onClick={() => openEdit(m)} aria-label={`Edit model ${m.name}`}>
                      Edit
                    </Button>
                  </div>
                  <p className="mt-2 text-sm text-ink-700">{amountSummary(m)}</p>
                  <p className="mt-1 text-xs text-ink-500">
                    Refund adjustment: {m.refund_adjustment === 'reverse' ? 'reverse commission when a refund is processed' : 'none'}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2 text-xs font-medium">
                    {flag(m.is_default) && (
                      <span className="rounded-full bg-brand-100 px-2.5 py-0.5 text-brand-800">Default</span>
                    )}
                    <span
                      className={`rounded-full px-2.5 py-0.5 ${
                        flag(m.is_active) ? 'bg-success-50 text-success-800' : 'bg-ink-100 text-ink-700'
                      }`}
                    >
                      {flag(m.is_active) ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}

      {data && (
        <section className="mt-8 rounded-xl border border-ink-100 p-5 shadow-xs" aria-labelledby="assign-heading">
          <h2 id="assign-heading" className="text-base font-semibold text-ink-900">
            Assign to vendor
          </h2>
          <p className="mt-1 text-sm text-ink-500">
            An assigned model overrides the default for that vendor from now on. Past bookings are not recalculated.
          </p>

          <form onSubmit={handleVendorSearch} className="mt-4 flex flex-wrap items-end gap-2">
            <div className="min-w-0 flex-1 basis-56">
              <label htmlFor="vendor-search" className="block text-sm font-medium text-ink-700">
                Find vendor
              </label>
              <input
                id="vendor-search"
                type="search"
                value={vendorQuery}
                onChange={(e) => setVendorQuery(e.target.value)}
                placeholder="Business name, owner or phone"
                className={inputCls}
              />
            </div>
            <Button type="submit" variant="secondary" loading={vendorsLoading}>
              Search
            </Button>
          </form>

          {vendorsError && (
            <div className="mt-3">
              <ErrorBanner message={vendorsError} onRetry={() => void searchVendors(vendorQuery)} />
            </div>
          )}

          <form onSubmit={submitAssign} className="mt-4 grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="assign-vendor" className="block text-sm font-medium text-ink-700">
                Vendor
              </label>
              <select
                id="assign-vendor"
                value={vendorId}
                onChange={(e) => setVendorId(e.target.value)}
                disabled={vendorsLoading || !vendors?.length}
                className={inputCls}
              >
                <option value="">
                  {vendorsLoading ? 'Loading vendors…' : vendors?.length ? 'Select a vendor' : 'No vendors found'}
                </option>
                {(vendors ?? []).map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.business_name} ({v.city || 'no city'})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="assign-model" className="block text-sm font-medium text-ink-700">
                Commission model
              </label>
              <select
                id="assign-model"
                value={modelId}
                onChange={(e) => setModelId(e.target.value)}
                disabled={activeModels.length === 0}
                className={inputCls}
              >
                <option value="">{activeModels.length ? 'Select an active model' : 'No active models'}</option>
                {activeModels.map((m) => (
                  <option key={String(m.id)} value={String(m.id)}>
                    {m.name}
                  </option>
                ))}
              </select>
            </div>
            {assignError && (
              <p role="alert" className="text-sm text-danger-600 sm:col-span-2">
                {assignError}
              </p>
            )}
            <div className="sm:col-span-2">
              <Button type="submit" loading={assigning} disabled={!vendorId || !modelId}>
                Assign model
              </Button>
            </div>
          </form>
        </section>
      )}

      <BottomSheet open={sheetOpen} onClose={closeSheet} title={editing ? `Edit ${editing.name}` : 'New commission model'}>
        <form onSubmit={submitModel} className="space-y-4" noValidate>
          <div>
            <label htmlFor="cm-name" className="block text-sm font-medium text-ink-700">
              Model name
            </label>
            <input id="cm-name" name="name" type="text" value={form.name} onChange={handleField} className={inputCls} required />
          </div>
          <div>
            <label htmlFor="cm-type" className="block text-sm font-medium text-ink-700">
              Type
            </label>
            <select id="cm-type" name="type" value={form.type} onChange={handleField} className={inputCls}>
              {(Object.keys(TYPE_FALLBACK) as CommissionType[]).map((t) => (
                <option key={t} value={t}>
                  {data?.types[t] ?? TYPE_FALLBACK[t]}
                </option>
              ))}
            </select>
          </div>
          {usesFixed && (
            <div>
              <label htmlFor="cm-fixed" className="block text-sm font-medium text-ink-700">
                Fixed amount (₹)
              </label>
              <input id="cm-fixed" name="fixed_amount" type="number" min="0" step="0.01" inputMode="decimal" value={form.fixed_amount} onChange={handleField} className={inputCls} />
            </div>
          )}
          {usesPct && (
            <>
              <div>
                <label htmlFor="cm-pct" className="block text-sm font-medium text-ink-700">
                  Percentage of fare (%)
                </label>
                <input id="cm-pct" name="percentage" type="number" min="0" max="100" step="0.01" inputMode="decimal" value={form.percentage} onChange={handleField} className={inputCls} />
              </div>
              <div>
                <label htmlFor="cm-min" className="block text-sm font-medium text-ink-700">
                  Minimum amount (₹)
                </label>
                <input id="cm-min" name="min_amount" type="number" min="0" step="0.01" inputMode="decimal" value={form.min_amount} onChange={handleField} className={inputCls} />
              </div>
            </>
          )}
          {form.type === 'monthly' && (
            <div>
              <label htmlFor="cm-month" className="block text-sm font-medium text-ink-700">
                Monthly fee (₹)
              </label>
              <input id="cm-month" name="monthly_fee" type="number" min="0" step="0.01" inputMode="decimal" value={form.monthly_fee} onChange={handleField} className={inputCls} />
            </div>
          )}
          <div>
            <label htmlFor="cm-refund" className="block text-sm font-medium text-ink-700">
              Refund adjustment
            </label>
            <select id="cm-refund" name="refund_adjustment" value={form.refund_adjustment} onChange={handleField} className={inputCls}>
              <option value="none">None: keep the commission after a refund</option>
              <option value="reverse">Reverse: credit the commission back when a refund is processed</option>
            </select>
          </div>
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input id="cm-default" name="is_default" type="checkbox" checked={form.is_default} onChange={handleField} className="h-4 w-4 rounded border-ink-300 text-brand-600 focus-visible:ring-2 focus-visible:ring-brand-500/40" />
            Default model (applies to vendors without an assigned model)
          </label>
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input id="cm-active" name="is_active" type="checkbox" checked={form.is_active} onChange={handleField} className="h-4 w-4 rounded border-ink-300 text-brand-600 focus-visible:ring-2 focus-visible:ring-brand-500/40" />
            Active
          </label>
          {formError && (
            <p role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
              {formError}
            </p>
          )}
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button type="button" variant="secondary" onClick={closeSheet} disabled={saving}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              {editing ? 'Save changes' : 'Create model'}
            </Button>
          </div>
        </form>
      </BottomSheet>
    </div>
  );
}
