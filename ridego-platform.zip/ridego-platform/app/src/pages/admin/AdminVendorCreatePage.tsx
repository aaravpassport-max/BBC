import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createAdminVendor, ApiError } from '../../lib/api';
import { Button } from '../../components/ui/Button';

const BUSINESS_TYPES = [
  { value: 'individual', label: 'Individual / Owner-Driver' },
  { value: 'fleet_owner', label: 'Fleet Owner (multiple vehicles)' },
  { value: 'agency', label: 'Travel Agency' },
  { value: 'rental', label: 'Car Rental Operator' },
];

export function AdminVendorCreatePage() {
  const navigate = useNavigate();
  const [businessName, setBusinessName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('');
  const [totalVehicles, setTotalVehicles] = useState('');
  const [yearsExperience, setYearsExperience] = useState('');
  const [businessType, setBusinessType] = useState('individual');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await createAdminVendor({
        business_name: businessName.trim(),
        owner_name: ownerName.trim(),
        phone: phone.trim(),
        email: email.trim(),
        city: city.trim(),
        business_type: businessType,
        total_vehicles: totalVehicles ? Number(totalVehicles) : undefined,
        years_experience: yearsExperience ? Number(yearsExperience) : undefined,
      });
      navigate(`/app/admin/vendors/${res.vendor_id}`);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not create vendor. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
      <Link to="/admin/vendors" className="text-sm font-medium text-brand-700 hover:text-brand-800">
        ← Back
      </Link>
      <h1 className="mt-1 text-2xl font-bold text-ink-900 sm:text-3xl">Add new vendor</h1>
      <p className="mt-1 text-sm text-ink-500">New vendor registration.</p>

      <form onSubmit={onSubmit} className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs sm:p-6">
        {error && (
          <div role="alert" className="mb-4 rounded-lg border border-danger-500/30 bg-danger-50 px-3.5 py-2.5 text-sm text-danger-600">
            {error}
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label htmlFor="business_name" className="block text-sm font-medium text-ink-700">
              Business / Trade Name <span className="text-danger-600">*</span>
            </label>
            <input
              id="business_name"
              required
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              placeholder="Ramesh Sharma Travels"
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div>
            <label htmlFor="owner_name" className="block text-sm font-medium text-ink-700">
              Owner Full Name <span className="text-danger-600">*</span>
            </label>
            <input
              id="owner_name"
              required
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              autoComplete="name"
              placeholder="As per Aadhaar"
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-ink-700">
              Mobile Number <span className="text-danger-600">*</span>
            </label>
            <input
              id="phone"
              type="tel"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              autoComplete="tel"
              placeholder="+91 98765 43210"
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-ink-700">
              Email Address <span className="text-danger-600">*</span>
            </label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              placeholder="vendor@example.com"
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div>
            <label htmlFor="city" className="block text-sm font-medium text-ink-700">
              Base City <span className="text-danger-600">*</span>
            </label>
            <input
              id="city"
              required
              value={city}
              onChange={(e) => setCity(e.target.value)}
              autoComplete="address-level2"
              placeholder="Delhi"
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="total_vehicles" className="block text-sm font-medium text-ink-700">
                Total Vehicles
              </label>
              <input
                id="total_vehicles"
                type="number"
                min={0}
                value={totalVehicles}
                onChange={(e) => setTotalVehicles(e.target.value)}
                placeholder="2"
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="years_experience" className="block text-sm font-medium text-ink-700">
                Years of Experience
              </label>
              <input
                id="years_experience"
                type="number"
                min={0}
                value={yearsExperience}
                onChange={(e) => setYearsExperience(e.target.value)}
                placeholder="5"
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <div>
            <label htmlFor="business_type" className="block text-sm font-medium text-ink-700">
              Business Type
            </label>
            <select
              id="business_type"
              value={businessType}
              onChange={(e) => setBusinessType(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            >
              {BUSINESS_TYPES.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </select>
            <p className="mt-1.5 text-xs text-ink-400">A welcome email with login credentials will be sent to the email address provided.</p>
          </div>
        </div>

        {/* Desktop: always-visible submit at the bottom of the form.
            Mobile: the submit lives in the sticky footer below instead,
            matching BookingPage's mobile-forms convention, so the primary
            action stays within thumb reach on this 8-field form. */}
        <div className="mt-6 hidden lg:block">
          <Button type="submit" loading={submitting} disabled={!businessName || !ownerName || !phone || !email || !city}>
            Create Vendor Account
          </Button>
        </div>

        <div className="mt-6 lg:hidden" aria-hidden="true" style={{ height: '4.5rem' }} />

        <div
          className="fixed inset-x-0 bottom-16 z-30 border-t border-ink-100 bg-white/95 px-4 py-3 backdrop-blur lg:hidden"
          style={{ paddingBottom: 'max(0.75rem, env(safe-area-inset-bottom, 0px))' }}
        >
          <div className="mx-auto max-w-2xl">
            <Button
              type="submit"
              fullWidth
              loading={submitting}
              disabled={!businessName || !ownerName || !phone || !email || !city}
            >
              Create Vendor Account
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
