import { useCallback, useEffect, useState } from 'react';
import {
  getAdminNotificationStats,
  getAdminNotificationQueue,
  getAdminNotificationDeadLetter,
  sendAdminNotificationBroadcast,
  retryAdminNotification,
  discardAdminNotification,
  ApiError,
} from '../../lib/api';
import type { AdminNotificationQueueRow, AdminNotificationChannelStat } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';

const STATUS_OPTIONS = [
  ['', 'All Statuses'],
  ['pending', 'Pending'],
  ['sent', 'Sent'],
  ['dead_letter', 'Dead Letter'],
  ['discarded', 'Discarded'],
];

const CHANNEL_OPTIONS = [
  ['', 'All Channels'],
  ['whatsapp', 'Whatsapp'],
  ['email', 'Email'],
  ['sms', 'Sms'],
  ['telegram', 'Telegram'],
];

function statusBadgeClass(status: string) {
  switch (status) {
    case 'sent':
      return 'bg-success-50 text-success-700';
    case 'pending':
      return 'bg-amber-50 text-amber-700';
    case 'dead_letter':
      return 'bg-danger-50 text-danger-700';
    case 'discarded':
      return 'bg-ink-100 text-ink-600';
    default:
      return 'bg-ink-100 text-ink-600';
  }
}

function fmtDate(s: string | null) {
  if (!s) return '—';
  const d = new Date(s.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

/**
 * Rebuild of admin/pages/notifications.php: the Notifications Center —
 * KPI tiles, per-channel delivery success-rate breakdown, the broadcast
 * send form, and the Recent Queue / Dead Letter views with retry/discard
 * actions. This is a SEPARATE, admin-only broadcast/queue-monitoring
 * tool — not to be confused with the customer/vendor-facing read/unread
 * notification inbox at app/src/pages/NotificationsPage.tsx.
 */
export function AdminNotificationsPage() {
  const [kpis, setKpis] = useState<{ sent: number; pending: number; retrying: number; dead_letter: number } | null>(null);
  const [channels, setChannels] = useState<AdminNotificationChannelStat[]>([]);
  const [loadingStats, setLoadingStats] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [banner, setBanner] = useState<string | null>(null);

  // Broadcast form
  const [target, setTarget] = useState('all_vendors');
  const [bookingId, setBookingId] = useState('');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);

  // Queue / Dead Letter tabs
  const [tab, setTab] = useState<'queue' | 'dead_letter'>('queue');
  const [statusFilter, setStatusFilter] = useState('');
  const [channelFilter, setChannelFilter] = useState('');
  const [eventFilter, setEventFilter] = useState('');
  const [page, setPage] = useState(1);

  const [queueRows, setQueueRows] = useState<AdminNotificationQueueRow[] | null>(null);
  const [queueTotal, setQueueTotal] = useState(0);
  const [queuePerPage, setQueuePerPage] = useState(40);
  const [queueLoading, setQueueLoading] = useState(true);

  const [dlqRows, setDlqRows] = useState<AdminNotificationQueueRow[] | null>(null);
  const [dlqLoading, setDlqLoading] = useState(true);
  const [dlqActingId, setDlqActingId] = useState<number | null>(null);

  const loadStats = useCallback(async () => {
    setLoadingStats(true);
    setError(null);
    try {
      const res = await getAdminNotificationStats();
      setKpis(res.kpis);
      setChannels(res.channels);
    } catch (err) {
      setError(
        err instanceof ApiError && err.code === 'forbidden'
          ? "You don't have permission to view the notifications center."
          : err instanceof ApiError
          ? err.message
          : 'Could not load notification stats. Please try again.'
      );
    } finally {
      setLoadingStats(false);
    }
  }, []);

  const loadQueue = useCallback(async (s: string, c: string, e: string, pg: number) => {
    setQueueLoading(true);
    try {
      const res = await getAdminNotificationQueue({ status: s || undefined, channel: c || undefined, event: e || undefined, page: pg });
      setQueueRows(res.rows);
      setQueueTotal(res.total);
      setQueuePerPage(res.per_page);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load the notification queue.');
    } finally {
      setQueueLoading(false);
    }
  }, []);

  const loadDlq = useCallback(async () => {
    setDlqLoading(true);
    try {
      const res = await getAdminNotificationDeadLetter();
      setDlqRows(res.rows);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load dead-letter notifications.');
    } finally {
      setDlqLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  useEffect(() => {
    if (tab === 'queue') {
      loadQueue(statusFilter, channelFilter, eventFilter, page);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, statusFilter, channelFilter, page]);

  useEffect(() => {
    if (tab === 'dead_letter') {
      loadDlq();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  function applyQueueFilters() {
    setPage(1);
    loadQueue(statusFilter, channelFilter, eventFilter, 1);
  }

  async function submitBroadcast() {
    if (!title.trim() || !message.trim()) return;
    if (!window.confirm('Queue this notification?')) return;
    setSending(true);
    setBanner(null);
    setError(null);
    try {
      const res = await sendAdminNotificationBroadcast({
        target,
        booking_id: target === 'booking_id' ? Number(bookingId) || undefined : undefined,
        title: title.trim(),
        message: message.trim(),
      });
      setBanner(res.message);
      setTitle('');
      setMessage('');
      setBookingId('');
      await loadStats();
      if (tab === 'queue') await loadQueue(statusFilter, channelFilter, eventFilter, page);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not queue this broadcast.');
    } finally {
      setSending(false);
    }
  }

  async function doRetry(id: number) {
    setDlqActingId(id);
    setBanner(null);
    try {
      const res = await retryAdminNotification(id);
      setBanner(res.message);
      await loadDlq();
      await loadStats();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not retry this notification.');
    } finally {
      setDlqActingId(null);
    }
  }

  async function doDiscard(id: number) {
    if (!window.confirm('Discard this notification permanently?')) return;
    setDlqActingId(id);
    setBanner(null);
    try {
      const res = await discardAdminNotification(id);
      setBanner(res.message);
      await loadDlq();
      await loadStats();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not discard this notification.');
    } finally {
      setDlqActingId(null);
    }
  }

  const totalPages = Math.max(1, Math.ceil(queueTotal / queuePerPage));

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div>
        <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Notifications Center</h1>
        <p className="text-sm text-ink-500">Broadcast notifications and monitor delivery of the notification queue.</p>
      </div>

      {loadingStats && (
        <div className="mt-6 space-y-6" aria-busy="true" aria-label="Loading notifications center">
          <div className="grid gap-4 sm:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-64 w-full rounded-xl" />
        </div>
      )}

      {!loadingStats && error && !kpis && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={loadStats} />
        </div>
      )}

      {!loadingStats && kpis && (
        <>
          {banner && (
            <div className="mt-6 rounded-lg border border-success-200 bg-success-50 px-4 py-2.5 text-sm text-success-800">
              {banner}
            </div>
          )}
          {error && (
            <div className="mt-6">
              <ErrorBanner message={error} onRetry={() => setError(null)} />
            </div>
          )}

          <div className="mt-6 grid gap-4 sm:grid-cols-4">
            <div className="rounded-xl border border-success-200 bg-success-50 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-success-600">Sent</p>
              <p className="mt-2 text-xl font-bold text-success-700">✅ {kpis.sent}</p>
            </div>
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-amber-600">Pending</p>
              <p className="mt-2 text-xl font-bold text-amber-700">⏳ {kpis.pending}</p>
            </div>
            <div className="rounded-xl border border-danger-200 bg-danger-50 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-danger-500">Retrying</p>
              <p className="mt-2 text-xl font-bold text-danger-700">🔁 {kpis.retrying}</p>
            </div>
            <div className="rounded-xl border border-danger-200 bg-danger-50 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-danger-500">Dead Letter</p>
              <p className="mt-2 text-xl font-bold text-danger-700">💀 {kpis.dead_letter}</p>
            </div>
          </div>

          <div className="mt-6 rounded-xl border border-ink-100 p-4">
            <h2 className="text-base font-semibold text-ink-900">📊 Delivery Success Rate by Channel</h2>
            <div className="mt-3 overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-ink-50 text-left text-xs font-medium uppercase tracking-wide text-ink-500">
                  <tr>
                    <th className="px-3 py-2">Channel</th>
                    <th className="px-3 py-2">Sent</th>
                    <th className="px-3 py-2">Pending/Retrying</th>
                    <th className="px-3 py-2">Dead Letter</th>
                    <th className="px-3 py-2">Total</th>
                    <th className="px-3 py-2">Success Rate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink-100">
                  {channels.length > 0 ? (
                    channels.map((c) => (
                      <tr key={c.channel}>
                        <td className="px-3 py-2 font-semibold text-ink-900 capitalize">{c.channel}</td>
                        <td className="px-3 py-2">{c.sent}</td>
                        <td className="px-3 py-2">{c.pending_retrying}</td>
                        <td className="px-3 py-2">{c.dead_letter}</td>
                        <td className="px-3 py-2">{c.total}</td>
                        <td className="px-3 py-2">{c.success_rate}%</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="px-3 py-4 text-center text-ink-400">
                        No data yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <div className="rounded-xl border border-ink-100 p-4">
              <h2 className="text-base font-semibold text-ink-900">📢 Send Broadcast Notification</h2>
              <div className="mt-4 space-y-4">
                <div>
                  <label htmlFor="notif-target" className="block text-sm font-medium text-ink-700">
                    Target Audience
                  </label>
                  <select
                    id="notif-target"
                    value={target}
                    onChange={(e) => setTarget(e.target.value)}
                    className="mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                  >
                    <option value="all_vendors">All Vendors</option>
                    <option value="active_vendors">Active Vendors Only</option>
                    <option value="booking_id">Specific Booking</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="notif-booking" className="block text-sm font-medium text-ink-700">
                    Booking ID (if specific)
                  </label>
                  <input
                    id="notif-booking"
                    type="number"
                    value={bookingId}
                    onChange={(e) => setBookingId(e.target.value)}
                    placeholder="Booking ID number"
                    disabled={target !== 'booking_id'}
                    className="mt-1.5 w-40 rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs disabled:bg-ink-50 disabled:text-ink-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                  />
                </div>
                <div>
                  <label htmlFor="notif-title" className="block text-sm font-medium text-ink-700">
                    Title <span className="text-danger-600">*</span>
                  </label>
                  <input
                    id="notif-title"
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                    placeholder="Notification title"
                    className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                  />
                </div>
                <div>
                  <label htmlFor="notif-message" className="block text-sm font-medium text-ink-700">
                    Message <span className="text-danger-600">*</span>
                  </label>
                  <textarea
                    id="notif-message"
                    rows={3}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    required
                    placeholder="Notification message body..."
                    className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                  />
                </div>
                <Button onClick={submitBroadcast} loading={sending} disabled={!title.trim() || !message.trim()}>
                  📢 Queue Notification
                </Button>
                <div className="rounded-lg border border-sky-200 bg-sky-50 px-3.5 py-2.5 text-xs text-sky-800">
                  Notifications are enqueued and delivered asynchronously by the cron processor — this never blocks on sending.
                </div>
              </div>
            </div>

            <div className="rounded-xl border border-ink-100 p-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-semibold text-ink-900">📬 Queue</h2>
              </div>
              <div className="mt-3 flex gap-2">
                <Button variant={tab === 'queue' ? 'primary' : 'secondary'} size="sm" onClick={() => setTab('queue')}>
                  Recent Queue
                </Button>
                <Button variant={tab === 'dead_letter' ? 'primary' : 'secondary'} size="sm" onClick={() => setTab('dead_letter')}>
                  Dead Letter ({kpis.dead_letter})
                </Button>
              </div>

              {tab === 'queue' && (
                <div className="mt-4">
                  <div className="flex flex-wrap gap-2">
                    <select
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      className="rounded-lg border border-ink-200 px-2.5 py-1.5 text-xs"
                      aria-label="Filter by delivery status"
                    >
                      {STATUS_OPTIONS.map(([v, l]) => (
                        <option key={v} value={v}>
                          {l}
                        </option>
                      ))}
                    </select>
                    <select
                      value={channelFilter}
                      onChange={(e) => setChannelFilter(e.target.value)}
                      className="rounded-lg border border-ink-200 px-2.5 py-1.5 text-xs"
                      aria-label="Filter by channel"
                    >
                      {CHANNEL_OPTIONS.map(([v, l]) => (
                        <option key={v} value={v}>
                          {l}
                        </option>
                      ))}
                    </select>
                    <input
                      type="text"
                      value={eventFilter}
                      onChange={(e) => setEventFilter(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && applyQueueFilters()}
                      placeholder="Event name"
                      className="rounded-lg border border-ink-200 px-2.5 py-1.5 text-xs"
                      aria-label="Filter by event name"
                    />
                    <Button size="sm" onClick={applyQueueFilters}>
                      Filter
                    </Button>
                  </div>

                  {queueLoading ? (
                    <Skeleton className="mt-4 h-64 w-full rounded-xl" />
                  ) : queueRows && queueRows.length > 0 ? (
                    <>
                      <div className="mt-4 divide-y divide-ink-100">
                        {queueRows.map((q) => (
                          <div key={q.id} className="py-2.5 text-sm">
                            <div className="flex items-center justify-between">
                              <span className="font-semibold text-ink-900">{q.event}</span>
                              <span className={`rounded-full px-2 py-0.5 text-xs font-medium capitalize ${statusBadgeClass(q.status)}`}>
                                {q.status.replace('_', ' ')}
                              </span>
                            </div>
                            <div className="mt-0.5 text-xs text-ink-500">
                              {q.recipient} · {q.channel} · {fmtDate(q.created_at)}
                              {q.attempts > 0 && <> · attempts: {q.attempts}</>}
                            </div>
                            {q.error_msg && (
                              <div className="mt-0.5 text-xs text-danger-600">Error: {q.error_msg.slice(0, 120)}</div>
                            )}
                          </div>
                        ))}
                      </div>
                      <div className="mt-4 flex items-center justify-between">
                        <p className="text-xs text-ink-400">
                          Page {page} of {totalPages}
                        </p>
                        <div className="flex gap-2">
                          <Button variant="secondary" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                            Previous
                          </Button>
                          <Button variant="secondary" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                            Next
                          </Button>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="mt-4">
                      <EmptyState title="No notifications" description="Nothing matches this filter." />
                    </div>
                  )}
                </div>
              )}

              {tab === 'dead_letter' && (
                <div className="mt-4">
                  {dlqLoading ? (
                    <Skeleton className="h-64 w-full rounded-xl" />
                  ) : dlqRows && dlqRows.length > 0 ? (
                    <div className="divide-y divide-ink-100">
                      {dlqRows.map((q) => (
                        <div key={q.id} className="py-3 text-sm">
                          <div className="flex items-center justify-between">
                            <span className="font-semibold text-ink-900">{q.event}</span>
                            <span className="rounded-full bg-danger-50 px-2 py-0.5 text-xs font-medium text-danger-700">Dead Letter</span>
                          </div>
                          <div className="mt-0.5 text-xs text-ink-500">
                            Recipient: {q.recipient} · Channel: {q.channel} · Attempts: {q.attempts} · Queued: {fmtDate(q.created_at)}
                          </div>
                          {q.error_msg && <div className="mt-0.5 text-xs text-danger-600">Error: {q.error_msg}</div>}
                          <div className="mt-2 flex gap-2">
                            <Button size="sm" loading={dlqActingId === q.id} onClick={() => doRetry(q.id)}>
                              🔁 Retry Now
                            </Button>
                            <Button variant="secondary" size="sm" loading={dlqActingId === q.id} onClick={() => doDiscard(q.id)}>
                              🗑️ Discard
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <EmptyState title="No dead-letter notifications" description="Nothing needs review." />
                  )}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
