import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getAdminComplaints, updateAdminComplaint, bulkUpdateAdminComplaints, ApiError } from '../../lib/api';
import type { AdminComplaintRow } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { BottomSheet } from '../../components/ui/BottomSheet';

const STATUS_OPTIONS = [
  ['open', 'Open'],
  ['in_progress', 'In Progress'],
  ['resolved', 'Resolved'],
  ['closed', 'Closed'],
  ['disputed', 'Disputed'],
];

const PRIORITY_LABEL: Record<string, string> = { urgent: '🚨 Urgent', high: '⚡ High', normal: 'Normal', low: 'Low' };
const PRIORITY_COLOR: Record<string, string> = {
  urgent: 'text-danger-600',
  high: 'text-amber-600',
  normal: 'text-ink-600',
  low: 'text-ink-400',
};

function statusBadgeClass(status: string) {
  switch (status) {
    case 'open':
      return 'bg-danger-50 text-danger-700';
    case 'in_progress':
      return 'bg-amber-50 text-amber-700';
    case 'resolved':
      return 'bg-success-50 text-success-700';
    case 'closed':
      return 'bg-ink-100 text-ink-600';
    case 'disputed':
      return 'bg-violet-50 text-violet-700';
    default:
      return 'bg-ink-100 text-ink-600';
  }
}

function fmtDate(s: string | null) {
  if (!s) return '—';
  const d = new Date(s.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

/**
 * Rebuild of admin/pages/complaints.php: filtered/paginated complaint
 * list with per-row status update (note + status select, exactly
 * matching the legacy inline form) and a bulk status-change action
 * over checked rows. SLA breach/due-soon badges reproduce the legacy
 * page's own 2-hour "due soon" window computation, now done
 * server-side in includes/app-admin-complaints-api.php and returned
 * as `sla_state` so the client never has to reimplement that logic.
 */
export function AdminComplaintsPage() {
  const [status, setStatus] = useState('');
  const [priority, setPriority] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  const [rows, setRows] = useState<AdminComplaintRow[] | null>(null);
  const [total, setTotal] = useState(0);
  const [perPage, setPerPage] = useState(25);
  const [kpis, setKpis] = useState<{ open: number; urgent: number; resolved: number } | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [banner, setBanner] = useState<string | null>(null);

  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [bulkStatus, setBulkStatus] = useState('');
  const [bulkSaving, setBulkSaving] = useState(false);

  const [rowDrafts, setRowDrafts] = useState<Record<number, { note: string; status: string }>>({});
  const [savingRow, setSavingRow] = useState<number | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const load = useCallback(async (s: string, p: string, q: string, pg: number) => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminComplaints({ status: s || undefined, priority: p || undefined, s: q || undefined, page: pg });
      setRows(res.rows);
      setTotal(res.total);
      setPerPage(res.per_page);
      setKpis(res.kpis);
      const drafts: Record<number, { note: string; status: string }> = {};
      res.rows.forEach((r) => {
        drafts[r.id] = { note: '', status: r.status };
      });
      setRowDrafts(drafts);
      setSelected(new Set());
    } catch (err) {
      setError(
        err instanceof ApiError && err.code === 'forbidden'
          ? "You don't have permission to manage complaints."
          : err instanceof ApiError
          ? err.message
          : 'Could not load complaints. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(status, priority, search, page);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, priority, page]);

  function applyFilters() {
    setPage(1);
    load(status, priority, search, 1);
  }

  async function saveRow(id: number) {
    const draft = rowDrafts[id];
    if (!draft) return;
    setSavingRow(id);
    setBanner(null);
    try {
      const res = await updateAdminComplaint(id, { new_status: draft.status, admin_note: draft.note || undefined });
      setBanner(res.message);
      await load(status, priority, search, page);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not update this complaint.');
    } finally {
      setSavingRow(null);
    }
  }

  async function applyBulk() {
    if (!bulkStatus || selected.size === 0) return;
    if (!window.confirm('Apply bulk status change to selected complaints?')) return;
    setBulkSaving(true);
    setBanner(null);
    try {
      const res = await bulkUpdateAdminComplaints(bulkStatus, Array.from(selected));
      setBanner(`${res.updated} succeeded${res.skipped.length ? `, ${res.skipped.length} skipped: ${res.skipped.slice(0, 5).join('; ')}${res.skipped.length > 5 ? ' …' : ''}` : '.'}`);
      setBulkStatus('');
      await load(status, priority, search, page);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Bulk update failed.');
    } finally {
      setBulkSaving(false);
    }
  }

  function toggleSelected(id: number) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function toggleSelectAll() {
    if (!rows) return;
    setSelected((prev) => (prev.size === rows.length ? new Set() : new Set(rows.map((r) => r.id))));
  }

  const totalPages = Math.max(1, Math.ceil(total / perPage));
  const activeFilterCount = [status, priority, search].filter(Boolean).length;

  function filterFields(idPrefix: string) {
    return (
      <>
        <div>
          <label htmlFor={`${idPrefix}-status`} className="block text-sm font-medium text-ink-700">
            Status
          </label>
          <select
            id={`${idPrefix}-status`}
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              setPage(1);
            }}
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          >
            <option value="">All status</option>
            {STATUS_OPTIONS.map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor={`${idPrefix}-priority`} className="block text-sm font-medium text-ink-700">
            Priority
          </label>
          <select
            id={`${idPrefix}-priority`}
            value={priority}
            onChange={(e) => {
              setPriority(e.target.value);
              setPage(1);
            }}
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          >
            <option value="">All priority</option>
            {Object.entries(PRIORITY_LABEL).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </select>
        </div>
        <div className="min-w-[220px] flex-1">
          <label htmlFor={`${idPrefix}-search`} className="block text-sm font-medium text-ink-700">
            Search
          </label>
          <input
            id={`${idPrefix}-search`}
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && applyFilters()}
            placeholder="Complaint#, booking#, client, phone, vendor"
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>
      </>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div>
        <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Complaints</h1>
        <p className="text-sm text-ink-500">Client and vendor complaints, SLA tracking, and resolution.</p>
      </div>

      {loading && (
        <div className="mt-6 space-y-6" aria-busy="true" aria-label="Loading complaints">
          <div className="grid gap-4 sm:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-96 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={() => load(status, priority, search, page)} />
        </div>
      )}

      {!loading && !error && kpis && (
        <>
          {banner && (
            <div className="mt-6 rounded-lg border border-success-200 bg-success-50 px-4 py-2.5 text-sm text-success-800">
              {banner}
            </div>
          )}

          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            <div className="rounded-xl border border-danger-200 bg-danger-50 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-danger-500">Open</p>
              <p className="mt-2 text-xl font-bold text-danger-700">{kpis.open}</p>
            </div>
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-amber-600">Urgent</p>
              <p className="mt-2 text-xl font-bold text-amber-700">🚨 {kpis.urgent}</p>
            </div>
            <div className="rounded-xl border border-success-200 bg-success-50 p-4">
              <p className="text-xs font-medium uppercase tracking-wide text-success-600">Resolved</p>
              <p className="mt-2 text-xl font-bold text-success-700">✅ {kpis.resolved}</p>
            </div>
          </div>

          <div className="mt-6 hidden flex-wrap items-end gap-3 lg:flex">
            {filterFields('cmp')}
            <Button onClick={applyFilters}>Filter</Button>
            <span className="ml-auto text-sm text-ink-500">{total} complaints</span>
          </div>

          <div className="mt-6 flex items-center justify-between gap-3 lg:hidden">
            <button
              type="button"
              onClick={() => setFiltersOpen(true)}
              className="relative flex items-center gap-2 rounded-lg border border-ink-200 bg-white px-3.5 py-2 text-sm font-medium text-ink-700 shadow-xs"
            >
              <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 4h18M6 8h12M9 12h6M11 16h2" />
              </svg>
              Filters
              {activeFilterCount > 0 && <span className="ml-1 flex h-2 w-2 rounded-full bg-brand-600" aria-hidden="true" />}
            </button>
            <span className="text-sm text-ink-500">{total} complaints</span>
          </div>

          <BottomSheet open={filtersOpen} title="Filters" onClose={() => setFiltersOpen(false)}>
            <div className="flex flex-col gap-3">
              {filterFields('cmp-sheet')}
              <Button
                onClick={() => {
                  applyFilters();
                  setFiltersOpen(false);
                }}
              >
                Filter
              </Button>
            </div>
          </BottomSheet>

          <div className="mt-4 flex flex-wrap items-center gap-2 rounded-lg border border-ink-100 bg-ink-50/60 px-3 py-2.5">
            <span className="text-sm text-ink-600">{selected.size} selected</span>
            <select
              value={bulkStatus}
              onChange={(e) => setBulkStatus(e.target.value)}
              className="rounded-lg border border-ink-200 px-3 py-1.5 text-sm"
              aria-label="Bulk status change for selected complaints"
            >
              <option value="">Bulk status change…</option>
              <option value="in_progress">In Progress</option>
              <option value="resolved">Resolved</option>
              <option value="closed">Closed</option>
            </select>
            <Button variant="secondary" size="sm" disabled={!bulkStatus || selected.size === 0} loading={bulkSaving} onClick={applyBulk}>
              Apply
            </Button>
          </div>

          <div className="mt-4 hidden overflow-x-auto rounded-xl border border-ink-100 lg:block">
            <table className="w-full text-sm">
              <thead className="bg-ink-50 text-left text-xs font-medium uppercase tracking-wide text-ink-500">
                <tr>
                  <th className="px-3 py-3">
                    <input
                      type="checkbox"
                      checked={!!rows && rows.length > 0 && selected.size === rows.length}
                      onChange={toggleSelectAll}
                      aria-label="Select all complaints on this page"
                    />
                  </th>
                  <th className="px-3 py-3">ID</th>
                  <th className="px-3 py-3">Booking</th>
                  <th className="px-3 py-3">Client</th>
                  <th className="px-3 py-3">Vendor</th>
                  <th className="px-3 py-3">Category</th>
                  <th className="px-3 py-3">Priority</th>
                  <th className="px-3 py-3">Status</th>
                  <th className="px-3 py-3">SLA</th>
                  <th className="px-3 py-3">Raised</th>
                  <th className="px-3 py-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {rows && rows.length > 0 ? (
                  rows.map((c) => {
                    const draft = rowDrafts[c.id] ?? { note: '', status: c.status };
                    return (
                      <tr key={c.id}>
                        <td className="px-3 py-3">
                          <input
                            type="checkbox"
                            checked={selected.has(c.id)}
                            onChange={() => toggleSelected(c.id)}
                            aria-label={`Select complaint ${c.complaint_id}`}
                          />
                        </td>
                        <td className="px-3 py-3 font-mono text-xs text-ink-700">{c.complaint_id}</td>
                        <td className="px-3 py-3 text-xs text-ink-600">
                          {c.booking_number && c.booking_id ? (
                            <Link to={`/app/admin/bookings/${c.booking_id}`} className="font-medium text-brand-700 hover:text-brand-800">
                              {c.booking_number}
                            </Link>
                          ) : (
                            c.booking_number ?? '—'
                          )}
                        </td>
                        <td className="px-3 py-3 font-medium text-ink-900">{c.client_name ?? ''}</td>
                        <td className="px-3 py-3 text-xs text-ink-600">{c.vendor_name ?? '—'}</td>
                        <td className="px-3 py-3 text-xs text-ink-600">
                          {c.category}
                          {c.sub_category && <div className="text-ink-400">{c.sub_category}</div>}
                        </td>
                        <td className={`px-3 py-3 text-xs font-bold ${PRIORITY_COLOR[c.priority] ?? 'text-ink-600'}`}>
                          {c.priority.toUpperCase()}
                        </td>
                        <td className="px-3 py-3">
                          <span className={`rounded-full px-2 py-0.5 text-xs font-medium capitalize ${statusBadgeClass(c.status)}`}>
                            {c.status.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="px-3 py-3 text-xs">
                          {c.sla_state === 'breach' && <span className="font-bold text-danger-600">⛔ Breached</span>}
                          {c.sla_state === 'warn' && <span className="font-bold text-amber-600">⚠️ Due soon</span>}
                          {!c.sla_state && c.sla_deadline && <span className="text-ink-400">{fmtDate(c.sla_deadline)}</span>}
                          {!c.sla_state && !c.sla_deadline && '—'}
                        </td>
                        <td className="px-3 py-3 text-xs text-ink-500">{fmtDate(c.created_at)}</td>
                        <td className="px-3 py-3">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <input
                              type="text"
                              placeholder="Note (optional)"
                              value={draft.note}
                              onChange={(e) => setRowDrafts((p) => ({ ...p, [c.id]: { ...draft, note: e.target.value } }))}
                              className="w-32 rounded-md border border-ink-200 px-2 py-1 text-xs"
                              aria-label={`Note for complaint ${c.complaint_id}`}
                            />
                            <select
                              value={draft.status}
                              onChange={(e) => setRowDrafts((p) => ({ ...p, [c.id]: { ...draft, status: e.target.value } }))}
                              className="rounded-md border border-ink-200 px-2 py-1 text-xs"
                              aria-label={`Status for complaint ${c.complaint_id}`}
                            >
                              {STATUS_OPTIONS.map(([v, l]) => (
                                <option key={v} value={v}>
                                  {l}
                                </option>
                              ))}
                            </select>
                            <Button size="sm" loading={savingRow === c.id} onClick={() => saveRow(c.id)}>
                              Save
                            </Button>
                          </div>
                          {c.description && (
                            <p className="mt-1 max-w-[240px] truncate text-xs text-ink-400">{c.description.slice(0, 80)}...</p>
                          )}
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={11}>
                      <EmptyState title="No complaints found" description="Nothing matches the current filters." />
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {rows && rows.length > 0 ? (
            <div className="mt-4 space-y-3 lg:hidden">
              {rows.map((c) => {
                const draft = rowDrafts[c.id] ?? { note: '', status: c.status };
                return (
                  <div key={c.id} className="rounded-xl border border-ink-100 bg-white p-4">
                    <div className="flex items-start justify-between gap-3">
                      <label className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={selected.has(c.id)}
                          onChange={() => toggleSelected(c.id)}
                          aria-label={`Select complaint ${c.complaint_id}`}
                        />
                        <span className="font-mono text-xs text-ink-700">{c.complaint_id}</span>
                      </label>
                      <span className={`rounded-full px-2 py-0.5 text-xs font-medium capitalize ${statusBadgeClass(c.status)}`}>
                        {c.status.replace('_', ' ')}
                      </span>
                    </div>

                    <p className="mt-2 text-sm font-medium text-ink-900">{c.client_name ?? ''}</p>
                    {c.booking_number && c.booking_id ? (
                      <Link to={`/app/admin/bookings/${c.booking_id}`} className="text-xs font-medium text-brand-700 hover:text-brand-800">
                        {c.booking_number}
                      </Link>
                    ) : (
                      <p className="text-xs text-ink-500">{c.booking_number ?? '—'}</p>
                    )}

                    <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
                      <span className="text-ink-400">Vendor</span>
                      <span className="text-right text-ink-600">{c.vendor_name ?? '—'}</span>
                      <span className="text-ink-400">Category</span>
                      <span className="text-right text-ink-600">
                        {c.category}
                        {c.sub_category && ` · ${c.sub_category}`}
                      </span>
                      <span className="text-ink-400">Priority</span>
                      <span className={`text-right font-bold ${PRIORITY_COLOR[c.priority] ?? 'text-ink-600'}`}>
                        {c.priority.toUpperCase()}
                      </span>
                      <span className="text-ink-400">SLA</span>
                      <span className="text-right">
                        {c.sla_state === 'breach' && <span className="font-bold text-danger-600">⛔ Breached</span>}
                        {c.sla_state === 'warn' && <span className="font-bold text-amber-600">⚠️ Due soon</span>}
                        {!c.sla_state && c.sla_deadline && <span className="text-ink-400">{fmtDate(c.sla_deadline)}</span>}
                        {!c.sla_state && !c.sla_deadline && '—'}
                      </span>
                      <span className="text-ink-400">Raised</span>
                      <span className="text-right text-ink-500">{fmtDate(c.created_at)}</span>
                    </div>

                    {c.description && (
                      <p className="mt-2 text-xs text-ink-400">{c.description.slice(0, 80)}...</p>
                    )}

                    <div className="mt-3 space-y-2 border-t border-ink-100 pt-3">
                      <input
                        type="text"
                        placeholder="Note (optional)"
                        value={draft.note}
                        onChange={(e) => setRowDrafts((p) => ({ ...p, [c.id]: { ...draft, note: e.target.value } }))}
                        className="w-full rounded-md border border-ink-200 px-2.5 py-1.5 text-xs"
                        aria-label={`Note for complaint ${c.complaint_id}`}
                      />
                      <div className="flex gap-2">
                        <select
                          value={draft.status}
                          onChange={(e) => setRowDrafts((p) => ({ ...p, [c.id]: { ...draft, status: e.target.value } }))}
                          className="flex-1 rounded-md border border-ink-200 px-2 py-1.5 text-xs"
                          aria-label={`Status for complaint ${c.complaint_id}`}
                        >
                          {STATUS_OPTIONS.map(([v, l]) => (
                            <option key={v} value={v}>
                              {l}
                            </option>
                          ))}
                        </select>
                        <Button size="sm" loading={savingRow === c.id} onClick={() => saveRow(c.id)}>
                          Save
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="mt-4 lg:hidden">
              <EmptyState title="No complaints found" description="Nothing matches the current filters." />
            </div>
          )}

          <div className="mt-4 flex items-center justify-between">
            <p className="text-xs text-ink-400">
              Page {page} of {totalPages}
            </p>
            <div className="flex gap-2">
              <Button variant="secondary" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                Previous
              </Button>
              <Button variant="secondary" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
