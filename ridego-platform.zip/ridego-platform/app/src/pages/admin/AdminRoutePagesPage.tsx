import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ApiError,
  deleteRoutePage,
  generateRoutePages,
  getEligibleRoutes,
  getRoutePages,
  setRoutePageStatus,
  updateRoutePage,
} from '../../lib/api';
import type { EligibleRoute, RoutePage, RoutePageHeroFields, RoutePageStatus } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { RoutePageHeroFieldsEditor } from '../../components/admin/RoutePageHeroFieldsEditor';

const EMPTY_HERO: RoutePageHeroFields = {
  hero_mode: '',
  hero_heading: '',
  hero_subheading: '',
  hero_bg_color: '',
  hero_image_desktop_url: '',
  hero_image_mobile_url: '',
  hero_height_desktop: '',
  hero_height_mobile: '',
  hero_overlay_enabled: null,
  card_image_url: '',
};

const STATUS_LABEL: Record<RoutePageStatus, string> = {
  draft: 'Draft',
  needs_review: 'Needs review',
  published: 'Published',
};

const STATUS_BADGE: Record<RoutePageStatus, string> = {
  draft: 'bg-ink-100 text-ink-600',
  needs_review: 'bg-warning-50 text-warning-700',
  published: 'bg-success-50 text-success-700',
};

type StatusFilter = 'all' | RoutePageStatus;

export function AdminRoutePagesPage() {
  const [rows, setRows] = useState<RoutePage[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [state, setState] = useState('');

  const [editing, setEditing] = useState<RoutePage | null>(null);
  const [editSeoTitle, setEditSeoTitle] = useState('');
  const [editMetaDescription, setEditMetaDescription] = useState('');
  const [editHero, setEditHero] = useState<RoutePageHeroFields>(EMPTY_HERO);
  const [savingEdit, setSavingEdit] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);
  const [editIssues, setEditIssues] = useState<string[]>([]);

  const [statusTarget, setStatusTarget] = useState<{ row: RoutePage; status: RoutePageStatus } | null>(null);
  const [statusSaving, setStatusSaving] = useState(false);
  const [statusError, setStatusError] = useState<string | null>(null);
  const [statusIssues, setStatusIssues] = useState<string[]>([]);

  const [deleteTarget, setDeleteTarget] = useState<RoutePage | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const [showGenerate, setShowGenerate] = useState(false);
  const [eligible, setEligible] = useState<EligibleRoute[] | null>(null);
  const [eligibleLoading, setEligibleLoading] = useState(false);
  const [eligibleError, setEligibleError] = useState<string | null>(null);
  const [selectedRouteIds, setSelectedRouteIds] = useState<Set<number>>(new Set());
  const [generating, setGenerating] = useState(false);
  const [generateError, setGenerateError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getRoutePages({
        status: statusFilter === 'all' ? undefined : statusFilter,
        origin: origin.trim() || undefined,
        destination: destination.trim() || undefined,
        state: state.trim() || undefined,
      });
      setRows(res.rows);
    } catch (err) {
      if (err instanceof ApiError && err.code === 'forbidden') {
        setError("You don't have permission to manage route pages.");
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not load route pages. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  }, [statusFilter, origin, destination, state]);

  useEffect(() => {
    load();
  }, [load]);

  const publishedCount = useMemo(() => (rows ?? []).filter((r) => r.status === 'published').length, [rows]);
  // Published pages whose underlying Routes-tab record is inactive: these are
  // real, live, "Published" pages that are nonetheless invisible in the Home
  // Page's Popular Outstation Routes section (see ridego_app_api_popular_routes()'s
  // `r.is_active = 1`). The per-row badge below is easy to miss in a long list,
  // so also surface a single dashboard-level banner naming exactly how many —
  // this is the #1 reason an admin reports "it's published but doesn't show up".
  const inactiveRoutePublished = useMemo(
    () => (rows ?? []).filter((r) => r.status === 'published' && !r.route_active),
    [rows]
  );

  function openEdit(row: RoutePage) {
    setEditing(row);
    setEditSeoTitle(row.seo_title);
    setEditMetaDescription(row.meta_description);
    setEditHero({
      hero_mode: row.hero_mode,
      hero_heading: row.hero_heading,
      hero_subheading: row.hero_subheading,
      hero_bg_color: row.hero_bg_color,
      hero_image_desktop_url: row.hero_image_desktop_url,
      hero_image_mobile_url: row.hero_image_mobile_url,
      hero_height_desktop: row.hero_height_desktop,
      hero_height_mobile: row.hero_height_mobile,
      hero_overlay_enabled: row.hero_overlay_enabled,
      card_image_url: row.card_image_url,
    });
    setEditError(null);
    setEditIssues([]);
  }

  async function submitEdit() {
    if (!editing) return;
    setSavingEdit(true);
    setEditError(null);
    try {
      const res = await updateRoutePage(editing.id, {
        seo_title: editSeoTitle,
        meta_description: editMetaDescription,
        ...editHero,
      });
      setEditIssues(res.quality_issues);
      setActionMessage('Route page updated.');
      setEditing(null);
      await load();
    } catch (err) {
      setEditError(err instanceof ApiError ? err.message : 'Could not save this route page.');
    } finally {
      setSavingEdit(false);
    }
  }

  async function confirmStatusChange() {
    if (!statusTarget) return;
    setStatusSaving(true);
    setStatusError(null);
    setStatusIssues([]);
    try {
      const res = await setRoutePageStatus(statusTarget.row.id, statusTarget.status);
      setActionMessage(res.message);
      setStatusTarget(null);
      await load();
    } catch (err) {
      if (err instanceof ApiError && err.code === 'quality_check_failed') {
        const issues = err.data?.quality_issues ?? [];
        setStatusIssues(issues);
        setStatusError(err.message);
      } else {
        setStatusError(err instanceof ApiError ? err.message : 'Could not change this route page\'s status.');
      }
    } finally {
      setStatusSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    setDeleteError(null);
    try {
      const res = await deleteRoutePage(deleteTarget.id);
      setActionMessage(res.message);
      setDeleteTarget(null);
      await load();
    } catch (err) {
      setDeleteError(err instanceof ApiError ? err.message : 'Could not delete this route page.');
    } finally {
      setDeleting(false);
    }
  }

  async function openGenerate() {
    setShowGenerate(true);
    setSelectedRouteIds(new Set());
    setGenerateError(null);
    setEligibleLoading(true);
    setEligibleError(null);
    try {
      const res = await getEligibleRoutes();
      setEligible(res.rows);
    } catch (err) {
      setEligibleError(err instanceof ApiError ? err.message : 'Could not load eligible routes.');
    } finally {
      setEligibleLoading(false);
    }
  }

  function toggleRoute(id: number) {
    setSelectedRouteIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function toggleSelectAll() {
    if (!eligible) return;
    setSelectedRouteIds((prev) => (prev.size === eligible.length ? new Set() : new Set(eligible.map((r) => r.route_id))));
  }

  async function submitGenerate() {
    if (selectedRouteIds.size === 0) return;
    setGenerating(true);
    setGenerateError(null);
    try {
      const res = await generateRoutePages(Array.from(selectedRouteIds));
      setActionMessage(`Generated ${res.created} of ${res.total} selected route page(s).`);
      setShowGenerate(false);
      await load();
    } catch (err) {
      setGenerateError(err instanceof ApiError ? err.message : 'Could not generate route pages.');
    } finally {
      setGenerating(false);
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Route Pages</h1>
          <p className="text-sm text-ink-500">
            SEO/marketing landing pages for individual routes, generated from real route, pricing and vehicle data.
          </p>
          {!loading && !error && rows && (
            <p className="mt-1 text-xs text-ink-400">
              {rows.length} route page{rows.length === 1 ? '' : 's'} &middot; {publishedCount} published
            </p>
          )}
        </div>
        <div className="flex gap-2">
          <Link
            to="/admin/route-page-settings"
            className="inline-flex items-center rounded-lg border border-ink-200 px-3.5 py-2 text-sm font-medium text-ink-700 hover:bg-ink-50"
          >
            Hero settings
          </Link>
          <Button onClick={openGenerate}>Generate pages</Button>
        </div>
      </div>

      {actionMessage && !loading && (
        <div role="status" className="mt-4 rounded-lg border border-success-500/30 bg-success-50 px-3.5 py-2.5 text-sm text-success-700">
          {actionMessage}
        </div>
      )}

      {!loading && !error && inactiveRoutePublished.length > 0 && (
        <div role="alert" className="mt-4 rounded-lg border border-warning-500/40 bg-warning-50 px-3.5 py-3 text-sm text-warning-800">
          <p className="font-semibold">
            {inactiveRoutePublished.length} published route page{inactiveRoutePublished.length === 1 ? ' is' : 's are'} hidden from the Home Page
          </p>
          <p className="mt-0.5 text-warning-700">
            {inactiveRoutePublished
              .map((r) => `${r.from_city} → ${r.to_city}`)
              .join(', ')}
            {' — '}"Published" here only controls this page; the Home Page's Popular Outstation Routes also requires the underlying route to be active on the{' '}
            <strong>Routes tab</strong>. Activate it there to make {inactiveRoutePublished.length === 1 ? 'this route' : 'these routes'} appear.
          </p>
        </div>
      )}

      <div className="mt-6 flex flex-wrap gap-3">
        <div className="w-full sm:w-48">
          <label htmlFor="rp-status-filter" className="sr-only">
            Status
          </label>
          <select
            id="rp-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
            className="w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          >
            <option value="all">All statuses</option>
            <option value="draft">Draft</option>
            <option value="needs_review">Needs review</option>
            <option value="published">Published</option>
          </select>
        </div>
        <div className="w-full flex-1 sm:min-w-[10rem]">
          <label htmlFor="rp-origin" className="sr-only">
            Origin
          </label>
          <input
            id="rp-origin"
            type="text"
            placeholder="Origin city"
            value={origin}
            onChange={(e) => setOrigin(e.target.value)}
            className="w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>
        <div className="w-full flex-1 sm:min-w-[10rem]">
          <label htmlFor="rp-destination" className="sr-only">
            Destination
          </label>
          <input
            id="rp-destination"
            type="text"
            placeholder="Destination city"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            className="w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>
        <div className="w-full flex-1 sm:min-w-[10rem]">
          <label htmlFor="rp-state" className="sr-only">
            State
          </label>
          <input
            id="rp-state"
            type="text"
            placeholder="State"
            value={state}
            onChange={(e) => setState(e.target.value)}
            className="w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>
      </div>

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading route pages">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-xl" />
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={load} />}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState
            title="No route pages yet"
            description="Generate a page for an eligible route to get started."
            action={<Button onClick={openGenerate}>Generate pages</Button>}
          />
        )}

        {!loading && !error && rows && rows.length > 0 && (
          <ul className="space-y-3">
            {rows.map((r) => (
              <li key={r.id} className="rounded-xl border border-ink-100 p-4 shadow-xs sm:p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0 max-w-full break-words">
                    <p className="font-semibold text-ink-900">
                      {r.from_city} &rarr; {r.to_city}
                      <span className={`ml-2 rounded-full px-2 py-0.5 text-xs font-semibold ${STATUS_BADGE[r.status]}`}>
                        {STATUS_LABEL[r.status]}
                      </span>
                      {r.status === 'published' && !r.route_active && (
                        <span className="ml-2 rounded-full bg-danger-50 px-2 py-0.5 text-xs font-semibold text-danger-600">
                          Route deactivated — hidden from Home Page
                        </span>
                      )}
                      {r.has_quality_issues && (
                        <span className="ml-2 rounded-full bg-danger-50 px-2 py-0.5 text-xs font-semibold text-danger-600">
                          {r.quality_issues.length} quality issue{r.quality_issues.length === 1 ? '' : 's'}
                        </span>
                      )}
                      {r.is_popular && (
                        <span className="ml-2 rounded-full bg-brand-50 px-2 py-0.5 text-xs font-semibold text-brand-700">
                          Popular
                        </span>
                      )}
                    </p>
                    <p className="mt-0.5 text-sm text-ink-500">
                      /routes/{r.slug} &middot; {r.from_state ?? '—'} &rarr; {r.to_state ?? '—'} &middot; {r.distance_km} km
                    </p>
                    <p className="mt-1 text-sm text-ink-700">{r.seo_title || <em className="text-ink-400">No SEO title set</em>}</p>
                    {r.has_quality_issues && (
                      <ul className="mt-1.5 list-inside list-disc text-xs text-danger-600">
                        {r.quality_issues.map((issue, i) => (
                          <li key={i}>{issue}</li>
                        ))}
                      </ul>
                    )}
                  </div>
                  <div className="flex shrink-0 flex-wrap gap-2">
                    <Button variant="secondary" size="sm" onClick={() => openEdit(r)}>
                      Edit SEO
                    </Button>
                    {r.status !== 'published' && (
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => {
                          setStatusTarget({ row: r, status: 'published' });
                          setStatusError(null);
                          setStatusIssues([]);
                        }}
                      >
                        Publish
                      </Button>
                    )}
                    {r.status === 'published' && (
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => {
                          setStatusTarget({ row: r, status: 'draft' });
                          setStatusError(null);
                          setStatusIssues([]);
                        }}
                      >
                        Unpublish
                      </Button>
                    )}
                    {r.status !== 'needs_review' && r.status !== 'published' && (
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => {
                          setStatusTarget({ row: r, status: 'needs_review' });
                          setStatusError(null);
                          setStatusIssues([]);
                        }}
                      >
                        Mark needs review
                      </Button>
                    )}
                    <Button
                      variant="danger"
                      size="sm"
                      onClick={() => {
                        setDeleteTarget(r);
                        setDeleteError(null);
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Edit SEO fields */}
      <ConfirmDialog
        open={!!editing}
        title={editing ? `Edit SEO — ${editing.from_city} → ${editing.to_city}` : 'Edit SEO'}
        confirmLabel="Save changes"
        confirmVariant="primary"
        loading={savingEdit}
        onConfirm={submitEdit}
        onCancel={() => {
          if (savingEdit) return;
          setEditing(null);
        }}
      >
        <div className="space-y-3">
          {editError && (
            <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
              {editError}
            </div>
          )}
          {editIssues.length > 0 && (
            <ul className="list-inside list-disc rounded-lg border border-warning-500/30 bg-warning-50 px-3 py-2 text-xs text-warning-700">
              {editIssues.map((issue, i) => (
                <li key={i}>{issue}</li>
              ))}
            </ul>
          )}
          <div>
            <label htmlFor="rp-seo-title" className="block text-sm font-medium text-ink-700">
              SEO title
            </label>
            <input
              id="rp-seo-title"
              type="text"
              value={editSeoTitle}
              onChange={(e) => setEditSeoTitle(e.target.value)}
              maxLength={160}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div>
            <label htmlFor="rp-meta-description" className="block text-sm font-medium text-ink-700">
              Meta description
            </label>
            <textarea
              id="rp-meta-description"
              value={editMetaDescription}
              onChange={(e) => setEditMetaDescription(e.target.value)}
              maxLength={320}
              rows={3}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>

          <div>
            <p className="text-sm font-semibold text-ink-800">Hero — per-route override</p>
            <p className="text-xs text-ink-500">
              Overrides the <Link to="/admin/route-page-settings" className="text-brand-600 hover:underline">global default</Link> for this route only.
              Leave a field blank/unset to keep using the global default.
            </p>
            <div className="mt-2">
              <RoutePageHeroFieldsEditor value={editHero} onChange={(patch) => setEditHero((prev) => ({ ...prev, ...patch }))} isOverride />
            </div>
          </div>
        </div>
      </ConfirmDialog>

      {/* Status change confirm */}
      <ConfirmDialog
        open={!!statusTarget}
        title={
          statusTarget
            ? `${statusTarget.status === 'published' ? 'Publish' : statusTarget.status === 'draft' ? 'Unpublish' : 'Mark needs review:'} ${statusTarget.row.from_city} → ${statusTarget.row.to_city}?`
            : ''
        }
        confirmLabel={statusTarget?.status === 'published' ? 'Publish' : 'Confirm'}
        confirmVariant="primary"
        loading={statusSaving}
        onConfirm={confirmStatusChange}
        onCancel={() => {
          if (statusSaving) return;
          setStatusTarget(null);
        }}
      >
        {statusError && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {statusError}
          </div>
        )}
        {statusIssues.length > 0 && (
          <ul className="mt-2 list-inside list-disc rounded-lg border border-warning-500/30 bg-warning-50 px-3 py-2 text-xs text-warning-700">
            {statusIssues.map((issue, i) => (
              <li key={i}>{issue}</li>
            ))}
          </ul>
        )}
      </ConfirmDialog>

      {/* Delete confirm */}
      <ConfirmDialog
        open={!!deleteTarget}
        title={deleteTarget ? `Delete route page ${deleteTarget.from_city} → ${deleteTarget.to_city}?` : ''}
        description="This removes the page's workflow entry; the underlying route is untouched."
        confirmLabel="Delete"
        confirmVariant="danger"
        loading={deleting}
        onConfirm={confirmDelete}
        onCancel={() => {
          if (deleting) return;
          setDeleteTarget(null);
        }}
      >
        {deleteError && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {deleteError}
          </div>
        )}
      </ConfirmDialog>

      {/* Generate pages */}
      <ConfirmDialog
        open={showGenerate}
        title="Generate route pages"
        confirmLabel={generating ? 'Generating…' : `Generate ${selectedRouteIds.size || ''}`.trim()}
        confirmVariant="primary"
        loading={generating}
        confirmDisabled={selectedRouteIds.size === 0}
        onConfirm={submitGenerate}
        onCancel={() => {
          if (generating) return;
          setShowGenerate(false);
        }}
      >
        <div className="space-y-3">
          {generateError && (
            <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
              {generateError}
            </div>
          )}
          {eligibleLoading && (
            <div className="space-y-2" aria-busy="true" aria-label="Loading eligible routes">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full rounded-lg" />
              ))}
            </div>
          )}
          {!eligibleLoading && eligibleError && <ErrorBanner message={eligibleError} onRetry={openGenerate} />}
          {!eligibleLoading && !eligibleError && eligible && eligible.length === 0 && (
            <p className="text-sm text-ink-500">Every active route already has a page.</p>
          )}
          {!eligibleLoading && !eligibleError && eligible && eligible.length > 0 && (
            <>
              <div className="flex items-center justify-between text-sm">
                <span className="text-ink-500">
                  {selectedRouteIds.size} of {eligible.length} eligible route{eligible.length === 1 ? '' : 's'} selected
                </span>
                <button type="button" className="font-medium text-brand-700 hover:text-brand-800" onClick={toggleSelectAll}>
                  {selectedRouteIds.size === eligible.length ? 'Clear all' : 'Select all'}
                </button>
              </div>
              <ul className="max-h-72 space-y-1 overflow-y-auto rounded-lg border border-ink-100 p-2">
                {eligible.map((r) => (
                  <li key={r.route_id}>
                    <label className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-ink-50">
                      <input
                        type="checkbox"
                        checked={selectedRouteIds.has(r.route_id)}
                        disabled={!r.eligible}
                        onChange={() => toggleRoute(r.route_id)}
                        className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
                      />
                      <span className={r.eligible ? 'text-ink-800' : 'text-ink-300'}>
                        {r.from_city} &rarr; {r.to_city}
                        {r.is_popular && <span className="ml-1.5 text-xs font-semibold text-brand-600">Popular</span>}
                        {!r.eligible && <span className="ml-1.5 text-xs">(no distance or vehicle data)</span>}
                      </span>
                    </label>
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      </ConfirmDialog>
    </div>
  );
}
