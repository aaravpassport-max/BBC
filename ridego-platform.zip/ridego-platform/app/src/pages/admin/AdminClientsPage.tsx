import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createClient, duplicateOf, errMessage, inr, listClients, SOURCE_LABELS, type ClientListResponse } from '../../lib/api-admin-crm';
import { ClientFields, EMPTY_CLIENT, validateClientForm, type ClientFormErrors, type ClientFormValues } from '../../components/admin/ClientFields';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { useToast } from '../../context/ToastContext';
import { INPUT_CLASS, ToneBadge, formatDateTime } from '../vendor-mkt/vendor-mkt-shared';
import { brand } from '../../lib/brand';

const SORTS: { key: string; label: string; order: string }[] = [
  { key: 'recent', label: 'Newest first', order: 'DESC' },
  { key: 'name', label: 'Name A to Z', order: 'ASC' },
  { key: 'bookings', label: 'Most bookings', order: 'DESC' },
  { key: 'billed', label: 'Highest ride value', order: 'DESC' },
];

// TRACE: route /app/admin/clients → searchable, filterable, sortable client list with a "New client" sheet → list, sheet, navigation to the created profile.
//        Search box (name, mobile digits, email, company) + type/status/source filters + sort + paging all refetch through listClients; the server returns booking
//        counts per row. Creating validates client-side first, then the server (duplicate mobile/email → 409 → warning with "Open profile"); success navigates to
//        the new profile. Edge cases: empty result (designed empty state), API error (banner + retry), double submit (button loading), stale response ignored.
export function AdminClientsPage() {
  const toast = useToast();
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [qInput, setQInput] = useState('');
  const [type, setType] = useState('');
  const [status, setStatus] = useState('');
  const [source, setSource] = useState('');
  const [sort, setSort] = useState('recent');
  const [page, setPage] = useState(1);
  const [data, setData] = useState<ClientListResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sheet, setSheet] = useState(false);
  const [form, setForm] = useState<ClientFormValues>(EMPTY_CLIENT);
  const [errors, setErrors] = useState<ClientFormErrors>({});
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [dupId, setDupId] = useState<number | null>(null);
  const reqId = useRef(0);

  // TRACE: any filter/sort/page change → fetches the list → stores it; a response that arrives after a newer request started is dropped. Error → banner.
  const load = useCallback(async () => {
    const my = ++reqId.current;
    setLoading(true);
    setError(null);
    try {
      const s = SORTS.find((x) => x.key === sort);
      const res = await listClients({ q, type, status, source, sort, order: s?.order, page });
      if (my === reqId.current) setData(res);
    } catch (err) {
      if (my === reqId.current) setError(errMessage(err, 'Could not load clients. Please try again.'));
    } finally {
      if (my === reqId.current) setLoading(false);
    }
  }, [q, type, status, source, sort, page]);

  useEffect(() => {
    void load();
  }, [load]);

  // TRACE: search form submit → applies the typed text as the query and returns to page 1 → state set.
  const submitSearch = (e: FormEvent) => {
    e.preventDefault();
    setQ(qInput.trim());
    setPage(1);
  };

  // TRACE: "New client" click → opens an empty form sheet with previous errors cleared → state reset.
  const openNew = () => {
    setForm(EMPTY_CLIENT);
    setErrors({});
    setFormError(null);
    setDupId(null);
    setSheet(true);
  };

  // TRACE: New client submit → validate → POST → toast + go to the profile; 409 → shows the duplicate warning with a link; other errors inline. Values kept on failure.
  const submitNew = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    const v = validateClientForm(form);
    setErrors(v);
    if (Object.keys(v).length > 0) return;
    setSaving(true);
    setFormError(null);
    setDupId(null);
    try {
      const res = await createClient({ ...form, allow_email_duplicate: false });
      toast.show(res.message || 'Client created.', 'success');
      setSheet(false);
      if (res.id) navigate(`/app/admin/clients/${res.id}`);
      else void load();
    } catch (err) {
      setFormError(errMessage(err, 'Could not save the client. Please try again.'));
      setDupId(duplicateOf(err)?.id ?? null);
    } finally {
      setSaving(false);
    }
  };

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.per_page)) : 1;

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Clients</h1>
          <p className="mt-1 text-sm text-ink-600">Every person or company who books with {brand().name}, however they reached you.</p>
        </div>
        <div className="flex gap-2">
          <Link to="/admin/bookings/new" className="inline-flex items-center rounded-lg border border-ink-200 bg-white px-4 py-2.5 text-sm font-medium text-ink-800 hover:bg-ink-50">
            New booking
          </Link>
          <Button onClick={openNew}>New client</Button>
        </div>
      </div>

      <form onSubmit={submitSearch} className="mt-5 flex flex-col gap-3 rounded-xl border border-ink-100 bg-white p-4 shadow-xs" role="search" aria-label="Search clients">
        <div className="flex gap-2">
          <input
            type="search"
            value={qInput}
            onChange={(e) => setQInput(e.target.value)}
            placeholder="Search name, mobile, email or company"
            aria-label="Search clients"
            className={INPUT_CLASS}
          />
          <Button type="submit" variant="secondary">
            Search
          </Button>
        </div>
        <div className="grid gap-3 sm:grid-cols-4">
          <select aria-label="Client type" value={type} onChange={(e) => { setType(e.target.value); setPage(1); }} className={INPUT_CLASS}>
            <option value="">All types</option>
            <option value="individual">Individual</option>
            <option value="corporate">Corporate</option>
          </select>
          <select aria-label="Client status" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} className={INPUT_CLASS}>
            <option value="">Active and blocked</option>
            <option value="active">Active</option>
            <option value="blocked">Blocked</option>
          </select>
          <select aria-label="Source" value={source} onChange={(e) => { setSource(e.target.value); setPage(1); }} className={INPUT_CLASS}>
            <option value="">All sources</option>
            {Object.entries(SOURCE_LABELS).map(([k, label]) => (
              <option key={k} value={k}>
                {label}
              </option>
            ))}
          </select>
          <select aria-label="Sort by" value={sort} onChange={(e) => { setSort(e.target.value); setPage(1); }} className={INPUT_CLASS}>
            {SORTS.map((s) => (
              <option key={s.key} value={s.key}>
                {s.label}
              </option>
            ))}
          </select>
        </div>
      </form>

      <div className="mt-5">
        {error && <ErrorBanner message={error} onRetry={() => void load()} />}
        {loading && !data && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading clients">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        )}
        {data && data.rows.length === 0 && !error && (
          <EmptyState
            title="No clients found"
            description={q || type || status || source ? 'Nothing matches these filters. Try clearing them.' : 'Create your first client, or create a booking and the client is added automatically.'}
            action={<Button onClick={openNew}>New client</Button>}
          />
        )}
        {data && data.rows.length > 0 && (
          <>
            <p className="mb-2 text-sm text-ink-600" aria-live="polite">
              {data.total} client{data.total === 1 ? '' : 's'}
            </p>
            <ul className="space-y-3">
              {data.rows.map((c) => (
                <li key={c.id} className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0">
                      <Link to={`/app/admin/clients/${c.id}`} className="text-base font-semibold text-brand-700 hover:underline">
                        {c.name}
                      </Link>
                      <p className="text-sm text-ink-600">
                        {[c.phone, c.email, c.client_type === 'corporate' ? c.company_name : '', c.city].filter(Boolean).join(' · ')}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {c.client_type === 'corporate' && <ToneBadge tone="brand">Corporate</ToneBadge>}
                      {c.status === 'blocked' && <ToneBadge tone="danger">Blocked</ToneBadge>}
                      <ToneBadge tone="neutral">{SOURCE_LABELS[c.source] ?? c.source}</ToneBadge>
                    </div>
                  </div>
                  <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-sm sm:grid-cols-4">
                    <div>
                      <dt className="text-ink-500">Bookings</dt>
                      <dd className="font-medium text-ink-900">
                        {c.bookings} ({c.completed} done, {c.cancelled} cancelled)
                      </dd>
                    </div>
                    <div>
                      <dt className="text-ink-500">Ride value (est.)</dt>
                      <dd className="font-medium text-ink-900">{inr(c.billed)}</dd>
                    </div>
                    <div>
                      <dt className="text-ink-500">Last trip</dt>
                      <dd className="font-medium text-ink-900">{c.last_trip ? formatDateTime(c.last_trip) : '—'}</dd>
                    </div>
                    <div className="flex items-end gap-3">
                      <Link to={`/app/admin/bookings/new?client=${c.id}`} className="text-sm font-medium text-brand-700 hover:underline" aria-label={`New booking for ${c.name}`}>
                        New booking
                      </Link>
                    </div>
                  </dl>
                </li>
              ))}
            </ul>
            {totalPages > 1 && (
              <nav className="mt-4 flex items-center justify-between" aria-label="Pagination">
                <Button variant="secondary" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                  Previous
                </Button>
                <span className="text-sm text-ink-600">
                  Page {page} of {totalPages}
                </span>
                <Button variant="secondary" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))}>
                  Next
                </Button>
              </nav>
            )}
          </>
        )}
      </div>

      <BottomSheet open={sheet} title="New client" onClose={() => (saving ? undefined : setSheet(false))}>
        <form onSubmit={submitNew} className="space-y-4" noValidate>
          <ClientFields values={form} errors={errors} onChange={(p) => setForm((f) => ({ ...f, ...p }))} disabled={saving} idPrefix="newcl" />
          {formError && (
            <div role="alert" className="text-sm font-medium text-danger-600">
              {formError}{' '}
              {dupId && (
                <Link to={`/app/admin/clients/${dupId}`} className="underline">
                  Open the existing profile
                </Link>
              )}
            </div>
          )}
          <div className="flex gap-3">
            <Button type="submit" loading={saving} fullWidth>
              Save client
            </Button>
            <Button type="button" variant="secondary" onClick={() => setSheet(false)} disabled={saving} fullWidth>
              Cancel
            </Button>
          </div>
        </form>
      </BottomSheet>
    </div>
  );
}
