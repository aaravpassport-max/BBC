import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ApiError, getRoutePageHeroDefaults, updateRoutePageHeroDefaults } from '../../lib/api';
import type { RoutePageHeroFields } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Button } from '../../components/ui/Button';
import { RoutePageHeroFieldsEditor } from '../../components/admin/RoutePageHeroFieldsEditor';

const EMPTY_HERO: RoutePageHeroFields = {
  hero_mode: 'standard',
  hero_heading: '',
  hero_subheading: '',
  hero_bg_color: '',
  hero_image_desktop_url: '',
  hero_image_mobile_url: '',
  hero_height_desktop: '',
  hero_height_mobile: '',
  hero_overlay_enabled: false,
  card_image_url: '',
};

/**
 * Global-default Hero settings (Task 3-6) — the fallback every route page's
 * hero uses for a given field when that route has no override set for it
 * (see AdminRoutePagesPage's per-route "Hero — per-route override" section).
 * Same field set, same backend (route_page_hero_default_* keys in the shared
 * ridego_settings store), read/written through
 * getRoutePageHeroDefaults()/updateRoutePageHeroDefaults().
 */
export function AdminRoutePageSettingsPage() {
  const [hero, setHero] = useState<RoutePageHeroFields>(EMPTY_HERO);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await getRoutePageHeroDefaults();
        if (!cancelled) {
          setHero({
            ...res,
            hero_mode: res.hero_mode || 'standard',
            hero_overlay_enabled: res.hero_overlay_enabled ?? false,
          });
        }
      } catch (err) {
        if (!cancelled) setError(err instanceof ApiError ? err.message : 'Could not load hero settings.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  async function handleSave() {
    setSaving(true);
    setSaveError(null);
    setSaved(false);
    try {
      await updateRoutePageHeroDefaults(hero);
      setSaved(true);
    } catch (err) {
      setSaveError(err instanceof ApiError ? err.message : 'Could not save hero settings.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <p className="text-xs text-ink-400">
        <Link to="/admin/route-pages" className="hover:underline">
          Route Pages
        </Link>{' '}
        / Settings
      </p>
      <h1 className="mt-1 text-2xl font-bold text-ink-900 sm:text-3xl">Route Page Settings — Hero (Global Default)</h1>
      <p className="mt-1 text-sm text-ink-500">
        The fallback hero every route page uses, for any field a specific route hasn&apos;t overridden. Edit a route&apos;s own hero from its
        entry on the Route Pages screen.
      </p>

      {loading && (
        <div className="mt-6 space-y-3">
          <Skeleton className="h-40 w-full" />
        </div>
      )}
      {error && (
        <div className="mt-6">
          <ErrorBanner message={error} />
        </div>
      )}

      {!loading && !error && (
        <div className="mt-6 space-y-4">
          {saveError && (
            <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
              {saveError}
            </div>
          )}
          {saved && (
            <div role="status" className="rounded-lg border border-success-500/30 bg-success-50 px-3 py-2 text-sm text-success-700">
              Global default hero settings saved.
            </div>
          )}
          <RoutePageHeroFieldsEditor value={hero} onChange={(patch) => setHero((prev) => ({ ...prev, ...patch }))} />
          <Button variant="primary" onClick={handleSave} loading={saving}>
            Save global default
          </Button>
        </div>
      )}
    </div>
  );
}
