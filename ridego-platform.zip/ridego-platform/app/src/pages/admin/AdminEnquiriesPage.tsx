import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { createEnquiry, errMessage, inr, listEnquiries, SOURCE_LABELS, TRIP_TYPE_LABELS, updateEnquiry, type Enquiry, type EnquiryListResponse } from '../../lib/api-admin-crm';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { useToast } from '../../context/ToastContext';
import { FormField, INPUT_CLASS, ToneBadge } from '../vendor-mkt/vendor-mkt-shared';

const STATUS_TABS: { key: string; label: string }[] = [
  { key: '', label: 'All' },
  { key: 'new', label: 'New' },
  { key: 'contacted', label: 'Contacted' },
  { key: 'quoted', label: 'Quoted' },
  { key: 'converted', label: 'Converted' },
  { key: 'lost', label: 'Lost' },
];

interface EnquiryForm {
  name: string;
  phone: string;
  email: string;
  source: string;
  trip_type: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  passengers: string;
  message: string;
  quoted_amount: string;
  follow_up_date: string;
  status: string;
  lost_reason: string;
}

const EMPTY: EnquiryForm = {
  name: '', phone: '', email: '', source: 'phone', trip_type: 'one_way', pickup_city: '', drop_city: '', journey_date: '',
  passengers: '1', message: '', quoted_amount: '', follow_up_date: '', status: 'new', lost_reason: '',
};

// TRACE: row status → badge tone name. Pure lookup; unknown status falls back to neutral.
function toneFor(s: string): 'brand' | 'success' | 'danger' | 'warning' | 'neutral' {
  if (s === 'converted') return 'success';
  if (s === 'lost') return 'danger';
  if (s === 'new') return 'warning';
  if (s === 'quoted') return 'brand';
  return 'neutral';
}

// TRACE: route /app/admin/enquiries → status tabs with counts, search, overdue filter, new/edit sheet, "Convert to booking" link → list, sheet, navigation.
//        Save validates (name, mobile 10+ digits; lost needs a reason) then POST/PUT; success closes the sheet and reloads; failure shows the message inline with
//        values kept. Converted enquiries are read-only (no edit, no convert). Edge cases: empty tab, API error + retry, double submit, stale response dropped.
export function AdminEnquiriesPage() {
  const toast = useToast();
  const [status, setStatus] = useState('');
  const [overdue, setOverdue] = useState(false);
  const [q, setQ] = useState('');
  const [qInput, setQInput] = useState('');
  const [page, setPage] = useState(1);
  const [data, setData] = useState<EnquiryListResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sheet, setSheet] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<EnquiryForm>(EMPTY);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const reqId = useRef(0);

  // TRACE: filter/page change → GET enquiries → stores; older responses ignored; error → banner.
  const load = useCallback(async () => {
    const my = ++reqId.current;
    setLoading(true);
    setError(null);
    try {
      const res = await listEnquiries({ status, q, overdue, page });
      if (my === reqId.current) setData(res);
    } catch (err) {
      if (my === reqId.current) setError(errMessage(err, 'Could not load enquiries. Please try again.'));
    } finally {
      if (my === reqId.current) setLoading(false);
    }
  }, [status, q, overdue, page]);

  useEffect(() => {
    void load();
  }, [load]);

  // TRACE: "New enquiry" → empty sheet. State reset only.
  const openNew = () => {
    setEditId(null);
    setForm(EMPTY);
    setFormError(null);
    setSheet(true);
  };

  // TRACE: "Edit" on a row → sheet prefilled with THAT row's values (from the row object, not an index). State set only.
  const openEdit = (e: Enquiry) => {
    setEditId(e.id);
    setForm({
      name: e.name, phone: e.phone, email: e.email, source: e.source, trip_type: e.trip_type, pickup_city: e.pickup_city, drop_city: e.drop_city,
      journey_date: e.journey_date ?? '', passengers: String(e.passengers || 1), message: e.message,
      quoted_amount: e.quoted_amount == null ? '' : String(e.quoted_amount), follow_up_date: e.follow_up_date ?? '', status: e.status, lost_reason: e.lost_reason,
    });
    setFormError(null);
    setSheet(true);
  };

  // TRACE: sheet submit → validate → POST (new) or PUT (edit) → toast, close, reload. Errors inline; values kept.
  const submit = async (ev: FormEvent) => {
    ev.preventDefault();
    if (saving) return;
    if (form.name.trim() === '') return setFormError('Enter the name.');
    if (form.phone.replace(/\D/g, '').length < 10) return setFormError('Enter a valid mobile number.');
    if (form.status === 'lost' && form.lost_reason.trim() === '') return setFormError('Say why this enquiry was lost.');
    setSaving(true);
    setFormError(null);
    const body: Record<string, unknown> = {
      ...form,
      passengers: Number(form.passengers) || 1,
      quoted_amount: form.quoted_amount === '' ? null : Number(form.quoted_amount),
    };
    try {
      const res = editId ? await updateEnquiry(editId, body) : await createEnquiry(body);
      toast.show(res.message || 'Enquiry saved.', 'success');
      setSheet(false);
      void load();
    } catch (err) {
      setFormError(errMessage(err, 'Could not save the enquiry. Please try again.'));
    } finally {
      setSaving(false);
    }
  };

  const set = (k: keyof EnquiryForm) => (e: { target: { value: string } }) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.per_page)) : 1;

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Enquiries</h1>
          <p className="mt-1 text-sm text-ink-600">Track calls and messages, quote them, follow up, then convert to a booking.</p>
        </div>
        <Button onClick={openNew}>New enquiry</Button>
      </div>

      <div className="mt-5 flex flex-wrap gap-2" role="tablist" aria-label="Enquiry status">
        {STATUS_TABS.map((t) => (
          <button
            key={t.key || 'all'}
            type="button"
            role="tab"
            aria-selected={status === t.key}
            onClick={() => { setStatus(t.key); setPage(1); }}
            className={`rounded-full border px-3 py-1.5 text-sm font-medium ${status === t.key ? 'border-brand-600 bg-brand-50 text-brand-700' : 'border-ink-200 bg-white text-ink-700 hover:bg-ink-50'}`}
          >
            {t.label}
            {t.key !== '' && data?.counts ? ` (${data.counts[t.key] ?? 0})` : ''}
          </button>
        ))}
      </div>

      <form
        onSubmit={(e) => { e.preventDefault(); setQ(qInput.trim()); setPage(1); }}
        className="mt-4 flex flex-wrap items-center gap-2"
        role="search"
        aria-label="Search enquiries"
      >
        <input type="search" value={qInput} onChange={(e) => setQInput(e.target.value)} placeholder="Search name, mobile or city" aria-label="Search enquiries" className={`${INPUT_CLASS} max-w-sm`} />
        <Button type="submit" variant="secondary">Search</Button>
        <label className="flex items-center gap-2 text-sm text-ink-700">
          <input type="checkbox" checked={overdue} onChange={(e) => { setOverdue(e.target.checked); setPage(1); }} />
          Follow-up overdue only
        </label>
      </form>

      <div className="mt-5">
        {error && <ErrorBanner message={error} onRetry={() => void load()} />}
        {loading && !data && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading enquiries">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        )}
        {data && data.rows.length === 0 && !error && (
          <EmptyState title="No enquiries here" description="Log a call or message as an enquiry so it can be quoted and followed up." action={<Button onClick={openNew}>New enquiry</Button>} />
        )}
        {data && data.rows.length > 0 && (
          <>
            <ul className="space-y-3">
              {data.rows.map((e) => (
                <li key={e.id} className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-semibold text-ink-900">{e.name} <span className="font-normal text-ink-600">· {e.phone}</span></p>
                      <p className="text-sm text-ink-600">
                        {TRIP_TYPE_LABELS[e.trip_type] ?? e.trip_type}: {[e.pickup_city, e.drop_city].filter(Boolean).join(' to ') || 'route not given'}
                        {e.journey_date ? ` · ${e.journey_date}` : ''} · {e.passengers} pax
                      </p>
                      {e.message && <p className="mt-1 text-sm text-ink-700">{e.message}</p>}
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      <ToneBadge tone={toneFor(e.status)}>{e.status}</ToneBadge>
                      {e.overdue && <ToneBadge tone="danger">Follow-up overdue</ToneBadge>}
                      <ToneBadge tone="neutral">{SOURCE_LABELS[e.source] ?? e.source}</ToneBadge>
                    </div>
                  </div>
                  <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-1 text-sm text-ink-600">
                    {e.quoted_amount != null && e.quoted_amount !== '' && <span>Quoted {inr(e.quoted_amount)}</span>}
                    {e.follow_up_date && <span>Follow up {e.follow_up_date}</span>}
                    {e.status === 'lost' && e.lost_reason && <span>Lost: {e.lost_reason}</span>}
                    {e.status === 'converted' && e.converted_booking_id && (
                      <Link to={`/app/admin/bookings/${e.converted_booking_id}`} className="font-medium text-brand-700 hover:underline">View booking</Link>
                    )}
                    {e.status !== 'converted' && (
                      <span className="ml-auto flex gap-4">
                        <button type="button" onClick={() => openEdit(e)} className="font-medium text-brand-700 hover:underline" aria-label={`Edit enquiry from ${e.name}`}>Edit</button>
                        {e.status !== 'lost' && (
                          <Link to={`/app/admin/bookings/new?enquiry=${e.id}`} className="font-medium text-brand-700 hover:underline" aria-label={`Convert enquiry from ${e.name} to a booking`}>Convert to booking</Link>
                        )}
                      </span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
            {totalPages > 1 && (
              <nav className="mt-4 flex items-center justify-between" aria-label="Pagination">
                <Button variant="secondary" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>Previous</Button>
                <span className="text-sm text-ink-600">Page {page} of {totalPages}</span>
                <Button variant="secondary" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))}>Next</Button>
              </nav>
            )}
          </>
        )}
      </div>

      <BottomSheet open={sheet} title={editId ? 'Edit enquiry' : 'New enquiry'} onClose={() => (saving ? undefined : setSheet(false))}>
        <form onSubmit={submit} className="space-y-4" noValidate>
          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Name" htmlFor="enq-name"><input id="enq-name" className={INPUT_CLASS} value={form.name} onChange={set('name')} disabled={saving} /></FormField>
            <FormField label="Mobile number" htmlFor="enq-phone"><input id="enq-phone" type="tel" className={INPUT_CLASS} value={form.phone} onChange={set('phone')} disabled={saving} /></FormField>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Email (optional)" htmlFor="enq-email"><input id="enq-email" type="email" className={INPUT_CLASS} value={form.email} onChange={set('email')} disabled={saving} /></FormField>
            <FormField label="Source" htmlFor="enq-source">
              <select id="enq-source" className={INPUT_CLASS} value={form.source} onChange={set('source')} disabled={saving}>
                {Object.entries(SOURCE_LABELS).filter(([k]) => k !== 'online').map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </select>
            </FormField>
          </div>
          <div className="grid gap-4 sm:grid-cols-3">
            <FormField label="Trip type" htmlFor="enq-trip">
              <select id="enq-trip" className={INPUT_CLASS} value={form.trip_type} onChange={set('trip_type')} disabled={saving}>
                {Object.entries(TRIP_TYPE_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </select>
            </FormField>
            <FormField label="Pickup city" htmlFor="enq-from"><input id="enq-from" className={INPUT_CLASS} value={form.pickup_city} onChange={set('pickup_city')} disabled={saving} /></FormField>
            <FormField label="Drop city" htmlFor="enq-to"><input id="enq-to" className={INPUT_CLASS} value={form.drop_city} onChange={set('drop_city')} disabled={saving} /></FormField>
          </div>
          <div className="grid gap-4 sm:grid-cols-3">
            <FormField label="Journey date" htmlFor="enq-date"><input id="enq-date" type="date" className={INPUT_CLASS} value={form.journey_date} onChange={set('journey_date')} disabled={saving} /></FormField>
            <FormField label="Passengers" htmlFor="enq-pax"><input id="enq-pax" type="number" min={1} className={INPUT_CLASS} value={form.passengers} onChange={set('passengers')} disabled={saving} /></FormField>
            <FormField label="Quoted amount (optional)" htmlFor="enq-quote"><input id="enq-quote" type="number" min={0} className={INPUT_CLASS} value={form.quoted_amount} onChange={set('quoted_amount')} disabled={saving} /></FormField>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Follow-up date" htmlFor="enq-fu"><input id="enq-fu" type="date" className={INPUT_CLASS} value={form.follow_up_date} onChange={set('follow_up_date')} disabled={saving} /></FormField>
            <FormField label="Status" htmlFor="enq-status">
              <select id="enq-status" className={INPUT_CLASS} value={form.status} onChange={set('status')} disabled={saving}>
                <option value="new">New</option>
                <option value="contacted">Contacted</option>
                <option value="quoted">Quoted</option>
                <option value="lost">Lost</option>
              </select>
            </FormField>
          </div>
          {form.status === 'lost' && (
            <FormField label="Why was it lost?" htmlFor="enq-lost"><input id="enq-lost" className={INPUT_CLASS} value={form.lost_reason} onChange={set('lost_reason')} disabled={saving} /></FormField>
          )}
          <FormField label="Message / requirements" htmlFor="enq-msg"><textarea id="enq-msg" rows={3} className={INPUT_CLASS} value={form.message} onChange={set('message')} disabled={saving} /></FormField>
          {formError && <div role="alert" className="text-sm font-medium text-danger-600">{formError}</div>}
          <div className="flex gap-3">
            <Button type="submit" loading={saving} fullWidth>Save enquiry</Button>
            <Button type="button" variant="secondary" onClick={() => setSheet(false)} disabled={saving} fullWidth>Cancel</Button>
          </div>
        </form>
      </BottomSheet>
    </div>
  );
}
