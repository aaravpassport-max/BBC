import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getAdminLeads, ApiError } from '../../lib/api';
import type { AdminLeadRow } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';

const PILLS: [string, string][] = [
  ['', 'All'],
  ['sent', '⏳ Sent'],
  ['accepted', '✅ Accepted'],
  ['rejected', '❌ Rejected'],
  ['expired', '⌛ Expired'],
  ['lost_to_other_vendor', '🔁 Lost to Other Vendor'],
];

const STATUS_OPTIONS = [
  ['sent', 'Sent'],
  ['accepted', 'Accepted'],
  ['rejected', 'Rejected'],
  ['expired', 'Expired'],
  ['lost_to_other_vendor', 'Lost to Other Vendor'],
];

function statusBadgeClass(status: string) {
  switch (status) {
    case 'sent':
      return 'bg-amber-50 text-amber-700';
    case 'accepted':
      return 'bg-success-50 text-success-700';
    case 'rejected':
      return 'bg-danger-50 text-danger-700';
    case 'expired':
      return 'bg-ink-100 text-ink-500';
    case 'lost_to_other_vendor':
      return 'bg-violet-50 text-violet-700';
    default:
      return 'bg-ink-100 text-ink-600';
  }
}

function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

function fmtDateTime(s: string | null) {
  if (!s) return '—';
  const d = new Date(s.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}

function countdown(seconds: number | null) {
  if (seconds === null) return null;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')} left`;
}

/**
 * Rebuild of admin/pages/leads.php — read-only lead monitor: 5 KPI
 * tiles, status pills, filter + search, paginated table. The
 * "Accepted"/"Fees Collected" KPIs intentionally filter on
 * status='accepted' (matching includes/app-admin-leads-api.php,
 * which preserves the legacy page's own already-fixed root-cause
 * correction — status='assigned' is never actually written anywhere).
 */
export function AdminLeadsPage() {
  const [status, setStatus] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  const [rows, setRows] = useState<AdminLeadRow[] | null>(null);
  const [total, setTotal] = useState(0);
  const [perPage, setPerPage] = useState(30);
  const [kpis, setKpis] = useState<{ total_leads: number; pending: number; accepted: number; rejected: number; fees_collected: number } | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (s: string, q: string, p: number) => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminLeads({ status: s || undefined, s: q || undefined, page: p });
      setRows(res.rows);
      setTotal(res.total);
      setPerPage(res.per_page);
      setKpis(res.kpis);
    } catch (err) {
      setError(
        err instanceof ApiError && err.code === 'forbidden'
          ? "You don't have permission to view leads."
          : err instanceof ApiError
          ? err.message
          : 'Could not load leads. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(status, search, page);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, page]);

  function applyFilters() {
    setPage(1);
    load(status, search, 1);
  }

  const totalPages = Math.max(1, Math.ceil(total / perPage));

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div>
        <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">📤 Lead monitor</h1>
        <p className="text-sm text-ink-500">Every lead sent to a vendor, its status, and the fee it earned.</p>
      </div>

      {loading && (
        <div className="mt-6 space-y-6" aria-busy="true" aria-label="Loading leads">
          <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-96 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={() => load(status, search, page)} />
        </div>
      )}

      {!loading && !error && kpis && (
        <>
          <div className="mt-6 grid gap-4 sm:grid-cols-3 lg:grid-cols-5">
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Total leads</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{kpis.total_leads}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Pending</p>
              <p className="mt-2 text-xl font-bold text-amber-600">{kpis.pending}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Assigned</p>
              <p className="mt-2 text-xl font-bold text-success-600">{kpis.accepted}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Rejected</p>
              <p className="mt-2 text-xl font-bold text-danger-600">{kpis.rejected}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Fees collected</p>
              <p className="mt-2 text-xl font-bold text-violet-600">{currency(kpis.fees_collected)}</p>
            </div>
          </div>

          <div className="mt-6 flex flex-wrap items-end gap-3">
            <div className="flex-1 min-w-[240px]">
              <label htmlFor="lead-search" className="block text-sm font-medium text-ink-700">
                Search
              </label>
              <input
                id="lead-search"
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && applyFilters()}
                placeholder="Booking#, client, vendor..."
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="lead-status" className="block text-sm font-medium text-ink-700">
                Status
              </label>
              <select
                id="lead-status"
                value={status}
                onChange={(e) => {
                  setStatus(e.target.value);
                  setPage(1);
                }}
                className="mt-1.5 rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              >
                <option value="">All status</option>
                {STATUS_OPTIONS.map(([v, l]) => (
                  <option key={v} value={v}>
                    {l}
                  </option>
                ))}
              </select>
            </div>
            <Button onClick={applyFilters}>Filter</Button>
            <span className="ml-auto text-sm text-ink-500">{total} leads</span>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {PILLS.map(([v, l]) => (
              <button
                key={v}
                type="button"
                onClick={() => {
                  setStatus(v);
                  setPage(1);
                }}
                className={`rounded-full px-3 py-1.5 text-xs font-medium ${
                  status === v ? 'bg-brand-600 text-white' : 'bg-ink-100 text-ink-600 hover:bg-ink-200'
                }`}
              >
                {l}
              </button>
            ))}
          </div>

          <div className="mt-4 hidden overflow-x-auto rounded-xl border border-ink-100 lg:block">
            <table className="w-full text-sm">
              <thead className="bg-ink-50 text-left text-xs font-medium uppercase tracking-wide text-ink-500">
                <tr>
                  <th className="px-4 py-3">Lead ID</th>
                  <th className="px-4 py-3">Booking</th>
                  <th className="px-4 py-3">Route</th>
                  <th className="px-4 py-3">Client</th>
                  <th className="px-4 py-3">Vendor</th>
                  <th className="px-4 py-3">Lead fee</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Sent</th>
                  <th className="px-4 py-3">Expires</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {rows && rows.length > 0 ? (
                  rows.map((l) => (
                    <tr key={l.id}>
                      <td className="px-4 py-3 font-mono text-xs text-ink-700">#{l.id}</td>
                      <td className="px-4 py-3 text-xs text-ink-600">
                        {l.booking_number && l.booking_id ? (
                          <Link to={`/app/admin/bookings/${l.booking_id}`} className="font-medium text-brand-700 hover:text-brand-800">
                            {l.booking_number}
                          </Link>
                        ) : (
                          l.booking_number ?? '—'
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-ink-700">
                        <p className="font-medium">
                          {l.pickup_city ?? ''} → {l.drop_city ?? ''}
                        </p>
                        <p className="text-ink-400">
                          {l.journey_date ? new Date(l.journey_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : ''}
                          {l.trip_type ? ` · ${l.trip_type.replace(/_/g, ' ')}` : ''}
                        </p>
                      </td>
                      <td className="px-4 py-3 text-ink-700">{l.client_name ?? '—'}</td>
                      <td className="px-4 py-3">
                        <p className="font-medium text-ink-800">{l.business_name ?? '—'}</p>
                        <p className="text-xs text-ink-400">{l.vendor_phone ?? ''}</p>
                      </td>
                      <td className="px-4 py-3 font-semibold text-ink-900">{currency(l.fee_amount)}</td>
                      <td className="px-4 py-3">
                        <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ${statusBadgeClass(l.status)}`}>
                          {l.status.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-ink-500">{fmtDateTime(l.sent_at)}</td>
                      <td className="px-4 py-3 text-xs">
                        {l.expires_seconds_left !== null ? (
                          <span className="font-medium text-amber-600">{countdown(l.expires_seconds_left)}</span>
                        ) : (
                          <span className="text-ink-400">{fmtDateTime(l.expires_at)}</span>
                        )}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={9}>
                      <EmptyState title="No leads found" description="Nothing matches the current filters." />
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {rows && rows.length > 0 ? (
            <div className="mt-4 space-y-3 lg:hidden">
              {rows.map((l) => (
                <div key={l.id} className="rounded-xl border border-ink-100 bg-white p-4">
                  <div className="flex items-start justify-between gap-3">
                    <span className="font-mono text-xs text-ink-700">#{l.id}</span>
                    <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ${statusBadgeClass(l.status)}`}>
                      {l.status.replace(/_/g, ' ')}
                    </span>
                  </div>

                  <p className="mt-2 text-sm font-medium text-ink-900">
                    {l.pickup_city ?? ''} → {l.drop_city ?? ''}
                  </p>
                  <p className="text-xs text-ink-400">
                    {l.journey_date ? new Date(l.journey_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : ''}
                    {l.trip_type ? ` · ${l.trip_type.replace(/_/g, ' ')}` : ''}
                  </p>

                  {l.booking_number && l.booking_id ? (
                    <Link to={`/app/admin/bookings/${l.booking_id}`} className="mt-1 inline-block text-xs font-medium text-brand-700 hover:text-brand-800">
                      {l.booking_number}
                    </Link>
                  ) : (
                    <p className="mt-1 text-xs text-ink-500">{l.booking_number ?? '—'}</p>
                  )}

                  <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
                    <span className="text-ink-400">Client</span>
                    <span className="text-right text-ink-700">{l.client_name ?? '—'}</span>
                    <span className="text-ink-400">Vendor</span>
                    <span className="text-right text-ink-700">
                      {l.business_name ?? '—'}
                      {l.vendor_phone ? ` (${l.vendor_phone})` : ''}
                    </span>
                    <span className="text-ink-400">Lead fee</span>
                    <span className="text-right font-semibold text-ink-900">{currency(l.fee_amount)}</span>
                    <span className="text-ink-400">Sent</span>
                    <span className="text-right text-ink-500">{fmtDateTime(l.sent_at)}</span>
                    <span className="text-ink-400">Expires</span>
                    <span className="text-right">
                      {l.expires_seconds_left !== null ? (
                        <span className="font-medium text-amber-600">{countdown(l.expires_seconds_left)}</span>
                      ) : (
                        <span className="text-ink-400">{fmtDateTime(l.expires_at)}</span>
                      )}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-4 lg:hidden">
              <EmptyState title="No leads found" description="Nothing matches the current filters." />
            </div>
          )}

          <div className="mt-4 flex items-center justify-between">
            <p className="text-xs text-ink-400">
              Page {page} of {totalPages}
            </p>
            <div className="flex gap-2">
              <Button variant="secondary" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                Previous
              </Button>
              <Button variant="secondary" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
