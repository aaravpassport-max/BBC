import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react';
import { ApiError } from '../../lib/api';
import {
  createTask, createTeamMember, deleteRegion, getAdminTasks, getDirectory, getRegions, getTeam, resetTeamPassword, saveRegion,
  updateTask, updateTeamMember, type DirectoryUser, type Region, type Task, type TeamMember, type TeamModule,
} from '../../lib/api-team';
import { startImpersonation } from '../../lib/api-admin-finance';
import { roleLabel } from '../../lib/roles';
import { useToast } from '../../context/ToastContext';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { Button } from '../../components/ui/Button';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { EmptyState } from '../../components/ui/EmptyState';
import { Pagination, paginate } from '../../components/ui/Pagination';
import { FormField, INPUT_CLASS } from '../vendor-mkt/vendor-mkt-shared';

const TEAM_PAGE_SIZE = 15;

type TabKey = 'team' | 'regions' | 'tasks' | 'viewas';
const TABS: { key: TabKey; label: string }[] = [
  { key: 'team', label: 'Team' }, { key: 'regions', label: 'Regions' }, { key: 'tasks', label: 'Tasks' }, { key: 'viewas', label: 'View as' },
];
const errMsg = (e: unknown, fallback: string) => (e instanceof ApiError ? e.message : fallback);

// TRACE: route /app/admin/team (administrators only) → tabs Team / Regions / Tasks / View as, each loading its own data.
//        Preconditions: RequireAdmin passed. Postconditions: one tab mounted at a time, switching never loses saved data
//        (re-fetched on mount). Edge cases: load failure (ErrorBanner + retry), empty lists (EmptyState).
export function AdminTeamPage() {
  const [tab, setTab] = useState<TabKey>('team');
  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Team &amp; access</h1>
      <p className="mt-1 text-sm text-ink-600">Create regional managers and staff, choose exactly what each can do, define regions, assign tasks and view the app as any user.</p>
      <div role="tablist" aria-label="Team sections" className="mt-5 flex gap-1 overflow-x-auto border-b border-ink-100">
        {TABS.map((t) => (
          <button
            key={t.key} type="button" role="tab" aria-selected={tab === t.key} id={`team-tab-${t.key}`} aria-controls={`team-panel-${t.key}`}
            onClick={() => setTab(t.key)}
            className={`whitespace-nowrap px-4 py-2.5 text-sm font-medium focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600 ${tab === t.key ? 'border-b-2 border-brand-600 text-brand-700' : 'text-ink-600 hover:text-ink-900'}`}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div role="tabpanel" id={`team-panel-${tab}`} aria-labelledby={`team-tab-${tab}`} className="mt-6">
        {tab === 'team' && <TeamTab />}
        {tab === 'regions' && <RegionsTab />}
        {tab === 'tasks' && <TasksTab />}
        {tab === 'viewas' && <ViewAsTab />}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ Team */

// TRACE: Team tab mount → GET /admin/team → list with Add / Edit / Send reset link. Postconditions: after a save the list is
//        re-fetched so what shows is what the server stored. Edge cases: no members (EmptyState), load failure (retry).
function TeamTab() {
  const toast = useToast();
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [modules, setModules] = useState<TeamModule[]>([]);
  const [regions, setRegions] = useState<Region[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sheet, setSheet] = useState<{ open: boolean; member: TeamMember | null; nonce: number }>({ open: false, member: null, nonce: 0 });

  // Root-cause fix: this list has always fetched and rendered every team
  // member with no way to find one — the same class of gap fixed on the
  // Cities screen (see Pagination.tsx's doc comment). Purely client-side
  // over the already-loaded list; page resets to 1 whenever a filter
  // narrows the results.
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | 'ridego_regional_manager' | 'ridego_staff'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'disabled'>('all');
  const [page, setPage] = useState(1);

  // TRACE: mount/retry/after save → fetches the team → stores members, module catalogue and regions. Edge: failure → error text.
  const load = useCallback(async () => {
    setError(null);
    try {
      const r = await getTeam();
      setMembers(r.members); setModules(r.modules); setRegions(r.regions);
    } catch (e) {
      setError(errMsg(e, 'Could not load the team.'));
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const filteredMembers = useMemo(() => {
    const q = search.trim().toLowerCase();
    return members.filter((m) => {
      if (q && !`${m.name} ${m.email} ${m.phone}`.toLowerCase().includes(q)) return false;
      if (roleFilter !== 'all' && m.role !== roleFilter) return false;
      if (statusFilter === 'active' && !m.active) return false;
      if (statusFilter === 'disabled' && m.active) return false;
      return true;
    });
  }, [members, search, roleFilter, statusFilter]);
  useEffect(() => { setPage(1); }, [search, roleFilter, statusFilter]);
  const { pageItems: visibleMembers, pageCount, page: currentPage } = paginate(filteredMembers, page, TEAM_PAGE_SIZE);

  // TRACE: "Add team member"/"Edit" click → opens the sheet with a fresh form (nonce) → void.
  const openSheet = (member: TeamMember | null) => setSheet((s) => ({ open: true, member, nonce: s.nonce + 1 }));
  // TRACE: sheet close/save → closes the sheet, keeping the member for the exit animation → void.
  const closeSheet = () => setSheet((s) => ({ ...s, open: false }));
  // TRACE: "Send password reset" click → POST reset → toast success or the server message. Edge: mail failure → error toast.
  const sendReset = async (m: TeamMember) => {
    try { await resetTeamPassword(m.id); toast.show(`Password reset link sent to ${m.email}.`, 'success'); }
    catch (e) { toast.show(errMsg(e, 'Could not send the reset email.'), 'error'); }
  };

  if (loading) return <Skeleton className="h-40 w-full rounded-xl" />;
  return (
    <div>
      {error && <ErrorBanner message={error} onRetry={load} />}
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold text-ink-900">Regional managers &amp; staff</h2>
        <Button size="sm" onClick={() => openSheet(null)}>Add team member</Button>
      </div>
      {members.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-3">
          <div className="w-full flex-1 sm:min-w-[16rem]">
            <label htmlFor="tm-search" className="sr-only">Search team members</label>
            <input id="tm-search" placeholder="Search by name, email or phone" className={INPUT_CLASS} value={search} onChange={(e) => setSearch(e.target.value)} autoComplete="off" />
          </div>
          <div className="w-full sm:w-52">
            <label htmlFor="tm-role-filter" className="sr-only">Role</label>
            <select id="tm-role-filter" className={INPUT_CLASS} value={roleFilter} onChange={(e) => setRoleFilter(e.target.value as typeof roleFilter)}>
              <option value="all">All roles</option>
              <option value="ridego_regional_manager">Regional Manager</option>
              <option value="ridego_staff">Staff</option>
            </select>
          </div>
          <div className="w-full sm:w-44">
            <label htmlFor="tm-status-filter" className="sr-only">Status</label>
            <select id="tm-status-filter" className={INPUT_CLASS} value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}>
              <option value="all">All statuses</option>
              <option value="active">Active</option>
              <option value="disabled">Disabled</option>
            </select>
          </div>
        </div>
      )}
      {members.length === 0 ? (
        <div className="mt-4"><EmptyState title="No team members yet" description="Add a regional manager or a staff member and choose what they can access." /></div>
      ) : filteredMembers.length === 0 ? (
        <div className="mt-4"><EmptyState title="No team members match your filters" description="Try a different search term or clear the filters above." /></div>
      ) : (
        <ul className="mt-4 space-y-3">
          {visibleMembers.map((m) => (
            <li key={m.id} className="rounded-xl border border-ink-100 p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="font-semibold text-ink-900">{m.name} <span className="ml-1 rounded-full bg-ink-100 px-2 py-0.5 text-xs font-medium text-ink-700">{m.role === 'ridego_regional_manager' ? 'Regional Manager' : 'Staff'}</span>{!m.active && <span className="ml-1 rounded-full bg-danger-50 px-2 py-0.5 text-xs font-medium text-danger-600">Disabled</span>}</p>
                  <p className="text-sm text-ink-600">{m.email}{m.phone ? ` · ${m.phone}` : ''}</p>
                  <p className="mt-1 text-xs text-ink-600">
                    Access: {m.modules.length ? m.modules.map((k) => modules.find((x) => x.key === k)?.label ?? k).join(', ') : 'none'}
                  </p>
                  {m.role === 'ridego_regional_manager' && (
                    <p className="text-xs text-ink-600">Regions: {m.region_scope === 'all' ? 'All regions (authorised)' : m.region_ids.map((id) => regions.find((r) => r.id === id)?.name ?? `#${id}`).join(', ') || 'none assigned'}</p>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="secondary" onClick={() => openSheet(m)} aria-label={`Edit ${m.name}`}>Edit</Button>
                  <Button size="sm" variant="secondary" onClick={() => sendReset(m)} aria-label={`Send password reset link to ${m.name}`}>Send reset link</Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
      {filteredMembers.length > 0 && (
        <Pagination page={currentPage} pageCount={pageCount} totalItems={filteredMembers.length} pageSize={TEAM_PAGE_SIZE} onPageChange={setPage} />
      )}
      <BottomSheet open={sheet.open} title={sheet.member ? 'Edit team member' : 'Add team member'} onClose={closeSheet}>
        <MemberForm key={sheet.nonce} member={sheet.member} modules={modules} regions={regions} onCancel={closeSheet}
          onSaved={async () => { closeSheet(); toast.show(sheet.member ? 'Team member updated.' : 'Team member created.', 'success'); await load(); }} />
      </BottomSheet>
    </div>
  );
}

// TRACE: member sheet → controlled form (name, email, phone, role, password, module checkboxes, region scope) → create or update →
//        onSaved(). Preconditions: modules/regions loaded. Postconditions: fields keep values on failure; button disabled while saving
//        (no double submit); server message shown inline. Edge cases: blank name/email (client check), duplicate email (server 409 text),
//        regional-manager-only fields hidden for staff.
function MemberForm({ member, modules, regions, onCancel, onSaved }: { member: TeamMember | null; modules: TeamModule[]; regions: Region[]; onCancel: () => void; onSaved: () => void }) {
  const [name, setName] = useState(member?.name ?? '');
  const [email, setEmail] = useState(member?.email ?? '');
  const [phone, setPhone] = useState(member?.phone ?? '');
  const [role, setRole] = useState<string>(member?.role ?? 'ridego_staff');
  const [password, setPassword] = useState('');
  const [mods, setMods] = useState<string[]>(member?.modules ?? (member ? [] : []));
  const [scope, setScope] = useState<'assigned' | 'all'>(member?.region_scope ?? 'assigned');
  const [regionIds, setRegionIds] = useState<number[]>(member?.region_ids ?? []);
  const [active, setActive] = useState(member?.active ?? true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [regionFilter, setRegionFilter] = useState('');
  const toggle = <T,>(list: T[], v: T) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);
  // Root-cause fix: this checkbox list rendered every region with no way
  // to find one, same gap as the Cities/Team lists — see Pagination.tsx's
  // doc comment (a checkbox list of this length doesn't paginate well, so
  // a search filter is the right shape here rather than pages). A region
  // already selected stays visible above the filtered set so unchecking
  // it never requires first guessing the right search term.
  const shownRegions = useMemo(() => {
    const q = regionFilter.trim().toLowerCase();
    if (!q) return regions;
    return regions.filter((r) => r.name.toLowerCase().includes(q) || regionIds.includes(r.id));
  }, [regions, regionFilter, regionIds]);

  // TRACE: submit → validates → POST/PUT → onSaved(). Edge: saving already (ignored), validation failure (inline message, no request).
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    if (name.trim() === '') { setError('Enter the name.'); return; }
    if (!member && !/^\S+@\S+\.\S+$/.test(email.trim())) { setError('Enter a valid email address.'); return; }
    if (!member && password !== '' && password.length < 10) { setError('Password must be at least 10 characters (or leave it blank to email a set-password link).'); return; }
    setSaving(true); setError(null);
    const body = { name: name.trim(), email: email.trim(), phone: phone.trim(), role, password, modules: mods, region_ids: role === 'ridego_regional_manager' ? regionIds : [], region_scope: role === 'ridego_regional_manager' ? scope : ('assigned' as const), active };
    try {
      if (member) await updateTeamMember(member.id, body); else await createTeamMember(body);
      onSaved();
    } catch (err) {
      setError(errMsg(err, 'Could not save. Please try again.'));
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <FormField label="Full name *" htmlFor="tm-name"><input id="tm-name" className={INPUT_CLASS} value={name} onChange={(e) => setName(e.target.value)} disabled={saving} autoComplete="off" /></FormField>
      <FormField label={member ? 'Email (cannot be changed)' : 'Email *'} htmlFor="tm-email"><input id="tm-email" type="email" className={INPUT_CLASS} value={email} onChange={(e) => setEmail(e.target.value)} disabled={saving || !!member} autoComplete="off" /></FormField>
      <FormField label="Phone (optional)" htmlFor="tm-phone"><input id="tm-phone" type="tel" className={INPUT_CLASS} value={phone} onChange={(e) => setPhone(e.target.value)} disabled={saving} /></FormField>
      {!member && (
        <>
          <FormField label="Role *" htmlFor="tm-role">
            <select id="tm-role" className={INPUT_CLASS} value={role} onChange={(e) => setRole(e.target.value)} disabled={saving}>
              <option value="ridego_staff">Staff</option><option value="ridego_regional_manager">Regional Manager</option>
            </select>
          </FormField>
          <FormField label="Password (optional)" htmlFor="tm-pw" hint="Leave blank to email them a link to set their own password.">
            <input id="tm-pw" type="password" className={INPUT_CLASS} value={password} onChange={(e) => setPassword(e.target.value)} disabled={saving} autoComplete="new-password" />
          </FormField>
        </>
      )}
      <fieldset>
        <legend className="text-sm font-medium text-ink-800">Access (nothing is granted by default)</legend>
        <div className="mt-2 grid gap-2 sm:grid-cols-2">
          {modules.map((m) => (
            <label key={m.key} className="flex items-start gap-2 rounded-lg border border-ink-100 p-2.5 text-sm">
              <input type="checkbox" className="mt-0.5" checked={mods.includes(m.key)} onChange={() => setMods((l) => toggle(l, m.key))} disabled={saving} />
              <span><span className="font-medium text-ink-900">{m.label}</span><span className="block text-xs text-ink-600">{m.description}</span></span>
            </label>
          ))}
        </div>
      </fieldset>
      {role === 'ridego_regional_manager' && (
        <fieldset>
          <legend className="text-sm font-medium text-ink-800">Regions</legend>
          <label className="mt-2 flex items-center gap-2 text-sm"><input type="radio" name="tm-scope" checked={scope === 'assigned'} onChange={() => setScope('assigned')} disabled={saving} /> Only the regions selected below</label>
          <label className="mt-1 flex items-center gap-2 text-sm"><input type="radio" name="tm-scope" checked={scope === 'all'} onChange={() => setScope('all')} disabled={saving} /> All regions (explicit authorisation)</label>
          {scope === 'assigned' && (
            <>
              {regions.length > 5 && (
                <input aria-label="Filter regions" placeholder="Filter regions" className={`${INPUT_CLASS} mt-2`} value={regionFilter} onChange={(e) => setRegionFilter(e.target.value)} disabled={saving} />
              )}
              <div className="mt-2 grid max-h-56 gap-2 overflow-y-auto sm:grid-cols-2">
                {regions.length === 0 && <p className="text-sm text-ink-600">No regions yet — create one in the Regions tab first.</p>}
                {regions.length > 0 && shownRegions.length === 0 && <p className="text-sm text-ink-600">No regions match &ldquo;{regionFilter}&rdquo;.</p>}
                {shownRegions.map((r) => (
                  <label key={r.id} className="flex items-center gap-2 rounded-lg border border-ink-100 p-2.5 text-sm">
                    <input type="checkbox" checked={regionIds.includes(r.id)} onChange={() => setRegionIds((l) => toggle(l, r.id))} disabled={saving} /> {r.name}
                  </label>
                ))}
              </div>
            </>
          )}
        </fieldset>
      )}
      {member && <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} disabled={saving} /> Account enabled (untick to block sign-in)</label>}
      {error && <p role="alert" className="text-sm font-medium text-danger-600">{error}</p>}
      <div className="flex justify-end gap-2">
        <Button type="button" variant="secondary" onClick={onCancel} disabled={saving}>Cancel</Button>
        <Button type="submit" loading={saving}>{member ? 'Save changes' : 'Create member'}</Button>
      </div>
    </form>
  );
}

/* ------------------------------------------------------------------ Regions */

// TRACE: Regions tab mount → GET /admin/regions → list with Add / Edit / Delete (confirm naming the region).
//        Postconditions: list re-fetched after save/delete. Edge cases: empty, load failure, delete failure (toast).
function RegionsTab() {
  const toast = useToast();
  const [data, setData] = useState<{ regions: Region[]; states: string[]; cities: { name: string; state: string }[] } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [sheet, setSheet] = useState<{ open: boolean; region: Region | null; nonce: number }>({ open: false, region: null, nonce: 0 });
  const [del, setDel] = useState<Region | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  // TRACE: mount/after save → fetch regions and pickers → state. Edge: failure → error banner.
  const load = useCallback(async () => {
    setError(null);
    try { setData(await getRegions()); } catch (e) { setError(errMsg(e, 'Could not load regions.')); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  const filteredRegions = useMemo(() => {
    if (!data) return [];
    const q = search.trim().toLowerCase();
    if (!q) return data.regions;
    return data.regions.filter((r) => `${r.name} ${r.states.join(' ')} ${r.resolved_cities.join(' ')}`.toLowerCase().includes(q));
  }, [data, search]);
  useEffect(() => { setPage(1); }, [search]);
  const { pageItems: visibleRegions, pageCount, page: currentPage } = paginate(filteredRegions, page, TEAM_PAGE_SIZE);
  // TRACE: confirm delete → POST delete → toast + reload. Edge: failure keeps the dialog closed and shows an error toast.
  const confirmDelete = async () => {
    if (!del || deleting) return;
    setDeleting(true);
    try { await deleteRegion(del.id); toast.show(`Region "${del.name}" deleted.`, 'success'); setDel(null); await load(); }
    catch (e) { toast.show(errMsg(e, 'Could not delete the region.'), 'error'); }
    finally { setDeleting(false); }
  };
  if (!data) return error ? <ErrorBanner message={error} onRetry={load} /> : <Skeleton className="h-40 w-full rounded-xl" />;
  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold text-ink-900">Regions</h2>
        <Button size="sm" onClick={() => setSheet((s) => ({ open: true, region: null, nonce: s.nonce + 1 }))}>Add region</Button>
      </div>
      {data.regions.length > 5 && (
        <div className="mt-4">
          <label htmlFor="region-search" className="sr-only">Search regions</label>
          <input id="region-search" placeholder="Search regions by name, state or city" className={INPUT_CLASS} value={search} onChange={(e) => setSearch(e.target.value)} autoComplete="off" />
        </div>
      )}
      {data.regions.length === 0 ? (
        <div className="mt-4"><EmptyState title="No regions yet" description="A region is a set of states or cities. Assign regions to a Regional Manager to limit them to bookings picked up there." /></div>
      ) : filteredRegions.length === 0 ? (
        <div className="mt-4"><EmptyState title="No regions match your search" description="Try a different search term." /></div>
      ) : (
        <ul className="mt-4 space-y-3">
          {visibleRegions.map((r) => (
            <li key={r.id} className="rounded-xl border border-ink-100 p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="font-semibold text-ink-900">{r.name} <span className="ml-1 rounded-full bg-ink-100 px-2 py-0.5 text-xs">{r.region_type}</span>{r.status === 'inactive' && <span className="ml-1 rounded-full bg-warning-50 px-2 py-0.5 text-xs text-warning-600">Inactive</span>}</p>
                  <p className="text-xs text-ink-600">{r.states.length ? `States: ${r.states.join(', ')}. ` : ''}Covers {r.resolved_cities.length} cit{r.resolved_cities.length === 1 ? 'y' : 'ies'}: {r.resolved_cities.join(', ') || 'none'}</p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="secondary" onClick={() => setSheet((s) => ({ open: true, region: r, nonce: s.nonce + 1 }))} aria-label={`Edit region ${r.name}`}>Edit</Button>
                  <Button size="sm" variant="secondary" onClick={() => setDel(r)} aria-label={`Delete region ${r.name}`}>Delete</Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
      {filteredRegions.length > 0 && (
        <Pagination page={currentPage} pageCount={pageCount} totalItems={filteredRegions.length} pageSize={TEAM_PAGE_SIZE} onPageChange={setPage} />
      )}
      <BottomSheet open={sheet.open} title={sheet.region ? 'Edit region' : 'Add region'} onClose={() => setSheet((s) => ({ ...s, open: false }))}>
        <RegionForm key={sheet.nonce} region={sheet.region} states={data.states} cities={data.cities} onCancel={() => setSheet((s) => ({ ...s, open: false }))}
          onSaved={async () => { setSheet((s) => ({ ...s, open: false })); toast.show('Region saved.', 'success'); await load(); }} />
      </BottomSheet>
      <ConfirmDialog open={!!del} title={del ? `Delete region "${del.name}"?` : 'Delete region?'} description="Regional managers assigned to it lose this region. Bookings are not affected." confirmLabel="Delete region" confirmVariant="danger" loading={deleting} onConfirm={confirmDelete} onCancel={() => setDel(null)} />
    </div>
  );
}

// TRACE: region sheet → name, type, status, states and cities checkboxes → POST/PUT → onSaved(). Edge: no name / nothing selected
//        (inline message), duplicate name (server 409 text). Fields keep their values on failure.
function RegionForm({ region, states, cities, onCancel, onSaved }: { region: Region | null; states: string[]; cities: { name: string; state: string }[]; onCancel: () => void; onSaved: () => void }) {
  const [name, setName] = useState(region?.name ?? '');
  const [type, setType] = useState(region?.region_type ?? 'state');
  const [status, setStatus] = useState<'active' | 'inactive'>(region?.status ?? 'active');
  const [selStates, setSelStates] = useState<string[]>(region?.states ?? []);
  const [selCities, setSelCities] = useState<string[]>(region?.cities ?? []);
  const [filter, setFilter] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const toggle = (list: string[], v: string) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);
  const shown = useMemo(() => cities.filter((c) => c.name.toLowerCase().includes(filter.toLowerCase())), [cities, filter]);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    if (name.trim() === '') { setError('Enter a region name.'); return; }
    if (selStates.length === 0 && selCities.length === 0) { setError('Choose at least one state or city.'); return; }
    setSaving(true); setError(null);
    try { await saveRegion(region?.id ?? null, { name: name.trim(), region_type: type, states: selStates, cities: selCities, status }); onSaved(); }
    catch (err) { setError(errMsg(err, 'Could not save the region.')); setSaving(false); }
  };
  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <FormField label="Region name *" htmlFor="rg-name"><input id="rg-name" className={INPUT_CLASS} value={name} onChange={(e) => setName(e.target.value)} disabled={saving} autoComplete="off" /></FormField>
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Type" htmlFor="rg-type">
          <select id="rg-type" className={INPUT_CLASS} value={type} onChange={(e) => setType(e.target.value)} disabled={saving}>
            <option value="state">State(s)</option><option value="city">City</option><option value="group">City group</option><option value="custom">Custom</option>
          </select>
        </FormField>
        <FormField label="Status" htmlFor="rg-status">
          <select id="rg-status" className={INPUT_CLASS} value={status} onChange={(e) => setStatus(e.target.value as 'active' | 'inactive')} disabled={saving}>
            <option value="active">Active</option><option value="inactive">Inactive</option>
          </select>
        </FormField>
      </div>
      <fieldset>
        <legend className="text-sm font-medium text-ink-800">States (every configured city in the state is included)</legend>
        <div className="mt-2 grid gap-2 sm:grid-cols-3">
          {states.map((s) => <label key={s} className="flex items-center gap-2 rounded-lg border border-ink-100 p-2 text-sm"><input type="checkbox" checked={selStates.includes(s)} onChange={() => setSelStates((l) => toggle(l, s))} disabled={saving} /> {s}</label>)}
        </div>
      </fieldset>
      <fieldset>
        <legend className="text-sm font-medium text-ink-800">Individual cities</legend>
        <input aria-label="Filter cities" placeholder="Filter cities" className={`${INPUT_CLASS} mt-2`} value={filter} onChange={(e) => setFilter(e.target.value)} disabled={saving} />
        <div className="mt-2 grid max-h-48 gap-2 overflow-y-auto sm:grid-cols-3">
          {shown.map((c) => <label key={c.name} className="flex items-center gap-2 rounded-lg border border-ink-100 p-2 text-sm"><input type="checkbox" checked={selCities.includes(c.name)} onChange={() => setSelCities((l) => toggle(l, c.name))} disabled={saving} /> {c.name}</label>)}
        </div>
      </fieldset>
      {error && <p role="alert" className="text-sm font-medium text-danger-600">{error}</p>}
      <div className="flex justify-end gap-2"><Button type="button" variant="secondary" onClick={onCancel} disabled={saving}>Cancel</Button><Button type="submit" loading={saving}>{region ? 'Save region' : 'Create region'}</Button></div>
    </form>
  );
}

/* ------------------------------------------------------------------ Tasks */

// TRACE: Tasks tab mount → GET /admin/tasks and the team → list with Add / Edit. Postconditions: assignee options are the
//        team members only. Edge cases: no team yet (message), empty list, failure (retry).
function TasksTab() {
  const toast = useToast();
  const [tasks, setTasks] = useState<Task[] | null>(null);
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [sheet, setSheet] = useState<{ open: boolean; task: Task | null; nonce: number }>({ open: false, task: null, nonce: 0 });
  // TRACE: mount/after save → fetch tasks + team → state. Edge: failure → banner.
  const load = useCallback(async () => {
    setError(null);
    try { const [t, m] = await Promise.all([getAdminTasks(), getTeam()]); setTasks(t.tasks); setTeam(m.members); } catch (e) { setError(errMsg(e, 'Could not load tasks.')); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  if (!tasks) return error ? <ErrorBanner message={error} onRetry={load} /> : <Skeleton className="h-40 w-full rounded-xl" />;
  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold text-ink-900">Tasks</h2>
        <Button size="sm" onClick={() => setSheet((s) => ({ open: true, task: null, nonce: s.nonce + 1 }))}>Add task</Button>
      </div>
      {tasks.length === 0 ? <div className="mt-4"><EmptyState title="No tasks yet" description="Assign work to a staff member or regional manager and they will see it on their workspace." /></div> : (
        <ul className="mt-4 space-y-3">
          {tasks.map((t) => (
            <li key={t.id} className="flex flex-wrap items-start justify-between gap-2 rounded-xl border border-ink-100 p-4">
              <div>
                <p className="font-semibold text-ink-900">{t.title} <span className="ml-1 rounded-full bg-ink-100 px-2 py-0.5 text-xs">{t.status.replace('_', ' ')}</span></p>
                <p className="text-sm text-ink-600">For {t.assigned_name || 'unassigned'} · {t.priority} priority{t.due_date ? ` · due ${t.due_date}` : ''}</p>
                {t.description && <p className="mt-1 text-sm text-ink-700">{t.description}</p>}
              </div>
              <Button size="sm" variant="secondary" onClick={() => setSheet((s) => ({ open: true, task: t, nonce: s.nonce + 1 }))} aria-label={`Edit task ${t.title}`}>Edit</Button>
            </li>
          ))}
        </ul>
      )}
      <BottomSheet open={sheet.open} title={sheet.task ? 'Edit task' : 'Add task'} onClose={() => setSheet((s) => ({ ...s, open: false }))}>
        <TaskForm key={sheet.nonce} task={sheet.task} team={team} onCancel={() => setSheet((s) => ({ ...s, open: false }))}
          onSaved={async () => { setSheet((s) => ({ ...s, open: false })); toast.show('Task saved.', 'success'); await load(); }} />
      </BottomSheet>
    </div>
  );
}

// TRACE: task sheet → title, description, assignee, priority, due date, status(edit) → POST/PUT → onSaved().
//        Edge cases: missing title/assignee (inline message), server failure (message, values kept), double submit (ignored).
function TaskForm({ task, team, onCancel, onSaved }: { task: Task | null; team: TeamMember[]; onCancel: () => void; onSaved: () => void }) {
  const [title, setTitle] = useState(task?.title ?? '');
  const [description, setDescription] = useState(task?.description ?? '');
  const [assignee, setAssignee] = useState<number>(task?.assigned_to ?? 0);
  const [priority, setPriority] = useState(task?.priority ?? 'normal');
  const [due, setDue] = useState(task?.due_date ?? '');
  const [status, setStatus] = useState(task?.status ?? 'open');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    if (title.trim() === '') { setError('Enter a task title.'); return; }
    if (!assignee) { setError('Choose who this task is for.'); return; }
    setSaving(true); setError(null);
    const body = { title: title.trim(), description, assigned_to: assignee, priority, due_date: due, status };
    try { if (task) await updateTask(task.id, body); else await createTask(body); onSaved(); }
    catch (err) { setError(errMsg(err, 'Could not save the task.')); setSaving(false); }
  };
  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <FormField label="Title *" htmlFor="tk-title"><input id="tk-title" className={INPUT_CLASS} value={title} onChange={(e) => setTitle(e.target.value)} disabled={saving} autoComplete="off" /></FormField>
      <FormField label="Details (optional)" htmlFor="tk-desc"><textarea id="tk-desc" rows={3} className={INPUT_CLASS} value={description} onChange={(e) => setDescription(e.target.value)} disabled={saving} /></FormField>
      <FormField label="Assign to *" htmlFor="tk-to">
        <select id="tk-to" className={INPUT_CLASS} value={assignee} onChange={(e) => setAssignee(Number(e.target.value))} disabled={saving}>
          <option value={0}>Choose a team member</option>
          {team.map((m) => <option key={m.id} value={m.id}>{m.name} ({m.role === 'ridego_regional_manager' ? 'Regional Manager' : 'Staff'})</option>)}
        </select>
      </FormField>
      <div className="grid gap-4 sm:grid-cols-3">
        <FormField label="Priority" htmlFor="tk-pr"><select id="tk-pr" className={INPUT_CLASS} value={priority} onChange={(e) => setPriority(e.target.value as Task['priority'])} disabled={saving}><option value="low">Low</option><option value="normal">Normal</option><option value="high">High</option></select></FormField>
        <FormField label="Due date (optional)" htmlFor="tk-due"><input id="tk-due" type="date" className={INPUT_CLASS} value={due} onChange={(e) => setDue(e.target.value)} disabled={saving} /></FormField>
        {task && <FormField label="Status" htmlFor="tk-st"><select id="tk-st" className={INPUT_CLASS} value={status} onChange={(e) => setStatus(e.target.value as Task['status'])} disabled={saving}><option value="open">Open</option><option value="in_progress">In progress</option><option value="done">Done</option></select></FormField>}
      </div>
      {error && <p role="alert" className="text-sm font-medium text-danger-600">{error}</p>}
      <div className="flex justify-end gap-2"><Button type="button" variant="secondary" onClick={onCancel} disabled={saving}>Cancel</Button><Button type="submit" loading={saving}>{task ? 'Save task' : 'Create task'}</Button></div>
    </form>
  );
}

/* ------------------------------------------------------------------ View as */

const HOME_FOR: Record<string, string> = { vendor: '/vendor/dashboard', client: '/dashboard', regional_manager: '/team', staff: '/team', driver: '/driver' };
const ROLE_FILTERS = [
  { key: '', label: 'All roles' }, { key: 'vendor', label: 'Vendors (fleet & individual)' }, { key: 'driver', label: 'Drivers' }, { key: 'client', label: 'Clients' },
  { key: 'regional_manager', label: 'Regional Managers' }, { key: 'staff', label: 'Staff' },
];

// TRACE: View as tab → role filter + search (debounced 300ms, stale replies ignored) → matching accounts, each with "View as" →
//        confirm dialog naming the person → POST /admin/impersonate → full page load to that role's home (fresh nonce/cookies).
//        Preconditions: administrator holding the matching impersonation capability. Postconditions: banner with "Return to Admin"
//        shows on the target session; no credentials are ever fetched or displayed. Edge cases: no results, search failure,
//        start failure (message shown in the dialog area), double click (button loading).
function ViewAsTab() {
  const [role, setRole] = useState('');
  const [q, setQ] = useState('');
  const [users, setUsers] = useState<DirectoryUser[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [target, setTarget] = useState<DirectoryUser | null>(null);
  const [starting, setStarting] = useState(false);
  const [startError, setStartError] = useState<string | null>(null);

  // TRACE: role/q change → waits 300ms → fetches the directory; a newer change cancels the older fetch (flag) → users state.
  useEffect(() => {
    let live = true;
    const t = window.setTimeout(() => {
      getDirectory(role, q).then((r) => { if (live) { setUsers(r.users); setError(null); } }).catch((e) => { if (live) setError(errMsg(e, 'Could not search users.')); });
    }, 300);
    return () => { live = false; window.clearTimeout(t); };
  }, [role, q]);

  // TRACE: confirm → POST start → on success full navigation to the role home. Edge: failure → message, stays put.
  const start = async () => {
    if (!target || starting) return;
    setStarting(true); setStartError(null);
    try {
      const r = await startImpersonation(target.id);
      if (r.success === false) { setStartError(r.message || 'Could not start the session.'); setStarting(false); return; }
      window.location.assign(HOME_FOR[target.role] ?? '/');
    } catch (e) { setStartError(errMsg(e, 'Could not start the session.')); setStarting(false); }
  };

  return (
    <div>
      <p className="text-sm text-ink-600">See exactly what a user sees. The session is logged, time-limited and shows a banner with a Return to Admin button. Passwords and payout details cannot be changed while viewing.</p>
      <div className="mt-4 flex flex-wrap gap-3">
        <div className="w-full sm:w-64"><label htmlFor="va-role" className="sr-only">Role</label>
          <select id="va-role" className={INPUT_CLASS} value={role} onChange={(e) => setRole(e.target.value)}>{ROLE_FILTERS.map((r) => <option key={r.key} value={r.key}>{r.label}</option>)}</select></div>
        <div className="w-full flex-1 sm:min-w-[16rem]"><label htmlFor="va-q" className="sr-only">Search users</label>
          <input id="va-q" className={INPUT_CLASS} placeholder="Search by name, email or username" value={q} onChange={(e) => setQ(e.target.value)} autoComplete="off" /></div>
      </div>
      {error && <div className="mt-4"><ErrorBanner message={error} /></div>}
      {users === null && !error ? <Skeleton className="mt-4 h-32 w-full rounded-xl" /> : users && users.length === 0 ? <div className="mt-4"><EmptyState title="No matching accounts" description="Try another role or search term." /></div> : (
        <ul className="mt-4 divide-y divide-ink-100 rounded-xl border border-ink-100">
          {(users ?? []).map((u) => (
            <li key={u.id} className="flex flex-wrap items-center justify-between gap-2 p-3">
              <div><p className="font-medium text-ink-900">{u.name}</p><p className="text-xs text-ink-600">{u.email} · {roleLabel(u.label)}</p></div>
              <Button size="sm" variant="secondary" onClick={() => { setStartError(null); setTarget(u); }} aria-label={`View as ${u.name}`}>View as</Button>
            </li>
          ))}
        </ul>
      )}
      <ConfirmDialog open={!!target} title={target ? `View as ${target.name}?` : 'View as'}
        description={<>You will see the app as this {target ? roleLabel(target.label).toLowerCase() : 'user'} for a limited time. Use “Return to Admin” in the banner to come back.{startError && <span role="alert" className="mt-2 block font-medium text-danger-600">{startError}</span>}</>}
        confirmLabel="Start viewing" loading={starting} onConfirm={start} onCancel={() => setTarget(null)} />
    </div>
  );
}
