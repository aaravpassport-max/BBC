import { cloneElement, isValidElement, useCallback, useEffect, useState } from 'react';
import { getAdminSettings, saveAdminSettings, uploadQrImage, ApiError } from '../../lib/api';
import type {
  AdminSettingsSecretKey,
  AdminSettingsToggleKey,
  AdminSettingsValueKey,
  AdminSettingsSaveRequest,
} from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Button } from '../../components/ui/Button';
import { brand } from '../../lib/brand';
import { BrandingPanel } from '../../components/admin/BrandingPanel';
import { Link } from 'react-router-dom';

type Tab = 'general' | 'branding' | 'payment' | 'sms' | 'whatsapp' | 'maps' | 'booking' | 'marketplace' | 'advanced';

/** Marketplace keys returned and saved by the same values{} round-trip as every other text field. */
type MarketplaceSettingKey = 'lead_assignment_mode' | 'lead_response_window' | 'lead_accept_minutes' | 'lead_max_vendors' | 'impersonation_minutes';
type SettingValueKey = AdminSettingsValueKey | MarketplaceSettingKey;

const TABS: { id: Tab; label: string }[] = [
  { id: 'general', label: '🌐 General' },
  { id: 'branding', label: '🏷️ Branding & business' },
  { id: 'payment', label: '💳 Payment' },
  { id: 'sms', label: '📱 SMS / OTP' },
  { id: 'whatsapp', label: '💬 WhatsApp' },
  { id: 'maps', label: '🗺️ Maps & APIs' },
  { id: 'booking', label: '📋 Booking Rules' },
  { id: 'marketplace', label: '🤝 Marketplace' },
  { id: 'advanced', label: '🔧 Advanced' },
];

/** Every text/number/select/textarea field's default value, used only until the GET response arrives. */
const DEFAULT_VALUES: Record<SettingValueKey, string | number> = {
  platform_name: '',
  platform_tagline: 'Safe, Reliable & Affordable Cab Booking',
  admin_email: '',
  support_phone: '',
  support_whatsapp: '',
  invoice_company_name: '',
  invoice_company_address: '',
  invoice_gstin: '',
  invoice_footer_note: '',
  currency: 'INR',
  meta_title: '',
  meta_description: '',
  bank_name: '',
  bank_account: '',
  bank_ifsc: '',
  bank_holder: '',
  upi_id: '',
  upi_qr_url: '',
  gst_percent: 5,
  otp_expiry_minutes: 10,
  sms_provider: 'textlocal',
  sms_sender_id: 'RIDEGO',
  twilio_from: '',
  booking_advance_hours: 2,
  booking_max_days: 90,
  payment_deadline_hours: 5,
  cancellation_free_hours: 24,
  min_wallet_balance: 200,
  booking_closure_dispute_hours: 0,
  lead_assignment_mode: 'compare',
  lead_response_window: 15,
  lead_accept_minutes: 10,
  lead_max_vendors: 5,
  impersonation_minutes: 30,
  night_hours_start: '22:00',
  night_hours_end: '06:00',
  complaint_sla_hours_urgent: 4,
  complaint_sla_hours_high: 24,
  complaint_sla_hours_normal: 72,
  complaint_sla_hours_low: 168,
  ridego_audit_log_retention_days: 730,
  booking_amount_mode: 'fixed',
  token_amount: 500,
  booking_amount_percent: 10,
  booking_amount_min: 0,
  booking_amount_max: 0,
  token_label: 'Booking amount',
  token_instructions: '',
  disclaimer_client: '',
  disclaimer_vendor: '',
  disclaimer_receipt: '',
};

const DEFAULT_TOGGLES: Record<AdminSettingsToggleKey, boolean> = {
  require_payment_proof: true,
  razorpay_enabled: false,
  gst_enabled: true,
  otp_enabled: true,
  email_otp_enabled: false,
  otp_trust_device_enabled: true,
  whatsapp_enabled: false,
  auto_assign_vendor: true,
  lead_auto_redistribute: false,
  require_complete_driver_profile: true,
  fraud_detection_enabled: true,
  delete_data_on_uninstall: false,
  ridego_allow_destructive_tools: false,
};

const SECRET_KEYS: AdminSettingsSecretKey[] = [
  'razorpay_key_id',
  'razorpay_key_secret',
  'razorpay_webhook_secret',
  'sms_api_key',
  'twilio_sid',
  'twilio_token',
  'fonnte_token',
  'google_maps_key',
];

const inputCls =
  'mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30';

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  // The visible label above is not a <label htmlFor> — it sits beside the
  // control, not above a single labelled input in every case, and several
  // Fields hold a Toggle rather than a form control. To keep every actual
  // input/select/textarea/Toggle programmatically named without threading
  // ids through every call site, clone the single child and give it an
  // aria-label matching the visible text, unless it already names itself.
  const child =
    isValidElement(children) && !(children.props as Record<string, unknown>)?.['aria-label']
      ? cloneElement(children as React.ReactElement<Record<string, unknown>>, { 'aria-label': label })
      : children;
  return (
    <div className="grid gap-1 border-b border-ink-100 py-3 last:border-b-0 sm:grid-cols-2 sm:items-start sm:gap-4">
      <div>
        <p className="text-sm font-medium text-ink-800">{label}</p>
        {hint && <p className="text-xs text-ink-400">{hint}</p>}
      </div>
      <div>{child}</div>
    </div>
  );
}

function Toggle({
  checked,
  onChange,
  label,
  danger,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  danger?: boolean;
}) {
  return (
    <label className="flex items-center gap-2 text-sm">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
      />
      <span className={danger ? 'font-semibold text-danger-600' : 'text-ink-700'}>{label}</span>
    </label>
  );
}

function SecretInput({
  value,
  isSet,
  onChange,
  placeholder,
}: {
  value: string;
  isSet: boolean;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  const ph = isSet ? '•••••••• (saved — leave blank to keep)' : placeholder;
  return (
    <input
      type="password"
      autoComplete="off"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={ph}
      className={inputCls}
    />
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-ink-100 p-5 shadow-xs">
      <h3 className="mb-1 text-sm font-semibold uppercase tracking-wide text-ink-500">{title}</h3>
      {children}
    </div>
  );
}

function InfoNote({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-3 rounded-lg border border-brand-200 bg-brand-50 px-3.5 py-2.5 text-sm text-brand-800">
      {children}
    </div>
  );
}

function WarnNote({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-3 rounded-lg border border-amber-300 bg-amber-50 px-3.5 py-2.5 text-sm text-amber-800">
      {children}
    </div>
  );
}

/**
 * Rebuild of admin/pages/settings.php's 7-tab settings form. Client-side
 * tabs only — all fields across all tabs are submitted together in one
 * "Save All Settings" request, matching the legacy page's one-form,
 * one-submit behaviour.
 *
 * Secret fields (Razorpay keys, SMS/Twilio/Fonnte/Google Maps keys) are
 * never populated with their real value: the GET response only reports
 * whether each is set, and the inputs start empty with a "saved" placeholder.
 * An empty secret input is a no-op on save — it never clears a stored secret.
 */
export function AdminSettingsPage() {
  const [activeTab, setActiveTab] = useState<Tab>('general');

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const [values, setValues] = useState<Record<SettingValueKey, string | number>>(DEFAULT_VALUES);
  const [toggles, setToggles] = useState<Record<AdminSettingsToggleKey, boolean>>(DEFAULT_TOGGLES);
  const [secretIsSet, setSecretIsSet] = useState<Record<AdminSettingsSecretKey, boolean>>(
    Object.fromEntries(SECRET_KEYS.map((k) => [k, false])) as Record<AdminSettingsSecretKey, boolean>
  );
  const [secretInputs, setSecretInputs] = useState<Record<AdminSettingsSecretKey, string>>(
    Object.fromEntries(SECRET_KEYS.map((k) => [k, ''])) as Record<AdminSettingsSecretKey, string>
  );
  const [uploadingQr, setUploadingQr] = useState(false);
  const [qrUploadError, setQrUploadError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminSettings();
      setValues((v) => ({ ...v, ...res.values }));
      setToggles((t) => ({ ...t, ...res.toggles }));
      const isSet = { ...secretIsSet };
      for (const k of SECRET_KEYS) {
        isSet[k] = !!res.secrets[k]?.is_set;
      }
      setSecretIsSet(isSet);
      setSecretInputs(Object.fromEntries(SECRET_KEYS.map((k) => [k, ''])) as Record<AdminSettingsSecretKey, string>);
    } catch (err) {
      setError(
        err instanceof ApiError && err.code === 'forbidden'
          ? "You don't have permission to manage settings."
          : err instanceof ApiError
          ? err.message
          : 'Could not load settings. Please try again.'
      );
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // TRACE: any settings input change → merges one key into the values map → re-render with the new value.
  //        Preconditions: key is a known text field (core or marketplace) → postconditions: other keys untouched →
  //        edge cases: numeric fields may hold '' while the operator is typing (sent as-is, server sanitises).
  function setValue(key: SettingValueKey, v: string | number) {
    setValues((prev) => ({ ...prev, [key]: v }));
  }

  // TRACE: a QR image file chosen in Settings → Payment → uploaded via
  //        uploadQrImage() (reuses the same real upload endpoint pattern as
  //        the Cities photo/route-page hero image uploads) → on success the
  //        returned URL is put straight into values.upi_qr_url, saved on the
  //        next "Save changes" like every other setting → void. Edge case:
  //        upload failure shows the server's reason and leaves whatever
  //        upi_qr_url the form already had.
  async function handleQrChosen(file: File | undefined) {
    if (!file) return;
    setUploadingQr(true);
    setQrUploadError(null);
    try {
      const res = await uploadQrImage(file);
      setValue('upi_qr_url', res.url);
    } catch (err) {
      setQrUploadError(err instanceof ApiError ? err.message : 'Could not upload the QR code. Please try again.');
    } finally {
      setUploadingQr(false);
    }
  }

  function setToggle(key: AdminSettingsToggleKey, v: boolean) {
    setToggles((prev) => ({ ...prev, [key]: v }));
  }

  function setSecret(key: AdminSettingsSecretKey, v: string) {
    setSecretInputs((prev) => ({ ...prev, [key]: v }));
  }

  async function saveAll() {
    setSaving(true);
    setSaveError(null);
    setSuccessMsg(null);
    try {
      const body: AdminSettingsSaveRequest = {
        values,
        toggles,
        // Only non-empty secret inputs are sent — an empty field means
        // "leave the stored secret alone", enforced again server-side.
        secrets: Object.fromEntries(
          SECRET_KEYS.filter((k) => secretInputs[k] !== '').map((k) => [k, secretInputs[k]])
        ),
      };
      await saveAdminSettings(body);
      setSuccessMsg('✅ Settings saved successfully.');
      await load();
    } catch (err) {
      setSaveError(err instanceof ApiError ? err.message : 'Could not save settings. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">⚙️ Platform settings</h1>
          <p className="text-sm text-ink-500">Settings are saved across all tabs together when you click Save.</p>
        </div>
        <Button onClick={saveAll} loading={saving} disabled={loading || !!error}>
          💾 Save All Settings
        </Button>
      </div>

      {successMsg && !loading && (
        <div role="status" className="mt-4 rounded-lg border border-success-200 bg-success-50 px-3.5 py-2.5 text-sm text-success-800">
          {successMsg}
        </div>
      )}
      {saveError && (
        <div role="alert" className="mt-4 rounded-lg border border-danger-500/30 bg-danger-50 px-3.5 py-2.5 text-sm text-danger-600">
          {saveError}
        </div>
      )}

      {loading && (
        <div className="mt-6 space-y-3" aria-busy="true" aria-label="Loading settings">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-14 w-full rounded-xl" />
          ))}
        </div>
      )}

      {!loading && error && <ErrorBanner message={error} onRetry={load} />}

      {!loading && !error && (
        <>
          <div className="mt-6 flex flex-wrap gap-1 border-b border-ink-100">
            {TABS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveTab(t.id)}
                className={`rounded-t-lg px-3.5 py-2 text-sm font-medium transition-colors ${
                  activeTab === t.id
                    ? 'border-b-2 border-brand-600 text-brand-700'
                    : 'text-ink-500 hover:text-ink-800'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="mt-5 space-y-5">
            {activeTab === 'branding' && <BrandingPanel onSaved={() => void load()} />}

            {activeTab === 'general' && (
              <Card title="General">
                <InfoNote>
                  Brand name, logo, contact details, address, social links and footer text now live in the Branding &amp; business tab.
                </InfoNote>
                <Field label="Admin Email">
                  <input type="email" value={values.admin_email} onChange={(e) => setValue('admin_email', e.target.value)} className={inputCls} />
                </Field>
                <Field label="Invoice footer note">
                  <input type="text" value={values.invoice_footer_note} onChange={(e) => setValue('invoice_footer_note', e.target.value)} placeholder="e.g. Thank you for travelling with us" className={inputCls} />
                </Field>
                <Field label="Currency">
                  <select value={values.currency} onChange={(e) => setValue('currency', e.target.value)} className={inputCls}>
                    <option value="INR">INR (₹)</option>
                    <option value="USD">USD ($)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="AED">AED</option>
                  </select>
                </Field>
                <Field label="SEO Meta Title">
                  <input type="text" value={values.meta_title} onChange={(e) => setValue('meta_title', e.target.value)} placeholder="Book Cab Online | Your Platform Name" className={inputCls} />
                </Field>
                <Field label="SEO Meta Description">
                  <textarea rows={2} value={values.meta_description} onChange={(e) => setValue('meta_description', e.target.value)} placeholder="Book reliable cabs at best prices..." className={inputCls} />
                </Field>
              </Card>
            )}

            {activeTab === 'payment' && (
              <Card title="Bank transfer details">
                <InfoNote>
                  These details are shown to clients on the booking confirmation page to complete bank transfer / UPI payment.
                </InfoNote>
                <Field label="Bank Name">
                  <input type="text" value={values.bank_name} onChange={(e) => setValue('bank_name', e.target.value)} placeholder="e.g. HDFC Bank, SBI" className={inputCls} />
                </Field>
                <Field label="Account Number">
                  <input type="text" value={values.bank_account} onChange={(e) => setValue('bank_account', e.target.value)} placeholder="Your bank account number" className={inputCls} />
                </Field>
                <Field label="IFSC Code">
                  <input type="text" value={values.bank_ifsc} onChange={(e) => setValue('bank_ifsc', e.target.value)} placeholder="e.g. HDFC0001234" className={inputCls} />
                </Field>
                <Field label="Account Holder Name">
                  <input type="text" value={values.bank_holder} onChange={(e) => setValue('bank_holder', e.target.value)} placeholder="As per bank records" className={inputCls} />
                </Field>

                <h4 className="mb-1 mt-5 text-sm font-semibold uppercase tracking-wide text-ink-500">UPI / QR payment</h4>
                <Field label="UPI ID">
                  <input type="text" value={values.upi_id} onChange={(e) => setValue('upi_id', e.target.value)} placeholder="yourname@bankname" className={inputCls} />
                </Field>
                <Field label="UPI QR Code" hint="Shown to customers on the Payment Details step">
                  <div className="flex flex-wrap items-center gap-3">
                    {values.upi_qr_url ? (
                      <img
                        src={String(values.upi_qr_url)}
                        alt="UPI QR code preview"
                        className="h-24 w-24 rounded-lg border border-ink-100 bg-white object-contain"
                      />
                    ) : (
                      <span className="text-xs text-ink-400">No QR code uploaded</span>
                    )}
                    <label className="cursor-pointer rounded-lg border border-ink-200 px-3 py-1.5 text-sm font-medium text-ink-800 hover:bg-ink-50 focus-within:outline focus-within:outline-2 focus-within:outline-brand-600">
                      {uploadingQr ? 'Uploading…' : values.upi_qr_url ? 'Replace QR code' : 'Upload QR code'}
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/webp"
                        className="sr-only"
                        disabled={uploadingQr}
                        aria-label="Upload UPI QR code"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          e.target.value = '';
                          void handleQrChosen(file);
                        }}
                      />
                    </label>
                    {values.upi_qr_url && (
                      <button
                        type="button"
                        onClick={() => setValue('upi_qr_url', '')}
                        className="text-sm font-medium text-ink-500 hover:text-danger-600"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                  {qrUploadError && <p className="mt-1 text-xs text-danger-600">{qrUploadError}</p>}
                </Field>
                <Field label="Require Payment Proof">
                  <Toggle checked={toggles.require_payment_proof} onChange={(v) => setToggle('require_payment_proof', v)} label="Require screenshot upload before confirmation" />
                </Field>

                <h4 className="mb-1 mt-5 text-sm font-semibold uppercase tracking-wide text-ink-500">Razorpay (online gateway)</h4>
                <Field label="Enable Razorpay">
                  <Toggle checked={toggles.razorpay_enabled} onChange={(v) => setToggle('razorpay_enabled', v)} label="Enable online card/UPI payments" />
                </Field>
                <Field label="Razorpay Key ID">
                  <SecretInput value={secretInputs.razorpay_key_id} isSet={secretIsSet.razorpay_key_id} onChange={(v) => setSecret('razorpay_key_id', v)} placeholder="rzp_live_..." />
                </Field>
                <Field label="Razorpay Key Secret">
                  <SecretInput value={secretInputs.razorpay_key_secret} isSet={secretIsSet.razorpay_key_secret} onChange={(v) => setSecret('razorpay_key_secret', v)} placeholder="Your secret key" />
                </Field>
                <Field label="Razorpay Webhook Secret">
                  <SecretInput
                    value={secretInputs.razorpay_webhook_secret}
                    isSet={secretIsSet.razorpay_webhook_secret}
                    onChange={(v) => setSecret('razorpay_webhook_secret', v)}
                    placeholder="Set in Razorpay Dashboard → Webhooks"
                  />
                  <p className="mt-1.5 text-xs text-ink-400">
                    Configured separately from the API secret above — used only to verify the{' '}
                    <code className="rounded bg-ink-100 px-1 py-0.5">X-Razorpay-Signature</code> header on incoming webhook calls
                    to <code className="rounded bg-ink-100 px-1 py-0.5">/wp-json/ridego/v1/webhooks/razorpay</code>. Must match the
                    secret entered for that webhook in the Razorpay dashboard.
                  </p>
                </Field>
                <Field label="GST Rate (%)">
                  <input
                    type="number"
                    min={0}
                    max={28}
                    value={values.gst_percent}
                    onChange={(e) => setValue('gst_percent', e.target.value === '' ? '' : Number(e.target.value))}
                    className={`${inputCls} w-28`}
                  />
                </Field>
                <Field label="Enable GST">
                  <Toggle checked={toggles.gst_enabled} onChange={(v) => setToggle('gst_enabled', v)} label="Include GST in fare calculations" />
                </Field>
              </Card>
            )}

            {activeTab === 'payment' && (
              <Card title="Customer advance and platform wording">
                <InfoNote>
                  {brand().name} is a booking facilitator. Clients pay only the customer advance below through the platform; the vendor/driver bills the ride and collects the rest directly.
                  The advance is a customer payment and is separate from the vendor lead fee. How the lead fee is calculated, and whether the advance is set against it, is configured under{' '}
                  <Link to="/admin/lead-fee" className="font-semibold underline">Vendor lead fee</Link>.
                </InfoNote>
                <Field label="How the customer advance is set">
                  <select
                    value={String(values.booking_amount_mode)}
                    onChange={(e) => setValue('booking_amount_mode', e.target.value)}
                    className={`${inputCls} w-56`}
                  >
                    <option value="fixed">Fixed amount per booking</option>
                    <option value="percent">Percentage of the estimated fare</option>
                  </select>
                </Field>
                {values.booking_amount_mode === 'percent' ? (
                  <Field label="Customer advance (% of estimated fare)" hint="Applies to new bookings only — changing this never alters bookings already placed">
                    <input
                      type="number"
                      min={1}
                      max={100}
                      value={values.booking_amount_percent}
                      onChange={(e) => setValue('booking_amount_percent', e.target.value === '' ? '' : Number(e.target.value))}
                      className={`${inputCls} w-40`}
                    />
                  </Field>
                ) : (
                  <Field label="Customer advance (₹)" hint="Applies to new bookings only — changing this never alters bookings already placed. 0 means no online advance.">
                    <input
                      type="number"
                      min={0}
                      value={values.token_amount}
                      onChange={(e) => setValue('token_amount', e.target.value === '' ? '' : Number(e.target.value))}
                      className={`${inputCls} w-40`}
                    />
                  </Field>
                )}
                <Field label="Minimum customer advance (₹)" hint="0 = no minimum">
                  <input
                    type="number"
                    min={0}
                    value={values.booking_amount_min}
                    onChange={(e) => setValue('booking_amount_min', e.target.value === '' ? '' : Number(e.target.value))}
                    className={`${inputCls} w-40`}
                  />
                </Field>
                <Field label="Maximum customer advance (₹)" hint="0 = no maximum. The advance never exceeds the estimated fare.">
                  <input
                    type="number"
                    min={0}
                    value={values.booking_amount_max}
                    onChange={(e) => setValue('booking_amount_max', e.target.value === '' ? '' : Number(e.target.value))}
                    className={`${inputCls} w-40`}
                  />
                </Field>
                <Field label="Client-facing label">
                  <input
                    type="text"
                    value={values.token_label}
                    onChange={(e) => setValue('token_label', e.target.value)}
                    placeholder="e.g. Advance payment"
                    className={inputCls}
                  />
                </Field>
                <Field label="Client instructions" hint="Shown at booking and payment. Leave blank to use the standard text (refundable before a vendor is arranged, non-refundable after).">
                  <textarea rows={4} value={values.token_instructions} onChange={(e) => setValue('token_instructions', e.target.value)} className={inputCls} />
                </Field>
                <Field label="Client disclaimer" hint="Shown on booking, confirmation, trip pages and the Terms page. Leave blank for the standard text.">
                  <textarea rows={4} value={values.disclaimer_client} onChange={(e) => setValue('disclaimer_client', e.target.value)} className={inputCls} />
                </Field>
                <Field label="Vendor / driver disclaimer" hint="Shown on vendor booking screens. Leave blank for the standard text.">
                  <textarea rows={4} value={values.disclaimer_vendor} onChange={(e) => setValue('disclaimer_vendor', e.target.value)} className={inputCls} />
                </Field>
                <Field label="Receipt and email footer disclaimer" hint="Printed on booking receipts and in the email footer. Leave blank for the standard text.">
                  <textarea rows={3} value={values.disclaimer_receipt} onChange={(e) => setValue('disclaimer_receipt', e.target.value)} className={inputCls} />
                </Field>
              </Card>
            )}

            {activeTab === 'sms' && (
              <Card title="OTP configuration">
                <Field label="Enable Phone OTP Verification">
                  <Toggle checked={toggles.otp_enabled} onChange={(v) => setToggle('otp_enabled', v)} label="Require a phone OTP to confirm booking" />
                </Field>
                <Field label="Enable Email OTP Verification">
                  <Toggle checked={toggles.email_otp_enabled} onChange={(v) => setToggle('email_otp_enabled', v)} label="Require an email OTP to confirm booking" />
                </Field>
                <Field label="Trust Device">
                  <Toggle checked={toggles.otp_trust_device_enabled} onChange={(v) => setToggle('otp_trust_device_enabled', v)} label="Skip OTP for trusted devices (30 days)" />
                </Field>
                <Field label="OTP Expiry (minutes)">
                  <input
                    type="number"
                    min={1}
                    max={60}
                    value={values.otp_expiry_minutes}
                    onChange={(e) => setValue('otp_expiry_minutes', e.target.value === '' ? '' : Number(e.target.value))}
                    className={`${inputCls} w-28`}
                  />
                </Field>

                <h4 className="mb-1 mt-5 text-sm font-semibold uppercase tracking-wide text-ink-500">SMS provider</h4>
                <Field label="SMS Provider">
                  <select value={values.sms_provider} onChange={(e) => setValue('sms_provider', e.target.value)} className={inputCls}>
                    <option value="textlocal">TextLocal (India)</option>
                    <option value="twilio">Twilio</option>
                    <option value="msg91">MSG91</option>
                    <option value="fast2sms">Fast2SMS</option>
                    <option value="custom">Custom</option>
                  </select>
                </Field>
                <Field label="API Key">
                  <SecretInput value={secretInputs.sms_api_key} isSet={secretIsSet.sms_api_key} onChange={(v) => setSecret('sms_api_key', v)} placeholder="Your SMS provider API key" />
                </Field>
                <Field label="Sender ID">
                  <input
                    type="text"
                    value={values.sms_sender_id}
                    onChange={(e) => setValue('sms_sender_id', e.target.value)}
                    placeholder="RIDEGO"
                    className={`${inputCls} uppercase`}
                  />
                </Field>

                <h4 className="mb-1 mt-5 text-sm font-semibold uppercase tracking-wide text-ink-500">Twilio (optional)</h4>
                <Field label="Account SID">
                  <SecretInput value={secretInputs.twilio_sid} isSet={secretIsSet.twilio_sid} onChange={(v) => setSecret('twilio_sid', v)} placeholder="AC..." />
                </Field>
                <Field label="Auth Token">
                  <SecretInput value={secretInputs.twilio_token} isSet={secretIsSet.twilio_token} onChange={(v) => setSecret('twilio_token', v)} />
                </Field>
                <Field label="From Number">
                  <input type="text" value={values.twilio_from} onChange={(e) => setValue('twilio_from', e.target.value)} placeholder="+1..." className={inputCls} />
                </Field>
              </Card>
            )}

            {activeTab === 'whatsapp' && (
              <Card title="Fonnte WhatsApp API">
                <InfoNote>
                  Fonnte sends WhatsApp messages. Get your token at{' '}
                  <a href="https://fonnte.com" target="_blank" rel="noreferrer" className="font-medium underline">
                    fonnte.com
                  </a>
                </InfoNote>
                <Field label="Enable WhatsApp">
                  <Toggle checked={toggles.whatsapp_enabled} onChange={(v) => setToggle('whatsapp_enabled', v)} label="Send booking notifications via WhatsApp" />
                </Field>
                <Field label="Fonnte API Token">
                  <SecretInput value={secretInputs.fonnte_token} isSet={secretIsSet.fonnte_token} onChange={(v) => setSecret('fonnte_token', v)} placeholder="Your Fonnte API token" />
                </Field>
              </Card>
            )}

            {activeTab === 'maps' && (
              <Card title="Google Maps integration">
                <InfoNote>
                  Required for distance calculation and route distance lookup. Get your key at{' '}
                  <a href="https://console.cloud.google.com" target="_blank" rel="noreferrer" className="font-medium underline">
                    Google Cloud Console
                  </a>
                  . Enable: Maps JS API, Places API, Distance Matrix API.
                </InfoNote>
                <Field label="Google Maps API Key">
                  <SecretInput value={secretInputs.google_maps_key} isSet={secretIsSet.google_maps_key} onChange={(v) => setSecret('google_maps_key', v)} placeholder="AIza..." />
                </Field>
              </Card>
            )}

            {activeTab === 'booking' && (
              <>
                <Card title="Booking parameters">
                  <Field label="Advance Notice Required (hours)" hint="Minimum hours in advance a booking can be made">
                    <input type="text" inputMode="numeric" value={values.booking_advance_hours} onChange={(e) => setValue('booking_advance_hours', e.target.value)} className={`${inputCls} w-32`} />
                  </Field>
                  <Field label="Max Days in Advance" hint="How far ahead bookings are allowed">
                    <input type="text" inputMode="numeric" value={values.booking_max_days} onChange={(e) => setValue('booking_max_days', e.target.value)} className={`${inputCls} w-32`} />
                  </Field>
                  <Field label="Payment Deadline (hours)" hint="Hours for client to complete payment after booking">
                    <input type="text" inputMode="numeric" value={values.payment_deadline_hours} onChange={(e) => setValue('payment_deadline_hours', e.target.value)} className={`${inputCls} w-32`} />
                  </Field>
                  <Field label="Free Cancellation Window (hours)" hint="Cancel X hours before pickup for free">
                    <input type="text" inputMode="numeric" value={values.cancellation_free_hours} onChange={(e) => setValue('cancellation_free_hours', e.target.value)} className={`${inputCls} w-32`} />
                  </Field>
                  <Field label="Min Vendor Wallet Balance (₹)" hint="Vendors below this cannot receive new leads">
                    <input type="text" inputMode="decimal" value={values.min_wallet_balance} onChange={(e) => setValue('min_wallet_balance', e.target.value)} className={`${inputCls} w-32`} />
                  </Field>
                  <Field label="Dispute/Refund Window After Completion (hours)" hint="A completed booking will not close (locking in settlement) until this many hours after the trip ended. 0 = close as soon as otherwise eligible, no waiting window.">
                    <input type="text" inputMode="numeric" value={values.booking_closure_dispute_hours} onChange={(e) => setValue('booking_closure_dispute_hours', e.target.value)} className={`${inputCls} w-32`} />
                  </Field>
                  <Field label="Night Hours Start" hint="Night surcharge start time (24h)">
                    <input type="text" value={values.night_hours_start} onChange={(e) => setValue('night_hours_start', e.target.value)} className={`${inputCls} w-32`} />
                  </Field>
                  <Field label="Night Hours End" hint="Night surcharge end time (24h)">
                    <input type="text" value={values.night_hours_end} onChange={(e) => setValue('night_hours_end', e.target.value)} className={`${inputCls} w-32`} />
                  </Field>
                  <Field label="Auto Assign Vendor">
                    <Toggle checked={toggles.auto_assign_vendor} onChange={(v) => setToggle('auto_assign_vendor', v)} label="Auto-dispatch leads to vendors after payment" />
                  </Field>
                  <Field label="Fraud Detection">
                    <Toggle checked={toggles.fraud_detection_enabled} onChange={(v) => setToggle('fraud_detection_enabled', v)} label="Flag suspicious booking patterns" />
                  </Field>
                </Card>
                <Card title="Complaint SLA deadlines">
                  <Field label="Urgent Priority (hours)" hint="Safety/harassment/emergency complaints">
                    <input type="number" min={1} value={values.complaint_sla_hours_urgent} onChange={(e) => setValue('complaint_sla_hours_urgent', e.target.value === '' ? '' : Number(e.target.value))} className={`${inputCls} w-32`} />
                  </Field>
                  <Field label="High Priority (hours)" hint="Payment disputes, fraud, driver misconduct">
                    <input type="number" min={1} value={values.complaint_sla_hours_high} onChange={(e) => setValue('complaint_sla_hours_high', e.target.value === '' ? '' : Number(e.target.value))} className={`${inputCls} w-32`} />
                  </Field>
                  <Field label="Normal Priority (hours)" hint="Default category">
                    <input type="number" min={1} value={values.complaint_sla_hours_normal} onChange={(e) => setValue('complaint_sla_hours_normal', e.target.value === '' ? '' : Number(e.target.value))} className={`${inputCls} w-32`} />
                  </Field>
                  <Field label="Low Priority (hours)" hint="Feedback / general queries">
                    <input type="number" min={1} value={values.complaint_sla_hours_low} onChange={(e) => setValue('complaint_sla_hours_low', e.target.value === '' ? '' : Number(e.target.value))} className={`${inputCls} w-32`} />
                  </Field>
                </Card>
              </>
            )}

            {activeTab === 'marketplace' && (
              <Card title="Lead assignment &amp; view-as">
                <InfoNote>
                  These settings control how bookings reach vendors and how long an admin&apos;s &quot;view as vendor&quot; session lasts.
                  They are saved together with all other settings.
                </InfoNote>
                <Field label="Lead assignment mode" hint="How a booking gets its vendor">
                  <select
                    value={String(values.lead_assignment_mode)}
                    onChange={(e) => setValue('lead_assignment_mode', e.target.value)}
                    className={inputCls}
                  >
                    <option value="compare">Vendors show interest, admin selects</option>
                    <option value="instant">First vendor to accept wins</option>
                  </select>
                </Field>
                <Field label="Response window (minutes)" hint="Compare mode: how long vendors have to respond to a lead. A reminder goes out at 50% of this time.">
                  <input
                    type="number"
                    min={1}
                    max={1440}
                    value={values.lead_response_window}
                    onChange={(e) => setValue('lead_response_window', e.target.value === '' ? '' : Number(e.target.value))}
                    className={`${inputCls} w-32`}
                  />
                </Field>
                <Field label="First-to-accept window (minutes)" hint="Instant mode only: how long each batch of vendors has to accept before the lead moves on">
                  <input
                    type="number"
                    min={1}
                    max={1440}
                    value={values.lead_accept_minutes}
                    onChange={(e) => setValue('lead_accept_minutes', e.target.value === '' ? '' : Number(e.target.value))}
                    className={`${inputCls} w-32`}
                  />
                </Field>
                <Field label="Vendors per lead" hint="How many eligible vendors each booking is offered to (1 to 50)">
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={values.lead_max_vendors}
                    onChange={(e) => setValue('lead_max_vendors', e.target.value === '' ? '' : Number(e.target.value))}
                    className={`${inputCls} w-32`}
                  />
                </Field>
                <Field label="Re-send unanswered leads">
                  <Toggle
                    checked={toggles.lead_auto_redistribute}
                    onChange={(v) => setToggle('lead_auto_redistribute', v)}
                    label="When nobody responds in time, offer the booking to the next eligible vendors automatically (off: it waits in the Command Centre for a person to decide)"
                  />
                </Field>
                <Field label="Driver profile required">
                  <Toggle
                    checked={toggles.require_complete_driver_profile}
                    onChange={(v) => setToggle('require_complete_driver_profile', v)}
                    label="Drivers must have a complete profile (identity, licence, address, emergency contact) before they can be put on a trip"
                  />
                </Field>
                <Field label="View-as session length (minutes)" hint="Between 5 and 120; sessions end automatically">
                  <input
                    type="number"
                    min={5}
                    max={120}
                    value={values.impersonation_minutes}
                    onChange={(e) => setValue('impersonation_minutes', e.target.value === '' ? '' : Number(e.target.value))}
                    className={`${inputCls} w-32`}
                  />
                </Field>
              </Card>
            )}

            {activeTab === 'advanced' && (
              <Card title="Danger zone">
                <WarnNote>⚠️ These settings affect core plugin behavior. Change carefully.</WarnNote>
                <Field label="Delete All Data on Uninstall" hint="WARNING: Permanently deletes ALL bookings, vendors, settings on plugin deletion">
                  <Toggle checked={toggles.delete_data_on_uninstall} onChange={(v) => setToggle('delete_data_on_uninstall', v)} label="Enable (DANGER)" danger />
                </Field>
                <Field
                  label="Allow Destructive Tools Page Actions"
                  hint={'Required (in addition to WP_DEBUG) to enable "Recreate DB Tables" and "Seed Demo Data" on the Tools page. Off by default so these can\'t be run accidentally on a live production site.'}
                >
                  <Toggle checked={toggles.ridego_allow_destructive_tools} onChange={(v) => setToggle('ridego_allow_destructive_tools', v)} label="Enable (DANGER)" danger />
                </Field>
                <Field
                  label="Audit Log Retention (days)"
                  hint="Financial/security audit trails need much longer retention than operational data (bookings cache, OTPs, etc). Default 730 days (2 years)."
                >
                  <input
                    type="number"
                    min={90}
                    value={values.ridego_audit_log_retention_days}
                    onChange={(e) => setValue('ridego_audit_log_retention_days', e.target.value === '' ? '' : Number(e.target.value))}
                    className={`${inputCls} w-32`}
                  />
                </Field>
              </Card>
            )}
          </div>

          <div className="mt-6 flex items-center justify-between gap-3 rounded-xl border border-ink-100 bg-ink-50/60 p-5">
            <span className="text-xs text-ink-500">Settings are saved immediately across all tabs when you click Save.</span>
            <Button onClick={saveAll} loading={saving} size="lg">
              💾 Save All Settings
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
