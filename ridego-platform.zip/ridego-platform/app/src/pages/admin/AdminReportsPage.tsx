import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getBootstrap } from '../../lib/bootstrap';
import {
  getAdminReportSummary,
  getAdminReportsDaily,
  getAdminReportsExportNonce,
  getAdminReportsTopRoutes,
  getAdminReportsTripTypes,
  getAdminVendorPerformance,
  ApiError,
} from '../../lib/api';
import type {
  AdminReportSummary,
  AdminReportsDailyRow,
  AdminReportsTopRouteRow,
  AdminReportsTripTypeRow,
  AdminVendorPerformanceRow,
} from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Button } from '../../components/ui/Button';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { brand } from '../../lib/brand';

function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

function humanize(value: string): string {
  return value
    .split('_')
    .map((part) => (part ? part[0].toUpperCase() + part.slice(1) : part))
    .join(' ');
}

function fmtDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function defaultFrom(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`;
}

function defaultTo(): string {
  return fmtDate(new Date());
}

const PERIOD_PRESETS: { label: string; range: () => [string, string] }[] = [
  {
    label: 'MTD',
    range: () => {
      const d = new Date();
      return [`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`, fmtDate(d)];
    },
  },
  {
    label: 'Last 7D',
    range: () => {
      const to = new Date();
      const from = new Date();
      from.setDate(from.getDate() - 7);
      return [fmtDate(from), fmtDate(to)];
    },
  },
  {
    label: 'Last 30D',
    range: () => {
      const to = new Date();
      const from = new Date();
      from.setDate(from.getDate() - 30);
      return [fmtDate(from), fmtDate(to)];
    },
  },
  {
    label: 'YTD',
    range: () => {
      const d = new Date();
      return [`${d.getFullYear()}-01-01`, fmtDate(d)];
    },
  },
];

const RANK_MEDALS = ['🥇', '🥈', '🥉'];

/**
 * The CSV export lives at admin-ajax.php (a legacy wp_ajax_* handler,
 * not a REST route — see the caveat in includes/app-admin-reports-api.php),
 * gated on the separate ridego_export_data capability rather than
 * ridego_view_reports, and requires a 'ridego_admin_nonce' nonce the SPA
 * fetches via getAdminReportsExportNonce(). Built from the bootstrap's
 * siteUrl rather than apiUrl(), since admin-ajax.php lives at the site
 * root, not under the REST namespace this page's other calls use.
 */
function exportCsvUrl(type: 'bookings' | 'vendors', nonce: string): string {
  const root = getBootstrap().siteUrl.replace(/\/$/, '');
  return `${root}/wp-admin/admin-ajax.php?action=ridego_export_csv&type=${type}&nonce=${encodeURIComponent(nonce)}`;
}

export function AdminReportsPage() {
  const [from, setFrom] = useState(defaultFrom());
  const [to, setTo] = useState(defaultTo());
  const [dailyPage, setDailyPage] = useState(1);

  const [summary, setSummary] = useState<AdminReportSummary | null>(null);
  const [tripTypes, setTripTypes] = useState<AdminReportsTripTypeRow[] | null>(null);
  const [topRoutes, setTopRoutes] = useState<AdminReportsTopRouteRow[] | null>(null);
  const [vendors, setVendors] = useState<AdminVendorPerformanceRow[] | null>(null);
  const [daily, setDaily] = useState<{ rows: AdminReportsDailyRow[]; total: number; per_page: number } | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [exportNonce, setExportNonce] = useState<string | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const load = useCallback(
    async (f: string, t: string, dp: number) => {
      setLoading(true);
      setError(null);
      try {
        const [summaryRes, tripRes, routesRes, vendorRes, dailyRes] = await Promise.all([
          getAdminReportSummary({ from: f, to: t }),
          getAdminReportsTripTypes({ from: f, to: t }),
          getAdminReportsTopRoutes({ from: f, to: t }),
          getAdminVendorPerformance({ from: f, to: t, limit: 10 }),
          getAdminReportsDaily({ from: f, to: t, page: dp }),
        ]);
        setSummary(summaryRes);
        setTripTypes(tripRes.rows);
        setTopRoutes(routesRes.rows);
        setVendors(vendorRes.vendors);
        setDaily({ rows: dailyRes.rows, total: dailyRes.total, per_page: dailyRes.per_page });
      } catch (err) {
        if (err instanceof ApiError && err.code === 'forbidden') {
          setError("You don't have permission to view reports.");
        } else {
          setError(err instanceof ApiError ? err.message : 'Could not load reports. Please try again.');
        }
      } finally {
        setLoading(false);
      }
    },
    []
  );

  useEffect(() => {
    load(from, to, dailyPage);
  }, [from, to, dailyPage, load]);

  useEffect(() => {
    // A 403 here means this admin has ridego_view_reports but not the
    // separate ridego_export_data capability — export buttons simply
    // don't render rather than being shown and failing on click.
    getAdminReportsExportNonce()
      .then((res) => setExportNonce(res.nonce))
      .catch(() => setExportNonce(null));
  }, []);

  function applyRange() {
    setDailyPage(1);
    load(from, to, 1);
  }

  function applyPreset(range: () => [string, string]) {
    const [f, t] = range();
    setFrom(f);
    setTo(t);
    setDailyPage(1);
    load(f, t, 1);
  }

  const maxDailyRevenue = daily?.rows.length ? Math.max(...daily.rows.map((d) => d.collected ?? 0), 1) : 1;
  const canPrevDaily = dailyPage > 1;
  const canNextDaily = daily ? dailyPage * daily.per_page < daily.total : false;

  function rangeFields(idPrefix: string) {
    return (
      <>
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm font-medium text-ink-600">Period:</span>
          {PERIOD_PRESETS.map((p) => (
            <Button key={p.label} variant="secondary" size="sm" onClick={() => applyPreset(p.range)}>
              {p.label}
            </Button>
          ))}
        </div>
        <div>
          <label htmlFor={`${idPrefix}-from`} className="block text-sm font-medium text-ink-700">
            From
          </label>
          <input
            id={`${idPrefix}-from`}
            type="date"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>
        <div>
          <label htmlFor={`${idPrefix}-to`} className="block text-sm font-medium text-ink-700">
            To
          </label>
          <input
            id={`${idPrefix}-to`}
            type="date"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>
      </>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Reports &amp; analytics</h1>
          <p className="text-sm text-ink-500">Bookings, booking amounts collected, estimated ride value and vendor performance for the selected period.</p>
          <Link to="/admin/reports/marketplace" className="mt-1 inline-block text-sm font-semibold text-brand-700 underline">
            Marketplace report: funnel, response times and commission by vendor
          </Link>
        </div>
        {exportNonce && (
          <div className="flex gap-2">
            <Button variant="secondary" size="sm" onClick={() => window.open(exportCsvUrl('bookings', exportNonce), '_blank')}>
              ⬇ Export bookings
            </Button>
            <Button variant="secondary" size="sm" onClick={() => window.open(exportCsvUrl('vendors', exportNonce), '_blank')}>
              ⬇ Export vendors
            </Button>
          </div>
        )}
      </div>

      <div className="mt-6 hidden flex-wrap items-end gap-3 lg:flex">
        {rangeFields('report')}
        <Button onClick={applyRange}>Apply</Button>
      </div>

      <div className="mt-6 lg:hidden">
        <button
          type="button"
          onClick={() => setFiltersOpen(true)}
          className="relative flex items-center gap-2 rounded-lg border border-ink-200 bg-white px-3.5 py-2 text-sm font-medium text-ink-700 shadow-xs"
        >
          <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 4h18M6 8h12M9 12h6M11 16h2" />
          </svg>
          Filters
        </button>
      </div>

      <BottomSheet open={filtersOpen} title="Filters" onClose={() => setFiltersOpen(false)}>
        <div className="flex flex-col gap-3">
          {rangeFields('report-sheet')}
          <Button
            onClick={() => {
              applyRange();
              setFiltersOpen(false);
            }}
          >
            Apply
          </Button>
        </div>
      </BottomSheet>

      {loading && (
        <div className="mt-6 space-y-6" aria-busy="true" aria-label="Loading reports">
          <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-64 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={() => load(from, to, dailyPage)} />
        </div>
      )}

      {!loading && !error && summary && (
        <>
          <div className="mt-6 grid gap-4 sm:grid-cols-3 lg:grid-cols-6">
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Total bookings</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{summary.total_bookings}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Completed</p>
              <p className="mt-2 text-xl font-bold text-success-600">{summary.completed}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Cancelled</p>
              <p className="mt-2 text-xl font-bold text-danger-600">{summary.cancelled}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Booking amounts collected</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{currency(summary.revenue)}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Est. ride value (billed by vendors)</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{currency(summary.ride_value ?? 0)}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Avg booking amount</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{currency(summary.avg_booking)}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Completion rate</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{summary.completion_rate_pct}%</p>
            </div>
          </div>

          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <div className="rounded-xl border border-ink-100 p-5 shadow-xs">
              <h3 className="text-base font-semibold text-ink-900">Bookings by trip type</h3>
              {tripTypes && tripTypes.length > 0 ? (
                <ul className="mt-3 space-y-3">
                  {(() => {
                    const totalCount = tripTypes.reduce((sum, t) => sum + t.bookings, 0);
                    return tripTypes.map((t) => {
                      const pct = totalCount > 0 ? Math.round((t.bookings / totalCount) * 100) : 0;
                      return (
                        <li key={t.trip_type} className="text-sm">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-ink-700">{humanize(t.trip_type)}</span>
                            <span className="text-ink-500">
                              {t.bookings} &middot; est. ride value {currency(t.revenue)}
                            </span>
                          </div>
                          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-ink-100">
                            <div className="h-full rounded-full bg-brand-500" style={{ width: `${pct}%` }} />
                          </div>
                          <p className="mt-0.5 text-xs text-ink-400">{pct}%</p>
                        </li>
                      );
                    });
                  })()}
                </ul>
              ) : (
                <p className="mt-3 text-sm text-ink-500">No bookings in this period.</p>
              )}
            </div>

            <div className="rounded-xl border border-ink-100 p-5 shadow-xs">
              <h3 className="text-base font-semibold text-ink-900">Top routes (completed)</h3>
              {topRoutes && topRoutes.length > 0 ? (
                <ul className="mt-3 space-y-2">
                  {topRoutes.map((r, i) => (
                    <li key={i} className="flex items-center justify-between text-sm">
                      <span className="text-ink-700">
                        {r.pickup_city} → {r.drop_city}
                      </span>
                      <span className="text-ink-500">
                        {r.bookings} &middot; est. ride value {currency(r.revenue)}
                      </span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="mt-3 text-sm text-ink-500">No completed trips in this period.</p>
              )}
            </div>
          </div>

          <div className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs">
            <h3 className="text-base font-semibold text-ink-900">🏆 Top performing vendors</h3>
            <p className="mt-1 text-xs text-ink-400">
              Performance Score = 40% completed trips (relative to the top vendor) + 25% completion rate + 25% avg
              rating + 10% inverse cancellation rate.
            </p>
            {vendors && vendors.length > 0 ? (
              <div className="mt-3 hidden overflow-x-auto lg:block">
                <table className="w-full text-sm">
                  <thead className="text-left text-xs font-medium uppercase tracking-wide text-ink-400">
                    <tr>
                      <th className="py-2 pr-2">Rank</th>
                      <th className="py-2 pr-2">Vendor</th>
                      <th className="py-2 pr-2">Phone</th>
                      <th className="py-2 pr-2">Score</th>
                      <th className="py-2 pr-2" title="Volume / Completion / Rating / Cancellation-inverse">
                        Breakdown
                      </th>
                      <th className="py-2 pr-2">Completed</th>
                      <th className="py-2 pr-2">Completion</th>
                      <th className="py-2 pr-2">Cancel</th>
                      <th className="py-2">Rating</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {vendors.map((v, i) => (
                      <tr key={v.vendor_id}>
                        <td className="py-2 pr-2 text-base">{RANK_MEDALS[i] ?? `#${i + 1}`}</td>
                        <td className="py-2 pr-2 font-medium text-ink-900">{v.business_name}</td>
                        <td className="py-2 pr-2 text-ink-500">{v.phone || '—'}</td>
                        <td className="py-2 pr-2 font-semibold text-brand-700">{v.perf_score.toFixed(1)} / 100</td>
                        <td className="py-2 pr-2 text-xs text-ink-400">
                          V{v.breakdown.volume} &middot; C{v.breakdown.completion} &middot; R{v.breakdown.rating}{' '}
                          &middot; X{v.breakdown.cancellation}
                        </td>
                        <td className="py-2 pr-2 text-ink-700">{v.completed_trips}</td>
                        <td className="py-2 pr-2 text-ink-700">{v.completion_rate_pct}%</td>
                        <td className="py-2 pr-2 text-ink-700">{v.cancellation_rate_pct}%</td>
                        <td className="py-2 text-ink-700">{v.rating ? `${v.rating.toFixed(1)} ⭐` : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="mt-3 text-sm text-ink-500">No vendor activity in this period.</p>
            )}

            {vendors && vendors.length > 0 && (
              <div className="mt-3 space-y-3 lg:hidden">
                {vendors.map((v, i) => (
                  <div key={v.vendor_id} className="rounded-xl border border-ink-100 bg-white p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <span className="text-base">{RANK_MEDALS[i] ?? `#${i + 1}`}</span>
                        <div>
                          <p className="text-sm font-medium text-ink-900">{v.business_name}</p>
                          <p className="text-xs text-ink-500">{v.phone || '—'}</p>
                        </div>
                      </div>
                      <span className="shrink-0 text-sm font-semibold text-brand-700">{v.perf_score.toFixed(1)} / 100</span>
                    </div>
                    <p className="mt-1 text-xs text-ink-400" title="Volume / Completion / Rating / Cancellation-inverse">
                      V{v.breakdown.volume} &middot; C{v.breakdown.completion} &middot; R{v.breakdown.rating} &middot; X{v.breakdown.cancellation}
                    </p>
                    <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
                      <span className="text-ink-400">Completed</span>
                      <span className="text-right text-ink-700">{v.completed_trips}</span>
                      <span className="text-ink-400">Completion rate</span>
                      <span className="text-right text-ink-700">{v.completion_rate_pct}%</span>
                      <span className="text-ink-400">Cancellation</span>
                      <span className="text-right text-ink-700">{v.cancellation_rate_pct}%</span>
                      <span className="text-ink-400">Rating</span>
                      <span className="text-right text-ink-700">{v.rating ? `${v.rating.toFixed(1)} ⭐` : '—'}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs">
            <h3 className="text-base font-semibold text-ink-900">Daily breakdown</h3>
            <p className="mt-1 text-xs text-ink-500">Bookings per day and booking amounts collected by {brand().name}.</p>
            {daily && daily.rows.length > 0 ? (
              <>
                <ul className="mt-3 space-y-1.5">
                  {daily.rows.map((d) => (
                    <li key={d.date} className="flex items-center gap-3 text-sm">
                      <span className="w-24 shrink-0 text-ink-500">{d.date}</span>
                      <span className="h-2 flex-1 overflow-hidden rounded-full bg-ink-100">
                        <span
                          className="block h-full rounded-full bg-brand-500"
                          style={{ width: `${Math.max(4, ((d.collected ?? 0) / maxDailyRevenue) * 100)}%` }}
                        />
                      </span>
                      <span className="w-16 shrink-0 text-right text-ink-700">{d.bookings}</span>
                      <span className="w-24 shrink-0 text-right font-medium text-ink-900">{currency(d.collected ?? 0)}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-4 flex items-center justify-between">
                  <p className="text-xs text-ink-400">
                    Page {dailyPage} of {Math.max(1, Math.ceil(daily.total / daily.per_page))}
                  </p>
                  <div className="flex gap-2">
                    <Button variant="secondary" size="sm" disabled={!canPrevDaily} onClick={() => setDailyPage((p) => Math.max(1, p - 1))}>
                      Previous
                    </Button>
                    <Button variant="secondary" size="sm" disabled={!canNextDaily} onClick={() => setDailyPage((p) => p + 1)}>
                      Next
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <p className="mt-3 text-sm text-ink-500">No bookings in this period.</p>
            )}
          </div>
        </>
      )}
    </div>
  );
}
