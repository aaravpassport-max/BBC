import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  createAdminSurgeRule,
  deleteAdminSurgeRule,
  getAdminCities,
  getAdminPricingVehicles,
  getAdminSurgeRules,
  getAdminZones,
  updateAdminSurgeRule,
  ApiError,
} from '../../lib/api';
import type {
  AdminPricingVehicleRow,
  AdminSurgeInput,
  AdminSurgeRuleRow,
  AdminZoneRow,
  City,
} from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';

const EMPTY_FORM: AdminSurgeInput = {
  vehicle_id: undefined,
  city: '',
  zone: '',
  zone_id: undefined,
  from_date: '',
  to_date: '',
  time_from: '00:00',
  time_to: '23:59',
  multiplier: '1.5',
  reason: '',
  is_active: true,
};

export function AdminSurgePage() {
  const [rows, setRows] = useState<AdminSurgeRuleRow[] | null>(null);
  const [vehicles, setVehicles] = useState<AdminPricingVehicleRow[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [zones, setZones] = useState<AdminZoneRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<AdminSurgeRuleRow | null>(null);
  const [form, setForm] = useState<AdminSurgeInput>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [deleteTarget, setDeleteTarget] = useState<AdminSurgeRuleRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [surgeRes, vehiclesRes, citiesRes, zonesRes] = await Promise.all([
        getAdminSurgeRules(),
        getAdminPricingVehicles(),
        getAdminCities(),
        getAdminZones(),
      ]);
      setRows(surgeRes.rows);
      setVehicles(vehiclesRes.rows.filter((v) => v.is_active));
      setCities(citiesRes.rows);
      setZones(zonesRes.rows.filter((z) => z.is_active));
    } catch (err) {
      if (err instanceof ApiError && err.code === 'forbidden') {
        setError("You don't have permission to manage surge pricing.");
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not load surge rules. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function openAdd() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setFormError(null);
    setShowForm(true);
  }

  function openEdit(rule: AdminSurgeRuleRow) {
    setEditing(rule);
    setForm({
      vehicle_id: rule.vehicle_id || undefined,
      city: rule.city,
      zone: rule.zone,
      zone_id: rule.zone_id || undefined,
      from_date: rule.from_date,
      to_date: rule.to_date,
      time_from: rule.time_from,
      time_to: rule.time_to,
      multiplier: rule.multiplier,
      reason: rule.reason,
      is_active: rule.is_active,
    });
    setFormError(null);
    setShowForm(true);
  }

  async function submitForm() {
    if (!form.from_date || !form.to_date) {
      setFormError('Please provide a start and end date.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      if (editing) {
        await updateAdminSurgeRule(editing.id, form);
        setActionMessage('Surge rule updated.');
      } else {
        await createAdminSurgeRule(form);
        setActionMessage('Surge rule created.');
      }
      setShowForm(false);
      await load();
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : 'Could not save this surge rule.');
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    setDeleteError(null);
    try {
      await deleteAdminSurgeRule(deleteTarget.id);
      setActionMessage('Surge rule deleted.');
      setDeleteTarget(null);
      await load();
    } catch (err) {
      setDeleteError(err instanceof ApiError ? err.message : 'Could not delete this surge rule.');
    } finally {
      setDeleting(false);
    }
  }

  const zonesForSelectedCity = form.city ? zones.filter((z) => z.city_name === form.city) : zones;

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Link to="/admin/pricing" className="text-sm font-medium text-brand-700 hover:text-brand-800">
            ← Vehicle pricing
          </Link>
          <h1 className="mt-1 text-2xl font-bold text-ink-900 sm:text-3xl">Surge pricing</h1>
          <p className="text-sm text-ink-500">
            Time/date/city/zone/vehicle-scoped fare multipliers. Multiplier is clamped to 0.5–5.0×.
          </p>
          {!loading && rows && <p className="mt-1 text-xs font-medium text-ink-400">{rows.length} rule{rows.length === 1 ? '' : 's'}</p>}
        </div>
        <Button onClick={openAdd}>Add surge rule</Button>
      </div>

      {actionMessage && !loading && (
        <div role="status" className="mt-4 rounded-lg border border-success-500/30 bg-success-50 px-3.5 py-2.5 text-sm text-success-700">
          {actionMessage}
        </div>
      )}

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading surge rules">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full rounded-xl" />
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={load} />}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState title="No surge rules yet" description="Add a rule to apply time-based or zone-based fare multipliers." />
        )}

        {!loading && !error && rows && rows.length > 0 && (
          <ul className="space-y-3">
            {rows.map((r) => (
              <li key={r.id} className="flex flex-wrap items-start justify-between gap-3 rounded-xl border border-ink-100 p-4 shadow-xs sm:p-5">
                <div>
                  <p className="font-semibold text-ink-900">
                    {r.multiplier.toFixed(2)}× {r.reason ? `— ${r.reason}` : ''}
                    {!r.is_active && (
                      <span className="ml-2 rounded-full bg-ink-100 px-2 py-0.5 text-xs font-semibold text-ink-500">
                        Inactive
                      </span>
                    )}
                  </p>
                  <p className="mt-0.5 text-sm text-ink-500">
                    {r.vehicle_name || 'All vehicles'} &middot; {r.city || 'All cities'}
                    {r.zone ? ` (${r.zone})` : ''}
                    {r.zone_name ? ` · 📍 ${r.zone_name}` : ''}
                  </p>
                  <p className="mt-1 text-xs text-ink-400">
                    {r.from_date} → {r.to_date} &middot; {r.time_from}–{r.time_to}
                  </p>
                </div>
                <div className="flex shrink-0 gap-2">
                  <Button variant="secondary" size="sm" onClick={() => openEdit(r)}>
                    Edit
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => {
                      setDeleteTarget(r);
                      setDeleteError(null);
                    }}
                  >
                    Delete
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <ConfirmDialog
        open={showForm}
        title={editing ? 'Edit surge rule' : 'Add surge rule'}
        confirmLabel={editing ? 'Save changes' : 'Create rule'}
        confirmVariant="primary"
        loading={saving}
        onConfirm={submitForm}
        onCancel={() => {
          if (saving) return;
          setShowForm(false);
        }}
      >
        <div className="max-h-[60vh] space-y-3 overflow-y-auto pr-1">
          {formError && (
            <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
              {formError}
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="surge-vehicle" className="block text-sm font-medium text-ink-700">
                Vehicle
              </label>
              <select
                id="surge-vehicle"
                value={form.vehicle_id ?? ''}
                onChange={(e) => setForm((f) => ({ ...f, vehicle_id: e.target.value ? Number(e.target.value) : undefined }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              >
                <option value="">All vehicles</option>
                {vehicles.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="surge-city" className="block text-sm font-medium text-ink-700">
                City
              </label>
              <select
                id="surge-city"
                value={form.city ?? ''}
                onChange={(e) => setForm((f) => ({ ...f, city: e.target.value, zone_id: undefined }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              >
                <option value="">All cities</option>
                {cities.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
              <p className="mt-1 text-xs text-ink-400">Leave blank to apply to all cities</p>
            </div>
          </div>
          <div>
            <label htmlFor="surge-zone" className="block text-sm font-medium text-ink-700">
              Zone (optional — pins the rule to a specific zone within the city)
            </label>
            <select
              id="surge-zone"
              value={form.zone_id ?? ''}
              onChange={(e) => setForm((f) => ({ ...f, zone_id: e.target.value ? Number(e.target.value) : undefined }))}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            >
              <option value="">No specific zone</option>
              {zonesForSelectedCity.map((z) => (
                <option key={z.id} value={z.id}>
                  {z.name} ({z.city_name})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="surge-zone-label" className="block text-sm font-medium text-ink-700">
              Zone label
            </label>
            <input
              id="surge-zone-label"
              type="text"
              value={form.zone ?? ''}
              onChange={(e) => setForm((f) => ({ ...f, zone: e.target.value }))}
              placeholder="e.g. Airport, Downtown"
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
            <p className="mt-1 text-xs text-ink-400">Optional free-text display label (not used for matching).</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="surge-from-date" className="block text-sm font-medium text-ink-700">
                From date
              </label>
              <input
                id="surge-from-date"
                type="date"
                value={form.from_date}
                onChange={(e) => setForm((f) => ({ ...f, from_date: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="surge-to-date" className="block text-sm font-medium text-ink-700">
                To date
              </label>
              <input
                id="surge-to-date"
                type="date"
                value={form.to_date}
                onChange={(e) => setForm((f) => ({ ...f, to_date: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="surge-time-from" className="block text-sm font-medium text-ink-700">
                Time from
              </label>
              <input
                id="surge-time-from"
                type="time"
                value={form.time_from}
                onChange={(e) => setForm((f) => ({ ...f, time_from: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="surge-time-to" className="block text-sm font-medium text-ink-700">
                Time to
              </label>
              <input
                id="surge-time-to"
                type="time"
                value={form.time_to}
                onChange={(e) => setForm((f) => ({ ...f, time_to: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <div>
            <label htmlFor="surge-multiplier" className="block text-sm font-medium text-ink-700">
              Multiplier (0.5–5.0×)
            </label>
            <input
              id="surge-multiplier"
              type="number"
              min={0.5}
              max={5}
              step={0.1}
              value={form.multiplier}
              onChange={(e) => setForm((f) => ({ ...f, multiplier: e.target.value }))}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
            <p className="mt-1 text-xs text-ink-400">
              Values outside this range are clamped by the server regardless of what's entered here.
            </p>
          </div>
          <div>
            <label htmlFor="surge-reason" className="block text-sm font-medium text-ink-700">
              Reason
            </label>
            <input
              id="surge-reason"
              type="text"
              value={form.reason}
              onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))}
              placeholder="e.g. New Year's Eve demand"
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={form.is_active !== false}
              onChange={(e) => setForm((f) => ({ ...f, is_active: e.target.checked }))}
              className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
            />
            Active
          </label>
        </div>
      </ConfirmDialog>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete this surge rule?"
        description="This cannot be undone."
        confirmLabel="Delete rule"
        confirmVariant="danger"
        loading={deleting}
        onConfirm={confirmDelete}
        onCancel={() => {
          if (deleting) return;
          setDeleteTarget(null);
          setDeleteError(null);
        }}
      >
        {deleteError && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {deleteError}
          </div>
        )}
      </ConfirmDialog>
    </div>
  );
}
