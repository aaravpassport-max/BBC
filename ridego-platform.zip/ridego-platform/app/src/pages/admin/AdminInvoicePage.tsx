import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { errMessage, getAdminInvoice, inr, type InvoiceData } from '../../lib/api-admin-crm';
import { Button } from '../../components/ui/Button';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { brand } from '../../lib/brand';

// TRACE: route /app/admin/bookings/:id/invoice → GET receipt data (assigns the receipt number on first view server-side) → printable BOOKING RECEIPT for the booking amount RideGo collected;
//        the ride invoice is issued by the vendor/driver, so the estimated ride fare is shown separately and clearly marked; "Print" calls window.print().
//        Preconditions: numeric id in the URL. Postconditions: shows company block, client block, line items summing to the total, paid, balance and payment history.
//        Edge cases: invalid id (error banner), API failure (banner + retry), zero-value lines are still listed as returned by the server.
export function AdminInvoicePage() {
  const { id } = useParams();
  const bookingId = Number(id);
  const [data, setData] = useState<InvoiceData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let live = true;
    if (!bookingId || Number.isNaN(bookingId)) {
      setError('This receipt link is not valid.');
      return;
    }
    setError(null);
    setData(null);
    getAdminInvoice(bookingId)
      .then((r) => { if (live) setData(r); })
      .catch((e) => { if (live) setError(errMessage(e, 'Could not load the receipt. Please try again.')); });
    return () => { live = false; };
  }, [bookingId, tick]);

  return (
    <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6">
      <div className="mb-4 flex items-center justify-between print:hidden">
        <Link to={`/app/admin/bookings/${bookingId}`} className="text-sm font-medium text-brand-700 hover:underline">Back to booking</Link>
        <Button size="sm" onClick={() => window.print()} disabled={!data}>Print</Button>
      </div>
      {error && <ErrorBanner message={error} onRetry={() => setTick((t) => t + 1)} />}
      {!error && !data && <Skeleton className="h-96 w-full" />}
      {data && (
        <article className="rounded-xl border border-ink-100 bg-white p-6 shadow-xs print:border-0 print:shadow-none" aria-label={`Booking receipt ${data.receipt_number ?? data.invoice_number}`}>
          <header className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold text-ink-900">{data.company.name}</h1>
              {data.company.address && <p className="whitespace-pre-line text-sm text-ink-600">{data.company.address}</p>}
              {data.company.gstin && <p className="text-sm text-ink-600">GSTIN {data.company.gstin}</p>}
              <p className="text-sm text-ink-600">{[data.company.phone, data.company.email].filter(Boolean).join(' · ')}</p>
            </div>
            <div className="text-right text-sm text-ink-700">
              <p className="text-lg font-bold text-ink-900">Booking receipt {data.receipt_number ?? data.invoice_number}</p>
              <p>Booking {data.booking_number}</p>
              <p>Issued {data.issued_on}</p>
            </div>
          </header>
          <section className="mt-6 grid gap-4 sm:grid-cols-2">
            <div>
              <h2 className="text-xs font-semibold uppercase tracking-wide text-ink-500">Received from</h2>
              <p className="font-medium text-ink-900">{data.client_company || data.client_name}</p>
              {data.client_company && <p className="text-sm text-ink-700">{data.client_name}</p>}
              <p className="text-sm text-ink-600">{[data.client_phone, data.client_email].filter(Boolean).join(' · ')}</p>
              {data.client_gst && <p className="text-sm text-ink-600">GSTIN {data.client_gst}</p>}
            </div>
            <div>
              <h2 className="text-xs font-semibold uppercase tracking-wide text-ink-500">Trip</h2>
              <p className="font-medium text-ink-900">{data.route}</p>
              <p className="text-sm text-ink-600">{data.journey_date} {data.journey_time} · {data.trip_type.replace(/_/g, ' ')}</p>
            </div>
          </section>
          <table className="mt-6 w-full text-sm">
            <thead>
              <tr className="border-b border-ink-200 text-left text-ink-500"><th className="py-2 font-medium">Collected by {brand().name}</th><th className="py-2 text-right font-medium">Amount</th></tr>
            </thead>
            <tbody>
              {data.lines.map((l) => (
                <tr key={l.label} className="border-b border-ink-100"><td className="py-2 text-ink-800">{l.label}</td><td className="py-2 text-right text-ink-900">{inr(l.amount)}</td></tr>
              ))}
              <tr><td className="pt-3 font-semibold text-ink-900">Net booking amount received</td><td className="pt-3 text-right font-semibold text-ink-900">{inr(data.total)}</td></tr>
              {!!data.booking_amount_pending && <tr><td className="py-1 text-ink-700">Booking amount still pending</td><td className="py-1 text-right text-ink-900">{inr(data.booking_amount_pending)}</td></tr>}
            </tbody>
          </table>
          {data.ride && (
            <section className="mt-6 rounded-lg bg-ink-50 p-4 text-sm print:border print:border-ink-200">
              <h2 className="font-semibold text-ink-900">Ride fare — billed and collected by the vendor/driver</h2>
              {(data.estimate_lines ?? []).length > 0 && (
                <ul className="mt-2 space-y-1 text-ink-700">
                  {(data.estimate_lines ?? []).map((l) => (
                    <li key={l.label} className="flex justify-between gap-3"><span>{l.label}</span><span>{inr(l.amount)}</span></li>
                  ))}
                </ul>
              )}
              <p className="mt-2 flex justify-between font-semibold text-ink-900"><span>Estimated ride fare</span><span>{inr(data.estimated_ride_fare)}</span></p>
              <p className="mt-1 flex justify-between text-ink-700"><span>Payable directly to {data.ride.vendor_name || 'the vendor/driver'}</span><span>{inr(data.ride.payable_to_vendor)}</span></p>
              {data.ride.vendor_invoice_number && <p className="mt-1 text-xs text-ink-600">Vendor invoice {data.ride.vendor_invoice_number}</p>}
            </section>
          )}
          {data.payments.length > 0 && (
            <section className="mt-6">
              <h2 className="text-xs font-semibold uppercase tracking-wide text-ink-500">Booking amount history</h2>
              <ul className="mt-2 space-y-1 text-sm text-ink-700">
                {data.payments.map((p) => (
                  <li key={p.id}>{p.created_at} · {p.entry_type === 'refund' ? 'Refund' : 'Booking amount'} {inr(p.amount)} via {p.method}{p.reference ? ` (${p.reference})` : ''}</li>
                ))}
              </ul>
            </section>
          )}
          {data.disclaimer && <p className="mt-6 text-xs leading-relaxed text-ink-600">{data.disclaimer}</p>}
          {data.company.footer && <p className="mt-8 border-t border-ink-100 pt-4 text-center text-xs text-ink-500">{data.company.footer}</p>}
        </article>
      )}
    </div>
  );
}
