import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import {
  approveVendorKyc,
  creditAdminVendorWallet,
  debitAdminVendorWallet,
  getAdminVendorDetail,
  getVendorDocumentUrl,
  rejectVendorKyc,
  saveVendorNotes,
  setVendorStatus,
  ApiError,
} from '../../lib/api';
import {
  getVendorFleet,
  saveVendorFleetEntity,
  deleteVendorFleetEntity,
  type FleetEntityKind,
  type FleetVehicle,
  type FleetDriver,
  setVendorType,
  startImpersonation,
  type DocValidity,
  type VendorFleet,
} from '../../lib/api-admin-finance';
import type { AdminVendorDetail, VendorStatus } from '../../types/api';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { hasAdminCap } from '../../lib/permissions';
import { EmptyState } from '../../components/ui/EmptyState';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';

const statusBadgeStyles: Record<string, string> = {
  pending: 'bg-warning-50 text-warning-600',
  active: 'bg-success-50 text-success-600',
  suspended: 'bg-warning-50 text-warning-600',
  blacklisted: 'bg-danger-50 text-danger-600',
};

const kycBadgeStyles: Record<string, string> = {
  pending: 'bg-ink-100 text-ink-600',
  submitted: 'bg-warning-50 text-warning-600',
  complete: 'bg-warning-50 text-warning-600',
  verified: 'bg-success-50 text-success-600',
  rejected: 'bg-danger-50 text-danger-600',
  expired_docs: 'bg-danger-50 text-danger-600',
};

const docBadgeStyles: Record<string, string> = {
  pending: 'bg-ink-100 text-ink-600',
  submitted: 'bg-warning-50 text-warning-600',
  verified: 'bg-success-50 text-success-600',
  rejected: 'bg-danger-50 text-danger-600',
};

function badgeClass(map: Record<string, string>, value: string): string {
  return map[value] ?? 'bg-ink-100 text-ink-600';
}

function humanize(value: string): string {
  return value
    .split('_')
    .map((part) => (part ? part[0].toUpperCase() + part.slice(1) : part))
    .join(' ');
}

function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

type StatusAction = { status: VendorStatus; label: string; confirmVariant: 'primary' | 'danger' };

const STATUS_ACTIONS: StatusAction[] = [
  { status: 'active', label: 'Activate', confirmVariant: 'primary' },
  { status: 'suspended', label: 'Suspend', confirmVariant: 'danger' },
  { status: 'blacklisted', label: 'Blacklist', confirmVariant: 'danger' },
];

/**
 * Mirrors ridego_get_vendor_status_transitions() (includes/vendor.php)
 * exactly. The status-action buttons must only offer legal transitions —
 * a blacklisted vendor can only be reinstated to active, never moved
 * straight to suspended, for example. Offering an illegal transition
 * used to just bounce back a raw server error instead of being caught
 * in the UI.
 */
const LEGAL_VENDOR_TRANSITIONS: Record<VendorStatus, VendorStatus[]> = {
  pending: ['active', 'suspended', 'blacklisted'],
  active: ['suspended', 'blacklisted'],
  suspended: ['active', 'blacklisted'],
  blacklisted: ['active'],
};

/** Mirrors ridego_set_vendor_status()'s $requires_reason check exactly. */
function vendorStatusChangeRequiresReason(current: VendorStatus, target: VendorStatus): boolean {
  return target === 'suspended' || target === 'blacklisted' || (current === 'blacklisted' && target === 'active');
}

const TABS = [
  { id: 'profile', label: '👤 Profile' },
  { id: 'wallet', label: '💳 Wallet' },
  { id: 'docs', label: '📄 Documents' },
  { id: 'actions', label: '⚡ Actions' },
] as const;

type TabId = (typeof TABS)[number]['id'];

function DetailRow({ label, value }: { label: string; value: string | number | null | undefined }) {
  if (value === null || value === undefined || value === '' || value === 0) return null;
  return (
    <div className="flex justify-between gap-4 border-b border-ink-50 py-1.5 text-sm last:border-b-0">
      <span className="text-ink-500">{label}</span>
      <span className="min-w-0 break-words text-right font-medium text-ink-800">{value}</span>
    </div>
  );
}

const DOC_VALIDITY_LABEL: Record<DocValidity, string> = {
  valid: 'Valid',
  expiring_soon: 'Expiring within 30 days',
  expired: 'Expired',
  no_expiry: 'No expiry date',
};

const DOC_VALIDITY_STYLE: Record<DocValidity, string> = {
  valid: 'bg-success-50 text-success-800',
  expiring_soon: 'bg-warning-50 text-warning-600',
  expired: 'bg-danger-50 text-danger-600',
  no_expiry: 'bg-ink-100 text-ink-600',
};

/** The vendor detail payload does not carry these fields today; they are read defensively if the API adds them. */
type VendorWithMarketplaceFields = AdminVendorDetail & { user_id?: number | string; vendor_type?: string };

// TRACE: vendor detail page render → marketplace controls for one vendor: type badge and change control
//        (cap ridego_manage_vendors), "View as this vendor" (cap ridego_impersonate) and a read-only fleet panel
//        (cap ridego_view_fleets) → renders the section or nothing when the user holds none of those caps.
//        Preconditions: vendor loaded → postconditions: type change re-fetches the fleet; view-as ends in a full page reload →
//        edge cases: fleet loading/error/empty states, stale fleet responses dropped, fleet→individual refusal shown verbatim,
//        missing user_id in the payload disables view-as with an explanation, double submit blocked.
function VendorMarketplacePanel({ vendorId, vendor }: { vendorId: number; vendor: VendorWithMarketplaceFields }) {
  const { user } = useAuth();
  const toast = useToast();
  const canViewFleet = hasAdminCap(user, 'ridego_view_fleets');
  const canManage = hasAdminCap(user, 'ridego_manage_vendors');
  const canImpersonate = hasAdminCap(user, 'ridego_impersonate_vendor');

  const [fleet, setFleet] = useState<VendorFleet | null>(null);
  const [fleetLoading, setFleetLoading] = useState(canViewFleet);
  const [fleetError, setFleetError] = useState<string | null>(null);
  const seq = useRef(0);

  const [typeDialog, setTypeDialog] = useState<'fleet' | 'individual' | null>(null);
  const [typeSaving, setTypeSaving] = useState(false);
  const [typeError, setTypeError] = useState<string | null>(null);

  const [viewAsOpen, setViewAsOpen] = useState(false);
  const [viewAsBusy, setViewAsBusy] = useState(false);
  const [viewAsError, setViewAsError] = useState<string | null>(null);

  // TRACE: mount / retry / after type change → GET vendor fleet → stores it.
  //        Preconditions: cap ridego_view_fleets → postconditions: latest request wins →
  //        edge cases: no capability skips the call, ApiError message shown, stale response dropped.
  const loadFleet = useCallback(async () => {
    if (!canViewFleet) return;
    const id = ++seq.current;
    setFleetLoading(true);
    setFleetError(null);
    try {
      const res = await getVendorFleet(vendorId);
      if (id !== seq.current) return;
      setFleet(res);
    } catch (err) {
      if (id !== seq.current) return;
      setFleetError(err instanceof ApiError ? err.message : 'Could not load the fleet. Please try again.');
    } finally {
      if (id === seq.current) setFleetLoading(false);
    }
  }, [vendorId, canViewFleet]);

  // TRACE: mount / vendor change → runs loadFleet; unmount → invalidates the in-flight request.
  //        Preconditions: none → postconditions: no state writes after unmount → edge cases: none.
  useEffect(() => {
    void loadFleet();
    return () => {
      seq.current += 1;
    };
  }, [loadFleet]);

  const currentType = fleet?.vendor_type ?? vendor.vendor_type ?? null;
  const otherType: 'fleet' | 'individual' | null = currentType === 'fleet' ? 'individual' : currentType === 'individual' ? 'fleet' : null;
  const userId = Number(vendor.user_id);
  const hasUserId = Number.isInteger(userId) && userId > 0;

  // TRACE: dialog cancel/Escape → closes the type dialog unless saving. Preconditions: none →
  //        postconditions: error cleared on next open → edge cases: ignored while saving.
  const closeType = useCallback(() => {
    if (!typeSaving) setTypeDialog(null);
  }, [typeSaving]);

  // TRACE: type dialog confirm → POST vendor type → toast, close, re-fetch the fleet.
  //        Preconditions: target type set → postconditions: vendor_type updated, no fleet rows deleted →
  //        edge cases: fleet→individual refusal (too many active vehicles/drivers) shown verbatim in the dialog and toast,
  //        double submit blocked.
  async function confirmType() {
    if (!typeDialog || typeSaving) return;
    setTypeSaving(true);
    setTypeError(null);
    try {
      const res = await setVendorType(vendorId, typeDialog);
      toast.show(res.message || `Vendor type changed to ${typeDialog}.`, 'success');
      setTypeDialog(null);
      await loadFleet();
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Could not change the vendor type.';
      setTypeError(msg);
      toast.show(msg, 'error');
    } finally {
      setTypeSaving(false);
    }
  }

  // TRACE: view-as dialog cancel/Escape → closes it unless the request is in flight.
  //        Preconditions: none → postconditions: none → edge cases: ignored while busy.
  const closeViewAs = useCallback(() => {
    if (!viewAsBusy) setViewAsOpen(false);
  }, [viewAsBusy]);

  // TRACE: view-as dialog confirm → POST impersonate {user_id} → full page load of the vendor dashboard so the nonce and
  //        cookies switch to the vendor session.
  //        Preconditions: cap ridego_impersonate and a user id → postconditions: signed session cookie set, page navigates →
  //        edge cases: API refusal (self, admin account, unknown user) shown verbatim and toasted, button stays busy after success
  //        so it cannot be clicked twice before the reload.
  async function confirmViewAs() {
    if (viewAsBusy || !hasUserId) return;
    setViewAsBusy(true);
    setViewAsError(null);
    try {
      await startImpersonation(userId);
      window.location.assign('/vendor/dashboard');
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Could not start the view-as session.';
      setViewAsError(msg);
      toast.show(msg, 'error');
      setViewAsBusy(false);
    }
  }

  if (!canViewFleet && !canManage && !canImpersonate) return null;

  return (
    <section className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs sm:p-6" aria-labelledby="mkt-heading">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 id="mkt-heading" className="text-base font-semibold text-ink-900">
            Marketplace
          </h3>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-sm">
            <span className="text-ink-500">Vendor type:</span>
            {currentType ? (
              <span className="rounded-full bg-brand-100 px-2.5 py-1 text-xs font-semibold text-brand-800">
                {currentType === 'fleet' ? 'Fleet' : 'Individual'}
              </span>
            ) : (
              <span className="text-ink-500">{canViewFleet && fleetLoading ? 'Loading…' : 'Not available'}</span>
            )}
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {canManage && otherType && (
            <Button
              variant="secondary"
              onClick={() => {
                setTypeError(null);
                setTypeDialog(otherType);
              }}
            >
              Change type
            </Button>
          )}
          {canImpersonate && (
            <Button
              variant="secondary"
              disabled={!hasUserId}
              onClick={() => {
                setViewAsError(null);
                setViewAsOpen(true);
              }}
            >
              View as this vendor
            </Button>
          )}
        </div>
      </div>
      {canImpersonate && !hasUserId && (
        <p className="mt-2 text-xs text-ink-500">View-as is unavailable because this vendor record does not include its account user id.</p>
      )}

      {canViewFleet && (
        <div className="mt-5 border-t border-ink-100 pt-4">
          <h4 className="text-sm font-bold text-ink-900">Fleet (read-only)</h4>
          {fleetLoading && (
            <div className="mt-3 space-y-2" aria-busy="true" aria-label="Loading fleet">
              <Skeleton className="h-10 w-full rounded-lg" />
              <Skeleton className="h-10 w-full rounded-lg" />
            </div>
          )}
          {!fleetLoading && fleetError && (
            <div className="mt-3">
              <ErrorBanner message={fleetError} onRetry={loadFleet} />
            </div>
          )}
          {!fleetLoading && !fleetError && fleet && (
            <FleetTables fleet={fleet} vendorId={vendorId} canManage={hasAdminCap(user, 'ridego_manage_fleet_vehicles')} onChanged={loadFleet} />
          )}
        </div>
      )}

      <ConfirmDialog
        open={!!typeDialog}
        title={`Change ${vendor.business_name} to ${typeDialog === 'fleet' ? 'a fleet' : 'an individual'} vendor?`}
        description={
          typeDialog === 'individual'
            ? 'An individual vendor has one vehicle and one driver. This is refused while more than one vehicle or driver is active. No fleet records are deleted.'
            : 'A fleet vendor manages several vehicles, drivers and branches. Existing records are kept.'
        }
        confirmLabel="Change type"
        loading={typeSaving}
        onConfirm={confirmType}
        onCancel={closeType}
      >
        {typeError && (
          <p role="alert" className="text-sm text-danger-600">
            {typeError}
          </p>
        )}
      </ConfirmDialog>

      <ConfirmDialog
        open={viewAsOpen}
        title={`View as ${vendor.business_name}?`}
        description={
          <>
            <p>You will see the vendor app exactly as this vendor sees it.</p>
            <ul className="mt-2 list-disc space-y-1 pl-5">
              <li>The session is time-limited and ends automatically.</li>
              <li>Every start and stop is recorded in the audit log.</li>
              <li>Passwords, profile details and payouts cannot be changed while viewing as this vendor.</li>
            </ul>
          </>
        }
        confirmLabel="Start view-as session"
        loading={viewAsBusy}
        onConfirm={confirmViewAs}
        onCancel={closeViewAs}
      >
        {viewAsError && (
          <p role="alert" className="text-sm text-danger-600">
            {viewAsError}
          </p>
        )}
      </ConfirmDialog>
    </section>
  );
}

// TRACE: constant → driver-profile keys editable by an admin override (mirrors ridego_driver_required_fields + optional fields in fleet.php). Pure.
const DRIVER_PROFILE_KEYS = ['alt_mobile', 'date_of_birth', 'blood_group', 'address', 'city', 'pincode', 'license_class', 'badge_number', 'emergency_contact_name', 'emergency_contact_phone', 'emergency_contact_relation', 'id_proof_type', 'id_proof_number', 'police_verification_status', 'police_verification_date'];
// TRACE: constant → field key → allowed option values rendered as a select in the admin driver editor. Pure.
const DRIVER_SELECTS: Record<string, string[]> = {
  blood_group: ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
  license_class: ['LMV', 'LMV-TR', 'HMV', 'HPMV', 'MCWG'],
  id_proof_type: ['aadhaar', 'voter_id', 'passport', 'pan'],
  police_verification_status: ['none', 'pending', 'verified'],
};

// TRACE: fleet payload → read-only tables for vehicles, drivers, branches and documents with validity text badges.
//        Preconditions: loaded VendorFleet → postconditions: pure render →
//        edge cases: an empty list shows an empty-state message, documents resolve their vehicle/driver name from the lists,
//        validity is text, never colour alone.
function FleetTables({ fleet, vendorId, canManage, onChanged }: { fleet: VendorFleet; vendorId: number; canManage: boolean; onChanged: () => void }) {
  const toast = useToast();
  const [editor, setEditor] = useState<{ kind: FleetEntityKind; id?: number | string; values: Record<string, string> } | null>(null);
  const [removal, setRemoval] = useState<{ kind: FleetEntityKind; id: number | string; label: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [dialogError, setDialogError] = useState<string | null>(null);

  // TRACE: Add/Edit click → opens the editor pre-filled with that row's current values (or blanks for a new row) → state set.
  //        kind + optional row → editor state → edge cases: previous error cleared, values copied as strings so edits never mutate the fleet payload.
  function openEditor(kind: FleetEntityKind, row?: FleetVehicle | FleetDriver) {
    setDialogError(null);
    if (kind === 'vehicles') {
      const v = row as FleetVehicle | undefined;
      setEditor({ kind, id: v?.id, values: { make_model: v?.make_model ?? '', registration_number: v?.registration_number ?? '', seating_capacity: String(v?.seating_capacity ?? 4), status: v?.status ?? 'active' } });
    } else {
      const d = row as FleetDriver | undefined;
      setEditor({ kind, id: d?.id, values: { name: d?.name ?? '', mobile: d?.mobile ?? '', license_number: d?.license_number ?? '', license_expiry: d?.license_expiry ?? '', experience_years: String(d?.experience_years ?? 0), status: d?.status ?? 'active', ...Object.fromEntries(DRIVER_PROFILE_KEYS.map((k) => [k, typeof d?.[k] === 'string' ? (d[k] as string).replace('0000-00-00', '') : ''])) } });
    }
  }

  // TRACE: editor Save → one create/update request (busy blocks double submit) → success toast + editor closes + list reloads;
  //        failure keeps the editor open with the server message inline. Edge cases: individual vendor add refused (message shown).
  async function submitEditor() {
    if (!editor || busy) return;
    setBusy(true);
    setDialogError(null);
    try {
      const res = await saveVendorFleetEntity(vendorId, editor.kind, editor.values, editor.id);
      toast.show(res.message ?? 'Saved.', 'success');
      setEditor(null);
      onChanged();
    } catch (err) {
      setDialogError(err instanceof ApiError ? err.message : 'Could not save. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  // TRACE: removal confirm → DELETE request once → toast, dialog closes, list reloads; failure message inline and the row stays.
  async function confirmRemoval() {
    if (!removal || busy) return;
    setBusy(true);
    setDialogError(null);
    try {
      const res = await deleteVendorFleetEntity(vendorId, removal.kind, removal.id);
      toast.show(res.message ?? 'Deleted.', 'success');
      setRemoval(null);
      onChanged();
    } catch (err) {
      setDialogError(err instanceof ApiError ? err.message : 'Could not delete. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  // TRACE: document's vehicle id → readable vehicle name from the fleet list → string.
  //        Preconditions: fleet loaded → postconditions: pure → edge cases: unknown id falls back to "Vehicle #id".
  const vehicleName = (vid: number | string | null): string => {
    const v = fleet.vehicles.find((x) => String(x.id) === String(vid));
    return v ? `${v.make_model} ${v.registration_number}`.trim() : `Vehicle #${vid}`;
  };
  // TRACE: document's driver id → driver name from the fleet list → string.
  //        Preconditions: fleet loaded → postconditions: pure → edge cases: unknown id falls back to "Driver #id".
  const driverName = (did: number | string | null): string => fleet.drivers.find((x) => String(x.id) === String(did))?.name ?? `Driver #${did}`;
  const nothing = fleet.vehicles.length + fleet.drivers.length + fleet.branches.length + fleet.docs.length === 0;
  if (nothing && !canManage) return <div className="mt-3"><EmptyState title="No fleet records" description="This vendor has no vehicles, drivers, branches or fleet documents." /></div>;
  const th = 'px-3 py-2 text-left text-xs font-medium uppercase tracking-wide text-ink-500';
  const td = 'px-3 py-2 text-ink-800';
  return (
    <>
    <div className="mt-3 space-y-5">
      <div>
        <div className="flex items-center justify-between gap-2">
          <h5 className="text-sm font-semibold text-ink-800">Vehicles ({fleet.vehicles.length})</h5>
          {canManage && <Button size="sm" variant="secondary" onClick={() => openEditor('vehicles')}>Add vehicle</Button>}
        </div>
        {fleet.vehicles.length === 0 ? <p className="mt-1 text-sm text-ink-500">None registered.</p> : (
          <div className="mt-2 overflow-x-auto rounded-lg border border-ink-100">
            <table className="w-full min-w-[480px] text-sm">
              <thead className="bg-ink-50"><tr><th className={th}>Vehicle</th><th className={th}>Registration</th><th className={th}>Seats</th><th className={th}>Status</th>{canManage && <th className={th}><span className="sr-only">Actions</span></th>}</tr></thead>
              <tbody className="divide-y divide-ink-100">
                {fleet.vehicles.map((v) => (
                  <tr key={String(v.id)}><td className={td}>{v.make_model || '—'}</td><td className={td}>{v.registration_number || '—'}</td><td className={td}>{v.seating_capacity}</td><td className={td}>{humanize(v.status)}</td>
                    {canManage && (
                      <td className={`${td} whitespace-nowrap text-right`}>
                        <Button size="sm" variant="ghost" aria-label={`Edit vehicle ${v.registration_number || v.make_model}`} onClick={() => openEditor('vehicles', v)}>Edit</Button>
                        <Button size="sm" variant="ghost" aria-label={`Delete vehicle ${v.registration_number || v.make_model}`} onClick={() => { setDialogError(null); setRemoval({ kind: 'vehicles', id: v.id, label: `${v.make_model} ${v.registration_number}`.trim() || `vehicle #${v.id}` }); }}>Delete</Button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <div>
        <div className="flex items-center justify-between gap-2">
          <h5 className="text-sm font-semibold text-ink-800">Drivers ({fleet.drivers.length})</h5>
          {canManage && <Button size="sm" variant="secondary" onClick={() => openEditor('drivers')}>Add driver</Button>}
        </div>
        {fleet.drivers.length === 0 ? <p className="mt-1 text-sm text-ink-500">None registered.</p> : (
          <div className="mt-2 overflow-x-auto rounded-lg border border-ink-100">
            <table className="w-full min-w-[620px] text-sm">
              <thead className="bg-ink-50"><tr><th className={th}>Name</th><th className={th}>Mobile</th><th className={th}>Licence</th><th className={th}>Licence expiry</th><th className={th}>Status</th>{canManage && <th className={th}><span className="sr-only">Actions</span></th>}</tr></thead>
              <tbody className="divide-y divide-ink-100">
                {fleet.drivers.map((d) => (
                  <tr key={String(d.id)}><td className={td}>{d.name || '—'}</td><td className={td}>{d.mobile || '—'}</td><td className={td}>{d.license_number || '—'}</td><td className={td}>{d.license_expiry ?? '—'}</td><td className={td}>{humanize(d.status)}</td>
                    {canManage && (
                      <td className={`${td} whitespace-nowrap text-right`}>
                        <Button size="sm" variant="ghost" aria-label={`Edit driver ${d.name}`} onClick={() => openEditor('drivers', d)}>Edit</Button>
                        <Button size="sm" variant="ghost" aria-label={`Delete driver ${d.name}`} onClick={() => { setDialogError(null); setRemoval({ kind: 'drivers', id: d.id, label: d.name || `driver #${d.id}` }); }}>Delete</Button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      <div>
        <h5 className="text-sm font-semibold text-ink-800">Branches ({fleet.branches.length})</h5>
        {fleet.branches.length === 0 ? <p className="mt-1 text-sm text-ink-500">None registered.</p> : (
          <ul className="mt-2 divide-y divide-ink-100 rounded-lg border border-ink-100 text-sm">
            {fleet.branches.map((b) => (
              <li key={String(b.id)} className="px-3 py-2 text-ink-800">
                <span className="font-medium">{b.name}</span>
                {Number(b.is_primary) === 1 ? ' (primary)' : ''}
                <span className="text-ink-500"> &middot; {b.city_name || 'no city'} &middot; {humanize(b.status)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
      <div>
        <h5 className="text-sm font-semibold text-ink-800">Documents ({fleet.docs.length})</h5>
        {fleet.docs.length === 0 ? <p className="mt-1 text-sm text-ink-500">None uploaded.</p> : (
          <div className="mt-2 overflow-x-auto rounded-lg border border-ink-100">
            <table className="w-full min-w-[520px] text-sm">
              <thead className="bg-ink-50"><tr><th className={th}>Belongs to</th><th className={th}>Document</th><th className={th}>Review status</th><th className={th}>Expiry</th><th className={th}>Validity</th></tr></thead>
              <tbody className="divide-y divide-ink-100">
                {fleet.docs.map((d) => (
                  <tr key={String(d.id)}>
                    <td className={td}>{d.vehicle_id ? vehicleName(d.vehicle_id) : driverName(d.driver_id)}</td>
                    <td className={td}>{humanize(d.doc_type)}</td>
                    <td className={td}>{humanize(d.status)}</td>
                    <td className={td}>{d.expiry_date ?? '—'}</td>
                    <td className={td}><span className={`rounded-full px-2 py-0.5 text-xs font-medium ${DOC_VALIDITY_STYLE[d.validity] ?? DOC_VALIDITY_STYLE.no_expiry}`}>{DOC_VALIDITY_LABEL[d.validity] ?? humanize(d.validity)}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
    <ConfirmDialog
      open={editor !== null}
      title={editor ? `${editor.id ? 'Edit' : 'Add'} ${editor.kind === 'vehicles' ? 'vehicle' : 'driver'}` : ''}
      description="Changes are made on the vendor's behalf and recorded in the audit log."
      confirmLabel="Save"
      confirmVariant="primary"
      loading={busy}
      onConfirm={() => void submitEditor()}
      onCancel={() => { if (!busy) { setEditor(null); setDialogError(null); } }}
    >
      {editor && (
        <div className="mt-3 grid max-h-[60vh] gap-3 overflow-y-auto pr-1">
          {Object.keys(editor.values).map((k) => (
            <label key={k} className="block text-sm text-ink-700">
              <span className="mb-1 block font-medium">{humanize(k)}</span>
              {k === 'status' ? (
                <select value={editor.values[k]} onChange={(e) => setEditor({ ...editor, values: { ...editor.values, [k]: e.target.value } })} className="w-full rounded-lg border border-ink-200 px-3 py-2 text-sm">
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              ) : (
                DRIVER_SELECTS[k] ? (
                  <select value={editor.values[k]} onChange={(e) => setEditor({ ...editor, values: { ...editor.values, [k]: e.target.value } })} className="w-full rounded-lg border border-ink-200 px-3 py-2 text-sm">
                    <option value="">Select</option>
                    {DRIVER_SELECTS[k].map((o) => <option key={o} value={o}>{humanize(o)}</option>)}
                  </select>
                ) : <input
                  type={k === 'license_expiry' || k === 'date_of_birth' || k === 'police_verification_date' ? 'date' : k === 'seating_capacity' || k === 'experience_years' ? 'number' : 'text'}
                  value={editor.values[k]}
                  onChange={(e) => setEditor({ ...editor, values: { ...editor.values, [k]: e.target.value } })}
                  className="w-full rounded-lg border border-ink-200 px-3 py-2 text-sm"
                />
              )}
            </label>
          ))}
          {dialogError && <p role="alert" className="text-sm text-danger-600">{dialogError}</p>}
        </div>
      )}
    </ConfirmDialog>
    <ConfirmDialog
      open={removal !== null}
      title={removal ? `Delete ${removal.label}?` : ''}
      description="This removes the record from the vendor's fleet. Past trips keep their snapshot of the driver and vehicle."
      confirmLabel="Delete"
      confirmVariant="danger"
      loading={busy}
      onConfirm={() => void confirmRemoval()}
      onCancel={() => { if (!busy) { setRemoval(null); setDialogError(null); } }}
    >
      {dialogError && <p role="alert" className="mt-2 text-sm text-danger-600">{dialogError}</p>}
    </ConfirmDialog>
    </>
  );
}

// TRACE: route /app/admin/vendors/:id → vendor profile, KYC, wallet, documents and actions, plus the marketplace panel
//        (type, view-as, fleet) → renders the detail view.
//        Preconditions: vendor id in the URL → postconditions: existing behaviour unchanged; panel added below the summary card →
//        edge cases: not found, load error with retry, loading skeleton (existing), panel hidden without marketplace capabilities.
export function AdminVendorDetailPage() {
  const { id } = useParams<{ id: string }>();
  const vendorId = Number(id);

  const [vendor, setVendor] = useState<AdminVendorDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [searchParams] = useSearchParams();
  const initialTabParam = searchParams.get('tab');
  const initialTab: TabId = TABS.some((t) => t.id === initialTabParam) ? (initialTabParam as TabId) : 'profile';
  const [tab, setTab] = useState<TabId>(initialTab);

  // KYC approve dialog state.
  const [showApprove, setShowApprove] = useState(false);
  const [approving, setApproving] = useState(false);
  const [approveError, setApproveError] = useState<string | null>(null);
  // Root-cause fix (KYC approved without documents): set when the server refuses approval (409) because
  // required documents are missing — surfaced here so the dialog can offer "Approve anyway" instead of
  // just showing the error text and dead-ending.
  const [missingDocs, setMissingDocs] = useState<string[] | null>(null);

  // KYC reject dialog state.
  const [showReject, setShowReject] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [rejecting, setRejecting] = useState(false);
  const [rejectError, setRejectError] = useState<string | null>(null);

  // Status change dialog state.
  const [statusAction, setStatusAction] = useState<StatusAction | null>(null);
  const [statusReason, setStatusReason] = useState('');
  const [changingStatus, setChangingStatus] = useState(false);
  const [statusError, setStatusError] = useState<string | null>(null);

  // Wallet adjust.
  const [walletAmount, setWalletAmount] = useState('');
  const [walletNotes, setWalletNotes] = useState('');
  const [walletBusy, setWalletBusy] = useState<'credit' | 'debit' | null>(null);
  const [walletError, setWalletError] = useState<string | null>(null);
  const [walletMessage, setWalletMessage] = useState<string | null>(null);

  // Admin notes.
  const [notes, setNotes] = useState('');
  const [savingNotes, setSavingNotes] = useState(false);
  const [notesError, setNotesError] = useState<string | null>(null);
  const [notesSaved, setNotesSaved] = useState(false);

  // Document viewer.
  const [docLoading, setDocLoading] = useState<number | null>(null);

  const load = useCallback(async () => {
    if (!vendorId || Number.isNaN(vendorId)) {
      setNotFound(true);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    setNotFound(false);
    try {
      const res = await getAdminVendorDetail(vendorId);
      setVendor(res);
      setNotes(res.notes_admin || '');
    } catch (err) {
      if (err instanceof ApiError && (err.status === 404 || err.code === 'not_found')) {
        setNotFound(true);
      } else if (err instanceof ApiError && err.code === 'forbidden') {
        setError("You don't have permission to manage vendors.");
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not load this vendor. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  }, [vendorId]);

  useEffect(() => {
    load();
  }, [load]);

  async function refetch() {
    setRefreshing(true);
    try {
      const res = await getAdminVendorDetail(vendorId);
      setVendor(res);
      setNotes(res.notes_admin || '');
    } catch {
      // If the refetch fails after a successful action, keep showing stale
      // data rather than replacing a success with an error.
    } finally {
      setRefreshing(false);
    }
  }

  async function confirmApprove(force = false) {
    setApproving(true);
    setApproveError(null);
    try {
      await approveVendorKyc(vendorId, force);
      setShowApprove(false);
      setMissingDocs(null);
      await refetch();
    } catch (err) {
      if (err instanceof ApiError && err.code === 'missing_documents') {
        setMissingDocs((err.data as { missing_docs?: string[] } | undefined)?.missing_docs ?? []);
        setApproveError(err.message);
      } else {
        setApproveError(err instanceof ApiError ? err.message : 'Could not approve KYC.');
      }
    } finally {
      setApproving(false);
    }
  }

  async function confirmReject() {
    if (!rejectReason.trim()) return;
    setRejecting(true);
    setRejectError(null);
    try {
      await rejectVendorKyc(vendorId, { reason: rejectReason.trim() });
      setShowReject(false);
      setRejectReason('');
      await refetch();
    } catch (err) {
      setRejectError(err instanceof ApiError ? err.message : 'Could not reject KYC.');
    } finally {
      setRejecting(false);
    }
  }

  async function confirmStatusChange() {
    if (!statusAction) return;
    setChangingStatus(true);
    setStatusError(null);
    try {
      await setVendorStatus(vendorId, { status: statusAction.status, reason: statusReason.trim() || undefined });
      setStatusAction(null);
      setStatusReason('');
      await refetch();
    } catch (err) {
      setStatusError(err instanceof ApiError ? err.message : 'Could not update vendor status.');
    } finally {
      setChangingStatus(false);
    }
  }

  async function submitWallet(kind: 'credit' | 'debit') {
    const amt = Number(walletAmount);
    if (!amt || amt <= 0) return;
    setWalletBusy(kind);
    setWalletError(null);
    setWalletMessage(null);
    try {
      const res =
        kind === 'credit'
          ? await creditAdminVendorWallet(vendorId, amt, walletNotes.trim() || undefined)
          : await debitAdminVendorWallet(vendorId, amt, walletNotes.trim() || undefined);
      setWalletMessage(res.message || (kind === 'credit' ? 'Wallet credited.' : 'Wallet debited.'));
      setWalletAmount('');
      setWalletNotes('');
      await refetch();
    } catch (err) {
      setWalletError(err instanceof ApiError ? err.message : `Could not ${kind} wallet.`);
    } finally {
      setWalletBusy(null);
    }
  }

  async function submitNotes() {
    setSavingNotes(true);
    setNotesError(null);
    setNotesSaved(false);
    try {
      await saveVendorNotes(vendorId, notes);
      setNotesSaved(true);
    } catch (err) {
      setNotesError(err instanceof ApiError ? err.message : 'Could not save notes.');
    } finally {
      setSavingNotes(false);
    }
  }

  async function viewDocument(docId: number, path: string) {
    setDocLoading(docId);
    try {
      const url = await getVendorDocumentUrl(path);
      window.open(url, '_blank', 'noopener,noreferrer');
    } finally {
      setDocLoading(null);
    }
  }

  if (notFound) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <div className="rounded-2xl border border-ink-100 bg-ink-50/60 p-10">
          <h1 className="text-xl font-bold text-ink-900">Vendor not found</h1>
          <p className="mt-2 text-ink-500">This vendor doesn't exist or may have been removed.</p>
          <div className="mt-6">
            <Link to="/admin/vendors">
              <Button variant="secondary">Back to vendor list</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const canReviewKyc = vendor && vendor.status === 'pending' && ['submitted', 'complete'].includes(vendor.kyc_status);

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Link to="/admin/vendors" className="text-sm font-medium text-brand-700 hover:text-brand-800">
            ← Back to vendor list
          </Link>
          <h1 className="mt-1 text-2xl font-bold text-ink-900 sm:text-3xl">Vendor details</h1>
        </div>
        {refreshing && <span className="text-sm text-ink-400">Refreshing…</span>}
      </div>

      {loading && (
        <div className="mt-6 space-y-6" aria-busy="true" aria-label="Loading vendor">
          <div className="grid gap-4 sm:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="rounded-xl border border-ink-100 p-5">
                <Skeleton className="h-3 w-20" />
                <Skeleton className="mt-3 h-7 w-28" />
              </div>
            ))}
          </div>
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-16 w-full rounded-xl" />
          ))}
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {!loading && !error && vendor && (
        <>
          <div className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs sm:p-6">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-ink-900">{vendor.business_name}</h2>
                <p className="mt-1 text-sm text-ink-500">
                  {vendor.owner_name} &middot; {humanize(vendor.business_type || 'individual')} &middot; {vendor.total_vehicles} vehicle
                  {vendor.total_vehicles === 1 ? '' : 's'}
                </p>
                <p className="mt-1 text-sm text-ink-500">
                  {vendor.phone} &middot; {vendor.email} &middot; {vendor.city}
                </p>
                <p className="mt-1 text-xs text-ink-400">Joined {vendor.joined_at}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${badgeClass(statusBadgeStyles, vendor.status)}`}>
                  {humanize(vendor.status)}
                </span>
                <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${badgeClass(kycBadgeStyles, vendor.kyc_status)}`}>
                  KYC: {humanize(vendor.kyc_status)}
                </span>
                {vendor.kyc_status === 'verified' && vendor.kyc_missing_docs.length > 0 && (
                  <span
                    className="rounded-full bg-warning-50 px-2.5 py-1 text-xs font-semibold text-warning-600"
                    title="Approved without all required documents on file"
                  >
                    ⚠️ Missing: {vendor.kyc_missing_docs.map((d) => d.replace(/_/g, ' ')).join(', ')}
                  </span>
                )}
              </div>
            </div>

            {/* Leads / rides / fees / wallet KPI strip */}
            <div className="mt-5 grid gap-4 border-t border-ink-100 pt-4 sm:grid-cols-5">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Total leads</p>
                <p className="mt-1 text-lg font-bold text-ink-900">{vendor.kpis.total_leads}</p>
              </div>
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Accepted</p>
                <p className="mt-1 text-lg font-bold text-success-600">{vendor.kpis.accepted_leads}</p>
              </div>
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Completed rides</p>
                <p className="mt-1 text-lg font-bold text-ink-900">{vendor.kpis.completed_rides}</p>
              </div>
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Fees paid</p>
                <p className="mt-1 text-lg font-bold text-ink-900">{currency(vendor.kpis.fees_paid)}</p>
              </div>
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Wallet balance</p>
                <p className={`mt-1 text-lg font-bold ${vendor.wallet_balance < 200 ? 'text-danger-600' : 'text-ink-900'}`}>
                  {currency(vendor.wallet_balance)}
                </p>
              </div>
            </div>
          </div>

          <VendorMarketplacePanel vendorId={vendorId} vendor={vendor} />

          {canReviewKyc && (
            <div className="mt-6 rounded-xl border border-brand-200 bg-brand-50/40 p-5 shadow-xs sm:p-6">
              <h3 className="text-base font-semibold text-ink-900">KYC review needed</h3>
              <p className="mt-1 text-sm text-ink-600">
                This vendor's documents are ready for review. Approve to activate them, or reject with a reason.
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Button
                  onClick={() => {
                    setShowApprove(true);
                    setApproveError(null);
                    setMissingDocs(null);
                  }}
                >
                  Approve KYC
                </Button>
                <Button
                  variant="danger"
                  onClick={() => {
                    setShowReject(true);
                    setRejectReason('');
                    setRejectError(null);
                  }}
                >
                  Reject KYC
                </Button>
              </div>
            </div>
          )}

          {/* Tabs */}
          <div className="mt-6 flex flex-wrap gap-1 border-b border-ink-100">
            {TABS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={`rounded-t-lg px-3.5 py-2 text-sm font-semibold transition-colors ${
                  tab === t.id ? 'border-b-2 border-brand-600 text-brand-700' : 'text-ink-500 hover:text-ink-800'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Profile tab */}
          {tab === 'profile' && (
            <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
                <h3 className="text-sm font-bold text-ink-900">Business Details</h3>
                <div className="mt-2">
                  <DetailRow label="Business Name" value={vendor.business_name} />
                  <DetailRow label="Owner Name" value={vendor.owner_name} />
                  <DetailRow label="Phone" value={vendor.phone} />
                  <DetailRow label="Alt Phone" value={vendor.alt_phone} />
                  <DetailRow label="Email" value={vendor.email} />
                  <DetailRow label="WhatsApp" value={vendor.whatsapp_number} />
                  <DetailRow label="Business Type" value={humanize(vendor.business_type)} />
                  <DetailRow label="GST Number" value={vendor.gst_number} />
                  <DetailRow label="PAN Number" value={vendor.pan_number} />
                  <DetailRow label="License #" value={vendor.license_number} />
                  <DetailRow label="Insurance Policy" value={vendor.insurance_policy} />
                  <DetailRow label="Address" value={vendor.address} />
                </div>
              </div>
              <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
                <h3 className="text-sm font-bold text-ink-900">Operations & Account</h3>
                <div className="mt-2">
                  <DetailRow label="Base City" value={vendor.city} />
                  <DetailRow label="Operating Cities" value={vendor.operating_cities} />
                  <DetailRow label="Vehicle Types" value={vendor.vehicle_types} />
                  <DetailRow label="Total Vehicles" value={vendor.total_vehicles} />
                  <DetailRow label="Years Experience" value={vendor.years_experience ? `${vendor.years_experience} yrs` : ''} />
                  <DetailRow label="Documents Verified" value={vendor.documents_verified ? '✅ Yes' : '❌ No'} />
                  <DetailRow label="Background Check" value={vendor.background_check ? '✅ Passed' : 'Pending'} />
                  <DetailRow label="Total Rides" value={vendor.total_rides_completed} />
                  <DetailRow label="Rating" value={vendor.rating ? `${vendor.rating} ⭐` : 'Not rated'} />
                  <DetailRow label="Commission %" value={vendor.commission_pct ? `${vendor.commission_pct}%` : ''} />
                  <DetailRow label="Joined" value={vendor.joined_at} />
                </div>
              </div>
              <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
                <h3 className="text-sm font-bold text-ink-900">Bank & Payment</h3>
                <div className="mt-2">
                  <DetailRow label="Bank Name" value={vendor.bank_name} />
                  <DetailRow label="Account No" value={vendor.bank_account} />
                  <DetailRow label="IFSC Code" value={vendor.bank_ifsc} />
                  <DetailRow label="Account Holder" value={vendor.bank_holder} />
                  <DetailRow label="UPI ID" value={vendor.upi_id} />
                  {!vendor.bank_name && !vendor.bank_account && !vendor.upi_id && (
                    <p className="text-sm text-ink-400">No bank/payment details on file.</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Wallet tab */}
          {tab === 'wallet' && (
            <div className="mt-5 grid gap-4 lg:grid-cols-2">
              <div className="rounded-xl border border-ink-100 p-5 shadow-xs">
                <h3 className="text-sm font-bold text-ink-900">💳 Current Balance</h3>
                <p className={`mt-2 text-4xl font-extrabold tracking-tight ${vendor.wallet_balance < 200 ? 'text-danger-600' : 'text-success-600'}`}>
                  {currency(vendor.wallet_balance)}
                </p>
                {vendor.wallet_balance < 200 && (
                  <div className="mt-2 rounded-lg border border-warning-500/30 bg-warning-50 px-3 py-2 text-sm text-warning-700">
                    ⚠️ Balance below ₹200 minimum. Vendor cannot receive new leads.
                  </div>
                )}
                <div className="mt-5 border-t border-ink-100 pt-4">
                  <h4 className="text-sm font-bold text-ink-900">Adjust Wallet</h4>
                  {walletMessage && <p className="mt-2 text-sm text-success-600">{walletMessage}</p>}
                  {walletError && <p className="mt-2 text-sm text-danger-600">{walletError}</p>}
                  <div className="mt-3 flex flex-wrap gap-2">
                    <input
                      type="number"
                      min={1}
                      step="0.01"
                      value={walletAmount}
                      onChange={(e) => setWalletAmount(e.target.value)}
                      placeholder="Amount ₹"
                      className="w-32 rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                      aria-label="Wallet adjustment amount"
                    />
                    <input
                      type="text"
                      value={walletNotes}
                      onChange={(e) => setWalletNotes(e.target.value)}
                      placeholder="Reason / notes"
                      className="min-w-[160px] flex-1 rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                      aria-label="Wallet adjustment reason"
                    />
                  </div>
                  <div className="mt-3 flex gap-2">
                    <Button
                      size="sm"
                      loading={walletBusy === 'credit'}
                      disabled={!walletAmount || Number(walletAmount) <= 0}
                      onClick={() => submitWallet('credit')}
                    >
                      + Credit Wallet
                    </Button>
                    <Button
                      size="sm"
                      variant="danger"
                      loading={walletBusy === 'debit'}
                      disabled={!walletAmount || Number(walletAmount) <= 0}
                      onClick={() => submitWallet('debit')}
                    >
                      − Deduct
                    </Button>
                  </div>
                </div>
              </div>
              <div className="rounded-xl border border-ink-100 p-5 shadow-xs">
                <h3 className="text-sm font-bold text-ink-900">📜 Transaction History</h3>
                {vendor.wallet_history.length > 0 ? (
                  <>
                    <div className="mt-3 hidden overflow-x-auto lg:block">
                      <table className="min-w-full divide-y divide-ink-100 text-xs">
                        <thead>
                          <tr>
                            <th className="py-1.5 text-left font-semibold text-ink-500">Date</th>
                            <th className="py-1.5 text-left font-semibold text-ink-500">Type</th>
                            <th className="py-1.5 text-left font-semibold text-ink-500">Amount</th>
                            <th className="py-1.5 text-left font-semibold text-ink-500">Notes</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-ink-50">
                          {vendor.wallet_history.map((tx) => (
                            <tr key={tx.id}>
                              <td className="py-1.5 text-ink-600">{tx.created_at}</td>
                              <td className="py-1.5 text-ink-600">{humanize(tx.type)}</td>
                              <td className={`py-1.5 font-semibold ${tx.amount >= 0 ? 'text-success-600' : 'text-danger-600'}`}>
                                {currency(Math.abs(tx.amount))}
                              </td>
                              <td className="py-1.5 text-ink-400">{tx.notes?.slice(0, 40)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    <div className="mt-3 space-y-2 lg:hidden">
                      {vendor.wallet_history.map((tx) => (
                        <div key={tx.id} className="rounded-xl border border-ink-100 bg-white p-3">
                          <div className="flex items-start justify-between gap-3">
                            <span className="text-xs font-medium text-ink-800">{humanize(tx.type)}</span>
                            <span className={`shrink-0 text-sm font-semibold ${tx.amount >= 0 ? 'text-success-600' : 'text-danger-600'}`}>
                              {tx.amount >= 0 ? '+' : '−'}
                              {currency(Math.abs(tx.amount))}
                            </span>
                          </div>
                          <p className="mt-1 text-xs text-ink-500">{tx.created_at}</p>
                          {tx.notes && <p className="mt-0.5 text-xs text-ink-400">{tx.notes.slice(0, 60)}</p>}
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <p className="mt-3 text-sm text-ink-500">No transactions yet.</p>
                )}
              </div>
            </div>
          )}

          {/* Documents tab */}
          {tab === 'docs' && (
            <div className="mt-5">
              {vendor.docs.length === 0 ? (
                <div className="rounded-xl border border-ink-100 p-8 text-center text-sm text-ink-500">
                  <p className="text-2xl">📄</p>
                  <p className="mt-2 font-semibold text-ink-700">No documents uploaded</p>
                  <p className="mt-1">Vendor has not submitted KYC documents yet.</p>
                </div>
              ) : (
                <ul className="space-y-2">
                  {vendor.docs.map((doc) => (
                    <li
                      key={doc.id}
                      className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-ink-100 p-4 shadow-xs"
                    >
                      <div>
                        <p className="font-medium text-ink-900">{humanize(doc.doc_type)}</p>
                        <p className="mt-0.5 text-xs text-ink-500">
                          Uploaded {doc.uploaded_at}
                          {doc.expiry_date ? ` · Expires ${doc.expiry_date}` : ''}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {doc.file_path && (
                          <Button
                            size="sm"
                            variant="secondary"
                            loading={docLoading === doc.id}
                            onClick={() => viewDocument(doc.id, doc.file_path)}
                          >
                            📷 View
                          </Button>
                        )}
                        <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${badgeClass(docBadgeStyles, doc.status)}`}>
                          {humanize(doc.status)}
                        </span>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}

          {/* Actions tab */}
          {tab === 'actions' && (
            <div className="mt-5 flex flex-wrap gap-4">
              <div className="min-w-[280px] rounded-xl border border-ink-100 p-5">
                <h3 className="text-sm font-bold text-ink-900">Status</h3>
                <div className="mt-3 flex flex-wrap gap-2">
                  {STATUS_ACTIONS.filter((a) => (LEGAL_VENDOR_TRANSITIONS[vendor.status] ?? []).includes(a.status)).map((action) => (
                    <Button
                      key={action.status}
                      size="sm"
                      variant={action.confirmVariant === 'danger' ? 'danger' : 'secondary'}
                      onClick={() => {
                        setStatusAction(action);
                        setStatusReason('');
                        setStatusError(null);
                      }}
                    >
                      {action.label}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="min-w-[300px] flex-1 rounded-xl border border-ink-100 p-5">
                <h3 className="text-sm font-bold text-ink-900">📝 Admin Notes</h3>
                <textarea
                  rows={4}
                  value={notes}
                  onChange={(e) => {
                    setNotes(e.target.value);
                    setNotesSaved(false);
                  }}
                  placeholder="Internal notes..."
                  className="mt-3 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                  aria-label="Admin notes about this vendor"
                />
                {notesError && <p className="mt-2 text-sm text-danger-600">{notesError}</p>}
                {notesSaved && !notesError && <p className="mt-2 text-sm text-success-600">Notes saved.</p>}
                <div className="mt-3">
                  <Button variant="secondary" size="sm" onClick={submitNotes} loading={savingNotes}>
                    Save Notes
                  </Button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      <ConfirmDialog
        open={showApprove}
        title={missingDocs ? 'Missing required documents' : 'Approve KYC?'}
        description={`This marks ${vendor?.business_name ?? 'this vendor'}'s documents as verified.`}
        confirmLabel={missingDocs ? 'Approve anyway' : 'Approve KYC'}
        confirmVariant={missingDocs ? 'danger' : 'primary'}
        loading={approving}
        onConfirm={() => confirmApprove(Boolean(missingDocs))}
        onCancel={() => {
          if (approving) return;
          setShowApprove(false);
          setApproveError(null);
          setMissingDocs(null);
        }}
      >
        {approveError && (
          <div role="alert" className="mb-3 rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {approveError}
          </div>
        )}
      </ConfirmDialog>

      <ConfirmDialog
        open={showReject}
        title="Reject KYC"
        description="Let the vendor know why their documents were rejected."
        confirmLabel="Reject KYC"
        confirmVariant="danger"
        loading={rejecting}
        confirmDisabled={!rejectReason.trim()}
        onConfirm={confirmReject}
        onCancel={() => {
          if (rejecting) return;
          setShowReject(false);
          setRejectReason('');
          setRejectError(null);
        }}
      >
        {rejectError && (
          <div role="alert" className="mb-3 rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {rejectError}
          </div>
        )}
        <label htmlFor="reject-reason" className="block text-sm font-medium text-ink-700">
          Reason (required)
        </label>
        <textarea
          id="reject-reason"
          rows={3}
          value={rejectReason}
          onChange={(e) => setRejectReason(e.target.value)}
          placeholder="e.g. Driving license image is unreadable"
          className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        />
      </ConfirmDialog>

      <ConfirmDialog
        open={!!statusAction}
        title={`${statusAction?.label ?? ''} vendor?`}
        description={`This changes the vendor's account status to "${statusAction ? humanize(statusAction.status) : ''}".`}
        confirmLabel={statusAction?.label ?? 'Confirm'}
        confirmVariant={statusAction?.confirmVariant ?? 'primary'}
        loading={changingStatus}
        confirmDisabled={
          !!statusAction &&
          !!vendor &&
          vendorStatusChangeRequiresReason(vendor.status, statusAction.status) &&
          !statusReason.trim()
        }
        onConfirm={confirmStatusChange}
        onCancel={() => {
          if (changingStatus) return;
          setStatusAction(null);
          setStatusReason('');
          setStatusError(null);
        }}
      >
        {statusError && (
          <div role="alert" className="mb-3 rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {statusError}
          </div>
        )}
        <label htmlFor="status-reason" className="block text-sm font-medium text-ink-700">
          Reason{' '}
          {statusAction && vendor && vendorStatusChangeRequiresReason(vendor.status, statusAction.status)
            ? '(required)'
            : '(optional)'}
        </label>
        <textarea
          id="status-reason"
          rows={3}
          value={statusReason}
          onChange={(e) => setStatusReason(e.target.value)}
          placeholder="e.g. Repeated customer complaints"
          className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        />
      </ConfirmDialog>
    </div>
  );
}
