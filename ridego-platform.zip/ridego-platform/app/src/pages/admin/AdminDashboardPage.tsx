import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getAdminDashboard, ApiError } from '../../lib/api';
import type { AdminDashboardOverview } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { getBootstrap } from '../../lib/bootstrap';
import { brand } from '../../lib/brand';

/**
 * The React landing page for /app/admin — reproduces
 * admin/pages/dashboard.php (wp-admin's "Dashboard" page) as a
 * single-call SPA screen. Every figure comes from the one new
 * GET /app/admin/dashboard endpoint (includes/app-admin-dashboard-api.php),
 * which itself reuses ridego_get_dashboard_stats() — the same cached
 * stats object the wp-admin page already renders — so the numbers
 * here always agree with wp-admin's, not a second computation of them.
 */

const statusBadgeStyles: Record<string, string> = {
  pending_payment: 'bg-warning-50 text-warning-600',
  payment_proof_submitted: 'bg-warning-50 text-warning-600',
  payment_rejected: 'bg-danger-50 text-danger-600',
  confirmed: 'bg-success-50 text-success-600',
  vendor_assigned: 'bg-brand-50 text-brand-700',
  driver_en_route: 'bg-brand-50 text-brand-700',
  trip_started: 'bg-brand-50 text-brand-700',
  completed: 'bg-success-50 text-success-600',
  cancelled: 'bg-danger-50 text-danger-600',
  expired: 'bg-ink-100 text-ink-600',
};

function badgeClass(value: string): string {
  return statusBadgeStyles[value] ?? 'bg-ink-100 text-ink-600';
}

/**
 * Mirrors rga_money() (admin/admin.php): ridego_currency_symbol() + a
 * 2-decimal number_format(). The old hardcoded '₹' + 0-decimals ignored
 * the configured currency setting entirely.
 */
function currency(n: number) {
  const symbol = getBootstrap().currencySymbol;
  return `${symbol}${n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function compactCurrency(n: number) {
  const symbol = getBootstrap().currencySymbol;
  return n >= 1000 ? `${symbol}${(n / 1000).toLocaleString('en-IN', { maximumFractionDigits: 1 })}k` : currency(n);
}

function humanize(value: string): string {
  return value
    .split('_')
    .map((part) => (part ? part[0].toUpperCase() + part.slice(1) : part))
    .join(' ');
}

function fmtDate(s: string) {
  if (!s) return '—';
  const d = new Date(s.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function fmtDateTime(s: string) {
  if (!s) return '—';
  const d = new Date(s.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}

function fmtDayLabel(dateStr: string) {
  const d = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit' });
}

function Trend({ value }: { value: number | null }) {
  if (value === null) return null;
  const up = value > 0;
  const flat = value === 0;
  const cls = flat ? 'text-ink-400' : up ? 'text-success-600' : 'text-danger-600';
  const arrow = flat ? '▬' : up ? '▲' : '▼';
  return (
    <p className={`mt-1 text-xs font-semibold ${cls}`} title="vs. prior period">
      {arrow} {Math.abs(value)}%
    </p>
  );
}

interface KpiTile {
  icon: string;
  label: string;
  value: string;
  subtitle?: string;
  trend?: number | null;
}

function KpiCard({ tile }: { tile: KpiTile }) {
  return (
    <div className="rounded-xl border border-ink-100 p-4 shadow-xs" title={tile.subtitle}>
      <div className="flex items-center justify-between">
        <span className="text-lg">{tile.icon}</span>
      </div>
      <p className="mt-2 text-xl font-bold text-ink-900">{tile.value}</p>
      <p className="text-xs font-medium uppercase tracking-wide text-ink-400">{tile.label}</p>
      {tile.trend !== undefined ? (
        <Trend value={tile.trend} />
      ) : (
        tile.subtitle && <p className="mt-0.5 text-xs text-ink-400">{tile.subtitle}</p>
      )}
    </div>
  );
}

interface QuickAction {
  icon: string;
  label: string;
  to: string;
  badge?: number;
}

export function AdminDashboardPage() {
  const [data, setData] = useState<AdminDashboardOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminDashboard();
      setData(res);
    } catch (err) {
      setError(
        err instanceof ApiError && err.code === 'forbidden'
          ? "You don't have permission to view the admin dashboard."
          : err instanceof ApiError
          ? err.message
          : 'Could not load the dashboard. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const wmax = data?.revenue_7d.length ? Math.max(...data.revenue_7d.map((w) => w.collected ?? 0), 1) : 1;
  const typeTotal = data?.trips_by_type_30d.reduce((sum, t) => sum + t.count, 0) ?? 0;

  const kpis: KpiTile[] = data
    ? [
        { icon: '📅', label: 'Today Bookings', value: String(data.kpis.bookings_today), trend: data.kpis.bookings_today_trend },
        { icon: '📅', label: 'This Month', value: String(data.kpis.bookings_month), subtitle: 'total bookings', trend: data.kpis.bookings_month_trend },
        { icon: '💰', label: 'Booking Amounts Today', value: currency(data.kpis.revenue_today), subtitle: 'collected by ' + brand().name + ' (verified)', trend: data.kpis.revenue_today_trend },
        { icon: '💰', label: 'Booking Amounts (Month)', value: currency(data.kpis.revenue_month), subtitle: 'collected by ' + brand().name + ' (verified)', trend: data.kpis.revenue_month_trend },
        { icon: '🏦', label: 'Commission Earned Today', value: currency(data.kpis.commission_today), subtitle: brand().name + ' lead fee charged to vendors, not client revenue', trend: data.kpis.commission_today_trend },
        { icon: '🏦', label: 'Commission Earned (Month)', value: currency(data.kpis.commission_month), subtitle: brand().name + ' lead fee charged to vendors, not client revenue', trend: data.kpis.commission_month_trend },
        ...(data.kpis.lead_fee_month ? [{ icon: '🧾', label: 'Vendor Lead Fees (Month)', value: currency(data.kpis.lead_fee_month.accrued), subtitle: `${currency(data.kpis.lead_fee_month.outstanding)} outstanding` }] : []),
        { icon: '🔍', label: 'Proof Pending', value: String(data.kpis.proof_submitted), subtitle: 'awaiting verification' },
        { icon: '🚫', label: 'No Driver (Stuck)', value: String(data.kpis.no_vendor_bookings), subtitle: `confirmed, unassigned & older than ${data.kpis.no_vendor_stale_minutes} min` },
        { icon: '🛣️', label: 'Active Trips', value: String(data.kpis.active_trips), subtitle: 'in progress now' },
        { icon: '📄', label: 'KYC Pending', value: String(data.kpis.vendors_pending_kyc), subtitle: 'submitted docs, awaiting approval' },
        { icon: '⚠️', label: 'Low Wallets', value: String(data.kpis.low_wallet_vendors), subtitle: 'below min balance' },
        { icon: '💬', label: 'Complaints', value: String(data.kpis.open_complaints), subtitle: 'open cases' },
        { icon: '🚗', label: 'Active Vendors', value: String(data.kpis.vendors_active) },
        { icon: '💳', label: 'Wallet Float', value: currency(data.kpis.total_wallet_float), subtitle: 'combined balances' },
      ]
    : [];

  const quickActions: QuickAction[] = data
    ? [
        { icon: '📋', label: 'Bookings', to: '/admin/bookings' },
        { icon: '🔍', label: 'Verify Proofs', to: '/admin/bookings?status=payment_proof_submitted', badge: data.kpis.proof_submitted },
        { icon: '✅', label: 'KYC Queue', to: '/admin/vendors?kyc=submitted', badge: data.kpis.vendors_pending_kyc },
        { icon: '💬', label: 'Complaints', to: '/admin/complaints', badge: data.kpis.open_complaints },
        { icon: '💰', label: 'Financial', to: '/admin/financial' },
        { icon: '📊', label: 'Reports', to: '/admin/reports' },
        { icon: '🎟️', label: 'Promos', to: '/admin/promo' },
        { icon: '🏙️', label: 'Cities', to: '/admin/cities' },
        { icon: '⚡', label: 'Surge', to: '/admin/surge' },
        { icon: '⚙️', label: 'Settings', to: '/admin/settings' },
        { icon: '🛠️', label: 'Tools', to: '/admin/tools' },
      ]
    : [];

  const typeColors: Record<string, string> = {
    one_way: 'bg-brand-500',
    round_trip: 'bg-violet-500',
    local: 'bg-success-500',
    airport_pickup: 'bg-warning-500',
    airport_drop: 'bg-danger-500',
    outstation: 'bg-violet-500',
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">📊 Admin dashboard</h1>
          <p className="text-sm text-ink-500">Operational overview — bookings, booking amounts collected, vendors and system health.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link to="/admin/bookings">
            <Button variant="primary" size="sm">
              📋 All Bookings
            </Button>
          </Link>
          <Link to="/admin/reports">
            <Button variant="secondary" size="sm">
              📊 Reports
            </Button>
          </Link>
          <Link to="/admin/settings">
            <Button variant="secondary" size="sm">
              ⚙️ Settings
            </Button>
          </Link>
        </div>
      </div>

      {loading && (
        <div className="mt-6 space-y-6" aria-busy="true" aria-label="Loading dashboard">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-24 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-64 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {!loading && !error && data && (
        <>
          {!data.setup_complete && (
            <div className="mt-6 flex flex-col gap-2 rounded-lg border border-warning-500/30 bg-warning-50 p-4 text-sm text-warning-700 sm:flex-row sm:items-center sm:justify-between">
              <span>⚠️ <strong>Some setup steps are incomplete.</strong> Some features may not work until configured.</span>
              <Link to="/admin/settings" className="shrink-0 font-semibold text-warning-700 underline underline-offset-2">
                Configure Now →
              </Link>
            </div>
          )}

          {/* KPI tiles */}
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {kpis.map((tile) => (
              <KpiCard key={tile.label} tile={tile} />
            ))}
          </div>

          {/* Quick actions */}
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {quickActions.map((qa) => (
              <Link
                key={qa.label}
                to={qa.to}
                className="relative flex flex-col items-center gap-1.5 rounded-xl border border-ink-100 p-4 text-center text-sm font-medium text-ink-700 shadow-xs transition hover:border-brand-300 hover:bg-brand-50/40"
              >
                {!!qa.badge && (
                  <span className="absolute right-2 top-2 rounded-full bg-danger-500 px-1.5 py-0.5 text-[10px] font-bold text-white">
                    {qa.badge}
                  </span>
                )}
                <span className="text-lg">{qa.icon}</span>
                {qa.label}
              </Link>
            ))}
          </div>

          {/* Charts row */}
          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <div className="rounded-xl border border-ink-100 p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-semibold text-ink-900">📈 Booking amounts collected — last 7 days</h3>
                <Link to="/admin/reports">
                  <Button variant="secondary" size="sm">
                    Full Report →
                  </Button>
                </Link>
              </div>
              {data.revenue_7d.length > 0 ? (
                <div className="mt-4 flex h-48 items-end gap-2">
                  {data.revenue_7d.map((w) => (
                    <div key={w.date} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
                      <span className="text-[10px] font-semibold text-ink-500">{compactCurrency(w.collected ?? 0)}</span>
                      <div
                        className="w-full rounded-t bg-brand-500"
                        style={{ height: `${Math.max(4, ((w.collected ?? 0) / wmax) * 100)}%` }}
                        title={`Booking amounts ${currency(w.collected ?? 0)} · est. ride value ${currency(w.revenue)}`}
                      />
                      <span className="text-[10px] text-ink-400">{fmtDayLabel(w.date)}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState icon={<span className="text-4xl">📊</span>} title="No data yet" description="Bookings will appear here." />
              )}
            </div>

            <div className="rounded-xl border border-ink-100 p-5 shadow-xs">
              <h3 className="text-base font-semibold text-ink-900">🗂️ Trips by Type (30 days)</h3>
              {data.trips_by_type_30d.length > 0 ? (
                <div className="mt-4 space-y-3">
                  {data.trips_by_type_30d.map((t) => {
                    const pct = typeTotal > 0 ? Math.round((t.count / typeTotal) * 100) : 0;
                    return (
                      <div key={t.trip_type}>
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-medium text-ink-800">{humanize(t.trip_type)}</span>
                          <span className="font-semibold text-ink-900">
                            {t.count} · est. ride value {currency(t.revenue)}
                          </span>
                        </div>
                        <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-ink-100">
                          <div
                            className={`h-full rounded-full ${typeColors[t.trip_type] ?? 'bg-brand-500'}`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        <p className="mt-0.5 text-xs text-ink-400">{pct}%</p>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <EmptyState icon={<span className="text-4xl">🗂️</span>} title="No bookings yet" />
              )}
            </div>
          </div>

          {/* Proofs + system health */}
          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <div className="rounded-xl border border-ink-100 p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-semibold text-ink-900">🔍 Payment Proofs Pending</h3>
                <Link to="/admin/bookings?status=payment_proof_submitted">
                  <Button variant="secondary" size="sm">
                    View All
                  </Button>
                </Link>
              </div>
              {data.proofs_pending.length > 0 ? (
                <ul className="mt-3 space-y-2 text-sm">
                  {data.proofs_pending.map((p, i) => (
                    <li key={i} className="flex items-center justify-between border-b border-ink-100 pb-2 last:border-b-0">
                      <div>
                        <p className="font-medium text-ink-900">{p.client_name}</p>
                        <p className="text-xs text-ink-400">
                          {p.booking_number} · {humanize(p.payment_method)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-brand-700">{currency(p.total_fare)}</p>
                        <p className="text-xs text-ink-400">{fmtDateTime(p.created_at)}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <EmptyState icon={<span className="text-4xl">✅</span>} title="No pending proofs!" />
              )}
            </div>

            <div className="rounded-xl border border-ink-100 p-5 shadow-xs">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-semibold text-ink-900">🛡️ System Health</h3>
                <Link to="/admin/settings">
                  <Button variant="secondary" size="sm">
                    Settings →
                  </Button>
                </Link>
              </div>
              <div className="mt-3 divide-y divide-ink-100 text-sm">
                {data.system_health.checks.map((c) => (
                  <div key={c.key} className="flex items-center justify-between py-2">
                    <span className="text-ink-700">{c.label}</span>
                    {c.ok ? (
                      <span className="font-semibold text-success-600">✓ OK</span>
                    ) : (
                      <Link to="/admin/settings" className="font-semibold text-danger-600 hover:underline">
                        ✗ Set Up
                      </Link>
                    )}
                  </div>
                ))}
              </div>
              <div className="mt-3 rounded-lg bg-ink-50 p-2.5 text-xs text-ink-400">
                Plugin v{data.system_health.plugin_version} · PHP {data.system_health.php_version} · WP{' '}
                {data.system_health.wp_version}
              </div>
            </div>
          </div>

          {/* Recent bookings */}
          <div className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold text-ink-900">📋 Recent Bookings</h3>
              <Link to="/admin/bookings">
                <Button variant="secondary" size="sm">
                  View All →
                </Button>
              </Link>
            </div>
            <div className="mt-3 hidden overflow-x-auto lg:block">
              <table className="w-full text-sm">
                <thead className="text-left text-xs font-medium uppercase tracking-wide text-ink-500">
                  <tr>
                    <th className="px-2 py-2">Booking #</th>
                    <th className="px-2 py-2">Client</th>
                    <th className="px-2 py-2">Route</th>
                    <th className="px-2 py-2">Date</th>
                    <th className="px-2 py-2">Est. fare</th>
                    <th className="px-2 py-2">Status</th>
                    <th className="px-2 py-2">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink-100">
                  {data.recent_bookings.length > 0 ? (
                    data.recent_bookings.map((b) => (
                      <tr key={b.id}>
                        <td className="px-2 py-2.5">
                          <Link to={`/app/admin/bookings/${b.id}`} className="font-medium text-brand-700 hover:underline">
                            {b.booking_number}
                          </Link>
                        </td>
                        <td className="px-2 py-2.5 font-medium text-ink-900">{b.client_name}</td>
                        <td className="px-2 py-2.5 text-xs text-ink-600">
                          {b.pickup_city} → {b.drop_city}
                        </td>
                        <td className="px-2 py-2.5 text-xs text-ink-400">{fmtDate(b.journey_date)}</td>
                        <td className="px-2 py-2.5 font-semibold text-ink-900">{currency(b.total_fare)}</td>
                        <td className="px-2 py-2.5">
                          <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${badgeClass(b.status)}`}>
                            {humanize(b.status)}
                          </span>
                        </td>
                        <td className="px-2 py-2.5">
                          <Link to={`/app/admin/bookings/${b.id}`}>
                            <Button variant="secondary" size="sm">
                              View
                            </Button>
                          </Link>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7}>
                        <EmptyState icon={<span className="text-4xl">📋</span>} title="No bookings yet" />
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {data.recent_bookings.length > 0 ? (
              <div className="mt-3 space-y-3 lg:hidden">
                {data.recent_bookings.map((b) => (
                  <div key={b.id} className="rounded-xl border border-ink-100 bg-white p-4">
                    <div className="flex items-start justify-between gap-3">
                      <Link to={`/app/admin/bookings/${b.id}`} className="font-medium text-brand-700 hover:underline">
                        {b.booking_number}
                      </Link>
                      <span className={`shrink-0 rounded-full px-2 py-0.5 text-xs font-medium ${badgeClass(b.status)}`}>
                        {humanize(b.status)}
                      </span>
                    </div>
                    <p className="mt-1 text-sm font-medium text-ink-900">{b.client_name}</p>
                    <p className="mt-0.5 text-xs text-ink-600">
                      {b.pickup_city} → {b.drop_city}
                    </p>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-xs text-ink-400">{fmtDate(b.journey_date)}</span>
                      <span className="font-semibold text-ink-900">{currency(b.total_fare)}</span>
                    </div>
                    <div className="mt-3">
                      <Link to={`/app/admin/bookings/${b.id}`}>
                        <Button variant="secondary" size="sm">
                          View
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mt-3 lg:hidden">
                <EmptyState icon={<span className="text-4xl">📋</span>} title="No bookings yet" />
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
