import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import {
  approveVendorKyc,
  bulkVendorAction,
  getAdminReportsExportNonce,
  getAdminVendors,
  ApiError,
} from '../../lib/api';
import type { AdminVendorRow, AdminVendorsResponse } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { BottomSheet } from '../../components/ui/BottomSheet';

/** Mirrors admin/pages/vendors.php's quick-filter pill row exactly. */
const QUICK_PILLS: { key: string; label: string; kyc?: boolean }[] = [
  { key: '', label: 'All' },
  { key: 'active', label: '✅ Active' },
  { key: 'pending', label: '⏳ Pending' },
  { key: 'submitted', label: '📄 KYC Ready', kyc: true },
  { key: 'suspended', label: '🚫 Suspended' },
];

const STATUS_OPTIONS: { key: string; label: string }[] = [
  { key: '', label: 'All statuses' },
  { key: 'pending', label: 'Pending' },
  { key: 'active', label: 'Active' },
  { key: 'suspended', label: 'Suspended' },
  { key: 'blacklisted', label: 'Blacklisted' },
];

const KYC_OPTIONS: { key: string; label: string }[] = [
  { key: '', label: 'All KYC statuses' },
  { key: 'pending', label: 'Pending' },
  { key: 'submitted', label: 'Submitted' },
  { key: 'complete', label: 'Complete' },
  { key: 'verified', label: 'Verified' },
  { key: 'rejected', label: 'Rejected' },
  { key: 'expired_docs', label: 'Expired docs' },
];

const statusBadgeStyles: Record<string, string> = {
  pending: 'bg-warning-50 text-warning-600',
  active: 'bg-success-50 text-success-600',
  suspended: 'bg-warning-50 text-warning-600',
  blacklisted: 'bg-danger-50 text-danger-600',
};

const kycBadgeStyles: Record<string, string> = {
  pending: 'bg-ink-100 text-ink-600',
  submitted: 'bg-warning-50 text-warning-600',
  complete: 'bg-warning-50 text-warning-600',
  verified: 'bg-success-50 text-success-600',
  rejected: 'bg-danger-50 text-danger-600',
  expired_docs: 'bg-danger-50 text-danger-600',
};

function badgeClass(map: Record<string, string>, value: string): string {
  return map[value] ?? 'bg-ink-100 text-ink-600';
}

function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

function humanize(value: string): string {
  return value
    .split('_')
    .map((part) => (part ? part[0].toUpperCase() + part.slice(1) : part))
    .join(' ');
}

export function AdminVendorsPage() {
  const [status, setStatus] = useState('');
  const [kyc, setKyc] = useState('');
  const [vtype, setVtype] = useState('');
  const [expiring, setExpiring] = useState(0);
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [page, setPage] = useState(1);
  const [data, setData] = useState<AdminVendorsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const [exportingSelected, setExportingSelected] = useState(false);
  const [approvingId, setApprovingId] = useState<number | null>(null);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [bulkAction, setBulkAction] = useState('');
  const [bulkRunning, setBulkRunning] = useState(false);
  const [bulkMessage, setBulkMessage] = useState<string | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const load = useCallback(async (s: string, k: string, exp: number, q: string, p: number, vt: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminVendors({
        status: s || undefined,
        kyc: k || undefined,
        vendor_type: vt || undefined,
        expiring: exp || undefined,
        search: q || undefined,
        page: p,
      });
      setData(res);
    } catch (err) {
      if (err instanceof ApiError && err.code === 'forbidden') {
        setError("You don't have permission to manage vendors.");
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not load vendors. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(status, kyc, expiring, search, page, vtype);
  }, [status, kyc, expiring, search, page, vtype, load]);

  useEffect(() => {
    // Selection is scoped to the current page's results, same as the old
    // admin's per-page checkboxes — invalidated on filter/page change.
    setSelectedIds([]);
  }, [status, kyc, expiring, search, page, vtype]);

  function changePill(pv: string, isKyc?: boolean) {
    if (isKyc) {
      setStatus('');
      setKyc(pv);
    } else {
      setStatus(pv);
      setKyc('');
    }
    setExpiring(0);
    setPage(1);
  }

  function toggleRow(id: number) {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  function toggleSelectAll(rows: AdminVendorRow[]) {
    setSelectedIds((prev) => (prev.length === rows.length ? [] : rows.map((r) => r.id)));
  }

  async function applyBulkAction() {
    if (!bulkAction || selectedIds.length === 0) return;
    setBulkRunning(true);
    setBulkMessage(null);
    try {
      const res = await bulkVendorAction(bulkAction as 'approve_kyc' | 'suspend', selectedIds);
      setBulkMessage(res.message);
      setSelectedIds([]);
      setBulkAction('');
      await load(status, kyc, expiring, search, page, vtype);
    } catch (err) {
      setBulkMessage(err instanceof ApiError ? err.message : 'Bulk action failed.');
    } finally {
      setBulkRunning(false);
    }
  }

  /**
   * Same admin-ajax.php "ridego_export_csv" handler as the toolbar
   * Export button, but posts selected_ids[] so the server constrains the
   * export to exactly the checked rows.
   */
  async function exportSelected() {
    if (selectedIds.length === 0) return;
    setExportingSelected(true);
    try {
      const { nonce } = await getAdminReportsExportNonce();
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = `${window.location.origin}/wp-admin/admin-ajax.php?action=ridego_export_csv&type=vendors&nonce=${encodeURIComponent(
        nonce
      )}`;
      form.target = '_blank';
      selectedIds.forEach((id) => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_ids[]';
        input.value = String(id);
        form.appendChild(input);
      });
      document.body.appendChild(form);
      form.submit();
      document.body.removeChild(form);
    } finally {
      setExportingSelected(false);
    }
  }

  function changeStatus(s: string) {
    setStatus(s);
    setExpiring(0);
    setPage(1);
  }

  function changeKyc(k: string) {
    setKyc(k);
    setExpiring(0);
    setPage(1);
  }

  function submitSearch(e: FormEvent) {
    e.preventDefault();
    setSearch(searchInput.trim());
    setPage(1);
  }

  async function exportCsv() {
    setExporting(true);
    try {
      const { nonce } = await getAdminReportsExportNonce();
      const url = `${window.location.origin}/wp-admin/admin-ajax.php?action=ridego_export_csv&type=vendors&nonce=${encodeURIComponent(
        nonce
      )}`;
      window.open(url, '_blank', 'noopener,noreferrer');
    } finally {
      setExporting(false);
    }
  }

  async function quickApprove(id: number) {
    setApprovingId(id);
    setBulkMessage(null);
    try {
      await approveVendorKyc(id);
      await load(status, kyc, expiring, search, page, vtype);
    } catch (err) {
      if (err instanceof ApiError && err.code === 'missing_documents') {
        const missing = Array.isArray((err.data as { missing_docs?: string[] } | undefined)?.missing_docs)
          ? ((err.data as { missing_docs?: string[] }).missing_docs as string[])
          : [];
        const docsLabel = missing.map((d) => d.replace(/_/g, ' ')).join(', ');
        setBulkMessage(
          `Could not approve this vendor — missing documents${docsLabel ? `: ${docsLabel}` : ''}. Open the vendor's detail page to review and approve anyway if you've verified them another way.`
        );
      } else {
        setBulkMessage("Could not approve this vendor's KYC. Please try again from the vendor's detail page.");
      }
    } finally {
      setApprovingId(null);
    }
  }

  const rows = data?.rows ?? null;
  const total = data?.total ?? 0;
  const perPage = data?.per_page ?? 20;
  const kpis = data?.kpis;
  const canPrev = page > 1;
  const canNext = page * perPage < total;
  const activeFilterCount = [status, kyc, vtype, search].filter(Boolean).length;

  const filterControls = (
    <>
      <select
        value={status}
        onChange={(e) => changeStatus(e.target.value)}
        className="rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        aria-label="Filter by vendor status"
      >
        {STATUS_OPTIONS.map((o) => (
          <option key={o.key} value={o.key}>
            {o.label}
          </option>
        ))}
      </select>
      <select
        value={vtype}
        onChange={(e) => {
          setVtype(e.target.value);
          setPage(1);
        }}
        className="rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        aria-label="Filter by vendor type"
      >
        <option value="">All types</option>
        <option value="individual">Individual</option>
        <option value="fleet">Fleet</option>
      </select>
      <select
        value={kyc}
        onChange={(e) => changeKyc(e.target.value)}
        className="rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        aria-label="Filter by KYC status"
      >
        {KYC_OPTIONS.map((o) => (
          <option key={o.key} value={o.key}>
            {o.label}
          </option>
        ))}
      </select>
    </>
  );

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Vendor management</h1>
          <p className="text-sm text-ink-500">Review vendors, verify KYC documents and manage account status.</p>
        </div>
        <div className="flex gap-2">
          <Link to="/admin/vendors/new">
            <Button size="sm">+ Add Vendor</Button>
          </Link>
          <Button variant="secondary" size="sm" loading={exporting} onClick={exportCsv}>
            ⬇️ Export
          </Button>
        </div>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-4 lg:grid-cols-7">
        <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Total vendors</p>
          <p className="mt-2 text-xl font-bold text-ink-900">{loading ? '—' : kpis?.total ?? 0}</p>
        </div>
        <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Active</p>
          <p className="mt-2 text-xl font-bold text-success-600">{loading ? '—' : kpis?.active ?? 0}</p>
        </div>
        <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">KYC pending</p>
          <p className="mt-2 text-xl font-bold text-warning-600">{loading ? '—' : kpis?.kyc_pending ?? 0}</p>
        </div>
        <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Wallet float</p>
          <p className="mt-2 text-xl font-bold text-brand-700">{loading ? '—' : currency(kpis?.wallet_float ?? 0)}</p>
        </div>
        <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Low balance</p>
          <p className="mt-2 text-xl font-bold text-danger-600">{loading ? '—' : kpis?.low_wallet ?? 0}</p>
        </div>
        <button
          type="button"
          onClick={() => setExpiring(30)}
          className="rounded-xl border border-ink-100 p-4 text-left shadow-xs transition hover:border-warning-300"
        >
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Docs expiring 30d</p>
          <p className="mt-2 text-xl font-bold text-warning-600">{loading ? '—' : kpis?.docs_expiring_30d ?? 0}</p>
        </button>
        <button
          type="button"
          onClick={() => changeKyc('expired_docs')}
          className="rounded-xl border border-ink-100 p-4 text-left shadow-xs transition hover:border-danger-300"
        >
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Expired docs</p>
          <p className="mt-2 text-xl font-bold text-danger-600">{loading ? '—' : kpis?.expired_docs ?? 0}</p>
        </button>
      </div>

      <div className="mt-6 hidden gap-3 lg:flex lg:flex-wrap lg:items-center">
        {filterControls}
        <form onSubmit={submitSearch} className="flex flex-1 gap-2 sm:min-w-[240px]">
          <input
            type="search"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search business, owner, phone or email"
            className="w-full rounded-lg border border-ink-200 px-3.5 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            aria-label="Search vendors"
          />
          <Button type="submit" variant="secondary" size="sm">
            Search
          </Button>
        </form>
      </div>

      <div className="mt-6 lg:hidden">
        <button
          type="button"
          onClick={() => setFiltersOpen(true)}
          className="relative flex items-center gap-2 rounded-lg border border-ink-200 bg-white px-3.5 py-2 text-sm font-medium text-ink-700 shadow-xs"
        >
          <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 4h18M6 8h12M9 12h6M11 16h2" />
          </svg>
          Filters
          {activeFilterCount > 0 && (
            <span className="ml-1 flex h-2 w-2 rounded-full bg-brand-600" aria-hidden="true" />
          )}
        </button>
      </div>

      <BottomSheet open={filtersOpen} title="Filters" onClose={() => setFiltersOpen(false)}>
        <div className="flex flex-col gap-3">
          {filterControls}
          <form
            onSubmit={(e) => {
              submitSearch(e);
              setFiltersOpen(false);
            }}
            className="flex flex-col gap-2"
          >
            <input
              type="search"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search business, owner, phone or email"
              className="w-full rounded-lg border border-ink-200 px-3.5 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              aria-label="Search vendors"
            />
            <Button type="submit" variant="secondary" size="sm">
              Search
            </Button>
          </form>
          <Button variant="secondary" size="sm" onClick={() => setFiltersOpen(false)}>
            Done
          </Button>
        </div>
      </BottomSheet>

      <div className="mt-4 flex flex-wrap gap-2">
        {QUICK_PILLS.map((p) => (
          <button
            key={p.key}
            type="button"
            onClick={() => changePill(p.key, p.kyc)}
            className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition ${
              (p.kyc ? kyc : status) === p.key
                ? 'border-brand-600 bg-brand-600 text-white'
                : 'border-ink-200 bg-white text-ink-600 hover:bg-ink-50'
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      {selectedIds.length > 0 && (
        <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl border border-brand-200 bg-brand-50 px-4 py-3">
          <span className="text-sm font-medium text-brand-800">{selectedIds.length} selected</span>
          <select
            value={bulkAction}
            onChange={(e) => setBulkAction(e.target.value)}
            className="rounded-lg border border-ink-200 px-3 py-1.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            aria-label="Bulk action"
          >
            <option value="">Bulk action…</option>
            <option value="approve_kyc">✅ Approve KYC</option>
            <option value="suspend">🚫 Suspend</option>
          </select>
          <Button size="sm" variant="secondary" loading={bulkRunning} disabled={!bulkAction} onClick={applyBulkAction}>
            Apply
          </Button>
          <Button size="sm" variant="secondary" loading={exportingSelected} onClick={exportSelected}>
            ⬇️ Export Selected
          </Button>
          {bulkMessage && <span className="text-sm text-ink-600">{bulkMessage}</span>}
        </div>
      )}

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading vendors">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="rounded-xl border border-ink-100 p-4 sm:p-5">
                <div className="flex items-center justify-between">
                  <Skeleton className="h-4 w-40" />
                  <Skeleton className="h-5 w-20 rounded-full" />
                </div>
                <Skeleton className="mt-3 h-3 w-64" />
                <Skeleton className="mt-2 h-3 w-32" />
              </div>
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={() => load(status, kyc, expiring, search, page, vtype)} />}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState title="No vendors found" description="Try adjusting your filters or search." />
        )}

        {!loading && !error && rows && rows.length > 0 && (
          <>
            <div className="mb-2 flex items-center gap-2 text-sm text-ink-500">
              <input
                type="checkbox"
                checked={selectedIds.length === rows.length}
                onChange={() => toggleSelectAll(rows)}
                aria-label="Select all vendors on this page"
                className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
              />
              Select all on this page
            </div>
            <ul className="space-y-3">
              {rows.map((v: AdminVendorRow) => (
                <li key={v.id} className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={selectedIds.includes(v.id)}
                    onChange={() => toggleRow(v.id)}
                    aria-label={`Select vendor ${v.business_name}`}
                    className="mt-5 h-4 w-4 shrink-0 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
                  />
                  <Link
                    to={`/app/admin/vendors/${v.id}`}
                    className="block flex-1 rounded-xl border border-ink-100 p-4 shadow-xs transition hover:shadow-sm sm:p-5"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <p className="font-semibold text-ink-900">{v.business_name}</p>
                        <p className="mt-0.5 text-sm text-ink-500">
                          {v.owner_name} &middot; {v.phone} &middot; {v.city}
                          {v.business_type ? ` · ${humanize(v.business_type)}` : ''} · {v.vendor_type === 'fleet' ? 'Fleet' : 'Individual'}
                        </p>
                      </div>
                      <div className="flex shrink-0 flex-wrap items-center gap-2">
                        {['submitted', 'complete'].includes(v.kyc_status) && v.status === 'pending' && (
                          <Button
                            size="sm"
                            variant="secondary"
                            loading={approvingId === v.id}
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              quickApprove(v.id);
                            }}
                          >
                            ✅ Approve
                          </Button>
                        )}
                        <span
                          className={`rounded-full px-2.5 py-1 text-xs font-semibold ${badgeClass(statusBadgeStyles, v.status)}`}
                        >
                          {humanize(v.status)}
                        </span>
                        <span
                          className={`rounded-full px-2.5 py-1 text-xs font-semibold ${badgeClass(kycBadgeStyles, v.kyc_status)}`}
                        >
                          KYC: {humanize(v.kyc_status)}
                        </span>
                        {v.kyc_docs_incomplete && (
                          <span
                            className="rounded-full bg-warning-50 px-2.5 py-1 text-xs font-semibold text-warning-600"
                            title={`Missing: ${v.kyc_missing_docs.map((d) => d.replace(/_/g, ' ')).join(', ')}`}
                          >
                            ⚠️ Docs incomplete
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-ink-100 pt-3 text-sm text-ink-500">
                      <div>
                        Wallet{' '}
                        <span className={`font-semibold ${v.wallet_balance < 200 ? 'text-danger-600' : 'text-ink-800'}`}>
                          {currency(v.wallet_balance)}
                        </span>
                      </div>
                      <div>
                        Rating <span className="font-semibold text-ink-800">{v.rating.toFixed(1)}</span> (
                        {v.total_ratings})
                      </div>
                      <div>Joined {v.joined_at}</div>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>

            <div className="mt-6 flex items-center justify-between">
              <p className="text-sm text-ink-500">
                Page {page} of {Math.max(1, Math.ceil(total / perPage))} &middot; {total} vendor{total === 1 ? '' : 's'}
              </p>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" disabled={!canPrev} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                  Previous
                </Button>
                <Button variant="secondary" size="sm" disabled={!canNext} onClick={() => setPage((p) => p + 1)}>
                  Next
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
