import { useCallback, useEffect, useState } from 'react';
import { NumberField } from '../../components/ui/NumberField';
import {
  getAdminSubscriptionPlans,
  createAdminSubscriptionPlan,
  updateAdminSubscriptionPlan,
  getAdminActiveSubscriptions,
  cancelAdminVendorSubscription,
  ApiError,
} from '../../lib/api';
import type { AdminSubscriptionPlan, AdminSubscriptionsKpis, AdminActiveSubscriptionRow, AdminSubscriptionPlanInput } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';

function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

const EMPTY_FORM: AdminSubscriptionPlanInput = {
  name: '',
  price: 0,
  billing_cycle: 'monthly',
  wallet_credits: 0,
  lead_discount: 0,
  priority_boost: 0,
  max_leads: 0,
  features: '',
  is_active: true,
};

/**
 * Rebuild of admin/pages/subscriptions.php: plan management (create/
 * edit, real per-plan usage/MRR), dashboard KPIs (active subscribers,
 * MRR, 30-day churn), and the currently-active-subscriptions list
 * with an admin cancel action (delegating to the existing
 * ridego_cancel_vendor_subscription(); no refund is issued, matching
 * the legacy page's confirm-dialog wording).
 */
export function AdminSubscriptionsPage() {
  const [plans, setPlans] = useState<AdminSubscriptionPlan[] | null>(null);
  const [kpis, setKpis] = useState<AdminSubscriptionsKpis | null>(null);
  const [active, setActive] = useState<AdminActiveSubscriptionRow[] | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [banner, setBanner] = useState<string | null>(null);

  const [editing, setEditing] = useState<AdminSubscriptionPlan | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState<AdminSubscriptionPlanInput>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [cancelTarget, setCancelTarget] = useState<AdminActiveSubscriptionRow | null>(null);
  const [cancelSaving, setCancelSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [plansRes, activeRes] = await Promise.all([getAdminSubscriptionPlans(), getAdminActiveSubscriptions()]);
      setPlans(plansRes.plans);
      setKpis(plansRes.kpis);
      setActive(activeRes.rows);
    } catch (err) {
      setError(
        err instanceof ApiError && err.code === 'forbidden'
          ? "You don't have permission to manage subscriptions."
          : err instanceof ApiError
          ? err.message
          : 'Could not load subscription data. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function openCreate() {
    setForm(EMPTY_FORM);
    setFormError(null);
    setCreating(true);
  }

  function openEdit(plan: AdminSubscriptionPlan) {
    setForm({
      name: plan.name,
      price: plan.price,
      billing_cycle: plan.billing_cycle,
      wallet_credits: plan.wallet_credits,
      lead_discount: plan.lead_discount,
      priority_boost: plan.priority_boost,
      max_leads: plan.max_leads,
      features: plan.features,
      is_active: plan.is_active,
    });
    setFormError(null);
    setEditing(plan);
  }

  async function submitForm() {
    if (!form.name.trim()) {
      setFormError('Plan name is required.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      if (editing) {
        await updateAdminSubscriptionPlan(editing.id, form);
        setBanner('Plan updated.');
      } else {
        await createAdminSubscriptionPlan(form);
        setBanner('✅ Plan created!');
      }
      setEditing(null);
      setCreating(false);
      await load();
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : 'Could not save this plan.');
    } finally {
      setSaving(false);
    }
  }

  async function submitCancel() {
    if (!cancelTarget) return;
    setCancelSaving(true);
    try {
      await cancelAdminVendorSubscription(cancelTarget.vendor_id, 'Admin cancellation via Subscriptions page');
      setCancelTarget(null);
      setBanner(`Cancelled ${cancelTarget.business_name}'s subscription.`);
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not cancel this subscription.');
    } finally {
      setCancelSaving(false);
    }
  }

  const dialogOpen = creating || !!editing;

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">💎 Subscription plans</h1>
          <p className="text-sm text-ink-500">Vendors subscribe to premium plans for lead discounts, wallet credits, and priority dispatch.</p>
        </div>
        <Button onClick={openCreate}>+ Create plan</Button>
      </div>

      {loading && (
        <div className="mt-6 space-y-6" aria-busy="true" aria-label="Loading subscriptions">
          <div className="grid gap-4 sm:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-64 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {!loading && !error && kpis && (
        <>
          {banner && (
            <div className="mt-6 rounded-lg border border-success-200 bg-success-50 px-4 py-2.5 text-sm text-success-800">
              {banner}
            </div>
          )}

          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Active subscribers</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{kpis.active_subscribers}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">MRR</p>
              <p className="mt-2 text-xl font-bold text-ink-900">{currency(kpis.mrr)}</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Churn (30d)</p>
              <p className="mt-2 text-xl font-bold text-amber-600">{kpis.churn_rate_pct}%</p>
            </div>
            <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Cancelled/expired (30d)</p>
              <p className="mt-2 text-xl font-bold text-danger-600">{kpis.churned_30d}</p>
            </div>
          </div>

          <div className="mt-6 rounded-xl border border-ink-100 shadow-xs">
            <div className="border-b border-ink-100 px-5 py-3">
              <h3 className="text-base font-semibold text-ink-900">🎟️ Active subscriptions</h3>
            </div>
            {active && active.length > 0 ? (
              <>
                <table className="hidden w-full text-sm lg:table">
                  <thead className="text-left text-xs font-medium uppercase tracking-wide text-ink-500">
                    <tr>
                      <th className="px-5 py-2.5">Vendor</th>
                      <th className="px-5 py-2.5">Plan</th>
                      <th className="px-5 py-2.5">Expires</th>
                      <th className="px-5 py-2.5">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {active.map((av) => (
                      <tr key={av.vendor_id}>
                        <td className="px-5 py-3 font-medium text-ink-900">{av.business_name}</td>
                        <td className="px-5 py-3 text-ink-700">{av.plan_name ?? '—'}</td>
                        <td className="px-5 py-3 text-xs text-ink-500">{av.subscription_expires ?? '—'}</td>
                        <td className="px-5 py-3">
                          <Button
                            variant="danger"
                            size="sm"
                            onClick={() => setCancelTarget(av)}
                            aria-label={`Cancel ${av.business_name}'s subscription`}
                          >
                            Cancel
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                <div className="space-y-3 p-4 lg:hidden">
                  {active.map((av) => (
                    <div key={av.vendor_id} className="rounded-xl border border-ink-100 bg-white p-4">
                      <p className="text-sm font-medium text-ink-900">{av.business_name}</p>
                      <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
                        <span className="text-ink-400">Plan</span>
                        <span className="text-right text-ink-700">{av.plan_name ?? '—'}</span>
                        <span className="text-ink-400">Expires</span>
                        <span className="text-right text-ink-500">{av.subscription_expires ?? '—'}</span>
                      </div>
                      <div className="mt-3">
                        <Button
                          variant="danger"
                          size="sm"
                          onClick={() => setCancelTarget(av)}
                          aria-label={`Cancel ${av.business_name}'s subscription`}
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="px-5 py-8">
                <EmptyState title="No active subscriptions" />
              </div>
            )}
          </div>

          <div className="mt-6">
            <h3 className="text-base font-semibold text-ink-900">Current plans ({plans?.length ?? 0})</h3>
            {plans && plans.length > 0 ? (
              <div className="mt-3 grid gap-4 sm:grid-cols-2">
                {plans.map((p) => (
                  <div
                    key={p.id}
                    className={`rounded-xl border p-4 shadow-xs ${p.is_active ? 'border-brand-200 bg-brand-50/40' : 'border-ink-100'}`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-lg font-bold text-ink-900">{p.name}</p>
                        <p className="text-xs capitalize text-ink-400">{p.billing_cycle}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold text-brand-700">{currency(p.price)}</p>
                        <span
                          className={`mt-1 inline-block rounded-full px-2 py-0.5 text-xs font-medium ${
                            p.is_active ? 'bg-success-50 text-success-700' : 'bg-ink-100 text-ink-500'
                          }`}
                        >
                          {p.is_active ? 'active' : 'inactive'}
                        </span>
                      </div>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-2 text-xs">
                      {p.wallet_credits > 0 && (
                        <span className="rounded-full bg-success-50 px-2 py-0.5 font-semibold text-success-700">
                          +{currency(p.wallet_credits)} credits
                        </span>
                      )}
                      {p.lead_discount > 0 && (
                        <span className="rounded-full bg-violet-50 px-2 py-0.5 font-semibold text-violet-700">
                          {p.lead_discount}% lead discount
                        </span>
                      )}
                      {p.priority_boost > 0 && (
                        <span className="rounded-full bg-amber-50 px-2 py-0.5 font-semibold text-amber-700">
                          Priority: {p.priority_boost}
                        </span>
                      )}
                    </div>
                    <div className="mt-3 flex items-center justify-between border-t border-dashed border-ink-200 pt-3 text-xs text-ink-500">
                      <span>
                        <strong className="text-ink-800">{p.active_subscribers}</strong> active subscribers
                      </span>
                      <span>
                        MRR: <strong className="text-ink-800">{currency(p.mrr)}</strong>
                      </span>
                    </div>
                    <div className="mt-3">
                      <Button variant="secondary" size="sm" onClick={() => openEdit(p)}>
                        Edit
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mt-3">
                <EmptyState title="No plans yet" description="Create your first subscription plan to get started." />
              </div>
            )}
          </div>
        </>
      )}

      <ConfirmDialog
        open={dialogOpen}
        title={editing ? `Edit ${editing.name}` : 'Create plan'}
        confirmLabel={editing ? 'Save changes' : 'Create plan'}
        loading={saving}
        confirmDisabled={!form.name.trim()}
        onConfirm={submitForm}
        onCancel={() => {
          setEditing(null);
          setCreating(false);
        }}
      >
        <div className="max-h-[60vh] space-y-3 overflow-y-auto pr-1">
          <div>
            <label htmlFor="plan-name" className="block text-sm font-medium text-ink-700">
              Plan name
            </label>
            <input
              id="plan-name"
              type="text"
              required
              placeholder="e.g. Starter, Pro, Premium"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="plan-price" className="block text-sm font-medium text-ink-700">
                Price (₹)
              </label>
              <NumberField
                id="plan-price"
                min="0"
                step="0.01"
                value={form.price}
                onValue={(n) => setForm((f) => ({ ...f, price: n }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="plan-cycle" className="block text-sm font-medium text-ink-700">
                Billing cycle
              </label>
              <select
                id="plan-cycle"
                value={form.billing_cycle}
                onChange={(e) => setForm((f) => ({ ...f, billing_cycle: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              >
                <option value="monthly">Monthly</option>
                <option value="quarterly">Quarterly</option>
                <option value="yearly">Yearly</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="plan-credits" className="block text-sm font-medium text-ink-700">
                Wallet credits (₹)
              </label>
              <NumberField
                id="plan-credits"
                min="0"
                step="0.01"
                value={form.wallet_credits ?? 0}
                onValue={(n) => setForm((f) => ({ ...f, wallet_credits: n }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="plan-discount" className="block text-sm font-medium text-ink-700">
                Lead fee discount (%)
              </label>
              <NumberField
                id="plan-discount"
                min="0"
                max="100"
                step="0.01"
                value={form.lead_discount ?? 0}
                onValue={(n) => setForm((f) => ({ ...f, lead_discount: n }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="plan-priority" className="block text-sm font-medium text-ink-700">
                Priority boost
              </label>
              <NumberField
                id="plan-priority"
                min="0"
                value={form.priority_boost ?? 0} integer
                onValue={(n) => setForm((f) => ({ ...f, priority_boost: n }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="plan-max-leads" className="block text-sm font-medium text-ink-700">
                Max leads/month (0 = unlimited)
              </label>
              <NumberField
                id="plan-max-leads"
                min="0"
                value={form.max_leads ?? 0}
                integer
                onValue={(n) => setForm((f) => ({ ...f, max_leads: n }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <div>
            <label htmlFor="plan-features" className="block text-sm font-medium text-ink-700">
              Features (one per line)
            </label>
            <textarea
              id="plan-features"
              rows={4}
              placeholder={'Priority lead dispatch\nLead fee 10% discount\nWhatsApp alerts'}
              value={form.features}
              onChange={(e) => setForm((f) => ({ ...f, features: e.target.value }))}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={!!form.is_active}
              onChange={(e) => setForm((f) => ({ ...f, is_active: e.target.checked }))}
            />
            Visible to vendors
          </label>
          {formError && <p className="text-sm text-danger-600">{formError}</p>}
        </div>
      </ConfirmDialog>

      <ConfirmDialog
        open={!!cancelTarget}
        title={`Cancel ${cancelTarget?.business_name ?? ''}'s subscription?`}
        description="No refund is issued."
        confirmLabel="Cancel subscription"
        confirmVariant="danger"
        loading={cancelSaving}
        onConfirm={submitCancel}
        onCancel={() => setCancelTarget(null)}
      />
    </div>
  );
}
