import { useCallback, useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ApiError } from '../../lib/api';
import {
  assignBookingCandidate,
  getBookingComparison,
  rejectLead,
  reopenBooking,
  replaceBookingAssignment,
  reportBookingNoShow,
  requestDriverDetails,
  type ComparisonCandidate,
  type ComparisonResponse,
  type MutationResult,
  type RankingEntry,
} from '../../lib/api-admin-command';
import { useToast } from '../../context/ToastContext';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';

type Dialog =
  | { kind: 'assign'; candidate: ComparisonCandidate }
  | { kind: 'reject'; candidate: ComparisonCandidate }
  | { kind: 'replace' }
  | { kind: 'reopen' }
  | { kind: 'noshow' }
  | null;

const INPUT_CLASS =
  'w-full rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30';

const INTEREST_LABELS: Record<string, string> = {
  sent: 'Awaiting response',
  pending: 'Awaiting response',
  viewed: 'Viewed, no response',
  interested: 'Interested',
  driver_confirmed: 'Interested, driver confirmed',
  declined: 'Declined',
  not_selected: 'Not selected',
  expired: 'Expired',
  cancelled: 'Booking cancelled',
};

// TRACE: interest_status → tone classes for the status pill → string. Any string → class list → unknown falls back to neutral.
function interestTone(status: string): string {
  if (status === 'interested' || status === 'driver_confirmed') return 'bg-success-50 text-success-700';
  if (status === 'declined' || status === 'not_selected' || status === 'expired') return 'bg-danger-50 text-danger-600';
  return 'bg-ink-100 text-ink-700';
}

// TRACE: ISO-like timestamp → localised short date-time → string. null/empty → "—"; unparsable → raw text.
function formatWhen(value: string | null | undefined): string {
  if (!value) return '—';
  const d = new Date(value.replace(' ', 'T'));
  return Number.isNaN(d.getTime()) ? value : d.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

// TRACE: number → rupee string with Indian grouping → string. Non-finite → ₹0.
function currency(n: number): string {
  return `₹${(Number.isFinite(n) ? n : 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

// TRACE: factor key → readable label → string. "on_time_rate" → "On time rate"; empty stays empty.
function factorLabel(key: string): string {
  const s = key.replace(/_/g, ' ');
  return s ? s[0].toUpperCase() + s.slice(1) : s;
}

// TRACE: field props → labelled control wrapper → element. label + id + children → label bound to the control.
function Field({ id, label, hint, children }: { id: string; label: string; hint?: string; children: ReactNode }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm font-medium text-ink-800">
        {label}
      </label>
      {children}
      {hint && <p className="mt-1 text-xs text-ink-500">{hint}</p>}
    </div>
  );
}

// TRACE: constant → [snapshot key, label] rows shown in the "Driver details for tracking" card. Pure. Full ID number is never in the snapshot (masked only).
const DRIVER_TRACE_ROWS: Array<[string, string]> = [['mobile', 'Mobile'], ['alt_mobile', 'Alternate mobile'], ['date_of_birth', 'Date of birth'], ['blood_group', 'Blood group'], ['address', 'Address'], ['city', 'City'], ['license_number', 'Licence number'], ['license_class', 'Licence class'], ['license_expiry', 'Licence expiry'], ['badge_number', 'Badge number'], ['emergency_contact_name', 'Emergency contact'], ['emergency_contact_phone', 'Emergency phone'], ['emergency_contact_relation', 'Relation'], ['id_proof_type', 'ID type'], ['id_proof_number_masked', 'ID number (masked)'], ['police_verification_status', 'Police verification']];

// TRACE: route /app/admin/bookings/:id/compare → loads comparison, renders candidates + assignment actions.
//        Capability ridego_assign_vendor → admin can assign/ask/reject/replace/reopen/no-show → every mutation
//        re-fetches; handles loading, empty candidates, error/404, reason_required from the API, stale responses,
//        double submit (pending lock), input kept on failure and reset on success.
export function AdminBookingComparePage() {
  const { id } = useParams<{ id: string }>();
  const bookingId = Number(id);
  const toast = useToast();
  const [data, setData] = useState<ComparisonResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [dialog, setDialog] = useState<Dialog>(null);
  const [reason, setReason] = useState('');
  const [reasonForced, setReasonForced] = useState(false);
  const [driverName, setDriverName] = useState('');
  const [driverPhone, setDriverPhone] = useState('');
  const [vehicleModel, setVehicleModel] = useState('');
  const [vehicleReg, setVehicleReg] = useState('');
  const [pending, setPending] = useState(false);
  const [askingLeadId, setAskingLeadId] = useState<number | null>(null);
  const seq = useRef(0);
  const pendingRef = useRef(false);

  // TRACE: mount / id change / after mutation → GET comparison → data or error; silent keeps current data on screen.
  //        bookingId → state set from the newest response only → invalid id and 404 give a friendly error.
  const load = useCallback(
    async (silent: boolean) => {
      if (!bookingId || Number.isNaN(bookingId)) {
        setError('This booking link is not valid.');
        setLoading(false);
        return;
      }
      const mine = ++seq.current;
      if (!silent) setLoading(true);
      try {
        const res = await getBookingComparison(bookingId);
        if (mine !== seq.current) return;
        setData(res);
        setError(null);
      } catch (err) {
        if (mine !== seq.current) return;
        setError(err instanceof ApiError ? err.message : 'Could not load this comparison. Please try again.');
      } finally {
        if (mine === seq.current) setLoading(false);
      }
    },
    [bookingId]
  );

  useEffect(() => {
    // TRACE: mount → load; unmount → invalidate in-flight response → no setState after leaving the page.
    //        bookingId → fresh load → cleanup bumps sequence.
    void load(false);
    return () => {
      seq.current += 1;
    };
  }, [load]);

  // TRACE: closing a dialog (Cancel/Escape/backdrop) → clears dialog and form fields unless a request is running.
  //        dialog open → dialog closed, inputs reset → ignored while pending so a running submit is not orphaned.
  const closeDialog = useCallback(() => {
    if (pendingRef.current) return;
    setDialog(null);
    setReason('');
    setReasonForced(false);
    setDriverName('');
    setDriverPhone('');
    setVehicleModel('');
    setVehicleReg('');
  }, []);

  // TRACE: an action button → opens the matching dialog with empty inputs → dialog state set.
  //        dialog descriptor → dialog visible → replace dialog is prefilled from the current assignment.
  function openDialog(next: Exclude<Dialog, null>) {
    setReason('');
    setReasonForced(false);
    if (next.kind === 'replace') {
      const a = data?.assignment;
      setDriverName(a?.driver_name_snapshot ?? '');
      setDriverPhone(a?.driver_phone_snapshot ?? '');
      setVehicleModel(a?.vehicle_model_snapshot ?? '');
      setVehicleReg(a?.vehicle_registration_snapshot ?? '');
    }
    setDialog(next);
  }

  // TRACE: any mutation → runs the request under a pending lock, toasts the outcome, re-fetches server state.
  //        request fn + fallback message → success closes/reset dialog and reloads → failure toasts ApiError message,
  //        keeps dialog and input; API success=false payloads are treated as failures; double submit blocked.
  async function run(request: () => Promise<MutationResult>, fallbackSuccess: string): Promise<boolean> {
    if (pendingRef.current) return false;
    pendingRef.current = true;
    setPending(true);
    try {
      const res = await request();
      if (res && res.success === false) {
        toast.show(res.message || 'The action could not be completed.', 'error');
        return false;
      }
      toast.show(res?.message || fallbackSuccess, 'success');
      pendingRef.current = false;
      closeDialog();
      await load(true);
      return true;
    } catch (err) {
      if (err instanceof ApiError && err.code === 'reason_required') setReasonForced(true);
      toast.show(err instanceof ApiError ? err.message : 'Something went wrong. Please try again.', 'error');
      return false;
    } finally {
      pendingRef.current = false;
      setPending(false);
    }
  }

  // TRACE: submit of the assign sheet → POST assign with vendor, lead and reason → toast + reload.
  //        candidate chosen → booking assigned, other leads marked not selected → blank required reason blocked client-side.
  async function submitAssign(e: FormEvent) {
    e.preventDefault();
    if (dialog?.kind !== 'assign') return;
    const c = dialog.candidate;
    await run(() => assignBookingCandidate(bookingId, { vendor_id: c.vendor_id, lead_id: c.lead_id, reason: reason.trim() }), `${c.vendor_name} assigned.`);
  }

  // TRACE: submit of the reject sheet → POST lead reject with reason → toast + reload.
  //        open lead → marked not selected and vendor notified → reason is required in the UI.
  async function submitReject(e: FormEvent) {
    e.preventDefault();
    if (dialog?.kind !== 'reject') return;
    const c = dialog.candidate;
    await run(() => rejectLead(c.lead_id, reason.trim()), `${c.vendor_name} marked as not selected.`);
  }

  // TRACE: submit of the change driver/vehicle sheet → POST replace-assignment → toast + reload.
  //        at least one of driver/vehicle plus a reason → new current assignment → empty combo blocked client-side.
  async function submitReplace(e: FormEvent) {
    e.preventDefault();
    await run(
      () =>
        replaceBookingAssignment(bookingId, {
          driver_name: driverName.trim(),
          driver_phone: driverPhone.trim(),
          vehicle_model: vehicleModel.trim(),
          vehicle_registration: vehicleReg.trim(),
          reason: reason.trim(),
        }),
      'Driver and vehicle updated.'
    );
  }

  // TRACE: Ask for driver details click → POST request-driver-details for that lead → toast + reload.
  //        interested lead without a driver → vendor notified → per-row loading, ignored while another action runs.
  async function askDriver(c: ComparisonCandidate) {
    if (pendingRef.current) return;
    setAskingLeadId(c.lead_id);
    await run(() => requestDriverDetails(c.lead_id), `${c.vendor_name} asked for driver details.`);
    setAskingLeadId(null);
  }

  const booking = data?.booking ?? null;
  const ranking: RankingEntry[] = data?.ranking ?? [];
  const topVendorId = ranking.length > 0 ? ranking[0].vendor_id : null;
  const hasVendor = Boolean(booking?.vendor_id);
  const assignCandidate = dialog?.kind === 'assign' ? dialog.candidate : null;
  const assignNeedsReason =
    assignCandidate !== null && (reasonForced || (ranking.length > 0 && topVendorId !== assignCandidate.vendor_id));
  const otherOpenCount = assignCandidate
    ? (data?.candidates ?? []).filter((c) => c.lead_id !== assignCandidate.lead_id && c.status === 'sent').length
    : 0;
  const replaceEmpty = !driverName.trim() && !vehicleReg.trim() && !vehicleModel.trim() && !driverPhone.trim();

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <Link to={booking ? `/app/admin/bookings/${booking.id}` : '/admin/bookings'} className="text-sm font-medium text-brand-700 hover:text-brand-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600">
        ← Back to booking
      </Link>
      <h1 className="mt-1 text-2xl font-bold text-ink-900 sm:text-3xl">Compare and assign</h1>

      {loading && (
        <div className="mt-6 space-y-3" aria-busy="true" aria-label="Loading comparison">
          <Skeleton className="h-24 w-full rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={() => void load(false)} />
        </div>
      )}

      {!loading && data && booking && (
        <>
          {error && (
            <div className="mt-4">
              <ErrorBanner message={error} onRetry={() => void load(false)} />
            </div>
          )}

          <section aria-label="Booking summary" className="mt-6 rounded-xl border border-ink-100 bg-white p-4 shadow-xs sm:p-5">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <p className="text-lg font-semibold text-ink-900">{booking.booking_number}</p>
                <p className="text-sm text-ink-600">
                  {booking.pickup_city} → {booking.drop_city}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {booking.is_safety_sensitive && (
                  <span className="rounded-full bg-warning-50 px-2.5 py-1 text-xs font-semibold text-warning-700" title="Female-only or includes children — requires manual review.">
                    🛡 Safety-sensitive
                  </span>
                )}
                <span className="rounded-full bg-ink-100 px-2.5 py-1 text-xs font-semibold text-ink-700">{booking.status.replace(/_/g, ' ')}</span>
              </div>
            </div>
            <dl className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
              <div>
                <dt className="text-ink-500">Journey</dt>
                <dd className="font-medium text-ink-800">
                  {booking.journey_date} {booking.journey_time}
                </dd>
              </div>
              <div>
                <dt className="text-ink-500">Passengers</dt>
                <dd className="font-medium text-ink-800">
                  {booking.passengers}
                  {(booking.passenger_male !== null || booking.passenger_female !== null || booking.passenger_children !== null) && (
                    <span className="block text-xs font-normal text-ink-500">
                      {[
                        booking.passenger_female ? `${booking.passenger_female}F` : null,
                        booking.passenger_male ? `${booking.passenger_male}M` : null,
                        booking.passenger_children ? `${booking.passenger_children} child${booking.passenger_children === 1 ? '' : 'ren'}` : null,
                      ]
                        .filter(Boolean)
                        .join(' · ')}
                    </span>
                  )}
                </dd>
              </div>
              <div>
                <dt className="text-ink-500">Fare</dt>
                <dd className="font-medium text-ink-800">{currency(booking.total_fare)}</dd>
              </div>
              <div>
                <dt className="text-ink-500">Lead mode</dt>
                <dd className="font-medium text-ink-800">{data.lead_mode === 'compare' ? 'Compare & select' : 'Instant accept'}</dd>
              </div>
            </dl>
          </section>

          {hasVendor && (
            <section aria-label="Current assignment" className="mt-4 rounded-xl border border-brand-200 bg-brand-50 p-4 sm:p-5">
              <h2 className="text-base font-semibold text-ink-900">Current assignment</h2>
              {data.assignment ? (
                <dl className="mt-2 grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
                  <div>
                    <dt className="text-ink-600">Vendor</dt>
                    <dd className="font-medium text-ink-900">
                      {data.candidates.find((c) => c.vendor_id === data.assignment?.vendor_id)?.vendor_name ?? `Vendor #${data.assignment.vendor_id}`}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-ink-600">Driver</dt>
                    <dd className="font-medium text-ink-900">
                      {data.assignment.driver_name_snapshot || 'Not provided yet'}
                      {data.assignment.driver_phone_snapshot ? ` · ${data.assignment.driver_phone_snapshot}` : ''}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-ink-600">Vehicle</dt>
                    <dd className="font-medium text-ink-900">
                      {data.assignment.vehicle_model_snapshot || 'Not provided yet'}
                      {data.assignment.vehicle_registration_snapshot ? ` · ${data.assignment.vehicle_registration_snapshot}` : ''}
                    </dd>
                  </div>
                </dl>
              ) : (
                <p className="mt-2 text-sm text-ink-700">A vendor is assigned but no driver or vehicle snapshot is recorded.</p>
              )}
              {data.assignment?.driver_profile && (
                <div className="mt-3 rounded-lg border border-ink-100 bg-ink-50 p-3">
                  <h4 className="text-sm font-semibold text-ink-900">Driver details for tracking</h4>
                  <dl className="mt-2 grid gap-x-4 gap-y-1 text-sm sm:grid-cols-2">
                    {DRIVER_TRACE_ROWS.map(([k, label]) => {
                      const v = data.assignment?.driver_profile?.[k] ?? '';
                      return (
                        <div key={k}>
                          <dt className="text-ink-600">{label}</dt>
                          <dd className="font-medium text-ink-900">{v && v !== '0000-00-00' ? v : 'Not recorded'}</dd>
                        </div>
                      );
                    })}
                  </dl>
                </div>
              )}
              <div className="mt-4 flex flex-wrap gap-2">
                <Button size="sm" variant="secondary" onClick={() => openDialog({ kind: 'replace' })}>
                  Change driver/vehicle
                </Button>
                <Button size="sm" variant="secondary" onClick={() => openDialog({ kind: 'reopen' })}>
                  Reopen for reassignment
                </Button>
                <Button size="sm" variant="danger" onClick={() => openDialog({ kind: 'noshow' })}>
                  Report no-show
                </Button>
              </div>
            </section>
          )}

          <section aria-label="Candidates" className="mt-6">
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-lg font-semibold text-ink-900">Candidates ({data.candidates.length})</h2>
              <Button size="sm" variant="secondary" onClick={() => void load(true)} disabled={pending}>
                Refresh
              </Button>
            </div>
            {data.recommendations_enabled && ranking.length > 0 && !hasVendor && (() => {
              const topCand = data.candidates.find((c) => c.vendor_id === topVendorId);
              if (!topCand) return null;
              return (
                <div role="region" aria-label="System recommendation" className="mt-3 rounded-xl border border-brand-200 bg-brand-50 p-4">
                  <p className="text-sm font-semibold text-ink-900">System recommendation: {topCand.vendor_name}</p>
                  <p className="mt-1 text-sm text-ink-700">Ranked first on score. Accept it, or choose another vendor below and explain why.</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button size="sm" disabled={!topCand.can_select || pending} onClick={() => openDialog({ kind: 'assign', candidate: topCand })}>
                      Accept recommendation
                    </Button>
                    <Button size="sm" variant="secondary" onClick={() => document.getElementById('candidate-list')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>
                      Choose another
                    </Button>
                  </div>
                </div>
              );
            })()}
            {data.recommendations_enabled && ranking.length === 0 && data.candidates.length > 0 && (
              <p className="mt-2 text-sm text-ink-600">Recommendations are on, but no candidate is ready to be ranked yet.</p>
            )}

            {data.candidates.length === 0 ? (
              <div className="mt-3">
                <EmptyState
                  title="No vendors have been offered this booking"
                  description={
                    data.lead_mode === 'compare'
                      ? 'In compare mode, vendors receive the lead and show interest first; you then pick one here. Nobody has been offered this booking yet.'
                      : 'In instant mode the first eligible vendor to accept wins the booking automatically, so no shortlist is built. Nobody has been offered this booking yet.'
                  }
                  action={
                    hasVendor ? undefined : (
                      <Link
                        to={`/app/admin/bookings/${booking.id}`}
                        className="inline-flex rounded-lg border border-ink-200 bg-white px-4 py-2.5 text-sm font-medium text-ink-800 hover:bg-ink-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
                      >
                        Assign a vendor manually
                      </Link>
                    )
                  }
                />
              </div>
            ) : (
              <ul id="candidate-list" className="mt-3 space-y-3">
                {data.candidates.map((c) => {
                  const rankIndex = ranking.findIndex((r) => r.lead_id === c.lead_id);
                  const rank = rankIndex >= 0 ? ranking[rankIndex] : null;
                  const recommended = data.recommendations_enabled && rankIndex === 0;
                  const needsDriver = c.status === 'sent' && c.interest_status === 'interested' && !c.driver_name;
                  const canAct = c.can_select && !hasVendor;
                  return (
                    <li key={c.lead_id} className={`rounded-xl border bg-white p-4 shadow-xs sm:p-5 ${recommended ? 'border-brand-400' : 'border-ink-100'}`}>
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="font-semibold text-ink-900">{c.vendor_name}</h3>
                            <span className="rounded-full bg-ink-100 px-2 py-0.5 text-xs font-semibold text-ink-700">
                              {c.vendor_type === 'individual' ? 'Individual' : 'Fleet'}
                            </span>
                            {recommended && (
                              <span className="rounded-full bg-brand-600 px-2 py-0.5 text-xs font-semibold text-white">★ Recommended</span>
                            )}
                          </div>
                          <p className="mt-0.5 text-sm text-ink-600">
                            Rating {c.rating > 0 ? c.rating.toFixed(1) : 'none yet'} · {c.rides} ride{c.rides === 1 ? '' : 's'} · Fee {currency(c.fee_amount)}
                          </p>
                        </div>
                        <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${interestTone(c.interest_status)}`}>
                          {INTEREST_LABELS[c.interest_status] ?? c.interest_status}
                        </span>
                      </div>

                      <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-sm md:grid-cols-4">
                        <div>
                          <dt className="text-ink-500">Sent</dt>
                          <dd className="text-ink-800">{formatWhen(c.sent_at)}</dd>
                        </div>
                        <div>
                          <dt className="text-ink-500">Viewed</dt>
                          <dd className="text-ink-800">{formatWhen(c.viewed_at)}</dd>
                        </div>
                        <div>
                          <dt className="text-ink-500">Interested</dt>
                          <dd className="text-ink-800">{formatWhen(c.interested_at)}</dd>
                        </div>
                        <div>
                          <dt className="text-ink-500">Driver confirmed</dt>
                          <dd className="text-ink-800">{formatWhen(c.driver_confirmed_at)}</dd>
                        </div>
                        <div>
                          <dt className="text-ink-500">Driver</dt>
                          <dd className="text-ink-800">{c.driver_name || 'Not provided'}</dd>
                        </div>
                        <div>
                          <dt className="text-ink-500">Vehicle</dt>
                          <dd className="text-ink-800">
                            {c.vehicle_registration ? `${c.vehicle_model ? `${c.vehicle_model} · ` : ''}${c.vehicle_registration}` : 'Not provided'}
                          </dd>
                        </div>
                        {c.not_selected_reason && (
                          <div className="col-span-2">
                            <dt className="text-ink-500">Reason not selected</dt>
                            <dd className="text-ink-800">{c.not_selected_reason}</dd>
                          </div>
                        )}
                      </dl>

                      {rank && (
                        <div className="mt-3 rounded-lg bg-ink-50 p-3">
                          <p className="text-sm font-medium text-ink-800">
                            Rank {rankIndex + 1} · Score {rank.score.toFixed(1)}
                          </p>
                          <ul className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-ink-600">
                            {Object.entries(rank.breakdown).map(([key, val]) => (
                              <li key={key}>
                                {factorLabel(key)}: {Number(val).toFixed(2)}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <div className="mt-4 flex flex-wrap items-center gap-2">
                        <Button size="sm" disabled={!canAct || pending} onClick={() => openDialog({ kind: 'assign', candidate: c })} aria-label={`Assign ${c.vendor_name} to ${booking.booking_number}`}>
                          Assign
                        </Button>
                        {needsDriver && (
                          <Button size="sm" variant="secondary" loading={askingLeadId === c.lead_id} disabled={pending} onClick={() => void askDriver(c)}>
                            Ask for driver details
                          </Button>
                        )}
                        <Button size="sm" variant="secondary" disabled={c.status !== 'sent' || pending} onClick={() => openDialog({ kind: 'reject', candidate: c })} aria-label={`Reject ${c.vendor_name}`}>
                          Reject
                        </Button>
                        {!c.can_select && (
                          <p className="text-xs text-ink-600">
                            {c.status !== 'sent'
                              ? 'Not selectable: this lead is closed.'
                              : c.interest_status === 'interested' || c.interest_status === 'driver_confirmed'
                                ? 'Not selectable: this vendor is not active.'
                                : 'Not selectable until the vendor shows interest.'}
                          </p>
                        )}
                        {c.can_select && hasVendor && <p className="text-xs text-ink-600">A vendor is already assigned. Reopen the booking to choose another.</p>}
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </>
      )}

      <BottomSheet open={dialog?.kind === 'assign'} title={assignCandidate ? `Assign ${assignCandidate.vendor_name}` : 'Assign'} onClose={closeDialog}>
        {assignCandidate && (
          <form onSubmit={submitAssign} className="space-y-4">
            {booking?.is_safety_sensitive && (
              <p className="rounded-lg border border-warning-300 bg-warning-50 px-3 py-2 text-sm font-medium text-warning-800">
                🛡 This booking is flagged safety-sensitive (female-only or includes children). Confirming here is the manual review this booking requires — double-check the vendor/driver before assigning.
              </p>
            )}
            <p className="text-sm text-ink-700">
              {assignCandidate.vendor_name} will get booking {booking?.booking_number}.{' '}
              {otherOpenCount > 0
                ? `The other ${otherOpenCount} open vendor${otherOpenCount === 1 ? '' : 's'} will be marked not selected and told the booking went elsewhere.`
                : 'No other open vendors remain on this booking.'}
            </p>
            <Field
              id="assign-reason"
              label={assignNeedsReason ? 'Reason (required)' : 'Reason (optional)'}
              hint={assignNeedsReason ? 'This vendor is not the top recommendation, so explain your choice.' : undefined}
            >
              <textarea id="assign-reason" rows={3} value={reason} onChange={(e) => setReason(e.target.value)} className={INPUT_CLASS} required={assignNeedsReason} />
            </Field>
            <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <Button type="button" variant="secondary" onClick={closeDialog} disabled={pending}>
                Cancel
              </Button>
              <Button type="submit" loading={pending} disabled={assignNeedsReason && !reason.trim()}>
                Assign vendor
              </Button>
            </div>
          </form>
        )}
      </BottomSheet>

      <BottomSheet open={dialog?.kind === 'reject'} title={dialog?.kind === 'reject' ? `Reject ${dialog.candidate.vendor_name}` : 'Reject'} onClose={closeDialog}>
        <form onSubmit={submitReject} className="space-y-4">
          <p className="text-sm text-ink-700">The vendor is marked not selected and notified. This cannot be undone.</p>
          <Field id="reject-reason" label="Reason (required)">
            <textarea id="reject-reason" rows={3} value={reason} onChange={(e) => setReason(e.target.value)} className={INPUT_CLASS} required />
          </Field>
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button type="button" variant="secondary" onClick={closeDialog} disabled={pending}>
              Cancel
            </Button>
            <Button type="submit" variant="danger" loading={pending} disabled={!reason.trim()}>
              Reject vendor
            </Button>
          </div>
        </form>
      </BottomSheet>

      <BottomSheet open={dialog?.kind === 'replace'} title="Change driver/vehicle" onClose={closeDialog}>
        <form onSubmit={submitReplace} className="space-y-3">
          <Field id="rep-driver" label="Driver name">
            <input id="rep-driver" type="text" value={driverName} onChange={(e) => setDriverName(e.target.value)} className={INPUT_CLASS} autoComplete="off" />
          </Field>
          <Field id="rep-phone" label="Driver phone">
            <input id="rep-phone" type="tel" inputMode="tel" value={driverPhone} onChange={(e) => setDriverPhone(e.target.value)} className={INPUT_CLASS} autoComplete="off" />
          </Field>
          <Field id="rep-model" label="Vehicle model">
            <input id="rep-model" type="text" value={vehicleModel} onChange={(e) => setVehicleModel(e.target.value)} className={INPUT_CLASS} autoComplete="off" />
          </Field>
          <Field id="rep-reg" label="Vehicle registration">
            <input id="rep-reg" type="text" value={vehicleReg} onChange={(e) => setVehicleReg(e.target.value)} className={INPUT_CLASS} autoComplete="off" />
          </Field>
          <Field id="rep-reason" label="Reason (required)">
            <textarea id="rep-reason" rows={2} value={reason} onChange={(e) => setReason(e.target.value)} className={INPUT_CLASS} required />
          </Field>
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button type="button" variant="secondary" onClick={closeDialog} disabled={pending}>
              Cancel
            </Button>
            <Button type="submit" loading={pending} disabled={!reason.trim() || replaceEmpty}>
              Save changes
            </Button>
          </div>
        </form>
      </BottomSheet>

      <ConfirmDialog
        open={dialog?.kind === 'reopen'}
        title={`Reopen ${booking?.booking_number ?? 'this booking'}?`}
        description="The current vendor is removed and the booking is offered to vendors again."
        confirmLabel="Reopen for reassignment"
        loading={pending}
        confirmDisabled={!reason.trim()}
        onConfirm={() => void run(() => reopenBooking(bookingId, reason.trim()), 'Booking reopened for reassignment.')}
        onCancel={closeDialog}
      >
        <label htmlFor="reopen-reason" className="mb-1 block text-sm font-medium text-ink-800">
          Reason (required)
        </label>
        <textarea id="reopen-reason" rows={3} value={reason} onChange={(e) => setReason(e.target.value)} className={INPUT_CLASS} />
      </ConfirmDialog>

      <ConfirmDialog
        open={dialog?.kind === 'noshow'}
        title={`Report no-show on ${booking?.booking_number ?? 'this booking'}?`}
        description="The driver did not turn up. This records the issue against the vendor."
        confirmLabel="Report no-show"
        confirmVariant="danger"
        loading={pending}
        onConfirm={() => void run(() => reportBookingNoShow(bookingId, reason.trim()), 'No-show reported.')}
        onCancel={closeDialog}
      >
        <label htmlFor="noshow-notes" className="mb-1 block text-sm font-medium text-ink-800">
          Notes (optional)
        </label>
        <textarea id="noshow-notes" rows={2} value={reason} onChange={(e) => setReason(e.target.value)} className={INPUT_CLASS} />
      </ConfirmDialog>
    </div>
  );
}
