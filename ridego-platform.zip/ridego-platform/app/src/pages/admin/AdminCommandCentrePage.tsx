import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ApiError } from '../../lib/api';
import { getCommandCentre, type CommandBookingRow, type CommandCentreResponse } from '../../lib/api-admin-command';
import { BookingQuickActions } from '../../components/admin/BookingQuickActions';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Button } from '../../components/ui/Button';

const REFRESH_MS = 60_000;

interface QueueDef {
  key: 'new_leads' | 'awaiting_vendor_response' | 'driver_pending' | 'ready_for_assignment' | 'today_trips' | 'payments_pending' | 'needs_driver_details' | 'ongoing';
  title: string;
  empty: string;
  compare: boolean;
}

const QUEUES: QueueDef[] = [
  { key: 'new_leads', title: 'New leads', empty: 'Every confirmed booking has been offered to vendors.', compare: true },
  { key: 'awaiting_vendor_response', title: 'Awaiting vendor response', empty: 'No vendor is sitting on a lead.', compare: true },
  { key: 'driver_pending', title: 'Driver pending', empty: 'No interested vendor still owes driver details.', compare: true },
  { key: 'ready_for_assignment', title: 'Ready for assignment', empty: 'No booking has a driver-confirmed vendor waiting for you.', compare: true },
  { key: 'today_trips', title: "Today's trips", empty: 'No assigned trips today.', compare: false },
  { key: 'payments_pending', title: 'Booking amount pending', empty: 'No booking amounts are waiting.', compare: false },
  { key: 'needs_driver_details', title: 'Assigned, driver details missing', empty: 'Every assigned trip has a driver and vehicle.', compare: false },
  { key: 'ongoing', title: 'Ongoing trips', empty: 'No trips are on the road right now.', compare: false },
];

// TRACE: number → formats as rupees with Indian grouping → string.
//        finite number → "₹1,234" → non-finite treated as 0.
function currency(n: number): string {
  return `₹${(Number.isFinite(n) ? n : 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

// TRACE: snake_case status → words with capital first letters → string.
//        any string → "Vendor Assigned" → empty string stays empty.
function humanize(value: string): string {
  return value
    .split('_')
    .map((part) => (part ? part[0].toUpperCase() + part.slice(1) : part))
    .join(' ');
}

// TRACE: KPI tile props → renders label + value card → element.
//        label/value strings → card in the KPI grid → loading shows a skeleton instead of the value.
function KpiTile({ label, value, loading }: { label: string; value: string; loading: boolean }) {
  return (
    <div className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs">
      <p className="text-xs font-medium uppercase tracking-wide text-ink-500">{label}</p>
      {loading ? <Skeleton className="mt-2 h-6 w-20" /> : <p className="mt-2 text-xl font-bold text-ink-900">{value}</p>}
    </div>
  );
}

// TRACE: queue definition + rows → renders a titled list of linked booking rows or an "All clear" state → element.
//        rows array (max 50 from API) → links to compare or detail → empty rows show the friendly all-clear text.
function QueueSection({ def, rows, onDone }: { def: QueueDef; rows: CommandBookingRow[]; onDone: () => void }) {
  const headingId = `queue-${def.key}`;
  return (
    <section aria-labelledby={headingId} className="min-w-0 rounded-xl border border-ink-100 bg-white p-4 shadow-xs sm:p-5">
      <div className="flex items-center justify-between gap-2">
        <h2 id={headingId} className="text-base font-semibold text-ink-900">
          {def.title}
        </h2>
        <span className="rounded-full bg-ink-100 px-2.5 py-0.5 text-xs font-semibold text-ink-700">{rows.length}</span>
      </div>
      {rows.length === 0 ? (
        <p className="mt-3 rounded-lg bg-success-50 px-3 py-2.5 text-sm text-success-700">
          <span aria-hidden="true">✓ </span>All clear. {def.empty}
        </p>
      ) : (
        <ul className="mt-3 divide-y divide-ink-100">
          {rows.map((r) => {
            const sum = r.response_summary;
            const first = r.vendors?.[0];
            return (
              <li key={r.id} className="py-3">
                <p className="font-semibold text-ink-900">
                  {r.booking_number} <span className="ml-1 rounded-full bg-ink-100 px-2 py-0.5 text-xs font-semibold text-ink-700">{humanize(r.status)}</span>
                </p>
                <p className="truncate text-sm text-ink-600">
                  {r.pickup_city} → {r.drop_city} · {r.client_name}
                </p>
                <p className="text-xs text-ink-500">
                  {r.journey_date} {r.journey_time} · {currency(Number(r.total_fare))}
                </p>
                {sum && sum.total > 0 && (
                  <p className="mt-1 text-xs font-medium text-brand-700">
                    {sum.total} vendors · {sum.interested} interested · {sum.driver_confirmed} driver confirmed
                  </p>
                )}
                <div className="mt-2">
                  <BookingQuickActions
                    bookingId={r.id}
                    bookingNumber={r.booking_number}
                    status={r.status}
                    hasVendor={Boolean(r.vendor_id)}
                    clientPhone={r.client_phone}
                    vendorPhone={def.key === 'payments_pending' ? undefined : first?.phone}
                    vendorName={first?.name}
                    section={def.key === 'new_leads' || def.key === 'awaiting_vendor_response' || def.key === 'driver_pending' || def.key === 'ready_for_assignment' ? def.key : 'other'}
                    paymentStatus={def.key === 'payments_pending' ? 'pending' : undefined}
                    onDone={onDone}
                  />
                  <Link className="mt-2 inline-block text-xs font-semibold text-brand-700 underline" to={`/app/admin/bookings/${r.id}`}>Open booking</Link>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

// TRACE: route /app/admin/command-centre → fetches queues now and every 60s, manual Refresh → renders KPIs and queues.
//        Capability ridego_view_command_centre → data shown or error banner → stale responses ignored, interval cleared
//        on unmount, first load shows skeletons, background refresh keeps old data visible, 403/network errors shown.
export function AdminCommandCentrePage() {
  const [data, setData] = useState<CommandCentreResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const requestSeq = useRef(0);
  const hasData = useRef(false);

  // TRACE: mount / interval / Refresh click → GET command centre → state updated with the newest response only.
  //        none → data or error set → older in-flight responses dropped via sequence number.
  const load = useCallback(async () => {
    const seq = ++requestSeq.current;
    if (hasData.current) setRefreshing(true);
    else setLoading(true);
    try {
      const res = await getCommandCentre();
      if (seq !== requestSeq.current) return;
      hasData.current = true;
      setData(res);
      setError(null);
      setUpdatedAt(new Date());
    } catch (err) {
      if (seq !== requestSeq.current) return;
      setError(err instanceof ApiError ? err.message : 'Could not load the command centre. Please try again.');
    } finally {
      if (seq === requestSeq.current) {
        setLoading(false);
        setRefreshing(false);
      }
    }
  }, []);

  useEffect(() => {
    // TRACE: mount → first load + 60s timer → cleanup clears timer and invalidates in-flight requests.
    //        none → periodic refresh → unmount stops updates.
    void load();
    const timer = window.setInterval(() => {
      void load();
    }, REFRESH_MS);
    return () => {
      window.clearInterval(timer);
      requestSeq.current += 1;
    };
  }, [load]);

  const kpis = data?.kpis;
  const showSkeleton = loading && !data;

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Command centre</h1>
          <p className="text-sm text-ink-600">
            What needs attention right now.
            {updatedAt && <span> Updated {updatedAt.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}.</span>}
          </p>
        </div>
        <Button variant="secondary" size="sm" onClick={() => void load()} loading={refreshing} disabled={showSkeleton}>
          Refresh
        </Button>
      </div>

      {error && (
        <div className="mt-4">
          <ErrorBanner message={error} onRetry={() => void load()} />
        </div>
      )}

      {showSkeleton && (
        <div className="mt-6 space-y-4" aria-busy="true" aria-label="Loading command centre">
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-6">
            {QUEUES.map((q) => (
              <Skeleton key={q.key} className="h-20 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-40 w-full rounded-xl" />
          <Skeleton className="h-40 w-full rounded-xl" />
        </div>
      )}

      {data && (
        <>
          <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
            <KpiTile label="Bookings today" value={String(kpis?.bookings_today ?? 0)} loading={false} />
            <KpiTile label="GMV today" value={currency(kpis?.gmv_today ?? 0)} loading={false} />
            <KpiTile label="Pending ledger net" value={currency(kpis?.ledger_pending_net ?? 0)} loading={false} />
            <KpiTile label="Active vendors" value={String(kpis?.active_vendors ?? 0)} loading={false} />
            <KpiTile label="Open complaints" value={String(data.complaints_open)} loading={false} />
            <div className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs">
              <p className="text-xs font-medium uppercase tracking-wide text-ink-500">Lead mode</p>
              <p className="mt-2">
                <span className="rounded-full bg-brand-50 px-2.5 py-1 text-sm font-semibold text-brand-700">
                  {data.lead_mode === 'compare' ? 'Compare & select' : data.lead_mode === 'instant' ? 'Instant accept' : humanize(String(data.lead_mode))}
                </span>
              </p>
            </div>
          </div>

          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            {QUEUES.map((q) => (
              <QueueSection key={q.key} def={q} rows={data[q.key]} onDone={() => void load()} />
            ))}
          </div>

          <section aria-labelledby="activity-feed" className="mt-6 rounded-xl border border-ink-100 bg-white p-4 shadow-xs sm:p-5">
            <h2 id="activity-feed" className="text-base font-semibold text-ink-900">Recent activity</h2>
            {data.activity.length === 0 ? (
              <p className="mt-3 text-sm text-ink-600">No activity has been recorded yet.</p>
            ) : (
              <ul className="mt-3 divide-y divide-ink-100">
                {data.activity.map((a) => (
                  <li key={a.id} className="flex flex-wrap justify-between gap-2 py-2 text-sm">
                    <span className="text-ink-800">{humanize(a.action)} · {a.entity}{a.entity_id ? ` #${a.entity_id}` : ''}</span>
                    <span className="text-xs text-ink-500">{a.created_at}</span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </>
      )}
    </div>
  );
}
