import { useCallback, useEffect, useRef, useState } from 'react';
import { ApiError } from '../../lib/api';
import { getMarketplaceReport, type MarketplaceReport } from '../../lib/api-admin-finance';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';

const inputCls =
  'mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500/40';

const WHO_LABELS: Record<string, string> = {
  client: 'Client',
  vendor: 'Vendor',
  admin: 'Admin',
  system: 'System',
  unknown: 'Not recorded',
};

// TRACE: Date → local yyyy-mm-dd string → used for the date inputs.
//        Preconditions: valid Date → postconditions: pure → edge cases: uses local (not UTC) calendar day.
function isoDay(d: Date): string {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

// TRACE: API value → finite number → 0 for null or non-numeric. Preconditions: none → postconditions: pure → edge cases: '5' string.
function n(v: number | string | null | undefined): number {
  const x = Number(v);
  return Number.isFinite(x) ? x : 0;
}

// TRACE: rupee value → "₹1,234.5". Preconditions: none → postconditions: pure → edge cases: NaN renders as ₹0.
function money(v: number | string | null | undefined): string {
  return `₹${n(v).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

// TRACE: label, count and the largest count → one CSS bar row with the number printed beside it.
//        Preconditions: counts are non-negative → postconditions: pure render; value is always shown as text →
//        edge cases: zero max renders an empty bar without dividing by zero.
function BarRow({ label, value, max, note }: { label: string; value: number; max: number; note?: string }) {
  return (
    <li className="flex items-center gap-3 text-sm">
      <span className="w-36 shrink-0 text-ink-700 sm:w-44">{label}</span>
      <div className="h-4 flex-1 overflow-hidden rounded bg-ink-100">
        <div className="h-full rounded bg-brand-600" style={{ width: max > 0 ? `${Math.min(100, (value / max) * 100)}%` : '0%' }} />
      </div>
      <span className="w-28 shrink-0 text-right font-medium text-ink-900">
        {value}
        {note ? <span className="ml-1 text-xs font-normal text-ink-500">{note}</span> : null}
      </span>
    </li>
  );
}

// TRACE: route /app/admin/reports/marketplace → date range → GET marketplace report → funnel, response time,
//        cancellations, commission by vendor, volume by vendor type.
//        Preconditions: cap ridego_view_reports → postconditions: read-only →
//        edge cases: loading skeleton, error banner with retry, empty range (no bookings) shows an empty state,
//        reversed range blocked, stale responses dropped, conversion shown only when the previous step is above zero.
export function AdminMarketplaceReportsPage() {
  const [from, setFrom] = useState(() => isoDay(new Date(Date.now() - 30 * 86400000)));
  const [to, setTo] = useState(() => isoDay(new Date()));
  const [data, setData] = useState<MarketplaceReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const seq = useRef(0);
  const rangeInvalid = from !== '' && to !== '' && from > to;

  // TRACE: range change / retry → GET report for the range → stores it.
  //        Preconditions: range not reversed → postconditions: latest request wins →
  //        edge cases: ApiError message shown, stale response dropped, loading cleared in finally.
  const load = useCallback(async () => {
    if (rangeInvalid) return;
    const id = ++seq.current;
    setLoading(true);
    setError(null);
    try {
      const res = await getMarketplaceReport(from, to);
      if (id !== seq.current) return;
      setData(res);
    } catch (err) {
      if (id !== seq.current) return;
      setError(err instanceof ApiError ? err.message : 'Could not load the marketplace report. Please try again.');
    } finally {
      if (id === seq.current) setLoading(false);
    }
  }, [from, to, rangeInvalid]);

  // TRACE: range change → runs load; unmount → invalidates in-flight request. Preconditions: none →
  //        postconditions: no state writes after unmount → edge cases: none.
  useEffect(() => {
    void load();
    return () => {
      seq.current += 1;
    };
  }, [load]);

  const f = data?.funnel;
  const steps = f
    ? [
        { label: 'Bookings', value: f.bookings },
        { label: 'With leads sent', value: f.with_leads },
        { label: 'With vendor interest', value: f.with_interest },
        { label: 'Assigned to a vendor', value: f.assigned },
        { label: 'Completed', value: f.completed },
      ]
    : [];
  const cancelTotal = (data?.cancellations ?? []).reduce((s, c) => s + n(c.n), 0);
  const maxCancel = Math.max(0, ...(data?.cancellations ?? []).map((c) => n(c.n)));
  const maxCommission = Math.max(0, ...(data?.commission_by_vendor ?? []).map((c) => n(c.commission)));
  const maxType = Math.max(0, ...(data?.volume_by_vendor_type ?? []).map((t) => n(t.bookings)));

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Marketplace report</h1>
      <p className="text-sm text-ink-500">How bookings move from request to completion, and where they drop out.</p>

      <form className="mt-6 grid gap-3 sm:max-w-md sm:grid-cols-2" onSubmit={(e) => e.preventDefault()} aria-label="Report date range">
        <div>
          <label htmlFor="mr-from" className="block text-sm font-medium text-ink-700">
            From
          </label>
          <input id="mr-from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} className={inputCls} />
        </div>
        <div>
          <label htmlFor="mr-to" className="block text-sm font-medium text-ink-700">
            To
          </label>
          <input id="mr-to" type="date" value={to} onChange={(e) => setTo(e.target.value)} className={inputCls} />
        </div>
      </form>
      {rangeInvalid && (
        <p role="alert" className="mt-2 text-sm text-danger-600">
          The start date must be on or before the end date.
        </p>
      )}

      {loading && !data && (
        <div className="mt-6 space-y-3" aria-busy="true" aria-label="Loading report">
          <Skeleton className="h-48 w-full rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
        </div>
      )}
      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {data && !error && f && (
        <div aria-busy={loading}>
          {f.bookings === 0 ? (
            <div className="mt-6">
              <EmptyState title="No bookings in this range" description={`Nothing was created between ${data.from} and ${data.to}. Try a wider range.`} />
            </div>
          ) : (
            <section className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs" aria-labelledby="funnel-heading">
              <h2 id="funnel-heading" className="text-base font-semibold text-ink-900">
                Booking funnel
              </h2>
              <ul className="mt-4 space-y-3">
                {steps.map((s, i) => {
                  const prev = i > 0 ? steps[i - 1].value : 0;
                  const note = i > 0 && prev > 0 ? `${((s.value / prev) * 100).toFixed(1)}% of previous` : undefined;
                  return <BarRow key={s.label} label={s.label} value={s.value} max={f.bookings} note={note} />;
                })}
              </ul>
              <p className="mt-3 text-xs text-ink-500">
                Overall conversion to completed: {((f.completed / f.bookings) * 100).toFixed(1)}%.
              </p>
              <p className="mt-3 text-sm text-ink-700">
                Average time to first vendor interest:{' '}
                <strong>{data.avg_minutes_to_interest === null ? 'no interest recorded in this range' : `${data.avg_minutes_to_interest} minutes`}</strong>
              </p>
            </section>
          )}

          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <section className="rounded-xl border border-ink-100 p-5 shadow-xs" aria-labelledby="cancel-heading">
              <h2 id="cancel-heading" className="text-base font-semibold text-ink-900">
                Cancellations by who
              </h2>
              {data.cancellations.length === 0 ? (
                <p className="mt-3 text-sm text-ink-500">No cancellations in this range.</p>
              ) : (
                <ul className="mt-4 space-y-3">
                  {data.cancellations.map((c) => (
                    <BarRow key={c.who} label={WHO_LABELS[c.who] ?? c.who} value={n(c.n)} max={maxCancel} note={cancelTotal ? `${((n(c.n) / cancelTotal) * 100).toFixed(0)}%` : undefined} />
                  ))}
                </ul>
              )}
            </section>

            <section className="rounded-xl border border-ink-100 p-5 shadow-xs" aria-labelledby="type-heading">
              <h2 id="type-heading" className="text-base font-semibold text-ink-900">
                Volume by vendor type
              </h2>
              {data.volume_by_vendor_type.length === 0 ? (
                <p className="mt-3 text-sm text-ink-500">No assigned bookings in this range.</p>
              ) : (
                <ul className="mt-4 space-y-3">
                  {data.volume_by_vendor_type.map((t) => (
                    <BarRow key={t.vendor_type} label={t.vendor_type === 'fleet' ? 'Fleet vendors' : t.vendor_type === 'individual' ? 'Individual vendors' : t.vendor_type} value={n(t.bookings)} max={maxType} />
                  ))}
                </ul>
              )}
            </section>
          </div>

          <section className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs" aria-labelledby="comm-heading">
            <h2 id="comm-heading" className="text-base font-semibold text-ink-900">
              Commission by vendor
            </h2>
            {data.commission_by_vendor.length === 0 ? (
              <p className="mt-3 text-sm text-ink-500">No commission was charged in this range.</p>
            ) : (
              <div className="mt-3 overflow-x-auto">
                <table className="w-full min-w-[480px] text-sm">
                  <thead className="text-left text-xs font-medium uppercase tracking-wide text-ink-500">
                    <tr>
                      <th className="py-2 pr-4">Vendor</th>
                      <th className="py-2 pr-4 text-right">Bookings</th>
                      <th className="py-2 pr-4 text-right">Commission</th>
                      <th className="py-2">Share of top</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {data.commission_by_vendor.map((c) => (
                      <tr key={String(c.vendor_id)}>
                        <td className="py-2 pr-4 font-medium text-ink-900">{c.business_name}</td>
                        <td className="py-2 pr-4 text-right text-ink-700">{n(c.bookings)}</td>
                        <td className="py-2 pr-4 text-right font-semibold text-ink-900">{money(c.commission)}</td>
                        <td className="w-40 py-2">
                          <div className="h-2.5 overflow-hidden rounded bg-ink-100">
                            <div className="h-full rounded bg-success-500" style={{ width: maxCommission > 0 ? `${(n(c.commission) / maxCommission) * 100}%` : '0%' }} />
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </div>
      )}
    </div>
  );
}
