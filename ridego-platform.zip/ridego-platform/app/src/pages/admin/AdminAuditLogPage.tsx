import { useCallback, useEffect, useState } from 'react';
import { getAdminAuditLog, ApiError } from '../../lib/api';
import type { AdminAuditLogRow } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';

const ENTITY_OPTIONS = [
  ['booking', 'Booking'],
  ['vendor', 'Vendor'],
  ['payment', 'Payment'],
  ['setting', 'Setting'],
  ['promo', 'Promo'],
];

function fmtDate(s: string) {
  const d = new Date(s.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

/** Rebuild of admin/pages/audit.php — read-only, filtered/paginated audit trail. */
export function AdminAuditLogPage() {
  const [entity, setEntity] = useState('');
  const [actionFilter, setActionFilter] = useState('');
  const [page, setPage] = useState(1);

  const [rows, setRows] = useState<AdminAuditLogRow[] | null>(null);
  const [total, setTotal] = useState(0);
  const [perPage, setPerPage] = useState(40);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (e: string, a: string, p: number) => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminAuditLog({ entity: e || undefined, action_filter: a || undefined, page: p });
      setRows(res.rows);
      setTotal(res.total);
      setPerPage(res.per_page);
    } catch (err) {
      setError(
        err instanceof ApiError && err.code === 'forbidden'
          ? "You don't have permission to view the audit log."
          : err instanceof ApiError
          ? err.message
          : 'Could not load the audit log. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(entity, actionFilter, page);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entity, page]);

  function applyFilters() {
    setPage(1);
    load(entity, actionFilter, 1);
  }

  const totalPages = Math.max(1, Math.ceil(total / perPage));

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div>
        <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">🔍 Audit log</h1>
        <p className="text-sm text-ink-500">Every administrative action taken across the platform.</p>
      </div>

      <div className="mt-6 flex flex-wrap items-end gap-3">
        <div>
          <label htmlFor="audit-entity" className="block text-sm font-medium text-ink-700">
            Entity
          </label>
          <select
            id="audit-entity"
            value={entity}
            onChange={(e) => {
              setEntity(e.target.value);
              setPage(1);
            }}
            className="mt-1.5 rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          >
            <option value="">All entities</option>
            {ENTITY_OPTIONS.map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </select>
        </div>
        <div className="flex-1 min-w-[220px]">
          <label htmlFor="audit-action" className="block text-sm font-medium text-ink-700">
            Filter by action
          </label>
          <input
            id="audit-action"
            type="text"
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && applyFilters()}
            placeholder="e.g. wallet_topup"
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>
        <Button onClick={applyFilters}>Filter</Button>
        <span className="ml-auto text-sm text-ink-500">{total.toLocaleString('en-IN')} entries</span>
      </div>

      {loading && (
        <div className="mt-6" aria-busy="true" aria-label="Loading audit log">
          <Skeleton className="h-96 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={() => load(entity, actionFilter, page)} />
        </div>
      )}

      {!loading && !error && (
        <>
          <div className="mt-4 hidden overflow-x-auto rounded-xl border border-ink-100 lg:block">
            <table className="w-full text-sm">
              <thead className="bg-ink-50 text-left text-xs font-medium uppercase tracking-wide text-ink-500">
                <tr>
                  <th className="px-4 py-3">Date/Time</th>
                  <th className="px-4 py-3">Admin user</th>
                  <th className="px-4 py-3">Action</th>
                  <th className="px-4 py-3">Entity</th>
                  <th className="px-4 py-3">Entity ID</th>
                  <th className="px-4 py-3">IP</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-100">
                {rows && rows.length > 0 ? (
                  rows.map((r) => (
                    <tr key={r.id}>
                      <td className="whitespace-nowrap px-4 py-3 text-xs text-ink-600">{fmtDate(r.created_at)}</td>
                      <td className="px-4 py-3 text-ink-800">{r.user_login}</td>
                      <td className="px-4 py-3">
                        <span className="rounded-full bg-violet-50 px-2.5 py-0.5 text-xs font-semibold text-violet-700">{r.action}</span>
                      </td>
                      <td className="px-4 py-3 text-ink-700 capitalize">{r.entity}</td>
                      <td className="px-4 py-3 font-mono text-xs text-ink-500">{r.entity_id ?? ''}</td>
                      <td className="px-4 py-3 text-xs text-ink-400">{r.ip_address}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6}>
                      <EmptyState title="No audit log entries yet" />
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {rows && rows.length > 0 ? (
            <div className="mt-4 space-y-3 lg:hidden">
              {rows.map((r) => (
                <div key={r.id} className="rounded-xl border border-ink-100 bg-white p-4">
                  <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-1">
                    <span className="rounded-full bg-violet-50 px-2.5 py-0.5 text-xs font-semibold text-violet-700">{r.action}</span>
                    <span className="text-xs text-ink-500">{fmtDate(r.created_at)}</span>
                  </div>
                  <p className="mt-2 text-sm font-medium text-ink-900">{r.user_login}</p>
                  <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
                    <span className="text-ink-400">Entity</span>
                    <span className="text-right capitalize text-ink-700">{r.entity}</span>
                    <span className="text-ink-400">Entity ID</span>
                    <span className="text-right font-mono text-ink-500">{r.entity_id ?? '—'}</span>
                    <span className="text-ink-400">IP</span>
                    <span className="text-right text-ink-500">{r.ip_address}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-4 lg:hidden">
              <EmptyState title="No audit log entries yet" />
            </div>
          )}

          <div className="mt-4 flex items-center justify-between">
            <p className="text-xs text-ink-400">
              Page {page} of {totalPages}
            </p>
            <div className="flex gap-2">
              <Button variant="secondary" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                Previous
              </Button>
              <Button variant="secondary" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
