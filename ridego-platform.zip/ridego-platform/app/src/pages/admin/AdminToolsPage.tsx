import { useCallback, useEffect, useState } from 'react';
import { getAdminTools, runAdminToolAction, ApiError } from '../../lib/api';
import type { AdminToolsResponse, AdminToolActionResponse } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';

interface ToolDef {
  action: string;
  label: string;
  description: string;
  destructive: boolean;
  /** Confirm dialog copy for actions that need a confirmation step. */
  confirm?: string;
}

const SETUP_TOOLS: ToolDef[] = [
  {
    action: 'create_pages',
    label: 'Create All Frontend Pages',
    description: 'Creates booking, vendor portal, my trips, cities, etc.',
    destructive: false,
  },
  {
    action: 'seed_vehicles',
    label: 'Seed Vehicles & Cities',
    description: 'Adds demo vehicles (Sedan, Innova, etc.) and major cities.',
    destructive: false,
  },
  {
    action: 'flush_rewrite',
    label: 'Flush Rewrite Rules',
    description: 'Fix 404 errors on frontend pages.',
    destructive: false,
  },
  {
    action: 'clear_cache',
    label: 'Clear Route Cache',
    description: 'Remove cached route distances older than 30 days.',
    destructive: false,
  },
  {
    action: 'recreate_tables',
    label: 'Recreate/Update DB Tables',
    description: 'Runs dbDelta on all tables — destructive on a live site if a table definition changed.',
    destructive: true,
  },
];

const DEMO_SEED_TOOL: ToolDef = {
  action: 'reseed_data',
  label: 'Seed Demo Data',
  description: 'Adds sample vendors, bookings, leads, promo codes, reviews.',
  destructive: true,
  confirm: 'This will add demo data. Proceed?',
};

const DEMO_RESET_TOOL: ToolDef = {
  action: 'delete_demo',
  label: 'Reset Demo Flag',
  description: 'Allows re-seeding demo data again.',
  destructive: false,
};

const DISABLED_HINT = 'Disabled — enable WP_DEBUG or "Allow Destructive Tools" in Settings > Advanced.';

const pageStatusStyles: Record<string, string> = {
  live: 'text-success-600',
  missing: 'text-danger-600',
};

function humanizeStatus(status: string): string {
  if (status === 'live') return '✓ Live';
  if (status === 'missing') return '✗ Not Created';
  return status.charAt(0).toUpperCase() + status.slice(1);
}

export function AdminToolsPage() {
  const [data, setData] = useState<AdminToolsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Feedback banner from the most recently run action.
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [runningAction, setRunningAction] = useState<string | null>(null);

  // The demo-seed action needs an extra confirmation step.
  const [confirmSeed, setConfirmSeed] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [seedError, setSeedError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminTools();
      setData(res);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load tools. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function runAction(action: string): Promise<AdminToolActionResponse | null> {
    setRunningAction(action);
    setActionMessage(null);
    setActionError(null);
    try {
      const res = await runAdminToolAction(action);
      setActionMessage(res.message);
      await load();
      return res;
    } catch (err) {
      setActionError(err instanceof ApiError ? err.message : 'Could not run this action.');
      return null;
    } finally {
      setRunningAction(null);
    }
  }

  async function confirmSeedDemoData() {
    setSeeding(true);
    setSeedError(null);
    try {
      const res = await runAdminToolAction(DEMO_SEED_TOOL.action);
      setActionMessage(res.message);
      setConfirmSeed(false);
      await load();
    } catch (err) {
      setSeedError(err instanceof ApiError ? err.message : 'Could not seed demo data.');
    } finally {
      setSeeding(false);
    }
  }

  const destructiveAllowed = data?.destructive_allowed ?? false;

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Tools & Database</h1>
      <p className="mt-1 text-sm text-ink-500">Setup, maintenance and diagnostic tools for this installation.</p>

      {actionMessage && !error && (
        <div role="status" className="mt-6 rounded-lg border border-success-500/30 bg-success-50 px-4 py-3 text-sm text-success-700">
          {actionMessage}
        </div>
      )}
      {actionError && (
        <div className="mt-6">
          <ErrorBanner message={actionError} />
        </div>
      )}

      {loading && (
        <div className="mt-6 grid gap-6 lg:grid-cols-2" aria-busy="true" aria-label="Loading tools">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-48 w-full rounded-xl" />
          ))}
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {!loading && !error && data && (
        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          <div className="flex flex-col gap-6">
            {/* Setup & Maintenance */}
            <div className="rounded-xl border border-ink-100 p-5 shadow-xs sm:p-6">
              <h2 className="text-base font-semibold text-ink-900">⚙️ Setup & Maintenance</h2>
              <div className="mt-4 flex flex-col gap-3">
                {SETUP_TOOLS.map((tool) => {
                  const disabled = tool.destructive && !destructiveAllowed;
                  return (
                    <div
                      key={tool.action}
                      className="flex items-center gap-3 rounded-lg border border-ink-100 bg-ink-50/40 p-3"
                    >
                      <div className="flex-1">
                        <div className="text-sm font-semibold text-ink-900">{tool.label}</div>
                        <div className="mt-0.5 text-xs text-ink-500">
                          {tool.description}
                          {disabled && <strong className="ml-1 text-danger-600">{DISABLED_HINT}</strong>}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant={tool.destructive ? 'danger' : 'secondary'}
                        disabled={disabled}
                        loading={runningAction === tool.action}
                        onClick={() => runAction(tool.action)}
                      >
                        {tool.label}
                      </Button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Demo & Testing Data */}
            <div className="rounded-xl border border-warning-500/30 bg-warning-50/30 p-5 shadow-xs sm:p-6">
              <h2 className="text-base font-semibold text-warning-700">🎭 Demo & Testing Data</h2>
              <div className="mt-3 rounded-lg border border-warning-500/30 bg-warning-50 px-3 py-2 text-sm text-warning-700">
                ⚠️ These actions insert demo/test data. Only use on development/staging sites, not on a live
                production site with real customers.
              </div>
              <div className="mt-4 flex flex-col gap-3">
                <div className="flex items-center gap-3 rounded-lg border border-warning-500/40 bg-warning-50 p-3">
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-ink-900">{DEMO_SEED_TOOL.label}</div>
                    <div className="mt-0.5 text-xs text-ink-600">
                      {DEMO_SEED_TOOL.description}
                      {!destructiveAllowed && <strong className="ml-1 text-danger-600">{DISABLED_HINT}</strong>}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="danger"
                    disabled={!destructiveAllowed}
                    onClick={() => {
                      setConfirmSeed(true);
                      setSeedError(null);
                    }}
                  >
                    Seed Demo Data
                  </Button>
                </div>
                <div className="flex items-center gap-3 rounded-lg border border-ink-100 bg-white p-3">
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-ink-900">{DEMO_RESET_TOOL.label}</div>
                    <div className="mt-0.5 text-xs text-ink-500">{DEMO_RESET_TOOL.description}</div>
                  </div>
                  <Button
                    size="sm"
                    variant="secondary"
                    loading={runningAction === DEMO_RESET_TOOL.action}
                    onClick={() => runAction(DEMO_RESET_TOOL.action)}
                  >
                    Reset Flag
                  </Button>
                </div>
              </div>
            </div>

            {/* Frontend Pages Status */}
            <div className="rounded-xl border border-ink-100 p-5 shadow-xs sm:p-6">
              <h2 className="text-base font-semibold text-ink-900">📄 Frontend Pages Status</h2>
              <div className="mt-3 divide-y divide-ink-100">
                {data.pages.map((pg) => (
                  <div key={pg.key} className="flex items-center justify-between py-2 text-sm">
                    <span className="text-ink-700">{pg.label}</span>
                    {pg.status === 'live' && pg.url ? (
                      <a
                        href={pg.url}
                        target="_blank"
                        rel="noreferrer"
                        className={`font-medium underline-offset-2 hover:underline ${pageStatusStyles.live}`}
                      >
                        ✓ Live
                      </a>
                    ) : (
                      <span className={`font-medium ${pageStatusStyles[pg.status] ?? 'text-ink-500'}`}>
                        {humanizeStatus(pg.status)}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-6">
            {/* Database Tables */}
            <div className="rounded-xl border border-ink-100 p-5 shadow-xs sm:p-6">
              <h2 className="text-base font-semibold text-ink-900">🗄️ Database Tables</h2>
              <div className="mt-3 divide-y divide-ink-100">
                {data.tables.map((t) => (
                  <div key={t.name} className="flex items-center justify-between py-2 text-sm">
                    <span className="font-mono text-xs text-ink-600">{t.table}</span>
                    {t.exists ? (
                      <span className="flex items-center gap-2">
                        <span className="text-xs text-ink-400">{t.count.toLocaleString('en-IN')} rows</span>
                        <span className="font-medium text-success-600">✓ OK</span>
                      </span>
                    ) : (
                      <span className="font-medium text-danger-600">✗ Missing</span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* System Information */}
            <div className="rounded-xl border border-ink-100 p-5 shadow-xs sm:p-6">
              <h2 className="text-base font-semibold text-ink-900">🖥️ System Information</h2>
              <div className="mt-3 divide-y divide-ink-100">
                {data.system.map((si) => (
                  <div key={si.label} className="flex items-center justify-between py-2 text-sm">
                    <span className="text-ink-500">{si.label}</span>
                    <span className="font-mono text-xs text-ink-900">{si.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={confirmSeed}
        title="Seed demo data?"
        description={DEMO_SEED_TOOL.confirm}
        confirmLabel="Seed Demo Data"
        confirmVariant="danger"
        loading={seeding}
        onConfirm={confirmSeedDemoData}
        onCancel={() => {
          if (seeding) return;
          setConfirmSeed(false);
          setSeedError(null);
        }}
      >
        {seedError && (
          <div role="alert" className="mb-3 rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {seedError}
          </div>
        )}
      </ConfirmDialog>
    </div>
  );
}
