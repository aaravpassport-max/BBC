import { NumberField } from '../../components/ui/NumberField';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  createAdminCity,
  getAdminCities,
  toggleAdminCity,
  updateAdminCity,
  uploadCityImage,
  ApiError,
} from '../../lib/api';
import type { AdminCityInput, AdminCityRow } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { Pagination, paginate } from '../../components/ui/Pagination';

const PAGE_SIZE = 20;
type StatusFilter = 'all' | 'active' | 'inactive';
type RoleFilter = 'all' | 'origin' | 'destination' | 'popular';

const EMPTY_FORM: AdminCityInput = {
  name: '',
  state: '',
  country: 'India',
  lat: '',
  lng: '',
  airport_name: '',
  airport_code: '',
  is_popular: false,
  sort_order: 0,
  is_origin_enabled: true,
  is_destination_enabled: true,
  image_url: '',
};

export function AdminCitiesPage() {
  const [rows, setRows] = useState<AdminCityRow[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<AdminCityRow | null>(null);
  const [form, setForm] = useState<AdminCityInput>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const [formIsActive, setFormIsActive] = useState(true);

  const [toggleTarget, setToggleTarget] = useState<AdminCityRow | null>(null);
  const [toggling, setToggling] = useState(false);
  const [toggleError, setToggleError] = useState<string | null>(null);

  // Root-cause fix: this list has always fetched and rendered every city
  // (77+ in real data) with no way to find one — see Pagination.tsx's doc
  // comment. Search/status/role are pure client-side filters over the
  // already-loaded rows (no extra request), and the page resets to 1
  // whenever a filter narrows the result set so the user is never left
  // staring at an empty "page 4 of 1".
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [roleFilter, setRoleFilter] = useState<RoleFilter>('all');
  const [page, setPage] = useState(1);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminCities();
      setRows(res.rows);
    } catch (err) {
      if (err instanceof ApiError && err.code === 'forbidden') {
        setError("You don't have permission to manage cities.");
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not load cities. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filteredRows = useMemo(() => {
    if (!rows) return [];
    const q = search.trim().toLowerCase();
    return rows.filter((c) => {
      if (q && !`${c.name} ${c.state} ${c.country} ${c.slug}`.toLowerCase().includes(q)) return false;
      if (statusFilter === 'active' && !c.is_active) return false;
      if (statusFilter === 'inactive' && c.is_active) return false;
      if (roleFilter === 'origin' && !c.is_origin_enabled) return false;
      if (roleFilter === 'destination' && !c.is_destination_enabled) return false;
      if (roleFilter === 'popular' && !c.is_popular) return false;
      return true;
    });
  }, [rows, search, statusFilter, roleFilter]);

  useEffect(() => { setPage(1); }, [search, statusFilter, roleFilter]);

  const { pageItems: visibleRows, pageCount, page: currentPage } = paginate(filteredRows, page, PAGE_SIZE);

  function openAdd() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setFormIsActive(true);
    setFormError(null);
    setUploadError(null);
    setShowForm(true);
  }

  function openEdit(city: AdminCityRow) {
    setEditing(city);
    setForm({
      name: city.name,
      slug: city.slug,
      state: city.state,
      country: city.country,
      lat: city.lat ?? '',
      lng: city.lng ?? '',
      airport_name: city.airport_name,
      airport_code: city.airport_code,
      is_popular: city.is_popular,
      sort_order: city.sort_order,
      is_origin_enabled: city.is_origin_enabled,
      is_destination_enabled: city.is_destination_enabled,
      image_url: city.image_url,
    });
    setFormIsActive(city.is_active);
    setFormError(null);
    setUploadError(null);
    setShowForm(true);
  }

  // TRACE: a photo file chosen in the Cities form → uploaded via uploadCityImage()
  //        → on success the returned URL is put straight into form.image_url (the
  //        Save button then persists it on create/update, same two-step flow as
  //        the branding image fields) → void. Edge case: upload failure shows the
  //        server's reason and leaves whatever image_url the form already had.
  async function handleImageChosen(file: File | undefined) {
    if (!file) return;
    setUploadingImage(true);
    setUploadError(null);
    try {
      const res = await uploadCityImage(file);
      setForm((f) => ({ ...f, image_url: res.url }));
    } catch (err) {
      setUploadError(err instanceof ApiError ? err.message : 'Could not upload the image. Please try again.');
    } finally {
      setUploadingImage(false);
    }
  }

  async function submitForm() {
    if (!form.name?.trim()) {
      setFormError('Please provide a city name.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      const payload = { ...form, is_active: formIsActive };
      if (editing) {
        await updateAdminCity(editing.id, payload);
        setActionMessage(`"${form.name}" updated.`);
      } else {
        await createAdminCity(payload);
        setActionMessage(`"${form.name}" created.`);
      }
      setShowForm(false);
      await load();
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : 'Could not save this city.');
    } finally {
      setSaving(false);
    }
  }

  async function confirmToggle() {
    if (!toggleTarget) return;
    setToggling(true);
    setToggleError(null);
    try {
      const res = await toggleAdminCity(toggleTarget.id);
      setActionMessage(res.message);
      setToggleTarget(null);
      await load();
    } catch (err) {
      setToggleError(err instanceof ApiError ? err.message : 'Could not change city status.');
    } finally {
      setToggling(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Cities</h1>
          <p className="text-sm text-ink-500">Manage the cities and service areas the platform operates in.</p>
          <div className="mt-2 flex gap-4 text-sm">
            <Link to="/admin/routes" className="font-medium text-brand-700 hover:text-brand-800">
              Manage routes →
            </Link>
            <Link to="/admin/zones" className="font-medium text-brand-700 hover:text-brand-800">
              Manage zones →
            </Link>
          </div>
        </div>
        <Button onClick={openAdd}>Add city</Button>
      </div>

      {actionMessage && !loading && (
        <div role="status" className="mt-4 rounded-lg border border-success-500/30 bg-success-50 px-3.5 py-2.5 text-sm text-success-700">
          {actionMessage}
        </div>
      )}

      {!loading && !error && rows && rows.length > 0 && (
        <div className="mt-6 flex flex-wrap gap-3">
          <div className="w-full flex-1 sm:min-w-[16rem]">
            <label htmlFor="city-search" className="sr-only">
              Search cities
            </label>
            <input
              id="city-search"
              type="text"
              placeholder="Search by name, state or country"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div className="w-full sm:w-48">
            <label htmlFor="city-status-filter" className="sr-only">
              Status
            </label>
            <select
              id="city-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as StatusFilter)}
              className="w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            >
              <option value="all">All statuses</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
          <div className="w-full sm:w-48">
            <label htmlFor="city-role-filter" className="sr-only">
              Role
            </label>
            <select
              id="city-role-filter"
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value as RoleFilter)}
              className="w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            >
              <option value="all">Origin or destination</option>
              <option value="origin">Origin enabled</option>
              <option value="destination">Destination enabled</option>
              <option value="popular">Popular only</option>
            </select>
          </div>
        </div>
      )}

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading cities">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full rounded-xl" />
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={load} />}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState title="No cities yet" description="Add your first city to start accepting bookings there." />
        )}

        {!loading && !error && rows && rows.length > 0 && filteredRows.length === 0 && (
          <EmptyState title="No cities match your filters" description="Try a different search term or clear the filters above." />
        )}

        {!loading && !error && filteredRows.length > 0 && (
          <ul className="space-y-3">
            {visibleRows.map((c) => (
              <li key={c.id} className="rounded-xl border border-ink-100 p-4 shadow-xs sm:p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0 max-w-full break-words">
                    <p className="font-semibold text-ink-900">
                      {c.name}
                      {c.is_popular && (
                        <span className="ml-2 rounded-full bg-brand-50 px-2 py-0.5 text-xs font-semibold text-brand-700">
                          Popular
                        </span>
                      )}
                      {!c.is_active && (
                        <span className="ml-2 rounded-full bg-ink-100 px-2 py-0.5 text-xs font-semibold text-ink-500">
                          Inactive
                        </span>
                      )}
                      {c.is_origin_enabled && (
                        <span className="ml-2 rounded-full bg-ink-50 px-2 py-0.5 text-xs font-semibold text-ink-600">
                          Origin
                        </span>
                      )}
                      {c.is_destination_enabled && (
                        <span className="ml-2 rounded-full bg-ink-50 px-2 py-0.5 text-xs font-semibold text-ink-600">
                          Destination
                        </span>
                      )}
                    </p>
                    <p className="mt-0.5 text-sm text-ink-500">
                      {c.state}, {c.country} &middot; slug: {c.slug}
                    </p>
                    {c.airport_code && (
                      <p className="mt-0.5 text-xs text-ink-400">
                        Airport: {c.airport_name} ({c.airport_code})
                      </p>
                    )}
                    <p className="mt-1 text-xs text-ink-400">
                      {c.route_count} route{c.route_count === 1 ? '' : 's'} &middot; {c.zone_count} zone
                      {c.zone_count === 1 ? '' : 's'} referencing this city
                    </p>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <Button variant="secondary" size="sm" onClick={() => openEdit(c)}>
                      Edit
                    </Button>
                    <Button
                      variant={c.is_active ? 'danger' : 'secondary'}
                      size="sm"
                      onClick={() => {
                        setToggleTarget(c);
                        setToggleError(null);
                      }}
                      aria-label={`${c.is_active ? 'Deactivate' : 'Activate'} ${c.name}`}
                    >
                      {c.is_active ? 'Deactivate' : 'Activate'}
                    </Button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
        {!loading && !error && filteredRows.length > 0 && (
          <Pagination page={currentPage} pageCount={pageCount} totalItems={filteredRows.length} pageSize={PAGE_SIZE} onPageChange={setPage} />
        )}
      </div>

      <ConfirmDialog
        open={showForm}
        title={editing ? `Edit ${editing.name}` : 'Add city'}
        confirmLabel={editing ? 'Save changes' : 'Create city'}
        confirmVariant="primary"
        loading={saving}
        onConfirm={submitForm}
        onCancel={() => {
          if (saving) return;
          setShowForm(false);
        }}
      >
        <div className="space-y-3">
          {formError && (
            <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
              {formError}
            </div>
          )}
          <div>
            <label htmlFor="city-name" className="block text-sm font-medium text-ink-700">
              City name
            </label>
            <input
              id="city-name"
              type="text"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              required
            />
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="city-state" className="block text-sm font-medium text-ink-700">
                State
              </label>
              <input
                id="city-state"
                type="text"
                value={form.state}
                onChange={(e) => setForm((f) => ({ ...f, state: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="city-country" className="block text-sm font-medium text-ink-700">
                Country
              </label>
              <input
                id="city-country"
                type="text"
                value={form.country}
                onChange={(e) => setForm((f) => ({ ...f, country: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="city-lat" className="block text-sm font-medium text-ink-700">
                Latitude
              </label>
              <input
                id="city-lat"
                type="text"
                inputMode="decimal"
                value={form.lat}
                onChange={(e) => setForm((f) => ({ ...f, lat: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="city-lng" className="block text-sm font-medium text-ink-700">
                Longitude
              </label>
              <input
                id="city-lng"
                type="text"
                inputMode="decimal"
                value={form.lng}
                onChange={(e) => setForm((f) => ({ ...f, lng: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="city-airport-name" className="block text-sm font-medium text-ink-700">
                Airport name
              </label>
              <input
                id="city-airport-name"
                type="text"
                value={form.airport_name}
                onChange={(e) => setForm((f) => ({ ...f, airport_name: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="city-airport-code" className="block text-sm font-medium text-ink-700">
                Airport code
              </label>
              <input
                id="city-airport-code"
                type="text"
                value={form.airport_code}
                onChange={(e) => setForm((f) => ({ ...f, airport_code: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-ink-700">Photo (Popular cities card)</label>
            <p className="mt-0.5 text-xs text-ink-500">
              Shown on the home page &ldquo;Popular cities&rdquo; card for this city. Leave blank to show a plain
              labelled card instead of a photo.
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-3">
              {form.image_url ? (
                <img
                  src={form.image_url}
                  alt={`${form.name || 'City'} preview`}
                  className="h-16 w-28 rounded-lg border border-ink-100 bg-white object-cover"
                />
              ) : (
                <span className="text-xs text-ink-400">No photo set</span>
              )}
              <label className="cursor-pointer rounded-lg border border-ink-200 px-3 py-1.5 text-sm font-medium text-ink-800 hover:bg-ink-50 focus-within:outline focus-within:outline-2 focus-within:outline-brand-600">
                {uploadingImage ? 'Uploading…' : form.image_url ? 'Replace photo' : 'Upload photo'}
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  className="sr-only"
                  disabled={uploadingImage}
                  aria-label="Upload city photo"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    e.target.value = '';
                    void handleImageChosen(file);
                  }}
                />
              </label>
              {form.image_url && (
                <button
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, image_url: '' }))}
                  className="text-sm font-medium text-ink-500 hover:text-danger-600"
                >
                  Remove
                </button>
              )}
            </div>
            {uploadError && <p className="mt-1.5 text-xs text-danger-600">{uploadError}</p>}
          </div>
          <div>
            <label htmlFor="city-sort-order" className="block text-sm font-medium text-ink-700">
              Sort order
            </label>
            <NumberField
              id="city-sort-order"
              value={form.sort_order ?? 0}
              integer
              onValue={(n) => setForm((f) => ({ ...f, sort_order: n }))}
              className="mt-1.5 w-32 rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={!!form.is_popular}
              onChange={(e) => setForm((f) => ({ ...f, is_popular: e.target.checked }))}
              className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
            />
            Popular city (featured on home)
          </label>
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={formIsActive}
              onChange={(e) => setFormIsActive(e.target.checked)}
              className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
            />
            Active (visible in booking)
          </label>
          <div className="rounded-lg border border-ink-100 bg-ink-50/50 p-3">
            <p className="text-xs font-medium text-ink-500">
              Where this city can be picked from booking &mdash; a city can be either, both, or neither role
              (neither means it stays in the list for reference but never shows up as a pickup or drop
              choice while still active).
            </p>
            <label className="mt-2 flex items-center gap-2 text-sm text-ink-700">
              <input
                type="checkbox"
                checked={!!form.is_origin_enabled}
                onChange={(e) => setForm((f) => ({ ...f, is_origin_enabled: e.target.checked }))}
                className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
              />
              Origin &mdash; can be selected as a pickup city
            </label>
            <label className="mt-1.5 flex items-center gap-2 text-sm text-ink-700">
              <input
                type="checkbox"
                checked={!!form.is_destination_enabled}
                onChange={(e) => setForm((f) => ({ ...f, is_destination_enabled: e.target.checked }))}
                className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
              />
              Destination &mdash; can be selected as a drop city
            </label>
          </div>
        </div>
      </ConfirmDialog>

      <ConfirmDialog
        open={!!toggleTarget}
        title={toggleTarget?.is_active ? `Deactivate ${toggleTarget?.name}?` : `Activate ${toggleTarget?.name}?`}
        description={
          toggleTarget?.is_active
            ? `This hides ${toggleTarget?.name} from customer search and booking. Its ${toggleTarget?.route_count ?? 0} route(s) and ${toggleTarget?.zone_count ?? 0} zone(s) are not automatically deactivated.`
            : `This makes ${toggleTarget?.name} available again for customer search and booking.`
        }
        confirmLabel={toggleTarget?.is_active ? 'Deactivate' : 'Activate'}
        confirmVariant={toggleTarget?.is_active ? 'danger' : 'primary'}
        loading={toggling}
        onConfirm={confirmToggle}
        onCancel={() => {
          if (toggling) return;
          setToggleTarget(null);
          setToggleError(null);
        }}
      >
        {toggleError && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {toggleError}
          </div>
        )}
      </ConfirmDialog>
    </div>
  );
}
