import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ApiError, getAdminVendors } from '../../lib/api';
import { getLedger, settleLedgerBooking, type LedgerResponse, type LedgerRow, type LedgerStatus } from '../../lib/api-admin-finance';
import type { AdminVendorRow } from '../../types/api';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { hasAdminCap } from '../../lib/permissions';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { brand } from '../../lib/brand';

const inputCls =
  'mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500/40';

const ENTRY_LABELS: Record<string, string> = {
  commission: 'Commission',
  advance_held: 'Advance held (earlier bookings)',
  lead_fee_retained: 'Lead fee set off from customer advance',
  lead_fee: 'Lead fee payable by vendor to ' + brand().name,
  cancellation_compensation: 'Cancellation compensation to vendor',
  commission_reversal: 'Commission reversal',
};

interface SettleTarget {
  bookingId: number;
  bookingNumber: string;
  vendorName: string;
  net: number;
}

// TRACE: any amount display → rupees with Indian grouping, sign kept → "₹1,234.5" or "-₹20".
//        Preconditions: number or numeric string → postconditions: pure → edge cases: NaN/null render as ₹0.
function money(v: number | string | null | undefined): string {
  const n = Number(v);
  const safe = Number.isFinite(n) ? n : 0;
  return `${safe < 0 ? '-' : ''}₹${Math.abs(safe).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

// TRACE: ledger entry_type key → readable label → string.
//        Preconditions: none → postconditions: pure → edge cases: unknown types are title-cased from snake_case.
function entryLabel(t: string): string {
  if (ENTRY_LABELS[t]) return ENTRY_LABELS[t];
  const spaced = t.replace(/_/g, ' ');
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

// TRACE: MySQL datetime → short local date-time → string.
//        Preconditions: none → postconditions: pure → edge cases: empty gives an em dash, unparseable is returned as-is.
function fmtDate(s: string | null | undefined): string {
  if (!s) return '—';
  const d = new Date(s.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return s;
  return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

// TRACE: ledger row → signed amount (credit positive, debit negative) → number. Preconditions: row → postconditions: pure →
//        edge cases: non-numeric amount counts as 0.
function signed(r: LedgerRow): number {
  const a = Number(r.amount) || 0;
  return r.direction === 'credit' ? a : -a;
}

// TRACE: summary tile props → one labelled figure → tile markup.
//        Preconditions: label and value strings → postconditions: pure render → edge cases: optional hint line.
function Tile({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
      <p className="text-xs font-medium uppercase tracking-wide text-ink-500">{label}</p>
      <p className="mt-2 text-xl font-bold text-ink-900">{value}</p>
      {hint && <p className="mt-1 text-xs text-ink-500">{hint}</p>}
    </div>
  );
}

// TRACE: route /app/admin/ledger → filters (vendor, status, date range) → GET ledger → summary tiles + paginated table;
//        Settle (cap ridego_settle_ledger only) → ConfirmDialog → POST settle → toast + re-fetch.
//        Preconditions: cap ridego_view_ledger → postconditions: table always reflects the server after a mutation →
//        edge cases: loading skeleton, error banner with retry, empty state, stale responses dropped, reversed date range
//        blocked, wallet-shortfall error shown verbatim in the dialog and toast, double submit blocked.
export function AdminLedgerPage() {
  const { user } = useAuth();
  const toast = useToast();
  const canSettle = hasAdminCap(user, 'ridego_settle_ledger');

  const [vendorId, setVendorId] = useState('');
  const [status, setStatus] = useState<LedgerStatus | ''>('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [page, setPage] = useState(1);

  const [data, setData] = useState<LedgerResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const seq = useRef(0);

  const [vendors, setVendors] = useState<AdminVendorRow[]>([]);
  const [vendorsError, setVendorsError] = useState<string | null>(null);

  const [target, setTarget] = useState<SettleTarget | null>(null);
  const [settling, setSettling] = useState(false);
  const [settleError, setSettleError] = useState<string | null>(null);

  const rangeInvalid = from !== '' && to !== '' && from > to;

  // TRACE: filter/page change or retry → GET ledger with the current filters → stores the response.
  //        Preconditions: date range not reversed → postconditions: only the latest request writes state →
  //        edge cases: stale response dropped, ApiError message shown, loading cleared in finally.
  const load = useCallback(async () => {
    if (rangeInvalid) return;
    const id = ++seq.current;
    setLoading(true);
    setError(null);
    try {
      const res = await getLedger({ vendor_id: vendorId ? Number(vendorId) : undefined, status, page, from, to });
      if (id !== seq.current) return;
      setData(res);
    } catch (err) {
      if (id !== seq.current) return;
      setError(err instanceof ApiError ? err.message : 'Could not load the ledger. Please try again.');
    } finally {
      if (id === seq.current) setLoading(false);
    }
  }, [vendorId, status, page, from, to, rangeInvalid]);

  // TRACE: filters change → re-runs load; unmount → invalidates in-flight requests.
  //        Preconditions: none → postconditions: no state writes after unmount → edge cases: none.
  useEffect(() => {
    void load();
    return () => {
      seq.current += 1;
    };
  }, [load]);

  // TRACE: mount → loads the vendor filter options from the admin vendor list.
  //        Preconditions: none → postconditions: options filled or a non-blocking note shown →
  //        edge cases: failure leaves the filter empty with a message, unmount ignores the result.
  useEffect(() => {
    let live = true;
    getAdminVendors()
      .then((res) => {
        if (live) setVendors(res.rows);
      })
      .catch((err: unknown) => {
        if (live) setVendorsError(err instanceof ApiError ? err.message : 'Could not load the vendor filter.');
      });
    return () => {
      live = false;
    };
  }, []);

  // TRACE: any filter control change → applies the value and returns to page 1.
  //        Preconditions: none → postconditions: page 1 → edge cases: none.
  function applyFilter(setter: (v: string) => void, value: string) {
    setter(value);
    setPage(1);
  }

  // TRACE: Settle click → computes the pending net of that booking from the rows shown and opens the confirm dialog.
  //        Preconditions: row is pending with a booking number → postconditions: dialog names the booking and net effect →
  //        edge cases: booking rows split across pages (dialog states it counts the rows shown).
  function openSettle(row: LedgerRow) {
    const rows = (data?.rows ?? []).filter((r) => String(r.booking_id) === String(row.booking_id) && r.status === 'pending');
    setSettleError(null);
    setTarget({
      bookingId: Number(row.booking_id),
      bookingNumber: row.booking_number ?? `#${row.booking_id}`,
      vendorName: row.business_name ?? 'the vendor',
      net: rows.reduce((sum, r) => sum + signed(r), 0),
    });
  }

  // TRACE: dialog cancel/Escape → closes the settle dialog unless a settle is in flight.
  //        Preconditions: none → postconditions: target cleared → edge cases: ignored while settling.
  const closeSettle = useCallback(() => {
    if (!settling) setTarget(null);
  }, [settling]);

  // TRACE: dialog confirm → POST settle for the booking → toast, close, re-fetch ledger.
  //        Preconditions: target set, not already settling → postconditions: pending rows settled or nothing changed →
  //        edge cases: wallet shortfall / nothing pending shown verbatim and dialog kept open, double submit blocked.
  async function confirmSettle() {
    if (!target || settling) return;
    setSettling(true);
    setSettleError(null);
    try {
      await settleLedgerBooking(target.bookingId);
      toast.show(`Booking ${target.bookingNumber} settled.`, 'success');
      setTarget(null);
      await load();
    } catch (err) {
      const msg = err instanceof ApiError ? err.message : 'Could not settle this booking.';
      setSettleError(msg);
      toast.show(msg, 'error');
    } finally {
      setSettling(false);
    }
  }

  const firstPendingIds = useMemo(() => {
    const seen = new Set<string>();
    const ids = new Set<string>();
    for (const r of data?.rows ?? []) {
      if (r.status === 'pending' && !seen.has(String(r.booking_id))) {
        seen.add(String(r.booking_id));
        ids.add(String(r.id));
      }
    }
    return ids;
  }, [data]);

  const totalPages = data ? Math.max(1, Math.ceil(data.total / (data.per_page || 30))) : 1;
  const scope = vendorId ? 'Selected vendor' : 'All vendors';

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Commission ledger</h1>
      <p className="text-sm text-ink-500">Commission, advances held and reversals per booking, with settlement.</p>

      <form className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4" onSubmit={(e) => e.preventDefault()} aria-label="Ledger filters">
        <div>
          <label htmlFor="lg-vendor" className="block text-sm font-medium text-ink-700">
            Vendor
          </label>
          <select id="lg-vendor" value={vendorId} onChange={(e) => applyFilter(setVendorId, e.target.value)} className={inputCls}>
            <option value="">All vendors</option>
            {vendors.map((v) => (
              <option key={v.id} value={v.id}>
                {v.business_name}
              </option>
            ))}
          </select>
          {vendorsError && <p className="mt-1 text-xs text-danger-600">{vendorsError}</p>}
        </div>
        <div>
          <label htmlFor="lg-status" className="block text-sm font-medium text-ink-700">
            Status
          </label>
          <select id="lg-status" value={status} onChange={(e) => applyFilter((v) => setStatus(v as LedgerStatus | ''), e.target.value)} className={inputCls}>
            <option value="">All statuses</option>
            <option value="pending">Pending</option>
            <option value="settled">Settled</option>
          </select>
        </div>
        <div>
          <label htmlFor="lg-from" className="block text-sm font-medium text-ink-700">
            Platform net from
          </label>
          <input id="lg-from" type="date" value={from} onChange={(e) => applyFilter(setFrom, e.target.value)} className={inputCls} />
        </div>
        <div>
          <label htmlFor="lg-to" className="block text-sm font-medium text-ink-700">
            Platform net to
          </label>
          <input id="lg-to" type="date" value={to} onChange={(e) => applyFilter(setTo, e.target.value)} className={inputCls} />
        </div>
      </form>
      <p className="mt-2 text-xs text-ink-500">The date range applies to the platform net tiles only; the table lists all entries for the chosen vendor and status.</p>
      {rangeInvalid && (
        <p role="alert" className="mt-2 text-sm text-danger-600">
          The start date must be on or before the end date.
        </p>
      )}

      {loading && !data && (
        <div className="mt-6 space-y-4" aria-busy="true" aria-label="Loading ledger">
          <div className="grid gap-4 sm:grid-cols-3">
            {Array.from({ length: 6 }, (_, n) => `sk${n}`).map((k) => (
              <Skeleton key={k} className="h-20 w-full rounded-xl" />
            ))}
          </div>
          <Skeleton className="h-64 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {data && !error && (
        <div aria-busy={loading}>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Tile label="Commission charged" value={money(data.summary.commission)} hint={scope} />
            <Tile label="Lead fees set off from advance" value={money(data.summary.fee_retained)} hint={scope} />
            <Tile label="Lead fees outstanding" value={money(data.summary.fee_outstanding ?? 0)} hint={scope} />
            <Tile label="Cancellation compensation" value={money(data.summary.compensation ?? 0)} hint={scope} />
            <Tile label="Lead fees total" value={money(data.summary.fee_total ?? 0)} hint={scope} />
            <Tile label="Advance held (earlier bookings)" value={money(data.summary.advance_held)} hint={scope} />
            <Tile label="Reversals" value={money(data.summary.reversals)} hint={scope} />
            <Tile label="Pending net" value={money(data.summary.pending_net)} hint={`${scope}; credits minus debits`} />
            <Tile label="Settled net" value={money(data.summary.settled_net)} hint={`${scope}; credits minus debits`} />
            <Tile
              label="Platform net"
              value={money(data.platform.net)}
              hint={`${money(data.platform.gross_commission)} commission minus ${money(data.platform.reversals)} reversals${from || to ? ' in range' : ', all time'}`}
            />
          </div>

          <div className="mt-6">
            {data.rows.length === 0 ? (
              <EmptyState title="No ledger entries" description="Entries appear when bookings complete with a commission or an advance held." />
            ) : (
              <div className="overflow-x-auto rounded-xl border border-ink-100">
                <table className="w-full min-w-[820px] text-sm">
                  <thead className="bg-ink-50 text-left text-xs font-medium uppercase tracking-wide text-ink-500">
                    <tr>
                      <th className="px-4 py-3">Booking</th>
                      <th className="px-4 py-3">Vendor</th>
                      <th className="px-4 py-3">Entry</th>
                      <th className="px-4 py-3">Direction</th>
                      <th className="px-4 py-3 text-right">Amount</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Created</th>
                      <th className="px-4 py-3">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink-100">
                    {data.rows.map((r) => (
                      <tr key={String(r.id)}>
                        <td className="px-4 py-3 font-medium">
                          {r.booking_number ? (
                            <Link to={`/app/admin/bookings/${r.booking_id}`} className="text-brand-700 underline-offset-2 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600">
                              {r.booking_number}
                            </Link>
                          ) : (
                            `#${r.booking_id}`
                          )}
                        </td>
                        <td className="px-4 py-3 text-ink-700">{r.business_name ?? '—'}</td>
                        <td className="px-4 py-3 text-ink-700">{entryLabel(r.entry_type)}</td>
                        <td className="px-4 py-3 text-ink-700">{r.direction === 'credit' ? 'Credit' : 'Debit'}</td>
                        <td className="px-4 py-3 text-right font-semibold text-ink-900">{money(r.amount)}</td>
                        <td className="px-4 py-3">
                          <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${r.status === 'settled' ? 'bg-success-50 text-success-800' : 'bg-amber-50 text-amber-800'}`}>
                            {r.status === 'settled' ? 'Settled' : 'Pending'}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-xs text-ink-500">{fmtDate(r.created_at)}</td>
                        <td className="px-4 py-3">
                          {canSettle && firstPendingIds.has(String(r.id)) && (
                            <Button variant="secondary" size="sm" onClick={() => openSettle(r)} aria-label={`Settle booking ${r.booking_number ?? r.booking_id}`}>
                              Settle
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-sm text-ink-600">
              <span>
                {data.total} {data.total === 1 ? 'entry' : 'entries'}; page {data.page} of {totalPages}
              </span>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" disabled={page <= 1 || loading} onClick={() => setPage(page - 1)}>
                  Previous
                </Button>
                <Button variant="secondary" size="sm" disabled={page >= totalPages || loading} onClick={() => setPage(page + 1)}>
                  Next
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={!!target}
        title={`Settle booking ${target?.bookingNumber ?? ''}?`}
        description={
          target && (
            <>
              <p>
                Marks every pending ledger entry of booking <strong>{target.bookingNumber}</strong> ({target.vendorName}) as settled. This cannot be undone.
              </p>
              <p className="mt-2">
                Net of the pending entries shown here: <strong>{money(target.net)}</strong>.{' '}
                {target.net < 0
                  ? `The shortfall of ${money(Math.abs(target.net))} is deducted from the vendor wallet. If the wallet cannot cover it, nothing is changed.`
                  : 'No wallet deduction is needed; the entries are only marked settled.'}
              </p>
            </>
          )
        }
        confirmLabel="Settle booking"
        loading={settling}
        onConfirm={confirmSettle}
        onCancel={closeSettle}
      >
        {settleError && (
          <p role="alert" className="text-sm text-danger-600">
            {settleError}
          </p>
        )}
      </ConfirmDialog>
    </div>
  );
}
