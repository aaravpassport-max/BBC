import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ApiError } from '../../lib/api';
import {
  getPerformanceList,
  getVendorPerformance,
  type PerformanceDetail,
  type PerformanceEntity,
  type PerformanceListRow,
  type PerformanceSnapshot,
} from '../../lib/api-admin-finance';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';

type MetricKey = 'avg_rating' | 'completion_rate' | 'on_time_pct' | 'bookings_completed';

const METRICS: { key: MetricKey; label: string; max: number | null; suffix: string }[] = [
  { key: 'avg_rating', label: 'Average rating', max: 5, suffix: ' / 5' },
  { key: 'completion_rate', label: 'Completion rate', max: 100, suffix: '%' },
  { key: 'on_time_pct', label: 'On-time %', max: 100, suffix: '%' },
  { key: 'bookings_completed', label: 'Bookings completed', max: null, suffix: '' },
];

const inputCls =
  'mt-1.5 rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500/40';

// TRACE: API value (number, numeric string or null) → number or null → null stays null so no figure is ever invented.
//        Preconditions: none → postconditions: pure → edge cases: '' / NaN / undefined become null.
function toNum(v: number | string | null | undefined): number | null {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

// TRACE: nullable number → display text with suffix → "4.5 / 5" or an em dash when there is no data.
//        Preconditions: none → postconditions: pure → edge cases: null shows "—".
function show(v: number | null, suffix = '', digits = 1): string {
  return v === null ? '—' : `${Number(v.toFixed(digits))}${suffix}`;
}

// TRACE: seconds → "12 min" / "1 h 5 min" text → string.
//        Preconditions: none → postconditions: pure → edge cases: null shows "—", under a minute shows seconds.
function fmtSecs(v: number | null): string {
  if (v === null) return '—';
  if (v < 60) return `${Math.round(v)} s`;
  const m = Math.round(v / 60);
  return m < 60 ? `${m} min` : `${Math.floor(m / 60)} h ${m % 60} min`;
}

// TRACE: snake_case key → readable label → string. Preconditions: none → postconditions: pure → edge cases: empty string.
function prettyKey(k: string): string {
  const s = k.replace(/_/g, ' ');
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// TRACE: snapshot list → the latest snapshot of an entity → snapshot or null.
//        Preconditions: trend is chronological → postconditions: pure → edge cases: empty trend gives null.
function latest(e: PerformanceEntity): PerformanceSnapshot | null {
  return e.trend.length ? e.trend[e.trend.length - 1] : null;
}

// TRACE: entity trend + metric → one bar per period, scaled to the metric maximum (or the largest value for counts) →
//        list of labelled bars. Preconditions: trend array → postconditions: pure render →
//        edge cases: empty trend shows a message, null values show "no data" text instead of a bar.
function TrendBars({ trend, metric }: { trend: PerformanceSnapshot[]; metric: MetricKey }) {
  const def = METRICS.find((m) => m.key === metric) ?? METRICS[0];
  if (trend.length === 0) return <p className="text-sm text-ink-500">No monthly snapshots have been computed yet.</p>;
  const values = trend.map((t) => toNum(t[metric]));
  const ceiling = def.max ?? Math.max(1, ...values.map((v) => v ?? 0));
  return (
    <ul className="space-y-2">
      {trend.map((t, i) => {
        const v = values[i];
        return (
          <li key={t.period} className="flex items-center gap-3 text-sm">
            <span className="w-16 shrink-0 text-xs text-ink-500">{t.period}</span>
            <div className="h-3 flex-1 overflow-hidden rounded bg-ink-100">
              {v !== null && <div className="h-full rounded bg-brand-600" style={{ width: `${Math.min(100, (v / ceiling) * 100)}%` }} />}
            </div>
            <span className="w-24 shrink-0 text-right font-medium text-ink-800">{v === null ? 'no data' : show(v, def.suffix)}</span>
          </li>
        );
      })}
    </ul>
  );
}

// TRACE: category map → average score bars out of 5 with the number of ratings → list.
//        Preconditions: object or empty array → postconditions: pure render → edge cases: no ratings shows a message.
function CategoryBars({ categories }: { categories: PerformanceEntity['categories'] }) {
  const entries = Object.entries(categories);
  if (entries.length === 0) return <p className="text-sm text-ink-500">No category ratings in the last 12 months.</p>;
  return (
    <ul className="space-y-2">
      {entries.map(([key, c]) => (
        <li key={key} className="flex items-center gap-3 text-sm">
          <span className="w-32 shrink-0 text-ink-700">{prettyKey(key)}</span>
          <div className="h-3 flex-1 overflow-hidden rounded bg-ink-100">
            <div className="h-full rounded bg-success-500" style={{ width: `${Math.min(100, (c.avg / 5) * 100)}%` }} />
          </div>
          <span className="w-28 shrink-0 text-right font-medium text-ink-800">
            {c.avg.toFixed(2)} / 5 ({c.count})
          </span>
        </li>
      ))}
    </ul>
  );
}

// TRACE: drivers or vehicles → table of latest-period figures per entity → responsive table.
//        Preconditions: rows carry trend + categories → postconditions: pure render →
//        edge cases: no rows shows an empty state, entities without a snapshot show em dashes.
function EntityTable({ title, rows, nameOf, extra }: {
  title: string;
  rows: { id: number; trend: PerformanceSnapshot[]; categories: PerformanceEntity['categories']; name: string; extra?: string }[];
  nameOf: string;
  extra?: string;
}) {
  return (
    <section className="mt-6" aria-label={title}>
      <h2 className="text-base font-semibold text-ink-900">{title}</h2>
      {rows.length === 0 ? (
        <div className="mt-3">
          <EmptyState title={`No ${title.toLowerCase()}`} description="Nothing is registered for this vendor yet." />
        </div>
      ) : (
        <div className="mt-3 overflow-x-auto rounded-xl border border-ink-100">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="bg-ink-50 text-left text-xs font-medium uppercase tracking-wide text-ink-500">
              <tr>
                <th className="px-4 py-3">{nameOf}</th>
                {extra && <th className="px-4 py-3">{extra}</th>}
                <th className="px-4 py-3">Period</th>
                <th className="px-4 py-3 text-right">Completed</th>
                <th className="px-4 py-3 text-right">Avg rating</th>
                <th className="px-4 py-3 text-right">On-time</th>
                <th className="px-4 py-3 text-right">Complaints</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-100">
              {rows.map((r) => {
                const s = latest(r);
                return (
                  <tr key={r.id}>
                    <td className="px-4 py-3 font-medium text-ink-900">{r.name}</td>
                    {extra && <td className="px-4 py-3 text-ink-700">{r.extra ?? '—'}</td>}
                    <td className="px-4 py-3 text-ink-700">{s?.period ?? '—'}</td>
                    <td className="px-4 py-3 text-right">{s ? s.bookings_completed : '—'}</td>
                    <td className="px-4 py-3 text-right">{show(s ? s.avg_rating : null, ' / 5', 2)}</td>
                    <td className="px-4 py-3 text-right">{show(s ? s.on_time_pct : null, '%')}</td>
                    <td className="px-4 py-3 text-right">{s ? s.complaint_count : '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

// TRACE: vendor id → loads the drill-down (trend, categories, drivers, vehicles) → detail view.
//        Preconditions: vendor id from ?vendor_id → postconditions: read-only →
//        edge cases: loading skeleton, error banner with retry (404 unknown vendor), empty trend, stale responses dropped,
//        per-driver/vehicle tables only for fleet vendors.
function VendorDrilldown({ vendorId }: { vendorId: number }) {
  const [detail, setDetail] = useState<PerformanceDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [metric, setMetric] = useState<MetricKey>('avg_rating');
  const seq = useRef(0);

  // TRACE: mount / vendor change / retry → GET performance detail → stores it. Preconditions: none →
  //        postconditions: latest request wins → edge cases: ApiError message shown, stale response dropped.
  const load = useCallback(async () => {
    const id = ++seq.current;
    setLoading(true);
    setError(null);
    try {
      const res = await getVendorPerformance(vendorId);
      if (id !== seq.current) return;
      setDetail(res);
    } catch (err) {
      if (id !== seq.current) return;
      setDetail(null);
      setError(err instanceof ApiError ? err.message : 'Could not load this vendor\'s performance. Please try again.');
    } finally {
      if (id === seq.current) setLoading(false);
    }
  }, [vendorId]);

  // TRACE: mount / vendor change → runs load; unmount → invalidates in-flight request.
  //        Preconditions: none → postconditions: no state writes after unmount → edge cases: none.
  useEffect(() => {
    void load();
    return () => {
      seq.current += 1;
    };
  }, [load]);

  const isFleet = detail?.vendor_type === 'fleet';

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <Link to="/admin/performance" className="text-sm font-medium text-brand-700 hover:text-brand-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600">
        ← All vendors
      </Link>
      <h1 className="mt-2 text-2xl font-bold text-ink-900 sm:text-3xl">Vendor #{vendorId} performance</h1>

      {loading && (
        <div className="mt-6 space-y-3" aria-busy="true" aria-label="Loading performance">
          <Skeleton className="h-40 w-full rounded-xl" />
          <Skeleton className="h-40 w-full rounded-xl" />
        </div>
      )}
      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {!loading && detail && (
        <>
          <p className="mt-1 text-sm text-ink-500">Account type: {detail.vendor_type === 'fleet' ? 'Fleet' : 'Individual'}</p>
          <section className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs" aria-label="Monthly trend">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <h2 className="text-base font-semibold text-ink-900">Monthly trend (last 6 periods)</h2>
              <div>
                <label htmlFor="perf-metric" className="block text-sm font-medium text-ink-700">
                  Metric
                </label>
                <select id="perf-metric" value={metric} onChange={(e) => setMetric(e.target.value as MetricKey)} className={inputCls}>
                  {METRICS.map((m) => (
                    <option key={m.key} value={m.key}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="mt-4">
              <TrendBars trend={detail.vendor.trend} metric={metric} />
            </div>
            {latest(detail.vendor) && (
              <dl className="mt-5 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
                {[
                  ['Cancelled', String(latest(detail.vendor)?.bookings_cancelled ?? '—')],
                  ['Cancellation rate', show(latest(detail.vendor)?.cancellation_rate ?? null, '%')],
                  ['Avg response', fmtSecs(latest(detail.vendor)?.response_time_avg_secs ?? null)],
                  ['Complaints', String(latest(detail.vendor)?.complaint_count ?? '—')],
                ].map(([k, v]) => (
                  <div key={k}>
                    <dt className="text-xs uppercase tracking-wide text-ink-500">{k}</dt>
                    <dd className="font-semibold text-ink-900">{v}</dd>
                  </div>
                ))}
              </dl>
            )}
          </section>

          <section className="mt-6 rounded-xl border border-ink-100 p-5 shadow-xs" aria-label="Category breakdown">
            <h2 className="text-base font-semibold text-ink-900">Rating categories (last 12 months)</h2>
            <div className="mt-4">
              <CategoryBars categories={detail.vendor.categories} />
            </div>
          </section>

          {isFleet && (
            <>
              <EntityTable
                title="Drivers"
                nameOf="Driver"
                extra="Overall rating"
                rows={detail.drivers.map((d) => ({ id: d.id, trend: d.trend, categories: d.categories, name: d.name, extra: d.rating ? d.rating.toFixed(2) : undefined }))}
              />
              <EntityTable
                title="Vehicles"
                nameOf="Vehicle"
                rows={detail.vehicles.map((v) => ({ id: v.id, trend: v.trend, categories: v.categories, name: v.label || `Vehicle #${v.id}` }))}
              />
            </>
          )}
        </>
      )}
    </div>
  );
}

// TRACE: route /app/admin/performance → with ?vendor_id renders the drill-down, otherwise the ranked vendor list
//        (latest snapshot period per vendor, sortable client-side).
//        Preconditions: cap ridego_view_performance_data → postconditions: read-only →
//        edge cases: loading skeleton, error banner with retry, no snapshots yet (empty state), null metrics sort last and
//        show "—", stale responses dropped, invalid vendor_id falls back to the list.
export function AdminPerformancePage() {
  const [params] = useSearchParams();
  const vendorParam = Number(params.get('vendor_id'));
  const vendorId = Number.isInteger(vendorParam) && vendorParam > 0 ? vendorParam : 0;

  const [rows, setRows] = useState<PerformanceListRow[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [rankBy, setRankBy] = useState<MetricKey>('avg_rating');
  const seq = useRef(0);

  // TRACE: mount / retry → GET performance list → stores rows. Preconditions: none → postconditions: latest request wins →
  //        edge cases: ApiError message shown, stale response dropped.
  const load = useCallback(async () => {
    const id = ++seq.current;
    setLoading(true);
    setError(null);
    try {
      const res = await getPerformanceList();
      if (id !== seq.current) return;
      setRows(res.rows);
    } catch (err) {
      if (id !== seq.current) return;
      setError(err instanceof ApiError ? err.message : 'Could not load vendor performance. Please try again.');
    } finally {
      if (id === seq.current) setLoading(false);
    }
  }, []);

  // TRACE: list mode mount → runs load; unmount or switch to drill-down → invalidates in-flight request.
  //        Preconditions: none → postconditions: no state writes after unmount → edge cases: drill-down mode skips the fetch.
  useEffect(() => {
    if (vendorId) return undefined;
    void load();
    return () => {
      seq.current += 1;
    };
  }, [load, vendorId]);

  const ranked = useMemo(() => {
    const list = (rows ?? []).map((r) => ({ r, v: toNum(r[rankBy]) }));
    list.sort((a, b) => (a.v === null ? 1 : 0) - (b.v === null ? 1 : 0) || (b.v ?? 0) - (a.v ?? 0));
    return list;
  }, [rows, rankBy]);

  if (vendorId) return <VendorDrilldown vendorId={vendorId} />;

  const period = rows && rows.length ? rows[0].period : null;

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Vendor performance</h1>
          <p className="text-sm text-ink-500">
            {period ? `Latest computed period: ${period}. ` : ''}Snapshots are computed from real bookings, ratings and service events.
          </p>
        </div>
        <div>
          <label htmlFor="rank-by" className="block text-sm font-medium text-ink-700">
            Rank by
          </label>
          <select id="rank-by" value={rankBy} onChange={(e) => setRankBy(e.target.value as MetricKey)} className={inputCls}>
            {METRICS.map((m) => (
              <option key={m.key} value={m.key}>
                {m.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading && (
        <div className="mt-6 space-y-3" aria-busy="true" aria-label="Loading vendor performance">
          <Skeleton className="h-12 w-full rounded-xl" />
          <Skeleton className="h-12 w-full rounded-xl" />
          <Skeleton className="h-12 w-full rounded-xl" />
        </div>
      )}
      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}
      {!loading && !error && rows && rows.length === 0 && (
        <div className="mt-6">
          <EmptyState title="No performance snapshots yet" description="Snapshots are computed nightly once vendors have completed bookings." />
        </div>
      )}
      {!loading && !error && rows && rows.length > 0 && (
        <div className="mt-6 overflow-x-auto rounded-xl border border-ink-100">
          <table className="w-full min-w-[760px] text-sm">
            <thead className="bg-ink-50 text-left text-xs font-medium uppercase tracking-wide text-ink-500">
              <tr>
                <th className="px-4 py-3">Rank</th>
                <th className="px-4 py-3">Vendor</th>
                <th className="px-4 py-3">Type</th>
                <th className="px-4 py-3 text-right">Completed</th>
                <th className="px-4 py-3 text-right">Completion</th>
                <th className="px-4 py-3 text-right">Avg rating</th>
                <th className="px-4 py-3 text-right">On-time</th>
                <th className="px-4 py-3 text-right">Complaints</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-100">
              {ranked.map(({ r, v }, i) => (
                <tr key={String(r.entity_id)}>
                  <td className="px-4 py-3 text-ink-700">{v === null ? '—' : i + 1}</td>
                  <td className="px-4 py-3 font-medium">
                    <Link to={`/app/admin/performance?vendor_id=${r.entity_id}`} className="text-brand-700 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600">
                      {r.business_name}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-ink-700">{r.vendor_type === 'fleet' ? 'Fleet' : 'Individual'}</td>
                  <td className="px-4 py-3 text-right">{toNum(r.bookings_completed) ?? '—'}</td>
                  <td className="px-4 py-3 text-right">{show(toNum(r.completion_rate), '%')}</td>
                  <td className="px-4 py-3 text-right">{show(toNum(r.avg_rating), ' / 5', 2)}</td>
                  <td className="px-4 py-3 text-right">{show(toNum(r.on_time_pct), '%')}</td>
                  <td className="px-4 py-3 text-right">{toNum(r.complaint_count) ?? '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
