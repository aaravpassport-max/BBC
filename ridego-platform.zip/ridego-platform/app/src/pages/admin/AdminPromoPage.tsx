import { useCallback, useEffect, useState } from 'react';
import {
  createAdminPromoCode,
  getAdminPromoCodes,
  toggleAdminPromoCode,
  updateAdminPromoCode,
  ApiError,
} from '../../lib/api';
import type { AdminPromoInput, AdminPromoRow } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';

const TRIP_TYPE_OPTIONS: { key: string; label: string }[] = [
  { key: 'one_way', label: 'One way' },
  { key: 'round_trip', label: 'Round trip' },
  { key: 'local', label: 'Local' },
  { key: 'airport_pickup', label: 'Airport pickup' },
  { key: 'airport_drop', label: 'Airport drop' },
  { key: 'outstation', label: 'Outstation' },
];

const EMPTY_FORM: AdminPromoInput = {
  code: '',
  description: '',
  discount_type: 'percentage',
  discount_value: '',
  min_booking_amount: '',
  max_discount: '',
  usage_limit: '',
  start_date: '',
  expiry_date: '',
  trip_type: [],
  is_active: true,
};

function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

export function AdminPromoPage() {
  const [rows, setRows] = useState<AdminPromoRow[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<AdminPromoRow | null>(null);
  const [form, setForm] = useState<AdminPromoInput>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [toggleTarget, setToggleTarget] = useState<AdminPromoRow | null>(null);
  const [toggling, setToggling] = useState(false);
  const [toggleError, setToggleError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminPromoCodes();
      setRows(res.rows);
    } catch (err) {
      if (err instanceof ApiError && err.code === 'forbidden') {
        setError("You don't have permission to manage promo codes.");
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not load promo codes. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function openAdd() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setFormError(null);
    setShowForm(true);
  }

  function openEdit(p: AdminPromoRow) {
    setEditing(p);
    setForm({
      code: p.code,
      description: p.description,
      discount_type: p.discount_type,
      discount_value: p.discount_value,
      min_booking_amount: p.min_booking_amount,
      max_discount: p.max_discount,
      usage_limit: p.usage_limit,
      start_date: p.start_date,
      expiry_date: p.expiry_date,
      trip_type: p.trip_type,
      is_active: p.is_active,
    });
    setFormError(null);
    setShowForm(true);
  }

  function toggleTripType(key: string) {
    setForm((f) => {
      const current = f.trip_type ?? [];
      return {
        ...f,
        trip_type: current.includes(key) ? current.filter((t) => t !== key) : [...current, key],
      };
    });
  }

  async function submitForm() {
    if (!form.code?.trim()) {
      setFormError('Please provide a promo code.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      if (editing) {
        await updateAdminPromoCode(editing.id, form);
        setActionMessage(`"${form.code.toUpperCase()}" updated.`);
      } else {
        await createAdminPromoCode(form);
        setActionMessage(`"${form.code.toUpperCase()}" created.`);
      }
      setShowForm(false);
      await load();
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : 'Could not save this promo code.');
    } finally {
      setSaving(false);
    }
  }

  async function confirmToggle() {
    if (!toggleTarget) return;
    setToggling(true);
    setToggleError(null);
    try {
      const res = await toggleAdminPromoCode(toggleTarget.id);
      setActionMessage(res.message);
      setToggleTarget(null);
      await load();
    } catch (err) {
      setToggleError(err instanceof ApiError ? err.message : 'Could not change promo status.');
    } finally {
      setToggling(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Promo codes</h1>
          <p className="text-sm text-ink-500">Create and manage discount codes customers can apply at booking.</p>
          {!loading && rows && <p className="mt-1 text-xs font-medium text-ink-400">{rows.length} code{rows.length === 1 ? '' : 's'}</p>}
        </div>
        <Button onClick={openAdd}>Add promo code</Button>
      </div>

      {actionMessage && !loading && (
        <div role="status" className="mt-4 rounded-lg border border-success-500/30 bg-success-50 px-3.5 py-2.5 text-sm text-success-700">
          {actionMessage}
        </div>
      )}

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading promo codes">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full rounded-xl" />
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={load} />}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState title="No promo codes yet" description="Create your first discount code." />
        )}

        {!loading && !error && rows && rows.length > 0 && (
          <ul className="space-y-3">
            {rows.map((p) => (
              <li key={p.id} className="flex flex-wrap items-start justify-between gap-3 rounded-xl border border-ink-100 p-4 shadow-xs sm:p-5">
                <div>
                  <p className="font-mono text-base font-bold tracking-wide text-brand-700">
                    {p.code}
                    {!p.is_active && (
                      <span className="ml-2 rounded-full bg-ink-100 px-2 py-0.5 text-xs font-semibold text-ink-500">
                        Paused
                      </span>
                    )}
                  </p>
                  {p.description && <p className="mt-0.5 text-sm text-ink-500">{p.description}</p>}
                  <p className="mt-1 text-xs text-ink-400">
                    Used {p.used_count}/{p.usage_limit > 0 ? p.usage_limit : '∞'} &middot; {p.start_date || '—'} – {p.expiry_date || '—'}
                    {p.min_booking_amount > 0 ? ` · min booking ${currency(p.min_booking_amount)}` : ''}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-3">
                  <p
                    className={`text-lg font-bold ${p.discount_type === 'percentage' ? 'text-brand-700' : 'text-success-600'}`}
                  >
                    {p.discount_type === 'percentage' ? `${p.discount_value}%` : currency(p.discount_value)} OFF
                  </p>
                  <Button variant="secondary" size="sm" onClick={() => openEdit(p)}>
                    Edit
                  </Button>
                  <Button
                    variant={p.is_active ? 'danger' : 'secondary'}
                    size="sm"
                    onClick={() => {
                      setToggleTarget(p);
                      setToggleError(null);
                    }}
                    aria-label={`${p.is_active ? 'Pause' : 'Activate'} promo code ${p.code}`}
                  >
                    {p.is_active ? 'Pause' : 'Activate'}
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <ConfirmDialog
        open={showForm}
        title={editing ? `Edit ${editing.code}` : 'Add promo code'}
        confirmLabel={editing ? 'Save changes' : 'Create promo code'}
        confirmVariant="primary"
        loading={saving}
        onConfirm={submitForm}
        onCancel={() => {
          if (saving) return;
          setShowForm(false);
        }}
      >
        <div className="max-h-[60vh] space-y-3 overflow-y-auto pr-1">
          {formError && (
            <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
              {formError}
            </div>
          )}
          <div>
            <label htmlFor="promo-code" className="block text-sm font-medium text-ink-700">
              Promo code
            </label>
            <input
              id="promo-code"
              type="text"
              value={form.code}
              onChange={(e) => setForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))}
              placeholder="SAVE20"
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 font-mono text-sm uppercase tracking-wide shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div>
            <label htmlFor="promo-description" className="block text-sm font-medium text-ink-700">
              Description
            </label>
            <input
              id="promo-description"
              type="text"
              value={form.description}
              onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
              placeholder="Shown to customers when applied"
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="promo-type" className="block text-sm font-medium text-ink-700">
                Discount type
              </label>
              <select
                id="promo-type"
                value={form.discount_type}
                onChange={(e) => setForm((f) => ({ ...f, discount_type: e.target.value as 'percentage' | 'fixed' }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              >
                <option value="percentage">Percentage (%)</option>
                <option value="fixed">Fixed amount (₹)</option>
              </select>
            </div>
            <div>
              <label htmlFor="promo-value" className="block text-sm font-medium text-ink-700">
                Discount value
              </label>
              <input
                id="promo-value"
                type="text"
                inputMode="decimal"
                value={form.discount_value}
                onChange={(e) => setForm((f) => ({ ...f, discount_value: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="promo-min" className="block text-sm font-medium text-ink-700">
                Min booking fare (₹)
              </label>
              <input
                id="promo-min"
                type="text"
                inputMode="decimal"
                value={form.min_booking_amount}
                onChange={(e) => setForm((f) => ({ ...f, min_booking_amount: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="promo-max" className="block text-sm font-medium text-ink-700">
                Max discount (₹, 0 = unlimited)
              </label>
              <input
                id="promo-max"
                type="text"
                inputMode="decimal"
                value={form.max_discount}
                onChange={(e) => setForm((f) => ({ ...f, max_discount: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <div>
            <label htmlFor="promo-usage-limit" className="block text-sm font-medium text-ink-700">
              Usage limit (0 = unlimited)
            </label>
            <input
              id="promo-usage-limit"
              type="text"
              inputMode="numeric"
              value={form.usage_limit}
              onChange={(e) => setForm((f) => ({ ...f, usage_limit: e.target.value }))}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="promo-start" className="block text-sm font-medium text-ink-700">
                Valid from
              </label>
              <input
                id="promo-start"
                type="date"
                value={form.start_date}
                onChange={(e) => setForm((f) => ({ ...f, start_date: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="promo-end" className="block text-sm font-medium text-ink-700">
                Valid until
              </label>
              <input
                id="promo-end"
                type="date"
                value={form.expiry_date}
                onChange={(e) => setForm((f) => ({ ...f, expiry_date: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <div>
            <p className="block text-sm font-medium text-ink-700">Trip types (none checked = all)</p>
            <div className="mt-1.5 flex flex-wrap gap-2">
              {TRIP_TYPE_OPTIONS.map((t) => (
                <label key={t.key} className="flex items-center gap-1.5 text-sm text-ink-700">
                  <input
                    type="checkbox"
                    checked={(form.trip_type ?? []).includes(t.key)}
                    onChange={() => toggleTripType(t.key)}
                    className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
                  />
                  {t.label}
                </label>
              ))}
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={form.is_active !== false}
              onChange={(e) => setForm((f) => ({ ...f, is_active: e.target.checked }))}
              className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
            />
            Active (visible to users)
          </label>
        </div>
      </ConfirmDialog>

      <ConfirmDialog
        open={!!toggleTarget}
        title={toggleTarget?.is_active ? `Pause ${toggleTarget?.code}?` : `Activate ${toggleTarget?.code}?`}
        description={
          toggleTarget?.is_active
            ? 'This hides the promo code from customers — it can no longer be applied.'
            : 'This makes the promo code available to customers again.'
        }
        confirmLabel={toggleTarget?.is_active ? 'Pause' : 'Activate'}
        confirmVariant={toggleTarget?.is_active ? 'danger' : 'primary'}
        loading={toggling}
        onConfirm={confirmToggle}
        onCancel={() => {
          if (toggling) return;
          setToggleTarget(null);
          setToggleError(null);
        }}
      >
        {toggleError && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {toggleError}
          </div>
        )}
      </ConfirmDialog>
    </div>
  );
}
