import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { SOURCE_LABELS } from '../../lib/api-admin-crm';
import { Link, useSearchParams } from 'react-router-dom';
import {
  bulkBookingAction,
  getAdminBookings,
  getAdminBookingVendorPicker,
  getAdminReportsExportNonce,
  verifyBookingPayment,
  ApiError,
} from '../../lib/api';
import { bulkBookings, type BulkAction, type BulkResponse } from '../../lib/api-admin-command';
import { hasAdminCap } from '../../lib/permissions';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import type { AdminBookingRow, AdminBookingsResponse, AdminBookingVendorPickerRow } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { BookingQuickActions } from '../../components/admin/BookingQuickActions';
import { Button } from '../../components/ui/Button';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';

/** Mirrors admin/pages/bookings.php's quick-filter pill row exactly (same statuses, same order, same labels/emoji). */
const QUICK_PILLS: { key: string; label: string }[] = [
  { key: '', label: 'All' },
  { key: 'payment_proof_submitted', label: '🔍 Proofs' },
  { key: 'pending_payment', label: '💳 Awaiting Pmt' },
  { key: 'confirmed', label: '✅ Confirmed' },
  { key: 'vendor_assigned', label: '🚗 Assigned' },
  { key: 'token_refund_due', label: '⏳ Booking Amount Refund Due' },
  { key: 'completed', label: '🏁 Completed' },
  { key: 'cancelled', label: '❌ Cancelled' },
];

const STATUS_OPTIONS: { key: string; label: string }[] = [
  { key: '', label: 'All statuses' },
  { key: 'pending', label: 'Pending' },
  { key: 'pending_payment', label: 'Booking amount pending' },
  { key: 'payment_proof_submitted', label: 'Proof submitted' },
  { key: 'confirmed', label: 'Confirmed' },
  { key: 'vendor_assigned', label: 'Vendor assigned' },
  { key: 'driver_en_route', label: 'Driver en route' },
  { key: 'trip_started', label: 'Trip started' },
  { key: 'token_refund_due', label: 'Booking not arranged — booking amount refund due' },
  { key: 'completed', label: 'Completed' },
  { key: 'cancelled', label: 'Cancelled' },
  { key: 'expired', label: 'Expired' },
];

/** Mirrors the real trip_type enum used by the booking form/backend (includes/app-admin-bookings-api.php) exactly. */
const TRIP_TYPE_OPTIONS: { key: string; label: string }[] = [
  { key: '', label: 'All trip types' },
  { key: 'one_way', label: 'One way' },
  { key: 'round_trip', label: 'Round trip' },
  { key: 'local', label: 'Local' },
  { key: 'airport_pickup', label: 'Airport pickup' },
  { key: 'airport_drop', label: 'Airport drop' },
  { key: 'outstation', label: 'Outstation' },
];

const statusBadgeStyles: Record<string, string> = {
  pending_payment: 'bg-warning-50 text-warning-600',
  payment_proof_submitted: 'bg-warning-50 text-warning-600',
  payment_rejected: 'bg-danger-50 text-danger-600',
  confirmed: 'bg-success-50 text-success-600',
  vendor_assigned: 'bg-brand-50 text-brand-700',
  driver_en_route: 'bg-brand-50 text-brand-700',
  trip_started: 'bg-brand-50 text-brand-700',
  token_refund_due: 'bg-warning-50 text-warning-700',
  completed: 'bg-success-50 text-success-600',
  cancelled: 'bg-danger-50 text-danger-600',
  expired: 'bg-ink-100 text-ink-600',
};

function badgeClass(value: string): string {
  return statusBadgeStyles[value] ?? 'bg-ink-100 text-ink-600';
}

function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

function humanize(value: string): string {
  return value
    .split('_')
    .map((part) => (part ? part[0].toUpperCase() + part.slice(1) : part))
    .join(' ');
}

// TRACE: route /app/admin/bookings → filterable booking list with legacy bulk bar plus (for ridego_bulk_booking_actions holders)
//        a sticky Cancel / Reopen bar → list, confirm dialog, per-id results.
//        Capability check via useAuth → bulk UI hidden without it → results never claim success for failed ids,
//        selection cleared and list re-fetched after every bulk call, reason required, double submit blocked.
export function AdminBookingsPage() {
  const { user } = useAuth();
  const toast = useToast();
  const canBulk = hasAdminCap(user, 'ridego_bulk_booking_actions');
  const [bulkDialog, setBulkDialog] = useState<BulkAction | null>(null);
  const [bulkReason, setBulkReason] = useState('');
  const [bulkPending, setBulkPending] = useState(false);
  const [bulkResult, setBulkResult] = useState<{ action: BulkAction; response: BulkResponse; labels: Record<number, string> } | null>(null);
  const [searchParams] = useSearchParams();
  const initialStatus = searchParams.get('status') ?? '';
  const [status, setStatus] = useState(initialStatus);
  const [tripType, setTripType] = useState('');
  const [vendorId, setVendorId] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [page, setPage] = useState(1);
  const [data, setData] = useState<AdminBookingsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const [exportingSelected, setExportingSelected] = useState(false);
  const [verifyingId, setVerifyingId] = useState<number | null>(null);
  const [vendors, setVendors] = useState<AdminBookingVendorPickerRow[]>([]);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [bulkAction, setBulkAction] = useState('');
  const [bulkRunning, setBulkRunning] = useState(false);
  const [bulkMessage, setBulkMessage] = useState<string | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const canCreate = !!user?.is_admin || hasAdminCap(user, 'ridego_create_admin_booking');
  const [source, setSource] = useState('');
  const sourceRef = useRef('');

  const load = useCallback(
    async (s: string, t: string, v: string, df: string, dt: string, q: string, p: number) => {
      setLoading(true);
      setError(null);
      try {
        const res = await getAdminBookings({
          status: s || undefined,
          trip_type: t || undefined,
          vendor_id: v ? Number(v) : undefined,
          date_from: df || undefined,
          date_to: dt || undefined,
          search: q || undefined,
          source: sourceRef.current || undefined,
          page: p,
        });
        setData(res);
      } catch (err) {
        if (err instanceof ApiError && err.code === 'forbidden') {
          setError("You don't have permission to manage bookings.");
        } else {
          setError(err instanceof ApiError ? err.message : 'Could not load bookings. Please try again.');
        }
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // TRACE: any filter change (incl. booking source, held in a ref the loader reads) → reloads the list. Source change resets to page 1 via the select handler.
  useEffect(() => {
    sourceRef.current = source;
    load(status, tripType, vendorId, dateFrom, dateTo, search, page);
  }, [status, tripType, vendorId, dateFrom, dateTo, search, page, source, load]);

  useEffect(() => {
    getAdminBookingVendorPicker()
      .then((res) => setVendors(res.rows))
      .catch(() => {
        // Non-fatal — the vendor filter just stays empty if this fails.
      });
  }, []);

  useEffect(() => {
    // Selection is scoped to the current page's results; changing filters
    // or paging invalidates it (matches the old admin's per-page checkbox
    // behaviour — there's no cross-page "select all" there either).
    setSelectedIds([]);
  }, [status, tripType, vendorId, dateFrom, dateTo, search, page]);

  // TRACE: bulk bar button → opens the confirm dialog for cancel|reopen with an empty reason → dialog state set.
  //        action chosen → dialog visible → ignored when nothing is selected.
  function openBulkDialog(action: BulkAction) {
    if (selectedIds.length === 0) return;
    setBulkReason('');
    setBulkDialog(action);
  }

  // TRACE: dialog Cancel/Escape → closes and clears the reason unless a request is in flight → dialog state reset.
  //        dialog open → closed → ignored while pending.
  const closeBulkDialog = useCallback(() => {
    if (bulkPending) return;
    setBulkDialog(null);
    setBulkReason('');
  }, [bulkPending]);

  // TRACE: dialog confirm → POST /admin/bookings/bulk {action, ids, reason} → summary shown, selection cleared, list re-fetched.
  //        1..50 selected ids and a reason → per-id results stored verbatim → API error toasts the message and keeps the
  //        dialog and reason; partial failures reported as warnings (never as full success).
  async function confirmBulk() {
    if (!bulkDialog || bulkPending || !bulkReason.trim()) return;
    setBulkPending(true);
    try {
      const response = await bulkBookings(bulkDialog, selectedIds, bulkReason.trim());
      const labels: Record<number, string> = {};
      (data?.rows ?? []).forEach((r) => {
        labels[r.id] = r.booking_number;
      });
      setBulkResult({ action: bulkDialog, response, labels });
      if (response.failed === 0) toast.show(`${response.ok} booking${response.ok === 1 ? '' : 's'} updated.`, 'success');
      else toast.show(`${response.ok} succeeded, ${response.failed} failed. See the results below.`, 'error');
      setBulkDialog(null);
      setBulkReason('');
      setSelectedIds([]);
      await load(status, tripType, vendorId, dateFrom, dateTo, search, page);
    } catch (err) {
      toast.show(err instanceof ApiError ? err.message : 'Bulk action failed. Please try again.', 'error');
    } finally {
      setBulkPending(false);
    }
  }

  function changeStatus(s: string) {
    setStatus(s);
    setPage(1);
  }

  function changeTripType(t: string) {
    setTripType(t);
    setPage(1);
  }

  function changeVendor(v: string) {
    setVendorId(v);
    setPage(1);
  }

  function changeDateFrom(v: string) {
    setDateFrom(v);
    setPage(1);
  }

  function changeDateTo(v: string) {
    setDateTo(v);
    setPage(1);
  }

  function submitSearch(e: FormEvent) {
    e.preventDefault();
    setSearch(searchInput.trim());
    setPage(1);
  }

  function toggleRow(id: number) {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  function toggleSelectAll(rows: AdminBookingRow[]) {
    setSelectedIds((prev) => (prev.length === rows.length ? [] : rows.map((r) => r.id)));
  }

  async function applyBulkAction() {
    if (!bulkAction || selectedIds.length === 0) return;
    setBulkRunning(true);
    setBulkMessage(null);
    try {
      const res = await bulkBookingAction(bulkAction as 'verify_payment' | 'cancel', selectedIds);
      setBulkMessage(res.message);
      setSelectedIds([]);
      setBulkAction('');
      await load(status, tripType, vendorId, dateFrom, dateTo, search, page);
    } catch (err) {
      setBulkMessage(err instanceof ApiError ? err.message : 'Bulk action failed.');
    } finally {
      setBulkRunning(false);
    }
  }

  /**
   * Same admin-ajax.php "ridego_export_csv" handler as the toolbar
   * Export CSV button, but posts selected_ids[] so the server constrains
   * the export to exactly the checked rows (admin/admin.php's
   * wp_ajax_ridego_export_csv already supports this via $_POST).
   */
  async function exportSelected() {
    if (selectedIds.length === 0) return;
    setExportingSelected(true);
    try {
      const { nonce } = await getAdminReportsExportNonce();
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = `${window.location.origin}/wp-admin/admin-ajax.php?action=ridego_export_csv&type=bookings&nonce=${encodeURIComponent(
        nonce
      )}`;
      form.target = '_blank';
      selectedIds.forEach((id) => {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'selected_ids[]';
        input.value = String(id);
        form.appendChild(input);
      });
      document.body.appendChild(form);
      form.submit();
      document.body.removeChild(form);
    } finally {
      setExportingSelected(false);
    }
  }

  /**
   * Same admin-ajax.php "ridego_export_csv" round-trip the old
   * admin/pages/bookings.php's "Export CSV" toolbar button uses — a
   * freshly minted ridego_admin_nonce lets this REST-authenticated
   * React admin drive that same, unchanged legacy export handler.
   */
  async function exportCsv() {
    setExporting(true);
    try {
      const { nonce } = await getAdminReportsExportNonce();
      const url = `${window.location.origin}/wp-admin/admin-ajax.php?action=ridego_export_csv&type=bookings&nonce=${encodeURIComponent(
        nonce
      )}`;
      window.open(url, '_blank', 'noopener,noreferrer');
    } finally {
      setExporting(false);
    }
  }

  async function quickVerify(id: number) {
    setVerifyingId(id);
    try {
      await verifyBookingPayment(id);
      await load(status, tripType, vendorId, dateFrom, dateTo, search, page);
    } catch {
      // Surfaced on the detail page if this quick action fails; the list
      // stays as-is rather than showing a modal for a one-click row action.
    } finally {
      setVerifyingId(null);
    }
  }

  const rows = data?.rows ?? null;
  const total = data?.total ?? 0;
  const perPage = data?.per_page ?? 25;
  const kpis = data?.kpis;
  const canPrev = page > 1;
  const canNext = page * perPage < total;
  const activeFilterCount = [status, tripType, vendorId, dateFrom, dateTo, search, source].filter(Boolean).length;

  const filterControls = (
    <>
      <select
        value={status}
        onChange={(e) => changeStatus(e.target.value)}
        className="rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        aria-label="Filter by booking status"
      >
        {STATUS_OPTIONS.map((o) => (
          <option key={o.key} value={o.key}>
            {o.label}
          </option>
        ))}
      </select>
      <select
        value={tripType}
        onChange={(e) => changeTripType(e.target.value)}
        className="rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        aria-label="Filter by trip type"
      >
        {TRIP_TYPE_OPTIONS.map((o) => (
          <option key={o.key} value={o.key}>
            {o.label}
          </option>
        ))}
      </select>
      <select
        value={source}
        onChange={(e) => { setSource(e.target.value); setPage(1); }}
        className="rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        aria-label="Filter by booking source"
      >
        <option value="">All sources</option>
        {Object.entries(SOURCE_LABELS).map(([k, l]) => (
          <option key={k} value={k}>
            {l}
          </option>
        ))}
      </select>
      <select
        value={vendorId}
        onChange={(e) => changeVendor(e.target.value)}
        className="rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        aria-label="Filter by vendor"
      >
        <option value="">All vendors</option>
        {vendors.map((v) => (
          <option key={v.id} value={v.id}>
            {v.business_name}
          </option>
        ))}
      </select>
      <input
        type="date"
        value={dateFrom}
        onChange={(e) => changeDateFrom(e.target.value)}
        title="Journey from"
        className="rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        aria-label="Journey date from"
      />
      <input
        type="date"
        value={dateTo}
        onChange={(e) => changeDateTo(e.target.value)}
        title="Journey to"
        className="rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        aria-label="Journey date to"
      />
    </>
  );

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Booking management</h1>
          <p className="text-sm text-ink-500">Review bookings, verify payments, assign vendors and manage trip status.</p>
        </div>
        <div className="flex gap-2">
          {canCreate && (
            <Link to="/admin/bookings/new" className="inline-flex items-center rounded-lg bg-brand-600 px-3 py-2 text-sm font-medium text-white hover:bg-brand-700">
              New booking
            </Link>
          )}
          <Button variant="secondary" size="sm" loading={exporting} onClick={exportCsv}>
            ⬇️ Export CSV
          </Button>
        </div>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-3 lg:grid-cols-6">
        <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Today's bookings</p>
          <p className="mt-2 text-xl font-bold text-ink-900">{loading ? '—' : kpis?.today_bookings ?? 0}</p>
        </div>
        <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Proof pending</p>
          <p className="mt-2 text-xl font-bold text-warning-600">{loading ? '—' : kpis?.proof_submitted ?? 0}</p>
        </div>
        <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Active trips</p>
          <p className="mt-2 text-xl font-bold text-brand-700">{loading ? '—' : kpis?.active_trips ?? 0}</p>
        </div>
        <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">No vendor</p>
          <p className="mt-2 text-xl font-bold text-danger-600">{loading ? '—' : kpis?.no_vendor ?? 0}</p>
        </div>
        <div className="rounded-xl border border-ink-100 p-4 shadow-xs">
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Booking amounts collected (month)</p>
          <p className="mt-2 text-xl font-bold text-success-600">{loading ? '—' : currency(kpis?.month_revenue ?? 0)}</p>
        </div>
        <button
          type="button"
          onClick={() => setStatus('token_refund_due')}
          className="rounded-xl border border-ink-100 p-4 text-left shadow-xs transition hover:border-warning-300"
        >
          <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Booking amount refunds due</p>
          <p className="mt-2 text-xl font-bold text-warning-700">{loading ? '—' : kpis?.token_refund_due ?? 0}</p>
        </button>
      </div>

      <div className="mt-6 hidden gap-3 lg:flex lg:flex-wrap lg:items-center">
        {filterControls}
        <form onSubmit={submitSearch} className="flex flex-1 gap-2 sm:min-w-[240px]">
          <input
            type="search"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search booking number, name or phone"
            className="w-full rounded-lg border border-ink-200 px-3.5 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            aria-label="Search bookings"
          />
          <Button type="submit" variant="secondary" size="sm">
            Search
          </Button>
        </form>
      </div>

      <div className="mt-6 lg:hidden">
        <button
          type="button"
          onClick={() => setFiltersOpen(true)}
          className="relative flex items-center gap-2 rounded-lg border border-ink-200 bg-white px-3.5 py-2 text-sm font-medium text-ink-700 shadow-xs"
        >
          <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 4h18M6 8h12M9 12h6M11 16h2" />
          </svg>
          Filters
          {activeFilterCount > 0 && (
            <span className="ml-1 flex h-2 w-2 rounded-full bg-brand-600" aria-hidden="true" />
          )}
        </button>
      </div>

      <BottomSheet open={filtersOpen} title="Filters" onClose={() => setFiltersOpen(false)}>
        <div className="flex flex-col gap-3">
          {filterControls}
          <form
            onSubmit={(e) => {
              submitSearch(e);
              setFiltersOpen(false);
            }}
            className="flex flex-col gap-2"
          >
            <input
              type="search"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search booking number, name or phone"
              className="w-full rounded-lg border border-ink-200 px-3.5 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              aria-label="Search bookings"
            />
            <Button type="submit" variant="secondary" size="sm">
              Search
            </Button>
          </form>
          <Button variant="secondary" size="sm" onClick={() => setFiltersOpen(false)}>
            Done
          </Button>
        </div>
      </BottomSheet>

      <div className="mt-4 flex flex-wrap gap-2">
        {QUICK_PILLS.map((p) => (
          <button
            key={p.key}
            type="button"
            onClick={() => changeStatus(p.key)}
            className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition ${
              status === p.key
                ? 'border-brand-600 bg-brand-600 text-white'
                : 'border-ink-200 bg-white text-ink-600 hover:bg-ink-50'
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      {canBulk && bulkResult && (
        <section
          aria-label="Bulk action results"
          className={`mt-4 rounded-xl border p-4 ${bulkResult.response.failed > 0 ? 'border-warning-500/40 bg-warning-50' : 'border-success-500/30 bg-success-50'}`}
        >
          <div className="flex flex-wrap items-start justify-between gap-2">
            <p role="status" className="text-sm font-semibold text-ink-900">
              {bulkResult.action === 'cancel' ? 'Cancel' : 'Reopen'} finished: {bulkResult.response.ok} succeeded, {bulkResult.response.failed} failed.
            </p>
            <Button size="sm" variant="secondary" onClick={() => setBulkResult(null)}>
              Dismiss results
            </Button>
          </div>
          <ul className="mt-2 space-y-1 text-sm">
            {bulkResult.response.results.map((r) => (
              <li key={r.id} className={r.success ? 'text-success-700' : 'text-danger-600'}>
                <span className="font-semibold">{r.success ? 'Done' : 'Failed'}</span> · {bulkResult.labels[r.id] ?? `Booking #${r.id}`}: {r.message}
              </li>
            ))}
          </ul>
        </section>
      )}

      {selectedIds.length > 0 && (
        <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl border border-brand-200 bg-brand-50 px-4 py-3">
          <span className="text-sm font-medium text-brand-800">{selectedIds.length} selected</span>
          <select
            value={bulkAction}
            onChange={(e) => setBulkAction(e.target.value)}
            className="rounded-lg border border-ink-200 px-3 py-1.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            aria-label="Bulk action"
          >
            <option value="">Bulk action…</option>
            <option value="verify_payment">✅ Verify Payment</option>
            <option value="cancel">🚫 Cancel</option>
          </select>
          <Button size="sm" variant="secondary" loading={bulkRunning} disabled={!bulkAction} onClick={applyBulkAction}>
            Apply
          </Button>
          <Button size="sm" variant="secondary" loading={exportingSelected} onClick={exportSelected}>
            ⬇️ Export Selected
          </Button>
          {bulkMessage && <span className="text-sm text-ink-600">{bulkMessage}</span>}
        </div>
      )}

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading bookings">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="rounded-xl border border-ink-100 p-4 sm:p-5">
                <div className="flex items-center justify-between">
                  <Skeleton className="h-4 w-40" />
                  <Skeleton className="h-5 w-24 rounded-full" />
                </div>
                <Skeleton className="mt-3 h-3 w-64" />
                <Skeleton className="mt-2 h-3 w-32" />
              </div>
            ))}
          </div>
        )}

        {!loading && error && (
          <ErrorBanner
            message={error}
            onRetry={() => load(status, tripType, vendorId, dateFrom, dateTo, search, page)}
          />
        )}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState title="No bookings found" description="Try adjusting your filters or search." />
        )}

        {!loading && !error && rows && rows.length > 0 && (
          <>
            <div className="mb-2 flex items-center gap-2 text-sm text-ink-500">
              <input
                type="checkbox"
                checked={selectedIds.length === rows.length}
                onChange={() => toggleSelectAll(rows)}
                aria-label="Select all bookings on this page"
                className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
              />
              Select all on this page
            </div>
            <ul className="space-y-3">
              {rows.map((b: AdminBookingRow) => (
                <li key={b.id} className="relative flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={selectedIds.includes(b.id)}
                    onChange={() => toggleRow(b.id)}
                    aria-label={`Select booking ${b.booking_number}`}
                    className="mt-5 h-4 w-4 shrink-0 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
                  />
                  <div className="min-w-0 flex-1">
                  <Link
                    to={`/app/admin/bookings/${b.id}`}
                    className="block rounded-xl border border-ink-100 p-4 shadow-xs transition hover:shadow-sm sm:p-5"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <p className="font-semibold text-ink-900">
                          {b.booking_number}
                          {b.booking_source && b.booking_source !== 'online' && (
                            <span className="ml-2 rounded-full bg-brand-50 px-2 py-0.5 text-xs font-medium text-brand-700">{SOURCE_LABELS[b.booking_source] ?? b.booking_source}</span>
                          )}
                          {!!b.balance_due && b.balance_due > 0 && !['cancelled', 'expired'].includes(b.status) && (
                            <span className="ml-2 text-xs font-medium text-warning-700">Vendor to collect {currency(b.balance_due)}</span>
                          )}
                        </p>
                        <p className="mt-0.5 text-sm text-ink-500">
                          {b.client_name} &middot; {b.client_phone}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {b.payment_status === 'proof_submitted' && (
                          <Button
                            size="sm"
                            variant="secondary"
                            loading={verifyingId === b.id}
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              quickVerify(b.id);
                            }}
                          >
                            ✅ Verify
                          </Button>
                        )}
                        <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${badgeClass(b.status)}`}>
                          {humanize(b.status)}
                        </span>
                      </div>
                    </div>

                    <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-ink-100 pt-3 text-sm text-ink-500">
                      <div>
                        {b.pickup_city} → {b.drop_city} &middot; {humanize(b.trip_type)} &middot; {b.journey_date}
                      </div>
                      <div>
                        Est. fare <span className="font-semibold text-ink-800">{currency(b.total_fare)}</span>
                      </div>
                      <div>{b.vendor_name || 'Unassigned'}</div>
                    </div>
                  </Link>
                  <div className="mt-2">
                    <BookingQuickActions
                      bookingId={b.id}
                      bookingNumber={b.booking_number}
                      status={b.status}
                      paymentStatus={b.payment_status}
                      hasVendor={Boolean(b.vendor_id)}
                      clientPhone={b.client_phone}
                      onDone={() => void load(status, tripType, vendorId, dateFrom, dateTo, search, page)}
                    />
                  </div>
                  </div>
                </li>
              ))}
            </ul>

            <div className="mt-6 flex items-center justify-between">
              <p className="text-sm text-ink-500">
                Page {page} of {Math.max(1, Math.ceil(total / perPage))} &middot; {total} booking{total === 1 ? '' : 's'}
              </p>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" disabled={!canPrev} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                  Previous
                </Button>
                <Button variant="secondary" size="sm" disabled={!canNext} onClick={() => setPage((p) => p + 1)}>
                  Next
                </Button>
              </div>
            </div>
          </>
        )}
      </div>

      {canBulk && selectedIds.length > 0 && (
        <div
          role="region"
          aria-label="Bulk booking actions"
          className="sticky bottom-20 z-30 mt-4 flex flex-wrap items-center gap-2 rounded-xl border border-ink-200 bg-white px-4 py-3 shadow-lg lg:bottom-4"
        >
          <span className="text-sm font-semibold text-ink-900">
            {selectedIds.length} booking{selectedIds.length === 1 ? '' : 's'} selected
          </span>
          <Button size="sm" variant="danger" onClick={() => openBulkDialog('cancel')} disabled={bulkPending}>
            Cancel bookings
          </Button>
          <Button size="sm" variant="secondary" onClick={() => openBulkDialog('reopen')} disabled={bulkPending}>
            Reopen for reassignment
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setSelectedIds([])} disabled={bulkPending}>
            Clear selection
          </Button>
        </div>
      )}

      <ConfirmDialog
        open={canBulk && bulkDialog !== null}
        title={`${bulkDialog === 'cancel' ? 'Cancel' : 'Reopen'} ${selectedIds.length} booking${selectedIds.length === 1 ? '' : 's'}?`}
        description={
          bulkDialog === 'cancel'
            ? 'Each selected booking is cancelled. Bookings that cannot be cancelled are reported as failed below.'
            : 'Each selected booking loses its vendor and is offered to vendors again. Bookings that cannot be reopened are reported as failed below.'
        }
        confirmLabel={bulkDialog === 'cancel' ? 'Cancel bookings' : 'Reopen bookings'}
        confirmVariant={bulkDialog === 'cancel' ? 'danger' : 'primary'}
        loading={bulkPending}
        confirmDisabled={!bulkReason.trim()}
        onConfirm={() => void confirmBulk()}
        onCancel={closeBulkDialog}
      >
        <label htmlFor="bulk-reason" className="mb-1 block text-sm font-medium text-ink-800">
          Reason (required)
        </label>
        <textarea
          id="bulk-reason"
          rows={3}
          value={bulkReason}
          onChange={(e) => setBulkReason(e.target.value)}
          className="w-full rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
        />
      </ConfirmDialog>
    </div>
  );
}
