import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  createAdminPricingVehicle,
  getAdminPricingVehicles,
  toggleAdminPricingVehicle,
  updateAdminPricingVehicle,
  uploadAdminPricingVehicleImage,
  ApiError,
} from '../../lib/api';
import type { AdminPricingVehicleInput, AdminPricingVehicleRow } from '../../types/api';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { EmptyState } from '../../components/ui/EmptyState';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';

const RATE_FIELDS: { key: keyof AdminPricingVehicleInput; label: string; hint?: string }[] = [
  { key: 'base_price_per_km', label: 'Base price / km', hint: 'Base price per km for local and one-way trips' },
  { key: 'base_price_outstation', label: 'Outstation price / km', hint: 'Per km rate for outstation trips' },
  { key: 'minimum_km', label: 'Minimum km', hint: 'Minimum km billed per booking' },
  { key: 'night_charge_pct', label: 'Night charge %', hint: '% extra for trips starting 10pm–6am' },
  { key: 'driver_allowance_day', label: 'Driver allowance / day', hint: 'Per-day allowance for overnight outstation' },
  { key: 'extra_hour_charge', label: 'Extra hour charge', hint: 'Per hour after local package limit' },
  { key: 'airport_base_charge', label: 'Airport base charge', hint: 'Fixed fee for airport pickups/drops' },
  { key: 'local_4hr_40km', label: 'Local 4hr/40km package' },
  { key: 'local_8hr_80km', label: 'Local 8hr/80km package' },
  { key: 'local_extra_km', label: 'Local extra km rate' },
  { key: 'local_extra_hr', label: 'Local extra hour rate' },
];

const EMPTY_FORM: AdminPricingVehicleInput = {
  name: '',
  seating_capacity: 4,
  luggage_capacity: 2,
  ac_available: true,
  base_price_per_km: '',
  base_price_outstation: '',
  minimum_km: '',
  night_charge_pct: '',
  driver_allowance_day: '',
  extra_hour_charge: '',
  airport_base_charge: '',
  local_4hr_40km: '',
  local_8hr_80km: '',
  local_extra_km: '',
  local_extra_hr: '',
  lead_fee_mode: 'fixed',
  lead_fee_fixed: '',
  lead_fee_pct: '',
  is_active: true,
};

function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

export function AdminPricingPage() {
  const [rows, setRows] = useState<AdminPricingVehicleRow[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<AdminPricingVehicleRow | null>(null);
  const [form, setForm] = useState<AdminPricingVehicleInput>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [toggleTarget, setToggleTarget] = useState<AdminPricingVehicleRow | null>(null);
  const [toggling, setToggling] = useState(false);
  const [toggleError, setToggleError] = useState<string | null>(null);

  // "Choose your ride" card image — uploads immediately per vehicle (not tied to the pricing
  // form's save button), same pattern as the branding logo/favicon uploader.
  const [imgBusyId, setImgBusyId] = useState<number | null>(null);
  const [imgErr, setImgErr] = useState<string | null>(null);

  async function uploadImage(id: number, file: File | undefined) {
    if (!file) return;
    setImgBusyId(id);
    setImgErr(null);
    try {
      await uploadAdminPricingVehicleImage(id, file);
      await load();
    } catch (err) {
      setImgErr(err instanceof ApiError ? err.message : 'Could not upload the image. Please try again.');
    } finally {
      setImgBusyId(null);
    }
  }

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getAdminPricingVehicles();
      setRows(res.rows);
    } catch (err) {
      if (err instanceof ApiError && err.code === 'forbidden') {
        setError("You don't have permission to manage pricing.");
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not load pricing. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function openAdd() {
    setEditing(null);
    setForm(EMPTY_FORM);
    setFormError(null);
    setShowForm(true);
  }

  function openEdit(v: AdminPricingVehicleRow) {
    setEditing(v);
    setForm({
      name: v.name,
      seating_capacity: v.seating_capacity,
      luggage_capacity: v.luggage_capacity,
      ac_available: v.ac_available,
      base_price_per_km: v.base_price_per_km,
      base_price_outstation: v.base_price_outstation,
      minimum_km: v.minimum_km,
      night_charge_pct: v.night_charge_pct,
      driver_allowance_day: v.driver_allowance_day,
      extra_hour_charge: v.extra_hour_charge,
      airport_base_charge: v.airport_base_charge,
      local_4hr_40km: v.local_4hr_40km,
      local_8hr_80km: v.local_8hr_80km,
      local_extra_km: v.local_extra_km,
      local_extra_hr: v.local_extra_hr,
      lead_fee_mode: v.lead_fee_mode,
      lead_fee_fixed: v.lead_fee_fixed,
      lead_fee_pct: v.lead_fee_pct,
      is_active: v.is_active,
    });
    setFormError(null);
    setShowForm(true);
  }

  async function submitForm() {
    if (!form.name?.trim()) {
      setFormError('Please provide a vehicle name.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      if (editing) {
        await updateAdminPricingVehicle(editing.id, form);
        setActionMessage(`Pricing saved for ${form.name}.`);
      } else {
        await createAdminPricingVehicle(form);
        setActionMessage(`"${form.name}" added.`);
      }
      setShowForm(false);
      await load();
    } catch (err) {
      setFormError(err instanceof ApiError ? err.message : 'Could not save pricing.');
    } finally {
      setSaving(false);
    }
  }

  async function confirmToggle() {
    if (!toggleTarget) return;
    setToggling(true);
    setToggleError(null);
    try {
      const res = await toggleAdminPricingVehicle(toggleTarget.id);
      setActionMessage(res.message);
      setToggleTarget(null);
      await load();
    } catch (err) {
      setToggleError(err instanceof ApiError ? err.message : 'Could not change vehicle status.');
    } finally {
      setToggling(false);
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Vehicle pricing</h1>
          <p className="text-sm text-ink-500">
            Base fare rates by vehicle type. These feed every live customer fare quote — changes take effect
            immediately.
          </p>
          <Link to="/admin/surge" className="mt-2 inline-block text-sm font-medium text-brand-700 hover:text-brand-800">
            Manage surge pricing →
          </Link>
        </div>
        <Button onClick={openAdd}>Add vehicle type</Button>
      </div>

      {actionMessage && !loading && (
        <div role="status" className="mt-4 rounded-lg border border-success-500/30 bg-success-50 px-3.5 py-2.5 text-sm text-success-700">
          {actionMessage}
        </div>
      )}

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading pricing">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full rounded-xl" />
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={load} />}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState title="No vehicle types yet" description="Add a vehicle type to start quoting fares." />
        )}

        {imgErr && <ErrorBanner message={imgErr} onRetry={() => setImgErr(null)} />}

        {!loading && !error && rows && rows.length > 0 && (
          <ul className="space-y-3">
            {rows.map((v) => (
              <li key={v.id} className="rounded-xl border border-ink-100 p-4 shadow-xs sm:p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex gap-3">
                    <div className="flex h-14 w-16 shrink-0 items-center justify-center rounded-lg bg-ink-50">
                      {v.icon_url ? (
                        <img src={v.icon_url} alt={`${v.name} card image`} className="h-full w-full object-contain p-1" />
                      ) : (
                        <span className="text-xs text-ink-400">No image</span>
                      )}
                    </div>
                    <div>
                      <p className="font-semibold text-ink-900">
                        {v.name}
                        {!v.is_active && (
                          <span className="ml-2 rounded-full bg-ink-100 px-2 py-0.5 text-xs font-semibold text-ink-500">
                            Inactive
                          </span>
                        )}
                      </p>
                      <p className="mt-0.5 text-sm text-ink-500">
                        {v.seating_capacity} seats &middot; {v.luggage_capacity} luggage &middot; {v.ac_available ? 'AC' : 'Non-AC'}
                      </p>
                      <p className="mt-1 text-xs text-ink-400">
                        {currency(v.base_price_per_km)}/km &middot; min {v.minimum_km} km &middot; night +{v.night_charge_pct}%
                      </p>
                      <label className="mt-2 inline-flex cursor-pointer items-center text-xs font-semibold text-brand-700 hover:text-brand-800">
                        {imgBusyId === v.id ? 'Uploading…' : v.icon_url ? 'Change card image' : 'Add card image'}
                        <input
                          type="file"
                          accept="image/png,image/jpeg,image/webp"
                          className="hidden"
                          disabled={imgBusyId === v.id}
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            e.target.value = '';
                            void uploadImage(v.id, file);
                          }}
                        />
                      </label>
                    </div>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <Button variant="secondary" size="sm" onClick={() => openEdit(v)}>
                      Edit pricing
                    </Button>
                    <Button
                      variant={v.is_active ? 'danger' : 'secondary'}
                      size="sm"
                      onClick={() => {
                        setToggleTarget(v);
                        setToggleError(null);
                      }}
                    >
                      {v.is_active ? 'Deactivate' : 'Activate'}
                    </Button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <ConfirmDialog
        open={showForm}
        title={editing ? `Edit pricing — ${editing.name}` : 'Add vehicle type'}
        confirmLabel={editing ? 'Save pricing' : 'Create vehicle type'}
        confirmVariant="primary"
        loading={saving}
        onConfirm={submitForm}
        onCancel={() => {
          if (saving) return;
          setShowForm(false);
        }}
      >
        <div className="max-h-[60vh] space-y-3 overflow-y-auto pr-1">
          {formError && (
            <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
              {formError}
            </div>
          )}
          <div>
            <label htmlFor="pv-name" className="block text-sm font-medium text-ink-700">
              Vehicle name
            </label>
            <input
              id="pv-name"
              type="text"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor="pv-seats" className="block text-sm font-medium text-ink-700">
                Seating capacity
              </label>
              <input
                id="pv-seats"
                type="number"
                min={1}
                value={form.seating_capacity}
                onChange={(e) => setForm((f) => ({ ...f, seating_capacity: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="pv-luggage" className="block text-sm font-medium text-ink-700">
                Luggage capacity
              </label>
              <input
                id="pv-luggage"
                type="number"
                min={0}
                value={form.luggage_capacity}
                onChange={(e) => setForm((f) => ({ ...f, luggage_capacity: e.target.value }))}
                className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={!!form.ac_available}
              onChange={(e) => setForm((f) => ({ ...f, ac_available: e.target.checked }))}
              className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
            />
            AC available
          </label>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 border-t border-ink-100 pt-3">
            {RATE_FIELDS.map((f) => (
              <div key={f.key}>
                <label htmlFor={`pv-${f.key}`} className="block text-xs font-medium text-ink-600">
                  {f.label}
                </label>
                <input
                  id={`pv-${f.key}`}
                  type="text"
                  inputMode="decimal"
                  value={form[f.key] as string | number}
                  onChange={(e) => setForm((prev) => ({ ...prev, [f.key]: e.target.value }))}
                  className="mt-1 w-full rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                />
                {f.hint && <p className="mt-1 text-xs text-ink-400">{f.hint}</p>}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 border-t border-ink-100 pt-3">
            <div>
              <label htmlFor="pv-lead-mode" className="block text-xs font-medium text-ink-600">
                Lead fee mode
              </label>
              <select
                id="pv-lead-mode"
                value={form.lead_fee_mode}
                onChange={(e) => setForm((f) => ({ ...f, lead_fee_mode: e.target.value }))}
                className="mt-1 w-full rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              >
                <option value="fixed">Fixed</option>
                <option value="percent">Percent</option>
              </select>
            </div>
            <div>
              <label htmlFor="pv-lead-fixed" className="block text-xs font-medium text-ink-600">
                Lead fee (fixed)
              </label>
              <input
                id="pv-lead-fixed"
                type="text"
                inputMode="decimal"
                value={form.lead_fee_fixed}
                onChange={(e) => setForm((f) => ({ ...f, lead_fee_fixed: e.target.value }))}
                className="mt-1 w-full rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
            <div>
              <label htmlFor="pv-lead-pct" className="block text-xs font-medium text-ink-600">
                Lead fee %
              </label>
              <input
                id="pv-lead-pct"
                type="text"
                inputMode="decimal"
                value={form.lead_fee_pct}
                onChange={(e) => setForm((f) => ({ ...f, lead_fee_pct: e.target.value }))}
                className="mt-1 w-full rounded-lg border border-ink-200 px-3 py-2 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              />
            </div>
          </div>

          <label className="flex items-center gap-2 border-t border-ink-100 pt-3 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={form.is_active !== false}
              onChange={(e) => setForm((f) => ({ ...f, is_active: e.target.checked }))}
              className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-brand-500/30"
            />
            Active (listed for customer booking)
          </label>
        </div>
      </ConfirmDialog>

      <ConfirmDialog
        open={!!toggleTarget}
        title={toggleTarget?.is_active ? `Deactivate ${toggleTarget?.name}?` : `Activate ${toggleTarget?.name}?`}
        description={
          toggleTarget?.is_active
            ? 'This hides the vehicle type from customer search and new quotes.'
            : 'This makes the vehicle type available again for customer search and quotes.'
        }
        confirmLabel={toggleTarget?.is_active ? 'Deactivate' : 'Activate'}
        confirmVariant={toggleTarget?.is_active ? 'danger' : 'primary'}
        loading={toggling}
        onConfirm={confirmToggle}
        onCancel={() => {
          if (toggling) return;
          setToggleTarget(null);
          setToggleError(null);
        }}
      >
        {toggleError && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {toggleError}
          </div>
        )}
      </ConfirmDialog>
    </div>
  );
}
