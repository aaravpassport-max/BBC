import { useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { ApiError, getCities } from '../lib/api';
import type { City } from '../types/api';
import { SHOWCASE_CARD_CLASS } from '../components/ui/Zone';

const inputClasses =
  'mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30';
const labelClasses = 'block text-sm font-medium text-ink-700';

export function VendorRegisterPage() {
  const { user, isLoggedIn, isVendor, register } = useAuth();
  const navigate = useNavigate();

  const [businessName, setBusinessName] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [city, setCity] = useState('');
  const [cities, setCities] = useState<City[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    getCities()
      .then((res) => {
        if (!cancelled) setCities(res);
      })
      .catch(() => {
        // Non-fatal: the city field falls back to free text entry below.
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (isLoggedIn && isVendor) {
    navigate('/vendor/dashboard', { replace: true });
  }

  // Gap: there is no dedicated "register an existing logged-in customer
  // account as a vendor" endpoint in includes/app-api.php — only
  // POST /app/auth/register (with as_vendor) for a brand-new account. A
  // customer who is already logged in has no in-app way to add a vendor
  // profile to their existing account, so we surface that clearly instead
  // of faking success.
  if (isLoggedIn && !isVendor) {
    return (
      <div className="mx-auto flex min-h-[calc(100vh-64px)] max-w-md flex-col justify-center px-4 py-12">
        <div className={`p-8 ${SHOWCASE_CARD_CLASS}`}>
          <h1 className="text-xl font-bold text-ink-900">Become a driver-partner</h1>
          <p className="mt-3 text-sm text-ink-600">
            You're signed in as <span className="font-semibold">{user?.name}</span>, but there's currently no way
            to add a vendor profile to an existing account from the app. Please contact support to have a vendor
            profile added, or register a separate account below.
          </p>
        </div>
      </div>
    );
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (!businessName.trim()) {
      setError('Please enter your business or fleet name.');
      return;
    }
    if (password.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }
    if (!city.trim()) {
      setError('Please tell us which city you operate in.');
      return;
    }
    setSubmitting(true);
    try {
      // The register API has no separate business-name field; we fold it
      // into the display name so it's captured somewhere visible to the
      // vendor admin flow, matching how RegisterPage already uses
      // as_vendor for the "I'm a driver / vendor" checkbox.
      await register({
        name: `${businessName.trim()} (${name.trim()})`,
        email,
        phone,
        password,
        as_vendor: true,
        city: city.trim(),
      });
      navigate('/vendor/dashboard', { replace: true });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-md flex-col justify-center px-4 py-12">
      <div className={`p-8 ${SHOWCASE_CARD_CLASS}`}>
        <h1 className="text-2xl font-bold text-ink-900">Become a driver-partner</h1>
        <p className="mt-1 text-sm text-ink-500">Register your fleet or vehicle to start receiving ride leads.</p>

        <form className="mt-6 space-y-4" onSubmit={handleSubmit} noValidate>
          {error && (
            <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
              {error}
            </div>
          )}

          <div>
            <label htmlFor="business-name" className={labelClasses}>
              Business / fleet name
            </label>
            <input
              id="business-name"
              required
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              className={inputClasses}
            />
          </div>

          <div>
            <label htmlFor="vendor-name" className={labelClasses}>
              Your full name
            </label>
            <input id="vendor-name" required value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" className={inputClasses} />
          </div>

          <div>
            <label htmlFor="vendor-email" className={labelClasses}>
              Email
            </label>
            <input
              id="vendor-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              className={inputClasses}
            />
          </div>

          <div>
            <label htmlFor="vendor-phone" className={labelClasses}>
              Phone number
            </label>
            <input
              id="vendor-phone"
              type="tel"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              autoComplete="tel"
              className={inputClasses}
            />
          </div>

          <div>
            <label htmlFor="vendor-city" className={labelClasses}>
              City you operate in
            </label>
            {cities.length > 0 ? (
              <select
                id="vendor-city"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className={inputClasses}
              >
                <option value="">Select a city</option>
                {cities.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            ) : (
              <input
                id="vendor-city"
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="e.g. Bengaluru"
                className={inputClasses}
              />
            )}
          </div>

          <div>
            <label htmlFor="vendor-password" className={labelClasses}>
              Password
            </label>
            <input
              id="vendor-password"
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="new-password"
              className={inputClasses}
            />
            <p className="mt-1 text-xs text-ink-400">At least 8 characters.</p>
          </div>

          <Button type="submit" fullWidth loading={submitting} size="lg">
            Register as a vendor
          </Button>
        </form>

        <p className="mt-6 text-center text-sm text-ink-500">
          Already have a vendor account?{' '}
          <Link to="/login" className="font-semibold text-brand-600 hover:text-brand-700">
            Log in
          </Link>
        </p>
      </div>
    </div>
  );
}
