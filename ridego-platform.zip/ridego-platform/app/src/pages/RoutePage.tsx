import { useEffect, useState, type ReactElement } from 'react';
import { Link, useParams } from 'react-router-dom';
import { getPublicRoutePage, getCities, getVehicles, ApiError } from '../lib/api';
import type { RoutePageContent, City, Vehicle } from '../types/api';
import { Skeleton, SkeletonText } from '../components/ui/Skeleton';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Button } from '../components/ui/Button';
import { brand, fitClass } from '../lib/brand';
import { FareSearchWidget } from '../components/home/FareSearchWidget';
import { BookingPage } from './BookingPage';
import { MobileBottomNav } from '../components/layout/MobileBottomNav';
import { Header } from '../components/layout/Header';
import { Footer } from '../components/layout/Footer';

/* -----------------------------------------------------------------
 * Small decorative icons. All generic UI iconography (no claim about
 * a specific real vehicle/place photo) — used to give the page visual
 * structure without inventing any imagery presented as photographic fact.
 * --------------------------------------------------------------- */

function IconWrap({ children, tone = 'brand' }: { children: ReactElement; tone?: 'brand' | 'emerald' | 'violet' | 'accent' }) {
  const tones: Record<string, string> = {
    brand: 'bg-brand-50 text-brand-600',
    emerald: 'bg-emerald-50 text-emerald-600',
    violet: 'bg-violet-50 text-violet-600',
    accent: 'bg-accent-50 text-accent-600',
  };
  return (
    <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${tones[tone]}`}>
      {children}
    </span>
  );
}

function ArrowRightIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M5 12h14m0 0l-6-6m6 6l-6 6" />
    </svg>
  );
}
function CheckBadgeIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className="h-5 w-5" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  );
}
function MapPinIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className={className} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 21s-6.5-5.7-6.5-11a6.5 6.5 0 0113 0c0 5.3-6.5 11-6.5 11z" />
      <circle cx="12" cy="10" r="2.2" />
    </svg>
  );
}
function RulerIcon({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className={className} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 15l5-5m-1 6l1-1m3-3l1-1m3-3l1-1M3 17l4 4L21 7l-4-4L3 17z" />
    </svg>
  );
}
function ClockIcon({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className={className} aria-hidden="true">
      <circle cx="12" cy="12" r="9" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 7v5l3.5 2" />
    </svg>
  );
}
function MountainIcon({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className={className} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 19l6.5-10L14 15l2.5-3.5L21 19H3z" />
      <circle cx="7.5" cy="7" r="1.6" />
    </svg>
  );
}
function CarStatIcon({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className={className} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M5 11l1.5-4.5A2 2 0 018.4 5h7.2a2 2 0 011.9 1.5L19 11m-14 0h14m-14 0a1.5 1.5 0 00-1.5 1.5V16a1 1 0 001 1h1a1 1 0 001-1v-1h11v1a1 1 0 001 1h1a1 1 0 001-1v-3.5A1.5 1.5 0 0019 11" />
    </svg>
  );
}
function ShieldIcon({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className={className} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3z" />
    </svg>
  );
}
function PlaneIcon({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className={className} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 3.5l3 3-5.5 2 2.5 2.5-2 .5-2-1.5-1.5.5 1 1.8-.9.9-3-1.8V9.5l1-1 3 .5 2-5.5z" />
      <path strokeLinecap="round" d="M4 20h16" />
    </svg>
  );
}
function SuitcaseIcon({ className = 'h-6 w-6' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className={className} aria-hidden="true">
      <rect x="3" y="7" width="18" height="13" rx="2" />
      <path strokeLinecap="round" d="M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2M3 12h18" />
    </svg>
  );
}
function ChevronDownIcon({ className = 'h-5 w-5' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 9l6 6 6-6" />
    </svg>
  );
}
function ChevronRightIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 6l6 6-6 6" />
    </svg>
  );
}
function PhoneIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className={className} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 5c0-.6.4-1 1-1h3l2 5-2 1.5a11 11 0 005 5L14 14l5 2v3c0 .6-.4 1-1 1C9.4 20 4 14.6 4 6V5z" />
    </svg>
  );
}
function ArrowUpRightIcon({ className = 'h-4 w-4' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={className} aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M7 17L17 7M9 7h8v8" />
    </svg>
  );
}

const WHY_TONES: ('brand' | 'emerald' | 'violet' | 'accent')[] = ['brand', 'emerald', 'violet', 'accent'];
const WHY_ICONS: ReactElement[] = [<MountainIcon />, <ShieldIcon />, <PlaneIcon />, <CheckBadgeIcon />];

const SERVICE_TONES: ('emerald' | 'violet' | 'brand' | 'accent')[] = ['emerald', 'violet', 'brand', 'accent'];
const SERVICE_ICON_FOR_KEY: Record<string, ReactElement> = {
  one_way: <CarStatIcon />,
  round_trip: <ArrowRightIcon className="h-5 w-5" />,
  airport_transfer: <PlaneIcon />,
  local: <SuitcaseIcon className="h-5 w-5" />,
};

/* Vehicle silhouettes — generic per-category icon (decorative UI iconography,
 * not a claim about a specific real vehicle photo). Chosen by matching the
 * vehicle's real name; falls back to a plain sedan-style silhouette. */
function vehicleIcon(name: string) {
  const n = name.toLowerCase();
  if (n.includes('tempo') || n.includes('traveller') || n.includes('van') || n.includes('bus')) {
    return (
      <svg viewBox="0 0 64 40" className="h-16 w-28" aria-hidden="true">
        <rect x="3" y="10" width="52" height="18" rx="4" fill="currentColor" opacity="0.15" />
        <path d="M3 24V14a4 4 0 014-4h40a4 4 0 014 4v10" stroke="currentColor" strokeWidth="2" fill="none" />
        <rect x="10" y="13" width="8" height="7" rx="1" fill="currentColor" opacity="0.4" />
        <rect x="21" y="13" width="8" height="7" rx="1" fill="currentColor" opacity="0.4" />
        <rect x="32" y="13" width="8" height="7" rx="1" fill="currentColor" opacity="0.4" />
        <circle cx="14" cy="29" r="4" fill="currentColor" />
        <circle cx="44" cy="29" r="4" fill="currentColor" />
      </svg>
    );
  }
  if (n.includes('innova') || n.includes('suv') || n.includes('crysta') || n.includes('ertiga') || n.includes('xylo')) {
    return (
      <svg viewBox="0 0 64 40" className="h-16 w-28" aria-hidden="true">
        <path d="M5 26c0-3 2-9 7-11 3-6 10-8 18-8s14 2 17 8c4 1 8 4 8 11" stroke="currentColor" strokeWidth="2" fill="currentColor" fillOpacity="0.15" />
        <path d="M10 15l3-6c2-2 6-3 10-3" stroke="currentColor" strokeWidth="2" fill="none" />
        <rect x="14" y="14" width="10" height="8" rx="1" fill="currentColor" opacity="0.4" />
        <rect x="26" y="14" width="10" height="8" rx="1" fill="currentColor" opacity="0.4" />
        <rect x="38" y="14" width="9" height="8" rx="1" fill="currentColor" opacity="0.4" />
        <circle cx="17" cy="28" r="4.5" fill="currentColor" />
        <circle cx="45" cy="28" r="4.5" fill="currentColor" />
      </svg>
    );
  }
  if (n.includes('luxury')) {
    return (
      <svg viewBox="0 0 64 40" className="h-16 w-28" aria-hidden="true">
        <path d="M4 25c0-3 2-6 6-7 2-5 8-9 15-9s12 3 15 6c5 1 10 4 10 10" stroke="currentColor" strokeWidth="2" fill="currentColor" fillOpacity="0.22" />
        <rect x="14" y="12" width="10" height="8" rx="1" fill="currentColor" opacity="0.55" />
        <rect x="26" y="12" width="9" height="8" rx="1" fill="currentColor" opacity="0.55" />
        <rect x="37" y="14" width="9" height="7" rx="1" fill="currentColor" opacity="0.55" />
        <circle cx="16" cy="27" r="4.5" fill="currentColor" />
        <circle cx="44" cy="27" r="4.5" fill="currentColor" />
      </svg>
    );
  }
  if (n.includes('hatch') || n.includes('wagonr') || n.includes('swift') || n.includes('alto')) {
    return (
      <svg viewBox="0 0 64 40" className="h-16 w-28" aria-hidden="true">
        <path d="M8 26c-1-4 1-9 6-11 2-4 7-6 12-6s9 2 11 6c4 1 8 5 8 11" stroke="currentColor" strokeWidth="2" fill="currentColor" fillOpacity="0.15" />
        <rect x="16" y="13" width="11" height="8" rx="1" fill="currentColor" opacity="0.4" />
        <rect x="29" y="13" width="10" height="8" rx="1" fill="currentColor" opacity="0.4" />
        <circle cx="18" cy="28" r="4.5" fill="currentColor" />
        <circle cx="42" cy="28" r="4.5" fill="currentColor" />
      </svg>
    );
  }
  // Sedan — default silhouette.
  return (
    <svg viewBox="0 0 64 40" className="h-16 w-28" aria-hidden="true">
      <path d="M4 25c0-3 2-6 6-7 2-5 8-9 15-9s12 3 15 6c5 1 10 4 10 10" stroke="currentColor" strokeWidth="2" fill="currentColor" fillOpacity="0.15" />
      <rect x="14" y="12" width="10" height="8" rx="1" fill="currentColor" opacity="0.4" />
      <rect x="26" y="12" width="9" height="8" rx="1" fill="currentColor" opacity="0.4" />
      <rect x="37" y="14" width="9" height="7" rx="1" fill="currentColor" opacity="0.4" />
      <circle cx="16" cy="27" r="4.5" fill="currentColor" />
      <circle cx="44" cy="27" r="4.5" fill="currentColor" />
    </svg>
  );
}

export function RoutePage() {
  const { slug } = useParams<{ slug: string }>();
  const [content, setContent] = useState<RoutePageContent | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Real cities/vehicles for the embedded booking form — the same lists
  // HomePage's FareSearchWidget uses; fetched independently so this page
  // works standalone. Best-effort: if these fail, the rest of the page
  // (which doesn't depend on them) still renders.
  const [cities, setCities] = useState<City[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  // Which real fare field ('one_way' vs 'round_trip') the vehicle grid
  // displays — a display toggle over the same already-fetched data, not a
  // new data source.
  const [fareView, setFareView] = useState<'one_way' | 'round_trip'>('one_way');
  // "Book this route" / vehicle-card CTA opens the real booking form in
  // place (no navigation) — see Task 2. null = closed; a vehicleId means a
  // specific vehicle card's CTA was clicked and that vehicle is pre-selected.
  const [bookingOpen, setBookingOpen] = useState<{ vehicleId?: number } | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      if (!slug) return;
      setLoading(true);
      setError(null);
      setNotFound(false);
      try {
        const res = await getPublicRoutePage(slug);
        if (!cancelled) setContent(res);
      } catch (err) {
        if (cancelled) return;
        if (err instanceof ApiError && err.status === 404) {
          setNotFound(true);
        } else {
          setError(err instanceof ApiError ? err.message : 'Could not load this page. Please try again.');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    Promise.all([getCities(), getVehicles()])
      .then(([c, v]) => {
        if (!cancelled) {
          setCities(c);
          setVehicles(v);
        }
      })
      .catch(() => {
        // Best-effort — the booking form simply falls back to empty
        // dropdowns if this fails; it never blocks the page itself.
      });
    return () => {
      cancelled = true;
    };
  }, [slug]);

  useEffect(() => {
    if (!content) return;
    const prevTitle = document.title;
    if (content.seo_title) document.title = content.seo_title;
    let metaTag = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    let created = false;
    if (content.meta_description) {
      if (!metaTag) {
        metaTag = document.createElement('meta');
        metaTag.name = 'description';
        document.head.appendChild(metaTag);
        created = true;
      }
      const prevContent = metaTag.content;
      metaTag.content = content.meta_description;
      return () => {
        document.title = prevTitle;
        if (metaTag) {
          if (created) {
            metaTag.remove();
          } else {
            metaTag.content = prevContent;
          }
        }
      };
    }
    return () => {
      document.title = prevTitle;
    };
  }, [content]);

  // Preload the hero image the browser will actually paint first (the
  // page's LCP element), for both hero variants: the CSS background-image
  // hero (this doesn't get an <img> for the browser to discover early) and
  // the image-hero mode's own <img> (already loading="eager" +
  // fetchPriority="high" below, but a <link rel="preload"> lets the
  // browser start the request before it has even parsed that far into the
  // DOM). No fake/derived URL is used — it's the same real, already-stored
  // URL the page renders.
  useEffect(() => {
    if (!content) return;
    const hero = content.hero;
    const heroSrc =
      hero.mode === 'image'
        ? hero.image_desktop_url || hero.image_mobile_url
        : content.to_city_image_url || content.from_city_image_url;
    if (!heroSrc) return;
    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'image';
    link.href = heroSrc;
    document.head.appendChild(link);
    return () => {
      link.remove();
    };
  }, [content]);

  if (loading) {
    return (
      <>
        <Header />
        <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
          <Skeleton className="mb-4 h-10 w-2/3 rounded-lg" />
          <Skeleton className="mb-8 h-5 w-1/3 rounded-lg" />
          <SkeletonText lines={4} />
        </div>
        <Footer />
      </>
    );
  }

  if (notFound) {
    return (
      <>
        <Header />
        <div className="mx-auto max-w-2xl px-4 py-20 text-center sm:px-6 lg:px-8">
          <h1 className="text-2xl font-bold text-ink-900">Page not found</h1>
          <p className="mt-2 text-sm text-ink-500">
            This route page doesn&rsquo;t exist or isn&rsquo;t published yet.
          </p>
          <Link to="/" className="mt-6 inline-block">
            <Button>Go to {brand().name}</Button>
          </Link>
        </div>
        <Footer />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Header />
        <div className="mx-auto max-w-2xl px-4 py-12 sm:px-6 lg:px-8">
          <ErrorBanner message={error} />
        </div>
        <Footer />
      </>
    );
  }

  if (!content) return null;

  // Real photo only — never a stock/placeholder fallback. Prefer the
  // destination's photo (what the mockup calls the hero backdrop), then
  // the origin's, and fall back to a plain brand-color gradient when
  // neither city has one uploaded.
  const heroImage = content.to_city_image_url || content.from_city_image_url;
  const roadStripImage = content.to_city_image_url || content.from_city_image_url;
  const b = brand();

  const fromAirportPoint = content.pickup_points.find((p) => !p.label.endsWith('(city)'));
  const toAirportPoint = content.drop_points.find((p) => !p.label.endsWith('(city)'));
  const hasAirport = Boolean(fromAirportPoint || toAirportPoint);
  const hasBothTripTypes = content.services.some((s) => s.key === 'one_way') && content.services.some((s) => s.key === 'round_trip');
  const vehicleTypeNames = Array.from(new Set(content.vehicles.map((v) => v.name.split(' ')[0])));
  const isMultiVehicleClass = vehicleTypeNames.length > 1 || content.vehicles.length > 1;

  // Section-3 trust band: 4 always-real items, a 5th only when this route
  // actually touches a real airport.
  const trustItems: { icon: ReactElement; tone: 'brand' | 'emerald' | 'violet' | 'accent'; title: string; sub: string }[] = [
    { icon: <CarStatIcon />, tone: 'brand', title: 'Multiple vehicle options', sub: isMultiVehicleClass ? 'From hatchback to luxury' : `${content.vehicles.length} option${content.vehicles.length === 1 ? '' : 's'} available` },
  ];
  if (hasBothTripTypes) {
    trustItems.push({ icon: <ArrowRightIcon />, tone: 'emerald', title: 'One-way & round-trip', sub: 'Both options available' });
  }
  trustItems.push({ icon: <ShieldIcon />, tone: 'violet', title: 'Verified & experienced drivers', sub: 'Safe and comfortable travel' });
  trustItems.push({ icon: <RulerIcon />, tone: 'accent', title: 'Transparent pricing', sub: 'No hidden charges' });
  if (hasAirport) {
    trustItems.push({ icon: <PlaneIcon />, tone: 'brand', title: 'Airport pickup & drop', sub: 'Available on this route' });
  }

  const hero = content.hero;
  const isImageHero = hero.mode === 'image';
  // Image mode always has SOME image to show — the desktop one doubles as the
  // mobile fallback when no mobile-specific image was uploaded (see spec).
  const heroDesktopImage = isImageHero ? hero.image_desktop_url : '';
  const heroMobileImage = isImageHero ? (hero.image_mobile_url || hero.image_desktop_url) : '';
  const showImageHero = isImageHero && (heroDesktopImage || heroMobileImage);

  return (
    <>
      <Header />
      <div className="pb-[calc(4rem+env(safe-area-inset-bottom,0px))] lg:pb-16">
      {/* ============ 1. Hero ============
          'image' mode: an admin-uploaded photo only, full-bleed, at the
          admin-configured height per breakpoint — no heading/subheading/
          background-color unless the overlay checkbox is on. Independent
          desktop/mobile <img> elements (hidden md:block / md:hidden) so each
          breakpoint's height and image are genuinely independent, with no
          duplicate layer and no layout shift (heights fixed via inline style
          on both, so nothing collapses while an image is loading).
          'standard' mode (default, and the fallback when image mode has no
          image configured yet): the original real-city-photo-backdrop hero,
          driven by the resolved hero heading/subheading instead of
          hardcoded copy. */}
      {showImageHero ? (
        <section className="relative overflow-hidden bg-ink-900">
          {/* This is the page's LCP element in image-hero mode, so it must
              never be lazy-loaded and should be prioritized over every other
              request on the page. Note: no srcset/sizes here — uploads go
              through wp_handle_upload() directly (see
              includes/app-admin-route-pages-api.php), never
              wp_insert_attachment()/add_image_size(), so no smaller,
              real, non-404ing size variant of this file exists on disk to
              reference. Fixing that needs a backend image-size pipeline. */}
          <img
            src={heroDesktopImage || heroMobileImage}
            alt=""
            loading="eager"
            fetchPriority="high"
            decoding="async"
            className="hidden w-full object-fill md:block"
            style={{ height: hero.height_desktop_px }}
          />
          <img
            src={heroMobileImage || heroDesktopImage}
            alt=""
            loading="eager"
            fetchPriority="high"
            decoding="async"
            className="block w-full object-fill md:hidden"
            style={{ height: hero.height_mobile_px }}
          />
          {/* Exactly one <h1> must always be in the DOM regardless of the
              overlay setting — previously this whole block (including the
              only <h1> on the page) was skipped when overlay_enabled was
              false, leaving the page with zero H1s. When the overlay is on,
              it renders visibly as before; when it's off, the same real
              heading text is still present (visually hidden, not
              display:none, so it stays in the accessibility tree) so the
              page always has a real, meaningful H1 without changing the
              intended look of the image-hero-without-overlay design. */}
          {hero.overlay_enabled && (hero.heading || hero.subheading) ? (
            <div
              className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-b from-ink-950/40 via-ink-950/20 to-ink-950/55 px-4 text-center text-white"
              style={hero.bg_color ? { backgroundColor: `${hero.bg_color}66` } : undefined}
            >
              {hero.heading && <h1 className="text-3xl font-extrabold leading-tight sm:text-4xl lg:text-[2.6rem]">{hero.heading}</h1>}
              {hero.subheading && <p className="mx-auto mt-3 max-w-xl text-sm font-medium text-white/85 sm:text-base">{hero.subheading}</p>}
            </div>
          ) : (
            <h1 className="sr-only">
              {hero.heading || `${content.from_city} to ${content.to_city} Cab & Taxi`}
            </h1>
          )}
        </section>
      ) : (
        <section
          className="relative overflow-hidden bg-gradient-to-br from-ink-900 via-ink-800 to-brand-900 px-4 pb-28 pt-8 sm:px-6 lg:px-8"
          style={
            heroImage
              ? { backgroundImage: `linear-gradient(180deg, rgba(16,18,22,0.55) 0%, rgba(16,18,22,0.35) 45%, rgba(16,18,22,0.75) 100%), url(${heroImage})`, backgroundSize: 'cover', backgroundPosition: 'center' }
              : hero.bg_color
                ? { backgroundColor: hero.bg_color, backgroundImage: 'none' }
                : undefined
          }
        >
          <div className="mx-auto max-w-6xl">
            <p className="flex items-center gap-1.5 text-xs font-medium text-white/70">
              <MapPinIcon className="h-3.5 w-3.5" />
              <Link to="/" className="hover:text-white">
                {b.name}
              </Link>
              <ChevronRightIcon className="h-3 w-3 text-white/40" />
              <Link to="/routes" className="hover:text-white">
                Routes
              </Link>
              <ChevronRightIcon className="h-3 w-3 text-white/40" />
              <span className="text-white">
                {content.from_city} to {content.to_city}
              </span>
            </p>

            <div className="mt-8 flex justify-end">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-ink-900/70 px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm ring-1 ring-white/10 backdrop-blur">
                <MountainIcon className="h-3.5 w-3.5" /> Best route for a perfect getaway
              </span>
            </div>

            <div className="mt-4 text-center text-white sm:mt-2">
              <h1 className="text-3xl font-extrabold leading-tight sm:text-4xl lg:text-[2.6rem]">
                {hero.heading || (
                  <>
                    {content.from_city} to {content.to_city}
                    <br />
                    Cab &amp; Taxi
                  </>
                )}
              </h1>
              <p className="mx-auto mt-3 max-w-xl text-sm font-medium text-white/85 sm:text-base">
                {hero.subheading || `A comfortable journey from ${content.from_city} to ${content.to_city}`}
              </p>

              <div className="mx-auto mt-7 flex max-w-3xl flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm text-white">
                <span className="inline-flex items-center gap-2">
                  <MapPinIcon className="h-4 w-4" />
                  <span>
                    <span className="block font-bold leading-none">{content.distance_km} km</span>
                    <span className="block text-[11px] font-normal text-white/70">Distance</span>
                  </span>
                </span>
                <span className="inline-flex items-center gap-2">
                  <ClockIcon className="h-4 w-4" />
                  <span>
                    <span className="block font-bold leading-none">
                      {content.journey.typical_minutes_low}&ndash;{content.journey.typical_minutes_high} min
                    </span>
                    <span className="block text-[11px] font-normal text-white/70">Typical time</span>
                  </span>
                </span>
                <span className="inline-flex items-center gap-2">
                  <CarStatIcon className="h-4 w-4" />
                  <span>
                    <span className="block font-bold leading-none">{content.vehicles.length}</span>
                    <span className="block text-[11px] font-normal text-white/70">Vehicle options</span>
                  </span>
                </span>
                <span className="inline-flex items-center gap-2">
                  <ShieldIcon className="h-4 w-4" />
                  <span>
                    <span className="block font-bold leading-none">Verified drivers</span>
                    <span className="block text-[11px] font-normal text-white/70">On every trip</span>
                  </span>
                </span>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ============ Floating white search card, overlapping the hero ============ */}
      <div className="relative z-10 mx-auto -mt-16 px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-5xl rounded-2xl bg-white p-5 shadow-xl ring-1 ring-black/5 sm:p-6">
          <FareSearchWidget
            cities={cities}
            vehicles={vehicles}
            initialPickup={content.from_city}
            initialDrop={content.to_city}
            embedded
            layout="inline"
            onSubmitOverride={() => setBookingOpen({})}
          />
        </div>
      </div>

      {/* ============ Trust band ============ */}
      <section className="mt-10 bg-ink-50/60 px-4 py-8 sm:px-6 lg:px-8">
        <div className="mx-auto grid max-w-6xl grid-cols-2 gap-6 sm:grid-cols-3 lg:flex lg:flex-wrap lg:items-start lg:justify-between">
          {trustItems.map((t, i) => (
            <div key={i} className="flex items-start gap-3">
              <IconWrap tone={t.tone}>{t.icon}</IconWrap>
              <div className="min-w-0">
                <p className="text-sm font-semibold leading-snug text-ink-900">{t.title}</p>
                <p className="text-xs text-ink-500">{t.sub}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <div className="mx-auto max-w-6xl px-4 pt-14 sm:px-6 lg:px-8">
        {/* ============ Available services on this route — real service list,
            restyled as 4 pill cards; never padded with invented services. ============ */}
        {content.services.length > 0 && (
          <section>
            <h2 className="text-xl font-bold text-ink-900 sm:text-2xl">Available services on this route</h2>
            <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {content.services.map((s, i) => (
                <div key={s.key} className="rounded-2xl border border-ink-100 bg-white p-4 shadow-xs">
                  <IconWrap tone={SERVICE_TONES[i % SERVICE_TONES.length]}>{SERVICE_ICON_FOR_KEY[s.key] ?? <CarStatIcon />}</IconWrap>
                  <p className="mt-3 text-sm font-bold text-ink-900">{s.label}</p>
                  <p className="mt-1 text-xs leading-relaxed text-ink-500">{s.description}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* ============ Choose your vehicle ============ */}
        {content.vehicles.length > 0 && (
          <section className="mt-14">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-xl font-bold text-ink-900 sm:text-2xl">Choose your vehicle</h2>
              <div className="flex gap-1 rounded-full bg-ink-50 p-1" role="tablist" aria-label="Fare view">
                {(['one_way', 'round_trip'] as const).map((k) => (
                  <button
                    key={k}
                    type="button"
                    role="tab"
                    aria-selected={fareView === k}
                    onClick={() => setFareView(k)}
                    className={`flex min-h-[44px] items-center justify-center rounded-full px-4 text-xs font-semibold transition-colors ${
                      fareView === k ? 'bg-brand-600 text-white shadow-xs' : 'text-ink-500 hover:text-ink-700'
                    }`}
                  >
                    {k === 'one_way' ? 'One-Way Fare' : 'Round-Trip Fare'}
                  </button>
                ))}
              </div>
            </div>
            <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {content.vehicles.map((v) => {
                const fare = fareView === 'one_way' ? v.one_way : v.round_trip;
                return (
                  <div key={v.id} className="flex flex-col overflow-hidden rounded-2xl border border-ink-100 bg-white p-4 shadow-sm transition-shadow hover:shadow-md">
                    <div className="flex aspect-[3/2] w-full items-center justify-center overflow-hidden rounded-xl bg-ink-50/70 text-brand-500">
                      {v.image_url ? (
                        <img
                          src={v.image_url}
                          alt={v.name}
                          loading="lazy"
                          className={'block aspect-[3/2] w-full ' + fitClass(brand().vehicle_card_fit)}
                        />
                      ) : (
                        vehicleIcon(v.name)
                      )}
                    </div>
                    <p className="mt-4 text-base font-bold text-ink-900">{v.name}</p>
                    <p className="mt-1 text-xs text-ink-500">
                      Seats {v.seating_capacity} &middot; {v.luggage_capacity} bags{v.ac_available ? ' · AC' : ''}
                    </p>
                    <div className="mt-3 flex items-end justify-between">
                      {fare ? (
                        <p className="text-xl font-bold text-ink-900">
                          &#8377;{fare.amount}
                          <span className="ml-1 text-[11px] font-normal text-ink-400">
                            {fare.source === 'estimated' ? 'est. ' : ''}
                            {fareView === 'one_way' ? 'one-way' : 'round trip'}
                          </span>
                        </p>
                      ) : (
                        <p className="text-sm text-ink-400">Fare unavailable</p>
                      )}
                      <button
                        type="button"
                        onClick={() => setBookingOpen({ vehicleId: v.id })}
                        aria-label={`Book ${v.name}`}
                        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-brand-600 text-white shadow-xs transition-colors hover:bg-brand-700"
                      >
                        <ArrowRightIcon className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                );
              })}

              {content.vehicle_guidance.length > 0 && (
                <a
                  href="#vehicle-guidance"
                  className="flex flex-col justify-between rounded-2xl border border-dashed border-accent-300 bg-accent-50/60 p-5 transition-colors hover:bg-accent-50"
                >
                  <div>
                    <SuitcaseIcon className="h-8 w-8 text-accent-600" />
                    <p className="mt-3 text-base font-bold text-ink-900">Not sure which vehicle is right for you?</p>
                    <p className="mt-1 text-sm text-ink-600">Check our quick guide to find the perfect option for your trip.</p>
                  </div>
                  <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-accent-700">
                    View Vehicle Guide <ArrowRightIcon className="h-3.5 w-3.5" />
                  </span>
                </a>
              )}
            </div>

            {content.vehicle_guidance.length > 0 && (
              <div id="vehicle-guidance" className="mt-6 scroll-mt-24 rounded-2xl border border-dashed border-brand-200 bg-brand-50/40 p-5">
                <p className="flex items-center gap-2 font-semibold text-ink-900">
                  <SuitcaseIcon className="h-5 w-5 text-brand-500" /> Choosing the right vehicle
                </p>
                <ul className="mt-3 grid grid-cols-1 gap-x-8 gap-y-1.5 sm:grid-cols-2">
                  {content.vehicle_guidance.map((g, i) => (
                    <li key={i} className="text-sm text-ink-700">
                      <strong>{g.vehicle}:</strong> {g.note}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </section>
        )}

        {/* ============ Route overview / Why travel this route — real
            distance & duration only (no fabricated via-route waypoints or
            "best time to travel"); why-travel bullets are the same real,
            platform-wide reasons already generated. ============ */}
        <section className="mt-14 grid grid-cols-1 gap-8 lg:grid-cols-2">
          <div>
            <h2 className="text-xl font-bold text-ink-900 sm:text-2xl">Route overview</h2>
            <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-[1.2fr_1fr]">
              <div className="overflow-hidden rounded-2xl border border-emerald-100 bg-emerald-50/60">
                <div className="flex flex-col justify-center p-6">
                  <div className="flex flex-col items-center gap-1">
                    <span className="flex h-3.5 w-3.5 items-center justify-center rounded-full bg-brand-600 ring-4 ring-white" />
                    <span className="text-xs font-semibold text-ink-800">{content.to_city}</span>
                  </div>
                  <div className="my-2 ml-6 h-14 w-0.5 rounded-full border-l-2 border-dashed border-emerald-400" />
                  <div className="flex flex-col items-center gap-1">
                    <span className="flex h-3.5 w-3.5 items-center justify-center rounded-full bg-accent-500 ring-4 ring-white" />
                    <span className="text-xs font-semibold text-ink-800">{content.from_city}</span>
                  </div>
                </div>
                {roadStripImage && (
                  <img src={roadStripImage} alt="" className="h-24 w-full object-cover" loading="lazy" aria-hidden="true" />
                )}
                {!roadStripImage && <div className="h-16 w-full bg-gradient-to-r from-emerald-100 to-emerald-200" />}
              </div>
              <div className="rounded-2xl bg-white p-4 shadow-xs ring-1 ring-inset ring-ink-100">
                <div className="flex items-start gap-3 border-b border-ink-100 pb-3">
                  <RulerIcon className="mt-0.5 h-4 w-4 text-brand-500" />
                  <div>
                    <p className="text-xs text-ink-500">Distance</p>
                    <p className="text-sm font-bold text-ink-900">{content.journey.distance_km} km</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 pt-3">
                  <ClockIcon className="mt-0.5 h-4 w-4 text-brand-500" />
                  <div>
                    <p className="text-xs text-ink-500">Travel time</p>
                    <p className="text-sm font-bold text-ink-900">
                      {content.journey.typical_minutes_low}&ndash;{content.journey.typical_minutes_high} min
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <p className="mt-3 text-xs text-ink-400">{content.journey.note}</p>
          </div>

          {content.why_ridego.length > 0 && (
            <div>
              <h3 className="text-lg font-bold text-ink-900">Why travel this route?</h3>
              <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {content.why_ridego.slice(0, 4).map((w, i) => (
                  <div key={i} className="rounded-2xl border border-ink-100 bg-white p-4 shadow-xs">
                    <IconWrap tone={WHY_TONES[i % 4]}>{WHY_ICONS[i % 4]}</IconWrap>
                    <p className="mt-3 text-sm font-semibold leading-snug text-ink-800">{w}</p>
                  </div>
                ))}
              </div>
              <div className="relative mt-3 min-h-[140px] overflow-hidden rounded-2xl">
                {roadStripImage ? (
                  <img src={roadStripImage} alt="" className="absolute inset-0 h-full w-full object-cover" loading="lazy" aria-hidden="true" />
                ) : (
                  <div className="absolute inset-0 bg-gradient-to-br from-brand-100 to-brand-200" />
                )}
                <div className="absolute inset-0 bg-ink-900/35" />
                <p className="relative flex h-full items-center p-6 text-lg font-medium italic leading-snug text-white">
                  &ldquo;{content.travel_guide}&rdquo;
                </p>
              </div>
            </div>
          )}
        </section>

        {/* ============ Popular places / Pickup & drop points ============ */}
        <section className="mt-14 grid grid-cols-1 gap-8 lg:grid-cols-2">
          {content.to_city_image_url && (
            <div>
              <h2 className="text-xl font-bold text-ink-900 sm:text-2xl">Popular in {content.to_city}</h2>
              <div className="relative mt-5 min-h-[220px] overflow-hidden rounded-2xl shadow-sm">
                <img src={content.to_city_image_url} alt={content.to_city} className="absolute inset-0 h-full w-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-900/80 via-ink-900/10 to-transparent" />
                <p className="absolute bottom-4 left-4 right-4 text-sm font-semibold text-white">{content.to_city}</p>
              </div>
            </div>
          )}
          <div>
            <h2 className="text-xl font-bold text-ink-900 sm:text-2xl">Pickup &amp; drop points</h2>
            <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="rounded-2xl bg-white p-4 shadow-xs ring-1 ring-inset ring-ink-100">
                <p className="text-xs font-semibold uppercase tracking-wide text-ink-500">Pickup points ({content.from_city})</p>
                <ul className="mt-3 space-y-2">
                  {content.pickup_points.map((p, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-ink-800">
                      <MapPinIcon className="h-4 w-4 shrink-0 text-emerald-600" /> {p.label}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="rounded-2xl bg-white p-4 shadow-xs ring-1 ring-inset ring-ink-100">
                <p className="text-xs font-semibold uppercase tracking-wide text-ink-500">Drop points ({content.to_city})</p>
                <ul className="mt-3 space-y-2">
                  {content.drop_points.map((p, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-ink-800">
                      <MapPinIcon className="h-4 w-4 shrink-0 text-accent-600" /> {p.label}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* ============ Explore Related Routes — real, published sibling
            routes only. ============ */}
        {content.related_routes.length > 0 && (
          <section className="mt-14">
            <h2 className="text-xl font-bold text-ink-900 sm:text-2xl">Explore Related Routes</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {content.related_routes.map((r) => (
                <Link
                  key={r.slug}
                  to={`/routes/${r.slug}`}
                  className="inline-flex items-center gap-1 rounded-full border border-ink-200 bg-white px-4 py-2 text-sm text-ink-700 shadow-xs hover:border-brand-500 hover:text-brand-700"
                >
                  {r.from_city} <ArrowUpRightIcon className="h-3 w-3" /> {r.to_city}
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* ============ FAQs — two-column accordion ============ */}
        {content.faqs.length > 0 && (
          <section className="mt-14">
            <h2 className="text-xl font-bold text-ink-900 sm:text-2xl">Frequently asked questions</h2>
            <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {content.faqs.map((f, i) => (
                <details key={i} className="group rounded-xl border border-ink-100 bg-white p-4 shadow-xs transition-colors open:border-brand-200 hover:border-brand-200">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-3 font-medium text-ink-900">
                    {f.q}
                    <ChevronDownIcon className="h-4 w-4 shrink-0 text-ink-400 transition-transform group-open:rotate-180" />
                  </summary>
                  <p className="mt-2 text-sm text-ink-600">{f.a}</p>
                </details>
              ))}
            </div>
          </section>
        )}
      </div>

      {/* ============ Bottom CTA banner — real booking link + real contact
          info only. ============ */}
      <section className="mt-16 bg-ink-900 px-4 py-14 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl text-center text-white">
          <h2 className="text-2xl font-bold sm:text-3xl">
            Ready to book {content.from_city} to {content.to_city}?
          </h2>
          <p className="mt-3 text-sm text-white/70 sm:text-base">
            Compare real vehicle options and get a fare estimate in minutes.
          </p>
          <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => setBookingOpen({})}
              className="rounded-full bg-emerald-500 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-emerald-600"
            >
              Book this route now
            </button>
            {b.support_phone && (
              <a
                href={`tel:${b.support_phone}`}
                className="inline-flex items-center gap-2 rounded-full border border-white/30 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-white/10"
              >
                <PhoneIcon /> Call {b.support_phone}
              </a>
            )}
          </div>
        </div>
      </section>

      {bookingOpen && (
        <BookingPage
          embeddedPrefill={{
            tripType: 'one_way',
            pickup: content.from_city,
            drop: content.to_city,
            vehicleId: bookingOpen.vehicleId,
          }}
          onEmbeddedClose={() => setBookingOpen(null)}
        />
      )}

      {/*
        This top-level route sits outside AppLayout (a deliberate earlier
        choice, so it can be a standalone landing page — see the module
        doc comment above), so it doesn't get AppLayout's bottom nav for
        free the way every other /app/* page does. Rendering the same
        shared component here (not a reimplementation) keeps it in sync
        with the real nav automatically. `elevated` raises it above the
        booking modal's z-50 (BookingModalShell) so it stays visible and
        clickable while that modal is open; `reserveBottomNav` on the
        modal (passed in BookingPage when embedded) keeps the modal from
        overlapping it in return.
      */}
      <MobileBottomNav elevated />
      <Footer />
      </div>
    </>
  );
}
