import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { getPublicRoutePagesIndex, ApiError } from '../lib/api';
import type { RoutePagesIndexRoute } from '../types/api';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Skeleton } from '../components/ui/Skeleton';
import { getBootstrap } from '../lib/bootstrap';
import { brand } from '../lib/brand';

/**
 * /routes/ — the real, browsable index of every published route-marketing
 * page. Before this page existed there was no way to reach the full set of
 * /routes/{slug} pages except a direct link, and the route detail page's
 * breadcrumb "Routes" segment had nothing real to link to (see
 * includes/app-shell.php's breadcrumb JSON-LD for the server-side half of
 * this fix). Data comes from GET /ridego/v1/routes
 * (ridego_app_api_route_pages_index() in includes/app-api.php), which reuses
 * the exact same ridego_route_pages_list_published() helper the server-side
 * SSR snapshot for this same URL uses — so the client-rendered list here can
 * never disagree with what a crawler sees in the raw HTML.
 */
export function RoutesIndexPage() {
  const [routes, setRoutes] = useState<RoutePagesIndexRoute[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const currencySymbol = getBootstrap().currencySymbol;
  const brandName = brand().name;

  function load() {
    setLoading(true);
    setError(null);
    getPublicRoutePagesIndex()
      .then((res) => setRoutes(res.routes))
      .catch((err) => setError(err instanceof ApiError ? err.message : 'Could not load routes. Please try again.'))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  // Grouped by origin city — matches the grouping the server-rendered SSR
  // snapshot for this same URL uses, so there's no visible reflow in
  // structure once the SPA bundle boots and this replaces that snapshot.
  const grouped = useMemo(() => {
    if (!routes) return [];
    const byOrigin = new Map<string, RoutePagesIndexRoute[]>();
    for (const r of routes) {
      const list = byOrigin.get(r.from_city) ?? [];
      list.push(r);
      byOrigin.set(r.from_city, list);
    }
    return Array.from(byOrigin.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [routes]);

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <nav aria-label="Breadcrumb" className="mb-4 text-xs font-medium text-ink-500">
        <Link to="/" className="hover:text-ink-700">
          {brandName}
        </Link>
        <span className="mx-1.5">&rsaquo;</span>
        <span className="text-ink-700">Routes</span>
      </nav>

      <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Explore All Routes</h1>
      <p className="mt-2 max-w-2xl text-sm text-ink-500">
        Real outstation cab routes available on {brandName}, with distance and starting fares.
      </p>

      <div className="mt-8">
        {loading && (
          <div className="space-y-3">
            <Skeleton className="h-6 w-40" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={load} />}

        {!loading && !error && routes && routes.length === 0 && (
          <p className="text-sm text-ink-500">No routes are published yet. Please check back soon.</p>
        )}

        {!loading && !error && grouped.length > 0 && (
          <div className="space-y-8">
            {grouped.map(([origin, group]) => (
              <section key={origin}>
                <h2 className="text-lg font-semibold text-ink-900">From {origin}</h2>
                <ul className="mt-3 divide-y divide-ink-100 rounded-xl border border-ink-100">
                  {group.map((r) => (
                    <li key={r.slug}>
                      <Link
                        to={`/routes/${r.slug}`}
                        className="flex items-center justify-between gap-4 px-4 py-3 text-sm hover:bg-ink-50"
                      >
                        <span className="font-medium text-ink-900">
                          {r.from_city} to {r.to_city}
                        </span>
                        <span className="shrink-0 text-ink-500">
                          {Math.round(r.distance_km)} km
                          {r.starting_fare != null && (
                            <> &middot; from {currencySymbol}{Math.round(r.starting_fare)}</>
                          )}
                        </span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </section>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
