import { useCallback, useEffect, useState } from 'react';
import { getNotifications, markAllNotificationsRead, markNotificationRead, ApiError } from '../lib/api';
import type { AppNotification } from '../types/api';
import { Skeleton } from '../components/ui/Skeleton';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { EmptyState } from '../components/ui/EmptyState';
import { Button } from '../components/ui/Button';
import { DATA_CARD_CLASS } from '../components/ui/Zone';

const TABS: { key: 'all' | 'unread'; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'unread', label: 'Unread' },
];

function formatSentAt(sentAt: string): string {
  const d = new Date(sentAt.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return sentAt;
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function NotificationsPage() {
  const [tab, setTab] = useState<'all' | 'unread'>('all');
  const [page, setPage] = useState(1);
  const [rows, setRows] = useState<AppNotification[] | null>(null);
  const [total, setTotal] = useState(0);
  const [perPage, setPerPage] = useState(20);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [markingAll, setMarkingAll] = useState(false);
  const [markingId, setMarkingId] = useState<number | null>(null);

  const load = useCallback(async (t: 'all' | 'unread', p: number) => {
    setLoading(true);
    setError(null);
    try {
      const res = await getNotifications({ page: p, unreadOnly: t === 'unread' });
      setRows(res.rows);
      setTotal(res.total);
      setPerPage(res.per_page);
      setUnreadCount(res.unread_count);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load your notifications. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(tab, page);
  }, [tab, page, load]);

  function changeTab(t: 'all' | 'unread') {
    setTab(t);
    setPage(1);
  }

  async function handleMarkRead(id: number) {
    setMarkingId(id);
    try {
      const res = await markNotificationRead(id);
      setUnreadCount(res.unread_count);
      setRows((prev) => (prev ? prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)) : prev));
      if (tab === 'unread') {
        setRows((prev) => (prev ? prev.filter((n) => n.id !== id) : prev));
        setTotal((t) => Math.max(0, t - 1));
      }
    } catch {
      // Leave the row as-is; the next full load will reconcile state.
    } finally {
      setMarkingId(null);
    }
  }

  async function handleMarkAll() {
    setMarkingAll(true);
    try {
      await markAllNotificationsRead();
      await load(tab, page);
    } catch {
      // Ignore; user can retry.
    } finally {
      setMarkingAll(false);
    }
  }

  const canPrev = page > 1;
  const canNext = page * perPage < total;
  const hasUnreadShown = unreadCount > 0;

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Notifications</h1>
          <p className="text-sm text-ink-500">Updates about your bookings and account.</p>
        </div>
        {hasUnreadShown && (
          <Button variant="secondary" size="sm" onClick={handleMarkAll} loading={markingAll} disabled={markingAll}>
            Mark all as read
          </Button>
        )}
      </div>

      <div className="mt-6 flex gap-1 overflow-x-auto border-b border-ink-100" role="tablist" aria-label="Notification filter">
        {TABS.map((t) => (
          <button
            key={t.key}
            role="tab"
            aria-selected={tab === t.key}
            onClick={() => changeTab(t.key)}
            className={`shrink-0 whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 ${
              tab === t.key ? 'border-brand-600 text-brand-700' : 'border-transparent text-ink-500 hover:text-ink-800'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading notifications">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="mt-2 h-3 w-32" />
              </div>
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={() => load(tab, page)} />}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState
            title={tab === 'unread' ? "You're all caught up" : 'No notifications yet'}
            description={
              tab === 'unread'
                ? 'You have no unread notifications.'
                : "We'll let you know here when there's something new."
            }
          />
        )}

        {!loading && !error && rows && rows.length > 0 && (
          <>
            <ul className="space-y-3">
              {rows.map((n) => (
                <li
                  key={n.id}
                  className={`${DATA_CARD_CLASS} p-4 transition sm:p-5 ${
                    n.is_read ? '' : 'bg-brand-50 ring-brand-100'
                  }`}
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="flex items-start gap-2">
                      {!n.is_read && (
                        <span
                          className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand-600"
                          aria-hidden="true"
                        />
                      )}
                      <div>
                        <p className="text-sm text-ink-900">{n.message}</p>
                        <p className="mt-1 text-xs text-ink-500">{formatSentAt(n.sent_at)}</p>
                      </div>
                    </div>
                    {!n.is_read && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleMarkRead(n.id)}
                        loading={markingId === n.id}
                        disabled={markingId === n.id}
                      >
                        Mark as read
                      </Button>
                    )}
                  </div>
                </li>
              ))}
            </ul>

            <div className="mt-6 flex items-center justify-between">
              <p className="text-sm text-ink-500">
                Page {page} of {Math.max(1, Math.ceil(total / perPage))} &middot; {total} notification{total === 1 ? '' : 's'}
              </p>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" disabled={!canPrev} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                  Previous
                </Button>
                <Button variant="secondary" size="sm" disabled={!canNext} onClick={() => setPage((p) => p + 1)}>
                  Next
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
