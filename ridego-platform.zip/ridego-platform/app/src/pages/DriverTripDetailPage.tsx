import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ApiError } from '../lib/api';
import {
  driverTripArrived,
  driverTripEnRoute,
  driverTripNoShow,
  driverTripStart,
  getDriverTrip,
  type DriverTripDetail,
} from '../lib/api-team';
import { useToast } from '../context/ToastContext';
import { Button } from '../components/ui/Button';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Skeleton } from '../components/ui/Skeleton';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { DATA_CARD_CLASS } from '../components/ui/Zone';

const STATUS_LABELS: Record<string, string> = {
  confirmed: 'Confirmed',
  vendor_assigned: 'Vendor Assigned',
  driver_en_route: 'En route to pickup',
  trip_started: 'Trip in progress',
  completed: 'Completed',
  cancelled: 'Cancelled',
  no_show: 'No-show',
  expired: 'Expired',
};

// TRACE: route /app/driver/trips/:id → full detail for one trip assigned (now or previously) to the
//        signed-in driver, with the real state-machine actions this driver can take next (en route →
//        arrived → start with client OTP, or report a no-show) — the piece DriverDashboardPage never
//        had even though the backend endpoints (RG-012) have existed since before this page did.
//        Preconditions: trip belongs to this driver (server 404 otherwise). Postconditions: each action
//        re-fetches the trip so the UI always reflects the server's own state machine, never an
//        optimistic guess. Edge cases: wrong-state action (409, shown inline), trip no longer the
//        driver's CURRENT assignment (actions hidden, detail still viewable — e.g. from history).
export function DriverTripDetailPage() {
  const { id } = useParams();
  const tripId = Number(id);
  const toast = useToast();
  const [trip, setTrip] = useState<DriverTripDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [otp, setOtp] = useState('');
  const [noShowOpen, setNoShowOpen] = useState(false);
  const [noShowReason, setNoShowReason] = useState('');

  const load = useCallback(async () => {
    setError(null);
    try {
      setTrip(await getDriverTrip(tripId));
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not load this trip.');
    }
  }, [tripId]);

  useEffect(() => {
    if (Number.isFinite(tripId) && tripId > 0) void load();
    else setError('Invalid trip.');
  }, [tripId, load]);

  async function runAction(fn: () => Promise<{ success: boolean; message: string }>) {
    if (busy) return;
    setBusy(true);
    setActionError(null);
    try {
      const res = await fn();
      toast.show(res.message, 'success');
      await load();
    } catch (e) {
      setActionError(e instanceof ApiError ? e.message : 'That action could not be completed. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  async function submitStart(e: FormEvent) {
    e.preventDefault();
    if (!otp.trim()) {
      setActionError('Ask the customer for their pickup OTP to start the trip.');
      return;
    }
    await runAction(() => driverTripStart(tripId, otp.trim()));
    setOtp('');
  }

  async function submitNoShow() {
    if (!noShowReason.trim()) {
      setActionError('Please give a reason for the no-show.');
      return;
    }
    setNoShowOpen(false);
    await runAction(() => driverTripNoShow(tripId, noShowReason.trim()));
    setNoShowReason('');
  }

  if (error) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-8">
        <ErrorBanner message={error} onRetry={load} />
        <Link to="/driver" className="mt-4 inline-block text-sm font-medium text-brand-700 hover:text-brand-800">
          Back to my trips
        </Link>
      </div>
    );
  }
  if (!trip) {
    return (
      <div className="mx-auto max-w-2xl space-y-3 px-4 py-8">
        <Skeleton className="h-8 w-1/2" />
        <Skeleton className="h-40 w-full rounded-xl" />
      </div>
    );
  }

  const canActOn = trip.is_current_assignment && !['completed', 'cancelled', 'no_show', 'expired'].includes(trip.status);
  const canEnRoute = canActOn && ['confirmed', 'vendor_assigned'].includes(trip.status);
  const canArrive = canActOn && trip.status === 'driver_en_route' && !trip.driver_arrived_at;
  const canStart = canActOn && trip.status === 'driver_en_route' && Boolean(trip.driver_arrived_at);
  const canNoShow = canStart; // same precondition: en route AND already arrived

  return (
    <div className="mx-auto max-w-2xl px-4 py-8 sm:px-6">
      <Link to="/driver" className="text-sm font-medium text-brand-700 hover:text-brand-800">
        &larr; Back to my trips
      </Link>

      <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-2xl font-bold text-ink-900">{trip.booking_number}</h1>
        <span className="rounded-full bg-brand-50 px-3 py-1 text-xs font-semibold text-brand-700">
          {STATUS_LABELS[trip.status] ?? trip.status}
        </span>
      </div>

      <section className={`mt-6 space-y-2 ${DATA_CARD_CLASS} p-5`}>
        <p className="text-lg font-semibold text-ink-900">
          {trip.pickup_city} &rarr; {trip.drop_city}
        </p>
        <p className="text-sm text-ink-600">
          {trip.journey_date} at {trip.journey_time.slice(0, 5)}
        </p>
        <p className="text-sm text-ink-700">Pickup: {trip.pickup_address}</p>
        {trip.drop_address && <p className="text-sm text-ink-700">Drop: {trip.drop_address}</p>}
        <p className="text-sm text-ink-600">
          {trip.passengers} passenger{trip.passengers === 1 ? '' : 's'}
          {trip.luggage_count ? ` · ${trip.luggage_count} bag(s)` : ''}
        </p>
        {trip.special_requests && <p className="text-sm text-ink-600">Note: {trip.special_requests}</p>}
      </section>

      {trip.is_current_assignment && (
        <section className={`mt-6 space-y-2 ${DATA_CARD_CLASS} p-5`}>
          <h2 className="text-sm font-semibold text-ink-900">Customer</h2>
          <p className="text-sm text-ink-700">{trip.client_name}</p>
          {trip.client_phone && (
            <a href={`tel:${trip.client_phone}`} className="text-sm font-medium text-brand-700 hover:text-brand-800">
              Call {trip.client_phone}
            </a>
          )}
        </section>
      )}

      <section className={`mt-6 space-y-3 ${DATA_CARD_CLASS} p-5`}>
        <h2 className="text-sm font-semibold text-ink-900">Trip progress</h2>
        <ol className="space-y-2 text-sm">
          <li className="flex items-center gap-2">
            <span className={`h-2 w-2 rounded-full ${trip.driver_en_route_at ? 'bg-brand-600' : 'bg-ink-200'}`} />
            En route to pickup{trip.driver_en_route_at ? ` · ${trip.driver_en_route_at}` : ''}
          </li>
          <li className="flex items-center gap-2">
            <span className={`h-2 w-2 rounded-full ${trip.driver_arrived_at ? 'bg-brand-600' : 'bg-ink-200'}`} />
            Arrived at pickup{trip.driver_arrived_at ? ` · ${trip.driver_arrived_at}` : ''}
          </li>
          <li className="flex items-center gap-2">
            <span className={`h-2 w-2 rounded-full ${trip.trip_started_at ? 'bg-brand-600' : 'bg-ink-200'}`} />
            Trip started{trip.trip_started_at ? ` · ${trip.trip_started_at}` : ''}
          </li>
          <li className="flex items-center gap-2">
            <span className={`h-2 w-2 rounded-full ${trip.status === 'completed' ? 'bg-brand-600' : 'bg-ink-200'}`} />
            Completed{trip.trip_ended_at ? ` · ${trip.trip_ended_at}` : ''}
          </li>
        </ol>
        {trip.status === 'no_show' && trip.no_show_reason && (
          <p className="text-sm font-medium text-danger-600">No-show reason: {trip.no_show_reason}</p>
        )}

        {actionError && <p role="alert" className="text-sm font-medium text-danger-600">{actionError}</p>}

        {canActOn && (
          <div className="space-y-3 pt-2">
            {canEnRoute && (
              <Button type="button" fullWidth loading={busy} onClick={() => runAction(() => driverTripEnRoute(tripId))}>
                Mark en route to pickup
              </Button>
            )}
            {canArrive && (
              <Button type="button" fullWidth loading={busy} onClick={() => runAction(() => driverTripArrived(tripId))}>
                Mark arrived at pickup
              </Button>
            )}
            {canStart && (
              <form onSubmit={submitStart} className="space-y-2 rounded-lg bg-ink-50 p-3">
                <label htmlFor="pickup-otp" className="block text-sm font-medium text-ink-700">
                  Ask the customer for their pickup OTP to start the trip
                </label>
                <input
                  id="pickup-otp"
                  inputMode="numeric"
                  className="w-full rounded-lg border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  disabled={busy}
                  maxLength={6}
                />
                <Button type="submit" fullWidth loading={busy}>
                  Start trip
                </Button>
              </form>
            )}
            {canNoShow && (
              <Button type="button" fullWidth variant="danger" loading={busy} onClick={() => setNoShowOpen(true)}>
                Report no-show
              </Button>
            )}
          </div>
        )}
        {!trip.is_current_assignment && (
          <p className="text-sm text-ink-500">
            This trip is no longer your current assignment — it&apos;s shown here for your records only.
          </p>
        )}
      </section>

      <ConfirmDialog
        open={noShowOpen}
        title="Report a no-show?"
        description={
          <div className="space-y-2 text-left">
            <p className="text-sm text-ink-700">Tell us what happened — this is recorded on the booking.</p>
            <textarea
              className="w-full rounded-lg border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              rows={3}
              value={noShowReason}
              onChange={(e) => setNoShowReason(e.target.value)}
              placeholder="e.g. Waited 20 minutes, customer unreachable"
            />
          </div>
        }
        confirmLabel="Report no-show"
        cancelLabel="Cancel"
        confirmVariant="danger"
        onConfirm={submitNoShow}
        onCancel={() => setNoShowOpen(false)}
      />
    </div>
  );
}
